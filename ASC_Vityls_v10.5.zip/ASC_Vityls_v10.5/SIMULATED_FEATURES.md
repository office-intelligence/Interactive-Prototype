# SIMULATED_FEATURES — for Henry

Everything below is stubbed in the browser (localStorage) and shows **"Not connected"** in the clean build.

| Area | Today | Replace with |
|---|---|---|
| Storage | `svRead/svWrite`, `medRepo` (localStorage) | Backend API + DB (per-tenant, encrypted, BAA) |
| Sign-in / staff | Role-titled "(test account)" users, PIN 1234 | Real auth (SSO/MFA), per-user PIN hash |
| Nightingale summaries / OCR | `draftHistory()` builds a draft only from data already in the record; intake OCR is off in the clean build | LLM + OCR service (BAA); Nightingale only drafts, and clinicians sign |
| Payments | Recorded locally, no charge | Finix (tokenized card; no PAN in the app) |
| Eligibility / claims | Not connected | Stedi 270/271, 837P/I, 277CA, 835 |
| SMS / email (next-day text, reminders) | Logged only | Azure Communication Services |
| Fax in/out, intake email address | Manual scan → blank intake item | Documo or Sinch fax; inbound email parser |
| Audit log | localStorage | Append-only server audit |
| Demo pack | `?demo=1` loads fictional patients | Delete for production, or keep it for sales demos |
| "Simulated" wording | Display layer `asc10/wording.ts` rewrites legacy strings | Remove the layer once connectors are live |

| Vendor connectors | `src/connectors/index.ts`: every call throws `NotConnected`; setup is gated by the center BAA plus each vendor BAA (recorded locally) | Server-side connectors; keys stored on the server only |
| Module entitlements | `core/practices.ts` in localStorage (`VITE_CORE_ASC=1`) | CenterModule table checked on every API route; nightly trial expiry |
| CEO console | Owner test PIN 1234; plan prices are test prices; MRR counts live practices only | Server owner role + 2FA; Finix subscriptions |
| Onboarding / leads | Wizard progress and leads stored in the browser | POST /signup, /onboarding/steps, /go-live (design doc §13.5) |
| Question bank answers | `asc10-answers` per case in localStorage; Export / Print uses the browser print dialog | Answers table with provenance; server-rendered, hashed PDFs on request |

- v10.2 · Compliance & credentials "Ask Nightingale for a compliance task": scripted, on-device drafts only (no AI service connected); a person confirms each task.
- v10.2 · Anesthesia questionnaire summary on Anesthesia/Surgeon: a rule-based list of the patient's "yes" answers (Nightingale draft), not an AI summary.
- v10.3 · Ambient capture on the native OR / PACU nursing records (and any station form): an on-device sample transcript plus local rules; drafts need nurse confirmation. No audio is recorded or sent. A BAA-covered speech service replaces the adapter.
- v10.3 · Dictation mics (Interval H&P, Brief OP report, formal op report): an editable sample transcript, parsed on the device. The formal op dictation is stored as a draft on the case only.
- v10.3 · Portal / At-home "Send forms": queued in the simulated outbox; nothing is texted or emailed.
