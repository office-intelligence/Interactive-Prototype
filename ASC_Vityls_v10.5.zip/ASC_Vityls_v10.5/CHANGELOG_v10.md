# ASC.Vityls v10.5 — Changelog (branch asc-v10, from v10.4 @ 04a21d3)

All data is fictional. The default build is clean; the demo pack loads only with `?demo=1`.

## 1 · Anesthesia station back to the simple layout
- The v10.4 three-form Next/Back sequence is gone.
- The station now shows the medical history, a Nightingale summary card (draft only) covering the history and the anesthesia questionnaire answers, and a link to open the full questionnaire.
- It also shows the short evaluation panel: airway, ASA and focused exam, anesthesia type and technique, and the pre-induction re-evaluation.
- The Consents card lists only the anesthesia consent. It opens full screen so it can be signed there.
- Step navigation stays inside the station. The OR/PACU built-in forms and the other v10.4 fixes (close X, Portal overlay, surgeon "As per facility protocol") are kept.

## 2 · Fix: clicking the Booking step crashed the app
- Root cause: Case details (`asc83/frontdesk.tsx`) rendered `c.d.equipment || c.d.implants` directly. Cases saved by nursing, and the demo cases, store implants as an object (`{none:true}` / `{list}`). React threw error #31, and with no error boundary the whole app went blank.
- Fix: a `txt()` helper turns every booking field (assistant, anesthesia type, equipment/implants, notes, booked by) into text, and the booked date is guarded.
- Safety net: a new `ScreenBoundary` wraps the station host. If a screen fails, it shows "This screen could not open." with a Close button and the rest of the app keeps working.

## Tests
- tsc stays at the 68-error baseline. Node tests: 22/22 passed.
- walk105 (clean build, full flow): 163/163 passed. It clicks every stepper step (11) from 6 benches and 6 step panels, with no page errors and no blank screens.
- Demo probe: Booking from check-in opens for all 14 demo cases.

# ASC.Vityls v10.4 — Changelog (branch asc-v10, from v10.3 @ ee0fb13)

All data is fictional. The default build is clean; the demo pack loads only with `?demo=1`.

## 1 · Anesthesia station: three built-in forms in sequence
- The form library's **Anesthesia questionnaire → Anesthesia evaluation → Anesthesia consent** are rendered natively in the station, the same way as OR and PACU (no link, no iframe). The forms keep their own layout and checkmarks.
- **Step indicator** at the top: three tappable steps, each showing its number, title and status (Not started / In progress / N signed / Signed). The current step is outlined, and signed steps show ✓.
- Large **‹ Back** and **Next: … ›** buttons above and below the form, plus "Form N of 3".
- Each form autosaves to the case, has the **ambient mic** (simulated; it fills drafts for confirmation) and is **signed inside the form** using its own signature panel.
  - The anesthesia provider signs the evaluation with a drawn signature and PIN.
  - The consent shows the patient's signature captured at nursing admission.
- A signed in-form evaluation unlocks the immediate pre-induction re-evaluation. If the form records the ASA class, it is copied to the case.
- The separate airway/ASA/technique panels are removed because they duplicated the evaluation form. The anesthesia questionnaire summary and consent link cards are also removed, since both forms are now part of the sequence. Medical history and the pre-induction re-evaluation stay below the forms.

## 2 · Portal / At-home slider on Today
- The slider is rendered at the top of the page (portal to the document body, z-index 400), so it always overlays Today and every other page instead of loading behind it.

## 3 · Surgeon station
- The Doctor orders block is replaced by the text **"As per facility protocol"**.
- The anesthesia items are removed (questionnaire summary and anesthesia consent). The surgical consent link is kept.

## 4 · Close X and the journey stepper, at every station
- Root cause: since v10.3, built-in station forms inherited an older full-screen rule (`.a82-form { position:fixed; inset:0; z-index:300 }`). The form silently became a full-screen layer under the journey stepper and covered the station header and its close X. Built-in forms are now part of the station's normal scroll.
- Full-screen forms (opened from a link) are rendered at the top of the page. The stepper is hidden while one is open, so the form's own close X is always visible.
- Station headers (case card, Capture / Upload, close X) are pinned below the stepper while the station scrolls. The station panel can no longer be scrolled away by the browser.

## Tests (v10.4)
- `scripts/walk104.py` runs the full v10.3 walk plus the v10.4 checks: **154/154 passed** on the clean build. Screenshots are in `/workspace/vityls/asc10_shots/v10.4/`.
  - Anesthesia: each of the three steps, the step indicator, Next and Back, ambient mic, and the evaluation signed in-form.
  - Surgeon: the "As per facility protocol" text and the removed anesthesia items.
  - The Portal slider is the topmost element on Today.
  - The close X is visible, with no stepper overlap, at the front, pre-op, anesthesia, surgeon, OR and PACU station panels after scrolling the form, and on the nursing, anesthesia, surgeon, PACU and discharge benches.
- `tsc`: 68 errors (legacy baseline), none new. Unit tests asc87/88/89: 22/22.
- Privacy: the three anesthesia forms were checked. They carry only the neutral placeholder (scrubbed in v10.3), with no real-looking patient data.

---

# ASC.Vityls v10.3 — Changelog (branch asc-v10, from v10.2 @ 0ff5a9b)

All data is fictional. The default build is clean, and the demo only loads with `?demo=1`.

## A · OR and PACU nursing records rendered natively in the station
- Kevin's two form-library HTML forms are now part of the station page itself. There is no link, no iframe and no pop-up.
  - **OR station:** Intra-Operative Nursing Record & Surgical Time-Out Log.
  - **PACU station:** PACU Progress & Recovery Record, on both the PACU station and the PACU/Discharge bench.
- The layout, section banners and every checkmark match the library HTML (OR: 48 checkboxes, PACU: 9 checkboxes plus the Aldrete and flowsheet tables). The form's own time-out checkmarks now show; earlier they were replaced by a pointer to the Universal Protocol checklist.
- Tablet sizing: 24 px checkboxes, rows at least 44 px tall that can be tapped, 16 px inputs.
- The form header shows the case's patient. The template's sample patient line is removed (see the PHI note).
- Answers **autosave** to the case (form record plus case facts) about 0.7 s after each change, so there is no Save button to forget. Fields are prefilled from the case (procedure, surgeon, rooms, OR event times), and prefilled values are tagged "From case" or "Carried".
- **Ambient capture** (microphone button in the form header): tap to start, tap to stop. Heard checkmarks and fields are filled as **amber drafts** marked "Voice — reviewed — confirm". The nurse checks each one, then taps "Confirm all". Each fill is audited.
  - This is **simulated**: an on-device sample transcript plus local rules. Nothing is recorded or sent. A speech service covered by a BAA plugs into the same adapter later.
- Same approach for the other library forms: opening any form from a station's form list renders it inline in the station panel, with autosave and ambient capture. It no longer replaces the screen with a full-screen viewer.
- New voice rule: a checkbox is suggested when its label's key words are heard, e.g. "fire risk assessment completed".

## B · Rooms have one source of truth
- The **Schedule columns** list is the only place rooms are kept.
- Practice › Hours & rooms shows that list read-only, with a link: "Add or edit rooms in Schedule columns".
- Schedule columns notes that its rooms are used on the schedule, in booking and on Hours & rooms.

## C · Nursing admission consents
- Each consent has an "Open & sign" button that opens the actual Anesthesia Consent / Procedure Consent form inline at nursing.
- The patient signs in the form's own signature box: drawn signature plus attestation. The case consent status follows the signature in the form.
- The Procedure Consent no longer forces the surgeon to sign before the patient (sequential off), so the patient can sign at nursing and the surgeon can co-sign at any time.

## D · Portal / At-home button
- The button now opens **Portal / At-home forms** for the chart that is open (or a patient picker):
  - the forms already sent to the patient, each with its status (Not started / In progress / Completed);
  - a checklist of the At-home station's forms to send by text, email or portal. Sending is simulated: the message goes to the outbox and is audited.
- Booking intake is still one tap away from a link in that slider.

## E · Form viewer
- The journey stepper is hidden while a full-screen form is open, so its icons are no longer drawn over the consent.

## F · Booking step in Case details
- The Booking step now has the same layout as the other steps: patient card, "Step 1 · Booking" header and section cards.
  - **Case:** procedure, CPT, surgeon, assistant, date/time and length, room, anesthesia type, anesthesia provider, special equipment / implants.
  - **Booking:** when it was booked and by whom, where it was booked from, booking-request notes.
  - **Patient & payment.**
- "Add a Case" has a new **Special equipment / implants** field and records when the case was booked.

## G · Surgeon station
- Interval H&P has four new checkboxes plus a **Plan notes** text area:
  - "Patient remains a suitable candidate for the planned procedure and anesthesia"
  - "No new contraindications identified"
  - "Proceed as planned" and "Defer / modify plan (notes below)", which exclude each other
- Signing the H&P now needs Proceed or Defer to be ticked. The signed record stores all four answers and the plan notes.
- Dictation microphones (simulated):
  - **Interval H&P:** ticks the boxes it hears and adds to Plan notes, flagged "review before you sign".
  - **Brief OP report:** fills pre/post diagnosis, findings, EBL, specimens, implants, complications and condition.
  - **Formal op report:** saves a dictation draft on the case for the later mobile app and dictation service.

## Privacy
- Kevin's two attached forms contained a real-looking patient name, date of birth and MRN in the `<title>` and header. It was replaced with a neutral placeholder before bundling. The same name and MRN were also found and removed in 27 other bundled library forms, two concept pages and the design-reference files.

## Tests (v10.3)
- `scripts/walk103.py` runs the v10.2 walk with the fictional patient Jordan Example, plus all v10.3 checks: **130/130 passed** on the clean build. Screenshots are in `/workspace/vityls/asc10_shots/v10.3/` (43 PNGs).
- `tsc`: 68 errors, the same legacy baseline, none new. Unit tests asc87/88/89: 22/22.

---

# ASC.Vityls v10.2 — Changelog (branch asc-v10, from v10.1 @ 884c16a)

All data is fictional. The default build is clean. The demo pack loads only with `?demo=1`.

## Stations
- **One Capture / Upload per station**, top right of the station header (the OR panel too). Per-item Upload buttons and in-section Capture buttons are removed.
- **Upload is general**: no document type or category. A scanned stack can go in as one multipage PDF. Each file is tagged with the station it came from ("Uploaded at Arrival & check-in"), and all of them land in the case documents folder. Files up to about 4 MB keep their content on this device; Henry's server storage replaces this.
- **One confirm checkmark per station** ("Everything at … is verified"). One tick confirms the whole station and is audited once:
  - Check-in: all documents are received and ID and insurance are confirmed.
  - Nursing: all 16 admission items plus the surgeon's pre-op orders are ticked.
  - PACU: all post-op orders are ticked.
  - Anesthesia, Surgeon, OR and Discharge: a station confirmation is recorded.
- The per-item checkboxes are hidden on Nursing and on the pre-op and post-op order lists. Items show ✓ or ○.
- **Missing information** (replaces "Forms · question bank"):
  - A station shows only its own team's questions. Front desk also asks the patient-supplied questions the patient left blank on the intake forms, which fixes questions leaking across stations.
  - Fields are laid out as an aligned online form, with labels in one column and inputs in the other.
  - Form titles are shown only for forms that station owns. Anything else is grouped under "Other details".
  - Export / Print is removed from the stations.
- **Check-in**: "At-home forms" is removed (it duplicated Intake forms). The ID and insurance cards panel (front and back, camera or upload) now always shows on the check-in station.
- **Consents are signed at Nursing admission.** A new Consents card lets the patient sign the anesthesia and surgical consents there, with the nurse as witness (PIN). The consent signing sections were removed from the Anesthesia and Surgeon stations.
- **Anesthesia and Surgeon stations** show:
  - An anesthesia questionnaire summary (Nightingale draft that lists the "yes" answers), with an "Open the questionnaire" link.
  - Links to the anesthesia and surgical consents, with "Signed at nursing admission" status.

## Orders
- **Facility standard orders for every surgeon.** Kevin's form-library "PACU & Post Anesthesia Orders" are now the standard post-op (PACU) orders for every surgeon, unless the surgeon saves their own version under Practice Settings › Standard pre-op & post-op orders. The orders are pain (fentanyl, hydromorphone, ketorolac, acetaminophen), nausea (ondansetron, promethazine, metoclopramide, dexamethasone), vital signs, O₂ to keep SpO₂ > 92%, warming, IV fluids, Aldrete ≥ 9 and notify-physician.
- The attached file contains PACU/post-op orders only. The **pre-op** standard is the facility's existing standard pre-op set: antibiotic prophylaxis, pre-emptive analgesia, PONV patch, SCDs, glucose, NPO/site/ride. These are for Medical Director approval.
- The duplicate "Standard doctor's orders list" is removed from Surgery settings, leaving one list. Its PACU seed entries now match the same form.

## Wording
- A display layer for internal terms runs in every ASC build, demo included. It removes or replaces "Question bank", "(Bank only — no template field)", "seeded (test)", "(test account)", version notes such as "v0.4:", and "Surgery.Vityls". The clean build also removes leftover "fictional" and "simulated" wording.
- The Surgery settings page no longer shows the edition card or the "This practice uses Surgery.Vityls" card.

## Look & layout
- The Nightingale Spark wordmark (top left) is now 44 px tall, up from 28 px (34 px on phones).
- The journey stepper and the Case details slider now share one width and edge, so they no longer overlap.
- Settings pages use white section cards (Surgery settings, Visit types, Staff, Facility profile). Staff rows are shaded in six rotating light colors.

## Settings
- **Facility profile**: the two profile sections are merged into one. The facility card holds name, address, phone and the rest. The second block is now just "Hours & rooms", with OR 1 and OR 2 as the default rooms.
- **Surgery settings**: the "Plain-English test descriptions" section is removed, because Nightingale explains results in the portal.
- **Visit types page**: "Schedule columns" moved to the top. The default room columns are OR 1 and OR 2 only (OR 3, Procedure room and staff columns were removed from the defaults). Surgeons stay, because booking needs them.
- **Compliance & credentials**: new "Ask Nightingale for a compliance task" chat box. Nightingale drafts a task, with a due date when one is named, and a person confirms it. It is scripted and on-device, and nothing is sent.

## Schedule
- "Add visit" is renamed to **Add a Case**.
- The Booking intake slider, opened from At-home/Portal on Today, is unchanged and tested.

## Tests (v10.2)
- `scripts/walk102.py` runs on the clean build with a fictional patient (Jordan Example) through booking, check-in, verify, nursing, anesthesia, surgeon, OR, PACU, discharge and closure, plus the settings checks: **100/100 passed**. Screenshots are in `/workspace/vityls/asc10_shots/v10.2/`.
- `tsc` shows 68 errors, the legacy baseline, with none new. Unit tests asc87, asc88 and asc89 pass (22/22).
- `walk10.py` and `walk101.py` (v10.1) were not re-run. They click per-item "Received" and "Export / Print" buttons, which no longer exist.

---

# ASC.Vityls v10.1 — Changelog (branch asc-v10)

All data is fictional. The default build is still clean; the demo pack loads only with `?demo=1`.

## 5 · Question bank on the stations
- Bank v1.1 (218 questions) and 30 center templates live under `src/surgery/asc10/bank/` (engine from v7.8/v7.9).
- Every patient bench, plus the OR step, has a "Forms · question bank" section. Fields are grouped by template and each maps to one bank question, answered once per case. Only unanswered fields show; the rest are under "Show answered".
- Booking data and the official medical history prefill their answers, so they are never asked again.
- The form is rendered from the answers only when someone presses **Export / Print**. Nothing is generated automatically.
- Settings › Forms & consents › Question bank lists every question by template.

## 6 · Vityls Core on for ASC
- `VITE_CORE_ASC=1` runs ASC2 on the module system with one center record. The default is the full ASC bundle (same as v9.1), with Email intake as an add-on.
- Locked modules show as "Try free" teasers. Trials, expiry and read-only all work, and dependencies are added automatically.
- Starter plan (Email intake only): only Email intake is usable, the rest is teasers, and there are no station shortcuts. The clean build has no sample mail.

## 7 · CEO console (owner only)
- Opens at `#vityls-console` (also `#vityls-admin` and `#ceo`) and replaces CeoAdminDashboard and AdminConsole in the ASC build.
- It has its own owner sign-in (test PIN 1234) and shows no patient data, only counts.
- Covers practices, edition, plan (test prices), status, modules (on/off, trial start, +7 days, end), MRR, Finix "Not connected", leads, usage (staff, cases, portal Free/Plus) and the audit log.
- Starts empty in the clean build. With `?demo=1` it shows 4 fictional demo practices.

## 8 · Settings in 8 groups + Onboarding Wizard
- The 8 groups follow design doc §13.2: Practice profile, Rooms & hours, People & roles, Surgeons & standing orders, Forms & consents, Billing & fees, Nightingale & notifications, Security & audit.
- New pages: the surgeon standing pre-op/post-op list editor (versioned), vendor connectors, the audit log viewer and the question bank.
- Onboarding wizard steps: Plan (Starter or Full) → the 8 groups → Go live. Go live is blocked until the BAA is recorded. It requests a go-live review, which appears as a lead in the CEO console, and the center shows up as a sandbox practice.

## 9 · Vendor connector layer (`src/connectors/`)
- Stubs for Finix (tokenized), Stedi (270/271, 837P/I, 277CA, 835), Azure Communication Services (SMS and email), fax (Documo or Sinch) and the intake email address.
- Every call throws `NotConnected`. Setup is gated by the center BAA plus each vendor's BAA.
- Key-like values are refused in the browser. A connector can only reach "Configured · awaiting server".

## Gaps closed
- The Surgeon station no longer has the consent or interval H&P form links. It uses a brief consent note and keeps paper upload and e-sign. Anesthesia's consent "Open" link was replaced with Capture/Upload.
- Fixed: the demo pack is no longer lost on reload (a seed reset was clearing the demo flag).
- Removed sample names from teaser previews and the form-editor preview.

## Tests (v10.1)
- `scripts/walk10.py`: 46/46 passed (full fictional episode plus the question-bank and surgeon checks).
- `scripts/walk101.py`: 33/33 passed (console, modules, wizard, settings, lists, connectors).
- Storage after a clean load has zero seed or demo names. `tsc` shows 68 errors (legacy baseline, none new).

---

# ASC.Vityls v10 — Changelog (branch asc-v10, from asc-v9.1 @ 8132894)

All data is fictional. The default build is clean, with no patients, sample summaries or sample faxes.

## 1 · Design (kit v1.2)
- Kit tokens and `vityls.css` load locally, along with DM Sans (OFL) and the Lucide icons (ISC). Styling is scoped to `html[data-product="asc"]`.
- The ASC green Nightingale Spark wordmark is in the shell.
- Buttons are pill-shaped, with primary, danger and disabled states. Fields are rounded and the focus ring is visible.
- Every dialog closes with a round X.
- Allergy cards (`AllergyCard`) are green for NKDA, red for allergies and amber for "Not reported". They are used on every case card.
- Alerts and toasts follow the kit (`KitToast`, `KitAlert`).
- Placeholders are a lighter gray (#9CA39F) at weight 400, and data examples read "e.g. …".
- Phone fields format as you type, e.g. (310) 555-1234 with an optional ext. `toE164()` gives `+13105551234;ext=12`. Incomplete numbers get a soft warning that never blocks.

## 2 · Clean production build
- No seed patients, cases, summaries or sample faxes. The demo pack is opt-in with `?demo=1` (or `VITE_DEMO=1`); `?demo=0` turns it off.
- "Simulated" wording is shown as "Not connected" in the clean build, using the runtime display layer in `asc10/wording.ts`.
- The top bar has a "Not connected" chip. Benches show empty states.
- The scanner in the clean build creates a blank intake item for manual entry, because document reading is not connected.

## 3 · Frozen workflow
- Front desk only confirms that documents are present (portal, at-home, intake, H&P, labs, ECG). It never holds a case.
- A new **Verify medical history** step replaces Pre-op/Registration on the journey bar. It shows the Nightingale draft and source links. The nurse edits and confirms once with a PIN, and that becomes the official history. Licensed clinicians can amend it with a reason, and the amendment is audited.
- Nursing admission keeps vitals, NPO, IV and prep. It also shows the surgeon's standing pre-op list (tick with time and initials, plus one-off orders) and prefills portal answers.
- Anesthesia and Surgeon show the official history. Consent can be electronic or paper (Capture).
- Brief OP report: the OR nurse writes it and the surgeon PIN-signs it. The formal op report shows "Formal op report pending" until it is marked received. The intra-op anesthesia record is paper, scanned and uploaded.
- PACU uses the surgeon's post-op list. Only anesthesia PIN-signs the discharge from PACU.
- Prescriptions read "To be done by the operating surgeon". The next-day text and the Day-2 call are both optional.
- Every bench has a Capture/Upload button. Surgeon lists are versioned and snapshotted when a case reaches nursing, so later edits don't change cases already in nursing.

## 4 · v9.1 bug fixes
- Removed duplicate fields: ID, ride, site mark, pain and discharge signature.
- Portal answers now prefill at nursing.
- The false "Anesthesia has not signed PACU orders" warning now checks the signed order-set version.
- Aldrete is entered once (from the PACU record).
- The OR screen has one time bar.
- Every bench shows a Today pill, including Surgeon.
- Every check-in entry point opens the same slide-over.
- A deposit or account credit reduces the case balance right away.
- No hard-coded ibuprofen prescription.
- Closure counts the brief report and the formal op report separately.
- With 0 records, the Records brief gives no ASA suggestion.

## Tests
- `scripts/walk10.py` runs on the clean build: 37/37 checks passed, with screenshots in `/workspace/vityls/asc10_shots/`.
- `tsc` shows 68 errors, the same pre-existing legacy baseline as v9.1, with none new.
