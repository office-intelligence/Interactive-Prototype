import React, { useState, useEffect, useRef } from 'react';
import {
  ShieldCheck,
  Calendar,
  Clock,
  FileText,
  MessageSquare,
  Upload,
  CreditCard,
  Pill,
  User,
  Heart,
  Activity,
  CheckCircle2,
  AlertCircle,
  ChevronRight,
  ArrowRight,
  Download,
  Eye,
  Plus,
  Send,
  Lock,
  Phone,
  Mail,
  Smartphone,
  MapPin,
  Building2,
  Sparkles,
  LogOut,
  HelpCircle,
  FileCheck,
  Paperclip,
  Check,
  X,
  Printer,
  ChevronDown,
  RefreshCw,
  ExternalLink,
  Shield,
  Sliders,
  CheckSquare,
  Square,
  PenTool,
  KeyRound,
  UserCheck,
  Stethoscope,
  Info,
  Filter,
  Layers,
  Building
} from 'lucide-react';
import {
  PortalPatientProfile,
  PortalAppointment,
  PortalIntakeForm,
  PortalDocument,
  PortalMessage,
  PortalPrescription,
  PortalBill,
  PortalProvider,
  PORTAL_PROVIDERS,
  DEFAULT_PORTAL_PROFILES,
  DEFAULT_PORTAL_APPOINTMENTS,
  DEFAULT_PORTAL_FORMS,
  DEFAULT_PORTAL_DOCUMENTS,
  DEFAULT_PORTAL_MESSAGES,
  DEFAULT_PORTAL_PRESCRIPTIONS,
  DEFAULT_PORTAL_BILLS
} from '../data/portalData';
import {
  getMessagesForPatient,
  sendPatientMessage,
  subscribeToMessageUpdates
} from '../utils/portalMessageStore';
import {
  IntakeHtmlForm,
  INITIAL_INTAKE_HTML_FORMS
} from '../data/intakeHtmlForms';
import { getPrefilledIntakeHtml } from '../utils/formPrefill';

interface PatientPortalPageProps {
  onBackToOIApp: () => void;
  onNavigateLanding?: () => void;
  initialPatientId?: string;
}

export type PortalTab = 'overview' | 'appointments' | 'forms' | 'messages' | 'documents' | 'prescriptions' | 'billing';

export const PatientPortalPage: React.FC<PatientPortalPageProps> = ({
  onBackToOIApp,
  onNavigateLanding,
  initialPatientId = '114202'
}) => {
  // Authentication State
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(true);
  const [authMode, setAuthMode] = useState<'login' | 'register'>('login');
  const [loginEmail, setLoginEmail] = useState<string>('danielle.vance@example.com');
  const [loginPassword, setLoginPassword] = useState<string>('••••••••••••');
  const [registerEmail, setRegisterEmail] = useState<string>('');
  const [registerPassword, setRegisterPassword] = useState<string>('');
  const [registerConfirmPassword, setRegisterConfirmPassword] = useState<string>('');
  const [registerPhone, setRegisterPhone] = useState<string>('');

  // Active Patient Profile - Single Patient View
  const [activeProfile, setActiveProfile] = useState<PortalPatientProfile>(() => {
    return DEFAULT_PORTAL_PROFILES.find((p) => p.patientId === initialPatientId) || DEFAULT_PORTAL_PROFILES[0];
  });

  // Active Portal Navigation Tab
  const [activeTab, setActiveTab] = useState<PortalTab>('overview');

  // Interactive Portal Data State (persisted in localStorage for real-time sync with main OI app)
  const [appointments, setAppointments] = useState<PortalAppointment[]>(() => {
    const saved = localStorage.getItem(`portal_apts_${activeProfile.patientId}`);
    return saved ? JSON.parse(saved) : DEFAULT_PORTAL_APPOINTMENTS;
  });

  const [forms, setForms] = useState<PortalIntakeForm[]>(() => {
    const saved = localStorage.getItem(`portal_forms_${activeProfile.patientId}`);
    return saved ? JSON.parse(saved) : DEFAULT_PORTAL_FORMS;
  });

  // Native HTML Intake Forms state matching primary Patient Chart Page
  const [portalHtmlForms, setPortalHtmlForms] = useState<IntakeHtmlForm[]>(() => {
    const saved = localStorage.getItem(`portal_intake_html_forms_${activeProfile.patientId}`);
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error(e);
      }
    }
    return INITIAL_INTAKE_HTML_FORMS;
  });
  const [selectedIntakeFormIds, setSelectedIntakeFormIds] = useState<string[]>([]);
  const [viewingHtmlForm, setViewingHtmlForm] = useState<IntakeHtmlForm | null>(null);
  const [fillingHtmlForm, setFillingHtmlForm] = useState<IntakeHtmlForm | null>(null);
  const [fillSignature, setFillSignature] = useState<string>(
    `${activeProfile.firstName} ${activeProfile.lastName}`
  );
  const [fillAgreed, setFillAgreed] = useState<boolean>(true);

  const [documents, setDocuments] = useState<PortalDocument[]>(() => {
    const saved = localStorage.getItem(`portal_docs_${activeProfile.patientId}`);
    return saved ? JSON.parse(saved) : DEFAULT_PORTAL_DOCUMENTS;
  });

  const [messages, setMessages] = useState<PortalMessage[]>(() => {
    return getMessagesForPatient(activeProfile.patientId);
  });

  // Subscribe to real-time message changes (including replies from EHR / Patient Chart / Home Page)
  useEffect(() => {
    setMessages(getMessagesForPatient(activeProfile.patientId));
    const unsubscribe = subscribeToMessageUpdates(() => {
      setMessages(getMessagesForPatient(activeProfile.patientId));
    });
    return unsubscribe;
  }, [activeProfile.patientId]);

  const [prescriptions, setPrescriptions] = useState<PortalPrescription[]>(() => {
    const saved = localStorage.getItem(`portal_rx_${activeProfile.patientId}`);
    return saved ? JSON.parse(saved) : DEFAULT_PORTAL_PRESCRIPTIONS;
  });

  const [bills, setBills] = useState<PortalBill[]>(() => {
    const saved = localStorage.getItem(`portal_bills_${activeProfile.patientId}`);
    return saved ? JSON.parse(saved) : DEFAULT_PORTAL_BILLS;
  });

  // UI Modals & Interaction States
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [activeFormModal, setActiveFormModal] = useState<PortalIntakeForm | null>(null);
  const [isAppointmentRequestModalOpen, setIsAppointmentRequestModalOpen] = useState<boolean>(false);
  const [isUploadDocumentModalOpen, setIsUploadDocumentModalOpen] = useState<boolean>(false);
  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState<boolean>(false);
  const [viewingDocument, setViewingDocument] = useState<PortalDocument | null>(null);
  const [viewingAppointment, setViewingAppointment] = useState<PortalAppointment | null>(null);
  const [isRefillModalOpen, setIsRefillModalOpen] = useState<boolean>(false);
  const [selectedPrescriptionForRefill, setSelectedPrescriptionForRefill] = useState<PortalPrescription | null>(null);
  
  // New Prescription Request Modal state
  const [isNewPrescriptionModalOpen, setIsNewPrescriptionModalOpen] = useState<boolean>(false);
  const [newRxName, setNewRxName] = useState<string>('Celebrex 200mg Capsules');
  const [newRxDosage, setNewRxDosage] = useState<string>('1 capsule by mouth twice daily with meals');
  const [newRxReason, setNewRxReason] = useState<string>('Post-surgical pain management & anti-inflammatory');
  const [newRxPharmacy, setNewRxPharmacy] = useState<string>(
    activeProfile?.preferredPharmacy ? `${activeProfile.preferredPharmacy.name} - ${activeProfile.preferredPharmacy.address}` : 'CVS Pharmacy #9182 - 9600 Wilshire Blvd, Beverly Hills, CA'
  );
  const [newRxNotes, setNewRxNotes] = useState<string>('Requesting Dr. Sterling renewal/approval for upcoming surgery.');

  // Message compose state
  const [newMessageText, setNewMessageText] = useState<string>('');
  const [newMessageCategory, setNewMessageCategory] = useState<PortalMessage['category']>('Clinical Question');

  // Appointment Request Form state
  const [reqProvider, setReqProvider] = useState<string>('Dr. Alistair Sterling, MD');
  const [reqType, setReqType] = useState<string>('Post-Operative Follow-Up');
  const [reqDate, setReqDate] = useState<string>('2026-07-20');
  const [reqTimeOfDay, setReqTimeOfDay] = useState<string>('Morning (9:00 AM - 12:00 PM)');
  const [reqReason, setReqReason] = useState<string>('Need follow-up evaluation on surgical recovery and dressing inspection.');

  // Document Upload state
  const [uploadTitle, setUploadTitle] = useState<string>('');
  const [uploadCategory, setUploadCategory] = useState<PortalDocument['category']>('Patient Uploads');
  const [uploadFileName, setUploadFileName] = useState<string>('');
  const [uploadFileSummary, setUploadFileSummary] = useState<string>('');

  // Payment form state
  const [cardNumber, setCardNumber] = useState<string>('4007 0000 0002 9184');
  const [cardExp, setCardExp] = useState<string>('08/29');
  const [cardCvv, setCardCvv] = useState<string>('382');
  const [cardZip, setCardZip] = useState<string>('90210');
  const [isProcessingPayment, setIsProcessingPayment] = useState<boolean>(false);

  // Intake Form Wizard State
  const [formStep, setFormStep] = useState<number>(1);
  const [signatureText, setSignatureText] = useState<string>('');
  const [agreedToTerms, setAgreedToTerms] = useState<boolean>(false);
  const [medicalHistoryChecks, setMedicalHistoryChecks] = useState<Record<string, boolean>>({
    hypertension: false,
    diabetes: false,
    heartDisease: false,
    asthma: false,
    bleedingDisorder: false,
    priorAnesthesiaReaction: false,
    smoker: false,
    latexAllergy: true
  });

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  // Sync to localStorage
  useEffect(() => {
    localStorage.setItem(`portal_apts_${activeProfile.patientId}`, JSON.stringify(appointments));
    localStorage.setItem(`portal_forms_${activeProfile.patientId}`, JSON.stringify(forms));
    localStorage.setItem(`portal_intake_html_forms_${activeProfile.patientId}`, JSON.stringify(portalHtmlForms));
    localStorage.setItem(`portal_docs_${activeProfile.patientId}`, JSON.stringify(documents));
    localStorage.setItem(`portal_msgs_${activeProfile.patientId}`, JSON.stringify(messages));
    localStorage.setItem(`portal_rx_${activeProfile.patientId}`, JSON.stringify(prescriptions));
    localStorage.setItem(`portal_bills_${activeProfile.patientId}`, JSON.stringify(bills));
  }, [appointments, forms, portalHtmlForms, documents, messages, prescriptions, bills, activeProfile.patientId]);

  // Handle Login
  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    const matchedProfile = DEFAULT_PORTAL_PROFILES.find((p) => p.email.toLowerCase() === loginEmail.toLowerCase());
    if (matchedProfile) {
      setActiveProfile(matchedProfile);
      setIsAuthenticated(true);
      showToast(`Welcome back, ${matchedProfile.firstName}! Logged into MyHealth Portal.`);
    } else {
      setIsAuthenticated(true);
      showToast('Logged into MyHealth Portal securely.');
    }
  };

  // Handle Registration (Email from OI + setting up password)
  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    if (!registerEmail || !registerPassword) {
      showToast('Please enter your email and choose a password.');
      return;
    }
    if (registerPassword !== registerConfirmPassword) {
      showToast('Passwords do not match. Please verify.');
      return;
    }
    const matchedProfile = DEFAULT_PORTAL_PROFILES.find((p) => p.email.toLowerCase() === registerEmail.toLowerCase()) || DEFAULT_PORTAL_PROFILES[0];
    setActiveProfile(matchedProfile);
    setIsAuthenticated(true);
    showToast(`Account registered successfully for ${matchedProfile.firstName} ${matchedProfile.lastName}!`);
  };

  // Handle Sending a Message
  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMessageText.trim()) return;

    sendPatientMessage(activeProfile.patientId, {
      senderName: `${activeProfile.firstName} ${activeProfile.lastName}`,
      category: newMessageCategory,
      content: newMessageText.trim(),
      providerId: 'dr-sterling'
    });

    setMessages(getMessagesForPatient(activeProfile.patientId));
    setNewMessageText('');
    showToast('Message transmitted securely to Dr. Sterling care team.');
  };

  // Handle Intake Form Submission (Interactive HTML Forms)
  const handleCompleteHtmlForm = (form: IntakeHtmlForm) => {
    if (!fillSignature.trim()) {
      showToast('Please provide your legal digital signature.');
      return;
    }
    if (!fillAgreed) {
      showToast('Please check the attestation agreement box.');
      return;
    }
    const dateStr = new Date().toLocaleDateString('en-US', { month: 'short', day: '2-digit', year: 'numeric' });
    const updated = portalHtmlForms.map((f) => {
      if (f.id === form.id) {
        return {
          ...f,
          status: 'Completed in Portal' as const,
          completedDate: dateStr
        };
      }
      return f;
    });
    setPortalHtmlForms(updated);

    // Also create a newly generated completed form document in Documents
    const newDoc: PortalDocument = {
      id: `doc-signed-${Date.now()}`,
      patientId: activeProfile.patientId,
      title: `Signed ${form.title}`,
      fileName: `${form.fileName.replace(/\.html$/i, '')}_Signed.pdf`,
      category: 'Consents',
      uploadDate: 'Today',
      uploadedBy: 'Patient',
      fileSize: '1.4 MB',
      fileType: 'pdf',
      summary: `Digitally executed by ${fillSignature} on ${dateStr}. Submitted directly into Office Intelligence chart.`,
      isNew: true
    };

    setDocuments((prev) => [newDoc, ...prev]);
    setFillingHtmlForm(null);
    showToast(`Form "${form.title}" completed, digitally signed, and filed to your chart!`);
  };

  // Handle Legacy Modal Intake Form Submission
  const handleSubmitIntakeForm = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeFormModal) return;
    if (!signatureText.trim()) {
      showToast('Please type your full legal name as your digital signature.');
      return;
    }
    if (!agreedToTerms) {
      showToast('Please check the confirmation declaration box.');
      return;
    }

    const updatedForms = forms.map((f) => {
      if (f.id === activeFormModal.id) {
        return {
          ...f,
          status: 'COMPLETED' as const,
          completedDate: 'Today, ' + new Date().toLocaleDateString(),
          signedBy: signatureText
        };
      }
      return f;
    });

    setForms(updatedForms);

    // Also create a newly generated completed form document in Documents
    const newDoc: PortalDocument = {
      id: `doc-sub-${Date.now()}`,
      patientId: activeProfile.patientId,
      title: `Signed ${activeFormModal.title}`,
      fileName: `${activeFormModal.title.replace(/\s+/g, '_')}_Signed.pdf`,
      category: 'Consents',
      uploadDate: 'Today',
      uploadedBy: 'Patient',
      fileSize: '1.2 MB',
      fileType: 'pdf',
      summary: `Digitally executed by ${signatureText} on ${new Date().toLocaleDateString()}. Submitted directly into Office Intelligence chart.`,
      isNew: true
    };

    setDocuments((prev) => [newDoc, ...prev]);
    setActiveFormModal(null);
    setFormStep(1);
    setSignatureText('');
    setAgreedToTerms(false);
    showToast(`Form "${activeFormModal.title}" submitted and filed to Office Intelligence!`);
  };

  // Handle Document Upload (syncs to Document folder in Main App)
  const handleUploadDocument = (e: React.FormEvent) => {
    e.preventDefault();
    if (!uploadTitle.trim()) {
      showToast('Please enter a document title.');
      return;
    }

    const fileName = uploadFileName || `${uploadTitle.replace(/\s+/g, '_')}.pdf`;
    const newDoc: PortalDocument = {
      id: `doc-up-${Date.now()}`,
      patientId: activeProfile.patientId,
      title: uploadTitle.trim(),
      fileName: fileName,
      category: uploadCategory,
      uploadDate: 'Today',
      uploadedBy: 'Patient',
      fileSize: '2.1 MB',
      fileType: fileName.endsWith('.png') || fileName.endsWith('.jpg') ? 'png' : 'pdf',
      summary: uploadFileSummary.trim() || `Uploaded by patient via MyHealth Portal on ${new Date().toLocaleDateString()}. Transferred to Office Intelligence document vault.`,
      isNew: true
    };

    setDocuments([newDoc, ...documents]);
    setIsUploadDocumentModalOpen(false);
    setUploadTitle('');
    setUploadFileName('');
    setUploadFileSummary('');
    showToast(`Document "${newDoc.title}" uploaded! It is now accessible in the OI Chart Document Folder.`);
  };

  // Handle Requesting an Appointment
  const handleRequestAppointment = (e: React.FormEvent) => {
    e.preventDefault();
    const newApt: PortalAppointment = {
      id: `apt-req-${Date.now()}`,
      patientId: activeProfile.patientId,
      title: `${reqType} with ${reqProvider.split(',')[0]}`,
      doctor: reqProvider,
      specialty: 'Plastic & Reconstructive Surgery',
      facility: 'Aura Vanguard Surgical Pavilion',
      location: '1000 Vanguard Way, Suite 400, Beverly Hills, CA',
      date: reqDate,
      time: reqTimeOfDay,
      duration: '30-45 mins',
      status: 'REQUESTED',
      instructions: `Request submitted: "${reqReason}". Our scheduling coordinator will confirm within 2 business hours.`,
      checklist: [{ text: 'Awaiting practice confirmation and calendar block', done: false }]
    };

    setAppointments([newApt, ...appointments]);
    setIsAppointmentRequestModalOpen(false);
    showToast('Appointment request submitted! Practice scheduling team notified.');
  };

  // Handle Requesting a New Prescription
  const handleRequestNewPrescription = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newRxName.trim()) {
      showToast('Please specify the medication name.');
      return;
    }

    const newRx: PortalPrescription = {
      id: `rx-req-${Date.now()}`,
      patientId: activeProfile.patientId,
      medicationName: newRxName.trim(),
      dosage: newRxDosage.trim() || 'As directed by physician',
      instructions: newRxReason.trim() ? `Indication: ${newRxReason.trim()}. ${newRxNotes.trim()}` : 'Take as directed by Dr. Sterling.',
      prescribedBy: 'Dr. Alistair Sterling, MD (Pending Review)',
      datePrescribed: 'Requested Today',
      refillsRemaining: 1,
      pharmacy: newRxPharmacy || activeProfile.preferredPharmacy.name,
      status: 'REFILL_REQUESTED'
    };

    setPrescriptions([newRx, ...prescriptions]);
    setIsNewPrescriptionModalOpen(false);
    showToast(`New prescription request for "${newRx.medicationName}" submitted to Dr. Sterling!`);
  };

  // Handle Payment
  const handleProcessPayment = (e: React.FormEvent) => {
    e.preventDefault();
    setIsProcessingPayment(true);
    setTimeout(() => {
      setIsProcessingPayment(false);
      const updatedBills = bills.map((b) => ({
        ...b,
        patientBalance: 0,
        status: 'PAID' as const,
        receiptId: `REC-${Math.floor(100000 + Math.random() * 900000)}`
      }));
      setBills(updatedBills);
      setIsPaymentModalOpen(false);
      showToast('Payment of $150.00 processed successfully! Official receipt generated.');
    }, 1200);
  };

  // Handle Prescription Refill
  const handleConfirmRefill = () => {
    if (!selectedPrescriptionForRefill) return;
    const updatedRx = prescriptions.map((r) => {
      if (r.id === selectedPrescriptionForRefill.id) {
        return {
          ...r,
          status: 'REFILL_REQUESTED' as const
        };
      }
      return r;
    });
    setPrescriptions(updatedRx);
    setIsRefillModalOpen(false);
    showToast(`Refill request for ${selectedPrescriptionForRefill.medicationName} transmitted to Dr. Sterling!`);
  };

  // Active Provider & Practice Filter Selector State
  const [selectedProviderId, setSelectedProviderId] = useState<string>('all');
  const [isProviderDropdownOpen, setIsProviderDropdownOpen] = useState<boolean>(false);
  const providerDropdownRef = useRef<HTMLDivElement>(null);

  // Close provider dropdown when clicking outside or pressing Escape
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (providerDropdownRef.current && !providerDropdownRef.current.contains(event.target as Node)) {
        setIsProviderDropdownOpen(false);
      }
    };
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        setIsProviderDropdownOpen(false);
      }
    };
    if (isProviderDropdownOpen) {
      document.addEventListener('mousedown', handleClickOutside);
      document.addEventListener('keydown', handleKeyDown);
    }
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, [isProviderDropdownOpen]);

  const selectedProvider: PortalProvider | null =
    selectedProviderId === 'all'
      ? null
      : PORTAL_PROVIDERS.find((p) => p.id === selectedProviderId) || null;

  // Filtered Collections based on active provider selection
  const filteredAppointments = appointments.filter((a) => {
    if (selectedProviderId === 'all') return true;
    if (a.providerId === selectedProviderId) return true;
    if (selectedProvider && a.doctor && a.doctor.toLowerCase().includes(selectedProvider.name.replace('Dr. ', '').toLowerCase())) return true;
    return false;
  });

  const filteredForms = forms.filter((f) => {
    if (selectedProviderId === 'all') return true;
    if (f.providerId === selectedProviderId) return true;
    if (selectedProvider && f.doctor && f.doctor.toLowerCase().includes(selectedProvider.name.replace('Dr. ', '').toLowerCase())) return true;
    return false;
  });

  const filteredPortalHtmlForms = portalHtmlForms.filter((f) => {
    if (selectedProviderId === 'all') return true;
    if (f.providerId === selectedProviderId) return true;
    if (selectedProvider && f.doctor && f.doctor.toLowerCase().includes(selectedProvider.name.replace('Dr. ', '').toLowerCase())) return true;
    return false;
  });

  const filteredDocuments = documents.filter((d) => {
    if (selectedProviderId === 'all') return true;
    if (d.providerId === selectedProviderId) return true;
    if (selectedProvider && d.doctor && d.doctor.toLowerCase().includes(selectedProvider.name.replace('Dr. ', '').toLowerCase())) return true;
    return false;
  });

  const filteredMessages = messages.filter((m) => {
    if (selectedProviderId === 'all') return true;
    if (m.providerId === selectedProviderId) return true;
    if (selectedProvider && m.senderName && m.senderName.toLowerCase().includes(selectedProvider.name.replace('Dr. ', '').toLowerCase())) return true;
    return false;
  });

  const filteredPrescriptions = prescriptions.filter((p) => {
    if (selectedProviderId === 'all') return true;
    if (p.providerId === selectedProviderId) return true;
    if (selectedProvider && p.prescribedBy && p.prescribedBy.toLowerCase().includes(selectedProvider.name.replace('Dr. ', '').toLowerCase())) return true;
    return false;
  });

  const filteredBills = bills.filter((b) => {
    if (selectedProviderId === 'all') return true;
    if (b.providerId === selectedProviderId) return true;
    if (selectedProvider && b.doctor && b.doctor.toLowerCase().includes(selectedProvider.name.replace('Dr. ', '').toLowerCase())) return true;
    return false;
  });

  const pendingHtmlFormsCount = filteredPortalHtmlForms.filter((f) => f.status !== 'Completed in Portal').length;
  const pendingFormsCount = filteredForms.filter((f) => f.status !== 'COMPLETED').length;
  const unreadMessagesCount = filteredMessages.filter((m) => m.sender === 'provider' && !m.read).length;
  const nextAppointment = filteredAppointments.find((a) => a.status === 'UPCOMING') || appointments.find((a) => a.status === 'UPCOMING');
  const outstandingBalance = filteredBills.reduce((acc, b) => (b.status === 'UNPAID' ? acc + b.patientBalance : acc), 0);

  // =========================================================================
  // VIEW: AUTHENTICATION / LOGIN / REGISTER
  // =========================================================================
  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-slate-900 text-slate-100 flex flex-col justify-between selection:bg-teal-500 selection:text-slate-950 font-sans">
        
        {/* Top Navbar */}
        <header className="bg-slate-950/80 border-b border-slate-800 px-6 py-4 flex items-center justify-between backdrop-blur-md">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-teal-500 to-cyan-400 flex items-center justify-center text-slate-950 font-black shadow-lg shadow-teal-500/20">
              <Heart className="w-5 h-5 fill-slate-950" />
            </div>
            <div>
              <div className="text-sm font-bold text-white tracking-tight flex items-center gap-2">
                <span>MyHealth Patient Portal</span>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-teal-500/20 text-teal-300 font-mono border border-teal-500/30">HIPAA Certified</span>
              </div>
              <div className="text-xs text-slate-400">Aura Vanguard Surgical &amp; Aesthetic Pavilion</div>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={onBackToOIApp}
              className="px-3.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <Building2 className="w-3.5 h-3.5 text-teal-400" />
              <span>Back to Clinic Staff OS</span>
            </button>
          </div>
        </header>

        {/* Auth Body */}
        <div className="max-w-4xl mx-auto px-4 py-12 flex-1 flex flex-col justify-center">
          <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-center">
            
            {/* Left Info Column */}
            <div className="md:col-span-6 space-y-6">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-teal-950/80 text-teal-300 border border-teal-500/30 text-xs font-semibold">
                <ShieldCheck className="w-4 h-4 text-teal-400" />
                <span>Encrypted 256-Bit Patient Health Vault</span>
              </div>

              <h1 className="text-3xl sm:text-4xl font-serif font-bold text-white leading-tight">
                Seamless access to your surgical care, intake forms &amp; medical records.
              </h1>

              <p className="text-sm text-slate-300 leading-relaxed">
                Welcome to the official patient portal for Aura Vanguard Surgical Pavilion. Complete your pre-operative questionnaires, message Dr. Sterling and your care team, review diagnostic labs, and manage upcoming surgical appointments.
              </p>

              {/* Quick Fictitious Patient Review Switcher */}
              <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800 space-y-3">
                <div className="text-xs font-bold uppercase tracking-wider text-teal-400 flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Instant Demo Review Accounts</span>
                </div>
                <div className="text-xs text-slate-400">
                  Select a sample patient to test the portal with preloaded appointments, intake forms, lab documents, and messages:
                </div>
                <div className="grid grid-cols-1 gap-2">
                  {DEFAULT_PORTAL_PROFILES.map((p) => (
                    <button
                      key={p.id}
                      onClick={() => {
                        setActiveProfile(p);
                        setLoginEmail(p.email);
                        setIsAuthenticated(true);
                        showToast(`Logged in as demo patient ${p.firstName} ${p.lastName}`);
                      }}
                      className="p-2.5 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-700 text-left transition-all flex items-center justify-between group cursor-pointer"
                    >
                      <div>
                        <div className="text-xs font-bold text-white group-hover:text-teal-300">
                          {p.firstName} {p.lastName} <span className="text-[10px] text-slate-400 font-mono">({p.mrn})</span>
                        </div>
                        <div className="text-[11px] text-slate-400">
                          {p.email} • {p.primarySurgeon}
                        </div>
                      </div>
                      <ChevronRight className="w-4 h-4 text-slate-500 group-hover:text-teal-400 group-hover:translate-x-0.5 transition-all" />
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Right Form Card */}
            <div className="md:col-span-6 bg-slate-950 border border-slate-800 rounded-2xl p-6 sm:p-8 shadow-2xl relative">
              
              {/* Tab Selector: Login vs Register */}
              <div className="flex rounded-lg bg-slate-900 p-1 border border-slate-800 mb-6">
                <button
                  onClick={() => setAuthMode('login')}
                  className={`flex-1 py-2 text-xs font-bold rounded-md transition-all ${
                    authMode === 'login' ? 'bg-teal-500 text-slate-950 shadow-md' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Log In
                </button>
                <button
                  onClick={() => setAuthMode('register')}
                  className={`flex-1 py-2 text-xs font-bold rounded-md transition-all ${
                    authMode === 'register' ? 'bg-teal-500 text-slate-950 shadow-md' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Register Portal Access
                </button>
              </div>

              {authMode === 'login' ? (
                <form onSubmit={handleLogin} className="space-y-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1.5">Email Address</label>
                    <div className="relative">
                      <Mail className="w-4 h-4 text-slate-500 absolute left-3 top-3" />
                      <input
                        type="email"
                        value={loginEmail}
                        onChange={(e) => setLoginEmail(e.target.value)}
                        placeholder="you@example.com"
                        className="w-full pl-9 pr-3 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-teal-400"
                        required
                      />
                    </div>
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-1.5">
                      <label className="text-xs font-semibold text-slate-300">Password</label>
                      <button
                        type="button"
                        onClick={() => showToast('Password reset link sent to your registered email.')}
                        className="text-[11px] text-teal-400 hover:underline"
                      >
                        Forgot password?
                      </button>
                    </div>
                    <div className="relative">
                      <Lock className="w-4 h-4 text-slate-500 absolute left-3 top-3" />
                      <input
                        type="password"
                        value={loginPassword}
                        onChange={(e) => setLoginPassword(e.target.value)}
                        placeholder="••••••••••••"
                        className="w-full pl-9 pr-3 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-teal-400"
                        required
                      />
                    </div>
                  </div>

                  <div className="pt-2">
                    <button
                      type="submit"
                      className="w-full py-3 bg-gradient-to-r from-teal-500 via-cyan-500 to-emerald-600 hover:from-teal-400 hover:to-emerald-500 text-slate-950 font-bold text-xs rounded-xl shadow-lg shadow-teal-500/20 transition-all flex items-center justify-center gap-2 cursor-pointer"
                    >
                      <KeyRound className="w-4 h-4" />
                      <span>Sign In to MyHealth Portal</span>
                    </button>
                  </div>

                  <div className="text-center pt-2">
                    <span className="text-xs text-slate-400">First time using the portal? </span>
                    <button
                      type="button"
                      onClick={() => setAuthMode('register')}
                      className="text-xs text-teal-400 font-bold hover:underline"
                    >
                      Set up your password
                    </button>
                  </div>
                </form>
              ) : (
                <form onSubmit={handleRegister} className="space-y-3.5">
                  <div className="bg-emerald-950/40 border border-emerald-500/30 rounded-lg p-3 text-xs text-emerald-200">
                    <span className="font-bold">Note for Patients:</span> Use the email address you gave to the clinic when registering. You only need to set up a password to activate your portal.
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">Registered Email Address</label>
                    <input
                      type="email"
                      value={registerEmail}
                      onChange={(e) => setRegisterEmail(e.target.value)}
                      placeholder="e.g. danielle.vance@example.com"
                      className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-xs text-white placeholder-slate-500 focus:outline-none focus:border-teal-400"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">Mobile Phone Number</label>
                    <input
                      type="tel"
                      value={registerPhone}
                      onChange={(e) => setRegisterPhone(e.target.value)}
                      placeholder="(310) 555-0199"
                      className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-xs text-white placeholder-slate-500 focus:outline-none focus:border-teal-400"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="block text-xs font-semibold text-slate-300 mb-1">Create Password</label>
                      <input
                        type="password"
                        value={registerPassword}
                        onChange={(e) => setRegisterPassword(e.target.value)}
                        placeholder="••••••••"
                        className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-xs text-white placeholder-slate-500 focus:outline-none focus:border-teal-400"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-slate-300 mb-1">Confirm Password</label>
                      <input
                        type="password"
                        value={registerConfirmPassword}
                        onChange={(e) => setRegisterConfirmPassword(e.target.value)}
                        placeholder="••••••••"
                        className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-xs text-white placeholder-slate-500 focus:outline-none focus:border-teal-400"
                        required
                      />
                    </div>
                  </div>

                  <div className="pt-2">
                    <button
                      type="submit"
                      className="w-full py-2.5 bg-teal-500 hover:bg-teal-400 text-slate-950 font-bold text-xs rounded-lg shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer"
                    >
                      <UserCheck className="w-4 h-4" />
                      <span>Activate &amp; Enter Portal</span>
                    </button>
                  </div>
                </form>
              )}
            </div>

          </div>
        </div>

        {/* Footer */}
        <footer className="bg-slate-950 border-t border-slate-800 py-4 px-6 text-center text-xs text-slate-500">
          © 2026 Aura Vanguard Surgical &amp; Aesthetic Pavilion. Connected to Office Intelligence Clinical OS. HIPAA &amp; HITECH Compliant.
        </footer>

      </div>
    );
  }

  // =========================================================================
  // VIEW: AUTHENTICATED PATIENT PORTAL DASHBOARD
  // =========================================================================
  return (
    <div className="min-h-screen bg-slate-100 text-slate-900 font-sans antialiased flex flex-col selection:bg-teal-500/20 selection:text-teal-900">
      
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-4 right-4 z-50 bg-slate-900 text-white text-xs font-semibold px-4 py-3 rounded-2xl shadow-2xl border border-slate-700 flex items-center gap-2.5 animate-in slide-in-from-top duration-300 max-w-md">
          <Sparkles className="w-4 h-4 text-teal-300 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Top Main Healthcare Header Bar */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-40 shadow-xs">
        <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8">
          
          <div className="flex items-center justify-between h-16 gap-2 sm:gap-4">
            
            {/* Left: Branding & Patient Info */}
            <div className="flex items-center gap-2 sm:gap-3.5 min-w-0">
              <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-xl bg-gradient-to-tr from-teal-600 to-cyan-500 flex items-center justify-center text-white font-black shadow-md shadow-teal-600/20 shrink-0">
                <Heart className="w-4 h-4 sm:w-5 sm:h-5 fill-white" />
              </div>

              <div className="min-w-0">
                <div className="flex items-center gap-1.5 sm:gap-2">
                  <span className="font-bold text-xs sm:text-sm text-slate-900 tracking-tight truncate">MyHealth Portal</span>
                  <span className="hidden sm:inline text-[10px] bg-emerald-100 text-emerald-800 font-bold px-2 py-0.2 rounded-full border border-emerald-300">
                    Active Patient
                  </span>
                </div>
                <div className="text-[11px] sm:text-xs text-slate-500 flex items-center gap-1.5 truncate">
                  <span className="truncate">Aura Vanguard Pavilion</span>
                  <span className="hidden sm:inline">•</span>
                  <span className="hidden sm:inline font-mono text-slate-700 font-medium">MRN: {activeProfile.mrn}</span>
                </div>
              </div>
            </div>

            {/* Center: Global Provider & Practice Filter Dropdown */}
            <div className="flex items-center gap-1.5 sm:gap-2" ref={providerDropdownRef}>
              <div className="relative">
                <button
                  type="button"
                  id="portal-provider-filter-button"
                  onClick={() => setIsProviderDropdownOpen(!isProviderDropdownOpen)}
                  className={`flex items-center gap-1.5 sm:gap-2 px-2 sm:px-3 py-1.5 rounded-xl border text-xs font-semibold transition-all cursor-pointer shadow-2xs ${
                    selectedProviderId !== 'all'
                      ? 'bg-teal-50 border-teal-300 text-teal-900 ring-2 ring-teal-500/20'
                      : 'bg-slate-50 hover:bg-slate-100 border-slate-200 text-slate-800'
                  }`}
                  title="Filter all portal information by practice or physician"
                >
                  <Building2 className={`w-3.5 h-3.5 shrink-0 ${selectedProviderId !== 'all' ? 'text-teal-700' : 'text-slate-500'}`} />
                  <div className="text-left max-w-[100px] sm:max-w-[210px]">
                    <span className="text-[8px] sm:text-[9px] text-slate-500 block uppercase font-mono leading-none">Practice Filter</span>
                    <span className="font-bold text-slate-900 truncate block text-[10.5px] sm:text-[11px]">
                      {selectedProvider ? selectedProvider.shortName : 'All Practices (4)'}
                    </span>
                  </div>
                  <ChevronDown className={`w-3.5 h-3.5 text-slate-400 ml-0.5 shrink-0 transition-transform duration-200 ${isProviderDropdownOpen ? 'rotate-180' : ''}`} />
                </button>

                {isProviderDropdownOpen && (
                  <div className="absolute right-0 sm:right-auto sm:left-0 mt-2 w-76 sm:w-88 max-w-[calc(100vw-1.5rem)] bg-white rounded-2xl border border-slate-200 shadow-2xl z-50 p-2 animate-in fade-in zoom-in-95 duration-150">
                    <div className="px-3 py-2 border-b border-slate-100 mb-1 flex items-center justify-between">
                      <div>
                        <span className="text-xs font-bold text-slate-900 block">Choose Attending Practice</span>
                        <span className="text-[10.5px] text-slate-500">Filter portal data &amp; records by provider</span>
                      </div>
                      <span className="text-[10px] bg-slate-100 text-slate-600 px-2 py-0.5 rounded-md font-mono font-bold">
                        4 Practices
                      </span>
                    </div>

                    <button
                      type="button"
                      onClick={() => {
                        setSelectedProviderId('all');
                        setIsProviderDropdownOpen(false);
                        showToast('Displaying records from all connected practices & providers.');
                      }}
                      className={`w-full text-left px-3 py-2 rounded-xl text-xs flex items-center justify-between transition-colors cursor-pointer ${
                        selectedProviderId === 'all' ? 'bg-teal-50 text-teal-900 font-bold border border-teal-200/70' : 'hover:bg-slate-50 text-slate-700'
                      }`}
                    >
                      <div className="flex items-center gap-2.5">
                        <div className="w-8 h-8 rounded-lg bg-teal-800 text-white flex items-center justify-center font-bold text-xs shadow-2xs">
                          <Layers className="w-4 h-4" />
                        </div>
                        <div>
                          <div className="font-bold text-slate-900">All Connected Practices</div>
                          <div className="text-[10.5px] text-slate-500">Multi-Disciplinary Combined View</div>
                        </div>
                      </div>
                      {selectedProviderId === 'all' && <Check className="w-4 h-4 text-teal-600 shrink-0" />}
                    </button>

                    <div className="my-1 border-t border-slate-100"></div>

                    <div className="space-y-1">
                      {PORTAL_PROVIDERS.map((provider) => (
                        <button
                          key={provider.id}
                          type="button"
                          onClick={() => {
                            setSelectedProviderId(provider.id);
                            setIsProviderDropdownOpen(false);
                            showToast(`Filtered portal to ${provider.name} (${provider.shortName})`);
                          }}
                          className={`w-full text-left px-3 py-2 rounded-xl text-xs flex items-center justify-between transition-colors cursor-pointer ${
                            selectedProviderId === provider.id ? 'bg-teal-50 text-teal-900 font-bold border border-teal-200/70' : 'hover:bg-slate-50 text-slate-700'
                          }`}
                        >
                          <div className="flex items-center gap-2.5 min-w-0">
                            <div className={`w-8 h-8 rounded-lg ${provider.avatarBg} flex items-center justify-center font-bold text-xs shrink-0 shadow-2xs`}>
                              {provider.initials}
                            </div>
                            <div className="truncate min-w-0">
                              <div className="font-bold truncate text-slate-900">{provider.name}</div>
                              <div className="text-[10.5px] text-slate-500 truncate">{provider.practiceShortName || provider.practiceName}</div>
                            </div>
                          </div>
                          {selectedProviderId === provider.id && <Check className="w-4 h-4 text-teal-600 shrink-0 ml-2" />}
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Right: Patient User Info & Logout */}
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-2.5 bg-slate-50 border border-slate-200 px-3 py-1.5 rounded-xl">
                <div className="w-8 h-8 rounded-full bg-teal-100 text-teal-800 font-bold text-xs flex items-center justify-center border border-teal-300">
                  {activeProfile.firstName[0]}{activeProfile.lastName[0]}
                </div>
                <div className="text-left">
                  <div className="text-xs font-bold text-slate-800 leading-tight">
                    {activeProfile.firstName} {activeProfile.lastName}
                  </div>
                  <div className="text-[10px] text-slate-500 font-mono">DOB: {activeProfile.dob}</div>
                </div>
              </div>

              <button
                onClick={() => {
                  setIsAuthenticated(false);
                  showToast('Logged out of patient portal.');
                }}
                className="p-2 text-slate-400 hover:text-rose-600 rounded-xl hover:bg-rose-50 transition-colors cursor-pointer border border-transparent hover:border-rose-200 flex items-center gap-1.5 text-xs font-semibold"
                title="Sign out of portal"
              >
                <LogOut className="w-4 h-4" />
                <span className="hidden sm:inline">Sign Out</span>
              </button>
            </div>

          </div>

          {/* Navigation Bar Tabs */}
          <div className="flex items-center gap-1 overflow-x-auto border-t border-slate-200 py-1.5 scrollbar-none snap-x">
            <button
              onClick={() => setActiveTab('overview')}
              className={`px-3 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 whitespace-nowrap cursor-pointer shrink-0 snap-start ${
                activeTab === 'overview'
                  ? 'bg-teal-50 text-teal-800 border border-teal-200 font-black'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <Activity className="w-4 h-4 text-teal-600" />
              <span>Dashboard</span>
            </button>

            <button
              onClick={() => setActiveTab('appointments')}
              className={`px-3 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 whitespace-nowrap cursor-pointer shrink-0 snap-start ${
                activeTab === 'appointments'
                  ? 'bg-teal-50 text-teal-800 border border-teal-200 font-black'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <Calendar className="w-4 h-4 text-emerald-600" />
              <span>Appointments</span>
              <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-emerald-100 text-emerald-800 font-mono font-bold">
                {filteredAppointments.length}
              </span>
            </button>

            <button
              onClick={() => setActiveTab('forms')}
              className={`px-3 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 whitespace-nowrap cursor-pointer shrink-0 snap-start ${
                activeTab === 'forms'
                  ? 'bg-teal-50 text-teal-800 border border-teal-200 font-black'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <FileText className="w-4 h-4 text-amber-600" />
              <span>Intake Forms</span>
              {pendingFormsCount > 0 && (
                <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-amber-200 text-amber-900 font-bold">
                  {pendingFormsCount} Due
                </span>
              )}
            </button>

            <button
              onClick={() => setActiveTab('messages')}
              className={`px-3 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 whitespace-nowrap cursor-pointer shrink-0 snap-start ${
                activeTab === 'messages'
                  ? 'bg-teal-50 text-teal-800 border border-teal-200 font-black'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <MessageSquare className="w-4 h-4 text-purple-600" />
              <span>Messages &amp; Care Team</span>
              <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-purple-100 text-purple-800 font-mono font-bold">
                {filteredMessages.length}
              </span>
            </button>

            <button
              onClick={() => setActiveTab('documents')}
              className={`px-3 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 whitespace-nowrap cursor-pointer shrink-0 snap-start ${
                activeTab === 'documents'
                  ? 'bg-teal-50 text-teal-800 border border-teal-200 font-black'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <Upload className="w-4 h-4 text-emerald-600" />
              <span>Documents &amp; Uploads</span>
              <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-emerald-100 text-emerald-800 font-mono font-bold">
                {filteredDocuments.length}
              </span>
            </button>

            <button
              onClick={() => setActiveTab('prescriptions')}
              className={`px-3 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 whitespace-nowrap cursor-pointer shrink-0 snap-start ${
                activeTab === 'prescriptions'
                  ? 'bg-teal-50 text-teal-800 border border-teal-200 font-black'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <Pill className="w-4 h-4 text-rose-600" />
              <span>Prescriptions</span>
              <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-rose-100 text-rose-800 font-mono font-bold">
                {filteredPrescriptions.length}
              </span>
            </button>

            <button
              onClick={() => setActiveTab('billing')}
              className={`px-3 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 whitespace-nowrap cursor-pointer shrink-0 snap-start ${
                activeTab === 'billing'
                  ? 'bg-teal-50 text-teal-800 border border-teal-200 font-black'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <CreditCard className="w-4 h-4 text-indigo-600" />
              <span>Billing &amp; Payments</span>
              {outstandingBalance > 0 && (
                <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-rose-100 text-rose-800 font-bold">
                  ${outstandingBalance.toFixed(0)}
                </span>
              )}
            </button>
          </div>

        </div>
      </header>

      {/* Main Page Body */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-3 sm:p-6 lg:p-8 space-y-6 pb-24 sm:pb-8">
        
        {/* ========================================================================= */}
        {/* TAB 1: OVERVIEW & DASHBOARD */}
        {/* ========================================================================= */}
        {activeTab === 'overview' && (
          <div className="space-y-6">
            
            {/* Welcome Banner */}
            <div className="bg-gradient-to-r from-[#1c2d3d] via-[#243b53] to-[#2f495e] rounded-2xl p-6 text-white shadow-lg relative overflow-hidden">
              <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
                <div className="space-y-2">
                  <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-teal-500/20 text-teal-300 text-xs font-semibold border border-teal-500/30">
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>Surgical Care Portal Active</span>
                  </div>
                  <h1 className="text-2xl sm:text-3xl font-serif font-bold text-white tracking-tight">
                    Hello, {activeProfile.firstName}!
                  </h1>
                  <p className="text-xs sm:text-sm text-slate-300 max-w-2xl leading-relaxed">
                    You have <span className="text-teal-300 font-bold">{pendingFormsCount} pending intake questionnaires</span> to complete before your scheduled procedure with <span className="text-white font-bold">{activeProfile.primarySurgeon}</span>.
                  </p>
                </div>

                <div className="flex flex-wrap gap-2.5">
                  <button
                    onClick={() => setIsAppointmentRequestModalOpen(true)}
                    className="px-4 py-2.5 bg-teal-500 hover:bg-teal-400 text-slate-950 font-bold text-xs rounded-xl shadow-md transition-all flex items-center gap-1.5 cursor-pointer"
                  >
                    <Plus className="w-4 h-4" />
                    <span>Request Appointment</span>
                  </button>

                  <button
                    onClick={() => setActiveTab('forms')}
                    className="px-4 py-2.5 bg-white/10 hover:bg-white/20 text-white font-bold text-xs rounded-xl border border-white/20 transition-all flex items-center gap-1.5 cursor-pointer backdrop-blur-sm"
                  >
                    <FileText className="w-4 h-4 text-teal-300" />
                    <span>Complete Intake Forms</span>
                  </button>
                </div>
              </div>
            </div>

            {/* ========================================================================= */}
            {/* PRACTICE & ATTENDING PROVIDER SELECTOR */}
            {/* ========================================================================= */}
            <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3.5">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-xl bg-teal-50 text-teal-700 flex items-center justify-center border border-teal-200/60 shadow-2xs">
                    <Building2 className="w-4 h-4" />
                  </div>
                  <div>
                    <h2 className="text-sm font-bold text-slate-900">Choose Practice &amp; Attending Specialist</h2>
                    <p className="text-[11px] text-slate-500">Filter your health portal to view records, visits, and care from a specific physician</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  {selectedProvider ? (
                    <span className="text-xs text-teal-900 bg-teal-50 border border-teal-200/80 px-3 py-1 rounded-full font-bold flex items-center gap-1.5 shadow-2xs">
                      <Filter className="w-3 h-3 text-teal-600" />
                      <span>Filtered: {selectedProvider.shortName}</span>
                    </span>
                  ) : (
                    <span className="text-xs text-slate-500 font-medium bg-slate-50 border border-slate-200/80 px-3 py-1 rounded-full">
                      Showing All 4 Connected Practices
                    </span>
                  )}
                  {selectedProviderId !== 'all' && (
                    <button
                      type="button"
                      onClick={() => {
                        setSelectedProviderId('all');
                        showToast('Showing records from all practices & providers.');
                      }}
                      className="text-xs font-bold text-slate-600 hover:text-teal-800 cursor-pointer bg-slate-100 hover:bg-slate-200 px-3 py-1 rounded-full transition-colors flex items-center gap-1"
                    >
                      <X className="w-3 h-3" />
                      <span>Show All</span>
                    </button>
                  )}
                </div>
              </div>

              {/* Provider Selection Grid / Cards */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
                {/* All Providers Option */}
                <button
                  type="button"
                  onClick={() => {
                    setSelectedProviderId('all');
                    showToast('Displaying comprehensive multi-disciplinary records.');
                  }}
                  className={`p-3.5 rounded-xl border text-left transition-all cursor-pointer flex flex-col justify-between gap-3 ${
                    selectedProviderId === 'all'
                      ? 'bg-[#1c2d3d] text-white border-slate-700 shadow-md ring-2 ring-teal-500/40'
                      : 'bg-slate-50/80 hover:bg-slate-100 text-slate-800 border-slate-200 hover:border-slate-300'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className={`w-8 h-8 rounded-lg flex items-center justify-center font-bold text-xs shadow-2xs ${
                      selectedProviderId === 'all' ? 'bg-teal-700 text-white' : 'bg-slate-200 text-slate-700'
                    }`}>
                      <Layers className="w-4 h-4" />
                    </div>
                    {selectedProviderId === 'all' ? (
                      <span className="w-2.5 h-2.5 rounded-full bg-teal-400"></span>
                    ) : (
                      <span className="text-[10px] text-slate-400 font-mono">4 Clinics</span>
                    )}
                  </div>
                  <div>
                    <div className="font-bold text-xs leading-tight">All Connected Practices</div>
                    <div className={`text-[10.5px] mt-0.5 ${selectedProviderId === 'all' ? 'text-teal-200' : 'text-slate-500'}`}>
                      Multi-Disciplinary Record
                    </div>
                  </div>
                </button>

                {/* Individual Providers */}
                {PORTAL_PROVIDERS.map((provider) => {
                  const isSelected = selectedProviderId === provider.id;
                  return (
                    <button
                      key={provider.id}
                      type="button"
                      onClick={() => {
                        setSelectedProviderId(provider.id);
                        showToast(`Filtered portal to ${provider.name} (${provider.practiceName})`);
                      }}
                      className={`p-3.5 rounded-xl border text-left transition-all cursor-pointer flex flex-col justify-between gap-3 ${
                        isSelected
                          ? 'bg-[#1c2d3d] text-white border-slate-700 shadow-md ring-2 ring-teal-500/40'
                          : 'bg-slate-50/80 hover:bg-slate-100 text-slate-800 border-slate-200 hover:border-slate-300'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <div className={`w-8 h-8 rounded-lg flex items-center justify-center font-bold text-xs shadow-2xs ${
                          isSelected ? 'bg-teal-600 text-white' : `${provider.avatarBg}`
                        }`}>
                          {provider.initials}
                        </div>
                        {isSelected && (
                          <span className="w-2.5 h-2.5 rounded-full bg-teal-400"></span>
                        )}
                      </div>
                      <div>
                        <div className="font-bold text-xs truncate leading-tight">{provider.name}</div>
                        <div className={`text-[10.5px] truncate mt-0.5 ${isSelected ? 'text-teal-200' : 'text-slate-500'}`}>
                          {provider.specialty}
                        </div>
                      </div>
                    </button>
                  );
                })}
              </div>

              {/* If a provider is chosen: Display Provider & Practice Detail Card */}
              {selectedProvider ? (
                <div className="p-4 bg-teal-50/80 rounded-xl border border-teal-200/90 flex flex-col lg:flex-row lg:items-center justify-between gap-4 animate-in fade-in duration-150">
                  <div className="flex items-start gap-3.5">
                    <div className={`w-12 h-12 rounded-xl ${selectedProvider.avatarBg} font-bold text-sm flex items-center justify-center shrink-0 shadow-sm border border-white/20`}>
                      {selectedProvider.initials}
                    </div>
                    <div className="space-y-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <h3 className="font-bold text-slate-900 text-sm">{selectedProvider.name}</h3>
                        <span className="text-[10px] px-2 py-0.5 rounded-full bg-teal-200/80 text-teal-900 font-bold">
                          {selectedProvider.specialty}
                        </span>
                        <span className="text-[10.5px] text-slate-500 font-medium">
                          {selectedProvider.title}
                        </span>
                      </div>
                      <div className="text-xs font-semibold text-slate-800">{selectedProvider.practiceName}</div>
                      <div className="text-[11px] text-slate-600 flex items-center gap-3.5 flex-wrap pt-0.5">
                        <span className="flex items-center gap-1">
                          <MapPin className="w-3 h-3 text-teal-700 shrink-0" />
                          <span>{selectedProvider.location}</span>
                        </span>
                        <a 
                          href={`tel:${selectedProvider.phone.replace(/[^0-9]/g, '')}`} 
                          className="flex items-center gap-1 text-teal-800 font-semibold hover:underline"
                        >
                          <Phone className="w-3 h-3 text-teal-700 shrink-0" />
                          <span>{selectedProvider.phone}</span>
                        </a>
                        <a 
                          href={`mailto:${selectedProvider.email}`} 
                          className="flex items-center gap-1 text-teal-800 font-semibold hover:underline"
                        >
                          <Mail className="w-3 h-3 text-teal-700 shrink-0" />
                          <span>{selectedProvider.email}</span>
                        </a>
                      </div>
                      <p className="text-[11px] text-slate-600 italic pt-0.5">
                        "{selectedProvider.bio}"
                      </p>
                    </div>
                  </div>

                  <div className="flex flex-wrap items-center gap-2 shrink-0 pt-2 lg:pt-0 border-t lg:border-t-0 border-teal-200/60">
                    <button
                      type="button"
                      onClick={() => {
                        setActiveTab('messages');
                        showToast(`Initiating secure message to ${selectedProvider.name}`);
                      }}
                      className="px-3 py-1.5 bg-teal-700 hover:bg-teal-800 text-white font-bold text-xs rounded-xl shadow-2xs transition-colors cursor-pointer flex items-center gap-1.5"
                    >
                      <MessageSquare className="w-3.5 h-3.5" />
                      <span>Message</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setIsAppointmentRequestModalOpen(true);
                      }}
                      className="px-3 py-1.5 bg-white hover:bg-slate-100 text-slate-800 font-bold text-xs rounded-xl border border-slate-300 transition-colors shadow-2xs cursor-pointer flex items-center gap-1.5"
                    >
                      <Calendar className="w-3.5 h-3.5 text-teal-700" />
                      <span>Request Visit</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setActiveTab('forms');
                      }}
                      className="px-3 py-1.5 bg-white hover:bg-slate-100 text-slate-800 font-bold text-xs rounded-xl border border-slate-300 transition-colors shadow-2xs cursor-pointer flex items-center gap-1.5"
                    >
                      <FileText className="w-3.5 h-3.5 text-teal-700" />
                      <span>Forms</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setSelectedProviderId('all');
                        showToast('Reset to all connected providers.');
                      }}
                      className="px-3 py-1.5 bg-white hover:bg-slate-100 text-slate-600 font-bold text-xs rounded-xl border border-slate-300 transition-colors shadow-2xs cursor-pointer flex items-center gap-1"
                      title="Clear filter and show all practices"
                    >
                      <X className="w-3.5 h-3.5 text-slate-500" />
                      <span>Clear</span>
                    </button>
                  </div>
                </div>
              ) : (
                <div className="p-3 bg-slate-50 rounded-xl border border-slate-200/70 flex flex-wrap items-center justify-between gap-2 text-xs text-slate-600">
                  <div className="flex items-center gap-2">
                    <span className="inline-block w-2 h-2 rounded-full bg-teal-500"></span>
                    <span className="font-semibold text-slate-800">Connected Care Network:</span>
                    <span>All records from Aura Vanguard Surgical, Facial Aesthetics, Anesthesia, and Dermatology are combined.</span>
                  </div>
                  <span className="text-[11px] text-slate-500 font-mono">Select any doctor card to focus your portal view</span>
                </div>
              )}
            </div>

            {/* Next Upcoming Appointment Highlight Card */}
            {nextAppointment && (
              <div className="bg-white rounded-2xl border border-slate-200/90 p-5 shadow-xs">
                <div className="flex items-center justify-between border-b border-slate-100 pb-3 mb-4">
                  <div className="flex items-center gap-2">
                    <div className="p-2 rounded-lg bg-emerald-50 text-emerald-700">
                      <Calendar className="w-5 h-5" />
                    </div>
                    <div>
                      <span className="text-xs font-bold uppercase tracking-wider text-slate-500">Next Upcoming Encounter</span>
                      <h2 className="text-base font-bold text-slate-900">{nextAppointment.title}</h2>
                    </div>
                  </div>
                  <span className="px-2.5 py-1 rounded-full bg-emerald-100 text-emerald-800 text-xs font-bold">
                    {nextAppointment.date}
                  </span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-xs">
                  <div className="bg-slate-50 p-3 rounded-xl border border-slate-200/70">
                    <span className="text-slate-500 font-semibold block mb-0.5">Time &amp; Arrival</span>
                    <span className="font-bold text-slate-900 text-sm block">{nextAppointment.time}</span>
                    <span className="text-[11px] text-slate-500">Duration: {nextAppointment.duration}</span>
                  </div>

                  <div className="bg-slate-50 p-3 rounded-xl border border-slate-200/70">
                    <span className="text-slate-500 font-semibold block mb-0.5">Attending Surgeon</span>
                    <span className="font-bold text-slate-900 text-sm block">{nextAppointment.doctor}</span>
                    <span className="text-[11px] text-slate-500">{nextAppointment.specialty}</span>
                  </div>

                  <div className="bg-slate-50 p-3 rounded-xl border border-slate-200/70">
                    <span className="text-slate-500 font-semibold block mb-0.5">Location &amp; Suite</span>
                    <span className="font-bold text-slate-900 text-sm block">{nextAppointment.room || 'OR Suite 1'}</span>
                    <span className="text-[11px] text-slate-500 truncate block">{nextAppointment.facility}</span>
                  </div>

                  <div className="bg-emerald-50 p-3 rounded-xl border border-emerald-200 flex flex-col justify-between">
                    <div>
                      <span className="text-emerald-800 font-bold block mb-0.5">Pre-Op Fasting Readiness</span>
                      <span className="text-[11px] text-emerald-700 leading-tight block">
                        Strict NPO: No food or drink after midnight prior to surgery.
                      </span>
                    </div>
                    <button
                      onClick={() => {
                        setViewingAppointment(nextAppointment);
                      }}
                      className="mt-2 text-xs text-emerald-800 font-bold hover:underline flex items-center gap-1 cursor-pointer"
                    >
                      <span>View Full Pre-Op Protocol</span>
                      <ChevronRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* Quick Portal Action Cards Grid */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
              
              {/* Card 1: Intake Forms Alert */}
              <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs hover:border-teal-300 transition-all flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <div className="p-2.5 rounded-xl bg-amber-50 text-amber-700 border border-amber-200">
                      <FileText className="w-5 h-5" />
                    </div>
                    <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-amber-100 text-amber-800">
                      {pendingFormsCount} Pending
                    </span>
                  </div>
                  <h3 className="font-bold text-slate-900 text-sm mb-1">Pre-Operative Intake Forms</h3>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    Sent via email from the Office Intelligence app. Complete medical history and digital consents to clear surgical check-in.
                  </p>
                </div>

                <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between">
                  <span className="text-xs text-slate-500 font-medium">{forms.length} total questionnaires</span>
                  <button
                    onClick={() => setActiveTab('forms')}
                    className="text-xs font-bold text-teal-700 hover:text-teal-900 flex items-center gap-1 cursor-pointer"
                  >
                    <span>Open Forms</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              {/* Card 2: Document Vault */}
              <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs hover:border-teal-300 transition-all flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <div className="p-2.5 rounded-xl bg-emerald-50 text-emerald-700 border border-emerald-200">
                      <Upload className="w-5 h-5" />
                    </div>
                    <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
                      {documents.length} Files
                    </span>
                  </div>
                  <h3 className="font-bold text-slate-900 text-sm mb-1">Clinical Documents &amp; Uploads</h3>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    Upload insurance cards, photo IDs, and outside medical clearances that sync directly into your clinic chart.
                  </p>
                </div>

                <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between">
                  <button
                    onClick={() => setIsUploadDocumentModalOpen(true)}
                    className="text-xs font-bold text-emerald-700 hover:text-emerald-900 flex items-center gap-1 cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Upload New File</span>
                  </button>
                  <button
                    onClick={() => setActiveTab('documents')}
                    className="text-xs font-semibold text-slate-500 hover:text-slate-800 cursor-pointer"
                  >
                    View All
                  </button>
                </div>
              </div>

              {/* Card 3: Care Team Messaging */}
              <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs hover:border-teal-300 transition-all flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <div className="p-2.5 rounded-xl bg-purple-50 text-purple-700 border border-purple-200">
                      <MessageSquare className="w-5 h-5" />
                    </div>
                    <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-purple-100 text-purple-800">
                      Care Team Active
                    </span>
                  </div>
                  <h3 className="font-bold text-slate-900 text-sm mb-1">Secure Practice Messaging</h3>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    Communicate directly with Camila Rojas, RN, Dr. Sterling, and the surgical coordinators regarding medications or preparation.
                  </p>
                </div>

                <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between">
                  <span className="text-xs text-slate-500 font-medium">HIPAA Encrypted</span>
                  <button
                    onClick={() => setActiveTab('messages')}
                    className="text-xs font-bold text-purple-700 hover:text-purple-900 flex items-center gap-1 cursor-pointer"
                  >
                    <span>Send Message</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

            </div>

            {/* Health Metrics & Care Plan Summary */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
              
              {/* Left 8 Cols: Vitals & Clinical Snapshot */}
              <div className="lg:col-span-8 bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-4">
                <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                  <div className="flex items-center gap-2">
                    <Activity className="w-4 h-4 text-teal-600" />
                    <h3 className="font-bold text-sm text-slate-900">Recorded Health Snapshot &amp; Vitals</h3>
                  </div>
                  <span className="text-xs text-slate-500">Verified by Aura Vanguard Staff</span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  <div className="p-3 bg-slate-50 rounded-xl border border-slate-200/80">
                    <span className="text-[11px] text-slate-500 font-medium block">Blood Pressure</span>
                    <span className="text-sm font-bold text-slate-900 block mt-0.5">{activeProfile.vitals.bloodPressure}</span>
                    <span className="text-[10px] text-emerald-700 font-semibold">Normal Sinus</span>
                  </div>

                  <div className="p-3 bg-slate-50 rounded-xl border border-slate-200/80">
                    <span className="text-[11px] text-slate-500 font-medium block">Heart Rate</span>
                    <span className="text-sm font-bold text-slate-900 block mt-0.5">{activeProfile.vitals.heartRate}</span>
                    <span className="text-[10px] text-emerald-700 font-semibold">Resting ECG Cleared</span>
                  </div>

                  <div className="p-3 bg-slate-50 rounded-xl border border-slate-200/80">
                    <span className="text-[11px] text-slate-500 font-medium block">Oxygen Sat (SpO2)</span>
                    <span className="text-sm font-bold text-slate-900 block mt-0.5">{activeProfile.vitals.oxygenSat}</span>
                    <span className="text-[10px] text-emerald-700 font-semibold">Room Air</span>
                  </div>

                  <div className="p-3 bg-slate-50 rounded-xl border border-slate-200/80">
                    <span className="text-[11px] text-slate-500 font-medium block">Height &amp; Weight</span>
                    <span className="text-sm font-bold text-slate-900 block mt-0.5">{activeProfile.vitals.weight}</span>
                    <span className="text-[10px] text-slate-500">BMI: {activeProfile.vitals.bmi}</span>
                  </div>
                </div>

                {/* Allergies on file */}
                <div className="p-3.5 bg-rose-50/80 rounded-xl border border-rose-200 flex items-start gap-3">
                  <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                  <div>
                    <span className="text-xs font-bold text-rose-900 block">Allergies on Clinical File:</span>
                    <div className="flex flex-wrap gap-1.5 mt-1">
                      {activeProfile.allergies.map((allergy, i) => (
                        <span key={i} className="text-xs bg-rose-200/90 text-rose-900 font-semibold px-2 py-0.5 rounded-md border border-rose-300">
                          {allergy}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              {/* Right 4 Cols: Pharmacy & Insurance Quick Info */}
              <div className="lg:col-span-4 bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-4 flex flex-col justify-between">
                <div>
                  <div className="flex items-center gap-2 border-b border-slate-100 pb-3 mb-3">
                    <ShieldCheck className="w-4 h-4 text-emerald-600" />
                    <h3 className="font-bold text-sm text-slate-900">Coverage &amp; Pharmacy</h3>
                  </div>

                  <div className="space-y-3 text-xs">
                    <div>
                      <span className="text-slate-500 font-medium block">Primary Insurance:</span>
                      <span className="font-bold text-slate-900 block">{activeProfile.insurance.provider}</span>
                      <span className="font-mono text-slate-600 text-[11px]">Policy: {activeProfile.insurance.policyNumber}</span>
                    </div>

                    <div className="pt-2 border-t border-slate-100">
                      <span className="text-slate-500 font-medium block">Preferred Pharmacy:</span>
                      <span className="font-bold text-slate-900 block">{activeProfile.preferredPharmacy.name}</span>
                      <span className="text-slate-600 text-[11px] block">{activeProfile.preferredPharmacy.address}</span>
                      <span className="text-slate-600 text-[11px] block">{activeProfile.preferredPharmacy.phone}</span>
                    </div>
                  </div>
                </div>

                <button
                  onClick={() => setActiveTab('prescriptions')}
                  className="w-full py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs rounded-xl transition-colors text-center cursor-pointer"
                >
                  View Active Prescriptions
                </button>
              </div>

            </div>

          </div>
        )}

        {/* ========================================================================= */}
        {/* TAB 2: APPOINTMENTS TIMELINE & REQUEST HUB */}
        {/* ========================================================================= */}
        {activeTab === 'appointments' && (
          <div className="space-y-6">
            
            {/* Header with CTA */}
            <div className="flex flex-wrap items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
              <div>
                <div className="flex items-center gap-2">
                  <h2 className="text-lg font-bold text-slate-900">Appointments &amp; Surgical Encounters</h2>
                  {selectedProvider && (
                    <span className="text-[11px] bg-teal-100 text-teal-900 font-bold px-2.5 py-0.5 rounded-full border border-teal-300">
                      {selectedProvider.shortName}
                    </span>
                  )}
                </div>
                <p className="text-xs text-slate-500">
                  Track upcoming visits, review pre-op instructions, view past clinical encounter summaries, and request new dates.
                </p>
              </div>

              <div className="flex items-center gap-2.5">
                {selectedProviderId !== 'all' && (
                  <button
                    onClick={() => setSelectedProviderId('all')}
                    className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-semibold transition-all cursor-pointer"
                  >
                    View All Practices
                  </button>
                )}
                <button
                  onClick={() => setIsAppointmentRequestModalOpen(true)}
                  className="px-4 py-2.5 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-xs font-bold shadow-xs transition-all flex items-center gap-1.5 cursor-pointer"
                >
                  <Plus className="w-4 h-4 text-white" />
                  <span>Request New Appointment</span>
                </button>
              </div>
            </div>

            {/* Timeline List */}
            {filteredAppointments.length === 0 ? (
              <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center space-y-3">
                <div className="w-12 h-12 rounded-full bg-slate-100 text-slate-500 mx-auto flex items-center justify-center">
                  <Calendar className="w-6 h-6" />
                </div>
                <h3 className="font-bold text-slate-800 text-sm">No Appointments Found</h3>
                <p className="text-xs text-slate-500 max-w-md mx-auto">
                  {selectedProvider 
                    ? `There are currently no scheduled appointments for ${selectedProvider.name}.`
                    : 'You have no scheduled appointments on file.'}
                </p>
                {selectedProviderId !== 'all' && (
                  <button
                    onClick={() => setSelectedProviderId('all')}
                    className="mt-2 text-xs font-bold text-teal-700 hover:underline cursor-pointer"
                  >
                    Show Appointments from All Practices
                  </button>
                )}
              </div>
            ) : (
              <div className="space-y-4">
                {filteredAppointments.map((apt) => {
                  const isUpcoming = apt.status === 'UPCOMING';
                  const isRequested = apt.status === 'REQUESTED';

                  return (
                    <div
                      key={apt.id}
                      className={`bg-white rounded-2xl border p-5 shadow-xs transition-all ${
                        isUpcoming ? 'border-emerald-300 ring-1 ring-emerald-100' : isRequested ? 'border-amber-300 bg-amber-50/20' : 'border-slate-200'
                      }`}
                    >
                      <div className="flex flex-col md:flex-row md:items-start justify-between gap-4">
                        
                        <div className="flex items-start gap-3.5">
                          <div className={`p-3 rounded-xl shrink-0 ${
                            isUpcoming ? 'bg-emerald-100 text-emerald-800' : isRequested ? 'bg-amber-100 text-amber-800' : 'bg-slate-100 text-slate-700'
                          }`}>
                            <Calendar className="w-5 h-5" />
                          </div>

                          <div className="space-y-1">
                            <div className="flex items-center gap-2 flex-wrap">
                              <span className={`text-xs font-bold px-2 py-0.5 rounded-full ${
                                isUpcoming ? 'bg-emerald-100 text-emerald-800' : isRequested ? 'bg-amber-100 text-amber-800' : 'bg-slate-100 text-slate-700'
                              }`}>
                                {apt.status}
                              </span>
                              <span className="text-xs font-bold text-slate-500">{apt.date} • {apt.time}</span>
                              {apt.practiceName && (
                                <span className="text-[10px] font-semibold text-slate-500 bg-slate-100 px-2 py-0.5 rounded-md">
                                  {apt.practiceName}
                                </span>
                              )}
                            </div>

                            <h3 className="text-base font-bold text-slate-900">{apt.title}</h3>
                            
                            <div className="text-xs text-slate-600 flex items-center gap-2 flex-wrap">
                              <span className="font-semibold text-slate-800">{apt.doctor}</span>
                              <span>•</span>
                              <span>{apt.facility}</span>
                              {apt.room && <span>({apt.room})</span>}
                            </div>

                            {apt.instructions && (
                              <p className="text-xs text-slate-600 bg-slate-50 p-2.5 rounded-lg border border-slate-200/80 mt-2 max-w-2xl">
                                <span className="font-bold text-slate-800">Special Instructions: </span>
                                {apt.instructions}
                              </p>
                            )}

                            {apt.summaryNote && (
                              <p className="text-xs text-slate-600 bg-slate-50 p-2.5 rounded-lg border border-slate-200/80 mt-2 max-w-2xl">
                                <span className="font-bold text-slate-800">Clinical Summary: </span>
                                {apt.summaryNote}
                              </p>
                            )}
                          </div>
                        </div>

                        {/* Action Buttons */}
                        <div className="flex flex-wrap md:flex-col items-end gap-2 shrink-0">
                          {isUpcoming && (
                            <>
                              <button
                                onClick={() => {
                                  showToast(`Checked in for ${apt.title}! Staff alert sent.`);
                                }}
                                className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-lg shadow-xs transition-colors cursor-pointer"
                              >
                                Digital Check-In
                              </button>
                              <button
                                onClick={() => setViewingAppointment(apt)}
                                className="px-3.5 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-800 font-semibold text-xs rounded-lg transition-colors cursor-pointer"
                              >
                                View Pre-Op Checklist
                              </button>
                            </>
                          )}
                          
                          {!isUpcoming && (
                            <button
                              onClick={() => {
                                setActiveTab('documents');
                                showToast('Viewing clinical notes & documents for past encounter.');
                              }}
                              className="px-3.5 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-800 font-semibold text-xs rounded-lg transition-colors cursor-pointer flex items-center gap-1"
                            >
                              <FileText className="w-3.5 h-3.5 text-slate-600" />
                              <span>View Visit Notes</span>
                            </button>
                          )}
                        </div>

                      </div>
                    </div>
                  );
                })}
              </div>
            )}

          </div>
        )}

        {/* ========================================================================= */}
        {/* TAB 3: INTAKE FORMS SENT FROM OFFICE INTELLIGENCE */}
        {/* ========================================================================= */}
        {activeTab === 'forms' && (
          <div className="space-y-6">
            
            {/* Header Banner */}
            <div className="bg-gradient-to-r from-[#1c2d3d] via-[#243b53] to-[#2f495e] p-6 rounded-2xl text-white shadow-md border border-slate-700/50 flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div className="space-y-1">
                <div className="inline-flex items-center gap-1.5 text-teal-300 font-bold text-xs uppercase tracking-wider">
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Office Intelligence E-Forms Sync</span>
                </div>
                <div className="flex items-center gap-2.5 flex-wrap">
                  <h2 className="text-xl font-bold text-white">Pre-Operative Intake &amp; Surgical Consents</h2>
                  {selectedProvider && (
                    <span className="text-xs bg-teal-500/30 text-teal-200 font-bold px-2.5 py-0.5 rounded-full border border-teal-400/40">
                      {selectedProvider.shortName}
                    </span>
                  )}
                </div>
                <p className="text-xs text-slate-300 max-w-2xl leading-relaxed">
                  These electronic questionnaires and informed consent packets were dispatched directly from your Office Intelligence clinical chart. You can preview, fill out, and digitally sign each questionnaire below to update your surgical clearance record.
                </p>
              </div>

              <div className="flex items-center gap-4 bg-slate-900/60 border border-slate-700/60 px-5 py-3 rounded-xl shrink-0">
                <div className="text-center pr-4 border-r border-slate-700">
                  <span className="text-2xl font-black text-emerald-400">
                    {filteredPortalHtmlForms.filter((f) => f.status === 'Completed in Portal').length}
                  </span>
                  <span className="text-[10px] text-slate-400 block font-semibold uppercase">Completed</span>
                </div>
                <div className="text-center">
                  <span className="text-2xl font-black text-amber-400">
                    {pendingHtmlFormsCount}
                  </span>
                  <span className="text-[10px] text-slate-400 block font-semibold uppercase">Incomplete</span>
                </div>
              </div>
            </div>

            {/* Tabular Forms Table (matching PatientChartPage.tsx) */}
            <div className="bg-white rounded-2xl border border-slate-200/90 shadow-xs overflow-hidden">
              <div className="p-4 bg-slate-50 border-b border-slate-200 flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center gap-2">
                  <FileText className="w-4 h-4 text-teal-700" />
                  <span className="font-bold text-xs text-slate-900 uppercase tracking-wide">
                    Intake Questionnaires &amp; Disclosures ({filteredPortalHtmlForms.length})
                  </span>
                </div>

                <div className="text-xs text-slate-500 flex items-center gap-2">
                  <span className="inline-block w-2 h-2 rounded-full bg-emerald-500"></span>
                  <span>Instant two-way sync with provider clinical chart</span>
                </div>
              </div>

              {filteredPortalHtmlForms.length === 0 ? (
                <div className="p-10 text-center space-y-2">
                  <FileText className="w-8 h-8 text-slate-400 mx-auto" />
                  <h4 className="font-bold text-slate-800 text-sm">No Intake Forms Found</h4>
                  <p className="text-xs text-slate-500">
                    {selectedProvider ? `There are no pending intake forms for ${selectedProvider.name}.` : 'No forms currently assigned.'}
                  </p>
                  {selectedProviderId !== 'all' && (
                    <button
                      onClick={() => setSelectedProviderId('all')}
                      className="mt-2 text-xs font-bold text-teal-700 hover:underline cursor-pointer"
                    >
                      Show Forms for All Providers
                    </button>
                  )}
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse">
                    <thead>
                      <tr className="bg-slate-100/80 border-b border-slate-200 text-[11px] font-bold text-slate-600 uppercase tracking-wider">
                        <th className="p-3.5 pl-4 w-10 text-center">
                          <input
                            type="checkbox"
                            checked={filteredPortalHtmlForms.length > 0 && selectedIntakeFormIds.length === filteredPortalHtmlForms.length}
                            onChange={(e) => {
                              if (e.target.checked) {
                                setSelectedIntakeFormIds(filteredPortalHtmlForms.map((f) => f.id));
                              } else {
                                setSelectedIntakeFormIds([]);
                              }
                            }}
                            className="w-4 h-4 rounded border-slate-300 text-teal-600 focus:ring-teal-500 cursor-pointer"
                            title="Select / Deselect All Forms"
                          />
                        </th>
                        <th className="p-3.5"># &amp; Form Name</th>
                        <th className="p-3.5">Practice / Doctor</th>
                        <th className="p-3.5">Status</th>
                        <th className="p-3.5">Last Activity</th>
                        <th className="p-3.5 text-right pr-4">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200/80 text-xs">
                      {filteredPortalHtmlForms.map((form, idx) => {
                        const isCompleted = form.status === 'Completed in Portal';

                        return (
                          <tr key={form.id} className="hover:bg-slate-50/80 transition-colors">
                            <td className="p-3.5 pl-4 w-10 text-center">
                              <input
                                type="checkbox"
                                checked={selectedIntakeFormIds.includes(form.id)}
                                onChange={() => {
                                  if (selectedIntakeFormIds.includes(form.id)) {
                                    setSelectedIntakeFormIds(selectedIntakeFormIds.filter((id) => id !== form.id));
                                  } else {
                                    setSelectedIntakeFormIds([...selectedIntakeFormIds, form.id]);
                                  }
                                }}
                                className="w-4 h-4 rounded border-slate-300 text-teal-600 focus:ring-teal-500 cursor-pointer"
                              />
                            </td>

                            <td className="p-3.5 min-w-[220px]">
                              <div className="flex items-start gap-2.5">
                                <span className="w-5 h-5 rounded-full bg-slate-200 text-slate-800 font-bold text-[10px] flex items-center justify-center shrink-0 mt-0.5">
                                  {idx + 1}
                                </span>
                                <div>
                                  <div className="font-bold text-slate-900 text-xs flex items-center gap-1.5">
                                    <span>{form.title}</span>
                                  </div>
                                  <div className="text-[11px] text-slate-500 font-mono font-medium line-clamp-1 mt-0.5">
                                    {form.fileName}
                                  </div>
                                </div>
                              </div>
                            </td>

                            <td className="p-3.5 text-slate-700 text-xs">
                              <div className="font-semibold text-slate-800">{form.doctor || 'Dr. Alistair Sterling, MD'}</div>
                              <div className="text-[10.5px] text-slate-500">{form.practiceName || 'Aura Vanguard Plastic Surgery'}</div>
                            </td>

                            <td className="p-3.5">
                              <span
                                className={`px-2.5 py-1 rounded-full text-[10.5px] font-bold border flex items-center gap-1.5 w-fit ${
                                  form.status === 'Completed in Portal'
                                    ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                                    : form.status === 'Sent via Email'
                                    ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                                    : form.status === 'Sent via SMS'
                                    ? 'bg-teal-50 text-teal-800 border-teal-200'
                                    : 'bg-amber-50 text-amber-800 border-amber-200'
                                }`}
                              >
                                {form.status === 'Completed in Portal' && <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />}
                                {form.status === 'Sent via Email' && <Mail className="w-3.5 h-3.5 text-emerald-600" />}
                                {form.status === 'Sent via SMS' && <Smartphone className="w-3.5 h-3.5 text-teal-600" />}
                                {form.status === 'Pending Send' && <Clock className="w-3.5 h-3.5 text-amber-600" />}
                                <span>{form.status}</span>
                              </span>
                            </td>

                            <td className="p-3.5 text-slate-600 text-[11px] font-mono">
                              {form.completedDate ? (
                                <span className="text-emerald-700 font-semibold">Completed {form.completedDate}</span>
                              ) : form.lastSentDate ? (
                                <span>Sent {form.lastSentDate}</span>
                              ) : (
                                <span className="text-amber-700 font-medium">Pending Completion</span>
                              )}
                            </td>

                            <td className="p-3.5 text-right pr-4">
                              <div className="flex items-center justify-end gap-2">
                                {/* Combined Single Button: Complete OR Fill & Sign */}
                                {isCompleted ? (
                                  <button
                                    onClick={() => {
                                      setFillSignature(form.signedBy || `${activeProfile.firstName} ${activeProfile.lastName}`);
                                      setFillAgreed(true);
                                      setViewingHtmlForm(form);
                                    }}
                                    title="View Completed Form & Legal Seal"
                                    className="px-3.5 py-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-300 rounded-lg transition-colors cursor-pointer shadow-2xs flex items-center gap-1.5 text-xs font-bold"
                                  >
                                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                                    <span>Complete</span>
                                  </button>
                                ) : (
                                  <button
                                    onClick={() => {
                                      setFillSignature(`${activeProfile.firstName} ${activeProfile.lastName}`);
                                      setFillAgreed(true);
                                      setViewingHtmlForm(form);
                                    }}
                                    title="Fill & Sign Form"
                                    className="px-3.5 py-1.5 bg-teal-600 hover:bg-teal-700 text-white rounded-lg transition-colors cursor-pointer shadow-xs flex items-center gap-1.5 text-xs font-bold"
                                  >
                                    <PenTool className="w-3.5 h-3.5 text-white" />
                                    <span>Fill &amp; Sign</span>
                                  </button>
                                )}
                              </div>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              )}

              <div className="p-4 bg-teal-50/80 border-t border-teal-200 text-xs text-teal-950 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-teal-700 shrink-0" />
                  <span>
                    Digitally completed forms are encrypted with a cryptographic timestamp and filed into your Office Intelligence medical record.
                  </span>
                </div>
                {selectedIntakeFormIds.length > 0 && (
                  <span className="font-bold text-teal-900 bg-teal-100 px-2.5 py-1 rounded-lg">
                    {selectedIntakeFormIds.length} Form(s) selected
                  </span>
                )}
              </div>
            </div>

          </div>
        )}

        {/* ========================================================================= */}
        {/* TAB 4: TWO-WAY SECURE MESSAGING WITH CLINIC & CARE TEAM */}
        {/* ========================================================================= */}
        {activeTab === 'messages' && (
          <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden flex flex-col h-[700px]">
            
            {/* Thread Header */}
            <div className="p-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-teal-600 text-white font-bold flex items-center justify-center text-sm shadow-xs">
                  <Stethoscope className="w-5 h-5" />
                </div>
                <div>
                  <h2 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                    <span>{selectedProvider ? selectedProvider.practiceName : 'Aura Vanguard Surgical Care Team'}</span>
                    <span className="text-[10px] bg-emerald-100 text-emerald-800 px-2 py-0.2 rounded-full font-bold">Online</span>
                  </h2>
                  <p className="text-xs text-slate-500">
                    {selectedProvider ? `${selectedProvider.name} (${selectedProvider.specialty})` : 'Dr. Alistair Sterling, MD • Dr. Raymond Cruz, MD • Camila Rojas, RN'}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-3">
                {selectedProviderId !== 'all' && (
                  <button
                    onClick={() => setSelectedProviderId('all')}
                    className="text-[11px] font-bold text-teal-700 bg-teal-50 px-2.5 py-1 rounded-lg border border-teal-200 hover:bg-teal-100 cursor-pointer hidden md:block"
                  >
                    Showing {selectedProvider?.shortName} • Reset
                  </button>
                )}
                <div className="text-xs text-slate-400 hidden sm:flex items-center gap-1">
                  <ShieldCheck className="w-4 h-4 text-emerald-600" />
                  <span>HIPAA Encrypted Channel</span>
                </div>
              </div>
            </div>

            {/* Message Feed */}
            <div className="flex-1 p-5 overflow-y-auto space-y-4 bg-slate-50/40">
              {filteredMessages.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center text-center p-6 space-y-2">
                  <MessageSquare className="w-8 h-8 text-slate-400" />
                  <h4 className="font-bold text-slate-700 text-xs">No Direct Messages Found</h4>
                  <p className="text-xs text-slate-500 max-w-sm">
                    {selectedProvider ? `You have no archived messages with ${selectedProvider.name}. Send a new message below!` : 'No messages in this folder.'}
                  </p>
                </div>
              ) : (
                filteredMessages.map((msg) => {
                  const isMe = msg.sender === 'patient';

                  return (
                    <div
                      key={msg.id}
                      className={`flex flex-col ${isMe ? 'items-end' : 'items-start'}`}
                    >
                      <div className="text-[11px] text-slate-500 font-semibold mb-1 flex items-center gap-1.5 px-1">
                        <span>{msg.senderName}</span>
                        {msg.senderTitle && <span className="text-[10px] text-teal-700">({msg.senderTitle})</span>}
                        {msg.practiceName && <span className="text-[10px] text-slate-400">[{msg.practiceName}]</span>}
                        <span>•</span>
                        <span>{msg.timestamp}</span>
                      </div>

                      <div className={`max-w-xl p-4 rounded-2xl text-xs leading-relaxed shadow-2xs ${
                        isMe 
                          ? 'bg-[#1F6E52] text-white rounded-tr-xs' 
                          : 'bg-white text-slate-800 border border-slate-200 rounded-tl-xs'
                      }`}>
                        {msg.category && (
                          <span className={`inline-block text-[10px] font-bold px-2 py-0.5 rounded-full mb-2 ${
                            isMe ? 'bg-slate-700 text-teal-200' : 'bg-teal-50 text-teal-800 border border-teal-200'
                          }`}>
                            {msg.category}
                          </span>
                        )}
                        <p>{msg.content}</p>
                      </div>
                    </div>
                  );
                })
              )}
            </div>

            {/* Message Input Box */}
            <form onSubmit={handleSendMessage} className="p-3 bg-white border-t border-slate-200 flex flex-col gap-2">
              <div className="flex items-center gap-2">
                <span className="text-xs text-slate-500 font-semibold">Message Topic:</span>
                <select
                  value={newMessageCategory}
                  onChange={(e) => setNewMessageCategory(e.target.value as any)}
                  className="text-xs bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1 text-slate-800 focus:outline-none focus:border-teal-500 font-medium cursor-pointer"
                >
                  <option value="Clinical Question">Clinical Question / Pre-Op</option>
                  <option value="Prescription Refill">Prescription Refill Request</option>
                  <option value="Scheduling">Scheduling / Rescheduling</option>
                  <option value="Billing">Billing &amp; Payment Inquiry</option>
                  <option value="General">General Question</option>
                </select>
              </div>

              <div className="flex items-center gap-2">
                <input
                  type="text"
                  value={newMessageText}
                  onChange={(e) => setNewMessageText(e.target.value)}
                  placeholder={`Type your message to ${selectedProvider ? selectedProvider.name : 'the surgical care team'}...`}
                  className="flex-1 px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:outline-none focus:border-teal-500 focus:bg-white transition-all"
                />

                <button
                  type="button"
                  onClick={() => setIsUploadDocumentModalOpen(true)}
                  className="p-2.5 text-slate-500 hover:text-teal-600 rounded-xl hover:bg-slate-100 transition-colors border border-slate-200"
                  title="Attach Photo or Document"
                >
                  <Paperclip className="w-4 h-4" />
                </button>

                <button
                  type="submit"
                  className="px-5 py-2.5 bg-teal-600 hover:bg-teal-700 text-white font-bold text-xs rounded-xl shadow-xs transition-colors flex items-center gap-1.5 cursor-pointer"
                >
                  <span>Send</span>
                  <Send className="w-3.5 h-3.5" />
                </button>
              </div>
            </form>

          </div>
        )}

        {/* ========================================================================= */}
        {/* TAB 5: CLINICAL DOCUMENTS & PATIENT UPLOADS */}
        {/* ========================================================================= */}
        {activeTab === 'documents' && (
          <div className="space-y-6">
            
            {/* Header Bar */}
            <div className="flex flex-wrap items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
              <div>
                <div className="flex items-center gap-2">
                  <h2 className="text-lg font-bold text-slate-900">Documents, Labs &amp; Patient Uploads</h2>
                  {selectedProvider && (
                    <span className="text-[11px] bg-teal-100 text-teal-900 font-bold px-2.5 py-0.5 rounded-full border border-teal-300">
                      {selectedProvider.shortName}
                    </span>
                  )}
                </div>
                <p className="text-xs text-slate-500">
                  View lab results, diagnostic clearances, and upload insurance cards or photo IDs that appear directly in your clinic chart.
                </p>
              </div>

              <div className="flex items-center gap-2.5">
                {selectedProviderId !== 'all' && (
                  <button
                    onClick={() => setSelectedProviderId('all')}
                    className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-semibold transition-all cursor-pointer"
                  >
                    View All Practices
                  </button>
                )}
                <button
                  onClick={() => setIsUploadDocumentModalOpen(true)}
                  className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-xs transition-all flex items-center gap-1.5 cursor-pointer"
                >
                  <Upload className="w-4 h-4 text-white" />
                  <span>Upload New Document</span>
                </button>
              </div>
            </div>

            {/* Documents Grid */}
            {filteredDocuments.length === 0 ? (
              <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center space-y-3">
                <div className="w-12 h-12 rounded-full bg-slate-100 text-slate-500 mx-auto flex items-center justify-center">
                  <FileText className="w-6 h-6" />
                </div>
                <h3 className="font-bold text-slate-800 text-sm">No Documents Found</h3>
                <p className="text-xs text-slate-500 max-w-md mx-auto">
                  {selectedProvider 
                    ? `There are no clinical records or uploads on file for ${selectedProvider.name}.`
                    : 'No documents or lab results available.'}
                </p>
                {selectedProviderId !== 'all' && (
                  <button
                    onClick={() => setSelectedProviderId('all')}
                    className="mt-2 text-xs font-bold text-teal-700 hover:underline cursor-pointer"
                  >
                    Show Documents for All Practices
                  </button>
                )}
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {filteredDocuments.map((doc) => (
                  <div
                    key={doc.id}
                    className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs hover:shadow-md transition-all flex flex-col justify-between"
                  >
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500 px-2 py-0.5 rounded-full bg-slate-100">
                          {doc.category}
                        </span>
                        <span className={`text-[10px] font-bold px-2 py-0.2 rounded-full ${
                          doc.uploadedBy === 'Patient' ? 'bg-purple-100 text-purple-800' : 'bg-emerald-100 text-emerald-800'
                        }`}>
                          {doc.uploadedBy === 'Patient' ? 'Patient Upload' : 'Practice Record'}
                        </span>
                      </div>

                      <div className="flex items-start gap-2.5 mt-2">
                        <div className="p-2 rounded-lg bg-slate-100 text-slate-700 shrink-0">
                          <FileText className="w-5 h-5 text-teal-700" />
                        </div>
                        <div>
                          <h3 className="font-bold text-xs text-slate-900 leading-snug">{doc.title}</h3>
                          <span className="text-[11px] font-mono text-slate-500 block truncate mt-0.5">{doc.fileName}</span>
                          {doc.practiceName && (
                            <span className="text-[10px] text-teal-700 font-semibold block mt-0.5">
                              {doc.practiceName}
                            </span>
                          )}
                        </div>
                      </div>

                      <p className="text-xs text-slate-600 mt-2.5 line-clamp-2 bg-slate-50 p-2 rounded-lg border border-slate-100">
                        {doc.summary}
                      </p>
                    </div>

                    <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
                      <span className="text-slate-500 text-[11px]">{doc.uploadDate} • {doc.fileSize}</span>
                      <div className="flex items-center gap-1.5">
                        <button
                          onClick={() => setViewingDocument(doc)}
                          className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold rounded-md transition-colors cursor-pointer flex items-center gap-1"
                        >
                          <Eye className="w-3.5 h-3.5" />
                          <span>View</span>
                        </button>
                        <button
                          onClick={() => {
                            showToast(`Downloaded ${doc.fileName}`);
                          }}
                          className="p-1 text-slate-500 hover:text-slate-900 rounded-md transition-colors cursor-pointer"
                          title="Download PDF"
                        >
                          <Download className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}

          </div>
        )}

        {/* ========================================================================= */}
        {/* TAB 6: PRESCRIPTIONS & REFILL REQUESTS */}
        {/* ========================================================================= */}
        {activeTab === 'prescriptions' && (
          <div className="space-y-6">
            
            <div className="flex flex-wrap items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
              <div>
                <div className="flex items-center gap-2">
                  <h2 className="text-lg font-bold text-slate-900">Active Prescriptions &amp; Medications</h2>
                  {selectedProvider && (
                    <span className="text-[11px] bg-teal-100 text-teal-900 font-bold px-2.5 py-0.5 rounded-full border border-teal-300">
                      {selectedProvider.shortName}
                    </span>
                  )}
                </div>
                <p className="text-xs text-slate-500">
                  Review your prescribed post-operative medications, directions, and submit refill or new prescription requests to your provider.
                </p>
              </div>

              <div className="flex items-center gap-3 flex-wrap">
                <div className="text-xs text-slate-600 bg-slate-100 px-3 py-2 rounded-xl border border-slate-200 hidden sm:block">
                  <span className="font-semibold">Pharmacy: </span>{activeProfile.preferredPharmacy.name}
                </div>

                {selectedProviderId !== 'all' && (
                  <button
                    onClick={() => setSelectedProviderId('all')}
                    className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-semibold transition-all cursor-pointer"
                  >
                    View All Practices
                  </button>
                )}

                <button
                  onClick={() => setIsNewPrescriptionModalOpen(true)}
                  className="px-4 py-2.5 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-xs font-bold shadow-xs transition-all flex items-center gap-1.5 cursor-pointer"
                >
                  <Plus className="w-4 h-4 text-white" />
                  <span>Request New Prescription</span>
                </button>
              </div>
            </div>

            {filteredPrescriptions.length === 0 ? (
              <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center space-y-3">
                <div className="w-12 h-12 rounded-full bg-slate-100 text-slate-500 mx-auto flex items-center justify-center">
                  <Pill className="w-6 h-6" />
                </div>
                <h3 className="font-bold text-slate-800 text-sm">No Prescriptions Found</h3>
                <p className="text-xs text-slate-500 max-w-md mx-auto">
                  {selectedProvider 
                    ? `No active prescriptions issued by ${selectedProvider.name}.`
                    : 'No active prescriptions currently on file.'}
                </p>
                <div className="flex items-center justify-center gap-3 mt-3">
                  {selectedProviderId !== 'all' && (
                    <button
                      onClick={() => setSelectedProviderId('all')}
                      className="text-xs font-bold text-teal-700 hover:underline cursor-pointer"
                    >
                      Show Prescriptions from All Practices
                    </button>
                  )}
                  <button
                    onClick={() => setIsNewPrescriptionModalOpen(true)}
                    className="px-4 py-2 bg-teal-600 text-white rounded-xl text-xs font-bold shadow-xs hover:bg-teal-700 cursor-pointer"
                  >
                    Request New Prescription
                  </button>
                </div>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
                {filteredPrescriptions.map((rx) => (
                  <div
                    key={rx.id}
                    className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs flex flex-col justify-between"
                  >
                    <div className="space-y-2.5">
                      <div className="flex items-center justify-between">
                        <div className="p-2 rounded-lg bg-rose-50 text-rose-700">
                          <Pill className="w-5 h-5" />
                        </div>
                        <span className={`text-xs font-bold px-2 py-0.5 rounded-full ${
                          rx.status === 'ACTIVE' ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-900'
                        }`}>
                          {rx.status === 'ACTIVE' ? 'Active Rx' : 'Refill Requested'}
                        </span>
                      </div>

                      <div>
                        <h3 className="font-bold text-sm text-slate-900">{rx.medicationName}</h3>
                        <span className="text-xs font-semibold text-teal-700">{rx.dosage}</span>
                        {rx.practiceName && (
                          <span className="text-[10px] text-slate-500 font-medium block mt-0.5">
                            {rx.practiceName}
                          </span>
                        )}
                      </div>

                      <p className="text-xs text-slate-600 bg-slate-50 p-2.5 rounded-lg border border-slate-200/80">
                        <span className="font-bold text-slate-800">Directions: </span>
                        {rx.instructions}
                      </p>

                      <div className="text-[11px] text-slate-500 space-y-0.5">
                        <div>Prescribed by: <span className="font-semibold text-slate-800">{rx.prescribedBy}</span></div>
                        <div>Date: {rx.datePrescribed} • Refills left: <span className="font-bold text-slate-800">{rx.refillsRemaining}</span></div>
                      </div>
                    </div>

                    <div className="mt-4 pt-3 border-t border-slate-100">
                      <button
                        onClick={() => {
                          setSelectedPrescriptionForRefill(rx);
                          setIsRefillModalOpen(true);
                        }}
                        disabled={rx.status === 'REFILL_REQUESTED'}
                        className={`w-full py-2 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                          rx.status === 'REFILL_REQUESTED'
                            ? 'bg-slate-100 text-slate-400 cursor-not-allowed'
                            : 'bg-teal-600 hover:bg-teal-700 text-white shadow-xs'
                        }`}
                      >
                        <RefreshCw className="w-3.5 h-3.5" />
                        <span>{rx.status === 'REFILL_REQUESTED' ? 'Refill In Review' : 'Request Refill'}</span>
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}

          </div>
        )}

        {/* ========================================================================= */}
        {/* TAB 7: BILLING & ONLINE PAYMENTS */}
        {/* ========================================================================= */}
        {activeTab === 'billing' && (
          <div className="space-y-6">
            
            {/* Balance Overview Card */}
            <div className="bg-gradient-to-r from-[#1e293b] via-[#5B6B60] to-[#1e293b] rounded-2xl p-6 text-white shadow-md flex flex-col md:flex-row md:items-center justify-between gap-6">
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold uppercase tracking-wider text-teal-400">Statement Summary</span>
                  {selectedProvider && (
                    <span className="text-[10px] bg-teal-500/30 text-teal-200 font-bold px-2 py-0.5 rounded-md">
                      {selectedProvider.shortName}
                    </span>
                  )}
                </div>
                <h2 className="text-3xl font-serif font-bold text-white mt-1">
                  ${outstandingBalance.toFixed(2)}
                </h2>
                <p className="text-xs text-slate-300 mt-1">
                  {outstandingBalance > 0 
                    ? `Total balance due for ${selectedProvider ? selectedProvider.practiceName : 'upcoming surgical facility & anesthesia co-pay'}.` 
                    : 'All statement balances are paid in full. Thank you!'}
                </p>
              </div>

              {outstandingBalance > 0 && (
                <button
                  onClick={() => setIsPaymentModalOpen(true)}
                  className="px-6 py-3 bg-teal-400 hover:bg-teal-300 text-slate-950 font-bold text-sm rounded-xl shadow-lg transition-all flex items-center gap-2 cursor-pointer"
                >
                  <CreditCard className="w-4 h-4" />
                  <span>Pay Balance (${outstandingBalance.toFixed(2)})</span>
                </button>
              )}
            </div>

            {/* Statements List */}
            {filteredBills.length === 0 ? (
              <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center space-y-3">
                <div className="w-12 h-12 rounded-full bg-emerald-50 text-emerald-600 mx-auto flex items-center justify-center">
                  <CheckCircle2 className="w-6 h-6" />
                </div>
                <h3 className="font-bold text-slate-800 text-sm">No Statements Found</h3>
                <p className="text-xs text-slate-500 max-w-md mx-auto">
                  {selectedProvider ? `There are no active or past invoices for ${selectedProvider.name}.` : 'No billing records on file.'}
                </p>
                {selectedProviderId !== 'all' && (
                  <button
                    onClick={() => setSelectedProviderId('all')}
                    className="mt-2 text-xs font-bold text-teal-700 hover:underline cursor-pointer"
                  >
                    Show Statements from All Practices
                  </button>
                )}
              </div>
            ) : (
              <div className="space-y-4">
                {filteredBills.map((bill) => (
                  <div key={bill.id} className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-4">
                    <div className="flex flex-wrap items-center justify-between border-b border-slate-100 pb-3 gap-2">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-bold text-slate-500 uppercase">{bill.statementDate}</span>
                          {bill.practiceName && (
                            <span className="text-[10px] font-semibold text-teal-800 bg-teal-50 px-2 py-0.5 rounded-md border border-teal-200">
                              {bill.practiceName}
                            </span>
                          )}
                        </div>
                        <h3 className="text-base font-bold text-slate-900 mt-0.5">{bill.description}</h3>
                      </div>
                      <span className={`text-xs font-bold px-3 py-1 rounded-full ${
                        bill.status === 'PAID' ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'
                      }`}>
                        {bill.status === 'PAID' ? `PAID IN FULL (Receipt: ${bill.receiptId})` : `Due: ${bill.dueDate}`}
                      </span>
                    </div>

                    {/* Itemized charges table */}
                    <div className="overflow-x-auto">
                      <table className="w-full text-xs text-left">
                        <thead className="bg-slate-50 text-slate-500 font-bold border-b border-slate-200">
                          <tr>
                            <th className="py-2 px-3">Service / Procedure Item</th>
                            <th className="py-2 px-3 text-right">Standard Charge</th>
                            <th className="py-2 px-3 text-right">Insurance Paid / Adj</th>
                            <th className="py-2 px-3 text-right font-bold text-slate-900">Your Co-Pay</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100 text-slate-700">
                          {bill.items.map((item, i) => (
                            <tr key={i}>
                              <td className="py-2 px-3 font-medium">{item.description}</td>
                              <td className="py-2 px-3 text-right font-mono">${item.charge.toFixed(2)}</td>
                              <td className="py-2 px-3 text-right font-mono text-emerald-700">-${item.insuranceDiscount.toFixed(2)}</td>
                              <td className="py-2 px-3 text-right font-mono font-bold text-slate-900">${item.patientOwes.toFixed(2)}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                ))}
              </div>
            )}

          </div>
        )}

      </main>

      {/* ========================================================================= */}
      {/* MODAL 1: INTAKE FORM COMPLETION WIZARD */}
      {/* ========================================================================= */}
      {activeFormModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl border border-slate-200 shadow-2xl max-w-2xl w-full max-h-[90vh] flex flex-col overflow-hidden animate-in fade-in zoom-in-95 duration-200">
            
            {/* Modal Header */}
            <div className="p-4 bg-[#1F6E52] text-white flex items-center justify-between">
              <div>
                <span className="text-[10px] font-mono uppercase tracking-wider text-teal-300">Office Intelligence E-Form</span>
                <h3 className="font-bold text-sm sm:text-base">{activeFormModal.title}</h3>
              </div>
              <button
                onClick={() => setActiveFormModal(null)}
                className="p-1 rounded-lg text-slate-300 hover:text-white hover:bg-slate-800 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Body: Multi-Step Form */}
            <form onSubmit={handleSubmitIntakeForm} className="flex-1 p-6 overflow-y-auto space-y-5 text-xs text-slate-800">
              
              {/* Step indicator */}
              <div className="flex items-center justify-between border-b border-slate-200 pb-3">
                <span className="font-bold text-slate-900">Step {formStep} of 3: Clinical Disclosures &amp; Attestation</span>
                <span className="text-slate-500 font-mono">Patient: {activeProfile.firstName} {activeProfile.lastName}</span>
              </div>

              {formStep === 1 && (
                <div className="space-y-4">
                  <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
                    <span className="font-bold text-slate-900 block mb-1">1. Patient Identification &amp; Demographics Verification</span>
                    <p className="text-slate-600 text-[11px]">
                      Please confirm that your legal name, date of birth ({activeProfile.dob}), and contact phone ({activeProfile.phone}) are current.
                    </p>
                  </div>

                  <div>
                    <span className="font-bold text-slate-900 block mb-2">2. Medical History Screening (Check all that apply):</span>
                    <div className="grid grid-cols-2 gap-2">
                      {Object.keys(medicalHistoryChecks).map((k) => (
                        <label key={k} className="flex items-center gap-2 p-2 rounded-lg bg-slate-50 border border-slate-200 cursor-pointer hover:bg-slate-100">
                          <input
                            type="checkbox"
                            checked={medicalHistoryChecks[k]}
                            onChange={(e) => setMedicalHistoryChecks({ ...medicalHistoryChecks, [k]: e.target.checked })}
                            className="rounded text-teal-600 focus:ring-teal-500"
                          />
                          <span className="capitalize text-slate-800">{k.replace(/([A-Z])/g, ' $1')}</span>
                        </label>
                      ))}
                    </div>
                  </div>

                  <div className="flex justify-end pt-3">
                    <button
                      type="button"
                      onClick={() => setFormStep(2)}
                      className="px-5 py-2 bg-teal-600 hover:bg-teal-700 text-white font-bold rounded-xl transition-colors flex items-center gap-1 cursor-pointer"
                    >
                      <span>Next: Surgical &amp; Anesthesia Disclosure</span>
                      <ChevronRight className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              )}

              {formStep === 2 && (
                <div className="space-y-4">
                  <div className="p-3 bg-amber-50 rounded-xl border border-amber-200 text-amber-950">
                    <span className="font-bold block mb-1">Informed Consent Acknowledgement</span>
                    <p className="text-[11px] leading-relaxed">
                      I authorize Dr. Alistair Sterling and designated anesthesiologists at Aura Vanguard Surgical Pavilion to perform the scheduled procedure. The surgical risks, benefits, and alternatives have been explained to me.
                    </p>
                  </div>

                  <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
                    <span className="font-bold text-slate-900 block">NPO &amp; Discharge Escort Policy</span>
                    <p className="text-[11px] text-slate-600">
                      I confirm that I will not consume any food or liquids from midnight prior to my surgery date, and I have arranged for an adult driver ({activeProfile.emergencyContact.name}) to transport me home safely.
                    </p>
                  </div>

                  <div className="flex justify-between pt-3">
                    <button
                      type="button"
                      onClick={() => setFormStep(1)}
                      className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 font-semibold rounded-xl"
                    >
                      Back
                    </button>
                    <button
                      type="button"
                      onClick={() => setFormStep(3)}
                      className="px-5 py-2 bg-teal-600 hover:bg-teal-700 text-white font-bold rounded-xl transition-colors flex items-center gap-1 cursor-pointer"
                    >
                      <span>Next: Digital Signature</span>
                      <ChevronRight className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              )}

              {formStep === 3 && (
                <div className="space-y-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-900 mb-1">
                      Type Your Full Legal Name (Digital Signature):
                    </label>
                    <input
                      type="text"
                      value={signatureText}
                      onChange={(e) => setSignatureText(e.target.value)}
                      placeholder={`e.g. ${activeProfile.firstName} ${activeProfile.lastName}`}
                      className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl font-serif text-sm font-bold text-slate-900 focus:outline-none focus:border-teal-500 focus:bg-white"
                      required
                    />
                    <span className="text-[10px] text-slate-500 block mt-1">
                      By typing your name, you acknowledge this as your binding legal signature under the Uniform Electronic Transactions Act.
                    </span>
                  </div>

                  <label className="flex items-start gap-2.5 p-3 rounded-xl bg-teal-50 border border-teal-200 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={agreedToTerms}
                      onChange={(e) => setAgreedToTerms(e.target.checked)}
                      className="rounded text-teal-600 focus:ring-teal-500 mt-0.5"
                      required
                    />
                    <span className="text-xs text-teal-950 font-medium">
                      I declare under penalty of perjury that the health history provided is accurate and true to the best of my knowledge.
                    </span>
                  </label>

                  <div className="flex justify-between pt-3">
                    <button
                      type="button"
                      onClick={() => setFormStep(2)}
                      className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 font-semibold rounded-xl"
                    >
                      Back
                    </button>
                    <button
                      type="submit"
                      className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl shadow-md transition-colors flex items-center gap-1.5 cursor-pointer"
                    >
                      <CheckCircle2 className="w-4 h-4" />
                      <span>Submit Form to Clinic Chart</span>
                    </button>
                  </div>
                </div>
              )}

            </form>

          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 2: REQUEST NEW APPOINTMENT */}
      {/* ========================================================================= */}
      {isAppointmentRequestModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl border border-slate-200 shadow-2xl max-w-lg w-full overflow-hidden animate-in fade-in zoom-in-95 duration-200">
            
            <div className="p-4 bg-[#1F6E52] text-white flex items-center justify-between">
              <div>
                <span className="text-[10px] font-mono uppercase tracking-wider text-teal-300">Appointment Request Hub</span>
                <h3 className="font-bold text-sm sm:text-base">Request New Encounter</h3>
              </div>
              <button
                onClick={() => setIsAppointmentRequestModalOpen(false)}
                className="p-1 rounded-lg text-slate-300 hover:text-white hover:bg-slate-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleRequestAppointment} className="p-5 space-y-4 text-xs text-slate-800">
              <div>
                <label className="block font-bold text-slate-900 mb-1">Select Physician / Provider</label>
                <select
                  value={reqProvider}
                  onChange={(e) => setReqProvider(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl font-medium focus:outline-none focus:border-teal-500"
                >
                  <option value="Dr. Alistair Sterling, MD">Dr. Alistair Sterling, MD (Plastic &amp; Reconstructive Surgery)</option>
                  <option value="Dr. Julian Mercer, MD">Dr. Julian Mercer, MD (Facial Plastic Surgery)</option>
                  <option value="Dr. Raymond Cruz, MD">Dr. Raymond Cruz, MD (Anesthesiology &amp; Pain Management)</option>
                </select>
              </div>

              <div>
                <label className="block font-bold text-slate-900 mb-1">Encounter Type</label>
                <select
                  value={reqType}
                  onChange={(e) => setReqType(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl font-medium focus:outline-none focus:border-teal-500"
                >
                  <option value="Post-Operative Follow-Up">Post-Operative Follow-Up</option>
                  <option value="Surgical Consultation">New Surgical Consultation</option>
                  <option value="Pre-Op Clearance Check">Pre-Operative Clearance Check</option>
                  <option value="Minor In-Office Procedure">Minor In-Office Procedure</option>
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-900 mb-1">Preferred Date</label>
                  <input
                    type="date"
                    value={reqDate}
                    onChange={(e) => setReqDate(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl font-medium focus:outline-none focus:border-teal-500"
                    required
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-900 mb-1">Time of Day</label>
                  <select
                    value={reqTimeOfDay}
                    onChange={(e) => setReqTimeOfDay(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl font-medium focus:outline-none focus:border-teal-500"
                  >
                    <option value="Morning (8:00 AM - 12:00 PM)">Morning (8:00 AM - 12:00 PM)</option>
                    <option value="Afternoon (1:00 PM - 5:00 PM)">Afternoon (1:00 PM - 5:00 PM)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-900 mb-1">Reason for Visit / Specific Symptoms</label>
                <textarea
                  value={reqReason}
                  onChange={(e) => setReqReason(e.target.value)}
                  rows={3}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl font-medium focus:outline-none focus:border-teal-500"
                  placeholder="Describe your reason for booking..."
                  required
                />
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsAppointmentRequestModalOpen(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 font-semibold rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-teal-600 hover:bg-teal-700 text-white font-bold rounded-xl shadow-xs transition-colors cursor-pointer"
                >
                  Submit Request
                </button>
              </div>
            </form>

          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 3: UPLOAD NEW DOCUMENT (SYNCED TO OI CHART) */}
      {/* ========================================================================= */}
      {isUploadDocumentModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl border border-slate-200 shadow-2xl max-w-lg w-full overflow-hidden animate-in fade-in zoom-in-95 duration-200">
            
            <div className="p-4 bg-[#1F6E52] text-white flex items-center justify-between">
              <div>
                <span className="text-[10px] font-mono uppercase tracking-wider text-teal-300">Office Intelligence Document Sync</span>
                <h3 className="font-bold text-sm sm:text-base">Upload Document or Photo</h3>
              </div>
              <button
                onClick={() => setIsUploadDocumentModalOpen(false)}
                className="p-1 rounded-lg text-slate-300 hover:text-white hover:bg-slate-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleUploadDocument} className="p-5 space-y-4 text-xs text-slate-800">
              <div>
                <label className="block font-bold text-slate-900 mb-1">Document Title</label>
                <input
                  type="text"
                  value={uploadTitle}
                  onChange={(e) => setUploadTitle(e.target.value)}
                  placeholder="e.g. Outside Cardiology Clearance Note or Driver License"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl font-medium focus:outline-none focus:border-teal-500"
                  required
                />
              </div>

              <div>
                <label className="block font-bold text-slate-900 mb-1">Category</label>
                <select
                  value={uploadCategory}
                  onChange={(e) => setUploadCategory(e.target.value as any)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl font-medium focus:outline-none focus:border-teal-500"
                >
                  <option value="Patient Uploads">Patient Upload (ID / Insurance)</option>
                  <option value="Clinical Notes">Outside Clinical Clearance / PCP Letter</option>
                  <option value="Lab Results">Outside Lab Panel / EKG Tracing</option>
                  <option value="Consents">Signed Consent Document</option>
                </select>
              </div>

              {/* Drag and Drop Zone */}
              <div className="border-2 border-dashed border-slate-300 rounded-xl p-6 text-center bg-slate-50 hover:bg-slate-100 transition-colors cursor-pointer">
                <Upload className="w-8 h-8 text-teal-600 mx-auto mb-2" />
                <span className="font-bold text-slate-900 block text-xs">Click to browse or drop file here</span>
                <span className="text-[10px] text-slate-500 block mt-0.5">PDF, PNG, JPG up to 15 MB</span>
                <input
                  type="file"
                  onChange={(e) => {
                    if (e.target.files && e.target.files[0]) {
                      setUploadFileName(e.target.files[0].name);
                      if (!uploadTitle) {
                        setUploadTitle(e.target.files[0].name.replace(/\.[^/.]+$/, ''));
                      }
                    }
                  }}
                  className="hidden"
                  id="portal-file-input"
                />
                <label htmlFor="portal-file-input" className="mt-2 inline-block px-3 py-1 bg-white border border-slate-300 rounded-lg text-xs font-bold text-slate-700 shadow-2xs hover:bg-slate-50 cursor-pointer">
                  Select File
                </label>
                {uploadFileName && (
                  <div className="mt-2 text-xs font-mono text-emerald-700 font-bold">
                    Selected: {uploadFileName}
                  </div>
                )}
              </div>

              <div>
                <label className="block font-bold text-slate-900 mb-1">Notes for Clinical Staff (Optional)</label>
                <textarea
                  value={uploadFileSummary}
                  onChange={(e) => setUploadFileSummary(e.target.value)}
                  rows={2}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl font-medium focus:outline-none focus:border-teal-500"
                  placeholder="Additional context for Dr. Sterling's team..."
                />
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsUploadDocumentModalOpen(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 font-semibold rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl shadow-xs transition-colors cursor-pointer"
                >
                  Upload to Chart
                </button>
              </div>
            </form>

          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 4: PAY BILLING STATEMENT */}
      {/* ========================================================================= */}
      {isPaymentModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl border border-slate-200 shadow-2xl max-w-md w-full overflow-hidden animate-in fade-in zoom-in-95 duration-200">
            
            <div className="p-4 bg-[#1F6E52] text-white flex items-center justify-between">
              <div>
                <span className="text-[10px] font-mono uppercase tracking-wider text-teal-300">Secure Payment Gateway</span>
                <h3 className="font-bold text-sm sm:text-base">Pay Facility Balance</h3>
              </div>
              <button
                onClick={() => setIsPaymentModalOpen(false)}
                className="p-1 rounded-lg text-slate-300 hover:text-white hover:bg-slate-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleProcessPayment} className="p-5 space-y-4 text-xs text-slate-800">
              <div className="bg-teal-50 p-3.5 rounded-xl border border-teal-200 flex items-center justify-between">
                <div>
                  <span className="text-teal-900 font-bold block text-xs">Total Amount Due</span>
                  <span className="text-[10px] text-teal-700">Aura Vanguard Surgical Facility Co-Pay</span>
                </div>
                <span className="text-xl font-bold text-teal-950 font-serif">${outstandingBalance.toFixed(2)}</span>
              </div>

              <div>
                <label className="block font-bold text-slate-900 mb-1">Card Number</label>
                <input
                  type="text"
                  value={cardNumber}
                  onChange={(e) => setCardNumber(e.target.value)}
                  placeholder="4000 1234 5678 9010"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl font-mono text-xs focus:outline-none focus:border-teal-500"
                  required
                />
              </div>

              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="block font-bold text-slate-900 mb-1">Expires</label>
                  <input
                    type="text"
                    value={cardExp}
                    onChange={(e) => setCardExp(e.target.value)}
                    placeholder="MM/YY"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl font-mono text-xs text-center"
                    required
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-900 mb-1">CVV</label>
                  <input
                    type="text"
                    value={cardCvv}
                    onChange={(e) => setCardCvv(e.target.value)}
                    placeholder="123"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl font-mono text-xs text-center"
                    required
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-900 mb-1">ZIP Code</label>
                  <input
                    type="text"
                    value={cardZip}
                    onChange={(e) => setCardZip(e.target.value)}
                    placeholder="90210"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl font-mono text-xs text-center"
                    required
                  />
                </div>
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  disabled={isProcessingPayment}
                  className="w-full py-3 bg-teal-600 hover:bg-teal-700 text-white font-bold text-xs rounded-xl shadow-md transition-colors flex items-center justify-center gap-2 cursor-pointer"
                >
                  {isProcessingPayment ? (
                    <span>Processing Payment...</span>
                  ) : (
                    <>
                      <Lock className="w-4 h-4" />
                      <span>Confirm &amp; Pay ${outstandingBalance.toFixed(2)}</span>
                    </>
                  )}
                </button>
              </div>
            </form>

          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 5: VIEW DOCUMENT PREVIEW */}
      {/* ========================================================================= */}
      {viewingDocument && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl border border-slate-200 shadow-2xl max-w-2xl w-full max-h-[85vh] flex flex-col overflow-hidden animate-in fade-in zoom-in-95 duration-200">
            
            <div className="p-4 bg-[#1F6E52] text-white flex items-center justify-between">
              <div>
                <span className="text-[10px] font-mono uppercase tracking-wider text-teal-300">{viewingDocument.category}</span>
                <h3 className="font-bold text-sm sm:text-base">{viewingDocument.title}</h3>
              </div>
              <button
                onClick={() => setViewingDocument(null)}
                className="p-1 rounded-lg text-slate-300 hover:text-white hover:bg-slate-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 overflow-y-auto space-y-4 text-xs text-slate-800 bg-slate-50/50">
              <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs space-y-3">
                <div className="flex items-center justify-between text-[11px] text-slate-500 border-b border-slate-100 pb-2">
                  <span>File: {viewingDocument.fileName}</span>
                  <span>Uploaded: {viewingDocument.uploadDate}</span>
                </div>
                <div className="text-sm font-bold text-slate-900">Clinical Summary &amp; Index Record:</div>
                <p className="text-slate-700 leading-relaxed bg-slate-50 p-3 rounded-lg border border-slate-200 font-mono text-[11px]">
                  {viewingDocument.summary}
                </p>
              </div>
            </div>

            <div className="p-3 bg-white border-t border-slate-200 flex items-center justify-between">
              <span className="text-xs text-slate-500">Aura Vanguard Vault Encrypted</span>
              <button
                onClick={() => {
                  showToast(`Downloaded ${viewingDocument.fileName}`);
                }}
                className="px-4 py-2 bg-teal-600 hover:bg-teal-700 text-white font-bold text-xs rounded-xl shadow-xs transition-colors flex items-center gap-1.5 cursor-pointer"
              >
                <Download className="w-4 h-4" />
                <span>Download Document</span>
              </button>
            </div>

          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 6: REFILL PRESCRIPTION MODAL */}
      {/* ========================================================================= */}
      {isRefillModalOpen && selectedPrescriptionForRefill && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl border border-slate-200 shadow-2xl max-w-md w-full overflow-hidden animate-in fade-in zoom-in-95 duration-200">
            
            <div className="p-4 bg-[#1F6E52] text-white flex items-center justify-between">
              <div>
                <span className="text-[10px] font-mono uppercase tracking-wider text-teal-300">Prescription Refill Hub</span>
                <h3 className="font-bold text-sm sm:text-base">Request Medication Refill</h3>
              </div>
              <button
                onClick={() => setIsRefillModalOpen(false)}
                className="p-1 rounded-lg text-slate-300 hover:text-white hover:bg-slate-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-5 space-y-4 text-xs text-slate-800">
              <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200 space-y-1">
                <span className="font-bold text-slate-900 text-sm block">{selectedPrescriptionForRefill.medicationName}</span>
                <span className="text-teal-700 font-semibold block">{selectedPrescriptionForRefill.dosage}</span>
                <p className="text-slate-600 text-[11px] pt-1">{selectedPrescriptionForRefill.instructions}</p>
              </div>

              <div className="text-[11px] text-slate-600 bg-emerald-50 p-3 rounded-xl border border-emerald-200">
                <span className="font-bold text-emerald-900 block mb-0.5">Fulfillment Pharmacy:</span>
                <div>{selectedPrescriptionForRefill.pharmacy}</div>
                <div className="text-slate-500 mt-1">This request will be routed to {selectedPrescriptionForRefill.prescribedBy} for e-prescribing review.</div>
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsRefillModalOpen(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 font-semibold rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleConfirmRefill}
                  className="px-5 py-2 bg-teal-600 hover:bg-teal-700 text-white font-bold rounded-xl shadow-xs transition-colors cursor-pointer"
                >
                  Confirm &amp; Send Request
                </button>
              </div>
            </div>

          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 7: VIEW APPOINTMENT PRE-OP CHECKLIST */}
      {/* ========================================================================= */}
      {viewingAppointment && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl border border-slate-200 shadow-2xl max-w-lg w-full overflow-hidden animate-in fade-in zoom-in-95 duration-200">
            
            <div className="p-4 bg-[#1F6E52] text-white flex items-center justify-between">
              <div>
                <span className="text-[10px] font-mono uppercase tracking-wider text-teal-300">Encounter Preparation</span>
                <h3 className="font-bold text-sm sm:text-base">{viewingAppointment.title}</h3>
              </div>
              <button
                onClick={() => setViewingAppointment(null)}
                className="p-1 rounded-lg text-slate-300 hover:text-white hover:bg-slate-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-5 space-y-4 text-xs text-slate-800">
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-1 text-slate-700">
                <div className="font-bold text-slate-900">{viewingAppointment.date} at {viewingAppointment.time}</div>
                <div>Surgeon: <span className="font-semibold text-slate-900">{viewingAppointment.doctor}</span></div>
                <div>Location: {viewingAppointment.location}</div>
              </div>

              {viewingAppointment.checklist && (
                <div className="space-y-2">
                  <span className="font-bold text-slate-900 block">Pre-Encounter Preparation Checklist:</span>
                  <div className="space-y-1.5">
                    {viewingAppointment.checklist.map((item, i) => (
                      <div key={i} className="flex items-center gap-2 p-2 rounded-lg bg-slate-50 border border-slate-200">
                        {item.done ? (
                          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                        ) : (
                          <div className="w-4 h-4 rounded-full border-2 border-slate-400 shrink-0" />
                        )}
                        <span className={`text-xs ${item.done ? 'text-slate-800 font-semibold' : 'text-slate-600'}`}>
                          {item.text}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <div className="pt-2 flex justify-end">
                <button
                  type="button"
                  onClick={() => setViewingAppointment(null)}
                  className="px-5 py-2 bg-teal-600 hover:bg-teal-700 text-white font-bold rounded-xl shadow-xs transition-colors cursor-pointer"
                >
                  Done
                </button>
              </div>
            </div>

          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 8: FULL-SCREEN HTML INTAKE FORM & ELECTRONIC SIGNATURE ATTESTATION   */}
      {/* ========================================================================= */}
      {viewingHtmlForm && (
        <div className="fixed inset-0 z-[99999] bg-stone-100 flex flex-col w-screen h-screen overflow-y-auto no-scrollbar [scrollbar-width:none] [-ms-overflow-style:none] [&::-webkit-scrollbar]:hidden animate-in fade-in duration-150">
          {/* Top Control Bar with Close & Status */}
          <div className="sticky top-0 z-[100000] bg-slate-900/95 border-b border-slate-700 px-4 sm:px-6 py-3 flex items-center justify-between backdrop-blur-md shadow-lg text-white">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-xl bg-teal-500/20 border border-teal-500/40 text-teal-300">
                <FileText className="w-4 h-4" />
              </div>
              <div>
                <h3 className="font-bold text-xs sm:text-sm text-white flex items-center gap-2">
                  <span>{viewingHtmlForm.title}</span>
                  <span
                    className={`text-[10px] px-2 py-0.5 rounded-full border font-semibold ${
                      viewingHtmlForm.status === 'Completed in Portal'
                        ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                        : 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                    }`}
                  >
                    {viewingHtmlForm.status === 'Completed in Portal' ? '✓ Completed & Signed' : 'Action Required'}
                  </span>
                </h3>
                <p className="text-[11px] text-slate-400 font-mono hidden sm:block">{viewingHtmlForm.fileName}</p>
              </div>
            </div>

            <button
              type="button"
              onClick={() => setViewingHtmlForm(null)}
              className="px-3.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-xl text-xs font-bold transition-colors flex items-center gap-1.5 cursor-pointer border border-slate-700 shadow-xs group"
            >
              <X className="w-4 h-4 text-slate-400 group-hover:text-white" />
              <span>Close Form</span>
            </button>
          </div>

          {/* Blank Page Native Form Container & Integrated Signature Section (Full Screen No Scrollbars) */}
          <div className="w-full flex-1 bg-stone-100 p-2 sm:p-6 flex flex-col items-center gap-6 min-h-screen overflow-x-hidden no-scrollbar">
            <div className="w-full max-w-4xl bg-white rounded-2xl shadow-xl border border-stone-200 p-3 sm:p-6 my-2 relative overflow-x-hidden">
              <style>{`
                * { scrollbar-width: none !important; -ms-overflow-style: none !important; }
                *::-webkit-scrollbar { display: none !important; width: 0 !important; height: 0 !important; }
                .page { max-width: 100% !important; margin: 0 auto !important; box-shadow: none !important; border: none !important; padding: 12px 16px !important; }
                .grid { max-width: 100% !important; }
                table { max-width: 100% !important; width: 100% !important; }
              `}</style>
              <div dangerouslySetInnerHTML={{ __html: getPrefilledIntakeHtml(viewingHtmlForm.htmlTemplate, activeProfile) }} />

              {/* Patient Electronic Signature & Legal Attestation Section at the bottom of the single form page */}
              <div className="mt-8 pt-6 border-t-2 border-slate-200/90">
                {viewingHtmlForm.status === 'Completed in Portal' ? (
                  <div className="p-6 bg-emerald-50/80 border-2 border-emerald-400/60 rounded-2xl space-y-3.5 text-xs text-emerald-950 shadow-xs">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2 text-emerald-900 font-bold text-sm">
                        <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                        <span>Patient Electronic Signature &amp; Legal Attestation</span>
                      </div>
                      <span className="bg-emerald-200/80 text-emerald-900 font-bold px-2.5 py-0.5 rounded-full text-[10.5px]">
                        Completed &amp; Verified
                      </span>
                    </div>

                    <p className="leading-relaxed text-emerald-900">
                      This clinical intake questionnaire has been digitally completed, attested, and legally executed by the patient. A verified PDF copy is securely filed in your Office Intelligence medical record.
                    </p>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 border-t border-emerald-200/80 font-mono text-[11px]">
                      <div>
                        <span className="text-emerald-700 block font-sans font-bold text-[10px] uppercase">Legally Signed By</span>
                        <span className="font-bold text-emerald-950">{viewingHtmlForm.signedBy || `${activeProfile.firstName} ${activeProfile.lastName}`}</span>
                      </div>
                      <div>
                        <span className="text-emerald-700 block font-sans font-bold text-[10px] uppercase">Execution Timestamp</span>
                        <span className="font-bold text-emerald-950">{viewingHtmlForm.completedDate || 'Aug 16, 2026'} · Verified</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 pt-1 text-[10.5px] text-emerald-800 font-mono">
                      <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
                      <span>Audit Trail: Cryptographic SHA-256 Signature Sealed into EHR Chart</span>
                    </div>
                  </div>
                ) : (
                  <div className="p-6 bg-slate-50 border-2 border-teal-500/40 rounded-2xl space-y-4 text-xs text-slate-900 shadow-md">
                    <div className="flex items-center gap-2 text-teal-900 font-bold text-sm">
                      <PenTool className="w-4 h-4 text-teal-600" />
                      <span>Patient Electronic Signature &amp; Legal Attestation</span>
                    </div>

                    <div className="p-3.5 bg-teal-50/70 border border-teal-200 rounded-xl text-xs text-teal-950 space-y-2">
                      <p className="leading-relaxed">
                        By typing my legal name and submitting this document, I certify that all information provided is accurate and complete to the best of my knowledge, and I agree to provide consent for clinical procedures and medical record processing.
                      </p>
                      <div className="flex items-center gap-2 pt-1 font-mono text-[11px] text-teal-800">
                        <Lock className="w-3.5 h-3.5 text-teal-600" />
                        <span>IP Address &amp; Time: {new Date().toLocaleDateString()} {new Date().toLocaleTimeString()} (Logged)</span>
                      </div>
                    </div>

                    <div className="space-y-3 pt-1">
                      <div>
                        <label className="block text-xs font-bold text-slate-800 mb-1.5">
                          Type Your Full Legal Name (Electronic Signature)
                        </label>
                        <input
                          type="text"
                          value={fillSignature}
                          onChange={(e) => setFillSignature(e.target.value)}
                          placeholder="First Name Last Name"
                          className="w-full px-4 py-2.5 bg-white border border-slate-300 rounded-xl text-sm font-serif font-bold text-slate-900 focus:outline-none focus:border-teal-500 transition-all shadow-2xs"
                        />
                      </div>

                      <label className="flex items-start gap-2.5 cursor-pointer pt-1">
                        <input
                          type="checkbox"
                          checked={fillAgreed}
                          onChange={(e) => setFillAgreed(e.target.checked)}
                          className="w-4 h-4 rounded border-slate-300 text-teal-600 focus:ring-teal-500 mt-0.5"
                        />
                        <span className="text-xs text-slate-700 leading-relaxed font-medium">
                          I acknowledge that my electronic signature constitutes a legally binding signature identical to an ink handwritten signature on paper.
                        </span>
                      </label>
                    </div>

                    <div className="pt-3 border-t border-slate-200 flex items-center justify-between">
                      <button
                        type="button"
                        onClick={() => setViewingHtmlForm(null)}
                        className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-xl text-xs font-bold transition-colors cursor-pointer"
                      >
                        Cancel
                      </button>

                      <button
                        type="button"
                        onClick={() => handleCompleteHtmlForm(viewingHtmlForm)}
                        disabled={!fillSignature.trim() || !fillAgreed}
                        className="px-6 py-2.5 bg-teal-600 hover:bg-teal-700 disabled:bg-slate-300 disabled:cursor-not-allowed text-white rounded-xl text-xs font-bold shadow-md transition-all flex items-center gap-2 cursor-pointer"
                      >
                        <CheckCircle2 className="w-4 h-4" />
                        <span>Submit &amp; Sign to Chart</span>
                      </button>
                    </div>
                  </div>
                )}
              </div>

            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 10: REQUEST NEW PRESCRIPTION MODAL */}
      {/* ========================================================================= */}
      {isNewPrescriptionModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl border border-slate-200 shadow-2xl max-w-lg w-full overflow-hidden animate-in fade-in zoom-in-95 duration-200">
            
            <div className="p-4 bg-[#1F6E52] text-white flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-teal-500/20 rounded-xl text-teal-300 border border-teal-500/30">
                  <Pill className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-bold text-sm sm:text-base">Request New Prescription</h3>
                  <p className="text-[11px] text-slate-300">Submit medication request directly to Dr. Sterling</p>
                </div>
              </div>
              <button
                onClick={() => setIsNewPrescriptionModalOpen(false)}
                className="p-1 rounded-lg text-slate-300 hover:text-white hover:bg-slate-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleRequestNewPrescription} className="p-6 space-y-4 text-xs text-slate-800">
              <div>
                <label className="block font-bold text-slate-900 mb-1">Medication Name &amp; Strength</label>
                <input
                  type="text"
                  value={newRxName}
                  onChange={(e) => setNewRxName(e.target.value)}
                  placeholder="e.g., Ciprofloxacin 500mg, Ondansetron 4mg"
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs text-slate-900 focus:outline-none focus:border-teal-500 focus:bg-white"
                  required
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-900 mb-1">Dosage / Form</label>
                  <input
                    type="text"
                    value={newRxDosage}
                    onChange={(e) => setNewRxDosage(e.target.value)}
                    placeholder="e.g., 1 tablet orally twice daily"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs text-slate-900 focus:outline-none focus:border-teal-500 focus:bg-white"
                    required
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-900 mb-1">Reason / Indication</label>
                  <input
                    type="text"
                    value={newRxReason}
                    onChange={(e) => setNewRxReason(e.target.value)}
                    placeholder="e.g., Post-op nausea prophylaxis"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs text-slate-900 focus:outline-none focus:border-teal-500 focus:bg-white"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-900 mb-1">Preferred Pharmacy</label>
                <select
                  value={newRxPharmacy}
                  onChange={(e) => setNewRxPharmacy(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs text-slate-900 focus:outline-none focus:border-teal-500 focus:bg-white cursor-pointer"
                >
                  <option value={activeProfile.preferredPharmacy.name}>{activeProfile.preferredPharmacy.name} ({activeProfile.preferredPharmacy.address})</option>
                  <option value="CVS Pharmacy #9412 - 9045 Wilshire Blvd, Beverly Hills, CA">CVS Pharmacy #9412 - 9045 Wilshire Blvd, Beverly Hills, CA</option>
                  <option value="Walgreens Specialty Pharmacy - 8490 Santa Monica Blvd, West Hollywood, CA">Walgreens Specialty Pharmacy - 8490 Santa Monica Blvd, West Hollywood, CA</option>
                </select>
              </div>

              <div>
                <label className="block font-bold text-slate-900 mb-1">Clinical Notes for Provider (Optional)</label>
                <textarea
                  value={newRxNotes}
                  onChange={(e) => setNewRxNotes(e.target.value)}
                  placeholder="Describe any symptoms, previous tolerability, or notes for Dr. Sterling..."
                  rows={3}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs text-slate-900 focus:outline-none focus:border-teal-500 focus:bg-white"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2.5 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setIsNewPrescriptionModalOpen(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 font-semibold rounded-xl text-xs"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-teal-600 hover:bg-teal-700 text-white font-bold rounded-xl shadow-xs transition-colors cursor-pointer text-xs flex items-center gap-1.5"
                >
                  <Pill className="w-3.5 h-3.5" />
                  <span>Transmit Request</span>
                </button>
              </div>
            </form>

          </div>
        </div>
      )}

      {/* Mobile Primary Bottom Navigation Bar (Visible on mobile/tablet < sm) */}
      <nav className="fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-slate-200 sm:hidden px-2 py-1 flex items-center justify-around shadow-lg">
        <button
          onClick={() => setActiveTab('overview')}
          className={`flex flex-col items-center justify-center py-1 px-2 rounded-xl transition-all cursor-pointer ${
            activeTab === 'overview' ? 'text-teal-700 font-bold' : 'text-slate-500 hover:text-slate-900'
          }`}
        >
          <Activity className={`w-5 h-5 ${activeTab === 'overview' ? 'text-teal-700' : 'text-slate-500'}`} />
          <span className="text-[10px] mt-0.5">Home</span>
        </button>

        <button
          onClick={() => setActiveTab('appointments')}
          className={`flex flex-col items-center justify-center py-1 px-2 rounded-xl transition-all cursor-pointer relative ${
            activeTab === 'appointments' ? 'text-teal-700 font-bold' : 'text-slate-500 hover:text-slate-900'
          }`}
        >
          <Calendar className={`w-5 h-5 ${activeTab === 'appointments' ? 'text-teal-700' : 'text-slate-500'}`} />
          {filteredAppointments.length > 0 && (
            <span className="absolute top-0.5 right-2 w-2 h-2 bg-emerald-600 rounded-full" />
          )}
          <span className="text-[10px] mt-0.5">Appts</span>
        </button>

        <button
          onClick={() => setActiveTab('forms')}
          className={`flex flex-col items-center justify-center py-1 px-2 rounded-xl transition-all cursor-pointer relative ${
            activeTab === 'forms' ? 'text-teal-700 font-bold' : 'text-slate-500 hover:text-slate-900'
          }`}
        >
          <FileText className={`w-5 h-5 ${activeTab === 'forms' ? 'text-teal-700' : 'text-slate-500'}`} />
          {pendingFormsCount > 0 && (
            <span className="absolute top-0.5 right-2 w-2 h-2 bg-amber-500 rounded-full" />
          )}
          <span className="text-[10px] mt-0.5">Forms</span>
        </button>

        <button
          onClick={() => setActiveTab('messages')}
          className={`flex flex-col items-center justify-center py-1 px-2 rounded-xl transition-all cursor-pointer relative ${
            activeTab === 'messages' ? 'text-teal-700 font-bold' : 'text-slate-500 hover:text-slate-900'
          }`}
        >
          <MessageSquare className={`w-5 h-5 ${activeTab === 'messages' ? 'text-teal-700' : 'text-slate-500'}`} />
          {filteredMessages.length > 0 && (
            <span className="absolute top-0.5 right-2 w-2 h-2 bg-purple-600 rounded-full" />
          )}
          <span className="text-[10px] mt-0.5">Messages</span>
        </button>

        <button
          onClick={() => {
            // Cycle or toggle between documents / billing / rx
            if (activeTab === 'documents') setActiveTab('billing');
            else if (activeTab === 'billing') setActiveTab('prescriptions');
            else setActiveTab('documents');
          }}
          className={`flex flex-col items-center justify-center py-1 px-2 rounded-xl transition-all cursor-pointer ${
            ['documents', 'prescriptions', 'billing'].includes(activeTab) ? 'text-teal-700 font-bold' : 'text-slate-500 hover:text-slate-900'
          }`}
        >
          <Layers className={`w-5 h-5 ${['documents', 'prescriptions', 'billing'].includes(activeTab) ? 'text-teal-700' : 'text-slate-500'}`} />
          <span className="text-[10px] mt-0.5">
            {activeTab === 'documents' ? 'Docs' : activeTab === 'prescriptions' ? 'Rx' : activeTab === 'billing' ? 'Billing' : 'More'}
          </span>
        </button>
      </nav>

      {/* Bottom Footer */}
      <footer className="bg-white border-t border-slate-200 py-4 px-6 text-center text-xs text-slate-500">
        © 2026 Aura Vanguard Surgical &amp; Aesthetic Pavilion. Powered by Office Intelligence Medical OS.
      </footer>

    </div>
  );
};
