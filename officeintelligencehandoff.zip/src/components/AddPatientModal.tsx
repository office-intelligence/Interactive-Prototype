import React, { useState } from 'react';
import { PatientCase, PAYMENT_TYPE_OPTIONS } from '../types';
import { X, UserPlus, Sparkles, User, Calendar, ShieldAlert, Stethoscope, Clock, MapPin, Phone, CreditCard } from 'lucide-react';
import { generateSampleDriverLicense, generateSampleInsuranceFront, generateSampleInsuranceBack } from '../utils/cardTemplates';

interface AddPatientModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddPatient: (newPatient: PatientCase) => void;
}

export const AddPatientModal: React.FC<AddPatientModalProps> = ({
  isOpen,
  onClose,
  onAddPatient,
}) => {
  const [name, setName] = useState('');
  const [patientId, setPatientId] = useState(
    `${Math.floor(110000 + Math.random() * 80000)}`
  );
  const [age, setAge] = useState(38);
  const [gender, setGender] = useState<'Female' | 'Male' | 'Other'>('Female');
  const [dob, setDob] = useState('08/14/1988');
  const [phone, setPhone] = useState('(310) 555-0199');
  const [procedure, setProcedure] = useState('Primary Open Rhinoplasty & Septoplasty');
  const [surgeon, setSurgeon] = useState('Dr. Alistair Sterling, MD');
  const [anesthesiologist, setAnesthesiologist] = useState('Raymond Cruz, MD');
  const [room, setRoom] = useState<'OR 1' | 'OR 2' | 'Minor Proc Bay' | 'PACU Bay 1' | 'PACU Bay 2'>('OR 1');
  const [scheduledTime, setScheduledTime] = useState('11:15 AM');
  const [allergiesText, setAllergiesText] = useState('Latex, Codeine');
  const [paymentType, setPaymentType] = useState<string>('Private Insurance');
  const [notes, setNotes] = useState('Patient scheduled for primary aesthetic & functional nasal surgery. Pre-op labs cleared.');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    const allergies = allergiesText
      .split(',')
      .map((a) => a.trim())
      .filter(Boolean);

    const newPatient: PatientCase = {
      id: `case-${Date.now()}`,
      patientId: patientId || `${Math.floor(100000 + Math.random() * 900000)}`,
      name: name.trim(),
      age: Number(age) || 35,
      gender,
      dob,
      phone,
      scheduledTime,
      estimatedDurationMins: 120,
      room,
      surgeon,
      anesthesiologist,
      procedure,
      aiSummary: `${name} is a ${age}-year-old ${gender.toLowerCase()} scheduled for ${procedure} with ${surgeon}. All electronic pre-op forms, consent, and safety checklists are ready for clinical review.`,
      readinessScore: 98,
      readinessLevel: 'CLEARED',
      allergies: allergies.length > 0 ? allergies : ['None known'],
      labs: [
        { name: 'CBC', value: '13.8 g/dL', status: 'normal' },
        { name: 'BMP', value: 'Normal', status: 'normal' },
        { name: 'PT/INR', value: '1.0', status: 'normal' },
        { name: 'EKG', value: 'Normal Sinus Rhythm', status: 'normal' },
      ],
      stage: 'CHECK_IN',
      preOpBay: 'Bay 1',
      arrivalStatus: 'ARRIVED',
      arrivalTime: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      bottlenecks: [],
      actionItems: [
        { id: `act-${Date.now()}-1`, text: 'Verify surgical site marking & pre-op photo signoff', type: 'CONSENT', done: false, urgent: false },
        { id: `act-${Date.now()}-2`, text: 'Review Electronic Clinical Forms packet (9 Forms)', type: 'ANESTHESIA', done: false },
      ],
      notes,
      paymentType,
      idCardUrl: generateSampleDriverLicense(name.toUpperCase(), dob, `CA${patientId}`, 'BEVERLY HILLS, CA'),
      insuranceCardFrontUrl: generateSampleInsuranceFront(name.toUpperCase(), 'Anthem Blue Cross PPO', `ANT-${patientId}`, 'GRP-77210'),
      insuranceCardBackUrl: generateSampleInsuranceBack('Anthem Blue Cross PPO', '1-888-555-0199'),
    };

    onAddPatient(newPatient);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto animate-in fade-in duration-200">
      <div className="bg-white w-full max-w-2xl rounded-3xl shadow-2xl border border-stone-200 overflow-hidden my-8">
        
        {/* Modal Header */}
        <div className="bg-emerald-900 text-white px-6 py-4 flex items-center justify-between border-b border-emerald-800">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-emerald-600 flex items-center justify-center text-white">
              <UserPlus className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white tracking-tight">Add New Patient Record</h2>
              <p className="text-xs text-emerald-200">Create a new surgical patient chart & initialize electronic clinical forms</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl bg-emerald-800 hover:bg-emerald-700 text-emerald-200 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-5">
          <div className="p-3 bg-indigo-50/70 border border-indigo-200/80 rounded-2xl flex items-center gap-3 text-xs text-indigo-950">
            <Sparkles className="w-4 h-4 text-indigo-600 shrink-0" />
            <span>
              Creating this patient will automatically assemble all <strong>9 Electronic Clinical Forms</strong> (H&P, Nursing Pre-Op, Surgical Consent, Anesthesia Record, Post-Op Orders, etc.).
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Name */}
            <div>
              <label className="block text-xs font-bold text-stone-700 mb-1">
                Patient Full Name <span className="text-red-500">*</span>
              </label>
              <div className="relative">
                <User className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  required
                  placeholder="e.g. Elena Rostova"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 bg-stone-50 border border-stone-300 rounded-xl text-xs font-bold text-stone-900 focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                />
              </div>
            </div>

            {/* MRN / Patient ID */}
            <div>
              <label className="block text-xs font-bold text-stone-700 mb-1">
                Medical Record Number (MRN)
              </label>
              <input
                type="text"
                value={patientId}
                onChange={(e) => setPatientId(e.target.value)}
                className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-xl text-xs font-mono font-bold text-stone-900 focus:ring-2 focus:ring-indigo-500 focus:outline-none"
              />
            </div>

            {/* Age & Gender */}
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">Age</label>
                <input
                  type="number"
                  min="1"
                  max="110"
                  value={age}
                  onChange={(e) => setAge(Number(e.target.value))}
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-xl text-xs font-bold text-stone-900 focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">Gender</label>
                <select
                  value={gender}
                  onChange={(e) => setGender(e.target.value as 'Female' | 'Male' | 'Other')}
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-xl text-xs font-bold text-stone-900 focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                >
                  <option value="Female">Female</option>
                  <option value="Male">Male</option>
                  <option value="Other">Other</option>
                </select>
              </div>
            </div>

            {/* DOB & Phone */}
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">DOB</label>
                <input
                  type="text"
                  placeholder="MM/DD/YYYY"
                  value={dob}
                  onChange={(e) => setDob(e.target.value)}
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-xl text-xs font-bold text-stone-900 focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">Phone</label>
                <input
                  type="text"
                  placeholder="(310) 000-0000"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-xl text-xs font-bold text-stone-900 focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                />
              </div>
            </div>

            {/* Procedure */}
            <div className="md:col-span-2">
              <label className="block text-xs font-bold text-stone-700 mb-1">
                Surgical Procedure Name <span className="text-red-500">*</span>
              </label>
              <div className="relative">
                <Stethoscope className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  required
                  placeholder="e.g. Primary Rhinoplasty & Septoplasty"
                  value={procedure}
                  onChange={(e) => setProcedure(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 bg-stone-50 border border-stone-300 rounded-xl text-xs font-bold text-stone-900 focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                />
              </div>
            </div>

            {/* Surgeon & Anesthesiologist */}
            <div>
              <label className="block text-xs font-bold text-stone-700 mb-1">Attending Surgeon</label>
              <input
                type="text"
                value={surgeon}
                onChange={(e) => setSurgeon(e.target.value)}
                className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-xl text-xs font-bold text-stone-900 focus:ring-2 focus:ring-indigo-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-stone-700 mb-1">Anesthesiologist</label>
              <input
                type="text"
                value={anesthesiologist}
                onChange={(e) => setAnesthesiologist(e.target.value)}
                className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-xl text-xs font-bold text-stone-900 focus:ring-2 focus:ring-indigo-500 focus:outline-none"
              />
            </div>

            {/* Room & Scheduled Time */}
            <div>
              <label className="block text-xs font-bold text-stone-700 mb-1">Assigned OR / Bay</label>
              <select
                value={room}
                onChange={(e) => setRoom(e.target.value as any)}
                className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-xl text-xs font-bold text-stone-900 focus:ring-2 focus:ring-indigo-500 focus:outline-none"
              >
                <option value="OR 1">OR 1 (Main Operating Suite)</option>
                <option value="OR 2">OR 2 (Aesthetic Suite)</option>
                <option value="Minor Proc Bay">Minor Procedure Bay</option>
                <option value="PACU Bay 1">PACU Bay 1</option>
                <option value="PACU Bay 2">PACU Bay 2</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-stone-700 mb-1">Scheduled Start Time</label>
              <input
                type="text"
                value={scheduledTime}
                onChange={(e) => setScheduledTime(e.target.value)}
                className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-xl text-xs font-bold text-stone-900 focus:ring-2 focus:ring-indigo-500 focus:outline-none"
              />
            </div>

            {/* Payment Type */}
            <div className="md:col-span-2">
              <label className="block text-xs font-bold text-stone-700 mb-1 flex items-center gap-1">
                <CreditCard className="w-3.5 h-3.5 text-indigo-600" />
                <span>Payment Type</span>
              </label>
              <select
                value={paymentType}
                onChange={(e) => setPaymentType(e.target.value)}
                className="w-full px-3 py-2 bg-indigo-50/50 border border-indigo-200 rounded-xl text-xs font-bold text-stone-900 focus:ring-2 focus:ring-indigo-500 focus:outline-none cursor-pointer"
              >
                {PAYMENT_TYPE_OPTIONS.map((opt) => (
                  <option key={opt} value={opt}>
                    {opt}
                  </option>
                ))}
              </select>
            </div>

            {/* Allergies */}
            <div className="md:col-span-2">
              <label className="block text-xs font-bold text-stone-700 mb-1 flex items-center gap-1">
                <ShieldAlert className="w-3.5 h-3.5 text-amber-600" />
                <span>Documented Allergies (Comma-separated)</span>
              </label>
              <input
                type="text"
                placeholder="e.g. Latex, Penicillin, Codeine"
                value={allergiesText}
                onChange={(e) => setAllergiesText(e.target.value)}
                className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-xl text-xs font-bold text-stone-900 focus:ring-2 focus:ring-indigo-500 focus:outline-none"
              />
            </div>
          </div>

          {/* Action Buttons */}
          <div className="pt-3 border-t border-stone-200 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 text-xs font-bold rounded-xl transition-colors cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-xl flex items-center gap-2 shadow-md transition-colors cursor-pointer"
            >
              <UserPlus className="w-4 h-4" />
              <span>Create Patient Chart & Generate 9 Forms</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
