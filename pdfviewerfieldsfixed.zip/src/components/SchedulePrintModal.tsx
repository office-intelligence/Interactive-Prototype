import React, { useState } from 'react';
import { 
  Printer, 
  X, 
  Download, 
  Calendar, 
  Clock, 
  User, 
  Phone, 
  Stethoscope, 
  Building2, 
  ShieldCheck, 
  CheckCircle2, 
  FileText, 
  Layers,
  ChevronDown,
  Activity,
  AlertCircle
} from 'lucide-react';
import { AppointmentItem } from './ScheduleFullView';
import { PracticeConfig } from '../types';

interface SchedulePrintModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialViewMode: 'DAY' | 'WK';
  selectedDayIndex: number;
  appointmentsList: AppointmentItem[];
  daysOfWeek: { label: string; dayName: string; date: string; isToday: boolean; fullDateStr: string; dayNum: number }[];
  rooms: string[];
  practiceConfig?: PracticeConfig;
  onShowToast?: (msg: string) => void;
}

export const SchedulePrintModal: React.FC<SchedulePrintModalProps> = ({
  isOpen,
  onClose,
  initialViewMode = 'DAY',
  selectedDayIndex = 0,
  appointmentsList = [],
  daysOfWeek = [],
  rooms = ['OR#1', 'OR#2', 'OR#3'],
  practiceConfig,
  onShowToast
}) => {
  const [printScope, setPrintScope] = useState<'DAY' | 'WK'>(initialViewMode);
  const [selectedDayIdx, setSelectedDayIdx] = useState<number>(selectedDayIndex);
  const [selectedRoomFilter, setSelectedRoomFilter] = useState<string>('ALL');

  if (!isOpen) return null;

  const practiceName = practiceConfig?.practiceName || 'Aura Vanguard Surgical & Aesthetic Pavilion';
  const practicePhone = practiceConfig?.phone || '(310) 555-0100';
  const practiceAddress = practiceConfig?.city && practiceConfig?.state 
    ? `435 N Bedford Dr, Suite 400, ${practiceConfig.city}, ${practiceConfig.state}` 
    : '435 N Bedford Dr, Suite 400, Beverly Hills, CA 90210';

  const currentDayInfo = daysOfWeek[selectedDayIdx] || daysOfWeek[0] || {
    label: 'Mon, 07/13/26',
    dayName: 'Monday',
    date: '07/13/26',
    fullDateStr: 'Monday, July 13, 2026',
    dayNum: 13
  };

  // Filter appointments according to active scope (Day vs Week) and room
  const scopeAppointments = printScope === 'DAY'
    ? appointmentsList.filter((a) => a.dayIndex === selectedDayIdx)
    : appointmentsList;

  const filteredAppointments = selectedRoomFilter === 'ALL'
    ? scopeAppointments
    : scopeAppointments.filter((a) => a.room === selectedRoomFilter);

  // Group appointments by Room
  const appointmentsByRoom: { [room: string]: AppointmentItem[] } = {};
  const allActiveRooms = selectedRoomFilter === 'ALL' ? rooms : [selectedRoomFilter];

  allActiveRooms.forEach((r) => {
    appointmentsByRoom[r] = filteredAppointments
      .filter((a) => a.room === r)
      .sort((a, b) => {
        if (printScope === 'WK' && a.dayIndex !== b.dayIndex) {
          return a.dayIndex - b.dayIndex;
        }
        return a.startHour - b.startHour;
      });
  });

  // Calculate statistics
  const totalCases = filteredAppointments.filter((a) => !a.isBlock).length;
  const totalHours = filteredAppointments.reduce((acc, curr) => acc + (curr.durationHours || 1), 0);
  const distinctSurgeons = Array.from(new Set(filteredAppointments.map((a) => a.surgeon).filter(Boolean)));

  const handlePrint = () => {
    window.print();
    if (onShowToast) {
      onShowToast(`Sent ${printScope === 'DAY' ? 'Daily' : 'Weekly'} Schedule roster to printer.`);
    }
  };

  const handleDownloadReport = () => {
    const docTitle = printScope === 'DAY' 
      ? `Operating-Schedule-Day-${currentDayInfo.dayName}-${currentDayInfo.date.replace(/\//g, '-')}`
      : `Operating-Schedule-Master-Week-July-13-19-2026`;

    const printableElement = document.getElementById('printable-schedule-document');
    if (!printableElement) return;

    const htmlContent = `
      <!DOCTYPE html>
      <html>
      <head>
        <title>${docTitle}</title>
        <meta charset="utf-8" />
        <style>
          body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; color: #1e293b; margin: 20px; line-height: 1.4; }
          .header { border-bottom: 2px solid #0f172a; padding-bottom: 12px; margin-bottom: 16px; }
          .title { font-size: 18px; font-weight: bold; color: #0f172a; text-transform: uppercase; }
          .subtitle { font-size: 13px; color: #475569; margin-top: 4px; }
          .meta-bar { display: flex; justify-content: space-between; background: #f1f5f9; padding: 8px 12px; border-radius: 6px; font-size: 11px; font-weight: bold; margin-bottom: 16px; }
          .room-section { margin-bottom: 24px; page-break-inside: avoid; }
          .room-title { background: #1e293b; color: white; padding: 6px 10px; font-size: 13px; font-weight: bold; border-radius: 4px; margin-bottom: 8px; }
          table { width: 100%; border-collapse: collapse; font-size: 11px; }
          th { background: #e2e8f0; text-align: left; padding: 6px 8px; font-weight: bold; border: 1px solid #cbd5e1; }
          td { padding: 6px 8px; border: 1px solid #e2e8f0; vertical-align: top; }
          tr:nth-child(even) { background-color: #f8fafc; }
          .patient-name { font-weight: bold; color: #0f172a; font-size: 12px; }
          .phone { color: #0369a1; font-weight: 600; }
          .procedure { font-weight: 600; color: #5B6B60; }
          .provider { color: #0f172a; font-weight: 600; }
          .footer { margin-top: 30px; border-top: 1px solid #cbd5e1; padding-top: 12px; font-size: 10px; color: #64748b; display: flex; justify-content: space-between; }
        </style>
      </head>
      <body>
        ${printableElement.innerHTML}
      </body>
      </html>
    `;

    const blob = new Blob([htmlContent], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${docTitle}.html`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);

    if (onShowToast) {
      onShowToast(`Downloaded schedule report (${docTitle}.html). Ready to print/save as PDF.`);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-stone-950/80 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4 overflow-y-auto print:p-0 print:bg-white animate-in fade-in duration-200">
      
      {/* Print Specific CSS to ensure clean paper output */}
      <style>{`
        @media print {
          body * {
            visibility: hidden !important;
          }
          #printable-schedule-document, #printable-schedule-document * {
            visibility: visible !important;
          }
          #printable-schedule-document {
            position: absolute !important;
            left: 0 !important;
            top: 0 !important;
            width: 100% !important;
            margin: 0 !important;
            padding: 12px !important;
            background: white !important;
            color: black !important;
          }
          .no-print {
            display: none !important;
          }
          @page {
            size: letter portrait;
            margin: 0.4in;
          }
        }
      `}</style>

      {/* Main Modal Card */}
      <div className="bg-white w-full max-w-5xl rounded-2xl shadow-2xl border border-stone-200 flex flex-col max-h-[92vh] overflow-hidden my-auto print:border-none print:shadow-none print:max-h-none print:w-full print:rounded-none">
        
        {/* Modal Top Control Bar (Hidden when printing) */}
        <div className="px-5 py-3.5 bg-slate-900 text-white flex items-center justify-between gap-4 border-b border-slate-800 shrink-0 no-print flex-wrap">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-teal-500/20 border border-teal-500/30 flex items-center justify-center text-teal-400">
              <Printer className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm sm:text-base font-bold text-white tracking-tight flex items-center gap-2">
                <span>Print Schedule Matrix</span>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-teal-400/20 text-teal-300 border border-teal-400/30">
                  PDF / Print Ready
                </span>
              </h2>
              <p className="text-[11px] text-slate-400">
                Operating room schedule compiled by patient name, procedure, patient phone, and attending provider
              </p>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleDownloadReport}
              className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white rounded-xl text-xs font-bold border border-slate-700 transition-colors flex items-center gap-1.5 cursor-pointer shadow-sm"
              title="Download print-ready HTML/PDF file"
              id="schedule-download-pdf-btn"
            >
              <Download className="w-4 h-4 text-teal-400" />
              <span className="hidden sm:inline">Download File</span>
            </button>

            <button
              type="button"
              onClick={handlePrint}
              className="px-4 py-1.5 bg-gradient-to-r from-teal-500 to-cyan-500 hover:from-teal-400 hover:to-cyan-400 text-slate-950 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer shadow-md shadow-teal-500/20 hover:scale-105 active:scale-95"
              id="schedule-print-now-btn"
            >
              <Printer className="w-4 h-4" />
              <span>Print Schedule</span>
            </button>

            <button
              type="button"
              onClick={onClose}
              className="p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white rounded-xl transition-colors cursor-pointer ml-1"
              title="Close print dialog"
              id="schedule-print-modal-close-btn"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* View Mode & Scope Selector Tabs (Hidden when printing) */}
        <div className="px-5 py-2.5 bg-slate-50 border-b border-stone-200 flex flex-wrap items-center justify-between gap-3 shrink-0 no-print">
          
          {/* Day vs Week Scope Buttons */}
          <div className="flex items-center gap-1 bg-white p-1 rounded-xl border border-stone-200 shadow-2xs">
            <button
              type="button"
              onClick={() => setPrintScope('DAY')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                printScope === 'DAY'
                  ? 'bg-[#1F6E52] text-white shadow-xs'
                  : 'text-stone-600 hover:bg-stone-100'
              }`}
              id="print-scope-day-tab"
            >
              <Calendar className="w-3.5 h-3.5" />
              <span>Day Schedule ({currentDayInfo.dayName})</span>
            </button>

            <button
              type="button"
              onClick={() => setPrintScope('WK')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                printScope === 'WK'
                  ? 'bg-[#1F6E52] text-white shadow-xs'
                  : 'text-stone-600 hover:bg-stone-100'
              }`}
              id="print-scope-week-tab"
            >
              <Layers className="w-3.5 h-3.5" />
              <span>Full Week Schedule (Mon–Sun)</span>
            </button>
          </div>

          {/* Day Selector (When Day scope is active) */}
          {printScope === 'DAY' && (
            <div className="flex items-center gap-1 overflow-x-auto">
              <span className="text-[10px] font-bold text-stone-500 uppercase tracking-wider mr-1">
                Day:
              </span>
              {daysOfWeek.map((d, idx) => (
                <button
                  key={d.date}
                  type="button"
                  onClick={() => setSelectedDayIdx(idx)}
                  className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                    selectedDayIdx === idx
                      ? 'bg-teal-700 text-white font-bold shadow-2xs'
                      : 'bg-white text-stone-700 border border-stone-200 hover:bg-stone-100'
                  }`}
                >
                  {d.dayName.slice(0, 3)} {d.date}
                </button>
              ))}
            </div>
          )}

          {/* Room Filter Dropdown */}
          <div className="flex items-center gap-1.5">
            <span className="text-[10px] font-bold text-stone-500 uppercase tracking-wider">
              Room Filter:
            </span>
            <select
              value={selectedRoomFilter}
              onChange={(e) => setSelectedRoomFilter(e.target.value)}
              className="bg-white border border-stone-200 rounded-lg px-2.5 py-1 text-xs font-bold text-stone-800 focus:outline-hidden focus:ring-1 focus:ring-teal-500 cursor-pointer shadow-2xs"
            >
              <option value="ALL">All Operating Rooms (OR#1, OR#2, OR#3)</option>
              {rooms.map((r) => (
                <option key={r} value={r}>
                  {r} Only
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Printable Document Preview Area (Scrollable in Modal, Full Width on Paper) */}
        <div className="p-4 sm:p-6 overflow-y-auto flex-1 bg-stone-100/70 print:p-0 print:bg-white print:overflow-visible">
          
          <div 
            id="printable-schedule-document"
            className="max-w-4xl mx-auto bg-white p-6 sm:p-8 rounded-xl border border-stone-200/90 shadow-sm print:border-none print:shadow-none print:p-0 print:max-w-none text-stone-900"
          >
            
            {/* Clinical Practice Document Header */}
            <div className="border-b-2 border-stone-900 pb-4 mb-4">
              <div className="flex flex-wrap items-start justify-between gap-4">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xl sm:text-2xl font-serif font-black tracking-tight text-stone-900 uppercase">
                      {practiceName}
                    </span>
                  </div>
                  <p className="text-xs font-bold text-teal-800 tracking-wide uppercase mt-0.5">
                    Operating Room &amp; Clinical Procedure Schedule
                  </p>
                  <p className="text-[11px] text-stone-500 mt-1">
                    {practiceAddress} • Tel: {practicePhone}
                  </p>
                </div>

                <div className="text-right sm:text-right">
                  <div className="inline-block px-3 py-1 bg-slate-900 text-white text-xs font-bold rounded-lg uppercase tracking-wider mb-1">
                    {printScope === 'DAY' ? 'Daily Schedule' : 'Master Weekly Schedule'}
                  </div>
                  <div className="text-sm font-bold text-stone-900">
                    {printScope === 'DAY' ? currentDayInfo.fullDateStr : 'Monday, July 13, 2026 – Sunday, July 19, 2026'}
                  </div>
                  <p className="text-[10px] text-stone-500 font-mono mt-0.5">
                    Compiled: {new Date().toLocaleDateString()} {new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </p>
                </div>
              </div>

              {/* Scope Summary Banner */}
              <div className="mt-3.5 grid grid-cols-2 sm:grid-cols-4 gap-2 bg-stone-50 p-2.5 rounded-xl border border-stone-200 text-xs">
                <div>
                  <span className="text-[10px] font-bold text-stone-500 uppercase block">Active Scope</span>
                  <span className="font-bold text-stone-900">
                    {printScope === 'DAY' ? currentDayInfo.dayName : '7-Day Full Week'}
                  </span>
                </div>
                <div>
                  <span className="text-[10px] font-bold text-stone-500 uppercase block">Total Scheduled Cases</span>
                  <span className="font-bold text-teal-800">{totalCases} Surgical Patients</span>
                </div>
                <div>
                  <span className="text-[10px] font-bold text-stone-500 uppercase block">OR Operating Hours</span>
                  <span className="font-bold text-stone-900">{totalHours.toFixed(1)} Hours Total</span>
                </div>
                <div>
                  <span className="text-[10px] font-bold text-stone-500 uppercase block">Surgeons on Duty</span>
                  <span className="font-bold text-stone-900 truncate block">
                    {distinctSurgeons.length} Providers
                  </span>
                </div>
              </div>
            </div>

            {/* Room Breakdown Tables */}
            <div className="space-y-6">
              {allActiveRooms.map((roomName) => {
                const roomApts = appointmentsByRoom[roomName] || [];

                return (
                  <div key={roomName} className="break-inside-avoid">
                    
                    {/* Room Header Pill */}
                    <div className="flex items-center justify-between bg-slate-900 text-white px-3.5 py-2 rounded-lg mb-2">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-sm tracking-wide">
                          {roomName === 'OR#1' ? 'Operating Room #1 (Main Surgical Suite)' :
                           roomName === 'OR#2' ? 'Operating Room #2 (Aesthetic & Laser Suite)' :
                           roomName === 'OR#3' ? 'Operating Room #3 (Minor Procedures & Injection)' : roomName}
                        </span>
                      </div>
                      <span className="text-[11px] font-bold text-teal-300">
                        {roomApts.length} {roomApts.length === 1 ? 'Entry' : 'Entries'}
                      </span>
                    </div>

                    {/* Table of Entries for this Room */}
                    {roomApts.length === 0 ? (
                      <div className="p-3 text-center text-xs text-stone-500 bg-stone-50 rounded-lg border border-stone-200 italic">
                        No scheduled procedures in {roomName} for this period.
                      </div>
                    ) : (
                      <div className="overflow-x-auto">
                        <table className="w-full text-left text-xs border-collapse border border-stone-200">
                          <thead>
                            <tr className="bg-stone-100 text-stone-700 font-bold border-b border-stone-200 text-[11px]">
                              <th className="p-2 border-r border-stone-200 w-24">Time / DOS</th>
                              <th className="p-2 border-r border-stone-200">Patient Name</th>
                              <th className="p-2 border-r border-stone-200">Visit Type / Procedure</th>
                              <th className="p-2 border-r border-stone-200 w-32">Patient Phone</th>
                              <th className="p-2 border-r border-stone-200">Provider / Surgeon</th>
                              <th className="p-2 w-28">Anesthesia / Notes</th>
                            </tr>
                          </thead>
                          <tbody>
                            {roomApts.map((apt, idx) => {
                              const isBlockSlot = apt.isBlock;

                              return (
                                <tr 
                                  key={apt.id || idx}
                                  className={`border-b border-stone-200 ${
                                    isBlockSlot 
                                      ? 'bg-emerald-50/50 text-emerald-950 font-medium' 
                                      : idx % 2 === 0 ? 'bg-white' : 'bg-stone-50/60'
                                  }`}
                                >
                                  {/* Time & DOS */}
                                  <td className="p-2 border-r border-stone-200 align-top font-mono font-bold text-[11px]">
                                    <div className="text-stone-900">{apt.startTime}</div>
                                    <div className="text-[10px] text-stone-500">{apt.dos}</div>
                                    <div className="text-[9px] text-stone-400 font-sans">{apt.length || `${apt.durationHours}h`}</div>
                                  </td>

                                  {/* Patient Name */}
                                  <td className="p-2 border-r border-stone-200 align-top">
                                    <div className="font-bold text-stone-900 text-xs flex items-center gap-1.5">
                                      <span>{apt.patientName || apt.title}</span>
                                      {isBlockSlot && (
                                        <span className="px-1.5 py-0.2 rounded text-[9px] font-bold bg-emerald-200 text-emerald-900">
                                          BLOCK
                                        </span>
                                      )}
                                    </div>
                                    {!isBlockSlot && apt.dob && (
                                      <div className="text-[10px] text-stone-500 font-medium mt-0.5">
                                        DOB: {apt.dob} {apt.age ? `(Age ${apt.age})` : ''} • ID #{apt.id}
                                      </div>
                                    )}
                                  </td>

                                  {/* Visit Type / Procedure */}
                                  <td className="p-2 border-r border-stone-200 align-top">
                                    <div className="font-semibold text-stone-800 leading-snug">
                                      {apt.procedure || apt.details || apt.title}
                                    </div>
                                    {apt.details && apt.details !== apt.procedure && (
                                      <div className="text-[10px] text-stone-500 mt-0.5 italic">
                                        {apt.details}
                                      </div>
                                    )}
                                  </td>

                                  {/* Patient Phone Number */}
                                  <td className="p-2 border-r border-stone-200 align-top font-semibold text-teal-800 font-mono text-[11px]">
                                    {apt.phone && apt.phone !== 'N/A' ? (
                                      <div className="flex items-center gap-1">
                                        <span>{apt.phone}</span>
                                      </div>
                                    ) : isBlockSlot ? (
                                      <span className="text-stone-400 italic">N/A</span>
                                    ) : (
                                      <span>(310) 555-0192</span>
                                    )}
                                  </td>

                                  {/* Provider / Surgeon */}
                                  <td className="p-2 border-r border-stone-200 align-top">
                                    <div className="font-bold text-stone-900 text-xs">
                                      {apt.surgeon}
                                    </div>
                                    {apt.anesthesiologist && (
                                      <div className="text-[10px] text-stone-500 mt-0.5">
                                        Anesth: {apt.anesthesiologist}
                                      </div>
                                    )}
                                  </td>

                                  {/* Anesthesia / Notes */}
                                  <td className="p-2 align-top text-[10px] text-stone-600">
                                    <div className="font-semibold text-stone-800">
                                      {apt.anesthesiaType || 'General'}
                                    </div>
                                    {apt.paymentType && (
                                      <div className="text-[9px] text-stone-500 mt-0.5 font-medium">
                                        {apt.paymentType}
                                      </div>
                                    )}
                                    {apt.notes && (
                                      <div className="text-[9px] text-stone-500 mt-0.5 line-clamp-2 italic">
                                        {apt.notes}
                                      </div>
                                    )}
                                  </td>
                                </tr>
                              );
                            })}
                          </tbody>
                        </table>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>

            {/* Provider Sign-off & OR Verification Block */}
            <div className="mt-8 pt-4 border-t border-stone-300 text-xs text-stone-600 break-inside-avoid">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
                <div>
                  <div className="border-b border-stone-400 h-8 mb-1"></div>
                  <span className="text-[10px] font-bold text-stone-500 uppercase block">OR Charge Nurse Sign-off</span>
                </div>
                <div>
                  <div className="border-b border-stone-400 h-8 mb-1"></div>
                  <span className="text-[10px] font-bold text-stone-500 uppercase block">Attending Surgeon Verification</span>
                </div>
                <div>
                  <div className="border-b border-stone-400 h-8 mb-1"></div>
                  <span className="text-[10px] font-bold text-stone-500 uppercase block">Clinical Director / Date</span>
                </div>
              </div>

              <div className="mt-4 flex items-center justify-between text-[10px] text-stone-400 border-t border-stone-200 pt-2">
                <span>CONFIDENTIAL CLINICAL DOCUMENT • HIPAA PROTECTED HEALTH INFORMATION</span>
                <span>Page 1 of 1 • Generated by Office Intelligence Medical OS</span>
              </div>
            </div>

          </div>
        </div>

        {/* Modal Footer Controls (Hidden when printing) */}
        <div className="px-5 py-3 bg-stone-50 border-t border-stone-200 flex items-center justify-between gap-3 shrink-0 no-print flex-wrap">
          <div className="flex items-center gap-2 text-xs text-stone-500 font-medium">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            <span>Ready for standard letter printing and export</span>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-white hover:bg-stone-100 text-stone-700 text-xs font-bold rounded-xl border border-stone-300 transition-colors cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={handlePrint}
              className="px-5 py-2 bg-[#1F6E52] hover:bg-[#1e2936] text-white text-xs font-bold rounded-xl shadow-md transition-all flex items-center gap-1.5 cursor-pointer"
            >
              <Printer className="w-4 h-4 text-teal-300" />
              <span>Print {printScope === 'DAY' ? 'Day Schedule' : 'Week Schedule'}</span>
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
