import React, { useState, useEffect } from 'react';
import {
  CreditCard,
  Settings,
  Sparkles,
  Building2,
  ShieldCheck,
  Layers,
  Zap,
  DollarSign,
  Inbox,
  Sliders,
  CheckCircle2,
  Calendar,
  Users,
  Search,
  ArrowRight,
  Activity
} from 'lucide-react';
import { PatientCase, PracticeConfig } from '../types';
import { BillingModulePage } from './BillingModulePage';
import { AdministrationPage, AdminActiveSection } from './AdministrationPage';
import { AIHomePage } from './AIHomePage';
import { AIWorkflowExamples } from './AIWorkflowExamples';

// Note: Messages moved out to a standalone top-level page (see MessagesPage.tsx,
// rendered directly from App.tsx) — it's used by nearly every employee and was
// hard to find buried as a Practice sub-tab, so it no longer lives here.
export type PracticeSubModule = 'billing' | 'admin' | 'workflows';

interface PracticeWorkspaceProps {
  initialSubModule?: PracticeSubModule;
  cases: PatientCase[];
  onShowToast: (message: string) => void;
  onOpenPatientChartById: (patientId: string, sectionKey?: string) => void;
  onOpenPatientChart: (patient: PatientCase, sectionKey?: string) => void;
  onTriggerEKGFastTrack: (caseId: string) => void;
  onUpdateStage: (caseId: string, newStage: any) => void;
  practiceConfig: PracticeConfig;
  practicesList: PracticeConfig[];
  activePracticeId: string;
  onSelectPractice: (practiceId: string) => void;
  onAddPractice: (newPractice: PracticeConfig) => void;
  onDeletePractice: (practiceId: string) => void;
  onUpdatePracticeConfig: (updated: PracticeConfig) => void;
  adminActiveSection: AdminActiveSection;
  onAdminSectionChange: (section: AdminActiveSection) => void;
  onNavigateTab: (tab: string, subModule?: string) => void;
}

export const PracticeWorkspace: React.FC<PracticeWorkspaceProps> = ({
  initialSubModule = 'billing',
  cases,
  onShowToast,
  onOpenPatientChartById,
  onOpenPatientChart,
  onTriggerEKGFastTrack,
  onUpdateStage,
  practiceConfig,
  practicesList,
  activePracticeId,
  onSelectPractice,
  onAddPractice,
  onDeletePractice,
  onUpdatePracticeConfig,
  adminActiveSection,
  onAdminSectionChange,
  onNavigateTab,
}) => {
  const [activeSubModule, setActiveSubModule] = useState<PracticeSubModule>(initialSubModule);

  useEffect(() => {
    if (initialSubModule) {
      setActiveSubModule(initialSubModule);
    }
  }, [initialSubModule]);

  const subModules: {
    id: PracticeSubModule;
    label: string;
    description: string;
    icon: React.ComponentType<{ className?: string }>;
    badge?: number;
    badgeColor?: string;
  }[] = [
    {
      id: 'billing',
      label: 'Billing & Invoices',
      description: 'Claims, fee schedules, electronic scrubbing, and ledger',
      icon: CreditCard,
    },
    {
      id: 'admin',
      label: 'Administration & Locations',
      description: 'Practice configuration, locations, provider credentials, and OR suite settings',
      icon: Settings,
    },
    {
      id: 'workflows',
      label: 'AI Hub & Automation',
      description: 'Autonomous clinical protocols, EKG fast-track, and agent workflows',
      icon: Sparkles,
    },
  ];

  return (
    <div className="space-y-5">
      {/* Practice Workspace Navigation Bar */}
      <div className="bg-white rounded-2xl border border-stone-200/90 p-4 shadow-2xs">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          
          {/* Header Info */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-slate-900 via-emerald-900 to-emerald-900 text-white flex items-center justify-center shadow-md">
              <Building2 className="w-5 h-5 text-teal-300" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200">
                  Practice Workspace
                </span>
                <span className="text-xs text-stone-500 font-medium">
                  {practiceConfig.practiceName}
                </span>
              </div>
              <h1 className="text-base font-bold text-stone-900 mt-0.5">
                Practice Operations, Financials & Administration
              </h1>
            </div>
          </div>

          {/* Sub-Module Switcher Tabs */}
          <div className="flex items-center gap-1.5 p-1 bg-stone-100/90 rounded-xl border border-stone-200 overflow-x-auto scrollbar-none">
            {subModules.map((mod) => {
              const Icon = mod.icon;
              const isActive = activeSubModule === mod.id;
              return (
                <button
                  key={mod.id}
                  onClick={() => {
                    setActiveSubModule(mod.id);
                    onShowToast(`Switched Practice module: ${mod.label}`);
                  }}
                  id={`practice-subtab-${mod.id}`}
                  className={`flex items-center gap-2 px-3 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer whitespace-nowrap select-none ${
                    isActive
                      ? 'bg-emerald-700 text-white shadow-xs font-black'
                      : 'text-stone-700 hover:text-stone-950 hover:bg-stone-200/70'
                  }`}
                  title={mod.description}
                >
                  <Icon className={`w-4 h-4 ${isActive ? 'text-white' : 'text-stone-500'}`} />
                  <span>{mod.label}</span>
                  {mod.badge !== undefined && (
                    <span className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono font-bold ${
                      isActive ? 'bg-white text-emerald-900' : mod.badgeColor || 'bg-amber-500 text-white'
                    }`}>
                      {mod.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </div>

        </div>
      </div>

      {/* Sub-Module Content Rendering */}
      <div className="transition-all animate-in fade-in duration-150">
        {activeSubModule === 'billing' && (
          <BillingModulePage
            cases={cases}
            onShowToast={onShowToast}
          />
        )}

        {activeSubModule === 'admin' && (
          <AdministrationPage
            onShowToast={onShowToast}
            activeSection={adminActiveSection}
            onSectionChange={onAdminSectionChange}
            practiceConfig={practiceConfig}
            practicesList={practicesList}
            activePracticeId={activePracticeId}
            onSelectPractice={onSelectPractice}
            onAddPractice={onAddPractice}
            onDeletePractice={onDeletePractice}
            onUpdatePracticeConfig={onUpdatePracticeConfig}
          />
        )}

        {activeSubModule === 'workflows' && (
          <div className="space-y-6">
            <AIHomePage
              cases={cases}
              onSelectPatient={onOpenPatientChart}
              onOpenPatientChartById={onOpenPatientChartById}
              onTriggerEKGFastTrack={onTriggerEKGFastTrack}
              onUpdateStage={onUpdateStage}
              onShowToast={onShowToast}
              onNavigateTab={onNavigateTab}
            />
            <div className="mt-8 pt-8 border-t border-stone-200">
              <h2 className="text-base font-bold text-stone-900 mb-4 flex items-center gap-2">
                <Zap className="w-5 h-5 text-amber-500" />
                <span>Autonomous Workflow Protocols & Fast-Tracks</span>
              </h2>
              <AIWorkflowExamples
                cases={cases}
                onSelectPatient={(patientId) => onOpenPatientChartById(patientId)}
                onRunWorkflow={(workflowId) => {
                  if (workflowId === 'wf-ekg-fasttrack') {
                    onTriggerEKGFastTrack('case-2');
                  }
                }}
                onShowToast={onShowToast}
              />
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
