import React, { useState } from 'react';
import { 
  Sparkles, 
  Send, 
  Clock, 
  RotateCcw, 
  Filter, 
  FileText, 
  CheckCircle2, 
  AlertCircle, 
  Calendar, 
  Plus, 
  Printer,
  ChevronLeft,
  ChevronRight,
  CalendarDays,
  LayoutGrid,
  Lock,
  Info
} from 'lucide-react';

interface NightingaleScheduleCommandCoordinatorProps {
  onExecuteCommand: (command: string) => { success: boolean; message: string };
  onOpenBriefing: () => void;
  onOpenNewAppointmentModal?: () => void;
  onOpenBlockTimeModal?: () => void;
  onOpenPrintModal?: () => void;
  viewMode?: 'DAY' | 'WK';
  onSetViewMode?: (mode: 'DAY' | 'WK') => void;
  onPrevDate?: () => void;
  onNextDate?: () => void;
  onToday?: () => void;
  activeFilters: {
    surgeon: string | null;
    room: string | null;
    procedure: string | null;
  };
  onClearFilters: () => void;
  currentDateDisplay?: string;
  timeHorizonInfo?: {
    monthYearStr: string;
    isOffset: boolean;
    offsetDesc: string;
  };
  onResetToToday?: () => void;
}

export const NightingaleScheduleCommandCoordinator: React.FC<NightingaleScheduleCommandCoordinatorProps> = ({
  onExecuteCommand,
  onOpenBriefing,
  onOpenNewAppointmentModal,
  onOpenBlockTimeModal,
  onOpenPrintModal,
  viewMode = 'WK',
  onSetViewMode,
  onPrevDate,
  onNextDate,
  onToday,
  activeFilters,
  onClearFilters,
  currentDateDisplay = 'Monday, July 13, 2026',
  timeHorizonInfo,
  onResetToToday,
}) => {
  const [commandInput, setCommandInput] = useState('');
  const [lastFeedback, setLastFeedback] = useState<{ text: string; isError?: boolean } | null>({
    text: "Nightingale AI is active. Enter any scheduling command or choose a critical task below."
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!commandInput.trim()) return;

    const res = onExecuteCommand(commandInput.trim());
    setLastFeedback({
      text: res.message,
      isError: !res.success,
    });
    setCommandInput('');
  };

  const handleSuggestedTask = (taskPrompt: string) => {
    const res = onExecuteCommand(taskPrompt);
    setLastFeedback({
      text: res.message,
      isError: !res.success,
    });
  };

  const hasActiveFilters = Boolean(activeFilters.surgeon || activeFilters.room || activeFilters.procedure);

  // Only the single most common action stays a persistent button. Block Time,
  // Print, and Surgical Briefing are one command away instead of permanent
  // chrome (handleExecuteNightingaleCommand already recognizes "block time",
  // "print", and "brief" as directives) — see the hint line under the input.
  const handleAddAppointment = () => {
    if (onOpenNewAppointmentModal) onOpenNewAppointmentModal();
    else handleSuggestedTask('Schedule new appointment');
  };

  return (
    <div className="bg-[#F1F3EC] text-[#1A2E22] rounded-xl border border-[#3E8FA6]/50 shadow-2xs overflow-hidden transition-all nightingale-highlight-border">

      {/* Top Banner: Blended seamlessly with the rest of the page */}
      <div className="bg-[#F1F3EC] px-4 py-2.5 flex flex-wrap items-center justify-between gap-3 border-b border-[#E1E4DC]">
        <div className="flex items-center gap-2.5">
          <div className="w-7 h-7 rounded-lg bg-[#E7F1F3] border border-[#3E8FA6]/50 flex items-center justify-center text-[#3E8FA6]">
            <Sparkles className="w-4 h-4" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-bold text-xs text-[#1A2E22] font-display tracking-wide">Nightingale AI</span>
              <span className="text-[10px] text-[#1D4E5A] font-semibold px-2 py-0.2 rounded-full bg-[#E7F1F3] border border-[#3E8FA6]/50 flex items-center gap-0.5">
                <Info className="w-2.5 h-2.5" />
                Virtual Surgical Coordinator
              </span>
              <span className="hidden sm:inline-flex items-center gap-1 text-[10px] text-[#1B4332] font-medium font-mono">
                <span className="w-1.5 h-1.5 rounded-full bg-[#2F9E6E] animate-pulse"></span>
                Active on OR Suites
              </span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          {timeHorizonInfo?.isOffset && onResetToToday && (
            <button
              type="button"
              onClick={onResetToToday}
              className="px-2.5 py-1 rounded-lg text-[11px] font-bold bg-[#FBEEDB] hover:bg-[#FBEEDB]/80 text-[#7A4E17] border border-[#E1E4DC] transition-colors flex items-center gap-1 cursor-pointer shadow-2xs"
              title="Return schedule matrix to today (July 13, 2026)"
            >
              <RotateCcw className="w-3 h-3" />
              <span>Return to Today (Jul 13, 2026)</span>
            </button>
          )}

          {hasActiveFilters && (
            <button
              type="button"
              onClick={onClearFilters}
              className="px-2.5 py-1 rounded-lg text-[11px] font-bold bg-[#FBEEDB] hover:bg-[#FBEEDB]/80 text-[#7A4E17] border border-[#E1E4DC] transition-colors flex items-center gap-1 cursor-pointer"
            >
              <RotateCcw className="w-3 h-3" />
              <span>Reset Filters</span>
            </button>
          )}

        </div>
      </div>

      {/* AI Search & Command Input Area */}
      <div className="p-3 bg-[#F1F3EC] space-y-2.5">
        <form onSubmit={handleSubmit} className="relative flex items-center gap-2">
          <div className="relative flex-1">
            <input
              type="text"
              value={commandInput}
              onChange={(e) => setCommandInput(e.target.value)}
              placeholder="Ask Nightingale AI to schedule, filter, reassign rooms, or update cases..."
              className="w-full pl-9 pr-24 py-2.5 bg-white hover:bg-white border border-[#E1E4DC] rounded-xl text-xs font-semibold text-[#1A2E22] placeholder:text-[#5B6B60] focus:outline-hidden focus:ring-2 focus:ring-[#1F6E52] focus:border-[#1F6E52] transition-all shadow-2xs"
              id="nightingale-ai-schedule-search-input"
            />
            <Sparkles className="w-4 h-4 text-[#1F6E52] absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            <button
              type="submit"
              disabled={!commandInput.trim()}
              className="absolute right-1.5 top-1/2 -translate-y-1/2 px-3 py-1.5 bg-[#1F6E52] hover:bg-[#17553F] disabled:opacity-40 text-white rounded-lg text-xs font-bold transition-all flex items-center gap-1 cursor-pointer shadow-2xs font-sans"
            >
              <span>Execute</span>
              <Send className="w-3 h-3" />
            </button>
          </div>
        </form>

        {/* One primary action + a compact date stepper. Everything else that used
            to be a persistent button (Block Time, Print, Surgical Briefing) is
            now a typed/spoken command — see the hint line below. */}
        <div className="flex items-center gap-1.5 flex-wrap pt-0.5">
          <button
            type="button"
            onClick={handleAddAppointment}
            className="px-2.5 py-1 rounded-lg text-[11px] font-bold transition-colors cursor-pointer shadow-2xs flex items-center gap-1.5 border bg-[#1F6E52] hover:bg-[#17553F] text-white border-[#1F6E52]"
          >
            <Plus className="w-3 h-3 text-white" />
            <span>Add Appointment</span>
          </button>

          {/* Compact date stepper — replaces the separate Prev/Today/Next buttons */}
          <div className="flex items-center rounded-lg border border-[#E1E4DC] bg-white shadow-2xs overflow-hidden">
            <button
              type="button"
              onClick={() => (onPrevDate ? onPrevDate() : handleSuggestedTask('Go to previous date'))}
              className="p-1.5 hover:bg-[#F1F3EC] text-[#5B6B60] hover:text-[#1A2E22] transition-colors cursor-pointer"
              title={viewMode === 'DAY' ? 'Previous day' : 'Previous week'}
            >
              <ChevronLeft className="w-3.5 h-3.5" />
            </button>
            <button
              type="button"
              onClick={() => {
                if (onToday) onToday();
                else if (onResetToToday) onResetToToday();
                handleSuggestedTask('Return to today');
              }}
              className="px-2.5 py-1 text-[11px] font-bold text-[#1A2E22] hover:bg-[#F1F3EC] transition-colors cursor-pointer border-x border-[#E1E4DC] whitespace-nowrap"
            >
              {currentDateDisplay || 'Today'}
            </button>
            <button
              type="button"
              onClick={() => (onNextDate ? onNextDate() : handleSuggestedTask('Go to next date'))}
              className="p-1.5 hover:bg-[#F1F3EC] text-[#5B6B60] hover:text-[#1A2E22] transition-colors cursor-pointer"
              title={viewMode === 'DAY' ? 'Next day' : 'Next week'}
            >
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Day / Week — single compact toggle instead of two buttons */}
          <div className="flex items-center rounded-lg border border-[#E1E4DC] bg-white shadow-2xs overflow-hidden text-[11px] font-bold">
            <button
              type="button"
              onClick={() => { if (onSetViewMode) onSetViewMode('DAY'); handleSuggestedTask('Switch to day view'); }}
              className={`px-2.5 py-1 transition-colors cursor-pointer ${viewMode === 'DAY' ? 'bg-[#1A2E22] text-white' : 'text-[#5B6B60] hover:bg-[#F1F3EC]'}`}
            >
              Day
            </button>
            <button
              type="button"
              onClick={() => { if (onSetViewMode) onSetViewMode('WK'); handleSuggestedTask('Switch to week view'); }}
              className={`px-2.5 py-1 transition-colors cursor-pointer border-l border-[#E1E4DC] ${viewMode === 'WK' ? 'bg-[#1A2E22] text-white' : 'text-[#5B6B60] hover:bg-[#F1F3EC]'}`}
            >
              Week
            </button>
          </div>

          <span className="text-[10.5px] text-[#5B6B60] italic ml-1">
            Block time, print, or ask for a briefing — just tell Nightingale.
          </span>
        </div>
      </div>

      {/* Real-Time Feedback from Nightingale */}
      {lastFeedback && (
        <div className={`px-4 py-2 text-xs font-medium flex items-center gap-2 border-t ${
          lastFeedback.isError 
            ? 'bg-[#FBE4E1] text-[#7A2E22] border-[#C1503D]/30' 
            : 'bg-[#DCEEE3] text-[#1B4332] border-[#E1E4DC]'
        }`}>
          {lastFeedback.isError ? (
            <AlertCircle className="w-4 h-4 text-[#C1503D] shrink-0" />
          ) : (
            <CheckCircle2 className="w-4 h-4 text-[#1F6E52] shrink-0" />
          )}
          <span className="flex-1 leading-snug">{lastFeedback.text}</span>
        </div>
      )}

      {/* Active Filter Indicators */}
      {hasActiveFilters && (
        <div className="px-4 py-1.5 bg-[#FBEEDB] border-t border-[#E1E4DC] flex items-center justify-between text-xs text-[#7A4E17]">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="font-bold flex items-center gap-1">
              <Filter className="w-3.5 h-3.5 text-[#7A4E17]" />
              Active Filter:
            </span>
            {activeFilters.surgeon && (
              <span className="px-2 py-0.5 rounded-md bg-white border border-[#E1E4DC] font-semibold text-[11px]">
                Surgeon: {activeFilters.surgeon}
              </span>
            )}
            {activeFilters.room && (
              <span className="px-2 py-0.5 rounded-md bg-white border border-[#E1E4DC] font-semibold text-[11px]">
                Room: {activeFilters.room}
              </span>
            )}
            {activeFilters.procedure && (
              <span className="px-2 py-0.5 rounded-md bg-white border border-[#E1E4DC] font-semibold text-[11px]">
                Procedure: {activeFilters.procedure}
              </span>
            )}
          </div>

          <button
            type="button"
            onClick={onClearFilters}
            className="text-[11px] font-bold text-[#7A4E17] hover:text-[#1A2E22] underline cursor-pointer"
          >
            Clear All
          </button>
        </div>
      )}

    </div>
  );
};


