import React, { useState } from 'react';
import { Sparkles, ArrowRight, ChevronDown, ChevronUp, Info } from 'lucide-react';
import { PatientCase, CommunicationStats } from '../types';
import { CommunicationWidget } from './CommunicationWidget';

interface NightingaleBriefBannerProps {
  cases: PatientCase[];
  onActionClick: () => void;
  onFilterNeedsAttention?: () => void;
  stats?: CommunicationStats;
  onSelectCategory?: (category: string) => void;
}

export const NightingaleBriefBanner: React.FC<NightingaleBriefBannerProps> = ({
  cases,
  onActionClick,
  stats,
  onSelectCategory,
}) => {
  const [isWaitingExpanded, setIsWaitingExpanded] = useState(false);

  const waitingTotal = stats
    ? stats.insuranceApproval + stats.labResults + stats.implantShipment + stats.physicianSignature
    : 0;
  const commTotal = stats
    ? stats.patientMessages + stats.referrals + stats.insuranceQueries + stats.labNotifications
    : 0;
  const combinedTotal = waitingTotal + commTotal;

  return (
    <div className="bg-[#F1F3EC] rounded-xl border border-[#3E8FA6]/50 p-4 sm:p-5 shadow-2xs space-y-4 nightingale-highlight-border">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-[#E1E4DC] pb-3">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-lg bg-[#E7F1F3] border border-[#3E8FA6]/50 text-[#3E8FA6] flex items-center justify-center shadow-2xs">
            <Sparkles className="w-4 h-4 text-[#3E8FA6]" />
          </div>
          <h2 className="text-sm font-bold text-[#1A2E22] font-display tracking-tight flex items-center gap-1.5">
            <span>Nightingale morning brief</span>
            <span className="px-1.5 py-0.2 rounded-full text-[10px] font-bold bg-[#E7F1F3] text-[#1D4E5A] border border-[#3E8FA6]/50 font-mono flex items-center gap-0.5">
              <Info className="w-2.5 h-2.5" />
              AI
            </span>
          </h2>
        </div>
        <span className="text-[11px] font-medium text-[#5B6B60] font-mono">07:00 AM Sync</span>
      </div>

      {/* Bullet Points */}
      <div className="space-y-2 text-xs text-[#1A2E22] font-medium">
        <div className="flex items-start gap-2">
          <span className="w-1.5 h-1.5 rounded-full bg-[#1F6E52] mt-1.5 shrink-0"></span>
          <span>Five procedures scheduled today across OR 1 and OR 2.</span>
        </div>
        <div className="flex items-start gap-2">
          <span className="w-1.5 h-1.5 rounded-full bg-[#5B6B60] mt-1.5 shrink-0"></span>
          <span>Four patients fully pre-cleared for surgical transport.</span>
        </div>
        <div className="flex items-start gap-2">
          <span className="w-1.5 h-1.5 rounded-full bg-[#7A4E17] mt-1.5 shrink-0"></span>
          <span className="font-semibold text-[#7A4E17]">
            One patient requires an EKG result and pre-op baseline photo review.
          </span>
        </div>
        <div className="flex items-start gap-2">
          <span className="w-1.5 h-1.5 rounded-full bg-[#2F9E6E] mt-1.5 shrink-0"></span>
          <span>Operating rooms are currently on schedule.</span>
        </div>
      </div>

      {/* Recommended Action Box */}
      <div className="p-3.5 bg-white rounded-xl border border-[#E1E4DC] shadow-2xs space-y-2">
        <div className="text-[10px] font-bold tracking-wider text-[#5B6B60] uppercase font-display">
          Recommended Action
        </div>
        <p className="text-xs text-[#1A2E22] font-medium leading-snug">
          Request Patricia DePoli's EKG result before the 8:00 AM case to prevent OR 1 cascade delay.
        </p>
        <button
          onClick={onActionClick}
          className="w-full py-1.5 px-3 rounded-lg bg-[#1F6E52] hover:bg-[#17553F] text-white text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors shadow-2xs cursor-pointer font-sans"
        >
          <span>View day details & resolve</span>
          <ArrowRight className="w-3.5 h-3.5 text-[#DCEEE3]" />
        </button>
      </div>

      {/* Waiting For / Communication Center — merged into one collapsed line
          instead of two always-open panels, since it's the same "what needs a
          human" concept this brief is already reporting on. */}
      {stats && (
        <div className="rounded-xl border border-[#E1E4DC] overflow-hidden">
          <button
            type="button"
            onClick={() => setIsWaitingExpanded((v) => !v)}
            className="w-full px-3.5 py-2.5 bg-white hover:bg-[#F1F3EC] flex items-center justify-between gap-2 text-xs font-semibold text-[#1A2E22] transition-colors cursor-pointer"
          >
            <span>{combinedTotal} item{combinedTotal === 1 ? '' : 's'} waiting on you today — insurance ({stats.insuranceApproval}), labs ({stats.labResults}), messages ({stats.patientMessages})</span>
            {isWaitingExpanded ? <ChevronUp className="w-3.5 h-3.5 text-[#5B6B60] shrink-0" /> : <ChevronDown className="w-3.5 h-3.5 text-[#5B6B60] shrink-0" />}
          </button>
          {isWaitingExpanded && (
            <div className="p-3 bg-[#F1F3EC] border-t border-[#E1E4DC]">
              <CommunicationWidget stats={stats} onSelectCategory={onSelectCategory || (() => {})} />
            </div>
          )}
        </div>
      )}
    </div>
  );
};
