import React, { useState, useEffect } from 'react';
import {
  MessageSquare,
  Search,
  CheckCircle2,
  Clock,
  User,
  ArrowRight,
  Send,
  Sparkles,
  AlertTriangle,
  FileText,
  Phone,
  Check,
  Stethoscope,
  Building2,
  ChevronRight,
  Eye,
  EyeOff,
  Plus,
  RefreshCw,
  Zap,
  Layers,
  Inbox,
  Filter,
  ShieldCheck,
  Trash2,
  Paperclip,
  Calendar,
  ExternalLink,
  MessageCircle,
  Activity,
  AlertCircle
} from 'lucide-react';
import { PortalMessage } from '../data/portalData';
import {
  getAllPortalMessages,
  getMessagesForPatient,
  markMessageReadStatus,
  sendProviderReply,
  subscribeToMessageUpdates,
  getUnreadCount,
  deletePortalMessage,
  normalizePatientId
} from '../utils/portalMessageStore';
import { PatientCase } from '../types';

interface MessagesPageProps {
  cases?: PatientCase[];
  onOpenPatientChart?: (patientId: string, sectionKey?: string) => void;
  onShowToast?: (msg: string) => void;
  onNavigateTab?: (tab: string) => void;
}

export const MessagesPage: React.FC<MessagesPageProps> = ({
  cases = [],
  onOpenPatientChart,
  onShowToast,
  onNavigateTab
}) => {
  const [messages, setMessages] = useState<PortalMessage[]>(() => getAllPortalMessages());
  const [selectedTab, setSelectedTab] = useState<'ALL' | 'UNREAD' | 'CLINICAL' | 'REFILL' | 'SCHEDULING' | 'BILLING'>('ALL');
  const [selectedProviderFilter, setSelectedProviderFilter] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [activeMessageId, setActiveMessageId] = useState<string | null>(null);

  // Quick Reply & Active Composer State
  const [replyText, setReplyText] = useState<string>('');
  const [selectedStaffAuthor, setSelectedStaffAuthor] = useState<string>('Dr. Alistair Sterling, MD');
  const [selectedStaffRole, setSelectedStaffRole] = useState<string>('Attending Surgeon & Medical Director');
  const [sendSmsNotification, setSendSmsNotification] = useState<boolean>(true);
  const [selectedAttachment, setSelectedAttachment] = useState<{ name: string; size: string } | null>(null);
  const [isGeneratingAiDraft, setIsGeneratingAiDraft] = useState<boolean>(false);
  const [aiDraftSummary, setAiDraftSummary] = useState<string | null>(null);
  const [showTemplates, setShowTemplates] = useState<boolean>(false);

  // Subscribe to updates across app
  useEffect(() => {
    const refresh = () => {
      const all = getAllPortalMessages();
      setMessages(all);
    };
    refresh();
    const unsubscribe = subscribeToMessageUpdates(refresh);
    return () => unsubscribe();
  }, []);

  // Filter messages (patient inbound primarily for triage, plus all conversation threads)
  const patientInboundMessages = messages.filter((m) => m.sender === 'patient');
  const unreadMessages = patientInboundMessages.filter((m) => !m.read);

  const filteredMessages = patientInboundMessages.filter((m) => {
    // Tab filtering
    if (selectedTab === 'UNREAD' && m.read) return false;
    if (selectedTab === 'CLINICAL' && m.category !== 'Clinical Question') return false;
    if (selectedTab === 'REFILL' && m.category !== 'Prescription Refill') return false;
    if (selectedTab === 'SCHEDULING' && m.category !== 'Scheduling') return false;
    if (selectedTab === 'BILLING' && m.category !== 'Billing') return false;

    // Provider filtering
    if (selectedProviderFilter !== 'ALL') {
      if (selectedProviderFilter === 'sterling' && m.providerId !== 'dr-sterling') return false;
      if (selectedProviderFilter === 'mercer' && m.providerId !== 'dr-mercer') return false;
      if (selectedProviderFilter === 'cruz' && m.providerId !== 'dr-cruz') return false;
      if (selectedProviderFilter === 'chen' && m.providerId !== 'dr-chen') return false;
    }

    // Search query
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchName = m.senderName.toLowerCase().includes(q);
      const matchContent = m.content.toLowerCase().includes(q);
      const matchCategory = m.category?.toLowerCase().includes(q);
      const matchPatientId = m.patientId.includes(q);
      if (!matchName && !matchContent && !matchCategory && !matchPatientId) return false;
    }

    return true;
  });

  // Auto-select first message if none selected or if active one no longer exists
  useEffect(() => {
    if (filteredMessages.length > 0 && (!activeMessageId || !filteredMessages.some((m) => m.id === activeMessageId))) {
      setActiveMessageId(filteredMessages[0].id);
    }
  }, [filteredMessages, activeMessageId]);

  const activeMessage = filteredMessages.find((m) => m.id === activeMessageId) || filteredMessages[0] || null;

  // Get full thread for active message's patient
  const activeThread = activeMessage ? getMessagesForPatient(activeMessage.patientId) : [];

  // Associated case data if found
  const associatedCase = activeMessage
    ? cases.find(
        (c) =>
          normalizePatientId(c.id) === normalizePatientId(activeMessage.patientId) ||
          normalizePatientId(c.patientId) === normalizePatientId(activeMessage.patientId)
      )
    : null;

  const handleToggleRead = (msg: PortalMessage, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    markMessageReadStatus(msg.patientId, msg.id, !msg.read);
    setMessages(getAllPortalMessages());
  };

  const handleMarkAllRead = () => {
    unreadMessages.forEach((m) => {
      markMessageReadStatus(m.patientId, m.id, true);
    });
    setMessages(getAllPortalMessages());
    if (onShowToast) onShowToast('All inbound portal messages marked as triaged.');
  };

  const handleOpenChart = (patientId: string, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    if (onOpenPatientChart) {
      onOpenPatientChart(patientId, 'portalMessages');
    }
  };

  const handleSendReply = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeMessage || !replyText.trim()) return;

    sendProviderReply(activeMessage.patientId, {
      senderName: selectedStaffAuthor,
      senderTitle: selectedStaffRole,
      category: activeMessage.category,
      content: replyText.trim(),
      attachment: selectedAttachment || undefined
    });

    // Mark active message read if unread
    if (!activeMessage.read) {
      markMessageReadStatus(activeMessage.patientId, activeMessage.id, true);
    }

    const patientName = activeMessage.senderName;
    setReplyText('');
    setSelectedAttachment(null);
    setAiDraftSummary(null);
    setShowTemplates(false);
    setMessages(getAllPortalMessages());

    if (onShowToast) {
      onShowToast(`Response successfully transmitted to ${patientName}'s MyHealth portal inbox.`);
    }
  };

  // Quick Clinical Templates
  const clinicalTemplates = [
    {
      title: 'Pre-Op Fasting & Morning Meds',
      category: 'Clinical Question' as const,
      text: `Hello, you may take approved morning cardiovascular/blood pressure medications with a single small sip of water at 5:30 AM. Strictly avoid all other liquids, coffee, and solid foods from midnight onward. Please arrive at the ASC on time.`
    },
    {
      title: 'Prescription Transmitted to Pharmacy',
      category: 'Prescription Refill' as const,
      text: `Hi, your surgical prescriptions (including post-op analgesia, anti-emetic prophylaxis, and surgical antibiotic) have been electronically transmitted to your pharmacy on file. They are verified and ready for pickup prior to surgery.`
    },
    {
      title: '12-Lead EKG & Clearance Verified',
      category: 'Clinical Question' as const,
      text: `Good day, we have received and reviewed your 12-lead EKG report from cardiology. The rhythm interpretation has been signed off by Dr. Sterling and your surgical clearance is 100% complete.`
    },
    {
      title: 'Post-Op Follow-Up Reminder',
      category: 'Scheduling' as const,
      text: `Hello, your post-operative dressing evaluation and follow-up appointment is confirmed. Please wear comfortable, loose-fitting clothing with front-button closures and bring your support garment.`
    },
    {
      title: 'Billing & Account Cleared',
      category: 'Billing' as const,
      text: `Thank you for your inquiry. Your surgical facility and anesthesia pre-authorizations have been processed, and your current patient balance is $0.00. Detailed receipts are available in your portal billing documents.`
    }
  ];

  const handleGenerateAiDraft = () => {
    if (!activeMessage) return;
    setIsGeneratingAiDraft(true);

    setTimeout(() => {
      setIsGeneratingAiDraft(false);
      const firstName = activeMessage.senderName.split(' ')[0];
      const contentLower = activeMessage.content.toLowerCase();

      if (
        activeMessage.category === 'Prescription Refill' ||
        contentLower.includes('prescription') ||
        contentLower.includes('walgreens') ||
        contentLower.includes('medication') ||
        contentLower.includes('refill')
      ) {
        setReplyText(
          `Hi ${firstName}, Dr. Sterling's clinical team has confirmed your surgical prescriptions (Celebrex 200mg and Zofran 4mg) were electronically transmitted to your pharmacy on Wilshire Blvd. They are verified and ready for pickup prior to surgery.`
        );
        setAiDraftSummary(`Generated pharmacy verification reply for ${activeMessage.senderName}.`);
      } else if (contentLower.includes('ekg') || contentLower.includes('cardiology')) {
        setReplyText(
          `Dear ${firstName}, we have verified receipt of your 12-lead EKG fax directly from Pacific Coast Cardiology. The rhythm report has been reviewed and cleared by Dr. Sterling. Your surgical clearance is now complete!`
        );
        setAiDraftSummary(`Generated clearance confirmation addressing external EKG fax.`);
      } else if (contentLower.includes('water') || contentLower.includes('fasting') || contentLower.includes('morning')) {
        setReplyText(
          `Hi ${firstName}, you may take your morning blood pressure medication at 5:30 AM with a small sip of water. Maintain strict fasting from midnight onward otherwise. Let us know if you have any questions before arrival.`
        );
        setAiDraftSummary(`Generated fasting & morning medication guidance.`);
      } else {
        setReplyText(
          `Hello ${firstName}, thank you for contacting us through the patient portal. Dr. Sterling's surgical team has reviewed your chart notes and confirmed all details for your upcoming procedure. Please let us know if you experience any changes in symptoms prior to arrival.`
        );
        setAiDraftSummary(`Generated empathetic clinical triage response.`);
      }

      if (onShowToast) {
        onShowToast('✨ Nightingale AI drafted context-aware reply.');
      }
    }, 450);
  };

  const totalInboundCount = patientInboundMessages.length;
  const unreadCount = unreadMessages.length;
  const clinicalCount = patientInboundMessages.filter((m) => m.category === 'Clinical Question').length;
  const refillCount = patientInboundMessages.filter((m) => m.category === 'Prescription Refill').length;
  const billingCount = patientInboundMessages.filter((m) => m.category === 'Billing').length;

  // Email-client-style folder list — kept intentionally short & scannable
  const folderTabs: { key: typeof selectedTab; label: string; count: number; icon: React.ComponentType<{ className?: string }>; isAlert?: boolean }[] = [
    { key: 'ALL', label: 'All Inbound', count: totalInboundCount, icon: Inbox },
    { key: 'UNREAD', label: 'Unread', count: unreadCount, icon: AlertCircle, isAlert: unreadCount > 0 },
    { key: 'CLINICAL', label: 'Clinical', count: clinicalCount, icon: Stethoscope },
    { key: 'REFILL', label: 'Rx Refills', count: refillCount, icon: RefreshCw },
    { key: 'BILLING', label: 'Billing', count: billingCount, icon: FileText },
  ];

  return (
    <div className="space-y-5 animate-in fade-in duration-200">

      {/* Slim Header — no more oversized dark hero banner */}
      <div className="bg-white rounded-2xl border border-stone-200/90 shadow-2xs p-4 sm:p-5 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-[#DCEEE3] border border-[#E1E4DC] text-[#1F6E52] flex items-center justify-center shadow-2xs">
            <Inbox className="w-5 h-5" />
          </div>
          <div>
            <h1 className="text-base font-bold text-stone-900">Messages</h1>
            <p className="text-xs text-stone-500 font-medium">
              Patient portal inbox · {totalInboundCount} conversation{totalInboundCount === 1 ? '' : 's'}
              {unreadCount > 0 ? ` · ${unreadCount} unread` : ''}
            </p>
          </div>
        </div>
        {unreadCount > 0 && (
          <button
            type="button"
            onClick={handleMarkAllRead}
            className="px-3 py-1.5 rounded-xl bg-[#1F6E52] hover:bg-[#17553F] text-white text-xs font-bold flex items-center gap-1.5 shadow-xs transition-colors cursor-pointer"
          >
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>Mark All Read</span>
          </button>
        )}
      </div>

      {/* Three-Pane Email-Client Layout: Folders / Message List / Reading Pane */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-start">

        {/* Pane 1: Folders (2 cols) */}
        <div className="lg:col-span-2 space-y-3">
          <div className="bg-white rounded-2xl border border-stone-200/90 shadow-2xs p-2 space-y-0.5">
            {folderTabs.map((tab) => {
              const isActive = selectedTab === tab.key;
              const Icon = tab.icon;
              return (
                <button
                  key={tab.key}
                  type="button"
                  onClick={() => setSelectedTab(tab.key)}
                  className={`w-full flex items-center justify-between gap-2 px-3 py-2 rounded-xl text-xs font-bold transition-colors cursor-pointer ${
                    isActive ? 'bg-[#DCEEE3] text-[#1B4332]' : 'text-stone-600 hover:bg-stone-50'
                  }`}
                >
                  <span className="flex items-center gap-2">
                    <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-[#1F6E52]' : 'text-stone-400'}`} />
                    <span>{tab.label}</span>
                  </span>
                  <span
                    className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono font-bold ${
                      isActive
                        ? 'bg-white text-[#1B4332]'
                        : tab.isAlert
                        ? 'bg-amber-200 text-amber-950'
                        : 'bg-stone-100 text-stone-600'
                    }`}
                  >
                    {tab.count}
                  </span>
                </button>
              );
            })}
          </div>

          <div className="bg-white rounded-2xl border border-stone-200/90 shadow-2xs p-3 space-y-1.5">
            <label className="text-[10px] font-bold text-stone-400 uppercase tracking-wider block">Provider</label>
            <select
              value={selectedProviderFilter}
              onChange={(e) => setSelectedProviderFilter(e.target.value)}
              className="w-full bg-stone-50 border border-stone-200 rounded-lg px-2 py-1.5 text-[11px] font-semibold text-stone-700 focus:outline-hidden focus:ring-2 focus:ring-[#1F6E52]"
            >
              <option value="ALL">All Providers</option>
              <option value="sterling">Dr. Sterling</option>
              <option value="mercer">Dr. Mercer</option>
              <option value="cruz">Dr. Cruz</option>
              <option value="chen">Dr. Chen</option>
            </select>
          </div>
        </div>

        {/* Pane 2: Message List (4 cols) */}
        <div className="lg:col-span-4 bg-white rounded-2xl border border-stone-200/90 shadow-2xs overflow-hidden flex flex-col">
          <div className="p-3 border-b border-stone-200/80">
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search messages..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-8 pr-3 py-1.5 bg-stone-50 border border-stone-200 rounded-lg text-xs font-medium text-stone-900 placeholder:text-stone-400 focus:outline-hidden focus:ring-2 focus:ring-[#1F6E52]"
              />
              {searchQuery && (
                <button
                  type="button"
                  onClick={() => setSearchQuery('')}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 text-xs text-stone-400 hover:text-stone-600 font-bold cursor-pointer"
                >
                  ✕
                </button>
              )}
            </div>
          </div>

          <div className="flex-1 overflow-y-auto divide-y divide-stone-100 max-h-[640px]">
            {filteredMessages.length === 0 ? (
              <div className="p-8 text-center space-y-2">
                <Inbox className="w-7 h-7 text-stone-300 mx-auto" />
                <p className="text-xs font-bold text-stone-600">No messages match your filter</p>
                <p className="text-[11px] text-stone-400">Try clearing the search or choosing a different folder.</p>
              </div>
            ) : (
              filteredMessages.map((msg) => {
                const isSelected = activeMessage?.id === msg.id;
                return (
                  <button
                    key={msg.id}
                    type="button"
                    onClick={() => setActiveMessageId(msg.id)}
                    className={`w-full text-left px-4 py-3 flex items-start gap-2.5 transition-colors cursor-pointer ${
                      isSelected ? 'bg-[#DCEEE3]/50' : msg.read ? 'hover:bg-stone-50' : 'bg-[#FBF3E6]/50 hover:bg-[#FBF3E6]'
                    }`}
                  >
                    <span className={`w-1.5 h-1.5 rounded-full mt-1.5 shrink-0 ${msg.read ? '' : 'bg-[#C98A34]'}`} />
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center justify-between gap-2">
                        <span className={`text-xs truncate ${msg.read ? 'font-semibold text-stone-700' : 'font-bold text-stone-900'}`}>
                          {msg.senderName}
                        </span>
                        <span className="text-[10px] text-stone-400 shrink-0 font-mono">{msg.date || msg.timestamp}</span>
                      </div>
                      {msg.category && (
                        <span className="text-[9.5px] font-bold uppercase tracking-wide text-[#1F6E52]">{msg.category}</span>
                      )}
                      <p className={`text-[11.5px] truncate mt-0.5 ${msg.read ? 'text-stone-500' : 'text-stone-700 font-medium'}`}>
                        {msg.content}
                      </p>
                    </div>
                  </button>
                );
              })
            )}
          </div>
        </div>

        {/* Pane 3: Reading Pane + Reply Composer (6 cols) */}
        <div className="lg:col-span-6">
          {activeMessage ? (
            <div className="bg-white rounded-2xl border border-stone-200/90 shadow-2xs overflow-hidden flex flex-col">

              {/* Thread Header */}
              <div className="p-4 border-b border-stone-200/80 flex flex-wrap items-start justify-between gap-3">
                <div className="min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <h3 className="text-sm font-bold text-stone-900 truncate">{activeMessage.senderName}</h3>
                    {!activeMessage.read && (
                      <span className="px-1.5 py-0.2 rounded text-[9px] font-black bg-[#C98A34] text-white uppercase tracking-wider">
                        Unread
                      </span>
                    )}
                  </div>
                  <p className="text-[11px] text-stone-500 font-medium mt-0.5 truncate">
                    MRN #{activeMessage.patientId}
                    {activeMessage.category ? ` · ${activeMessage.category}` : ''}
                    {associatedCase ? ` · ${associatedCase.procedure}` : ''}
                  </p>
                </div>

                <div className="flex items-center gap-1.5 shrink-0">
                  <button
                    type="button"
                    onClick={() => handleToggleRead(activeMessage)}
                    className="p-1.5 bg-stone-50 hover:bg-stone-100 border border-stone-200 rounded-lg text-stone-600 transition-colors cursor-pointer"
                    title={activeMessage.read ? 'Mark as Unread' : 'Mark as Read'}
                  >
                    {activeMessage.read ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5 text-[#C98A34]" />}
                  </button>
                  <button
                    type="button"
                    onClick={() => handleOpenChart(activeMessage.patientId)}
                    className="px-3 py-1.5 bg-[#1F6E52] hover:bg-[#17553F] text-white rounded-lg text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer shadow-2xs"
                    title="Open Full EHR Patient Chart"
                  >
                    <FileText className="w-3.5 h-3.5" />
                    <span>Open Chart</span>
                  </button>
                </div>
              </div>

              {/* Message Thread Flow */}
              <div className="p-4 space-y-3 overflow-y-auto bg-stone-50/40 max-h-[380px]">
                {activeThread.map((item) => {
                  const isStaff = item.sender === 'provider';
                  return (
                    <div key={item.id} className={`flex flex-col ${isStaff ? 'items-end' : 'items-start'} space-y-1`}>
                      <div className="flex items-center gap-1.5 text-[11px] text-stone-500 font-medium px-1">
                        <span className="font-bold text-stone-800">{item.senderName}</span>
                        <span>({isStaff ? item.senderTitle || 'Clinical Staff' : 'Patient'})</span>
                        <span>·</span>
                        <span>{item.date || 'Today'} {item.timestamp}</span>
                      </div>

                      <div
                        className={`p-3.5 rounded-2xl max-w-lg text-xs leading-relaxed font-medium shadow-2xs ${
                          isStaff
                            ? 'bg-[#1F6E52] text-white rounded-tr-xs'
                            : 'bg-white border border-stone-200 text-stone-800 rounded-tl-xs'
                        }`}
                      >
                        <p className="whitespace-pre-line">{item.content}</p>

                        {item.attachment && (
                          <div
                            className={`mt-2.5 p-2 rounded-xl flex items-center justify-between text-[11px] font-medium ${
                              isStaff
                                ? 'bg-[#17553F] text-[#DCEEE3] border border-[#17553F]'
                                : 'bg-stone-100 text-stone-700 border border-stone-200'
                            }`}
                          >
                            <div className="flex items-center gap-1.5">
                              <Paperclip className="w-3.5 h-3.5" />
                              <span className="font-bold">{item.attachment.name}</span>
                            </div>
                            <span className="text-[10px] opacity-75">{item.attachment.size}</span>
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Reply Composer — compact toolbar; templates & AI draft tuck away until needed */}
              <form onSubmit={handleSendReply} className="border-t border-stone-200/80 p-3 space-y-2">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-1.5 text-[11px]">
                    <span className="text-stone-400 font-semibold">Replying as:</span>
                    <select
                      value={selectedStaffAuthor}
                      onChange={(e) => {
                        setSelectedStaffAuthor(e.target.value);
                        if (e.target.value.includes('Sterling')) {
                          setSelectedStaffRole('Attending Surgeon & Medical Director');
                        } else if (e.target.value.includes('Mercer')) {
                          setSelectedStaffRole('Attending Facial Surgeon');
                        } else {
                          setSelectedStaffRole('Lead Surgical Coordinator, RN');
                        }
                      }}
                      className="bg-stone-50 border border-stone-200 rounded-lg px-2 py-1 text-[11px] font-semibold text-stone-700 focus:outline-hidden focus:ring-2 focus:ring-[#1F6E52]"
                    >
                      <option value="Dr. Alistair Sterling, MD">Dr. Alistair Sterling, MD</option>
                      <option value="Dr. Julian Mercer, MD">Dr. Julian Mercer, MD</option>
                      <option value="Nurse Evelyn Brooks, RN">Nurse Evelyn Brooks, RN</option>
                    </select>
                  </div>

                  <div className="flex items-center gap-1.5 flex-wrap">
                    <button
                      type="button"
                      onClick={() => setShowTemplates((v) => !v)}
                      className={`px-2 py-1 rounded-lg text-[10.5px] font-bold flex items-center gap-1 transition-colors cursor-pointer border ${
                        showTemplates ? 'bg-stone-200 text-stone-900 border-stone-300' : 'bg-stone-50 hover:bg-stone-100 text-stone-600 border-stone-200'
                      }`}
                    >
                      <Layers className="w-3 h-3" />
                      <span>Templates</span>
                    </button>
                    <button
                      type="button"
                      onClick={handleGenerateAiDraft}
                      disabled={isGeneratingAiDraft}
                      className="px-2 py-1 rounded-lg text-[10.5px] font-bold flex items-center gap-1 transition-colors cursor-pointer border bg-[#E7F1F3] hover:bg-[#DCEEF1] text-[#1D4E5A] border-[#3E8FA6]/50 disabled:opacity-50"
                    >
                      <Sparkles className="w-3 h-3 text-[#3E8FA6]" />
                      <span>{isGeneratingAiDraft ? 'Drafting…' : 'AI Draft'}</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setSelectedAttachment({ name: 'PreOp_Surgical_Instructions_Packet.pdf', size: '1.4 MB' });
                        if (onShowToast) onShowToast('Attached Pre-Op Instructions PDF.');
                      }}
                      className="px-2 py-1 rounded-lg text-[10.5px] font-bold flex items-center gap-1 transition-colors cursor-pointer border bg-stone-50 hover:bg-stone-100 text-stone-600 border-stone-200"
                    >
                      <Paperclip className="w-3 h-3" />
                      <span>Attach</span>
                    </button>
                    <label className="px-2 py-1 rounded-lg text-[10.5px] font-bold flex items-center gap-1.5 border bg-stone-50 text-stone-600 border-stone-200 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={sendSmsNotification}
                        onChange={(e) => setSendSmsNotification(e.target.checked)}
                        className="rounded border-stone-300 text-[#1F6E52] focus:ring-[#1F6E52]"
                      />
                      <span>SMS</span>
                    </label>
                  </div>
                </div>

                {showTemplates && (
                  <div className="flex flex-wrap gap-1.5 p-2 bg-stone-50 rounded-xl border border-stone-200">
                    {clinicalTemplates.map((tpl, i) => (
                      <button
                        key={i}
                        type="button"
                        onClick={() => {
                          setReplyText(tpl.text);
                          setShowTemplates(false);
                          if (onShowToast) onShowToast(`Loaded template: "${tpl.title}"`);
                        }}
                        className="px-2.5 py-1 bg-white hover:bg-[#DCEEE3]/60 border border-stone-200 rounded-lg text-[10.5px] font-semibold text-stone-700 transition-colors cursor-pointer"
                      >
                        {tpl.title}
                      </button>
                    ))}
                  </div>
                )}

                {aiDraftSummary && (
                  <div className="p-2 bg-[#DCEEE3]/70 border border-[#1F6E52]/30 rounded-lg flex items-center justify-between text-[11px] text-[#1B4332] font-medium">
                    <div className="flex items-center gap-1.5">
                      <Check className="w-3.5 h-3.5 text-[#1F6E52]" />
                      <span>{aiDraftSummary}</span>
                    </div>
                    <button type="button" onClick={() => setAiDraftSummary(null)} className="text-[#1F6E52] hover:text-[#17553F] font-bold text-xs cursor-pointer">
                      ✕
                    </button>
                  </div>
                )}

                {selectedAttachment && (
                  <div className="flex items-center justify-between p-2 bg-stone-100 rounded-lg text-[11px] text-stone-800 font-medium">
                    <div className="flex items-center gap-1.5">
                      <Paperclip className="w-3.5 h-3.5 text-stone-500" />
                      <span>{selectedAttachment.name} ({selectedAttachment.size})</span>
                    </div>
                    <button type="button" onClick={() => setSelectedAttachment(null)} className="text-stone-400 hover:text-stone-700 font-bold cursor-pointer">
                      ✕
                    </button>
                  </div>
                )}

                <div className="flex items-end gap-2">
                  <textarea
                    rows={3}
                    value={replyText}
                    onChange={(e) => setReplyText(e.target.value)}
                    placeholder={`Reply to ${activeMessage.senderName}...`}
                    className="flex-1 p-3 bg-stone-50 border border-stone-200 rounded-xl text-xs font-medium text-stone-900 focus:outline-hidden focus:ring-2 focus:ring-[#1F6E52] focus:bg-white leading-relaxed placeholder:text-stone-400 resize-none transition-all"
                  />
                  <button
                    type="submit"
                    disabled={!replyText.trim()}
                    className="h-full px-4 py-3 bg-[#1F6E52] hover:bg-[#17553F] disabled:opacity-40 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all shadow-xs cursor-pointer disabled:cursor-not-allowed shrink-0"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>Send</span>
                  </button>
                </div>
              </form>
            </div>
          ) : (
            <div className="p-12 bg-white rounded-2xl border border-stone-200 text-center space-y-3">
              <MessageSquare className="w-10 h-10 text-stone-300 mx-auto" />
              <h3 className="text-sm font-bold text-stone-700">Select a Message</h3>
              <p className="text-xs text-stone-500 max-w-sm mx-auto">
                Choose a conversation from the inbox to read the full thread and send a reply.
              </p>
            </div>
          )}
        </div>

      </div>

    </div>
  );
};
