import React, { useEffect, useMemo, useState } from 'react';
import {
  X,
  ClipboardList,
  ClipboardCheck,
  Syringe,
  Stethoscope,
  CheckCircle2,
  FileClock,
  FileText,
  PenTool,
  Lock,
  ShieldCheck,
  Mic,
} from 'lucide-react';
import type { PatientCase } from '../types';
import type { NursingHtmlForm } from '../data/nursingHtmlForms';
import type { IntakeHtmlForm } from '../data/intakeHtmlForms';
import { SignaturePad } from './SignaturePad';
import { VoiceDictationButton } from './VoiceDictationButton';
import { getPrefilledIntakeHtml } from '../utils/formPrefill';
import { PdfFormViewer } from './PdfFormViewer';
import { getPdfFormDocument } from '../data/pdfFormDocuments';
import { computePreopEvalPrefill } from '../utils/pdfPrefillMap';
import { loadStoredPdfDoc } from '../utils/pdfFormEngine';

// Documents migrated to the real-PDF viewer (see pdfFormDocuments.ts) —
// looked up by the existing HTML-catalog id so this is a drop-in swap at the
// render step only; everything else about how these docs are listed,
// counted, and gated for signature is untouched.
const PDF_BACKED_DOC_ID: Record<string, string> = {
  'form-anesthesia': 'pdf-anesthesia-questionnaire',
  'nursing-anesthesia-preop-evaluation': 'pdf-anesthesia-preop-evaluation',
};

export type ClinicalWorkflowRole = 'Nursing' | 'Anesthesia' | 'Surgeons';

interface ClinicalWorkflowPageProps {
  role: ClinicalWorkflowRole;
  patient: PatientCase;
  nursingForms: NursingHtmlForm[];
  intakeForms: IntakeHtmlForm[];
  onClose: () => void;
}

// Which existing nursing/intake HTML forms belong to each role's workflow, in
// display order, per the "Clinical Workflow Buttons" spec (section 4 of the
// Patient Journey Workflow Add-On Features document). Nursing sees the full
// perioperative packet; Anesthesia and Surgeons each see a role-scoped subset
// plus one net-new document specific to that role.
const NURSING_FORM_IDS: Record<ClinicalWorkflowRole, string[]> = {
  Nursing: [
    'nursing-preop-checklist',
    'nursing-perioperative-assessment',
    'nursing-surgical-checklist',
    'nursing-consent-operation',
    'nursing-patient-consent-anesthesia',
    'nursing-doctors-standing-orders',
    'nursing-brief-op-summary',
    'nursing-recovery-room-record',
    'nursing-postop-instructions',
    'nursing-anesthesia-preop-evaluation',
    'nursing-liposuction-treatment-areas',
  ],
  Anesthesia: ['nursing-anesthesia-preop-evaluation', 'nursing-patient-consent-anesthesia'],
  Surgeons: ['nursing-consent-operation', 'nursing-doctors-standing-orders', 'nursing-brief-op-summary'],
};

const INTAKE_FORM_IDS: Record<ClinicalWorkflowRole, string[]> = {
  Nursing: [],
  Anesthesia: ['form-medical', 'form-anesthesia'],
  Surgeons: ['form-medical'],
};

type NativeDocKind = 'operative-report' | 'coming-soon';
interface NativeDoc {
  id: string;
  title: string;
  kind: NativeDocKind;
  note?: string;
}

const NATIVE_DOCS: Record<ClinicalWorkflowRole, NativeDoc[]> = {
  Nursing: [],
  Anesthesia: [{ id: 'anesthesia-record', title: 'Anesthesia Record', kind: 'coming-soon', note: 'To be added later' }],
  Surgeons: [{ id: 'detailed-operative-report', title: 'Detailed Operative Report', kind: 'operative-report' }],
};

const ROLE_META: Record<ClinicalWorkflowRole, { icon: React.ComponentType<{ className?: string }>; color: string; description: string }> = {
  Nursing: {
    icon: ClipboardList,
    color: '#1F6E52',
    description: 'Verify medical history, allergies, medications, planned procedure, post-op ride & NPO status, surgical & anesthesia consents, and pre-op orders.',
  },
  Anesthesia: {
    icon: Syringe,
    color: '#1F6E52',
    description: 'Review intake information, anesthesia questionnaire, pre-op evaluation, anesthesia consent, and the anesthesia record.',
  },
  Surgeons: {
    icon: Stethoscope,
    color: '#1F6E52',
    description: 'Review medical history, surgical consent, standing orders, brief operative summary, and dictate the detailed operative report.',
  },
};

type WorkflowDoc =
  | { source: 'nursing'; form: NursingHtmlForm }
  | { source: 'intake'; form: IntakeHtmlForm }
  | { source: 'native'; form: NativeDoc };

function docKey(d: WorkflowDoc): string {
  return `${d.source}:${d.form.id}`;
}

// Matches the Patient Portal's check-in form viewer: a simple list of
// documents that opens into one full-screen page per document, with an
// integrated signature & attestation panel at the bottom of the form itself
// (rather than a permanent side-by-side split view). Tablet-friendly by
// design — no persistent sidebar competing for width.
export const ClinicalWorkflowPage: React.FC<ClinicalWorkflowPageProps> = ({ role, patient, nursingForms, intakeForms, onClose }) => {
  const docs: WorkflowDoc[] = useMemo(() => {
    const nursingDocs: WorkflowDoc[] = NURSING_FORM_IDS[role]
      .map((id) => nursingForms.find((f) => f.id === id))
      .filter((f): f is NursingHtmlForm => Boolean(f))
      .map((form) => ({ source: 'nursing', form }));
    const intakeDocs: WorkflowDoc[] = INTAKE_FORM_IDS[role]
      .map((id) => intakeForms.find((f) => f.id === id))
      .filter((f): f is IntakeHtmlForm => Boolean(f))
      .map((form) => ({ source: 'intake', form }));
    const nativeDocs: WorkflowDoc[] = NATIVE_DOCS[role].map((form) => ({ source: 'native', form }));
    // Spec order: intake-sourced items first (Medical History / Anesthesia Questionnaire),
    // then the role's clinical forms, then any net-new native document last.
    return [...intakeDocs, ...nursingDocs, ...nativeDocs];
  }, [role, nursingForms, intakeForms]);

  const [activeKey, setActiveKey] = useState<string | null>(null);
  const [signedKeys, setSignedKeys] = useState<Set<string>>(new Set());
  const [signedMeta, setSignedMeta] = useState<Record<string, { signedBy: string; date: string }>>({});
  const [reportText, setReportText] = useState('');

  // Draft state for whichever single document is currently open — reset each
  // time a different document is opened, mirroring the portal's pattern.
  const [draftSignature, setDraftSignature] = useState<string | null>(null);
  const [draftAgreed, setDraftAgreed] = useState(false);

  useEffect(() => {
    setDraftSignature(null);
    setDraftAgreed(false);
  }, [activeKey]);

  const activeDoc = docs.find((d) => docKey(d) === activeKey) || null;
  const meta = ROLE_META[role];
  const RoleIcon = meta.icon;

  const isDocSigned = (d: WorkflowDoc) => {
    const key = docKey(d);
    if (signedKeys.has(key)) return true;
    if (d.source === 'native') return false;
    const pdfDocId = PDF_BACKED_DOC_ID[d.form.id];
    if (pdfDocId) return loadStoredPdfDoc(patient.patientId, pdfDocId)?.status === 'LOCKED';
    return d.form.status === 'Signed & Verified' || d.form.status === 'Completed in Portal';
  };
  const isComingSoon = (d: WorkflowDoc) => d.source === 'native' && d.form.kind === 'coming-soon';

  // Whether a document needs the full legal e-signature panel (canvas
  // signature + attestation + audit trail) vs. a lightweight "Mark as
  // Reviewed" completion. Driven by the explicit `requiresSignature` flag on
  // each form template (see intakeHtmlForms.ts / nursingHtmlForms.ts) — set
  // per document rather than guessed at render time, so it stays correct
  // however a given practice's form library is put together. The operative
  // report is native (dictated, not template-backed) and always needs a
  // surgeon signature; the "coming soon" placeholder has no content to act on.
  const docRequiresSignature = (d: WorkflowDoc): boolean => {
    if (d.source === 'native') return d.form.kind === 'operative-report';
    return d.form.requiresSignature;
  };

  const signableDocs = docs.filter((d) => !isComingSoon(d));
  const signedCount = signableDocs.filter(isDocSigned).length;
  const allSigned = signableDocs.length > 0 && signedCount === signableDocs.length;

  const submitActiveDoc = () => {
    if (!activeKey || !draftSignature || !draftAgreed) return;
    const dateStr = new Date().toLocaleDateString('en-US', { month: 'short', day: '2-digit', year: 'numeric' });
    setSignedKeys((prev) => new Set(prev).add(activeKey));
    setSignedMeta((prev) => ({
      ...prev,
      [activeKey]: { signedBy: patient.name, date: dateStr },
    }));
    setActiveKey(null);
  };

  // Lightweight completion path for documents that don't require a legal
  // signature — records who reviewed it and when, same as the signed path,
  // just without the canvas signature / attestation checkbox / audit trail.
  const markActiveDocReviewed = () => {
    if (!activeKey) return;
    const dateStr = new Date().toLocaleDateString('en-US', { month: 'short', day: '2-digit', year: 'numeric' });
    const reviewer =
      role === 'Surgeons' ? patient.surgeon || 'Surgical Staff'
      : role === 'Anesthesia' ? patient.anesthesiologist || 'Anesthesia Staff'
      : 'Nursing Staff';
    setSignedKeys((prev) => new Set(prev).add(activeKey));
    setSignedMeta((prev) => ({
      ...prev,
      [activeKey]: { signedBy: reviewer, date: dateStr },
    }));
    setActiveKey(null);
  };

  // ============================================================
  // SINGLE DOCUMENT VIEW — matches the portal's full-screen form viewer
  // ============================================================
  if (activeDoc) {
    const key = docKey(activeDoc);
    const signed = isDocSigned(activeDoc);
    const meta2 = signedMeta[key];
    const needsSignature = docRequiresSignature(activeDoc);

    // PDF-backed documents (see pdfFormDocuments.ts) render through the real
    // PDF viewer instead of the HTML-template iframe — a real AcroForm,
    // pen tool, and Save (Editable) / Save & Lock, matching the practice's
    // existing ASPX viewer. Reviewing/signing happens inside that viewer's
    // own Save & Lock step, so it bypasses this page's separate signature
    // panel entirely.
    const pdfDocId = activeDoc.source !== 'native' ? PDF_BACKED_DOC_ID[activeDoc.form.id] : undefined;
    const pdfDoc = pdfDocId ? getPdfFormDocument(pdfDocId) : undefined;
    if (pdfDoc) {
      const signerName =
        role === 'Surgeons' ? patient.surgeon || 'Surgical Staff'
        : role === 'Anesthesia' ? patient.anesthesiologist || 'Anesthesia Staff'
        : 'Nursing Staff';
      const prefill =
        pdfDoc.id === 'pdf-anesthesia-preop-evaluation' ? computePreopEvalPrefill(patient.patientId) : undefined;
      return (
        <PdfFormViewer
          patientId={patient.patientId}
          documentId={pdfDoc.id}
          title={pdfDoc.title}
          pdfUrl={pdfDoc.pdfUrl}
          signerName={signerName}
          prefill={prefill}
          onClose={() => setActiveKey(null)}
        />
      );
    }

    return (
      <div className="fixed inset-0 z-[99999] bg-stone-100 flex flex-col w-screen h-screen overflow-y-auto animate-in fade-in duration-150">
        {/* Top Control Bar with Close & Status — matches portal's dark sticky header */}
        <div className="sticky top-0 z-[100000] bg-slate-900/95 border-b border-slate-700 px-4 sm:px-6 py-3 flex items-center justify-between backdrop-blur-md shadow-lg text-white">
          <div className="flex items-center gap-3 min-w-0">
            <div className="p-2 rounded-xl bg-teal-500/20 border border-teal-500/40 text-teal-300 shrink-0">
              <FileText className="w-4 h-4" />
            </div>
            <div className="min-w-0">
              <h3 className="font-bold text-xs sm:text-sm text-white flex items-center gap-2 flex-wrap">
                <span className="truncate">{activeDoc.form.title}</span>
                {!isComingSoon(activeDoc) && (
                  <span
                    className={`text-[10px] px-2 py-0.5 rounded-full border font-semibold shrink-0 ${
                      signed ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40' : 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                    }`}
                  >
                    {signed ? (needsSignature ? '✓ Completed & Signed' : '✓ Reviewed') : needsSignature ? 'Action Required' : 'Review Required'}
                  </span>
                )}
              </h3>
              <p className="text-[11px] text-slate-400 font-mono hidden sm:block truncate">
                {activeDoc.source === 'intake' ? activeDoc.form.fileName : activeDoc.source === 'nursing' ? activeDoc.form.fileName : 'Dictated Report'}
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={() => setActiveKey(null)}
            className="px-3.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-xl text-xs font-bold transition-colors flex items-center gap-1.5 cursor-pointer border border-slate-700 shadow-xs group shrink-0"
          >
            <X className="w-4 h-4 text-slate-400 group-hover:text-white" />
            <span>Close Form</span>
          </button>
        </div>

        <div className="w-full flex-1 bg-stone-100 p-2 sm:p-6 flex flex-col items-center gap-6 min-h-screen">
          <div className="w-full max-w-4xl bg-white rounded-2xl shadow-xl border border-stone-200 p-3 sm:p-6 my-2 relative">

            {/* Document body */}
            {isComingSoon(activeDoc) ? (
              <div className="text-center py-16 space-y-2">
                <FileClock className="w-8 h-8 text-amber-500 mx-auto" />
                <h3 className="text-sm font-bold text-stone-900">{(activeDoc.form as NativeDoc).note}</h3>
                <p className="text-xs text-stone-500 font-medium">This document is planned but not yet available in this build.</p>
              </div>
            ) : activeDoc.source === 'native' && activeDoc.form.kind === 'operative-report' ? (
              <div className="space-y-3">
                <div className="flex items-center justify-between gap-2">
                  <h3 className="text-sm font-bold text-stone-900">Detailed Operative Report</h3>
                  <VoiceDictationButton
                    label="Dictate Report"
                    onTranscript={(text) => setReportText((prev) => (prev ? `${prev} ${text}` : text))}
                  />
                </div>
                <textarea
                  value={reportText}
                  onChange={(e) => setReportText(e.target.value)}
                  rows={14}
                  placeholder="Dictate or type the detailed operative report: pre-op & post-op diagnosis, procedure(s) performed, indications, findings, technique, estimated blood loss, specimens, complications, and disposition..."
                  className="w-full p-3 border border-stone-300 rounded-xl text-sm font-medium text-stone-800 focus:outline-none focus:ring-2 focus:ring-teal-500 leading-relaxed"
                />
              </div>
            ) : activeDoc.source !== 'native' ? (
              // HTML-embedded form, rendered in an iframe so its own global CSS
              // can't leak out and restyle the attestation panel below it.
              <iframe
                title={activeDoc.form.title}
                // Pre-filled from the patient's chart (name, DOB, allergies, meds, past
                // medical/surgical/anesthesia history, etc.) when on file from a prior
                // visit, so staff only need to review and confirm rather than
                // re-collect everything from scratch. A first-time patient has no
                // medicalProfile on record, so their forms open blank as usual.
                srcDoc={getPrefilledIntakeHtml(activeDoc.form.htmlTemplate, patient)}
                sandbox="allow-forms allow-scripts allow-modals"
                className="w-full border-0"
                style={{ height: '1400px' }}
              />
            ) : null}

            {/* Signature & Attestation Section — integrated at the bottom of the
                single document page, matching the patient portal exactly */}
            {!isComingSoon(activeDoc) && (
              <div className="mt-8 pt-6 border-t-2 border-slate-200/90">
                {signed && needsSignature ? (
                  <div className="p-6 bg-emerald-50/80 border-2 border-emerald-400/60 rounded-2xl space-y-3.5 text-xs text-emerald-950 shadow-xs">
                    <div className="flex items-center justify-between flex-wrap gap-2">
                      <div className="flex items-center gap-2 text-emerald-900 font-bold text-sm">
                        <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                        <span>Provider Signature &amp; Legal Attestation</span>
                      </div>
                      <span className="bg-emerald-200/80 text-emerald-900 font-bold px-2.5 py-0.5 rounded-full text-[10.5px]">
                        Completed &amp; Verified
                      </span>
                    </div>

                    <p className="leading-relaxed text-emerald-900">
                      This document has been digitally completed, attested, and legally executed. A verified copy is securely filed in the patient's Office Intelligence chart.
                    </p>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 border-t border-emerald-200/80 font-mono text-[11px]">
                      <div>
                        <span className="text-emerald-700 block font-sans font-bold text-[10px] uppercase">Legally Signed By</span>
                        <span className="font-bold text-emerald-950">{meta2?.signedBy || 'On file'}</span>
                      </div>
                      <div>
                        <span className="text-emerald-700 block font-sans font-bold text-[10px] uppercase">Execution Timestamp</span>
                        <span className="font-bold text-emerald-950">{meta2?.date || 'Verified'}</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 pt-1 text-[10.5px] text-emerald-800 font-mono">
                      <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
                      <span>Audit Trail: Cryptographic SHA-256 Signature Sealed into EHR Chart</span>
                    </div>
                  </div>
                ) : signed && !needsSignature ? (
                  <div className="p-6 bg-emerald-50/80 border-2 border-emerald-400/60 rounded-2xl space-y-3.5 text-xs text-emerald-950 shadow-xs">
                    <div className="flex items-center justify-between flex-wrap gap-2">
                      <div className="flex items-center gap-2 text-emerald-900 font-bold text-sm">
                        <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                        <span>Document Review</span>
                      </div>
                      <span className="bg-emerald-200/80 text-emerald-900 font-bold px-2.5 py-0.5 rounded-full text-[10.5px]">
                        Reviewed &amp; Filed
                      </span>
                    </div>

                    <p className="leading-relaxed text-emerald-900">
                      This document type doesn't require a signature. It has been reviewed and filed to the patient's Office Intelligence chart.
                    </p>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 border-t border-emerald-200/80 font-mono text-[11px]">
                      <div>
                        <span className="text-emerald-700 block font-sans font-bold text-[10px] uppercase">Reviewed By</span>
                        <span className="font-bold text-emerald-950">{meta2?.signedBy || 'On file'}</span>
                      </div>
                      <div>
                        <span className="text-emerald-700 block font-sans font-bold text-[10px] uppercase">Review Timestamp</span>
                        <span className="font-bold text-emerald-950">{meta2?.date || 'Verified'}</span>
                      </div>
                    </div>
                  </div>
                ) : needsSignature ? (
                  <div className="p-6 bg-slate-50 border-2 border-teal-500/40 rounded-2xl space-y-4 text-xs text-slate-900 shadow-md">
                    <div className="flex items-center gap-2 text-teal-900 font-bold text-sm">
                      <PenTool className="w-4 h-4 text-teal-600" />
                      <span>Provider Signature &amp; Legal Attestation</span>
                    </div>

                    <div className="p-3.5 bg-teal-50/70 border border-teal-200 rounded-xl text-xs text-teal-950 space-y-2">
                      <p className="leading-relaxed">
                        By signing below and submitting this document, I certify that all information provided is accurate and complete to the best of my knowledge.
                      </p>
                      <div className="flex items-center gap-2 pt-1 font-mono text-[11px] text-teal-800">
                        <Lock className="w-3.5 h-3.5 text-teal-600" />
                        <span>IP Address &amp; Time: {new Date().toLocaleDateString()} {new Date().toLocaleTimeString()} (Logged)</span>
                      </div>
                    </div>

                    <div className="space-y-3 pt-1">
                      <SignaturePad
                        label="Draw Your Signature"
                        signerName={role === 'Surgeons' ? patient.surgeon : role === 'Anesthesia' ? patient.anesthesiologist : undefined}
                        savedSignature={draftSignature}
                        onSave={setDraftSignature}
                      />

                      <label className="flex items-start gap-2.5 cursor-pointer pt-1">
                        <input
                          type="checkbox"
                          checked={draftAgreed}
                          onChange={(e) => setDraftAgreed(e.target.checked)}
                          className="w-4 h-4 rounded border-slate-300 text-teal-600 focus:ring-teal-500 mt-0.5"
                        />
                        <span className="text-xs text-slate-700 leading-relaxed font-medium">
                          I acknowledge that my handwritten signature above constitutes a legally binding signature identical to an ink signature on paper.
                        </span>
                      </label>

                      <div className="flex items-center gap-2 pt-1">
                        <Mic className="w-3.5 h-3.5 text-stone-400 shrink-0" />
                        <VoiceDictationButton label="Dictate Clinical Note" onTranscript={(text) => setReportText((prev) => (prev ? `${prev} ${text}` : text))} />
                      </div>
                    </div>

                    <div className="pt-3 border-t border-slate-200 flex items-center justify-between">
                      <button
                        type="button"
                        onClick={() => setActiveKey(null)}
                        className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-xl text-xs font-bold transition-colors cursor-pointer"
                      >
                        Cancel
                      </button>

                      <button
                        type="button"
                        onClick={submitActiveDoc}
                        disabled={!draftSignature || !draftAgreed}
                        className="px-6 py-2.5 bg-teal-600 hover:bg-teal-700 disabled:bg-slate-300 disabled:cursor-not-allowed text-white rounded-xl text-xs font-bold shadow-md transition-all flex items-center gap-2 cursor-pointer"
                      >
                        <CheckCircle2 className="w-4 h-4" />
                        <span>Submit &amp; Sign to Chart</span>
                      </button>
                    </div>
                  </div>
                ) : (
                  // No signature required for this document — a lighter
                  // review-and-file action instead of the full signature pad.
                  <div className="p-6 bg-slate-50 border-2 border-slate-300 rounded-2xl space-y-4 text-xs text-slate-900 shadow-md">
                    <div className="flex items-center gap-2 text-slate-800 font-bold text-sm">
                      <ClipboardCheck className="w-4 h-4 text-slate-500" />
                      <span>Document Review</span>
                    </div>

                    <p className="leading-relaxed text-slate-600">
                      This document doesn't require a signature. Review its contents above, then mark it reviewed to file it to {patient.name}'s chart.
                    </p>

                    <div className="flex items-center gap-2">
                      <Mic className="w-3.5 h-3.5 text-stone-400 shrink-0" />
                      <VoiceDictationButton label="Dictate Clinical Note" onTranscript={(text) => setReportText((prev) => (prev ? `${prev} ${text}` : text))} />
                    </div>

                    <div className="pt-3 border-t border-slate-200 flex items-center justify-between">
                      <button
                        type="button"
                        onClick={() => setActiveKey(null)}
                        className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-xl text-xs font-bold transition-colors cursor-pointer"
                      >
                        Cancel
                      </button>

                      <button
                        type="button"
                        onClick={markActiveDocReviewed}
                        className="px-6 py-2.5 bg-slate-700 hover:bg-slate-800 text-white rounded-xl text-xs font-bold shadow-md transition-all flex items-center gap-2 cursor-pointer"
                      >
                        <CheckCircle2 className="w-4 h-4" />
                        <span>Mark as Reviewed</span>
                      </button>
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    );
  }

  // ============================================================
  // LIST VIEW — matches the portal's pre-arrival check-in list page
  // ============================================================
  return (
    <div className="fixed inset-0 z-[99999] bg-slate-50 flex flex-col w-screen h-screen overflow-y-auto animate-in fade-in duration-150">
      <div className="sticky top-0 z-[99999] bg-[#1F6E52] text-white px-4 sm:px-6 py-4 flex items-center justify-between shadow-lg">
        <div className="flex items-center gap-3 min-w-0">
          <div className="w-9 h-9 rounded-xl bg-white/15 border border-white/20 text-white flex items-center justify-center shrink-0">
            <RoleIcon className="w-4.5 h-4.5" />
          </div>
          <div className="min-w-0">
            <span className="text-[10px] font-mono uppercase tracking-wider text-teal-200">{role} Workflow</span>
            <h2 className="font-bold text-sm sm:text-base truncate">{patient.name} — {meta.description}</h2>
          </div>
        </div>
        <button
          onClick={onClose}
          className="p-2 rounded-xl text-teal-100 hover:text-white hover:bg-white/10 transition-colors cursor-pointer shrink-0"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      <div className="flex-1 max-w-3xl w-full mx-auto p-4 sm:p-8 space-y-4">
        <p className="text-xs sm:text-sm text-slate-600 font-medium">
          Tap a document to review, sign, and file it to {patient.name}'s chart. Each document opens in a full page.
        </p>

        <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-2xs flex items-center justify-between">
          <span className="text-xs sm:text-sm font-bold text-slate-800">{signedCount} / {signableDocs.length} documents completed</span>
          {allSigned && (
            <span className="px-3 py-1 rounded-full bg-emerald-100 text-emerald-800 border border-emerald-300 text-[11px] font-bold flex items-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5" />
              All documents signed
            </span>
          )}
        </div>

        <div className="space-y-2.5">
          {docs.length === 0 && (
            <div className="p-6 text-center text-sm text-stone-500 bg-white rounded-2xl border border-slate-200">No documents configured for this role yet.</div>
          )}
          {docs.map((d) => {
            const key = docKey(d);
            const signed = isDocSigned(d);
            const comingSoon = isComingSoon(d);
            return (
              <button
                key={key}
                onClick={() => setActiveKey(key)}
                className="w-full text-left p-4 bg-white rounded-2xl border border-slate-200 hover:border-teal-400 hover:shadow-2xs transition-all cursor-pointer flex items-center justify-between gap-3"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
                    comingSoon ? 'bg-amber-100 text-amber-700' : signed ? 'bg-emerald-100 text-emerald-700' : 'bg-slate-100 text-slate-500'
                  }`}>
                    {comingSoon ? <FileClock className="w-4.5 h-4.5" /> : <FileText className="w-4.5 h-4.5" />}
                  </div>
                  <div className="min-w-0">
                    <div className="text-sm font-bold text-slate-900 truncate">{d.form.title}</div>
                    <div className="text-[11px] text-slate-500 font-medium truncate">
                      {d.source === 'intake' ? `From Intake · ${d.form.category}` : d.source === 'nursing' ? d.form.category : comingSoon ? (d.form as NativeDoc).note : 'Dictated Report'}
                    </div>
                  </div>
                </div>
                <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full shrink-0 ${
                  comingSoon ? 'bg-amber-100 text-amber-800 border border-amber-300'
                    : signed ? 'bg-emerald-100 text-emerald-800 border border-emerald-300' : 'bg-amber-100 text-amber-800 border border-amber-300'
                }`}>
                  {comingSoon ? 'Coming Soon' : signed ? 'Completed' : 'Action Required'}
                </span>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
