import React, { useState, useEffect } from 'react';
import { 
  Sparkles, 
  Zap, 
  AlertTriangle, 
  CheckCircle2, 
  Clock, 
  Activity, 
  Users, 
  Calendar, 
  TrendingUp, 
  FileText, 
  ShieldCheck, 
  ArrowRight,
  RefreshCw,
  Sliders,
  DollarSign,
  Stethoscope,
  Maximize2,
  MessageSquare
} from 'lucide-react';
import { PatientCase } from '../types';
import { getUnreadCount, subscribeToMessageUpdates } from '../utils/portalMessageStore';

interface AIHomePageProps {
  cases: PatientCase[];
  onSelectPatient: (patient: PatientCase) => void;
  onOpenPatientChartById?: (patientId: string, sectionKey?: string) => void;
  onTriggerEKGFastTrack: (caseId: string) => void;
  onUpdateStage: (caseId: string, newStage: any) => void;
  onShowToast: (msg: string) => void;
  onNavigateTab: (tab: string) => void;
}

export const AIHomePage: React.FC<AIHomePageProps> = ({
  cases,
  onSelectPatient,
  onOpenPatientChartById,
  onTriggerEKGFastTrack,
  onUpdateStage,
  onShowToast,
  onNavigateTab
}) => {
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [selectedAIInsight, setSelectedAIInsight] = useState<string | null>(null);
  const [unreadMsgCount, setUnreadMsgCount] = useState<number>(() => getUnreadCount());

  useEffect(() => {
    setUnreadMsgCount(getUnreadCount());
    const unsub = subscribeToMessageUpdates(() => {
      setUnreadMsgCount(getUnreadCount());
    });
    return unsub;
  }, []);

  // Compute metrics
  const totalCases = cases.length;
  const clearedCases = cases.filter(c => c.readinessLevel === 'CLEARED').length;
  const holdCases = cases.filter(c => c.readinessLevel === 'NEEDS_ATTENTION' || c.readinessLevel === 'CRITICAL_HOLD').length;
  const avgReadiness = Math.round(cases.reduce((acc, c) => acc + c.readinessScore, 0) / (totalCases || 1));

  const handleRunFullAIScan = () => {
    setIsAnalyzing(true);
    onShowToast('Running Nightingale AI Full ASC Operations Scan...');
    
    setTimeout(() => {
      setIsAnalyzing(false);
      onShowToast('✨ AI Scan Complete: 2 schedule optimizations identified, 1 EKG cleared.');
    }, 2000);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      
      {/* Hero Operational Banner */}
      <div className="bg-[#14432E] p-6 md:p-8 rounded-2xl text-white shadow-xl border border-[#5B6B60] relative overflow-hidden">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-3 max-w-2xl">
            <div className="flex flex-wrap items-center gap-2">
              <div className="px-3 py-1 rounded-full bg-[#2F9E6E] text-[#E4F3EA] border border-[#1B4332] text-xs font-bold flex items-center gap-1.5 font-display">
                <Sparkles className="w-3.5 h-3.5 text-[#E4F3EA]" />
                <span>Nightingale AI Operational Suite v3.0</span>
              </div>
              <span className="text-xs font-semibold px-2.5 py-0.5 rounded-full bg-[#E4F3EA] text-[#1B4332] border border-[#E1E4DC] font-mono">
                Live ASC Telemetry
              </span>
            </div>

            <h1 className="text-2xl md:text-3xl font-bold tracking-tight text-white font-display">
              ASC Operations & Schedule Intelligence
            </h1>

            <p className="text-sm text-[#E1E4DC] leading-relaxed">
              Real-time surgical schedule coordination, automated pre-op clearances, OR turnover prediction, and anesthesia risk management powered by Nightingale AI.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
            <button
              onClick={handleRunFullAIScan}
              disabled={isAnalyzing}
              className="px-5 py-3 rounded-xl bg-[#2F9E6E] hover:bg-[#1B4332] text-white font-bold text-xs shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer font-sans"
            >
              {isAnalyzing ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin text-white" />
                  <span>Scanning ASC Schedule...</span>
                </>
              ) : (
                <>
                  <Zap className="w-4 h-4 text-[#FBEEDB] fill-[#FBEEDB]" />
                  <span>Run Full AI Operations Scan</span>
                </>
              )}
            </button>

            <button
              onClick={() => onNavigateTab('workflows')}
              className="px-4 py-3 rounded-xl bg-[#14432E] hover:bg-[#17553F] text-white font-bold text-xs border border-[#5B6B60] transition-all flex items-center justify-center gap-2 cursor-pointer font-sans"
            >
              <FileText className="w-4 h-4 text-[#E4F3EA]" />
              <span>Explore AI Workflows</span>
            </button>
          </div>
        </div>
      </div>

      {/* Metric Cards Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        <div className="p-5 bg-white rounded-xl border border-[#E1E4DC] shadow-2xs flex items-center justify-between">
          <div className="space-y-1">
            <span className="text-xs font-medium text-[#5B6B60] block">Total Scheduled Cases</span>
            <span className="text-2xl font-bold text-[#14432E] block font-display">{totalCases} Cases</span>
            <span className="text-[11px] font-semibold text-[#5B6B60] flex items-center gap-1 font-mono">
              <Calendar className="w-3 h-3 text-[#2F9E6E]" /> Today's OR Board
            </span>
          </div>
          <div className="w-12 h-12 rounded-xl bg-[#E4F3EA] border border-[#E1E4DC] flex items-center justify-center text-[#2F9E6E] shrink-0">
            <Users className="w-6 h-6" />
          </div>
        </div>

        <div className="p-5 bg-white rounded-xl border border-[#E1E4DC] shadow-2xs flex items-center justify-between">
          <div className="space-y-1">
            <span className="text-xs font-medium text-[#5B6B60] block">AI Clearance Index</span>
            <span className="text-2xl font-bold text-[#1B4332] block font-display">{avgReadiness}% Ready</span>
            <span className="text-[11px] font-semibold text-[#1B4332] flex items-center gap-1 font-mono">
              <ShieldCheck className="w-3 h-3" /> {clearedCases} Fully Cleared
            </span>
          </div>
          <div className="w-12 h-12 rounded-xl bg-[#E4F3EA] border border-[#E1E4DC] flex items-center justify-center text-[#1B4332] shrink-0">
            <CheckCircle2 className="w-6 h-6" />
          </div>
        </div>

        <div className="p-5 bg-white rounded-xl border border-[#E1E4DC] shadow-2xs flex items-center justify-between">
          <div className="space-y-1">
            <span className="text-xs font-medium text-[#5B6B60] block">Pre-Op Holds & Alerts</span>
            <span className="text-2xl font-bold text-[#7A4E17] block font-display">{holdCases} Holds</span>
            <span className="text-[11px] font-semibold text-[#7A4E17] flex items-center gap-1 font-mono">
              <AlertTriangle className="w-3 h-3" /> 1 Fast-track EKG hold
            </span>
          </div>
          <div className="w-12 h-12 rounded-xl bg-[#FBEEDB] border border-[#E1E4DC] flex items-center justify-center text-[#7A4E17] shrink-0">
            <Clock className="w-6 h-6" />
          </div>
        </div>

        {/* Patient Portal Messages Tile */}
        <div 
          onClick={() => {
            const el = document.getElementById('collective-portal-messages-section');
            if (el) el.scrollIntoView({ behavior: 'smooth' });
          }}
          className="p-5 bg-white rounded-xl border border-[#E1E4DC] shadow-2xs flex items-center justify-between cursor-pointer hover:border-[#2F9E6E] hover:shadow-md transition-all group"
        >
          <div className="space-y-1">
            <span className="text-xs font-medium text-[#5B6B60] block">Patient Portal Inbound</span>
            <span className="text-2xl font-bold text-[#14432E] block font-display">{unreadMsgCount} Unread</span>
            <span className="text-[11px] font-semibold text-[#2F9E6E] flex items-center gap-1 group-hover:underline font-mono">
              <MessageSquare className="w-3 h-3" /> Collective Messages
            </span>
          </div>
          <div className={`w-12 h-12 rounded-xl border flex items-center justify-center shrink-0 ${
            unreadMsgCount > 0 
              ? 'bg-[#E4F3EA] border-[#E1E4DC] text-[#2F9E6E] ring-2 ring-[#2F9E6E]/20 animate-pulse' 
              : 'bg-[#F1F3EC] border-[#E1E4DC] text-[#5B6B60]'
          }`}>
            <MessageSquare className="w-6 h-6" />
          </div>
        </div>

        <div className="p-5 bg-white rounded-xl border border-[#E1E4DC] shadow-2xs flex items-center justify-between">
          <div className="space-y-1">
            <span className="text-xs font-medium text-[#5B6B60] block">OR Turnover Velocity</span>
            <span className="text-2xl font-bold text-[#14432E] block font-display">18 Mins</span>
            <span className="text-[11px] font-semibold text-[#2F9E6E] flex items-center gap-1 font-mono">
              <TrendingUp className="w-3 h-3" /> +12% faster than target
            </span>
          </div>
          <div className="w-12 h-12 rounded-xl bg-[#E4F3EA] border border-[#E1E4DC] flex items-center justify-center text-[#2F9E6E] shrink-0">
            <Activity className="w-6 h-6" />
          </div>
        </div>
      </div>

      {/* AI Quick Resolution Hub */}
      <div className="p-6 bg-[#14432E] rounded-2xl text-white shadow-lg space-y-4 border border-[#5B6B60]">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-[#E4F3EA]" />
            <h3 className="text-base font-bold text-white font-display">Nightingale AI Action Hub</h3>
          </div>
          <span className="text-xs font-semibold px-2.5 py-1 bg-[#FBEEDB] text-[#7A4E17] border border-[#E1E4DC] rounded-full font-mono">
            1 High-Priority Action
          </span>
        </div>

        <div className="p-4 bg-[#14432E] rounded-xl border border-[#5B6B60] flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2 text-xs font-bold text-[#FBEEDB] font-display">
              <AlertTriangle className="w-4 h-4 text-[#7A4E17]" />
              <span>Patricia DePoli (7:30 AM · OR 1) - Missing EKG Report Clearance</span>
            </div>
            <p className="text-xs text-[#E1E4DC]">
              Inbound fax received from Beverly Hills Cardiology. AI matched fax to case #228940 with Normal Sinus Rhythm.
            </p>
          </div>

          <button
            onClick={() => {
              onTriggerEKGFastTrack('case-2');
            }}
            className="px-4 py-2.5 bg-[#2F9E6E] hover:bg-[#1B4332] text-white font-bold text-xs rounded-lg shadow-md transition-all flex items-center justify-center gap-1.5 shrink-0 cursor-pointer font-sans"
          >
            <Zap className="w-4 h-4 text-[#E4F3EA] fill-[#E4F3EA]" />
            <span>Fast-Track Clear EKG (Score 72% ➔ 98%)</span>
          </button>
        </div>
      </div>

      {/* Note: "Today's Surgical Board & Readiness Status" used to live here,
          duplicating the Dashboard's Today's Patients list. It has been removed —
          that same readiness detail (score, procedure, AI brief, checklist) is
          now available by expanding any patient row on the Dashboard, so there's
          one place to look instead of two. */}

      {/* Quick Link Card to Dedicated Patient Messages Hub */}
      <div className="bg-[#14432E] rounded-2xl p-6 border border-[#5B6B60] text-white flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-lg">
        <div className="flex items-center gap-3.5">
          <div className="w-10 h-10 rounded-xl bg-[#2F9E6E] text-[#E4F3EA] border border-[#1B4332] flex items-center justify-center shrink-0">
            <MessageSquare className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-sm md:text-base font-bold text-white tracking-tight font-display">
                Patient Portal Messages & Triage Hub
              </h3>
              {unreadMsgCount > 0 && (
                <span className="px-2 py-0.5 rounded-full bg-[#FBEEDB] text-[#7A4E17] font-bold text-xs font-mono">
                  {unreadMsgCount} Action Required
                </span>
              )}
            </div>
            <p className="text-xs text-[#E1E4DC] font-medium mt-0.5">
              Two-way secure EHR portal communications with AI clinical drafting, automated triage, and instant SMS alerts.
            </p>
          </div>
        </div>

        <button
          onClick={() => onNavigateTab('messages')}
          className="px-4 py-2.5 bg-[#2F9E6E] hover:bg-[#1B4332] text-white font-bold text-xs rounded-lg transition-all cursor-pointer flex items-center justify-center gap-1.5 shadow-md shrink-0 active:scale-95 font-sans"
        >
          <span>Open Patient Messages</span>
          <ArrowRight className="w-3.5 h-3.5 text-[#E4F3EA]" />
        </button>
      </div>

    </div>
  );
};
