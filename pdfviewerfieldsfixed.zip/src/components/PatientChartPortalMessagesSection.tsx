import React, { useState, useEffect } from 'react';
import {
  MessageSquare,
  Send,
  Sparkles,
  CheckCircle2,
  Clock,
  User,
  ShieldCheck,
  Paperclip,
  Search,
  Filter,
  RefreshCw,
  Eye,
  EyeOff,
  AlertCircle,
  FileText,
  Zap,
  Phone,
  Check,
  Stethoscope,
  Building2,
  Trash2,
  ChevronDown
} from 'lucide-react';
import { PortalMessage } from '../data/portalData';
import {
  getMessagesForPatient,
  sendProviderReply,
  markMessageReadStatus,
  deletePortalMessage,
  subscribeToMessageUpdates
} from '../utils/portalMessageStore';

interface PatientChartPortalMessagesSectionProps {
  patient?: any;
  patientId?: string;
  patientName?: string;
  patientPhone?: string;
  patientProcedure?: string;
  patientSurgeon?: string;
  onShowToast?: (msg: string) => void;
  onNavigateToPortalTab?: () => void;
  initialMessageId?: string;
}

export const PatientChartPortalMessagesSection: React.FC<PatientChartPortalMessagesSectionProps> = ({
  patient,
  patientId,
  patientName,
  patientPhone,
  patientProcedure,
  patientSurgeon,
  onShowToast,
  onNavigateToPortalTab
}) => {
  const activePatientId = patient?.patientId || patient?.id || patientId || '114202';
  const activePatientName = patient?.name || patientName || 'Patient';
  const activePatientPhone = patient?.phone || patientPhone || '(310) 555-0100';
  const activePatientProcedure = patient?.procedure || patientProcedure || 'Surgical Procedure';
  const activePatientSurgeon = patient?.surgeon || patientSurgeon || 'Dr. Alistair Sterling, MD';

  const [messages, setMessages] = useState<PortalMessage[]>(() => getMessagesForPatient(activePatientId));
  const [filterCategory, setFilterCategory] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [isGeneratingAiDraft, setIsGeneratingAiDraft] = useState<boolean>(false);
  const [aiDraftSummary, setAiDraftSummary] = useState<string | null>(null);
  const [replyingToMessage, setReplyingToMessage] = useState<PortalMessage | null>(null);

  // Compose State
  const [replyText, setReplyText] = useState<string>('');
  const [selectedCategory, setSelectedCategory] = useState<PortalMessage['category']>('Clinical Question');
  const [selectedStaffAuthor, setSelectedStaffAuthor] = useState<string>(
    activePatientSurgeon.includes('Mercer') ? 'Dr. Julian Mercer, MD' : 'Dr. Alistair Sterling, MD'
  );
  const [selectedStaffRole, setSelectedStaffRole] = useState<string>('Attending Surgeon');
  const [sendSmsNotification, setSendSmsNotification] = useState<boolean>(true);
  const [selectedAttachment, setSelectedAttachment] = useState<{ name: string; size: string } | null>(null);

  // Subscribe to real-time message updates
  useEffect(() => {
    const refresh = () => {
      setMessages(getMessagesForPatient(activePatientId));
    };
    refresh();
    const unsubscribe = subscribeToMessageUpdates(refresh);
    return () => unsubscribe();
  }, [activePatientId]);

  // Derived counts
  const unreadCount = messages.filter((m) => m.sender === 'patient' && !m.read).length;
  const patientMsgCount = messages.filter((m) => m.sender === 'patient').length;
  const staffMsgCount = messages.filter((m) => m.sender === 'provider').length;

  // Filter messages
  const filteredMessages = messages.filter((m) => {
    const matchesCat = filterCategory === 'All' || m.category === filterCategory;
    const matchesSearch =
      searchQuery === '' ||
      m.content.toLowerCase().includes(searchQuery.toLowerCase()) ||
      m.senderName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (m.category && m.category.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesCat && matchesSearch;
  });

  const handleSendMessage = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!replyText.trim()) return;

    const newMsg = sendProviderReply(activePatientId, {
      senderName: selectedStaffAuthor,
      senderTitle: selectedStaffRole,
      category: selectedCategory,
      content: replyText,
      attachment: selectedAttachment || undefined
    });

    if (replyingToMessage) {
      markMessageReadStatus(activePatientId, replyingToMessage.id, true);
    }

    setReplyText('');
    setSelectedAttachment(null);
    setAiDraftSummary(null);
    setReplyingToMessage(null);
    setMessages(getMessagesForPatient(activePatientId));
    if (onShowToast) {
      onShowToast(`Message delivered to ${activePatientName}'s Patient Portal inbox.`);
    }
  };

  const handleReplyToIncomingMessage = (msg: PortalMessage) => {
    setReplyingToMessage(msg);
    if (!msg.read) {
      markMessageReadStatus(activePatientId, msg.id, true);
      setMessages(getMessagesForPatient(activePatientId));
    }
    if (msg.category) {
      setSelectedCategory(msg.category);
    }
    const firstName = activePatientName.split(' ')[0];
    if (!replyText.trim()) {
      if (msg.category === 'Prescription Refill' || msg.content.toLowerCase().includes('medication') || msg.content.toLowerCase().includes('walgreens') || msg.content.toLowerCase().includes('refill')) {
        setReplyText(`Hi ${firstName}, Dr. Sterling's team verified your prescriptions with the pharmacy on file and they are ready for pickup prior to surgery.`);
      } else if (msg.content.toLowerCase().includes('ekg') || msg.content.toLowerCase().includes('cardiology')) {
        setReplyText(`Dear ${firstName}, we received your 12-lead EKG report from cardiology and it has been cleared for your procedure.`);
      } else if (msg.content.toLowerCase().includes('fasting') || msg.content.toLowerCase().includes('water') || msg.content.toLowerCase().includes('blood pressure')) {
        setReplyText(`Hi ${firstName}, you may take your morning blood pressure medication at 5:30 AM with a small sip of water. Maintain strict fasting otherwise.`);
      } else {
        setReplyText(`Hello ${firstName}, thank you for reaching out via the patient portal. In response to your question: `);
      }
    }

    if (onShowToast) {
      onShowToast(`Replying to ${msg.senderName}'s incoming message.`);
    }

    setTimeout(() => {
      const composerEl = document.getElementById('portal-reply-composer');
      if (composerEl) {
        composerEl.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
      const textareaEl = document.getElementById('portal-reply-textarea') as HTMLTextAreaElement | null;
      if (textareaEl) {
        textareaEl.focus();
      }
    }, 80);
  };

  const handleMarkAllRead = () => {
    messages.forEach((m) => {
      if (m.sender === 'patient' && !m.read) {
        markMessageReadStatus(activePatientId, m.id, true);
      }
    });
    setMessages(getMessagesForPatient(activePatientId));
    if (onShowToast) {
      onShowToast(`All patient portal messages marked as read for ${activePatientName}.`);
    }
  };

  const handleToggleRead = (msg: PortalMessage) => {
    const newStatus = !msg.read;
    markMessageReadStatus(activePatientId, msg.id, newStatus);
    setMessages(getMessagesForPatient(activePatientId));
  };

  const handleDelete = (msgId: string) => {
    deletePortalMessage(activePatientId, msgId);
    setMessages(getMessagesForPatient(activePatientId));
    if (onShowToast) {
      onShowToast('Message removed from chart record.');
    }
  };

  // Pre-configured Quick Clinical Templates
  const clinicalTemplates = [
    {
      title: 'Pre-Op Fasting & Morning Meds',
      category: 'Clinical Question' as const,
      text: `Hello ${activePatientName.split(' ')[0]}, you may take approved morning cardiovascular/blood pressure medications with 1 tablespoon of water at 5:30 AM. Strictly avoid all other solids and liquids from midnight. Please arrive at the ASC at your scheduled check-in time.`
    },
    {
      title: 'Prescription Sent to Pharmacy',
      category: 'Prescription Refill' as const,
      text: `Hi ${activePatientName.split(' ')[0]}, your surgical prescriptions (including post-op pain management, anti-nausea, and antibiotic prophylaxis) have been electronically transmitted to your designated pharmacy on file. They are ready for pickup.`
    },
    {
      title: 'Lab Clearance & OR Approval',
      category: 'Clinical Question' as const,
      text: `Good day ${activePatientName.split(' ')[0]}, we have reviewed your lab panel and pre-op clearance packet. All markers are within normal limits and you are 100% medically cleared for your procedure.`
    },
    {
      title: 'Post-Op Follow-Up Confirmed',
      category: 'Scheduling' as const,
      text: `Hello ${activePatientName.split(' ')[0]}, your post-operative dressing and incision evaluation has been confirmed. Please remember to wear comfortable clothing with front-zipper or button closures and bring your surgical garment.`
    },
    {
      title: 'Billing & Copay Receipt',
      category: 'Billing' as const,
      text: `Thank you ${activePatientName.split(' ')[0]}, your payment has been processed and your account balance reflects a $0.00 patient responsibility for today's encounter. A detailed receipt has been filed in your portal documents vault.`
    }
  ];

  // Nightingale AI smart reply generator
  const handleGenerateAiDraft = () => {
    setIsGeneratingAiDraft(true);
    const lastPatientMsg = replyingToMessage || [...messages].reverse().find((m) => m.sender === 'patient');

    setTimeout(() => {
      setIsGeneratingAiDraft(false);
      if (lastPatientMsg) {
        if (lastPatientMsg.category === 'Prescription Refill' || lastPatientMsg.content.toLowerCase().includes('medication') || lastPatientMsg.content.toLowerCase().includes('walgreens') || lastPatientMsg.content.toLowerCase().includes('refill')) {
          setReplyText(
            `Hi ${activePatientName.split(' ')[0]}, Dr. Sterling's clinical team has confirmed your prescriptions (Celebrex 200mg and Zofran 4mg) were electronically transmitted to Walgreens Pharmacy on Wilshire Blvd. They are verified and ready for pickup prior to surgery.`
          );
          setSelectedCategory('Prescription Refill');
          setAiDraftSummary(`Generated response addressing pharmacy pickup inquiry for ${activePatientName}.`);
        } else if (lastPatientMsg.content.toLowerCase().includes('ekg') || lastPatientMsg.content.toLowerCase().includes('cardiology')) {
          setReplyText(
            `Dear ${activePatientName.split(' ')[0]}, we have received the 12-lead EKG fax directly from Pacific Coast Cardiology. The rhythm report has been reviewed and cleared by Dr. Sterling and Dr. Cruz. Your surgical clearance is now complete!`
          );
          setSelectedCategory('Clinical Question');
          setAiDraftSummary(`Drafted clearance confirmation addressing pending EKG from external cardiologist.`);
        } else {
          setReplyText(
            `Hello ${activePatientName.split(' ')[0]}, thank you for reaching out via the patient portal. We have reviewed your chart notes for ${activePatientProcedure}. Everything is coordinated for your scheduled encounter. Please let us know if you experience any changes in symptoms prior to arrival.`
          );
          setSelectedCategory('Clinical Question');
          setAiDraftSummary(`Generated empathetic clinical reply tailored to ${activePatientProcedure}.`);
        }
      } else {
        setReplyText(
          `Hello ${activePatientName.split(' ')[0]}, this is the clinical coordination team at Aura Vanguard Surgical Pavilion. We are checking in regarding your upcoming ${activePatientProcedure}. Please let us know if you have any questions!`
        );
        setAiDraftSummary(`Generated general clinical check-in message.`);
      }

      if (onShowToast) {
        onShowToast('✨ Nightingale AI generated context-aware clinical draft.');
      }
    }, 500);
  };

  return (
    <div className="space-y-5 animate-in fade-in duration-200">
      {/* Top Banner with Stats & Actions */}
      <div className="flex flex-wrap items-center justify-between gap-4 p-4 rounded-2xl bg-stone-50 border border-stone-200/90 shadow-2xs">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-indigo-600 text-white flex items-center justify-center shadow-xs shrink-0">
            <MessageSquare className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h3 className="text-sm font-bold text-stone-900">
                Patient Portal Messaging & Communication Hub
              </h3>
              {unreadCount > 0 ? (
                <span className="px-2.5 py-0.5 rounded-full bg-amber-100 text-amber-900 text-[11px] font-extrabold border border-amber-300 animate-pulse">
                  {unreadCount} Unread from Patient
                </span>
              ) : (
                <span className="px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[11px] font-bold border border-emerald-200 flex items-center gap-1">
                  <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                  All Messages Triaged
                </span>
              )}
            </div>
            <p className="text-xs text-stone-500 font-medium mt-0.5">
              Direct two-way secure EHR portal communication with <strong className="text-stone-800">{activePatientName}</strong> (MRN: #{activePatientId})
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {unreadCount > 0 && (
            <button
              onClick={handleMarkAllRead}
              className="px-3 py-1.5 rounded-xl bg-white hover:bg-stone-100 text-stone-700 text-xs font-bold border border-stone-300 shadow-2xs transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
              <span>Mark All Read</span>
            </button>
          )}

          <button
            onClick={handleGenerateAiDraft}
            disabled={isGeneratingAiDraft}
            className="px-3.5 py-1.5 rounded-xl bg-indigo-50 hover:bg-indigo-100 text-indigo-700 text-xs font-bold border border-indigo-200 shadow-2xs transition-all flex items-center gap-1.5 cursor-pointer"
          >
            {isGeneratingAiDraft ? (
              <RefreshCw className="w-3.5 h-3.5 animate-spin text-indigo-600" />
            ) : (
              <Sparkles className="w-3.5 h-3.5 text-indigo-600" />
            )}
            <span>AI Draft Reply</span>
          </button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-1.5">
          {['All', 'Clinical Question', 'Prescription Refill', 'Scheduling', 'Billing', 'General'].map((cat) => {
            const count = cat === 'All' ? messages.length : messages.filter((m) => m.category === cat).length;
            const isSelected = filterCategory === cat;
            return (
              <button
                key={cat}
                onClick={() => setFilterCategory(cat)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                  isSelected
                    ? 'bg-stone-900 text-white shadow-2xs'
                    : 'bg-stone-100 hover:bg-stone-200 text-stone-600 border border-stone-200/80'
                }`}
              >
                <span>{cat}</span>
                <span
                  className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono ${
                    isSelected ? 'bg-stone-700 text-stone-100' : 'bg-stone-200/90 text-stone-700'
                  }`}
                >
                  {count}
                </span>
              </button>
            );
          })}
        </div>

        <div className="relative min-w-[220px]">
          <Search className="w-3.5 h-3.5 text-stone-400 absolute left-3 top-2.5" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search conversation thread..."
            className="w-full pl-9 pr-3 py-1.5 bg-stone-50 border border-stone-200 rounded-xl text-xs font-medium focus:outline-none focus:ring-2 focus:ring-indigo-500 text-stone-800"
          />
        </div>
      </div>

      {/* Message Feed Container */}
      <div className="bg-white rounded-2xl border border-stone-200/90 shadow-2xs overflow-hidden">
        {/* Feed Header */}
        <div className="p-3.5 bg-stone-100/80 border-b border-stone-200/80 flex items-center justify-between text-xs font-bold text-stone-600">
          <div className="flex items-center gap-2">
            <span>Secure Patient Portal Thread</span>
            <span className="text-stone-400">·</span>
            <span className="text-stone-500 font-normal">
              {patientMsgCount} from patient, {staffMsgCount} provider responses
            </span>
          </div>
          <span className="text-[11px] text-stone-400 font-medium">HIPAA Compliant In-App Vault</span>
        </div>

        {/* Message Stream */}
        <div className="p-4 sm:p-5 space-y-4 max-h-[460px] overflow-y-auto bg-stone-50/40">
          {filteredMessages.length === 0 ? (
            <div className="text-center py-10 space-y-2">
              <div className="w-12 h-12 rounded-2xl bg-stone-100 text-stone-400 mx-auto flex items-center justify-center">
                <MessageSquare className="w-6 h-6" />
              </div>
              <p className="text-xs font-bold text-stone-700">No portal messages found matching criteria.</p>
              <p className="text-[11px] text-stone-400">Use the composer below to send a message to {patientName}'s portal.</p>
            </div>
          ) : (
            filteredMessages.map((msg) => {
              const isPatient = msg.sender === 'patient';

              return (
                <div
                  key={msg.id}
                  className={`flex flex-col ${isPatient ? 'items-start' : 'items-end'} animate-in fade-in duration-150`}
                >
                  <div
                    className={`max-w-xl rounded-2xl p-4 shadow-2xs border ${
                      isPatient
                        ? !msg.read
                          ? 'bg-amber-50/90 border-amber-300 text-stone-900 ring-2 ring-amber-200/60'
                          : 'bg-white border-stone-200/90 text-stone-900'
                        : 'bg-gradient-to-br from-emerald-900 to-slate-900 border-indigo-800 text-white'
                    }`}
                  >
                    {/* Header line */}
                    <div className="flex items-center justify-between gap-3 pb-2 mb-2 border-b border-stone-200/50 border-white/10 text-xs">
                      <div className="flex items-center gap-2">
                        <div
                          className={`w-6 h-6 rounded-lg flex items-center justify-center text-[10px] font-bold ${
                            isPatient ? 'bg-indigo-100 text-indigo-800' : 'bg-emerald-500/20 text-emerald-300 border border-emerald-400/30'
                          }`}
                        >
                          {isPatient ? <User className="w-3.5 h-3.5" /> : <Stethoscope className="w-3.5 h-3.5" />}
                        </div>
                        <div>
                          <span className={`font-bold ${isPatient ? 'text-stone-900' : 'text-white'}`}>
                            {msg.senderName}
                          </span>
                          {msg.senderTitle && (
                            <span className={`text-[10px] ml-1.5 ${isPatient ? 'text-stone-500' : 'text-indigo-200'}`}>
                              ({msg.senderTitle})
                            </span>
                          )}
                        </div>
                      </div>

                      <div className="flex items-center gap-2">
                        {msg.category && (
                          <span
                            className={`px-2 py-0.5 rounded-md text-[10px] font-bold uppercase tracking-wider ${
                              isPatient
                                ? 'bg-indigo-50 text-indigo-800 border border-indigo-200'
                                : 'bg-indigo-800/80 text-indigo-200 border border-indigo-700'
                            }`}
                          >
                            {msg.category}
                          </span>
                        )}
                        <span className={`text-[10px] font-mono ${isPatient ? 'text-stone-400' : 'text-slate-400'}`}>
                          {msg.date || 'Today'} · {msg.timestamp}
                        </span>
                      </div>
                    </div>

                    {/* Message Body */}
                    <p
                      className={`text-xs leading-relaxed font-medium whitespace-pre-wrap ${
                        isPatient ? 'text-stone-800' : 'text-slate-100'
                      }`}
                    >
                      {msg.content}
                    </p>

                    {/* Attachment preview if any */}
                    {msg.attachment && (
                      <div
                        className={`mt-2.5 p-2 rounded-xl border flex items-center gap-2 text-xs font-semibold ${
                          isPatient
                            ? 'bg-stone-50 border-stone-200 text-stone-800'
                            : 'bg-indigo-950/60 border-indigo-700 text-indigo-200'
                        }`}
                      >
                        <FileText className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
                        <span className="truncate flex-1">{msg.attachment.name}</span>
                        <span className="text-[10px] text-stone-400 font-mono">{msg.attachment.size}</span>
                      </div>
                    )}

                    {/* Footer Actions */}
                    <div className="mt-3 pt-2 border-t border-stone-100 border-white/10 flex items-center justify-between gap-2 text-[11px]">
                      <div className="flex items-center gap-2">
                        {isPatient ? (
                          <>
                            <span className="px-2 py-0.5 rounded-full bg-stone-100 text-stone-600 font-semibold text-[10px]">
                              From Patient Portal
                            </span>
                            {!msg.read && (
                              <span className="px-2 py-0.5 rounded-full bg-amber-500 text-white font-bold text-[10px]">
                                New / Action Needed
                              </span>
                            )}
                          </>
                        ) : (
                          <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 font-semibold text-[10px] flex items-center gap-1 border border-emerald-500/30">
                            <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                            Delivered to Patient Portal Inbox
                          </span>
                        )}
                      </div>

                      <div className="flex items-center gap-2">
                        {isPatient && (
                          <>
                            <button
                              type="button"
                              onClick={() => handleReplyToIncomingMessage(msg)}
                              className="px-3 py-1 bg-indigo-600 hover:bg-indigo-700 active:scale-95 text-white text-[11px] font-bold rounded-xl transition-all flex items-center gap-1.5 cursor-pointer shadow-2xs"
                              title="Reply to incoming message"
                            >
                              <Send className="w-3 h-3 text-white" />
                              <span>Reply to incoming message</span>
                            </button>

                            <button
                              type="button"
                              onClick={() => handleToggleRead(msg)}
                              className="p-1 text-stone-400 hover:text-stone-700 rounded-md transition-colors cursor-pointer"
                              title={msg.read ? 'Mark unread' : 'Mark read'}
                            >
                              {msg.read ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5 text-amber-600" />}
                            </button>
                          </>
                        )}
                        <button
                          type="button"
                          onClick={() => handleDelete(msg.id)}
                          className="p-1 text-stone-300 hover:text-rose-500 rounded-md transition-colors cursor-pointer"
                          title="Delete message"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>

      {/* Interactive Clinical Reply & Message Composer */}
      <div id="portal-reply-composer" className="bg-white rounded-2xl border border-stone-200/90 shadow-2xs p-5 space-y-4 scroll-mt-6">
        <div className="flex flex-wrap items-center justify-between border-b border-stone-200/80 pb-3 gap-2">
          <div className="flex items-center gap-2">
            <Send className="w-4 h-4 text-indigo-600" />
            <h4 className="text-xs font-bold text-stone-900 uppercase tracking-wider">
              Respond & Send Message to Patient Portal
            </h4>
          </div>
          <span className="text-[11px] text-stone-500 font-medium">
            Recipient: <strong className="text-stone-800">{activePatientName}</strong> · Notification via Portal + SMS
          </span>
        </div>

        {/* Replying-to Active Indicator Banner */}
        {replyingToMessage && (
          <div className="p-3 bg-indigo-50/90 border border-indigo-200 rounded-xl flex items-center justify-between gap-3 animate-in fade-in duration-150">
            <div className="flex items-center gap-2.5 min-w-0">
              <div className="p-1.5 bg-indigo-600 text-white rounded-lg shrink-0 shadow-2xs">
                <Send className="w-3.5 h-3.5" />
              </div>
              <div className="min-w-0">
                <div className="text-[11px] font-bold text-indigo-950 flex items-center gap-2">
                  <span>Replying to {replyingToMessage.senderName}</span>
                  {replyingToMessage.category && (
                    <span className="px-2 py-0.5 rounded text-[9px] bg-indigo-200 text-indigo-900 font-bold uppercase tracking-wider">
                      {replyingToMessage.category}
                    </span>
                  )}
                </div>
                <p className="text-[11px] text-indigo-800 truncate font-medium mt-0.5">
                  "{replyingToMessage.content}"
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={() => setReplyingToMessage(null)}
              className="px-2 py-1 rounded-lg text-indigo-600 hover:text-indigo-950 hover:bg-indigo-100 transition-colors text-xs font-bold shrink-0 cursor-pointer flex items-center gap-1"
              title="Cancel replying target"
            >
              ✕ Cancel
            </button>
          </div>
        )}

        {/* Quick Clinical Templates Carousel */}
        <div className="space-y-1.5">
          <span className="text-[11px] font-bold text-stone-600 flex items-center gap-1.5">
            <Zap className="w-3 h-3 text-amber-600" />
            <span>Click Quick Template to Insert Response:</span>
          </span>
          <div className="flex flex-wrap gap-1.5">
            {clinicalTemplates.map((tpl, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => {
                  setReplyText(tpl.text);
                  setSelectedCategory(tpl.category);
                  if (onShowToast) {
                    onShowToast(`Inserted "${tpl.title}" template.`);
                  }
                }}
                className="px-2.5 py-1 rounded-xl bg-stone-100 hover:bg-indigo-50 hover:text-indigo-700 text-stone-700 text-[11px] font-semibold border border-stone-200 transition-colors cursor-pointer text-left"
              >
                + {tpl.title}
              </button>
            ))}
          </div>
        </div>

        {/* Composer Form */}
        <form onSubmit={handleSendMessage} className="space-y-3.5">
          {/* Author and Category Selectors */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="text-[11px] font-bold text-stone-700 block mb-1">
                Author / Sender
              </label>
              <select
                value={selectedStaffAuthor}
                onChange={(e) => {
                  setSelectedStaffAuthor(e.target.value);
                  if (e.target.value.includes('Sterling')) setSelectedStaffRole('Attending Surgeon & Medical Director');
                  else if (e.target.value.includes('Mercer')) setSelectedStaffRole('Attending Facial Surgeon');
                  else if (e.target.value.includes('Cruz')) setSelectedStaffRole('Attending Anesthesiologist');
                  else if (e.target.value.includes('Camila')) setSelectedStaffRole('Lead Surgical Coordinator, RN');
                  else setSelectedStaffRole('Clinical Support Staff');
                }}
                className="w-full bg-stone-50 border border-stone-300 rounded-xl px-3 py-2 text-xs font-semibold text-stone-900 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="Dr. Alistair Sterling, MD">Dr. Alistair Sterling, MD (Surgeon)</option>
                <option value="Camila Rojas, RN">Camila Rojas, RN (Surgical Coordinator)</option>
                <option value="Dr. Raymond Cruz, MD">Dr. Raymond Cruz, MD (Anesthesiologist)</option>
                <option value="Dr. Julian Mercer, MD">Dr. Julian Mercer, MD (Surgeon)</option>
                <option value="Aura Vanguard Clinical Team">Aura Vanguard Clinical Support Desk</option>
              </select>
            </div>

            <div>
              <label className="text-[11px] font-bold text-stone-700 block mb-1">
                Sender Title / Role
              </label>
              <input
                type="text"
                value={selectedStaffRole}
                onChange={(e) => setSelectedStaffRole(e.target.value)}
                className="w-full bg-stone-50 border border-stone-300 rounded-xl px-3 py-2 text-xs font-semibold text-stone-900 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            <div>
              <label className="text-[11px] font-bold text-stone-700 block mb-1">
                Topic / Category
              </label>
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value as any)}
                className="w-full bg-stone-50 border border-stone-300 rounded-xl px-3 py-2 text-xs font-semibold text-stone-900 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="Clinical Question">Clinical Question & Clearance</option>
                <option value="Prescription Refill">Prescription & Medication</option>
                <option value="Scheduling">Scheduling & Arrival Protocol</option>
                <option value="Billing">Billing & Pre-Auth Statement</option>
                <option value="General">General In-App Notice</option>
              </select>
            </div>
          </div>

          {/* AI Draft Insight pill if generated */}
          {aiDraftSummary && (
            <div className="p-2.5 rounded-xl bg-indigo-50 border border-indigo-200 text-indigo-900 text-xs font-medium flex items-center justify-between gap-2">
              <div className="flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
                <span>{aiDraftSummary}</span>
              </div>
              <button
                type="button"
                onClick={() => setAiDraftSummary(null)}
                className="text-indigo-400 hover:text-indigo-700 text-xs font-bold cursor-pointer"
              >
                ✕
              </button>
            </div>
          )}

          {/* Textarea */}
          <div>
            <textarea
              id="portal-reply-textarea"
              rows={3}
              value={replyText}
              onChange={(e) => setReplyText(e.target.value)}
              placeholder={`Write response to ${activePatientName}'s patient portal...`}
              className="w-full p-3.5 bg-stone-50 border border-stone-300 rounded-xl text-xs font-medium text-stone-900 focus:outline-none focus:ring-2 focus:ring-indigo-500 leading-relaxed placeholder:text-stone-400"
            />
          </div>

          {/* Bottom Bar: Attachment, SMS toggle, and Submit */}
          <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
            <div className="flex items-center gap-3">
              {/* Add Attachment pill */}
              <div className="flex items-center gap-1.5">
                {selectedAttachment ? (
                  <span className="px-2.5 py-1 rounded-xl bg-indigo-100 text-indigo-800 text-xs font-bold border border-indigo-200 flex items-center gap-1.5">
                    <FileText className="w-3 h-3 text-indigo-600" />
                    <span>{selectedAttachment.name}</span>
                    <button
                      type="button"
                      onClick={() => setSelectedAttachment(null)}
                      className="hover:text-red-600 ml-1 cursor-pointer"
                    >
                      ✕
                    </button>
                  </span>
                ) : (
                  <button
                    type="button"
                    onClick={() => {
                      setSelectedAttachment({
                        name: 'Pre-Op_Patient_Preparation_Guide_2026.pdf',
                        size: '420 KB'
                      });
                      if (onShowToast) onShowToast('Attached Pre-Op Patient Preparation Guide.');
                    }}
                    className="px-2.5 py-1 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-600 text-xs font-semibold border border-stone-200 flex items-center gap-1.5 cursor-pointer"
                  >
                    <Paperclip className="w-3 h-3" />
                    <span>Attach Clinical PDF</span>
                  </button>
                )}
              </div>

              {/* SMS text toggle */}
              <label className="flex items-center gap-1.5 text-xs text-stone-600 font-medium cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={sendSmsNotification}
                  onChange={(e) => setSendSmsNotification(e.target.checked)}
                  className="rounded border-stone-300 text-indigo-600 focus:ring-indigo-500"
                />
                <span>Send Instant SMS Alert to {activePatientPhone}</span>
              </label>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="submit"
                disabled={!replyText.trim()}
                className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-40 disabled:cursor-not-allowed text-white font-bold text-xs rounded-xl shadow-xs transition-all flex items-center gap-2 cursor-pointer hover:scale-101 active:scale-98"
              >
                <Send className="w-3.5 h-3.5" />
                <span>Send to Patient Portal</span>
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
