import React, { useState } from 'react';
import { 
  Sparkles, 
  Send, 
  FileText, 
  Pill, 
  Mail, 
  Printer, 
  Tag,
  Calendar,
  ShieldCheck, 
  CreditCard, 
  CheckCircle2, 
  AlertCircle,
  FileCheck,
  Stethoscope,
  PenTool,
  Maximize2,
  Minimize2,
  MessageSquare,
  Building2,
  Zap,
  Layers,
  Check,
  ChevronDown,
  ChevronUp,
  Bot,
  User as UserIcon,
  RotateCcw,
  Info,
  Mic
} from 'lucide-react';
import { PatientCase } from '../types';
import { MasterPatientRecord, getAllMasterPatients } from '../utils/patientDirectory';

export interface ChatMessage {
  sender: 'user' | 'ai' | 'Clinician' | 'Nightingale';
  text: string;
  timestamp?: string;
}

export interface NightingaleChartCommandCoordinatorProps {
  selectedPatient?: PatientCase;
  currentPatient?: PatientCase;
  cases?: PatientCase[];
  availablePatients?: MasterPatientRecord[];
  onSelectPatient?: (patient: any) => void;
  onExecuteDirective?: (directive: string, param?: string) => void;
  onExecuteChartCommand?: (command: string) => { success: boolean; message: string };
  onExecuteAiCommand?: (commandLabel: string, sectionKey: string) => void;
  selectedCommandKey?: string;
  patientUnreadCount?: number;
  onOpenPrintModal?: (option?: any) => void;
  onOpenEPrescribe?: () => void;
  onOpenIntakeSendModal?: () => void;
  onOpenNoteWorkspace?: () => void;
  isMinimalMode?: boolean;
  onToggleMinimalMode?: () => void;
}

export const NightingaleChartCommandCoordinator: React.FC<NightingaleChartCommandCoordinatorProps> = ({
  selectedPatient,
  currentPatient,
  cases = [],
  availablePatients,
  onSelectPatient,
  onExecuteDirective,
  onExecuteChartCommand,
  onExecuteAiCommand,
  selectedCommandKey = 'clearance',
  patientUnreadCount = 0,
  onOpenPrintModal,
  onOpenEPrescribe,
  onOpenIntakeSendModal,
  onOpenNoteWorkspace,
  isMinimalMode = false,
  onToggleMinimalMode,
}) => {
  const patient = selectedPatient || currentPatient || cases[0] || {
    id: 'case-0',
    patientId: '113561',
    name: 'Sarah Wilson',
    age: 42,
    dob: '05/12/1984',
    phone: '(310) 555-0142',
    procedure: 'Rhinoplasty & Septoplasty',
    surgeon: 'Dr. Alistair Sterling',
    room: 'OR #1',
    scheduledTime: '07:30 AM',
    stage: 'PRE_OP',
    readinessScore: 94,
    readinessLevel: 'CLEARED',
    aiSummary: 'Pre-op clearance verified. All consents signed and labs within normal limits.',
    bottlenecks: [],
    actionItems: [],
    labs: [],
    timeline: [],
    allergies: ['Penicillin (Hives / Rash)', 'Sulfa Drugs']
  };

  const masterList = availablePatients || getAllMasterPatients() || [];
  const [commandInput, setCommandInput] = useState('');
  const [isChatLogExpanded, setIsChatLogExpanded] = useState(false);
  const [chatLog, setChatLog] = useState<ChatMessage[]>([
    {
      sender: 'ai',
      text: `Hello! I'm Nightingale AI. Ask me clinical questions about ${patient.name}'s chart (allergies, clearance, labs, consents) or select a suggested command to filter and display records on demand.`,
      timestamp: 'Active'
    }
  ]);

  const [lastFeedback, setLastFeedback] = useState<{ text: string; isError?: boolean } | null>({
    text: `Nightingale AI active on ${patient.name}'s chart (MRN #${patient.patientId}). Ready for clinical directives, Q&A, and quick actions.`
  });

  const getAiAnswerForQuery = (query: string): { answer: string; sectionKey?: string } => {
    const qLower = query.toLowerCase();

    if (qLower.includes('allergy') || qLower.includes('allergies') || qLower.includes('penicillin') || qLower.includes('reaction')) {
      const allergyText = (patient.allergies && patient.allergies.length > 0) ? patient.allergies.join(', ') : 'No Known Drug Allergies (NKDA)';
      return {
        answer: `Documented allergies for ${patient.name}: ${allergyText}. Pre-op order sets and electronic prescriptions have been cross-checked.`,
        sectionKey: 'medications'
      };
    }

    if (qLower.includes('clear') || qLower.includes('cardiac') || qLower.includes('airway') || qLower.includes('ekg') || qLower.includes('mallampati')) {
      return {
        answer: `Pre-Op Clearance: ${patient.name} is ${patient.readinessLevel === 'CLEARED' ? 'CLEARED (Readiness Score: ' + patient.readinessScore + '%)' : 'PENDING'}. EKG normal sinus rhythm, airway Mallampati Class I, and pre-anesthesia questionnaire signed.`,
        sectionKey: 'clearance'
      };
    }

    if (qLower.includes('doctor note') || qLower.includes('h&p') || qLower.includes('soap') || qLower.includes('progress note') || qLower.includes('draft note')) {
      return {
        answer: `Displaying Doctor Notes & Clinical Progress H&P for ${patient.name} by ${patient.surgeon || 'Dr. Alistair Sterling'}. Dictation and note templates are ready.`,
        sectionKey: 'clinicalNotes'
      };
    }

    if (qLower.includes('nurs') || qLower.includes('vital') || qLower.includes('pacu') || qLower.includes('post-op note')) {
      return {
        answer: `Displaying Nursing Clinical Notes & Surgical Episodes (Pre-Op, Intra-Op, PACU) for ${patient.name}.`,
        sectionKey: 'nursingNotes'
      };
    }

    if (qLower.includes('intake') || qLower.includes('consent') || qLower.includes('send form') || qLower.includes('arbitration')) {
      return {
        answer: `Displaying 9 interactive electronic Intake Forms & Surgical Consents for ${patient.name}. All verified electronic forms are signed.`,
        sectionKey: 'intakeForms'
      };
    }

    if (qLower.includes('document') || qLower.includes('pdf') || qLower.includes('upload') || qLower.includes('standing order')) {
      return {
        answer: `Displaying 9 verified clinical document records, lab reports, and standing orders for ${patient.name}.`,
        sectionKey: 'documents'
      };
    }

    if (qLower.includes('med') || qLower.includes('rx') || qLower.includes('prescrib') || qLower.includes('refill') || qLower.includes('augmentin')) {
      return {
        answer: `Displaying active reconciled medications and Surescripts E-Prescribe controls for ${patient.name}.`,
        sectionKey: 'medications'
      };
    }

    if (qLower.includes('pay') || qLower.includes('financ') || qLower.includes('bill') || qLower.includes('invoic') || qLower.includes('fee')) {
      return {
        answer: `Displaying Payment & Financial Summary notes and invoice options for ${patient.name}.`,
        sectionKey: 'financial'
      };
    }

    if (qLower.includes('appoint') || qLower.includes('visit') || qLower.includes('encounter') || qLower.includes('history') || qLower.includes('schedule')) {
      return {
        answer: `Displaying Appointment History & 5 Clinical Encounters for ${patient.name} (Current DOS: May 06, 2026 at Aura Vanguard Pavilion).`,
        sectionKey: 'appointments'
      };
    }

    if (qLower.includes('message') || qLower.includes('portal') || qLower.includes('chat') || qLower.includes('sms')) {
      return {
        answer: `Displaying Patient Portal Messages & Two-Way Clinical Communications for ${patient.name}. (${patientUnreadCount} unread message(s))`,
        sectionKey: 'portalMessages'
      };
    }

    if (qLower.includes('id') || qLower.includes('insurance') || qLower.includes('driver') || qLower.includes('license') || qLower.includes('card')) {
      return {
        answer: `Displaying Driver's License Photo ID and Primary Insurance Cards (Front & Back) for ${patient.name}.`,
        sectionKey: 'idInsurance'
      };
    }

    if (qLower.includes('surgeon') || qLower.includes('team') || qLower.includes('room') || qLower.includes('anesthesiologist') || qLower.includes('cruz') || qLower.includes('sterling')) {
      return {
        answer: `Surgical Team: Attending Surgeon is ${patient.surgeon || 'Dr. Alistair Sterling'}, Anesthesiologist is Dr. Raymond Cruz, Location is ${patient.room || 'OR 2'}.`,
        sectionKey: 'surgicalDetails'
      };
    }

    if (qLower.includes('implant') || qLower.includes('mentor') || qLower.includes('gel')) {
      return {
        answer: `Implant Tracking: Mentor MemoryGel smooth round implants verified. Lot and serial numbers logged in operative prep checklist.`,
        sectionKey: 'clearance'
      };
    }

    if (qLower.includes('all') || qLower.includes('expand') || qLower.includes('everything') || qLower.includes('show all')) {
      return {
        answer: `Displaying all patient chart sections for ${patient.name}.`,
        sectionKey: 'all'
      };
    }

    // Default response
    return {
      answer: `Nightingale verified: Records for ${patient.name} (MRN #${patient.patientId}) updated. Procedure: ${patient.procedure}. Vitals and clinical chart ready for physician review.`,
      sectionKey: 'all'
    };
  };

  const handleProcessQueryOrCommand = (inputStr: string) => {
    const raw = inputStr.trim();
    if (!raw) return;

    const timeStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    const lower = raw.toLowerCase();

    // Check if directive is switching patient
    if (lower.startsWith('switch to ') || lower.startsWith('load chart for ') || lower.startsWith('open ')) {
      const targetName = lower.replace(/^(switch to|load chart for|open chart for|open patient|view)\s+/i, '').trim();
      const foundInCases = cases.find(c => c.name.toLowerCase().includes(targetName) || c.patientId.includes(targetName));
      const foundInMaster = masterList.find(m => m.name.toLowerCase().includes(targetName) || m.patientId.includes(targetName));
      
      if (foundInCases && onSelectPatient) {
        onSelectPatient(foundInCases);
        const feedback = `Nightingale: Switched clinical chart to ${foundInCases.name} (MRN #${foundInCases.patientId}).`;
        setLastFeedback({ text: feedback, isError: false });
        setChatLog(prev => [...prev, { sender: 'user', text: raw, timestamp: timeStr }, { sender: 'ai', text: feedback, timestamp: timeStr }]);
        return;
      } else if (foundInMaster && onSelectPatient) {
        onSelectPatient(foundInMaster);
        const feedback = `Nightingale: Loaded master EHR record for ${foundInMaster.name} (MRN #${foundInMaster.patientId}).`;
        setLastFeedback({ text: feedback, isError: false });
        setChatLog(prev => [...prev, { sender: 'user', text: raw, timestamp: timeStr }, { sender: 'ai', text: feedback, timestamp: timeStr }]);
        return;
      }
    }

    // Modal triggers
    if (lower.includes('eprescribe') || (lower.includes('prescribe') && lower.includes('modal'))) {
      if (onOpenEPrescribe) onOpenEPrescribe();
    }
    if (lower.includes('send intake') || lower.includes('email intake') || lower.includes('send consent')) {
      if (onOpenIntakeSendModal) onOpenIntakeSendModal();
    }
    if (lower.includes('print facesheet') || lower.includes('print chart')) {
      if (onOpenPrintModal) onOpenPrintModal('facesheet');
    }

    // Directive routing
    if (onExecuteDirective) {
      if (lower.includes('clearance') || lower.includes('ekg')) onExecuteDirective('check_clearance');
      else if (lower.includes('soap') || lower.includes('draft note')) onExecuteDirective('draft_soap_note');
      else if (lower.includes('eprescribe') || lower.includes('prescrib')) onExecuteDirective('eprescribe');
      else if (lower.includes('send intake')) onExecuteDirective('send_intake');
      else if (lower.includes('print')) onExecuteDirective('print_chart');
    }

    // Get intelligent answer and section key
    const { answer, sectionKey } = getAiAnswerForQuery(raw);

    // If section key found and parent handler exists, trigger section filter / scroll
    if (sectionKey && onExecuteAiCommand) {
      onExecuteAiCommand(raw, sectionKey);
    }

    setLastFeedback({ text: answer, isError: false });
    setChatLog(prev => [
      ...prev,
      { sender: 'user', text: raw, timestamp: timeStr },
      { sender: 'ai', text: answer, timestamp: timeStr }
    ]);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!commandInput.trim()) return;
    handleProcessQueryOrCommand(commandInput);
    setCommandInput('');
  };

  const handleSuggestedClick = (label: string, key: string) => {
    const timeStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    let aiResponse = `Nightingale AI: Displaying ${label} for ${patient.name}.`;
    
    if (key === 'clearance') {
      aiResponse = `Nightingale AI: Displaying Pre-Op Clearance status and 6 completed clearance items for ${patient.name}.`;
    } else if (key === 'clinicalNotes') {
      aiResponse = `Nightingale AI: Displaying Doctor Notes and Clinical Progress Records for ${patient.name}.`;
    } else if (key === 'nursingNotes') {
      aiResponse = `Nightingale AI: Displaying Pre-Op & PACU Nursing Notes for ${patient.name}.`;
    } else if (key === 'intakeForms') {
      aiResponse = `Nightingale AI: Displaying 9 interactive Intake Forms & Consents for ${patient.name}.`;
    } else if (key === 'documents') {
      aiResponse = `Nightingale AI: Displaying 9 verified clinical document records for ${patient.name}.`;
    } else if (key === 'medications') {
      aiResponse = `Nightingale AI: Displaying active reconciled medications and E-Prescribe controls.`;
    } else if (key === 'financial') {
      aiResponse = `Nightingale AI: Displaying Payment & Financial Summary notes and invoice options.`;
    } else if (key === 'appointments') {
      aiResponse = `Nightingale AI: Displaying Appointment History and 5 Clinical Encounters for ${patient.name}.`;
    } else if (key === 'portalMessages') {
      aiResponse = `Nightingale AI: Displaying Patient Portal Messages & Two-Way Clinical Communications.`;
    } else if (key === 'idInsurance') {
      aiResponse = `Nightingale AI: Displaying Driver's License Photo ID and Primary Insurance Cards.`;
    } else if (key === 'surgicalDetails') {
      aiResponse = `Nightingale AI: Displaying Surgical Team, Surgeon, Anesthesiologist, and Room.`;
    } else if (key === 'quickActions') {
      aiResponse = `Nightingale AI: Displaying Quick Chart Actions & Messaging options.`;
    } else if (key === 'all') {
      aiResponse = `Nightingale AI: Displaying all chart sections for ${patient.name}.`;
    }

    if (onExecuteAiCommand) {
      onExecuteAiCommand(`Show ${label}`, key);
    } else if (onExecuteDirective) {
      onExecuteDirective(key);
    }

    setLastFeedback({ text: aiResponse, isError: false });
    setChatLog(prev => [
      ...prev,
      { sender: 'user', text: `Show ${label}`, timestamp: timeStr },
      { sender: 'ai', text: aiResponse, timestamp: timeStr }
    ]);
  };

  // Contextual suggestions: at most 2 chips, computed from the patient's actual
  // chart state rather than a fixed menu. Everything else (doctor notes, nursing
  // notes, intake forms, documents, medications, payment, ID & insurance,
  // surgical team, etc.) is still reachable — just by typing it into the command
  // input above, the same way you'd ask a coordinator directly.
  const isCleared = patient.readinessLevel === 'CLEARED';
  const contextualCommands: { label: string; key: string; icon: typeof ShieldCheck; badge?: string }[] = [
    isCleared
      ? { label: 'Pre-Op Clearance', key: 'clearance', icon: ShieldCheck }
      : { label: 'Pre-Op Clearance', key: 'clearance', icon: ShieldCheck, badge: 'Action needed' },
    patientUnreadCount > 0
      ? { label: 'Portal Messages', key: 'portalMessages', icon: MessageSquare, badge: `${patientUnreadCount} new` }
      : { label: 'Appointment History', key: 'appointments', icon: Calendar },
  ];

  const commandExamples = [
    'doctor notes', 'nursing notes', 'intake forms', 'documents', 'medications', 'payment & financial', 'ID & insurance', 'surgical team',
  ];

  // Pending items drawn from the patient's real actionItems checklist — this is
  // the app's live model of the nine-step encounter checklist's outstanding
  // clinical/administrative gates. Each maps to the chart section that resolves it.
  const actionTypeToSection: Record<string, string> = {
    EKG: 'clearance',
    PHOTO: 'idInsurance',
    ANESTHESIA: 'clearance',
    IMPLANT: 'surgicalDetails',
    CONSENT: 'intakeForms',
    TRANSPORT: 'appointments',
  };
  const pendingChecklistItems = (patient.actionItems || []).filter((item) => !item.done);

  return (
    <div id="nightingale-coordinator-section" className="bg-[#F1F3EC] text-[#1A2E22] rounded-xl border border-[#3E8FA6]/50 shadow-2xs overflow-hidden transition-all nightingale-highlight-border">

      {/* Top Banner: Clinical Coordinator & AI Assistant Refined Header */}
      <div className="bg-[#F1F3EC] px-4 py-2.5 flex flex-wrap items-center justify-between gap-3 border-b border-[#E1E4DC]">
        <div className="flex items-center gap-2.5">
          <div className="w-7 h-7 rounded-lg bg-[#E7F1F3] border border-[#3E8FA6]/50 flex items-center justify-center text-[#3E8FA6] shadow-2xs">
            <Sparkles className="w-4 h-4 text-[#3E8FA6]" />
          </div>
          <div>
            <div className="flex flex-wrap items-center gap-2">
              <span className="font-bold text-xs text-[#1A2E22] font-display tracking-wide">Nightingale AI</span>
              <span className="text-[10px] text-[#1D4E5A] font-semibold px-2 py-0.5 rounded-full bg-[#E7F1F3] border border-[#3E8FA6]/50 flex items-center gap-0.5">
                <Info className="w-2.5 h-2.5" />
                Clinical Coordinator
              </span>
              <span className="inline-flex items-center gap-1 text-[10px] text-[#1B4332] font-medium font-mono">
                <span className="w-1.5 h-1.5 rounded-full bg-[#2F9E6E] animate-pulse"></span>
                Active: {patient.name}
              </span>
            </div>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {/* Toggle Chat History Log */}
          <button
            type="button"
            onClick={() => setIsChatLogExpanded(!isChatLogExpanded)}
            className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition-all flex items-center gap-1.5 cursor-pointer font-sans shadow-2xs border ${
              isChatLogExpanded
                ? 'bg-[#DCEEE3] text-[#1B4332] border-[#E1E4DC] ring-1 ring-[#1B4332]/20'
                : 'bg-white hover:bg-[#F1F3EC] text-[#1A2E22] border-[#E1E4DC]'
            }`}
            title="Toggle Conversation Log"
          >
            <MessageSquare className={`w-3.5 h-3.5 ${isChatLogExpanded ? 'text-[#1B4332]' : 'text-[#1F6E52]'}`} />
            <span>{isChatLogExpanded ? 'Hide Chat' : `Chat (${chatLog.length})`}</span>
            {isChatLogExpanded ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
          </button>

          {onToggleMinimalMode && (
            <button
              type="button"
              onClick={onToggleMinimalMode}
              className="px-2.5 py-1 rounded-lg text-[11px] font-bold bg-white hover:bg-[#F1F3EC] text-[#1A2E22] border border-[#E1E4DC] transition-all flex items-center gap-1.5 cursor-pointer font-sans shadow-2xs"
              title="Toggle View Density"
            >
              {isMinimalMode ? <Maximize2 className="w-3.5 h-3.5 text-[#1F6E52]" /> : <Minimize2 className="w-3.5 h-3.5 text-[#1F6E52]" />}
              <span>{isMinimalMode ? 'Expanded' : 'Compact'}</span>
            </button>
          )}
        </div>
      </div>

      {/* Unified Search / Ask / Directives Area */}
      <div className="p-3 bg-[#F1F3EC] space-y-2.5">
        <form onSubmit={handleSubmit} className="relative flex items-center gap-2">
          <div className="relative flex-1">
            <input
              type="text"
              value={commandInput}
              onChange={(e) => setCommandInput(e.target.value)}
              placeholder="Ask Nightingale AI or instruct commands (e.g. 'Show pre-op clearance', 'What are her allergies?', 'Doctor notes', 'Medications', 'E-Prescribe Augmentin')..."
              className="w-full pl-9 pr-24 py-2.5 bg-white border border-[#E1E4DC] rounded-xl text-xs font-semibold text-[#1A2E22] placeholder:text-[#5B6B60] focus:outline-hidden focus:ring-2 focus:ring-[#1F6E52] focus:border-[#1F6E52] transition-all shadow-2xs"
            />
            <Sparkles className="w-4 h-4 text-[#1F6E52] absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            <button
              type="submit"
              disabled={!commandInput.trim()}
              className="absolute right-1.5 top-1/2 -translate-y-1/2 px-3 py-1.5 bg-[#1F6E52] hover:bg-[#17553F] disabled:opacity-40 disabled:hover:bg-[#1F6E52] text-white rounded-lg text-xs font-bold transition-all flex items-center gap-1 cursor-pointer shadow-xs font-sans"
            >
              <Send className="w-3 h-3" />
              <span>Ask AI</span>
            </button>
          </div>
        </form>

        {/* Contextual Suggestions Row (max 2 — changes with chart state) */}
        <div className="space-y-1.5 pt-0.5">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-bold text-[#5B6B60] uppercase tracking-wider font-display flex items-center gap-1">
              <Sparkles className="w-3 h-3 text-[#1F6E52]" />
              <span>Suggested:</span>
            </span>
            {selectedCommandKey && selectedCommandKey !== 'all' && (
              <span className="text-[9.5px] font-bold text-[#1B4332] bg-[#DCEEE3] px-2 py-0.5 rounded-full border border-[#E1E4DC]">
                Active Filter: {selectedCommandKey}
              </span>
            )}
          </div>

          <div className="flex items-center gap-1.5 flex-wrap">
            {contextualCommands.map((cmd) => {
              const IconComp = cmd.icon;
              const isActive = selectedCommandKey === cmd.key || (selectedCommandKey === 'all' && cmd.key === 'all');
              return (
                <button
                  key={cmd.key}
                  type="button"
                  onClick={() => handleSuggestedClick(cmd.label, cmd.key)}
                  className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold transition-all cursor-pointer border flex items-center gap-1.5 shadow-2xs font-sans ${
                    isActive
                      ? 'bg-[#1F6E52] text-white border-[#17553F] ring-1 ring-[#17553F]/20 font-bold'
                      : 'bg-white hover:bg-[#F1F3EC] text-[#1A2E22] border-[#E1E4DC]'
                  }`}
                >
                  <IconComp className={`w-3 h-3 ${isActive ? 'text-white' : 'text-[#1F6E52]'}`} />
                  <span>{cmd.label}</span>
                  {cmd.badge && (
                    <span className={`px-1.5 py-0.2 rounded-full text-[9.5px] font-black ${
                      isActive ? 'bg-white text-[#1F6E52]' : 'bg-[#7A4E17] text-white'
                    }`}>
                      {cmd.badge}
                    </span>
                  )}
                  {isActive && <Check className="w-3 h-3 text-white ml-0.5" />}
                </button>
              );
            })}
            <span className="text-[10.5px] text-[#5B6B60] italic">
              or type it — try "{commandExamples[Math.floor((patient.patientId?.length || 0) % commandExamples.length)]}"
            </span>
          </div>
        </div>

        {/* Common Actions — the repeated per-patient tasks (chart documents, intake
            forms, provider notes, messages, print) live here as Nightingale suggested
            commands instead of being duplicated as standalone buttons elsewhere on
            the chart page. */}
        <div className="space-y-1.5 pt-1 border-t border-[#E1E4DC]">
          <span className="text-[10px] font-bold text-[#5B6B60] uppercase tracking-wider font-display flex items-center gap-1">
            <Zap className="w-3 h-3 text-[#3E8FA6]" />
            <span>Common Actions:</span>
          </span>
          <div className="flex items-center gap-1.5 flex-wrap">
            <button
              type="button"
              onClick={() => handleSuggestedClick('Chart Documents', 'documents')}
              className="px-2.5 py-1 rounded-lg text-[11px] font-semibold transition-all cursor-pointer border flex items-center gap-1.5 shadow-2xs font-sans bg-white hover:bg-[#F1F3EC] text-[#1A2E22] border-[#E1E4DC]"
            >
              <FileText className="w-3 h-3 text-[#1F6E52]" />
              <span>Chart Documents</span>
            </button>
            <button
              type="button"
              onClick={() => handleSuggestedClick('Intake Forms', 'intakeForms')}
              className="px-2.5 py-1 rounded-lg text-[11px] font-semibold transition-all cursor-pointer border flex items-center gap-1.5 shadow-2xs font-sans bg-white hover:bg-[#F1F3EC] text-[#1A2E22] border-[#E1E4DC]"
            >
              <FileCheck className="w-3 h-3 text-[#1F6E52]" />
              <span>Intake Forms</span>
            </button>
            <button
              type="button"
              onClick={() => handleSuggestedClick('Provider Notes', 'clinicalNotes')}
              className="px-2.5 py-1 rounded-lg text-[11px] font-semibold transition-all cursor-pointer border flex items-center gap-1.5 shadow-2xs font-sans bg-white hover:bg-[#F1F3EC] text-[#1A2E22] border-[#E1E4DC]"
            >
              <Stethoscope className="w-3 h-3 text-[#1F6E52]" />
              <span>Provider Notes</span>
            </button>
            <button
              type="button"
              onClick={() => handleSuggestedClick('Patient Messages', 'portalMessages')}
              className="px-2.5 py-1 rounded-lg text-[11px] font-semibold transition-all cursor-pointer border flex items-center gap-1.5 shadow-2xs font-sans bg-white hover:bg-[#F1F3EC] text-[#1A2E22] border-[#E1E4DC]"
            >
              <MessageSquare className="w-3 h-3 text-[#1F6E52]" />
              <span>Messages</span>
              {patientUnreadCount > 0 && (
                <span className="px-1.5 py-0.2 rounded-full text-[9.5px] font-black bg-[#7A4E17] text-white">
                  {patientUnreadCount}
                </span>
              )}
            </button>
            {/* Print now lives as its own dedicated button (with the full
                labels/facesheet/visit-summary/ID-cards dropdown) in the patient
                header — kept out of the AI suggested commands here. */}
            {onOpenEPrescribe && (
              <button
                type="button"
                onClick={onOpenEPrescribe}
                className="px-2.5 py-1 rounded-lg text-[11px] font-semibold transition-all cursor-pointer border flex items-center gap-1.5 shadow-2xs font-sans bg-white hover:bg-[#F1F3EC] text-[#1A2E22] border-[#E1E4DC]"
              >
                <Send className="w-3 h-3 text-[#1F6E52]" />
                <span>E-Prescribe</span>
              </button>
            )}
            {onOpenNoteWorkspace && (
              <button
                type="button"
                onClick={onOpenNoteWorkspace}
                className="px-2.5 py-1 rounded-lg text-[11px] font-semibold transition-all cursor-pointer border flex items-center gap-1.5 shadow-2xs font-sans bg-white hover:bg-[#F1F3EC] text-[#1A2E22] border-[#E1E4DC]"
              >
                <Mic className="w-3 h-3 text-[#1F6E52]" />
                <span>Dictate Note</span>
              </button>
            )}
          </div>
        </div>

        {/* Pending Nine-Step Encounter Checklist Items — proactive Nightingale
            suggestions drawn from the patient's live actionItems checklist. */}
        {pendingChecklistItems.length > 0 && (
          <div className="space-y-1.5 pt-1 border-t border-[#E1E4DC]">
            <span className="text-[10px] font-bold text-[#7A4E17] uppercase tracking-wider font-display flex items-center gap-1">
              <AlertCircle className="w-3 h-3 text-[#C98A34]" />
              <span>Pending Encounter Checklist Items ({pendingChecklistItems.length}):</span>
            </span>
            <div className="space-y-1">
              {pendingChecklistItems.map((item) => (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => handleSuggestedClick(item.text, actionTypeToSection[item.type] || 'clearance')}
                  className={`w-full flex items-center justify-between gap-2 px-2.5 py-1.5 rounded-lg border text-left transition-all cursor-pointer shadow-2xs font-sans ${
                    item.urgent
                      ? 'bg-[#FBE4E1] border-[#C1503D]/40 hover:bg-[#F8D5D1]'
                      : 'bg-[#FBF3E6] border-[#C98A34]/40 hover:bg-[#F7EAD1]'
                  }`}
                >
                  <span className="flex items-center gap-1.5 text-[11px] font-semibold text-[#1A2E22]">
                    <AlertCircle className={`w-3.5 h-3.5 shrink-0 ${item.urgent ? 'text-[#C1503D]' : 'text-[#C98A34]'}`} />
                    <span>{item.text}</span>
                  </span>
                  <span className="text-[10px] font-bold text-[#1F6E52] shrink-0">Resolve →</span>
                </button>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Expandable Conversation Stream */}
      {isChatLogExpanded && (
        <div className="p-3 bg-white border-t border-[#E1E4DC] space-y-2 max-h-60 overflow-y-auto animate-in fade-in duration-200">
          <div className="flex items-center justify-between text-[10px] font-bold text-[#5B6B60] uppercase tracking-wider font-mono border-b border-[#F1F3EC] pb-1.5">
            <span className="flex items-center gap-1">
              <Bot className="w-3.5 h-3.5 text-[#1F6E52]" />
              <span>Nightingale AI Clinical Conversation Log</span>
            </span>
            <button
              onClick={() => setChatLog([
                {
                  sender: 'ai',
                  text: `Hello! I'm Nightingale AI. Ask me clinical questions about ${patient.name}'s chart or select a suggested command.`,
                  timestamp: 'Active'
                }
              ])}
              className="text-[#5B6B60] hover:text-[#1A2E22] flex items-center gap-1 cursor-pointer lowercase"
            >
              <RotateCcw className="w-3 h-3" />
              <span>clear log</span>
            </button>
          </div>

          <div className="space-y-2 text-xs">
            {chatLog.map((msg, idx) => {
              const isUser = msg.sender === 'user' || msg.sender === 'Clinician';
              return (
                <div
                  key={idx}
                  className={`p-2.5 rounded-xl max-w-2xl leading-relaxed font-medium ${
                    isUser
                      ? 'bg-[#1F6E52] text-white ml-auto text-right shadow-2xs'
                      : 'bg-[#DCEEE3]/70 text-[#1A2E22] border border-[#E1E4DC] shadow-2xs'
                  }`}
                >
                  <div className={`text-[10px] font-bold mb-0.5 flex items-center gap-1.5 justify-between ${
                    isUser ? 'text-[#DCEEE3]' : 'text-[#1B4332]'
                  }`}>
                    <span>{isUser ? 'Clinician' : 'Nightingale AI'}</span>
                    {msg.timestamp && (
                      <span className={`text-[9px] font-mono ${isUser ? 'text-[#DCEEE3]' : 'text-[#5B6B60]'}`}>
                        {msg.timestamp}
                      </span>
                    )}
                  </div>
                  <div className="text-xs">{msg.text}</div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Real-Time Single-Line Feedback from Nightingale */}
      {lastFeedback && (
        <div className={`px-4 py-2 text-xs font-medium flex items-center gap-2 border-t ${
          lastFeedback.isError 
            ? 'bg-[#FBE4E1] text-[#7A2E22] border-[#C1503D]/30' 
            : 'bg-[#DCEEE3] text-[#1B4332] border-[#E1E4DC]'
        }`}>
          {lastFeedback.isError ? (
            <AlertCircle className="w-4 h-4 text-[#C1503D] shrink-0" />
          ) : (
            <CheckCircle2 className="w-4 h-4 text-[#2F9E6E] shrink-0" />
          )}
          <span className="flex-1 leading-snug">{lastFeedback.text}</span>
          {!isChatLogExpanded && chatLog.length > 1 && (
            <button
              onClick={() => setIsChatLogExpanded(true)}
              className="text-[10px] font-bold text-[#1B4332] underline cursor-pointer shrink-0"
            >
              View conversation ({chatLog.length})
            </button>
          )}
        </div>
      )}

    </div>
  );
};
