import React, { useEffect, useState } from 'react';
import { X, UserCheck, FileText, CheckCircle2, ClipboardCheck, Smartphone, PenTool, Lock, ShieldCheck } from 'lucide-react';
import type { PatientCase } from '../types';
import { INITIAL_INTAKE_HTML_FORMS, IntakeHtmlForm } from '../data/intakeHtmlForms';
import { SignaturePad } from './SignaturePad';
import { getPrefilledIntakeHtml } from '../utils/formPrefill';

interface OfficeCheckInPageProps {
  patient: PatientCase;
  onClose: () => void;
  onComplete: (patientId: string) => void;
}

// Day-of-surgery front-desk check-in review — front office staff step through
// the practice's intake forms to verify/complete them for the arriving
// patient before the encounter proceeds, per the "Patient Check-In Workflow"
// spec (section 3d). Mirrors the Patient Portal's check-in form viewer: a
// simple list of forms that opens into one full-screen page per form, with
// the verification/attestation panel integrated at the bottom of the form
// itself — tablet-friendly, no persistent sidebar competing for width.
export const OfficeCheckInPage: React.FC<OfficeCheckInPageProps> = ({ patient, onClose, onComplete }) => {
  const forms: IntakeHtmlForm[] = INITIAL_INTAKE_HTML_FORMS;
  const [activeFormId, setActiveFormId] = useState<string | null>(null);
  const [verifiedIds, setVerifiedIds] = useState<Set<string>>(new Set());
  const [verifiedMeta, setVerifiedMeta] = useState<Record<string, { by: string; date: string }>>({});
  const [frontDeskSignature, setFrontDeskSignature] = useState<string | null>(null);

  // Draft state for whichever form is currently open — reset each time a
  // different form is opened, mirroring the portal's pattern.
  const [draftSignature, setDraftSignature] = useState<string | null>(null);
  const [draftAgreed, setDraftAgreed] = useState(false);

  useEffect(() => {
    setDraftSignature(null);
    setDraftAgreed(false);
  }, [activeFormId]);

  const activeForm = forms.find((f) => f.id === activeFormId) || null;
  const verifiedCount = verifiedIds.size;
  const allVerified = forms.length > 0 && verifiedCount === forms.length;

  const submitActiveForm = () => {
    if (!activeFormId || !draftSignature || !draftAgreed) return;
    const dateStr = new Date().toLocaleDateString('en-US', { month: 'short', day: '2-digit', year: 'numeric' });
    setVerifiedIds((prev) => new Set(prev).add(activeFormId));
    setVerifiedMeta((prev) => ({ ...prev, [activeFormId]: { by: 'Front Desk Staff', date: dateStr } }));
    setActiveFormId(null);
  };

  // Lightweight completion path for forms that don't require a signature —
  // driven by the form template's own `requiresSignature` flag (see
  // intakeHtmlForms.ts) rather than guessed from content, so it stays
  // correct however a given practice's form library is put together.
  const markActiveFormReviewed = () => {
    if (!activeFormId) return;
    const dateStr = new Date().toLocaleDateString('en-US', { month: 'short', day: '2-digit', year: 'numeric' });
    setVerifiedIds((prev) => new Set(prev).add(activeFormId));
    setVerifiedMeta((prev) => ({ ...prev, [activeFormId]: { by: 'Front Desk Staff', date: dateStr } }));
    setActiveFormId(null);
  };

  // ============================================================
  // SINGLE FORM VIEW — matches the portal's full-screen form viewer
  // ============================================================
  if (activeForm) {
    const isVerified = verifiedIds.has(activeForm.id);
    const meta = verifiedMeta[activeForm.id];
    const needsSignature = activeForm.requiresSignature;

    return (
      <div className="fixed inset-0 z-[99999] bg-stone-100 flex flex-col w-screen h-screen overflow-y-auto animate-in fade-in duration-150">
        <div className="sticky top-0 z-[100000] bg-slate-900/95 border-b border-slate-700 px-4 sm:px-6 py-3 flex items-center justify-between backdrop-blur-md shadow-lg text-white">
          <div className="flex items-center gap-3 min-w-0">
            <div className="p-2 rounded-xl bg-teal-500/20 border border-teal-500/40 text-teal-300 shrink-0">
              <FileText className="w-4 h-4" />
            </div>
            <div className="min-w-0">
              <h3 className="font-bold text-xs sm:text-sm text-white flex items-center gap-2 flex-wrap">
                <span className="truncate">{activeForm.title}</span>
                <span className={`text-[10px] px-2 py-0.5 rounded-full border font-semibold shrink-0 ${
                  isVerified ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40' : 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                }`}>
                  {isVerified ? (needsSignature ? '✓ Verified' : '✓ Reviewed') : needsSignature ? 'Action Required' : 'Review Required'}
                </span>
              </h3>
              <p className="text-[11px] text-slate-400 font-mono hidden sm:block truncate">{activeForm.fileName}</p>
            </div>
          </div>

          <button
            type="button"
            onClick={() => setActiveFormId(null)}
            className="px-3.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-xl text-xs font-bold transition-colors flex items-center gap-1.5 cursor-pointer border border-slate-700 shadow-xs group shrink-0"
          >
            <X className="w-4 h-4 text-slate-400 group-hover:text-white" />
            <span>Close Form</span>
          </button>
        </div>

        <div className="w-full flex-1 bg-stone-100 p-2 sm:p-6 flex flex-col items-center gap-6 min-h-screen">
          <div className="w-full max-w-4xl bg-white rounded-2xl shadow-xl border border-stone-200 p-3 sm:p-6 my-2 relative">

            {/* Rendered in an iframe so the form's own global CSS can't leak
                out and restyle the verification panel below it. Pre-filled from
                the patient's chart when on file from a prior visit — front
                desk reviews and confirms rather than re-collecting from
                scratch; a first-time patient's forms open blank as usual. */}
            <iframe
              title={activeForm.title}
              srcDoc={getPrefilledIntakeHtml(activeForm.htmlTemplate, patient)}
              sandbox="allow-forms allow-scripts allow-modals"
              className="w-full border-0"
              style={{ height: '1400px' }}
            />

            {/* Verification & Attestation Section — integrated at the bottom of
                the single form page, matching the patient portal exactly */}
            <div className="mt-8 pt-6 border-t-2 border-slate-200/90">
              {isVerified && needsSignature ? (
                <div className="p-6 bg-emerald-50/80 border-2 border-emerald-400/60 rounded-2xl space-y-3.5 text-xs text-emerald-950 shadow-xs">
                  <div className="flex items-center justify-between flex-wrap gap-2">
                    <div className="flex items-center gap-2 text-emerald-900 font-bold text-sm">
                      <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                      <span>Front Desk Verification</span>
                    </div>
                    <span className="bg-emerald-200/80 text-emerald-900 font-bold px-2.5 py-0.5 rounded-full text-[10.5px]">
                      Verified &amp; Complete
                    </span>
                  </div>
                  <p className="leading-relaxed text-emerald-900">
                    This form has been reviewed and verified for {patient.name}'s day-of-surgery check-in.
                  </p>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 border-t border-emerald-200/80 font-mono text-[11px]">
                    <div>
                      <span className="text-emerald-700 block font-sans font-bold text-[10px] uppercase">Verified By</span>
                      <span className="font-bold text-emerald-950">{meta?.by || 'Front Desk Staff'}</span>
                    </div>
                    <div>
                      <span className="text-emerald-700 block font-sans font-bold text-[10px] uppercase">Verification Timestamp</span>
                      <span className="font-bold text-emerald-950">{meta?.date || 'Verified'}</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 pt-1 text-[10.5px] text-emerald-800 font-mono">
                    <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span>Audit Trail: Cryptographic SHA-256 Signature Sealed into EHR Chart</span>
                  </div>
                </div>
              ) : isVerified && !needsSignature ? (
                <div className="p-6 bg-emerald-50/80 border-2 border-emerald-400/60 rounded-2xl space-y-3.5 text-xs text-emerald-950 shadow-xs">
                  <div className="flex items-center justify-between flex-wrap gap-2">
                    <div className="flex items-center gap-2 text-emerald-900 font-bold text-sm">
                      <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                      <span>Front Desk Review</span>
                    </div>
                    <span className="bg-emerald-200/80 text-emerald-900 font-bold px-2.5 py-0.5 rounded-full text-[10.5px]">
                      Reviewed &amp; Filed
                    </span>
                  </div>
                  <p className="leading-relaxed text-emerald-900">
                    This form type doesn't require a signature. It has been reviewed and filed for {patient.name}'s day-of-surgery check-in.
                  </p>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 border-t border-emerald-200/80 font-mono text-[11px]">
                    <div>
                      <span className="text-emerald-700 block font-sans font-bold text-[10px] uppercase">Reviewed By</span>
                      <span className="font-bold text-emerald-950">{meta?.by || 'Front Desk Staff'}</span>
                    </div>
                    <div>
                      <span className="text-emerald-700 block font-sans font-bold text-[10px] uppercase">Review Timestamp</span>
                      <span className="font-bold text-emerald-950">{meta?.date || 'Verified'}</span>
                    </div>
                  </div>
                </div>
              ) : needsSignature ? (
                <div className="p-6 bg-slate-50 border-2 border-teal-500/40 rounded-2xl space-y-4 text-xs text-slate-900 shadow-md">
                  <div className="flex items-center gap-2 text-teal-900 font-bold text-sm">
                    <PenTool className="w-4 h-4 text-teal-600" />
                    <span>Front Desk Verification</span>
                  </div>

                  <div className="p-3.5 bg-teal-50/70 border border-teal-200 rounded-xl text-xs text-teal-950 space-y-2">
                    <p className="leading-relaxed">
                      By signing below, I certify that I have reviewed this form with the patient and confirmed it is complete and accurate for today's visit.
                    </p>
                    <div className="flex items-center gap-2 pt-1 font-mono text-[11px] text-teal-800">
                      <Lock className="w-3.5 h-3.5 text-teal-600" />
                      <span>IP Address &amp; Time: {new Date().toLocaleDateString()} {new Date().toLocaleTimeString()} (Logged)</span>
                    </div>
                  </div>

                  <div className="space-y-3 pt-1">
                    <SignaturePad label="Front Desk Staff Signature" savedSignature={draftSignature} onSave={setDraftSignature} />

                    <label className="flex items-start gap-2.5 cursor-pointer pt-1">
                      <input
                        type="checkbox"
                        checked={draftAgreed}
                        onChange={(e) => setDraftAgreed(e.target.checked)}
                        className="w-4 h-4 rounded border-slate-300 text-teal-600 focus:ring-teal-500 mt-0.5"
                      />
                      <span className="text-xs text-slate-700 leading-relaxed font-medium">
                        I acknowledge that my handwritten signature above constitutes a legally binding signature identical to an ink signature on paper.
                      </span>
                    </label>
                  </div>

                  <div className="pt-3 border-t border-slate-200 flex items-center justify-between">
                    <button
                      type="button"
                      onClick={() => setActiveFormId(null)}
                      className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-xl text-xs font-bold transition-colors cursor-pointer"
                    >
                      Cancel
                    </button>
                    <button
                      type="button"
                      onClick={submitActiveForm}
                      disabled={!draftSignature || !draftAgreed}
                      className="px-6 py-2.5 bg-teal-600 hover:bg-teal-700 disabled:bg-slate-300 disabled:cursor-not-allowed text-white rounded-xl text-xs font-bold shadow-md transition-all flex items-center gap-2 cursor-pointer"
                    >
                      <CheckCircle2 className="w-4 h-4" />
                      <span>Mark Verified &amp; Complete</span>
                    </button>
                  </div>
                </div>
              ) : (
                // No signature required for this form — a lighter
                // review-and-file action instead of the full signature pad.
                <div className="p-6 bg-slate-50 border-2 border-slate-300 rounded-2xl space-y-4 text-xs text-slate-900 shadow-md">
                  <div className="flex items-center gap-2 text-slate-800 font-bold text-sm">
                    <ClipboardCheck className="w-4 h-4 text-slate-500" />
                    <span>Front Desk Review</span>
                  </div>

                  <p className="leading-relaxed text-slate-600">
                    This form doesn't require a signature. Review its contents above with the patient, then mark it reviewed to file it to their chart.
                  </p>

                  <div className="pt-3 border-t border-slate-200 flex items-center justify-between">
                    <button
                      type="button"
                      onClick={() => setActiveFormId(null)}
                      className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-xl text-xs font-bold transition-colors cursor-pointer"
                    >
                      Cancel
                    </button>
                    <button
                      type="button"
                      onClick={markActiveFormReviewed}
                      className="px-6 py-2.5 bg-slate-700 hover:bg-slate-800 text-white rounded-xl text-xs font-bold shadow-md transition-all flex items-center gap-2 cursor-pointer"
                    >
                      <CheckCircle2 className="w-4 h-4" />
                      <span>Mark as Reviewed</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    );
  }

  // ============================================================
  // LIST VIEW — matches the portal's pre-arrival check-in list page
  // ============================================================
  return (
    <div className="fixed inset-0 z-[99999] bg-slate-50 flex flex-col w-screen h-screen overflow-y-auto animate-in fade-in duration-150">
      <div className="sticky top-0 z-[99999] bg-[#1F6E52] text-white px-4 sm:px-6 py-4 flex items-center justify-between shadow-lg">
        <div className="flex items-center gap-3 min-w-0">
          <div className="w-9 h-9 rounded-xl bg-white/15 border border-white/20 text-white flex items-center justify-center shrink-0">
            <UserCheck className="w-4.5 h-4.5" />
          </div>
          <div className="min-w-0">
            <span className="text-[10px] font-mono uppercase tracking-wider text-teal-200 flex items-center gap-1.5">
              <Smartphone className="w-3 h-3" />
              Office Check-In — Tablet-Optimized
            </span>
            <h2 className="font-bold text-sm sm:text-base truncate">{patient.name} — MRN {patient.patientId} — {patient.procedure}</h2>
          </div>
        </div>
        <button
          onClick={onClose}
          className="p-2 rounded-xl text-teal-100 hover:text-white hover:bg-white/10 transition-colors cursor-pointer shrink-0"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      <div className="flex-1 max-w-3xl w-full mx-auto p-4 sm:p-8 space-y-4">
        <p className="text-xs sm:text-sm text-slate-600 font-medium">
          Please review and verify each intake form below with the patient before their visit proceeds. Forms open in a full page — tap a form to begin.
        </p>

        <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-2xs flex items-center justify-between">
          <span className="text-xs sm:text-sm font-bold text-slate-800">{verifiedCount} / {forms.length} forms verified</span>
          {allVerified && (
            <span className="px-3 py-1 rounded-full bg-emerald-100 text-emerald-800 border border-emerald-300 text-[11px] font-bold flex items-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5" />
              Check-in complete
            </span>
          )}
        </div>

        <div className="space-y-2.5">
          {forms.map((f) => {
            const isVerified = verifiedIds.has(f.id);
            return (
              <button
                key={f.id}
                onClick={() => setActiveFormId(f.id)}
                className="w-full text-left p-4 bg-white rounded-2xl border border-slate-200 hover:border-teal-400 hover:shadow-2xs transition-all cursor-pointer flex items-center justify-between gap-3"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${isVerified ? 'bg-emerald-100 text-emerald-700' : 'bg-slate-100 text-slate-500'}`}>
                    <FileText className="w-4.5 h-4.5" />
                  </div>
                  <div className="min-w-0">
                    <div className="text-sm font-bold text-slate-900 truncate">{f.title}</div>
                    <div className="text-[11px] text-slate-500 font-medium">{f.category}</div>
                  </div>
                </div>
                <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full shrink-0 ${isVerified ? 'bg-emerald-100 text-emerald-800 border border-emerald-300' : 'bg-amber-100 text-amber-800 border border-amber-300'}`}>
                  {isVerified ? 'Verified' : 'Action Required'}
                </span>
              </button>
            );
          })}
        </div>

        {allVerified && (
          <div className="p-4 bg-white rounded-2xl border-2 border-teal-500/40 shadow-md space-y-3">
            <div className="flex items-center gap-2 text-teal-900 font-bold text-sm">
              <ClipboardCheck className="w-4 h-4 text-teal-600" />
              <span>Final Front Desk Sign-Off</span>
            </div>
            <SignaturePad label="Front Desk Sign-Off" compact savedSignature={frontDeskSignature} onSave={setFrontDeskSignature} />
            <button
              type="button"
              disabled={!frontDeskSignature}
              onClick={() => onComplete(patient.id)}
              className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 disabled:bg-slate-300 disabled:cursor-not-allowed text-white font-bold text-sm rounded-xl shadow-md transition-colors cursor-pointer flex items-center justify-center gap-2"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>Complete Office Check-In</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
