import React, { useEffect, useMemo, useRef, useState } from 'react';
import * as pdfjsLib from 'pdfjs-dist';
// eslint-disable-next-line import/no-unresolved
import pdfjsWorkerUrl from 'pdfjs-dist/build/pdf.worker.min.mjs?url';
import { X, PenTool, Type, Eraser, Lock, Save, Loader2, FileCheck2 } from 'lucide-react';
import {
  loadPdfDocMeta,
  readPdfFieldDefaults,
  loadStoredPdfDoc,
  saveDraftPdfDoc,
  lockPdfDoc,
  bakeDraftIntoPdf,
  base64ToUint8,
  type PdfDocMeta,
  type PdfFieldMeta,
  type PdfDraftState,
  type PdfDocStatus,
} from '../utils/pdfFormEngine';

pdfjsLib.GlobalWorkerOptions.workerSrc = pdfjsWorkerUrl;

interface PdfFormViewerProps {
  patientId: string;
  documentId: string;
  title: string;
  pdfUrl: string;
  signerName: string;
  /** Values to prefill for specific named fields (e.g. carried over from another
   *  document, or from the patient's chart). Applied on top of the PDF's own
   *  baked-in template defaults, and only for a brand-new draft — never
   *  overwrites what a person already typed. */
  prefill?: Record<string, string | boolean>;
  onClose: () => void;
}

const RENDER_WIDTH = 860; // CSS px the page is rendered at — fixed for v1, no zoom control yet

const PEN_COLOR = '#1B4332';

export const PdfFormViewer: React.FC<PdfFormViewerProps> = ({
  patientId,
  documentId,
  title,
  pdfUrl,
  signerName,
  prefill,
  onClose,
}) => {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [pdfBytes, setPdfBytes] = useState<ArrayBuffer | null>(null);
  const [meta, setMeta] = useState<PdfDocMeta | null>(null);
  const [status, setStatus] = useState<PdfDocStatus>('DRAFT');
  const [lockedPdfBytes, setLockedPdfBytes] = useState<Uint8Array | null>(null);
  const [lockedAt, setLockedAt] = useState<string | null>(null);
  const [lockedBy, setLockedBy] = useState<string | null>(null);

  const [fieldValues, setFieldValues] = useState<Record<string, string | boolean>>({});
  const [signatureImages, setSignatureImages] = useState<Record<string, string>>({});
  const [penStrokes, setPenStrokes] = useState<{ points: { x: number; y: number }[]; color: string }[]>([]);
  const [textAnnotations, setTextAnnotations] = useState<{ x: number; y: number; text: string }[]>([]);
  const [saving, setSaving] = useState<'idle' | 'draft' | 'lock'>('idle');
  const [savedFlash, setSavedFlash] = useState(false);

  const [tool, setTool] = useState<'select' | 'pen' | 'text'>('select');
  const [pendingTextAt, setPendingTextAt] = useState<{ x: number; y: number } | null>(null);
  const [pendingTextValue, setPendingTextValue] = useState('');

  const canvasRef = useRef<HTMLCanvasElement>(null);
  const drawCanvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const viewportRef = useRef<pdfjsLib.PageViewport | null>(null);
  const isDrawingRef = useRef(false);
  const currentStrokeRef = useRef<{ x: number; y: number }[]>([]);
  const [canvasSize, setCanvasSize] = useState({ width: RENDER_WIDTH, height: RENDER_WIDTH * 1.3 });

  // ---------------------------------------------------------------
  // Load: fetch PDF bytes once, then branch on stored status.
  // ---------------------------------------------------------------
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        setLoading(true);
        setError(null);
        const res = await fetch(pdfUrl);
        if (!res.ok) throw new Error(`Could not load PDF (${res.status})`);
        const bytes = await res.arrayBuffer();
        if (cancelled) return;
        setPdfBytes(bytes);

        const docMeta = await loadPdfDocMeta(bytes.slice(0));
        if (cancelled) return;
        setMeta(docMeta);

        const stored = loadStoredPdfDoc(patientId, documentId);
        if (stored && stored.status === 'LOCKED' && stored.lockedPdfBase64) {
          setStatus('LOCKED');
          setLockedPdfBytes(base64ToUint8(stored.lockedPdfBase64));
          setLockedAt(stored.lockedAt ?? null);
          setLockedBy(stored.lockedBy ?? null);
          setFieldValues(stored.draft.fieldValues);
          setSignatureImages(stored.draft.signatureImages);
          setPenStrokes(stored.draft.penStrokes);
          setTextAnnotations(stored.draft.textAnnotations);
        } else if (stored && stored.status === 'DRAFT') {
          setStatus('DRAFT');
          setFieldValues(stored.draft.fieldValues);
          setSignatureImages(stored.draft.signatureImages);
          setPenStrokes(stored.draft.penStrokes);
          setTextAnnotations(stored.draft.textAnnotations);
        } else {
          // Brand new document: start from the template's own baked-in
          // defaults (e.g. the practice's "normal exam" boilerplate), then
          // layer the caller-provided prefill (from another document / the
          // chart) on top for the specific fields it targets.
          const defaults = await readPdfFieldDefaults(bytes.slice(0));
          const merged: Record<string, string | boolean> = { ...defaults };
          if (prefill) {
            const entries = Object.entries(prefill) as [string, string | boolean][];
            for (const [k, v] of entries) {
              if (k in merged) merged[k] = v;
            }
          }
          setStatus('DRAFT');
          setFieldValues(merged);
        }
      } catch (e) {
        if (!cancelled) setError(e instanceof Error ? e.message : 'Failed to load PDF');
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pdfUrl, patientId, documentId]);

  // ---------------------------------------------------------------
  // Render the base page to canvas whenever the source (template vs
  // locked-and-baked) or size changes. Locked docs render WITH their
  // annotation appearances (so the baked-in values show up as flat
  // pixels); draft docs render WITHOUT annotations — our own overlay
  // handles interactivity there instead.
  // ---------------------------------------------------------------
  useEffect(() => {
    const bytesToRender = status === 'LOCKED' ? lockedPdfBytes : pdfBytes ? new Uint8Array(pdfBytes) : null;
    if (!bytesToRender || !canvasRef.current) return;
    let cancelled = false;
    // pdf.js throws "Cannot use the same canvas during multiple render()
    // operations" if a second render starts on the same <canvas> before the
    // first finishes — which React StrictMode's dev-mode double-invoke of
    // effects triggers reliably. Track the in-flight render task so the
    // cleanup can explicitly cancel it instead of racing a second one.
    let renderTask: ReturnType<pdfjsLib.PDFPageProxy['render']> | null = null;

    (async () => {
      const loadingTask = pdfjsLib.getDocument({ data: bytesToRender.slice(0) });
      const doc = await loadingTask.promise;
      if (cancelled) return;
      const page = await doc.getPage(1);
      if (cancelled) return;
      const unscaled = page.getViewport({ scale: 1 });
      const scale = RENDER_WIDTH / unscaled.width;
      const viewport = page.getViewport({ scale });
      if (cancelled) return;
      viewportRef.current = viewport;
      setCanvasSize({ width: viewport.width, height: viewport.height });

      const canvas = canvasRef.current!;
      canvas.width = viewport.width;
      canvas.height = viewport.height;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;
      try {
        renderTask = page.render({
          canvasContext: ctx,
          viewport,
          annotationMode: status === 'LOCKED' ? pdfjsLib.AnnotationMode.ENABLE : pdfjsLib.AnnotationMode.DISABLE,
        });
        await renderTask.promise;
      } catch (e) {
        // A cancelled render rejects with a RenderingCancelledException —
        // expected during StrictMode's double-invoke, not a real error.
        if (cancelled) return;
        console.error('PDF page render failed', e);
        return;
      }
      if (cancelled) return;

      if (drawCanvasRef.current) {
        drawCanvasRef.current.width = viewport.width;
        drawCanvasRef.current.height = viewport.height;
        redrawStrokes();
      }
    })();

    return () => {
      cancelled = true;
      renderTask?.cancel();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [status, lockedPdfBytes, pdfBytes, loading]);

  function redrawStrokes() {
    const canvas = drawCanvasRef.current;
    const viewport = viewportRef.current;
    if (!canvas || !viewport) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    for (const stroke of penStrokes) {
      if (stroke.points.length < 2) continue;
      ctx.strokeStyle = stroke.color;
      ctx.lineWidth = 2.25;
      ctx.beginPath();
      const first = viewport.convertToViewportPoint(stroke.points[0].x, stroke.points[0].y);
      ctx.moveTo(first[0], first[1]);
      for (let i = 1; i < stroke.points.length; i++) {
        const p = viewport.convertToViewportPoint(stroke.points[i].x, stroke.points[i].y);
        ctx.lineTo(p[0], p[1]);
      }
      ctx.stroke();
    }
  }

  useEffect(() => {
    redrawStrokes();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [penStrokes, canvasSize]);

  // ---------------------------------------------------------------
  // Pen tool handlers (draft mode only)
  // ---------------------------------------------------------------
  function toCanvasPoint(e: React.MouseEvent | React.TouchEvent): { x: number; y: number } | null {
    const canvas = drawCanvasRef.current;
    if (!canvas) return null;
    const rect = canvas.getBoundingClientRect();
    const clientX = 'touches' in e ? e.touches[0]?.clientX : (e as React.MouseEvent).clientX;
    const clientY = 'touches' in e ? e.touches[0]?.clientY : (e as React.MouseEvent).clientY;
    if (clientX === undefined || clientY === undefined) return null;
    return {
      x: (clientX - rect.left) * (canvas.width / rect.width),
      y: (clientY - rect.top) * (canvas.height / rect.height),
    };
  }

  function handlePenDown(e: React.MouseEvent | React.TouchEvent) {
    if (tool !== 'pen') return;
    const pt = toCanvasPoint(e);
    if (!pt) return;
    isDrawingRef.current = true;
    currentStrokeRef.current = [pt];
  }

  function handlePenMove(e: React.MouseEvent | React.TouchEvent) {
    if (tool !== 'pen' || !isDrawingRef.current) return;
    const pt = toCanvasPoint(e);
    const canvas = drawCanvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (!pt || !ctx) return;
    const last = currentStrokeRef.current[currentStrokeRef.current.length - 1];
    ctx.strokeStyle = PEN_COLOR;
    ctx.lineWidth = 2.25;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.beginPath();
    ctx.moveTo(last.x, last.y);
    ctx.lineTo(pt.x, pt.y);
    ctx.stroke();
    currentStrokeRef.current.push(pt);
  }

  function handlePenUp() {
    if (tool !== 'pen' || !isDrawingRef.current) return;
    isDrawingRef.current = false;
    const viewport = viewportRef.current;
    if (viewport && currentStrokeRef.current.length > 1) {
      const pdfPoints = currentStrokeRef.current.map((p) => {
        const [px, py] = viewport.convertToPdfPoint(p.x, p.y);
        return { x: px, y: py };
      });
      setPenStrokes((prev) => [...prev, { points: pdfPoints, color: PEN_COLOR }]);
    }
    currentStrokeRef.current = [];
  }

  function handleOverlayClick(e: React.MouseEvent) {
    if (tool !== 'text') return;
    const canvas = drawCanvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    setPendingTextAt({ x, y });
    setPendingTextValue('');
  }

  function commitPendingText() {
    const viewport = viewportRef.current;
    if (!pendingTextAt || !viewport || !pendingTextValue.trim()) {
      setPendingTextAt(null);
      return;
    }
    const [px, py] = viewport.convertToPdfPoint(pendingTextAt.x, pendingTextAt.y);
    setTextAnnotations((prev) => [...prev, { x: px, y: py - 3, text: pendingTextValue.trim() }]);
    setPendingTextAt(null);
    setPendingTextValue('');
  }

  // ---------------------------------------------------------------
  // Field overlay geometry
  // ---------------------------------------------------------------
  const overlayRects = useMemo(() => {
    const viewport = viewportRef.current;
    if (!meta || !viewport) return [];
    return meta.fields.flatMap((field: PdfFieldMeta) =>
      field.rects.map((r, i) => {
        const [vx1, vy1] = viewport.convertToViewportPoint(r.x, r.y);
        const [vx2, vy2] = viewport.convertToViewportPoint(r.x + r.width, r.y + r.height);
        return {
          field,
          widgetIndex: i,
          left: Math.min(vx1, vx2),
          top: Math.min(vy1, vy2),
          width: Math.abs(vx2 - vx1),
          height: Math.abs(vy2 - vy1),
        };
      })
    );
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [meta, canvasSize]);

  const textAnnotationPositions = useMemo(() => {
    const viewport = viewportRef.current;
    if (!viewport) return [];
    return textAnnotations.map((ann) => {
      const [x, y] = viewport.convertToViewportPoint(ann.x, ann.y);
      return { ...ann, left: x, top: y };
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [textAnnotations, canvasSize]);

  // ---------------------------------------------------------------
  // Save
  // ---------------------------------------------------------------
  function currentDraft(): PdfDraftState {
    return {
      fieldValues,
      signatureImages,
      penStrokes,
      textAnnotations,
      lastSavedAt: new Date().toISOString(),
    };
  }

  async function handleSaveEditable() {
    setSaving('draft');
    try {
      saveDraftPdfDoc(patientId, documentId, currentDraft());
      setSavedFlash(true);
      setTimeout(() => setSavedFlash(false), 1800);
    } finally {
      setSaving('idle');
    }
  }

  async function handleSaveAndLock() {
    if (!pdfBytes || !meta) return;
    setSaving('lock');
    try {
      const draft = currentDraft();
      const baked = await bakeDraftIntoPdf(pdfBytes.slice(0), draft, meta.fields);
      lockPdfDoc(patientId, documentId, draft, baked, signerName);
      setStatus('LOCKED');
      setLockedPdfBytes(baked);
      setLockedAt(new Date().toISOString());
      setLockedBy(signerName);
    } finally {
      setSaving('idle');
    }
  }

  const isLocked = status === 'LOCKED';

  return (
    <div className="fixed inset-0 z-[99999] bg-stone-100 flex flex-col w-screen h-screen overflow-y-auto animate-in fade-in duration-150">
      {/* Header */}
      <div className="sticky top-0 z-[100000] bg-slate-900/95 border-b border-slate-700 px-4 sm:px-6 py-3 flex items-center justify-between backdrop-blur-md shadow-lg text-white">
        <div className="flex items-center gap-3 min-w-0">
          <div className="p-2 rounded-xl bg-teal-500/20 border border-teal-500/40 text-teal-300 shrink-0">
            <FileCheck2 className="w-4 h-4" />
          </div>
          <div className="min-w-0">
            <h3 className="font-bold text-xs sm:text-sm text-white flex items-center gap-2 flex-wrap">
              <span className="truncate">{title}</span>
              <span
                className={`text-[10px] px-2 py-0.5 rounded-full border font-semibold shrink-0 ${
                  isLocked
                    ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                    : 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                }`}
              >
                {isLocked ? '🔒 Locked — Read Only' : 'Draft — Editable'}
              </span>
            </h3>
            {isLocked && lockedBy && (
              <p className="text-[11px] text-slate-400 hidden sm:block truncate">
                Locked by {lockedBy}{lockedAt ? ` on ${new Date(lockedAt).toLocaleString()}` : ''}
              </p>
            )}
          </div>
        </div>

        <div className="flex items-center gap-2">
          {!isLocked && !loading && !error && (
            <>
              <button
                type="button"
                onClick={() => setTool(tool === 'pen' ? 'select' : 'pen')}
                title="Pen tool — draw freehand anywhere on the form"
                className={`px-2.5 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer border transition-colors ${
                  tool === 'pen'
                    ? 'bg-teal-500 text-white border-teal-400'
                    : 'bg-slate-800 hover:bg-slate-700 text-slate-300 border-slate-700'
                }`}
              >
                <PenTool className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Pen</span>
              </button>
              <button
                type="button"
                onClick={() => setTool(tool === 'text' ? 'select' : 'text')}
                title="Text tool — click anywhere to add a typed note"
                className={`px-2.5 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer border transition-colors ${
                  tool === 'text'
                    ? 'bg-teal-500 text-white border-teal-400'
                    : 'bg-slate-800 hover:bg-slate-700 text-slate-300 border-slate-700'
                }`}
              >
                <Type className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Text</span>
              </button>
              {penStrokes.length > 0 && (
                <button
                  type="button"
                  onClick={() => setPenStrokes([])}
                  title="Clear all pen marks"
                  className="px-2.5 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer border bg-slate-800 hover:bg-slate-700 text-slate-300 border-slate-700"
                >
                  <Eraser className="w-3.5 h-3.5" />
                </button>
              )}
              <div className="w-px h-5 bg-slate-700 mx-1" />
              <button
                type="button"
                onClick={handleSaveEditable}
                disabled={saving !== 'idle'}
                className="px-3 py-1.5 bg-slate-700 hover:bg-slate-600 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
              >
                {saving === 'draft' ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Save className="w-3.5 h-3.5" />}
                <span>{savedFlash ? 'Saved' : 'Save (Editable)'}</span>
              </button>
              <button
                type="button"
                onClick={handleSaveAndLock}
                disabled={saving !== 'idle'}
                className="px-3 py-1.5 bg-[#1F6E52] hover:bg-[#17553F] text-white rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
              >
                {saving === 'lock' ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Lock className="w-3.5 h-3.5" />}
                <span>Save &amp; Lock</span>
              </button>
            </>
          )}
          <button
            type="button"
            onClick={onClose}
            className="px-3.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-xl text-xs font-bold transition-colors flex items-center gap-1.5 cursor-pointer border border-slate-700 shadow-xs group shrink-0"
          >
            <X className="w-4 h-4 text-slate-400 group-hover:text-white" />
            <span>Close</span>
          </button>
        </div>
      </div>

      <div className="w-full flex-1 bg-stone-100 p-2 sm:p-6 flex flex-col items-center gap-4 min-h-screen">
        {loading && (
          <div className="py-24 flex flex-col items-center gap-3 text-stone-500">
            <Loader2 className="w-6 h-6 animate-spin" />
            <span className="text-xs font-bold">Loading PDF…</span>
          </div>
        )}
        {error && (
          <div className="py-24 flex flex-col items-center gap-2 text-red-600">
            <span className="text-xs font-bold">Couldn't load this document.</span>
            <span className="text-[11px]">{error}</span>
          </div>
        )}

        {!loading && !error && (
          <div
            ref={containerRef}
            className="relative bg-white rounded-2xl shadow-xl border border-stone-200"
            style={{ width: canvasSize.width, height: canvasSize.height }}
          >
            <canvas ref={canvasRef} className="absolute inset-0 rounded-2xl" />

            {/* Field overlay — only interactive in draft mode */}
            {!isLocked &&
              overlayRects.map(({ field, widgetIndex, left, top, width, height }) => {
                const key = `${field.name}__${widgetIndex}`;
                if (field.kind === 'text') {
                  return (
                    <input
                      key={key}
                      type="text"
                      value={typeof fieldValues[field.name] === 'string' ? (fieldValues[field.name] as string) : ''}
                      onChange={(e) => setFieldValues((prev) => ({ ...prev, [field.name]: e.target.value }))}
                      className="absolute bg-[#E7F1F3]/40 focus:bg-[#E7F1F3]/80 border border-transparent focus:border-teal-400 rounded-[3px] text-[11px] font-medium text-slate-900 px-1 outline-none"
                      style={{ left, top, width, height, pointerEvents: tool === 'select' ? 'auto' : 'none' }}
                    />
                  );
                }
                if (field.kind === 'checkbox') {
                  const checked = Boolean(fieldValues[field.name]);
                  return (
                    <button
                      key={key}
                      type="button"
                      onClick={() => setFieldValues((prev) => ({ ...prev, [field.name]: !checked }))}
                      className={`absolute rounded-[3px] border-2 flex items-center justify-center transition-colors cursor-pointer ${
                        checked ? 'bg-[#1F6E52] border-[#1F6E52]' : 'bg-white/70 border-slate-400 hover:border-teal-500'
                      }`}
                      style={{ left, top, width, height, pointerEvents: tool === 'select' ? 'auto' : 'none' }}
                    >
                      {checked && <span className="text-white text-[10px] font-bold leading-none">✓</span>}
                    </button>
                  );
                }
                if (field.kind === 'signature') {
                  const hasSig = Boolean(signatureImages[field.name]);
                  return (
                    <div
                      key={key}
                      className="absolute border border-dashed border-teal-400/70 bg-white/40 rounded-md overflow-hidden"
                      style={{ left, top, width, height, pointerEvents: tool === 'select' ? 'auto' : 'none' }}
                    >
                      {hasSig ? (
                        <img src={signatureImages[field.name]} alt="Signature" className="w-full h-full object-contain" />
                      ) : (
                        <MiniSignatureCapture
                          onSave={(dataUrl) => setSignatureImages((prev) => ({ ...prev, [field.name]: dataUrl }))}
                        />
                      )}
                    </div>
                  );
                }
                return null;
              })}

            {/* Pen + text annotation layer. This canvas sits on top of the
                whole page, so it must get out of the way (pointerEvents:
                'none') whenever the Pen/Text tools aren't active — otherwise
                it silently swallows every click meant for the field overlay
                beneath it, even though nothing about it looks clickable. */}
            <canvas
              ref={drawCanvasRef}
              className="absolute inset-0 rounded-2xl"
              style={{
                cursor: tool === 'pen' ? 'crosshair' : tool === 'text' ? 'text' : 'default',
                touchAction: 'none',
                pointerEvents: tool === 'select' ? 'none' : 'auto',
              }}
              onMouseDown={handlePenDown}
              onMouseMove={handlePenMove}
              onMouseUp={handlePenUp}
              onMouseLeave={handlePenUp}
              onTouchStart={handlePenDown}
              onTouchMove={handlePenMove}
              onTouchEnd={handlePenUp}
              onClick={handleOverlayClick}
            />

            {!isLocked &&
              textAnnotationPositions.map((ann, i) => (
                <div
                  key={i}
                  className="absolute text-[10px] font-bold text-[#1B4332] bg-white/70 px-0.5 rounded-sm pointer-events-none"
                  style={{ left: ann.left, top: ann.top - 12 }}
                >
                  {ann.text}
                </div>
              ))}

            {pendingTextAt && (
              <input
                autoFocus
                type="text"
                value={pendingTextValue}
                onChange={(e) => setPendingTextValue(e.target.value)}
                onBlur={commitPendingText}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') commitPendingText();
                  if (e.key === 'Escape') setPendingTextAt(null);
                }}
                placeholder="Type a note…"
                className="absolute z-10 bg-white border-2 border-teal-500 rounded-md text-[11px] font-bold text-[#1B4332] px-1.5 py-0.5 outline-none shadow-lg"
                style={{ left: pendingTextAt.x, top: pendingTextAt.y - 10, minWidth: 90 }}
              />
            )}

            {/* Locked-mode read-only text annotations (baked strokes/checkboxes
                are already part of the raster; free-text notes render as a
                simple label overlay so they stay legible over the page). */}
            {isLocked &&
              textAnnotationPositions.map((ann, i) => (
                <div
                  key={i}
                  className="absolute text-[10px] font-bold text-[#1B4332] bg-white/70 px-0.5 rounded-sm pointer-events-none"
                  style={{ left: ann.left, top: ann.top - 12 }}
                >
                  {ann.text}
                </div>
              ))}
          </div>
        )}

        {!loading && !error && !isLocked && (
          <p className="text-[11px] text-stone-400 font-medium max-w-2xl text-center">
            <strong>Save (Editable)</strong> keeps this document as an in-progress draft that any authorized role can reopen and
            continue. <strong>Save &amp; Lock</strong> finalizes the values into the PDF itself and reopens it read-only from
            then on.
          </p>
        )}
      </div>
    </div>
  );
};

// A compact, inline freehand signature capture used for /Sig fields — same
// draw mechanics as SignaturePad.tsx, sized to fit inside the field's own
// widget rect instead of a fixed panel.
const MiniSignatureCapture: React.FC<{ onSave: (dataUrl: string) => void }> = ({ onSave }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const drawingRef = useRef(false);
  const lastRef = useRef<{ x: number; y: number } | null>(null);
  const [hasStroke, setHasStroke] = useState(false);

  const getPoint = (e: React.MouseEvent | React.TouchEvent) => {
    const canvas = canvasRef.current;
    if (!canvas) return null;
    const rect = canvas.getBoundingClientRect();
    const clientX = 'touches' in e ? e.touches[0]?.clientX : (e as React.MouseEvent).clientX;
    const clientY = 'touches' in e ? e.touches[0]?.clientY : (e as React.MouseEvent).clientY;
    if (clientX === undefined || clientY === undefined) return null;
    return { x: (clientX - rect.left) * (canvas.width / rect.width), y: (clientY - rect.top) * (canvas.height / rect.height) };
  };

  return (
    <div className="w-full h-full relative">
      <canvas
        ref={canvasRef}
        className="w-full h-full cursor-crosshair touch-none"
        onMouseDown={(e) => {
          e.stopPropagation();
          const pt = getPoint(e);
          if (!pt) return;
          drawingRef.current = true;
          lastRef.current = pt;
        }}
        onMouseMove={(e) => {
          e.stopPropagation();
          if (!drawingRef.current) return;
          const canvas = canvasRef.current;
          const ctx = canvas?.getContext('2d');
          const pt = getPoint(e);
          if (!ctx || !pt || !lastRef.current) return;
          ctx.strokeStyle = '#1B4332';
          ctx.lineWidth = 1.6;
          ctx.lineCap = 'round';
          ctx.beginPath();
          ctx.moveTo(lastRef.current.x, lastRef.current.y);
          ctx.lineTo(pt.x, pt.y);
          ctx.stroke();
          lastRef.current = pt;
          setHasStroke(true);
        }}
        onMouseUp={(e) => {
          e.stopPropagation();
          drawingRef.current = false;
          if (hasStroke && canvasRef.current) onSave(canvasRef.current.toDataURL('image/png'));
        }}
        onMouseLeave={() => {
          drawingRef.current = false;
        }}
      />
    </div>
  );
};
