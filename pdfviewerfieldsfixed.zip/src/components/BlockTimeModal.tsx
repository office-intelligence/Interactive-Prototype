import React, { useState } from 'react';
import { 
  Lock, 
  X, 
  Clock, 
  Calendar, 
  Check, 
  Building2, 
  UserCheck, 
  ShieldAlert, 
  Sparkles,
  Layers,
  CheckSquare,
  Square
} from 'lucide-react';
import { AppointmentItem } from './ScheduleFullView';

interface DayOption {
  dayIndex: number;
  dayName: string;
  shortName: string;
  dateStr: string;
  fullDateStr: string;
  isHoliday?: boolean;
  holidayName?: string | null;
}

interface BlockTimeModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSaveBlocks: (blocks: AppointmentItem[]) => void;
  daysOfWeek: {
    label: string;
    dayName: string;
    date: string;
    fullDateStr: string;
    dateObj: Date;
    isHoliday?: boolean;
    holidayName?: string | null;
  }[];
  rooms?: string[];
  initialDayIndex?: number;
  initialRoom?: string;
  initialStartHour?: number;
}

const PROVIDER_OPTIONS = [
  'Dr. Alistair Sterling, MD',
  'Dr. Evelyn Vance, MD',
  'Dr. Julian Mercer, MD',
  'Dr. Raymond Cruz, MD (Anesthesia Block)',
  'Facility Operations / Deep Sterilization Turnover',
  'Practice Holiday & Admin Block',
  'Staff Training & Equipment Calibration',
  'Custom Provider / Hold',
];

const TIME_OPTIONS = [
  { label: '06:00 AM', hour: 6 },
  { label: '06:30 AM', hour: 6.5 },
  { label: '07:00 AM', hour: 7 },
  { label: '07:30 AM', hour: 7.5 },
  { label: '08:00 AM', hour: 8 },
  { label: '08:30 AM', hour: 8.5 },
  { label: '09:00 AM', hour: 9 },
  { label: '09:30 AM', hour: 9.5 },
  { label: '10:00 AM', hour: 10 },
  { label: '10:30 AM', hour: 10.5 },
  { label: '11:00 AM', hour: 11 },
  { label: '11:30 AM', hour: 11.5 },
  { label: '12:00 PM (Noon)', hour: 12 },
  { label: '12:30 PM', hour: 12.5 },
  { label: '01:00 PM', hour: 13 },
  { label: '01:30 PM', hour: 13.5 },
  { label: '02:00 PM', hour: 14 },
  { label: '02:30 PM', hour: 14.5 },
  { label: '03:00 PM', hour: 15 },
  { label: '03:30 PM', hour: 15.5 },
  { label: '04:00 PM', hour: 16 },
  { label: '04:30 PM', hour: 16.5 },
  { label: '05:00 PM', hour: 17 },
  { label: '05:30 PM', hour: 17.5 },
  { label: '06:00 PM', hour: 18 },
  { label: '07:00 PM', hour: 19 },
  { label: '08:00 PM', hour: 20 },
  { label: '09:00 PM', hour: 21 },
  { label: '10:00 PM', hour: 22 },
];

const COLOR_THEMES = [
  { id: 'navy', label: 'Navy Blue (Provider)', bg: 'bg-emerald-900 text-white border-emerald-950', dot: 'bg-emerald-900' },
  { id: 'slate', label: 'Dark Slate (Reserved)', bg: 'bg-slate-800 text-white border-slate-900', dot: 'bg-slate-800' },
  { id: 'amber', label: 'Amber (Turnover / Maint)', bg: 'bg-amber-600 text-white border-amber-700', dot: 'bg-amber-600' },
  { id: 'purple', label: 'Purple (VIP / Special)', bg: 'bg-purple-800 text-white border-purple-900', dot: 'bg-purple-800' },
  { id: 'rose', label: 'Rose / Coral (Restricted)', bg: 'bg-rose-700 text-white border-rose-800', dot: 'bg-rose-700' },
  { id: 'emerald', label: 'Emerald (Block Hold)', bg: 'bg-emerald-800 text-white border-emerald-900', dot: 'bg-emerald-800' },
];

export const BlockTimeModal: React.FC<BlockTimeModalProps> = ({
  isOpen,
  onClose,
  onSaveBlocks,
  daysOfWeek,
  rooms = ['OR#1', 'OR#2', 'OR#3'],
  initialDayIndex = 0,
  initialRoom = 'OR#1',
  initialStartHour = 7,
}) => {
  const [selectedProvider, setSelectedProvider] = useState<string>('Dr. Alistair Sterling, MD');
  const [customProviderName, setCustomProviderName] = useState<string>('');
  const [selectedRoom, setSelectedRoom] = useState<string>(initialRoom || 'OR#1'); // 'OR#1' | 'OR#2' | 'OR#3' | 'ALL'
  const [startHour, setStartHour] = useState<number>(initialStartHour || 7);
  const [endHour, setEndHour] = useState<number>(Math.min((initialStartHour || 7) + 4.5, 21));
  const [blockTitle, setBlockTitle] = useState<string>('Time slot blocked for:');
  const [blockReason, setBlockReason] = useState<string>('OR Block Reservation — Provider Assigned');
  const [notes, setNotes] = useState<string>('Reserved surgical block time. Circulating nurse notified.');
  const [selectedColor, setSelectedColor] = useState<string>(COLOR_THEMES[0].bg);
  
  // Selected Days of Week state (0 to 6)
  const [selectedDays, setSelectedDays] = useState<boolean[]>(() => {
    const initial = [false, false, false, false, false, false, false];
    if (initialDayIndex >= 0 && initialDayIndex < 7) {
      initial[initialDayIndex] = true;
    } else {
      // Default to Monday-Friday
      initial[0] = true;
      initial[1] = true;
      initial[2] = true;
      initial[3] = true;
      initial[4] = true;
    }
    return initial;
  });

  if (!isOpen) return null;

  const durationHours = Math.max(endHour - startHour, 0.5);

  const toggleDay = (idx: number) => {
    setSelectedDays(prev => {
      const next = [...prev];
      next[idx] = !next[idx];
      return next;
    });
  };

  const handleSelectAllWeekdays = () => {
    setSelectedDays([true, true, true, true, true, false, false]);
  };

  const handleSelectAllDays = () => {
    setSelectedDays([true, true, true, true, true, true, true]);
  };

  const handleClearAllDays = () => {
    setSelectedDays([false, false, false, false, false, false, false]);
  };

  const formatHourLabel = (hourVal: number) => {
    const h = Math.floor(hourVal);
    const m = Math.round((hourVal - h) * 60);
    const mStr = m < 10 ? `0${m}` : `${m}`;
    const period = h >= 12 ? 'PM' : 'AM';
    const displayH = h % 12 === 0 ? 12 : h % 12;
    const hStr = displayH < 10 ? `0${displayH}` : `${displayH}`;
    return `${hStr}:${mStr} ${period}`;
  };

  const finalProvider = selectedProvider === 'Custom Provider / Hold' 
    ? (customProviderName.trim() || 'Reserved Block') 
    : selectedProvider;

  const targetRooms = selectedRoom === 'ALL' ? rooms : [selectedRoom];
  const selectedDayCount = selectedDays.filter(Boolean).length;
  const totalBlocksGenerated = selectedDayCount * targetRooms.length;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (selectedDayCount === 0) {
      alert('Please check at least one day of the week to apply the block.');
      return;
    }
    if (endHour <= startHour) {
      alert('End time must be later than start time.');
      return;
    }

    const newBlocks: AppointmentItem[] = [];

    selectedDays.forEach((isChecked, dIdx) => {
      if (!isChecked) return;
      const dayData = daysOfWeek[dIdx];
      const dosFormatted = dayData?.date || '07/13/2026';

      targetRooms.forEach(roomName => {
        const uniqueId = `BLOCK-${Date.now().toString().slice(-4)}-${dIdx}-${roomName.replace('#', '')}`;
        
        newBlocks.push({
          id: uniqueId,
          dayIndex: dIdx,
          room: roomName,
          startHour: startHour,
          durationHours: durationHours,
          title: blockTitle || 'Time slot blocked for:',
          surgeon: finalProvider,
          details: `[Aura Vanguard Pavilion] ${blockReason}`,
          bgColor: selectedColor,
          isBlock: true,
          dos: dosFormatted,
          startTime: formatHourLabel(startHour),
          length: `${durationHours} Hours`,
          patientName: finalProvider.includes('Dr.') ? `OR Block: ${finalProvider}` : finalProvider,
          dob: 'N/A',
          age: 'N/A',
          phone: 'N/A',
          procedure: blockReason,
          anesthesiologist: 'Raymond Cruz, MD',
          anesthesiaType: 'Block Reservation',
          paymentType: 'Facility Block',
          notes: notes || `Blocked time slot reserved for ${finalProvider} in ${roomName}.`
        });
      });
    });

    onSaveBlocks(newBlocks);
    onClose();
  };

  const dayNames = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
  const shortDays = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

  return (
    <div className="fixed inset-0 z-[99999] bg-stone-950/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 animate-in fade-in duration-200">
      <div className="bg-white rounded-2xl shadow-2xl border border-stone-300 w-full max-w-2xl max-h-[92vh] flex flex-col overflow-hidden animate-in zoom-in-95 duration-150">
        
        {/* Header */}
        <div className="px-5 py-3.5 bg-slate-900 text-white flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-xl bg-emerald-700 text-white flex items-center justify-center shadow-xs">
              <Lock className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm sm:text-base font-bold text-white flex items-center gap-2">
                <span>Block Operating Room Time</span>
                <span className="text-[10px] font-semibold bg-emerald-950 text-emerald-300 px-2 py-0.5 rounded-full border border-emerald-800">
                  Recurring / Single Block
                </span>
              </h2>
              <p className="text-[11px] text-slate-300">
                Reserve surgeon block time, turnover buffers, or maintenance holds across rooms and days.
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body Form */}
        <form onSubmit={handleSubmit} className="p-5 space-y-4 overflow-y-auto flex-1 text-xs text-stone-800">
          
          {/* Section 1: Provider Selection */}
          <div className="bg-stone-50 p-3.5 rounded-xl border border-stone-200/90 space-y-2.5">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-stone-900 flex items-center gap-1.5 uppercase tracking-wide">
                <UserCheck className="w-3.5 h-3.5 text-emerald-700" />
                <span>Provider / Assignee</span>
              </label>
              <span className="text-[10px] text-stone-500 font-medium">Select provider for blocked slot</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <select
                  value={selectedProvider}
                  onChange={(e) => setSelectedProvider(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-stone-300 rounded-lg text-xs font-bold text-stone-900 focus:outline-hidden focus:ring-2 focus:ring-emerald-600 shadow-2xs cursor-pointer"
                >
                  {PROVIDER_OPTIONS.map((prov) => (
                    <option key={prov} value={prov}>
                      {prov}
                    </option>
                  ))}
                </select>
              </div>

              {selectedProvider === 'Custom Provider / Hold' ? (
                <div>
                  <input
                    type="text"
                    value={customProviderName}
                    onChange={(e) => setCustomProviderName(e.target.value)}
                    placeholder="Enter custom provider or team name..."
                    className="w-full px-3 py-2 bg-white border border-stone-300 rounded-lg text-xs font-semibold text-stone-900 focus:outline-hidden focus:ring-2 focus:ring-emerald-600 shadow-2xs"
                    autoFocus
                  />
                </div>
              ) : (
                <div className="flex items-center text-[11px] text-stone-600 bg-white px-3 py-2 rounded-lg border border-stone-200">
                  <span className="font-semibold text-stone-500 mr-1.5">Assigned to:</span>
                  <strong className="text-stone-900 truncate">{selectedProvider}</strong>
                </div>
              )}
            </div>
          </div>

          {/* Section 2: Operating Room & Time Window */}
          <div className="bg-stone-50 p-3.5 rounded-xl border border-stone-200/90 space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-stone-900 flex items-center gap-1.5 uppercase tracking-wide">
                <Clock className="w-3.5 h-3.5 text-emerald-700" />
                <span>Operating Room & Time Window</span>
              </label>
              <span className="text-[11px] font-bold text-emerald-900 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200">
                Duration: {durationHours} Hours ({Math.round(durationHours * 60)} mins)
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {/* Operating Room */}
              <div>
                <label className="block text-[10.5px] font-bold text-stone-600 uppercase mb-1">
                  Operating Room (OR)
                </label>
                <select
                  value={selectedRoom}
                  onChange={(e) => setSelectedRoom(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-stone-300 rounded-lg text-xs font-bold text-stone-900 focus:outline-hidden focus:ring-2 focus:ring-emerald-600 shadow-2xs cursor-pointer"
                >
                  <option value="OR#1">OR#1 (Main Suite)</option>
                  <option value="OR#2">OR#2 (Aesthetic Suite)</option>
                  <option value="OR#3">OR#3 (Laser & Plastics)</option>
                  <option value="ALL">All Suites (OR#1, OR#2, OR#3)</option>
                </select>
              </div>

              {/* Start Time */}
              <div>
                <label className="block text-[10.5px] font-bold text-stone-600 uppercase mb-1">
                  Start Time
                </label>
                <select
                  value={startHour}
                  onChange={(e) => {
                    const newStart = parseFloat(e.target.value);
                    setStartHour(newStart);
                    if (endHour <= newStart) {
                      setEndHour(Math.min(newStart + 2, 22));
                    }
                  }}
                  className="w-full px-3 py-2 bg-white border border-stone-300 rounded-lg text-xs font-semibold text-stone-900 focus:outline-hidden focus:ring-2 focus:ring-emerald-600 shadow-2xs cursor-pointer"
                >
                  {TIME_OPTIONS.filter(t => t.hour < 22).map((t) => (
                    <option key={t.hour} value={t.hour}>
                      {t.label}
                    </option>
                  ))}
                </select>
              </div>

              {/* End Time */}
              <div>
                <label className="block text-[10.5px] font-bold text-stone-600 uppercase mb-1">
                  End Time
                </label>
                <select
                  value={endHour}
                  onChange={(e) => setEndHour(parseFloat(e.target.value))}
                  className="w-full px-3 py-2 bg-white border border-stone-300 rounded-lg text-xs font-semibold text-stone-900 focus:outline-hidden focus:ring-2 focus:ring-emerald-600 shadow-2xs cursor-pointer"
                >
                  {TIME_OPTIONS.filter(t => t.hour > startHour).map((t) => (
                    <option key={t.hour} value={t.hour}>
                      {t.label}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </div>

          {/* Section 3: Days of the Week Checkmarks (EXPLICIT USER REQUIREMENT) */}
          <div className="bg-stone-50 p-3.5 rounded-xl border border-stone-200/90 space-y-2.5">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <label className="text-xs font-bold text-stone-900 flex items-center gap-1.5 uppercase tracking-wide">
                <Calendar className="w-3.5 h-3.5 text-emerald-700" />
                <span>Select Days of the Week to Block</span>
              </label>

              {/* Quick action buttons */}
              <div className="flex items-center gap-1">
                <button
                  type="button"
                  onClick={handleSelectAllWeekdays}
                  className="px-2 py-0.5 bg-white hover:bg-stone-100 text-stone-700 text-[10.5px] font-bold rounded border border-stone-300 shadow-2xs cursor-pointer"
                >
                  Mon-Fri
                </button>
                <button
                  type="button"
                  onClick={handleSelectAllDays}
                  className="px-2 py-0.5 bg-white hover:bg-stone-100 text-stone-700 text-[10.5px] font-bold rounded border border-stone-300 shadow-2xs cursor-pointer"
                >
                  All 7 Days
                </button>
                <button
                  type="button"
                  onClick={handleClearAllDays}
                  className="px-2 py-0.5 bg-white hover:bg-stone-100 text-stone-500 text-[10.5px] font-medium rounded border border-stone-300 cursor-pointer"
                >
                  Clear
                </button>
              </div>
            </div>

            {/* Interactive Day Cards with Checkmarks */}
            <div className="grid grid-cols-2 sm:grid-cols-7 gap-2 pt-1">
              {daysOfWeek.map((day, idx) => {
                const isChecked = selectedDays[idx];
                const isHoliday = day.isHoliday;

                return (
                  <button
                    key={day.dayName}
                    type="button"
                    onClick={() => toggleDay(idx)}
                    className={`p-2 rounded-xl text-center border transition-all cursor-pointer flex flex-col items-center justify-between min-h-[72px] relative ${
                      isChecked
                        ? 'bg-emerald-900 text-white border-emerald-950 shadow-xs ring-2 ring-emerald-500'
                        : isHoliday
                        ? 'bg-slate-200/80 hover:bg-slate-300/80 text-slate-700 border-slate-300'
                        : 'bg-white hover:bg-stone-100 text-stone-800 border-stone-300'
                    }`}
                  >
                    <div className="w-full flex items-center justify-between">
                      <span className={`text-[10px] font-bold uppercase tracking-wider ${isChecked ? 'text-emerald-200' : 'text-stone-500'}`}>
                        {shortDays[idx]}
                      </span>
                      <div className={`w-4 h-4 rounded flex items-center justify-center transition-colors ${
                        isChecked ? 'bg-emerald-500 text-white' : 'border border-stone-400 bg-white'
                      }`}>
                        {isChecked && <Check className="w-3 h-3 stroke-[3]" />}
                      </div>
                    </div>

                    <div className="my-0.5">
                      <span className={`text-sm font-black ${isChecked ? 'text-white' : 'text-stone-900'}`}>
                        {day.dayName.slice(0, 3)}
                      </span>
                      <div className={`text-[9.5px] font-medium ${isChecked ? 'text-emerald-200' : 'text-stone-500'}`}>
                        {day.date.slice(0, 5)}
                      </div>
                    </div>

                    {isHoliday && (
                      <span className={`text-[8px] px-1 py-0.2 rounded font-bold truncate max-w-[90%] ${
                        isChecked ? 'bg-emerald-950 text-amber-300' : 'bg-slate-300 text-slate-800'
                      }`} title={day.holidayName || 'Federal Holiday'}>
                        🇺🇸 Holiday
                      </span>
                    )}
                  </button>
                );
              })}
            </div>

            <div className="text-[11px] text-stone-500 flex items-center justify-between pt-1">
              <span>Selected: <strong className="text-stone-800 font-bold">{selectedDayCount} day(s)</strong></span>
              <span>Total blocks to generate: <strong className="text-emerald-900 font-bold">{totalBlocksGenerated} block(s)</strong></span>
            </div>
          </div>

          {/* Section 4: Block Details & Color */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-[10.5px] font-bold text-stone-600 uppercase mb-1">
                Block Title Header
              </label>
              <input
                type="text"
                value={blockTitle}
                onChange={(e) => setBlockTitle(e.target.value)}
                className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-lg text-xs font-semibold text-stone-900 focus:outline-hidden focus:ring-2 focus:ring-emerald-600 shadow-2xs"
                placeholder="e.g. Time slot blocked for:"
              />
            </div>

            <div>
              <label className="block text-[10.5px] font-bold text-stone-600 uppercase mb-1">
                Visual Badge Style
              </label>
              <div className="flex items-center gap-1.5 flex-wrap pt-0.5">
                {COLOR_THEMES.map((theme) => (
                  <button
                    key={theme.id}
                    type="button"
                    onClick={() => setSelectedColor(theme.bg)}
                    className={`px-2 py-1 rounded-md text-[10.5px] font-bold border transition-all cursor-pointer flex items-center gap-1.5 ${
                      selectedColor === theme.bg
                        ? 'ring-2 ring-emerald-600 ring-offset-1 shadow-2xs font-black'
                        : 'opacity-70 hover:opacity-100'
                    } ${theme.bg}`}
                  >
                    <span className="w-2 h-2 rounded-full bg-white"></span>
                    <span>{theme.label.split(' ')[0]}</span>
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Section 5: Notes */}
          <div>
            <label className="block text-[10.5px] font-bold text-stone-600 uppercase mb-1">
              Reservation Notes / Circulating Nurse Directive
            </label>
            <input
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="e.g. Reserved for Dr. Sterling's revision cases or deep equipment sterilization..."
              className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-lg text-xs text-stone-900 focus:outline-hidden focus:ring-2 focus:ring-emerald-600 shadow-2xs"
            />
          </div>

          {/* Footer Actions */}
          <div className="pt-3 border-t border-stone-200 flex items-center justify-between gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 font-bold text-xs rounded-xl border border-stone-300 transition-colors cursor-pointer"
            >
              Cancel
            </button>

            <button
              type="submit"
              disabled={selectedDayCount === 0}
              className="px-5 py-2.5 bg-emerald-800 hover:bg-emerald-900 disabled:opacity-50 text-white font-bold text-xs rounded-xl shadow-md transition-all flex items-center gap-2 cursor-pointer font-sans"
            >
              <Lock className="w-4 h-4 text-emerald-200" />
              <span>
                Block Time ({totalBlocksGenerated} {totalBlocksGenerated === 1 ? 'Slot' : 'Slots'})
              </span>
            </button>
          </div>

        </form>

      </div>
    </div>
  );
};
