import React, { useState } from 'react';
import { 
  PatientCase, 
  PatientStage, 
  ReadinessLevel 
} from '../types';
import { 
  Clock, 
  Sparkles, 
  AlertTriangle, 
  CheckCircle2, 
  ChevronRight, 
  UserCheck, 
  Filter, 
  Layers, 
  Phone, 
  FileSpreadsheet, 
  Activity, 
  Zap, 
  ArrowUpRight, 
  ArrowRight,
  Check, 
  AlertCircle,
  Building2,
  CalendarDays
} from 'lucide-react';

export type ScheduleViewMode = 'PRIORITY' | 'ROOM_FLOW' | 'BOTTLENECKS' | 'PIPELINE';

interface ScheduleIntelligenceBoxProps {
  cases: PatientCase[];
  onSelectPatient: (patient: PatientCase) => void;
  onUpdateStage: (caseId: string, newStage: PatientStage) => void;
  onResolveAction: (caseId: string, actionId: string) => void;
  onTriggerEKGFastTrack: (caseId: string) => void;
  viewMode?: ScheduleViewMode;
  onViewModeChange?: (mode: ScheduleViewMode) => void;
  onOpenCheckIn?: (patient: PatientCase) => void;
}

export const ScheduleIntelligenceBox: React.FC<ScheduleIntelligenceBoxProps> = ({
  cases,
  onSelectPatient,
  onUpdateStage,
  onResolveAction,
  onTriggerEKGFastTrack,
  viewMode: externalViewMode,
  onViewModeChange,
  onOpenCheckIn,
}) => {
  const [internalViewMode, setInternalViewMode] = useState<ScheduleViewMode>('PRIORITY');
  const viewMode = externalViewMode !== undefined ? externalViewMode : internalViewMode;
  const setViewMode = onViewModeChange || setInternalViewMode;

  const [roomFilter, setRoomFilter] = useState<string>('ALL');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');

  // Cards collapse to one line by default; Needs Attention cases auto-expand.
  // This set holds ids the user has manually clicked away from that default.
  const [manuallyToggledIds, setManuallyToggledIds] = useState<Set<string>>(new Set());
  const toggleCardExpanded = (patientId: string) => {
    setManuallyToggledIds((prev) => {
      const next = new Set(prev);
      if (next.has(patientId)) next.delete(patientId);
      else next.add(patientId);
      return next;
    });
  };

  // Filter cases
  const filteredCases = cases.filter((c) => {
    if (roomFilter !== 'ALL' && c.room !== roomFilter) return false;
    if (statusFilter === 'NEEDS_ATTENTION' && c.readinessLevel === 'CLEARED') return false;
    if (statusFilter === 'CLEARED' && c.readinessLevel !== 'CLEARED') return false;
    return true;
  });

  // Sort cases for AI Arrival Priority Mode
  const prioritySortedCases = [...filteredCases].sort((a, b) => {
    // Put Needs Attention / Low Readiness score first
    if (a.readinessLevel === 'NEEDS_ATTENTION' && b.readinessLevel !== 'NEEDS_ATTENTION') return -1;
    if (b.readinessLevel === 'NEEDS_ATTENTION' && a.readinessLevel !== 'NEEDS_ATTENTION') return 1;
    return a.readinessScore - b.readinessScore;
  });

  const getReadinessBadge = (score: number, level: ReadinessLevel) => {
    if (level === 'NEEDS_ATTENTION' || score < 80) {
      return (
        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-amber-100/90 text-amber-900 border border-amber-300 text-[11px] font-bold shadow-2xs">
          <AlertTriangle className="w-3 h-3 text-amber-700" />
          <span>Needs Attention ({score})</span>
        </span>
      );
    }
    return (
      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-emerald-50 text-emerald-800 border border-emerald-200 text-[11px] font-bold shadow-2xs">
        <CheckCircle2 className="w-3 h-3 text-emerald-600" />
        <span>Ready ({score})</span>
      </span>
    );
  };

  // Check-in status badge — reflects where the patient is in the pre-arrival
  // (patient portal) and day-of-surgery (front desk) check-in workflow.
  // Clicking it opens the office check-in review for that patient.
  const getCheckInBadge = (patient: PatientCase) => {
    const status = patient.checkInStatus || 'NOT_STARTED';
    const config: Record<NonNullable<PatientCase['checkInStatus']>, { label: string; className: string }> = {
      NOT_STARTED: { label: 'Check-In: Not Started', className: 'bg-stone-100 text-stone-600 border-stone-200' },
      PORTAL_IN_PROGRESS: { label: 'Check-In: In Progress', className: 'bg-amber-100 text-amber-800 border-amber-300' },
      PORTAL_COMPLETE: { label: 'Check-In: Portal Complete', className: 'bg-sky-100 text-sky-800 border-sky-300' },
      OFFICE_VERIFIED: { label: 'Check-In: Verified', className: 'bg-emerald-100 text-emerald-800 border-emerald-300' },
    };
    const { label, className } = config[status];
    return (
      <button
        type="button"
        onClick={(e) => { e.stopPropagation(); onOpenCheckIn?.(patient); }}
        title="Open Office Check-In Review"
        className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10.5px] font-bold border shadow-2xs transition-colors cursor-pointer hover:brightness-95 ${className}`}
      >
        <UserCheck className="w-3 h-3" />
        <span>{label}</span>
      </button>
    );
  };

  const getStagePill = (stage: PatientStage) => {
    switch (stage) {
      case 'CHECK_IN':
        return (
          <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-amber-100 text-amber-800 border border-amber-200">
            Arrived
          </span>
        );
      case 'PRE_OP':
        return (
          <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-indigo-50 text-indigo-700 border border-indigo-200">
            Pre-Op
          </span>
        );
      case 'IN_OR':
        return (
          <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-sky-100 text-sky-800 border border-sky-200 animate-pulse">
            In OR
          </span>
        );
      case 'PACU_RECOVERY':
        return (
          <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-purple-100 text-purple-800 border border-purple-200">
            PACU
          </span>
        );
      case 'DISCHARGED':
        return (
          <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-slate-100 text-slate-700 border border-slate-200">
            Discharged
          </span>
        );
      default:
        return (
          <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-slate-100 text-slate-600">
            En Route
          </span>
        );
    }
  };

  return (
    <div className="bg-white rounded-xl border border-stone-200/90 shadow-2xs overflow-hidden">
      
      {/* Box Header Controls */}
      <div className="p-3 px-4 border-b border-stone-200/80 bg-stone-50/70 flex items-center justify-between gap-3">
        {/* Title */}
        <div className="flex items-center gap-2.5">
          <div className="w-7 h-7 rounded-lg bg-amber-100 border border-amber-200 text-amber-800 flex items-center justify-center font-bold">
            <Zap className="w-4 h-4" />
          </div>
          <div>
            <h2 className="text-sm font-bold text-stone-900 tracking-tight flex items-center gap-2">
              <span>Today's Patients</span>
              <span className="text-[11px] font-semibold px-1.5 py-0.2 rounded-md bg-stone-200 text-stone-700">
                {cases.length} {cases.length === 1 ? 'Case' : 'Cases'}
              </span>
            </h2>
          </div>
        </div>

        {/* Status Filter buttons */}
        <div className="flex items-center gap-1.5 text-xs">
          <button
            onClick={() => setStatusFilter('ALL')}
            className={`px-2 py-1 rounded-md font-semibold text-[11px] transition-colors cursor-pointer ${
              statusFilter === 'ALL'
                ? 'bg-emerald-700 text-white'
                : 'bg-white text-stone-600 border border-stone-200 hover:bg-stone-100'
            }`}
          >
            All ({cases.length})
          </button>
          <button
            onClick={() => setStatusFilter('NEEDS_ATTENTION')}
            className={`px-2 py-1 rounded-md font-bold text-[11px] transition-colors cursor-pointer ${
              statusFilter === 'NEEDS_ATTENTION'
                ? 'bg-amber-600 text-white'
                : 'bg-amber-50 text-amber-800 border border-amber-200 hover:bg-amber-100'
            }`}
          >
            Needs Attention (1)
          </button>
        </div>
      </div>

      {/* Patient List Content Area */}
      <div className="p-3 sm:p-4 space-y-2.5">
        
        {/* VIEW 1: AI PRIORITY QUEUE (DEFAULT) — collapsed to one line per patient;
            only cases Nightingale flagged as Needs Attention auto-expand. Click
            any row to expand/collapse the rest. */}
        {viewMode === 'PRIORITY' && (
          <div className="space-y-2.5">
            {prioritySortedCases.map((patient) => {
              const isNeedsAttention = patient.readinessLevel === 'NEEDS_ATTENTION';
              const hasAllergy = !patient.allergies.some(a => a.toLowerCase().includes('none') || a.toLowerCase().includes('nkda'));
              // Needs-attention cases auto-expand; everything else starts collapsed
              // to one line. Clicking a row toggles it away from that default.
              const expanded = manuallyToggledIds.has(patient.id) ? !isNeedsAttention : isNeedsAttention;

              return (
                <div
                  key={patient.id}
                  onClick={() => toggleCardExpanded(patient.id)}
                  className={`rounded-xl p-3 sm:p-3.5 transition-all border cursor-pointer ${
                    isNeedsAttention
                      ? 'bg-amber-50/50 border-amber-300 shadow-2xs ring-1 ring-amber-300/40'
                      : 'bg-white border-stone-200/90 hover:border-emerald-300 hover:shadow-2xs'
                  }`}
                >
                  {/* Row 1: Time, Room, Patient Name, Demographics, Readiness, and Action */}
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div className="flex items-center gap-2 flex-wrap min-w-0">
                      <span className="text-sm sm:text-base font-black text-stone-900 tracking-tight">
                        {patient.scheduledTime}
                      </span>
                      <span className="px-1.5 py-0.5 rounded bg-emerald-600 text-white text-[10.5px] font-bold">
                        {patient.room}
                      </span>
                      {getStagePill(patient.stage)}
                      {getCheckInBadge(patient)}
                      <span className="text-stone-300 font-light hidden sm:inline">|</span>
                      <button
                        onClick={(e) => { e.stopPropagation(); onSelectPatient(patient); }}
                        className="text-xs sm:text-sm font-bold text-stone-900 hover:text-emerald-700 hover:underline transition-colors text-left truncate cursor-pointer"
                      >
                        {patient.name}
                      </button>
                      <span className="text-[11px] text-stone-500 font-medium">
                        ({patient.age}{patient.gender === 'Female' ? 'F' : patient.gender === 'Male' ? 'M' : ''})
                      </span>
                      <span className="text-[11px] text-stone-400 font-mono">
                        #{patient.patientId}
                      </span>
                      {/* Compact always-visible allergy flag (safety data stays visible even collapsed) */}
                      {hasAllergy && (
                        <span title={`Allergies: ${patient.allergies.join(', ')}`}>
                          <AlertCircle className="w-3.5 h-3.5 text-rose-600 shrink-0" />
                        </span>
                      )}
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      {getReadinessBadge(patient.readinessScore, patient.readinessLevel)}
                      <button
                        onClick={(e) => { e.stopPropagation(); onSelectPatient(patient); }}
                        className="py-1 px-2.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-[11px] font-bold flex items-center gap-1 transition-colors shadow-2xs cursor-pointer"
                      >
                        <span>Chart</span>
                        <ArrowRight className="w-3 h-3" />
                      </button>
                      <ChevronRight className={`w-3.5 h-3.5 text-stone-400 transition-transform ${expanded ? 'rotate-90' : ''}`} />
                    </div>
                  </div>

                  {/* Everything below is hidden unless Nightingale flagged this case or
                      the user expanded it — collapsed rows show only the line above. */}
                  {expanded && (
                  <>
                  {/* Row 2: Procedure & Surgeon & Allergies & Duration */}
                  <div className="flex flex-wrap items-center justify-between gap-2 mt-1.5 pt-1.5 border-t border-stone-100 text-xs">
                    <div className="flex items-center gap-1.5 flex-wrap min-w-0">
                      <span className="font-semibold text-stone-900 truncate">
                        {patient.procedure}
                      </span>
                      <span className="text-stone-400">•</span>
                      <span className="text-stone-600 truncate">
                        Surgeon: <strong className="text-stone-800 font-semibold">{patient.surgeon}</strong>
                      </span>
                      <span className="text-stone-400">•</span>
                      <span className="text-stone-500 text-[11px]">
                        Est: <strong className="text-stone-700">{patient.estimatedDurationMins}m</strong>
                      </span>
                    </div>

                    {/* Allergies Pill (full detail) */}
                    <div className="flex items-center gap-1.5">
                      {hasAllergy ? (
                        <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[10.5px] font-bold bg-rose-100 text-rose-900 border border-rose-200">
                          <AlertCircle className="w-3 h-3 text-rose-600" />
                          <span>Allergies: {patient.allergies.join(', ')}</span>
                        </span>
                      ) : (
                        <span className="text-[11px] text-stone-400">
                          NKDA
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Row 3: AI Summary in plain English — replaces the old CBC/CMP/EKG
                      chip stack, which just repeated what this sentence already says.
                      Ask Nightingale ("show labs") if you need the raw values. */}
                  <div className={`mt-2 p-2 rounded-lg text-xs flex flex-wrap items-center justify-between gap-2 border ${
                    isNeedsAttention
                      ? 'bg-amber-100/70 border-amber-200/90 text-amber-950'
                      : 'bg-stone-50 border-stone-200/70 text-stone-700'
                  }`}>
                    <div className="flex items-start sm:items-center gap-1.5 flex-1 min-w-0">
                      <Sparkles className={`w-3.5 h-3.5 mt-0.5 sm:mt-0 shrink-0 ${isNeedsAttention ? 'text-amber-700' : 'text-emerald-600'}`} />
                      <span className="text-[11.5px] leading-tight truncate">
                        <strong className="font-semibold text-stone-900">AI Note: </strong>
                        {patient.aiSummary}
                      </span>
                    </div>

                    {isNeedsAttention && (
                      <button
                        onClick={(e) => { e.stopPropagation(); onTriggerEKGFastTrack(patient.id); }}
                        className="px-2 py-0.5 rounded bg-amber-600 hover:bg-amber-700 text-white font-bold text-[10.5px] shadow-2xs transition-colors cursor-pointer ml-1 shrink-0"
                      >
                        Fast-Track EKG Call
                      </button>
                    )}
                  </div>

                  {/* Row 4: Detailed Readiness View — the pending pre-op checklist items
                      behind the readiness score, so this expanded row is a genuine
                      "detailed readiness view" rather than a repeat of Row 1's badge. */}
                  {patient.actionItems.length > 0 && (
                    <div className="mt-2 pt-2 border-t border-stone-100 space-y-1">
                      <div className="text-[10px] font-bold uppercase tracking-wider text-stone-400">
                        Readiness Checklist ({patient.actionItems.filter(a => a.done).length}/{patient.actionItems.length} complete)
                      </div>
                      {patient.actionItems.map((item) => (
                        <div key={item.id} className="flex items-center gap-1.5 text-[11.5px]">
                          {item.done ? (
                            <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                          ) : (
                            <AlertCircle className={`w-3.5 h-3.5 shrink-0 ${item.urgent ? 'text-rose-600' : 'text-amber-600'}`} />
                          )}
                          <span className={item.done ? 'text-stone-400 line-through' : 'text-stone-700 font-medium'}>
                            {item.text}
                          </span>
                          {item.urgent && !item.done && (
                            <span className="px-1.5 py-0.2 rounded-full bg-rose-100 text-rose-800 text-[9.5px] font-bold shrink-0">Urgent</span>
                          )}
                        </div>
                      ))}
                    </div>
                  )}
                  </>
                  )}

                </div>
              );
            })}
          </div>
        )}

        {/* VIEW 2: OR ROOM FLOW GRID */}
        {viewMode === 'ROOM_FLOW' && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {['OR 1', 'OR 2'].map((roomName) => {
              const roomCases = cases.filter((c) => c.room === roomName);
              return (
                <div key={roomName} className="bg-slate-50/80 rounded-2xl border border-slate-200 p-4 space-y-3">
                  <div className="flex items-center justify-between border-b border-slate-200/80 pb-2">
                    <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                      <Building2 className="w-4 h-4 text-indigo-600" />
                      <span>{roomName} Schedule</span>
                    </h3>
                    <span className="text-xs font-semibold text-slate-500">
                      {roomCases.length} Cases Scheduled
                    </span>
                  </div>

                  <div className="space-y-3">
                    {roomCases.map((patient) => (
                      <div key={patient.id} className="bg-white rounded-xl p-3.5 border border-slate-200/80 shadow-2xs space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-bold text-slate-900">{patient.scheduledTime}</span>
                          {getReadinessBadge(patient.readinessScore, patient.readinessLevel)}
                        </div>
                        <div className="text-xs font-bold text-slate-800">{patient.name}</div>
                        <div className="text-[11px] text-slate-500 line-clamp-1">{patient.procedure}</div>
                        <div className="flex items-center justify-between text-[11px] text-slate-400 pt-1 border-t border-slate-100">
                          <span>Surgeon: {patient.surgeon}</span>
                          <button
                            onClick={() => onSelectPatient(patient)}
                            className="text-indigo-600 font-semibold hover:underline"
                          >
                            View Details
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* VIEW 3: BOTTLENECKS ONLY VIEW */}
        {viewMode === 'BOTTLENECKS' && (
          <div className="space-y-4">
            <div className="p-4 rounded-2xl bg-amber-50 border border-amber-300 space-y-3">
              <div className="flex items-center gap-2 text-amber-900 font-bold text-sm">
                <AlertTriangle className="w-5 h-5 text-amber-600" />
                <span>Urgent ASC Workflow Bottleneck Detected</span>
              </div>
              <p className="text-xs text-amber-800 leading-relaxed">
                Patricia DePoli (8:00 AM - OR 1) is currently missing her pre-op EKG report and facial baseline photos. If not cleared within 20 minutes, OR 1 will experience a 25-minute delay that impacts Dr. Evelyn Vance's afternoon procedures.
              </p>
              <div className="flex flex-wrap gap-2 pt-1">
                <button
                  onClick={() => onTriggerEKGFastTrack('case-2')}
                  className="px-3 py-1.5 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold shadow-xs transition-colors"
                >
                  Trigger Fast-Track Cardiology EKG Call
                </button>
                <button
                  onClick={() => onSelectPatient(cases.find((c) => c.id === 'case-2')!)}
                  className="px-3 py-1.5 rounded-xl bg-white text-amber-900 border border-amber-300 text-xs font-semibold hover:bg-amber-100 transition-colors"
                >
                  Open Patricia DePoli Chart
                </button>
              </div>
            </div>
          </div>
        )}

        {/* VIEW 4: PIPELINE FLOW */}
        {viewMode === 'PIPELINE' && (
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
            {[
              { stage: 'CHECK_IN', title: 'Check-In / Waiting' },
              { stage: 'PRE_OP', title: 'Pre-Op Bays' },
              { stage: 'IN_OR', title: 'Operating Rooms' },
              { stage: 'PACU_RECOVERY', title: 'PACU Recovery' },
            ].map((col) => {
              const stageCases = cases.filter((c) => c.stage === col.stage);
              return (
                <div key={col.stage} className="bg-slate-50 rounded-xl p-3 border border-slate-200/80 space-y-2">
                  <div className="text-xs font-bold text-slate-700 pb-1 border-b border-slate-200 flex justify-between">
                    <span>{col.title}</span>
                    <span className="text-slate-400">{stageCases.length}</span>
                  </div>
                  <div className="space-y-2">
                    {stageCases.map((p) => (
                      <div key={p.id} className="bg-white p-2.5 rounded-lg border border-slate-200 text-xs space-y-1 shadow-2xs">
                        <div className="font-bold text-slate-900">{p.name}</div>
                        <div className="text-[10px] text-slate-500">{p.scheduledTime} • {p.room}</div>
                        <button
                          onClick={() => onSelectPatient(p)}
                          className="text-[10px] text-indigo-600 font-semibold hover:underline block pt-1"
                        >
                          Open Record →
                        </button>
                      </div>
                    ))}
                    {stageCases.length === 0 && (
                      <div className="text-[11px] text-slate-400 italic py-2 text-center">Empty</div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}

      </div>
    </div>
  );
};
