/**
 * Utility for prefilling intake forms with known patient data and previously submitted form values.
 * Allows the patient / clinic staff to only review and update new information or modifications.
 */

export interface PatientInfoPayload {
  id?: string;
  patientId?: string;
  name?: string;
  firstName?: string;
  lastName?: string;
  dob?: string;
  age?: number | string;
  gender?: string;
  sex?: string;
  phone?: string;
  email?: string;
  address?: string;
  emergencyContact?: any;
  emergencyName?: string;
  emergencyPhone?: string;
  emergencyRelation?: string;
  insurance?: any;
  insuranceCompany?: string;
  memberId?: string;
  groupNumber?: string;
  planType?: string;
  doctor?: string;
  surgeon?: string;
  procedure?: string;
  procedureDate?: string;
  surgeryDate?: string;
  date?: string;
  pcp?: string;
  primaryPhysician?: string;
  height?: string;
  weight?: string;
  allergies?: string[] | string;
  medications?: string[] | string;
  preferredPharmacy?: any;
  medicalProfile?: any;
  [key: string]: any;
}

/** `<input type="date">` only renders a value in `YYYY-MM-DD` (ISO) format, but
 * mock/demo patient records store `dob` as `MM/DD/YYYY`. Convert so the date of
 * birth actually shows up pre-filled instead of silently rendering blank. */
function normalizeDobForDateInput(dob?: string): string {
  if (!dob) return '';
  if (/^\d{4}-\d{2}-\d{2}$/.test(dob)) return dob;
  const m = dob.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
  if (m) {
    const [, mm, dd, yyyy] = m;
    return `${yyyy}-${mm.padStart(2, '0')}-${dd.padStart(2, '0')}`;
  }
  return dob;
}

function escapeAttr(value: string): string {
  return String(value).replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;');
}

function escapeHtml(value: string): string {
  return String(value).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

/** Checks/unchecks every `<input type="checkbox" name="groupName" value="...">` in a
 * group based on whether its value is in `selectedValues` — used for the Medical
 * History form's pmh/fh/ros condition checklists. */
function fillCheckboxGroupByValue(html: string, groupName: string, selectedValues: string[]): string {
  const tagRegex = new RegExp(`<input\\b[^>]*?type=["']checkbox["'][^>]*?name=["']${groupName}["'][^>]*?>`, 'gi');
  return html.replace(tagRegex, (tag) => {
    const valMatch = tag.match(/value=["']([^"']*)["']/i);
    const val = valMatch ? valMatch[1] : '';
    const shouldCheck = selectedValues.includes(val);
    let t = tag.replace(/\s+checked(=["'][^"']*["'])?/gi, '');
    if (shouldCheck) t = t.replace(/>$/, ' checked>');
    return t;
  });
}

/** Selects exactly one `<input type="radio" name="groupName" value="...">` in a group,
 * clearing the template's default `checked` on the others. */
function fillRadioGroupByValue(html: string, groupName: string, selectedValue: string): string {
  const tagRegex = new RegExp(`<input\\b[^>]*?type=["']radio["'][^>]*?name=["']${groupName}["'][^>]*?>`, 'gi');
  return html.replace(tagRegex, (tag) => {
    const valMatch = tag.match(/value=["']([^"']*)["']/i);
    const val = valMatch ? valMatch[1] : '';
    let t = tag.replace(/\s+checked(=["'][^"']*["'])?/gi, '');
    if (val === selectedValue) t = t.replace(/>$/, ' checked>');
    return t;
  });
}

/** Flips a `display:none;` inline style on a wrapper div (e.g. the collapsed
 * medications table) to `display:block;` so pre-filled content is visible without
 * requiring the form's own onchange/toggle script to run first. */
function revealHiddenDiv(html: string, id: string): string {
  return html.replace(
    new RegExp(`(<div[^>]*?id=["']${id}["'][^>]*?style=["'])display:\\s*none;?`, 'i'),
    '$1display:block;'
  );
}

/** Sets/clears a checkbox or radio input by its `id` attribute (for standalone
 * inputs not part of a name= group, e.g. the airway-concern checkboxes). */
function setCheckedById(html: string, id: string, checked: boolean): string {
  return html.replace(new RegExp(`(<input[^>]*?id=["']${id}["'][^>]*?)(/?>)`, 'i'), (m, p1, close) => {
    let t = p1.replace(/\s+checked(=["'][^"']*["'])?/gi, '');
    if (checked) t += ' checked';
    return t + close;
  });
}

/** Marks the matching `<option value="value">` inside `<select id="id">` as selected. */
function setSelectValue(html: string, id: string, value: string): string {
  return html.replace(
    new RegExp(`(<select[^>]*?id=["']${id}["'][^>]*?>)([\\s\\S]*?)(</select>)`, 'i'),
    (_m, open, body, close) => {
      let b = String(body).replace(/\s+selected(=["'][^"']*["'])?/gi, '');
      b = b.replace(new RegExp(`(<option[^>]*?value=["']${value}["'][^>]*?)(>)`, 'i'), (_mm, p1) => `${p1} selected>`);
      return open + b + close;
    }
  );
}

/** Fills a text `<input name="name">` with `value`, leaving it untouched if it
 * already has a `value=` (e.g. from a filename-scoped generic replacement earlier)
 * or if `value` is empty/undefined. */
function fillTextValueByName(html: string, name: string, value?: string): string {
  if (!value) return html;
  return html.replace(new RegExp(`(<input[^>]*?name=["']${name}["'][^>]*?)(/?>)`, 'i'), (m, p1, close) => {
    if (p1.includes('value=')) return m;
    return `${p1} value="${escapeAttr(value)}"${close}`;
  });
}

/** Fills a `<textarea id-or-name="key">...</textarea>` with `value`, leaving it
 * untouched if it already has content or `value` is empty/undefined. */
function fillTextareaByAttr(html: string, key: string, value?: string): string {
  if (!value) return html;
  return html.replace(
    new RegExp(`(<textarea[^>]*?(?:id|name)=["']${key}["'][^>]*?>)([\\s\\S]*?)(</textarea>)`, 'i'),
    (m, open, body, close) => (String(body).trim() ? m : `${open}${escapeHtml(value)}${close}`)
  );
}

/**
 * Returns an enriched HTML template with all known patient fields pre-filled at the top and throughout the form.
 */
export function getPrefilledIntakeHtml(
  htmlTemplate: string,
  patient?: PatientInfoPayload | null,
  previousSavedValues?: Record<string, string | boolean>
): string {
  if (!htmlTemplate) return '';

  const ptName =
    patient?.name ||
    (patient?.firstName && patient?.lastName ? `${patient.firstName} ${patient.lastName}` : 'Sarah Wilson');
  
  const ptDob = normalizeDobForDateInput(patient?.dob) || '1988-04-12';
  const ptPhone = patient?.phone || '(310) 555-0192';
  const ptEmail = patient?.email || 'sarah.wilson@example.com';
  const ptAddress = patient?.address || '10484 Wilshire Blvd, Apt 8B, Los Angeles, CA 90024';
  
  const emName =
    patient?.emergencyName ||
    (typeof patient?.emergencyContact === 'string'
      ? patient.emergencyContact.split('-')[0].replace(/\(.*?\)/g, '').trim()
      : patient?.emergencyContact?.name || 'Mark Wilson');

  const emPhone =
    patient?.emergencyPhone ||
    (typeof patient?.emergencyContact === 'string'
      ? (patient.emergencyContact.match(/[\(\d\)\s\-]{10,}/) || ['(310) 555-0199'])[0]
      : patient?.emergencyContact?.phone || '(310) 555-0199');

  const emRelation =
    patient?.emergencyRelation ||
    (patient?.emergencyContact?.relationship || 'Spouse');

  let insCompany = 'Blue Shield of California PPO';
  let insMemberId = 'XEH90218492';
  let insGroup = '882941';
  let insPlan = 'PPO Premier Choice';

  if (patient?.insurance) {
    if (typeof patient.insurance === 'string') {
      insCompany = patient.insurance.split('(')[0].trim() || insCompany;
      const memMatch = patient.insurance.match(/Member ID:?\s*([A-Za-z0-9]+)/i);
      if (memMatch) insMemberId = memMatch[1];
      const grpMatch = patient.insurance.match(/Group:?\s*([A-Za-z0-9]+)/i);
      if (grpMatch) insGroup = grpMatch[1];
    } else if (typeof patient.insurance === 'object') {
      insCompany = patient.insurance.provider || patient.insurance.company || insCompany;
      insMemberId = patient.insurance.policyNumber || patient.insurance.memberId || insMemberId;
      insGroup = patient.insurance.groupNumber || patient.insurance.group || insGroup;
      insPlan = patient.insurance.planName || patient.insurance.planType || insPlan;
    }
  }

  const doctor = patient?.surgeon || patient?.doctor || 'Dr. Alistair Sterling, MD';
  const procedure = patient?.procedure || 'Deep Plane Facelift & Neck Lift + SMAS Plication';
  const procDate = patient?.surgeryDate || patient?.procedureDate || patient?.date || '2026-08-17';
  const pcp =
    patient?.pcp ||
    patient?.primaryPhysician ||
    patient?.medicalProfile?.primaryCarePhysician ||
    'Dr. Marcus Chen, MD (Cedars-Sinai Medical Group)';
  const age = String(patient?.age || '38');
  const sex = patient?.gender || patient?.sex || 'Female';
  const height = patient?.height || patient?.medicalProfile?.height || `5'7"`;
  const weight = patient?.weight || patient?.medicalProfile?.weight || '138 lbs';

  let html = htmlTemplate;

  // 1. Pre-fill Patient Name fields
  html = html.replace(
    /(<input[^>]*?(?:id|name)=["'](?:patientName|fullName|ptName|clientName|printName|certPrint|ackPrint)["'][^>]*?)(>)/gi,
    (match, p1) => {
      if (p1.includes('value=')) return match;
      return `${p1} value="${ptName}">`;
    }
  );

  // 2. Pre-fill DOB fields
  html = html.replace(
    /(<input[^>]*?(?:id|name)=["'](?:dob|ptDob|birthDate)["'][^>]*?)(>)/gi,
    (match, p1) => {
      if (p1.includes('value=')) return match;
      return `${p1} value="${ptDob}">`;
    }
  );

  // 3. Pre-fill Phone fields
  html = html.replace(
    /(<input[^>]*?(?:id|name)=["'](?:phone|ptPhone|tel|telephone)["'][^>]*?)(>)/gi,
    (match, p1) => {
      if (p1.includes('value=')) return match;
      return `${p1} value="${ptPhone}">`;
    }
  );

  // 4. Pre-fill Email fields
  html = html.replace(
    /(<input[^>]*?(?:id|name)=["'](?:email|ptEmail)["'][^>]*?)(>)/gi,
    (match, p1) => {
      if (p1.includes('value=')) return match;
      return `${p1} value="${ptEmail}">`;
    }
  );

  // 5. Pre-fill Address fields
  html = html.replace(
    /(<input[^>]*?(?:id|name)=["'](?:address|streetAddress|patientAddress)["'][^>]*?)(>)/gi,
    (match, p1) => {
      if (p1.includes('value=')) return match;
      return `${p1} value="${ptAddress}">`;
    }
  );

  // 6. Pre-fill Age
  html = html.replace(
    /(<input[^>]*?(?:id|name)=["'](?:age|ptAge)["'][^>]*?)(>)/gi,
    (match, p1) => {
      if (p1.includes('value=')) return match;
      return `${p1} value="${age}">`;
    }
  );

  // 7. Pre-fill Sex / Gender select options
  if (sex.toLowerCase().includes('female')) {
    html = html.replace(
      /(<option[^>]*?value=["']Female["'][^>]*?)(>)/gi,
      (match, p1) => (p1.includes('selected') ? match : `${p1} selected>`)
    );
  } else if (sex.toLowerCase().includes('male')) {
    html = html.replace(
      /(<option[^>]*?value=["']Male["'][^>]*?)(>)/gi,
      (match, p1) => (p1.includes('selected') ? match : `${p1} selected>`)
    );
  }

  // 8. Pre-fill Height & Weight
  html = html.replace(
    /(<input[^>]*?(?:id|name)=["']height["'][^>]*?)(>)/gi,
    (match, p1) => (p1.includes('value=') ? match : `${p1} value="${height}">`)
  );
  html = html.replace(
    /(<input[^>]*?(?:id|name)=["']weight["'][^>]*?)(>)/gi,
    (match, p1) => (p1.includes('value=') ? match : `${p1} value="${weight}">`)
  );

  // 9. Pre-fill Primary Care Physician / Referring Doctor
  html = html.replace(
    /(<input[^>]*?(?:id|name)=["'](?:primaryPhysician|pcp|physician|referringDoc)["'][^>]*?)(>)/gi,
    (match, p1) => (p1.includes('value=') ? match : `${p1} value="${pcp}">`)
  );

  // 10. Pre-fill Emergency Contact Info
  html = html.replace(
    /(<input[^>]*?(?:id|name)=["'](?:emergencyName|emContactName|emName)["'][^>]*?)(>)/gi,
    (match, p1) => (p1.includes('value=') ? match : `${p1} value="${emName}">`)
  );
  html = html.replace(
    /(<input[^>]*?(?:id|name)=["'](?:emergencyPhone|emContactPhone|emPhone)["'][^>]*?)(>)/gi,
    (match, p1) => (p1.includes('value=') ? match : `${p1} value="${emPhone}">`)
  );
  html = html.replace(
    /(<input[^>]*?(?:id|name)=["'](?:certRelation|emergencyRelation|relation)["'][^>]*?)(>)/gi,
    (match, p1) => (p1.includes('value=') ? match : `${p1} value="${emRelation}">`)
  );

  // 11. Pre-fill Insurance fields
  html = html.replace(
    /(<input[^>]*?(?:id|name)=["'](?:insCompany|insuranceCompany|carrier)["'][^>]*?)(>)/gi,
    (match, p1) => (p1.includes('value=') ? match : `${p1} value="${insCompany}">`)
  );
  html = html.replace(
    /(<input[^>]*?(?:id|name)=["'](?:memberId|subscriberId|policyNumber)["'][^>]*?)(>)/gi,
    (match, p1) => (p1.includes('value=') ? match : `${p1} value="${insMemberId}">`)
  );
  html = html.replace(
    /(<input[^>]*?(?:id|name)=["'](?:groupNumber|groupNum|secGroup)["'][^>]*?)(>)/gi,
    (match, p1) => (p1.includes('value=') ? match : `${p1} value="${insGroup}">`)
  );
  html = html.replace(
    /(<input[^>]*?(?:id|name)=["'](?:planName|planType)["'][^>]*?)(>)/gi,
    (match, p1) => (p1.includes('value=') ? match : `${p1} value="${insPlan}">`)
  );

  // 12. Pre-fill Surgeon and Procedure Date
  html = html.replace(
    /(<input[^>]*?(?:id|name)=["'](?:surgeon|doctor)["'][^>]*?)(>)/gi,
    (match, p1) => (p1.includes('value=') ? match : `${p1} value="${doctor}">`)
  );
  html = html.replace(
    /(<input[^>]*?(?:id|name)=["'](?:procedureDate|surgDate|procDate|surgeryDate)["'][^>]*?)(>)/gi,
    (match, p1) => (p1.includes('value=') ? match : `${p1} value="${procDate}">`)
  );

  // 13. Pre-fill Cardholder Name for CC Auth
  html = html.replace(
    /(<input[^>]*?(?:id|name)=["']cardName["'][^>]*?)(>)/gi,
    (match, p1) => (p1.includes('value=') ? match : `${p1} value="${ptName}">`)
  );
  html = html.replace(
    /(<input[^>]*?(?:id|name)=["']zip["'][^>]*?)(>)/gi,
    (match, p1) => (p1.includes('value=') ? match : `${p1} value="90024">`)
  );

  // 14. Check default checkboxes (Advance Directives acknowledgement, HIPAA acknowledgment)
  html = html.replace(
    /(<input[^>]*?id=["'](?:advUnderstood|advNo|ackHipaa|ackInfo)["'][^>]*?)(>)/gi,
    (match, p1) => (p1.includes('checked') ? match : `${p1} checked>`)
  );

  // 15. Pre-fill known clinical history (Medical History / Anesthesia Questionnaire /
  // Anesthesia Pre-Op Evaluation forms) from patient.medicalProfile, when on file from
  // a prior visit. A first-time patient has no medicalProfile, so none of this applies
  // and the form opens blank as before — only a "repeat" patient with a record gets the
  // review-and-confirm experience.
  const mp: any = patient?.medicalProfile;
  const knownAllergies = Array.isArray(patient?.allergies)
    ? patient!.allergies
    : typeof patient?.allergies === 'string' && patient.allergies
    ? [patient.allergies]
    : [];
  const hasDocumentedAllergies = knownAllergies.length > 0 && !knownAllergies.some((a) => /none known/i.test(a));

  if (mp) {
    const pmhValues = mp.pastMedicalHistory?.length ? mp.pastMedicalHistory : ['None'];
    html = fillCheckboxGroupByValue(html, 'pmh', pmhValues);
    html = fillTextareaByAttr(html, 'pmhDetails', mp.pastMedicalHistoryDetails);

    const fhValues = mp.familyHistory?.length ? mp.familyHistory : ['None Known'];
    html = fillCheckboxGroupByValue(html, 'fh', fhValues);
    html = fillTextareaByAttr(html, 'fhDetails', mp.familyHistoryDetails);

    const rosValues = mp.reviewOfSystems?.length ? mp.reviewOfSystems : ['None'];
    html = fillCheckboxGroupByValue(html, 'ros', rosValues);

    // Allergy status — reuse the patient's existing `allergies` field (already the
    // source of truth used elsewhere in the chart) rather than duplicating it on
    // medicalProfile.
    html = fillRadioGroupByValue(html, 'allergyStatus', hasDocumentedAllergies ? 'yes' : 'none');
    if (hasDocumentedAllergies) {
      html = revealHiddenDiv(html, 'allergyDetails');
      html = fillTextareaByAttr(html, 'drugAllergies', knownAllergies.join('; '));
    }

    // Medications
    const meds: any[] = mp.medications || [];
    html = fillRadioGroupByValue(html, 'medStatus', meds.length ? 'yes' : 'none');
    if (meds.length) {
      html = revealHiddenDiv(html, 'medTableWrap');
      meds.slice(0, 6).forEach((med, i) => {
        const n = i + 1;
        html = fillTextValueByName(html, `med${n}_name`, med.name);
        html = fillTextValueByName(html, `med${n}_dose`, med.dose);
        html = fillTextValueByName(html, `med${n}_freq`, med.freq);
        html = fillTextValueByName(html, `med${n}_reason`, med.reason);
      });
    }

    // Past surgeries + prior anesthesia complications
    const surgeries: any[] = mp.pastSurgeries || [];
    html = fillRadioGroupByValue(html, 'surgStatus', surgeries.length ? 'yes' : 'none');
    if (surgeries.length) {
      html = revealHiddenDiv(html, 'surgTableWrap');
      surgeries.slice(0, 5).forEach((surg, i) => {
        const n = i + 1;
        html = fillTextValueByName(html, `surg${n}_name`, surg.name);
        html = fillTextValueByName(html, `surg${n}_year`, surg.year);
        html = fillTextValueByName(html, `surg${n}_notes`, surg.notes);
      });
      if (mp.priorAnesthesiaComplications) {
        html = setCheckedById(html, 'anesProblems', true);
        html = fillTextareaByAttr(html, 'anesDetails', mp.priorAnesthesiaComplications);
      }
    }

    // Social history
    if (mp.smokingStatus) {
      html = fillRadioGroupByValue(html, 'smoking', mp.smokingStatus);
      if (mp.smokingStatus !== 'Never') html = revealHiddenDiv(html, 'smokeDetails');
    }
    if (mp.alcoholUse) html = fillRadioGroupByValue(html, 'alcohol', mp.alcoholUse);
    if (mp.illicitDrugUse) {
      html = fillRadioGroupByValue(html, 'illicit', mp.illicitDrugUse);
      if (mp.illicitDrugUse === 'Yes') html = fillTextValueByName(html, 'drugDetails', mp.illicitDrugDetails);
    }
    if (mp.exerciseLevel) html = fillRadioGroupByValue(html, 'exercise', mp.exerciseLevel);

    // Anesthesia Questionnaire (form-anesthesia) — prior GA experience, PONV history,
    // and airway concerns. ASA/airway *classification* is a clinical judgment made at
    // the visit, so it is deliberately left for the anesthesiologist to assess live
    // rather than auto-filled from history.
    if (mp.priorGeneralAnesthesia) html = setSelectValue(html, 'priorGA', mp.priorGeneralAnesthesia);
    if (mp.postOpNauseaHistory) html = setSelectValue(html, 'ponv', mp.postOpNauseaHistory);
    const airway: string[] = mp.airwayConcerns || [];
    html = setCheckedById(html, 'air_loose', airway.includes('looseTeeth'));
    html = setCheckedById(html, 'air_dentures', airway.includes('dentures'));
    html = setCheckedById(html, 'air_tmj', airway.includes('tmj'));
    html = setCheckedById(html, 'air_neck', airway.includes('neckMovement'));

    // Anesthesia Pre-Op Evaluation (nursing-anesthesia-preop-evaluation) — free-text
    // summary fields distinct from the intake Medical History's checkbox grid.
    html = fillTextValueByName(html, 'pmh', mp.pastMedicalHistory?.length ? mp.pastMedicalHistory.join(', ') : undefined);
    if (mp.pastMedicalHistory && mp.pastMedicalHistory.length === 0) html = setCheckedById(html, 'pmh_none', true);
    const pshSummary = [
      ...surgeries.map((s) => `${s.name}${s.year ? ` (${s.year})` : ''}`),
      mp.priorAnesthesiaComplications ? `Anesthesia: ${mp.priorAnesthesiaComplications}` : '',
    ]
      .filter(Boolean)
      .join('; ');
    html = fillTextValueByName(html, 'psh', pshSummary || undefined);
    if (!surgeries.length) html = setCheckedById(html, 'psh_none', true);
    if (surgeries.length && !mp.priorAnesthesiaComplications) html = setCheckedById(html, 'ga_none', true);
    html = fillTextValueByName(html, 'allergies', hasDocumentedAllergies ? knownAllergies.join(', ') : undefined);
    if (!hasDocumentedAllergies) html = setCheckedById(html, 'nkda', true);
    const medsSummary = meds.map((m) => `${m.name}${m.dose ? ` ${m.dose}` : ''}${m.freq ? ` ${m.freq}` : ''}`).join('; ');
    html = fillTextValueByName(html, 'meds', medsSummary || undefined);
    if (!meds.length) html = setCheckedById(html, 'nomeds', true);
  }

  // 16. Apply any previous user inputs if passed
  if (previousSavedValues) {
    Object.entries(previousSavedValues).forEach(([key, val]) => {
      if (typeof val === 'boolean') {
        if (val) {
          html = html.replace(
            new RegExp(`(<input[^>]*?(?:id|name)=["']${key}["'][^>]*?)(>)`, 'gi'),
            (match, p1) => (p1.includes('checked') ? match : `${p1} checked>`)
          );
        }
      } else if (typeof val === 'string' && val.trim()) {
        html = html.replace(
          new RegExp(`(<input[^>]*?(?:id|name)=["']${key}["'][^>]*?)(>)`, 'gi'),
          (match, p1) => {
            if (p1.includes('value=')) {
              return p1.replace(/value=["'][^"']*?["']/, `value="${val}"`) + '>';
            }
            return `${p1} value="${val}">`;
          }
        );
      }
    });
  }

  return html;
}
