// Core engine behind the PDF-backed form viewer (PdfFormViewer.tsx).
//
// This is the OI equivalent of the ASPX PDF form viewer described by the
// practice: real PDF templates (with their own AcroForm fields, exactly as
// authored), a freehand pen tool, and a two-state save model — "Save
// (editable)" keeps the document as an in-progress draft any authorized role
// can reopen and continue, "Save & Lock" bakes the current values into the
// PDF's own fields and marks it read-only from then on.
//
// pdf.js (pdfjs-dist) is used purely for rendering pages to a <canvas>.
// pdf-lib is used to read the AcroForm field layout (name/type/rects) and to
// write field values back into the PDF bytes. We deliberately do NOT rely on
// pdf-lib's form.flatten() — it chokes on some legitimately-authored real
// PDFs (verified against the practice's own anesthesia forms) — locking is
// instead enforced at the OI application layer: a locked document simply
// never mounts an editable overlay, so within OI it is unmistakably
// read-only, while the field VALUES are still written into the PDF's own
// AcroForm so the file is self-describing if it's ever opened elsewhere.

import { PDFDocument, PDFTextField, PDFCheckBox, PDFSignature, rgb } from 'pdf-lib';

export type PdfFieldKind = 'text' | 'checkbox' | 'signature';

export interface PdfFieldRect {
  x: number; // PDF points, page space, origin bottom-left
  y: number;
  width: number;
  height: number;
}

export interface PdfFieldMeta {
  name: string;
  kind: PdfFieldKind;
  rects: PdfFieldRect[]; // usually 1; checkboxes can legitimately have >1 widget sharing one field name
  onValue?: string; // checkbox "checked" export value
}

export interface PdfDocMeta {
  pageWidth: number;
  pageHeight: number;
  fields: PdfFieldMeta[];
}

export async function loadPdfDocMeta(pdfBytes: ArrayBuffer): Promise<PdfDocMeta> {
  const pdfDoc = await PDFDocument.load(pdfBytes);
  const page = pdfDoc.getPage(0);
  const { width, height } = page.getSize();
  const form = pdfDoc.getForm();

  const fields: PdfFieldMeta[] = form.getFields().map((field) => {
    const widgets = field.acroField.getWidgets();
    const rects: PdfFieldRect[] = widgets.map((w) => {
      const r = w.getRectangle();
      return { x: r.x, y: r.y, width: r.width, height: r.height };
    });

    if (field instanceof PDFCheckBox) {
      let onValue: string | undefined;
      try {
        onValue = field.acroField.getOnValue()?.decodeText?.() ?? String(field.acroField.getOnValue() ?? 'Yes');
      } catch {
        onValue = 'Yes';
      }
      return { name: field.getName(), kind: 'checkbox', rects, onValue };
    }
    if (field instanceof PDFSignature) {
      return { name: field.getName(), kind: 'signature', rects };
    }
    // Text fields, and anything else we don't specifically model, are
    // treated as free text — safe default for a real-world form.
    return { name: field.getName(), kind: 'text', rects };
  });

  return { pageWidth: width, pageHeight: height, fields };
}

// Reads each field's current value baked into the PDF (i.e. the template's
// own defaults — e.g. the practice's "normal exam" boilerplate) so a brand
// new draft opens exactly the way the source PDF would in any other viewer.
export async function readPdfFieldDefaults(pdfBytes: ArrayBuffer): Promise<Record<string, string | boolean>> {
  const pdfDoc = await PDFDocument.load(pdfBytes);
  const form = pdfDoc.getForm();
  const values: Record<string, string | boolean> = {};
  for (const field of form.getFields()) {
    if (field instanceof PDFTextField) {
      values[field.getName()] = field.getText() ?? '';
    } else if (field instanceof PDFCheckBox) {
      values[field.getName()] = field.isChecked();
    }
    // Signature fields have no text/boolean "value" — the drawn image is
    // tracked separately as a data URL keyed by field name.
  }
  return values;
}

export interface PenStroke {
  points: { x: number; y: number }[]; // PDF points, page space
  color: string;
}

export interface TextAnnotation {
  x: number;
  y: number;
  text: string;
}

export interface PdfDraftState {
  fieldValues: Record<string, string | boolean>;
  signatureImages: Record<string, string>; // fieldName -> PNG data URL
  penStrokes: PenStroke[];
  textAnnotations: TextAnnotation[];
  lastSavedAt: string;
}

export type PdfDocStatus = 'DRAFT' | 'LOCKED';

interface StoredPdfDoc {
  status: PdfDocStatus;
  draft: PdfDraftState;
  lockedPdfBase64?: string; // present once status === 'LOCKED'
  lockedAt?: string;
  lockedBy?: string;
}

function storageKey(patientId: string, documentId: string): string {
  return `oi_pdf_form_${documentId}_${patientId}`;
}

export function loadStoredPdfDoc(patientId: string, documentId: string): StoredPdfDoc | null {
  try {
    const raw = localStorage.getItem(storageKey(patientId, documentId));
    if (!raw) return null;
    return JSON.parse(raw) as StoredPdfDoc;
  } catch {
    return null;
  }
}

export function saveDraftPdfDoc(patientId: string, documentId: string, draft: PdfDraftState): void {
  const existing = loadStoredPdfDoc(patientId, documentId);
  const stored: StoredPdfDoc = { ...existing, status: 'DRAFT', draft };
  localStorage.setItem(storageKey(patientId, documentId), JSON.stringify(stored));
}

export function lockPdfDoc(patientId: string, documentId: string, draft: PdfDraftState, lockedPdfBytes: Uint8Array, lockedBy: string): void {
  const stored: StoredPdfDoc = {
    status: 'LOCKED',
    draft,
    lockedPdfBase64: uint8ToBase64(lockedPdfBytes),
    lockedAt: new Date().toISOString(),
    lockedBy,
  };
  localStorage.setItem(storageKey(patientId, documentId), JSON.stringify(stored));
}

function uint8ToBase64(bytes: Uint8Array): string {
  let binary = '';
  const chunkSize = 0x8000;
  for (let i = 0; i < bytes.length; i += chunkSize) {
    binary += String.fromCharCode(...bytes.subarray(i, i + chunkSize));
  }
  return btoa(binary);
}

export function base64ToUint8(base64: string): Uint8Array {
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return bytes;
}

// Writes the current draft's field values (and, for signature fields, the
// drawn image) into the PDF's own AcroForm fields, and draws any freehand
// pen strokes / free-placed text directly onto the page content. Returns the
// resulting PDF bytes — used both to produce the locked artifact and to
// offer a "download filled PDF" export at any time.
export async function bakeDraftIntoPdf(
  pdfBytes: ArrayBuffer,
  draft: PdfDraftState,
  fieldMeta: PdfFieldMeta[]
): Promise<Uint8Array> {
  const pdfDoc = await PDFDocument.load(pdfBytes);
  const form = pdfDoc.getForm();
  const page = pdfDoc.getPage(0);

  for (const meta of fieldMeta) {
    const value = draft.fieldValues[meta.name];
    if (meta.kind === 'text' && typeof value === 'string') {
      try {
        form.getTextField(meta.name).setText(value);
      } catch {
        // Field may legitimately not resolve as a simple text field on some
        // unusually-authored PDFs; skip rather than abort the whole bake.
      }
    } else if (meta.kind === 'checkbox') {
      try {
        const cb = form.getCheckBox(meta.name);
        if (value) cb.check();
        else cb.uncheck();
      } catch {
        // ignore
      }
    } else if (meta.kind === 'signature') {
      const dataUrl = draft.signatureImages[meta.name];
      const rect = meta.rects[0];
      if (dataUrl && rect) {
        const pngBytes = base64ToUint8(dataUrl.split(',')[1] || '');
        const img = await pdfDoc.embedPng(pngBytes);
        page.drawImage(img, { x: rect.x, y: rect.y, width: rect.width, height: rect.height });
      }
    }
  }

  for (const stroke of draft.penStrokes) {
    for (let i = 1; i < stroke.points.length; i++) {
      page.drawLine({
        start: stroke.points[i - 1],
        end: stroke.points[i],
        thickness: 1.6,
        color: hexToRgbColor(stroke.color),
      });
    }
  }

  for (const ann of draft.textAnnotations) {
    page.drawText(ann.text, { x: ann.x, y: ann.y, size: 10 });
  }

  return pdfDoc.save();
}

function hexToRgbColor(hex: string) {
  const clean = hex.replace('#', '');
  const r = parseInt(clean.substring(0, 2), 16) / 255;
  const g = parseInt(clean.substring(2, 4), 16) / 255;
  const b = parseInt(clean.substring(4, 6), 16) / 255;
  return rgb(r, g, b);
}
