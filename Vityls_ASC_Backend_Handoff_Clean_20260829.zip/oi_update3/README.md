# Vityls ASC — Backend Handoff Baseline

This repository is the clean ASC frontend baseline prepared for backend development.

## Start locally

```bash
npm install
npm run dev
```

The development server exposes a health endpoint at:

`GET /api/health`

All other `/api/*` routes intentionally return `501 BACKEND_NOT_IMPLEMENTED` until the production API is connected.

## Important

There is no seeded patient, appointment, encounter, document, message, task, billing, or clinical AI data in this handoff baseline.

The only clinical content intentionally retained is the **default HTML Form Studio template library** available to practices.

Read `BACKEND_HANDOFF.md` before implementing persistence.

## Target architecture

`React frontend -> authenticated Vityls API -> SQL database + object/blob storage`

The browser-local storage/IndexedDB utilities in `src/utils/` are prototype adapters and should be replaced behind backend services.

## Templates

The platform retains 27 default HTML form templates:

- 26 source HTML templates under `reference-forms/asc-default-library/`
- 1 Vityls/Office Intelligence core Pre-Operative Assessment & Readiness template

## Suggested backend sequence

1. Organization / Location / User / Role
2. Patient / Appointment / Encounter
3. Workflow stages and tasks
4. Form templates / versions / responses / signatures
5. Documents / reviews / annotations / object storage
6. Audit trail
7. Communications model
8. Nightingale AI services
9. Microsoft Graph Mail connector

Production clinical tables should begin empty.
