# Vityls ASC — Clean Backend Handoff

Date: August 29, 2026

## Purpose

This package is the frozen ASC frontend baseline for backend development.

It intentionally contains **no seeded clinical records**. The next patient,
appointment, encounter, document, form response, signature, task, message, or
Nightingale clinical summary should come from the new backend/API rather than
from hard-coded frontend demo data.

## Intentionally retained

- Finalized ASC user interface and navigation
- Day-of-Surgery workflow architecture
- Patient Chart UI
- Intake workflow
- Forms & Documents architecture
- Interactive HTML form viewer
- Continuous multipage PDF viewer and annotation engine
- Clinical Form Studio
- Administration/configuration UI
- Patient Portal UI shell
- Nightingale UI/interaction surfaces
- Default ASC HTML template library
- Generic platform types, workflow definitions, and configuration structures

### Default HTML templates

The platform template library remains available to all practices:

- 26 user-supplied ASC HTML source templates in `reference-forms/asc-default-library/`
- 1 Office Intelligence/Vityls core `Pre-Operative Assessment & Readiness` template definition
- Total platform defaults: **27**

The source/template implementation remains in:

- `src/data/ascDefaultFormLibrary.ts`
- `src/data/ascDefaultFormPresentations.ts`
- `src/data/officialHtmlFormLibrary.ts`
- `reference-forms/asc-default-library/`

## Removed / emptied

The handoff baseline has no seeded:

- fictitious patients
- historical patient directory
- appointments or surgical cases
- encounter workflow progress
- bottleneck alerts
- tasks
- communication counts
- portal patient profiles
- portal appointments
- portal forms/responses
- portal documents
- portal messages
- prescriptions
- bills
- claims
- invoices
- implant-use records
- sample practice locations/providers/users
- fictitious Nightingale morning brief
- fictitious Nightingale workflow examples
- legacy Nursing/Notes/Intake test-form instances
- bundled PDF test templates

The patient chart displays an empty-state message until patient data is supplied
by the backend. The portal displays a backend-integration placeholder until
patient identity/authentication is connected.

## Existing browser-storage code

Several current services still contain local browser persistence because they
were used to prove the frontend workflow:

- `src/utils/localFormStudioDb.ts`
- `src/utils/localFormResponseStore.ts`
- `src/utils/pdfFormEngine.ts`
- `src/utils/portalMessageStore.ts`

**Do not treat these as the production data layer.**

They should be replaced/adapted behind API services. The production target is:

`React UI -> authenticated Vityls API -> SQL database + object/blob storage`

Large source documents/PDFs should live in object/blob storage. SQL should hold
metadata, relationships, status, hashes, annotations/audit metadata, and storage
references.

## Recommended first backend entities

Start with these stable platform-level entities:

1. Organization
2. Location
3. User
4. Role / Permission
5. Provider
6. Patient
7. Appointment
8. Encounter
9. WorkflowStage / EncounterStage
10. FormTemplate
11. FormTemplateVersion
12. FormResponse
13. Signature / Attestation
14. Document
15. DocumentVersion / Annotation
16. DocumentReview
17. Task
18. Communication
19. CommunicationParticipant
20. CommunicationAttachment
21. NightingaleOutput / AIEvent
22. AuditEvent

Design these as **Vityls platform entities**, not ASC-only tables. ASC is the
first and most comprehensive edition; MED, SPA, ADMIN, FORMS, PORTAL and MAIL
should later use the same platform services/capability model.

## Suggested API boundary

The frontend should eventually obtain data from services such as:

- `/api/organizations`
- `/api/locations`
- `/api/users`
- `/api/patients`
- `/api/appointments`
- `/api/encounters`
- `/api/form-templates`
- `/api/form-responses`
- `/api/documents`
- `/api/document-reviews`
- `/api/tasks`
- `/api/communications`
- `/api/ai`

The exact route structure is Henry's/backend team's decision; these are logical
resource boundaries rather than a mandated URL design.

## Data reset policy

Production should begin with empty clinical tables.

Do not migrate any records from the prototype/local browser stores. Import only
approved platform configuration and the default HTML template library.

Development/Staging may create new fictitious patients after the database is
connected, but those patients should be created through the real API/database
so the test exercises the production persistence path.

## Mail

The database can be built before Vityls Mail is implemented.

Reserve generic Communication/Participant/Attachment relationships now. A later
Microsoft Graph connector can add mailbox/provider-specific metadata without
redesigning Patient, Encounter, Document, Task, or Audit tables.

## Validation performed on this package

- 79 TypeScript/TSX files parsed successfully
- 0 syntax parse errors
- 0 focused unresolved-name/type errors in the cleaned data/configuration paths
