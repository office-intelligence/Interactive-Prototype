export interface NursingHtmlForm {
  id: string;
  order: number;
  title: string;
  category: string;
  episode: string;
  status: 'Completed' | 'In Progress' | 'Signed & Verified' | 'Pending Entry';
  aiStatus: string;
  aiStatusType: 'success' | 'warning' | 'info';
  fileName: string;
  summary: string;
  htmlTemplate: string;
  // See the matching comment on IntakeHtmlForm in intakeHtmlForms.ts. Most
  // clinical/nursing chart documents here already embed their own typed
  // "signed by" field as part of the document content (a printed-name line,
  // matching how the paper version of the form works), so the outer legal
  // e-signature panel would just duplicate that — those are false and
  // complete via a lightweight "Mark as Reviewed" action instead. The two
  // patient consent forms and the post-op instructions acknowledgment are
  // genuine patient/legal attestations with no such embedded field, so they
  // keep the full outer signature capture — true.
  requiresSignature: boolean;
}

export const SURGICAL_EPISODES = [];

export const INITIAL_NURSING_HTML_FORMS: NursingHtmlForm[] = [];
