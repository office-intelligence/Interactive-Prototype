import type { AscDefaultFormTemplate } from './ascDefaultFormLibrary';
import { ASC_DEFAULT_FORM_LIBRARY } from './ascDefaultFormLibrary';

const CORE_PREOP_TEMPLATE: AscDefaultFormTemplate = {
  title: 'Pre-Operative Assessment & Readiness',
  sourceFile: 'Office_Intelligence_PreOperative_Assessment_Readiness.html',
  group: 'Nursing / Recovery',
  collectionStage: 'Nursing',
  reviewStages: ['Anesthesia','Surgeon'],
  sourceControlCount: 11,
  signatureZones: 2,
  fields: [
    { id:'identity',label:'Patient / procedure / surgeon / date of service',type:'text',required:true,owner:'Front Desk',source:'Chart' },
    { id:'history',label:'Current history / interval change review',type:'textarea',required:true,owner:'Nursing + Provider',source:'Chart' },
    { id:'allergies',label:'Allergies — carried forward; verify/update',type:'clinical-list',required:true,owner:'Nursing',source:'Chart' },
    { id:'meds',label:'Active medications — carried forward; verify/update',type:'clinical-list',required:true,owner:'Nursing',source:'Chart' },
    { id:'npo',label:'NPO status',type:'radio',required:true,owner:'Nursing',source:'Patient',options:['Confirmed','Not confirmed','Exception — explain'] },
    { id:'ride',label:'Responsible adult / transportation',type:'radio',required:true,owner:'Front Desk + Nursing',source:'Patient',options:['Confirmed','Not confirmed','Not applicable'] },
    { id:'clearance',label:'Medical clearance / H&P source reviewed',type:'checkbox',required:true,owner:'Nursing + Provider',source:'Chart',options:['Reviewed and available'] },
    { id:'vte',label:'VTE risk assessment and prophylaxis plan',type:'score',required:true,owner:'Nursing + Surgeon',source:'Provider' },
    { id:'consent',label:'Procedure consent — procedure + named surgeon',type:'signature',required:true,owner:'Patient + Surgeon',source:'Provider' },
    { id:'anesthesiaConsent',label:'Anesthesia / sedation consent',type:'signature',required:true,owner:'Patient + Anesthesia',source:'Provider' },
    { id:'timeout',label:'Time-out verification',type:'checkbox',required:true,owner:'OR Team',source:'Provider',options:['Patient','Procedure','Site/laterality','Implants/equipment'] },
  ],
};

export const OFFICIAL_HTML_FORM_LIBRARY: AscDefaultFormTemplate[] = [
  CORE_PREOP_TEMPLATE,
  ...ASC_DEFAULT_FORM_LIBRARY,
];

export const OFFICIAL_HTML_FORM_TEMPLATE_COUNT = OFFICIAL_HTML_FORM_LIBRARY.length;
