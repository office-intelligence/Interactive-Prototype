/**
 * Configurable clinical-record profile.
 *
 * Design intent: the practice/facility configures WHAT must be collected and WHO
 * owns/approves it. The rendering layer (HTML/tablet UI) and archival layer
 * (final PDF rendition) are implementation details, not the source of truth.
 *
 * In production these records should come from the database and be versioned by
 * facility + effective date so a historical encounter always retains the exact
 * rules/templates that governed that date of service.
 */
export type CaseWorkflowRole = 'Patient' | 'Front Office' | 'Nursing' | 'Anesthesia' | 'Surgeon' | 'PACU' | 'Administrator';

export interface CaseRequirementDefinition {
  id: string;
  title: string;
  owner: CaseWorkflowRole | CaseWorkflowRole[];
  required: boolean;
  requiresSignature?: boolean;
  requiresClinicalReview?: boolean;
  sourceType: 'structured-form' | 'uploaded-source' | 'generated-note' | 'device-record' | 'checklist';
  finalFormat: 'PDF';
  specialtyTags?: string[];
}

export interface CaseStageDefinition {
  id: string;
  title: string;
  owner: string;
  gate?: 'before-clinical-handoff' | 'before-procedure' | 'before-discharge' | 'before-case-close';
  requirementIds: string[];
}

export interface CaseWorkflowProfile {
  id: string;
  name: string;
  facilityType: 'ASC' | 'Office-based Surgery' | 'Multispecialty Surgical Facility' | 'Clinic';
  version: string;
  effectiveDate: string;
  requirements: CaseRequirementDefinition[];
  stages: CaseStageDefinition[];
}

export const MULTISPECIALTY_SURGERY_CENTER_PROFILE: CaseWorkflowProfile = {
  id: 'multispecialty-surgery-center-default',
  name: 'Multispecialty Surgery Center — Core Surgical Encounter',
  facilityType: 'Multispecialty Surgical Facility',
  version: '1.0',
  effectiveDate: '2026-08-22',
  requirements: [
    { id: 'registration', title: 'Registration / Demographics', owner: ['Patient', 'Front Office'], required: true, sourceType: 'structured-form', finalFormat: 'PDF' },
    { id: 'medical-history', title: 'Medical & Surgical History', owner: ['Patient', 'Nursing'], required: true, requiresClinicalReview: true, sourceType: 'structured-form', finalFormat: 'PDF' },
    { id: 'anesthesia-questionnaire', title: 'Anesthesia Questionnaire', owner: ['Patient', 'Anesthesia'], required: true, requiresClinicalReview: true, sourceType: 'structured-form', finalFormat: 'PDF' },
    { id: 'preop-clearance', title: 'Pre-op Clearance / Consultation', owner: ['Front Office', 'Surgeon', 'Anesthesia'], required: true, requiresClinicalReview: true, sourceType: 'uploaded-source', finalFormat: 'PDF' },
    { id: 'labs-diagnostics', title: 'Laboratory / EKG / Diagnostic Reports', owner: ['Front Office', 'Nursing', 'Anesthesia', 'Surgeon'], required: true, requiresClinicalReview: true, sourceType: 'uploaded-source', finalFormat: 'PDF' },
    { id: 'nursing-preop', title: 'Pre-operative Nursing Assessment', owner: 'Nursing', required: true, requiresSignature: true, sourceType: 'structured-form', finalFormat: 'PDF' },
    { id: 'surgical-checklist', title: 'Comprehensive Surgical Safety Checklist', owner: ['Nursing', 'Anesthesia', 'Surgeon'], required: true, requiresSignature: true, sourceType: 'checklist', finalFormat: 'PDF' },
    { id: 'procedure-consent', title: 'Consent to Procedure', owner: ['Patient', 'Surgeon'], required: true, requiresSignature: true, sourceType: 'structured-form', finalFormat: 'PDF' },
    { id: 'anesthesia-consent', title: 'Consent to Anesthesia', owner: ['Patient', 'Anesthesia'], required: true, requiresSignature: true, sourceType: 'structured-form', finalFormat: 'PDF' },
    { id: 'standing-orders', title: "Doctor's Standing Orders", owner: 'Surgeon', required: true, requiresSignature: true, sourceType: 'structured-form', finalFormat: 'PDF' },
    { id: 'anesthesia-eval', title: 'Anesthesia Pre-op Evaluation', owner: 'Anesthesia', required: true, requiresSignature: true, sourceType: 'structured-form', finalFormat: 'PDF' },
    { id: 'anesthesia-record', title: 'Intra-operative Anesthesia Record', owner: 'Anesthesia', required: true, requiresSignature: true, sourceType: 'device-record', finalFormat: 'PDF' },
    { id: 'brief-op-note', title: 'Brief Operative Summary', owner: 'Surgeon', required: true, requiresSignature: true, sourceType: 'generated-note', finalFormat: 'PDF' },
    { id: 'operative-report', title: 'Detailed Operative Report', owner: 'Surgeon', required: true, requiresSignature: true, sourceType: 'generated-note', finalFormat: 'PDF' },
    { id: 'pacu-record', title: 'PACU / Recovery Record', owner: 'PACU', required: true, requiresSignature: true, sourceType: 'structured-form', finalFormat: 'PDF' },
    { id: 'discharge-criteria', title: 'Discharge Readiness / Objective Criteria', owner: ['PACU', 'Anesthesia', 'Surgeon'], required: true, requiresSignature: true, sourceType: 'checklist', finalFormat: 'PDF' },
    { id: 'postop-instructions', title: 'Postoperative Instructions & Acknowledgment', owner: ['PACU', 'Patient'], required: true, requiresSignature: true, sourceType: 'structured-form', finalFormat: 'PDF' },
    { id: 'case-summary', title: 'Nightingale Encounter Case Summary', owner: 'Administrator', required: true, sourceType: 'generated-note', finalFormat: 'PDF' },
  ],
  stages: [
    { id: 'prearrival', title: 'Pre-arrival Intake', owner: 'Patient + Front Office', requirementIds: ['registration', 'medical-history', 'anesthesia-questionnaire'] },
    { id: 'checkin', title: 'Arrival & Office Check-in', owner: 'Front Office', gate: 'before-clinical-handoff', requirementIds: ['registration', 'preop-clearance', 'labs-diagnostics'] },
    { id: 'nursing', title: 'Pre-op Nursing', owner: 'Nursing', gate: 'before-procedure', requirementIds: ['medical-history', 'nursing-preop', 'surgical-checklist', 'procedure-consent', 'anesthesia-consent', 'standing-orders'] },
    { id: 'anesthesia', title: 'Anesthesia Readiness', owner: 'Anesthesia', gate: 'before-procedure', requirementIds: ['anesthesia-questionnaire', 'preop-clearance', 'labs-diagnostics', 'anesthesia-eval', 'anesthesia-consent', 'anesthesia-record'] },
    { id: 'surgeon', title: 'Surgeon / Procedure', owner: 'Surgeon', gate: 'before-procedure', requirementIds: ['medical-history', 'preop-clearance', 'labs-diagnostics', 'procedure-consent', 'standing-orders', 'brief-op-note', 'operative-report'] },
    { id: 'pacu', title: 'PACU & Discharge', owner: 'PACU + Qualified Discharging Clinician', gate: 'before-discharge', requirementIds: ['pacu-record', 'discharge-criteria', 'postop-instructions'] },
    { id: 'final', title: 'Final Case Record', owner: 'Nightingale + Administrator', gate: 'before-case-close', requirementIds: ['case-summary'] },
  ],
};

/** Example of how a specialty can extend the core profile without forking UI code. */
export const OPHTHALMOLOGY_EXTENSION: CaseRequirementDefinition[] = [
  { id: 'laterality-confirmation', title: 'Eye / Laterality Confirmation', owner: ['Nursing', 'Surgeon'], required: true, requiresClinicalReview: true, sourceType: 'checklist', finalFormat: 'PDF', specialtyTags: ['Ophthalmology'] },
  { id: 'iol-implant-record', title: 'IOL / Implant Record', owner: ['Nursing', 'Surgeon'], required: true, sourceType: 'device-record', finalFormat: 'PDF', specialtyTags: ['Ophthalmology'] },
];

export const ORTHOPEDIC_EXTENSION: CaseRequirementDefinition[] = [
  { id: 'implant-log', title: 'Orthopedic Implant / Lot Tracking', owner: ['Nursing', 'Surgeon'], required: true, sourceType: 'device-record', finalFormat: 'PDF', specialtyTags: ['Orthopedics'] },
  { id: 'site-marking', title: 'Site / Side Marking Verification', owner: ['Nursing', 'Surgeon'], required: true, requiresClinicalReview: true, sourceType: 'checklist', finalFormat: 'PDF', specialtyTags: ['Orthopedics'] },
];
