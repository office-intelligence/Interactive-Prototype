// Generated from the 26 user-supplied Office Intelligence ASC HTML templates.
// Original HTML files are preserved under reference-forms/asc-default-library.
// Legacy inline/canvas signature implementations are normalized to editable signature fields.

export type AscDefaultFieldType = 'text' | 'textarea' | 'checkbox' | 'radio' | 'select' | 'date' | 'signature' | 'clinical-list' | 'score';
export interface AscDefaultField {
  id: string; label: string; type: AscDefaultFieldType; required: boolean; owner: string;
  options?: string[]; source?: 'Patient' | 'Chart' | 'Nursing' | 'Provider';
}
export interface AscDefaultFormTemplate {
  title: string; sourceFile: string; group: string; collectionStage: string; reviewStages: string[];
  fields: AscDefaultField[]; sourceControlCount: number; signatureZones: number;
}
export const ASC_DEFAULT_FORM_LIBRARY: AscDefaultFormTemplate[] = [
  {
    "title": "Against Medical Advice / Refusal Form",
    "sourceFile": "AMA_Refusal_Form.html",
    "group": "Nursing / Recovery",
    "collectionStage": "Nursing",
    "reviewStages": [
      "Surgeon"
    ],
    "fields": [
      {
        "id": "ama-refusal-form-patientname",
        "label": "Patient Name",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Chart"
      },
      {
        "id": "ama-refusal-form-dob",
        "label": "Date of Birth",
        "type": "date",
        "required": false,
        "owner": "Practice-defined",
        "source": "Chart"
      },
      {
        "id": "ama-refusal-form-formwhen",
        "label": "Date / Time of this form",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "ama-refusal-form-context",
        "label": "Procedure / visit context",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Chart"
      },
      {
        "id": "ama-refusal-form-natureother",
        "label": "Describe",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "ama-refusal-form-recommended",
        "label": "Recommended care explained to patient",
        "type": "textarea",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "ama-refusal-form-risks",
        "label": "Risks of refusal / leaving discussed (be specific)",
        "type": "textarea",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "ama-refusal-form-benefits",
        "label": "Benefits of recommended care discussed",
        "type": "textarea",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "ama-refusal-form-alternatives",
        "label": "Alternatives discussed (if any)",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Nursing"
      },
      {
        "id": "ama-refusal-form-patientreason",
        "label": "Patient’s stated reason for refusal / leaving",
        "type": "textarea",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "ama-refusal-form-capacity",
        "label": "Capacity / decision-maker notes",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "ama-refusal-form-patientprint",
        "label": "Print name (patient/surrogate)",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "ama-refusal-form-clinicianprint",
        "label": "Physician / RN print name",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Provider"
      },
      {
        "id": "ama-refusal-form-sigwhen",
        "label": "Date / Time",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "ama-refusal-form-nature",
        "label": "Leaving facility against medical advice (AMA)",
        "type": "checkbox",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "Leaving facility against medical advice (AMA)",
          "Refusing recommended procedure or treatment",
          "Refusing recommended diagnostic test",
          "Refusing recommended transfer / higher level of care",
          "Other:"
        ]
      },
      {
        "id": "ama-refusal-form-ack",
        "label": "I have been informed of the recommended care and of the risks of refusing it or leaving against medical advice.",
        "type": "checkbox",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "I have been informed of the recommended care and of the risks of refusing it or leaving against medi",
          "I understand that my refusal or departure may result in serious harm, including permanent injury or ",
          "I still choose to refuse the recommended care / leave against medical advice.",
          "I have had the opportunity to ask questions."
        ]
      },
      {
        "id": "ama-refusal-form-sigamapatient",
        "label": "Patient Signature",
        "type": "signature",
        "required": true,
        "owner": "Patient",
        "source": "Patient"
      },
      {
        "id": "ama-refusal-form-sigamawitness",
        "label": "Witness Signature",
        "type": "signature",
        "required": true,
        "owner": "Provider",
        "source": "Provider"
      }
    ],
    "sourceControlCount": 26,
    "signatureZones": 2
  },
  {
    "title": "Admission Form",
    "sourceFile": "Admission_Form.html",
    "group": "Patient Intake",
    "collectionStage": "Home / Patient Portal",
    "reviewStages": [
      "Front Desk",
      "Nursing"
    ],
    "fields": [
      {
        "id": "admission-form-patientname",
        "label": "Patient Full Name",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "admission-form-dob",
        "label": "Date of Birth",
        "type": "date",
        "required": false,
        "owner": "Practice-defined",
        "source": "Chart"
      },
      {
        "id": "admission-form-phone",
        "label": "Phone",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "admission-form-email",
        "label": "Email",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "admission-form-patientrights",
        "label": "patientRights",
        "type": "textarea",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "admission-form-patientresponsibilities",
        "label": "patientResponsibilities",
        "type": "textarea",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "admission-form-phirights",
        "label": "phiRights",
        "type": "textarea",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "admission-form-hipaanotice",
        "label": "hipaaNotice",
        "type": "textarea",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "admission-form-ownershipdisclosure",
        "label": "ownershipDisclosure",
        "type": "textarea",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "admission-form-grievancepolicy",
        "label": "grievancePolicy",
        "type": "textarea",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "admission-form-advancedirectives",
        "label": "advanceDirectives",
        "type": "textarea",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "admission-form-arbitrationtext",
        "label": "arbitrationText",
        "type": "textarea",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "admission-form-arbpatientdate",
        "label": "Date",
        "type": "date",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "admission-form-arbfacilitydate",
        "label": "Date",
        "type": "date",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "admission-form-ackprint",
        "label": "Print Name",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "admission-form-ackdate",
        "label": "Date",
        "type": "date",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "admission-form-feedisclosure",
        "label": "feeDisclosure",
        "type": "textarea",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "admission-form-init1",
        "label": "I have read and understand the fee disclosure above, including responsibility for charges in excess of the time estimate. Initial:",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "admission-form-init2",
        "label": "I understand the insurance payment assignment and 30-day remittance requirement if payment is sent to me. Initial:",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "admission-form-cashwitness",
        "label": "Witness",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "admission-form-cashdate",
        "label": "Date",
        "type": "date",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "admission-form-advunderstood",
        "label": "I have read and have an understanding about Advanced Directives.",
        "type": "checkbox",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "I have read and have an understanding about Advanced Directives."
        ]
      },
      {
        "id": "admission-form-advyes",
        "label": "I Do have an Advance Directive.",
        "type": "checkbox",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "I Do have an Advance Directive."
        ]
      },
      {
        "id": "admission-form-advno",
        "label": "I Do Not have an Advance Directive.",
        "type": "checkbox",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "I Do Not have an Advance Directive."
        ]
      },
      {
        "id": "admission-form-ackhipaa",
        "label": "I acknowledge that I have received a copy of the Privacy Notice/HIPAA Policy.",
        "type": "checkbox",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "I acknowledge that I have received a copy of the Privacy Notice/HIPAA Policy."
        ]
      },
      {
        "id": "admission-form-ackinfo",
        "label": "ackInfo",
        "type": "checkbox",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "I acknowledge that prior to my surgery date, I have received verbally and in writing: Patient Rights"
        ]
      },
      {
        "id": "admission-form-sigarbpatient",
        "label": "Patient Arbitration Signature",
        "type": "signature",
        "required": true,
        "owner": "Patient",
        "source": "Patient"
      },
      {
        "id": "admission-form-sigack",
        "label": "Patient Acknowledgement Signature",
        "type": "signature",
        "required": true,
        "owner": "Patient",
        "source": "Patient"
      },
      {
        "id": "admission-form-sigcashpatient",
        "label": "Patient Cash Fee Acknowledgement Signature",
        "type": "signature",
        "required": true,
        "owner": "Patient",
        "source": "Patient"
      }
    ],
    "sourceControlCount": 30,
    "signatureZones": 3
  },
  {
    "title": "Anesthesia Consent",
    "sourceFile": "Anesthesia_Consent.html",
    "group": "Anesthesia",
    "collectionStage": "Anesthesia",
    "reviewStages": [
      "Nursing"
    ],
    "fields": [
      {
        "id": "anesthesia-consent-patientname",
        "label": "Patient Name",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Chart"
      },
      {
        "id": "anesthesia-consent-procdate",
        "label": "Date of Procedure",
        "type": "date",
        "required": false,
        "owner": "Practice-defined",
        "source": "Chart"
      },
      {
        "id": "anesthesia-consent-anestypenotes",
        "label": "Additional notes / combined technique details",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "anesthesia-consent-risks",
        "label": "risks",
        "type": "textarea",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "anesthesia-consent-patientdate",
        "label": "Date",
        "type": "date",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "anesthesia-consent-anesdate",
        "label": "Date",
        "type": "date",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "anesthesia-consent-anestype",
        "label": "General — Endotracheal Anesthetic and respiratory gases passed through a tube in the trachea via nose or mouth.",
        "type": "checkbox",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "General - Endotracheal",
          "General - Mask",
          "TIVA",
          "Epidural",
          "Spinal",
          "Nerve Block",
          "MAC / IV Sedation",
          "Local",
          "Topical",
          "Combined / Other"
        ]
      },
      {
        "id": "anesthesia-consent-sigpatient",
        "label": "Patient Signature",
        "type": "signature",
        "required": true,
        "owner": "Patient",
        "source": "Patient"
      },
      {
        "id": "anesthesia-consent-siganes",
        "label": "Anesthesiologist Signature",
        "type": "signature",
        "required": true,
        "owner": "Provider",
        "source": "Provider"
      }
    ],
    "sourceControlCount": 18,
    "signatureZones": 2
  },
  {
    "title": "Anesthesia Evaluation",
    "sourceFile": "Anesthesia_Evaluation.html",
    "group": "Anesthesia",
    "collectionStage": "Anesthesia",
    "reviewStages": [
      "Nursing",
      "Surgeon"
    ],
    "fields": [
      {
        "id": "anesthesia-evaluation-patientname",
        "label": "Patient Full Name *",
        "type": "text",
        "required": true,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "anesthesia-evaluation-dob",
        "label": "Date of Birth *",
        "type": "date",
        "required": true,
        "owner": "Practice-defined",
        "source": "Chart"
      },
      {
        "id": "anesthesia-evaluation-proceduredate",
        "label": "Procedure Date",
        "type": "date",
        "required": false,
        "owner": "Practice-defined",
        "source": "Chart"
      },
      {
        "id": "anesthesia-evaluation-surgeon",
        "label": "Surgeon",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Provider"
      },
      {
        "id": "anesthesia-evaluation-field-5",
        "label": "Reaction details / other allergens",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "anesthesia-evaluation-field-6",
        "label": "Medication list (name, dose, frequency) or “See attached med reconciliation”",
        "type": "textarea",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "anesthesia-evaluation-field-7",
        "label": "Additional PMH / details",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "anesthesia-evaluation-field-8",
        "label": "Prior surgeries (list with approximate years)",
        "type": "textarea",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "anesthesia-evaluation-field-9",
        "label": "Tobacco Select... Never Former (quit >1 year) Former (quit <1 year) Current — cigarettes Current — vape / other",
        "type": "select",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "Never",
          "Former (quit >1 year)",
          "Former (quit <1 year)",
          "Current — cigarettes",
          "Current — vape / other"
        ]
      },
      {
        "id": "anesthesia-evaluation-field-10",
        "label": "Alcohol Select... None Occasional / social Daily moderate Heavy / possible dependence",
        "type": "select",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "None",
          "Occasional / social",
          "Daily moderate",
          "Heavy / possible dependence"
        ]
      },
      {
        "id": "anesthesia-evaluation-field-11",
        "label": "Recreational drugs Select... None Marijuana (occasional) Marijuana (daily) Other (document)",
        "type": "select",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "None",
          "Marijuana (occasional)",
          "Marijuana (daily)",
          "Other (document)"
        ]
      },
      {
        "id": "anesthesia-evaluation-field-12",
        "label": "Exercise tolerance / METS estimate Select... ≥4 METS (climb stairs, walk on level without stopping) <4 METS (limited by dyspnea, chest pain, or fatigue) Unable to assess / unknown",
        "type": "select",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "≥4 METS (climb stairs, walk on level without stopping)",
          "<4 METS (limited by dyspnea, chest pain, or fatigue)",
          "Unable to assess / unknown"
        ]
      },
      {
        "id": "anesthesia-evaluation-field-13",
        "label": "Ambulatory status Select... Independent Cane / walker Wheelchair Bedbound / limited",
        "type": "select",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "Independent",
          "Cane / walker",
          "Wheelchair",
          "Bedbound / limited"
        ]
      },
      {
        "id": "anesthesia-evaluation-field-14",
        "label": "Living situation / support Select... Lives with responsible adult Lives alone — escort confirmed for discharge Lives alone — escort NOT yet confirmed Assisted living / facility",
        "type": "select",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "Lives with responsible adult",
          "Lives alone — escort confirmed for discharge",
          "Lives alone — escort NOT yet confirmed",
          "Assisted living / facility"
        ]
      },
      {
        "id": "anesthesia-evaluation-field-15",
        "label": "ROS details / other positive findings",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "anesthesia-evaluation-field-16",
        "label": "BP (mmHg)",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "anesthesia-evaluation-field-17",
        "label": "HR (bpm)",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "anesthesia-evaluation-field-18",
        "label": "RR",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "anesthesia-evaluation-field-19",
        "label": "SpO2 (%)",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "anesthesia-evaluation-field-20",
        "label": "Temp (°F / °C)",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "anesthesia-evaluation-field-21",
        "label": "Height",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "anesthesia-evaluation-field-22",
        "label": "Weight",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "anesthesia-evaluation-field-23",
        "label": "BMI (if calculated)",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "anesthesia-evaluation-field-24",
        "label": "Well-appearing, no acute distress Ill-appearing / distressed Other (note)",
        "type": "select",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "Well-appearing, no acute distress",
          "Ill-appearing / distressed",
          "Other (note)"
        ]
      },
      {
        "id": "anesthesia-evaluation-field-25",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "anesthesia-evaluation-field-26",
        "label": "Mallampati I–II, adequate mouth opening, normal neck Mallampati III–IV or limited mobility Dentures / loose teeth / beard / other concern",
        "type": "select",
        "required": false,
        "owner": "Practice-defined",
        "source": "Nursing",
        "options": [
          "Mallampati I–II, adequate mouth opening, normal neck",
          "Mallampati III–IV or limited mobility",
          "Dentures / loose teeth / beard / other concern"
        ]
      },
      {
        "id": "anesthesia-evaluation-field-27",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "anesthesia-evaluation-field-28",
        "label": "RRR, no murmur, normal S1/S2 Irregular / murmur / other abnormal",
        "type": "select",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "RRR, no murmur, normal S1/S2",
          "Irregular / murmur / other abnormal"
        ]
      },
      {
        "id": "anesthesia-evaluation-field-29",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "anesthesia-evaluation-field-30",
        "label": "Clear bilaterally, no wheeze/rales Wheeze / rales / decreased BS / other",
        "type": "select",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "Clear bilaterally, no wheeze/rales",
          "Wheeze / rales / decreased BS / other"
        ]
      },
      {
        "id": "anesthesia-evaluation-field-31",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "anesthesia-evaluation-field-32",
        "label": "Soft, non-tender, no masses Tender / distended / other N/A (not relevant)",
        "type": "select",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "Soft, non-tender, no masses",
          "Tender / distended / other",
          "N/A (not relevant)"
        ]
      },
      {
        "id": "anesthesia-evaluation-field-33",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "anesthesia-evaluation-field-34",
        "label": "No edema, pulses intact Edema / poor pulses / other",
        "type": "select",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "No edema, pulses intact",
          "Edema / poor pulses / other"
        ]
      },
      {
        "id": "anesthesia-evaluation-field-35",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "anesthesia-evaluation-field-36",
        "label": "Alert, oriented ×3, non-focal Altered / focal deficit / other",
        "type": "select",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "Alert, oriented ×3, non-focal",
          "Altered / focal deficit / other"
        ]
      },
      {
        "id": "anesthesia-evaluation-field-37",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "anesthesia-evaluation-field-38",
        "label": "Key lab / study findings or “WNL”",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "anesthesia-evaluation-field-39",
        "label": "ASA Physical Status Classification Select... ASA I - Healthy ASA II - Mild Systemic ASA III - Severe Systemic ASA IV - Threat to Life",
        "type": "select",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "ASA I - Healthy",
          "ASA II - Mild Systemic",
          "ASA III - Severe Systemic",
          "ASA IV - Threat to Life"
        ]
      },
      {
        "id": "anesthesia-evaluation-field-40",
        "label": "Mallampati Airway Score Select... Class I Class II Class III Class IV",
        "type": "select",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "Class I",
          "Class II",
          "Class III",
          "Class IV"
        ]
      },
      {
        "id": "anesthesia-evaluation-field-41",
        "label": "Thyromental Distance Select... > 6 cm (Normal) < 6 cm (Restricted)",
        "type": "select",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "> 6 cm (Normal)",
          "< 6 cm (Restricted)"
        ]
      },
      {
        "id": "anesthesia-evaluation-field-42",
        "label": "Print Name & Credentials",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "anesthesia-evaluation-field-43",
        "label": "Date",
        "type": "date",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "anesthesia-evaluation-field-44",
        "label": "Time (Military)",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "anesthesia-evaluation-field-45",
        "label": "Print Name & Credentials",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "anesthesia-evaluation-field-46",
        "label": "Current Date",
        "type": "date",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "anesthesia-evaluation-field-47",
        "label": "Immediate Induction Time (Military)",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "anesthesia-evaluation-field-5",
        "label": "No Known Drug Allergies (NKDA)",
        "type": "checkbox",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "No Known Drug Allergies (NKDA)",
          "Penicillin / Beta-lactams",
          "Sulfa",
          "Latex",
          "Iodine / Contrast",
          "Opioids / Codeine",
          "NSAIDs / Aspirin",
          "Local anesthetics",
          "Other (list below)"
        ]
      },
      {
        "id": "anesthesia-evaluation-field-6",
        "label": "Anticoagulant / antiplatelet (list below)",
        "type": "checkbox",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "Anticoagulant / antiplatelet (list below)",
          "Insulin or oral hypoglycemic",
          "GLP-1 agonist (Ozempic, Wegovy, Mounjaro, etc.)",
          "Beta-blocker",
          "ACEI / ARB",
          "Diuretic",
          "Steroids (chronic)",
          "Opioid / benzodiazepine (chronic)",
          "None of the above high-risk classes"
        ]
      },
      {
        "id": "anesthesia-evaluation-field-7",
        "label": "Hypertension",
        "type": "checkbox",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "Hypertension",
          "CAD / Prior MI",
          "Heart failure / CHF",
          "Arrhythmia / AFib",
          "Pacemaker / ICD",
          "Valvular disease",
          "Stroke / TIA",
          "Peripheral vascular disease",
          "Asthma",
          "COPD / Emphysema",
          "Sleep apnea (OSA)",
          "Uses CPAP / BiPAP",
          "Recent URI / pneumonia",
          "Home O2",
          "Tobacco use (current)",
          "Tobacco use (former)",
          "Diabetes mellitus (Type 1)",
          "Diabetes mellitus (Type 2)",
          "Thyroid disorder",
          "Chronic kidney disease",
          "Dialysis",
          "Liver disease / Hepatitis",
          "Obesity (BMI ≥30)",
          "Adrenal disorder",
          "GERD / Severe reflux",
          "Seizure disorder",
          "Bleeding / clotting disorder",
          "History of DVT / PE",
          "Anemia",
          "Cancer (active or history)",
          "Immunosuppression",
          "Psychiatric / anxiety / depression"
        ]
      },
      {
        "id": "anesthesia-evaluation-field-9",
        "label": "No prior surgery",
        "type": "checkbox",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "No prior surgery",
          "Prior difficult intubation / airway",
          "Prior anesthesia complication (PONV, awareness, delayed emergence)",
          "Family history of malignant hyperthermia",
          "Prior transfusion reaction"
        ]
      },
      {
        "id": "anesthesia-evaluation-field-15",
        "label": "Chest pain / angina",
        "type": "checkbox",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "Chest pain / angina",
          "Shortness of breath / DOE",
          "Palpitations / syncope",
          "Orthopedic / joint issues affecting positioning",
          "Recent fever / infection",
          "Unexplained weight loss",
          "Bleeding gums / easy bruising",
          "Pregnancy (or possibility)",
          "None of the above (ROS negative for clearance-relevant items)"
        ]
      },
      {
        "id": "anesthesia-evaluation-field-38",
        "label": "CBC reviewed / normal or acceptable",
        "type": "checkbox",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "CBC reviewed / normal or acceptable",
          "BMP / electrolytes reviewed",
          "Coagulation studies reviewed",
          "ECG reviewed (or not indicated)",
          "Pregnancy test (if applicable) negative",
          "No recent labs available — clinical clearance only"
        ]
      },
      {
        "id": "anesthesia-evaluation-field-42",
        "label": "General Anesthesia",
        "type": "checkbox",
        "required": false,
        "owner": "Practice-defined",
        "source": "Provider",
        "options": [
          "General Anesthesia",
          "LMA",
          "ET Tube",
          "Total Intravenous Anesthesia (TIVA)",
          "MAC / Deep Sedation",
          "Regional / Spinal / Epidural Block",
          "Upon examination, there have been no changes in the patient's condition since the H&P was completed.",
          "This update note reflects changes in the patient's status since the H&P during the first visit of th"
        ]
      },
      {
        "id": "anesthesia-evaluation-siganesstep1",
        "label": "Anesthesiologist Signature",
        "type": "signature",
        "required": true,
        "owner": "Provider",
        "source": "Provider"
      },
      {
        "id": "anesthesia-evaluation-siganesstep2",
        "label": "Anesthesiologist Signature",
        "type": "signature",
        "required": true,
        "owner": "Provider",
        "source": "Provider"
      }
    ],
    "sourceControlCount": 127,
    "signatureZones": 2
  },
  {
    "title": "Anesthesia Intraoperative Record",
    "sourceFile": "Anesthesia_IntraOp_Record.html",
    "group": "Anesthesia",
    "collectionStage": "Anesthesia",
    "reviewStages": [
      "PACU"
    ],
    "fields": [
      {
        "id": "anesthesia-intraop-record-patientname",
        "label": "Patient Name",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Chart"
      },
      {
        "id": "anesthesia-intraop-record-dob",
        "label": "DOB",
        "type": "date",
        "required": false,
        "owner": "Practice-defined",
        "source": "Chart"
      },
      {
        "id": "anesthesia-intraop-record-procdate",
        "label": "Date of Procedure",
        "type": "date",
        "required": false,
        "owner": "Practice-defined",
        "source": "Chart"
      },
      {
        "id": "anesthesia-intraop-record-procedure",
        "label": "Procedure",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Chart"
      },
      {
        "id": "anesthesia-intraop-record-surgeon",
        "label": "Surgeon",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Provider"
      },
      {
        "id": "anesthesia-intraop-record-provider",
        "label": "Anesthesia Provider",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Provider"
      },
      {
        "id": "anesthesia-intraop-record-inor",
        "label": "Patient in OR",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "anesthesia-intraop-record-anesstart",
        "label": "Anesthesia Start",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Provider"
      },
      {
        "id": "anesthesia-intraop-record-surgstart",
        "label": "Surgery Start",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "anesthesia-intraop-record-surgend",
        "label": "Surgery End",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "anesthesia-intraop-record-anesend",
        "label": "Anesthesia End",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Provider"
      },
      {
        "id": "anesthesia-intraop-record-outor",
        "label": "Out of OR / to PACU",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Nursing"
      },
      {
        "id": "anesthesia-intraop-record-asa",
        "label": "ASA Class — I II III IV V E",
        "type": "select",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "—",
          "I",
          "II",
          "III",
          "IV",
          "V",
          "E"
        ]
      },
      {
        "id": "anesthesia-intraop-record-mallampati",
        "label": "Mallampati — I II III IV",
        "type": "select",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "—",
          "I",
          "II",
          "III",
          "IV"
        ]
      },
      {
        "id": "anesthesia-intraop-record-airway",
        "label": "Airway / Device — Select — Mask LMA / Supraglottic Endotracheal tube Nasal cannula / natural airway Other",
        "type": "select",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "Mask",
          "LMA / Supraglottic",
          "Endotracheal tube",
          "Nasal cannula / natural airway",
          "Other"
        ]
      },
      {
        "id": "anesthesia-intraop-record-airwaydetails",
        "label": "ETT / LMA size / details",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "anesthesia-intraop-record-field-17",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "anesthesia-intraop-record-field-18",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "anesthesia-intraop-record-field-19",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "anesthesia-intraop-record-field-20",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "anesthesia-intraop-record-field-21",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "anesthesia-intraop-record-field-22",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "anesthesia-intraop-record-field-23",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "anesthesia-intraop-record-field-24",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "anesthesia-intraop-record-field-25",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "anesthesia-intraop-record-field-26",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "anesthesia-intraop-record-field-27",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "anesthesia-intraop-record-field-28",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "anesthesia-intraop-record-field-29",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "anesthesia-intraop-record-field-30",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "anesthesia-intraop-record-field-31",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "anesthesia-intraop-record-field-32",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "anesthesia-intraop-record-field-33",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "anesthesia-intraop-record-field-34",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "anesthesia-intraop-record-field-35",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "anesthesia-intraop-record-field-36",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "anesthesia-intraop-record-volatilenotes",
        "label": "Volatile / infusion notes",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "anesthesia-intraop-record-ivfluids",
        "label": "IV Fluids (type / total mL)",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "anesthesia-intraop-record-blood",
        "label": "Blood Products",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "anesthesia-intraop-record-ebl",
        "label": "Estimated Blood Loss (mL)",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "anesthesia-intraop-record-uo",
        "label": "Urine Output (mL)",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "anesthesia-intraop-record-otherloss",
        "label": "Other losses",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "anesthesia-intraop-record-field-43",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "anesthesia-intraop-record-field-44",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "anesthesia-intraop-record-field-45",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "anesthesia-intraop-record-field-46",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "anesthesia-intraop-record-field-47",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "anesthesia-intraop-record-field-48",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "anesthesia-intraop-record-field-49",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "anesthesia-intraop-record-field-50",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "anesthesia-intraop-record-field-51",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "anesthesia-intraop-record-field-52",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "anesthesia-intraop-record-field-53",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "anesthesia-intraop-record-field-54",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "anesthesia-intraop-record-field-55",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "anesthesia-intraop-record-field-56",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "anesthesia-intraop-record-field-57",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "anesthesia-intraop-record-field-58",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "anesthesia-intraop-record-field-59",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "anesthesia-intraop-record-field-60",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "anesthesia-intraop-record-field-61",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "anesthesia-intraop-record-field-62",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "anesthesia-intraop-record-field-63",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "anesthesia-intraop-record-eventnotes",
        "label": "Event notes / interventions",
        "type": "textarea",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "anesthesia-intraop-record-disposition",
        "label": "Disposition",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "anesthesia-intraop-record-anesprint",
        "label": "Print Name & Credentials",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "anesthesia-intraop-record-anesdate",
        "label": "Date",
        "type": "date",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "anesthesia-intraop-record-anestime",
        "label": "Time",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "anesthesia-intraop-record-type",
        "label": "General",
        "type": "checkbox",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "General",
          "TIVA",
          "MAC / Sedation",
          "Regional",
          "Spinal",
          "Epidural",
          "Nerve Block",
          "Local only"
        ]
      },
      {
        "id": "anesthesia-intraop-record-airwayeasy",
        "label": "Easy intubation / placement",
        "type": "checkbox",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "Easy intubation / placement"
        ]
      },
      {
        "id": "anesthesia-intraop-record-airwaydiff",
        "label": "Difficult airway",
        "type": "checkbox",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "Difficult airway"
        ]
      },
      {
        "id": "anesthesia-intraop-record-airwayvideo",
        "label": "Video laryngoscope used",
        "type": "checkbox",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "Video laryngoscope used"
        ]
      },
      {
        "id": "anesthesia-intraop-record-airwayfiber",
        "label": "Fiberoptic used",
        "type": "checkbox",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "Fiberoptic used"
        ]
      },
      {
        "id": "anesthesia-intraop-record-event",
        "label": "Uneventful",
        "type": "checkbox",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "Uneventful",
          "Hypotension treated",
          "Hypertension treated",
          "Bradycardia / arrhythmia",
          "Desaturation",
          "Difficult airway",
          "Nausea / vomiting",
          "Other (notes)"
        ]
      },
      {
        "id": "anesthesia-intraop-record-siganesrecord",
        "label": "Anesthesiologist Signature",
        "type": "signature",
        "required": true,
        "owner": "Provider",
        "source": "Provider"
      }
    ],
    "sourceControlCount": 89,
    "signatureZones": 1
  },
  {
    "title": "Anesthesia Questionnaire",
    "sourceFile": "Anesthesia_Questionnaire.html",
    "group": "Patient Intake",
    "collectionStage": "Home / Patient Portal",
    "reviewStages": [
      "Nursing",
      "Anesthesia"
    ],
    "fields": [
      {
        "id": "anesthesia-questionnaire-patientname",
        "label": "Patient Full Name",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "anesthesia-questionnaire-dob",
        "label": "Date of Birth",
        "type": "date",
        "required": false,
        "owner": "Practice-defined",
        "source": "Chart"
      },
      {
        "id": "anesthesia-questionnaire-proceduredate",
        "label": "Scheduled Procedure Date",
        "type": "date",
        "required": false,
        "owner": "Practice-defined",
        "source": "Chart"
      },
      {
        "id": "anesthesia-questionnaire-surgeon",
        "label": "Surgeon",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Provider"
      },
      {
        "id": "anesthesia-questionnaire-priorganotes",
        "label": "If yes — approximate dates / procedures and any problems (nausea, prolonged recovery, difficult wake-up, awareness, etc.)",
        "type": "textarea",
        "required": false,
        "owner": "Practice-defined",
        "source": "Chart"
      },
      {
        "id": "anesthesia-questionnaire-prolongednotes",
        "label": "If yes, describe",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "anesthesia-questionnaire-airwaynotes",
        "label": "Additional airway / dental / neck details",
        "type": "textarea",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "anesthesia-questionnaire-rarerisknotes",
        "label": "If yes to any above, describe (who was affected, what happened)",
        "type": "textarea",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "anesthesia-questionnaire-uriwhen",
        "label": "When did symptoms start / end?",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "anesthesia-questionnaire-urisymptoms",
        "label": "Main symptoms",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "anesthesia-questionnaire-respnotes",
        "label": "If yes, describe",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "anesthesia-questionnaire-cpaptype",
        "label": "Device / settings (if known)",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "anesthesia-questionnaire-cpapbring",
        "label": "Will you bring your device on the day of surgery? — Select — Yes No",
        "type": "select",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "Yes",
          "No"
        ]
      },
      {
        "id": "anesthesia-questionnaire-lastsolid",
        "label": "Time of last solid food",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "anesthesia-questionnaire-lastclear",
        "label": "Time of last clear liquid",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "anesthesia-questionnaire-lastmeds",
        "label": "Time of last oral medications (with sip of water if allowed)",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "anesthesia-questionnaire-btname",
        "label": "Medication name(s)",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "anesthesia-questionnaire-btlastdose",
        "label": "Date & time of last dose",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "anesthesia-questionnaire-glpname",
        "label": "GLP-1 medication name(s)",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "anesthesia-questionnaire-glplastdose",
        "label": "Date & time of last dose",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "anesthesia-questionnaire-specialmednotes",
        "label": "If yes, list name(s) and any day-of-surgery instructions",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "anesthesia-questionnaire-othernotes",
        "label": "Anything else the anesthesia team should know?",
        "type": "textarea",
        "required": false,
        "owner": "Practice-defined",
        "source": "Provider"
      },
      {
        "id": "anesthesia-questionnaire-certprint",
        "label": "Print Name",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "anesthesia-questionnaire-certdate",
        "label": "Date",
        "type": "date",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "anesthesia-questionnaire-certrelation",
        "label": "Relationship (if not patient)",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "anesthesia-questionnaire-priorga",
        "label": "Never",
        "type": "radio",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "Never",
          "Yes"
        ]
      },
      {
        "id": "anesthesia-questionnaire-diffintub",
        "label": "No",
        "type": "radio",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "No",
          "Yes",
          "Unsure"
        ]
      },
      {
        "id": "anesthesia-questionnaire-prolonged",
        "label": "No",
        "type": "radio",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "No",
          "Yes"
        ]
      },
      {
        "id": "anesthesia-questionnaire-ponv",
        "label": "No",
        "type": "radio",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "No",
          "Yes",
          "N/A"
        ]
      },
      {
        "id": "anesthesia-questionnaire-motion",
        "label": "No",
        "type": "radio",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "No",
          "Yes"
        ]
      },
      {
        "id": "anesthesia-questionnaire-airway",
        "label": "Loose, broken, or capped teeth",
        "type": "checkbox",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "Loose, broken, or capped teeth",
          "Dentures, partials, or bridges",
          "Braces or permanent retainers",
          "TMJ problems or limited mouth opening",
          "Limited neck movement / stiff neck",
          "Cervical spine disease, fusion, or instability",
          "Prior tracheostomy or neck surgery",
          "Radiation to head or neck",
          "None of the above"
        ]
      },
      {
        "id": "anesthesia-questionnaire-mobility",
        "label": "Yes",
        "type": "radio",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "Yes",
          "No",
          "Limited"
        ]
      },
      {
        "id": "anesthesia-questionnaire-mh",
        "label": "No",
        "type": "radio",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "No",
          "Yes",
          "Unsure"
        ]
      },
      {
        "id": "anesthesia-questionnaire-pche",
        "label": "No",
        "type": "radio",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "No",
          "Yes",
          "Unsure"
        ]
      },
      {
        "id": "anesthesia-questionnaire-unusualrxn",
        "label": "No",
        "type": "radio",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "No",
          "Yes"
        ]
      },
      {
        "id": "anesthesia-questionnaire-recenturi",
        "label": "No",
        "type": "radio",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "No",
          "Yes"
        ]
      },
      {
        "id": "anesthesia-questionnaire-currentresp",
        "label": "No",
        "type": "radio",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "No",
          "Yes"
        ]
      },
      {
        "id": "anesthesia-questionnaire-cpap",
        "label": "No",
        "type": "radio",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "No",
          "Yes"
        ]
      },
      {
        "id": "anesthesia-questionnaire-asprisk",
        "label": "Active severe heartburn / reflux (especially when lying flat)",
        "type": "checkbox",
        "required": false,
        "owner": "Practice-defined",
        "source": "Nursing",
        "options": [
          "Active severe heartburn / reflux (especially when lying flat)",
          "Known hiatal hernia",
          "Gastroparesis or delayed stomach emptying",
          "Ate or drank after instructed NPO time",
          "None of the above"
        ]
      },
      {
        "id": "anesthesia-questionnaire-bloodthinner",
        "label": "No",
        "type": "radio",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "No",
          "Yes"
        ]
      },
      {
        "id": "anesthesia-questionnaire-btstopped",
        "label": "Yes – stopped as directed",
        "type": "radio",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "Yes",
          "No",
          "Unsure"
        ]
      },
      {
        "id": "anesthesia-questionnaire-glp",
        "label": "No",
        "type": "radio",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "No",
          "Yes"
        ]
      },
      {
        "id": "anesthesia-questionnaire-glpstopped",
        "label": "Yes – stopped as directed",
        "type": "radio",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "Yes",
          "No",
          "Unsure"
        ]
      },
      {
        "id": "anesthesia-questionnaire-specialmed",
        "label": "No",
        "type": "radio",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "No",
          "Yes"
        ]
      },
      {
        "id": "anesthesia-questionnaire-otherconcern",
        "label": "Sleep apnea or told to use CPAP",
        "type": "checkbox",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "Sleep apnea or told to use CPAP",
          "Significant anxiety about anesthesia / needles",
          "Fear of awareness under anesthesia",
          "Chronic pain or high opioid tolerance",
          "Recent recreational drug or alcohol use that may affect anesthesia",
          "None of the above"
        ]
      },
      {
        "id": "anesthesia_questionnaire-signature-1",
        "label": "Patient Signature",
        "type": "signature",
        "required": true,
        "owner": "Patient",
        "source": "Patient"
      }
    ],
    "sourceControlCount": 87,
    "signatureZones": 1
  },
  {
    "title": "Billing & Fee Disclosure",
    "sourceFile": "Billing_Fee_Disclosure.html",
    "group": "Patient Intake",
    "collectionStage": "Home / Patient Portal",
    "reviewStages": [
      "Front Desk"
    ],
    "fields": [
      {
        "id": "billing-fee-disclosure-billingtext",
        "label": "billingText",
        "type": "textarea",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "billing-fee-disclosure-printname",
        "label": "Print Name",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "billing-fee-disclosure-date",
        "label": "Date",
        "type": "date",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "billing_fee_disclosure-signature-1",
        "label": "Patient Signature",
        "type": "signature",
        "required": true,
        "owner": "Patient",
        "source": "Patient"
      }
    ],
    "sourceControlCount": 4,
    "signatureZones": 1
  },
  {
    "title": "Credit Card Authorization",
    "sourceFile": "Credit_Card_Authorization.html",
    "group": "Patient Intake",
    "collectionStage": "Home / Patient Portal",
    "reviewStages": [
      "Front Desk"
    ],
    "fields": [
      {
        "id": "credit-card-authorization-authtext",
        "label": "authText",
        "type": "textarea",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "credit-card-authorization-surgdate",
        "label": "Date of Surgery",
        "type": "date",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "credit-card-authorization-cardname",
        "label": "Cardholder Name",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "credit-card-authorization-cardnumber",
        "label": "Credit Card Number",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "credit-card-authorization-exp",
        "label": "Expiration Date",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "credit-card-authorization-cvv",
        "label": "CVV / Security Code",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "credit-card-authorization-zip",
        "label": "Billing Zip Code",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "credit-card-authorization-field-8",
        "label": "Date",
        "type": "date",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "credit-card-authorization-sigpacurn",
        "label": "RN Signature",
        "type": "signature",
        "required": true,
        "owner": "Nursing",
        "source": "Nursing"
      }
    ],
    "sourceControlCount": 9,
    "signatureZones": 1
  },
  {
    "title": "Day-of-Surgery Interval H&P Update",
    "sourceFile": "DayOf_Interval_HP_Update.html",
    "group": "Surgeon / OR",
    "collectionStage": "Surgeon",
    "reviewStages": [
      "Nursing",
      "Anesthesia"
    ],
    "fields": [
      {
        "id": "dayof-interval-hp-update-patientname",
        "label": "Patient Name",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Chart"
      },
      {
        "id": "dayof-interval-hp-update-dob",
        "label": "DOB",
        "type": "date",
        "required": false,
        "owner": "Practice-defined",
        "source": "Chart"
      },
      {
        "id": "dayof-interval-hp-update-updatewhen",
        "label": "Date / Time of This Update",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "dayof-interval-hp-update-procedure",
        "label": "Planned Procedure",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Chart"
      },
      {
        "id": "dayof-interval-hp-update-orighp",
        "label": "Date of Original H&P (if on file)",
        "type": "date",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "dayof-interval-hp-update-clinician",
        "label": "Surgeon / Clinician",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Provider"
      },
      {
        "id": "dayof-interval-hp-update-changes",
        "label": "New symptoms, illnesses, hospitalizations, or medication changes since last H&P",
        "type": "textarea",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "dayof-interval-hp-update-meds",
        "label": "Current medications confirmed",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "dayof-interval-hp-update-allergies",
        "label": "Allergies confirmed",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "dayof-interval-hp-update-npo",
        "label": "NPO status verified — Select — Compliant Non-compliant — anesthesia notified",
        "type": "select",
        "required": false,
        "owner": "Practice-defined",
        "source": "Provider",
        "options": [
          "Compliant",
          "Non-compliant — anesthesia notified"
        ]
      },
      {
        "id": "dayof-interval-hp-update-preg",
        "label": "Pregnancy status (if applicable) — Select — Not applicable Negative Positive Refused / deferred",
        "type": "select",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "Not applicable",
          "Negative",
          "Positive",
          "Refused / deferred"
        ]
      },
      {
        "id": "dayof-interval-hp-update-general",
        "label": "General / Mental status",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "dayof-interval-hp-update-heart",
        "label": "Heart",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "dayof-interval-hp-update-lungs",
        "label": "Lungs",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "dayof-interval-hp-update-abd",
        "label": "Abdomen / other relevant",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "dayof-interval-hp-update-airway",
        "label": "Airway / Mallampati (if assessed)",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "dayof-interval-hp-update-site",
        "label": "Operative site examination",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "dayof-interval-hp-update-vitals",
        "label": "Vitals (or see nursing admission)",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Nursing"
      },
      {
        "id": "dayof-interval-hp-update-findings",
        "label": "Additional findings",
        "type": "textarea",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "dayof-interval-hp-update-plannotes",
        "label": "Plan notes",
        "type": "textarea",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "dayof-interval-hp-update-printname",
        "label": "Print Name & Credentials",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "dayof-interval-hp-update-sigdate",
        "label": "Date",
        "type": "date",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "dayof-interval-hp-update-sigtime",
        "label": "Time",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "dayof-interval-hp-update-interval",
        "label": "No change in history since prior H&P",
        "type": "checkbox",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "No change in history since prior H&P",
          "Changes documented below"
        ]
      },
      {
        "id": "dayof-interval-hp-update-plan",
        "label": "Patient remains a suitable candidate for the planned procedure and anesthesia",
        "type": "checkbox",
        "required": false,
        "owner": "Practice-defined",
        "source": "Provider",
        "options": [
          "Patient remains a suitable candidate for the planned procedure and anesthesia",
          "No new contraindications identified",
          "Proceed as planned",
          "Defer / modify plan (notes below)"
        ]
      },
      {
        "id": "dayof-interval-hp-update-siginterval",
        "label": "Signature 1",
        "type": "signature",
        "required": true,
        "owner": "Configured signer",
        "source": "Provider"
      }
    ],
    "sourceControlCount": 30,
    "signatureZones": 1
  },
  {
    "title": "Emergency Transfer Form",
    "sourceFile": "Emergency_Transfer_Form.html",
    "group": "Nursing / Recovery",
    "collectionStage": "PACU",
    "reviewStages": [
      "Surgeon"
    ],
    "fields": [
      {
        "id": "emergency-transfer-form-patientname",
        "label": "Patient Name",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Chart"
      },
      {
        "id": "emergency-transfer-form-dob",
        "label": "DOB",
        "type": "date",
        "required": false,
        "owner": "Practice-defined",
        "source": "Chart"
      },
      {
        "id": "emergency-transfer-form-eventdate",
        "label": "Date of Procedure / Event",
        "type": "date",
        "required": false,
        "owner": "Practice-defined",
        "source": "Chart"
      },
      {
        "id": "emergency-transfer-form-decisiontime",
        "label": "Time Decision to Transfer",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "emergency-transfer-form-procedure",
        "label": "Procedure (if started / completed)",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Chart"
      },
      {
        "id": "emergency-transfer-form-surgeon",
        "label": "Surgeon",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Provider"
      },
      {
        "id": "emergency-transfer-form-reasonnarrative",
        "label": "Clinical summary / reason (narrative)",
        "type": "textarea",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "emergency-transfer-form-condition",
        "label": "Current condition / vital signs at transfer",
        "type": "textarea",
        "required": false,
        "owner": "Practice-defined",
        "source": "Nursing"
      },
      {
        "id": "emergency-transfer-form-hospital",
        "label": "Receiving hospital / facility",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "emergency-transfer-form-recvmd",
        "label": "Receiving physician / service",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Provider"
      },
      {
        "id": "emergency-transfer-form-transport",
        "label": "Mode of transport — Select — Ambulance (ALS) Ambulance (BLS) Private vehicle (not preferred) Other",
        "type": "select",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "Ambulance (ALS)",
          "Ambulance (BLS)",
          "Private vehicle (not preferred)",
          "Other"
        ]
      },
      {
        "id": "emergency-transfer-form-transporttime",
        "label": "Time transport contacted / arrived",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "emergency-transfer-form-reportto",
        "label": "Report given to (name / role at receiving facility)",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "emergency-transfer-form-familynotified",
        "label": "Family / responsible party notified",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "emergency-transfer-form-departtime",
        "label": "Date / Time of departure",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "emergency-transfer-form-reason",
        "label": "Medical instability / complication",
        "type": "checkbox",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "Medical instability / complication",
          "Need for higher level of care",
          "Unexpected finding requiring hospital care",
          "Anesthesia-related event",
          "Other"
        ]
      },
      {
        "id": "emergency-transfer-form-sent",
        "label": "Face sheet / demographics",
        "type": "checkbox",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "Face sheet / demographics",
          "Consents",
          "H&P / pre-op notes",
          "Anesthesia / intra-op records",
          "Labs / imaging",
          "Medication list",
          "Copy of this transfer form"
        ]
      },
      {
        "id": "emergency-transfer-form-sigtransfermd",
        "label": "Physician Signature",
        "type": "signature",
        "required": true,
        "owner": "Provider",
        "source": "Provider"
      },
      {
        "id": "emergency-transfer-form-sigtransferrn",
        "label": "RN Signature",
        "type": "signature",
        "required": true,
        "owner": "Nursing",
        "source": "Nursing"
      }
    ],
    "sourceControlCount": 29,
    "signatureZones": 2
  },
  {
    "title": "Insurance Information",
    "sourceFile": "Insurance_Information.html",
    "group": "Patient Intake",
    "collectionStage": "Home / Patient Portal",
    "reviewStages": [
      "Front Desk"
    ],
    "fields": [
      {
        "id": "insurance-information-patientname",
        "label": "Patient Full Name",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "insurance-information-dob",
        "label": "Date of Birth",
        "type": "date",
        "required": false,
        "owner": "Practice-defined",
        "source": "Chart"
      },
      {
        "id": "insurance-information-inscompany",
        "label": "Insurance Company",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "insurance-information-memberid",
        "label": "Member / Subscriber ID",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "insurance-information-groupnumber",
        "label": "Group Number",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "insurance-information-planname",
        "label": "Plan Name / Type (if known)",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "insurance-information-holdername",
        "label": "Policy Holder Name (if not patient)",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "insurance-information-holderdob",
        "label": "Policy Holder Date of Birth",
        "type": "date",
        "required": false,
        "owner": "Practice-defined",
        "source": "Chart"
      },
      {
        "id": "insurance-information-holderrelation",
        "label": "Relationship to Patient",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "insurance-information-seccompany",
        "label": "Insurance Company",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "insurance-information-secmemberid",
        "label": "Member / Subscriber ID",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "insurance-information-secgroup",
        "label": "Group Number",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "insurance-information-cardfront",
        "label": "Front of Card",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "insurance-information-cardback",
        "label": "Back of Card",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "insurance-information-seccardfront",
        "label": "Secondary – Front (optional)",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "insurance-information-seccardback",
        "label": "Secondary – Back (optional)",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "insurance-information-sigdate",
        "label": "Date",
        "type": "date",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "insurance-information-isholder",
        "label": "Yes",
        "type": "radio",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "Yes",
          "No"
        ]
      },
      {
        "id": "insurance_information-signature-1",
        "label": "Patient Signature",
        "type": "signature",
        "required": true,
        "owner": "Patient",
        "source": "Patient"
      }
    ],
    "sourceControlCount": 20,
    "signatureZones": 1
  },
  {
    "title": "Intraoperative Nursing Record / Time-Out",
    "sourceFile": "IntraOp_Nursing_Record_TO.html",
    "group": "Surgeon / OR",
    "collectionStage": "OR Team",
    "reviewStages": [
      "PACU"
    ],
    "fields": [
      {
        "id": "intraop-nursing-record-to-field-1",
        "label": "Patient Full Name",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "intraop-nursing-record-to-field-2",
        "label": "Date of Birth",
        "type": "date",
        "required": false,
        "owner": "Practice-defined",
        "source": "Chart"
      },
      {
        "id": "intraop-nursing-record-to-field-3",
        "label": "MRN / Chart #",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Nursing"
      },
      {
        "id": "intraop-nursing-record-to-field-4",
        "label": "Pre-Operative Diagnosis / Procedure Planned",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Chart"
      },
      {
        "id": "intraop-nursing-record-to-field-5",
        "label": "Post-Operative Diagnosis / Procedure Performed",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Chart"
      },
      {
        "id": "intraop-nursing-record-to-field-6",
        "label": "Surgical Procedure(s) Performed (detailed)",
        "type": "textarea",
        "required": false,
        "owner": "Practice-defined",
        "source": "Chart"
      },
      {
        "id": "intraop-nursing-record-to-field-7",
        "label": "Time-Out Execution Time (Military)",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "intraop-nursing-record-to-field-8",
        "label": "Antibiotic Agent Name",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "intraop-nursing-record-to-field-9",
        "label": "Antibiotic Infusion Time",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "intraop-nursing-record-to-field-10",
        "label": "Surgeon",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Provider"
      },
      {
        "id": "intraop-nursing-record-to-field-11",
        "label": "Assistant Surgeon",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Provider"
      },
      {
        "id": "intraop-nursing-record-to-field-12",
        "label": "Anesthesiologist / CRNA",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Nursing"
      },
      {
        "id": "intraop-nursing-record-to-field-13",
        "label": "Scrub Nurse / Tech",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Nursing"
      },
      {
        "id": "intraop-nursing-record-to-field-14",
        "label": "OR Circulating Nurse",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Nursing"
      },
      {
        "id": "intraop-nursing-record-to-field-15",
        "label": "X-ray Technician",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "intraop-nursing-record-to-field-16",
        "label": "Laser Technician",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "intraop-nursing-record-to-field-17",
        "label": "Other Personnel",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "intraop-nursing-record-to-field-18",
        "label": "Allergy details (if any)",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "intraop-nursing-record-to-field-19",
        "label": "Notable medication comments",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "intraop-nursing-record-to-field-20",
        "label": "Patient in Room",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "intraop-nursing-record-to-field-21",
        "label": "Anesthesia Start",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Provider"
      },
      {
        "id": "intraop-nursing-record-to-field-22",
        "label": "Surgery Start (Incision)",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "intraop-nursing-record-to-field-23",
        "label": "Surgery Stop (Close)",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "intraop-nursing-record-to-field-24",
        "label": "OR Out / Transfer Out",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "intraop-nursing-record-to-field-25",
        "label": "Date of Procedure",
        "type": "date",
        "required": false,
        "owner": "Practice-defined",
        "source": "Chart"
      },
      {
        "id": "intraop-nursing-record-to-field-26",
        "label": "ASA Classification Select... ASA I ASA II ASA III ASA IV ASA V ASA VI",
        "type": "select",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "ASA I",
          "ASA II",
          "ASA III",
          "ASA IV",
          "ASA V",
          "ASA VI"
        ]
      },
      {
        "id": "intraop-nursing-record-to-field-27",
        "label": "Additional anesthesia notes (if needed)",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Provider"
      },
      {
        "id": "intraop-nursing-record-to-field-28",
        "label": "Location(s) and description of findings",
        "type": "textarea",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "intraop-nursing-record-to-field-29",
        "label": "Select... Right upper arm Left upper arm Right forearm Left forearm Thigh Other / N/A",
        "type": "select",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "Right upper arm",
          "Left upper arm",
          "Right forearm",
          "Left forearm",
          "Thigh",
          "Other / N/A"
        ]
      },
      {
        "id": "intraop-nursing-record-to-field-30",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "intraop-nursing-record-to-field-31",
        "label": "Select... Right finger Left finger Toe Earlobe Other / N/A",
        "type": "select",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "Right finger",
          "Left finger",
          "Toe",
          "Earlobe",
          "Other / N/A"
        ]
      },
      {
        "id": "intraop-nursing-record-to-field-32",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "intraop-nursing-record-to-field-33",
        "label": "Select... Right hand / forearm Left hand / forearm Right antecubital Left antecubital Other / central N/A",
        "type": "select",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "Right hand / forearm",
          "Left hand / forearm",
          "Right antecubital",
          "Left antecubital",
          "Other / central",
          "N/A"
        ]
      },
      {
        "id": "intraop-nursing-record-to-field-34",
        "label": "Gauge / site notes",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "intraop-nursing-record-to-field-35",
        "label": "Select... Right thigh Left thigh Right buttock Left buttock Back / other N/A (bipolar only / not used)",
        "type": "select",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "Right thigh",
          "Left thigh",
          "Right buttock",
          "Left buttock",
          "Back / other",
          "N/A (bipolar only / not used)"
        ]
      },
      {
        "id": "intraop-nursing-record-to-field-36",
        "label": "Serial / lot if required",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "intraop-nursing-record-to-field-37",
        "label": "Select... Right upper extremity Left upper extremity Right lower extremity Left lower extremity Bilateral N/A",
        "type": "select",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "Right upper extremity",
          "Left upper extremity",
          "Right lower extremity",
          "Left lower extremity",
          "Bilateral",
          "N/A"
        ]
      },
      {
        "id": "intraop-nursing-record-to-field-38",
        "label": "Pressure / time if documented here",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "intraop-nursing-record-to-field-39",
        "label": "Select... Bilateral lower extremities Right only Left only N/A",
        "type": "select",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "Bilateral lower extremities",
          "Right only",
          "Left only",
          "N/A"
        ]
      },
      {
        "id": "intraop-nursing-record-to-field-40",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "intraop-nursing-record-to-field-41",
        "label": "Select... Bilateral Right only Left only N/A",
        "type": "select",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "Bilateral",
          "Right only",
          "Left only",
          "N/A"
        ]
      },
      {
        "id": "intraop-nursing-record-to-field-42",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "intraop-nursing-record-to-field-43",
        "label": "Select... Both legs in stirrups Right only Left only Yellowfin / Allen / other brand N/A",
        "type": "select",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "Both legs in stirrups",
          "Right only",
          "Left only",
          "Yellowfin / Allen / other brand",
          "N/A"
        ]
      },
      {
        "id": "intraop-nursing-record-to-field-44",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "intraop-nursing-record-to-field-45",
        "label": "Patient Position Select... Supine Prone Lateral (right side up) Lateral (left side up) Lithotomy Beach chair / semi-sitting Trendelenburg Reverse Trendelenburg Other (note)",
        "type": "select",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "Supine",
          "Prone",
          "Lateral (right side up)",
          "Lateral (left side up)",
          "Lithotomy",
          "Beach chair / semi-sitting",
          "Trendelenburg",
          "Reverse Trendelenburg",
          "Other (note)"
        ]
      },
      {
        "id": "intraop-nursing-record-to-field-46",
        "label": "Positioning aids / technique notes",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "intraop-nursing-record-to-field-47",
        "label": "Prep Solution Select... Chlorhexidine (CHG) — e.g., ChloraPrep Povidone-iodine (Betadine) Alcohol-based Other / combination None / N/A",
        "type": "select",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "Chlorhexidine (CHG) — e.g., ChloraPrep",
          "Povidone-iodine (Betadine)",
          "Alcohol-based",
          "Other / combination",
          "None / N/A"
        ]
      },
      {
        "id": "intraop-nursing-record-to-field-48",
        "label": "Prep area / laterality",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "intraop-nursing-record-to-field-49",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "intraop-nursing-record-to-field-50",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "intraop-nursing-record-to-field-51",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "intraop-nursing-record-to-field-52",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "intraop-nursing-record-to-field-53",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "intraop-nursing-record-to-field-54",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "intraop-nursing-record-to-field-55",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "intraop-nursing-record-to-field-56",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "intraop-nursing-record-to-field-57",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "intraop-nursing-record-to-field-58",
        "label": "Specimen / culture details (type, site, number of containers, labels verified)",
        "type": "textarea",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "intraop-nursing-record-to-field-59",
        "label": "Estimated Blood Loss (EBL)",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "intraop-nursing-record-to-field-60",
        "label": "Wound Classification Select... Class I — Clean Class II — Clean-Contaminated Class III — Contaminated Class IV — Dirty / Infected",
        "type": "select",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "Class I — Clean",
          "Class II — Clean-Contaminated",
          "Class III — Contaminated",
          "Class IV — Dirty / Infected"
        ]
      },
      {
        "id": "intraop-nursing-record-to-field-61",
        "label": "Wound / closure notes (optional)",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "intraop-nursing-record-to-field-62",
        "label": "Receiving PACU Nurse Name",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Nursing"
      },
      {
        "id": "intraop-nursing-record-to-field-63",
        "label": "Hand-Off / Transfer Time",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "intraop-nursing-record-to-field-64",
        "label": "Intra-operative nursing notes (events, communications, exceptions, or other relevant information)",
        "type": "textarea",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "intraop-nursing-record-to-field-65",
        "label": "Date",
        "type": "date",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "intraop-nursing-record-to-field-66",
        "label": "OR Out Time (Military)",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "intraop-nursing-record-to-field-7",
        "label": "Patient Identity Confirmed (Dual Identifiers Checked)",
        "type": "checkbox",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "Patient Identity Confirmed (Dual Identifiers Checked)",
          "Correct Surgical Site & Laterality Confirmed",
          "Correct Planned Procedure Verbally Verified",
          "Correct Implants / Hardware / Equipment Present",
          "Pre-Operative Antibiotic Prophylaxis Administered",
          "Fire Risk Assessment Completed & Mitigated"
        ]
      },
      {
        "id": "intraop-nursing-record-to-field-18",
        "label": "NKDA",
        "type": "checkbox",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "NKDA",
          "Allergies listed on chart / band reviewed",
          "Allergy band applied / verified"
        ]
      },
      {
        "id": "intraop-nursing-record-to-field-19",
        "label": "Medication list reviewed with patient / chart",
        "type": "checkbox",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "Medication list reviewed with patient / chart",
          "High-risk meds noted (anticoagulants, GLP-1, insulin, etc.)",
          "See Anesthesia Record for intra-op meds"
        ]
      },
      {
        "id": "intraop-nursing-record-to-field-20",
        "label": "Verbal (patient stated name & DOB)",
        "type": "checkbox",
        "required": false,
        "owner": "Practice-defined",
        "source": "Chart",
        "options": [
          "Verbal (patient stated name & DOB)",
          "Chart / schedule verified",
          "ID band checked (name & DOB)",
          "Photo ID (if used)",
          "Family / representative confirmed (if patient unable)"
        ]
      },
      {
        "id": "intraop-nursing-record-to-field-27",
        "label": "Self (independent)",
        "type": "checkbox",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "Self (independent)",
          "Assisted (partial assist)",
          "Full assist / lift",
          "With assistive device (slider, board, etc.)",
          "Stretcher to table (lateral transfer)",
          "General",
          "TIVA",
          "MAC / Deep Sedation",
          "Regional / Spinal / Epidural",
          "Local only",
          "Combined (specify in notes)",
          "Anesthesia agents / medications — See Anesthesia Record"
        ]
      },
      {
        "id": "intraop-nursing-record-to-field-28",
        "label": "No pre-existing skin breakdown, bruises, cuts, or abrasions noted",
        "type": "checkbox",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "No pre-existing skin breakdown, bruises, cuts, or abrasions noted",
          "Bruises present",
          "Cuts / lacerations present",
          "Abrasions present",
          "Pressure areas / redness",
          "Other injury / lesion"
        ]
      },
      {
        "id": "intraop-nursing-record-to-field-49",
        "label": "Hair clipped (if applicable) — clippers used, not razor",
        "type": "checkbox",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "Hair clipped (if applicable) — clippers used, not razor",
          "Prep allowed to dry per manufacturer instructions"
        ]
      },
      {
        "id": "intraop-nursing-record-to-field-52",
        "label": "Correct",
        "type": "checkbox",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "Correct"
        ]
      },
      {
        "id": "intraop-nursing-record-to-field-55",
        "label": "Correct",
        "type": "checkbox",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "Correct"
        ]
      },
      {
        "id": "intraop-nursing-record-to-field-58",
        "label": "Correct",
        "type": "checkbox",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "Correct",
          "No specimens sent",
          "Pathology specimen(s) sent",
          "Culture(s) sent",
          "Frozen section",
          "Other lab / cytology"
        ]
      },
      {
        "id": "intraop-nursing-record-to-field-62",
        "label": "Patient awake, stable, and taken to PACU",
        "type": "checkbox",
        "required": false,
        "owner": "Practice-defined",
        "source": "Nursing",
        "options": [
          "Patient awake, stable, and taken to PACU"
        ]
      },
      {
        "id": "intraop-nursing-record-to-field-64",
        "label": "Verbal hand-off completed and acknowledged by PACU nurse",
        "type": "checkbox",
        "required": false,
        "owner": "Practice-defined",
        "source": "Nursing",
        "options": [
          "Verbal hand-off completed and acknowledged by PACU nurse",
          "Chart, consents, and specimens transferred with patient"
        ]
      },
      {
        "id": "intraop-nursing-record-to-sigcircrn",
        "label": "RN Signature",
        "type": "signature",
        "required": true,
        "owner": "Nursing",
        "source": "Nursing"
      }
    ],
    "sourceControlCount": 115,
    "signatureZones": 1
  },
  {
    "title": "Medical History & VTE Assessment",
    "sourceFile": "MH_and_VTE_Assessment.html",
    "group": "Patient Intake",
    "collectionStage": "Home / Patient Portal",
    "reviewStages": [
      "Nursing",
      "Surgeon"
    ],
    "fields": [
      {
        "id": "mh-and-vte-assessment-patientname",
        "label": "Patient Name",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Chart"
      },
      {
        "id": "mh-and-vte-assessment-date",
        "label": "Date",
        "type": "date",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "mh-and-vte-assessment-caffeine",
        "label": "How many caffeinated beverages do you consume daily?",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "mh-and-vte-assessment-mh-family-explain",
        "label": "Have any blood relatives had problems with anesthesia? If Yes, explain",
        "type": "textarea",
        "required": false,
        "owner": "Practice-defined",
        "source": "Provider"
      },
      {
        "id": "mh-and-vte-assessment-mh-muscle-explain",
        "label": "Do you have a muscle or neuromuscular disorder? If Yes, explain",
        "type": "textarea",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "mh-and-vte-assessment-totalscore",
        "label": "TOTAL SCORE",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "mh-and-vte-assessment-sigdate",
        "label": "Date",
        "type": "date",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "mh-and-vte-assessment-mh-cramp",
        "label": "Unexplained Muscle Cramping or Spasms",
        "type": "radio",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "Yes",
          "No"
        ]
      },
      {
        "id": "mh-and-vte-assessment-mh-sweat",
        "label": "Excessive Sweating",
        "type": "radio",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "Yes",
          "No"
        ]
      },
      {
        "id": "mh-and-vte-assessment-mh-night",
        "label": "Night Sweats",
        "type": "radio",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "Yes",
          "No"
        ]
      },
      {
        "id": "mh-and-vte-assessment-mh-fatigue",
        "label": "Fatigue",
        "type": "radio",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "Yes",
          "No"
        ]
      },
      {
        "id": "mh-and-vte-assessment-mh-nausea",
        "label": "Nausea or Motion Sickness",
        "type": "radio",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "Yes",
          "No"
        ]
      },
      {
        "id": "mh-and-vte-assessment-mh-dizzy",
        "label": "Dizziness",
        "type": "radio",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "Yes",
          "No"
        ]
      },
      {
        "id": "mh-and-vte-assessment-mh-thirst",
        "label": "Excessive Thirst",
        "type": "radio",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "Yes",
          "No"
        ]
      },
      {
        "id": "mh-and-vte-assessment-mh-headache",
        "label": "Headaches",
        "type": "radio",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "Yes",
          "No"
        ]
      },
      {
        "id": "mh-and-vte-assessment-mh-heatstroke",
        "label": "Heatstroke",
        "type": "radio",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "Yes",
          "No"
        ]
      },
      {
        "id": "mh-and-vte-assessment-mh-heatintol",
        "label": "Heat Intolerance",
        "type": "radio",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "Yes",
          "No"
        ]
      },
      {
        "id": "mh-and-vte-assessment-mh-bp",
        "label": "Elevated Blood Pressure",
        "type": "radio",
        "required": false,
        "owner": "Practice-defined",
        "source": "Nursing",
        "options": [
          "Yes",
          "No"
        ]
      },
      {
        "id": "mh-and-vte-assessment-mh-thyroid",
        "label": "Hypothyroidism",
        "type": "radio",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "Yes",
          "No"
        ]
      },
      {
        "id": "mh-and-vte-assessment-mh-fever",
        "label": "Fevers following exercise or anesthesia",
        "type": "radio",
        "required": false,
        "owner": "Practice-defined",
        "source": "Provider",
        "options": [
          "Yes",
          "No"
        ]
      },
      {
        "id": "mh-and-vte-assessment-mh-urine",
        "label": "Dark (Chocolate) Colored Urine",
        "type": "radio",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "Yes",
          "No"
        ]
      },
      {
        "id": "mh-and-vte-assessment-vte5",
        "label": "Recent elective hip or knee joint replacement surgery",
        "type": "checkbox",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "Recent elective hip or knee joint replacement surgery",
          "Broken hip, pelvis, or leg within the last month",
          "Serious trauma within the last month",
          "Spinal cord injury with paralysis within the last month"
        ]
      },
      {
        "id": "mh-and-vte-assessment-vte3",
        "label": "Age 75 or over",
        "type": "checkbox",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "Age 75 or over",
          "History of blood clots",
          "Family history of blood clots",
          "Family history of blood-clotting disorders"
        ]
      },
      {
        "id": "mh-and-vte-assessment-vte2",
        "label": "Age 60–74 years",
        "type": "checkbox",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "Age 60–74 years",
          "Cancer (current or previous)",
          "Recently had major surgery longer than 45 minutes",
          "Recent laparoscopic surgery longer than 45 minutes",
          "Plaster cast limiting limb movement within last month",
          "Central venous access"
        ]
      },
      {
        "id": "mh-and-vte-assessment-vte1",
        "label": "Birth control or Hormone Replacement Therapy",
        "type": "checkbox",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "Birth control or Hormone Replacement Therapy",
          "Pregnant or had a baby within the last month",
          "Age 41–60 years",
          "Planning minor surgery in the near future",
          "Had major surgery within the past month",
          "Serious infection (e.g., pneumonia)",
          "Lung disease (emphysema / COPD)",
          "Varicose veins",
          "Inflammatory Bowel Disease (Crohn’s, UC)",
          "Legs currently swollen",
          "Overweight or obese",
          "Heart attack",
          "History of Congestive Heart Failure",
          "Current bed rest or severely restricted mobility"
        ]
      },
      {
        "id": "mh_and_vte_assessment-signature-1",
        "label": "Patient Signature",
        "type": "signature",
        "required": true,
        "owner": "Patient",
        "source": "Patient"
      }
    ],
    "sourceControlCount": 67,
    "signatureZones": 1
  },
  {
    "title": "Medical History",
    "sourceFile": "Medical_History.html",
    "group": "Patient Intake",
    "collectionStage": "Home / Patient Portal",
    "reviewStages": [
      "Front Desk",
      "Nursing",
      "Anesthesia"
    ],
    "fields": [
      {
        "id": "medical-history-field-1",
        "label": "Patient Full Name",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "medical-history-field-2",
        "label": "Date of Birth",
        "type": "date",
        "required": false,
        "owner": "Practice-defined",
        "source": "Chart"
      },
      {
        "id": "medical-history-field-3",
        "label": "Medical Record # (MRN)",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Nursing"
      },
      {
        "id": "medical-history-field-4",
        "label": "Scheduled Surgery Date",
        "type": "date",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "medical-history-field-5",
        "label": "Operating Surgeon",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Provider"
      },
      {
        "id": "medical-history-field-6",
        "label": "Proposed Procedure",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Chart"
      },
      {
        "id": "medical-history-field-7",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "medical-history-field-8",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "medical-history-field-9",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "medical-history-field-10",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "medical-history-field-11",
        "label": "Other Drug/Food/Environmental",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "medical-history-field-12",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "medical-history-field-13",
        "label": "Other Drug/Food/Environmental",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "medical-history-field-14",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "medical-history-field-15",
        "label": "Additional PMH / details",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "medical-history-field-16",
        "label": "e.g., Ozempic / Wegovy (GLP-1)",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "medical-history-field-17",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "medical-history-field-18",
        "label": "Field",
        "type": "date",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "medical-history-field-19",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "medical-history-field-20",
        "label": "e.g., Coumadin / Eliquis (Anticoagulant)",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "medical-history-field-21",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "medical-history-field-22",
        "label": "Field",
        "type": "date",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "medical-history-field-23",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "medical-history-field-24",
        "label": "e.g., Insulin / Metformin",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "medical-history-field-25",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "medical-history-field-26",
        "label": "Field",
        "type": "date",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "medical-history-field-27",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "medical-history-field-28",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "medical-history-field-29",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "medical-history-field-30",
        "label": "Field",
        "type": "date",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "medical-history-field-31",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "medical-history-field-32",
        "label": "List Previous Surgeries & Operations (with approximate dates)",
        "type": "textarea",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "medical-history-field-33",
        "label": "Designated Responsible Adult Escort/Driver Name",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "medical-history-field-34",
        "label": "Primary Contact Phone Number during Surgery",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "medical-history-field-35",
        "label": "Print Name",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "medical-history-field-36",
        "label": "Date",
        "type": "date",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "medical-history-field-37",
        "label": "Time (Military)",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "medical-history-field-7",
        "label": "No Known Drug Allergies (NKDA)",
        "type": "checkbox",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "No Known Drug Allergies (NKDA)"
        ]
      },
      {
        "id": "medical-history-field-15",
        "label": "Hypertension",
        "type": "checkbox",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "Hypertension",
          "Coronary Artery Disease",
          "Pacemaker / AICD",
          "Stroke / TIA",
          "Asthma / COPD",
          "Sleep Apnea (OSA)",
          "Uses CPAP at Home",
          "Recent Upper Resp Infection",
          "Diabetes Mellitus",
          "Thyroid Disorder",
          "Renal / Kidney Disease",
          "Liver Disease / Hepatitis",
          "Severe Acid Reflux / GERD",
          "Seizure Disorder",
          "Bleeding / Clotting Disorder",
          "History of DVT / PE"
        ]
      },
      {
        "id": "medical-history-field-33",
        "label": "Personal history of anesthesia complications (Severe Nausea, Intubation trauma)",
        "type": "checkbox",
        "required": false,
        "owner": "Practice-defined",
        "source": "Provider",
        "options": [
          "Personal history of anesthesia complications (Severe Nausea, Intubation trauma)",
          "Blood relatives with history of Malignant Hyperthermia (Anesthesia high-fever crisis)"
        ]
      },
      {
        "id": "medical-history-sighistreview",
        "label": "Signature 1",
        "type": "signature",
        "required": true,
        "owner": "Configured signer",
        "source": "Provider"
      }
    ],
    "sourceControlCount": 57,
    "signatureZones": 1
  },
  {
    "title": "Nursing Admission",
    "sourceFile": "Nursing_Admission.html",
    "group": "Nursing / Recovery",
    "collectionStage": "Nursing",
    "reviewStages": [
      "Anesthesia"
    ],
    "fields": [
      {
        "id": "nursing-admission-field-1",
        "label": "Patient Full Name",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "nursing-admission-field-2",
        "label": "Date of Birth",
        "type": "date",
        "required": false,
        "owner": "Practice-defined",
        "source": "Chart"
      },
      {
        "id": "nursing-admission-field-3",
        "label": "MRN / Chart #",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Nursing"
      },
      {
        "id": "nursing-admission-field-4",
        "label": "Surgeon",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Provider"
      },
      {
        "id": "nursing-admission-field-5",
        "label": "Anesthesiologist / CRNA",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Nursing"
      },
      {
        "id": "nursing-admission-field-6",
        "label": "Planned Procedure",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Chart"
      },
      {
        "id": "nursing-admission-field-7",
        "label": "Admission Date",
        "type": "date",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "nursing-admission-field-8",
        "label": "Arrival Time (24 hr)",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "nursing-admission-field-9",
        "label": "Location / Unit",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "nursing-admission-field-10",
        "label": "Verbalized Allergies & Reaction Types",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "nursing-admission-field-11",
        "label": "Responsible Adult Discharge Driver",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "nursing-admission-field-12",
        "label": "Last Solid Food Intake",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "nursing-admission-field-13",
        "label": "Last Clear Liquid Intake",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "nursing-admission-field-14",
        "label": "NPO Status Compliance — Select — COMPLIANT (met standard fasting guidelines) NON-COMPLIANT (anesthesia notified)",
        "type": "select",
        "required": false,
        "owner": "Practice-defined",
        "source": "Provider",
        "options": [
          "COMPLIANT (met standard fasting guidelines)",
          "NON-COMPLIANT (anesthesia notified)"
        ]
      },
      {
        "id": "nursing-admission-field-15",
        "label": "Height",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "nursing-admission-field-16",
        "label": "Weight",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "nursing-admission-field-17",
        "label": "Isolation Precautions None Contact Droplet Airborne",
        "type": "select",
        "required": false,
        "owner": "Practice-defined",
        "source": "Nursing",
        "options": [
          "None",
          "Contact",
          "Droplet",
          "Airborne"
        ]
      },
      {
        "id": "nursing-admission-field-18",
        "label": "Urine hCG Screening Not Applicable Negative Positive Refused",
        "type": "select",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "Not Applicable",
          "Negative",
          "Positive",
          "Refused"
        ]
      },
      {
        "id": "nursing-admission-field-19",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "nursing-admission-field-20",
        "label": "122/78",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "nursing-admission-field-21",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "nursing-admission-field-22",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "nursing-admission-field-23",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "nursing-admission-field-24",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "nursing-admission-field-25",
        "label": "Room Air Nasal Cannula",
        "type": "select",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "Room Air",
          "Nasal Cannula"
        ]
      },
      {
        "id": "nursing-admission-field-26",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "nursing-admission-field-27",
        "label": "Urine / Blood hCG Pregnancy Test Select... Negative Positive Not Applicable (Post-Menopausal/Surgical)",
        "type": "select",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "Negative",
          "Positive",
          "Not Applicable (Post-Menopausal/Surgical)"
        ]
      },
      {
        "id": "nursing-admission-field-28",
        "label": "Pre-Op Blood Glucose Level",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "nursing-admission-field-29",
        "label": "Potassium / CBC Status (If ordered)",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "nursing-admission-field-30",
        "label": "Alert & Oriented Confused Lethargic",
        "type": "select",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "Alert & Oriented",
          "Confused",
          "Lethargic"
        ]
      },
      {
        "id": "nursing-admission-field-31",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "nursing-admission-field-32",
        "label": "Regular Rhythm Irregular Rhythm",
        "type": "select",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "Regular Rhythm",
          "Irregular Rhythm"
        ]
      },
      {
        "id": "nursing-admission-field-33",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "nursing-admission-field-34",
        "label": "Unlabored Dyspnea Wheezing/Cough",
        "type": "select",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "Unlabored",
          "Dyspnea",
          "Wheezing/Cough"
        ]
      },
      {
        "id": "nursing-admission-field-35",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "nursing-admission-field-36",
        "label": "Normal / WNL Nausea Present",
        "type": "select",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "Normal / WNL",
          "Nausea Present"
        ]
      },
      {
        "id": "nursing-admission-field-37",
        "label": "Voided pre-op time: ____",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "nursing-admission-field-38",
        "label": "Skin Intact Lesions/Rash",
        "type": "select",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "Skin Intact",
          "Lesions/Rash"
        ]
      },
      {
        "id": "nursing-admission-field-39",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "nursing-admission-field-40",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "nursing-admission-field-41",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "nursing-admission-field-42",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "nursing-admission-field-43",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "nursing-admission-field-44",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "nursing-admission-field-45",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "nursing-admission-field-46",
        "label": "Ordering Physician",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Provider"
      },
      {
        "id": "nursing-admission-field-47",
        "label": "RN Name",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Nursing"
      },
      {
        "id": "nursing-admission-field-48",
        "label": "Date",
        "type": "date",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "nursing-admission-field-49",
        "label": "Time (24 hr)",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "nursing-admission-field-50",
        "label": "RN Name",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Nursing"
      },
      {
        "id": "nursing-admission-field-51",
        "label": "Date Received",
        "type": "date",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "nursing-admission-field-52",
        "label": "Time of Transfer",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "nursing-admission-field-10",
        "label": "ID Band Applied & Verified — spelling and DOB against patient verbal statement",
        "type": "checkbox",
        "required": false,
        "owner": "Practice-defined",
        "source": "Chart",
        "options": [
          "ID Band Applied & Verified — spelling and DOB against patient verbal statement",
          "Allergy Band Applied (red band if allergies exist)"
        ]
      },
      {
        "id": "nursing-admission-field-30",
        "label": "Contact Lenses / Glasses Removed",
        "type": "checkbox",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "Contact Lenses / Glasses Removed",
          "Dentures / Removable Dental Work Removed",
          "Jewelry / Body Piercings Removed",
          "Voided / Foley Catheter Output Checked Before Transfer"
        ]
      },
      {
        "id": "nursing-admission-field-40",
        "label": "Anticoagulants / antiplatelets verified held for recommended window",
        "type": "checkbox",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "Anticoagulants / antiplatelets verified held for recommended window",
          "GLP-1 agonists verified held appropriately for general anesthesia risk"
        ]
      },
      {
        "id": "nursing-admission-field-46",
        "label": "Patient Identity Verified (Dual Band: Name & DOB)",
        "type": "checkbox",
        "required": false,
        "owner": "Practice-defined",
        "source": "Chart",
        "options": [
          "Patient Identity Verified (Dual Band: Name & DOB)",
          "Consents Completed (Surgical & Anesthesia signed)",
          "History & Physical (H&P) Present in Chart",
          "Pre-anesthesia evaluation present",
          "Day-of-surgery H&P update documented",
          "Labs / diagnostics attached & flagged",
          "Surgical Site Marked by Operating Surgeon",
          "Valuables logged / given to family",
          "Operative site prepped / clipped per protocol)",
          "NPO Status Verified (Solids: >8h, Liquids: >2h)",
          "Responsible Adult Driver Confirmed on Premises",
          "Patient Changed into Gown & Personal Items Secured",
          "ID Band & Allergy Band Applied (if applicable)",
          "Voided / catheterized prior to transfer",
          "Dentures, plates, bridges removed",
          "Contacts, glasses, hearing aids removed & bagged",
          "Piercings, makeup, jewelry cleared"
        ]
      },
      {
        "id": "nursing-admission-field-47",
        "label": "Start I.V. Normal Saline at TKO",
        "type": "checkbox",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "Start I.V. Normal Saline at TKO",
          "NPO except for meds",
          "Valium 5 mg P.O. in pre-op",
          "Versed 1 mg I.V. in pre-op",
          "Afrin 3 puffs each nostril X 3",
          "Celebrex 200 mg P.O.",
          "Journavx 50 mg P.O.",
          "Emend 40 mg P.O.",
          "Zofran 4 mg I.V",
          "Cefazolin (Ancef) 1 gm I.V."
        ]
      },
      {
        "id": "nursing-admission-sigadmitrn",
        "label": "RN Signature",
        "type": "signature",
        "required": true,
        "owner": "Nursing",
        "source": "Nursing"
      },
      {
        "id": "nursing-admission-sigorrn",
        "label": "RN Signature",
        "type": "signature",
        "required": true,
        "owner": "Nursing",
        "source": "Nursing"
      }
    ],
    "sourceControlCount": 89,
    "signatureZones": 2
  },
  {
    "title": "PACU Recovery Record",
    "sourceFile": "PACU_Recovery_Record.html",
    "group": "Nursing / Recovery",
    "collectionStage": "PACU",
    "reviewStages": [],
    "fields": [
      {
        "id": "pacu-recovery-record-field-1",
        "label": "Patient Name",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Chart"
      },
      {
        "id": "pacu-recovery-record-field-2",
        "label": "MRN",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Nursing"
      },
      {
        "id": "pacu-recovery-record-field-3",
        "label": "Date of Birth",
        "type": "date",
        "required": false,
        "owner": "Practice-defined",
        "source": "Chart"
      },
      {
        "id": "pacu-recovery-record-field-4",
        "label": "Date of Procedure",
        "type": "date",
        "required": false,
        "owner": "Practice-defined",
        "source": "Chart"
      },
      {
        "id": "pacu-recovery-record-field-5",
        "label": "Procedure Performed",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Chart"
      },
      {
        "id": "pacu-recovery-record-field-6",
        "label": "Surgeon",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Provider"
      },
      {
        "id": "pacu-recovery-record-field-7",
        "label": "Anesthesia Provider",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Provider"
      },
      {
        "id": "pacu-recovery-record-field-8",
        "label": "Anesthesia Type",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Provider"
      },
      {
        "id": "pacu-recovery-record-field-9",
        "label": "Time of Admission (military)",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-10",
        "label": "Admitted From",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-11",
        "label": "Mode of Transfer",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-12",
        "label": "Aldrete Score at Admission",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-13",
        "label": "Initial BP (mmHg)",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-14",
        "label": "Heart Rate (bpm)",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-15",
        "label": "Respiratory Rate",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-16",
        "label": "SpO2 (%)",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-17",
        "label": "Temperature",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-18",
        "label": "Oxygen Delivery",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-19",
        "label": "Surgical Dressing Status",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-20",
        "label": "Initial Pain Level (0–10)",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-21",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-22",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-23",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-24",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-25",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-26",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-27",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-28",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-29",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-30",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-31",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-32",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-33",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-34",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-35",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-36",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-37",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-38",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-39",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-40",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-41",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-42",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-43",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-44",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-45",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-46",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-47",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-48",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-49",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-50",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-51",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-52",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-53",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-54",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-55",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-56",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-57",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-58",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-59",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-60",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-61",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-62",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-63",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-64",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-65",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-66",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-67",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-68",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-69",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-70",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-71",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-72",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-73",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-74",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-75",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-76",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-77",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-78",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-79",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-80",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-81",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-82",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-83",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-84",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-85",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-86",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-87",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-88",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-89",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-90",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-91",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-92",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-93",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-94",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-95",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-96",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-97",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-98",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-99",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-100",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-101",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-102",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-103",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-104",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-105",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-106",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-107",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-108",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-109",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-110",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-111",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-112",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-113",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-114",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-115",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-116",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-117",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-118",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-119",
        "label": "Pain Scale Used",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-120",
        "label": "Patient's Acceptable Pain Goal",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-121",
        "label": "Non-Pharmacologic Measures Used",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-122",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-123",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-124",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-125",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-126",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-127",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-128",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-129",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-130",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-131",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-132",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-133",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-134",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-135",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-136",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-137",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-138",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-139",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-140",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-141",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-142",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-143",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-144",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-145",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-146",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-147",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-148",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-149",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-150",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-151",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-152",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-153",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-154",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-155",
        "label": "Analgesia orders (drug/dose/route/frequency/max per 24h)",
        "type": "textarea",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-156",
        "label": "Antiemetic / nausea orders (drug/dose/route/frequency)",
        "type": "textarea",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-157",
        "label": "IV Fluids",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-158",
        "label": "Oxygen weaning parameters",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-159",
        "label": "Notify physician if: (parameters)",
        "type": "textarea",
        "required": false,
        "owner": "Practice-defined",
        "source": "Provider"
      },
      {
        "id": "pacu-recovery-record-field-160",
        "label": "Printed Name / Credentials",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-161",
        "label": "Date",
        "type": "date",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-162",
        "label": "Time",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-163",
        "label": "Disposition",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-164",
        "label": "Discharge Vital Signs (BP/HR/RR/SpO2)",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Nursing"
      },
      {
        "id": "pacu-recovery-record-field-165",
        "label": "Time of Discharge/Transfer (military)",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-166",
        "label": "Total PACU Length of Stay",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Nursing"
      },
      {
        "id": "pacu-recovery-record-field-167",
        "label": "Additional discharge notes / abnormalities",
        "type": "textarea",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-168",
        "label": "Printed Name / Credentials",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-169",
        "label": "Date",
        "type": "date",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-170",
        "label": "Time",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-171",
        "label": "Printed Name / Credentials",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-172",
        "label": "Date",
        "type": "date",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-173",
        "label": "Clearance Time (military)",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "pacu-recovery-record-field-13",
        "label": "Verbal handoff report received from anesthesia/circulating RN",
        "type": "checkbox",
        "required": false,
        "owner": "Practice-defined",
        "source": "Provider",
        "options": [
          "Verbal handoff report received from anesthesia/circulating RN",
          "Report included procedure, anesthesia type, EBL, allergies, and any intraoperative events",
          "Written anesthesia record (ASC-9) accompanies patient"
        ]
      },
      {
        "id": "pacu-recovery-record-field-143",
        "label": "No nausea/vomiting reported",
        "type": "checkbox",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "No nausea/vomiting reported",
          "Nausea present — treated per orders below",
          "Vomiting present — treated per orders below"
        ]
      },
      {
        "id": "pacu-recovery-record-field-155",
        "label": "Per facility standing PACU order protocol",
        "type": "checkbox",
        "required": false,
        "owner": "Practice-defined",
        "source": "Nursing",
        "options": [
          "Per facility standing PACU order protocol"
        ]
      },
      {
        "id": "pacu-recovery-record-field-163",
        "label": "Patient has met all of above Discharge Criteria and is being discharged in care of a responsible adult.",
        "type": "checkbox",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "Patient has met all of above Discharge Criteria and is being discharged in care of a responsible adu"
        ]
      },
      {
        "id": "pacu-recovery-record-field-167",
        "label": "Discharge medications reviewed (see Physician Orders / Discharge Summary)",
        "type": "checkbox",
        "required": false,
        "owner": "Practice-defined",
        "source": "Provider",
        "options": [
          "Discharge medications reviewed (see Physician Orders / Discharge Summary)",
          "Follow-up appointment instructions given"
        ]
      },
      {
        "id": "pacu_recovery_record-signature-1",
        "label": "Provider Signature",
        "type": "signature",
        "required": true,
        "owner": "Provider",
        "source": "Provider"
      }
    ],
    "sourceControlCount": 186,
    "signatureZones": 1
  },
  {
    "title": "Patient Satisfaction Survey",
    "sourceFile": "Patient_Satisfaction_Survey.html",
    "group": "Patient Intake",
    "collectionStage": "Home / Patient Portal",
    "reviewStages": [
      "Front Desk"
    ],
    "fields": [
      {
        "id": "patient-satisfaction-survey-comments",
        "label": "Comments (positive or negative)",
        "type": "textarea",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "patient-satisfaction-survey-patientname",
        "label": "Patient Name",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Chart"
      },
      {
        "id": "patient-satisfaction-survey-physician",
        "label": "Physician’s Name",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Provider"
      },
      {
        "id": "patient-satisfaction-survey-procdate",
        "label": "Date of Procedure",
        "type": "date",
        "required": false,
        "owner": "Practice-defined",
        "source": "Chart"
      },
      {
        "id": "patient-satisfaction-survey-waitdays",
        "label": "Same day",
        "type": "radio",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "Same day",
          "1-2",
          "3-7",
          "8-14",
          "15+"
        ]
      },
      {
        "id": "patient-satisfaction-survey-q1",
        "label": "q1",
        "type": "radio",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "5",
          "4",
          "3",
          "2",
          "Yes",
          "NA"
        ]
      },
      {
        "id": "patient-satisfaction-survey-q2",
        "label": "q2",
        "type": "radio",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "5",
          "4",
          "3",
          "2",
          "Yes",
          "NA"
        ]
      },
      {
        "id": "patient-satisfaction-survey-q3",
        "label": "q3",
        "type": "radio",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "5",
          "4",
          "3",
          "2",
          "Yes",
          "NA"
        ]
      },
      {
        "id": "patient-satisfaction-survey-q4",
        "label": "q4",
        "type": "radio",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "5",
          "4",
          "3",
          "2",
          "Yes",
          "NA"
        ]
      },
      {
        "id": "patient-satisfaction-survey-q5",
        "label": "q5",
        "type": "radio",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "5",
          "4",
          "3",
          "2",
          "Yes",
          "NA"
        ]
      },
      {
        "id": "patient-satisfaction-survey-waitmin",
        "label": "0–15 min",
        "type": "radio",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "0-15",
          "16-30",
          "30+"
        ]
      },
      {
        "id": "patient-satisfaction-survey-q6",
        "label": "q6",
        "type": "radio",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "5",
          "4",
          "3",
          "2",
          "Yes",
          "NA"
        ]
      },
      {
        "id": "patient-satisfaction-survey-q7",
        "label": "q7",
        "type": "radio",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "5",
          "4",
          "3",
          "2",
          "Yes",
          "NA"
        ]
      },
      {
        "id": "patient-satisfaction-survey-q8",
        "label": "q8",
        "type": "radio",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "5",
          "4",
          "3",
          "2",
          "Yes",
          "NA"
        ]
      },
      {
        "id": "patient-satisfaction-survey-q9",
        "label": "q9",
        "type": "radio",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "5",
          "4",
          "3",
          "2",
          "Yes",
          "NA"
        ]
      },
      {
        "id": "patient-satisfaction-survey-q10",
        "label": "q10",
        "type": "radio",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "5",
          "4",
          "3",
          "2",
          "Yes",
          "NA"
        ]
      },
      {
        "id": "patient-satisfaction-survey-q11",
        "label": "q11",
        "type": "radio",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "5",
          "4",
          "3",
          "2",
          "Yes",
          "NA"
        ]
      },
      {
        "id": "patient-satisfaction-survey-q12",
        "label": "q12",
        "type": "radio",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "5",
          "4",
          "3",
          "2",
          "Yes",
          "NA"
        ]
      },
      {
        "id": "patient-satisfaction-survey-q13",
        "label": "q13",
        "type": "radio",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "5",
          "4",
          "3",
          "2",
          "Yes",
          "NA"
        ]
      },
      {
        "id": "patient-satisfaction-survey-q14",
        "label": "q14",
        "type": "radio",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "5",
          "4",
          "3",
          "2",
          "Yes",
          "NA"
        ]
      },
      {
        "id": "patient-satisfaction-survey-q15",
        "label": "q15",
        "type": "radio",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "5",
          "4",
          "3",
          "2",
          "Yes",
          "NA"
        ]
      },
      {
        "id": "patient-satisfaction-survey-recommend",
        "label": "Yes",
        "type": "radio",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "Yes",
          "No"
        ]
      }
    ],
    "sourceControlCount": 104,
    "signatureZones": 0
  },
  {
    "title": "Photography / Media / Research Consent",
    "sourceFile": "Photography_Media_Research_Consent.html",
    "group": "Patient Intake",
    "collectionStage": "Home / Patient Portal",
    "reviewStages": [
      "Front Desk",
      "Surgeon"
    ],
    "fields": [
      {
        "id": "photography-media-research-consent-patientname",
        "label": "Patient Full Name",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "photography-media-research-consent-dob",
        "label": "Date of Birth",
        "type": "date",
        "required": false,
        "owner": "Practice-defined",
        "source": "Chart"
      },
      {
        "id": "photography-media-research-consent-encdate",
        "label": "Date of Procedure / Encounter",
        "type": "date",
        "required": false,
        "owner": "Practice-defined",
        "source": "Chart"
      },
      {
        "id": "photography-media-research-consent-provider",
        "label": "Surgeon / Provider",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Provider"
      },
      {
        "id": "photography-media-research-consent-mediarestrictions",
        "label": "If identifiable media is consented — any restrictions (e.g., no full face, no name)",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "photography-media-research-consent-studyname",
        "label": "Study or project name (if known)",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "photography-media-research-consent-comments",
        "label": "Additional comments or limitations",
        "type": "textarea",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "photography-media-research-consent-printname",
        "label": "Print Name",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "photography-media-research-consent-relationship",
        "label": "Relationship (if not patient)",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "photography-media-research-consent-sigdate",
        "label": "Date",
        "type": "date",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "photography-media-research-consent-witnessprint",
        "label": "Witness Print Name / Date",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "photography-media-research-consent-clinicalyes",
        "label": "I consent to clinical photography/imaging for use in my medical record and for treatment-related purposes only.",
        "type": "checkbox",
        "required": false,
        "owner": "Practice-defined",
        "source": "Chart",
        "options": [
          "Yes"
        ]
      },
      {
        "id": "photography-media-research-consent-clinicalno",
        "label": "I decline clinical photography beyond what is medically required for the procedure itself.",
        "type": "checkbox",
        "required": false,
        "owner": "Practice-defined",
        "source": "Chart",
        "options": [
          "No"
        ]
      },
      {
        "id": "photography-media-research-consent-edudeid",
        "label": "I consent to use of de-identified images/video for education and training (no name or other identifiers).",
        "type": "checkbox",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "De-identified"
        ]
      },
      {
        "id": "photography-media-research-consent-eduid",
        "label": "I consent to use of images/video that may include identifying features (e.g., face) for education and training.",
        "type": "checkbox",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "Identifiable"
        ]
      },
      {
        "id": "photography-media-research-consent-eduno",
        "label": "I decline educational use of my images/video.",
        "type": "checkbox",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "No"
        ]
      },
      {
        "id": "photography-media-research-consent-mediadeid",
        "label": "I consent to use of de-identified images for marketing and public media.",
        "type": "checkbox",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "De-identified"
        ]
      },
      {
        "id": "photography-media-research-consent-mediaid",
        "label": "I consent to use of images that may include identifying features for marketing and public media.",
        "type": "checkbox",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "Identifiable"
        ]
      },
      {
        "id": "photography-media-research-consent-mediano",
        "label": "I decline any marketing or public media use of my images.",
        "type": "checkbox",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "No"
        ]
      },
      {
        "id": "photography-media-research-consent-researchdeid",
        "label": "I consent to use of de-identified data and images for research and quality improvement.",
        "type": "checkbox",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "De-identified QI/Research"
        ]
      },
      {
        "id": "photography-media-research-consent-researchcontact",
        "label": "I consent to be contacted about future research opportunities related to my care.",
        "type": "checkbox",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "May contact"
        ]
      },
      {
        "id": "photography-media-research-consent-researchno",
        "label": "I decline research / QI use beyond routine quality review of my own care.",
        "type": "checkbox",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "No"
        ]
      },
      {
        "id": "photography-media-research-consent-ack1",
        "label": "I have read this form (or had it read to me) and understand the uses I have selected.",
        "type": "checkbox",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "I have read this form (or had it read to me) and understand the uses I have selected."
        ]
      },
      {
        "id": "photography-media-research-consent-ack2",
        "label": "I understand that refusal will not affect my medical care.",
        "type": "checkbox",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "I understand that refusal will not affect my medical care."
        ]
      },
      {
        "id": "photography-media-research-consent-ack3",
        "label": "I understand I may revoke consent in writing for future uses; materials already used in good faith may not be recalled.",
        "type": "checkbox",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "I understand I may revoke consent in writing for future uses; materials already used in good faith m"
        ]
      },
      {
        "id": "photography-media-research-consent-sigmediapatient",
        "label": "Patient Signature",
        "type": "signature",
        "required": true,
        "owner": "Patient",
        "source": "Patient"
      },
      {
        "id": "photography-media-research-consent-sigmediawitness",
        "label": "Witness Signature",
        "type": "signature",
        "required": true,
        "owner": "Provider",
        "source": "Provider"
      }
    ],
    "sourceControlCount": 27,
    "signatureZones": 2
  },
  {
    "title": "Physician Discharge Order",
    "sourceFile": "Physician_Discharge_Order.html",
    "group": "Surgeon / OR",
    "collectionStage": "Surgeon",
    "reviewStages": [
      "PACU"
    ],
    "fields": [
      {
        "id": "physician-discharge-order-patientname",
        "label": "Patient Full Name",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "physician-discharge-order-dob",
        "label": "Date of Birth",
        "type": "date",
        "required": false,
        "owner": "Practice-defined",
        "source": "Chart"
      },
      {
        "id": "physician-discharge-order-procdate",
        "label": "Date of Procedure",
        "type": "date",
        "required": false,
        "owner": "Practice-defined",
        "source": "Chart"
      },
      {
        "id": "physician-discharge-order-procedure",
        "label": "Procedure Performed",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Chart"
      },
      {
        "id": "physician-discharge-order-surgeon",
        "label": "Operating Surgeon",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Provider"
      },
      {
        "id": "physician-discharge-order-primarydx",
        "label": "Primary Discharge Diagnosis",
        "type": "textarea",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "physician-discharge-order-secondarydx",
        "label": "Secondary / Additional Diagnoses",
        "type": "textarea",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "physician-discharge-order-activityorders",
        "label": "Activity / diet / wound care orders",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "physician-discharge-order-medorders",
        "label": "Medications / prescriptions",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "physician-discharge-order-followup",
        "label": "Follow-up appointment",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "physician-discharge-order-restrictions",
        "label": "Restrictions",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "physician-discharge-order-notes",
        "label": "Additional discharge orders / notes",
        "type": "textarea",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "physician-discharge-order-mdprint",
        "label": "Print Name & Credentials",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "physician-discharge-order-mddate",
        "label": "Date",
        "type": "date",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "physician-discharge-order-mdtime",
        "label": "Time",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "physician-discharge-order-order",
        "label": "Patient meets discharge criteria and may be released to home with responsible adult escort",
        "type": "checkbox",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "Patient meets discharge criteria and may be released to home with responsible adult escort",
          "Patient may be released when nursing criteria are met (RN to document time)",
          "Transfer to acute care / hospital (see Transfer Form)",
          "Other (specify in notes)"
        ]
      },
      {
        "id": "physician-discharge-order-sigdischargemd",
        "label": "Physician Signature",
        "type": "signature",
        "required": true,
        "owner": "Provider",
        "source": "Provider"
      }
    ],
    "sourceControlCount": 20,
    "signatureZones": 1
  },
  {
    "title": "Post-Operative Discharge",
    "sourceFile": "PostOp_Discharge.html",
    "group": "Nursing / Recovery",
    "collectionStage": "PACU",
    "reviewStages": [
      "Nursing"
    ],
    "fields": [
      {
        "id": "postop-discharge-field-1",
        "label": "Date",
        "type": "date",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "postop-discharge-field-2",
        "label": "Release Time (Military)",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "postop-discharge-field-1",
        "label": "Vital signs stabilized and returned to baseline target parameters",
        "type": "checkbox",
        "required": false,
        "owner": "Practice-defined",
        "source": "Nursing",
        "options": [
          "Vital signs stabilized and returned to baseline target parameters",
          "Surgical site checked; no active hemorrhage or standard leakage",
          "Minimal nausea, vomiting, or dizziness observed during ambulation",
          "Pain levels adequately controlled with oral therapeutic agents",
          "Patient tolerated oral fluids / ice chips with zero aspiration issues",
          "Patient voided successfully (if required per surgical tracking protocols)",
          "Written, individualized post-operative instructions provided and explained to the patient and escort",
          "Emergency contact phone numbers and follow-up appointment details clearly documented."
        ]
      },
      {
        "id": "postop-discharge-sigdischargepatient",
        "label": "Patient Signature",
        "type": "signature",
        "required": true,
        "owner": "Patient",
        "source": "Patient"
      },
      {
        "id": "postop-discharge-sigdischargeescort",
        "label": "Responsible Adult / Escort Signature",
        "type": "signature",
        "required": true,
        "owner": "Patient",
        "source": "Patient"
      },
      {
        "id": "postop-discharge-sigdischargern",
        "label": "RN Signature",
        "type": "signature",
        "required": true,
        "owner": "Nursing",
        "source": "Nursing"
      }
    ],
    "sourceControlCount": 14,
    "signatureZones": 3
  },
  {
    "title": "Pre-Operative H&P Clearance",
    "sourceFile": "PreOp_HP_Clearance.html",
    "group": "Surgeon / OR",
    "collectionStage": "Surgeon",
    "reviewStages": [
      "Nursing",
      "Anesthesia"
    ],
    "fields": [
      {
        "id": "preop-hp-clearance-field-1",
        "label": "Patient Full Name",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "preop-hp-clearance-field-2",
        "label": "Date of Birth",
        "type": "date",
        "required": false,
        "owner": "Practice-defined",
        "source": "Chart"
      },
      {
        "id": "preop-hp-clearance-field-3",
        "label": "MRN / Chart #",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Nursing"
      },
      {
        "id": "preop-hp-clearance-field-4",
        "label": "Age",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "preop-hp-clearance-field-5",
        "label": "Sex Select... Female Male Other / Prefer not to state",
        "type": "select",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "Female",
          "Male",
          "Other / Prefer not to state"
        ]
      },
      {
        "id": "preop-hp-clearance-field-6",
        "label": "Date of This Examination",
        "type": "date",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "preop-hp-clearance-field-7",
        "label": "Proposed Procedure",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Chart"
      },
      {
        "id": "preop-hp-clearance-field-8",
        "label": "Operating Surgeon",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Provider"
      },
      {
        "id": "preop-hp-clearance-field-9",
        "label": "Scheduled Surgery Date",
        "type": "date",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "preop-hp-clearance-field-10",
        "label": "Anesthesia Planned Select... General MAC / Deep Sedation Regional / Spinal / Epidural Local only TIVA Not yet determined",
        "type": "select",
        "required": false,
        "owner": "Practice-defined",
        "source": "Provider",
        "options": [
          "General",
          "MAC / Deep Sedation",
          "Regional / Spinal / Epidural",
          "Local only",
          "TIVA",
          "Not yet determined"
        ]
      },
      {
        "id": "preop-hp-clearance-field-11",
        "label": "Field",
        "type": "select",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "Patient unable to obtain PCP appointment in time",
          "No established PCP",
          "PCP declined / deferred clearance",
          "Out-of-area / traveling patient",
          "Other (document below)"
        ]
      },
      {
        "id": "preop-hp-clearance-field-12",
        "label": "Primary indication / diagnosis for procedure",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Chart"
      },
      {
        "id": "preop-hp-clearance-field-13",
        "label": "Brief history of present illness (onset, severity, prior treatments)",
        "type": "textarea",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "preop-hp-clearance-field-14",
        "label": "Reaction details / other allergens",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "preop-hp-clearance-field-15",
        "label": "Medication list (name, dose, frequency) or “See attached med reconciliation”",
        "type": "textarea",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "preop-hp-clearance-field-16",
        "label": "Additional PMH / details",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "preop-hp-clearance-field-17",
        "label": "Prior surgeries (list with approximate years)",
        "type": "textarea",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "preop-hp-clearance-field-18",
        "label": "Tobacco Select... Never Former (quit >1 year) Former (quit <1 year) Current — cigarettes Current — vape / other",
        "type": "select",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "Never",
          "Former (quit >1 year)",
          "Former (quit <1 year)",
          "Current — cigarettes",
          "Current — vape / other"
        ]
      },
      {
        "id": "preop-hp-clearance-field-19",
        "label": "Alcohol Select... None Occasional / social Daily moderate Heavy / possible dependence",
        "type": "select",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "None",
          "Occasional / social",
          "Daily moderate",
          "Heavy / possible dependence"
        ]
      },
      {
        "id": "preop-hp-clearance-field-20",
        "label": "Recreational drugs Select... None Marijuana (occasional) Marijuana (daily) Other (document)",
        "type": "select",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "None",
          "Marijuana (occasional)",
          "Marijuana (daily)",
          "Other (document)"
        ]
      },
      {
        "id": "preop-hp-clearance-field-21",
        "label": "Exercise tolerance / METS estimate Select... ≥4 METS (climb stairs, walk on level without stopping) <4 METS (limited by dyspnea, chest pain, or fatigue) Unable to assess / unknown",
        "type": "select",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "≥4 METS (climb stairs, walk on level without stopping)",
          "<4 METS (limited by dyspnea, chest pain, or fatigue)",
          "Unable to assess / unknown"
        ]
      },
      {
        "id": "preop-hp-clearance-field-22",
        "label": "Ambulatory status Select... Independent Cane / walker Wheelchair Bedbound / limited",
        "type": "select",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "Independent",
          "Cane / walker",
          "Wheelchair",
          "Bedbound / limited"
        ]
      },
      {
        "id": "preop-hp-clearance-field-23",
        "label": "Living situation / support Select... Lives with responsible adult Lives alone — escort confirmed for discharge Lives alone — escort NOT yet confirmed Assisted living / facility",
        "type": "select",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "Lives with responsible adult",
          "Lives alone — escort confirmed for discharge",
          "Lives alone — escort NOT yet confirmed",
          "Assisted living / facility"
        ]
      },
      {
        "id": "preop-hp-clearance-field-24",
        "label": "ROS details / other positive findings",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "preop-hp-clearance-field-25",
        "label": "BP (mmHg)",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "preop-hp-clearance-field-26",
        "label": "HR (bpm)",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "preop-hp-clearance-field-27",
        "label": "RR",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "preop-hp-clearance-field-28",
        "label": "SpO2 (%)",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "preop-hp-clearance-field-29",
        "label": "Temp (°F / °C)",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "preop-hp-clearance-field-30",
        "label": "Height",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "preop-hp-clearance-field-31",
        "label": "Weight",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "preop-hp-clearance-field-32",
        "label": "BMI (if calculated)",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "preop-hp-clearance-field-33",
        "label": "Well-appearing, no acute distress Ill-appearing / distressed Other (note)",
        "type": "select",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "Well-appearing, no acute distress",
          "Ill-appearing / distressed",
          "Other (note)"
        ]
      },
      {
        "id": "preop-hp-clearance-field-34",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "preop-hp-clearance-field-35",
        "label": "Mallampati I–II, adequate mouth opening, normal neck Mallampati III–IV or limited mobility Dentures / loose teeth / beard / other concern",
        "type": "select",
        "required": false,
        "owner": "Practice-defined",
        "source": "Nursing",
        "options": [
          "Mallampati I–II, adequate mouth opening, normal neck",
          "Mallampati III–IV or limited mobility",
          "Dentures / loose teeth / beard / other concern"
        ]
      },
      {
        "id": "preop-hp-clearance-field-36",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "preop-hp-clearance-field-37",
        "label": "RRR, no murmur, normal S1/S2 Irregular / murmur / other abnormal",
        "type": "select",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "RRR, no murmur, normal S1/S2",
          "Irregular / murmur / other abnormal"
        ]
      },
      {
        "id": "preop-hp-clearance-field-38",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "preop-hp-clearance-field-39",
        "label": "Clear bilaterally, no wheeze/rales Wheeze / rales / decreased BS / other",
        "type": "select",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "Clear bilaterally, no wheeze/rales",
          "Wheeze / rales / decreased BS / other"
        ]
      },
      {
        "id": "preop-hp-clearance-field-40",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "preop-hp-clearance-field-41",
        "label": "Soft, non-tender, no masses Tender / distended / other N/A (not relevant)",
        "type": "select",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "Soft, non-tender, no masses",
          "Tender / distended / other",
          "N/A (not relevant)"
        ]
      },
      {
        "id": "preop-hp-clearance-field-42",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "preop-hp-clearance-field-43",
        "label": "No edema, pulses intact Edema / poor pulses / other",
        "type": "select",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "No edema, pulses intact",
          "Edema / poor pulses / other"
        ]
      },
      {
        "id": "preop-hp-clearance-field-44",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "preop-hp-clearance-field-45",
        "label": "Alert, oriented ×3, non-focal Altered / focal deficit / other",
        "type": "select",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "Alert, oriented ×3, non-focal",
          "Altered / focal deficit / other"
        ]
      },
      {
        "id": "preop-hp-clearance-field-46",
        "label": "Field",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "preop-hp-clearance-field-47",
        "label": "Key lab / study findings or “WNL”",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "preop-hp-clearance-field-48",
        "label": "Field",
        "type": "select",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "CLEARED for proposed procedure and anesthesia as planned",
          "CLEARED with recommendations / conditions (list below)",
          "NOT CLEARED — further evaluation required",
          "DEFERRED — pending additional studies or optimization"
        ]
      },
      {
        "id": "preop-hp-clearance-field-49",
        "label": "Field",
        "type": "select",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "ASA I — Normal healthy patient",
          "ASA II — Mild systemic disease",
          "ASA III — Severe systemic disease",
          "ASA IV — Severe systemic disease that is a constant threat to life",
          "ASA V — Moribund (not expected for elective outpatient)"
        ]
      },
      {
        "id": "preop-hp-clearance-field-50",
        "label": "Clinician Name & Credentials",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "preop-hp-clearance-field-51",
        "label": "Date / Time",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "preop-hp-clearance-field-52",
        "label": "NPI or License # (if required)",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "preop-hp-clearance-field-53",
        "label": "Facility / Practice",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "preop-hp-clearance-field-14",
        "label": "No Known Drug Allergies (NKDA)",
        "type": "checkbox",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "No Known Drug Allergies (NKDA)",
          "Penicillin / Beta-lactams",
          "Sulfa",
          "Latex",
          "Iodine / Contrast",
          "Opioids / Codeine",
          "NSAIDs / Aspirin",
          "Local anesthetics",
          "Other (list below)"
        ]
      },
      {
        "id": "preop-hp-clearance-field-15",
        "label": "Anticoagulant / antiplatelet (list below)",
        "type": "checkbox",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "Anticoagulant / antiplatelet (list below)",
          "Insulin or oral hypoglycemic",
          "GLP-1 agonist (Ozempic, Wegovy, Mounjaro, etc.)",
          "Beta-blocker",
          "ACEI / ARB",
          "Diuretic",
          "Steroids (chronic)",
          "Opioid / benzodiazepine (chronic)",
          "None of the above high-risk classes"
        ]
      },
      {
        "id": "preop-hp-clearance-field-16",
        "label": "Hypertension",
        "type": "checkbox",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "Hypertension",
          "CAD / Prior MI",
          "Heart failure / CHF",
          "Arrhythmia / AFib",
          "Pacemaker / ICD",
          "Valvular disease",
          "Stroke / TIA",
          "Peripheral vascular disease",
          "Asthma",
          "COPD / Emphysema",
          "Sleep apnea (OSA)",
          "Uses CPAP / BiPAP",
          "Recent URI / pneumonia",
          "Home O2",
          "Diabetes mellitus (Type 1)",
          "Diabetes mellitus (Type 2)",
          "Thyroid disorder",
          "Chronic kidney disease",
          "Dialysis",
          "Liver disease / Hepatitis",
          "Obesity (BMI ≥30)",
          "Adrenal disorder",
          "GERD / Severe reflux",
          "Seizure disorder",
          "Bleeding / clotting disorder",
          "History of DVT / PE",
          "Anemia",
          "Cancer (active or history)",
          "Immunosuppression",
          "Psychiatric / anxiety / depression"
        ]
      },
      {
        "id": "preop-hp-clearance-field-18",
        "label": "No prior surgery",
        "type": "checkbox",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "No prior surgery",
          "Prior difficult intubation / airway",
          "Prior anesthesia complication (PONV, awareness, delayed emergence)",
          "Family history of malignant hyperthermia",
          "Prior transfusion reaction"
        ]
      },
      {
        "id": "preop-hp-clearance-field-24",
        "label": "Chest pain / angina",
        "type": "checkbox",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "Chest pain / angina",
          "Shortness of breath / DOE",
          "Palpitations / syncope",
          "Orthopedic / joint issues affecting positioning",
          "Recent fever / infection",
          "Unexplained weight loss",
          "Bleeding gums / easy bruising",
          "Pregnancy (or possibility)",
          "None of the above (ROS negative for clearance-relevant items)"
        ]
      },
      {
        "id": "preop-hp-clearance-field-47",
        "label": "CBC reviewed / normal or acceptable",
        "type": "checkbox",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "CBC reviewed / normal or acceptable",
          "BMP / electrolytes reviewed",
          "Coagulation studies reviewed",
          "ECG reviewed (or not indicated)",
          "Pregnancy test (if applicable) negative",
          "No recent labs available — clinical clearance only"
        ]
      },
      {
        "id": "preop-hp-clearance-field-50",
        "label": "Risks, benefits, and alternatives of proceeding without external PCP note discussed",
        "type": "checkbox",
        "required": false,
        "owner": "Practice-defined",
        "source": "Nursing",
        "options": [
          "Risks, benefits, and alternatives of proceeding without external PCP note discussed",
          "Responsible adult escort confirmed for discharge."
        ]
      },
      {
        "id": "preop-hp-clearance-sigclearingclinician",
        "label": "Signature 1",
        "type": "signature",
        "required": true,
        "owner": "Configured signer",
        "source": "Provider"
      }
    ],
    "sourceControlCount": 124,
    "signatureZones": 1
  },
  {
    "title": "Procedure Consent",
    "sourceFile": "Procedure_Consent.html",
    "group": "Patient Intake",
    "collectionStage": "Home / Patient Portal",
    "reviewStages": [
      "Nursing",
      "Surgeon"
    ],
    "fields": [
      {
        "id": "procedure-consent-patientname",
        "label": "Patient Name",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Chart"
      },
      {
        "id": "procedure-consent-date",
        "label": "Date",
        "type": "date",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "procedure-consent-doctor",
        "label": "I hereby authorize and direct Doctor and if necessary assistant of his/her choice to perform the following operation on me:",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "procedure-consent-procedure",
        "label": "Procedure(s)",
        "type": "textarea",
        "required": false,
        "owner": "Practice-defined",
        "source": "Chart"
      },
      {
        "id": "procedure-consent-consentterms",
        "label": "consentTerms",
        "type": "textarea",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "procedure-consent-anesconsent",
        "label": "anesConsent",
        "type": "textarea",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "procedure-consent-valuables",
        "label": "valuables",
        "type": "textarea",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "procedure-consent-discharge",
        "label": "discharge",
        "type": "textarea",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "procedure-consent-sigdate",
        "label": "Date",
        "type": "date",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "procedure-consent-sigtime",
        "label": "Time",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "procedure-consent-sigprocpatient",
        "label": "Patient Signature",
        "type": "signature",
        "required": true,
        "owner": "Patient",
        "source": "Patient"
      },
      {
        "id": "procedure-consent-sigprocwitness",
        "label": "Witness Signature",
        "type": "signature",
        "required": true,
        "owner": "Provider",
        "source": "Provider"
      }
    ],
    "sourceControlCount": 12,
    "signatureZones": 2
  },
  {
    "title": "Surgeon Operative Report",
    "sourceFile": "Surgeon_Operative_Report.html",
    "group": "Surgeon / OR",
    "collectionStage": "Surgeon",
    "reviewStages": [
      "OR Team",
      "PACU"
    ],
    "fields": [
      {
        "id": "surgeon-operative-report-patientname",
        "label": "Patient Full Name",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "surgeon-operative-report-dob",
        "label": "Date of Birth",
        "type": "date",
        "required": false,
        "owner": "Practice-defined",
        "source": "Chart"
      },
      {
        "id": "surgeon-operative-report-mrn",
        "label": "MRN / Chart #",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Nursing"
      },
      {
        "id": "surgeon-operative-report-procdate",
        "label": "Date of Procedure",
        "type": "date",
        "required": false,
        "owner": "Practice-defined",
        "source": "Chart"
      },
      {
        "id": "surgeon-operative-report-orroom",
        "label": "OR Room / Suite",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "surgeon-operative-report-asa",
        "label": "ASA Classification — Select — I II III IV V E (Emergency)",
        "type": "select",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "I",
          "II",
          "III",
          "IV",
          "V",
          "E (Emergency)"
        ]
      },
      {
        "id": "surgeon-operative-report-surgeon",
        "label": "Surgeon",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Provider"
      },
      {
        "id": "surgeon-operative-report-assistant",
        "label": "Assistant Surgeon(s)",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Provider"
      },
      {
        "id": "surgeon-operative-report-anesthesia",
        "label": "Anesthesiologist / CRNA",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Nursing"
      },
      {
        "id": "surgeon-operative-report-nurses",
        "label": "Scrub / Circulating Nurse",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Nursing"
      },
      {
        "id": "surgeon-operative-report-predx",
        "label": "Pre-Operative Diagnosis",
        "type": "textarea",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "surgeon-operative-report-postdx",
        "label": "Post-Operative Diagnosis",
        "type": "textarea",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "surgeon-operative-report-procedure",
        "label": "Procedure(s) Performed (include CPT if known)",
        "type": "textarea",
        "required": false,
        "owner": "Practice-defined",
        "source": "Chart"
      },
      {
        "id": "surgeon-operative-report-starttime",
        "label": "Incision / Start Time",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "surgeon-operative-report-stoptime",
        "label": "Close / Stop Time",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "surgeon-operative-report-ebl",
        "label": "Estimated Blood Loss (mL)",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "surgeon-operative-report-anestype",
        "label": "Anesthesia Type",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Provider"
      },
      {
        "id": "surgeon-operative-report-woundclass",
        "label": "Wound Classification — Select — Clean Clean-Contaminated Contaminated Dirty / Infected",
        "type": "select",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "Clean",
          "Clean-Contaminated",
          "Contaminated",
          "Dirty / Infected"
        ]
      },
      {
        "id": "surgeon-operative-report-findings",
        "label": "Findings",
        "type": "textarea",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "surgeon-operative-report-technique",
        "label": "Technique / Description of Procedure",
        "type": "textarea",
        "required": false,
        "owner": "Practice-defined",
        "source": "Chart"
      },
      {
        "id": "surgeon-operative-report-implants",
        "label": "Implants / Devices / Grafts (manufacturer, model, lot/serial if applicable)",
        "type": "textarea",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "surgeon-operative-report-specimens",
        "label": "Specimens / Cultures Sent",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "surgeon-operative-report-complications",
        "label": "Complications None Bleeding Other (describe below)",
        "type": "textarea",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "surgeon-operative-report-disposition",
        "label": "Disposition / Condition at End of Case",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "surgeon-operative-report-notes",
        "label": "Additional Notes",
        "type": "textarea",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "surgeon-operative-report-surgeonprint",
        "label": "Print Name & Credentials",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "surgeon-operative-report-sigdate",
        "label": "Date",
        "type": "date",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "surgeon-operative-report-sigtime",
        "label": "Time",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "surgeon-operative-report-compnone",
        "label": "None",
        "type": "checkbox",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "None"
        ]
      },
      {
        "id": "surgeon-operative-report-compbleeding",
        "label": "Bleeding",
        "type": "checkbox",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "Bleeding"
        ]
      },
      {
        "id": "surgeon-operative-report-compother",
        "label": "Other (describe below)",
        "type": "checkbox",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "Other (describe below)"
        ]
      },
      {
        "id": "surgeon-operative-report-sigopreport",
        "label": "Facility Representative Signature",
        "type": "signature",
        "required": true,
        "owner": "Provider",
        "source": "Provider"
      }
    ],
    "sourceControlCount": 32,
    "signatureZones": 1
  },
  {
    "title": "Surgeon Pre-Operative Clearance",
    "sourceFile": "Surgeon_PreOp_Clearance.html",
    "group": "Surgeon / OR",
    "collectionStage": "Surgeon",
    "reviewStages": [
      "Nursing",
      "Anesthesia"
    ],
    "fields": [
      {
        "id": "surgeon-preop-clearance-field-1",
        "label": "Comprehensive H&P Document Status Select... Completed within past 30 days (attached to chart) Completed on-site today prior to procedure",
        "type": "select",
        "required": false,
        "owner": "Practice-defined",
        "source": "Chart",
        "options": [
          "Completed within past 30 days (attached to chart)",
          "Completed on-site today prior to procedure"
        ]
      },
      {
        "id": "surgeon-preop-clearance-field-2",
        "label": "Primary Diagnosis Justifying Surgery",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "surgeon-preop-clearance-field-3",
        "label": "Interval Changes / Structural Updates (If none, write \"None\") None",
        "type": "textarea",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "surgeon-preop-clearance-field-4",
        "label": "Date",
        "type": "date",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "surgeon-preop-clearance-field-5",
        "label": "Pre-Incision Time (Military)",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "surgeon-preop-clearance-field-3",
        "label": "Surgical risks, benefits, alternatives, and potential blood transfusion protocols were reviewed with the patient.",
        "type": "checkbox",
        "required": false,
        "owner": "Practice-defined",
        "source": "Nursing",
        "options": [
          "Surgical risks, benefits, alternatives, and potential blood transfusion protocols were reviewed with"
        ]
      },
      {
        "id": "surgeon-preop-clearance-sigsurgeon",
        "label": "Surgeon Signature",
        "type": "signature",
        "required": true,
        "owner": "Provider",
        "source": "Provider"
      }
    ],
    "sourceControlCount": 8,
    "signatureZones": 1
  },
  {
    "title": "Universal Protocol Safety Checklist",
    "sourceFile": "Universal_Protocol_Safety_Checklist.html",
    "group": "Surgeon / OR",
    "collectionStage": "OR Team",
    "reviewStages": [
      "Surgeon"
    ],
    "fields": [
      {
        "id": "universal-protocol-safety-checklist-patientname",
        "label": "Patient Name",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Chart"
      },
      {
        "id": "universal-protocol-safety-checklist-date",
        "label": "Date",
        "type": "date",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "universal-protocol-safety-checklist-procedure",
        "label": "Procedure",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Chart"
      },
      {
        "id": "universal-protocol-safety-checklist-verifyby",
        "label": "Verified by (name / role)",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "universal-protocol-safety-checklist-abxtime",
        "label": "Antibiotic given within last 60 minutes (if indicated) — time:",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "universal-protocol-safety-checklist-timeouttime",
        "label": "Time-Out Time",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "universal-protocol-safety-checklist-timeoutleader",
        "label": "Circulator / Leader documenting",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "universal-protocol-safety-checklist-circrn",
        "label": "Circulating RN Initials / Name",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Nursing"
      },
      {
        "id": "universal-protocol-safety-checklist-surginit",
        "label": "Surgeon Initials / Name",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Provider"
      },
      {
        "id": "universal-protocol-safety-checklist-anesinit",
        "label": "Anesthesia Initials / Name",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Provider"
      },
      {
        "id": "universal-protocol-safety-checklist-docdate",
        "label": "Date",
        "type": "date",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "universal-protocol-safety-checklist-v",
        "label": "Patient identity verified (name + DOB) against ID band and chart",
        "type": "checkbox",
        "required": false,
        "owner": "Practice-defined",
        "source": "Chart",
        "options": [
          "Patient identity verified (name + DOB) against ID band and chart",
          "Consent form present, signed, and matches planned procedure",
          "H&P / interval note present and current",
          "Site marked by operating surgeon (visible after prep/drape) or N/A",
          "Imaging / studies available and labeled correctly (if applicable)",
          "Implants / special equipment available and correct",
          "Allergies reviewed",
          "VTE risk / prophylaxis plan confirmed",
          "Antibiotic ordered / given within window (if indicated)"
        ]
      },
      {
        "id": "universal-protocol-safety-checklist-t",
        "label": "All team members introduce name and role (or confirm present)",
        "type": "checkbox",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "All team members introduce name and role (or confirm present)",
          "Patient identity confirmed aloud",
          "Procedure confirmed aloud (matches consent)",
          "Site / side confirmed aloud; mark visible",
          "Positioning confirmed",
          "Anesthesia / allergy concerns stated",
          "Anticipated critical events discussed (if any)",
          "Antibiotic given within last 60 minutes (if indicated) — time:",
          "Essential imaging displayed (if applicable)"
        ]
      },
      {
        "id": "universal-protocol-safety-checklist-s",
        "label": "Procedure name recorded as performed",
        "type": "checkbox",
        "required": false,
        "owner": "Practice-defined",
        "source": "Chart",
        "options": [
          "Procedure name recorded as performed",
          "Instrument / sponge / needle counts correct (or N/A)",
          "Specimens labeled (patient, site, type)",
          "Equipment problems addressed",
          "Key recovery concerns for PACU communicated"
        ]
      },
      {
        "id": "universal_protocol_safety_checklist-signature-1",
        "label": "Provider Signature",
        "type": "signature",
        "required": true,
        "owner": "Provider",
        "source": "Provider"
      }
    ],
    "sourceControlCount": 34,
    "signatureZones": 1
  },
  {
    "title": "Written Discharge Instructions",
    "sourceFile": "Written_Discharge_Instructions.html",
    "group": "Nursing / Recovery",
    "collectionStage": "PACU",
    "reviewStages": [
      "Nursing"
    ],
    "fields": [
      {
        "id": "written-discharge-instructions-patientname",
        "label": "Patient Name",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Chart"
      },
      {
        "id": "written-discharge-instructions-procdate",
        "label": "Date of Procedure",
        "type": "date",
        "required": false,
        "owner": "Practice-defined",
        "source": "Chart"
      },
      {
        "id": "written-discharge-instructions-procedure",
        "label": "Procedure",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Chart"
      },
      {
        "id": "written-discharge-instructions-surgeon",
        "label": "Surgeon",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Provider"
      },
      {
        "id": "written-discharge-instructions-genother",
        "label": "Additional general instructions",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "written-discharge-instructions-activity",
        "label": "Activity restrictions",
        "type": "textarea",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "written-discharge-instructions-wound",
        "label": "Wound / dressing care",
        "type": "textarea",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "written-discharge-instructions-bathing",
        "label": "Bathing / showering",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "written-discharge-instructions-painmed",
        "label": "Pain medication",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "written-discharge-instructions-othermed",
        "label": "Other prescribed medications",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "written-discharge-instructions-resumemed",
        "label": "Medications to resume / hold",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "written-discharge-instructions-warnother",
        "label": "warnOther",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Nursing"
      },
      {
        "id": "written-discharge-instructions-followup",
        "label": "Follow-up appointment",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "written-discharge-instructions-officephone",
        "label": "Office phone (business hours)",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "written-discharge-instructions-afterhours",
        "label": "After-hours / emergency contact",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "written-discharge-instructions-ed",
        "label": "Nearest emergency department",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "written-discharge-instructions-additional",
        "label": "Additional procedure-specific instructions",
        "type": "textarea",
        "required": false,
        "owner": "Practice-defined",
        "source": "Chart"
      },
      {
        "id": "written-discharge-instructions-signerprint",
        "label": "Print name of person signing for patient",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "written-discharge-instructions-reldate",
        "label": "Relationship / Date / Time",
        "type": "text",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient"
      },
      {
        "id": "written-discharge-instructions-gen",
        "label": "A responsible adult must stay with the patient for at least 12–24 hours after anesthesia/sedation.",
        "type": "checkbox",
        "required": false,
        "owner": "Practice-defined",
        "source": "Provider",
        "options": [
          "A responsible adult must stay with the patient for at least 12–24 hours after anesthesia/sedation.",
          "Do not drink alcohol for 24 hours.",
          "Start with clear liquids; advance diet as tolerated unless told otherwise.",
          "Other:"
        ]
      },
      {
        "id": "written-discharge-instructions-warn",
        "label": "Fever over 101°F (38.3°C)",
        "type": "checkbox",
        "required": false,
        "owner": "Practice-defined",
        "source": "Patient",
        "options": [
          "Fever over 101°F (38.3°C)",
          "Increasing pain not controlled by prescribed medication",
          "Excessive bleeding, swelling, or drainage from the incision",
          "Difficulty breathing, chest pain, or calf pain/swelling",
          "Persistent vomiting or inability to keep fluids down",
          "Other procedure-specific warnings:"
        ]
      },
      {
        "id": "written-discharge-instructions-siginstrpatient",
        "label": "Patient Signature",
        "type": "signature",
        "required": true,
        "owner": "Patient",
        "source": "Patient"
      },
      {
        "id": "written-discharge-instructions-siginstrrn",
        "label": "RN Signature",
        "type": "signature",
        "required": true,
        "owner": "Nursing",
        "source": "Nursing"
      }
    ],
    "sourceControlCount": 32,
    "signatureZones": 2
  }
];
