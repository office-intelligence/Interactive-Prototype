import { PatientCase } from '../types';

export interface PortalProvider {
  id: string;
  name: string;
  shortName: string;
  title: string;
  specialty: string;
  practiceName: string;
  practiceShortName: string;
  location: string;
  phone: string;
  email: string;
  initials: string;
  badgeColor: string;
  borderColor: string;
  bgLightColor: string;
  accentColor: string;
  avatarBg: string;
  summary: string;
  bio: string;
}

export const PORTAL_PROVIDERS: PortalProvider[] = [];

export interface PortalAppointment {
  id: string;
  patientId: string;
  providerId?: string;
  practiceName?: string;
  title: string;
  doctor: string;
  specialty: string;
  facility: string;
  location: string;
  date: string;
  time: string;
  duration: string;
  status: 'UPCOMING' | 'COMPLETED' | 'REQUESTED' | 'CANCELLED';
  room?: string;
  instructions?: string;
  checklist?: { text: string; done: boolean }[];
  summaryNote?: string;
  canCheckIn?: boolean;
}

export interface PortalIntakeForm {
  id: string;
  patientId: string;
  providerId?: string;
  practiceName?: string;
  doctor?: string;
  title: string;
  category: string;
  sentDate: string;
  dueDate: string;
  status: 'PENDING' | 'IN_PROGRESS' | 'COMPLETED';
  completedDate?: string;
  description: string;
  questionsCount: number;
  signedBy?: string;
  data?: Record<string, any>;
}

export interface PortalDocument {
  id: string;
  patientId: string;
  providerId?: string;
  practiceName?: string;
  doctor?: string;
  title: string;
  fileName: string;
  category: 'Clinical Notes' | 'Lab Results' | 'Consents' | 'Patient Uploads' | 'Imaging' | 'Billing';
  uploadDate: string;
  uploadedBy: 'Practice' | 'Patient';
  fileSize: string;
  fileType: 'pdf' | 'png' | 'jpg' | 'doc';
  previewUrl?: string;
  summary: string;
  isNew?: boolean;
}

export interface PortalMessage {
  id: string;
  patientId: string;
  providerId?: string;
  practiceName?: string;
  sender: 'patient' | 'provider' | 'system';
  senderName: string;
  senderTitle?: string;
  timestamp: string;
  date: string;
  category?: 'Clinical Question' | 'Prescription Refill' | 'Scheduling' | 'Billing' | 'General';
  content: string;
  read: boolean;
  attachment?: {
    name: string;
    size: string;
  };
}

export interface PortalPrescription {
  id: string;
  patientId: string;
  providerId?: string;
  practiceName?: string;
  medicationName: string;
  dosage: string;
  instructions: string;
  prescribedBy: string;
  datePrescribed: string;
  refillsRemaining: number;
  pharmacy: string;
  status: 'ACTIVE' | 'REFILL_REQUESTED' | 'COMPLETED' | 'EXPIRED';
}

export interface PortalBill {
  id: string;
  patientId: string;
  providerId?: string;
  practiceName?: string;
  doctor?: string;
  statementDate: string;
  dueDate: string;
  totalAmount: number;
  insurancePaid: number;
  patientBalance: number;
  status: 'PAID' | 'UNPAID' | 'PENDING_INSURANCE';
  description: string;
  items: { description: string; charge: number; insuranceDiscount: number; patientOwes: number }[];
  receiptId?: string;
}

export interface PortalPatientProfile {
  id: string;
  patientId: string;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  dob: string;
  gender: 'Female' | 'Male' | 'Other';
  mrn: string;
  address: string;
  emergencyContact: {
    name: string;
    relationship: string;
    phone: string;
  };
  primarySurgeon: string;
  allergies: string[];
  vitals: {
    bloodPressure: string;
    heartRate: string;
    height: string;
    weight: string;
    bmi: string;
    temperature: string;
    oxygenSat: string;
  };
  preferredPharmacy: {
    name: string;
    address: string;
    phone: string;
  };
  insurance: {
    provider: string;
    policyNumber: string;
    groupNumber: string;
    status: 'ACTIVE_VERIFIED' | 'PENDING';
  };
}

// Sample Fictitious Patient Profiles connected to Office Intelligence
export const DEFAULT_PORTAL_PROFILES: PortalPatientProfile[] = [];

// Sample Appointments Timeline
export const DEFAULT_PORTAL_APPOINTMENTS: PortalAppointment[] = [];

// Sample Intake Forms sent to patient via email from OI
export const DEFAULT_PORTAL_FORMS: PortalIntakeForm[] = [];

// Sample Clinical & Uploaded Documents
export const DEFAULT_PORTAL_DOCUMENTS: PortalDocument[] = [];

// Sample Messages Thread
export const DEFAULT_PORTAL_MESSAGES: PortalMessage[] = [];

// Sample Prescriptions
export const DEFAULT_PORTAL_PRESCRIPTIONS: PortalPrescription[] = [];

// Sample Billing Statements
export const DEFAULT_PORTAL_BILLS: PortalBill[] = [];
