import { PatientCase, TaskItem, CommunicationStats, BottleneckAlert } from '../types';

// BACKEND HANDOFF: intentionally empty. Production data will come from the API/database.
export const initialPatientCases: PatientCase[] = [];
export const initialBottleneckAlerts: BottleneckAlert[] = [];
export const initialTasks: TaskItem[] = [];
export const initialStats: CommunicationStats = {
  insuranceApproval: 0,
  labResults: 0,
  implantShipment: 0,
  physicianSignature: 0,
  patientMessages: 0,
  referrals: 0,
  insuranceQueries: 0,
  labNotifications: 0,
};
