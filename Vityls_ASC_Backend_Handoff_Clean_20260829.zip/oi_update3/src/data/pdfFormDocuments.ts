// Registry of documents rendered through the real-PDF viewer (PdfFormViewer)
// rather than the HTML-template system. This is an additive, opt-in layer:
// only documents listed here are migrated off the HTML forms; everything
// else keeps using the existing HTML-template + iframe rendering untouched
// while this approach is validated against real practice documents.
//
// Phase 1 covers exactly the two documents proven against the practice's own
// real PDFs (see the Anesthesia Questionnaire <-> Pre-Op Evaluation prefill
// relationship in pdfPrefillMap.ts). The Consent for Anesthesia and the
// Malignant Hyperthermia & VTE Risk Assessment pages from the same source
// PDF are a deliberate next phase, not yet split out or wired in here.

export interface PdfFormDocument {
  /** Stable id — also used as the localStorage draft/lock key and must be
   *  unique across the whole catalog. */
  id: string;
  title: string;
  pdfUrl: string;
  requiresSignature: boolean;
}

export const PDF_FORM_DOCUMENTS: PdfFormDocument[] = [];

export function getPdfFormDocument(id: string): PdfFormDocument | undefined {
  return PDF_FORM_DOCUMENTS.find((d) => d.id === id);
}
