export interface IntakeHtmlForm {
  id: string;
  order: number;
  providerId?: string;
  doctor?: string;
  practiceName?: string;
  title: string;
  category: 'Admission' | 'Insurance' | 'Medical' | 'Anesthesia';
  type: string;
  targetAudience: string;
  status: 'Pending Send' | 'Sent via Email' | 'Sent via SMS' | 'Completed in Portal';
  lastSentDate?: string;
  completedDate?: string;
  fileName: string;
  summary: string;
  description: string;
  htmlTemplate: string;
  // Whether completing this document requires capturing a legal electronic
  // signature (canvas signature + attestation checkbox + IP/timestamp audit
  // trail) via the surrounding chart UI. When false, the document is instead
  // completed with a lightweight "Mark as Reviewed" action. This is an
  // explicit per-form flag rather than something inferred from the HTML
  // content at render time — practices vary too much for that to be reliable
  // — but it was set here by checking whether each template's own text
  // already defers to "the Official Patient Electronic Signature & Legal
  // Attestation section below" (signature required) or not (not required).
  requiresSignature: boolean;
  // Form Studio templates can carry multiple standardized freehand signature zones.
  // Legacy forms may omit this and continue to use the single surrounding signature panel.
  signatureZones?: Array<{ id: string; label: string; owner?: string; required?: boolean }>;
}

export const INITIAL_INTAKE_HTML_FORMS: IntakeHtmlForm[] = [];
