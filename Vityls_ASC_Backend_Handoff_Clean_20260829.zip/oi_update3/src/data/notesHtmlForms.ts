export interface NoteHtmlForm {
  id: string;
  order: number;
  title: string;
  subtitle: string;
  author: string;
  date: string;
  status: 'Signed & Cleared' | 'Pending Review' | 'Draft';
  category: string;
  fileName: string;
  summary: string;
  htmlTemplate: string;
}

export const INITIAL_NOTES_HTML_FORMS: NoteHtmlForm[] = [];
