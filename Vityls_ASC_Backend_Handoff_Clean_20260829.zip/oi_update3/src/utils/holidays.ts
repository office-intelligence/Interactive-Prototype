// US Federal Holidays Utility

export interface FederalHoliday {
  name: string;
  dateStr: string; // YYYY-MM-DD
  observedDateStr: string; // YYYY-MM-DD
  isObserved?: boolean;
}

/**
 * Calculates US Federal Holidays for a given year.
 * Handles both actual dates and observed dates (if a holiday falls on a weekend).
 */
export function getFederalHolidaysForYear(year: number): { [key: string]: string } {
  // Returns map of "YYYY-MM-DD" -> Holiday Name
  const holidays: { [key: string]: string } = {};

  const addHoliday = (actualMonth: number, actualDay: number, name: string, observeOnWeekend = true) => {
    const actualDate = new Date(year, actualMonth - 1, actualDay);
    const m = actualMonth < 10 ? `0${actualMonth}` : `${actualMonth}`;
    const d = actualDay < 10 ? `0${actualDay}` : `${actualDay}`;
    const actualKey = `${year}-${m}-${d}`;
    holidays[actualKey] = name;

    if (observeOnWeekend) {
      const dayOfWeek = actualDate.getDay(); // 0 = Sun, 6 = Sat
      if (dayOfWeek === 0) {
        // Sunday -> Observed on Monday
        const obsDate = new Date(year, actualMonth - 1, actualDay + 1);
        const obsM = obsDate.getMonth() + 1;
        const obsD = obsDate.getDate();
        const obsKey = `${obsDate.getFullYear()}-${obsM < 10 ? `0${obsM}` : obsM}-${obsD < 10 ? `0${obsD}` : obsD}`;
        holidays[obsKey] = `${name} (Observed)`;
      } else if (dayOfWeek === 6) {
        // Saturday -> Observed on Friday
        const obsDate = new Date(year, actualMonth - 1, actualDay - 1);
        const obsM = obsDate.getMonth() + 1;
        const obsD = obsDate.getDate();
        const obsKey = `${obsDate.getFullYear()}-${obsM < 10 ? `0${obsM}` : obsM}-${obsD < 10 ? `0${obsD}` : obsD}`;
        holidays[obsKey] = `${name} (Observed)`;
      }
    }
  };

  const getNthWeekdayOfMonth = (month: number, weekday: number, n: number): number => {
    // weekday: 0 = Sun, 1 = Mon, ..., 6 = Sat
    // n: 1 = 1st, 2 = 2nd, 3 = 3rd, 4 = 4th
    const firstDay = new Date(year, month - 1, 1);
    let day = 1 + ((weekday - firstDay.getDay() + 7) % 7);
    day += (n - 1) * 7;
    return day;
  };

  const getLastWeekdayOfMonth = (month: number, weekday: number): number => {
    const lastDay = new Date(year, month, 0); // last day of month
    let day = lastDay.getDate() - ((lastDay.getDay() - weekday + 7) % 7);
    return day;
  };

  // 1. New Year's Day: January 1
  addHoliday(1, 1, "New Year's Day");

  // 2. Martin Luther King Jr. Day: 3rd Monday in January
  const mlkDay = getNthWeekdayOfMonth(1, 1, 3);
  addHoliday(1, mlkDay, 'Martin Luther King Jr. Day', false);

  // 3. Washington's Birthday / Presidents' Day: 3rd Monday in February
  const presDay = getNthWeekdayOfMonth(2, 1, 3);
  addHoliday(2, presDay, "Presidents' Day", false);

  // 4. Memorial Day: Last Monday in May
  const memDay = getLastWeekdayOfMonth(5, 1);
  addHoliday(5, memDay, 'Memorial Day', false);

  // 5. Juneteenth National Independence Day: June 19
  addHoliday(6, 19, 'Juneteenth National Independence Day');

  // 6. Independence Day (4th of July): July 4
  addHoliday(7, 4, 'Independence Day (4th of July)');

  // 7. Labor Day: 1st Monday in September
  const laborDay = getNthWeekdayOfMonth(9, 1, 1);
  addHoliday(9, laborDay, 'Labor Day', false);

  // 8. Columbus Day / Indigenous Peoples' Day: 2nd Monday in October
  const columbusDay = getNthWeekdayOfMonth(10, 1, 2);
  addHoliday(10, columbusDay, 'Columbus Day', false);

  // 9. Veterans Day: November 11
  addHoliday(11, 11, 'Veterans Day');

  // 10. Thanksgiving Day: 4th Thursday in November
  const tgivingDay = getNthWeekdayOfMonth(11, 4, 4);
  addHoliday(11, tgivingDay, 'Thanksgiving Day', false);

  // Day after Thanksgiving / Black Friday (Common practice holiday)
  const dayAfterTgiving = tgivingDay + 1;
  addHoliday(11, dayAfterTgiving, 'Day after Thanksgiving', false);

  // 11. Christmas Day: December 25
  addHoliday(12, 25, 'Christmas Day');

  // Christmas Eve (December 24)
  addHoliday(12, 24, 'Christmas Eve', false);

  // New Year's Eve (December 31)
  addHoliday(12, 31, "New Year's Eve", false);

  return holidays;
}

/**
 * Checks if a Date is a US Federal Holiday or observed holiday.
 */
export function checkIsFederalHoliday(date: Date): { isHoliday: boolean; holidayName: string | null } {
  const year = date.getFullYear();
  const month = date.getMonth() + 1;
  const day = date.getDate();

  const mStr = month < 10 ? `0${month}` : `${month}`;
  const dStr = day < 10 ? `0${day}` : `${day}`;
  const dateKey = `${year}-${mStr}-${dStr}`;

  const holidays = getFederalHolidaysForYear(year);
  if (holidays[dateKey]) {
    return {
      isHoliday: true,
      holidayName: holidays[dateKey],
    };
  }

  return {
    isHoliday: false,
    holidayName: null,
  };
}
