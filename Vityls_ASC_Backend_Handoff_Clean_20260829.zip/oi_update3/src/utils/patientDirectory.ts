import { PatientCase } from '../types';

export interface MasterPatientRecord {
  id: string;
  patientId: string;
  name: string;
  firstName: string;
  lastName: string;
  dob: string;
  age: number | string;
  phone: string;
  gender?: string;
  procedure?: string;
  surgeon?: string;
  anesthesiologist?: string;
  anesthesiaType?: string;
  paymentType?: string;
  allergies?: string[];
  notes?: string;
  arrivalStatus?: string;
  room?: string;
}

export interface PatientAppointmentHistoryRecord {
  id: string;
  patientId: string;
  patientName: string;
  dob: string;
  age: string;
  phone: string;
  date: string;
  dayName: string;
  startTime: string;
  length: string;
  room: string;
  title: string;
  surgeon: string;
  anesthesiologist: string;
  anesthesiaType: string;
  procedure: string;
  paymentType: string;
  notes: string;
  status: 'Scheduled' | 'Completed' | 'Prior Visit' | 'Follow-Up';
  dayIndex?: number;
  caseId?: string;
  bgColor?: string;
  startHour?: number;
  durationHours?: number;
}

// BACKEND HANDOFF: no built-in patient directory.
export const MASTER_PATIENT_DIRECTORY: MasterPatientRecord[] = [];

export function parseFirstAndLastName(fullName: string): { firstName: string; lastName: string } {
  if (!fullName) return { firstName: '', lastName: '' };
  const cleaned = fullName.replace(/^(Dr\.|Mr\.|Mrs\.|Ms\.)\s+/i, '').trim();
  if (cleaned.includes(',')) {
    const parts = cleaned.split(',').map((p) => p.trim());
    return { lastName: parts[0] || '', firstName: parts[1] || '' };
  }
  const parts = cleaned.split(/\s+/);
  if (parts.length === 1) return { firstName: parts[0], lastName: parts[0] };
  return { firstName: parts.slice(0, -1).join(' '), lastName: parts[parts.length - 1] };
}

export function getAllMasterPatients(customCases: PatientCase[] = []): MasterPatientRecord[] {
  return customCases
    .filter((c) => Boolean(c.name))
    .map((c) => {
      const { firstName, lastName } = parseFirstAndLastName(c.name);
      return {
        id: c.id,
        patientId: c.patientId,
        name: c.name,
        firstName,
        lastName,
        dob: c.dob || '',
        age: c.age ?? '',
        phone: c.phone || '',
        gender: c.gender,
        procedure: c.procedure,
        surgeon: c.surgeon,
        anesthesiologist: c.anesthesiologist,
        allergies: c.allergies,
        notes: c.notes,
        arrivalStatus: c.arrivalStatus,
        room: c.room,
      };
    });
}

export function convertMasterRecordToPatientCase(
  m: MasterPatientRecord,
  existingCases: PatientCase[] = []
): PatientCase {
  const existing = existingCases.find(
    (c) => c.id === m.id || c.patientId === m.patientId || c.name.toLowerCase() === m.name.toLowerCase()
  );
  if (existing) return existing;

  const ageNum = typeof m.age === 'number' ? m.age : parseInt(String(m.age), 10) || 0;
  return {
    id: m.id,
    patientId: m.patientId,
    name: m.name,
    age: ageNum,
    gender: (m.gender as any) || 'Other',
    dob: m.dob || '',
    phone: m.phone || '',
    scheduledTime: '',
    estimatedDurationMins: 0,
    room: m.room || '',
    surgeon: m.surgeon || '',
    anesthesiologist: m.anesthesiologist || '',
    procedure: m.procedure || '',
    aiSummary: '',
    readinessScore: 0,
    readinessLevel: 'IN_PROGRESS',
    allergies: m.allergies || [],
    labs: [],
    stage: 'CHECK_IN',
    arrivalStatus: (m.arrivalStatus as any) || 'EN_ROUTE',
    arrivalTime: '',
    bottlenecks: [],
    actionItems: [],
    notes: m.notes || '',
  };
}

export function searchPatientsByLastName(
  query: string,
  customCases: PatientCase[] = [],
  options?: { minChars?: number; matchAnywhere?: boolean }
): MasterPatientRecord[] {
  const q = query.trim().toLowerCase();
  const minChars = options?.minChars ?? 3;
  if (q.length < minChars) return [];
  return getAllMasterPatients(customCases)
    .filter((patient) => {
      const cleanPhone = patient.phone.replace(/\D/g, '');
      const cleanQuery = q.replace(/\D/g, '');
      return (
        patient.lastName.toLowerCase().includes(q) ||
        patient.firstName.toLowerCase().includes(q) ||
        patient.name.toLowerCase().includes(q) ||
        patient.dob.toLowerCase().includes(q) ||
        patient.patientId.toLowerCase().includes(q) ||
        (cleanQuery.length >= 3 && cleanPhone.includes(cleanQuery))
      );
    })
    .sort((a, b) => a.lastName.localeCompare(b.lastName));
}

export function getPatientAppointmentHistory(
  patient: MasterPatientRecord,
  currentScheduleAppointments: any[] = []
): PatientAppointmentHistoryRecord[] {
  return currentScheduleAppointments
    .filter((apt) => {
      const aptPatientName = (apt.patientName || apt.title || '').toLowerCase();
      return (
        aptPatientName.includes(patient.lastName.toLowerCase().trim()) ||
        apt.caseId === patient.id ||
        apt.id === patient.patientId
      );
    })
    .map((apt) => ({
      id: apt.id || '',
      patientId: patient.patientId,
      patientName: patient.name,
      dob: apt.dob || patient.dob,
      age: `${apt.age ?? patient.age ?? ''}`,
      phone: apt.phone || patient.phone,
      date: apt.dos || apt.date || '',
      dayName: apt.dayName || '',
      startTime: apt.startTime || '',
      length: apt.length || '',
      room: apt.room || patient.room || '',
      title: apt.title || '',
      surgeon: apt.surgeon || patient.surgeon || '',
      anesthesiologist: apt.anesthesiologist || patient.anesthesiologist || '',
      anesthesiaType: apt.anesthesiaType || patient.anesthesiaType || '',
      procedure: apt.procedure || patient.procedure || '',
      paymentType: apt.paymentType || patient.paymentType || '',
      notes: apt.notes || '',
      status: apt.status || 'Scheduled',
      dayIndex: apt.dayIndex,
      caseId: apt.caseId || patient.id,
      bgColor: apt.bgColor,
      startHour: apt.startHour,
      durationHours: apt.durationHours,
    }));
}
