import { PortalMessage } from '../data/portalData';

// Multi-patient initial default seed messages for the entire practice network
export const SEED_PORTAL_MESSAGES: PortalMessage[] = [];

const STORAGE_PREFIX = 'portal_msgs_';
const ALL_MESSAGES_KEY = 'portal_all_messages_v2';
const EVENT_NAME = 'portal_messages_updated';

// Initialize global storage if not present
export function initMessageStore(): void {
  if (typeof window === 'undefined') return;

  const existingAll = localStorage.getItem(ALL_MESSAGES_KEY);
  if (!existingAll) {
    localStorage.setItem(ALL_MESSAGES_KEY, JSON.stringify(SEED_PORTAL_MESSAGES));
  }

  // Also seed per-patient keys for backwards compatibility with portal page
  const patientIds = Array.from(new Set(SEED_PORTAL_MESSAGES.map((m) => m.patientId)));
  patientIds.forEach((pid) => {
    const existing = localStorage.getItem(`${STORAGE_PREFIX}${pid}`);
    if (!existing) {
      const patientMsgs = SEED_PORTAL_MESSAGES.filter((m) => m.patientId === pid);
      localStorage.setItem(`${STORAGE_PREFIX}${pid}`, JSON.stringify(patientMsgs));
    }
  });
}

// Get all messages across the entire practice
export function getAllPortalMessages(): PortalMessage[] {
  if (typeof window === 'undefined') return SEED_PORTAL_MESSAGES;
  try {
    initMessageStore();
    const stored = localStorage.getItem(ALL_MESSAGES_KEY);
    if (stored) {
      return JSON.parse(stored);
    }
  } catch (err) {
    console.error('Failed to parse all portal messages', err);
  }
  return SEED_PORTAL_MESSAGES;
}

// Case ID to MRN normalization map
export function normalizePatientId(id?: string): string {
  if (!id) return '114202';
  const mapping: Record<string, string> = {
    'case-new-1': '115088',
    'case-0': '113561',
    'case-1': '114202',
    'case-2': '113850',
    'case-3': '114091',
    'case-4': '114320',
  };
  return mapping[id] || id;
}

// Get messages for a specific patient
export function getMessagesForPatient(patientId: string): PortalMessage[] {
  const normId = normalizePatientId(patientId);
  if (typeof window === 'undefined') {
    return SEED_PORTAL_MESSAGES.filter((m) => m.patientId === normId || m.patientId === patientId);
  }
  try {
    // Try normalized and raw per-patient keys
    const perPatient = localStorage.getItem(`${STORAGE_PREFIX}${normId}`) || localStorage.getItem(`${STORAGE_PREFIX}${patientId}`);
    if (perPatient) {
      return JSON.parse(perPatient);
    }

    // Fallback to filtering from all messages
    const all = getAllPortalMessages();
    const filtered = all.filter((m) => m.patientId === normId || m.patientId === patientId);
    if (filtered.length > 0) {
      localStorage.setItem(`${STORAGE_PREFIX}${normId}`, JSON.stringify(filtered));
      return filtered;
    }
  } catch (err) {
    console.error(`Failed to get messages for patient ${patientId}`, err);
  }
  return SEED_PORTAL_MESSAGES.filter((m) => m.patientId === normId || m.patientId === patientId);
}

// Save messages for a specific patient & update master store
export function saveMessagesForPatient(patientId: string, messages: PortalMessage[]): void {
  if (typeof window === 'undefined') return;
  const normId = normalizePatientId(patientId);
  try {
    localStorage.setItem(`${STORAGE_PREFIX}${normId}`, JSON.stringify(messages));
    if (normId !== patientId) {
      localStorage.setItem(`${STORAGE_PREFIX}${patientId}`, JSON.stringify(messages));
    }

    // Update the master list
    const all = getAllPortalMessages().filter((m) => m.patientId !== normId && m.patientId !== patientId);
    const updatedAll = [...all, ...messages];
    localStorage.setItem(ALL_MESSAGES_KEY, JSON.stringify(updatedAll));

    // Broadcast update event
    window.dispatchEvent(new CustomEvent(EVENT_NAME, { detail: { patientId: normId, rawId: patientId, messages } }));
  } catch (err) {
    console.error(`Failed to save messages for patient ${patientId}`, err);
  }
}

// Send a reply from provider/clinic staff to patient portal
export function sendProviderReply(
  patientId: string,
  replyData: {
    senderName: string;
    senderTitle?: string;
    providerId?: string;
    practiceName?: string;
    category?: PortalMessage['category'];
    content: string;
    attachment?: { name: string; size: string };
  }
): PortalMessage {
  const normId = normalizePatientId(patientId);
  const currentMessages = getMessagesForPatient(normId);
  const now = new Date();
  const timeStr = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  const dateStr = now.toLocaleDateString('en-US', { month: 'short', day: '2-digit', year: 'numeric' });

  const newMsg: PortalMessage = {
    id: `msg-staff-${Date.now()}`,
    patientId: normId,
    providerId: replyData.providerId || 'dr-sterling',
    practiceName: replyData.practiceName || 'Vityls ASC',
    sender: 'provider',
    senderName: replyData.senderName,
    senderTitle: replyData.senderTitle || 'Attending Clinical Staff',
    timestamp: timeStr,
    date: 'Today, ' + dateStr,
    category: replyData.category || 'Clinical Question',
    content: replyData.content.trim(),
    read: true,
    attachment: replyData.attachment
  };

  const updated = [...currentMessages, newMsg];
  saveMessagesForPatient(normId, updated);
  return newMsg;
}

// Send a message from patient to clinic
export function sendPatientMessage(
  patientId: string,
  msgData: {
    senderName: string;
    category?: PortalMessage['category'];
    content: string;
    providerId?: string;
    attachment?: { name: string; size: string };
  }
): PortalMessage {
  const normId = normalizePatientId(patientId);
  const currentMessages = getMessagesForPatient(normId);
  const now = new Date();
  const timeStr = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  const dateStr = now.toLocaleDateString('en-US', { month: 'short', day: '2-digit', year: 'numeric' });

  const newMsg: PortalMessage = {
    id: `msg-pt-${Date.now()}`,
    patientId: normId,
    providerId: msgData.providerId || 'dr-sterling',
    practiceName: 'Vityls ASC',
    sender: 'patient',
    senderName: msgData.senderName,
    timestamp: timeStr,
    date: 'Today, ' + dateStr,
    category: msgData.category || 'Clinical Question',
    content: msgData.content.trim(),
    read: false, // Unread for clinic staff
    attachment: msgData.attachment
  };

  const updated = [...currentMessages, newMsg];
  saveMessagesForPatient(normId, updated);
  return newMsg;
}

// Mark a message as read/unread
export function markMessageReadStatus(patientId: string, messageId: string, read: boolean): void {
  const currentMessages = getMessagesForPatient(patientId);
  const updated = currentMessages.map((m) => (m.id === messageId ? { ...m, read } : m));
  saveMessagesForPatient(patientId, updated);
}

// Delete a message
export function deletePortalMessage(patientId: string, messageId: string): void {
  const currentMessages = getMessagesForPatient(patientId);
  const updated = currentMessages.filter((m) => m.id !== messageId);
  saveMessagesForPatient(patientId, updated);
}

// Subscribe to message changes across components
export function subscribeToMessageUpdates(callback: (e?: CustomEvent) => void): () => void {
  if (typeof window === 'undefined') return () => {};

  const handler = (e: Event) => {
    callback(e as CustomEvent);
  };

  window.addEventListener(EVENT_NAME, handler);
  window.addEventListener('storage', handler);

  return () => {
    window.removeEventListener(EVENT_NAME, handler);
    window.removeEventListener('storage', handler);
  };
}

// Helper to get total unread messages across all patients or for one patient
export function getUnreadCount(patientId?: string): number {
  if (patientId) {
    const msgs = getMessagesForPatient(patientId);
    return msgs.filter((m) => m.sender === 'patient' && !m.read).length;
  }
  const all = getAllPortalMessages();
  return all.filter((m) => m.sender === 'patient' && !m.read).length;
}
