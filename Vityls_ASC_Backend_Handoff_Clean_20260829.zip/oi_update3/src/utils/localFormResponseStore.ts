export interface LocalFormResponse {
  practiceId: string;
  patientId: string;
  formId: string;
  formTitle: string;
  version: string;
  values: Record<string,string | boolean | string[]>;
  completedAt: string;
  completedBy: string;
  renderedHtml?: string;
}

const keyFor = (practiceId:string, patientId:string, formId:string) =>
  `oi-form-response:${practiceId}:${patientId}:${formId}`;

export function saveLocalFormResponse(response: LocalFormResponse): void {
  localStorage.setItem(keyFor(response.practiceId,response.patientId,response.formId), JSON.stringify(response));
  window.dispatchEvent(new CustomEvent('oi-form-response-updated',{detail:response}));
}

export function getLocalFormResponse(practiceId:string, patientId:string, formId:string): LocalFormResponse | null {
  try {
    const raw=localStorage.getItem(keyFor(practiceId,patientId,formId));
    return raw ? JSON.parse(raw) as LocalFormResponse : null;
  } catch { return null; }
}

export function listLocalFormResponses(practiceId:string, patientId:string): LocalFormResponse[] {
  const prefix=`oi-form-response:${practiceId}:${patientId}:`;
  const out:LocalFormResponse[]=[];
  for(let i=0;i<localStorage.length;i++){
    const k=localStorage.key(i);
    if(!k || !k.startsWith(prefix)) continue;
    try { const row=JSON.parse(localStorage.getItem(k) || ''); if(row) out.push(row); } catch {}
  }
  return out.sort((a,b)=>b.completedAt.localeCompare(a.completedAt));
}
