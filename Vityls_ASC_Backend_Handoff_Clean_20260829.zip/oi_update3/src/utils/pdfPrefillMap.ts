// Cross-document prefill for the two real-PDF anesthesia documents.
//
// The practice's own PDFs already name their fields well enough for a direct
// mapping on the fields that matter for this relationship: the anesthesiologist's
// Pre-Op Evaluation summarizes allergies, medications, height/weight, and past
// surgical history that the patient already entered on the Anesthesia
// Questionnaire. Everything else on the Pre-Op Eval (the physical exam
// findings, ASA class, plan) is the anesthesiologist's own clinical judgment
// and is intentionally left alone — it already opens pre-filled with the
// template's own "normal exam" boilerplate defaults (see pdfFormEngine's
// readPdfFieldDefaults), not something derived from the Questionnaire.
//
// The long, anonymously-numbered "Have you had..." checklist and the MH/VTE
// risk screener are NOT part of this mapping yet — those fields have no
// semantic field name to key off of, and turning 18 individual checkboxes
// into a one-line PMH summary is a separate, deliberate follow-up once this
// core relationship is proven out.

import { loadStoredPdfDoc } from './pdfFormEngine';

const QUESTIONNAIRE_DOC_ID = 'pdf-anesthesia-questionnaire';

function asText(v: string | boolean | undefined): string {
  return typeof v === 'string' ? v.trim() : '';
}

/**
 * Reads whatever the patient has entered so far on the Anesthesia
 * Questionnaire (draft or locked — either is fine, we just want the latest
 * answers) and derives the Pre-Op Evaluation's initial field values from it.
 * Returns undefined if the patient hasn't started the Questionnaire yet, so
 * the Pre-Op Eval simply falls back to its own template defaults.
 */
export function computePreopEvalPrefill(patientId: string): Record<string, string | boolean> | undefined {
  const stored = loadStoredPdfDoc(patientId, QUESTIONNAIRE_DOC_ID);
  if (!stored) return undefined;

  const q = stored.draft.fieldValues;
  const drugAllergies = asText(q['drugs All']);
  const foodAllergies = asText(q['food all']);
  const allergies = [drugAllergies, foodAllergies].filter(Boolean).join('; ');
  const medications = asText(q['drugs list']);
  const pastSurgery = asText(q['past surgery']);
  const pastHospital = asText(q['past hospital']);
  const psh = [pastSurgery, pastHospital].filter(Boolean).join('; ');

  const prefill: Record<string, string | boolean> = {};
  if (q['ht'] !== undefined) prefill['H'] = asText(q['ht']);
  if (q['wt'] !== undefined) prefill['W'] = asText(q['wt']);

  if (allergies) {
    prefill['ALL 1'] = allergies;
    prefill['NKDA'] = false;
  } else {
    prefill['NKDA'] = true;
  }

  if (medications) {
    prefill['MEDICATIONS1'] = medications;
    prefill['NMEDS'] = false;
  } else {
    prefill['NMEDS'] = true;
  }

  if (psh) {
    prefill['PSH'] = psh;
    prefill['NPSH'] = false;
  } else {
    prefill['NPSH'] = true;
  }

  return prefill;
}
