import { PatientCase } from '../types';

// BACKEND HANDOFF: schedule/case data is intentionally empty.
// Replace this adapter with the appointments/encounters API during backend integration.
export function getCasesForDateKey(_dateKey: string, _displayDate?: string): PatientCase[] {
  return [];
}
