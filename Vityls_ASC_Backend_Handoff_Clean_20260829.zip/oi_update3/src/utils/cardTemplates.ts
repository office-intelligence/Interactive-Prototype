// Helper utility to generate realistic SVG data URIs for mock Driver Licenses and Insurance Cards

export function generateSampleDriverLicense(
  name: string = 'SARAH WILSON',
  dob: string = '02/11/1972',
  dlNumber: string = 'C8910245',
  address: string = '435 N BEDFORD DR, BEVERLY HILLS, CA'
): string {
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="600" height="380" viewBox="0 0 600 380" fill="none">
    <rect width="600" height="380" rx="20" fill="url(#dl_grad)" stroke="#cbd5e1" stroke-width="3"/>
    <defs>
      <linearGradient id="dl_grad" x1="0" y1="0" x2="600" y2="380" gradientUnits="userSpaceOnUse">
        <stop stop-color="#f8fafc"/>
        <stop offset="0.5" stop-color="#f1f5f9"/>
        <stop offset="1" stop-color="#e2e8f0"/>
      </linearGradient>
    </defs>
    <!-- Header Banner -->
    <rect x="0" y="0" width="600" height="60" rx="20" fill="#1e3a8a"/>
    <rect x="0" y="40" width="600" height="20" fill="#1e3a8a"/>
    <text x="20" y="38" fill="#ffffff" font-family="sans-serif" font-weight="900" font-size="22" letter-spacing="2">CALIFORNIA</text>
    <text x="380" y="38" fill="#facc15" font-family="sans-serif" font-weight="800" font-size="16" letter-spacing="1">DRIVER LICENSE</text>

    <!-- Photo Placeholder -->
    <rect x="24" y="80" width="130" height="160" rx="10" fill="#cbd5e1" stroke="#94a3b8" stroke-width="2"/>
    <!-- Person Icon Silhouette -->
    <circle cx="89" cy="130" r="30" fill="#64748b"/>
    <path d="M 49 210 Q 89 170 129 210 Z" fill="#64748b"/>
    <rect x="24" y="245" width="130" height="25" rx="5" fill="#e2e8f0"/>
    <text x="89" y="262" text-anchor="middle" fill="#475569" font-family="sans-serif" font-size="10" font-weight="bold">REAL ID ★</text>

    <!-- Details -->
    <text x="175" y="95" fill="#1e293b" font-family="sans-serif" font-size="12" font-weight="bold">DL NO.</text>
    <text x="240" y="95" fill="#dc2626" font-family="monospace" font-size="16" font-weight="900">${dlNumber}</text>

    <text x="175" y="125" fill="#64748b" font-family="sans-serif" font-size="10" font-weight="bold">EXP</text>
    <text x="210" y="125" fill="#0f172a" font-family="sans-serif" font-size="12" font-weight="bold">02/11/2028</text>

    <text x="320" y="125" fill="#64748b" font-family="sans-serif" font-size="10" font-weight="bold">DOB</text>
    <text x="355" y="125" fill="#0f172a" font-family="sans-serif" font-size="12" font-weight="bold">${dob}</text>

    <text x="175" y="155" fill="#64748b" font-family="sans-serif" font-size="10" font-weight="bold">FN</text>
    <text x="200" y="155" fill="#0f172a" font-family="sans-serif" font-size="14" font-weight="900">${name}</text>

    <text x="175" y="185" fill="#64748b" font-family="sans-serif" font-size="10" font-weight="bold">ADDR</text>
    <text x="215" y="185" fill="#1e293b" font-family="sans-serif" font-size="11" font-weight="bold">${address}</text>

    <text x="175" y="215" fill="#64748b" font-family="sans-serif" font-size="10" font-weight="bold">CLASS</text>
    <text x="215" y="215" fill="#0f172a" font-family="sans-serif" font-size="12" font-weight="bold">C - NONE</text>

    <text x="320" y="215" fill="#64748b" font-family="sans-serif" font-size="10" font-weight="bold">SEX</text>
    <text x="350" y="215" fill="#0f172a" font-family="sans-serif" font-size="12" font-weight="bold">F</text>

    <text x="400" y="215" fill="#64748b" font-family="sans-serif" font-size="10" font-weight="bold">HAIR</text>
    <text x="435" y="215" fill="#0f172a" font-family="sans-serif" font-size="12" font-weight="bold">BRN</text>

    <!-- State Golden Seal watermark -->
    <circle cx="500" cy="140" r="45" fill="none" stroke="#f59e0b" stroke-width="2" stroke-dasharray="4 2"/>
    <text x="500" y="145" text-anchor="middle" fill="#d97706" font-family="sans-serif" font-size="10" font-weight="bold">STATE OF CA</text>

    <!-- Bottom Signature Area & Barcode -->
    <path d="M 175 255 Q 230 240 290 255 T 350 250" fill="none" stroke="#1e293b" stroke-width="2"/>
    <text x="175" y="275" fill="#94a3b8" font-family="sans-serif" font-size="9">CARDHOLDER SIGNATURE</text>

    <!-- Mock PDF417 2D Barcode representation -->
    <rect x="24" y="295" width="552" height="60" fill="#0f172a" rx="4"/>
    <line x1="40" y1="295" x2="40" y2="355" stroke="#ffffff" stroke-width="4"/>
    <line x1="60" y1="295" x2="60" y2="355" stroke="#ffffff" stroke-width="2"/>
    <line x1="75" y1="295" x2="75" y2="355" stroke="#ffffff" stroke-width="6"/>
    <line x1="95" y1="295" x2="95" y2="355" stroke="#ffffff" stroke-width="3"/>
    <line x1="120" y1="295" x2="120" y2="355" stroke="#ffffff" stroke-width="5"/>
    <line x1="150" y1="295" x2="150" y2="355" stroke="#ffffff" stroke-width="2"/>
    <line x1="180" y1="295" x2="180" y2="355" stroke="#ffffff" stroke-width="8"/>
    <line x1="220" y1="295" x2="220" y2="355" stroke="#ffffff" stroke-width="4"/>
    <line x1="250" y1="295" x2="250" y2="355" stroke="#ffffff" stroke-width="2"/>
    <line x1="280" y1="295" x2="280" y2="355" stroke="#ffffff" stroke-width="7"/>
    <line x1="320" y1="295" x2="320" y2="355" stroke="#ffffff" stroke-width="3"/>
    <line x1="360" y1="295" x2="360" y2="355" stroke="#ffffff" stroke-width="6"/>
    <line x1="410" y1="295" x2="410" y2="355" stroke="#ffffff" stroke-width="2"/>
    <line x1="450" y1="295" x2="450" y2="355" stroke="#ffffff" stroke-width="5"/>
    <line x1="500" y1="295" x2="500" y2="355" stroke="#ffffff" stroke-width="4"/>
    <line x1="540" y1="295" x2="540" y2="355" stroke="#ffffff" stroke-width="2"/>
  </svg>`;

  return `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`;
}

export function generateSampleInsuranceFront(
  name: string = 'SARAH WILSON',
  carrier: string = 'Blue Shield of California',
  memberId: string = 'XEN98127340',
  groupNumber: string = 'GRP-88120'
): string {
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="600" height="380" viewBox="0 0 600 380" fill="none">
    <rect width="600" height="380" rx="20" fill="url(#ins_front_grad)" stroke="#2563eb" stroke-width="3"/>
    <defs>
      <linearGradient id="ins_front_grad" x1="0" y1="0" x2="600" y2="380" gradientUnits="userSpaceOnUse">
        <stop stop-color="#ffffff"/>
        <stop offset="0.7" stop-color="#f0f9ff"/>
        <stop offset="1" stop-color="#e0f2fe"/>
      </linearGradient>
    </defs>

    <!-- Top Header Ribbon -->
    <rect x="0" y="0" width="600" height="70" rx="20" fill="#0284c7"/>
    <rect x="0" y="50" width="600" height="20" fill="#0284c7"/>
    
    <!-- Shield Logo Icon -->
    <path d="M 30 20 L 50 15 L 70 20 L 70 42 C 70 55 50 62 50 62 C 50 62 30 55 30 42 Z" fill="#ffffff"/>
    <text x="82" y="44" fill="#ffffff" font-family="sans-serif" font-weight="900" font-size="20" letter-spacing="1">${carrier.toUpperCase()}</text>
    <text x="450" y="44" fill="#e0f2fe" font-family="sans-serif" font-weight="800" font-size="13">PPO PREMIER</text>

    <!-- Subtitle -->
    <text x="30" y="100" fill="#0369a1" font-family="sans-serif" font-weight="bold" font-size="12">HEALTH BENEFIT PLAN</text>

    <!-- Member Name -->
    <text x="30" y="130" fill="#64748b" font-family="sans-serif" font-size="10" font-weight="bold">SUBSCRIBER NAME</text>
    <text x="30" y="152" fill="#0f172a" font-family="sans-serif" font-size="18" font-weight="900">${name.toUpperCase()}</text>

    <!-- Member ID and Group -->
    <rect x="30" y="170" width="260" height="60" rx="8" fill="#f1f5f9" stroke="#cbd5e1"/>
    <text x="45" y="190" fill="#64748b" font-family="sans-serif" font-size="10" font-weight="bold">MEMBER ID</text>
    <text x="45" y="215" fill="#0284c7" font-family="monospace" font-size="18" font-weight="900">${memberId}</text>

    <rect x="310" y="170" width="260" height="60" rx="8" fill="#f1f5f9" stroke="#cbd5e1"/>
    <text x="325" y="190" fill="#64748b" font-family="sans-serif" font-size="10" font-weight="bold">GROUP NUMBER</text>
    <text x="325" y="215" fill="#0f172a" font-family="monospace" font-size="18" font-weight="900">${groupNumber}</text>

    <!-- Copay Table -->
    <rect x="30" y="245" width="540" height="75" rx="10" fill="#f0f9ff" stroke="#bae6fd"/>
    <text x="45" y="268" fill="#0369a1" font-family="sans-serif" font-size="11" font-weight="bold">CO-PAYS & DEDUCTIBLES</text>
    
    <text x="45" y="295" fill="#475569" font-family="sans-serif" font-size="11">PCP: <tspan font-weight="bold" fill="#0f172a">$20</tspan></text>
    <text x="145" y="295" fill="#475569" font-family="sans-serif" font-size="11">SPEC: <tspan font-weight="bold" fill="#0f172a">$50</tspan></text>
    <text x="250" y="295" fill="#475569" font-family="sans-serif" font-size="11">OUTPATIENT SURG: <tspan font-weight="bold" fill="#0284c7">$150 / 10%</tspan></text>
    <text x="430" y="295" fill="#475569" font-family="sans-serif" font-size="11">EMERGENCY: <tspan font-weight="bold" fill="#0f172a">$250</tspan></text>

    <!-- Rx BIN / PCN -->
    <text x="30" y="348" fill="#64748b" font-family="sans-serif" font-size="10">RxBIN: <tspan font-weight="bold" fill="#0f172a">610014</tspan></text>
    <text x="160" y="348" fill="#64748b" font-family="sans-serif" font-size="10">RxPCN: <tspan font-weight="bold" fill="#0f172a">BCAL</tspan></text>
    <text x="280" y="348" fill="#64748b" font-family="sans-serif" font-size="10">RxGRP: <tspan font-weight="bold" fill="#0f172a">RX8812</tspan></text>

    <!-- Watermark Logo -->
    <circle cx="510" cy="115" r="30" fill="#e0f2fe" opacity="0.6"/>
  </svg>`;

  return `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`;
}

export function generateSampleInsuranceBack(
  carrier: string = 'Blue Shield of California',
  authPhone: string = '1-800-555-0199'
): string {
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="600" height="380" viewBox="0 0 600 380" fill="none">
    <rect width="600" height="380" rx="20" fill="#f8fafc" stroke="#94a3b8" stroke-width="3"/>
    
    <!-- Magnetic Strip -->
    <rect x="0" y="25" width="600" height="50" fill="#1e293b"/>

    <!-- Claims Notice -->
    <text x="30" y="100" fill="#0f172a" font-family="sans-serif" font-size="11" font-weight="bold">FOR PROVIDERS & OUTPATIENT SURGICAL CENTERS</text>
    <text x="30" y="118" fill="#475569" font-family="sans-serif" font-size="10">File all outpatient surgical & facility electronic claims via EDI Payer ID: <tspan font-weight="bold" fill="#0f172a">99201</tspan></text>

    <!-- Prior Auth Contact Box -->
    <rect x="30" y="135" width="540" height="85" rx="10" fill="#eff6ff" stroke="#bfdbfe"/>
    <text x="45" y="160" fill="#1e40af" font-family="sans-serif" font-size="12" font-weight="bold">PRIOR AUTHORIZATION & PRE-CERTIFICATION REQUIRED</text>
    <text x="45" y="180" fill="#5B6B60" font-family="sans-serif" font-size="11">Inpatient & Ambulatory Surgical Pre-Auth Line: <tspan font-weight="bold" fill="#1e3a8a">${authPhone}</tspan></text>
    <text x="45" y="200" fill="#5B6B60" font-family="sans-serif" font-size="11">24/7 Clinical Emergency Line: <tspan font-weight="bold" fill="#1e3a8a">1-888-555-9000</tspan></text>

    <!-- Claims Address -->
    <text x="30" y="245" fill="#0f172a" font-family="sans-serif" font-size="11" font-weight="bold">SUBMIT CLAIMS TO:</text>
    <text x="30" y="263" fill="#475569" font-family="sans-serif" font-size="10">${carrier} Claims Dept</text>
    <text x="30" y="278" fill="#475569" font-family="sans-serif" font-size="10">P.O. Box 272540, Sacramento, CA 95827-2540</text>

    <!-- Member Services -->
    <text x="320" y="245" fill="#0f172a" font-family="sans-serif" font-size="11" font-weight="bold">MEMBER CUSTOMER SERVICE:</text>
    <text x="320" y="263" fill="#475569" font-family="sans-serif" font-size="10">Phone: 1-800-888-2233 (TTY: 711)</text>
    <text x="320" y="278" fill="#475569" font-family="sans-serif" font-size="10">24/7 Nurse Advice: 1-800-888-0911</text>

    <!-- Bottom Barcode -->
    <rect x="150" y="305" width="300" height="40" fill="#0f172a" rx="4"/>
    <line x1="165" y1="305" x2="165" y2="345" stroke="#ffffff" stroke-width="3"/>
    <line x1="180" y1="305" x2="180" y2="345" stroke="#ffffff" stroke-width="1"/>
    <line x1="195" y1="305" x2="195" y2="345" stroke="#ffffff" stroke-width="4"/>
    <line x1="215" y1="305" x2="215" y2="345" stroke="#ffffff" stroke-width="2"/>
    <line x1="235" y1="305" x2="235" y2="345" stroke="#ffffff" stroke-width="5"/>
    <line x1="265" y1="305" x2="265" y2="345" stroke="#ffffff" stroke-width="2"/>
    <line x1="290" y1="305" x2="290" y2="345" stroke="#ffffff" stroke-width="6"/>
    <line x1="320" y1="305" x2="320" y2="345" stroke="#ffffff" stroke-width="3"/>
    <line x1="350" y1="305" x2="350" y2="345" stroke="#ffffff" stroke-width="4"/>
    <line x1="380" y1="305" x2="380" y2="345" stroke="#ffffff" stroke-width="2"/>
    <line x1="410" y1="305" x2="410" y2="345" stroke="#ffffff" stroke-width="5"/>
    <line x1="435" y1="305" x2="435" y2="345" stroke="#ffffff" stroke-width="2"/>
    <text x="300" y="360" text-anchor="middle" fill="#64748b" font-family="monospace" font-size="9">PA-2026-99182-CA</text>
  </svg>`;

  return `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`;
}
