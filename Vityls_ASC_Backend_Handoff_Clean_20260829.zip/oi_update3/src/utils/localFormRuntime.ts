import { LocalFormTemplate } from './localFormStudioDb';
import { IntakeHtmlForm } from '../data/intakeHtmlForms';

type BuilderField = {
  id: string; label: string; type: string; required?: boolean; owner?: string;
  options?: string[]; source?: string;
};

const esc = (v: unknown) => String(v ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c] || c));

function fieldHtml(field: BuilderField): string {
  const req = field.required ? ' required' : '';
  const label = `<label>${esc(field.label)}${field.required ? ' *' : ''}</label>`;
  const opts = (field.options || []).filter(Boolean);
  if (field.type === 'textarea') return `<div class="field">${label}<textarea name="${esc(field.id)}" rows="4"${req}></textarea></div>`;
  if (field.type === 'date') return `<div class="field">${label}<input type="date" name="${esc(field.id)}"${req}></div>`;
  if (field.type === 'signature') return `<div class="field">${label}<div class="signature-note">Signature is captured in the secure Office Intelligence signature panel.</div></div>`;
  if (field.type === 'checkbox' || field.type === 'radio') return `<fieldset class="field"><legend>${esc(field.label)}${field.required ? ' *' : ''}</legend>${opts.map((o,i)=>`<label class="choice"><input type="${field.type}" name="${esc(field.id)}${field.type==='checkbox'?`-${i}`:''}" value="${esc(o)}"> ${esc(o)}</label>`).join('')}</fieldset>`;
  if (field.type === 'select') return `<div class="field">${label}<select name="${esc(field.id)}"${req}><option value="">Select…</option>${opts.map(o=>`<option>${esc(o)}</option>`).join('')}</select></div>`;
  if (field.type === 'clinical-list') return `<div class="field">${label}<div class="chart-value">Shared chart value — verify/update in the patient record.</div></div>`;
  if (field.type === 'score') return `<div class="field">${label}<input type="number" name="${esc(field.id)}"${req}></div>`;
  return `<div class="field">${label}<input type="text" name="${esc(field.id)}"${req}></div>`;
}

/**
 * Full-width patient label modeled after the user's preferred hospital-style
 * document header. It is inserted at runtime so it is identical on HTML forms,
 * styled imported templates, and the future finalized PDF rendition.
 */
const PATIENT_HEADER = `
<section class="oi-patient-form-header" aria-label="Patient identification">
  <div class="oi-ph-top">
    <div class="oi-ph-name">{{patientNameUpper}}</div>
    <div class="oi-ph-mrn-top">MRN: {{patientId}}</div>
  </div>
  <div class="oi-ph-details">
    <div class="oi-ph-left">
      <div><strong>Attending Physician:</strong></div>
      <div class="oi-ph-provider">{{surgeon}}</div>
      <div class="oi-ph-spacer"></div>
      <div><strong>Facility:</strong> {{facility}}</div>
      <div><strong>Reason For Visit:</strong> {{reasonForVisit}}</div>
    </div>
    <div class="oi-ph-middle">
      <div><strong>MRN:</strong> {{patientId}}</div>
      <div class="oi-ph-spacer-small"></div>
      <div><strong>Encounter Date:</strong></div>
      <div>{{encounterDate}}</div>
    </div>
    <div class="oi-ph-right">
      <div><strong>DOB:</strong> {{dobDisplay}}</div>
      <div class="oi-ph-spacer-small"></div>
      <div><strong>Admit Age/Gender:</strong></div>
      <div>{{age}}Y/{{genderShort}}</div>
    </div>
  </div>
</section>`;

const HEADER_STYLE = `
<style id="oi-patient-form-header-style">
  .oi-patient-form-header{width:100%;box-sizing:border-box;background:#f7f7f7;border:1px solid #b8b8b8;color:#050505;font-family:Arial,Helvetica,sans-serif;margin:0 0 12px 0;page-break-inside:avoid}
  .oi-ph-top{display:flex;justify-content:space-between;align-items:center;gap:12px;padding:6px 10px;border-bottom:1px solid #b8b8b8;background:#fff}
  .oi-ph-name,.oi-ph-mrn-top{font-size:16px;font-weight:900;line-height:1.05;letter-spacing:.1px}
  .oi-ph-details{display:grid;grid-template-columns:1.45fr .9fr 1fr;gap:12px;padding:7px 10px 8px;font-size:11px;line-height:1.18}
  .oi-ph-details strong{font-weight:900}.oi-ph-provider{font-size:12px;margin-top:2px}.oi-ph-spacer{height:7px}.oi-ph-spacer-small{height:5px}
  @media(max-width:760px){.oi-ph-name,.oi-ph-mrn-top{font-size:14px}.oi-ph-details{grid-template-columns:1fr;font-size:10.5px;gap:5px}.oi-ph-provider{font-size:11px}.oi-ph-spacer,.oi-ph-spacer-small{height:2px}}
  @media print{.oi-patient-form-header{break-inside:avoid}.oi-ph-top{background:#fff}.oi-ph-details{background:#f6f6f6}}
</style>`;

function injectPatientHeader(html: string): string {
  if (!html) return html;
  // Avoid duplicating the header if a saved visual draft already contains it.
  if (html.includes('oi-patient-form-header')) return html;
  const insert = HEADER_STYLE + PATIENT_HEADER;
  if (/<body[^>]*>/i.test(html)) return html.replace(/(<body[^>]*>)/i, `$1${insert}`);
  return insert + html;
}

export function localTemplateToIntakeForm(form: LocalFormTemplate): IntakeHtmlForm {
  const fields=(form.fields || []) as BuilderField[];
  const signatureZones = fields.filter(f => f.type === 'signature').map(f => ({
    id: f.id,
    label: f.label || 'Signature',
    owner: f.owner,
    required: f.required !== false,
  }));

  const structuredHtml = `<!doctype html><html><head><meta charset="utf-8"><style>
      body{font-family:Arial,sans-serif;background:#f8fafc;color:#1c1917;padding:18px;margin:0}.page{max-width:980px;margin:auto;background:white;border:1px solid #d6d3d1;border-radius:12px;padding:28px;box-sizing:border-box}
      h1{font-size:22px;margin:0 0 22px}.field{margin:18px 0}label,legend{font-weight:700;font-size:13px;margin-bottom:6px;display:block}
      input[type=text],input[type=date],input[type=number],select,textarea{width:100%;box-sizing:border-box;padding:10px;border:1px solid #a8a29e;border-radius:6px}.choice{font-weight:400;display:block;margin:8px 0}
      .chart-value,.signature-note{padding:10px;background:#ecfdf5;border:1px solid #a7f3d0;border-radius:6px;font-size:12px}
    </style></head><body><div class="page">
      ${PATIENT_HEADER}
      <h1>${esc(form.title)}</h1>${fields.map(fieldHtml).join('')}
    </div>${HEADER_STYLE}</body></html>`;

  const sourceHtml = form.presentationHtml
    ? injectPatientHeader(form.presentationHtml)
    : structuredHtml;

  return {
    id: form.id,
    order: 1,
    title: form.title,
    category: form.collectionStage.includes('Anesthesia') ? 'Anesthesia' : form.collectionStage.includes('Home') ? 'Medical' : 'Admission',
    requiresSignature: signatureZones.length > 0,
    signatureZones,
    type: 'Form Studio Form',
    targetAudience: form.collectionStage,
    status: 'Pending Send',
    fileName: `${form.title.replace(/[^a-z0-9]+/gi,'_')}.html`,
    summary: `${form.collectionStage} · ${form.version}`,
    description: `Created in Clinical Form Studio. Verification: ${form.reviewStages?.join(' → ') || 'None'}.`,
    htmlTemplate: sourceHtml,
  };
}
