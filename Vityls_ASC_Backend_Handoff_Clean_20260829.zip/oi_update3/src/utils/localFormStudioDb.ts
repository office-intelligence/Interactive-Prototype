export interface LocalPractice {
  id: string;
  name: string;
  createdAt: string;
}

export type FormLifecycleStatus = 'Draft' | 'Active' | 'Superseded' | 'Retired';

export interface LocalFormTemplate {
  id: string;
  templateId?: string;
  practiceId: string;
  title: string;
  version: string;
  profile: string;
  collectionStage: string;
  reviewStages: string[];
  fields: unknown[];
  updatedAt: string;
  createdAt?: string;
  status?: FormLifecycleStatus;
  publishedAt?: string;
  supersededAt?: string;
  retiredAt?: string;
  basedOnId?: string;
  sourceTemplate?: string;
  sourceFile?: string;
  presentationHtml?: string;
  sourceCssPreserved?: boolean;
}

export interface LocalPdfTemplate {
  id: string;
  practiceId: string;
  title: string;
  version: string;
  status: 'Template' | 'Active' | 'Retired';
  collectionStage: string;
  reviewStages: string[];
  category: string;
  fileName: string;
  mimeType: string;
  uploadedAt: string;
  updatedAt: string;
  blob: Blob;
}

export interface LocalEncounterDocument {
  id: string;
  practiceId: string;
  patientId: string;
  encounterKey: string;
  title: string;
  sourceType: 'PDF_TEMPLATE' | 'PAPER_SCAN' | 'UPLOADED_PDF' | 'HTML_FINAL';
  templateId?: string;
  fileName: string;
  mimeType: string;
  uploadedAt: string;
  uploadedBy: string;
  blob?: Blob;
  aiStatus: 'Pending Review' | 'Summarized';
  reviewStatus?: 'Pending Review' | 'Reviewed';
  aiSummary: string;
  classification: string;
}

const DB_NAME = 'office-intelligence-local-test';
const DB_VERSION = 3;
const PRACTICES = 'practices';
const FORMS = 'forms';
const PDF_TEMPLATES = 'pdfTemplates';
const ENCOUNTER_DOCUMENTS = 'encounterDocuments';

function openDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(PRACTICES)) {
        db.createObjectStore(PRACTICES, { keyPath: 'id' });
      }
      if (!db.objectStoreNames.contains(FORMS)) {
        const store = db.createObjectStore(FORMS, { keyPath: 'id' });
        store.createIndex('practiceId', 'practiceId', { unique: false });
      }
      if (!db.objectStoreNames.contains(PDF_TEMPLATES)) {
        const store = db.createObjectStore(PDF_TEMPLATES, { keyPath: 'id' });
        store.createIndex('practiceId', 'practiceId', { unique: false });
      }
      if (!db.objectStoreNames.contains(ENCOUNTER_DOCUMENTS)) {
        const store = db.createObjectStore(ENCOUNTER_DOCUMENTS, { keyPath: 'id' });
        store.createIndex('practiceId', 'practiceId', { unique: false });
        store.createIndex('patientId', 'patientId', { unique: false });
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

function txDone(tx: IDBTransaction): Promise<void> {
  return new Promise((resolve, reject) => {
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
    tx.onabort = () => reject(tx.error);
  });
}

export async function listLocalPractices(): Promise<LocalPractice[]> {
  const db = await openDb();
  const tx = db.transaction(PRACTICES, 'readonly');
  const req = tx.objectStore(PRACTICES).getAll();
  const rows = await new Promise<LocalPractice[]>((resolve, reject) => {
    req.onsuccess = () => resolve(req.result as LocalPractice[]);
    req.onerror = () => reject(req.error);
  });
  db.close();
  return rows.sort((a, b) => a.createdAt.localeCompare(b.createdAt));
}

export async function createLocalPractice(name: string): Promise<LocalPractice> {
  const practice: LocalPractice = {
    id: `practice-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
    name: name.trim() || 'New Test Practice',
    createdAt: new Date().toISOString(),
  };
  const db = await openDb();
  const tx = db.transaction(PRACTICES, 'readwrite');
  tx.objectStore(PRACTICES).put(practice);
  await txDone(tx);
  db.close();
  return practice;
}

export async function listPracticeForms(practiceId: string): Promise<LocalFormTemplate[]> {
  const db = await openDb();
  const tx = db.transaction(FORMS, 'readonly');
  const index = tx.objectStore(FORMS).index('practiceId');
  const req = index.getAll(practiceId);
  const rows = await new Promise<LocalFormTemplate[]>((resolve, reject) => {
    req.onsuccess = () => resolve(req.result as LocalFormTemplate[]);
    req.onerror = () => reject(req.error);
  });
  db.close();
  return rows.sort((a, b) => b.updatedAt.localeCompare(a.updatedAt));
}

export async function savePracticeForm(form: LocalFormTemplate): Promise<void> {
  const db = await openDb();
  const tx = db.transaction(FORMS, 'readwrite');
  tx.objectStore(FORMS).put(form);
  await txDone(tx);
  db.close();
}

export async function deletePracticeForm(id: string): Promise<void> {
  const db = await openDb();
  const tx = db.transaction(FORMS, 'readwrite');
  tx.objectStore(FORMS).delete(id);
  await txDone(tx);
  db.close();
}


function normalizedTemplateId(form: LocalFormTemplate): string {
  return form.templateId || `legacy-${form.practiceId}-${form.title.trim().toLowerCase().replace(/[^a-z0-9]+/g,'-')}`;
}

export async function saveDraftForm(form: LocalFormTemplate): Promise<LocalFormTemplate> {
  const now = new Date().toISOString();
  const draft: LocalFormTemplate = {
    ...form,
    id: form.id || `form-${Date.now()}-${Math.random().toString(36).slice(2,7)}`,
    templateId: form.templateId || `template-${Date.now()}-${Math.random().toString(36).slice(2,7)}`,
    status: 'Draft',
    createdAt: form.createdAt || now,
    updatedAt: now,
  };
  await savePracticeForm(draft);
  return draft;
}

export async function publishPracticeForm(form: LocalFormTemplate): Promise<LocalFormTemplate> {
  const now = new Date().toISOString();
  const templateId = normalizedTemplateId(form);
  const db = await openDb();
  const tx = db.transaction(FORMS, 'readwrite');
  const store = tx.objectStore(FORMS);
  const index = store.index('practiceId');
  const req = index.getAll(form.practiceId);
  const rows = await new Promise<LocalFormTemplate[]>((resolve, reject) => {
    req.onsuccess = () => resolve(req.result as LocalFormTemplate[]);
    req.onerror = () => reject(req.error);
  });

  for (const row of rows) {
    const rowTemplateId = normalizedTemplateId(row);
    const sameFamily = rowTemplateId === templateId ||
      (!row.templateId && row.title.trim().toLowerCase() === form.title.trim().toLowerCase());
    if (sameFamily && row.status === 'Active') {
      store.put({ ...row, status: 'Superseded', supersededAt: now, updatedAt: now });
    }
  }

  const published: LocalFormTemplate = {
    ...form,
    id: form.id || `form-${Date.now()}-${Math.random().toString(36).slice(2,7)}`,
    templateId,
    status: 'Active',
    publishedAt: now,
    createdAt: form.createdAt || now,
    updatedAt: now,
  };
  store.put(published);
  await txDone(tx);
  db.close();
  return published;
}

export async function retirePracticeForm(id: string): Promise<void> {
  const db = await openDb();
  const tx = db.transaction(FORMS, 'readwrite');
  const store = tx.objectStore(FORMS);
  const req = store.get(id);
  const row = await new Promise<LocalFormTemplate | undefined>((resolve, reject) => {
    req.onsuccess = () => resolve(req.result as LocalFormTemplate | undefined);
    req.onerror = () => reject(req.error);
  });
  if (row) {
    const now = new Date().toISOString();
    store.put({ ...row, status: 'Retired', retiredAt: now, updatedAt: now });
  }
  await txDone(tx);
  db.close();
}

export async function getFormVersionHistory(practiceId: string, templateId: string, title?: string): Promise<LocalFormTemplate[]> {
  const rows = await listPracticeForms(practiceId);
  return rows.filter(row =>
    normalizedTemplateId(row) === templateId ||
    (!row.templateId && title && row.title.trim().toLowerCase() === title.trim().toLowerCase())
  ).sort((a,b)=>b.updatedAt.localeCompare(a.updatedAt));
}

export async function ensureLocalPractice(id: string, name: string): Promise<LocalPractice> {
  const db = await openDb();
  const tx = db.transaction(PRACTICES, 'readwrite');
  const store = tx.objectStore(PRACTICES);
  const existingReq = store.get(id);
  const existing = await new Promise<LocalPractice | undefined>((resolve, reject) => {
    existingReq.onsuccess = () => resolve(existingReq.result as LocalPractice | undefined);
    existingReq.onerror = () => reject(existingReq.error);
  });
  if (existing) { db.close(); return existing; }
  const practice: LocalPractice = { id, name, createdAt: new Date().toISOString() };
  store.put(practice);
  await txDone(tx);
  db.close();
  return practice;
}

export async function listCurrentPracticeForms(practiceId: string): Promise<LocalFormTemplate[]> {
  const rows = await listPracticeForms(practiceId);
  const families = new Map<string, LocalFormTemplate[]>();
  for (const row of rows) {
    const key = normalizedTemplateId(row);
    const group = families.get(key) || [];
    group.push(row);
    families.set(key, group);
  }

  const active: LocalFormTemplate[] = [];
  for (const group of families.values()) {
    const explicitActive = group
      .filter(r => r.status === 'Active')
      .sort((a,b)=>b.updatedAt.localeCompare(a.updatedAt))[0];
    if (explicitActive) { active.push(explicitActive); continue; }

    // Backward compatibility for older local test rows that predate lifecycle status.
    const legacy = group
      .filter(r => !r.status)
      .sort((a,b)=>b.updatedAt.localeCompare(a.updatedAt))[0];
    if (legacy) active.push(legacy);
  }
  return active.sort((a,b)=>a.title.localeCompare(b.title));
}


export async function listPdfTemplates(practiceId: string): Promise<LocalPdfTemplate[]> {
  const db = await openDb();
  const tx = db.transaction(PDF_TEMPLATES, 'readonly');
  const req = tx.objectStore(PDF_TEMPLATES).index('practiceId').getAll(practiceId);
  const rows = await new Promise<LocalPdfTemplate[]>((resolve, reject) => {
    req.onsuccess = () => resolve(req.result as LocalPdfTemplate[]);
    req.onerror = () => reject(req.error);
  });
  db.close();
  return rows.sort((a,b)=>b.updatedAt.localeCompare(a.updatedAt));
}

export async function savePdfTemplate(input: Omit<LocalPdfTemplate,'id'|'version'|'status'|'uploadedAt'|'updatedAt'>): Promise<LocalPdfTemplate> {
  const existing = await listPdfTemplates(input.practiceId);
  const sameTitle = existing.filter(x => x.title.trim().toLowerCase() === input.title.trim().toLowerCase());
  const major = sameTitle.length ? Math.max(...sameTitle.map(x => Number(x.version.replace(/^v/i,'').split('.')[0]) || 0)) + 1 : 1;
  const now = new Date().toISOString();
  const template: LocalPdfTemplate = {
    ...input,
    id: `pdf-template-${Date.now()}-${Math.random().toString(36).slice(2,7)}`,
    version: `v${major}.0`,
    status: 'Template',
    uploadedAt: now,
    updatedAt: now,
  };
  const db = await openDb();
  const tx = db.transaction(PDF_TEMPLATES, 'readwrite');
  const store = tx.objectStore(PDF_TEMPLATES);
  store.put(template);
  await txDone(tx);
  db.close();
  return template;
}

export async function retirePdfTemplate(id: string): Promise<void> {
  const db = await openDb();
  const tx = db.transaction(PDF_TEMPLATES, 'readwrite');
  const store = tx.objectStore(PDF_TEMPLATES);
  const req = store.get(id);
  const row = await new Promise<LocalPdfTemplate|undefined>((resolve,reject)=>{
    req.onsuccess=()=>resolve(req.result as LocalPdfTemplate|undefined);
    req.onerror=()=>reject(req.error);
  });
  if (row) store.put({ ...row, status:'Retired', updatedAt:new Date().toISOString() });
  await txDone(tx); db.close();
}

export async function saveEncounterDocument(input: Omit<LocalEncounterDocument,'id'|'uploadedAt'|'aiStatus'|'aiSummary'|'classification'> & {
  classification?: string; aiSummary?: string;
}): Promise<LocalEncounterDocument> {
  const now = new Date().toISOString();
  const doc: LocalEncounterDocument = {
    ...input,
    id:`enc-doc-${Date.now()}-${Math.random().toString(36).slice(2,7)}`,
    uploadedAt:now,
    aiStatus:'Pending Review',
    reviewStatus:'Pending Review',
    classification:input.classification || (
      /anesth/i.test(input.title) ? 'Anesthesia Record' :
      /consent/i.test(input.title) ? 'Consent' :
      /lab|cbc|bmp/i.test(input.title) ? 'Laboratory' :
      /ekg|ecg/i.test(input.title) ? 'EKG/ECG' :
      'Encounter Document'
    ),
    aiSummary:input.aiSummary || 'Nightingale has preserved the original document. Text extraction/classification is queued; staff review is required before any extracted facts are promoted into the structured chart.',
  };
  const db = await openDb();
  const tx = db.transaction(ENCOUNTER_DOCUMENTS,'readwrite');
  tx.objectStore(ENCOUNTER_DOCUMENTS).put(doc);
  await txDone(tx); db.close();
  return doc;
}

export async function listEncounterDocuments(practiceId: string, patientId: string): Promise<LocalEncounterDocument[]> {
  const db = await openDb();
  const tx = db.transaction(ENCOUNTER_DOCUMENTS,'readonly');
  const req = tx.objectStore(ENCOUNTER_DOCUMENTS).index('patientId').getAll(patientId);
  const rows = await new Promise<LocalEncounterDocument[]>((resolve,reject)=>{
    req.onsuccess=()=>resolve((req.result as LocalEncounterDocument[]).filter(x=>x.practiceId===practiceId));
    req.onerror=()=>reject(req.error);
  });
  db.close();
  return rows.sort((a,b)=>b.uploadedAt.localeCompare(a.uploadedAt));
}

export async function deleteEncounterDocument(id: string): Promise<void> {
  const db = await openDb();
  const tx = db.transaction(ENCOUNTER_DOCUMENTS,'readwrite');
  tx.objectStore(ENCOUNTER_DOCUMENTS).delete(id);
  await txDone(tx);
  db.close();
}

export async function updateEncounterDocumentReviewStatus(id: string, reviewStatus: 'Pending Review' | 'Reviewed'): Promise<void> {
  const db = await openDb();
  const tx = db.transaction(ENCOUNTER_DOCUMENTS,'readwrite');
  const store = tx.objectStore(ENCOUNTER_DOCUMENTS);
  const req = store.get(id);
  const row = await new Promise<LocalEncounterDocument|undefined>((resolve,reject)=>{
    req.onsuccess=()=>resolve(req.result as LocalEncounterDocument|undefined);
    req.onerror=()=>reject(req.error);
  });
  if (row) store.put({ ...row, reviewStatus });
  await txDone(tx); db.close();
}

export async function updateEncounterDocumentSummary(id: string, summary: string, classification?: string): Promise<void> {
  const db = await openDb();
  const tx = db.transaction(ENCOUNTER_DOCUMENTS,'readwrite');
  const store = tx.objectStore(ENCOUNTER_DOCUMENTS);
  const req = store.get(id);
  const row = await new Promise<LocalEncounterDocument|undefined>((resolve,reject)=>{
    req.onsuccess=()=>resolve(req.result as LocalEncounterDocument|undefined);
    req.onerror=()=>reject(req.error);
  });
  if (row) store.put({ ...row, aiStatus:'Summarized', aiSummary:summary, classification:classification || row.classification });
  await txDone(tx); db.close();
}

export function createLocalBlobUrl(blob?: Blob): string | null {
  return blob ? URL.createObjectURL(blob) : null;
}


export async function activatePdfTemplate(id: string, collectionStage?: string): Promise<void> {
  const db = await openDb();
  const tx = db.transaction(PDF_TEMPLATES,'readwrite');
  const store = tx.objectStore(PDF_TEMPLATES);
  const req = store.get(id);
  const row = await new Promise<LocalPdfTemplate|undefined>((resolve,reject)=>{
    req.onsuccess=()=>resolve(req.result as LocalPdfTemplate|undefined);
    req.onerror=()=>reject(req.error);
  });
  if (row) {
    const allReq=store.index('practiceId').getAll(row.practiceId);
    const all=await new Promise<LocalPdfTemplate[]>((resolve,reject)=>{
      allReq.onsuccess=()=>resolve(allReq.result as LocalPdfTemplate[]);
      allReq.onerror=()=>reject(allReq.error);
    });
    const now=new Date().toISOString();
    for(const other of all){
      if(other.id!==row.id && other.title.trim().toLowerCase()===row.title.trim().toLowerCase() && other.status==='Active'){
        store.put({...other,status:'Retired',updatedAt:now});
      }
    }
    store.put({...row,status:'Active',collectionStage:collectionStage || row.collectionStage,updatedAt:now});
  }
  await txDone(tx); db.close();
}

export async function updatePdfTemplateStage(id: string, collectionStage: string): Promise<void> {
  const db = await openDb();
  const tx = db.transaction(PDF_TEMPLATES,'readwrite');
  const store = tx.objectStore(PDF_TEMPLATES);
  const req = store.get(id);
  const row = await new Promise<LocalPdfTemplate|undefined>((resolve,reject)=>{
    req.onsuccess=()=>resolve(req.result as LocalPdfTemplate|undefined);
    req.onerror=()=>reject(req.error);
  });
  if(row) store.put({...row,collectionStage,updatedAt:new Date().toISOString()});
  await txDone(tx); db.close();
}

export async function replacePracticeForms(practiceId: string, forms: LocalFormTemplate[]): Promise<void> {
  const db=await openDb();
  const tx=db.transaction(FORMS,'readwrite');
  const store=tx.objectStore(FORMS);
  const index=store.index('practiceId');
  const req=index.openCursor(IDBKeyRange.only(practiceId));
  await new Promise<void>((resolve,reject)=>{
    req.onsuccess=()=>{
      const cursor=req.result;
      if(!cursor){resolve();return;}
      cursor.delete();
      cursor.continue();
    };
    req.onerror=()=>reject(req.error);
  });
  for(const form of forms) store.put(form);
  await txDone(tx);
  db.close();
}


export async function clearPracticeForms(practiceId: string): Promise<void> {
  const db=await openDb();
  const tx=db.transaction(FORMS,'readwrite');
  const store=tx.objectStore(FORMS);
  const index=store.index('practiceId');
  const req=index.openCursor(IDBKeyRange.only(practiceId));
  await new Promise<void>((resolve,reject)=>{
    req.onsuccess=()=>{
      const cursor=req.result;
      if(!cursor){resolve();return;}
      cursor.delete();
      cursor.continue();
    };
    req.onerror=()=>reject(req.error);
  });
  await txDone(tx);
  db.close();
}
