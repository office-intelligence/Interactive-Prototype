/**
 * Vityls ASC — backend handoff baseline.
 *
 * This file documents the intentional state of the frontend being handed to
 * backend development. It is configuration, not clinical data.
 */
export const BACKEND_HANDOFF = {
  product: 'Vityls ASC',
  edition: 'ASC',
  clinicalDataSeeded: false,
  aiClinicalSummariesSeeded: false,
  samplePortalDataSeeded: false,
  sampleMessagesSeeded: false,
  bundledPdfTemplatesSeeded: false,
  defaultHtmlTemplatesEnabled: true,
  defaultHtmlTemplateCount: 27,
  productionPersistenceRequired: true,
  localStorageProductionAllowed: false,
  indexedDbProductionAllowed: false,
  modules: {
    asc: true,
    portal: true,
    administration: true,
    formStudio: true,
    formsDocuments: true,
    nightingaleUi: true,
    mailConnector: false,
  },
} as const;
