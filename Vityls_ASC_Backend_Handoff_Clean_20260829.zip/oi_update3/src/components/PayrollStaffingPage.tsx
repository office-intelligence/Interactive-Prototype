import React, { useState } from 'react';
import {
  Users,
  Clock,
  Calendar,
  Lock,
  Unlock,
  UserPlus,
  CheckCircle2,
  AlertTriangle,
  Sparkles,
  KeyRound,
  Mail,
  UserX,
  ShieldAlert,
  Smartphone,
  X,
  ArrowRight,
  FileEdit,
  DollarSign,
} from 'lucide-react';
import {
  EmployeeProfile,
  TimeClockEntry,
  TimesheetPeriod,
  EmploymentStatus,
  PayClassification,
  AccountLockState,
  UserRoleTitle,
} from '../types';

interface PayrollStaffingPageProps {
  onShowToast?: (msg: string) => void;
}

type TabKey = 'directory' | 'timeclock' | 'timesheets';

/* ============================================================
   MOCK SEED DATA
   ============================================================ */

const seedEmployees: EmployeeProfile[] = [];

const seedTimeClock: TimeClockEntry[] = [];

const seedTimesheets: TimesheetPeriod[] = [];

const userRoleTitles: UserRoleTitle[] = [
  'Nurse',
  'Medical Assistant',
  'Front Office',
  'Practice Administrator',
  'Surgical Tech',
  'Billing Specialist',
  'Attending Physician',
  'Anesthesiologist',
  'Other',
];

const payClassifications: PayClassification[] = [
  'Hourly (Non-Exempt)',
  'Salaried (Exempt)',
  'Contractor / 1099',
];

/* ============================================================
   BADGE HELPERS
   ============================================================ */

function employmentStatusBadge(status: EmploymentStatus): { label: string; className: string } {
  switch (status) {
    case 'ACTIVE':
      return { label: 'Active', className: 'bg-[#E4F3EA] text-[#1B4332] border-[#2F9E6E]/40' };
    case 'ON_LEAVE':
      return { label: 'On Leave', className: 'bg-[#FBEEDB] text-[#7A4E17] border-[#C98A34]/40' };
    case 'SUSPENDED':
      return { label: 'Suspended', className: 'bg-[#FBE4E1] text-[#7A2E22] border-[#C1503D]/40' };
    case 'TERMINATED':
      return { label: 'Terminated', className: 'bg-[#F1F3EC] text-[#5B6B60] border-[#E1E4DC]' };
    case 'INVITED_PENDING':
      return { label: 'Invited — Pending', className: 'bg-[#E7F1F3] text-[#1D4E5A] border-[#3E8FA6]/40' };
    default:
      return { label: status, className: 'bg-[#F1F3EC] text-[#5B6B60] border-[#E1E4DC]' };
  }
}

function lockStateBadge(state: AccountLockState): { label: string; className: string } {
  switch (state) {
    case 'ACTIVE':
      return { label: 'Unlocked', className: 'bg-[#E4F3EA] text-[#1B4332] border-[#2F9E6E]/40' };
    case 'LOCKED_FAILED_LOGIN':
      return { label: 'Locked — Failed Logins', className: 'bg-[#FBE4E1] text-[#7A2E22] border-[#C1503D]/40' };
    case 'LOCKED_BY_ADMIN':
      return { label: 'Locked — By Admin', className: 'bg-[#FBE4E1] text-[#7A2E22] border-[#C1503D]/40' };
    case 'PENDING_INVITE':
      return { label: 'Invite Pending', className: 'bg-[#E7F1F3] text-[#1D4E5A] border-[#3E8FA6]/40' };
    default:
      return { label: state, className: 'bg-[#F1F3EC] text-[#5B6B60] border-[#E1E4DC]' };
  }
}

function timeClockStatusBadge(status: TimeClockEntry['status']): { label: string; className: string } {
  switch (status) {
    case 'CLOCKED_IN':
      return { label: 'Clocked In', className: 'bg-[#E4F3EA] text-[#1B4332] border-[#2F9E6E]/40' };
    case 'ON_BREAK':
      return { label: 'On Break', className: 'bg-[#ECFEFF] text-[#1D4E5A] border-[#A5F3FC]' };
    case 'CLOCKED_OUT':
      return { label: 'Clocked Out', className: 'bg-[#F1F3EC] text-[#5B6B60] border-[#E1E4DC]' };
    case 'MISSING_CLOCK_OUT':
      return { label: 'Missing Clock-Out', className: 'bg-[#FBE4E1] text-[#7A2E22] border-[#C1503D]/40' };
    default:
      return { label: status, className: 'bg-[#F1F3EC] text-[#5B6B60] border-[#E1E4DC]' };
  }
}

function timesheetStatusBadge(status: TimesheetPeriod['status']): { label: string; className: string } {
  switch (status) {
    case 'OPEN':
      return { label: 'Open', className: 'bg-[#F1F3EC] text-[#5B6B60] border-[#E1E4DC]' };
    case 'PENDING_APPROVAL':
      return { label: 'Pending Approval', className: 'bg-[#FBEEDB] text-[#7A4E17] border-[#C98A34]/40' };
    case 'APPROVED':
      return { label: 'Approved', className: 'bg-[#DCEEE3] text-[#1B4332] border-[#DCEEE3]' };
    case 'PROCESSED':
      return { label: 'Processed', className: 'bg-[#E7F1F3] text-[#1D4E5A] border-[#3E8FA6]/40' };
    case 'PAID':
      return { label: 'Paid', className: 'bg-[#E4F3EA] text-[#1B4332] border-[#2F9E6E]/40' };
    default:
      return { label: status, className: 'bg-[#F1F3EC] text-[#5B6B60] border-[#E1E4DC]' };
  }
}

function Badge({ label, className }: { label: string; className: string }) {
  return (
    <span className={`inline-flex items-center px-2.5 py-1 rounded-full text-[11px] font-semibold border ${className}`}>
      {label}
    </span>
  );
}

/* ============================================================
   MAIN COMPONENT
   ============================================================ */

export const PayrollStaffingPage: React.FC<PayrollStaffingPageProps> = ({ onShowToast }) => {
  const [activeTab, setActiveTab] = useState<TabKey>('directory');

  // Staff directory state
  const [employees, setEmployees] = useState<EmployeeProfile[]>(seedEmployees);
  const [isInviteModalOpen, setIsInviteModalOpen] = useState(false);
  const [inviteName, setInviteName] = useState('');
  const [inviteTitle, setInviteTitle] = useState<UserRoleTitle>('Medical Assistant');
  const [invitePayClass, setInvitePayClass] = useState<PayClassification>('Hourly (Non-Exempt)');
  const [inviteMobileAccess, setInviteMobileAccess] = useState(true);

  const [deactivateTarget, setDeactivateTarget] = useState<EmployeeProfile | null>(null);

  // Time clock state
  const [timeClockEntries, setTimeClockEntries] = useState<TimeClockEntry[]>(seedTimeClock);
  const [correctionOpenId, setCorrectionOpenId] = useState<string | null>(null);
  const [correctionNote, setCorrectionNote] = useState('');

  // Timesheets state
  const [timesheets, setTimesheets] = useState<TimesheetPeriod[]>(seedTimesheets);

  const notify = (msg: string) => {
    if (onShowToast) onShowToast(msg);
  };

  /* ---------------- Staff Directory actions ---------------- */

  const handleUnlockAccount = (id: string) => {
    setEmployees((prev) =>
      prev.map((e) => (e.id === id ? { ...e, accountLockState: 'ACTIVE' as AccountLockState } : e))
    );
    const emp = employees.find((e) => e.id === id);
    notify(`${emp?.name ?? 'Employee'}'s account has been unlocked.`);
  };

  const handleLockAccount = (id: string) => {
    setEmployees((prev) =>
      prev.map((e) => (e.id === id ? { ...e, accountLockState: 'LOCKED_BY_ADMIN' as AccountLockState } : e))
    );
    const emp = employees.find((e) => e.id === id);
    notify(`${emp?.name ?? 'Employee'}'s account has been locked.`);
  };

  const handleResetPassword = (id: string) => {
    const emp = employees.find((e) => e.id === id);
    notify(`Password reset link sent to ${emp?.name ?? 'employee'}.`);
  };

  const handleResendInvite = (id: string) => {
    const emp = employees.find((e) => e.id === id);
    notify(`Invitation resent to ${emp?.name ?? 'employee'}.`);
  };

  const handleConfirmDeactivate = () => {
    if (!deactivateTarget) return;
    setEmployees((prev) =>
      prev.map((e) =>
        e.id === deactivateTarget.id
          ? { ...e, employmentStatus: 'TERMINATED' as EmploymentStatus, accountLockState: 'LOCKED_BY_ADMIN' as AccountLockState }
          : e
      )
    );
    notify(`${deactivateTarget.name} has been deactivated. Historical timesheet and audit data is preserved.`);
    setDeactivateTarget(null);
  };

  const handleOpenInviteModal = () => {
    setInviteName('');
    setInviteTitle('Medical Assistant');
    setInvitePayClass('Hourly (Non-Exempt)');
    setInviteMobileAccess(true);
    setIsInviteModalOpen(true);
  };

  const handleSubmitInvite = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inviteName.trim()) return;
    const newEmployee: EmployeeProfile = {
      id: `emp-${Date.now()}`,
      userId: `usr-${Date.now()}`,
      name: inviteName.trim(),
      title: inviteTitle,
      employmentStatus: 'INVITED_PENDING',
      payClassification: invitePayClass,
      startDate: new Date().toISOString().slice(0, 10),
      mobileAccessEnabled: inviteMobileAccess,
      accountLockState: 'PENDING_INVITE',
    };
    setEmployees((prev) => [newEmployee, ...prev]);
    setIsInviteModalOpen(false);
    notify(`Invitation sent to ${newEmployee.name}.`);
  };

  /* ---------------- Time Clock actions ---------------- */

  const handleToggleCorrection = (id: string) => {
    setCorrectionOpenId((prev) => (prev === id ? null : id));
    setCorrectionNote('');
  };

  const handleSaveCorrection = (entry: TimeClockEntry) => {
    setTimeClockEntries((prev) =>
      prev.map((t) =>
        t.id === entry.id
          ? { ...t, flagReason: correctionNote.trim() ? correctionNote.trim() : t.flagReason }
          : t
      )
    );
    notify(`Correction note saved for ${entry.employeeName}.`);
    setCorrectionOpenId(null);
    setCorrectionNote('');
  };

  /* ---------------- Timesheets actions ---------------- */

  const handleApproveTimesheet = (id: string) => {
    setTimesheets((prev) =>
      prev.map((t) => (t.id === id ? { ...t, status: 'APPROVED' as TimesheetPeriod['status'], approvedBy: 'Office Manager', approvedAt: new Date().toLocaleString() } : t))
    );
    const period = timesheets.find((t) => t.id === id);
    notify(`${period?.periodLabel ?? 'Timesheet'} approved and sent to payroll.`);
  };

  /* ---------------- Derived AI summary ---------------- */

  const clockedInOnTime = timeClockEntries.filter((t) => t.status === 'CLOCKED_IN' || t.status === 'ON_BREAK' || t.status === 'CLOCKED_OUT').length;
  const pendingApprovalCount = timesheets.filter((t) => t.status === 'PENDING_APPROVAL').length;
  const lockedAccountsCount = employees.filter((e) => e.accountLockState === 'LOCKED_BY_ADMIN' || e.accountLockState === 'LOCKED_FAILED_LOGIN').length;

  const tabs: { key: TabKey; label: string; icon: React.ReactNode }[] = [
    { key: 'directory', label: 'Staff Directory', icon: <Users className="w-4 h-4" /> },
    { key: 'timeclock', label: 'Time Clock / Today', icon: <Clock className="w-4 h-4" /> },
    { key: 'timesheets', label: 'Timesheets', icon: <Calendar className="w-4 h-4" /> },
  ];

  return (
    <div className="min-h-screen bg-[#F1F3EC] p-4 sm:p-6 space-y-6">
      {/* ============================================================ */}
      {/* HEADER BAND                                                   */}
      {/* ============================================================ */}
      <div className="space-y-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-[#1A2E22] font-display tracking-tight">
            Payroll &amp; Staffing Command Center
          </h1>
          <p className="text-xs sm:text-sm text-[#5B6B60] mt-1">
            Manage employee accounts, review daily time clock activity, and approve biweekly timesheets before payroll runs.
          </p>
        </div>

        {/* AI Summary Strip */}
        <div className="bg-white rounded-xl border border-[#E1E4DC] p-4 sm:p-5 shadow-2xs">
          <div className="flex items-start gap-3">
            <div className="w-8 h-8 rounded-lg bg-[#DCEEE3] border border-[#E1E4DC] text-[#1F6E52] flex items-center justify-center shadow-2xs shrink-0">
              <Sparkles className="w-4 h-4 text-[#1F6E52]" />
            </div>
            <div className="space-y-1 min-w-0">
              <div className="flex items-center gap-1.5">
                <h2 className="text-sm font-bold text-[#1A2E22] font-display tracking-tight">
                  Nightingale AI staffing brief
                </h2>
                <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-[#DCEEE3] text-[#1B4332] border border-[#E1E4DC] font-mono">
                  AI
                </span>
              </div>
              <p className="text-xs text-[#1A2E22] leading-snug">
                {clockedInOnTime} of {timeClockEntries.length} employees clocked in on time today. {pendingApprovalCount > 0
                  ? `${pendingApprovalCount} timesheet${pendingApprovalCount === 1 ? '' : 's'} need${pendingApprovalCount === 1 ? 's' : ''} your approval before Friday's pay run.`
                  : 'No timesheets are currently awaiting approval.'} {lockedAccountsCount > 0
                  ? `${lockedAccountsCount} account${lockedAccountsCount === 1 ? ' is' : 's are'} locked after failed login attempts or admin action.`
                  : 'All employee accounts are currently unlocked.'}
              </p>
            </div>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex flex-wrap items-center gap-2 border-b border-[#E1E4DC]">
          {tabs.map((tab) => (
            <button
              key={tab.key}
              type="button"
              id={`payroll-tab-${tab.key}`}
              onClick={() => setActiveTab(tab.key)}
              className={`flex items-center gap-1.5 px-4 py-2.5 text-xs font-semibold border-b-2 -mb-px transition-colors cursor-pointer ${
                activeTab === tab.key
                  ? 'border-[#1F6E52] text-[#1F6E52]'
                  : 'border-transparent text-[#5B6B60] hover:text-[#1A2E22]'
              }`}
            >
              {tab.icon}
              <span>{tab.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* ============================================================ */}
      {/* TAB: STAFF DIRECTORY                                          */}
      {/* ============================================================ */}
      {activeTab === 'directory' && (
        <div className="bg-white rounded-2xl border border-[#E1E4DC] shadow-2xs p-5 sm:p-6 space-y-5">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[#E1E4DC] pb-4">
            <div>
              <h3 className="text-base font-bold text-[#1A2E22] flex items-center gap-2">
                <Users className="w-5 h-5 text-[#1F6E52]" />
                <span>Employee Accounts</span>
              </h3>
              <p className="text-xs text-[#5B6B60] mt-0.5">
                {employees.length} employee record{employees.length === 1 ? '' : 's'} on file.
              </p>
            </div>
            <button
              type="button"
              id="invite-employee-btn"
              onClick={handleOpenInviteModal}
              className="px-4 py-2 bg-[#1F6E52] hover:bg-[#17553F] text-white text-xs font-bold rounded-xl shadow-xs flex items-center gap-1.5 cursor-pointer transition-colors"
            >
              <UserPlus className="w-4 h-4" />
              <span>+ Invite Employee</span>
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-[#E1E4DC] bg-[#F1F3EC] text-[#5B6B60] font-bold uppercase tracking-wider text-[10px]">
                  <th className="py-3 px-4">Name / Title</th>
                  <th className="py-3 px-4">Employment</th>
                  <th className="py-3 px-4">Pay Classification</th>
                  <th className="py-3 px-4">Account</th>
                  <th className="py-3 px-4">Last Login</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#E1E4DC]">
                {employees.map((emp) => {
                  const empBadge = employmentStatusBadge(emp.employmentStatus);
                  const lockBadge = lockStateBadge(emp.accountLockState);
                  return (
                    <tr key={emp.id} id={`employee-row-${emp.id}`} className="hover:bg-[#F1F3EC] transition-colors">
                      <td className="py-3.5 px-4">
                        <div className="font-bold text-[#1A2E22]">{emp.name}</div>
                        <div className="text-[#5B6B60] text-[11px] mt-0.5">{emp.title}</div>
                      </td>
                      <td className="py-3.5 px-4">
                        <Badge label={empBadge.label} className={empBadge.className} />
                      </td>
                      <td className="py-3.5 px-4 text-[#5B6B60]">
                        <div className="flex items-center gap-1">
                          <DollarSign className="w-3 h-3 text-[#5B6B60]" />
                          <span>{emp.payClassification}</span>
                        </div>
                        {emp.mobileAccessEnabled && (
                          <div className="flex items-center gap-1 text-[10px] text-[#1F6E52] mt-1">
                            <Smartphone className="w-3 h-3" />
                            <span>Mobile access enabled</span>
                          </div>
                        )}
                      </td>
                      <td className="py-3.5 px-4">
                        <Badge label={lockBadge.label} className={lockBadge.className} />
                      </td>
                      <td className="py-3.5 px-4 text-[#5B6B60] text-[11px] font-mono">
                        {emp.lastLoginAt || '—'}
                      </td>
                      <td className="py-3.5 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5 flex-wrap">
                          {(emp.accountLockState === 'LOCKED_BY_ADMIN' || emp.accountLockState === 'LOCKED_FAILED_LOGIN') && (
                            <button
                              type="button"
                              id={`unlock-btn-${emp.id}`}
                              onClick={() => handleUnlockAccount(emp.id)}
                              className="px-2.5 py-1 rounded-lg bg-[#E4F3EA] hover:bg-[#D1FAE5] text-[#1B4332] font-semibold text-[11px] transition-colors cursor-pointer inline-flex items-center gap-1"
                            >
                              <Unlock className="w-3 h-3" />
                              <span>Unlock Account</span>
                            </button>
                          )}
                          {emp.accountLockState === 'ACTIVE' && emp.employmentStatus === 'ACTIVE' && (
                            <button
                              type="button"
                              id={`lock-btn-${emp.id}`}
                              onClick={() => handleLockAccount(emp.id)}
                              className="px-2.5 py-1 rounded-lg bg-[#F1F3EC] hover:bg-[#E1E4DC] text-[#5B6B60] font-semibold text-[11px] transition-colors cursor-pointer inline-flex items-center gap-1"
                            >
                              <Lock className="w-3 h-3" />
                              <span>Lock Account</span>
                            </button>
                          )}
                          {emp.accountLockState === 'PENDING_INVITE' ? (
                            <button
                              type="button"
                              id={`resend-invite-btn-${emp.id}`}
                              onClick={() => handleResendInvite(emp.id)}
                              className="px-2.5 py-1 rounded-lg bg-[#DCEEE3] hover:bg-[#DCEEE3] text-[#1B4332] font-semibold text-[11px] transition-colors cursor-pointer inline-flex items-center gap-1"
                            >
                              <Mail className="w-3 h-3" />
                              <span>Resend Invite</span>
                            </button>
                          ) : (
                            <button
                              type="button"
                              id={`reset-password-btn-${emp.id}`}
                              onClick={() => handleResetPassword(emp.id)}
                              className="px-2.5 py-1 rounded-lg bg-[#F1F3EC] hover:bg-[#E1E4DC] text-[#5B6B60] font-semibold text-[11px] transition-colors cursor-pointer inline-flex items-center gap-1"
                            >
                              <KeyRound className="w-3 h-3" />
                              <span>Reset Password</span>
                            </button>
                          )}
                          {emp.employmentStatus !== 'TERMINATED' && (
                            <button
                              type="button"
                              id={`deactivate-btn-${emp.id}`}
                              onClick={() => setDeactivateTarget(emp)}
                              className="p-1.5 text-[#5B6B60] hover:text-[#C1503D] transition-colors cursor-pointer inline-flex items-center"
                              title="Deactivate Employee"
                            >
                              <UserX className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ============================================================ */}
      {/* TAB: TIME CLOCK / TODAY                                       */}
      {/* ============================================================ */}
      {activeTab === 'timeclock' && (
        <div className="bg-white rounded-2xl border border-[#E1E4DC] shadow-2xs p-5 sm:p-6 space-y-5">
          <div className="border-b border-[#E1E4DC] pb-4">
            <h3 className="text-base font-bold text-[#1A2E22] flex items-center gap-2">
              <Clock className="w-5 h-5 text-[#1F6E52]" />
              <span>Today's Time Clock Activity</span>
            </h3>
            <p className="text-xs text-[#5B6B60] mt-0.5">
              Live clock-in / clock-out status for all staff scheduled today.
            </p>
          </div>

          <div className="space-y-3">
            {timeClockEntries.map((entry) => {
              const statusBadge = timeClockStatusBadge(entry.status);
              return (
                <div
                  key={entry.id}
                  id={`timeclock-row-${entry.id}`}
                  className={`rounded-xl border p-4 space-y-2 ${
                    entry.flaggedForReview ? 'border-[#C98A34]/40 bg-[#FBEEDB]/40' : 'border-[#E1E4DC] bg-white'
                  }`}
                >
                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <div>
                      <div className="font-bold text-[#1A2E22] text-sm">{entry.employeeName}</div>
                      <div className="text-[#5B6B60] text-[11px]">{entry.role}</div>
                    </div>
                    <div className="flex items-center gap-4 text-[11px] text-[#5B6B60]">
                      <div>
                        <span className="text-[#5B6B60]">In:</span> <span className="font-mono">{entry.clockIn}</span>
                      </div>
                      <div>
                        <span className="text-[#5B6B60]">Out:</span> <span className="font-mono">{entry.clockOut || '—'}</span>
                      </div>
                      <div>
                        <span className="text-[#5B6B60]">Break:</span> <span className="font-mono">{entry.breakMinutes}m</span>
                      </div>
                      {typeof entry.totalHours === 'number' && (
                        <div>
                          <span className="text-[#5B6B60]">Total:</span> <span className="font-mono">{entry.totalHours}h</span>
                        </div>
                      )}
                    </div>
                    <Badge label={statusBadge.label} className={statusBadge.className} />
                  </div>

                  {entry.flaggedForReview && (
                    <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-[#C98A34]/40">
                      <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-semibold bg-[#FBEEDB] text-[#7A4E17] border border-[#C98A34]/40">
                        <AlertTriangle className="w-3 h-3" />
                        <span>{entry.flagReason}</span>
                      </span>
                      <button
                        type="button"
                        id={`add-correction-btn-${entry.id}`}
                        onClick={() => handleToggleCorrection(entry.id)}
                        className="px-2.5 py-1 rounded-lg bg-[#F1F3EC] hover:bg-[#E1E4DC] text-[#5B6B60] font-semibold text-[11px] transition-colors cursor-pointer inline-flex items-center gap-1"
                      >
                        <FileEdit className="w-3 h-3" />
                        <span>Add Correction</span>
                      </button>
                    </div>
                  )}

                  {correctionOpenId === entry.id && (
                    <div className="pt-2 space-y-2">
                      <textarea
                        id={`correction-note-${entry.id}`}
                        value={correctionNote}
                        onChange={(e) => setCorrectionNote(e.target.value)}
                        placeholder="Add a note explaining the correction..."
                        rows={2}
                        className="w-full px-3 py-2 rounded-lg border border-[#E1E4DC] text-xs outline-hidden focus:border-[#1F6E52]"
                      />
                      <div className="flex items-center justify-end gap-2">
                        <button
                          type="button"
                          onClick={() => handleToggleCorrection(entry.id)}
                          className="px-3 py-1.5 rounded-lg text-xs font-semibold text-[#5B6B60] hover:bg-[#F1F3EC] cursor-pointer"
                        >
                          Cancel
                        </button>
                        <button
                          type="button"
                          id={`save-correction-btn-${entry.id}`}
                          onClick={() => handleSaveCorrection(entry)}
                          className="px-3 py-1.5 rounded-lg bg-[#1F6E52] hover:bg-[#17553F] text-white text-xs font-bold cursor-pointer"
                        >
                          Save Note
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* ============================================================ */}
      {/* TAB: TIMESHEETS                                               */}
      {/* ============================================================ */}
      {activeTab === 'timesheets' && (
        <div className="bg-white rounded-2xl border border-[#E1E4DC] shadow-2xs p-5 sm:p-6 space-y-5">
          <div className="border-b border-[#E1E4DC] pb-4">
            <h3 className="text-base font-bold text-[#1A2E22] flex items-center gap-2">
              <Calendar className="w-5 h-5 text-[#1F6E52]" />
              <span>Biweekly Timesheet Periods</span>
            </h3>
            <p className="text-xs text-[#5B6B60] mt-0.5">
              Review hours and exceptions, then approve to release to payroll processing.
            </p>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-[#E1E4DC] bg-[#F1F3EC] text-[#5B6B60] font-bold uppercase tracking-wider text-[10px]">
                  <th className="py-3 px-4">Pay Period</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4">Employees</th>
                  <th className="py-3 px-4">Regular / OT / PTO Hours</th>
                  <th className="py-3 px-4">Exceptions</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#E1E4DC]">
                {timesheets.map((period) => {
                  const statusBadge = timesheetStatusBadge(period.status);
                  return (
                    <tr key={period.id} id={`timesheet-row-${period.id}`} className="hover:bg-[#F1F3EC] transition-colors">
                      <td className="py-3.5 px-4">
                        <div className="font-bold text-[#1A2E22]">{period.periodLabel}</div>
                        {period.approvedBy && (
                          <div className="text-[10px] text-[#5B6B60] mt-0.5">
                            Approved by {period.approvedBy}{period.approvedAt ? ` — ${period.approvedAt}` : ''}
                          </div>
                        )}
                      </td>
                      <td className="py-3.5 px-4">
                        <Badge label={statusBadge.label} className={statusBadge.className} />
                      </td>
                      <td className="py-3.5 px-4 text-[#1A2E22] font-semibold">{period.employeeCount}</td>
                      <td className="py-3.5 px-4 text-[#5B6B60] font-mono text-[11px]">
                        {period.totalRegularHours}h / {period.totalOvertimeHours}h / {period.totalPtoHours}h
                      </td>
                      <td className="py-3.5 px-4">
                        {period.exceptionsCount > 0 ? (
                          <span className="inline-flex items-center gap-1 text-[#7A4E17] font-semibold">
                            <AlertTriangle className="w-3 h-3" />
                            {period.exceptionsCount} exception{period.exceptionsCount === 1 ? '' : 's'}
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 text-[#1B4332] font-semibold">
                            <CheckCircle2 className="w-3 h-3" />
                            None
                          </span>
                        )}
                      </td>
                      <td className="py-3.5 px-4 text-right">
                        {period.status === 'PENDING_APPROVAL' ? (
                          <button
                            type="button"
                            id={`approve-timesheet-btn-${period.id}`}
                            onClick={() => handleApproveTimesheet(period.id)}
                            className="px-3 py-1.5 rounded-lg bg-[#1F6E52] hover:bg-[#17553F] text-white text-[11px] font-bold cursor-pointer inline-flex items-center gap-1.5 transition-colors"
                          >
                            <span>Approve &amp; Send to Payroll</span>
                            <ArrowRight className="w-3 h-3" />
                          </button>
                        ) : (
                          <span className="text-[11px] text-[#5B6B60]">—</span>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ============================================================ */}
      {/* MODAL: INVITE EMPLOYEE                                        */}
      {/* ============================================================ */}
      {isInviteModalOpen && (
        <div className="fixed inset-0 z-50 bg-[#14432E]/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl border border-[#E1E4DC] shadow-2xl p-6 max-w-md w-full space-y-4">
            <div className="flex items-center justify-between border-b border-[#E1E4DC] pb-3">
              <h3 className="text-base font-bold text-[#1A2E22] flex items-center gap-2">
                <UserPlus className="w-5 h-5 text-[#1F6E52]" />
                <span>+ Invite Employee</span>
              </h3>
              <button
                type="button"
                id="close-invite-modal-btn"
                onClick={() => setIsInviteModalOpen(false)}
                className="text-[#5B6B60] hover:text-[#1A2E22] cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSubmitInvite} className="space-y-4">
              <div className="space-y-1">
                <label className="text-xs font-bold text-[#5B6B60]">Full Name <span className="text-[#C1503D]">*</span></label>
                <input
                  type="text"
                  id="invite-name-input"
                  required
                  value={inviteName}
                  onChange={(e) => setInviteName(e.target.value)}
                  placeholder="e.g. Jordan Lee"
                  className="w-full px-3 py-2 rounded-xl border border-[#E1E4DC] text-xs outline-hidden focus:border-[#1F6E52]"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-[#5B6B60]">Title / Role</label>
                <select
                  id="invite-title-select"
                  value={inviteTitle}
                  onChange={(e) => setInviteTitle(e.target.value as UserRoleTitle)}
                  className="w-full px-3 py-2 rounded-xl border border-[#E1E4DC] text-xs outline-hidden focus:border-[#1F6E52] bg-white"
                >
                  {userRoleTitles.map((title) => (
                    <option key={title} value={title}>
                      {title}
                    </option>
                  ))}
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-[#5B6B60]">Pay Classification</label>
                <select
                  id="invite-pay-classification-select"
                  value={invitePayClass}
                  onChange={(e) => setInvitePayClass(e.target.value as PayClassification)}
                  className="w-full px-3 py-2 rounded-xl border border-[#E1E4DC] text-xs outline-hidden focus:border-[#1F6E52] bg-white"
                >
                  {payClassifications.map((pc) => (
                    <option key={pc} value={pc}>
                      {pc}
                    </option>
                  ))}
                </select>
              </div>

              <div className="flex items-center justify-between p-3 rounded-xl border border-[#E1E4DC] bg-[#F1F3EC]">
                <div className="flex items-center gap-2">
                  <Smartphone className="w-4 h-4 text-[#5B6B60]" />
                  <span className="text-xs font-semibold text-[#1A2E22]">Enable mobile app access</span>
                </div>
                <button
                  type="button"
                  id="invite-mobile-access-toggle"
                  onClick={() => setInviteMobileAccess((v) => !v)}
                  className={`w-10 h-5.5 rounded-full transition-colors relative cursor-pointer ${
                    inviteMobileAccess ? 'bg-[#1F6E52]' : 'bg-[#E1E4DC]'
                  }`}
                >
                  <span
                    className={`absolute top-0.5 w-4.5 h-4.5 rounded-full bg-white shadow transition-transform ${
                      inviteMobileAccess ? 'translate-x-5' : 'translate-x-0.5'
                    }`}
                  />
                </button>
              </div>

              <div className="pt-3 border-t border-[#E1E4DC] flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsInviteModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-[#5B6B60] hover:bg-[#F1F3EC] cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  id="submit-invite-btn"
                  className="px-5 py-2 bg-[#1F6E52] hover:bg-[#17553F] text-white text-xs font-bold rounded-xl shadow-xs cursor-pointer"
                >
                  Send Invitation
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ============================================================ */}
      {/* MODAL: CONFIRM DEACTIVATE                                     */}
      {/* ============================================================ */}
      {deactivateTarget && (
        <div className="fixed inset-0 z-50 bg-[#14432E]/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl border border-[#E1E4DC] shadow-2xl p-6 max-w-md w-full space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-full bg-[#FBE4E1] border border-[#C1503D]/40 text-[#C1503D] flex items-center justify-center shrink-0">
                <ShieldAlert className="w-4.5 h-4.5" />
              </div>
              <h3 className="text-base font-bold text-[#1A2E22]">Deactivate {deactivateTarget.name}?</h3>
            </div>
            <p className="text-xs text-[#5B6B60] leading-relaxed">
              This will mark the employee as terminated and lock their account. Historical timesheet, payroll, and
              audit data will be <span className="font-semibold text-[#1A2E22]">preserved, not deleted</span>, and
              remains accessible for compliance and reporting purposes.
            </p>
            <div className="flex items-center justify-end gap-2 pt-2 border-t border-[#E1E4DC]">
              <button
                type="button"
                id="cancel-deactivate-btn"
                onClick={() => setDeactivateTarget(null)}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-[#5B6B60] hover:bg-[#F1F3EC] cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                id="confirm-deactivate-btn"
                onClick={handleConfirmDeactivate}
                className="px-5 py-2 bg-[#C1503D] hover:bg-[#DC2626] text-white text-xs font-bold rounded-xl shadow-xs cursor-pointer"
              >
                Deactivate Employee
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
