import React, { useState } from 'react';
import { FileText, Sparkles, Maximize2, Printer, CheckCircle2, ChevronRight, X } from 'lucide-react';
import { PatientCase } from '../types';

interface ClinicalPdfFormsViewProps {
  patient: PatientCase;
  onOpenElectronicForms?: () => void;
  dosDate?: string;
}

export const ClinicalPdfFormsView: React.FC<ClinicalPdfFormsViewProps> = ({
  patient,
  onOpenElectronicForms,
  dosDate = '05/06/2026',
}) => {
  const [activePdfFormTab, setActivePdfFormTab] = useState<'standing-orders' | 'preop-checklist' | 'surgical-checklist'>('standing-orders');
  const [isQuickModalOpen, setIsQuickModalOpen] = useState(false);

  return (
    <div className="space-y-6">
      {/* Header Bar */}
      <div className="flex flex-wrap items-center justify-between border-b border-stone-200/80 pb-3 gap-3">
        <div>
          <h3 className="font-bold text-sm text-stone-900 flex items-center gap-2">
            <FileText className="w-4 h-4 text-indigo-600" />
            <span>Converted Interactive HTML Clinical Assessment Forms</span>
            <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-bold border border-emerald-200">
              Nightingale AI Verified
            </span>
          </h3>
          <p className="text-xs text-stone-500 mt-0.5">
            Direct HTML reproductions of the attached Vityls ASC PDF records for {patient.name} (DOS: {dosDate})
          </p>
        </div>

        <div className="flex items-center gap-2">
          {onOpenElectronicForms && (
            <button
              onClick={onOpenElectronicForms}
              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-xl flex items-center gap-1.5 shadow-sm transition-colors cursor-pointer"
            >
              <Sparkles className="w-3.5 h-3.5 text-indigo-200" />
              <span>Open Electronic Forms Portal (9 Forms)</span>
            </button>
          )}
          <button
            onClick={() => setIsQuickModalOpen(true)}
            className="px-3.5 py-2 bg-stone-100 hover:bg-stone-200 text-stone-800 text-xs font-bold rounded-xl flex items-center gap-1.5 border border-stone-300 transition-colors cursor-pointer"
          >
            <Maximize2 className="w-3.5 h-3.5" />
            <span>Quick Modal</span>
          </button>
          <button
            onClick={() => window.print()}
            className="px-3 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 text-xs font-bold rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer border border-stone-200"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print</span>
          </button>
        </div>
      </div>

      {/* Interactive Sub-Tab Switcher inside Tab Content */}
      <div className="flex gap-2 bg-stone-100 p-1.5 rounded-2xl border border-stone-200 max-w-2xl">
        <button
          onClick={() => setActivePdfFormTab('standing-orders')}
          className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold transition-all cursor-pointer text-center ${
            activePdfFormTab === 'standing-orders'
              ? 'bg-white text-indigo-900 shadow-2xs border border-indigo-200'
              : 'text-stone-600 hover:text-stone-900'
          }`}
        >
          1. Doctors Standing Orders
        </button>
        <button
          onClick={() => setActivePdfFormTab('preop-checklist')}
          className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold transition-all cursor-pointer text-center ${
            activePdfFormTab === 'preop-checklist'
              ? 'bg-white text-indigo-900 shadow-2xs border border-indigo-200'
              : 'text-stone-600 hover:text-stone-900'
          }`}
        >
          2. Pre-Op Checklist & Assessment
        </button>
        <button
          onClick={() => setActivePdfFormTab('surgical-checklist')}
          className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold transition-all cursor-pointer text-center ${
            activePdfFormTab === 'surgical-checklist'
              ? 'bg-white text-indigo-900 shadow-2xs border border-indigo-200'
              : 'text-stone-600 hover:text-stone-900'
          }`}
        >
          3. Surgical Checklist
        </button>
      </div>

      {/* Form Display Canvas */}
      <div className="bg-stone-50/80 p-4 sm:p-6 rounded-2xl border border-stone-200">
        {activePdfFormTab === 'standing-orders' && (
          <div className="bg-white p-6 sm:p-8 rounded-xl border border-stone-300 shadow-sm space-y-6 max-w-2xl mx-auto">
            <div className="text-center space-y-1 border-b border-stone-300 pb-4">
              <h2 className="text-base font-bold tracking-wider uppercase text-stone-900">SUMMIT SURGICAL CENTER</h2>
              <p className="text-xs text-stone-600">416 N. Bedford Drive Suite 400B, Beverly Hills, CA 90210</p>
              <h3 className="text-sm font-bold tracking-wide uppercase pt-2 text-stone-800 underline">DOCTORS STANDING ORDERS</h3>
            </div>

            {/* Preoperative Orders */}
            <div className="space-y-3">
              <h4 className="font-bold text-xs uppercase tracking-wider text-stone-900 border-b border-stone-200 pb-1">PREOPERATIVE ORDERS</h4>
              <div className="space-y-2 text-xs">
                <div className="flex items-center gap-2">
                  <span className="w-4 h-4 bg-stone-900 text-white rounded flex items-center justify-center font-bold text-xs">✓</span>
                  <span className="font-semibold">History and Physical</span>
                </div>
                <div className="flex items-start gap-2">
                  <span className="w-4 h-4 bg-stone-900 text-white rounded flex items-center justify-center font-bold text-xs shrink-0 mt-0.5">✓</span>
                  <div>
                    <span className="font-semibold">Surgery Consents For: </span>
                    <span className="font-mono underline font-bold text-stone-900">{patient.procedure || 'Rhinoplasty & Septoplasty'}</span>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <span className="w-4 h-4 bg-stone-900 text-white rounded flex items-center justify-center font-bold text-xs">✓</span>
                  <span className="font-semibold">IV Per Anesthesia</span>
                </div>
                <div className="flex items-start gap-2">
                  <span className="w-4 h-4 bg-stone-900 text-white rounded flex items-center justify-center font-bold text-xs shrink-0 mt-0.5">✓</span>
                  <div>
                    <span className="font-semibold">Labs Ordered: </span>
                    <span>Hgb, Hct, CBC, UA, PT, PTT, Electrolytes, Chest X Ray, EKG, HIV, Hepatitis</span>
                  </div>
                </div>
                <div className="flex items-start gap-2">
                  <span className="w-4 h-4 bg-stone-900 text-white rounded flex items-center justify-center font-bold text-xs shrink-0 mt-0.5">✓</span>
                  <div>
                    <span className="font-semibold">PreOP Medication: </span>
                    <span className="font-mono underline font-bold text-stone-900">IV Ancef 1g</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Postoperative Orders */}
            <div className="space-y-3 border-t border-stone-300 pt-4">
              <h4 className="font-bold text-xs uppercase tracking-wider text-stone-900 border-b border-stone-200 pb-1">POSTOPERATIVE ORDERS</h4>
              <div className="space-y-2 text-xs">
                <div className="flex items-center gap-2">
                  <span className="w-4 h-4 bg-stone-900 text-white rounded flex items-center justify-center font-bold text-xs">✓</span>
                  <span className="font-semibold">Routine Vital Signs.</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="w-4 h-4 bg-stone-900 text-white rounded flex items-center justify-center font-bold text-xs">✓</span>
                  <span className="font-semibold">D/C IV when patient tolerating PO fluids without nausea and stable.</span>
                </div>
                <div className="flex items-start gap-2 pl-6">
                  <span className="font-semibold">Take home meds: </span>
                  <span className="font-mono underline font-bold text-stone-900">as prescribed by MD</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="w-4 h-4 bg-stone-900 text-white rounded flex items-center justify-center font-bold text-xs">✓</span>
                  <span className="font-semibold">D/C patient per Anesthesiologist</span>
                </div>
              </div>
            </div>

            {/* Signatures & Stamp Box */}
            <div className="border-t-2 border-stone-800 pt-4 grid grid-cols-2 gap-4 text-xs">
              <div className="space-y-2">
                <div><span className="font-bold">M.D. Signature:</span> <span className="font-serif italic font-bold text-indigo-900 underline">{patient.surgeon || 'Primary Provider'}</span></div>
                <div><span className="font-bold">Date:</span> <span className="underline font-bold">{dosDate}</span></div>
                <div><span className="font-bold">Noted by:</span> <span className="underline font-bold">Staff Member, RN</span></div>
              </div>

              <div className="p-3 bg-stone-100 rounded-lg border border-stone-400 text-[11px] font-mono space-y-0.5">
                <div className="font-bold border-b border-stone-300 pb-1">{patient.name} ({patient.patientId})</div>
                <div>DOB: {patient.dob || '02/11/1972'} | Age: {patient.age} | Sex: {patient.gender}</div>
                <div>Provider: {patient.surgeon || 'Primary Provider'}</div>
                <div>DOS: {dosDate}</div>
              </div>
            </div>
          </div>
        )}

        {activePdfFormTab === 'preop-checklist' && (
          <div className="bg-white p-6 sm:p-8 rounded-xl border border-stone-300 shadow-sm space-y-5 max-w-2xl mx-auto text-xs">
            <div className="text-center border-b-2 border-stone-800 pb-2">
              <h3 className="text-sm font-bold uppercase tracking-wide">Vityls ASC Pre-Operative Checklist and Assessment</h3>
            </div>

            <div className="grid grid-cols-2 gap-3 bg-stone-50 p-3 rounded-lg border border-stone-200">
              <div><span className="font-bold">Date:</span> <span className="underline font-mono">{dosDate}</span></div>
              <div><span className="font-bold">Patient:</span> <span className="underline font-bold">{patient.name}</span></div>
              <div><span className="font-bold">MRN:</span> <span className="underline font-mono">{patient.patientId}</span></div>
              <div><span className="font-bold">Surgeon:</span> <span className="underline">{patient.surgeon || 'Primary Provider'}</span></div>
            </div>

            {/* Vitals Banner */}
            <div className="p-3 bg-rose-50 border border-rose-300 rounded-lg space-y-1">
              <div className="font-bold text-rose-950 flex justify-between">
                <span>Admission Vitals: Ht: 5'5" | Wt: 128 lb | Temp: 36.8°C | BP: 118/76 | RR: 16 | SpO2: 99%</span>
              </div>
              <div className="text-rose-900 font-bold underline">
                Allergies: {patient.allergies?.join(', ') || 'NKDA'}
              </div>
            </div>

            {/* Pre-Op Checklist Table */}
            <div className="grid grid-cols-2 gap-4 border-t border-stone-300 pt-3">
              <div className="space-y-1.5">
                <div className="flex justify-between font-bold border-b border-stone-200 pb-1">
                  <span>Checklist Item</span>
                  <span>Status</span>
                </div>
                <div className="flex justify-between"><span>H&P in chart</span><span className="font-bold text-emerald-700">✓ Yes</span></div>
                <div className="flex justify-between"><span>Surgical consent signed</span><span className="font-bold text-emerald-700">✓ Yes</span></div>
                <div className="flex justify-between"><span>Patient verbalized site</span><span className="font-bold text-emerald-700">✓ Yes</span></div>
                <div className="flex justify-between"><span>NPO Time</span><span className="font-bold underline">Confirmed</span></div>
                <div className="flex justify-between"><span>Jewelry Removed</span><span className="font-bold text-emerald-700">✓ Yes</span></div>
              </div>

              <div className="space-y-1.5">
                <div className="flex justify-between font-bold border-b border-stone-200 pb-1">
                  <span>Pre-Op Meds</span>
                  <span>Admin Time</span>
                </div>
                <div className="flex justify-between"><span>IV Cefazolin 2g</span><span className="font-mono">07:45 AM</span></div>
                <div className="flex justify-between"><span>Celebrex 200mg</span><span className="font-mono">07:30 AM</span></div>
                <div className="flex justify-between"><span>Valium 5mg PO</span><span className="font-mono">07:40 AM</span></div>
                <div className="flex justify-between"><span>SCDs Applied</span><span className="font-bold text-emerald-700">✓ Yes</span></div>
              </div>
            </div>
          </div>
        )}

        {activePdfFormTab === 'surgical-checklist' && (
          <div className="bg-white p-6 sm:p-8 rounded-xl border border-stone-300 shadow-sm space-y-5 max-w-2xl mx-auto text-xs">
            <div className="text-center border-b-2 border-stone-800 pb-2">
              <h3 className="text-sm font-bold uppercase tracking-wide">AORN / WHO Comprehensive Surgical Safety Checklist</h3>
            </div>

            <div className="grid grid-cols-3 gap-3">
              <div className="p-3 bg-stone-50 rounded-lg border border-stone-300 space-y-2">
                <div className="font-bold text-stone-900 uppercase border-b border-stone-200 pb-1 text-[11px]">Before Induction (Sign-In)</div>
                <div className="space-y-1 text-[11px]">
                  <div>Anesthesia: <span className="font-bold underline">{patient.anesthesiologist || 'Anesthesia Provider'}</span></div>
                  <div className="text-rose-700 font-bold">✓ Allergy Checked</div>
                  <div className="text-emerald-700 font-bold">✓ Difficult Airway: No</div>
                  <div className="text-emerald-700 font-bold">✓ Equipment Ready</div>
                  <div className="text-emerald-700 font-bold">✓ SCD On</div>
                </div>
              </div>

              <div className="p-3 bg-stone-50 rounded-lg border border-stone-300 space-y-2">
                <div className="font-bold text-stone-900 uppercase border-b border-stone-200 pb-1 text-[11px]">Before Incision (Time-Out)</div>
                <div className="space-y-1 text-[11px]">
                  <div>Surgeon: <span className="font-bold underline">{patient.surgeon || 'Primary Provider'}</span></div>
                  <div className="text-emerald-700 font-bold">✓ Time-Out Executed</div>
                  <div className="text-emerald-700 font-bold">✓ Antibiotics Given</div>
                  <div className="text-emerald-700 font-bold">✓ Sterilization Confirm</div>
                  <div className="text-emerald-700 font-bold">✓ Images Displayed</div>
                </div>
              </div>

              <div className="p-3 bg-stone-50 rounded-lg border border-stone-300 space-y-2">
                <div className="font-bold text-stone-900 uppercase border-b border-stone-200 pb-1 text-[11px]">Before Leaving OR (Sign-Out)</div>
                <div className="space-y-1 text-[11px]">
                  <div>RN: <span className="font-bold underline">Camila Rojas, RN</span></div>
                  <div className="text-emerald-700 font-bold">✓ Procedure Name</div>
                  <div className="text-emerald-700 font-bold">✓ Counts Complete</div>
                  <div className="text-emerald-700 font-bold">✓ Specimens Labeled</div>
                  <div className="text-emerald-700 font-bold">✓ PACU Transfer Ready</div>
                </div>
              </div>
            </div>

            <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-lg text-center font-bold text-emerald-900">
              Surgical Safety Verification Complete · All Audit Gateways Signed for {patient.name}
            </div>
          </div>
        )}
      </div>

      {/* Quick Modal Lightbox */}
      {isQuickModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-3xl rounded-3xl shadow-2xl overflow-hidden border border-stone-200 p-6 space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-stone-200 pb-3">
              <h3 className="font-bold text-stone-900 text-sm">Quick Modal — Clinical PDF Forms Viewer</h3>
              <button
                onClick={() => setIsQuickModalOpen(false)}
                className="p-1.5 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-600 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <p className="text-xs text-stone-600">
              High-resolution digital view of converted forms for {patient.name} ({patient.patientId}).
            </p>
            <div className="p-4 bg-stone-50 rounded-2xl border border-stone-200 text-xs space-y-2">
              <div className="font-bold text-stone-900">1. Doctors Standing Orders — Signed by {patient.surgeon}</div>
              <div className="font-bold text-stone-900">2. Pre-Op Nursing Assessment — Vitals & Clearances Verified</div>
              <div className="font-bold text-stone-900">3. WHO Surgical Safety Time-Out Checklist — 4 Gateways Passed</div>
            </div>
            <div className="flex justify-end gap-2 pt-2">
              {onOpenElectronicForms && (
                <button
                  onClick={() => {
                    setIsQuickModalOpen(false);
                    onOpenElectronicForms();
                  }}
                  className="px-4 py-2 bg-indigo-600 text-white rounded-xl text-xs font-bold cursor-pointer hover:bg-indigo-700"
                >
                  Open Full Electronic Forms Portal
                </button>
              )}
              <button
                onClick={() => setIsQuickModalOpen(false)}
                className="px-4 py-2 bg-stone-100 text-stone-800 rounded-xl text-xs font-bold cursor-pointer hover:bg-stone-200"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
