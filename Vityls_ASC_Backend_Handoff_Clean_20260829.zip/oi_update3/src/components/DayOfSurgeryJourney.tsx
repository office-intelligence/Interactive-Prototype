import React from 'react';
import { AlertTriangle, CheckCircle2, ChevronRight, Circle, Clock3, ShieldCheck } from 'lucide-react';
import type { PatientCase } from '../types';
import type { LocalFormTemplate, LocalPdfTemplate } from '../utils/localFormStudioDb';

type StepState = 'complete' | 'attention' | 'pending' | 'blocked';

interface Props {
  patient: PatientCase;
  htmlForms: LocalFormTemplate[];
  pdfForms: LocalPdfTemplate[];
  onOpenPreArrival: () => void;
  onOpenCheckIn: () => void;
  onOpenNursing: () => void;
  onOpenAnesthesia: () => void;
  onOpenSurgeon: () => void;
  onOpenPacu: () => void;
  onOpenFinal: () => void;
}

export const DayOfSurgeryJourney: React.FC<Props> = ({
  patient, htmlForms, pdfForms,
  onOpenPreArrival, onOpenCheckIn, onOpenNursing, onOpenAnesthesia, onOpenSurgeon, onOpenPacu, onOpenFinal,
}) => {
  const journey=patient.encounterWorkflow?.status || 'ARRIVED';
  const hasCriticalLab=patient.labs?.some(l=>l.status==='critical') || false;
  const portalComplete=patient.checkInStatus==='PORTAL_COMPLETE' || patient.checkInStatus==='OFFICE_VERIFIED';
  const officeVerified=patient.checkInStatus==='OFFICE_VERIFIED';
  const inOrOrLater=['READY_FOR_OR','IN_OR','PACU','READY_FOR_DISCHARGE','DISCHARGED','RECORD_COMPLETION','CASE_COMPLETE'].includes(journey);
  const pacuOrLater=['PACU','READY_FOR_DISCHARGE','DISCHARGED','RECORD_COMPLETION','CASE_COMPLETE'].includes(journey);
  const discharged=['DISCHARGED','RECORD_COMPLETION','CASE_COMPLETE'].includes(journey);

  const countFor=(stages:string[]) =>
    htmlForms.filter(f=>stages.includes(f.collectionStage)).length +
    pdfForms.filter(f=>f.status==='Active' && stages.includes(f.collectionStage)).length;

  const steps:Array<{
    id:string; title:string; owner:string; state:StepState; forms:number; action:()=>void;
  }>=[
    { id:'prearrival', title:'1. Pre-arrival Intake', owner:'Patient + Front Office', state:portalComplete?'complete':'attention', forms:countFor(['Home / Patient Portal']), action:onOpenPreArrival },
    { id:'checkin', title:'2. Arrival & Check-in', owner:'Front Office', state:officeVerified || !['ARRIVED','CHECKING_IN'].includes(journey)?'complete':'attention', forms:countFor(['Front Desk']), action:onOpenCheckIn },
    { id:'nursing', title:'3. Pre-op Nursing', owner:'Nursing', state:hasCriticalLab?'blocked':['READY_FOR_ANESTHESIA','ANESTHESIA_EVALUATION','READY_FOR_OR','IN_OR','PACU','READY_FOR_DISCHARGE','DISCHARGED','RECORD_COMPLETION','CASE_COMPLETE'].includes(journey)?'complete':journey==='PREOP_NURSING'?'attention':'pending', forms:countFor(['Nursing']), action:onOpenNursing },
    { id:'anesthesia', title:'4. Anesthesia Readiness', owner:'Anesthesia', state:hasCriticalLab?'blocked':inOrOrLater?'complete':['READY_FOR_ANESTHESIA','ANESTHESIA_EVALUATION'].includes(journey)?'attention':'pending', forms:countFor(['Anesthesia']), action:onOpenAnesthesia },
    { id:'surgeon', title:'5. Surgeon / Procedure', owner:'Surgeon + OR', state:inOrOrLater?'complete':['READY_FOR_OR'].includes(journey)?'attention':'pending', forms:countFor(['Surgeon','OR Team']), action:onOpenSurgeon },
    { id:'pacu', title:'6. PACU & Discharge', owner:'PACU / Nursing', state:discharged?'complete':pacuOrLater?'attention':'pending', forms:countFor(['PACU']), action:onOpenPacu },
    { id:'final', title:'7. Final Case Record', owner:'Nightingale + Admin', state:journey==='CASE_COMPLETE'?'complete':discharged?'attention':'pending', forms:0, action:onOpenFinal },
  ];

  const complete=steps.filter(s=>s.state==='complete').length;

  const icon=(state:StepState)=>{
    if(state==='complete') return <CheckCircle2 className="w-4 h-4 text-emerald-700"/>;
    if(state==='blocked') return <AlertTriangle className="w-4 h-4 text-rose-700"/>;
    if(state==='attention') return <Clock3 className="w-4 h-4 text-amber-700"/>;
    return <Circle className="w-4 h-4 text-stone-400"/>;
  };
  const cls=(state:StepState)=>
    state==='complete'?'border-emerald-200 bg-emerald-50/70':
    state==='blocked'?'border-rose-200 bg-rose-50/70':
    state==='attention'?'border-amber-200 bg-amber-50/70':
    'border-stone-200 bg-white';

  return (
    <section id="day-of-surgery-journey-section" className="bg-white rounded-2xl border border-stone-200/90 shadow-2xs overflow-hidden">
      <div className="px-4 py-3 border-b border-stone-200 flex items-center justify-between gap-3">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-slate-900 text-white flex items-center justify-center"><ShieldCheck className="w-4 h-4"/></div>
          <div>
            <h3 className="text-sm font-black text-stone-900">Day of Surgery Journey</h3>
            <p className="text-[11px] text-stone-500 mt-0.5">Seven encounter stages · select a box to open the forms/workflow for completion.</p>
          </div>
        </div>
        <span className="px-2.5 py-1 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-200 text-[10px] font-black">{complete}/7 complete</span>
      </div>
      <div className="p-3 grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-2.5">
        {steps.map(step=><button key={step.id} onClick={step.action} className={`text-left rounded-xl border p-3 hover:shadow-sm transition-all ${cls(step.state)}`}>
          <div className="flex items-start justify-between gap-2">
            <div className="flex items-center gap-2 min-w-0">{icon(step.state)}<div className="text-xs font-black text-stone-900 truncate">{step.title}</div></div>
            <ChevronRight className="w-4 h-4 text-stone-400 shrink-0"/>
          </div>
          <div className="text-[10px] text-stone-500 mt-2">{step.owner}</div>
          <div className="flex items-center justify-between gap-2 mt-2">
            <span className="text-[9px] uppercase tracking-wide font-black text-stone-500">{step.state==='complete'?'Complete':step.state==='attention'?'Needs attention':step.state==='blocked'?'Blocked':'Not started'}</span>
            {step.forms>0 && <span className="text-[9.5px] font-bold text-indigo-700">{step.forms} form{step.forms===1?'':'s'}</span>}
          </div>
        </button>)}
      </div>
    </section>
  );
};
