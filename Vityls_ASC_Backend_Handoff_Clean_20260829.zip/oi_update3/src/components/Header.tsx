import React, { useState, useRef, useEffect } from 'react';
import { 
  Sparkles,
  Zap,
  RefreshCw, 
  Plus, 
  Check, 
  LogOut,
  ShieldCheck,
  ChevronDown,
  KeyRound,
  Eye,
  EyeOff,
  CheckCircle2,
  Lock,
  Users,
  Activity,
  Sliders
} from 'lucide-react';
import { AuthUser, PracticeConfig } from '../types';
import { AdminActiveSection } from './AdministrationPage';
import { getUnreadCount, subscribeToMessageUpdates } from '../utils/portalMessageStore';

interface HeaderProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onRefresh: () => void;
  onAppointmentBooks?: () => void;
  onPrint?: () => void;
  searchQuery?: string;
  setSearchQuery?: (query: string) => void;
  onAddPatient?: () => void;
  onOpenAIChat?: () => void;
  needsAttentionCount?: number;
  currentUser?: AuthUser | null;
  onLogout?: () => void;
  onNavigateLanding?: () => void;
  onNavigatePortal?: () => void;
  onNavigateAdminSection?: (section: AdminActiveSection) => void;
  practiceConfig?: PracticeConfig;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  onRefresh,
  onAppointmentBooks,
  onPrint,
  searchQuery,
  setSearchQuery,
  onAddPatient,
  onOpenAIChat,
  needsAttentionCount = 0,
  currentUser,
  onLogout,
  onNavigateLanding,
  onNavigatePortal,
  onNavigateAdminSection,
  practiceConfig
}) => {
  const [unreadPortalMessages, setUnreadPortalMessages] = useState<number>(() => getUnreadCount());
  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);
  const [isChangePasswordOpen, setIsChangePasswordOpen] = useState(false);
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showCurrentPw, setShowCurrentPw] = useState(false);
  const [showNewPw, setShowNewPw] = useState(false);
  const [passwordError, setPasswordError] = useState<string | null>(null);
  const [passwordSuccess, setPasswordSuccess] = useState(false);

  const userMenuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const updateCount = () => {
      setUnreadPortalMessages(getUnreadCount());
    };
    updateCount();
    const unsubscribe = subscribeToMessageUpdates(updateCount);
    return () => unsubscribe();
  }, []);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (userMenuRef.current && !userMenuRef.current.contains(event.target as Node)) {
        setIsUserMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleChangePasswordSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setPasswordError(null);

    if (!currentPassword) {
      setPasswordError('Please enter your current password.');
      return;
    }
    if (newPassword.length < 8) {
      setPasswordError('New password must be at least 8 characters long.');
      return;
    }
    if (newPassword !== confirmPassword) {
      setPasswordError('New passwords do not match.');
      return;
    }

    setPasswordSuccess(true);
    setTimeout(() => {
      setPasswordSuccess(false);
      setIsChangePasswordOpen(false);
      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');
    }, 1800);
  };

  const userInitials = currentUser 
    ? `${currentUser.firstName[0] || ''}${currentUser.lastName[0] || ''}`.toUpperCase()
    : '--';

  const userDisplayName = currentUser
    ? `${currentUser.firstName} ${currentUser.lastName}`
    : 'No user connected';

  const practiceDisplayName = practiceConfig?.practiceName || 'Vityls ASC';

  return (
    <header className="sticky top-0 z-30 bg-white border-b border-[#E1E4DC] shadow-xs">
      {/* Top Bar: Brand, Facility, Actions & User Account */}
      <div className="w-full px-3 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-15 gap-2 sm:gap-4">
          
          {/* Left: Branding & Facility Pill */}
          <div className="flex items-center gap-3 min-w-0">
            {/* Logo / Brand */}
            <button
              type="button"
              onClick={() => setActiveTab('home')}
              className="flex items-center gap-2.5 text-left group cursor-pointer"
            >
              <div className="w-9 h-9 rounded-xl bg-[#1F6E52] flex items-center justify-center text-white shadow-sm shrink-0 group-hover:bg-[#17553F] transition-colors">
                <Activity className="w-5 h-5 text-[#DCEEE3]" />
              </div>
              <div className="min-w-0">
                <div className="flex items-center gap-1.5">
                  <span className="font-bold text-[#1A2E22] font-display text-sm tracking-tight truncate leading-none">
                    Office Intelligence
                  </span>
                  <span className="px-1.5 py-0.2 rounded-md text-[9px] font-bold bg-[#DCEEE3] text-[#1B4332] border border-[#E1E4DC] uppercase font-mono">
                    v2.0
                  </span>
                  <span className="hidden sm:inline-flex items-center gap-1 px-1.5 py-0.2 rounded-md text-[9px] font-bold bg-[#E4F3EA] text-[#1B4332] border border-[#E1E4DC] font-mono">
                    <span className="w-1.5 h-1.5 rounded-full bg-[#2F9E6E] animate-pulse"></span>
                    HIPAA
                  </span>
                </div>
                <div className="text-[11px] text-[#5B6B60] flex items-center gap-1 truncate mt-0.5">
                  <span className="text-[#1F6E52] font-semibold truncate font-display">Medical OS</span>
                  <span className="text-[#5B6B60]">•</span>
                  <span className="truncate">{practiceDisplayName}</span>
                </div>
              </div>
            </button>
          </div>

          {/* Right: Quick Action Buttons & User Menu */}
          <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
            
            {/* Add Patient Button */}
            {activeTab === 'patients' && onAddPatient && (
              <button
                onClick={onAddPatient}
                className="px-2.5 sm:px-3.5 py-1.5 rounded-lg bg-[#1F6E52] hover:bg-[#17553F] text-white text-xs font-semibold flex items-center gap-1.5 transition-colors shadow-2xs cursor-pointer font-sans"
              >
                <Plus className="w-4 h-4" />
                <span className="hidden sm:inline">Add Patient</span>
              </button>
            )}

            {/* Refresh Live Schedule Button */}
            <button
              onClick={onRefresh}
              className="p-1.5 sm:p-2 rounded-lg bg-[#F1F3EC] hover:bg-[#DCEEE3] border border-[#E1E4DC] text-[#5B6B60] hover:text-[#1A2E22] transition-colors shadow-2xs cursor-pointer"
              title="Refresh Real-time Schedule & Status"
            >
              <RefreshCw className="w-4 h-4" />
            </button>

            {/* User Profile Dropdown */}
            <div className="relative" ref={userMenuRef}>
              <button
                onClick={() => setIsUserMenuOpen(!isUserMenuOpen)}
                className={`flex items-center gap-1.5 sm:gap-2 px-2 sm:px-2.5 py-1.5 bg-[#F1F3EC] hover:bg-[#DCEEE3] border rounded-lg transition-all shadow-2xs cursor-pointer ${
                  isUserMenuOpen ? 'border-[#1F6E52] ring-2 ring-[#1F6E52]/20 bg-[#DCEEE3]' : 'border-[#E1E4DC]'
                }`}
                id="header-user-menu-btn"
              >
                <div className="w-7 h-7 rounded-lg bg-[#1F6E52] text-[#DCEEE3] font-bold text-xs flex items-center justify-center font-display shadow-xs">
                  {userInitials}
                </div>
                <div className="text-left hidden lg:block max-w-[130px]">
                  <div className="text-xs font-bold text-[#1A2E22] truncate leading-tight font-display">
                    {userDisplayName}
                  </div>
                  <div className="text-[10px] text-[#5B6B60] truncate leading-tight font-mono">
                    {currentUser?.role || 'Practice Admin'}
                  </div>
                </div>
                <ChevronDown className={`w-3.5 h-3.5 text-[#5B6B60] transition-transform duration-150 ${isUserMenuOpen ? 'rotate-180 text-[#1F6E52]' : ''}`} />
              </button>

              {/* User Dropdown Menu */}
              {isUserMenuOpen && (
                <div className="absolute right-0 mt-2 w-68 max-w-[calc(100vw-1.5rem)] bg-white rounded-xl border border-[#E1E4DC] shadow-2xl p-2 z-50 animate-in fade-in slide-in-from-top-2 duration-150 space-y-1">
                  <div className="p-3 bg-[#F1F3EC] rounded-lg border border-[#E1E4DC] mb-1">
                    <p className="text-xs font-bold text-[#1A2E22] truncate font-display">{userDisplayName}</p>
                    <p className="text-[11px] text-[#5B6B60] truncate font-mono">{currentUser?.email || 'No account connected'}</p>
                    <div className="flex items-center gap-1 text-[10px] font-bold text-[#1B4332] mt-1">
                      <ShieldCheck className="w-3 h-3 text-[#2F9E6E]" />
                      <span>Authenticated • HIPAA Session</span>
                    </div>
                  </div>

                  {/* Configure Practice shortcut */}
                  {onNavigateAdminSection && (
                    <button
                      type="button"
                      onClick={() => {
                        setIsUserMenuOpen(false);
                        onNavigateAdminSection('configure-practice');
                      }}
                      className="w-full px-3 py-2 rounded-lg text-xs font-semibold text-[#1A2E22] hover:bg-[#F1F3EC] flex items-center gap-2.5 transition-colors cursor-pointer text-left"
                    >
                      <Sliders className="w-4 h-4 text-[#1F6E52]" />
                      <span>Configure Practice</span>
                    </button>
                  )}

                  {/* Switch to Patient Portal */}
                  {onNavigatePortal && (
                    <button
                      type="button"
                      onClick={() => {
                        setIsUserMenuOpen(false);
                        onNavigatePortal();
                      }}
                      className="w-full px-3 py-2 rounded-lg text-xs font-semibold text-[#1F6E52] hover:bg-[#DCEEE3] flex items-center gap-2.5 transition-colors cursor-pointer text-left"
                      id="header-user-menu-patient-portal"
                    >
                      <Users className="w-4 h-4 text-[#1F6E52]" />
                      <span>Switch to Patient Portal</span>
                    </button>
                  )}

                  {/* Change Password */}
                  <button
                    type="button"
                    onClick={() => {
                      setIsUserMenuOpen(false);
                      setPasswordError(null);
                      setPasswordSuccess(false);
                      setIsChangePasswordOpen(true);
                    }}
                    className="w-full px-3 py-2 rounded-lg text-xs font-semibold text-[#1A2E22] hover:bg-[#F1F3EC] flex items-center gap-2.5 transition-colors cursor-pointer text-left"
                    id="header-user-menu-change-password"
                  >
                    <KeyRound className="w-4 h-4 text-[#5B6B60]" />
                    <span>Change Password</span>
                  </button>

                  {/* Logout */}
                  {onLogout && (
                    <div className="pt-1 border-t border-[#E1E4DC]">
                      <button
                        type="button"
                        onClick={() => {
                          setIsUserMenuOpen(false);
                          onLogout();
                        }}
                        className="w-full px-3 py-2 rounded-lg text-xs font-semibold text-[#7A2E22] hover:bg-[#FBE4E1] flex items-center gap-2.5 transition-colors cursor-pointer text-left"
                        id="header-user-menu-logout"
                      >
                        <LogOut className="w-4 h-4 text-[#C1503D]" />
                        <span>Log Out</span>
                      </button>
                    </div>
                  )}
                </div>
              )}
            </div>

          </div>

        </div>
      </div>

      {/* Change Password Modal */}
      {isChangePasswordOpen && (
        <div className="fixed inset-0 z-50 bg-[#1A2E22]/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl border border-[#E1E4DC] shadow-2xl p-6 max-w-md w-full space-y-4 animate-in fade-in zoom-in-95 duration-200">
            <div className="flex items-center justify-between border-b border-[#E1E4DC] pb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-[#DCEEE3] text-[#1F6E52] flex items-center justify-center">
                  <KeyRound className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-[#1A2E22] font-display">Change Account Password</h3>
                  <p className="text-[11px] text-[#5B6B60]">Update your HIPAA secure credentials</p>
                </div>
              </div>
              <button
                onClick={() => setIsChangePasswordOpen(false)}
                className="text-[#5B6B60] hover:text-[#1A2E22] text-xs font-bold p-1 rounded-lg hover:bg-[#F1F3EC] transition-colors cursor-pointer"
              >
                ✕
              </button>
            </div>

            {passwordSuccess ? (
              <div className="p-4 rounded-2xl bg-[#E4F3EA] border border-[#E1E4DC] text-[#1B4332] text-xs space-y-2 text-center py-6">
                <CheckCircle2 className="w-8 h-8 text-[#2F9E6E] mx-auto animate-bounce" />
                <h4 className="font-bold text-sm text-[#1B4332] font-display">Password Updated Successfully</h4>
                <p className="text-[#5B6B60]">Your practice account password has been updated.</p>
              </div>
            ) : (
              <form onSubmit={handleChangePasswordSubmit} className="space-y-3.5">
                {passwordError && (
                  <div className="p-3 rounded-xl bg-[#FBE4E1] border border-[#C1503D]/30 text-[#7A2E22] text-xs font-medium">
                    {passwordError}
                  </div>
                )}

                {/* Current Password */}
                <div className="space-y-1">
                  <label className="text-xs font-bold text-[#1A2E22] flex items-center gap-1.5">
                    <Lock className="w-3.5 h-3.5 text-[#5B6B60]" />
                    <span>Current Password</span>
                  </label>
                  <div className="relative">
                    <input
                      type={showCurrentPw ? 'text' : 'password'}
                      required
                      value={currentPassword}
                      onChange={(e) => setCurrentPassword(e.target.value)}
                      placeholder="Enter current password"
                      className="w-full px-3.5 py-2 rounded-xl border border-[#E1E4DC] text-xs outline-hidden focus:border-[#1F6E52] pr-10 text-[#1A2E22]"
                    />
                    <button
                      type="button"
                      onClick={() => setShowCurrentPw(!showCurrentPw)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-[#5B6B60] hover:text-[#1A2E22] cursor-pointer"
                    >
                      {showCurrentPw ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                {/* New Password */}
                <div className="space-y-1">
                  <label className="text-xs font-bold text-[#1A2E22] flex items-center gap-1.5">
                    <KeyRound className="w-3.5 h-3.5 text-[#5B6B60]" />
                    <span>New Password</span>
                  </label>
                  <div className="relative">
                    <input
                      type={showNewPw ? 'text' : 'password'}
                      required
                      value={newPassword}
                      onChange={(e) => setNewPassword(e.target.value)}
                      placeholder="At least 8 characters"
                      className="w-full px-3.5 py-2 rounded-xl border border-[#E1E4DC] text-xs outline-hidden focus:border-[#1F6E52] pr-10 text-[#1A2E22]"
                    />
                    <button
                      type="button"
                      onClick={() => setShowNewPw(!showNewPw)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-[#5B6B60] hover:text-[#1A2E22] cursor-pointer"
                    >
                      {showNewPw ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                {/* Confirm New Password */}
                <div className="space-y-1">
                  <label className="text-xs font-bold text-[#1A2E22]">Confirm New Password</label>
                  <input
                    type="password"
                    required
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    placeholder="Re-enter new password"
                    className="w-full px-3.5 py-2 rounded-xl border border-[#E1E4DC] text-xs outline-hidden focus:border-[#1F6E52] text-[#1A2E22]"
                  />
                </div>

                <div className="flex items-center justify-end gap-2 pt-2 border-t border-[#E1E4DC]">
                  <button
                    type="button"
                    onClick={() => setIsChangePasswordOpen(false)}
                    className="px-4 py-2 rounded-xl text-xs font-semibold text-[#5B6B60] hover:bg-[#F1F3EC] cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 bg-[#1F6E52] hover:bg-[#17553F] text-white text-xs font-bold rounded-xl shadow-xs transition-colors cursor-pointer"
                  >
                    Update Password
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}
    </header>
  );
};

