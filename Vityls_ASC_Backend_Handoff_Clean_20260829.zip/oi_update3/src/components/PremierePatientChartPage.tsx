import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  AlertTriangle, Bot, CheckCircle2, ChevronDown, ClipboardList, FileCheck2, FileText,
  MessageSquare, Printer, ShieldCheck, Sparkles, Upload, UserRound, X, Eye, BrainCircuit
} from 'lucide-react';
import type { EncounterJourneyStatus, PatientCase } from '../types';
import { CaseRecordCommandCenter } from './CaseRecordCommandCenter';
import { ClinicalWorkflowPage, ClinicalWorkflowRole } from './ClinicalWorkflowPage';
import {
  listCurrentPracticeForms, listPdfTemplates, listEncounterDocuments, saveEncounterDocument,
  updateEncounterDocumentSummary, createLocalBlobUrl,
  type LocalFormTemplate, type LocalPdfTemplate, type LocalEncounterDocument,
} from '../utils/localFormStudioDb';
import { localTemplateToIntakeForm } from '../utils/localFormRuntime';
import { getPrefilledIntakeHtml } from '../utils/formPrefill';
import { getLocalFormResponse, listLocalFormResponses, saveLocalFormResponse } from '../utils/localFormResponseStore';

interface Props {
  patient: PatientCase;
  activePracticeId: string;
  initialSelectedSection?: string;
  onAdvanceEncounter?: (caseId: string, toStatus: EncounterJourneyStatus, reason?: string, unresolvedItems?: string[]) => void;
}

const gateLabel = (status?: string) => (status || 'ARRIVED').replaceAll('_',' ');

export const PremierePatientChartPage: React.FC<Props> = ({
  patient, activePracticeId, initialSelectedSection, onAdvanceEncounter
}) => {
  const [forms, setForms] = useState<LocalFormTemplate[]>([]);
  const [pdfTemplates,setPdfTemplates]=useState<LocalPdfTemplate[]>([]);
  const [encounterDocs,setEncounterDocs]=useState<LocalEncounterDocument[]>([]);
  const [caseOpen, setCaseOpen] = useState(false);
  const [workflowRole, setWorkflowRole] = useState<ClinicalWorkflowRole | null>(null);
  const [openForm,setOpenForm]=useState<LocalFormTemplate|null>(null);
  const [responseTick,setResponseTick]=useState(0);
  const [documentSectionOpen,setDocumentSectionOpen]=useState(true);
  const formFrameRef=useRef<HTMLIFrameElement>(null);
  const uploadRef=useRef<HTMLInputElement>(null);

  const refreshDocuments=async()=>{
    const [f,pdfs,docs]=await Promise.all([
      listCurrentPracticeForms(activePracticeId),
      listPdfTemplates(activePracticeId),
      listEncounterDocuments(activePracticeId,patient.id),
    ]);
    setForms(f);
    setPdfTemplates(pdfs.filter(p=>p.status==='Active'));
    setEncounterDocs(docs);
  };

  useEffect(() => { refreshDocuments().catch(()=>{}); }, [activePracticeId,patient.id]);

  useEffect(() => {
    if (initialSelectedSection === 'nursing-workflow') setWorkflowRole('Nursing');
    if (initialSelectedSection === 'anesthesia-workflow') setWorkflowRole('Anesthesia');
    if (initialSelectedSection === 'surgeon-workflow') setWorkflowRole('Surgeons');
  }, [initialSelectedSection, patient.id]);

  useEffect(()=>{
    const h=()=>setResponseTick(x=>x+1);
    window.addEventListener('oi-form-response-updated',h);
    return()=>window.removeEventListener('oi-form-response-updated',h);
  },[]);

  const intakeForms = useMemo(
    () => forms.filter(f=>f.collectionStage === 'Home / Patient Portal' || f.collectionStage === 'Front Desk').map(localTemplateToIntakeForm),
    [forms]
  );

  const currentOwner = patient.encounterWorkflow?.currentOwner || 'Front Desk';
  const status = patient.encounterWorkflow?.status || 'ARRIVED';
  const allergyKnown = patient.allergies.length > 0;
  const completedResponses = useMemo(()=>listLocalFormResponses(activePracticeId,patient.id),[activePracticeId,patient.id,responseTick]);
  const completedIds=new Set(completedResponses.map(r=>r.formId));

  const openPdf=(blob?:Blob)=>{
    const url=createLocalBlobUrl(blob);
    if(url) window.open(url,'_blank');
  };

  const addPdfTemplateToEncounter=async(pdf:LocalPdfTemplate)=>{
    await saveEncounterDocument({
      practiceId:activePracticeId,
      patientId:patient.id,
      encounterKey:`${patient.id}:${patient.scheduledTime || 'current'}`,
      title:pdf.title,
      sourceType:'PDF_TEMPLATE',
      templateId:pdf.id,
      fileName:pdf.fileName,
      mimeType:pdf.mimeType,
      blob:pdf.blob,
      uploadedBy:'Practice Staff',
      classification:pdf.category,
      aiSummary:'Original practice PDF template added to this encounter. Complete on paper or electronically outside Form Studio, then upload the executed/scanned version. The original template remains viewable and printable.',
    });
    await refreshDocuments();
  };

  const uploadPaperOrPdf=async(file:File)=>{
    await saveEncounterDocument({
      practiceId:activePracticeId,
      patientId:patient.id,
      encounterKey:`${patient.id}:${patient.scheduledTime || 'current'}`,
      title:file.name.replace(/\.[^.]+$/,'').replace(/[_-]+/g,' '),
      sourceType:/scan|paper/i.test(file.name)?'PAPER_SCAN':'UPLOADED_PDF',
      fileName:file.name,
      mimeType:file.type || 'application/pdf',
      blob:file,
      uploadedBy:'Practice Staff',
      aiSummary:'Original uploaded source preserved. Nightingale classification/extraction is pending human review; no extracted fact has been written into the structured chart.',
    });
    await refreshDocuments();
  };

  const summarizeDocument=async(doc:LocalEncounterDocument)=>{
    const summary=`Local test summary for ${doc.title}: preserved as the original ${doc.sourceType.replaceAll('_',' ').toLowerCase()} for this encounter. Production Nightingale will OCR/read the document, identify timestamps, medications, vital-sign trends, procedures, signatures and exceptions where present, retain page/source provenance, and present extracted facts for staff approval before chart promotion.`;
    await updateEncounterDocumentSummary(doc.id,summary);
    await refreshDocuments();
  };

  const saveTestFormEntry=()=>{
    if(!openForm || !formFrameRef.current?.contentDocument) return;
    const doc=formFrameRef.current.contentDocument;
    const values:Record<string,string|boolean|string[]>={};
    doc.querySelectorAll<HTMLInputElement|HTMLTextAreaElement|HTMLSelectElement>('input,textarea,select').forEach((el:any)=>{
      const key=el.name || el.id;
      if(!key) return;
      if(el.type==='checkbox'){
        if(!Array.isArray(values[key])) values[key]=[];
        if(el.checked) (values[key] as string[]).push(el.value || 'Yes');
      } else if(el.type==='radio'){
        if(el.checked) values[key]=el.value;
      } else values[key]=el.value;
    });
    saveLocalFormResponse({
      practiceId:activePracticeId,
      patientId:patient.id,
      formId:openForm.id,
      formTitle:openForm.title,
      version:openForm.version,
      values,
      completedAt:new Date().toISOString(),
      completedBy:'Local Test User',
      renderedHtml:doc.documentElement.outerHTML,
    });
    setOpenForm(null);
  };

  if (caseOpen) return (
    <CaseRecordCommandCenter
      patient={patient}
      activePracticeId={activePracticeId}
      onClose={()=>setCaseOpen(false)}
      onOpenWorkflow={(role)=>{ setCaseOpen(false); setWorkflowRole(role); }}
      onAdvanceGate={(toStatus, reason, unresolved)=>onAdvanceEncounter?.(patient.id,toStatus,reason,unresolved)}
    />
  );

  if (workflowRole) return (
    <ClinicalWorkflowPage
      role={workflowRole}
      patient={patient}
      nursingForms={[]}
      intakeForms={intakeForms}
      localPracticeForms={forms}
      onClose={()=>setWorkflowRole(null)}
      onAdvanceGate={(toStatus, reason, unresolved)=>onAdvanceEncounter?.(patient.id,toStatus,reason,unresolved)}
    />
  );

  const activeFormHtml=openForm ? getPrefilledIntakeHtml(localTemplateToIntakeForm(openForm).htmlTemplate,{
    ...patient,
    facility:'Office Intelligence Premiere Test Center',
    reasonForVisit:patient.procedure || 'Scheduled surgical encounter',
    encounterDate:new Date().toLocaleString(),
  }) : '';

  return (
    <div className="w-full max-w-[1500px] mx-auto space-y-5 animate-in fade-in duration-200">
      {/* Original-style patient chart header */}
      <section className="bg-white rounded-2xl border border-stone-200 shadow-2xs overflow-hidden">
        <div className="p-5 flex flex-col lg:flex-row lg:items-start justify-between gap-5">
          <div className="flex items-start gap-4 min-w-0">
            <div className="w-14 h-14 rounded-2xl bg-sky-50 border border-sky-100 text-sky-800 font-black flex items-center justify-center text-lg shrink-0">NP</div>
            <div className="min-w-0">
              <div className="flex items-center gap-2 flex-wrap"><h1 className="text-xl font-black text-stone-900">{patient.name}</h1><span className="px-2 py-1 rounded-full bg-amber-50 border border-amber-200 text-amber-800 text-[10px] font-black">NEW CHART</span></div>
              <div className="text-xs text-stone-500 mt-1">MRN {patient.patientId} · DOB {patient.dob || 'Not entered'} · {patient.age || 'Age not entered'} · {patient.gender || 'Gender not entered'}</div>
              <div className="mt-3 rounded-xl border border-emerald-200 bg-emerald-50 px-3.5 py-3 max-w-xl">
                <div className="text-[9px] uppercase tracking-wider font-black text-emerald-700">Planned procedure</div>
                <div className="text-sm font-black text-stone-900 mt-0.5">{patient.procedure || 'Procedure not assigned'}</div>
                <div className="text-[10.5px] text-stone-600 mt-0.5">Surgeon: {patient.surgeon || 'Not assigned'} · Current gate: <strong>{gateLabel(status)}</strong></div>
              </div>
            </div>
          </div>
          <div className="flex flex-wrap gap-2">
            <button onClick={()=>setCaseOpen(true)} className="px-4 py-2 rounded-xl bg-slate-900 text-white text-xs font-black flex items-center gap-2"><ShieldCheck className="w-4 h-4"/>Case Record</button>
            <button onClick={()=>window.print()} className="px-4 py-2 rounded-xl bg-slate-900 text-white text-xs font-black flex items-center gap-2"><Printer className="w-4 h-4"/>Print</button>
          </div>
        </div>
        <div className="px-5 py-3 border-t border-stone-100 flex flex-wrap gap-x-6 gap-y-2 text-xs">
          <div><strong>Drug Allergies:</strong> {allergyKnown ? patient.allergies.join(', ') : <span className="text-amber-800 font-bold">Not yet entered</span>}</div>
          <div><strong>Medications:</strong> {patient.medicalProfile?.medications?.length ? patient.medicalProfile.medications.map((m:any)=>typeof m==='string'?m:(m.name||'Medication')).join(', ') : <span className="text-amber-800 font-bold">Not yet entered</span>}</div>
          <div><strong>Current owner:</strong> {currentOwner}</div>
        </div>
      </section>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        <div className="lg:col-span-8 space-y-5">
          <section className="bg-white rounded-2xl border border-[#3E8FA6]/40 shadow-2xs overflow-hidden">
            <div className="px-4 py-3 border-b border-stone-100 flex items-center justify-between">
              <div className="flex items-center gap-2"><div className="w-7 h-7 rounded-lg bg-[#3E8FA6] text-white flex items-center justify-center"><Sparkles className="w-4 h-4"/></div><div><div className="text-sm font-black text-stone-900">Current Visit Summary</div><div className="text-[11px] text-stone-500">Live encounter · structured forms + original documents</div></div></div>
              <span className="px-2 py-1 rounded-full bg-amber-50 border border-amber-200 text-amber-800 text-[10px] font-black">{completedResponses.length} forms completed</span>
            </div>
            <div className="p-5">
              {completedResponses.length || encounterDocs.length ? <div className="space-y-2">
                <p className="text-xs text-stone-700">This encounter currently contains <strong>{completedResponses.length} completed HTML form{completedResponses.length===1?'':'s'}</strong> and <strong>{encounterDocs.length} uploaded/original document{encounterDocs.length===1?'':'s'}</strong>. Nightingale will reconcile approved structured data with summaries of original PDF/paper sources.</p>
                {encounterDocs.filter(d=>d.aiStatus==='Summarized').slice(0,2).map(d=><div key={d.id} className="rounded-xl bg-sky-50 border border-sky-200 p-3 text-[11px] text-sky-900"><strong>{d.title}:</strong> {d.aiSummary}</div>)}
              </div> : <div className="rounded-xl border border-dashed border-stone-300 bg-stone-50 p-5 text-center"><UserRound className="w-7 h-7 mx-auto text-stone-300 mb-2"/><div className="text-xs font-black text-stone-700">Nothing has been documented yet</div><p className="text-[11px] text-stone-500 mt-1">Complete a Form Studio form or upload a source PDF/paper record to begin the encounter record.</p></div>}
            </div>
          </section>

          <section className="bg-white rounded-2xl border border-stone-200 shadow-2xs overflow-hidden">
            <button onClick={()=>setDocumentSectionOpen(!documentSectionOpen)} className="w-full px-4 py-3 flex items-center justify-between border-b border-stone-100 text-left">
              <div><div className="text-sm font-black text-stone-900">Forms & Encounter Documents</div><div className="text-[11px] text-stone-500">HTML forms, practice PDF templates, and executed/scanned paper documents share one encounter index.</div></div>
              <ChevronDown className={`w-4 h-4 text-stone-500 transition-transform ${documentSectionOpen?'rotate-180':''}`}/>
            </button>
            {documentSectionOpen && <div>
              <div className="px-4 py-2.5 bg-stone-50 border-b border-stone-100 flex items-center justify-between gap-3">
                <div className="text-[10px] uppercase tracking-wide font-black text-stone-500">Active HTML Forms</div>
                <span className="text-[10px] font-bold text-stone-500">{forms.length}</span>
              </div>
              {forms.length===0 ? <div className="p-4 text-xs text-stone-500">No HTML forms published for this practice.</div> :
                <div className="divide-y divide-stone-100">{forms.map(f=>{
                  const done=completedIds.has(f.id);
                  return <div key={f.id} className="px-4 py-3 flex items-center justify-between gap-3">
                    <div><div className="text-xs font-black text-stone-900">{f.title}</div><div className="text-[10.5px] text-stone-500 mt-0.5">{f.collectionStage}{f.reviewStages?.length?` · Verify: ${f.reviewStages.join(' → ')}`:''} · {f.version}</div></div>
                    <div className="flex items-center gap-2"><span className={`text-[10px] px-2 py-1 rounded-lg border font-black ${done?'bg-emerald-50 border-emerald-200 text-emerald-800':'bg-amber-50 border-amber-200 text-amber-800'}`}>{done?'Completed':'Not started'}</span><button onClick={()=>setOpenForm(f)} className="px-3 py-1.5 rounded-lg bg-white border border-stone-300 text-[10px] font-black text-stone-700">{done?'Review':'Open'}</button></div>
                  </div>})}</div>}

              <div className="px-4 py-2.5 bg-stone-50 border-y border-stone-100 flex items-center justify-between gap-3">
                <div><div className="text-[10px] uppercase tracking-wide font-black text-stone-500">Practice PDF Templates</div><div className="text-[9.5px] text-stone-400 mt-0.5">View/print only. Upload a new template version in Form Studio.</div></div><span className="text-[10px] font-bold text-stone-500">{pdfTemplates.length}</span>
              </div>
              {pdfTemplates.length===0 ? <div className="p-4 text-xs text-stone-500">No active PDF templates uploaded.</div> :
                <div className="divide-y divide-stone-100">{pdfTemplates.map(pdf=><div key={pdf.id} className="px-4 py-3 flex items-center justify-between gap-3"><div><div className="text-xs font-black text-stone-900">{pdf.title}</div><div className="text-[10.5px] text-stone-500 mt-0.5">{pdf.version} · {pdf.collectionStage} · Original PDF preserved</div></div><div className="flex gap-2"><button onClick={()=>openPdf(pdf.blob)} className="px-2.5 py-1.5 rounded-lg border border-stone-300 text-[10px] font-bold flex items-center gap-1"><Eye className="w-3 h-3"/>Open</button><button onClick={()=>addPdfTemplateToEncounter(pdf)} className="px-2.5 py-1.5 rounded-lg bg-emerald-700 text-white text-[10px] font-black">Add to Encounter</button></div></div>)}</div>}

              <div className="px-4 py-2.5 bg-stone-50 border-y border-stone-100 flex items-center justify-between gap-3">
                <div><div className="text-[10px] uppercase tracking-wide font-black text-stone-500">Executed / Scanned Documents</div><div className="text-[9.5px] text-stone-400 mt-0.5">Paper anesthesia records, scanned checklists, outside PDFs, and completed PDF forms.</div></div>
                <><input ref={uploadRef} type="file" accept="application/pdf,image/*" className="hidden" onChange={e=>{const f=e.target.files?.[0];if(f) uploadPaperOrPdf(f);e.currentTarget.value='';}}/><button onClick={()=>uploadRef.current?.click()} className="px-3 py-1.5 rounded-lg bg-slate-900 text-white text-[10px] font-black flex items-center gap-1"><Upload className="w-3.5 h-3.5"/>Upload Source</button></>
              </div>
              {encounterDocs.length===0 ? <div className="p-4 text-xs text-stone-500">No source documents uploaded for this encounter.</div> :
                <div className="divide-y divide-stone-100">{encounterDocs.map(doc=><div key={doc.id} className="px-4 py-3"><div className="flex items-center justify-between gap-3"><div><div className="text-xs font-black text-stone-900">{doc.title}</div><div className="text-[10px] text-stone-500 mt-0.5">{doc.classification} · {doc.sourceType.replaceAll('_',' ')} · {doc.aiStatus}</div></div><div className="flex gap-2">{doc.blob && <button onClick={()=>openPdf(doc.blob)} className="px-2.5 py-1.5 rounded-lg border border-stone-300 text-[10px] font-bold flex items-center gap-1"><Eye className="w-3 h-3"/>Original</button>}{doc.aiStatus!=='Summarized' && <button onClick={()=>summarizeDocument(doc)} className="px-2.5 py-1.5 rounded-lg bg-sky-50 border border-sky-200 text-sky-800 text-[10px] font-black flex items-center gap-1"><BrainCircuit className="w-3 h-3"/>Nightingale Summary</button>}</div></div><div className="mt-2 text-[10.5px] text-stone-600 leading-relaxed">{doc.aiSummary}</div></div>)}</div>}
            </div>}
          </section>
        </div>

        {/* Original-style Nightingale right column */}
        <aside className="lg:col-span-4 space-y-5">
          <section className="bg-[#F4EFE3] rounded-2xl border border-[#D9A448] shadow-sm overflow-hidden">
            <div className="px-4 py-3 border-b border-[#D9A448] bg-[#14432E] flex items-center justify-between">
              <div className="flex items-center gap-2"><div className="w-8 h-8 rounded-xl bg-[#3E8FA6] text-white flex items-center justify-center"><Bot className="w-4 h-4"/></div><div><div className="text-sm font-black text-[#F4EFE3]">Nightingale AI</div><div className="text-[10px] text-[#D9A448]">Clinical Coordinator · Active</div></div></div><span className="w-2 h-2 rounded-full bg-emerald-500"></span>
            </div>
            <div className="p-4 space-y-3">
              <div className="rounded-xl border border-stone-200 bg-white px-3 py-2 text-[11px] text-stone-500">Ask Nightingale about this encounter, forms, missing records, or the current gate.</div>
              <div><div className="text-[9px] uppercase tracking-wide font-black text-stone-400 mb-2">Suggested</div><div className="grid gap-2"><button onClick={()=>setCaseOpen(true)} className="text-left rounded-xl border border-emerald-200 bg-emerald-50 p-3"><div className="text-xs font-black text-emerald-900">Review Case Record</div><div className="text-[10px] text-emerald-700 mt-1">{forms.length-completedResponses.length} HTML forms remain incomplete · {encounterDocs.filter(d=>d.aiStatus!=='Summarized').length} source documents await AI summary</div></button><button onClick={()=>setDocumentSectionOpen(true)} className="text-left rounded-xl border border-stone-200 bg-stone-50 p-3"><div className="text-xs font-black text-stone-800">Encounter Documents</div><div className="text-[10px] text-stone-500 mt-1">Open original HTML/PDF/paper records and review provenance.</div></button></div></div>
              <div className="rounded-xl bg-emerald-50 border border-emerald-200 p-3"><div className="text-[9px] uppercase tracking-wide font-black text-emerald-700">Current gate</div><div className="text-sm font-black text-stone-900 mt-1">{gateLabel(status)}</div><div className="text-[11px] text-stone-600 mt-1">Owner: {currentOwner}</div></div>
            </div>
          </section>
        </aside>
      </div>

      {openForm && <div className="fixed inset-0 z-[100800] bg-slate-950/70 backdrop-blur-sm p-3 sm:p-6 overflow-y-auto">
        <div className="max-w-6xl mx-auto bg-white rounded-2xl shadow-2xl overflow-hidden">
          <div className="px-4 py-3 bg-slate-900 text-white flex items-center justify-between gap-3"><div><div className="text-sm font-black">{openForm.title}</div><div className="text-[10px] text-slate-400">{openForm.version} · Test patient data-entry view</div></div><button onClick={()=>setOpenForm(null)} className="p-2 rounded-lg bg-white/10"><X className="w-4 h-4"/></button></div>
          <iframe ref={formFrameRef} srcDoc={activeFormHtml} sandbox="allow-same-origin" className="w-full h-[70vh] bg-white border-0"/>
          <div className="px-4 py-3 border-t border-stone-200 flex flex-wrap items-center justify-between gap-3"><div className="text-[10.5px] text-stone-500">Local test responses are stored separately and are reflected in Case Record status. The rendered HTML snapshot is preserved for view/print testing.</div><div className="flex gap-2"><button onClick={()=>formFrameRef.current?.contentWindow?.print()} className="px-4 py-2 rounded-xl border border-stone-300 bg-white text-stone-700 text-xs font-black flex items-center gap-1.5"><Printer className="w-4 h-4"/>Print Form</button><button onClick={saveTestFormEntry} className="px-4 py-2 rounded-xl bg-emerald-700 text-white text-xs font-black flex items-center gap-1.5"><FileCheck2 className="w-4 h-4"/>Save Test Entry</button></div></div>
        </div>
      </div>}
    </div>
  );
};
