import React, { useState, useMemo } from 'react';
import { PatientCase, PAYMENT_TYPE_OPTIONS } from '../types';
import {
  X, UserPlus, Sparkles, User, Calendar, ShieldAlert, MapPin, Phone,
  CreditCard, Mail, Fingerprint, Briefcase, HeartPulse, Megaphone
} from 'lucide-react';
import { generateSampleDriverLicense, generateSampleInsuranceFront, generateSampleInsuranceBack } from '../utils/cardTemplates';

interface AddPatientModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddPatient: (newPatient: PatientCase) => void;
}

// Calculates whole-years age from a MM/DD/YYYY string; returns null if the
// string doesn't parse cleanly (the field stays editable either way).
function calculateAgeFromDob(dob: string): number | null {
  const match = dob.trim().match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
  if (!match) return null;
  const [, mm, dd, yyyy] = match;
  const dobDate = new Date(Number(yyyy), Number(mm) - 1, Number(dd));
  if (Number.isNaN(dobDate.getTime())) return null;
  const today = new Date();
  let age = today.getFullYear() - dobDate.getFullYear();
  const hasHadBirthdayThisYear =
    today.getMonth() > dobDate.getMonth() ||
    (today.getMonth() === dobDate.getMonth() && today.getDate() >= dobDate.getDate());
  if (!hasHadBirthdayThisYear) age -= 1;
  return age >= 0 && age < 130 ? age : null;
}

const inputClass =
  'w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-xl text-xs font-bold text-stone-900 focus:ring-2 focus:ring-indigo-500 focus:outline-none';
const labelClass = 'block text-xs font-bold text-stone-700 mb-1 flex items-center gap-1';

export const AddPatientModal: React.FC<AddPatientModalProps> = ({
  isOpen,
  onClose,
  onAddPatient,
}) => {
  // Identity
  const [firstName, setFirstName] = useState('');
  const [middleInitial, setMiddleInitial] = useState('');
  const [lastName, setLastName] = useState('');
  const [patientId, setPatientId] = useState(
    `${Math.floor(110000 + Math.random() * 80000)}`
  );
  const [dob, setDob] = useState('08/14/1988');
  const [manualAge, setManualAge] = useState<number | null>(null);
  const [gender, setGender] = useState<'Female' | 'Male' | 'Other'>('Female');
  const [ethnicity, setEthnicity] = useState('Prefer not to say');
  const [maritalStatus, setMaritalStatus] = useState<NonNullable<PatientCase['maritalStatus']>>('Prefer not to say');

  // Contact
  const [phone, setPhone] = useState('(310) 555-0199');
  const [email, setEmail] = useState('');
  const [address, setAddress] = useState('');
  const [city, setCity] = useState('Beverly Hills');
  const [state, setState] = useState('CA');
  const [zipCode, setZipCode] = useState('90210');
  const [country, setCountry] = useState('United States');

  // Identification
  const [ssn, setSsn] = useState('');
  const [driversLicenseNumber, setDriversLicenseNumber] = useState('');

  // Personal / employment / emergency / referral
  const [occupation, setOccupation] = useState('');
  const [employer, setEmployer] = useState('');
  const [emergencyContactName, setEmergencyContactName] = useState('');
  const [emergencyContactPhone, setEmergencyContactPhone] = useState('');
  const [referralSource, setReferralSource] = useState('Patient Referral');

  // Insurance, allergies & notes (registration-relevant; NOT scheduling)
  const [allergiesText, setAllergiesText] = useState('');
  const [paymentType, setPaymentType] = useState<string>('Private Insurance');
  const [notes, setNotes] = useState('');

  // Surgical procedure, surgeon, anesthesiologist, OR/bay, and start time are
  // intentionally NOT collected here — this form only registers the patient
  // and creates their chart. Scheduling a procedure happens as a separate
  // step once the chart exists, so new records are created with neutral
  // "not yet scheduled" placeholders instead.
  const procedure = 'Procedure Not Yet Scheduled';
  const surgeon = 'Unassigned';
  const anesthesiologist = undefined;
  const room = 'Unassigned';
  const scheduledTime = 'Not Scheduled';

  const calculatedAge = useMemo(() => calculateAgeFromDob(dob), [dob]);
  const age = manualAge ?? calculatedAge ?? 38;
  const fullName = [firstName.trim(), middleInitial.trim() ? `${middleInitial.trim()}.` : '', lastName.trim()]
    .filter(Boolean)
    .join(' ');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!firstName.trim() || !lastName.trim()) return;

    const allergies = allergiesText
      .split(',')
      .map((a) => a.trim())
      .filter(Boolean);

    const newPatient: PatientCase = {
      id: `case-${Date.now()}`,
      patientId: patientId || `${Math.floor(100000 + Math.random() * 900000)}`,
      name: fullName,
      age: Number(age) || 35,
      gender,
      dob,
      phone,
      scheduledTime,
      estimatedDurationMins: 0,
      room,
      surgeon,
      anesthesiologist,
      procedure,
      aiSummary: `${fullName} is a ${age}-year-old ${gender.toLowerCase()} newly registered patient. A procedure has not yet been scheduled; electronic pre-op forms, consent, and safety checklists are ready to be assigned once it is.`,
      readinessScore: 98,
      readinessLevel: 'CLEARED',
      allergies: allergies.length > 0 ? allergies : ['None known'],
      labs: [
        { name: 'CBC', value: '13.8 g/dL', status: 'normal' },
        { name: 'BMP', value: 'Normal', status: 'normal' },
        { name: 'PT/INR', value: '1.0', status: 'normal' },
        { name: 'EKG', value: 'Normal Sinus Rhythm', status: 'normal' },
      ],
      stage: 'CHECK_IN',
      preOpBay: 'Bay 1',
      arrivalStatus: 'ARRIVED',
      arrivalTime: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      bottlenecks: [],
      actionItems: [
        { id: `act-${Date.now()}-1`, text: 'Verify surgical site marking & pre-op photo signoff', type: 'CONSENT', done: false, urgent: false },
        { id: `act-${Date.now()}-2`, text: 'Review Electronic Clinical Forms packet (9 Forms)', type: 'ANESTHESIA', done: false },
      ],
      notes,
      paymentType,
      idCardUrl: generateSampleDriverLicense(fullName.toUpperCase(), dob, `CA${patientId}`, `${city.toUpperCase()}, ${state}`),
      insuranceCardFrontUrl: generateSampleInsuranceFront(fullName.toUpperCase(), 'Anthem Blue Cross PPO', `ANT-${patientId}`, 'GRP-77210'),
      insuranceCardBackUrl: generateSampleInsuranceBack('Anthem Blue Cross PPO', '1-888-555-0199'),
      middleInitial: middleInitial.trim() || undefined,
      ethnicity: ethnicity || undefined,
      email: email.trim() || undefined,
      address: address.trim() || undefined,
      city: city.trim() || undefined,
      state: state.trim() || undefined,
      zipCode: zipCode.trim() || undefined,
      country: country.trim() || undefined,
      ssn: ssn.trim() || undefined,
      driversLicenseNumber: driversLicenseNumber.trim() || undefined,
      maritalStatus,
      occupation: occupation.trim() || undefined,
      employer: employer.trim() || undefined,
      emergencyContactName: emergencyContactName.trim() || undefined,
      emergencyContactPhone: emergencyContactPhone.trim() || undefined,
      referralSource: referralSource || undefined,
      checkInStatus: 'NOT_STARTED',
    };

    onAddPatient(newPatient);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-sm flex items-start justify-center p-4 overflow-y-auto animate-in fade-in duration-200">
      <div className="bg-white w-full max-w-3xl rounded-3xl shadow-2xl border border-stone-200 overflow-hidden my-8 sm:my-10">

        {/* Modal Header */}
        <div className="bg-emerald-900 text-white px-6 py-4 flex items-center justify-between border-b border-emerald-800 sticky top-0 z-10">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-emerald-600 flex items-center justify-center text-white">
              <UserPlus className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white tracking-tight">Add New Patient Record</h2>
              <p className="text-xs text-emerald-200">Create a new patient chart & initialize electronic clinical forms</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl bg-emerald-800 hover:bg-emerald-700 text-emerald-200 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          <div className="p-3 bg-indigo-50/70 border border-indigo-200/80 rounded-2xl flex items-center gap-3 text-xs text-indigo-950">
            <Sparkles className="w-4 h-4 text-indigo-600 shrink-0" />
            <span>
              Creating this patient will automatically assemble all <strong>9 Electronic Clinical Forms</strong> (H&P, Nursing Pre-Op, Surgical Consent, Anesthesia Record, Post-Op Orders, etc.).
            </span>
          </div>

          {/* SECTION: Identity */}
          <div className="space-y-3">
            <h3 className="text-[11px] font-bold uppercase tracking-wider text-stone-400 flex items-center gap-1.5">
              <User className="w-3.5 h-3.5 text-[#1F6E52]" />
              Patient Identity
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-6 gap-3">
              <div className="sm:col-span-3">
                <label className={labelClass}>First Name <span className="text-red-500">*</span></label>
                <input type="text" required placeholder="e.g. Elena" value={firstName} onChange={(e) => setFirstName(e.target.value)} className={inputClass} />
              </div>
              <div className="sm:col-span-1">
                <label className={labelClass}>M.I.</label>
                <input type="text" maxLength={2} placeholder="M" value={middleInitial} onChange={(e) => setMiddleInitial(e.target.value)} className={inputClass} />
              </div>
              <div className="sm:col-span-2">
                <label className={labelClass}>Last Name <span className="text-red-500">*</span></label>
                <input type="text" required placeholder="e.g. Rostova" value={lastName} onChange={(e) => setLastName(e.target.value)} className={inputClass} />
              </div>

              <div className="sm:col-span-2">
                <label className={labelClass}><Calendar className="w-3.5 h-3.5 text-stone-400" />Date of Birth</label>
                <input type="text" placeholder="MM/DD/YYYY" value={dob} onChange={(e) => { setDob(e.target.value); setManualAge(null); }} className={inputClass} />
              </div>
              <div className="sm:col-span-1">
                <label className={labelClass}>Age</label>
                <input
                  type="number"
                  min="0"
                  max="130"
                  value={age}
                  onChange={(e) => setManualAge(Number(e.target.value))}
                  title={calculatedAge !== null ? 'Auto-calculated from DOB — override if needed' : undefined}
                  className={inputClass}
                />
              </div>
              <div className="sm:col-span-1">
                <label className={labelClass}>Gender</label>
                <select value={gender} onChange={(e) => setGender(e.target.value as 'Female' | 'Male' | 'Other')} className={inputClass}>
                  <option value="Female">Female</option>
                  <option value="Male">Male</option>
                  <option value="Other">Other</option>
                </select>
              </div>
              <div className="sm:col-span-2">
                <label className={labelClass}>Ethnicity</label>
                <select value={ethnicity} onChange={(e) => setEthnicity(e.target.value)} className={inputClass}>
                  {['Prefer not to say', 'American Indian or Alaska Native', 'Asian', 'Black or African American', 'Hispanic or Latino', 'Native Hawaiian or Other Pacific Islander', 'White', 'Two or More Races', 'Other'].map((opt) => (
                    <option key={opt} value={opt}>{opt}</option>
                  ))}
                </select>
              </div>

              <div className="sm:col-span-3">
                <label className={labelClass}>Marital Status</label>
                <select value={maritalStatus} onChange={(e) => setMaritalStatus(e.target.value as NonNullable<PatientCase['maritalStatus']>)} className={inputClass}>
                  {(['Single', 'Married', 'Divorced', 'Widowed', 'Domestic Partner', 'Prefer not to say'] as const).map((opt) => (
                    <option key={opt} value={opt}>{opt}</option>
                  ))}
                </select>
              </div>
              <div className="sm:col-span-3">
                <label className={labelClass}>Medical Record Number (MRN)</label>
                <input type="text" value={patientId} onChange={(e) => setPatientId(e.target.value)} className={`${inputClass} font-mono`} />
              </div>
            </div>
          </div>

          {/* SECTION: Contact & Address */}
          <div className="space-y-3">
            <h3 className="text-[11px] font-bold uppercase tracking-wider text-stone-400 flex items-center gap-1.5">
              <MapPin className="w-3.5 h-3.5 text-[#1F6E52]" />
              Contact & Address
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className={labelClass}><Phone className="w-3.5 h-3.5 text-stone-400" />Telephone</label>
                <input type="text" placeholder="(310) 000-0000" value={phone} onChange={(e) => setPhone(e.target.value)} className={inputClass} />
              </div>
              <div>
                <label className={labelClass}><Mail className="w-3.5 h-3.5 text-stone-400" />Email</label>
                <input type="email" placeholder="patient@email.com" value={email} onChange={(e) => setEmail(e.target.value)} className={inputClass} />
              </div>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-6 gap-3">
              <div className="sm:col-span-6">
                <label className={labelClass}>Street Address</label>
                <input type="text" placeholder="1420 Ocean Ave" value={address} onChange={(e) => setAddress(e.target.value)} className={inputClass} />
              </div>
              <div className="sm:col-span-2">
                <label className={labelClass}>City</label>
                <input type="text" value={city} onChange={(e) => setCity(e.target.value)} className={inputClass} />
              </div>
              <div className="sm:col-span-1">
                <label className={labelClass}>State</label>
                <input type="text" value={state} onChange={(e) => setState(e.target.value)} className={inputClass} />
              </div>
              <div className="sm:col-span-1">
                <label className={labelClass}>Zip</label>
                <input type="text" value={zipCode} onChange={(e) => setZipCode(e.target.value)} className={inputClass} />
              </div>
              <div className="sm:col-span-2">
                <label className={labelClass}>Country</label>
                <input type="text" value={country} onChange={(e) => setCountry(e.target.value)} className={inputClass} />
              </div>
            </div>
          </div>

          {/* SECTION: Identification */}
          <div className="space-y-3">
            <h3 className="text-[11px] font-bold uppercase tracking-wider text-stone-400 flex items-center gap-1.5">
              <Fingerprint className="w-3.5 h-3.5 text-[#1F6E52]" />
              Identification
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className={labelClass}>Social Security Number</label>
                <input type="text" placeholder="XXX-XX-XXXX" value={ssn} onChange={(e) => setSsn(e.target.value)} className={inputClass} />
              </div>
              <div>
                <label className={labelClass}>Driver's License Number</label>
                <input type="text" placeholder="e.g. D1234567" value={driversLicenseNumber} onChange={(e) => setDriversLicenseNumber(e.target.value)} className={inputClass} />
              </div>
            </div>
          </div>

          {/* SECTION: Occupation, Emergency Contact & Referral */}
          <div className="space-y-3">
            <h3 className="text-[11px] font-bold uppercase tracking-wider text-stone-400 flex items-center gap-1.5">
              <Briefcase className="w-3.5 h-3.5 text-[#1F6E52]" />
              Occupation, Emergency Contact & Referral
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className={labelClass}>Occupation</label>
                <input type="text" value={occupation} onChange={(e) => setOccupation(e.target.value)} className={inputClass} />
              </div>
              <div>
                <label className={labelClass}>Employer</label>
                <input type="text" value={employer} onChange={(e) => setEmployer(e.target.value)} className={inputClass} />
              </div>
              <div>
                <label className={labelClass}><HeartPulse className="w-3.5 h-3.5 text-stone-400" />Emergency Contact Name</label>
                <input type="text" value={emergencyContactName} onChange={(e) => setEmergencyContactName(e.target.value)} className={inputClass} />
              </div>
              <div>
                <label className={labelClass}>Emergency Contact Phone</label>
                <input type="text" placeholder="(310) 000-0000" value={emergencyContactPhone} onChange={(e) => setEmergencyContactPhone(e.target.value)} className={inputClass} />
              </div>
              <div className="sm:col-span-2">
                <label className={labelClass}><Megaphone className="w-3.5 h-3.5 text-stone-400" />Referral Source</label>
                <select value={referralSource} onChange={(e) => setReferralSource(e.target.value)} className={inputClass}>
                  {['Patient Referral', 'Physician Referral', 'Google Search', 'Instagram / Social Media', 'Insurance Directory', 'Walk-In', 'Other'].map((opt) => (
                    <option key={opt} value={opt}>{opt}</option>
                  ))}
                </select>
              </div>
            </div>
          </div>

          {/* SECTION: Insurance, Allergies & Notes */}
          <div className="space-y-3">
            <h3 className="text-[11px] font-bold uppercase tracking-wider text-stone-400 flex items-center gap-1.5">
              <CreditCard className="w-3.5 h-3.5 text-[#1F6E52]" />
              Insurance, Allergies & Notes
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <div className="md:col-span-2">
                <label className={labelClass}>
                  <CreditCard className="w-3.5 h-3.5 text-indigo-600" />
                  Payment Type
                </label>
                <select
                  value={paymentType}
                  onChange={(e) => setPaymentType(e.target.value)}
                  className="w-full px-3 py-2 bg-indigo-50/50 border border-indigo-200 rounded-xl text-xs font-bold text-stone-900 focus:ring-2 focus:ring-indigo-500 focus:outline-none cursor-pointer"
                >
                  {PAYMENT_TYPE_OPTIONS.map((opt) => (
                    <option key={opt} value={opt}>
                      {opt}
                    </option>
                  ))}
                </select>
              </div>

              <div className="md:col-span-2">
                <label className={labelClass}>
                  <ShieldAlert className="w-3.5 h-3.5 text-amber-600" />
                  Documented Allergies (Comma-separated)
                </label>
                <input
                  type="text"
                  placeholder="e.g. Latex, Penicillin, Codeine"
                  value={allergiesText}
                  onChange={(e) => setAllergiesText(e.target.value)}
                  className={inputClass}
                />
              </div>

              <div className="md:col-span-2">
                <label className={labelClass}>Registration Notes</label>
                <textarea
                  rows={2}
                  placeholder="Optional — any notes relevant to intake/registration"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-xl text-xs font-medium text-stone-900 focus:ring-2 focus:ring-indigo-500 focus:outline-none resize-none"
                />
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="pt-3 border-t border-stone-200 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 text-xs font-bold rounded-xl transition-colors cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-xl flex items-center gap-2 shadow-md transition-colors cursor-pointer"
            >
              <UserPlus className="w-4 h-4" />
              <span>Create Patient Chart & Generate 9 Forms</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
