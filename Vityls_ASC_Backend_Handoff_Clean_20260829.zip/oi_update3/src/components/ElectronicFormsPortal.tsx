import React, { useState, useEffect } from 'react';
import {
  FileText,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  Sparkles,
  Printer,
  X,
  Save,
  Sliders,
  PenTool,
  Calendar,
  Building2,
  Clock,
  User,
  Heart,
  Pill,
  Activity,
  FileCheck,
  ChevronRight,
  Download,
  Info,
  Edit3,
  RotateCcw
} from 'lucide-react';
import { PatientCase } from '../types';

export type ClinicalFormTab =
  | 'asc-1-hp'
  | 'asc-2-nursing'
  | 'asc-3-opnote'
  | 'asc-4-orders'
  | 'asc-5-discharge'
  | 'asc-6-mh'
  | 'asc-7-vte'
  | 'asc-4-timeout'
  | 'asc-recovery-record'
  | 'anesthesia-questionnaire'
  | 'anesthesia-record';

interface ElectronicFormsPortalProps {
  patient: PatientCase;
  appointmentDate?: string;
  initialTab?: ClinicalFormTab;
  isOpen?: boolean;
  isInline?: boolean;
  hideNavigationSidebar?: boolean;
  onClose?: () => void;
}

const getInitialFormData = (patient: PatientCase, appointmentDate: string) => {
  const allergyStr = patient.allergies && patient.allergies.length > 0 ? patient.allergies.join(', ') : '';
  const isNKDA = !allergyStr || allergyStr.toLowerCase().includes('none') || allergyStr.toLowerCase().includes('nkda');

  return {
    patientName: patient.name,
    dob: patient.dob || '',
    gender: patient.gender,
    patientId: patient.patientId,
    mrn: `MRN-${patient.patientId}-2026`,
    dos: appointmentDate,
    arrivalTime: '',
    modeOfArrival: '',
    accompaniedBy: '',
    responsibleParty: '',
    procedure: patient.procedure || '',
    laterality: '',
    surgeon: patient.surgeon || '',
    admittingDiagnosis: '',
    allergiesNKDA: isNKDA,
    allergiesDrug: !isNKDA,
    allergiesLatex: allergyStr.toLowerCase().includes('latex'),
    allergiesFood: false,
    allergyDetails: isNKDA ? 'None Known (NKDA)' : allergyStr,
    currentMeds: '',
    pmh: '',
    pastSurgicalHistory: '',
    anesthesiaComplications: '',
    familySocialHistory: '',
    rosCV: '',
    rosGI: '',
    rosNeuro: '',
    height: '',
    weight: '',
    bp: '',
    hr: '',
    rr: '',
    temp: '',
    spo2: '',
    painScore: '',
    asaClass: '',
    mallampati: '',
    npoConfirmed: '',
    clearanceStatus: 'Pending Clinical Assessment',
    physicianSigned: false,
    physicianSignedDate: '',
    rnSigned: false,
    rnSignedDate: '',
    anesthesiologistSigned: false,
    anesthesiologistSignedDate: '',
    patientSigned: false,
    patientSignedDate: '',
    preOpInHolding: '',
    timeIntoOR: '',
    surgeryStarted: '',
    surgeryEnded: '',
    timeOutOfOR: '',
    pacuArrival: '',
    aldreteScore: '',
    preOpDiag: '',
    postOpDiag: '',
    ebl: '',
    ivFluids: '',
    specimens: '',
    mhHistory: '',
    mhDantroleneStockVerified: false,
    mhHotlinePosted: false,
    capriniScore: '',
    vteProphylaxis: '',
  };
};

export const ElectronicFormsPortal: React.FC<ElectronicFormsPortalProps> = ({
  patient,
  appointmentDate = 'May 06, 2026',
  initialTab = 'asc-1-hp',
  isOpen = true,
  isInline = true,
  hideNavigationSidebar = false,
  onClose,
}) => {
  const [activeTab, setActiveTab] = useState<ClinicalFormTab>(initialTab);
  const [isSaved, setIsSaved] = useState(false);
  const [showCustomizationDrawer, setShowCustomizationDrawer] = useState(false);

  useEffect(() => {
    if (initialTab) {
      setActiveTab(initialTab);
    }
  }, [initialTab]);

  // Practice-specific Customization State
  const [facilityConfig, setFacilityConfig] = useState({
    facilityName: 'Vityls ASC',
    licenseNo: 'ASC-CA-90210-AV',
    aaahcAccreditation: 'AAAHC-88204-REV2',
    address: '1000 Vanguard Way, Suite 500, Beverly Hills, CA 90210',
    phone: '(310) 555-0199',
    fax: '(310) 555-0198',
    primarySurgeon: 'Primary Provider, M.D.',
    anesthesiologist: 'Anesthesia Provider, M.D.',
    requireDigitalSignatures: true,
  });

  // Dynamic Form Field State (Synchronized with selected patient)
  const [formData, setFormData] = useState(() => getInitialFormData(patient, appointmentDate));

  useEffect(() => {
    setFormData(getInitialFormData(patient, appointmentDate));
  }, [patient.id, patient.name, patient.patientId, appointmentDate]);

  if (!isOpen) return null;

  const handleSave = () => {
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 2500);
  };

  const handlePrint = () => {
    window.print();
  };

  const formTabs: Array<{ id: ClinicalFormTab; code: string; title: string; subtitle: string }> = [
    { id: 'asc-1-hp', code: 'ASC-8', title: 'Patient Admission / H&P Clearance', subtitle: 'History & Physical Pre-Op Clearance' },
    { id: 'asc-6-mh', code: 'ASC-9', title: 'Malignant Hyperthermia Screening', subtitle: 'MH Risk Screening & Dantrolene Log' },
    { id: 'asc-7-vte', code: 'ASC-10', title: 'VTE / DVT Risk Protocol', subtitle: 'Caprini Score & Prophylaxis Protocol' },
    { id: 'asc-4-orders', code: 'ASC-3', title: 'Doctors Standing Orders', subtitle: 'Pre-Op & Post-Op Orders (Vityls ASC)' },
    { id: 'asc-4-timeout', code: 'ASC-2', title: 'Comprehensive Surgical Safety Checklist', subtitle: 'AORN/WHO 4-Stage Check-In, Sign-In, Time-Out & Sign-Out' },
    { id: 'asc-3-opnote', code: 'ASC-4', title: 'Brief Operative Summary Note', subtitle: 'Surgeon Post-Op Summary, EBL, Fluids & Drains' },
    { id: 'asc-recovery-record', code: 'ASC-6', title: 'Recovery Room Record (PACU)', subtitle: 'Aldrete Score, Post-Op MD Orders & Discharge Criteria' },
    { id: 'asc-2-nursing', code: 'ASC-1', title: 'Pre-Op Checklist & Assessment', subtitle: 'Vitals, Allergies, Pre-Op Orders & Nurse Notes' },
    { id: 'anesthesia-record', code: 'ASC-5', title: 'Anesthesia Intra-Op Record', subtitle: 'Vital Signs Grid, Medications & Airway Log' },
    { id: 'asc-5-discharge', code: 'ASC-7', title: 'Post-Operative Discharge Instructions', subtitle: '16 Post-Op Rules & Signed Acknowledgment' },
  ];

  if (!isOpen && !isInline) return null;

  const innerPortal = (
    <div className={`bg-white w-full ${isInline ? 'rounded-2xl border border-stone-300 shadow-sm min-h-[750px]' : 'max-w-6xl h-[92vh] rounded-3xl shadow-2xl border border-stone-300'} flex flex-col overflow-hidden relative`}>
        
        {/* Top Header Bar */}
        <div className="bg-emerald-900 text-white px-5 py-4 flex flex-wrap items-center justify-between gap-3 shrink-0 border-b border-emerald-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-indigo-600 flex items-center justify-center text-white shadow-md">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-bold text-white tracking-wide">
                  Electronic Clinical Forms Module
                </h2>
                <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-[10px] font-bold">
                  HIPAA & AAAHC Compliant
                </span>
                <span className="px-2 py-0.5 rounded-md bg-indigo-500/20 text-indigo-200 text-[10px] font-mono">
                  Encounter: {appointmentDate}
                </span>
              </div>
              <p className="text-xs text-slate-300 font-medium mt-0.5">
                Patient: <strong className="text-white">{patient.name}</strong> ({patient.age}y {patient.gender}) · MRN: {formData.mrn} · Facility: {facilityConfig.facilityName}
              </p>
            </div>
          </div>

          {/* Action Toolbar */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                setFormData(getInitialFormData(patient, appointmentDate));
              }}
              title="Reset all form fields for this patient"
              className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer border border-slate-700"
            >
              <RotateCcw className="w-3.5 h-3.5 text-amber-400" />
              <span>Reset Form</span>
            </button>

            <button
              onClick={() => setShowCustomizationDrawer(!showCustomizationDrawer)}
              className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer border border-slate-700"
            >
              <Sliders className="w-3.5 h-3.5 text-indigo-400" />
              <span>Customize Practice Settings</span>
            </button>

            <button
              onClick={handlePrint}
              className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer border border-slate-700"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print / Export PDF</span>
            </button>

            <button
              onClick={handleSave}
              className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer shadow-sm"
            >
              <Save className="w-3.5 h-3.5" />
              <span>{isSaved ? 'Saved to EHR ✓' : 'Save Changes'}</span>
            </button>

            {onClose && !isInline && (
              <button
                onClick={onClose}
                className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors cursor-pointer ml-1"
              >
                <X className="w-5 h-5" />
              </button>
            )}
          </div>
        </div>

        {/* Practice Customization Panel Drawer Overlay */}
        {showCustomizationDrawer && (
          <div className="bg-indigo-950 text-white p-4 border-b border-indigo-800 animate-in slide-in-from-top duration-200 space-y-3 shrink-0">
            <div className="flex items-center justify-between border-b border-indigo-800 pb-2">
              <div className="flex items-center gap-2">
                <Sliders className="w-4 h-4 text-indigo-400" />
                <h3 className="text-xs font-bold text-white uppercase tracking-wider">
                  Practice-Specific Electronic Form Customization Engine
                </h3>
              </div>
              <button
                onClick={() => setShowCustomizationDrawer(false)}
                className="text-xs text-indigo-300 hover:text-white font-bold cursor-pointer"
              >
                Close Settings
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-4 gap-3 text-xs">
              <div>
                <label className="block text-[10px] font-bold text-indigo-300 uppercase mb-1">Facility Name</label>
                <input
                  type="text"
                  value={facilityConfig.facilityName}
                  onChange={(e) => setFacilityConfig({ ...facilityConfig, facilityName: e.target.value })}
                  className="w-full px-2.5 py-1.5 bg-indigo-900/80 border border-indigo-700 rounded-lg text-white text-xs focus:outline-none focus:ring-1 focus:ring-indigo-400"
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold text-indigo-300 uppercase mb-1">State License No.</label>
                <input
                  type="text"
                  value={facilityConfig.licenseNo}
                  onChange={(e) => setFacilityConfig({ ...facilityConfig, licenseNo: e.target.value })}
                  className="w-full px-2.5 py-1.5 bg-indigo-900/80 border border-indigo-700 rounded-lg text-white text-xs focus:outline-none focus:ring-1 focus:ring-indigo-400"
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold text-indigo-300 uppercase mb-1">AAAHC Accreditation No.</label>
                <input
                  type="text"
                  value={facilityConfig.aaahcAccreditation}
                  onChange={(e) => setFacilityConfig({ ...facilityConfig, aaahcAccreditation: e.target.value })}
                  className="w-full px-2.5 py-1.5 bg-indigo-900/80 border border-indigo-700 rounded-lg text-white text-xs focus:outline-none focus:ring-1 focus:ring-indigo-400"
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold text-indigo-300 uppercase mb-1">Default Attending Surgeon</label>
                <input
                  type="text"
                  value={facilityConfig.primarySurgeon}
                  onChange={(e) => setFacilityConfig({ ...facilityConfig, primarySurgeon: e.target.value })}
                  className="w-full px-2.5 py-1.5 bg-indigo-900/80 border border-indigo-700 rounded-lg text-white text-xs focus:outline-none focus:ring-1 focus:ring-indigo-400"
                />
              </div>
            </div>

            <div className="flex items-center gap-6 text-xs text-indigo-200 pt-1">
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={facilityConfig.requireDigitalSignatures}
                  onChange={(e) => setFacilityConfig({ ...facilityConfig, requireDigitalSignatures: e.target.checked })}
                  className="rounded text-indigo-500 focus:ring-0"
                />
                <span>Require Multi-Provider Digital Signatures (Surgeon, Anesthesiologist, RN)</span>
              </label>
            </div>
          </div>
        )}

        {/* Body Container: Horizontal Navigation + Form Canvas */}
        <div className="flex-1 flex flex-col md:flex-row overflow-hidden">
          
          {/* Left Form Navigation Sub-Sidebar */}
          {!hideNavigationSidebar && (
            <div className="w-full md:w-64 bg-emerald-950 text-emerald-100 p-3 space-y-1 overflow-y-auto shrink-0 border-r border-emerald-900">
              <div className="px-2 py-1 text-[10px] font-bold text-stone-400 uppercase tracking-wider">
                Converted Clinical Forms ({formTabs.length})
              </div>

              {formTabs.map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`w-full p-2.5 rounded-xl text-left transition-all cursor-pointer flex items-center justify-between gap-2 ${
                    activeTab === tab.id
                      ? 'bg-indigo-600 text-white font-bold shadow-md'
                      : 'hover:bg-stone-800 text-stone-300 hover:text-white font-medium'
                  }`}
                >
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-1.5">
                      <span className={`px-1.5 py-0.2 rounded text-[9px] font-mono font-bold ${
                        activeTab === tab.id ? 'bg-indigo-800 text-white' : 'bg-stone-800 text-stone-400'
                      }`}>
                        {tab.code}
                      </span>
                      <span className="text-xs truncate">{tab.title}</span>
                    </div>
                    <p className={`text-[10px] truncate mt-0.5 ${
                      activeTab === tab.id ? 'text-indigo-100' : 'text-stone-500'
                    }`}>
                      {tab.subtitle}
                    </p>
                  </div>
                  {activeTab === tab.id && <ChevronRight className="w-4 h-4 shrink-0 text-white" />}
                </button>
              ))}

              <div className="pt-3 border-t border-stone-800 px-2 text-[10px] text-stone-400 space-y-1">
                <p className="font-bold text-stone-300">Appointment Attachment:</p>
                <p>Attached collectively to encounter <strong className="text-stone-200">{appointmentDate}</strong>.</p>
              </div>
            </div>
          )}

          {/* Right HTML Form Canvas Area */}
          <div className="flex-1 overflow-y-auto p-4 sm:p-6 md:p-8 bg-stone-100/80 space-y-6">
            
            {/* Quick Form Selector Dropdown & Navigation Bar */}
            <div className="bg-white p-3.5 rounded-2xl border border-stone-300 shadow-2xs flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-2">
                <FileText className="w-4 h-4 text-indigo-600 shrink-0" />
                <span className="text-xs font-bold text-stone-800">Form Navigation:</span>
                <select
                  value={activeTab}
                  onChange={(e) => setActiveTab(e.target.value as ClinicalFormTab)}
                  className="bg-stone-100 hover:bg-stone-200/80 text-stone-900 text-xs font-bold py-1.5 px-3 rounded-xl border border-stone-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 cursor-pointer transition-colors"
                >
                  {formTabs.map((tab) => (
                    <option key={tab.id} value={tab.id}>
                      {tab.code}: {tab.title}
                    </option>
                  ))}
                </select>
              </div>

              {/* Prev / Next Form Navigation Buttons */}
              <div className="flex items-center gap-2">
                <button
                  disabled={formTabs.findIndex(t => t.id === activeTab) === 0}
                  onClick={() => {
                    const idx = formTabs.findIndex(t => t.id === activeTab);
                    if (idx > 0) setActiveTab(formTabs[idx - 1].id);
                  }}
                  className="px-3 py-1.5 bg-stone-100 hover:bg-stone-200 disabled:opacity-40 disabled:cursor-not-allowed text-stone-700 font-bold text-xs rounded-xl transition-colors cursor-pointer flex items-center gap-1 border border-stone-200"
                >
                  ← Previous Form
                </button>
                <span className="text-[11px] font-bold text-stone-600 font-mono">
                  {formTabs.findIndex(t => t.id === activeTab) + 1} of {formTabs.length}
                </span>
                <button
                  disabled={formTabs.findIndex(t => t.id === activeTab) === formTabs.length - 1}
                  onClick={() => {
                    const idx = formTabs.findIndex(t => t.id === activeTab);
                    if (idx < formTabs.length - 1) setActiveTab(formTabs[idx + 1].id);
                  }}
                  className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-40 disabled:cursor-not-allowed text-white font-bold text-xs rounded-xl transition-colors cursor-pointer flex items-center gap-1 shadow-2xs"
                >
                  Next Form →
                </button>
              </div>
            </div>
            
            {/* FACILITY & PATIENT HEADER BLOCK (Standard across all forms) */}
            <div className="bg-white p-5 rounded-2xl border border-stone-300 shadow-2xs space-y-3 font-sans">
              <div className="flex flex-wrap items-center justify-between gap-3 border-b border-stone-200 pb-3">
                <div>
                  <h1 className="text-sm font-bold text-stone-900 tracking-wider uppercase font-serif">
                    {facilityConfig.facilityName}
                  </h1>
                  <p className="text-[11px] text-stone-500">
                    License No: {facilityConfig.licenseNo} · AAAHC Accr No: {facilityConfig.aaahcAccreditation}
                  </p>
                </div>
                <div className="text-right">
                  <span className="text-xs font-bold text-indigo-900 bg-indigo-50 px-2.5 py-1 rounded-lg border border-indigo-200 inline-block font-mono">
                    {formTabs.find((t) => t.id === activeTab)?.code} — {formTabs.find((t) => t.id === activeTab)?.title}
                  </span>
                  <p className="text-[10px] text-stone-400 mt-0.5">Freestanding Outpatient Surgical Facility Record</p>
                </div>
              </div>

              {/* Patient Identification Header Bar */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-stone-50 p-3 rounded-xl border border-stone-200 text-xs">
                <div>
                  <span className="text-[10px] font-bold text-stone-400 uppercase block">Patient Name</span>
                  <input
                    type="text"
                    value={formData.patientName}
                    onChange={(e) => setFormData({ ...formData, patientName: e.target.value })}
                    className="font-bold text-stone-900 bg-transparent border-b border-dashed border-stone-300 focus:outline-none w-full"
                  />
                </div>
                <div>
                  <span className="text-[10px] font-bold text-stone-400 uppercase block">DOB / Age / Sex</span>
                  <span className="font-semibold text-stone-800">{formData.dob} ({patient.age}y / {formData.gender})</span>
                </div>
                <div>
                  <span className="text-[10px] font-bold text-stone-400 uppercase block">Medical Record No (MRN)</span>
                  <span className="font-mono font-bold text-stone-800">{formData.mrn}</span>
                </div>
                <div>
                  <span className="text-[10px] font-bold text-stone-400 uppercase block">Date of Service (DOS)</span>
                  <span className="font-bold text-indigo-900">{formData.dos}</span>
                </div>
              </div>
            </div>

            {/* ------------------------------------------------------------------------------------- */}
            {/* FORM 1: ASC-1 PATIENT ADMISSION / HISTORY & PHYSICAL */}
            {/* ------------------------------------------------------------------------------------- */}
            {activeTab === 'asc-1-hp' && (
              <div className="bg-white p-6 rounded-2xl border border-stone-300 shadow-sm space-y-6 text-xs text-stone-900">
                <div className="border-b-2 border-stone-800 pb-2 flex items-center justify-between">
                  <h2 className="text-sm font-bold uppercase tracking-wider text-stone-900">
                    Patient Admission / History & Physical (Form ASC-1)
                  </h2>
                  <span className="text-[10px] text-stone-500 font-medium">Mapped to 22 CCR §70527 & AAAHC Ch. 6</span>
                </div>

                {/* Arrival / Admission Section */}
                <div className="space-y-3">
                  <h3 className="font-bold text-xs uppercase tracking-wider text-stone-900 bg-stone-100 p-2 rounded-lg border border-stone-200">
                    1. Arrival / Admission Details (22 CCR §70527d)
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                    <div>
                      <label className="block text-[10px] font-bold text-stone-500 uppercase mb-1">Date/Time of Arrival</label>
                      <input
                        type="text"
                        value={formData.arrivalTime}
                        onChange={(e) => setFormData({ ...formData, arrivalTime: e.target.value })}
                        className="w-full p-2 bg-stone-50 border border-stone-300 rounded-lg text-xs font-semibold focus:ring-1 focus:ring-indigo-500"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-stone-500 uppercase mb-1">Mode of Arrival</label>
                      <select
                        value={formData.modeOfArrival}
                        onChange={(e) => setFormData({ ...formData, modeOfArrival: e.target.value })}
                        className="w-full p-2 bg-stone-50 border border-stone-300 rounded-lg text-xs font-semibold focus:ring-1 focus:ring-indigo-500"
                      >
                        <option value="Ambulatory">Ambulatory</option>
                        <option value="Wheelchair">Wheelchair</option>
                        <option value="Stretcher">Stretcher</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-stone-500 uppercase mb-1">Accompanied By</label>
                      <input
                        type="text"
                        value={formData.accompaniedBy}
                        onChange={(e) => setFormData({ ...formData, accompaniedBy: e.target.value })}
                        className="w-full p-2 bg-stone-50 border border-stone-300 rounded-lg text-xs font-semibold focus:ring-1 focus:ring-indigo-500"
                      />
                    </div>
                  </div>
                </div>

                {/* Scheduled Procedure & Diagnosis */}
                <div className="space-y-3">
                  <h3 className="font-bold text-xs uppercase tracking-wider text-stone-900 bg-stone-100 p-2 rounded-lg border border-stone-200">
                    2. Scheduled Procedure & Admitting Diagnosis (22 CCR §70527c1)
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                    <div className="md:col-span-2">
                      <label className="block text-[10px] font-bold text-stone-500 uppercase mb-1">Scheduled Procedure(s)</label>
                      <input
                        type="text"
                        value={formData.procedure}
                        onChange={(e) => setFormData({ ...formData, procedure: e.target.value })}
                        className="w-full p-2 bg-stone-50 border border-stone-300 rounded-lg text-xs font-bold text-indigo-950 focus:ring-1 focus:ring-indigo-500"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-stone-500 uppercase mb-1">Scheduled Surgeon</label>
                      <input
                        type="text"
                        value={formData.surgeon}
                        onChange={(e) => setFormData({ ...formData, surgeon: e.target.value })}
                        className="w-full p-2 bg-stone-50 border border-stone-300 rounded-lg text-xs font-semibold focus:ring-1 focus:ring-indigo-500"
                      />
                    </div>
                  </div>
                </div>

                {/* Allergies Section */}
                <div className="space-y-3">
                  <h3 className="font-bold text-xs uppercase tracking-wider text-stone-900 bg-rose-50 text-rose-950 p-2 rounded-lg border border-rose-200 flex items-center justify-between">
                    <span>3. Allergy Status (AAAHC Ch. 6 — Prominent Location Requirement)</span>
                    <AlertCircle className="w-4 h-4 text-rose-600" />
                  </h3>
                  <div className="p-3 bg-rose-50/50 rounded-xl border border-rose-200 space-y-2">
                    <div className="flex flex-wrap items-center gap-4 text-xs font-semibold text-rose-900">
                      <label className="flex items-center gap-1.5 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={formData.allergiesNKDA}
                          onChange={(e) => setFormData({ ...formData, allergiesNKDA: e.target.checked })}
                          className="rounded text-rose-600 focus:ring-0"
                        />
                        <span>NKDA (No Known Drug Allergies)</span>
                      </label>

                      <label className="flex items-center gap-1.5 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={formData.allergiesDrug}
                          onChange={(e) => setFormData({ ...formData, allergiesDrug: e.target.checked })}
                          className="rounded text-rose-600 focus:ring-0"
                        />
                        <span className="font-bold text-rose-800">Drug Allergy</span>
                      </label>

                      <label className="flex items-center gap-1.5 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={formData.allergiesLatex}
                          onChange={(e) => setFormData({ ...formData, allergiesLatex: e.target.checked })}
                          className="rounded text-rose-600 focus:ring-0"
                        />
                        <span>Latex Allergy</span>
                      </label>

                      <label className="flex items-center gap-1.5 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={formData.allergiesFood}
                          onChange={(e) => setFormData({ ...formData, allergiesFood: e.target.checked })}
                          className="rounded text-rose-600 focus:ring-0"
                        />
                        <span>Food / Environmental</span>
                      </label>
                    </div>

                    <div>
                      <label className="block text-[10px] font-bold text-rose-900 uppercase mb-1">List Specific Allergies & Reaction Type</label>
                      <input
                        type="text"
                        value={formData.allergyDetails}
                        onChange={(e) => setFormData({ ...formData, allergyDetails: e.target.value })}
                        className="w-full p-2 bg-white border border-rose-300 rounded-lg text-xs font-bold text-rose-950 focus:ring-1 focus:ring-rose-500"
                      />
                    </div>
                  </div>
                </div>

                {/* Physical Examination & Vitals */}
                <div className="space-y-3">
                  <h3 className="font-bold text-xs uppercase tracking-wider text-stone-900 bg-stone-100 p-2 rounded-lg border border-stone-200">
                    4. Physical Examination & Pre-Op Evaluation (22 CCR §70527c3)
                  </h3>
                  <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-8 gap-2">
                    <div className="p-2 bg-stone-50 rounded-lg border border-stone-200">
                      <span className="text-[9px] font-bold text-stone-400 block uppercase">Height</span>
                      <input type="text" value={formData.height} onChange={(e) => setFormData({ ...formData, height: e.target.value })} className="font-bold text-xs w-full bg-transparent border-b border-stone-300" />
                    </div>
                    <div className="p-2 bg-stone-50 rounded-lg border border-stone-200">
                      <span className="text-[9px] font-bold text-stone-400 block uppercase">Weight</span>
                      <input type="text" value={formData.weight} onChange={(e) => setFormData({ ...formData, weight: e.target.value })} className="font-bold text-xs w-full bg-transparent border-b border-stone-300" />
                    </div>
                    <div className="p-2 bg-stone-50 rounded-lg border border-stone-200">
                      <span className="text-[9px] font-bold text-stone-400 block uppercase">BP</span>
                      <input type="text" value={formData.bp} onChange={(e) => setFormData({ ...formData, bp: e.target.value })} className="font-bold text-xs w-full bg-transparent border-b border-stone-300" />
                    </div>
                    <div className="p-2 bg-stone-50 rounded-lg border border-stone-200">
                      <span className="text-[9px] font-bold text-stone-400 block uppercase">HR</span>
                      <input type="text" value={formData.hr} onChange={(e) => setFormData({ ...formData, hr: e.target.value })} className="font-bold text-xs w-full bg-transparent border-b border-stone-300" />
                    </div>
                    <div className="p-2 bg-stone-50 rounded-lg border border-stone-200">
                      <span className="text-[9px] font-bold text-stone-400 block uppercase">RR</span>
                      <input type="text" value={formData.rr} onChange={(e) => setFormData({ ...formData, rr: e.target.value })} className="font-bold text-xs w-full bg-transparent border-b border-stone-300" />
                    </div>
                    <div className="p-2 bg-stone-50 rounded-lg border border-stone-200">
                      <span className="text-[9px] font-bold text-stone-400 block uppercase">Temp</span>
                      <input type="text" value={formData.temp} onChange={(e) => setFormData({ ...formData, temp: e.target.value })} className="font-bold text-xs w-full bg-transparent border-b border-stone-300" />
                    </div>
                    <div className="p-2 bg-stone-50 rounded-lg border border-stone-200">
                      <span className="text-[9px] font-bold text-stone-400 block uppercase">SpO2</span>
                      <input type="text" value={formData.spo2} onChange={(e) => setFormData({ ...formData, spo2: e.target.value })} className="font-bold text-xs w-full bg-transparent border-b border-stone-300" />
                    </div>
                    <div className="p-2 bg-stone-50 rounded-lg border border-stone-200">
                      <span className="text-[9px] font-bold text-stone-400 block uppercase">Pain Score</span>
                      <input type="text" value={formData.painScore} onChange={(e) => setFormData({ ...formData, painScore: e.target.value })} className="font-bold text-xs w-full bg-transparent border-b border-stone-300" />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-3 pt-2">
                    <div>
                      <label className="block text-[10px] font-bold text-stone-500 uppercase mb-1">ASA Physical Status Class</label>
                      <input type="text" value={formData.asaClass} onChange={(e) => setFormData({ ...formData, asaClass: e.target.value })} className="w-full p-2 bg-stone-50 border border-stone-300 rounded-lg text-xs font-semibold" />
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-stone-500 uppercase mb-1">Airway Assessment (Mallampati)</label>
                      <input type="text" value={formData.mallampati} onChange={(e) => setFormData({ ...formData, mallampati: e.target.value })} className="w-full p-2 bg-stone-50 border border-stone-300 rounded-lg text-xs font-semibold" />
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-stone-500 uppercase mb-1">NPO Status Confirmed Since</label>
                      <input type="text" value={formData.npoConfirmed} onChange={(e) => setFormData({ ...formData, npoConfirmed: e.target.value })} className="w-full p-2 bg-stone-50 border border-stone-300 rounded-lg text-xs font-semibold text-emerald-800" />
                    </div>
                  </div>
                </div>

                {/* Clearance & Signatures */}
                <div className="p-4 bg-emerald-50/80 rounded-xl border border-emerald-200 space-y-3">
                  <div className="flex items-center justify-between border-b border-emerald-200 pb-2">
                    <span className="font-bold text-xs text-emerald-950 flex items-center gap-1.5">
                      <ShieldCheck className="w-4 h-4 text-emerald-600" />
                      <span>5. Clearance For Surgery & Physician Electronic Signatures</span>
                    </span>
                    <span className="px-2 py-0.5 rounded bg-emerald-600 text-white font-bold text-[10px]">
                      {formData.clearanceStatus}
                    </span>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-3 pt-1">
                    <div className="p-3 bg-white rounded-lg border border-emerald-300 space-y-1">
                      <span className="text-[10px] font-bold text-stone-400 block uppercase">Examining Physician / Practitioner</span>
                      <div className="font-serif italic font-bold text-indigo-900 text-sm">
                        {patient.surgeon || 'Primary Provider'}
                      </div>
                      <span className="text-[10px] text-emerald-700 font-bold block">
                        ✓ Digitally Signed on {formData.physicianSignedDate}
                      </span>
                    </div>

                    <div className="p-3 bg-white rounded-lg border border-emerald-300 space-y-1">
                      <span className="text-[10px] font-bold text-stone-400 block uppercase">Anesthesiologist Clearance</span>
                      <div className="font-serif italic font-bold text-indigo-900 text-sm">
                        {patient.anesthesiologist || 'Anesthesia Provider'}
                      </div>
                      <span className="text-[10px] text-emerald-700 font-bold block">
                        ✓ Digitally Signed on {formData.anesthesiologistSignedDate}
                      </span>
                    </div>

                    <div className="p-3 bg-white rounded-lg border border-emerald-300 space-y-1">
                      <span className="text-[10px] font-bold text-stone-400 block uppercase">Pre-Op RN Admitting Nurse</span>
                      <div className="font-serif italic font-bold text-indigo-900 text-sm">
                        U. Kriskier, RN
                      </div>
                      <span className="text-[10px] text-emerald-700 font-bold block">
                        ✓ Digitally Signed on {formData.rnSignedDate}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* ------------------------------------------------------------------------------------- */}
            {/* FORM 2: ASC-2 PERIOPERATIVE NURSING ASSESSMENT & NOTES */}
            {/* ------------------------------------------------------------------------------------- */}
            {activeTab === 'asc-2-nursing' && (
              <div className="bg-white p-6 rounded-2xl border border-stone-300 shadow-sm space-y-6 text-xs text-stone-900">
                <div className="border-b-2 border-stone-800 pb-2 flex items-center justify-between">
                  <h2 className="text-sm font-bold uppercase tracking-wider text-stone-900">
                    Perioperative Nursing Assessment & Notes (Form ASC-2)
                  </h2>
                  <span className="text-[10px] text-stone-500 font-medium">Mapped to 22 CCR §70527c & AAAHC Ch. 10</span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {/* Pre-Op Nursing Block */}
                  <div className="p-4 bg-stone-50 rounded-xl border border-stone-300 space-y-3">
                    <h3 className="font-bold text-xs text-indigo-950 uppercase border-b border-stone-200 pb-1">
                      Phase 1: Pre-Op Assessment
                    </h3>
                    <div className="text-[11px] space-y-2 text-stone-700 font-medium">
                      <div>
                        <label className="block text-[10px] font-bold text-stone-500 uppercase mb-0.5">Time Assessment</label>
                        <input type="text" placeholder="e.g. 07:30 AM" value={formData.preOpInHolding} onChange={(e) => setFormData({ ...formData, preOpInHolding: e.target.value })} className="w-full p-1.5 bg-white border border-stone-300 rounded text-xs font-semibold" />
                      </div>
                      <div>
                        <label className="block text-[10px] font-bold text-stone-500 uppercase mb-0.5">Surgical Site Marked</label>
                        <input type="text" placeholder="e.g. Face & Neck / Left Side" value={formData.laterality} onChange={(e) => setFormData({ ...formData, laterality: e.target.value })} className="w-full p-1.5 bg-white border border-stone-300 rounded text-xs" />
                      </div>
                      <div>
                        <label className="block text-[10px] font-bold text-stone-500 uppercase mb-0.5">IV Access Location & Gauge</label>
                        <input type="text" placeholder="e.g. 20G Left Forearm" value={formData.ivFluids} onChange={(e) => setFormData({ ...formData, ivFluids: e.target.value })} className="w-full p-1.5 bg-white border border-stone-300 rounded text-xs" />
                      </div>
                      <div className="pt-1 space-y-1">
                        <label className="flex items-center gap-2 cursor-pointer text-xs">
                          <input type="checkbox" className="rounded text-indigo-600 focus:ring-0" />
                          <span>Informed Consent Verified</span>
                        </label>
                        <label className="flex items-center gap-2 cursor-pointer text-xs">
                          <input type="checkbox" className="rounded text-indigo-600 focus:ring-0" />
                          <span>Allergies Re-confirmed</span>
                        </label>
                        <label className="flex items-center gap-2 cursor-pointer text-xs">
                          <input type="checkbox" className="rounded text-indigo-600 focus:ring-0" />
                          <span>NPO Status Verified</span>
                        </label>
                      </div>
                    </div>
                  </div>

                  {/* Intra-Op Nursing Block */}
                  <div className="p-4 bg-stone-50 rounded-xl border border-stone-300 space-y-3">
                    <h3 className="font-bold text-xs text-indigo-950 uppercase border-b border-stone-200 pb-1">
                      Phase 2: Intra-Op Notes
                    </h3>
                    <div className="text-[11px] space-y-2 text-stone-700 font-medium">
                      <div>
                        <label className="block text-[10px] font-bold text-stone-500 uppercase mb-0.5">Time Into OR</label>
                        <input type="text" placeholder="e.g. 08:15 AM" value={formData.timeIntoOR} onChange={(e) => setFormData({ ...formData, timeIntoOR: e.target.value })} className="w-full p-1.5 bg-white border border-stone-300 rounded text-xs font-semibold" />
                      </div>
                      <div className="grid grid-cols-2 gap-1.5">
                        <div>
                          <label className="block text-[10px] font-bold text-stone-500 uppercase mb-0.5">Start Time</label>
                          <input type="text" placeholder="08:35 AM" value={formData.surgeryStarted} onChange={(e) => setFormData({ ...formData, surgeryStarted: e.target.value })} className="w-full p-1.5 bg-white border border-stone-300 rounded text-xs" />
                        </div>
                        <div>
                          <label className="block text-[10px] font-bold text-stone-500 uppercase mb-0.5">End Time</label>
                          <input type="text" placeholder="11:45 AM" value={formData.surgeryEnded} onChange={(e) => setFormData({ ...formData, surgeryEnded: e.target.value })} className="w-full p-1.5 bg-white border border-stone-300 rounded text-xs" />
                        </div>
                      </div>
                      <div>
                        <label className="block text-[10px] font-bold text-stone-500 uppercase mb-0.5">Patient Position</label>
                        <input type="text" placeholder="e.g. Supine / Head Elevated" className="w-full p-1.5 bg-white border border-stone-300 rounded text-xs" />
                      </div>
                      <div className="pt-1 space-y-1">
                        <label className="flex items-center gap-2 cursor-pointer text-xs">
                          <input type="checkbox" className="rounded text-indigo-600 focus:ring-0" />
                          <span>WHO Surgical Time-Out Conducted</span>
                        </label>
                        <label className="flex items-center gap-2 cursor-pointer text-xs">
                          <input type="checkbox" className="rounded text-indigo-600 focus:ring-0" />
                          <span>Sponge, Sharps & Instrument Counts Correct</span>
                        </label>
                      </div>
                    </div>
                  </div>

                  {/* PACU Recovery Block */}
                  <div className="p-4 bg-stone-50 rounded-xl border border-stone-300 space-y-3">
                    <h3 className="font-bold text-xs text-indigo-950 uppercase border-b border-stone-200 pb-1">
                      Phase 3: PACU Recovery Notes
                    </h3>
                    <div className="text-[11px] space-y-2 text-stone-700 font-medium">
                      <div>
                        <label className="block text-[10px] font-bold text-stone-500 uppercase mb-0.5">Time Arrived PACU</label>
                        <input type="text" placeholder="e.g. 12:05 PM" value={formData.pacuArrival} onChange={(e) => setFormData({ ...formData, pacuArrival: e.target.value })} className="w-full p-1.5 bg-white border border-stone-300 rounded text-xs font-semibold" />
                      </div>
                      <div>
                        <label className="block text-[10px] font-bold text-stone-500 uppercase mb-0.5">Initial Aldrete Score</label>
                        <input type="text" placeholder="e.g. 10 / 10" value={formData.aldreteScore} onChange={(e) => setFormData({ ...formData, aldreteScore: e.target.value })} className="w-full p-1.5 bg-white border border-stone-300 rounded text-xs font-semibold" />
                      </div>
                      <div>
                        <label className="block text-[10px] font-bold text-stone-500 uppercase mb-0.5">Level of Consciousness & Dressing</label>
                        <input type="text" placeholder="e.g. Alert, dressing clean & dry" className="w-full p-1.5 bg-white border border-stone-300 rounded text-xs" />
                      </div>
                      <div className="pt-1 space-y-1">
                        <label className="flex items-center gap-2 cursor-pointer text-xs">
                          <input type="checkbox" className="rounded text-indigo-600 focus:ring-0" />
                          <span>Post-Op Vitals Stable</span>
                        </label>
                        <label className="flex items-center gap-2 cursor-pointer text-xs">
                          <input type="checkbox" className="rounded text-indigo-600 focus:ring-0" />
                          <span>Discharge Criteria Met</span>
                        </label>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="p-3 bg-stone-50 border border-stone-200 rounded-xl flex items-center justify-between text-xs text-stone-900 font-bold">
                  <span>Circulating RN Sign-Off</span>
                  <input type="text" placeholder="Enter RN Name / Electronic Signature" className="p-1.5 bg-white border border-stone-300 rounded text-xs font-serif italic font-normal w-64" />
                </div>
              </div>
            )}

            {/* ------------------------------------------------------------------------------------- */}
            {/* FORM 3: ASC-3 BRIEF OPERATIVE NOTE */}
            {/* ------------------------------------------------------------------------------------- */}
            {activeTab === 'asc-3-opnote' && (
              <div className="bg-white p-6 rounded-2xl border border-stone-300 shadow-sm space-y-6 text-xs text-stone-900">
                <div className="border-b-2 border-stone-800 pb-2 flex items-center justify-between">
                  <h2 className="text-sm font-bold uppercase tracking-wider text-stone-900">
                    Brief Operative Note (Form ASC-3)
                  </h2>
                  <span className="text-[10px] font-mono text-indigo-900 bg-indigo-50 px-2 py-0.5 rounded border border-indigo-200">
                    Entered Immediately Post-Op
                  </span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-3">
                    <div>
                      <label className="block text-[10px] font-bold text-stone-500 uppercase mb-1">Pre-Operative Diagnosis</label>
                      <input type="text" value={formData.preOpDiag} onChange={(e) => setFormData({ ...formData, preOpDiag: e.target.value })} className="w-full p-2 bg-stone-50 border border-stone-300 rounded-lg text-xs font-semibold" />
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-stone-500 uppercase mb-1">Post-Operative Diagnosis</label>
                      <input type="text" value={formData.postOpDiag} onChange={(e) => setFormData({ ...formData, postOpDiag: e.target.value })} className="w-full p-2 bg-stone-50 border border-stone-300 rounded-lg text-xs font-bold text-indigo-950" />
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-stone-500 uppercase mb-1">Procedure(s) Performed</label>
                      <textarea value={formData.procedure} onChange={(e) => setFormData({ ...formData, procedure: e.target.value })} className="w-full p-2 bg-stone-50 border border-stone-300 rounded-lg text-xs font-semibold h-16" />
                    </div>
                  </div>

                  <div className="space-y-3">
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <label className="block text-[10px] font-bold text-stone-500 uppercase mb-1">Estimated Blood Loss (EBL)</label>
                        <input type="text" value={formData.ebl} onChange={(e) => setFormData({ ...formData, ebl: e.target.value })} className="w-full p-2 bg-stone-50 border border-stone-300 rounded-lg text-xs font-bold text-stone-900" />
                      </div>
                      <div>
                        <label className="block text-[10px] font-bold text-stone-500 uppercase mb-1">IV Fluids Administered</label>
                        <input type="text" value={formData.ivFluids} onChange={(e) => setFormData({ ...formData, ivFluids: e.target.value })} className="w-full p-2 bg-stone-50 border border-stone-300 rounded-lg text-xs font-semibold" />
                      </div>
                    </div>

                    <div>
                      <label className="block text-[10px] font-bold text-stone-500 uppercase mb-1">Specimens & Pathology</label>
                      <textarea value={formData.specimens} onChange={(e) => setFormData({ ...formData, specimens: e.target.value })} className="w-full p-2 bg-stone-50 border border-stone-300 rounded-lg text-xs font-medium h-20" />
                    </div>
                  </div>
                </div>

                <div className="p-3 bg-stone-50 rounded-xl border border-stone-300 flex items-center justify-between">
                  <span className="font-bold text-xs text-stone-800">Primary Surgeon Signature: {patient.surgeon || 'Primary Provider'}</span>
                  <span className="text-[10px] text-emerald-700 font-bold">✓ Recorded Immediately Post-Op</span>
                </div>
              </div>
            )}

            {/* ------------------------------------------------------------------------------------- */}
            {/* FORM 4: ASC-4 PHYSICIAN ORDERS SHEET */}
            {/* ------------------------------------------------------------------------------------- */}
            {activeTab === 'asc-4-orders' && (
              <div className="bg-white p-6 rounded-2xl border border-stone-300 shadow-sm space-y-6 text-xs text-stone-900">
                <div className="border-b-2 border-stone-800 pb-2 flex items-center justify-between">
                  <h2 className="text-sm font-bold uppercase tracking-wider text-stone-900">
                    Physician Orders Sheet (Form ASC-4)
                  </h2>
                  <span className="text-[10px] text-stone-500 font-medium">Mapped to 22 CCR §70527c2,6</span>
                </div>

                <div className="space-y-4">
                  <div className="p-3.5 bg-stone-50 rounded-xl border border-stone-200 space-y-2">
                    <h3 className="font-bold text-xs text-stone-900 uppercase">Pre-Operative Orders</h3>
                    <textarea placeholder="Enter pre-operative physician orders (e.g., NPO status, pre-op IV antibiotics, site marking)..." className="w-full p-2 bg-white border border-stone-300 rounded text-xs h-24" />
                  </div>

                  <div className="p-3.5 bg-stone-50 rounded-xl border border-stone-200 space-y-2">
                    <h3 className="font-bold text-xs text-stone-900 uppercase">Post-Operative Orders</h3>
                    <textarea placeholder="Enter post-operative physician orders (e.g., antiemetics, analgesics, diet advancement, discharge criteria)..." className="w-full p-2 bg-white border border-stone-300 rounded text-xs h-24" />
                  </div>
                </div>
              </div>
            )}

            {/* ------------------------------------------------------------------------------------- */}
            {/* FORM 5: ASC-5 DISCHARGE SUMMARY */}
            {/* ------------------------------------------------------------------------------------- */}
            {activeTab === 'asc-5-discharge' && (
              <div className="bg-white p-6 rounded-2xl border border-stone-300 shadow-sm space-y-6 text-xs text-stone-900">
                <div className="border-b-2 border-stone-800 pb-2 flex items-center justify-between">
                  <h2 className="text-sm font-bold uppercase tracking-wider text-stone-900">
                    Patient Discharge Summary (Form ASC-5)
                  </h2>
                  <span className="text-[10px] text-stone-500 font-medium">Mapped to 22 CCR §70527c7</span>
                </div>

                <div className="p-4 bg-stone-50 rounded-xl border border-stone-300 space-y-3">
                  <h3 className="font-bold text-xs text-stone-900 uppercase">Discharge Disposition & Condition</h3>
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 text-xs">
                    <div>
                      <label className="block text-[10px] font-bold text-stone-500 uppercase mb-1">Discharge Vitals</label>
                      <input type="text" placeholder="e.g. 118/74 BP, HR 72" className="w-full p-2 bg-white border border-stone-300 rounded text-xs" />
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-stone-500 uppercase mb-1">Pain Score at Discharge</label>
                      <input type="text" placeholder="e.g. 0 / 10" className="w-full p-2 bg-white border border-stone-300 rounded text-xs" />
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-stone-500 uppercase mb-1">Alertness & Orientation</label>
                      <input type="text" placeholder="e.g. A&O x4" className="w-full p-2 bg-white border border-stone-300 rounded text-xs" />
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-stone-500 uppercase mb-1">Responsible Escort</label>
                      <input type="text" placeholder="Name & Contact Phone" value={formData.responsibleParty} onChange={(e) => setFormData({ ...formData, responsibleParty: e.target.value })} className="w-full p-2 bg-white border border-stone-300 rounded text-xs" />
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* ------------------------------------------------------------------------------------- */}
            {/* FORM 6: ASC-6 MALIGNANT HYPERTHERMIA SCREENING */}
            {/* ------------------------------------------------------------------------------------- */}
            {activeTab === 'asc-6-mh' && (
              <div className="bg-white p-6 rounded-2xl border border-stone-300 shadow-sm space-y-6 text-xs text-stone-900">
                <div className="border-b-2 border-stone-800 pb-2 flex items-center justify-between">
                  <h2 className="text-sm font-bold uppercase tracking-wider text-stone-900">
                    Malignant Hyperthermia (MH) Screening & Emergency Response Record (Form ASC-6)
                  </h2>
                  <span className="text-[10px] text-stone-500 font-medium">SAMBA / ASA & MHAUS Guidelines</span>
                </div>

                <div className="space-y-4">
                  <div className="p-4 bg-stone-50 rounded-xl border border-stone-300 space-y-2">
                    <h3 className="font-bold text-xs text-stone-900 uppercase">1. Pre-Operative MH Risk Screening</h3>
                    <label className="flex items-center gap-2 cursor-pointer text-xs">
                      <input type="checkbox" className="rounded text-indigo-600 focus:ring-0" />
                      <span>No personal or family history of MH, unexplained anesthesia deaths, or muscle disorders.</span>
                    </label>
                    <textarea placeholder="Enter any MH risk factors or family history notes..." className="w-full p-2 bg-white border border-stone-300 rounded text-xs h-16 mt-2" />
                  </div>

                  <div className="p-4 bg-stone-50 rounded-xl border border-stone-300 space-y-2">
                    <h3 className="font-bold text-xs text-stone-900 uppercase">
                      2. MH Cart & Dantrolene Readiness Verification (Daily Check)
                    </h3>
                    <div className="space-y-2 text-xs font-semibold text-stone-800">
                      <label className="flex items-center gap-2 cursor-pointer">
                        <input type="checkbox" checked={formData.mhDantroleneStockVerified} onChange={(e) => setFormData({ ...formData, mhDantroleneStockVerified: e.target.checked })} className="rounded text-indigo-600 focus:ring-0" />
                        <span>Dantrolene stock present within expiration (36 x 20mg)</span>
                      </label>
                      <label className="flex items-center gap-2 cursor-pointer">
                        <input type="checkbox" checked={formData.mhHotlinePosted} onChange={(e) => setFormData({ ...formData, mhHotlinePosted: e.target.checked })} className="rounded text-indigo-600 focus:ring-0" />
                        <span>MH Hotline Number Posted: 1-800-644-9737 & Cooling Supplies Verified</span>
                      </label>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* ------------------------------------------------------------------------------------- */}
            {/* FORM 7: ASC-7 VTE / DVT RISK ASSESSMENT */}
            {/* ------------------------------------------------------------------------------------- */}
            {activeTab === 'asc-7-vte' && (
              <div className="bg-white p-6 rounded-2xl border border-stone-300 shadow-sm space-y-6 text-xs text-stone-900">
                <div className="border-b-2 border-stone-800 pb-2 flex items-center justify-between">
                  <h2 className="text-sm font-bold uppercase tracking-wider text-stone-900">
                    VTE / DVT Risk Assessment & Prophylaxis Orders (Form ASC-7)
                  </h2>
                  <span className="text-[10px] text-stone-500 font-medium">Caprini / Padua Model Assessment</span>
                </div>

                <div className="p-4 bg-stone-50 rounded-xl border border-stone-300 space-y-3">
                  <div className="flex justify-between items-center border-b border-stone-200 pb-2">
                    <span className="font-bold text-xs text-stone-900">Caprini Risk Score:</span>
                    <input type="text" placeholder="Enter score" value={formData.capriniScore} onChange={(e) => setFormData({ ...formData, capriniScore: e.target.value })} className="p-1.5 bg-white border border-stone-300 rounded text-xs w-32 font-bold" />
                  </div>

                  <div className="space-y-2">
                    <label className="block text-[10px] font-bold text-stone-500 uppercase">Ordered Prophylaxis Protocol</label>
                    <textarea placeholder="e.g. Sequential Compression Devices (SCDs) intra-operatively + Early post-operative ambulation..." value={formData.vteProphylaxis} onChange={(e) => setFormData({ ...formData, vteProphylaxis: e.target.value })} className="w-full p-2 bg-white border border-stone-300 rounded text-xs h-20" />
                  </div>
                </div>
              </div>
            )}

            {/* ------------------------------------------------------------------------------------- */}
            {/* FORM: ASC-4-TIMEOUT COMPREHENSIVE SURGICAL SAFETY CHECKLIST (AORN/WHO) */}
            {/* ------------------------------------------------------------------------------------- */}
            {activeTab === 'asc-4-timeout' && (
              <div className="bg-white p-6 rounded-2xl border border-stone-300 shadow-sm space-y-6 text-xs text-stone-900">
                <div className="border-b-2 border-stone-800 pb-2 flex items-center justify-between">
                  <h2 className="text-sm font-bold uppercase tracking-wider text-stone-900">
                    Comprehensive Surgical Safety Checklist (AORN / WHO Protocol)
                  </h2>
                  <span className="text-[10px] text-stone-500 font-medium">Vityls ASC · Page 3</span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* Stage 1: Pre-Procedure Check-In */}
                  <div className="p-4 bg-stone-50 border border-stone-300 rounded-xl space-y-2">
                    <h3 className="font-bold text-xs text-stone-900 uppercase border-b border-stone-200 pb-1 flex items-center justify-between">
                      <span>1. Pre-Procedure Check-In (Admissions)</span>
                      <input type="text" placeholder="Time" className="p-1 bg-white border border-stone-300 rounded text-[10px] w-16" />
                    </h3>
                    <div className="space-y-1.5 text-stone-800 font-medium text-[11px]">
                      <label className="flex items-center gap-2 cursor-pointer"><input type="checkbox" className="rounded text-indigo-600 focus:ring-0" /><span>Patient Identity, Consent & Site Confirmed</span></label>
                      <label className="flex items-center gap-2 cursor-pointer"><input type="checkbox" className="rounded text-indigo-600 focus:ring-0" /><span>Surgical Site Marked by Surgeon</span></label>
                      <label className="flex items-center gap-2 cursor-pointer"><input type="checkbox" className="rounded text-indigo-600 focus:ring-0" /><span>Pulse Oximeter Attached & Functioning</span></label>
                      <label className="flex items-center gap-2 cursor-pointer"><input type="checkbox" className="rounded text-indigo-600 focus:ring-0" /><span>Airway / Aspiration Risk Assessed</span></label>
                    </div>
                  </div>

                  {/* Stage 2: Sign-In Before Induction */}
                  <div className="p-4 bg-stone-50 border border-stone-300 rounded-xl space-y-2">
                    <h3 className="font-bold text-xs text-stone-900 uppercase border-b border-stone-200 pb-1 flex items-center justify-between">
                      <span>2. Sign-In (Before Induction of Anesthesia)</span>
                      <input type="text" placeholder="Time" className="p-1 bg-white border border-stone-300 rounded text-[10px] w-16" />
                    </h3>
                    <div className="space-y-1.5 text-stone-800 font-medium text-[11px]">
                      <label className="flex items-center gap-2 cursor-pointer"><input type="checkbox" className="rounded text-indigo-600 focus:ring-0" /><span>Anesthesia Safety Check Completed</span></label>
                      <label className="flex items-center gap-2 cursor-pointer"><input type="checkbox" className="rounded text-indigo-600 focus:ring-0" /><span>Known Allergy Check Completed</span></label>
                      <label className="flex items-center gap-2 cursor-pointer"><input type="checkbox" className="rounded text-indigo-600 focus:ring-0" /><span>Difficult Airway / Equipment Available</span></label>
                      <label className="flex items-center gap-2 cursor-pointer"><input type="checkbox" className="rounded text-indigo-600 focus:ring-0" /><span>Risk of &gt; 500ml Blood Loss Evaluated</span></label>
                    </div>
                  </div>

                  {/* Stage 3: Time-Out Before Skin Incision */}
                  <div className="p-4 bg-stone-50 border border-stone-300 rounded-xl space-y-2">
                    <h3 className="font-bold text-xs text-stone-900 uppercase border-b border-stone-200 pb-1 flex items-center justify-between">
                      <span>3. Surgical Time-Out (Before Skin Incision)</span>
                      <input type="text" placeholder="Time" className="p-1 bg-white border border-stone-300 rounded text-[10px] w-16" />
                    </h3>
                    <div className="space-y-1.5 text-stone-800 font-medium text-[11px]">
                      <label className="flex items-center gap-2 cursor-pointer"><input type="checkbox" className="rounded text-indigo-600 focus:ring-0" /><span>All Team Members Introduced by Name & Role</span></label>
                      <label className="flex items-center gap-2 cursor-pointer"><input type="checkbox" className="rounded text-indigo-600 focus:ring-0" /><span>Surgeon, Anesthetist & RN Verbal Confirmation</span></label>
                      <label className="flex items-center gap-2 cursor-pointer"><input type="checkbox" className="rounded text-indigo-600 focus:ring-0" /><span>Antibiotic Prophylaxis Administered</span></label>
                      <label className="flex items-center gap-2 cursor-pointer"><input type="checkbox" className="rounded text-indigo-600 focus:ring-0" /><span>Essential Imaging Displayed</span></label>
                    </div>
                  </div>

                  {/* Stage 4: Sign-Out Before Leaving OR */}
                  <div className="p-4 bg-stone-50 border border-stone-300 rounded-xl space-y-2">
                    <h3 className="font-bold text-xs text-stone-900 uppercase border-b border-stone-200 pb-1 flex items-center justify-between">
                      <span>4. Sign-Out (Before Patient Leaves OR)</span>
                      <input type="text" placeholder="Time" className="p-1 bg-white border border-stone-300 rounded text-[10px] w-16" />
                    </h3>
                    <div className="space-y-1.5 text-stone-800 font-medium text-[11px]">
                      <label className="flex items-center gap-2 cursor-pointer"><input type="checkbox" className="rounded text-indigo-600 focus:ring-0" /><span>Instrument, Sponge & Needle Counts Correct</span></label>
                      <label className="flex items-center gap-2 cursor-pointer"><input type="checkbox" className="rounded text-indigo-600 focus:ring-0" /><span>Specimens Labeled & Confirmed</span></label>
                      <label className="flex items-center gap-2 cursor-pointer"><input type="checkbox" className="rounded text-indigo-600 focus:ring-0" /><span>Equipment Problems Addressed</span></label>
                      <label className="flex items-center gap-2 cursor-pointer"><input type="checkbox" className="rounded text-indigo-600 focus:ring-0" /><span>Key Post-Op Recovery Concerns Reviewed</span></label>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* ------------------------------------------------------------------------------------- */}
            {/* FORM: ASC-RECOVERY-RECORD (PACU / RECOVERY ROOM RECORD & ALDRETE SCORE) */}
            {/* ------------------------------------------------------------------------------------- */}
            {activeTab === 'asc-recovery-record' && (
              <div className="bg-white p-6 rounded-2xl border border-stone-300 shadow-sm space-y-6 text-xs text-stone-900">
                <div className="border-b-2 border-stone-800 pb-2 flex items-center justify-between">
                  <h2 className="text-sm font-bold uppercase tracking-wider text-stone-900">
                    Recovery Room Record (PACU) & Post-Anesthesia Score (Page 8)
                  </h2>
                  <span className="text-[10px] text-stone-500 font-medium">Vityls ASC PACU</span>
                </div>

                {/* Aldrete Scoring Flowsheet Table */}
                <div className="space-y-2">
                  <h3 className="font-bold text-xs text-stone-900 uppercase tracking-wider bg-stone-100 p-2 rounded-lg border border-stone-200">
                    Post-Anesthesia Recovery Scoring (Modified Aldrete Score)
                  </h3>
                  <div className="overflow-x-auto">
                    <table className="w-full text-left border-collapse border border-stone-300 text-[11px]">
                      <thead>
                        <tr className="bg-emerald-900 text-white">
                          <th className="p-2 border border-stone-700">Assessment Parameter</th>
                          <th className="p-2 border border-stone-700">Admission</th>
                          <th className="p-2 border border-stone-700">+30 Min</th>
                          <th className="p-2 border border-stone-700">+60 Min</th>
                          <th className="p-2 border border-stone-700">Discharge</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-stone-200 font-medium">
                        <tr className="hover:bg-stone-50">
                          <td className="p-2 font-bold text-stone-900">Activity (Move extremities)</td>
                          <td className="p-2"><input type="text" placeholder="Score (0-2)" className="w-full p-1 bg-white border border-stone-300 rounded text-xs" /></td>
                          <td className="p-2"><input type="text" placeholder="Score (0-2)" className="w-full p-1 bg-white border border-stone-300 rounded text-xs" /></td>
                          <td className="p-2"><input type="text" placeholder="Score (0-2)" className="w-full p-1 bg-white border border-stone-300 rounded text-xs" /></td>
                          <td className="p-2"><input type="text" placeholder="Score (0-2)" className="w-full p-1 bg-white border border-stone-300 rounded text-xs" /></td>
                        </tr>
                        <tr className="hover:bg-stone-50">
                          <td className="p-2 font-bold text-stone-900">Respiration</td>
                          <td className="p-2"><input type="text" placeholder="Score (0-2)" className="w-full p-1 bg-white border border-stone-300 rounded text-xs" /></td>
                          <td className="p-2"><input type="text" placeholder="Score (0-2)" className="w-full p-1 bg-white border border-stone-300 rounded text-xs" /></td>
                          <td className="p-2"><input type="text" placeholder="Score (0-2)" className="w-full p-1 bg-white border border-stone-300 rounded text-xs" /></td>
                          <td className="p-2"><input type="text" placeholder="Score (0-2)" className="w-full p-1 bg-white border border-stone-300 rounded text-xs" /></td>
                        </tr>
                        <tr className="hover:bg-stone-50">
                          <td className="p-2 font-bold text-stone-900">Circulation (BP)</td>
                          <td className="p-2"><input type="text" placeholder="Score (0-2)" className="w-full p-1 bg-white border border-stone-300 rounded text-xs" /></td>
                          <td className="p-2"><input type="text" placeholder="Score (0-2)" className="w-full p-1 bg-white border border-stone-300 rounded text-xs" /></td>
                          <td className="p-2"><input type="text" placeholder="Score (0-2)" className="w-full p-1 bg-white border border-stone-300 rounded text-xs" /></td>
                          <td className="p-2"><input type="text" placeholder="Score (0-2)" className="w-full p-1 bg-white border border-stone-300 rounded text-xs" /></td>
                        </tr>
                        <tr className="hover:bg-stone-50">
                          <td className="p-2 font-bold text-stone-900">Consciousness</td>
                          <td className="p-2"><input type="text" placeholder="Score (0-2)" className="w-full p-1 bg-white border border-stone-300 rounded text-xs" /></td>
                          <td className="p-2"><input type="text" placeholder="Score (0-2)" className="w-full p-1 bg-white border border-stone-300 rounded text-xs" /></td>
                          <td className="p-2"><input type="text" placeholder="Score (0-2)" className="w-full p-1 bg-white border border-stone-300 rounded text-xs" /></td>
                          <td className="p-2"><input type="text" placeholder="Score (0-2)" className="w-full p-1 bg-white border border-stone-300 rounded text-xs" /></td>
                        </tr>
                        <tr className="hover:bg-stone-50">
                          <td className="p-2 font-bold text-stone-900">Color / O2 Sat</td>
                          <td className="p-2"><input type="text" placeholder="Score (0-2)" className="w-full p-1 bg-white border border-stone-300 rounded text-xs" /></td>
                          <td className="p-2"><input type="text" placeholder="Score (0-2)" className="w-full p-1 bg-white border border-stone-300 rounded text-xs" /></td>
                          <td className="p-2"><input type="text" placeholder="Score (0-2)" className="w-full p-1 bg-white border border-stone-300 rounded text-xs" /></td>
                          <td className="p-2"><input type="text" placeholder="Score (0-2)" className="w-full p-1 bg-white border border-stone-300 rounded text-xs" /></td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* PACU Doctor Standing Post-Op Orders */}
                <div className="p-4 bg-stone-50 rounded-xl border border-stone-300 space-y-2">
                  <h3 className="font-bold text-xs text-stone-900 uppercase">PACU Post-Operative Orders & Vitals Log</h3>
                  <textarea placeholder="Record PACU vital signs, medication administration, and post-op recovery notes..." className="w-full p-2 bg-white border border-stone-300 rounded text-xs h-20" />
                </div>
              </div>
            )}

            {/* ------------------------------------------------------------------------------------- */}
            {/* FORM 8: ANESTHESIA QUESTIONNAIRE & CONSENT */}
            {/* ------------------------------------------------------------------------------------- */}
            {activeTab === 'anesthesia-questionnaire' && (
              <div className="bg-white p-6 rounded-2xl border border-stone-300 shadow-sm space-y-6 text-xs text-stone-900">
                <div className="border-b-2 border-stone-800 pb-2 flex items-center justify-between">
                  <h2 className="text-sm font-bold uppercase tracking-wider text-stone-900">
                    Anesthesia Health Questionnaire & Informed Consent
                  </h2>
                  <span className="text-[10px] text-stone-500 font-medium">Pre-Anesthetic Risk Evaluation</span>
                </div>

                <div className="p-4 bg-stone-50 rounded-xl border border-stone-300 space-y-3">
                  <h3 className="font-bold text-xs text-stone-900 uppercase">Patient Pre-Anesthetic Consent</h3>
                  <p className="text-xs text-stone-700 leading-relaxed font-normal">
                    I understand that I will receive IV Sedation / General Anesthesia for my procedure. Risks, benefits, and alternatives have been explained.
                  </p>
                  <div className="pt-2 grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs font-bold">
                    <div>
                      <label className="block text-[10px] text-stone-500 uppercase mb-0.5">Patient Electronic Signature</label>
                      <input type="text" placeholder="Enter patient signature" className="w-full p-2 bg-white border border-stone-300 rounded text-xs font-serif italic" />
                    </div>
                    <div>
                      <label className="block text-[10px] text-stone-500 uppercase mb-0.5">Date Signed</label>
                      <input type="text" placeholder="MM/DD/YYYY" className="w-full p-2 bg-white border border-stone-300 rounded text-xs" />
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* ------------------------------------------------------------------------------------- */}
            {/* FORM 9: ANESTHESIA INTRA-OPERATIVE RECORD */}
            {/* ------------------------------------------------------------------------------------- */}
            {activeTab === 'anesthesia-record' && (
              <div className="bg-white p-6 rounded-2xl border border-stone-300 shadow-sm space-y-6 text-xs text-stone-900">
                <div className="border-b-2 border-stone-800 pb-2 flex items-center justify-between">
                  <h2 className="text-sm font-bold uppercase tracking-wider text-stone-900">
                    Anesthesia Intra-Operative Record & Monitor Flowsheet
                  </h2>
                  <span className="text-[10px] text-stone-500 font-medium">Real-Time Monitor & Medication Grid</span>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse border border-stone-300 text-[11px]">
                    <thead>
                      <tr className="bg-emerald-900 text-white">
                        <th className="p-2 border border-slate-700">Time Interval</th>
                        <th className="p-2 border border-slate-700">O2 / Agents</th>
                        <th className="p-2 border border-slate-700">Medications Administered</th>
                        <th className="p-2 border border-slate-700">BP / HR / SpO2</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-stone-200">
                      <tr className="hover:bg-stone-50">
                        <td className="p-2 font-bold"><input type="text" placeholder="e.g. Induction" className="w-full p-1 bg-white border border-stone-300 rounded text-xs" /></td>
                        <td className="p-2"><input type="text" placeholder="O2 L/min" className="w-full p-1 bg-white border border-stone-300 rounded text-xs" /></td>
                        <td className="p-2"><input type="text" placeholder="Drugs & dosage" className="w-full p-1 bg-white border border-stone-300 rounded text-xs" /></td>
                        <td className="p-2"><input type="text" placeholder="Vitals" className="w-full p-1 bg-white border border-stone-300 rounded text-xs" /></td>
                      </tr>
                      <tr className="hover:bg-stone-50">
                        <td className="p-2 font-bold"><input type="text" placeholder="e.g. Maintenance" className="w-full p-1 bg-white border border-stone-300 rounded text-xs" /></td>
                        <td className="p-2"><input type="text" placeholder="O2 L/min" className="w-full p-1 bg-white border border-stone-300 rounded text-xs" /></td>
                        <td className="p-2"><input type="text" placeholder="Drugs & dosage" className="w-full p-1 bg-white border border-stone-300 rounded text-xs" /></td>
                        <td className="p-2"><input type="text" placeholder="Vitals" className="w-full p-1 bg-white border border-stone-300 rounded text-xs" /></td>
                      </tr>
                      <tr className="hover:bg-stone-50">
                        <td className="p-2 font-bold"><input type="text" placeholder="e.g. Emergence" className="w-full p-1 bg-white border border-stone-300 rounded text-xs" /></td>
                        <td className="p-2"><input type="text" placeholder="O2 L/min" className="w-full p-1 bg-white border border-stone-300 rounded text-xs" /></td>
                        <td className="p-2"><input type="text" placeholder="Drugs & dosage" className="w-full p-1 bg-white border border-stone-300 rounded text-xs" /></td>
                        <td className="p-2"><input type="text" placeholder="Vitals" className="w-full p-1 bg-white border border-stone-300 rounded text-xs" /></td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* Bottom Form Actions Footer */}
            <div className="bg-white p-4 rounded-2xl border border-stone-300 flex flex-wrap items-center justify-between gap-3 shadow-2xs">
              <div className="flex items-center gap-2 text-xs text-stone-600 font-medium">
                <FileText className="w-4 h-4 text-indigo-600" />
                <span>Form status: <strong className={isSaved ? 'text-emerald-700' : 'text-amber-700'}>{isSaved ? 'Saved to Electronic Medical Record' : 'Blank / Incomplete (Ready for Clinical Entry)'}</strong></span>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={handleSave}
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl transition-colors cursor-pointer flex items-center gap-1.5 shadow-xs"
                >
                  <Save className="w-3.5 h-3.5" />
                  <span>Save Electronic Record</span>
                </button>
              </div>
            </div>

          </div>
        </div>

      </div>
  );

  if (isInline) {
    return innerPortal;
  }

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-md flex items-center justify-center p-2 sm:p-4 md:p-6 overflow-hidden animate-in fade-in duration-200">
      {innerPortal}
    </div>
  );
};
