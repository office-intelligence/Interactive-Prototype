import React from 'react';
import { X } from 'lucide-react';

interface Props {
  title: React.ReactNode;
  onClose: () => void;
  sticky?: boolean;
  actionLabel?: string;
}

export const MinimalWorkflowHeader: React.FC<Props> = ({ title, onClose, sticky = true, actionLabel }) => (
  <div className={`${sticky ? 'sticky top-0' : ''} z-[100000] bg-white border-b border-stone-200 px-4 sm:px-5 py-2.5 flex items-center justify-between gap-3`}>
    <div className="min-w-0 text-sm font-black text-stone-900 truncate">{title}</div>
    <button
      type="button"
      onMouseDown={(e) => { e.preventDefault(); e.stopPropagation(); }}
      onClick={(e) => { e.preventDefault(); e.stopPropagation(); onClose(); }}
      aria-label={actionLabel || 'Close'}
      title={actionLabel || 'Close'}
      className={`relative z-[100001] shrink-0 inline-flex items-center justify-center border transition-colors ${
        actionLabel
          ? 'h-8 px-3 border-[#1F6E52] bg-[#1F6E52] text-white hover:bg-[#17553F] text-xs font-black'
          : 'w-8 h-8 border-stone-200 bg-white text-stone-600 hover:bg-stone-100 hover:text-stone-900'
      }`}
    >
      {actionLabel ? actionLabel : <X className="w-4 h-4" />}
    </button>
  </div>
);
