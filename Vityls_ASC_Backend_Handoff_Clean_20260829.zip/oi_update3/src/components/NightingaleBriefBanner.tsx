import React, { useState } from 'react';
import { Sparkles, ArrowRight, ChevronDown, ChevronUp, Info } from 'lucide-react';
import { PatientCase, CommunicationStats } from '../types';
import { CommunicationWidget } from './CommunicationWidget';

interface NightingaleBriefBannerProps {
  cases: PatientCase[];
  onActionClick: () => void;
  onFilterNeedsAttention?: () => void;
  stats?: CommunicationStats;
  onSelectCategory?: (category: string) => void;
}

export const NightingaleBriefBanner: React.FC<NightingaleBriefBannerProps> = ({
  cases,
  onActionClick,
  stats,
  onSelectCategory,
}) => {
  const [isWaitingExpanded, setIsWaitingExpanded] = useState(false);

  const waitingTotal = stats
    ? stats.insuranceApproval + stats.labResults + stats.implantShipment + stats.physicianSignature
    : 0;
  const commTotal = stats
    ? stats.patientMessages + stats.referrals + stats.insuranceQueries + stats.labNotifications
    : 0;
  const combinedTotal = waitingTotal + commTotal;

  return (
    <div className="bg-[#F1F3EC] rounded-xl border border-[#3E8FA6]/50 p-4 sm:p-5 shadow-2xs space-y-4 nightingale-highlight-border">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-[#E1E4DC] pb-3">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-lg bg-[#E7F1F3] border border-[#3E8FA6]/50 text-[#3E8FA6] flex items-center justify-center shadow-2xs">
            <Sparkles className="w-4 h-4 text-[#3E8FA6]" />
          </div>
          <h2 className="text-sm font-bold text-[#1A2E22] font-display tracking-tight flex items-center gap-1.5">
            <span>Nightingale morning brief</span>
            <span className="px-1.5 py-0.2 rounded-full text-[10px] font-bold bg-[#E7F1F3] text-[#1D4E5A] border border-[#3E8FA6]/50 font-mono flex items-center gap-0.5">
              <Info className="w-2.5 h-2.5" />
              AI
            </span>
          </h2>
        </div>
        <span className="text-[11px] font-medium text-[#5B6B60] font-mono">07:00 AM Sync</span>
      </div>

      {/* Backend-ready brief: no fictitious AI-generated clinical content. */}
      <div className="space-y-2 text-xs text-[#1A2E22] font-medium">
        {cases.length === 0 ? (
          <div className="p-3 bg-white border border-[#E1E4DC]">
            No patient or encounter data is loaded. Nightingale will generate the operational brief from the production API.
          </div>
        ) : (
          <div className="p-3 bg-white border border-[#E1E4DC]">
            {cases.length} active encounter{cases.length === 1 ? '' : 's'} loaded. Production Nightingale analysis will be generated from persisted clinical and workflow data.
          </div>
        )}
      </div>

      {/* Waiting For / Communication Center — merged into one collapsed line
          instead of two always-open panels, since it's the same "what needs a
          human" concept this brief is already reporting on. */}
      {stats && (
        <div className="rounded-xl border border-[#E1E4DC] overflow-hidden">
          <button
            type="button"
            onClick={() => setIsWaitingExpanded((v) => !v)}
            className="w-full px-3.5 py-2.5 bg-white hover:bg-[#F1F3EC] flex items-center justify-between gap-2 text-xs font-semibold text-[#1A2E22] transition-colors cursor-pointer"
          >
            <span>{combinedTotal} item{combinedTotal === 1 ? '' : 's'} waiting on you today — insurance ({stats.insuranceApproval}), labs ({stats.labResults}), messages ({stats.patientMessages})</span>
            {isWaitingExpanded ? <ChevronUp className="w-3.5 h-3.5 text-[#5B6B60] shrink-0" /> : <ChevronDown className="w-3.5 h-3.5 text-[#5B6B60] shrink-0" />}
          </button>
          {isWaitingExpanded && (
            <div className="p-3 bg-[#F1F3EC] border-t border-[#E1E4DC]">
              <CommunicationWidget stats={stats} onSelectCategory={onSelectCategory || (() => {})} />
            </div>
          )}
        </div>
      )}
    </div>
  );
};
