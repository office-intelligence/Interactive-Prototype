import React, { useRef, useState, useEffect, useCallback } from 'react';
import { PenTool, RotateCcw, Check } from 'lucide-react';

interface SignaturePadProps {
  label?: string;
  signerName?: string;
  onSave: (dataUrl: string) => void;
  savedSignature?: string | null;
  compact?: boolean;
}

// Freehand signature capture used across intake, nursing, anesthesia, and
// surgeon forms wherever a wet-ink signature would traditionally be required.
// Draws on a canvas (mouse + touch/stylus), and hands back a PNG data URL.
export const SignaturePad: React.FC<SignaturePadProps> = ({
  label = 'Signature',
  signerName,
  onSave,
  savedSignature = null,
  compact = false,
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const drawingRef = useRef(false);
  const lastPointRef = useRef<{ x: number; y: number } | null>(null);
  const [hasStroke, setHasStroke] = useState(false);
  const [isEditing, setIsEditing] = useState(!savedSignature);

  useEffect(() => {
    setIsEditing(!savedSignature);
  }, [savedSignature]);

  const getCanvasPoint = (e: React.MouseEvent | React.TouchEvent) => {
    const canvas = canvasRef.current;
    if (!canvas) return null;
    const rect = canvas.getBoundingClientRect();
    const clientX = 'touches' in e ? e.touches[0]?.clientX : (e as React.MouseEvent).clientX;
    const clientY = 'touches' in e ? e.touches[0]?.clientY : (e as React.MouseEvent).clientY;
    if (clientX === undefined || clientY === undefined) return null;
    return {
      x: (clientX - rect.left) * (canvas.width / rect.width),
      y: (clientY - rect.top) * (canvas.height / rect.height),
    };
  };

  const startStroke = (e: React.MouseEvent | React.TouchEvent) => {
    e.preventDefault();
    const pt = getCanvasPoint(e);
    if (!pt) return;
    drawingRef.current = true;
    lastPointRef.current = pt;
  };

  const drawStroke = (e: React.MouseEvent | React.TouchEvent) => {
    if (!drawingRef.current) return;
    e.preventDefault();
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    const pt = getCanvasPoint(e);
    if (!ctx || !pt || !lastPointRef.current) return;
    ctx.strokeStyle = '#1B4332';
    ctx.lineWidth = 2.25;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.beginPath();
    ctx.moveTo(lastPointRef.current.x, lastPointRef.current.y);
    ctx.lineTo(pt.x, pt.y);
    ctx.stroke();
    lastPointRef.current = pt;
    if (!hasStroke) setHasStroke(true);
  };

  const endStroke = () => {
    drawingRef.current = false;
    lastPointRef.current = null;
  };

  const clearCanvas = useCallback(() => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (canvas && ctx) ctx.clearRect(0, 0, canvas.width, canvas.height);
    setHasStroke(false);
  }, []);

  const handleClear = () => {
    clearCanvas();
  };

  const handleSave = () => {
    const canvas = canvasRef.current;
    if (!canvas || !hasStroke) return;
    onSave(canvas.toDataURL('image/png'));
    setIsEditing(false);
  };

  return (
    <div className={`rounded-xl border ${isEditing ? 'border-[#3E8FA6]/50 bg-[#E7F1F3]/30' : 'border-emerald-200 bg-emerald-50/40'} p-3 space-y-2`}>
      <div className="flex items-center justify-between gap-2">
        <span className="text-[10px] font-bold uppercase tracking-wider text-stone-500 flex items-center gap-1.5">
          <PenTool className="w-3 h-3 text-[#1F6E52]" />
          {label}{signerName ? ` — ${signerName}` : ''}
        </span>
        {!isEditing && savedSignature && (
          <button
            type="button"
            onClick={() => { setIsEditing(true); clearCanvas(); }}
            className="text-[10px] font-bold text-stone-500 hover:text-stone-800 cursor-pointer flex items-center gap-1"
          >
            <RotateCcw className="w-3 h-3" />
            Re-sign
          </button>
        )}
      </div>

      {isEditing ? (
        <>
          <canvas
            ref={canvasRef}
            width={480}
            height={compact ? 100 : 140}
            className="w-full bg-white rounded-lg border border-dashed border-stone-300 cursor-crosshair touch-none"
            style={{ height: compact ? 100 : 140 }}
            onMouseDown={startStroke}
            onMouseMove={drawStroke}
            onMouseUp={endStroke}
            onMouseLeave={endStroke}
            onTouchStart={startStroke}
            onTouchMove={drawStroke}
            onTouchEnd={endStroke}
          />
          <div className="flex items-center justify-between gap-2">
            <span className="text-[10px] text-stone-400 font-medium">Draw signature above with mouse, finger, or stylus</span>
            <div className="flex items-center gap-1.5 shrink-0">
              <button
                type="button"
                onClick={handleClear}
                className="px-2.5 py-1 rounded-lg bg-stone-100 hover:bg-stone-200 text-stone-600 text-[10.5px] font-bold cursor-pointer"
              >
                Clear
              </button>
              <button
                type="button"
                onClick={handleSave}
                disabled={!hasStroke}
                className="px-2.5 py-1 rounded-lg bg-[#1F6E52] hover:bg-[#17553F] disabled:opacity-40 disabled:cursor-not-allowed text-white text-[10.5px] font-bold cursor-pointer flex items-center gap-1"
              >
                <Check className="w-3 h-3" />
                Save Signature
              </button>
            </div>
          </div>
        </>
      ) : (
        savedSignature && (
          <div className="bg-white rounded-lg border border-emerald-200 p-2 flex items-center justify-between gap-2">
            <img src={savedSignature} alt="Captured signature" className="h-12 object-contain" />
            <span className="text-[10px] font-bold text-emerald-700 flex items-center gap-1 shrink-0">
              <Check className="w-3.5 h-3.5" />
              Signed
            </span>
          </div>
        )
      )}
    </div>
  );
};
