import React, { useEffect, useState } from 'react';
import { Loader2 } from 'lucide-react';
import { PdfFormViewer } from './PdfFormViewer';
import type { LocalPdfTemplate } from '../utils/localFormStudioDb';

interface Props {
  patientId: string;
  patientName: string;
  template: LocalPdfTemplate;
  onClose: () => void;
}

/**
 * Adapter between Form Studio's IndexedDB PDF template blobs and the original
 * interactive PdfFormViewer engine. The underlying viewer provides:
 * - AcroForm field entry where PDF fields exist
 * - freehand pen annotation
 * - text annotation
 * - eraser
 * - automatic editable-draft persistence
 * - a single Done action that saves and closes
 *
 * Draft state is persisted by pdfFormEngine using patientId + template id and
 * remains editable when the same patient document is reopened.
 */
export const PdfTemplateInteractiveViewer: React.FC<Props> = ({
  patientId, patientName, template, onClose
}) => {
  const [bytes,setBytes]=useState<ArrayBuffer|null>(null);
  const [error,setError]=useState<string|null>(null);

  useEffect(()=>{
    let cancelled=false;
    setBytes(null);
    setError(null);
    template.blob.arrayBuffer()
      .then(buf=>{if(!cancelled)setBytes(buf);})
      .catch(err=>{if(!cancelled)setError(err instanceof Error?err.message:'Unable to load PDF template');});
    return()=>{cancelled=true;};
  },[template.id,template.updatedAt]);

  if(error){
    return <div className="fixed inset-0 z-[101000] bg-slate-950/75 flex items-center justify-center p-4"><div className="max-w-lg w-full bg-white rounded-2xl p-6"><div className="text-sm font-black text-rose-700">PDF could not be opened</div><div className="text-xs text-stone-600 mt-2">{error}</div><button onClick={onClose} className="mt-4 px-4 py-2 rounded-xl bg-slate-900 text-white text-xs font-bold">Close</button></div></div>;
  }

  if(!bytes){
    return <div className="fixed inset-0 z-[101000] bg-slate-950/75 flex items-center justify-center"><div className="bg-white rounded-2xl px-5 py-4 flex items-center gap-3 text-sm font-bold text-stone-700"><Loader2 className="w-5 h-5 animate-spin text-emerald-700"/>Loading interactive PDF…</div></div>;
  }

  return (
    <PdfFormViewer
      patientId={patientId}
      documentId={`practice-pdf:${template.id}:${template.version}`}
      title={`${template.title} · ${template.version}`}
      pdfUrl=""
      pdfBytesOverride={bytes}
      signerName={patientName}
      onClose={()=>{
        window.dispatchEvent(new CustomEvent('oi-pdf-form-updated',{
          detail:{patientId,templateId:template.id}
        }));
        onClose();
      }}
    />
  );
};
