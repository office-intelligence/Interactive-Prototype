import React, { useState } from 'react';
import { 
  Sparkles, 
  Zap, 
  ShieldCheck, 
  AlertTriangle, 
  CheckCircle2, 
  Stethoscope, 
  FileText, 
  Mic, 
  Activity, 
  DollarSign, 
  Clock, 
  RefreshCw, 
  FileCheck, 
  Check, 
  Lock, 
  ArrowRight,
  ChevronDown,
  Layers,
  Database
} from 'lucide-react';
import { PatientCase } from '../types';

interface AIPatientChartOverviewProps {
  patient: PatientCase;
  onTriggerEKGFastTrack?: (caseId: string) => void;
  onShowToast?: (msg: string) => void;
  onUpdateAiSummary?: (newSummary: string) => void;
}

export const AIPatientChartOverview: React.FC<AIPatientChartOverviewProps> = ({
  patient,
  onTriggerEKGFastTrack,
  onShowToast,
  onUpdateAiSummary
}) => {
  const [activeToolTab, setActiveToolTab] = useState<'ANESTHESIA' | 'DICTATION' | 'SAFETY' | 'FINANCIAL'>('ANESTHESIA');
  const [dictationText, setDictationText] = useState('');
  const [isDictating, setIsDictating] = useState(false);
  const [generatedNote, setGeneratedNote] = useState<string | null>(null);
  const [isGeneratingNote, setIsGeneratingNote] = useState(false);

  const isCleared = patient.readinessLevel === 'CLEARED';

  const handleSimulateDictation = () => {
    setIsDictating(true);
    if (onShowToast) onShowToast('Listening to clinician ambient dictation...');

    setTimeout(() => {
      setDictationText(
        `Patient ${patient.name}, age ${patient.age}, undergoing ${patient.procedure} with Dr. ${patient.surgeon}. Pre-op vitals stable. Airway Mallampati Class I. No cardiac contraindications. Patient consented and cleared for OR.`
      );
      setIsDictating(false);
      if (onShowToast) onShowToast('Captured 22-second voice dictation snippet.');
    }, 1800);
  };

  const handleGenerateAINote = () => {
    setIsGeneratingNote(true);
    if (onShowToast) onShowToast('Nightingale AI structuring H&P / Operative note with ICD-10 codes...');

    setTimeout(() => {
      setIsGeneratingNote(false);
      const note = `PATIENT CLINICAL SUMMARY & PRE-OP EVALUATION
Patient Name: ${patient.name} | DOB/Age: ${patient.age} y.o. | Gender: ${patient.gender}
Surgical Procedure: ${patient.procedure}
Attending Surgeon: ${patient.surgeon} | Room: ${patient.room}

CLINICAL IMPRESSION & RISK MATRIX:
- Airway: Mallampati Class I (Predictive easy intubation)
- Cardiac: EKG ${isCleared ? 'Normal Sinus Rhythm' : 'Pending Clearance'}
- Allergies: ${patient.allergies.join(', ')}
- VTE Caprini Score: 2 (Low Risk - Early ambulation recommended)
- Fasting Status: NPO since 00:00 (12+ hours)

RECOMMENDED EMR ORDERS:
1. Pre-op Cefazolin 2g IV within 60 mins of incision.
2. Sequential Compression Devices (SCDs) bilaterally in pre-op.
3. Discharge instruction bundle for peri-orbital surgical care.

ICD-10 Diagnostic Tag: Z01.818 (Encounter for pre-procedural examination)
CPT Primary Code: 15823 (Blepharoplasty / Reconstructive Peri-Orbital)`;

      setGeneratedNote(note);
      if (onShowToast) onShowToast('✨ Generated structured clinical note ready for 1-click EMR sign-off.');
    }, 2200);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      
      {/* Top Patient AI Header Card */}
      <div className="p-6 bg-[#14432E] rounded-2xl text-white shadow-xl border border-[#D9A448] flex flex-col md:flex-row md:items-center justify-between gap-6 relative overflow-hidden">
        <div className="space-y-2 max-w-2xl z-10">
          <div className="flex items-center gap-2">
            <span className="px-3 py-1 rounded-full bg-[#2F9E6E] text-[#E4F3EA] border border-[#1B4332] text-xs font-bold flex items-center gap-1.5 font-display">
              <Sparkles className="w-3.5 h-3.5 text-[#E4F3EA]" />
              <span>Nightingale AI Chart Intelligence</span>
            </span>
            <span
              className={`text-xs font-bold px-2.5 py-0.5 rounded-full border font-mono ${
                isCleared
                  ? 'bg-[#E4F3EA] text-[#1B4332] border-[#E1E4DC]'
                  : 'bg-[#FBEEDB] text-[#7A4E17] border-[#E1E4DC]'
              }`}
            >
              {isCleared ? 'READINESS CLEARED' : 'PRE-OP HOLD ACTIVE'}
            </span>
          </div>

          <h2 className="text-2xl font-bold text-white tracking-tight font-display">
            {patient.name} ({patient.age}y {patient.gender}) · ID #{patient.patientId}
          </h2>

          <p className="text-xs text-[#E1E4DC] font-medium leading-relaxed">
            <span className="font-bold text-[#FBEEDB] font-display">AI Clinical Summary: </span>
            {patient.aiSummary}
          </p>
        </div>

        <div className="flex flex-col items-end gap-3 z-10 shrink-0">
          <div className="flex items-center gap-3 bg-[#14432E] p-3 rounded-xl border border-[#D9A448]">
            <div className="text-right">
              <span className="text-[10px] font-bold text-[#E1E4DC] block uppercase font-mono">AI Readiness Index</span>
              <span className={`text-2xl font-bold font-display ${isCleared ? 'text-[#E4F3EA]' : 'text-[#FBEEDB]'}`}>
                {patient.readinessScore}%
              </span>
            </div>
            <div
              className={`w-12 h-12 rounded-xl flex items-center justify-center font-bold text-sm ${
                isCleared ? 'bg-[#2F9E6E] text-[#E4F3EA] border border-[#1B4332]' : 'bg-[#FBEEDB] text-[#7A4E17] border border-[#E1E4DC]'
              }`}
            >
              <ShieldCheck className="w-6 h-6" />
            </div>
          </div>

          {!isCleared && onTriggerEKGFastTrack && (
            <button
              onClick={() => onTriggerEKGFastTrack(patient.id)}
              className="px-4 py-2 bg-[#2F9E6E] hover:bg-[#1B4332] text-white font-bold text-xs rounded-lg shadow-md transition-all flex items-center gap-1.5 cursor-pointer font-sans"
            >
              <Zap className="w-4 h-4 fill-white" />
              <span>Fast-Track Clear EKG Report</span>
            </button>
          )}
        </div>
      </div>

      {/* AI Tool Sub-Tabs Navigation */}
      <div className="flex flex-wrap items-center gap-2 border-b border-[#E1E4DC] pb-2">
        <button
          onClick={() => setActiveToolTab('ANESTHESIA')}
          className={`px-4 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-2 cursor-pointer font-sans ${
            activeToolTab === 'ANESTHESIA'
              ? 'bg-[#2F9E6E] text-white shadow-xs'
              : 'bg-white text-[#5B6B60] hover:bg-[#F1F3EC] border border-[#E1E4DC]'
          }`}
        >
          <Stethoscope className="w-4 h-4" />
          <span>Anesthesia Risk Screening</span>
        </button>

        <button
          onClick={() => setActiveToolTab('DICTATION')}
          className={`px-4 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-2 cursor-pointer font-sans ${
            activeToolTab === 'DICTATION'
              ? 'bg-[#2F9E6E] text-white shadow-xs'
              : 'bg-white text-[#5B6B60] hover:bg-[#F1F3EC] border border-[#E1E4DC]'
          }`}
        >
          <Mic className="w-4 h-4" />
          <span>Ambient Voice Scribe & Note Builder</span>
        </button>

        <button
          onClick={() => setActiveToolTab('SAFETY')}
          className={`px-4 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-2 cursor-pointer font-sans ${
            activeToolTab === 'SAFETY'
              ? 'bg-[#2F9E6E] text-white shadow-xs'
              : 'bg-white text-[#5B6B60] hover:bg-[#F1F3EC] border border-[#E1E4DC]'
          }`}
        >
          <ShieldCheck className="w-4 h-4" />
          <span>Pre-Op Safety Shield</span>
        </button>

        <button
          onClick={() => setActiveToolTab('FINANCIAL')}
          className={`px-4 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-2 cursor-pointer font-sans ${
            activeToolTab === 'FINANCIAL'
              ? 'bg-[#2F9E6E] text-white shadow-xs'
              : 'bg-white text-[#5B6B60] hover:bg-[#F1F3EC] border border-[#E1E4DC]'
          }`}
        >
          <DollarSign className="w-4 h-4" />
          <span>Financial & Prior Auth Check</span>
        </button>
      </div>

      {/* TOOL 1: ANESTHESIA RISK SCREENING */}
      {activeToolTab === 'ANESTHESIA' && (
        <div className="bg-white rounded-2xl p-6 border border-[#E1E4DC] shadow-2xs space-y-5">
          <div className="flex items-center justify-between border-b border-[#E1E4DC] pb-3">
            <div>
              <h3 className="text-sm font-bold text-[#14432E] flex items-center gap-2 font-display">
                <Stethoscope className="w-4 h-4 text-[#2F9E6E]" />
                <span>Automated Pre-Op Anesthesia Risk Profile</span>
              </h3>
              <p className="text-xs text-[#5B6B60]">Cross-analyzed with AORN and ASA physical status guidelines</p>
            </div>
            <span className="px-2.5 py-1 bg-[#E4F3EA] text-[#1B4332] font-bold text-xs rounded-full border border-[#E1E4DC] font-mono">
              ASA Class II (Low Complexity)
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="p-4 bg-[#F1F3EC] rounded-xl border border-[#E1E4DC] space-y-1">
              <span className="text-[11px] font-semibold text-[#5B6B60] block">Airway Assessment</span>
              <span className="text-sm font-bold text-[#14432E] block font-display">Mallampati Class I</span>
              <span className="text-[10px] text-[#1B4332] font-bold block font-mono">✓ Full uvula visibility</span>
            </div>

            <div className="p-4 bg-[#F1F3EC] rounded-xl border border-[#E1E4DC] space-y-1">
              <span className="text-[11px] font-semibold text-[#5B6B60] block">VTE Prophylaxis</span>
              <span className="text-sm font-bold text-[#14432E] block font-display">Caprini Score: 2</span>
              <span className="text-[10px] text-[#2F9E6E] font-bold block font-mono">✓ Early ambulation order</span>
            </div>

            <div className="p-4 bg-[#F1F3EC] rounded-xl border border-[#E1E4DC] space-y-1">
              <span className="text-[11px] font-semibold text-[#5B6B60] block">Allergy Cross-Check</span>
              <span className="text-sm font-bold text-[#14432E] block font-display">
                {patient.allergies.join(', ') || 'NKDA'}
              </span>
              <span className="text-[10px] text-[#1B4332] font-bold block font-mono">✓ Ancef & Propofol safe</span>
            </div>

            <div className="p-4 bg-[#F1F3EC] rounded-xl border border-[#E1E4DC] space-y-1">
              <span className="text-[11px] font-semibold text-[#5B6B60] block">Cardiac Clearance</span>
              <span className="text-sm font-bold text-[#14432E] block font-display">
                {isCleared ? 'Cleared (Normal Sinus)' : 'Pending EKG Fax'}
              </span>
              <span className={`text-[10px] font-bold block font-mono ${isCleared ? 'text-[#1B4332]' : 'text-[#7A4E17]'}`}>
                {isCleared ? '✓ QTc 418ms normal' : '⚠ Action required'}
              </span>
            </div>
          </div>
        </div>
      )}

      {/* TOOL 2: AMBIENT VOICE SCRIBE */}
      {activeToolTab === 'DICTATION' && (
        <div className="bg-white rounded-2xl p-6 border border-[#E1E4DC] shadow-2xs space-y-5">
          <div className="flex items-center justify-between border-b border-[#E1E4DC] pb-3">
            <div>
              <h3 className="text-sm font-bold text-[#14432E] flex items-center gap-2 font-display">
                <Mic className="w-4 h-4 text-[#2F9E6E]" />
                <span>Ambient Clinical Voice Dictation & Note Builder</span>
              </h3>
              <p className="text-xs text-[#5B6B60]">Record spoken notes and auto-format into structured EMR documentation</p>
            </div>
          </div>

          <div className="space-y-4">
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
              <button
                onClick={handleSimulateDictation}
                disabled={isDictating}
                className="px-4 py-2.5 bg-[#2F9E6E] hover:bg-[#1B4332] text-white font-bold text-xs rounded-lg shadow-xs transition-all flex items-center justify-center gap-2 cursor-pointer font-sans"
              >
                <Mic className={`w-4 h-4 ${isDictating ? 'animate-pulse text-[#FBEEDB]' : ''}`} />
                <span>{isDictating ? 'Listening...' : 'Simulate 20-Sec Dictation'}</span>
              </button>

              <button
                onClick={handleGenerateAINote}
                disabled={isGeneratingNote || !dictationText}
                className={`px-4 py-2.5 font-bold text-xs rounded-lg transition-all flex items-center justify-center gap-2 cursor-pointer font-sans ${
                  dictationText
                    ? 'bg-[#14432E] hover:bg-[#14432E] text-white shadow-xs'
                    : 'bg-[#F1F3EC] text-[#5B6B60] cursor-not-allowed'
                }`}
              >
                <Sparkles className="w-4 h-4 text-[#FBEEDB]" />
                <span>Generate Structured Note</span>
              </button>
            </div>

            {dictationText && (
              <div className="p-4 bg-[#F1F3EC] rounded-xl border border-[#E1E4DC] space-y-1">
                <span className="text-[11px] font-bold text-[#5B6B60] uppercase block font-mono">Captured Audio Transcript</span>
                <p className="text-xs text-[#14432E] font-mono leading-relaxed">{dictationText}</p>
              </div>
            )}

            {generatedNote && (
              <div className="p-4 bg-[#14432E] text-white rounded-xl border border-[#5B6B60] space-y-2">
                <div className="flex items-center justify-between border-b border-[#5B6B60] pb-2">
                  <span className="text-xs font-bold text-[#E4F3EA] flex items-center gap-1.5 font-display">
                    <FileCheck className="w-4 h-4 text-[#1B4332]" />
                    <span>Nightingale AI Generated Note (H&P)</span>
                  </span>
                  <span className="text-[10px] bg-[#E4F3EA] text-[#1B4332] border border-[#E1E4DC] px-2 py-0.5 rounded font-bold font-mono">
                    Ready for Sign-Off
                  </span>
                </div>
                <pre className="text-xs font-mono whitespace-pre-wrap text-[#E1E4DC] leading-relaxed overflow-x-auto">
                  {generatedNote}
                </pre>
              </div>
            )}
          </div>
        </div>
      )}

      {/* TOOL 3: PRE-OP SAFETY SHIELD */}
      {activeToolTab === 'SAFETY' && (
        <div className="bg-white rounded-2xl p-6 border border-[#E1E4DC] shadow-2xs space-y-4">
          <h3 className="text-sm font-bold text-[#14432E] flex items-center gap-2 font-display">
            <ShieldCheck className="w-4 h-4 text-[#1B4332]" />
            <span>Pre-Operative Safety & Infection Control Checklist</span>
          </h3>

          <div className="space-y-2">
            {patient.actionItems.map((action) => (
              <div
                key={action.id}
                className={`p-3 rounded-xl border text-xs flex items-center justify-between gap-3 ${
                  action.done ? 'bg-[#E4F3EA] border-[#E1E4DC] text-[#1B4332]' : 'bg-[#F1F3EC] border-[#E1E4DC] text-[#14432E]'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <div
                    className={`w-5 h-5 rounded-md flex items-center justify-center text-xs ${
                      action.done ? 'bg-[#1B4332] text-white' : 'bg-[#E1E4DC] text-[#5B6B60]'
                    }`}
                  >
                    {action.done && <Check className="w-3.5 h-3.5" />}
                  </div>
                  <span className="font-semibold">{action.text}</span>
                </div>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-white text-[#5B6B60] border border-[#E1E4DC] font-mono">
                  {action.type}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TOOL 4: FINANCIAL & PRIOR AUTH */}
      {activeToolTab === 'FINANCIAL' && (
        <div className="bg-white rounded-2xl p-6 border border-[#E1E4DC] shadow-2xs space-y-4">
          <h3 className="text-sm font-bold text-[#14432E] flex items-center gap-2 font-display">
            <DollarSign className="w-4 h-4 text-[#2F9E6E]" />
            <span>AI Revenue Cycle & Payer Authorization Verification</span>
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="p-4 bg-[#F1F3EC] rounded-xl border border-[#E1E4DC] space-y-1">
              <span className="text-[11px] font-semibold text-[#5B6B60] block">Payer Status</span>
              <span className="text-sm font-bold text-[#14432E] block font-display">Blue Shield PPO</span>
              <span className="text-[10px] font-bold text-[#1B4332] block font-mono">✓ Eligibility Verified</span>
            </div>

            <div className="p-4 bg-[#F1F3EC] rounded-xl border border-[#E1E4DC] space-y-1">
              <span className="text-[11px] font-semibold text-[#5B6B60] block">Prior Authorization</span>
              <span className="text-sm font-bold text-[#1B4332] block font-mono">Auth #AUTH-99201</span>
              <span className="text-[10px] font-bold text-[#5B6B60] block">CPT 15823 Approved</span>
            </div>

            <div className="p-4 bg-[#F1F3EC] rounded-xl border border-[#E1E4DC] space-y-1">
              <span className="text-[11px] font-semibold text-[#5B6B60] block">Estimated Copay / Pre-Pay</span>
              <span className="text-sm font-bold text-[#14432E] block font-mono">$500.00</span>
              <span className="text-[10px] font-bold text-[#1B4332] block font-mono">✓ Paid in Pre-Op</span>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
