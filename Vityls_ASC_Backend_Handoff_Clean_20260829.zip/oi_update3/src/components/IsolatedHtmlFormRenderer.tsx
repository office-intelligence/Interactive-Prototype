import React, { useEffect, useRef } from 'react';

interface Props {
  html: string;
  className?: string;
}

/**
 * Renders legacy/styled clinical HTML without an iframe.
 *
 * Why Shadow DOM:
 * - the form grows to its natural height, so there is no nested iframe scrollbar;
 * - imported form CSS stays isolated and cannot cover/disable the application header;
 * - native inputs, checkboxes, selects and textareas remain directly interactive;
 * - only the application page itself scrolls.
 */
export const IsolatedHtmlFormRenderer: React.FC<Props> = ({ html, className = '' }) => {
  const hostRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const host = hostRef.current;
    if (!host) return;

    const root = host.shadowRoot || host.attachShadow({ mode: 'open' });
    const parser = new DOMParser();
    const doc = parser.parseFromString(html || '<div></div>', 'text/html');

    // Clinical templates are presentation/data-entry content only. Never let
    // embedded legacy code, frames or plugin objects execute in the viewer.
    doc.querySelectorAll('script,iframe,object,embed').forEach((node) => node.remove());
    doc.querySelectorAll<HTMLElement>('*').forEach((node) => {
      [...node.attributes].forEach((attr) => {
        if (/^on/i.test(attr.name)) node.removeAttribute(attr.name);
      });
    });

    // Preserve imported styles while translating document-level selectors to
    // Shadow-DOM equivalents so body/html styling still behaves as expected.
    const rewriteCss = (css: string) =>
      css
        .replace(/\bhtml\b/g, ':host')
        .replace(/\bbody\b/g, '.oi-shadow-body');

    const styleText = Array.from(doc.querySelectorAll('style'))
      .map((style) => rewriteCss(style.textContent || ''))
      .join('\n');

    const bodyClass = doc.body.getAttribute('class') || '';
    const bodyStyle = doc.body.getAttribute('style') || '';

    root.innerHTML = `
      <style>
        :host {
          display:block;
          width:100%;
          max-width:100%;
          box-sizing:border-box;
          contain:content;
        }
        *, *::before, *::after { box-sizing:border-box; }
        .oi-shadow-body {
          display:block;
          width:100%;
          max-width:100%;
          min-height:0 !important;
          height:auto !important;
          margin:0 !important;
          padding:0 !important;
          background:#fff !important;
          overflow:visible !important;
          scrollbar-width:none !important;
          -ms-overflow-style:none !important;
        }
        .oi-shadow-body::-webkit-scrollbar,
        *::-webkit-scrollbar { display:none !important; width:0 !important; height:0 !important; }
        .page {
          width:100% !important;
          max-width:100% !important;
          min-height:0 !important;
          height:auto !important;
          margin:0 auto !important;
          box-shadow:none !important;
          border:none !important;
          overflow:visible !important;
        }
        img,svg,canvas,video { max-width:100%; height:auto; }
        table { max-width:100%; }
        input,textarea,select,button { max-width:100%; }
        ${styleText}
      </style>
      <div class="oi-shadow-body ${bodyClass}" style="${bodyStyle.replace(/"/g, '&quot;')}">
        ${doc.body.innerHTML}
      </div>
    `;

    return () => {
      root.innerHTML = '';
    };
  }, [html]);

  return <div ref={hostRef} className={`w-full min-w-0 ${className}`} />;
};
