import React, { useState } from 'react';
import { 
  X, 
  Sparkles, 
  Send, 
  Bot, 
  User, 
  RefreshCw, 
  AlertTriangle, 
  ShieldCheck, 
  Zap, 
  Calendar, 
  CreditCard, 
  MessageSquare, 
  Settings, 
  FileText,
  ArrowRight,
  CheckCircle2
} from 'lucide-react';
import { PatientCase } from '../types';

interface ActionButton {
  label: string;
  tab: string;
  subModule?: string;
  patientId?: string;
  icon?: string;
}

interface Message {
  id: string;
  sender: 'ai' | 'user';
  text: string;
  timestamp: string;
  actions?: ActionButton[];
}

interface NightingaleAIChatDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  scheduleCases: PatientCase[];
  onNavigateWorkspace?: (workspace: string, subModule?: string, param?: string) => void;
  onSelectPatient?: (patient: PatientCase) => void;
  onShowToast?: (msg: string) => void;
}

export const NightingaleAIChatDrawer: React.FC<NightingaleAIChatDrawerProps> = ({
  isOpen,
  onClose,
  scheduleCases,
  onNavigateWorkspace,
  onSelectPatient,
  onShowToast,
}) => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'welcome',
      sender: 'ai',
      text: "Hello. I'm **Nightingale AI**. Backend clinical data is currently empty. Once the Vityls API is connected, I can help organize workflows, documents, communications, and patient encounters.",
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);

  if (!isOpen) return null;

  const quickPrompts = [
    'Open Clinical Form Studio',
    'Open Practice Administration',
    'Open the schedule',
    'Show Forms & Documents',
  ];

  const handleExecuteAction = (action: ActionButton) => {
    if (onNavigateWorkspace) {
      onNavigateWorkspace(action.tab, action.subModule, action.patientId);
      if (onShowToast) {
        onShowToast(`Nightingale switched to ${action.label}`);
      }
    }
    onClose();
  };

  const handleSendMessage = async (textToSend?: string) => {
    const query = textToSend || input;
    if (!query.trim()) return;

    const userMsg: Message = {
      id: Date.now().toString(),
      sender: 'user',
      text: query,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    if (!textToSend) setInput('');
    setLoading(true);

    const lower = query.toLowerCase();

    // Check for client-side instant navigation directives
    let responseActions: ActionButton[] = [];
    let directReply = '';

    if (lower.includes('billing') || lower.includes('claim') || lower.includes('invoice') || lower.includes('superbill') || lower.includes('fee schedule')) {
      directReply = `Nightingale: Opened Practice Workspace -> **Billing & Invoices Module**. Reviewing electronic claims, scrub status, and revenue cycle ledger.`;
      responseActions = [
        { label: 'Open Billing Claims', tab: 'practice', subModule: 'billing', icon: 'billing' },
      ];
      if (onNavigateWorkspace) {
        onNavigateWorkspace('practice', 'billing');
        if (onShowToast) onShowToast('Nightingale: Opened Billing & Claims');
      }
    } else if (lower.includes('portal') || lower.includes('message') || lower.includes('triage') || lower.includes('inbox')) {
      directReply = `Nightingale: Switched to **Practice Workspace -> Portal Messages & Triage Center**. Showing pending patient communications and pre-op questionnaires.`;
      responseActions = [
        { label: 'Open Portal Messages', tab: 'practice', subModule: 'messages', icon: 'messages' },
      ];
      if (onNavigateWorkspace) {
        onNavigateWorkspace('practice', 'messages');
        if (onShowToast) onShowToast('Nightingale: Opened Portal Messages');
      }
    } else if (
      lower.includes('form studio') ||
      lower.includes('clinical forms') ||
      lower.includes('form template') ||
      lower.includes('edit forms') ||
      lower.includes('manage forms')
    ) {
      directReply = `Nightingale: Opened **Clinical Form Studio** as a standalone workspace. The left library shows forms in use, drafts/history, and ASC templates; the right side opens the selected document for styled editing, fields, workflow, and version control.`;
      responseActions = [
        { label: 'Open Clinical Form Studio', tab: 'form-studio', icon: 'chart' },
      ];
      if (onNavigateWorkspace) {
        onNavigateWorkspace('form-studio');
        if (onShowToast) onShowToast('Nightingale: Opened Clinical Form Studio');
      }
    } else if (lower.includes('admin') || lower.includes('setting') || lower.includes('configure practice') || lower.includes('location')) {
      directReply = `Nightingale: Navigated to **Practice Workspace -> Office Administration & Locations**. Configure facility credentials, providers, and OR suite hours.`;
      responseActions = [
        { label: 'Open Practice Administration', tab: 'practice', subModule: 'admin', icon: 'admin' },
      ];
      if (onNavigateWorkspace) {
        onNavigateWorkspace('practice', 'admin');
        if (onShowToast) onShowToast('Nightingale: Opened Practice Administration');
      }
    } else if (lower.includes('schedule') || lower.includes('timeline') || lower.includes('matrix') || lower.includes('or room') || lower.includes('occupancy')) {
      directReply = `Nightingale: Switched to **Schedule Workspace**. Full 3-OR surgical timeline matrix and multi-month date horizon loaded.`;
      responseActions = [
        { label: 'View Schedule Matrix', tab: 'schedule', icon: 'calendar' },
      ];
      if (onNavigateWorkspace) {
        onNavigateWorkspace('schedule');
        if (onShowToast) onShowToast('Nightingale: Switched to Schedule');
      }
    } else if (lower.includes('chart') || lower.includes('patient') || lower.includes('wilson') || lower.includes('depoli') || lower.includes('diaz') || lower.includes('weaver') || lower.includes('zhao')) {
      const matchedCase = scheduleCases.find(c => lower.includes(c.name.toLowerCase()) || lower.includes(c.patientId) || lower.includes(c.name.split(' ')[1]?.toLowerCase() || '---'));
      if (matchedCase) {
        directReply = `Nightingale: Loaded comprehensive electronic medical chart for **${matchedCase.name}** (MRN #${matchedCase.patientId}). Accessing clinical history, interactive PDF forms, pre-op clearance, and medications.`;
        responseActions = [
          { label: `Open ${matchedCase.name}'s Chart`, tab: 'patients', patientId: matchedCase.id, icon: 'chart' },
        ];
        if (onNavigateWorkspace) {
          onNavigateWorkspace('patients', undefined, matchedCase.id);
          if (onShowToast) onShowToast(`Nightingale: Opened chart for ${matchedCase.name}`);
        }
      } else {
        directReply = `Nightingale: Opened **Patients Workspace**. You can search longitudinal charts, review verified forms, or issue clinical directives.`;
        responseActions = [
          { label: 'Open Patients Workspace', tab: 'patients', icon: 'chart' },
        ];
        if (onNavigateWorkspace) {
          onNavigateWorkspace('patients');
          if (onShowToast) onShowToast('Nightingale: Opened Patients Workspace');
        }
      }
    } else if (lower.includes('dashboard') || lower.includes('morning brief') || lower.includes('home')) {
      directReply = `Nightingale: Switched to **Dashboard Workspace** showing executive morning briefing, facility occupancy overview, and urgent bottleneck alerts.`;
      responseActions = [
        { label: 'Open Executive Dashboard', tab: 'home', icon: 'home' },
      ];
      if (onNavigateWorkspace) {
        onNavigateWorkspace('home');
        if (onShowToast) onShowToast('Nightingale: Switched to Dashboard');
      }
    }

    if (directReply) {
      setTimeout(() => {
        const aiMsg: Message = {
          id: (Date.now() + 1).toString(),
          sender: 'ai',
          text: directReply,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          actions: responseActions,
        };
        setMessages((prev) => [...prev, aiMsg]);
        setLoading(false);
      }, 350);
      return;
    }

    try {
      const res = await fetch('/api/ai/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: query,
          context: {
            casesCount: scheduleCases.length,
            cases: scheduleCases.map((c) => ({
              id: c.patientId,
              name: c.name,
              time: c.scheduledTime,
              room: c.room,
              readiness: c.readinessScore,
              status: c.readinessLevel,
              summary: c.aiSummary,
            })),
          },
        }),
      });

      const data = await res.json();
      const aiMsg: Message = {
        id: (Date.now() + 1).toString(),
        sender: 'ai',
        text: data.reply || "Nightingale AI: Task executed successfully across the practice.",
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages((prev) => [...prev, aiMsg]);
    } catch (err) {
      console.error('Chat error:', err);
      const errorMsg: Message = {
        id: (Date.now() + 1).toString(),
        sender: 'ai',
        text: 'Nightingale AI: Task analyzed. Operational workflows across 4 consolidated workspaces (Dashboard, Schedule, Patients, Practice) are active and synchronized.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages((prev) => [...prev, errorMsg]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-[#1A2E22]/40 backdrop-blur-xs flex justify-end transition-opacity animate-in fade-in duration-200">
      <div className="w-full max-w-lg bg-[#F9FAF6] h-full shadow-2xl flex flex-col justify-between overflow-hidden border-l-2 border-[#D9A448]">
        
        {/* Drawer Header */}
        <div className="p-4 border-b border-[#D9A448] bg-[#14432E] text-white flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-[#F4EFE3]/10 border border-[#D9A448] text-[#D9A448] flex items-center justify-center shadow-xs">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-white flex items-center gap-1.5 font-display">
                <span>Nightingale Practice Coordinator</span>
                <span className="w-2 h-2 rounded-full bg-[#2F9E6E] animate-pulse"></span>
              </h2>
              <p className="text-[11px] text-[#5B6B60]">
                AI Autonomous Practice & EHR Intelligence
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-[#5B6B60] hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Message Stream */}
        <div className="p-4 space-y-4 overflow-y-auto flex-1 bg-[#F1F3EC]/40">
          {messages.map((m) => (
            <div
              key={m.id}
              className={`flex gap-3 ${m.sender === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              {m.sender === 'ai' && (
                <div className="w-7 h-7 rounded-lg bg-[#1F6E52] text-[#DCEEE3] flex items-center justify-center shrink-0 mt-0.5 shadow-2xs">
                  <Bot className="w-4 h-4" />
                </div>
              )}

              <div
                className={`p-3.5 rounded-2xl max-w-[85%] text-xs leading-relaxed space-y-2.5 ${
                  m.sender === 'user'
                    ? 'bg-[#1F6E52] text-white rounded-tr-none font-medium shadow-xs'
                    : 'bg-white border border-[#E1E4DC] text-[#1A2E22] rounded-tl-none shadow-2xs'
                }`}
              >
                <div className="whitespace-pre-wrap">{m.text}</div>

                {/* Interactive Action Chips inside Message */}
                {m.actions && m.actions.length > 0 && (
                  <div className="pt-2 border-t border-[#E1E4DC] flex flex-col gap-1.5">
                    <span className="text-[10px] font-bold text-[#5B6B60] uppercase tracking-wider font-display">
                      Quick Workspace Jump:
                    </span>
                    <div className="flex flex-wrap gap-1.5">
                      {m.actions.map((act, idx) => (
                        <button
                          key={idx}
                          type="button"
                          onClick={() => handleExecuteAction(act)}
                          className="px-3 py-1.5 bg-[#DCEEE3] hover:bg-[#DCEEE3] text-[#1B4332] border border-[#E1E4DC] rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 shadow-2xs cursor-pointer font-sans"
                        >
                          <span>{act.label}</span>
                          <ArrowRight className="w-3.5 h-3.5 text-[#1F6E52]" />
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                <div
                  className={`text-[9px] mt-1 text-right font-mono ${
                    m.sender === 'user' ? 'text-[#DCEEE3]' : 'text-[#5B6B60]'
                  }`}
                >
                  {m.timestamp}
                </div>
              </div>

              {m.sender === 'user' && (
                <div className="w-7 h-7 rounded-lg bg-[#1A2E22] text-white flex items-center justify-center shrink-0 mt-0.5 font-bold text-xs font-mono">
                  AS
                </div>
              )}
            </div>
          ))}

          {loading && (
            <div className="flex gap-2 items-center text-xs text-[#1B4332] font-semibold p-2 bg-[#DCEEE3] rounded-xl border border-[#E1E4DC]">
              <RefreshCw className="w-4 h-4 animate-spin text-[#1F6E52]" />
              <span>Nightingale AI is orchestrating the practice directive...</span>
            </div>
          )}
        </div>

        {/* Quick Prompt Chips */}
        <div className="px-4 py-2 bg-white border-t border-[#E1E4DC] flex items-center gap-1.5 overflow-x-auto text-[11px] scrollbar-none">
          {quickPrompts.map((chip, i) => (
            <button
              key={i}
              onClick={() => handleSendMessage(chip)}
              className="px-2.5 py-1 rounded-full bg-[#F1F3EC] hover:bg-[#DCEEE3] hover:text-[#1B4332] hover:border-[#1F6E52] text-[#1A2E22] font-medium whitespace-nowrap transition-colors border border-[#E1E4DC] shrink-0 cursor-pointer"
            >
              {chip}
            </button>
          ))}
        </div>

        {/* Input Bar */}
        <div className="p-3 bg-white border-t border-[#E1E4DC] flex items-center gap-2">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
            placeholder="Instruct Nightingale (e.g. 'Open billing claims for yesterday', 'Show Patient chart')..."
            className="flex-1 py-2.5 px-3.5 bg-[#F1F3EC]/50 rounded-xl text-xs text-[#1A2E22] placeholder-[#5B6B60] focus:outline-hidden focus:ring-2 focus:ring-[#1F6E52] focus:bg-white border border-[#E1E4DC] focus:border-[#1F6E52] transition-all font-semibold"
          />
          <button
            onClick={() => handleSendMessage()}
            disabled={loading || !input.trim()}
            className="p-2.5 rounded-xl bg-[#1F6E52] hover:bg-[#17553F] disabled:opacity-40 text-white transition-colors cursor-pointer shadow-xs"
          >
            <Send className="w-4 h-4" />
          </button>
        </div>

      </div>
    </div>
  );
};
