import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  Archive, CheckCircle2, ChevronRight, Copy, Eye, FileText, FolderOpen, History,
  Layers, Pencil, Plus, Rocket, Save, Search, Settings2, ShieldCheck, Sparkles,
  Trash2, Type, X, Upload, FileUp, Printer
} from 'lucide-react';
import {
  deletePracticeForm, listPracticeForms, publishPracticeForm, retirePracticeForm, saveDraftForm,
  listPdfTemplates, savePdfTemplate, retirePdfTemplate, activatePdfTemplate, updatePdfTemplateStage, createLocalBlobUrl,
  type FormLifecycleStatus, type LocalFormTemplate, type LocalPdfTemplate,
} from '../utils/localFormStudioDb';
import { type AscDefaultField, type AscDefaultFormTemplate } from '../data/ascDefaultFormLibrary';
import { OFFICIAL_HTML_FORM_LIBRARY } from '../data/officialHtmlFormLibrary';
import { ASC_DEFAULT_FORM_PRESENTATIONS } from '../data/ascDefaultFormPresentations';

type StudioTab = 'document' | 'fields' | 'workflow' | 'history';

interface Props {
  activePracticeId: string;
  practiceName: string;
  onShowToast?: (message: string) => void;
  onBackToAdministration?: () => void;
}

type WorkingForm = {
  id?: string;
  templateId: string;
  title: string;
  version: string;
  status: FormLifecycleStatus | 'Template';
  collectionStage: string;
  reviewStages: string[];
  fields: AscDefaultField[];
  sourceFile?: string;
  sourceTemplate?: string;
  basedOnId?: string;
  presentationHtml?: string;
};

const nextVersion = (v: string) => {
  const parts = v.replace(/^v/i, '').split('.').map(Number);
  return `v${Number.isFinite(parts[0]) ? parts[0] : 1}.${(Number.isFinite(parts[1]) ? parts[1] : 0) + 1}`;
};

const statusClass = (status?: string) =>
  status === 'Active' ? 'bg-emerald-100 text-emerald-800 border-emerald-200' :
  status === 'Draft' ? 'bg-sky-100 text-sky-800 border-sky-200' :
  status === 'Superseded' ? 'bg-stone-100 text-stone-600 border-stone-200' :
  status === 'Retired' ? 'bg-rose-100 text-rose-700 border-rose-200' :
  'bg-violet-100 text-violet-800 border-violet-200';

const toWorkingSaved = (form: LocalFormTemplate): WorkingForm => ({
  id: form.id,
  templateId: form.templateId || `legacy-${form.practiceId}-${form.title.toLowerCase().replace(/[^a-z0-9]+/g,'-')}`,
  title: form.title,
  version: form.version,
  status: form.status || 'Active',
  collectionStage: form.collectionStage,
  reviewStages: form.reviewStages || [],
  fields: (form.fields || []) as AscDefaultField[],
  sourceFile: form.sourceFile,
  sourceTemplate: form.sourceTemplate,
  basedOnId: form.basedOnId,
  presentationHtml: form.presentationHtml || (form.sourceFile ? ASC_DEFAULT_FORM_PRESENTATIONS[form.sourceFile] : undefined),
});

const toWorkingTemplate = (template: AscDefaultFormTemplate): WorkingForm => ({
  templateId: `asc-${template.sourceFile.toLowerCase().replace(/[^a-z0-9]+/g,'-')}`,
  title: template.title,
  version: 'v1.0',
  status: 'Template',
  collectionStage: template.collectionStage,
  reviewStages: [...template.reviewStages],
  fields: template.fields.map(f=>({...f,options:f.options?[...f.options]:undefined})),
  sourceFile: template.sourceFile,
  sourceTemplate: 'Office Intelligence ASC Default Library',
  presentationHtml: ASC_DEFAULT_FORM_PRESENTATIONS[template.sourceFile],
});

const StyledDocumentCanvas: React.FC<{
  html?: string;
  documentKey: string;
  editable: boolean;
  onHtmlChange: (html: string) => void;
}> = ({ html, documentKey, editable, onHtmlChange }) => {
  const ref = useRef<HTMLIFrameElement>(null);
  const [frameSource, setFrameSource] = useState(html || '');
  const [frameHeight, setFrameHeight] = useState(760);
  const latestEditedHtml = useRef(html || '');
  const previousEditable = useRef(editable);

  useEffect(() => {
    setFrameSource(html || '');
    latestEditedHtml.current = html || '';
  }, [documentKey]);

  useEffect(() => {
    const frame = ref.current;
    if (!frame) return;

    let currentDoc: Document | null = null;
    let inputHandler: (() => void) | null = null;
    let resizeObserver: ResizeObserver | null = null;

    const measure = () => {
      const doc = frame.contentDocument;
      if (!doc) return;
      const h = Math.max(
        doc.documentElement?.scrollHeight || 0,
        doc.body?.scrollHeight || 0,
        doc.documentElement?.offsetHeight || 0,
        doc.body?.offsetHeight || 0,
        620
      );
      setFrameHeight(Math.min(Math.max(h + 12, 620), 12000));
    };

    const applyMode = () => {
      const doc = frame.contentDocument;
      if (!doc) return;
      currentDoc = doc;
      doc.designMode = editable ? 'on' : 'off';

      if (doc.documentElement) {
        doc.documentElement.style.overflow = 'hidden';
        doc.documentElement.style.maxWidth = '100%';
      }
      if (doc.body) {
        doc.body.setAttribute('spellcheck', editable ? 'true' : 'false');
        doc.body.style.cursor = editable ? 'text' : '';
        doc.body.style.overflow = 'hidden';
        doc.body.style.maxWidth = '100%';
      }

      // Hide scrollbars inside preserved templates without changing their visible styling.
      if (!doc.getElementById('oi-form-studio-frame-style')) {
        const style = doc.createElement('style');
        style.id = 'oi-form-studio-frame-style';
        style.textContent = `
          html, body { overflow: hidden !important; scrollbar-width: none !important; }
          html::-webkit-scrollbar, body::-webkit-scrollbar, *::-webkit-scrollbar { display:none !important; width:0 !important; height:0 !important; }
          img, table { max-width:100%; }
        `;
        doc.head?.appendChild(style);
      }

      if (editable) {
        inputHandler = () => {
          latestEditedHtml.current = doc.documentElement.outerHTML;
          onHtmlChange(latestEditedHtml.current);
          requestAnimationFrame(measure);
        };
        doc.addEventListener('input', inputHandler);
      }

      if (typeof ResizeObserver !== 'undefined' && doc.body) {
        resizeObserver = new ResizeObserver(() => measure());
        resizeObserver.observe(doc.body);
      }
      requestAnimationFrame(measure);
      setTimeout(measure, 100);
    };

    applyMode();
    frame.addEventListener('load', applyMode);

    if (previousEditable.current && !editable) {
      const doc = frame.contentDocument;
      if (doc) latestEditedHtml.current = doc.documentElement.outerHTML;
      if (latestEditedHtml.current) onHtmlChange(latestEditedHtml.current);
    }
    previousEditable.current = editable;

    return () => {
      frame.removeEventListener('load', applyMode);
      if (currentDoc && inputHandler) currentDoc.removeEventListener('input', inputHandler);
      resizeObserver?.disconnect();
    };
  }, [editable, documentKey]);

  if (!frameSource) {
    return (
      <div className="min-h-[560px] rounded-xl border border-dashed border-stone-300 bg-stone-50 flex items-center justify-center p-8 text-center">
        <div><FileText className="w-8 h-8 text-stone-300 mx-auto mb-2"/><div className="text-xs font-black text-stone-700">No original styled document</div><p className="text-[11px] text-stone-500 mt-1">This form was created directly in Form Studio. Its appearance will use the Office Intelligence form design system.</p></div>
      </div>
    );
  }

  return (
    <iframe
      ref={ref}
      title="Styled document editor"
      srcDoc={frameSource}
      sandbox="allow-same-origin"
      scrolling="no"
      style={{ height: `${frameHeight}px` }}
      className="block w-full bg-white border-0 overflow-hidden"
    />
  );
};

export const FormStudioWorkspacePage: React.FC<Props> = ({
  activePracticeId, practiceName, onShowToast, onBackToAdministration
}) => {
  const [practiceForms,setPracticeForms]=useState<LocalFormTemplate[]>([]);
  const [query,setQuery]=useState('');
  const [librarySection,setLibrarySection]=useState<'in-use'|'drafts'|'history'|'templates'|'pdf'>('in-use');
  const [working,setWorking]=useState<WorkingForm|null>(null);
  const [tab,setTab]=useState<StudioTab>('document');
  const [documentEdit,setDocumentEdit]=useState(false);
  const [pdfTemplates,setPdfTemplates]=useState<LocalPdfTemplate[]>([]);
  const pdfInputRef = useRef<HTMLInputElement>(null);
  const [pdfStage,setPdfStage]=useState('Nursing');


  const refresh = async () => {
    const [forms, pdfs] = await Promise.all([
      listPracticeForms(activePracticeId),
      listPdfTemplates(activePracticeId),
    ]);
    setPracticeForms(forms);
    setPdfTemplates(pdfs);
  };
  useEffect(()=>{ refresh().catch(()=>onShowToast?.('Could not load Form Studio database.')); },[activePracticeId]);

  const activeForms = practiceForms.filter(f=>(f.status || 'Active')==='Active');
  const activePdfTemplates = pdfTemplates.filter(p=>p.status==='Active');
  const drafts = practiceForms.filter(f=>f.status==='Draft');
  const history = practiceForms.filter(f=>f.status==='Superseded' || f.status==='Retired');
  const match = (s:string)=>!query.trim() || s.toLowerCase().includes(query.toLowerCase());
  const visibleTemplates=OFFICIAL_HTML_FORM_LIBRARY.filter(t=>match(`${t.title} ${t.group} ${t.collectionStage}`));
  const visibleSaved=(librarySection==='in-use'?activeForms:librarySection==='drafts'?drafts:history).filter(f=>match(`${f.title} ${f.version} ${f.collectionStage}`));

  useEffect(()=>{
    if (!working) {
      if (activeForms[0]) setWorking(toWorkingSaved(activeForms[0]));
      else if (OFFICIAL_HTML_FORM_LIBRARY[0]) setWorking(toWorkingTemplate(OFFICIAL_HTML_FORM_LIBRARY[0]));
    }
  },[practiceForms.length]);

  const updateField=(id:string,patch:Partial<AscDefaultField>)=>{
    setWorking(w=>w?({...w,fields:w.fields.map(f=>f.id===id?{...f,...patch}:f)}):w);
  };
  const deleteField=(id:string)=>setWorking(w=>w?({...w,fields:w.fields.filter(f=>f.id!==id)}):w);
  const addField=()=>setWorking(w=>w?({...w,fields:[...w.fields,{id:`custom-${Date.now()}`,label:'New field',type:'text',required:false,owner:'Practice-defined',source:'Patient'}]}):w);

  const createDraftFromWorking = async () => {
    if (!working) return;
    const version = working.status==='Active' ? nextVersion(working.version) : working.version;
    const saved=await saveDraftForm({
      id: working.status==='Draft' && working.id ? working.id : '',
      templateId: working.templateId,
      practiceId: activePracticeId,
      title: working.title,
      version,
      profile: 'Multispecialty Core',
      collectionStage: working.collectionStage,
      reviewStages: working.reviewStages,
      fields: working.fields,
      updatedAt:new Date().toISOString(),
      status:'Draft',
      basedOnId: working.status==='Active' ? working.id : working.basedOnId,
      sourceTemplate:working.sourceTemplate,
      sourceFile:working.sourceFile,
      presentationHtml:working.presentationHtml,
      sourceCssPreserved:Boolean(working.presentationHtml),
    });
    setWorking(toWorkingSaved(saved));
    await refresh();
    onShowToast?.(`Draft saved: ${saved.title} ${saved.version}.`);
  };

  const publish = async () => {
    if (!working) return;
    const payload:LocalFormTemplate={
      id:working.status==='Draft' && working.id ? working.id : '',
      templateId:working.templateId,
      practiceId:activePracticeId,
      title:working.title,
      version:working.status==='Active'?nextVersion(working.version):working.version,
      profile:'Multispecialty Core',
      collectionStage:working.collectionStage,
      reviewStages:working.reviewStages,
      fields:working.fields,
      updatedAt:new Date().toISOString(),
      status:'Draft',
      basedOnId:working.status==='Active'?working.id:working.basedOnId,
      sourceTemplate:working.sourceTemplate,
      sourceFile:working.sourceFile,
      presentationHtml:working.presentationHtml,
      sourceCssPreserved:Boolean(working.presentationHtml),
    };
    const published=await publishPracticeForm(payload);
    setWorking(toWorkingSaved(published));
    setLibrarySection('in-use');
    await refresh();
    onShowToast?.(`Published ${published.title} ${published.version}. Previous active version was superseded.`);
  };

  const uploadPdfTemplate = async (file: File) => {
    if (file.type !== 'application/pdf' && !file.name.toLowerCase().endsWith('.pdf')) {
      onShowToast?.('Please choose a PDF file.');
      return;
    }
    const cleanTitle = file.name.replace(/\.pdf$/i,'').replace(/[_-]+/g,' ').replace(/\s+/g,' ').trim();
    const saved = await savePdfTemplate({
      practiceId: activePracticeId,
      title: cleanTitle || 'PDF Form Template',
      collectionStage: pdfStage,
      reviewStages: [],
      category: 'Practice PDF Form',
      fileName: file.name,
      mimeType: file.type || 'application/pdf',
      blob: file,
    });
    await refresh();
    setLibrarySection('pdf');
    onShowToast?.(`Uploaded ${saved.title} ${saved.version}. PDF templates are view/print only. Assign a station, then choose Add to In Use when ready.`);
  };

  const chooseTemplate=(t:AscDefaultFormTemplate)=>{
    setWorking(toWorkingTemplate(t));
    setTab('document');
    setDocumentEdit(false);
  };
  const chooseSaved=(f:LocalFormTemplate)=>{
    setWorking(toWorkingSaved(f));
    setTab('document');
    setDocumentEdit(false);
  };

  return (
    <div className="w-full min-w-0 bg-[#F4F5F1] border border-stone-200 rounded-2xl overflow-hidden shadow-2xs">
      <header className="bg-gradient-to-r from-emerald-50 via-white to-sky-50 text-stone-900 px-4 sm:px-5 lg:px-6 py-4 border-b border-emerald-200 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-emerald-700 text-[10px] font-black uppercase tracking-[0.18em]"><Sparkles className="w-4 h-4"/> Nightingale Form Intelligence</div>
          <div className="flex items-center gap-3 mt-1"><h1 className="text-xl font-black">Clinical Form Studio</h1><span className="text-[10px] px-2 py-1 rounded-full border border-emerald-200 bg-white text-emerald-800">{practiceName}</span></div>
          <p className="text-xs text-stone-600 mt-1">Forms in use, version history, and the Office Intelligence ASC template library in one workspace.</p>
        </div>
        <div className="flex items-center gap-2">
          {onBackToAdministration && <button onClick={onBackToAdministration} className="px-3 py-2 rounded-xl bg-white border border-stone-300 text-stone-700 text-xs font-bold">Administration</button>}
          <button onClick={()=>{setWorking({templateId:`template-${Date.now()}`,title:'Untitled Form',version:'v1.0',status:'Draft',collectionStage:'Home / Patient Portal',reviewStages:['Front Desk'],fields:[]});setTab('fields');}} className="px-3 py-2 rounded-xl bg-emerald-400 text-slate-950 text-xs font-black flex items-center gap-1.5"><Plus className="w-4 h-4"/>New Form</button>
        </div>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-[320px_minmax(0,1fr)] min-h-[calc(100vh-205px)]">
        <aside className="bg-white lg:border-r border-stone-200 lg:h-[calc(100vh-205px)] lg:overflow-y-auto min-w-0">
          <div className="p-3.5 border-b border-stone-200 sticky top-0 bg-white z-10">
            <div className="relative"><Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-stone-400"/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search forms and templates…" className="w-full pl-9 pr-3 py-2.5 rounded-xl border border-stone-300 text-xs"/></div>
            <div className="grid grid-cols-2 gap-1 mt-3">
              {([
                ['in-use',`In Use (${activeForms.length + activePdfTemplates.length})`],
                ['drafts',`Drafts (${drafts.length})`],
                ['history',`History (${history.length})`],
                ['templates',`HTML Templates (${OFFICIAL_HTML_FORM_LIBRARY.length})`],
                ['pdf',`PDF Templates (${pdfTemplates.filter(p=>p.status==='Active').length})`],
              ] as const).map(([id,label])=><button key={id} onClick={()=>setLibrarySection(id)} className={`px-2 py-2 rounded-lg text-[10.5px] font-black border ${librarySection===id?'bg-emerald-700 text-white border-emerald-700':'bg-stone-50 text-stone-600 border-stone-200'}`}>{label}</button>)}
            </div>
          </div>

          <div className="p-3 space-y-2">
            {librarySection==='templates' ? visibleTemplates.map(t=>{
              const selected=working?.status==='Template' && working.sourceFile===t.sourceFile;
              return <button key={t.sourceFile} onClick={()=>chooseTemplate(t)} className={`w-full text-left rounded-xl border p-3 transition-all ${selected?'border-emerald-400 bg-emerald-50':'border-stone-200 bg-white hover:bg-stone-50'}`}>
                <div className="flex items-start justify-between gap-2"><div className="min-w-0"><div className="text-[9px] uppercase tracking-wide font-black text-emerald-700">{t.group}</div><div className="text-xs font-black text-stone-900 mt-1">{t.title}</div></div><Copy className="w-3.5 h-3.5 text-stone-400 shrink-0"/></div>
                <div className="text-[10px] text-stone-500 mt-1">{t.fields.length} fields · {t.signatureZones} signatures</div>
                <div className="text-[9.5px] text-stone-400 mt-1">Original CSS preserved</div>
              </button>
            }) : librarySection==='pdf' ? (
              <div className="space-y-2">
                <div className="rounded-xl border border-dashed border-emerald-300 bg-emerald-50/60 p-3">
                  <div className="text-[10px] font-black text-emerald-900">Upload practice PDF template</div>
                  <p className="text-[9.5px] text-emerald-800 mt-1">PDFs are preserved exactly and are not edited in Form Studio. Upload a new file to create the next version.</p>
                  <select value={pdfStage} onChange={e=>setPdfStage(e.target.value)} className="w-full mt-2 px-2 py-2 rounded-lg border border-emerald-200 bg-white text-[10px]">
                    {['Home / Patient Portal','Front Desk','Nursing','Anesthesia','Surgeon','OR Team','PACU'].map(s=><option key={s}>{s}</option>)}
                  </select>
                  <input ref={pdfInputRef} type="file" accept="application/pdf,.pdf" className="hidden" onChange={e=>{const f=e.target.files?.[0];if(f) uploadPdfTemplate(f);e.currentTarget.value='';}}/>
                  <button onClick={()=>pdfInputRef.current?.click()} className="w-full mt-2 px-3 py-2 rounded-lg bg-emerald-700 text-white text-[10px] font-black flex items-center justify-center gap-1.5"><Upload className="w-3.5 h-3.5"/>Upload PDF Template</button>
                </div>
                {pdfTemplates.map(pdf=><div key={pdf.id} className="rounded-xl border border-stone-200 bg-white p-3">
                  <div className="flex items-start justify-between gap-2"><div><div className="text-xs font-black text-stone-900">{pdf.title}</div><div className="text-[10px] text-stone-500 mt-1">{pdf.version} · {pdf.collectionStage}</div></div><span className={`text-[8.5px] font-black uppercase px-1.5 py-0.5 rounded-full border ${pdf.status==='Active'?'bg-emerald-100 text-emerald-800 border-emerald-200':'bg-stone-100 text-stone-500 border-stone-200'}`}>{pdf.status}</span></div>
                  <div className="mt-2 space-y-2">
                    <select value={pdf.collectionStage} onChange={async e=>{await updatePdfTemplateStage(pdf.id,e.target.value);await refresh();}} className="w-full px-2 py-1.5 rounded-lg border border-stone-200 bg-white text-[10px]">
                      {['Home / Patient Portal','Front Desk','Nursing','Anesthesia','Surgeon','OR Team','PACU'].map(s=><option key={s}>{s}</option>)}
                    </select>
                    <div className="flex gap-2">
                      <button onClick={()=>{const url=createLocalBlobUrl(pdf.blob);if(url) window.open(url,'_blank');}} className="text-[10px] font-bold text-emerald-700 flex items-center gap-1"><Eye className="w-3 h-3"/>Open</button>
                      {pdf.status!=='Active' && <button onClick={async()=>{await activatePdfTemplate(pdf.id,pdf.collectionStage);await refresh();setLibrarySection('in-use');}} className="text-[10px] font-black text-violet-700 flex items-center gap-1"><Plus className="w-3 h-3"/>Add to In Use</button>}
                      {pdf.status==='Active' && <button onClick={async()=>{await retirePdfTemplate(pdf.id);await refresh();}} className="text-[10px] font-bold text-rose-600 flex items-center gap-1"><Archive className="w-3 h-3"/>Retire</button>}
                    </div>
                  </div>
                </div>)}
              </div>
            ) : <>
              {visibleSaved.map(f=>{
                const selected=working?.id===f.id;
                return <button key={f.id} onClick={()=>chooseSaved(f)} className={`w-full text-left rounded-xl border p-3 transition-all ${selected?'border-emerald-400 bg-emerald-50':'border-stone-200 bg-white hover:bg-stone-50'}`}>
                  <div className="flex items-start justify-between gap-2"><div className="text-xs font-black text-stone-900">{f.title}</div><span className={`text-[8.5px] font-black uppercase px-1.5 py-0.5 rounded-full border ${statusClass(f.status||'Active')}`}>{f.status||'Active'}</span></div>
                  <div className="text-[10px] text-stone-500 mt-1">{f.version} · {f.collectionStage}</div>
                  {f.sourceFile && <div className="text-[9.5px] text-stone-400 mt-1 truncate">{f.sourceFile}</div>}
                </button>
              })}
              {librarySection==='in-use' && activePdfTemplates.filter(pdf=>match(`${pdf.title} ${pdf.collectionStage} pdf`)).map(pdf=><div key={pdf.id} className="w-full rounded-xl border border-violet-200 bg-violet-50/50 p-3">
                <div className="flex items-start justify-between gap-2"><div className="text-xs font-black text-stone-900">{pdf.title}</div><span className="text-[8.5px] font-black uppercase px-1.5 py-0.5 rounded-full border bg-violet-100 text-violet-800 border-violet-200">PDF</span></div>
                <div className="text-[10px] text-stone-500 mt-1">{pdf.version} · {pdf.collectionStage}</div>
                <div className="flex gap-2 mt-2"><button onClick={()=>{const u=createLocalBlobUrl(pdf.blob);if(u)window.open(u,'_blank');}} className="text-[10px] font-bold text-violet-700 flex items-center gap-1"><Eye className="w-3 h-3"/>Open</button><button onClick={async()=>{await retirePdfTemplate(pdf.id);await refresh();}} className="text-[10px] font-bold text-rose-600 flex items-center gap-1"><Archive className="w-3 h-3"/>Retire</button></div>
              </div>)}
            </>}
                        {(librarySection==='templates'?visibleTemplates.length:librarySection==='pdf'?pdfTemplates.length:librarySection==='in-use'?(visibleSaved.length+activePdfTemplates.length):visibleSaved.length)===0 && <div className="p-5 text-center text-xs text-stone-500 border border-dashed border-stone-300 rounded-xl">No forms in this section.</div>}
          </div>
        </aside>

        <main className="min-w-0 p-3 sm:p-4 lg:p-5 overflow-hidden">
          {!working ? <div className="h-full min-h-[600px] flex items-center justify-center text-sm text-stone-500">Select a form or template.</div> : <>
            <section className="bg-white rounded-2xl border border-stone-200 shadow-2xs overflow-hidden mb-4">
              <div className="p-4 flex flex-col xl:flex-row xl:items-center justify-between gap-4">
                <div className="min-w-0">
                  <div className="flex items-center gap-2 flex-wrap"><input value={working.title} onChange={e=>setWorking({...working,title:e.target.value})} className="text-lg font-black text-stone-900 bg-transparent border-0 outline-none min-w-[280px] max-w-full"/><span className={`text-[9px] uppercase font-black px-2 py-1 rounded-full border ${statusClass(working.status)}`}>{working.status}</span><span className="text-[10px] text-stone-400">{working.version}</span></div>
                  <div className="text-[10.5px] text-stone-500 mt-1">{working.sourceFile ? `Imported from ${working.sourceFile}` : 'Created in Office Intelligence'}{working.presentationHtml ? ' · Original CSS & layout preserved' : ''}</div>
                </div>
                <div className="flex flex-wrap gap-2">
                  {working.status==='Active' && <button onClick={()=>setWorking({...working,id:undefined,version:nextVersion(working.version),status:'Draft',basedOnId:working.id})} className="px-3 py-2 rounded-xl border border-stone-300 bg-white text-xs font-bold flex items-center gap-1.5"><Pencil className="w-4 h-4"/>Create Revision</button>}
                  <button onClick={createDraftFromWorking} className="px-3 py-2 rounded-xl border border-slate-300 bg-slate-100 text-slate-800 text-xs font-black flex items-center gap-1.5"><Save className="w-4 h-4"/>Save Draft</button>
                  <button onClick={publish} className="px-3 py-2 rounded-xl bg-emerald-700 text-white text-xs font-black flex items-center gap-1.5"><Rocket className="w-4 h-4"/>Publish</button>
                  {working.id && (working.status==='Active'||working.status==='Draft') && <button onClick={async()=>{await retirePracticeForm(working.id!);await refresh();setWorking(null);}} className="px-3 py-2 rounded-xl border border-rose-200 bg-rose-50 text-rose-700 text-xs font-bold"><Archive className="w-4 h-4"/></button>}
                </div>
              </div>
              <div className="px-4 border-t border-stone-200 flex items-center gap-1 overflow-x-auto">
                {([
                  ['document','Styled Document',Type],
                  ['fields',`Fields (${working.fields.length})`,Layers],
                  ['workflow','Workflow & Version',Settings2],
                  ['history','Version History',History],
                ] as const).map(([id,label,Icon])=><button key={id} onClick={()=>setTab(id)} className={`px-3 py-2.5 text-xs font-black flex items-center gap-1.5 border-b-2 whitespace-nowrap ${tab===id?'border-emerald-700 text-emerald-800':'border-transparent text-stone-500'}`}><Icon className="w-3.5 h-3.5"/>{label}</button>)}
              </div>
            </section>

            {tab==='document' && <section className="bg-white rounded-xl border border-stone-200 shadow-2xs overflow-hidden">
              <div className="p-3.5 border-b border-stone-200 flex flex-wrap items-center justify-between gap-3">
                <div><div className="text-sm font-black text-stone-900">Original Styled Document</div><div className="text-[10.5px] text-stone-500 mt-0.5">Static text, CSS, tables and typography are preserved. Scripts and legacy signature canvases are removed.</div></div>
                <button onClick={()=>setDocumentEdit(!documentEdit)} disabled={!working.presentationHtml} className={`px-3 py-2 rounded-xl text-xs font-black flex items-center gap-1.5 ${documentEdit?'bg-emerald-700 text-white':'bg-stone-100 text-stone-700 border border-stone-300'} disabled:opacity-40`}><Pencil className="w-4 h-4"/>{documentEdit?'Editing document':'Edit Document Text'}</button>
              </div>
              <div className="p-0 bg-white">
                {documentEdit && <div className="m-3 mb-0 rounded-xl border border-amber-200 bg-amber-50 px-3 py-2 text-[10.5px] text-amber-900"><strong>Visual edit mode:</strong> click directly into paragraphs, headings, table cells and disclosures. Your edits remain on screen while you type and are preserved in the working draft without reloading the template.</div>}
                <StyledDocumentCanvas
                  documentKey={`${working.templateId}:${working.id || working.sourceFile || working.version}`}
                  html={working.presentationHtml}
                  editable={documentEdit}
                  onHtmlChange={html=>setWorking(w=>w?({...w,presentationHtml:html}):w)}
                />
              </div>
            </section>}

            {tab==='fields' && <section className="bg-white rounded-2xl border border-stone-200 shadow-2xs">
              <div className="p-4 border-b border-stone-200 flex items-center justify-between"><div><div className="text-sm font-black text-stone-900">Interactive Fields</div><div className="text-[10.5px] text-stone-500 mt-0.5">Questions and controls remain structured separately from informational document text.</div></div><button onClick={addField} className="px-3 py-2 rounded-xl bg-emerald-700 text-white text-xs font-black flex items-center gap-1"><Plus className="w-4 h-4"/>Add Field</button></div>
              <div className="divide-y divide-stone-100">
                {working.fields.map((f,index)=><div key={f.id} className="p-3.5 grid grid-cols-1 xl:grid-cols-[36px_minmax(0,1fr)_150px_110px_36px] gap-2 items-center">
                  <div className="text-[10px] font-black text-stone-400">{index+1}</div>
                  <input value={f.label} onChange={e=>updateField(f.id,{label:e.target.value})} className="px-3 py-2 rounded-lg border border-stone-300 text-xs"/>
                  <select value={f.type} onChange={e=>updateField(f.id,{type:e.target.value as any})} className="px-2 py-2 rounded-lg border border-stone-300 text-xs bg-white"><option>text</option><option>textarea</option><option>checkbox</option><option>radio</option><option>select</option><option>date</option><option>signature</option><option>clinical-list</option><option>score</option></select>
                  <label className="flex items-center gap-2 text-[10px] font-bold text-stone-600"><input type="checkbox" checked={f.required} onChange={e=>updateField(f.id,{required:e.target.checked})}/>Required</label>
                  <button onClick={()=>deleteField(f.id)} className="p-2 text-stone-400 hover:text-rose-600"><Trash2 className="w-4 h-4"/></button>
                  {['checkbox','radio','select'].includes(f.type) && <div className="xl:col-start-2 xl:col-span-3 rounded-xl border border-stone-200 bg-stone-50 p-2.5">
                    <div className="flex items-center justify-between gap-2 mb-2"><label className="text-[9px] uppercase font-black text-stone-500">Options</label><button onClick={()=>updateField(f.id,{options:[...(f.options||[]),`Option ${(f.options?.length||0)+1}`]})} className="px-2 py-1 rounded-lg bg-emerald-700 text-white text-[9.5px] font-black flex items-center gap-1"><Plus className="w-3 h-3"/>Add Option</button></div>
                    <div className="space-y-1.5">{(f.options||[]).map((opt,optIndex)=><div key={`${f.id}-opt-${optIndex}`} className="flex items-center gap-2"><span className="w-5 text-[9px] text-stone-400 font-black">{optIndex+1}</span><input value={opt} onChange={e=>{const options=[...(f.options||[])];options[optIndex]=e.target.value;updateField(f.id,{options});}} className="flex-1 px-2.5 py-2 rounded-lg border border-stone-200 bg-white text-[10.5px]"/><button onClick={()=>updateField(f.id,{options:(f.options||[]).filter((_,i)=>i!==optIndex)})} className="p-1.5 text-stone-400 hover:text-rose-600"><Trash2 className="w-3.5 h-3.5"/></button></div>)}</div>
                    {(f.options||[]).length===0 && <div className="text-[10px] text-amber-700">No options yet. Click Add Option.</div>}
                  </div>}
                </div>)}
                {!working.fields.length && <div className="p-8 text-center text-xs text-stone-500">No interactive fields. This can still be a valid informational document with signatures added below.</div>}
              </div>
            </section>}

            {tab==='workflow' && <section className="bg-white rounded-2xl border border-stone-200 shadow-2xs p-5 space-y-5">
              <div><div className="text-sm font-black text-stone-900">Workflow & Publication</div><div className="text-[10.5px] text-stone-500 mt-1">Controls where the document enters the patient journey and who must review it later.</div></div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <label className="space-y-1"><span className="text-xs font-bold text-stone-600">Collect first at</span><select value={working.collectionStage} onChange={e=>setWorking({...working,collectionStage:e.target.value})} className="w-full px-3 py-2.5 rounded-xl border border-stone-300 text-xs bg-white">{['Home / Patient Portal','Front Desk','Nursing','Anesthesia','Surgeon','OR Team','PACU'].map(s=><option key={s}>{s}</option>)}</select></label>
                <label className="space-y-1"><span className="text-xs font-bold text-stone-600">Version</span><input value={working.version} onChange={e=>setWorking({...working,version:e.target.value})} className="w-full px-3 py-2.5 rounded-xl border border-stone-300 text-xs"/></label>
              </div>
              <div><div className="text-xs font-bold text-stone-600 mb-2">Review / verify at later gates</div><div className="flex flex-wrap gap-2">{['Front Desk','Nursing','Anesthesia','Surgeon','OR Team','PACU'].map(s=><button key={s} onClick={()=>setWorking({...working,reviewStages:working.reviewStages.includes(s)?working.reviewStages.filter(x=>x!==s):[...working.reviewStages,s]})} className={`px-3 py-1.5 rounded-lg border text-[10.5px] font-bold ${working.reviewStages.includes(s)?'bg-emerald-700 text-white border-emerald-700':'bg-white text-stone-600 border-stone-300'}`}>{s}</button>)}</div></div>
              <div className="rounded-xl bg-emerald-50 border border-emerald-200 p-3 text-[10.5px] text-emerald-900"><strong>Publication rule:</strong> only Active versions are used for new encounters. Publishing this version supersedes the prior Active version but never changes historical signed records.</div>
            </section>}

            {tab==='history' && <section className="bg-white rounded-2xl border border-stone-200 shadow-2xs p-5">
              <div className="text-sm font-black text-stone-900">Version History</div>
              <div className="mt-4 space-y-2">{practiceForms.filter(f=>(f.templateId||'')===working.templateId || f.title.toLowerCase()===working.title.toLowerCase()).map(f=><button onClick={()=>chooseSaved(f)} key={f.id} className="w-full text-left rounded-xl border border-stone-200 p-3 flex items-center justify-between gap-3"><div><div className="text-xs font-black text-stone-900">{f.version}</div><div className="text-[10px] text-stone-500 mt-0.5">{f.updatedAt}</div></div><span className={`text-[9px] font-black uppercase px-2 py-1 rounded-full border ${statusClass(f.status||'Active')}`}>{f.status||'Active'}</span></button>)}</div>
              {!practiceForms.some(f=>(f.templateId||'')===working.templateId || f.title.toLowerCase()===working.title.toLowerCase()) && <div className="mt-4 p-5 text-center border border-dashed border-stone-300 rounded-xl text-xs text-stone-500">This template has not been saved to the practice yet.</div>}
            </section>}
          </>}
        </main>
      </div>
    </div>
  );
};
