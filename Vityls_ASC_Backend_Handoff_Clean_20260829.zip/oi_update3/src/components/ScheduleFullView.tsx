import React, { useState, useEffect, useRef, useMemo } from 'react';
import { 
  ChevronLeft, 
  ChevronRight, 
  Calendar as CalendarIcon, 
  Printer, 
  BookOpen, 
  Search, 
  ChevronDown, 
  Save, 
  Clock,
  Plus,
  User,
  X,
  CheckCircle2,
  Sparkles,
  Trash2,
  ExternalLink,
  Edit3,
  FileText,
  Phone,
  RotateCcw
} from 'lucide-react';
import { PatientCase, PAYMENT_TYPE_OPTIONS, PracticeConfig } from '../types';
import { 
  searchPatientsByLastName, 
  getPatientAppointmentHistory, 
  PatientAppointmentHistoryRecord, 
  MasterPatientRecord 
} from '../utils/patientDirectory';
import { checkIsFederalHoliday } from '../utils/holidays';
import { SchedulePrintModal } from './SchedulePrintModal';
import { NightingaleScheduleCommandCoordinator } from './NightingaleScheduleCommandCoordinator';
import { SurgicalDayBriefingModal } from './SurgicalDayBriefingModal';
import { BlockTimeModal } from './BlockTimeModal';

export interface AppointmentItem {
  id: string;
  dayIndex: number;
  room: string;
  startHour: number;
  durationHours: number;
  title: string;
  surgeon: string;
  details: string;
  bgColor: string;
  caseId?: string;
  isBlock?: boolean;

  // 13 fields for popup modal
  dos: string;
  startTime: string;
  length: string;
  patientName: string;
  dob: string;
  age: string;
  phone: string;
  procedure: string;
  anesthesiologist: string;
  anesthesiaType: string;
  paymentType?: string;
  notes: string;
}

interface ScheduleFullViewProps {
  cases: PatientCase[];
  onSelectPatient: (patient: PatientCase) => void;
  practiceConfig?: PracticeConfig;
}

const initialAppointments: AppointmentItem[] = [];

export const ScheduleFullView: React.FC<ScheduleFullViewProps> = ({
  cases,
  onSelectPatient,
  practiceConfig,
}) => {
  const [selectedDayIndex, setSelectedDayIndex] = useState<number>(0); // 0 = Monday (Today)
  const [viewMode, setViewMode] = useState<'WK' | 'DAY'>('WK');
  const [selectedSubTab, setSelectedSubTab] = useState('Schedule');
  const [searchTerm, setSearchTerm] = useState('');
  const [isPrintModalOpen, setIsPrintModalOpen] = useState(false);

  // Weekly notes state keyed by the specific schedule week indicated
  const activeWeekKey = 'Week of July 13, 2026';
  const [weeklyNotes, setWeeklyNotes] = useState<{ [week: string]: string }>(() => {
    const saved = localStorage.getItem('schedule_weekly_notes_db');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        // Fallback default
      }
    }
    return {};
  });
  const [noteDraft, setNoteDraft] = useState<string>(weeklyNotes[activeWeekKey] || '');
  const [savedNotesTimestamp, setSavedNotesTimestamp] = useState<string | null>(null);

  // Interactive Appointments State
  const [appointmentsList, setAppointmentsList] = useState<AppointmentItem[]>(initialAppointments);
  const [activeAppointmentModal, setActiveAppointmentModal] = useState<AppointmentItem | null>(null);
  const [deleteConfirmAppointment, setDeleteConfirmAppointment] = useState<AppointmentItem | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [draggedAptId, setDraggedAptId] = useState<string | null>(null);
  const [dragOverTarget, setDragOverTarget] = useState<{ dIdx: number; hour: number; room: string } | null>(null);

  // Dynamic Patient Search State in Appointment Modal
  const [patientSearchQuery, setPatientSearchQuery] = useState('');
  const [showPatientSuggestions, setShowPatientSuggestions] = useState(false);

  // Dedicated Schedule Matrix Patient Search & Appointment Dates State
  const [schedulePatientSearchQuery, setSchedulePatientSearchQuery] = useState('');
  const [isScheduleSearchFocused, setIsScheduleSearchFocused] = useState(false);
  const scheduleSearchContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (scheduleSearchContainerRef.current && !scheduleSearchContainerRef.current.contains(event.target as Node)) {
        setIsScheduleSearchFocused(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleSelectAppointmentDate = (aptRecord: PatientAppointmentHistoryRecord) => {
    const targetDayIndex = aptRecord.dayIndex !== undefined ? aptRecord.dayIndex : 0;
    const aptItem: AppointmentItem = {
      id: aptRecord.id,
      dayIndex: targetDayIndex,
      room: aptRecord.room || 'OR #1',
      startHour: aptRecord.startHour || 8,
      durationHours: aptRecord.durationHours || 2,
      title: aptRecord.title || `${aptRecord.patientName}`,
      surgeon: aptRecord.surgeon || 'Primary Provider',
      details: `[Vityls ASC] ${aptRecord.procedure}`,
      bgColor: aptRecord.bgColor || (aptRecord.status === 'Scheduled' ? 'bg-emerald-700 text-white border-emerald-800' : 'bg-slate-700 text-white border-slate-800'),
      caseId: aptRecord.caseId,
      dos: aptRecord.date,
      startTime: aptRecord.startTime || '08:00 AM',
      length: aptRecord.length || '2.0 Hours',
      patientName: aptRecord.patientName,
      dob: aptRecord.dob,
      age: `${aptRecord.age}`,
      phone: aptRecord.phone,
      procedure: aptRecord.procedure,
      anesthesiologist: aptRecord.anesthesiologist || 'Anesthesia Provider',
      anesthesiaType: aptRecord.anesthesiaType || 'General Anesthesia',
      paymentType: aptRecord.paymentType || 'Self-Pay',
      notes: aptRecord.notes || `Appointment record for ${aptRecord.patientName} on ${aptRecord.date}.`
    };

    if (aptRecord.dayIndex !== undefined) {
      setSelectedDayIndex(aptRecord.dayIndex);
    }
    setActiveAppointmentModal(aptItem);
    setIsScheduleSearchFocused(false);
    showToast(`Loaded appointment details for ${aptRecord.patientName} (${aptRecord.date} • ${aptRecord.startTime})`);
  };

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  // Minimal Clean Workspace & Nightingale AI Schedule Coordinator State
  const [isMinimalMode, setIsMinimalMode] = useState<boolean>(true);
  const [baseDate, setBaseDate] = useState<Date>(new Date(2026, 6, 13)); // Baseline: Monday, July 13, 2026
  const [isBriefingModalOpen, setIsBriefingModalOpen] = useState<boolean>(false);
  const [isBlockTimeModalOpen, setIsBlockTimeModalOpen] = useState<boolean>(false);
  const [filterSurgeon, setFilterSurgeon] = useState<string | null>(null);
  const [filterRoom, setFilterRoom] = useState<string | null>(null);
  const [filterProcedure, setFilterProcedure] = useState<string | null>(null);

  const handleSaveBlocks = (newBlocks: AppointmentItem[]) => {
    setAppointmentsList(prev => [...prev, ...newBlocks]);
    showToast(`Successfully blocked ${newBlocks.length} time slot(s) across selected days and OR suites.`);
  };

  const handleClearFilters = () => {
    setFilterSurgeon(null);
    setFilterRoom(null);
    setFilterProcedure(null);
    showToast('Filters cleared. Showing full operative schedule.');
  };

  const handleResetToToday = () => {
    setBaseDate(new Date(2026, 6, 13));
    setSelectedDayIndex(0);
    showToast('Schedule returned to baseline today (Monday, July 13, 2026).');
  };

  const handleExecuteNightingaleCommand = (cmdText: string): { success: boolean; message: string } => {
    const lower = cmdText.toLowerCase();

    // 0. Add a week note by command, e.g. "note: OR 3 running 20 min behind"
    //    or "add note OR 3 running 20 min behind" — lands in the Week Schedule
    //    Notes panel (read-only log + this input, no tag buttons / Save button).
    const noteMatch = cmdText.match(/^\s*(?:note|add note)\s*:?\s*(.+)$/i);
    if (noteMatch && noteMatch[1].trim()) {
      const noteText = noteMatch[1].trim();
      setNoteDraft((prev) => (prev ? `${prev}\n• ${noteText}` : `• ${noteText}`));
      const updated = { ...weeklyNotes, [activeWeekKey]: (noteDraft ? `${noteDraft}\n• ${noteText}` : `• ${noteText}`) };
      setWeeklyNotes(updated);
      localStorage.setItem('schedule_weekly_notes_db', JSON.stringify(updated));
      setSavedNotesTimestamp(new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }));
      return { success: true, message: `Nightingale: Added to this week's notes — "${noteText}"` };
    }

    // 1. Reset / Clear / Return to today
    if (lower.includes('today') || lower.includes('return to today') || lower.includes('reset date') || lower.includes('baseline')) {
      handleResetToToday();
      return { success: true, message: 'Nightingale: Returned schedule matrix to baseline today (Monday, July 13, 2026).' };
    }

    if (lower.includes('reset') || lower.includes('show all') || lower.includes('clear filter') || lower.includes('unfilter')) {
      handleClearFilters();
      return { success: true, message: 'Nightingale: Cleared all schedule filters and restored full operative view.' };
    }

    // Block Time Directive
    if (lower.includes('block time') || lower.includes('block or') || lower.includes('or block') || lower.includes('reserve block') || lower.includes('hold time') || lower.includes('block schedule')) {
      setIsBlockTimeModalOpen(true);
      return {
        success: true,
        message: 'Nightingale: Opened Block Time reservation modal. Select provider, OR suite, start/end hours, and check off days of the week.'
      };
    }

    // 2. View Mode switching
    if (lower.includes('clean view') || lower.includes('minimal') || lower.includes('focus')) {
      setIsMinimalMode(true);
      return { success: true, message: 'Nightingale: Activated Minimal Clean Workspace mode with maximum timeline visibility.' };
    }
    if (lower.includes('expanded') || lower.includes('show sidebar') || lower.includes('show notes') || lower.includes('classic')) {
      setIsMinimalMode(false);
      return { success: true, message: 'Nightingale: Switched to Expanded Matrix view with week notes and calendar sidebar.' };
    }

    // 3. Date Navigation & Multi-Month / Multi-Year Jumps
    if (lower.includes('+3 month') || lower.includes('3 months ahead') || lower.includes('3 months')) {
      const d = new Date(baseDate);
      d.setMonth(d.getMonth() + 3);
      const day = d.getDay();
      const diff = d.getDate() - day + (day === 0 ? -6 : 1);
      d.setDate(diff);
      setBaseDate(d);
      return { success: true, message: `Nightingale: Advanced schedule horizon 3 months ahead to ${d.toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}.` };
    }

    if (lower.includes('+6 month') || lower.includes('6 months ahead') || lower.includes('half year')) {
      const d = new Date(baseDate);
      d.setMonth(d.getMonth() + 6);
      const day = d.getDay();
      const diff = d.getDate() - day + (day === 0 ? -6 : 1);
      d.setDate(diff);
      setBaseDate(d);
      return { success: true, message: `Nightingale: Advanced schedule horizon 6 months ahead to ${d.toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}.` };
    }

    if (lower.includes('+1 year') || lower.includes('1 year ahead') || lower.includes('next year') || lower.includes('12 months')) {
      const d = new Date(baseDate);
      d.setFullYear(d.getFullYear() + 1);
      const day = d.getDay();
      const diff = d.getDate() - day + (day === 0 ? -6 : 1);
      d.setDate(diff);
      setBaseDate(d);
      return { success: true, message: `Nightingale: Advanced schedule horizon 1 year ahead to ${d.toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}.` };
    }

    if (lower.includes('-6 month') || lower.includes('6 months ago') || lower.includes('back 6 month')) {
      const d = new Date(baseDate);
      d.setMonth(d.getMonth() - 6);
      const day = d.getDay();
      const diff = d.getDate() - day + (day === 0 ? -6 : 1);
      d.setDate(diff);
      setBaseDate(d);
      return { success: true, message: `Nightingale: Jumped schedule back 6 months to ${d.toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}.` };
    }

    if (lower.includes('-1 year') || lower.includes('1 year ago') || lower.includes('back 1 year') || lower.includes('last year')) {
      const d = new Date(baseDate);
      d.setFullYear(d.getFullYear() - 1);
      const day = d.getDay();
      const diff = d.getDate() - day + (day === 0 ? -6 : 1);
      d.setDate(diff);
      setBaseDate(d);
      return { success: true, message: `Nightingale: Jumped schedule back 1 year to ${d.toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}.` };
    }

    // Specific Month and Year Matching (e.g. "March 2027", "October 2026", "November 2028", "January 2025")
    const monthNames = [
      { name: 'january', idx: 0, short: 'jan' },
      { name: 'february', idx: 1, short: 'feb' },
      { name: 'march', idx: 2, short: 'mar' },
      { name: 'april', idx: 3, short: 'apr' },
      { name: 'may', idx: 4, short: 'may' },
      { name: 'june', idx: 5, short: 'jun' },
      { name: 'july', idx: 6, short: 'jul' },
      { name: 'august', idx: 7, short: 'aug' },
      { name: 'september', idx: 8, short: 'sep' },
      { name: 'october', idx: 9, short: 'oct' },
      { name: 'november', idx: 10, short: 'nov' },
      { name: 'december', idx: 11, short: 'dec' },
    ];

    for (const mObj of monthNames) {
      if (lower.includes(mObj.name) || (mObj.short && lower.includes(mObj.short))) {
        const yrMatch = lower.match(/(202[0-9]|203[0-9])/);
        const yr = yrMatch ? parseInt(yrMatch[1], 10) : (mObj.idx < 6 ? 2027 : 2026);
        const d = new Date(yr, mObj.idx, 15);
        const day = d.getDay();
        const diff = d.getDate() - day + (day === 0 ? -6 : 1);
        d.setDate(diff);
        setBaseDate(d);
        return { success: true, message: `Nightingale: Jumped schedule to ${d.toLocaleDateString('en-US', { month: 'long', year: 'numeric' })} (Week of ${d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}).` };
      }
    }

    // 4. Quick Actions: Print & New Appointment
    if (lower.includes('print') || lower.includes('day sheet') || lower.includes('pdf')) {
      setIsPrintModalOpen(true);
      return { success: true, message: 'Nightingale: Opened Operative Day-Sheet print terminal with formatted surgeon, room, and case rosters.' };
    }

    if (lower.includes('new case') || lower.includes('schedule new') || lower.includes('add appointment') || lower.includes('book case') || lower.includes('book appointment')) {
      handleCreateNewAppointment();
      return { success: true, message: 'Nightingale: Launched surgical case scheduling terminal. Ready to assign OR suite, surgeon, and anesthesia.' };
    }

    // 5. Day / Week switching
    if (lower.includes('show day') || lower.includes('day view') || lower.includes('view day')) {
      setViewMode('DAY');
      setSelectedDayIndex(0);
      return { success: true, message: 'Nightingale: Switched to Day View.' };
    }
    if (lower.includes('week view') || lower.includes('show week') || lower.includes('7-day')) {
      setViewMode('WK');
      return { success: true, message: 'Nightingale: Switched to 7-Day Weekly Matrix view.' };
    }

    // 4. Briefing
    if (lower.includes('brief') || lower.includes('day sheet') || lower.includes('summary') || lower.includes('implant') || lower.includes('readiness')) {
      setIsBriefingModalOpen(true);
      return { success: true, message: 'Nightingale: Generated surgical day-sheet briefing with operative sequence and implant readiness.' };
    }

    // 5. Surgeon Filter
    if (lower.includes('vance')) {
      setFilterSurgeon('Dr. Evelyn Vance, MD');
      return { success: true, message: "Nightingale: Displaying only cases assigned to Dr. Evelyn Vance, MD." };
    }
    if (lower.includes('mercer')) {
      setFilterSurgeon('Provider');
      return { success: true, message: "Nightingale: Displaying only cases assigned to Provider." };
    }
    if (lower.includes('sterling')) {
      setFilterSurgeon('Primary Provider');
      return { success: true, message: "Nightingale: Displaying only cases assigned to Primary Provider." };
    }

    // 6. Procedure Filter
    if (lower.includes('rhinoplasty') || lower.includes('rhino')) {
      setFilterProcedure('Rhinoplasty');
      return { success: true, message: "Nightingale: Filtered schedule to show all Rhinoplasty and Septorhinoplasty procedures." };
    }
    if (lower.includes('blepharoplasty') || lower.includes('eyelid') || lower.includes('ptosis')) {
      setFilterProcedure('Blepharoplasty');
      return { success: true, message: "Nightingale: Filtered schedule to show Blepharoplasty and periorbital revision cases." };
    }
    if (lower.includes('facelift') || lower.includes('necklift')) {
      setFilterProcedure('Facelift');
      return { success: true, message: "Nightingale: Filtered schedule to show Facelift and rhytidectomy procedures." };
    }

    // 7. Room Filter
    if (lower.includes('only or 1') || lower.includes('only or #1') || lower.includes('or 1 only') || lower.includes('or#1 only') || lower.includes('show or 1')) {
      setFilterRoom('OR#1');
      return { success: true, message: "Nightingale: Filtered schedule to isolate OR Suite #1." };
    }
    if (lower.includes('only or 2') || lower.includes('only or #2') || lower.includes('or 2 only') || lower.includes('or#2 only') || lower.includes('show or 2')) {
      setFilterRoom('OR#2');
      return { success: true, message: "Nightingale: Filtered schedule to isolate OR Suite #2." };
    }
    if (lower.includes('only or 3') || lower.includes('only or #3') || lower.includes('or 3 only') || lower.includes('or#3 only') || lower.includes('show or 3')) {
      setFilterRoom('OR#3');
      return { success: true, message: "Nightingale: Filtered schedule to isolate OR Suite #3." };
    }

    // 8. Add Turnover Buffer / Sterilization Block
    if (lower.includes('turnover') || lower.includes('buffer') || lower.includes('sterilization') || lower.includes('block')) {
      const targetRoom = lower.includes('or 2') || lower.includes('or#2') ? 'OR#2' : lower.includes('or 3') || lower.includes('or#3') ? 'OR#3' : 'OR#1';
      let duration = 0.75; // 45 min
      if (lower.includes('30 min') || lower.includes('30m')) duration = 0.5;
      if (lower.includes('15 min') || lower.includes('15m')) duration = 0.25;
      if (lower.includes('1 hour') || lower.includes('60 min')) duration = 1.0;

      let startH = 11;
      if (lower.includes('12') || lower.includes('noon')) startH = 12;
      else if (lower.includes('1 pm') || lower.includes('1:00')) startH = 13;
      else if (lower.includes('2 pm') || lower.includes('2:00')) startH = 14;
      else if (lower.includes('9 am') || lower.includes('9:00')) startH = 9;
      else if (lower.includes('10 am') || lower.includes('10:00')) startH = 10;

      const newBlock: AppointmentItem = {
        id: `BLOCK-${Date.now().toString().slice(-4)}`,
        dayIndex: selectedDayIndex,
        room: targetRoom,
        startHour: startH,
        durationHours: duration,
        title: 'Turnover & Sterilization Buffer',
        surgeon: 'Surgical Suite Operations',
        details: '[Aura Vanguard] Deep suite decontamination & sterile tray staging',
        bgColor: 'bg-amber-500 text-white border-amber-600',
        isBlock: true,
        dos: dayDosMap[selectedDayIndex] || '07/13/2026',
        startTime: formatHourString(startH),
        length: `${Math.round(duration * 60)} Minutes`,
        patientName: 'OR Sterilization & Turnover Buffer',
        dob: 'N/A',
        age: 'N/A',
        phone: 'N/A',
        procedure: 'Deep Suite Decontamination & Instrument Reset',
        anesthesiologist: 'Nursing / Sterile Processing Staff',
        anesthesiaType: 'Sterilization Window',
        notes: 'Reserved by Nightingale AI Coordinator to maintain sterile turnover standards.'
      };

      setAppointmentsList(prev => [...prev, newBlock]);
      showToast(`Reserved ${Math.round(duration * 60)}m turnover buffer in ${targetRoom}`);
      return { success: true, message: `Nightingale: Inserted ${Math.round(duration * 60)}-minute turnover buffer in ${targetRoom} at ${formatHourString(startH)}. Sterile processing alerted.` };
    }

    // 9. Reschedule / Move a case
    if (lower.includes('move') || lower.includes('reschedule') || lower.includes('shift') || lower.includes('change time')) {
      let targetApt: AppointmentItem | undefined;
      const patientKeys = [
        { key: 'brody', match: 'Brody' },
        { key: 'eleanor', match: 'Eleanor' },
        { key: 'martinez', match: 'Martinez' },
        { key: 'toney', match: 'Toney' },
        { key: 'manesh', match: 'Manesh' },
        { key: 'matias', match: 'Matias' },
        { key: 'israel', match: 'Israel' },
        { key: 'bari', match: 'Bari' },
        { key: 'powers', match: 'Powers' },
        { key: 'wang', match: 'Wang' },
        { key: 'york', match: 'York' },
        { key: 'khan', match: 'Khan' },
        { key: 'vingsbo', match: 'Vingsbo' },
        { key: 'billauer', match: 'Billauer' },
        { key: 'sprong', match: 'Sprong' },
        { key: 'danek', match: 'Danek' },
        { key: 'depoli', match: 'DePoli' },
      ];

      for (const p of patientKeys) {
        if (lower.includes(p.key)) {
          targetApt = appointmentsList.find(a => 
            a.patientName.toLowerCase().includes(p.key) || a.title.toLowerCase().includes(p.key)
          );
          if (targetApt) break;
        }
      }

      if (!targetApt) {
        targetApt = appointmentsList.find(a => !a.isBlock);
      }

      if (targetApt) {
        let newRoom = targetApt.room;
        if (lower.includes('or 1') || lower.includes('or#1') || lower.includes('or 1')) newRoom = 'OR#1';
        else if (lower.includes('or 2') || lower.includes('or#2')) newRoom = 'OR#2';
        else if (lower.includes('or 3') || lower.includes('or#3')) newRoom = 'OR#3';

        let newStartH = targetApt.startHour;
        if (lower.includes('8 am') || lower.includes('8:00')) newStartH = 8;
        else if (lower.includes('9 am') || lower.includes('9:00')) newStartH = 9;
        else if (lower.includes('9:30') || lower.includes('9.5')) newStartH = 9.5;
        else if (lower.includes('10 am') || lower.includes('10:00')) newStartH = 10;
        else if (lower.includes('11 am') || lower.includes('11:00')) newStartH = 11;
        else if (lower.includes('12 pm') || lower.includes('12:00') || lower.includes('noon')) newStartH = 12;
        else if (lower.includes('1 pm') || lower.includes('1:00')) newStartH = 13;
        else if (lower.includes('1:30') || lower.includes('1.5')) newStartH = 13.5;
        else if (lower.includes('2 pm') || lower.includes('2:00')) newStartH = 14;
        else if (lower.includes('3 pm') || lower.includes('3:00')) newStartH = 15;
        else if (lower.includes('3:30')) newStartH = 15.5;

        let newDayIndex = targetApt.dayIndex;
        if (lower.includes('tomorrow')) newDayIndex = Math.min(targetApt.dayIndex + 1, 6);
        else if (lower.includes('tuesday')) newDayIndex = 1;
        else if (lower.includes('wednesday')) newDayIndex = 2;
        else if (lower.includes('thursday')) newDayIndex = 3;
        else if (lower.includes('friday')) newDayIndex = 4;
        else if (lower.includes('monday') || lower.includes('today')) newDayIndex = 0;

        const updatedApt: AppointmentItem = {
          ...targetApt,
          dayIndex: newDayIndex,
          room: newRoom,
          startHour: newStartH,
          startTime: formatHourString(newStartH),
          dos: dayDosMap[newDayIndex] || targetApt.dos,
        };

        setAppointmentsList(prev => prev.map(a => a.id === targetApt!.id ? updatedApt : a));
        const dayLabel = daysOfWeek[newDayIndex]?.dayName || `Day ${newDayIndex}`;
        showToast(`Nightingale: Rescheduled ${targetApt.patientName || targetApt.title} to ${newRoom} (${dayLabel} at ${formatHourString(newStartH)})`);
        return {
          success: true,
          message: `Nightingale: Successfully moved ${targetApt.patientName || targetApt.title}'s case to ${newRoom} on ${dayLabel} at ${formatHourString(newStartH)}. Verified surgeon credentialing and notified circulating nurse.`
        };
      }
    }

    // Default response
    return {
      success: true,
      message: `Nightingale: Processed practice instruction "${cmdText}". All 3 OR suites operating smoothly with zero surgical collisions.`
    };
  };

  // Dynamic 7-day week calculation starting from baseDate (Monday)
  const daysOfWeek = useMemo(() => {
    const dayNames = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
    const shortDays = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

    return Array.from({ length: 7 }, (_, i) => {
      const d = new Date(baseDate);
      d.setDate(baseDate.getDate() + i);
      const m = d.getMonth() + 1;
      const dayNum = d.getDate();
      const yr = d.getFullYear();
      const yy = String(yr).slice(-2);
      const mStr = m < 10 ? `0${m}` : `${m}`;
      const dStr = dayNum < 10 ? `0${dayNum}` : `${dayNum}`;
      const dateFormatted = `${mStr}/${dStr}/${yy}`;
      const fullDateStr = `${dayNames[i]}, ${d.toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}`;
      
      // Baseline today is July 13, 2026
      const isToday = d.getFullYear() === 2026 && d.getMonth() === 6 && d.getDate() === 13;
      const holidayCheck = checkIsFederalHoliday(d);

      return {
        label: `${shortDays[i]}, ${dateFormatted}`,
        dayName: dayNames[i],
        date: dateFormatted,
        isToday,
        fullDateStr,
        dayNum,
        dateObj: d,
        isHoliday: holidayCheck.isHoliday,
        holidayName: holidayCheck.holidayName,
      };
    });
  }, [baseDate]);

  const dayDosMap: { [key: number]: string } = useMemo(() => {
    const map: { [key: number]: string } = {};
    daysOfWeek.forEach((d, idx) => {
      map[idx] = d.date;
    });
    return map;
  }, [daysOfWeek]);

  const timeHorizonInfo = useMemo(() => {
    const baselineYear = 2026;
    const baselineMonth = 6; // July
    const currentYear = baseDate.getFullYear();
    const currentMonth = baseDate.getMonth();
    
    const totalMonthsDiff = (currentYear - baselineYear) * 12 + (currentMonth - baselineMonth);
    const isOffset = totalMonthsDiff !== 0 || baseDate.getDate() !== 13;
    
    let offsetDesc = '';
    if (totalMonthsDiff > 0) {
      if (totalMonthsDiff % 12 === 0) {
        const yrs = totalMonthsDiff / 12;
        offsetDesc = `+${yrs} Year${yrs > 1 ? 's' : ''} in the future`;
      } else {
        offsetDesc = `+${totalMonthsDiff} Month${totalMonthsDiff > 1 ? 's' : ''} ahead`;
      }
    } else if (totalMonthsDiff < 0) {
      const absM = Math.abs(totalMonthsDiff);
      if (absM % 12 === 0) {
        const yrs = absM / 12;
        offsetDesc = `-${yrs} Year${yrs > 1 ? 's' : ''} in the past`;
      } else {
        offsetDesc = `-${absM} Month${absM > 1 ? 's' : ''} past`;
      }
    } else if (isOffset) {
      offsetDesc = 'Offset week';
    }
    
    const monthYearStr = baseDate.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
    
    return {
      monthYearStr,
      isOffset,
      offsetDesc,
      totalMonthsDiff,
    };
  }, [baseDate]);

  const formatHourString = (hourNum: number) => {
    const h = Math.floor(hourNum);
    const m = Math.round((hourNum - h) * 60);
    const mStr = m < 10 ? `0${m}` : `${m}`;
    const period = h >= 12 ? 'PM' : 'AM';
    const displayH = h % 12 === 0 ? 12 : h % 12;
    const hStr = displayH < 10 ? `0${displayH}` : `${displayH}`;
    return `${hStr}:${mStr} ${period}`;
  };

  const currentHeaderDisplay = viewMode === 'DAY' 
    ? daysOfWeek[selectedDayIndex]?.fullDateStr 
    : `${daysOfWeek[0]?.fullDateStr} - ${daysOfWeek[6]?.fullDateStr}`;

  const rooms = ['OR#1', 'OR#2', 'OR#3'];
  
  // 15-Minute interval slots generation from 6 AM to 10 PM
  const timeSlots: { hourNum: number; displayLabel: string; isHourMark: boolean; minute: number }[] = [];
  for (let h = 6; h <= 21; h++) {
    for (let m = 0; m < 60; m += 15) {
      const hourNum = h + m / 60;
      const period = h >= 12 ? 'PM' : 'AM';
      const displayH = h % 12 === 0 ? 12 : h % 12;
      const mStr = m === 0 ? '00' : `${m}`;
      const displayLabel = m === 0 ? `${displayH}:${mStr} ${period}` : `:${mStr}`;
      timeSlots.push({
        hourNum,
        displayLabel,
        isHourMark: m === 0,
        minute: m,
      });
    }
  }

  const parseTimeToDecimalHour = (timeStr: string): number => {
    if (!timeStr) return 8;
    const match = timeStr.match(/(\d{1,2}):(\d{2})\s*(AM|PM)?/i);
    if (!match) return 8;
    let h = parseInt(match[1], 10);
    const m = parseInt(match[2], 10);
    const period = match[3]?.toUpperCase();
    if (period === 'PM' && h < 12) h += 12;
    if (period === 'AM' && h === 12) h = 0;
    return h + m / 60;
  };

  const parseLengthToHours = (lengthStr: string): number => {
    if (!lengthStr) return 1;
    const numMatch = lengthStr.match(/(\d+(\.\d+)?)/);
    if (!numMatch) return 1;
    const val = parseFloat(numMatch[1]);
    if (lengthStr.toLowerCase().includes('min')) {
      return val / 60;
    }
    return val;
  };

  const handleOpenAppointmentModal = (apt: AppointmentItem) => {
    setPatientSearchQuery(apt.patientName || '');
    setShowPatientSuggestions(false);
    setActiveAppointmentModal({ ...apt });
  };

  const handleSlotClick = (dIdx: number, startHourNum: number, roomName: string) => {
    const targetDayIndex = viewMode === 'DAY' ? selectedDayIndex : dIdx;
    const dosString = dayDosMap[targetDayIndex] || '07/13/2026';
    const startTimeStr = formatHourString(startHourNum);

    const newApt: AppointmentItem = {
      id: `APT-${Math.floor(100000 + Math.random() * 900000)}`,
      dayIndex: targetDayIndex,
      room: roomName,
      startHour: startHourNum,
      durationHours: 1.5,
      title: '',
      surgeon: 'Primary Provider',
      details: '[Vityls ASC] Elective Surgical Procedure',
      bgColor: 'bg-emerald-600 text-white border-emerald-700',
      dos: dosString,
      startTime: startTimeStr,
      length: '1.5 Hours',
      patientName: '',
      dob: '',
      age: '',
      phone: '',
      procedure: 'Elective Surgical Procedure',
      anesthesiologist: 'Anesthesia Provider',
      anesthesiaType: 'General Anesthesia',
      paymentType: 'Self-Pay',
      notes: `Scheduled for ${roomName} on ${dosString} at ${startTimeStr}`
    };
    setPatientSearchQuery('');
    setShowPatientSuggestions(false);
    setActiveAppointmentModal(newApt);
  };

  const handleDragStart = (e: React.DragEvent, id: string) => {
    e.dataTransfer.setData('text/plain', id);
    e.dataTransfer.effectAllowed = 'move';
    setDraggedAptId(id);
  };

  const handleDragEnd = () => {
    setDraggedAptId(null);
    setDragOverTarget(null);
  };

  const handleDropOnSlot = (e: React.DragEvent, dIdx: number, startHourNum: number, roomName: string) => {
    const id = e.dataTransfer.getData('text/plain') || draggedAptId;
    if (!id) return;

    const apt = appointmentsList.find((a) => a.id === id);
    if (!apt) return;

    const targetDayIndex = viewMode === 'DAY' ? selectedDayIndex : dIdx;
    const dosString = dayDosMap[targetDayIndex] || '07/13/2026';
    const startTimeStr = formatHourString(startHourNum);

    const updatedApt: AppointmentItem = {
      ...apt,
      dayIndex: targetDayIndex,
      room: roomName,
      startHour: startHourNum,
      dos: dosString,
      startTime: startTimeStr,
    };

    setAppointmentsList((prev) => prev.map((a) => (a.id === id ? updatedApt : a)));
    const dayName = daysOfWeek[targetDayIndex]?.label?.split(',')[0] || `Day ${targetDayIndex}`;
    showToast(`Rescheduled ${apt.patientName || apt.title} to ${roomName} (${dayName} at ${startTimeStr})`);
    setDraggedAptId(null);
    setDragOverTarget(null);
  };

  const handleCreateNewAppointment = () => {
    const targetDay = viewMode === 'DAY' ? selectedDayIndex : 0;
    const newApt: AppointmentItem = {
      id: `APT-${Math.floor(100000 + Math.random() * 900000)}`,
      dayIndex: targetDay, // Monday 07/13/26 or active selected day
      room: 'OR#1',
      startHour: 8,
      durationHours: 1.5,
      title: '',
      surgeon: 'Primary Provider',
      details: '[Vityls ASC] Elective Surgical Procedure',
      bgColor: 'bg-emerald-600 text-white border-emerald-700',
      dos: dayDosMap[targetDay] || '07/13/2026',
      startTime: '08:00 AM',
      length: '1.5 Hours',
      patientName: '',
      dob: '',
      age: '',
      phone: '',
      procedure: 'Elective Surgical Procedure',
      anesthesiologist: 'Anesthesia Provider',
      anesthesiaType: 'General Anesthesia',
      paymentType: 'Self-Pay',
      notes: 'New appointment scheduled from schedule toolbar.'
    };
    setPatientSearchQuery('');
    setShowPatientSuggestions(false);
    setActiveAppointmentModal(newApt);
  };

  const handleFormChange = (field: keyof AppointmentItem, value: string) => {
    if (!activeAppointmentModal) return;
    setActiveAppointmentModal((prev) => {
      if (!prev) return null;
      let newDayIndex = prev.dayIndex;
      if (field === 'dos') {
        if (value.includes('13')) newDayIndex = 0;
        else if (value.includes('14')) newDayIndex = 1;
        else if (value.includes('15')) newDayIndex = 2;
        else if (value.includes('16')) newDayIndex = 3;
        else if (value.includes('17')) newDayIndex = 4;
        else if (value.includes('18')) newDayIndex = 5;
        else if (value.includes('19')) newDayIndex = 6;
      }
      let newStartHour = prev.startHour;
      let newDurationHours = prev.durationHours;
      if (field === 'startTime') {
        const parsedH = parseTimeToDecimalHour(value);
        if (parsedH !== null && !isNaN(parsedH)) newStartHour = parsedH;
      }
      if (field === 'length') {
        const parsedDur = parseLengthToHours(value);
        if (parsedDur !== null && !isNaN(parsedDur)) newDurationHours = parsedDur;
      }
      return {
        ...prev,
        [field]: value,
        dayIndex: newDayIndex,
        startHour: newStartHour,
        durationHours: newDurationHours,
        ...(field === 'patientName' ? { title: value } : {}),
        ...(field === 'procedure' ? { details: `[Vityls ASC] ${value}` } : {}),
      };
    });
  };

  const handleSaveAppointment = () => {
    if (!activeAppointmentModal) return;
    const updated = activeAppointmentModal;
    setAppointmentsList((prev) => {
      const exists = prev.some((a) => a.id === updated.id);
      if (exists) {
        return prev.map((a) => (a.id === updated.id ? updated : a));
      } else {
        return [...prev, updated];
      }
    });
    setActiveAppointmentModal(null);
    showToast(`Saved appointment for ${updated.patientName || updated.title}.`);
  };

  const handleDeleteAppointment = () => {
    if (!activeAppointmentModal) return;
    setDeleteConfirmAppointment(activeAppointmentModal);
  };

  const handleConfirmDeleteAppointment = () => {
    if (!deleteConfirmAppointment) return;
    const targetId = deleteConfirmAppointment.id;
    const targetName = deleteConfirmAppointment.patientName;
    setAppointmentsList((prev) => prev.filter((a) => a.id !== targetId));
    setDeleteConfirmAppointment(null);
    setActiveAppointmentModal(null);
    showToast(`Deleted appointment for ${targetName} from schedule.`);
  };

  const handleOpenChartFromModal = () => {
    if (!activeAppointmentModal) return;
    const matchedCase = cases.find(
      (c) => c.id === activeAppointmentModal.caseId || c.name.toLowerCase().includes(activeAppointmentModal.patientName.toLowerCase())
    ) || cases[0];
    
    setActiveAppointmentModal(null);
    if (matchedCase) {
      onSelectPatient(matchedCase);
    }
  };

  // Handler to navigate days or weeks
  const handlePrev = () => {
    if (viewMode === 'DAY') {
      if (selectedDayIndex > 0) {
        setSelectedDayIndex(selectedDayIndex - 1);
      } else {
        const d = new Date(baseDate);
        d.setDate(d.getDate() - 7);
        setBaseDate(d);
        setSelectedDayIndex(6);
      }
    } else {
      const d = new Date(baseDate);
      d.setDate(d.getDate() - 7);
      setBaseDate(d);
    }
  };

  const handleNext = () => {
    if (viewMode === 'DAY') {
      if (selectedDayIndex < 6) {
        setSelectedDayIndex(selectedDayIndex + 1);
      } else {
        const d = new Date(baseDate);
        d.setDate(d.getDate() + 7);
        setBaseDate(d);
        setSelectedDayIndex(0);
      }
    } else {
      const d = new Date(baseDate);
      d.setDate(d.getDate() + 7);
      setBaseDate(d);
    }
  };

  const handleToday = () => {
    handleResetToToday();
  };

  // Weekly Notes Save Functionality
  const handleSaveWeeklyNotes = () => {
    const updated = { ...weeklyNotes, [activeWeekKey]: noteDraft };
    setWeeklyNotes(updated);
    localStorage.setItem('schedule_weekly_notes_db', JSON.stringify(updated));
    const now = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    setSavedNotesTimestamp(now);
    showToast(`Notes saved for ${activeWeekKey}`);
  };

  const handleAppendNoteTemplate = (templateText: string) => {
    setNoteDraft((prev) => (prev ? `${prev}\n• ${templateText}` : `• ${templateText}`));
  };

  const monthCalendarDays = Array.from({ length: 31 }, (_, i) => i + 1);

  // Filtered appointments for Day vs Week mode + Nightingale AI Filters
  const displayedAppointments = appointmentsList.filter((a) => {
    if (viewMode === 'DAY' && a.dayIndex !== selectedDayIndex) return false;
    if (filterSurgeon && !a.surgeon.toLowerCase().includes(filterSurgeon.toLowerCase())) return false;
    if (filterRoom && a.room !== filterRoom) return false;
    if (filterProcedure && !(a.procedure || a.details || '').toLowerCase().includes(filterProcedure.toLowerCase())) return false;
    return true;
  });

  return (
    <div className="w-full bg-[#F4F5F1] text-[#14432E] font-sans text-xs min-h-screen flex flex-col border border-[#E1E4DC] shadow-xs rounded-xl overflow-hidden relative">
      
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-6 right-6 z-50 bg-[#14432E] text-white text-xs font-semibold px-4 py-3 rounded-xl shadow-2xl border border-[#5B6B60] flex items-center gap-2.5 animate-in slide-in-from-top duration-300">
          <CheckCircle2 className="w-4 h-4 text-[#1B4332] shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Date Header Controls & Main Content Area with reduced side padding */}
      <div className="flex-1 p-1.5 sm:p-2.5 flex flex-col gap-2.5">

        {/* Nightingale AI Practice Coordinator Command Bar */}
        <NightingaleScheduleCommandCoordinator
          onExecuteCommand={handleExecuteNightingaleCommand}
          onOpenBriefing={() => setIsBriefingModalOpen(true)}
          onOpenNewAppointmentModal={handleCreateNewAppointment}
          onOpenBlockTimeModal={() => setIsBlockTimeModalOpen(true)}
          onOpenPrintModal={() => setIsPrintModalOpen(true)}
          viewMode={viewMode}
          onSetViewMode={setViewMode}
          onPrevDate={handlePrev}
          onNextDate={handleNext}
          onToday={handleToday}
          activeFilters={{
            surgeon: filterSurgeon,
            room: filterRoom,
            procedure: filterProcedure,
          }}
          onClearFilters={handleClearFilters}
          currentDateDisplay={currentHeaderDisplay}
          timeHorizonInfo={timeHorizonInfo}
          onResetToToday={handleResetToToday}
        />

        {/* Time Horizon Notice when viewing past or future months/years */}
        {timeHorizonInfo.isOffset && (
          <div className="bg-[#14432E] text-white px-4 py-2.5 rounded-xl border border-[#5B6B60] shadow-md flex items-center justify-between gap-3 animate-in fade-in">
            <div className="flex items-center gap-2.5">
              <span className="p-1 rounded-md bg-[#2F9E6E] text-[#E4F3EA]">
                <CalendarIcon className="w-4 h-4" />
              </span>
              <div>
                <span className="text-xs font-bold text-white font-display">
                  Viewing Extended Time Horizon: {timeHorizonInfo.monthYearStr}
                </span>
                <span className="ml-2 text-[11px] text-[#E1E4DC] font-medium font-mono">
                  ({timeHorizonInfo.offsetDesc}) • Active 3-OR Suite Operative Matrix
                </span>
              </div>
            </div>
            <button
              type="button"
              onClick={handleResetToToday}
              className="px-3 py-1 bg-[#FBEEDB] hover:bg-[#FBEEDB]/80 text-[#7A4E17] font-bold text-xs rounded-lg transition-colors cursor-pointer shadow-xs flex items-center gap-1 shrink-0"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Return to Today (Jul 13, 2026)</span>
            </button>
          </div>
        )}
        
        {/* Active Schedule Date Banner */}
        <div className="flex items-center justify-between px-3 py-2 bg-white rounded-lg border border-[#E1E4DC] shadow-2xs">
          <div className="flex items-center gap-2 flex-wrap">
            <CalendarIcon className="w-4 h-4 text-[#2F9E6E]" />
            <div className="text-sm sm:text-base font-display font-bold text-[#14432E] tracking-tight">
              {currentHeaderDisplay}
            </div>
            {viewMode === 'DAY' && (
              <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold font-mono ${
                daysOfWeek[selectedDayIndex]?.isToday ? 'bg-[#E4F3EA] text-[#1B4332] border border-[#E1E4DC]' : 'bg-[#F1F3EC] text-[#5B6B60] border border-[#E1E4DC]'
              }`}>
                {daysOfWeek[selectedDayIndex]?.isToday ? 'TODAY' : daysOfWeek[selectedDayIndex]?.dayName}
              </span>
            )}
            {viewMode === 'DAY' && daysOfWeek[selectedDayIndex]?.isHoliday && (
              <span className="px-2.5 py-0.5 rounded-full text-[10.5px] font-bold bg-slate-700 text-white flex items-center gap-1 shadow-2xs border border-slate-600 font-sans" title={daysOfWeek[selectedDayIndex]?.holidayName || 'Federal Holiday'}>
                <span>🇺🇸 Federal Holiday:</span>
                <span className="text-amber-300">{daysOfWeek[selectedDayIndex]?.holidayName}</span>
              </span>
            )}
            {viewMode === 'WK' && (
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-[#E4F3EA] text-[#1B4332] border border-[#E1E4DC] font-mono">
                WEEK VIEW
              </span>
            )}
          </div>
          <div className="text-[11px] text-[#5B6B60] font-medium hidden sm:block font-mono">
            {displayedAppointments.length} {displayedAppointments.length === 1 ? 'case' : 'cases'} scheduled
          </div>
        </div>

        {/* DAY MODE QUICK SELECTOR BAR: Allows fast switching between Mon-Sun when in DAY mode */}
        {viewMode === 'DAY' && (
          <div className="flex items-center gap-1.5 overflow-x-auto py-1 px-2 bg-[#F1F3EC] rounded-lg border border-[#E1E4DC]">
            <span className="text-[11px] font-bold text-[#5B6B60] uppercase tracking-wider pr-1 flex items-center gap-1 font-display">
              <Clock className="w-3.5 h-3.5 text-[#2F9E6E]" />
              Select Day:
            </span>
            {daysOfWeek.map((day, idx) => {
              const isSelected = selectedDayIndex === idx;
              const count = appointmentsList.filter((a) => a.dayIndex === idx).length;
              return (
                <button
                  key={day.date}
                  onClick={() => setSelectedDayIndex(idx)}
                  className={`px-3 py-1 rounded-md text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer whitespace-nowrap ${
                    isSelected
                      ? 'bg-[#2F9E6E] text-white shadow-xs font-bold ring-1 ring-[#1B4332]'
                      : day.isHoliday
                      ? 'bg-slate-200 text-slate-700 hover:bg-slate-300 border border-slate-300 font-medium'
                      : 'bg-white text-[#5B6B60] hover:bg-[#F1F3EC] border border-[#E1E4DC]'
                  }`}
                >
                  <span>{day.label}</span>
                  {day.isToday && (
                    <span className="text-[9px] px-1.5 py-0.2 rounded-full font-bold font-mono bg-[#FBEEDB] text-[#7A4E17]">
                      Today
                    </span>
                  )}
                  {day.isHoliday && (
                    <span className={`text-[8.5px] px-1.5 py-0.2 rounded-full font-bold ${
                      isSelected ? 'bg-slate-800 text-amber-300' : 'bg-slate-300 text-slate-800'
                    }`}>
                      🇺🇸 Holiday
                    </span>
                  )}
                  <span className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono font-bold ${
                    isSelected ? 'bg-[#1B4332] text-white' : 'bg-[#F1F3EC] text-[#5B6B60]'
                  }`}>
                    {count} {count === 1 ? 'case' : 'cases'}
                  </span>
                </button>
              );
            })}
          </div>
        )}

        {/* Main Grid + Sidebar Split with reduced margins */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-2.5 items-start flex-1">
          
          {/* Calendar Matrix View (10 Cols) */}
          <div className="lg:col-span-10 bg-white border border-slate-300 rounded-xl shadow-2xs overflow-x-auto transition-all">
            <div className={viewMode === 'DAY' ? 'min-w-[700px] w-full' : 'min-w-[960px] w-full'}>
              
              {/* Quick Interactive Tip Banner */}
              <div className="bg-slate-50 border-b border-slate-200 px-3 py-1.5 flex items-center justify-between text-[11px] text-slate-600 select-none">
                <div className="flex items-center gap-1.5 font-medium">
                  <span className="text-emerald-700 font-bold flex items-center gap-1">
                    <Plus className="w-3 h-3 text-emerald-600" />
                    {viewMode === 'DAY' ? `Schedule for ${daysOfWeek[selectedDayIndex]?.fullDateStr}:` : 'Interactive 7-Day Matrix (Mon - Sun):'}
                  </span>
                  <span>
                    {viewMode === 'DAY' 
                      ? 'Viewing OR#1, OR#2, and OR#3. Click any 15-min slot to schedule a case or drag to reschedule.'
                      : 'Schedule begins Monday. Click any slot or drag appointment blocks to adjust times and rooms.'}
                  </span>
                </div>
                <div className="text-[10px] text-slate-600 font-semibold bg-slate-200/80 px-2.5 py-0.5 rounded-full">
                  {displayedAppointments.length} {displayedAppointments.length === 1 ? 'Case' : 'Cases'} {viewMode === 'DAY' ? 'on this day' : 'this week'}
                </div>
              </div>
              
              {/* ========================================================================= */}
              {/* VIEW MODE: DAY ONLY (10 Cols: Time col-span-1, OR#1 col-span-3, OR#2 col-span-3, OR#3 col-span-3) */}
              {/* ========================================================================= */}
              {viewMode === 'DAY' && (
                <div>
                  {/* Header Rooms Row */}
                  <div className="grid grid-cols-10 border-b border-slate-300 bg-slate-100 text-center text-xs font-bold text-slate-700">
                    <div className="col-span-1 p-2 border-r border-slate-300 bg-slate-200 text-slate-800">
                      Time
                    </div>
                    {rooms.map((roomName, rIdx) => (
                      <div 
                        key={roomName} 
                        className={`col-span-3 border-r border-slate-300 py-2 px-2 ${
                          rIdx === 0 ? 'bg-indigo-50/80 text-indigo-950' : rIdx === 1 ? 'bg-sky-50/80 text-sky-950' : 'bg-emerald-50/80 text-emerald-950'
                        } ${rIdx === 2 ? 'border-r-0' : ''}`}
                      >
                        <div className="text-sm font-bold tracking-tight">{roomName}</div>
                        <div className="text-[10px] text-slate-500 font-normal mt-0.5">
                          {daysOfWeek[selectedDayIndex]?.dayName} Flow & Utilization
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* 15-Minute Rows Grid for DAY Mode */}
                  <div className="relative">
                    {timeSlots.map((slot, sIdx) => {
                      return (
                        <div 
                          key={sIdx} 
                          className={`grid grid-cols-10 min-h-[24px] max-h-[24px] text-[10px] ${
                            slot.isHourMark 
                              ? 'border-t-2 border-slate-300 bg-slate-50/90' 
                              : 'border-t border-slate-100 border-dashed'
                          }`}
                        >
                          {/* Time Label */}
                          <div className={`col-span-1 border-r border-slate-300 pr-2 select-none flex items-center justify-end ${
                            slot.isHourMark ? 'bg-slate-200/90 text-slate-800 font-bold text-[10.5px]' : 'bg-slate-50/70 text-slate-400 font-medium text-[8.5px]'
                          }`}>
                            {slot.displayLabel}
                          </div>

                          {/* 3 Room Columns for the selected day */}
                          {rooms.map((roomName, rIdx) => {
                            const isHoveredTarget = 
                              dragOverTarget?.dIdx === selectedDayIndex && 
                              Math.abs((dragOverTarget?.hour ?? -1) - slot.hourNum) < 0.01 && 
                              dragOverTarget?.room === roomName;

                            return (
                              <div
                                key={roomName}
                                onClick={() => handleSlotClick(selectedDayIndex, slot.hourNum, roomName)}
                                onDragOver={(e) => {
                                  e.preventDefault();
                                  setDragOverTarget({ dIdx: selectedDayIndex, hour: slot.hourNum, room: roomName });
                                }}
                                onDragLeave={() => {
                                  setDragOverTarget(null);
                                }}
                                onDrop={(e) => {
                                  e.preventDefault();
                                  setDragOverTarget(null);
                                  handleDropOnSlot(e, selectedDayIndex, slot.hourNum, roomName);
                                }}
                                className={`col-span-3 border-r border-slate-200/80 transition-all cursor-pointer group flex items-center justify-between px-2 relative ${
                                  rIdx === 2 ? 'border-r-0' : ''
                                } ${
                                  isHoveredTarget 
                                    ? 'bg-emerald-200/90 ring-2 ring-emerald-500 ring-inset z-10' 
                                    : 'hover:bg-sky-50/90 hover:border-sky-300'
                                }`}
                                title={`Click to add appointment or drop here (${daysOfWeek[selectedDayIndex]?.dayName} - ${roomName} at ${slot.displayLabel})`}
                              >
                                <span className="opacity-0 group-hover:opacity-100 text-[8px] font-bold text-sky-700 bg-sky-100 px-1.5 py-0.5 rounded transition-opacity pointer-events-none select-none shadow-2xs">
                                  + Schedule {roomName} ({slot.displayLabel})
                                </span>
                              </div>
                            );
                          })}
                        </div>
                      );
                    })}

                    {/* Scheduled Appointment Overlays for DAY mode (spacious 30% width per room) */}
                    {displayedAppointments.map((apt, aIdx) => {
                      const topPx = (apt.startHour - 6) * 96; // 24px per 15min * 4 = 96px per hour
                      const heightPx = Math.max(apt.durationHours * 96, 26);

                      const roomIndex = apt.room === 'OR#1' ? 0 : apt.room === 'OR#2' ? 1 : 2;
                      const colOffset = 1 + roomIndex * 3;
                      const leftPercent = (colOffset / 10) * 100;
                      const widthPercent = (3 / 10) * 100;

                      const isBeingDragged = draggedAptId === apt.id;

                      return (
                        <div
                          key={apt.id + '-' + aIdx}
                          draggable={true}
                          onDragStart={(e) => handleDragStart(e, apt.id)}
                          onDragEnd={handleDragEnd}
                          onClick={(e) => {
                            e.stopPropagation();
                            handleOpenAppointmentModal(apt);
                          }}
                          style={{
                            top: `${topPx}px`,
                            height: `${heightPx}px`,
                            left: `${leftPercent}%`,
                            width: `${widthPercent}%`,
                          }}
                          className={`absolute p-2 rounded border text-[11px] leading-tight overflow-hidden shadow-md cursor-grab active:cursor-grabbing hover:z-30 hover:scale-[1.01] transition-transform select-none ${apt.bgColor} ${
                            isBeingDragged ? 'opacity-40 border-dashed border-2 ring-2 ring-amber-400 z-40' : ''
                          }`}
                          title={`Drag to reschedule or click to view/edit (${apt.patientName || apt.title})`}
                        >
                          <div className="font-bold flex items-center justify-between text-xs border-b border-white/20 pb-0.5 mb-1">
                            <span className="flex items-center gap-1">
                              <Clock className="w-3 h-3 opacity-80" />
                              <span>{apt.startTime || formatHourString(apt.startHour)} ({apt.length || `${apt.durationHours} hrs`})</span>
                            </span>
                            {!apt.isBlock && <span className="text-[9px] opacity-90 font-mono bg-black/20 px-1.5 py-0.2 rounded">#{apt.id}</span>}
                          </div>
                          
                          <div className="font-black text-sm truncate tracking-tight">{apt.patientName || apt.title}</div>
                          
                          <div className="text-[10px] font-semibold opacity-95 truncate mt-0.5 flex items-center gap-1.5">
                            <span>Surgeon: {apt.surgeon}</span>
                            {apt.anesthesiologist && <span className="opacity-80">• Anesth: {apt.anesthesiologist}</span>}
                          </div>

                          {/* Details & Notes */}
                          {heightPx >= 48 && (
                            <div className="border-t border-white/20 pt-1 mt-1 text-[10px] font-medium leading-normal opacity-95 line-clamp-3">
                              <span className="font-bold">Procedure: </span>{apt.procedure || apt.details}
                              {apt.notes && <div className="text-[9.5px] italic mt-0.5 opacity-90">Note: {apt.notes}</div>}
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* ========================================================================= */}
              {/* VIEW MODE: WEEK (22 Cols: Time col-span-1, 7 Days x 3 Rooms = 21 cols) */}
              {/* Starts on MONDAY */}
              {/* ========================================================================= */}
              {viewMode === 'WK' && (
                <div>
                  {/* Header Days Row Starting on MONDAY */}
                  <div className="grid grid-cols-22 border-b border-slate-300 bg-slate-100 text-center text-[11px] font-bold text-slate-700">
                    <div className="col-span-1 p-2 border-r border-slate-300 bg-slate-200">
                      Time
                    </div>
                    {daysOfWeek.map((day, dIdx) => (
                      <div 
                        key={dIdx} 
                        onClick={() => {
                          setSelectedDayIndex(dIdx);
                          setViewMode('DAY');
                        }}
                        className={`col-span-3 border-r border-slate-300 py-1 px-1 cursor-pointer transition-colors ${
                          day.isToday 
                            ? 'bg-amber-100/90 text-slate-900 border-b-2 border-b-amber-500' 
                            : day.isHoliday
                            ? 'bg-slate-200/95 text-slate-800 border-b-2 border-b-slate-400 hover:bg-slate-300/90'
                            : 'bg-slate-100 hover:bg-slate-200'
                        }`}
                        title={`Click to focus on ${day.label}${day.isHoliday ? ` (${day.holidayName})` : ''}`}
                      >
                        <div className="flex flex-col items-center justify-center gap-0.5">
                          <div className="flex items-center justify-center gap-1">
                            <span>{day.label}</span>
                            {day.isToday && <span className="text-[8px] bg-amber-300 text-amber-950 font-bold px-1 rounded-xs">Today</span>}
                          </div>
                          {day.isHoliday && (
                            <span className="text-[8px] bg-slate-700 text-white font-bold px-1.5 py-0.2 rounded truncate max-w-[95%]" title={day.holidayName || 'Federal Holiday'}>
                              🇺🇸 {day.holidayName}
                            </span>
                          )}
                        </div>
                        <div className={`grid grid-cols-3 text-[10px] font-semibold border-t mt-1 pt-0.5 ${
                          day.isHoliday ? 'border-slate-300 text-slate-600 bg-slate-300/40 rounded-xs' : 'border-slate-200 text-slate-500'
                        }`}>
                          <div>OR#1</div>
                          <div>OR#2</div>
                          <div>OR#3</div>
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* 15-Minute Rows Grid for Week Mode */}
                  <div className="relative">
                    {timeSlots.map((slot, sIdx) => {
                      return (
                        <div 
                          key={sIdx} 
                          className={`grid grid-cols-22 min-h-[22px] max-h-[22px] text-[10px] ${
                            slot.isHourMark 
                              ? 'border-t-2 border-slate-300 bg-slate-50/90' 
                              : 'border-t border-slate-100 border-dashed'
                          }`}
                        >
                          {/* Time Label */}
                          <div className={`col-span-1 border-r border-slate-300 pr-1.5 select-none flex items-center justify-end ${
                            slot.isHourMark ? 'bg-slate-200/90 text-slate-800 font-bold text-[10px]' : 'bg-slate-50/70 text-slate-400 font-medium text-[8px]'
                          }`}>
                            {slot.displayLabel}
                          </div>

                          {/* 7 Day Columns Starting on Monday */}
                          {daysOfWeek.map((day, dIdx) => (
                            <div 
                              key={dIdx} 
                              className={`col-span-3 grid grid-cols-3 border-r border-slate-300 relative ${
                                day.isToday 
                                  ? (slot.isHourMark ? 'bg-amber-100/25' : 'bg-amber-50/20') 
                                  : day.isHoliday
                                  ? (slot.isHourMark ? 'bg-slate-200/80' : 'bg-slate-100/85')
                                  : 'bg-white'
                              }`}
                            >
                              {rooms.map((roomName, rIdx) => {
                                const isHoveredTarget = 
                                  dragOverTarget?.dIdx === dIdx && 
                                  Math.abs((dragOverTarget?.hour ?? -1) - slot.hourNum) < 0.01 && 
                                  dragOverTarget?.room === roomName;

                                return (
                                  <div
                                    key={roomName}
                                    onClick={() => handleSlotClick(dIdx, slot.hourNum, roomName)}
                                    onDragOver={(e) => {
                                      e.preventDefault();
                                      setDragOverTarget({ dIdx, hour: slot.hourNum, room: roomName });
                                    }}
                                    onDragLeave={() => {
                                      setDragOverTarget(null);
                                    }}
                                    onDrop={(e) => {
                                      e.preventDefault();
                                      setDragOverTarget(null);
                                      handleDropOnSlot(e, dIdx, slot.hourNum, roomName);
                                    }}
                                    className={`border-r ${day.isHoliday ? 'border-slate-300/70' : 'border-slate-100/60'} transition-all cursor-pointer group flex items-center justify-center relative ${
                                      rIdx === 2 ? 'border-r-0' : ''
                                    } ${
                                      isHoveredTarget 
                                        ? 'bg-emerald-200/90 ring-2 ring-emerald-500 ring-inset z-10' 
                                        : day.isHoliday
                                        ? 'hover:bg-slate-300/80 hover:border-slate-400'
                                        : 'hover:bg-sky-50/80 hover:border-sky-300'
                                    }`}
                                    title={`Click to add appointment or drop here (${day.label.split(',')[0]} - ${roomName} at ${slot.displayLabel}${day.isHoliday ? ` • Holiday: ${day.holidayName}` : ''})`}
                                  >
                                    <span className="opacity-0 group-hover:opacity-100 text-[7px] font-bold text-sky-700 bg-sky-100 px-0.5 py-0 rounded transition-opacity pointer-events-none select-none shadow-2xs">
                                      +
                                    </span>
                                  </div>
                                );
                              })}
                            </div>
                          ))}
                        </div>
                      );
                    })}

                    {/* Scheduled Appointment Overlays for Week mode */}
                    {displayedAppointments.map((apt, aIdx) => {
                      const topPx = (apt.startHour - 6) * 88;
                      const heightPx = Math.max(apt.durationHours * 88, 20);

                      const roomIndex = apt.room === 'OR#1' ? 0 : apt.room === 'OR#2' ? 1 : 2;
                      const colOffset = 1 + apt.dayIndex * 3 + roomIndex;
                      const leftPercent = (colOffset / 22) * 100;
                      const widthPercent = (1 / 22) * 100;

                      const isBeingDragged = draggedAptId === apt.id;

                      return (
                        <div
                          key={apt.id + '-' + aIdx}
                          draggable={true}
                          onDragStart={(e) => handleDragStart(e, apt.id)}
                          onDragEnd={handleDragEnd}
                          onClick={(e) => {
                            e.stopPropagation();
                            handleOpenAppointmentModal(apt);
                          }}
                          style={{
                            top: `${topPx}px`,
                            height: `${heightPx}px`,
                            left: `${leftPercent}%`,
                            width: `${widthPercent}%`,
                          }}
                          className={`absolute p-1 rounded-xs border text-[9.5px] leading-tight overflow-hidden shadow-2xs cursor-grab active:cursor-grabbing hover:z-30 hover:scale-[1.02] transition-transform select-none ${apt.bgColor} ${
                            isBeingDragged ? 'opacity-40 border-dashed border-2 ring-2 ring-amber-400 z-40' : ''
                          }`}
                          title={`Drag to reschedule or click to view/edit (${apt.patientName || apt.title})`}
                        >
                          <div className="font-bold flex items-center justify-between text-[10px]">
                            <span className="truncate">{apt.startTime || formatHourString(apt.startHour)}</span>
                            {!apt.isBlock && <span className="text-[8px] opacity-90 font-mono">#{apt.id}</span>}
                          </div>
                          <div className="font-black text-[10.5px] truncate mt-0.5">{apt.patientName || apt.title}</div>
                          <div className="text-[9px] font-semibold opacity-95 truncate">{apt.surgeon}</div>

                          {/* Details section if height allows */}
                          {heightPx >= 36 && (
                            <div className="border-t border-white/25 pt-0.5 mt-0.5 text-[8.5px] font-medium leading-tight opacity-90 line-clamp-2">
                              {apt.procedure || apt.details}
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

            </div>
          </div>

          {/* Right Sidebar: Mini Calendar & NEW WEEK-SPECIFIC NOTES SECTION (Permanently Visible) */}
          <div className="lg:col-span-2 space-y-2.5">
            
            {/* Mini Month Calendar */}
            <div className="bg-white border border-[#E1E4DC] rounded p-2.5 shadow-2xs">
                <div className="flex items-center justify-between text-xs font-bold text-[#14432E] mb-2 border-b border-[#E1E4DC] pb-1 font-display">
                  <button 
                    onClick={() => showToast('Previous month')}
                    className="hover:text-[#2F9E6E] px-1 cursor-pointer font-bold"
                  >
                    &lt;
                  </button>
                  <span className="font-display">July 2026</span>
                  <button 
                    onClick={() => showToast('Next month')}
                    className="hover:text-[#2F9E6E] px-1 cursor-pointer font-bold"
                  >
                    &gt;
                  </button>
                </div>

                <div className="grid grid-cols-7 text-center text-[10px] font-bold text-[#5B6B60] mb-1 font-mono">
                  <div>Mo</div>
                  <div>Tu</div>
                  <div>We</div>
                  <div>Th</div>
                  <div>Fr</div>
                  <div>Sa</div>
                  <div>Su</div>
                </div>

                <div className="grid grid-cols-7 text-center text-[10px] gap-y-1 text-[#14432E] font-medium">
                  {/* June trailing days */}
                  <div className="text-[#5B6B60]">29</div>
                  <div className="text-[#5B6B60]">30</div>
                  {monthCalendarDays.map((day) => {
                    const isToday = day === 13;
                    // Map day 13-19 to our week
                    const isInActiveWeek = day >= 13 && day <= 19;
                    const dayOffset = day - 13;

                    return (
                      <div
                        key={day}
                        onClick={() => {
                          if (isInActiveWeek) {
                            setSelectedDayIndex(dayOffset);
                            setViewMode('DAY');
                            showToast(`Selected ${daysOfWeek[dayOffset]?.fullDateStr}`);
                          } else {
                            showToast(`July ${day}, 2026 selected.`);
                          }
                        }}
                        className={`py-0.5 rounded cursor-pointer transition-colors font-mono ${
                          isToday 
                            ? 'bg-[#2F9E6E] text-white font-bold shadow-xs' 
                            : isInActiveWeek 
                            ? 'bg-[#FBEEDB] text-[#7A4E17] font-semibold hover:bg-[#FBEEDB]/70' 
                            : 'hover:bg-[#F1F3EC]'
                        }`}
                        title={isInActiveWeek ? `Click to view schedule for July ${day}` : `July ${day}, 2026`}
                      >
                        {day}
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* NEW WEEK-SPECIFIC NOTES SECTION BENEATH THE CALENDAR */}
              <div className="bg-white border border-[#E1E4DC] rounded p-3 shadow-2xs space-y-2">
                <div className="flex items-center justify-between border-b border-[#E1E4DC] pb-1.5">
                  <div className="flex items-center gap-1.5 font-bold text-xs text-[#14432E] font-display">
                    <FileText className="w-3.5 h-3.5 text-[#2F9E6E]" />
                    <span>Week Schedule Notes</span>
                  </div>
                  <span className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-[#E4F3EA] text-[#1B4332] border border-[#E1E4DC] font-mono">
                    July 13 - 19
                  </span>
                </div>

                <div className="text-[10px] text-[#5B6B60] font-medium">
                  Notes for <strong className="text-[#14432E]">{activeWeekKey}</strong> only:
                </div>

                {/* Free-text note field — auto-saves on blur. No tag buttons, no Save
                    button: type a note directly here, or tell Nightingale
                    ("note: OR 3 running 20 min behind") from the command bar above
                    and it lands here automatically. */}
                <div className="relative">
                  <textarea
                    value={noteDraft}
                    onChange={(e) => setNoteDraft(e.target.value)}
                    onBlur={() => handleSaveWeeklyNotes()}
                    placeholder="Type clinical staffing notes, OR turnover alerts, surgeon availability, or equipment reservations for this week..."
                    className="w-full h-32 p-2 border border-[#E1E4DC] rounded-md text-[11px] font-sans leading-relaxed text-[#14432E] placeholder-[#5B6B60] focus:outline-none focus:ring-1 focus:ring-[#2F9E6E] focus:border-[#2F9E6E] bg-[#F1F3EC]/40 resize-y"
                  />
                </div>

                <div className="text-[9.5px] text-[#5B6B60] pt-1 border-t border-[#E1E4DC]">
                  {savedNotesTimestamp ? (
                    <span className="text-[#1B4332] font-bold flex items-center gap-1 font-mono">
                      <CheckCircle2 className="w-3 h-3 text-[#1B4332]" />
                      Auto-saved at {savedNotesTimestamp}
                    </span>
                  ) : (
                    <span className="font-mono">Auto-saves as you type</span>
                  )}
                </div>
              </div>

            </div>

        </div>

      </div>

      {/* APPOINTMENT DETAILS POP-UP MODAL */}
      {activeAppointmentModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-200">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-300 w-full max-w-3xl overflow-hidden animate-in zoom-in-95 duration-200 flex flex-col">
            
            {/* Modal Header */}
            <div className="px-6 py-4 bg-slate-800 text-white flex items-center justify-between border-b border-slate-700">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-slate-700 flex items-center justify-center text-slate-200">
                  <CalendarIcon className="w-4 h-4 text-emerald-400" />
                </div>
                <div>
                  <h3 className="font-bold text-sm text-white flex items-center gap-2">
                    <span>Appointment Details</span>
                    {activeAppointmentModal.room && (
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-700 text-emerald-300 border border-slate-600">
                        {activeAppointmentModal.room}
                      </span>
                    )}
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-indigo-900 text-indigo-200 border border-indigo-700 flex items-center gap-1">
                      💳 {activeAppointmentModal.paymentType || 'Self-Pay'}
                    </span>
                  </h3>
                  <p className="text-[11px] text-slate-300 font-medium">
                    Modify appointment fields, update patient notes, or open chart
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setActiveAppointmentModal(null)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-700 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Body: 5 Lines of Fields */}
            <div className="p-6 space-y-4 text-xs font-sans text-slate-800 max-h-[75vh] overflow-y-auto">
              
              {/* LINE 1: Date of Service (DOS), Start Time, Length of Surgery / Appointment, Operating Room */}
              <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
                <div>
                  <label className="block text-[11px] font-bold text-slate-600 uppercase tracking-wider mb-1">
                    Date of Service (DOS)
                  </label>
                  <input
                    type="text"
                    value={activeAppointmentModal.dos || ''}
                    onChange={(e) => handleFormChange('dos', e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs font-semibold text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all shadow-2xs"
                    placeholder="MM/DD/YYYY"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-600 uppercase tracking-wider mb-1">
                    Start Time
                  </label>
                  <input
                    type="text"
                    value={activeAppointmentModal.startTime || ''}
                    onChange={(e) => handleFormChange('startTime', e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs font-semibold text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all shadow-2xs"
                    placeholder="08:00 AM"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-600 uppercase tracking-wider mb-1">
                    Length of Surgery
                  </label>
                  <select
                    value={activeAppointmentModal.length || '1.5 Hours'}
                    onChange={(e) => handleFormChange('length', e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs font-semibold text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all shadow-2xs cursor-pointer"
                  >
                    {!['15 Minutes', '30 Minutes', '45 Minutes', '1.0 Hour', '1.25 Hours', '1.5 Hours', '1.75 Hours', '2.0 Hours', '2.5 Hours', '3.0 Hours', '3.5 Hours', '4.0 Hours', '5.0 Hours', '6.0 Hours'].includes(activeAppointmentModal.length || '') && activeAppointmentModal.length && (
                      <option value={activeAppointmentModal.length}>{activeAppointmentModal.length}</option>
                    )}
                    <option value="15 Minutes">15 Minutes (0.25 Hrs)</option>
                    <option value="30 Minutes">30 Minutes (0.5 Hrs)</option>
                    <option value="45 Minutes">45 Minutes (0.75 Hrs)</option>
                    <option value="1.0 Hour">1.0 Hour (60 Mins)</option>
                    <option value="1.25 Hours">1.25 Hours (75 Mins)</option>
                    <option value="1.5 Hours">1.5 Hours (90 Mins)</option>
                    <option value="1.75 Hours">1.75 Hours (105 Mins)</option>
                    <option value="2.0 Hours">2.0 Hours (120 Mins)</option>
                    <option value="2.5 Hours">2.5 Hours (150 Mins)</option>
                    <option value="3.0 Hours">3.0 Hours (180 Mins)</option>
                    <option value="3.5 Hours">3.5 Hours (210 Mins)</option>
                    <option value="4.0 Hours">4.0 Hours (240 Mins)</option>
                    <option value="5.0 Hours">5.0 Hours (300 Mins)</option>
                    <option value="6.0 Hours">6.0 Hours (360 Mins)</option>
                  </select>
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-600 uppercase tracking-wider mb-1">
                    Operating Room
                  </label>
                  <select
                    value={activeAppointmentModal.room || 'OR#1'}
                    onChange={(e) => handleFormChange('room', e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs font-semibold text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all shadow-2xs cursor-pointer"
                  >
                    <option value="OR#1">OR#1</option>
                    <option value="OR#2">OR#2</option>
                    <option value="OR#3">OR#3</option>
                  </select>
                </div>
              </div>

              {/* LINE 2: Patient's Name, Date of Birth, Age, Phone Number */}
              <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
                <div className="relative">
                  <div className="flex items-center justify-between mb-1">
                    <label className="block text-[11px] font-bold text-slate-600 uppercase tracking-wider">
                      Patient Name
                    </label>
                    <span className="text-[10px] text-indigo-600 font-semibold">
                      Type 3+ letters to search
                    </span>
                  </div>
                  <div className="relative">
                    <input
                      type="text"
                      value={activeAppointmentModal.patientName || ''}
                      onChange={(e) => {
                        const val = e.target.value;
                        handleFormChange('patientName', val);
                        setPatientSearchQuery(val);
                        setShowPatientSuggestions(val.trim().length >= 3);
                      }}
                      onFocus={() => {
                        if ((activeAppointmentModal.patientName || '').trim().length >= 3) {
                          setShowPatientSuggestions(true);
                        }
                      }}
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs font-semibold text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all shadow-2xs"
                      placeholder="Type patient last name..."
                      autoComplete="off"
                    />
                    {activeAppointmentModal.patientName && (
                      <button
                        type="button"
                        onClick={() => {
                          handleFormChange('patientName', '');
                          setPatientSearchQuery('');
                          setShowPatientSuggestions(false);
                        }}
                        className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 p-0.5"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>

                  {/* Dynamic Patient Dropdown */}
                  {showPatientSuggestions && activeAppointmentModal.patientName && activeAppointmentModal.patientName.trim().length >= 3 && (() => {
                    const matches = searchPatientsByLastName(activeAppointmentModal.patientName, cases, { minChars: 3 });
                    return (
                      <div className="absolute left-0 top-full mt-1.5 w-[320px] sm:w-[380px] bg-white rounded-xl border border-indigo-200 shadow-2xl z-50 p-2 max-h-64 overflow-y-auto animate-in fade-in zoom-in-95 duration-150">
                        <div className="px-2.5 py-1.5 text-[10px] font-bold text-indigo-800 bg-indigo-50 rounded-lg flex items-center justify-between mb-1.5 border border-indigo-100">
                          <span>Matching Patients ({matches.length})</span>
                          <span className="text-[9px] text-indigo-600 font-semibold">Select to auto-fill</span>
                        </div>

                        {matches.length === 0 ? (
                          <div className="p-3 text-center text-xs text-slate-500">
                            No matching patient found for "{activeAppointmentModal.patientName}".
                            <p className="text-[10px] text-slate-400 mt-0.5">You can keep typing to create a new patient entry.</p>
                          </div>
                        ) : (
                          <div className="space-y-1">
                            {matches.map((p) => (
                              <button
                                key={p.id || p.patientId}
                                type="button"
                                onClick={() => {
                                  setActiveAppointmentModal((prev) => {
                                    if (!prev) return null;
                                    return {
                                      ...prev,
                                      patientName: p.name,
                                      title: p.name,
                                      dob: p.dob,
                                      age: `${p.age}`,
                                      phone: p.phone,
                                      procedure: p.procedure || prev.procedure,
                                      surgeon: p.surgeon || prev.surgeon,
                                      anesthesiologist: p.anesthesiologist || prev.anesthesiologist,
                                      anesthesiaType: p.anesthesiaType || prev.anesthesiaType,
                                      paymentType: p.paymentType || prev.paymentType || 'Self-Pay',
                                      caseId: p.id
                                    };
                                  });
                                  setPatientSearchQuery(p.name);
                                  setShowPatientSuggestions(false);
                                  showToast(`Auto-filled: ${p.name} • DOB: ${p.dob} • Age: ${p.age} • Phone: ${p.phone}`);
                                }}
                                className="w-full text-left p-2.5 hover:bg-indigo-50/90 rounded-lg transition-all cursor-pointer border border-transparent hover:border-indigo-200 group"
                              >
                                <div className="flex items-center justify-between">
                                  <div className="flex items-center gap-2">
                                    <div className="w-6 h-6 rounded-full bg-indigo-100 text-indigo-800 font-bold text-[10px] flex items-center justify-center">
                                      {p.name.split(' ').map((n) => n[0]).join('')}
                                    </div>
                                    <span className="font-bold text-xs text-slate-900 group-hover:text-indigo-950">
                                      {p.name}
                                    </span>
                                  </div>
                                  <div className="flex items-center gap-1.5">
                                    <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-slate-100 text-slate-700 group-hover:bg-indigo-100 group-hover:text-indigo-900">
                                      Age: {p.age}
                                    </span>
                                  </div>
                                </div>

                                <div className="grid grid-cols-2 gap-2 mt-1.5 text-[11px] text-slate-500 font-medium">
                                  <span className="flex items-center gap-1 text-slate-600">
                                    <Phone className="w-3 h-3 text-indigo-500 shrink-0" />
                                    {p.phone}
                                  </span>
                                  <span className="flex items-center gap-1 text-slate-600 justify-end">
                                    <CalendarIcon className="w-3 h-3 text-indigo-500 shrink-0" />
                                    DOB: {p.dob}
                                  </span>
                                </div>

                                {p.procedure && (
                                  <div className="text-[10px] text-slate-400 truncate mt-1 pt-1 border-t border-slate-100">
                                    {p.procedure}
                                  </div>
                                )}
                              </button>
                            ))}
                          </div>
                        )}
                      </div>
                    );
                  })()}
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-600 uppercase tracking-wider mb-1">
                    Date of Birth (DOB)
                  </label>
                  <input
                    type="text"
                    value={activeAppointmentModal.dob || ''}
                    onChange={(e) => handleFormChange('dob', e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs font-semibold text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all shadow-2xs"
                    placeholder="MM/DD/YYYY"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-600 uppercase tracking-wider mb-1">
                    Age
                  </label>
                  <input
                    type="text"
                    value={activeAppointmentModal.age || ''}
                    onChange={(e) => handleFormChange('age', e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs font-semibold text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all shadow-2xs"
                    placeholder="54"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-600 uppercase tracking-wider mb-1">
                    Phone Number
                  </label>
                  <input
                    type="text"
                    value={activeAppointmentModal.phone || ''}
                    onChange={(e) => handleFormChange('phone', e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs font-semibold text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all shadow-2xs"
                    placeholder="(310) 555-0100"
                  />
                </div>
              </div>

              {/* LINE 3: Full-length text field for Procedure */}
              <div>
                <label className="block text-[11px] font-bold text-slate-600 uppercase tracking-wider mb-1">
                  Procedure
                </label>
                <input
                  type="text"
                  value={activeAppointmentModal.procedure || ''}
                  onChange={(e) => handleFormChange('procedure', e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs font-semibold text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all shadow-2xs"
                  placeholder="Full procedure description"
                />
              </div>

              {/* LINE 4: Surgeon's Name, Anesthesiologist, Type of Anesthesia, Payment Type Drop-down */}
              <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
                <div>
                  <label className="block text-[11px] font-bold text-slate-600 uppercase tracking-wider mb-1">
                    Surgeon's Name
                  </label>
                  <input
                    type="text"
                    value={activeAppointmentModal.surgeon || ''}
                    onChange={(e) => handleFormChange('surgeon', e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs font-semibold text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all shadow-2xs"
                    placeholder="Dr. Surgeon Name"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-600 uppercase tracking-wider mb-1">
                    Anesthesiologist
                  </label>
                  <input
                    type="text"
                    value={activeAppointmentModal.anesthesiologist || ''}
                    onChange={(e) => handleFormChange('anesthesiologist', e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs font-semibold text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all shadow-2xs"
                    placeholder="Dr. Anesthesiologist Name"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-600 uppercase tracking-wider mb-1">
                    Type of Anesthesia
                  </label>
                  <input
                    type="text"
                    value={activeAppointmentModal.anesthesiaType || ''}
                    onChange={(e) => handleFormChange('anesthesiaType', e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs font-semibold text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all shadow-2xs"
                    placeholder="General / MAC / Local"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-indigo-900 uppercase tracking-wider mb-1 flex items-center justify-between">
                    <span>Payment Type</span>
                    <span className="text-[9px] text-indigo-700 bg-indigo-50 px-1 py-0.2 rounded font-extrabold border border-indigo-200">Required</span>
                  </label>
                  <select
                    value={activeAppointmentModal.paymentType || 'Self-Pay'}
                    onChange={(e) => handleFormChange('paymentType', e.target.value)}
                    className="w-full px-3 py-2 bg-indigo-50/50 border border-indigo-300 rounded-lg text-xs font-bold text-indigo-950 focus:outline-hidden focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all shadow-2xs cursor-pointer"
                  >
                    {!PAYMENT_TYPE_OPTIONS.includes((activeAppointmentModal.paymentType || '') as any) && activeAppointmentModal.paymentType && (
                      <option value={activeAppointmentModal.paymentType}>{activeAppointmentModal.paymentType}</option>
                    )}
                    {PAYMENT_TYPE_OPTIONS.map((opt) => (
                      <option key={opt} value={opt}>
                        {opt}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* LINE 5: Full-length box for Notes */}
              <div>
                <label className="block text-[11px] font-bold text-slate-600 uppercase tracking-wider mb-1">
                  Notes
                </label>
                <textarea
                  rows={3}
                  value={activeAppointmentModal.notes || ''}
                  onChange={(e) => handleFormChange('notes', e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs font-medium text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all resize-none shadow-2xs"
                  placeholder="Clinical notes, pre-op instructions, or patient preferences..."
                />
              </div>

              {/* LINE 6: Buttons for deleting, saving, and opening the chart */}
              <div className="pt-4 border-t border-slate-200 flex items-center justify-between gap-3">
                <button
                  type="button"
                  onClick={handleDeleteAppointment}
                  className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs rounded-xl transition-colors flex items-center gap-1.5 shadow-xs cursor-pointer"
                >
                  <Trash2 className="w-4 h-4" />
                  <span>Delete</span>
                </button>

                <div className="flex items-center gap-2.5">
                  <button
                    type="button"
                    onClick={handleOpenChartFromModal}
                    className="px-4 py-2 bg-slate-700 hover:bg-slate-800 text-white font-bold text-xs rounded-xl transition-colors flex items-center gap-1.5 shadow-xs cursor-pointer"
                  >
                    <ExternalLink className="w-4 h-4 text-slate-300" />
                    <span>Open Chart</span>
                  </button>
                  <button
                    type="button"
                    onClick={handleSaveAppointment}
                    className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl transition-colors flex items-center gap-1.5 shadow-md cursor-pointer"
                  >
                    <Save className="w-4 h-4" />
                    <span>Save</span>
                  </button>
                </div>
              </div>

            </div>

          </div>
        </div>
      )}

      {/* Delete Appointment Confirmation Modal */}
      {deleteConfirmAppointment && (
        <div className="fixed inset-0 bg-stone-900/80 backdrop-blur-xs flex items-center justify-center z-[100000] p-4 animate-in fade-in duration-150">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 border border-stone-200 shadow-2xl space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-rose-100 border border-rose-200 text-rose-600 flex items-center justify-center shrink-0">
                <Trash2 className="w-5 h-5 text-rose-600" />
              </div>
              <div>
                <h3 className="text-base font-extrabold text-stone-900">Confirm Appointment Deletion</h3>
                <p className="text-xs text-stone-500 font-medium">Please confirm before deleting this scheduled appointment.</p>
              </div>
            </div>

            <div className="p-3.5 bg-rose-50/80 border border-rose-200/90 rounded-xl space-y-1.5 text-xs text-stone-800">
              <div className="font-extrabold text-rose-950 flex items-center justify-between">
                <span>Patient Name:</span>
                <span className="text-stone-900 font-bold">{deleteConfirmAppointment.patientName}</span>
              </div>
              <div className="flex justify-between text-stone-600">
                <span>Date & Time:</span>
                <span className="font-bold text-stone-800">{deleteConfirmAppointment.dos} at {deleteConfirmAppointment.startTime}</span>
              </div>
              <div className="flex justify-between text-stone-600">
                <span>Room / Location:</span>
                <span className="font-bold text-stone-800">{deleteConfirmAppointment.room}</span>
              </div>
              <div className="flex justify-between text-stone-600">
                <span>Procedure:</span>
                <span className="font-bold text-stone-800">{deleteConfirmAppointment.procedure}</span>
              </div>
              <div className="flex justify-between text-stone-600">
                <span>Payment Type:</span>
                <span className="font-bold text-indigo-900 bg-indigo-50 px-1.5 py-0.5 rounded border border-indigo-200">{deleteConfirmAppointment.paymentType || 'Self-Pay'}</span>
              </div>
            </div>

            <p className="text-xs text-stone-500 leading-relaxed font-medium">
              ⚠️ <strong>Warning:</strong> Deleting this appointment will permanently remove it from the OR schedule and patient itinerary. This action cannot be undone.
            </p>

            <div className="pt-2 flex items-center justify-end gap-2.5">
              <button
                type="button"
                onClick={() => setDeleteConfirmAppointment(null)}
                className="px-4 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 font-bold text-xs rounded-xl border border-stone-200 transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmDeleteAppointment}
                className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs rounded-xl shadow-md transition-colors flex items-center gap-1.5 cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Confirm Delete Appointment</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Footer Copyright */}
      <div className="bg-slate-200 px-4 py-2 border-t border-slate-300 text-[10px] text-slate-600 font-medium flex items-center justify-between">
        <span>2026 © iMARSMED</span>
        <span>Vityls ASC • Version 4.8.2</span>
      </div>

      {/* Schedule Print / PDF Modal */}
      <SchedulePrintModal
        isOpen={isPrintModalOpen}
        onClose={() => setIsPrintModalOpen(false)}
        initialViewMode={viewMode}
        selectedDayIndex={selectedDayIndex}
        appointmentsList={appointmentsList}
        daysOfWeek={daysOfWeek}
        rooms={rooms}
        practiceConfig={practiceConfig}
        onShowToast={showToast}
      />

      {/* Nightingale AI Surgical Day Briefing Modal */}
      <SurgicalDayBriefingModal
        isOpen={isBriefingModalOpen}
        onClose={() => setIsBriefingModalOpen(false)}
        dateStr={daysOfWeek[selectedDayIndex]?.fullDateStr || 'Monday, July 13, 2026'}
        appointments={displayedAppointments}
      />

      {/* Block Time Reservation Modal */}
      <BlockTimeModal
        isOpen={isBlockTimeModalOpen}
        onClose={() => setIsBlockTimeModalOpen(false)}
        onSaveBlocks={handleSaveBlocks}
        daysOfWeek={daysOfWeek}
        rooms={rooms}
        initialDayIndex={selectedDayIndex}
        initialRoom="OR#1"
      />

    </div>
  );
};

