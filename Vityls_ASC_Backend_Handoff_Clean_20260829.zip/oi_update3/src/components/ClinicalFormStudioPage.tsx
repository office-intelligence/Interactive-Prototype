import React, { useEffect, useMemo, useState } from 'react';
import {
  AlertTriangle, CheckCircle2, Eye, FileCheck2, FileText, GripVertical, Layers,
  Plus, Save, ShieldCheck, Sparkles, Trash2, WandSparkles, Settings2, Building2, Database, FolderOpen, ArrowRight, Copy, History, Rocket, Archive, Pencil
} from 'lucide-react';

import {
  createLocalPractice, deletePracticeForm, listLocalPractices, listPracticeForms,
  saveDraftForm, publishPracticeForm, retirePracticeForm,
  type LocalPractice, type LocalFormTemplate, type FormLifecycleStatus,
} from '../utils/localFormStudioDb';
import { ASC_DEFAULT_FORM_LIBRARY, type AscDefaultFormTemplate } from '../data/ascDefaultFormLibrary';

type FieldType = 'text' | 'textarea' | 'checkbox' | 'radio' | 'select' | 'date' | 'signature' | 'clinical-list' | 'score';
type SpecialtyProfile = 'Multispecialty Core' | 'Plastic Surgery' | 'Orthopedics' | 'Ophthalmology';
type CollectionStage = 'Home / Patient Portal' | 'Front Desk' | 'Nursing' | 'Anesthesia' | 'Surgeon' | 'OR Team' | 'PACU';

interface BuilderField {
  id: string;
  label: string;
  type: FieldType;
  required: boolean;
  owner: string;
  options?: string[];
  source?: 'Patient' | 'Chart' | 'Nursing' | 'Provider';
}

const CORE_FIELDS: BuilderField[] = [
  { id: 'identity', label: 'Patient / procedure / surgeon / date of service', type: 'text', required: true, owner: 'Front Desk', source: 'Chart' },
  { id: 'history', label: 'Current history / interval change review', type: 'textarea', required: true, owner: 'Nursing + Provider', source: 'Chart' },
  { id: 'allergies', label: 'Allergies — carried forward; verify/update', type: 'clinical-list', required: true, owner: 'Nursing', source: 'Chart' },
  { id: 'meds', label: 'Active medications — carried forward; verify/update', type: 'clinical-list', required: true, owner: 'Nursing', source: 'Chart' },
  { id: 'npo', label: 'NPO status', type: 'radio', required: true, owner: 'Nursing', source: 'Patient', options: ['Confirmed', 'Not confirmed', 'Exception — explain'] },
  { id: 'ride', label: 'Responsible adult / transportation', type: 'radio', required: true, owner: 'Front Desk + Nursing', source: 'Patient', options: ['Confirmed', 'Not confirmed', 'Not applicable'] },
  { id: 'clearance', label: 'Medical clearance / H&P source reviewed', type: 'checkbox', required: true, owner: 'Nursing + Provider', source: 'Chart', options: ['Reviewed and available'] },
  { id: 'vte', label: 'VTE risk assessment and prophylaxis plan', type: 'score', required: true, owner: 'Nursing + Surgeon', source: 'Provider' },
  { id: 'consent', label: 'Procedure consent — procedure + named surgeon', type: 'signature', required: true, owner: 'Patient + Surgeon', source: 'Provider' },
  { id: 'anesthesiaConsent', label: 'Anesthesia / sedation consent', type: 'signature', required: true, owner: 'Patient + Anesthesia', source: 'Provider' },
  { id: 'timeout', label: 'Time-out verification', type: 'checkbox', required: true, owner: 'OR Team', source: 'Provider', options: ['Patient', 'Procedure', 'Site/laterality', 'Implants/equipment'] },
];

const SPECIALTY_FIELDS: Record<Exclude<SpecialtyProfile, 'Multispecialty Core'>, BuilderField[]> = {
  'Plastic Surgery': [
    { id: 'lipoAreas', label: 'Liposuction treatment areas / aspirate totals', type: 'clinical-list', required: false, owner: 'Surgeon + Nursing', source: 'Provider' },
    { id: 'implantsPlastic', label: 'Implant / device / lot information when used', type: 'clinical-list', required: false, owner: 'OR Team', source: 'Provider' },
  ],
  Orthopedics: [
    { id: 'lateralityOrtho', label: 'Operative extremity / laterality', type: 'radio', required: true, owner: 'Surgeon + OR Team', source: 'Provider', options: ['Left', 'Right', 'Bilateral', 'Not applicable'] },
    { id: 'implantsOrtho', label: 'Implant manufacturer / catalog / lot / serial', type: 'clinical-list', required: true, owner: 'Circulating Nurse', source: 'Provider' },
  ],
  Ophthalmology: [
    { id: 'eyeLaterality', label: 'Eye laterality', type: 'radio', required: true, owner: 'Surgeon + OR Team', source: 'Provider', options: ['Left eye', 'Right eye', 'Bilateral'] },
    { id: 'iol', label: 'IOL model / power / serial number', type: 'clinical-list', required: true, owner: 'Circulating Nurse', source: 'Provider' },
  ],
};

const REFERENCE_FORMS = [
  { group: 'Patient Intake', count: 10, examples: 'Admission Form · General Medical History · Anesthesia Questionnaire · MH & VTE Assessment · Procedure Consent', use: 'Home collection + Front Desk verification' },
  { group: 'Nursing', count: 9, examples: 'Pre-Operative Checklist · Peri-Operative Assessment · Surgical Checklist · Recovery Room Record · Post-Op Instructions', use: 'Nursing / OR / PACU gates' },
  { group: 'Doctor Notes', count: 4, examples: 'History & Physical · Progress Note · SOAP Note · Local Anesthesia Injection', use: 'Provider documentation' },
];


const PREBUILT_FORM_TEMPLATES: { title: string; group: string; collectionStage: CollectionStage; reviewStages: CollectionStage[]; fields: BuilderField[] }[] = [
  { title: 'Admission Form', group: 'Patient Intake', collectionStage: 'Home / Patient Portal', reviewStages: ['Front Desk','Nursing'], fields: [
    { id:'adm-name', label:'Patient demographics / contact information', type:'text', required:true, owner:'Patient + Front Desk', source:'Patient' },
    { id:'adm-ride', label:'Responsible adult / transportation', type:'radio', required:true, owner:'Patient + Front Desk', source:'Patient', options:['Confirmed','Not yet arranged','Not applicable'] },
    { id:'adm-sign', label:'Patient acknowledgement', type:'signature', required:true, owner:'Patient', source:'Patient' },
  ]},
  { title: 'General Medical History', group: 'Patient Intake', collectionStage: 'Home / Patient Portal', reviewStages: ['Front Desk','Nursing','Anesthesia'], fields: [
    { id:'gmh-history', label:'Medical conditions / history', type:'checkbox', required:true, owner:'Patient + Nursing', source:'Patient', options:['Hypertension','Diabetes','Heart disease','Asthma / COPD','Sleep apnea','Kidney disease','Thyroid disease','None reported'] },
    { id:'gmh-allergy', label:'Allergies — shared chart record', type:'clinical-list', required:true, owner:'Patient + Nursing', source:'Chart' },
    { id:'gmh-meds', label:'Medications — shared chart record', type:'clinical-list', required:true, owner:'Patient + Nursing', source:'Chart' },
  ]},
  { title: 'Anesthesia Questionnaire', group: 'Patient Intake', collectionStage: 'Home / Patient Portal', reviewStages: ['Nursing','Anesthesia'], fields: [
    { id:'aq-ga', label:'Prior general anesthesia', type:'radio', required:true, owner:'Patient + Anesthesia', source:'Patient', options:['Yes','No','Unsure'] },
    { id:'aq-povn', label:'Prior nausea/vomiting after anesthesia', type:'radio', required:true, owner:'Patient + Anesthesia', source:'Patient', options:['Yes','No','Unsure'] },
    { id:'aq-notes', label:'Anesthesia concerns / explanation', type:'textarea', required:false, owner:'Patient + Anesthesia', source:'Patient' },
  ]},
  { title: 'MH & VTE Assessment', group: 'Patient Intake', collectionStage: 'Home / Patient Portal', reviewStages: ['Nursing','Surgeon'], fields: [
    { id:'vte-risk', label:'VTE risk factors', type:'checkbox', required:true, owner:'Patient + Nursing', source:'Patient', options:['Age-related risk','BMI / obesity risk','Prior VTE','Family history of VTE','Hormone therapy','Cancer history','Reduced mobility','Other'] },
    { id:'vte-score', label:'VTE risk score / assessment', type:'score', required:true, owner:'Nursing + Surgeon', source:'Provider' },
  ]},
  { title: 'Pre-Operative Checklist and Assessment', group: 'Nursing', collectionStage: 'Nursing', reviewStages: ['Anesthesia','Surgeon'], fields: CORE_FIELDS },
  { title: 'Peri-Operative Nursing Assessment', group: 'Nursing', collectionStage: 'Nursing', reviewStages: ['OR Team','PACU'], fields: [
    { id:'peri-site', label:'Procedure / site / laterality verified', type:'checkbox', required:true, owner:'Nursing + OR Team', source:'Provider', options:['Patient identity','Procedure','Site / laterality','Consent matches schedule'] },
    { id:'peri-handoff', label:'OR handoff notes', type:'textarea', required:true, owner:'Nursing', source:'Nursing' },
  ]},
  { title: 'Recovery Room Record', group: 'Nursing', collectionStage: 'PACU', reviewStages: [], fields: [
    { id:'pacu-status', label:'PACU recovery status', type:'select', required:true, owner:'PACU Nursing', source:'Nursing', options:['Stable','Needs continued monitoring','Escalated to provider'] },
    { id:'pacu-discharge', label:'Discharge criteria / authorization', type:'signature', required:true, owner:'PACU + Provider', source:'Provider' },
  ]},
  { title: 'Procedure Consent', group: 'Patient Intake', collectionStage: 'Home / Patient Portal', reviewStages: ['Nursing','Surgeon'], fields: [
    { id:'consent-proc', label:'Planned procedure', type:'text', required:true, owner:'Patient + Surgeon', source:'Chart' },
    { id:'consent-patient', label:'Patient signature', type:'signature', required:true, owner:'Patient', source:'Patient' },
    { id:'consent-surgeon', label:'Surgeon authentication', type:'signature', required:true, owner:'Surgeon', source:'Provider' },
  ]},
  { title: 'History & Physical', group: 'Doctor Notes', collectionStage: 'Surgeon', reviewStages: ['Nursing','Anesthesia'], fields: [
    { id:'hp-history', label:'History / interval changes', type:'textarea', required:true, owner:'Surgeon', source:'Provider' },
    { id:'hp-exam', label:'Focused physical examination', type:'textarea', required:true, owner:'Surgeon', source:'Provider' },
    { id:'hp-sign', label:'Provider signature', type:'signature', required:true, owner:'Surgeon', source:'Provider' },
  ]},
  { title: 'Brief Operative Report', group: 'Nursing', collectionStage: 'Surgeon', reviewStages: ['PACU'], fields: [
    { id:'op-proc', label:'Procedure performed', type:'text', required:true, owner:'Surgeon', source:'Provider' },
    { id:'op-findings', label:'Findings / complications / disposition', type:'textarea', required:true, owner:'Surgeon', source:'Provider' },
    { id:'op-sign', label:'Surgeon signature', type:'signature', required:true, owner:'Surgeon', source:'Provider' },
  ]},
];

const COVERAGE = [
  { area: 'Patient intake + medical history', status: 'covered', note: 'Your uploaded Admission, General Medical History, Anesthesia Questionnaire and MH/VTE forms provide a strong intake foundation.' },
  { area: 'Checkbox / radio option sets', status: 'covered', note: 'Existing forms already contain many mature Yes/No and multi-option sets. These should be importable into reusable option libraries.' },
  { area: 'Allergies + medications', status: 'covered', note: 'Convert repeated questions into shared chart fields. Each gate verifies or updates instead of re-entering.' },
  { area: 'Pre-op / peri-op nursing', status: 'covered', note: 'Your nursing forms cover the major workflow areas and can become schema templates assigned to Nursing/OR gates.' },
  { area: 'VTE risk assessment', status: 'covered', note: 'The uploaded MH & VTE Assessment includes scored checkbox logic. Preserve the scoring model as a reusable structured component.' },
  { area: 'Consents / signatures', status: 'partial', note: 'Consent forms are present; move typed signature placeholders to captured signature + signer identity + date/time + role authentication.' },
  { area: 'Anesthesia record', status: 'partial', note: 'Anesthesia forms exist, but the production engine should support serial intra-op medications, fluids, vitals and events.' },
  { area: 'Final case record PDFs', status: 'partial', note: 'Each completed form should render to a locked PDF and retain links to source data and original uploaded records.' },
];

const isChoiceType = (type: FieldType) => ['checkbox', 'radio', 'select'].includes(type);

export const ClinicalFormStudioPage: React.FC<{
  onShowToast?: (msg: string) => void;
  onOpenPracticeDashboard?: (practice: LocalPractice) => void;
}> = ({ onShowToast, onOpenPracticeDashboard }) => {
  const [profile, setProfile] = useState<SpecialtyProfile>('Multispecialty Core');
  const [fields, setFields] = useState<BuilderField[]>(CORE_FIELDS);
  const [preview, setPreview] = useState(false);
  const [title, setTitle] = useState('Pre-Operative Assessment & Readiness');
  const [version, setVersion] = useState('v1.0');
  const [collectionStage, setCollectionStage] = useState<CollectionStage>('Nursing');
  const [reviewStages, setReviewStages] = useState<CollectionStage[]>(['Anesthesia', 'Surgeon']);
  const [practices, setPractices] = useState<LocalPractice[]>([]);
  const [activePracticeId, setActivePracticeId] = useState('');
  const [practiceForms, setPracticeForms] = useState<LocalFormTemplate[]>([]);
  const [newPracticeName, setNewPracticeName] = useState('New Test Practice');
  const [currentFormId, setCurrentFormId] = useState<string | null>(null);
  const [currentTemplateId, setCurrentTemplateId] = useState<string>(`template-${Date.now()}`);
  const [currentStatus, setCurrentStatus] = useState<FormLifecycleStatus>('Draft');
  const [basedOnId, setBasedOnId] = useState<string | undefined>(undefined);
  const [sourceTemplate, setSourceTemplate] = useState<string | undefined>(undefined);
  const [sourceFile, setSourceFile] = useState<string | undefined>(undefined);
  const [showVersionHistory, setShowVersionHistory] = useState(true);
  const [libraryQuery, setLibraryQuery] = useState('');


  const refreshPractices = async (selectId?: string) => {
    const rows = await listLocalPractices();
    setPractices(rows);
    const target = selectId || activePracticeId || rows[0]?.id || '';
    if (target) setActivePracticeId(target);
  };

  const refreshForms = async (practiceId: string) => {
    if (!practiceId) { setPracticeForms([]); return; }
    setPracticeForms(await listPracticeForms(practiceId));
  };

  useEffect(() => { refreshPractices().catch(() => onShowToast?.('Local Form Studio database could not be opened in this browser.')); }, []);
  useEffect(() => { refreshForms(activePracticeId).catch(() => undefined); }, [activePracticeId]);

  const createEmptyPractice = async () => {
    const practice = await createLocalPractice(newPracticeName);
    await refreshPractices(practice.id);
    setActivePracticeId(practice.id);
    setPracticeForms([]);
    setCurrentFormId(null);
    setCurrentTemplateId(`template-${Date.now()}-${Math.random().toString(36).slice(2,6)}`);
    setCurrentStatus('Draft');
    setBasedOnId(undefined);
    setSourceTemplate(undefined);
    setSourceFile(undefined);
    setTitle('Untitled Form');
    setVersion('v1.0');
    setProfile('Multispecialty Core');
    setCollectionStage('Home / Patient Portal');
    setReviewStages(['Front Desk']);
    setFields([]);
    onShowToast?.(`Created empty practice: ${practice.name}. No forms were installed.`);
    onOpenPracticeDashboard?.(practice);
  };

  const newBlankForm = () => {
    setCurrentFormId(null);
    setCurrentTemplateId(`template-${Date.now()}-${Math.random().toString(36).slice(2,6)}`);
    setCurrentStatus('Draft');
    setBasedOnId(undefined);
    setSourceTemplate(undefined);
    setSourceFile(undefined);
    setTitle('Untitled Form');
    setVersion('v1.0');
    setFields([]);
    setCollectionStage('Home / Patient Portal');
    setReviewStages(['Front Desk']);
    setPreview(false);
    onShowToast?.('Blank draft started. Nothing becomes active until you publish it.');
  };

  const nextVersionNumber = (value: string) => {
    const parts = value.replace(/^v/i, '').split('.').map(Number);
    return `v${Number.isFinite(parts[0]) ? parts[0] : 1}.${(Number.isFinite(parts[1]) ? parts[1] : 0) + 1}`;
  };

  const loadLocalForm = (form: LocalFormTemplate) => {
    setCurrentFormId(form.id);
    setCurrentTemplateId(form.templateId || `legacy-${form.practiceId}-${form.title.toLowerCase().replace(/[^a-z0-9]+/g,'-')}`);
    setCurrentStatus(form.status || 'Active');
    setBasedOnId(form.basedOnId);
    setSourceTemplate(form.sourceTemplate);
    setSourceFile(form.sourceFile);
    setTitle(form.title);
    setVersion(form.version);
    setProfile(form.profile as SpecialtyProfile);
    setCollectionStage(form.collectionStage as CollectionStage);
    setReviewStages(form.reviewStages as CollectionStage[]);
    setFields(form.fields as BuilderField[]);
    setPreview(false);
    onShowToast?.(`Opened ${form.title} ${form.version} (${form.status || 'legacy active'}).`);
  };

  const createRevision = (form: LocalFormTemplate) => {
    setCurrentFormId(null);
    setCurrentTemplateId(form.templateId || `legacy-${form.practiceId}-${form.title.toLowerCase().replace(/[^a-z0-9]+/g,'-')}`);
    setCurrentStatus('Draft');
    setBasedOnId(form.id);
    setSourceTemplate(form.sourceTemplate);
    setSourceFile(form.sourceFile);
    setTitle(form.title);
    setVersion(nextVersionNumber(form.version));
    setProfile(form.profile as SpecialtyProfile);
    setCollectionStage(form.collectionStage as CollectionStage);
    setReviewStages(form.reviewStages as CollectionStage[]);
    setFields((form.fields as BuilderField[]).map(f => ({...f, options: f.options ? [...f.options] : undefined})));
    setPreview(false);
    onShowToast?.(`Created draft revision ${nextVersionNumber(form.version)} from active ${form.version}. The active version remains in use until Publish.`);
  };
  const requiredCount = useMemo(() => fields.filter(f => f.required).length, [fields]);

  const applyProfile = (next: SpecialtyProfile) => {
    setProfile(next);
    const extras = next === 'Multispecialty Core' ? [] : SPECIALTY_FIELDS[next];
    setFields([...CORE_FIELDS, ...extras]);
    onShowToast?.(`Applied ${next} profile — ${CORE_FIELDS.length + extras.length} fields loaded.`);
  };

  const addField = () => setFields(prev => [...prev, {
    id: `custom-${Date.now()}`, label: 'New custom field', type: 'text', required: false, owner: 'Practice-defined', source: 'Patient'
  }]);

  const updateField = (id: string, patch: Partial<BuilderField>) => setFields(prev => prev.map(f => f.id === id ? { ...f, ...patch } : f));
  const addChoiceOption = (id: string) => setFields(prev => prev.map(f => f.id === id ? { ...f, options: [...(f.options || []), `Option ${(f.options?.length || 0) + 1}`] } : f));
  const updateChoiceOption = (id: string, index: number, value: string) => setFields(prev => prev.map(f => {
    if (f.id !== id) return f;
    const options = [...(f.options || [])];
    options[index] = value;
    return { ...f, options };
  }));
  const removeChoiceOption = (id: string, index: number) => setFields(prev => prev.map(f => f.id === id ? { ...f, options: (f.options || []).filter((_, i) => i !== index) } : f));

  const toggleReviewStage = (stage: CollectionStage) => setReviewStages(prev => prev.includes(stage) ? prev.filter(s => s !== stage) : [...prev, stage]);

  const installPrebuiltTemplate = (template: typeof PREBUILT_FORM_TEMPLATES[number]) => {
    setCurrentFormId(null);
    setTitle(template.title);
    setVersion('v1.0');
    setProfile('Multispecialty Core');
    setCollectionStage(template.collectionStage);
    setReviewStages(template.reviewStages);
    setFields(template.fields.map(f => ({ ...f, options: f.options ? [...f.options] : undefined })));
    setPreview(false);
    onShowToast?.(`Loaded editable starter: ${template.title}. Modify any field, choices, gates, or signatures, then save it to this practice.`);
  };

  const loadAscDefaultTemplate = (template: AscDefaultFormTemplate) => {
    setCurrentFormId(null);
    setCurrentTemplateId(`asc-${template.sourceFile.toLowerCase().replace(/[^a-z0-9]+/g,'-')}-${Date.now()}`);
    setCurrentStatus('Draft');
    setBasedOnId(undefined);
    setSourceTemplate('Office Intelligence ASC Default Library');
    setSourceFile(template.sourceFile);
    setTitle(template.title);
    setVersion('v1.0');
    setProfile('Multispecialty Core');
    setCollectionStage(template.collectionStage as CollectionStage);
    setReviewStages(template.reviewStages as CollectionStage[]);
    setFields(template.fields.map(f => ({ ...f, owner: f.owner || 'Practice-defined', options: f.options ? [...f.options] : undefined })) as BuilderField[]);
    setPreview(false);
    onShowToast?.(`Loaded ${template.title} from the official ASC default library: ${template.fields.length} editable fields, ${template.signatureZones} standardized signature zone${template.signatureZones===1?'':'s'}.`);
  };

  const formPayload = (): LocalFormTemplate => ({
    id: currentFormId || '',
    templateId: currentTemplateId,
    practiceId: activePracticeId,
    title,
    version,
    profile,
    collectionStage,
    reviewStages,
    fields,
    updatedAt: new Date().toISOString(),
    status: currentStatus,
    basedOnId,
    sourceTemplate,
    sourceFile,
  });

  const saveDraft = async () => {
    if (!activePracticeId) { onShowToast?.('Select a practice before saving.'); return; }
    const payload = formPayload();
    if (currentStatus !== 'Draft') {
      payload.id = '';
      payload.version = nextVersionNumber(version);
      payload.basedOnId = currentFormId || undefined;
    }
    const saved = await saveDraftForm(payload);
    setCurrentFormId(saved.id);
    setCurrentTemplateId(saved.templateId || currentTemplateId);
    setCurrentStatus('Draft');
    setVersion(saved.version);
    await refreshForms(activePracticeId);
    onShowToast?.(`Draft saved: ${saved.title} ${saved.version}. The current active version has not changed.`);
  };

  const publishVersion = async () => {
    if (!activePracticeId) { onShowToast?.('Select a practice before publishing.'); return; }
    const payload = formPayload();
    // Never overwrite an Active/Superseded historical version in place.
    // Publishing from anything other than a Draft creates a new version row.
    if (currentStatus !== 'Draft') {
      payload.id = '';
      payload.version = nextVersionNumber(version);
      payload.basedOnId = currentFormId || undefined;
      payload.status = 'Draft';
    }
    const published = await publishPracticeForm(payload);
    setCurrentFormId(published.id);
    setCurrentTemplateId(published.templateId || currentTemplateId);
    setCurrentStatus('Active');
    setVersion(published.version);
    setBasedOnId(published.basedOnId);
    await refreshForms(activePracticeId);
    onShowToast?.(`Published ${published.title} ${published.version}. Any prior active version is now Superseded and remains available in Version History.`);
  };

  const saveVersion = publishVersion;

  const visibleAscTemplates = ASC_DEFAULT_FORM_LIBRARY.filter(template =>
    !libraryQuery.trim() ||
    `${template.title} ${template.group} ${template.collectionStage}`.toLowerCase().includes(libraryQuery.toLowerCase())
  );

  const statusClass = (status?: FormLifecycleStatus) =>
    status === 'Active' ? 'bg-emerald-100 text-emerald-800 border-emerald-200' :
    status === 'Draft' ? 'bg-sky-100 text-sky-800 border-sky-200' :
    status === 'Superseded' ? 'bg-stone-100 text-stone-600 border-stone-200' :
    status === 'Retired' ? 'bg-rose-100 text-rose-700 border-rose-200' :
    'bg-amber-100 text-amber-800 border-amber-200';

  return <div className="space-y-6">
    <section className="bg-white rounded-2xl border border-emerald-200 shadow-2xs p-5 sm:p-6 space-y-4">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div><div className="flex items-center gap-2"><Database className="w-5 h-5 text-emerald-700"/><h2 className="text-base font-black text-stone-900">Local Form Studio Test Database</h2></div><p className="text-xs text-stone-500 mt-1">Browser IndexedDB only — no API or production database required. Create an empty practice, build forms, assign gates, refresh the browser, and continue testing.</p></div>
        <span className="text-[10px] font-black uppercase tracking-wide px-2 py-1 rounded-full bg-emerald-100 text-emerald-800 border border-emerald-200">Local sandbox</span>
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-[1fr_1fr_auto] gap-2 items-end">
        <label className="space-y-1"><span className="text-[10px] font-black text-stone-500 uppercase">Active practice</span><select value={activePracticeId} onChange={e => setActivePracticeId(e.target.value)} className="w-full px-3 py-2 rounded-xl border border-stone-200 bg-white text-xs"><option value="">No local practice selected</option>{practices.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}</select></label>
        <label className="space-y-1"><span className="text-[10px] font-black text-stone-500 uppercase">Create empty practice</span><input value={newPracticeName} onChange={e=>setNewPracticeName(e.target.value)} className="w-full px-3 py-2 rounded-xl border border-stone-200 text-xs"/></label>
        <button onClick={() => createEmptyPractice().catch(() => onShowToast?.('Could not create local practice.'))} className="px-4 py-2 rounded-xl bg-slate-900 text-white text-xs font-black flex items-center gap-2 cursor-pointer"><Building2 className="w-4 h-4"/>Create Empty Practice</button>
      </div>
      {activePracticeId && <div className="flex justify-end"><button type="button" onClick={()=>{const practice=practices.find(p=>p.id===activePracticeId); if(practice) onOpenPracticeDashboard?.(practice);}} className="px-4 py-2 rounded-xl bg-emerald-700 text-white text-xs font-black flex items-center gap-2"><ArrowRight className="w-4 h-4"/>Open Practice Dashboard</button></div>}
      <div className="rounded-xl border border-stone-200 bg-stone-50/70 p-3">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div>
            <div className="text-xs font-black text-stone-800">Practice form lifecycle <span className="text-stone-400">({practiceForms.length} versions)</span></div>
            <div className="text-[10px] text-stone-500 mt-0.5">Only versions marked Active are used for new encounters. Drafts are safe to edit; Superseded versions remain available for historical records.</div>
          </div>
          <div className="flex items-center gap-2">
            <button onClick={()=>setShowVersionHistory(!showVersionHistory)} className="px-3 py-1.5 rounded-lg border border-stone-300 bg-white text-stone-700 text-[11px] font-bold flex items-center gap-1.5"><History className="w-3.5 h-3.5"/>{showVersionHistory?'Hide History':'Show History'}</button>
            <button onClick={newBlankForm} disabled={!activePracticeId} className="px-3 py-1.5 rounded-lg bg-emerald-700 disabled:bg-stone-300 text-white text-[11px] font-bold flex items-center gap-1.5 cursor-pointer"><Plus className="w-3.5 h-3.5"/>New Blank Form</button>
          </div>
        </div>
        {activePracticeId && practiceForms.length === 0 ? (
          <div className="mt-3 rounded-lg border border-dashed border-stone-300 bg-white p-4 text-center text-xs text-stone-500">This practice has no forms yet. Choose an ASC default below or create a blank form.</div>
        ) : (
          <div className="mt-3 grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-2">
            {practiceForms.filter(f=>showVersionHistory || f.status==='Active' || !f.status).map(f => (
              <div key={f.id} className={`rounded-xl border bg-white p-3 ${f.status==='Active'?'border-emerald-300':'border-stone-200'}`}>
                <div className="flex items-start justify-between gap-2">
                  <div className="font-black text-xs text-stone-900">{f.title}</div>
                  <span className={`px-2 py-0.5 rounded-full border text-[9px] font-black uppercase ${statusClass(f.status)}`}>{f.status || 'Legacy'}</span>
                </div>
                <div className="text-[10px] text-stone-500 mt-1">{f.version} · Collect: {f.collectionStage}</div>
                <div className="text-[9.5px] text-stone-400 mt-1">{(f.fields as any[])?.length || 0} fields{f.sourceFile ? ` · ${f.sourceFile}` : ''}</div>
                <div className="flex flex-wrap gap-x-3 gap-y-1 mt-2">
                  {f.status === 'Active' ? <button onClick={()=>createRevision(f)} className="text-[10px] font-bold text-emerald-700 flex items-center gap-1"><Pencil className="w-3 h-3"/>Create revision</button> : <button onClick={()=>loadLocalForm(f)} className="text-[10px] font-bold text-emerald-700 flex items-center gap-1"><FolderOpen className="w-3 h-3"/>Open</button>}
                  {f.status === 'Active' && <button onClick={()=>loadLocalForm(f)} className="text-[10px] font-bold text-stone-600 flex items-center gap-1"><Eye className="w-3 h-3"/>View active</button>}
                  {(f.status === 'Active' || f.status === 'Draft') && <button onClick={async()=>{await retirePracticeForm(f.id);await refreshForms(activePracticeId);}} className="text-[10px] font-bold text-rose-600 flex items-center gap-1"><Archive className="w-3 h-3"/>Retire</button>}
                  {f.status === 'Draft' && <button onClick={async()=>{await deletePracticeForm(f.id);await refreshForms(activePracticeId);}} className="text-[10px] font-bold text-rose-600 flex items-center gap-1"><Trash2 className="w-3 h-3"/>Delete draft</button>}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </section>

    <section className="bg-white rounded-2xl border border-stone-200 shadow-2xs overflow-hidden">
      <div className="p-5 sm:p-6 bg-gradient-to-r from-slate-950 to-emerald-950 text-white flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-emerald-300 text-[10px] font-black uppercase tracking-[0.18em]"><Sparkles className="w-3.5 h-3.5"/> Nightingale Form Intelligence</div>
          <h2 className="text-xl font-black mt-1">Clinical Form Studio</h2>
          <p className="text-xs text-slate-300 mt-1 max-w-2xl">One engine for patient intake, front-desk verification, Nursing, Anesthesia, Surgeon, OR and PACU documentation.</p>
        </div>
        <div className="flex gap-2">
          <button onClick={() => setPreview(!preview)} className="px-3 py-2 rounded-xl bg-white/10 border border-white/20 text-xs font-bold flex items-center gap-1.5 cursor-pointer"><Eye className="w-4 h-4"/>{preview ? 'Edit Builder' : 'Preview Form'}</button>
          <button onClick={saveDraft} className="px-3 py-2 rounded-xl bg-white/10 border border-white/20 text-white text-xs font-black flex items-center gap-1.5 cursor-pointer"><Save className="w-4 h-4"/>Save Draft</button>
          <button onClick={publishVersion} className="px-3 py-2 rounded-xl bg-emerald-400 hover:bg-emerald-300 text-slate-950 text-xs font-black flex items-center gap-1.5 cursor-pointer"><Rocket className="w-4 h-4"/>Publish Version</button>
        </div>
      </div>

      <div className="p-5 sm:p-6 space-y-5">
        <div className="grid grid-cols-1 xl:grid-cols-[1.1fr_1fr] gap-4">
          <div className="rounded-2xl border border-stone-200 p-4 space-y-3">
            <div className="flex items-center gap-2"><Settings2 className="w-4 h-4 text-emerald-700"/><h3 className="text-sm font-black text-stone-900">Form identity & customization</h3></div><div className="flex flex-wrap items-center gap-2"><span className={`px-2 py-1 rounded-full border text-[9px] font-black uppercase ${statusClass(currentStatus)}`}>{currentStatus}</span><span className="text-[10px] text-stone-500">Template ID: {currentTemplateId.slice(0,32)}{basedOnId ? ` · Revision of ${basedOnId.slice(0,18)}` : ''}</span></div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <label className="space-y-1"><span className="text-[11px] font-bold text-stone-600">Form title</span><input value={title} onChange={e => setTitle(e.target.value)} className="w-full px-3 py-2 rounded-xl border border-stone-300 text-xs"/></label>
              <label className="space-y-1"><span className="text-[11px] font-bold text-stone-600">Practice / specialty profile</span><select value={profile} onChange={e => applyProfile(e.target.value as SpecialtyProfile)} className="w-full px-3 py-2 rounded-xl border border-stone-300 text-xs bg-white"><option>Multispecialty Core</option><option>Plastic Surgery</option><option>Orthopedics</option><option>Ophthalmology</option></select></label>
              <label className="space-y-1"><span className="text-[11px] font-bold text-stone-600">Collect / complete first at</span><select value={collectionStage} onChange={e => setCollectionStage(e.target.value as CollectionStage)} className="w-full px-3 py-2 rounded-xl border border-stone-300 text-xs bg-white"><option>Home / Patient Portal</option><option>Front Desk</option><option>Nursing</option><option>Anesthesia</option><option>Surgeon</option><option>OR Team</option><option>PACU</option></select></label>
              <div className="space-y-1"><span className="text-[11px] font-bold text-stone-600">Verify / review at later gates</span><div className="flex flex-wrap gap-1.5">{(['Front Desk','Nursing','Anesthesia','Surgeon','OR Team','PACU'] as CollectionStage[]).map(stage => <button key={stage} onClick={() => toggleReviewStage(stage)} className={`px-2 py-1 rounded-lg border text-[10px] font-bold cursor-pointer ${reviewStages.includes(stage) ? 'bg-emerald-100 text-emerald-900 border-emerald-300' : 'bg-white text-stone-500 border-stone-200'}`}>{stage}</button>)}</div></div>
            </div>
            <div className="flex flex-wrap gap-2 text-[10.5px]"><span className="px-2 py-1 rounded-full bg-slate-100 border border-slate-200 font-bold">{version}</span><span className="px-2 py-1 rounded-full bg-emerald-100 border border-emerald-200 text-emerald-800 font-bold">{fields.length} fields</span><span className="px-2 py-1 rounded-full bg-amber-100 border border-amber-200 text-amber-800 font-bold">{requiredCount} required</span><span className="px-2 py-1 rounded-full bg-indigo-100 border border-indigo-200 text-indigo-800 font-bold">Final output: PDF</span></div>
          </div>

          <div className="rounded-2xl border border-cyan-200 bg-cyan-50/60 p-4">
            <div className="flex items-center gap-2 text-cyan-950 font-black text-sm"><WandSparkles className="w-4 h-4"/>Nightingale design checks</div>
            <div className="mt-3 space-y-2 text-[11px] text-cyan-950">
              <div className="flex gap-2"><CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0"/>Home + Front Desk assignment automatically makes this an intake workflow: patient completes it at home and Front Desk verifies changes on arrival.</div>
              <div className="flex gap-2"><CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0"/>Choice fields keep their option sets inside the form schema and can later use reusable standard option libraries.</div>
              <div className="flex gap-2"><CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0"/>Allergies + medications remain linked to shared chart data across gates.</div>
              <div className="flex gap-2"><AlertTriangle className="w-3.5 h-3.5 text-amber-600 shrink-0"/>AI may suggest changes; publishing a clinical form/version still requires administrator approval.</div>
            </div>
          </div>
        </div>

        {!preview ? <div className="rounded-2xl border border-stone-200 overflow-hidden">
          <div className="px-4 py-3 bg-stone-50 border-b border-stone-200 flex items-center justify-between"><div className="font-black text-sm text-stone-900">Form schema & choice options</div><button onClick={addField} className="px-3 py-1.5 rounded-lg bg-stone-900 text-white text-[11px] font-bold flex items-center gap-1 cursor-pointer"><Plus className="w-3.5 h-3.5"/>Add Field</button></div>
          <div className="divide-y divide-stone-100">{fields.map(field => <div key={field.id} className="p-3 space-y-2">
            <div className="grid grid-cols-[20px_1fr] lg:grid-cols-[20px_2fr_1fr_1fr_auto] gap-3 items-center">
              <GripVertical className="w-4 h-4 text-stone-300"/>
              <input value={field.label} onChange={e => updateField(field.id,{label:e.target.value})} className="px-2.5 py-2 rounded-lg border border-stone-200 text-xs font-semibold"/>
              <select value={field.type} onChange={e => updateField(field.id,{type:e.target.value as FieldType, options:isChoiceType(e.target.value as FieldType) ? (field.options?.length ? field.options : ['Yes','No']) : undefined})} className="px-2 py-2 rounded-lg border border-stone-200 bg-white text-[11px]"><option>text</option><option>textarea</option><option>checkbox</option><option>radio</option><option>select</option><option>date</option><option>signature</option><option>clinical-list</option><option>score</option></select>
              <input value={field.owner} onChange={e => updateField(field.id,{owner:e.target.value})} className="px-2.5 py-2 rounded-lg border border-stone-200 text-[11px]"/>
              <div className="flex items-center gap-2"><label className="flex items-center gap-1 text-[10px] font-bold text-stone-600"><input type="checkbox" checked={field.required} onChange={e => updateField(field.id,{required:e.target.checked})}/>Required</label><button onClick={() => setFields(prev => prev.filter(f => f.id !== field.id))} className="p-1.5 text-stone-400 hover:text-rose-600 cursor-pointer"><Trash2 className="w-3.5 h-3.5"/></button></div>
            </div>
            {isChoiceType(field.type) && <div className="ml-8 rounded-xl bg-stone-50 border border-stone-200 p-2.5">
              <div className="flex items-center justify-between gap-2 mb-2"><div className="text-[10px] font-black text-stone-600">Choice options</div><button type="button" onClick={()=>addChoiceOption(field.id)} className="px-2 py-1 rounded-lg bg-emerald-700 text-white text-[10px] font-bold flex items-center gap-1"><Plus className="w-3 h-3"/>Add option</button></div>
              <div className="space-y-1.5">{(field.options || []).map((opt, index)=><div key={`${field.id}-${index}`} className="flex items-center gap-2"><span className="w-5 text-[9px] text-stone-400 font-bold">{index+1}</span><input value={opt} onChange={e=>updateChoiceOption(field.id,index,e.target.value)} className="flex-1 px-2.5 py-2 rounded-lg border border-stone-200 bg-white text-[11px]"/><button type="button" onClick={()=>removeChoiceOption(field.id,index)} className="p-1.5 text-stone-400 hover:text-rose-600"><Trash2 className="w-3.5 h-3.5"/></button></div>)}</div>
              {(field.options || []).length===0 && <div className="text-[10px] text-amber-700">No choices yet. Click Add option.</div>}
              <div className="text-[9.5px] text-stone-400 mt-2">Add, rename, remove, and reorder choices during form design. Saved choices are prebuilt for the user completing the published form.</div>
            </div>}
          </div>)}</div>
        </div> : <div className="max-w-3xl mx-auto bg-white border border-stone-200 rounded-2xl shadow-sm p-6 space-y-4">
          <div className="border-b border-stone-200 pb-3"><div className="text-[10px] uppercase tracking-wider font-black text-emerald-700">{profile} · {version}</div><h3 className="text-xl font-black text-stone-900">{title}</h3><p className="text-xs text-stone-500">Collect: {collectionStage} · Verify: {reviewStages.join(' → ') || 'No later review'}</p></div>
          {fields.map(f => <div key={f.id} className="space-y-1"><label className="text-xs font-bold text-stone-700">{f.label}{f.required && <span className="text-rose-500"> *</span>} <span className="text-[9px] font-medium text-stone-400">· {f.owner}</span></label>{f.type === 'clinical-list' ? <div className="rounded-lg border border-emerald-200 bg-emerald-50 px-3 py-2 text-[11px] text-emerald-900">Prefilled from shared chart record — Verify unchanged / Update</div> : f.type === 'signature' ? <div className="rounded-lg border border-stone-300 bg-stone-50 px-3 py-4 text-[11px] text-stone-500">Signature capture + signer identity + timestamp</div> : isChoiceType(f.type) ? <div className="flex flex-wrap gap-2">{(f.options||[]).map(opt => <label key={opt} className="inline-flex items-center gap-1.5 px-2.5 py-2 rounded-lg border border-stone-200 bg-stone-50 text-[11px]"><input type={f.type==='radio'?'radio':'checkbox'} name={f.id}/>{opt}</label>)}</div> : <div className="min-h-9 rounded-lg border border-stone-300 bg-stone-50 px-3 py-2 text-[11px] text-stone-400">Input: {f.type}</div>}</div>)}
          <div className="pt-3 border-t border-stone-200 flex justify-end"><button className="px-4 py-2 rounded-xl bg-emerald-700 text-white text-xs font-bold flex items-center gap-1.5"><FileCheck2 className="w-4 h-4"/>Complete, Sign & Finalize PDF</button></div>
        </div>}
      </div>
    </section>

    <section className="bg-white rounded-2xl border border-emerald-200 shadow-2xs p-5 sm:p-6 space-y-4">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <div className="flex items-center gap-2"><Copy className="w-5 h-5 text-emerald-700"/><h3 className="text-base font-black text-stone-900">Office Intelligence ASC Default Form Library</h3></div>
          <p className="text-xs text-stone-500 mt-1">26 templates converted from the supplied ASC HTML forms. All extracted questions/options are editable. Legacy signature code is represented by standardized signature fields.</p>
        </div>
        <div className="relative w-full sm:w-72"><input value={libraryQuery} onChange={e=>setLibraryQuery(e.target.value)} placeholder="Search default forms…" className="w-full px-3 py-2 rounded-xl border border-stone-300 text-xs"/></div>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-2">
        {visibleAscTemplates.map(template=><div key={template.sourceFile} className="rounded-xl border border-stone-200 bg-stone-50/50 p-3">
          <div className="flex items-start justify-between gap-2"><div><div className="text-[9px] font-black uppercase tracking-wide text-emerald-700">{template.group}</div><div className="font-black text-xs text-stone-900 mt-1">{template.title}</div></div><span className="text-[9px] px-2 py-0.5 rounded-full border border-stone-200 bg-white font-bold">{template.fields.length} fields</span></div>
          <div className="text-[10px] text-stone-500 mt-1">Collect: {template.collectionStage}{template.signatureZones ? ` · ${template.signatureZones} signature zone${template.signatureZones===1?'':'s'}` : ''}</div>
          <div className="text-[9.5px] text-stone-400 mt-1">Source: {template.sourceFile} · {template.sourceControlCount} original controls</div>
          <button type="button" onClick={()=>loadAscDefaultTemplate(template)} className="mt-3 px-3 py-1.5 rounded-lg bg-white border border-emerald-300 text-emerald-800 text-[10px] font-black flex items-center gap-1"><Copy className="w-3 h-3"/>Use & Edit</button>
        </div>)}
      </div>
    </section>

    <section className="bg-white rounded-2xl border border-stone-200 shadow-2xs p-5 sm:p-6 space-y-4">
      <div><div className="flex items-center gap-2"><Layers className="w-5 h-5 text-emerald-700"/><h3 className="text-base font-black text-stone-900">Imported Practice Form Library</h3></div><p className="text-xs text-stone-500 mt-1">Your uploaded HTML forms are now treated as reference templates for the schema engine—not disposable mockups.</p></div>
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-3">{REFERENCE_FORMS.map(group => <div key={group.group} className="rounded-xl border border-stone-200 bg-stone-50/50 p-4"><div className="flex items-center justify-between"><div className="flex items-center gap-2"><FileText className="w-4 h-4 text-emerald-700"/><span className="text-xs font-black text-stone-900">{group.group}</span></div><span className="text-[10px] font-bold rounded-full bg-white border border-stone-200 px-2 py-0.5">{group.count} forms</span></div><p className="text-[10.5px] text-stone-600 mt-2 leading-relaxed">{group.examples}</p><div className="mt-3 text-[10px] font-bold text-emerald-800">Recommended lifecycle: {group.use}</div></div>)}</div>
    </section>

    <section className="bg-white rounded-2xl border border-stone-200 shadow-2xs p-5 sm:p-6 space-y-4">
      <div className="flex flex-wrap items-end justify-between gap-3"><div><div className="flex items-center gap-2"><ShieldCheck className="w-5 h-5 text-emerald-700"/><h3 className="text-base font-black text-stone-900">Uploaded Form Foundation Review</h3></div><p className="text-xs text-stone-500 mt-1">What should be preserved from your current practice forms and converted into structured reusable components.</p></div><span className="text-[10px] font-black uppercase tracking-wide px-2 py-1 rounded-full bg-amber-100 text-amber-800 border border-amber-200">Administrator review required</span></div>
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-3">{COVERAGE.map(item => <div key={item.area} className={`rounded-xl border p-3 ${item.status === 'covered' ? 'border-emerald-200 bg-emerald-50/50' : 'border-amber-200 bg-amber-50/50'}`}><div className="flex items-center justify-between gap-2"><div className="text-xs font-black text-stone-900">{item.area}</div><span className={`text-[9px] font-black uppercase px-2 py-0.5 rounded-full ${item.status === 'covered' ? 'bg-emerald-200 text-emerald-900' : 'bg-amber-200 text-amber-900'}`}>{item.status}</span></div><p className="text-[10.5px] text-stone-600 leading-relaxed mt-2">{item.note}</p></div>)}</div>
    </section>
  </div>;
};
