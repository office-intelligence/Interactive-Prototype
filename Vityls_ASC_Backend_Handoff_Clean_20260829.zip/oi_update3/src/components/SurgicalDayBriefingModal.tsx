import React from 'react';
import { X, Sparkles, CheckCircle2, AlertTriangle, ShieldCheck, Printer, Clock, User, Scissors, Stethoscope } from 'lucide-react';
import { AppointmentItem } from './ScheduleFullView';

interface SurgicalDayBriefingModalProps {
  isOpen: boolean;
  onClose: () => void;
  dateStr: string;
  appointments: AppointmentItem[];
}

export const SurgicalDayBriefingModal: React.FC<SurgicalDayBriefingModalProps> = ({
  isOpen,
  onClose,
  dateStr,
  appointments,
}) => {
  if (!isOpen) return null;

  const totalCases = appointments.filter(a => !a.isBlock).length;
  const totalBlocks = appointments.filter(a => a.isBlock).length;

  return (
    <div className="fixed inset-0 z-50 bg-stone-950/60 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-200">
      <div className="bg-white rounded-2xl shadow-2xl border border-stone-200 w-full max-w-4xl max-h-[90vh] overflow-hidden flex flex-col animate-in zoom-in-95 duration-200">
        
        {/* Modal Header */}
        <div className="px-6 py-4 bg-[#14432E] text-white flex items-center justify-between border-b border-[#5B6B60]">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-[#E4F3EA] border border-[#E1E4DC] flex items-center justify-center text-[#2F9E6E] shadow-xs">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-bold text-white tracking-tight font-display">Nightingale Surgical Day-Sheet Briefing</h2>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-[#E4F3EA] text-[#1B4332] border border-[#E1E4DC]">
                  AI Practice Coordinator
                </span>
              </div>
              <p className="text-xs text-[#E1E4DC]">
                Operative readiness, implant preparation, and staff turnover logistics for {dateStr}
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-[#E1E4DC] hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto space-y-6 text-stone-800">
          
          {/* Executive Overview Stats */}
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
            <div className="bg-stone-50 p-3.5 rounded-xl border border-stone-200">
              <div className="text-[10px] font-bold text-stone-500 uppercase tracking-wider">Scheduled Cases</div>
              <div className="text-xl font-bold text-stone-900 mt-0.5">{totalCases} Surgeries</div>
              <div className="text-[11px] text-stone-500 mt-0.5">Across OR #1, #2, #3</div>
            </div>

            <div className="bg-stone-50 p-3.5 rounded-xl border border-stone-200">
              <div className="text-[10px] font-bold text-stone-500 uppercase tracking-wider">Turnover Buffers</div>
              <div className="text-xl font-bold text-emerald-700 mt-0.5">{totalBlocks > 0 ? `${totalBlocks} Reserved` : 'Sterilization Ready'}</div>
              <div className="text-[11px] text-stone-500 mt-0.5">45m post-rhinoplasty</div>
            </div>

            <div className="bg-stone-50 p-3.5 rounded-xl border border-stone-200">
              <div className="text-[10px] font-bold text-stone-500 uppercase tracking-wider">Anesthesia Coverage</div>
              <div className="text-xl font-bold text-stone-900 mt-0.5">Anesthesia Provider</div>
              <div className="text-[11px] text-stone-500 mt-0.5">MAC & General certified</div>
            </div>

            <div className="bg-amber-50/80 p-3.5 rounded-xl border border-amber-200">
              <div className="text-[10px] font-bold text-amber-800 uppercase tracking-wider flex items-center gap-1">
                <AlertTriangle className="w-3 h-3 text-amber-600" />
                <span>Special Staging</span>
              </div>
              <div className="text-xs font-bold text-amber-950 mt-1">Orbital micro-tray staged</div>
              <div className="text-[10px] text-amber-700 mt-0.5">Silicone implant sizing verified</div>
            </div>
          </div>

          {/* Roster Table */}
          <div className="border border-stone-200 rounded-xl overflow-hidden shadow-2xs">
            <div className="bg-stone-100 px-4 py-2.5 border-b border-stone-200 flex items-center justify-between">
              <span className="text-xs font-bold text-stone-800 uppercase tracking-wider">
                Operative Sequence & Logistics
              </span>
              <span className="text-[11px] text-stone-500 font-medium">
                Showing {appointments.length} scheduled items
              </span>
            </div>

            <div className="divide-y divide-stone-100">
              {appointments.length === 0 ? (
                <div className="p-8 text-center text-stone-500 text-xs">
                  No cases scheduled for this date.
                </div>
              ) : (
                appointments.map((apt, idx) => (
                  <div key={apt.id || idx} className="p-3.5 hover:bg-stone-50 transition-colors flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div className="flex items-start gap-3">
                      <div className="w-7 h-7 rounded-lg bg-stone-100 text-stone-700 font-bold text-xs flex items-center justify-center shrink-0 border border-stone-200 mt-0.5">
                        {idx + 1}
                      </div>
                      <div>
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="font-bold text-sm text-stone-900">{apt.patientName || apt.title}</span>
                          <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-stone-200/80 text-stone-700">
                            {apt.room}
                          </span>
                          <span className="px-2 py-0.5 rounded-md text-[10px] font-semibold bg-emerald-50 text-emerald-800 border border-emerald-200">
                            {apt.startTime} ({apt.length || `${apt.durationHours} hrs`})
                          </span>
                          {apt.isBlock && (
                            <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-amber-100 text-amber-800 border border-amber-300">
                              TURNOVER BUFFER
                            </span>
                          )}
                        </div>
                        <div className="text-xs text-stone-600 font-medium mt-1">
                          <span className="font-semibold text-stone-800">Procedure:</span> {apt.procedure || apt.details}
                        </div>
                        <div className="text-[11px] text-stone-500 mt-0.5 flex items-center gap-3">
                          <span><strong>Surgeon:</strong> {apt.surgeon}</span>
                          {apt.anesthesiologist && <span><strong>Anesthesia:</strong> {apt.anesthesiologist} ({apt.anesthesiaType})</span>}
                        </div>
                      </div>
                    </div>

                    {apt.notes && (
                      <div className="sm:max-w-xs text-[11px] bg-stone-100/80 p-2 rounded-lg border border-stone-200 text-stone-600">
                        <span className="font-semibold text-stone-800">Clinical Prep:</span> {apt.notes}
                      </div>
                    )}
                  </div>
                ))
              )}
            </div>
          </div>

          {/* Nightingale Coordinator Action Advice */}
          <div className="bg-[#E4F3EA] border border-[#E1E4DC] rounded-xl p-4 flex items-start gap-3 shadow-2xs">
            <CheckCircle2 className="w-5 h-5 text-[#2F9E6E] shrink-0 mt-0.5" />
            <div className="text-xs text-[#1B4332]">
              <div className="font-bold mb-0.5 font-display">Nightingale Pre-Op Verification Status</div>
              <p className="leading-relaxed text-[#14432E] font-medium">
                All patient consent packets and EKG clearances for today's roster have been cross-checked with the electronic chart. Standard PACU recovery bays #1 through #4 are staffed and ready for patient intake.
              </p>
            </div>
          </div>

        </div>

        {/* Modal Footer */}
        <div className="px-6 py-3.5 bg-stone-50 border-t border-stone-200 flex items-center justify-between">
          <div className="text-xs text-stone-500 font-medium">
            Generated automatically by Nightingale Practice AI
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => window.print()}
              className="px-4 py-2 bg-stone-200 hover:bg-stone-300 text-stone-800 font-bold text-xs rounded-xl transition-colors cursor-pointer flex items-center gap-1.5"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print Day Briefing</span>
            </button>
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-stone-900 hover:bg-stone-800 text-white font-bold text-xs rounded-xl transition-colors cursor-pointer shadow-xs"
            >
              Done
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
