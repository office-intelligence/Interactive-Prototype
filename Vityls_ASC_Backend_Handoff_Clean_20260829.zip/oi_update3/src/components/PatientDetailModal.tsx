import React from 'react';
import { PatientCase, PatientStage } from '../types';
import { 
  X, 
  Sparkles, 
  AlertTriangle, 
  CheckCircle2, 
  User, 
  Phone, 
  Calendar, 
  Clock, 
  Building2, 
  FileText, 
  Activity, 
  ShieldAlert, 
  Check, 
  Printer, 
  Send,
  Stethoscope
} from 'lucide-react';

interface PatientDetailModalProps {
  patient: PatientCase | null;
  onClose: () => void;
  onUpdateStage: (caseId: string, stage: PatientStage) => void;
  onToggleAction: (caseId: string, actionId: string) => void;
  onTriggerEKGFastTrack: (caseId: string) => void;
  onOpenChart?: (patient: PatientCase) => void;
}

export const PatientDetailModal: React.FC<PatientDetailModalProps> = ({
  patient,
  onClose,
  onUpdateStage,
  onToggleAction,
  onTriggerEKGFastTrack,
  onOpenChart,
}) => {
  if (!patient) return null;

  const isNeedsAttention = patient.readinessLevel === 'NEEDS_ATTENTION';

  return (
    <div className="fixed inset-0 z-50 bg-stone-900/40 backdrop-blur-xs flex justify-end transition-opacity animate-in fade-in duration-200">
      <div className="w-full max-w-2xl bg-white h-full shadow-2xl flex flex-col justify-between overflow-y-auto">
        
        {/* Header */}
        <div className="p-6 border-b border-stone-200 bg-stone-50/80 sticky top-0 z-10 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-800 text-amber-100 font-bold text-sm flex items-center justify-center shadow-md shadow-amber-800/20">
              {patient.name.split(' ').map((n) => n[0]).join('')}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-bold text-stone-900">{patient.name}</h2>
                <span className="px-2 py-0.5 rounded-full text-xs font-semibold bg-stone-100 text-stone-700">
                  {patient.age} Yrs • {patient.gender}
                </span>
              </div>
              <p className="text-xs text-stone-500 font-mono">
                Patient ID: {patient.patientId} • Phone: {patient.phone}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl text-stone-400 hover:text-stone-700 hover:bg-stone-200/60 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 space-y-6 flex-1">
          
          {/* Top Status & Stage Banner */}
          <div className={`p-4 rounded-2xl border ${
            isNeedsAttention
              ? 'bg-amber-50 border-amber-300 text-amber-950'
              : 'bg-amber-50/60 border-amber-200 text-amber-950'
          }`}>
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2 font-bold text-sm">
                {isNeedsAttention ? (
                  <AlertTriangle className="w-4 h-4 text-amber-600" />
                ) : (
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                )}
                <span>
                  AI Readiness Score: {patient.readinessScore} ({patient.readinessLevel.replace('_', ' ')})
                </span>
              </div>
              <span className="text-xs font-bold px-2.5 py-0.5 rounded-md bg-white border border-stone-200 shadow-2xs">
                {patient.scheduledTime} • {patient.room}
              </span>
            </div>

            <p className="text-xs leading-relaxed font-medium">
              {patient.aiSummary}
            </p>

            {isNeedsAttention && (
              <div className="mt-3 pt-3 border-t border-amber-200 flex items-center justify-between">
                <span className="text-xs font-bold text-amber-900">Action required before surgical transfer</span>
                <button
                  onClick={() => onTriggerEKGFastTrack(patient.id)}
                  className="px-3 py-1.5 rounded-xl bg-amber-800 hover:bg-amber-900 text-amber-50 font-bold text-xs shadow-2xs transition-colors"
                >
                  Trigger Fast-Track Cardiology Fax
                </button>
              </div>
            )}
          </div>

          {/* Quick Stage Transition Buttons */}
          <div className="space-y-2">
            <div className="text-xs font-bold text-stone-400 uppercase tracking-wider">
              Current Flow Stage
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {[
                { stage: 'CHECK_IN', label: 'Check-In / Reception' },
                { stage: 'PRE_OP', label: 'Pre-Op Bay' },
                { stage: 'IN_OR', label: 'In OR Surgery' },
                { stage: 'PACU_RECOVERY', label: 'PACU Recovery' },
              ].map((item) => (
                <button
                  key={item.stage}
                  onClick={() => onUpdateStage(patient.id, item.stage as PatientStage)}
                  className={`py-2 px-3 rounded-xl text-xs font-bold border transition-all text-center ${
                    patient.stage === item.stage
                      ? 'bg-stone-900 text-amber-100 border-stone-900 shadow-xs'
                      : 'bg-white text-stone-700 border-stone-200 hover:bg-stone-100'
                  }`}
                >
                  {item.label}
                </button>
              ))}
            </div>
          </div>

          {/* Surgical Overview & Team */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="p-4 bg-stone-50 rounded-2xl border border-stone-200/80 space-y-2">
              <div className="text-xs font-bold text-stone-400 uppercase tracking-wider flex items-center gap-1.5">
                <Stethoscope className="w-3.5 h-3.5 text-amber-800" />
                <span>Procedure Details</span>
              </div>
              <div className="text-xs font-bold text-stone-900">{patient.procedure}</div>
              <div className="text-xs text-stone-500 flex items-center justify-between pt-1 border-t border-stone-200/60">
                <span>Duration: <strong className="text-stone-800">{patient.estimatedDurationMins} mins</strong></span>
                <span className="px-2 py-0.5 rounded bg-indigo-50 text-indigo-900 border border-indigo-200 font-bold text-[10px]">
                  💳 {patient.paymentType || 'Self-Pay'}
                </span>
              </div>
            </div>

            <div className="p-4 bg-stone-50 rounded-2xl border border-stone-200/80 space-y-2">
              <div className="text-xs font-bold text-stone-400 uppercase tracking-wider flex items-center gap-1.5">
                <User className="w-3.5 h-3.5 text-amber-800" />
                <span>Surgical Team</span>
              </div>
              <div className="text-xs font-semibold text-stone-900">
                Surgeon: <span className="font-bold">{patient.surgeon}</span>
              </div>
              <div className="text-xs font-semibold text-stone-700">
                Anesthesiologist: <span className="font-medium">{patient.anesthesiologist || 'Assigned On Call'}</span>
              </div>
            </div>
          </div>

          {/* Action Checklist */}
          <div className="space-y-2">
            <div className="text-xs font-bold text-stone-400 uppercase tracking-wider">
              Pre-Op Action Items
            </div>
            <div className="space-y-1.5">
              {patient.actionItems.map((item) => (
                <div
                  key={item.id}
                  onClick={() => onToggleAction(patient.id, item.id)}
                  className={`p-3 rounded-xl border flex items-center justify-between text-xs cursor-pointer transition-all ${
                    item.done
                      ? 'bg-stone-50 border-stone-200 text-stone-400 line-through'
                      : item.urgent
                      ? 'bg-amber-50 border-amber-300 text-amber-950 font-semibold'
                      : 'bg-white border-stone-200 hover:border-stone-300'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <div className={`w-4 h-4 rounded border flex items-center justify-center shrink-0 ${
                      item.done ? 'bg-slate-900 border-slate-900 text-white' : 'border-stone-300 bg-white'
                    }`}>
                      {item.done && <Check className="w-3 h-3" />}
                    </div>
                    <span>{item.text}</span>
                  </div>
                  {item.urgent && !item.done && (
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-700 text-white">
                      URGENT
                    </span>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Relevant Labs Breakdown */}
          <div className="space-y-2">
            <div className="text-xs font-bold text-stone-400 uppercase tracking-wider">
              Lab & Clinical Clearance Matrix
            </div>
            <div className="grid grid-cols-3 gap-2">
              {patient.labs.map((lab, i) => (
                <div key={i} className="p-3 bg-stone-50 rounded-xl border border-stone-200 text-xs space-y-1">
                  <div className="text-stone-500 font-medium">{lab.name}</div>
                  <div className={`font-bold ${
                    lab.status === 'normal' ? 'text-slate-900' : lab.status === 'warning' ? 'text-amber-700' : 'text-rose-700'
                  }`}>
                    {lab.value}
                  </div>
                </div>
              ))}
            </div>
          </div>

        </div>

        {/* Footer Actions */}
        <div className="p-4 border-t border-stone-200 bg-stone-50/80 flex items-center justify-between gap-3">
          <button
            onClick={() => alert(`Printing EHR surgical record for ${patient.name}...`)}
            className="px-3 py-2 rounded-xl bg-white border border-stone-200 text-stone-700 hover:bg-stone-100 text-xs font-semibold flex items-center gap-1.5 transition-colors"
          >
            <Printer className="w-4 h-4" />
            <span>Print EHR Chart</span>
          </button>

          <div className="flex items-center gap-2">
            {onOpenChart && (
              <button
                onClick={() => {
                  onClose();
                  onOpenChart(patient);
                }}
                className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold flex items-center gap-1.5 transition-colors shadow-2xs cursor-pointer"
              >
                <FileText className="w-4 h-4" />
                <span>Open Patient Chart</span>
              </button>
            )}

            <button
              onClick={onClose}
              className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold transition-colors cursor-pointer shadow-2xs"
            >
              Done
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
