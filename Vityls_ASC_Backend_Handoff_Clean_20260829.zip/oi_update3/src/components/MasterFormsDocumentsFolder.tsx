import React, { useEffect, useMemo, useRef, useState } from 'react';
import { CalendarDays, Download, Eye, FileCheck2, FileText, Filter, Search, Trash2, Upload } from 'lucide-react';
import type { PatientCase } from '../types';
import {
  createLocalBlobUrl, listCurrentPracticeForms, listPdfTemplates, listEncounterDocuments, saveEncounterDocument,
  updateEncounterDocumentSummary, updateEncounterDocumentReviewStatus, deleteEncounterDocument, type LocalEncounterDocument, type LocalFormTemplate, type LocalPdfTemplate,
} from '../utils/localFormStudioDb';
import { listLocalFormResponses, type LocalFormResponse } from '../utils/localFormResponseStore';
import { PdfTemplateInteractiveViewer } from './PdfTemplateInteractiveViewer';
import { PdfFormViewer } from './PdfFormViewer';
import { loadStoredPdfDoc, base64ToUint8 } from '../utils/pdfFormEngine';
import nightingaleIcon from '../assets/nightingale-ai-icon.png';

interface Props {
  patient: PatientCase;
  activePracticeId?: string;
  onOpenForm?: (form: LocalFormTemplate) => void;
}

type FolderRow = {
  id: string;
  title: string;
  category: string;
  encounterDate: string;
  source: string;
  status: string;
  summary: string;
  form?: LocalFormTemplate;
  doc?: LocalEncounterDocument;
  pdf?: LocalPdfTemplate;
};

export const MasterFormsDocumentsFolder: React.FC<Props> = ({ patient, activePracticeId, onOpenForm }) => {
  const [forms,setForms]=useState<LocalFormTemplate[]>([]);
  const [docs,setDocs]=useState<LocalEncounterDocument[]>([]);
  const [pdfTemplates,setPdfTemplates]=useState<LocalPdfTemplate[]>([]);
  const [activePdf,setActivePdf]=useState<LocalPdfTemplate|null>(null);
  const [activeUploadedPdf,setActiveUploadedPdf]=useState<{doc:LocalEncounterDocument;bytes:ArrayBuffer}|null>(null);
  const [summaryRow,setSummaryRow]=useState<FolderRow|null>(null);
  const [tick,setTick]=useState(0);
  const [query,setQuery]=useState('');
  const [dateFilter,setDateFilter]=useState('All');
  const uploadRef=useRef<HTMLInputElement>(null);

  const refresh=async()=>{
    if(!activePracticeId){setForms([]);setDocs([]);return;}
    const [f,pdfs,d]=await Promise.all([
      listCurrentPracticeForms(activePracticeId),
      listPdfTemplates(activePracticeId),
      listEncounterDocuments(activePracticeId,patient.id),
    ]);
    setForms(f);
    setPdfTemplates(pdfs.filter(pdf=>pdf.status==='Active'));
    setDocs(d);
  };

  useEffect(()=>{refresh().catch(()=>{});},[activePracticeId,patient.id]);
  useEffect(()=>{
    const h=()=>setTick(x=>x+1);
    const hp=()=>setTick(x=>x+1);
    window.addEventListener('oi-form-response-updated',h);
    window.addEventListener('oi-pdf-form-updated',hp);
    return()=>{
      window.removeEventListener('oi-form-response-updated',h);
      window.removeEventListener('oi-pdf-form-updated',hp);
    };
  },[]);

  const responses=useMemo(
    ()=>activePracticeId?listLocalFormResponses(activePracticeId,patient.id):[],
    [activePracticeId,patient.id,tick]
  );
  const responseByForm = new Map<string, LocalFormResponse>(responses.map((r): [string, LocalFormResponse] => [r.formId, r]));

  const rows:FolderRow[]=useMemo(()=>{
    const formRows=forms.map(form=>{
      const response=responseByForm.get(form.id);
      const answeredCount=response
        ? Object.values(response.values || {}).filter((value) => {
            if (Array.isArray(value)) return value.length > 0;
            if (typeof value === 'boolean') return value;
            return String(value ?? '').trim().length > 0;
          }).length
        : 0;
      const summary=response
        ? `Nightingale synopsis: ${form.title} was completed for this encounter on ${new Date(response.completedAt).toLocaleString()} by ${response.completedBy || 'the recorded user'}. ${answeredCount} structured response item${answeredCount===1?' was':'s were'} captured. The completed record remains available for review and printing, and the current internal version is ${form.version}.`
        : `Nightingale synopsis: ${form.title} is an active ${form.collectionStage} record (${form.version}) assigned to this encounter. It has not yet been completed for this patient, so there are no patient-entered events to summarize yet.`;
      return {
        id:`form-${form.id}`,
        title:form.title,
        category:form.collectionStage,
        encounterDate:response?.completedAt || 'Current encounter',
        source:'Internal',
        status:response?'Completed':'Available',
        summary,
        form,
      } as FolderRow;
    });

    const pdfRows=pdfTemplates.flatMap(pdf=>{
      const stored=loadStoredPdfDoc(patient.id,`practice-pdf:${pdf.id}:${pdf.version}`);
      if(!stored) return [];
      const eventText=stored.status==='LOCKED'
        ? `The PDF was finalized and locked${stored.lockedAt ? ` on ${new Date(stored.lockedAt).toLocaleString()}` : ''}. The locked rendered PDF is preserved as the encounter source.`
        : `An editable PDF draft exists for this patient. Staff can reopen it to continue annotation/field entry before final locking.`;
      return [{
        id:`pdf-${pdf.id}`,
        title:pdf.title,
        category:pdf.collectionStage,
        encounterDate:stored.lockedAt || 'Current encounter',
        source:'Internal',
        status:stored.status==='LOCKED'?'Completed':'Draft',
        summary:`Nightingale synopsis: ${pdf.title} is an internal ${pdf.collectionStage} record (${pdf.version}). ${eventText}`,
        pdf,
      } as FolderRow];
    });

    const docRows=docs.map(doc=>({
      id:`doc-${doc.id}`,
      title:doc.title,
      category:doc.classification || 'Encounter Document',
      encounterDate:doc.uploadedAt,
      source:'External',
      status:doc.reviewStatus || 'Pending Review',
      summary:doc.aiSummary || `Nightingale synopsis: ${doc.title} was uploaded to this encounter on ${new Date(doc.uploadedAt).toLocaleString()} by ${doc.uploadedBy || 'practice staff'}. The original source is preserved. Detailed content extraction is pending.`,
      doc,
    } as FolderRow));

    return [...formRows,...pdfRows,...docRows].sort((a,b)=>String(b.encounterDate).localeCompare(String(a.encounterDate)));
  },[forms,pdfTemplates,docs,tick,patient.id]);

  const dateOptions=['All',...Array.from(new Set(rows.map(r=>{
    if(r.encounterDate==='Current encounter') return 'Current encounter';
    const d=new Date(r.encounterDate);
    return Number.isNaN(d.getTime()) ? r.encounterDate : d.toLocaleDateString();
  }))).sort().reverse()];

  const filtered=rows.filter(row=>{
    const rowDate=row.encounterDate==='Current encounter'?'Current encounter':(()=>{
      const d=new Date(row.encounterDate);return Number.isNaN(d.getTime())?row.encounterDate:d.toLocaleDateString();
    })();
    return (!query.trim() || `${row.title} ${row.category} ${row.source}`.toLowerCase().includes(query.toLowerCase()))
      && (dateFilter==='All' || rowDate===dateFilter);
  });

  const uploadSource=async(file:File)=>{
    if(!activePracticeId)return;
    await saveEncounterDocument({
      practiceId:activePracticeId,
      patientId:patient.id,
      encounterKey:`${patient.id}:${patient.scheduledTime||'current'}`,
      title:file.name.replace(/\.[^.]+$/,'').replace(/[_-]+/g,' '),
      sourceType:/scan|paper/i.test(file.name)?'PAPER_SCAN':'UPLOADED_PDF',
      fileName:file.name,
      mimeType:file.type || 'application/pdf',
      blob:file,
      uploadedBy:'Practice Staff',
      aiSummary:'Original source preserved. Nightingale classification and encounter synopsis are pending staff review.',
    });
    await refresh();
  };

  const showAiSummary=async(row:FolderRow)=>{
    if(row.doc && row.doc.aiStatus!=='Summarized'){
      const generated=`Nightingale synopsis: ${row.doc.title} was added to this encounter on ${new Date(row.doc.uploadedAt).toLocaleString()} by ${row.doc.uploadedBy || 'practice staff'}. It is classified as ${row.doc.classification || 'an encounter document'}. The original file remains preserved. In this local test build, the synopsis is based on document metadata and workflow state; production Nightingale will read/OCR the source, summarize the clinical events it contains, cite page/source provenance, and require human verification before promoting extracted facts into the chart.`;
      await updateEncounterDocumentSummary(row.doc.id,generated);
      const updatedRow={...row,status:'Summarized',summary:generated,doc:{...row.doc,aiStatus:'Summarized' as const,aiSummary:generated}};
      setSummaryRow(updatedRow);
      await refresh();
      return;
    }
    setSummaryRow(row);
  };

  const downloadUploadedDocument=(doc:LocalEncounterDocument)=>{
    if(!doc.blob)return;
    const url=URL.createObjectURL(doc.blob);
    const a=document.createElement('a');
    a.href=url;
    a.download=doc.fileName || `${doc.title}.pdf`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(()=>URL.revokeObjectURL(url),1500);
  };

  const removeUploadedDocument=async(doc:LocalEncounterDocument)=>{
    const ok=window.confirm(`Delete "${doc.title}" from this patient's Forms & Documents folder?\n\nThis removes the uploaded source document from the local test record.`);
    if(!ok)return;
    if(summaryRow?.doc?.id===doc.id)setSummaryRow(null);
    if(activeUploadedPdf?.doc.id===doc.id)setActiveUploadedPdf(null);
    await deleteEncounterDocument(doc.id);
    await refresh();
  };

  return (
    <section id="documents-section" className="bg-white rounded-2xl border border-stone-200/90 shadow-2xs overflow-hidden">
      <div className="p-4 border-b border-stone-200 flex flex-col xl:flex-row xl:items-center justify-between gap-3">
        <div>
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-indigo-600 text-white flex items-center justify-center"><FileText className="w-4 h-4"/></div>
            <div><h3 className="text-sm font-black text-stone-900">Forms & Documents</h3><p className="text-[11px] text-stone-500 mt-0.5">Master electronic chart folder: intake, clearance, laboratory, ECG/EKG, pathology, nursing, anesthesia, operative, discharge, scanned paper records and outside documents.</p></div>
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <input ref={uploadRef} type="file" accept="application/pdf,image/*" className="hidden" onChange={e=>{const f=e.target.files?.[0];if(f)uploadSource(f);e.currentTarget.value='';}}/>
          <button onClick={()=>uploadRef.current?.click()} className="px-3 py-2 rounded-xl bg-slate-900 text-white text-xs font-black flex items-center gap-1.5"><Upload className="w-4 h-4"/>Upload Patient Document</button>
        </div>
      </div>

      <div className="p-4 border-b border-stone-100 bg-stone-50/60 grid grid-cols-1 md:grid-cols-[minmax(260px,1fr)_190px] gap-2">
        <div className="relative"><Search className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2"/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search forms and documents…" className="w-full pl-9 pr-3 py-2 rounded-xl border border-stone-300 bg-white text-xs"/></div>
        <select value={dateFilter} onChange={e=>setDateFilter(e.target.value)} className="px-3 py-2 rounded-xl border border-stone-300 bg-white text-xs">{dateOptions.map(v=><option key={v}>{v}</option>)}</select>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-left text-xs">
          <thead className="bg-white text-[10px] uppercase tracking-wide text-stone-500 border-b border-stone-200">
            <tr><th className="px-4 py-2.5">Form / Document</th><th className="px-4 py-2.5">Encounter Date</th><th className="px-4 py-2.5">Source</th><th className="px-4 py-2.5">Status</th><th className="px-4 py-2.5 text-right">Actions</th></tr>
          </thead>
          <tbody className="divide-y divide-stone-100">
            {filtered.map(row=>{
              const d=row.encounterDate==='Current encounter'?row.encounterDate:(()=>{
                const x=new Date(row.encounterDate);return Number.isNaN(x.getTime())?row.encounterDate:x.toLocaleString();
              })();
              return <tr key={row.id} className="hover:bg-stone-50">
                <td className="px-4 py-3 font-bold text-stone-900">{row.title}</td>
                <td className="px-4 py-3 text-stone-600">{d}</td>
                <td className="px-4 py-3 text-stone-600">{row.source}</td>
                <td className="px-4 py-3"><span className={`px-2 py-1 rounded-lg border text-[10px] font-black ${row.status==='Completed'||row.status==='Reviewed'?'bg-emerald-50 border-emerald-200 text-emerald-800':'bg-amber-50 border-amber-200 text-amber-800'}`}>{row.status}</span></td>
                <td className="px-4 py-3"><div className="flex justify-end gap-2">
                  {row.form && <button onClick={()=>onOpenForm?.(row.form!)} className="text-[10px] font-black text-indigo-700 flex items-center gap-1"><Eye className="w-3.5 h-3.5"/>Open</button>}
                  {row.pdf && <button onClick={()=>setActivePdf(row.pdf!)} className="text-[10px] font-black text-violet-700 flex items-center gap-1"><Eye className="w-3.5 h-3.5"/>Open</button>}
                  {row.doc?.blob && row.doc.mimeType === 'application/pdf' && <button title="View" aria-label={`View ${row.title}`} onClick={async()=>{const bytes=await row.doc!.blob!.arrayBuffer();setActiveUploadedPdf({doc:row.doc!,bytes});}} className="p-1.5 text-emerald-700 hover:bg-emerald-50 border border-transparent hover:border-emerald-200 rounded-lg"><Eye className="w-4 h-4"/></button>}
                  {row.doc?.blob && row.doc.mimeType !== 'application/pdf' && <button title="View" aria-label={`View ${row.title}`} onClick={()=>{const u=createLocalBlobUrl(row.doc?.blob);if(u)window.open(u,'_blank');}} className="p-1.5 text-emerald-700 hover:bg-emerald-50 border border-transparent hover:border-emerald-200 rounded-lg"><Eye className="w-4 h-4"/></button>}
                  {row.doc?.blob && <button title="Download" aria-label={`Download ${row.title}`} onClick={()=>downloadUploadedDocument(row.doc!)} className="p-1.5 text-slate-700 hover:bg-slate-100 border border-transparent hover:border-slate-200 rounded-lg"><Download className="w-4 h-4"/></button>}
                  {row.doc && <button title="Summarize" aria-label={`Summarize ${row.title}`} onClick={()=>showAiSummary(row)} className="p-1.5 text-[#14432E] hover:bg-[#F4EFE3] border border-transparent hover:border-[#D9A448] rounded-lg"><img src={nightingaleIcon} alt="" className="w-4 h-4 object-contain"/></button>}
                  {row.doc && <button title="Delete" aria-label={`Delete ${row.title}`} onClick={()=>removeUploadedDocument(row.doc!)} className="p-1.5 text-rose-700 hover:bg-rose-50 border border-transparent hover:border-rose-200 rounded-lg"><Trash2 className="w-4 h-4"/></button>}
                  {!row.doc && <button onClick={()=>showAiSummary(row)} className="text-[10px] font-black text-sky-700 flex items-center gap-1"><img src={nightingaleIcon} alt="" className="w-3.5 h-3.5 object-contain"/>AI Summary</button>}
                </div></td>
              </tr>;
            })}
            {!filtered.length && <tr><td colSpan={5} className="p-8 text-center text-stone-500">No forms or documents match these filters.</td></tr>}
          </tbody>
        </table>
      </div>
    
      {summaryRow && (
        <div className="m-4 rounded-2xl border border-[#D9A448] bg-[#F4EFE3] overflow-hidden shadow-sm">
          <div className="px-4 py-3 border-b border-[#D9A448] bg-[#14432E] flex items-start justify-between gap-3">
            <div>
              <div className="text-[10px] uppercase tracking-wider font-black text-[#D9A448] flex items-center gap-1.5"><img src={nightingaleIcon} alt="" className="w-4 h-4 object-contain"/>Nightingale AI Summary</div>
              <div className="text-sm font-black text-[#F4EFE3] mt-1">{summaryRow.title}</div>
              <div className="text-[10.5px] text-[#F4EFE3]/75 mt-0.5">{summaryRow.source} source</div>
            </div>
            <button onClick={()=>setSummaryRow(null)} className="px-2.5 py-1.5 rounded-lg bg-[#F4EFE3] border border-[#D9A448] text-[#14432E] text-[10px] font-black">Close</button>
          </div>
          <div className="p-4 text-xs leading-relaxed text-stone-700 whitespace-pre-wrap">{summaryRow.summary}</div>
          <div className="px-4 pb-4 text-[10px] text-[#5B6B60]">
            Local testing note: uploaded-document summaries are metadata/workflow summaries until production OCR/AI source reading is connected.
          </div>
        </div>
      )}

      {activeUploadedPdf && (
        <PdfFormViewer
          patientId={patient.id}
          documentId={`encounter-document:${activeUploadedPdf.doc.id}`}
          title={activeUploadedPdf.doc.title}
          pdfUrl=""
          pdfBytesOverride={activeUploadedPdf.bytes}
          signerName={patient.name}
          onSaved={async()=>{
            await updateEncounterDocumentReviewStatus(activeUploadedPdf.doc.id,'Reviewed');
            await refresh();
          }}
          onClose={()=>setActiveUploadedPdf(null)}
        />
      )}

      {activePdf && (
        <PdfTemplateInteractiveViewer
          patientId={patient.id}
          patientName={patient.name}
          template={activePdf}
          onClose={()=>setActivePdf(null)}
        />
      )}
</section>
  );
};
