import React from 'react';
import { PenTool } from 'lucide-react';
import { SignaturePad } from './SignaturePad';

export interface SignatureZoneDefinition {
  id: string;
  label: string;
  owner?: string;
  required?: boolean;
}

interface Props {
  zones: SignatureZoneDefinition[];
  values: Record<string,string>;
  onChange: (zoneId: string, dataUrl: string) => void;
  signerName?: string;
  heading?: string;
}

export const UnifiedSignatureZones: React.FC<Props> = ({
  zones, values, onChange, signerName, heading = 'Electronic Signatures'
}) => {
  if (!zones.length) return null;
  return (
    <div className="rounded-2xl border border-teal-200 bg-teal-50/40 p-4 space-y-4">
      <div className="flex items-start gap-2">
        <div className="w-8 h-8 rounded-xl bg-teal-700 text-white flex items-center justify-center shrink-0"><PenTool className="w-4 h-4"/></div>
        <div>
          <div className="text-sm font-black text-stone-900">{heading}</div>
          <div className="text-[10.5px] text-stone-500 mt-0.5">All Office Intelligence forms use the same freehand / mouse / touch signature control. Each signature is stored as its own signer event.</div>
        </div>
      </div>
      <div className="space-y-4">
        {zones.map(zone => (
          <div key={zone.id} className="bg-white rounded-xl border border-stone-200 p-3">
            <div className="flex items-center justify-between gap-2 mb-2">
              <div className="text-xs font-black text-stone-800">{zone.label}</div>
              <span className="text-[9px] font-black uppercase px-2 py-0.5 rounded-full bg-stone-100 text-stone-600">{zone.owner || 'Signer'}{zone.required===false?' · optional':''}</span>
            </div>
            <SignaturePad
              label={zone.label}
              signerName={signerName}
              savedSignature={values[zone.id] || null}
              onSave={(value)=>onChange(zone.id,value)}
            />
          </div>
        ))}
      </div>
    </div>
  );
};

export const requiredSignatureZonesComplete = (
  zones: SignatureZoneDefinition[],
  values: Record<string,string>
) => zones.filter(z=>z.required!==false).every(z=>Boolean(values[z.id]));
