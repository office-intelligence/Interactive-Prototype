import React, { useState } from 'react';
import {
  UserPlus,
  Sparkles,
  ShieldCheck,
  ArrowRight,
  Eye,
  EyeOff,
  CheckCircle2,
  AlertCircle,
  Building2,
  User,
  Mail,
  Phone,
  Lock,
  ArrowLeft,
  FileText,
  Check,
  Stethoscope,
  HeartPulse,
  Syringe,
  Users,
  MoreHorizontal,
  FileSignature,
  X,
  ClipboardList
} from 'lucide-react';
import { PracticeType, LegalAgreementDoc, LegalAgreementCategory, AgreementAcceptanceRecord } from '../types';

interface RegistrationPageProps {
  onRegisterSuccess: (newUser: {
    firstName: string;
    lastName: string;
    email: string;
    telephone: string;
    practiceType: PracticeType;
    specialty: string;
    agreementAcceptances: AgreementAcceptanceRecord[];
  }) => void;
  onNavigateLogin: () => void;
  onNavigateLanding: () => void;
}

/* ============================================================
   PRACTICE TYPE OPTIONS
   ============================================================ */

interface PracticeTypeOption {
  value: PracticeType;
  label: string;
  description: string;
  icon: React.ElementType;
}

const PRACTICE_TYPE_OPTIONS: PracticeTypeOption[] = [
  {
    value: 'ASC',
    label: 'ASC',
    description: 'Ambulatory Surgery Center performing scheduled outpatient procedures.',
    icon: Building2
  },
  {
    value: 'Office-based Surgery',
    label: 'Office-based Surgery',
    description: 'In-office procedure suite attached to a physician practice.',
    icon: Stethoscope
  },
  {
    value: 'General Medical/Surgical',
    label: 'General Medical/Surgical',
    description: 'Mixed medical and surgical patient care under one roof.',
    icon: HeartPulse
  },
  {
    value: 'Medspa',
    label: 'Medspa',
    description: 'Cosmetic and aesthetic procedures with light clinical oversight.',
    icon: Sparkles
  },
  {
    value: 'Surgeon-Owned Operating Suite',
    label: 'Surgeon-Owned Operating Suite',
    description: 'Independent operating suite owned and staffed by surgeons.',
    icon: Syringe
  },
  {
    value: 'Multispecialty Clinic',
    label: 'Multispecialty Clinic',
    description: 'Multiple specialties and providers coordinating shared patients.',
    icon: Users
  },
  {
    value: 'Other',
    label: 'Other',
    description: 'A different practice model not listed above.',
    icon: MoreHorizontal
  }
];

/* ============================================================
   LEGAL AGREEMENT DOCUMENTS
   Eight required agreements, one per LegalAgreementCategory.
   ============================================================ */

const AGREEMENT_DOCS: LegalAgreementDoc[] = [
  {
    id: 'terms-of-use',
    category: 'Terms of Use' as LegalAgreementCategory,
    title: 'Terms of Use',
    summary: 'Governs your access to and use of the Office Intelligence platform.',
    version: 'v2.1',
    effectiveDate: '2026-01-05',
    bodyPreview:
      'These Terms of Use govern your access to and use of the Office Intelligence software platform, including all clinical workflow, scheduling, and administrative modules made available to your practice. By creating an account, you represent that you are authorized to bind your practice to these terms. Office Intelligence reserves the right to suspend accounts found to be in violation of applicable law or these terms. Continued use of the platform following any update to these terms constitutes acceptance of the revised terms.',
    requiredForRoles: ['PRACTICE_ADMIN']
  },
  {
    id: 'privacy-policy',
    category: 'Privacy Policy' as LegalAgreementCategory,
    title: 'Privacy Policy',
    summary: 'Describes how account, usage, and practice data is collected and handled.',
    version: 'v2.0',
    effectiveDate: '2026-01-05',
    bodyPreview:
      'This Privacy Policy describes the categories of information Office Intelligence collects from practice administrators, staff, and providers, including account credentials, device and usage metadata, and support communications. Protected Health Information (PHI) processed on behalf of your practice is governed separately by the HIPAA Business Associate Agreement. We do not sell personal information. You may request an export or deletion of your account-level data at any time, subject to legal and recordkeeping retention requirements.',
    requiredForRoles: ['PRACTICE_ADMIN']
  },
  {
    id: 'hipaa-baa',
    category: 'HIPAA Business Associate Agreement' as LegalAgreementCategory,
    title: 'HIPAA Business Associate Agreement (BAA)',
    summary: 'Establishes Office Intelligence as a HIPAA Business Associate handling PHI on your behalf.',
    version: 'v3.0',
    effectiveDate: '2025-11-12',
    bodyPreview:
      'Office Intelligence operates as a Business Associate for covered entities under 45 CFR § 164.502(e) and § 164.504(e). All Protected Health Information (PHI) created, received, maintained, or transmitted on behalf of your practice is encrypted using AES-256 at rest and TLS 1.3 in transit, and access is logged for audit purposes. Office Intelligence will report any discovered breach of unsecured PHI without unreasonable delay, and in no case later than required by the Breach Notification Rule. Your practice remains the Covered Entity responsible for all clinical determinations.',
    requiredForRoles: ['PRACTICE_ADMIN']
  },
  {
    id: 'subscription-billing',
    category: 'Subscription & Billing Agreement' as LegalAgreementCategory,
    title: 'Subscription & Billing Agreement',
    summary: 'Covers subscription tiers, billing cycles, and cancellation terms.',
    version: 'v1.4',
    effectiveDate: '2025-09-01',
    bodyPreview:
      'This Subscription & Billing Agreement describes the fees, billing cadence, and renewal terms applicable to your selected Office Intelligence subscription tier. Subscriptions renew automatically at the then-current rate unless canceled prior to the renewal date. Seat-based charges are prorated for mid-cycle additions and are non-refundable for partial billing periods. Failure to remit payment within the applicable grace period may result in suspension of platform access until the account is brought current.',
    requiredForRoles: ['PRACTICE_ADMIN']
  },
  {
    id: 'ai-use-acknowledgment',
    category: 'AI Use & Human Review Acknowledgment' as LegalAgreementCategory,
    title: 'AI Use & Human Review Acknowledgment',
    summary: 'Explains the role and limits of AI-generated suggestions within the platform.',
    version: 'v1.2',
    effectiveDate: '2026-02-14',
    bodyPreview:
      'Office Intelligence provides automated suggestions, readiness scoring, bottleneck detection, and administrative triage generated by machine-learning models. These outputs are decision-support tools only and are not a substitute for clinical judgment. All AI-generated recommendations must be reviewed by a qualified, licensed member of your care team before being relied upon for any clinical, scheduling, or billing decision. Your practice remains solely responsible for verifying the accuracy of any AI-assisted output prior to acting on it.',
    requiredForRoles: ['PRACTICE_ADMIN']
  },
  {
    id: 'mobile-app-terms',
    category: 'Mobile Application Terms' as LegalAgreementCategory,
    title: 'Mobile Application Terms',
    summary: 'Additional terms specific to the Office Intelligence mobile applications.',
    version: 'v1.1',
    effectiveDate: '2025-12-01',
    bodyPreview:
      'These Mobile Application Terms apply in addition to the general Terms of Use whenever you access Office Intelligence through its iOS or Android applications. Push notifications, biometric login, and offline data caching may be enabled or disabled from your device settings at any time. Any PHI cached locally on a mobile device is encrypted at rest and is automatically purged after a period of device inactivity or upon remote wipe initiated by your practice administrator.',
    requiredForRoles: ['PRACTICE_ADMIN']
  },
  {
    id: 'esignature-consent',
    category: 'E-Signature Consent' as LegalAgreementCategory,
    title: 'E-Signature Consent',
    summary: 'Confirms your consent to sign these agreements electronically.',
    version: 'v1.0',
    effectiveDate: '2025-08-20',
    bodyPreview:
      'By typing your full legal name and submitting this registration, you consent to using an electronic signature to execute these agreements in lieu of a physical, handwritten signature, in accordance with the U.S. Electronic Signatures in Global and National Commerce (E-SIGN) Act. You acknowledge that your typed name, together with the recorded timestamp, constitutes a legally binding signature. You may withdraw consent to electronic signatures for future transactions by contacting Office Intelligence support.',
    requiredForRoles: ['PRACTICE_ADMIN']
  },
  {
    id: 'admin-responsibility',
    category: 'Administrator Responsibility Agreement' as LegalAgreementCategory,
    title: 'Administrator Responsibility Agreement',
    summary: 'Defines the obligations of the practice administrator account on this platform.',
    version: 'v1.3',
    effectiveDate: '2026-03-01',
    bodyPreview:
      'As the Practice Administrator account holder, you are responsible for managing user access, provisioning and deprovisioning staff accounts, and maintaining the confidentiality of practice-level credentials. You agree to promptly remove access for any staff member who separates from the practice and to notify Office Intelligence of any suspected unauthorized access. Administrator-level actions, including permission changes and data exports, are logged and may be subject to periodic compliance audit.',
    requiredForRoles: ['PRACTICE_ADMIN']
  }
];

type WizardStep = 1 | 2 | 3;

const STEP_LABELS: Record<WizardStep, string> = {
  1: 'Account Info',
  2: 'Practice Type',
  3: 'Legal Agreements'
};

export const RegistrationPage: React.FC<RegistrationPageProps> = ({
  onRegisterSuccess,
  onNavigateLogin,
  onNavigateLanding
}) => {
  const [step, setStep] = useState<WizardStep>(1);

  // Step 1: Account Info
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [email, setEmail] = useState('');
  const [telephone, setTelephone] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  // Step 2: Practice Type
  const [practiceType, setPracticeType] = useState<PracticeType | null>(null);
  const [specialty, setSpecialty] = useState('');

  // Step 3: Legal Agreements
  const [acceptedAgreementIds, setAcceptedAgreementIds] = useState<Set<string>>(new Set());
  const [signatureName, setSignatureName] = useState('');
  const [viewingDocId, setViewingDocId] = useState<string | null>(null);

  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const toggleAgreement = (id: string) => {
    setAcceptedAgreementIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
      }
      return next;
    });
  };

  const validateStep1 = (): string | null => {
    if (!firstName.trim() || !lastName.trim()) {
      return 'Please enter both your first and last name.';
    }
    if (!email.trim() || !email.includes('@')) {
      return 'Please enter a valid practice email address.';
    }
    if (!telephone.trim()) {
      return 'Please enter your direct telephone number for 2-factor authentication & notifications.';
    }
    if (!password || password.length < 6) {
      return 'Password must be at least 6 characters long.';
    }
    if (password !== confirmPassword) {
      return 'Passwords do not match. Please re-enter your password.';
    }
    return null;
  };

  const validateStep2 = (): string | null => {
    if (!practiceType) {
      return 'Please select the practice type that best matches your organization.';
    }
    if (!specialty.trim()) {
      return 'Please enter your primary specialty.';
    }
    return null;
  };

  const validateStep3 = (): string | null => {
    if (acceptedAgreementIds.size < AGREEMENT_DOCS.length) {
      return 'You must review and check all 8 agreements to continue.';
    }
    if (!signatureName.trim()) {
      return 'Please type your full legal name to sign these agreements.';
    }
    return null;
  };

  const handleContinue = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    if (step === 1) {
      const err = validateStep1();
      if (err) {
        setErrorMessage(err);
        return;
      }
      setStep(2);
      return;
    }

    if (step === 2) {
      const err = validateStep2();
      if (err) {
        setErrorMessage(err);
        return;
      }
      setStep(3);
      return;
    }

    // step === 3 -> final submit
    const err = validateStep3();
    if (err) {
      setErrorMessage(err);
      return;
    }
    if (!practiceType) {
      setErrorMessage('Please select the practice type that best matches your organization.');
      return;
    }

    setIsLoading(true);

    const acceptedAtIso = new Date().toISOString();
    const agreementAcceptances: AgreementAcceptanceRecord[] = AGREEMENT_DOCS.map((doc) => ({
      agreementId: doc.id,
      version: doc.version,
      acceptedAt: acceptedAtIso,
      acceptedByUserId: 'pending',
      acceptedByName: signatureName.trim(),
      acceptanceMethod: 'Typed Signature',
      ipAddress: '—'
    }));

    setTimeout(() => {
      setIsLoading(false);
      onRegisterSuccess({
        firstName: firstName.trim(),
        lastName: lastName.trim(),
        email: email.trim(),
        telephone: telephone.trim(),
        practiceType,
        specialty: specialty.trim(),
        agreementAcceptances
      });
    }, 600);
  };

  const handleBack = () => {
    setErrorMessage(null);
    if (step === 2) setStep(1);
    if (step === 3) setStep(2);
  };

  const viewingDoc = AGREEMENT_DOCS.find((d) => d.id === viewingDocId) || null;
  const allAgreementsChecked = acceptedAgreementIds.size === AGREEMENT_DOCS.length;

  return (
    <div className="min-h-screen bg-[#F1F3EC] flex flex-col justify-between font-sans selection:bg-[#DCEEE3] selection:text-[#1B4332]">

      {/* Top Header */}
      <header className="p-6 flex items-center justify-between max-w-7xl w-full mx-auto">
        <button
          onClick={onNavigateLanding}
          className="flex items-center gap-2.5 text-xs font-semibold text-[#5B6B60] hover:text-[#1A2E22] transition-colors cursor-pointer group"
        >
          <ArrowLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform text-[#1F6E52]" />
          <span>Back to Office Intelligence Website</span>
        </button>

        <div className="flex items-center gap-2">
          <ShieldCheck className="w-4 h-4 text-[#1F6E52]" />
          <span className="text-[11px] font-bold text-[#5B6B60] uppercase tracking-wider">HIPAA Verified Onboarding</span>
        </div>
      </header>

      {/* Main Registration Container */}
      <main className="flex-1 flex items-center justify-center p-4 sm:p-6">
        <div className="w-full max-w-xl bg-white rounded-3xl border border-[#E1E4DC] shadow-xl p-8 sm:p-10 space-y-6 animate-in fade-in zoom-in-95 duration-200">

          {/* Logo & Title */}
          <div className="text-center space-y-2">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-[#14432E] via-[#1F6E52] to-[#2F9E6E] text-white flex items-center justify-center mx-auto shadow-md">
              <Sparkles className="w-6 h-6 text-[#DCEEE3]" />
            </div>
            <h1 className="text-2xl sm:text-3xl font-serif font-bold text-[#1A2E22] tracking-tight">
              Create Practice Account
            </h1>
            <p className="text-xs text-[#5B6B60] max-w-md mx-auto">
              Get started with Office Intelligence. After creating your account, you will be guided directly to Configure Practice setup.
            </p>
          </div>

          {/* Step Progress Indicator */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-bold text-[#1F6E52] uppercase tracking-wider">
                Step {step} of 3 — {STEP_LABELS[step]}
              </span>
              <span className="text-[11px] font-semibold text-[#5B6B60]">{Math.round((step / 3) * 100)}%</span>
            </div>
            <div className="flex items-center gap-1.5">
              {[1, 2, 3].map((s) => (
                <div
                  key={s}
                  className={`h-1.5 flex-1 rounded-full transition-colors ${
                    s <= step ? 'bg-[#1F6E52]' : 'bg-[#E1E4DC]'
                  }`}
                />
              ))}
            </div>
          </div>

          {/* Error Banner */}
          {errorMessage && (
            <div className="p-3.5 rounded-xl bg-[#FBE4E1] border border-[#C1503D]/30 text-[#7A2E22] text-xs flex items-start gap-2.5 animate-in shake">
              <AlertCircle className="w-4 h-4 text-[#C1503D] shrink-0 mt-0.5" />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* Registration Form */}
          <form onSubmit={handleContinue} className="space-y-4">

            {/* ============================================ */}
            {/* STEP 1: ACCOUNT INFO                          */}
            {/* ============================================ */}
            {step === 1 && (
              <>
                {/* First & Last Name Grid */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-[#1A2E22] flex items-center gap-1">
                      <span>First Name</span> <span className="text-[#C1503D]">*</span>
                    </label>
                    <input
                      type="text"
                      required
                      value={firstName}
                      onChange={(e) => setFirstName(e.target.value)}
                      placeholder="e.g. Stuart"
                      className="w-full px-3.5 py-2.5 rounded-xl border border-[#E1E4DC] focus:border-[#1F6E52] focus:ring-2 focus:ring-[#DCEEE3] text-xs text-[#1A2E22] outline-hidden transition-all bg-white"
                      autoComplete="given-name"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-[#1A2E22] flex items-center gap-1">
                      <span>Last Name</span> <span className="text-[#C1503D]">*</span>
                    </label>
                    <input
                      type="text"
                      required
                      value={lastName}
                      onChange={(e) => setLastName(e.target.value)}
                      placeholder="e.g. Sterling"
                      className="w-full px-3.5 py-2.5 rounded-xl border border-[#E1E4DC] focus:border-[#1F6E52] focus:ring-2 focus:ring-[#DCEEE3] text-xs text-[#1A2E22] outline-hidden transition-all bg-white"
                      autoComplete="family-name"
                    />
                  </div>
                </div>

                {/* Email Address */}
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-[#1A2E22] flex items-center gap-1">
                    <Mail className="w-3.5 h-3.5 text-[#5B6B60]" />
                    <span>Practice / Provider Email Address</span> <span className="text-[#C1503D]">*</span>
                  </label>
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="e.g. dr.linder@summitsurgical.com"
                    className="w-full px-3.5 py-2.5 rounded-xl border border-[#E1E4DC] focus:border-[#1F6E52] focus:ring-2 focus:ring-[#DCEEE3] text-xs text-[#1A2E22] outline-hidden transition-all bg-white"
                    autoComplete="email"
                  />
                </div>

                {/* Telephone Number */}
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-[#1A2E22] flex items-center gap-1">
                    <Phone className="w-3.5 h-3.5 text-[#5B6B60]" />
                    <span>Direct Telephone Number</span> <span className="text-[#C1503D]">*</span>
                  </label>
                  <input
                    type="tel"
                    required
                    value={telephone}
                    onChange={(e) => setTelephone(e.target.value)}
                    placeholder="e.g. (310) 859-2000"
                    className="w-full px-3.5 py-2.5 rounded-xl border border-[#E1E4DC] focus:border-[#1F6E52] focus:ring-2 focus:ring-[#DCEEE3] text-xs text-[#1A2E22] outline-hidden transition-all bg-white"
                    autoComplete="tel"
                  />
                  <p className="text-[11px] text-[#5B6B60]">Required for multi-factor authentication & clinical text alerts.</p>
                </div>

                {/* Password & Confirm Password Grid */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-[#1A2E22] flex items-center gap-1">
                      <Lock className="w-3.5 h-3.5 text-[#5B6B60]" />
                      <span>Create Password</span> <span className="text-[#C1503D]">*</span>
                    </label>
                    <div className="relative">
                      <input
                        type={showPassword ? 'text' : 'password'}
                        required
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        placeholder="Min 6 characters"
                        className="w-full px-3.5 py-2.5 rounded-xl border border-[#E1E4DC] focus:border-[#1F6E52] focus:ring-2 focus:ring-[#DCEEE3] text-xs text-[#1A2E22] outline-hidden transition-all pr-10 bg-white"
                        autoComplete="new-password"
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-[#5B6B60] hover:text-[#1A2E22] cursor-pointer"
                      >
                        {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-[#1A2E22] flex items-center gap-1">
                      <Lock className="w-3.5 h-3.5 text-[#5B6B60]" />
                      <span>Confirm Password</span> <span className="text-[#C1503D]">*</span>
                    </label>
                    <input
                      type={showPassword ? 'text' : 'password'}
                      required
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      placeholder="Re-enter password"
                      className="w-full px-3.5 py-2.5 rounded-xl border border-[#E1E4DC] focus:border-[#1F6E52] focus:ring-2 focus:ring-[#DCEEE3] text-xs text-[#1A2E22] outline-hidden transition-all bg-white"
                      autoComplete="new-password"
                    />
                  </div>
                </div>

                {/* Continue Button */}
                <button
                  type="submit"
                  disabled={isLoading}
                  id="registration-submit-btn"
                  className="w-full py-3.5 bg-gradient-to-r from-[#1F6E52] via-[#17553F] to-[#14432E] hover:from-[#17553F] hover:to-[#0F3524] text-white font-bold text-xs rounded-xl shadow-md hover:shadow-lg transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                >
                  <span>Continue to Practice Type</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </>
            )}

            {/* ============================================ */}
            {/* STEP 2: PRACTICE TYPE                         */}
            {/* ============================================ */}
            {step === 2 && (
              <>
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-[#1A2E22] flex items-center gap-1">
                    <Building2 className="w-3.5 h-3.5 text-[#5B6B60]" />
                    <span>What best describes your practice?</span> <span className="text-[#C1503D]">*</span>
                  </label>
                  <p className="text-[11px] text-[#5B6B60]">
                    This selection seeds your practice's default workflow profile — visit types, room templates, and readiness rules — which you can further customize during Configure Practice setup.
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {PRACTICE_TYPE_OPTIONS.map((option) => {
                    const Icon = option.icon;
                    const isSelected = practiceType === option.value;
                    return (
                      <button
                        key={option.value}
                        type="button"
                        onClick={() => setPracticeType(option.value)}
                        className={`text-left p-3.5 rounded-xl border transition-all cursor-pointer flex items-start gap-2.5 ${
                          isSelected
                            ? 'border-[#1F6E52] bg-[#DCEEE3]/40 ring-2 ring-[#DCEEE3]'
                            : 'border-[#E1E4DC] bg-white hover:border-[#1F6E52]/50'
                        }`}
                      >
                        <div
                          className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${
                            isSelected ? 'bg-[#1F6E52] text-white' : 'bg-[#F1F3EC] text-[#5B6B60]'
                          }`}
                        >
                          <Icon className="w-4 h-4" />
                        </div>
                        <div className="space-y-0.5 min-w-0">
                          <div className="flex items-center gap-1.5">
                            <span className="text-xs font-bold text-[#1A2E22]">{option.label}</span>
                            {isSelected && <Check className="w-3.5 h-3.5 text-[#1F6E52] shrink-0" />}
                          </div>
                          <p className="text-[11px] text-[#5B6B60] leading-snug">{option.description}</p>
                        </div>
                      </button>
                    );
                  })}
                </div>

                {/* Specialty */}
                <div className="space-y-1.5 pt-1">
                  <label className="text-xs font-bold text-[#1A2E22] flex items-center gap-1">
                    <Stethoscope className="w-3.5 h-3.5 text-[#5B6B60]" />
                    <span>Primary Specialty</span> <span className="text-[#C1503D]">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={specialty}
                    onChange={(e) => setSpecialty(e.target.value)}
                    placeholder="e.g. Orthopedic Surgery, Dermatology, Plastic Surgery"
                    className="w-full px-3.5 py-2.5 rounded-xl border border-[#E1E4DC] focus:border-[#1F6E52] focus:ring-2 focus:ring-[#DCEEE3] text-xs text-[#1A2E22] outline-hidden transition-all bg-white"
                  />
                </div>

                {/* Back / Continue Buttons */}
                <div className="flex items-center gap-3 pt-2">
                  <button
                    type="button"
                    onClick={handleBack}
                    className="px-5 py-3.5 rounded-xl border border-[#E1E4DC] text-[#5B6B60] font-bold text-xs hover:bg-[#F1F3EC] transition-all flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <ArrowLeft className="w-4 h-4" />
                    <span>Back</span>
                  </button>
                  <button
                    type="submit"
                    className="flex-1 py-3.5 bg-gradient-to-r from-[#1F6E52] via-[#17553F] to-[#14432E] hover:from-[#17553F] hover:to-[#0F3524] text-white font-bold text-xs rounded-xl shadow-md hover:shadow-lg transition-all flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <span>Continue to Legal Agreements</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </>
            )}

            {/* ============================================ */}
            {/* STEP 3: LEGAL AGREEMENTS                      */}
            {/* ============================================ */}
            {step === 3 && (
              <>
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-[#1A2E22] flex items-center gap-1">
                    <ClipboardList className="w-3.5 h-3.5 text-[#5B6B60]" />
                    <span>Review & Accept Required Agreements</span> <span className="text-[#C1503D]">*</span>
                  </label>
                  <p className="text-[11px] text-[#5B6B60]">
                    Each agreement must be individually reviewed and checked before your account can be created.
                  </p>
                </div>

                <div className="space-y-2">
                  {AGREEMENT_DOCS.map((doc) => {
                    const checked = acceptedAgreementIds.has(doc.id);
                    return (
                      <div
                        key={doc.id}
                        className={`p-3 rounded-xl border transition-all ${
                          checked ? 'border-[#1F6E52]/40 bg-[#DCEEE3]/20' : 'border-[#E1E4DC] bg-[#F1F3EC]'
                        }`}
                      >
                        <div className="flex items-start gap-2.5">
                          <input
                            type="checkbox"
                            checked={checked}
                            onChange={() => toggleAgreement(doc.id)}
                            className="mt-0.5 w-4 h-4 rounded-sm border-[#E1E4DC] text-[#1F6E52] focus:ring-[#1F6E52] cursor-pointer accent-[#1F6E52]"
                            id={`agreement-checkbox-${doc.id}`}
                          />
                          <div className="flex-1 min-w-0 space-y-0.5">
                            <div className="flex items-center justify-between gap-2 flex-wrap">
                              <span className="text-xs font-bold text-[#1A2E22]">{doc.title}</span>
                              <button
                                type="button"
                                onClick={() => setViewingDocId(doc.id)}
                                className="text-[11px] font-bold text-[#1F6E52] hover:text-[#17553F] hover:underline cursor-pointer flex items-center gap-1"
                              >
                                <FileText className="w-3 h-3" />
                                <span>View</span>
                              </button>
                            </div>
                            <p className="text-[11px] text-[#5B6B60] leading-snug">{doc.summary}</p>
                            <p className="text-[10px] font-mono text-[#5B6B60]">
                              {doc.version} · Effective {doc.effectiveDate}
                            </p>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>

                <div className="flex items-center gap-2 text-[11px] text-[#5B6B60]">
                  {allAgreementsChecked ? (
                    <CheckCircle2 className="w-3.5 h-3.5 text-[#2F9E6E]" />
                  ) : (
                    <AlertCircle className="w-3.5 h-3.5 text-[#5B6B60]" />
                  )}
                  <span>{acceptedAgreementIds.size} of {AGREEMENT_DOCS.length} agreements reviewed & checked</span>
                </div>

                {/* Typed E-Signature */}
                <div className="space-y-1.5 pt-1">
                  <label className="text-xs font-bold text-[#1A2E22] flex items-center gap-1">
                    <FileSignature className="w-3.5 h-3.5 text-[#5B6B60]" />
                    <span>Type your full legal name to sign</span> <span className="text-[#C1503D]">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={signatureName}
                    onChange={(e) => setSignatureName(e.target.value)}
                    placeholder="e.g. Stuart J. Sterling"
                    className="w-full px-3.5 py-2.5 rounded-xl border border-[#E1E4DC] focus:border-[#1F6E52] focus:ring-2 focus:ring-[#DCEEE3] text-xs text-[#1A2E22] outline-hidden transition-all bg-white font-serif italic"
                    id="registration-esignature-input"
                  />
                  <p className="text-[11px] text-[#5B6B60]">
                    This typed name will be recorded as your electronic signature on all 8 agreements above, along with a timestamp.
                  </p>
                </div>

                {/* Back / Submit Buttons */}
                <div className="flex items-center gap-3 pt-2">
                  <button
                    type="button"
                    onClick={handleBack}
                    className="px-5 py-3.5 rounded-xl border border-[#E1E4DC] text-[#5B6B60] font-bold text-xs hover:bg-[#F1F3EC] transition-all flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <ArrowLeft className="w-4 h-4" />
                    <span>Back</span>
                  </button>
                  <button
                    type="submit"
                    disabled={isLoading}
                    id="registration-submit-btn"
                    className="flex-1 py-3.5 bg-gradient-to-r from-[#1F6E52] via-[#17553F] to-[#14432E] hover:from-[#17553F] hover:to-[#0F3524] text-white font-bold text-xs rounded-xl shadow-md hover:shadow-lg transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                  >
                    {isLoading ? (
                      <span>Creating Practice Account & Provisioning Security...</span>
                    ) : (
                      <>
                        <UserPlus className="w-4 h-4 text-[#DCEEE3]" />
                        <span>Create Account & Configure Practice</span>
                        <ArrowRight className="w-4 h-4" />
                      </>
                    )}
                  </button>
                </div>
              </>
            )}

          </form>

          {/* Link to Log In */}
          <div className="text-center pt-2 border-t border-[#E1E4DC]">
            <p className="text-xs text-[#5B6B60]">
              Already have an Office Intelligence account?{' '}
              <button
                type="button"
                onClick={onNavigateLogin}
                id="registration-login-link"
                className="font-bold text-[#1F6E52] hover:text-[#17553F] hover:underline cursor-pointer"
              >
                Log In
              </button>
            </p>
          </div>

        </div>
      </main>

      {/* Agreement Document Viewer Modal */}
      {viewingDoc && (
        <div className="fixed inset-0 z-50 bg-[#1A2E22]/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl border border-[#E1E4DC] shadow-2xl p-6 max-w-lg w-full space-y-4 max-h-[85vh] flex flex-col">
            <div className="flex items-center justify-between border-b border-[#E1E4DC] pb-3">
              <h3 className="text-base font-bold text-[#1A2E22] flex items-center gap-2">
                <FileText className="w-4 h-4 text-[#1F6E52]" />
                <span>{viewingDoc.title}</span>
              </h3>
              <button
                onClick={() => setViewingDocId(null)}
                className="text-[#5B6B60] hover:text-[#1A2E22] cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="text-[10px] font-mono text-[#5B6B60]">
              {viewingDoc.version} · Effective {viewingDoc.effectiveDate}
            </p>

            <div className="flex-1 overflow-y-auto text-xs text-[#5B6B60] space-y-3 pr-2">
              <p>{viewingDoc.bodyPreview}</p>
            </div>

            <div className="border-t border-[#E1E4DC] pt-3 flex justify-end gap-2">
              <button
                onClick={() => setViewingDocId(null)}
                className="px-4 py-2 rounded-xl text-xs font-bold text-[#5B6B60] hover:bg-[#F1F3EC] cursor-pointer"
              >
                Close
              </button>
              <button
                onClick={() => {
                  setAcceptedAgreementIds((prev) => {
                    const next = new Set(prev);
                    next.add(viewingDoc.id);
                    return next;
                  });
                  setViewingDocId(null);
                }}
                className="px-4 py-2 bg-[#1F6E52] text-white rounded-xl text-xs font-bold hover:bg-[#17553F] cursor-pointer"
              >
                I Have Read & Agree
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Footer */}
      <footer className="p-6 text-center text-xs text-[#5B6B60]">
        <p>© 2026 Office Intelligence Systems Inc. HIPAA-Compliant Medical Operating Platform.</p>
      </footer>

    </div>
  );
};
