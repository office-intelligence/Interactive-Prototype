import React, { useEffect, useMemo, useRef, useState } from 'react';
import * as pdfjsLib from 'pdfjs-dist';
// eslint-disable-next-line import/no-unresolved
import pdfjsWorkerUrl from 'pdfjs-dist/build/pdf.worker.min.mjs?url';
import { PenTool, Type, Eraser, Loader2 } from 'lucide-react';
import { MinimalWorkflowHeader } from './MinimalWorkflowHeader';
import {
  loadPdfDocMeta,
  readPdfFieldDefaults,
  loadStoredPdfDoc,
  saveDraftPdfDoc,
  lockPdfDoc,
  type PdfDocMeta,
  type PdfFieldMeta,
  type PdfDraftState,
  type PdfDocStatus,
} from '../utils/pdfFormEngine';

pdfjsLib.GlobalWorkerOptions.workerSrc = pdfjsWorkerUrl;

interface PdfFormViewerProps {
  patientId: string;
  documentId: string;
  title: string;
  /** Fetched from this URL when `pdfBytesOverride` isn't provided — used by
   *  the pre-registered catalog documents (pdfFormDocuments.ts). */
  pdfUrl: string;
  /** Raw PDF bytes to use directly instead of fetching `pdfUrl` — used by the
   *  generic "upload any PDF and try it" flow, where the bytes come from a
   *  local file the person picked rather than a static asset. */
  pdfBytesOverride?: ArrayBuffer;
  signerName: string;
  /** Values to prefill for specific named fields (e.g. carried over from another
   *  document, or from the patient's chart). Applied on top of the PDF's own
   *  baked-in template defaults, and only for a brand-new draft — never
   *  overwrites what a person already typed. */
  prefill?: Record<string, string | boolean>;
  onClose: () => void;
  onSaved?: (mode: 'draft' | 'locked') => void | Promise<void>;
}

const PEN_COLOR = '#1B4332';

export const PdfFormViewer: React.FC<PdfFormViewerProps> = ({
  patientId,
  documentId,
  title,
  pdfUrl,
  pdfBytesOverride,
  signerName,
  prefill,
  onClose,
  onSaved,
}) => {
  type PageView = { pageIndex:number; width:number; height:number };
  type PendingText = { pageIndex:number; x:number; y:number } | null;

  const [loading,setLoading]=useState(true);
  const [error,setError]=useState<string|null>(null);
  const [pdfBytes,setPdfBytes]=useState<ArrayBuffer|null>(null);
  const [meta,setMeta]=useState<PdfDocMeta|null>(null);
  const [status,setStatus]=useState<PdfDocStatus>('DRAFT');

  const [fieldValues,setFieldValues]=useState<Record<string,string|boolean>>({});
  const [signatureImages,setSignatureImages]=useState<Record<string,string>>({});
  const [penStrokes,setPenStrokes]=useState<Array<{pageIndex?:number;points:{x:number;y:number}[];color:string}>>([]);
  const [textAnnotations,setTextAnnotations]=useState<Array<{pageIndex?:number;x:number;y:number;text:string}>>([]);
  const [saving,setSaving]=useState<'idle'|'draft'>('idle');
  const [savedFlash,setSavedFlash]=useState(false);
  const [draftReady,setDraftReady]=useState(false);
  const [tool,setTool]=useState<'select'|'pen'|'text'>('select');
  const [pendingTextAt,setPendingTextAt]=useState<PendingText>(null);
  const [pendingTextValue,setPendingTextValue]=useState('');
  const [pageViews,setPageViews]=useState<PageView[]>([]);
  const [pageFieldRects,setPageFieldRects]=useState<Record<number,Array<{
    name:string;
    kind:'text'|'checkbox'|'signature';
    widgetIndex:number;
    left:number; top:number; width:number; height:number;
  }>>>({});

  const [windowWidth,setWindowWidth]=useState(()=>window.innerWidth);

  const pageCanvasRefs=useRef<Array<HTMLCanvasElement|null>>([]);
  const drawCanvasRefs=useRef<Array<HTMLCanvasElement|null>>([]);
  const viewportRefs=useRef<Array<pdfjsLib.PageViewport|null>>([]);
  const isDrawingRef=useRef(false);
  const activeDrawingPageRef=useRef<number|null>(null);
  const currentStrokeRef=useRef<{x:number;y:number}[]>([]);
  const penStrokesRef=useRef<typeof penStrokes>([]);
  const pageViewsRef=useRef<PageView[]>([]);
  const autosaveTimerRef=useRef<number|null>(null);
  const notifiedSavedRef=useRef(false);
  const userEditedRef=useRef(false);

  const isLocked=false;
  const readableWidth=Math.min(980,Math.max(560,windowWidth-56));

  useEffect(()=>{
    const onResize=()=>setWindowWidth(window.innerWidth);
    window.addEventListener('resize',onResize);
    return()=>window.removeEventListener('resize',onResize);
  },[]);

  useEffect(()=>{
    let cancelled=false;
    (async()=>{
      try{
        setLoading(true);
        setError(null);
        setDraftReady(false);
        let bytes:ArrayBuffer;
        if(pdfBytesOverride) bytes=pdfBytesOverride;
        else{
          const res=await fetch(pdfUrl);
          if(!res.ok) throw new Error(`Could not load PDF (${res.status})`);
          bytes=await res.arrayBuffer();
        }
        if(cancelled)return;
        setPdfBytes(bytes);
        const docMeta=await loadPdfDocMeta(bytes.slice(0));
        if(cancelled)return;
        setMeta(docMeta);

        const stored=loadStoredPdfDoc(patientId,documentId);
        if(stored?.status==='LOCKED'){
          // Legacy locked records are reopened as editable drafts. The saved
          // draft already contains the user's field values and annotations.
          setStatus('DRAFT');
          setFieldValues(stored.draft.fieldValues);
          setSignatureImages(stored.draft.signatureImages);
          penStrokesRef.current=stored.draft.penStrokes || [];
          setPenStrokes(penStrokesRef.current);
          setTextAnnotations(stored.draft.textAnnotations || []);
        }else if(stored?.status==='DRAFT'){
          setStatus('DRAFT');
          setFieldValues(stored.draft.fieldValues);
          setSignatureImages(stored.draft.signatureImages);
          penStrokesRef.current=stored.draft.penStrokes || [];
          setPenStrokes(penStrokesRef.current);
          setTextAnnotations(stored.draft.textAnnotations || []);
        }else{
          const defaults=await readPdfFieldDefaults(bytes.slice(0));
          const merged:Record<string,string|boolean>={...defaults};
          if(prefill){
            for(const [k,v] of Object.entries(prefill) as [string,string|boolean][]) if(k in merged) merged[k]=v;
          }
          setStatus('DRAFT');
          setFieldValues(merged);
        }
        setDraftReady(true);
      }catch(e){
        if(!cancelled)setError(e instanceof Error?e.message:'Failed to load PDF');
      }finally{
        if(!cancelled)setLoading(false);
      }
    })();
    return()=>{cancelled=true;};
    // eslint-disable-next-line react-hooks/exhaustive-deps
  },[pdfUrl,patientId,documentId,pdfBytesOverride]);

  // Continuous-document renderer: every PDF page is rendered, top-to-bottom,
  // at a comfortable Word-like reading width. Height never participates in
  // scale calculation, so pages are not shrunk just to fit the monitor.
  useEffect(()=>{
    const bytesToRender=pdfBytes ? new Uint8Array(pdfBytes) : null;
    if(!bytesToRender || loading)return;

    let cancelled=false;
    const tasks:Array<{cancel:()=>void}>=[];
    (async()=>{
      const loadingTask=pdfjsLib.getDocument({data:bytesToRender.slice(0)});
      const doc=await loadingTask.promise;
      if(cancelled)return;

      const views:PageView[]=[];
      const baseViewports:Array<pdfjsLib.PageViewport|null>=[];
      const fieldRectsByPage:Record<number,Array<{
        name:string; kind:'text'|'checkbox'|'signature'; widgetIndex:number;
        left:number; top:number; width:number; height:number;
      }>>={};

      for(let pageNumber=1;pageNumber<=doc.numPages;pageNumber++){
        const pageIndex=pageNumber-1;
        const page=await doc.getPage(pageNumber);
        if(cancelled)return;
        const unscaled=page.getViewport({scale:1});
        const scale=readableWidth/unscaled.width;
        const baseViewport=page.getViewport({scale});
        views.push({pageIndex,width:baseViewport.width,height:baseViewport.height});
        baseViewports[pageIndex]=baseViewport;

        // PDF.js exposes each widget on the page where it actually belongs.
        // This prevents a multi-page form's controls from being stacked on page 1.
        const annotations:any[]=await page.getAnnotations({intent:'display'});
        const rects:Array<{
          name:string; kind:'text'|'checkbox'|'signature'; widgetIndex:number;
          left:number; top:number; width:number; height:number;
        }>=[];
        annotations.forEach((ann:any,widgetIndex:number)=>{
          if(!ann?.fieldName || !Array.isArray(ann.rect)) return;
          let kind:'text'|'checkbox'|'signature'|null=null;
          if(ann.fieldType==='Tx') kind='text';
          else if(ann.fieldType==='Sig') kind='signature';
          else if(ann.fieldType==='Btn' && (ann.checkBox || !ann.radioButton)) kind='checkbox';
          if(!kind) return;
          const vr=baseViewport.convertToViewportRectangle(ann.rect);
          const left=Math.min(vr[0],vr[2]);
          const top=Math.min(vr[1],vr[3]);
          const width=Math.abs(vr[2]-vr[0]);
          const height=Math.abs(vr[3]-vr[1]);
          if(width>0 && height>0) rects.push({name:ann.fieldName,kind,widgetIndex,left,top,width,height});
        });
        fieldRectsByPage[pageIndex]=rects;
      }

      viewportRefs.current=baseViewports;
      pageViewsRef.current=views;
      setPageFieldRects(fieldRectsByPage);
      setPageViews(views);

      // Wait until React mounts all canvas elements.
      await new Promise<void>((resolve)=>requestAnimationFrame(()=>resolve()));
      if(cancelled)return;

      const dpr=Math.min(window.devicePixelRatio || 1,2);
      for(let pageNumber=1;pageNumber<=doc.numPages;pageNumber++){
        const pageIndex=pageNumber-1;
        const canvas=pageCanvasRefs.current[pageIndex];
        const drawCanvas=drawCanvasRefs.current[pageIndex];
        const baseViewport=baseViewports[pageIndex];
        if(!canvas || !baseViewport)continue;

        const page=await doc.getPage(pageNumber);
        const renderViewport=page.getViewport({scale:(baseViewport.width/page.getViewport({scale:1}).width)*dpr});
        canvas.width=renderViewport.width;
        canvas.height=renderViewport.height;
        canvas.style.width=`${baseViewport.width}px`;
        canvas.style.height=`${baseViewport.height}px`;
        const ctx=canvas.getContext('2d');
        if(!ctx)continue;
        const task=page.render({
          canvasContext:ctx,
          viewport:renderViewport,
          annotationMode:pdfjsLib.AnnotationMode.DISABLE,
        });
        tasks.push(task);
        try{await task.promise;}catch(e){if(!cancelled)console.error('PDF page render failed',e);}

        if(drawCanvas){
          drawCanvas.width=baseViewport.width;
          drawCanvas.height=baseViewport.height;
          drawCanvas.style.width=`${baseViewport.width}px`;
          drawCanvas.style.height=`${baseViewport.height}px`;
          redrawPageStrokes(pageIndex);
        }
      }
      if(!cancelled)redrawAllStrokes();
    })();

    return()=>{
      cancelled=true;
      tasks.forEach(task=>task.cancel());
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  },[pdfBytes,loading,readableWidth]);

  function redrawPageStrokes(pageIndex:number){
    const canvas=drawCanvasRefs.current[pageIndex];
    const viewport=viewportRefs.current[pageIndex];
    if(!canvas || !viewport)return;
    const ctx=canvas.getContext('2d');
    if(!ctx)return;

    ctx.clearRect(0,0,canvas.width,canvas.height);
    ctx.lineCap='round';
    ctx.lineJoin='round';

    for(const stroke of penStrokesRef.current){
      if((stroke.pageIndex??0)!==pageIndex || stroke.points.length<2)continue;
      ctx.strokeStyle=stroke.color;
      ctx.lineWidth=2.25;
      ctx.beginPath();
      const first=viewport.convertToViewportPoint(stroke.points[0].x,stroke.points[0].y);
      ctx.moveTo(first[0],first[1]);
      for(let i=1;i<stroke.points.length;i++){
        const pt=viewport.convertToViewportPoint(stroke.points[i].x,stroke.points[i].y);
        ctx.lineTo(pt[0],pt[1]);
      }
      ctx.stroke();
    }
  }

  function redrawAllStrokes(){
    const pages=pageViewsRef.current.length
      ? pageViewsRef.current.map(view=>view.pageIndex)
      : viewportRefs.current.map((_,index)=>index);
    pages.forEach(redrawPageStrokes);
  }

  useEffect(()=>{
    penStrokesRef.current=penStrokes;
    pageViewsRef.current=pageViews;
    redrawAllStrokes();
    /* eslint-disable-next-line react-hooks/exhaustive-deps */
  },[penStrokes,pageViews]);

  function canvasPoint(pageIndex:number,e:React.MouseEvent|React.TouchEvent){
    const canvas=drawCanvasRefs.current[pageIndex];
    if(!canvas)return null;
    const rect=canvas.getBoundingClientRect();
    const clientX='touches' in e?e.touches[0]?.clientX:(e as React.MouseEvent).clientX;
    const clientY='touches' in e?e.touches[0]?.clientY:(e as React.MouseEvent).clientY;
    if(clientX===undefined||clientY===undefined)return null;
    return {
      x:(clientX-rect.left)*(canvas.width/rect.width),
      y:(clientY-rect.top)*(canvas.height/rect.height),
    };
  }

  function penDown(pageIndex:number,e:React.MouseEvent|React.TouchEvent){
    if(tool!=='pen')return;
    const pt=canvasPoint(pageIndex,e);
    if(!pt)return;
    e.preventDefault();
    isDrawingRef.current=true;
    activeDrawingPageRef.current=pageIndex;
    currentStrokeRef.current=[pt];
  }

  function penMove(pageIndex:number,e:React.MouseEvent|React.TouchEvent){
    if(tool!=='pen'||!isDrawingRef.current||activeDrawingPageRef.current!==pageIndex)return;
    const pt=canvasPoint(pageIndex,e);
    if(!pt)return;
    e.preventDefault();
    const canvas=drawCanvasRefs.current[pageIndex];
    const ctx=canvas?.getContext('2d');
    const prev=currentStrokeRef.current[currentStrokeRef.current.length-1];
    if(ctx&&prev){
      ctx.strokeStyle=PEN_COLOR;ctx.lineWidth=2.25;ctx.lineCap='round';
      ctx.beginPath();ctx.moveTo(prev.x,prev.y);ctx.lineTo(pt.x,pt.y);ctx.stroke();
    }
    currentStrokeRef.current.push(pt);
  }

  function penUp(pageIndex:number){
    if(tool!=='pen'||!isDrawingRef.current||activeDrawingPageRef.current!==pageIndex)return;
    isDrawingRef.current=false;
    const viewport=viewportRefs.current[pageIndex];
    if(viewport&&currentStrokeRef.current.length>1){
      const pdfPoints=currentStrokeRef.current.map(p=>{
        const [x,y]=viewport.convertToPdfPoint(p.x,p.y);
        return {x,y};
      });
      userEditedRef.current=true;
      setPenStrokes(prev=>{
        const next=[...prev,{pageIndex,points:pdfPoints,color:PEN_COLOR}];
        penStrokesRef.current=next;
        return next;
      });
    }
    currentStrokeRef.current=[];
    activeDrawingPageRef.current=null;
  }

  function overlayClick(pageIndex:number,e:React.MouseEvent){
    if(tool!=='text')return;
    const canvas=drawCanvasRefs.current[pageIndex];
    if(!canvas)return;
    const rect=canvas.getBoundingClientRect();
    setPendingTextAt({pageIndex,x:e.clientX-rect.left,y:e.clientY-rect.top});
    setPendingTextValue('');
  }

  function commitPendingText(){
    if(!pendingTextAt||!pendingTextValue.trim()){setPendingTextAt(null);return;}
    const viewport=viewportRefs.current[pendingTextAt.pageIndex];
    if(!viewport){setPendingTextAt(null);return;}
    const [x,y]=viewport.convertToPdfPoint(pendingTextAt.x,pendingTextAt.y);
    userEditedRef.current=true;
    setTextAnnotations(prev=>[...prev,{pageIndex:pendingTextAt.pageIndex,x,y:y-3,text:pendingTextValue.trim()}]);
    setPendingTextAt(null);
    setPendingTextValue('');
  }



  function currentDraft(extraText?:{pageIndex:number;x:number;y:number;text:string}):PdfDraftState{
    const text = extraText ? [...textAnnotations,extraText] : textAnnotations;
    return {fieldValues,signatureImages,penStrokes,textAnnotations:text,lastSavedAt:new Date().toISOString()};
  }

  async function persistDraft(draft:PdfDraftState=currentDraft(), notify=true){
    saveDraftPdfDoc(patientId,documentId,draft);
    setSavedFlash(true);
    window.setTimeout(()=>setSavedFlash(false),1200);
    if(notify && !notifiedSavedRef.current){
      notifiedSavedRef.current=true;
      await onSaved?.('draft');
    }
  }

  // Background autosave. Every meaningful edit is debounced so typing does
  // not write on every keystroke, while pen/text/signature changes are
  // retained even if the viewer is closed shortly afterward.
  useEffect(()=>{
    if(!draftReady || loading || !userEditedRef.current)return;
    if(autosaveTimerRef.current)window.clearTimeout(autosaveTimerRef.current);
    setSaving('draft');
    autosaveTimerRef.current=window.setTimeout(async()=>{
      try{await persistDraft(currentDraft());}
      finally{setSaving('idle');}
    },300);
    return()=>{
      if(autosaveTimerRef.current)window.clearTimeout(autosaveTimerRef.current);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  },[draftReady,fieldValues,signatureImages,penStrokes,textAnnotations]);

  async function handleDone(){
    if(autosaveTimerRef.current){
      window.clearTimeout(autosaveTimerRef.current);
      autosaveTimerRef.current=null;
    }
    setSaving('draft');
    try{
      let draft=currentDraft();
      // If a typed note editor is still open, include its current value in
      // the final background save before closing.
      if(pendingTextAt && pendingTextValue.trim()){
        const viewport=viewportRefs.current[pendingTextAt.pageIndex];
        if(viewport){
          const [x,y]=viewport.convertToPdfPoint(pendingTextAt.x,pendingTextAt.y);
          draft=currentDraft({
            pageIndex:pendingTextAt.pageIndex,
            x,
            y:y-3,
            text:pendingTextValue.trim(),
          });
        }
      }
      await persistDraft(draft);
      onClose();
    }finally{
      setSaving('idle');
    }
  }

  const PEN_CURSOR=`url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='28' height='28' viewBox='0 0 28 28'%3E%3Cpath d='M5 22l2.2-6.8L19.8 2.6a2.1 2.1 0 0 1 3 0l2.6 2.6a2.1 2.1 0 0 1 0 3L12.8 20.8 6 23z' fill='%231B4332' stroke='white' stroke-width='1.2'/%3E%3Cpath d='M7.2 15.2l5.6 5.6' stroke='white' stroke-width='1.2'/%3E%3C/svg%3E") 5 24, crosshair`;

  return (
    <div className="fixed inset-0 z-[99999] bg-stone-100 flex flex-col w-screen h-screen overflow-hidden animate-in fade-in duration-150">
      <MinimalWorkflowHeader title={title} onClose={handleDone} actionLabel="Done"/>

      {!isLocked&&!loading&&!error&&(
        <div className="shrink-0 bg-stone-50 border-b border-stone-200 px-3 sm:px-5 py-2 flex flex-wrap items-center gap-2">
          <button type="button" onClick={()=>setTool(tool==='pen'?'select':'pen')} title="Pen tool"
            className={`px-2.5 py-1.5 text-xs font-bold flex items-center gap-1.5 border ${tool==='pen'?'bg-teal-600 text-white border-teal-600':'bg-white text-stone-700 border-stone-300'}`}>
            <PenTool className="w-3.5 h-3.5"/><span>Pen</span>
          </button>
          <button type="button" onClick={()=>setTool(tool==='text'?'select':'text')} title="Text tool"
            className={`px-2.5 py-1.5 text-xs font-bold flex items-center gap-1.5 border ${tool==='text'?'bg-teal-600 text-white border-teal-600':'bg-white text-stone-700 border-stone-300'}`}>
            <Type className="w-3.5 h-3.5"/><span>Text</span>
          </button>
          {penStrokes.length>0&&<button type="button" onClick={()=>{userEditedRef.current=true;penStrokesRef.current=[];setPenStrokes([]);}} className="px-2.5 py-1.5 text-xs font-bold flex items-center gap-1.5 border bg-white text-stone-700 border-stone-300">
            <Eraser className="w-3.5 h-3.5"/><span>Clear Pen</span>
          </button>}
          <div className="ml-auto flex items-center gap-3 text-[10.5px] text-stone-500 font-bold">
            <span className="flex items-center gap-1.5">
              {saving==='draft' ? <><Loader2 className="w-3 h-3 animate-spin"/>Saving…</> : savedFlash ? 'Saved' : 'Autosave on'}
            </span>
            {pageViews.length>1&&<span>{pageViews.length} pages · continuous view</span>}
          </div>
        </div>
      )}

      <div className="flex-1 overflow-y-auto overflow-x-auto bg-stone-200/60 px-3 sm:px-6 py-5">
        {loading&&<div className="py-24 flex flex-col items-center gap-3 text-stone-500"><Loader2 className="w-6 h-6 animate-spin"/><span className="text-xs font-bold">Loading PDF…</span></div>}
        {error&&<div className="py-24 flex flex-col items-center gap-2 text-red-600"><span className="text-xs font-bold">Couldn't load this document.</span><span className="text-[11px]">{error}</span></div>}

        {!loading&&!error&&(
          <div className="mx-auto flex flex-col items-center gap-5 pb-10" style={{width:readableWidth}}>
            {pageViews.map((view)=>(
              <div key={view.pageIndex} className="relative bg-white shadow-md border border-stone-300" style={{width:view.width,height:view.height}}>
                <canvas ref={el=>{pageCanvasRefs.current[view.pageIndex]=el;}} className="absolute inset-0"/>

                {(pageFieldRects[view.pageIndex] || []).map(({name,kind,widgetIndex,left,top,width,height})=>{
                  const key=`${view.pageIndex}_${name}__${widgetIndex}`;
                  if(kind==='text')return <input key={key} type="text" value={typeof fieldValues[name]==='string'?fieldValues[name] as string:''}
                    onChange={e=>{userEditedRef.current=true;setFieldValues(prev=>({...prev,[name]:e.target.value}));}}
                    title="Click to enter text"
                    className="absolute bg-[#E7F1F3]/18 hover:bg-[#E7F1F3]/32 focus:bg-white/94 border border-[#3E8FA6]/45 hover:border-[#3E8FA6]/75 focus:border-[#1F6E52] text-[11px] text-slate-900 px-1 outline-none shadow-[inset_0_0_0_1px_rgba(255,255,255,0.25)]"
                    style={{left,top,width,height,pointerEvents:tool==='select'?'auto':'none'}}/>;
                  if(kind==='checkbox'){
                    const checked=Boolean(fieldValues[name]);
                    return <button key={key} type="button" onClick={()=>{userEditedRef.current=true;setFieldValues(prev=>({...prev,[name]:!checked}));}}
                      title="Click to select"
                      className={`absolute border flex items-center justify-center shadow-[0_0_0_1px_rgba(255,255,255,0.45)] ${checked?'bg-[#1F6E52] border-[#1F6E52]':'bg-[#F4EFE3]/35 border-[#D9A448]/70 hover:bg-[#FBEEDB]/60 hover:border-[#C98A34]'}`}
                      style={{left,top,width,height,pointerEvents:tool==='select'?'auto':'none'}}>
                      {checked&&<span className="text-white text-[10px] font-black">✓</span>}
                    </button>;
                  }
                  if(kind==='signature')return <div key={key} title="Click to sign" className="absolute border border-[#D9A448]/65 hover:border-[#C98A34] bg-[#FBEEDB]/14 hover:bg-[#FBEEDB]/30 overflow-hidden shadow-[inset_0_0_0_1px_rgba(255,255,255,0.25)]"
                    style={{left,top,width,height,pointerEvents:tool==='select'?'auto':'none'}}>
                    {signatureImages[name]?<img src={signatureImages[name]} className="w-full h-full object-contain" alt="Signature"/>:<MiniSignatureCapture onSave={data=>{userEditedRef.current=true;setSignatureImages(prev=>({...prev,[name]:data}));}}/>}
                  </div>;
                  return null;
                })}

                <canvas
                  ref={el=>{drawCanvasRefs.current[view.pageIndex]=el;}}
                  className="absolute inset-0"
                  style={{
                    cursor:tool==='pen'?PEN_CURSOR:tool==='text'?'text':'default',
                    touchAction:'none',
                    pointerEvents:tool==='select'?'none':'auto',
                  }}
                  onMouseDown={e=>penDown(view.pageIndex,e)}
                  onMouseMove={e=>penMove(view.pageIndex,e)}
                  onMouseUp={()=>penUp(view.pageIndex)}
                  onMouseLeave={()=>penUp(view.pageIndex)}
                  onTouchStart={e=>penDown(view.pageIndex,e)}
                  onTouchMove={e=>penMove(view.pageIndex,e)}
                  onTouchEnd={()=>penUp(view.pageIndex)}
                  onClick={e=>overlayClick(view.pageIndex,e)}
                />

                {textAnnotations.filter(a=>(a.pageIndex??0)===view.pageIndex).map((ann,i)=>{
                  const viewport=viewportRefs.current[view.pageIndex];
                  if(!viewport)return null;
                  const [left,top]=viewport.convertToViewportPoint(ann.x,ann.y);
                  return <div key={i} className="absolute text-[10px] font-bold text-[#1B4332] bg-white/75 px-0.5 pointer-events-none" style={{left,top:top-12}}>{ann.text}</div>;
                })}

                {pendingTextAt?.pageIndex===view.pageIndex&&<input autoFocus type="text" value={pendingTextValue}
                  onChange={e=>setPendingTextValue(e.target.value)}
                  onBlur={commitPendingText}
                  onKeyDown={e=>{if(e.key==='Enter')commitPendingText();if(e.key==='Escape')setPendingTextAt(null);}}
                  placeholder="Type a note…"
                  className="absolute z-10 bg-white border-2 border-teal-500 text-[11px] font-bold text-[#1B4332] px-1.5 py-0.5 outline-none shadow-lg"
                  style={{left:pendingTextAt.x,top:pendingTextAt.y-10,minWidth:90}}/>
                }

                {pageViews.length>1&&<div className="absolute -bottom-4 left-1/2 -translate-x-1/2 text-[9px] text-stone-500 bg-stone-200/80 px-2">{view.pageIndex+1}</div>}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

// A compact, inline freehand signature capture used for /Sig fields — same
// draw mechanics as SignaturePad.tsx, sized to fit inside the field's own
// widget rect instead of a fixed panel.
const MiniSignatureCapture: React.FC<{ onSave: (dataUrl: string) => void }> = ({ onSave }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const drawingRef = useRef(false);
  const lastRef = useRef<{ x: number; y: number } | null>(null);
  const [hasStroke, setHasStroke] = useState(false);

  const getPoint = (e: React.MouseEvent | React.TouchEvent) => {
    const canvas = canvasRef.current;
    if (!canvas) return null;
    const rect = canvas.getBoundingClientRect();
    const clientX = 'touches' in e ? e.touches[0]?.clientX : (e as React.MouseEvent).clientX;
    const clientY = 'touches' in e ? e.touches[0]?.clientY : (e as React.MouseEvent).clientY;
    if (clientX === undefined || clientY === undefined) return null;
    return { x: (clientX - rect.left) * (canvas.width / rect.width), y: (clientY - rect.top) * (canvas.height / rect.height) };
  };

  return (
    <div className="w-full h-full relative">
      <canvas
        ref={canvasRef}
        className="w-full h-full cursor-crosshair touch-none"
        onMouseDown={(e) => {
          e.stopPropagation();
          const pt = getPoint(e);
          if (!pt) return;
          drawingRef.current = true;
          lastRef.current = pt;
        }}
        onMouseMove={(e) => {
          e.stopPropagation();
          if (!drawingRef.current) return;
          const canvas = canvasRef.current;
          const ctx = canvas?.getContext('2d');
          const pt = getPoint(e);
          if (!ctx || !pt || !lastRef.current) return;
          ctx.strokeStyle = '#1B4332';
          ctx.lineWidth = 1.6;
          ctx.lineCap = 'round';
          ctx.beginPath();
          ctx.moveTo(lastRef.current.x, lastRef.current.y);
          ctx.lineTo(pt.x, pt.y);
          ctx.stroke();
          lastRef.current = pt;
          setHasStroke(true);
        }}
        onMouseUp={(e) => {
          e.stopPropagation();
          drawingRef.current = false;
          if (hasStroke && canvasRef.current) onSave(canvasRef.current.toDataURL('image/png'));
        }}
        onMouseLeave={() => {
          drawingRef.current = false;
        }}
      />
    </div>
  );
};