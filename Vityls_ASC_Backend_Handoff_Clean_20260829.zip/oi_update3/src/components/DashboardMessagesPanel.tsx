import React, { useEffect, useState } from 'react';
import { MessageSquare, ArrowRight, Circle } from 'lucide-react';
import { getAllPortalMessages, getUnreadCount, subscribeToMessageUpdates } from '../utils/portalMessageStore';
import { PortalMessage } from '../data/portalData';

interface DashboardMessagesPanelProps {
  onNavigateToMessages: () => void;
}

// Dashboard column 2 — a preview of incoming patient portal messages and
// notifications, with a clear, always-visible link to the full Messages page.
// Kept intentionally simple: this is a preview, not a second inbox — the
// full triage/reply workflow lives on the dedicated Messages page.
export const DashboardMessagesPanel: React.FC<DashboardMessagesPanelProps> = ({
  onNavigateToMessages,
}) => {
  const [messages, setMessages] = useState<PortalMessage[]>(() => getAllPortalMessages());
  const [unreadCount, setUnreadCount] = useState<number>(() => getUnreadCount());

  useEffect(() => {
    const refresh = () => {
      setMessages(getAllPortalMessages());
      setUnreadCount(getUnreadCount());
    };
    refresh();
    const unsubscribe = subscribeToMessageUpdates(refresh);
    return () => unsubscribe();
  }, []);

  // Most recent patient-authored / unread-first messages make the best preview.
  const preview = [...messages]
    .sort((a, b) => {
      if (a.read !== b.read) return a.read ? 1 : -1;
      return 0;
    })
    .slice(0, 5);

  return (
    <div className="bg-white rounded-xl border border-stone-200/90 shadow-2xs overflow-hidden flex flex-col h-full">
      {/* Header */}
      <div className="p-3 px-4 border-b border-stone-200/80 bg-stone-50/70 flex items-center justify-between gap-2">
        <div className="flex items-center gap-2.5">
          <div className="w-7 h-7 rounded-lg bg-[#DCEEE3] border border-[#E1E4DC] text-[#1F6E52] flex items-center justify-center font-bold">
            <MessageSquare className="w-4 h-4" />
          </div>
          <h2 className="text-sm font-bold text-stone-900 tracking-tight">Messages</h2>
        </div>
        {unreadCount > 0 && (
          <span className="text-[11px] font-bold px-2 py-0.5 rounded-full bg-[#1F6E52] text-white">
            {unreadCount} unread
          </span>
        )}
      </div>

      {/* Preview list */}
      <div className="flex-1 divide-y divide-stone-100 overflow-y-auto">
        {preview.length === 0 && (
          <div className="p-6 text-center text-xs text-stone-400">No messages yet.</div>
        )}
        {preview.map((msg) => (
          <button
            key={msg.id}
            type="button"
            onClick={onNavigateToMessages}
            className="w-full text-left p-3 px-4 hover:bg-stone-50 transition-colors cursor-pointer flex items-start gap-2.5"
          >
            {!msg.read && (
              <Circle className="w-2 h-2 mt-1.5 fill-[#1F6E52] text-[#1F6E52] shrink-0" />
            )}
            <div className={`min-w-0 flex-1 ${msg.read ? 'pl-[14px]' : ''}`}>
              <div className="flex items-center justify-between gap-2">
                <span className={`text-xs truncate ${msg.read ? 'font-semibold text-stone-700' : 'font-bold text-stone-900'}`}>
                  {msg.senderName}
                </span>
                <span className="text-[10px] text-stone-400 shrink-0 font-mono">{msg.timestamp}</span>
              </div>
              {msg.category && (
                <span className="text-[10px] font-semibold text-[#1F6E52]">{msg.category}</span>
              )}
              <p className="text-[11.5px] text-stone-500 line-clamp-2 mt-0.5">{msg.content}</p>
            </div>
          </button>
        ))}
      </div>

      {/* Footer link */}
      <button
        type="button"
        onClick={onNavigateToMessages}
        id="dashboard-messages-view-all"
        className="p-3 border-t border-stone-200/80 bg-stone-50/70 text-xs font-bold text-[#1F6E52] hover:bg-[#DCEEE3]/60 transition-colors cursor-pointer flex items-center justify-center gap-1.5"
      >
        <span>View All Messages</span>
        <ArrowRight className="w-3.5 h-3.5" />
      </button>
    </div>
  );
};
