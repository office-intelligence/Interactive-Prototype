import React, { useEffect, useState } from 'react';
import { X, UserCheck, FileText, CheckCircle2, ClipboardCheck, Smartphone, PenTool, Lock, ShieldCheck, Sparkles, AlertTriangle, Pill, HeartPulse, ArrowRight } from 'lucide-react';
import type { PatientCase } from '../types';
import { INITIAL_INTAKE_HTML_FORMS, IntakeHtmlForm } from '../data/intakeHtmlForms';
import { SignaturePad } from './SignaturePad';
import { getPrefilledIntakeHtml } from '../utils/formPrefill';
import { listCurrentPracticeForms, listPdfTemplates, createLocalBlobUrl, type LocalPdfTemplate } from '../utils/localFormStudioDb';
import { localTemplateToIntakeForm } from '../utils/localFormRuntime';
import { PdfTemplateInteractiveViewer } from './PdfTemplateInteractiveViewer';
import { MinimalWorkflowHeader } from './MinimalWorkflowHeader';
import { IsolatedHtmlFormRenderer } from './IsolatedHtmlFormRenderer';

interface OfficeCheckInPageProps {
  patient: PatientCase;
  onClose: () => void;
  onComplete: (patientId: string, exceptionReason?: string, unresolvedItems?: string[]) => void;
  activePracticeId?: string;
}

// Day-of-surgery front-desk check-in review — front office staff step through
// the practice's intake forms to verify/complete them for the arriving
// patient before the encounter proceeds, per the "Patient Check-In Workflow"
// spec (section 3d). Mirrors the Patient Portal's check-in form viewer: a
// simple list of forms that opens into one full-screen page per form, with
// the verification/attestation panel integrated at the bottom of the form
// itself — tablet-friendly, no persistent sidebar competing for width.
export const OfficeCheckInPage: React.FC<OfficeCheckInPageProps> = ({ patient, onClose, onComplete, activePracticeId }) => {
  const isSandbox = patient.id === 'local-empty-patient';
  const [forms, setForms] = useState<IntakeHtmlForm[]>(isSandbox ? [] : INITIAL_INTAKE_HTML_FORMS);
  const [assignedPdfTemplates,setAssignedPdfTemplates]=useState<LocalPdfTemplate[]>([]);
  const [activePdfTemplate,setActivePdfTemplate]=useState<LocalPdfTemplate|null>(null);
  useEffect(() => {
    if (!isSandbox || !activePracticeId) return;
    Promise.all([listCurrentPracticeForms(activePracticeId),listPdfTemplates(activePracticeId)]).then(([rows,pdfs]) => {
      setForms(rows.filter(f => f.collectionStage === 'Home / Patient Portal' || f.collectionStage === 'Front Desk').map(localTemplateToIntakeForm));
      setAssignedPdfTemplates(pdfs.filter(pdf=>pdf.status==='Active' && pdf.collectionStage==='Front Desk'));
    }).catch(() => {setForms([]);setAssignedPdfTemplates([]);});
  }, [isSandbox, activePracticeId]);
  const [activeFormId, setActiveFormId] = useState<string | null>(null);
  const [verifiedIds, setVerifiedIds] = useState<Set<string>>(new Set());
  const [verifiedMeta, setVerifiedMeta] = useState<Record<string, { by: string; date: string }>>({});
  const [frontDeskSignature, setFrontDeskSignature] = useState<string | null>(null);
  const [advanceReason, setAdvanceReason] = useState('');

  // Draft state for whichever form is currently open — reset each time a
  // different form is opened, mirroring the portal's pattern.
  const [draftSignature, setDraftSignature] = useState<string | null>(null);
  const [draftAgreed, setDraftAgreed] = useState(false);

  useEffect(() => {
    setDraftSignature(null);
    setDraftAgreed(false);
  }, [activeFormId]);

  const activeForm = forms.find((f) => f.id === activeFormId) || null;
  const verifiedCount = verifiedIds.size;
  const allVerified = forms.length > 0 && verifiedCount === forms.length;

  const submitActiveForm = () => {
    if (!activeFormId || !draftSignature || !draftAgreed) return;
    const dateStr = new Date().toLocaleDateString('en-US', { month: 'short', day: '2-digit', year: 'numeric' });
    setVerifiedIds((prev) => new Set(prev).add(activeFormId));
    setVerifiedMeta((prev) => ({ ...prev, [activeFormId]: { by: 'Front Desk Staff', date: dateStr } }));
    setActiveFormId(null);
  };

  // Lightweight completion path for forms that don't require a signature —
  // driven by the form template's own `requiresSignature` flag (see
  // intakeHtmlForms.ts) rather than guessed from content, so it stays
  // correct however a given practice's form library is put together.
  const markActiveFormReviewed = () => {
    if (!activeFormId) return;
    const dateStr = new Date().toLocaleDateString('en-US', { month: 'short', day: '2-digit', year: 'numeric' });
    setVerifiedIds((prev) => new Set(prev).add(activeFormId));
    setVerifiedMeta((prev) => ({ ...prev, [activeFormId]: { by: 'Front Desk Staff', date: dateStr } }));
    setActiveFormId(null);
  };

  // ============================================================
  // SINGLE FORM VIEW — matches the portal's full-screen form viewer
  // ============================================================
  if (activeForm) {
    const isVerified = verifiedIds.has(activeForm.id);
    const meta = verifiedMeta[activeForm.id];
    const needsSignature = activeForm.requiresSignature;

    return (
      <div className="fixed inset-0 z-[99999] bg-stone-100 flex flex-col w-screen h-screen overflow-hidden animate-in fade-in duration-150">
        <MinimalWorkflowHeader
          title={`Front Desk — ${activeForm.title}`}
          onClose={() => setActiveFormId(null)}
        />

        <div className="w-full flex-1 overflow-y-auto overflow-x-auto bg-stone-200/60 px-3 sm:px-6 py-5">
          <div className="w-full max-w-[980px] mx-auto bg-white shadow-md border border-stone-300 p-5 sm:p-8 relative">

            <IsolatedHtmlFormRenderer
              html={getPrefilledIntakeHtml(activeForm.htmlTemplate, patient)}
            />

            {/* Verification & Attestation Section — integrated at the bottom of
                the single form page, matching the patient portal exactly */}
            <div className="mt-8 pt-6 border-t-2 border-slate-200/90">
              {isVerified && needsSignature ? (
                <div className="p-6 bg-emerald-50/80 border-2 border-emerald-400/60 rounded-2xl space-y-3.5 text-xs text-emerald-950 shadow-xs">
                  <div className="flex items-center justify-between flex-wrap gap-2">
                    <div className="flex items-center gap-2 text-emerald-900 font-bold text-sm">
                      <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                      <span>Front Desk Verification</span>
                    </div>
                    <span className="bg-emerald-200/80 text-emerald-900 font-bold px-2.5 py-0.5 rounded-full text-[10.5px]">
                      Verified &amp; Complete
                    </span>
                  </div>
                  <p className="leading-relaxed text-emerald-900">
                    This form has been reviewed and verified for {patient.name}'s day-of-surgery check-in.
                  </p>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 border-t border-emerald-200/80 font-mono text-[11px]">
                    <div>
                      <span className="text-emerald-700 block font-sans font-bold text-[10px] uppercase">Verified By</span>
                      <span className="font-bold text-emerald-950">{meta?.by || 'Front Desk Staff'}</span>
                    </div>
                    <div>
                      <span className="text-emerald-700 block font-sans font-bold text-[10px] uppercase">Verification Timestamp</span>
                      <span className="font-bold text-emerald-950">{meta?.date || 'Verified'}</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 pt-1 text-[10.5px] text-emerald-800 font-mono">
                    <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span>Audit Trail: Cryptographic SHA-256 Signature Sealed into EHR Chart</span>
                  </div>
                </div>
              ) : isVerified && !needsSignature ? (
                <div className="p-6 bg-emerald-50/80 border-2 border-emerald-400/60 rounded-2xl space-y-3.5 text-xs text-emerald-950 shadow-xs">
                  <div className="flex items-center justify-between flex-wrap gap-2">
                    <div className="flex items-center gap-2 text-emerald-900 font-bold text-sm">
                      <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                      <span>Front Desk Review</span>
                    </div>
                    <span className="bg-emerald-200/80 text-emerald-900 font-bold px-2.5 py-0.5 rounded-full text-[10.5px]">
                      Reviewed &amp; Filed
                    </span>
                  </div>
                  <p className="leading-relaxed text-emerald-900">
                    This form type doesn't require a signature. It has been reviewed and filed for {patient.name}'s day-of-surgery check-in.
                  </p>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 border-t border-emerald-200/80 font-mono text-[11px]">
                    <div>
                      <span className="text-emerald-700 block font-sans font-bold text-[10px] uppercase">Reviewed By</span>
                      <span className="font-bold text-emerald-950">{meta?.by || 'Front Desk Staff'}</span>
                    </div>
                    <div>
                      <span className="text-emerald-700 block font-sans font-bold text-[10px] uppercase">Review Timestamp</span>
                      <span className="font-bold text-emerald-950">{meta?.date || 'Verified'}</span>
                    </div>
                  </div>
                </div>
              ) : needsSignature ? (
                <div className="p-6 bg-slate-50 border-2 border-teal-500/40 rounded-2xl space-y-4 text-xs text-slate-900 shadow-md">
                  <div className="flex items-center gap-2 text-teal-900 font-bold text-sm">
                    <PenTool className="w-4 h-4 text-teal-600" />
                    <span>Front Desk Verification</span>
                  </div>

                  <div className="p-3.5 bg-teal-50/70 border border-teal-200 rounded-xl text-xs text-teal-950 space-y-2">
                    <p className="leading-relaxed">
                      By signing below, I certify that I have reviewed this form with the patient and confirmed it is complete and accurate for today's visit.
                    </p>
                    <div className="flex items-center gap-2 pt-1 font-mono text-[11px] text-teal-800">
                      <Lock className="w-3.5 h-3.5 text-teal-600" />
                      <span>IP Address &amp; Time: {new Date().toLocaleDateString()} {new Date().toLocaleTimeString()} (Logged)</span>
                    </div>
                  </div>

                  <div className="space-y-3 pt-1">
                    <SignaturePad label="Front Desk Staff Signature" savedSignature={draftSignature} onSave={setDraftSignature} />

                    <label className="flex items-start gap-2.5 cursor-pointer pt-1">
                      <input
                        type="checkbox"
                        checked={draftAgreed}
                        onChange={(e) => setDraftAgreed(e.target.checked)}
                        className="w-4 h-4 rounded border-slate-300 text-teal-600 focus:ring-teal-500 mt-0.5"
                      />
                      <span className="text-xs text-slate-700 leading-relaxed font-medium">
                        I acknowledge that my handwritten signature above constitutes a legally binding signature identical to an ink signature on paper.
                      </span>
                    </label>
                  </div>

                  <div className="pt-3 border-t border-slate-200 flex items-center justify-between">
                    <button
                      type="button"
                      onClick={() => setActiveFormId(null)}
                      className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-xl text-xs font-bold transition-colors cursor-pointer"
                    >
                      Cancel
                    </button>
                    <button
                      type="button"
                      onClick={submitActiveForm}
                      disabled={!draftSignature || !draftAgreed}
                      className="px-6 py-2.5 bg-teal-600 hover:bg-teal-700 disabled:bg-slate-300 disabled:cursor-not-allowed text-white rounded-xl text-xs font-bold shadow-md transition-all flex items-center gap-2 cursor-pointer"
                    >
                      <CheckCircle2 className="w-4 h-4" />
                      <span>Mark Verified &amp; Complete</span>
                    </button>
                  </div>
                </div>
              ) : (
                // No signature required for this form — a lighter
                // review-and-file action instead of the full signature pad.
                <div className="p-6 bg-slate-50 border-2 border-slate-300 rounded-2xl space-y-4 text-xs text-slate-900 shadow-md">
                  <div className="flex items-center gap-2 text-slate-800 font-bold text-sm">
                    <ClipboardCheck className="w-4 h-4 text-slate-500" />
                    <span>Front Desk Review</span>
                  </div>

                  <p className="leading-relaxed text-slate-600">
                    This form doesn't require a signature. Review its contents above with the patient, then mark it reviewed to file it to their chart.
                  </p>

                  <div className="pt-3 border-t border-slate-200 flex items-center justify-between">
                    <button
                      type="button"
                      onClick={() => setActiveFormId(null)}
                      className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-xl text-xs font-bold transition-colors cursor-pointer"
                    >
                      Cancel
                    </button>
                    <button
                      type="button"
                      onClick={markActiveFormReviewed}
                      className="px-6 py-2.5 bg-slate-700 hover:bg-slate-800 text-white rounded-xl text-xs font-bold shadow-md transition-all flex items-center gap-2 cursor-pointer"
                    >
                      <CheckCircle2 className="w-4 h-4" />
                      <span>Mark as Reviewed</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    );
  }

  // ============================================================
  // LIST VIEW — matches the portal's pre-arrival check-in list page
  // ============================================================
  return (
    <div className="fixed inset-0 z-[99999] bg-slate-50 flex flex-col w-screen h-screen overflow-y-auto animate-in fade-in duration-150">
      <MinimalWorkflowHeader
        title={`Front Desk Workflow — ${patient.name}`}
        onClose={onClose}
      />

      <div className="flex-1 max-w-3xl w-full mx-auto p-4 sm:p-8 space-y-4">
        <section className="rounded-2xl border border-cyan-200 bg-gradient-to-br from-cyan-50 to-white shadow-2xs overflow-hidden">
          <div className="px-4 py-3 bg-cyan-900 text-white flex items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-cyan-200" />
              <span className="text-sm font-black">Nightingale Arrival Review</span>
            </div>
            <span className="text-[10px] uppercase tracking-wider font-black bg-white/10 px-2 py-1 rounded-full">Front Desk Gate</span>
          </div>
          <div className="p-4 grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
            <div className="space-y-2">
              <div className="flex items-center gap-2 text-emerald-800 font-bold"><CheckCircle2 className="w-4 h-4" /> Identity / demographics available</div>
              <div className="flex items-center gap-2 text-emerald-800 font-bold"><CheckCircle2 className="w-4 h-4" /> Intake packet available for verification</div>
              <div className="flex items-center gap-2 text-emerald-800 font-bold"><CheckCircle2 className="w-4 h-4" /> Responsible adult / ride must be confirmed</div>
            </div>
            <div className="space-y-2">
              {patient.labs.some(l => l.status === 'critical' || l.status === 'pending') ? (
                <div className="flex items-start gap-2 text-amber-800 font-bold"><AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" /> Clinical results require Nursing/provider review; front desk should not resolve them.</div>
              ) : (
                <div className="flex items-center gap-2 text-emerald-800 font-bold"><CheckCircle2 className="w-4 h-4" /> Available labs show no unresolved result in this prototype</div>
              )}
              <div className="text-slate-600 leading-relaxed">Administrative staff verifies arrival information. Clinical changes are captured and handed forward, not interpreted at the desk.</div>
            </div>
          </div>
        </section>

        <section className="p-4 bg-white rounded-2xl border border-slate-200 shadow-2xs space-y-3">
          <div className="flex items-center justify-between gap-3">
            <div>
              <div className="text-sm font-black text-slate-900">Clinical information carried forward</div>
              <p className="text-[11px] text-slate-500 mt-0.5">Do not re-enter these items. Nursing receives the same record and verifies or updates only if the patient reports a change.</p>
            </div>
            <span className="text-[10px] font-black uppercase tracking-wide px-2 py-1 rounded-full bg-emerald-100 text-emerald-800 border border-emerald-200">Single Source</span>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="rounded-xl border border-rose-200 bg-rose-50/60 p-3">
              <div className="flex items-center gap-1.5 text-[11px] font-black uppercase tracking-wide text-rose-800 mb-2"><HeartPulse className="w-3.5 h-3.5" /> Allergies</div>
              <div className="text-xs font-bold text-slate-900">{patient.allergies.length ? patient.allergies.join(', ') : 'No allergy data on file'}</div>
            </div>
            <div className="rounded-xl border border-indigo-200 bg-indigo-50/60 p-3">
              <div className="flex items-center gap-1.5 text-[11px] font-black uppercase tracking-wide text-indigo-800 mb-2"><Pill className="w-3.5 h-3.5" /> Active medications</div>
              <div className="text-xs font-bold text-slate-900">{patient.medicalProfile?.medications?.length ? patient.medicalProfile.medications.map(m => `${m.name} ${m.dose} ${m.freq}`.trim()).join(' · ') : 'No active medications documented / needs verification'}</div>
            </div>
          </div>
        </section>

        <p className="text-xs sm:text-sm text-slate-600 font-medium">
          Review and verify the intake forms below. Resolve only missing administrative information; clinical questions flow forward to Nursing.
        </p>

        <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-2xs flex items-center justify-between">
          <span className="text-xs sm:text-sm font-bold text-slate-800">{verifiedCount} / {forms.length} forms verified</span>
          {allVerified && (
            <span className="px-3 py-1 rounded-full bg-emerald-100 text-emerald-800 border border-emerald-300 text-[11px] font-bold flex items-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5" />
              Check-in complete
            </span>
          )}
        </div>

        {assignedPdfTemplates.length>0 && <div className="rounded-2xl border border-violet-200 bg-violet-50/50 p-4 space-y-2">
          <div><div className="text-sm font-black text-slate-900">Assigned PDF Forms</div><div className="text-[10.5px] text-slate-500 mt-0.5">View/print-only forms placed In Use at Front Desk from Form Studio.</div></div>
          {assignedPdfTemplates.map(pdf=><div key={pdf.id} className="rounded-xl border border-violet-200 bg-white p-3 flex items-center justify-between gap-3"><div><div className="text-xs font-black text-stone-900">{pdf.title}</div><div className="text-[10px] text-stone-500">{pdf.version}</div></div><button onClick={()=>setActivePdfTemplate(pdf)} className="px-3 py-1.5 rounded-lg border border-violet-300 bg-violet-50 text-violet-800 text-[10px] font-black">Fill PDF</button></div>)}
        </div>}

        <div className="space-y-2.5">
          {forms.map((f) => {
            const isVerified = verifiedIds.has(f.id);
            return (
              <button
                key={f.id}
                onClick={() => setActiveFormId(f.id)}
                className="w-full text-left p-4 bg-white rounded-2xl border border-slate-200 hover:border-teal-400 hover:shadow-2xs transition-all cursor-pointer flex items-center justify-between gap-3"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${isVerified ? 'bg-emerald-100 text-emerald-700' : 'bg-slate-100 text-slate-500'}`}>
                    <FileText className="w-4.5 h-4.5" />
                  </div>
                  <div className="min-w-0">
                    <div className="text-sm font-bold text-slate-900 truncate">{f.title}</div>
                    <div className="text-[11px] text-slate-500 font-medium">{f.category}</div>
                  </div>
                </div>
                <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full shrink-0 ${isVerified ? 'bg-emerald-100 text-emerald-800 border border-emerald-300' : 'bg-amber-100 text-amber-800 border border-amber-300'}`}>
                  {isVerified ? 'Verified' : 'Action Required'}
                </span>
              </button>
            );
          })}
        </div>

        <div className={`p-4 bg-white rounded-2xl border-2 shadow-md space-y-3 ${allVerified ? 'border-teal-500/40' : 'border-amber-400/50'}`}>
          <div className="flex items-center gap-2 text-slate-900 font-bold text-sm">
            {allVerified ? <ClipboardCheck className="w-4 h-4 text-teal-600" /> : <AlertTriangle className="w-4 h-4 text-amber-600" />}
            <span>{allVerified ? 'Final Front Desk Sign-Off (optional for test)' : 'Advance With Open Items'}</span>
          </div>
          {!allVerified && (
            <div className="rounded-xl border border-amber-200 bg-amber-50 p-3 space-y-2">
              <p className="text-[11px] text-amber-900 font-semibold">Check-in may proceed even when forms are incomplete. The unfinished items will remain open, follow the patient into Nursing, and be visible as exceptions in the Case Record.</p>
              <div className="text-[10.5px] text-amber-800"><strong>Open items:</strong> {forms.filter(f => !verifiedIds.has(f.id)).map(f => f.title).join(' · ')}</div>
              <textarea
                value={advanceReason}
                onChange={(e) => setAdvanceReason(e.target.value)}
                rows={2}
                placeholder="Optional: explain why the patient is advancing with incomplete items. If left blank, Office Intelligence records a standard handoff exception."
                className="w-full rounded-xl border border-amber-300 bg-white px-3 py-2 text-xs outline-none focus:ring-2 focus:ring-amber-300"
              />
            </div>
          )}
          <SignaturePad label="Front Desk Sign-Off (optional for test)" compact savedSignature={frontDeskSignature} onSave={setFrontDeskSignature} />
          <button
            type="button"
            onClick={() => onComplete(
              patient.id,
              allVerified ? undefined : (advanceReason.trim() || 'Advanced with incomplete Front Desk items; Nursing to review unresolved items.'),
              allVerified ? undefined : forms.filter(f => !verifiedIds.has(f.id)).map(f => f.title)
            )}
            className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm rounded-xl shadow-md transition-colors cursor-pointer flex items-center justify-center gap-2"
          >
            <CheckCircle2 className="w-4 h-4" />
            <span>{allVerified ? 'Complete Check-In & Open Nursing Gate' : 'Advance & Open Nursing Gate With Exception'}</span><ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
      {activePdfTemplate && (
        <PdfTemplateInteractiveViewer
          patientId={patient.id}
          patientName={patient.name}
          template={activePdfTemplate}
          onClose={()=>setActivePdfTemplate(null)}
        />
      )}

    </div>

  );
};
