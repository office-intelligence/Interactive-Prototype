import React, { useState } from 'react';
import {
  FileText,
  ScanLine,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  ArrowUpCircle,
  RotateCcw,
  Sparkles,
  Mail,
  Printer,
  Upload,
  Smartphone,
  User,
  Clock,
  Inbox,
  ShieldCheck,
} from 'lucide-react';
import {
  IntakeDocument,
  ConfidenceScore,
  DocumentReviewDecision,
  DocumentIntakeSource,
} from '../types';

interface DocumentIntakeQueuePageProps {
  onShowToast?: (msg: string) => void;
}

const REVIEWER_NAME = 'Front Desk — Jamie Ruiz';

/* ---------------------------------------------------------------
   Mock seed data
   --------------------------------------------------------------- */

const seedDocuments: IntakeDocument[] = [
  {
    id: 'doc-1001',
    fileName: 'fax_20260819_0731_unknown.pdf',
    source: 'Fax',
    documentType: 'Referral Letter',
    receivedAt: '2026-08-19T07:31:00Z',
    patientNameGuess: 'Margaret Whitfeld',
    matchedPatientId: undefined,
    matchedPatientName: undefined,
    overallConfidence: 61,
    needsHumanReview: true,
    reviewReason: 'No matching patient record found',
    assignedTo: undefined,
    status: 'QUEUED',
    fields: [
      { field: 'Patient Name', extractedValue: 'Margaret Whitfeld', confidence: 58, matchStatus: 'NO_MATCH' },
      { field: 'Date of Birth', extractedValue: '03/12/1958', confidence: 72, matchStatus: 'AMBIGUOUS' },
      { field: 'Referring Provider', extractedValue: 'Dr. A. Coben, MD', confidence: 91, matchStatus: 'MATCHED' },
      { field: 'Reason for Referral', extractedValue: 'Eval. for rotator cuff repair', confidence: 88, matchStatus: 'MATCHED' },
    ],
    auditTrail: [],
  },
  {
    id: 'doc-1002',
    fileName: 'portal_upload_insurance_card_front.jpg',
    source: 'Patient Portal Upload',
    documentType: 'Insurance Card',
    receivedAt: '2026-08-19T08:02:00Z',
    patientNameGuess: 'Daniel Ferreira',
    matchedPatientId: 'pt-4471',
    matchedPatientName: 'Daniel Ferreira',
    overallConfidence: 68,
    needsHumanReview: true,
    reviewReason: 'Low OCR confidence on patient DOB',
    assignedTo: undefined,
    status: 'IN_REVIEW',
    fields: [
      { field: 'Patient Name', extractedValue: 'Daniel Ferreira', confidence: 96, matchStatus: 'MATCHED' },
      { field: 'Date of Birth', extractedValue: '11/31/1990', confidence: 42, matchStatus: 'AMBIGUOUS' },
      { field: 'Payer Name', extractedValue: 'BlueCross BlueShield PPO', confidence: 89, matchStatus: 'MATCHED' },
      { field: 'Member ID', extractedValue: 'YXH774821003', confidence: 74, matchStatus: 'MATCHED' },
      { field: 'Group Number', extractedValue: '00918-A', confidence: 63, matchStatus: 'AMBIGUOUS' },
    ],
    auditTrail: [
      {
        decidedBy: REVIEWER_NAME,
        decidedAt: '2026-08-19T08:10:00Z',
        action: 'CORRECTED',
        notes: 'Flagged DOB for manual re-check, month/day likely transposed by OCR.',
      },
    ],
  },
  {
    id: 'doc-1003',
    fileName: 'signed_consent_bariatric_procedure.pdf',
    source: 'Scanner Upload',
    documentType: 'Signed Consent Form',
    receivedAt: '2026-08-19T08:15:00Z',
    patientNameGuess: 'Priya Natarajan',
    matchedPatientId: 'pt-2290',
    matchedPatientName: 'Priya Natarajan',
    overallConfidence: 74,
    needsHumanReview: true,
    reviewReason: 'Signature field ambiguous',
    assignedTo: undefined,
    status: 'QUEUED',
    fields: [
      { field: 'Patient Name', extractedValue: 'Priya Natarajan', confidence: 95, matchStatus: 'MATCHED' },
      { field: 'Procedure', extractedValue: 'Laparoscopic Sleeve Gastrectomy', confidence: 90, matchStatus: 'MATCHED' },
      { field: 'Patient Signature', extractedValue: '(illegible mark)', confidence: 38, matchStatus: 'AMBIGUOUS' },
      { field: 'Witness Signature', extractedValue: 'K. Alvarez, RN', confidence: 84, matchStatus: 'MATCHED' },
      { field: 'Date Signed', extractedValue: '08/17/2026', confidence: 92, matchStatus: 'MATCHED' },
    ],
    auditTrail: [],
  },
  {
    id: 'doc-1004',
    fileName: 'email_attachment_lab_cbc_panel.pdf',
    source: 'Email',
    documentType: 'Lab Result',
    receivedAt: '2026-08-19T06:45:00Z',
    patientNameGuess: 'Owen Kaczmarek',
    matchedPatientId: 'pt-5518',
    matchedPatientName: 'Owen Kaczmarek',
    overallConfidence: 97,
    needsHumanReview: false,
    reviewReason: undefined,
    assignedTo: undefined,
    status: 'APPROVED',
    fields: [
      { field: 'Patient Name', extractedValue: 'Owen Kaczmarek', confidence: 99, matchStatus: 'MATCHED' },
      { field: 'Date of Birth', extractedValue: '05/22/1975', confidence: 98, matchStatus: 'MATCHED' },
      { field: 'Lab Panel', extractedValue: 'Complete Blood Count (CBC)', confidence: 96, matchStatus: 'MATCHED' },
      { field: 'Ordering Provider', extractedValue: 'Dr. S. Meyerhoff', confidence: 95, matchStatus: 'MATCHED' },
    ],
    auditTrail: [
      {
        decidedBy: 'Nightingale AI',
        decidedAt: '2026-08-19T06:46:12Z',
        action: 'APPROVED',
        notes: 'Auto-approved: all fields above 95% confidence with exact patient match.',
      },
    ],
  },
  {
    id: 'doc-1005',
    fileName: 'mobile_capture_photo_id_dl.png',
    source: 'Mobile Capture',
    documentType: 'Photo ID',
    receivedAt: '2026-08-19T09:03:00Z',
    patientNameGuess: 'Renata Souza',
    matchedPatientId: 'pt-3387',
    matchedPatientName: 'Renata Souza',
    overallConfidence: 94,
    needsHumanReview: false,
    reviewReason: undefined,
    assignedTo: undefined,
    status: 'APPROVED',
    fields: [
      { field: 'Patient Name', extractedValue: 'Renata Souza', confidence: 97, matchStatus: 'MATCHED' },
      { field: 'Date of Birth', extractedValue: '09/09/1988', confidence: 95, matchStatus: 'MATCHED' },
      { field: 'License Number', extractedValue: 'S8827734', confidence: 90, matchStatus: 'MATCHED' },
      { field: 'Expiration Date', extractedValue: '09/09/2028', confidence: 93, matchStatus: 'MATCHED' },
    ],
    auditTrail: [
      {
        decidedBy: 'Nightingale AI',
        decidedAt: '2026-08-19T09:04:02Z',
        action: 'APPROVED',
        notes: 'Auto-approved: all fields above 90% confidence with exact patient match.',
      },
    ],
  },
  {
    id: 'doc-1006',
    fileName: 'fax_20260819_1102_clearance.pdf',
    source: 'Fax',
    documentType: 'Clearance Letter',
    receivedAt: '2026-08-19T11:02:00Z',
    patientNameGuess: 'Harold Jennings',
    matchedPatientId: 'pt-1120',
    matchedPatientName: 'Harold Jennings',
    overallConfidence: 82,
    needsHumanReview: false,
    reviewReason: undefined,
    assignedTo: undefined,
    status: 'APPROVED',
    fields: [
      { field: 'Patient Name', extractedValue: 'Harold Jennings', confidence: 91, matchStatus: 'MATCHED' },
      { field: 'Clearing Provider', extractedValue: 'Dr. L. Ostrowski, Cardiology', confidence: 88, matchStatus: 'MATCHED' },
      { field: 'Cleared For', extractedValue: 'Elective Total Knee Arthroplasty', confidence: 79, matchStatus: 'MATCHED' },
      { field: 'Clearance Date', extractedValue: '08/15/2026', confidence: 86, matchStatus: 'MATCHED' },
    ],
    auditTrail: [
      {
        decidedBy: REVIEWER_NAME,
        decidedAt: '2026-08-19T11:20:41Z',
        action: 'APPROVED',
        notes: 'Reviewed manually — confidence just under auto-approve threshold, all fields verified correct.',
      },
    ],
  },
  {
    id: 'doc-1007',
    fileName: 'portal_upload_prior_records_bundle.pdf',
    source: 'Patient Portal Upload',
    documentType: 'Prior Records',
    receivedAt: '2026-08-19T09:47:00Z',
    patientNameGuess: 'A. Whitfeld or M. Whitfield',
    matchedPatientId: undefined,
    matchedPatientName: undefined,
    overallConfidence: 55,
    needsHumanReview: true,
    reviewReason: 'No matching patient record found',
    assignedTo: undefined,
    status: 'QUEUED',
    fields: [
      { field: 'Patient Name', extractedValue: 'A. Whitfeld / M. Whitfield', confidence: 47, matchStatus: 'AMBIGUOUS' },
      { field: 'Date of Birth', extractedValue: '(unreadable)', confidence: 21, matchStatus: 'NO_MATCH' },
      { field: 'Facility of Origin', extractedValue: 'Cedar Grove Orthopedic Group', confidence: 85, matchStatus: 'MATCHED' },
      { field: 'Record Type', extractedValue: 'Imaging + Progress Notes', confidence: 80, matchStatus: 'MATCHED' },
    ],
    auditTrail: [],
  },
  {
    id: 'doc-1008',
    fileName: 'unclassified_scan_20260819_1315.pdf',
    source: 'Scanner Upload',
    documentType: 'Unclassified',
    receivedAt: '2026-08-19T13:15:00Z',
    patientNameGuess: undefined,
    matchedPatientId: undefined,
    matchedPatientName: undefined,
    overallConfidence: 39,
    needsHumanReview: true,
    reviewReason: 'Low OCR confidence on patient DOB',
    assignedTo: undefined,
    status: 'QUEUED',
    fields: [
      { field: 'Document Category', extractedValue: '(unclear — possibly intake form)', confidence: 33, matchStatus: 'NO_MATCH' },
      { field: 'Patient Name', extractedValue: '(unreadable)', confidence: 18, matchStatus: 'NO_MATCH' },
      { field: 'Date of Birth', extractedValue: '(unreadable)', confidence: 15, matchStatus: 'NO_MATCH' },
    ],
    auditTrail: [],
  },
];

/* ---------------------------------------------------------------
   Helpers
   --------------------------------------------------------------- */

const sourceIcon = (source: DocumentIntakeSource) => {
  switch (source) {
    case 'Fax':
      return Printer;
    case 'Email':
      return Mail;
    case 'Scanner Upload':
      return ScanLine;
    case 'Patient Portal Upload':
      return Upload;
    case 'Mobile Capture':
      return Smartphone;
    default:
      return FileText;
  }
};

const confidenceTier = (confidence: number): 'high' | 'mid' | 'low' => {
  if (confidence >= 90) return 'high';
  if (confidence >= 70) return 'mid';
  return 'low';
};

const confidenceClasses = (confidence: number) => {
  const tier = confidenceTier(confidence);
  if (tier === 'high') {
    return { bar: 'bg-[#2F9E6E]', pillBg: 'bg-[#E4F3EA]', pillText: 'text-[#1B4332]' };
  }
  if (tier === 'mid') {
    return { bar: 'bg-[#C98A34]', pillBg: 'bg-[#FBEEDB]', pillText: 'text-[#7A4E17]' };
  }
  return { bar: 'bg-[#C1503D]', pillBg: 'bg-[#FBE4E1]', pillText: 'text-[#7A2E22]' };
};

const matchStatusClasses = (status: ConfidenceScore['matchStatus']) => {
  switch (status) {
    case 'MATCHED':
      return 'bg-[#E4F3EA] text-[#1B4332] border-[#2F9E6E]/30';
    case 'AMBIGUOUS':
      return 'bg-[#FBEEDB] text-[#7A4E17] border-[#C98A34]/30';
    case 'NO_MATCH':
      return 'bg-[#FBE4E1] text-[#7A2E22] border-[#C1503D]/30';
    default:
      return 'bg-slate-100 text-slate-600 border-slate-200';
  }
};

const statusBadgeClasses = (status: IntakeDocument['status']) => {
  switch (status) {
    case 'APPROVED':
      return 'bg-[#E4F3EA] text-[#1B4332]';
    case 'REJECTED':
      return 'bg-[#FBE4E1] text-[#7A2E22]';
    case 'ESCALATED':
      return 'bg-[#E7F1F3] text-[#3E8FA6]';
    case 'IN_REVIEW':
      return 'bg-[#DCEEE3] text-[#17553F]';
    case 'QUEUED':
    default:
      return 'bg-[#FBEEDB] text-[#7A4E17]';
  }
};

const docTypeBadgeClasses = 'bg-[#E7F1F3] text-[#3E8FA6]';

const formatDateTime = (iso: string) => {
  try {
    return new Date(iso).toLocaleString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: 'numeric',
      minute: '2-digit',
    });
  } catch {
    return iso;
  }
};

const actionMeta: Record<DocumentReviewDecision['action'], { label: string; icon: typeof CheckCircle2; color: string }> = {
  APPROVED: { label: 'Approved', icon: CheckCircle2, color: 'text-[#2F9E6E]' },
  CORRECTED: { label: 'Corrected', icon: Sparkles, color: 'text-[#3E8FA6]' },
  REJECTED: { label: 'Rejected', icon: XCircle, color: 'text-[#C1503D]' },
  ESCALATED: { label: 'Escalated', icon: ArrowUpCircle, color: 'text-[#3E8FA6]' },
  RE_SCAN_REQUESTED: { label: 'Re-scan Requested', icon: RotateCcw, color: 'text-[#C98A34]' },
};

/* ---------------------------------------------------------------
   Component
   --------------------------------------------------------------- */

export const DocumentIntakeQueuePage: React.FC<DocumentIntakeQueuePageProps> = ({ onShowToast }) => {
  const [documents, setDocuments] = useState<IntakeDocument[]>(seedDocuments);
  const [selectedId, setSelectedId] = useState<string>(seedDocuments[0].id);
  const [fieldEdits, setFieldEdits] = useState<Record<string, string>>({});

  const selectedDocument = documents.find((d) => d.id === selectedId) ?? documents[0];

  const needsReviewCount = documents.filter((d) => d.needsHumanReview).length;
  const autoApprovedToday = documents.filter(
    (d) => d.status === 'APPROVED' && d.auditTrail.some((a) => a.decidedBy === 'Nightingale AI' && a.action === 'APPROVED')
  ).length;
  const avgConfidence = Math.round(
    documents.reduce((sum, d) => sum + d.overallConfidence, 0) / Math.max(documents.length, 1)
  );

  const appendDecision = (docId: string, decision: DocumentReviewDecision, patch: Partial<IntakeDocument>) => {
    setDocuments((prev) =>
      prev.map((d) =>
        d.id === docId
          ? {
              ...d,
              ...patch,
              auditTrail: [...d.auditTrail, decision],
            }
          : d
      )
    );
  };

  const handleApprove = () => {
    if (!selectedDocument) return;
    appendDecision(
      selectedDocument.id,
      { decidedBy: REVIEWER_NAME, decidedAt: new Date().toISOString(), action: 'APPROVED', notes: 'Reviewed and approved by human reviewer.' },
      { status: 'APPROVED', needsHumanReview: false, reviewReason: undefined }
    );
    onShowToast?.(`${selectedDocument.fileName} approved.`);
  };

  const handleReject = () => {
    if (!selectedDocument) return;
    appendDecision(
      selectedDocument.id,
      { decidedBy: REVIEWER_NAME, decidedAt: new Date().toISOString(), action: 'REJECTED', notes: 'Document rejected — does not meet intake requirements.' },
      { status: 'REJECTED' }
    );
    onShowToast?.(`${selectedDocument.fileName} rejected.`);
  };

  const handleEscalate = () => {
    if (!selectedDocument) return;
    appendDecision(
      selectedDocument.id,
      { decidedBy: REVIEWER_NAME, decidedAt: new Date().toISOString(), action: 'ESCALATED', notes: 'Escalated to Practice Admin for further review.' },
      { status: 'ESCALATED' }
    );
    onShowToast?.(`${selectedDocument.fileName} escalated to Practice Admin.`);
  };

  const handleRescan = () => {
    if (!selectedDocument) return;
    appendDecision(
      selectedDocument.id,
      { decidedBy: REVIEWER_NAME, decidedAt: new Date().toISOString(), action: 'RE_SCAN_REQUESTED', notes: 'Requested re-scan due to poor image quality / illegible fields.' },
      { status: 'QUEUED', needsHumanReview: false, reviewReason: undefined }
    );
    onShowToast?.(`Re-scan requested for ${selectedDocument.fileName}.`);
  };

  const handleCorrectField = (fieldName: string) => {
    if (!selectedDocument) return;
    const editKey = `${selectedDocument.id}::${fieldName}`;
    const newValue = fieldEdits[editKey];
    if (!newValue || !newValue.trim()) return;

    setDocuments((prev) =>
      prev.map((d) =>
        d.id === selectedDocument.id
          ? {
              ...d,
              fields: d.fields.map((f) =>
                f.field === fieldName ? { ...f, extractedValue: newValue.trim(), confidence: 100, matchStatus: 'MATCHED' } : f
              ),
              auditTrail: [
                ...d.auditTrail,
                {
                  decidedBy: REVIEWER_NAME,
                  decidedAt: new Date().toISOString(),
                  action: 'CORRECTED',
                  notes: `Manually corrected "${fieldName}" to "${newValue.trim()}".`,
                },
              ],
            }
          : d
      )
    );
    setFieldEdits((prev) => ({ ...prev, [editKey]: '' }));
    onShowToast?.(`Field "${fieldName}" corrected.`);
  };

  return (
    <div className="p-6 space-y-5 bg-[#F1F3EC] min-h-full">
      {/* Header band */}
      <div className="bg-white p-6 rounded-2xl border border-[#E1E4DC] shadow-2xs flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-start gap-3">
          <div className="p-2.5 rounded-xl bg-gradient-to-br from-[#3E8FA6] to-[#3E8FA6] text-white shadow-2xs">
            <Inbox className="w-5 h-5" />
          </div>
          <div>
            <h1 className="text-lg font-bold text-[#1A2E22] flex items-center gap-2">
              Document Intake / OCR Review Queue
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-[#E7F1F3] text-[#3E8FA6] text-[10px] font-bold uppercase tracking-wide">
                <Sparkles className="w-3 h-3" />
                Nightingale AI
              </span>
            </h1>
            <p className="text-xs text-[#5B6B60] mt-0.5">
              Faxes, scans, portal uploads, and email attachments are auto-parsed and confidence-scored by Nightingale AI — anything uncertain routes here for human review with a full audit trail.
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <div id="stat-chip-needs-review" className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#FBEEDB] text-[#7A4E17] text-xs font-bold border border-[#C98A34]/20">
            <AlertTriangle className="w-3.5 h-3.5" />
            {needsReviewCount} need review
          </div>
          <div id="stat-chip-auto-approved" className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#E4F3EA] text-[#1B4332] text-xs font-bold border border-[#2F9E6E]/20">
            <ShieldCheck className="w-3.5 h-3.5" />
            {autoApprovedToday} auto-approved today
          </div>
          <div id="stat-chip-avg-confidence" className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#DCEEE3] text-[#17553F] text-xs font-bold border border-[#1F6E52]/20">
            <Sparkles className="w-3.5 h-3.5" />
            {avgConfidence}% avg confidence
          </div>
        </div>
      </div>

      {/* Two-pane layout */}
      <div className="grid grid-cols-1 lg:grid-cols-[minmax(0,1fr)_minmax(0,1.35fr)] gap-5 items-start">
        {/* Left pane: queue list */}
        <div className="bg-white rounded-2xl border border-[#E1E4DC] shadow-2xs overflow-hidden">
          <div className="px-4 py-3 border-b border-[#E1E4DC] flex items-center justify-between">
            <h2 className="text-sm font-bold text-[#1A2E22]">Queue</h2>
            <span className="text-[11px] text-[#5B6B60]">{documents.length} documents</span>
          </div>
          <div className="divide-y divide-[#E1E4DC] max-h-[720px] overflow-y-auto">
            {documents.map((doc) => {
              const SourceIcon = sourceIcon(doc.source);
              const conf = confidenceClasses(doc.overallConfidence);
              const isSelected = doc.id === selectedDocument?.id;
              return (
                <button
                  key={doc.id}
                  id={`queue-row-${doc.id}`}
                  type="button"
                  onClick={() => setSelectedId(doc.id)}
                  className={`w-full text-left px-4 py-3.5 transition-colors cursor-pointer ${
                    isSelected ? 'bg-[#DCEEE3]/40' : 'hover:bg-[#F1F3EC]'
                  }`}
                >
                  <div className="flex items-start gap-2.5">
                    <div className={`mt-0.5 p-1.5 rounded-lg shrink-0 ${isSelected ? 'bg-[#1F6E52] text-white' : 'bg-slate-100 text-[#5B6B60]'}`}>
                      <SourceIcon className="w-3.5 h-3.5" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center justify-between gap-2">
                        <p className="text-xs font-semibold text-[#1A2E22] truncate">{doc.fileName}</p>
                      </div>
                      <div className="flex flex-wrap items-center gap-1.5 mt-1.5">
                        <span className={`px-1.5 py-0.5 rounded-md text-[10px] font-bold ${docTypeBadgeClasses}`}>{doc.documentType}</span>
                        <span className={`px-1.5 py-0.5 rounded-md text-[10px] font-bold ${statusBadgeClasses(doc.status)}`}>{doc.status.replace('_', ' ')}</span>
                      </div>

                      <div className="flex items-center gap-2 mt-2">
                        <div className="flex-1 h-1.5 rounded-full bg-slate-100 overflow-hidden">
                          <div className={`h-full rounded-full ${conf.bar}`} style={{ width: `${doc.overallConfidence}%` }} />
                        </div>
                        <span className={`px-1.5 py-0.5 rounded-md text-[10px] font-bold ${conf.pillBg} ${conf.pillText}`}>
                          {doc.overallConfidence}%
                        </span>
                      </div>

                      <div className="flex items-center gap-1.5 mt-1.5 text-[11px] text-[#5B6B60]">
                        <User className="w-3 h-3 shrink-0" />
                        <span className="truncate">{doc.matchedPatientName ?? 'No match'}</span>
                      </div>

                      {doc.needsHumanReview && doc.reviewReason && (
                        <div className="flex items-start gap-1 mt-1.5 text-[10.5px] text-[#7A4E17]">
                          <AlertTriangle className="w-3 h-3 shrink-0 mt-0.5" />
                          <span>{doc.reviewReason}</span>
                        </div>
                      )}
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Right pane: document reviewer */}
        <div className="space-y-5">
          {selectedDocument && (
            <>
              {/* Document preview placeholder */}
              <div className="bg-white rounded-2xl border border-[#E1E4DC] shadow-2xs p-5">
                <div className="flex items-center justify-between gap-3 mb-3">
                  <div>
                    <h2 className="text-sm font-bold text-[#1A2E22]">{selectedDocument.fileName}</h2>
                    <p className="text-[11px] text-[#5B6B60] mt-0.5">
                      Received {formatDateTime(selectedDocument.receivedAt)} via {selectedDocument.source}
                    </p>
                  </div>
                  <span className={`px-2 py-1 rounded-lg text-[10px] font-bold ${statusBadgeClasses(selectedDocument.status)}`}>
                    {selectedDocument.status.replace('_', ' ')}
                  </span>
                </div>

                <div className="rounded-xl border border-dashed border-[#E1E4DC] bg-[#F1F3EC] h-56 flex flex-col items-center justify-center gap-2 text-[#5B6B60]">
                  <FileText className="w-10 h-10 text-[#1F6E52]" />
                  <p className="text-xs font-semibold text-[#1A2E22]">{selectedDocument.fileName}</p>
                  <p className="text-[11px] text-[#5B6B60]">Document preview unavailable in this mock view</p>
                </div>

                {selectedDocument.needsHumanReview && selectedDocument.reviewReason && (
                  <div className="mt-3 flex items-start gap-2 px-3 py-2.5 rounded-xl bg-[#FBEEDB] border border-[#C98A34]/30">
                    <AlertTriangle className="w-4 h-4 text-[#C98A34] shrink-0 mt-0.5" />
                    <div>
                      <p className="text-xs font-bold text-[#7A4E17]">Needs human review</p>
                      <p className="text-[11px] text-[#7A4E17]">{selectedDocument.reviewReason}</p>
                    </div>
                  </div>
                )}
              </div>

              {/* Field-by-field breakdown */}
              <div className="bg-white rounded-2xl border border-[#E1E4DC] shadow-2xs p-5">
                <h3 className="text-sm font-bold text-[#1A2E22] mb-3">Extracted Fields</h3>
                <div className="space-y-2.5">
                  {selectedDocument.fields.map((field) => {
                    const conf = confidenceClasses(field.confidence);
                    const editKey = `${selectedDocument.id}::${field.field}`;
                    return (
                      <div key={field.field} className="rounded-xl border border-[#E1E4DC] p-3">
                        <div className="flex flex-wrap items-center justify-between gap-2">
                          <div className="flex items-center gap-2">
                            <span className="text-xs font-semibold text-[#1A2E22]">{field.field}</span>
                            <span className={`px-1.5 py-0.5 rounded-md text-[10px] font-bold border ${matchStatusClasses(field.matchStatus)}`}>
                              {field.matchStatus.replace('_', ' ')}
                            </span>
                          </div>
                          <div className="flex items-center gap-2">
                            <div className="w-16 h-1.5 rounded-full bg-slate-100 overflow-hidden">
                              <div className={`h-full rounded-full ${conf.bar}`} style={{ width: `${field.confidence}%` }} />
                            </div>
                            <span className={`px-1.5 py-0.5 rounded-md text-[10px] font-bold ${conf.pillBg} ${conf.pillText}`}>
                              {field.confidence}%
                            </span>
                          </div>
                        </div>
                        <p className="text-xs text-[#5B6B60] mt-1.5 font-mono">{field.extractedValue}</p>

                        <div className="flex items-center gap-2 mt-2">
                          <input
                            id={`correct-input-${selectedDocument.id}-${field.field.replace(/\s+/g, '-')}`}
                            type="text"
                            value={fieldEdits[editKey] ?? ''}
                            onChange={(e) => setFieldEdits((prev) => ({ ...prev, [editKey]: e.target.value }))}
                            placeholder="Enter corrected value..."
                            className="flex-1 px-2.5 py-1.5 rounded-lg border border-[#E1E4DC] text-[11px] text-[#1A2E22] outline-hidden focus:border-[#1F6E52] bg-[#F1F3EC] focus:bg-white"
                          />
                          <button
                            id={`correct-btn-${selectedDocument.id}-${field.field.replace(/\s+/g, '-')}`}
                            type="button"
                            onClick={() => handleCorrectField(field.field)}
                            className="px-2.5 py-1.5 rounded-lg bg-[#DCEEE3] hover:bg-[#1F6E52] hover:text-white text-[#17553F] text-[11px] font-bold transition-colors cursor-pointer shrink-0"
                          >
                            Correct
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Actions */}
              <div className="bg-white rounded-2xl border border-[#E1E4DC] shadow-2xs p-5">
                <h3 className="text-sm font-bold text-[#1A2E22] mb-3">Review Decision</h3>
                <div className="flex flex-wrap gap-2">
                  <button
                    id="action-approve"
                    type="button"
                    onClick={handleApprove}
                    className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-[#2F9E6E] hover:bg-[#0ea371] text-white text-xs font-bold transition-colors cursor-pointer shadow-2xs"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    Approve
                  </button>
                  <button
                    id="action-reject"
                    type="button"
                    onClick={handleReject}
                    className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-[#C1503D] hover:bg-[#dc2626] text-white text-xs font-bold transition-colors cursor-pointer shadow-2xs"
                  >
                    <XCircle className="w-4 h-4" />
                    Reject
                  </button>
                  <button
                    id="action-escalate"
                    type="button"
                    onClick={handleEscalate}
                    className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-[#3E8FA6] hover:bg-[#6d28d9] text-white text-xs font-bold transition-colors cursor-pointer shadow-2xs"
                  >
                    <ArrowUpCircle className="w-4 h-4" />
                    Escalate to Practice Admin
                  </button>
                  <button
                    id="action-rescan"
                    type="button"
                    onClick={handleRescan}
                    className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-[#5B6B60] text-xs font-bold transition-colors cursor-pointer shadow-2xs"
                  >
                    <RotateCcw className="w-4 h-4" />
                    Request Re-scan
                  </button>
                </div>
              </div>

              {/* Audit trail */}
              <div className="bg-white rounded-2xl border border-[#E1E4DC] shadow-2xs p-5">
                <div className="flex items-center gap-2 mb-3">
                  <Clock className="w-4 h-4 text-[#5B6B60]" />
                  <h3 className="text-sm font-bold text-[#1A2E22]">Audit Trail</h3>
                  <span className="text-[10px] text-[#5B6B60] font-semibold uppercase tracking-wide">Permanent record</span>
                </div>

                {selectedDocument.auditTrail.length === 0 ? (
                  <p className="text-xs text-[#5B6B60]">No review decisions recorded yet for this document.</p>
                ) : (
                  <ol className="space-y-3">
                    {[...selectedDocument.auditTrail].reverse().map((entry, idx) => {
                      const meta = actionMeta[entry.action];
                      const Icon = meta.icon;
                      return (
                        <li key={`${entry.decidedAt}-${idx}`} className="flex gap-3">
                          <div className={`mt-0.5 p-1.5 rounded-full bg-slate-100 shrink-0 ${meta.color}`}>
                            <Icon className="w-3.5 h-3.5" />
                          </div>
                          <div className="min-w-0 flex-1 pb-3 border-b border-[#E1E4DC] last:border-b-0 last:pb-0">
                            <div className="flex flex-wrap items-center justify-between gap-2">
                              <span className="text-xs font-bold text-[#1A2E22]">{meta.label}</span>
                              <span className="text-[10.5px] text-[#5B6B60]">{formatDateTime(entry.decidedAt)}</span>
                            </div>
                            <p className="text-[11px] text-[#5B6B60] mt-0.5">by {entry.decidedBy}</p>
                            {entry.notes && <p className="text-[11px] text-[#5B6B60] mt-1 italic">"{entry.notes}"</p>}
                          </div>
                        </li>
                      );
                    })}
                  </ol>
                )}
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default DocumentIntakeQueuePage;
