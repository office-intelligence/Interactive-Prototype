import React, { useState } from 'react';
import {
  Building2,
  DollarSign,
  Users,
  ShieldCheck,
  TrendingUp,
  AlertTriangle,
  LogOut,
  Sparkles,
  Lock,
  ChevronDown,
  ChevronUp,
  LifeBuoy,
  FileCheck2,
  CalendarClock,
  Gauge,
  Activity,
  X,
  ExternalLink,
  ClipboardCheck
} from 'lucide-react';
import { CeoPracticeSummary, CeoBusinessMetrics, AuthUser, PracticeType } from '../types';

interface CeoAdminDashboardProps {
  currentUser?: AuthUser | null;
  onLogout: () => void;
}

/* ============================================================
   Mock data — business/compliance metrics only. No patient
   names, charts, or PHI of any kind appear anywhere on this
   page, per the Master CEO account's architectural isolation
   from clinical data.
   ============================================================ */

const MOCK_METRICS: CeoBusinessMetrics = {
  totalPractices: 6,
  totalActiveUsers: 214,
  totalMonthlyRecurringRevenue: 148250,
  netRevenueRetentionPct: 112,
  avgComplianceScore: 91,
  openSupportTickets: 7,
  practicesAtRisk: 1
};

const MOCK_PRACTICES: CeoPracticeSummary[] = [];

interface AuditEvent {
  id: string;
  title: string;
  detail: string;
  date: string;
  icon: React.ReactNode;
}

const AUDIT_EVENTS: AuditEvent[] = [];

/* ============================================================
   Formatting helpers
   ============================================================ */

const formatCurrency = (value: number): string =>
  new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    maximumFractionDigits: 0
  }).format(value);

const formatDate = (iso: string): string => {
  const d = new Date(`${iso}T00:00:00`);
  if (Number.isNaN(d.getTime())) return iso;
  return d.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });
};

const statusStyles: Record<CeoPracticeSummary['subscriptionStatus'], { bg: string; text: string; label: string }> = {
  ACTIVE: { bg: '#E4F3EA', text: '#1B4332', label: 'Active' },
  TRIAL: { bg: '#DCEEE3', text: '#1B4332', label: 'Trial' },
  PAST_DUE: { bg: '#FBEEDB', text: '#7A4E17', label: 'Past Due' },
  CANCELED: { bg: '#FBE4E1', text: '#7A2E22', label: 'Canceled' }
};

const complianceColor = (score: number): { icon: string; bg: string; text: string } => {
  if (score >= 90) return { icon: '#2F9E6E', bg: '#E4F3EA', text: '#1B4332' };
  if (score >= 75) return { icon: '#C98A34', bg: '#FBEEDB', text: '#7A4E17' };
  return { icon: '#C1503D', bg: '#FBE4E1', text: '#7A2E22' };
};

export const CeoAdminDashboard: React.FC<CeoAdminDashboardProps> = ({ currentUser, onLogout }) => {
  const [expandedPracticeId, setExpandedPracticeId] = useState<string | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const metrics = MOCK_METRICS;
  const practices = MOCK_PRACTICES;

  const userDisplayName = currentUser ? `${currentUser.firstName} ${currentUser.lastName}` : 'Master CEO';
  const userInitials = currentUser
    ? `${currentUser.firstName?.[0] || ''}${currentUser.lastName?.[0] || ''}`.toUpperCase()
    : 'CEO';

  const showToast = (message: string) => {
    setToastMessage(message);
    window.setTimeout(() => setToastMessage(null), 3000);
  };

  const togglePractice = (practiceId: string) => {
    setExpandedPracticeId((prev) => (prev === practiceId ? null : practiceId));
  };

  const statCards: Array<{
    id: string;
    label: string;
    value: string;
    icon: React.ReactNode;
    flag?: 'warning' | 'error';
    sub?: string;
  }> = [
    {
      id: 'stat-total-practices',
      label: 'Total Practices',
      value: String(metrics.totalPractices),
      icon: <Building2 className="w-4.5 h-4.5" />
    },
    {
      id: 'stat-active-users',
      label: 'Active Users',
      value: String(metrics.totalActiveUsers),
      icon: <Users className="w-4.5 h-4.5" />
    },
    {
      id: 'stat-mrr',
      label: 'Monthly Recurring Revenue',
      value: formatCurrency(metrics.totalMonthlyRecurringRevenue),
      icon: <DollarSign className="w-4.5 h-4.5" />
    },
    {
      id: 'stat-nrr',
      label: 'Net Revenue Retention',
      value: `${metrics.netRevenueRetentionPct}%`,
      icon: <TrendingUp className="w-4.5 h-4.5" />
    },
    {
      id: 'stat-compliance',
      label: 'Avg. Compliance Score',
      value: `${metrics.avgComplianceScore}`,
      icon: <ShieldCheck className="w-4.5 h-4.5" />
    },
    {
      id: 'stat-risk',
      label: 'Support Tickets / At Risk',
      value: `${metrics.openSupportTickets} / ${metrics.practicesAtRisk}`,
      icon: <LifeBuoy className="w-4.5 h-4.5" />,
      flag: metrics.practicesAtRisk > 0 ? 'error' : metrics.openSupportTickets > 0 ? 'warning' : undefined,
      sub: metrics.practicesAtRisk > 0 ? `${metrics.practicesAtRisk} practice at risk` : undefined
    }
  ];

  return (
    <div className="min-h-screen bg-[#F1F3EC] font-sans text-[#1A2E22]">
      {/* ============================================================
          Top bar — dark navy "business console" chrome, distinct
          from the clinical app's Header (same tokens, leaned harder
          into dark chrome since the audience is executives, not
          clinicians).
          ============================================================ */}
      <header className="sticky top-0 z-30 bg-[#14432E] border-b border-[#14432E] shadow-lg">
        <div className="w-full px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16 gap-3">
            {/* Left: logo mark + console badge */}
            <div className="flex items-center gap-3 min-w-0">
              <div className="w-9 h-9 rounded-xl bg-linear-to-br from-[#1F6E52] to-[#3E8FA6] flex items-center justify-center text-white shadow-sm shrink-0">
                <Activity className="w-5 h-5 text-white" />
              </div>
              <div className="min-w-0">
                <div className="flex items-center gap-2">
                  <span className="font-bold text-white font-display text-sm tracking-tight truncate leading-none">
                    Office Intelligence
                  </span>
                  <span className="hidden sm:inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-bold bg-linear-to-r from-[#3E8FA6]/20 to-[#3E8FA6]/20 text-[#D9A448] border border-[#3E8FA6]/30 uppercase font-mono tracking-wide">
                    <Sparkles className="w-3 h-3 text-[#D9A448]" />
                    CEO Business Console
                  </span>
                </div>
                <div className="text-[11px] text-[#5B6B60] truncate mt-0.5 font-mono">
                  Master administration • business &amp; compliance analytics
                </div>
              </div>
            </div>

            {/* Right: PHI notice + user menu */}
            <div className="flex items-center gap-3 sm:gap-4 shrink-0">
              <div className="hidden md:flex items-center gap-1.5 text-[11px] text-[#5B6B60] font-mono">
                <Lock className="w-3.5 h-3.5 text-[#5B6B60]" />
                <span>Business &amp; compliance data only — no PHI access</span>
              </div>

              <div className="flex items-center gap-2 pl-3 border-l border-white/10">
                <div className="w-7 h-7 rounded-lg bg-[#3E8FA6] text-white font-bold text-xs flex items-center justify-center font-display shadow-xs">
                  {userInitials}
                </div>
                <div className="hidden lg:block text-left max-w-[140px]">
                  <div className="text-xs font-bold text-white truncate leading-tight font-display">
                    {userDisplayName}
                  </div>
                  <div className="text-[10px] text-[#5B6B60] truncate leading-tight font-mono">
                    Master CEO
                  </div>
                </div>
              </div>

              <button
                type="button"
                id="ceo-logout-btn"
                onClick={onLogout}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 text-[#E1E4DC] hover:text-white text-xs font-semibold transition-colors cursor-pointer"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Log Out</span>
              </button>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
        {/* ============================================================
            Top-line metrics row
            ============================================================ */}
        <section id="ceo-metrics-row" className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-6 gap-3">
          {statCards.map((card) => {
            const flagColors =
              card.flag === 'error'
                ? { bg: '#FBE4E1', icon: '#C1503D', text: '#7A2E22', border: '#FCA5A5' }
                : card.flag === 'warning'
                ? { bg: '#FBEEDB', icon: '#C98A34', text: '#7A4E17', border: '#FCD34D' }
                : null;

            return (
              <div
                key={card.id}
                id={card.id}
                className={`rounded-2xl border p-4 shadow-xs bg-white ${
                  flagColors ? '' : 'border-[#E1E4DC]'
                }`}
                style={flagColors ? { borderColor: flagColors.border, backgroundColor: flagColors.bg } : undefined}
              >
                <div className="flex items-center justify-between mb-2">
                  <div
                    className="w-8 h-8 rounded-lg flex items-center justify-center"
                    style={{
                      backgroundColor: flagColors ? '#FFFFFF' : '#DCEEE3',
                      color: flagColors ? flagColors.icon : '#1F6E52'
                    }}
                  >
                    {card.icon}
                  </div>
                  {card.flag && <AlertTriangle className="w-4 h-4" style={{ color: flagColors?.icon }} />}
                </div>
                <div
                  className="text-xl font-bold font-display leading-none"
                  style={{ color: flagColors ? flagColors.text : '#1A2E22' }}
                >
                  {card.value}
                </div>
                <div className="text-[11px] text-[#5B6B60] mt-1.5 font-medium">{card.label}</div>
                {card.sub && (
                  <div className="text-[10px] font-bold mt-1" style={{ color: flagColors?.text }}>
                    {card.sub}
                  </div>
                )}
              </div>
            );
          })}
        </section>

        {/* ============================================================
            Business AI brief — Nightingale AI, CEO-themed
            ============================================================ */}
        <section
          id="ceo-ai-brief"
          className="rounded-2xl border border-[#D9A448] bg-linear-to-br from-[#14432E] via-[#14432E] to-[#101E33] p-5 shadow-lg relative overflow-hidden"
        >
          <div className="absolute -top-10 -right-10 w-40 h-40 rounded-full bg-[#3E8FA6]/20 blur-3xl pointer-events-none" />
          <div className="absolute -bottom-12 -left-12 w-48 h-48 rounded-full bg-[#3E8FA6]/10 blur-3xl pointer-events-none" />
          <div className="relative flex items-start gap-3.5">
            <div className="w-10 h-10 rounded-xl bg-linear-to-br from-[#3E8FA6] to-[#3E8FA6] flex items-center justify-center text-white shrink-0 shadow-md">
              <Sparkles className="w-5 h-5" />
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-2 mb-1">
                <h2 className="text-sm font-bold text-white font-display">Nightingale AI — Executive Brief</h2>
                <span className="px-1.5 py-0.5 rounded-md text-[9px] font-bold bg-white/10 text-[#D9A448] border border-white/10 uppercase font-mono">
                  Business intelligence
                </span>
              </div>
              <p className="text-[13px] text-[#E1E4DC] leading-relaxed">
                MRR grew <span className="font-bold text-white">4% this month</span> across 6 practices, with net revenue
                retention holding at 112%. <span className="font-bold text-[#FCA5A5]">Harborline Multispecialty Clinic</span> is
                12 days past due on its subscription and should be prioritized for outreach. Separately,{' '}
                <span className="font-bold text-white">Meridian Surgeon-Owned Operating Suite&apos;s</span> compliance score
                dropped to 58 after a missed BAA re-acceptance — recommend a compliance follow-up this week.
              </p>
            </div>
          </div>
        </section>

        {/* ============================================================
            Practices table
            ============================================================ */}
        <section id="ceo-practices-table" className="rounded-2xl border border-[#E1E4DC] bg-white shadow-xs overflow-hidden">
          <div className="px-5 py-4 border-b border-[#E1E4DC] flex items-center justify-between">
            <div>
              <h2 className="text-sm font-bold text-[#1A2E22] font-display">Practices</h2>
              <p className="text-[11px] text-[#5B6B60] mt-0.5">Subscription, seat usage, and compliance standing across the platform</p>
            </div>
            <Building2 className="w-4.5 h-4.5 text-[#5B6B60]" />
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse min-w-[900px]">
              <thead>
                <tr className="bg-[#F1F3EC] border-b border-[#E1E4DC]">
                  <th className="px-4 py-2.5 text-[10px] font-bold text-[#5B6B60] uppercase tracking-wide">Practice</th>
                  <th className="px-4 py-2.5 text-[10px] font-bold text-[#5B6B60] uppercase tracking-wide">Seats</th>
                  <th className="px-4 py-2.5 text-[10px] font-bold text-[#5B6B60] uppercase tracking-wide">MRR</th>
                  <th className="px-4 py-2.5 text-[10px] font-bold text-[#5B6B60] uppercase tracking-wide">Tier</th>
                  <th className="px-4 py-2.5 text-[10px] font-bold text-[#5B6B60] uppercase tracking-wide">Status</th>
                  <th className="px-4 py-2.5 text-[10px] font-bold text-[#5B6B60] uppercase tracking-wide">Compliance</th>
                  <th className="px-4 py-2.5 text-[10px] font-bold text-[#5B6B60] uppercase tracking-wide">Last Audit</th>
                  <th className="px-4 py-2.5 text-[10px] font-bold text-[#5B6B60] uppercase tracking-wide"></th>
                </tr>
              </thead>
              <tbody>
                {practices.map((practice) => {
                  const isExpanded = expandedPracticeId === practice.practiceId;
                  const status = statusStyles[practice.subscriptionStatus];
                  const compliance = complianceColor(practice.complianceScore);
                  const usagePct = Math.min(
                    100,
                    Math.round((practice.seatsActive / Math.max(1, practice.seatsLicensed)) * 100)
                  );

                  return (
                    <React.Fragment key={practice.practiceId}>
                      <tr
                        id={`ceo-practice-row-${practice.practiceId}`}
                        onClick={() => togglePractice(practice.practiceId)}
                        className={`border-b border-[#E1E4DC] cursor-pointer transition-colors hover:bg-[#F1F3EC] ${
                          isExpanded ? 'bg-[#F1F3EC]' : ''
                        }`}
                      >
                        <td className="px-4 py-3">
                          <div className="text-xs font-bold text-[#1A2E22]">{practice.practiceName}</div>
                          <div className="text-[10px] text-[#5B6B60] mt-0.5">{practice.practiceType}</div>
                        </td>
                        <td className="px-4 py-3">
                          <div className="text-xs font-semibold text-[#1A2E22] mb-1">
                            {practice.seatsActive} / {practice.seatsLicensed}
                          </div>
                          <div className="w-24 h-1.5 rounded-full bg-[#E1E4DC] overflow-hidden">
                            <div
                              className="h-full rounded-full bg-[#1F6E52]"
                              style={{ width: `${usagePct}%` }}
                            />
                          </div>
                        </td>
                        <td className="px-4 py-3">
                          <span className="text-xs font-bold text-[#1A2E22]">{formatCurrency(practice.monthlyRecurringRevenue)}</span>
                        </td>
                        <td className="px-4 py-3">
                          <span className="px-2 py-1 rounded-md text-[10px] font-bold bg-[#EAF2EC] text-[#1B4332] border border-[#DCEEE3]">
                            {practice.subscriptionTier}
                          </span>
                        </td>
                        <td className="px-4 py-3">
                          <span
                            className="px-2 py-1 rounded-md text-[10px] font-bold"
                            style={{ backgroundColor: status.bg, color: status.text }}
                          >
                            {status.label}
                          </span>
                        </td>
                        <td className="px-4 py-3">
                          <div className="flex items-center gap-2">
                            <div
                              className="w-8 h-8 rounded-full flex items-center justify-center text-[10px] font-bold shrink-0"
                              style={{ backgroundColor: compliance.bg, color: compliance.text, border: `2px solid ${compliance.icon}` }}
                            >
                              {practice.complianceScore}
                            </div>
                          </div>
                        </td>
                        <td className="px-4 py-3">
                          <span className="text-[11px] text-[#5B6B60]">{formatDate(practice.lastAuditDate)}</span>
                        </td>
                        <td className="px-4 py-3 text-right">
                          {isExpanded ? (
                            <ChevronUp className="w-4 h-4 text-[#5B6B60] ml-auto" />
                          ) : (
                            <ChevronDown className="w-4 h-4 text-[#5B6B60] ml-auto" />
                          )}
                        </td>
                      </tr>

                      {isExpanded && (
                        <tr className="border-b border-[#E1E4DC] bg-[#F1F3EC]">
                          <td colSpan={8} className="px-4 py-4">
                            <div
                              id={`ceo-practice-detail-${practice.practiceId}`}
                              className="rounded-xl border border-[#E1E4DC] bg-white p-4 grid grid-cols-2 sm:grid-cols-4 gap-4"
                            >
                              <div>
                                <div className="text-[10px] font-bold text-[#5B6B60] uppercase tracking-wide mb-1">Practice Type</div>
                                <div className="text-xs font-semibold text-[#1A2E22]">{practice.practiceType}</div>
                              </div>
                              <div>
                                <div className="text-[10px] font-bold text-[#5B6B60] uppercase tracking-wide mb-1">Seats Licensed / Active</div>
                                <div className="text-xs font-semibold text-[#1A2E22]">
                                  {practice.seatsLicensed} / {practice.seatsActive}
                                </div>
                              </div>
                              <div>
                                <div className="text-[10px] font-bold text-[#5B6B60] uppercase tracking-wide mb-1">Monthly Recurring Revenue</div>
                                <div className="text-xs font-semibold text-[#1A2E22]">{formatCurrency(practice.monthlyRecurringRevenue)}</div>
                              </div>
                              <div>
                                <div className="text-[10px] font-bold text-[#5B6B60] uppercase tracking-wide mb-1">Subscription Tier</div>
                                <div className="text-xs font-semibold text-[#1A2E22]">{practice.subscriptionTier}</div>
                              </div>
                              <div>
                                <div className="text-[10px] font-bold text-[#5B6B60] uppercase tracking-wide mb-1">Subscription Status</div>
                                <div className="text-xs font-semibold text-[#1A2E22]">{status.label}</div>
                              </div>
                              <div>
                                <div className="text-[10px] font-bold text-[#5B6B60] uppercase tracking-wide mb-1">Compliance Score</div>
                                <div className="text-xs font-semibold" style={{ color: compliance.text }}>
                                  {practice.complianceScore} / 100
                                </div>
                              </div>
                              <div>
                                <div className="text-[10px] font-bold text-[#5B6B60] uppercase tracking-wide mb-1">Last Audit Date</div>
                                <div className="text-xs font-semibold text-[#1A2E22]">{formatDate(practice.lastAuditDate)}</div>
                              </div>
                              <div>
                                <div className="text-[10px] font-bold text-[#5B6B60] uppercase tracking-wide mb-1">Onboarded</div>
                                <div className="text-xs font-semibold text-[#1A2E22]">{formatDate(practice.onboardedDate)}</div>
                              </div>

                              <div className="col-span-2 sm:col-span-4 pt-2 border-t border-[#E1E4DC] flex justify-end">
                                <button
                                  type="button"
                                  id={`ceo-view-compliance-report-${practice.practiceId}`}
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    showToast(`Compliance report for ${practice.practiceName} is not available in this preview.`);
                                  }}
                                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#1F6E52] hover:bg-[#17553F] text-white text-[11px] font-bold transition-colors cursor-pointer"
                                >
                                  <ExternalLink className="w-3.5 h-3.5" />
                                  View Full Compliance Report
                                </button>
                              </div>
                            </div>
                          </td>
                        </tr>
                      )}
                    </React.Fragment>
                  );
                })}
              </tbody>
            </table>
          </div>
        </section>

        {/* ============================================================
            Platform compliance / audit timeline
            ============================================================ */}
        <section id="ceo-audit-timeline" className="rounded-2xl border border-[#E1E4DC] bg-white shadow-xs p-5">
          <div className="flex items-center gap-2 mb-4">
            <Gauge className="w-4.5 h-4.5 text-[#5B6B60]" />
            <h2 className="text-sm font-bold text-[#1A2E22] font-display">Platform Compliance &amp; Audit Activity</h2>
          </div>
          <ol className="space-y-4">
            {AUDIT_EVENTS.map((event, idx) => (
              <li key={event.id} className="flex gap-3">
                <div className="flex flex-col items-center">
                  <div className="w-7 h-7 rounded-full bg-[#EAF2EC] text-[#1F6E52] flex items-center justify-center shrink-0">
                    {event.icon}
                  </div>
                  {idx < AUDIT_EVENTS.length - 1 && <div className="w-px flex-1 bg-[#E1E4DC] mt-1" />}
                </div>
                <div className="pb-1">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-[#1A2E22]">{event.title}</span>
                    <span className="text-[10px] text-[#5B6B60] font-mono">{formatDate(event.date)}</span>
                  </div>
                  <p className="text-[11px] text-[#5B6B60] mt-0.5">{event.detail}</p>
                </div>
              </li>
            ))}
          </ol>
        </section>
      </main>

      {/* ============================================================
          Toast (no-op action feedback)
          ============================================================ */}
      {toastMessage && (
        <div
          id="ceo-toast"
          className="fixed bottom-5 right-5 z-50 max-w-sm bg-[#14432E] border border-[#14432E] text-[#E1E4DC] text-xs rounded-xl shadow-2xl px-4 py-3 flex items-start gap-2.5 animate-in fade-in slide-in-from-bottom-2 duration-150"
        >
          <ShieldCheck className="w-4 h-4 text-[#3E8FA6] shrink-0 mt-0.5" />
          <span className="flex-1">{toastMessage}</span>
          <button
            type="button"
            onClick={() => setToastMessage(null)}
            className="text-[#5B6B60] hover:text-white cursor-pointer shrink-0"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}
    </div>
  );
};

export default CeoAdminDashboard;
