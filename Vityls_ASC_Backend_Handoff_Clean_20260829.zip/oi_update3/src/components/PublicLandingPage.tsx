import React, { useState } from 'react';
import { 
  ShieldCheck, 
  Sparkles, 
  Calendar, 
  FileText, 
  Activity, 
  Lock, 
  ArrowRight, 
  CheckCircle2, 
  Building2, 
  Zap, 
  Mail, 
  Phone, 
  MessageSquare, 
  Layers, 
  Stethoscope, 
  Clock, 
  ChevronRight, 
  Cpu, 
  Check, 
  Globe, 
  HeartHandshake, 
  BarChart3, 
  KeyRound, 
  UserPlus, 
  LogIn,
  Eye,
  Sliders,
  FileCheck,
  Send,
  Workflow,
  CheckCircle,
  Users,
  CreditCard,
  ClipboardCheck,
  TrendingUp,
  Inbox,
  Menu,
  X,
  Bot,
  Terminal,
  LayoutGrid,
  CheckSquare,
  FileUp
} from 'lucide-react';

interface PublicLandingPageProps {
  onNavigateLogin: () => void;
  onNavigateRegister: () => void;
  onEnterApp: () => void;
  onNavigatePortal?: () => void;
}

export const PublicLandingPage: React.FC<PublicLandingPageProps> = ({
  onNavigateLogin,
  onNavigateRegister,
  onEnterApp,
  onNavigatePortal
}) => {
  const [activeWorkflowTab, setActiveWorkflowTab] = useState<'email' | 'schedule' | 'clearance' | 'communication'>('email');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const workflowDetails = {
    email: {
      title: 'Autonomous Clinical Inbox & Document OCR Parsing',
      tag: 'Zero-Touch Ingestion',
      description: 'Office Intelligence continuously scans incoming practice emails, e-faxes, lab portals, and referral pipelines. Incoming lab panels, cardiology clearances, specialty referral notes, EKG tracings, and radiology PDFs are automatically parsed, OCR-indexed, and filed directly into the corresponding patient chart with zero manual clerical intervention.',
      bullets: [
        'Automatic recognition of PDF lab reports, imaging summaries, and specialist consults',
        'Intelligent chart reconciliation via patient DOB, MRN, name, and encounter date',
        'Extracts abnormal diagnostic values and elevates urgent clinical alerts to providers',
        'Reduces practice inbox triage and manual scanning time by over 88%'
      ],
      icon: Mail,
      metric: '99.6%',
      metricLabel: 'Parsing Accuracy',
    },
    schedule: {
      title: 'Predictive Multi-Room & Provider Schedule Orchestration',
      tag: 'Dynamic Practice Flow',
      description: 'Intelligent scheduling engine that coordinates appointment types, examination rooms, surgical suites, and physician availability. The platform dynamically recalibrates clinic queues, flags pending pre-visit requirements, and prevents bottleneck delays before they impact office throughput.',
      bullets: [
        'Concurrent multi-room visual matrix with live patient progression tracking',
        'Physician and procedure-specific historical duration models for optimized booking',
        'Real-time exam room, pre-op bay, and recovery bed status indicators',
        'Automated multi-channel alerts for room readiness and check-in milestones'
      ],
      icon: Calendar,
      metric: '28 min',
      metricLabel: 'Daily Practice Time Saved',
    },
    clearance: {
      title: 'Autonomous Pre-Visit & Pre-Procedure Readiness Scoring',
      tag: 'Zero Day-Of Cancellations',
      description: 'Every scheduled appointment and procedure receives an AI Readiness Score (0–100%) computed in real time from completed medical history, insurance eligibility, outside diagnostic clearances, signed consents, and necessary order sets.',
      bullets: [
        'Automated 7-day, 48-hour, and 24-hour pre-visit verification audits',
        'One-click automated fast-track resolution faxes to outside PCP and cardiology clinics',
        'Seamless digital patient intake with real-time biometric and photo validation',
        'Pre-screened allergy cross-checks and medical contraindication alerts'
      ],
      icon: Zap,
      metric: '98.5%',
      metricLabel: 'On-Time Encounter Starts',
    },
    communication: {
      title: 'Omnichannel HIPAA-Compliant Patient & Vendor Messaging',
      tag: 'Secure Medical Communication',
      description: 'Two-way HIPAA-compliant SMS, email, and portal communication for arrival directions, digital check-in links, pre-visit instructions, prescription notifications, and post-encounter care tracking. Automated coordination with pharmacies, labs, and medical suppliers.',
      bullets: [
        'Automated appointment confirmations and arrival texts with 1-touch response',
        'Direct digital e-Prescribing with Surescripts routing and pharmacy updates',
        'Medical supply order tracking with automated serial & lot number verification',
        'Interactive patient messaging with automated AI-assisted clinical triage'
      ],
      icon: MessageSquare,
      metric: '100%',
      metricLabel: 'HIPAA & TCPA Compliant',
    }
  };

  const useCases = [
    {
      title: 'Primary Care & Multi-Specialty Clinics',
      icon: Building2,
      description: 'High-volume outpatient practices requiring streamlined patient check-in, real-time insurance verification, automated chart filing, and rapid documentation.',
      features: ['Automated intake & digital kiosk sync', 'Real-time 270/271 eligibility checks', 'Surescripts e-Prescribing integration'],
    },
    {
      title: 'Ambulatory Surgical Centers (ASC)',
      icon: Activity,
      description: 'Multi-OR surgical facilities requiring surgical block scheduling, anesthesia risk pre-scrubbing, turnover optimization, and AAAASF/Joint Commission compliance.',
      features: ['Multi-OR visual schedule matrix', 'WHO/AORN surgical safety checklists', 'Aldrete PACU flowsheet scoring'],
    },
    {
      title: 'Specialty Surgical & Medical Practices',
      icon: Stethoscope,
      description: 'Plastic surgery, ophthalmology, orthopedics, ENT, and dermatology suites balancing consultative office visits with office-based procedures.',
      features: ['Longitudinal photographic records', 'Specialty operative note builders', 'Custom consent pathway automation'],
    },
    {
      title: 'Aesthetic, Wellness & Concierge Centers',
      icon: Sparkles,
      description: 'Bespoke medical aesthetic clinics and concierge wellness centers seeking premium patient experiences, point-of-sale billing, and automated follow-ups.',
      features: ['Digital photo baseline review', 'Doctor-to-pay & self-pay ledger', 'Automated SMS post-treatment care'],
    }
  ];

  return (
    <div className="min-h-screen bg-[#F1F3EC] text-[#1A2E22] font-sans selection:bg-[#DCEEE3] selection:text-[#1B4332]">
      
      {/* 1. Public Top Navigation Bar (Sage & Emerald Theme) */}
      <header className="sticky top-0 z-50 bg-[#F1F3EC]/90 backdrop-blur-xl border-b border-[#E1E4DC] shadow-2xs">
        <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 h-16 sm:h-18 flex items-center justify-between gap-2 sm:gap-4">
          
          {/* Mobile Hamburger Menu Button & Logo */}
          <div className="flex items-center gap-2.5 sm:gap-3 min-w-0">
            <button
              type="button"
              onClick={() => setIsMobileMenuOpen(true)}
              className="p-2 rounded-xl bg-white hover:bg-[#F1F3EC] text-[#1A2E22] border border-[#E1E4DC] transition-colors cursor-pointer md:hidden shrink-0 shadow-2xs"
              title="Open Navigation Menu"
              aria-label="Open Navigation Menu"
              id="landing-mobile-menu-btn"
            >
              <Menu className="w-5 h-5 text-[#1F6E52]" />
            </button>

            <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-gradient-to-tr from-[#14432E] via-[#1F6E52] to-[#2F9E6E] flex items-center justify-center text-white shadow-2xs shrink-0">
              <Sparkles className="w-4 h-4 sm:w-5 sm:h-5 text-[#DCEEE3] stroke-[2.5]" />
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-1.5 sm:gap-2">
                <span className="font-serif text-base sm:text-xl font-bold text-[#1A2E22] tracking-tight truncate">Office Intelligence</span>
                <span className="hidden sm:inline-block px-2 py-0.5 rounded-full text-[10px] font-bold bg-[#DCEEE3] text-[#1B4332] border border-[#E1E4DC] uppercase tracking-wider shrink-0">
                  Medical AI OS
                </span>
              </div>
              <p className="text-[10px] sm:text-[11px] text-[#5B6B60] font-medium truncate max-w-[200px] sm:max-w-none">Practice Management &amp; Clinical Intelligence</p>
            </div>
          </div>

          {/* Desktop Center Nav Links */}
          <nav className="hidden md:flex items-center gap-5 lg:gap-7 text-xs font-semibold text-[#5B6B60]">
            <a href="#philosophy" className="hover:text-[#1F6E52] transition-colors">Design Philosophy</a>
            <a href="#features" className="hover:text-[#1F6E52] transition-colors">Core Capabilities</a>
            <a href="#workflows" className="hover:text-[#1F6E52] transition-colors">AI Workflows</a>
            <a href="#specialties" className="hover:text-[#1F6E52] transition-colors">Specialties &amp; Clinics</a>
            <a href="#hipaa" className="hover:text-[#1F6E52] transition-colors">HIPAA &amp; Security</a>
            <a href="#administration" className="hover:text-[#1F6E52] transition-colors">Practice Setup</a>
          </nav>

          {/* Action Buttons */}
          <div className="flex items-center gap-1.5 sm:gap-3 shrink-0">
            {onNavigatePortal && (
              <button
                onClick={onNavigatePortal}
                id="public-nav-portal-btn"
                className="hidden sm:flex px-3 py-1.5 sm:px-3.5 sm:py-2 text-xs font-bold text-[#1B4332] bg-[#DCEEE3] hover:bg-[#DCEEE3] rounded-xl transition-all items-center gap-1.5 cursor-pointer border border-[#E1E4DC] shadow-2xs font-sans"
                title="Open Patient Portal (Review Sample Fictitious Data)"
              >
                <Users className="w-4 h-4 text-[#1F6E52]" />
                <span className="hidden md:inline">Patient Portal</span>
                <span className="md:hidden">Portal</span>
                <span className="hidden lg:inline px-1.5 py-0.2 rounded text-[9px] font-bold bg-[#1F6E52] text-white uppercase tracking-tight">New</span>
              </button>
            )}

            <button
              onClick={onNavigateLogin}
              id="public-nav-login-btn"
              className="px-3 py-1.5 sm:px-4 sm:py-2 text-xs font-bold text-[#1A2E22] hover:bg-white bg-[#F1F3EC] rounded-xl transition-all flex items-center gap-1.5 cursor-pointer border border-[#E1E4DC] shadow-2xs font-sans"
            >
              <LogIn className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-[#1F6E52]" />
              <span>Log In</span>
            </button>

            <button
              onClick={onNavigateRegister}
              id="public-nav-register-btn"
              className="px-3 py-1.5 sm:px-4 sm:py-2 bg-[#1F6E52] hover:bg-[#17553F] text-white text-xs font-bold rounded-xl shadow-2xs hover:shadow-xs transition-all flex items-center gap-1.5 cursor-pointer transform hover:-translate-y-0.5 font-sans"
            >
              <UserPlus className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-white" />
              <span className="hidden sm:inline">Get Started</span>
              <span className="sm:hidden">Join</span>
            </button>

            <button
              onClick={onEnterApp}
              id="public-nav-demo-btn"
              className="hidden lg:flex px-3.5 py-2 bg-white hover:bg-[#F1F3EC] text-[#1A2E22] text-xs font-semibold rounded-xl transition-all items-center gap-1.5 shadow-2xs border border-[#E1E4DC] cursor-pointer font-sans"
              title="Launch Live Practice Dashboard Demo"
            >
              <Eye className="w-3.5 h-3.5 text-[#1F6E52]" />
              <span>Live Demo</span>
            </button>
          </div>
        </div>
      </header>

      {/* Mobile Off-Canvas Drawer */}
      {isMobileMenuOpen && (
        <div className="fixed inset-0 z-50 md:hidden animate-in fade-in duration-200">
          {/* Backdrop Overlay */}
          <div 
            onClick={() => setIsMobileMenuOpen(false)}
            className="fixed inset-0 bg-[#1A2E22]/50 backdrop-blur-xs transition-opacity"
          />

          {/* Off-Canvas Left Drawer */}
          <aside className="fixed inset-y-0 left-0 z-50 w-76 max-w-[85vw] bg-[#F1F3EC] border-r border-[#E1E4DC] shadow-2xl p-5 flex flex-col justify-between overflow-y-auto animate-in slide-in-from-left duration-300">
            <div className="space-y-6">
              
              {/* Drawer Top Header with Brand & Close Button */}
              <div className="flex items-center justify-between pb-4 border-b border-[#E1E4DC]">
                <div className="flex items-center gap-2.5">
                  <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-[#14432E] via-[#1F6E52] to-[#2F9E6E] flex items-center justify-center text-white shadow-2xs">
                    <Sparkles className="w-4 h-4 text-[#DCEEE3] stroke-[2.5]" />
                  </div>
                  <div>
                    <h2 className="font-serif text-base font-bold text-[#1A2E22] tracking-tight">Office Intelligence</h2>
                    <span className="px-1.5 py-0.2 rounded text-[9px] font-bold bg-[#DCEEE3] text-[#1B4332] border border-[#E1E4DC] uppercase tracking-wider">
                      Medical AI OS
                    </span>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => setIsMobileMenuOpen(false)}
                  className="p-2 rounded-xl bg-white hover:bg-[#F1F3EC] text-[#5B6B60] hover:text-[#1A2E22] transition-colors cursor-pointer border border-[#E1E4DC]"
                  title="Close navigation menu"
                  id="landing-drawer-close-btn"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Vertical Navigation Links */}
              <div className="space-y-1">
                <p className="text-[10px] font-mono uppercase tracking-wider text-[#5B6B60] px-3 py-1 font-bold">
                  Navigation
                </p>
                <a
                  href="#philosophy"
                  onClick={() => setIsMobileMenuOpen(false)}
                  className="flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-semibold text-[#1A2E22] hover:bg-white transition-colors"
                >
                  <Sparkles className="w-4 h-4 text-[#1F6E52]" />
                  <span>Design Philosophy</span>
                </a>
                <a
                  href="#features"
                  onClick={() => setIsMobileMenuOpen(false)}
                  className="flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-semibold text-[#1A2E22] hover:bg-white transition-colors"
                >
                  <Zap className="w-4 h-4 text-[#1F6E52]" />
                  <span>Core Capabilities</span>
                </a>
                <a
                  href="#workflows"
                  onClick={() => setIsMobileMenuOpen(false)}
                  className="flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-semibold text-[#1A2E22] hover:bg-white transition-colors"
                >
                  <Cpu className="w-4 h-4 text-[#1F6E52]" />
                  <span>AI Workflows</span>
                </a>
                <a
                  href="#specialties"
                  onClick={() => setIsMobileMenuOpen(false)}
                  className="flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-semibold text-[#1A2E22] hover:bg-white transition-colors"
                >
                  <Stethoscope className="w-4 h-4 text-[#1F6E52]" />
                  <span>Specialties &amp; Clinics</span>
                </a>
                <a
                  href="#hipaa"
                  onClick={() => setIsMobileMenuOpen(false)}
                  className="flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-semibold text-[#1A2E22] hover:bg-white transition-colors"
                >
                  <ShieldCheck className="w-4 h-4 text-[#1F6E52]" />
                  <span>HIPAA &amp; Security</span>
                </a>
                <a
                  href="#administration"
                  onClick={() => setIsMobileMenuOpen(false)}
                  className="flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-semibold text-[#1A2E22] hover:bg-white transition-colors"
                >
                  <Sliders className="w-4 h-4 text-[#1F6E52]" />
                  <span>Practice Setup</span>
                </a>
              </div>

              {/* Action Buttons in Drawer */}
              <div className="space-y-2.5 pt-4 border-t border-[#E1E4DC]">
                <p className="text-[10px] font-mono uppercase tracking-wider text-[#5B6B60] px-3 py-1 font-bold">
                  Quick Access
                </p>

                {onNavigatePortal && (
                  <button
                    onClick={() => {
                      setIsMobileMenuOpen(false);
                      onNavigatePortal();
                    }}
                    className="w-full py-2.5 px-3.5 text-xs font-bold text-[#1B4332] bg-[#DCEEE3] hover:bg-[#DCEEE3] rounded-xl transition-all flex items-center justify-between cursor-pointer border border-[#E1E4DC] shadow-2xs"
                  >
                    <div className="flex items-center gap-2">
                      <Users className="w-4 h-4 text-[#1F6E52]" />
                      <span>Patient Portal</span>
                    </div>
                    <span className="px-1.5 py-0.2 rounded text-[9px] font-bold bg-[#1F6E52] text-white uppercase">New</span>
                  </button>
                )}

                <button
                  onClick={() => {
                    setIsMobileMenuOpen(false);
                    onEnterApp();
                  }}
                  className="w-full py-2.5 px-3.5 bg-white hover:bg-[#F1F3EC] text-[#1A2E22] text-xs font-semibold rounded-xl transition-all flex items-center gap-2 shadow-2xs border border-[#E1E4DC] cursor-pointer"
                >
                  <Eye className="w-4 h-4 text-[#1F6E52]" />
                  <span>Live Practice Demo</span>
                </button>

                <button
                  onClick={() => {
                    setIsMobileMenuOpen(false);
                    onNavigateLogin();
                  }}
                  className="w-full py-2.5 px-3.5 text-xs font-bold text-[#1A2E22] hover:bg-white bg-[#F1F3EC] rounded-xl transition-all flex items-center gap-2 cursor-pointer border border-[#E1E4DC]"
                >
                  <LogIn className="w-4 h-4 text-[#1F6E52]" />
                  <span>Log In to Practice</span>
                </button>

                <button
                  onClick={() => {
                    setIsMobileMenuOpen(false);
                    onNavigateRegister();
                  }}
                  className="w-full py-2.5 px-3.5 bg-[#1F6E52] hover:bg-[#17553F] text-white text-xs font-bold rounded-xl shadow-2xs transition-all flex items-center justify-center gap-2 cursor-pointer"
                >
                  <UserPlus className="w-4 h-4 text-white" />
                  <span>Get Started / Create Account</span>
                </button>
              </div>
            </div>

            {/* Drawer Footer */}
            <div className="pt-4 border-t border-[#E1E4DC] mt-6 text-center text-[11px] text-[#5B6B60]">
              <div className="flex items-center justify-center gap-1.5 text-[#1F6E52] font-semibold mb-1">
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>256-Bit Encrypted • HIPAA Verified</span>
              </div>
              <p>© 2026 Office Intelligence OS</p>
            </div>
          </aside>
        </div>
      )}

      {/* 2. Hero Section (Sage & Emerald Theme) */}
      <section className="relative overflow-hidden pt-16 pb-20 lg:pt-20 lg:pb-28 border-b border-[#E1E4DC] bg-[#F1F3EC]">
        
        {/* Subtle Ambient Glow */}
        <div className="absolute inset-0 z-0 overflow-hidden pointer-events-none">
          <div className="absolute -top-32 left-1/2 -translate-x-1/2 w-[800px] h-[450px] bg-gradient-to-r from-[#DCEEE3]/80 via-[#E1E4DC]/60 to-[#DCEEE3]/80 blur-[120px] rounded-full" />
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          
          <div className="text-center max-w-4xl mx-auto space-y-6">
            
            {/* High-Visibility AI Status Pill */}
            <div className="inline-flex items-center gap-2.5 px-4 py-1.5 rounded-full bg-white text-[#1A2E22] shadow-2xs text-xs font-semibold border border-[#E1E4DC] backdrop-blur-md">
              <span className="relative flex h-2.5 w-2.5">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#2F9E6E] opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-[#1F6E52]"></span>
              </span>
              <Sparkles className="w-4 h-4 text-[#1F6E52] animate-pulse" />
              <span className="font-bold tracking-wide text-[#1A2E22]">Autonomous Clinical Intelligence Engine</span>
              <span className="w-1.5 h-1.5 rounded-full bg-[#E1E4DC]" />
              <span className="text-[#1B4332] font-mono text-[11px] font-bold px-2 py-0.5 rounded-full bg-[#DCEEE3] border border-[#E1E4DC]">HIPAA Compliant</span>
            </div>

            {/* Main Headline with Refined Typography */}
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-serif font-bold text-[#1A2E22] tracking-tight leading-[1.15]">
              Super-Intelligent AI for <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#14432E] via-[#1F6E52] to-[#2F9E6E]">Medical &amp; Surgical Practices</span>
            </h1>

            {/* Sub-headline Box */}
            <div className="bg-white/80 backdrop-blur-xs p-4 sm:p-5 rounded-2xl border border-[#E1E4DC] max-w-3xl mx-auto shadow-2xs">
              <p className="text-base sm:text-lg text-[#5B6B60] font-normal leading-relaxed">
                Office Intelligence is the unified clinical AI operating system built for medical practices, outpatient clinics, specialty centers, and surgical pavilions. From autonomous email &amp; fax parsing and dynamic multi-room scheduling to automated patient check-in, EMR charting, and HIPAA-compliant communication — elevate every healthcare practice with seamless clinical precision.
              </p>
            </div>

            {/* Primary Action Buttons */}
            <div className="flex flex-wrap items-center justify-center gap-4 pt-2">
              <button
                onClick={onNavigateRegister}
                id="hero-register-cta-btn"
                className="px-6 py-3.5 bg-[#1F6E52] hover:bg-[#17553F] text-white font-bold text-sm rounded-xl shadow-2xs hover:shadow-xs transition-all flex items-center gap-2 cursor-pointer transform hover:-translate-y-0.5 active:scale-95 font-sans"
              >
                <UserPlus className="w-4 h-4 text-white" />
                <span>Register Practice &amp; Start Setup</span>
                <ArrowRight className="w-4 h-4 ml-0.5" />
              </button>

              <button
                onClick={onNavigateLogin}
                id="hero-login-cta-btn"
                className="px-6 py-3.5 bg-white hover:bg-[#F1F3EC] text-[#1A2E22] font-bold text-sm rounded-xl border border-[#E1E4DC] shadow-2xs transition-all flex items-center gap-2 cursor-pointer font-sans"
              >
                <LogIn className="w-4 h-4 text-[#1F6E52]" />
                <span>Sign In to Dashboard</span>
              </button>

              {onNavigatePortal && (
                <button
                  onClick={onNavigatePortal}
                  id="hero-patient-portal-cta-btn"
                  className="px-5 py-3.5 bg-[#DCEEE3] hover:bg-[#DCEEE3] text-[#1B4332] font-bold text-sm rounded-xl border border-[#E1E4DC] shadow-2xs transition-all flex items-center gap-2 cursor-pointer font-sans"
                >
                  <Users className="w-4 h-4 text-[#1F6E52]" />
                  <span>Patient Portal (Demo Data)</span>
                </button>
              )}

              <button
                onClick={onEnterApp}
                id="hero-enter-demo-btn"
                className="px-5 py-3.5 bg-white hover:bg-[#F1F3EC] text-[#5B6B60] hover:text-[#1A2E22] font-semibold text-sm rounded-xl border border-[#E1E4DC] shadow-2xs transition-all flex items-center gap-2 cursor-pointer font-sans"
              >
                <Eye className="w-4 h-4 text-[#1F6E52]" />
                <span>Explore Live Demo</span>
              </button>
            </div>

            {/* Trust Badges */}
            <div className="pt-6 flex flex-wrap items-center justify-center gap-4 sm:gap-6 text-xs text-[#5B6B60] font-medium">
              <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-white border border-[#E1E4DC] shadow-2xs">
                <ShieldCheck className="w-4 h-4 text-[#1F6E52]" />
                <span className="text-[#1A2E22] font-semibold">HIPAA &amp; BAA Ready</span>
              </div>
              <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-white border border-[#E1E4DC] shadow-2xs">
                <Lock className="w-4 h-4 text-[#1F6E52]" />
                <span className="text-[#1A2E22] font-semibold">256-Bit TLS &amp; At-Rest Encryption</span>
              </div>
              <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-white border border-[#E1E4DC] shadow-2xs">
                <Building2 className="w-4 h-4 text-[#1F6E52]" />
                <span className="text-[#1A2E22] font-semibold">Joint Commission / AAAASF Compliant</span>
              </div>
              <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-white border border-[#E1E4DC] shadow-2xs">
                <CheckCircle2 className="w-4 h-4 text-[#1F6E52]" />
                <span className="text-[#1A2E22] font-semibold">Surescripts &amp; Quest Integrated</span>
              </div>
            </div>

          </div>

          {/* Hero Visual Mockup: Office Intelligence Medical OS Command Window */}
          <div className="mt-12 max-w-5xl mx-auto rounded-2xl bg-white border border-[#E1E4DC] shadow-xl overflow-hidden">
            
            {/* Window Header */}
            <div className="bg-[#F1F3EC] px-5 py-3.5 flex items-center justify-between border-b border-[#E1E4DC]">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-[#C1503D]/80" />
                <div className="w-3 h-3 rounded-full bg-[#C88A2E]/80" />
                <div className="w-3 h-3 rounded-full bg-[#2F9E6E]/80" />
                <span className="ml-2 text-xs font-mono text-[#1A2E22] font-bold">Office Intelligence Medical OS v2.4 • Active Practice Command</span>
              </div>

              <div className="flex items-center gap-3 text-xs">
                <span className="px-2.5 py-0.5 rounded-full bg-[#DCEEE3] text-[#1B4332] border border-[#E1E4DC] font-semibold flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#2F9E6E] animate-ping" />
                  Clinical AI Engine Live
                </span>
                <span className="text-[#5B6B60] hidden sm:inline font-medium">Vityls ASC &amp; Medical Institute</span>
              </div>
            </div>

            {/* Dashboard Snapshot Content */}
            <div className="p-6 bg-[#FAFBFA] space-y-5">
              
              {/* Live Intelligence Banner */}
              <div className="bg-[#F1F3EC] rounded-xl p-4 text-[#1A2E22] flex flex-wrap items-center justify-between gap-4 border border-[#E1E4DC] shadow-2xs">
                <div className="flex items-center gap-3.5">
                  <div className="p-2.5 rounded-xl bg-[#DCEEE3] border border-[#E1E4DC] text-[#1F6E52]">
                    <Sparkles className="w-5 h-5 text-[#1F6E52]" />
                  </div>
                  <div>
                    <h2 className="text-sm font-bold tracking-wide flex items-center gap-2 text-[#1A2E22]">
                      Nightingale AI Morning Operational Brief
                      <span className="text-[10px] px-2 py-0.5 bg-[#DCEEE3] text-[#1B4332] border border-[#E1E4DC] rounded-full font-mono uppercase font-bold">Live</span>
                    </h2>
                    <p className="text-xs text-[#5B6B60] mt-0.5">
                      18 clinical encounters scheduled today. 6 surgical cases staged across OR 1 &amp; OR 2. 98% average readiness score. E-Prescribe gateway active.
                    </p>
                  </div>
                </div>

                <button 
                  onClick={onEnterApp}
                  className="px-3.5 py-1.5 rounded-lg bg-[#1F6E52] hover:bg-[#17553F] text-white font-bold text-xs transition-colors cursor-pointer shadow-2xs font-sans"
                >
                  Launch Live Dashboard
                </button>
              </div>

              {/* Sample Live Patient Encounters Grid */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                
                {/* Case 1 */}
                <div className="bg-white p-4 rounded-xl border border-[#E1E4DC] hover:border-[#1F6E52] transition-all space-y-2.5 shadow-2xs">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-[#1A2E22]">Primary Provider</span>
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-[#DCEEE3] text-[#1B4332] border border-[#E1E4DC]">
                      OR 1 • 07:00 AM
                    </span>
                  </div>
                  <div className="text-xs text-[#1A2E22] font-semibold">
                    Patient (53F)
                  </div>
                  <div className="text-[11px] text-[#5B6B60]">
                    Bilateral Revision &amp; Tissue Reconstruction
                  </div>
                  <div className="pt-1 flex items-center justify-between text-[11px]">
                    <span className="text-[#1F6E52] font-bold flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5" /> 98% Readiness
                    </span>
                    <span className="px-2 py-0.5 rounded bg-[#DCEEE3] text-[#1B4332] border border-[#E1E4DC] font-semibold">
                      IN PRE-OP
                    </span>
                  </div>
                </div>

                {/* Case 2 */}
                <div className="bg-white p-4 rounded-xl border border-[#E1E4DC] hover:border-[#1F6E52] transition-all space-y-2.5 shadow-2xs">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-[#1A2E22]">Dr. Evelyn Vance</span>
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-[#DCEEE3] text-[#1B4332] border border-[#E1E4DC]">
                      OR 1 • 08:30 AM
                    </span>
                  </div>
                  <div className="text-xs text-[#1A2E22] font-semibold">
                    Patient (66F)
                  </div>
                  <div className="text-[11px] text-[#5B6B60]">
                    Blepharoplasty, Fat Repositioning &amp; Ptosis
                  </div>
                  <div className="pt-1 flex items-center justify-between text-[11px]">
                    <span className="text-[#7A4E17] font-bold flex items-center gap-1">
                      <Zap className="w-3.5 h-3.5 text-[#7A4E17]" /> Fast-Track Resolved
                    </span>
                    <span className="px-2 py-0.5 rounded bg-[#FBEEDB] text-[#7A4E17] border border-[#E1E4DC] font-semibold">
                      CHECKED IN
                    </span>
                  </div>
                </div>

                {/* Case 3 */}
                <div className="bg-white p-4 rounded-xl border border-[#E1E4DC] hover:border-[#1F6E52] transition-all space-y-2.5 shadow-2xs">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-[#1A2E22]">Provider</span>
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-[#DCEEE3] text-[#1B4332] border border-[#E1E4DC]">
                      CLINIC BAY 2 • 10:15 AM
                    </span>
                  </div>
                  <div className="text-xs text-[#1A2E22] font-semibold">
                    Patient (36F)
                  </div>
                  <div className="text-[11px] text-[#5B6B60]">
                    Comprehensive Outpatient Consultation
                  </div>
                  <div className="pt-1 flex items-center justify-between text-[11px]">
                    <span className="text-[#1F6E52] font-bold flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5" /> Digital Intake Ingested
                    </span>
                    <span className="px-2 py-0.5 rounded bg-[#DCEEE3] text-[#1B4332] border border-[#E1E4DC] font-semibold">
                      CHART READY
                    </span>
                  </div>
                </div>

              </div>

            </div>

          </div>

        </div>
      </section>

      {/* 2.5. Core Design Philosophy Section */}
      <section id="philosophy" className="py-20 bg-white border-b border-[#E1E4DC] relative overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          
          {/* Section Header */}
          <div className="text-center max-w-3xl mx-auto space-y-4">
            <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-[#DCEEE3] border border-[#E1E4DC] text-[#1B4332] text-xs font-bold shadow-2xs">
              <Sparkles className="w-3.5 h-3.5 text-[#1F6E52]" />
              <span>Core Design Philosophy</span>
            </div>
            
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-serif font-bold text-[#1A2E22] tracking-tight leading-tight">
              From <span className="text-[#5B6B60] italic font-normal">"Form Overload"</span> to <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#14432E] via-[#1F6E52] to-[#2F9E6E]">Staff-Grade AI Orchestration</span>
            </h2>
            
            <p className="text-base sm:text-lg text-[#5B6B60] leading-relaxed">
              In traditional EHR and practice management software, every possible action requires a visible button, dropdown, filter panel, or input form. By elevating <strong className="text-[#1A2E22] font-semibold">Nightingale AI</strong> to an active member of your practice staff (similar to a Head Surgical Coordinator or Office Manager), you can remove <strong className="text-[#1F6E52] font-bold">60–70% of on-screen visual noise</strong> and delegate multi-step administrative workflows through natural language commands.
            </p>
          </div>

          {/* 3 Core Architecture Comparison Cards */}
          <div className="mt-14 grid grid-cols-1 lg:grid-cols-3 gap-8">
            
            {/* Card 1 */}
            <div className="bg-[#F1F3EC] p-7 rounded-2xl border border-[#E1E4DC] hover:border-[#1F6E52] transition-all space-y-4 shadow-2xs flex flex-col justify-between">
              <div className="space-y-4">
                <div className="w-12 h-12 rounded-xl bg-[#DCEEE3] text-[#1F6E52] flex items-center justify-center font-bold border border-[#E1E4DC] shadow-2xs">
                  <LayoutGrid className="w-6 h-6 stroke-[2.2]" />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-[#1A2E22]">Zero Visual Clutter</h3>
                  <p className="text-xs text-[#5B6B60] mt-1 font-medium">Calm, focused clinical screens replace 50+ nested buttons</p>
                </div>
                <div className="space-y-3 pt-2">
                  <div className="p-3 rounded-xl bg-white/70 border border-[#E1E4DC] text-xs text-[#5B6B60] space-y-1">
                    <span className="font-bold text-[#7A2E22] block text-[11px] uppercase tracking-wider">Traditional EHR Defect:</span>
                    <span>Cluttered toolbars, endless dropdowns, and deep nested submenus that cause cognitive fatigue and documentation burnout.</span>
                  </div>
                  <div className="p-3 rounded-xl bg-[#DCEEE3]/70 border border-[#1F6E52]/20 text-xs text-[#1B4332] space-y-1">
                    <span className="font-bold text-[#1F6E52] block text-[11px] uppercase tracking-wider">Office Intelligence:</span>
                    <span>A clean, distraction-free clinical canvas where routine tasks and deep updates execute seamlessly via conversational commands.</span>
                  </div>
                </div>
              </div>
              <div className="pt-2 text-xs font-semibold text-[#1F6E52] flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4" /> 60–70% less visual interface clutter
              </div>
            </div>

            {/* Card 2 */}
            <div className="bg-[#F1F3EC] p-7 rounded-2xl border border-[#E1E4DC] hover:border-[#1F6E52] transition-all space-y-4 shadow-2xs flex flex-col justify-between">
              <div className="space-y-4">
                <div className="w-12 h-12 rounded-xl bg-[#DCEEE3] text-[#1F6E52] flex items-center justify-center font-bold border border-[#E1E4DC] shadow-2xs">
                  <Bot className="w-6 h-6 stroke-[2.2]" />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-[#1A2E22]">Staff-Grade Delegation</h3>
                  <p className="text-xs text-[#5B6B60] mt-1 font-medium">Operates like an attentive Head Surgical Coordinator</p>
                </div>
                <div className="space-y-3 pt-2">
                  <div className="p-3 rounded-xl bg-white/70 border border-[#E1E4DC] text-xs text-[#5B6B60] space-y-1">
                    <span className="font-bold text-[#7A2E22] block text-[11px] uppercase tracking-wider">Traditional EHR Defect:</span>
                    <span>Staff must manually cross-reference faxed reports, call outside cardiology clinics, and tabulate clearance checklists by hand.</span>
                  </div>
                  <div className="p-3 rounded-xl bg-[#DCEEE3]/70 border border-[#1F6E52]/20 text-xs text-[#1B4332] space-y-1">
                    <span className="font-bold text-[#1F6E52] block text-[11px] uppercase tracking-wider">Office Intelligence:</span>
                    <span>Nightingale AI continuously audits lab values, detects clearance gaps, tracks surgical packet readiness, and drafts orders proactively.</span>
                  </div>
                </div>
              </div>
              <div className="pt-2 text-xs font-semibold text-[#1F6E52] flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4" /> Zero day-of procedure cancellations
              </div>
            </div>

            {/* Card 3 */}
            <div className="bg-[#F1F3EC] p-7 rounded-2xl border border-[#E1E4DC] hover:border-[#1F6E52] transition-all space-y-4 shadow-2xs flex flex-col justify-between">
              <div className="space-y-4">
                <div className="w-12 h-12 rounded-xl bg-[#DCEEE3] text-[#1F6E52] flex items-center justify-center font-bold border border-[#E1E4DC] shadow-2xs">
                  <Terminal className="w-6 h-6 stroke-[2.2]" />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-[#1A2E22]">Natural Language Command</h3>
                  <p className="text-xs text-[#5B6B60] mt-1 font-medium">Multi-step administrative actions triggered in one sentence</p>
                </div>
                <div className="space-y-3 pt-2">
                  <div className="p-3 rounded-xl bg-white/70 border border-[#E1E4DC] text-xs text-[#5B6B60] space-y-1">
                    <span className="font-bold text-[#7A2E22] block text-[11px] uppercase tracking-wider">Traditional EHR Defect:</span>
                    <span>Clicking across 6 different screens just to reschedule a case, add an allergy, block calendar time, or ping nursing staff.</span>
                  </div>
                  <div className="p-3 rounded-xl bg-[#DCEEE3]/70 border border-[#1F6E52]/20 text-xs text-[#1B4332] space-y-1">
                    <span className="font-bold text-[#1F6E52] block text-[11px] uppercase tracking-wider">Office Intelligence:</span>
                    <span>Speak or type naturally: <em>"Block OR 1 on Tuesday for Dr. Sterling"</em> or <em>"Clear patient for tissue reconstruction"</em>.</span>
                  </div>
                </div>
              </div>
              <div className="pt-2 text-xs font-semibold text-[#1F6E52] flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4" /> Sub-second multi-step command execution
              </div>
            </div>

          </div>

          {/* Interactive Command Gallery Showcase */}
          <div className="mt-12 bg-gradient-to-br from-[#1A2E22] via-[#14432E] to-[#1A2E22] p-8 sm:p-10 rounded-3xl text-white shadow-xl border border-[#14432E] relative overflow-hidden">
            <div className="relative z-10 flex flex-col lg:flex-row items-center justify-between gap-8">
              <div className="space-y-3 max-w-xl text-left">
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/10 text-[#DCEEE3] text-xs font-bold border border-white/20">
                  <Sparkles className="w-3.5 h-3.5 text-[#DCEEE3]" />
                  <span>Real-World Nightingale AI Commands</span>
                </div>
                <h3 className="text-2xl sm:text-3xl font-serif font-bold text-white tracking-tight">
                  Command Your Entire Medical Practice with Natural Clinical Directives
                </h3>
                <p className="text-xs sm:text-sm text-[#5B6B60] leading-relaxed">
                  Instead of searching for buried checkboxes and settings forms, staff and physicians instruct Nightingale AI just as they would an experienced clinical coordinator.
                </p>
              </div>

              {/* Sample Command Pills */}
              <div className="w-full lg:max-w-md space-y-2.5">
                <div className="p-3 rounded-xl bg-white/10 border border-white/15 backdrop-blur-xs flex items-center gap-3 text-xs text-white">
                  <div className="w-6 h-6 rounded-lg bg-[#1F6E52] text-white flex items-center justify-center shrink-0 font-mono text-[10px] font-bold">1</div>
                  <span className="font-mono text-[#DCEEE3]">"Clear patient Patient for surgical OR 1 at 07:00 AM"</span>
                </div>

                <div className="p-3 rounded-xl bg-white/10 border border-white/15 backdrop-blur-xs flex items-center gap-3 text-xs text-white">
                  <div className="w-6 h-6 rounded-lg bg-[#1F6E52] text-white flex items-center justify-center shrink-0 font-mono text-[10px] font-bold">2</div>
                  <span className="font-mono text-[#DCEEE3]">"Block OR 2 every Monday 07:00 - 12:00 for Primary Provider"</span>
                </div>

                <div className="p-3 rounded-xl bg-white/10 border border-white/15 backdrop-blur-xs flex items-center gap-3 text-xs text-white">
                  <div className="w-6 h-6 rounded-lg bg-[#1F6E52] text-white flex items-center justify-center shrink-0 font-mono text-[10px] font-bold">3</div>
                  <span className="font-mono text-[#DCEEE3]">"Add allergy to Amoxicillin and update E-Prescribe gateway"</span>
                </div>

                <div className="p-3 rounded-xl bg-white/10 border border-white/15 backdrop-blur-xs flex items-center gap-3 text-xs text-white">
                  <div className="w-6 h-6 rounded-lg bg-[#1F6E52] text-white flex items-center justify-center shrink-0 font-mono text-[10px] font-bold">4</div>
                  <span className="font-mono text-[#DCEEE3]">"Run daily morning brief across all 18 scheduled encounters"</span>
                </div>
              </div>
            </div>
          </div>

        </div>
      </section>

      {/* 3. Features Section: The AI-Powered Healthcare Operating System */}
      <section id="features" className="py-20 bg-white border-b border-[#E1E4DC]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="text-center max-w-3xl mx-auto space-y-3">
            <span className="text-xs font-bold text-[#1F6E52] uppercase tracking-widest">
              Core Capabilities
            </span>
            <h2 className="text-3xl sm:text-4xl font-serif font-bold text-[#1A2E22]">
              The AI Practice OS Built for Modern Healthcare
            </h2>
            <p className="text-sm text-[#5B6B60] leading-relaxed">
              Eliminate administrative fatigue and manual chart logging with autonomous clinical intelligence engineered for medical clinics, specialist practices, and surgical pavilions.
            </p>
          </div>

          <div className="mt-14 grid grid-cols-1 md:grid-cols-3 gap-8">
            
            {/* Feature 1 */}
            <div className="bg-[#F1F3EC] p-6 rounded-2xl border border-[#E1E4DC] hover:border-[#1F6E52] hover:shadow-md transition-all space-y-4 shadow-2xs">
              <div className="w-12 h-12 rounded-xl bg-[#DCEEE3] text-[#1F6E52] flex items-center justify-center shadow-2xs font-bold border border-[#E1E4DC]">
                <FileText className="w-6 h-6 stroke-[2.5]" />
              </div>
              <h3 className="text-lg font-bold text-[#1A2E22]">Longitudinal EMR &amp; Digital Charting</h3>
              <p className="text-xs text-[#5B6B60] leading-relaxed">
                Comprehensive patient medical records with interactive intake forms, nursing care pathways, digital consent signatures, and automatic PDF export.
              </p>
              <ul className="space-y-1.5 text-xs text-[#1A2E22] font-medium">
                <li className="flex items-center gap-2"><Check className="w-4 h-4 text-[#1F6E52]" /> Specialty operative &amp; encounter note templates</li>
                <li className="flex items-center gap-2"><Check className="w-4 h-4 text-[#1F6E52]" /> Live vital signs flowsheet &amp; PACU tracking</li>
                <li className="flex items-center gap-2"><Check className="w-4 h-4 text-[#1F6E52]" /> Clinical photography &amp; diagnostic image review</li>
              </ul>
            </div>

            {/* Feature 2 */}
            <div className="bg-[#F1F3EC] p-6 rounded-2xl border border-[#E1E4DC] hover:border-[#1F6E52] hover:shadow-md transition-all space-y-4 shadow-2xs">
              <div className="w-12 h-12 rounded-xl bg-[#DCEEE3] text-[#1F6E52] flex items-center justify-center shadow-2xs font-bold border border-[#E1E4DC]">
                <Cpu className="w-6 h-6 stroke-[2.5]" />
              </div>
              <h3 className="text-lg font-bold text-[#1A2E22]">Autonomous Practice Oversight</h3>
              <p className="text-xs text-[#5B6B60] leading-relaxed">
                Nightingale AI acts as an omnipresent clinical manager, identifying schedule gaps, detecting expired provider credentials, and monitoring order sets.
              </p>
              <ul className="space-y-1.5 text-xs text-[#1A2E22] font-medium">
                <li className="flex items-center gap-2"><Check className="w-4 h-4 text-[#1F6E52]" /> Daily Morning Brief with high-priority action items</li>
                <li className="flex items-center gap-2"><Check className="w-4 h-4 text-[#1F6E52]" /> Continuous compliance &amp; accreditation monitoring</li>
                <li className="flex items-center gap-2"><Check className="w-4 h-4 text-[#1F6E52]" /> Natural language chat queries across practice records</li>
              </ul>
            </div>

            {/* Feature 3 */}
            <div className="bg-[#F1F3EC] p-6 rounded-2xl border border-[#E1E4DC] hover:border-[#1F6E52] hover:shadow-md transition-all space-y-4 shadow-2xs">
              <div className="w-12 h-12 rounded-xl bg-[#DCEEE3] text-[#1F6E52] flex items-center justify-center shadow-2xs font-bold border border-[#E1E4DC]">
                <CreditCard className="w-6 h-6 stroke-[2.5]" />
              </div>
              <h3 className="text-lg font-bold text-[#1A2E22]">Revenue Cycle &amp; Claim Scrubbing</h3>
              <p className="text-xs text-[#5B6B60] leading-relaxed">
                Integrated medical billing engine supporting CMS-1500 and UB-04 EDI claims, 270/271 real-time eligibility verification, and multi-tier fee allocations.
              </p>
              <ul className="space-y-1.5 text-xs text-[#1A2E22] font-medium">
                <li className="flex items-center gap-2"><Check className="w-4 h-4 text-[#1F6E52]" /> Pre-submission AI claim validation engine</li>
                <li className="flex items-center gap-2"><Check className="w-4 h-4 text-[#1F6E52]" /> Doctor-to-Pay, Self-Pay &amp; Insurance splits</li>
                <li className="flex items-center gap-2"><Check className="w-4 h-4 text-[#1F6E52]" /> Credit card terminal integration with line item invoices</li>
              </ul>
            </div>

            {/* Feature 4 */}
            <div className="bg-[#F1F3EC] p-6 rounded-2xl border border-[#E1E4DC] hover:border-[#1F6E52] hover:shadow-md transition-all space-y-4 shadow-2xs">
              <div className="w-12 h-12 rounded-xl bg-[#E7F1F3] text-[#3E8FA6] flex items-center justify-center shadow-2xs font-bold border border-[#E1E4DC]">
                <Users className="w-6 h-6 stroke-[2.5]" />
              </div>
              <h3 className="text-lg font-bold text-[#1A2E22]">Payroll &amp; Staffing Command Center</h3>
              <p className="text-xs text-[#5B6B60] leading-relaxed">
                Office-manager-scoped employee accounts, daily time clock oversight, and biweekly payroll timesheet approval — with an AI staffing brief every morning.
              </p>
              <ul className="space-y-1.5 text-xs text-[#1A2E22] font-medium">
                <li className="flex items-center gap-2"><Check className="w-4 h-4 text-[#3E8FA6]" /> Account lock/unlock, reset &amp; invite workflows</li>
                <li className="flex items-center gap-2"><Check className="w-4 h-4 text-[#3E8FA6]" /> Mobile workforce clock-in with exception flags</li>
                <li className="flex items-center gap-2"><Check className="w-4 h-4 text-[#3E8FA6]" /> Biweekly timesheet approval before pay runs</li>
              </ul>
            </div>

            {/* Feature 5 */}
            <div className="bg-[#F1F3EC] p-6 rounded-2xl border border-[#E1E4DC] hover:border-[#1F6E52] hover:shadow-md transition-all space-y-4 shadow-2xs">
              <div className="w-12 h-12 rounded-xl bg-[#E7F1F3] text-[#3E8FA6] flex items-center justify-center shadow-2xs font-bold border border-[#E1E4DC]">
                <FileUp className="w-6 h-6 stroke-[2.5]" />
              </div>
              <h3 className="text-lg font-bold text-[#1A2E22]">AI Document Intake &amp; OCR Review</h3>
              <p className="text-xs text-[#5B6B60] leading-relaxed">
                Faxes, scans, and portal uploads are parsed and confidence-scored automatically — anything uncertain routes to a human review queue with a permanent audit trail.
              </p>
              <ul className="space-y-1.5 text-xs text-[#1A2E22] font-medium">
                <li className="flex items-center gap-2"><Check className="w-4 h-4 text-[#3E8FA6]" /> Field-level confidence scoring &amp; patient matching</li>
                <li className="flex items-center gap-2"><Check className="w-4 h-4 text-[#3E8FA6]" /> Side-by-side correction, escalation &amp; re-scan</li>
                <li className="flex items-center gap-2"><Check className="w-4 h-4 text-[#3E8FA6]" /> Full audit trail on every review decision</li>
              </ul>
            </div>

            {/* Feature 6 */}
            <div className="bg-[#F1F3EC] p-6 rounded-2xl border border-[#E1E4DC] hover:border-[#1F6E52] hover:shadow-md transition-all space-y-4 shadow-2xs">
              <div className="w-12 h-12 rounded-xl bg-[#14432E] text-[#DCEEE3] flex items-center justify-center shadow-2xs font-bold border border-[#E1E4DC]">
                <ShieldCheck className="w-6 h-6 stroke-[2.5]" />
              </div>
              <h3 className="text-lg font-bold text-[#1A2E22]">Master CEO Business Console</h3>
              <p className="text-xs text-[#5B6B60] leading-relaxed">
                A separate, PHI-isolated business-administration account for ownership and executive teams — practices, subscriptions, revenue, and compliance posture in one view.
              </p>
              <ul className="space-y-1.5 text-xs text-[#1A2E22] font-medium">
                <li className="flex items-center gap-2"><Check className="w-4 h-4 text-[#1F6E52]" /> Multi-practice revenue &amp; seat utilization tracking</li>
                <li className="flex items-center gap-2"><Check className="w-4 h-4 text-[#1F6E52]" /> Platform-wide compliance scoring &amp; audit history</li>
                <li className="flex items-center gap-2"><Check className="w-4 h-4 text-[#1F6E52]" /> Zero clinical/PHI data exposure by design</li>
              </ul>
            </div>

          </div>

          {/* Dedicated Interactive Patient Portal Showcase Card */}
          <div className="mt-12 bg-[#DCEEE3] p-7 sm:p-8 rounded-3xl border border-[#E1E4DC] shadow-sm relative overflow-hidden">
            <div className="flex flex-col lg:flex-row items-center justify-between gap-6 relative z-10">
              <div className="space-y-3 text-left max-w-2xl">
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white text-[#1B4332] border border-[#E1E4DC] text-xs font-bold shadow-2xs">
                  <Users className="w-3.5 h-3.5 text-[#1F6E52]" />
                  <span>Interactive Patient Portal Connected to Main EMR</span>
                </div>
                <h3 className="text-2xl font-serif font-bold text-[#1A2E22]">
                  Empower Patients with Seamless Self-Service, Intake Forms &amp; Direct Messaging
                </h3>
                <p className="text-xs text-[#5B6B60] leading-relaxed font-medium">
                  Patients register using their registered email and set up a secure password to view appointment timelines, submit emailed intake forms, send HIPAA-encrypted messages to their care team, upload diagnostic records into the main OI document folder, and request new visits.
                </p>
                <div className="flex flex-wrap items-center gap-4 text-xs font-semibold text-[#1B4332] pt-1">
                  <span className="flex items-center gap-1.5"><CheckCircle2 className="w-4 h-4 text-[#1F6E52]" /> Digital Intake Form Submissions</span>
                  <span className="flex items-center gap-1.5"><CheckCircle2 className="w-4 h-4 text-[#1F6E52]" /> Real-time Document Sync to EMR</span>
                  <span className="flex items-center gap-1.5"><CheckCircle2 className="w-4 h-4 text-[#1F6E52]" /> Pre-loaded Fictitious Review Accounts</span>
                </div>
              </div>

              {onNavigatePortal && (
                <div className="flex flex-col items-center sm:items-end gap-3 shrink-0">
                  <button
                    onClick={onNavigatePortal}
                    id="features-patient-portal-launch-btn"
                    className="px-6 py-3.5 bg-[#1F6E52] hover:bg-[#17553F] text-white font-bold text-sm rounded-2xl shadow-md transition-all flex items-center gap-2 cursor-pointer transform hover:-translate-y-0.5 font-sans"
                  >
                    <Users className="w-4 h-4 text-white" />
                    <span>Launch Patient Portal Demo</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                  <p className="text-[11px] text-[#5B6B60] text-center sm:text-right font-medium">
                    Try sample profiles: <span className="text-[#1A2E22] font-semibold">danielle.vance@example.com</span> or <span className="text-[#1A2E22] font-semibold">elena.rostova@example.com</span>
                  </p>
                </div>
              )}
            </div>
          </div>

        </div>
      </section>

      {/* 4. Workflow Section: Emails, Attachments, Schedules, Communications */}
      <section id="workflows" className="py-20 bg-[#F1F3EC] border-b border-[#E1E4DC]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="text-center max-w-3xl mx-auto space-y-3">
            <span className="text-xs font-bold text-[#1F6E52] uppercase tracking-widest">
              Intelligent Healthcare Workflows
            </span>
            <h2 className="text-3xl sm:text-4xl font-serif font-bold text-[#1A2E22]">
              How Office Intelligence Automates Daily Operations
            </h2>
            <p className="text-sm text-[#5B6B60] leading-relaxed">
              Watch how incoming emails, medical faxes, appointment requests, diagnostic lab panels, and patient communications flow autonomously.
            </p>
          </div>

          {/* Workflow Tabs */}
          <div className="mt-10 flex flex-wrap justify-center gap-2 p-1.5 bg-white rounded-2xl max-w-3xl mx-auto border border-[#E1E4DC] shadow-2xs">
            <button
              onClick={() => setActiveWorkflowTab('email')}
              className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-2 font-sans ${
                activeWorkflowTab === 'email'
                  ? 'bg-[#1F6E52] text-white shadow-2xs'
                  : 'text-[#5B6B60] hover:text-[#1A2E22] hover:bg-[#F1F3EC]'
              }`}
            >
              <Mail className="w-4 h-4" />
              <span>Email &amp; Fax Parsing</span>
            </button>

            <button
              onClick={() => setActiveWorkflowTab('schedule')}
              className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-2 font-sans ${
                activeWorkflowTab === 'schedule'
                  ? 'bg-[#1F6E52] text-white shadow-2xs'
                  : 'text-[#5B6B60] hover:text-[#1A2E22] hover:bg-[#F1F3EC]'
              }`}
            >
              <Calendar className="w-4 h-4" />
              <span>Schedule Matrix</span>
            </button>

            <button
              onClick={() => setActiveWorkflowTab('clearance')}
              className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-2 font-sans ${
                activeWorkflowTab === 'clearance'
                  ? 'bg-[#1F6E52] text-white shadow-2xs'
                  : 'text-[#5B6B60] hover:text-[#1A2E22] hover:bg-[#F1F3EC]'
              }`}
            >
              <Zap className="w-4 h-4" />
              <span>Readiness Scoring</span>
            </button>

            <button
              onClick={() => setActiveWorkflowTab('communication')}
              className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-2 font-sans ${
                activeWorkflowTab === 'communication'
                  ? 'bg-[#1F6E52] text-white shadow-2xs'
                  : 'text-[#5B6B60] hover:text-[#1A2E22] hover:bg-[#F1F3EC]'
              }`}
            >
              <MessageSquare className="w-4 h-4" />
              <span>Secure Messaging</span>
            </button>
          </div>

          {/* Active Workflow Card */}
          <div className="mt-8 bg-white p-8 rounded-2xl border border-[#E1E4DC] shadow-lg max-w-4xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            
            <div className="lg:col-span-8 space-y-4">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#DCEEE3] border border-[#E1E4DC] text-[#1B4332] text-xs font-bold">
                <Sparkles className="w-3.5 h-3.5 text-[#1F6E52]" />
                <span>{workflowDetails[activeWorkflowTab].tag}</span>
              </div>
              <h3 className="text-2xl font-serif font-bold text-[#1A2E22]">
                {workflowDetails[activeWorkflowTab].title}
              </h3>
              <p className="text-xs sm:text-sm text-[#5B6B60] leading-relaxed">
                {workflowDetails[activeWorkflowTab].description}
              </p>
              <div className="pt-2 space-y-2">
                {workflowDetails[activeWorkflowTab].bullets.map((bullet, idx) => (
                  <div key={idx} className="flex items-start gap-2 text-xs text-[#1A2E22] font-medium">
                    <CheckCircle2 className="w-4 h-4 text-[#1F6E52] shrink-0 mt-0.5" />
                    <span>{bullet}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="lg:col-span-4 bg-[#F1F3EC] p-6 rounded-xl border border-[#E1E4DC] space-y-4 text-center">
              <div className="text-4xl font-bold font-mono text-[#1F6E52]">
                {workflowDetails[activeWorkflowTab].metric}
              </div>
              <div className="text-xs font-semibold text-[#5B6B60]">
                {workflowDetails[activeWorkflowTab].metricLabel}
              </div>
              <div className="pt-2">
                <button
                  onClick={onEnterApp}
                  className="w-full py-2.5 bg-[#1F6E52] hover:bg-[#17553F] text-white rounded-lg text-xs font-bold transition-all shadow-2xs cursor-pointer font-sans"
                >
                  Test In Live Environment
                </button>
              </div>
            </div>

          </div>

        </div>
      </section>

      {/* 5. Specialties & Practice Environments Section */}
      <section id="specialties" className="py-20 bg-white border-b border-[#E1E4DC]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="text-center max-w-3xl mx-auto space-y-3">
            <span className="text-xs font-bold text-[#1F6E52] uppercase tracking-widest">
              Versatile Healthcare Solutions
            </span>
            <h2 className="text-3xl sm:text-4xl font-serif font-bold text-[#1A2E22]">
              Built for Every Medical &amp; Surgical Environment
            </h2>
            <p className="text-sm text-[#5B6B60] leading-relaxed">
              From high-throughput outpatient clinics and ambulatory surgery centers to private specialist offices, Office Intelligence adapts effortlessly to your clinical specialty.
            </p>
          </div>

          <div className="mt-14 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {useCases.map((uc, i) => {
              const Icon = uc.icon;
              return (
                <div key={i} className="bg-[#F1F3EC] p-6 rounded-2xl border border-[#E1E4DC] hover:border-[#1F6E52] hover:shadow-md transition-all space-y-4 flex flex-col justify-between shadow-2xs">
                  <div className="space-y-3">
                    <div className="w-10 h-10 rounded-xl bg-white border border-[#E1E4DC] flex items-center justify-center shadow-2xs text-[#1F6E52]">
                      <Icon className="w-5 h-5" />
                    </div>
                    <h3 className="text-base font-bold text-[#1A2E22]">{uc.title}</h3>
                    <p className="text-xs text-[#5B6B60] leading-relaxed">{uc.description}</p>
                  </div>
                  <div className="pt-3 border-t border-[#E1E4DC] space-y-1.5 text-[11px] text-[#1A2E22] font-medium">
                    {uc.features.map((f, fi) => (
                      <div key={fi} className="flex items-center gap-1.5">
                        <span className="w-1.5 h-1.5 rounded-full bg-[#1F6E52]" />
                        <span>{f}</span>
                      </div>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>

        </div>
      </section>

      {/* 6. HIPAA & Enterprise Security Section */}
      <section id="hipaa" className="py-20 bg-[#F1F3EC] border-b border-[#E1E4DC]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="bg-[#1A2E22] rounded-3xl p-8 sm:p-12 text-white shadow-xl border border-[#14432E] relative overflow-hidden">
            
            <div className="relative z-10 max-w-3xl space-y-5">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/10 text-[#DCEEE3] text-xs font-bold border border-white/20">
                <ShieldCheck className="w-4 h-4 text-[#DCEEE3]" />
                <span>Enterprise Healthcare Security Standard</span>
              </div>

              <h2 className="text-3xl sm:text-4xl font-serif font-bold tracking-tight text-white">
                HIPAA-Compliant by Design. Absolute Privacy for Clinical Data.
              </h2>

              <p className="text-sm text-[#5B6B60] leading-relaxed">
                Office Intelligence executes strict end-to-end encryption protocols, granular role-based access control (RBAC), automated Business Associate Agreements (BAAs), and immutable tamper-proof audit trails ensuring total compliance with federal and state healthcare regulations.
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-4 text-xs font-medium text-[#E1E4DC]">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-[#2F9E6E]" />
                  <span>256-Bit TLS in transit &amp; AES-256 at rest</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-[#2F9E6E]" />
                  <span>Signed BAA automatically provisioned</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-[#2F9E6E]" />
                  <span>Immutable audit logging for all ePHI access</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-[#2F9E6E]" />
                  <span>Two-factor EPCS authentication for e-Prescribe</span>
                </div>
              </div>

              <div className="pt-4 flex flex-wrap items-center gap-4">
                <button
                  onClick={onNavigateRegister}
                  className="px-6 py-3 bg-[#1F6E52] hover:bg-[#17553F] text-white font-bold text-xs rounded-xl transition-all shadow-md cursor-pointer font-sans"
                >
                  Create Secure Practice Account
                </button>
                <button
                  onClick={() => alert('HIPAA Compliance Verification: Office Intelligence maintains strict adherence to HIPAA Security & Privacy Rules, ISO 27001, and SOC 2 Type II with signed BAAs for all clinical workflows.')}
                  className="px-5 py-3 bg-white/10 hover:bg-white/20 text-white font-semibold text-xs rounded-xl border border-white/20 transition-all cursor-pointer font-sans"
                >
                  Download Security Whitepaper
                </button>
              </div>
            </div>

          </div>

        </div>
      </section>

      {/* 7. Practice Administration & Onboarding Teaser Section */}
      <section id="administration" className="py-16 bg-white border-b border-[#E1E4DC]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-[#F1F3EC] rounded-2xl border border-[#E1E4DC] p-8 flex flex-wrap items-center justify-between gap-6 shadow-2xs">
            <div className="space-y-2 max-w-2xl">
              <div className="flex items-center gap-2 text-xs font-bold text-[#1F6E52]">
                <Sliders className="w-4 h-4" />
                <span>Rapid Practice Setup</span>
              </div>
              <h2 className="text-2xl font-serif font-bold text-[#1A2E22]">
                Configure Your Facility, Providers, and Calendar in Minutes
              </h2>
              <p className="text-xs text-[#5B6B60] leading-relaxed">
                Define your practice profile, provider NPI credentials, appointment visit types, exam rooms, operating suites, and intake forms with unified ease.
              </p>
            </div>

            <div className="flex items-center gap-3">
              <button
                onClick={onNavigateRegister}
                className="px-5 py-3 bg-[#1F6E52] hover:bg-[#17553F] text-white font-bold text-xs rounded-xl shadow-2xs transition-all flex items-center gap-2 cursor-pointer font-sans"
              >
                <UserPlus className="w-4 h-4 text-white" />
                <span>Start Practice Setup</span>
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* 8. Public Footer (Sage/Emerald Contrast Theme) */}
      <footer className="bg-[#1A2E22] text-[#5B6B60] py-12 border-t border-[#14432E]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
          
          <div className="flex flex-wrap items-center justify-between gap-6 pb-8 border-b border-white/10">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-[#14432E] via-[#1F6E52] to-[#2F9E6E] flex items-center justify-center text-white font-bold shadow-2xs">
                <Sparkles className="w-4 h-4 text-[#DCEEE3] stroke-[2.5]" />
              </div>
              <div>
                <span className="font-serif text-lg font-bold text-white tracking-tight">Office Intelligence</span>
                <p className="text-[11px] text-[#5B6B60]">HIPAA-Compliant AI Medical Practice Management System</p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              {onNavigatePortal && (
                <button
                  onClick={onNavigatePortal}
                  className="px-3.5 py-2 bg-white/10 hover:bg-white/20 text-[#DCEEE3] text-xs font-bold rounded-lg transition-colors cursor-pointer border border-white/20 flex items-center gap-1.5 font-sans"
                >
                  <Users className="w-3.5 h-3.5 text-[#DCEEE3]" />
                  <span>Patient Portal</span>
                </button>
              )}
              <button
                onClick={onNavigateLogin}
                className="px-4 py-2 bg-white/10 hover:bg-white/20 text-white text-xs font-bold rounded-lg transition-colors cursor-pointer border border-white/20 font-sans"
              >
                Log In
              </button>
              <button
                onClick={onNavigateRegister}
                className="px-4 py-2 bg-[#1F6E52] hover:bg-[#17553F] text-white text-xs font-bold rounded-lg transition-colors cursor-pointer font-sans shadow-2xs"
              >
                Register Practice
              </button>
            </div>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-xs text-[#5B6B60]">
            <div className="space-y-2">
              <div className="font-bold text-white uppercase tracking-wider text-[11px]">Product</div>
              <div><a href="#philosophy" className="hover:text-white transition-colors">AI Orchestration Philosophy</a></div>
              <div><a href="#features" className="hover:text-white transition-colors">EMR &amp; Electronic Forms</a></div>
              <div><a href="#workflows" className="hover:text-white transition-colors">Schedule Matrix &amp; Multi-Room</a></div>
              <div><a href="#workflows" className="hover:text-white transition-colors">Pre-Visit Readiness Scoring</a></div>
              <div><a href="#workflows" className="hover:text-white transition-colors">Email &amp; Fax OCR Parsing</a></div>
            </div>

            <div className="space-y-2">
              <div className="font-bold text-white uppercase tracking-wider text-[11px]">Administration</div>
              <div><a href="#administration" className="hover:text-white transition-colors">Configure Practice</a></div>
              <div><a href="#administration" className="hover:text-white transition-colors">Provider Roster &amp; NPI</a></div>
              <div><a href="#administration" className="hover:text-white transition-colors">User &amp; Staff Roles</a></div>
              <div><a href="#administration" className="hover:text-white transition-colors">E-Prescribe Setup</a></div>
            </div>

            <div className="space-y-2">
              <div className="font-bold text-white uppercase tracking-wider text-[11px]">Security &amp; Legal</div>
              <div><a href="#hipaa" className="hover:text-white transition-colors">HIPAA Compliance</a></div>
              <div><a href="#hipaa" className="hover:text-white transition-colors">Business Associate Agreement</a></div>
              <div><a href="#hipaa" className="hover:text-white transition-colors">Data Privacy Policy</a></div>
              <div><a href="#hipaa" className="hover:text-white transition-colors">Terms of Service</a></div>
            </div>

            <div className="space-y-2">
              <div className="font-bold text-white uppercase tracking-wider text-[11px]">Support &amp; Contact</div>
              <div><span>Priority Clinical Support: 24/7</span></div>
              <div><span>Email: support@officeintelligence.med</span></div>
              <div><span>Phone: 1 (800) 592-MED-AI</span></div>
              <div><span>Encrypted Server: US-West-2 Tier 4</span></div>
            </div>
          </div>

          <div className="pt-6 border-t border-white/10 flex flex-wrap items-center justify-between text-[11px] text-[#5B6B60]/80">
            <p>© 2026 Office Intelligence Systems Inc. All rights reserved. HIPAA Certified.</p>
            <p>Engineered for Outpatient Medical Clinics, Surgical Pavilions &amp; Multi-Specialty Practices.</p>
          </div>

        </div>
      </footer>

    </div>
  );
};
