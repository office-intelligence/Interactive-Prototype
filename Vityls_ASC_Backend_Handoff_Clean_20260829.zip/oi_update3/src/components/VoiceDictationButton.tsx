import React, { useEffect, useRef, useState } from 'react';
import { Mic, MicOff, AlertCircle } from 'lucide-react';

interface VoiceDictationButtonProps {
  onTranscript: (text: string) => void;
  label?: string;
  className?: string;
}

// Thin wrapper over the browser's Web Speech API (SpeechRecognition) for
// voice-activated dictation/form-filling. Degrades gracefully with an inline
// notice in browsers that don't support it (e.g. Firefox) rather than failing
// silently — dictation is optional, never required, everywhere it's used.
export const VoiceDictationButton: React.FC<VoiceDictationButtonProps> = ({
  onTranscript,
  label = 'Dictate',
  className = '',
}) => {
  const [isListening, setIsListening] = useState(false);
  const [isSupported, setIsSupported] = useState(true);
  const [showUnsupportedNote, setShowUnsupportedNote] = useState(false);
  const recognitionRef = useRef<any>(null);

  useEffect(() => {
    const SpeechRecognitionCtor =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognitionCtor) {
      setIsSupported(false);
      return;
    }
    const recognition = new SpeechRecognitionCtor();
    recognition.continuous = true;
    recognition.interimResults = false;
    recognition.lang = 'en-US';

    recognition.onresult = (event: any) => {
      let finalText = '';
      for (let i = event.resultIndex; i < event.results.length; i++) {
        if (event.results[i].isFinal) {
          finalText += event.results[i][0].transcript;
        }
      }
      if (finalText.trim()) onTranscript(finalText.trim());
    };
    recognition.onerror = () => setIsListening(false);
    recognition.onend = () => setIsListening(false);

    recognitionRef.current = recognition;
    return () => {
      try { recognition.stop(); } catch { /* no-op */ }
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const toggleListening = () => {
    if (!isSupported) {
      setShowUnsupportedNote(true);
      setTimeout(() => setShowUnsupportedNote(false), 3500);
      return;
    }
    const recognition = recognitionRef.current;
    if (!recognition) return;
    if (isListening) {
      recognition.stop();
      setIsListening(false);
    } else {
      try {
        recognition.start();
        setIsListening(true);
      } catch {
        setIsListening(false);
      }
    }
  };

  return (
    <div className="relative inline-block">
      <button
        type="button"
        onClick={toggleListening}
        className={`px-2.5 py-1 rounded-lg text-[10.5px] font-bold flex items-center gap-1.5 transition-all cursor-pointer border ${
          isListening
            ? 'bg-rose-600 hover:bg-rose-700 text-white border-rose-700 animate-pulse'
            : 'bg-[#E7F1F3] hover:bg-[#DCEEF1] text-[#1D4E5A] border-[#3E8FA6]/50'
        } ${className}`}
        title={isSupported ? 'Voice-activated dictation' : 'Voice dictation is not supported in this browser'}
      >
        {isListening ? <MicOff className="w-3 h-3" /> : <Mic className="w-3 h-3" />}
        <span>{isListening ? 'Listening… (tap to stop)' : label}</span>
      </button>

      {showUnsupportedNote && (
        <div className="absolute left-0 top-full mt-1.5 w-56 bg-stone-900 text-white text-[10.5px] font-medium rounded-lg p-2 shadow-lg z-50 flex items-start gap-1.5 animate-in fade-in duration-150">
          <AlertCircle className="w-3.5 h-3.5 text-amber-400 shrink-0 mt-0.5" />
          <span>Voice dictation isn't supported in this browser. Try Chrome or Edge, or type directly.</span>
        </div>
      )}
    </div>
  );
};
