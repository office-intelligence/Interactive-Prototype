import React, { useEffect, useMemo, useState } from 'react';
import {
  X, Sparkles, ShieldCheck, CheckCircle2, AlertTriangle, Clock3, FileText,
  ClipboardList, Syringe, Stethoscope, UserCheck, Activity, Home, Printer,
  ChevronRight, ExternalLink, LockKeyhole, CircleDot, ClipboardCheck, FileCheck2,
} from 'lucide-react';
import type { PatientCase, EncounterJourneyStatus } from '../types';
import {
  listCurrentPracticeForms, listPdfTemplates, listEncounterDocuments, createLocalBlobUrl,
  type LocalFormTemplate, type LocalPdfTemplate, type LocalEncounterDocument
} from '../utils/localFormStudioDb';
import { listLocalFormResponses } from '../utils/localFormResponseStore';
import { loadStoredPdfDoc, base64ToUint8 } from '../utils/pdfFormEngine';
import type { ClinicalWorkflowRole } from './ClinicalWorkflowPage';

type CaseStatus = 'complete' | 'attention' | 'blocked' | 'pending';
type CaseSection = 'journey' | 'audit';

interface CaseRecordCommandCenterProps {
  patient: PatientCase;
  onClose: () => void;
  onOpenWorkflow: (role: ClinicalWorkflowRole) => void;
  onAdvanceGate?: (toStatus: EncounterJourneyStatus, reason?: string, unresolvedItems?: string[]) => void;
  activePracticeId?: string;
}

interface JourneyStep {
  id: string;
  title: string;
  owner: string;
  status: CaseStatus;
  summary: string;
  documents: string[];
  role?: ClinicalWorkflowRole;
}

const statusMeta: Record<CaseStatus, { label: string; className: string }> = {
  complete: { label: 'Complete', className: 'bg-emerald-100 text-emerald-800 border-emerald-200' },
  attention: { label: 'Needs Review', className: 'bg-amber-100 text-amber-800 border-amber-200' },
  blocked: { label: 'Blocked', className: 'bg-rose-100 text-rose-800 border-rose-200' },
  pending: { label: 'Pending', className: 'bg-stone-100 text-stone-700 border-stone-200' },
};

const StatusBadge: React.FC<{ status: CaseStatus }> = ({ status }) => {
  const meta = statusMeta[status];
  return <span className={`inline-flex items-center px-2.5 py-1 rounded-full border text-[10px] font-black uppercase tracking-wide ${meta.className}`}>{meta.label}</span>;
};

function deriveSteps(patient: PatientCase): JourneyStep[] {
  const portalComplete = patient.checkInStatus === 'PORTAL_COMPLETE' || patient.checkInStatus === 'OFFICE_VERIFIED';
  const officeVerified = patient.checkInStatus === 'OFFICE_VERIFIED';
  const journey = patient.encounterWorkflow?.status;
  const hasCriticalLab = patient.labs.some((l) => l.status === 'critical');
  const labsPending = patient.labs.some((l) => l.status === 'pending');
  const inClinicalFlow = ['PRE_OP', 'IN_OR', 'PACU_RECOVERY', 'DISCHARGED'].includes(patient.stage);
  const inOrOrLater = ['IN_OR', 'PACU_RECOVERY', 'DISCHARGED'].includes(patient.stage);
  const pacuOrLater = ['PACU_RECOVERY', 'DISCHARGED'].includes(patient.stage);
  const discharged = patient.stage === 'DISCHARGED';

  return [
    {
      id: 'prearrival', title: '1. Pre-arrival Intake', owner: 'Patient + Front Office',
      status: portalComplete ? 'complete' : 'attention',
      summary: portalComplete ? 'Patient intake packet received; identity and history available for verification.' : 'Patient intake packet is incomplete or has not been confirmed.',
      documents: ['Registration / demographics', 'Medical history', 'Anesthesia questionnaire', 'Privacy / financial forms', 'Patient signatures'],
    },
    {
      id: 'checkin', title: '2. Arrival & Office Check-in', owner: 'Front Office',
      status: officeVerified || ['READY_FOR_PREOP','PREOP_NURSING','READY_FOR_ANESTHESIA','ANESTHESIA_EVALUATION','READY_FOR_OR','IN_OR','PACU','READY_FOR_DISCHARGE','DISCHARGED','RECORD_COMPLETION','CASE_COMPLETE'].includes(journey || '') ? 'complete' : patient.arrivalStatus === 'ARRIVED' || patient.arrivalStatus === 'CHECKED_IN' ? 'attention' : 'pending',
      summary: officeVerified ? 'Identity, intake packet, contact information and required front-office items verified.' : 'Verify patient identity and resolve missing intake items before clinical handoff.',
      documents: ['Photo ID / insurance', 'Intake verification', 'Responsible adult / ride', 'Arrival time'],
    },
    {
      id: 'nursing', title: '3. Pre-op Nursing', owner: 'Nursing', role: 'Nursing',
      status: hasCriticalLab ? 'blocked' : ['READY_FOR_ANESTHESIA','ANESTHESIA_EVALUATION','READY_FOR_OR','IN_OR','PACU','READY_FOR_DISCHARGE','DISCHARGED','RECORD_COMPLETION','CASE_COMPLETE'].includes(journey || '') ? 'complete' : journey === 'PREOP_NURSING' ? 'attention' : inClinicalFlow ? (labsPending ? 'attention' : 'complete') : 'pending',
      summary: hasCriticalLab ? 'Critical result requires documented clinical review before proceeding.' : inClinicalFlow ? 'Pre-op nursing packet is active; Nightingale should verify required clinical elements and signatures.' : 'Begins after front-office handoff.',
      documents: ['Pre-op assessment', 'Allergies & medications', 'NPO / ride confirmation', 'Consents', 'Standing orders', 'Surgical checklist'],
    },
    {
      id: 'anesthesia', title: '4. Anesthesia Readiness', owner: 'Anesthesiologist', role: 'Anesthesia',
      status: hasCriticalLab ? 'blocked' : inOrOrLater ? 'complete' : inClinicalFlow ? 'attention' : 'pending',
      summary: inOrOrLater ? 'Anesthesia pre-op review is expected complete for this stage.' : 'Review medical history, questionnaire, clearance, labs and anesthesia consent.',
      documents: ['Anesthesia questionnaire', 'Pre-op evaluation', 'Anesthesia consent', 'Anesthesia record'],
    },
    {
      id: 'surgeon', title: '5. Surgeon / Procedure', owner: 'Surgeon', role: 'Surgeons',
      status: inOrOrLater ? 'complete' : inClinicalFlow ? 'attention' : 'pending',
      summary: inOrOrLater ? 'Procedure-stage documentation is active; operative report must be finalized and authenticated.' : 'Surgeon must review clearance, reports and consents before procedure.',
      documents: ['H&P / medical history', 'Surgical consent', 'Standing orders', 'Brief operative note', 'Detailed operative report'],
    },
    {
      id: 'pacu', title: '6. PACU & Discharge', owner: 'PACU Nurse + Qualified Discharging Clinician',
      status: discharged ? 'complete' : pacuOrLater ? 'attention' : 'pending',
      summary: discharged ? 'Recovery and discharge documentation expected finalized.' : pacuOrLater ? 'Complete recovery assessments, objective discharge criteria, instructions and authentication.' : 'Opens after transfer to recovery.',
      documents: ['PACU record', 'Discharge criteria / score', 'Post-op instructions', 'Responsible adult acknowledgment', 'Discharge authorization'],
    },
    {
      id: 'final', title: '7. Final Case Record', owner: 'Nightingale + Administrator',
      status: discharged && officeVerified && !hasCriticalLab ? 'attention' : 'pending',
      summary: 'Nightingale reconciles the encounter, identifies missing signatures/documents, creates the case summary, and prepares the audit packet for human finalization.',
      documents: ['Encounter summary', 'Document index', 'Signature / authentication index', 'Exception log', 'Final PDF packet'],
    },
  ];
}

export const CaseRecordCommandCenter: React.FC<CaseRecordCommandCenterProps> = ({ patient, onClose, onOpenWorkflow, onAdvanceGate, activePracticeId }) => {
  const [practiceForms, setPracticeForms] = useState<LocalFormTemplate[]>([]);
  const [pdfTemplates,setPdfTemplates]=useState<LocalPdfTemplate[]>([]);
  const [encounterDocs,setEncounterDocs]=useState<LocalEncounterDocument[]>([]);
  const [responseTick,setResponseTick]=useState(0);
  useEffect(() => {
    if (!activePracticeId) { setPracticeForms([]); setPdfTemplates([]); setEncounterDocs([]); return; }
    Promise.all([
      listCurrentPracticeForms(activePracticeId),
      listPdfTemplates(activePracticeId),
      listEncounterDocuments(activePracticeId,patient.id),
    ]).then(([forms,pdfs,docs])=>{
      setPracticeForms(forms);
      setPdfTemplates(pdfs.filter(p=>p.status==='Active'));
      setEncounterDocs(docs);
    }).catch(()=>{setPracticeForms([]);setPdfTemplates([]);setEncounterDocs([]);});
  }, [patient.id, activePracticeId]);
  useEffect(()=>{
    const h=()=>setResponseTick(x=>x+1);
    window.addEventListener('oi-form-response-updated',h);
    return()=>window.removeEventListener('oi-form-response-updated',h);
  },[]);
  const [section, setSection] = useState<CaseSection>('journey');
  const [advanceStepId, setAdvanceStepId] = useState<string | null>(null);
  const [advanceReason, setAdvanceReason] = useState('');
  const steps = useMemo(() => {
    const base = deriveSteps(patient);
    if (patient.id !== 'local-empty-patient') return base;
    const byStage = (stages: string[]) => [
      ...practiceForms.filter(f => stages.includes(f.collectionStage)).map(f => f.title),
      ...pdfTemplates.filter(f => stages.includes(f.collectionStage)).map(f => `${f.title} (PDF)`),
    ];
    return base.map(step => {
      if (step.id === 'prearrival') return { ...step, documents: byStage(['Home / Patient Portal']) };
      if (step.id === 'checkin') return { ...step, documents: byStage(['Front Desk']) };
      if (step.id === 'nursing') return { ...step, documents: byStage(['Nursing']) };
      if (step.id === 'anesthesia') return { ...step, documents: byStage(['Anesthesia']) };
      if (step.id === 'surgeon') return { ...step, documents: byStage(['Surgeon','OR Team']) };
      if (step.id === 'pacu') return { ...step, documents: byStage(['PACU']) };
      return { ...step, documents: [] };
    });
  }, [patient, practiceForms, pdfTemplates]);
  const complete = steps.filter((s) => s.status === 'complete').length;
  const blocked = steps.filter((s) => s.status === 'blocked');
  const attention = steps.filter((s) => s.status === 'attention');
  const percent = Math.round((complete / steps.length) * 100);
  const criticalLabs = patient.labs.filter((l) => l.status === 'critical');
  const pendingLabs = patient.labs.filter((l) => l.status === 'pending');

  const currentStatus = patient.encounterWorkflow?.status || 'ARRIVED';
  const activeStepId = ['ARRIVED','CHECKING_IN'].includes(currentStatus) ? 'checkin'
    : ['READY_FOR_PREOP','PREOP_NURSING'].includes(currentStatus) ? 'nursing'
    : ['READY_FOR_ANESTHESIA','ANESTHESIA_EVALUATION'].includes(currentStatus) ? 'anesthesia'
    : ['READY_FOR_OR','IN_OR'].includes(currentStatus) ? 'surgeon'
    : ['PACU','READY_FOR_DISCHARGE'].includes(currentStatus) ? 'pacu'
    : ['DISCHARGED','RECORD_COMPLETION'].includes(currentStatus) ? 'final'
    : null;
  const nextStatusByStep: Partial<Record<string, EncounterJourneyStatus>> = {
    checkin: 'READY_FOR_PREOP', nursing: 'READY_FOR_ANESTHESIA', anesthesia: 'READY_FOR_OR',
    surgeon: 'PACU', pacu: 'DISCHARGED', final: 'CASE_COMPLETE'
  };

  const aiFindings = [
    ...blocked.map((s) => ({ severity: 'Critical', text: `${s.title}: ${s.summary}` })),
    ...(!patient.checkInStatus || patient.checkInStatus !== 'OFFICE_VERIFIED' ? [{ severity: 'Action', text: 'Front-office verification is not finalized. Confirm identity and all patient-submitted information before clinical handoff.' }] : []),
    ...(pendingLabs.length ? [{ severity: 'Action', text: `${pendingLabs.length} laboratory item${pendingLabs.length > 1 ? 's are' : ' is'} still pending. Assign ownership and document provider review when received.` }] : []),
    ...(!blocked.length && !attention.length ? [{ severity: 'Ready', text: 'No unresolved workflow exceptions are visible in this prototype record.' }] : []),
  ];

  const formResponses = activePracticeId ? listLocalFormResponses(activePracticeId,patient.id) : [];
  const responseByForm = new Map(formResponses.map(r=>[r.formId,r]));

  const auditDocs = [
    ...practiceForms.map((form)=>({
      id:`html-${form.id}`,
      title:form.title,
      owner:form.collectionStage,
      status:(responseByForm.has(form.id)?'complete':'pending') as CaseStatus,
      source:`HTML Form Studio · ${form.version}`,
      blob:undefined as Blob|undefined,
      html:responseByForm.get(form.id)?.renderedHtml,
    })),
    ...pdfTemplates.flatMap(pdf=>{
      const stored=loadStoredPdfDoc(patient.id,`practice-pdf:${pdf.id}:${pdf.version}`);
      if(!stored) return [];
      const blob = stored.status==='LOCKED' && stored.lockedPdfBase64
        ? new Blob([base64ToUint8(stored.lockedPdfBase64)],{type:'application/pdf'})
        : undefined;
      return [{
        id:`pdf-${pdf.id}`,
        title:pdf.title,
        owner:pdf.collectionStage,
        status:(stored.status==='LOCKED'?'complete':'pending') as CaseStatus,
        source:`Interactive PDF · ${pdf.version}${stored.status==='DRAFT'?' · Draft':''}`,
        blob,
      }];
    }),
    ...encounterDocs.map(doc=>({
      id:`enc-${doc.id}`,
      title:doc.title,
      owner:'Encounter Record',
      status:'complete' as CaseStatus,
      source:`${doc.sourceType.replaceAll('_',' ')} · ${doc.aiStatus}`,
      blob:doc.blob,
    })),
  ];

  return (
    <div className="fixed inset-0 z-[100500] bg-stone-100 flex flex-col w-screen h-screen overflow-hidden">
      <header className="bg-slate-950 text-white border-b border-slate-800 px-4 sm:px-6 py-3 flex items-center justify-between gap-4 shadow-lg">
        <div className="min-w-0">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-emerald-400" />
            <h1 className="text-sm sm:text-base font-black truncate">Surgical Case Record · {patient.name}</h1>
          </div>
          <p className="text-[11px] text-slate-400 mt-0.5 truncate">DOS workflow, clinical verification, signatures, source documents and audit readiness · MRN {patient.patientId}</p>
        </div>
        <button onClick={onClose} className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-xs font-bold flex items-center gap-2 cursor-pointer shrink-0">
          <X className="w-4 h-4" /> Close
        </button>
      </header>

      <div className="flex-1 overflow-y-auto p-3 sm:p-5">
        <div className="max-w-7xl mx-auto space-y-4">
          <section className="bg-white rounded-2xl border border-stone-200 shadow-sm p-4">
            <div className="grid grid-cols-1 lg:grid-cols-[1.4fr_1fr] gap-4">
              <div>
                <div className="flex flex-wrap items-center gap-2 mb-2">
                  <span className="text-xs font-black text-stone-900">{patient.scheduledTime}</span>
                  <span className="text-xs text-stone-500">{patient.procedure}</span>
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-stone-100 border border-stone-200 font-bold text-stone-600">{patient.stage.replaceAll('_', ' ')}</span>
                </div>
                <div className="flex items-end justify-between gap-3 mb-1.5">
                  <div><div className="text-[10px] uppercase tracking-wider font-black text-stone-400">Case record readiness</div><div className="text-2xl font-black text-stone-900">{percent}%</div></div>
                  <div className="text-right text-[11px] font-bold text-stone-500">{complete} of {steps.length} workflow stages complete</div>
                </div>
                <div className="h-2.5 bg-stone-100 rounded-full overflow-hidden"><div className="h-full bg-emerald-600 rounded-full transition-all" style={{ width: `${percent}%` }} /></div>
              </div>
              <div className="grid grid-cols-3 gap-2">
                <div className="rounded-xl border border-emerald-200 bg-emerald-50 p-3"><CheckCircle2 className="w-4 h-4 text-emerald-700 mb-1"/><div className="text-xl font-black text-emerald-900">{complete}</div><div className="text-[10px] font-bold text-emerald-700">Complete</div></div>
                <div className="rounded-xl border border-amber-200 bg-amber-50 p-3"><Clock3 className="w-4 h-4 text-amber-700 mb-1"/><div className="text-xl font-black text-amber-900">{attention.length}</div><div className="text-[10px] font-bold text-amber-700">Needs review</div></div>
                <div className="rounded-xl border border-rose-200 bg-rose-50 p-3"><AlertTriangle className="w-4 h-4 text-rose-700 mb-1"/><div className="text-xl font-black text-rose-900">{blocked.length}</div><div className="text-[10px] font-bold text-rose-700">Blocked</div></div>
              </div>
            </div>
          </section>

          {patient.encounterWorkflow && (
            <section className="bg-white rounded-2xl border border-cyan-200 shadow-sm p-4">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div>
                  <div className="text-[10px] uppercase tracking-wider font-black text-cyan-700">Current encounter ownership</div>
                  <div className="text-lg font-black text-stone-900 mt-0.5">{patient.encounterWorkflow.currentOwner} · {patient.encounterWorkflow.status.replaceAll('_', ' ')}</div>
                  <p className="text-xs text-stone-500 mt-1">{patient.encounterWorkflow.lastHandoffNote || 'No handoff note recorded yet.'}</p>
                </div>
                <div className="flex flex-wrap gap-2 text-[10px] font-bold">
                  {patient.encounterWorkflow.frontDeskCompletedAt && <span className="px-2 py-1 rounded-full bg-emerald-100 text-emerald-800 border border-emerald-200">Front Desk complete</span>}
                  {patient.encounterWorkflow.nursingNotifiedAt && <span className="px-2 py-1 rounded-full bg-cyan-100 text-cyan-800 border border-cyan-200">Nursing notified</span>}
                  {patient.encounterWorkflow.nursingAcceptedAt && <span className="px-2 py-1 rounded-full bg-indigo-100 text-indigo-800 border border-indigo-200">Nursing accepted</span>}
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mt-3">
                <div className="rounded-xl bg-rose-50 border border-rose-200 p-3"><div className="text-[10px] uppercase font-black text-rose-700">Allergies carried forward</div><div className="text-xs font-bold text-stone-900 mt-1">{patient.allergies.length ? patient.allergies.join(', ') : 'No allergy data documented'}</div></div>
                <div className="rounded-xl bg-indigo-50 border border-indigo-200 p-3"><div className="text-[10px] uppercase font-black text-indigo-700">Medications carried forward</div><div className="text-xs font-bold text-stone-900 mt-1">{patient.medicalProfile?.medications?.length ? patient.medicalProfile.medications.map(m => `${m.name} ${m.dose} ${m.freq}`.trim()).join(' · ') : 'No active medications documented / verify status'}</div></div>
              </div>
            </section>
          )}

          {!!patient.encounterWorkflow?.exceptions?.length && (
            <section className="rounded-2xl border border-amber-200 bg-amber-50 p-4">
              <div className="flex items-center gap-2 text-amber-950 font-black text-sm"><AlertTriangle className="w-4 h-4"/>Open / Accepted Exceptions</div>
              <div className="mt-2 grid gap-2">
                {patient.encounterWorkflow.exceptions.map(ex => <div key={ex.id} className="rounded-xl bg-white border border-amber-200 p-3 text-xs text-stone-700"><div className="font-black text-amber-900">{ex.fromGate.replaceAll('_',' ')} → {ex.toGate.replaceAll('_',' ')}</div><div className="mt-1">{ex.reason}</div>{ex.unresolvedItems?.length ? <div className="mt-1 text-[10.5px] text-stone-500">Open items: {ex.unresolvedItems.join(' · ')}</div> : null}<div className="mt-1 text-[10px] text-stone-400">{ex.advancedBy} · {new Date(ex.advancedAt).toLocaleString()}</div></div>)}
              </div>
            </section>
          )}

          <section className="rounded-2xl border border-violet-200 bg-gradient-to-r from-violet-50 to-white shadow-sm p-4">
            <div className="flex items-start gap-3">
              <div className="p-2 rounded-xl bg-violet-100 text-violet-700"><Sparkles className="w-5 h-5" /></div>
              <div className="flex-1 min-w-0">
                <div className="flex flex-wrap items-center justify-between gap-2"><h2 className="text-sm font-black text-stone-900">Nightingale Case Verification</h2><span className="text-[10px] font-bold text-violet-700 bg-white border border-violet-200 rounded-full px-2 py-1">AI PRE-CHECK · HUMAN APPROVAL REQUIRED</span></div>
                <p className="text-xs text-stone-600 mt-1">Nightingale reconciles the workflow against the case record, highlights missing or conflicting items, and proposes the next action. It does not silently complete, sign, or clinically approve a record.</p>
                <div className="mt-3 grid gap-2">
                  {aiFindings.slice(0,4).map((f, i) => <div key={i} className="flex items-start gap-2 text-xs bg-white/80 rounded-xl border border-violet-100 px-3 py-2"><CircleDot className={`w-3.5 h-3.5 mt-0.5 shrink-0 ${f.severity === 'Critical' ? 'text-rose-600' : f.severity === 'Ready' ? 'text-emerald-600' : 'text-amber-600'}`} /><span><strong>{f.severity}:</strong> {f.text}</span></div>)}
                  {criticalLabs.map((l) => <div key={l.name} className="flex items-start gap-2 text-xs bg-rose-50 rounded-xl border border-rose-200 px-3 py-2"><AlertTriangle className="w-3.5 h-3.5 mt-0.5 text-rose-700"/><span><strong>Critical lab:</strong> {l.name} {l.value}. Require clinician acknowledgment, date/time and disposition before proceeding.</span></div>)}
                </div>
              </div>
            </div>
          </section>

          <nav className="flex gap-2 bg-white border border-stone-200 rounded-2xl p-1.5 shadow-sm w-fit">
            <button onClick={() => setSection('journey')} className={`px-3 py-2 rounded-xl text-xs font-black flex items-center gap-2 cursor-pointer ${section === 'journey' ? 'bg-slate-900 text-white' : 'text-stone-600 hover:bg-stone-50'}`}><Activity className="w-4 h-4"/>Day-of-Surgery Journey</button>
            <button onClick={() => setSection('audit')} className={`px-3 py-2 rounded-xl text-xs font-black flex items-center gap-2 cursor-pointer ${section === 'audit' ? 'bg-slate-900 text-white' : 'text-stone-600 hover:bg-stone-50'}`}><ClipboardCheck className="w-4 h-4"/>Audit Case Record</button>
          </nav>

          {section === 'journey' ? (
            <div className="grid gap-3">
              {steps.map((step) => (
                <section key={step.id} className="bg-white border border-stone-200 rounded-2xl shadow-sm p-4">
                  <div className="flex flex-col md:flex-row md:items-start gap-3">
                    <div className="flex-1 min-w-0">
                      <div className="flex flex-wrap items-center gap-2"><h3 className="text-sm font-black text-stone-900">{step.title}</h3><StatusBadge status={step.status}/><span className="text-[10px] font-bold text-stone-500">Owner: {step.owner}</span></div>
                      <p className="text-xs text-stone-600 mt-1.5">{step.summary}</p>
                      <div className="mt-3 flex flex-wrap gap-1.5">{step.documents.map((doc) => <span key={doc} className="text-[10px] font-semibold text-stone-600 bg-stone-50 border border-stone-200 rounded-lg px-2 py-1 flex items-center gap-1"><FileText className="w-3 h-3"/>{doc}</span>)}</div>
                    </div>
                    <div className="flex flex-col gap-2 shrink-0">
                      {step.role && <button onClick={() => onOpenWorkflow(step.role!)} className="px-3.5 py-2.5 rounded-xl bg-[#1F6E52] hover:bg-[#17553F] text-white text-xs font-black flex items-center gap-2 cursor-pointer">Open {step.role} Workflow <ChevronRight className="w-4 h-4"/></button>}
                      {step.id === activeStepId && nextStatusByStep[step.id] && onAdvanceGate && (
                        <button onClick={() => { setAdvanceStepId(step.id); setAdvanceReason(''); }} className="px-3.5 py-2.5 rounded-xl bg-slate-900 hover:bg-black text-white text-xs font-black flex items-center justify-center gap-2 cursor-pointer">
                          Advance to Next Gate <ChevronRight className="w-4 h-4"/>
                        </button>
                      )}
                    </div>
                  </div>
                </section>
              ))}
            </div>
          ) : (
            <div className="space-y-4">
              <section className="bg-white rounded-2xl border border-stone-200 shadow-sm p-4">
                <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-3">
                  <div><h2 className="text-sm font-black text-stone-900">Encounter Case Summary</h2><p className="text-xs text-stone-500 mt-1">One index for the date of service, source evidence, authentication status, and final printable record.</p></div>
                  <button onClick={() => window.print()} className="px-3.5 py-2.5 rounded-xl bg-slate-900 hover:bg-black text-white text-xs font-black flex items-center gap-2 cursor-pointer"><Printer className="w-4 h-4"/>Print / Save Summary PDF</button>
                </div>
                <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-2 mt-4 text-xs">
                  <div className="rounded-xl bg-stone-50 border border-stone-200 p-3"><div className="text-[10px] uppercase font-black text-stone-400">Patient</div><div className="font-black mt-1">{patient.name}</div><div className="text-stone-500">MRN {patient.patientId}</div></div>
                  <div className="rounded-xl bg-stone-50 border border-stone-200 p-3"><div className="text-[10px] uppercase font-black text-stone-400">Procedure</div><div className="font-black mt-1">{patient.procedure}</div><div className="text-stone-500">{patient.room} · {patient.scheduledTime}</div></div>
                  <div className="rounded-xl bg-stone-50 border border-stone-200 p-3"><div className="text-[10px] uppercase font-black text-stone-400">Surgeon</div><div className="font-black mt-1">{patient.surgeon}</div><div className="text-stone-500">Attending / proceduralist</div></div>
                  <div className="rounded-xl bg-stone-50 border border-stone-200 p-3"><div className="text-[10px] uppercase font-black text-stone-400">Anesthesia</div><div className="font-black mt-1">{patient.anesthesiologist || 'Not assigned'}</div><div className="text-stone-500">Authentication indexed separately</div></div>
                </div>
              </section>

              <section className="bg-white rounded-2xl border border-stone-200 shadow-sm overflow-hidden">
                <div className="px-4 py-3 border-b border-stone-200 flex items-center justify-between"><div><h3 className="text-sm font-black text-stone-900">Audit Document Index</h3><p className="text-[11px] text-stone-500">Prototype index. Production should link every row to the immutable source plus its finalized PDF rendition.</p></div><FileCheck2 className="w-5 h-5 text-emerald-700"/></div>
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-stone-50 text-[10px] uppercase tracking-wide text-stone-500"><tr><th className="px-4 py-2.5">Document</th><th className="px-4 py-2.5">Owner</th><th className="px-4 py-2.5">Source</th><th className="px-4 py-2.5">Status</th><th className="px-4 py-2.5">Record</th></tr></thead>
                    <tbody className="divide-y divide-stone-100">
                      {auditDocs.map((doc) => <tr key={doc.id} className="hover:bg-stone-50"><td className="px-4 py-3 font-bold text-stone-800">{doc.title}</td><td className="px-4 py-3 text-stone-600">{doc.owner}</td><td className="px-4 py-3 text-stone-600">{doc.source}</td><td className="px-4 py-3"><StatusBadge status={doc.status}/></td><td className="px-4 py-3"><button onClick={()=>{
  let url:string|null=null;
  if((doc as any).blob) url=createLocalBlobUrl((doc as any).blob);
  else if((doc as any).html) url=URL.createObjectURL(new Blob([(doc as any).html],{type:'text/html'}));
  if(url) window.open(url,'_blank');
}} className="inline-flex items-center gap-1 text-[11px] font-bold text-[#1F6E52] disabled:text-stone-400" disabled={doc.status !== 'complete'} title={doc.status === 'complete' ? ((doc as any).blob?'Open preserved original PDF/source':(doc as any).html?'Open preserved completed HTML snapshot':'Completed structured form') : 'Available after record completion'}>{doc.status === 'complete' ? <ExternalLink className="w-3.5 h-3.5"/> : <LockKeyhole className="w-3.5 h-3.5"/>}{doc.status === 'complete' ? ((doc as any).blob?'Original':(doc as any).html?'Open / Print':'Completed') : 'Not final'}</button></td></tr>)}
                    </tbody>
                  </table>
                </div>
              </section>

              <section className="rounded-2xl border border-sky-200 bg-sky-50 p-4 flex items-start gap-3"><UserCheck className="w-5 h-5 text-sky-700 shrink-0"/><div><div className="text-xs font-black text-sky-900">Finalization rule</div><p className="text-xs text-sky-800 mt-1">A case should receive its final “Complete” badge only after required documents exist, required fields pass validation, all required signatures/authentications are present, source documents are linked, exceptions are resolved or explicitly accepted, and a human authorized for the facility locks the case packet.</p></div></section>
            </div>
          )}
        </div>
      </div>

      {advanceStepId && (() => {
        const step = steps.find(s => s.id === advanceStepId)!;
        const toStatus = nextStatusByStep[advanceStepId]!;
        const incomplete = step.status !== 'complete';
        return <div className="fixed inset-0 z-[100700] bg-slate-950/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-lg rounded-2xl bg-white border border-stone-200 shadow-2xl p-5 space-y-4">
            <div className="flex items-start justify-between gap-3"><div><div className="text-[10px] uppercase tracking-wider font-black text-emerald-700">Gate Handoff</div><h3 className="text-lg font-black text-stone-900 mt-1">Advance from {step.title.replace(/^\d+\.\s*/, '')}</h3><p className="text-xs text-stone-500 mt-1">Next status: {toStatus.replaceAll('_',' ')}</p></div><button onClick={() => setAdvanceStepId(null)} className="p-2 rounded-xl hover:bg-stone-100 cursor-pointer"><X className="w-4 h-4"/></button></div>
            {incomplete ? <div className="rounded-xl border border-amber-200 bg-amber-50 p-3"><div className="flex gap-2 text-xs font-bold text-amber-900"><AlertTriangle className="w-4 h-4 shrink-0"/>This gate is not complete. Advancement is allowed, but the exception will remain visible and accountable.</div><textarea value={advanceReason} onChange={e => setAdvanceReason(e.target.value)} rows={3} placeholder="Required: explain why the patient is proceeding and who will resolve the open items." className="mt-3 w-full rounded-xl border border-amber-300 bg-white px-3 py-2 text-xs outline-none focus:ring-2 focus:ring-amber-300"/></div> : <div className="rounded-xl border border-emerald-200 bg-emerald-50 p-3 text-xs font-semibold text-emerald-900">This gate is currently marked complete. The handoff will be recorded in the encounter timeline.</div>}
            <div className="flex justify-end gap-2"><button onClick={() => setAdvanceStepId(null)} className="px-3 py-2 rounded-xl border border-stone-200 text-xs font-bold cursor-pointer">Cancel</button><button disabled={incomplete && !advanceReason.trim()} onClick={() => { onAdvanceGate(toStatus, incomplete ? advanceReason.trim() : undefined, incomplete ? step.documents : []); setAdvanceStepId(null); }} className="px-4 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-800 disabled:bg-stone-300 text-white text-xs font-black cursor-pointer disabled:cursor-not-allowed">{incomplete ? 'Advance With Exception' : 'Complete Handoff'}</button></div>
          </div>
        </div>;
      })()}
    </div>
  );
};
