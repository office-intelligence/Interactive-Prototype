# Henry — Start Here

This is the clean Vityls ASC frontend baseline for the production backend.

## What is intentionally empty

Do not look for prototype patients or demo clinical records. They have been removed.

The following should come from the backend from this point forward:

- practices/organizations and locations
- users/providers/roles
- patients
- appointments
- encounters
- workflow/gate state
- tasks
- form assignments and responses
- signatures
- patient documents
- PDF annotations/review state
- portal records/messages
- billing/claims data
- Nightingale clinical/operational outputs

## What is intentionally retained

- complete ASC frontend/workflow
- Form Studio
- Forms & Documents
- Patient Chart UI
- Day-of-Surgery workflow
- Administration UI
- Portal UI shell
- HTML/PDF viewers
- Nightingale UI surfaces
- 27 default platform HTML templates

## First frontend adapters to replace

These files are the clearest current boundaries between the prototype and the future backend:

1. `src/utils/dateCases.ts`
   - replace with appointment/encounter queries

2. `src/utils/patientDirectory.ts`
   - replace with patient search/directory API

3. `src/utils/localFormStudioDb.ts`
   - move practice templates, PDF templates and documents to API + database/blob storage

4. `src/utils/localFormResponseStore.ts`
   - move form responses/signatures to API/database

5. `src/utils/pdfFormEngine.ts`
   - move annotation draft state to backend/document storage while keeping the viewer behavior

6. `src/utils/portalMessageStore.ts`
   - replace with communications API; later this can also integrate with Vityls Mail

## Suggested backend order

1. Organization / Location
2. User / Role / Permission / Provider
3. Patient
4. Appointment
5. Encounter
6. Encounter workflow/gates
7. FormTemplate / FormTemplateVersion
8. FormResponse / Signature
9. Document / DocumentReview / Annotation
10. Task
11. AuditEvent
12. Communication / Participant / Attachment
13. Nightingale output/event storage
14. Microsoft Graph mailbox connector later

## Storage principle

Use SQL for structured metadata and relationships.

Use secure object/blob storage for:
- uploaded PDFs
- scans/images
- completed/finalized documents
- large attachments

Do not migrate browser IndexedDB/localStorage records into production.

## Initial production data

Start production clinical tables empty.

Import only:
- approved platform configuration
- the 27 default HTML templates

For Staging, create new fictitious patients through the real API after the database is connected. That way every test exercises the actual production persistence path.
