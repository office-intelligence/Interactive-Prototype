import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { createServer as createViteServer } from 'vite';
import dotenv from 'dotenv';

dotenv.config();

const app = express();
const PORT = Number(process.env.PORT || 3000);
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

app.use(express.json({ limit: '10mb' }));

// Backend handoff health endpoint.
app.get('/api/health', (_req, res) => {
  res.json({
    status: 'ok',
    product: 'Vityls ASC',
    backend: 'handoff-shell',
    timestamp: new Date().toISOString(),
  });
});

// No prototype/fictitious AI responses are included in this handoff.
// Henry/backend team should replace these routes with authenticated services.
app.use('/api', (req, res) => {
  res.status(501).json({
    error: 'BACKEND_NOT_IMPLEMENTED',
    message: `No production handler is connected for ${req.method} ${req.path}.`,
  });
});

async function start() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, () => {
    console.log(`Vityls ASC backend-handoff shell listening on port ${PORT}`);
  });
}

start().catch((error) => {
  console.error('Failed to start Vityls ASC server shell:', error);
  process.exit(1);
});
