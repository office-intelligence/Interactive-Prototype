/*
 * Henry: database link for the office apps (Surgery.Vityls / Medical.Vityls), step 1.
 * Patients and appointments only. Everything else still lives in the browser, as before.
 *
 * How it works ("write-through cache", so no screen has to change):
 *  - When a practice page opens (?practice=...) and you are signed in (/login-test), the practice's
 *    patients and appointments are loaded from Azure SQL into the browser cache that the screens read.
 *  - Every time a screen saves a patient or an appointment (medRepo.savePatient / saveVisit), the same
 *    record is also sent to the server, which saves it in Azure SQL for YOUR practice only.
 *  - Not signed in: the page goes to the sign-in page (/login) and comes back here afterwards.
 * A small badge at the bottom right shows the practice; click it to sign out.
 */
import type { MedPatient, MedVisit } from './record';

export const dbSync: { on: boolean; practice?: string; lastError?: string; pending: number } = { on: false, pending: 0 };
const ping = () => { try { window.dispatchEvent(new Event('vityls-med-updated')); } catch { /* */ } };

function badge() {
  try {
    let el = document.getElementById('vityls-db-badge');
    if (!el) {
      el = document.createElement('div'); el.id = 'vityls-db-badge';
      el.setAttribute('style', 'position:fixed;right:12px;bottom:12px;z-index:99999;font:12px/1.3 "Segoe UI",system-ui,sans-serif;padding:6px 10px;border-radius:999px;box-shadow:0 1px 4px rgba(0,0,0,.18);cursor:pointer');
      el.setAttribute('role', 'button'); el.title = 'Sign out';
      el.addEventListener('click', () => { void signOut(); });
      document.body.appendChild(el);
    }
    const err = dbSync.lastError;
    el.style.background = err ? '#fde8e6' : dbSync.on ? '#e3f1ea' : '#eef0ef';
    el.style.color = err ? '#a1261b' : dbSync.on ? '#1f4e3d' : '#4b5a54';
    el.textContent = err ? `Database: ${err}` : dbSync.on ? `Database · practice ${dbSync.practice}${dbSync.pending ? ' · saving…' : ' · Sign out'}` : 'Not signed in';
  } catch { /* */ }
}

export async function startDbSync(): Promise<void> {
  try {
    const me = await fetch('/api/auth/me', { credentials: 'same-origin' });
    if (me.status === 401) { goToSignIn(); return; }
    if (!me.ok) throw new Error(`sign-in check failed (${me.status})`);
    const r = await fetch('/api/office/sync', { credentials: 'same-origin' });
    const d = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(d.message || `load failed (${r.status})`);
    localStorage.setItem('vityls:med:patients', JSON.stringify(d.patients || []));
    localStorage.setItem('vityls:med:visits', JSON.stringify(d.visits || []));
    localStorage.setItem('vityls:surgery:documents', JSON.stringify(d.documents || []));
    try { await mergeProvidersAndRooms(d.providers || [], d.rooms || [], d.visits || []); } catch (e) { console.warn('Vityls: providers/rooms merge failed', e); }
    dbSync.on = true; dbSync.practice = d.practice; dbSync.lastError = undefined;
    watchProviders();
    ping();
  } catch (e: any) {
    dbSync.lastError = e?.message || 'could not load';
    console.error('Vityls database load failed:', e);
  }
  badge();
}

function goToSignIn() {
  location.replace('/login?next=' + encodeURIComponent(location.pathname + location.search + location.hash));
}
async function signOut() {
  await queue.catch(() => undefined); // let any save finish first
  try { await fetch('/api/auth/logout', { method: 'POST', credentials: 'same-origin' }); } catch { /* */ }
  // Clear this practice's cached records from the browser before leaving.
  try { for (const k of ['vityls:med:patients', 'vityls:med:visits', 'vityls:surgery:documents']) localStorage.removeItem(k); } catch { /* */ }
  location.replace('/login');
}

// Saves go out one at a time, in order, so a new patient is saved before its first appointment.
let queue: Promise<void> = Promise.resolve();
function send(path: string, body: unknown) {
  if ((window as any).__vitylsReloading) return; // v11.5: page is reloading into the signed-in practice
  dbSync.pending++; badge();
  queue = queue.then(() => sendNow(path, body));
}
async function sendNow(path: string, body: unknown) {
  try {
    const r = await fetch(path, { method: 'PUT', credentials: 'same-origin', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
    const d = await r.json().catch(() => ({}));
    if (r.status === 401) { dbSync.lastError = 'signed out - sign in again to save'; setTimeout(goToSignIn, 2500); return; }
    if (!r.ok) throw new Error(d.message || `save failed (${r.status})`);
    dbSync.lastError = undefined;
  } catch (e: any) {
    dbSync.lastError = `not saved: ${e?.message || 'error'}`;
    console.error('Vityls database save failed:', path, e);
  } finally { dbSync.pending--; badge(); }
}

export function pushPatient(p: MedPatient) {
  if (!dbSync.on) return;
  const { photo, ...rest } = p as MedPatient & { photo?: unknown }; // photos stay in the browser for now
  send('/api/office/patients', rest);
}
export function pushVisit(v: MedVisit) { if (dbSync.on) send('/api/office/visits', v); }

/* ---------------- Documents tab (files in Azure storage) ---------------- */
// Runs a step in the same save queue (so the patient is saved before its first document) and returns its result.
function inQueue<T>(fn: () => Promise<T>): Promise<T> {
  dbSync.pending++; badge();
  const job = queue.then(fn);
  queue = job.then(() => undefined, () => undefined).finally(() => { dbSync.pending--; badge(); });
  return job;
}
async function jsonOrThrow(r: Response, what: string) {
  const d = await r.json().catch(() => ({}));
  if (r.status === 401) { setTimeout(goToSignIn, 2500); throw new Error('Signed out - sign in again.'); }
  if (!r.ok) throw new Error(d.message || `${what} failed (${r.status})`);
  return d;
}
/** Uploads a file for a patient; returns the server's document id. */
export function uploadDocFile(patientId: string, file: File, type: string, title: string): Promise<string> {
  return inQueue(async () => {
    const q = `patient=${encodeURIComponent(patientId)}&type=${encodeURIComponent(type)}&title=${encodeURIComponent(title)}`;
    const r = await fetch(`/api/files?${q}`, { method: 'POST', credentials: 'same-origin',
      headers: { 'Content-Type': 'application/octet-stream', 'X-File-Name': encodeURIComponent(file.name || 'file') }, body: file });
    return String((await jsonOrThrow(r, 'Upload')).id);
  });
}
/** A document record without a file; returns the server's document id. */
export function createDocRecord(patientId: string, type: string, title: string): Promise<string> {
  return inQueue(async () => {
    const r = await fetch('/api/office/documents', { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ patientId, type, title }) });
    return String((await jsonOrThrow(r, 'Saving the document')).id);
  });
}
/** Saves the chart's details for a document (title, type, summary, removed/restored). */
export function pushDoc(d: { serverId?: string; dataUrl?: string } & Record<string, unknown>) {
  if (!dbSync.on || !d.serverId) return;
  const { dataUrl, ...doc } = d;
  send(`/api/office/documents/${d.serverId}`, { doc });
}

/* ---------------- v11.5: providers added in the app -> dbo.Providers ---------------- */
// The full provider record (credentials, onboarding, PIN) is saved by the record store; this keeps a copy of the basic
// fields (name, credentials, role, specialty, NPI, contact, color, active) in dbo.Providers for the real integrations.
let provTimer: any = 0; let provLast = '';
function watchProviders() {
  window.addEventListener('vityls-providers-updated', () => { clearTimeout(provTimer); provTimer = setTimeout(() => { void pushProviders(); }, 800); });
}
async function pushProviders() {
  if (!dbSync.on) return;
  try {
    const pm: any = await import('../v7/providers');
    const list = pm.getProviders().filter((p: any) => !String(p.id).startsWith('db-prov-')).map((p: any) => ({
      id: p.id, firstName: p.firstName, lastName: p.lastName, degree: p.degree, role: p.role, specialty: p.specialty,
      npi: p.npi, email: p.email, phone: p.phone, color: p.color, active: p.active !== false && !p.deactivatedAt }));
    const body = JSON.stringify(list); if (body === provLast) return; provLast = body;
    send('/api/office/providers', { providers: list });
  } catch (e) { console.warn('Vityls: providers not sent', e); }
}

/* ---------------- Providers / surgeons and rooms from the database (e.g. imported from iMars) ---------------- */
// They join the practice's provider list (with their iMars color) and become schedule columns.
// Loaded on demand (dynamic import) so this file stays independent of the scheduler modules.
type DbProvider = { showOnSchedule?: boolean; id: string; firstName: string; lastName: string; degree: string; role: string; specialty: string; npi: string; email: string; phone: string; color: string };
type DbRoom = { id: string; name: string; type: string; color: string };
async function mergeProvidersAndRooms(provs: DbProvider[], rooms: DbRoom[], visits: { provider?: string }[]) {
  if (!provs.length && !rooms.length) return;
  const pm: any = await import('../v7/providers');
  const keepProv = pm.getProviders().filter((p: any) => !String(p.id).startsWith('db-prov-'));
  const now = new Date().toISOString();
  const fromDb = provs.map((p, i) => ({ ...p, color: p.color || pm.PROVIDER_COLORS[i % pm.PROVIDER_COLORS.length], pinHash: '', active: true,
    app: { id: `APP-${p.id}`, status: 'Privileges approved', createdAt: now, history: [] }, onboarding: {} }));
  pm.saveProviders([...keepProv, ...fromDb]);
  const name = (p: DbProvider) => `${p.firstName} ${p.lastName}`.trim() + (p.degree ? `, ${p.degree}` : '');
  const sd: any = await import('../surgery/v09/schedData');
  const keepRes = sd.resources().filter((r: any) => !String(r.id).startsWith('r-db-'));
  const addRes = [
    ...fromDb.map(p => ({ id: `r-${p.id}`, kind: 'person', name: name(p), role: p.role, schedulable: true })),
    ...rooms.map(r => ({ id: `r-${r.id}`, kind: 'room', name: r.name, role: 'Room', schedulable: true })),
  ];
  localStorage.setItem('vityls:surgery:sched-resources', JSON.stringify([...keepRes, ...addRes]));
  // Visible columns: like the iMars appointment book, only providers marked "Scheduler: Yes" (plus anyone with
  // appointments) are shown; the others stay available under "Columns".
  const norm = (x: string) => String(x || '').toLowerCase().replace(/^dr\.?\s+/, '').replace(/,.*$/, '').trim();
  const busy = new Set(visits.map(v => norm(v.provider || '')).filter(Boolean));
  const withVisits = fromDb.filter(p => p.showOnSchedule || busy.has(norm(name(p)))).map(name);
  const roles = ['Surgeon', 'Physician', 'Nurse practitioner', 'Physician assistant'];
  try {
    const raw = localStorage.getItem('vityls:surgery:schedule-columns');
    const cols: string[] = raw ? JSON.parse(raw)
      : keepRes.filter((r: any) => r.kind === 'person' && roles.includes(r.role)).map((r: any) => r.name);
    const dbNames = new Set(fromDb.map(name));
    const next = [...cols.filter(n => !dbNames.has(n) || withVisits.includes(n)), ...withVisits.filter(n => !cols.includes(n))];
    localStorage.setItem('vityls:surgery:schedule-columns', JSON.stringify(next));
  } catch { /* */ }
}
