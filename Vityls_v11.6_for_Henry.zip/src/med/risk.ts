/*
 * Surgical risk AWARENESS (MED v0.1). Lists factors that may raise surgical risk, each with its source and the date
 * it was recorded. No score, no go/no-go, no clearance. The surgeon or physician decides and can mark each flag
 * "reviewed" or "not relevant" (with a note); that is audited.
 * Presence-based factors flag by presence alone. Numeric factors (BMI, A1c, BP) flag ONLY when the practice has
 * enabled a trigger with a value approved by the medical director (all ship disabled and empty).
 */
import { repo } from '../v6/dataLayer';
import { MEDS } from '../v7/clearance';
import { effectiveAllergy } from '../v7/allergy';
import { medRepo, MedPatient, RiskReview, patientKey, conditionLabel, ConditionType, fmtDate, isHuman, RISK_DECIDER_ROLES } from './record';
import { getSettings, NumericTrigger } from './settings';

export interface RiskFlag { id: string; label: string; detail: string; source: string; recordedAt: string; category: 'Problem list' | 'Medications' | 'Allergies' | 'Intake' | 'Vitals' | 'Labs' }
export interface Measurement { trigger: NumericTrigger; value?: number; recordedAt?: string; source: string; flagged: boolean; configured: boolean }

const RISK_CONDITIONS: ConditionType[] = ['diabetes', 'heart', 'hypertension', 'osa', 'ckd', 'bleeding', 'lung'];
const MED_CLASSES: [RegExp, string][] = [...MEDS, [/\b(aspirin|asa)\b/i, 'Antiplatelet (aspirin)']];
const INTAKE_FLAGS: Record<string, (v: string) => string | null> = {
  smoking: v => /current/i.test(v) ? 'Current smoker (patient-reported)' : null,
  priorAnesthesiaProblems: v => /^yes/i.test(v) ? 'Prior problem with anesthesia (patient-reported)' : null,
  malignantHyperthermia: v => /^yes/i.test(v) ? 'Personal or family history of malignant hyperthermia (patient-reported)' : null,
  bleedingHistory: v => /^yes/i.test(v) ? 'Bleeding or easy-bruising history (patient-reported)' : null,
  sleepApnea: v => /^yes/i.test(v) ? 'Sleep apnea (patient-reported)' : null,
  bloodClots: v => /^yes/i.test(v) ? 'Prior blood clot (DVT/PE) (patient-reported)' : null,
  pregnancy: v => /^(yes|possible)/i.test(v) ? 'Pregnancy possible or confirmed (patient-reported)' : null,
};

export function riskFlags(p: MedPatient): RiskFlag[] {
  const out: RiskFlag[] = [];
  medRepo.problems(p.id).filter(x => x.status === 'active' && RISK_CONDITIONS.includes(x.conditionType)).forEach(x =>
    out.push({ id: `problem:${x.id}`, label: `${conditionLabel(x.conditionType)} on problem list`, detail: x.description + (x.note ? ` — ${x.note}` : ''), source: `Problem list (${x.source})`, recordedAt: x.recordedAt, category: 'Problem list' }));
  medRepo.meds(p.id).filter(m => m.status === 'active').forEach(m => {
    const hit = MED_CLASSES.find(([re]) => re.test(m.name));
    if (hit) out.push({ id: `med:${m.id}`, label: `On ${hit[1].toLowerCase().startsWith('antiplatelet') || hit[1] === 'Anticoagulant' ? 'an ' : 'a '}${hit[1]}`, detail: `${m.name} ${m.dose} ${m.frequency}`.trim(), source: `Medication list (${m.source})`, recordedAt: m.recordedAt, category: 'Medications' });
  });
  const a = effectiveAllergy(p.allergies, patientKey(p.id));
  if (a.state === 'allergies') out.push({ id: 'allergy:list', label: a.pendingConfirm ? 'Patient-reported allergies (not yet confirmed)' : 'Drug allergies recorded', detail: a.text, source: a.pendingConfirm ? `Intake (${a.sourceForm || 'intake'})` : 'Allergy record', recordedAt: p.allergiesConfirmedAt || '', category: 'Allergies' });
  if (a.state === 'not-reported') out.push({ id: 'allergy:not-reported', label: 'Allergy status not reported', detail: 'Ask the patient and record allergies or NKDA.', source: 'Allergy record', recordedAt: '', category: 'Allergies' });
  const onList = new Set(out.map(f => f.label));
  medRepo.intake(p.id).forEach(i => { const l = INTAKE_FLAGS[i.key]?.(i.value); if (l && !(i.key === 'sleepApnea' && onList.has('Sleep apnea on problem list'))) out.push({ id: `intake:${i.key}`, label: l, detail: i.detail || i.value, source: `Intake (${i.source})`, recordedAt: i.recordedAt, category: 'Intake' }); });
  measurements(p).filter(m => m.flagged).forEach(m => out.push({ id: `num:${m.trigger.id}`, label: `${m.trigger.label} ${m.value} ${m.trigger.unit} (practice trigger ${m.trigger.operator} ${m.trigger.value})`, detail: `Trigger approved by ${m.trigger.approvedBy} on ${m.trigger.approvedOn}`, source: m.source, recordedAt: m.recordedAt || '', category: m.trigger.source === 'lab' ? 'Labs' : 'Vitals' }));
  return out;
}

/** v11.5 · numbers recorded on the pre-op H&P / medical clearance (newest visit first). Keys are the clearance form's field names. */
const CLEARANCE_FILES = ['ASC_PreOp_HP_Clearance.html', 'PreOp_HP_Clearance.html', 'Surgeon_PreOp_Clearance.html'];
const CLEAR_KEY: Record<NumericTrigger['id'], RegExp> = { bmi: /^bmi/, bpSys: /^bp(_mmhg)?$|blood_pressure/, bpDia: /^bp(_mmhg)?$|blood_pressure/, hr: /^hr(_bpm)?$|heart_rate|^pulse/, spo2: /^spo2/, a1c: /^lab_a1c$|a1c/, hgb: /^lab_hgb$/, plt: /^lab_plt$/, inr: /^lab_inr$/, k: /^lab_k$/, cr: /^lab_cr$/, glucose: /^lab_glucose$/ };
function clearanceValue(p: MedPatient, t: NumericTrigger): { value: number; at: string; source: string } | undefined {
  const visits = (() => { try { return medRepo.visits().filter(v => v.patientId === p.id).sort((a, b) => (b.date || '').localeCompare(a.date || '')); } catch { return []; } })();
  for (const v of visits) for (const f of CLEARANCE_FILES) { const r = repo.getForm(v.id, f); const vals = r.values || {};
    const k = Object.keys(vals).find(x => CLEAR_KEY[t.id].test(x) && String(vals[x] ?? '').trim()); if (!k) continue;
    const raw = String(vals[k]); let n: number;
    if (t.id === 'bpSys' || t.id === 'bpDia') { const m = raw.match(/(\d{2,3})\s*\/\s*(\d{2,3})/); if (!m) continue; n = +(t.id === 'bpSys' ? m[1] : m[2]); } else { n = parseFloat(raw.replace(/[^0-9.]/g, '')); }
    if (!Number.isFinite(n)) continue; return { value: n, at: (r as any).updatedAt || v.date || '', source: `Pre-op clearance (${v.date || 'visit'})` }; }
  return undefined;
}
export function measurements(p: MedPatient): Measurement[] {
  const s = getSettings(); const vit = medRepo.vitals(p.id); const labs = medRepo.labs(p.id);
  return s.triggers.map(t => {
    let value: number | undefined; let recordedAt: string | undefined; let source = '';
    if (t.source === 'vitals') { const v = [...vit].reverse().find(x => (x as any)[t.id] != null); if (v) { value = (v as any)[t.id]; recordedAt = v.at; source = `Vitals (${v.source === 'manual' ? 'recorded by ' + v.by : v.source})`; } }
    else if (t.labTest) { const l = [...labs].reverse().find(x => x.test === t.labTest && x.valueNum != null); if (l) { value = l.valueNum; recordedAt = l.collectedAt; source = `Lab result (${l.source})`; } }
    // the pre-op clearance counts too, whichever is newer
    const c = clearanceValue(p, t); if (c && (value == null || (c.at || '') > (recordedAt || ''))) { value = c.value; recordedAt = c.at; source = c.source; }
    const configured = t.enabled && t.value != null && !!t.approvedBy.trim();
    const flagged = configured && value != null && (t.operator === '>=' ? value >= (t.value as number) : value <= (t.value as number));
    return { trigger: t, value, recordedAt, source, flagged, configured };
  });
}

export type ReviewState = { review?: RiskReview; changedSinceReview: boolean };
export function reviewState(f: RiskFlag, reviews: RiskReview[]): ReviewState {
  const review = reviews.find(r => r.factorId === f.id);
  return { review, changedSinceReview: !!(review && f.recordedAt && f.recordedAt > review.at) };
}

export function saveReview(p: MedPatient, f: RiskFlag, status: 'reviewed' | 'not-relevant', note: string, by: string, role: string) {
  if (!isHuman(by)) throw new Error('Only a named clinician can review a risk flag. Nightingale cannot.');
  if (!RISK_DECIDER_ROLES.includes(role)) throw new Error('Only the surgeon or physician can mark risk flags. Switch "Acting as" to a surgeon or physician.');
  if (status === 'not-relevant' && note.trim().length < 3) throw new Error('Add a short note saying why it is not relevant.');
  medRepo.saveRiskReview({ factorId: f.id, patientId: p.id, status, note: note.trim(), by, role, at: new Date().toISOString() });
  repo.audit({ caseId: patientKey(p.id), user: by, role, action: status === 'reviewed' ? 'risk.review' : 'risk.not-relevant', detail: `${f.label} · ${f.detail}${note.trim() ? ` · note: ${note.trim()}` : ''} (source: ${f.source}${f.recordedAt ? `, recorded ${fmtDate(f.recordedAt)}` : ''})` });
}
