/*
 * MED.Vityls v0.1 — longitudinal (patient-level) record + office visits.
 * Encounter data (visit note signatures, visit timestamps, station verification, audit) still goes through
 * src/v6/dataLayer.ts (`repo`), keyed by the visit id. Patient-level data (problems, meds, vitals, labs, care plan,
 * caregivers, risk reviews) goes through the PatientRecordRepository below. This is the swap point for Henry's API:
 * replace LocalPatientRecordRepository with an HTTP implementation; screens only call `medRepo`.
 * Test scaffolding: browser storage (MED namespace), fictional data only.
 */
import { repo } from '../v6/dataLayer';
import { PatientCase } from '../types';
import { pushPatient, pushVisit } from './dbSync';

export type ConditionType = 'diabetes' | 'heart' | 'hypertension' | 'osa' | 'ckd' | 'bleeding' | 'lung' | 'thyroid' | 'skin' | 'mental-health' | 'other';
export const CONDITION_TYPES: { id: ConditionType; label: string }[] = [
  { id: 'diabetes', label: 'Diabetes' }, { id: 'heart', label: 'Heart disease' }, { id: 'hypertension', label: 'Hypertension' },
  { id: 'osa', label: 'Sleep apnea' }, { id: 'ckd', label: 'Kidney disease' }, { id: 'bleeding', label: 'Bleeding / clotting disorder' },
  { id: 'lung', label: 'Lung disease' }, { id: 'thyroid', label: 'Thyroid' }, { id: 'skin', label: 'Skin' }, { id: 'mental-health', label: 'Mental health' }, { id: 'other', label: 'Other' },
];
export const conditionLabel = (t: ConditionType) => CONDITION_TYPES.find(c => c.id === t)?.label || 'Other';

export interface MedPatient { id: string; name: string; dob: string; sex: 'Female' | 'Male' | 'Other'; phone: string; email?: string; language: string; allergies: string[]; allergiesConfirmedAt?: string; allergiesConfirmedBy?: string; primaryProvider: string; careTeam: { name: string; role: string; phone?: string }[]; emergencyContact?: string; insurance?: string; fictional: true; recordSharingConsent?: { granted: boolean; by: string; at: string; scope: string } }
export interface Problem { id: string; patientId: string; description: string; conditionType: ConditionType; status: 'active' | 'resolved'; onset?: string; recordedAt: string; recordedBy: string; source: string; note?: string }
export interface Medication { id: string; patientId: string; name: string; dose: string; frequency: string; status: 'active' | 'stopped'; problemIds: string[]; source: string; recordedAt: string; recordedBy: string; startedAt?: string; stoppedAt?: string; simulatedRx?: boolean }
export interface Vitals { id: string; patientId: string; visitId?: string; at: string; by: string; source: 'manual' | 'simulated-voice' | 'device'; bpSys?: number; bpDia?: number; hr?: number; rr?: number; spo2?: number; tempF?: number; heightIn?: number; weightLb?: number; bmi?: number }
export interface LabResult { id: string; patientId: string; visitId?: string; test: string; value: string; valueNum?: number; unit?: string; reportedRange?: string; collectedAt: string; enteredAt: string; enteredBy: string; source: string; problemIds: string[]; status: 'awaiting-review' | 'reviewed' | 'released'; reviewedBy?: string; reviewedAt?: string; reviewNote?: string; releasedAt?: string; releasedBy?: string; patientNote?: string }
export type IntakeKey = 'smoking' | 'priorAnesthesiaProblems' | 'malignantHyperthermia' | 'bleedingHistory' | 'sleepApnea' | 'bloodClots' | 'pregnancy';
export interface IntakeAnswer { key: IntakeKey; value: string; detail?: string; recordedAt: string; source: string }
export interface CarePlanItem { id: string; kind: 'medication' | 'activity' | 'check'; title: string; instructions: string; times: ('morning' | 'midday' | 'evening' | 'bedtime')[]; days: number[]; medId?: string; problemId?: string }
export interface CarePlanSnapshot { items: CarePlanItem[]; goals: { id: string; text: string; problemId?: string }[]; signedBy: string; signedAt: string; version: number }
/** `published` is the last SIGNED version: the only thing the portal shows as the Medications & Activities plan. */
export interface CarePlan { patientId: string; items: CarePlanItem[]; goals: { id: string; text: string; problemId?: string }[]; status: 'draft' | 'signed'; updatedAt: string; updatedBy: string; signedBy?: string; signedAt?: string; version: number; published?: CarePlanSnapshot }
export interface Caregiver { id: string; patientId: string; name: string; relationship: string; email?: string; scope: { results: boolean; plan: boolean; appointments: boolean; messages: boolean }; grantedBy: string; grantedVia: 'staff' | 'patient'; authorization: string; grantedAt: string; expiresOn?: string; revokedAt?: string; revokedBy?: string }
export interface PortalMessage { id: string; patientId: string; from: 'patient' | 'caregiver' | 'office'; author: string; text: string; at: string; read?: boolean }
export interface RiskReview { factorId: string; patientId: string; status: 'reviewed' | 'not-relevant'; note: string; by: string; role: string; at: string }
/** Remote patient monitoring (wearables) — data-model hook only. Not used by any screen in v0.1. */
export interface DeviceReading { id: string; patientId: string; device: string; kind: string; value: number; unit: string; at: string; source: 'device' }

export type VisitStep = 'scheduled' | 'check-in' | 'rooming' | 'provider' | 'checkout' | 'complete';
export const VISIT_STEPS: { id: Exclude<VisitStep, 'scheduled' | 'complete'>; label: string }[] = [
  { id: 'check-in', label: 'Check-in' }, { id: 'rooming', label: 'Rooming / vitals' }, { id: 'provider', label: 'Provider visit' }, { id: 'checkout', label: 'Checkout' },
];
export const VISIT_TYPES = ['Cosmetic consultation', 'Pre-surgical consult', 'Post-op follow-up', 'Injectables / filler', 'Skin check', 'Established patient visit'] as const;
export interface MedVisit { id: string; patientId: string; date: string; time: string; durationMin: number; provider: string; room: string; visitType: string; reason: string; step: VisitStep; problemIds: string[]; createdAt: string; createdBy: string; recall?: { when: string; reason: string; by: string; at: string }; /** Surgery v1.6: the surgical case this visit belongs to ('general' = not case-related). Medical ignores it. */ caseId?: string }
export interface VisitNote { visitId: string; template: string; subjective: string; objective: string; assessment: string; plan: string; status: 'draft' | 'signed'; updatedAt: string; updatedBy: string; signedBy?: string; signedAt?: string; contentHash?: string; addenda: { at: string; by: string; text: string }[] }

export interface PatientRecordRepository {
  patients(): MedPatient[]; patient(id: string): MedPatient | undefined; savePatient(p: MedPatient): void;
  problems(pid: string): Problem[]; saveProblem(p: Problem, by: string): void;
  meds(pid: string): Medication[]; saveMed(m: Medication, by: string, action?: 'med.add' | 'med.update'): void;
  vitals(pid: string): Vitals[]; addVitals(v: Vitals): void;
  labs(pid?: string): LabResult[]; saveLab(l: LabResult): void;
  intake(pid: string): IntakeAnswer[]; saveIntake(pid: string, a: IntakeAnswer[], by: string): void;
  carePlan(pid: string): CarePlan | undefined; saveCarePlan(c: CarePlan): void;
  caregivers(pid?: string): Caregiver[]; saveCaregiver(c: Caregiver): void;
  messages(pid?: string): PortalMessage[]; addMessage(m: PortalMessage): void;
  riskReviews(pid: string): RiskReview[]; saveRiskReview(r: RiskReview): void;
  visits(pid?: string): MedVisit[]; visit(id: string): MedVisit | undefined; saveVisit(v: MedVisit): void;
  note(visitId: string): VisitNote | undefined; saveNote(n: VisitNote): void;
  deviceReadings(pid: string): DeviceReading[];
}

const K = 'vityls:med';
const read = <T,>(k: string, f: T): T => { try { const r = localStorage.getItem(`${K}:${k}`); return r ? JSON.parse(r) : f; } catch { return f; } };
const write = (k: string, v: unknown) => { try { localStorage.setItem(`${K}:${k}`, JSON.stringify(v)); } catch { throw new Error('Browser storage is full (test build).'); } ping(); };
export const ping = () => { try { window.dispatchEvent(new Event('vityls-med-updated')); } catch { /* */ } };
const upsert = <T extends { id: string }>(k: string, item: T) => { const l = read<T[]>(k, []); const i = l.findIndex(x => x.id === item.id); if (i >= 0) l[i] = item; else l.push(item); write(k, l); };

class LocalPatientRecordRepository implements PatientRecordRepository {
  patients() { return read<MedPatient[]>('patients', []); }
  patient(id: string) { return this.patients().find(p => p.id === id); }
  savePatient(p: MedPatient) { upsert('patients', p); }
  problems(pid: string) { return read<Problem[]>('problems', []).filter(p => p.patientId === pid); }
  saveProblem(p: Problem, by: string) { const isNew = !read<Problem[]>('problems', []).some(x => x.id === p.id); upsert('problems', p); repo.audit({ caseId: patientKey(p.patientId), user: by, role: actorRole(), action: isNew ? 'problem.add' : 'problem.update', detail: `${p.description} (${conditionLabel(p.conditionType)}, ${p.status})` }); }
  meds(pid: string) { return read<Medication[]>('meds', []).filter(m => m.patientId === pid); }
  saveMed(m: Medication, by: string, action: 'med.add' | 'med.update' = 'med.update') { upsert('meds', m); repo.audit({ caseId: patientKey(m.patientId), user: by, role: actorRole(), action, detail: `${m.name} ${m.dose} ${m.frequency} (${m.status})` }); }
  vitals(pid: string) { return read<Vitals[]>('vitals', []).filter(v => v.patientId === pid).sort((a, b) => a.at.localeCompare(b.at)); }
  addVitals(v: Vitals) { upsert('vitals', v); repo.audit({ caseId: v.visitId || patientKey(v.patientId), user: v.by, role: actorRole(), action: 'vitals.record', detail: vitalsText(v) }); }
  labs(pid?: string) { const l = read<LabResult[]>('labs', []); return (pid ? l.filter(x => x.patientId === pid) : l).sort((a, b) => a.collectedAt.localeCompare(b.collectedAt)); }
  saveLab(l: LabResult) { upsert('labs', l); }
  intake(pid: string) { return read<Record<string, IntakeAnswer[]>>('intake', {})[pid] || []; }
  saveIntake(pid: string, a: IntakeAnswer[], by: string) { const all = read<Record<string, IntakeAnswer[]>>('intake', {}); const cur = all[pid] || []; a.forEach(n => { const i = cur.findIndex(x => x.key === n.key); if (i >= 0) cur[i] = n; else cur.push(n); }); all[pid] = cur; write('intake', all); repo.audit({ caseId: patientKey(pid), user: by, role: actorRole(), action: 'intake.record', detail: a.map(x => `${x.key}: ${x.value}`).join('; ') }); }
  carePlan(pid: string) { return read<Record<string, CarePlan>>('careplans', {})[pid]; }
  saveCarePlan(c: CarePlan) { const all = read<Record<string, CarePlan>>('careplans', {}); all[c.patientId] = c; write('careplans', all); }
  caregivers(pid?: string) { const l = read<Caregiver[]>('caregivers', []); return pid ? l.filter(c => c.patientId === pid) : l; }
  saveCaregiver(c: Caregiver) { upsert('caregivers', c); }
  messages(pid?: string) { const l = read<PortalMessage[]>('messages', []); return (pid ? l.filter(m => m.patientId === pid) : l).sort((a, b) => a.at.localeCompare(b.at)); }
  addMessage(m: PortalMessage) { upsert('messages', m); repo.audit({ caseId: patientKey(m.patientId), user: m.author, role: m.from, action: 'portal.message', detail: m.text.slice(0, 120) }); }
  riskReviews(pid: string) { return read<RiskReview[]>('risk-reviews', []).filter(r => r.patientId === pid); }
  saveRiskReview(r: RiskReview) { const l = read<RiskReview[]>('risk-reviews', []).filter(x => !(x.patientId === r.patientId && x.factorId === r.factorId)); write('risk-reviews', [...l, r]); }
  visits(pid?: string) { const l = read<MedVisit[]>('visits', []); return (pid ? l.filter(v => v.patientId === pid) : l).sort((a, b) => (a.date + toMin(a.time)).localeCompare(b.date + toMin(b.time))); }
  visit(id: string) { return read<MedVisit[]>('visits', []).find(v => v.id === id); }
  saveVisit(v: MedVisit) { upsert('visits', v); }
  note(visitId: string) { return read<Record<string, VisitNote>>('notes', {})[visitId]; }
  saveNote(n: VisitNote) { const all = read<Record<string, VisitNote>>('notes', {}); all[n.visitId] = n; write('notes', all); }
  deviceReadings(pid: string) { return read<DeviceReading[]>('rpm-readings', []).filter(r => r.patientId === pid); }
}
/** Henry: same local cache, plus write-through to Azure SQL for patients and appointments (see ./dbSync.ts). */
class DbBackedPatientRecordRepository extends LocalPatientRecordRepository {
  savePatient(p: MedPatient) { super.savePatient(p); pushPatient(p); }
  saveVisit(v: MedVisit) { super.saveVisit(v); pushVisit(v); }
}
export const medRepo: PatientRecordRepository = new DbBackedPatientRecordRepository();

/* ---------- helpers ---------- */
export const patientKey = (pid: string) => `patient:${pid}`;
export const actorRole = () => { try { return repo.getActor().role; } catch { return 'Staff'; } };
export const actorName = () => { try { return repo.getActor().name; } catch { return 'Staff'; } };
export const uid = (p: string) => `${p}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 6)}`;
const pad = (n: number) => String(n).padStart(2, '0');
export const isoDay = (d = new Date()) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
export const usDate = (iso?: string) => { if (!iso) return ''; const m = iso.match(/^(\d{4})-(\d{2})-(\d{2})/); return m ? `${m[2]}/${m[3]}/${m[1]}` : iso; };
export const addDays = (iso: string, n: number) => { const [y, m, d] = iso.split('-').map(Number); const x = new Date(y, m - 1, d + n); return isoDay(x); };
export function toMin(t: string) { const m = String(t || '').match(/(\d{1,2}):(\d{2})\s*(AM|PM)?/i); if (!m) return '9999'; let h = +m[1]; if (m[3]) { if (/pm/i.test(m[3]) && h < 12) h += 12; if (/am/i.test(m[3]) && h === 12) h = 0; } return String(h * 60 + +m[2]).padStart(4, '0'); }
export const ageFrom = (dob: string) => { const m = dob.match(/(\d{2})\/(\d{2})\/(\d{4})/); if (!m) return 0; const b = new Date(+m[3], +m[1] - 1, +m[2]); const n = new Date(); let a = n.getFullYear() - b.getFullYear(); if (n < new Date(n.getFullYear(), b.getMonth(), b.getDate())) a--; return a; };
export const bmiFrom = (heightIn?: number, weightLb?: number) => heightIn && weightLb ? Math.round((703 * weightLb / (heightIn * heightIn)) * 10) / 10 : undefined;
export const vitalsText = (v: Vitals) => [v.bpSys && v.bpDia ? `BP ${v.bpSys}/${v.bpDia}` : '', v.hr ? `HR ${v.hr}` : '', v.rr ? `RR ${v.rr}` : '', v.spo2 ? `SpO2 ${v.spo2}%` : '', v.tempF ? `Temp ${v.tempF}°F` : '', v.heightIn ? `Ht ${v.heightIn} in` : '', v.weightLb ? `Wt ${v.weightLb} lb` : '', v.bmi ? `BMI ${v.bmi}` : ''].filter(Boolean).join(' · ');
export const fmtDate = (iso?: string) => iso ? new Date(iso.length === 10 ? iso + 'T12:00:00' : iso).toLocaleDateString() : '';
export const fmtDateTime = (iso?: string) => iso ? new Date(iso).toLocaleString([], { month: 'numeric', day: 'numeric', year: 'numeric', hour: 'numeric', minute: '2-digit' }) : '';
export const isHuman = (name: string) => !!name.trim() && !/nightingale|\bai\b/i.test(name);
export const PROVIDER_ROLES = ['Surgeon', 'Physician', 'Nurse practitioner', 'Physician assistant'];
export const RISK_DECIDER_ROLES = ['Surgeon', 'Physician'];

/** A MED visit presented as a PatientCase so shared modules (forms, signatures, invoices) can be reused. */
export function visitAsCase(v: MedVisit, p?: MedPatient): PatientCase {
  const pt = p || medRepo.patient(v.patientId);
  return { id: v.id, patientId: v.patientId, name: pt?.name || 'Unknown patient', age: pt ? ageFrom(pt.dob) : 0, gender: pt?.sex || 'Other', dob: pt?.dob, phone: pt?.phone || '', email: pt?.email,
    scheduledTime: v.time, appointmentDate: usDate(v.date), estimatedDurationMins: v.durationMin, room: v.room, surgeon: v.provider, procedure: `${v.visitType}${v.reason ? `: ${v.reason}` : ''}`,
    aiSummary: '', readinessScore: 0, readinessLevel: 'IN_PROGRESS' as any, allergies: pt?.allergies || [], labs: [], stage: 'CHECK_IN' as any, arrivalStatus: 'EN_ROUTE', arrivalTime: '', bottlenecks: [], actionItems: [], paymentType: 'Self-Pay' } as PatientCase;
}
