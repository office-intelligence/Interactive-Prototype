/* Vityls OS v11.5 · open the signed-in user's own practice (runs before anything reads browser storage).
 *
 * Practices created at /signup carry their edition (ASC / SURGERY / MEDICAL) on the server. When someone from such a
 * practice is signed in, this step:
 *   1. adds the practice to this device's practice list (id "org-<code>", its own storage namespace, demo data off),
 *   2. makes it the active practice, so the app runs the right edition and shows ONLY that practice's records,
 *   3. remembers who signed in (window.__vitylsMe) so the empty practice can greet its administrator.
 * Practices without an edition on the server (Henry's earlier test practices) and the patient Portal pages are left
 * exactly as before. Must not import edition.ts or the app (they read the practice list when they load). */
import { practices, upsertPractice, type Practice, type CoreEdition, type Entitlement } from '../../core/practices';
import { ALL_MODULE_IDS, EDITION_BUNDLES } from '../../core/modules';
import { startIdleLock } from './idle';

export interface SignedInUser { username: string; name: string; practice: string; practiceName: string; edition: CoreEdition | null; isManager: boolean; roles?: string[]; hasPin?: boolean; idleMinutes?: number }
const env = ((import.meta as any).env || {}) as Record<string, string | undefined>;
const raw: Storage = window.localStorage;

function apiConfigured(): boolean {
  try { const q = new URLSearchParams(location.search).get('api'); if (q === 'off') return false; if (q) return true; } catch { /* */ }
  return !!(raw.getItem('vityls:api') || env.VITE_API_URL || (window as any).VITYLS_API_URL);
}
function portalPage(): boolean {
  const qs = new URLSearchParams(location.search);
  if (location.hash.startsWith('#portal')) return true;
  return String(env.VITE_PORTAL || '') === '1' && !qs.has('practice');
}
/** "org-pacificcoast": letters and digits only, so it is safe as an id, a URL value and a storage prefix. */
export const orgPracticeId = (code: string) => `org-${String(code).toLowerCase().replace(/[^a-z0-9]/g, '')}`;
const RUNTIME: Record<CoreEdition, Practice['runtime']> = { ASC: 'ASC2', SURGERY: 'SURGERY', MEDICAL: 'MEDICAL' };

/** Returns true when the page must reload to open the signed-in practice. The built app evaluates every module as soon as
 *  the page loads (one bundle), so the practice it runs is decided before this check finishes; if that was not the
 *  signed-in user's practice, the choice is saved and the page reloads before anything is sent to the database. */
export async function bindSignedInPractice(): Promise<boolean> {
  if (!apiConfigured() || portalPage()) return false;
  let me: SignedInUser | null = null;
  try {
    const r = await fetch('/api/auth/me', { credentials: 'same-origin' });
    if (r.status === 401) { // signed out: go straight to the sign-in page (no blank page while the app loads)
      (window as any).__vitylsReloading = true;
      location.replace('/login?next=' + encodeURIComponent(location.pathname + location.search + location.hash));
      return true;
    }
    if (!r.ok) return false;
    me = await r.json();
  } catch { return false; }
  startIdleLock(me?.idleMinutes || 30); // v11.5: every signed-in practice page locks after a break
  if (!me?.edition || !RUNTIME[me.edition]) return false;
  (window as any).__vitylsMe = me;
  const id = orgPracticeId(me.practice);
  const prev = practices().find(p => p.id === id);
  const modules = Object.fromEntries(ALL_MODULE_IDS.map(m => [m, prev?.modules[m] || ({ state: EDITION_BUNDLES[me!.edition!].includes(m) ? 'active' : 'off' } as Entitlement)]));
  const p: Practice = {
    id, name: me.practiceName || me.practice, edition: me.edition, runtime: RUNTIME[me.edition], namespace: `vityls-${id}~`,
    brand: me.edition === 'ASC' ? 'ASC' : me.edition === 'SURGERY' ? 'Surgery' : 'Medical', locked: 'teaser', expired: 'read-only',
    plan: prev?.plan || 'full', status: 'live', onboarded: prev?.onboarded || false, demo: false,
    createdAt: prev?.createdAt || new Date().toISOString(), note: 'Practice from the database (created at sign-up)', modules,
  };
  const u = new URL(location.href); const asked = u.searchParams.get('practice');
  // Did this page load open the right practice? (registry entry, edition and active practice already in place)
  const ranRight = !!prev && prev.runtime === p.runtime && raw.getItem('vityls:core:active') === id && (!asked || asked === id)
    && !u.searchParams.has('demo') && !u.searchParams.has('edition');
  if (!prev || prev.name !== p.name || prev.runtime !== p.runtime) upsertPractice(p, me.name || me.username, prev ? 'Practice details refreshed from the database' : 'Practice added from the database (signed in)');
  try {
    raw.setItem('vityls:core:active', id);
    raw.setItem(`${p.namespace}vityls:asc10:demo`, '0'); // a real practice never loads the demo pack
    if (!raw.getItem(`${p.namespace}vityls:v6:actor`)) raw.setItem(`${p.namespace}vityls:v6:actor`, JSON.stringify({ name: me.name || me.username, role: 'Practice administrator', kind: 'human' }));
    u.searchParams.set('practice', id); u.searchParams.delete('demo'); u.searchParams.delete('edition');
    if (ranRight) { if (asked !== id) history.replaceState(history.state, '', u.toString()); sessionStorage.removeItem('vityls:bind-reloads'); return false; }
    const n = Number(sessionStorage.getItem('vityls:bind-reloads') || '0');
    if (n >= 2) { console.warn('Vityls: could not open the signed-in practice (browser storage blocked?)'); return false; }
    sessionStorage.setItem('vityls:bind-reloads', String(n + 1));
    (window as any).__vitylsReloading = true; // nothing may be saved from this page load
    location.replace(u.toString());
    return true;
  } catch { return false; }
}
