/* Vityls OS v11.5 · an EMPTY practice for practices created at /signup (no demo patients, providers or cases).
 * Writes only the configuration every practice needs to open: the practice name, the default forms and which station
 * uses each, an empty provider list and the signed-in administrator as the person using this device. Everything else is
 * set up by the practice in Practice settings (the 8-step onboarding wizard). Runs once per practice: a second device
 * gets the same records from the database before this runs, sees the seed stamp and does nothing. */
import { repo } from '../../v6/dataLayer';
import { getSettings } from '../../med/settings';
import { MEDICAL_FEES } from '../../surgery/medical/data';
import type { SignedInUser } from './bind';

export const FRESH_SEED_VERSION = 'org-fresh-1';
const MY_FORMS: [string, string[], string][] = [
  ['Patient_Registration.html', ['frontOffice'], 'required'], ['Insurance_Information.html', ['frontOffice'], 'as-needed'],
  ['Medical_History.html', ['patientPortal', 'nursing'], 'required'], ['Photography_Media_Research_Consent.html', ['patientPortal', 'frontOffice'], 'as-needed'],
  ['Credit_Card_Authorization.html', ['frontOffice'], 'as-needed'], ['Procedure_Consent.html', ['surgeon'], 'as-needed'],
];
const STATIONS = ['patientPortal', 'frontOffice', 'nursing', 'anesthesia', 'orTeam', 'surgeon', 'pacu'];

export function seedFreshPractice(practiceName: string, medical: boolean) {
  try {
    if (localStorage.getItem('vityls:seed-version') === FRESH_SEED_VERSION) return;
    const me = (window as any).__vitylsMe as SignedInUser | undefined;
    const setIfMissing = (k: string, v: string) => { if (localStorage.getItem(k) === null) localStorage.setItem(k, v); };
    localStorage.setItem('vityls:seed-version', FRESH_SEED_VERSION);
    // legacy one-time clean-ups elsewhere in the app must not run on a practice that never had demo data
    setIfMissing('vityls-explicit-form-workflow-v3-clean', 'done'); setIfMissing('oi-premiere-official-html-library-v27-clean', 'done');
    setIfMissing('vityls:asc10:clean-config', new Date().toISOString());
    setIfMissing('vityls:v7:providers', '[]');
    // The Surgery and Medical screens add their own fictional examples the first time they open (each checks a
    // "seeded" stamp). A real practice must never get them, so they are stamped as done here.
    const SEEDED: [string, unknown][] = [['flow-seeded-v13', true], ['v17-seeded', true], ['v18-seeded', true], ['v12-seeded', true],
      ['med20-seeded', true], ['journeys-seeded-v12', true], ['episodes-seeded-v11', true], ['cases-seed-v16', true], ['hipaa-seeded', true],
      ['v06-seeded', true], ['asc86-seeded', 'asc86-seed-1'], ['asc87-seeded', 'asc87-seed-1'], ['asc83-seeded', true]];
    SEEDED.forEach(([k, v]) => setIfMissing(`vityls:surgery:${k}`, JSON.stringify(v)));
    setIfMissing('vityls:med:patients', '[]'); setIfMissing('vityls:med:visits', '[]');
    setIfMissing('vityls-my-forms:default-practice', JSON.stringify(MY_FORMS.map(f => f[0])));
    MY_FORMS.forEach(([file, stations, req]) => {
      const wf: Record<string, { enabled: boolean }> = {}; STATIONS.forEach(k => wf[k] = { enabled: stations.includes(k) });
      setIfMissing(`vityls-form-workflow:${file}`, JSON.stringify(wf)); setIfMissing(`vityls-form-requirement:${file}`, req);
    });
    if (localStorage.getItem('vityls:med:settings') === null) {
      const s = getSettings();
      localStorage.setItem('vityls:med:settings', JSON.stringify({ ...s, practiceName, ascName: '', ...(medical ? { fees: MEDICAL_FEES } : {}) }));
    }
    if (me && !localStorage.getItem('vityls:v6:actor')) repo.setActor({ name: me.name || me.username, role: 'Practice administrator', kind: 'human' } as any);
  } catch (e) { console.warn('Vityls: empty practice setup failed', e); }
}
