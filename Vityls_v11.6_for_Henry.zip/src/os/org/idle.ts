/* Vityls OS v11.5 · screen lock after a break.
 * After `minutes` without a click, key press, touch or scroll in ANY tab of the app on this computer, the server is told
 * to lock this sign-in and the page goes to /login, which shows "Screen locked" (unlock with the person's PIN) or the
 * normal sign-in when no PIN is set. The 15-second background sync does not count as activity, so a screen left open
 * really does lock. Must not import edition.ts or the app. */
const LAST = 'vityls:last-activity'; // shared by all tabs (outside every practice namespace, never synced)
export function startIdleLock(minutes: number) {
  if (!minutes || minutes < 1 || (window as any).__vitylsIdle) return; (window as any).__vitylsIdle = true;
  const raw = window.localStorage; const limit = minutes * 60000;
  const mark = () => { try { raw.setItem(LAST, String(Date.now())); } catch { /* */ } };
  let t = 0; const onAct = () => { const n = Date.now(); if (n - t > 5000) { t = n; mark(); } };
  mark(); ['pointerdown', 'keydown', 'wheel', 'touchstart', 'scroll', 'mousemove'].forEach(e => window.addEventListener(e, onAct, { passive: true, capture: true }));
  const check = async () => {
    const last = Number(raw.getItem(LAST) || Date.now());
    if (Date.now() - last < limit || (window as any).__vitylsReloading) return;
    (window as any).__vitylsReloading = true; // nothing more is saved from this page
    try { await fetch('/api/auth/lock', { method: 'POST', credentials: 'same-origin' }); } catch { /* the server locks it anyway after the idle time */ }
    location.replace('/login?next=' + encodeURIComponent(location.pathname + location.search + location.hash));
  };
  window.setInterval(() => { void check(); }, 20000);
}
