/* v11.6 · Vityls owner console (Kevin and Henry). Opens at #ceo (also #vityls-console, #vityls-admin) when the app runs
 * against the server. Access: the signed-in username must be listed in the server's OWNER_USERNAMES app setting.
 * Tabs: Practices (live from Azure SQL: users, providers, patients, last sign-in; plus plan, fees and payments),
 * Fee schedule (monthly / yearly price list, module add-ons), Vityls configuration (outside vendors and APIs) and Access.
 * Counts only, never patient data. Secrets never pass through this page: a vendor row names the App Service setting that
 * holds the key, and the server reports only whether that setting exists. */
import React, { useEffect, useMemo, useState } from 'react';
import { MODULES, MOD, type ModuleId } from '../core/modules';
import { SparkWordmark } from '../surgery/asc10/kit';
import './owner.css';

/* ---------- types ---------- */
export interface Plan { id: string; name: string; monthly: number; yearly: number; modules: ModuleId[]; includedProviders: number; extraProvider: number; active: boolean; note?: string }
export interface FeeSchedule { plans: Plan[]; addons: Partial<Record<ModuleId, { monthly: number; yearly: number }>>; setupFee: number; trialDays: number }
export type SubStatus = 'trial' | 'active' | 'past-due' | 'suspended' | 'cancelled';
export interface Sub { planId: string; cycle: 'monthly' | 'yearly'; status: SubStatus; start: string; addons: ModuleId[]; discountPct: number; note?: string }
export interface Payment { id: string; practiceId: string; date: string; amount: number; method: 'card' | 'ach' | 'check' | 'wire' | 'other'; ref: string; period: string; by: string }
export interface Vendor { id: string; category: string; vendor: string; purpose: string; environment: 'sandbox' | 'live'; accountId: string; secretSetting: string; webhookUrl: string; status: 'planned' | 'testing' | 'live' | 'off'; baa: boolean; notes: string }
interface Practice { id: string; code: string; name: string; active: boolean; createdAt: string | null; edition: string | null; users: number; providers: number; patients: number; lastLoginAt: string | null }
interface OwnerData { fees?: FeeSchedule; subs?: Record<string, Sub>; payments?: Payment[]; vendors?: Vendor[] }

/* ---------- defaults ---------- */
const CLINICAL: ModuleId[] = ['email-intake', 'scheduling', 'chart', 'stations-workflow', 'forms', 'asc-perioperative'];
const ALL_MODS = MODULES.filter(m => m.audience !== 'patient');
export const DEFAULT_FEES: FeeSchedule = {
  plans: [
    { id: 'starter', name: 'Starter (Email intake)', monthly: 299, yearly: 2990, modules: ['email-intake'], includedProviders: 3, extraProvider: 49, active: true },
    { id: 'clinical', name: 'Clinical', monthly: 899, yearly: 8990, modules: CLINICAL.filter(m => MOD[m]), includedProviders: 5, extraProvider: 79, active: true },
    { id: 'full', name: 'Full ASC bundle', monthly: 1499, yearly: 14990, modules: ALL_MODS.map(m => m.id).filter(m => m !== 'email-intake'), includedProviders: 10, extraProvider: 99, active: true },
  ],
  addons: {}, setupFee: 0, trialDays: 30,
};
const uid = (p: string) => `${p}-${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`;
export const DEFAULT_VENDORS: Vendor[] = [
  { id: 'v-finix', category: 'Card processing', vendor: 'Finix', purpose: 'Practice subscriptions and patient card payments (tokenized; no card numbers in Vityls)', environment: 'sandbox', accountId: '', secretSetting: 'FINIX_API_KEY', webhookUrl: '', status: 'planned', baa: false, notes: '' },
  { id: 'v-stedi', category: 'Insurance billing (EDI)', vendor: 'Stedi', purpose: 'Eligibility 270/271, claims 837P/837I, claim status and remittance 835', environment: 'sandbox', accountId: '', secretSetting: 'STEDI_API_KEY', webhookUrl: '', status: 'planned', baa: false, notes: '' },
  { id: 'v-ai', category: 'AI agents', vendor: 'Google Gemini', purpose: 'Nightingale drafting, chart and audit assistance', environment: 'live', accountId: '', secretSetting: 'GEMINI_API_KEY', webhookUrl: '', status: 'testing', baa: false, notes: 'Already read by the server (/api/ai).' },
  { id: 'v-email', category: 'Email', vendor: 'Azure Communication Services', purpose: 'Invitations, forms links, reminders, approval letters', environment: 'sandbox', accountId: '', secretSetting: 'ACS_CONNECTION_STRING', webhookUrl: '', status: 'planned', baa: false, notes: '' },
  { id: 'v-sms', category: 'Text messages (SMS)', vendor: 'Azure Communication Services', purpose: 'Reminders, next-day text, portal links', environment: 'sandbox', accountId: '', secretSetting: 'ACS_CONNECTION_STRING', webhookUrl: '', status: 'planned', baa: false, notes: '' },
  { id: 'v-fax', category: 'Fax', vendor: 'Documo', purpose: 'Inbound faxes to Booking intake; records packets out', environment: 'sandbox', accountId: '', secretSetting: 'FAX_API_KEY', webhookUrl: '', status: 'planned', baa: false, notes: '' },
];
const CATEGORIES = ['Card processing', 'Insurance billing (EDI)', 'Practice billing / invoicing', 'AI agents', 'Email', 'Text messages (SMS)', 'Fax', 'e-Prescribing', 'Labs', 'Identity / sign-in', 'Storage', 'Other'];
const SETTING_NAME = /^[A-Z][A-Z0-9_]{2,63}$/;
const LOOKS_SECRET = /(sk|pk|rk)_(live|test)_|-----BEGIN|AKIA[0-9A-Z]{12}|^[A-Za-z0-9+/=_-]{32,}$/;

/* ---------- money ---------- */
const money = (n: number) => `$${(Math.round(n * 100) / 100).toLocaleString('en-US', { minimumFractionDigits: n % 1 ? 2 : 0, maximumFractionDigits: 2 })}`;
const num = (v: string) => { const n = Number(String(v).replace(/[$,\s]/g, '')); return Number.isFinite(n) && n >= 0 ? n : 0; };
/** Price per billing period (monthly or yearly) and its monthly equivalent. */
export function subPrice(fees: FeeSchedule, s: Sub | undefined, providers: number) {
  if (!s) return { period: 0, monthly: 0, plan: undefined as Plan | undefined };
  const plan = fees.plans.find(p => p.id === s.planId); if (!plan) return { period: 0, monthly: 0, plan };
  const y = s.cycle === 'yearly'; const base = y ? plan.yearly : plan.monthly;
  const add = s.addons.filter(m => !plan.modules.includes(m)).reduce((t, m) => t + ((y ? fees.addons[m]?.yearly : fees.addons[m]?.monthly) || 0), 0);
  const extra = Math.max(0, providers - plan.includedProviders) * plan.extraProvider * (y ? 12 : 1);
  const period = (base + add + extra) * (1 - (s.discountPct || 0) / 100);
  return { period, monthly: y ? period / 12 : period, plan };
}
const billing = (s?: Sub) => !!s && (s.status === 'active' || s.status === 'past-due');
const modsOf = (fees: FeeSchedule, s?: Sub) => { const p = s && fees.plans.find(x => x.id === s.planId); return Array.from(new Set([...(p?.modules || []), ...(s?.addons || [])])); };
const usd = (iso: string | null) => (iso ? new Date(iso).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) : '—');
const thisMonth = () => new Date().toISOString().slice(0, 7);

/* ---------- api ---------- */
async function api<T>(url: string, body?: unknown): Promise<T> {
  const r = await fetch(url, { method: body === undefined ? 'GET' : 'PUT', credentials: 'same-origin', headers: body === undefined ? undefined : { 'Content-Type': 'application/json' }, body: body === undefined ? undefined : JSON.stringify(body) });
  const d = await r.json().catch(() => ({}));
  if (!r.ok) { const e = new Error(d.message || `Request failed (${r.status})`) as Error & { status?: number }; e.status = r.status; throw e; }
  return d as T;
}

type Tab = 'practices' | 'fees' | 'config' | 'access';
export const OwnerConsole: React.FC = () => {
  const [state, setState] = useState<'loading' | 'signed-out' | 'denied' | 'error' | 'ok'>('loading'); const [err, setErr] = useState('');
  const [practices, setPractices] = useState<Practice[]>([]); const [data, setData] = useState<OwnerData>({}); const [envPresent, setEnv] = useState<Record<string, boolean>>({}); const [owners, setOwners] = useState<string[]>([]);
  const [tab, setTab] = useState<Tab>('practices'); const [open, setOpen] = useState(''); const [msg, setMsg] = useState(''); const [q, setQ] = useState('');
  const load = async () => {
    try { const [p, d] = await Promise.all([api<{ practices: Practice[] }>('/api/owner/practices'), api<{ data: OwnerData; envPresent: Record<string, boolean>; owners: string[] }>('/api/owner/data')]);
      setPractices(p.practices); setData(d.data || {}); setEnv(d.envPresent || {}); setOwners(d.owners || []); setState('ok'); }
    catch (e) { const s = (e as any).status; setErr((e as Error).message); setState(s === 401 ? 'signed-out' : s === 403 ? 'denied' : 'error'); }
  };
  useEffect(() => { void load(); document.title = 'Vityls owner console'; }, []);
  const fees = data.fees || DEFAULT_FEES; const subs = data.subs || {}; const payments = data.payments || []; const vendors = data.vendors || DEFAULT_VENDORS;
  const save = async <K extends keyof OwnerData>(key: K, value: OwnerData[K], ok: string) => {
    const prev = data; setData({ ...data, [key]: value });
    try { await api('/api/owner/data', { key, value }); flash(ok);
      if (key === 'vendors') { const d = await api<{ envPresent: Record<string, boolean> }>('/api/owner/data'); setEnv(d.envPresent || {}); } // refresh "Key on server"
    } catch (e) { setData(prev); flash((e as Error).message, true); }
  };
  const [bad, setBad] = useState(false);
  const flash = (m: string, b = false) => { setMsg(m); setBad(b); window.clearTimeout((flash as any).t); (flash as any).t = window.setTimeout(() => setMsg(''), 5000); };

  if (state !== 'ok') return <div className="sv own-root"><div className="own-gate" data-testid="own-gate"><SparkWordmark /><h1 className="own-h1">Vityls owner console</h1>
    {state === 'loading' && <p>Loading…</p>}
    {state === 'signed-out' && <><p>Sign in with your Vityls owner account (password and authenticator code) to continue.</p><a className="a8-btn pri" href={`/login?next=${encodeURIComponent('/#ceo')}`} data-testid="own-signin">Sign in</a></>}
    {state === 'denied' && <><p data-testid="own-denied">{err}</p><p className="own-sub">Owners are set on the server in the <b>OWNER_USERNAMES</b> app setting (comma separated usernames, for example <code>kevin,henry</code>). Add yours in Azure: App Service → Settings → Environment variables, then restart the app. Locally: add it to <code>.env</code> and restart <code>npm run dev</code>.</p><a className="a8-btn" href="./">Back to the app</a></>}
    {state === 'error' && <><p className="a81-err">{err}</p><button type="button" className="a8-btn" onClick={() => { setState('loading'); void load(); }}>Try again</button></>}
  </div></div>;

  const rows = practices.filter(p => !q || `${p.name} ${p.code}`.toLowerCase().includes(q.toLowerCase()));
  const live = practices.filter(p => billing(subs[p.id]));
  const mrr = live.reduce((t, p) => t + subPrice(fees, subs[p.id], p.providers).monthly, 0);
  const month = payments.filter(x => x.date.startsWith(thisMonth())).reduce((t, x) => t + x.amount, 0);
  const kpis: [string, string][] = [['Practices', String(practices.length)], ['Paying', String(live.length)], ['Trials', String(practices.filter(p => subs[p.id]?.status === 'trial').length)], ['MRR', money(mrr)], ['ARR', money(mrr * 12)], ['Collected this month', money(month)], ['Users', String(practices.reduce((t, p) => t + p.users, 0))], ['Providers', String(practices.reduce((t, p) => t + p.providers, 0))]];

  return <div className="sv own-root" data-testid="owner-console"><div className="own-page">
    <header className="own-top"><SparkWordmark /><h1 className="own-h1">Owner console</h1><span className="v10-chip info">Owners only · counts, no patient data</span><span style={{ flex: 1 }} />
      <button type="button" className="a8-btn" onClick={() => { setState('loading'); void load(); }} data-testid="own-refresh">Refresh</button><a className="a8-btn" href="./">Back to the app</a></header>
    {msg && <div className={bad ? 'a81-err own-msg' : 'a81-ok own-msg'} role="status" data-testid="own-msg">{msg}</div>}
    <div className="own-kpis" data-testid="own-kpis">{kpis.map(([k, v]) => <div key={k} className="own-kpi"><span>{k}</span><b>{v}</b></div>)}</div>
    <nav className="own-tabs" role="tablist">{([['practices', 'Practices'], ['fees', 'Fee schedule'], ['config', 'Vityls configuration'], ['access', 'Access']] as [Tab, string][]).map(([t, l]) =>
      <button key={t} type="button" role="tab" aria-selected={tab === t} className={tab === t ? 'on' : ''} onClick={() => setTab(t)} data-testid={`own-tab-${t}`}>{l}</button>)}</nav>

    {tab === 'practices' && <section data-testid="own-practices">
      <div className="own-row"><input className="sv-input own-search" placeholder="Search practice name or code" value={q} onChange={e => setQ(e.target.value)} aria-label="Search practices" /><span className="own-sub">{rows.length} of {practices.length}</span></div>
      {!practices.length ? <div className="own-empty">No practices in the database yet.</div> :
        <div className="own-tablewrap"><table className="own-table"><thead><tr><th>Practice</th><th>Type</th><th>Began</th><th className="r">Providers</th><th className="r">Users</th><th className="r">Patients</th><th>Plan</th><th>Status</th><th className="r">Fee</th><th>Last payment</th><th>Last sign-in</th><th /></tr></thead>
          <tbody>{rows.map(p => { const s = subs[p.id]; const pr = subPrice(fees, s, p.providers); const pays = payments.filter(x => x.practiceId === p.id).sort((a, b) => b.date.localeCompare(a.date)); const last = pays[0];
            return <React.Fragment key={p.id}><tr data-testid="own-practice" data-pid={p.id} className={open === p.id ? 'on' : ''}>
              <td><b>{p.name}</b><div className="own-sub">{p.code}{!p.active && ' · inactive'}</div></td><td>{p.edition ? (p.edition === 'ASC' ? 'ASC' : p.edition[0] + p.edition.slice(1).toLowerCase()) : '—'}</td><td>{usd(s?.start || p.createdAt)}</td>
              <td className="r">{p.providers}</td><td className="r">{p.users}</td><td className="r">{p.patients}</td>
              <td>{pr.plan?.name || <span className="own-sub">No plan</span>}</td><td>{s ? <span className={`v10-chip ${s.status === 'active' ? 'ok' : s.status === 'trial' ? 'info' : s.status === 'past-due' ? 'warn' : 'nc'}`}>{s.status}</span> : '—'}</td>
              <td className="r">{s ? <>{money(pr.period)}<div className="own-sub">/{s.cycle === 'yearly' ? 'yr' : 'mo'}</div></> : '—'}</td>
              <td>{last ? <>{money(last.amount)}<div className="own-sub">{usd(last.date)}</div></> : <span className="own-sub">None</span>}</td><td>{usd(p.lastLoginAt)}</td>
              <td><button type="button" className="a8-btn" onClick={() => setOpen(open === p.id ? '' : p.id)} data-testid="own-open">{open === p.id ? 'Close' : 'Manage'}</button></td></tr>
              {open === p.id && <tr><td colSpan={12}><PracticePanel p={p} fees={fees} sub={s} pays={pays} onSub={v => save('subs', { ...subs, [p.id]: v }, `${p.name}: plan saved.`)}
                onPay={x => save('payments', [...payments, x], `${money(x.amount)} recorded for ${p.name}.`)} onDelPay={id => save('payments', payments.filter(x => x.id !== id), 'Payment removed.')} /></td></tr>}
            </React.Fragment>; })}</tbody></table></div>}
      <p className="own-sub">Practices, users, providers, patients and last sign-in come live from the database. Plans and payments are kept by this console until card processing (Finix) is connected; then payments arrive automatically.</p>
    </section>}

    {tab === 'fees' && <FeeEditor fees={fees} onSave={v => save('fees', v, 'Fee schedule saved.')} />}
    {tab === 'config' && <VendorEditor vendors={vendors} env={envPresent} saved={!!data.vendors} onSave={v => save('vendors', v, 'Vityls configuration saved.')} />}
    {tab === 'access' && <section className="own-card" data-testid="own-access"><h2 className="own-h2">Who can open this console</h2>
      <p>Owners on this server: {owners.map(o => <code key={o} className="own-code">{o}</code>)}</p>
      <p className="own-sub">Set in the server's <b>OWNER_USERNAMES</b> app setting. Owners sign in like everyone else (password and authenticator code). Clinical and practice staff accounts cannot open this page, even practice administrators.</p>
      <h2 className="own-h2">Server secrets</h2><ul className="own-env">{Object.entries(envPresent).map(([k, v]) => <li key={k}><code>{k}</code><span className={`v10-chip ${v ? 'ok' : 'nc'}`}>{v ? 'Set' : 'Not set'}</span></li>)}</ul>
      <p className="own-sub">Only whether each setting exists is shown. Values never leave the server.</p></section>}
  </div></div>;
};

/* ---------- practice: plan + payments ---------- */
const PracticePanel: React.FC<{ p: Practice; fees: FeeSchedule; sub?: Sub; pays: Payment[]; onSub: (s: Sub) => void; onPay: (x: Payment) => void; onDelPay: (id: string) => void }> = ({ p, fees, sub, pays, onSub, onPay, onDelPay }) => {
  const [s, setS] = useState<Sub>(() => sub || { planId: fees.plans.find(x => x.active)?.id || '', cycle: 'monthly', status: 'trial', start: (p.createdAt || new Date().toISOString()).slice(0, 10), addons: [], discountPct: 0 });
  const pr = subPrice(fees, s, p.providers); const plan = pr.plan; const mods = modsOf(fees, s);
  const [pay, setPay] = useState({ date: new Date().toISOString().slice(0, 10), amount: '', method: 'card' as Payment['method'], ref: '', period: thisMonth() });
  const total = pays.reduce((t, x) => t + x.amount, 0);
  return <div className="own-panel" data-testid="own-panel">
    <div className="own-card"><h3 className="own-h3">Plan and fee</h3>
      <div className="own-form">
        <label>Plan<select className="sv-input" value={s.planId} onChange={e => setS({ ...s, planId: e.target.value })} data-testid="own-plan">{fees.plans.map(x => <option key={x.id} value={x.id} disabled={!x.active}>{x.name}{x.active ? '' : ' (retired)'}</option>)}</select></label>
        <label>Billing<select className="sv-input" value={s.cycle} onChange={e => setS({ ...s, cycle: e.target.value as Sub['cycle'] })} data-testid="own-cycle"><option value="monthly">Monthly</option><option value="yearly">Yearly</option></select></label>
        <label>Status<select className="sv-input" value={s.status} onChange={e => setS({ ...s, status: e.target.value as SubStatus })} data-testid="own-status">{(['trial', 'active', 'past-due', 'suspended', 'cancelled'] as SubStatus[]).map(x => <option key={x}>{x}</option>)}</select></label>
        <label>Start date<input className="sv-input" type="date" value={s.start} onChange={e => setS({ ...s, start: e.target.value })} data-testid="own-start" /></label>
        <label>Discount %<input className="sv-input" inputMode="decimal" value={s.discountPct || ''} onChange={e => setS({ ...s, discountPct: Math.min(100, num(e.target.value)) })} data-testid="own-discount" /></label>
      </div>
      <div className="own-sub mt-2">Modules in use ({mods.length})</div>
      <div className="own-chips">{ALL_MODS.map(m => { const inPlan = !!plan?.modules.includes(m.id); const on = mods.includes(m.id); const ad = fees.addons[m.id];
        return <label key={m.id} className={`own-chip ${on ? 'on' : ''} ${inPlan ? 'plan' : ''}`} title={inPlan ? 'Included in the plan' : ad ? `Add-on ${money(s.cycle === 'yearly' ? ad.yearly : ad.monthly)}` : 'Add-on (no price set)'}>
          <input type="checkbox" checked={on} disabled={inPlan} onChange={e => setS({ ...s, addons: e.target.checked ? [...s.addons, m.id] : s.addons.filter(x => x !== m.id) })} />{m.short || m.name}{!inPlan && on && ad ? ` +${money(s.cycle === 'yearly' ? ad.yearly : ad.monthly)}` : ''}</label>; })}</div>
      <label className="own-note">Note<input className="sv-input" value={s.note || ''} onChange={e => setS({ ...s, note: e.target.value })} placeholder="e.g. founding customer pricing" /></label>
      <div className="own-row mt-2"><b data-testid="own-price">{money(pr.period)} / {s.cycle === 'yearly' ? 'year' : 'month'}</b>
        <span className="own-sub">{plan ? `${plan.name} ${money(s.cycle === 'yearly' ? plan.yearly : plan.monthly)}` : ''}{plan && p.providers > plan.includedProviders ? ` + ${p.providers - plan.includedProviders} extra provider${p.providers - plan.includedProviders === 1 ? '' : 's'}` : ''}{s.discountPct ? ` − ${s.discountPct}%` : ''}</span>
        <span style={{ flex: 1 }} /><button type="button" className="a8-btn pri" onClick={() => onSub(s)} data-testid="own-save-sub">Save plan</button></div>
      <p className="own-sub">This sets the price list for the practice. Turning modules on or off inside the practice's app from here is the next step (Henry: read this record at sign-in).</p>
    </div>
    <div className="own-card"><h3 className="own-h3">Payments <span className="own-sub">· {money(total)} total</span></h3>
      <div className="own-form">
        <label>Date<input className="sv-input" type="date" value={pay.date} onChange={e => setPay({ ...pay, date: e.target.value })} /></label>
        <label>Amount<input className="sv-input" inputMode="decimal" value={pay.amount} onChange={e => setPay({ ...pay, amount: e.target.value })} placeholder={pr.period ? String(Math.round(pr.period * 100) / 100) : '0'} data-testid="own-pay-amount" /></label>
        <label>Method<select className="sv-input" value={pay.method} onChange={e => setPay({ ...pay, method: e.target.value as Payment['method'] })}><option value="card">Card</option><option value="ach">ACH</option><option value="check">Check</option><option value="wire">Wire</option><option value="other">Other</option></select></label>
        <label>For period<input className="sv-input" type="month" value={pay.period} onChange={e => setPay({ ...pay, period: e.target.value })} /></label>
        <label>Reference<input className="sv-input" value={pay.ref} onChange={e => setPay({ ...pay, ref: e.target.value })} placeholder="check no. or receipt" /></label>
      </div>
      <div className="own-row mt-2"><span style={{ flex: 1 }} /><button type="button" className="a8-btn pri" disabled={!num(pay.amount || String(pr.period))} onClick={() => { const amount = num(pay.amount || String(pr.period)); onPay({ id: uid('pay'), practiceId: p.id, date: pay.date, amount, method: pay.method, ref: pay.ref.trim().slice(0, 80), period: pay.period, by: '' }); setPay({ ...pay, amount: '', ref: '' }); }} data-testid="own-pay-add">Record payment</button></div>
      {pays.length ? <table className="own-table sm"><thead><tr><th>Date</th><th>Period</th><th className="r">Amount</th><th>Method</th><th>Reference</th><th /></tr></thead><tbody>{pays.map(x => <tr key={x.id} data-testid="own-pay-row"><td>{usd(x.date + 'T12:00:00')}</td><td>{x.period}</td><td className="r">{money(x.amount)}</td><td>{x.method}</td><td>{x.ref}</td><td><button type="button" className="own-link" onClick={() => { if (confirmDel()) onDelPay(x.id); }}>Remove</button></td></tr>)}</tbody></table> : <p className="own-sub">No payments recorded.</p>}
    </div>
  </div>;
};
const confirmDel = () => { try { return window.confirm('Remove this payment record?'); } catch { return true; } };

/* ---------- fee schedule ---------- */
const FeeEditor: React.FC<{ fees: FeeSchedule; onSave: (f: FeeSchedule) => void }> = ({ fees, onSave }) => {
  const [f, setF] = useState<FeeSchedule>(() => JSON.parse(JSON.stringify(fees))); const dirty = useMemo(() => JSON.stringify(f) !== JSON.stringify(fees), [f, fees]);
  const setPlan = (i: number, v: Partial<Plan>) => setF({ ...f, plans: f.plans.map((p, j) => j === i ? { ...p, ...v } : p) });
  return <section data-testid="own-fees">
    <div className="own-card"><div className="own-row"><h2 className="own-h2" style={{ margin: 0 }}>Plans</h2><span style={{ flex: 1 }} /><button type="button" className="a8-btn" onClick={() => setF({ ...f, plans: [...f.plans, { id: uid('plan'), name: 'New plan', monthly: 0, yearly: 0, modules: [], includedProviders: 1, extraProvider: 0, active: true }] })} data-testid="own-plan-add">Add plan</button></div>
      <div className="own-tablewrap"><table className="own-table"><thead><tr><th>Plan name</th><th className="r">Monthly</th><th className="r">Yearly</th><th className="r">Yearly saves</th><th className="r">Providers included</th><th className="r">Each extra provider / mo</th><th>Offered</th></tr></thead>
        <tbody>{f.plans.map((p, i) => <React.Fragment key={p.id}><tr data-testid="own-plan-row">
          <td><input className="sv-input" value={p.name} onChange={e => setPlan(i, { name: e.target.value })} aria-label="Plan name" /></td>
          <td className="r"><Money v={p.monthly} on={v => setPlan(i, { monthly: v })} label="Monthly price" testId="own-plan-monthly" /></td>
          <td className="r"><Money v={p.yearly} on={v => setPlan(i, { yearly: v })} label="Yearly price" testId="own-plan-yearly" /></td>
          <td className="r own-sub">{p.monthly && p.yearly ? `${Math.round((1 - p.yearly / (p.monthly * 12)) * 100)}%` : '—'}</td>
          <td className="r"><input className="sv-input own-num" inputMode="numeric" value={p.includedProviders} onChange={e => setPlan(i, { includedProviders: Math.round(num(e.target.value)) })} aria-label="Providers included" /></td>
          <td className="r"><Money v={p.extraProvider} on={v => setPlan(i, { extraProvider: v })} label="Extra provider price" /></td>
          <td><label className="own-inline"><input type="checkbox" checked={p.active} onChange={e => setPlan(i, { active: e.target.checked })} /> {p.active ? 'Yes' : 'Retired'}</label></td></tr>
          <tr className="own-sublist"><td colSpan={7}><div className="own-chips">{ALL_MODS.map(m => <label key={m.id} className={`own-chip ${p.modules.includes(m.id) ? 'on' : ''}`}><input type="checkbox" checked={p.modules.includes(m.id)} onChange={e => setPlan(i, { modules: e.target.checked ? [...p.modules, m.id] : p.modules.filter(x => x !== m.id) })} />{m.short || m.name}</label>)}</div></td></tr>
        </React.Fragment>)}</tbody></table></div></div>
    <div className="own-card"><h2 className="own-h2">Module add-ons</h2><p className="own-sub">Price when a practice adds a module that its plan does not include.</p>
      <div className="own-tablewrap"><table className="own-table sm"><thead><tr><th>Module</th><th className="r">Monthly</th><th className="r">Yearly</th></tr></thead><tbody>{ALL_MODS.map(m => { const a = f.addons[m.id] || { monthly: 0, yearly: 0 };
        return <tr key={m.id}><td>{m.name}</td><td className="r"><Money v={a.monthly} on={v => setF({ ...f, addons: { ...f.addons, [m.id]: { ...a, monthly: v } } })} label={`${m.name} monthly`} /></td><td className="r"><Money v={a.yearly} on={v => setF({ ...f, addons: { ...f.addons, [m.id]: { ...a, yearly: v } } })} label={`${m.name} yearly`} /></td></tr>; })}</tbody></table></div></div>
    <div className="own-card own-form"><label>One-time setup fee<Money v={f.setupFee} on={v => setF({ ...f, setupFee: v })} label="Setup fee" /></label><label>Free trial (days)<input className="sv-input own-num" inputMode="numeric" value={f.trialDays} onChange={e => setF({ ...f, trialDays: Math.round(num(e.target.value)) })} /></label></div>
    <div className="own-savebar"><span className="own-sub">{dirty ? 'Unsaved changes. Prices apply to practices from the next billing period.' : 'Saved.'}</span><span style={{ flex: 1 }} /><button type="button" className="a8-btn" disabled={!dirty} onClick={() => setF(JSON.parse(JSON.stringify(fees)))}>Undo changes</button><button type="button" className="a8-btn pri" disabled={!dirty} onClick={() => onSave(f)} data-testid="own-fees-save">Save fee schedule</button></div>
  </section>;
};
const Money: React.FC<{ v: number; on: (v: number) => void; label: string; testId?: string }> = ({ v, on, label, testId }) => {
  const [t, setT] = useState(String(v ?? 0)); useEffect(() => setT(String(v ?? 0)), [v]);
  return <span className="own-money">$<input className="sv-input own-num" inputMode="decimal" value={t} onChange={e => setT(e.target.value)} onBlur={() => on(num(t))} aria-label={label} data-testid={testId} /></span>;
};

/* ---------- Vityls configuration (vendors) ---------- */
const VendorEditor: React.FC<{ vendors: Vendor[]; env: Record<string, boolean>; saved: boolean; onSave: (v: Vendor[]) => void }> = ({ vendors, env, saved, onSave }) => {
  const [list, setList] = useState<Vendor[]>(() => JSON.parse(JSON.stringify(vendors))); const [edit, setEdit] = useState<string>(''); const [err, setErr] = useState('');
  const dirty = !saved || JSON.stringify(list) !== JSON.stringify(vendors);
  const set = (id: string, v: Partial<Vendor>) => setList(list.map(x => x.id === id ? { ...x, ...v } : x));
  const check = () => { for (const x of list) { if (x.secretSetting && !SETTING_NAME.test(x.secretSetting)) return `${x.vendor}: "${x.secretSetting.slice(0, 10)}…" is not a setting name. Enter the NAME of the App Service setting, for example FINIX_API_KEY. Never paste the key itself.`;
    if ([x.accountId, x.webhookUrl, x.notes].some(f => LOOKS_SECRET.test(f || ''))) return `${x.vendor}: a field looks like a secret key. Keys go in the App Service settings or Key Vault, not here.`; } return ''; };
  return <section data-testid="own-config">
    <div className="own-card"><h2 className="own-h2">Outside vendors and APIs</h2>
      <p className="own-sub">One row per service Vityls uses: card processing, insurance billing, AI agents, email, text, fax and others. Record the vendor, the account, and the <b>name</b> of the server setting that holds the API key. Henry puts the key itself in Azure (App Service → Environment variables, or Key Vault); this page then shows it as Set. Keys never go into this page or the browser.</p>
      <div className="own-tablewrap"><table className="own-table"><thead><tr><th>Service</th><th>Vendor</th><th>Environment</th><th>Server setting</th><th>Key on server</th><th>BAA</th><th>Status</th><th /></tr></thead>
        <tbody>{list.map(x => <React.Fragment key={x.id}><tr data-testid="own-vendor">
          <td><b>{x.category}</b><div className="own-sub">{x.purpose}</div></td><td>{x.vendor}</td><td>{x.environment === 'live' ? 'Live' : 'Sandbox'}</td>
          <td>{x.secretSetting ? <code className="own-code">{x.secretSetting}</code> : <span className="own-sub">—</span>}</td>
          <td>{x.secretSetting ? <span className={`v10-chip ${env[x.secretSetting] ? 'ok' : 'nc'}`} data-testid="own-vendor-key">{env[x.secretSetting] ? 'Set' : env[x.secretSetting] === false ? 'Not set' : 'Save to check'}</span> : '—'}</td>
          <td>{x.baa ? 'Signed' : <span className="own-sub">Needed{/patient|card|claim|fax|email|sms|text|ai/i.test(x.category + x.purpose) ? '' : '?'}</span>}</td>
          <td><span className={`v10-chip ${x.status === 'live' ? 'ok' : x.status === 'testing' ? 'info' : x.status === 'off' ? 'nc' : ''}`}>{x.status}</span></td>
          <td><button type="button" className="a8-btn" onClick={() => setEdit(edit === x.id ? '' : x.id)} data-testid="own-vendor-edit">{edit === x.id ? 'Done' : 'Edit'}</button></td></tr>
          {edit === x.id && <tr><td colSpan={8}><div className="own-form own-vform">
            <label>Service<select className="sv-input" value={x.category} onChange={e => set(x.id, { category: e.target.value })}>{Array.from(new Set([...CATEGORIES, x.category])).map(c => <option key={c}>{c}</option>)}</select></label>
            <label>Vendor<input className="sv-input" value={x.vendor} onChange={e => set(x.id, { vendor: e.target.value })} data-testid="own-v-vendor" /></label>
            <label className="wide">What Vityls uses it for<input className="sv-input" value={x.purpose} onChange={e => set(x.id, { purpose: e.target.value })} /></label>
            <label>Environment<select className="sv-input" value={x.environment} onChange={e => set(x.id, { environment: e.target.value as Vendor['environment'] })}><option value="sandbox">Sandbox / test</option><option value="live">Live</option></select></label>
            <label>Account or merchant ID (not secret)<input className="sv-input" value={x.accountId} onChange={e => set(x.id, { accountId: e.target.value })} /></label>
            <label>Server setting that holds the key<input className="sv-input" value={x.secretSetting} onChange={e => set(x.id, { secretSetting: e.target.value.trim() })} placeholder="FINIX_API_KEY" data-testid="own-v-setting" /></label>
            <label className="wide">Webhook address (vendor → Vityls)<input className="sv-input" value={x.webhookUrl} onChange={e => set(x.id, { webhookUrl: e.target.value })} placeholder="https://…/api/webhooks/finix" /></label>
            <label>Status<select className="sv-input" value={x.status} onChange={e => set(x.id, { status: e.target.value as Vendor['status'] })}><option value="planned">Planned</option><option value="testing">Testing</option><option value="live">Live</option><option value="off">Off</option></select></label>
            <label className="own-inline"><input type="checkbox" checked={x.baa} onChange={e => set(x.id, { baa: e.target.checked })} /> BAA signed with this vendor</label>
            <label className="wide">Notes<input className="sv-input" value={x.notes} onChange={e => set(x.id, { notes: e.target.value })} /></label>
            <div className="wide own-row"><span style={{ flex: 1 }} /><button type="button" className="own-link danger" onClick={() => { setList(list.filter(y => y.id !== x.id)); setEdit(''); }}>Remove this vendor</button></div>
          </div></td></tr>}
        </React.Fragment>)}</tbody></table></div>
      <div className="own-row mt-2"><button type="button" className="a8-btn" onClick={() => { const v: Vendor = { id: uid('v'), category: 'Other', vendor: 'New vendor', purpose: '', environment: 'sandbox', accountId: '', secretSetting: '', webhookUrl: '', status: 'planned', baa: false, notes: '' }; setList([...list, v]); setEdit(v.id); }} data-testid="own-vendor-add">Add vendor</button></div>
    </div>
    {err && <p className="a81-err" role="alert" data-testid="own-v-err">{err}</p>}
    <div className="own-savebar"><span className="own-sub">{dirty ? (saved ? 'Unsaved changes.' : 'Suggested starting list, not saved yet.') : 'Saved.'}</span><span style={{ flex: 1 }} /><button type="button" className="a8-btn pri" disabled={!dirty} onClick={() => { const e = check(); setErr(e); if (!e) onSave(list); }} data-testid="own-config-save">Save configuration</button></div>
  </section>;
};
