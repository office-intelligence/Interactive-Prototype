/*
 * Surgery.Vityls v1.3 · 7-step workflow: reads the chart into FlowFacts (flow/logic.ts) for EVERY patient, keeps the v1.2 journey
 * engine running underneath (one journey per patient, created from the patient's data when missing), Undecided / resume, the
 * station-edit audit log, form review (blank or mismatched fields) and the To-do list. Browser storage only; nothing external.
 */
import { repo } from '../../v6/dataLayer';
import { medRepo, MedPatient, MedVisit, isoDay, patientKey, addDays } from '../../med/record';
import { svRead, svWrite, scribeSession, nurseAdmission, intakeLinks, checkoutOrders } from '../store';
import * as F from './logic';
import { modeOf } from './apptMode';
import { journeyFor, journeysFor, startJourney, syncJourney } from '../journey/store';
import * as J from '../journey/logic';
import { activeEpisode, episodesFor, episode } from '../episodes/store';
import { flowKey, caseById, primaryCase, caseOf, caseOfVisit, casesFor, openCase, linkTo, syncCases, quickFacts, GENERAL, SurgicalCase, quickSteps, caseTitle } from '../cases/store';
import * as EL from '../episodes/logic';
import { quotesFor, quoteStatus, cur as curQuote } from '../quotes';
import { patientPayments } from '../payments';
import { photosOf, bodyCharts } from '../media';
import { formsPackets, NEW_PATIENT_FORMS, formTitle } from '../newPatient';
import { cardStatus } from '../v12/cards';
import { docsOf } from '../documents';
import { getSettings } from '../../med/settings';

export interface FlowState { packet?: { at: string; by: string; file: string; items: Record<string, 'received' | 'missing'>; corrected: string[]; docId?: string }; postopDraft?: Record<string, string>; regAccepted?: { at: string; by: string }; deposit?: { amount: number; date: string; at: string; by: string }; undecided?: { at: string; by: string; reason?: string }; resumed?: { at: string; by: string }; since?: string; clearance?: ClrState; checks?: { at: string; text: string }[] }
/** v1.4 #15: clearance is decided and sent independently of booking (kept here, mirrored to the episode once booked). */
export interface ClrState { pcpEmail?: string; pcpFax?: string; required: boolean; at: string; by: string; tests: string[]; sentAt?: string; sentBy?: string; via?: string[]; letter?: string }
/** v1.5: chosen tests → the booked case's list → the practice default list (pregnancy test off for male patients). */
export const clearanceTests = (pid: string): string[] => { const c = flowState(pid).clearance?.tests; if (c) return c; const ep = activeEpisode(pid); const k = ep ? Object.keys(ep.clearance.tests) : []; if (k.length) return k.includes('H&P') ? k : ['H&P', ...k]; return F.defaultTestsFor(medRepo.patient(pid)?.sex, flowSettings().clearanceTests); };
export interface FlowAudit { at: string; by: string; role: string; pid: string; step: F.FStep | 0; what: string }
export interface FlowSettings { consultFee: number; /** v1.5: practice default pre-op clearance tests */ clearanceTests: string[] }
export const flowSettings = (): FlowSettings => ({ consultFee: 150, clearanceTests: [...F.PCP_CHECKLIST], ...svRead<Partial<FlowSettings>>('flow-settings', {}) });
export function saveFlowSettings(p: Partial<FlowSettings>, by: string, role: string, what: string) { svWrite('flow-settings', { ...svRead<Partial<FlowSettings>>('flow-settings', {}), ...p }); repo.audit({ caseId: 'practice', user: by, role, action: 'settings.flow' as any, detail: what }); }
const all = () => svRead<Record<string, FlowState>>('flow-state', {});
/** v1.6: workflow state is kept per CASE (the primary/focused open case; the patient until a case opens). */
export const flowState = (pid: string, caseId?: string): FlowState => all()[flowKey(pid, caseId)] || {};
export function setFlowState(pid: string, f: (s: FlowState) => FlowState, caseId?: string) { const a = all(); const k = flowKey(pid, caseId); a[k] = f(a[k] || {}); svWrite('flow-state', a); }
export const flowAudit = (pid?: string) => svRead<FlowAudit[]>('flow-audit', []).filter(x => !pid || x.pid === pid);
/** Every workflow change (station edits through the progress dots, Undecided, resume) is logged here and in the patient audit trail. */
export function logFlow(pid: string, step: F.FStep | 0, what: string, by: string, role: string) {
  svWrite('flow-audit', [...svRead<FlowAudit[]>('flow-audit', []), { at: new Date().toISOString(), by, role, pid, step, what }]);
  repo.audit({ caseId: patientKey(pid), user: by, role, action: 'workflow.update' as any, detail: `${step ? `Step ${step} · ${F.stepDef(step).short}: ` : ''}${what}` });
}

/* ---------------- the cycle: a returning patient's earlier surgery is history, not open work ---------------- */
export function cycleStart(pid: string): string { const s = flowState(pid).since; if (s != null) return s; const j = journeyFor(pid); return j ? j.createdAt : ''; }
const POSTOP = /post-?op/i;
/** The consultation visit for this cycle (first non-post-op visit since the cycle began). */
export function consultVisit(pid: string, cs?: SurgicalCase): MedVisit | undefined {
  if (cs) { const ep = cs.episodeId ? episode(cs.episodeId) : undefined; const vs = medRepo.visits(pid).filter(v => caseOfVisit(v) === cs.id && !POSTOP.test(v.visitType));
    return (ep?.consultVisitId && medRepo.visit(ep.consultVisitId)) || vs.find(v => /consult|new/i.test(v.visitType)) || vs[0]; }
  const since = cycleStart(pid).slice(0, 10); const ep = activeEpisode(pid);
  const vs = medRepo.visits(pid).filter(v => !POSTOP.test(v.visitType) && v.date >= since && (!ep || v.date <= ep.surgeryDate)).sort((a, b) => a.date.localeCompare(b.date) || a.time.localeCompare(b.time));
  return (ep?.consultVisitId && medRepo.visit(ep.consultVisitId)) || vs.find(v => /consult|new/i.test(v.visitType)) || vs[0];
}
const stampOf = (facts: Record<string, any>, k: string) => facts[k]?.value ? { at: String(facts[k].source?.at || facts[k].at || ''), by: facts[k].source?.by } : undefined;

import { patientPartDone } from '../../v6/formRules';
/* ---------------- forms: portal-submitted registration / admission / history ---------------- */
export interface FormReview { file: string; title: string; caseId: string; status: 'not-returned' | 'in-progress' | 'complete'; blanks: string[]; blankKeys: string[]; mismatches: { label: string; form: string; chart: string }[]; at?: string }
const norm = (x: unknown) => String(x ?? '').toLowerCase().replace(/[^a-z0-9]/g, '');
export function formReviews(pid: string, v?: MedVisit): FormReview[] {
  const p = medRepo.patient(pid); const files = Array.from(new Set([...NEW_PATIENT_FORMS, ...formsPackets(pid).flatMap(x => x.forms)])).filter(f => NEW_PATIENT_FORMS.includes(f));
  return files.map(f => {
    const cands = [`portal-forms:${pid}`, ...(v ? [v.id] : [])].map(id => ({ id, r: repo.getForm(id, f) })); const best = cands.find(c => c.r.status === 'locked') || cands.find(c => c.r.status !== 'not-started') || cands[0];
    const r = best.r; const labels = r.labels || {}; const values = r.values || {};
    const blankKeys = Object.keys(labels).filter(k => { const x = values[k]; return (x == null || x === '' || x === false) && labels[k] && !/signature|initial|office use|staff/i.test(labels[k]); }); const blanks = blankKeys.map(k => labels[k]);
    const mm: FormReview['mismatches'] = [];
    if (p) Object.keys(labels).forEach(k => { const l = labels[k] || ''; const val = values[k]; if (val == null || val === '') return;
      const chart = /^(patient )?(full )?name$/i.test(l) ? p.name : /date of birth|^dob$/i.test(l) ? p.dob : /^(cell |mobile |home )?phone/i.test(l) ? p.phone : /^e-?mail/i.test(l) ? p.email || '' : null;
      if (chart != null && chart !== '' && norm(chart) !== norm(val)) mm.push({ label: l, form: String(val), chart }); });
    return { file: f, title: formTitle(f), caseId: best.id, blankKeys, status: r.status === 'locked' || patientPartDone(f, r.signatures || []) ? 'complete' : r.status === 'not-started' ? 'not-returned' : 'in-progress', blanks, mismatches: mm, at: r.updatedAt || r.lockedAt };
  });
}
/** What the front desk still needs for "Registration complete": forms back, no blanks or mismatches, ID + insurance cards on file. */
export function registrationGaps(pid: string, v?: MedVisit): string[] {
  const out: string[] = []; formReviews(pid, v).forEach(r => { if (r.status !== 'complete') out.push(`${r.title} not returned`); else { if (r.blanks.length) out.push(`${r.title}: ${r.blanks.length} blank field${r.blanks.length === 1 ? '' : 's'}`); r.mismatches.forEach(m => out.push(`${r.title}: ${m.label} differs from the chart`)); } });
  cardStatus(pid).missing.forEach(m => out.push(`${m.label.replace(/ins\./, 'insurance card')} image`)); return out;
}

/* ---------------- chart → FlowFacts ---------------- */
type S = F.Stamp;
const jDone = (pid: string, ...keys: string[]): S | undefined => { const j = journeyFor(pid); const it = j?.items.find(i => keys.includes(i.key) && i.status === 'done'); return it ? { at: it.doneAt || j!.createdAt, by: it.doneBy, note: it.note } : undefined; };
export function factsFor(pid: string, today = isoDay(), caseId?: string): F.FlowFacts {
  const cs = caseId ? caseById(caseId) : primaryCase(pid);
  const p = medRepo.patient(pid); const since = cycleStart(pid); const st = flowState(pid, cs?.id);
  const v = consultVisit(pid, cs); const ep = cs ? (cs.episodeId ? episode(cs.episodeId) : undefined) : activeEpisode(pid); const facts = v ? repo.getFacts(v.id) : {};
  const order = ['scheduled', 'check-in', 'rooming', 'provider', 'checkout', 'complete']; const past = (s: string) => !!v && order.indexOf(v.step) > order.indexOf(s);
  const f: F.FlowFacts = { today, mode: modeOf(v), visitDate: v?.date, paymentRequired: false };
  if (!p) return f;
  if (v) f.booked = { at: v.createdAt, by: v.createdBy, note: `${v.visitType} · ${v.date} ${v.time}` };
  const pk = formsPackets(pid).filter(x => x.sentAt >= since.slice(0, 10)); const il = v ? intakeLinks(v.id) : [];
  f.formsSent = pk.length ? { at: pk[pk.length - 1].sentAt, by: pk[pk.length - 1].by } : il.length ? { at: il[0].createdAt, by: il[0].by } : jDone(pid, 's1-intake') || (past('scheduled') ? { at: v!.createdAt, by: v!.createdBy, note: 'forms completed in the office' } : undefined);
  const gaps = registrationGaps(pid, v); f.registrationMissing = gaps;
  const arrived = stampOf(facts, 'visit.arrived');
  f.registration = !gaps.length ? { at: arrived?.at || since || v?.createdAt || '', by: arrived?.by } : st.regAccepted ? { ...st.regAccepted, note: 'reviewed with the patient' } : v && v.date >= today && !past('check-in') ? undefined : jDone(pid, 's3-forms', 's2-consents') || (past('check-in') ? { at: v!.date, by: 'Front desk', note: 'checked in' } : undefined);
  const priorCycle = journeysFor(pid).some(j => j.closedAt) || episodesFor(pid).some(e => e.stage === 'closed');
  f.paymentRequired = !!v && /new|consult/i.test(v.visitType) && !priorCycle && flowSettings().consultFee > 0;
  const pay = patientPayments(pid).filter(x => cs ? caseOf('payment', x.id) === cs.id : x.at >= since).sort((a, b) => a.at.localeCompare(b.at))[0];
  f.paid = pay ? { at: pay.at, by: pay.takenBy, note: `$${pay.amount}` } : ep && ep.paid > 0 ? { at: ep.history.find(h => /Payment/.test(h.what))?.at || ep.createdAt, by: 'Front desk' } : jDone(pid, 's3-pay');
  if (v) {
    const vit = medRepo.vitals(pid).find(x => x.visitId === v.id); const na = nurseAdmission(v.id);
    if (vit) f.vitals = { at: vit.at, by: vit.by, note: vit.rr == null ? 'respiratory rate missing' : undefined };
    if (vit && vit.rr == null) { f.vitalsMissing = ['respiratory rate']; f.vitals = undefined; }
    const reason = na?.chiefComplaint || (past('rooming') ? v.reason : ''); if (reason) f.reason = { at: na?.at || v.date, by: na?.by, note: reason };
    if (na || past('rooming')) f.nurseNotes = { at: na?.at || v.date, by: na?.by || 'Nurse', note: na?.nurseNote || 'no additional notes' };
    const sc = scribeSession(v.id); const note = medRepo.note(v.id);
    if (sc.lines.length || note) f.exam = { at: note?.updatedAt || sc.startedAt || v.date, by: note?.updatedBy || sc.startedBy };
    if (note?.status === 'signed') f.noteSigned = { at: note.signedAt || note.updatedAt, by: note.signedBy };
  }
  const bc = bodyCharts(pid).filter(c => (v && c.visitId === v.id) || c.at >= since); if (bc.length) f.bodyChart = { at: bc[0].at, by: bc[0].by };
  const ph = photosOf(pid).filter(x => (v && x.visitId === v.id) || x.at >= since); if (ph.length) f.photos = { at: ph[0].at, by: ph[0].by, note: `${ph.length} photo${ph.length === 1 ? '' : 's'}` };
  // a booked surgery means the doctor step happened even if this build has no record of a sub-item (seeded / migrated patients)
  if (ep) { const at = ep.createdAt; f.exam ||= { at, by: ep.surgeon, note: 'consult on file' }; f.noteSigned ||= jDone(pid, 's5-note') || { at, by: ep.surgeon, note: 'consult on file' }; if (f.mode !== 'phone') { f.bodyChart ||= { at, note: 'consult on file' }; f.photos ||= { at, note: 'consult on file' }; } }
  // a past visit that was closed means its stations happened (v1.2 data predates some sub-items): count them as on file
  if (v && v.step === 'complete' && v.date < today) { const on = { at: v.date, note: 'visit closed (on file)' }; f.registration ||= on; f.paid ||= f.paymentRequired ? on : undefined; f.reason ||= on; f.nurseNotes ||= on; if (f.mode === 'office') f.vitals ||= on; f.exam ||= on; f.noteSigned ||= on; if (f.mode !== 'phone') { f.bodyChart ||= on; f.photos ||= on; } }
  const qs = quotesFor(pid).filter(q => cs ? caseOf('quote', q.id) === cs.id : curQuote(q).createdAt >= since); const q = qs[0];
  if (q) f.quote = { at: curQuote(q).createdAt, by: curQuote(q).createdBy, note: `${q.number} v${curQuote(q).v}` };
  if (!f.quote && v && v.step === 'complete' && v.date < today) f.quote = { at: v.date, note: 'no quote needed (visit closed)' };
  const acc = qs.find(x => quoteStatus(x) === 'Accepted');
  if (acc) { const e = acc.events.slice().reverse().find(x => /accept/i.test(x.what)); f.quoteAccepted = { at: e?.at || curQuote(acc).createdAt, by: e?.by }; }
  if (ep) { f.quote ||= { at: ep.createdAt, note: `$${ep.totalAmount}` }; f.quoteAccepted ||= { at: ep.createdAt, by: ep.createdBy, note: `$${ep.totalAmount}` }; }
  if (st.undecided) f.undecided = st.undecided; if (st.resumed) f.resumed = st.resumed;
  if (ep) {
    if (ep.paid >= ep.depositAmount && ep.paid > 0) { const h = ep.history.find(x => /Payment/.test(x.what)); f.deposit = { at: h?.at || ep.createdAt, by: h?.by, amount: ep.depositAmount, date: (h?.at || ep.createdAt).slice(0, 10) }; }
    f.caseBooked = { at: ep.createdAt, by: ep.createdBy, surgeryDate: ep.surgeryDate, time: ep.surgeryTime, note: `${ep.procedure} · ${ep.ascName}` };
    const dec = ep.items.find(i => i.key === 'clr-decide' && i.status === 'done'); if (dec || ep.clearance.decidedBy || ep.clearance.requestedAt || !ep.clearance.required) f.clearance = { required: ep.clearance.required, at: dec?.doneAt || ep.createdAt, by: dec?.doneBy || ep.clearance.decidedBy || ep.surgeon };
    if (ep.clearance.requestedAt) f.pcpSent = { at: ep.clearance.requestedAt, by: ep.items.find(i => i.key === 'clr-request')?.doneBy };
    const rec: Partial<Record<string, S>> = {}; Object.entries(ep.clearance.tests).forEach(([t, s]) => { if (s === 'received') rec[t] = { at: ep.history.find(h => new RegExp(`\\b${t}\\b`).test(h.what))?.at || ep.createdAt }; });
    const hp = jDone(pid, 's7-t-H&P') || (docsOf(pid).find(d => /outside/i.test(d.type) && /history|h&p/i.test(d.title)) ? { at: docsOf(pid).find(d => /outside/i.test(d.type))!.receivedAt } : undefined); if (hp) rec['H&P'] = hp;
    f.received = rec;
    if (ep.asc.sentAt) f.ascSent = { at: ep.asc.sentAt, by: ep.items.find(i => i.key === 'asc-send')?.doneBy };
    if (ep.asc.confirmedAt) f.ascConfirmed = { at: ep.asc.confirmedAt, by: ep.ascName, time: ep.surgeryTime };
    const pv = medRepo.visits(pid).filter(x => POSTOP.test(x.visitType) && x.date >= ep.surgeryDate && (!cs || caseOfVisit(x) === cs.id)).map(x => ({ date: x.date, confirmed: false })); f.postop = pv.length ? pv : ep.postOp.filter(x => x.visitId).map(x => ({ date: x.date, confirmed: false }));
  }
  if (ep && !st.clearance) f.clearanceTests = clearanceTests(pid);
  // v1.5 #4: the clearance packet (one upload, Nightingale match, staff corrections) works before or after booking
  if (st.packet) { const r: Partial<Record<string, S>> = { ...(f.received || {}) }; Object.entries(st.packet.items).forEach(([t, x]) => { if (x === 'received') r[t] ||= { at: st.packet!.at, by: st.packet!.by, note: 'clearance packet' }; else delete r[t]; }); f.received = r; }
  if (st.clearance) { f.clearance ||= { required: st.clearance.required, at: st.clearance.at, by: st.clearance.by }; if (st.clearance.sentAt) f.pcpSent ||= { at: st.clearance.sentAt, by: st.clearance.sentBy }; f.clearanceTests = st.clearance.tests; }
  if (!f.deposit && st.deposit) f.deposit = { ...st.deposit, note: `$${st.deposit.amount} due ${st.deposit.date}` };
  if (F.FLOW_MED && v && past('provider')) { const on = { at: v.date, note: 'seen by the doctor' }; f.exam ||= on; f.reason ||= on; f.nurseNotes ||= on; if (f.mode === 'office') f.vitals ||= on; f.registration ||= on; f.formsSent ||= on; f.paid ||= f.paymentRequired ? on : undefined; }
  if (F.FLOW_MED && v && (v.step === 'complete' || (v.date < today && v.step !== 'scheduled'))) f.checkout = { at: v.date, by: 'Front desk', note: 'visit closed' };
  return f;
}
export const flowFor = (pid: string, today = isoDay(), caseId?: string) => F.deriveFlow(factsFor(pid, today, caseId));

/* ---------------- discrepancies & missing items Nightingale may flag (only these) ---------------- */
export interface Flag { kind: 'missing' | 'discrepancy'; text: string; key?: string }
export function flagsFor(pid: string, fl = flowFor(pid)): Flag[] {
  const out: Flag[] = []; const f = factsFor(pid); const ep = activeEpisode(pid);
  if (fl.step === 2 || fl.step === 1) (f.registrationMissing || []).slice(0, 4).forEach(t => out.push({ kind: /differs/.test(t) ? 'discrepancy' : 'missing', text: t, key: 'registration' }));
  if (fl.step === 3 && f.vitalsMissing?.length) out.push({ kind: 'missing', text: `Vitals: ${f.vitalsMissing.join(', ')}`, key: 'vitals' });
  F.carried(fl).forEach(i => out.push({ kind: 'missing', text: `From Step ${i.step}: ${i.label.toLowerCase()}`, key: i.key }));
  if (ep && ep.clearance.required && ep.clearance.requestedAt) { const want = clearanceTests(pid); const miss = want.filter(t => !f.received?.[t]); if (miss.length === want.length) out.push({ kind: 'missing', text: `Waiting on the PCP's packet (${miss.length} items)`, key: 'docs' }); else if (miss.length) out.push({ kind: 'missing', text: `${miss.map(t => F.PCP_LABEL[t]).join(', ')} not in the PCP's packet`, key: 'docs' }); }
  // outside H&P medication list vs ours (the one discrepancy the v1.2 seed carries for Mary)
  const outside = svRead<Record<string, { name: string; dose: string }[]>>('outside-hp-meds', {})[pid] || []; const resolved = svRead<Record<string, string>>('flow-resolved', {});
  outside.forEach(o => { if (resolved[`${pid}:${o.name}`]) return; const ours = medRepo.meds(pid).find(m => m.status === 'active' && norm(m.name).startsWith(norm(o.name.split(' ')[0])));
    if (!ours) out.push({ kind: 'discrepancy', text: `The outside H&P lists ${o.name} ${o.dose}; it is not on our medication list.`, key: `med:${o.name}` });
    else if (norm(ours.dose) !== norm(o.dose)) out.push({ kind: 'discrepancy', text: `The outside H&P lists ${o.name} ${o.dose}; our record says ${ours.dose}.`, key: `med:${o.name}` }); });
  return out;
}
export function resolveFlag(pid: string, key: string, choice: string, by: string, role: string) { const r = svRead<Record<string, string>>('flow-resolved', {}); r[`${pid}:${key.replace(/^med:/, '')}`] = choice; svWrite('flow-resolved', r); logFlow(pid, 6, `Discrepancy resolved (${key.replace(/^med:/, '')}): ${choice}`, by, role); }

/* ---------------- Undecided / resume ---------------- */
export function markUndecided(pid: string, reason: string, by: string, role: string) { setFlowState(pid, s => ({ ...s, undecided: { at: new Date().toISOString(), by, reason }, resumed: undefined })); logFlow(pid, 4, `Consultation Performed — Undecided${reason ? ` (${reason})` : ''}. Workflow stopped.`, by, role); }
export function resumeFlow(pid: string, by: string, role: string) { setFlowState(pid, s => ({ ...s, resumed: { at: new Date().toISOString(), by } })); logFlow(pid, 5, 'Patient called back: workflow resumed at Step 5 (Steps 1–4 on file)', by, role); }
export function keepUndecided(pid: string, by: string, role: string) { logFlow(pid, 4, 'Kept as Consultation Performed — Undecided', by, role); }
export const isUndecided = (pid: string) => { const s = flowState(pid); return !!s.undecided && !s.resumed; };

/* ---------------- every patient gets a journey (v1.2 engine underneath) ---------------- */
export function ensureAllJourneys(by = 'Vityls', role = 'System') {
  if (svRead<boolean>('flow-journeys-v13', false)) return 0; let n = 0;
  medRepo.patients().forEach(p => { if (journeysFor(p.id).length) return; const vs = medRepo.visits(p.id).sort((a, b) => a.createdAt.localeCompare(b.createdAt)); const v = vs.find(x => !POSTOP.test(x.visitType)) || vs[0];
    const at = v?.createdAt || new Date().toISOString(); const ep = activeEpisode(p.id);
    try { startJourney(p, { service: ep?.procedure || v?.reason || v?.visitType || 'Consultation', episodeId: ep?.id, surgeryDate: ep?.surgeryDate }, by, role, at); setFlowState(p.id, s => ({ ...s, since: s.since ?? '' })); syncJourney(p.id); n++; } catch (e) { console.warn('journey for', p.id, e); } });
  svWrite('flow-journeys-v13', true); return n;
}
/** The v1.2 journey step shown under the hood (for Henry / the timeline), mapped to the 7 steps. */
export const journeyStep7 = (pid: string): F.FStep | undefined => { const j = journeyFor(pid); return j ? F.fromJourneyStep(j.current) : undefined; };

/* ---------------- v1.5 · To-do: every unfinished task, per patient and across patients ---------------- */
export interface Todo { pid: string; name: string; item: F.FlowItem; caseId: string; caseTitle: string }
/** Did the surgeon suggest surgery? (scribe suggestion or a checkout booking to-do, or a quote on file) */
export function surgerySuggested(pid: string): boolean {
  if (F.FLOW_MED) return false;
  const v = consultVisit(pid); if (!v) return false; const sc = scribeSession(v.id);
  return sc.suggestions.some(x => x.kind === 'surgery-booking' && x.status !== 'dismissed') || checkoutOrders(v.id).some(o => o.kind === 'surgery-booking' && o.status !== 'cancelled') || quotesFor(pid).length > 0;
}
/** The patient's To-do list (chart + Today). Nightingale keeps it; nothing on it blocks any workspace. */
export function patientTodos(pid: string, today = isoDay(), caseId?: string): F.FlowItem[] {
  const f = factsFor(pid, today, caseId); const fl = F.deriveFlow(f); const out = F.openTodos(fl, f, { surgerySuggested: surgerySuggested(pid) });
  if (F.FLOW_MED) { const cv = consultVisit(pid); out.forEach(i => { i.why ||= cv ? `${cv.visitType} · ${cv.time}` : 'Visit'; });
    checkoutOrders().filter(o => o.patientId === pid && o.status === 'to-do' && o.kind !== 'surgery-booking' && o.kind !== 'clearance').forEach(o => out.push(medOrderTodo(o))); return out; }
  checkoutOrders().filter(o => o.patientId === pid && o.status === 'to-do' && (!caseId || caseOfVisit(medRepo.visit(o.visitId)) === caseId)).forEach(o => { const v = medRepo.visit(o.visitId); out.push({ key: `order:${o.id}`, step: v && POSTOP.test(v.visitType) ? 7 : 4, label: `Checkout: ${o.text}`, status: 'incomplete', action: 'checkout', why: o.source }); });
  return out;
}
/** v1.6 #4: one list per open case (several open cases run independently); a patient with no open case has a patient-level list. */
export interface CaseTodoList { caseId: string; caseTitle: string; kind: string; items: F.FlowItem[] }
export function caseTodoLists(pid: string, today = isoDay()): CaseTodoList[] {
  if (F.FLOW_MED) { const items = patientTodos(pid, today); return items.length ? [{ caseId: GENERAL, caseTitle: 'Visits', kind: 'general', items }] : []; }
  const open = casesFor(pid, today).filter(c => c.status !== 'closed' && c.kind !== 'general'); const out: CaseTodoList[] = [];
  open.forEach(c => {
    if (c.kind === 'office-procedure') { const q = quickSteps(quickFacts(c)).filter(s => !s.done && s.key !== 'closed');
      out.push({ caseId: c.id, caseTitle: caseTitle(c), kind: c.kind, items: q.map(s => ({ key: `quick:${c.id}:${s.key}`, step: s.key === 'paid' ? 4 : s.key === 'procedure' ? 4 : 2, label: s.label, status: 'incomplete', action: s.key === 'paid' ? 'checkout' : s.key === 'procedure' ? 'doctor' : 'front', why: 'Office procedure (quick case)' } as any)) }); return; }
    out.push({ caseId: c.id, caseTitle: caseTitle(c), kind: c.kind, items: patientTodos(pid, today, c.id) });
  });
  if (!open.some(c => c.kind === 'surgical')) { const items = patientTodos(pid, today); const gen = open.length ? items.filter(i => !/^order:/.test(i.key) || caseOfVisit(medRepo.visit(i.key.slice(6))) === GENERAL) : items; if (gen.length) out.push({ caseId: GENERAL, caseTitle: 'General', kind: 'general', items: gen }); }
  return out.filter(l => l.items.length);
}
export function todos(today = isoDay()): Todo[] {
  const out: Todo[] = [];
  medRepo.patients().forEach(p => { caseTodoLists(p.id, today).forEach(l => l.items.forEach(i => out.push({ pid: p.id, name: p.name, item: i, caseId: l.caseId, caseTitle: l.caseTitle }))); });
  return out.sort((a, b) => (a.item.due || '9').localeCompare(b.item.due || '9'));
}
/** v1.6 #1: a case opens when the doctor suggests a procedure (Nightingale names it from the suggestion or the quote). */
export function autoOpenSuggested(today = isoDay()) {
  medRepo.patients().forEach(p => { const cs = casesFor(p.id, today); if (cs.some(c => c.kind === 'surgical' && c.status !== 'closed')) return;
    const v = consultVisit(p.id); if (!v || !surgerySuggested(p.id)) return; const vc = caseOfVisit(v); if (vc !== GENERAL) return;
    const lastClosed = cs.filter(c => c.closedAt).map(c => c.closedAt!.slice(0, 10)).sort().pop(); if (lastClosed && v.date <= lastClosed) return;
    const sc = scribeSession(v.id); const sug = sc.suggestions.find(x => x.kind === 'surgery-booking' && x.status !== 'dismissed') as any; const q = quotesFor(p.id)[0];
    const proc = (q && curQuote(q).procedure) || sug?.procedure || sug?.text?.replace(/^.*?:\s*/, '') || 'Surgery (procedure to be named)';
    const c = openCase(p.id, { procedure: String(proc).slice(0, 60), kind: 'surgical', source: 'doctor-suggested', openedAt: new Date().toISOString() }, 'Nightingale', 'Assistant');
    linkTo('visit', v.id, p.id, c.id, 'Nightingale', 'Assistant', 'nightingale');
    quotesFor(p.id).forEach(x => { if (caseOf('quote', x.id) === GENERAL) linkTo('quote', x.id, p.id, c.id, 'Nightingale', 'Assistant', 'nightingale'); });
    patientPayments(p.id).filter(x => x.at.slice(0, 10) >= v.date).forEach(x => { if (caseOf('payment', x.id) === GENERAL) linkTo('payment', x.id, p.id, c.id, 'Nightingale', 'Assistant', 'nightingale'); }); });
}
/** Medical v2.0: Nightingale's medical to-dos from checkout orders: follow-ups (front office), referrals (nursing / coordinator),
 *  refills drafted for the doctor's review (never sent or ordered by Nightingale). */
export function medOrderTodo(o: { id: string; kind: string; text: string; source: string }): F.FlowItem {
  if (/^refill/i.test(o.text)) return { key: `refill:${o.id}`, step: 4, label: `Refill drafted: ${o.text.replace(/^refill( request)?:?\s*/i, '')} — review`, status: 'incomplete', action: 'checkout', why: 'Nightingale drafted it; only the doctor approves' };
  if (/referr/i.test(o.text)) return { key: `referral:${o.id}`, step: 5, label: `Referral to send: ${o.text.replace(/^referral:?\s*/i, '')}`, status: 'incomplete', action: 'checkout', why: o.source };
  return { key: `order:${o.id}`, step: 5, label: o.kind === 'follow-up' ? `Follow-up to book: ${o.text}` : `Checkout: ${o.text}`, status: 'incomplete', action: 'checkout', why: o.source };
}
export function syncAll() { if (F.FLOW_MED) return; try { syncCases(); autoOpenSuggested(); syncCases(); } catch (e) { console.warn('cases sync', e); } }
export const postedChecks = (pid: string) => flowState(pid).checks || [];
export function postCheck(pid: string, text: string) { setFlowState(pid, s => ({ ...s, checks: [...(s.checks || []), { at: new Date().toISOString(), text }].slice(-12) })); }
export const practiceAsc = () => getSettings().ascName || 'the ASC';
void addDays; void J; void EL;
