/* Surgery.Vityls v1.3 · the REAL workspaces behind the chat cards. Each chip on the flow page opens one of these in a large
   slide-over (the Doctor workspace is full screen). They reuse the existing station components, so nothing is a mock popup:
   Front desk (portal forms with blanks/mismatches highlighted, ID + insurance cards, Arrived / Start video visit, Collect payment),
   Nurse (the full nurse station), Doctor (scribe + note, body charts, photos, price quote, plan + Nightingale rail), Book & clear
   (quote accepted, deposit, case booking, clearance, PCP letter), ASC (documents, discrepancies, Send to ASC, confirm), Post-op.
   Closing a workspace posts a check to the chat for every item that turned Done (FlowPage.close). Everything external is simulated. */
import React, { useEffect, useRef, useState } from 'react';
import { X } from 'lucide-react';
import { medRepo, MedPatient, MedVisit, isoDay, addDays, uid } from '../../med/record';
import { useActor, useMedTick } from '../../med/ui';
import { useSv } from '../ui';
import { nurseAdmission } from '../store';
import { FormPage } from '../../v6/FormPage';
import { NurseStep, SurgeonStep, StationVerify, IdentityCheck, CheckInTimes, IntakeStep } from '../SurgeryStation';
import { FdStationForms } from '../fd/StationForms';
import { runWsSavers } from './wsSave';
import { CheckoutWs, RecordWs, PacketUpload, PostopNote } from '../v15/ws15';
import { CaseChip } from '../v16/cases';
import { CardsPanel } from '../v12/CardsUi';
import { cardStatus } from '../v12/cards';
import { CollectPayment, patientPayments } from '../payments';
import { BodyChartsSection, PhotoGate, PhotoGallery, photosOf, bodyCharts } from '../media';
import { QuoteList, NewQuoteButton, quotesFor, quoteStatus, setQuoteStatus, cur as curQuote, money } from '../quotes';
import { FormsPrompt, formsPackets } from '../newPatient';
import { activeEpisode, startEpisode, mutate as mutateEp, episodeSettings } from '../episodes/store';
import * as EL from '../episodes/logic';
import { journeyFor, linkEpisode, sendToAsc, ascConfirmed, receiveClearance, mutateJ, who, SJourney } from '../journey/store';
import * as J from '../journey/logic';
import { draftFor, drName } from '../journey/coordinator';
import { addDoc, docsOf, AddDocumentDialog } from '../documents';
import { getSettings } from '../../med/settings';
import * as F from './logic';
import { clearanceTests, flowFor, flagsFor, formReviews, FormReview, consultVisit, setFlowState, flowState, logFlow, markUndecided, resolveFlag, practiceAsc } from './store';
import { modeOf, modeLabel, startLabel, ModeIcon } from './apptMode';
import { AddedFormsSection } from '../v14/addForm';
import { ClearanceSection, syncClearanceToEpisode } from '../v14/clearance';
import { startRemoteVisit } from './remote';
import { QuickJot } from '../v17/ui';
import { OfficeStation } from '../office11/stations';

export type WsId = 'schedule' | 'front' | 'nurse' | 'doctor' | 'book' | 'asc' | 'postop' | 'checkout' | 'record';
export const WS_TITLE: Record<WsId, string> = { schedule: 'Scheduling', front: 'Front desk workspace', nurse: 'Nurse station', doctor: 'Doctor workspace', book: 'Booking & clearance', asc: 'ASC workspace', postop: 'Post-op', checkout: 'Checkout', record: 'Visit record' };
/** v1.5 B: the one entry point for a visit (Today chips, Continue, appointment panel, chart, chat): which workspace opens. */
export function wsForVisit(v: MedVisit, want?: string): WsId {
  const m: Record<string, WsId> = { intake: 'schedule', 'check-in': 'front', scheduled: 'front', rooming: 'nurse', provider: 'doctor', media: 'doctor', checkout: 'checkout', record: 'record', complete: 'record' };
  if (want && m[want]) return m[want];
  if (/post-?op/i.test(v.visitType)) return v.step === 'scheduled' || v.step === 'check-in' ? 'front' : 'postop';
  return m[v.step] || 'front';
}
export function wsFor(a: F.FAction): WsId {
  switch (a) { case 'book': case 'forms': return 'schedule'; case 'registration': case 'payment': return 'front'; case 'nurse': return 'nurse';
    case 'doctor': case 'doctor-photos': case 'doctor-charts': case 'doctor-note': case 'doctor-quote': return 'doctor';
    case 'quote-accept': case 'deposit': case 'book-case': case 'clearance': case 'pcp-letter': return 'book';
    case 'docs': case 'send-asc': case 'asc-confirm': return 'asc'; case 'checkout': return 'checkout'; default: return 'postop'; }
}
const d5 = (iso?: string) => iso ? new Date(iso.length <= 10 ? `${iso}T12:00:00` : iso).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) : '';
const tm = (iso?: string) => iso ? new Date(iso).toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' }) : '';
const visitFor = (pid: string, vid?: string): MedVisit | undefined => (vid && medRepo.visit(vid)) || medRepo.visits(pid).find(x => x.date === isoDay() && !/post-?op/i.test(x.visitType)) || consultVisit(pid);
const Done: React.FC<{ it?: F.FlowItem }> = ({ it }) => it?.status === 'done' ? <span className="flp-done" data-testid="ws-item-done">✓ Done{it.by ? ` · ${it.by}` : ''}{it.at ? ` · ${d5(it.at)}` : ''}</span> : it ? <span className={`st ${({ incomplete: 'inc', due: 'due', overdue: 'ovd', done: 'ok' } as any)[it.status]}`}>{F.STATUS_LABEL[it.status]}{it.due ? ` · due ${d5(it.due)}` : ''}</span> : null;

export const Workspace: React.FC<{ id: WsId; pid: string; vid?: string; focus?: string; edit?: F.FStep; onClose: () => void }> = ({ id, pid, vid, focus, edit, onClose }) => {
  useMedTick(); const p = medRepo.patient(pid)!; const v = visitFor(pid, vid); const full = id === 'doctor';
  /* v1.5 #1: Save & close is the only way out. It saves whatever was typed (registered savers), then closes. Esc and the scrim do the same. */
  const saveClose = () => { runWsSavers(); onClose(); }; const ref = useRef(saveClose); ref.current = saveClose;
  useEffect(() => { const k = (e: KeyboardEvent) => { if (e.key === 'Escape' && !document.querySelector('[role="dialog"] [role="dialog"], .sv-modal')) ref.current(); }; window.addEventListener('keydown', k); return () => window.removeEventListener('keydown', k); }, []);
  if (!p) return null;
  /* v11: Check-in, Nurse / MA, Doctor and Checkout run on the Vityls OS station engine (same design as ASC). */
  if (v && (id === 'front' || id === 'nurse' || id === 'doctor' || id === 'checkout')) return <OfficeStation ws={id} vid={v.id} onClose={saveClose} />;
  const pv = id === 'postop' ? (vid ? medRepo.visit(vid) : undefined) : undefined;
  if (F.FLOW_MED && (id === 'book' || id === 'asc' || id === 'postop')) id = 'record';
  const body = id === 'schedule' ? <ScheduleWs p={p} v={v} /> : id === 'front' ? <FrontWs p={p} v={v} focus={focus} /> : id === 'nurse' ? <NurseWs p={p} v={v} /> : id === 'book' ? <BookWs p={p} focus={focus} /> : id === 'asc' ? <AscWs p={p} /> : id === 'postop' ? <PostopWs p={p} v={pv} /> : id === 'checkout' ? <CheckoutWs p={p} v={v} /> : id === 'record' ? <RecordWs p={p} v={v} /> : null;
  return <>
    <div className="flp-scrim" onClick={saveClose} />
    <section className={`flp${full ? ' full' : ''}`} role="dialog" aria-modal="true" aria-label={WS_TITLE[id]} data-testid={`ws-${id}`}>
      <header className="flp-h"><div><h2>{WS_TITLE[id]}{edit ? ` · editing Step ${edit}` : ''}</h2><div className="m">{p.name} · {p.dob} · {p.id}{v && id !== 'book' && id !== 'asc' ? <> · <ModeIcon mode={modeOf(v)} /> {modeLabel(modeOf(v))} · {v.visitType} {d5(v.date)} {v.time} <CaseChip v={v} compact /></> : ''}</div></div>
        <div className="r">{edit && <span className="und on">Changes are logged</span>}<button type="button" className="btn pri" onClick={saveClose} data-testid="ws-save">Save &amp; close</button></div></header>
      {id === 'doctor' ? <DoctorWs p={p} v={v} focus={focus} onClose={saveClose} /> : <div className="flp-b">{body}</div>}
    </section></>;
};

/* ---------------- 1 · Scheduling ---------------- */
const ScheduleWs: React.FC<{ p: MedPatient; v?: MedVisit }> = ({ p, v }) => { const { go } = useSv(); const [fp, setFp] = useState(() => !formsPackets(p.id).length); const fl = flowFor(p.id); const it = (k: string) => fl.items.find(i => i.key === k); const pk = formsPackets(p.id);
  return <>
    <div className="flp-sec" data-testid="ws-sched-visit"><h3>Appointment <Done it={it('booked')} /></h3>{v ? <p>{v.visitType} · {d5(v.date)} {v.time} · {v.provider} · <ModeIcon mode={modeOf(v)} label /></p> : <p>No visit booked.</p>}<button type="button" className="btn" onClick={() => go({ type: 'tab', tab: 'schedule' })} data-testid="ws-open-schedule">Open schedule</button></div>
    <div className="flp-sec" data-testid="ws-sched-forms"><h3>Admission &amp; registration forms <Done it={it('forms')} /></h3>{pk.length ? <p>Sent {d5(pk[pk.length - 1].sentAt)} by {pk[pk.length - 1].by} via {[pk[pk.length - 1].portal && 'Portal', pk[pk.length - 1].email && 'email', pk[pk.length - 1].text && 'text'].filter(Boolean).join(', ')} (simulated).</p> : null}<button type="button" className="btn pri" onClick={() => setFp(true)} data-testid="ws-send-forms">{pk.length ? 'Send forms again' : 'Send forms'}</button>{fp && <FormsPrompt p={p} onDone={() => setFp(false)} doneLabel="Done" />}</div>
    {v && <details className="flp-sec" data-testid="ws-sched-intake"><summary style={{ cursor: 'pointer' }}><b>Intake links · fill in the office · outbox</b></summary><div className="sv-station-body mt-2"><IntakeStep v={v} p={p} onNext={() => window.dispatchEvent(new CustomEvent('flow-open-ws', { detail: { id: 'front', pid: p.id, vid: v.id } }))} /></div></details>}</>; };

/* ---------------- 2 · Front desk ---------------- */
const FormView: React.FC<{ p: MedPatient; r: FormReview; onBack: () => void }> = ({ p, r, onBack }) => {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => { const keys = new Set(r.blankKeys); const mm = new Set(r.mismatches.map(m => m.label)); const mark = () => { const host = ref.current; if (!host) return; const roots: (Element | ShadowRoot)[] = [host, ...Array.from(host.querySelectorAll('*')).filter(e => e.shadowRoot).map(e => e.shadowRoot!)];
      roots.forEach(rt => { if (rt instanceof ShadowRoot && !rt.querySelector('style[data-flblank]')) { const st = document.createElement('style'); st.setAttribute('data-flblank', ''); st.textContent = '.fl-blank{outline:2px solid #e0a43a !important;outline-offset:1px;background:#fff6e8 !important}'; rt.appendChild(st); }
        rt.querySelectorAll<HTMLInputElement>('input,textarea,select').forEach(el => { const lab = el.closest('label, .field, div')?.querySelector('label')?.textContent?.trim() || ''; const unnamed = !el.name && !el.id; const empty = el.type !== 'checkbox' && el.type !== 'radio' && el.type !== 'hidden' && el.type !== 'button' && !el.disabled && !el.readOnly && !String(el.value || '').trim() && !/signature|initial|office use|staff/i.test(lab);
          el.classList.toggle('fl-blank', keys.has(el.name) || keys.has(el.id) || mm.has(lab) || (unnamed && empty)); }); });
      if (!(host as any).dataset.scrolled) { for (const rt of roots) { const f = rt.querySelector('.fl-blank'); if (f) { f.scrollIntoView({ block: 'center' }); (host as any).dataset.scrolled = '1'; break; } } } (host as any).dataset.blanks = String(roots.reduce((n, rt) => n + rt.querySelectorAll('.fl-blank').length, 0)); }; mark(); const i = setInterval(mark, 700); return () => clearInterval(i); }, [r]);
  const pc = { id: r.caseId, patientId: p.id, name: p.name, age: 0, gender: p.sex, dob: p.dob, phone: p.phone, email: p.email, scheduledTime: '', estimatedDurationMins: 0, room: '', surgeon: p.primaryProvider, procedure: 'New-patient forms', aiSummary: '', readinessScore: 0, readinessLevel: 'IN_PROGRESS', allergies: p.allergies, labs: [], stage: 'CHECK_IN', arrivalStatus: 'EN_ROUTE', arrivalTime: '' } as any;
  return <div data-testid="ws-form-view"><button type="button" className="btn sm" onClick={onBack} data-testid="ws-form-back">‹ All forms</button>
    {(r.blanks.length > 0 || r.mismatches.length > 0) && <div className="flp-sec flp-gapcard" data-testid="ws-form-gaps"><h3>Nightingale: check these with {p.name.split(' ')[0]}</h3>{r.blanks.map(b => <div key={b} className="flp-flag"><b>Blank:</b> {b}</div>)}{r.mismatches.map(m => <div key={m.label} className="flp-flag"><b>Differs from the chart:</b> {m.label}: form says “{m.form}”, chart says “{m.chart}”</div>)}<p className="flp-note">Outlined in the form. Fix them with the patient, or return to the front desk.</p><button type="button" className="btn sm" onClick={onBack} data-testid="ws-form-back2">‹ Back to the front desk</button></div>}
    <div className="flp-form" ref={ref}><FormPage patient={pc} form={{ title: r.title, file: r.file, category: 'Intake', stage: '' } as any} station="frontDesk" onClose={onBack} /></div></div>;
};
export type FrontPart = 'identity' | 'forms' | 'cards' | 'arrival' | 'pay' | 'stepforms';
export const FrontWs: React.FC<{ p: MedPatient; v?: MedVisit; focus?: string; part?: FrontPart }> = ({ p, v, focus, part }) => { const on = (k: FrontPart) => !part || part === k;
  const [actor] = useActor(); const { toast } = useSv(); const [form, setForm] = useState<FormReview | null>(null); const [pay, setPay] = useState(false); const [up, setUp] = useState(false); useEffect(() => { if (focus === 'payment') document.querySelector('[data-testid=ws-front-pay]')?.scrollIntoView({ block: 'start' }); }, [focus]);
  const fl = flowFor(p.id); const it = (k: string) => fl.items.find(i => i.key === k); const revs = formReviews(p.id, v); const cs = cardStatus(p.id);
  if (form) return <FormView p={p} r={formReviews(p.id, v).find(x => x.file === form.file) || form} onBack={() => setForm(null)} />;
  const facts = v ? (window as any).__noop || null : null; void facts; const remote = v && modeOf(v) !== 'office';
  const pays = patientPayments(p.id).slice(-3).reverse();
  return <>
    {v && on('identity') && <div className="flp-sec" data-testid="ws-front-identity"><h3>Confirm who the patient is</h3><IdentityCheck v={v} p={p} /></div>}
    {on('forms') && <div className="flp-sec" data-testid="ws-front-forms"><h3>Portal forms <Done it={it('registration')} /></h3><AddedFormsSection p={p} station="front" v={v} embed />
      {revs.length ? <table className="sv-table"><tbody>{revs.map(r => <tr key={r.file} data-testid={`ws-form-${r.file}`}><td><b>{r.title}</b><div className="flp-note">{r.status === 'complete' ? `Returned ${d5(r.at)}` : r.status === 'in-progress' ? 'Started, not submitted' : 'Not returned yet'}</div></td>
        <td>{r.blanks.length ? <span className="st inc">{r.blanks.length} blank</span> : null} {r.mismatches.length ? <span className="st ovd">{r.mismatches.length} mismatch</span> : null} {r.status === 'complete' && !r.blanks.length && !r.mismatches.length ? <span className="st ok">Done</span> : r.status !== 'complete' ? <span className="st inc">Incomplete</span> : null}</td>
        <td style={{ textAlign: 'right' }}><button type="button" className="btn sm" onClick={() => setForm(r)} data-testid="ws-form-open">Open form</button></td></tr>)}</tbody></table> : <p>No forms sent.</p>}
      {it('registration')?.status !== 'done' && <button type="button" className="btn sm mt-2" data-testid="ws-reg-accept" onClick={() => { setFlowState(p.id, s => ({ ...s, regAccepted: { at: new Date().toISOString(), by: actor.name } })); logFlow(p.id, 2, 'Registration reviewed and accepted at the front desk', actor.name, actor.role); toast('Registration complete'); }}>Registration reviewed with the patient · mark complete</button>}</div>}
    {on('cards') && <div className="flp-sec" data-testid="ws-front-cards"><h3>ID &amp; insurance cards {cs.missing.length ? <span className="st inc">{cs.missing.length} missing</span> : <span className="st ok">Done</span>}</h3><button type="button" className="btn sm v14-tr" onClick={() => setUp(true)} data-testid="ws-upload-docs">Upload documents</button><CardsPanel p={p} via="front desk" />
      <div className="v14-upl" data-testid="ws-front-upload"><span className="flp-note"><b>Upload documents</b> (top right): PCP notes, labs, imaging, outside records the patient brought in. Filed by type to the chart’s Documents folder.</span></div>
      {docsOf(p.id).filter(d => Date.now() - new Date(d.receivedAt).getTime() < 8 * 3600e3 && !d.example).map(d => <div key={d.id} className="flp-note" data-testid="ws-upload-item">✓ {d.type} · {d.title} · filed {tm(d.receivedAt)}</div>)}
      {up && <AddDocumentDialog p={p} onClose={() => setUp(false)} onDone={d => { setUp(false); logFlow(p.id, 2, `Document uploaded at the front desk: ${d.type} · ${d.title}`, actor.name, actor.role); toast(`${d.type} filed to Documents`); }} />}</div>}
    {v && on('arrival') && <div className="flp-sec" data-testid="ws-front-arrival"><h3>{remote ? `${modeLabel(modeOf(v))} · check-in` : 'Arrival & check-in'}</h3>
      {remote ? <p className="flp-note" data-testid="ws-front-remote-note">{modeLabel(modeOf(v))}: no arrival or rooming. The doctor starts the visit in the Doctor workspace.</p> : <CheckInTimes v={v} />}</div>}
    {on('pay') && fl.items.some(i => i.key === 'payment') && <div className="flp-sec" data-testid="ws-front-pay"><h3>Required payment <Done it={it('payment')} /></h3>
      {pays.map(x => <div key={x.id} className="flp-note" style={{ fontSize: 13 }}>{x.receipt} · ${x.amount} · {x.reason} · {d5(x.at)} · {x.takenBy}</div>)}
      <button type="button" className="btn pri mt-2" onClick={() => setPay(true)} data-testid="ws-collect">Collect payment</button>
      <p className="flp-note" data-testid="ws-pay-note">Simulated in this test build. In production, card capture uses the payment processor's hosted fields or the card terminal: card numbers never touch Vityls.</p></div>}
    {v && on('stepforms') && <div className="flp-sec" data-testid="ws-front-stepforms"><h3>Forms for this step</h3><FdStationForms v={v} station="frontOffice" step="check-in" /></div>}
    {v && !part && <StationVerify v={v} step="check-in" />}
    {pay && <CollectPayment p={p} onClose={() => setPay(false)} />}</>;
};
/* ---------------- 3 · Nurse ---------------- */
const NurseWs: React.FC<{ p: MedPatient; v?: MedVisit }> = ({ p, v }) => {
  if (!v) return <p>No visit to room.</p>; const fl = flowFor(p.id);
  return <><div className="flp-sec"><h3>Step 3 · {F.itemsOf(fl, 3).map(i => <span key={i.key} style={{ marginRight: 10, fontSize: 13, fontWeight: 400 }}>{i.label}: <Done it={i} /></span>)}</h3>
    {modeOf(v) !== 'office' && <p className="flp-note">Remote visit: no vitals in the room. Record the reason for the visit and any notes.</p>}</div>
    <AddedFormsSection p={p} station="nurse" v={v} />
    <div className="sv-station-body"><NurseStep v={v} p={p} /></div>
    <div className="flp-sec" data-testid="ws-nurse-stepforms"><h3>Forms for this step</h3><FdStationForms v={v} station="nursing" step="rooming" /></div>
    <StationVerify v={v} step="rooming" /></>;
};

/* ---------------- 4 · Doctor (full screen) ---------------- */
/** v11: one Doctor workspace section on its own, so the core station engine can host it as a step. */
export const DoctorPane: React.FC<{ p: MedPatient; v?: MedVisit; tab: 'scribe' | 'charts' | 'photos' | 'quote' | 'forms' | 'decision'; onMedia?: () => void; onClose?: () => void }> = ({ p, v, tab, onMedia, onClose }) => {
  useMedTick(); const [actor] = useActor(); const { toast } = useSv(); const [reason, setReason] = useState('Wants to think it over'); const fl = flowFor(p.id);
  if (!v && tab !== 'quote' && tab !== 'decision') return <p>No {F.FLOW_MED ? 'visit' : 'consultation visit'} on file.</p>;
  return <>
    {tab === 'scribe' && v && <>{modeOf(v) !== 'office' && <div className="flp-sec" data-testid="doc-remote">{v.step === 'scheduled' ? <><button type="button" className="btn pri" data-testid="ws-start-remote" onClick={() => { startRemoteVisit(v, actor.name, actor.role); toast(`${startLabel(modeOf(v))}: started (simulated)`); }}>{startLabel(modeOf(v))}</button><span className="flp-note"> The visit link / call is simulated in this build.</span></> : <span className="flp-done">✓ {modeLabel(modeOf(v))} started</span>}</div>}
      <div style={{ marginBottom: 8 }}><QuickJot vid={v.id} /></div><div className="sv-station-body"><SurgeonStep v={v} p={p} onMedia={onMedia || (() => undefined)} /></div></>}
    {tab === 'charts' && v && <BodyChartsSection p={p} visitId={v.id} />}
    {tab === 'photos' && v && <PhotoGate p={p} where="station"><PhotoGallery p={p} visitId={v.id} /></PhotoGate>}
    {tab === 'quote' && <div data-testid="doc-quote"><div className="flex gap-2 mb-3"><NewQuoteButton p={p} className="btn pri" label="New price quote" testId="doc-new-quote" /></div><QuoteList p={p} /></div>}
    {tab === 'forms' && <><AddedFormsSection p={p} station="doctor" v={v} />{v && <div className="flp-sec" data-testid="doc-stepforms"><h3>Forms for this step</h3><FdStationForms v={v} station="surgeon" step="provider" /></div>}</>}
    {tab === 'decision' && <div className="flp-sec" data-testid="doc-decision"><h3>Patient decision</h3>
      {fl.undecided ? <p>Consultation Performed — <b>Undecided</b>{flowState(p.id).undecided?.reason ? ` (${flowState(p.id).undecided!.reason})` : ''}. The workflow is stopped.</p> : <>
        <p>If the patient has decided, Nightingale adds the booking tasks (quote accepted, deposit, booking, clearance) to the patient’s To-do. If not, mark the consultation undecided.</p>
        <div className="g"><div><label htmlFor="und-r">Reason (optional)</label><select id="und-r" value={reason} onChange={e => setReason(e.target.value)} data-testid="doc-und-reason">{['Wants to think it over', 'Second opinion', 'Cost / financing', 'Timing', 'Other'].map(x => <option key={x}>{x}</option>)}</select></div></div>
        <button type="button" className="btn mt-3" data-testid="doc-undecided" onClick={() => { markUndecided(p.id, reason.toLowerCase(), actor.name, actor.role); toast('Consultation Performed — Undecided. Workflow stopped.'); onClose?.(); }}>Consultation Performed — Undecided</button></>}</div>}
  </>;
};
type DTab = 'scribe' | 'charts' | 'photos' | 'quote' | 'forms' | 'plan';
const DoctorWs: React.FC<{ p: MedPatient; v?: MedVisit; focus?: string; onClose: () => void }> = ({ p, v, focus, onClose }) => {
  const [actor] = useActor(); const { toast } = useSv();
  const [tab, setTab] = useState<DTab>(focus === 'body-chart' ? 'charts' : focus === 'photos' ? 'photos' : focus === 'quote' ? 'quote' : focus === 'undecided' ? 'plan' : 'scribe');
  const [reason, setReason] = useState('Wants to think it over'); const fl = flowFor(p.id); const it = (k: string) => fl.items.find(i => i.key === k);
  const TABS: [DTab, string, string?][] = [['scribe', F.FLOW_MED ? 'Scribe & visit note' : 'Scribe & consult note', 'note'], ...(modeOf(v) !== 'phone' ? [['charts', 'Body charts', 'body-chart'], ['photos', F.FLOW_MED ? 'Clinical photos' : 'Pre-op photos', 'photos']] as [DTab, string, string][] : []), ...(F.FLOW_MED ? [] : [['quote', 'Price quote', 'quote']] as [DTab, string, string][]), ['forms', 'Forms'], ...(F.FLOW_MED ? [] : [['plan', 'Plan & decision']] as [DTab, string][])];
  const vit = medRepo.vitals(p.id).slice(-1)[0]; const na = v ? nurseAdmission(v.id) : undefined; const meds = medRepo.meds(p.id).filter(m => m.status === 'active'); const probs = medRepo.problems(p.id).filter((x: any) => x.status !== 'resolved');
  const flags = flagsFor(p.id, fl); const qs = quotesFor(p.id);
  return <div className="flp-doc">
    <div style={{ display: 'flex', flexDirection: 'column', minHeight: 0 }}>
      {v && <div style={{ padding: '10px 20px 0' }}><QuickJot vid={v.id} /></div>}
      <nav className="flp-tabs" role="tablist" data-testid="doc-tabs">{TABS.map(([k, l, key]) => <button type="button" role="tab" key={k} aria-selected={tab === k} className={tab === k ? 'on' : ''} onClick={() => setTab(k)} data-testid={`doc-tab-${k}`}>{l}{key && it(key)?.status === 'done' ? ' ✓' : ''}</button>)}</nav>
      <div className="main" data-testid={`doc-pane-${tab}`}>
        {v && modeOf(v) !== 'office' && <div className="flp-sec" data-testid="doc-remote">{v.step === 'scheduled' ? <><button type="button" className="btn pri" data-testid="ws-start-remote" onClick={() => { startRemoteVisit(v, actor.name, actor.role); toast(`${startLabel(modeOf(v))}: started (simulated)`); }}>{startLabel(modeOf(v))}</button><span className="flp-note"> The visit link / call is simulated in this build.</span></> : <span className="flp-done">✓ {modeLabel(modeOf(v))} started</span>}</div>}
        {!v && tab !== 'quote' && tab !== 'plan' ? <p>No {F.FLOW_MED ? 'visit' : 'consultation visit'} on file.</p> : null}
        {v && tab === 'scribe' && <div className="sv-station-body"><SurgeonStep v={v} p={p} onMedia={() => setTab('charts')} /></div>}
        {v && tab === 'charts' && <BodyChartsSection p={p} visitId={v.id} />}
        {v && tab === 'photos' && <PhotoGate p={p} where="station"><PhotoGallery p={p} visitId={v.id} /></PhotoGate>}
        {tab === 'quote' && <div data-testid="doc-quote"><div className="flex gap-2 mb-3"><NewQuoteButton p={p} className="btn pri" label="New price quote" testId="doc-new-quote" /></div><QuoteList p={p} /></div>}
        {tab === 'forms' && <><AddedFormsSection p={p} station="doctor" v={v} />{v && <div className="flp-sec" data-testid="doc-stepforms"><h3>Forms for this step</h3><FdStationForms v={v} station="surgeon" step="provider" /></div>}</>}
        {tab === 'plan' && <div data-testid="doc-plan">
          <div className="flp-sec"><h3>Consult summary</h3>{F.itemsOf(fl, 4).map(i => <div key={i.key} style={{ display: 'flex', gap: 10, padding: '6px 0', borderTop: '1px solid #f0e6da' }}><span style={{ flex: 1 }}>{i.label}</span><Done it={i} /></div>)}</div>
          {v && <StationVerify v={v} step="provider" />}
          <div className="flp-sec" data-testid="doc-decision"><h3>Patient decision</h3>
            {fl.undecided ? <p>Consultation Performed — <b>Undecided</b>{flowState(p.id).undecided?.reason ? ` (${flowState(p.id).undecided!.reason})` : ''}. The workflow is stopped.</p> : <>
              <p>If the patient has decided, Nightingale adds the booking tasks (quote accepted, deposit, booking, clearance) to the patient’s To-do. If not, mark the consultation undecided.</p>
              <div className="g"><div><label htmlFor="und-r">Reason (optional)</label><select id="und-r" value={reason} onChange={e => setReason(e.target.value)} data-testid="doc-und-reason">{['Wants to think it over', 'Second opinion', 'Cost / financing', 'Timing', 'Other'].map(x => <option key={x}>{x}</option>)}</select></div></div>
              <button type="button" className="btn mt-3" data-testid="doc-undecided" onClick={() => { markUndecided(p.id, reason.toLowerCase(), actor.name, actor.role); toast('Consultation Performed — Undecided. Workflow stopped.'); onClose(); }}>Consultation Performed — Undecided</button></>}</div></div>}
      </div>
    </div>
    <aside className="rail flp-rail" aria-label="Nightingale" data-testid="doc-rail">
      <h4>Nightingale</h4>
      {(() => { const nx = F.itemsOf(fl, 4).find(i => i.status !== 'done'); return <div className="bub" style={{ fontSize: 13.5 }} data-testid="doc-rail-next">{nx ? <>Next: <b>{nx.label}</b>.</> : <>{F.FLOW_MED ? 'Visit complete. Follow-ups are on the patient’s To-do.' : 'Consult complete. Booking tasks are on the patient’s To-do.'}</>}</div>; })()}
      {flags.map((f, i) => <div key={i} className="flp-flag">{f.text}</div>)}
      <h4>Nurse intake</h4>{na ? <><div className="row">Reason: {na.chiefComplaint || '—'}</div><div className="row">Pain {na.pain || '—'}/10{na.medsReviewed ? ' · meds reviewed' : ''}</div>{na.nurseNote && <div className="row">{na.nurseNote}</div>}</> : <div className="row">Not roomed yet.</div>}
      <h4>Vitals</h4>{vit ? <div className="row" data-testid="doc-rail-vitals">BP {vit.bpSys}/{vit.bpDia} · HR {vit.hr} · RR {vit.rr ?? <b style={{ color: '#a2492f' }}>missing</b>} · SpO₂ {vit.spo2}%{vit.weightLb ? ` · ${vit.weightLb} lb` : ''}</div> : <div className="row">None recorded.</div>}
      <h4>Allergies</h4><div className="row">{p.allergies.length ? p.allergies.join(', ') : 'No known allergies'}</div>
      <h4>Medications</h4>{meds.length ? meds.map(m => <div key={m.id} className="row">{m.name} {m.dose} {m.frequency}</div>) : <div className="row">None</div>}
      <h4>Problems</h4>{probs.length ? probs.map((x: any) => <div key={x.id} className="row">{x.description}</div>) : <div className="row">None</div>}
      <h4>Media</h4><div className="row">{photosOf(p.id).length} photos · {bodyCharts(p.id).length} body charts</div>
      {!F.FLOW_MED && <><h4>Quotes</h4>{qs.length ? qs.slice(0, 3).map(q => <div key={q.id} className="row">{q.number} · {curQuote(q).procedure} · {money(curQuote(q).total)} · {quoteStatus(q)}</div>) : <div className="row">None yet</div>}</>}
    </aside>
  </div>;
};

/* ---------------- 5 · Book the case & clearance ---------------- */
const BookWs: React.FC<{ p: MedPatient; focus?: string }> = ({ p, focus }) => {
  useMedTick(); const [actor] = useActor(); const { toast } = useSv(); const fl = flowFor(p.id); const it = (k: string) => fl.items.find(i => i.key === k);
  const ep = activeEpisode(p.id); const qs = quotesFor(p.id); const acc = qs.find(q => quoteStatus(q) === 'Accepted') || qs[0]; const total = ep?.totalAmount || (acc ? curQuote(acc).total : 0);
  const sd = flowState(p.id).deposit; const pct = (episodeSettings() as any).depositPct ?? 20;
  const [amt, setAmt] = useState(String(sd?.amount ?? ep?.depositAmount ?? Math.round(total * pct) / 100)); const [ddate, setDdate] = useState(sd?.date || addDays(isoDay(), 7));
  const [surg, setSurg] = useState(addDays(isoDay(), 35)); const [time, setTime] = useState('07:30 AM'); const [proc, setProc] = useState(acc ? curQuote(acc).procedure : '');
  const [pay, setPay] = useState(false); const j = journeyFor(p.id);
  const [letter, setLetter] = useState(() => { try { return j ? draftFor('s7-request', j as SJourney, p, actor.name).body : ''; } catch { return ''; } });
  const ref = useRef<Record<string, HTMLDivElement | null>>({}); useEffect(() => { const k = focus === 'quote-accepted' ? 'quote' : focus === 'case' ? 'case' : focus || ''; ref.current[k]?.scrollIntoView({ block: 'start' }); }, [focus]);
  const run = (f: () => void, msg: string) => { try { f(); toast(msg); } catch (e: any) { toast(e.message || String(e)); } };
  return <>
    <div className="flp-sec" ref={el => { ref.current.quote = el; }} data-testid="ws-book-quote"><h3>Quote accepted <Done it={it('quote-accepted')} /></h3>
      {qs.length ? qs.map(q => <div key={q.id} style={{ display: 'flex', gap: 10, alignItems: 'center', padding: '6px 0', borderTop: '1px solid #f0e6da' }}><span style={{ flex: 1 }}><b>{q.number}</b> · {curQuote(q).procedure} · {money(curQuote(q).total)} · valid until {d5(curQuote(q).validUntil)}</span><span className="st due">{quoteStatus(q)}</span>
        {quoteStatus(q) !== 'Accepted' && <button type="button" className="btn sm pri" data-testid="ws-quote-accept" onClick={() => run(() => { setQuoteStatus(q, 'Accepted', actor.name, actor.role); if (quoteStatus(q) === 'Expired') logFlow(p.id, 5, `Quote ${q.number} was expired; accepted as re-presented`, actor.name, actor.role); }, `Quote ${q.number} accepted`)}>Mark accepted</button>}</div>) : <p>No quote yet. <NewQuoteButton p={p} className="btn sm" label="New price quote" /></p>}
      <details className="mt-2"><summary className="flp-note" style={{ cursor: 'pointer' }}>Quote details</summary><QuoteList p={p} compact /></details></div>
    <div className="flp-sec" ref={el => { ref.current.deposit = el; }} data-testid="ws-book-deposit"><h3>Deposit <Done it={it('deposit')} /></h3>
      <div className="g"><div><label htmlFor="dep-a">Amount ($)</label><input id="dep-a" inputMode="decimal" value={amt} onChange={e => setAmt(e.target.value)} data-testid="ws-dep-amount" /></div><div><label htmlFor="dep-d">Due date</label><input id="dep-d" type="date" value={ddate} onChange={e => setDdate(e.target.value)} data-testid="ws-dep-date" /></div></div>
      <div className="flex gap-2 mt-3 flex-wrap"><button type="button" className="btn pri" data-testid="ws-dep-record" onClick={() => run(() => { const a = Number(amt) || 0; setFlowState(p.id, s => ({ ...s, deposit: { amount: a, date: ddate, at: new Date().toISOString(), by: actor.name } })); if (ep) mutateEp(ep.id, e => ({ ...e, depositAmount: a }), actor.name, actor.role, `deposit set to $${a}`); logFlow(p.id, 5, `Deposit recorded: $${a} due ${ddate}`, actor.name, actor.role); }, 'Deposit recorded')}>Record deposit</button>
        <button type="button" className="btn" onClick={() => setPay(true)} data-testid="ws-dep-collect">Collect deposit now</button></div>
      <p className="flp-note">Simulated. Real card capture uses the processor's hosted fields or the terminal; card data never touches Vityls.</p></div>
    <div className="flp-sec" ref={el => { ref.current.case = el; }} data-testid="ws-book-case"><h3>Case booked <Done it={it('case')} /></h3>
      {ep ? <p>{ep.procedure} · <b>{d5(ep.surgeryDate)}</b> {ep.surgeryTime} · {ep.ascName} · surgeon {ep.surgeon}</p> : <>
        <div className="g"><div><label htmlFor="bk-p">Procedure</label><input id="bk-p" value={proc} onChange={e => setProc(e.target.value)} data-testid="ws-case-proc" /></div><div><label htmlFor="bk-d">Surgery date</label><input id="bk-d" type="date" value={surg} onChange={e => setSurg(e.target.value)} data-testid="ws-case-date" /></div><div><label htmlFor="bk-t">Time</label><input id="bk-t" value={time} onChange={e => setTime(e.target.value)} data-testid="ws-case-time" /></div><div><label>ASC</label><input value={practiceAsc()} readOnly /></div></div>
        <button type="button" className="btn pri mt-3" disabled={!proc || !surg} data-testid="ws-case-book" onClick={() => run(() => { if (acc && quoteStatus(acc) !== 'Accepted') setQuoteStatus(acc, 'Accepted', actor.name, actor.role); let e = startEpisode(p, { procedure: proc, surgeryDate: surg, total: total || 0, quoteId: acc?.id, consultVisitId: consultVisit(p.id)?.id }, actor.name, actor.role);
          e = mutateEp(e.id, x => ({ ...x, surgeryTime: time, depositAmount: sd?.amount ?? x.depositAmount }), actor.name, actor.role, `surgery time ${time}`); linkEpisode(p.id, e, actor.name, actor.role); syncClearanceToEpisode(p.id, actor.name, actor.role); logFlow(p.id, 5, `Case booked: ${proc} on ${surg} ${time}`, actor.name, actor.role); }, 'Case booked')}>Book case</button></>}</div>
    <ClearanceSection p={p} it={it} Done={Done} refs={k => el => { ref.current[k] = el; }} />
    <AddedFormsSection p={p} station="book" v={consultVisit(p.id)} />
    {pay && <CollectPayment p={p} onClose={() => { setPay(false); const last = patientPayments(p.id).slice(-1)[0]; const e = activeEpisode(p.id); if (last && e && Date.now() - new Date(last.at).getTime() < 120000 && !e.history.some(h => h.what.includes(last.receipt))) mutateEp(e.id, x => { const y = EL.applyPayment(x, last.amount, actor.name, last.at); return { ...y, history: [...y.history, { at: last.at, by: actor.name, what: `Receipt ${last.receipt} applied to the deposit` }] }; }, actor.name, actor.role, 'deposit collected'); }} />}</>;
};

/* ---------------- 6 · ASC ---------------- */
const AscWs: React.FC<{ p: MedPatient }> = ({ p }) => {
  useMedTick(); const [actor] = useActor(); const { toast } = useSv(); const fl = flowFor(p.id); const it = (k: string) => fl.items.find(i => i.key === k); const ep = activeEpisode(p.id);
  const flags = flagsFor(p.id, fl).filter(f => f.kind === 'discrepancy'); const docs = docsOf(p.id); const [time, setTime] = useState(ep?.surgeryTime || '07:30 AM');
  const pk = (flowState(p.id) as any).packet; const rec = (t: string) => pk ? pk.items[t] === 'received' : t === 'H&P' ? !!journeyFor(p.id)?.items.find(i => i.key === 's7-t-H&P' && i.status === 'done') : ep?.clearance.tests[t] === 'received';
  const clrReq = ep ? ep.clearance.required : !!flowState(p.id).clearance?.required;
  return <>
    {!ep && <div className="flp-sec" data-testid="ws-asc-nocase"><p className="flp-note">No case is booked yet. You can still work here: upload the clearance packet now; sending to the ASC uses the case details once it is booked in Booking &amp; clearance. Nightingale tracks what is left on the To-do.</p></div>}
    {(clrReq || !ep) && <PacketUpload p={p} />}
    {flags.length > 0 && <div className="flp-sec" data-testid="ws-asc-flags"><h3>Discrepancies</h3>{flags.map((f, i) => <div key={i} className="flp-flag">{f.text}<div className="flex gap-2 mt-2"><button type="button" className="btn sm" data-testid="ws-flag-ours" onClick={() => { resolveFlag(p.id, f.key!, 'our record is correct (outside H&P outdated)', actor.name, actor.role); toast('Resolved'); }}>Our record is correct</button><button type="button" className="btn sm" data-testid="ws-flag-update" onClick={() => { resolveFlag(p.id, f.key!, 'confirmed with patient; to update at pre-op call', actor.name, actor.role); toast('Resolved · confirm the dose with the patient at the pre-op call'); }}>Confirm with patient</button></div></div>)}</div>}
    {ep && <><div className="flp-sec" data-testid="ws-asc-send"><h3>Send to {ep.ascName.replace(/\s*\(fictional\)/, '')} <Done it={it('asc-sent')} /></h3><p>{docs.length} documents on file. {clearanceTests(p.id).filter(t => ep.clearance.required && !rec(t)).length ? <b>Some clearance items are still missing.</b> : 'Package ready.'}</p>
      <button type="button" className="btn pri" data-testid="ws-asc-sendbtn" onClick={() => { sendToAsc(p.id, actor.name, actor.role, docs.length); logFlow(p.id, 6, 'Documents sent to the ASC (simulated)', actor.name, actor.role); toast('Sent to the ASC (simulated)'); setTimeout(() => { ascConfirmed(p.id, `Package received for ${p.name}, ${d5(ep.surgeryDate)} ${ep.surgeryTime}. (simulated reply)`); window.dispatchEvent(new Event('vityls-med-updated')); }, 1800); }}>{ep.asc.sentAt ? 'Send again' : 'Send to ASC'}</button></div>
    <div className="flp-sec" data-testid="ws-asc-confirm"><h3>Surgery date &amp; time confirmed <Done it={it('asc-confirmed')} /></h3><p>{d5(ep.surgeryDate)} · arrival time:</p><div className="g"><div><input value={time} onChange={e => setTime(e.target.value)} data-testid="ws-asc-time" aria-label="Surgery time" /></div></div>
      <button type="button" className="btn mt-2" data-testid="ws-asc-confirmbtn" onClick={() => { mutateEp(ep.id, x => EL.setItem({ ...x, surgeryTime: time, asc: { ...x.asc, confirmedAt: new Date().toISOString(), missing: [] } }, 'asc-confirm', 'done', actor.name, new Date().toISOString(), `confirmed ${time} by phone`), actor.name, actor.role, `ASC confirmed ${time}`); logFlow(p.id, 6, `ASC confirmed ${d5(ep.surgeryDate)} ${time}`, actor.name, actor.role); toast('Confirmed'); }}>ASC confirmed by phone</button></div></>}
    <AddedFormsSection p={p} station="asc" v={consultVisit(p.id)} /></>;
};

/* ---------------- 7 · Post-op ---------------- */
const PostopWs: React.FC<{ p: MedPatient; v?: MedVisit }> = ({ p, v: pv }) => { const un = (x: MedVisit) => medRepo.note(x.id)?.status !== 'signed'; const [actor] = useActor(); const { toast, go } = useSv(); const ep = activeEpisode(p.id); const vs = medRepo.visits(p.id).filter(x => /post-?op/i.test(x.visitType)).sort((a, b) => a.date.localeCompare(b.date));
  return <div className="flp-sec" data-testid="ws-postop"><h3>Post-op visits</h3>{ep && <p className="flp-note">Surgery {d5(ep.surgeryDate)}. Routine visits: reminders and confirmations only.</p>}
    {vs.length ? vs.map(v => <div key={v.id} style={{ display: 'flex', gap: 10, alignItems: 'center', padding: '6px 0', borderTop: '1px solid #f0e6da' }}><span style={{ flex: 1 }}>{v.visitType} · {d5(v.date)} {v.time}</span>
      <button type="button" className="btn sm" onClick={() => { logFlow(p.id, 7, `Reminder sent for ${v.visitType} ${v.date} (simulated)`, actor.name, actor.role); toast('Reminder sent (simulated)'); }} data-testid="ws-postop-remind">Send reminder</button>
      <button type="button" className="btn sm" onClick={() => { logFlow(p.id, 7, `Patient confirmed ${v.visitType} ${v.date}`, actor.name, actor.role); toast('Confirmed'); }} data-testid="ws-postop-confirm">Confirmed</button></div>) : <p>No post-op visits booked.</p>}
    <button type="button" className="btn mt-2" onClick={() => go({ type: 'tab', tab: 'schedule' })}>Open schedule</button>
    <PostopNote p={p} v={pv || vs.find(x => x.date === isoDay() && un(x)) || vs.filter(x => x.date <= isoDay() && un(x)).slice(-1)[0] || vs.find(un) || vs.filter(x => x.date <= isoDay()).slice(-1)[0] || vs[0]} />
    <AddedFormsSection p={p} station="postop" v={vs.find(x => x.date >= isoDay()) || vs[vs.length - 1]} /></div>; };
void tm; void getSettings; void EL; void F;
