/* ASC.Vityls v8.3 · v7.5-style scheduler popups restored on the ASC2 data:
 * "Surgical case booking" (Add appointment) with every case detail, and "Block operating room time" (rooms × days).
 * Surgeon colors (one per surgeon, editable, audited) color-code the schedule. Fictional data; reminders/portal simulated. */
import React, { useState } from 'react';
import { medRepo, uid, ageFrom } from '../../med/record';
import { useActor } from '../../med/ui';
import { useSv } from '../ui';
import { repo } from '../../v6/dataLayer';
import { svRead, svWrite } from '../store';
import { staffList } from '../staff';
import { colorForSurgeon, getProviders, displayName } from '../../v7/providers';
import * as A from '../asc8/logic';
import * as S from '../asc8/store';
import { XClose } from '../asc82/common';
import { completeIntakeBooking, setPendingBook, type PendingBook } from '../asc82/intake';
import { matchPatient, normDob } from '../asc82/pure';

/* ---------- surgeon colors ---------- */
const PALETTE = ['#1D4ED8', '#B45309', '#7C3AED', '#0F766E', '#BE185D', '#4D7C0F', '#C2410C', '#0369A1'];
/** v11.5 · a real (signed-up) practice books the providers registered in Practice settings › Providers, never the test names.
 *  Only providers whose privileges are approved can be booked; the others are listed but greyed out. */
export const REAL_PRACTICE = () => !!(window as any).__vitylsMe;
export interface BookableProvider { name: string; role: string; approved: boolean }
export const practiceProviders = (roles: string[]): BookableProvider[] => getProviders().filter(p => p.active && roles.includes(p.role)).map(p => ({ name: displayName(p), role: p.role, approved: p.app.status === 'Privileges approved' }))
  .sort((a, b) => Number(b.approved) - Number(a.approved) || a.name.localeCompare(b.name));
export const surgeonChoices = () => practiceProviders(['Surgeon', 'Physician', 'Other provider']);
export const anesthesiaChoices = () => practiceProviders(['Anesthesiologist', 'CRNA']);
/** Anesthesia providers to offer: the practice's own (real practice) or the test list. */
export const anesList = (): string[] => REAL_PRACTICE() ? anesthesiaChoices().filter(p => p.approved).map(p => p.name) : S.ANES;
/** Option list for a provider select: approved first; pending ones disabled; a value already on the case always stays. */
export const ProviderOptions: React.FC<{ list: BookableProvider[]; value: string; none: string }> = ({ list, value, none }) => <>
  <option value="">{list.some(p => p.approved) ? 'Choose…' : none}</option>
  {(() => { const opt = (p: BookableProvider) => <option key={p.name} value={p.name} disabled={!p.approved && p.name !== value}>{p.name}{p.approved ? '' : ' (privileges not approved)'}</option>;
    const ORDER = ['Surgeon', 'Anesthesiologist', 'CRNA', 'Physician', 'Other provider']; const roles = Array.from(new Set(list.map(p => p.role))).sort((a: string, b: string) => ORDER.indexOf(a) - ORDER.indexOf(b)); // v11.5: anesthesiologists and CRNAs in one list, grouped
    return roles.length > 1 ? roles.map(r => <optgroup key={r} label={r === 'CRNA' ? 'CRNAs' : r === 'Other provider' ? 'Other' : `${r}s`}>{list.filter(p => p.role === r).map(opt)}</optgroup>) : list.map(opt); })()}
  {value && !list.some(p => p.name === value) && <option value={value}>{value}</option>}
</>;
export const surgeonList = (): string[] => REAL_PRACTICE() ? Array.from(new Set([...surgeonChoices().filter(p => p.approved).map(p => p.name), ...S.cases().map(c => c.surgeon)].filter(Boolean))) : Array.from(new Set([S.PATEL, S.WHITFIELD, ...S.cases().map(c => c.surgeon), ...staffList().filter(s => /surgeon/i.test(s.role)).map(s => s.name)].filter(Boolean)));
export const surgeonColors = () => svRead<Record<string, string>>('asc83-surgeon-colors', {});
export function surgeonColor(name: string): string { const v7 = colorForSurgeon(name); if (v7) return v7; const set = surgeonColors()[name]; if (set) return set; const i = surgeonList().indexOf(name); return PALETTE[(i >= 0 ? i : name.length) % PALETTE.length]; }
export const tint = (hex: string, a = 0.16) => { const n = parseInt(hex.slice(1), 16); return `rgba(${n >> 16},${(n >> 8) & 255},${n & 255},${a})`; };
export const SurgeonLegend: React.FC = () => { const [actor] = useActor(); const [ed, setEd] = useState(false); const [, f] = useState(0);
  return <div className="a83-legend s9-ctl" data-testid="a83-surgeon-legend"><span className="k">Surgeon colors</span>{surgeonList().map(s => <span key={s} className="a83-sw"><i style={{ background: surgeonColor(s) }} />{s.replace(/,.*$/, '')}{ed && <input type="color" value={surgeonColor(s)} aria-label={`Color for ${s}`} onChange={e => { svWrite('asc83-surgeon-colors', { ...surgeonColors(), [s]: e.target.value }); repo.audit({ caseId: 'practice', user: actor.name, role: actor.role, action: 'asc83.color' as any, detail: `Schedule color for ${s} → ${e.target.value}` }); f(x => x + 1); window.dispatchEvent(new Event('vityls-med-updated')); }} data-testid="a83-color-in" />}</span>)}
    <button type="button" className="sv-link sv-small" onClick={() => setEd(x => !x)} data-testid="a83-color-edit">{ed ? 'Done' : 'Edit colors'}</button></div>; };

/* ---------- shared bits ---------- */
const SLOTS = Array.from({ length: 48 }, (_, i) => { const m = 6 * 60 + i * 15; const h = Math.floor(m / 60), mm = m % 60; return `${String(((h + 11) % 12) + 1).padStart(2, '0')}:${String(mm).padStart(2, '0')} ${h < 12 ? 'AM' : 'PM'}`; });
const LENGTHS = [30, 45, 60, 75, 90, 120, 150, 180, 240, 300, 360];
const lenLabel = (m: number) => m < 60 ? `${m} min` : `${(m / 60).toString().replace(/\.5$/, '½')} h${m % 60 && m % 30 ? ` ${m % 60} min` : ''}`.replace('½', '.5');
export const ANES_TYPES = ['General Anesthesia', 'MAC / Monitored Anesthesia Care', 'Regional Anesthesia', 'Local with Sedation', 'Local Anesthesia', 'Other / TBD'];
export const PAY_TYPES = ['Self-pay', 'Commercial insurance', 'Medicare', 'Medicaid', 'Workers comp', 'Financing'];
const F: React.FC<{ l: string; req?: boolean; children: React.ReactNode; span?: number }> = ({ l, req, children, span }) => <label className="a83-f" style={span ? { gridColumn: `span ${span}` } : undefined}><span className="a83-l">{l}{req && <em>Required</em>}</span>{children}</label>;
const Shell: React.FC<{ title: string; sub?: string; testId: string; onClose: () => void; foot: React.ReactNode; children: React.ReactNode; wide?: boolean }> = ({ title, sub, testId, onClose, foot, children, wide }) =>
  <div className="a81-modal a83-modal" onMouseDown={e => { if (e.target === e.currentTarget) onClose(); }}><div className={`a81-dialog a83-dlg ${wide ? 'wide' : ''}`} role="dialog" aria-label={title} data-testid={testId}>
    <div className="a81-dhead"><div><b>{title}</b>{sub && <div className="sv-small sv-muted">{sub}</div>}</div><span style={{ marginLeft: 'auto' }} /><XClose onClick={onClose} testId={`${testId}-close`} /></div>
    <div className="a81-dbody">{children}</div><div className="a83-foot">{foot}</div></div></div>;

/* ---------- Surgical case booking (v7.5 "Add new appointment") ---------- */
export interface BookInit { blockId?: string; len?: number; date: string; time?: string; room?: string; surgeon?: string; pb?: PendingBook; draft?: { name?: string; dob?: string; phone?: string; email?: string; sex?: string; procedure?: string; anesthesia?: string; payType?: string; duration?: number; notes?: string; assistant?: string; equipment?: string } }
export const CaseBookingDialog: React.FC<{ init: BookInit; onClose: () => void; onBooked?: (c: A.AscCase) => void }> = ({ init, onClose, onBooked }) => {
  const [actor] = useActor(); const { toast, go } = useSv(); const d = init.draft || {}; const pb = init.pb;
  const anesGuess = (x = '') => ANES_TYPES.find(t => x && t.toLowerCase().startsWith(x.toLowerCase().slice(0, 3))) || (/mac/i.test(x) ? ANES_TYPES[1] : /local/i.test(x) ? ANES_TYPES[3] : x ? ANES_TYPES[0] : '');
  const payGuess = (x = '') => /self|cash/i.test(x) ? 'Self-pay' : /medicare/i.test(x) ? 'Medicare' : /medicaid/i.test(x) ? 'Medicaid' : x ? 'Commercial insurance' : '';
  const p0 = pb?.patientId ? medRepo.patient(pb.patientId) : undefined;
  const [f, setF] = useState({ date: init.date, time: init.time || '07:30 AM', len: d.duration || pb?.duration || 60, room: init.room || 'OR 1', pid: p0?.id || '', q: d.name || '', dob: d.dob || '', age: '', phone: d.phone || '', sex: d.sex || '', procedure: d.procedure || pb?.reason || '', surgeon: init.surgeon || pb?.provider || (REAL_PRACTICE() ? (surgeonChoices().find(x => x.approved)?.name || '') : S.PATEL), anesthesiologist: (anesList()[0] || ''), anesType: anesGuess(d.anesthesia || pb?.anesthesia), payType: payGuess(d.payType), notes: d.notes || pb?.notes || '', assistant: d.assistant || '' });
  const [err, setErr] = useState(''); const set = (k: string, v: any) => setF(x => ({ ...x, [k]: v }));
  const pt = f.pid ? medRepo.patient(f.pid) : undefined;
  const hits = !pt && f.q.trim().length >= 2 ? medRepo.patients().filter(p => p.name.toLowerCase().includes(f.q.trim().toLowerCase())).slice(0, 6) : [];
  const m = !pt && f.q.trim() ? matchPatient(f.q, f.dob, medRepo.patients().map(p => ({ id: p.id, name: p.name, dob: p.dob }))) : null;
  const surgeons = surgeonList(); if (!surgeons.includes(f.surgeon)) surgeons.push(f.surgeon);
  const busy = S.cases().filter(c => c.date === f.date && c.room === f.room && A.toMin(c.time) < A.toMin(f.time) + f.len && A.toMin(f.time) < A.toMin(c.time) + c.durationMin);
  const save = () => { const miss = [!pt && !f.q.trim() && 'patient', !pt && !f.dob.trim() && 'date of birth', !f.procedure.trim() && 'procedure', !f.surgeon && 'surgeon', !f.anesType && 'type of anesthesia', !f.payType && 'payment type'].filter(Boolean);
    if (miss.length) return setErr(`Still needed: ${miss.join(', ')}.`);
    let pid = pt?.id; if (!pid) { pid = uid('ASC-N'); medRepo.savePatient({ id: pid, name: f.q.trim(), dob: normDob(f.dob) || f.dob, sex: /^f/i.test(f.sex) ? 'Female' : /^m/i.test(f.sex) ? 'Male' : 'Other', phone: f.phone, email: d.email || '', language: 'English', allergies: [], primaryProvider: f.surgeon, careTeam: [], insurance: f.payType, fictional: true } as any);
      repo.audit({ caseId: 'practice', user: actor.name, role: actor.role, action: 'asc83.patient' as any, detail: `New patient ${f.q.trim()} created from case booking` }); }
    const v = { id: uid('visit'), patientId: pid, date: f.date, time: f.time, durationMin: f.len, provider: f.surgeon, room: f.room, visitType: 'Surgery case', reason: f.procedure.trim(), notes: f.notes || undefined, step: 'scheduled', problemIds: [], createdAt: new Date().toISOString(), createdBy: actor.name } as any;
    medRepo.saveVisit(v);
    const c0 = completeIntakeBooking(pb || { intakeId: '', patientId: pid, date: f.date, time: f.time, room: f.room, provider: f.surgeon, duration: f.len, reason: f.procedure, notes: f.notes, source: 'scheduler', anesthesia: f.anesType, email: d.email, phone: f.phone }, v, actor.name, actor.role);
    const c = S.saveCase({ ...c0, anesthesia: f.anesthesiologist, room: f.room, d: { ...c0.d, payType: f.payType, anesType: f.anesType, bookingNotes: f.notes, equipment: (f as any).equip || undefined, bookedAt: new Date().toISOString(), bookedBy: actor.name, assistant: f.assistant } }, actor.name, actor.role, `Booked: ${f.procedure} · ${f.surgeon} · ${f.anesType} · ${f.payType}`);
    toast(`Surgical case booked for ${medRepo.patient(pid)!.name} · ${new Date(f.date + 'T12:00').toLocaleDateString([], { month: 'short', day: 'numeric' })} ${f.time.replace(/^0/, '')} · ${f.room}. Portal forms sent (simulated).`); onBooked?.(c); onClose(); };
  return <Shell title="Surgical case booking" sub="Search the patient (2+ letters) or type a new one; every case detail in one place." testId="a83-booking" onClose={() => { if (pb) setPendingBook(null); onClose(); }} wide
    foot={<><span className="sv-small sv-muted" style={{ flex: 1 }}>{busy.length ? <span className="a81-warn" data-testid="a83-book-clash">{f.room} already has {busy.map(c => `${medRepo.patient(c.pid)?.name} ${c.time.replace(/^0/, '')}`).join(', ')} then.</span> : 'Reminders and portal forms go out automatically (simulated).'}</span>
      {pt && <button type="button" className="a8-btn" onClick={() => { onClose(); go({ type: 'chart', pid: pt.id } as any); }}>Open chart</button>}<button type="button" className="a8-btn" onClick={onClose}>Cancel</button><button type="button" className="a8-btn pri" onClick={save} data-testid="a83-book-save">Book surgical case</button></>}>
    {pb && <p className="a82-prefill" data-testid="a82-book-prefill">Pre-filled from the {pb.source === 'fax' ? 'scanned fax' : pb.source === 'email' ? 'email' : ''} booking request. Check and book; the surgery case is created when you book.</p>}
    <h4 className="a83-h">When &amp; where</h4>
    <div className="a83-grid4"><F l="Date of service (DOS)" req><input type="date" className="sv-input" value={f.date} onChange={e => set('date', e.target.value)} data-testid="a83-book-date" /></F>
      <F l="Start time" req><select className="sv-input" value={f.time} onChange={e => set('time', e.target.value)} data-testid="a83-book-time">{(SLOTS.includes(f.time) ? SLOTS : [f.time, ...SLOTS]).map(s => <option key={s}>{s}</option>)}</select></F>
      <F l="Length of surgery" req><select className="sv-input" value={f.len} onChange={e => set('len', +e.target.value)} data-testid="a83-book-len">{(LENGTHS.includes(f.len) ? LENGTHS : [f.len, ...LENGTHS]).map(n => <option key={n} value={n}>{lenLabel(n)}</option>)}</select></F>
      <F l="Operating room" req><select className="sv-input" value={f.room} onChange={e => set('room', e.target.value)} data-testid="a83-book-room">{S.ROOMS.map(r => <option key={r}>{r}</option>)}</select></F></div>
    <h4 className="a83-h">Patient</h4>
    {pt ? <div className="a83-pt" data-testid="a83-book-patient"><b>{pt.name}</b><span>DOB {pt.dob} · {ageFrom(pt.dob)} y · {pt.sex}</span><span>{pt.phone}</span>{pt.allergies.length ? <span className="alg">Allergies: {pt.allergies.join('; ')}</span> : <span>NKDA</span>}<button type="button" className="sv-link" onClick={() => set('pid', '')}>change</button></div> : <>
      <div className="a83-grid4"><F l="Patient name" req span={2}><input className="sv-input" placeholder="Type patient name…" value={f.q} onChange={e => set('q', e.target.value)} data-testid="a83-book-name" autoComplete="off" /></F>
        <F l="Date of birth (DOB)" req><input className="sv-input" placeholder="MM/DD/YYYY" value={f.dob} onChange={e => set('dob', e.target.value)} data-testid="a83-book-dob" /></F>
        <F l="Phone number"><input className="sv-input" placeholder="e.g. (310) 555-1234" value={f.phone} onChange={e => set('phone', e.target.value)} /></F>
        <F l="Sex"><select className="sv-input" value={f.sex} onChange={e => set('sex', e.target.value)}><option value="">—</option><option>Female</option><option>Male</option><option>Other</option></select></F></div>
      {hits.length > 0 && <div className="a83-hits" data-testid="a83-book-hits"><span className="sv-small sv-muted">Select to auto-fill</span>{hits.map(h => <button key={h.id} type="button" onClick={() => set('pid', h.id)} data-testid="a83-book-hit">{h.name} · DOB {h.dob}{normDob(h.dob) && normDob(h.dob) === normDob(f.dob) ? ' · DOB matches' : ''}</button>)}</div>}
      {f.q.trim().length >= 2 && <p className="sv-small sv-muted">{m?.kind === 'exact' ? 'Name and DOB match a chart above: select it to link.' : hits.length ? 'Pick a chart above, or keep typing to create a new patient.' : 'No match: a new patient chart is created when you book.'}</p>}</>}
    <h4 className="a83-h">Procedure &amp; team</h4>
    <div className="a83-grid4"><F l="Procedure" req span={4}><input className="sv-input" placeholder="Full procedure description (include side)" value={f.procedure} onChange={e => set('procedure', e.target.value)} data-testid="a83-book-proc" /></F>
      <F l="Surgeon" req><select className="sv-input" value={f.surgeon} onChange={e => set('surgeon', e.target.value)} data-testid="a83-book-surgeon">{REAL_PRACTICE() ? <ProviderOptions list={surgeonChoices()} value={f.surgeon} none="Add surgeons in Practice settings › Providers" /> : surgeons.map(s => <option key={s}>{s}</option>)}</select></F>
      <F l="Anesthesiologist"><select className="sv-input" value={f.anesthesiologist} onChange={e => set('anesthesiologist', e.target.value)}>{REAL_PRACTICE() ? <ProviderOptions list={anesthesiaChoices()} value={f.anesthesiologist} none="Add anesthesia providers in Practice settings › Providers" /> : S.ANES.map(s => <option key={s}>{s}</option>)}</select></F>
      <F l="Type of anesthesia" req><select className="sv-input" value={f.anesType} onChange={e => set('anesType', e.target.value)} data-testid="a83-book-anes"><option value="">Choose…</option>{ANES_TYPES.map(s => <option key={s}>{s}</option>)}</select></F>
      <F l="Payment type" req><select className="sv-input" value={f.payType} onChange={e => set('payType', e.target.value)} data-testid="a83-book-pay"><option value="">Choose…</option>{PAY_TYPES.map(s => <option key={s}>{s}</option>)}</select></F>
      <F l="Assistant"><input className="sv-input" value={f.assistant} onChange={e => set('assistant', e.target.value)} /></F>
      <F l="Notes" span={3}><input className="sv-input" placeholder="Clinical notes, pre-op instructions, equipment or patient preferences…" value={f.notes} onChange={e => set('notes', e.target.value)} data-testid="a83-book-notes" /></F><F l="Special equipment / implants" span={3}><input className="sv-input" placeholder="e.g. C-arm, mini fragment set, tourniquet" value={(f as any).equip || ''} onChange={e => (set as any)('equip', e.target.value)} data-testid="v103-book-equip" /></F></div>
    <div className="a83-swatch" style={{ borderLeftColor: surgeonColor(f.surgeon), background: tint(surgeonColor(f.surgeon)) }}>Shows on the schedule in {f.surgeon.replace(/,.*$/, '')}’s color.</div>
    {err && <p className="a81-err" data-testid="a83-book-err">{err}</p>}
  </Shell>;
};

/* ---------- Block operating room time (v7.5) ---------- */
const DOW = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'];
export { blockPlan } from './payrules'; import { blockPlan, monday, isoOf as iso } from './payrules';
export const BlockTime83: React.FC<{ day: string; onClose: () => void }> = ({ day, onClose }) => {
  const [actor] = useActor(); const { toast } = useSv(); const surgeons = surgeonList(); const dIdx = Math.min(4, Math.max(0, (new Date(day + 'T12:00:00').getDay() + 6) % 7));
  const [f, setF] = useState({ who: surgeons[0] || S.PATEL, custom: '', rooms: ['OR 1'] as string[], start: '07:00 AM', end: '12:00 PM', days: [dIdx] as number[], weeks: 1, reason: '', notes: '' }); const [err, setErr] = useState('');
  const who = f.who === '__custom' ? f.custom.trim() : f.who; const plan = blockPlan(day, f.days, f.weeks, f.rooms);
  const tog = <T,>(l: T[], x: T) => l.includes(x) ? l.filter(y => y !== x) : [...l, x];
  const save = () => { if (!who) return setErr('Choose who the block is for.'); if (!f.rooms.length || !f.days.length) return setErr('Pick at least one room and one day.'); if (A.toMin(f.end) <= A.toMin(f.start)) return setErr('End must be after start.');
    const l = svRead<any[]>('block-seed', []); const clash = plan.find(p => l.some(b => b.date === p.date && b.room === p.room && A.toMin(b.start) < A.toMin(f.end) && A.toMin(f.start) < A.toMin(b.end)));
    if (clash) return setErr(`${clash.room} already has block time on ${clash.date}.`);
    svWrite('block-seed', [...l, ...plan.map(p => ({ id: uid('blk'), surgeon: who, date: p.date, start: f.start, end: f.end, room: p.room, reason: f.reason, notes: f.notes }))]);
    repo.audit({ caseId: 'practice', user: actor.name, role: actor.role, action: 'asc81.block' as any, detail: `Block time ${who} · ${f.rooms.join(', ')} · ${plan.length} block(s) ${f.start}–${f.end}${f.reason ? ` · ${f.reason}` : ''}` }); window.dispatchEvent(new Event('vityls-med-updated'));
    toast(`${plan.length} block${plan.length === 1 ? '' : 's'} saved for ${who.replace(/,.*$/, '')}.`); onClose(); };
  return <Shell title="Block operating room time" sub="Reserve surgeon block time, turnover buffers or maintenance holds across rooms and days (recurring or single)." testId="a81-block-dialog" onClose={onClose}
    foot={<><span className="sv-small" style={{ flex: 1 }} data-testid="a83-block-count">Total blocks to generate: <b>{plan.length}</b></span><button type="button" className="a8-btn" onClick={onClose}>Cancel</button><button type="button" className="a8-btn pri" onClick={save} data-testid="a81-block-save">Save block time</button></>}>
    <h4 className="a83-h">Provider / assignee</h4>
    <div className="a83-grid4"><F l="Assigned to" req span={2}><select className="sv-input" value={f.who} onChange={e => setF({ ...f, who: e.target.value })} data-testid="a81-block-surgeon">{surgeons.map(s => <option key={s}>{s}</option>)}<option value="__custom">Other team / maintenance…</option></select></F>
      {f.who === '__custom' && <F l="Name" span={2}><input className="sv-input" placeholder="Enter custom provider or team name…" value={f.custom} onChange={e => setF({ ...f, custom: e.target.value })} /></F>}</div>
    <h4 className="a83-h">Operating room &amp; time window</h4>
    <div className="a83-chips" data-testid="a83-block-rooms"><label className="a82-chipck"><input type="checkbox" checked={f.rooms.length === S.ROOMS.length} onChange={e => setF({ ...f, rooms: e.target.checked ? [...S.ROOMS] : [] })} />All configured rooms</label>{S.ROOMS.map(r => <label key={r} className={`a82-chipck ${f.rooms.includes(r) ? 'on' : ''}`}><input type="checkbox" checked={f.rooms.includes(r)} onChange={() => setF({ ...f, rooms: tog(f.rooms, r) })} data-testid={`a81-block-room-${r.replace(/\W+/g, '')}`} />{r}</label>)}</div>
    <div className="a83-grid4 mt-2"><F l="Start"><select className="sv-input" value={f.start} onChange={e => setF({ ...f, start: e.target.value })}>{SLOTS.map(s => <option key={s}>{s}</option>)}</select></F><F l="End"><select className="sv-input" value={f.end} onChange={e => setF({ ...f, end: e.target.value })}>{SLOTS.map(s => <option key={s}>{s}</option>)}</select></F>
      <F l="Repeat"><select className="sv-input" value={f.weeks} onChange={e => setF({ ...f, weeks: +e.target.value })} data-testid="a83-block-weeks">{[1, 2, 4, 8, 12].map(n => <option key={n} value={n}>{n === 1 ? 'This week only' : `Weekly × ${n} weeks`}</option>)}</select></F></div>
    <h4 className="a83-h">Select days of the week to block · week of {monday(day).toLocaleDateString([], { month: 'short', day: 'numeric' })}</h4>
    <div className="a83-chips">{DOW.map((d, i) => { const x = new Date(monday(day)); x.setDate(x.getDate() + i); return <label key={d} className={`a82-chipck ${f.days.includes(i) ? 'on' : ''}`}><input type="checkbox" checked={f.days.includes(i)} onChange={() => setF({ ...f, days: tog(f.days, i) })} data-testid={`a83-block-day-${i}`} />{d} {x.getMonth() + 1}/{x.getDate()}</label>; })}</div>
    <div className="a83-grid4 mt-2"><F l="Purpose" span={2}><input className="sv-input" placeholder="e.g. Time slot blocked for: revision cases" value={f.reason} onChange={e => setF({ ...f, reason: e.target.value })} /></F><F l="Notes" span={2}><input className="sv-input" placeholder="e.g. Reserved for equipment sterilization" value={f.notes} onChange={e => setF({ ...f, notes: e.target.value })} /></F></div>
    {err && <p className="a81-err" data-testid="a81-block-err">{err}</p>}
  </Shell>;
};
