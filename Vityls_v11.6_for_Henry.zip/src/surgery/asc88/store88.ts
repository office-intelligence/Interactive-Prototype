/* ASC.Vityls v8.8 · storage: practice fee schedule (itemized) and facility profile (logo, name, address, contacts). Fictional placeholder facility.
 * Henry: fee_item, facility_profile. */
import { repo } from '../../v6/dataLayer';
import { svRead, svWrite } from '../store';
import { ACTIVE_PRACTICE } from '../../edition';
import { getSettings } from '../../med/settings';
import * as P from './pure88';
const bump = () => window.dispatchEvent(new Event('vityls-med-updated'));
const aud = (by: string, role: string, detail: string, action: string) => repo.audit({ caseId: 'practice', user: by, role, action: action as any, detail });
export const feeItems = () => svRead<P.FeeItem[]>('asc88-fees', P.FEE_SEED);
export function saveFeeItems(l: P.FeeItem[], by: string, role: string, what: string) { svWrite('asc88-fees', l); aud(by, role, `Fee schedule: ${what}`, 'asc88.fees'); bump(); }
/** v11.5 · Surgery/Medical: a doctor can see patients at two or more offices. The main office is the address above;
 *  these are the others. Henry: maps to dbo.Sites (one row per office). */
export interface Office { id: string; name: string; address: string; city: string; phone: string; fax: string }
export interface Facility { name: string; address: string; city: string; phone: string; fax: string; email: string; website: string; taxId: string; npi: string; logo?: string; logoName?: string;
  /** v11.5: practice profile in the onboarding wizard */ mainEmail?: string; offices?: Office[]; stateLicense?: string; medicareId?: string; accreditor?: string; accreditationNumber?: string; accreditationExpires?: string }
export const FACILITY_SEED: Facility = { name: 'Harborview Surgery Center (fictional)', address: '100 Example Ave, Suite 1', city: 'Sample City, CA 90000', phone: '(555) 010-0100', fax: '(555) 010-0101', email: 'billing@harborview.example', website: 'harborview.example', taxId: '00-0000000 (example)', npi: '0000000000 (example)' };
/** v11.5 · a real (signed-up) practice starts with a blank profile carrying only its own name, never the fictional example. */
const blankFacility = (): Facility => ({ name: (() => { try { return getSettings().practiceName || ''; } catch { return ''; } })(), address: '', city: '', phone: '', fax: '', email: '', website: '', taxId: '', npi: '' });
export const facility = () => ({ ...(ACTIVE_PRACTICE?.id.startsWith('org-') ? blankFacility() : FACILITY_SEED), ...svRead<Partial<Facility>>('asc88-facility', {}) });
export function saveFacility(f: Facility, by: string, role: string, what: string) { svWrite('asc88-facility', f); aud(by, role, `Facility profile: ${what}`, 'asc88.facility'); bump(); }
