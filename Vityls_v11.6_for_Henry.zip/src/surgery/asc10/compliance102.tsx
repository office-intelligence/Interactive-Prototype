/* ASC.Vityls v10.2 · Nightingale chat box on Compliance & credentials: staff ask for compliance tasks in plain words
 * ("which licenses expire in 60 days?", "remind me to renew the CLIA waiver"). Nightingale drafts the task; a person
 * confirms it. Nothing leaves the device and nothing is sent. Fictional data only. */
import React, { useEffect, useState } from 'react';
import { Sparkles, Send, Check, X } from 'lucide-react';
import { useActor } from '../../med/ui';
import { svRead, svWrite } from '../store';
import { repo } from '../../v6/dataLayer';
import { credentialsAudit, accreditationAudit } from './compliance115';

export interface CTask { id: string; text: string; due?: string; status: 'draft' | 'open' | 'done'; by: string; at: string }
const K = 'asc102-compliance-tasks';
export const ctasks = () => svRead<CTask[]>(K, []);
const put = (l: CTask[]) => { svWrite(K, l); window.dispatchEvent(new Event('vityls-med-updated')); };
/** v11.5 · audits draft their follow-ups here; a person confirms each one. */
export function addDraftTasks(items: { text: string; due?: string }[]) { const l = ctasks(); const have = new Set(l.filter(x => x.status !== 'done').map(x => x.text)); const n = [...l, ...items.filter(i => !have.has(i.text)).map((i, k) => ({ id: `ct-${Date.now().toString(36)}${k}`, text: i.text, due: i.due, status: 'draft' as const, by: 'Nightingale (audit draft)', at: new Date().toISOString() }))]; put(n); }
/** v11.5 · examples shown under the box (compliance, staff and provider credentialing). */
export const COMPLIANCE_EXAMPLES = ['Run the credentials audit', 'Which licenses expire in the next 30 days?', 'Who is missing BLS or ACLS?', 'Run the accreditation audit', 'Prepare the inspection binder', 'Remind me to renew the CLIA waiver in 60 days', 'Schedule the quarterly fire drill', 'Which logs are overdue?'];
/** Pure: Nightingale's draft reply + task for a request. Never decides; it only proposes. */
export function draftComplianceTask(q: string): { reply: string; task?: string; due?: string; run?: 'credentials' | 'accreditation' | 'binder' } {
  const t = q.trim(); if (!t) return { reply: '' };
  // v11.5: answers from the register and the audits
  const T = new Date().toISOString().slice(0, 10); const win = +(t.match(/(\d+)\s*days?/i)?.[1] || 30);
  if (/inspection binder|binder/i.test(t)) return { reply: 'Running the accreditation audit. Use “Inspection binder” in the results to print or save the binder: a tab per section with each document’s status and date, then the credential files.', run: 'binder' };
  if (/accreditation audit|survey|inspection|overdue log|logs? (are )?overdue|which logs/i.test(t)) { const r = accreditationAudit(T); const bad = r.filter(x => x.status === 'expired').length, miss = r.filter(x => x.status === 'missing').length, soon = r.filter(x => x.status === 'soon').length;
    return { reply: `Accreditation audit: ${bad} overdue, ${soon} due soon, ${miss} missing of ${r.filter(x => x.status !== 'optional').length} required items. The full list is in the results below.`, run: 'accreditation' }; }
  if (/credential|licen|expir|missing\s+(bls|acls)|who is missing|bls|acls|dea|malpractice/i.test(t) && (/\?$/.test(t) || /audit|run|check|list|who/i.test(t))) { const r = credentialsAudit(T, win); const ex = r.filter(x => x.status === 'expired'), so = r.filter(x => x.status === 'soon'), mi = r.filter(x => x.status === 'missing');
    const only = /bls|acls/i.test(t) ? mi.filter(x => /BLS|ACLS/.test(x.document)) : null;
    if (only) return { reply: only.length ? `Missing BLS/ACLS: ${only.map(x => `${x.who} (${x.document})`).join(', ')}.` : 'Everyone who needs BLS or ACLS has it on file.', run: 'credentials' };
    return { reply: `Credentials audit (${win} days): ${ex.length} expired, ${so.length} due${so.length ? ` (${so.slice(0, 3).map(x => `${x.who}: ${x.document} ${x.due}`).join('; ')}${so.length > 3 ? '…' : ''})` : ''}, ${mi.length} missing. The full list is in the results below; “Draft renewal tasks” adds them here for you to confirm.`, run: 'credentials' }; }
  const days = t.match(/(\d+)\s*days?/i)?.[1]; const due = days ? new Date(Date.now() + +days * 864e5).toISOString().slice(0, 10) : undefined;
  if (/expir|renew|due/i.test(t) && /\?$/.test(t)) return { reply: `I would check every credential and facility document with a renewal date${days ? ` in the next ${days} days` : ''}. Nothing is tracked with a date yet in this center. I drafted a task to review renewals.`, task: `Review credentials and documents due for renewal${days ? ` within ${days} days` : ''}`, due };
  if (/audit|survey|aaaasf|quad\s*a|joint commission|cdph/i.test(t)) return { reply: 'I drafted an accreditation readiness task. I can list the documents each binder needs once you upload them.', task: `Accreditation readiness: ${t.replace(/[?.!]+$/, '')}`, due };
  return { reply: 'I drafted this as a task. Confirm it to add it to the list.', task: t.replace(/^(please\s+)?(remind me to|create a task to|add a task to)\s+/i, '').replace(/[?.!]+$/, '').replace(/^./, m => m.toUpperCase()), due };
}
export const ComplianceAsk: React.FC = () => {
  const [actor] = useActor(); const [q, setQ] = useState(''); const [log, setLog] = useState<{ q: string; a: string }[]>([]); const [l, setL] = useState<CTask[]>(ctasks());
  useEffect(() => { const f = () => setL(ctasks()); window.addEventListener('vityls-med-updated', f); return () => window.removeEventListener('vityls-med-updated', f); }, []);
  const send = (text = q) => { const d = draftComplianceTask(text); if (!d.reply) return; if (d.run) { window.dispatchEvent(new CustomEvent('vityls-run-audit', { detail: d.run === 'binder' ? 'accreditation' : d.run })); setLog([...log, { q: text, a: d.reply }]); setQ(''); return; } const n = d.task ? [...l, { id: `ct-${Date.now().toString(36)}`, text: d.task, due: d.due, status: 'draft' as const, by: 'Nightingale (draft)', at: new Date().toISOString() }] : l; put(n); setL(n); setLog([...log, { q: text, a: d.reply }]); setQ(''); };
  const set = (id: string, status: CTask['status'] | 'delete') => { const n = status === 'delete' ? l.filter(x => x.id !== id) : l.map(x => x.id === id ? { ...x, status, by: actor.name } : x); put(n); setL(n); repo.audit({ caseId: 'practice', user: actor.name, role: actor.role, action: 'asc102.ctask' as any, detail: `Compliance task ${status}: ${l.find(x => x.id === id)?.text}` }); };
  return <section className="v10-card" data-testid="v102-compliance-ask" style={{ background: '#fff', marginTop: 12 }}>
    <h3 className="v10-h"><Sparkles size={18} aria-hidden="true" />Ask Nightingale for a compliance task</h3>
    <form className="v10-row" onSubmit={e => { e.preventDefault(); send(); }}><input className="sv-input" style={{ flex: 1 }} value={q} onChange={e => setQ(e.target.value)} placeholder="e.g. Which licenses expire in the next 60 days?" data-testid="v102-cask-input" />
      <button type="submit" className="a8-btn pri" disabled={!q.trim()} data-testid="v102-cask-send"><Send size={14} style={{ display: 'inline', verticalAlign: '-2px', marginRight: 4 }} />Ask</button></form>
    <div className="c115-examples" data-testid="v102-examples"><span className="sv-small sv-muted">Try:</span>{COMPLIANCE_EXAMPLES.map(x => <button key={x} type="button" className="c115-ex" onClick={() => send(x)} data-testid="v102-example">{x}</button>)}</div>
    {log.slice(-3).map((m, i) => <div key={i} className="sv-small" style={{ marginTop: 8 }} data-testid="v102-cask-reply"><b>You:</b> {m.q}<br /><b>Nightingale:</b> {m.a}</div>)}
    {l.length > 0 && <div className="c115-tasks" id="compliance-tasks" style={{ marginTop: 12 }} data-testid="v102-ctasks">
      <div className="v10-row" style={{ marginBottom: 4 }}><b>Compliance tasks</b><span className="v10-chip warn" data-testid="v102-ndraft">{l.filter(t => t.status === 'draft').length} draft</span><span className="v10-chip info">{l.filter(t => t.status === 'open').length} open</span><span className="v10-chip ok">{l.filter(t => t.status === 'done').length} done</span><span style={{ flex: 1 }} />
        {l.some(t => t.status === 'draft') && <button type="button" className="a8-btn" onClick={() => { const n = l.map(x => x.status === 'draft' ? { ...x, status: 'open' as const, by: actor.name } : x); put(n); setL(n); repo.audit({ caseId: 'practice', user: actor.name, role: actor.role, action: 'asc102.ctask' as any, detail: `Confirmed ${l.filter(t => t.status === 'draft').length} compliance tasks` }); }} data-testid="v102-confirm-all">Confirm all drafts</button>}
        {l.some(t => t.status === 'done') && <button type="button" className="sv-link sv-small" onClick={() => { const n = l.filter(x => x.status !== 'done'); put(n); setL(n); }}>Clear done</button>}</div>
      <p className="sv-small sv-muted" style={{ margin: '0 0 6px' }}>Drafts come from Nightingale and the audits. Confirm a draft to make it an open task; mark it done when it is finished.</p>
      {l.map(t => <div key={t.id} className={`v10-li ${t.status === 'done' ? 'done' : ''}`} data-testid="v102-ctask" data-status={t.status}>
      <span style={{ flex: 1 }}>{t.text}{t.due ? ` · due ${t.due}` : ''}</span><span className={`v10-chip ${t.status === 'draft' ? 'warn' : t.status === 'done' ? 'ok' : 'info'}`}>{t.status === 'draft' ? 'Draft' : t.status === 'open' ? 'Open' : 'Done'}</span>
      {t.status === 'draft' && <button type="button" className="sv-link sv-small" onClick={() => set(t.id, 'open')} data-testid="v102-ctask-confirm">Confirm</button>}
      {t.status === 'open' && <button type="button" className="sv-link sv-small" onClick={() => set(t.id, 'done')}><Check size={13} /> Done</button>}
      <button type="button" className="sv-link sv-small" aria-label="Remove" onClick={() => set(t.id, 'delete')}><X size={13} /></button></div>)}</div>}
    <p className="v10-sub" style={{ marginTop: 8 }}>Nightingale drafts tasks only. A person confirms each one.</p></section>;
};
