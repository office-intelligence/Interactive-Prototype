/* v11.5 · Compliance center (Practice settings › Security & audit › Accreditation & documents):
 * Run credentials audit · Run accreditation audit · Inspection binder · Document register with upload and history. */
import React, { useEffect, useState } from 'react';
import { ShieldCheck, FileCheck, Upload, Printer, ClipboardList, History, FileText, X } from 'lucide-react';
import { useActor, useMedTick } from '../../med/ui';
import { DialogShell } from '../../v7/ui';
import { getProviders, displayName } from '../../v7/providers';
import { staffList } from '../staff';
import { facility } from '../asc88/store88';
import { addDraftTasks } from './compliance102';
import * as D from './compliance115';
import * as R from './docRequests';
import { Mail, Send, Check } from 'lucide-react';

const today = () => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; };
const fmt = (iso: string) => iso ? new Date(iso + 'T12:00:00').toLocaleDateString() : '—';
const esc = (s: string) => String(s ?? '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]!));
const chip = (s: D.AuditStatus) => s === 'expired' || s === 'missing' ? 'v10-chip bad' : s === 'soon' ? 'v10-chip warn' : s === 'ok' ? 'v10-chip ok' : 'v10-chip';
const practice = () => { try { return facility().name || 'Our facility'; } catch { return 'Our facility'; } };
/** Opens a clean printable page (save as PDF from the print dialog). */
export function printPage(title: string, body: string) {
  const w = window.open('', '_blank'); if (!w) return;
  w.document.write(`<!doctype html><html><head><meta charset="utf-8"><title>${esc(title)}</title><style>body{font:13px/1.45 -apple-system,Segoe UI,Arial,sans-serif;color:#1d2522;margin:28px}h1{font-size:20px;margin:0 0 2px}h2{font-size:15px;margin:22px 0 6px;color:#1f4e3d;border-bottom:1px solid #cfd8d3;padding-bottom:3px}.sub{color:#5b6b66;margin:0 0 14px}table{width:100%;border-collapse:collapse;margin:4px 0 10px}th,td{border:1px solid #cfd8d3;padding:5px 7px;text-align:left;vertical-align:top}th{background:#eef3f0;font-size:12px}.bad{color:#9b1c1c;font-weight:700}.warn{color:#8a5300;font-weight:700}.ok{color:#1f6e52}.log td{height:26px}@media print{body{margin:10mm}h2{break-after:avoid}tr{break-inside:avoid}}</style></head><body>${body}</body></html>`);
  w.document.close(); setTimeout(() => { try { w.focus(); w.print(); } catch { /* */ } }, 300);
}
export function printLogSheet(it: D.CheckItem) {
  const cols = it.log || ['Date', 'Entry', 'Initials'];
  printPage(it.title, `<h1>${esc(it.title)}</h1><p class="sub">${esc(practice())} · Month / year: ______________ · Reviewed by: ______________</p><table class="log"><tr>${cols.map(c => `<th>${esc(c)}</th>`).join('')}</tr>${Array.from({ length: 31 }, () => `<tr>${cols.map(() => '<td></td>').join('')}</tr>`).join('')}</table>`);
}

const CredAudit: React.FC<{ rows: D.AuditRow[]; win: number; onTasks: () => void; onRequest: () => void }> = ({ rows, win, onTasks, onRequest }) => {
  const bad = rows.filter(r => r.status === 'expired' || r.status === 'soon' || r.status === 'missing').sort((a, b) => ['expired', 'soon', 'missing'].indexOf(a.status) - ['expired', 'soon', 'missing'].indexOf(b.status) || (a.due || '9').localeCompare(b.due || '9'));
  const people = new Set(rows.map(r => r.owner + r.who)).size; const n = (s: D.AuditStatus) => rows.filter(r => r.status === s).length;
  const print = () => printPage('Credentials audit', `<h1>Credentials audit · ${esc(practice())}</h1><p class="sub">${new Date().toLocaleString()} · ${people} people · window ${win} days · ${n('expired')} expired, ${n('soon')} due, ${n('missing')} missing</p><table><tr><th>Person</th><th>Role</th><th>Document</th><th>Status</th><th>Date</th><th>Source</th></tr>${bad.map(r => `<tr><td>${esc(r.who)}</td><td>${esc(r.role)}</td><td>${esc(r.document)}</td><td class="${r.status === 'soon' ? 'warn' : 'bad'}">${esc(D.STATUS_LABEL[r.status])}</td><td>${fmt(r.due)}</td><td>${esc(r.source)}</td></tr>`).join('') || '<tr><td colspan="6">Nothing expired, due or missing.</td></tr>'}</table>`);
  return <div className="c115-result" data-testid="c115-cred-result">
    <div className="v10-row"><b>{people} people checked</b><span className="v10-chip bad" data-testid="c115-cred-expired">{n('expired')} expired</span><span className="v10-chip warn" data-testid="c115-cred-soon">{n('soon')} due within {win} days</span><span className="v10-chip bad" data-testid="c115-cred-missing">{n('missing')} missing</span>
      <span style={{ flex: 1 }} />{bad.some(r => r.owner !== 'facility') && <button type="button" className="a8-btn pri" onClick={onRequest} data-testid="c115-cred-request"><Mail size={14} /> Request documents</button>}{bad.length > 0 && <button type="button" className="a8-btn" onClick={onTasks} data-testid="c115-cred-tasks"><ClipboardList size={14} /> Draft renewal tasks</button>}<button type="button" className="a8-btn" onClick={print} data-testid="c115-cred-print"><Printer size={14} /> Print / save PDF</button></div>
    {!people ? <p className="sv-small sv-muted">No providers or staff yet. Add them under People &amp; roles and Providers.</p> : bad.length === 0 ? <p className="a81-ok">Every credential is current for the next {win} days.</p> :
      <table className="sv-table c115-table"><thead><tr><th>Person</th><th>Document</th><th>Status</th><th>Date</th><th>Source</th></tr></thead><tbody>{bad.map((r, i) => <tr key={i} data-testid="c115-cred-row" data-status={r.status}><td><b>{r.who}</b><div className="sv-small sv-muted">{r.role}</div></td><td>{r.document}</td><td><span className={chip(r.status)}>{D.STATUS_LABEL[r.status]}{r.days != null && r.status !== 'missing' ? ` · ${r.days < 0 ? `${-r.days} days ago` : `in ${r.days} days`}` : ''}</span></td><td>{fmt(r.due)}</td><td className="sv-small">{r.source}</td></tr>)}</tbody></table>}
  </div>;
};

const AccredAudit: React.FC<{ rows: D.CheckRow[]; onTasks: () => void; onUpload: (it: D.CheckItem) => void }> = ({ rows, onTasks, onUpload }) => {
  const f = (() => { try { return facility(); } catch { return {} as any; } })(); const n = (s: D.AuditStatus) => rows.filter(r => r.status === s).length;
  const sections = Array.from(new Set(rows.map(r => r.section))); const need = rows.filter(r => ['expired', 'soon', 'missing'].includes(r.status));
  return <div className="c115-result" data-testid="c115-acc-result">
    <div className="v10-row"><b>{rows.length - n('optional')} required items{f.accreditor ? ` · ${f.accreditor}` : ''}</b><span className="v10-chip ok">{n('ok')} current</span><span className="v10-chip warn" data-testid="c115-acc-soon">{n('soon')} due soon</span><span className="v10-chip bad" data-testid="c115-acc-overdue">{n('expired')} overdue</span><span className="v10-chip bad" data-testid="c115-acc-missing">{n('missing')} missing</span>
      <span style={{ flex: 1 }} />{need.length > 0 && <button type="button" className="a8-btn" onClick={onTasks} data-testid="c115-acc-tasks"><ClipboardList size={14} /> Draft tasks</button>}<button type="button" className="a8-btn pri" onClick={() => printBinder(rows)} data-testid="c115-binder"><Printer size={14} /> Inspection binder</button></div>
    <p className="sv-small sv-muted">A general ASC survey list (licensure, governance, infection control, medications, emergency &amp; safety, equipment, patient rights). Confirm it against {f.accreditor || 'your accreditor'}’s current standards. Logs can be printed as blank sheets to fill in, then scanned back in.</p>
    {sections.map(sec => <div key={sec} className="c115-sec"><h4>{sec}</h4><table className="sv-table c115-table"><tbody>{rows.filter(r => r.section === sec).map(r => <tr key={r.id} data-testid="c115-acc-row" data-id={r.id} data-status={r.status}>
      <td style={{ width: '42%' }}><b>{r.title}</b>{r.hint && <div className="sv-small sv-muted">{r.hint}</div>}<div className="sv-small sv-muted">{r.every ? r.every <= 31 ? 'Monthly' : r.every <= 92 ? 'Quarterly' : r.every <= 183 ? 'Twice a year' : r.every <= 365 ? 'Every year' : 'Every 2 years' : r.expires ? 'Renews on its expiration date' : 'Keep on file'}</div></td>
      <td><span className={chip(r.status)}>{D.STATUS_LABEL[r.status]}{r.days != null && (r.status === 'soon' || r.status === 'expired') ? ` · ${r.days < 0 ? `${-r.days} days ago` : `in ${r.days} days`}` : ''}</span><div className="sv-small sv-muted">{r.source}{r.due ? ` · ${r.expires ? 'expires' : 'next due'} ${fmt(r.due)}` : ''}</div></td>
      <td style={{ textAlign: 'right', whiteSpace: 'nowrap' }}>{r.log && <button type="button" className="sv-link sv-small" onClick={() => printLogSheet(r)} data-testid={`c115-log-${r.id}`}>Blank log sheet</button>} <button type="button" className="sv-link sv-small" onClick={() => onUpload(r)} data-testid={`c115-up-${r.id}`}>{r.doc ? 'Replace' : 'Upload'}</button></td></tr>)}</tbody></table></div>)}
  </div>;
};
function printBinder(rows: D.CheckRow[]) {
  const f = (() => { try { return facility(); } catch { return {} as any; } })(); const sections = Array.from(new Set(rows.map(r => r.section)));
  const cred = D.credentialsAudit(today()); const people = Array.from(new Set(cred.map(r => `${r.who}|${r.role}|${r.owner}`)));
  printPage('Inspection binder', `<h1>Inspection binder · ${esc(f.name || 'Our facility')}</h1><p class="sub">${esc([f.address, f.city].filter(Boolean).join(', '))}${f.accreditor ? ` · ${esc(f.accreditor)}${f.accreditationNumber ? ` #${esc(f.accreditationNumber)}` : ''}` : ''} · prepared ${new Date().toLocaleDateString()}</p>
    ${sections.map((s, i) => `<h2>Tab ${i + 1} · ${esc(s)}</h2><table><tr><th>Item</th><th>Status</th><th>Document on file</th><th>Date</th></tr>${rows.filter(r => r.section === s).map(r => `<tr><td>${esc(r.title)}</td><td class="${r.status === 'ok' ? 'ok' : r.status === 'soon' ? 'warn' : r.status === 'optional' ? '' : 'bad'}">${esc(D.STATUS_LABEL[r.status])}</td><td>${esc(r.doc?.fileName || (r.status === 'missing' ? 'Missing' : r.source))}</td><td>${r.due ? `${r.expires ? 'Expires' : 'Next due'} ${fmt(r.due)}` : r.doc?.effective ? fmt(r.doc.effective) : ''}</td></tr>`).join('')}</table>`).join('')}
    <h2>Tab ${sections.length + 1} · Credential files</h2><table><tr><th>Person</th><th>Role</th><th>Current</th><th>Needs action</th></tr>${people.map(k => { const [who, role, owner] = k.split('|'); const mine = cred.filter(r => r.who === who && r.owner === owner); const badRows = mine.filter(r => ['expired', 'soon', 'missing'].includes(r.status)); return `<tr><td>${esc(who)}</td><td>${esc(role)}</td><td>${mine.filter(r => r.status === 'ok').length}</td><td class="${badRows.length ? 'bad' : 'ok'}">${badRows.length ? badRows.map(r => `${esc(r.document)} (${esc(D.STATUS_LABEL[r.status].toLowerCase())})`).join('; ') : 'None'}</td></tr>`; }).join('') || '<tr><td colspan="4">No providers or staff yet.</td></tr>'}</table>`);
}

/* ---------- upload ---------- */
const UploadDialog: React.FC<{ preset?: { owner: D.Owner; ownerId?: string; type?: string }; onClose: () => void; onDone: (m: string) => void }> = ({ preset, onClose, onDone }) => {
  const [actor] = useActor(); const provs = getProviders().filter(p => p.active); const staff = staffList().filter((s: any) => s.active !== false);
  const [owner, setOwner] = useState<D.Owner>(preset?.owner || 'facility'); const [ownerId, setOwnerId] = useState(preset?.ownerId || ''); const [type, setType] = useState(preset?.type || '');
  const [num, setNum] = useState(''); const [eff, setEff] = useState(today()); const [exp, setExp] = useState(''); const [file, setFile] = useState<{ name: string; data?: string } | null>(null); const [err, setErr] = useState('');
  const types: { value: string; label: string; expires: boolean; category: D.Category }[] = owner === 'facility' ? D.CHECKLIST.map(c => ({ value: c.id, label: `${c.section} · ${c.title}`, expires: !!c.expires, category: c.category })).concat([{ value: 'other', label: 'Other facility document', expires: false, category: 'Accreditation' }])
    : owner === 'provider' ? (() => { const p = provs.find(x => x.id === ownerId); return (p ? D.providerDocTypes(p) : []).map(t => ({ value: t.type, label: t.type, expires: t.expires, category: t.category })); })()
    : (() => { const s: any = staff.find(x => x.id === ownerId); return (s ? D.staffDocTypes(s.role) : []).map(t => ({ value: t.type, label: t.type, expires: t.expires, category: t.category })); })();
  const t = types.find(x => x.value === type);
  const pick = (f?: File) => { setErr(''); if (!f) return; if (f.size > 1.5 * 1024 * 1024) { setFile({ name: f.name }); setErr('Files over 1.5 MB are recorded by name only in this build: scan at a lower resolution to keep a copy here.'); return; } const r = new FileReader(); r.onload = () => setFile({ name: f.name, data: String(r.result) }); r.readAsDataURL(f); };
  const save = () => { setErr('');
    if (owner !== 'facility' && !ownerId) return setErr('Choose the person.'); if (!type) return setErr('Choose the document type.');
    if (t?.expires && !exp) return setErr('Enter the expiration date.'); if (!t?.expires && !eff) return setErr('Enter the date of the document.');
    const ownerName = owner === 'facility' ? practice() : owner === 'provider' ? displayName(provs.find(x => x.id === ownerId)!) : (staff.find((x: any) => x.id === ownerId) as any)?.name || '';
    D.addDoc({ owner, ownerId: owner === 'facility' ? 'facility' : ownerId, ownerName, type, category: t?.category || 'Accreditation', number: num.trim() || undefined, effective: eff || undefined, expires: exp || undefined, fileName: file?.name, dataUrl: file?.data, uploadedBy: `${actor.name} (${actor.role})` });
    onDone(`${t?.label.replace(/^.* · /, '') || type} saved for ${ownerName}.`); };
  return <DialogShell size="md" testId="c115-upload" kicker="Document register" title="Upload a compliance document" subtitle="Replacing a document keeps the earlier one in history." icon={<Upload size={20} />} onClose={onClose}
    footer={<button type="button" className="a8-btn pri" onClick={save} data-testid="c115-up-save">Save document</button>}>
    <div className="c115-grid">
      <label className="sv-small">For<select className="sv-input" value={owner} onChange={e => { setOwner(e.target.value as D.Owner); setOwnerId(''); setType(''); }} data-testid="c115-up-owner"><option value="facility">The facility</option><option value="provider">A provider</option><option value="staff">A staff member</option></select></label>
      {owner !== 'facility' && <label className="sv-small">{owner === 'provider' ? 'Provider' : 'Staff member'}<select className="sv-input" value={ownerId} onChange={e => { setOwnerId(e.target.value); setType(''); }} data-testid="c115-up-person"><option value="">Choose…</option>{owner === 'provider' ? provs.map(p => <option key={p.id} value={p.id}>{displayName(p)} · {p.role}</option>) : staff.map((s: any) => <option key={s.id} value={s.id}>{s.name} · {s.role}</option>)}</select></label>}
      <label className="sv-small" style={{ gridColumn: '1 / -1' }}>Document<select className="sv-input" value={type} onChange={e => setType(e.target.value)} data-testid="c115-up-type"><option value="">Choose…</option>{types.map(x => <option key={x.value} value={x.value}>{x.label}</option>)}</select></label>
      <label className="sv-small">Number (license, policy, certificate)<input className="sv-input" value={num} onChange={e => setNum(e.target.value)} /></label>
      <label className="sv-small">{t?.expires ? 'Issued' : 'Date of the document / log'}<input className="sv-input" type="date" value={eff} onChange={e => setEff(e.target.value)} data-testid="c115-up-eff" /></label>
      {t?.expires && <label className="sv-small">Expires<input className="sv-input" type="date" value={exp} onChange={e => setExp(e.target.value)} data-testid="c115-up-exp" /></label>}
      <label className="sv-small" style={{ gridColumn: '1 / -1' }}>File (PDF or image)<input className="sv-input" type="file" accept="application/pdf,image/*" onChange={e => pick(e.target.files?.[0])} data-testid="c115-up-file" />{file && <span className="sv-small">{file.name}</span>}</label>
    </div>
    {err && <p className="a81-err" role="alert">{err}</p>}
  </DialogShell>;
};
const openDoc = (d: D.CDoc) => { if (!d.dataUrl) return; const [h, b] = d.dataUrl.split(','); const bin = atob(b); const u8 = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) u8[i] = bin.charCodeAt(i); const url = URL.createObjectURL(new Blob([u8], { type: h.slice(5).split(';')[0] })); window.open(url, '_blank', 'noopener'); setTimeout(() => URL.revokeObjectURL(url), 60000); };
const labelOf = (d: D.CDoc) => d.owner === 'facility' ? (D.CHECKLIST.find(c => c.id === d.type)?.title || d.type) : d.type;

/** After drafting: bring the Compliance tasks list (top of the page) into view and highlight it for a moment. */
const showTasks = () => setTimeout(() => { const el = document.getElementById('compliance-tasks'); if (!el) return; el.scrollIntoView({ behavior: 'smooth', block: 'center' }); el.classList.add('flash'); setTimeout(() => el.classList.remove('flash'), 2200); }, 80);
/* ---------- document requests ---------- */
const RequestDialog: React.FC<{ drafts: R.RequestDraft[]; onClose: () => void; onDone: (m: string) => void }> = ({ drafts, onClose, onDone }) => {
  const [actor] = useActor(); const [l, setL] = useState(drafts.map(d => ({ ...d, on: !!d.email }))); const ok = l.filter(d => d.on && /^\S+@\S+\.\S+$/.test(d.email));
  const set = (i: number, p: Partial<typeof l[number]>) => setL(x => x.map((d, j) => j === i ? { ...d, ...p } : d));
  return <DialogShell size="xl" testId="c115-request" kicker="Document requests" title="Request documents by email" subtitle="One email per person, with a personal link to upload each document and its dates. Review and edit before sending." icon={<Mail size={20} />} onClose={onClose}
    footer={<><span className="sv-small sv-muted" style={{ marginRight: 'auto' }}>Not connected in this build: emails go to the outbox (Practice settings › Providers) and are not delivered yet.</span><button type="button" className="a8-btn pri" disabled={!ok.length} onClick={() => { ok.forEach(d => R.sendRequest(d, `${actor.name} (${actor.role})`)); onDone(`${ok.length} document request${ok.length === 1 ? '' : 's'} sent to the outbox. A reminder goes after 7 days if nothing comes back.`); }} data-testid="c115-req-send"><Send size={14} /> Send {ok.length} request{ok.length === 1 ? '' : 's'}</button></>}>
    {l.map((d, i) => <div key={d.owner + d.ownerId} className="c115-req" data-testid="c115-req-draft">
      <div className="v10-row"><label className="v10-row" style={{ gap: 6 }}><input type="checkbox" checked={d.on} onChange={e => set(i, { on: e.target.checked })} data-testid="c115-req-on" /><b>{d.ownerName}</b></label><span className="sv-small sv-muted">{d.items.length} item{d.items.length === 1 ? '' : 's'}</span>
        {d.already && <span className="v10-chip warn">Already requested {new Date(d.already.sentAt).toLocaleDateString()} · sending replaces it</span>}</div>
      <div className="c115-grid"><label className="sv-small">To{!d.email && <span className="a81-err"> · no email on file</span>}<input className="sv-input" type="email" value={d.email} placeholder="name@example.com" onChange={e => set(i, { email: e.target.value, on: true })} data-testid="c115-req-to" /></label>
        <label className="sv-small">Subject<input className="sv-input" value={d.subject} onChange={e => set(i, { subject: e.target.value })} /></label>
        <label className="sv-small" style={{ gridColumn: '1 / -1' }}>Message (the link replaces [secure upload link])<textarea className="sv-input" rows={9} value={d.body} onChange={e => set(i, { body: e.target.value })} data-testid="c115-req-body" /></label></div>
    </div>)}
  </DialogShell>;
};
const RequestsList: React.FC<{ onToast?: (m: string) => void }> = ({ onToast }) => {
  const l = R.requests().filter(r => !r.closed).slice(0, 30); const [open, setOpen] = useState<string | null>(null); if (!l.length) return null;
  return <div className="c115-result" data-testid="c115-requests"><h4 className="c115-h4">Document requests</h4>
    <table className="sv-table c115-table"><thead><tr><th>Sent to</th><th>Items</th><th>Status</th><th /></tr></thead><tbody>{l.map(r => <React.Fragment key={r.id}><tr data-testid="c115-request-row">
      <td><b>{r.ownerName}</b><div className="sv-small sv-muted">{r.email} · {new Date(r.sentAt).toLocaleDateString()}</div></td><td className="sv-small">{r.items.map(i => i.document).join(', ')}</td>
      <td><span className={`v10-chip ${r.submittedAt ? 'ok' : r.expiresAt <= new Date().toISOString() ? 'bad' : 'info'}`} data-testid="c115-request-status">{R.requestStatus(r)}</span>{r.submittedAt && <div className="sv-small sv-muted">{(r.submittedItems || []).length} sent {new Date(r.submittedAt).toLocaleDateString()}</div>}</td>
      <td style={{ whiteSpace: 'nowrap' }}><button type="button" className="sv-link sv-small" onClick={() => setOpen(open === r.id ? null : r.id)}>{open === r.id ? 'Hide' : 'View'} email</button> <a className="sv-link sv-small" href={R.requestLink(r.token)} target="_blank" rel="noopener" data-testid="c115-request-link">Open link</a></td></tr>
      {open === r.id && <tr><td colSpan={4}><pre className="c115-email">{`To: ${r.ownerName} <${r.email}>\nSubject: ${r.subject}\n\n${r.body}`}</pre></td></tr>}</React.Fragment>)}</tbody></table>
    <p className="sv-small sv-muted">“Open link” shows what the person sees (it works in this local build only).</p></div>;
};

export const ComplianceCenter: React.FC<{ onToast?: (m: string) => void }> = ({ onToast }) => {
  useMedTick(); const [win, setWin] = useState(30); const [cred, setCred] = useState<D.AuditRow[] | null>(null); const [acc, setAcc] = useState<D.CheckRow[] | null>(null);
  const [up, setUp] = useState<{ owner: D.Owner; ownerId?: string; type?: string } | null>(null); const [req, setReq] = useState<R.RequestDraft[] | null>(null);
  useEffect(() => { const n = R.runReminders(); if (n) onToast?.(`${n} reminder${n === 1 ? '' : 's'} sent for document requests with no reply after 7 days.`); }, []);
  const [cat, setCat] = useState<D.Category>('Accreditation'); const [hist, setHist] = useState(false); const [q, setQ] = useState('');
  const runCred = () => setCred(D.credentialsAudit(today(), win)); const runAcc = () => setAcc(D.accreditationAudit(today()));
  useEffect(() => { const f = (e: Event) => { const k = (e as CustomEvent).detail; if (k !== 'accreditation') setCred(D.credentialsAudit(today(), win)); if (k !== 'credentials') setAcc(D.accreditationAudit(today())); setTimeout(() => document.querySelector('[data-testid=c115-audits]')?.scrollIntoView({ behavior: 'smooth', block: 'start' }), 50); }; window.addEventListener('vityls-run-audit', f); return () => window.removeEventListener('vityls-run-audit', f); }, [win]);
  useEffect(() => { if (cred) runCred(); if (acc) runAcc(); /* refresh after uploads */ }, [D.cdocs().length]); // eslint-disable-line react-hooks/exhaustive-deps
  const credTasks = () => { const rows = (cred || []).filter(r => ['expired', 'soon', 'missing'].includes(r.status)); addDraftTasks(rows.map(r => ({ text: `${r.status === 'missing' ? 'Collect' : 'Renew'} ${r.document} · ${r.who}`, due: r.due && r.status === 'soon' ? r.due : undefined }))); onToast?.(`${rows.length} renewal task${rows.length === 1 ? '' : 's'} drafted in Compliance tasks. Confirm each one to make it a task.`); showTasks(); };
  const accTasks = () => { const rows = (acc || []).filter(r => ['expired', 'soon', 'missing'].includes(r.status)); addDraftTasks(rows.map(r => ({ text: `${r.status === 'missing' ? 'Add to the binder' : r.expires ? 'Renew' : 'Complete'}: ${r.title}`, due: r.status === 'soon' ? r.due : undefined }))); onToast?.(`${rows.length} accreditation task${rows.length === 1 ? '' : 's'} drafted in Compliance tasks. Confirm each one to make it a task.`); showTasks(); };
  const pend = D.pendingDocs(); const [actor] = useActor();
  const docs = (hist ? D.cdocs() : [...D.pendingDocs(), ...D.currentDocs()]).filter(d => d.category === cat).filter(d => !q.trim() || `${labelOf(d)} ${d.ownerName} ${d.fileName || ''} ${d.number || ''}`.toLowerCase().includes(q.toLowerCase()));
  return <div className="c115" data-testid="c115-center">
    <section className="v10-card" data-testid="c115-audits"><h3 className="v10-h"><ShieldCheck size={18} /> Audits</h3>
      <p className="v10-sub">Run any time. Nightingale checks every file against its dates and lists what is expired, due soon or missing; a person decides what to do.</p>
      <div className="v10-row"><button type="button" className="a8-btn pri" onClick={runCred} data-testid="c115-run-cred">Run credentials audit</button>
        <label className="sv-small">window <select className="sv-input" style={{ width: 'auto', display: 'inline-block' }} value={win} onChange={e => setWin(+e.target.value)} data-testid="c115-win"><option value={30}>30 days</option><option value={60}>60 days</option><option value={90}>90 days</option></select></label>
        <button type="button" className="a8-btn pri" onClick={runAcc} data-testid="c115-run-acc">Run accreditation audit</button></div>
      {cred && <><h4 className="c115-h4">Provider &amp; staff credentials</h4><CredAudit rows={cred} win={win} onTasks={credTasks} onRequest={() => setReq(R.draftRequests(cred))} /></>}
      <RequestsList onToast={onToast} />
      {acc && <><h4 className="c115-h4">Facility accreditation checklist</h4><AccredAudit rows={acc} onTasks={accTasks} onUpload={it => setUp({ owner: 'facility', type: it.id })} /></>}
    </section>
    {pend.length > 0 && <section className="v10-card c115-review" data-testid="c115-review"><h3 className="v10-h"><Mail size={18} /> Received documents to review ({pend.length})</h3>
      <p className="v10-sub">Sent in through a document request. Check each one; accepted documents become current and the earlier version moves to history.</p>
      <table className="sv-table c115-table"><tbody>{pend.map(d => <tr key={d.id} data-testid="c115-pending"><td><b>{labelOf(d)}</b><div className="sv-small sv-muted">{d.ownerName}{d.number ? ` · #${d.number}` : ''}</div></td>
        <td className="sv-small">{d.effective ? `Issued ${fmt(d.effective)}` : ''}{d.expires ? ` · expires ${fmt(d.expires)}` : ''}</td><td className="sv-small">{d.fileName ? (d.dataUrl ? <button type="button" className="sv-link" onClick={() => openDoc(d)}><FileText size={13} /> {d.fileName}</button> : d.fileName) : 'No file'}</td>
        <td style={{ whiteSpace: 'nowrap' }}><button type="button" className="a8-btn pri" onClick={() => { D.reviewDoc(d.id, true, `${actor.name} (${actor.role})`); onToast?.(`${labelOf(d)} accepted for ${d.ownerName}.`); }} data-testid="c115-accept"><Check size={14} /> Accept</button> <button type="button" className="a8-btn" onClick={() => { if (window.confirm(`Reject ${labelOf(d)} from ${d.ownerName}? It is removed; send a new request if you still need it.`)) D.reviewDoc(d.id, false, actor.name); }} data-testid="c115-reject">Reject</button></td></tr>)}</tbody></table></section>}
    <section className="v10-card" data-testid="c115-register"><div className="v10-row"><h3 className="v10-h" style={{ margin: 0 }}><FileCheck size={18} /> Document register</h3><span style={{ flex: 1 }} /><button type="button" className="a8-btn pri" onClick={() => setUp({ owner: 'facility' })} data-testid="c115-upload-btn"><Upload size={14} /> Upload compliance document</button></div>
      <div className="c115-tabs" role="tablist">{D.CATEGORIES.map(c => { const n = D.currentDocs().filter(d => d.category === c).length; return <button key={c} type="button" role="tab" aria-selected={cat === c} className={`v12-wtab${cat === c ? ' on' : ''}`} onClick={() => setCat(c)} data-testid={`c115-cat-${c}`}>{c} <span className="n">{n}</span></button>; })}</div>
      <div className="v10-row"><input className="sv-input" style={{ flex: 1 }} placeholder={`Search ${cat}`} value={q} onChange={e => setQ(e.target.value)} /><label className="sv-small"><input type="checkbox" checked={hist} onChange={e => setHist(e.target.checked)} /> <History size={13} /> Show earlier versions</label></div>
      {docs.length === 0 ? <p className="sv-small sv-muted" data-testid="c115-empty">Nothing in {cat} yet.</p> :
        <table className="sv-table c115-table"><thead><tr><th>Document</th><th>For</th><th>Dates</th><th>File</th><th /></tr></thead><tbody>{docs.map(d => { const s = d.expires ? (d.expires < today() ? 'expired' : d.expires <= D.addDays(today(), 30) ? 'soon' : 'ok') as D.AuditStatus : 'ok';
          return <tr key={d.id} data-testid="c115-doc" style={d.replacedBy ? { opacity: .55 } : undefined}><td><b>{labelOf(d)}</b>{d.number && <div className="sv-small sv-muted">#{d.number}</div>}{d.replacedBy && <div className="sv-small">Earlier version</div>}{d.pending && <div><span className="v10-chip warn">Waiting for review</span></div>}</td><td>{d.ownerName}</td>
            <td className="sv-small">{d.effective ? `Dated ${fmt(d.effective)}` : ''}{d.expires && <div><span className={chip(s)}>Expires {fmt(d.expires)}</span></div>}</td>
            <td className="sv-small">{d.fileName ? (d.dataUrl ? <button type="button" className="sv-link" onClick={() => openDoc(d)}><FileText size={13} /> {d.fileName}</button> : d.fileName) : '—'}<div className="sv-muted">{new Date(d.at).toLocaleDateString()} · {d.uploadedBy}</div></td>
            <td style={{ whiteSpace: 'nowrap' }}>{!d.replacedBy && <button type="button" className="sv-link sv-small" onClick={() => setUp({ owner: d.owner, ownerId: d.owner === 'facility' ? undefined : d.ownerId, type: d.type })}>Replace</button>} <button type="button" className="sv-link sv-small" aria-label="Remove (uploaded by mistake)" onClick={() => { if (window.confirm(`Remove ${labelOf(d)}${d.fileName ? ` (${d.fileName})` : ''}? Use this only for a document uploaded by mistake.`)) D.retireDoc(d.id); }}><X size={13} /></button></td></tr>; })}</tbody></table>}
    </section>
    {up && <UploadDialog preset={up} onClose={() => setUp(null)} onDone={m => { setUp(null); onToast?.(m); }} />}
    {req && <RequestDialog drafts={req} onClose={() => setReq(null)} onDone={m => { setReq(null); onToast?.(m); }} />}
  </div>;
};
