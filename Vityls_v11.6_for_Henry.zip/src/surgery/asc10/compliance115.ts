/* v11.5 · Compliance center data: the document register, the credentials audit and the facility accreditation audit.
 * Every document has an owner (a provider, a staff member or the facility), a type, and dates. Replacing a document keeps the
 * earlier one in history. The audits read the register (and, for providers, the dates in their membership application). */
import { svRead, svWrite } from '../store';
import { getProviders, displayName, type Provider } from '../../v7/providers';
import { staffList } from '../staff';
import { facility } from '../asc88/store88';

export type Owner = 'provider' | 'staff' | 'facility';
export const CATEGORIES = ['Employee Files', "Doctor's Credentials", 'Accreditation', 'Policy and Procedures', 'Logs', 'Legal', 'HR', 'Vendors', 'Manuals', 'Equipment Records', 'Financial & Audit'] as const;
export type Category = typeof CATEGORIES[number];
export interface CDoc { id: string; owner: Owner; ownerId: string; ownerName: string; type: string; category: Category; number?: string; effective?: string; expires?: string; fileName?: string; dataUrl?: string; note?: string; uploadedBy: string; at: string; replacedBy?: string; pending?: boolean; requestId?: string; reviewedBy?: string; reviewedAt?: string }
const K = 'c115-docs';
export const cdocs = (): CDoc[] => svRead<CDoc[]>(K, []);
/** Accepted documents (a document sent in through a request waits for review before it counts). */
export const currentDocs = () => cdocs().filter(d => !d.replacedBy && !d.pending);
export const pendingDocs = () => cdocs().filter(d => d.pending);
export function addDoc(d: Omit<CDoc, 'id' | 'at'>): CDoc {
  const all = cdocs(); const n: CDoc = { ...d, id: `cd-${Date.now().toString(36)}${Math.random().toString(36).slice(2, 5)}`, at: new Date().toISOString() };
  if (!n.pending) all.forEach(x => { if (!x.replacedBy && !x.pending && x.owner === n.owner && x.ownerId === n.ownerId && x.type === n.type) x.replacedBy = n.id; }); // earlier version kept in history
  svWrite(K, [n, ...all]); window.dispatchEvent(new Event('vityls-med-updated')); return n;
}
/** The administrator accepts a document sent in through a request: it becomes current, the earlier one goes to history. */
export function reviewDoc(id: string, accept: boolean, by: string) { const all = cdocs(); const d = all.find(x => x.id === id); if (!d) return;
  if (!accept) { svWrite(K, all.filter(x => x.id !== id)); window.dispatchEvent(new Event('vityls-med-updated')); return; }
  all.forEach(x => { if (x.id !== id && !x.replacedBy && !x.pending && x.owner === d.owner && x.ownerId === d.ownerId && x.type === d.type) x.replacedBy = d.id; });
  d.pending = false; d.reviewedBy = by; d.reviewedAt = new Date().toISOString(); svWrite(K, all); window.dispatchEvent(new Event('vityls-med-updated')); }
export function retireDoc(id: string) { svWrite(K, cdocs().filter(d => d.id !== id)); window.dispatchEvent(new Event('vityls-med-updated')); }

/* ---------- document types ---------- */
export interface DocType { type: string; req: boolean; expires: boolean; renewDays?: number; category: Category; why?: string }
const CLINICAL_RE = /\bRN\b|nurse|tech\b|technician|\bMA\b|medical assistant|CRNA|anesth|surgeon|physician|scrub|PACU|pre-?op|circulat/i;
const CLINICAL = { test: (r: string) => CLINICAL_RE.test(r) || /\bOR\b/.test(r) }; // "OR" only in capitals (OR nurse), never "Administrator"
const ACLS_ROLES = /PACU|pre-?op|circulat|anesth|CRNA/i;
export function providerDocTypes(p: Provider): DocType[] {
  const anes = /Anesthesiologist|CRNA/.test(p.role); const prescriber = p.role !== 'Other provider';
  return [
    { type: 'Medical / professional license', req: true, expires: true, category: "Doctor's Credentials" },
    { type: 'DEA registration', req: prescriber, expires: true, category: "Doctor's Credentials" },
    { type: 'Malpractice certificate', req: true, expires: true, category: "Doctor's Credentials" },
    { type: 'Board certification', req: false, expires: true, category: "Doctor's Credentials" },
    { type: 'ACLS', req: anes, expires: true, category: "Doctor's Credentials" },
    { type: 'Privileges approval letter', req: true, expires: false, category: "Doctor's Credentials" },
    { type: 'Reappointment (every 2 years)', req: true, expires: false, renewDays: 730, category: "Doctor's Credentials", why: 'Medical staff reappointment' },
    { type: 'CV', req: false, expires: false, category: "Doctor's Credentials" },
  ];
}
export function staffDocTypes(role: string): DocType[] {
  const clin = CLINICAL.test(role); const rn = /\bRN\b|nurse/i.test(role);
  return [
    ...(rn ? [{ type: 'RN license', req: true, expires: true, category: 'Employee Files' as Category }] : []),
    { type: 'BLS', req: clin, expires: true, category: 'Employee Files' },
    ...(ACLS_ROLES.test(role) ? [{ type: 'ACLS', req: true, expires: true, category: 'Employee Files' as Category }] : []),
    { type: 'TB screening', req: clin, expires: false, renewDays: 365, category: 'Employee Files' },
    { type: 'Hepatitis B vaccination or declination', req: clin, expires: false, category: 'Employee Files' },
    { type: 'HIPAA training', req: true, expires: false, renewDays: 365, category: 'Employee Files' },
    { type: 'OSHA bloodborne pathogens training', req: clin, expires: false, renewDays: 365, category: 'Employee Files' },
    { type: 'Annual competency', req: clin, expires: false, renewDays: 365, category: 'Employee Files' },
    { type: 'I-9 employment eligibility', req: true, expires: false, category: 'HR' },
  ];
}

/* ---------- dates ---------- */
const day = (iso?: string) => (iso || '').slice(0, 10);
export const addDays = (iso: string, n: number) => { const d = new Date(iso.slice(0, 10) + 'T12:00:00Z'); d.setUTCDate(d.getUTCDate() + n); return d.toISOString().slice(0, 10); };
const toIso = (s?: string) => { if (!s) return ''; const t = String(s).trim(); if (/^\d{4}-\d{2}-\d{2}/.test(t)) return t.slice(0, 10); const m = t.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/); return m ? `${m[3]}-${m[1].padStart(2, '0')}-${m[2].padStart(2, '0')}` : ''; };
export type AuditStatus = 'expired' | 'soon' | 'missing' | 'ok' | 'optional';
export interface AuditRow { who: string; role: string; owner: Owner; ownerId?: string; document: string; due: string; status: AuditStatus; source: string; docId?: string; days?: number }
const statusFor = (due: string, today: string, window = 30): { status: AuditStatus; days: number } => { const days = Math.round((Date.parse(due + 'T12:00:00Z') - Date.parse(today + 'T12:00:00Z')) / 864e5); return { status: days < 0 ? 'expired' : days <= window ? 'soon' : 'ok', days }; };

/* ---------- credentials audit (providers + staff) ---------- */
const APP_DATES: Record<string, string> = { 'Medical / professional license': 'licenseExp', 'DEA registration': 'deaExp', 'Malpractice certificate': 'malpracticeExp', 'Board certification': 'boardExp' };
function rowFor(who: string, role: string, owner: Owner, ownerId: string, t: DocType, today: string, window: number, appDate?: string): AuditRow {
  const d = currentDocs().find(x => x.owner === owner && x.ownerId === ownerId && x.type === t.type);
  let due = ''; let source = '';
  if (d) { due = t.expires ? day(d.expires) : t.renewDays && d.effective ? addDays(d.effective, t.renewDays) : ''; source = d.fileName ? `Document on file · ${d.fileName}` : 'Recorded in the register'; }
  else if (appDate) { due = appDate; source = 'Date from the membership application'; }
  const waiting = !d && cdocs().some(x => x.pending && x.owner === owner && x.ownerId === ownerId && x.type === t.type);
  if (!d && !appDate) return { who, role, owner, document: t.type, due: '', status: t.req ? 'missing' : 'optional', source: waiting ? 'Received · waiting for your review' : t.req ? 'Nothing on file' : 'Optional', ownerId } as AuditRow;
  if (!due) return { who, role, owner, ownerId, document: t.type, due: '', status: 'ok', source, docId: d?.id };
  const s = statusFor(due, today, window); return { who, role, owner, ownerId, document: t.type, due, ...s, source, docId: d?.id };
}
export function credentialsAudit(today: string, window = 30): AuditRow[] {
  const rows: AuditRow[] = [];
  getProviders().filter(p => p.active).forEach(p => { const a = (p.onboarding?.application || {}) as Record<string, any>;
    providerDocTypes(p).forEach(t => { const appDate = APP_DATES[t.type] ? toIso(a[APP_DATES[t.type]]) : '';
      const letter = t.type === 'Privileges approval letter' && p.app.status === 'Privileges approved';
      if (t.type === 'Reappointment (every 2 years)') { const approved = [...p.app.history].reverse().find(h => h.status === 'Privileges approved'); if (!approved) return; const due = addDays(approved.at, 730); const s = statusFor(due, today, window); rows.push({ who: displayName(p), role: p.role, owner: 'provider', ownerId: p.id, document: t.type, due, ...s, source: `Privileges approved ${day(approved.at)}` }); return; }
      if (letter) { rows.push({ who: displayName(p), role: p.role, owner: 'provider', document: t.type, due: '', status: 'ok', source: 'Created on approval' }); return; }
      rows.push(rowFor(displayName(p), p.role, 'provider', p.id, t, today, window, appDate || undefined)); }); });
  staffList().filter((s: any) => s.active !== false).forEach((s: any) => staffDocTypes(s.role).forEach(t => rows.push(rowFor(s.name, s.role, 'staff', s.id, t, today, window))));
  return rows;
}

/* ---------- facility accreditation checklist ---------- */
export interface CheckItem { id: string; section: string; title: string; every?: number; expires?: boolean; optional?: boolean; category: Category; log?: string[]; hint?: string }
const Y = 365, Q = 92, M = 31;
/** A general ASC survey checklist (AAAHC, The Joint Commission, QUAD A and CMS Conditions for Coverage share most items).
 *  Each practice confirms it against its accreditor's current standards. `log` = columns of a printable blank log sheet. */
export const CHECKLIST: CheckItem[] = [
  { id: 'lic-state', section: 'Licensure & certification', title: 'State ASC license', expires: true, category: 'Accreditation' },
  { id: 'lic-cms', section: 'Licensure & certification', title: 'CMS certification letter (CCN)', category: 'Accreditation' },
  { id: 'lic-accred', section: 'Licensure & certification', title: 'Accreditation certificate', expires: true, category: 'Accreditation' },
  { id: 'lic-clia', section: 'Licensure & certification', title: 'CLIA certificate of waiver', expires: true, category: 'Accreditation' },
  { id: 'lic-dea', section: 'Licensure & certification', title: 'Facility DEA registration', expires: true, category: 'Accreditation' },
  { id: 'lic-pharm', section: 'Licensure & certification', title: 'State pharmacy / clinic permit', expires: true, optional: true, category: 'Accreditation' },
  { id: 'lic-xray', section: 'Licensure & certification', title: 'X-ray / fluoroscopy registration', expires: true, optional: true, category: 'Accreditation', hint: 'If you use a C-arm' },
  { id: 'gov-minutes', section: 'Governance & quality', title: 'Governing body meeting minutes', every: Q, category: 'Policy and Procedures' },
  { id: 'gov-bylaws', section: 'Governance & quality', title: 'Medical staff bylaws & rules (annual review)', every: Y, category: 'Policy and Procedures' },
  { id: 'gov-qapi', section: 'Governance & quality', title: 'QAPI program and meeting minutes', every: Q, category: 'Policy and Procedures' },
  { id: 'gov-peer', section: 'Governance & quality', title: 'Peer review records', every: Q, category: 'Policy and Procedures' },
  { id: 'gov-pp', section: 'Governance & quality', title: 'Policy & procedure manual (annual review)', every: Y, category: 'Manuals' },
  { id: 'gov-incident', section: 'Governance & quality', title: 'Adverse event / incident log', every: M, category: 'Logs', log: ['Date', 'Patient / MRN', 'Event', 'Severity', 'Action taken', 'Reported to', 'Initials'] },
  { id: 'gov-grievance', section: 'Governance & quality', title: 'Patient grievance log', every: M, category: 'Logs', log: ['Date received', 'Patient', 'Grievance', 'Assigned to', 'Response date', 'Resolution', 'Initials'] },
  { id: 'ic-plan', section: 'Infection control', title: 'Infection control plan (annual review)', every: Y, category: 'Policy and Procedures' },
  { id: 'ic-hand', section: 'Infection control', title: 'Hand hygiene audits', every: M, category: 'Logs', log: ['Date', 'Area', 'Observations', 'Compliant', 'Not compliant', 'Observer'] },
  { id: 'ic-bi', section: 'Infection control', title: 'Sterilizer biological indicator log', every: M, category: 'Logs', log: ['Date', 'Sterilizer', 'Load #', 'BI lot', 'Result', 'Control', 'Initials'] },
  { id: 'ic-hld', section: 'Infection control', title: 'High-level disinfection / scope reprocessing log', every: M, optional: true, category: 'Logs', log: ['Date', 'Scope / item ID', 'Patient / MRN', 'Solution test', 'Exposure time', 'Initials'] },
  { id: 'med-fridge', section: 'Medications', title: 'Medication refrigerator temperature log', every: M, category: 'Logs', log: ['Date', 'AM temp', 'PM temp', 'In range (2–8 °C)', 'Action if out of range', 'Initials'] },
  { id: 'med-cs', section: 'Medications', title: 'Controlled substance count reconciliation', every: M, category: 'Logs', log: ['Date', 'Drug / strength', 'Opening count', 'Used', 'Wasted (witness)', 'Closing count', 'Initials ×2'] },
  { id: 'med-dea-inv', section: 'Medications', title: 'DEA biennial controlled substance inventory', every: 730, category: 'Accreditation' },
  { id: 'em-cart', section: 'Emergency & safety', title: 'Crash cart / defibrillator check log', every: M, category: 'Logs', log: ['Date', 'Seal # intact', 'Defibrillator test', 'Oxygen full', 'Suction works', 'Expired items', 'Initials'] },
  { id: 'em-mh', section: 'Emergency & safety', title: 'Malignant hyperthermia cart check & annual drill', every: Y, category: 'Logs', log: ['Date', 'Dantrolene / Ryanodex qty & exp', 'Cold IV fluids', 'Supplies complete', 'Drill done', 'Initials'] },
  { id: 'em-plan', section: 'Emergency & safety', title: 'Emergency preparedness plan (annual review)', every: Y, category: 'Policy and Procedures' },
  { id: 'em-drill', section: 'Emergency & safety', title: 'Emergency drill or tabletop exercise', every: 183, category: 'Logs', log: ['Date', 'Scenario', 'Participants', 'Duration', 'Issues found', 'Follow-up', 'Initials'] },
  { id: 'em-fire', section: 'Emergency & safety', title: 'Fire drill', every: Q, category: 'Logs', log: ['Date / time', 'Shift', 'Location', 'Evacuation time', 'Issues found', 'Conducted by'] },
  { id: 'em-marshal', section: 'Emergency & safety', title: 'Fire marshal inspection', every: Y, category: 'Accreditation' },
  { id: 'em-ext', section: 'Emergency & safety', title: 'Fire extinguisher monthly inspection', every: M, category: 'Logs', log: ['Date', 'Extinguisher #', 'Location', 'Pressure OK', 'Tag initialed', 'Inspector'] },
  { id: 'em-gen', section: 'Emergency & safety', title: 'Generator test log', every: M, category: 'Logs', log: ['Date', 'Run time (min)', 'Load %', 'Transfer OK', 'Fuel level', 'Issues', 'Initials'] },
  { id: 'em-transfer', section: 'Emergency & safety', title: 'Hospital transfer agreement', expires: true, category: 'Legal' },
  { id: 'saf-bbp', section: 'Emergency & safety', title: 'OSHA exposure control plan (annual review)', every: Y, category: 'Policy and Procedures' },
  { id: 'saf-300', section: 'Emergency & safety', title: 'OSHA 300 / 300A log (post Feb 1 – Apr 30)', every: Y, category: 'HR' },
  { id: 'saf-sds', section: 'Emergency & safety', title: 'Safety Data Sheets binder (annual review)', every: Y, category: 'Manuals' },
  { id: 'eq-biomed', section: 'Equipment', title: 'Biomedical equipment inspections (preventive maintenance)', every: Y, category: 'Equipment Records' },
  { id: 'pt-rights', section: 'Patient rights', title: 'Patient rights & responsibilities notice', every: Y, category: 'Policy and Procedures' },
  { id: 'pt-owner', section: 'Patient rights', title: 'Disclosure of physician ownership', every: Y, category: 'Policy and Procedures' },
  { id: 'pt-ad', section: 'Patient rights', title: 'Advance directive policy', every: Y, category: 'Policy and Procedures' },
  { id: 'pt-sat', section: 'Patient rights', title: 'Patient satisfaction survey review', every: Q, category: 'Policy and Procedures' },
];
export interface CheckRow extends CheckItem { status: AuditStatus; due: string; days?: number; doc?: CDoc; source: string }
export function accreditationAudit(today: string, window = 30): CheckRow[] {
  const docs = currentDocs().filter(d => d.owner === 'facility');
  const f = (() => { try { return facility(); } catch { return {} as any; } })();
  return CHECKLIST.map(it => {
    const doc = docs.find(d => d.type === it.id);
    if (!doc) { // the accreditation certificate's date can come from the facility profile
      if (it.id === 'lic-accred' && f.accreditationExpires) { const s = statusFor(f.accreditationExpires, today, window); return { ...it, ...s, due: f.accreditationExpires, source: 'Date from the facility profile (upload the certificate)' }; }
      return { ...it, status: it.optional ? 'optional' : 'missing', due: '', source: it.optional ? 'Optional · only if it applies' : 'Nothing on file' };
    }
    const due = it.expires ? day(doc.expires) : it.every && doc.effective ? addDays(doc.effective, it.every) : '';
    if (!due) return { ...it, status: 'ok', due: '', doc, source: doc.fileName || 'Recorded' };
    const s = statusFor(due, today, it.every && it.every <= M ? 7 : window); return { ...it, ...s, due, doc, source: doc.fileName || 'Recorded' };
  });
}
export const STATUS_LABEL: Record<AuditStatus, string> = { expired: 'Expired / overdue', soon: 'Due within 30 days', missing: 'Missing', ok: 'Current', optional: 'Optional' };
