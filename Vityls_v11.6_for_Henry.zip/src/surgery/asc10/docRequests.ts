/* v11.5 · Document requests: one email per provider or staff member listing everything of theirs that is missing or expiring,
 * with a personal link (works until it is used or expires in 14 days) to upload the documents and enter their dates.
 * What they send waits in the register for the administrator to accept. A reminder goes 7 days after the request (and
 * once more 7 days later) if nothing has been sent. Emails go to the Medical Staff Office outbox (not connected in this build). */
import { svRead, svWrite } from '../store';
import { getProviders, displayName } from '../../v7/providers';
import { pushOutbox } from '../../v7/invitations';
import { staffList } from '../staff';
import { facility } from '../asc88/store88';
import { repo } from '../../v6/dataLayer';
import type { AuditRow, Owner } from './compliance115';

export interface ReqItem { document: string; status: 'expired' | 'soon' | 'missing'; due: string }
export interface DocRequest { id: string; token: string; owner: Owner; ownerId: string; ownerName: string; email: string; items: ReqItem[]; subject: string; body: string;
  sentAt: string; sentBy: string; expiresAt: string; reminders: string[]; submittedAt?: string; submittedItems?: string[]; closed?: boolean }
const K = 'c115-requests';
export const requests = (): DocRequest[] => svRead<DocRequest[]>(K, []);
const save = (l: DocRequest[]) => { svWrite(K, l); window.dispatchEvent(new Event('vityls-med-updated')); };
const tok = () => { const a = new Uint8Array(16); try { crypto.getRandomValues(a); } catch { for (let i = 0; i < 16; i++) a[i] = Math.floor(Math.random() * 256); } return Array.from(a, b => b.toString(16).padStart(2, '0')).join(''); };
export const requestLink = (token: string) => `${location.href.split('#')[0].split('?')[0]}#docs=${token}`;
export const parseRequestHash = (h = location.hash) => { const m = h.match(/^#docs=([a-f0-9]{16,64})$/i); return m ? m[1] : null; };
const practice = () => { try { return facility().name || 'Our facility'; } catch { return 'Our facility'; } };
const usDate = (iso: string) => iso ? new Date(iso + 'T12:00:00').toLocaleDateString() : '';
export const openRequestFor = (owner: Owner, ownerId: string) => requests().find(r => r.owner === owner && r.ownerId === ownerId && !r.closed && !r.submittedAt && r.expiresAt > new Date().toISOString());

export interface RequestDraft { owner: Owner; ownerId: string; ownerName: string; email: string; items: ReqItem[]; subject: string; body: string; already?: DocRequest }
/** One draft per person from the audit rows that need action. People without an email are returned with email ''. */
export function draftRequests(rows: AuditRow[]): RequestDraft[] {
  const need = rows.filter(r => (r.status === 'expired' || r.status === 'soon' || r.status === 'missing') && r.ownerId && r.owner !== 'facility');
  const by = new Map<string, AuditRow[]>(); need.forEach(r => { const k = `${r.owner}|${r.ownerId}`; by.set(k, [...(by.get(k) || []), r]); });
  return [...by.entries()].map(([k, rs]) => { const [owner, ownerId] = k.split('|') as [Owner, string];
    const p = owner === 'provider' ? getProviders().find(x => x.id === ownerId) : undefined; const s: any = owner === 'staff' ? staffList().find((x: any) => x.id === ownerId) : undefined;
    const name = p ? displayName(p) : s?.name || rs[0].who; const email = (p?.email || s?.email || '').trim();
    const greet = p && /^(MD|DO|DPM|DDS|DMD)$/i.test(p.degree) ? `Dr. ${p.lastName}` : name.split(/[ ,]/)[0];
    const items: ReqItem[] = rs.map(r => ({ document: r.document, status: r.status as ReqItem['status'], due: r.due }));
    const line = (i: ReqItem) => `  • ${i.document}${i.status === 'missing' ? ' (not on file)' : i.status === 'expired' ? ` (expired ${usDate(i.due)})` : ` (expires ${usDate(i.due)})`}`;
    const subject = `${practice()} — documents needed for your ${owner === 'provider' ? 'credentialing file' : 'employee file'}`;
    const body = `Dear ${greet},\n\nTo keep your ${owner === 'provider' ? 'credentialing file' : 'employee file'} at ${practice()} complete and current, please send us the following:\n\n${items.map(line).join('\n')}\n\nUse the secure link below to upload each document and enter its dates. The link is personal to you and expires in 14 days.\n\n[secure upload link]\n\nIf you have already sent any of these, thank you, and please disregard that item.\n\n${practice()} · ${owner === 'provider' ? 'Medical Staff Office' : 'Administration'}`;
    return { owner, ownerId, ownerName: name, email, items, subject, body, already: openRequestFor(owner, ownerId) }; });
}
/** Sends one request (to the outbox). Returns the request. */
export function sendRequest(d: RequestDraft, by: string): DocRequest {
  const token = tok(); const now = new Date(); const link = requestLink(token);
  const r: DocRequest = { id: `DR-${now.getTime().toString(36).toUpperCase()}`, token, owner: d.owner, ownerId: d.ownerId, ownerName: d.ownerName, email: d.email, items: d.items, subject: d.subject,
    body: d.body.replace('[secure upload link]', link), sentAt: now.toISOString(), sentBy: by, expiresAt: new Date(now.getTime() + 14 * 864e5).toISOString(), reminders: [] };
  const l = requests().map(x => x.owner === d.owner && x.ownerId === d.ownerId && !x.closed && !x.submittedAt ? { ...x, closed: true } : x); // a new request replaces an older open one
  save([r, ...l]);
  pushOutbox({ id: r.id, kind: 'doc-request', providerId: d.owner === 'provider' ? d.ownerId : '', to: d.email, toName: d.ownerName, from: `${practice()} ${d.owner === 'provider' ? 'Medical Staff Office' : 'Administration'} <no-reply@vityls.local>`,
    subject: r.subject, body: r.body, links: {}, sentAt: r.sentAt, sentBy: by, transport: '', resend: false, expiresAt: r.expiresAt });
  repo.audit({ caseId: 'practice', user: by, role: '', action: 'compliance.request' as any, detail: `Document request sent to ${d.ownerName} <${d.email}>: ${d.items.map(i => i.document).join(', ')}` });
  return r;
}
/** Reminders: 7 days after the request and again 7 days later, while nothing has been sent and the link is still valid. */
export function runReminders(now = new Date()): number {
  let n = 0; const l = requests().map(r => {
    if (r.closed || r.submittedAt || r.expiresAt <= now.toISOString() || r.reminders.length >= 2) return r;
    const last = Date.parse(r.reminders[r.reminders.length - 1] || r.sentAt); if (now.getTime() - last < 7 * 864e5) return r;
    n++; const at = now.toISOString();
    pushOutbox({ id: `${r.id}-R${r.reminders.length + 1}`, kind: 'doc-request', providerId: r.owner === 'provider' ? r.ownerId : '', to: r.email, toName: r.ownerName, from: `${practice()} <no-reply@vityls.local>`,
      subject: `Reminder: ${r.subject}`, body: `This is a reminder of our request below. The link stays valid until ${new Date(r.expiresAt).toLocaleDateString()}.\n\n${r.body}`, links: {}, sentAt: at, sentBy: 'Vityls (automatic reminder)', transport: '', resend: true, expiresAt: r.expiresAt });
    return { ...r, reminders: [...r.reminders, at] }; });
  if (n) save(l); return n;
}
export const requestByToken = (t: string) => requests().find(r => r.token === t);
/** Called by the upload page when the person sends their documents. */
export function markSubmitted(token: string, items: string[]) { save(requests().map(r => r.token === token ? { ...r, submittedAt: new Date().toISOString(), submittedItems: items } : r)); }
export const requestStatus = (r: DocRequest) => r.submittedAt ? 'Received' : r.closed ? 'Replaced' : r.expiresAt <= new Date().toISOString() ? 'Link expired' : r.reminders.length ? `Sent · ${r.reminders.length} reminder${r.reminders.length === 1 ? '' : 's'}` : 'Sent';
