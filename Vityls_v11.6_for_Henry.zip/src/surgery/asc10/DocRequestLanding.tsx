/* v11.5 · The page a provider or staff member opens from a document request email (#docs=<token>).
 * They upload each requested document and enter its number and dates; what they send waits for the administrator's review. */
import React, { useState } from 'react';
import { Upload, ShieldCheck, Check } from 'lucide-react';
import * as R from './docRequests';
import * as D from './compliance115';
import { getProviders } from '../../v7/providers';
import { staffList } from '../staff';
import { facility } from '../asc88/store88';

interface Entry { file?: { name: string; data?: string }; number: string; issued: string; expires: string; skip: boolean }
export const DocRequestLanding: React.FC<{ token: string }> = ({ token }) => {
  const r = R.requestByToken(token); const fac = (() => { try { return facility(); } catch { return {} as any; } })();
  const types = (() => { if (!r) return [] as D.DocType[]; if (r.owner === 'provider') { const p = getProviders().find(x => x.id === r.ownerId); return p ? D.providerDocTypes(p) : []; } const s: any = staffList().find((x: any) => x.id === r.ownerId); return s ? D.staffDocTypes(s.role) : []; })();
  const [e, setE] = useState<Record<string, Entry>>(() => Object.fromEntries((r?.items || []).map(i => [i.document, { number: '', issued: '', expires: '', skip: false }])));
  const [err, setErr] = useState(''); const [done, setDone] = useState(!!r?.submittedAt);
  const shell = (body: React.ReactNode) => <div className="c115-landing"><div className="c115-landing-card"><div className="c115-landing-head">{fac.logo ? <img src={fac.logo} alt="" /> : <ShieldCheck size={26} />}<div><b>{fac.name || 'Your facility'}</b><div className="sv-small sv-muted">Secure document upload</div></div></div>{body}</div></div>;
  if (!r) return shell(<p data-testid="c115-landing-bad">This link is not valid. Ask the office to send a new one.</p>);
  if (r.closed) return shell(<p data-testid="c115-landing-bad">This request was replaced by a newer one. Please use the link in the most recent email.</p>);
  if (done) return shell(<div data-testid="c115-landing-done"><h2 className="c115-landing-h"><Check size={22} /> Thank you</h2><p>Your documents were sent to {fac.name || 'the office'}. They will review them and contact you if anything else is needed. You can close this page.</p></div>);
  if (r.expiresAt <= new Date().toISOString()) return shell(<p data-testid="c115-landing-bad">This link expired on {new Date(r.expiresAt).toLocaleDateString()}. Ask the office to send a new one.</p>);
  const set = (k: string, p: Partial<Entry>) => setE(x => ({ ...x, [k]: { ...x[k], ...p } }));
  const pick = (k: string, f?: File) => { if (!f) return; if (f.size > 1.5 * 1024 * 1024) { setErr(`${f.name} is over 1.5 MB. Take a photo or scan at a lower resolution.`); return; } setErr(''); const rd = new FileReader(); rd.onload = () => set(k, { file: { name: f.name, data: String(rd.result) } }); rd.readAsDataURL(f); };
  const submit = () => { setErr('');
    const ready = r.items.filter(i => !e[i.document].skip);
    for (const i of ready) { const t = types.find(x => x.type === i.document); const v = e[i.document];
      if (!v.file) return setErr(`Upload a file for “${i.document}”, or tick “I can’t provide this now”.`);
      if (t?.expires && !v.expires) return setErr(`Enter the expiration date for “${i.document}”.`);
      if (!t?.expires && !v.issued) return setErr(`Enter the date of “${i.document}”.`); }
    if (!ready.length) return setErr('Upload at least one document, or contact the office.');
    ready.forEach(i => { const t = types.find(x => x.type === i.document); const v = e[i.document];
      D.addDoc({ owner: r.owner, ownerId: r.ownerId, ownerName: r.ownerName, type: i.document, category: t?.category || (r.owner === 'provider' ? "Doctor's Credentials" : 'Employee Files'), number: v.number.trim() || undefined, effective: v.issued || undefined, expires: v.expires || undefined, fileName: v.file?.name, dataUrl: v.file?.data, uploadedBy: `${r.ownerName} (document request)`, pending: true, requestId: r.id }); });
    R.markSubmitted(token, ready.map(i => i.document)); setDone(true); };
  return shell(<div data-testid="c115-landing">
    <h2 className="c115-landing-h">Documents requested for {r.ownerName}</h2>
    <p className="sv-small">Upload a clear photo or PDF of each document and enter its dates. This link is personal to you and expires on {new Date(r.expiresAt).toLocaleDateString()}.</p>
    {r.items.map(i => { const t = types.find(x => x.type === i.document); const v = e[i.document]; return <div key={i.document} className={`c115-req${v.skip ? ' skip' : ''}`} data-testid="c115-landing-item">
      <div className="v10-row"><b>{i.document}</b><span className="sv-small sv-muted">{i.status === 'missing' ? 'Not on file' : i.status === 'expired' ? `Expired ${new Date(i.due + 'T12:00:00').toLocaleDateString()}` : `Expires ${new Date(i.due + 'T12:00:00').toLocaleDateString()}`}</span></div>
      {!v.skip && <div className="c115-grid">
        <label className="sv-small" style={{ gridColumn: '1 / -1' }}><span className="c115-file"><Upload size={14} /> {v.file ? v.file.name : 'Choose a photo or PDF'}<input type="file" accept="application/pdf,image/*" capture="environment" onChange={x => pick(i.document, x.target.files?.[0])} data-testid="c115-landing-file" /></span></label>
        <label className="sv-small">Number (if any)<input className="sv-input" value={v.number} onChange={x => set(i.document, { number: x.target.value })} /></label>
        <label className="sv-small">{t?.expires ? 'Issued' : 'Date of the document'}<input className="sv-input" type="date" value={v.issued} onChange={x => set(i.document, { issued: x.target.value })} data-testid="c115-landing-issued" /></label>
        {t?.expires && <label className="sv-small">Expires<input className="sv-input" type="date" value={v.expires} onChange={x => set(i.document, { expires: x.target.value })} data-testid="c115-landing-expires" /></label>}
      </div>}
      <label className="sv-small"><input type="checkbox" checked={v.skip} onChange={x => set(i.document, { skip: x.target.checked })} data-testid="c115-landing-skip" /> I can’t provide this now</label>
    </div>; })}
    {err && <p className="a81-err" role="alert" data-testid="c115-landing-err">{err}</p>}
    <button type="button" className="a8-btn pri" onClick={submit} data-testid="c115-landing-send">Send documents</button>
  </div>);
};
