/* ASC.Vityls v10.1 · Settings regrouped into the 8 groups of design doc §13.2 (same order as the onboarding wizard),
 * the Onboarding Wizard (§13.1), each surgeon's standing pre-/post-op list editor, vendor connectors behind the BAA
 * gate, an audit-log viewer and the question-bank library. Fictional data only. */
import { ChecklistsPage } from '../asc107/checklists107';
import { isAscEd, isMedical } from '../../edition';
import { DailyEmailSettings } from '../../os/notify/dailySchedule';
import { OfficeBankPage } from '../office11/bank11';
import React, { useEffect, useState } from 'react';
import { FacilitySettings } from '../asc88/ui88';
import { useActor, useMedTick } from '../../med/ui';
import { getSettings, saveSettings } from '../../med/settings';
import { useSv, type SvTab } from '../ui';
import { Sign } from '../asc82/benches';
import { surgeonList as surgeonNames } from '../asc83/booking';
import { surgeonList, saveSurgeonList, type Phase, type ListItem } from './store10';
import * as C from '../../connectors';
import { BaaPage, baaSigned, baaSignature } from './baa11';
import * as P from '../../core/practices';
import { isCoreBuild, useCoreTick } from '../../core/useCore';
import { MOD } from '../../core/modules';
import { applyPlan, addLead, PLAN_LABEL, PLAN_PRICE } from './console10';
import * as E from './bank/engine';
import { svRead, svWrite } from '../store';
import { ChevronRight } from 'lucide-react';
import { GROUP_ICON, rememberPick, useGroupScroll } from './practiceFrame';

const ADMIN = ['Practice Administrator', 'Practice Manager', 'Administrator'];
type Item = { label: string; sub: string; tab: SvTab };
const ASC_GROUPS_DEF: { n: number; title: string; icon: string; desc?: string; items: Item[] }[] = [
  { n: 1, title: 'Practice profile', icon: 'careteam', desc: 'Who you are: the facility record behind every invoice and packet.', items: [{ label: 'Facility profile', sub: 'Name, logo, address, Medical Director, tablet idle time', tab: 'profile' }] },
  { n: 2, title: 'Rooms & hours', icon: 'block', desc: 'Rooms, opening hours and how the schedule is laid out.', items: [{ label: 'Rooms, hours & schedule', sub: 'Operating rooms, hours, visit types and colors, schedule columns, block time', tab: 'surgery-settings' }] },
  { n: 3, title: 'People & roles', icon: 'careteam', desc: 'Everyone who signs in, and how they are invited.', items: [{ label: 'Staff, roles & invitations', sub: 'Staff, invitation links, roles, PIN reset and unlock', tab: 'staff' }] },
  { n: 4, title: 'Surgeons & standing orders', icon: 'form', desc: 'Providers, their credentials and the orders they start from.', items: [{ label: 'Providers & credentialing', sub: 'Surgeons, anesthesia, PAs; signature PINs', tab: 'people' }, { label: 'Standard pre-op & post-op orders', sub: 'The facility standard for every surgeon; a surgeon can save their own version', tab: 'v10-lists' as SvTab }] },
  { n: 5, title: 'Forms & consents', icon: 'form', desc: 'What patients and staff fill in, and at which station.', items: [{ label: 'Form library & stations', sub: 'My Forms, Form Studio, station assignments and signers', tab: 'forms' }, { label: 'Station checklists', sub: 'What each station asks: standard items plus your facility items from the form library', tab: 'v10-checklists' as SvTab }, { label: 'Form questions', sub: 'Every form field is asked once per surgery', tab: 'v10-bank' as SvTab }] },
  { n: 6, title: 'Billing & fees', icon: 'block', desc: 'Fees, payment terms and billing.', items: [{ label: 'Billing & fee schedule', sub: 'Billing configuration, fee schedule, payment types', tab: 'billing-settings' }] },
  { n: 7, title: 'Nightingale & notifications', icon: 'careteam', desc: 'How Nightingale behaves and how patients are reminded.', items: [{ label: 'Next-day schedule email', sub: 'Every surgeon gets tomorrow’s cases by email at 2:00 PM', tab: 'v10-daily' }, { label: 'Nightingale, reminders & labs', sub: 'Nightingale behavior, reminders, lab descriptions, risk triggers', tab: 'med-settings' }] },
  { n: 8, title: 'Security & audit', icon: 'audit', desc: 'Audit trail, records, accreditation and agreements.', items: [{ label: 'Audit log', sub: 'Every change, sign-in and signature', tab: 'v10-audit' as SvTab }, { label: 'Patient records admin', sub: 'Hidden and deleted charts, document types', tab: 'records-admin' }, { label: 'Accreditation & documents', sub: 'Policies, manuals, credentials, renewal tracking', tab: 'documents' }, { label: 'Medical Director', sub: 'Designation, privileges review, attestations', tab: 'medical-director' as SvTab }, { label: 'Vityls BAA', sub: 'Your Business Associate Agreement with Vityls', tab: 'v11-baa' as SvTab }] },
];
/** v11.2 · the same eight-step setup for Surgery.Vityls and Medical.Vityls (office pages; scheduling stays the office's own). */
const OFFICE_GROUPS: typeof ASC_GROUPS_DEF = [
  { n: 1, title: 'Practice profile', icon: 'careteam', desc: 'Who you are: name, logo and contact details on every printed document.', items: [{ label: 'Practice profile & logo', sub: 'Logo, name, address, phone, hours', tab: 'profile' }] },
  { n: 2, title: 'Rooms, visit types & reminders', icon: 'block', desc: 'Exam rooms, visit types and colors, intake lists and appointment reminders.', items: [{ label: 'Visit types, intake lists & reminders', sub: isMedical ? 'Schedule colors, durations, payment types, referral sources, reminders' : 'Schedule colors, durations, payment types, referral sources, reminders, surgical modules, surgery centers', tab: 'surgery-settings' }, { label: 'Exam & procedure rooms', sub: 'Rooms and office hours', tab: 'profile' }] },
  { n: 3, title: 'People & roles', icon: 'careteam', desc: 'Everyone who signs in, and how they are invited.', items: [{ label: 'Staff, coordinators & invitations', sub: 'Front desk, MAs, nurses, coordinators, managers; one PIN per person', tab: 'staff' }] },
  { n: 4, title: isMedical ? 'Doctors & providers' : 'Surgeons & providers', icon: 'form', desc: 'Providers, their credentials and signature PINs.', items: [{ label: 'Providers', sub: isMedical ? 'Physicians, NPs and PAs; signature PINs' : 'Surgeons, physicians, NPs and PAs; signature PINs', tab: 'people' }] },
  { n: 5, title: 'Forms, stations & questions', icon: 'form', desc: 'What patients and staff fill in, and at which station.', items: [{ label: 'Forms & workflow', sub: 'My Forms, form editor, station assignments and signers', tab: 'forms' }, { label: 'Station checklists', sub: 'Check-in, Nurse / MA, provider and Checkout: your own items', tab: 'v10-checklists' as SvTab }, { label: 'Question bank', sub: 'Groups on or off, wording, options, which station asks it', tab: 'v10-bank' as SvTab }] },
  { n: 6, title: 'Billing, fees & reports', icon: 'block', desc: 'Fees, payments and practice reports.', items: [...(isMedical ? [{ label: 'Billing & payments', sub: 'Invoices, payments, ledger, fee schedule', tab: 'billing-hub' as SvTab }] : [{ label: 'Billing settings', sub: 'Billing configuration and the practice fee per visit type', tab: 'billing-settings' as SvTab }]), { label: 'Practice performance & reports', sub: isMedical ? 'Visits, diagnoses & plans, collections' : 'Visits, surgeries, ASC utilization, collections', tab: 'ops-hub' as SvTab }] },
  { n: 7, title: 'Nightingale & notifications', icon: 'careteam', desc: 'How Nightingale behaves and how patients and providers are reminded.', items: [{ label: 'Next-day schedule email', sub: 'Every doctor and surgeon gets tomorrow’s appointments by email at 2:00 PM', tab: 'v10-daily' as SvTab }, { label: isMedical ? 'Medical.Vityls settings' : 'Surgery.Vityls settings', sub: 'Fee schedule, result release, risk triggers, lab descriptions, portal', tab: 'med-settings' }] },
  { n: 8, title: 'Security & audit', icon: 'audit', desc: 'Audit trail, records, policies and agreements.', items: [{ label: 'Audit log', sub: 'Every change, sign-in and signature', tab: 'v10-audit' as SvTab }, { label: 'Patient records', sub: 'Document types; hidden and deleted charts', tab: 'records-admin' }, { label: 'Policies & manuals', sub: 'Office policies and documents', tab: 'documents' }, { label: 'Vityls BAA', sub: 'Your Business Associate Agreement with Vityls', tab: 'v11-baa' as SvTab }] },
];
/** The eight setup groups of this edition (the home page, the page frame and the onboarding wizard all use it). */
export const ASC_GROUPS = isAscEd ? ASC_GROUPS_DEF : OFFICE_GROUPS;
/** v11.5 · the setup wizard skips Security & audit (still on Practice settings): Plan, steps 1–7, Go live. */
export const WIZ_GROUPS = ASC_GROUPS.filter(g => g.n !== 8);
export const WIZ_GO_LIVE = WIZ_GROUPS.length + 1;
/** Steps not marked done (for the go-live page and the administrator's reminder after go-live). */
export const setupGaps = () => { const o = onboarding(); return [{ n: 0, title: 'Plan' }, ...WIZ_GROUPS.map(g => ({ n: g.n, title: g.title }))].filter(x => !o.done.includes(x.n)); };
export const onboarding = () => svRead<{ done: number[]; plan?: string; finished?: string; step?: number; visited?: string[] }>('asc10-onboarding', { done: [] });
const saveOnb = (o: ReturnType<typeof onboarding>) => svWrite('asc10-onboarding', o);
/* v11.5 · wizard ↔ settings pages: the step the person came from (this tab only), pages already opened, done + next. */
const WIZ_KEY = 'vityls:wizard-step';
export const wizardStep = (): number | null => { try { const v = sessionStorage.getItem(WIZ_KEY); return v ? Number(v) : null; } catch { return null; } };
export const setWizardStep = (n: number | null) => { try { if (n == null) sessionStorage.removeItem(WIZ_KEY); else sessionStorage.setItem(WIZ_KEY, String(n)); } catch { /* */ } };
export const wizardVisit = (label: string) => { const o = onboarding(); if (!(o.visited || []).includes(label)) saveOnb({ ...o, visited: [...(o.visited || []), label] }); };
export function wizardMarkDone(n: number, goTo?: number) { const o = onboarding(); saveOnb({ ...o, done: [...new Set([...o.done, n])], ...(goTo != null ? { step: goTo } : {}) }); }
export const wizardGoStep = (n: number) => { const o = onboarding(); saveOnb({ ...o, step: n }); };

export const AscPracticeHome: React.FC = () => { useMedTick(); useCoreTick(); useGroupScroll(); const { setTab } = useSv(); const o = onboarding();
  const center = getSettings().practiceName; const setupDone = ASC_GROUPS.filter(g => o.done.includes(g.n)).length;
  const open = (tab: SvTab, label: string) => { rememberPick(tab, label); setTab(tab); };
  const gaps = o.finished ? setupGaps() : [];
  return <div className="pset-home" data-testid="v10-settings">
    {gaps.length > 0 && <div className="pset-gaps" role="status" data-testid="pset-gaps"><b>Setup not finished</b> · {gaps.map(g => g.title).join(', ')}. <button type="button" className="sv-link" onClick={() => { const x = onboarding(); svWrite('asc10-onboarding', { ...x, step: gaps[0].n }); setTab('v10-onboard' as SvTab); }} data-testid="pset-gaps-open">Finish in the setup wizard</button></div>}
    <header className="pset-hero">
      <div><div className="pset-kicker">Practice</div><h1 className="pset-title xl">Practice settings</h1>
        <p className="pset-lede">How {center || (isAscEd ? 'this surgery center' : 'this practice')} is set up. The eight groups follow the order of the onboarding wizard.</p></div>
      {isCoreBuild && <button type="button" className="a8-btn" onClick={() => open('modules' as SvTab, 'Modules & plan')} data-testid="v10-open-modules">Modules & plan</button>}
    </header>
    <section className="pset-setup" data-testid="v10-onb-card" aria-label="Onboarding wizard">
      <div className="pset-setup-text"><div className="pset-row"><b>Onboarding wizard</b><span className={`v10-chip ${o.finished ? 'ok' : 'warn'}`}>{o.finished ? 'Finished' : `${o.done.length} of 8 steps`}</span></div>
        <ol className="pset-steps" aria-label="Setup groups">{ASC_GROUPS.map(g => <li key={g.n} className={o.done.includes(g.n) ? 'done' : ''} title={`${g.n}. ${g.title}${o.done.includes(g.n) ? ' · done' : ''}`}><span className="sr-only">{g.n}. {g.title}{o.done.includes(g.n) ? ', done' : ', not done'}</span></li>)}</ol>
        <p className="pset-small">{o.finished ? 'Go-live review requested. You can still change any setting below.' : `${setupDone} of ${ASC_GROUPS.length} groups marked done. Open the wizard to work through them in order.`}</p></div>
      <button type="button" className="a8-btn pri" onClick={() => open('v10-onboard' as SvTab, 'Onboarding wizard')} data-testid="v10-open-wizard">{o.finished ? 'Review' : 'Continue setup'}</button>
    </section>
    <div className="pset-groups" data-testid="v10-groups">{ASC_GROUPS.map(g => { const Ico = GROUP_ICON[g.n]; const done = o.done.includes(g.n);
      return <section key={g.n} className={`pset-group${done ? ' done' : ''}`} data-testid="v10-group" data-n={g.n} aria-labelledby={`pset-g${g.n}`}>
        <header className="pset-group-head"><span className="pset-ico" aria-hidden><Ico size={20} strokeWidth={1.8} /></span>
          <div className="pset-group-text"><h2 id={`pset-g${g.n}`} className="pset-group-title"><span className="pset-num">{g.n}</span>{g.title}</h2>{g.desc && <p>{g.desc}</p>}</div>
          {done && <span className="v10-chip ok pset-done">Done</span>}</header>
        <ul className="pset-items">{g.items.map(i => <li key={i.label}><button type="button" className="pset-item" onClick={() => open(i.tab, i.label)} data-testid={`prac-${i.tab}`}>
          <span className="pset-item-text"><b>{i.label}</b><span>{i.sub}</span></span><ChevronRight className="pset-go" size={18} aria-hidden /></button></li>)}</ul>
      </section>; })}</div>
    <p className="pset-foot">Practice Intelligence and Billing & Payments are working pages in the sidebar, not settings.</p></div>; };

/* ---------- surgeon standing lists editor ---------- */
export const ListsEditor: React.FC = () => { useMedTick(); const [actor] = useActor(); const names = surgeonNames(); const [sur, setSur] = useState(names[0] || ''); const [phase, setPhase] = useState<Phase>('pre');
  const cur = surgeonList(sur, phase); const [items, setItems] = useState<ListItem[]>(cur?.items || []); const [k, setK] = useState(`${sur}|${phase}`); const [txt, setTxt] = useState(''); const [msg, setMsg] = useState('');
  if (k !== `${sur}|${phase}`) { setK(`${sur}|${phase}`); setItems(surgeonList(sur, phase)?.items || []); }
  if (!names.length) return <div className="v10-empty" data-testid="v10-lists-empty"><b>No surgeons yet</b><p>Add surgeons under Providers first.</p></div>;
  return <div className="v10-page" data-testid="v10-lists"><h1 className="sv-title" data-ps-legacy="">Standard pre-op & post-op orders</h1>
    <p className="v10-sub">Every surgeon starts with the facility standard orders from the form library. Edit and save to give this surgeon their own version; it applies only to cases that have not reached nursing yet. Nursing uses the pre-op orders and PACU the post-op orders.</p>
    <div className="v10-row"><select className="sv-input" value={sur} onChange={e => setSur(e.target.value)} data-testid="v10-lists-surgeon">{names.map(n => <option key={n}>{n}</option>)}</select>
      <div className="v10-tabs">{(['pre', 'post'] as Phase[]).map(p => <button key={p} type="button" className={phase === p ? 'on' : ''} onClick={() => setPhase(p)} data-testid={`v10-lists-${p}`}>{p === 'pre' ? 'Pre-op' : 'Post-op'}</button>)}</div>
      <span className="v10-chip info" data-testid="v10-lists-version">{cur.version ? `Own version v${cur.version} · ${cur.updatedBy}` : 'Facility standard'}</span></div>
    <div className="v10-card">{!items.length && <p className="v10-sub" data-testid="v10-lists-none">No items yet.</p>}
      {items.map((i, n) => <div key={i.id} className="v10-row" data-testid="v10-lists-item"><input className="sv-input" value={i.text} onChange={e => setItems(items.map(x => x.id === i.id ? { ...x, text: e.target.value } : x))} style={{ flex: 1 }} />
        <button type="button" className="a8-btn" disabled={!n} onClick={() => { const c = items.slice(); [c[n - 1], c[n]] = [c[n], c[n - 1]]; setItems(c); }} aria-label="Move up">↑</button>
        <button type="button" className="a8-btn danger" onClick={() => setItems(items.filter(x => x.id !== i.id))} data-testid="v10-lists-del">Remove</button></div>)}
      <div className="v10-row"><input className="sv-input" value={txt} onChange={e => setTxt(e.target.value)} placeholder="e.g. SCDs on before transfer to the OR" style={{ flex: 1 }} data-testid="v10-lists-new" />
        <button type="button" className="a8-btn" onClick={() => { if (!txt.trim()) return; setItems([...items, { id: `i${Date.now().toString(36)}`, text: txt.trim() }]); setTxt(''); }} data-testid="v10-lists-add">Add</button></div></div>
    <div className="v10-row"><button type="button" className="a8-btn pri" onClick={() => { saveSurgeonList(sur, phase, items, actor.name, actor.role); setMsg('Saved as a new version.'); }} data-testid="v10-lists-save">Save new version</button>{msg && <span className="a81-ok" data-testid="v10-lists-saved">{msg}</span>}</div></div>; };

/* ---------- vendor connectors behind the BAA gate ---------- */
export const ConnectorsPage: React.FC = () => { useMedTick(); const [actor] = useActor(); const [ed, setEd] = useState<C.ConnectorId | ''>(''); const [vals, setVals] = useState<Record<string, string>>({}); const [err, setErr] = useState(''); const [, f] = useState(0); const b = C.baa();
  return <div className="v10-page" data-testid="v10-connectors"><h1 className="sv-title" data-ps-legacy="">Vendor connectors</h1>
    <div className={`v10-card ${b.centerSignedAt ? '' : 'v10-warnbox'}`} data-testid="v10-baa"><div className="v10-row"><b>Business associate agreement (BAA)</b>{b.centerSignedAt ? <span className="v10-chip ok" data-testid="v10-baa-signed">Recorded · {b.centerSignedBy}</span> : <span className="v10-chip warn">Not signed</span>}</div>
      <p className="v10-sub">No vendor can be configured until your center's BAA with Vityls is recorded, and the vendor's BAA too where it touches patient data. Credentials are never entered here: Vityls sets them on the server.</p>
      {!b.centerSignedAt && <Sign label="Record center BAA" roles={ADMIN} what="Business associate agreement between this center and Vityls" testId="v10-baa-sign" onSigned={(by, role) => { C.signCenterBaa(by, role); f(x => x + 1); }} />}</div>
    {(['billing', 'notifications'] as const).map(g => <section key={g}><h2 className="v10-h">{g === 'billing' ? 'Billing & insurance' : 'Messaging & intake'}</h2><div className="v10-grid">{C.CONNECTORS.filter(c => c.group === g).map(c => { const gt = C.gate(c.id); const st = C.status(c.id);
      return <div key={c.id} className="v10-card" data-testid="v10-conn" data-id={c.id} data-status={st}><div className="v10-row"><b>{c.vendor}</b><span className="v10-sub">{c.name}</span><span style={{ marginLeft: 'auto' }} /><span className={`v10-chip ${st === 'configured' ? 'info' : 'nc'}`} data-testid="v10-conn-status">{st === 'configured' ? 'Configured · awaiting server' : 'Not connected'}</span></div>
        <p className="v10-sub">{c.what}</p><p className="v10-sub">{c.ops.join(' · ')}</p>
        {!gt.open ? <><p className="sv-small" data-testid="v10-conn-gated">🔒 Needs: {gt.missing.join(', ')}</p>{b.centerSignedAt && c.needsVendorBaa && !b.vendors[c.id] && <button type="button" className="a8-btn" onClick={() => { C.recordVendorBaa(c.id, actor.name, actor.role); f(x => x + 1); }} data-testid="v10-conn-vbaa">Record {c.vendor} BAA</button>}</>
          : ed === c.id ? <>{c.fields.map(x => <label key={x.k} className="sv-small">{x.label}<input className="sv-input" placeholder={x.ph} value={vals[x.k] || ''} onChange={e => setVals({ ...vals, [x.k]: e.target.value })} data-testid={`v10-conn-f-${x.k}`} /></label>)}
            {err && <p className="a81-err">{err}</p>}<div className="v10-row"><button type="button" className="a8-btn pri" onClick={() => { try { C.configure(c.id, vals, actor.name, actor.role); setEd(''); setErr(''); } catch (x) { setErr((x as Error).message); } }} data-testid="v10-conn-save">Save settings</button><button type="button" className="a8-btn" onClick={() => setEd('')}>Cancel</button></div></>
          : <button type="button" className="a8-btn" onClick={() => { setEd(c.id); setVals(C.configs()[c.id]?.values || {}); }} data-testid="v10-conn-config">Set up</button>}</div>; })}</div></section>)}</div>; };

/* ---------- audit log viewer ---------- */
export const AuditViewer: React.FC = () => { useMedTick(); const [q, setQ] = useState('');
  const rows: { at: string; user: string; role: string; detail: string; caseId: string }[] = [];
  for (let i = 0; i < localStorage.length; i++) { const k = localStorage.key(i) || ''; if (!/:audit:/.test(k)) continue; try { (JSON.parse(localStorage.getItem(k) || '[]') as any[]).forEach(a => rows.push(a)); } catch { /* */ } }
  const l = rows.filter(r => !q || JSON.stringify(r).toLowerCase().includes(q.toLowerCase())).sort((a, b) => b.at.localeCompare(a.at)).slice(0, 300);
  return <div className="v10-page" data-testid="v10-audit"><h1 className="sv-title" data-ps-legacy="">Audit log</h1><input className="sv-input" placeholder="e.g. signed" value={q} onChange={e => setQ(e.target.value)} data-testid="v10-audit-q" />
    {!l.length ? <div className="v10-empty"><b>No entries yet</b></div> : <table className="v10-table"><thead><tr><th>When</th><th>Who</th><th>Role</th><th>What</th></tr></thead><tbody>{l.map((r, i) => <tr key={i} data-testid="v10-audit-row"><td>{new Date(r.at).toLocaleString()}</td><td>{r.user}</td><td>{r.role}</td><td>{r.detail}</td></tr>)}</tbody></table>}</div>; };

/* ---------- question bank library ---------- */
export const BankLibrary: React.FC = () => { const [q, setQ] = useState(''); const B = E.BASE.filter(x => !x.hidden);
  const by = B.filter(x => !q || (x.text + x.id + (x.form || '')).toLowerCase().includes(q.toLowerCase())).reduce<Record<string, E.Question[]>>((m, x) => { const k = x.form || 'Other'; (m[k] = m[k] || []).push(x); return m; }, {});
  return <div className="v10-page" data-testid="v10-banklib"><h1 className="sv-title" data-ps-legacy="">Question bank</h1><p className="v10-sub">{E.BANK_VERSION} · {B.length} questions · {Object.keys(E.TEMPLATES).length} templates. Each template field maps to one question; a case answers it once and every station and form reuses it.</p>
    <input className="sv-input" placeholder="e.g. allergies" value={q} onChange={e => setQ(e.target.value)} data-testid="v10-banklib-q" />
    {Object.entries(by).map(([t, l]) => <details key={t} className="v10-card"><summary><b>{E.TEMPLATES[t]?.title || t.replace(/_/g, ' ')}</b> <span className="v10-chip info">{l.length}</span></summary><table className="v10-table"><tbody>{l.map(x => <tr key={x.id}><td>{x.id}</td><td>{x.text}</td><td>{x.ask.join(', ')}</td></tr>)}</tbody></table></details>)}</div>; };

/* ---------- onboarding wizard (same order as the 8 groups) ---------- */
export const OnboardingWizard: React.FC = () => { useMedTick(); useCoreTick(); const [actor] = useActor(); const { setTab } = useSv(); const [o, setO] = useState(onboarding()); const [n, setN0] = useState(() => Math.min(onboarding().step || 0, WIZ_GO_LIVE));
  const setN = (i: number) => { setN0(i); wizardGoStep(i); setO(x => ({ ...x, step: i })); }; useEffect(() => { setO(onboarding()); }, []); const s = getSettings(); const [nm, setNm] = useState(s.practiceName || ''); const [ct, setCt] = useState('');
  const mark = (i: number) => { const x = { ...o, done: [...new Set([...o.done, i])] }; setO(x); saveOnb(x); };
  const steps = ['Plan', ...WIZ_GROUPS.map(g => g.title), 'Go live']; const GO = WIZ_GO_LIVE;
  const center = P.practice(P.CENTER_ID);
  const body = () => {
    if (n === 0) return <><p className="v10-sub">Start small with Email intake only, or take the full {isAscEd ? 'ASC' : isMedical ? 'Medical' : 'Surgery'} bundle. You can add modules or start free trials later.</p>
      <div className="v10-grid">{(['starter', 'full'] as const).map(p => <button key={p} type="button" className={`v10-card ${o.plan === p ? 'on' : ''}`} onClick={() => { const x = { ...o, plan: p, done: [...new Set([...o.done, 0])] }; setO(x); saveOnb(x); if (center) { applyPlan(P.CENTER_ID, p, actor.name); P.coreWrite('center-touched', true); } }} data-testid={`v10-onb-plan-${p}`}><b>{p === 'full' && !isAscEd ? `Full ${isMedical ? 'Medical' : 'Surgery'} bundle` : PLAN_LABEL[p]}</b><div className="v10-sub">{p === 'starter' ? MOD['email-intake'].description : (isAscEd ? 'Every ASC module, exactly as v9.1.' : `Every ${isMedical ? 'Medical' : 'Surgery'}.Vityls module: scheduling, stations, chart, forms, billing, Nightingale.`)} · test price ${PLAN_PRICE[p]}/mo</div>{o.plan === p && <span className="v10-chip ok">Chosen</span>}</button>)}</div></>;
    if (n === 1) return <><p className="v10-sub">{isAscEd ? 'Name, logo, address' : 'Name, logo, main office and any other offices'}, phone, website, tax and NPI numbers and accreditation. They print on invoices, letters, quotes and packets. Save, and the wizard moves on to step 2.</p>
      <FacilitySettings onSaved={f => { if (f.name.trim()) { saveSettings({ ...getSettings(), practiceName: f.name.trim() }, actor.name, actor.role, 'Practice name set in onboarding'); if (center) P.upsertPractice({ ...P.practice(P.CENTER_ID)!, name: f.name.trim() }, actor.name, 'Center name set in onboarding'); P.coreWrite('center-touched', true); } mark(1); setN(2); window.scrollTo(0, 0); }} />
      {o.done.includes(1) && <p className="v10-wiz-ok" data-testid="v10-onb-done1">✓ Profile saved. Press Next for step 2.</p>}</>;
    if (n === GO) { const gaps = setupGaps(); const baa = { centerSignedAt: baaSigned() ? baaSignature()!.at : '', centerSignedBy: baaSignature()?.name || '' }; const isAdm = ADMIN.includes(actor.role) || !!(window as any).__vitylsMe?.isManager;
      return <><p className="v10-sub">Go live whenever you are ready; there is no review to wait for. Anything not finished stays on the administrator’s list on Practice settings, and you can finish it any time.</p>
      <div className={`v10-card ${baa.centerSignedAt ? '' : 'v10-warnbox'}`} data-testid="v10-golive-baa"><div className="v10-row"><b>Business Associate Agreement with Vityls</b>{baa.centerSignedAt ? <span className="v10-chip ok">Signed · {baa.centerSignedBy}</span> : <span className="v10-chip warn">Not signed</span>}</div>
        <p className="v10-sub">HIPAA requires this agreement before any patient information is entered. It is the one item needed to go live.</p>
        <button type="button" className={`a8-btn ${baa.centerSignedAt ? '' : 'pri'}`} onClick={() => { setWizardStep(null); setTab('v11-baa' as SvTab); }} data-testid="v10-golive-openbaa">{baa.centerSignedAt ? 'View the signed BAA' : 'Review and sign the BAA'}</button></div>
      <ul className="v10-golive-list">{steps.slice(0, GO).map((t, i) => <li key={t} className={`v10-li ${o.done.includes(i) ? 'done' : 'miss'}`} data-testid="v10-golive-step">{o.done.includes(i) ? '✓ ' : '⚠ '}{t}{!o.done.includes(i) && <> · <button type="button" className="sv-link" onClick={() => setN(i)}>finish</button></>}</li>)}</ul>
      {o.finished ? <p className="a81-ok" data-testid="v10-onb-finished">Live since {new Date(o.finished).toLocaleDateString()}.{gaps.length ? ` ${gaps.length} step${gaps.length === 1 ? '' : 's'} still flagged for the administrator.` : ''}</p>
        : <button type="button" className="a8-btn pri" disabled={!baa.centerSignedAt || !isAdm} onClick={() => { const x = { ...o, finished: new Date().toISOString() }; setO(x); saveOnb(x); if (center) P.upsertPractice({ ...P.practice(P.CENTER_ID)!, onboarded: true }, actor.name, `Practice went live${gaps.length ? `; unfinished: ${gaps.map(g => g.title).join(', ')}` : ''}`); }} data-testid="v10-onb-finish">Go live</button>}
      {!baa.centerSignedAt && <p className="sv-small" data-testid="v10-onb-needbaa">Sign the BAA above first.</p>}
      {!o.finished && gaps.length > 0 && baa.centerSignedAt && <p className="sv-small sv-muted">{gaps.length} step{gaps.length === 1 ? '' : 's'} not finished. They will be flagged to the administrator on Practice settings.</p>}</>; }
    const g = WIZ_GROUPS[n - 1]; const seen = (l: string) => (o.visited || []).includes(l); const allSeen = g.items.every(i => seen(i.label));
    const openItem = (i: Item) => { wizardVisit(i.label); setWizardStep(n); rememberPick(i.tab, i.label); setTab(i.tab); };
    return <>{g.desc && <p className="v10-sub">{g.desc}</p>}
      <p className="v10-wiz-how">{g.items.length > 1 ? `This step has ${g.items.length} pages.` : 'This step has one page.'} Open {g.items.length > 1 ? 'each page' : 'it'} and set it up; at the end of the page, <b>Done, next step</b> brings you back here.</p>
      <div className="v10-wiz-items">{g.items.map((i, k) => <div key={i.label} className={`v10-wiz-item ${seen(i.label) ? 'seen' : ''}`} data-testid={`v10-onb-item-${i.tab}`}>
        <div className="t"><span className="num">{k + 1}</span><div><b>{i.label}</b><span>{i.sub}</span></div></div>
        <button type="button" className="a8-btn pri v10-wiz-open" onClick={() => openItem(i)} data-testid={`v10-onb-open-${i.tab}`}>{seen(i.label) ? 'Open again' : `Set up ${i.label.toLowerCase().startsWith('rooms') ? 'rooms & schedule' : i.label}`} ›</button>
        {seen(i.label) && <span className="v10-chip ok">Opened</span>}</div>)}</div>
      <div className="v10-wiz-donebar">{o.done.includes(n) ? <span className="v10-chip ok" data-testid="v10-onb-isdone">✓ Step done</span>
        : <><button type="button" className="a8-btn" disabled={!allSeen} onClick={() => mark(n)} data-testid="v10-onb-done">I've finished this step</button>{!allSeen && <span className="sv-small sv-muted">Open {g.items.length > 1 ? 'every page' : 'the page'} above and set it up first.</span>}</>}</div></>;
  };
  return <div className="v10-page" data-testid="v10-wizard"><h1 className="sv-title" data-ps-legacy="">{isAscEd ? "Set up your center" : "Set up your practice"}</h1>
    <div className="v10-tabs" data-testid="v10-onb-steps">{steps.map((t, i) => <button key={t} type="button" className={n === i ? 'on' : ''} onClick={() => setN(i)} data-testid={`v10-onb-step-${i}`}>{(i === GO ? !!o.finished : o.done.includes(i)) ? '✓ ' : `${i}. `}{t}</button>)}</div>
    <div className="v10-card" data-testid="v10-onb-body" data-step={n}><h2 className="v10-h">{steps[n]}</h2>{body()}</div>
    <div className="v10-row"><button type="button" className="a8-btn" disabled={!n} onClick={() => setN(n - 1)} data-testid="v10-onb-back">Back</button><span style={{ marginLeft: 'auto' }} /><button type="button" className="a8-btn pri" disabled={n === steps.length - 1} onClick={() => setN(n + 1)} data-testid="v10-onb-next">Next</button></div></div>; };

export const V10Page: React.FC<{ tab: string }> = ({ tab }) => tab === 'v11-baa' ? <BaaPage /> : tab === 'v10-lists' ? <ListsEditor /> : tab === 'v10-connectors' ? <ConnectorsPage /> : tab === 'v10-onboard' ? <OnboardingWizard /> : tab === 'v10-audit' ? <AuditViewer /> : tab === 'v10-bank' ? (isAscEd ? <BankLibrary /> : <OfficeBankPage />) : tab === 'v10-checklists' ? <ChecklistsPage /> : tab === 'v10-daily' ? <DailyEmailSettings /> : null;
