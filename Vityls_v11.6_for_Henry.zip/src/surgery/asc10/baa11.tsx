/* v11.5 · The practice reviews and signs its Business Associate Agreement with Vityls (replaces "Record center BAA").
 * The text is a standard HIPAA business associate agreement (45 CFR 164.504(e)) marked as a draft until counsel approves the final
 * wording; BAA_VERSION changes when it does, and a practice that signed an older version is asked to sign the new one. */
import React, { useState } from 'react';
import { svRead, svWrite } from '../store';
import { useActor, useMedTick } from '../../med/ui';
import { repo } from '../../v6/dataLayer';
import * as C from '../../connectors';
import { facility } from '../asc88/store88';

export const BAA_VERSION = '2026-11 draft 1';
export const BAA_IS_DRAFT = true;
export interface BaaSignature { version: string; name: string; title: string; email: string; signature: string; at: string; practice: string }
export const baaSignature = (): BaaSignature | null => svRead<BaaSignature | null>('v11-baa-sign', null);
/** Signed, and on the current version. */
export const baaSigned = () => { const s = baaSignature(); return !!s && s.version === BAA_VERSION; };

const BA = 'Vityls';
export const baaSections = (ce: string): [string, string][] => [
  ['Parties and purpose', `This Business Associate Agreement ("Agreement") is between ${ce} ("Covered Entity") and ${BA} ("Business Associate"). Business Associate provides the Vityls software service, which creates, receives, maintains and transmits protected health information ("PHI") for Covered Entity. This Agreement sets out how Business Associate protects that PHI, as required by the Health Insurance Portability and Accountability Act of 1996, the HITECH Act, and their regulations at 45 CFR Parts 160 and 164 (together, "HIPAA"). Terms used here have the meanings given in HIPAA.`],
  ['Permitted uses and disclosures', `Business Associate may use and disclose PHI only to provide the Vityls service to Covered Entity, as this Agreement permits, or as required by law. Business Associate may also use PHI for its own proper management and administration and to meet its legal responsibilities, and may provide data aggregation services relating to Covered Entity's health care operations. Business Associate will not use or disclose PHI in a way that would violate HIPAA if done by Covered Entity, and will limit its uses, disclosures and requests to the minimum necessary. Business Associate will not sell PHI and will not use PHI for marketing.`],
  ['Safeguards', `Business Associate will use appropriate administrative, physical and technical safeguards, and will comply with the HIPAA Security Rule (45 CFR Part 164, Subpart C) for electronic PHI, to prevent any use or disclosure not provided for by this Agreement. This includes encryption of PHI in transit and at rest, access controls, audit logging, and workforce training.`],
  ['Reporting', `Business Associate will report to Covered Entity any use or disclosure not provided for by this Agreement, any security incident, and any breach of unsecured PHI, without unreasonable delay and in no case later than ten (10) business days after discovery for a breach. A breach report will include, to the extent known, the individuals affected, a description of what happened, the PHI involved, and the steps taken to mitigate harm. Unsuccessful attempts that do not result in unauthorized access (such as pings, port scans or blocked log-in attempts) are reported by this paragraph and need no further notice.`],
  ['Subcontractors', `Business Associate will ensure that any subcontractor that creates, receives, maintains or transmits PHI on its behalf (for example, cloud hosting, messaging, fax or payment processors) agrees in writing to the same restrictions and conditions that apply to Business Associate under this Agreement.`],
  ['Individuals’ rights', `Within fifteen (15) business days of a request from Covered Entity, Business Associate will: make PHI in a designated record set available so Covered Entity can meet an individual's right of access (45 CFR 164.524); make amendments Covered Entity directs (45 CFR 164.526); and provide the information Covered Entity needs to give an accounting of disclosures (45 CFR 164.528). If an individual asks Business Associate directly, Business Associate will forward the request to Covered Entity.`],
  ['Covered Entity’s obligations', `To the extent Business Associate carries out an obligation of Covered Entity under the HIPAA Privacy Rule, it will comply with the requirements that apply to Covered Entity for that obligation. Covered Entity will tell Business Associate of any limitation in its notice of privacy practices, any change in or revocation of an individual's permission, and any restriction it has agreed to, to the extent these affect Business Associate's use or disclosure of PHI. Covered Entity will not ask Business Associate to use or disclose PHI in a way HIPAA would not permit.`],
  ['Books and records', `Business Associate will make its internal practices, books and records relating to PHI available to the Secretary of Health and Human Services for determining compliance with HIPAA.`],
  ['Term and termination', `This Agreement starts on the date it is signed below and continues while Business Associate holds PHI for Covered Entity. If either party learns of a material breach of this Agreement by the other, it will give written notice and a reasonable opportunity (not less than thirty (30) days) to cure; if the breach is not cured, the non-breaching party may terminate this Agreement and the underlying service.`],
  ['Return or destruction of PHI', `When this Agreement ends, Business Associate will return to Covered Entity, or at Covered Entity's direction destroy, all PHI it holds, and will provide Covered Entity an export of its records in a standard format. Where return or destruction is not feasible, Business Associate will extend the protections of this Agreement to that PHI and limit further uses and disclosures to the purposes that make return or destruction infeasible.`],
  ['General', `This Agreement is to be read to permit compliance with HIPAA, and amends itself as needed when HIPAA changes. Nothing in this Agreement gives any third party any rights. If this Agreement conflicts with the Vityls terms of service on the protection of PHI, this Agreement controls. This Agreement may be signed electronically, and an electronic signature has the same effect as a handwritten one.`],
];

export const BaaPage: React.FC = () => {
  useMedTick(); const [actor] = useActor(); const me = (window as any).__vitylsMe as { name?: string; email?: string } | undefined;
  const ce = (() => { try { return facility().name || 'the practice'; } catch { return 'the practice'; } })();
  const sig = baaSignature(); const current = baaSigned();
  const [f, setF] = useState({ name: me?.name || actor.name || '', title: actor.role || 'Practice Administrator', email: me?.email || '', signature: '', agree: false }); const [err, setErr] = useState(''); const [, tick] = useState(0);
  const sign = () => { setErr('');
    if (!f.name.trim() || !f.title.trim()) return setErr('Enter your name and title.');
    if (f.signature.trim().toLowerCase() !== f.name.trim().toLowerCase()) return setErr('Type your full name exactly as above to sign.');
    if (!f.agree) return setErr('Confirm that you have read the agreement and are authorized to sign for the practice.');
    const s: BaaSignature = { version: BAA_VERSION, name: f.name.trim(), title: f.title.trim(), email: f.email.trim(), signature: f.signature.trim(), at: new Date().toISOString(), practice: ce };
    svWrite('v11-baa-sign', s); C.signCenterBaa(`${s.name} (${s.title})`, actor.role);
    repo.audit({ caseId: 'practice', user: s.name, role: s.title, action: 'asc10.connector' as any, detail: `Business Associate Agreement with Vityls signed electronically (version ${BAA_VERSION}) for ${ce}` }); tick(x => x + 1); };
  return <div className="v10-page baa11" data-testid="v11-baa">
    <div className="v10-card baa11-doc" data-testid="v11-baa-doc">
      {BAA_IS_DRAFT && <p className="baa11-draft" role="note">Draft for legal review · Vityls counsel approves the final wording before launch. Version {BAA_VERSION}.</p>}
      <h2 className="baa11-h">Business Associate Agreement</h2>
      <p className="v10-sub">Between <b>{ce}</b> (Covered Entity) and <b>{BA}</b> (Business Associate)</p>
      <ol className="baa11-ol">{baaSections(ce).map(([t, x]) => <li key={t}><b>{t}.</b> {x}</li>)}</ol>
      {sig && <div className="baa11-sigs" data-testid="v11-baa-signed"><div><span>Covered Entity</span><b className="baa11-script">{sig.signature}</b>{sig.name}, {sig.title}<br />{sig.practice}<br />Signed electronically {new Date(sig.at).toLocaleString()} · version {sig.version}</div>
        <div><span>Business Associate</span><b>{BA}</b>Countersigned by Vityls when the practice account is activated</div></div>}
    </div>
    {sig && current ? <div className="v10-row"><span className="v10-chip ok">Signed · {sig.name}</span><button type="button" className="a8-btn" onClick={() => window.print()} data-testid="v11-baa-print">Print or save as PDF</button></div>
      : <div className="v10-card" data-testid="v11-baa-form">{sig && !current && <p className="v10-sub"><b>The agreement has been updated.</b> You signed version {sig.version}; please review and sign version {BAA_VERSION}.</p>}
        <h3 className="v10-h">Sign for {ce}</h3>
        <div className="baa11-grid">
          <label className="sv-small">Your full name<input className="sv-input" value={f.name} onChange={e => setF({ ...f, name: e.target.value })} data-testid="v11-baa-name" /></label>
          <label className="sv-small">Title<input className="sv-input" value={f.title} onChange={e => setF({ ...f, title: e.target.value })} data-testid="v11-baa-title" /></label>
          <label className="sv-small">Email<input className="sv-input" type="email" value={f.email} onChange={e => setF({ ...f, email: e.target.value })} /></label>
          <label className="sv-small">Type your full name to sign<input className="sv-input baa11-script" value={f.signature} onChange={e => setF({ ...f, signature: e.target.value })} data-testid="v11-baa-sig" /></label>
        </div>
        <label className="baa11-agree"><input type="checkbox" checked={f.agree} onChange={e => setF({ ...f, agree: e.target.checked })} data-testid="v11-baa-agree" /> I have read this Business Associate Agreement and I am authorized to sign it for {ce}.</label>
        {err && <p className="a81-err" role="alert">{err}</p>}
        <button type="button" className="a8-btn pri" onClick={sign} data-testid="v11-baa-signbtn">Sign the agreement</button>
      </div>}
  </div>;
};
