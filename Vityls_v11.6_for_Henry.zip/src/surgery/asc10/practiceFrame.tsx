/* ASC.Vityls v10.6 · Practice settings redesign.
 * One shared frame for every page opened from Practice settings: a "← Practice settings" back button, a breadcrumb
 * (Practice settings › group › page), one page header (kicker, title, description) and tabs to the other pages of the
 * same group. Each page keeps its own content and behaviour; only its old ad-hoc back link and title are hidden inside
 * the frame (they carry `data-ps-legacy`). Other editions never render the frame, so they are unchanged.
 * Page names, groups and descriptions come from ASC_GROUPS (settings10.tsx), the same list the home page and the
 * onboarding wizard use. */
import React, { useEffect } from 'react';
import { ArrowLeft, ChevronRight, Building2, CalendarClock, Users, Stethoscope, FileText, CreditCard, BellRing, ShieldCheck, LayoutGrid, Rocket } from 'lucide-react';
import { useSv, type SvTab } from '../ui';
import { ASC_GROUPS, WIZ_GROUPS, wizardStep, setWizardStep, wizardVisit, wizardMarkDone, wizardGoStep, onboarding } from './settings10';
import './practice106.css';

type Icon = React.ComponentType<{ className?: string; size?: number; strokeWidth?: number; 'aria-hidden'?: boolean }>;
/** One icon per group, in the order of ASC_GROUPS (n = 1…8). */
export const GROUP_ICON: Record<number, Icon> = { 1: Building2, 2: CalendarClock, 3: Users, 4: Stethoscope, 5: FileText, 6: CreditCard, 7: BellRing, 8: ShieldCheck };

/** Pages opened from Practice settings that are not one of the group items. */
const EXTRA: Record<string, { title: string; lede: string; icon: Icon; parent?: string }> = {
  modules: { title: 'Modules & plan', lede: 'Modules in your plan, free trials and modules you can add.', icon: LayoutGrid },
  'v10-onboard': { title: 'Onboarding wizard', lede: 'Set up the practice step by step, in the same order as the groups on Practice settings.', icon: Rocket },
  'audit-pack': { title: 'Audit pack', lede: 'Records gathered for an accreditation or regulatory review.', icon: ShieldCheck, parent: 'medical-director' },
  'form-editor': { title: 'Form library & stations', lede: 'My Forms, Form Studio, station assignments and signers.', icon: FileText, parent: 'forms' },
};

/** Fuller descriptions where the page used to show its own subtitle (kept word for word). Otherwise the item's sub is used. */
const LEDE: Partial<Record<string, string>> = {
  profile: 'Name, logo, address and contact details shown on invoices, receipts and printed packets, plus office hours and rooms.',
  staff: 'Shared tablets stay signed in. Each person enters their own PIN only when they sign or attest.',
  'billing-settings': 'Billing configuration and the practice fee per visit type. Used by invoices, quotes and deposits.',
  'med-settings': 'Surgical risk triggers, results release and portal ranges, reminders and lab descriptions.',
  'records-admin': 'Document types for the chart’s Documents folder, and charts that were hidden or deleted.',
  'medical-director': 'Designation, privileges review and annual policy attestations. The Medical Director signs with their own PIN; Nightingale never approves.',
  forms: 'Manage practice forms, starter templates, station assignments and paper/PDF forms.',
  'v11-baa': 'Your Business Associate Agreement with Vityls. HIPAA requires it before any patient information is entered.',
  'v10-connectors': 'Vendors connect only after the business associate agreement (BAA) is recorded. Credentials are set by Vityls on the server, never here.',
  'v10-audit': 'Every change, sign-in and signature recorded on this device, newest first.',
};

/* Which item was clicked, so a page reachable from several items (e.g. connectors) shows the right group and tab. */
let lastPick: { tab: string; label: string } | null = null;
let pendingGroup: number | null = null;
export const rememberPick = (tab: string, label: string) => { lastPick = { tab, label }; };

export function pageMeta(tab: string) {
  const all = ASC_GROUPS.flatMap(g => g.items.map(i => ({ g, i })));
  const hit = (lastPick && lastPick.tab === tab && all.find(x => x.i.tab === tab && x.i.label === lastPick!.label)) || all.find(x => x.i.tab === tab);
  if (hit) return { group: hit.g, title: hit.i.label, lede: LEDE[tab] || hit.i.sub, icon: GROUP_ICON[hit.g.n], tab, label: hit.i.label };
  const x = EXTRA[tab]; if (!x) return null;
  const parent = x.parent ? all.find(p => p.i.tab === x.parent) : undefined;
  return { group: parent?.g, title: x.title, lede: x.lede, icon: x.icon, tab, label: x.title, parent: parent?.i };
}

/** v11.5 · shown on a settings page opened from the onboarding wizard: back to the wizard, the next page of the same step,
 *  or "Done, next step" (marks the step done and returns to the wizard on the following step). */
const WizardBar: React.FC<{ tab: string; label: string; where: 'top' | 'bottom' }> = ({ tab, label, where }) => {
  const { setTab } = useSv(); const ws = wizardStep(); const g = ws ? WIZ_GROUPS[ws - 1] : undefined;
  if (!ws || !g || !g.items.some(i => i.tab === tab)) return null;
  const visited = onboarding().visited || [];
  const next = g.items.find(i => i.label !== label && !visited.includes(i.label));
  const nextGroup = WIZ_GROUPS[ws]; // undefined after the last group -> "Go live"
  const toWizard = (step: number) => { wizardGoStep(step); setWizardStep(null); setTab('v10-onboard' as SvTab); window.scrollTo(0, 0); };
  return <div className={`pset-wizbar ${where}`} data-testid={`wizbar-${where}`} role="region" aria-label="Setup wizard">
    <div className="t"><Rocket size={16} aria-hidden /><span><b>Setup wizard</b> · Step {ws} of {WIZ_GROUPS.length}: {g.title}{g.items.length > 1 ? ` · page ${g.items.findIndex(i => i.label === label) + 1} of ${g.items.length}` : ''}</span></div>
    <div className="b">
      <button type="button" className="a8-btn" onClick={() => toWizard(ws)} data-testid={`wizbar-back-${where}`}><ArrowLeft size={14} aria-hidden /> Back to the wizard</button>
      {next ? <button type="button" className="a8-btn pri" onClick={() => { wizardVisit(next.label); rememberPick(next.tab, next.label); setTab(next.tab as SvTab); window.scrollTo(0, 0); }} data-testid={`wizbar-nextpage-${where}`}>Next page: {next.label} <ChevronRight size={14} aria-hidden /></button>
        : <button type="button" className="a8-btn pri" onClick={() => { wizardMarkDone(ws, ws + 1); toWizard(ws + 1); }} data-testid={`wizbar-done-${where}`}>Done, next step{nextGroup ? `: ${nextGroup.title}` : ': Go live'} <ChevronRight size={14} aria-hidden /></button>}
    </div></div>;
};

/** Wraps a Practice page. `on` false → renders children untouched (other editions, Practice home, locked gate). */
export const PracticeFrame: React.FC<{ tab: string; on: boolean; children: React.ReactNode }> = ({ tab, on, children }) => {
  const { setTab } = useSv();
  const m = on ? pageMeta(tab) : null;
  if (!m) return <>{children}</>;
  const go = (t: string, label: string) => { rememberPick(t, label); if (wizardStep()) wizardVisit(label); setTab(t as SvTab); };
  const toGroup = (n: number) => { pendingGroup = n; setTab('practice'); };
  const Ico = m.icon; const siblings = m.group && m.group.items.length > 1 ? m.group.items : [];
  return <div className="pset-frame" data-testid="pset-frame" data-tab={tab}>
    <div className="pset-bar">
      <button type="button" className="pset-back" onClick={() => setTab('practice')} data-testid="pset-back"><ArrowLeft size={18} aria-hidden />Practice settings</button>
      <nav aria-label="Breadcrumb" className="pset-crumbs"><ol>
        <li><button type="button" onClick={() => setTab('practice')} data-testid="pset-crumb-home">Practice settings</button></li>
        {m.group && <li><ChevronRight size={14} aria-hidden /><button type="button" onClick={() => toGroup(m.group!.n)} data-testid="pset-crumb-group">{m.group.n}. {m.group.title}</button></li>}
        {'parent' in m && m.parent && <li><ChevronRight size={14} aria-hidden /><button type="button" onClick={() => go(m.parent!.tab, m.parent!.label)}>{m.parent.label}</button></li>}
        <li aria-current="page"><ChevronRight size={14} aria-hidden /><span>{m.title}</span></li>
      </ol></nav>
    </div>
    <header className="pset-head" data-testid="pset-head">
      <span className="pset-ico lg" aria-hidden><Ico size={24} strokeWidth={1.8} /></span>
      <div className="pset-head-text">
        <div className="pset-kicker">{m.group ? `Step ${m.group.n} · ${m.group.title}` : 'Practice settings'}</div>
        <h1 className="pset-title">{m.title}</h1>
        <p className="pset-lede">{m.lede}</p>
      </div>
    </header>
    {siblings.length > 0 && <nav className="pset-tabs" aria-label={`${m.group!.title} pages`} data-testid="pset-tabs">
      {siblings.map(s => { const cur = s.tab === m.tab && s.label === m.label; return <button key={s.label} type="button" className={cur ? 'on' : ''} aria-current={cur ? 'page' : undefined} onClick={() => go(s.tab, s.label)} data-testid={`pset-tab-${s.tab}`}>{s.label}</button>; })}
    </nav>}
    <WizardBar tab={m.tab} label={m.label} where="top" />
    <div className="pset-body">{children}</div>
    <WizardBar tab={m.tab} label={m.label} where="bottom" />
  </div>;
};

/** Practice home: scroll to the group a breadcrumb pointed at. */
export const useGroupScroll = () => useEffect(() => {
  if (pendingGroup == null) return; const n = pendingGroup; pendingGroup = null;
  const el = document.querySelector(`[data-testid="v10-group"][data-n="${n}"]`) as HTMLElement | null;
  if (el) { el.scrollIntoView({ block: 'start' }); el.classList.add('pset-flash'); window.setTimeout(() => el.classList.remove('pset-flash'), 1400); (el.querySelector('button') as HTMLElement | null)?.focus({ preventScroll: true }); }
}, []);
