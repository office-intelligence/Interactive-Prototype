/* Surgery.Vityls v1.2 · Journey step page. One template for all 11 steps, ported from mockups/src/journey-step-clearance.html:
   stepper with recap popovers, step header (owner, due, countdown, status chip), Nightingale handoff, the one confirmation that
   is actually needed, checklist of OPEN items only (Completed folds below), right column (documents, payments, ASC requirements,
   care team) and the docked Nightingale composer. Role view switch also sets the acting user. Everything external is simulated. */
import React, { useEffect, useMemo, useRef, useState } from 'react';
import './journey.css';
import { medRepo, MedPatient, isoDay, uid, ageFrom } from '../../med/record';
import { useActor, useMedTick } from '../../med/ui';
import { useSv } from '../ui';
import { PinSign } from '../sign';
import { ROLE_GROUP, sessionUsers } from '../staff';
import { CollectPayment } from '../payments';
import { addDoc, docsOf } from '../documents';
import { PrintSendButton } from '../v13/PrintSend';
import { activeEpisode } from '../episodes/store';
import * as EL from '../episodes/logic';
import * as J from './logic';
import * as C from './confirm';
import { SJourney, journeyFor, syncJourney, mutateJ, who, receiveClearance, surgeonReview, sendToAsc, ascConfirmed, addDraft, setDraft, confirmationsOf, setX, confirmCats, confirmRules } from './store';
import { GapDialog, GapKind } from './GapsUi';
import { handoff, draftFor, stepAnswer, outsideRange, outsideMeds, contradictions, drName, Seg, JDraft, classify } from './coordinator';
import { XClose } from '../asc82/common';

type Role = 'front' | 'nurse' | 'surgeon';
const ROLE_LABEL: Record<Role, string> = { front: 'Front desk', nurse: 'Nurse', surgeon: 'Surgeon' };
const d5 = (iso?: string) => iso ? new Date(iso.length <= 10 ? `${iso}T12:00:00` : iso).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }) : '';
const dW = (iso?: string) => iso ? new Date(`${iso.slice(0, 10)}T12:00:00`).toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' }) : '';
const money = (n: number) => `$${n.toLocaleString('en-US', { maximumFractionDigits: 0 })}`;
const ini = (n: string) => n.replace(/^Dr\.?\s*/, '').split(/[\s,]+/).filter(Boolean).slice(0, 2).map(x => x[0]).join('').toUpperCase();
const ICON: Partial<Record<J.JAction, string>> = { upload: '⇪', pin: '🩺', 'send-asc': '⇢', draft: '✉', collect: '$', schedule: '▦', 'station-front': '⌂', 'station-nurse': '♡', 'station-doctor': '🩺', confirm: '✓', quote: '$', ack: '✍', photos: '📷', redflag: '⚑', tracker: '↻', records: '📄', reconcile: '⇄', 'day-record': '📅', 'postop-plan': '📅', note: '📝' };
const isTest = (k: string) => k.startsWith('s7-t-');

export const JourneyPage: React.FC<{ pid: string }> = ({ pid }) => {
  useMedTick(); const [actor, setActor] = useActor(); const { go, toast } = useSv();
  const [, bump] = useState(0); const refresh = () => bump(x => x + 1);
  const j0 = useMemo(() => syncJourney(pid), [pid]); const j = journeyFor(pid) || j0; const p = medRepo.patient(pid);
  const [view, setView] = useState<J.StepNo | null>(null);
  const [role, setRoleRaw] = useState<Role>(() => { const o = J.ROLE_TO_OWNER(actor.role); return (o === 'all' || o === 'asc' || o === 'patient' ? 'nurse' : o) as Role; });
  const [pop, setPop] = useState<{ n: J.StepNo; x: number; y: number } | null>(null);
  const [dlg, setDlg] = useState<{ kind: 'waive' | 'pin' | 'collect' | 'doc' | 'gap'; key?: string; doc?: string; gap?: GapKind } | null>(null);
  const [draftOpen, setDraftOpen] = useState<string | null>(null); const [ans, setAns] = useState<{ q: string; html: string } | null>(null); const [q, setQ] = useState('');
  const [compOpen, setCompOpen] = useState(false); const [doneOpen, setDoneOpen] = useState(false);
  useEffect(() => { const h = () => setPop(null); document.addEventListener('click', h); return () => document.removeEventListener('click', h); }, []);
  if (!j || !p) return <div className="jy" data-testid="journey-none">No active journey.</div>;
  const n = view || j.current; const def = J.stepDef(n); const ep = activeEpisode(pid); const st = J.stepState(j, n);
  const W = () => who(actor.name, actor.role);
  const run = (f: () => void, msg?: string) => { try { f(); if (msg) toast(msg); } catch (e: any) { toast(e.message || String(e)); } refresh(); };
  const setRole = (r: Role) => { setRoleRaw(r); const roles = r === 'front' ? ['Front desk'] : r === 'nurse' ? ['RN', 'Patient coordinator', 'Medical assistant'] : ROLE_GROUP.provider; const u = sessionUsers().find(a => roles.includes(a.role)); if (u && u.name !== actor.name) setActor(u); };
  const H = handoff(j as SJourney, n, p);
  const open = J.openItems(j, n).filter(i => i.owner !== 'asc' && !(n === 7 && isTest(i.key) && i.status !== 'open' ? false : false));
  // Step 7: the 8 clearance tests collapse into "X missing" items (only the ones still open), like the mockup.
  const visible = open.filter(i => !(n === 7 && ['s7-classify', 's7-verify', 's7-abn'].includes(i.key) && open.some(t => isTest(t.key))));
  const rel = (i: J.JItem) => i.owner === role || (isTest(i.key) && role !== 'surgeon'); const rank = (i: J.JItem) => rel(i) ? (J.statusOf(j, i) === 'blocked' ? 1 : 0) : 2;
  const mineFirst = [...visible].sort((a, b) => rank(a) - rank(b) || (a.due || '9').localeCompare(b.due || '9'));
  const c = J.counts(j, n); const ckOpen = c.open + c.blocked - visible.filter(i => J.statusOf(j, i) === 'blocked').length + visible.filter(i => J.statusOf(j, i) === 'open').length - c.open;
  const blockedCt = visible.filter(i => J.statusOf(j, i) !== 'open').length; const openCt = visible.length - blockedCt;
  const comp = J.completedItems(j, n); const next = J.nextAction(j, n);
  const dueKey = n === 7 ? 's7-asc' : J.stepItems(j, n).filter(i => i.due).sort((a, b) => a.due!.localeCompare(b.due!))[0]?.key; const dueIt = j.items.find(i => i.key === dueKey);
  const today = isoDay(); const left = dueIt?.due ? J.daysBetween(today, dueIt.due) : undefined;
  const conf = confirmationsOf(pid); const lc = (cat: C.Cat) => C.lcText(conf[cat]) || 'never confirmed';
  const diffs = contradictions(j as SJourney, p);
  const flagged = outsideRange(pid);
  const statusText = st === 'done' ? 'Step complete' : ep?.asc.sentAt && n === 7 && !ep.asc.confirmedAt ? 'Waiting on ASC' : openCt ? `${openCt} item${openCt === 1 ? '' : 's'} open` : blockedCt ? 'Waiting' : 'Ready';

  /* ---------- actions ---------- */
  const act = (it: J.JItem) => {
    switch (it.action) {
      case 'pin': setDlg({ kind: 'pin', key: it.key }); return;
      case 'collect': setDlg({ kind: 'collect', key: it.key }); return;
      case 'upload': return upload(it);
      case 'draft': return makeDraft(it.key);
      case 'send-asc': return sendAsc();
      case 'schedule': go({ type: 'tab', tab: 'schedule' }); return;
      case 'station-front': case 'station-nurse': case 'station-doctor': { const v = medRepo.visits().filter(x => x.patientId === pid && x.date === today)[0]; if (v) go({ type: 'station', visitId: v.id }); else toast('No visit today. Open the schedule to check the patient in.'); return; }
      case 'ack': case 'day-record': case 'records': case 'redflag': case 'tracker': case 'postop-plan': case 'reconcile': setDlg({ kind: 'gap', key: it.key, gap: it.action as GapKind }); return;
      case 'quote': case 'photos': case 'note': go({ type: 'fullchart', pid }); return;
      default: run(() => mutateJ(pid, x => ({ ...J.complete(x, it.key, W()), x: x.x }), actor.name, actor.role, `completed ${it.label}`), `${it.label}: done`);
    }
  };
  const upload = (it: J.JItem) => run(() => {
    const t = isTest(it.key) ? it.key.slice(5) : 'Document'; const cl = classify(`${t}.pdf`, p);
    addDoc({ id: uid('doc'), patientId: pid, type: t === 'ECG' ? 'ECG' : cl.type, title: J.CLEARANCE_LABEL[t] || it.label, source: drName(ep?.clearance.pcp || 'Outside office'), docDate: today, receivedAt: new Date().toISOString(), receivedBy: actor.name, receivedRole: actor.role, description: `${cl.text} (simulated upload)`, example: true });
    if (isTest(it.key)) receiveClearance(pid, [t], actor.name, actor.role, `uploaded · ${cl.text}`); else mutateJ(pid, x => ({ ...J.complete(x, it.key, W(), 'uploaded (simulated)'), x: x.x }), actor.name, actor.role, `uploaded for ${it.label}`);
  }, `${isTest(it.key) ? it.key.slice(5) : 'Document'} uploaded · Nightingale classified it and matched name + DOB`);
  const makeDraft = (key: string) => { const d = draftFor(key, j as SJourney, p, actor.name); addDraft(pid, { kind: d.kind, title: d.title, to: d.to, channel: d.channel, body: d.body, by: 'Nightingale', source: d.source, confidence: d.confidence, reviewer: d.reviewer, itemKey: key }); setDraftOpen(key); refresh(); };
  const sendDraft = (id: string, key: string, body: string) => run(() => {
    setDraft(pid, id, 'sent', actor.name, actor.role, body);
    const it = j.items.find(i => i.key === key);
    if (it && isTest(key)) mutateJ(pid, x => ({ ...J.setWaiting(x, key, W(), `Chased ${d5(today)} · Nightingale is watching the inbox`), x: x.x }), actor.name, actor.role, `chase sent for ${it.label}`);
    else if (it && !J.closed(it) && !J.blockersOf(j, it).length) mutateJ(pid, x => ({ ...J.complete(x, key, W(), 'sent (simulated)'), x: x.x }), actor.name, actor.role, `sent: ${it.label}`);
    setDraftOpen(null);
  }, 'Sent (simulated)');
  const sendAsc = () => run(() => { const docs = docsOf(pid).length; sendToAsc(pid, actor.name, actor.role, docs); setTimeout(() => { ascConfirmed(pid, `Package received for ${p.name}, ${d5(ep?.surgeryDate)}. All required items present. No deficiencies.`); refresh(); }, 2200); }, `Package sent to ${(ep?.ascName || 'the ASC').replace(/\s*\(fictional\)/, '')} (simulated)`);
  const nextBtn = () => { if (!next) { if (st === 'done' && j.current !== n) setView(null); return; } const d = (j as SJourney).x.drafts.find(x => x.itemKey === next.key && x.status === 'draft'); if (d) setDraftOpen(next.key); else act(next); };
  const nextLabel = !next ? (j.current !== n ? `Go to Step ${j.current}` : '') : next.action === 'draft' || isTest(next.key) && next.status === 'open' ? ((j as SJourney).x.drafts.some(x => x.itemKey === next.key && x.status === 'draft') ? 'Open draft' : isTest(next.key) ? '✦ Draft chase letter' : '✦ Draft') : next.action === 'pin' ? 'Review & sign with PIN' : next.action === 'send-asc' ? 'Send package to ASC' : next.action === 'upload' ? '⇪ Upload' : 'Open';
  const nextTitle = next ? (isTest(next.key) ? (next.status === 'waiting' ? `Upload the ${next.key.slice(5)} when ${drName(ep?.clearance.pcp || '')}'s office sends it` : `Chase the missing ${next.key.slice(5)} from ${drName(ep?.clearance.pcp || 'the PCP')}'s office`) : next.label) : st === 'done' ? `Step ${n} is complete.` : 'Nothing open for this step.';
  const onNext = () => { if (next && isTest(next.key) && next.status === 'open') { const d = (j as SJourney).x.drafts.find(x => x.itemKey === next.key && x.status === 'draft'); if (d) setDraftOpen(next.key); else makeDraft(next.key); } else if (next && isTest(next.key)) upload(next); else nextBtn(); };

  /* ---------- pieces ---------- */
  const chip = (s: Seg, i: number) => typeof s === 'string' ? <React.Fragment key={i}>{s}</React.Fragment> : <button type="button" key={i} className={`dchip${s.miss ? ' miss' : ''}`} onClick={e => { e.stopPropagation(); setDlg({ kind: 'doc', doc: s.doc }); }}>{s.chip}</button>;
  const stepper = <nav className="card jstep" aria-label="Patient journey" data-testid="jy-stepper">
    <div className="jhd"><b>{p.name.split(' ')[0]}'s journey · {j.service}</b><span className="r">Step {j.current} of 11 · tap a step for its recap</span></div>
    <div className="jtrack">{J.DISPLAY_ORDER.map(s => { const ss = J.stepState(j, s); const cls = s === j.current ? 'cur' : ss === 'done' ? 'done' : 'up';
      return <button type="button" key={s} className={`js ${cls}${s === n && s !== j.current ? ' sel' : ''}`} aria-current={s === j.current ? 'step' : undefined} aria-label={`Step ${s}, ${J.stepDef(s).title}, ${ss === 'done' ? 'done' : s === j.current ? 'current' : ss === 'skipped' ? 'not needed' : 'upcoming'}`}
        onClick={e => { e.stopPropagation(); if (s === j.current) { setView(null); setPop(null); return; } const r = (e.currentTarget as HTMLElement).getBoundingClientRect(); setPop({ n: s, x: Math.max(8, Math.min(window.innerWidth - 328, r.left + r.width / 2 - 160)), y: r.bottom + 8 }); }}>
        <span className="n">{cls === 'done' ? '✓' : s}</span><span className="l">{J.stepDef(s).short}</span>{s === j.current && <span className="jnow">Now</span>}</button>; })}</div></nav>;
  const recap = pop && (() => { const s = pop.n; const ss = J.stepState(j, s); const items = ss === 'done' ? J.completedItems(j, s).slice(0, 4).map(i => `${i.label}${i.doneBy ? ` · ${i.doneBy.replace(/,.*$/, '')}` : ''}`) : J.stepItems(j, s).slice(0, 3).map(i => i.label); const rec = j.steps.find(x => x.n === s);
    return <div className="spop" role="dialog" aria-label="Step recap" style={{ display: 'block', left: pop.x, top: pop.y, position: 'fixed' }} onClick={e => e.stopPropagation()} data-testid="jy-recap">
      <button type="button" className="x" aria-label="Close" onClick={() => setPop(null)}>✕</button><div className="ro">{ss === 'done' ? 'Done · read-only recap' : ss === 'skipped' ? 'Not needed for this patient' : 'Upcoming'}</div>
      <h4>Step {s} · {J.stepDef(s).title}</h4><div className="m">{J.stepDef(s).ownerLabel}{rec?.doneAt ? ` · ${d5(rec.doneAt)}` : ''}</div><ul>{items.map((x, i) => <li key={i}>{x}</li>)}</ul>
      {ss === 'done' ? <button type="button" className="btn sm" onClick={() => { setView(s); setPop(null); }}>Open step (read-only)</button> : <div className="fine">Opens on its own when its trigger happens: {J.stepDef(s).trigger.toLowerCase()}. Nightingale writes the handoff.</div>}</div>; })();

  const ro = n !== j.current; const surgeon = drName(ep?.surgeon || p.primaryProvider);
  const meds = medRepo.meds(pid).filter(m => m.status === 'active'); const probs = medRepo.problems(pid);
  const docs = docsOf(pid); const missing = n === 7 && ep ? EL.missingTests(ep) : [];
  const ascReq = ep ? [...Object.entries(ep.clearance.tests).map(([t, s]) => ({ label: t === 'ECG' ? 'ECG within 6 months' : t === 'CMP' ? 'Chemistry panel' : t === 'UA' ? 'Urinalysis' : t === 'CXR' ? 'Chest x-ray' : t === 'PT' || t === 'PTT' ? t : t, ok: s === 'received', waived: j.items.find(i => i.key === `s7-t-${t}`)?.status === 'waived', s: s === 'received' ? 'received' : 'missing' })),
    { label: 'H&P within 30 days', ok: !!j.items.find(i => i.key === 's7-t-H&P' && i.status === 'done'), waived: false, s: '' }, { label: 'Current medication list', ok: true, waived: false, s: d5(conf.medications?.at) },
    { label: 'Surgeon review documented', ok: !!j.items.find(i => i.key === 's7-review' && J.closed(i)), waived: false, s: 'open' }] : [];
  const met = ascReq.filter(r => r.ok).length;
  const drafts = (j as SJourney).x.drafts;

  return <div className="jy" data-testid="journey-page" data-step={n}>
    <div className="jy-toprow"><span className="t">Surgeries › {p.name} · {j.service} › Step {n} · {def.short}</span>
      <div className="r"><span className="dlab">Role view:</span><div className="demo" role="group" aria-label="Role view" data-testid="jy-roles">{(['front', 'nurse', 'surgeon'] as Role[]).map(r => <button type="button" key={r} className={role === r ? 'on' : ''} onClick={() => setRole(r)}>{ROLE_LABEL[r]}</button>)}</div></div></div>
    {stepper}{recap}
    <section className="card shd" id="top">
      <div className="shd-top">
        <div className="ttl"><div className="eyebrow">Step {n} of 11 · Owner: {def.ownerLabel}{ro ? ' · read-only' : ''}</div><h1>{def.title}</h1></div>
        <div className="pt"><span className="av big p">{ini(p.name)}</span><div><div className="nm">{p.name} {p.allergies.map(a => <span key={a} className="alg" title={`Last confirmed: ${lc('allergies')}`} data-lc={lc('allergies')}>⚠ {a}</span>)}</div><div className="meta">{ageFrom(p.dob)} · {p.sex?.[0] || ''} · MR# {p.id} · DOB {p.dob}</div></div></div>
        <div className="acts">{!ro && (n === 2 || n === 8) && (J.isReady(j, n) ? <span className="cnt ok" data-testid="jy-ready">✓ Ready{n === 8 ? ' for surgery' : ''}</span> : <button type="button" className="btn pri" data-testid="jy-mark-ready" disabled={!J.completeCheck(j, n).ok} title={J.completeCheck(j, n).ok ? '' : `Still needed: ${J.completeCheck(j, n).missing.join(', ')}`} onClick={() => run(() => mutateJ(pid, x => ({ ...J.markReady(x, n as 2 | 8, W()), x: x.x }), actor.name, actor.role, `marked Ready (Step ${n})`), 'Marked Ready')}>Mark Ready</button>)}<button type="button" className="btn" data-testid="jy-chart" onClick={() => go({ type: 'fullchart', pid })}>Chart overview</button><PrintSendButton p={p} /></div>
      </div>
      <div className="facts">
        <div className="fact"><div className="k">Owner</div><div className="v">{def.ownerLabel.split(' · ')[0]}</div><div className="s">{def.owners.includes('surgeon') && def.owners.length > 1 ? 'Surgeon signs' : n === 7 ? 'Surgeon reviews results' : def.trigger}</div></div>
        {dueIt?.due && <div className={`fact${left != null && left <= 9 ? ' hot' : ''}`}><div className="k">{n === 7 ? 'Package due to ASC' : 'Due'}</div><div className="v">{dW(dueIt.due)}</div><div className="s">{left! >= 0 ? `in ${left} day${left === 1 ? '' : 's'}` : `${-left!} days overdue`}{n === 7 ? ' · 7 days before surgery' : ''}</div></div>}
        {ep && <div className="fact"><div className="k">Surgery</div><div className="v">{dW(ep.surgeryDate)} · {ep.surgeryTime}</div><div className="s">in {J.daysBetween(today, ep.surgeryDate)} days · {ep.ascName.replace(/\s*\(fictional\)/, '')}</div></div>}
        <div className="fact"><div className="k">Status</div><div className="v" style={{ display: 'flex', gap: 6, flexWrap: 'wrap', alignItems: 'center' }}><span className={`cnt${!openCt ? ' ok' : ''}`} data-testid="jy-status">{statusText}</span>{blockedCt > 0 && openCt > 0 && <span className="cnt wait">{blockedCt} waiting</span>}</div><div className="s">Opened {d5(j.steps.find(s => s.n === n)?.openedAt)}{n === 7 && ep?.clearance.decidedBy ? ` · clearance required by ${drName(ep.clearance.decidedBy)}` : ''}</div></div>
      </div>
      <div className="known" aria-label="Known data, shown quietly. Hover for last confirmed date.">
        {probs.length > 0 && <span>Problems: <b data-lc={lc('history')} title={`Last confirmed: ${lc('history')}`}>{probs.map(x => x.description).join(', ')}</b></span>}
        <span>Meds: <b data-lc={lc('medications')} title={`Last confirmed: ${lc('medications')}`} data-testid="jy-meds-known">{meds.map(m => `${m.name} ${m.dose}`).join(', ') || 'none'}</b></span>
        <span>Pay: <b data-lc={lc('insurance')} title={`Last confirmed: ${lc('insurance')}`}>{(p as any).paymentType === 'self-pay' || /self/i.test(p.insurance || '') || !p.insurance ? 'Self-pay (cosmetic)' : p.insurance}</b></span>
        <span>ID &amp; cards: <b data-lc={lc('id')} title={`Last confirmed: ${lc('id')}`}>{conf.id ? 'on file' : 'not yet seen'}</b></span>
      </div>
    </section>

    <div className="layout">
      <div className="mainc">
        <section className="card hand" id="hand" data-testid="jy-handoff">
          <div className="hand-h"><span className="nmark">✦</span><div><div className="tt">{H.title}</div><div className="hst">{H.sub}</div></div>
            <div className="r"><span className="conf" title={H.confWhy}>Confidence: {H.confidence}</span><span className="rev">Reviewer: {H.reviewer}</span></div></div>
          <div className="hand-b">
            <div className="recap">{H.paras.map((pp, i) => <p key={i}>{pp.map(chip)}</p>)}</div>
            <div className="hgrid">
              <div className={`hbox${doneOpen ? ' open' : ''}`} id="doneBox"><button type="button" className="bh" onClick={() => setDoneOpen(!doneOpen)} aria-expanded={doneOpen}><span className="chev">▸</span> Done <span className="c">{H.done.length} items</span></button>
                <ul className="hl-list" id="doneL">{H.done.map((d, i) => <li key={i}><span className="ic ok">✓</span><div>{d}</div></li>)}</ul></div>
              <div className="hbox"><div className="sub">Still open</div><ul className="hl-list" id="openL">{H.open.length ? H.open.map((o, i) => <li key={i}><span className={`ic ${o.icon === '!' ? 'op' : 'wt'}`}>{o.icon}</span><div>{o.text}{(o.flags?.length || 0) > 0 && <div className="bad">{o.flags!.map(f => <span key={f} className="chip2 k-due">{f}</span>)}{o.reviewer && <span className="rev">Reviewer: {o.reviewer}</span>}</div>}</div></li>) : <li><span className="ic ok">✓</span><div>Nothing open.</div></li>}</ul></div>
            </div>
            {!ro && <div className="next" id="nextBox" data-testid="jy-next"><span className="bul">→</span><div><div className="lbl">Next action</div><div className="tx">{nextTitle}</div><div className="ow">{next ? `Owner: ${(isTest(next.key) && next.status === 'open' ? 'nurse' : next.owner) === role ? actor.name : J.JOWNER_LABEL[isTest(next.key) && next.status === 'open' ? 'nurse' : next.owner]}${next.action === 'draft' || isTest(next.key) ? ' · Nightingale has a letter ready to draft' : ''}` : ''}</div></div>{nextLabel && <button type="button" className="btn pri" onClick={onNext} data-testid="jy-next-btn">{nextLabel}</button>}</div>}
            <div className="provn"><span>Sources:</span>{H.sources.map(s => <a key={s.label + s.doc} onClick={() => setDlg({ kind: 'doc', doc: s.doc })}>{s.label}</a>)}<span>· Gaps: <b>{H.gaps}</b></span></div>
            <div className="fine" style={{ marginTop: 6 }}>Nightingale summarizes, organizes and drafts only. She never signs, orders, gives clearance or makes a go/no-go call.</div>
          </div>
        </section>

        {!ro && diffs.map(dd => <div className="confirm" key={dd.theirs?.name} data-testid="jy-confirm"><span className="ic">?</span><div className="tx"><b>Outside H&amp;P lists {dd.kind === 'new' ? 'a new medication' : 'a changed medication'} ({dd.theirs?.name} {dd.theirs?.dose}) not in our record.</b> Confirm or update.<small>Our record: {dd.ours ? `${dd.ours.name} ${dd.ours.dose}` : 'not listed'}, confirmed {d5(conf.medications?.at)} · Source: <a className="srcl" onClick={() => setDlg({ kind: 'doc', doc: docs.find(x => /outside/i.test(x.type))?.id || '' })}>H&amp;P, {drName(ep?.clearance.pcp || '')}</a></small></div>
          <div className="a"><button type="button" className="btn sm pri" onClick={() => run(() => { const m = medRepo.meds(pid).find(x => x.status === 'active' && dd.ours && x.name === dd.ours.name); if (m) medRepo.saveMed({ ...m, name: dd.theirs!.name, dose: dd.theirs!.dose }, actor.name, 'med.update'); setX(pid, x => ({ ...x, resolved: { ...x.resolved, [`med:${dd.theirs?.name}`]: { at: new Date().toISOString(), by: actor.name, choice: 'update' } } }), actor.name, actor.role, `medication updated from outside H&P: ${dd.theirs?.name}`); }, 'Medication list updated')}>Update to {dd.theirs?.name.replace(/^\w+\s*/, '')} {dd.theirs?.dose}</button>
            <button type="button" className="btn sm" onClick={() => run(() => setX(pid, x => ({ ...x, resolved: { ...x.resolved, [`med:${dd.theirs?.name}`]: { at: new Date().toISOString(), by: actor.name, choice: 'keep' } } }), actor.name, actor.role, `kept our medication record over outside H&P (${dd.theirs?.name})`), 'Kept our record · logged')}>Keep ours</button></div></div>)}

        {!ro && <ConfirmPanel pid={pid} n={n} since={ep?.bookedOn} onDone={(m) => { toast(m); syncJourney(pid); refresh(); }} />}
        <section className="card sec" id="ckSec" data-testid="jy-checklist">
          <div className="sh2"><h2><span className="si att">☑</span>Checklist</h2><span className={`cnt${openCt ? '' : ' ok'}`}>{openCt} open</span>{blockedCt > 0 && <span className="cnt wait">{blockedCt} waiting</span>}<div className="r"><span className="aitag">✦ {ROLE_LABEL[role]} items first</span></div><div className="sd">Only what still needs doing. Finished items fold into Completed below.</div></div>
          {role !== 'nurse' && !visible.some(i => i.owner === role) && !ro && <div className="rolehint on"><b>{ROLE_LABEL[role]} view.</b> Nothing in this step is assigned to you right now.</div>}
          <div className="cklist">{(ro ? [] : mineFirst).map(it => { const s = J.statusOf(j, it); const bl = J.blockersOf(j, it); const t = isTest(it.key) ? it.key.slice(5) : '';
            const d = drafts.find(x => x.itemKey === it.key && x.status === 'draft'); const mine = rel(it);
            return <div className={`ck${mine ? ' mine' : ''}`} key={it.id} data-key={it.key} data-testid={`jy-item-${it.key}`}>
              <div className="ck-h"><span className="ico">{t === 'ECG' ? '❤' : ICON[it.action] || '•'}</span><div><div className="tt">{t ? `${t} missing` : it.followUpOf ? `Follow-up: ${it.label}` : it.label}</div>
                <div className="ds">{t ? `Requested from ${drName(ep?.clearance.pcp || 'the PCP')} on ${d5(ep?.clearance.requestedAt)}.${docs.some(x => /lab/i.test(x.type)) ? ' Not in the packet received.' : ''}${t === 'ECG' ? ` ${(ep?.ascName || '').replace(/\s*\(fictional\)/, '')} requires an ECG from the last 6 months.` : ''}` : it.followUpOf ? 'Created by a waiver. It must be closed before the case can be marked Ready for surgery (Step 8).' : it.key === 's7-review' ? `Returned results are filed and matched to ${p.name.split(' ')[0]}. Nightingale lists the values outside the lab's reference range.` : it.key === 's7-asc' ? 'Nightingale has assembled the packet: H&P, labs, CXR report, ECG (once received), medication list and surgeon review.' : it.note || def.completeWhen}</div>
                <div className="who"><span className={mine ? 'me' : ''}>{it.owner === 'surgeon' ? surgeon : J.JOWNER_LABEL[it.owner]}</span>{t && <span>Front desk files it on arrival</span>}{it.due && <span>Due {d5(it.due)}</span>}</div></div>
                <span className={`chip2 ${s === 'blocked' ? 'k-blk' : s === 'waiting' ? 'k-due' : t ? 'k-miss' : it.action === 'pin' ? 'k-rev' : 'k-due'}`}>{s === 'blocked' ? 'Waiting' : s === 'waiting' ? (t ? `Chased ${d5(j.audit.filter(a => a.item === it.key && a.kind === 'waiting').slice(-1)[0]?.at)}` : 'Waiting') : t ? 'Missing' : it.action === 'pin' ? 'Needs review' : it.followUpOf ? 'Follow-up' : 'Open'}</span></div>
              {it.key === 's7-review' && <div className="res"><div className="rr hd"><span>Test</span><span>Result</span><span>Reference</span><span></span></div>
                {flagged.map(l => <div className="rr flag" key={l.id}><span>{l.test}</span><span className="v">{l.value} {l.unit}</span><span className="rg">{l.reportedRange}</span><span className="fl">✦ outside range</span></div>)}
                <div className="rr"><span>Other returned results</span><span className="v">within range</span><span className="rg">see report</span><span className="nl">no flags</span></div>
                <div className="cap"><span className="aitag">✦ Pre-flagged by Nightingale</span><span className="conf">Confidence: High</span><span className="rev">Reviewer: Surgeon</span><span>A flag means "outside the lab's range" only. No interpretation, no go/no-go opinion.</span></div></div>}
              {bl.length > 0 && <div className="blk">Blocked by: {bl.map(b => <b key={b.key}>{isTest(b.key) ? `${b.key.slice(5)} not received or waived` : b.label}</b>).reduce((a: React.ReactNode[], x, i) => i ? [...a, ' · ', x] : [x], [])}</div>}
              {!bl.length && it.key === 's7-asc' && <div className="blk"><span className="okk">✓ Nothing blocking.</span> Review the packet, then send.</div>}
              <div className="ra">{t ? <><button type="button" className="btn sm pri" onClick={() => d ? setDraftOpen(it.key) : makeDraft(it.key)}>✦ Chase PCP</button><button type="button" className="btn sm" onClick={() => upload(it)} data-testid={`jy-upload-${t}`}>⇪ Upload</button></> :
                it.action === 'pin' ? <><button type="button" className="btn sm pri" disabled={bl.length > 0} onClick={() => act(it)} data-testid="jy-pin">Review &amp; sign with PIN</button>{it.key === 's7-review' && <button type="button" className="btn sm" onClick={() => setDlg({ kind: 'doc', doc: 'labs' })}>Open lab report</button>}</> :
                it.action === 'send-asc' ? <><button type="button" className="btn sm pri" disabled={bl.length > 0 || !!ep?.asc.sentAt} onClick={sendAsc} data-testid="jy-send-asc">Send package to ASC</button><button type="button" className="btn sm" onClick={() => setAns({ q: 'asc', html: stepAnswer('asc', j as SJourney, n, p).html })}>✦ What does the ASC still need?</button></> :
                <button type="button" className="btn sm pri" disabled={bl.length > 0} onClick={() => act(it)}>{it.action === 'draft' ? (d ? 'Open draft' : '✦ Draft') : it.action === 'collect' ? 'Collect' : it.action.startsWith('station') ? 'Open station' : it.action === 'schedule' ? 'Open schedule' : 'Mark done'}</button>}
                {!it.followUpOf && it.action !== 'send-asc' && <button type="button" className="btn sm warn" onClick={() => setDlg({ kind: 'waive', key: it.key })}>Waive…</button>}</div>
              {draftOpen === it.key && d && <DraftCard d={d} onSend={b => sendDraft(d.id, it.key, b)} onDiscard={() => { setDraft(pid, d.id, 'discarded', actor.name, actor.role); setDraftOpen(null); refresh(); }} />}
            </div>; })}
            {ro && <div className="fine">Read-only recap of a finished step. Changes are made from the current step.</div>}
          </div>
          <div className={`comp${compOpen ? ' open' : ''}`}><button type="button" className="ch" onClick={() => setCompOpen(!compOpen)} aria-expanded={compOpen} data-testid="jy-completed"><span className="chev">▸</span><span>Completed ({comp.length})</span><span className="c">who · when</span></button>
            <ul>{comp.map(i => <li key={i.id}><span className={i.status === 'waived' ? 'wv' : 'ok'}>{i.status === 'waived' ? '~' : '✓'}</span><div>{i.status === 'waived' ? `${i.label} waived: ${i.waiver?.reason}` : i.label}<div className="w">{i.status === 'waived' ? `Waived by ${i.waiver?.by} · follow-up: ${i.waiver?.followUp}` : `${i.reviewedBy ? 'Signed by' : ''} ${i.doneBy || ''}${i.note ? ` · ${i.note}` : ''}`}</div></div><span className="t">{d5(i.doneAt || i.waiver?.at)}</span></li>)}</ul></div>
        </section>
      </div>

      <aside className="asidec" aria-label="Documents, payments, ASC and care team">
        <section className="card sec" id="docs" data-testid="jy-docs"><div className="sh2"><h2><span className="si doc">▤</span>Documents received</h2><div className="sd">Classified by Nightingale, confirmed by staff.</div></div>
          <div className="dl">{missing.map(t => { const it = j.items.find(i => i.key === `s7-t-${t}`); return <div className="di missing" key={t}><span className="fi">✕</span><div><div className="tt">{J.CLEARANCE_LABEL[t] || t}</div><div className="ds">{it?.status === 'waived' ? 'Waived' : `Not received · requested ${d5(ep?.clearance.requestedAt)}`}</div></div>{it && !J.closed(it) && <button type="button" className="ob" aria-label={`Upload ${t}`} onClick={() => upload(it)}>⇪</button>}</div>; })}
            {docs.slice(0, 8).map(x => <div className="di" key={x.id}><span className="fi">{/lab/i.test(x.type) ? '🧪' : /imag/i.test(x.type) ? '🩻' : /ecg/i.test(x.type) ? '❤' : '📄'}</span><div><div className="tt"><span className={`ty ${/lab/i.test(x.type) ? 'lab' : /imag/i.test(x.type) ? 'img' : /ecg/i.test(x.type) ? 'ecg' : 'hp'}`}>{x.type.replace('Outside records', 'H&P').replace('Laboratory', 'Labs').replace('Imaging', 'CXR')}</span>{x.title}</div><div className="ds">{x.source} · {d5(x.docDate)}</div></div><button type="button" className="ob" aria-label={`Open ${x.title}`} onClick={() => setDlg({ kind: 'doc', doc: x.id })}>↗</button></div>)}
            {!docs.length && !missing.length && <div className="fine">Nothing filed yet.</div>}</div></section>
        {ep && <section className="card sec" id="pay"><div className="sh2" style={{ marginBottom: 10 }}><h2><span className="si pay">$</span>Payments</h2></div>
          <div className="kv2"><span>Quote total</span><span className="v">{money(ep.totalAmount)}</span></div>
          <div className="kv2"><span>Deposit</span><span className={`v${ep.paid >= ep.depositAmount ? ' ok' : ' due'}`}>{ep.paid >= ep.depositAmount ? `✓ ${money(ep.depositAmount)} paid` : `${money(ep.depositAmount)} due`}</span></div>
          <div className="kv2"><span>Balance</span><span className={`v${EL.balanceDue(ep) ? ' due' : ' ok'}`}>{EL.balanceDue(ep) ? <>{money(EL.balanceDue(ep))} due {d5(ep.items.find(i => i.key === 'balance')?.due)}</> : '✓ paid in full'}</span></div>
          <div className="cardbtns"><button type="button" className="btn sm" onClick={() => toast('Payment reminder drafted for the front desk to review and send (simulated)')}>✦ Draft reminder</button><button type="button" className="btn sm" onClick={() => setDlg({ kind: 'collect' })}>Collect</button></div></section>}
        {ep && n >= 6 && ep.clearance.required && <section className="card sec" id="ascCard" data-testid="jy-asc"><div className="sh2" style={{ marginBottom: 10 }}><h2><span className="si sky">⌂</span>ASC requirements</h2><span className={`cnt${met === ascReq.length ? ' ok' : ''}`}>{met} of {ascReq.length} met</span><div className="sd">{ep.ascName}</div></div>
          <div className="pbar"><i style={{ width: `${(met / Math.max(1, ascReq.length)) * 100}%` }} /></div>
          <ul className="req">{ascReq.map(r => <li key={r.label}><span className={`m ${r.ok ? 'y' : r.waived ? 'w' : 'n'}`}>{r.ok ? '✓' : r.waived ? '~' : '✕'}</span>{r.label}<span className="s">{r.ok ? '' : r.waived ? 'waived · ASC to confirm' : r.s}</span></li>)}</ul>
          {(j as SJourney).x.ascReply && <div className="asc-reply" style={{ display: 'block' }}><b>{ep.ascName.replace(/\s*\(fictional\)/, '')} pre-op desk</b> · {d5((j as SJourney).x.ascReply!.at)} (simulated)<br />{(j as SJourney).x.ascReply!.text}</div>}</section>}
        <section className="card sec team"><div className="sh2" style={{ marginBottom: 8 }}><h2><span className="si cli">☺</span>Care team</h2></div>
          <div className="kv2"><span>Surgeon</span><span className="v">{surgeon}</span></div>
          {sessionUsers().filter(u => u.role === 'RN').slice(0, 1).map(u => <div className="kv2" key={u.name}><span>Nurse</span><span className="v">{u.name}</span></div>)}
          {sessionUsers().filter(u => /coordinator/i.test(u.role)).slice(0, 1).map(u => <div className="kv2" key={u.name}><span>Coordinator</span><span className="v">{u.name}</span></div>)}
          {sessionUsers().filter(u => u.role === 'Front desk').slice(0, 1).map(u => <div className="kv2" key={u.name}><span>Front desk</span><span className="v">{u.name}</span></div>)}
          {ep?.clearance.pcp && <div className="kv2"><span>PCP (outside)</span><span className="v"><span title={`Last confirmed: ${lc('history')}`}>{drName(ep.clearance.pcp)}</span></span></div>}
          {ep && <div className="kv2"><span>ASC</span><span className="v">{ep.ascName.replace(/\s*\(fictional\)/, '')}</span></div>}</section>
      </aside>
    </div>
    <div style={{ textAlign: 'center', fontSize: 11.5, color: 'var(--mu2)', margin: '32px 0 8px' }}>Fictional data · faxes, emails and the ASC are simulated · nothing is sent</div>

    <div className="dock" data-testid="jy-dock"><div className="composer">
      {ans && <div className="floaters"><div className="sheet" style={{ display: 'block' }} data-testid="jy-answer"><button type="button" className="btn sm" style={{ float: 'right' }} onClick={() => setAns(null)} aria-label="Close">✕</button><div className="fine">✦ Nightingale · {ans.q}</div><div dangerouslySetInnerHTML={{ __html: ans.html }} /><div className="fine" style={{ marginTop: 6 }}>Sources: chart and filed documents · Reviewer: {H.reviewer}</div></div></div>}
      <div className="cbox"><div className="ctxrow"><span className="ctx">◎ {p.name} · Step {n} · {def.short}</span><div className="hints">Try {['ecg', 'labs', 'asc'].map(h => <button type="button" key={h} onClick={() => ask(h)}>{h}</button>)}</div></div>
        <div className="crow"><button type="button" className="rb" aria-label="Attach a document" onClick={() => { const t = J.openItems(j, n).find(i => i.action === 'upload' || isTest(i.key)); if (t) upload(t); else toast('Nothing waiting for an upload in this step'); }}>＋</button><input value={q} onChange={e => setQ(e.target.value)} onKeyDown={e => { if (e.key === 'Enter' && q.trim()) { ask(q); setQ(''); } }} placeholder="Ask Nightingale… (⌘K)" aria-label="Ask Nightingale" data-testid="jy-ask" /><button type="button" className="rb send" aria-label="Send" onClick={() => { if (q.trim()) { ask(q); setQ(''); } }}>↑</button></div></div></div></div>

    {dlg?.kind === 'pin' && <PinSign title={j.items.find(i => i.key === dlg.key)?.label || 'Sign'} statement={dlg.key === 's7-review' ? <>I have reviewed the returned clearance results for {p.name}{flagged.length ? `, including the ${flagged.length} value${flagged.length === 1 ? '' : 's'} outside range` : ''}. Nightingale does not judge fitness for surgery.</> : <>Sign: {j.items.find(i => i.key === dlg.key)?.label} for {p.name}.</>} roles={ROLE_GROUP.provider} onClose={() => setDlg(null)}
      onSigned={s => { const k = dlg.key!; setDlg(null); run(() => { if (k === 's7-review') surgeonReview(pid, s.name, s.role, `reviewed${flagged.length ? ` (${flagged.map(l => `${l.test.toLowerCase()} ${l.value}`).join(', ')} noted)` : ''} · PIN`); else mutateJ(pid, x => ({ ...J.complete(x, k, who(s.name, s.role), 'signed with PIN', 'reviewed'), x: x.x }), s.name, s.role, `signed ${k}`); }, `Signed by ${s.name} (PIN)`); }} />}
    {dlg?.kind === 'collect' && <CollectPayment p={p} onClose={() => { setDlg(null); syncJourney(pid); refresh(); }} />}
    {dlg?.kind === 'waive' && <WaiveDialog it={j.items.find(i => i.key === dlg.key)!} actorRole={actor.role} onClose={() => setDlg(null)} onWaive={x => { setDlg(null); run(() => mutateJ(pid, y => ({ ...J.waive(y, dlg.key!, x, W()), x: y.x }), actor.name, actor.role, `waived ${dlg.key}: ${x.reason}`), `Waived · follow-up task created`); }} />}
    {dlg?.kind === 'gap' && <GapDialog kind={dlg.gap!} j={j as SJourney} onClose={m => { const k = dlg.key!; setDlg(null); if (m === '__postop__') { run(() => mutateJ(pid, x => ['s9-plan', 's10-visits', k].reduce((y, kk) => { const it = y.items.find(i => i.key === kk); return it && !J.closed(it) && !J.blockersOf(y, it).length && it.step === n ? { ...J.complete(y, kk, W(), 'post-op plan approved'), x: y.x } : y; }, x as SJourney), actor.name, actor.role, 'post-op plan approved'), 'Post-op plan approved'); return; }
      if (m) { toast(m); const it = journeyFor(pid)?.items.find(i => i.key === k); if (it && !J.closed(it) && (k === 's11-dates')) run(() => mutateJ(pid, x => ({ ...J.complete(x, k, W()), x: x.x }), actor.name, actor.role, 'last-confirmed dates reviewed')); } syncJourney(pid); refresh(); }} />}
    {dlg?.kind === 'doc' && <DocDialog pid={pid} doc={dlg.doc!} onClose={() => setDlg(null)} />}
  </div>;

  function ask(text: string) { const a = stepAnswer(text, j as SJourney, n, p!); if (a.kind === 'ecg') { const t = J.openItems(j!, n).find(i => i.key === 's7-t-ECG'); if (t) { makeDraft(t.key); setAns({ q: text, html: 'I drafted a chase letter for the missing ECG. It is on the ECG item, waiting for your review. Nothing is sent until you approve it.' }); } else setAns({ q: text, html: 'The ECG is resolved for this step.' }); return; } setAns({ q: text, html: a.html }); }
};

const DraftCard: React.FC<{ d: { id: string; title: string; body: string; source: string; confidence: string; reviewer: string; channel: string }; onSend: (body: string) => void; onDiscard: () => void }> = ({ d, onSend, onDiscard }) => {
  const [edit, setEdit] = useState(false); const [body, setBody] = useState(d.body);
  return <div className="draft" data-testid="jy-draft"><div className="dh"><span className="chip2 k-dr">✦ Draft</span><b>{d.title}</b><span className="chip2 k-due" style={{ marginLeft: 'auto' }}>Needs your review</span></div>
    <div className="meta">Drafted by Nightingale from {d.source} · <span className="conf">Confidence: {d.confidence}</span> · Reviewer: {d.reviewer}</div>
    {edit ? <textarea className="letter" style={{ width: '100%', minHeight: 220 }} value={body} onChange={e => setBody(e.target.value)} aria-label="Edit draft" /> : <div className="letter" style={{ whiteSpace: 'pre-wrap' }}>{body}</div>}
    <div className="ra2"><button type="button" className="btn sm" onClick={() => setEdit(!edit)}>{edit ? 'Done editing' : 'Edit'}</button><button type="button" className="btn sm pri" onClick={() => onSend(body)} data-testid="jy-draft-send">Approve &amp; send by {/fax/i.test(d.channel) ? 'fax' : 'message'} (simulated)</button><button type="button" className="btn sm" onClick={onDiscard}>Discard</button></div>
    <div className="fine" style={{ marginTop: 8 }}>Nothing is sent until a staff member approves it.</div></div>;
};

const WaiveDialog: React.FC<{ it: J.JItem; actorRole: string; onClose: () => void; onWaive: (x: J.WaiveInput) => void }> = ({ it, actorRole, onClose, onWaive }) => {
  const [reason, setReason] = useState(''); const [details, setDetails] = useState(''); const [task, setTask] = useState(isTest(it.key) ? `Confirm the ${it.key.slice(5)} result is in the ASC chart before surgery` : `Follow up: ${it.label}`);
  const [owner, setOwner] = useState<J.JOwner>(it.owner === 'asc' || it.owner === 'patient' ? 'nurse' : it.owner); const [due, setDue] = useState(J.addDaysIso(isoDay(), 7));
  const x: J.WaiveInput = { reason, details, followUp: { label: task, owner, due } }; const probs = J.waiveProblems(x);
  const clinicianOnly = it.safety && !/rn|nurse|md|do|surgeon|physician|practitioner|assistant/i.test(actorRole);
  return <div className="mod open" role="dialog" aria-modal="true" aria-label={`Waive ${it.label}`} onClick={e => { if (e.target === e.currentTarget) onClose(); }} data-testid="jy-waive"><div className="card">
    <h3>Waive {isTest(it.key) ? `${it.key.slice(5)} requirement` : it.label}</h3><div className="lead">A waiver needs a reason and a follow-up task. It is logged with your name and the time, and routed to the surgeon's review.{clinicianOnly ? ' This is a safety checkpoint: only a clinician can waive it.' : ''}</div>
    <label>Reason <span className="rq">*</span></label><select value={reason} onChange={e => setReason(e.target.value)} aria-label="Reason"><option value="">Choose a reason…</option>{(isTest(it.key) ? [`${it.key.slice(5)} to be done at the ASC pre-op visit`, 'Recent result on file elsewhere, copy requested', 'Not required for this patient (surgeon decision)'] : ['Not applicable for this patient', 'Done outside the system', 'Surgeon decision']).concat('Other').map(o => <option key={o}>{o}</option>)}</select>
    <label>Details <span className="rq">*</span></label><textarea value={details} onChange={e => setDetails(e.target.value)} aria-label="Details" placeholder="e.g. confirmed by phone with their pre-op desk." />
    <label>Follow-up task <span className="rq">*</span></label><input type="text" value={task} onChange={e => setTask(e.target.value)} aria-label="Follow-up task" />
    <div className="two" style={{ marginTop: 10 }}><select value={owner} onChange={e => setOwner(e.target.value as J.JOwner)} aria-label="Follow-up owner">{(['nurse', 'front', 'surgeon'] as J.JOwner[]).map(o => <option key={o} value={o}>{J.JOWNER_LABEL[o]}</option>)}</select><input type="date" value={due} onChange={e => setDue(e.target.value)} aria-label="Follow-up due date" /></div>
    <div className="err">{probs.length ? `Required: ${probs.join(', ')}.` : ''}</div>
    <div className="row"><button type="button" className="btn" onClick={onClose}>Cancel</button><button type="button" className="btn pri" disabled={!!probs.length || clinicianOnly} onClick={() => onWaive(x)} data-testid="jy-waive-go">Waive &amp; create follow-up</button></div></div></div>;
};

const DocDialog: React.FC<{ pid: string; doc: string; onClose: () => void }> = ({ pid, doc, onClose }) => {
  const p = medRepo.patient(pid)!; const docs = docsOf(pid); const d = docs.find(x => x.id === doc) || (doc === 'labs' ? docs.find(x => /lab/i.test(x.type)) : undefined);
  const labs = medRepo.labs(pid); const flagged = new Set(outsideRange(pid).map(l => l.id));
  const title = d ? `${d.type} · ${d.title}` : doc === 'labs' ? 'Labs' : doc === 'note' ? 'Consult note' : doc === 'photos' ? 'Photos' : doc.startsWith('missing:') ? `${doc.slice(8)} · not received` : 'Record';
  const v = medRepo.visits().filter(x => x.patientId === pid).map(x => medRepo.note(x.id)).find(x => x?.status === 'signed');
  return <div className="mod docm open" role="dialog" aria-modal="true" aria-label={title} onClick={e => { if (e.target === e.currentTarget) onClose(); }} data-testid="jy-doc"><div className="card">
    <div style={{ display: 'flex', alignItems: 'flex-start', gap: 10 }}><div style={{ flex: 1 }}><h3>{title}</h3><div className="lead">{d ? `${d.source} · dated ${d5(d.docDate)} · received ${d5(d.receivedAt)} by ${d.receivedBy}` : `${p.name} · DOB ${p.dob}`}</div></div><XClose onClick={onClose} testId="jy-close" /></div>
    <div className="docv">{(doc === 'labs' || /lab/i.test(d?.type || '')) ? <><div className="lh"><span>Patient: <b>{p.name}</b> · DOB {p.dob} ✓</span></div><table><tbody><tr><th>Test</th><th>Result</th><th>Reference</th></tr>{labs.map(l => <tr key={l.id} className={flagged.has(l.id) ? 'flagr' : ''}><td>{l.test}</td><td>{flagged.has(l.id) ? <b>{l.value} {l.unit}</b> : `${l.value} ${l.unit || ''}`}</td><td>{l.reportedRange}</td></tr>)}</tbody></table></>
      : doc === 'note' && v ? <div style={{ whiteSpace: 'pre-wrap' }}>{Object.values((v as any).sections || {}).filter(Boolean).join('\n\n') || 'Signed consult note.'}</div>
      : d ? <div style={{ whiteSpace: 'pre-wrap' }}>{d.text || d.description || d.scripted?.text || 'Filed document (simulated).'}</div>
      : <div>{doc.startsWith('missing:') ? 'Not received yet. Use Upload on the checklist item when it arrives.' : 'Open the full chart for this record.'}</div>}</div></div></div>;
};
/** P3 · Sparing confirmation: only what is stale (older than the practice limit or never confirmed), changed, or due at a safety
 *  checkpoint (ID at first arrival, allergies + medications at rooming, consent before surgery). One "All still correct" per group. */
export const CHECKPOINT_OF: Partial<Record<J.StepNo, C.Checkpoint>> = { 3: 'first-arrival', 4: 'rooming', 8: 'pre-surgery' };
const STEP_CATS: Partial<Record<J.StepNo, C.Cat[]>> = { 2: ['demographics', 'contact', 'insurance', 'pharmacy', 'prefs'], 3: ['demographics', 'contact', 'insurance', 'pharmacy', 'prefs', 'id'], 4: ['medications', 'allergies', 'history'], 8: ['consents'], 11: C.ALL_CATS };
export function promptsFor(pid: string, n: J.StepNo, since?: string) {
  const cats = STEP_CATS[n]; if (!cats) return [];
  const cp = CHECKPOINT_OF[n]; const conf = confirmationsOf(pid);
  // ID is only re-sighted at a FIRST arrival; a returning patient with an in-person sighting on file is not asked again.
  const checkpoint = cp === 'first-arrival' && conf.id?.via === 'in-person' ? undefined : cp;
  return C.groupPrompts(cats, conf, { today: isoDay(), rules: confirmRules(), checkpoint, since });
}
const ConfirmPanel: React.FC<{ pid: string; n: J.StepNo; since?: string; onDone: (m: string) => void }> = ({ pid, n, since, onDone }) => {
  const [actor] = useActor(); const { go } = useSv(); const g = promptsFor(pid, n, since); const conf = confirmationsOf(pid);
  if (!g.length) return null;
  return <section className="card sec" data-testid="jy-confirmations"><div className="sh2"><h2><span className="si att">?</span>Please confirm</h2><span className="cnt">{g.length} group{g.length === 1 ? '' : 's'}</span><div className="sd">Only what is out of date, changed or required at this checkpoint. Everything else stays quiet.</div></div>
    {g.map(x => <div className="confirm" key={x.id} data-testid={`jy-cg-${x.id}`}><span className="ic">?</span><div className="tx"><b>{x.label}</b>
      <small>{x.needs.map(nd => <span key={nd.cat} style={{ display: 'block' }}>{nd.text} · last confirmed {C.lcText(conf[nd.cat])}</span>)}</small></div>
      <div className="a"><button type="button" className="btn sm pri" data-testid={`jy-cg-ok-${x.id}`} onClick={() => { confirmCats(pid, x.needs.map(nd => nd.cat), actor.name, actor.role, x.id === 'id' || n === 8 ? 'in-person' : 'staff'); onDone(`${x.label.split(' (')[0]}: confirmed`); }}>All still correct</button>
        <button type="button" className="btn sm" onClick={() => go({ type: 'fullchart', pid })}>Update…</button></div></div>)}</section>;
};
export default JourneyPage;
