/* ASC.Vityls v8.7 · Today redesign (Surgery.Vityls Today structure + Kevin's iMARS layout): header with greeting, date selector,
 * Today button and arrows; LEFT 2/3 "Today's patients" timeline cards (Check in · Chart · Cancel; station chips on the day of
 * service only); RIGHT 1/3 one To-do list with typed, colored icons and a Nightingale activity panel. Upload documents dialog,
 * Standard doctor's orders list (Practice settings), cash-pay invoice (v7.5 structure). Never blocks. Fictional data. */
import { invoiceTodos, BillingPanel, BillToBlock } from '../asc106/invoice106';
import * as D10 from '../asc10/store10';
import React, { useEffect, useState } from 'react';
import { ChevronLeft, ChevronRight, Upload, CreditCard, FileCheck2, ClipboardSignature, Stethoscope, CalendarClock, PhoneCall, FolderCheck, Flag, Sparkles, Printer, Receipt, ArrowUp, ArrowDown, Plus } from 'lucide-react';
import { medRepo, isoDay, addDays, ageFrom, uid } from '../../med/record';
import { useActor, useMedTick } from '../../med/ui';
import { useSv } from '../ui';
import { displayName } from '../v07/Today7';
import * as A from '../asc8/logic';
import * as S from '../asc8/store';
import { openAsc } from '../asc8/ui';
import { openBench } from '../asc81/practice81';
import { s81, use81 } from '../asc81/store81';
import { StationChips } from '../asc84/chips';
import { Dlg } from '../asc84/appt';
import { CheckInDialog, cancelCase } from '../asc83/frontdesk';
import { caseMoney, casePays, collectPayment, payTypeOf, toCollect } from '../asc83/pay';
import { surgeonColor } from '../asc83/booking';
import * as D86 from '../asc86/store86';
import * as P86 from '../asc86/pure86';
import * as P from './pure87';
import * as D from './store87';
import { caseSignals } from '../asc81/Workbench';
import { bookingChecklist } from '../asc81/ai';
import { caseCharges, schedule, credits as credits89, applyCreditTo } from '../asc89/store89';
import { isSelfPay as isSelfPay89 } from '../asc89/pure89';
export const creditApps = (cid: string) => credits89().flatMap(cr => cr.applied.filter(a => a.cid === cid).map(a => ({ amount: a.amount, at: a.at, method: `${cr.type} (${cr.method})`, receipt: cr.receipt })));
import { Letterhead, openCardPay } from '../asc88/ui88';
import { DOC_CATS, UPLOAD_CAT } from '../asc89/pure89';

const money = (n: number) => `$${n.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
const dosL = (d: string) => new Date(d + 'T12:00').toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' });
const hm = (t: string) => t.replace(/^0/, '');
const pn = (c?: A.AscCase) => (c && medRepo.patient(c.pid)?.name) || '—';
/** v8.8: cleared to proceed = nothing missing on the booking checklist. */
export const cleared = (c: A.AscCase) => c.loc !== 'scheduled' || !bookingChecklist(caseSignals(c, s81.ai(c.id))).some(i => i.state === 'missing');
export const openUpload = (cid?: string, pid?: string, station?: string, docType?: string) => window.dispatchEvent(new CustomEvent('asc87-upload', { detail: { cid, pid, station, docType } }));
export const openInvoice = (cid: string) => window.dispatchEvent(new CustomEvent('asc87-invoice', { detail: { cid } }));
export const Asc87Host: React.FC = () => { const [u, setU] = useState<{ cid?: string; pid?: string } | null>(null); const [inv, setInv] = useState('');
  useEffect(() => { const a = (e: Event) => setU((e as CustomEvent).detail || {}); const b = (e: Event) => setInv((e as CustomEvent).detail.cid); window.addEventListener('asc87-upload', a); window.addEventListener('asc87-invoice', b); return () => { window.removeEventListener('asc87-upload', a); window.removeEventListener('asc87-invoice', b); }; }, []);
  return <>{u && <UploadDialog cid={u.cid} pid={u.pid} station={u.station} docType={(u as any).docType} onClose={() => setU(null)} />}{inv && <InvoiceDialog cid={inv} onClose={() => setInv('')} />}</>; };

/* ======================= Today ======================= */
export const AscToday87: React.FC = () => {
  useMedTick(); use81(); const [actor] = useActor(); const { go } = useSv(); const openChart = (pid: string) => go({ type: 'chart', pid } as any); const T = isoDay(); const [day, setDay] = useState(T); const [ci, setCi] = useState(''); const [cx, setCx] = useState('');
  const h = new Date().getHours(); const hello = h < 12 ? 'Good morning' : h < 17 ? 'Good afternoon' : 'Good evening';
  const st = A.stationOf(actor.role); const cs = S.cases().filter(c => c.date === day && (st !== 'surgeon' || c.surgeon === actor.name)).sort((a, b) => A.toMin(a.time) - A.toMin(b.time));
  const todos = buildTodos(T, day); const isToday = day === T; const future = day > T;
  const k = { cases: cs.length, waiting: cs.filter(c => c.loc === 'scheduled').length, inCare: cs.filter(c => ['arrived', 'preop', 'or', 'pacu'].includes(c.loc)).length, done: cs.filter(c => c.loc === 'discharged' || c.loc === 'closed').length };
  return <div className="v7-page a87-today" data-testid="sv-dashboard" data-station={st}>
    <div className="v7-today-head a87-head"><div className="min-w-0"><h1 className="v7-h1" data-testid="today-greeting">{hello}, {displayName(actor.name, actor.role)}</h1>
      <div className="v7-daynav"><span className="v7-date" data-testid="today-title">{new Date(day + 'T12:00').toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' })}</span>
        <button type="button" className="v7-icon-btn" onClick={() => setDay(addDays(day, -1))} aria-label="Previous day" data-testid="a87-prev"><ChevronLeft size={16} /></button><button type="button" className="v7-icon-btn" onClick={() => setDay(addDays(day, 1))} aria-label="Next day" data-testid="a87-next"><ChevronRight size={16} /></button>
        <label className="a87-datepick" title="Pick a date"><span className="sr-only">Pick a date</span><input type="date" value={day} onChange={e => e.target.value && setDay(e.target.value)} data-testid="a87-date" aria-label="Pick a date" /></label>
        <button type="button" className="v7-btn sm" onClick={() => setDay(T)} disabled={isToday} data-testid="a87-today-btn">Today</button></div></div>
</div>
    <div className="v7-kpis a87-kpis" data-testid="a87-kpis">{([['CASES', k.cases, ''], ['NOT ARRIVED', k.waiting, ''], ['IN CARE NOW', k.inCare, ''], ['DISCHARGED', k.done, ''], ['TO-DO', todos.length, todos.length ? 'amber' : '']] as [string, number, string][]).map(([l, n, c]) => <div key={l} className="v7-kpi"><div className="k">{l}</div><div className={`n ${c}`}>{n}</div></div>)}</div>
    <div className="a87-grid">
      <section className="a87-left" aria-label="Today's patients" data-testid="a87-patients"><h2 className="a87-h2">{isToday ? 'Today’s patients' : `Patients · ${dosL(day)}`} <span className="a83-badge g">{cs.length}</span>{future && <span className="sv-small sv-muted"> · scheduled ahead; check-in opens on the day of surgery</span>}</h2>
        {!cs.length && <p className="sv-muted a87-empty" data-testid="a87-none">No surgeries on this date.</p>}
        <ol className="a87-timeline">{cs.map(c => { const p = medRepo.patient(c.pid)!; const canCi = isToday && c.loc === 'scheduled'; const canCx = c.loc === 'scheduled';
          return <li key={c.id} className="a87-tl" data-testid="a87-card" data-case={c.id}><span className="tm">{hm(c.time)}</span><div className={`a87-card ${cleared(c) ? 'a88-cleared' : 'a88-missing'}`} data-cleared={cleared(c) ? '1' : '0'}>
            <div className="top"><div className="min-w-0 flex-1"><b className="nm">{p.name}</b><span className="sv-small sv-muted"> · {ageFrom(p.dob)} y · {p.sex}</span><div className="sub">{c.procedure}{c.side ? ` (${c.side})` : ''} · {c.surgeon} · {c.room}</div></div><span className="a8-stage" style={{ background: A.LOC_COLOR[c.loc] }} data-testid="a87-stage">{A.LOC_LABEL[c.loc]}</span></div>
            <div className="acts">{canCi && <button type="button" className="a87-b ok" onClick={() => setCi(c.id)} data-testid="a87-checkin">Check in</button>}<button type="button" className="a87-b" onClick={() => openChart(c.pid)} data-testid="a87-chart">Chart</button>{canCx && <button type="button" className="a87-b red" onClick={() => setCx(c.id)} data-testid="a87-cancel">Cancel</button>}</div>
            {isToday && <StationChips c={c} />}</div></li>; })}</ol></section>
      <aside className="a87-right"><TodoList items={todos} /><NightingalePanel /></aside></div>
    {ci && <CheckInDialog cid={ci} onClose={() => setCi('')} />}{cx && <CancelDialog cid={cx} onClose={() => setCx('')} />}
  </div>;
};

export const CancelDialog: React.FC<{ cid: string; onClose: () => void }> = ({ cid, onClose }) => { const [actor] = useActor(); const { toast } = useSv(); const c = S.caseById(cid); const [why, setWhy] = useState(''); const [note, setNote] = useState(''); const [err, setErr] = useState('');
  if (!c) return null; const R = ['Patient request', 'Medical clearance not obtained', 'Patient ill', 'Surgeon unavailable', 'Insurance / payment', 'No-show', 'Other'];
  return <Dlg title={`Cancel ${pn(c)}'s surgery?`} sub={`${c.procedure} · ${dosL(c.date)} ${hm(c.time)}`} testId="a87-cancel-dlg" onClose={onClose} foot={<><span style={{ flex: 1 }} /><button type="button" className="a8-btn" onClick={onClose}>Keep</button><button type="button" className="a8-btn red" onClick={() => { try { cancelCase(c, why, note, actor.name, actor.role); toast('Case cancelled; history kept in the chart.'); onClose(); } catch (e) { setErr((e as Error).message); } }} data-testid="a87-cancel-yes">Cancel surgery</button></>}>
    <label className="a84-f"><span className="a84-l">Reason</span><select className="sv-input" value={why} onChange={e => setWhy(e.target.value)} data-testid="a87-cancel-why"><option value="">Choose…</option>{R.map(r => <option key={r}>{r}</option>)}</select></label>
    <label className="a84-f mt-2"><span className="a84-l">Note (optional)</span><input className="sv-input" value={note} onChange={e => setNote(e.target.value)} /></label>{err && <p className="a81-err">{err}</p>}
    <p className="sv-small sv-muted mt-2">The case is archived with the reason; reminders are cancelled (simulated) and the change is logged.</p></Dlg>; };

/* ======================= To-do ======================= */
export interface Todo { id: string; kind: P.TodoKind; title: string; who: string; due: string; act: () => void; actLabel: string }
const KIND: Record<P.TodoKind, { label: string; Icon: React.FC<any>; cls: string }> = { payment: { label: 'Payment', Icon: CreditCard, cls: 'pay' }, clearance: { label: 'Clearance / documents', Icon: FileCheck2, cls: 'clr' }, forms: { label: 'Forms', Icon: ClipboardSignature, cls: 'frm' }, orders: { label: 'Orders', Icon: Stethoscope, cls: 'ord' }, scheduling: { label: 'Scheduling', Icon: CalendarClock, cls: 'sch' }, followup: { label: 'Follow-up', Icon: PhoneCall, cls: 'fu' }, closure: { label: 'Closure', Icon: FolderCheck, cls: 'cls' }, flag: { label: 'Flag', Icon: Flag, cls: 'flg' } };
export function buildTodos(T: string, day: string): Todo[] { const out: Todo[] = []; const all = S.cases();
  toCollect(T).forEach(c => { const m = caseMoney(c); out.push({ id: `pay-${c.id}`, kind: 'payment', title: `Collect ${money(m.balance)} from ${pn(c)} · surgery ${dosL(c.date)} (in ${P.daysBetween(T, c.date)} days)`, who: 'Front desk', due: c.date, act: () => openInvoice(c.id), actLabel: 'Collect' }); });
  all.filter(c => c.loc === 'scheduled' && c.date >= T && P.daysBetween(T, c.date) <= 14).forEach(c => {
    if (!A.isDone(c, 'clearance')) out.push({ id: `clr-${c.id}`, kind: 'clearance', title: `Get pre-op H&P / clearance from ${c.surgeon.replace(/,.*$/, '')}’s office for ${pn(c)} · DOS ${dosL(c.date)}`, who: 'Front desk → Pre-op nursing reviews', due: c.date, act: () => openUpload(c.id, c.pid), actLabel: 'Upload' });
    const f = [!A.isDone(c, 'forms') && 'registration', !A.isDone(c, 'financial') && 'financial'].filter(Boolean); if (f.length) out.push({ id: `frm-${c.id}`, kind: 'forms', title: `${pn(c)} has not signed the ${f.join(' and ')} form${f.length > 1 ? 's' : ''} · DOS ${dosL(c.date)}`, who: 'Front desk (patient portal)', due: c.date, act: () => openAsc({ t: 'details', cid: c.id }), actLabel: 'Open' }); });
  all.filter(c => c.date === day && c.loc !== 'closed' && c.loc !== 'discharged').forEach(c => (['preop', 'pacu'] as P86.Phase[]).forEach(ph => { const s = D86.orderSet(c.id, ph); if (D10.viewList(c.id, c.surgeon, ph === 'preop' ? 'pre' : 'post').items.length) return; if (!s || !P86.activeVersion(s) || P86.current(s).status === 'draft') { const signer = (s?.signer || (ph === 'pacu' ? 'anesthesia' : 'surgeon')) === 'anesthesia' ? c.anesthesia : c.surgeon;
    out.push({ id: `ord-${c.id}-${ph}`, kind: 'orders', title: `${P86.PHASE_LABEL[ph]} ${s ? 'drafted, not signed' : 'not entered'} for ${pn(c)}`, who: signer, due: c.date, act: () => openBench('orders' as any, c.id), actLabel: 'Orders' }); } }));
  invoiceTodos(T).forEach(x => out.push({ id: x.id, kind: 'payment', title: x.title, who: x.who, due: x.due, act: () => openInvoice(x.cid), actLabel: x.label }));
  s81.intake().filter(i => i.status === 'new').forEach(i => out.push({ id: `sch-${i.id}`, kind: 'scheduling', title: `Booking request to schedule: ${i.subject}`, who: 'Front desk / scheduler', due: T, act: () => openBench('intake'), actLabel: 'Book' }));
  all.filter(c => (c.loc === 'discharged' || c.loc === 'closed') && !D86.followUp(c.id)?.done && P86.followDue(c.date) <= addDays(T, 2)).forEach(c => out.push({ id: `fu-${c.id}`, kind: 'followup', title: `Day-2 follow-up call to ${pn(c)} (surgery ${dosL(c.date)}) · due ${dosL(P86.followDue(c.date))}`, who: D86.followUp(c.id)?.owner || 'PACU nursing', due: P86.followDue(c.date), act: () => openBench('after', c.id), actLabel: 'Call' }));
  all.filter(c => c.loc === 'discharged' && !D86.closeState(c.id).closed).forEach(c => out.push({ id: `cls-${c.id}`, kind: 'closure', title: `Close the episode for ${pn(c)} · DOS ${dosL(c.date)} (Nightingale checklist ready)`, who: 'Medical records / billing', due: addDays(c.date, 3), act: () => openBench('closure' as any, c.id), actLabel: 'Review' }));
  S.flagsAll().filter(f => f.status === 'open').forEach(f => out.push({ id: `flg-${f.id}`, kind: 'flag', title: `${f.text}`, who: `${A.TEAM_LABEL[f.to]} · from ${f.from.replace(/,.*$/, '')}`, due: T, act: () => openAsc({ t: 'reply', id: f.id }), actLabel: 'Reply' }));
  return P.sortTodos(out); }
export const TodoList: React.FC<{ items: Todo[] }> = ({ items }) => { const [f, setF] = useState<P.TodoKind | ''>(''); const [more, setMore] = useState(false); const kinds = P.KIND_ORDER.filter(k => items.some(i => i.kind === k));
  const list = items.filter(i => !f || i.kind === f); const shown = more ? list : list.slice(0, 10);
  return <section className="a87-panel" data-testid="a87-todo"><h2 className="a87-h2">To-do list <span className="a83-badge r" data-testid="a87-todo-count">{items.length}</span></h2>
    <div className="a87-kinds">{kinds.map(k => { const K = KIND[k]; return <button key={k} type="button" className={`a87-kf ${K.cls} ${f === k ? 'on' : ''}`} onClick={() => setF(f === k ? '' : k)} data-testid={`a87-kf-${k}`}><K.Icon size={13} />{K.label} {items.filter(i => i.kind === k).length}</button>; })}</div>
    {!items.length && <p className="a81-ok">✓ Nothing needs attention.</p>}
    {shown.map(t => { const K = KIND[t.kind]; return <div key={t.id} className="a87-todo" data-testid="a87-todo-item" data-kind={t.kind}><span className={`a87-ic ${K.cls}`} title={K.label}><K.Icon size={16} /></span><div className="min-w-0 flex-1"><div className="t">{t.title}</div><div className="w">For: {t.who}</div></div><button type="button" className="a87-go" onClick={t.act} data-testid={`a87-todo-go-${t.kind}`}>{t.actLabel}</button></div>; })}
    {list.length > 10 && <button type="button" className="a8-link" onClick={() => setMore(m => !m)}>{more ? 'Show fewer' : `Show all ${list.length}`}</button>}</section>; };

/* ======================= Nightingale activity ======================= */
const ACT: Record<D.ActKind, string> = { request: 'Scheduling requests received', clearance: 'Pre-op documents received & matched', forms: 'Registration forms returned', reminder: 'Reminders sent', filed: 'Documents filed', payment: 'Payment reminders', match: 'Duplicates avoided / charts matched' };
export const NightingalePanel: React.FC = () => { useMedTick(); const a = D.activity(); const [open, setOpen] = useState(false);
  const extra: Partial<Record<D.ActKind, number>> = { request: s81.intake().length, filed: D.uploads().length, reminder: S.cases().reduce((n, c) => n + D86.reminders(c.id).length, 0), match: D86.dupCount() };
  const count = (k: D.ActKind) => a.filter(x => x.kind === k).length + (k === 'request' || k === 'reminder' || k === 'match' ? extra[k] || 0 : 0);
  return <section className="a87-panel a87-ng" data-testid="a87-ng"><h2 className="a87-h2"><Sparkles size={16} /> Nightingale activity <span className="sv-small sv-muted">background · simulated</span></h2>
    <div className="a87-ngc">{(Object.keys(ACT) as D.ActKind[]).map(k => <div key={k} className="a87-ngk" data-testid="a87-ng-count"><b>{count(k)}</b><span>{ACT[k]}</span></div>)}</div>
    <ul className="a87-ngl">{(open ? a : a.slice(0, 5)).map(x => <li key={x.id} data-testid="a87-ng-item"><span className="sv-small sv-muted">{new Date(x.at).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' })}</span> {x.text}</li>)}</ul>
    {a.length > 5 && <button type="button" className="a8-link" onClick={() => setOpen(o => !o)}>{open ? 'Show fewer' : `Show all ${a.length}`}</button>}
    <p className="sv-small sv-muted">Nightingale files, matches and reminds; staff review anything uncertain. Nothing is sent outside this test build.</p></section>; };

/* ======================= Upload documents ======================= */
const readFile = (f: File): Promise<string | undefined> => new Promise(ok => { if (f.size > 4_000_000) return ok(undefined); const r = new FileReader(); r.onload = () => ok(String(r.result)); r.onerror = () => ok(undefined); r.readAsDataURL(f); });
export const UploadDialog: React.FC<{ cid?: string; pid?: string; station?: string; docType?: string; onClose: () => void }> = ({ cid, pid: pid0, station, docType, onClose }) => {
  const [actor] = useActor(); const { toast } = useSv(); const c0 = cid ? S.caseById(cid) : undefined; const [pid, setPid] = useState(pid0 || c0?.pid || ''); const [q, setQ] = useState(''); const [ep, setEp] = useState(cid || ''); /* v10.2: one general upload, no document type or category; tagged with the station it came from */ const type = docType || (station ? `Uploaded at ${station}` : 'Uploaded document'); /* v11.5: the chart's Missing list uploads a typed document (H&P, labs…) so it counts as received */ const [files, setFiles] = useState<File[]>([]); const [note, setNote] = useState(''); const [err, setErr] = useState('');
  const p = pid ? medRepo.patient(pid) : undefined; const hits = !p && q.trim().length >= 2 ? medRepo.patients().filter(x => x.name.toLowerCase().includes(q.toLowerCase()) || x.id.toLowerCase().includes(q.toLowerCase())).slice(0, 6) : [];
  const eps = pid ? S.cases().filter(c => c.pid === pid).sort((a, b) => b.date.localeCompare(a.date)) : [];
  useEffect(() => { if (pid && !ep && eps.length) setEp((eps.find(c => c.date >= isoDay()) || eps[0]).id); }, [pid]);
  const save = async () => { if (!p) return setErr('Choose the patient.'); if (!files.length) return setErr('Choose one or more files.'); const c = S.caseById(ep);
    const at = new Date().toISOString(); const list: D.Upload[] = await Promise.all(files.map(async f => ({ id: uid('up'), pid: p.id, cid: c?.id || '', dos: c?.date || '', type, cat: 'Case documents', station: station || '', name: f.name, size: f.size, mime: f.type, data: await readFile(f), at, by: actor.name, role: actor.role, note })));
    D.addUploads(list, actor.name, actor.role); toast(`${list.length} document${list.length === 1 ? '' : 's'} filed to ${p.name}${c ? ` · DOS ${dosL(c.date)}` : ' (general)'}.`); onClose(); };
  return <Dlg kicker={station || "Documents"} title={station ? `Capture / Upload · ${station}` : 'Capture / Upload'} sub="Everything goes into this surgery's documents folder. No sorting needed." testId="a87-upload" onClose={onClose} foot={<><span style={{ flex: 1 }} /><button type="button" className="a8-btn" onClick={onClose}>Cancel</button><button type="button" className="a8-btn pri" onClick={save} data-testid="a87-up-save"><Upload size={15} /> File {files.length || ''} document{files.length === 1 ? '' : 's'}</button></>}>
    <div className="a84-grid4">
      <label className="a84-f a84-rel" style={{ gridColumn: 'span 2' }}><span className="a84-l">Patient</span>{p ? <div className="a82-row"><b data-testid="a87-up-patient">{p.name}</b><span className="sv-small sv-muted">MRN {p.id} · DOB {p.dob}</span><button type="button" className="sv-link sv-small" onClick={() => { setPid(''); setEp(''); }}>Change</button></div>
        : <><input className="sv-input" placeholder="Name or MRN…" value={q} onChange={e => setQ(e.target.value)} data-testid="a87-up-q" />{hits.length > 0 && <div className="a84-drop">{hits.map(h => <button key={h.id} type="button" onClick={() => { setPid(h.id); setQ(''); }} data-testid="a87-up-hit"><b>{h.name}</b> <span>MRN {h.id} · DOB {h.dob}</span></button>)}</div>}</>}</label>
      <label className="a84-f" style={{ gridColumn: 'span 2' }}><span className="a84-l">Episode / date of service</span><select className="sv-input" value={ep} onChange={e => setEp(e.target.value)} disabled={!p} data-testid="a87-up-ep"><option value="">General (not tied to a surgery)</option>{eps.map(c => <option key={c.id} value={c.id}>{dosL(c.date)} · {c.procedure}</option>)}</select></label>
      <label className="a84-f" style={{ gridColumn: 'span 2' }}><span className="a84-l">Note (optional)</span><input className="sv-input" value={note} onChange={e => setNote(e.target.value)} placeholder="e.g. brought in by patient" /></label></div>
    <label className="a87-drop" data-testid="a87-up-drop"><input type="file" multiple accept="image/*,application/pdf,.doc,.docx,.txt" onChange={e => setFiles(Array.from(e.target.files || []))} data-testid="a87-up-files" /><Upload size={22} /><b>Choose files or take photos</b><span className="sv-small sv-muted">A scanned stack as one multipage PDF, photos or documents · several at once</span></label>
    {files.length > 0 && <ul className="a87-files" data-testid="a87-up-list">{files.map(f => <li key={f.name}>{f.name} <span className="sv-muted">· {Math.round(f.size / 1024)} KB</span></li>)}</ul>}
    {err && <p className="a81-err" data-testid="a87-up-err">{err}</p>}
    <p className="sv-small sv-muted">Files go to the case documents folder{station ? `, marked as uploaded at ${station}` : ''}, and every upload is audit-logged.</p></Dlg>;
};

/* ======================= Standard doctor's orders list (Practice settings) ======================= */
export const StandingOrdersSettings: React.FC = () => {
  useMedTick(); const [actor] = useActor(); const { toast } = useSv(); const [l, setL] = useState<P.StandingOrder[]>(() => D.standing()); const dirty = JSON.stringify(l) !== JSON.stringify(D.standing()); const [cat, setCat] = useState<P.OrderCat | ''>('');
  const up = (id: string, x: Partial<P.StandingOrder>) => setL(l.map(o => o.id === id ? { ...o, ...x } : o));
  return <section className="sv-sec mt-8 a87-std" id="standing-orders" data-testid="a87-standing"><h2 className="sv-title" style={{ fontSize: 20 }}>Standard doctor’s orders list</h2>
    <p className="sv-small sv-muted">One general standing-order list for pre-op, PACU and post-op orders. The case Orders section pulls from it; the doctor picks items, can always adjust the dose, and signs with their PIN. Nightingale only proposes drafts.</p>
    <div className="a86-banner" data-testid="a87-std-banner">⚠ Seeded entries are typical ASC examples with example doses, <b>for Medical Director approval</b>. They are not a clinical protocol until approved.</div>
    <div className="a82-row mb-2">{(['', 'Pre-op', 'PACU', 'Post-op'] as const).map(k => <button key={k || 'all'} type="button" className={`a87-kf ${cat === k ? 'on' : ''}`} onClick={() => setCat(k)}>{k || 'All'} {l.filter(o => !k || o.category === k).length}</button>)}</div>
    <div className="a83-scroll"><table className="sv-table a87-stdt"><thead><tr><th /><th>Category</th><th>Order</th><th>Drug</th><th>Dose</th><th>Route</th><th>Frequency</th><th>Signer</th><th>Active</th></tr></thead><tbody>
      {l.map((o, i) => (!cat || o.category === cat) && <tr key={o.id} data-testid="a87-std-row" className={o.active ? '' : 'off'}><td className="nowrap"><button type="button" className="v7-icon-btn" aria-label="Move up" onClick={() => setL(P.move(l, i, -1))} data-testid="a87-std-up"><ArrowUp size={13} /></button><button type="button" className="v7-icon-btn" aria-label="Move down" onClick={() => setL(P.move(l, i, 1))}><ArrowDown size={13} /></button></td>
        <td><select className="sv-input" value={o.category} onChange={e => up(o.id, { category: e.target.value as P.OrderCat })}><option>Pre-op</option><option>PACU</option><option>Post-op</option></select></td>
        <td><input className="sv-input" value={o.text} onChange={e => up(o.id, { text: e.target.value })} data-testid="a87-std-text" />{o.example && <span className="a87-ex" data-testid="a87-std-ex">{P.EXAMPLE_LABEL}</span>}</td>
        {(['drug', 'dose', 'route', 'freq'] as const).map(k => <td key={k}><input className="sv-input" value={o[k] || ''} onChange={e => up(o.id, { [k]: e.target.value })} data-testid={`a87-std-${k}`} /></td>)}
        <td><select className="sv-input" value={o.signer} onChange={e => up(o.id, { signer: e.target.value as any })}><option value="surgeon">Surgeon</option><option value="anesthesia">Anesthesiologist</option></select></td>
        <td className="text-center"><input type="checkbox" checked={o.active} onChange={e => up(o.id, { active: e.target.checked })} aria-label="Active" data-testid="a87-std-active" /></td></tr>)}</tbody></table></div>
    <div className="a81-foot"><button type="button" className="a8-btn" onClick={() => setL([...l, { id: uid('so'), category: (cat || 'Pre-op') as P.OrderCat, text: 'New order', active: true, signer: 'surgeon' }])} data-testid="a87-std-add"><Plus size={14} /> Add order</button><span style={{ flex: 1 }} />
      <button type="button" className="a8-btn" disabled={!dirty} onClick={() => setL(D.standing())}>Undo changes</button><button type="button" className="a8-btn pri" disabled={!dirty} onClick={() => { D.saveStanding(l, actor.name, actor.role, `${l.length} entries saved`); toast('Standard orders saved.'); }} data-testid="a87-std-save">Save list</button></div></section>;
};
/** Order items for a new case order set, from the active standing list (dose prefilled; original kept). */
export function standingItems(phase: P86.Phase): P86.OrderItem[] { return D.standing().filter(o => o.active && P.CAT_PHASE[o.category] === phase).map(o => ({ id: o.id, text: P.orderLine(o), on: true, ...(o.drug ? { field: 'Dose', value: o.dose || '', orig: o.dose || '' } : {}) } as any)); }

/* ======================= Cash-pay invoice (v7.5 structure) ======================= */
/** v8.9: ONE fee schedule. Lines = schedule charges; insured cases show the estimated plan share so the invoice total equals the check-in balance; an agreed quote adds an adjustment line. */
export function buildLines(c: A.AscCase): P.InvLine[] { const ch = caseCharges(c); const out: P.InvLine[] = ch.lines.map(l => ({ label: l.label, detail: l.detail, amount: l.amount }));
  const sp = isSelfPay89(payTypeOf(c)); const pct = schedule().insuredSharePct;
  if (!sp) out.push({ label: 'Insurance', detail: `Estimated plan responsibility (${100 - pct}%) · billed to ${payTypeOf(c)}`, amount: -Math.round(ch.total * (100 - pct)) / 100 });
  const sub = Math.round(out.reduce((n, l) => n + l.amount, 0) * 100) / 100;
  if (typeof c.d.quote === 'number' && Math.abs(c.d.quote - sub) > 0.004) out.push({ label: 'Adjustment', detail: 'Agreed quote for this case', amount: Math.round((c.d.quote - sub) * 100) / 100 });
  return out; }
export const InvoiceDialog: React.FC<{ cid: string; onClose: () => void }> = ({ cid, onClose }) => {
  useMedTick(); const [actor] = useActor(); const { toast } = useSv(); const c = S.caseById(cid); const [amt, setAmt] = useState(''); const [method, setMethod] = useState('Card (simulated)'); const [err, setErr] = useState('');
  if (!c) return null; const p = medRepo.patient(c.pid)!; const inv = D.invoiceFor(c.id); const lines = inv?.lines || buildLines(c); const pays = [...casePays(c.id).map(x => ({ amount: x.amount, at: x.at, method: x.method, receipt: x.receipt })), ...creditApps(c.id)]; const t = P.invoiceTotals(lines, pays); const cash = P.isCash(payTypeOf(c));
  const gen = () => { const i: D.AscInvoice = inv ? { ...inv, lines: buildLines(c) } : { id: uid('inv'), number: P.invoiceNumber(c.date, D.nextSeq()), cid: c.id, pid: c.pid, dos: c.date, payType: payTypeOf(c), lines: buildLines(c), createdAt: new Date().toISOString(), createdBy: actor.name, issued: { at: new Date().toISOString(), by: actor.name } }; D.saveInvoice(i, actor.name, actor.role, inv ? 'regenerated from the fee schedule' : `generated · total ${money(P.invoiceTotals(i.lines, []).total)}`);
    const need = P.invoiceTotals(i.lines, [...casePays(c.id), ...creditApps(c.id)]).balance; const ap = need > 0 ? applyCreditTo(c.id, c.pid, need, actor.name, actor.role) : 0;
    toast(`Invoice ${i.number} ${inv ? 'updated' : 'generated'}.${ap ? ` Account credit ${money(ap)} applied.` : ''}`); return i; };
  const pay = () => { try { collectPayment(c, +amt, method, '', actor.name, actor.role, c.loc === 'scheduled' ? 'pre-service' : 'other'); setAmt(''); setErr(''); toast('Payment recorded (simulated).'); } catch (e) { setErr((e as Error).message); } };
  const print = () => { D86.logPrint(c.id, actor.name, actor.role, `Invoice ${inv?.number || '(draft)'}`); window.print(); };
  return <Dlg kicker="Billing & payments" title={inv ? `Invoice ${inv.number}` : 'Cash-pay invoice'} sub={`${p.name} · DOS ${dosL(c.date)} · ${c.procedure}`} testId="a87-invoice" onClose={onClose}
    foot={<><span className={`a87-st ${t.status.startsWith('Paid') ? 'ok' : t.paid ? 'part' : 'due'}`} data-testid="a87-inv-status">{inv ? t.status : 'Not generated'}</span><span style={{ flex: 1 }} /><button type="button" className="a8-btn" onClick={gen} data-testid="a87-inv-gen"><Receipt size={15} /> {inv ? 'Regenerate from fee schedule' : 'Generate invoice'}</button>{inv && <button type="button" className="a8-btn" onClick={print} data-testid="a87-inv-print"><Printer size={15} /> Print</button>}</>}>
    <BillingPanel c={c} inv={inv} onNeedInvoice={() => gen()} />
    {!cash && <p className="a86-tint warn sv-small">Payment type is {payTypeOf(c)}. This invoice is for the patient-responsible (cash-pay) part.</p>}
    <div className="a87-inv a86-printwrap" data-testid="a87-inv-doc"><Letterhead number={inv?.number} issued={inv ? new Date(inv.createdAt).toLocaleDateString('en-US') : undefined} />
      <div className="a87-billto"><BillToBlock c={c} /><div><span className="sv-label">Service</span><b>{c.procedure}</b><div className="sv-small">DOS {c.date} · {c.surgeon} · {c.room}</div><div className="sv-small">Payment type: {payTypeOf(c)}</div></div></div>
      <table className="sv-table a87-invt"><thead><tr><th>Item</th><th>Detail</th><th className="r">Amount</th></tr></thead><tbody>{lines.map((l, i) => <tr key={i} data-testid="a87-inv-line"><td>{l.label}</td><td className="sv-small">{l.detail}</td><td className="r">{money(l.amount)}</td></tr>)}</tbody>
        <tfoot><tr><td colSpan={2}><b>Total</b></td><td className="r"><b data-testid="a87-inv-total">{money(t.total)}</b></td></tr>{pays.map(x => <tr key={x.receipt} className="paid"><td colSpan={2}>{/^CR-/.test(x.receipt) ? 'Account credit applied' : x.at < (inv?.createdAt || '9') ? 'Deposit' : 'Payment'} · {x.receipt} · {x.method} · {new Date(x.at).toLocaleDateString('en-US')}</td><td className="r">−{money(x.amount)}</td></tr>)}
          <tr className="bal"><td colSpan={2}><b>Balance due</b></td><td className="r"><b data-testid="a87-inv-balance">{money(t.balance)}</b></td></tr>{t.credit > 0 && <tr><td colSpan={2}>Credit on account</td><td className="r">{money(t.credit)}</td></tr>}</tfoot></table>
      <p className="sv-small sv-muted">Fictional test data. Amounts from the practice fee schedule (Practice › Billing settings). Printed manually; no PDF is generated or saved.</p></div>
    {inv && t.balance > 0 && <div className="a81-foot a87-pay" data-testid="a87-inv-pay"><CreditCard size={16} /><input className="sv-input" style={{ width: 130 }} placeholder="Amount" inputMode="decimal" value={amt} onChange={e => setAmt(e.target.value)} data-testid="a87-inv-amt" /><button type="button" className="sv-link sv-small" onClick={() => setAmt(String(t.balance))}>Full balance</button><button type="button" className="a8-btn pri" onClick={() => openCardPay({ cid: c.id, amount: +amt || t.balance })} data-testid="a87-inv-record">Collect payment</button></div>}
    {err && <p className="a81-err">{err}</p>}</Dlg>;
};
/** Billing & Payments › Invoices: every case with its invoice status. */
export const InvoicesList: React.FC = () => { useMedTick(); const [q, setQ] = useState(''); const cs = S.cases().filter(c => !q || pn(c).toLowerCase().includes(q.toLowerCase())).sort((a, b) => b.date.localeCompare(a.date));
  return <section className="v7-card" style={{ padding: 16 }} data-testid="a87-invoices"><div className="a82-row"><h3 className="a81-h3" style={{ flex: 1 }}>Cash-pay invoices</h3><input className="sv-input" style={{ width: 220 }} placeholder="Search patient" value={q} onChange={e => setQ(e.target.value)} /></div>
    <div className="a83-scroll"><table className="sv-table"><thead><tr><th>DOS</th><th>Patient</th><th>Procedure</th><th>Payment type</th><th>Invoice</th><th>Total</th><th>Balance</th><th>Status</th><th /></tr></thead><tbody>{cs.map(c => { const inv = D.invoiceFor(c.id); const t = P.invoiceTotals(inv?.lines || buildLines(c), [...casePays(c.id).map(x => ({ amount: x.amount, at: x.at, method: x.method, receipt: x.receipt })), ...creditApps(c.id)]);
      return <tr key={c.id} data-testid="a87-inv-row"><td>{c.date}</td><td>{pn(c)}</td><td>{c.procedure}</td><td>{payTypeOf(c)}</td><td>{inv?.number || '—'}</td><td>{money(t.total)}</td><td>{money(t.balance)}</td><td>{inv ? t.status : 'Not generated'}</td><td><button type="button" className="sv-link sv-small" onClick={() => openInvoice(c.id)} data-testid="a87-inv-open">{inv ? 'Open' : 'Generate'}</button></td></tr>; })}</tbody></table></div></section>; };
