/* ASC.Vityls v8.4 · v7.7 scheduler popups on the ASC2 case model (restyled to the current palette):
 * "Add new appointment" / "Appointment details" (new + existing case) and "Block operating room time". Fictional data. */
import { surgeonChoices, anesthesiaChoices, ProviderOptions, REAL_PRACTICE, anesList } from '../asc83/booking';
import { blockDates } from '../asc88/pure88';
import React, { useState } from 'react';
import { medRepo, uid, ageFrom } from '../../med/record';
import { useActor } from '../../med/ui';
import { useSv } from '../ui';
import { repo } from '../../v6/dataLayer';
import { svRead, svWrite } from '../store';
import * as A from '../asc8/logic';
import * as S from '../asc8/store';
import { XClose } from '../asc82/common';
import { completeIntakeBooking, setPendingBook } from '../asc82/intake';
import { normDob } from '../asc82/pure';
import { consumeBlock } from '../asc91/block91';
import { surgeonList, surgeonColor, tint, ANES_TYPES, type BookInit } from '../asc83/booking';
import { caseMoney } from '../asc83/pay';
import { cancelCase } from '../asc83/frontdesk';
import * as D86 from '../asc86/store86';
import * as P86 from '../asc86/pure86';
import { LENGTHS84, lenLabel84, billingChip, blockDays, blockTotal } from './pure84';

export const PAY_TYPES84 = ['Self-Pay', 'Commercial insurance', 'Medicare', 'Medicaid', 'Workers comp', 'Financing'];
const SLOTS = Array.from({ length: 48 }, (_, i) => { const m = 6 * 60 + i * 15; const h = Math.floor(m / 60), mm = m % 60; return `${String(((h + 11) % 12) + 1).padStart(2, '0')}:${String(mm).padStart(2, '0')} ${h < 12 ? 'AM' : 'PM'}`; });
const F: React.FC<{ l: string; req?: boolean; children: React.ReactNode; span?: number }> = ({ l, req, children, span }) => <label className="a84-f" style={span ? { gridColumn: `span ${span}` } : undefined}><span className="a84-l">{l}{req && <em> (Required)</em>}</span>{children}</label>;
export const Dlg: React.FC<{ kicker?: string; title: string; sub?: string; testId: string; onClose: () => void; foot: React.ReactNode; children: React.ReactNode }> = ({ kicker, title, sub, testId, onClose, foot, children }) =>
  <div className="a81-modal a83-modal" onMouseDown={e => { if (e.target === e.currentTarget) onClose(); }}><div className="a81-dialog a83-dlg a84-dlg" role="dialog" aria-label={title} data-testid={testId}>
    <div className="a84-dhead"><span className="ic">📅</span><div className="min-w-0 flex-1">{kicker && <div className="k">{kicker}</div>}<h2>{title}</h2>{sub && <p>{sub}</p>}</div><XClose onClick={onClose} testId={`${testId}-close`} /></div>
    <div className="a81-dbody">{children}</div><div className="a83-foot">{foot}</div></div></div>;

/** New appointment (init) or Appointment details for an existing case (cid). */
export const AppointmentDialog: React.FC<{ init?: BookInit; cid?: string; onClose: () => void }> = ({ init, cid, onClose }) => {
  const [actor] = useActor(); const { toast, go } = useSv(); const c0 = cid ? S.caseById(cid) : undefined; const d = init?.draft || {}; const pb = init?.pb;
  const anesGuess = (x = '') => ANES_TYPES.find(t => x && t.toLowerCase().startsWith(x.toLowerCase().slice(0, 3))) || (/mac/i.test(x) ? ANES_TYPES[1] : /local/i.test(x) ? ANES_TYPES[3] : x ? ANES_TYPES[0] : '');
  const payGuess = (x = '') => /self|cash/i.test(x) ? 'Self-Pay' : /medicare/i.test(x) ? 'Medicare' : /medicaid/i.test(x) ? 'Medicaid' : x ? 'Commercial insurance' : '';
  const p0 = c0 ? medRepo.patient(c0.pid) : pb?.patientId ? medRepo.patient(pb.patientId) : undefined;
  const [f, setF] = useState(() => c0 ? { date: c0.date, time: c0.time, len: c0.durationMin, room: c0.room, pid: c0.pid, q: p0?.name || '', dob: p0?.dob || '', phone: p0?.phone || '', procedure: c0.procedure, surgeon: c0.surgeon, anesthesiologist: c0.anesthesia || S.ANES[0], anesType: c0.d.anesType || '', payType: c0.d.payType || payGuess((p0 as any)?.insurance), notes: c0.d.bookingNotes || '' }
    : { date: init!.date, time: init!.time || '07:30 AM', len: init!.len || d.duration || pb?.duration || 90, room: init!.room || 'OR 1', pid: p0?.id || '', q: p0?.name || d.name || '', dob: p0?.dob || d.dob || '', phone: p0?.phone || d.phone || '', procedure: d.procedure || pb?.reason || '', surgeon: init!.surgeon || pb?.provider || (REAL_PRACTICE() ? (surgeonChoices().find(x => x.approved)?.name || '') : S.PATEL), anesthesiologist: (anesList()[0] || ''), anesType: anesGuess(d.anesthesia || pb?.anesthesia), payType: payGuess(d.payType), notes: d.notes || pb?.notes || '' });
  const [err, setErr] = useState(''); const [show, setShow] = useState(false); const [del, setDel] = useState(false); const [dupOk, setDupOk] = useState(false); const set = (k: string, v: any) => setF(x => ({ ...x, [k]: v }));
  const pt = f.pid ? medRepo.patient(f.pid) : undefined; const q = f.q.trim().toLowerCase();
  const hits = show && !pt && q.length >= 3 ? medRepo.patients().filter(p => p.name.toLowerCase().split(/\s+/).some(w => w.startsWith(q)) || p.name.toLowerCase().includes(q)).slice(0, 6) : [];
  const surgeons = surgeonList(); if (!surgeons.includes(f.surgeon)) surgeons.push(f.surgeon);
  const busy = S.cases().filter(c => c.id !== cid && c.date === f.date && c.room === f.room && A.toMin(c.time) < A.toMin(f.time) + f.len && A.toMin(f.time) < A.toMin(c.time) + c.durationMin);
  const age = f.dob && /\d{4}/.test(f.dob) ? `${ageFrom(normDob(f.dob) || f.dob)} y` : '';
  const chip = billingChip(f.payType, c0 ? caseMoney(c0) : undefined);
  const save = () => { const miss = [!pt && !f.q.trim() && 'patient', !pt && !f.dob.trim() && 'date of birth', !f.procedure.trim() && 'procedure', !f.surgeon && 'surgeon', !f.anesType && 'type of anesthesia', !f.payType && 'payment type'].filter(Boolean);
    if (miss.length) return setErr(`Still needed: ${miss.join(', ')}.`);
    if (c0) { const diff = P86.scheduleDiff(c0, f); if (diff) { D86.logSched(c0.pid, c0.id, { at: new Date().toISOString(), by: actor.name, role: actor.role, kind: 'rescheduled', from: diff, notices: ['Booking confirmation re-sent (simulated)', 'Two-day reminder re-queued (simulated)', 'Station tasks follow the new date'] }); D86.queueReminders(c0.id, (p0?.name || '').split(' ')[0], f.date, f.time); }
      const v = medRepo.visit(c0.visitId); if (v) medRepo.saveVisit({ ...v, date: f.date, time: f.time, durationMin: f.len, provider: f.surgeon, room: f.room, reason: f.procedure.trim(), notes: f.notes || undefined } as any);
      S.saveCase({ ...c0, date: f.date, time: f.time, durationMin: f.len, room: f.room, surgeon: f.surgeon, anesthesia: f.anesthesiologist, procedure: f.procedure.trim(), d: { ...c0.d, payType: f.payType, anesType: f.anesType, bookingNotes: f.notes, equipment: (f as any).equip ?? c0.d.equipment } }, actor.name, actor.role, `Appointment updated: ${f.date} ${f.time} · ${f.room} · ${f.surgeon}`);
      toast('Appointment saved.'); return onClose(); }
    let pid = pt?.id; if (!pid && !dupOk) { const dups = P86.dupCandidates(f.q, f.dob, f.phone, medRepo.patients()); if (dups.length) { const d0 = dups[0]; D86.incDup(); setF(x => ({ ...x, pid: d0.p.id, q: d0.p.name, dob: d0.p.dob, phone: d0.p.phone || x.phone })); return setErr(`Possible duplicate: ${d0.p.name} (MRN ${d0.p.id}, DOB ${d0.p.dob}) has the ${d0.why}. The existing chart is now selected; save again to book on it, or clear the name to create a new patient.`); } }
    if (!pid) { pid = uid('ASC-N'); medRepo.savePatient({ id: pid, name: f.q.trim(), dob: normDob(f.dob) || f.dob, sex: /^f/i.test(d.sex || '') ? 'Female' : /^m/i.test(d.sex || '') ? 'Male' : 'Other', phone: f.phone, email: d.email || '', language: 'English', allergies: [], primaryProvider: f.surgeon, careTeam: [], insurance: f.payType, fictional: true } as any);
      repo.audit({ caseId: 'practice', user: actor.name, role: actor.role, action: 'asc84.patient' as any, detail: `New patient ${f.q.trim()} created from the appointment popup` }); }
    const v = { id: uid('visit'), patientId: pid, date: f.date, time: f.time, durationMin: f.len, provider: f.surgeon, room: f.room, visitType: 'Surgery case', reason: f.procedure.trim(), notes: f.notes || undefined, step: 'scheduled', problemIds: [], createdAt: new Date().toISOString(), createdBy: actor.name } as any;
    medRepo.saveVisit(v);
    const b = completeIntakeBooking(pb || { intakeId: '', patientId: pid, date: f.date, time: f.time, room: f.room, provider: f.surgeon, duration: f.len, reason: f.procedure, notes: f.notes, source: 'scheduler', anesthesia: f.anesType, email: d.email, phone: f.phone }, v, actor.name, actor.role);
    S.saveCase({ ...b, anesthesia: f.anesthesiologist, room: f.room, d: { ...b.d, payType: f.payType, anesType: f.anesType, bookingNotes: f.notes, assistant: d.assistant, equipment: (f as any).equip || undefined, bookedAt: new Date().toISOString(), bookedBy: actor.name } }, actor.name, actor.role, `Booked: ${f.procedure} · ${f.surgeon} · ${f.anesType} · ${f.payType}`);
    if (init?.blockId) consumeBlock(init.blockId, f.date, f.time, f.len, actor.name, actor.role, medRepo.patient(pid)!.name);
    D86.logSched(pid, b.id, { at: new Date().toISOString(), by: actor.name, role: actor.role, kind: 'booked', to: `${f.date} ${f.time} ${f.room}`, notices: ['Booking confirmation (simulated)', 'Two-day reminder queued (simulated)', 'Portal registration request (simulated)'] }); D86.queueReminders(b.id, medRepo.patient(pid)!.name.split(' ')[0], f.date, f.time);
    toast(`Appointment saved for ${medRepo.patient(pid)!.name} · ${f.time.replace(/^0/, '')} · ${f.room}. Portal forms sent (simulated).`); onClose(); };
  const close = () => { if (pb) setPendingBook(null); onClose(); };
  return <Dlg kicker={f.room || 'Scheduler'} title={c0 ? 'Appointment details' : 'Add new appointment'} sub="Search the patient, surgeon and anesthesiologist (matches appear after 3 letters)." testId="a83-booking" onClose={close}
    foot={<>{c0 && <button type="button" className="a8-btn red" onClick={() => setDel(true)} data-testid="a84-appt-delete">🗑 Delete</button>}<span style={{ flex: 1 }} />
      {pt && <button type="button" className="a8-btn" onClick={() => { close(); go({ type: 'chart', pid: pt.id } as any); }} data-testid="a84-appt-chart">Open chart</button>}
      <button type="button" className="a8-btn pri" onClick={save} data-testid="a83-book-save">💾 Save appointment</button></>}>
    {pb && <p className="a82-prefill" data-testid="a82-book-prefill">Pre-filled from the {pb.source === 'fax' ? 'scanned fax' : pb.source === 'email' ? 'email' : ''} booking request. Check and save; the surgery case is created when you save.</p>}
    <div className="a84-billing">Billing: <span className={`a83-pay ${chip.cls}`} data-testid="a84-billing-chip">{chip.text}</span></div>
    <div className="a84-grid4">
      <F l="Date of Service (DOS)"><input type="date" className="sv-input" value={f.date} onChange={e => set('date', e.target.value)} data-testid="a83-book-date" /></F>
      <F l="Start time"><select className="sv-input" value={f.time} onChange={e => set('time', e.target.value)} data-testid="a83-book-time">{(SLOTS.includes(f.time) ? SLOTS : [f.time, ...SLOTS]).map(s => <option key={s}>{s}</option>)}</select></F>
      <F l="Length of surgery"><select className="sv-input" value={f.len} onChange={e => set('len', +e.target.value)} data-testid="a83-book-len">{(LENGTHS84.includes(f.len) ? LENGTHS84 : [f.len, ...LENGTHS84]).map(n => <option key={n} value={n}>{lenLabel84(n)}</option>)}</select></F>
      <F l="Operating room"><select className="sv-input" value={f.room} onChange={e => set('room', e.target.value)} data-testid="a83-book-room">{S.ROOMS.map(r => <option key={r}>{r}</option>)}</select></F>
      <label className="a84-f a84-rel"><span className="a84-l">Patient name</span><span className="a84-search"><input className="sv-input" placeholder="Type patient last name…" value={f.q} autoComplete="off" onChange={e => { setF(x => ({ ...x, q: e.target.value, pid: '' })); setShow(true); }} onFocus={() => setShow(true)} data-testid="a83-book-name" />{f.q && <button type="button" aria-label="Clear patient" onClick={() => setF(x => ({ ...x, q: '', pid: '', dob: c0 ? x.dob : '', phone: '' }))} data-testid="a84-clear-patient">✕</button>}</span>
        {hits.length > 0 && <div className="a84-drop" data-testid="a83-book-hits"><div className="h">Matching patients ({hits.length}) · select to auto-fill</div>{hits.map(h => <button key={h.id} type="button" onClick={() => { setF(x => ({ ...x, pid: h.id, q: h.name, dob: h.dob, phone: h.phone || '' })); setShow(false); }} data-testid="a83-book-hit"><b>{h.name}</b> <span>DOB {h.dob} · {h.phone}</span></button>)}</div>}
        {show && !pt && q.length >= 3 && !hits.length && <div className="a84-drop"><div className="sv-small sv-muted" style={{ padding: 8 }}>No match: keep typing to create a new patient.</div></div>}</label>
      <F l="DOB"><input className="sv-input" placeholder="MM/DD/YYYY" value={f.dob} readOnly={!!pt} onChange={e => set('dob', e.target.value)} data-testid="a83-book-dob" /></F>
      <F l="Age"><input className="sv-input" value={age} readOnly tabIndex={-1} data-testid="a84-book-age" /></F>
      <F l="Phone"><input className="sv-input" placeholder="e.g. (310) 555-1234" value={f.phone} readOnly={!!pt} onChange={e => set('phone', e.target.value)} /></F>
      <F l="Procedure" span={4}><input className="sv-input" placeholder="Full procedure description (include side)" value={f.procedure} onChange={e => set('procedure', e.target.value)} data-testid="a83-book-proc" /></F>
      <F l="Surgeon"><select className="sv-input" value={f.surgeon} onChange={e => set('surgeon', e.target.value)} data-testid="a83-book-surgeon" style={{ borderLeft: `5px solid ${surgeonColor(f.surgeon)}` }}>{REAL_PRACTICE() ? <ProviderOptions list={surgeonChoices()} value={f.surgeon} none="Add surgeons in Practice settings › Providers" /> : surgeons.map(s => <option key={s}>{s}</option>)}</select></F>
      <F l="Anesthesiologist"><select className="sv-input" value={f.anesthesiologist} onChange={e => set('anesthesiologist', e.target.value)} data-testid="a84-book-anesthesiologist">{REAL_PRACTICE() ? <ProviderOptions list={anesthesiaChoices()} value={f.anesthesiologist} none="Add anesthesia providers in Practice settings › Providers" /> : S.ANES.map(s => <option key={s}>{s}</option>)}</select></F>
      <F l="Type of anesthesia"><select className="sv-input" value={f.anesType} onChange={e => set('anesType', e.target.value)} data-testid="a83-book-anes"><option value="">Choose…</option>{ANES_TYPES.map(s => <option key={s}>{s}</option>)}</select></F>
      <F l="Payment type" req><select className="sv-input" value={f.payType} onChange={e => set('payType', e.target.value)} data-testid="a83-book-pay"><option value="">Choose…</option>{PAY_TYPES84.map(s => <option key={s}>{s}</option>)}</select></F>
      <F l="Notes" span={4}><textarea className="sv-input" rows={2} placeholder="Clinical notes, pre-op instructions, equipment or patient preferences…" value={f.notes} onChange={e => set('notes', e.target.value)} data-testid="a83-book-notes" /></F>
      <F l="Special equipment / implants" span={4}><input className="sv-input" placeholder="e.g. C-arm, mini fragment set, tourniquet" value={(f as any).equip ?? (c0?.d.equipment || '')} onChange={e => (set as any)('equip', e.target.value)} data-testid="v103-book-equip" /></F>
    </div>
    {busy.length > 0 && <p className="a84-warn" data-testid="a83-book-clash">{f.room} already has {busy.map(c => `${medRepo.patient(c.pid)?.name} ${c.time.replace(/^0/, '')}`).join(', ')} at this time (double-booking allowed).</p>}
    {err && <p className="a81-err" data-testid="a83-book-err">{err}</p>}
    {err.startsWith('Possible duplicate') && <div className="a86-tint warn" data-testid="a86-dup"><button type="button" className="a8-btn" onClick={() => { setDupOk(true); setErr(''); setF(x => ({ ...x, pid: '' })); }} data-testid="a86-dup-new">Not the same person: create a new chart (logged)</button></div>}
    {c0 && <details className="a81-box mt-2" data-testid="a86-sched-hist"><summary>Schedule history &amp; notifications ({D86.schedHistory(c0.pid).filter(h => true).length})</summary>{D86.schedHistory(c0.pid).map((h, i) => <div key={i} className="a81-line sv-small" data-testid="a86-hist-row"><b>{h.kind}</b> · {new Date(h.at).toLocaleString()} · {h.by} · {h.from || h.to}{h.reason ? ` · ${h.reason}` : ''} · {h.notices.join('; ')}</div>)}
      {D86.reminders(c0.id).map((r, i) => <div key={'r' + i} className="a81-line sv-small" data-testid="a86-reminder"><b>{r.kind}</b> · {r.on} · {r.status}<pre className="a81-pre">{r.body}</pre></div>)}</details>}
    {del && c0 && <div className="a83-cancel" data-testid="a84-delete-confirm"><b>Delete this appointment?</b> The case is cancelled and archived in the chart (audited).<div className="a82-row mt-2" style={{ gap: 8 }}><button type="button" className="a8-btn" onClick={() => setDel(false)}>Keep</button><button type="button" className="a8-btn red" onClick={() => { cancelCase(c0, 'Deleted from the schedule', '', actor.name, actor.role); toast('Appointment deleted (case archived).'); onClose(); }} data-testid="a84-delete-yes">Delete appointment</button></div></div>}
  </Dlg>;
};

/** v7.7 Block operating room time: provider/assignee · room & time window · day cards (2 weeks) · total blocks. */
export const BlockTime84: React.FC<{ day: string; onClose: () => void }> = ({ day, onClose }) => {
  const [actor] = useActor(); const { toast } = useSv(); const surgeons = surgeonList(); const days = blockDays(day, 14);
  const [f, setF] = useState({ who: surgeons[0] || S.PATEL, custom: '', room: 'OR 1', start: '07:00 AM', end: '12:00 PM', from: day, to: day, dow: [new Date(day + 'T12:00:00Z').getUTCDay()] as number[], notes: '' }); const sel = blockDates(f.from, f.to, f.dow); const [err, setErr] = useState('');
  const who = f.who === '__custom' ? f.custom.trim() : f.who; const rooms = f.room === '__all' ? S.ROOMS : [f.room]; const total = blockTotal(sel.length, rooms.length);
  const tog = (x: number) => setF(v => ({ ...v, dow: v.dow.includes(x) ? v.dow.filter(y => y !== x) : [...v.dow, x] })); void days;
  const save = () => { if (!who) return setErr('Choose who the block is for.'); if (!sel.length) return setErr('Pick a date range and at least one day of the week.'); if (A.toMin(f.end) <= A.toMin(f.start)) return setErr('End must be after start.');
    const l = svRead<any[]>('block-seed', []); const plan = sel.flatMap(date => rooms.map(room => ({ date, room })));
    const clash = plan.find(p => l.some(b => b.date === p.date && b.room === p.room && A.toMin(b.start) < A.toMin(f.end) && A.toMin(f.start) < A.toMin(b.end))); if (clash) return setErr(`${clash.room} already has block time on ${clash.date}.`);
    svWrite('block-seed', [...l, ...plan.map(p => ({ id: uid('blk'), surgeon: who, date: p.date, start: f.start, end: f.end, room: p.room, notes: f.notes }))]);
    repo.audit({ caseId: 'practice', user: actor.name, role: actor.role, action: 'asc81.block' as any, detail: `Block time ${who} · ${rooms.join(', ')} · ${plan.length} block(s) ${f.start}–${f.end}` }); window.dispatchEvent(new Event('vityls-med-updated'));
    toast(`${plan.length} block${plan.length === 1 ? '' : 's'} saved for ${who.replace(/,.*$/, '')}.`); onClose(); };
  return <Dlg kicker="Scheduler" title="Block operating room time" sub="Reserve surgeon block time, turnover buffers, or maintenance holds across rooms and days (recurring or single)." testId="a81-block-dialog" onClose={onClose}
    foot={<><span className="sv-small" style={{ flex: 1 }} data-testid="a83-block-count">Selected: <b>{sel.length} day(s)</b> · Total blocks to generate: <b>{total} block(s)</b></span><button type="button" className="a8-btn" onClick={onClose}>Cancel</button><button type="button" className="a8-btn pri" disabled={!sel.length} onClick={save} data-testid="a81-block-save">🔒 Block time</button></>}>
    <section className="a84-bsec"><h3><span className="n">1</span>Provider / Assignee <small>Select provider for blocked slot</small></h3>
      <div className="a84-grid4"><F l="Assigned to" span={2}><select className="sv-input" value={f.who} onChange={e => setF({ ...f, who: e.target.value })} data-testid="a81-block-surgeon">{surgeons.map(s => <option key={s}>{s}</option>)}<option value="__custom">Other team / maintenance…</option></select></F>
        {f.who === '__custom' && <F l="Name" span={2}><input className="sv-input" placeholder="Enter custom provider or team name..." value={f.custom} onChange={e => setF({ ...f, custom: e.target.value })} /></F>}</div>
      <p className="sv-small">Assigned to: <b>{who || '—'}</b></p></section>
    <section className="a84-bsec"><h3><span className="n">2</span>Operating Room &amp; Time Window <span className="a84-tag">{rooms.length} room{rooms.length === 1 ? '' : 's'}</span></h3>
      <div className="a84-grid4"><F l="Operating room"><select className="sv-input" value={f.room} onChange={e => setF({ ...f, room: e.target.value })} data-testid="a84-block-room"><option value="__all">All Configured Rooms</option>{S.ROOMS.map(r => <option key={r}>{r}</option>)}</select></F>
        <F l="Start time"><select className="sv-input" value={f.start} onChange={e => setF({ ...f, start: e.target.value })}>{SLOTS.map(s => <option key={s}>{s}</option>)}</select></F><F l="End time"><select className="sv-input" value={f.end} onChange={e => setF({ ...f, end: e.target.value })}>{SLOTS.map(s => <option key={s}>{s}</option>)}</select></F>
        <F l="Notes"><input className="sv-input" placeholder="e.g. Reserved for revisions" value={f.notes} onChange={e => setF({ ...f, notes: e.target.value })} /></F></div></section>
    <section className="a84-bsec"><h3><span className="n">3</span>Date range &amp; days of the week <span style={{ marginLeft: 'auto' }} /><button type="button" className="sv-link sv-small" onClick={() => setF({ ...f, dow: [1, 2, 3, 4, 5] })} data-testid="a84-block-weekdays">All weekdays</button><button type="button" className="sv-link sv-small" onClick={() => setF({ ...f, dow: [] })}>Clear</button></h3>
      <div className="a84-grid4"><F l="Start date"><input type="date" className="sv-input" value={f.from} onChange={e => setF({ ...f, from: e.target.value, to: f.to < e.target.value ? e.target.value : f.to })} data-testid="a88-block-from" /></F><F l="End date"><input type="date" className="sv-input" value={f.to} min={f.from} onChange={e => setF({ ...f, to: e.target.value })} data-testid="a88-block-to" /></F></div>
      <div className="a88-dow" role="group" aria-label="Days of the week">{[[1, 'Mon'], [2, 'Tue'], [3, 'Wed'], [4, 'Thu'], [5, 'Fri'], [6, 'Sat'], [0, 'Sun']].map(([n, l]) => <button key={n} type="button" className={`a88-dowb ${f.dow.includes(n as number) ? 'on' : ''}`} aria-pressed={f.dow.includes(n as number)} onClick={() => tog(n as number)} data-testid={`a88-dow-${l}`}>{l}</button>)}</div>
      <p className="sv-small sv-muted" data-testid="a88-block-preview">{sel.length ? `Generates ${sel.length} date(s): ${sel.slice(0, 6).join(', ')}${sel.length > 6 ? ` … ${sel[sel.length - 1]}` : ''}` : 'No dates in this range for the chosen days.'}</p></section>
    {err && <p className="a81-err" data-testid="a81-block-err">{err}</p>}
  </Dlg>;
};
