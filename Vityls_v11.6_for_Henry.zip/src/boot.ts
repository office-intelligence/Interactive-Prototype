/* Vityls OS v11.5 · entry point.
 * 1. Signed in to a practice created at /signup? Open that practice (src/os/org/bind.ts) before anything reads storage.
 * 2. Connect to the database (when configured) before the app reads its first record.
 * 3. Start the app. */
import { bindSignedInPractice } from './os/org/bind';
bindSignedInPractice().catch(() => false).then(async reloading => {
  if (reloading) return; // the page is reloading into the signed-in user's practice
  try { const { startRemote } = await import('./os/data/remote'); await startRemote(); } catch { /* the app still opens on this device's cache */ }
  import('./main');
});
