# Vityls v11.4 merged (Kevin's one app + Henry's Azure server): build, package and deploy to vityls-portal-test.
# Run from the portal folder:   .\deploy-portal.bat      (or: powershell -ExecutionPolicy Bypass -File .\deploy-portal.ps1)
# The app runs straight from the zip (app settings WEBSITE_RUN_FROM_PACKAGE=1, SCM_DO_BUILD_DURING_DEPLOYMENT=false, ENABLE_ORYX_BUILD=false).
# Options:  -NoDeploy   build and make the zip only (portal-deploy.zip in this folder), no upload.
param([switch]$NoDeploy)

$ErrorActionPreference = 'Stop'
$root  = $PSScriptRoot
$zip   = Join-Path $root 'portal-deploy.zip'
$group = 'vityls-v75-grok_group'
$app   = 'vityls-portal-test'
Set-Location $root

function Step($text) { Write-Host ""; Write-Host "==> $text" -ForegroundColor Cyan }
function Fail($text) { Write-Host ""; Write-Host "STOPPED: $text" -ForegroundColor Red; exit 1 }

if (-not (Test-Path 'server.ts') -or -not (Test-Path 'server-package.json')) { Fail "Run this from the merged v11.4 folder (server.ts and server-package.json not found here)." }

Step "1/4 Build (one app: ASC + Surgery + Medical practices, saves to Azure)"
Remove-Item Env:VITE_CORE, Env:VITE_PORTAL -ErrorAction SilentlyContinue
$env:VITE_ONE = '1'; $env:VITE_EDITION = 'ASC2'; $env:VITE_DEMO = '1'; $env:VITE_API_URL = '/api'
npm run build
if ($LASTEXITCODE -ne 0) { Fail "The build failed. Scroll up for the red error." }
if (-not (Test-Path 'dist\server.cjs')) { Fail "dist\server.cjs is missing - the server part of the build did not run." }
if (-not (Select-String -Path 'dist\assets\*.js' -Pattern 'vityls-db-badge' -List -Quiet)) { Fail "The database code is not in the build (src\med\dbSync.ts or src\main.tsx missing?)." }

Step "2/4 Check the server file (packages are bundled inside server.cjs since v11.6, so no node_modules folder is uploaded)"
if (Test-Path 'dist\node_modules') { Remove-Item 'dist\node_modules' -Recurse -Force }
Copy-Item 'server-package.json' 'dist\package.json' -Force
$ext = Select-String -Path 'dist\server.cjs' -Pattern 'require\("(express|dotenv|mssql|qrcode|adm-zip|@azure/[a-z-]+|@google/genai)"\)' -List
if ($ext) { Fail "dist\server.cjs still needs outside packages ($($ext.Matches[0].Value)). Check the build line in package.json (it must not say --packages=external)." }

Step "3/4 Zip -> $zip"
if (Test-Path $zip) { Remove-Item $zip -Force }
# The Linux server runs straight from the zip, so every path inside it must use forward slashes (assets/index.js).
# Windows PowerShell's own zip tools write backslashes, so each file is added by hand with a "/" path.
Add-Type -AssemblyName System.IO.Compression, System.IO.Compression.FileSystem
$distFull = (Resolve-Path 'dist').Path
$za = [IO.Compression.ZipFile]::Open($zip, 'Create')
try {
  Get-ChildItem -LiteralPath $distFull -Recurse -File | ForEach-Object {
    $rel = $_.FullName.Substring($distFull.Length + 1).Replace('\', '/')
    [void][IO.Compression.ZipFileExtensions]::CreateEntryFromFile($za, $_.FullName, $rel, [IO.Compression.CompressionLevel]::Optimal)
  }
} finally { $za.Dispose() }
$zr = [IO.Compression.ZipFile]::OpenRead($zip)
try { $bad = @($zr.Entries | Where-Object { $_.FullName -like '*\*' }).Count; $hasJs = @($zr.Entries | Where-Object { $_.FullName -like 'assets/*.js' }).Count } finally { $zr.Dispose() }
if ($bad -gt 0) { Fail "The zip has $bad paths with backslashes." }
if ($hasJs -eq 0) { Fail "The zip has no assets/*.js file." }
$mb = [math]::Round((Get-Item $zip).Length / 1MB, 1)
Write-Host "Zip ready: $zip ($mb MB)"
if ($NoDeploy) { Step "Done (no upload). Upload $zip yourself, or run again without -NoDeploy."; exit 0 }

Step "4/4 Upload to $app (tries up to 3 times if the connection drops)"
for ($try = 1; $try -le 3; $try++) {
  az webapp deploy -g $group -n $app --src-path $zip --type zip --track-status false
  if ($LASTEXITCODE -eq 0) {
    Write-Host ""
    Write-Host "UPLOADED. The app restarts from the new zip; wait 1-2 minutes, then open https://$app.azurewebsites.net/login" -ForegroundColor Green
    Write-Host "If it does not come up: az webapp log tail -g $group -n $app" -ForegroundColor Green
    exit 0
  }
  if ($try -lt 3) { Write-Host "Upload try $try failed - trying again in 10 seconds..." -ForegroundColor Yellow; Start-Sleep -Seconds 10 }
}
Fail "Upload failed 3 times. If it says 'az login', run: az login --tenant f1f6517f-8cf9-48ab-982e-5e8dca0dfded   then run this again."
