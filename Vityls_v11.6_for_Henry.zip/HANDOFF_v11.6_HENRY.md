# Vityls v11.6 handoff for Henry

Nov 10, 2026 · from Kevin

v11.6 is live on `vityls-portal-test` as of the morning of Nov 10, 2026. This note covers everything since Henry's v11.4 merged build: v11.5 (Nov 7–9) and v11.6 (Nov 9–10).

## What to send Henry

1. **The project zip:** `C:\Vityls\Vityls_v11.4_merged\Vityls_v11.6_for_Henry.zip`. It holds the full source and this note as `HANDOFF_v11.6_HENRY.md`. It leaves out `.env`, `node_modules`, `_backups`, `dist` and `portal-deploy.zip`. Henry runs `npm install` to get `node_modules` back.
2. **This note:** share its link, or download it as Word or PDF.
3. **Secrets, separately:** send them through a password manager or in person, never by email or text. They are the same values as the App Service settings on `vityls-portal-test`, so Henry may already have them there: `MFA_KEY`, `STORAGE_KEY`, `GEMINI_API_KEY` and `SIGNUP_CODE`, plus `SQL_SERVER` and `SQL_DATABASE`. `MFA_KEY` must stay exactly the same, or every authenticator code stops working.

`.env.example` in the zip lists every setting with comments and no values. Henry copies it to `.env` and fills it in.

## How deployment works now

The app now runs straight from the uploaded zip, and an upload takes seconds instead of timing out. Three deploys failed on Nov 9–10 until these changes were made:

| Change | Why |
| --- | --- |
| Server packages are bundled into `dist/server.cjs` (build line in `package.json`: `--external:vite` instead of `--packages=external`) | `dist/node_modules` was thousands of small files; Azure's unpacking timed out on B1 and left a half-installed site |
| `deploy-portal.ps1` writes zip entries with forward slashes and checks the zip before uploading | Windows PowerShell's zip tools write `assets\index.js`; the Linux server then could not find `assets/` or `node_modules/` (blank page, then "Cannot find module 'express'") |
| `deploy-portal.ps1` no longer runs `npm install` in `dist` | Nothing outside `server.cjs` is needed at run time |

New App Service settings on `vityls-portal-test` (set Nov 10):

| Setting | Value |
| --- | --- |
| `WEBSITE_RUN_FROM_PACKAGE` | `1` |
| `SCM_DO_BUILD_DURING_DEPLOYMENT` | `false` |
| `ENABLE_ORYX_BUILD` | `false` |

The startup command is unchanged: `NODE_ENV=production node server.cjs`. To deploy, run `deploy-portal.bat` from the project folder. It builds, checks, zips and uploads; the app is back within 1–2 minutes. The app folder on the server is read-only now; the server writes no local files (data goes to Azure SQL and Blob storage), so nothing depends on it.

## Server changes since v11.4

`server.ts` gained about 540 lines. There are no new database tables or columns: the new routes use the existing `dbo.Organizations`, `dbo.Sites`, `dbo.Users`, `dbo.Providers`, `dbo.AuthSessions`, `dbo.AuditEvents` and `app.record` / `app.record_history`.

| Route | Version | What it does |
| --- | --- | --- |
| `GET /signup`, `POST /api/signup/practice` | v11.5 | Creates a practice (organization, site, administrator) from scratch; needs `SIGNUP_CODE` |
| `PUT /api/office/providers` | v11.5 | Saves the practice's providers to `dbo.Providers` |
| `POST /api/auth/lock`, `/api/auth/unlock`, `/api/auth/pin` | v11.5 | Screen lock with PIN unlock; fixes the idle timeout |
| `POST /api/auth/forget-device` | v11.5 | Ends "remember this computer for 30 days" |
| `GET /api/owner/me` | v11.6 | Whether the signed-in user is a Vityls owner |
| `GET /api/owner/practices` | v11.6 | Owner console list: every organization with user, provider and patient counts, start date, last sign-in (counts only, no patient data) |
| `GET` / `PUT /api/owner/data` | v11.6 | Owner records: fee schedule, plans per practice, payments, vendor configuration; stored in `app.record` under tenant `vityls-owner`, history kept |

Settings:

| Setting | Status | Use |
| --- | --- | --- |
| `OWNER_USERNAMES` | New in v11.6, **add on Azure** | Comma-separated sign-in usernames that can open the owner console at `/#ceo` (for example `kevin,henry`); not secret |
| `SIGNUP_CODE` | New in v11.5, already on Azure | Code required at `/signup`; secret |

The owner routes refuse anyone signed out (401) or not listed (403). `PUT /api/owner/data` rejects any vendor row that contains something that looks like an API key: the console stores only the *name* of the App Service setting that holds each key, and reports only whether that setting exists. `/api/health` now explains why the database cannot be reached.

## App changes in v11.5 and v11.6

Kevin tested these in his local build with the Beverly Hills Surgery Center practice; they went live together on Nov 10. Newest first:

| Date | Area | Change |
| --- | --- | --- |
| Nov 10 | Deployment | Bundled server, forward-slash zip, run from package (see above) |
| Nov 9 | Owner console | New page at `/#ceo` for Kevin and Henry: practices with live counts, plan, fee, payments; fee schedule (monthly and yearly prices, module add-ons, extra-provider price, setup fee, trial days); Vityls configuration for outside vendors (card processing, insurance EDI, AI, email, SMS, fax) with the name of each key's App Service setting and whether it is set |
| Nov 9 | Schedule | Card shows time without icon ("8:00–10:00 AM"), patient, surgeon and anesthesia as "S. Austin, MD", procedure, notes |
| Nov 9 | Forms | Facility-specific text in the Admission form replaced with bracketed placeholders and instructions (health department, accreditor, physician owners); old "Upload ID" section removed from Registration; no "Save & go to signatures" button |
| Nov 9 | Patient portal | Patients see and sign only their own signature lines; a form counts as returned once the patient has signed (staff sign later) |
| Nov 9 | Patient forms link | The `#portal-forms=` link in the forms text and email opens a patient page: date-of-birth check (5 tries), only the forms sent, status, save and return for 30 days; audit entries for opens and wrong tries |
| Nov 9 | Send forms | Outbox of the messages sent to each patient, with Open patient link and Copy link |
| Nov 9 | Providers | Anesthesiologist and CRNA roles; the appointment's anesthesia list is grouped by role |
| Nov 9 | Schedule | Provider-colour cards, drag to move, drag the bottom edge to resize, undo |
| Nov 9 | Patient chart | Missing list = pre-surgery items with direct actions; allergies show "Not reported" until confirmed |
| Nov 9 | Compliance | Document request emails with a secure upload link, review of received documents, automatic reminders |
| Nov 8 | Compliance | Compliance center: credentials audit, accreditation audit, inspection binder, log sheets, document register, task list |
| Nov 8 | Patients | Working list (Today, Upcoming, Needs attention, Recent, All) and search by name, date of birth or phone |
| Nov 8 | Booking | Surgeon and anesthesia lists come from the practice's own providers |
| Nov 8 | Credentialing | Medical Director decisions signed with PIN, Review again, approval letter PDF |
| Nov 7 | Practice setup | `/signup` for a new practice; onboarding wizard; full practice profile with offices; schedule hours set by the practice; rooms as columns for new ASC schedules |
| Nov 7 | Sign-in | Remember this computer for 30 days; screen lock with PIN; signed-out visitors go straight to sign-in |

## Open items for Henry

The next test round needs a near-final app with real email, text messages, AI and document storage; Finix and Stedi follow, then final testing.

**For the next round**

- [ ] Real email through Azure Communication Services: invitations, forms links, reminders, approval letters, document requests. Today these go to a simulated outbox in the app.
- [ ] Real text messages (SMS) for reminders and portal links.
- [ ] Live AI: `GEMINI_API_KEY` is read by `/api/ai/chat`; confirm the key and the agents Nightingale should run.
- [ ] Document storage end to end: uploads (ID and insurance cards, provider documents, compliance documents) to Blob storage.
- [ ] Patient forms link on the patient's own phone: two endpoints, `GET /portal-forms/:id` with the date-of-birth check and `PUT` for the answers. Today the page reads and saves through the practice's browser storage (note at the top of `src/surgery/PortalFormsLanding.tsx`).
- [ ] Owner console against the real database: it was tested on a stand-in database only. Add `OWNER_USERNAMES` on Azure, open `/#ceo`, and check the Practices tab.
- [ ] Plans control modules: read the practice's plan from the owner records at sign-in, so the modules ticked in the owner console turn on or off inside the practice's app.

**Later**

- [ ] Finix (card processing) and Stedi (insurance EDI); the owner console's Vityls configuration tab already lists them with their setting names.
- [ ] Server-side patient search and loading a chart on demand, for practices with 10,000+ patients (deferred by Kevin).
- [ ] Desktop and mobile shells: start the Apple and Google developer accounts and a permanent web address now; build the shells alongside Finix and Stedi.
- [ ] Animated Vityls loading indicator while long tasks run.
