import express from "express";
import fs from "fs";
import crypto from "crypto";
import path from "path";
import dotenv from "dotenv";
// Azure note: "vite" (dev only) and "@google/genai" (AI calls, switched off) are loaded on demand,
// so the production server needs no node_modules folder: dist/server.cjs is self-contained.

dotenv.config();

const app = express();
const PORT = Number(process.env.PORT) || 3000;

// The record store (/api/v1) takes bigger bodies (whole record lists); everything else stays at 1 MB.
const json1mb = express.json({ limit: "1mb" });
app.use((req, res, next) => (req.path.startsWith("/api/v1/") ? next() : json1mb(req, res, next)));

// Initialize Gemini client lazily
async function getGenAI() {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) return null;
  const { GoogleGenAI } = await import("@google/genai");
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        "User-Agent": "aistudio-build",
      },
    },
  });
}

// ---------------------------------------------------------------------------
// Azure SQL (step 3a): connection check + practices and their patients.
// TEST DATA ONLY. /api/db/health and /api/db/practices show no patient data; patients need a login.
// Signs in with the app's own Azure identity (managed identity) - no passwords.
// Settings come from App Service app settings: SQL_SERVER, SQL_DATABASE.
// "mssql" is loaded on demand and shipped in dist/node_modules (pure JavaScript).
// ---------------------------------------------------------------------------
let dbPool: Promise<any> | null = null;
let sqlLib: any = null;

async function getDb(): Promise<any> {
  const server = process.env.SQL_SERVER;
  const database = process.env.SQL_DATABASE;
  if (!server || !database) throw new Error("Database is not configured (set SQL_SERVER and SQL_DATABASE).");
  if (!dbPool) {
    dbPool = (async () => {
      const mod: any = await import("mssql");
      const sql = mod.default ?? mod;
      sqlLib = sql;
      const pool = new sql.ConnectionPool({
        server,
        database,
        port: 1433,
        options: { encrypt: true, trustServerCertificate: false },
        authentication: { type: "azure-active-directory-default", options: {} },
        pool: { max: 5, min: 0, idleTimeoutMillis: 30000 },
      });
      return pool.connect();
    })().catch((e) => { dbPool = null; throw e; });
  }
  return dbPool;
}

app.get("/api/db/health", async (_req, res) => {
  try {
    const pool = await getDb();
    const r = await pool.request().query(
      "SELECT DB_NAME() AS [database], SUSER_SNAME() AS signedInAs, SYSUTCDATETIME() AS serverTimeUtc"
    );
    res.json({ status: "connected", ...r.recordset[0] });
  } catch (e: any) {
    console.error("DB health error:", e);
    // v11.5: spell out the real reason (the driver often wraps it: firewall, sign-in, permission). No secrets in here.
    const reasons: string[] = []; const seen = new Set<any>();
    const walk = (x: any, d = 0) => { if (!x || d > 5 || seen.has(x)) return; seen.add(x);
      const m = [x.code, x.message].filter(Boolean).join(": "); if (m && !reasons.includes(m)) reasons.push(m);
      (x.errors || []).forEach((y: any) => walk(y, d + 1)); walk(x.originalError, d + 1); walk(x.cause, d + 1); };
    walk(e);
    const all = reasons.join(" | ");
    const hint = /not allowed to access the server|Client with IP address/i.test(all) ? "The database firewall blocks this computer: SQL server > Security > Networking > Add your client IPv4 address > Save."
      : /Login failed|token-identified principal|AADSTS|not.*authorized/i.test(all) ? "Your Microsoft account is not allowed into this database: SQL server > Settings > Microsoft Entra ID (set an admin), or ask Henry to add your account as a database user."
      : /az login|AzureCliCredential|CredentialUnavailable|DefaultAzureCredential|EnvironmentCredential/i.test(all) ? "No Microsoft sign-in found on this computer: run az login in the terminal, then restart npm run dev."
      : /ENOTFOUND|getaddrinfo/i.test(all) ? "The server name was not found: check SQL_SERVER in .env (something.database.windows.net)."
      : /ETIMEOUT|timeout|ESOCKET|ECONNRESET/i.test(all) ? "No answer from the database: the firewall may block this computer, or the network blocks port 1433."
      : "";
    res.status(500).json({ status: "error", message: e?.message || String(e), details: reasons.slice(0, 8), hint });
  }
});

// All practices in the dev database, with patient counts (fictional test data only).
app.get("/api/db/practices", async (_req, res) => {
  try {
    const pool = await getDb();
    const r = await pool.request().query(`
      SELECT o.OrganizationId, o.OrganizationCode, o.OrganizationName,
             (SELECT COUNT(*) FROM dbo.Patients p WHERE p.OrganizationId = o.OrganizationId AND p.IsActive = 1) AS PatientCount,
             (SELECT COUNT(*) FROM dbo.Sites s WHERE s.OrganizationId = o.OrganizationId AND s.IsActive = 1) AS SiteCount
      FROM dbo.Organizations o
      WHERE o.IsActive = 1
      ORDER BY o.OrganizationCode`);
    res.json({ count: r.recordset.length, practices: r.recordset });
  } catch (e: any) {
    console.error("DB practices error:", e);
    res.status(500).json({ status: "error", message: e?.message || String(e) });
  }
});

// ---------------------------------------------------------------------------
// Sign-in with MFA (step 4).
//  1. Username + password  -> a short "half signed-in" session (10 minutes, no data access).
//  2. 6-digit code from Google Authenticator (TOTP) -> full session (8 hours, 30-minute idle timeout).
//     First time: the page shows a QR code to scan, then asks for a code to confirm it.
//  3. If a manager reset the password (MustChangePassword), the user picks a new one before going on.
// Passwords: same format as the existing apps, "salt:hash" with Node scrypt (keylen 64).
// Sessions: random token in an HttpOnly cookie; only its SHA-256 is stored (dbo.AuthSessions).
// 5 wrong passwords or codes lock the account for 15 minutes.
// MFA secrets: this app's own columns (MfaTotpSecret...), encrypted with AES-256-GCM using the
// MFA_KEY app setting. ChatGPT's app columns (MfaEnabled, MfaSecretEncrypted) are left untouched.
// ---------------------------------------------------------------------------
const SESSION_COOKIE = "vityls_sid";
const IDLE_MINUTES = 30;
const SESSION_HOURS = 8;
const PENDING_MINUTES = 10;
const MAX_FAILED = 5;
const LOCK_MINUTES = 15;
const MFA_ISSUER = "Vityls Test";

function sha256(buf: Buffer | string): Buffer { return crypto.createHash("sha256").update(buf).digest(); }

function verifyPassword(password: string, stored: string | null): boolean {
  if (!stored) return false;
  const [salt, expectedHex] = stored.split(":");
  if (!salt || !expectedHex) return false;
  const actual = crypto.scryptSync(password, salt, 64);
  const expected = Buffer.from(expectedHex, "hex");
  return expected.length === actual.length && crypto.timingSafeEqual(actual, expected);
}
function hashPassword(password: string): string {
  const salt = crypto.randomBytes(16).toString("hex");
  return `${salt}:${crypto.scryptSync(password, salt, 64).toString("hex")}`;
}
function passwordProblem(pw: string, username: string): string | null {
  if (pw.length < 10) return "Use at least 10 characters.";
  if (pw.length > 200) return "That password is too long.";
  if (username && pw.toLowerCase().includes(username.toLowerCase())) return "Don't include your username in the password.";
  return null;
}

function readCookie(req: any, name: string): string | null {
  const raw = String(req.headers.cookie || "");
  for (const part of raw.split(";")) {
    const i = part.indexOf("=");
    if (i > 0 && part.slice(0, i).trim() === name) return decodeURIComponent(part.slice(i + 1).trim());
  }
  return null;
}

// --- TOTP (the 6-digit codes Google Authenticator shows; RFC 6238, SHA-1, 30 seconds) ---
const B32 = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";
function base32Encode(buf: Buffer): string {
  let bits = 0, value = 0, out = "";
  for (const byte of buf) {
    value = (value << 8) | byte; bits += 8;
    while (bits >= 5) { out += B32[(value >>> (bits - 5)) & 31]; bits -= 5; }
  }
  if (bits > 0) out += B32[(value << (5 - bits)) & 31];
  return out;
}
function totpAt(secret: Buffer, step: number): string {
  const msg = Buffer.alloc(8);
  msg.writeBigUInt64BE(BigInt(step));
  const h = crypto.createHmac("sha1", secret).update(msg).digest();
  const o = h[h.length - 1] & 15;
  return String((h.readUInt32BE(o) & 0x7fffffff) % 1000000).padStart(6, "0");
}
// Accepts the current code and one either side (phone clock drift). Each code works only once.
function checkTotp(secret: Buffer, code: string, lastStep: number | null): number | null {
  if (!/^\d{6}$/.test(code)) return null;
  const now = Math.floor(Date.now() / 30000);
  for (const step of [now, now - 1, now + 1]) {
    if (lastStep != null && step <= lastStep) continue;
    if (crypto.timingSafeEqual(Buffer.from(totpAt(secret, step)), Buffer.from(code))) return step;
  }
  return null;
}

// --- MFA secret encryption (MFA_KEY app setting: 32 random bytes, base64). Never change it once set. ---
function mfaKey(): Buffer {
  const k = Buffer.from(process.env.MFA_KEY || "", "base64");
  if (k.length !== 32) throw new Error("MFA_KEY app setting is missing or is not 32 bytes (base64).");
  return k;
}
function encryptSecret(secret: Buffer): string {
  const iv = crypto.randomBytes(12);
  const c = crypto.createCipheriv("aes-256-gcm", mfaKey(), iv);
  const ct = Buffer.concat([c.update(secret), c.final()]);
  return ["v1", iv.toString("base64"), c.getAuthTag().toString("base64"), ct.toString("base64")].join(":");
}
function decryptSecret(stored: string | null): Buffer | null {
  const parts = String(stored || "").split(":");
  if (parts.length !== 4 || parts[0] !== "v1") return null;
  try {
    const d = crypto.createDecipheriv("aes-256-gcm", mfaKey(), Buffer.from(parts[1], "base64"));
    d.setAuthTag(Buffer.from(parts[2], "base64"));
    return Buffer.concat([d.update(Buffer.from(parts[3], "base64")), d.final()]);
  } catch { return null; }
}

// --- Sessions ---
// Any live session (half or fully signed in), with the user's practice. Also refreshes the idle timer.
async function sessionFor(req: any): Promise<any | null> {
  const token = readCookie(req, SESSION_COOKIE);
  if (!token || !/^[a-f0-9]{64}$/.test(token)) return null;
  const pool = await getDb();
  const r = await pool.request()
    .input("h", sqlLib.VarBinary(32), sha256(token))
    .input("idle", sqlLib.Int, IDLE_MINUTES)
    .query(`SELECT TOP 1 s.AuthSessionId, s.MfaVerifiedAt, u.UserId, u.Username, u.FirstName, u.LastName, u.OrganizationId,
                   u.MustChangePassword, u.PasswordHash, u.MfaTotpSecret, u.MfaTotpEnabledAt, u.MfaTotpLastStep,
                   o.OrganizationCode, o.OrganizationName
            FROM dbo.AuthSessions s
            JOIN dbo.Users u ON u.UserId = s.UserId
            JOIN dbo.Organizations o ON o.OrganizationId = u.OrganizationId
            WHERE s.SessionTokenHash = @h AND s.RevokedAt IS NULL AND s.ExpiresAt > SYSUTCDATETIME()
              AND s.LastActivityAt > DATEADD(minute, -@idle, SYSUTCDATETIME()) AND u.IsActive = 1;
            UPDATE dbo.AuthSessions SET LastActivityAt = SYSUTCDATETIME()
            WHERE SessionTokenHash = @h AND RevokedAt IS NULL AND ExpiresAt > SYSUTCDATETIME()
              AND LastActivityAt > DATEADD(minute, -@idle, SYSUTCDATETIME());`);
  return r.recordset[0] || null;
}
// Fully signed in (password + MFA code, and no password change pending). Only this can see data.
async function currentUser(req: any): Promise<any | null> {
  const s = await sessionFor(req);
  return s && s.MfaVerifiedAt && !s.MustChangePassword ? s : null;
}
async function countFailure(pool: any, userId: any): Promise<boolean> {
  const r = await pool.request().input("id", userId).input("max", MAX_FAILED).input("lock", LOCK_MINUTES).query(
    `UPDATE dbo.Users SET FailedLoginCount = FailedLoginCount + 1,
            LockedUntil = CASE WHEN FailedLoginCount + 1 >= @max THEN DATEADD(minute, @lock, SYSUTCDATETIME()) ELSE LockedUntil END
     WHERE UserId = @id;
     SELECT CASE WHEN LockedUntil > SYSUTCDATETIME() THEN 1 ELSE 0 END AS IsLocked FROM dbo.Users WHERE UserId = @id;`);
  return !!r.recordset[0]?.IsLocked;
}
function nextStep(s: any): string {
  if (!s.MfaVerifiedAt) return decryptSecret(s.MfaTotpSecret) && s.MfaTotpEnabledAt ? "mfa" : "mfa-setup";
  if (s.MustChangePassword) return "change-password";
  return "done";
}
const authFail = (res: any, status: number, message: string) => res.status(status).json({ status: "error", message });

// ---------------------------------------------------------------------------
// v11.5 (Kevin): easier sign-in for a busy center, same security.
//  1. "Remember this computer for 30 days": after the 6-digit code is entered once with the box ticked, that browser
//     gets a second HttpOnly cookie (vityls_dev). Next sign-ins on it ask for the password only. A manager's password
//     reset, MFA reset or turning the account off forgets every remembered computer of that person.
//  2. Screen lock + PIN: after IDLE_MINUTES without use the app locks the screen (POST /api/auth/lock, or simply no
//     activity). Within the 8-hour sign-in, the person unlocks with a personal 4-8 digit PIN (POST /api/auth/unlock)
//     instead of signing in again. 5 wrong PINs end the sign-in. No PIN set: the full sign-in, as before.
// Stored in app.record under the server-only tenant "server-auth" (the app can never read or write it):
//   trust:<sha256 of the device token> = { userId, until, at, ua }      pin:<UserId> = { hash, at }
// ---------------------------------------------------------------------------
const DEVICE_COOKIE = "vityls_dev";
const TRUST_DAYS = 30;
const AUTH_TENANT = "server-auth";
const PIN_TRIES = 5;
async function authGet(pool: any, key: string): Promise<any | null> {
  try {
    const r = await pool.request().input("t", sqlLib.NVarChar(64), AUTH_TENANT).input("k", sqlLib.NVarChar(400), key)
      .query(`SELECT TOP 1 value_json AS v FROM app.record WHERE tenant_id = @t AND record_key = @k`);
    return r.recordset[0]?.v ? JSON.parse(r.recordset[0].v) : null;
  } catch { return null; }
}
async function authPut(pool: any, key: string, value: any | null, by: string) {
  const rq = pool.request().input("t", sqlLib.NVarChar(64), AUTH_TENANT).input("k", sqlLib.NVarChar(400), key).input("b", sqlLib.NVarChar(200), by.slice(0, 200));
  if (value === null) { await rq.query(`DELETE FROM app.record WHERE tenant_id = @t AND record_key = @k`); return; }
  await rq.input("v", sqlLib.NVarChar(sqlLib.MAX), JSON.stringify(value))
    .query(`MERGE app.record WITH (HOLDLOCK) AS d USING (SELECT @t AS tenant_id, @k AS record_key) AS s
              ON d.tenant_id = s.tenant_id AND d.record_key = s.record_key
            WHEN MATCHED THEN UPDATE SET value_json = @v, updated_at = SYSUTCDATETIME(), updated_by = @b
            WHEN NOT MATCHED THEN INSERT (tenant_id, record_key, value_json, updated_at, updated_by) VALUES (@t, @k, @v, SYSUTCDATETIME(), @b);`);
}
const cookieFlags = (req: any) => `Path=/; HttpOnly; SameSite=Strict${req.headers["x-forwarded-proto"] === "https" || process.env.NODE_ENV === "production" ? "; Secure" : ""}`;
const deviceKey = (req: any) => { const t = readCookie(req, DEVICE_COOKIE); return t && /^[a-f0-9]{64}$/.test(t) ? `trust:${sha256(t).toString("hex")}` : null; };
async function deviceTrusted(pool: any, req: any, userId: any): Promise<boolean> {
  const k = deviceKey(req); if (!k) return false;
  const t = await authGet(pool, k);
  return !!t && String(t.userId) === String(userId) && Date.parse(t.until) > Date.now();
}
async function forgetDevicesOf(pool: any, userId: any) {
  await pool.request().input("t", sqlLib.NVarChar(64), AUTH_TENANT).input("p", `%"userId":"${String(userId).replace(/[^0-9]/g, "")}"%`)
    .query(`DELETE FROM app.record WHERE tenant_id = @t AND record_key LIKE N'trust:%' AND value_json LIKE @p`);
}
function pinProblem(pin: string): string | null {
  if (!/^\d{4,8}$/.test(pin)) return "Use 4 to 8 digits.";
  if (/^(\d)\1+$/.test(pin)) return "Don't use the same digit for every number.";
  if ("0123456789".includes(pin) || "9876543210".includes(pin)) return "Don't use digits in a row (like 1234).";
  return null;
}
/** A full sign-in that has been idle past IDLE_MINUTES but not ended: the screen is locked. */
async function lockedSessionFor(req: any): Promise<any | null> {
  const token = readCookie(req, SESSION_COOKIE);
  if (!token || !/^[a-f0-9]{64}$/.test(token)) return null;
  const pool = await getDb();
  const r = await pool.request().input("h", sqlLib.VarBinary(32), sha256(token)).input("idle", sqlLib.Int, IDLE_MINUTES)
    .query(`SELECT TOP 1 s.AuthSessionId, u.UserId, u.Username, u.FirstName, u.LastName
            FROM dbo.AuthSessions s JOIN dbo.Users u ON u.UserId = s.UserId
            WHERE s.SessionTokenHash = @h AND s.RevokedAt IS NULL AND s.ExpiresAt > SYSUTCDATETIME() AND s.MfaVerifiedAt IS NOT NULL
              AND s.LastActivityAt <= DATEADD(minute, -@idle, SYSUTCDATETIME()) AND u.IsActive = 1 AND u.MustChangePassword = 0`);
  return r.recordset[0] || null;
}
const pinFails = new Map<string, number>();

app.post("/api/auth/login", async (req, res) => {
  const username = String(req.body?.username || "").trim();
  const password = String(req.body?.password || "");
  if (!username || !password) return authFail(res, 400, "Enter your username and password.");
  try {
    mfaKey(); // fail early and clearly if the app setting is missing
    const pool = await getDb();
    const u = (await pool.request().input("u", username).query(
      `SELECT TOP 1 UserId, Username, PasswordHash, MfaTotpSecret, MfaTotpEnabledAt, MustChangePassword,
              CASE WHEN LockedUntil > SYSUTCDATETIME() THEN 1 ELSE 0 END AS IsLocked
       FROM dbo.Users WHERE Username = @u AND IsActive = 1`)).recordset[0];
    if (!u) return authFail(res, 401, "Wrong username or password.");
    if (u.IsLocked) return authFail(res, 423, "This account is locked for 15 minutes after too many tries. Your manager can unlock it.");
    if (!verifyPassword(password, u.PasswordHash)) {
      await countFailure(pool, u.UserId);
      return authFail(res, 401, "Wrong username or password.");
    }
    const token = crypto.randomBytes(32).toString("hex");
    await pool.request()
      .input("id", u.UserId)
      .input("h", sqlLib.VarBinary(32), sha256(token))
      .input("min", PENDING_MINUTES)
      .input("ip", String(req.headers["x-forwarded-for"] || req.socket?.remoteAddress || "").slice(0, 64))
      .input("ua", String(req.headers["user-agent"] || "").slice(0, 500))
      .query(`INSERT dbo.AuthSessions (UserId, SessionTokenHash, ExpiresAt, IPAddress, UserAgent)
              VALUES (@id, @h, DATEADD(minute, @min, SYSUTCDATETIME()), @ip, @ua);`);
    const secure = req.headers["x-forwarded-proto"] === "https" || process.env.NODE_ENV === "production";
    res.setHeader("Set-Cookie", `${SESSION_COOKIE}=${token}; Path=/; HttpOnly; SameSite=Strict; Max-Age=${SESSION_HOURS * 3600}${secure ? "; Secure" : ""}`);
    // v11.5: on a computer remembered after a code was entered, the password is enough.
    if (u.MfaTotpEnabledAt && decryptSecret(u.MfaTotpSecret) && await deviceTrusted(pool, req, u.UserId)) {
      await pool.request().input("id", u.UserId).input("h", sqlLib.VarBinary(32), sha256(token)).input("hrs", SESSION_HOURS)
        .query(`UPDATE dbo.AuthSessions SET MfaVerifiedAt = SYSUTCDATETIME(), ExpiresAt = DATEADD(hour, @hrs, SYSUTCDATETIME()) WHERE SessionTokenHash = @h;
                UPDATE dbo.Users SET FailedLoginCount = 0, LockedUntil = NULL, LastLoginAt = SYSUTCDATETIME() WHERE UserId = @id;`);
      return res.json({ status: "ok", remembered: true, next: nextStep({ ...u, MfaVerifiedAt: new Date() }) });
    }
    res.json({ status: "ok", next: nextStep({ ...u, MfaVerifiedAt: null }) });
  } catch (e: any) {
    console.error("Login error:", e);
    authFail(res, 500, "Sign-in failed on the server. Check the app log.");
  }
});

// First-time MFA setup: QR code + typed key for Google Authenticator. Only while half signed in and not yet set up.
app.get("/api/auth/mfa/setup", async (req, res) => {
  try {
    const s = await sessionFor(req);
    if (!s || s.MfaVerifiedAt) return authFail(res, 401, "Sign in with your password first.");
    if (s.MfaTotpEnabledAt && decryptSecret(s.MfaTotpSecret)) return authFail(res, 409, "MFA is already set up for this account.");
    let secret = decryptSecret(s.MfaTotpSecret); // reuse a not-yet-confirmed secret so a scanned QR keeps working
    if (!secret) {
      secret = crypto.randomBytes(20);
      const pool = await getDb();
      await pool.request().input("id", s.UserId).input("sec", encryptSecret(secret)).query(
        `UPDATE dbo.Users SET MfaTotpSecret = @sec, MfaTotpEnabledAt = NULL, MfaTotpLastStep = NULL WHERE UserId = @id`);
    }
    const key = base32Encode(secret);
    const label = encodeURIComponent(`${MFA_ISSUER}:${s.Username}`);
    const uri = `otpauth://totp/${label}?secret=${key}&issuer=${encodeURIComponent(MFA_ISSUER)}&algorithm=SHA1&digits=6&period=30`;
    const qrMod: any = await import("qrcode");
    const qrSvg = await (qrMod.default ?? qrMod).toString(uri, { type: "svg", margin: 1, errorCorrectionLevel: "M" });
    res.json({ status: "ok", account: `${MFA_ISSUER} (${s.Username})`, key: key.replace(/(.{4})/g, "$1 ").trim(), qrSvg });
  } catch (e: any) {
    console.error("MFA setup error:", e);
    authFail(res, 500, "Could not start MFA setup. Check the app log.");
  }
});

app.post("/api/auth/mfa/verify", async (req, res) => {
  try {
    const s = await sessionFor(req);
    if (!s) return authFail(res, 401, "Your sign-in timed out. Start again.");
    if (s.MfaVerifiedAt) return res.json({ status: "ok", next: nextStep(s) });
    const secret = decryptSecret(s.MfaTotpSecret);
    if (!secret) return authFail(res, 409, "MFA is not set up yet. Start again.");
    const code = String(req.body?.code || "").replace(/\s/g, "");
    const pool = await getDb();
    const step = checkTotp(secret, code, s.MfaTotpLastStep == null ? null : Number(s.MfaTotpLastStep));
    if (step == null) {
      if (await countFailure(pool, s.UserId)) {
        await pool.request().input("sid", s.AuthSessionId).query(
          `UPDATE dbo.AuthSessions SET RevokedAt = SYSUTCDATETIME(), RevokeReason = N'locked' WHERE AuthSessionId = @sid`);
        return authFail(res, 423, "Too many wrong codes. The account is locked for 15 minutes.");
      }
      return authFail(res, 401, "That code didn't match. Use the newest code in Google Authenticator.");
    }
    await pool.request().input("id", s.UserId).input("sid", s.AuthSessionId).input("step", sqlLib.BigInt, step).input("hrs", SESSION_HOURS)
      .query(`UPDATE dbo.Users SET MfaTotpLastStep = @step, MfaTotpEnabledAt = ISNULL(MfaTotpEnabledAt, SYSUTCDATETIME()),
                     FailedLoginCount = 0, LockedUntil = NULL, LastLoginAt = SYSUTCDATETIME()
              WHERE UserId = @id;
              UPDATE dbo.AuthSessions SET MfaVerifiedAt = SYSUTCDATETIME(), ExpiresAt = DATEADD(hour, @hrs, SYSUTCDATETIME())
              WHERE AuthSessionId = @sid;`);
    if (req.body?.remember === true) { // v11.5: remember this computer for 30 days
      const dev = crypto.randomBytes(32).toString("hex");
      await authPut(pool, `trust:${sha256(dev).toString("hex")}`, { userId: String(s.UserId), until: new Date(Date.now() + TRUST_DAYS * 864e5).toISOString(),
        at: new Date().toISOString(), ua: String(req.headers["user-agent"] || "").slice(0, 200) }, s.Username);
      res.setHeader("Set-Cookie", `${DEVICE_COOKIE}=${dev}; ${cookieFlags(req)}; Max-Age=${TRUST_DAYS * 86400}`);
    }
    res.json({ status: "ok", next: nextStep({ ...s, MfaVerifiedAt: new Date() }) });
  } catch (e: any) {
    console.error("MFA verify error:", e);
    authFail(res, 500, "Could not check the code. Check the app log.");
  }
});

// New password: required after a manager reset; also usable any time (then the current password is needed).
app.post("/api/auth/change-password", async (req, res) => {
  try {
    const s = await sessionFor(req);
    if (!s || !s.MfaVerifiedAt) return authFail(res, 401, "Sign in first.");
    const current = String(req.body?.currentPassword || "");
    const next = String(req.body?.newPassword || "");
    if (!s.MustChangePassword && !verifyPassword(current, s.PasswordHash)) return authFail(res, 401, "Your current password is not right.");
    const problem = passwordProblem(next, s.Username);
    if (problem) return authFail(res, 400, problem);
    if (verifyPassword(next, s.PasswordHash)) return authFail(res, 400, "Pick a password you haven't just used.");
    const pool = await getDb();
    await pool.request().input("id", s.UserId).input("sid", s.AuthSessionId).input("ph", hashPassword(next)).query(
      `UPDATE dbo.Users SET PasswordHash = @ph, PasswordChangedAt = SYSUTCDATETIME(), MustChangePassword = 0 WHERE UserId = @id;
       UPDATE dbo.AuthSessions SET RevokedAt = SYSUTCDATETIME(), RevokeReason = N'password changed'
       WHERE UserId = @id AND AuthSessionId <> @sid AND RevokedAt IS NULL;`);
    res.json({ status: "ok", next: "done" });
  } catch (e: any) {
    console.error("Change password error:", e);
    authFail(res, 500, "Could not change the password. Check the app log.");
  }
});

app.post("/api/auth/logout", async (req, res) => {
  try {
    const token = readCookie(req, SESSION_COOKIE);
    if (token && /^[a-f0-9]{64}$/.test(token)) {
      const pool = await getDb();
      await pool.request().input("h", sqlLib.VarBinary(32), sha256(token)).query(
        `UPDATE dbo.AuthSessions SET RevokedAt = SYSUTCDATETIME(), RevokeReason = N'logout'
         WHERE SessionTokenHash = @h AND RevokedAt IS NULL`);
    }
  } catch (e) { console.error("Logout error:", e); }
  res.setHeader("Set-Cookie", `${SESSION_COOKIE}=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0`);
  res.json({ status: "ok" });
});

app.get("/api/auth/me", async (req, res) => {
  try {
    const s = await sessionFor(req);
    if (!s) {
      const l = await lockedSessionFor(req); // v11.5: idle -> locked screen (PIN), when the person has a PIN
      if (l && await authGet(await getDb(), `pin:${l.UserId}`)) return res.status(401).json({ status: "signed-out", next: "unlock", name: `${l.FirstName || ""} ${l.LastName || ""}`.trim() || l.Username, username: l.Username });
      return res.status(401).json({ status: "signed-out" });
    }
    const step = nextStep(s);
    if (step !== "done") return res.status(401).json({ status: "signed-out", next: step });
    const roles = await rolesOf(await getDb(), s.UserId);
    const prof = await orgProfile(await getDb(), s.OrganizationId);
    const hasPin = !!(await authGet(await getDb(), `pin:${s.UserId}`));
    const deviceRemembered = await deviceTrusted(await getDb(), req, s.UserId);
    res.json({ status: "signed-in", username: s.Username, name: `${s.FirstName || ""} ${s.LastName || ""}`.trim(),
               practice: s.OrganizationCode, practiceName: s.OrganizationName, isManager: roles.some(r => MANAGER_ROLES.includes(r)),
               // v11.5: practices created at /signup carry their edition; older ones (Henry's test practices) have none.
               edition: prof?.edition || null, roles, hasPin, deviceRemembered, idleMinutes: IDLE_MINUTES });
  } catch (e: any) { console.error("Me error:", e); res.status(500).json({ status: "error" }); }
});

// v11.5: lock the screen now (the app calls this after IDLE_MINUTES without use; "Lock" buttons can call it too).
app.post("/api/auth/lock", async (req, res) => {
  try {
    const s = await sessionFor(req); if (!s) return res.json({ status: "ok" });
    const pool = await getDb();
    await pool.request().input("sid", s.AuthSessionId).input("idle", sqlLib.Int, IDLE_MINUTES + 1)
      .query(`UPDATE dbo.AuthSessions SET LastActivityAt = DATEADD(minute, -@idle, SYSUTCDATETIME()) WHERE AuthSessionId = @sid`);
    res.json({ status: "ok", hasPin: !!(await authGet(pool, `pin:${s.UserId}`)) });
  } catch (e: any) { console.error("Lock error:", e); res.status(500).json({ status: "error" }); }
});
// v11.5: unlock a locked screen with the person's PIN.
app.post("/api/auth/unlock", async (req, res) => {
  try {
    const l = await lockedSessionFor(req);
    if (!l) return authFail(res, 401, "Your sign-in has ended. Sign in again.");
    const pool = await getDb();
    const rec = await authGet(pool, `pin:${l.UserId}`);
    if (!rec) return authFail(res, 409, "No PIN is set. Sign in again.");
    const pin = String(req.body?.pin || "").replace(/\s/g, "");
    const sid = String(l.AuthSessionId);
    if (!verifyPassword(pin, rec.hash)) {
      const n = (pinFails.get(sid) || 0) + 1; pinFails.set(sid, n);
      if (n >= PIN_TRIES) {
        pinFails.delete(sid);
        await pool.request().input("sid", l.AuthSessionId).query(`UPDATE dbo.AuthSessions SET RevokedAt = SYSUTCDATETIME(), RevokeReason = N'too many wrong PINs' WHERE AuthSessionId = @sid`);
        return authFail(res, 423, "Too many wrong PINs. Sign in again with your password.");
      }
      return authFail(res, 401, `That PIN is not right. ${PIN_TRIES - n} ${PIN_TRIES - n === 1 ? "try" : "tries"} left.`);
    }
    pinFails.delete(sid);
    await pool.request().input("sid", l.AuthSessionId).query(`UPDATE dbo.AuthSessions SET LastActivityAt = SYSUTCDATETIME() WHERE AuthSessionId = @sid`);
    res.json({ status: "ok", next: "done" });
  } catch (e: any) { console.error("Unlock error:", e); authFail(res, 500, "Could not unlock. Sign in again."); }
});
// v11.5: set or change your PIN (signed in fully).
app.post("/api/auth/pin", async (req, res) => {
  try {
    const s = await currentUser(req); if (!s) return authFail(res, 401, "Sign in first.");
    const pin = String(req.body?.pin || "").replace(/\s/g, "");
    const bad = pinProblem(pin); if (bad) return authFail(res, 400, bad);
    await authPut(await getDb(), `pin:${s.UserId}`, { hash: hashPassword(pin), at: new Date().toISOString() }, s.Username);
    res.json({ status: "ok" });
  } catch (e: any) { console.error("PIN error:", e); authFail(res, 500, "Could not save the PIN."); }
});
// v11.5: stop remembering this computer (the next sign-in here asks for the code again).
app.post("/api/auth/forget-device", async (req, res) => {
  try { const k = deviceKey(req); if (k) await authPut(await getDb(), k, null, "forget"); } catch (e) { console.error("Forget device error:", e); }
  res.setHeader("Set-Cookie", `${DEVICE_COOKIE}=; ${cookieFlags(req)}; Max-Age=0`);
  res.json({ status: "ok" });
});

// The signed-in user's OWN practice only. The practice comes from the session, never from the request.
app.get("/api/my/patients", async (req, res) => {
  try {
    const me = await currentUser(req);
    if (!me) return res.status(401).json({ status: "signed-out", message: "Sign in first." });
    const pool = await getDb();
    const r = await pool.request().input("org", String(me.OrganizationId)).query(
      `SELECT PatientId, PatientCode, FirstName, LastName, CONVERT(varchar(10), DateOfBirth, 23) AS DateOfBirth, City
       FROM dbo.Patients WHERE OrganizationId = @org AND IsActive = 1 ORDER BY LastName, FirstName`);
    res.json({ practice: me.OrganizationCode, count: r.recordset.length, patients: r.recordset });
  } catch (e: any) { console.error("My patients error:", e); res.status(500).json({ status: "error" }); }
});

// ---------------------------------------------------------------------------
// Office app (Surgery.Vityls / Medical.Vityls) patients + appointments in Azure SQL.
// Always scoped to the signed-in user's practice (from the session, never from the request).
// The browser's own record shape is kept in AppJson so nothing the screens need is lost.
// ---------------------------------------------------------------------------
const pad2 = (n: number) => String(n).padStart(2, "0");
function usToIsoDate(d: string): string | null {
  const s = String(d || "").trim();
  let m = s.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
  if (m) return `${m[3]}-${pad2(+m[1])}-${pad2(+m[2])}`;
  m = s.match(/^(\d{4})-(\d{2})-(\d{2})/);
  if (m) return `${m[1]}-${m[2]}-${m[3]}`;
  return null;
}
function isoToUsDate(d: string | null): string {
  const m = String(d || "").match(/^(\d{4})-(\d{2})-(\d{2})/);
  return m ? `${m[2]}/${m[3]}/${m[1]}` : "";
}
function to24h(t: string): string | null {
  const m = String(t || "").match(/(\d{1,2}):(\d{2})\s*(AM|PM)?/i);
  if (!m) return null;
  let h = +m[1];
  const ap = (m[3] || "").toUpperCase();
  if (ap === "PM" && h < 12) h += 12;
  if (ap === "AM" && h === 12) h = 0;
  return `${pad2(h)}:${m[2]}:00`;
}
function to12h(hhmm: string): string {
  const [hs, mm] = String(hhmm || "00:00").split(":");
  let h = +hs;
  const ap = h >= 12 ? "PM" : "AM";
  h = h % 12 || 12;
  return `${pad2(h)}:${mm} ${ap}`;
}
function splitName(n: string): [string, string] {
  const t = String(n || "").trim().replace(/\s+/g, " ");
  const i = t.lastIndexOf(" ");
  return i > 0 ? [t.slice(0, i), t.slice(i + 1)] : [t, ""];
}
function safeJson(s: string | null): any {
  try { return s ? JSON.parse(s) : null; } catch { return null; }
}
const VISIT_STATUS: Record<string, string> = {
  scheduled: "SCHEDULED", "check-in": "CHECKED_IN", rooming: "IN_PROGRESS",
  provider: "IN_PROGRESS", checkout: "IN_PROGRESS", complete: "COMPLETED",
};

app.get("/api/office/sync", async (req, res) => {
  try {
    const me = await currentUser(req);
    if (!me) return res.status(401).json({ status: "signed-out", message: "Sign in at /login first." });
    const pool = await getDb();
    const org = String(me.OrganizationId);
    const pr = await pool.request().input("org", org).query(
      `SELECT PatientCode, FirstName, LastName, CONVERT(varchar(10), DateOfBirth, 23) AS Dob, SexAtBirth, Email, MobilePhone, AppJson
       FROM dbo.Patients WHERE OrganizationId = @org AND IsActive = 1`);
    const patients = pr.recordset.map((r: any) => {
      const j = safeJson(r.AppJson);
      const base = {
        id: r.PatientCode, name: `${r.FirstName || ""} ${r.LastName || ""}`.trim(), dob: isoToUsDate(r.Dob),
        sex: r.SexAtBirth === "Female" || r.SexAtBirth === "Male" ? r.SexAtBirth : "Other",
        phone: r.MobilePhone || "", email: r.Email || undefined,
        language: "English", allergies: [], primaryProvider: "", careTeam: [], fictional: true,
      };
      return j ? { ...base, ...j, id: r.PatientCode } : base;
    });
    const vr = await pool.request().input("org", org).query(
      `SELECT a.AppointmentId, a.AppRef, a.AppJson, a.AppointmentType, a.ReasonForVisit, a.Status, a.Notes, a.CreatedAt,
              CONVERT(varchar(10), a.StartDateTime, 23) AS D, CONVERT(varchar(5), a.StartDateTime, 108) AS T,
              DATEDIFF(minute, a.StartDateTime, a.EndDateTime) AS Dur, p.PatientCode
       FROM dbo.Appointments a
       JOIN dbo.Sites s ON s.SiteId = a.SiteId
       JOIN dbo.Patients p ON p.PatientId = a.PatientId
       WHERE s.OrganizationId = @org AND p.OrganizationId = @org AND a.IsActive = 1`);
    const visits = vr.recordset.map((r: any) => {
      const j = safeJson(r.AppJson);
      const base = {
        id: r.AppRef || `db-${r.AppointmentId}`, patientId: r.PatientCode, date: r.D, time: to12h(r.T),
        durationMin: r.Dur || 30, provider: "", room: "", visitType: r.AppointmentType || "Visit",
        reason: r.ReasonForVisit || "", notes: r.Notes || undefined,
        step: r.Status === "COMPLETED" ? "complete" : "scheduled", problemIds: [], createdAt: r.CreatedAt, createdBy: "",
      };
      return j ? { ...base, ...j, id: base.id, patientId: r.PatientCode, date: r.D, time: to12h(r.T) } : base;
    });
    const dr = await pool.request().input("org", org).query(
      `SELECT d.DocumentId, d.DocumentType, d.DocumentTitle, d.FileName, d.ContentType, d.FileSizeBytes, d.Status, d.StorageBlobName,
              CONVERT(varchar(10), d.DocumentDate, 23) AS DocDate, CONVERT(varchar(19), d.CreatedAt, 126) AS CreatedAt, d.AppJson,
              p.PatientCode, u.Username, u.FirstName AS UFirst, u.LastName AS ULast
       FROM dbo.Documents d
       JOIN dbo.Patients p ON p.PatientId = d.PatientId
       LEFT JOIN dbo.Users u ON u.UserId = d.CreatedByUserId
       WHERE d.OrganizationId = @org AND p.OrganizationId = @org AND d.IsActive = 1`);
    const documents = dr.recordset.map((r: any) => {
      const j = safeJson(r.AppJson);
      const created = r.CreatedAt ? `${r.CreatedAt}Z` : new Date().toISOString();
      const base: any = { id: `dbdoc-${r.DocumentId}`, patientId: r.PatientCode, type: r.DocumentType || "Other", title: r.DocumentTitle || r.FileName || "Document",
        source: "Uploaded file", docDate: r.DocDate || created.slice(0, 10), receivedAt: created,
        receivedBy: `${r.UFirst || ""} ${r.ULast || ""}`.trim() || r.Username || "", receivedRole: "",
        fileName: r.FileName || undefined, mime: r.ContentType || undefined, size: r.FileSizeBytes == null ? undefined : Number(r.FileSizeBytes),
        removedAt: r.Status === "REMOVED" ? created : undefined, removedBy: r.Status === "REMOVED" ? "" : undefined, removedReason: r.Status === "REMOVED" ? "Removed" : undefined };
      const out: any = j ? { ...base, ...j } : base;
      out.patientId = r.PatientCode; out.serverId = String(r.DocumentId);
      out.remoteUrl = r.StorageBlobName ? `/api/files/${r.DocumentId}` : undefined;
      delete out.dataUrl;
      return out;
    });
    const provs = (await pool.request().input("org", org).query(
      `SELECT ProviderId, FirstName, LastName, Credentials, ProviderType, Specialty, NPI, Email, Phone, Color, ShowOnSchedule
       FROM dbo.Providers WHERE OrganizationId = @org AND IsActive = 1 AND (ProviderCode IS NULL OR ProviderCode NOT LIKE N'app:%')`)).recordset.map((r: any) => ({ showOnSchedule: !!r.ShowOnSchedule,
        id: `db-prov-${r.ProviderId}`, firstName: r.FirstName || "", lastName: r.LastName || "", degree: r.Credentials || "",
        role: r.ProviderType || "Physician", specialty: r.Specialty || "", npi: r.NPI || "", email: r.Email || "", phone: r.Phone || "", color: r.Color || "" }));
    const rooms = (await pool.request().input("org", org).query(
      `SELECT r.ResourceId, r.ResourceName, r.ResourceType, r.Color FROM dbo.Resources r JOIN dbo.Sites s ON s.SiteId = r.SiteId
       WHERE s.OrganizationId = @org AND r.IsActive = 1 AND r.IsSchedulable = 1`)).recordset.map((r: any) => ({
        id: `db-room-${r.ResourceId}`, name: r.ResourceName, type: r.ResourceType || "Room", color: r.Color || "" }));
    res.json({ practice: me.OrganizationCode, patients, visits, documents, providers: provs, rooms });
  } catch (e: any) {
    console.error("Office sync error:", e);
    res.status(500).json({ status: "error", message: "Could not load from the database." });
  }
});

app.put("/api/office/patients", async (req, res) => {
  try {
    const me = await currentUser(req);
    if (!me) return res.status(401).json({ status: "signed-out", message: "Signed out. Sign in again at /login." });
    const p = req.body || {};
    const code = String(p.id || "").trim();
    if (!code || code.length > 50) return res.status(400).json({ status: "error", message: "Patient id is missing or too long." });
    const [first, last] = splitName(p.name);
    if (!first) return res.status(400).json({ status: "error", message: "Patient name is required." });
    const { photo, ...rest } = p; // photos stay in the browser for now
    const json = JSON.stringify(rest);
    if (json.length > 500000) return res.status(413).json({ status: "error", message: "Patient record is too large." });
    const pool = await getDb();
    await pool.request()
      .input("org", String(me.OrganizationId)).input("code", code)
      .input("fn", first.slice(0, 100)).input("ln", last.slice(0, 100))
      .input("dob", usToIsoDate(p.dob)).input("sex", String(p.sex || "").slice(0, 30) || null)
      .input("email", p.email ? String(p.email).slice(0, 254) : null)
      .input("phone", p.phone ? String(p.phone).slice(0, 30) : null)
      .input("json", json)
      .query(`UPDATE dbo.Patients SET FirstName = @fn, LastName = @ln, DateOfBirth = @dob, SexAtBirth = @sex, Email = @email,
                     MobilePhone = @phone, AppJson = @json, UpdatedAt = SYSUTCDATETIME()
              WHERE OrganizationId = @org AND PatientCode = @code;
              IF @@ROWCOUNT = 0
                INSERT dbo.Patients (OrganizationId, PatientCode, FirstName, LastName, DateOfBirth, SexAtBirth, Email, MobilePhone, AppJson)
                VALUES (@org, @code, @fn, @ln, @dob, @sex, @email, @phone, @json);`);
    res.json({ status: "ok" });
  } catch (e: any) {
    console.error("Save patient error:", e);
    res.status(500).json({ status: "error", message: "Could not save the patient." });
  }
});

app.put("/api/office/visits", async (req, res) => {
  try {
    const me = await currentUser(req);
    if (!me) return res.status(401).json({ status: "signed-out", message: "Signed out. Sign in again at /login." });
    const v = req.body || {};
    const ref = String(v.id || "").trim();
    const date = usToIsoDate(v.date);
    const time = to24h(v.time);
    if (!ref || ref.length > 100 || !date || !time) return res.status(400).json({ status: "error", message: "Appointment id, date or time is missing." });
    const dur = Math.max(5, Math.min(600, Number(v.durationMin) || 30));
    const pool = await getDb();
    const org = String(me.OrganizationId);
    const look = (await pool.request().input("org", org).input("code", String(v.patientId || "")).query(
      `SELECT (SELECT TOP 1 PatientId FROM dbo.Patients WHERE OrganizationId = @org AND PatientCode = @code AND IsActive = 1) AS PatientId,
              (SELECT TOP 1 SiteId FROM dbo.Sites WHERE OrganizationId = @org AND IsActive = 1 ORDER BY SiteId) AS SiteId`)).recordset[0];
    if (!look?.PatientId) return res.status(409).json({ status: "error", message: "This patient is not in the database yet." });
    if (!look?.SiteId) return res.status(409).json({ status: "error", message: "This practice has no site (location) in the database." });
    await pool.request()
      .input("org", org).input("ref", ref).input("site", String(look.SiteId)).input("pid", String(look.PatientId))
      .input("type", String(v.visitType || "Visit").slice(0, 50)).input("start", `${date} ${time}`).input("dur", dur)
      .input("status", VISIT_STATUS[String(v.step)] || "SCHEDULED")
      .input("reason", v.reason ? String(v.reason).slice(0, 500) : null)
      .input("notes", v.notes ? String(v.notes).slice(0, 1000) : null)
      .input("json", JSON.stringify(v))
      .query(`DECLARE @s datetime2(0) = CAST(@start AS datetime2(0));
              UPDATE a SET PatientId = @pid, AppointmentType = @type, StartDateTime = @s, EndDateTime = DATEADD(minute, @dur, @s),
                     Status = @status, ReasonForVisit = @reason, Notes = @notes, AppJson = @json, UpdatedAt = SYSUTCDATETIME()
              FROM dbo.Appointments a JOIN dbo.Sites s ON s.SiteId = a.SiteId
              WHERE a.AppRef = @ref AND s.OrganizationId = @org;
              IF @@ROWCOUNT = 0
                INSERT dbo.Appointments (SiteId, PatientId, AppointmentType, StartDateTime, EndDateTime, Status, ReasonForVisit, Notes, AppRef, AppJson)
                VALUES (@site, @pid, @type, @s, DATEADD(minute, @dur, @s), @status, @reason, @notes, @ref, @json);`);
    res.json({ status: "ok" });
  } catch (e: any) {
    console.error("Save appointment error:", e);
    res.status(500).json({ status: "error", message: "Could not save the appointment." });
  }
});

// ---------------------------------------------------------------------------
// Staff management for practice managers (step 5): /manage
// Who: users with the ORG_ADMIN or SITE_ADMIN role, for their OWN practice only (from the session).
// What: add a staff member, reset a password (temporary password, must change at next sign-in),
//       unlock an account, reset MFA (lost phone: a new QR code at next sign-in), turn an account off/on.
// Every action is written to dbo.AuditEvents. A manager cannot use these actions on their own account.
// ---------------------------------------------------------------------------
// v11.5 (Kevin): providers added in the app. The app sends its whole provider list (except the ones that came from this
// table, e.g. the iMars import); each is upserted into dbo.Providers with ProviderCode "app:<app id>", and app-made
// providers that are no longer in the list are marked inactive. The full record stays in the record store.
const SCHEDULE_ROLES = /surgeon|physician|doctor|anesthesiolog|crna|nurse practitioner|physician assistant|\bnp\b|\bpa\b/i;
app.put("/api/office/providers", async (req, res) => {
  try {
    const me = await currentUser(req);
    if (!me) return res.status(401).json({ status: "signed-out", message: "Sign in at /login first." });
    const list = Array.isArray(req.body?.providers) ? req.body.providers.slice(0, 500) : null;
    if (!list) return res.status(400).json({ status: "error", message: "providers[] is required." });
    const s = (v: any, n: number) => { const t = String(v ?? "").trim(); return t ? t.slice(0, n) : null; };
    const pool = await getDb(); const org = String(me.OrganizationId);
    const codes: string[] = [];
    const tx = new sqlLib.Transaction(pool); await tx.begin();
    try {
      for (const p of list) {
        const id = s(p?.id, 45); if (!id || id.startsWith("db-prov-")) continue;
        const code = `app:${id}`; codes.push(code);
        const role = s(p.role, 50) || "Physician";
        await new sqlLib.Request(tx).input("org", org).input("code", code).input("fn", s(p.firstName, 100) || "").input("ln", s(p.lastName, 100) || "")
          .input("cred", s(p.degree, 50)).input("type", role).input("spec", s(p.specialty, 400)).input("npi", s(p.npi, 20))
          .input("em", s(p.email, 254)).input("ph", s(p.phone, 30)).input("color", s(p.color, 20))
          .input("sched", p.active !== false && SCHEDULE_ROLES.test(role) ? 1 : 0).input("act", p.active === false ? 0 : 1)
          .query(`DECLARE @id bigint = (SELECT TOP 1 ProviderId FROM dbo.Providers WHERE OrganizationId = @org AND ProviderCode = @code);
                  IF @id IS NOT NULL
                    UPDATE dbo.Providers SET FirstName = @fn, LastName = @ln, Credentials = @cred, ProviderType = @type, Specialty = @spec, NPI = @npi,
                           Email = @em, Phone = @ph, Color = @color, ShowOnSchedule = @sched, IsActive = @act, UpdatedAt = SYSUTCDATETIME()
                    WHERE ProviderId = @id;
                  ELSE
                    INSERT dbo.Providers (OrganizationId, ProviderCode, FirstName, LastName, Credentials, ProviderType, Specialty, NPI, Email, Phone, Color, ShowOnSchedule, IsActive)
                    VALUES (@org, @code, @fn, @ln, @cred, @type, @spec, @npi, @em, @ph, @color, @sched, @act);`);
      }
      await new sqlLib.Request(tx).input("org", org).input("keep", JSON.stringify(codes))
        .query(`UPDATE dbo.Providers SET IsActive = 0, UpdatedAt = SYSUTCDATETIME()
                WHERE OrganizationId = @org AND ProviderCode LIKE N'app:%' AND IsActive = 1
                  AND ProviderCode NOT IN (SELECT value FROM OPENJSON(@keep))`);
      await tx.commit();
    } catch (e) { try { await tx.rollback(); } catch { /* */ } throw e; }
    res.json({ status: "ok", saved: codes.length });
  } catch (e: any) { console.error("Providers save error:", e); res.status(500).json({ status: "error", message: "Could not save the providers." }); }
});

const MANAGER_ROLES = ["ORG_ADMIN", "SITE_ADMIN"];
const STAFF_ROLES = ["FRONT_DESK", "SCHEDULER", "NURSE", "PROVIDER", "BILLING", "READ_ONLY", "SITE_ADMIN", "ORG_ADMIN"];

async function rolesOf(pool: any, userId: any): Promise<string[]> {
  const r = await pool.request().input("id", userId).query(
    `SELECT r.RoleCode FROM dbo.UserRoles ur JOIN dbo.Roles r ON r.RoleId = ur.RoleId
     WHERE ur.UserId = @id AND ur.IsActive = 1 AND r.IsActive = 1`);
  return r.recordset.map((x: any) => x.RoleCode);
}
// Signed-in manager, or null (and the response is already sent).
async function requireManager(req: any, res: any): Promise<any | null> {
  const me = await currentUser(req);
  if (!me) { res.status(401).json({ status: "signed-out", message: "Sign in first." }); return null; }
  const pool = await getDb();
  const roles = await rolesOf(pool, me.UserId);
  if (!roles.some(r => MANAGER_ROLES.includes(r))) { res.status(403).json({ status: "error", message: "Only a practice manager can do this." }); return null; }
  return { ...me, roles, pool };
}
// The target user must be in the manager's practice, and not the manager.
async function staffInPractice(m: any, userId: any): Promise<any | null> {
  if (!/^\d{1,18}$/.test(String(userId || ""))) return null;
  if (String(userId) === String(m.UserId)) return null;
  const r = await m.pool.request().input("id", String(userId)).input("org", String(m.OrganizationId)).query(
    `SELECT UserId, Username, FirstName, LastName FROM dbo.Users WHERE UserId = @id AND OrganizationId = @org`);
  return r.recordset[0] || null;
}
async function audit(m: any, req: any, action: string, target: any, description: string) {
  try {
    await m.pool.request()
      .input("org", String(m.OrganizationId)).input("uid", String(m.UserId)).input("eid", target ? String(target.UserId) : null)
      .input("act", action).input("desc", description.slice(0, 1000))
      .input("ip", String(req.headers["x-forwarded-for"] || req.socket?.remoteAddress || "").slice(0, 64))
      .input("ua", String(req.headers["user-agent"] || "").slice(0, 1000))
      .query(`INSERT dbo.AuditEvents (OrganizationId, UserId, EntityType, EntityId, ActionType, Description, SourceSystem, IpAddress, UserAgent)
              VALUES (@org, @uid, N'User', @eid, @act, @desc, N'vityls-portal-test', @ip, @ua)`);
  } catch (e) { console.error("Audit write failed:", e); }
}
// Easy-to-read temporary password, e.g. "Kp7m-Wq3x-Rt9b" (no 0/O, 1/l/I).
function tempPassword(): string {
  const chars = "ABCDEFGHJKMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789";
  const pick = () => Array.from(crypto.randomBytes(4), (b: number) => chars[b % chars.length]).join("");
  return `${pick()}-${pick()}-${pick()}`;
}
async function revokeSessions(m: any, userId: any, reason: string) {
  await m.pool.request().input("id", String(userId)).input("why", reason).query(
    `UPDATE dbo.AuthSessions SET RevokedAt = SYSUTCDATETIME(), RevokeReason = @why WHERE UserId = @id AND RevokedAt IS NULL`);
  try { await forgetDevicesOf(m.pool, userId); } catch (e) { console.error("Forget devices error:", e); } // v11.5
}

app.get("/api/manage/staff", async (req, res) => {
  try {
    const m = await requireManager(req, res); if (!m) return;
    const r = await m.pool.request().input("org", String(m.OrganizationId)).query(
      `SELECT u.UserId, u.Username, u.FirstName, u.LastName, u.Email, u.Phone, u.IsActive, u.MustChangePassword, u.UserCode, u.Title, u.Color, u.ShowOnSchedule,
              CONVERT(varchar(19), u.LastLoginAt, 126) AS LastLoginAt,
              CASE WHEN u.LockedUntil > SYSUTCDATETIME() THEN 1 ELSE 0 END AS IsLocked,
              CASE WHEN u.MfaTotpEnabledAt IS NOT NULL THEN 1 ELSE 0 END AS MfaReady,
              STUFF((SELECT N', ' + r.RoleCode FROM dbo.UserRoles ur JOIN dbo.Roles r ON r.RoleId = ur.RoleId
                     WHERE ur.UserId = u.UserId AND ur.IsActive = 1 FOR XML PATH('')), 1, 2, N'') AS Roles
       FROM dbo.Users u WHERE u.OrganizationId = @org
       ORDER BY u.IsActive DESC, u.LastName, u.FirstName`);
    res.json({ practice: m.OrganizationCode, practiceName: m.OrganizationName, me: String(m.UserId), roles: STAFF_ROLES, staff: r.recordset });
  } catch (e: any) { console.error("Manage list error:", e); res.status(500).json({ status: "error", message: "Could not load staff." }); }
});

app.post("/api/manage/staff", async (req, res) => {
  try {
    const m = await requireManager(req, res); if (!m) return;
    const first = String(req.body?.firstName || "").trim().slice(0, 100);
    const last = String(req.body?.lastName || "").trim().slice(0, 100);
    const username = String(req.body?.username || "").trim().toLowerCase();
    const role = String(req.body?.role || "");
    const email = String(req.body?.email || "").trim().slice(0, 254) || null;
    if (!first || !last) return res.status(400).json({ status: "error", message: "First and last name are required." });
    if (!/^[a-z0-9._-]{3,50}$/.test(username)) return res.status(400).json({ status: "error", message: "Username: 3-50 letters, numbers, dot, dash or underscore." });
    if (!STAFF_ROLES.includes(role)) return res.status(400).json({ status: "error", message: "Pick a role." });
    if (role === "ORG_ADMIN" && !m.roles.includes("ORG_ADMIN")) return res.status(403).json({ status: "error", message: "Only an organization administrator can add another administrator." });
    const taken = (await m.pool.request().input("u", username).query(`SELECT 1 AS x FROM dbo.Users WHERE Username = @u`)).recordset.length;
    if (taken) return res.status(409).json({ status: "error", message: "That username is already used. Try another." });
    const temp = tempPassword();
    const r = await m.pool.request()
      .input("org", String(m.OrganizationId)).input("fn", first).input("ln", last).input("u", username).input("em", email)
      .input("ph", hashPassword(temp)).input("role", role)
      .query(`DECLARE @roleId bigint = (SELECT TOP 1 RoleId FROM dbo.Roles WHERE RoleCode = @role AND IsActive = 1
                                          AND (OrganizationId = @org OR OrganizationId IS NULL) ORDER BY OrganizationId DESC);
              IF @roleId IS NULL THROW 50001, 'Role not found', 1;
              DECLARE @new TABLE (UserId bigint);
              INSERT dbo.Users (OrganizationId, FirstName, LastName, Username, Email, PasswordHash, MustChangePassword, PasswordChangedAt)
              OUTPUT inserted.UserId INTO @new
              VALUES (@org, @fn, @ln, @u, @em, @ph, 1, SYSUTCDATETIME());
              INSERT dbo.UserRoles (UserId, RoleId) SELECT UserId, @roleId FROM @new;
              SELECT UserId FROM @new;`);
    const target = { UserId: r.recordset[0].UserId };
    await audit(m, req, "USER_CREATED", target, `Added ${username} (${role})`);
    res.json({ status: "ok", username, tempPassword: temp });
  } catch (e: any) { console.error("Add staff error:", e); res.status(500).json({ status: "error", message: "Could not add the staff member." }); }
});

app.post("/api/manage/staff/:id/:action", async (req, res) => {
  try {
    const m = await requireManager(req, res); if (!m) return;
    const t = await staffInPractice(m, req.params.id);
    if (!t) return res.status(404).json({ status: "error", message: "Staff member not found in your practice (or it is your own account)." });
    const id = String(t.UserId);
    if (!m.roles.includes("ORG_ADMIN") && (await rolesOf(m.pool, id)).includes("ORG_ADMIN"))
      return res.status(403).json({ status: "error", message: "Only an organization administrator can change another administrator's account." });
    switch (req.params.action) {
      case "reset-password": {
        const temp = tempPassword();
        await m.pool.request().input("id", id).input("ph", hashPassword(temp)).query(
          `UPDATE dbo.Users SET PasswordHash = @ph, MustChangePassword = 1, PasswordChangedAt = SYSUTCDATETIME(),
                  FailedLoginCount = 0, LockedUntil = NULL WHERE UserId = @id`);
        await revokeSessions(m, id, "password reset by manager");
        await audit(m, req, "PASSWORD_RESET", t, `Password reset for ${t.Username}`);
        return res.json({ status: "ok", tempPassword: temp });
      }
      case "unlock":
        await m.pool.request().input("id", id).query(`UPDATE dbo.Users SET FailedLoginCount = 0, LockedUntil = NULL WHERE UserId = @id`);
        await audit(m, req, "ACCOUNT_UNLOCKED", t, `Unlocked ${t.Username}`);
        return res.json({ status: "ok" });
      case "reset-mfa":
        await m.pool.request().input("id", id).query(
          `UPDATE dbo.Users SET MfaTotpSecret = NULL, MfaTotpEnabledAt = NULL, MfaTotpLastStep = NULL WHERE UserId = @id`);
        await revokeSessions(m, id, "MFA reset by manager");
        await audit(m, req, "MFA_RESET", t, `MFA reset for ${t.Username}`);
        return res.json({ status: "ok" });
      case "deactivate":
      case "activate": {
        const on = req.params.action === "activate" ? 1 : 0;
        await m.pool.request().input("id", id).input("on", on).query(`UPDATE dbo.Users SET IsActive = @on WHERE UserId = @id`);
        if (!on) await revokeSessions(m, id, "account turned off by manager");
        await audit(m, req, on ? "USER_ACTIVATED" : "USER_DEACTIVATED", t, `${on ? "Turned on" : "Turned off"} ${t.Username}`);
        return res.json({ status: "ok" });
      }
      case "edit": {
        // Change a person's details. Also updates their provider record (schedule column) when they have one.
        const b = req.body || {};
        const first = String(b.firstName || "").trim().slice(0, 100), last = String(b.lastName || "").trim().slice(0, 100);
        if (!first || !last) return res.status(400).json({ status: "error", message: "First and last name are required." });
        const title = String(b.title || "").trim().slice(0, 50) || null;
        const email = String(b.email || "").trim().slice(0, 254) || null;
        const phone = String(b.phone || "").trim().slice(0, 30) || null;
        const colorIn = String(b.color || "").trim().toLowerCase();
        const color = /^#[0-9a-f]{6}$/.test(colorIn) ? colorIn : null;
        const onSched = b.showOnSchedule ? 1 : 0;
        const role = String(b.role || "");
        if (!STAFF_ROLES.includes(role)) return res.status(400).json({ status: "error", message: "Pick a role." });
        if (role === "ORG_ADMIN" && !m.roles.includes("ORG_ADMIN")) return res.status(403).json({ status: "error", message: "Only an organization administrator can make someone an administrator." });
        const cur = (await m.pool.request().input("id", id).query(`SELECT Username, UserCode FROM dbo.Users WHERE UserId = @id`)).recordset[0];
        let newUsername: string | null = null;
        const wantUser = String(b.username || "").trim().toLowerCase();
        if (wantUser && !cur.Username) {
          if (!/^[a-z0-9._@-]{3,100}$/.test(wantUser)) return res.status(400).json({ status: "error", message: "Username: 3-100 letters, numbers, dot, dash, @ or underscore." });
          const taken = (await m.pool.request().input("u", wantUser).query(`SELECT 1 AS x FROM dbo.Users WHERE Username = @u`)).recordset.length;
          if (taken) return res.status(409).json({ status: "error", message: "That username is already used. Try another." });
          newUsername = wantUser;
        }
        await m.pool.request().input("id", id).input("org", String(m.OrganizationId)).input("fn", first).input("ln", last).input("title", title)
          .input("em", email).input("ph", phone).input("color", color).input("sched", onSched).input("u", newUsername).input("role", role)
          .input("code", cur.UserCode || null)
          .query(`UPDATE dbo.Users SET FirstName = @fn, LastName = @ln, Title = @title, Email = @em, Phone = @ph, Color = @color, ShowOnSchedule = @sched,
                         Username = ISNULL(Username, @u), MustChangePassword = CASE WHEN @u IS NOT NULL THEN 1 ELSE MustChangePassword END,
                         UpdatedAt = SYSUTCDATETIME()
                  WHERE UserId = @id;
                  DECLARE @roleId bigint = (SELECT TOP 1 RoleId FROM dbo.Roles WHERE RoleCode = @role AND IsActive = 1
                                              AND (OrganizationId = @org OR OrganizationId IS NULL) ORDER BY OrganizationId DESC);
                  IF @roleId IS NOT NULL BEGIN
                    UPDATE dbo.UserRoles SET IsActive = CASE WHEN RoleId = @roleId THEN 1 ELSE 0 END, UpdatedAt = SYSUTCDATETIME()
                    WHERE UserId = @id AND SiteId IS NULL;
                    IF NOT EXISTS (SELECT 1 FROM dbo.UserRoles WHERE UserId = @id AND RoleId = @roleId AND SiteId IS NULL)
                      INSERT dbo.UserRoles (UserId, RoleId) VALUES (@id, @roleId);
                  END
                  IF @code IS NOT NULL
                    UPDATE dbo.Providers SET FirstName = @fn, LastName = @ln, Title = @title, Email = @em, Phone = @ph, Color = @color,
                           ShowOnSchedule = @sched, UpdatedAt = SYSUTCDATETIME()
                    WHERE OrganizationId = @org AND ProviderCode = @code;`);
        await audit(m, req, "USER_UPDATED", t, `Edited ${first} ${last}${newUsername ? ` (login "${newUsername}" created)` : ""}`);
        return res.json({ status: "ok", loginCreated: !!newUsername });
      }
      default:
        return res.status(400).json({ status: "error", message: "Unknown action." });
    }
  } catch (e: any) { console.error("Manage action error:", e); res.status(500).json({ status: "error", message: "That didn't work. Check the app log." }); }
});

app.get("/manage", (_req, res) => {
  res.setHeader("Cache-Control", "no-store");
  res.type("html").send(`<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Staff · Vityls</title>
<style>
 :root{--ink:#1d2b25;--muted:#5b6b64;--line:#d5ddd9;--brand:#1f4e3d;--soft:#e8f1ed;--err:#a1261b;--warn:#8a5a00;--warnbg:#fdf3df}
 *{box-sizing:border-box} body{font-family:"Segoe UI",system-ui,sans-serif;background:#f4f6f5;color:var(--ink);margin:0;padding:32px 16px}
 main{max-width:980px;margin:0 auto}
 header{display:flex;flex-wrap:wrap;gap:12px;align-items:baseline;justify-content:space-between;margin-bottom:18px}
 h1{font-size:22px;margin:0} .sub{color:var(--muted);font-size:14px} header a{color:var(--brand);font-size:14px;margin-left:14px}
 .card{background:#fff;border:1px solid var(--line);border-radius:12px;padding:18px 20px;margin-bottom:18px}
 h2{font-size:16px;margin:0 0 12px}
 table{width:100%;border-collapse:collapse;font-size:14px} th{text-align:left;font-size:12px;color:var(--muted);font-weight:600;padding:6px 8px;border-bottom:1px solid var(--line)}
 td{padding:10px 8px;border-bottom:1px solid #eef2f0;vertical-align:top} tr.off td{color:#93a19b}
 .tag{display:inline-block;font-size:11px;font-weight:600;padding:2px 8px;border-radius:999px;margin:0 4px 4px 0;background:var(--soft);color:var(--brand)}
 .tag.warn{background:var(--warnbg);color:var(--warn)} .tag.err{background:#fde8e6;color:var(--err)} .tag.grey{background:#eef0ef;color:#5b6b64}
 .acts{display:flex;flex-wrap:wrap;gap:6px} button{font:inherit;font-size:13px;padding:6px 10px;border-radius:6px;border:1px solid #b9c6c0;background:#fff;color:var(--ink);cursor:pointer}
 button:hover{border-color:var(--brand)} button.primary{background:var(--brand);border-color:var(--brand);color:#fff;font-weight:600;padding:9px 16px}
 form.add{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:10px;align-items:end}
 label{display:block;font-size:12px;font-weight:600;margin-bottom:4px} input,select{width:100%;padding:8px 9px;border:1px solid #b9c6c0;border-radius:6px;font-size:14px;background:#fff;color:var(--ink)}
 .msg{margin-top:12px;font-size:14px} .msg.err{color:var(--err)}
 .temp{background:var(--warnbg);border:1px solid #f0d9a8;border-radius:10px;padding:14px 16px;margin-bottom:18px;font-size:14px;line-height:1.5}
 .temp code{font-family:Consolas,monospace;font-size:20px;background:#fff;border-radius:6px;padding:3px 9px;letter-spacing:1px;user-select:all}
 .small{font-size:12px;color:var(--muted)} [hidden]{display:none!important}
 @media (max-width:700px){thead{display:none} td{display:block;border:0;padding:4px 0} tr{display:block;border-bottom:1px solid var(--line);padding:10px 0}}
</style></head><body><main>
<header><div><h1>Staff</h1><div class="sub" id="prac"></div></div>
 <div><a href="/import">Import from iMars</a><a href="/?practice=coastline">Back to the practice</a><a href="/login">My sign-in</a></div></header>
<div class="temp" id="temp" hidden></div>
<div class="msg err" id="err"></div>
<section class="card"><div style="display:flex;flex-wrap:wrap;gap:10px;align-items:center;justify-content:space-between;margin-bottom:10px">
  <h2 style="margin:0">People in this practice <span class="small" id="cnt"></span></h2>
  <input id="q" placeholder="Search name, username or title" style="max-width:280px" aria-label="Search people"></div>
 <table><thead><tr><th>Name</th><th>Title</th><th>Username</th><th>Role</th><th>Color</th><th>Status</th><th>Actions</th></tr></thead><tbody id="rows"></tbody></table>
 <nav id="pager" aria-label="Pages" style="display:flex;flex-wrap:wrap;gap:4px;margin-top:12px"></nav>
</section>
<div id="ed" hidden style="position:fixed;inset:0;background:rgba(20,30,26,.45);z-index:50;display:flex;align-items:flex-start;justify-content:center;padding:40px 16px;overflow:auto">
 <form id="f-ed" class="card" style="max-width:560px;width:100%;margin:0">
  <h2 id="ed-h">Edit</h2>
  <div class="add" style="grid-template-columns:1fr 1fr">
   <div><label for="e-fn">First name</label><input id="e-fn" required maxlength="100"></div>
   <div><label for="e-ln">Last name</label><input id="e-ln" required maxlength="100"></div>
   <div><label for="e-ti">Title</label><input id="e-ti" maxlength="50" placeholder="e.g. Doctor"></div>
   <div><label for="e-ro">Role</label><select id="e-ro"></select></div>
   <div><label for="e-em">Email</label><input id="e-em" type="email" maxlength="254"></div>
   <div><label for="e-ph">Phone</label><input id="e-ph" maxlength="30"></div>
   <div><label for="e-co">Color</label><div style="display:flex;gap:8px;align-items:center"><input id="e-co" type="color" style="width:56px;height:36px;padding:2px">
     <label style="display:flex;gap:6px;align-items:center;margin:0;font-weight:400"><input id="e-nc" type="checkbox" style="width:auto"> no color</label></div></div>
   <div><label for="e-sc">Appointment book</label><label style="display:flex;gap:6px;align-items:center;font-weight:400;margin:8px 0 0"><input id="e-sc" type="checkbox" style="width:auto"> Show on the schedule</label></div>
   <div style="grid-column:1/-1" id="e-userbox"><label for="e-un">Username (creates a login; then use Reset password to give them a temporary password)</label><input id="e-un" maxlength="100" autocapitalize="none"></div>
  </div>
  <div style="display:flex;gap:8px;margin-top:6px"><button class="primary" type="submit">Save</button><button type="button" id="ed-x">Cancel</button></div>
  <div class="msg err" id="ed-err"></div>
 </form>
</div>
<section class="card"><h2>Add a staff member</h2>
 <form class="add" id="f-add">
  <div><label for="fn">First name</label><input id="fn" required maxlength="100"></div>
  <div><label for="ln">Last name</label><input id="ln" required maxlength="100"></div>
  <div><label for="un">Username</label><input id="un" required maxlength="50" autocapitalize="none" placeholder="e.g. jsmith"></div>
  <div><label for="ro">Role</label><select id="ro" required></select></div>
  <div><button class="primary" type="submit">Add</button></div>
 </form>
 <p class="small">They get a temporary password (shown once, here). At first sign-in they choose their own password and set up Google Authenticator.</p>
</section>
<script>
const $=id=>document.getElementById(id);
const NAMES={FRONT_DESK:"Front desk",SCHEDULER:"Scheduler",NURSE:"Nurse",PROVIDER:"Provider",BILLING:"Billing",READ_ONLY:"Read only",SITE_ADMIN:"Site manager",ORG_ADMIN:"Practice administrator"};
function el(tag,attrs,...kids){const e=document.createElement(tag);for(const k in attrs||{}){if(k==="class")e.className=attrs[k];else if(k.startsWith("on"))e.addEventListener(k.slice(2),attrs[k]);else e.setAttribute(k,attrs[k]);}
  for(const c of kids)if(c!=null)e.append(c);return e;}
async function api(url,body){const r=await fetch(url,{method:body===undefined?"GET":"POST",credentials:"same-origin",headers:{"Content-Type":"application/json"},body:body===undefined?undefined:JSON.stringify(body)});
  const d=await r.json().catch(()=>({}));if(r.status===401){location.replace("/login?next=/manage");throw new Error("Signed out");}if(!r.ok)throw new Error(d.message||"Something went wrong.");return d;}
function showTemp(who,pw){const t=$("temp");t.innerHTML="";t.append("Temporary password for ",el("b",{},who),": ",el("code",{},pw),
  el("div",{class:"small"},"Give this to them in person or by phone. It is shown only now. They must pick a new password when they sign in."));t.hidden=false;t.scrollIntoView({behavior:"smooth"});}
async function act(u,action,label){
  const ask={"reset-password":"Reset the password for "+u.Username+"? They will be signed out and get a temporary password.",
    "reset-mfa":"Reset Google Authenticator for "+u.Username+"? They will scan a new QR code at their next sign-in.",
    "deactivate":"Turn off "+u.Username+"? They will be signed out and cannot sign in until turned back on."}[action];
  if(ask&&!window.confirm(ask))return;
  $("err").textContent="";
  try{const d=await api("/api/manage/staff/"+u.UserId+"/"+action,{});if(d.tempPassword)showTemp(u.Username,d.tempPassword);await load();}
  catch(e){$("err").textContent=e.message;}}
async function load(){
  const d=await api("/api/manage/staff");
  $("prac").textContent="Practice "+d.practice+" · "+(d.practiceName||"");
  roleList=d.roles;if(!$("ro").options.length)for(const r of d.roles)$("ro").append(el("option",{value:r},NAMES[r]||r));
  $("ro").value=$("ro").value||"FRONT_DESK";
  all=d.staff;meId=d.me;render();
}
const PAGE=10;let all=[],meId="",page=1;
function render(){
  const q=$("q").value.trim().toLowerCase();
  const list=q?all.filter(u=>[(u.FirstName||"")+" "+(u.LastName||""),u.Username||"",u.Title||"",u.UserCode||""].join(" ").toLowerCase().includes(q)):all;
  const pages=Math.max(1,Math.ceil(list.length/PAGE));if(page>pages)page=pages;
  $("cnt").textContent="· "+list.length+(q?" found":" people");
  const rows=$("rows");rows.innerHTML="";
  for(const u of list.slice((page-1)*PAGE,page*PAGE)){
    const me=String(u.UserId)===meId;
    const st=el("td",{});
    if(!u.IsActive)st.append(el("span",{class:"tag grey"},"Turned off"));
    if(!u.Username)st.append(el("span",{class:"tag grey"},"No login"));
    if(u.ShowOnSchedule)st.append(el("span",{class:"tag"},"On the schedule"));
    if(u.IsLocked)st.append(el("span",{class:"tag err"},"Locked"));
    if(u.MustChangePassword)st.append(el("span",{class:"tag warn"},"Temporary password"));
    if(u.Username)st.append(el("span",{class:u.MfaReady?"tag":"tag warn"},u.MfaReady?"Authenticator set":"Authenticator not set"));
    st.append(el("div",{class:"small"},u.LastLoginAt?"Last sign-in "+new Date(u.LastLoginAt+"Z").toLocaleString():"Never signed in"));
    const acts=el("div",{class:"acts"});
    if(me)acts.append(el("span",{class:"small"},"This is you"));
    else{
      acts.append(el("button",{onclick:()=>openEdit(u)},"Edit"));
      if(u.Username)acts.append(el("button",{onclick:()=>act(u,"reset-password")},"Reset password"));
      if(u.IsLocked)acts.append(el("button",{onclick:()=>act(u,"unlock")},"Unlock"));
    if(u.MfaReady)acts.append(el("button",{onclick:()=>act(u,"reset-mfa")},"Reset authenticator"));
      acts.append(el("button",{onclick:()=>act(u,u.IsActive?"deactivate":"activate")},u.IsActive?"Turn off":"Turn on"));
    }
    const roles=String(u.Roles||"").split(", ").filter(Boolean).map(r=>NAMES[r]||r).join(", ")||"-";
    const sw=el("td",{});if(u.Color){const b=el("span",{title:u.Color});b.setAttribute("style","display:inline-block;width:34px;height:16px;border-radius:4px;border:1px solid #c9d3cf;background:"+u.Color);sw.append(b);}
    const nm=el("td",{},(u.FirstName||"")+" "+(u.LastName||""));if(u.UserCode&&/^imars-/.test(u.UserCode))nm.append(el("div",{class:"small"},"iMars "+u.UserCode.slice(6)));
    rows.append(el("tr",{class:u.IsActive?"":"off"},nm,el("td",{},u.Title||""),el("td",{},u.Username||"-"),el("td",{},roles),sw,st,el("td",{},acts)));
  }
  const nav=$("pager");nav.replaceChildren();
  if(pages>1){
    const btn=(label,p,cur)=>{const b=el("button",{type:"button","aria-label":"Page "+p},label);if(cur){b.setAttribute("aria-current","page");b.setAttribute("style","background:var(--brand);color:#fff;border-color:var(--brand)");}
      b.addEventListener("click",()=>{page=p;render();});return b;};
    if(page>1)nav.append(btn("‹ Prev",page-1,false));
    for(let i=1;i<=pages;i++)nav.append(btn(String(i),i,i===page));
    if(page<pages)nav.append(btn("Next ›",page+1,false));
  }
}
$("q").addEventListener("input",()=>{page=1;render();});
let editing=null,roleList=[];
function openEdit(u){editing=u;$("ed-h").textContent="Edit "+(u.FirstName||"")+" "+(u.LastName||"");$("ed-err").textContent="";
  $("e-fn").value=u.FirstName||"";$("e-ln").value=u.LastName||"";$("e-ti").value=u.Title||"";$("e-em").value=u.Email||"";$("e-ph").value=u.Phone||"";
  $("e-co").value=/^#[0-9a-fA-F]{6}$/.test(u.Color||"")?u.Color:"#ffffff";$("e-nc").checked=!u.Color;$("e-sc").checked=!!u.ShowOnSchedule;
  const sel=$("e-ro");sel.replaceChildren(...roleList.map(r=>el("option",{value:r},NAMES[r]||r)));sel.value=String(u.Roles||"").split(", ")[0]||"FRONT_DESK";
  $("e-userbox").hidden=!!u.Username;$("e-un").value="";$("ed").hidden=false;$("e-fn").focus();}
$("ed-x").addEventListener("click",()=>{$("ed").hidden=true;});
$("e-co").addEventListener("input",()=>{$("e-nc").checked=false;});
$("f-ed").addEventListener("submit",async ev=>{ev.preventDefault();if(!editing)return;$("ed-err").textContent="";
  try{const d=await api("/api/manage/staff/"+editing.UserId+"/edit",{firstName:$("e-fn").value,lastName:$("e-ln").value,title:$("e-ti").value,role:$("e-ro").value,
      email:$("e-em").value,phone:$("e-ph").value,color:$("e-nc").checked?"":$("e-co").value,showOnSchedule:$("e-sc").checked,username:$("e-un").value});
    $("ed").hidden=true;await load();}catch(e){$("ed-err").textContent=e.message;}});
$("f-add").addEventListener("submit",async ev=>{ev.preventDefault();$("err").textContent="";
  try{const d=await api("/api/manage/staff",{firstName:$("fn").value,lastName:$("ln").value,username:$("un").value,role:$("ro").value});
    showTemp(d.username,d.tempPassword);ev.target.reset();$("ro").value="FRONT_DESK";await load();}catch(e){$("err").textContent=e.message;}});
load().catch(e=>{$("err").textContent=e.message;});
</script></main></body></html>`);
});

// ---------------------------------------------------------------------------
// Patient files (step 6): upload / list / open, stored in Azure Blob Storage.
// The file goes to the private container (no public access); a row in dbo.Documents records the
// practice, patient, name, type, size and SHA-256. Files are only served through the app, after
// sign-in, and only to the same practice. Every upload and every view is written to dbo.AuditEvents.
// App settings: STORAGE_ACCOUNT, STORAGE_CONTAINER, and for now STORAGE_KEY (test only).
// Without STORAGE_KEY the app uses its own Azure identity instead (needs "Storage Blob Data Contributor").
// ---------------------------------------------------------------------------
const MAX_FILE_MB = 25;
const DOC_TYPES = ["Consent", "Lab result", "Imaging", "Referral", "Photo", "ID / insurance", "Letter", "Other"];
// Only these kinds of files are accepted. Inline = opens in the browser; the rest download.
const FILE_KINDS: Record<string, { type: string; inline: boolean }> = {
  ".pdf": { type: "application/pdf", inline: true },
  ".jpg": { type: "image/jpeg", inline: true }, ".jpeg": { type: "image/jpeg", inline: true },
  ".png": { type: "image/png", inline: true }, ".gif": { type: "image/gif", inline: true },
  ".webp": { type: "image/webp", inline: true }, ".heic": { type: "image/heic", inline: false },
  ".tif": { type: "image/tiff", inline: false }, ".tiff": { type: "image/tiff", inline: false },
  ".txt": { type: "text/plain; charset=utf-8", inline: true },
  ".doc": { type: "application/msword", inline: false },
  ".docx": { type: "application/vnd.openxmlformats-officedocument.wordprocessingml.document", inline: false },
  ".xls": { type: "application/vnd.ms-excel", inline: false },
  ".xlsx": { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", inline: false },
  ".csv": { type: "text/csv; charset=utf-8", inline: false },
};

let containerClient: Promise<any> | null = null;
function getContainer(): Promise<any> {
  if (!containerClient) {
    containerClient = (async () => {
      const account = process.env.STORAGE_ACCOUNT, container = process.env.STORAGE_CONTAINER;
      if (!account || !container) throw new Error("File storage is not configured (STORAGE_ACCOUNT, STORAGE_CONTAINER).");
      const blob: any = await import("@azure/storage-blob");
      const url = `https://${account}.blob.core.windows.net`;
      let service;
      if (process.env.STORAGE_KEY) {
        service = new blob.BlobServiceClient(url, new blob.StorageSharedKeyCredential(account, process.env.STORAGE_KEY));
      } else {
        const id: any = await import("@azure/identity");
        service = new blob.BlobServiceClient(url, new id.DefaultAzureCredential());
      }
      return service.getContainerClient(container);
    })().catch((e) => { containerClient = null; throw e; });
  }
  return containerClient;
}
async function auditFile(me: any, req: any, action: string, docId: any, description: string) {
  try {
    const pool = await getDb();
    await pool.request()
      .input("org", String(me.OrganizationId)).input("uid", String(me.UserId)).input("eid", docId == null ? null : String(docId))
      .input("act", action).input("desc", description.slice(0, 1000))
      .input("ip", String(req.headers["x-forwarded-for"] || req.socket?.remoteAddress || "").slice(0, 64))
      .input("ua", String(req.headers["user-agent"] || "").slice(0, 1000))
      .query(`INSERT dbo.AuditEvents (OrganizationId, UserId, EntityType, EntityId, ActionType, Description, SourceSystem, IpAddress, UserAgent)
              VALUES (@org, @uid, N'Document', @eid, @act, @desc, N'vityls-portal-test', @ip, @ua)`);
  } catch (e) { console.error("Audit write failed:", e); }
}
const fileErr = (res: any, status: number, message: string) => res.status(status).json({ status: "error", message });

// Office app Documents tab: a record without a file (e.g. "faxed page, scan later").
app.post("/api/office/documents", async (req, res) => {
  try {
    const me = await currentUser(req); if (!me) return fileErr(res, 401, "Signed out. Sign in again at /login.");
    const pool = await getDb();
    const p = (await pool.request().input("org", String(me.OrganizationId)).input("code", String(req.body?.patientId || "")).query(
      `SELECT TOP 1 PatientId, PatientCode FROM dbo.Patients WHERE OrganizationId = @org AND PatientCode = @code AND IsActive = 1`)).recordset[0];
    if (!p) return fileErr(res, 409, "This patient is not in the database yet.");
    const type = String(req.body?.type || "Other").slice(0, 100), title = String(req.body?.title || type).slice(0, 255);
    const r = await pool.request().input("org", String(me.OrganizationId)).input("pid", String(p.PatientId)).input("type", type).input("title", title).input("uid", String(me.UserId))
      .query(`DECLARE @new TABLE (DocumentId bigint);
              INSERT dbo.Documents (OrganizationId, PatientId, DocumentType, DocumentTitle, FileName, StoragePath, DocumentDate, CreatedByUserId, SourceSystem)
              OUTPUT inserted.DocumentId INTO @new
              VALUES (@org, @pid, @type, @title, N'', N'', CAST(SYSUTCDATETIME() AS date), @uid, N'vityls-portal-test');
              SELECT DocumentId FROM @new;`);
    const id = r.recordset[0].DocumentId;
    await auditFile(me, req, "DOCUMENT_ADDED", id, `${type}: ${title} (no file) for patient ${p.PatientCode}`);
    res.json({ status: "ok", id: String(id) });
  } catch (e: any) { console.error("Add document error:", e); fileErr(res, 500, "Could not add the document."); }
});

// Office app Documents tab: save the chart's own details for a document (title, type, date, summary, removed/restored).
app.put("/api/office/documents/:id", async (req, res) => {
  try {
    const me = await currentUser(req); if (!me) return fileErr(res, 401, "Signed out. Sign in again at /login.");
    if (!/^\d{1,18}$/.test(req.params.id)) return fileErr(res, 404, "Document not found.");
    const doc = { ...(req.body?.doc || {}) }; delete doc.dataUrl; delete doc.remoteUrl; delete doc.serverId;
    const json = JSON.stringify(doc);
    if (json.length > 900000) return fileErr(res, 413, "Document details are too large.");
    const pool = await getDb();
    const cur = (await pool.request().input("org", String(me.OrganizationId)).input("id", req.params.id).query(
      `SELECT TOP 1 DocumentId, Status, DocumentTitle FROM dbo.Documents WHERE DocumentId = @id AND OrganizationId = @org AND IsActive = 1`)).recordset[0];
    if (!cur) return fileErr(res, 404, "Document not found in your practice.");
    const status = doc.removedAt ? "REMOVED" : "ACTIVE";
    const m = String(doc.docDate || "").match(/^(\d{4})-(\d{2})-(\d{2})/);
    await pool.request().input("id", req.params.id).input("json", json)
      .input("type", String(doc.type || "Other").slice(0, 100)).input("title", String(doc.title || cur.DocumentTitle || "Document").slice(0, 255))
      .input("dd", m ? `${m[1]}-${m[2]}-${m[3]}` : null).input("st", status)
      .query(`UPDATE dbo.Documents SET AppJson = @json, DocumentType = @type, DocumentTitle = @title,
                     DocumentDate = ISNULL(TRY_CAST(@dd AS date), DocumentDate), Status = @st, UpdatedAt = SYSUTCDATETIME()
              WHERE DocumentId = @id`);
    if (cur.Status !== status) await auditFile(me, req, status === "REMOVED" ? "DOCUMENT_REMOVED" : "DOCUMENT_RESTORED", cur.DocumentId,
      `${status === "REMOVED" ? "Removed from the chart" : "Restored to the chart"}: ${doc.title || cur.DocumentTitle}${doc.removedReason ? ` (${doc.removedReason})` : ""}`);
    res.json({ status: "ok" });
  } catch (e: any) { console.error("Save document error:", e); fileErr(res, 500, "Could not save the document details."); }
});

// Patient picker: the practice's patients matching a name or code (max 25).
app.get("/api/files/patients", async (req, res) => {
  try {
    const me = await currentUser(req); if (!me) return fileErr(res, 401, "Sign in first.");
    const q = String(req.query.q || "").trim().slice(0, 60);
    const pool = await getDb();
    const r = await pool.request().input("org", String(me.OrganizationId)).input("q", `%${q.replace(/[%_[]/g, "[$&]")}%`).query(
      `SELECT TOP 25 p.PatientCode, p.FirstName, p.LastName, CONVERT(varchar(10), p.DateOfBirth, 23) AS Dob,
              (SELECT COUNT(*) FROM dbo.Documents d WHERE d.PatientId = p.PatientId AND d.IsActive = 1
                 AND d.Status <> N'REMOVED' AND d.StorageBlobName IS NOT NULL) AS Files
       FROM dbo.Patients p
       WHERE p.OrganizationId = @org AND p.IsActive = 1
         AND (p.FirstName + N' ' + p.LastName LIKE @q OR p.LastName LIKE @q OR p.PatientCode LIKE @q)
       ORDER BY p.LastName, p.FirstName`);
    res.json({ practice: me.OrganizationCode, patients: r.recordset, types: DOC_TYPES, maxMb: MAX_FILE_MB });
  } catch (e: any) { console.error("File patients error:", e); fileErr(res, 500, "Could not load patients."); }
});

// One patient's files.
app.get("/api/files", async (req, res) => {
  try {
    const me = await currentUser(req); if (!me) return fileErr(res, 401, "Sign in first.");
    const pool = await getDb();
    const r = await pool.request().input("org", String(me.OrganizationId)).input("code", String(req.query.patient || "")).query(
      `SELECT d.DocumentId, d.DocumentType, d.DocumentTitle, d.FileName, d.ContentType, d.FileSizeBytes,
              CONVERT(varchar(19), d.CreatedAt, 126) AS CreatedAt, u.Username AS AddedBy
       FROM dbo.Documents d
       JOIN dbo.Patients p ON p.PatientId = d.PatientId
       LEFT JOIN dbo.Users u ON u.UserId = d.CreatedByUserId
       WHERE p.OrganizationId = @org AND d.OrganizationId = @org AND p.PatientCode = @code AND d.IsActive = 1
         AND d.Status <> N'REMOVED' AND d.StorageBlobName IS NOT NULL
       ORDER BY d.CreatedAt DESC`);
    res.json({ files: r.recordset });
  } catch (e: any) { console.error("File list error:", e); fileErr(res, 500, "Could not load the files."); }
});

// Upload: the file is the request body; name, title and type come in headers/query.
app.post("/api/files", express.raw({ type: () => true, limit: `${MAX_FILE_MB}mb` }), async (req: any, res) => {
  try {
    const me = await currentUser(req); if (!me) return fileErr(res, 401, "Sign in first.");
    const body: Buffer = Buffer.isBuffer(req.body) ? req.body : Buffer.alloc(0);
    if (!body.length) return fileErr(res, 400, "The file is empty.");
    const fileName = decodeURIComponent(String(req.headers["x-file-name"] || "")).replace(/[\\/:*?"<>|\u0000-\u001f]/g, "_").trim().slice(0, 200);
    const ext = (fileName.match(/\.[A-Za-z0-9]{1,5}$/)?.[0] || "").toLowerCase();
    const kind = FILE_KINDS[ext];
    if (!fileName || !kind) return fileErr(res, 415, "This kind of file is not accepted. Use PDF, a picture (JPG, PNG), Word, Excel, CSV or text.");
    const docType = String(req.query.type || "").replace(/[\u0000-\u001f]/g, "").trim().slice(0, 100) || "Other";
    const title = (String(req.query.title || "").trim() || fileName).slice(0, 255);
    const pool = await getDb();
    const p = (await pool.request().input("org", String(me.OrganizationId)).input("code", String(req.query.patient || "")).query(
      `SELECT TOP 1 PatientId, PatientCode FROM dbo.Patients WHERE OrganizationId = @org AND PatientCode = @code AND IsActive = 1`)).recordset[0];
    if (!p) return fileErr(res, 404, "Patient not found in your practice.");
    const hash = crypto.createHash("sha256").update(body).digest("hex");
    const blobName = `org-${me.OrganizationId}/patient-${p.PatientId}/${crypto.randomUUID()}${ext}`;
    const container = await getContainer();
    await container.getBlockBlobClient(blobName).uploadData(body, {
      blobHTTPHeaders: { blobContentType: kind.type },
      metadata: { org: String(me.OrganizationId), patient: String(p.PatientId), sha256: hash },
    });
    const r = await pool.request()
      .input("org", String(me.OrganizationId)).input("pid", String(p.PatientId)).input("type", docType).input("title", title)
      .input("fn", fileName).input("ct", kind.type).input("size", sqlLib.BigInt, body.length)
      .input("path", `${process.env.STORAGE_CONTAINER}/${blobName}`).input("cont", String(process.env.STORAGE_CONTAINER))
      .input("blob", blobName).input("hash", hash).input("uid", String(me.UserId))
      .query(`DECLARE @new TABLE (DocumentId bigint);
              INSERT dbo.Documents (OrganizationId, PatientId, DocumentType, DocumentTitle, FileName, ContentType, FileSizeBytes,
                                    StoragePath, StorageContainer, StorageBlobName, FileHashSHA256, DocumentDate, CreatedByUserId, SourceSystem)
              OUTPUT inserted.DocumentId INTO @new
              VALUES (@org, @pid, @type, @title, @fn, @ct, @size, @path, @cont, @blob, @hash, CAST(SYSUTCDATETIME() AS date), @uid, N'vityls-portal-test');
              SELECT DocumentId FROM @new;`);
    const docId = r.recordset[0].DocumentId;
    await auditFile(me, req, "DOCUMENT_UPLOADED", docId, `${docType}: ${fileName} (${body.length} bytes) for patient ${p.PatientCode}`);
    res.json({ status: "ok", id: String(docId) });
  } catch (e: any) {
    console.error("File upload error:", e);
    if (e?.type === "entity.too.large") return fileErr(res, 413, `The file is larger than ${MAX_FILE_MB} MB.`);
    fileErr(res, 500, e?.statusCode === 403 ? "The app is not allowed to write to file storage yet." : "Could not upload the file. Check the app log.");
  }
});

// Open / download one file (same practice only).
app.get("/api/files/:id", async (req, res) => {
  try {
    const me = await currentUser(req); if (!me) return res.redirect(302, `/login?next=${encodeURIComponent(req.originalUrl)}`);
    if (!/^\d{1,18}$/.test(req.params.id)) return res.status(404).send("Not found");
    const pool = await getDb();
    const d = (await pool.request().input("org", String(me.OrganizationId)).input("id", req.params.id).query(
      `SELECT TOP 1 d.DocumentId, d.FileName, d.ContentType, d.StorageBlobName, p.PatientCode
       FROM dbo.Documents d JOIN dbo.Patients p ON p.PatientId = d.PatientId
       WHERE d.DocumentId = @id AND d.OrganizationId = @org AND p.OrganizationId = @org AND d.IsActive = 1`)).recordset[0];
    if (!d || !d.StorageBlobName) return res.status(404).send("Not found");
    const ext = (String(d.FileName).match(/\.[A-Za-z0-9]{1,5}$/)?.[0] || "").toLowerCase();
    const kind = FILE_KINDS[ext] || { type: "application/octet-stream", inline: false };
    const container = await getContainer();
    const dl = await container.getBlobClient(d.StorageBlobName).download();
    await auditFile(me, req, "DOCUMENT_VIEWED", d.DocumentId, `Opened ${d.FileName} for patient ${d.PatientCode}`);
    const safeName = String(d.FileName).replace(/[^\w.\- ()]/g, "_");
    res.setHeader("Content-Type", kind.type);
    const asAttachment = !kind.inline || req.query.download === "1";
    res.setHeader("Content-Disposition", `${asAttachment ? "attachment" : "inline"}; filename="${safeName}"; filename*=UTF-8''${encodeURIComponent(d.FileName)}`);
    res.setHeader("X-Content-Type-Options", "nosniff");
    res.setHeader("Cache-Control", "private, no-store");
    if (dl.contentLength != null) res.setHeader("Content-Length", String(dl.contentLength));
    dl.readableStreamBody.on("error", (e: any) => { console.error("File stream error:", e); res.destroy(e); }).pipe(res);
  } catch (e: any) { console.error("File open error:", e); if (!res.headersSent) res.status(500).send("Could not open the file."); }
});

app.get("/files", (_req, res) => {
  res.setHeader("Cache-Control", "no-store");
  res.type("html").send(`<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Patient files · Vityls</title>
<style>
 :root{--ink:#1d2b25;--muted:#5b6b64;--line:#d5ddd9;--brand:#1f4e3d;--soft:#e8f1ed;--err:#a1261b}
 *{box-sizing:border-box} body{font-family:"Segoe UI",system-ui,sans-serif;background:#f4f6f5;color:var(--ink);margin:0;padding:32px 16px}
 main{max-width:980px;margin:0 auto}
 header{display:flex;flex-wrap:wrap;gap:12px;align-items:baseline;justify-content:space-between;margin-bottom:18px}
 h1{font-size:22px;margin:0} .sub{color:var(--muted);font-size:14px} header a{color:var(--brand);font-size:14px;margin-left:14px}
 .grid{display:grid;grid-template-columns:320px 1fr;gap:18px} @media (max-width:780px){.grid{grid-template-columns:1fr}}
 .card{background:#fff;border:1px solid var(--line);border-radius:12px;padding:18px 20px}
 h2{font-size:16px;margin:0 0 12px}
 input,select{width:100%;padding:9px 10px;border:1px solid #b9c6c0;border-radius:7px;font-size:14px;background:#fff;color:var(--ink)}
 label{display:block;font-size:12px;font-weight:600;margin:12px 0 4px}
 ul.pts{list-style:none;margin:10px 0 0;padding:0;max-height:520px;overflow:auto}
 ul.pts li button{width:100%;text-align:left;background:none;border:0;border-radius:8px;padding:9px 10px;font:inherit;font-size:14px;color:var(--ink);cursor:pointer}
 ul.pts li button:hover{background:#f1f5f3} ul.pts li button.on{background:var(--soft);font-weight:600}
 .meta{display:block;font-size:12px;color:var(--muted);font-weight:400}
 table{width:100%;border-collapse:collapse;font-size:14px} th{text-align:left;font-size:12px;color:var(--muted);font-weight:600;padding:6px 8px;border-bottom:1px solid var(--line)}
 td{padding:9px 8px;border-bottom:1px solid #eef2f0;vertical-align:top} td a{color:var(--brand);font-weight:600}
 .up{display:grid;grid-template-columns:1fr 1fr;gap:0 12px;margin-top:4px} .up .full{grid-column:1/-1} @media (max-width:600px){.up{grid-template-columns:1fr}}
 button.primary{margin-top:14px;padding:10px 18px;border:0;border-radius:7px;background:var(--brand);color:#fff;font-size:14px;font-weight:600;cursor:pointer}
 button.primary:disabled{opacity:.6;cursor:default}
 .msg{margin-top:10px;font-size:14px} .msg.err{color:var(--err)} .msg.ok{color:var(--brand)}
 .empty{color:var(--muted);font-size:14px;padding:8px 0} .small{font-size:12px;color:var(--muted)} [hidden]{display:none!important}
</style></head><body><main>
<header><div><h1>Patient files</h1><div class="sub" id="prac">Test system, fictional data</div></div>
 <div><a href="/?practice=coastline">Back to the practice</a><a href="/login">My sign-in</a></div></header>
<div class="msg err" id="err"></div>
<div class="grid">
 <section class="card"><h2>Patients</h2>
  <input id="q" placeholder="Search name or code" autocomplete="off" aria-label="Search patients">
  <ul class="pts" id="pts"></ul>
 </section>
 <section class="card">
  <div id="pick" class="empty">Pick a patient on the left.</div>
  <div id="pane" hidden>
   <h2 id="pname"></h2><div class="small" id="pmeta"></div>
   <table style="margin-top:12px"><thead><tr><th>File</th><th>Type</th><th>Size</th><th>Added</th></tr></thead><tbody id="files"></tbody></table>
   <div class="empty" id="nofiles" hidden>No files for this patient yet.</div>
   <h2 style="margin-top:22px">Add a file</h2>
   <form id="f-up" class="up">
    <div class="full"><label for="file">File (PDF, picture, Word, Excel, CSV or text, up to <span id="max">25</span> MB)</label><input id="file" type="file" required
      accept=".pdf,.jpg,.jpeg,.png,.gif,.webp,.heic,.tif,.tiff,.txt,.doc,.docx,.xls,.xlsx,.csv"></div>
    <div><label for="ty">Type</label><select id="ty"></select></div>
    <div><label for="ti">Title (optional)</label><input id="ti" maxlength="255" placeholder="e.g. Signed surgical consent"></div>
    <div class="full"><button class="primary" type="submit">Upload</button><div class="msg" id="upmsg"></div></div>
   </form>
  </div>
 </section>
</div>
<script>
const $=id=>document.getElementById(id);
let current=null,types=[],maxMb=25,timer=null;
async function api(url,opts){const r=await fetch(url,Object.assign({credentials:"same-origin"},opts||{}));const d=await r.json().catch(()=>({}));
  if(r.status===401){location.replace("/login?next=/files");throw new Error("Signed out");}if(!r.ok)throw new Error(d.message||"Something went wrong.");return d;}
function size(n){n=Number(n||0);return n<1024?n+" B":n<1048576?(n/1024).toFixed(0)+" KB":(n/1048576).toFixed(1)+" MB";}
function usDate(iso){const m=String(iso||"").match(/^(\\d{4})-(\\d{2})-(\\d{2})/);return m?m[2]+"/"+m[3]+"/"+m[1]:"";}
function li(p){const b=document.createElement("button");b.type="button";b.dataset.code=p.PatientCode;
  b.append((p.FirstName||"")+" "+(p.LastName||""));const s=document.createElement("span");s.className="meta";
  s.textContent=p.PatientCode+(p.Dob?" · DOB "+usDate(p.Dob):"")+" · "+p.Files+" file"+(p.Files==1?"":"s");b.append(s);
  b.addEventListener("click",()=>open(p));const l=document.createElement("li");l.append(b);return l;}
async function search(){try{const d=await api("/api/files/patients?q="+encodeURIComponent($("q").value));
  $("prac").textContent="Practice "+d.practice+" · test system, fictional data";
  if(!types.length){types=d.types;maxMb=d.maxMb;$("max").textContent=maxMb;for(const t of types){const o=document.createElement("option");o.value=o.textContent=t;$("ty").append(o);}}
  $("pts").replaceChildren(...d.patients.map(li));if(current)mark();}catch(e){$("err").textContent=e.message;}}
function mark(){for(const b of $("pts").querySelectorAll("button"))b.classList.toggle("on",current&&b.dataset.code===current.PatientCode);}
async function open(p){current=p;mark();$("pick").hidden=true;$("pane").hidden=false;$("upmsg").textContent="";
  $("pname").textContent=(p.FirstName||"")+" "+(p.LastName||"");$("pmeta").textContent="Patient "+p.PatientCode+(p.Dob?" · DOB "+usDate(p.Dob):"");
  await loadFiles();}
async function loadFiles(){const d=await api("/api/files?patient="+encodeURIComponent(current.PatientCode));
  const rows=d.files.map(f=>{const tr=document.createElement("tr");const a=document.createElement("a");a.href="/api/files/"+f.DocumentId;a.target="_blank";a.rel="noopener";
    a.textContent=f.DocumentTitle||f.FileName;const t1=document.createElement("td");t1.append(a);
    if(f.DocumentTitle&&f.DocumentTitle!==f.FileName){const s=document.createElement("div");s.className="small";s.textContent=f.FileName;t1.append(s);}
    const td=(x)=>{const c=document.createElement("td");c.textContent=x;return c;};
    tr.append(t1,td(f.DocumentType),td(size(f.FileSizeBytes)),td(new Date(f.CreatedAt+"Z").toLocaleString()+(f.AddedBy?" · "+f.AddedBy:"")));return tr;});
  $("files").replaceChildren(...rows);$("nofiles").hidden=rows.length>0;}
$("q").addEventListener("input",()=>{clearTimeout(timer);timer=setTimeout(search,250);});
$("f-up").addEventListener("submit",async ev=>{ev.preventDefault();const f=$("file").files[0];if(!f||!current)return;
  const m=$("upmsg");m.className="msg";if(f.size>maxMb*1048576){m.className="msg err";m.textContent="That file is larger than "+maxMb+" MB.";return;}
  const btn=ev.target.querySelector("button");btn.disabled=true;m.textContent="Uploading "+f.name+"...";
  try{await api("/api/files?patient="+encodeURIComponent(current.PatientCode)+"&type="+encodeURIComponent($("ty").value)+"&title="+encodeURIComponent($("ti").value),
      {method:"POST",headers:{"Content-Type":"application/octet-stream","X-File-Name":encodeURIComponent(f.name)},body:f});
    m.className="msg ok";m.textContent="Uploaded "+f.name+".";ev.target.reset();await loadFiles();search();}
  catch(e){m.className="msg err";m.textContent=e.message;}finally{btn.disabled=false;}});
search();
</script></main></body></html>`);
});

// ---------------------------------------------------------------------------
// iMars import (step 7, TEST): /import, managers only, into the manager's OWN practice.
// Input: imars-export.zip made by export-imars.ps1 (manifest.json + files/...).
// Patients: PatientCode = iMars SysUserID (also LegacyImarsSysUserID); existing ones are updated, not duplicated.
// Appointments: LegacyImarsAppointmentID = iMars appntID; already-imported ones are skipped.
// Files: to Azure storage + a Documents row with LegacyRelativePath (= <SysUserID>/<folder>/<file>); already-imported
// paths are skipped, so the same zip can be imported again safely. SSN / driver's license are never imported.
// ---------------------------------------------------------------------------
const IMPORT_MAX_MB = 200;
// iMars patient folders (Account/local_files/<id>/<folder>) -> one Documents type each, so every folder can be compared 1:1
// with the type filter in the Documents tab. "temp" is not imported.
const IMARS_FOLDER_TYPE: Record<string, string> = {
  chart: "Chart", clinical: "Clinical note", document: "Outside records", ids: "ID / insurance", intakeforms: "Intake forms",
};
const IMARS_SKIP_FOLDERS = ["temp"];
// iMars keeps colors as hex numbers without leading zeros ("63C6" = #0063C6, "0" = black).
function imarsColor(v: any): string | null {
  const h = String(v ?? "").trim().replace(/^#/, "").toLowerCase();
  return /^[0-9a-f]{1,6}$/.test(h) ? `#${h.padStart(6, "0")}` : null;
}
// iMars often typed the degree into the first name ("Morris, MD" / "Leslie MD" / "Lindi, M.D."). Split it out.
function imarsPerson(first: any, last: any, suffix: any) {
  let f = String(first ?? "").trim(), cred = String(suffix ?? "").trim();
  const m = f.match(/^(.*?)[,\s]+(M\.?\s?D\.?|D\.?\s?O\.?|O\.?\s?D\.?|PA-?C|PA|NP|DDS|DMD|RN|PhD)\.?$/i);
  if (m && m[1].trim()) { f = m[1].replace(/,\s*$/, "").trim(); if (!cred) cred = m[2].replace(/[.\s]/g, "").toUpperCase(); }
  cred = cred.replace(/^,\s*/, "").replace(/\./g, "").toUpperCase();
  const l = String(last ?? "").trim();
  return { first: f, last: l, cred, display: `${f} ${l}`.trim() + (cred ? `, ${cred}` : "") };
}
function imarsDate(v: any): string | null {
  const s = String(v || "").trim(); if (!s) return null;
  let m = s.match(/^(\d{4})-(\d{1,2})-(\d{1,2})/); if (m) return `${m[1]}-${m[2].padStart(2, "0")}-${m[3].padStart(2, "0")}`;
  m = s.match(/^(\d{1,2})[\/\-.](\d{1,2})[\/\-.](\d{2,4})/);
  if (m) { let y = +m[3]; if (y < 100) y += y > 30 ? 1900 : 2000; return `${y}-${m[1].padStart(2, "0")}-${m[2].padStart(2, "0")}`; }
  return null;
}
function imarsSex(v: any): string | null {
  const s = String(v || "").trim().toLowerCase();
  return s.startsWith("f") ? "Female" : s.startsWith("m") ? "Male" : s ? "Other" : null;
}
const cut = (v: any, n: number) => { const s = String(v ?? "").trim(); return s ? s.slice(0, n) : null; };
const pad2i = (n: number) => String(n).padStart(2, "0");
function isoLocal(s: any): string | null { const m = String(s || "").match(/^(\d{4}-\d{2}-\d{2})T(\d{2}:\d{2})(:\d{2})?/); return m ? `${m[1]} ${m[2]}:00` : null; }

app.post("/api/import/imars", express.raw({ type: () => true, limit: `${IMPORT_MAX_MB}mb` }), async (req: any, res) => {
  const m = await requireManager(req, res); if (!m) return;
  const notes: string[] = [];
  const count = { patientsAdded: 0, patientsUpdated: 0, apptsAdded: 0, apptsUpdated: 0, apptsSkipped: 0, filesAdded: 0, filesUpdated: 0, filesSkipped: 0, filesMissing: 0 };
  try {
    const body: Buffer = Buffer.isBuffer(req.body) ? req.body : Buffer.alloc(0);
    if (!body.length) return res.status(400).json({ status: "error", message: "The zip file is empty." });
    const AdmZipMod: any = await import("adm-zip");
    const AdmZip = AdmZipMod.default ?? AdmZipMod;
    let zip: any; try { zip = new AdmZip(body); } catch { return res.status(400).json({ status: "error", message: "That is not a zip file." }); }
    const entries = new Map<string, any>();
    for (const e of zip.getEntries()) if (!e.isDirectory) entries.set(String(e.entryName).replace(/\\/g, "/").replace(/^\/+/, ""), e);
    const me = entries.get("manifest.json");
    if (!me) return res.status(400).json({ status: "error", message: "manifest.json is missing. Use the zip made by export-imars.ps1." });
    const mf = JSON.parse(me.getData().toString("utf8").replace(/^﻿/, ""));
    if (mf.source !== "imars") return res.status(400).json({ status: "error", message: "This zip is not an iMars export." });
    const asList = (x: any) => Array.isArray(x) ? x : x ? [x] : [];
    // ---- Staff zip (export-imars.ps1 -Staff): providers/surgeons with their colors, staff logins, rooms ----
    if (mf.kind === "staff") {
      const pool = m.pool; const org = String(m.OrganizationId);
      const c = { providersAdded: 0, providersUpdated: 0, usersAdded: 0, usersUpdated: 0, logins: 0, roomsAdded: 0, roomsUpdated: 0, skipped: 0 };
      const site = (await pool.request().input("org", org).query(
        `SELECT TOP 1 SiteId FROM dbo.Sites WHERE OrganizationId = @org AND IsActive = 1 ORDER BY SiteId`)).recordset[0];
      if (!site) return res.status(409).json({ status: "error", message: "Your practice has no site (location) in the database." });
      const hexColor = imarsColor;
      const yes = (v: any) => /^(yes|true|1|y)$/i.test(String(v ?? "").trim());
      for (const e of asList(mf.employees)) {
        const sys = cut(e.UserSysID, 100); if (!sys) { c.skipped++; continue; }
        const person = imarsPerson(e.firstname, e.lastname, e.suffix);
        const first = cut(person.first, 100) || "(no first name)", last = cut(person.last, 100) || "(no last name)";
        const suffix = cut(person.cred, 100);
        const isProvider = yes(e.provider);
        const onSchedule = yes(e.schedule) ? 1 : 0;          // iMars "Scheduler" = add to appointment book
        const title = cut(e.title, 50);                       // iMars "Title" (Doctor, Anesthesiologist, ...)
        const color = hexColor(e.color);
        const access = String(e.access || "").trim().toLowerCase();   // iMars "Access": admin / limited / none
        if (isProvider) {
          const sfx = String(suffix || "").toUpperCase();
          const ptype = /anesth/i.test(title || "") ? "Anesthesiologist" : /\bPA\b|PA-C/.test(sfx) ? "Physician assistant" : /\bNP\b|FNP|ARNP/.test(sfx) ? "Nurse practitioner"
            : /doctor|surg/i.test(`${title || ""} ${e.specialty || ""}`) || /\b(MD|DO)\b/.test(sfx) ? "Surgeon" : "Physician";
          const npi = /^\d{10}$/.test(String(e.ipn || "").trim()) ? String(e.ipn).trim() : null;
          const r = await pool.request().input("org", org).input("sys", sys).input("site", cut(e.siteID, 100))
            .input("fn", first).input("mn", cut(e.mi, 100)).input("ln", last).input("cred", suffix).input("type", ptype)
            .input("npi", npi).input("em", cut(e.email, 254)).input("ph", cut(e.cellphone, 30)).input("spec", cut(e.specialty, 400))
            .input("color", color).input("code", `imars-${sys}`.slice(0, 50)).input("sched", onSchedule).input("title", title)
            .query(`DECLARE @id bigint = (SELECT TOP 1 ProviderId FROM dbo.Providers WHERE OrganizationId = @org AND LegacyImarsUserSysID = @sys);
                    IF @id IS NOT NULL BEGIN
                      UPDATE dbo.Providers SET FirstName = @fn, MiddleName = @mn, LastName = @ln, Credentials = @cred, ProviderType = @type, NPI = @npi,
                             Email = @em, Phone = @ph, Specialty = @spec, Color = @color, ShowOnSchedule = @sched, Title = @title,
                             LegacyImarsSiteID = @site, IsActive = 1, UpdatedAt = SYSUTCDATETIME()
                      WHERE ProviderId = @id; SELECT 0 AS Added;
                    END ELSE BEGIN
                      INSERT dbo.Providers (OrganizationId, ProviderCode, FirstName, MiddleName, LastName, Credentials, ProviderType, NPI, Email, Phone,
                                            Specialty, Color, ShowOnSchedule, Title, LegacyImarsSiteID, LegacyImarsUserSysID)
                      VALUES (@org, @code, @fn, @mn, @ln, @cred, @type, @npi, @em, @ph, @spec, @color, @sched, @title, @site, @sys); SELECT 1 AS Added;
                    END`);
          if (r.recordset[0].Added) c.providersAdded++; else c.providersUpdated++;
        }
        // Everyone goes into the practice's people list (Staff page), like iMars "Manage Users".
        // Login (username) only for people who had an iMars login. Passwords are NOT carried over: the account cannot
        // sign in until a manager uses "Reset password" on the Staff page.
        const code = `imars-${sys}`.slice(0, 50);
        const roleCode = access === "admin" ? "SITE_ADMIN" : isProvider ? "PROVIDER" : access === "limited" ? "FRONT_DESK" : (isProvider ? "PROVIDER" : "READ_ONLY");
        const mine = (await pool.request().input("org", org).input("code", code).query(
          `SELECT TOP 1 UserId, Username FROM dbo.Users WHERE OrganizationId = @org AND UserCode = @code`)).recordset[0];
        const uname0 = String(e.username || "").trim().toLowerCase().replace(/[^a-z0-9._@-]/g, "").slice(0, 90);
        let username: string | null = null;
        if (uname0 && !mine?.Username) {
          const taken = async (u: string) => (await pool.request().input("u", u).query(`SELECT 1 AS x FROM dbo.Users WHERE Username = @u`)).recordset.length > 0;
          username = uname0;
          if (await taken(username)) username = `${uname0}.${m.OrganizationCode}`.slice(0, 100).toLowerCase();
          if (await taken(username)) { notes.push(`Login "${uname0}" already exists; ${first} ${last} added without a login.`); username = null; }
          else if (username !== uname0) notes.push(`Login "${uname0}" was taken; created as "${username}" for ${first} ${last}.`);
        }
        const rq = pool.request().input("org", org).input("code", code).input("fn", first).input("ln", last)
          .input("em", cut(e.loginEmail || e.email, 254)).input("ph", cut(e.cellphone, 30)).input("title", title)
          .input("color", color).input("sched", onSchedule).input("u", username).input("role", roleCode)
          .input("active", e.loginApproved == null || yes(e.loginApproved) ? 1 : 0);
        if (mine) {
          await rq.input("id", String(mine.UserId)).query(
            `UPDATE dbo.Users SET FirstName = @fn, LastName = @ln, Email = @em, Phone = @ph, Title = @title, Color = @color, ShowOnSchedule = @sched,
                    Username = ISNULL(Username, @u), UpdatedAt = SYSUTCDATETIME() WHERE UserId = @id`);
          c.usersUpdated++;
        } else {
          await rq.query(
            `DECLARE @roleId bigint = (SELECT TOP 1 RoleId FROM dbo.Roles WHERE RoleCode = @role AND IsActive = 1
                                         AND (OrganizationId = @org OR OrganizationId IS NULL) ORDER BY OrganizationId DESC);
             DECLARE @new TABLE (UserId bigint);
             INSERT dbo.Users (OrganizationId, UserCode, FirstName, LastName, Username, Email, Phone, Title, Color, ShowOnSchedule,
                               PasswordHash, MustChangePassword, IsActive)
             OUTPUT inserted.UserId INTO @new
             VALUES (@org, @code, @fn, @ln, @u, @em, @ph, @title, @color, @sched, NULL, 1, @active);
             IF @roleId IS NOT NULL INSERT dbo.UserRoles (UserId, RoleId) SELECT UserId, @roleId FROM @new;`);
          c.usersAdded++;
        }
        if (username) c.logins++;
      }
      for (const r0 of asList(mf.rooms)) {
        const rid = cut(r0.ID, 100); if (!rid) { c.skipped++; continue; }
        const r = await pool.request().input("site", String(site.SiteId)).input("rid", rid).input("code", `imars-${rid}`.slice(0, 50))
          .input("name", cut(r0.name, 150) || "Room").input("type", cut(r0.type, 50) || "Room").input("color", hexColor(r0.color))
          .query(`DECLARE @id bigint = (SELECT TOP 1 ResourceId FROM dbo.Resources WHERE SiteId = @site AND LegacyImarsResourceID = @rid);
                  IF @id IS NOT NULL BEGIN
                    UPDATE dbo.Resources SET ResourceName = @name, ResourceType = @type, Color = @color, IsActive = 1, UpdatedAt = SYSUTCDATETIME() WHERE ResourceId = @id;
                    SELECT 0 AS Added;
                  END ELSE BEGIN
                    INSERT dbo.Resources (SiteId, ResourceCode, ResourceName, ResourceType, Color, LegacyImarsResourceID) VALUES (@site, @code, @name, @type, @color, @rid);
                    SELECT 1 AS Added;
                  END`);
        if (r.recordset[0].Added) c.roomsAdded++; else c.roomsUpdated++;
      }
      await audit(m, req, "IMARS_IMPORT", null, `iMars staff import: ${c.providersAdded} providers added, ${c.providersUpdated} updated; ${c.usersAdded} people added, ${c.usersUpdated} updated (${c.logins} new logins); ${c.roomsAdded} rooms added, ${c.roomsUpdated} updated`);
      return res.json({ status: "ok", kind: "staff", practice: m.OrganizationCode, ...c, notes });
    }

    const pool = m.pool; const org = String(m.OrganizationId);
    const site = (await pool.request().input("org", org).query(
      `SELECT TOP 1 SiteId FROM dbo.Sites WHERE OrganizationId = @org AND IsActive = 1 ORDER BY SiteId`)).recordset[0];
    if (!site) return res.status(409).json({ status: "error", message: "Your practice has no site (location) in the database." });

    // 1. Patients
    const pidByCode = new Map<string, string>();
    for (const p of asList(mf.patients)) {
      const code = cut(p.SysUserID, 50); if (!code) continue;
      const r = await pool.request()
        .input("org", org).input("code", code)
        .input("fn", cut(p.firstName, 100) || "(no first name)").input("mn", cut(p.mi, 100)).input("ln", cut(p.lastName, 100) || "(no last name)")
        .input("dob", imarsDate(p.dob)).input("sex", imarsSex(p.gender)).input("em", cut(p.email, 254))
        .input("cell", cut(p.cellphome || p.bestphone, 30)).input("home", cut(p.homephone, 30))
        .input("a1", cut(p.address, 200)).input("city", cut(p.city, 100)).input("st", cut(p.state, 100)).input("zip", cut(p.zipcode, 20))
        .query(`DECLARE @id bigint = (SELECT TOP 1 PatientId FROM dbo.Patients WHERE OrganizationId = @org AND PatientCode = @code);
                IF @id IS NOT NULL
                BEGIN
                  UPDATE dbo.Patients SET FirstName = @fn, MiddleName = @mn, LastName = @ln, DateOfBirth = TRY_CAST(@dob AS date), SexAtBirth = @sex,
                         Email = @em, MobilePhone = @cell, HomePhone = @home, AddressLine1 = @a1, City = @city, StateProvince = @st, PostalCode = @zip,
                         LegacyImarsSysUserID = @code, IsActive = 1, UpdatedAt = SYSUTCDATETIME()
                  WHERE PatientId = @id;
                  SELECT @id AS PatientId, 0 AS Added;
                END
                ELSE
                BEGIN
                  DECLARE @new TABLE (PatientId bigint);
                  INSERT dbo.Patients (OrganizationId, PatientCode, FirstName, MiddleName, LastName, DateOfBirth, SexAtBirth, Email, MobilePhone, HomePhone,
                                       AddressLine1, City, StateProvince, PostalCode, LegacyImarsSysUserID)
                  OUTPUT inserted.PatientId INTO @new
                  VALUES (@org, @code, @fn, @mn, @ln, TRY_CAST(@dob AS date), @sex, @em, @cell, @home, @a1, @city, @st, @zip, @code);
                  SELECT PatientId, 1 AS Added FROM @new;
                END`);
      const row = r.recordset[0]; pidByCode.set(code, String(row.PatientId));
      if (row.Added) count.patientsAdded++; else count.patientsUpdated++;
    }

    // 2. Appointments
    // iMars keeps a display line in "name": "last,first<br />id<br />provider<br />reason<br />note"; reasonSysID often holds
    // the reason text itself; duration is in hours. Already-imported appointments are updated (so a fixed import corrects them).
    for (const a of asList(mf.appointments)) {
      const code = String(a.patientSysID || ""); const pid = pidByCode.get(code);
      const legacy = cut(a.appntID, 255); const start = isoLocal(a.starttime);
      if (!pid || !legacy || !start) { count.apptsSkipped++; continue; }
      const parts = String(a.name || "").split(/<br\s*\/?>/i).map((x: string) => x.replace(/<[^>]*>/g, "").trim());
      const looksLikeId = (x: any) => /^\d{4,}$/.test(String(x || "").trim());
      const end = isoLocal(a.endtime);
      const hours = Number(a.duration);
      const startMs = new Date(start.replace(" ", "T")).getTime();
      let durMin = end ? Math.round((new Date(end.replace(" ", "T")).getTime() - startMs) / 60000) : Math.round((isFinite(hours) && hours > 0 ? hours : 0.5) * 60);
      durMin = Math.max(5, Math.min(720, durMin || 30));
      // The appointment is booked "for" a calendar column (roomSysID = imars_SiteAppntFor): a surgeon/employee or an OR room.
      // Its color (forcolor) is what iMars paints the appointment with.
      const isOR = String(a.type || "").toUpperCase() === "OR";
      const type = cut(a.visitTypeName, 50) || (isOR ? "Surgery" : "Visit");
      let provider: string, room: string, reason: string | null, noteText: string;
      if (isOR) {   // name: "last,first<br />id<br />room<br />provider<br />procedure<br />note"
        room = String(a.roomEventName || a.roomName || parts[2] || "").trim();
        provider = String(a.misc3 || parts[3] || "").trim();
        reason = cut(a.procedures || parts[4], 500);
        noteText = String(a.note || parts[5] || "").trim();
      } else {      // name: "last,first<br />id<br />provider<br />reason<br />note"
        room = "";
        provider = (a.employeeFirst || a.employeeLast) ? imarsPerson(a.employeeFirst, a.employeeLast, a.employeeSuffix).display
          : String(a.roomName || a.providerName || parts[2] || "").trim();
        reason = cut(a.reasonName || (!looksLikeId(a.reasonSysID) ? a.reasonSysID : "") || parts[3] || a.procedures, 500);
        noteText = String(a.note || parts[4] || "").trim();
      }
      // iMars colors by the calendar column: employees in imars_SiteEmployee.color, rooms/events in imars_SiteRoomEvent.color
      // (older sites: imars_SiteAppntFor.forcolor).
      const color = imarsColor(a.employeeColor || a.roomEventColor || a.roomColor || a.providerColor) || undefined;
      const past = startMs < Date.now();
      const checkedIn = /check/i.test(String(a.checkedin || ""));
      const confirmed = /confirm/i.test(String(a.confirmation || ""));
      const status = past ? "COMPLETED" : checkedIn ? "CHECKED_IN" : "SCHEDULED";
      const ref = `imars-${legacy}`.slice(0, 100);
      const [d, t] = start.split(" "); const hh = +t.slice(0, 2);
      const visit: any = { id: ref, patientId: code, date: d, time: `${pad2i(hh % 12 || 12)}:${t.slice(3, 5)} ${hh >= 12 ? "PM" : "AM"}`,
        durationMin: durMin, provider, room, visitType: type, reason: reason || "", notes: noteText || undefined, color,
        step: past ? "complete" : checkedIn ? "check-in" : "scheduled", problemIds: [], createdAt: new Date().toISOString(), createdBy: "iMars import",
        imars: { appntID: legacy, siteID: a.siteID || undefined, confirmed, checkedIn } };
      const r = await pool.request()
        .input("org", org).input("site", String(site.SiteId)).input("pid", pid).input("type", type).input("start", start).input("dur", durMin)
        .input("status", status).input("reason", reason).input("notes", cut(noteText, 1000))
        .input("legacy", legacy).input("ref", ref).input("json", JSON.stringify(visit))
        .query(`DECLARE @s datetime2(0) = CAST(@start AS datetime2(0));
                DECLARE @id bigint = (SELECT TOP 1 a.AppointmentId FROM dbo.Appointments a JOIN dbo.Sites s ON s.SiteId = a.SiteId
                                      WHERE a.LegacyImarsAppointmentID = @legacy AND s.OrganizationId = @org);
                IF @id IS NOT NULL
                BEGIN
                  UPDATE dbo.Appointments SET PatientId = @pid, AppointmentType = @type, StartDateTime = @s, EndDateTime = DATEADD(minute, @dur, @s),
                         Status = @status, ReasonForVisit = @reason, Notes = @notes, AppRef = @ref, AppJson = @json, IsActive = 1, UpdatedAt = SYSUTCDATETIME()
                  WHERE AppointmentId = @id;
                  SELECT 2 AS Added;
                END
                ELSE IF EXISTS (SELECT 1 FROM dbo.Appointments WHERE LegacyImarsAppointmentID = @legacy) SELECT 0 AS Added;
                ELSE BEGIN
                  INSERT dbo.Appointments (SiteId, PatientId, AppointmentType, StartDateTime, EndDateTime, Status, ReasonForVisit, Notes,
                                           LegacyImarsAppointmentID, AppRef, AppJson)
                  VALUES (@site, @pid, @type, @s, DATEADD(minute, @dur, @s), @status, @reason, @notes, @legacy, @ref, @json);
                  SELECT 1 AS Added;
                END`);
      const added = r.recordset[0].Added;
      if (added === 1) count.apptsAdded++; else if (added === 2) count.apptsUpdated++; else { count.apptsSkipped++; notes.push(`Appointment ${legacy} belongs to another practice; skipped.`); }
    }

    // 3. Files
    const docs = asList(mf.documents);
    const container = await getContainer();
    for (const f of asList(mf.files)) {
      const code = String(f.patient || ""); const pid = pidByCode.get(code);
      if (!pid) { count.filesSkipped++; continue; }
      const rel = cut(f.relativePath, 1000) || `${code}/${f.folder}/${f.name}`;
      const folder = String(f.folder || "").toLowerCase();
      if (IMARS_SKIP_FOLDERS.includes(folder)) { count.filesSkipped++; continue; }
      const folderType = IMARS_FOLDER_TYPE[folder] || (f.folder ? `${String(f.folder).slice(0, 80)}` : "Outside records");
      // Already imported: only correct its type (no second upload).
      const existing = (await pool.request().input("org", org).input("rel", rel).input("type", folderType).query(
        `UPDATE dbo.Documents SET DocumentType = @type,
                AppJson = CASE WHEN ISJSON(AppJson) = 1 THEN JSON_MODIFY(AppJson, '$.type', @type) ELSE AppJson END, UpdatedAt = SYSUTCDATETIME()
         WHERE OrganizationId = @org AND LegacyRelativePath = @rel AND IsActive = 1;
         SELECT @@ROWCOUNT AS n;`)).recordset[0].n;
      if (existing) { count.filesUpdated++; continue; }
      const entry = entries.get(String(f.zipPath || "").replace(/\\/g, "/"));
      if (!entry) { count.filesMissing++; notes.push(`Missing in zip: ${rel}`); continue; }
      const data: Buffer = entry.getData();
      const hash = crypto.createHash("sha256").update(data).digest("hex");
      if (f.sha256 && f.sha256 !== hash) { count.filesMissing++; notes.push(`Damaged in zip (checksum differs): ${rel}`); continue; }
      const fileName = String(f.name || "file").slice(0, 255);
      const ext = (fileName.match(/\.[A-Za-z0-9]{1,5}$/)?.[0] || "").toLowerCase();
      const contentType = FILE_KINDS[ext]?.type || "application/octet-stream";
      const match = docs.find((d: any) => String(d.userSysID) === code && (d.name === fileName || String(d.path || "").replace(/\\/g, "/").endsWith("/" + fileName)));
      const docType = folderType.slice(0, 100);
      const title = (cut(match?.name, 255) || fileName.replace(/\.[^.]+$/, "") || fileName).slice(0, 255);
      const docDate = imarsDate(match?.datesend) || imarsDate(f.modified);
      const safeName = fileName.replace(/[^\w.\- ()]/g, "_").slice(0, 120);
      const blobName = `org-${org}/patient-${pid}/${folder || "files"}/${crypto.randomUUID().slice(0, 8)}-${safeName}`;
      await container.getBlockBlobClient(blobName).uploadData(data, {
        blobHTTPHeaders: { blobContentType: contentType }, metadata: { org, patient: pid, sha256: hash, source: "imars" } });
      const appJson = { patientId: code, type: docType, title, source: "iMars (migrated)", docDate: docDate || new Date().toISOString().slice(0, 10),
        receivedAt: match?.datesend ? `${String(match.datesend).slice(0, 19)}Z` : new Date().toISOString(), receivedBy: "iMars import", receivedRole: "",
        description: `Migrated from iMars folder "${f.folder || ""}": ${rel}`, fileName, mime: contentType, size: data.length };
      await pool.request()
        .input("org", org).input("pid", pid).input("type", docType).input("title", title).input("fn", fileName).input("ct", contentType)
        .input("size", sqlLib.BigInt, data.length).input("path", `${process.env.STORAGE_CONTAINER}/${blobName}`)
        .input("cont", String(process.env.STORAGE_CONTAINER)).input("blob", blobName).input("hash", hash).input("dd", docDate)
        .input("uid", String(m.UserId)).input("ref", cut(match?.ID, 500)).input("rel", rel).input("json", JSON.stringify(appJson))
        .query(`INSERT dbo.Documents (OrganizationId, PatientId, DocumentType, DocumentTitle, FileName, ContentType, FileSizeBytes, StoragePath,
                                      StorageContainer, StorageBlobName, FileHashSHA256, DocumentDate, CreatedByUserId, SourceSystem, SourceReference,
                                      LegacyRelativePath, ImportedAt, ImportedByUserId, AppJson)
                VALUES (@org, @pid, @type, @title, @fn, @ct, @size, @path, @cont, @blob, @hash, TRY_CAST(@dd AS date), @uid, N'imars', @ref,
                        @rel, SYSUTCDATETIME(), @uid, @json)`);
      count.filesAdded++;
    }
    const summary = `iMars import: ${count.patientsAdded} patients added, ${count.patientsUpdated} updated; ${count.apptsAdded} appointments added, ${count.apptsUpdated} updated, ${count.apptsSkipped} skipped; ${count.filesAdded} files added, ${count.filesUpdated} updated, ${count.filesSkipped} skipped, ${count.filesMissing} missing`;
    await audit(m, req, "IMARS_IMPORT", null, summary);
    res.json({ status: "ok", practice: m.OrganizationCode, ...count, notes });
  } catch (e: any) {
    console.error("iMars import error:", e);
    if (e?.type === "entity.too.large") return res.status(413).json({ status: "error", message: `The zip is larger than ${IMPORT_MAX_MB} MB. Export fewer patients at a time.` });
    res.status(500).json({ status: "error", message: "The import stopped with an error (anything before it was saved). Check the app log.", ...count, notes });
  }
});

app.get("/import", (_req, res) => {
  res.setHeader("Cache-Control", "no-store");
  res.type("html").send(`<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Import from iMars · Vityls</title>
<style>
 :root{--ink:#1d2b25;--muted:#5b6b64;--line:#d5ddd9;--brand:#1f4e3d;--soft:#e8f1ed;--err:#a1261b}
 *{box-sizing:border-box} body{font-family:"Segoe UI",system-ui,sans-serif;background:#f4f6f5;color:var(--ink);margin:0;padding:32px 16px}
 main{max-width:720px;margin:0 auto} header{display:flex;flex-wrap:wrap;gap:12px;align-items:baseline;justify-content:space-between;margin-bottom:18px}
 h1{font-size:22px;margin:0} .sub{color:var(--muted);font-size:14px} header a{color:var(--brand);font-size:14px;margin-left:14px}
 .card{background:#fff;border:1px solid var(--line);border-radius:12px;padding:20px 22px;margin-bottom:18px}
 p{font-size:14px;line-height:1.5;color:var(--muted);margin:0 0 12px} input[type=file]{width:100%;padding:10px;border:1px dashed #b9c6c0;border-radius:8px;background:#fafcfb}
 button{margin-top:14px;padding:10px 18px;border:0;border-radius:7px;background:var(--brand);color:#fff;font-size:14px;font-weight:600;cursor:pointer} button:disabled{opacity:.6}
 progress{width:100%;margin-top:12px;height:10px} .msg{margin-top:12px;font-size:14px} .msg.err{color:var(--err)}
 table{width:100%;border-collapse:collapse;font-size:14px;margin-top:6px} td{padding:8px 4px;border-bottom:1px solid #eef2f0} td.n{text-align:right;font-weight:600;font-variant-numeric:tabular-nums}
 ul{font-size:13px;color:var(--err);padding-left:18px} [hidden]{display:none!important}
</style></head><body><main>
<header><div><h1>Import from iMars</h1><div class="sub" id="prac">Test import · managers only</div></div>
 <div><a href="/manage">Staff</a><a href="/?practice=coastline">Back to the practice</a></div></header>
<section class="card">
 <p>Upload the <b>imars-export.zip</b> made by <b>export-imars.ps1</b>. Patients, appointments and files go into <b>your practice</b>.
 Importing the same zip again is safe: nothing is duplicated.</p>
 <form id="f"><input id="zip" type="file" accept=".zip,application/zip" required><button type="submit">Import</button></form>
 <progress id="pg" max="100" value="0" hidden></progress><div class="msg" id="msg"></div>
</section>
<section class="card" id="out" hidden><h2 style="font-size:16px;margin:0 0 6px">Result</h2><table id="res"></table><ul id="notes"></ul></section>
<script>
const $=id=>document.getElementById(id);
fetch("/api/manage/staff",{credentials:"same-origin"}).then(async r=>{if(r.status===401){location.replace("/login?next=/import");return;}
  const d=await r.json().catch(()=>({}));if(!r.ok){$("msg").className="msg err";$("msg").textContent=d.message||"Only a practice manager can import.";$("f").hidden=true;return;}
  $("prac").textContent="Into practice "+d.practice+" · "+(d.practiceName||"");});
$("f").addEventListener("submit",ev=>{ev.preventDefault();const file=$("zip").files[0];if(!file)return;
  const btn=ev.target.querySelector("button");btn.disabled=true;$("out").hidden=true;$("msg").className="msg";$("msg").textContent="Uploading "+file.name+"...";
  const x=new XMLHttpRequest();x.open("POST","/api/import/imars");x.withCredentials=true;x.setRequestHeader("Content-Type","application/zip");
  $("pg").hidden=false;$("pg").value=0;
  x.upload.onprogress=e=>{if(e.lengthComputable){$("pg").value=Math.round(e.loaded*100/e.total);if(e.loaded===e.total)$("msg").textContent="Uploaded. Importing (this can take a minute)...";}};
  x.onload=()=>{btn.disabled=false;$("pg").hidden=true;let d={};try{d=JSON.parse(x.responseText);}catch(e){}
    if(x.status===401){location.replace("/login?next=/import");return;}
    if(x.status!==200){$("msg").className="msg err";$("msg").textContent=d.message||("Import failed ("+x.status+").");}
    else{$("msg").textContent="Import finished.";}
    if(d.kind==="staff"){const rows=[["Providers / surgeons added",d.providersAdded],["Providers updated (already there)",d.providersUpdated],["People added to the Staff page",d.usersAdded],
      ["People updated",d.usersUpdated],["New logins (no password yet)",d.logins],["Rooms added",d.roomsAdded],["Rooms updated",d.roomsUpdated],["Skipped",d.skipped]];
      $("res").replaceChildren(...rows.map(([k,v])=>{const tr=document.createElement("tr");const a=document.createElement("td");a.textContent=k;const b=document.createElement("td");b.className="n";b.textContent=v;tr.append(a,b);return tr;}));
      $("notes").replaceChildren(...(d.notes||[]).map(n=>{const li=document.createElement("li");li.textContent=n;return li;}));$("out").hidden=false;return;}
    if(d.patientsAdded!=null){const rows=[["Patients added",d.patientsAdded],["Patients updated (already there)",d.patientsUpdated],["Appointments added",d.apptsAdded],
      ["Appointments updated (already imported)",d.apptsUpdated],["Appointments skipped",d.apptsSkipped],["Files added",d.filesAdded],["Files updated (already imported)",d.filesUpdated],["Files skipped (temp folder)",d.filesSkipped],["Files missing or damaged",d.filesMissing]];
      $("res").replaceChildren(...rows.map(([k,v])=>{const tr=document.createElement("tr");const a=document.createElement("td");a.textContent=k;const b=document.createElement("td");b.className="n";b.textContent=v;tr.append(a,b);return tr;}));
      $("notes").replaceChildren(...(d.notes||[]).map(n=>{const li=document.createElement("li");li.textContent=n;return li;}));$("out").hidden=false;}};
  x.onerror=()=>{btn.disabled=false;$("pg").hidden=true;$("msg").className="msg err";$("msg").textContent="The upload was interrupted. Try again.";};
  x.send(file);});
</script></main></body></html>`);
});

// ---------------------------------------------------------------------------
// Kevin's record store (Vityls OS v11.4) on Azure SQL, behind OUR sign-in (merge step 1).
//   GET  /api/v1/store[?since=ISO]  -> { items: [{ k, v, at, by }], now }
//   PUT  /api/v1/store { items: [{ k, v|null }], by } -> { ok, at }
//   POST /api/v1/store-beacon      (last save when a tab closes)
//   GET  /api/v1/health
// Differences from Kevin's server/store.ts:
//   * Only a fully signed-in user (password + MFA) can read or write.
//   * The tenant is the signed-in user's practice ("org-<OrganizationId>"); the X-Vityls-Tenant header is ignored,
//     so one practice can never read or write another practice's records.
//   * The Patient Portal channel ("portal": practice<->patient messages, portal accounts) is kept per practice as
//     "org-<OrganizationId>:portal" and, for now, only signed-in staff can read or write it. When patients get their own
//     sign-in, the Portal will need its own rules here.
//   * Records that live in our real tables (patients, appointments, documents, providers) are not stored here, so there is
//     one source of truth for them; the iMars import keeps writing those tables.
//   * Uses the app's own Azure identity (getDb), no connection string or password. Tables: app.record, app.record_history
//     (created once by Vityls_Merge_Step1.sql, Kevin's DDL).
// ---------------------------------------------------------------------------
// v11.5: providers (vityls:v7:providers) are kept here again: the full record (credentials, onboarding, PIN) lives in the
// store, and a copy of the basic fields goes to dbo.Providers through /api/office/providers for integrations.
const STORE_OWNED_BY_TABLES = /(^|~)vityls:(med:patients|med:visits|surgery:documents)$|^server:/;
const storeTenant = (me: any) => `org-${me.OrganizationId}`;
const isPortalTenant = (req: any) => String(req.headers["x-vityls-tenant"] || "").toLowerCase() === "portal";
const reqTenant = (me: any, portal: boolean) => storeTenant(me) + (portal ? ":portal" : "");
const storeJson = express.json({ limit: "25mb" });

async function storeList(tenant: string, since?: string) {
  const pool = await getDb();
  const r = pool.request().input("t", sqlLib.NVarChar(64), tenant);
  if (since) r.input("s", sqlLib.DateTime2(3), new Date(since));
  const q = await r.query(`SELECT record_key AS k, value_json AS v, CONVERT(varchar(30), updated_at, 127) + 'Z' AS at, updated_by AS [by]
                           FROM app.record WHERE tenant_id = @t${since ? " AND updated_at > @s" : ""}`);
  return q.recordset.filter((x: any) => !STORE_OWNED_BY_TABLES.test(x.k));
}
async function storePut(tenant: string, items: { k: string; v: string | null }[], by: string) {
  const pool = await getDb();
  const at = new Date();
  const tx = new sqlLib.Transaction(pool); await tx.begin();
  try {
    for (const i of items) {
      await new sqlLib.Request(tx).input("t", sqlLib.NVarChar(64), tenant).input("k", sqlLib.NVarChar(400), i.k)
        .input("v", sqlLib.NVarChar(sqlLib.MAX), i.v).input("a", sqlLib.DateTime2(3), at).input("b", sqlLib.NVarChar(200), by)
        .query(`MERGE app.record WITH (HOLDLOCK) AS d USING (SELECT @t AS tenant_id, @k AS record_key) AS s
                  ON d.tenant_id = s.tenant_id AND d.record_key = s.record_key
                WHEN MATCHED THEN UPDATE SET value_json = @v, updated_at = @a, updated_by = @b
                WHEN NOT MATCHED THEN INSERT (tenant_id, record_key, value_json, updated_at, updated_by) VALUES (@t, @k, @v, @a, @b);
                INSERT INTO app.record_history (tenant_id, record_key, value_json, changed_at, changed_by) VALUES (@t, @k, @v, @a, @b);`);
    }
    await tx.commit();
  } catch (e) { await tx.rollback(); throw e; }
  return at.toISOString();
}
const storeItems = (body: any) => (Array.isArray(body?.items) ? body.items : [])
  .filter((i: any) => typeof i?.k === "string" && i.k.length <= 400 && (i.v === null || typeof i.v === "string") && !STORE_OWNED_BY_TABLES.test(i.k));
const storeBy = (me: any, body: any) => `${me.Username}${body?.by ? ` · ${String(body.by).slice(0, 120)}` : ""}`.slice(0, 200);

app.get("/api/v1/health", async (_req, res) => {
  try { const pool = await getDb(); await pool.request().query("SELECT TOP 0 tenant_id FROM app.record"); res.json({ ok: true, backend: "azure-sql", at: new Date().toISOString() }); }
  catch (e: any) { res.status(500).json({ ok: false, backend: "azure-sql", error: "Record store not ready (run Vityls_Merge_Step1.sql)." }); }
});
app.get("/api/v1/store", async (req, res) => {
  try {
    const me = await currentUser(req); if (!me) return res.status(401).json({ error: "signed-out" });
    const since = typeof req.query.since === "string" && !isNaN(Date.parse(req.query.since)) ? req.query.since : undefined;
    res.json({ items: await storeList(reqTenant(me, isPortalTenant(req)), since), now: new Date().toISOString() });
  } catch (e: any) { console.error("Store read error:", e); res.status(500).json({ error: "Could not read the record store." }); }
});
app.put("/api/v1/store", storeJson, async (req, res) => {
  try {
    const me = await currentUser(req); if (!me) return res.status(401).json({ error: "signed-out" });
    const items = storeItems(req.body);
    if (!items.length) return res.json({ ok: true, at: new Date().toISOString() });
    res.json({ ok: true, at: await storePut(reqTenant(me, isPortalTenant(req)), items, storeBy(me, req.body)) });
  } catch (e: any) { console.error("Store write error:", e); res.status(500).json({ error: "Could not save to the record store." }); }
});
app.post("/api/v1/store-beacon", express.text({ type: "*/*", limit: "25mb" }), async (req: any, res) => {
  try {
    const me = await currentUser(req); if (!me) return res.sendStatus(401);
    const body = JSON.parse(String(req.body || "{}"));
    const items = storeItems(body);
    if (items.length) await storePut(reqTenant(me, String(body.tenant || "").toLowerCase() === "portal"), items, storeBy(me, { by: "page closed" }));
    res.sendStatus(204);
  } catch { res.sendStatus(400); }
});

// What the record store holds for your practice (names, sizes, last change; no contents). For checking saves.
app.get("/api/v1/store-keys", async (req, res) => {
  try {
    const me = await currentUser(req); if (!me) return res.status(401).json({ error: "signed-out" });
    const pool = await getDb();
    const q = await pool.request().input("t", sqlLib.NVarChar(64), storeTenant(me)).input("p", sqlLib.NVarChar(64), storeTenant(me) + ":portal")
      .query(`SELECT tenant_id AS tenant, record_key AS k, LEN(value_json) AS size, CONVERT(varchar(30), updated_at, 127) + 'Z' AS at, updated_by AS [by]
              FROM app.record WHERE tenant_id IN (@t, @p) ORDER BY updated_at DESC`);
    res.json({ count: q.recordset.length, newestFirst: q.recordset });
  } catch (e: any) { console.error("Store keys error:", e); res.status(500).json({ error: "Could not read the record store." }); }
});

// Sign-in page: /login  (the old /login-test address forwards here)
app.get("/login-test", (_req, res) => res.redirect(302, "/login"));
app.get("/login", (_req, res) => {
  res.setHeader("Cache-Control", "no-store");
  res.type("html").send(`<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Sign in · Vityls</title>
<style>
 :root{--ink:#1d2b25;--muted:#5b6b64;--line:#d5ddd9;--brand:#1f4e3d;--soft:#e8f1ed;--err:#a1261b}
 *{box-sizing:border-box} body{font-family:"Segoe UI",system-ui,sans-serif;background:#f4f6f5;color:var(--ink);margin:0;padding:48px 16px}
 main{max-width:400px;margin:0 auto;background:#fff;border:1px solid var(--line);border-radius:12px;padding:28px}
 .brand{font-weight:700;font-size:18px;margin:0 0 18px} .brand span{font-weight:400;color:var(--muted)}
 h1{font-size:20px;margin:0 0 6px} p{color:var(--muted);font-size:14px;line-height:1.45;margin:0 0 16px}
 label{display:block;font-size:13px;font-weight:600;margin:14px 0 5px}
 input{width:100%;padding:10px 11px;border:1px solid #b9c6c0;border-radius:7px;font-size:16px;color:var(--ink)}
 input:focus{outline:2px solid var(--brand);outline-offset:1px;border-color:var(--brand)}
 input.code{font-size:26px;letter-spacing:8px;text-align:center;font-variant-numeric:tabular-nums}
 button{width:100%;margin-top:18px;padding:11px 16px;border:0;border-radius:7px;background:var(--brand);color:#fff;font-size:15px;font-weight:600;cursor:pointer}
 button:disabled{opacity:.6;cursor:default} button.link{background:none;color:var(--brand);width:auto;padding:0;margin-top:14px;font-weight:500;text-decoration:underline}
 .err{color:var(--err);font-size:14px;margin-top:12px;min-height:1px}
 .qr{display:flex;justify-content:center;margin:6px 0 10px} .qr svg{width:200px;height:200px}
 .key{font-family:Consolas,monospace;font-size:15px;background:var(--soft);border-radius:7px;padding:9px 11px;text-align:center;word-break:break-all}
 ol{padding-left:20px;margin:0 0 6px;color:var(--muted);font-size:14px;line-height:1.5} ol li{margin-bottom:4px}
 .who{background:var(--soft);border-radius:8px;padding:12px 14px;font-size:14px;line-height:1.5}
 a.btn{display:block;text-align:center;margin-top:16px;padding:11px;border-radius:7px;background:var(--brand);color:#fff;text-decoration:none;font-weight:600}
 .rem{display:flex;gap:9px;align-items:flex-start;font-size:14px;font-weight:500;margin:14px 0 0;color:var(--ink);cursor:pointer}
 .rem input{width:18px;height:18px;margin:1px 0 0;flex:none;accent-color:var(--brand)} .rem small{display:block;color:var(--muted);font-weight:400;font-size:13px;margin-top:2px}
 input.pin{font-size:26px;letter-spacing:10px;text-align:center}
 .links{display:flex;gap:16px;justify-content:center;flex-wrap:wrap} .links .link{margin-top:14px}
 [hidden]{display:none!important}
</style></head><body><main>
<div class="brand">Vityls <span>· test system, fictional data</span></div>

<section id="s-unlock" hidden>
 <h1>Screen locked</h1><p>Welcome back, <b id="ul-who"></b>. Enter your PIN to pick up where you left off.</p>
 <form id="f-unlock"><input id="ul-pin" class="pin" type="password" inputmode="numeric" autocomplete="off" maxlength="8" required aria-label="Your PIN">
 <button type="submit">Unlock</button><div class="err" id="e-unlock"></div></form>
 <button class="link" data-restart>Not you? Sign in as someone else</button>
</section>

<section id="s-pin" hidden>
 <h1>Set a quick-unlock PIN</h1>
 <p>After a break, the screen locks to protect patient information. With a PIN you unlock it in a second instead of signing in again. 4 to 8 digits; only you should know it.</p>
 <form id="f-pin"><label for="pn1">PIN</label><input id="pn1" class="pin" type="password" inputmode="numeric" autocomplete="new-password" maxlength="8" required>
 <label for="pn2">Type it again</label><input id="pn2" class="pin" type="password" inputmode="numeric" autocomplete="new-password" maxlength="8" required>
 <button type="submit">Save PIN</button><div class="err" id="e-pin"></div></form>
 <button class="link" id="pin-skip">Not now</button>
</section>

<section id="s-signin">
 <h1>Sign in</h1><p>Use the username and password your practice gave you.</p>
 <form id="f-signin"><label for="u">Username</label><input id="u" autocomplete="username" autocapitalize="none" required>
 <label for="p">Password</label><input id="p" type="password" autocomplete="current-password" required>
 <button type="submit">Continue</button><div class="err" id="e-signin"></div></form>
 <a href="/signup" style="display:block;text-align:center;margin-top:14px;color:var(--brand);font-size:14px">Create a new practice</a>
</section>

<section id="s-mfa" hidden>
 <h1>Enter your code</h1><p>Open Google Authenticator on your phone and type the 6-digit code for <b>Vityls Test</b>.</p>
 <form id="f-mfa"><input id="c" class="code" inputmode="numeric" autocomplete="one-time-code" maxlength="7" required aria-label="6-digit code">
 <label class="rem"><input type="checkbox" id="rm"><span>Remember this computer for 30 days<small>Don't ask for the code again on this computer. Only on a computer at your practice, never a shared or public one.</small></span></label>
 <button type="submit">Sign in</button><div class="err" id="e-mfa"></div></form>
 <button class="link" data-restart>Start over</button>
</section>

<section id="s-setup" hidden>
 <h1>Set up your phone</h1>
 <p>This is needed once. After this, signing in asks for a code from your phone.</p>
 <ol><li>Open <b>Google Authenticator</b> and tap <b>+</b>.</li>
 <li>Choose <b>Scan a QR code</b> and scan this:</li></ol>
 <div class="qr" id="qr"></div>
 <p style="margin:0 0 6px">Can't scan? Choose <b>Enter a setup key</b>, type any name, and this key (time based):</p>
 <div class="key" id="key"></div>
 <form id="f-setup"><label for="c2">Then type the 6-digit code it shows</label>
 <input id="c2" class="code" inputmode="numeric" autocomplete="one-time-code" maxlength="7" required>
 <label class="rem"><input type="checkbox" id="rm2"><span>Remember this computer for 30 days<small>Don't ask for the code again on this computer. Only on a computer at your practice, never a shared or public one.</small></span></label>
 <button type="submit">Confirm and sign in</button><div class="err" id="e-setup"></div></form>
 <button class="link" data-restart>Start over</button>
</section>

<section id="s-change" hidden>
 <h1>Choose a new password</h1><p>Your password was reset. Pick a new one with at least 10 characters.</p>
 <form id="f-change"><label for="n1">New password</label><input id="n1" type="password" autocomplete="new-password" required>
 <label for="n2">Type it again</label><input id="n2" type="password" autocomplete="new-password" required>
 <button type="submit">Save and continue</button><div class="err" id="e-change"></div></form>
</section>

<section id="s-done" hidden>
 <h1>You're signed in</h1><div class="who" id="who"></div>
 <a class="btn" id="go" href="/?practice=coastline">Open the practice</a>
 <a class="btn" href="/files" style="background:#fff;color:var(--brand);border:1px solid var(--brand)">Patient files</a>
 <a class="btn" id="mg" href="/manage" style="background:#fff;color:var(--brand);border:1px solid var(--brand)" hidden>Manage staff</a>
 <div class="links"><button class="link" id="pin-set">Set unlock PIN</button><button class="link" id="fg" hidden>Forget this computer</button><button class="link" id="lo">Sign out</button></div>
</section>

<script>
const $=id=>document.getElementById(id);
const nextUrl=(()=>{const n=new URLSearchParams(location.search).get("next")||"";return /^\\/(?![\\/\\\\])/.test(n)?n:"/?practice=coastline";})();
$("go").href=nextUrl;
function show(name){for(const s of ["signin","mfa","setup","change","done","unlock","pin"])$("s-"+s).hidden=s!==name;
  const f=document.querySelector("#s-"+name+" input");if(f)setTimeout(()=>f.focus(),30);}
async function post(url,body){const r=await fetch(url,{method:"POST",credentials:"same-origin",headers:{"Content-Type":"application/json"},body:JSON.stringify(body||{})});
  const d=await r.json().catch(()=>({}));if(!r.ok)throw new Error(d.message||"Something went wrong ("+r.status+").");return d;}
function busy(form,on){const b=form.querySelector("button[type=submit]");if(b)b.disabled=on;}
async function goStep(next){
  if(next==="mfa")return show("mfa");
  if(next==="mfa-setup"){show("setup");$("e-setup").textContent="";
    try{const r=await fetch("/api/auth/mfa/setup",{credentials:"same-origin"});const d=await r.json();if(!r.ok)throw new Error(d.message);
      $("qr").innerHTML=d.qrSvg;$("key").textContent=d.key;}catch(e){$("e-setup").textContent=e.message||"Could not load the QR code.";}
    return;}
  if(next==="change-password")return show("change");
  if(next==="done")return loadMe(true);
  show("signin");
}
// v11.5: after signing in or unlocking, go back to the page that asked (?next=), after an optional PIN step.
const goOn=()=>{const nu=new URLSearchParams(location.search).get("next");if(nu&&nextUrl===nu){location.replace(nextUrl);return true;}return false;};
let me0=null;
function showDone(){if(goOn())return;show("done");}
async function loadMe(after){const r=await fetch("/api/auth/me",{credentials:"same-origin"});const d=await r.json().catch(()=>({}));
  if(r.ok){me0=d;$("who").innerHTML="";const t=document.createElement("div");t.textContent=(d.name||d.username)+" ("+d.username+")";
    const p=document.createElement("div");p.textContent="Practice "+d.practice+" · "+(d.practiceName||"");$("who").append(t,p);$("mg").hidden=!d.isManager;
    $("pin-set").textContent=d.hasPin?"Change unlock PIN":"Set unlock PIN";$("fg").hidden=!d.deviceRemembered;
    if(after&&!d.hasPin&&!sessionStorage.getItem("vityls:pin-later"))return show("pin");
    if(after)return showDone();show("done");}
  else if(d.next==="unlock"){$("ul-who").textContent=d.name||d.username||"";show("unlock");}
  else goStep(d.next||"signin");}
function wire(formId,errId,fn){$(formId).addEventListener("submit",async ev=>{ev.preventDefault();$(errId).textContent="";busy(ev.target,true);
  try{await fn();}catch(e){$(errId).textContent=e.message;}finally{busy(ev.target,false);}});}
wire("f-signin","e-signin",async()=>{const d=await post("/api/auth/login",{username:$("u").value,password:$("p").value});$("p").value="";goStep(d.next);});
wire("f-mfa","e-mfa",async()=>{try{const d=await post("/api/auth/mfa/verify",{code:$("c").value,remember:$("rm").checked});goStep(d.next);}finally{$("c").value="";}});
wire("f-setup","e-setup",async()=>{try{const d=await post("/api/auth/mfa/verify",{code:$("c2").value,remember:$("rm2").checked});goStep(d.next);}finally{$("c2").value="";}});
wire("f-unlock","e-unlock",async()=>{try{await post("/api/auth/unlock",{pin:$("ul-pin").value});await loadMe(true);}
  catch(e){if(/Sign in again/.test(e.message))setTimeout(()=>show("signin"),1800);throw e;}finally{$("ul-pin").value="";}});
wire("f-pin","e-pin",async()=>{if($("pn1").value!==$("pn2").value)throw new Error("The two PINs don't match.");
  try{await post("/api/auth/pin",{pin:$("pn1").value});}finally{$("pn1").value=$("pn2").value="";}if(me0)me0.hasPin=true;$("pin-set").textContent="Change unlock PIN";showDone();});
$("pin-skip").addEventListener("click",()=>{sessionStorage.setItem("vityls:pin-later","1");showDone();});
$("pin-set").addEventListener("click",()=>show("pin"));
$("fg").addEventListener("click",async()=>{await post("/api/auth/forget-device").catch(()=>{});$("fg").hidden=true;});
wire("f-change","e-change",async()=>{if($("n1").value!==$("n2").value)throw new Error("The two passwords don't match.");
  const d=await post("/api/auth/change-password",{newPassword:$("n1").value});$("n1").value=$("n2").value="";goStep(d.next);});
document.querySelectorAll("[data-restart]").forEach(b=>b.addEventListener("click",async()=>{await post("/api/auth/logout").catch(()=>{});show("signin");}));
$("lo").addEventListener("click",async()=>{await post("/api/auth/logout").catch(()=>{});show("signin");});
loadMe();
</script></main></body></html>`);
});

// ---------------------------------------------------------------------------
// Kevin (v11.5): create a new practice from scratch (/signup).
//   POST /api/signup/practice  -> creates dbo.Organizations + dbo.Sites (main location) + the first administrator
//                                  (dbo.Users + ORG_ADMIN in dbo.UserRoles), all in one transaction, and records the
//                                  practice's edition (ASC / SURGERY / MEDICAL) in app.record as "server:org-profile".
//   The new administrator then signs in at /login, sets up the authenticator app (MFA) and opens an EMPTY practice.
// Protected by the SIGNUP_CODE app setting: without it, sign-up is switched off. Test system, fictional data only.
// Columns this server does not know about: if dbo.Organizations or dbo.Sites has a required column without a default,
// it is filled only when its meaning is obvious from its name (code, name, time zone, status, dates, flags); otherwise
// sign-up stops and names the column, so nothing half-made is ever saved.
// ---------------------------------------------------------------------------
const EDITIONS = ["ASC", "SURGERY", "MEDICAL"] as const;
type OrgEdition = typeof EDITIONS[number];
const EDITION_NAME: Record<OrgEdition, string> = { ASC: "Ambulatory surgery center", SURGERY: "Surgical practice", MEDICAL: "Medical practice" };
const PROFILE_KEY = "server:org-profile";
const signupTries = new Map<string, { n: number; first: number }>();
function signupLimited(req: any): boolean {
  const ip = String(req.headers["x-forwarded-for"] || req.socket?.remoteAddress || "").split(",")[0].trim();
  const now = Date.now(); const t = signupTries.get(ip);
  if (!t || now - t.first > 15 * 60000) { signupTries.set(ip, { n: 1, first: now }); return false; }
  t.n++; return t.n > 8;
}
function sameSecret(a: string, b: string): boolean {
  const x = sha256(a), y = sha256(b); return crypto.timingSafeEqual(x, y);
}
async function orgProfile(pool: any, orgId: any): Promise<{ edition?: OrgEdition; createdAt?: string } | null> {
  try {
    const r = await pool.request().input("t", sqlLib.NVarChar(64), `org-${orgId}`).input("k", sqlLib.NVarChar(400), PROFILE_KEY)
      .query(`SELECT TOP 1 value_json AS v FROM app.record WHERE tenant_id = @t AND record_key = @k`);
    return r.recordset[0]?.v ? JSON.parse(r.recordset[0].v) : null;
  } catch { return null; }
}
/** Required columns (NOT NULL, no default, not identity/computed) of a table. */
async function requiredColumns(tx: any, table: string): Promise<{ name: string; type: string }[]> {
  const r = await new sqlLib.Request(tx).input("t", table).query(
    `SELECT c.name, t.name AS type FROM sys.columns c JOIN sys.types t ON t.user_type_id = c.user_type_id
     WHERE c.object_id = OBJECT_ID(@t) AND c.is_nullable = 0 AND c.is_identity = 0 AND c.is_computed = 0 AND c.default_object_id = 0`);
  return r.recordset;
}
/** INSERT with the known values, plus any required column whose value is obvious from its name. Returns the new id. */
async function insertRow(tx: any, table: string, idCol: string, known: Record<string, any>, hints: { code: string; name: string }) {
  // Only columns that really exist in this database (the layout was made outside this repo).
  const existing = (await new sqlLib.Request(tx).input("t", table).query(`SELECT name FROM sys.columns WHERE object_id = OBJECT_ID(@t)`)).recordset.map((r: any) => String(r.name));
  if (!existing.length) throw Object.assign(new Error(`${table} was not found`), { schema: true });
  const values: Record<string, any> = {};
  for (const [k, v] of Object.entries(known)) { const col = existing.find(c => c.toLowerCase() === k.toLowerCase()); if (col) values[col] = v; }
  const exprs: Record<string, string> = {};
  const missing: string[] = [];
  for (const c of await requiredColumns(tx, table)) {
    if (c.name in values) continue;
    const n = c.name.toLowerCase(), t = c.type.toLowerCase();
    if (/char|text/.test(t)) {
      if (/code/.test(n)) values[c.name] = hints.code;
      else if (/name/.test(n)) values[c.name] = hints.name;
      else if (/time.?zone|tz/.test(n)) values[c.name] = "America/Los_Angeles";
      else if (/status/.test(n)) values[c.name] = "ACTIVE";
      else if (/country/.test(n)) values[c.name] = "US";
      else missing.push(`${c.name} (${c.type})`);
    } else if (/date|time/.test(t)) exprs[c.name] = "SYSUTCDATETIME()";
    else if (t === "bit") values[c.name] = /active|enabled/.test(n) ? 1 : 0;
    else if (t === "uniqueidentifier") exprs[c.name] = "NEWID()";
    else missing.push(`${c.name} (${c.type})`);
  }
  if (missing.length) throw Object.assign(new Error(`${table} needs a value for: ${missing.join(", ")}`), { schema: true });
  const cols = Object.keys(values), ex = Object.keys(exprs);
  const rq = new sqlLib.Request(tx); cols.forEach((c, i) => rq.input(`v${i}`, values[c]));
  const r = await rq.query(`INSERT ${table} (${[...cols, ...ex].map(c => `[${c}]`).join(", ")}) OUTPUT inserted.[${idCol}] AS id
                            VALUES (${[...cols.map((_, i) => `@v${i}`), ...ex.map(c => exprs[c])].join(", ")})`);
  return r.recordset[0].id;
}
function orgCodeFrom(name: string): string {
  const words = name.toUpperCase().replace(/[^A-Z0-9 ]/g, " ").split(/\s+/).filter(Boolean)
    .filter(w => !["THE", "OF", "AND", "INC", "LLC", "PC", "PA", "MD", "GROUP"].includes(w));
  return (words.join("").slice(0, 12) || "PRACTICE");
}

app.post("/api/signup/practice", async (req, res) => {
  const want = process.env.SIGNUP_CODE || "";
  if (!want) return res.status(403).json({ status: "error", message: "Creating new practices is switched off on this server (no SIGNUP_CODE app setting)." });
  if (signupLimited(req)) return res.status(429).json({ status: "error", message: "Too many tries. Wait 15 minutes and try again." });
  const b = req.body || {};
  const code = String(b.signupCode || "");
  if (!code || !sameSecret(code, want)) return res.status(403).json({ status: "error", message: "That sign-up code is not right." });
  const practiceName = String(b.practiceName || "").trim().replace(/\s+/g, " ").slice(0, 150);
  const edition = String(b.edition || "").toUpperCase() as OrgEdition;
  const first = String(b.firstName || "").trim().slice(0, 100), last = String(b.lastName || "").trim().slice(0, 100);
  const email = String(b.email || "").trim().slice(0, 254);
  const username = String(b.username || "").trim().toLowerCase();
  const password = String(b.password || "");
  if (practiceName.length < 3) return res.status(400).json({ status: "error", message: "Enter the practice name." });
  if (!EDITIONS.includes(edition)) return res.status(400).json({ status: "error", message: "Choose the type of practice." });
  if (!first || !last) return res.status(400).json({ status: "error", message: "Enter your first and last name." });
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) return res.status(400).json({ status: "error", message: "Enter a valid email address." });
  if (!/^[a-z0-9._-]{3,50}$/.test(username)) return res.status(400).json({ status: "error", message: "Username: 3-50 letters, numbers, dot, dash or underscore." });
  const pwBad = passwordProblem(password, username); if (pwBad) return res.status(400).json({ status: "error", message: pwBad });
  let pool: any;
  try { pool = await getDb(); } catch (e: any) { return res.status(500).json({ status: "error", message: e?.message || "Database not reachable." }); }
  const tx = new sqlLib.Transaction(pool);
  try {
    await tx.begin();
    const taken = (await new sqlLib.Request(tx).input("u", username).query(`SELECT 1 AS x FROM dbo.Users WITH (UPDLOCK, HOLDLOCK) WHERE Username = @u`)).recordset.length;
    if (taken) { await tx.rollback(); return res.status(409).json({ status: "error", message: "That username is already used. Try another." }); }
    const dupName = (await new sqlLib.Request(tx).input("n", practiceName).query(`SELECT 1 AS x FROM dbo.Organizations WHERE OrganizationName = @n AND IsActive = 1`)).recordset.length;
    if (dupName) { await tx.rollback(); return res.status(409).json({ status: "error", message: "A practice with that name already exists. Add the city or a number to tell them apart." }); }
    const base = orgCodeFrom(practiceName); let orgCode = base;
    for (let i = 2; (await new sqlLib.Request(tx).input("c", orgCode).query(`SELECT 1 AS x FROM dbo.Organizations WHERE OrganizationCode = @c`)).recordset.length; i++) orgCode = `${base.slice(0, 10)}${i}`;
    const orgId = await insertRow(tx, "dbo.Organizations", "OrganizationId",
      { OrganizationCode: orgCode, OrganizationName: practiceName, IsActive: 1 }, { code: orgCode, name: practiceName });
    await insertRow(tx, "dbo.Sites", "SiteId",
      { OrganizationId: orgId, SiteCode: `${orgCode}-1`, SiteName: `${practiceName} (main location)`, IsActive: 1 }, { code: `${orgCode}-1`, name: practiceName });
    const u = await new sqlLib.Request(tx).input("org", String(orgId)).input("fn", first).input("ln", last).input("u", username).input("em", email)
      .input("ph", hashPassword(password)).input("role", "ORG_ADMIN")
      .query(`DECLARE @roleId bigint = (SELECT TOP 1 RoleId FROM dbo.Roles WHERE RoleCode = @role AND IsActive = 1
                                          AND (OrganizationId = @org OR OrganizationId IS NULL) ORDER BY OrganizationId DESC);
              IF @roleId IS NULL THROW 50001, 'The ORG_ADMIN role is missing in dbo.Roles', 1;
              DECLARE @new TABLE (UserId bigint);
              INSERT dbo.Users (OrganizationId, FirstName, LastName, Username, Email, PasswordHash, MustChangePassword, PasswordChangedAt)
              OUTPUT inserted.UserId INTO @new
              VALUES (@org, @fn, @ln, @u, @em, @ph, 0, SYSUTCDATETIME());
              INSERT dbo.UserRoles (UserId, RoleId) SELECT UserId, @roleId FROM @new;
              SELECT UserId FROM @new;`);
    const userId = u.recordset[0].UserId;
    const profile = JSON.stringify({ edition, practiceName, createdAt: new Date().toISOString(), createdBy: username, via: "signup" });
    await new sqlLib.Request(tx).input("t", sqlLib.NVarChar(64), `org-${orgId}`).input("k", sqlLib.NVarChar(400), PROFILE_KEY)
      .input("v", sqlLib.NVarChar(sqlLib.MAX), profile).input("b", sqlLib.NVarChar(200), `${username} · sign-up`)
      .query(`INSERT INTO app.record (tenant_id, record_key, value_json, updated_at, updated_by) VALUES (@t, @k, @v, SYSUTCDATETIME(), @b);
              INSERT INTO app.record_history (tenant_id, record_key, value_json, changed_at, changed_by) VALUES (@t, @k, @v, SYSUTCDATETIME(), @b);`);
    await new sqlLib.Request(tx).input("org", String(orgId)).input("uid", String(userId)).input("act", "PRACTICE_CREATED")
      .input("desc", `New ${EDITION_NAME[edition].toLowerCase()} "${practiceName}" (${orgCode}) created with administrator ${username}`.slice(0, 1000))
      .input("ip", String(req.headers["x-forwarded-for"] || req.socket?.remoteAddress || "").slice(0, 64))
      .input("ua", String(req.headers["user-agent"] || "").slice(0, 1000))
      .query(`INSERT dbo.AuditEvents (OrganizationId, UserId, EntityType, EntityId, ActionType, Description, SourceSystem, IpAddress, UserAgent)
              VALUES (@org, @uid, N'User', @uid, @act, @desc, N'vityls-portal-test', @ip, @ua)`);
    await tx.commit();
    res.json({ status: "ok", practice: orgCode, practiceName, edition, username });
  } catch (e: any) {
    try { await tx.rollback(); } catch { /* */ }
    console.error("Sign-up error:", e);
    res.status(500).json({ status: "error", message: e?.schema ? `The database needs one more value: ${e.message}. Nothing was saved.` : "Could not create the practice. Nothing was saved. Check the app log." });
  }
});

app.get("/signup", (_req, res) => {
  res.setHeader("Cache-Control", "no-store");
  res.type("html").send(`<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Create a practice · Vityls</title>
<style>
 :root{--ink:#1d2b25;--muted:#5b6b64;--line:#d5ddd9;--brand:#1f4e3d;--soft:#e8f1ed;--err:#a1261b}
 *{box-sizing:border-box} body{font-family:"Segoe UI",system-ui,sans-serif;background:#f4f6f5;color:var(--ink);margin:0;padding:40px 16px}
 main{max-width:480px;margin:0 auto;background:#fff;border:1px solid var(--line);border-radius:12px;padding:28px}
 .brand{font-weight:700;font-size:18px;margin:0 0 18px} .brand span{font-weight:400;color:var(--muted)}
 h1{font-size:20px;margin:0 0 6px} h2{font-size:15px;margin:22px 0 2px} p{color:var(--muted);font-size:14px;line-height:1.45;margin:0 0 12px}
 label{display:block;font-size:13px;font-weight:600;margin:12px 0 5px} .hint{font-weight:400;color:var(--muted)}
 input{width:100%;padding:10px 11px;border:1px solid #b9c6c0;border-radius:7px;font-size:16px;color:var(--ink)}
 input:focus{outline:2px solid var(--brand);outline-offset:1px;border-color:var(--brand)}
 .row{display:grid;grid-template-columns:1fr 1fr;gap:10px}
 .ed{display:grid;gap:8px;margin-top:6px} .ed label{display:flex;gap:10px;align-items:flex-start;border:1px solid var(--line);border-radius:9px;padding:10px 12px;margin:0;font-weight:600;cursor:pointer}
 .ed label:has(input:checked){border-color:var(--brand);background:var(--soft)} .ed input{width:auto;margin-top:3px} .ed small{display:block;font-weight:400;color:var(--muted);font-size:13px;margin-top:2px}
 button{width:100%;margin-top:20px;padding:11px 16px;border:0;border-radius:7px;background:var(--brand);color:#fff;font-size:15px;font-weight:600;cursor:pointer}
 button:disabled{opacity:.6;cursor:default}
 .err{color:var(--err);font-size:14px;margin-top:12px;min-height:1px}
 .ok{background:var(--soft);border-radius:9px;padding:14px;font-size:14px;line-height:1.55}
 a.btn{display:block;text-align:center;margin-top:16px;padding:11px;border-radius:7px;background:var(--brand);color:#fff;text-decoration:none;font-weight:600}
 .alt{display:block;text-align:center;margin-top:14px;color:var(--brand);font-size:14px}
 [hidden]{display:none!important}
</style></head><body><main>
<div class="brand">Vityls <span>· test system, fictional data</span></div>
<section id="s-form">
 <h1>Create a new practice</h1>
 <p>This sets up an empty practice and makes you its administrator. You'll add providers, staff, rooms and forms after you sign in.</p>
 <form id="f" novalidate>
  <label for="sc">Sign-up code <span class="hint">(from the Vityls owner)</span></label><input id="sc" type="password" autocomplete="off" required>
  <h2>Practice</h2>
  <label for="pn">Practice name</label><input id="pn" autocomplete="organization" required maxlength="150" placeholder="e.g. Pacific Coast Surgery Center">
  <label>Type of practice</label>
  <div class="ed" role="radiogroup">
   <label><input type="radio" name="ed" value="ASC" checked><span>Ambulatory surgery center (ASC)<small>Operating rooms, pre-op, anesthesia, PACU and the day-of-surgery stations.</small></span></label>
   <label><input type="radio" name="ed" value="SURGERY"><span>Surgical practice<small>A surgeon's office: consults, surgical planning, photos, quotes and surgery booking.</small></span></label>
   <label><input type="radio" name="ed" value="MEDICAL"><span>Medical practice<small>Internal medicine or family practice: visits, diagnoses, care plans and labs.</small></span></label>
  </div>
  <h2>You, the administrator</h2>
  <div class="row"><div><label for="fn">First name</label><input id="fn" autocomplete="given-name" required></div>
   <div><label for="ln">Last name</label><input id="ln" autocomplete="family-name" required></div></div>
  <label for="em">Email</label><input id="em" type="email" autocomplete="email" required>
  <label for="un">Username <span class="hint">(3-50 letters, numbers, dot, dash)</span></label><input id="un" autocomplete="username" autocapitalize="none" required>
  <label for="p1">Password <span class="hint">(at least 10 characters)</span></label><input id="p1" type="password" autocomplete="new-password" required>
  <label for="p2">Type it again</label><input id="p2" type="password" autocomplete="new-password" required>
  <button type="submit">Create the practice</button><div class="err" id="err" role="alert"></div>
 </form>
 <a class="alt" href="/login">Already have an account? Sign in</a>
</section>
<section id="s-done" hidden>
 <h1>Your practice is ready</h1>
 <div class="ok" id="ok"></div>
 <p style="margin-top:14px">Next, sign in with your new username and password. The first time, you'll set up <b>Google Authenticator</b> (or any authenticator app) on your phone for the 6-digit sign-in code.</p>
 <a class="btn" href="/login?next=%2F">Sign in</a>
</section>
<script>
const $=id=>document.getElementById(id);
$("f").addEventListener("submit",async ev=>{ev.preventDefault();$("err").textContent="";
  const btn=ev.target.querySelector("button");
  if($("p1").value!==$("p2").value){$("err").textContent="The two passwords don't match.";return;}
  for(const id of ["sc","pn","fn","ln","em","un","p1"])if(!$(id).value.trim()){$("err").textContent="Please fill in every field.";$(id).focus();return;}
  btn.disabled=true;
  try{const body={signupCode:$("sc").value,practiceName:$("pn").value,edition:document.querySelector("input[name=ed]:checked").value,
      firstName:$("fn").value,lastName:$("ln").value,email:$("em").value,username:$("un").value,password:$("p1").value};
    const r=await fetch("/api/signup/practice",{method:"POST",credentials:"same-origin",headers:{"Content-Type":"application/json"},body:JSON.stringify(body)});
    const d=await r.json().catch(()=>({}));if(!r.ok)throw new Error(d.message||"Something went wrong ("+r.status+").");
    $("p1").value=$("p2").value=$("sc").value="";
    const ok=$("ok");ok.textContent="";
    const add=(k,v)=>{const line=document.createElement("div");const b=document.createElement("b");b.textContent=k+": ";line.append(b,document.createTextNode(v));ok.append(line);};
    add("Practice",d.practiceName);add("Type",{ASC:"Ambulatory surgery center",SURGERY:"Surgical practice",MEDICAL:"Medical practice"}[d.edition]);
    add("Practice code",d.practice);add("Your username",d.username);
    $("s-form").hidden=true;$("s-done").hidden=false;
  }catch(e){$("err").textContent=e.message;}finally{btn.disabled=false;}});
</script></main></body></html>`);
});

// Health check

// ---------------------------------------------------------------------------
// v11.6 · Vityls owner console (Kevin and Henry). Only usernames listed in the OWNER_USERNAMES app setting
// (comma separated) can use these routes, after the normal sign-in with password + authenticator code.
// Never returns patient data: counts only. Owner data (fee schedule, subscriptions, payments, vendor settings)
// lives in app.record under the tenant "vityls-owner"; every change is kept in app.record_history.
// Vendor secrets are never stored here: a vendor row names the App Service setting (or Key Vault reference)
// that holds the secret, and the console only shows whether that setting exists.
const OWNER_TENANT = "vityls-owner";
const OWNER_KEYS = ["fees", "subs", "payments", "vendors"];
const ownerNames = () => String(process.env.OWNER_USERNAMES || "").split(",").map(x => x.trim().toLowerCase()).filter(Boolean);
async function requireOwner(req: any, res: any): Promise<any | null> {
  const me = await currentUser(req);
  if (!me) { res.status(401).json({ status: "signed-out", message: "Sign in at /login first." }); return null; }
  if (!ownerNames().length) { res.status(403).json({ status: "error", message: "No owners are set on this server. Add the OWNER_USERNAMES app setting (for example: kevin,henry) and restart." }); return null; }
  if (!ownerNames().includes(String(me.Username).toLowerCase())) { res.status(403).json({ status: "error", message: "This account is not a Vityls owner." }); return null; }
  return me;
}
const SETTING_NAME = /^[A-Z][A-Z0-9_]{2,63}$/;
app.get("/api/owner/me", async (req, res) => {
  try { const me = await currentUser(req); res.json({ owner: !!me && ownerNames().includes(String(me.Username).toLowerCase()) }); }
  catch { res.json({ owner: false }); }
});
app.get("/api/owner/practices", async (req, res) => {
  const me = await requireOwner(req, res); if (!me) return;
  try {
    const pool = await getDb();
    const r = await pool.request().query(`
      SELECT o.OrganizationId, o.OrganizationCode, o.OrganizationName, o.IsActive, CONVERT(varchar(30), o.CreatedAt, 127) AS CreatedAt,
             (SELECT COUNT(*) FROM dbo.Users u WHERE u.OrganizationId = o.OrganizationId AND u.IsActive = 1) AS UserCount,
             (SELECT COUNT(*) FROM dbo.Providers p WHERE p.OrganizationId = o.OrganizationId AND p.IsActive = 1) AS ProviderCount,
             (SELECT COUNT(*) FROM dbo.Patients p WHERE p.OrganizationId = o.OrganizationId AND p.IsActive = 1) AS PatientCount,
             (SELECT CONVERT(varchar(30), MAX(u.LastLoginAt), 127) FROM dbo.Users u WHERE u.OrganizationId = o.OrganizationId) AS LastLoginAt
      FROM dbo.Organizations o
      ORDER BY o.OrganizationName`);
    const prof = await pool.request().input("k", sqlLib.NVarChar(400), PROFILE_KEY)
      .query(`SELECT tenant_id AS t, value_json AS v FROM app.record WHERE record_key = @k`);
    const byOrg: Record<string, any> = {};
    prof.recordset.forEach((x: any) => { byOrg[String(x.t).replace(/^org-/, "")] = safeJson(x.v) || {}; });
    const practices = r.recordset.map((o: any) => ({ id: String(o.OrganizationId), code: o.OrganizationCode, name: o.OrganizationName, active: !!o.IsActive,
      createdAt: byOrg[String(o.OrganizationId)]?.createdAt || (o.CreatedAt ? `${o.CreatedAt}Z`.replace(/ZZ$/, "Z") : null),
      edition: byOrg[String(o.OrganizationId)]?.edition || null, users: o.UserCount || 0, providers: o.ProviderCount || 0, patients: o.PatientCount || 0,
      lastLoginAt: o.LastLoginAt ? `${o.LastLoginAt}Z`.replace(/ZZ$/, "Z") : null }));
    res.json({ status: "ok", practices });
  } catch (e: any) { console.error("Owner practices error:", e); res.status(500).json({ status: "error", message: e?.message || "Could not read practices." }); }
});
app.get("/api/owner/data", async (req, res) => {
  const me = await requireOwner(req, res); if (!me) return;
  try {
    const rows = await storeList(OWNER_TENANT);
    const data: Record<string, any> = {}; const at: Record<string, any> = {};
    rows.forEach((x: any) => { if (OWNER_KEYS.includes(x.k)) { data[x.k] = safeJson(x.v); at[x.k] = { at: x.at, by: x.by }; } });
    const names = new Set<string>((Array.isArray(data.vendors) ? data.vendors : []).map((v: any) => String(v?.secretSetting || "")).filter((n: string) => SETTING_NAME.test(n)));
    ["GEMINI_API_KEY", "SIGNUP_CODE", "MFA_KEY", "STORAGE_KEY"].forEach(n => names.add(n));
    const envPresent: Record<string, boolean> = {}; names.forEach(n => { envPresent[n] = !!process.env[n]; });
    res.json({ status: "ok", data, at, envPresent, owners: ownerNames() });
  } catch (e: any) { console.error("Owner data error:", e); res.status(500).json({ status: "error", message: e?.message || "Could not read owner data." }); }
});
app.put("/api/owner/data", async (req, res) => {
  const me = await requireOwner(req, res); if (!me) return;
  const k = String(req.body?.key || ""); const v = req.body?.value;
  if (!OWNER_KEYS.includes(k)) return res.status(400).json({ status: "error", message: "Unknown owner record." });
  if (k === "vendors") {
    const list = Array.isArray(v) ? v : [];
    for (const x of list) {
      if (x?.secretSetting && !SETTING_NAME.test(String(x.secretSetting))) return res.status(400).json({ status: "error", message: `"${String(x.secretSetting).slice(0, 12)}…" is not a setting name. Enter the NAME of the App Service setting (like FINIX_API_KEY), never the key itself.` });
      if (/(sk|pk|rk)_(live|test)_|-----BEGIN|AKIA[0-9A-Z]{12}/.test(JSON.stringify(x))) return res.status(400).json({ status: "error", message: "That looks like a secret key. Put secrets in the App Service settings or Key Vault, and enter only the setting name here." });
    }
  }
  try {
    const json = JSON.stringify(v ?? null); if (json.length > 2_000_000) return res.status(413).json({ status: "error", message: "Too large." });
    const at = await storePut(OWNER_TENANT, [{ k, v: json }], `${me.Username} · owner console`);
    res.json({ status: "ok", at });
  } catch (e: any) { console.error("Owner save error:", e); res.status(500).json({ status: "error", message: e?.message || "Could not save." }); }
});

app.get("/api/health", (req, res) => {
  res.json({ status: "ok", timestamp: new Date().toISOString() });
});

// Nightingale AI Chat Endpoint
app.post("/api/ai/chat", async (req, res) => {
  try {
    const { message, context } = req.body;
    const ai = await getGenAI();

    if (!ai) {
      // Intelligent fallback response if API key is not yet set
      return res.json({
        reply: `[Nightingale AI Local Intelligence] Analyzing schedule context: ${message}\n\nKey Recommendation: Patricia DePoli's EKG is pending for her 8:00 AM Blepharoplasty in OR 1. I recommend fast-tracking cardiology sign-off or prepping backup clearance to prevent a 25-minute turnaround delay for Sophia Diaz at 8:45 AM.`,
        sources: ["Pre-Op Clearance Protocol", "OR 1 Schedule Map"],
      });
    }

    const systemInstruction = `You are Nightingale AI, an advanced AI Clinical & Operational Assistant for the active Vityls practice.
You specialize in Outpatient Surgical Center (ASC) office efficiency, patient arrival prioritization, pre-op readiness tracking, and OR turnover optimization.
Provide concise, actionable, professional advice for surgical coordinators, charge nurses, and practice owners.
When given schedule context, highlight potential bottlenecks, missing labs/EKG/consents, and room allocation risks.`;

    const prompt = `Schedule Context: ${JSON.stringify(context || {})}\n\nUser Question: ${message}`;

    const response = await ai.models.generateContent({
      model: "gemini-3.6-flash",
      contents: prompt,
      config: {
        systemInstruction,
        temperature: 0.7,
      },
    });

    res.json({
      reply: response.text || "No response generated.",
      sources: ["Nightingale Clinical Rules Engine", "Vityls EHR"],
    });
  } catch (error: any) {
    console.error("AI Chat Error:", error);
    res.status(500).json({ error: error.message || "Failed to generate response" });
  }
});

// AI Schedule Bottleneck & Prioritization Analyzer
app.post("/api/ai/analyze-bottlenecks", async (req, res) => {
  try {
    const { schedule } = req.body;
    const ai = await getGenAI();

    if (!ai) {
      // Rich default AI analysis output
      return res.json({
        bottlenecks: [
          {
            id: "b1",
            patientId: "113850",
            patientName: "Patricia DePoli",
            severity: "high",
            title: "Missing EKG & Pre-Op Photo Review (8:00 AM Case - OR 1)",
            impact: "High risk of 20-30 min OR 1 start delay affecting subsequent cases.",
            recommendation: "Immediate phone outreach to Beverly Hills Cardiology for faxed EKG. Notify Dr. Guy Massry.",
            actionType: "REQUEST_EKG",
          },
          {
            id: "b2",
            patientId: "114202",
            patientName: "Danielle Weaver",
            severity: "medium",
            title: "Pre-Op Transport Prep Ready (7:00 AM Case - OR 1)",
            impact: "Patient cleared; delay in transfer to OR 1 will reduce OR turnover buffer.",
            recommendation: "Initiate Pre-Op Bay 2 transport call to surgical team.",
            actionType: "TRANSPORT_OR",
          },
        ],
        prioritizedArrivals: [
          { patientId: "114202", name: "Danielle Weaver", priorityRank: 1, readinessScore: 98, status: "IN_PRE_OP" },
          { patientId: "113850", name: "Patricia DePoli", priorityRank: 2, readinessScore: 65, status: "ARRIVING_NEEDS_ATTENTION" },
          { patientId: "114091", name: "Sophia Diaz", priorityRank: 3, readinessScore: 95, status: "ON_SCHEDULE" },
          { patientId: "114036", name: "Holly Radom", priorityRank: 4, readinessScore: 100, status: "ON_SCHEDULE" },
          { patientId: "113974", name: "Ashlee Fishman", priorityRank: 5, readinessScore: 92, status: "IMPLANT_VERIFIED" },
        ],
      });
    }

    const prompt = `Analyze this ASC surgery schedule and identify workflow bottlenecks, arrival priorities, and risk mitigations.
Schedule Data: ${JSON.stringify(schedule)}
Return JSON with format:
{
  "bottlenecks": [{"id": "b1", "patientName": "...", "severity": "high|medium|low", "title": "...", "impact": "...", "recommendation": "...", "actionType": "..."}],
  "prioritizedArrivals": [{"patientId": "...", "name": "...", "priorityRank": 1, "readinessScore": 85, "status": "..."}]
}`;

    const response = await ai.models.generateContent({
      model: "gemini-3.6-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
      },
    });

    const parsed = JSON.parse(response.text || "{}");
    res.json(parsed);
  } catch (err: any) {
    console.error("Bottleneck Analysis Error:", err);
    res.status(500).json({ error: "Failed to perform AI analysis" });
  }
});

// Vite server in dev or static files in production
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const { createServer: createViteServer } = await import("vite");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    // Works both when server.cjs sits inside the deployed dist folder (Azure)
    // and when run from the project folder as dist/server.cjs.
    const here = typeof __dirname !== "undefined" ? __dirname : process.cwd();
    const distPath = fs.existsSync(path.join(here, "index.html")) ? here : path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Office Intelligence Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
