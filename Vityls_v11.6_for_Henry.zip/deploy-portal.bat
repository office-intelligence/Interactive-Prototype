@echo off
rem Double-click (or run) to build, zip and deploy the Vityls portal. Add -NoDeploy to only make the zip.
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0deploy-portal.ps1" %*
pause
