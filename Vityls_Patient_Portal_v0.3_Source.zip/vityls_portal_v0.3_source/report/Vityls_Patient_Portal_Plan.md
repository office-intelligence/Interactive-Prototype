# Vityls Patient Portal: plan (v0.3)

Branch `portal` (from `core-modules-v1.0`). The Portal is a separate patient-facing **app on Vityls Core**, registered in the Core module registry as `patient-portal`. The practice-side `portal-link` module is what connects a practice to it (Architecture doc, section 9). Every connection stays **simulated until a BAA is signed**. All data in the test build is fictitious.

## 1. What the Portal is
- **A patient-owned account, independent of any provider.** A patient signs up with an email and password and gets a Vityls patient ID. No practice invitation is needed. Practices that use Vityls connect to that account through a consent link (`patient_practice_links`). The patient can grant scopes and revoke them at any time.
- **An AI-first health journal.** Home is a Nightingale conversation, not a menu. She reads what comes in (labs, documents, visit notes), explains it in plain language, keeps the patient's medication, allergy, history and symptom record current, and helps the patient prepare for visits.
- **Goal: patients engaged in their own care.** Nightingale educates, organizes and asks questions. She **never diagnoses, never gives go/no-go advice, and never signs anything**. When something matters she says "this is worth asking your doctor about" and offers to draft the question.

## 2. Plans: free and paid
| Free (always) | Paid (Portal Plus) |
|---|---|
| Account, records, documents, labs, meds, allergies | Wearables and home devices (Apple Health, Fitbit, BP cuffs, glucose meters) |
| Plain-language explanations of labs and documents (fair-use monthly limit) | Unlimited explanations and heavy AI (whole-record review, long-term trend analysis) |
| Simple tasks: reminders, refill requests, questions to the doctor | Report drafting: visit-prep summaries, symptom diaries, a health summary for a new doctor |
| Connect my doctor, records requests, provider upload links | Family / caregiver profiles (later) |
| **Anything a practice initiates**: forms, check-in, messages, results, bills, reminders | — |

**Rule: nothing a practice initiates is ever paywalled.** Patient entitlements use the Core model (`off / trial / active / expired`) on the patient account, with a free trial of Plus.

## 3. Nightingale proactive engagement
Nightingale starts conversations from the data. Each question is a card on Home with one-tap answers, and every card can be dismissed.
- **New abnormal lab, then ask about medications:** "Now that I've seen your latest labs, tell me about your medications so I can check whether any could explain the abnormal results." The answer is added to the medication list. She then explains, in general terms, which medicines are commonly known to affect that test, and drafts a question for the doctor.
- **Missing allergies:** "I don't have your allergies yet. Do you have any allergies to medicines, foods or latex?" "No known allergies" is a valid answer and is recorded as verified by the patient.
- **Missing medications, history or surgeries:** short follow-ups, one at a time.
- **New document:** "Your MRI report arrived. Want a plain-language summary?"
- **Upcoming visit:** "Your visit with Dr. Patel is Friday. Want me to list your questions?"
- **Symptoms check-in:** after a new symptom is logged, she follows up a few days later ("Is the headache better, the same, or worse?").
- **Guardrails:** no diagnosis and no "safe/unsafe to do X." Red-flag words (chest pain, trouble breathing, and similar) always get "call 911 or your doctor now." Every claim is attributed to the source document.

## 4. Receiving records from providers that aren't on Vityls (4 layers)
The key idea is that the **patient pulls their own records** under the HIPAA right of access and the 21st Century Cures Act rule against information blocking. The provider doesn't have to push anything.

1. **"Connect my doctor": patient-directed SMART on FHIR.** Certified EMRs must offer patient-access FHIR APIs (ONC (g)(10) / Cures Act). The patient searches for their health system, signs in with their own portal login (Epic MyChart, Oracle Health/Cerner, athenahealth and others), and approves. Vityls imports Patient, AllergyIntolerance, MedicationRequest/Statement, Condition, Observation (labs, vitals), DiagnosticReport, DocumentReference and Encounter, then refreshes on a schedule. This covers most hospitals and large groups with no call to the practice. Vityls registers as a patient-facing app in Epic's developer program (open.epic) and athena's developer portal, and with Oracle Health.
2. **Patient-directed HIPAA right-of-access requests by fax or Direct.** For offices with no API, Vityls generates a signed right-of-access request from the patient. This is the patient's own request, not a practice release form. It goes out by fax or email with a **unique return inbox for that one request** (an inbound fax number plus a Direct secure-mail address, both carrying a request ID). Incoming records are matched to the request, auto-filed to Documents, classified by type and explained by Nightingale. The 30-day legal clock is tracked, with a reminder to the patient.
3. **No-account secure upload link / QR for outside offices.** The patient shares a one-time link or QR code. The outside office opens it, uploads results and adds a note, without an account. The link is single-patient, time-limited (for example 7 days) and revocable, and every upload is logged. The page also tells the office about Vityls, which makes it a sales channel.
4. **Later: national networks.** TEFCA (QHIN) Individual Access Services, or Carequality/CommonWell through a vendor, let the patient pull from essentially every participating provider at once. Identity proofing (IAL2) is required, and onboarding takes months.

**Fallback that always works:** the patient uploads photos or PDFs, and Nightingale classifies and explains them.

## 5. EMR integration for practices (Vityls practice apps)
- **Standard FHIR read APIs.** Patient and provider SMART on FHIR (Epic developer program / Showroom, athenahealth Marketplace). Reads are broadly available. Write-back is limited and vendor-specific.
- **Practice-level system connections.** Bulk FHIR ($export) for population loads, plus HL7 v2 feeds: ADT (registration and admissions), ORU (results), SIU (scheduling), and MDM/ORM where useful. Each site must approve the connection, it's usually sold practice by practice, and there may be vendor fees. This tier gives real-time feeds.
- **Integration platforms.** Redox, Health Gorilla and Particle Health give one connection across many EMRs and the national networks, priced per connection or per record. This is the fastest route to production for a startup.

**Recommended order**
1. Portal "Connect my doctor" on patient-access FHIR first. It needs the least approval and delivers the most.
2. Fax/Direct inbox for right-of-access requests, plus the secure provider upload link.
3. An integration platform when the first practice customer on Epic or athena needs a two-way sync.
4. Join TEFCA/Carequality individual access.

## 6. Data guidance for Henry
- Store imported clinical data **FHIR-shaped** (resource type, FHIR JSON, plus extracted columns for search). Every row carries `source_id` (the connection: FHIR endpoint, fax request, upload link, patient upload, Vityls practice), `source_record_id`, `imported_at` and `effective_at`.
- **Deduplicate across sources.** A match key per resource (lab: LOINC + effective time + value + unit; med: RxNorm + start; document: hash). Keep every source copy, but show one row, with "seen in 2 sources."
- Every connector writes to the same Core tables, so the Portal and practice charts read one model.
- Additions to `schema_proposed.sql`:

```sql
CREATE TABLE portal_accounts (patient_id UNIQUEIDENTIFIER PRIMARY KEY, email NVARCHAR(320) NOT NULL UNIQUE, password_hash VARBINARY(256) NOT NULL, mfa_enabled BIT NOT NULL DEFAULT 0, identity_level VARCHAR(10) NOT NULL DEFAULT 'IAL1', created_at DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME());
CREATE TABLE patient_entitlements (patient_id UNIQUEIDENTIFIER REFERENCES portal_accounts(patient_id), feature_id VARCHAR(40) NOT NULL, state VARCHAR(10) NOT NULL, trial_end DATETIME2 NULL, since DATETIME2 NULL, PRIMARY KEY (patient_id, feature_id)); -- plus, wearables, reports, unlimited-ai
CREATE TABLE patient_practice_links (link_id UNIQUEIDENTIFIER PRIMARY KEY, patient_id UNIQUEIDENTIFIER NOT NULL, practice_id UNIQUEIDENTIFIER NOT NULL, scopes NVARCHAR(400) NOT NULL, granted_at DATETIME2 NOT NULL, revoked_at DATETIME2 NULL);
CREATE TABLE record_sources (source_id UNIQUEIDENTIFIER PRIMARY KEY, patient_id UNIQUEIDENTIFIER NOT NULL, kind VARCHAR(20) NOT NULL, -- fhir | fax | direct | upload-link | patient-upload | practice | tefca
  display_name NVARCHAR(200) NOT NULL, fhir_base_url NVARCHAR(400) NULL, token_ref NVARCHAR(200) NULL, status VARCHAR(12) NOT NULL, last_sync_at DATETIME2 NULL);
CREATE TABLE clinical_resources (resource_id UNIQUEIDENTIFIER PRIMARY KEY, patient_id UNIQUEIDENTIFIER NOT NULL, source_id UNIQUEIDENTIFIER REFERENCES record_sources(source_id), resource_type VARCHAR(40) NOT NULL, source_record_id NVARCHAR(200) NULL, fhir_json NVARCHAR(MAX) NOT NULL, code_system VARCHAR(40) NULL, code VARCHAR(40) NULL, effective_at DATETIME2 NULL, imported_at DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(), dedup_key VARCHAR(200) NULL, canonical_id UNIQUEIDENTIFIER NULL);
CREATE TABLE records_requests (request_id UNIQUEIDENTIFIER PRIMARY KEY, patient_id UNIQUEIDENTIFIER NOT NULL, provider_name NVARCHAR(200) NOT NULL, provider_fax VARCHAR(30) NULL, return_fax VARCHAR(30) NOT NULL, return_direct NVARCHAR(320) NOT NULL, scope NVARCHAR(400) NOT NULL, sent_at DATETIME2 NULL, due_at DATETIME2 NULL, status VARCHAR(12) NOT NULL);
CREATE TABLE upload_links (token VARCHAR(64) PRIMARY KEY, patient_id UNIQUEIDENTIFIER NOT NULL, recipient NVARCHAR(200) NULL, expires_at DATETIME2 NOT NULL, revoked_at DATETIME2 NULL, uploads INT NOT NULL DEFAULT 0);
CREATE TABLE nightingale_prompts (prompt_id UNIQUEIDENTIFIER PRIMARY KEY, patient_id UNIQUEIDENTIFIER NOT NULL, kind VARCHAR(30) NOT NULL, trigger_resource_id UNIQUEIDENTIFIER NULL, status VARCHAR(12) NOT NULL, created_at DATETIME2 NOT NULL, answered_at DATETIME2 NULL);
CREATE TABLE portal_reminders (reminder_id UNIQUEIDENTIFIER PRIMARY KEY, patient_id UNIQUEIDENTIFIER NOT NULL, title NVARCHAR(200) NOT NULL, due_at DATETIME2 NOT NULL, repeat_rule VARCHAR(40) NULL, done_at DATETIME2 NULL);
```
- Open questions: when global patient identity happens (now or later), and identity proofing level for FHIR and TEFCA access.

## 6b. v0.2 additions: practices, care team, history, family, guest mode
- **Practices connect to the same Portal.** A Vityls practice (portal-link module, Portal page in the practice app) asks to connect by the patient's Portal email; the patient (or their caregiver) approves in Care team, and can revoke. Then the practice sends at-home forms, check-in, bills, messages, refill replies, appointment reminders, documents and results. Patients sign, check in, pay, confirm, message, request refills and appointments. **Practice-initiated items are never paywalled and never count against free limits.**
- **Care team:** Vityls-network practices with actions (message, request appointment, forms and bills, history); non-Vityls providers (FHIR sources, records requests, upload-link offices, manually added) listed separately.
- **Interaction history:** one append-only log of every practice/Portal interaction (sent, opened, signed, checked in, paid, message, refill, file, consent given/revoked, caregiver actions), with actor, role and timestamp. Viewable per practice and overall in the Portal, and per practice in the practice app. The server must enforce append-only (no UPDATE/DELETE grants; hash-chain optional).
- **Family / caregiver access:** the patient invites a family member with full access; a consent record is signed and kept; revocable at any time. The caregiver switches profiles; every action is logged as the caregiver, acting for the patient. Notifications (abnormal results, worsening trends, practice messages, documents) go to the patient and each active caregiver. In v0.2 they appear in an in-app notification center. Email, text and push are simulated.
- **Guest mode:** the Portal opens with Nightingale and no sign-in. Guests get 3 free explanations, stored locally on the device. Saving records, connecting doctors, messaging, family access, wearables and keeping uploads all ask the guest to create a free account. The guest session (chat and entered labs) carries into the new account.
- **Worsening-trend rule (informational only, never a diagnosis):** the latest value is outside the range and further from it than the previous value, or there have been three consecutive moves in one direction ending outside the range.

```sql
CREATE TABLE care_team (care_team_id UNIQUEIDENTIFIER PRIMARY KEY, patient_id UNIQUEIDENTIFIER NOT NULL REFERENCES portal_accounts(patient_id),
  practice_id UNIQUEIDENTIFIER NULL,          -- set for Vityls-network practices (via patient_practice_links)
  npi CHAR(10) NULL, display_name NVARCHAR(200) NOT NULL, specialty NVARCHAR(120) NULL, phone VARCHAR(30) NULL,
  source_kind VARCHAR(20) NOT NULL,           -- vityls | fhir | records-request | upload-link | manual | npi
  source_id UNIQUEIDENTIFIER NULL, added_at DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(), removed_at DATETIME2 NULL);
CREATE TABLE portal_items (item_id UNIQUEIDENTIFIER PRIMARY KEY, patient_id UNIQUEIDENTIFIER NOT NULL, practice_id UNIQUEIDENTIFIER NOT NULL,
  kind VARCHAR(20) NOT NULL,                  -- form | checkin | bill | message | refill-request | refill-reply | reminder | document | result | appt-request
  direction VARCHAR(10) NOT NULL,             -- practice | patient
  title NVARCHAR(300) NOT NULL, body NVARCHAR(MAX) NULL, amount_cents INT NULL, due_at DATETIME2 NULL, payload_json NVARCHAR(MAX) NULL,
  status VARCHAR(20) NOT NULL, reply_to UNIQUEIDENTIFIER NULL, created_by NVARCHAR(200) NOT NULL, created_at DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME());
CREATE TABLE portal_interactions (           -- append-only: grant INSERT/SELECT only
  interaction_id BIGINT IDENTITY PRIMARY KEY, patient_id UNIQUEIDENTIFIER NOT NULL, practice_id UNIQUEIDENTIFIER NULL, item_id UNIQUEIDENTIFIER NULL,
  actor_name NVARCHAR(200) NOT NULL, actor_user_id UNIQUEIDENTIFIER NULL, actor_role VARCHAR(12) NOT NULL, -- practice | patient | caregiver | system
  on_behalf_of UNIQUEIDENTIFIER NULL, action VARCHAR(40) NOT NULL, detail NVARCHAR(1000) NOT NULL, at DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(), prev_hash VARBINARY(32) NULL);
CREATE TABLE caregiver_access (access_id UNIQUEIDENTIFIER PRIMARY KEY, patient_id UNIQUEIDENTIFIER NOT NULL REFERENCES portal_accounts(patient_id),
  caregiver_email NVARCHAR(320) NOT NULL, caregiver_patient_id UNIQUEIDENTIFIER NULL REFERENCES portal_accounts(patient_id), relation VARCHAR(30) NOT NULL,
  scope VARCHAR(20) NOT NULL DEFAULT 'full', consent_text NVARCHAR(MAX) NOT NULL, consent_signed_at DATETIME2 NOT NULL,
  status VARCHAR(10) NOT NULL, accepted_at DATETIME2 NULL, revoked_at DATETIME2 NULL, revoked_by NVARCHAR(200) NULL);
CREATE TABLE notifications (notification_id UNIQUEIDENTIFIER PRIMARY KEY, recipient_patient_id UNIQUEIDENTIFIER NOT NULL, profile_patient_id UNIQUEIDENTIFIER NOT NULL,
  kind VARCHAR(20) NOT NULL,                  -- abnormal | trend | message | document | item | caregiver
  text NVARCHAR(500) NOT NULL, channel VARCHAR(10) NOT NULL DEFAULT 'in-app', created_at DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(), read_at DATETIME2 NULL);
```
`patient_practice_links` (section 6) gains `status` (pending | active | revoked), `requested_by`, `granted_by` and `core_patient_id` (the practice's chart record).

## 7. Doctor Finder (built in v0.3)
- **Search** by name, specialty (NUCC taxonomy description/code), practice/organization, and location (city, state, ZIP; "near" a ZIP = same 3-digit ZIP area in v0.3). Nightingale chips and free text are parsed into a query, for example "find a cardiologist near 90210".
- **Filters:** gender, credential (MD/DO/NP/PA), NPI age, On Vityls only. **Sort:** last name, first name, NPI date (oldest/newest), ZIP. 10 per page.
- **Card:** name and credentials, primary specialty, practice address, phone and fax, NPI. Years are shown as "NPI since YYYY (approx. N yrs)". NPI doesn't record years in practice, and NPIs were first issued in 2005–07, so older dates are labeled "likely longer". A detail view lists all taxonomies, the NPI record update date, and a link to the official NPPES page.
- **Vityls in-network** (badge): Connect (patient-initiated consent, logged as `link.patient-connected`), Message, Request appointment. **Not on Vityls:** Add to my care team, Send records request (prefilled from NPI: name, fax), Send upload link. These reuse the v0.1/v0.2 flows.
- **Guests** can search freely. Saving, connecting, messaging and sending need a free account.
- **Neutrality rule:** Nightingale lists, filters and sorts only by objective fields. She never ranks providers, never says one is better, and never "recommends" a doctor. Any future ordering by distance or availability must stay factual and labeled.
- **Data source:** the public NPPES NPI Registry API v2.1 (`https://npiregistry.cms.hhs.gov/api/?version=2.1`). It has no API key, and results are capped at 200 per call with skip up to 1,000.
  - **CORS:** the API sends no `Access-Control-Allow-Origin` header, so browsers block direct calls. Checked on 2026-10-14 with curl and in Chrome. The v0.3 build therefore runs one provider adapter (`src/portal/finder.ts`) in two modes. The **bundled snapshot** has 666 real public NPI-1 records for Beverly Hills and Los Angeles across 12 specialties, fetched with `scripts/fetch_npi_snapshot.py`. **Live** mode goes through a configurable proxy URL (`vityls:portal:finder-proxy`). The mode in use is always shown.
  - The Vityls-badged entries are **fictional test practices** (Coastline, Bayview). Real NPI providers are never shown as on Vityls unless they've actually joined.

### Server proxy and cache (for Henry)
- `GET /api/providers?name=&specialty=&org=&city=&state=&zip=&page=` → server calls NPPES (`version=2.1`, `limit` ≤ 200, `skip`), normalizes results to the `Provider` shape in `finder.ts`, and returns them with CORS for the Vityls origins only.
- **Cache:**
  - Keep query results for 24 h, keyed by normalized parameters, and each provider row by NPI with `fetched_at`.
  - Refresh weekly, or load the full monthly NPPES data dissemination file (CSV) into `provider_directory` for fast, local search: full-text search on name and org, an index on taxonomy, ZIP and state, and ZIP-centroid distance later.
- Rate-limit per patient and IP, and log nothing about who searched for which doctor beyond aggregate metrics. Search history is health-adjacent data.
- `vityls_practice_id` links a directory row to a Vityls practice when a practice claims its NPI. The practice must verify it (the authorized official on the NPI record, or a document). Only then does the Vityls badge appear.

```sql
CREATE TABLE provider_directory (npi CHAR(10) PRIMARY KEY, entity_type CHAR(5) NOT NULL,            -- NPI-1 individual | NPI-2 organization
  first_name NVARCHAR(100) NULL, last_name NVARCHAR(100) NULL, middle_initial NCHAR(1) NULL, credential NVARCHAR(40) NULL, sex CHAR(1) NULL,
  organization_name NVARCHAR(300) NULL, primary_taxonomy_code VARCHAR(10) NULL, primary_taxonomy_desc NVARCHAR(200) NULL, taxonomies_json NVARCHAR(MAX) NULL,
  address_1 NVARCHAR(200) NULL, address_2 NVARCHAR(200) NULL, city NVARCHAR(100) NULL, state CHAR(2) NULL, zip5 CHAR(5) NULL,
  phone VARCHAR(20) NULL, fax VARCHAR(20) NULL, enumeration_date DATE NULL, npi_last_updated DATE NULL, status CHAR(1) NOT NULL DEFAULT 'A',
  vityls_practice_id UNIQUEIDENTIFIER NULL, claimed_at DATETIME2 NULL, claim_verified_by NVARCHAR(200) NULL,
  source VARCHAR(20) NOT NULL DEFAULT 'nppes-api',   -- nppes-api | nppes-file
  fetched_at DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME());
CREATE INDEX ix_provider_dir_loc ON provider_directory (state, city, zip5);
CREATE INDEX ix_provider_dir_tax ON provider_directory (primary_taxonomy_code);
CREATE TABLE provider_search_cache (cache_key VARCHAR(300) PRIMARY KEY, result_npis NVARCHAR(MAX) NOT NULL, result_count INT NOT NULL, fetched_at DATETIME2 NOT NULL, expires_at DATETIME2 NOT NULL);
```
`care_team.npi` (section 6b) references `provider_directory.npi` when a patient adds a non-Vityls provider from the Finder.

## 8. v0.1 test build scope (v0.2 additions in section 6b)
Sign-up/login (no practice), Nightingale Home with chips and proactive cards, Labs (trend charts, explanations), Documents (upload and explain), Medications and Allergies, Connect my doctor (simulated FHIR import from fictional Epic/athena sources), records-request generator, provider upload link and the simulated provider page (`#portal-upload=<token>`), messages/refills/reminders with linked fictional Vityls practices, and the Free/Plus plan screen (wearables gated).
