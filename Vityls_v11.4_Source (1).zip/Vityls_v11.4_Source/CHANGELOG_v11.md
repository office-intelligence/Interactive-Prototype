# Vityls OS v11.0 · one core for ASC, Surgery and Medical (step 1)

Test builds: `ASC_Vityls_v11.0`, `Surgery_Vityls_v11.0`, `Medical_Vityls_v11.0`, all built from the same source by `scripts/build_v11.sh`. All data is fictional.

## What moved into the core (`src/os/`)

| Core piece | File | Was |
|---|---|---|
| Station engine: Talk / Manual, Nightingale summary, notifications, numbered steps, one list of controls, "Before you sign", PIN signatures at the end, Nightingale's hand-off to the next station | `os/station/engine.tsx`, `station.css`, `scope.css` (generated) | ASC only (`asc108/native108`) |
| Nightingale chat box at the bottom of every page, with action buttons | `os/ai/dock.tsx`, `dock.css` | Two different boxes (ASC `ai106`, office `flow/Composer`) |
| Next-step director: the next steps of every patient journey, by team | `os/next/next.ts` | Did not exist |

Each edition plugs in through an **adapter** (what a station works on and how it draws the header) and a **brain** (edition commands for the chat box):
- ASC: `surgery/asc108/native108.tsx` (adapter for an ASC case), `surgery/asc106/ai106.tsx` (ASC brain). ASC behaves as in v10.8.
- Surgery and Medical: `surgery/office11/stations.tsx` (adapter for an office visit + the four stations), `surgery/office11/nightingale.tsx` (next steps, Today card, office brain).

## Surgery.Vityls and Medical.Vityls: AI-first

- **Today opens with "Nightingale · next for you".** Steps for the signed-in role (Front desk, Nurse / MA, Provider, Coordinator), with Mine / Everyone. Each step says why now and opens the station that does the work. When nothing is waiting on you, it shows what the team does next.
- **The Nightingale box at the bottom of every page** now runs commands: "what's next", "who's waiting", "start Ellen", "room Ellen", "check out Alicia". Answers come with buttons that open the station. Chart and practice questions work as before.
- **Check-in, Nurse / MA, Doctor (Surgeon in Surgery.Vityls) and Checkout** use the ASC station design:
  - patient header with the visit journey (tap a step to open it) and allergies
  - Talk / Manual, Nightingale summary, notifications
  - Nurse / MA is native: reason for the visit, pain, vitals with quick values, allergies and medications confirmed, screening, a note for the provider. Talk mode fills it from a sample conversation; heard items wait for confirmation.
  - Doctor / Surgeon opens with Nightingale's summary of the intake, then the scribe and note, body charts and photos, price quote (Surgery), forms, and plan (Medical: follow-up and orders; Surgery: decision). Talk jumps to the scribe.
  - Check-in and Checkout host the existing identity, portal forms, cards, arrival, payment and checkout pieces as steps.
  - Signing a station stamps the time and advances the visit, the same as "Verify with PIN". Then Nightingale offers the next step ("Ready for Dr. Patel", "Send to checkout").
- Values are saved to the same records as before (nurse admission, vitals, visit note, flow, station verification), so the chart, To-do lists and journey keep working.

## Kept as they are

- **Scheduling stays different per edition.** Medical and Surgery book appointments; ASC books cases. The schedulers were not changed.
- Booking & clearance, ASC workspace, Post-op and the visit record in Surgery keep their current workspaces.

## Next (steps 2–5 of the plan)

2. Make the edition a practice setting instead of a separate build (replace the edition checks with module entitlements and terminology).
3. Database: move the general tables (station answers, signatures, forms, documents, notes, audit) to a core schema; visits, surgical cases and perioperative data become module schemas.
4. Put the patient portal on the same core (same Nightingale box and form renderer).
5. Rebuild the remaining Surgery workspaces (booking & clearance, ASC hand-off, post-op) on the station engine, and have a real practice of each kind try them.

# v11.1 · question bank, station checklists, schedule email, logo and photo

All three builds (ASC, Surgery, Medical) still come from one source (`scripts/build_v11.sh`).

- **ID & insurance cards** have their own chart tab in Surgery and Medical (was inside Documents). The tab shows how many cards are missing.
- **Question bank in Surgery and Medical** (Practice settings › Question bank). It is the ASC master bank: 218 questions, every group available.
  - The office stations map to bank stations: Check-in = Front desk, Nurse / MA = Pre-op nursing, Doctor / Surgeon = Surgeon, Checkout = Discharge.
  - Medical starts with registration, rights & advance directives, and the patient-supplied history (demographics, allergies, medications, past medical and surgical history, women's health). Surgery also starts with the MH risk screen, post-op care arrangements, case definition, records & clearance review, and consent & site marking.
  - A practice can switch groups on or off, reword a question, change its options, move it to another station, make it required or hide it, and add its own questions.
  - Questions appear as steps at the station that asks them. A question the patient answered on the portal shows only if it is still blank. Answers are kept once per patient with who, when and which station, and carry forward to the next visit. Anything the station already asks with its own controls (vitals, allergies, medications, tobacco, photo ID) is not asked twice.
- **Station checklists in Surgery and Medical** (Practice settings › Station checklists), the same editor as ASC v10.7. The four office stations each have locked standard items. Facility items can be placed in any step and limited to a room, provider, visit type / reason or age. They can have Talk phrases and numbered versions, and can be picked from the form library. Fields of forms assigned to a station appear automatically; only published form versions count. Demo items: "Interpreter needed" at Check-in, and "Diabetic foot check" at Nurse / MA for diabetes and chronic-care visits.
- **Next-day schedule email at 2:00 PM** (all three editions; Practice settings › Next-day schedule email). Each surgeon (ASC) or doctor / surgeon (Surgery, Medical) with cases or appointments tomorrow gets one email:
  - ASC: time, patient, procedure, room, anesthesia, length.
  - Office: time, patient, visit type and reason, room or video / phone.
  - Settings: on/off, send time, full names or initials only, a preview of tomorrow's emails, "Send tomorrow's now", and a sent log.
  - Simulated: emails go to the Vityls outbox. Providers without an email on file use a fictional demo address until one is added in Providers.
- **Practice logo** (Surgery, Medical: Practice settings › Practice profile & rooms): upload, replace or remove. It is shown next to Vityls at the top of the expanded menu.
- **Patient photo in the patient header:** the chart header shows a visible "Add photo" under the initials (upload, take a photo, or drag in a picture). The photo also appears on the patient card at every office station.
- The engine's steps can keep question bank wording exactly as written (no terminology change in Medical).

# v11.2 · one app, database connectivity, setup wizard everywhere

- **One app for every edition: `Vityls_OS_v11.2`.** ASC, Surgery and Medical run from the same file; the practice record decides the edition when the app loads (in production: the signed-in user's practice). Demo practices: Harborview Surgery Center (ASC), Coastline Plastic Surgery (Surgery), Bayview Family Medicine (Medical); switch with the practice picker at the bottom right, or `?practice=harbor|coastline|bayview`. Each practice keeps its own data. The three single-edition builds are still produced for testing.
- **Database connectivity.**
  - The app keeps working offline-first in the browser cache and writes every record to the Vityls record store API (`/api/v1/store`). It loads the practice's records before the app starts and pulls other devices' changes every 15 seconds. A "Database · saved" badge shows the state; changes made offline wait and are sent when the connection returns.
  - The server stores records in **Azure SQL** when `AZURE_SQL_CONNECTION_STRING` is set (tables `app.record` and append-only `app.record_history`, created on first start), or in a JSON file for development. Turn it on with `?api=<url>` (remembered on the device) or `VITE_API_URL`.
  - Tested end to end with the JSON store: two separate browsers on one practice, a nurse intake saved on one appeared on the other, and live changes arrived within 15 seconds. The Azure SQL backend is written but not yet run against a real Azure SQL database.
- **Handoff for Henry:** `DATABASE_HANDOFF_v11.md` covers running it, the API, the "before real patient data" checklist, and the record key → table map for 92 record types across the three editions. Two SQL files:
  - `db/vityls_v11_store_azure_sql.sql`: phase 1, live today.
  - `db/vityls_v11_core_modules_azure_sql.sql`: phase 2, one database with schemas core, sched, chart, stations, forms, bank, billing, msg, notify, office, surgery and portal, tenant_id on every table and a row-level security function. The v10.8 ASC schema stays as delivered.
- **Practice setup wizard in Surgery and Medical.** The same Practice settings home and eight-step onboarding wizard as ASC, with office groups:
  1. Practice profile
  2. Rooms, visit types & reminders
  3. People & roles
  4. Doctors / Surgeons & providers
  5. Forms, stations & questions
  6. Billing, fees & reports
  7. Nightingale & notifications
  8. Security & audit
  
  Every settings page opens inside the same frame with the group list.
- **Practice logo:** removed from the left menu. It now prints on visit summaries, letters and clearance requests, price quotes, invoices (new Print button on case invoices) and records packets (PNG or JPG logos).

## v11.3 · Surgical Planning module

The standalone Surgical Planning Suite (from `SURGICAL_PLANNER.zip`) is now the module `surgical-planning`.

- **Editions:** on in Surgery; a 14-day-trial add-on for Medical and ASC (Practice settings → Modules). In the one-app build, Coastline (Surgery) has it; Bayview and Harbor don't.
- **Where it appears:**
  - Surgeon station: a new "Surgical plan" step.
  - Chart → Photos & charts: a "Surgical plans" section with thumbnails, Edit and a viewer.
  - Nightingale: "surgical plan for Ellen" opens the planner.
- **How it connects:** the planner opens full screen with the patient's name, MRN, booked procedure, surgeon and latest pre-op photo already loaded. Saving files the marked image as a "Surgical plan" document and keeps the markings, so Edit reopens the plan exactly as left.
- **Fixes to the original file:**
  - A missing closing brace stopped the whole script from running.
  - Saving tried to post a live image object, which the browser can't copy, so it failed. It now sends plain JSON.
  - The blocking "saved" alert is gone.
- **Offline:** three.js r128 and OrbitControls (MIT) are bundled into the build, with no CDN.
- **Fictional defaults:** the original default patient and surgeon names were replaced with fictional ones.
- **Database:** plan records map to `chart.surgical_plan` (see `DATABASE_HANDOFF_v11.md`). Plan images stay in the browser (IndexedDB) until Azure Blob Storage is connected.

## v11.4 · Patient Portal (vityls.com) on the core

The patient-facing Portal is now a fifth build, `Vityls_Portal_v11.4`. It's the page to host on vityls.com, built from the same source and saving to the same database. Opening it shows the Portal; `?practice=coastline`, `bayview` or `harbor` opens a practice in the same file.

**Everything from Portal v0.5 is in it:**
- Nightingale chat as a guest (3 free explanations) and signed in.
- The Chat | Portal switch.
- Timeline, My Doctors, Care team, My Labs, My Health (medicines, allergies, conditions), Documents, Wearables & journal, Family access, Messages & refills, Appointments and Activity history.
- The profile menu: Billing & payments, Plan (Plus trial), Notifications and Settings.
- The Doctor Finder: the public NPPES NPI snapshot plus the Vityls practices, with filters, sorting, paging, live mode and Connect / Message / Book.
- Connect my doctor and records: FHIR sign-in, a fax/Direct records request, an upload link, and patient uploads.
- Deep links (`#portal/task/<id>`, `#portal/view/<section>`), demo accounts (password `portal2026`) and `?reset-portal`.

**New in v11.4:**
- **One database.** The Portal belongs to the patient, not a practice, so its records sync under their own tenant, `portal`. Every app keeps two channels in step, its practice and the Portal. Sign-in sessions stay on the device. See `DATABASE_HANDOFF_v11.md` for the `portal.*` tables.
- **All three kinds of practice.**
  - Harborview Surgery Center (ASC) is now in the Doctor Finder next to Coastline (Surgery) and Bayview (Medical).
  - The practice's Portal page is in the navigation of every build, not only the one-app build.
- **Chart → Portal tab** (Surgery and Medical):
  - the connection and consent, or "Send connection request";
  - what the patient sent, with Reply;
  - what the practice sent and its status, including signed form answers, check-in from home and bills paid;
  - a quick message to the patient.
- **Check-in station: "From the patient's Portal".** Shows check-in from home, signed forms with answers, and bills paid or unpaid, so nothing done at home is asked again. Waiting requests link to the Portal page.
- **Nightingale.**
  - Each unanswered Portal request (message, refill or appointment request) becomes a front-desk next step on Today, opening the Portal page.
  - Asking "portal" or "portal requests" lists what's waiting; "portal for Ellen" gives that patient's status.
- **Matching to charts.** A patient who connects from the Doctor Finder is matched to the chart with the same email, or the same name and date of birth. Otherwise the Portal page offers "Match" to an existing chart or "Create chart" from the Portal account.

**Before real patients:**
- Portal sign-in moves to Entra ID B2C; the test build keeps demo passwords in the account record.
- Delivery stays simulated until the BAA and vendors are in place: email/text, card payments, FHIR, fax/Direct and wearables.
- The API must enforce consent: a practice reads a patient's Portal items only through an active link.

### v11.4.1 · Portal sign-up and sign-in fields

- Labelled Portal fields (sign-up, sign-in, forms, settings) were stretched about 140px tall each, which pushed the button off screen. A flex size meant for side-by-side rows was applied to fields stacked vertically. Fields are back to their normal height, and the sign-up / sign-in card fits on desktop and phone screens (it scrolls if a screen is shorter).
