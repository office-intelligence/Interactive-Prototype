/* Vityls OS v11.2 · server-side record store behind /api/v1/store.
 *
 * The app keeps working offline-first: every record it saves (one key = one record, JSON) is written to the browser cache
 * and to this store; on load the browser fetches the practice's records first. Two backends:
 *   - Azure SQL (production): set AZURE_SQL_CONNECTION_STRING. Tables app.record (current value per tenant + key) and
 *     app.record_history (append-only, every change with who / when). Created on first start if missing
 *     (db/vityls_v11_store_azure_sql.sql has the same DDL).
 *   - JSON file (development / demo): data/vityls-store.json. Used when no connection string is set.
 * Tenancy: every row carries tenant_id (the practice id). A request may only read and write its own tenant. */
import fs from 'fs';
import path from 'path';

export interface Rec { k: string; v: string | null; at: string; by: string }
export interface Backend { name: string; init(): Promise<void>; list(tenant: string, since?: string): Promise<Rec[]>; put(tenant: string, items: { k: string; v: string | null }[], by: string): Promise<string> }

/* ---------------- JSON file (development) ---------------- */
export class FileBackend implements Backend {
  name = 'json-file'; private file: string; private db: Record<string, Record<string, Rec>> = {};
  constructor(file = path.join(process.cwd(), 'data', 'vityls-store.json')) { this.file = file; }
  async init() { try { this.db = JSON.parse(fs.readFileSync(this.file, 'utf8')); } catch { this.db = {}; } }
  private save() { fs.mkdirSync(path.dirname(this.file), { recursive: true }); fs.writeFileSync(this.file + '.tmp', JSON.stringify(this.db)); fs.renameSync(this.file + '.tmp', this.file); }
  async list(tenant: string, since?: string) { const t = this.db[tenant] || {}; return Object.values(t).filter(r => !since || r.at > since); }
  async put(tenant: string, items: { k: string; v: string | null }[], by: string) {
    const at = new Date().toISOString(); const t = (this.db[tenant] = this.db[tenant] || {});
    items.forEach(i => { t[i.k] = { k: i.k, v: i.v, at, by }; }); this.save(); return at;
  }
}

/* ---------------- Azure SQL (production) ---------------- */
export const STORE_DDL = `
IF SCHEMA_ID(N'app') IS NULL EXEC(N'CREATE SCHEMA app');
IF OBJECT_ID(N'app.record') IS NULL
CREATE TABLE app.record (
  tenant_id   NVARCHAR(64)  NOT NULL,
  record_key  NVARCHAR(400) NOT NULL,
  value_json  NVARCHAR(MAX) NULL,           -- NULL = deleted (kept so other devices learn about the delete)
  updated_at  DATETIME2(3)  NOT NULL,
  updated_by  NVARCHAR(200) NOT NULL,
  CONSTRAINT pk_app_record PRIMARY KEY (tenant_id, record_key)
);
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'ix_app_record_changes')
CREATE INDEX ix_app_record_changes ON app.record (tenant_id, updated_at);
IF OBJECT_ID(N'app.record_history') IS NULL
CREATE TABLE app.record_history (
  history_id  BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT pk_app_record_history PRIMARY KEY,
  tenant_id   NVARCHAR(64)  NOT NULL,
  record_key  NVARCHAR(400) NOT NULL,
  value_json  NVARCHAR(MAX) NULL,
  changed_at  DATETIME2(3)  NOT NULL,
  changed_by  NVARCHAR(200) NOT NULL
);`;
export class SqlBackend implements Backend {
  name = 'azure-sql'; private pool: any; constructor(private conn: string) {}
  async init() { const sql = (await import('mssql')).default; this.pool = await new sql.ConnectionPool(this.conn).connect(); await this.pool.request().batch(STORE_DDL); }
  async list(tenant: string, since?: string) {
    const sql = (await import('mssql')).default; const r = this.pool.request().input('t', sql.NVarChar(64), tenant);
    if (since) r.input('s', sql.DateTime2(3), new Date(since));
    const q = await r.query(`SELECT record_key AS k, value_json AS v, CONVERT(varchar(30), updated_at, 127) + 'Z' AS at, updated_by AS by FROM app.record WHERE tenant_id = @t${since ? ' AND updated_at > @s' : ''}`);
    return q.recordset as Rec[];
  }
  async put(tenant: string, items: { k: string; v: string | null }[], by: string) {
    const sql = (await import('mssql')).default; const at = new Date(); const tx = new sql.Transaction(this.pool); await tx.begin();
    try {
      for (const i of items) {
        const rq = new sql.Request(tx).input('t', sql.NVarChar(64), tenant).input('k', sql.NVarChar(400), i.k).input('v', sql.NVarChar(sql.MAX), i.v).input('a', sql.DateTime2(3), at).input('b', sql.NVarChar(200), by);
        await rq.query(`MERGE app.record WITH (HOLDLOCK) AS d USING (SELECT @t AS tenant_id, @k AS record_key) AS s ON d.tenant_id = s.tenant_id AND d.record_key = s.record_key
          WHEN MATCHED THEN UPDATE SET value_json = @v, updated_at = @a, updated_by = @b
          WHEN NOT MATCHED THEN INSERT (tenant_id, record_key, value_json, updated_at, updated_by) VALUES (@t, @k, @v, @a, @b);
          INSERT INTO app.record_history (tenant_id, record_key, value_json, changed_at, changed_by) VALUES (@t, @k, @v, @a, @b);`);
      }
      await tx.commit();
    } catch (e) { await tx.rollback(); throw e; }
    return at.toISOString();
  }
}

export function makeBackend(): Backend { const c = process.env.AZURE_SQL_CONNECTION_STRING; return c ? new SqlBackend(c) : new FileBackend(process.env.VITYLS_STORE_FILE || undefined); }
