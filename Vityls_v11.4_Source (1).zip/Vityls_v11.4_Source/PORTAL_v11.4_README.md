# Vityls Patient Portal v11.4 · for vityls.com

The patient-facing Portal, built from the same source as ASC, Surgery and Medical (Vityls OS v11.4) and saving to the same database. All data is fictional. Every outside connection is simulated: email/text, card payments, FHIR, fax/Direct and wearables.

## Open it

- Unzip, then open `Vityls_Portal_v11.4/index.html` in Chrome or Edge.
- The page opens on Nightingale chat as a guest (3 free explanations). Use **Chat | Portal** in the sidebar to switch.
- **Demo accounts** (password `portal2026`):
  - `jordan.rivera@example.test`: a patient connected to Bayview Family Medicine.
  - `alex.rivera@example.test`: Jordan's family member, to try family access.
- **The practice side, in the same file:**
  - `index.html?practice=bayview` (Medical)
  - `?practice=coastline` (Surgery)
  - `?practice=harbor` (ASC)

  Open **Patient Portal** in the navigation.
- **Deep links** (what an email or text opens):
  - `index.html#portal/task/<item id>`
  - `index.html#portal/view/<section>`
- **Start over:** add `?reset-portal` to the address.

## Host it on vityls.com

1. Upload the contents of `Vityls_Portal_v11.4/` to the site (any static host: Azure Static Web Apps, Blob Storage static website or App Service). `index.html` is the whole app; `forms/` and `pdf-templates/` are the form library.
2. Run the Vityls API (`server.ts`, see `DATABASE_HANDOFF_v11.md`) and point the Portal at it, either by opening it once with `index.html?api=https://api.vityls.com/api`, or by building with `VITE_API_URL=https://api.vityls.com/api`.
3. Portal records sync under the patient-owned tenant `portal`, and each practice app syncs the same tenant. So a form a patient signs at vityls.com shows up at the practice's check-in station, and the practice's reply shows up in the Portal within 15 seconds.

## Before real patients

- **Sign-in:** move it to Entra ID B2C. The test build keeps demo passwords in the account record.
- **Consent in the API:** a practice may read a patient's Portal items only through an active `portal.practice_link`.
- **BAA and real vendors:** email/SMS, card processor (tokens only), FHIR apps, fax/Direct and wearables.
