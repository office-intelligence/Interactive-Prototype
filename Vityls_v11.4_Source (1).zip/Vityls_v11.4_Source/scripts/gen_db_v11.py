"""Vityls OS v11.4 · writes the database handoff for Henry:
   db/vityls_v11_store_azure_sql.sql            phase 1: the record store the app syncs to today (app.record)
   db/vityls_v11_core_modules_azure_sql.sql     phase 2: normalized core + module schemas (one database, every edition)
   DATABASE_HANDOFF_v11.md                      how it fits together + the record-key -> table map
Input: a JSON dump of the record store (data/vityls-store.json) after opening every edition, plus the key families below."""
import json, re, os, sys, collections
root = os.path.join(os.path.dirname(__file__), '..')
store = json.load(open(os.path.join(root, 'data', 'vityls-store.json'))) if os.path.exists(os.path.join(root, 'data', 'vityls-store.json')) else {}

# (key pattern, schema.table, module, what it holds)
MAP = [
 (r'^vityls:med:patients$', 'core.patient', 'Core', 'Patient identity, demographics, allergies, contact, insurance (one row per patient)'),
 (r'^vityls:med:visits$', 'office.visit', 'Scheduling', 'Appointments / office visits: date, time, provider, room, type, step'),
 (r'^vityls:med:notes$', 'office.visit_note', 'Chart', 'Visit notes (SOAP), signed versions and addenda'),
 (r'^vityls:med:(problems|meds|vitals|labs|intake|careplans|caregivers)$', 'chart.<problem|medication|vitals|lab_result|intake_answer|care_plan|caregiver>', 'Chart', 'Clinical record lists, one row per item'),
 (r'^vityls:med:messages$', 'msg.message', 'Messages', 'Portal and staff messages'),
 (r'^vityls:med:settings$|^vityls:surgery:settings$', 'core.practice_setting', 'Core', 'Practice settings (name, fees, reminders, Nightingale)'),
 (r'^vityls:v7:providers$', 'core.provider', 'Core', 'Providers, credentialing, signature PIN hashes'),
 (r'^vityls:surgery:(coordinators|roles-v011|signers-v011)$', 'core.staff / core.role', 'Core', 'Staff, roles, who signs what'),
 (r'^vityls:v6:audit:', 'core.audit_event', 'Core', 'Append-only audit trail (per patient / case / practice)'),
 (r'^vityls:v6:facts:', 'core.fact', 'Core', 'Time stamps and facts per visit/case (arrived, roomed, checked out...)'),
 (r'^vityls:v6:stations:', 'core.station_signoff', 'Stations', 'Station verification (PIN sign-off) per visit'),
 (r'^vityls:v6:forms?:|^vityls-form-(requirement|workflow):|^vityls-my-forms:|^vityls-explicit-form-workflow|^oi-premiere-official-html-library', 'forms.form_instance / forms.form_assignment', 'Forms', 'Filled forms per visit/case, form-to-station assignments, requirements'),
 (r'^vityls:v6:signers:', 'forms.form_signer_rule', 'Forms', 'Who signs each form'),
 (r'^vityls:portal:accounts$', 'portal.account (+ portal.lab / portal.document / portal.medication … in data_json)', 'Patient Portal', 'Patient-owned Portal accounts (tenant portal): profile, labs, documents, medicines, allergies, journal, chats, plan. Test build keeps a plain password here; production signs in with Entra ID B2C and stores no password'),
 (r'^vityls:portal:hub:links$', 'portal.practice_link', 'Patient Portal', 'Practice ↔ patient connections with consent, scopes and the matched chart (tenant portal)'),
 (r'^vityls:portal:hub:items$', 'portal.item', 'Patient Portal', 'Forms, check-ins, bills, messages, results, refills and requests between a practice and a patient, with status and answers'),
 (r'^vityls:portal:hub:interactions$', 'portal.interaction', 'Patient Portal', 'Append-only Portal history (who did what, for which practice)'),
 (r'^vityls:portal:hub:notifications$', 'portal.notification', 'Patient Portal', 'Notifications to the patient and every active caregiver'),
 (r'^vityls:portal:hub:caregivers$', 'portal.caregiver_access', 'Patient Portal', 'Family / caregiver access with the signed consent text'),
 (r'^vityls:portal:upload-links$', 'portal.upload_link', 'Patient Portal', 'Upload links a patient gives an outside doctor (expiry, revoked)'),
 (r'^vityls:portal:(seed|finder-mode|finder-proxy|viewing|guest|session)$', '(not migrated)', 'Test build', 'Portal seed marker and device-only preferences'),
 (r'^vityls:surgery:planner-plans$', 'chart.surgical_plan', 'Chart', 'Surgical Planning: markings JSON per plan (marked and base images go to Blob Storage)'),
 (r'^vityls:surgery:(documents|photos|body-charts|asc87-uploads|img-gen)$', 'core.document / chart.photo / chart.body_chart', 'Core / Chart', 'Documents folder, uploads (blobs in Azure Blob Storage, metadata here), photos, body charts'),
 (r'^vityls:surgery:(nurse|o11-nurse)$', 'stations.station_record (station = nurse)', 'Stations', 'Nurse / MA intake per visit'),
 (r'^vityls:surgery:o11-(front|provider|checkout)$|^vityls:surgery:asc108-|^vityls:surgery:asc106-or$', 'stations.station_record + stations.station_record_value', 'Stations', 'Every station answer (Talk/Manual, heard quote, confirmed), signatures'),
 (r'^vityls:surgery:o11-answers$|^vityls:surgery:asc10-answers$', 'bank.answer', 'Question bank', 'Question bank answers with provenance (once per patient / case)'),
 (r'^vityls:surgery:o11-bank$', 'bank.practice_override', 'Question bank', 'Practice changes to the master bank: groups on/off, wording, options, station, added questions'),
 (r'^vityls:surgery:asc107-(checklists|pins)$', 'stations.checklist_version / stations.checklist_item / stations.case_checklist_pin', 'Stations', 'Facility checklist items, versions, pinned version per visit/case'),
 (r'^vityls:surgery:(scribe|v17-jots|v17-notes|contact-notes|outside-hp-meds)$', 'chart.scribe_session / chart.note', 'Chart', 'Ambient scribe transcripts, quick jots, contact notes'),
 (r'^vityls:surgery:(v17-flags|asc8-flags)$', 'core.flag', 'Core', 'Flags and to-dos between teams'),
 (r'^vityls:surgery:(reminder-sends|reminders-since|appt-confirm|confirmations)$', 'sched.reminder / sched.confirmation', 'Scheduling', 'Appointment reminders sent and confirmations'),
 (r'^vityls-surgery-v11-apptnotes$', 'sched.appointment_note', 'Scheduling', 'Appointment notes'),
 (r'^vityls:surgery:(journeys|flow-journeys-v13|flow-state|flow-audit|episodes|case-links|cases|forms-packets)$', 'surgery.episode / surgery.journey_step / surgery.case_request', 'Surgery', 'Surgical episodes: consult to surgery to post-op, booking, clearance, ASC hand-off'),
 (r'^vityls:surgery:quotes$', 'billing.quote / billing.quote_version', 'Billing', 'Price quotes with versions'),
 (r'^vityls:surgery:(patient-payments|asc83-case-pay)$', 'billing.payment', 'Billing', 'Payments and receipts (card data never stored: processor tokens only)'),
 (r'^vityls:surgery:orders$|^vityls:surgery:asc86-orders$', 'chart.order', 'Chart', 'Orders (standing and one-off)'),
 (r'^vityls:surgery:asc8-cases$', 'asc.surgical_case (+ asc tables of the v10.8 handoff)', 'ASC', 'ASC cases: day-of-surgery record, events, station values'),
 (r'^vityls:surgery:asc86-vitals$', 'asc.flowsheet_vital', 'ASC', 'PACU flowsheet vitals'),
 (r'^vityls:surgery:asc87-activity$', 'core.activity', 'Core', 'Activity feed (requests received, faxes filed...)'),
 (r'^vityls:surgery:surgical-history$', 'chart.surgical_history', 'Chart', 'Past surgical history'),
 (r'^vityls:surgery:os-daily-email(-log)?$', 'notify.daily_schedule_setting / notify.outbox', 'Notifications', '2 PM next-day schedule email settings and sends'),
 (r'^vityls:surgery:asc8-forms-config$|^asc8-forms-config$', 'forms.form_assignment', 'Forms', 'ASC form configuration'),
 (r'-mode$', '(not migrated)', 'Test build', 'Per-device view preference (Talk / Manual)'),
 (r'^vityls:surgery:hipaa-v013$', 'core.disclosure', 'Core', 'HIPAA accounting of disclosures (records packets sent)'),
 (r'^vityls:surgery:stations-v010$', 'core.practice_setting', 'Core', 'Station configuration (office workflow)'),
 (r'^vityls:mod:', 'module tables (per module)', 'Modules', 'Module data (email intake, outbox)'),
 (r'(seeded|seed|migrated|-since|^vityls:seed-version|demo|sync-probe|img-gen)', '(not migrated)', 'Test build', 'Seed markers, demo switches and test probes: device-only, not production data'),
]
def classify(k):
  for rx, tbl, mod, what in MAP:
    if re.search(rx, k): return tbl, mod, what
  return 'review', '—', 'Not mapped yet: review with Kevin'

keys = collections.defaultdict(lambda: {'ed': set(), 'bytes': 0})
for t, recs in store.items():
  for k, r in recs.items():
    base = re.sub(r'^vityls-[a-z0-9]+~', '', k); base = re.sub(r'(:audit:patient:|:audit:asc8:)[^:]+$', r'\1<id>', base); base = re.sub(r'(:form:[^:]+:)[^:]+:', r':form:<instance>:', base)
    base = re.sub(r':form:[^:]+:([^:]+)$', r':form:<instance>:\1', base); base = re.sub(r':forms:.+$', ':forms:<instance>', base)
    base = re.sub(r'(:signers:|form-requirement:|form-workflow:)[^:]+$', r'\1<form>', base); base = re.sub(r':facts:.+$', ':facts:<subject>', base); base = re.sub(r':stations:.+$', ':stations:<visit>', base)
    keys[base]['ed'].add(t); keys[base]['bytes'] += len(r.get('v') or '')
for extra in ['vityls:surgery:asc106-or', 'vityls:surgery:asc108-nursing', 'vityls:surgery:asc10-answers', 'vityls:surgery:o11-front', 'vityls:surgery:o11-provider', 'vityls:surgery:o11-checkout', 'vityls:surgery:o11-answers', 'vityls:surgery:o11-bank', 'vityls:surgery:os-daily-email', 'vityls:surgery:os-daily-email-log', 'vityls:surgery:planner-plans', 'vityls:portal:accounts', 'vityls:portal:hub:links', 'vityls:portal:hub:items', 'vityls:portal:hub:interactions', 'vityls:portal:hub:notifications', 'vityls:portal:hub:caregivers', 'vityls:portal:upload-links']:
  keys.setdefault(extra, {'ed': set(['(when used)']), 'bytes': 0})

for k in list(keys):
  if k.startswith('vityls:portal:'): keys[k]['ed'] = set(['Portal (tenant portal)'])
NAMES = {'harbor': 'ASC', 'coastline': 'Surgery', 'bayview': 'Medical'}
rows = sorted(((classify(k), k, v) for k, v in keys.items()), key=lambda x: (x[0][1], x[0][0], x[1]))
md_map = '\n'.join(f'| `{k}` | {", ".join(sorted(NAMES.get(e, e) for e in v["ed"]))} | {c[1]} | `{c[0]}` | {c[2]} |' for c, k, v in rows if c[0] != '(not migrated)')
skip = sorted(k for c, k, v in rows if c[0] == '(not migrated)')

STORE_SQL = open(os.path.join(root, 'server', 'store.ts')).read().split('export const STORE_DDL = `')[1].split('`;')[0]
open(os.path.join(root, 'db', 'vityls_v11_store_azure_sql.sql'), 'w').write('/* Vityls OS v11.4 · phase 1 record store (live today): server.ts /api/v1/store writes here when AZURE_SQL_CONNECTION_STRING is set.\n   The server creates these on first start; this file is the same DDL for DBA review. */\n' + STORE_SQL.strip().replace(';\nIF', ';\nGO\nIF') + '\nGO\n')

T = lambda name, cols, note='': f"CREATE TABLE {name} (  -- {note}\n  " + ',\n  '.join(cols) + "\n);\nGO"
ID = 'id UNIQUEIDENTIFIER NOT NULL PRIMARY KEY DEFAULT NEWSEQUENTIALID()'
TEN = 'tenant_id NVARCHAR(64) NOT NULL'
PAT = 'patient_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.patient(id)'
DATA = 'data_json NVARCHAR(MAX) NULL CHECK (data_json IS NULL OR ISJSON(data_json) = 1)'
WHO = 'created_at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME(), created_by NVARCHAR(200) NULL, updated_at DATETIME2(3) NULL, updated_by NVARCHAR(200) NULL'
P2 = [
 '/* Vityls OS v11.4 · phase 2: one database for every edition (ASC, Surgery, Medical) and the patient portal.',
 '   Schemas: core (tenant, people, patients, documents, audit), sched, chart, stations, forms, bank, billing, msg, notify,',
 '   surgery (office surgical episodes), office (visits), asc (perioperative: the v10.8 asc schema stays as delivered), portal.',
 '   Every table carries tenant_id; row-level security limits each request to its practice. Typed key columns for search and',
 '   reporting, plus data_json with the full record so the app can move one family at a time from app.record. */',
 "CREATE SCHEMA core; GO\nCREATE SCHEMA sched; GO\nCREATE SCHEMA chart; GO\nCREATE SCHEMA stations; GO\nCREATE SCHEMA forms; GO\nCREATE SCHEMA bank; GO\nCREATE SCHEMA billing; GO\nCREATE SCHEMA msg; GO\nCREATE SCHEMA notify; GO\nCREATE SCHEMA office; GO\nCREATE SCHEMA surgery; GO\nCREATE SCHEMA portal; GO",
 T('core.tenant', ['id NVARCHAR(64) NOT NULL PRIMARY KEY', 'name NVARCHAR(200) NOT NULL', "edition NVARCHAR(10) NOT NULL CHECK (edition IN (N'ASC', N'SURGERY', N'MEDICAL'))", 'plan NVARCHAR(20) NULL', 'status NVARCHAR(20) NOT NULL DEFAULT N\'sandbox\'', 'logo_blob_url NVARCHAR(400) NULL', DATA, WHO], 'a practice; the edition decides the interface (one app)'),
 T('core.tenant_module', [TEN + ' REFERENCES core.tenant(id)', 'module_id NVARCHAR(40) NOT NULL', "state NVARCHAR(10) NOT NULL CHECK (state IN (N'off', N'trial', N'active', N'expired'))", 'trial_end DATETIME2 NULL', 'PRIMARY KEY (tenant_id, module_id)'], 'entitlements (see report/Vityls_Core_Modules_Architecture.md)'),
 T('core.app_user', [ID, 'email NVARCHAR(320) NOT NULL UNIQUE', 'display_name NVARCHAR(200) NOT NULL', 'identity_subject NVARCHAR(200) NULL', WHO], 'one login across practices'),
 T('core.membership', [ID, TEN + ' REFERENCES core.tenant(id)', 'user_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.app_user(id)', 'role NVARCHAR(60) NOT NULL', 'pin_hash NVARCHAR(200) NULL', 'active BIT NOT NULL DEFAULT 1', WHO], 'a person\'s role in one practice (a surgeon in an office and at an ASC = two rows)'),
 T('core.provider', [ID, TEN, 'user_id UNIQUEIDENTIFIER NULL REFERENCES core.app_user(id)', 'display_name NVARCHAR(200) NOT NULL', 'role NVARCHAR(40) NOT NULL', 'npi NVARCHAR(10) NULL', 'email NVARCHAR(320) NULL', DATA, WHO], ''),
 T('core.patient', [ID, TEN, 'mrn NVARCHAR(40) NOT NULL', 'name NVARCHAR(200) NOT NULL', 'dob DATE NULL', 'sex NVARCHAR(10) NULL', 'phone NVARCHAR(40) NULL', 'email NVARCHAR(320) NULL', 'portal_account_id UNIQUEIDENTIFIER NULL', 'photo_blob_url NVARCHAR(400) NULL', DATA, WHO, 'CONSTRAINT uq_patient_mrn UNIQUE (tenant_id, mrn)'], ''),
 T('core.document', [ID, TEN, PAT, 'subject_id UNIQUEIDENTIFIER NULL', 'doc_type NVARCHAR(80) NOT NULL', 'title NVARCHAR(300) NOT NULL', 'blob_url NVARCHAR(400) NULL', 'mime NVARCHAR(100) NULL', 'source NVARCHAR(30) NULL', DATA, WHO], 'uploads, faxes, generated PDFs (bytes in Azure Blob Storage)'),
 T('core.fact', [ID, TEN, 'subject_id NVARCHAR(80) NOT NULL', 'fact_key NVARCHAR(80) NOT NULL', 'value NVARCHAR(400) NULL', 'by_name NVARCHAR(200) NULL', 'at DATETIME2(3) NOT NULL'], 'time stamps per visit/case'),
 T('core.flag', [ID, TEN, 'patient_id UNIQUEIDENTIFIER NULL', 'subject_id NVARCHAR(80) NULL', 'to_team NVARCHAR(40) NOT NULL', 'text NVARCHAR(1000) NOT NULL', "status NVARCHAR(10) NOT NULL DEFAULT N'open'", DATA, WHO], ''),
 T('core.audit_event', ['id BIGINT IDENTITY PRIMARY KEY', TEN, 'subject_id NVARCHAR(80) NULL', 'action NVARCHAR(80) NOT NULL', 'detail NVARCHAR(2000) NOT NULL', 'user_name NVARCHAR(200) NOT NULL', 'role NVARCHAR(60) NULL', 'at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME()'], 'append-only (no UPDATE/DELETE grants)'),
 T('sched.appointment', [ID, TEN, PAT, 'provider_id UNIQUEIDENTIFIER NULL REFERENCES core.provider(id)', 'starts_at DATETIME2 NOT NULL', 'duration_min INT NOT NULL', 'room NVARCHAR(40) NULL', 'visit_type NVARCHAR(80) NOT NULL', "mode NVARCHAR(10) NOT NULL DEFAULT N'office'", 'reason NVARCHAR(400) NULL', 'step NVARCHAR(20) NOT NULL', DATA, WHO], 'office visits (Surgery, Medical); ASC cases stay in asc.surgical_case'),
 T('sched.reminder', [ID, TEN, 'appointment_id UNIQUEIDENTIFIER NOT NULL', 'channel NVARCHAR(10) NOT NULL', 'sent_at DATETIME2 NOT NULL', 'result NVARCHAR(40) NULL', DATA], ''),
 T('chart.item', [ID, TEN, PAT, "kind NVARCHAR(20) NOT NULL CHECK (kind IN (N'problem', N'medication', N'allergy', N'vitals', N'lab', N'intake', N'care_plan', N'caregiver', N'surgical_history', N'order'))", "status NVARCHAR(20) NULL", 'recorded_at DATETIME2 NOT NULL', DATA, WHO], 'clinical lists; one row per item (split per kind later if reporting needs it)'),
 T('chart.note', [ID, TEN, PAT, 'subject_id NVARCHAR(80) NULL', "kind NVARCHAR(20) NOT NULL", "status NVARCHAR(10) NOT NULL DEFAULT N'draft'", 'signed_by NVARCHAR(200) NULL', 'signed_at DATETIME2 NULL', 'content_hash NVARCHAR(80) NULL', DATA, WHO], 'visit notes, scribe drafts, jots, contact notes; signed notes are locked, corrections are addenda'),
 T('chart.surgical_plan', [ID, TEN, PAT, 'visit_id UNIQUEIDENTIFIER NULL', 'document_id UNIQUEIDENTIFIER NULL REFERENCES core.document(id)', 'procedure_name NVARCHAR(300) NULL', 'surgeon NVARCHAR(200) NULL', 'marked_blob_url NVARCHAR(400) NULL', 'base_photo_blob_url NVARCHAR(400) NULL', 'plan_json NVARCHAR(MAX) NULL CHECK (plan_json IS NULL OR ISJSON(plan_json) = 1)', DATA, WHO], 'Surgical Planning module: markings, measurements and calibration in plan_json; images in Azure Blob Storage'),
 T('stations.station_record', [ID, TEN, 'subject_id NVARCHAR(80) NOT NULL', 'station NVARCHAR(30) NOT NULL', DATA, WHO, 'CONSTRAINT uq_station_record UNIQUE (tenant_id, subject_id, station)'], 'one per visit/case per station (ASC and office)'),
 T('stations.station_record_value', ['id BIGINT IDENTITY PRIMARY KEY', 'record_id UNIQUEIDENTIFIER NOT NULL REFERENCES stations.station_record(id)', 'item_key NVARCHAR(120) NOT NULL', 'value_json NVARCHAR(MAX) NULL', "source NVARCHAR(6) NOT NULL", 'heard_quote NVARCHAR(1000) NULL', 'confirmed BIT NOT NULL DEFAULT 1', 'by_name NVARCHAR(200) NULL', 'at DATETIME2(3) NOT NULL'], 'every answer change (talk/manual), append-only'),
 T('stations.station_signoff', [ID, 'record_id UNIQUEIDENTIFIER NOT NULL REFERENCES stations.station_record(id)', "sign_key NVARCHAR(40) NOT NULL DEFAULT N'main'", 'by_name NVARCHAR(200) NOT NULL', 'role NVARCHAR(60) NOT NULL', 'at DATETIME2(3) NOT NULL', 'exceptions_json NVARCHAR(MAX) NULL'], 'PIN signatures'),
 T('stations.checklist_version', [ID, TEN, 'station NVARCHAR(30) NOT NULL', 'version INT NOT NULL', 'items_json NVARCHAR(MAX) NOT NULL', 'published_by NVARCHAR(200) NOT NULL', 'published_at DATETIME2 NOT NULL'], 'facility items per station, append-only versions'),
 T('forms.form_template', [ID, TEN, 'file NVARCHAR(200) NOT NULL', 'title NVARCHAR(300) NOT NULL', 'published_version INT NULL', DATA, WHO], 'form library; versions in forms.form_template_version'),
 T('forms.form_instance', [ID, TEN, PAT, 'subject_id NVARCHAR(80) NULL', 'file NVARCHAR(200) NOT NULL', 'template_version INT NULL', "status NVARCHAR(20) NOT NULL", DATA, WHO], 'a filled form; signatures in forms.form_signature'),
 T('bank.answer', [ID, TEN, PAT, 'question_id NVARCHAR(20) NOT NULL', 'value NVARCHAR(MAX) NULL', 'source NVARCHAR(20) NOT NULL', 'station NVARCHAR(4) NULL', 'by_name NVARCHAR(200) NULL', 'at DATETIME2(3) NOT NULL', 'confirms_json NVARCHAR(MAX) NULL'], 'question bank answers, once per patient (office) or case (ASC)'),
 T('bank.practice_override', [TEN + ' PRIMARY KEY', 'groups_json NVARCHAR(MAX) NOT NULL', 'overrides_json NVARCHAR(MAX) NOT NULL', 'version INT NOT NULL', WHO], ''),
 T('billing.quote', [ID, TEN, PAT, 'number NVARCHAR(40) NOT NULL', 'status NVARCHAR(20) NOT NULL', 'total DECIMAL(12,2) NOT NULL', DATA, WHO], 'versions inside data_json'),
 T('billing.invoice', [ID, TEN, PAT, 'number NVARCHAR(40) NOT NULL', 'total DECIMAL(12,2) NOT NULL', 'paid DECIMAL(12,2) NOT NULL DEFAULT 0', 'status NVARCHAR(30) NOT NULL', DATA, WHO], ''),
 T('billing.payment', [ID, TEN, PAT, 'receipt NVARCHAR(40) NOT NULL', 'amount DECIMAL(12,2) NOT NULL', 'method NVARCHAR(20) NOT NULL', 'processor_ref NVARCHAR(100) NULL', DATA, WHO], 'no card numbers: processor tokens only'),
 T('msg.message', [ID, TEN, 'patient_id UNIQUEIDENTIFIER NULL', 'thread_id NVARCHAR(80) NULL', 'author NVARCHAR(200) NOT NULL', 'body NVARCHAR(MAX) NOT NULL', 'at DATETIME2(3) NOT NULL', DATA], ''),
 T('notify.outbox', [ID, TEN, 'channel NVARCHAR(10) NOT NULL', 'to_address NVARCHAR(400) NOT NULL', 'subject NVARCHAR(400) NULL', 'body NVARCHAR(MAX) NOT NULL', 'kind NVARCHAR(40) NOT NULL', "status NVARCHAR(20) NOT NULL DEFAULT N'queued'", 'sent_at DATETIME2 NULL', WHO], 'email / SMS / fax queue (2 PM schedule email: kind = daily-schedule)'),
 T('surgery.episode', [ID, TEN, PAT, 'surgeon_id UNIQUEIDENTIFIER NULL REFERENCES core.provider(id)', 'status NVARCHAR(30) NOT NULL', 'asc_tenant_id NVARCHAR(64) NULL', 'asc_case_id UNIQUEIDENTIFIER NULL', DATA, WHO], 'consult to surgery to post-op in the surgeon\'s office; links to the ASC case by explicit hand-off'),
 T('portal.account', [ID, 'email NVARCHAR(320) NOT NULL UNIQUE', 'identity_subject NVARCHAR(200) NULL', DATA, WHO], 'the patient\'s own account (not owned by a practice)'),
 T('portal.practice_link', ['account_id UNIQUEIDENTIFIER NOT NULL REFERENCES portal.account(id)', TEN, 'patient_id UNIQUEIDENTIFIER NOT NULL', 'scopes NVARCHAR(400) NOT NULL', 'granted_at DATETIME2 NOT NULL', 'revoked_at DATETIME2 NULL', 'PRIMARY KEY (account_id, tenant_id)'], 'consent: which practices may deliver to / read from the account'),
 T('portal.item', [ID, 'account_id UNIQUEIDENTIFIER NOT NULL REFERENCES portal.account(id)', TEN, "kind NVARCHAR(20) NOT NULL", "direction NVARCHAR(10) NOT NULL CHECK (direction IN (N'practice', N'patient'))", 'title NVARCHAR(300) NOT NULL', 'body NVARCHAR(MAX) NULL', 'amount DECIMAL(12,2) NULL', 'status NVARCHAR(20) NOT NULL', 'answers_json NVARCHAR(MAX) NULL', 'reply_to UNIQUEIDENTIFIER NULL', DATA, WHO], 'forms, check-in, bills, messages, results, refills, appointment requests between a practice and a patient'),
 T('portal.interaction', ['seq BIGINT IDENTITY PRIMARY KEY', 'account_id UNIQUEIDENTIFIER NOT NULL', 'tenant_id NVARCHAR(64) NULL', 'actor NVARCHAR(200) NOT NULL', "role NVARCHAR(10) NOT NULL", 'action NVARCHAR(60) NOT NULL', 'item_id UNIQUEIDENTIFIER NULL', 'detail NVARCHAR(2000) NOT NULL', 'at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME()'], 'append-only Portal history (no UPDATE/DELETE grants)'),
 T('portal.upload_link', ['token NVARCHAR(64) NOT NULL PRIMARY KEY', 'account_id UNIQUEIDENTIFIER NOT NULL REFERENCES portal.account(id)', 'recipient NVARCHAR(300) NOT NULL', 'expires_at DATETIME2 NOT NULL', 'uploads INT NOT NULL DEFAULT 0', 'revoked_at DATETIME2 NULL', WHO], 'a link a patient gives an outside doctor to upload records'),
 T('portal.notification', [ID, 'to_account_id UNIQUEIDENTIFIER NOT NULL', 'profile_account_id UNIQUEIDENTIFIER NOT NULL', 'kind NVARCHAR(20) NOT NULL', 'text NVARCHAR(1000) NOT NULL', 'read_at DATETIME2 NULL', 'at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME()'], 'to the patient and each active caregiver'),
 T('portal.caregiver_access', [ID, 'owner_account_id UNIQUEIDENTIFIER NOT NULL REFERENCES portal.account(id)', 'caregiver_account_id UNIQUEIDENTIFIER NULL', 'email NVARCHAR(320) NOT NULL', 'relation NVARCHAR(40) NOT NULL', 'consent_text NVARCHAR(2000) NOT NULL', "status NVARCHAR(10) NOT NULL", 'invited_at DATETIME2 NOT NULL', 'accepted_at DATETIME2 NULL', 'revoked_at DATETIME2 NULL'], 'family access with the signed consent'),
 '/* Row-level security: every query runs with SESSION_CONTEXT(N\'tenant_id\') set by the API from the signed-in user. */\nCREATE SCHEMA sec; GO\nCREATE FUNCTION sec.fn_tenant(@tenant_id NVARCHAR(64)) RETURNS TABLE WITH SCHEMABINDING AS RETURN SELECT 1 AS ok WHERE @tenant_id = CAST(SESSION_CONTEXT(N\'tenant_id\') AS NVARCHAR(64));\nGO\n/* Apply to each table: CREATE SECURITY POLICY sec.tenant_policy ADD FILTER PREDICATE sec.fn_tenant(tenant_id) ON core.patient, ADD BLOCK PREDICATE sec.fn_tenant(tenant_id) ON core.patient, ... WITH (STATE = ON); */',
]
open(os.path.join(root, 'db', 'vityls_v11_core_modules_azure_sql.sql'), 'w').write('\n\n'.join(P2).replace('; GO', ';\nGO') + '\n')

DOC = f"""# Vityls OS v11.4 · Database connectivity handoff (Azure SQL)

For Henry. One app, one database, every edition. All data in the test builds is fictional.

## 1. What changed in v11.2, v11.3 and v11.4

- **v11.4 · Patient Portal (vityls.com) on the same database.** The Portal is patient-owned, so its records sync under their own tenant, **`portal`**, not under a practice: keys `vityls:portal:*` (accounts, links, items, history, notifications, caregivers, upload links). Every app opens two sync channels: its practice tenant and `portal`; sign-in sessions and the profile being viewed stay on the device. Phase 2 tables: `portal.account`, `portal.practice_link`, `portal.item`, `portal.interaction`, `portal.notification`, `portal.caregiver_access` (section 5). A practice reads a patient's Portal data only through an active `portal.practice_link` (consent); in production that check runs in the API, and the Portal signs in with Entra ID B2C (the test build keeps demo passwords in the account record).

- **v11.3 · Surgical Planning module.** Plans are saved under the record key `planner-plans` and map to the new table `chart.surgical_plan` (see section 5). Each plan has two images: the marked image and the unmarked base photo. Today both stay in the browser (IndexedDB keys `plan:<id>` and `planphoto:<id>`) and are **not** sent to the API; they move to Azure Blob Storage, with the URLs in `marked_blob_url` / `base_photo_blob_url`. Each saved plan is also filed as a `core.document` of type \"Surgical plan\".

- **One app.** The build `Vityls_OS_v11.4` runs ASC, Surgery and Medical. The practice record decides the edition when the app loads (`core/practices.ts › runtime`). In production the practice comes from the signed-in user's membership; in the test build there is a practice switcher (bottom right). The three per-edition builds are still produced from the same source for testing.
- **Connected to a database.** The app saves every record to the browser cache (it reads synchronously, offline-first) **and** to the Vityls record store API. On load it fetches the practice's records first; every change goes to the API in batches; every 15 seconds it pulls changes made on other devices. A "Database · saved" badge shows the state.
- **Server.** `server.ts` serves `/api/v1/store` and stores records in **Azure SQL** when `AZURE_SQL_CONNECTION_STRING` is set (tables `app.record`, `app.record_history`, created on first start), otherwise in `data/vityls-store.json` for development.

## 2. Run it

```
npm install
# development (JSON file store), one app with the demo practices:
VITE_ONE=1 VITE_EDITION=ASC2 VITE_DEMO=1 npx tsx server.ts        # http://localhost:3000/?api=/api
# Azure SQL:
AZURE_SQL_CONNECTION_STRING="Server=tcp:<server>.database.windows.net,1433;Database=vityls;User Id=...;Password=...;Encrypt=true" \\
VITYLS_API_TOKEN=<shared secret for the test> VITE_ONE=1 VITE_EDITION=ASC2 npx tsx server.ts
```

The app connects when it is opened with `?api=<url>` (remembered on the device; `?api=off` turns it off), or when built with `VITE_API_URL`. A packaged file can point at a remote API: `index.html?api=https://api.example.com/api` (CORS is open to the calling origin).

## 3. API (v1)

| Method | Path | Body / query | Returns |
|---|---|---|---|
| GET | `/api/v1/health` | | `{{ ok, backend }}` |
| GET | `/api/v1/store` | `?since=ISO` (optional) | `{{ items: [{{ k, v, at, by }}], now }}`: all records of the tenant, or those changed since |
| PUT | `/api/v1/store` | `{{ items: [{{ k, v | null }}], by }}` | `{{ ok, at }}`: upsert / delete in one transaction, history row per change |
| POST | `/api/v1/store-beacon` | same as PUT plus `tenant` | 204: last-moment save when a tab closes |

Headers: `X-Vityls-Tenant: <practice id>`, `Authorization: Bearer <VITYLS_API_TOKEN>` when set.

**Before real patient data** (what the test build does not do yet):
1. Tenant from the identity token, never from a header; enforce with row-level security (`sec.fn_tenant`, see phase 2 SQL).
2. Sign-in (Entra ID / Azure AD B2C), per-user tokens; PIN signatures checked on the server.
3. Blobs (photos, uploads, PDFs, surgical plan images) to Azure Blob Storage; today they live in the browser (IndexedDB / data URLs).
4. TLS only, BAA with Microsoft, Azure SQL TDE + backups + point-in-time restore, audit table append-only (no UPDATE/DELETE grants).
5. Conflicts: today last write wins per record; move hot records (visits, station records) to row-level tables (phase 2) first.

## 4. Phase 2: normalized tables (one database, every edition)

`db/vityls_v11_core_modules_azure_sql.sql` adds schemas **core, sched, chart, stations, forms, bank, billing, msg, notify, office, surgery, portal**; the ASC perioperative schema from v10.8 (`db/asc_vityls_v10_6_azure_sql.sql`, schema `asc`) stays as delivered. Every table has `tenant_id`, typed key columns and `data_json` with the full record, so each record family can move from `app.record` to its table one at a time behind the same API, without changing the screens.

## 5. Record key → table map

Generated from the record store after opening ASC, Surgery and Medical (`scripts/gen_db_v11.py`). Keys are shown without the practice namespace prefix (`vityls-asc2~`, `vityls-surgery~`, `vityls-medical~`).

| Record key | Editions | Module | Phase 2 table | What it holds |
|---|---|---|---|---|
{md_map}

Not migrated (seed markers, demo switches, test probes; device-only): {', '.join(f'`{k}`' for k in skip)}.
"""
open(os.path.join(root, 'DATABASE_HANDOFF_v11.md'), 'w').write(DOC)
print('rows', len(rows), 'review', sum(1 for c, k, v in rows if c[0] == 'review'))
for c, k, v in rows:
  if c[0] == 'review': print('  review:', k)
