set -e
VER=${VER:-v11.4}
# Vityls OS v11: one codebase, three editions built from the same core (station engine, Nightingale box, next steps).
cd "$(dirname "$0")/.."
python3 scripts/gen_os_scope.py
VITE_EDITION=ASC2 VITE_CORE_ASC=1 npx vite build --outDir dist-asc10 >/tmp/v11asc.log 2>&1 || { tail -30 /tmp/v11asc.log; exit 1; }
DIST=dist-asc10 OUT=ASC_Vityls_${VER} node scripts/package-surgery.mjs
sed -i "0,/<title>[^<]*<\/title>/s##<title>ASC.Vityls ${VER}</title>#" release/ASC_Vityls_${VER}/index.html
VITE_EDITION=SURGERY npx vite build --outDir dist-surgery11 >/tmp/v11surg.log 2>&1 || { tail -30 /tmp/v11surg.log; exit 1; }
DIST=dist-surgery11 OUT=Surgery_Vityls_${VER} node scripts/package-surgery.mjs
sed -i "0,/<title>[^<]*<\/title>/s##<title>Surgery.Vityls ${VER} — test build (fictional data)</title>#" release/Surgery_Vityls_${VER}/index.html
VITE_EDITION=MEDICAL npx vite build --outDir dist-medical11 >/tmp/v11med.log 2>&1 || { tail -30 /tmp/v11med.log; exit 1; }
DIST=dist-medical11 OUT=Medical_Vityls_${VER} node scripts/package-medical.mjs
sed -i "0,/<title>[^<]*<\/title>/s##<title>Medical.Vityls ${VER} — test build (fictional data)</title>#" release/Medical_Vityls_${VER}/index.html
# One app: every edition, the practice record decides (Vityls OS). Connects to the database with ?api=<url>.
VITE_ONE=1 VITE_EDITION=ASC2 VITE_DEMO=1 npx vite build --outDir dist-one >/tmp/v11one.log 2>&1 || { tail -30 /tmp/v11one.log; exit 1; }
DIST=dist-one OUT=Vityls_OS_${VER} TITLE="Vityls OS ${VER} — one app: ASC, Surgery, Medical (fictional data)" node scripts/package-core.mjs
# Vityls Patient Portal for vityls.com: the same one-app core, opens the patient Portal by default (?practice=<id> opens a practice).
VITE_PORTAL=1 VITE_ONE=1 VITE_EDITION=ASC2 VITE_DEMO=1 npx vite build --outDir dist-portal >/tmp/v11portal.log 2>&1 || { tail -30 /tmp/v11portal.log; exit 1; }
DIST=dist-portal OUT=Vityls_Portal_${VER} TITLE="Vityls Patient Portal ${VER} (fictional data)" node scripts/package-core.mjs
python3 scripts/gen_db_v11.py
