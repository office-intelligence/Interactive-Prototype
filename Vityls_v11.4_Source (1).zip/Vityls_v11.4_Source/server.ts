import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

import { makeBackend, Backend } from "./server/store";

dotenv.config();

const app = express();
const PORT = Number(process.env.PORT || 3000);

app.use(express.json({ limit: "25mb" }));

/* ---------------- Vityls OS v11.2 · record store API (database connectivity) ----------------
 * GET  /api/v1/store[?since=ISO]   -> { items: [{ k, v, at, by }], now }   all records of the tenant (or changes since)
 * PUT  /api/v1/store { items: [{ k, v|null }], by } -> { ok, at }      upsert / delete, one transaction
 * GET  /api/v1/health               -> { ok, backend }
 * Tenant = X-Vityls-Tenant header (the practice id). If VITYLS_API_TOKEN is set, Authorization: Bearer <token> is required.
 * In production the tenant comes from the signed-in user's token (Henry's identity service), never from the browser. */
const store: Backend = makeBackend(); let storeReady: Promise<void> = store.init().catch(e => { console.error("Record store failed to start:", e); });
app.use("/api/v1", (req, res, next) => {
  res.setHeader("Access-Control-Allow-Origin", req.headers.origin || "*"); res.setHeader("Vary", "Origin");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization, X-Vityls-Tenant"); res.setHeader("Access-Control-Allow-Methods", "GET, PUT, OPTIONS");
  if (req.method === "OPTIONS") return res.sendStatus(204);
  const tok = process.env.VITYLS_API_TOKEN; if (tok && req.headers.authorization !== `Bearer ${tok}`) return res.status(401).json({ error: "unauthorized" });
  next();
});
const tenantOf = (req: express.Request) => String(req.headers["x-vityls-tenant"] || "default").replace(/[^a-z0-9_.-]/gi, "").slice(0, 64) || "default";
app.post("/api/v1/store-beacon", express.text({ type: "*/*", limit: "25mb" }), async (req, res) => { try { await storeReady; const b = JSON.parse(String(req.body || "{}")); const items = Array.isArray(b.items) ? b.items.filter((i: any) => typeof i?.k === "string" && (i.v === null || typeof i.v === "string")) : [];
  if (items.length) await store.put(String(b.tenant || "default").replace(/[^a-z0-9_.-]/gi, "").slice(0, 64) || "default", items, "Vityls app (page closed)"); res.sendStatus(204); } catch { res.sendStatus(400); } });
app.get("/api/v1/health", async (_req, res) => { await storeReady; res.json({ ok: true, backend: store.name, at: new Date().toISOString() }); });
app.get("/api/v1/store", async (req, res) => { try { await storeReady; const since = typeof req.query.since === "string" ? req.query.since : undefined; res.json({ items: await store.list(tenantOf(req), since), now: new Date().toISOString() }); } catch (e: any) { res.status(500).json({ error: String(e?.message || e) }); } });
app.put("/api/v1/store", async (req, res) => { try { await storeReady; const items = Array.isArray(req.body?.items) ? req.body.items.filter((i: any) => typeof i?.k === "string" && i.k.length <= 400 && (i.v === null || typeof i.v === "string")) : [];
  if (!items.length) return res.json({ ok: true, at: new Date().toISOString() }); const at = await store.put(tenantOf(req), items, String(req.body?.by || "Vityls app").slice(0, 200)); res.json({ ok: true, at }); } catch (e: any) { res.status(500).json({ error: String(e?.message || e) }); } });

// Initialize Gemini client lazily
function getGenAI() {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) return null;
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        "User-Agent": "aistudio-build",
      },
    },
  });
}

// Health check
app.get("/api/health", (req, res) => {
  res.json({ status: "ok", timestamp: new Date().toISOString() });
});

// Nightingale AI Chat Endpoint
app.post("/api/ai/chat", async (req, res) => {
  try {
    const { message, context } = req.body;
    const ai = getGenAI();

    if (!ai) {
      // Intelligent fallback response if API key is not yet set
      return res.json({
        reply: `[Nightingale AI Local Intelligence] Analyzing schedule context: ${message}\n\nKey Recommendation: Patricia DePoli's EKG is pending for her 8:00 AM Blepharoplasty in OR 1. I recommend fast-tracking cardiology sign-off or prepping backup clearance to prevent a 25-minute turnaround delay for Sophia Diaz at 8:45 AM.`,
        sources: ["Pre-Op Clearance Protocol", "OR 1 Schedule Map"],
      });
    }

    const systemInstruction = `You are Nightingale AI, an advanced AI Clinical & Operational Assistant for the active Vityls practice.
You specialize in Outpatient Surgical Center (ASC) office efficiency, patient arrival prioritization, pre-op readiness tracking, and OR turnover optimization.
Provide concise, actionable, professional advice for surgical coordinators, charge nurses, and practice owners.
When given schedule context, highlight potential bottlenecks, missing labs/EKG/consents, and room allocation risks.`;

    const prompt = `Schedule Context: ${JSON.stringify(context || {})}\n\nUser Question: ${message}`;

    const response = await ai.models.generateContent({
      model: "gemini-3.6-flash",
      contents: prompt,
      config: {
        systemInstruction,
        temperature: 0.7,
      },
    });

    res.json({
      reply: response.text || "No response generated.",
      sources: ["Nightingale Clinical Rules Engine", "Vityls EHR"],
    });
  } catch (error: any) {
    console.error("AI Chat Error:", error);
    res.status(500).json({ error: error.message || "Failed to generate response" });
  }
});

// AI Schedule Bottleneck & Prioritization Analyzer
app.post("/api/ai/analyze-bottlenecks", async (req, res) => {
  try {
    const { schedule } = req.body;
    const ai = getGenAI();

    if (!ai) {
      // Rich default AI analysis output
      return res.json({
        bottlenecks: [
          {
            id: "b1",
            patientId: "113850",
            patientName: "Patricia DePoli",
            severity: "high",
            title: "Missing EKG & Pre-Op Photo Review (8:00 AM Case - OR 1)",
            impact: "High risk of 20-30 min OR 1 start delay affecting subsequent cases.",
            recommendation: "Immediate phone outreach to Beverly Hills Cardiology for faxed EKG. Notify Dr. Guy Massry.",
            actionType: "REQUEST_EKG",
          },
          {
            id: "b2",
            patientId: "114202",
            patientName: "Danielle Weaver",
            severity: "medium",
            title: "Pre-Op Transport Prep Ready (7:00 AM Case - OR 1)",
            impact: "Patient cleared; delay in transfer to OR 1 will reduce OR turnover buffer.",
            recommendation: "Initiate Pre-Op Bay 2 transport call to surgical team.",
            actionType: "TRANSPORT_OR",
          },
        ],
        prioritizedArrivals: [
          { patientId: "114202", name: "Danielle Weaver", priorityRank: 1, readinessScore: 98, status: "IN_PRE_OP" },
          { patientId: "113850", name: "Patricia DePoli", priorityRank: 2, readinessScore: 65, status: "ARRIVING_NEEDS_ATTENTION" },
          { patientId: "114091", name: "Sophia Diaz", priorityRank: 3, readinessScore: 95, status: "ON_SCHEDULE" },
          { patientId: "114036", name: "Holly Radom", priorityRank: 4, readinessScore: 100, status: "ON_SCHEDULE" },
          { patientId: "113974", name: "Ashlee Fishman", priorityRank: 5, readinessScore: 92, status: "IMPLANT_VERIFIED" },
        ],
      });
    }

    const prompt = `Analyze this ASC surgery schedule and identify workflow bottlenecks, arrival priorities, and risk mitigations.
Schedule Data: ${JSON.stringify(schedule)}
Return JSON with format:
{
  "bottlenecks": [{"id": "b1", "patientName": "...", "severity": "high|medium|low", "title": "...", "impact": "...", "recommendation": "...", "actionType": "..."}],
  "prioritizedArrivals": [{"patientId": "...", "name": "...", "priorityRank": 1, "readinessScore": 85, "status": "..."}]
}`;

    const response = await ai.models.generateContent({
      model: "gemini-3.6-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
      },
    });

    const parsed = JSON.parse(response.text || "{}");
    res.json(parsed);
  } catch (err: any) {
    console.error("Bottleneck Analysis Error:", err);
    res.status(500).json({ error: "Failed to perform AI analysis" });
  }
});

// Vite server in dev or static files in production
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Office Intelligence Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
