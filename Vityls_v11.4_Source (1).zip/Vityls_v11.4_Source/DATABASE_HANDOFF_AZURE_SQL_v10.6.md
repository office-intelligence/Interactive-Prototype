# ASC.Vityls v10.7: Database handoff for Azure SQL

**For:** Henry (Microsoft / Azure / SQL)
**From:** Kevin, Office Intelligence
**Build:** ASC_Vityls_v10.6 (React 19 + Vite 6; edition `VITE_EDITION=ASC2 VITE_CORE_ASC=1`)
**Companion file:** `db/asc_vityls_v10_6_azure_sql.sql` holds the complete T-SQL DDL described below.

---

## 1. Where the data lives today

The test build has no server database. Every record sits in the browser's `localStorage`, and all the data is fictional.

- **Key prefix:** every key starts with `vityls:surgery:`.
- **Access layer:** all reads and writes go through two functions in `src/surgery/store.ts`, `svRead(key, fallback)` and `svWrite(key, value)`. That makes them the seam to replace with API calls.
- **Audit:** every clinical or billing action calls `repo.audit({ caseId, user, role, action, detail })` in `src/v6/dataLayer.ts`.
- **Refresh:** screens listen for the `vityls-med-updated` event. With a server, this becomes a SignalR push (see §6).

**Recommended migration path:**
1. Implement the tables in §3–§4.
2. Expose the REST endpoints in §5.
3. Swap `svRead`/`svWrite` for a repository class per key family (the mapping is in §7).

The UI does not need to change.

## 2. Conventions

| Topic | Decision |
|---|---|
| Engine | Azure SQL Database (General Purpose or Business Critical), compatibility level 160 |
| Keys | `UNIQUEIDENTIFIER` PKs with `DEFAULT NEWSEQUENTIALID()`. Keep the app's string IDs (e.g. `c4`, `note-…`) in a `legacy_id` column during migration. |
| Time | All instants are `DATETIME2(3)` in UTC (`SYSUTCDATETIME()`). Dates of service are `DATE`. Clock times entered at stations (e.g. "07:34 AM") are stored as `TIME(0)` plus the original text. |
| Tenancy | Every table carries `facility_id`. Enforce isolation with Row-Level Security (a security predicate on `facility_id = SESSION_CONTEXT(N'facility_id')`). |
| Who did it | `*_by_user_id` + `*_by_role` (the role the person acted as at that moment) on every write, matching what the app records. |
| Flexible case data | `surgical_case.d` is a key/value map in the app. Store it in `case_item_value` (one row per item, value in `NVARCHAR(MAX)` with `ISJSON` check). Promote fields to columns only when they are reported on. |
| Files | Document bytes, scans, images and drawn signatures go to **Azure Blob Storage** (private container, per-facility path). SQL stores the blob URI, SHA-256, MIME type and size. Nothing binary goes in SQL. |
| Audit | `audit_log` is an **append-only ledger table** (`LEDGER = ON (APPEND_ONLY = ON)`), so tampering is detectable. Sign-offs, consents, reviews, annotations and sent invoices are also append-only. Corrections are new rows that reference the old row. |
| Security | Entra ID authentication only. TDE (on by default). Auditing to Log Analytics. Microsoft Defender for SQL. Private endpoint. Consider Always Encrypted for DOB, phone and email if policy requires. |
| PHI | All tables below may hold PHI once real data is used. Sign the Microsoft BAA before going live. |

## 3. Core tables (existing v10.5 features)

**Practice & people**
- `facility`: name, address, phone, email, logo blob URI, time zone (feeds the invoice letterhead). Key: `asc88-facility`.
- `room`: OR 1–3, Proc 1, and so on.
- `app_user`: Entra object ID, display name, initials, primary role, PIN hash (bcrypt/Argon2 only, never the PIN).
- `provider`: surgeons and anesthesia providers, with an email for invoices (used by `findProvider`).
- `patient`: name, DOB, sex, phone, email, language, insurance text, emergency contact, allergies confirmed at/by.
- `patient_allergy`: one row per allergy.

**Cases & workflow**
- `surgical_case`: patient, DOS, booked start, duration, room, surgeon, anesthesia provider, procedure, CPT, side, `loc` (`scheduled | arrived | preop | or | pacu | discharged | closed`), pay type.
- `case_event`: OR times (`inRoom, anesStart, incision, close, anesEnd, outRoom, pacuIn, pacuOut`). Edits keep the old value and a required reason.
- `case_item_value`: every checklist item and value (`forms`, `financial`, `insurance`, `clearance`, `labs`, `id`, `vitals`, `npo`, `iv`, `sitecheck`, `exceptions`, …) with who and when.
- `station_signoff`: the PIN signature per station. Includes `exceptions_json`, the items left open, which become flags.
- `case_cancellation`, `schedule_history`: booking, reschedule and cancel history.

**Forms & signatures**
- `form_template`: the form library, with its station assignment and HTML template.
- `case_form`: a filled form per case.
- `signature`: drawn-signature blob plus PIN-verified signer, for consents and forms.

**Standard orders (Practice settings → per surgeon)**
- `surgeon_order_list` and `surgeon_order_item`: versioned pre-op and post-op lists. When a surgeon has no list of their own, the facility standard applies.
- `case_order_list` and `case_order_item`: the snapshot taken when the case is booked, plus one-off items.
- `case_order_tick`: time, initials and user for each tick.

**Medical history**
- `case_medical_history`: allergies, meds, conditions, surgical history, anesthesia history and notes, with a confirmed stamp.
- `case_medical_history_amendment`: before-JSON, reason, who.

**Documents**
- `document`: uploads and received records (H&P, labs, ECG, clearance, imaging, ID or insurance photos, receipts), with a blob URI, kind, source, station and DOS.
- `document_page`: per-page blob and extracted text, used by the Nightingale clearance brief.

**Flags & messages**
- `flag`: from, to team (or a person), case, text, status (`open | answered | closed`), reply.
- `outbox_message`: email or SMS, simulated today. The send goes to Azure Communication Services.

**Money**
- `fee_schedule`, `fee_time_rule` (facility and anesthesia base, included minutes, increment) and `fee_item`. Keys: `asc88-fees`, `asc89-billcfg`.
- `invoice` and `invoice_line`.
- `payment` and `payment_application`.
- `patient_credit` and `credit_application`.

**AI drafts**
- `ai_case_draft`: role summaries, the records brief and station cards (`asc81-ai`). These are always drafts; staff confirm.

**Chat**
- `chat_thread` and `chat_message`: Nightingale chats, including action-card JSON.

**Audit**
- `audit_log`: a ledger table (see §2).

## 4. New in v10.6 (from this round of changes)

| Table | Purpose | Device key today | Notes |
|---|---|---|---|
| `clearance_review` | "Reviewed & initialed" on a clearance document | `asc106-review` | One row per (case, document, user). Initials, role, timestamp. Append-only. |
| `document_annotation` | Pen, highlighter and initials-stamp marks on a document page | `asc106-marks` | Stroke points normalized to a 1000×1294 page box as JSON. Per user; "Clear mine" sets `voided_at` and never deletes. Clinical roles only. |
| `station_note` | Notes typed or dictated at any station, or said in chat | `asc106-notes` | Station, text, author, optional `flagged_to_team` (which also writes a `flag`). Shown in the chart, newest first. |
| `invoice_billing_plan` | When and to whom a case is billed | `asc106-billing` | `timing` = `pre` (14 days before DOS, booked minutes) or `post` (actual in/out-of-room minutes). `bill_to` = `patient`, `surgeon` or `both`. Default for cash/self-pay cases is pre/patient. |
| `invoice_delivery` | Each time an invoice is sent | `asc106-sent` | Recipients, addresses, timing, basis text ("91 recorded minutes"), total, invoice number. The outbox row links here. |
| `bedside_capture` | Talk-mode conversation and per-role drafts | `asc81-ai.bedside` | Transcript text (or a blob for real audio later), plus drafts JSON by role. Confirmations are audited. |
| `user_preference` | Essentials / Full record view, Standard / Talk mode, chat-only | `asc106-view`, `asc106-mode`, `v18-chatonly-*` | Per user (role defaults for chat-only in `role_preference`). |

**New in v10.7 (station checklists and the OR record):**

| Table | Purpose | Device key today | Notes |
|---|---|---|---|
| `station_checklist_version` | Each published version of a station's facility checklist | `asc107-checklists` | Append-only; draft kept separately until published. Standard items are code, not rows. |
| `station_checklist_item` | Facility items of a version | `asc107-checklists` | Control type, options, required, conditions (room, surgeon, procedure/CPT, anesthesia, age), Talk phrases, linked form field. |
| `case_checklist_pin` | The version a case uses at a station | `asc107-pins` | Set the first time the station opens for that case; later edits never change a started record. |
| `or_record_value` | Every answer in the OR intra-op record | `asc106-or` | Standard and facility items; source talk/manual, heard quote, confirmed flag. Signature goes to `station_signoff`. |

Fields of custom forms assigned to a station appear on its checklist automatically (computed from the form library), so they need no rows until a facility customizes them.

**Derived, not stored.** These are computed on read:
- Missing items: from checklist, documents and history.
- The front-desk invoice to-do: `sendBy = DOS − 14 days`, overdue when past and not sent.
- The "who's next" queue.
- Past-case views.

Create views or API projections for them instead of tables.

## 5. API surface (REST, `/api/v1`, Entra ID bearer tokens)

**Today & cases**
- `GET /cases?date=`
- `GET /cases/{id}`
- `PATCH /cases/{id}` (loc, room, time)
- `POST /cases/{id}/events` (stamp or edit an OR time, with reason)
- `PUT /cases/{id}/items/{key}`
- `POST /cases/{id}/signoffs` (PIN verified on the server)

**Orders**
- `GET /cases/{id}/orders?phase=`
- `POST /cases/{id}/orders/{itemId}/tick`
- `GET|PUT /surgeons/{id}/order-lists/{phase}`

**Documents**
- `POST /cases/{id}/documents`: returns a SAS upload URL; the browser uploads straight to Blob.
- `GET /documents/{id}/pages/{n}`: short-lived SAS read URL.
- `POST /documents/{id}/reviews`
- `GET|POST /documents/{id}/pages/{n}/annotations`
- `DELETE /annotations/{id}`: soft void, own marks only.

**Notes & flags**
- `GET|POST /cases/{id}/notes`
- `GET /flags?status=open`: everyone sees all flags.
- `POST /flags`
- `POST /flags/{id}/reply`

**Billing**
- `GET|PUT /cases/{id}/billing-plan`
- `POST /cases/{id}/invoices`: generated from the fee schedule. For post-surgery billing it uses actual minutes.
- `POST /invoices/{id}/send`: creates `invoice_delivery` and sends through Azure Communication Services Email, with a PDF rendered server-side.
- `POST /payments`
- `POST /credits`

**History & AI**
- `GET|PUT /cases/{id}/history`
- `POST /cases/{id}/history/amendments`
- `GET /cases/{id}/ai-drafts`
- `POST /cases/{id}/bedside`

**Chat & preferences**
- `GET|POST /chats`
- `POST /chats/{id}/messages`
- `GET|PUT /me/preferences`

**Audit**
- `GET /audit?caseId=`: read-only. The server writes audit rows inside the same transaction as each change.

## 6. Azure layout

- **Front end:** Azure Static Web Apps or App Service. The build is one `index.html` plus `/forms` and `/pdf-templates`.
- **API:** App Service (Node 20) or Azure Functions, with managed identity to SQL and Blob.
- **Database:** Azure SQL. Ledger enabled on `audit_log`. Automated backups with point-in-time restore; set long-term retention to policy (7+ years for medical records).
- **Other services:**
  - Blob Storage: private, versioning and soft delete on, immutability policy for signed documents.
  - Azure Communication Services: email and SMS.
  - SignalR Service: live refresh in place of `vityls-med-updated`.
  - Key Vault: secrets.
  - Application Insights: monitoring.
- **Scheduled job:** a daily timer (Functions) raises the invoice to-dos 14 days out and the post-op follow-up calls.

## 7. Device key → table map (for the migration script)

| Device key(s) | Table(s) |
|---|---|
| `asc8-cases` | `surgical_case`, `case_event`, `case_item_value` (from `d`), `audit_log` (from `audit[]`) |
| `asc8-flags` | `flag` |
| `asc8-outbox`, `asc81-outbox`, `records-outbox`, `pin-outbox` | `outbox_message` |
| `asc8-fees`, `asc88-fees`, `asc89-billcfg`, `billing-config` | `fee_schedule`, `fee_time_rule`, `fee_item` |
| `asc87-invoices` | `invoice`, `invoice_line` |
| `asc106-billing` | `invoice_billing_plan` |
| `asc106-sent` | `invoice_delivery` |
| `patient-payments`, `asc83-case-pay` | `payment`, `payment_application` |
| `asc89-credits` | `patient_credit`, `credit_application` |
| `asc87-uploads`, `documents`, `photos` | `document`, `document_page` (+ Blob) |
| `asc106-review` | `clearance_review` |
| `asc106-marks` | `document_annotation` |
| `asc106-notes` | `station_note` |
| `asc10-history` | `case_medical_history`, `case_medical_history_amendment` |
| `asc10-surgeon-lists`, `asc87-standing` | `surgeon_order_list`, `surgeon_order_item` |
| `asc10-case-lists` | `case_order_list`, `case_order_item`, `case_order_tick` |
| `asc10-briefop`, `asc83-op-full` | `case_form` (brief and full op report) |
| `asc82-sigs`, `signers-v011` | `signature` |
| `asc81-ai` | `ai_case_draft`, `bedside_capture` |
| `asc83-cancelled`, `asc89-schedule` | `case_cancellation`, `schedule_history` |
| `asc88-facility`, `asc-facilities` | `facility` |
| `form-lib`, `forms-packets`, `asc-packets` | `form_template` (add a `form_packet` table if packets stay a separate concept) |
| `fd-chats` | `chat_thread`, `chat_message` |
| `asc106-view`, `asc106-mode`, `v18-chatonly-user`, `v18-chatonly-roles` | `user_preference`, `role_preference` |
| `*-seeded`, `*-seed-*`, `img-*` | Demo seeding and caches only. Do not migrate. |

## 8. Open questions for Henry

1. **Tenancy:** one database per facility group, or a shared database with RLS (the DDL assumes shared + RLS)?
2. **Patient identity:** one patient per facility, or one per enterprise with a facility link? The DDL assumes enterprise-level `patient` plus `facility_patient`.
3. **PIN signing:** keep a PIN (verified server-side and rate-limited) or move to Entra re-authentication for sign-offs?
4. **Real ambient capture:** if Talk mode moves from simulated to real audio, we need a speech-to-text service decision (Azure AI Speech) and a retention rule for audio.
5. **Invoice PDF:** render server-side (recommended, keeps the letterhead consistent) or keep browser print?
