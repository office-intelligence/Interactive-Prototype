/* Vityls OS · Nightingale's next-step director (v11). Every edition registers one provider that reads the day and returns
 * the next steps of the patient journey: who it is for (team), what to do, why now, and how to open it. Today leads with
 * them, the chat box answers "what's next" from them, and stations hand off with them. Nothing is done automatically:
 * each step opens the station where a person does the work. */
export type Team = 'front' | 'nurse' | 'provider' | 'coord' | 'billing' | 'manager';
export interface NextStep { id: string; pid: string; vid?: string; name: string; team: Team; title: string; why: string; cta: string; when?: string; urgency: number; open: () => void }
export type NextProvider = (actor: { name: string; role: string }) => NextStep[];

let provider: NextProvider | null = null;
export const setNextProvider = (fn: NextProvider) => { provider = fn; };
export const nextSteps = (actor: { name: string; role: string }): NextStep[] => { try { return provider ? provider(actor).sort((a, b) => b.urgency - a.urgency) : []; } catch { return []; } };

export const TEAM_LABEL: Record<Team, string> = { front: 'Front desk', nurse: 'Nurse / MA', provider: 'Provider', coord: 'Coordinator', billing: 'Billing', manager: 'Manager' };
/** Which teams a role works for. Managers and administrators see everything. */
export function teamsOf(role: string): Team[] {
  const r = role.toLowerCase();
  if (/manager|administrator|owner/.test(r)) return ['front', 'nurse', 'provider', 'coord', 'billing', 'manager'];
  if (/surgeon|doctor|physician|\bmd\b|\bdo\b|practitioner|\bnp\b|\bpa\b|anesthes/.test(r)) return ['provider'];
  if (/assistant|\bma\b|\brn\b|nurse|lpn/.test(r)) return ['nurse'];
  if (/coordinator/.test(r)) return ['coord', 'front'];
  if (/billing/.test(r)) return ['billing', 'front'];
  return ['front'];
}
export const mineOnly = (l: NextStep[], actor: { name: string; role: string }) => { const t = teamsOf(actor.role); const isProv = t.length === 1 && t[0] === 'provider';
  return l.filter(s => t.includes(s.team) && (!isProv || !(s as any).provider || (s as any).provider === actor.name)); };
