/* Vityls OS · the one Nightingale chat box (v11). Moved here from ASC.Vityls v10.6.3 (asc106/ai106) so every edition uses
 * the same AI-first box at the bottom of every page. Answer order: the edition's brain (commands with action buttons and
 * Nightingale's next steps), then the page's own answerer (usePageAsk), then the edition's fallback. Draft answers only;
 * nothing is signed, ordered or sent from here. Fictional data. */
import React, { useEffect, useRef, useState } from 'react';
import { ArrowUp, Mic, Plus, X } from 'lucide-react';
import { useActor, useMedTick } from '../../med/ui';
import '../../surgery/asc106/ai106.css';
import './dock.css';

export interface Act { label: string; run: () => void; testId?: string; pri?: boolean }
export interface Reply { text: string; acts?: Act[]; render?: (ask: (q: string) => void) => React.ReactNode }
export interface AskCtx { actor: { name: string; role: string }; tab: string; patientId?: string; page: string }
export type Brain = (q: string, ctx: AskCtx) => Reply | null;

/** Pages hand the box their own answerer (schedule search, revenue and operations evaluations). */
const PAGE_ASK: { fn: ((q: string) => Reply | null) | null } = { fn: null };
export function usePageAsk<R extends Reply>(fn: (q: string) => R | null) { const ref = React.useRef(fn); ref.current = fn; React.useEffect(() => { const h = (q: string) => ref.current(q); PAGE_ASK.fn = h; return () => { if (PAGE_ASK.fn === h) PAGE_ASK.fn = null; }; }, []); }

export interface DockIds { root: string; input: string; go: string; answer: string; close: string; plus?: string; mic?: string }
export const ASC_IDS: DockIds = { root: 'n9-ask', input: 'n9-ask-input', go: 'n9-ask-go', answer: 'n9-ask-answer', close: 'n9-ask-close' };
export const OFFICE_IDS: DockIds = { root: 'flow-composer', input: 'nightingale-input', go: 'flow-composer-send', answer: 'nightingale-answer', close: 'nightingale-answer-close', plus: 'flow-composer-plus', mic: 'flow-composer-mic' };

export const AiDock: React.FC<{ tab: string; patientId?: string; page: string; placeholder: string; sample: string; brain: Brain; fallback: (q: string, ctx: AskCtx) => Reply; ids: DockIds; plus?: Act[]; onAsked?: (q: string, r: Reply) => void }> =
  ({ tab, patientId, page, placeholder, sample, brain, fallback, ids, plus, onAsked }) => {
  useMedTick(); const [actor] = useActor(); const [q, setQ] = useState(''); const [r, setR] = useState<(Reply & { q: string }) | null>(null); const [menu, setMenu] = useState(false);
  const inp = useRef<HTMLInputElement>(null);
  useEffect(() => { setR(null); }, [patientId, tab]);
  useEffect(() => { const f = (e: KeyboardEvent) => { const t = e.target as HTMLElement; if (e.key === '/' && !/input|textarea|select/i.test(t.tagName) && !t.isContentEditable) { e.preventDefault(); inp.current?.focus(); } }; window.addEventListener('keydown', f); return () => window.removeEventListener('keydown', f); }, []);
  const ask = (text: string) => { const t = text.trim(); if (!t) return; const ctx: AskCtx = { actor, tab, patientId, page };
    const x = brain(t, ctx) || (PAGE_ASK.fn && PAGE_ASK.fn(t)) || fallback(t, ctx); setR({ ...x, q: t }); setQ(''); onAsked?.(t, x); };
  return <div className="ai6-dock os-dock" data-testid={ids.root}><div className="fd-col">
    {r && <div className="ai6-ans fd-msg ng" data-testid={ids.answer} role="status"><div className="ai6-ah"><span className="who">Nightingale</span><span className="ai6-q">“{r.q}”</span><button type="button" className="ai6-x" aria-label="Close" onClick={() => setR(null)} data-testid={ids.close}><X size={16} /></button></div>
      <div className="ai6-text">{r.text}</div>
      {r.acts && r.acts.length > 0 && <div className="os-acts">{r.acts.map((a, i) => <button key={i} type="button" className={`os-act ${a.pri ? 'pri' : ''}`} onClick={() => { a.run(); setR(null); }} data-testid={a.testId || 'os-act'}>{a.label}</button>)}</div>}
      {r.render?.(ask)}</div>}
    {menu && plus && <div className="os-plus" role="menu">{plus.map((a, i) => <button key={i} type="button" role="menuitem" onClick={() => { setMenu(false); a.run(); }}>{a.label}</button>)}</div>}
    <form className="fd-box" role="search" onSubmit={e => { e.preventDefault(); ask(q); }}>
      {plus && <button type="button" className="fd-icon" aria-label="More actions" aria-expanded={menu} onClick={() => setMenu(x => !x)} data-testid={ids.plus}><Plus size={18} /></button>}
      <label htmlFor="os-ask" className="sr-only">Ask Nightingale</label>
      <input id="os-ask" ref={inp} value={q} onChange={e => setQ(e.target.value)} placeholder={placeholder} autoComplete="off" data-testid={ids.input} />
      <button type="button" className="fd-icon" aria-label="Voice (simulated)" title="Simulated: nothing is recorded" onClick={() => { setQ(sample); inp.current?.focus(); }} data-testid={ids.mic}><Mic size={17} /></button>
      <button type="submit" className="fd-send" aria-label="Send" data-testid={ids.go}><ArrowUp size={18} /></button>
    </form>
    <div className="fd-disc">On-device, from recorded data only. Nightingale never signs, orders or decides.</div>
  </div></div>;
};
