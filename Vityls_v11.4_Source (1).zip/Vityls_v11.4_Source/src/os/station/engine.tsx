/* Vityls OS · core station engine (v11). One station design for every edition: ASC, Surgery and Medical.
 * Moved here from ASC.Vityls v10.8 (asc108/native108) and made generic over the "subject" a station works on: an ASC case,
 * or an office visit. Everything edition-specific (how to load the subject, the journey bar, the patient card, uploads,
 * facility checklist items, flags, notes, "Before you sign") comes from the definition's adapter.
 *
 * A station is a definition: phases of checklist items (checkbox, tap buttons, chips, staff picker, number with quick values,
 * text, time stamp, item list, counts grid) plus "panel" items that host existing native pieces. Talk (ambient, simulated)
 * and Manual fill the same list; heard items wait for confirmation. Nightingale summarizes progress and names the next step.
 * Signatures (PIN) sit at the end, after notes and "Before you sign". Fictional data. */
import React, { useEffect, useState } from 'react';
import { Mic, PenLine, Check, Clock, Pause, Play, CheckCheck, X, ArrowRight } from 'lucide-react';
import { medRepo, isoDay, type MedPatient } from '../../med/record';
import { useActor, useMedTick } from '../../med/ui';
import { useSv } from '../../surgery/ui';
import { repo } from '../../v6/dataLayer';
import { svRead, svWrite } from '../../surgery/store';
import { PinSign } from '../../surgery/sign';
import { peopleIn } from '../../surgery/staff';
import { FacTag, type FacItem } from '../../surgery/asc107/checklists107';
import '../../surgery/asc106/or106.css';
import './station.css';
import './scope.css';

export type Kind = 'check' | 'radio' | 'multi' | 'select' | 'dropdown' | 'number' | 'text' | 'time' | 'list' | 'counts' | 'panel';
export interface Subject { id: string; pid: string }
export interface Actor { name: string; role: string }
export interface Item<T = any> { id: string; label: string | ((t: T) => string); kind: Kind; opts?: string[]; req?: boolean; event?: string; unit?: string; quick?: string[]; roles?: string[]; dflt?: (t: T) => any; fac?: FacItem; name?: string; long?: boolean;
  /** panel items: an existing native piece rendered in place; done() decides whether it counts as complete */
  render?: (t: T, ctx: { close: (m?: string) => void }) => React.ReactNode; done?: (t: T) => boolean }
export interface Phase<T = any> { id: string; title: string; when: string; items: Item<T>[]; /** text shown exactly as written (no edition terminology layer), e.g. question bank wording */ raw?: boolean }
export interface Val { val: any; by: string; at: string; src: 'talk' | 'manual'; heard?: boolean; quote?: string }
export interface Rec { v: Record<string, Val>; signed?: { by: string; role: string; at: string }; signs?: Record<string, { by: string; role: string; at: string }>; transcript?: string[]; line?: number }
export interface Signer { name: string; role: string; at: string }
export interface SignDef<T = any> { id: string; label: string; roles: string[]; allow?: (p: { name: string; role: string }, t: T) => boolean; phase?: string; locks?: string[]; needs?: string[];
  statement: (t: T, open: number) => string; onSigned: (t: T, values: Record<string, any>, s: Signer, open: string[]) => void; done?: (t: T) => boolean }

/** What a station needs from its edition. */
export interface Adapter<T extends Subject> {
  get: (id: string) => T | undefined;
  /** date (yyyy-mm-dd) and room/place for the header pill */
  date: (t: T) => string; place: (t: T) => string; time: (t: T) => string;
  /** {placeholders} in Talk scripts */
  fill?: (s: string, t: T, p: MedPatient) => string;
  journey?: (t: T, def: Def<T>, close: () => void) => React.ReactNode;
  card?: (t: T, def: Def<T>) => React.ReactNode;
  upload?: (t: T, def: Def<T>) => React.ReactNode;
  wrap?: (t: T, def: Def<T>, children: React.ReactNode) => React.ReactNode;
  notes?: (t: T, which: string) => React.ReactNode;
  /** the "Before you sign" box (flags, warnings); children are the engine's own open-item lines */
  before?: (t: T, def: Def<T>, children: React.ReactNode) => React.ReactNode;
  facility?: (t: T, st: string) => FacItem[]; fillLinked?: (t: T, f: FacItem, val: any) => void;
  events?: (t: T) => Record<string, any> | undefined; recordEvent?: (t: T, key: string, val: string, actor: Actor, why: string) => void;
  nowTime: () => string;
  flag?: (t: T, def: Def<T>, s: Actor, open: string[]) => void;
  auditKey: (t: T) => string;
  sigCase?: (t: T) => string;
  closeTestId?: (def: Def<T>) => string;
  /** label of a subject in the patient picker */
  pickLabel?: (t: T) => string;
}
export interface Def<T extends Subject = any> { noFac?: boolean; st: string; bench: string; here: string; title: string; storeKey: string; testId: string; phases: Phase<T>[]; script?: [string, Record<string, any>][];
  sync?: (t: T, v: (id: string) => any, actor: Actor) => void; signs: SignDef<T>[]; notes?: string;
  footer?: (t: T, x: { signed: (id: string) => boolean; actor: Actor; toast: (m: string) => void; close: (m?: string) => void }) => React.ReactNode;
  tail?: (t: T, close: (m?: string) => void) => React.ReactNode; brief?: (t: T) => string;
  /** Talk with no scripted conversation of its own (e.g. the doctor's scribe lives in a panel): what the Talk button does */
  onTalk?: (t: T, go: (phase: string) => void) => void;
  /** after closing (Save & close): persist anything kept until the end, e.g. one vitals record per visit */
  onClose?: (t: T, v: (id: string) => any, actor: Actor) => void;
  /** Nightingale's hand-off once the station is signed: the next station, who it goes to, and how to open it */
  next?: (t: T, signed: (id: string) => boolean) => { label: string; detail: string; run: () => void } | null;
  adapter?: Adapter<T>;
}

export const COUNT_ROWS = ['Sponges', 'Sharps / needles', 'Instruments'] as const; export const COUNT_COLS = ['Initial', 'First closing', 'Final'] as const;
export const recOf = (key: string, id: string): Rec => svRead<Record<string, Rec>>(key, {})[id] || { v: {} };
const saveRec = (key: string, id: string, r: Rec) => { svWrite(key, { ...svRead<Record<string, Rec>>(key, {}), [id]: r }); window.dispatchEvent(new Event('vityls-med-updated')); };
const filled = (it: Item, v: any) => it.kind === 'counts' ? COUNT_ROWS.every(r => v?.[r]?.Final === 'ok') : it.kind === 'multi' ? Array.isArray(v) && v.length > 0 : it.kind === 'list' ? !!(v && (v.none || (v.items || []).length)) : v !== undefined && v !== null && v !== '' && v !== false;
export const labelOf = <T,>(it: Item<T>, t: T) => (typeof it.label === 'function' ? it.label(t) : it.label) || it.name || '';
const nowClock = () => { const d = new Date(); let h = d.getHours(); const ap = h >= 12 ? 'PM' : 'AM'; h = h % 12 || 12; return `${String(h).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')} ${ap}`; };

/** Default "Before you sign" box for editions without their own. */
const BeforeBox: React.FC<{ children?: React.ReactNode }> = ({ children }) => { const kids = React.Children.toArray(children).filter(Boolean);
  return <section className="v106-before" data-testid="v106-before-sign"><h3>Before you sign</h3>{kids}{!kids.length && <div className="v106-bitem ok"><Check size={16} aria-hidden="true" /><span>No open items or warnings.</span></div>}</section>; };

export function StationEngine<T extends Subject>({ def, id, onClose, pick, onPick }: { def: Def<T>; id: string; onClose: (m?: string) => void; pick?: T[]; onPick?: (id: string) => void }) {
  useMedTick(); const [actor] = useActor(); const { toast } = useSv(); const A = def.adapter!; const t0 = A.get(id);
  const MK = `${def.storeKey}-mode`;
  const [mode, setMode] = useState<'talk' | 'manual'>(() => svRead<'talk' | 'manual'>(MK, 'manual'));
  const [listening, setListening] = useState(false); const [sign, setSign] = useState<SignDef<T> | null>(null); const [phase, setPhase] = useState(def.phases[0]?.id || ''); const [ed, setEd] = useState<string | null>(null);
  useEffect(() => { setListening(false); }, [id]);
  const t = t0 ? (A.get(id) || t0) : null;
  const rec = t ? recOf(def.storeKey, t.id) : { v: {} } as Rec;
  const p = t ? medRepo.patient(t.pid) : undefined;
  const fac = t && !def.noFac && A.facility ? A.facility(t, def.st) : [];
  const toItem = (f: FacItem): Item<T> => ({ id: f.id, label: f.label, kind: f.kind as Kind, opts: f.opts, req: f.req, unit: f.unit, quick: f.quick || (f.kind === 'number' ? [] : undefined), roles: f.roles, fac: f });
  const phases: Phase<T>[] = (() => { const known = new Set(def.phases.map(x => x.id)); const base = def.phases.map(ph => ({ ...ph, items: [...ph.items.map(it => it.kind === 'panel' && !it.name ? { ...it, name: ph.title } : it), ...fac.filter(f => f.group === ph.id).map(toItem)] }));
    const extra = Array.from(new Set(fac.filter(f => !known.has(f.group)).map(f => f.group))).map(g => ({ id: `fac-${g}`, title: g, when: 'Facility items', items: fac.filter(f => f.group === g).map(toItem) }));
    const lastSigned = base.length > 1 && def.signs.some(s => s.phase === base[base.length - 1].id);
    return lastSigned || def.st === 'or' ? [...base.slice(0, -1), ...extra, base[base.length - 1]] : [...base, ...extra]; })();
  const ALLc = phases.flatMap(x => x.items);
  const signedMap: Record<string, { by: string; role: string; at: string }> = { ...(rec.signs || {}), ...(rec.signed && def.signs[0] ? { [def.signs.find(s => !s.phase)?.id || def.signs[0].id]: rec.signed } : {}) };
  const isSigned = (s: SignDef<T>) => !!signedMap[s.id] || !!(t && s.done?.(t));
  const lockedPh = (phId: string) => def.signs.some(s => isSigned(s) && (s.locks ? s.locks.includes(phId) : !def.signs.some(o => o.phase === phId)));
  const ev = () => (t && A.events ? A.events(A.get(t.id) || t) : undefined) || {};
  const dflt = (it: Item<T>) => t && it.dflt ? it.dflt(t) : undefined;
  const valOf = (it: Item<T>) => it.event ? ev()[it.event] : rec.v[it.id]?.val ?? dflt(it);
  const isDone = (it: Item<T>) => it.kind === 'panel' ? !!(t && it.done && it.done(t)) : filled(it, valOf(it)) && !rec.v[it.id]?.heard;
  const counts = (it: Item<T>) => it.kind !== 'panel' || !!it.done;
  const vget = (r: Rec) => (k: string) => { if (r.v[k] && !r.v[k].heard) return r.v[k].val; const it = ALLc.find(x => x.id === k); return it?.event ? ev()[it.event] : it && t && it.dflt ? it.dflt(t) : undefined; };
  const sync = (r: Rec) => { if (t && def.sync) def.sync(A.get(t.id) || t, vget(r), actor); };

  const put = (it: Item<T>, val: any, src: 'talk' | 'manual' = 'manual', heard = false, quote?: string) => { if (!t) return; const phId = phases.find(ph => ph.items.includes(it))?.id || ''; if (lockedPh(phId)) return;
    if (it.event) { if (val && A.recordEvent) { try { A.recordEvent(A.get(t.id) || t, it.event, val, actor, rec.v[it.id] ? 'Corrected at the station' : ''); } catch (e) { toast((e as Error).message); } } return; }
    const r = recOf(def.storeKey, t.id); const n: Rec = { ...r, v: { ...r.v, [it.id]: { val, by: actor.name, at: new Date().toISOString(), src, heard, quote } } }; saveRec(def.storeKey, t.id, n); if (!heard) { sync(n); if (it.fac && A.fillLinked) A.fillLinked(t, it.fac, val); } };
  const confirm = (ids: string[]) => { if (!t) return; const r = recOf(def.storeKey, t.id); const v = { ...r.v }; ids.forEach(k => { if (v[k]) { v[k] = { ...v[k], heard: false, by: actor.name, at: new Date().toISOString() }; const f = fac.find(x => x.id === k); if (f && A.fillLinked) A.fillLinked(t, f, v[k].val); } }); const n = { ...r, v }; saveRec(def.storeKey, t.id, n); sync(n);
    repo.audit({ caseId: A.auditKey(t), user: actor.name, role: actor.role, action: 'os.station.confirm' as any, detail: `${def.title}: confirmed ${ids.length} item(s) heard` }); };

  const script = def.script || [];
  const fill = (s: string) => !t || !p ? s : (A.fill ? A.fill(s, t, p) : s).replace(/\{first\}/g, p.name.split(' ')[0]).replace(/\{name\}/g, p.name).replace(/\{dob\}/g, /^\d{4}-/.test(p.dob) ? new Date(p.dob + 'T12:00').toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' }) : p.dob);
  useEffect(() => { if (!listening || !t) return; const tm = window.setInterval(() => { const r = recOf(def.storeKey, t.id); const i = r.line || 0; if (i >= script.length) { setListening(false); return; }
      const [line, hits] = script[i]; const text = fill(line); const v = { ...r.v };
      Object.entries(hits).forEach(([k, val]) => { const it = ALLc.find(x => x.id === k); if (!it || (v[k] && !v[k].heard)) return; const prev = v[k]?.val; const merged = it.kind === 'counts' ? Object.fromEntries(COUNT_ROWS.map(rw => [rw, { ...(prev?.[rw] || {}), ...(val as any)[rw] }])) : typeof val === 'string' ? fill(val) : val; v[k] = { val: merged, by: 'Nightingale (heard)', at: new Date().toISOString(), src: 'talk', heard: true, quote: text }; });
      fac.filter(f => (f.talk || []).some(w => text.toLowerCase().includes(w.toLowerCase())) && !(v[f.id] && !v[f.id].heard)).forEach(f => { const low = text.toLowerCase(); const val = f.kind === 'check' ? true : f.kind === 'multi' ? (f.opts || []).filter(o => o.toLowerCase().split(/[^a-z]+/).some(w => w.length > 3 && low.includes(w))) : f.kind === 'radio' ? (f.opts || [])[0] : undefined; if (val === undefined || (Array.isArray(val) && !val.length)) return; v[f.id] = { val, by: 'Nightingale (heard)', at: new Date().toISOString(), src: 'talk', heard: true, quote: text }; });
      saveRec(def.storeKey, t.id, { ...r, v, transcript: [...(r.transcript || []), text], line: i + 1 }); }, 1600);
    return () => window.clearInterval(tm); }, [listening, t?.id]);

  if (!t || !p) return null;
  const T = isoDay();
  const phaseStat = (ph: Phase<T>) => { const l = ph.items.filter(counts); return { done: l.filter(isDone).length, n: l.length, heard: ph.items.filter(it => rec.v[it.id]?.heard).map(it => it.id) }; };
  const reqOpen = ALLc.filter(it => it.req && counts(it) && !isDone(it));
  const heardAll = ALLc.filter(it => rec.v[it.id]?.heard).map(it => it.id);
  const countable = ALLc.filter(counts); const total = countable.length; const doneN = countable.filter(isDone).length;
  const goPhase = (k: string) => { setPhase(k); document.getElementById(`or6-${k}`)?.scrollIntoView({ behavior: 'smooth', block: 'start' }); };
  const setM = (m: 'talk' | 'manual') => { if (m === 'talk' && !script.length && def.onTalk) { def.onTalk(t, goPhase); } svWrite(MK, m); setMode(m); if (m === 'manual') setListening(false); };
  const transcript = rec.transcript || [];
  const openIn = (s: SignDef<T>) => (s.phase ? phases.filter(ph => ph.id === s.phase) : phases.filter(ph => !def.signs.some(o => o.phase === ph.id))).flatMap(ph => ph.items).filter(it => it.req && counts(it) && !isDone(it));
  const footSigns = def.signs.filter(s => !s.phase);
  const signedFn = (k: string) => { const sd = def.signs.find(x => x.id === k); return sd ? isSigned(sd) : false; };
  const nx = def.next ? def.next(A.get(t.id) || t, signedFn) : null;
  const close = (m?: string) => { if (def.onClose) def.onClose(A.get(t.id) || t, vget(recOf(def.storeKey, t.id)), actor); onClose(m); };

  const Row: React.FC<{ it: Item<T>; locked: boolean }> = ({ it, locked }) => { const v = valOf(it); const meta = rec.v[it.id]; const heard = !!meta?.heard; const done = isDone(it); const L = labelOf(it, t);
    if (it.kind === 'panel') return <div className={`or6-row k-panel ${done ? 'done' : ''}`} data-testid="or6-row" data-id={it.id}>{L && L !== it.name && <div className="or6-lab"><span className={`dot ${done ? 'ok' : ''}`}>{done && <Check size={11} />}</span>{L}{it.req && !done && it.done && <span className="req">required</span>}</div>}<div className="n8-panel">{it.render?.(t, { close })}</div></div>;
    const ctl = (() => { switch (it.kind) {
      case 'check': return <button type="button" className={`or6-check ${v ? 'on' : ''}`} role="checkbox" aria-checked={!!v} disabled={locked} onClick={() => put(it, !v)} data-testid={`or6-${it.id}`}><span className="box">{v ? <Check size={16} /> : null}</span><span className="t">{L}{it.fac && <> <FacTag it={it.fac} /></>}{it.req && !done && <span className="req"> required</span>}</span></button>;
      case 'radio': return <div className="or6-seg" role="radiogroup" aria-label={L}>{it.opts!.map(o => <button key={o} type="button" role="radio" aria-checked={v === o} className={v === o ? 'on' : ''} disabled={locked} onClick={() => put(it, o)} data-testid={`or6-${it.id}-${o}`}>{o}</button>)}</div>;
      case 'multi': { const arr: string[] = Array.isArray(v) ? v : []; return <div className="or6-chips">{it.opts!.map(o => <button key={o} type="button" aria-pressed={arr.includes(o)} className={arr.includes(o) ? 'on' : ''} disabled={locked} onClick={() => put(it, arr.includes(o) ? arr.filter(x => x !== o) : [...arr.filter(x => (/^(none|not indicated|not taking)/i.test(o)) ? false : !/^(none|not indicated|not taking)/i.test(x)), o])} data-testid={`or6-${it.id}-${o}`}>{arr.includes(o) && <Check size={14} />}{o}</button>)}</div>; }
      case 'dropdown': return <select className="or6-sel" value={v || ''} disabled={locked} onChange={e => put(it, e.target.value)} data-testid={`or6-${it.id}`}><option value="">Choose…</option>{(it.opts || []).map(o => <option key={o}>{o}</option>)}</select>;
      case 'select': { const opts = Array.from(new Set([...(v ? [v] : []), ...peopleIn(it.roles || ['Circulating RN', 'RN', 'Scrub tech']).map(x => x.name)])); return <select className="or6-sel" value={v || ''} disabled={locked} onChange={e => put(it, e.target.value)} data-testid={`or6-${it.id}`}><option value="">Choose…</option>{opts.map(o => <option key={o}>{o}</option>)}</select>; }
      case 'number': return <div className="or6-num">{(it.quick || []).length > 0 && <div className="or6-chips">{(it.quick || []).map(q => <button key={q} type="button" className={v === q ? 'on' : ''} disabled={locked} onClick={() => put(it, q)} data-testid={`or6-${it.id}-q-${q}`}>{q}{/^[\d.]+$/.test(q) && it.unit ? ` ${it.unit}` : ''}</button>)}</div>}<span className="or6-in"><input inputMode="decimal" defaultValue={v && !(it.quick || []).includes(v) ? v : ''} key={String(v ?? '')} placeholder={(it.quick || []).length ? 'Other' : ''} disabled={locked} onBlur={e => { const x = e.target.value.replace(/[^\d./]/g, ''); if (x !== (v ?? '')) put(it, x); }} data-testid={`or6-${it.id}`} />{it.unit && <span>{it.unit}</span>}</span></div>;
      case 'text': return <div className="or6-txt">{it.quick && <div className="or6-chips">{it.quick.map(q => <button key={q} type="button" className={v === q ? 'on' : ''} disabled={locked} onClick={() => put(it, q)} data-testid={`or6-${it.id}-q-${q}`}>{q}</button>)}</div>}{it.long ? <textarea className="or6-input ta" rows={3} defaultValue={v || ''} key={String(v || '')} placeholder="Type…" disabled={locked} onBlur={e => e.target.value !== (v || '') && put(it, e.target.value)} data-testid={`or6-${it.id}`} /> : <input className="or6-input" defaultValue={v || ''} key={String(v || '')} placeholder="Type…" disabled={locked} onBlur={e => e.target.value !== (v || '') && put(it, e.target.value)} data-testid={`or6-${it.id}`} />}</div>;
      case 'time': return <div className="or6-time">{v ? <><b>{String(v).replace(/^0/, '')}</b>{ed === it.id ? <><input type="time" className="or6-input sm" onBlur={e => { const m = /^(\d{1,2}):(\d{2})$/.exec(e.target.value); if (m) { let h = +m[1]; const ap = h >= 12 ? 'PM' : 'AM'; h = h % 12 || 12; put(it, `${String(h).padStart(2, '0')}:${m[2]} ${ap}`); } setEd(null); }} autoFocus data-testid={`or6-${it.id}-edit`} /></> : !locked && <button type="button" className="or6-link" onClick={() => setEd(it.id)}>Edit</button>}</> : <button type="button" className="or6-stamp" disabled={locked} onClick={() => put(it, (A.nowTime || nowClock)())} data-testid={`or6-${it.id}`}><Clock size={15} /> Stamp now</button>}</div>;
      case 'list': { const l = v || {}; return <div className="or6-list"><div className="or6-seg"><button type="button" className={l.none ? 'on' : ''} disabled={locked} onClick={() => put(it, { none: true })} data-testid={`or6-${it.id}-none`}>None</button><button type="button" className={!l.none && (l.items || []).length ? 'on' : ''} disabled={locked} onClick={() => put(it, { items: l.items || [] })}>Add</button></div>
        {!l.none && <>{(l.items || []).map((x: string, i: number) => <span key={i} className="or6-li">{x}{!locked && <button type="button" aria-label="Remove" onClick={() => put(it, { items: l.items.filter((_: string, j: number) => j !== i) })}>×</button>}</span>)}
          {!locked && <input className="or6-input" placeholder={it.id === 'implants' ? 'e.g. Mesh 10 × 15 cm · lot 4471 · Enter' : 'Type and press Enter'} onKeyDown={e => { const x = (e.target as HTMLInputElement); if (e.key === 'Enter' && x.value.trim()) { put(it, { items: [...(l.items || []), x.value.trim()] }); x.value = ''; } }} data-testid={`or6-${it.id}-add`} />}</>}</div>; }
      case 'counts': { const cv = v || {}; return <table className="or6-counts" data-testid="or6-counts"><thead><tr><th />{COUNT_COLS.map(col => <th key={col}>{col}</th>)}</tr></thead><tbody>{COUNT_ROWS.map(rw => <tr key={rw}><th>{rw}</th>{COUNT_COLS.map(col => { const s = cv[rw]?.[col]; return <td key={col}><div className="or6-seg sm">{([['ok', 'Correct'], ['bad', 'Incorrect']] as const).map(([k, tt]) => <button key={k} type="button" className={s === k ? `on ${k}` : ''} disabled={locked} onClick={() => put(it, { ...cv, [rw]: { ...(cv[rw] || {}), [col]: k } })} data-testid={`or6-count-${rw.split(' ')[0]}-${col.split(' ')[0]}-${k}`}>{tt}</button>)}</div></td>; })}</tr>)}</tbody></table>; }
      default: return null;
    } })();
    return <div className={`or6-row k-${it.kind} ${done ? 'done' : ''} ${heard ? 'heard' : ''}`} data-testid="or6-row" data-id={it.id}>
      {it.kind !== 'check' && <div className="or6-lab"><span className={`dot ${done ? 'ok' : heard ? 'hd' : ''}`}>{done && <Check size={11} />}</span>{L}{it.fac && <FacTag it={it.fac} />}{it.req && !done && <span className="req">required</span>}</div>}
      {ctl}
      {heard && <div className="or6-heard"><span>Heard: “{meta?.quote}”</span><button type="button" onClick={() => confirm([it.id])} data-testid={`or6-confirm-${it.id}`}>Confirm</button></div>}
      {done && meta && !heard && it.kind !== 'time' && <span className="or6-by">{meta.by.replace(/,.*$/, '')} · {new Date(meta.at).toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' })}{meta.src === 'talk' ? ' · from talk' : ''}</span>}
    </div>; };

  const SignBtn: React.FC<{ s: SignDef<T> }> = ({ s }) => { const sg = signedMap[s.id]; const n = openIn(s).length;
    if (isSigned(s)) return <span className="or6-signed" data-testid={`n8-signed-${s.id}`}><Check size={16} /> {s.label.replace(/^Sign /, '')} signed{sg ? ` by ${sg.by.replace(/,.*$/, '')} · ${new Date(sg.at).toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' })}` : ''}</span>;
    const blocked = (s.needs || []).some(k => { const it = ALLc.find(x => x.id === k); return it ? !isDone(it) : !isSigned(def.signs.find(x => x.id === k)!); });
    return <button type="button" className="a8-btn pri" onClick={() => setSign(s)} disabled={heardAll.length > 0 || blocked} title={blocked ? 'Complete the earlier steps first' : ''} data-testid={`n8-sign-${s.id}`}>{n ? `${s.label} with exceptions (${n})` : s.label}</button>; };

  const before = <>{reqOpen.length > 0 && <div className="v106-bitem warn" data-testid="or6-open"><span><b>{reqOpen.length} required item{reqOpen.length === 1 ? '' : 's'} open:</b> {reqOpen.slice(0, 8).map(it => labelOf(it, t).replace(/:.*$/, '')).join(' · ')}{reqOpen.length > 8 ? ` +${reqOpen.length - 8} more` : ''}{def.signs.length ? '. You can sign; open items become flags.' : '.'}</span></div>}
    {heardAll.length > 0 && <div className="v106-bitem warn"><span><b>{heardAll.length} heard item{heardAll.length === 1 ? '' : 's'} not confirmed.</b> Confirm or correct them{def.signs.length ? ' before signing' : ''}.</span></div>}</>;
  const talkable = script.length > 0 || !!def.onTalk;
  const body = <>
      <div className="b6"><div className="b6-row">
        <div className="or6-mode" role="group" aria-label="How to fill the record"><button type="button" className={mode === 'talk' ? 'on' : ''} aria-pressed={mode === 'talk'} onClick={() => setM('talk')} disabled={!talkable} data-testid="or6-mode-talk"><Mic size={18} /><span><b>Talk</b><small>Ambient</small></span></button><button type="button" className={mode === 'manual' ? 'on' : ''} aria-pressed={mode === 'manual'} onClick={() => setM('manual')} data-testid="or6-mode-manual"><PenLine size={18} /><span><b>Manual</b><small>Tap & type</small></span></button></div>
        <div className="b6-card ai"><span className="b6-k">Nightingale</span><p data-testid="or6-brief">{def.brief ? `${def.brief(t)} ` : ''}{doneN} of {total} done{heardAll.length ? ` · ${heardAll.length} heard to confirm` : ''}. {reqOpen.length ? `Next: ${labelOf(reqOpen[0], t).replace(/:.*$/, '')}.` : nx ? `Next step: ${nx.label}.` : 'Every required item is recorded.'}</p></div>
        <button type="button" className={`b6-card note ${reqOpen.length ? 'warn' : 'ok'}`} onClick={() => document.querySelector('[data-testid="v106-before-sign"]')?.scrollIntoView({ behavior: 'smooth' })}><span className="b6-k">Notifications</span><p>{reqOpen.length ? `${reqOpen.length} required open` : 'None open'}</p></button>
      </div></div>
      {mode === 'talk' && script.length > 0 && <div className="or6-listen" data-testid="or6-listen"><button type="button" className={`or6-mic ${listening ? 'on' : ''}`} onClick={() => setListening(!listening)} disabled={(rec.line || 0) >= script.length} data-testid="or6-listen-btn">{listening ? <Pause size={20} /> : <Play size={20} />}</button>
        <div className="or6-tx" aria-live="polite">{transcript.length ? transcript.slice(-3).map((l, i) => <p key={i} className={i === Math.min(2, transcript.length - 1) ? 'cur' : ''}>{l}</p>) : <p className="mu">{listening ? 'Listening…' : 'Tap play to listen. Nightingale matches what is said to the checklist and drafts each item as “Heard” for you to confirm. Simulated with a sample conversation.'}</p>}</div>
        {heardAll.length > 0 && <button type="button" className="or6-confall" onClick={() => confirm(heardAll)} data-testid="or6-confirm-all"><CheckCheck size={16} /> Confirm all heard ({heardAll.length})</button>}</div>}
      <div className="a81-dbody v106-dbody or6-body">
        <nav className="or6-rail" aria-label="Phases">{phases.map((ph, i) => { const s = phaseStat(ph); const ok = s.n > 0 && s.done === s.n; return <button key={ph.id} type="button" className={`${phase === ph.id ? 'cur' : ''} ${ok ? 'ok' : ''}`} onClick={() => goPhase(ph.id)} data-testid={`or6-rail-${ph.id}`} data-no-terms={ph.raw ? '' : undefined}><span className="n">{ok ? <Check size={13} /> : i + 1}</span><span className="t">{ph.title}</span><span className="c">{s.n ? `${s.done}/${s.n}` : ''}</span></button>; })}</nav>
        <div className="or6-main">
          {phases.map((ph, i) => { const s = phaseStat(ph); const ok = s.n > 0 && s.done === s.n; const lk = lockedPh(ph.id); const phSign = def.signs.filter(x => x.phase === ph.id);
            return <section key={ph.id} id={`or6-${ph.id}`} className="or6-phase" data-testid={`or6-phase-${ph.id}`} data-no-terms={ph.raw ? '' : undefined}>
            <header><span className={`n ${ok ? 'ok' : ''}`}>{ok ? <Check size={14} /> : i + 1}</span><div><h3>{ph.title}</h3><span className="w">{ph.when}</span></div>{s.n > 0 && <span className="p">{s.done} of {s.n}</span>}{s.heard.length > 0 && <button type="button" className="or6-confph" onClick={() => confirm(s.heard)} data-testid={`or6-confirm-ph-${ph.id}`}>Confirm heard ({s.heard.length})</button>}</header>
            <div className="or6-items">{ph.items.map(it => <Row key={it.id} it={it} locked={lk} />)}</div>
            {phSign.length > 0 && <div className="n8-phsign">{phSign.map(sd => <SignBtn key={sd.id} s={sd} />)}</div>}
          </section>; })}
          {def.notes && A.notes?.(t, def.notes)}
          {A.before ? A.before(t, def, before) : <BeforeBox>{before}</BeforeBox>}
          {def.tail?.(t, close)}
          {nx && def.signs.length > 0 && footSigns.every(isSigned) && <div className="os-next" data-testid="os-next"><span className="k">Nightingale · next step</span><p><b>{nx.label}</b> {nx.detail}</p><button type="button" className="a8-btn pri" onClick={() => { nx.run(); close(); }} data-testid="os-next-go">{nx.label} <ArrowRight size={16} /></button></div>}
          <div className="a81-foot">
            <button type="button" className="a8-btn" onClick={() => close()} data-testid="a8-save">Save &amp; close</button>
            {footSigns.map(sd => <SignBtn key={sd.id} s={sd} />)}
            {def.footer?.(t, { signed: signedFn, actor, toast, close })}
          </div>
        </div>
      </div></>;
  return <div className="a81-modal os-station" data-edition={def.st} onMouseDown={e => { if (e.target === e.currentTarget) close(); }}>
    <div className="a81-dialog or6 n8" role="dialog" aria-label={def.title} data-testid={def.testId}>
      <div className="a81-dhead"><b>{def.title}</b>{pick && pick.length > 1 && <select className="sv-input a81-pick" value={t.id} onChange={e => onPick?.(e.target.value)} data-testid="a81-case-pick" aria-label="Switch patient">{pick.map(x => <option key={x.id} value={x.id}>{A.pickLabel ? A.pickLabel(x) : `${medRepo.patient(x.pid)?.name} · ${A.time(x).replace(/^0/, '')}`}</option>)}</select>}<span className={`v10-chip ${A.date(t) === T ? 'ok' : 'warn'}`} data-testid="v10-today-pill">{A.date(t) === T ? 'Today' : 'Not today'} · {A.place(t)}</span><span style={{ marginLeft: 'auto' }} />{A.upload?.(t, def)}<button type="button" className="a82-x" onClick={() => close()} aria-label="Close" title="Close" data-testid={A.closeTestId ? A.closeTestId(def) : 'a81-close'}><X size={18} /></button></div>
      {A.journey?.(t, def, () => close())}
      {A.card && <div className="a82-dcase">{A.card(t, def)}</div>}
      {A.wrap ? A.wrap(t, def, body) : body}
      {sign && <PinSign title={`Sign · ${sign.label.replace(/^Sign /, '')}`} sigCase={A.sigCase ? A.sigCase(t) : t.id} roles={sign.roles} allow={sign.allow ? (pp => sign.allow!(pp, t)) : undefined} statement={<>{sign.statement(t, openIn(sign).length)} Nightingale does not sign.</>} onClose={() => setSign(null)}
        onSigned={s => { const r = recOf(def.storeKey, t.id); const at = new Date().toISOString(); const open = openIn(sign).map(it => labelOf(it, t)); const n: Rec = { ...r, signs: { ...(r.signs || {}), [sign.id]: { by: s.name, role: s.role, at } } }; saveRec(def.storeKey, t.id, n); sync(n);
          const values = Object.fromEntries(Object.entries(n.v).filter(([, v]) => !v.heard).map(([k, v]) => [k, v.val])); sign.onSigned(A.get(t.id) || t, values, { name: s.name, role: s.role, at }, open);
          if (open.length && A.flag) A.flag(t, def, { name: s.name, role: s.role }, open);
          setSign(null); toast(`${sign.label.replace(/^Sign /, '')} signed.`); }} confirmLabel="Sign" />}
    </div></div>;
}
