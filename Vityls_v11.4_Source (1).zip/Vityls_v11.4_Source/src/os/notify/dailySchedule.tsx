/* Vityls OS · next-day schedule email (v11.1). At 2:00 PM (practice setting) every surgeon (ASC) or doctor / surgeon
 * (Surgery, Medical) with cases or appointments tomorrow gets one email listing them. Each edition registers its source
 * (ASC: tomorrow's surgical cases; office: tomorrow's appointments). Runs on the app's minute tick, once per provider per
 * day; "Send now" sends today's run on demand. Delivery is SIMULATED: the email goes to the Vityls outbox, nothing leaves
 * the browser. In production this is a server job (practice time zone) through the secure email service. Fictional data. */
import React, { useState } from 'react';
import { Mail, Send } from 'lucide-react';
import { isoDay, addDays } from '../../med/record';
import { useActor, useMedTick } from '../../med/ui';
import { repo } from '../../v6/dataLayer';
import { svRead, svWrite } from '../../surgery/store';
import { getProviders, displayName } from '../../v7/providers';
import { queueOutbox, outbox } from '../../core/store';
import '../ai/dock.css';

export interface SchedRow { time: string; patient: string; what: string; place: string; note?: string }
export interface ProviderDay { provider: string; rows: SchedRow[] }
export interface Source { noun: [string, string]; title: string; collect: (date: string) => ProviderDay[] }
let SRC: Source | null = null;
export const setScheduleSource = (s: Source) => { SRC = s; };

export interface DailyCfg { on: boolean; time: string; names: 'full' | 'initials' }
const CK = 'os-daily-email'; const LK = 'os-daily-email-log';
export const dailyCfg = (): DailyCfg => ({ on: true, time: '14:00', names: 'full', ...svRead<Partial<DailyCfg>>(CK, {}) });
const sentLog = () => svRead<Record<string, string>>(LK, {});
const toMin = (t: string) => { const m = /(\d{1,2}):(\d{2})\s*(AM|PM)?/i.exec(t); if (!m) return 9999; let h = +m[1]; if (m[3]) h = h % 12 + (/pm/i.test(m[3]) ? 12 : 0); return h * 60 + +m[2]; };
const hm = (t: string) => { const m = toMin(t); if (m >= 9999) return t; const h = Math.floor(m / 60), mm = m % 60; return `${h % 12 || 12}:${String(mm).padStart(2, '0')} ${h >= 12 ? 'PM' : 'AM'}`; };
const initials = (n: string) => n.split(/\s+/).map(w => w[0]).join('').toUpperCase();
const dayLabel = (d: string) => new Date(d + 'T12:00').toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' });

/** The provider's email (Providers in Practice settings); demo providers without one get a fictional address. */
export function emailOf(name: string): { to: string; demo: boolean } {
  const p = getProviders().find(x => displayName(x) === name || `${x.firstName} ${x.lastName}` === name.replace(/,.*$/, ''));
  if (p?.email) return { to: p.email, demo: false };
  const base = name.replace(/,.*$/, '').replace(/^Dr\.?\s*/i, '').trim().toLowerCase().replace(/[^a-z]+/g, '.');
  return { to: `${base}@example.test`, demo: true };
}
export function composeFor(d: ProviderDay, date: string, cfg = dailyCfg()) {
  const [one, many] = SRC?.noun || ['appointment', 'appointments']; const rows = d.rows.slice().sort((a, b) => toMin(a.time) - toMin(b.time));
  const subject = `Your ${SRC?.title || 'schedule'} for ${dayLabel(date)} · ${rows.length} ${rows.length === 1 ? one : many}`;
  const first = d.provider.replace(/,.*$/, '').split(' ').slice(-1)[0];
  const body = [`Dr. ${first},`, '', `Here is your ${SRC?.title || 'schedule'} for ${dayLabel(date)}:`, '',
    ...rows.map(r => `${hm(r.time).padEnd(9)} ${cfg.names === 'initials' ? initials(r.patient) : r.patient} · ${r.what} · ${r.place}${r.note ? ` · ${r.note}` : ''}`), '',
    `First ${one} at ${hm(rows[0]?.time || '')}. Changes after this email appear in Vityls and Nightingale will tell you.`,
    'Sent automatically by Vityls at the time set in Practice settings. Reply is not monitored.'].join('\n');
  return { subject, body };
}
/** Send tomorrow's emails once per provider when the send time has passed (or now, when forced). Returns how many were sent. */
export function runDailySchedule(now = new Date(), force = false, by = 'Vityls (automatic)'): number {
  const cfg = dailyCfg(); if (!SRC || (!cfg.on && !force)) return 0;
  const [h, m] = cfg.time.split(':').map(Number); if (!force && now.getHours() * 60 + now.getMinutes() < h * 60 + m) return 0;
  const date = addDays(isoDay(), 1); const log = sentLog(); let n = 0;
  SRC.collect(date).filter(d => d.rows.length).forEach(d => { const k = `${date}|${d.provider}`; if (log[k] && !force) return;
    const { subject, body } = composeFor(d, date, cfg); const { to, demo } = emailOf(d.provider);
    queueOutbox({ module: 'core', to: `${d.provider} <${to}>${demo ? ' (demo address)' : ''}`, subject, body, by }, now.toISOString());
    repo.audit({ caseId: 'practice', user: by, role: 'System', action: 'os.daily-email' as any, detail: `Next-day schedule emailed to ${d.provider} (${d.rows.length}) · simulated` });
    log[k] = now.toISOString(); n++; });
  if (n) { svWrite(LK, log); window.dispatchEvent(new Event('vityls-med-updated')); }
  return n;
}

/** Practice settings › Next-day schedule email */
export const DailyEmailSettings: React.FC = () => {
  useMedTick(); const [actor] = useActor(); const [c, setC] = useState(dailyCfg()); const [msg, setMsg] = useState('');
  const save = (n: DailyCfg, what: string) => { setC(n); svWrite(CK, n); repo.audit({ caseId: 'practice', user: actor.name, role: actor.role, action: 'os.daily-email.settings' as any, detail: `Next-day schedule email: ${what}` }); };
  const date = addDays(isoDay(), 1); const days = SRC ? SRC.collect(date).filter(d => d.rows.length) : [];
  const sent = outbox().filter(o => /^Your .* for /.test(o.subject)).slice(-8).reverse();
  const [one, many] = SRC?.noun || ['appointment', 'appointments'];
  return <div className="v10-page os-daily" data-testid="os-daily"><h1 className="sv-title" data-ps-legacy="">Next-day schedule email</h1>
    <p className="v10-sub">Every afternoon each {SRC?.title === 'surgery schedule' ? 'surgeon' : 'doctor and surgeon'} with {many} tomorrow gets one email listing them. Simulated in this test build: emails go to the Vityls outbox.</p>
    <div className="os-daily-set">
      <label className="os-sw"><input type="checkbox" checked={c.on} onChange={e => save({ ...c, on: e.target.checked }, e.target.checked ? 'on' : 'off')} data-testid="os-daily-on" /><span>{c.on ? 'On' : 'Off'}</span></label>
      <label>Send at<input type="time" value={c.time} onChange={e => save({ ...c, time: e.target.value || '14:00' }, `time ${e.target.value}`)} data-testid="os-daily-time" /></label>
      <label>Patients shown as<select value={c.names} onChange={e => save({ ...c, names: e.target.value as DailyCfg['names'] }, `names ${e.target.value}`)} data-testid="os-daily-names"><option value="full">Full name</option><option value="initials">Initials only</option></select></label>
      <button type="button" className="a8-btn pri" onClick={() => { const n = runDailySchedule(new Date(), true, actor.name); setMsg(n ? `Sent ${n} email${n === 1 ? '' : 's'} (simulated).` : `No ${many} tomorrow.`); }} data-testid="os-daily-send"><Send size={15} /> Send tomorrow’s now</button></div>
    {msg && <p className="a81-ok" data-testid="os-daily-msg">{msg}</p>}
    <h2 className="os-h2">Tomorrow · {dayLabel(date)}</h2>
    {days.length ? days.map(d => { const { subject, body } = composeFor(d, date, c); const e = emailOf(d.provider); const k = `${date}|${d.provider}`; const s = sentLog()[k];
      return <article key={d.provider} className="os-mail" data-testid="os-daily-preview"><header><Mail size={16} /><div><b>{subject}</b><span>To {d.provider} · {e.to}{e.demo ? ' (demo address: add the email in Providers)' : ''}</span></div><span className={`v10-chip ${s ? 'ok' : 'warn'}`}>{s ? `Sent ${new Date(s).toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' })}` : `Sends at ${hm(c.time)}`}</span></header><pre>{body}</pre></article>; })
      : <p className="v10-sub">No {many} tomorrow yet.</p>}
    {sent.length > 0 && <><h2 className="os-h2">Recently sent</h2><table className="v10-table"><tbody>{sent.map(o => <tr key={o.id}><td>{new Date(o.at).toLocaleString('en-US', { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' })}</td><td>{o.to}</td><td>{o.subject}</td></tr>)}</tbody></table></>}
    <p className="v10-sub">One {one} line per patient: time, patient, {SRC?.title === 'surgery schedule' ? 'procedure, room and anesthesia' : 'visit type, reason and room or video / phone'}. Only the provider’s own list is sent.</p>
  </div>;
};
