/* Vityls OS v11.4 · database connectivity (client side).
 * Offline-first write-through sync between the browser cache (localStorage, where every screen reads and writes records
 * synchronously) and the Vityls record store API (server.ts › /api/v1/store › Azure SQL app.record).
 *   1. On load, before the app starts: GET the records and put them in the cache. If the database is empty for a tenant,
 *      this device seeds it with what it has (first device / migration from a test browser).
 *   2. Every record the app saves or deletes is queued and sent in one PUT a moment later (batched). If the API cannot be
 *      reached the queue waits and retries; nothing is lost while the tab is open.
 *   3. Every 15 seconds: GET changes made by other devices since the last sync and apply them; the screens refresh.
 * Two channels (v11.4):
 *   · the practice  — tenant = the practice id (harbor / coastline / bayview …), keys in the practice namespace;
 *   · the Portal    — tenant = 'portal', keys `vityls:portal:*`: patient-owned accounts and the practice ↔ patient hub
 *                     (links, items, history, notifications, caregivers). Not owned by any practice, so every practice app
 *                     and the Vityls.com Portal read the same records.
 * Turned on by ?api=<url> (remembered on this device), VITE_API_URL at build time, or window.VITYLS_API_URL. ?api=off turns
 * it off. Without it the app runs on the browser cache only, as before. Fictional data in this test build. */
import { NAMESPACE, TENANT, rawStorage } from '../../edition';

const env = ((import.meta as any).env || {}) as Record<string, string | undefined>;
const CFG = 'vityls:api';
function apiUrl(): string {
  try { const q = new URLSearchParams(location.search).get('api'); if (q === 'off') { rawStorage.removeItem(CFG); return ''; } if (q) { rawStorage.setItem(CFG, q); return q; } } catch { /* */ }
  return rawStorage.getItem(CFG) || String(env.VITE_API_URL || '') || String((window as any).VITYLS_API_URL || '');
}
export const API = apiUrl().replace(/\/$/, '');
export const REMOTE = !!API;
/** Device-only keys: API config, sign-in sessions, the profile being viewed, guest counters, view preferences. */
const LOCAL_ONLY = /^(vityls:api|vityls:core:active|vityls:asc10:demo|vityls:practice-edition)|session|:actor$|^vityls:portal:(viewing|guest|finder-mode|finder-proxy)$/i;
export const PORTAL_TENANT = 'portal';
const isPortalKey = (k: string) => k.startsWith('vityls:portal:');
interface Channel { tenant: string; match: (k: string) => boolean; since: string; queue: Map<string, string | null>; timer: any; inflight: boolean }
const mk = (tenant: string, match: (k: string) => boolean): Channel => ({ tenant, match: k => !LOCAL_ONLY.test(k) && match(k), since: `vityls:api-since:${tenant}`, queue: new Map(), timer: 0, inflight: false });
const CH: Channel[] = [
  mk(TENANT, k => !isPortalKey(k) && (NAMESPACE ? k.startsWith(NAMESPACE) : k.startsWith('vityls'))),
  ...(TENANT === PORTAL_TENANT ? [] : [mk(PORTAL_TENANT, isPortalKey)]),
];
const channelOf = (k: string) => CH.find(c => c.match(k));
const proto = Storage.prototype; const origSet = proto.setItem; const origRemove = proto.removeItem;
const LS: Storage = rawStorage;
const headers = (tenant: string): Record<string, string> => ({ 'Content-Type': 'application/json', 'X-Vityls-Tenant': tenant, ...(env.VITE_API_TOKEN ? { Authorization: `Bearer ${env.VITE_API_TOKEN}` } : {}) });

export type SyncState = 'off' | 'loading' | 'saved' | 'saving' | 'offline' | 'error';
export const sync = { state: (REMOTE ? 'loading' : 'off') as SyncState, pending: 0, last: '', backend: '' };
const pending = () => CH.reduce((n, c) => n + c.queue.size, 0);
const emit = () => { try { window.dispatchEvent(new CustomEvent('vityls-sync', { detail: { ...sync } })); } catch { /* */ } badge(); };

function badge() { if (!REMOTE) return; let el = document.getElementById('vityls-sync-badge'); if (!el) { el = document.createElement('div'); el.id = 'vityls-sync-badge'; el.setAttribute('role', 'status'); el.setAttribute('data-testid', 'sync-badge'); el.style.cssText = 'position:fixed;right:12px;top:58px;z-index:90;font:600 12px/1 system-ui,sans-serif;padding:6px 10px;border-radius:999px;background:#fff;border:1px solid #d9d1c4;color:#1f5d45;box-shadow:0 2px 8px rgba(0,0,0,.08);pointer-events:none'; document.body?.appendChild(el); }
  const t: Record<SyncState, string> = { off: '', loading: 'Database · loading…', saved: 'Database · saved', saving: `Database · saving ${sync.pending}…`, offline: `Database · offline · ${sync.pending} waiting`, error: 'Database · error (retrying)' };
  el.textContent = t[sync.state]; el.style.color = sync.state === 'offline' || sync.state === 'error' ? '#8C2620' : '#1f5d45'; el.dataset.state = sync.state; }

async function flush(c: Channel) {
  if (c.inflight || !c.queue.size) return; c.inflight = true; const items = [...c.queue.entries()].map(([k, v]) => ({ k, v })); c.queue.clear(); sync.pending = pending() + items.length; sync.state = 'saving'; emit();
  try { const r = await fetch(`${API}/v1/store`, { method: 'PUT', headers: headers(c.tenant), body: JSON.stringify({ items, by: actorName() }) }); if (!r.ok) throw new Error(String(r.status)); const j = await r.json(); sync.last = j.at; sync.pending = pending(); sync.state = sync.pending ? 'saving' : 'saved'; }
  catch { items.forEach(i => { if (!c.queue.has(i.k)) c.queue.set(i.k, i.v); }); sync.pending = pending(); sync.state = 'offline'; window.setTimeout(() => flush(c), 5000); }
  finally { c.inflight = false; emit(); if (c.queue.size && sync.state !== 'offline') schedule(c); }
}
const schedule = (c: Channel) => { clearTimeout(c.timer); c.timer = setTimeout(() => flush(c), 400); };
function actorName() { try { for (let i = 0; i < LS.length; i++) { const k = LS.key(i) || ''; if (/actor$/.test(k) && k.startsWith(NAMESPACE)) { const v = JSON.parse(LS.getItem(k) || 'null'); if (v?.name) return `${v.name} (${v.role || ''})`; } } } catch { /* */ } return 'Vityls app'; }

function apply(c: Channel, items: { k: string; v: string | null }[]) { let n = 0; items.forEach(i => { if (!c.match(i.k)) return; if (c.queue.has(i.k)) return; const cur = LS.getItem(i.k); if (i.v === null) { if (cur !== null) { origRemove.call(LS, i.k); n++; } } else if (cur !== i.v) { origSet.call(LS, i.k, i.v); n++; } }); return n; }
async function pull(c: Channel) { try { const since = LS.getItem(c.since) || ''; const r = await fetch(`${API}/v1/store${since ? `?since=${encodeURIComponent(since)}` : ''}`, { headers: headers(c.tenant) }); if (!r.ok) throw new Error(String(r.status)); const j = await r.json();
    const n = apply(c, j.items || []); origSet.call(LS, c.since, j.now); if (n) ['vityls-med-updated', 'vityls-core-updated', 'vityls-billing-updated', 'vityls-portal-hub'].forEach(e => window.dispatchEvent(new Event(e))); if (sync.state === 'offline' || sync.state === 'error') { sync.state = pending() ? 'saving' : 'saved'; emit(); flush(c); } }
  catch { if (sync.state !== 'offline') { sync.state = 'offline'; emit(); } } }

/** First load of one channel: take the database's records, or seed the database from this device when it is empty. */
async function load(c: Channel) {
  const r = await fetch(`${API}/v1/store`, { headers: headers(c.tenant) }); if (!r.ok) throw new Error(String(r.status)); const j = await r.json(); const items: { k: string; v: string | null }[] = j.items || [];
  if (!items.filter(i => i.v !== null).length) { for (let i = 0; i < LS.length; i++) { const k = LS.key(i) || ''; if (c.match(k)) c.queue.set(k, LS.getItem(k) || ''); } }
  else { const keep = new Set(items.map(i => i.k)); const drop: string[] = []; for (let i = 0; i < LS.length; i++) { const k = LS.key(i) || ''; if (c.match(k) && !keep.has(k)) drop.push(k); } drop.forEach(k => origRemove.call(LS, k)); apply(c, items); }
  origSet.call(LS, c.since, j.now);
}

/** Load the practice's and the Portal's records before the app starts, then keep the cache and the database in step. */
export async function startRemote(): Promise<void> {
  if (!REMOTE) return;
  try {
    const h = await fetch(`${API}/v1/health`, { headers: headers(TENANT) }).then(r => r.json()).catch(() => null); sync.backend = h?.backend || '';
    await Promise.all(CH.map(load)); sync.pending = pending(); sync.state = sync.pending ? 'saving' : 'saved';
  } catch { sync.state = 'offline'; }
  proto.setItem = function (this: Storage, k: string, v: string) { origSet.call(this, k, v); const c = this === LS ? channelOf(k) : undefined; if (c) { c.queue.set(k, String(v)); sync.pending = pending(); schedule(c); } };
  proto.removeItem = function (this: Storage, k: string) { origRemove.call(this, k); const c = this === LS ? channelOf(k) : undefined; if (c) { c.queue.set(k, null); sync.pending = pending(); schedule(c); } };
  window.setInterval(() => CH.forEach(pull), 15000); window.addEventListener('online', () => CH.forEach(c => { pull(c); flush(c); }));
  window.addEventListener('beforeunload', () => CH.forEach(c => { if (c.queue.size) { try { navigator.sendBeacon?.(`${API}/v1/store-beacon`, JSON.stringify({ items: [...c.queue.entries()].map(([k, v]) => ({ k, v })), tenant: c.tenant })); } catch { /* */ } } }));
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', () => emit()); else emit();
  CH.forEach(c => { if (c.queue.size) schedule(c); });
}
