/*
 * Doctor Finder (Portal v0.3) · one provider adapter, two modes.
 *  - live: NPPES NPI Registry API v2.1. The API sends no CORS headers, so a browser call fails; in production the
 *    request goes through Henry's backend proxy/cache (GET /api/providers?...), configurable here.
 *  - snapshot: real public NPI results fetched from the box with curl (scripts/fetch_npi_snapshot.py), bundled.
 * Vityls in-network entries are FICTIONAL test practices (never real doctors badged as Vityls).
 * Nightingale lists providers; she never ranks or recommends one doctor as better.
 */
// @ts-ignore json import (vite)
import snapshot from './npi_snapshot.json';
import { rawStorage } from '../edition';

export interface Provider { npi: string; type: string; first: string; last: string; middle: string; credential: string; sex: string; org: string; specialty: string; taxonomy: string; taxonomies: string[]; enumerated: string; updated: string; line1: string; line2: string; city: string; state: string; zip: string; phone: string; fax: string; vityls?: { practiceId: string; practiceName: string }; fictional?: boolean; }
export interface Query { name?: string; specialty?: string; org?: string; city?: string; state?: string; zip?: string; }
export type Mode = 'snapshot' | 'live';
export const SNAPSHOT_INFO = { source: (snapshot as any).source as string, fetched: (snapshot as any).fetched as string, count: (snapshot as any).providers.length as number };
export const NPPES_URL = 'https://npiregistry.cms.hhs.gov/api/';

/** Fictional Vityls practices in the directory (test entries, clearly labeled). */
const VITYLS: Provider[] = [
  { npi: 'TEST-0000001', type: 'NPI-1', first: 'Sam', last: 'Patel', middle: '', credential: 'MD', sex: 'M', org: 'Coastline Plastic Surgery', specialty: 'Plastic Surgery', taxonomy: '208200000X', taxonomies: ['Plastic Surgery'], enumerated: '2009-03-02', updated: '2026-01-10', line1: '100 Fictional Way', line2: 'Suite 200', city: 'Beverly Hills', state: 'CA', zip: '90210', phone: '555-010-2000', fax: '555-010-2001', vityls: { practiceId: 'coastline', practiceName: 'Coastline Plastic Surgery' }, fictional: true },
  { npi: 'TEST-0000002', type: 'NPI-1', first: 'Dana', last: 'Kim', middle: '', credential: 'MD', sex: 'F', org: 'Bayview Family Medicine', specialty: 'Family Medicine', taxonomy: '207Q00000X', taxonomies: ['Family Medicine'], enumerated: '2012-07-16', updated: '2026-02-01', line1: '200 Example Blvd', line2: '', city: 'Los Angeles', state: 'CA', zip: '90048', phone: '555-010-3000', fax: '555-010-3001', vityls: { practiceId: 'bayview', practiceName: 'Bayview Family Medicine' }, fictional: true },
  { npi: 'TEST-0000003', type: 'NPI-2', first: '', last: '', middle: '', credential: '', sex: '', org: 'Harborview Surgery Center', specialty: 'Ambulatory Surgical Center', taxonomy: '261QA1903X', taxonomies: ['Ambulatory Surgical Center'], enumerated: '2014-04-01', updated: '2026-03-01', line1: '300 Sample Harbor Dr', line2: '', city: 'Long Beach', state: 'CA', zip: '90802', phone: '555-010-4000', fax: '555-010-4001', vityls: { practiceId: 'harbor', practiceName: 'Harborview Surgery Center' }, fictional: true },
];
const clean = (p: any): Provider => { const o: any = { ...p }; ['first', 'last', 'middle', 'credential', 'sex', 'org', 'specialty', 'taxonomy', 'enumerated', 'updated', 'line1', 'line2', 'city', 'state', 'zip', 'phone', 'fax'].forEach(k => { o[k] = o[k] == null ? '' : String(o[k]); }); o.taxonomies = (o.taxonomies || []).filter(Boolean); return o; };
const ALL: Provider[] = [...VITYLS, ...((snapshot as any).providers as any[]).map(clean)];

export const MODE_KEY = 'vityls:portal:finder-mode'; export const PROXY_KEY = 'vityls:portal:finder-proxy';
export const getMode = (): Mode => (rawStorage.getItem(MODE_KEY) as Mode) || 'snapshot';
export const setMode = (m: Mode) => rawStorage.setItem(MODE_KEY, m);
export const proxyUrl = () => rawStorage.getItem(PROXY_KEY) || '';

export const SPECIALTIES = ['Cardiovascular Disease', 'Dermatology', 'Endocrinology', 'Family Medicine', 'Gastroenterology', 'Internal Medicine', 'Neurology', 'Obstetrics & Gynecology', 'Ophthalmology', 'Orthopaedic Surgery', 'Pediatrics', 'Plastic Surgery'];
const WORDS: [RegExp, string][] = [[/cardiolog|heart/i, 'Cardiovascular Disease'], [/dermatolog|skin/i, 'Dermatology'], [/endocrin|diabet|thyroid/i, 'Endocrinology'], [/family|primary care|gp\b/i, 'Family Medicine'], [/gastro|stomach|gi\b/i, 'Gastroenterology'], [/internist|internal med/i, 'Internal Medicine'], [/neurolog/i, 'Neurology'], [/ob.?gyn|gyn|obstet/i, 'Obstetrics & Gynecology'], [/ophthalm|eye/i, 'Ophthalmology'], [/orthop|bone|joint/i, 'Orthopaedic Surgery'], [/pediatric|child/i, 'Pediatrics'], [/plastic/i, 'Plastic Surgery']];
/** Nightingale free text → query: “find a cardiologist near 90210”. */
export function parse(text: string): Query {
  const q: Query = {}; const sp = WORDS.find(([r]) => r.test(text)); if (sp) q.specialty = sp[1];
  const z = text.match(/\b(\d{5})\b/); if (z) q.zip = z[1];
  const c = text.match(/\bin ([A-Za-z .]+?)(?:,\s*([A-Z]{2}))?$/i); if (c && !z) { q.city = c[1].trim().replace(/\b\w/g, m => m.toUpperCase()); if (c[2]) q.state = c[2].toUpperCase(); }
  return q;
}
const norm = (s: string) => s.toLowerCase().replace(/[^a-z0-9]/g, '');
/** Specialty matches the NUCC taxonomy description (e.g. "Internal Medicine, Cardiovascular Disease"). */
const specMatch = (p: Provider, s: string) => { const n = norm(s.replace('&', '')); return p.taxonomies.some(t => norm(t.replace('&', '')).includes(n)) || p.taxonomy.toLowerCase() === s.toLowerCase(); };
export function searchSnapshot(q: Query): Provider[] {
  return ALL.filter(p => (!q.name || norm(`${p.first}${p.last}`).includes(norm(q.name)) || norm(`${p.last}${p.first}`).includes(norm(q.name)) || norm(p.org).includes(norm(q.name)))
    && (!q.specialty || specMatch(p, q.specialty)) && (!q.org || norm(p.org).includes(norm(q.org)))
    && (!q.city || norm(p.city) === norm(q.city)) && (!q.state || p.state === q.state.toUpperCase())
    && (!q.zip || (q.zip.length === 5 ? p.zip.slice(0, 3) === q.zip.slice(0, 3) : p.zip.startsWith(q.zip))));
}
/** Live: NPPES via the backend proxy when set, else the public API directly (fails in a browser: no CORS). */
export async function searchLive(q: Query): Promise<Provider[]> {
  const base = proxyUrl() || NPPES_URL; const u = new URLSearchParams({ version: '2.1', limit: '50' });
  if (q.name) { const [a, b] = q.name.trim().split(/\s+/); if (b) { u.set('first_name', a); u.set('last_name', b); } else u.set('last_name', a + '*'); }
  if (q.specialty) u.set('taxonomy_description', q.specialty); if (q.org) u.set('organization_name', q.org + '*');
  if (q.city) u.set('city', q.city); if (q.state) u.set('state', q.state); if (q.zip) u.set('postal_code', q.zip.slice(0, 5) + (q.zip.length === 5 ? '' : '*'));
  const r = await fetch(`${base}?${u}`); const d = await r.json(); return (d.results || []).map(fromNppes).map(clean);
}
export function fromNppes(r: any): Provider {
  const b = r.basic || {}; const loc = (r.addresses || []).find((a: any) => a.address_purpose === 'LOCATION') || (r.addresses || [])[0] || {}; const tx = (r.taxonomies || []).find((t: any) => t.primary) || (r.taxonomies || [])[0] || {};
  const t = (s: string) => (s || '').toLowerCase().replace(/\b\w/g, m => m.toUpperCase());
  return { npi: r.number, type: r.enumeration_type, first: t(b.first_name), last: t(b.last_name), middle: (b.middle_name || '').slice(0, 1), credential: b.credential || '', sex: b.sex || '', org: b.organization_name || '', specialty: tx.desc || '', taxonomy: tx.code || '', taxonomies: (r.taxonomies || []).map((x: any) => x.desc), enumerated: b.enumeration_date || '', updated: b.last_updated || '', line1: t(loc.address_1), line2: t(loc.address_2), city: t(loc.city), state: loc.state || '', zip: (loc.postal_code || '').slice(0, 5), phone: loc.telephone_number || '', fax: loc.fax_number || '' };
}
/** Try one live call and report what happened (for the mode label). */
export async function checkLive(): Promise<string> {
  try { const r = await searchLive({ city: 'Beverly Hills', state: 'CA', specialty: 'Dermatology' }); return `Live works: ${r.length} results${proxyUrl() ? ' via proxy' : ''}.`; }
  catch { return proxyUrl() ? 'The proxy did not answer. Using the bundled snapshot.' : 'Live NPPES is blocked in the browser (the API sends no CORS headers). Using the bundled snapshot until the Vityls backend proxy is set.'; }
}
export const displayName = (p: Provider) => p.type === 'NPI-2' ? p.org : `${p.first}${p.middle ? ' ' + p.middle + '.' : ''} ${p.last}${p.credential ? ', ' + p.credential.replace(/\./g, '').toUpperCase() : ''}`;
/** NPI does not record years in practice: estimate from the enumeration date, labeled. */
export function since(p: Provider) { const y = parseInt(p.enumerated.slice(0, 4)); if (!y) return ''; const n = new Date().getFullYear() - y; return y <= 2007 ? `NPI since ${y} (approx. ${n}+ yrs; NPIs began 2005–07, so likely longer)` : `NPI since ${y} (approx. ${n} yrs)`; }
export const phoneFmt = (s: string) => { const d = s.replace(/\D/g, ''); return d.length === 10 ? `(${d.slice(0, 3)}) ${d.slice(3, 6)}-${d.slice(6)}` : s; };
export type Sort = 'last' | 'first' | 'since-old' | 'since-new' | 'zip';
export function sortList(l: Provider[], s: Sort) {
  const c = [...l]; const k: Record<Sort, (a: Provider, b: Provider) => number> = { last: (a, b) => (a.last || a.org).localeCompare(b.last || b.org), first: (a, b) => a.first.localeCompare(b.first), 'since-old': (a, b) => a.enumerated.localeCompare(b.enumerated), 'since-new': (a, b) => b.enumerated.localeCompare(a.enumerated), zip: (a, b) => a.zip.localeCompare(b.zip) };
  return c.sort(k[s]);
}
export const byNpi = (npi: string) => ALL.find(p => p.npi === npi);
