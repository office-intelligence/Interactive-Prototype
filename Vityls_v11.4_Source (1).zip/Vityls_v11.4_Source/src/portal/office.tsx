/* Vityls OS v11.4 · the Patient Portal inside the practice apps (module portal-link).
 * The Portal (vityls.com) is patient-owned; a practice connects to a patient's account with consent (hub.ts). This file
 * brings what the patient does there into the practice's own screens:
 *   · PortalChartPanel   — chart › Portal tab: connection, what the patient sent, what the practice sent and its status
 *                          (signed form answers, check-in from home, bills paid), quick reply / message.
 *   · PortalStationPanel — Check-in station step "From the patient's Portal": check-in, forms and payments done at home.
 *   · portalSteps()      — Nightingale next steps for unanswered Portal requests (messages, refills, appointment requests).
 *   · autoMatch()        — connects a Portal account to the chart with the same email, or the same name and date of birth.
 * Everything is simulated (no real email/SMS/payment) and fictional in the test build. */
import React, { useEffect, useState } from 'react';
import * as H from './hub';
import { accounts } from './store';
import { medRepo, MedPatient } from '../med/record';
import { useActor, useMedTick } from '../med/ui';
import { corePractice, isCoreBuild, modVisible } from '../core/useCore';
import { BUILD_EDITION } from '../edition';
import type { NextStep } from '../os/next/next';
import './portal.css';

const NAMES: Record<string, string> = { coastline: 'Coastline Plastic Surgery', bayview: 'Bayview Family Medicine', harbor: 'Harborview Surgery Center' };
export const DOCTORS: Record<string, string> = { coastline: 'Sam Patel, MD', bayview: 'Dana Kim, MD', sierra: 'Sierra Vista team', 'harbor-asc': 'Harbor team', harbor: 'Harborview care team' };
/** The practice this app is running for (one-app: the practice record; edition builds: the edition's demo practice). */
export function practiceNow(): { id: string; name: string; doctor: string } {
  const cp = corePractice(); const id = cp?.id || (BUILD_EDITION === 'MEDICAL' ? 'bayview' : /ASC/.test(BUILD_EDITION) ? 'harbor' : 'coastline');
  return { id, name: cp?.name || NAMES[id] || id, doctor: DOCTORS[id] || '' };
}
export const portalOn = () => !isCoreBuild || modVisible('portal-link');
/** Opens the practice's Portal page (SurgeryApp listens). */
export const goPortalHub = () => window.dispatchEvent(new CustomEvent('vityls-go-tab', { detail: 'portal-hub' }));
export const linkOf = (pid: string) => H.practiceLinks(practiceNow().id).filter(l => l.corePatientId === pid && l.status !== 'revoked').sort((a, b) => (a.status === 'active' ? -1 : 1) - (b.status === 'active' ? -1 : 1))[0];

const norm = (s: string) => s.toLowerCase().replace(/[^a-z]/g, '');
/** Match Portal connections without a chart to the chart with the same email, or the same name and date of birth. */
export function autoMatch(): number {
  const p = practiceNow(); let n = 0; const accts = accounts(); const pts = medRepo.patients();
  H.practiceLinks(p.id).filter(l => l.status !== 'revoked' && !l.corePatientId).forEach(l => {
    const a = accts.find(x => x.id === l.acctId);
    const pt = pts.find(x => !!x.email && x.email.toLowerCase() === l.email) || pts.find(x => norm(x.name) === norm(l.patientName) && !!a?.dob && x.dob === a.dob);
    if (pt) { H.matchPatient(l.id, pt.id, pt.name, 'Nightingale (matched by ' + (pt.email?.toLowerCase() === l.email ? 'email' : 'name and date of birth') + ')'); n++; }
  });
  return n;
}
export const portalAccountOf = (l: H.Link) => accounts().find(a => a.id === l.acctId);

const KIND: Record<string, string> = { message: 'message', 'refill-request': 'refill request', 'appt-request': 'appointment request', form: 'form', checkin: 'check-in', bill: 'bill', reminder: 'reminder', document: 'document', result: 'result', 'refill-reply': 'refill answer' };
const STATUS: Record<string, string> = { sent: 'Sent', opened: 'Opened', signed: 'Signed', 'checked-in': 'Checked in from home', paid: 'Paid', confirmed: 'Confirmed', done: 'Done' };
const fmt = (d: string) => new Date(d).toLocaleString('en-US', { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' });
const first = (n: string) => n.split(' ')[0];

/** Nightingale next steps: every unanswered Portal request is a front-desk step (oldest first). */
export function portalSteps(): NextStep[] {
  if (!portalOn()) return [];
  const p = practiceNow(); const ls = H.practiceLinks(p.id);
  return H.waitingFor(p.id).map(it => { const l = ls.find(x => x.acctId === it.acctId); const who = l?.corePatientName || l?.patientName || it.by;
    return { id: `portal-${it.id}`, pid: l?.corePatientId || '', name: who, team: 'front' as const, title: `Answer ${first(who)}’s Portal ${KIND[it.kind] || 'request'}`, why: `${it.body ? `“${it.body.slice(0, 90)}${it.body.length > 90 ? '…' : ''}”` : it.title} · sent ${fmt(it.at)}.`, cta: 'Open Portal', urgency: 35 + Math.min(30, (Date.now() - Date.parse(it.at)) / 36e5), open: goPortalHub }; });
}

function useHubTick() { const [, s] = useState(0); useEffect(() => { const f = () => s(n => n + 1); ['vityls-portal-hub', 'storage', 'focus'].forEach(e => window.addEventListener(e, f)); return () => ['vityls-portal-hub', 'storage', 'focus'].forEach(e => window.removeEventListener(e, f)); }, []); }

/** Not connected yet: send a connection request to the Portal account with the chart's email. */
const Connect: React.FC<{ p: MedPatient; by: string }> = ({ p, by }) => {
  const [email, setEmail] = useState(p.email || ''); const [msg, setMsg] = useState(''); const pr = practiceNow();
  return <div data-testid="portal-connect"><p className="pp-muted" style={{ margin: '0 0 8px' }}>{p.name.split(' ')[0]} is not connected to the Vityls Portal yet. Patients own their Portal account (free at vityls.com); you connect with their consent, then forms, check-in, bills, messages and results go there.</p>
    <div className="pp-row"><input className="pp-input" value={email} onChange={e => setEmail(e.target.value)} placeholder="Patient's Portal email" aria-label="Patient's Portal email" data-testid="portal-connect-email" />
      <button type="button" className="pp-btn" disabled={!email.includes('@')} onClick={() => { const r = H.requestLink({ practiceId: pr.id, practiceName: pr.name, doctor: pr.doctor, corePatientId: p.id, corePatientName: p.name, email, by }); setMsg(typeof r === 'string' ? r : `Connection request sent to ${r.patientName}. They approve it in their Portal.`); }} data-testid="portal-connect-send">Send connection request</button></div>
    {msg && <p className="pp-note" data-testid="portal-connect-msg">{msg}</p>}</div>;
};

/** Answers of a signed form, in the order of its questions. */
const Answers: React.FC<{ it: H.Item }> = ({ it }) => !it.answers ? null : <dl className="pp-small" style={{ margin: '6px 0 0', display: 'grid', gridTemplateColumns: 'minmax(160px,auto) 1fr', gap: '2px 12px' }} data-testid="portal-answers">
  {Object.entries(it.answers).filter(([k]) => k !== '__signedBy').map(([k, v]) => <React.Fragment key={k}><dt className="pp-muted">{k}</dt><dd style={{ margin: 0 }}>{v || '—'}</dd></React.Fragment>)}
  {it.answers.__signedBy && <><dt className="pp-muted">Signed</dt><dd style={{ margin: 0 }}>{it.answers.__signedBy}</dd></>}</dl>;

/** Chart › Portal: the connection and everything exchanged with the patient's Portal. */
export const PortalChartPanel: React.FC<{ pid: string }> = ({ pid }) => {
  useHubTick(); useMedTick(); const [actor] = useActor(); const p = medRepo.patient(pid); const [txt, setTxt] = useState(''); const [rep, setRep] = useState<Record<string, string>>({}); const [msg, setMsg] = useState('');
  useEffect(() => { autoMatch(); }, [pid]);
  if (!p) return null; const l = linkOf(pid);
  const send = (kind: H.ItemKind, x: Partial<H.Item>) => { if (!l) return; const r = H.sendFromPractice(l, kind, x, actor.name); setMsg(typeof r === 'string' ? r : `Sent to ${first(l.patientName)}’s Portal: ${r.title}`); };
  return <section className="v7-card mb-4 pp-hub" style={{ padding: '16px 18px' }} data-testid="portal-chart">
    <div className="pp-row" style={{ justifyContent: 'space-between' }}><h3 className="v7-h3" style={{ margin: 0 }}>Vityls Portal</h3><button type="button" className="pp-link" onClick={goPortalHub} data-testid="portal-open-hub">Open the practice’s Portal page ›</button></div>
    {!l ? <Connect p={p} by={actor.name} /> : l.status === 'pending' ? <p className="pp-note" data-testid="portal-pending">Connection request sent {fmt(l.requestedAt)} to {l.email}. Waiting for {first(l.patientName)} to approve it in the Portal.</p> : (() => {
      const its = H.itemsFor(l.acctId, l.practiceId); const fromPt = its.filter(i => i.from === 'patient'); const sent = its.filter(i => i.from === 'practice');
      return <>
        <p className="pp-muted" style={{ margin: '4px 0 10px' }} data-testid="portal-status">Connected since {fmt(l.grantedAt || l.requestedAt)} · {l.email} · consent for {l.scopes.join(', ')}. Everything you send is free for the patient.</p>
        {msg && <p className="pp-note" data-testid="portal-msg">{msg}</p>}
        <h4 className="pp-h4">From {first(l.patientName)}</h4>
        {!fromPt.length && <p className="pp-muted pp-small">Nothing from the patient yet.</p>}
        {fromPt.map(r => { const replied = its.some(x => x.replyTo === r.id); return <div key={r.id} className="pp-li" data-testid="portal-from-patient"><div><b>{r.title}</b> <span className="pp-muted pp-small">{r.by} · {fmt(r.at)}</span><div className="pp-small">{r.body}</div></div>
          {replied ? <span className="pp-free pp-small">Answered</span> : <div className="pp-row"><input className="pp-input" value={rep[r.id] || ''} onChange={e => setRep({ ...rep, [r.id]: e.target.value })} placeholder="Reply" aria-label={`Reply to ${r.title}`} data-testid="portal-reply-text" /><button type="button" className="pp-btn" disabled={!(rep[r.id] || '').trim()} onClick={() => { send(r.kind === 'refill-request' ? 'refill-reply' : 'message', { title: 'Reply', body: rep[r.id], replyTo: r.id }); setRep({ ...rep, [r.id]: '' }); }} data-testid="portal-reply">Reply</button></div>}</div>; })}
        <h4 className="pp-h4">Sent to the Portal</h4>
        {!sent.length && <p className="pp-muted pp-small">Nothing sent yet.</p>}
        {sent.map(i => <div key={i.id} className="pp-li" data-testid="portal-sent"><div><b>{i.title}</b>{i.amount ? ` · $${i.amount.toFixed(2)}` : ''} <span className="pp-muted pp-small">{fmt(i.at)} · {i.by}</span>{i.kind === 'form' && i.status === 'signed' && <Answers it={i} />}</div><span className={'pp-flag ' + (/signed|paid|checked-in|confirmed|done/.test(i.status) ? 'normal' : 'high')} data-testid="portal-sent-status">{STATUS[i.status] || i.status}</span></div>)}
        <div className="pp-row" style={{ marginTop: 10 }}><input className="pp-input" value={txt} onChange={e => setTxt(e.target.value)} placeholder={`Message to ${first(l.patientName)}’s Portal`} aria-label="Message to the patient's Portal" data-testid="portal-text" /><button type="button" className="pp-btn" disabled={!txt.trim()} onClick={() => { send('message', { title: 'Message', body: txt.trim() }); setTxt(''); }} data-testid="portal-send">Send</button></div>
      </>; })()}
  </section>;
};

/** Check-in station · "From the patient's Portal": what the patient already did at home for this practice. */
export const PortalStationPanel: React.FC<{ pid: string }> = ({ pid }) => {
  useHubTick(); const [actor] = useActor(); const p = medRepo.patient(pid); useEffect(() => { autoMatch(); }, [pid]);
  if (!p) return null; const l = linkOf(pid);
  if (!l) return <div className="pp-hub" data-testid="portal-station"><Connect p={p} by={actor.name} /></div>;
  if (l.status !== 'active') return <p className="pp-note" data-testid="portal-station">Waiting for {first(l.patientName)} to approve the Portal connection.</p>;
  const its = H.itemsFor(l.acctId, l.practiceId).filter(i => i.from === 'practice'); const ci = its.find(i => i.kind === 'checkin'); const forms = its.filter(i => i.kind === 'form'); const bills = its.filter(i => i.kind === 'bill'); const waiting = H.waitingFor(l.practiceId).filter(i => i.acctId === l.acctId);
  const Row: React.FC<{ ok: boolean; label: string; detail: string; children?: React.ReactNode; tid: string }> = ({ ok, label, detail, children, tid }) => <div className="pp-li" data-testid={tid}><div><b>{label}</b> <span className="pp-small pp-muted">{detail}</span>{children}</div><span className={'pp-flag ' + (ok ? 'normal' : 'high')}>{ok ? 'Done' : 'Not yet'}</span></div>;
  return <div className="pp-hub" data-testid="portal-station">
    <p className="pp-muted pp-small" style={{ margin: '0 0 6px' }}>{first(p.name)} uses the Vityls Portal. Done at home is not asked again here.</p>
    <Row tid="portal-st-checkin" ok={!!ci && ci.status === 'checked-in'} label="Check-in from home" detail={ci ? `${ci.title} · ${STATUS[ci.status] || ci.status}` : 'No check-in sent. Send one from the Portal page.'} />
    {forms.map(f => <Row key={f.id} tid="portal-st-form" ok={f.status === 'signed'} label={f.title} detail={STATUS[f.status] || f.status}>{f.status === 'signed' && <Answers it={f} />}</Row>)}
    {bills.map(b => <Row key={b.id} tid="portal-st-bill" ok={b.status === 'paid'} label={`${b.title} · $${(b.amount || 0).toFixed(2)}`} detail={b.status === 'paid' ? 'Paid in the Portal (simulated card)' : 'Not paid yet: collect at the desk or remind in the Portal'} />)}
    {!!waiting.length && <p className="pp-note" data-testid="portal-st-waiting">{waiting.length} Portal request{waiting.length === 1 ? '' : 's'} waiting: {waiting.map(w => w.title).join(', ')}. <button type="button" className="pp-link" onClick={goPortalHub}>Answer</button></p>}
  </div>;
};
