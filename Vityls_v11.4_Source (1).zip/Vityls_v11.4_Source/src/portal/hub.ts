/*
 * Vityls Core · Portal hub (v0.2). The shared data layer between Vityls practices (portal-link module) and the
 * patient-owned Portal. Uses the browser's RAW storage (never a practice namespace), so the Surgery/Core practice app
 * and the Portal in the same browser see the same links, items, history, notifications and caregiver grants.
 * Future tables: patient_practice_links, portal_items, portal_interactions (append-only), notifications, caregiver_access.
 * Everything is SIMULATED (no real email/SMS/payment) until a BAA is signed. Fictitious data only.
 */
import { rawStorage } from '../edition';

export type ItemKind = 'form' | 'checkin' | 'bill' | 'message' | 'refill-request' | 'refill-reply' | 'reminder' | 'document' | 'result' | 'appt-request';
export interface Link { id: string; acctId: string; patientName: string; email: string; practiceId: string; practiceName: string; doctor: string; corePatientId?: string; corePatientName?: string; scopes: string[]; status: 'pending' | 'active' | 'revoked'; requestedAt: string; requestedBy: string; grantedAt?: string; grantedBy?: string; revokedAt?: string; }
export interface LabPayload { name: string; code: string; value: number; unit: string; low: number; high: number; date: string; }
export interface Item { id: string; acctId: string; practiceId: string; practiceName: string; kind: ItemKind; from: 'practice' | 'patient'; title: string; body: string; amount?: number; lab?: LabPayload; due?: string; fields?: string[]; answers?: Record<string, string>; status: string; at: string; by: string; replyTo?: string; }
export interface Interaction { seq: number; id: string; at: string; acctId: string; practiceId: string | null; practiceName: string | null; actor: string; role: 'practice' | 'patient' | 'caregiver' | 'system'; action: string; itemId?: string; detail: string; }
export interface Notice { id: string; at: string; toAcct: string; profileAcct: string; profileName: string; kind: 'abnormal' | 'trend' | 'message' | 'document' | 'item' | 'caregiver'; text: string; read?: boolean; }
export interface Caregiver { id: string; ownerAcct: string; ownerName: string; email: string; name: string; relation: string; scope: 'full'; consent: string; status: 'invited' | 'active' | 'revoked'; invitedAt: string; acceptedAt?: string; caregiverAcct?: string; revokedAt?: string; revokedBy?: string; }

const K = { links: 'vityls:portal:hub:links', items: 'vityls:portal:hub:items', log: 'vityls:portal:hub:interactions', notes: 'vityls:portal:hub:notifications', cg: 'vityls:portal:hub:caregivers', accts: 'vityls:portal:accounts' };
const read = <T,>(k: string, d: T): T => { try { const v = rawStorage.getItem(k); return v ? JSON.parse(v) as T : d; } catch { return d; } };
const write = (k: string, v: unknown) => { rawStorage.setItem(k, JSON.stringify(v)); window.dispatchEvent(new Event('vityls-portal-hub')); };
const uid = (p: string) => p + Math.random().toString(36).slice(2, 10);
const now = () => new Date().toISOString();
export const HUB_KEYS = K;

export const links = () => read<Link[]>(K.links, []);
export const items = () => read<Item[]>(K.items, []);
export const interactions = () => read<Interaction[]>(K.log, []);
export const notices = () => read<Notice[]>(K.notes, []);
export const caregivers = () => read<Caregiver[]>(K.cg, []);
const acctList = () => read<{ id: string; email: string; name: string }[]>(K.accts, []);

/** Append-only history: there is no update or delete for interactions. */
export function log(e: Omit<Interaction, 'seq' | 'id' | 'at'>) { const l = interactions(); l.push({ ...e, seq: l.length + 1, id: uid('ix-'), at: now() }); write(K.log, l); }
export const historyFor = (acctId: string, practiceId?: string) => interactions().filter(i => i.acctId === acctId && (!practiceId || i.practiceId === practiceId)).sort((a, b) => b.seq - a.seq);
export const practiceHistory = (practiceId: string) => interactions().filter(i => i.practiceId === practiceId).sort((a, b) => b.seq - a.seq);

/* ---------- notifications: owner + every active caregiver ---------- */
export function notify(profileAcct: string, profileName: string, kind: Notice['kind'], text: string) {
  const to = [profileAcct, ...caregivers().filter(c => c.ownerAcct === profileAcct && c.status === 'active' && c.caregiverAcct).map(c => c.caregiverAcct!)];
  const l = notices(); to.forEach(t => l.push({ id: uid('nt-'), at: now(), toAcct: t, profileAcct, profileName, kind, text })); write(K.notes, l);
}
export const noticesFor = (acct: string) => notices().filter(n => n.toAcct === acct).sort((a, b) => b.at.localeCompare(a.at));
export function markRead(acct: string) { write(K.notes, notices().map(n => n.toAcct === acct ? { ...n, read: true } : n)); }

/* ---------- practice ↔ patient links (consent) ---------- */
export function requestLink(p: { practiceId: string; practiceName: string; doctor: string; corePatientId?: string; corePatientName?: string; email: string; by: string }): Link | string {
  const a = acctList().find(x => x.email === p.email.trim().toLowerCase());
  if (!a) return 'No Vityls Portal account uses that email. The patient can create one for free, then you can link.';
  const ex = links().find(l => l.acctId === a.id && l.practiceId === p.practiceId && l.status !== 'revoked'); if (ex) return ex;
  const l: Link = { id: uid('lk-'), acctId: a.id, patientName: a.name, email: a.email, practiceId: p.practiceId, practiceName: p.practiceName, doctor: p.doctor, corePatientId: p.corePatientId, corePatientName: p.corePatientName, scopes: ['forms', 'check-in', 'bills', 'messages', 'refills', 'reminders', 'documents', 'results'], status: 'pending', requestedAt: now(), requestedBy: p.by };
  write(K.links, [...links(), l]);
  log({ acctId: a.id, practiceId: p.practiceId, practiceName: p.practiceName, actor: p.by, role: 'practice', action: 'link.requested', detail: `${p.practiceName} asked to connect to your Portal (patient record: ${p.corePatientName || 'not chosen'})` });
  notify(a.id, a.name, 'item', `${p.practiceName} wants to connect to your Portal. Review it in Care team.`);
  return l;
}
function setLink(id: string, f: (l: Link) => void) { write(K.links, links().map(l => { if (l.id === id) f(l); return l; })); }
export function answerLink(id: string, accept: boolean, actor: string, role: 'patient' | 'caregiver') {
  const l = links().find(x => x.id === id)!; setLink(id, x => { x.status = accept ? 'active' : 'revoked'; if (accept) { x.grantedAt = now(); x.grantedBy = actor; } else x.revokedAt = now(); });
  log({ acctId: l.acctId, practiceId: l.practiceId, practiceName: l.practiceName, actor, role, action: accept ? 'link.granted' : 'link.declined', detail: accept ? `Consent given: ${l.practiceName} may send ${l.scopes.join(', ')}` : 'Connection declined' });
}
export function revokeLink(id: string, actor: string, role: 'patient' | 'caregiver') { const l = links().find(x => x.id === id)!; setLink(id, x => { x.status = 'revoked'; x.revokedAt = now(); }); log({ acctId: l.acctId, practiceId: l.practiceId, practiceName: l.practiceName, actor, role, action: 'link.revoked', detail: `Consent revoked for ${l.practiceName}` }); }
export const linksFor = (acctId: string) => links().filter(l => l.acctId === acctId);
export const practiceLinks = (practiceId: string) => links().filter(l => l.practiceId === practiceId);

/* ---------- items ---------- */
const ACTION: Record<ItemKind, string> = { form: 'form.sent', checkin: 'checkin.sent', bill: 'bill.sent', message: 'message.sent', 'refill-request': 'refill.requested', 'refill-reply': 'refill.replied', reminder: 'reminder.sent', document: 'document.sent', result: 'result.sent', 'appt-request': 'appointment.requested' };
export function sendFromPractice(link: Link, kind: ItemKind, f: Partial<Item>, by: string): Item | string {
  const l = links().find(x => x.id === link.id); if (!l || l.status !== 'active') return 'The patient has not given (or has revoked) consent for this connection.';
  const it: Item = { id: uid('it-'), acctId: l.acctId, practiceId: l.practiceId, practiceName: l.practiceName, kind, from: 'practice', title: f.title || kind, body: f.body || '', amount: f.amount, lab: f.lab, due: f.due, fields: f.fields, status: 'sent', at: now(), by, replyTo: f.replyTo };
  write(K.items, [...items(), it]);
  log({ acctId: l.acctId, practiceId: l.practiceId, practiceName: l.practiceName, actor: by, role: 'practice', action: ACTION[kind], itemId: it.id, detail: it.title + (it.amount ? ` · $${it.amount.toFixed(2)}` : '') });
  const abn = it.lab && (it.lab.value > it.lab.high || it.lab.value < it.lab.low);
  notify(l.acctId, l.patientName, kind === 'message' || kind === 'refill-reply' ? 'message' : kind === 'result' ? (abn ? 'abnormal' : 'document') : kind === 'document' ? 'document' : 'item',
    kind === 'result' ? `${l.practiceName} sent a result: ${it.lab!.name} ${it.lab!.value} ${it.lab!.unit}${abn ? ' (outside the reference range)' : ''}.` : `${l.practiceName}: ${it.title}`);
  return it;
}
export function patientSend(acctId: string, practiceId: string, kind: ItemKind, title: string, body: string, actor: string, role: 'patient' | 'caregiver', replyTo?: string): Item | string {
  const l = links().find(x => x.acctId === acctId && x.practiceId === practiceId && x.status === 'active'); if (!l) return 'This practice is not connected.';
  const it: Item = { id: uid('it-'), acctId, practiceId, practiceName: l.practiceName, kind, from: 'patient', title, body, status: 'sent', at: now(), by: actor, replyTo };
  write(K.items, [...items(), it]); log({ acctId, practiceId, practiceName: l.practiceName, actor, role, action: ACTION[kind], itemId: it.id, detail: `${title}${body ? ': ' + body.slice(0, 120) : ''}` }); return it;
}
/** Patient/caregiver acts on a practice item: opened, signed, checked in, paid, done. */
export function act(itemId: string, status: string, actor: string, role: 'patient' | 'caregiver' | 'practice', extra?: Partial<Item>, detail?: string) {
  let it: Item | undefined; write(K.items, items().map(x => { if (x.id === itemId) { it = { ...x, ...extra, status }; return it; } return x; }));
  if (it) log({ acctId: it.acctId, practiceId: it.practiceId, practiceName: it.practiceName, actor, role, action: `${it.kind}.${status}`, itemId, detail: detail || it.title });
}
export function markOpened(it: Item, actor: string, role: 'patient' | 'caregiver') { if (it.status === 'sent' && it.from === 'practice') act(it.id, 'opened', actor, role); }
export const itemsFor = (acctId: string, practiceId?: string) => items().filter(i => i.acctId === acctId && (!practiceId || i.practiceId === practiceId)).sort((a, b) => b.at.localeCompare(a.at));

/* ---------- caregiver access ---------- */
export const CONSENT_TEXT = (owner: string, name: string, rel: string) => `I, ${owner}, give ${name} (${rel}) full access to my Vityls Portal: records, labs, documents, medications, messages with my practices, forms, bills and notifications. ${name} can act for me and everything they do is recorded in my history. I can revoke this at any time.`;
export function inviteCaregiver(owner: { id: string; name: string }, name: string, email: string, relation: string): Caregiver | string {
  if (!name.trim() || !email.includes('@')) return 'Enter the family member’s name and email.';
  const em = email.trim().toLowerCase(); if (caregivers().some(c => c.ownerAcct === owner.id && c.email === em && c.status !== 'revoked')) return 'That person already has an invitation or access.';
  const c: Caregiver = { id: uid('cg-'), ownerAcct: owner.id, ownerName: owner.name, email: em, name: name.trim(), relation, scope: 'full', consent: CONSENT_TEXT(owner.name, name.trim(), relation), status: 'invited', invitedAt: now() };
  write(K.cg, [...caregivers(), c]);
  log({ acctId: owner.id, practiceId: null, practiceName: null, actor: owner.name, role: 'patient', action: 'caregiver.invited', detail: `${c.name} (${relation}, ${em}) invited with full access. Consent signed electronically.` });
  return c;
}
export function acceptCaregiver(id: string, cgAcct: { id: string; name: string }) {
  let c: Caregiver | undefined; write(K.cg, caregivers().map(x => { if (x.id === id) { c = { ...x, status: 'active', acceptedAt: now(), caregiverAcct: cgAcct.id }; return c; } return x; }));
  if (c) { log({ acctId: c.ownerAcct, practiceId: null, practiceName: null, actor: cgAcct.name, role: 'caregiver', action: 'caregiver.accepted', detail: `${cgAcct.name} accepted access to ${c.ownerName}’s Portal` }); notify(c.ownerAcct, c.ownerName, 'caregiver', `${cgAcct.name} now has access to ${c.ownerName}’s Portal.`); }
}
export function revokeCaregiver(id: string, actor: string) {
  let c: Caregiver | undefined; write(K.cg, caregivers().map(x => { if (x.id === id) { c = { ...x, status: 'revoked', revokedAt: now(), revokedBy: actor }; return c; } return x; }));
  if (c) log({ acctId: c.ownerAcct, practiceId: null, practiceName: null, actor, role: 'patient', action: 'caregiver.revoked', detail: `Access for ${c.name} (${c.relation}) revoked` });
}
export const caregiversOf = (ownerAcct: string) => caregivers().filter(c => c.ownerAcct === ownerAcct);
/** Profiles this account may open: its own + every active grant. Pending invites matched by email. */
export const grantsFor = (acct: { id: string; email: string }) => caregivers().filter(c => c.status === 'active' && c.caregiverAcct === acct.id);
export const invitesFor = (acct: { id: string; email: string }) => caregivers().filter(c => c.status === 'invited' && c.email === acct.email);

/** v0.3: the patient connects to a Vityls practice from the Doctor Finder (patient-initiated consent). */
export function patientConnect(acct: { id: string; name: string; email: string }, practiceId: string, practiceName: string, doctor: string, actor: string, role: 'patient' | 'caregiver'): Link {
  const ex = links().find(l => l.acctId === acct.id && l.practiceId === practiceId && l.status !== 'revoked');
  if (ex) { if (ex.status === 'pending') answerLink(ex.id, true, actor, role); return links().find(l => l.id === ex.id)!; }
  const l: Link = { id: uid('lk-'), acctId: acct.id, patientName: acct.name, email: acct.email, practiceId, practiceName, doctor, scopes: ['forms', 'check-in', 'bills', 'messages', 'refills', 'reminders', 'documents', 'results'], status: 'active', requestedAt: now(), requestedBy: actor, grantedAt: now(), grantedBy: actor };
  write(K.links, [...links(), l]);
  log({ acctId: acct.id, practiceId, practiceName, actor, role, action: 'link.patient-connected', detail: `Connected from the Doctor Finder to ${practiceName} (${doctor}); consent given for ${l.scopes.join(', ')}` });
  return l;
}

/** v11.4: the practice matches a Portal connection to a chart (a patient who connected from the Doctor Finder, or an email match). */
export function matchPatient(linkId: string, corePatientId: string, corePatientName: string, by: string) {
  const l = links().find(x => x.id === linkId); if (!l) return;
  setLink(linkId, x => { x.corePatientId = corePatientId; x.corePatientName = corePatientName; });
  log({ acctId: l.acctId, practiceId: l.practiceId, practiceName: l.practiceName, actor: by, role: 'practice', action: 'link.matched', detail: `Portal account matched to the chart of ${corePatientName}` });
}
/** v11.4: patient requests the practice has not answered yet (no reply item points at them). */
export const waitingFor = (practiceId: string) => { const all = items().filter(i => i.practiceId === practiceId); return all.filter(i => i.from === 'patient' && i.status === 'sent' && !all.some(x => x.replyTo === i.id)).sort((a, b) => a.at.localeCompare(b.at)); };
