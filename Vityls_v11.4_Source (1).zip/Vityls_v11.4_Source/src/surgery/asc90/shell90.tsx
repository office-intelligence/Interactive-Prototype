import { modOn } from '../../core/useCore';
/* ASC.Vityls v9.0 · Mockup v2 shell pieces: top-bar station shortcut pills + bell, and the floating "Ask Nightingale about this page"
 * bar (drafts only; nothing is sent). Fictional data. */
import React, { useState } from 'react';
import { Bell, Sparkles, ArrowUp } from 'lucide-react';
import { isoDay } from '../../med/record';
import { useMedTick } from '../../med/ui';
import * as A from '../asc8/logic';
import * as S from '../asc8/store';
import { openAsc } from '../asc8/ui';
import { openBench } from '../asc81/practice81';
import { XClose } from '../asc82/common';
import { useSv } from '../ui';
import { caseFlow } from './today90';
import { openPortal103, Portal103Host } from '../asc10/portal103';
void modOn; let curPidG = ''; const curPid = () => curPidG;
const firstAt = (locs: A.Loc[]) => S.cases().filter(c => c.date === isoDay() && locs.includes(c.loc)).sort((a, b) => A.toMin(a.time) - A.toMin(b.time))[0];
export const SHORT: [string, string, () => void][] = [
  ['portal', 'Portal/At-home', () => openPortal103(curPid())],
  ['front', 'Front desk', () => { const c = firstAt(['arrived']); openBench('arrival' as any, c?.id); }],
  ['preop', 'Pre-op', () => openBench('nursing' as any, firstAt(['arrived', 'preop'])?.id)],
  ['anes', 'Anesthesia', () => openBench('anesthesia' as any, firstAt(['preop', 'arrived'])?.id)],
  ['or', 'OR/Surgeon', () => { const c = firstAt(['or']); if (c) openAsc({ t: 'step', cid: c.id, station: 'or' }); else openBench('surgeon' as any); }],
  ['pacu', 'PACU/Discharge', () => openBench('pacu' as any, firstAt(['pacu'])?.id)]];
export const TopBar90: React.FC = () => { useMedTick(); const sv = useSv(); curPidG = sv?.patientId && ['patients', 'episode', 'station', 'chart'].includes(sv.tab as string) ? sv.patientId : ''; const n = S.flagsAll().filter((f: any) => f.status === 'open').length;
  return <span className="n9-top" data-testid="n9-top">{/* v10.7: station shortcut pills removed (Today rows, the journey bar and My station open stations) */}
    <Portal103Host /><button type="button" className="n9-bell" onClick={() => openAsc({ t: 'flag' })} aria-label={`Flags and messages (${n} open)`} data-testid="n9-bell"><Bell size={17} />{n > 0 && <i>{n}</i>}</button></span>; };

export function draftAnswer(q: string, page: string): string { const T = isoDay(); const cs = S.cases().filter(c => c.date === T); const fl = cs.map(c => ({ c, f: caseFlow(c) }));
  const nc = fl.filter(x => x.f.clear !== 'cleared'); const inP = cs.filter(c => ['arrived', 'preop', 'or', 'pacu'].includes(c.loc));
  if (/clear|missing|pending/i.test(q)) return nc.length ? `${nc.length} case${nc.length === 1 ? ' is' : 's are'} not cleared: ${nc.map(x => `${x.c.time.replace(/^0/, '')} (${x.f.missing.slice(0, 2).join(', ') || 'items pending'})`).join('; ')}.` : 'Every case today is cleared.';
  if (/late|delay|turnover/i.test(q)) return `${cs.filter(c => c.loc === 'scheduled').length} case${cs.length === 1 ? '' : 's'} still scheduled; ${inP.length} in progress. Turnover figures come from recorded OR times.`;
  return `On this ${page}: ${cs.length} cases today across ${new Set(cs.map(c => c.room)).size} rooms, ${inP.length} in progress, ${nc.length} not cleared. Ask about clearance, late starts or a patient.`; }
export const AskBar90: React.FC<{ page: string }> = ({ page }) => { const [q, setQ] = useState(''); const [a, setA] = useState('');
  return <div className="n9-ask" data-testid="n9-ask">{a && <div className="n9-askans" data-testid="n9-ask-answer"><div className="n9-askh"><Sparkles size={14} /><b>Nightingale · draft</b><XClose onClick={() => setA('')} testId="n9-ask-close" /></div><p>{a}</p><span className="n9-mu s">Draft only · nothing is sent or changed.</span></div>}
    <form className="n9-askbar" onSubmit={e => { e.preventDefault(); if (q.trim()) { setA(draftAnswer(q, page)); setQ(''); } }}><span className="n9-mark"><Sparkles size={14} /></span><input value={q} onChange={e => setQ(e.target.value)} placeholder="Ask Nightingale about this page" aria-label="Ask Nightingale about this page" data-testid="n9-ask-input" /><button type="submit" className="n9-send" aria-label="Ask" data-testid="n9-ask-go"><ArrowUp size={15} /></button></form></div>; };
