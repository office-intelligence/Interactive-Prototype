/* ASC.Vityls v10.6.4 · OR station: the intra-operative nursing record as ONE native checklist (no embedded forms).
 * The standard intra-op record (Universal Protocol sign-in, room & positioning, time-out, intra-op, counts, sign-out, hand-off)
 * is a fixed checklist in seven phases that follows the case. Two ways to fill the same list:
 *  - Talk: ambient listening (simulated). What the team says is matched to checklist items and drafted as "Heard";
 *    the circulator confirms per item or per phase.
 *  - Manual: the same items with checkboxes, tap buttons, chips, selectors and number keys.
 * OR times are tapped once to stamp (same event log as before). Values flow into the case record (time-out, counts, EBL,
 * wound class, implants, specimens) so every other screen keeps working. The circulator signs once with PIN, then sends the
 * patient to PACU. Fictional data. */
import React from 'react';
import { medRepo } from '../../med/record';
import * as A from '../asc8/logic';
import * as S from '../asc8/store';
import { BriefOpReport } from '../asc10/flow10';
import { PaperAnesRecord } from '../asc10/fixes10';
import { NativeStation, COUNT_ROWS, type Item, type Phase, type Def } from '../asc108/native108';
const allergyText = (c: A.AscCase) => { const a = medRepo.patient(c.pid)?.allergies || []; return a.length ? a.join('; ') : 'NKDA'; };

export const PHASES: Phase[] = [
  { id: 'signin', title: 'Sign-in', when: 'Before induction', items: [
    { id: 'id_verified', label: 'Patient identity confirmed: name, DOB and ID band', kind: 'check', req: true },
    { id: 'proc_site', label: c => `Procedure, site and side confirmed: ${c.procedure}`, kind: 'check', req: true },
    { id: 'consent', label: 'Surgical and anesthesia consents signed', kind: 'check', req: true },
    { id: 'site_marked', label: 'Site marked', kind: 'radio', opts: ['Yes', 'N/A · no laterality'], req: true },
    { id: 'allergies', label: c => `Allergies reviewed: ${allergyText(c)}`, kind: 'check', req: true },
    { id: 'anes_check', label: 'Anesthesia machine and medication check complete', kind: 'check', req: true },
    { id: 'pulse_ox', label: 'Pulse oximeter on and functioning', kind: 'check', req: true },
    { id: 'airway_risk', label: 'Difficult airway or aspiration risk', kind: 'radio', opts: ['No', 'Yes · equipment ready'], req: true },
    { id: 'blood_loss', label: 'Risk of > 500 mL blood loss', kind: 'radio', opts: ['No', 'Yes · access & fluids planned'], req: true },
    { id: 'implants_avail', label: 'Implants and special equipment available', kind: 'radio', opts: ['N/A', 'Yes · verified'], req: true },
    { id: 'vte', label: 'VTE prophylaxis', kind: 'multi', opts: ['SCDs on', 'Chemoprophylaxis given', 'Not indicated'], req: true },
    { id: 'antibiotic', label: 'Antibiotic within 60 min of incision', kind: 'radio', opts: ['Given', 'Given by anesthesia', 'Not indicated'], req: true },
  ] },
  { id: 'room', title: 'Room, team & positioning', when: 'Patient in room', items: [
    { id: 'ev_inRoom', label: 'In room', kind: 'time', event: 'inRoom', req: true },
    { id: 'team_surgeon', label: 'Surgeon', kind: 'select', dflt: c => c.surgeon, roles: ['Surgeon', 'Physician'], req: true },
    { id: 'team_anes', label: 'Anesthesia', kind: 'select', dflt: c => c.anesthesia, roles: ['Anesthesiologist', 'CRNA'], req: true },
    { id: 'team_circ', label: 'Circulating RN', kind: 'select', roles: ['Circulating RN', 'RN', 'Pre-op RN', 'PACU RN'], req: true },
    { id: 'team_scrub', label: 'Scrub', kind: 'select', roles: ['Scrub tech', 'Circulating RN', 'RN'], req: true },
    { id: 'team_other', label: 'Others in room (rep, student, X-ray)', kind: 'text' },
    { id: 'position', label: 'Position', kind: 'radio', opts: ['Supine', 'Prone', 'Lateral', 'Lithotomy', 'Beach chair', 'Jackknife'], req: true },
    { id: 'pos_aids', label: 'Positioning & safety', kind: 'multi', opts: ['Safety strap', 'Arm boards < 90°', 'Gel pads', 'Heels floated', 'Eyes protected', 'Pillows'], req: true },
    { id: 'pressure', label: 'Pressure points padded and checked', kind: 'check', req: true },
    { id: 'skin_pre', label: 'Skin before prep', kind: 'radio', opts: ['Intact', 'Issue noted'], req: true },
    { id: 'hair', label: 'Hair removal', kind: 'radio', opts: ['None', 'Clipped in OR', 'Clipped pre-op'] },
    { id: 'prep', label: 'Skin prep', kind: 'radio', opts: ['Chlorhexidine-alcohol', 'Povidone-iodine', 'Iodine-alcohol', 'Other'], req: true },
    { id: 'prep_dry', label: 'Prep dried ≥ 3 min before draping (fire safety)', kind: 'check', req: true },
    { id: 'esu', label: 'ESU dispersive pad', kind: 'radio', opts: ['R thigh', 'L thigh', 'Flank', 'Back', 'N/A'], req: true },
    { id: 'tourniquet', label: 'Tourniquet', kind: 'radio', opts: ['N/A', 'Applied'] },
    { id: 'warming', label: 'Warming', kind: 'multi', opts: ['Forced-air warmer', 'Warm blanket', 'Warm fluids', 'None'] },
    { id: 'catheter', label: 'Urinary catheter', kind: 'radio', opts: ['None', 'Foley placed', 'Straight cath'] },
  ] },
  { id: 'timeout', title: 'Time-out', when: 'Before incision', items: [
    { id: 'timeout', label: 'Time-out: patient, procedure, site and side, position, implants, antibiotic, images; all team members agree', kind: 'check', req: true },
    { id: 'fire_risk', label: 'Fire risk score', kind: 'radio', opts: ['Low (0–1)', 'Moderate (2)', 'High (3)'], req: true },
    { id: 'imaging', label: 'Essential imaging displayed', kind: 'radio', opts: ['N/A', 'Displayed'] },
    { id: 'ev_anesStart', label: 'Anesthesia start', kind: 'time', event: 'anesStart', req: true },
    { id: 'ev_incision', label: 'Incision', kind: 'time', event: 'incision', req: true },
  ] },
  { id: 'intraop', title: 'Intra-op', when: 'During the case', items: [
    { id: 'meds_field', label: 'Local, irrigation and medications on the field', kind: 'text', quick: ['None', '0.25% bupivacaine', 'Lidocaine 1%', 'NS irrigation'] },
    { id: 'implants', label: 'Implants (type, size, lot #)', kind: 'list', req: true },
    { id: 'specimens', label: 'Specimens (type, destination)', kind: 'list', req: true },
    { id: 'wound', label: 'Wound class', kind: 'radio', opts: ['I · Clean', 'II · Clean-contaminated', 'III · Contaminated', 'IV · Dirty'], req: true },
    { id: 'ebl', label: 'Estimated blood loss', kind: 'number', unit: 'mL', quick: ['Minimal', '10', '25', '50', '100'], req: true },
    { id: 'drains', label: 'Drains', kind: 'radio', opts: ['None', 'JP', 'Penrose', 'Other'] },
    { id: 'xray', label: 'Imaging during case', kind: 'radio', opts: ['None', 'Fluoroscopy', 'X-ray'] },
    { id: 'p_anes', label: '', kind: 'panel', render: c => <PaperAnesRecord c={c} /> },
  ] },
  { id: 'counts', title: 'Counts', when: 'Initial, closing, final', items: [
    { id: 'counts', label: 'Counts', kind: 'counts', req: true },
  ] },
  { id: 'signout', title: 'Sign-out & closure', when: 'Before leaving the room', items: [
    { id: 'ev_close', label: 'Closure', kind: 'time', event: 'close', req: true },
    { id: 'proc_done', label: c => `Procedure as performed recorded: ${c.procedure}`, kind: 'check', req: true },
    { id: 'spec_labeled', label: 'Specimen labels read back', kind: 'radio', opts: ['Yes', 'N/A · no specimen'], req: true },
    { id: 'equipment', label: 'Equipment problems', kind: 'radio', opts: ['None', 'Problem reported'], req: true },
    { id: 'dressing', label: 'Dressing', kind: 'radio', opts: ['Gauze & tape', 'Skin glue', 'Steri-strips', 'Island dressing', 'Transparent film', 'Other'], req: true },
    { id: 'skin_post', label: 'Skin after case', kind: 'radio', opts: ['Intact', 'Issue noted'], req: true },
    { id: 'esu_post', label: 'ESU pad site after removal', kind: 'radio', opts: ['Intact', 'Issue noted', 'N/A'], req: true },
    { id: 'ev_anesEnd', label: 'Anesthesia end', kind: 'time', event: 'anesEnd', req: true },
    { id: 'ev_outRoom', label: 'Out of room', kind: 'time', event: 'outRoom', req: true },
    { id: 'p_brief', label: 'Brief op report · surgeon signs', kind: 'panel', render: c => <BriefOpReport c={c} />, done: c => !!c.d.opReport?.signedAt },
  ] },
  { id: 'handoff', title: 'Hand-off to PACU', when: 'Leaving the OR', items: [
    { id: 'handoff_rn', label: 'Receiving PACU RN', kind: 'select', roles: ['PACU RN', 'RN', 'Pre-op RN'], req: true },
    { id: 'handoff', label: 'Verbal hand-off: procedure, anesthesia, EBL, meds, allergies, concerns', kind: 'check', req: true },
  ] },
];
export const SCRIPT: [string, Record<string, any>][] = [
  ['Circulator: Can you tell me your name and date of birth?', {}],
  ['Patient: {first}, born {dob}.', { id_verified: true }],
  ['Circulator: And what are we doing today?', {}],
  ['Patient: The {procedure}.', { proc_site: true }],
  ['Circulator: Consents are signed, the site is marked, allergies {allergy}.', { consent: true, site_marked: 'Yes', allergies: true }],
  ['Anesthesia: Machine and meds checked, pulse ox is on. No airway or aspiration concerns.', { anes_check: true, pulse_ox: true, airway_risk: 'No' }],
  ['Circulator: Low blood-loss risk, no implants beyond the mesh, and it is in the room. SCDs on. Antibiotic given.', { blood_loss: 'No', implants_avail: 'Yes · verified', vte: ['SCDs on'], antibiotic: 'Given' }],
  ['Circulator: Patient is supine, arms on boards under ninety, safety strap on, heels floated, pressure points padded.', { position: 'Supine', pos_aids: ['Safety strap', 'Arm boards < 90°', 'Heels floated'], pressure: true }],
  ['Circulator: Skin intact. Chlorhexidine prep, dry for three minutes. Grounding pad on the right thigh. Bair Hugger on.', { skin_pre: 'Intact', prep: 'Chlorhexidine-alcohol', prep_dry: true, esu: 'R thigh', warming: ['Forced-air warmer'], hair: 'None' }],
  ['Surgeon: Time-out. {first}, {procedure}, supine, mesh available, antibiotic in. Everyone agree?', { timeout: true }],
  ['Team: Agreed. Fire risk is low, no imaging needed.', { fire_risk: 'Low (0–1)', imaging: 'N/A' }],
  ['Scrub: Initial count, sponges ten, sharps and instruments correct.', { counts: { 'Sponges': { Initial: 'ok' }, 'Sharps / needles': { Initial: 'ok' }, 'Instruments': { Initial: 'ok' } } }],
  ['Surgeon: Twenty of quarter percent bupivacaine, please. Mesh is a 10 by 15, lot 4471.', { meds_field: '0.25% bupivacaine 20 mL', implants: { items: ['Mesh 10 × 15 cm · lot 4471'] } }],
  ['Surgeon: No specimen. Clean case. Blood loss about ten.', { specimens: { none: true }, wound: 'I · Clean', ebl: '10', drains: 'None', xray: 'None' }],
  ['Scrub: Closing count correct. Final count correct.', { counts: Object.fromEntries(COUNT_ROWS.map(r => [r, { Initial: 'ok', 'First closing': 'ok', Final: 'ok' }])) }],
  ['Circulator: Skin glue and gauze. Skin intact, pad site intact, no equipment problems. Procedure as performed, no specimen to label.', { dressing: 'Skin glue', skin_post: 'Intact', esu_post: 'Intact', equipment: 'None', proc_done: true, spec_labeled: 'N/A · no specimen' }],
];

const st = (by: string, what: string) => ({ by, at: new Date().toISOString(), what });
export const OR_DEF: Def = { st: 'or', bench: 'or', here: 'or', title: 'OR · Intra-op nursing record', storeKey: 'asc106-or', testId: 'a81-bench-or', phases: PHASES, script: SCRIPT, notes: 'OR',
  sync: (c, v, actor) => { let x = S.caseById(c.id)!;
    if (v('timeout') && !A.isDone(x, 'timeout')) x = S.setValue(x, 'timeout', st(actor.name, 'Time-out'), actor.name, actor.role, 'Time-out performed (OR record)');
    const cnt = v('counts'); if (cnt && COUNT_ROWS.every(rw => cnt[rw]?.Final === 'ok') && !A.isDone(x, 'counts')) x = S.setValue(x, 'counts', st(actor.name, 'Final counts correct'), actor.name, actor.role, 'Final counts correct (OR record)');
    const ebl = v('ebl'); if (ebl !== undefined && ebl !== '' && x.d.ebl !== ebl) x = S.setValue(x, 'ebl', ebl, actor.name, actor.role, `EBL ${ebl}${/^\d+$/.test(String(ebl)) ? ' mL' : ''}`);
    const w = v('wound'); if (w && x.d.wound !== w) x = S.setValue(x, 'wound', w, actor.name, actor.role, `Wound class ${w}`);
    (['implants', 'specimens'] as const).forEach(k => { const l = v(k); if (!l) return; const nv = l.none ? { none: true } : { list: (l.items || []).join('; ') }; if (JSON.stringify(x.d[k]) !== JSON.stringify(nv)) x = S.setValue(x, k, nv, actor.name, actor.role, `${k === 'implants' ? 'Implants' : 'Specimens'}: ${l.none ? 'none' : nv.list}`); }); },
  signs: [{ id: 'or', label: 'Sign intra-op record', roles: [...S.NURSE_ROLES, 'Circulating RN'], statement: (c, n) => `I recorded and reviewed the intra-operative nursing record for ${medRepo.patient(c.pid)?.name}.${n ? ` ${n} item(s) are open and become flags.` : ''}`,
    onSigned: (c, values, s, open) => { S.setValue(S.caseById(c.id)!, 'orRecord', { by: s.name, at: s.at, open, items: values }, s.name, s.role, `Intra-op nursing record signed with PIN${open.length ? ` (${open.length} open)` : ''}`); } }],
  footer: (c, x) => c.loc === 'or' ? <button type="button" className="a8-btn pri" disabled={!x.signed('or')} onClick={() => { S.toPacu(S.caseById(c.id)!, x.actor.name, x.actor.role); x.toast(`Patient to PACU. ${c.surgeon.replace(/,.*$/, '')} was flagged to dictate the op report.`); x.close(); }} title={x.signed('or') ? '' : 'Sign the record first'} data-testid="a8-to-pacu">Patient to PACU</button> : null };
export const OrStation106: React.FC<{ cid: string; onClose: () => void }> = ({ cid, onClose }) => <NativeStation def={OR_DEF} cid={cid} onClose={() => onClose()} />;
