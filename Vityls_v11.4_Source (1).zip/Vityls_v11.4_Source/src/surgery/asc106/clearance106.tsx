/* ASC.Vityls v10.6 · clearance review.
 *  - Every pre-op H&P, lab, ECG, clearance letter and other clearance document for the case is listed and linked at the first
 *    nurse station (Verify medical history), where the nurse opens and verifies each one.
 *  - Documents open full screen with a pen tool: pen, highlighter and an initials stamp, saved per document page. Clinicians
 *    can mark; everyone else can view. Every marking and every "reviewed" is audited.
 *  - A Nightingale clearance summary (draft, from the records brief) carries over to Nursing, Anesthesia, Surgeon and PACU.
 * Storage (browser, test build): asc106-review, asc106-marks. Henry: clearance_document_review, document_annotation. */
import React, { useEffect, useMemo, useRef, useState } from 'react';
import { FileText, Check, AlertTriangle, Pen, Highlighter, Stamp, Undo2, Trash2, X, ChevronLeft, ChevronRight, ShieldCheck, Hand } from 'lucide-react';
import { useActor, useMedTick } from '../../med/ui';
import { repo } from '../../v6/dataLayer';
import { svRead, svWrite } from '../store';
import * as A from '../asc8/logic';
import { s81, use81 } from '../asc81/store81';
import { recordsBrief, type RecPage, type BriefLine } from '../asc81/ai';
import { uploads } from '../asc87/store87';
import { openUpload } from '../asc87/ui87';
import { frontDocState } from '../asc10/flow10';
import { initials as initialsOf } from '../asc10/store10';
import './clearance106.css';

/* ---------------- model ---------------- */
export type DocKind = 'H&P' | 'Labs' | 'ECG' | 'Clearance' | 'Imaging' | 'Records';
export interface CDoc { id: string; title: string; kind: DocKind; date: string; source: 'records' | 'upload'; pages: { n: number; text?: string; data?: string; mime?: string }[]; name?: string }
export interface Review { by: string; role: string; at: string; initials: string }
export interface Mark { t: 'pen' | 'hi' | 'stamp'; color: string; pts?: [number, number][]; x?: number; y?: number; text?: string; by: string; at: string }

const CLEAR_UPLOAD_TYPES = ['Pre-op H&P', 'H&P + clearance', 'Medical clearance', 'Lab results', 'ECG', 'Imaging report', 'Surgeon office records'];
const kindOf = (s: string): DocKind => /lab|cbc|bmp|a1c|metabolic/i.test(s) ? 'Labs' : /\becg\b|\bekg\b|electrocardio/i.test(s) ? 'ECG' : /clearance|cleared/i.test(s) ? 'Clearance' : /h&p|history|physical|primary care|pcp/i.test(s) ? 'H&P' : /imaging|x-?ray|echo|ct\b|mri/i.test(s) ? 'Imaging' : 'Records';
export const CLINICAL_MARK_ROLES = /nurse|\brn\b|lvn|crna|anesthes|surgeon|physician|\bmd\b|\bdo\b|practitioner|\bnp\b|assistant \(pa\)|\bpa\b|medical director/i;

export function clearanceDocs(c: A.AscCase): CDoc[] {
  const pages = s81.pages(c.id) as RecPage[]; const by = new Map<string, RecPage[]>();
  pages.forEach(p => by.set(p.doc, [...(by.get(p.doc) || []), p]));
  const fromRecords: CDoc[] = [...by.entries()].map(([doc, ps]) => {
    const sorted = [...ps].sort((a, b) => a.page - b.page); const t = sorted[0].docTitle;
    return { id: `rec:${doc}`, title: t, kind: kindOf(t), date: sorted.map(p => p.date).sort().slice(-1)[0], source: 'records' as const, pages: sorted.map(p => ({ n: p.page, text: p.text })) };
  });
  const fromUploads: CDoc[] = uploads(c.id).filter(u => CLEAR_UPLOAD_TYPES.includes(u.type)).map(u => ({ id: `up:${u.id}`, title: u.type, kind: kindOf(u.type), date: (u.at || '').slice(0, 10), source: 'upload' as const, name: u.name, pages: [{ n: 1, data: u.data, mime: u.mime }] }));
  return [...fromRecords, ...fromUploads];
}
/** Expected documents (H&P, labs, ECG) with no copy on file. */
export function missingExpected(c: A.AscCase, docs: CDoc[]) {
  const st = frontDocState(c); const have = new Set(docs.map(d => d.kind));
  const want: [string, DocKind, string][] = [['hp', 'H&P', 'Pre-op H&P'], ['labs', 'Labs', 'Labs'], ['ecg', 'ECG', 'ECG']];
  return want.filter(([id, k]) => !have.has(k) && !(k === 'H&P' && have.has('Clearance'))).map(([id, , label]) => ({ label, marked: !!st.find(d => d.id === id)?.present }));
}

const REV = 'asc106-review'; const MARKS = 'asc106-marks'; const EV = 'asc106-doc';
const bump = () => window.dispatchEvent(new Event('vityls-med-updated'));
export const reviewsFor = (cid: string) => (svRead<Record<string, Record<string, Review>>>(REV, {})[cid] || {});
export function setReviewed(cid: string, docId: string, title: string, by: string, role: string) {
  const all = svRead<Record<string, Record<string, Review>>>(REV, {}); const r: Review = { by, role, at: new Date().toISOString(), initials: initialsOf(by) };
  svWrite(REV, { ...all, [cid]: { ...(all[cid] || {}), [docId]: r } });
  repo.audit({ caseId: `asc8:${cid}`, user: by, role, action: 'asc106.review' as any, detail: `Clearance document reviewed and initialed: ${title}` }); bump();
}
const markKey = (cid: string, docId: string, page: number) => `${cid}|${docId}|${page}`;
export const marksFor = (cid: string, docId: string, page: number) => svRead<Record<string, Mark[]>>(MARKS, {})[markKey(cid, docId, page)] || [];
function saveMarks(cid: string, docId: string, page: number, list: Mark[]) { const all = svRead<Record<string, Mark[]>>(MARKS, {}); svWrite(MARKS, { ...all, [markKey(cid, docId, page)]: list }); }
export const markCount = (cid: string, docId: string) => Object.entries(svRead<Record<string, Mark[]>>(MARKS, {})).filter(([k]) => k.startsWith(`${cid}|${docId}|`)).reduce((n, [, l]) => n + l.length, 0);

/** Open a clearance document full screen (from any station, the summary or the chart). */
export const openDoc = (cid: string, docId: string, page = 1) => window.dispatchEvent(new CustomEvent(EV, { detail: { cid, docId, page } }));

/* ---------------- full-screen viewer with pen tool ---------------- */
export const Doc106Host: React.FC = () => {
  const [o, setO] = useState<{ cid: string; docId: string; page: number } | null>(null);
  useEffect(() => { const h = (e: Event) => setO((e as CustomEvent).detail); window.addEventListener(EV, h); return () => window.removeEventListener(EV, h); }, []);
  if (!o) return null; return <DocViewer106 key={o.cid + o.docId} cid={o.cid} docId={o.docId} page0={o.page} onClose={() => setO(null)} />;
};

const COLORS = [['#C0262D', 'Red'], ['#1F4E8C', 'Blue'], ['#1C2B2A', 'Black']] as const;
const toPath = (pts: [number, number][]) => pts.map(([x, y], i) => `${i ? 'L' : 'M'}${(x * 1000).toFixed(1)} ${(y * 1294).toFixed(1)}`).join(' ');

export const DocViewer106: React.FC<{ cid: string; docId: string; page0: number; onClose: () => void }> = ({ cid, docId, page0, onClose }) => {
  useMedTick(); const [actor] = useActor();
  const [docs] = useState<CDoc[]>(() => clearanceDocs({ id: cid } as A.AscCase));
  const d = docs.find(x => x.id === docId); const [pi, setPi] = useState(Math.max(0, (d?.pages.findIndex(p => p.n === page0) ?? 0)));
  const [tool, setTool] = useState<'view' | 'pen' | 'hi' | 'stamp'>('view'); const [color, setColor] = useState<string>(COLORS[0][0]);
  const pg = d?.pages[pi]; const [marks, setMarks] = useState<Mark[]>(() => d && pg ? marksFor(cid, d.id, pg.n) : []);
  const drawing = useRef<Mark | null>(null); const svgRef = useRef<SVGSVGElement>(null); const [, force] = useState(0);
  const canMark = CLINICAL_MARK_ROLES.test(actor.role); const rev = d ? reviewsFor(cid)[d.id] : undefined;
  useEffect(() => { if (d && pg) setMarks(marksFor(cid, d.id, pg.n)); }, [pi]);
  useEffect(() => { const k = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose(); }; window.addEventListener('keydown', k); return () => window.removeEventListener('keydown', k); }, [onClose]);
  if (!d || !pg) return <div className="v106-full v106-viewer" role="dialog" aria-modal="true" aria-label="Document"><div className="v106-vhead"><b>Document not found</b><button type="button" className="v106-ib" onClick={onClose} aria-label="Close"><X size={20} /></button></div></div>;
  const persist = (l: Mark[]) => { setMarks(l); saveMarks(cid, d.id, pg.n, l); };
  const pt = (e: React.PointerEvent): [number, number] => { const r = svgRef.current!.getBoundingClientRect(); return [Math.min(1, Math.max(0, (e.clientX - r.left) / r.width)), Math.min(1, Math.max(0, (e.clientY - r.top) / r.height))]; };
  const audit = (what: string) => repo.audit({ caseId: `asc8:${cid}`, user: actor.name, role: actor.role, action: 'asc106.mark' as any, detail: `${what} on ${d.title}, page ${pg.n}` });
  const down = (e: React.PointerEvent) => { if (!canMark || tool === 'view') return; e.preventDefault(); (e.target as Element).setPointerCapture?.(e.pointerId);
    const at = new Date().toISOString();
    if (tool === 'stamp') { const [x, y] = pt(e); const t = `${initialsOf(actor.name)} ${new Date().toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' })}`; persist([...marks, { t: 'stamp', color, x, y, text: t, by: actor.name, at }]); audit('Initials stamped'); return; }
    drawing.current = { t: tool, color: tool === 'hi' ? '#F2C94C' : color, pts: [pt(e)], by: actor.name, at }; force(x => x + 1); };
  const move = (e: React.PointerEvent) => { if (!drawing.current) return; drawing.current.pts!.push(pt(e)); force(x => x + 1); };
  const up = () => { const m = drawing.current; drawing.current = null; if (m && (m.pts?.length || 0) > 1) { persist([...marks, m]); audit(m.t === 'hi' ? 'Highlight added' : 'Pen marking added'); } force(x => x + 1); };
  const all = drawing.current ? [...marks, drawing.current] : marks;
  const T = (k: typeof tool, label: string, Icon: React.FC<any>) => <button type="button" className={`v106-tool ${tool === k ? 'on' : ''}`} aria-pressed={tool === k} onClick={() => setTool(k)} disabled={k !== 'view' && !canMark} data-testid={`v106-tool-${k}`}><Icon size={18} aria-hidden="true" />{label}</button>;
  return <div className="v106-full v106-viewer" role="dialog" aria-modal="true" aria-label={d.title} data-testid="v106-viewer">
    <header className="v106-vhead">
      <div className="v106-vt"><span className="v106-kind">{d.kind}</span><b>{d.title}</b><span className="v106-mu">{d.date}{d.name ? ` · ${d.name}` : ''}</span></div>
      <div className="v106-pages">{d.pages.length > 1 && <><button type="button" className="v106-ib" disabled={pi === 0} onClick={() => setPi(pi - 1)} aria-label="Previous page"><ChevronLeft size={20} /></button><span data-testid="v106-page">Page {pg.n} of {d.pages.length}</span><button type="button" className="v106-ib" disabled={pi === d.pages.length - 1} onClick={() => setPi(pi + 1)} aria-label="Next page"><ChevronRight size={20} /></button></>}</div>
      <button type="button" className="v106-ib" onClick={onClose} aria-label="Close document" data-testid="v106-close"><X size={22} /></button>
    </header>
    <div className="v106-tools" role="toolbar" aria-label="Markup tools">
      {T('view', 'Scroll', Hand)}{T('pen', 'Pen', Pen)}{T('hi', 'Highlight', Highlighter)}{T('stamp', 'Initials', Stamp)}
      {tool === 'pen' && <span className="v106-colors">{COLORS.map(([c2, n]) => <button key={c2} type="button" className={`v106-sw ${color === c2 ? 'on' : ''}`} style={{ background: c2 }} aria-label={n} aria-pressed={color === c2} onClick={() => setColor(c2)} />)}</span>}
      <span className="v106-sp" />
      <button type="button" className="v106-tool" disabled={!canMark || !marks.some(m => m.by === actor.name)} onClick={() => { const i = [...marks].reverse().findIndex(m => m.by === actor.name); if (i < 0) return; const idx = marks.length - 1 - i; persist(marks.filter((_, j) => j !== idx)); audit('Marking removed (undo)'); }} data-testid="v106-undo"><Undo2 size={18} aria-hidden="true" />Undo</button>
      <button type="button" className="v106-tool" disabled={!canMark || !marks.some(m => m.by === actor.name)} onClick={() => { persist(marks.filter(m => m.by !== actor.name)); audit('My markings cleared on this page'); }} data-testid="v106-clear"><Trash2 size={18} aria-hidden="true" />Clear mine</button>
      {!canMark && <span className="v106-mu">View only · nurses and doctors can mark</span>}
    </div>
    <div className={`v106-stage ${tool !== 'view' ? 'drawing' : ''}`}>
      <div className="v106-sheet" data-testid="v106-sheet">
        {pg.text != null ? <div className="v106-paper"><div className="v106-ph"><b>{d.title}</b><span>{d.date} · page {pg.n}</span></div><p>{pg.text}</p></div>
          : pg.data && /^data:image\//.test(pg.data) ? <img src={pg.data} alt={d.title} className="v106-img" />
          : pg.data ? <object data={pg.data} type={pg.mime || 'application/pdf'} className="v106-obj" aria-label={d.title}><p>This file can’t be shown here.</p></object>
          : <div className="v106-paper"><p>The file for this upload isn’t stored on this device (test build).</p></div>}
        <svg ref={svgRef} className="v106-ink" viewBox="0 0 1000 1294" preserveAspectRatio="none" onPointerDown={down} onPointerMove={move} onPointerUp={up} onPointerCancel={up} data-testid="v106-ink" aria-hidden="true">
          {all.map((m, i) => m.t === 'stamp' ? <g key={i}><rect x={m.x! * 1000 - 4} y={m.y! * 1294 - 30} width={(m.text!.length * 15) + 12} height={40} rx={6} fill="none" stroke={m.color} strokeWidth={3} /><text x={m.x! * 1000 + 4} y={m.y! * 1294 + 0} fontSize={26} fontWeight={700} fill={m.color} fontFamily="DM Sans, system-ui, sans-serif">{m.text}</text></g>
            : <path key={i} d={toPath(m.pts || [])} fill="none" stroke={m.color} strokeWidth={m.t === 'hi' ? 22 : 4} strokeOpacity={m.t === 'hi' ? 0.42 : 1} strokeLinecap="round" strokeLinejoin="round" />)}
        </svg>
      </div>
    </div>
    <footer className="v106-vfoot">
      <span className="v106-mu" data-testid="v106-mark-count">{marks.length ? `${marks.length} marking${marks.length === 1 ? '' : 's'} on this page · saved` : 'No markings on this page'}</span>
      <span className="v106-sp" />
      {rev ? <span className="v106-rev" data-testid="v106-reviewed"><Check size={16} aria-hidden="true" />Reviewed · {rev.initials} · {new Date(rev.at).toLocaleString('en-US', { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' })}</span>
        : canMark && <button type="button" className="a8-btn pri" onClick={() => { setReviewed(cid, d.id, d.title, actor.name, actor.role); }} data-testid="v106-mark-reviewed">Reviewed &amp; initialed</button>}
      <button type="button" className="a8-btn" onClick={onClose}>Done</button>
    </footer>
  </div>;
};

/* ---------------- list at the first nurse station ---------------- */
export const ClearanceDocsCard: React.FC<{ c: A.AscCase }> = ({ c }) => {
  useMedTick(); use81(); const docs = clearanceDocs(c); const rev = reviewsFor(c.id); const miss = missingExpected(c, docs); const n = docs.filter(d => rev[d.id]).length;
  return <section className="v10-card v106-docs" data-testid="v106-clearance-docs">
    <h3 className="v10-h"><FileText size={18} aria-hidden="true" />Clearance documents to verify
      <span className={`v10-chip ${docs.length && n === docs.length ? 'ok' : 'warn'}`} style={{ marginLeft: 'auto' }} data-testid="v106-docs-count">{n} of {docs.length} reviewed</span></h3>
    <p className="v10-sub">Open each document full screen, mark or initial results as needed, then tap “Reviewed &amp; initialed”. Anesthesia, the surgeon and PACU see the same documents and your markings.</p>
    <ul className="v106-dlist">{docs.map(d => { const r = rev[d.id]; const mk = markCount(c.id, d.id);
      return <li key={d.id} data-testid="v106-doc-row" data-reviewed={r ? '1' : '0'}><button type="button" className="v106-drow" onClick={() => openDoc(c.id, d.id)} data-testid="v106-doc-open">
        <span className="v106-kind">{d.kind}</span><span className="v106-dt"><b>{d.title}</b><span>{d.date}{d.pages.length > 1 ? ` · ${d.pages.length} pages` : ''}{d.source === 'upload' ? ` · ${d.name && !/\.(pdf|jpe?g|png|heic|tiff?)$/i.test(d.name) ? d.name : 'uploaded'}` : ''}{mk ? ` · ${mk} marking${mk === 1 ? '' : 's'}` : ''}</span></span>
        {r ? <span className="v10-chip ok"><Check size={14} aria-hidden="true" />{r.initials} · {new Date(r.at).toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' })}</span> : <span className="v10-chip warn">Not reviewed</span>}
        <span className="v106-open">Open</span></button></li>; })}
      {miss.map(m => <li key={m.label} data-testid="v106-doc-missing"><div className="v106-drow miss"><span className="v106-kind">{m.label}</span><span className="v106-dt"><b>{m.label}</b><span>{m.marked ? 'Marked as received, but no copy is on file' : 'Not received'}</span></span><AlertTriangle size={18} aria-hidden="true" /></div></li>)}
      {!docs.length && !miss.length && <li className="v10-sub">No clearance documents for this case.</li>}
    </ul>
    <div className="v10-row" style={{ marginTop: 10 }}><button type="button" className="a8-btn" onClick={() => openUpload(c.id, c.pid, 'Verify medical history')} data-testid="v106-docs-upload">Upload a scanned document</button></div>
  </section>;
};

/* ---------------- Nightingale clearance summary (carries over to every clinical station) ---------------- */
export const ClearanceSummary: React.FC<{ c: A.AscCase; station: string }> = ({ c, station }) => {
  useMedTick(); use81(); const docs = clearanceDocs(c); const rev = reviewsFor(c.id); const miss = missingExpected(c, docs);
  const b = useMemo(() => recordsBrief(s81.pages(c.id) as RecPage[]), [c.id, docs.length]);
  const ab = b.lines.filter(l => l.abnormal && (l.kind === 'lab' || l.kind === 'test')); const conflicts = b.lines.filter(l => l.kind === 'conflict'); const probs = b.lines.filter(l => l.kind === 'problem');
  const meds = b.lines.filter(l => l.kind === 'med'); const clear = b.clearance; const reviewed = docs.filter(d => rev[d.id]).length;
  const src = (l: BriefLine) => <button type="button" className="v106-src" onClick={() => openDoc(c.id, `rec:${l.src.doc}`, l.src.page)} title={`${l.src.title}, page ${l.src.page}`}>{l.src.title.replace(/\s*\(fictional[^)]*\)/i, '')}{l.src.page > 1 ? ` p.${l.src.page}` : ''}</button>;
  if (!docs.length && !miss.length) return null;
  return <section className="vt-alert vt-alert--ai v106-sum" data-testid="v106-clearance-summary" data-station={station}>
    <ShieldCheck aria-hidden="true" />
    <div style={{ flex: 1 }}>
      <span className="vt-alert__title">Nightingale · clearance summary <span className="v106-draft">Draft</span></span>
      <p className="v106-line" data-testid="v106-sum-status">{docs.length} document{docs.length === 1 ? '' : 's'} on file · <b>{reviewed} of {docs.length} reviewed by nursing</b>{miss.length ? <> · <span className="v106-warn">missing: {miss.map(m => m.label).join(', ')}</span></> : null}</p>
      {clear && <p className="v106-line"><b>{clear.text.replace(/,?\s*signed Dr\.?\s*—\s*/i, ' — signed ')}</b> {src(clear)}</p>}
      {ab.length > 0 && <p className="v106-line"><span className="v106-warn">Out of range:</span> {ab.map((l, i) => <React.Fragment key={i}>{i ? ' · ' : ''}{l.text} {src(l)}</React.Fragment>)}</p>}
      {probs.length > 0 && <p className="v106-line">Conditions in the records: {probs.map(l => l.text).join(', ')}.</p>}
      {meds.length > 0 && <p className="v106-line">Medications of note: {meds.map((l, i) => <React.Fragment key={i}>{i ? ' · ' : ''}{l.text}</React.Fragment>)}</p>}
      {conflicts.map((l, i) => <p key={i} className="v106-line v106-warn">{l.text} {src(l)}</p>)}
      <p className="v106-foot">Suggested ASA {['', 'I', 'II', 'III', 'IV'][b.asa.cls]} ({b.asa.why.join(', ')}). Nightingale drafts from the documents; clinicians decide. Tap a source to open it.</p>
    </div>
  </section>;
};
