/* ASC.Vityls v10.6 · Chat-only commands (mockups "Chat · home", "· pre-op nurse", "· front desk"). Everything a station
 * does can start from a chat line; each answer comes with action cards that open the same popups the pages use (station,
 * check-in, invoice, upload, clearance viewer, chart) or act in place (tick standard orders, save a note, raise a flag).
 * Signing always opens the station so the PIN is entered there. Today's cases only. Fictional data. */
import React from 'react';
import { medRepo, isoDay } from '../../med/record';
import { useActor, useMedTick } from '../../med/ui';
import { useSv } from '../ui';
import * as A from '../asc8/logic';
import * as S from '../asc8/store';
import { openAsc } from '../asc8/ui';
import { s81 } from '../asc81/store81';
import { caseSignals } from '../asc81/Workbench';
import { bookingChecklist } from '../asc81/ai';
import { WSS } from '../asc84/chips';
import { caseMoney, payTypeOf } from '../asc83/pay';
import { openUpload, openInvoice } from '../asc87/ui87';
import * as D10 from '../asc10/store10';
import * as F from '../asc90/flow90';
import { caseFlow } from '../asc90/today90';
import { clearanceDocs, openDoc, reviewsFor } from './clearance106';
import { addNote } from './stations106';
import { planFor } from './invoice106';
import { openPortal103 } from '../asc10/portal103';

export type Act106 =
  | { k: 'station'; cid: string; st: F.FlowKey; label?: string }
  | { k: 'checkin'; cid: string } | { k: 'chart'; pid: string } | { k: 'invoice'; cid: string } | { k: 'upload'; cid: string }
  | { k: 'doc'; cid: string; doc: string; label: string } | { k: 'orders'; cid: string; phase: D10.Phase } | { k: 'details'; cid: string } | { k: 'ask'; q: string; label: string } | { k: 'forms'; pid: string };
export interface Reply106 { text: string; acts: Act106[] }

const money = (n: number) => `$${n.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
const hm = (t: string) => t.replace(/^0/, '');
const nm = (c: A.AscCase) => medRepo.patient(c.pid)?.name || 'Patient';
const fn = (c: A.AscCase) => nm(c).split(' ')[0];
const todayCases = () => S.cases().filter(c => c.date === isoDay()).sort((a, b) => A.toMin(a.time) - A.toMin(b.time));
const missing = (c: A.AscCase) => bookingChecklist(caseSignals(c, s81.ai(c.id))).filter(i => i.state === 'missing').map(i => i.label);
const done = (c: A.AscCase) => c.loc === 'discharged' || c.loc === 'closed';
const curKey = (c: A.AscCase): F.FlowKey | null => { const f = caseFlow(c); return f.cur >= 0 && f.cur < 6 ? F.FLOW[f.cur] : c.loc === 'scheduled' ? 'front' : null; };
const STW: [RegExp, F.FlowKey][] = [[/\b(front desk|check-?in station|front)\b/i, 'front'], [/\b(pre-?op|nursing|admission)\b/i, 'nursing'], [/\b(anesthesia|anaesthesia|anes)\b/i, 'anesthesia'], [/\b(or|operating room|surgery|time-?out)\b/i, 'or'], [/\b(pacu|recovery)\b/i, 'pacu'], [/\b(discharge)\b/i, 'discharge']];
const TEAMW: [RegExp, A.Team][] = [[/front desk|front/i, 'front'], [/pre-?op|nurs/i, 'preop'], [/pacu|recovery/i, 'pacu'], [/anesth/i, 'anesthesia'], [/surgeon|dr\.? /i, 'surgeon'], [/\bor\b|or team|circulat/i, 'or'], [/coordinator/i, 'coord'], [/manager/i, 'pm']];
const NOTE_STATION: Record<F.FlowKey, string> = { front: 'Pre-op nursing', nursing: 'Pre-op nursing', anesthesia: 'Pre-op nursing', or: 'OR', pacu: 'PACU', discharge: 'Discharge' };

/** Find the patient a line is about: any of today's patients whose first or last name appears as a word. */
export function caseIn(text: string): A.AscCase | undefined {
  const t = text.toLowerCase(); return todayCases().find(c => nm(c).toLowerCase().split(/\s+/).some(w => w.length > 2 && new RegExp(`\\b${w.replace(/[^a-z]/g, '')}\\b`).test(t)));
}
const after = (text: string) => (text.match(/[:—–-]\s*(.+)$/)?.[1] || '').trim();

export function ascCommand(raw: string, actor: { name: string; role: string }): Reply106 | null {
  const t = raw.trim(); const l = t.toLowerCase(); const c = caseIn(t); const all = todayCases(); const st = A.stationOf(actor.role);
  const where = (x: A.AscCase) => { const k = curKey(x); const lab = A.LOC_LABEL[x.loc]; return `${lab}${k && !done(x) && !lab.toLowerCase().includes(F.FLOW_LABEL[k].toLowerCase()) ? ` · next: ${F.FLOW_LABEL[k]}` : ''}`; };
  const stAct = (x: A.AscCase): Act106[] => { const k = curKey(x); return x.loc === 'scheduled' ? [{ k: 'checkin', cid: x.id }, { k: 'chart', pid: x.pid }] : k ? [{ k: 'station', cid: x.id, st: k }, { k: 'chart', pid: x.pid }] : [{ k: 'chart', pid: x.pid }]; };

  if (/^(help|commands|what can you do|\?)$/i.test(l) || /what can i (say|ask)/.test(l))
    return { text: 'You can run the day from here. Try: “who’s next”, “what’s missing”, “check in Priya”, “start pre-op for Desmond”, “vitals Desmond BP 128/82 HR 74 SpO2 98”, “orders for Desmond”, “note for Desmond: anxious, family in waiting room”, “flag anesthesia: Desmond took metformin this morning”, “clearance Desmond”, “invoice for Ada”, “collect payment Owen”, “upload for Celia”, “send forms to Jonah”, “sign Desmond” or “where is Maren”.', acts: [] };

  if (/who.?s next|who is next|next (patient|case|up)/.test(l)) {
    const pool = all.filter(x => !done(x));
    const mine = st === 'front' ? pool.filter(x => x.loc === 'scheduled') : st === 'preop' ? pool.filter(x => x.loc === 'arrived' || x.loc === 'preop') : st === 'anesthesia' ? pool.filter(x => ['arrived', 'preop'].includes(x.loc)) : st === 'pacu' ? pool.filter(x => x.loc === 'pacu' || x.loc === 'or') : pool;
    const x = mine[0] || pool[0];
    if (!x) return { text: 'Nobody is waiting: every case today is discharged.', acts: [] };
    const m = missing(x);
    return { text: `${nm(x)} at ${hm(x.time)} in ${x.room} · ${x.procedure} with ${x.surgeon.replace(/,.*$/, '')}. ${where(x)}.${m.length ? ` Missing: ${m.slice(0, 3).join(', ').toLowerCase()}.` : ''}${mine.length > 1 ? ` After that: ${mine.slice(1, 3).map(y => `${fn(y)} ${hm(y.time)}`).join(', ')}.` : ''}`, acts: stAct(x) };
  }

  if (/missing|outstanding|still need/.test(l)) {
    if (c) { const m = missing(c); return { text: m.length ? `${nm(c)} is missing ${m.length}: ${m.join(', ')}.` : `${nm(c)} has nothing missing.`, acts: m.length ? [{ k: 'upload', cid: c.id }, { k: 'details', cid: c.id }] : [{ k: 'chart', pid: c.pid }] }; }
    const rows = all.filter(x => !done(x)).map(x => [x, missing(x)] as const).filter(([, m]) => m.length);
    return { text: rows.length ? `${rows.length} of today’s patients have missing items. ${rows.map(([x, m]) => `${fn(x)} (${hm(x.time)}): ${m.slice(0, 3).join(', ').toLowerCase()}${m.length > 3 ? ` +${m.length - 3}` : ''}`).join(' · ')}` : 'Nothing is missing for today’s patients.', acts: rows.slice(0, 4).map(([x]) => ({ k: 'details', cid: x.id }) as Act106) };
  }

  if (/^check ?in\b|^arrive/.test(l)) {
    if (!c) return { text: 'Who is checking in? Say “check in” and the patient’s name.', acts: all.filter(x => x.loc === 'scheduled').slice(0, 4).map(x => ({ k: 'ask', q: `check in ${fn(x)}`, label: `${fn(x)} · ${hm(x.time)}` }) as Act106) };
    if (c.loc !== 'scheduled') return { text: `${nm(c)} is already checked in (${where(c)}).`, acts: stAct(c) };
    const m = caseMoney(c); return { text: `Check-in for ${nm(c)} (${hm(c.time)}, ${c.room}). ${payTypeOf(c)}${m.balance > 0 ? ` · ${money(m.balance)} due` : ''}. ID and insurance photos and any payment are taken in the check-in window.`, acts: [{ k: 'checkin', cid: c.id }] };
  }

  if (/\bvitals?\b|\bbp\b/.test(l) && c) {
    const g = (re: RegExp) => t.match(re)?.[1]; const v = { BP: g(/\b(?:bp|blood pressure)\s*(\d{2,3}\s*\/\s*\d{2,3})/i), HR: g(/\b(?:hr|pulse|heart rate)\s*(\d{2,3})/i), SpO2: g(/\b(?:spo2|sat(?:uration)?|o2)\s*(\d{2,3})/i), Temp: g(/\btemp(?:erature)?\s*(\d{2,3}(?:\.\d)?)/i), RR: g(/\b(?:rr|resp(?:irations)?)\s*(\d{1,2})/i) };
    const got = Object.entries(v).filter(([, x]) => x); if (!got.length) return { text: `Say the values, e.g. “vitals ${fn(c)} BP 128/82 HR 74 SpO2 98 temp 98.2”.`, acts: [] };
    const line = got.map(([k, x]) => `${k} ${x}`).join(', ');
    addNote({ cid: c.id, station: 'Pre-op nursing', text: `Vitals said in chat (draft to confirm): ${line}`, by: actor.name, role: actor.role });
    return { text: `Drafted vitals for ${fn(c)}: ${line}. Saved to the nursing notes with your name and time; confirm them in pre-op nursing so they go into the record.`, acts: [{ k: 'station', cid: c.id, st: 'nursing', label: 'Confirm in Pre-op' }] };
  }

  if (/\borders?\b/.test(l) && c) {
    const phase: D10.Phase = /post/.test(l) || c.loc === 'pacu' || done(c) ? 'post' : 'pre'; D10.snapshotLists(c.id, c.surgeon); const list = D10.viewList(c.id, c.surgeon, phase);
    const n = list.items.filter(i => list.ticks[i.id]).length;
    return { text: `${c.surgeon.replace(/,.*$/, '')}’s standard ${phase}-op orders for ${fn(c)}: ${n} of ${list.items.length} done. Tick each one as it’s done; the time and your initials are recorded.`, acts: [{ k: 'orders', cid: c.id, phase }] };
  }

  if (/^(add (a )?)?note\b/.test(l) && c) {
    const text = after(t); if (!text) return { text: `What should the note say? e.g. “note for ${fn(c)}: anxious, family in waiting room”.`, acts: [] };
    const k = curKey(c) || 'nursing'; addNote({ cid: c.id, station: NOTE_STATION[k] as any, text, by: actor.name, role: actor.role });
    return { text: `Note saved on ${fn(c)}’s ${NOTE_STATION[k].toLowerCase()} record: “${text}”. Everyone on the case sees it in the chart.`, acts: [{ k: 'chart', pid: c.pid }] };
  }

  if (/^flag\b/.test(l)) {
    const head = t.split(/[:—–]/)[0]; const team = TEAMW.find(([re]) => re.test(head.replace(/^flag\s*/i, '')))?.[1]; const text = after(t) || t.replace(/^flag\s*/i, '');
    if (!c) return { text: 'Which patient is the flag about? Include their name, e.g. “flag anesthesia: Desmond took metformin this morning”.', acts: [] };
    if (!team) return { text: `Who should see it? Start with the team, e.g. “flag front desk: …”. Teams: ${Object.values(A.TEAM_LABEL).join(', ')}.`, acts: [] };
    S.raiseFlag({ from: actor.name, fromRole: actor.role, to: team, pid: c.pid, caseId: c.id, text } as any);
    return { text: `Flag raised for ${A.TEAM_LABEL[team]} on ${fn(c)}: “${text}”. Everyone sees it on Today and in the chart; ${A.TEAM_LABEL[team]} also gets it in their queue.`, acts: [{ k: 'chart', pid: c.pid }] };
  }

  if (/clearance|h&p|labs?\b|ecg|ekg/.test(l) && c) {
    const docs = clearanceDocs(c); const rv = reviewsFor(c.id); const m = missing(c).filter(x => /clearance|h&p|lab|ecg|ekg/i.test(x));
    return { text: docs.length ? `${docs.length} clearance document${docs.length === 1 ? '' : 's'} for ${fn(c)}, ${Object.keys(rv).length} reviewed: ${docs.map(d => `${d.title}${rv[d.id] ? ` (✓ ${rv[d.id].initials})` : ''}`).join('; ')}.${m.length ? ` Still missing: ${m.join(', ')}.` : ''} Open one full screen to mark or initial it.` : `No clearance documents on file for ${fn(c)} yet.${m.length ? ` Missing: ${m.join(', ')}.` : ''}`, acts: [...docs.slice(0, 4).map(d => ({ k: 'doc', cid: c.id, doc: d.id, label: d.kind }) as Act106), { k: 'upload', cid: c.id }] };
  }

  if (/invoice|bill\b|billing/.test(l) && c) {
    const pl = planFor(c); const m = caseMoney(c);
    return { text: `${fn(c)} · ${payTypeOf(c)} · ${pl ? `billed ${pl.timing === 'pre' ? 'before surgery' : 'after surgery from in/out-of-room time'} to ${pl.billTo === 'both' ? 'patient and surgeon' : pl.billTo}` : 'insurance case'}. Balance ${money(m.balance)}. The invoice opens on the practice letterhead; send it from there.`, acts: [{ k: 'invoice', cid: c.id }] };
  }

  if (/collect|payment|pay\b|copay/.test(l) && c) {
    const m = caseMoney(c); return { text: m.balance > 0 ? `${fn(c)} owes ${money(m.balance)} (${payTypeOf(c)}). Take the payment in the chart; a receipt is recorded.` : `${fn(c)} has no balance.`, acts: [{ k: 'chart', pid: c.pid }, { k: 'invoice', cid: c.id }] };
  }

  if (/send.*form|form.*send|intake|at-home|portal form/.test(l)) { if (!c) return { text: 'Which patient? e.g. “send forms to Priya”.', acts: [] }; return { text: `Pick the intake / at-home forms to send ${nm(c)}. Forms already sent show their status; repeat patients can get just the forms they need.`, acts: [{ k: 'forms', pid: c.pid }] }; }
  if (/upload|scan/.test(l) && c) return { text: `Upload a scanned or photographed document for ${fn(c)}; it is filed on today’s case.`, acts: [{ k: 'upload', cid: c.id }] };

  if (/^sign\b/.test(l) && c) { const k = curKey(c); return { text: k ? `Signing ${F.FLOW_LABEL[k]} for ${fn(c)} needs your PIN, so I’ve put the station here. Anything still open becomes a flag everyone can see.` : `${fn(c)} has nothing left to sign today.`, acts: k ? [{ k: 'station', cid: c.id, st: k, label: `Open ${F.FLOW_LABEL[k]} to sign` }] : [] }; }

  const stw = STW.find(([re]) => re.test(l));
  if (c && stw && /\b(start|open|go to|begin|do)\b/.test(l)) return { text: `${F.FLOW_LABEL[stw[1]]} for ${nm(c)} (${hm(c.time)}, ${c.room}).`, acts: [{ k: 'station', cid: c.id, st: stw[1] }] };

  if (c && (/where|status|how is|open\b|^\w+$/.test(l))) { const m = missing(c); return { text: `${nm(c)} · ${hm(c.time)} · ${c.room} · ${c.procedure}. ${where(c)}.${m.length ? ` Missing: ${m.join(', ').toLowerCase()}.` : ''}`, acts: stAct(c) }; }
  return null;
}

/** Suggestions for the chat home, by role. */
export function chips106(role: string): string[] {
  const st = A.stationOf(role); const all = todayCases().filter(x => !done(x)); const nx = (f: (x: A.AscCase) => boolean) => all.find(f); const a = nx(x => x.loc === 'scheduled'); const b = nx(x => x.loc === 'arrived' || x.loc === 'preop');
  if (st === 'front') return ['Who’s next?', 'What’s missing?', ...(a ? [`Check in ${fn(a)}`] : []), ...(a ? [`Invoice for ${fn(a)}`] : [])];
  if (st === 'preop') return ['Who’s next?', ...(b ? [`Start pre-op for ${fn(b)}`, `Orders for ${fn(b)}`, `Clearance ${fn(b)}`] : []), 'What’s missing?'];
  if (st === 'anesthesia') return ['Who’s next?', ...(b ? [`Clearance ${fn(b)}`, `Start anesthesia for ${fn(b)}`] : []), 'What’s missing?'];
  if (st === 'pacu') { const p = nx(x => x.loc === 'pacu'); return ['Who’s next?', ...(p ? [`Post-op orders for ${fn(p)}`, `Open discharge for ${fn(p)}`] : [])]; }
  return ['Who’s next?', 'What’s missing?', 'Help'];
}

export const Acts106: React.FC<{ acts: Act106[]; onAsk: (q: string) => void }> = ({ acts, onAsk }) => {
  useMedTick(); const [actor] = useActor(); const { go } = useSv();
  const lab = (a: Act106) => { const c = 'cid' in a ? S.caseById(a.cid) : undefined; const n = c ? fn(c) : '';
    return a.k === 'station' ? (a.label || `Open ${F.FLOW_LABEL[a.st]}${n ? ` · ${n}` : ''}`) : a.k === 'checkin' ? `Check in ${n}` : a.k === 'chart' ? `Open chart${medRepo.patient(a.pid) ? ` · ${medRepo.patient(a.pid)!.name.split(' ')[0]}` : ''}` : a.k === 'invoice' ? `Invoice · ${n}` : a.k === 'upload' ? `Upload · ${n}` : a.k === 'doc' ? `View ${a.label}` : a.k === 'details' ? `${n} · details` : a.k === 'ask' ? a.label : a.k === 'forms' ? 'Send forms' : ''; };
  const run = (a: Act106) => { if (a.k === 'station') { const c = S.caseById(a.cid); const w = WSS.find(x => x.k === a.st); if (c && w) w.open(c); } else if (a.k === 'checkin') openAsc({ t: 'checkin', cid: a.cid } as any); else if (a.k === 'chart') go({ type: 'chart', pid: a.pid } as any); else if (a.k === 'invoice') openInvoice(a.cid); else if (a.k === 'upload') { const c = S.caseById(a.cid); if (c) openUpload(c.id, c.pid); } else if (a.k === 'doc') openDoc(a.cid, a.doc); else if (a.k === 'details') openAsc({ t: 'details', cid: a.cid } as any); else if (a.k === 'ask') onAsk(a.q); else if (a.k === 'forms') openPortal103(a.pid); };
  const btns = acts.filter(a => a.k !== 'orders');
  return <div className="h6-acts" data-testid="v106-chat-acts">
    {acts.filter(a => a.k === 'orders').map((a, i) => { if (a.k !== 'orders') return null; const c = S.caseById(a.cid); if (!c) return null; const list = D10.viewList(c.id, c.surgeon, a.phase);
      return <ul key={i} className="h6-orders" data-testid="v106-chat-orders">{list.items.map(it => { const tk = list.ticks[it.id]; return <li key={it.id}><label><input type="checkbox" checked={!!tk} onChange={e => D10.tickItem(c.id, c.surgeon, a.phase, it.id, e.target.checked, actor.name, actor.role)} data-testid="v106-chat-order" /><span>{it.text}</span>{tk && <small>{tk.time} · {tk.initials}</small>}</label></li>; })}</ul>; })}
    {btns.length > 0 && <div className="h6-btns">{btns.map((a, i) => <button key={i} type="button" className={`fd-btn ${i === 0 ? 'primary' : ''}`} onClick={() => run(a)} data-testid={`v106-chat-act-${a.k}`}>{lab(a)}</button>)}</div>}
  </div>;
};
