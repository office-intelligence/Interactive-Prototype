/* ASC.Vityls v10.6.3 · One standard Nightingale box on every page (AI-first).
 * AiBox106 is the same pill as the main Chat page (sparkle · input · mic · round send). Pages that already had their own
 * ask (Schedule, Practice Intelligence, Billing) now use it in place; every other page gets AiDock106 floating near the
 * bottom. The dock runs the chat commands (who's next, check in, orders, flags, invoice…) with action cards, and otherwise
 * answers about the page. Draft answers only; nothing is signed or sent from here. Fictional data. */
import React from 'react';
import { ArrowUp, Mic, Sparkles } from 'lucide-react';
import { AiDock, ASC_IDS, usePageAsk as osUsePageAsk, type Brain, type Reply } from '../../os/ai/dock';
import { ascCommand, Acts106, type Reply106 } from './chat106';
import { draftAnswer } from '../asc90/shell90';
import './ai106.css';

export const AiBox106: React.FC<{ value: string; onChange: (v: string) => void; onSubmit: () => void; placeholder: string; inputId?: string; goId?: string; sample?: string; label?: string }> =
  ({ value, onChange, onSubmit, placeholder, inputId, goId, sample, label }) =>
  <form className="ai6-box" role="search" onSubmit={e => { e.preventDefault(); onSubmit(); }}>
    <span className="ai6-mark" aria-hidden="true"><Sparkles size={16} /></span>
    <input value={value} onChange={e => onChange(e.target.value)} placeholder={placeholder} aria-label={label || 'Ask Nightingale'} data-testid={inputId} autoComplete="off" />
    <button type="button" className="ai6-mic" aria-label="Voice (simulated)" title="Simulated voice: types a sample question" onClick={() => sample && onChange(sample)}><Mic size={17} /></button>
    <button type="submit" className="ai6-send" aria-label="Ask" data-testid={goId}><ArrowUp size={18} /></button>
  </form>;

/** v11: the box itself lives in Vityls OS (src/os/ai/dock.tsx); this is the ASC brain and the ASC page answerers. */
const toReply = (r: Reply106): Reply => ({ text: r.text, render: r.acts.length ? (ask => <Acts106 acts={r.acts} onAsk={ask} />) : undefined });
export function usePageAsk(fn: (q: string) => Reply106 | null) { osUsePageAsk(q => { const r = fn(q); return r ? toReply(r) : null; }); }

const PAGE: Record<string, [string, string, string]> = {
  schedule: ['schedule', 'Ask or tell Nightingale: “when is Hugo Pell”, “Dr Patel’s cases next week”, “unconfirmed cases”…', 'Dr Patel’s cases next week'],
  'billing-hub': ['billing page', 'Ask or tell Nightingale: “unpaid invoices”, “collections this month”, “claims not submitted”…', 'Unpaid invoices'],
  intel: ['practice intelligence', 'Ask or tell Nightingale: “utilization by room”, “cancellation reasons”, “overtime by role”…', 'Utilization by room'],
  home: ['Today page', 'Ask or tell Nightingale: “who’s next”, “what’s missing”, “check in Priya”, “help”…', 'Who’s next?'],
  patients: ['patient record', 'Ask Nightingale about this patient or say what to do…', 'What’s missing?'],
  messages: ['messages', 'Ask Nightingale about messages, flags or a patient…', 'What’s missing?'],
  'ops-hub': ['operations page', 'Ask Nightingale about rooms, cases or the day…', 'Who’s next?'],
};
const ascBrain: Brain = (q, ctx) => { const r = ascCommand(q, ctx.actor); return r ? toReply(r) : null; };
/** The ASC edition of the one Nightingale box. */
export const AiDock106: React.FC<{ tab: string }> = ({ tab }) => { const [page, ph, sample] = PAGE[tab] || ['page', 'Ask Nightingale or tell it what to do…', 'Who’s next?'];
  return <AiDock tab={tab} page={page} placeholder={ph} sample={sample} brain={ascBrain} fallback={(q2, c) => ({ text: draftAnswer(q2, c.page) })} ids={ASC_IDS} />; };
