import { DEMO } from '../asc10/demo';
/* v8.5 · Nightingale search/chat over the schedule (simulated, local data; nothing is sent). */
import { usePageAsk } from '../asc106/ai106';
import React, { useState } from 'react';
import { medRepo, isoDay } from '../../med/record';
import { useMedTick } from '../../med/ui';
import * as S from '../asc8/store';
import * as A from '../asc8/logic';
import { confirmationOf } from '../reminders';
import { caseMoney } from '../asc83/pay';
import { surgeonColor } from '../asc83/booking';
import { ask, type AskCase, type AskResult } from './askpure';
const SUGGEST = DEMO ? ['When is Hugo Pell?', 'Dr Patel’s cases next week', 'Unconfirmed cases', 'Missing clearance this week', 'Unpaid cases'] : ['Cases next week', 'Unconfirmed cases', 'Missing clearance this week', 'Unpaid cases'];
export const toAsk = (): AskCase[] => S.cases().map(c => ({ id: c.id, date: c.date, time: c.time, patient: medRepo.patient(c.pid)?.name || '', surgeon: c.surgeon, procedure: c.procedure, room: c.room, confirmed: confirmationOf(c.visitId)?.status === 'confirmed', missing: A.ITEMS.filter(i => !A.isDone(c, i.key)).map(i => i.label), pay: caseMoney(c).status, loc: A.LOC_LABEL[c.loc] }));
export const ScheduleAsk: React.FC<{ onDay: (d: string) => void; onOpen: (cid: string) => void }> = ({ onDay, onOpen }) => { useMedTick(); const [q, setQ] = useState(''); const [r, setR] = useState<AskResult | null>(null);
  const run = (x = q) => { setQ(x); setR(ask(x, toAsk(), isoDay())); };
  /* v10.6.4: the schedule search answers through the page's standard Nightingale box (bottom of the page). */
  usePageAsk(x => { const res = ask(x, toAsk(), isoDay()); return { text: res.answer, acts: res.cases.slice(0, 6).map(c => ({ k: 'details', cid: c.id }) as const) }; });
  void r; void run; void onDay; void onOpen; void SUGGEST; void surgeonColor; return null; };
