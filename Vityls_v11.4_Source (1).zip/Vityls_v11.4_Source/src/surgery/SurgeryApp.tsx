import { V10Page } from './asc10/settings10';
import { ensureClearanceDemo } from './asc108/clearanceDemo';
import { PracticeFrame } from './asc10/practiceFrame';
import { Doc106Host } from './asc106/clearance106';
import { AscToday106 } from './asc106/today106';
/*
 * Surgery.Vityls v0.6 app shell (edition SURGERY, src/edition.ts). Built on MED.Vityls v0.1; ASC.Vityls is untouched.
 * One thin top bar (wordmark, five text links, Acting as, portal, simulation stamp), the Nightingale header in the same
 * place on every primary page, the page, and one right panel for every source / secondary view.
 */
import { runReminders } from './reminders';
import { installHiddenFilter, PatientRecordsAdmin } from './patientAdmin';
import { ensureV06Seed } from './documents';
import { DEMO } from './asc10/demo';
import { KitToast } from './asc10/kit';
import { ensureV12Seed } from './v12/seed';
import { ensureFlowSeed } from './flow/seed';
import { FlowPage } from './flow/FlowPage';
import { OfficeDock, OFFICE_SCHEDULE_SOURCE } from './office11/nightingale';
import { PlannerHost } from './planner11/planner';
import { ASC_SCHEDULE_SOURCE } from './asc108/schedule108';
import { setScheduleSource, runDailySchedule } from '../os/notify/dailySchedule';
import { ensureAllJourneys, syncAll } from './flow/store';
import { ensureCaseSeed } from './cases/seed';
import { ensureV17Seed } from './v17/seed';
import { ensureV18Seed } from './v18/seed';
import { installScope } from './v18/scope';
import { ProviderFilter, CoverGate } from './v18/ui';
import { ChatOnlySwitch, chatOnlyOn } from './v18/chatOnly';
import { V17Host } from './v17/ui';
import { showNav } from './v17/logic';
import { viewOf } from './v17/store';
import { migrateCases } from './cases/store';
import { ensureHipaaWorkflow, seedHipaa } from './v13/hipaa';
import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { AdminActiveSection } from '../components/AdministrationPage';
import { SurgeryFormsWorkspace } from './v10/SurgeryFormsWorkspace';
import { migrateSurgeryStations } from './v10/stations';
import { migrateSurgerySigners } from './v11/signers';
import { migrateOfficeRoles } from './v11/officeRoles';
import { ensureV11ApptNotes } from './v11/apptNotes';
import { ProvidersAdmin } from '../v7/ProvidersAdmin';
import { PracticeConfig } from '../types';
import { MED_ROOMS } from '../med/seed';
import { getSettings, saveSettings } from '../med/settings';
import { medRepo } from '../med/record';
import { useActor, useMedTick } from '../med/ui';
import { AdministrationPage } from '../components/AdministrationPage';
import { BillingHub } from '../v7/Hubs';
import { SurgeryBilling, BillingSettings } from './v14/Billing';
import { SurgeryPerformance } from './SurgeryPerformance';
import { sessionUsers } from './staff';
import { PracticeHome, StaffPins, PracticeProfile, practiceNext } from './SurgeryPractice';
import { receivePending } from './asc';
import { Messages8 } from './v07/Messages8';
import { PracticePortalHub } from '../portal/PracticePortalHub';
import { MedPortal } from '../med/MedPortal';
import { MedPracticeSettings } from '../med/MedPracticeSettings';
import { SurgerySchedule } from './SurgerySchedule';
import { SurgerySettings } from './SurgerySettings';
import { SurgeryChart } from './SurgeryChart';
import { SurgeryStation } from './SurgeryStation';
import { WsHost, openWs } from './flow/WsHost';
import { wsForVisit } from './flow/Workspaces';
import { takeFdStationStep } from './fd/stationStep';
import './v15/v15.css';
import { Act, Ref, Step, chartNextSteps, todayNextSteps } from './nightingale';
import { Ctx, NightingaleBar, SvTab } from './ui';
import { RightPanel } from './panel';
import { PracticeGate } from './PracticeGate';
import { practiceUnlocked, practiceEditor, lockPractice, touchPractice } from './practiceLock';
import './surgery.css';
import './v07/v7.css';
import './v07/v8.css';
import './v09/v9.css';
import { installSurgeryForms } from './v09/formChrome';
installSurgeryForms();
import { migrateLegalStored } from './v12/legal';
import { initImages } from './v12/img';
import './v12/v12.css';
import './v14/v14.css';
let booted = false;
import { EmailIntakePage } from '../modules/email-intake/EmailIntake';
import { MinimalPatient, ModulesPlan, Teaser, TrialBanner } from '../core/ui';
import { isCoreBuild, modOn, modReadOnly, modVisible, tabModule, teasersInNav, useCoreTick, corePractice } from '../core/useCore';
import { MOD, ModuleId } from '../core/modules';
import { Lock } from 'lucide-react';
import { NightingaleCard } from './v07/NightingaleCard';
import { pageBrief } from './v07/brief';
import { Today7 } from './v07/Today7';
import { Chart7 } from './v07/Chart7';
import { FD } from './fd/flag';
import { isMedical, isAscEd } from '../edition';
import { PracticeIntelligence } from './asc91/intel91';
import { canSeeIntel } from './asc91/intelLogic';
import './asc91/asc91.css';
import { FacilitySettings, PracticeLogoSettings } from './asc88/ui88';
import { StandingOrdersSettings } from './asc87/ui87';
import { ensureAsc8Seed, caseOfPatient } from './asc8/store';
import { ensureAscFormConfig, installAscForms } from './asc8/forms';
import { Asc8Host, openAsc } from './asc8/ui';
import { AscToday87 as AscToday, Asc87Host } from './asc87/ui87';
import { ensureAsc87Seed } from './asc87/store87';
import './asc87/asc87.css';
import './asc88/asc88.css';
import './asc89/asc89.css';
import './asc90/asc90.css';
import { AscToday90 } from './asc90/today90';
import { AscChart90 } from './asc90/chart90';
import { AscChart106 } from './asc106/chart106';
import { AiDock106 } from './asc106/ai106';
import { TopBar90, AskBar90 } from './asc90/shell90';
import { BillingPage89 } from './asc89/billing89';
import { CardPayHost } from './asc88/ui88';
import { AscOperations, FeeSchedule } from './asc8/ops';
import { Asc81Host, MedicalDirector, AuditPackPage, ensureAsc81Seed } from './asc81/practice81';
import './asc81/asc81.css';
import './asc82/asc82.css';
import './asc83/asc83.css';
import './asc84/asc84.css';
import './asc85/asc85.css';
import './asc86/asc86.css';
import { DeviceSwitch, UserChip, StaffBoard } from './asc85/tablet';
import { ensureAsc83Seed } from './asc83/seed83';
import { ensureAsc86Seed } from './asc86/store86';
import { AscChart } from './asc83/chart';
import { stationOf, STATION_LABEL as ASC_STATION_LABEL } from './asc8/logic';
/** ASC.Vityls v8.0: menus per station (each station sees only its own work; everything else via search / See all roles). */
const ASC_MENUS: Record<string, string[]> = { front: ['email', 'home', 'schedule', 'patients', 'messages', 'portal-hub', 'billing-hub'], preop: ['home', 'patients', 'schedule', 'messages'], pacu: ['home', 'patients', 'schedule', 'messages'], anesthesia: ['home', 'patients', 'schedule'], surgeon: ['home', 'patients', 'schedule'], or: ['home', 'patients', 'schedule'], billing: ['email', 'home', 'patients', 'schedule', 'messages', 'portal-hub', 'billing-hub', 'ops-hub', 'practice'] };
if (isAscEd) installAscForms();
import { ensureMed20Seed } from './medical/seed20';
/** Medical v2.0 runs the Surgery v1.8 screens (role views, workspaces, flags, chat-only); the v1.0 Medical screens are retired. */
const LEGACY_MED = false;
import { FdShell, FdDrawer, FdHeading, FdMenuItem } from '../frontdoor/FdShell';
import { SurgeryChat } from './fd/SurgeryChat';
import { FdSearch } from './fd/FdSearch';
import { fdChats } from './fd/chats';
import { CalendarDays, FileText, LayoutList, MessageSquare, Users, Scissors, CreditCard, Settings, BarChart3, Mail, Globe } from 'lucide-react';
import { SurgeriesPage, EpisodePage } from './episodes/EpisodeViews';
import { ensureEpisodeSeed, activeEpisode } from './episodes/store';
import { JourneyPage } from './journey/JourneyPage';
import { ensureJourneySeed, journeyFor } from './journey/store';
import { setConfirmation } from './reminders';

const practice = (): PracticeConfig => ({
  id: 'default-practice', practiceName: getSettings().practiceName, locationName: 'Main office', isPrimary: true, isSatellite: false, practiceType: 'General Medical/Surgical', specialty: 'Plastic Surgery',
  streetAddress: '', city: '', state: 'CA', zipCode: '', country: 'United States', telephone: '', email: '', website: '',
  primaryProvider: { firstName: 'Sam', lastName: 'Patel', degree: 'MD', cellPhone: '', email: '', npi: '' },
  calendarSettings: { startTime: '07:00 AM', endTime: '05:00 PM', visitTypes: [], rooms: MED_ROOMS.map((n, i) => ({ id: `room-exam-${i + 1}`, name: n, color: '#64748b', type: n.startsWith('Procedure') ? 'Procedure' : 'Exam', active: true, sortOrder: i + 1 })) },
} as PracticeConfig);

const NAV_ALL: { id: SvTab; label: string }[] = [{ id: 'email', label: 'Email intake' }, { id: 'home', label: 'Today' }, { id: 'schedule', label: 'Schedule' }, { id: 'patients', label: 'Patients' }, { id: 'messages', label: 'Messages' }, { id: 'portal-hub' as SvTab, label: 'Portal' }, { id: 'practice', label: 'Practice' }];
/** core-modules: nav entries of enabled modules (+ calm teasers for locked ones when the practice wants them). Core: Patients, Practice. */
const navItems = () => NAV_ALL.map(n => { const m = tabModule(n.id); return { ...n, locked: !!m && !modVisible(m) }; }).filter(n => !n.locked || teasersInNav());
const firstTab = (): SvTab => FD ? 'chat' : (navItems().find(n => !n.locked)?.id || 'patients') as SvTab;

// v0.6: hidden charts are filtered at the repository; fictional documents + contact notes seeded once on top of v0.5 data.
installHiddenFilter();

export const SurgeryApp: React.FC = () => {
  if (!booted) { booted = true; try { migrateLegalStored(); } catch { /* */ } try { const cp = corePractice(); if (cp && cp.namespace.startsWith('vityls-p-') && !getSettings().practiceName.startsWith(cp.name)) saveSettings({ ...getSettings(), practiceName: `${cp.name} (fictional)` }, 'Vityls Core', 'System', 'Practice name from Vityls Core'); } catch { /* */ } void initImages(); }
  useMedTick(); useCoreTick(); const [actor, setActor] = useActor();
  const [tab, setTabRaw] = useState<SvTab>(firstTab); const [teaserMod, setTeaserMod] = useState<ModuleId | null>(null); const [patientId, setPatientId] = useState(''); const [visitId, setVisitId] = useState('');
  const [panel, setPanel] = useState<Ref | null>(null); const [toastMsg, setToast] = useState(''); const [portal, setPortal] = useState(false);
  const [chatId, setChatId] = useState(''); const [search, setSearch] = useState(false); const [fdMode, setFdMode] = useState<'chat' | 'practice'>('chat');
  const [practiceConfig, setPracticeConfig] = useState<PracticeConfig>(practice);
  const coNow = !LEGACY_MED && chatOnlyOn(actor.name, actor.role); useEffect(() => { if (coNow) { setChatId(''); setFdMode('chat'); setTabRaw('chat'); } }, [actor.name, coNow]); // v1.8 chat-only: always land on Chat
  useEffect(() => { document.title = FD ? (isAscEd ? 'ASC.Vityls v11.4' : isMedical ? 'Medical.Vityls v11.4 (test build)' : 'Surgery.Vityls v11.4 (test build)') : 'Surgery.Vityls v0.13 (test build)'; try { if (DEMO) { ensureV06Seed(); ensureV12Seed(); } if (!isMedical && !isAscEd) { ensureEpisodeSeed(); ensureJourneySeed(); } ensureHipaaWorkflow(); if (DEMO) seedHipaa(); if (!isAscEd) { migrateSurgeryStations(); migrateSurgerySigners(); migrateOfficeRoles(); } if (DEMO) ensureV11ApptNotes(); } catch (e) { console.warn('v0.6 seed', e); } try { if (isAscEd) { if (DEMO) ensureAsc8Seed(); ensureAscFormConfig(); if (DEMO) { ensureAsc81Seed(); ensureAsc83Seed(); ensureAsc86Seed(); ensureAsc87Seed(); ensureClearanceDemo(); } } else { ensureFlowSeed(); if (!isMedical) { ensureAllJourneys(); ensureCaseSeed(); ensureV17Seed(); ensureV18Seed(); migrateCases(); syncAll(); } else ensureMed20Seed(); } } catch (e) { console.warn('v1.3 flow seed', e); } installScope(); receivePending(); runReminders(); confirmDeepLink(); setScheduleSource(isAscEd ? ASC_SCHEDULE_SOURCE : OFFICE_SCHEDULE_SOURCE); runDailySchedule(); let tm: any = 0; const onUp = () => { if (isMedical || isAscEd) return; clearTimeout(tm); tm = setTimeout(syncAll, 400); }; window.addEventListener('vityls-med-updated', onUp); const i = setInterval(() => { runReminders(); runDailySchedule(); onUp(); }, 60000); return () => { clearInterval(i); clearTimeout(tm); window.removeEventListener('vityls-med-updated', onUp); }; }, []);
  useEffect(() => { const f = (e: Event) => { const t = (e as CustomEvent).detail; if (t) { setTabRaw(t); setPanel(null); if (FD) setFdMode('practice'); window.scrollTo(0, 0); } }; window.addEventListener('vityls-go-tab', f); return () => window.removeEventListener('vityls-go-tab', f); }, []);
  useEffect(() => { if (!toastMsg) return; const t = setTimeout(() => setToast(''), 3800); return () => clearTimeout(t); }, [toastMsg]);
  const setTab = useCallback((t: SvTab) => { setTeaserMod(null); setTabRaw(t); if (FD) setFdMode(t === 'chat' ? 'chat' : 'practice'); setPanel(null); window.scrollTo(0, 0); }, []);
  const openChart = useCallback((pid: string, r?: Ref, full?: boolean) => { setPatientId(pid); setVisitId(''); setTabRaw('patients'); void full; setPanel(r ? { ...r, pid } : null); window.scrollTo(0, 0); }, []);
  const openStation = useCallback((vid: string) => { const v = medRepo.visit(vid); if (!v) return; if (isAscEd) { const c = caseOfPatient(v.patientId); if (c) openAsc({ t: 'record', cid: c.id }); return; } if (!LEGACY_MED) { const want = takeFdStationStep(); openWs({ id: wsForVisit(v, want || undefined), pid: v.patientId, vid: v.id }); return; } setPatientId(v.patientId); setVisitId(vid); setTabRaw('station'); setPanel(null); window.scrollTo(0, 0); }, []);
  const go = useCallback((a: Act) => { if (a.type === 'episode') { setPatientId(a.pid); setVisitId(''); setTabRaw('episode'); setPanel(null); window.scrollTo(0, 0); } else if (a.type === 'fullchart') openChart(a.pid, undefined, true); else if (a.type === 'panel') setPanel(a.ref); else if (a.type === 'chart') openChart(a.pid, a.ref); else if (a.type === 'station') openStation(a.visitId); else { if (a.tab === 'patients') setPatientId(''); setTab(a.tab as SvTab); } }, [openChart, openStation, setTab]);
  const ctx = useMemo(() => ({ tab, patientId, panel, openPanel: (r: Ref) => setPanel({ ...r, pid: r.pid || patientId }), closePanel: () => setPanel(null), go, toast: setToast, setTab }), [tab, patientId, panel, go, setTab]);
  // v0.4: Practice needs an access PIN. Re-lock on leaving Practice, after 5 min idle, or on reload.
  const PRACTICE_TABS = ['v10-lists', 'v10-checklists', 'v10-connectors', 'v10-onboard', 'v10-audit', 'v10-bank', 'v10-daily', 'modules', 'practice', 'forms', 'med-settings', 'surgery-settings', 'staff', 'profile', ...(LEGACY_MED ? ['billing-hub'] : ['billing-settings']), ...(isAscEd ? [] : ['ops-hub']), 'people', 'documents', 'records-admin', 'form-editor', ...(isAscEd ? ['medical-director', 'audit-pack'] : [])];
  const inPractice = PRACTICE_TABS.includes(tab) && !portal;
  /* v1.2: Billing & Payments is its own Surgery page for front desk, administrators and doctors (no Practice PIN). */
  const canBill = !LEGACY_MED && /front|desk|manager|administrator|md|do\b|surgeon|physician|practitioner|assistant \(pa\)|billing/i.test(actor.role);
  useEffect(() => { if (!inPractice && practiceUnlocked()) lockPractice('left Practice'); }, [inPractice]);
  useEffect(() => { const t = () => touchPractice(); window.addEventListener('pointerdown', t, true); window.addEventListener('keydown', t, true); const i = setInterval(() => { practiceUnlocked(); }, 15000); return () => { window.removeEventListener('pointerdown', t, true); window.removeEventListener('keydown', t, true); clearInterval(i); }; }, []);
  if (portal) return <div className="sv8-portal" data-edition="SURGERY"><MedPortal onExit={() => setPortal(false)} /></div>;

  const chartPid = (tab === 'patients' || tab === 'station' || tab === 'episode') ? patientId : '';
  const nextAll: Step[] = chartPid && medRepo.patient(chartPid) ? chartNextSteps(medRepo.patient(chartPid)!, actor.role) : tab === 'home' || tab === 'schedule' || tab === 'messages' || (tab === 'patients' && !patientId) ? todayNextSteps() : practiceNext();
  // core-modules: Nightingale chips only for enabled modules
  const next = nextAll.filter(x => { const a: any = x.act; return a.type === 'tab' ? (!tabModule(a.tab) || modOn(tabModule(a.tab)!)) : a.type === 'station' ? modOn('stations-workflow') : true; });
  const chartOn = modVisible('chart'); const brand = corePractice()?.brand || (isAscEd ? 'ASC' : isMedical ? 'Medical' : 'Surgery');
  const lockedMod: ModuleId | null = teaserMod || ((m => m && !modVisible(m) ? m : null)(tabModule(tab) || null));
  const roMod: ModuleId | null = !lockedMod && tabModule(tab) && modReadOnly(tabModule(tab)!) ? tabModule(tab)! : null;
  const trialMod: ModuleId | null = isCoreBuild && !lockedMod && tabModule(tab) ? tabModule(tab)! : null;
  const activeNav = tab === 'station' ? 'home' : PRACTICE_TABS.includes(tab) ? 'practice' : tab; const unlocked = inPractice && practiceUnlocked(); const editor = practiceEditor();
  const ctxLabel = chartPid ? `${medRepo.patient(chartPid)?.name} · ${tab === 'station' ? 'visit workflow' : tab === 'episode' ? 'journey' : 'chart'}` : tab === 'surgeries' ? 'Patients' : tab === 'home' ? (isAscEd ? `Today · ${ASC_STATION_LABEL[stationOf(actor.role)]}` : 'Today · front office') : tab === 'schedule' ? 'Schedule' : tab === 'messages' ? 'Messages' : tab === 'patients' ? 'Patients' : 'Practice · settings are commands';
  // v0.7: Today and the Patient Chart are redesigned (Kevin's design A/B) and carry their own Nightingale card.
  const v7page = !portal && (!!lockedMod || (FD && (tab === 'chat' || tab === 'station')) || tab === 'email' || tab === 'modules' || tab === 'home' || (tab === 'patients' && !!patientId && !!medRepo.patient(patientId)) || tab === 'surgeries' || tab === 'episode');
  const mainEl = <>
      {trialMod && !v7page && <div className="core-banner-wrap"><TrialBanner m={trialMod} /></div>}
      {!v7page && !(FD && !LEGACY_MED) && (() => { const b = pageBrief(tab, chartPid); return <div className="v8-ngwrap"><NightingaleCard patientId={chartPid || undefined} reads={b.reads} placeholder={b.placeholder} summary={b.summary} chips={next.map(x => ({ label: x.label, act: x.act }))} /></div>; })()}
      <main id="sv-main" className={`sv-main${roMod ? ' core-readonly' : ''}`} data-readonly={roMod || undefined}>
        {lockedMod ? <Teaser m={lockedMod} onStarted={() => { setTeaserMod(null); setToast(`${MOD[lockedMod].name}: free trial started.`); }} /> : <PracticeFrame tab={tab} on={unlocked && tab !== 'practice'}>
        {(tab === 'home' || tab === 'patients') && trialMod && <div className="mb-3"><TrialBanner m={trialMod} /></div>}
        {inPractice && !unlocked && <PracticeGate />}
        {tab === 'email' && <EmailIntakePage onOpenPatient={pid => openChart(pid)} onOpenSchedule={() => setTab('schedule')} toast={setToast} />}
        {unlocked && tab === 'modules' && <ModulesPlan onOpen={m => setTeaserMod(m)} onBack={() => setTab('practice')} />}{unlocked && tab.startsWith('v10-') && <V10Page tab={tab} />}
        {tab === 'home' && (isAscEd ? <AscToday106 /> : <Today7 />)}
        {tab === 'surgeries' && <SurgeryChart patientId="" />}
        {tab === 'episode' && patientId && (!LEGACY_MED ? <CoverGate pid={patientId}><FlowPage key={patientId} pid={patientId} /></CoverGate> : journeyFor(patientId) ? <JourneyPage key={patientId} pid={patientId} /> : <EpisodePage pid={patientId} />)}
        {tab === 'schedule' && <SurgerySchedule />}
        {unlocked && tab === 'surgery-settings' && <SurgerySettings />}
        {tab === 'patients' && (patientId && medRepo.patient(patientId) ? (chartOn ? <CoverGate pid={patientId}>{isAscEd ? <AscChart106 patientId={patientId} /> : <Chart7 patientId={patientId} />}</CoverGate> : <MinimalPatient pid={patientId} onBack={() => { setPatientId(''); setTab('patients'); }} onTryChart={() => setTeaserMod('chart')} />) : <SurgeryChart patientId={patientId} />)}
        {tab === 'station' && visitId && (FD ? <><Today7 /><FdDrawer title={<>Station · {medRepo.patient(medRepo.visit(visitId)?.patientId || '')?.name}</>} onClose={() => setTab('home')} testId="fd-station-drawer"><SurgeryStation key={visitId} visitId={visitId} onBack={() => setTab('home')} /></FdDrawer></> : <SurgeryStation key={visitId} visitId={visitId} onBack={() => setTab('home')} />)}
        {FD && tab === 'chat' && <SurgeryChat chatId={chatId} onChat={setChatId} />}
        {tab === 'messages' && <Messages8 onOpenChart={pid => openChart(pid)} />}
        {tab === 'portal-hub' && <PracticePortalHub by={actor.name} />}
        {/* v0.11: the form editor is reached from Forms & workflow › Edit form; old links land there */}
        {unlocked && (tab === 'forms' || tab === 'form-editor') && <SurgeryFormsWorkspace activePracticeId="default-practice" onShowToast={setToast} onBack={() => setTab('practice')} />}
        {unlocked && tab === 'med-settings' && <MedPracticeSettings onBack={() => setTab('practice')} onToast={setToast} />}
        {unlocked && tab === 'practice' && <PracticeHome />}
        {unlocked && tab === 'staff' && <StaffPins />}
        {unlocked && tab === 'profile' && <>{isAscEd ? <div className="sv-page" style={{ paddingBottom: 0 }}><FacilitySettings /></div> : <div className="sv-page" style={{ paddingBottom: 0 }}><PracticeLogoSettings /></div>}<PracticeProfile /></>}
        {(LEGACY_MED ? unlocked : canBill) && tab === 'billing-hub' && (LEGACY_MED ? <BillingHub onBack={() => setTab('practice')} onToast={setToast} /> : (isAscEd ? <BillingPage89 onToast={setToast} /> : <SurgeryBilling onToast={setToast} />))}{!LEGACY_MED && unlocked && tab === 'billing-settings' && <BillingSettings onToast={setToast} />}{!LEGACY_MED && !canBill && tab === 'billing-hub' && <div className="v7-card" style={{ padding: 18 }} data-testid="billing-no-access">Billing &amp; Payments is open to the front desk, administrators and doctors.</div>}
        {isAscEd && tab === 'intel' && <PracticeIntelligence />}{isAscEd && unlocked && tab === 'medical-director' && <MedicalDirector />}{isAscEd && unlocked && tab === 'audit-pack' && <AuditPackPage />}{!isAscEd && unlocked && tab === 'ops-hub' && <SurgeryPerformance />}{isAscEd && tab === 'ops-hub' && (stationOf(actor.role) === 'billing' ? <AscOperations /> : <div className="v7-card" style={{ padding: 18 }} data-testid="ops-no-access">Operations is open to the Practice Manager, billing and administrators.</div>)}
        {unlocked && tab === 'records-admin' && <PatientRecordsAdmin />}
        {unlocked && tab === 'people' && <div className="sv-legacy" data-testid="surgery-providers"><button type="button" className="sv-link text-[13px] mb-2" data-ps-legacy="" onClick={() => setTab('practice')}>‹ Practice</button><ProvidersAdmin practice={practiceConfig.practiceName} onToast={setToast} sub="Surgeons, physicians, nurse practitioners and physician assistants. Adding a provider sends one invitation (simulated) with the membership application, username and signature PIN setup." /></div>}
        {unlocked && tab === 'documents' && <div className="sv-legacy sv-v14-admin" data-testid="surgery-compliance"><button type="button" className="sv-link text-[13px] mb-2" data-ps-legacy="" onClick={() => setTab('practice')}>‹ Practice</button><AdministrationPage hideAdminHome onShowToast={setToast} practiceConfig={practiceConfig} practicesList={[practiceConfig]} activePracticeId="default-practice" onSelectPractice={() => {}} onAddPractice={() => setToast('Additional locations are not part of this test build.')} onDeletePractice={() => {}} onUpdatePracticeConfig={setPracticeConfig} activeSection={tab as AdminActiveSection} onSectionChange={sec => { if (sec === 'home') setTab('practice'); else if (sec === 'people' || sec === 'documents') setTab(sec); }} onOpenFormsWorkspace={() => setTab('forms')} onNavigateBilling={() => setTab('billing-hub')} /></div>}
        </PracticeFrame>}
      </main>
  </>;
  const extras = <>
      <RightPanel />
      {!LEGACY_MED && !portal && <WsHost />}
      {!LEGACY_MED && !portal && <V17Host />}
      {isAscEd && !portal && <Asc8Host />}{isAscEd && !portal && <Doc106Host />}{isAscEd && !portal && <Asc81Host />}{isAscEd && !portal && <Asc87Host />}{isAscEd && !portal && <CardPayHost />}
      {FD && !LEGACY_MED && !isAscEd && !portal && tab !== 'chat' && <OfficeDock key={tab} tab={tab} patientId={chartPid || undefined} />}<PlannerHost />
      {toastMsg && (isAscEd ? <KitToast msg={toastMsg} onClose={() => setToast('')} /> : <div role="status" className="fixed bottom-5 left-1/2 -translate-x-1/2 z-[90] bg-[#111418] text-white px-4 py-2.5 rounded-lg shadow-lg text-[14px] max-w-[90vw]" data-testid="sv-toast">{toastMsg}</div>)}
  </>;
  if (FD) {
    const lockedNav = (id: SvTab) => { const m = tabModule(id); return !!m && !modVisible(m); };
    const fdActive = tab === 'station' ? 'home' : tab === 'episode' ? 'patients' : isAscEd && PRACTICE_TABS.includes(tab) ? 'practice' : ['forms', 'form-editor', 'documents'].includes(tab) ? (LEGACY_MED ? 'forms' : 'practice') : tab === 'chat' ? '' : tab;
    const T = new Date().toISOString().slice(0, 10); const view = viewOf(actor.role); const coOn = !LEGACY_MED && chatOnlyOn(actor.name, actor.role);
    const H: FdHeading[] = [
      ...(isAscEd && isCoreBuild && modVisible('email-intake') ? [{ id: 'email', label: 'Email intake', icon: <Mail size={17} />, testId: 'sv-nav-email-h' }] : []),
      { id: 'home', label: 'Today', icon: <LayoutList size={17} />, testId: 'sv-nav-home' },
      { id: 'patients', label: 'Patients', icon: <Users size={17} />, testId: 'sv-nav-patients' },
      { id: 'schedule', label: 'Schedule', icon: <CalendarDays size={17} />, testId: 'sv-nav-schedule' },
      { id: 'messages', label: 'Messages', icon: <MessageSquare size={17} />, testId: 'sv-nav-messages' },
      { id: 'portal-hub', label: 'Patient Portal', icon: <Globe size={17} />, testId: 'sv-nav-portal', title: 'Patients connected through the Vityls Portal: requests, forms, check-in, bills, messages' },
      ...(!LEGACY_MED ? [{ id: 'billing-hub', label: 'Billing & Payments', icon: <CreditCard size={17} />, testId: 'sv-nav-billing', title: 'Invoices, payments and balances (front desk, administrators, doctors)' }] : []),
      ...(isAscEd ? [{ id: 'intel', label: 'Practice Intelligence', icon: <BarChart3 size={17} />, testId: 'sv-nav-intel', title: 'Practice Intelligence: volume, rooms, people and money (Administrator, Medical Director)' }] : []),
      ...(isAscEd ? [{ id: 'ops-hub', label: 'Operations', icon: <Scissors size={17} />, testId: 'sv-nav-ops', title: 'Room grid, bottlenecks, turnover, utilization and delays' }] : []),
      LEGACY_MED ? { id: 'forms', label: 'Forms & Documents', icon: <FileText size={17} />, testId: 'sv-nav-forms', title: 'Forms & workflow, practice documents (Practice PIN)' } : { id: 'practice', label: 'Practice Settings', icon: <Settings size={17} />, testId: 'sv-nav-forms', title: 'Practice settings, forms and documents (Practice PIN)' },
    ].map(h => ({ ...h, locked: lockedNav(h.id as SvTab) })).filter(h => !h.locked || teasersInNav()).filter(h => isAscEd ? (h.id === 'intel' ? canSeeIntel(actor.role) : (ASC_MENUS[stationOf(actor.role)] || []).includes(h.id)) : LEGACY_MED || showNav(view, h.id)); // v1.7: each role sees only its own menus
    void T;
    const adminOn = LEGACY_MED || view === 'admin' || unlocked; // v1.7: admin items only for managers, or once the Practice PIN is entered
    const M: FdMenuItem[] = [
      { label: 'Practice & settings', testId: 'sv-nav-practice', run: () => setTab('practice'), hint: 'Practice PIN' },
      ...(adminOn ? [{ label: isMedical ? 'Office settings' : 'Surgery settings', testId: 'fd-menu-settings', run: () => setTab('surgery-settings') }] : []),
      ...(adminOn || canBill ? [{ label: 'Billing', testId: 'fd-menu-billing', run: () => setTab('billing-hub') }] : []),
      ...(adminOn ? [{ label: 'Staff & PINs', testId: 'fd-menu-staff', run: () => setTab('staff') }, { label: 'Patient records admin', testId: 'fd-menu-records', run: () => setTab('records-admin') }] : []),
      ...(isCoreBuild ? [{ label: 'Modules & plan', testId: 'fd-menu-modules', run: () => setTab('modules') }] : []),
      { label: 'Email intake', testId: 'sv-nav-email', run: () => setTab('email'), locked: lockedNav('email') },
      ...(modOn('portal-link') ? [{ label: 'Open patient portal (simulated)', testId: 'open-portal', run: () => setPortal(true) }] : []),
      ...(unlocked && editor ? [{ label: 'Lock practice', testId: 'practice-lock', run: () => { lockPractice('locked by user'); setTab('home'); }, danger: true }] : []),

    ].filter(m => !m.locked || teasersInNav());
    const navTo = (id: string) => { if (id === 'patients') setPatientId(''); setTab(id as SvTab); };
    const crumb = tab === 'chat' ? <><b>Chat</b> · Nightingale</> : <><b>{ctxLabel.split(' · ')[0]}</b>{ctxLabel.includes(' · ') ? ` · ${ctxLabel.split(' · ').slice(1).join(' · ')}` : ''}</>;
    return <Ctx.Provider value={ctx}>
    <div className={`sv fd ${isAscEd ? 'n9-asc' : ''} ${v7page ? 'sv7-on' : ''} ${coOn ? 'v18-chatonly' : ''}`} data-chatonly={coOn ? '1' : '0'} data-edition={isMedical ? 'MEDICAL' : 'SURGERY'} data-testid="surgery-app" data-fd="1">
      <a href="#sv-main" className="sr-only focus:not-sr-only">Skip to content</a>
      <FdShell brand={brand} responsive mode={fdMode} onMode={m => { setFdMode(m); if (m === 'chat') { setChatId(''); setTab('chat'); } else if (tab === 'chat') setTab('home'); }} onNewChat={() => { setChatId(''); setTab('chat'); }} onSearch={() => setSearch(true)} onLogo={() => { setChatId(''); setTab(firstTab()); }}
        headings={H} active={fdActive} onNav={navTo} chats={fdChats().slice(0, 12).map(c => ({ id: c.id, title: c.title }))} activeChat={tab === 'chat' ? chatId : ''} onOpenChat={id => { setChatId(id); setTab('chat'); }}
        me={{ name: actor.name, role: actor.role }} menu={M}
        crumb={crumb}
        topRight={<>{isAscEd && <TopBar90 />}<span className="n9-testctl">
          <label className="flex items-center gap-1.5 text-[12.5px] text-[var(--ink3)]"><span className="hidden xl:inline">Test as</span><select className="sv-select fd-acting" value={actor.name} onChange={e => { const a = sessionUsers().find(x => x.name === e.target.value); if (a) setActor(a); }} aria-label="Tablet session (test build)" title="Shared tablet session. Signing always asks for the signer’s own PIN." data-testid="acting-as">{sessionUsers().map(a => <option key={a.name} value={a.name}>{a.name} · {a.role}</option>)}</select></label>
          {isAscEd && <DeviceSwitch />}{isAscEd && <UserChip tab={tab} />}
          {!LEGACY_MED && <ChatOnlySwitch away={tab !== 'chat'} onChat={() => { setChatId(''); setTab('chat'); }} onFindChart={() => setSearch(true)} />}
          {!LEGACY_MED && <ProviderFilter />}
          {unlocked && editor && <span className="sv-tag warn whitespace-nowrap" data-testid="practice-unlocked" title="Practice re-locks when you leave it or after 5 minutes without activity">Practice open</span>}
          {isAscEd ? (DEMO ? <span className="sv-stamp hidden md:inline" title="Demo pack: fictional data">DEMO DATA</span> : <span className="v10-chip nc hidden md:inline-flex" title="Outside services (fax, text, email, payments, claims) are not connected until a BAA is recorded" data-testid="v10-not-connected">Not connected</span>) : <span className="sv-stamp hidden md:inline" title="Fictional data · scripted, on-device Nightingale · nothing is sent">SIMULATION</span>}
        </span></>}>
        {mainEl}{isAscEd && tab !== 'chat' && <AiDock106 key={tab} tab={tab} />}{isAscEd && <StaffBoard />}
      </FdShell>
      {search && <FdSearch onClose={() => setSearch(false)} onPatient={pid => openChart(pid)} onVisit={vid => go({ type: 'station', visitId: vid })} onChat={id => { setChatId(id); setTab('chat'); }} pages={[...H.map(h => ({ label: h.label, run: () => navTo(h.id) })), ...M.filter(m => !m.danger).map(m => ({ label: m.label, run: m.run }))]} />}
      {extras}
    </div>
  </Ctx.Provider>;
  }
  return <Ctx.Provider value={ctx}>
    <div className={`sv ${v7page ? 'sv7-on' : ''}`} data-edition="SURGERY" data-testid="surgery-app">
      <a href="#sv-main" className="sr-only focus:not-sr-only">Skip to content</a>
      <header className="sv-top">
        <button type="button" className="sv-mark" onClick={() => setTab(firstTab())} data-testid="sv-logo">{brand}<span>.Vityls</span></button>
        <nav className="sv-nav" aria-label="Primary">{navItems().map(n => <button key={n.id} type="button" className={n.locked ? 'core-locked' : undefined} title={n.locked ? `Not in your plan · try ${MOD[tabModule(n.id)!].name} free` : undefined} aria-current={activeNav === n.id ? 'page' : undefined} onClick={() => { if (n.id === 'patients') setPatientId(''); setTab(n.id); }} data-testid={`sv-nav-${n.id}`}>{n.locked && <Lock size={12} />}{n.label}</button>)}</nav>
        <div className="sv-top-right">
          <label className="flex items-center gap-1.5 text-[12.5px] text-[var(--ink3)]"><span className="hidden lg:inline">Session</span><select className="sv-select" value={actor.name} onChange={e => { const a = sessionUsers().find(x => x.name === e.target.value); if (a) setActor(a); }} aria-label="Tablet session (test build)" title="Shared tablet session. Signing always asks for the signer’s own PIN." data-testid="acting-as">{sessionUsers().map(a => <option key={a.name} value={a.name}>{a.name} · {a.role}</option>)}</select></label>
          {unlocked && editor && <span className="sv-tag warn whitespace-nowrap" data-testid="practice-unlocked" title="Practice re-locks when you leave it or after 5 minutes without activity">Practice open · {editor.name.replace(/,.*$/, '')} <button type="button" className="sv-link ml-1" onClick={() => { lockPractice('locked by user'); setTab('home'); }} data-testid="practice-lock">Lock</button></span>}
          {modOn('portal-link') && <button type="button" className="sv-link text-[13px] whitespace-nowrap" onClick={() => setPortal(true)} data-testid="open-portal">Portal</button>}
          <span className="sv-stamp" title="Fictional data · scripted, on-device Nightingale · nothing is sent">SIMULATION · fictional</span>
        </div>
      </header>
      {trialMod && !v7page && <div className="core-banner-wrap"><TrialBanner m={trialMod} /></div>}
      {!v7page && (() => { const b = pageBrief(tab, chartPid); return <div className="v8-ngwrap"><NightingaleCard patientId={chartPid || undefined} reads={b.reads} placeholder={b.placeholder} summary={b.summary} chips={next.map(x => ({ label: x.label, act: x.act }))} /></div>; })()}
      <main id="sv-main" className={`sv-main${roMod ? ' core-readonly' : ''}`} data-readonly={roMod || undefined}>
        {lockedMod ? <Teaser m={lockedMod} onStarted={() => { setTeaserMod(null); setToast(`${MOD[lockedMod].name}: free trial started.`); }} /> : <PracticeFrame tab={tab} on={unlocked && tab !== 'practice'}>
        {(tab === 'home' || tab === 'patients') && trialMod && <div className="mb-3"><TrialBanner m={trialMod} /></div>}
        {inPractice && !unlocked && <PracticeGate />}
        {tab === 'email' && <EmailIntakePage onOpenPatient={pid => openChart(pid)} onOpenSchedule={() => setTab('schedule')} toast={setToast} />}
        {unlocked && tab === 'modules' && <ModulesPlan onOpen={m => setTeaserMod(m)} onBack={() => setTab('practice')} />}{unlocked && tab.startsWith('v10-') && <V10Page tab={tab} />}
        {tab === 'home' && <Today7 />}
        {tab === 'schedule' && <SurgerySchedule />}
        {unlocked && tab === 'surgery-settings' && <SurgerySettings />}
        {tab === 'patients' && (patientId && medRepo.patient(patientId) ? (chartOn ? <CoverGate pid={patientId}>{isAscEd ? <AscChart106 patientId={patientId} /> : <Chart7 patientId={patientId} />}</CoverGate> : <MinimalPatient pid={patientId} onBack={() => { setPatientId(''); setTab('patients'); }} onTryChart={() => setTeaserMod('chart')} />) : <SurgeryChart patientId={patientId} />)}
        {tab === 'station' && visitId && (FD ? <><Today7 /><FdDrawer title={<>Station · {medRepo.patient(medRepo.visit(visitId)?.patientId || '')?.name}</>} onClose={() => setTab('home')} testId="fd-station-drawer"><SurgeryStation key={visitId} visitId={visitId} onBack={() => setTab('home')} /></FdDrawer></> : <SurgeryStation key={visitId} visitId={visitId} onBack={() => setTab('home')} />)}
        {FD && tab === 'chat' && <SurgeryChat chatId={chatId} onChat={setChatId} />}
        {tab === 'messages' && <Messages8 onOpenChart={pid => openChart(pid)} />}
        {tab === 'portal-hub' && <PracticePortalHub by={actor.name} />}
        {/* v0.11: the form editor is reached from Forms & workflow › Edit form; old links land there */}
        {unlocked && (tab === 'forms' || tab === 'form-editor') && <SurgeryFormsWorkspace activePracticeId="default-practice" onShowToast={setToast} onBack={() => setTab('practice')} />}
        {unlocked && tab === 'med-settings' && <MedPracticeSettings onBack={() => setTab('practice')} onToast={setToast} />}
        {unlocked && tab === 'practice' && <PracticeHome />}
        {unlocked && tab === 'staff' && <StaffPins />}
        {unlocked && tab === 'profile' && <>{isAscEd ? <div className="sv-page" style={{ paddingBottom: 0 }}><FacilitySettings /></div> : <div className="sv-page" style={{ paddingBottom: 0 }}><PracticeLogoSettings /></div>}<PracticeProfile /></>}
        {(LEGACY_MED ? unlocked : canBill) && tab === 'billing-hub' && (LEGACY_MED ? <BillingHub onBack={() => setTab('practice')} onToast={setToast} /> : (isAscEd ? <BillingPage89 onToast={setToast} /> : <SurgeryBilling onToast={setToast} />))}{!LEGACY_MED && unlocked && tab === 'billing-settings' && <BillingSettings onToast={setToast} />}{!LEGACY_MED && !canBill && tab === 'billing-hub' && <div className="v7-card" style={{ padding: 18 }} data-testid="billing-no-access">Billing &amp; Payments is open to the front desk, administrators and doctors.</div>}
        {unlocked && tab === 'ops-hub' && <SurgeryPerformance />}
        {unlocked && tab === 'records-admin' && <PatientRecordsAdmin />}
        {unlocked && tab === 'people' && <div className="sv-legacy" data-testid="surgery-providers"><button type="button" className="sv-link text-[13px] mb-2" data-ps-legacy="" onClick={() => setTab('practice')}>‹ Practice</button><ProvidersAdmin practice={practiceConfig.practiceName} onToast={setToast} sub="Surgeons, physicians, nurse practitioners and physician assistants. Adding a provider sends one invitation (simulated) with the membership application, username and signature PIN setup." /></div>}
        {unlocked && tab === 'documents' && <div className="sv-legacy sv-v14-admin" data-testid="surgery-compliance"><button type="button" className="sv-link text-[13px] mb-2" data-ps-legacy="" onClick={() => setTab('practice')}>‹ Practice</button><AdministrationPage hideAdminHome onShowToast={setToast} practiceConfig={practiceConfig} practicesList={[practiceConfig]} activePracticeId="default-practice" onSelectPractice={() => {}} onAddPractice={() => setToast('Additional locations are not part of this test build.')} onDeletePractice={() => {}} onUpdatePracticeConfig={setPracticeConfig} activeSection={tab as AdminActiveSection} onSectionChange={sec => { if (sec === 'home') setTab('practice'); else if (sec === 'people' || sec === 'documents') setTab(sec); }} onOpenFormsWorkspace={() => setTab('forms')} onNavigateBilling={() => setTab('billing-hub')} /></div>}
        </PracticeFrame>}
      </main>
      <RightPanel />
      {toastMsg && (isAscEd ? <KitToast msg={toastMsg} onClose={() => setToast('')} /> : <div role="status" className="fixed bottom-5 left-1/2 -translate-x-1/2 z-[90] bg-[#111418] text-white px-4 py-2.5 rounded-lg shadow-lg text-[14px] max-w-[90vw]" data-testid="sv-toast">{toastMsg}</div>)}
    </div>
  </Ctx.Provider>;
};

/** v1.1: the confirm link in reminder texts/emails (#confirm=<visitId>) deep-links into the app and records the confirmation. */
function confirmDeepLink() {
  const m = location.hash.match(/^#confirm=([\w-]+)/); if (!m) return; const v = medRepo.visit(m[1]);
  if (v) { try { setConfirmation(v, 'confirmed', 'patient-reply', medRepo.patient(v.patientId)?.name || 'Patient', 'Patient'); sessionStorage.setItem('sv-today-day', v.date); } catch (e) { console.warn('confirm link', e); } }
  history.replaceState(null, '', location.pathname + location.search);
}
void AscChart90;
