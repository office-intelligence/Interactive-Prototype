/* ASC.Vityls v10.8 · Demo only: a faxed cardiology pre-op clearance letter and its 12-lead ECG, filed to Hugo Pell's
 * case (c8, surgery tomorrow) the way an incoming fax is filed after matching. Everything here is fictional: the practice, the physician,
 * the fax numbers and the results. Drawn as SVG so the document viewer can open, zoom and mark it like a scan. */
import { svRead, svWrite } from '../store';
import * as S from '../asc8/store';
import { uploads, logActivity, type Upload } from '../asc87/store87';

const KEY = 'asc108-clearance-demo';
const esc = (s: string) => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
const svgUrl = (svg: string) => 'data:image/svg+xml;base64,' + btoa(unescape(encodeURIComponent(svg)));
const fmt = (d: Date) => d.toLocaleDateString('en-US', { month: '2-digit', day: '2-digit', year: 'numeric' });
const long = (d: Date) => d.toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' });

function letter(sent: Date, dos: Date): string {
  const W = 850, F = "font-family='Georgia, Times New Roman, serif'", SF = "font-family='Helvetica, Arial, sans-serif'";
  let y = 0; const t: string[] = [];
  const line = (s: string, x = 70, size = 14.5, extra = '') => { t.push(`<text x='${x}' y='${y}' font-size='${size}' ${F} fill='#1d1d1f' ${extra}>${esc(s)}</text>`); };
  const para = (s: string, w = 92, x = 70) => { const words = s.split(' '); let cur = ''; words.forEach(wd => { if ((cur + ' ' + wd).trim().length > w) { line(cur.trim(), x); y += 21; cur = wd; } else cur += ' ' + wd; }); if (cur.trim()) { line(cur.trim(), x); y += 21; } };
  t.push(`<rect width='${W}' height='1100' fill='#fdfcf8'/>`);
  t.push(`<text x='24' y='20' font-size='10.5' ${SF} fill='#555'>${esc(`${fmt(sent)} 07:42   FROM: Bayside Heart & Vascular (555) 016-4400   TO: ASC Pre-op (555) 019-3300   P.1/1`)}</text>`);
  t.push(`<line x1='24' y1='28' x2='826' y2='28' stroke='#999' stroke-width='0.6'/>`);
  t.push(`<rect x='70' y='54' width='46' height='46' rx='8' fill='#2f5d62'/><text x='93' y='86' text-anchor='middle' font-size='22' ${SF} font-weight='700' fill='#fff'>BHV</text>`);
  t.push(`<text x='130' y='74' font-size='22' ${F} font-weight='700' fill='#2f5d62'>Bayside Heart &amp; Vascular</text>`);
  t.push(`<text x='130' y='94' font-size='11.5' ${SF} fill='#555'>Cardiology · 880 Bayside Parkway, Suite 210 · Tel (555) 016-4400 · Fax (555) 016-4401</text>`);
  t.push(`<line x1='70' y1='112' x2='780' y2='112' stroke='#2f5d62' stroke-width='2'/>`);
  y = 146; t.push(`<text x='425' y='${y}' text-anchor='middle' font-size='18' ${SF} font-weight='700' letter-spacing='1.5' fill='#1d1d1f'>PRE-OPERATIVE CARDIAC CLEARANCE</text>`);
  y = 184; line(`Date: ${long(sent)}`); y += 21; line('To: Sam Patel, MD — General Surgery, and the Anesthesia team'); y += 30;
  const kv: [string, string][] = [['Patient', 'Hugo Pell'], ['Date of birth', '12/04/1958'], ['Procedure', 'Inguinal hernia repair, left (open)'], ['Date of surgery', fmt(dos)], ['Last seen', `${fmt(new Date(sent.getTime() - 2 * 864e5))} (in office)`]];
  t.push(`<rect x='70' y='${y - 18}' width='710' height='${kv.length * 22 + 14}' fill='#f2efe6' stroke='#d8d2c2'/>`);
  kv.forEach(([k, v]) => { t.push(`<text x='86' y='${y}' font-size='13.5' ${SF} font-weight='700' fill='#333'>${esc(k)}</text><text x='240' y='${y}' font-size='13.5' ${SF} fill='#1d1d1f'>${esc(v)}</text>`); y += 22; });
  y += 22;
  const h = (s: string) => { t.push(`<text x='70' y='${y}' font-size='13' ${SF} font-weight='700' letter-spacing='0.8' fill='#2f5d62'>${esc(s.toUpperCase())}</text>`); y += 22; };
  h('Pertinent history');
  para('Persistent atrial fibrillation since 2021, rate controlled without AV-nodal agents, anticoagulated with apixaban 5 mg twice daily. CHA2DS2-VASc 1 (age). No coronary disease, heart failure, stroke/TIA or bleeding history. Echo (03/2026): LVEF 60%, mild left atrial enlargement, no significant valve disease. No known drug allergies.');
  y += 8; h('Exam & results');
  para('BP 128/78, HR 78 irregularly irregular, SpO2 98% on room air. No murmur; lungs clear; no edema. ECG: atrial fibrillation, ventricular rate 78, no acute ST-T changes (tracing attached). Labs: creatinine 1.0 (CrCl 74 mL/min), Hgb 14.6, platelets 212, K 4.1.');
  y += 8; h('Assessment');
  para('Functional capacity > 4 METs (walks 2 miles daily without symptoms). RCRI 0 points. Low cardiac risk for a low-to-moderate bleeding-risk outpatient procedure. No further cardiac testing is indicated before surgery.');
  y += 8; h('Recommendations');
  ['Hold apixaban for 2 days: last dose the morning of ' + fmt(new Date(dos.getTime() - 2 * 864e5)) + '. No bridging is needed.', 'Resume apixaban 24 hours after surgery if hemostasis is adequate, per the surgeon.', 'Expect an irregular rhythm on the monitor; treat HR > 110 per anesthesia.', 'Mechanical VTE prophylaxis (SCDs) during the procedure.', 'Please fax the operative note to our office.'].forEach(r => { t.push(`<text x='78' y='${y}' font-size='14.5' ${F} fill='#1d1d1f'>•</text>`); para(r, 86, 96); });
  y += 14;
  t.push(`<rect x='70' y='${y - 22}' width='710' height='38' fill='none' stroke='#2f5d62' stroke-width='1.6'/><text x='86' y='${y + 3}' font-size='15.5' ${SF} font-weight='700' fill='#2f5d62'>☑ ACCEPTABLE CARDIAC RISK — cleared for surgery with the plan above</text>`);
  y += 62; line('Please call with any questions.'); y += 46;
  t.push(`<path d='M ${80} ${y} c 18 -26 30 8 44 -8 s 20 -22 34 2 s 22 10 40 -12 s 26 6 48 -4' fill='none' stroke='#1b3a8a' stroke-width='2' stroke-linecap='round'/>`);
  y += 22; line('Marcus Feld, MD, FACC', 70, 14.5, "font-weight='700'"); y += 20; line('Cardiology · NPI 1999999998 (demo)', 70, 12.5); y += 18; line(`Electronically signed ${fmt(sent)} 07:38`, 70, 12.5);
  t.push(`<text x='425' y='1080' text-anchor='middle' font-size='10' ${SF} fill='#888'>CONFIDENTIAL: This fax contains protected health information. Fictional demo document.</text>`);
  return `<svg xmlns='http://www.w3.org/2000/svg' width='${W}' height='1100' viewBox='0 0 ${W} 1100'>${t.join('')}</svg>`;
}

function ecg(sent: Date): string {
  const W = 1100, H = 850, SF = "font-family='Helvetica, Arial, sans-serif'"; const t: string[] = [];
  t.push(`<rect width='${W}' height='${H}' fill='#fff'/>`);
  t.push(`<text x='24' y='20' font-size='10.5' ${SF} fill='#555'>${esc(`${fmt(sent)} 07:43   FROM: Bayside Heart & Vascular (555) 016-4400   TO: ASC Pre-op (555) 019-3300   ECG P.1/1`)}</text>`);
  t.push(`<text x='40' y='54' font-size='15' ${SF} font-weight='700'>PELL, HUGO   DOB 12/04/1958   M   ID ASC-2008</text>`);
  t.push(`<text x='40' y='76' font-size='12.5' ${SF}>Vent rate 78 bpm · PR — · QRS 94 ms · QT/QTc 372/418 ms · Axis 22°</text>`);
  t.push(`<text x='40' y='96' font-size='12.5' ${SF} font-weight='700'>Atrial fibrillation with controlled ventricular response · No acute ST-T changes · Confirmed by M. Feld, MD</text>`);
  const gx = 40, gy = 112, gw = 1020, gh = 700;
  for (let x = 0; x <= gw; x += 8) t.push(`<line x1='${gx + x}' y1='${gy}' x2='${gx + x}' y2='${gy + gh}' stroke='#f6c6c6' stroke-width='${x % 40 ? 0.4 : 1}'/>`);
  for (let y = 0; y <= gh; y += 8) t.push(`<line x1='${gx}' y1='${gy + y}' x2='${gx + gw}' y2='${gy + y}' stroke='#f6c6c6' stroke-width='${y % 40 ? 0.4 : 1}'/>`);
  const leads = [['I', 'aVR', 'V1', 'V4'], ['II', 'aVL', 'V2', 'V5'], ['III', 'aVF', 'V3', 'V6']];
  const amp: Record<string, number> = { I: 0.8, II: 1.1, III: 0.5, aVR: -0.9, aVL: 0.4, aVF: 0.8, V1: -0.6, V2: -0.3, V3: 0.6, V4: 1.2, V5: 1.1, V6: 0.9 };
  const beat = (x0: number, base: number, a: number) => { const k = 40 * a; return `L ${x0} ${base} l 4 -2 l 4 3 l 4 -3 l 4 2 l 4 -2 l 4 3 l 4 -1 L ${x0 + 34} ${base} L ${x0 + 38} ${base + 4} L ${x0 + 43} ${base - k} L ${x0 + 48} ${base + 10 * Math.sign(a)} L ${x0 + 52} ${base} L ${x0 + 66} ${base} q 10 -${12 * Math.abs(a) + 2} 20 0 l 4 -2 l 4 2 l 4 -2 l 4 2`; };
  const row = (r: number, names: string[] | null, lead: string) => { const base = gy + 110 + r * 170; let d = `M ${gx + 10} ${base} l 0 -40 l 16 0 l 0 40`; const seg = gw / 4;
    const gaps = [96, 118, 84, 132, 102, 90, 124, 88, 110, 98]; let gi = r * 3; for (let x = gx + 30; x < gx + gw - 90; x += gaps[gi++ % gaps.length]) { const L = names ? names[Math.min(3, Math.floor((x - gx) / seg))] : lead; d += ' ' + beat(x, base, amp[L]); }
    t.push(`<path d='${d}' fill='none' stroke='#111' stroke-width='1.3'/>`);
    (names || [lead]).forEach((n, i) => t.push(`<text x='${gx + 34 + i * seg}' y='${base - 50}' font-size='13' ${SF} font-weight='700'>${n}</text>`)); };
  leads.forEach((n, r) => row(r, n, '')); row(3, null, 'II');
  t.push(`<text x='40' y='836' font-size='10.5' ${SF} fill='#666'>25 mm/s · 10 mm/mV · 0.05–150 Hz · Fictional demo tracing</text>`);
  return `<svg xmlns='http://www.w3.org/2000/svg' width='${W}' height='${H}' viewBox='0 0 ${W} ${H}'>${t.join('')}</svg>`;
}

/** Files the demo clearance once. A reset of demo data runs it again. */
export function ensureClearanceDemo() {
  if (svRead<string>(KEY, '') === '1') return; const c = S.caseById('c8'); if (!c) return;
  if (uploads('c8').some(u => u.id.startsWith('demo108-'))) { svWrite(KEY, '1'); return; }
  const dos = new Date(c.date + 'T12:00'); const sent = new Date(Date.now() - 18 * 3600e3);
  const mk = (id: string, type: string, name: string, svg: string, note: string): Upload => { const data = svgUrl(svg); return { id, pid: c.pid, cid: c.id, dos: c.date, type, cat: 'Clinical', station: 'Fax inbox', name, size: Math.round(data.length * 0.75), mime: 'image/svg+xml', data, at: sent.toISOString(), by: 'Fax inbox (auto-matched)', role: 'System', note }; };
  const list = [mk('demo108-clear', 'Medical clearance', 'Bayside Heart & Vascular · cardiac clearance (fax)', letter(sent, dos), 'Faxed by Bayside Heart & Vascular · matched by name + DOB'),
    mk('demo108-ecg', 'ECG', 'Bayside Heart & Vascular · 12-lead ECG (fax)', ecg(sent), 'Attached to the clearance fax')];
  try { svWrite('asc87-uploads', [...uploads(), ...list]); } catch { return; }
  logActivity('clearance', 'Cardiac clearance and ECG from Bayside Heart & Vascular received by fax and matched to Hugo Pell (DOS tomorrow)', 'c8');
  svWrite(KEY, '1');
}
