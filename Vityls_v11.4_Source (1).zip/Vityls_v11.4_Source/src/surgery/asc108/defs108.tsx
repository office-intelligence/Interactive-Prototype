/* ASC.Vityls v10.8 · Station definitions for the native engine: check-in, verify history, pre-op nursing, anesthesia,
 * surgeon, PACU and discharge (the OR definition lives in asc106/or106). Consents keep the real form, opened full screen
 * with the signature captured inside it. Each sync() writes the same case keys the earlier stations wrote, so status,
 * Today, the chart, billing and the journey are unchanged. Sample Talk conversations are fictional. */
import React from 'react';
import { medRepo, PROVIDER_ROLES } from '../../med/record';
import * as A from '../asc8/logic';
import * as S from '../asc8/store';
import { openBench } from '../asc81/practice81';
import { Arrival } from '../asc81/Workbench';
import { CardCapture, Discharge82 } from '../asc82/benches';
import { AIRWAY } from '../asc82/pure';
import { CheckInFlow } from '../asc83/frontdesk';
import { ActiveOrdersCard, Flowsheet } from '../asc86/ui86';
import { BriefOpReport, FrontDeskDocs, StandingChecklist, VerifyHistory } from '../asc10/flow10';
import { FormalOpPending } from '../asc10/fixes10';
import { NursingConsents, ConsentLinks, AnesSummary } from '../asc10/station102';
import { historyVerified, viewList } from '../asc10/store10';
import { ClearanceDocsCard, clearanceDocs, reviewsFor } from '../asc106/clearance106';
import { anesType } from '../asc90/today90';
import { allergyText, type Def, type Item } from './native108';

const now = () => new Date().toISOString();
const listDone = (cid: string, surgeon: string, ph: 'pre' | 'post') => { const l = viewList(cid, surgeon, ph); return l.items.length > 0 && l.items.every(i => l.ticks[i.id]); };
const nm = (c: A.AscCase) => medRepo.patient(c.pid)?.name || 'the patient';
const PAIN = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '10'];
const isSurgeonOf = (p: { name: string }, c: A.AscCase) => p.name === c.surgeon;

/* ---------------- Check-in (front desk) ---------------- */
export const FRONT_DEF: Def = { st: 'front', bench: 'arrival', here: 'checkin', title: 'Check-in', storeKey: 'asc108-front', testId: 'a81-bench-arrival',
  phases: [
    { id: 'forms', title: 'At-home forms', when: 'Signed in the portal', items: [{ id: 'p_forms', label: '', kind: 'panel', render: c => <FrontDeskDocs c={c} />, done: c => !!(c.d.forms && c.d.financial), req: true }] },
    { id: 'cards', title: 'ID & insurance cards', when: 'Photos on the tablet', items: [{ id: 'p_cards', label: '', kind: 'panel', render: c => <CardCapture c={c} />, done: c => A.isDone(c, 'id'), req: true }] },
    { id: 'escort', title: 'Ride home & caregiver', when: 'Confirm before pre-op', items: [
      { id: 'adult_name', label: 'Escort name', kind: 'text', req: true, dflt: c => c.d.adult?.name },
      { id: 'adult_phone', label: 'Escort phone', kind: 'text', req: true, dflt: c => c.d.adult?.phone },
      { id: 'adult_rel', label: 'Relationship', kind: 'radio', opts: ['Spouse / partner', 'Family', 'Friend', 'Other'] },
      { id: 'adult_stay', label: 'Stays with the patient tonight', kind: 'radio', opts: ['Yes', 'No · arranged other care'], req: true }] },
    { id: 'checkin', title: 'Check-in & payment', when: 'Patient arrives', items: [{ id: 'p_checkin', label: '', kind: 'panel', render: (c, x) => <CheckInFlow cid={c.id} onDone={m => x.close(m)} />, done: c => A.atLeast(c.loc, 'arrived'), req: true }] },
    { id: 'follow', title: 'Booking checklist & follow-up', when: 'Missing items and emails', items: [{ id: 'p_follow', label: '', kind: 'panel', render: (c, x) => <Arrival c={c} onClose={x.close} only="followup" /> }] }],
  script: [['Front desk: Good morning, can I have your name and date of birth?', {}], ['Patient: {name}, born {dob}.', {}], ['Front desk: Who is driving you home today?', {}], ['Patient: My sister Dana, her number is 555 010 2233, she is staying with me tonight.', { adult_name: 'Dana', adult_phone: '(555) 010-2233', adult_rel: 'Family', adult_stay: 'Yes' }]],
  sync: (c, v, actor) => { const x = S.caseById(c.id)!; const n = v('adult_name'), ph = v('adult_phone'); if (n && ph && (x.d.adult?.name !== n || x.d.adult?.phone !== ph)) S.setValue(x, 'adult', { ...(x.d.adult || {}), name: n, phone: ph, relationship: v('adult_rel'), overnight: v('adult_stay'), present: true }, actor.name, actor.role, `Responsible adult: ${n} · ${ph}`); },
  signs: [] };

/* ---------------- Verify medical history (no signature) ---------------- */
export const VERIFY_DEF: Def = { noFac: true, st: 'nursing', bench: 'verify', here: 'verify', title: 'Verify medical history', storeKey: 'asc108-verify', testId: 'a81-bench-verify',
  phases: [
    { id: 'docs', title: 'Clearance documents', when: 'Open, mark, initial', items: [{ id: 'p_docs', label: '', kind: 'panel', render: c => <ClearanceDocsCard c={c} />, done: c => { const d = clearanceDocs(c); return d.length > 0 && Object.keys(reviewsFor(c.id)).length >= d.length; }, req: true }] },
    { id: 'history', title: 'Official medical history', when: 'Confirm once for every station', items: [{ id: 'p_hx', label: '', kind: 'panel', render: (c, x) => <VerifyHistory c={c} onClose={x.close} hideDocs />, done: c => historyVerified(c.id), req: true }] }],
  signs: [] };

/* ---------------- Pre-op nursing ---------------- */
export const NURSING_DEF: Def = { st: 'nursing', bench: 'nursing', here: 'nursing', title: 'Pre-op nursing', storeKey: 'asc108-nursing', testId: 'a81-bench-nursing', notes: 'Pre-op nursing',
  phases: [
    { id: 'orders', title: 'Surgeon’s pre-op orders', when: 'Standing orders from Practice settings', items: [{ id: 'p_orders', label: '', kind: 'panel', render: c => <StandingChecklist c={c} phase="pre" />, done: c => listDone(c.id, c.surgeon, 'pre'), req: true }] },
    { id: 'consents', title: 'Consents', when: 'The patient signs inside each form', items: [{ id: 'p_consents', label: '', kind: 'panel', render: c => <NursingConsents c={c} />, done: c => !!(S.caseById(c.id)?.d.anesConsent && S.caseById(c.id)?.d.consentConfirm), req: true }] },
    { id: 'identity', title: 'Identity, procedure & allergies', when: 'With the patient', items: [
      { id: 'id_band', label: 'ID band on: name and DOB match the patient’s answer', kind: 'check', req: true },
      { id: 'proc', label: c => `Patient states procedure, site and side: ${c.procedure}`, kind: 'check', req: true },
      { id: 'allergy', label: c => `Allergies confirmed with the patient: ${allergyText(c)}`, kind: 'check', req: true },
      { id: 'allergy_band', label: 'Allergy band', kind: 'radio', opts: ['On', 'N/A · no allergies'], req: true },
      { id: 'clearance', label: 'H&P, clearance and labs on the chart', kind: 'check', req: true },
      { id: 'isolation', label: 'Isolation precautions', kind: 'radio', opts: ['None', 'Contact', 'Droplet', 'Airborne'] }] },
    { id: 'npo', title: 'NPO & medications', when: 'Last intake and holds', items: [
      { id: 'npo_solids', label: 'Last solid food', kind: 'text', quick: ['Before midnight', '8 PM', '9 PM', '10 PM'], req: true },
      { id: 'npo_clears', label: 'Last clear liquids', kind: 'text', quick: ['4 AM', '5 AM', '6 AM', '2 h before arrival'], req: true },
      { id: 'meds_am', label: 'Morning medications', kind: 'radio', opts: ['Taken as instructed', 'None', 'Took a held medication'], req: true },
      { id: 'anticoag', label: 'Blood thinners', kind: 'radio', opts: ['Held as instructed', 'Not taking', 'Not held · notify'], req: true },
      { id: 'glp1', label: 'GLP-1 medication', kind: 'radio', opts: ['Held as instructed', 'Not taking', 'Not held · notify'], req: true }] },
    { id: 'assess', title: 'Vitals & assessment', when: 'Baseline', items: [
      { id: 'bp', label: 'Blood pressure', kind: 'text', req: true }, { id: 'hr', label: 'Heart rate', kind: 'number', unit: 'bpm', req: true },
      { id: 'spo2', label: 'SpO₂', kind: 'number', unit: '%', quick: ['95', '96', '97', '98', '99', '100'], req: true }, { id: 'temp', label: 'Temperature', kind: 'number', unit: '°F', quick: ['97.8', '98.2', '98.6'] },
      { id: 'weight', label: 'Weight', kind: 'number', unit: 'kg' }, { id: 'pain', label: 'Pain score (0–10)', kind: 'radio', opts: PAIN, req: true },
      { id: 'glucose', label: 'Fingerstick glucose (diabetic patients)', kind: 'number', unit: 'mg/dL', quick: ['N/A'] },
      { id: 'hcg', label: 'Pregnancy test', kind: 'radio', opts: ['Negative', 'Positive · notify', 'N/A'], req: true },
      { id: 'skin_void', label: 'Skin intact at the surgical site; voided before surgery', kind: 'check', req: true }] },
    { id: 'prep', title: 'Lines & prep', when: 'Before transfer', items: [
      { id: 'iv_site', label: 'IV site', kind: 'dropdown', opts: ['R hand', 'L hand', 'R forearm', 'L forearm', 'R antecubital', 'L antecubital'], req: true },
      { id: 'iv_gauge', label: 'IV gauge', kind: 'radio', opts: ['18 g', '20 g', '22 g', '24 g'], req: true },
      { id: 'hair', label: 'Skin prep / hair removal', kind: 'radio', opts: ['Not needed', 'Clipped', 'Prep done per protocol'] },
      { id: 'belongings', label: 'Removed and secured', kind: 'multi', opts: ['Dentures / partials', 'Jewelry / piercings', 'Contacts / glasses', 'Hearing aids', 'None'], req: true },
      { id: 'implants', label: 'Metal implants or devices', kind: 'radio', opts: ['None', 'Pacemaker / ICD', 'Joint / hardware', 'Other · note'], req: true }] },
    { id: 'plan', title: 'Discharge planning', when: 'Going home', items: [
      { id: 'home_plan', label: 'After surgery', kind: 'radio', opts: ['Home with adult overnight', 'Hotel with adult', 'Recovery facility'], req: true },
      { id: 'instr', label: 'Pre-op and discharge instructions given and understood by patient and escort', kind: 'check', req: true }] }],
  script: [['Nurse: Good morning. Can you tell me your name and date of birth?', {}], ['Patient: {name}, {dob}.', { id_band: true }], ['Nurse: And what are we doing today?', {}], ['Patient: The {procedure}.', { proc: true }],
    ['Nurse: Any allergies? I have {allergy}.', { allergy: true }], ['Nurse: When did you last eat or drink?', {}], ['Patient: Toast at nine last night, a sip of water at five this morning.', { npo_solids: '9 PM', npo_clears: '5 AM' }],
    ['Nurse: Did you take any medicines this morning? Any blood thinners?', {}], ['Patient: Just my blood pressure pill, and I stopped the blood thinner like they said.', { meds_am: 'Taken as instructed', anticoag: 'Held as instructed' }],
    ['Nurse: BP 132 over 84, heart rate 76, oxygen 97 percent, temperature 98.2.', { bp: '132/84', hr: '76', spo2: '97', temp: '98.2' }], ['Nurse: Any pain right now, zero to ten?', {}], ['Patient: Maybe a two.', { pain: '2' }],
    ['Nurse: IV in the left forearm, twenty gauge. Glasses and rings are in your bag.', { iv_site: 'L forearm', iv_gauge: '20 g', belongings: ['Jewelry / piercings', 'Contacts / glasses'] }],
    ['Nurse: Who is taking you home?', {}], ['Patient: My sister, she is staying with me tonight.', { home_plan: 'Home with adult overnight' }]],
  sync: (c, v, actor) => { let x = S.caseById(c.id)!; const who = actor.name, role = actor.role; const at = now();
    const vit = { bp: v('bp'), hr: v('hr'), spo2: v('spo2'), temp: v('temp'), weight: v('weight') }; if (vit.bp && vit.hr && JSON.stringify(x.d.vitals) !== JSON.stringify(vit)) x = S.setValue(x, 'vitals', vit, who, role, `Vitals: BP ${vit.bp}, HR ${vit.hr}, SpO2 ${vit.spo2 || '—'}`);
    if (v('npo_solids') && v('npo_clears') && (x.d.npo?.solids !== v('npo_solids') || x.d.npo?.clears !== v('npo_clears'))) x = S.setValue(x, 'npo', { solids: v('npo_solids'), clears: v('npo_clears') }, who, role, `NPO: solids ${v('npo_solids')}, clears ${v('npo_clears')}`);
    if (v('allergy') && !A.isDone(x, 'allergy')) x = S.confirmAllergies(x, who, role);
    if (v('meds_am') && v('anticoag') && !A.isDone(x, 'meds')) x = S.setValue(x, 'meds', { by: who, at, am: v('meds_am'), anticoag: v('anticoag'), glp1: v('glp1') }, who, role, 'Medications reviewed');
    if (v('iv_site') && v('iv_gauge') && (x.d.iv?.site !== v('iv_site') || x.d.iv?.gauge !== v('iv_gauge'))) x = S.setValue(x, 'iv', { site: v('iv_site'), gauge: v('iv_gauge'), time: S.nowTime() }, who, role, `IV started: ${v('iv_site')}, ${v('iv_gauge')}`);
    if (v('skin_void') && !x.d.sitecheck) x = S.setValue(x, 'sitecheck', { by: who, at }, who, role, 'Site-mark / skin check');
    if (v('clearance') && !x.d.clearance) x = S.setValue(x, 'clearance', { by: who, at }, who, role, 'Clearance reviewed'); },
  signs: [{ id: 'nursing', label: 'Sign nursing admission', roles: S.NURSE_ROLES, statement: (c, n) => `I completed the pre-op nursing admission for ${nm(c)}.${n ? ` ${n} item(s) are open and become flags.` : ''}`,
    onSigned: (c, values, s, open) => { let x = S.caseById(c.id)!; if (open.length) x = S.setValue(x, 'exceptions', { ...(x.d.exceptions || {}), nursing: { items: open, by: s.name, at: s.at } }, s.name, s.role, `Nursing admission signed with exceptions: ${open.join('; ')}`);
      S.setValue(x, 'nursingForm', { by: s.name, at: s.at, signed: true, values }, s.name, s.role, 'Nursing admission signed with PIN'); } }] };

/* ---------------- Anesthesia ---------------- */
const roman = ['I', 'II', 'III', 'IV'];
export const ANES_DEF: Def = { st: 'anesthesia', bench: 'anesthesia', here: 'anesthesia', title: 'Anesthesia', storeKey: 'asc108-anesthesia', testId: 'a81-bench-anesthesia',
  brief: c => `${anesType(c)} planned.`,
  phases: [
    { id: 'consent', title: 'Anesthesia consent', when: 'Opens the form; signature inside it', items: [{ id: 'p_consent', label: '', kind: 'panel', render: c => <ConsentLinks c={c} station="anesthesia" only="anes" />, done: c => !!S.caseById(c.id)?.d.anesConsent, req: true }] },
    { id: 'review', title: 'History & questionnaire', when: 'Already known, review', items: [
      { id: 'p_sum', label: '', kind: 'panel', render: c => <AnesSummary c={c} station="anesthesia" /> },
      { id: 'hx_reviewed', label: 'History, medications, questionnaire, labs and ECG reviewed', kind: 'check', req: true },
      { id: 'mets', label: 'Functional capacity', kind: 'radio', opts: ['≥ 4 METs, ambulatory', '< 4 METs', 'Wheelchair / assisted'], req: true },
      { id: 'cp_sx', label: 'Cardiopulmonary symptoms', kind: 'multi', opts: ['None', 'Chest pain', 'Shortness of breath', 'Palpitations / syncope', 'Recent infection'], req: true },
      { id: 'prior_anes', label: 'Prior anesthesia problems', kind: 'multi', opts: ['None', 'PONV', 'Difficult airway', 'Malignant hyperthermia (patient / family)'] }] },
    { id: 'airway', title: 'Airway', when: 'Examine', items: [...AIRWAY.map(([k, l, o]): Item => ({ id: `aw_${k}`, label: l, kind: 'radio', opts: o as string[], req: true })),
      { id: 'aw_note', label: 'Airway notes', kind: 'text' } as Item] },
    { id: 'exam', title: 'ASA & focused exam', when: 'Classify', items: [
      { id: 'asa', label: 'ASA class', kind: 'radio', opts: ['I', 'II', 'III', 'IV'], req: true, dflt: c => c.d.asa },
      { id: 'heart', label: 'Heart: regular rate and rhythm, no murmur', kind: 'check', req: true }, { id: 'lungs', label: 'Lungs: clear bilaterally', kind: 'check', req: true },
      { id: 'neuro', label: 'Alert and oriented', kind: 'check', req: true }, { id: 'npo_ok', label: 'NPO status confirmed', kind: 'check', req: true }, { id: 'iv_ok', label: 'IV patent', kind: 'check', req: true }] },
    { id: 'plan', title: 'Plan', when: 'Type and technique', items: [
      { id: 'type', label: 'Anesthesia type', kind: 'radio', opts: ['General', 'MAC', 'Regional', 'Local + sedation'], req: true, dflt: c => c.d.plan?.technique },
      { id: 'tech', label: 'Airway / technique', kind: 'multi', opts: ['Natural airway', 'LMA', 'ETT', 'Nerve block', 'Spinal', 'Local infiltration'], req: true },
      { id: 'ponv', label: 'PONV prophylaxis', kind: 'radio', opts: ['None', 'Ondansetron', 'Dexamethasone', 'Scopolamine patch', 'Multimodal'] },
      { id: 'plan_note', label: 'Plan notes', kind: 'text', long: true }] },
    { id: 'induction', title: 'At induction', when: 'Immediately before induction', items: [
      { id: 'reeval', label: 'Re-evaluated immediately before induction: vitals and airway reviewed; still a suitable candidate', kind: 'check', req: true },
      { id: 'reeval_note', label: 'Changes since the evaluation', kind: 'text', quick: ['No change'] }] }],
  script: [['Anesthesia: Good morning, I am Dr. {surgeon}’s anesthesia partner. Any problems with anesthesia before?', {}], ['Patient: I got sick to my stomach last time.', { prior_anes: ['PONV'] }],
    ['Anesthesia: Can you climb two flights of stairs without stopping?', {}], ['Patient: Yes, no chest pain or trouble breathing.', { mets: '≥ 4 METs, ambulatory', cp_sx: ['None'] }],
    ['Anesthesia: Open wide. Mallampati two, good mouth opening, full neck movement, teeth intact.', { aw_mallampati: 'II', aw_mouth: '≥ 3 fingers', aw_neck: 'Full', aw_teeth: 'Intact', aw_tmd: '≥ 6 cm' }],
    ['Anesthesia: Heart regular, lungs clear. ASA two.', { heart: true, lungs: true, asa: 'II' }], ['Anesthesia: Plan general anesthesia with an LMA, ondansetron and dexamethasone for nausea.', { type: 'General', tech: ['LMA'], ponv: 'Multimodal' }]],
  sync: (c, v, actor) => { let x = S.caseById(c.id)!; const who = actor.name, role = actor.role;
    if (v('asa') && x.d.asa !== v('asa')) x = S.setValue(x, 'asa', v('asa'), who, role, `ASA ${v('asa')}`);
    const aw = Object.fromEntries(AIRWAY.map(([k]) => [k, v(`aw_${k}`)])); if (aw.mallampati && JSON.stringify({ ...aw, notes: v('aw_note') || '' }) !== JSON.stringify(x.d.airway)) x = S.setValue(x, 'airway', { ...aw, notes: v('aw_note') || '' }, who, role, `Airway: Mallampati ${aw.mallampati}`);
    if (v('type') && (x.d.plan?.technique !== v('type') || JSON.stringify(x.d.plan?.tech) !== JSON.stringify(v('tech') || []))) S.setValue(x, 'plan', { technique: v('type'), tech: v('tech') || [], ponv: v('ponv'), notes: v('plan_note') || '', by: who, at: now() }, who, role, `Plan: ${v('type')}`); },
  signs: [
    { id: 'eval', label: 'Sign evaluation', roles: S.ANES_ROLES, locks: ['review', 'airway', 'exam', 'plan'], statement: c => `I completed the pre-anesthesia evaluation for ${nm(c)}.`,
      onSigned: (c, values, s) => { S.setValue(S.caseById(c.id)!, 'anesEval', { by: s.name, at: s.at, signed: true, values }, s.name, s.role, 'Pre-anesthesia evaluation signed with PIN'); } },
    { id: 'reeval', label: 'Sign re-evaluation', roles: S.ANES_ROLES, phase: 'induction', needs: ['eval', 'reeval'], locks: ['induction'], statement: c => `I re-evaluated ${nm(c)} immediately before induction.`,
      onSigned: (c, values, s) => { S.setValue(S.caseById(c.id)!, 'preInduction', { by: s.name, at: s.at, note: values.reeval_note || '' }, s.name, s.role, 'Immediate pre-induction re-evaluation signed'); } }] };
void roman;

/* ---------------- Surgeon ---------------- */
export const SURGEON_DEF: Def = { st: 'surgeon', bench: 'surgeon', here: 'surgeon', title: 'Surgeon', storeKey: 'asc108-surgeon', testId: 'a81-bench-surgeon',
  phases: [
    { id: 'consent', title: 'Surgical consent', when: 'Opens the form; signature inside it', items: [{ id: 'p_consent', label: '', kind: 'panel', render: c => <ConsentLinks c={c} station="surgeon" only="surg" />, done: c => !!S.caseById(c.id)?.d.consentConfirm, req: true }] },
    { id: 'orders', title: 'Doctor orders', when: 'As per facility protocol', items: [
      { id: 'orders_ok', label: 'Pre-op orders as per facility protocol', kind: 'check', req: true },
      { id: 'p_orders', label: '', kind: 'panel', render: c => <button type="button" className="a8-btn" onClick={() => openBench('orders' as any, c.id)} data-testid="n8-open-orders">Open doctor orders</button> }] },
    { id: 'hp', title: 'Interval H&P and site marking', when: 'Before the patient goes back', items: [
      { id: 'hp_ok', label: 'H&P reviewed and patient examined today', kind: 'check', req: true },
      { id: 'interval', label: 'Interval changes', kind: 'radio', opts: ['No interval change', 'Changes noted below'], req: true },
      { id: 'interval_note', label: 'Changes', kind: 'text' },
      { id: 'site', label: c => `Site marked with the patient awake and agreeing${c.side ? ` (${c.side})` : ''}`, kind: 'radio', opts: ['Marked', 'N/A · no laterality', 'Patient refused'], req: true },
      { id: 'suitable', label: 'Still a suitable candidate; no new contraindications', kind: 'check', req: true },
      { id: 'decision', label: 'Decision', kind: 'radio', opts: ['Proceed as planned', 'Defer / modify plan'], req: true },
      { id: 'plan_notes', label: 'Plan notes', kind: 'text', long: true }] },
    { id: 'brief', title: 'Brief op report', when: 'After the case, before leaving', items: [{ id: 'p_brief', label: '', kind: 'panel', render: c => <BriefOpReport c={c} />, done: c => !!S.caseById(c.id)?.d.opReport?.signedAt }] },
    { id: 'formal', title: 'Formal op report', when: 'From dictation', items: [{ id: 'p_formal', label: '', kind: 'panel', render: c => <FormalOpPending c={c} /> }] }],
  script: [['Surgeon: Morning. I reviewed your H and P, nothing new since I saw you?', {}], ['Patient: Nothing new.', { hp_ok: true, interval: 'No interval change' }], ['Surgeon: Let me mark the site, this is the {procedure} side, correct?', {}], ['Patient: Yes, that side.', { site: 'Marked' }], ['Surgeon: You are a good candidate, we will proceed as planned.', { suitable: true, decision: 'Proceed as planned' }]],
  signs: [{ id: 'hp', label: 'Sign H&P update', roles: PROVIDER_ROLES as string[], allow: (p, c) => isSurgeonOf(p, c), statement: c => `I reviewed the H&P, examined ${nm(c)} today and marked the site.`,
    onSigned: (c, v, s) => { let x = S.caseById(c.id)!; if (v.site === 'Marked' && !x.d.sitemark) x = S.setValue(x, 'sitemark', { by: s.name, at: s.at }, s.name, s.role, `Site marked${c.side ? ` (${c.side})` : ''}`);
      S.setValue(x, 'hpUpdate', { by: s.name, at: s.at, signed: true, note: v.interval_note || '', suitable: !!v.suitable, noNewContra: !!v.suitable, plan: v.decision || '', planNotes: v.plan_notes || '' }, s.name, s.role, `Interval H&P update signed with PIN · ${v.decision || ''}`); } }] };

/* ---------------- PACU ---------------- */
const ALD: [string, string[]][] = [['ald_act', ['2 · moves 4 limbs', '1 · moves 2 limbs', '0 · none']], ['ald_resp', ['2 · breathes deeply', '1 · limited', '0 · apneic']], ['ald_circ', ['2 · BP ±20%', '1 · ±20–50%', '0 · > ±50%']], ['ald_cons', ['2 · fully awake', '1 · arousable', '0 · not responding']], ['ald_o2', ['2 · > 92% on air', '1 · needs O₂', '0 · < 90% on O₂']]];
const ALD_L: Record<string, string> = { ald_act: 'Activity', ald_resp: 'Respiration', ald_circ: 'Circulation', ald_cons: 'Consciousness', ald_o2: 'Oxygen saturation' };
const aldScore = (v: (id: string) => any) => ALD.every(([k]) => v(k)) ? ALD.reduce((n, [k]) => n + parseInt(String(v(k)), 10), 0) : undefined;
export const PACU_DEF: Def = { st: 'pacu', bench: 'pacu', here: 'pacu', title: 'PACU', storeKey: 'asc108-pacu', testId: 'a81-bench-pacu', notes: 'PACU',
  phases: [
    { id: 'arrival', title: 'Arrival & hand-off', when: 'Patient arrives from the OR', items: [
      { id: 'ev_pacuIn', label: 'PACU arrival', kind: 'time', event: 'pacuIn', req: true },
      { id: 'report_from', label: 'Report received from', kind: 'select', roles: ['Anesthesiologist', 'CRNA', 'Circulating RN'], req: true },
      { id: 'report', label: 'Hand-off received: procedure, anesthesia, EBL, meds given, allergies, concerns', kind: 'check', req: true },
      { id: 'airway', label: 'Airway', kind: 'radio', opts: ['Natural', 'Oral airway', 'LMA in place'], req: true },
      { id: 'o2', label: 'Oxygen', kind: 'radio', opts: ['Room air', 'Nasal cannula', 'Face mask'], req: true }] },
    { id: 'vitals', title: 'Vitals every 15 minutes', when: 'Flowsheet', items: [{ id: 'p_flow', label: '', kind: 'panel', render: c => <Flowsheet c={c} /> }] },
    { id: 'comfort', title: 'Pain, nausea & site', when: 'Treat and reassess', items: [
      { id: 'pain', label: 'Pain score (0–10)', kind: 'radio', opts: PAIN, req: true }, { id: 'pain_tx', label: 'Pain treatment', kind: 'radio', opts: ['None needed', 'Medicated per orders', 'Non-drug measures'] },
      { id: 'nausea', label: 'Nausea / vomiting', kind: 'radio', opts: ['None', 'Nausea · treated', 'Vomiting · treated'], req: true },
      { id: 'dressing', label: 'Dressing', kind: 'radio', opts: ['Dry and intact', 'Drainage noted', 'Bleeding · surgeon notified'], req: true },
      { id: 'void', label: 'Voided', kind: 'radio', opts: ['Yes', 'Not yet', 'N/A'] }, { id: 'iv_fluids', label: 'IV fluids in PACU', kind: 'text', quick: ['None', 'LR 250 mL', 'LR 500 mL'] }] },
    { id: 'orders', title: 'Post-op orders', when: 'Standing orders and active orders', items: [
      { id: 'p_post', label: '', kind: 'panel', render: c => <StandingChecklist c={c} phase="post" />, done: c => listDone(c.id, c.surgeon, 'post') },
      { id: 'p_active', label: '', kind: 'panel', render: c => <ActiveOrdersCard c={c} phases={['pacu', 'postop']} /> }] },
    { id: 'aldrete', title: 'Aldrete & discharge criteria', when: 'Ready for phase 2 / home', items: [
      ...ALD.map(([k, o]) => ({ id: k, label: ALD_L[k], kind: 'radio' as const, opts: o, req: true })),
      { id: 'criteria', label: 'Discharge criteria met: stable vitals, oriented, pain and nausea controlled, ambulating, site OK', kind: 'check', req: true },
      { id: 'ev_pacuOut', label: 'PACU discharge time', kind: 'time', event: 'pacuOut' }] }],
  script: [['Anesthesia: This is {name}, {procedure}, general with an LMA, blood loss minimal, got ondansetron, no allergies, no concerns.', { report: true, airway: 'Natural', o2: 'Nasal cannula' }], ['PACU nurse: Any pain, zero to ten?', {}], ['Patient: About a three.', { pain: '3', pain_tx: 'None needed' }], ['PACU nurse: Any nausea?', {}], ['Patient: No.', { nausea: 'None' }], ['PACU nurse: Dressing dry and intact.', { dressing: 'Dry and intact' }]],
  sync: (c, v, actor) => { let x = S.caseById(c.id)!; const sc = aldScore(v); if (sc !== undefined && x.d.aldrete?.score !== sc) x = S.setValue(x, 'aldrete', { score: sc, by: actor.name, at: now() }, actor.name, actor.role, `Aldrete score ${sc}`);
    if (v('criteria') && !x.d.criteria) S.setValue(x, 'criteria', { by: actor.name, at: now() }, actor.name, actor.role, 'Discharge criteria met'); },
  signs: [{ id: 'pacu', label: 'Sign PACU record', roles: S.NURSE_ROLES, statement: (c, n) => `I recorded and reviewed the PACU record for ${nm(c)}.${n ? ` ${n} item(s) are open and become flags.` : ''}`,
    onSigned: (c, values, s, open) => { S.setValue(S.caseById(c.id)!, 'pacuRecord', { by: s.name, at: s.at, open, values }, s.name, s.role, 'PACU record signed with PIN'); } }],
  footer: (c, x) => <button type="button" className="a8-btn" onClick={() => { x.close(); window.setTimeout(() => openBench('discharge' as any, c.id), 50); }} data-testid="n8-open-discharge">Open discharge</button> };

/* ---------------- Discharge ---------------- */
export const DISCHARGE_DEF: Def = { st: 'discharge', bench: 'discharge', here: 'discharge', title: 'Discharge', storeKey: 'asc108-discharge', testId: 'a81-bench-discharge', notes: 'Discharge',
  phases: [
    { id: 'escort', title: 'Escort & ride home', when: 'Who takes the patient home', items: [
      { id: 'escort', label: 'Responsible adult present', kind: 'radio', opts: ['Yes', 'No · do not discharge'], req: true },
      { id: 'escort_name', label: 'Escort', kind: 'text', dflt: c => c.d.adult?.name, req: true },
      { id: 'escort_phone', label: 'Escort phone', kind: 'text', dflt: c => c.d.adult?.phone }] },
    { id: 'ready', title: 'Ready to go home', when: 'Final check', items: [
      { id: 'vitals_ok', label: 'Vitals stable, oriented, pain and nausea controlled', kind: 'check', req: true },
      { id: 'ambulating', label: 'Ambulating with steady gait', kind: 'radio', opts: ['Yes', 'With assistance', 'Wheelchair to car'], req: true },
      { id: 'iv_out', label: 'IV removed, catheter intact', kind: 'check', req: true },
      { id: 'site_ok', label: 'Dressing dry and intact', kind: 'check', req: true },
      { id: 'belongings_back', label: 'Belongings returned', kind: 'check' }] },
    { id: 'instructions', title: 'Instructions & prescriptions', when: 'Reviewed with the patient and escort', items: [
      { id: 'p_instr', label: '', kind: 'panel', render: (c, x) => <Discharge82 c={c} onClose={x.close} part="instructions" />, done: c => !!S.caseById(c.id)?.d.instructions }] }],
  script: [['PACU nurse: Who is driving you home?', {}], ['Patient: My sister Dana is here.', { escort: 'Yes' }], ['PACU nurse: Vitals look good, you are walking well, IV is out and the dressing is dry.', { vitals_ok: true, ambulating: 'Yes', iv_out: true, site_ok: true }]],
  tail: (c, close) => <section className="or6-phase n8-sigs"><header><span className="n">✎</span><div><h3>Signatures & discharge</h3><span className="w">Nurse, patient or adult, anesthesia</span></div></header><div className="or6-items"><Discharge82 c={c} onClose={close} part="signatures" /></div></section>,
  signs: [] };

export const NATIVE_DEFS: Record<string, Def> = { arrival: FRONT_DEF, verify: VERIFY_DEF, nursing: NURSING_DEF, anesthesia: ANES_DEF, surgeon: SURGEON_DEF, pacu: PACU_DEF, discharge: DISCHARGE_DEF };
