/* ASC.Vityls · source of the next-day schedule email (src/os/notify/dailySchedule): tomorrow's cases, one email per surgeon. */
import { medRepo } from '../../med/record';
import * as S from '../asc8/store';
import type { Source } from '../../os/notify/dailySchedule';

export const ASC_SCHEDULE_SOURCE: Source = { noun: ['case', 'cases'], title: 'surgery schedule',
  collect: date => { const by = new Map<string, ReturnType<Source['collect']>[number]['rows']>();
    S.cases().filter(c => c.date === date && !c.d?.cancelled).forEach(c => by.set(c.surgeon, [...(by.get(c.surgeon) || []), { time: c.time, patient: medRepo.patient(c.pid)?.name || 'Patient', what: `${c.procedure}${c.side && !new RegExp(c.side, 'i').test(c.procedure) ? ` (${c.side})` : ''}`, place: `${c.room} · anesthesia: ${c.anesthesia || 'TBD'}`, note: `${c.durationMin} min` }]));
    return [...by.entries()].map(([provider, rows]) => ({ provider, rows })); } };
