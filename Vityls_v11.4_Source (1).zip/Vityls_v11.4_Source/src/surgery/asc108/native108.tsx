/* ASC.Vityls · the ASC edition of the core station engine (src/os/station/engine.tsx).
 * Since v11 the engine lives in Vityls OS and is shared with Surgery and Medical; this file is the ASC adapter: it loads
 * an ASC case, draws the ASC journey bar and case card, files uploads, merges facility checklist items, stamps OR/PACU
 * events, raises flags and supplies ASC's "Before you sign". Type names and exports are unchanged for ASC code. */
import React from 'react';
import { medRepo } from '../../med/record';
import * as A from '../asc8/logic';
import * as S from '../asc8/store';
import { CaseCard } from '../asc82/common';
import { JourneyBar } from '../asc88/journey88';
import { CaptureUpload } from '../asc10/flow10';
import { StationNotes } from '../asc106/stations106';
import { StationCtx, BeforeSign } from '../asc106/slots106';
import { facilityFor, fillLinked, type StKey } from '../asc107/checklists107';
import * as E from '../../os/station/engine';

export type Kind = E.Kind;
export type Item = E.Item<A.AscCase> & { event?: A.EventKey };
export type Phase = E.Phase<A.AscCase>;
export type Val = E.Val; export type Rec = E.Rec; export type Signer = E.Signer;
export type SignDef = E.SignDef<A.AscCase>;
export type Def = Omit<E.Def<A.AscCase>, 'st' | 'notes'> & { st: StKey; notes?: 'Pre-op nursing' | 'OR' | 'PACU' | 'Discharge' };
export const COUNT_ROWS = E.COUNT_ROWS; export const COUNT_COLS = E.COUNT_COLS;
export const recOf = E.recOf; export const labelOf = E.labelOf;
export const allergyText = (c: A.AscCase) => { const a = medRepo.patient(c.pid)?.allergies || []; return a.length ? a.join('; ') : 'NKDA'; };

const stationOf = (st: string) => (st === 'nursing' ? 'preop' : st === 'discharge' ? 'pacu' : st) as A.Station;
export const ASC_ADAPTER: E.Adapter<A.AscCase> = {
  get: id => S.caseById(id), date: c => c.date, place: c => c.room, time: c => c.time,
  fill: (s, c) => s.replace(/\{procedure\}/g, c.procedure.toLowerCase()).replace(/\{allergy\}/g, allergyText(c) === 'NKDA' ? 'none known' : allergyText(c)).replace(/\{surgeon\}/g, c.surgeon.replace(/,.*$/, '').split(' ').slice(-1)[0]),
  journey: (c, def, close) => <JourneyBar c={c} here={def.here as any} onLeave={close} />,
  card: (c, def) => <CaseCard c={c} station={stationOf(def.st)} />,
  upload: (c, def) => <CaptureUpload c={c} station={def.title} />,
  wrap: (c, def, children) => <StationCtx.Provider value={{ c, bench: def.bench }}>{children}</StationCtx.Provider>,
  notes: (c, which) => <StationNotes c={c} station={which as any} />,
  before: (_c, _def, children) => <BeforeSign confirm={false} bank={false}>{children}</BeforeSign>,
  facility: (c, st) => facilityFor(c, st as StKey, true), fillLinked: (c, f, v) => fillLinked(c, f, v),
  events: c => c.events as any, recordEvent: (c, k, v, actor, why) => { S.recordEvent(S.caseById(c.id)!, k as A.EventKey, v, actor.name, actor.role, why); },
  nowTime: () => S.nowTime(),
  flag: (c, def, s, open) => { S.raiseFlag({ from: s.name, fromRole: s.role, to: (def.st === 'nursing' ? 'preop' : def.st === 'discharge' ? 'pacu' : def.st === 'front' ? 'front' : def.st) as any, pid: c.pid, caseId: c.id, text: `${def.title} signed with ${open.length} open item(s): ${open.slice(0, 4).map(l => l.replace(/:.*$/, '')).join(', ')}` } as any); },
  auditKey: c => `asc8:${c.id}`, sigCase: c => c.id,
  closeTestId: def => def.st === 'or' ? 'a8-close' : 'a81-close',
};

/** The ASC station: the core engine with the ASC adapter. */
export const NativeStation: React.FC<{ def: Def; cid: string; onClose: (m?: string) => void; pick?: A.AscCase[]; onPick?: (cid: string) => void }> = ({ def, cid, onClose, pick, onPick }) =>
  <E.StationEngine def={{ ...(def as unknown as E.Def<A.AscCase>), adapter: ASC_ADAPTER }} id={cid} onClose={onClose} pick={pick} onPick={onPick} />;
