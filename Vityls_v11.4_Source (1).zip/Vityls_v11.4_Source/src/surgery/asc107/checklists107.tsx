/* ASC.Vityls v10.7 · Station checklists: standard items (locked) + facility items, linked to the form library.
 * - Forms stay the source of what is captured (form library + Form Studio). Assigning a form to a station puts its
 *   practice-defined fields on that station's checklist automatically ("from form"); the checklist editor is optional
 *   fine-tuning: move to a phase/section, conditions (room, surgeon, procedure/CPT, anesthesia type, age), required,
 *   control, quick values and Talk phrases. Fields can also be picked one by one from any library form, or created here.
 * - Published versions are numbered; a case keeps the version it first opened at a station.
 * - Every answer also fills the linked form field, so the form prints complete.
 * Storage (device, test build): asc107-checklists, asc107-pins, answers in asc10-answers / asc106-or. Fictional data. */
import React, { useMemo, useState } from 'react';
import { Lock, GripVertical, Plus, FileText, Mic, ChevronUp, ChevronDown, X, Check } from 'lucide-react';
import { medRepo, ageFrom, uid } from '../../med/record';
import { useActor, useMedTick } from '../../med/ui';
import { repo } from '../../v6/dataLayer';
import { svRead, svWrite } from '../store';
import { peopleIn } from '../staff';
import * as A from '../asc8/logic';
import * as S from '../asc8/store';
import { anesType } from '../asc90/today90';
import { DEMO } from '../asc10/demo';
import { isAscEd, isMedical } from '../../edition';
import type { MedVisit } from '../../med/record';
import { stationPlan } from '../../v7/myForms';
import { VITYLS_FORM_CATALOG, type WorkflowKey } from '../../data/formWorkspaceCatalog';
import * as FL from '../v09/formLib';
import { NURSE_SECTIONS, AIRWAY } from '../asc82/pure';
import { PHASES as OR_STD } from '../asc106/or106';
import './checklists107.css';

/* ---------------- model ---------------- */
export type StKey = 'front' | 'nursing' | 'anesthesia' | 'surgeon' | 'or' | 'pacu' | 'discharge' | OfficeKey;
/** v11.1: the office stations of Surgery.Vityls and Medical.Vityls (same ids as the station definitions in office11). */
export type OfficeKey = 'office-front' | 'office-nurse' | 'office-provider' | 'office-checkout';
const OFFICE_STATIONS: { k: StKey; label: string; wk: WorkflowKey | null; who: string }[] = [
  { k: 'office-front', label: 'Check-in', wk: 'frontOffice', who: 'Front desk' }, { k: 'office-nurse', label: 'Nurse / MA', wk: 'nursing', who: 'Medical assistant, RN' },
  { k: 'office-provider', label: isMedical ? 'Doctor' : 'Surgeon', wk: 'surgeon', who: isMedical ? 'Doctor, NP, PA' : 'Surgeon, NP, PA' }, { k: 'office-checkout', label: 'Checkout', wk: null, who: 'Front desk' }];
/** Steps of each office station (ids match office11/stations.tsx), so facility items can be placed inside a step. */
export const OFFICE_PHASES: Partial<Record<StKey, [string, string][]>> = {
  'office-front': [['identity', 'Who is here'], ['forms', 'Portal forms & registration'], ['cards', 'ID & insurance cards'], ['arrival', 'Arrival & check-in'], ['pay', 'Payment']],
  'office-nurse': [['reason', 'Reason for the visit'], ['vitals', 'Vital signs'], ['safety', 'Allergies & medications'], ['screen', 'Screening'], ['note', 'Note for the provider']],
  'office-provider': isMedical ? [['ready', 'Before you go in'], ['scribe', 'Scribe & visit note'], ['forms', 'Forms'], ['plan', 'Plan & follow-up']] : [['ready', 'Before you go in'], ['scribe', 'Scribe & consult note'], ['media', 'Body charts & photos'], ['quote', 'Price quote'], ['forms', 'Forms'], ['decision', 'Plan & decision']],
  'office-checkout': [['close', 'Close the visit'], ['leave', 'Before the patient leaves']] };
const ASC_STATIONS: { k: StKey; label: string; wk: WorkflowKey | null; who: string }[] = [
  { k: 'front', label: 'Check-in', wk: 'frontOffice', who: 'Front desk' }, { k: 'nursing', label: 'Pre-op nursing', wk: 'nursing', who: 'Pre-op RN' },
  { k: 'anesthesia', label: 'Anesthesia', wk: 'anesthesia', who: 'Anesthesiologist, CRNA' }, { k: 'surgeon', label: 'Surgeon', wk: 'surgeon', who: 'Surgeon' },
  { k: 'or', label: 'OR · intra-op record', wk: 'orTeam', who: 'Circulating RN' }, { k: 'pacu', label: 'PACU', wk: 'pacu', who: 'PACU RN' }, { k: 'discharge', label: 'Discharge', wk: null, who: 'PACU RN' }];
/** The stations of this edition: ASC's seven, or the office's four. */
export const STATIONS = isAscEd ? ASC_STATIONS : OFFICE_STATIONS;
export const BENCH_ST: Record<string, StKey> = { arrival: 'front', front: 'front', nursing: 'nursing', preop: 'nursing', anesthesia: 'anesthesia', surgeon: 'surgeon', or: 'or', pacu: 'pacu', discharge: 'discharge' };
export type Kind = 'check' | 'radio' | 'multi' | 'dropdown' | 'select' | 'number' | 'text' | 'time';
export const KIND_LABEL: Record<Kind, string> = { check: 'Checkbox', radio: 'Single', multi: 'Multiple', dropdown: 'Dropdown', select: 'Staff', number: 'Number', text: 'Text', time: 'Time stamp' };
export interface Cond { rooms?: string[]; surgeons?: string[]; procedures?: string; anes?: string[]; minAge?: number; maxAge?: number }
export interface FacItem { id: string; station: StKey; group: string; label: string; kind: Kind; opts?: string[]; unit?: string; quick?: string[]; req: boolean; cond?: Cond; talk?: string[]; link?: { file: string; field: string; title: string }; src: 'manual' | 'form'; roles?: string[]; edited?: boolean }
interface Ver { v: number; items: FacItem[]; at: string; by: string; note?: string }
interface StDoc { versions: Ver[]; draft?: FacItem[]; draftAt?: string }
type Store = Partial<Record<StKey, StDoc>>;
const K = 'asc107-checklists'; const PK = 'asc107-pins';
const read = (): Store => seed(svRead<Store | null>(K, null));
const write = (s: Store) => { svWrite(K, s); window.dispatchEvent(new Event('vityls-med-updated')); };
const latest = (d?: StDoc) => d?.versions.length ? d.versions[d.versions.length - 1] : undefined;

/** OR phases (ids must match or106) and default groups for the other stations. */
export const OR_PHASES: [string, string][] = [['signin', 'Sign-in'], ['room', 'Room, team & positioning'], ['timeout', 'Time-out'], ['intraop', 'Intra-op'], ['counts', 'Counts'], ['signout', 'Sign-out & closure'], ['handoff', 'Hand-off to PACU']];
export const groupsOf = (st: StKey, items: FacItem[]) => st === 'or' ? OR_PHASES.map(([id, t]) => ({ id, title: t })) : OFFICE_PHASES[st] ? [...OFFICE_PHASES[st]!.map(([id, t]) => ({ id, title: t })), ...Array.from(new Set(['Facility items', ...items.filter(i => i.station === st && !OFFICE_PHASES[st]!.some(x => x[0] === i.group)).map(i => i.group)])).map(g => ({ id: g, title: g }))] : Array.from(new Set(['Facility items', ...items.filter(i => i.station === st).map(i => i.group)])).map(g => ({ id: g, title: g }));

/** Built-in items each station already asks (shown locked in the editor). OR's come from or106 PHASES at runtime. */
export const STANDARD: Partial<Record<StKey, { group: string; items: string[] }[]>> = {
  front: [{ group: 'Check-in', items: ['ID and insurance cards captured', 'At-home forms signed', 'Financial agreement signed', 'Payment or deposit collected', 'Ride home and caregiver confirmed'] }],
  nursing: NURSE_SECTIONS.map(s => ({ group: s.title, items: s.items.map(i => i.label) })),
  anesthesia: [{ group: 'Airway evaluation', items: AIRWAY.map(a => a[1]) }, { group: 'ASA class & focused exam', items: ['ASA class', 'Heart', 'Lungs', 'Mental status', 'NPO confirmed', 'IV patent'] }, { group: 'Anesthesia type & technique', items: ['Type', 'Technique', 'Plan notes'] }, { group: 'At induction', items: ['Immediate pre-induction re-evaluation'] }],
  surgeon: [{ group: 'Doctor orders', items: ['Orders as per facility protocol'] }, { group: 'Interval H&P and site marking', items: ['H&P reviewed, no interval change', 'Site marked', 'Suitable candidate / no new contraindications', 'Proceed or defer'] }, { group: 'Brief op report', items: ['Diagnoses, procedure, findings, EBL, specimens, implants, complications, condition'] }],
  pacu: [{ group: 'PACU record', items: ['Arrival report', 'Vitals flowsheet every 15 min', 'Pain and nausea', 'Aldrete score', 'Post-op orders'] }],
  discharge: [{ group: 'Discharge', items: ['Instructions drafted and reviewed', 'Prescriptions', 'Escort', 'Nurse, patient and anesthesia signatures'] }],
  'office-front': [{ group: 'Check-in', items: ['Identity confirmed (name, DOB, photo ID)', 'Portal forms and registration reviewed', 'ID and insurance cards', 'Arrival and check-in times', 'Who is with the patient', 'Best phone number', 'Payment'] }],
  'office-nurse': [{ group: 'Nurse / MA intake', items: ['Reason for the visit', 'Pain (0–10)', 'Blood pressure, pulse, respiratory rate, SpO₂, temperature, height, weight', 'Allergies confirmed', 'Medications reviewed', 'Preferred pharmacy', 'Tobacco, falls, mood screen (PHQ-2)', 'Note for the provider'] }],
  'office-provider': [{ group: 'Provider', items: ['Nightingale summary of the intake', 'Ambient scribe and signed note', ...(isMedical ? ['Follow-up', 'Orders placed today', 'Plan explained'] : ['Body charts and photos', 'Price quote', 'Patient decision'])] }],
  'office-checkout': [{ group: 'Checkout', items: ['Follow-up, balance and instructions', 'Visit summary sent', 'Next appointment', 'After-hours contact explained'] }],
};

function seed(s: Store | null): Store {
  if (s) return s; const at = new Date().toISOString(); const by = 'Practice Administrator';
  const items: FacItem[] = !isAscEd ? [
    { id: 'fac-o-interp', station: 'office-front', group: 'Facility items', label: 'Interpreter needed', kind: 'radio', opts: ['No', 'Yes · in person', 'Yes · phone / video'], req: false, talk: ['interpreter', 'spanish', 'translate'], src: 'manual' },
    { id: 'fac-o-foot', station: 'office-nurse', group: 'screen', label: 'Diabetic foot check (monofilament)', kind: 'radio', opts: ['Normal both feet', 'Abnormal · tell the provider', 'Declined'], req: true, cond: { procedures: 'diabetes, chronic care' }, talk: ['foot', 'monofilament'], src: 'manual' },
  ] : DEMO ? [
    { id: 'fac-laser', station: 'or', group: 'timeout', label: 'Laser safety', kind: 'multi', opts: ['Goggles on (patient & staff)', 'Signage posted', 'Wet towels on field', 'Extinguisher ready'], req: true, cond: { rooms: ['OR 3'] }, talk: ['laser', 'goggles', 'wet towels'], src: 'manual' },
    { id: 'fac-tq', station: 'or', group: 'room', label: 'Tourniquet pressure', kind: 'number', unit: 'mmHg', quick: ['250', '300'], req: true, cond: { surgeons: ['Sam Patel, MD'], procedures: 'carpal, 64721' }, talk: ['tourniquet'], src: 'manual' },
    { id: 'fac-interp', station: 'nursing', group: 'Facility items', label: 'Interpreter needed', kind: 'radio', opts: ['No', 'Yes · in person', 'Yes · phone / video'], req: false, src: 'manual' },
  ] : [];
  const st: Store = {}; (isAscEd ? ['or', 'nursing'] as StKey[] : ['office-front', 'office-nurse'] as StKey[]).forEach(k => { st[k] = { versions: [{ v: 1, items: items.filter(i => i.station === k), at, by, note: 'Starter facility items (demo)' }] }; });
  quiet(K, st); return st;
}
/** Render-time writes (seed, pin) skip the store ping so no other component updates while this one renders. */
function quiet(k: string, v: unknown) { try { localStorage.setItem(`vityls:surgery:${k}`, JSON.stringify(v)); } catch { /* storage full */ } }

/* ---------------- fields that come from assigned forms ---------------- */
const SKIP = new Set(['signature', 'initials', 'heading', 'instruction', 'prefill', 'grid']);
const bundled = new Set(VITYLS_FORM_CATALOG.filter(f => f.category !== 'Custom').map(f => f.file));
const names = (d: FL.FormDef) => new Set(d.sections.flatMap(s => s.fields.map(f => f.name)));
const origCache: Record<string, Set<string>> = {};
const baseNames = (file: string) => origCache[file] || (origCache[file] = (() => { try { return names(FL.originalDef(file)); } catch { return new Set<string>(); } })());
const origFields: Record<string, Map<string, FL.Field>> = {};
const baseFields = (file: string) => origFields[file] || (origFields[file] = (() => { try { return new Map(FL.originalDef(file).sections.flatMap(s => s.fields).map(f => [f.name, f] as [string, FL.Field])); } catch { return new Map<string, FL.Field>(); } })());
/** v10.8: an original library field the practice reworded or whose options it changed (same field name, new wording). */
const changed = (file: string, f: FL.Field) => { const o = baseFields(file).get(f.name); return !!o && ((o.label || '').trim() !== (f.label || '').trim() || JSON.stringify(o.options || []) !== JSON.stringify(f.options || []) || o.type !== f.type); };
export const kindOf = (t: FL.FieldType, n: number): Kind | null => SKIP.has(t) ? null : t === 'checkbox' ? 'check' : t === 'yesno' ? 'radio' : t === 'single' ? (n <= 6 ? 'radio' : 'dropdown') : t === 'dropdown' ? (n <= 6 ? 'radio' : 'dropdown') : t === 'multi' ? 'multi' : t === 'number' ? 'number' : 'text';
export function formItem(file: string, title: string, f: FL.Field, st: StKey, group: string): FacItem | null {
  const k = kindOf(f.type, (f.options || []).length); if (!k) return null;
  return { id: `form:${file}:${f.name}`, station: st, group, label: f.label || f.name, kind: k, opts: f.type === 'yesno' ? ['Yes', 'No'] : f.options?.length ? f.options : undefined, req: !!f.required, src: 'form', link: { file, field: f.name, title } };
}
/** Practice-defined fields on forms assigned to a station: every field of a custom form, or fields a practice added to a library form. */
export function autoItems(st: StKey): FacItem[] {
  const wk = STATIONS.find(s => s.k === st)?.wk; if (!wk) return [];
  const p = stationPlan(wk); const files = Array.from(new Set([...p.required, ...p.asNeeded]));
  return files.flatMap(file => { const e = FL.entry(file); const custom = !bundled.has(file) || /^practice-/.test(file);
    const def = FL.publishedDef(file); if (!def) return []; /* v10.8: only published versions reach stations; drafts stay in the editor */
    const base = custom ? (e?.clonedFrom && e.clonedFrom !== 'Blank_Custom_Form.html' ? baseNames(e.clonedFrom) : new Set<string>()) : baseNames(file);
    const title = def.title || FL.titleOf(file); const group = st === 'or' ? 'intraop' : title;
    const src = custom ? (e?.clonedFrom && e.clonedFrom !== 'Blank_Custom_Form.html' ? e.clonedFrom : '') : file;
    return def.sections.flatMap(s => s.fields).filter(f => !base.has(f.name) || (src && changed(src, f))).map(f => { const it = formItem(file, title, f, st, group); return it && base.has(f.name) ? { ...it, edited: true } : it; }).filter(Boolean) as FacItem[]; });
}

/* ---------------- runtime ---------------- */
export const published = (st: StKey) => latest(read()[st]);
const pins = () => svRead<Record<string, number>>(PK, {});
/** The version a case uses at a station: pinned on first use, so later edits never change a started record. */
export function versionFor(cid: string, st: StKey, pin = false): Ver | undefined {
  const d = read()[st]; const key = `${cid}|${st}`; const p = pins()[key];
  const v = (p && d?.versions.find(x => x.v === p)) || latest(d);
  if (pin && v && p !== v.v) quiet(PK, { ...pins(), [key]: v.v });
  return v;
}
/** v11.1: conditions for an office visit (room, provider, visit type / reason, age). */
export function matchesVisit(v: MedVisit, cond?: Cond): boolean {
  if (!cond) return true; const p = medRepo.patient(v.patientId); const age = p?.dob ? ageFrom(p.dob) : undefined;
  if (cond.rooms?.length && !cond.rooms.includes(v.room)) return false;
  if (cond.surgeons?.length && !cond.surgeons.includes(v.provider)) return false;
  if (cond.procedures?.trim()) { const keys = cond.procedures.toLowerCase().split(/[,;]+/).map(x => x.trim()).filter(Boolean); const hay = `${v.visitType} ${v.reason || ''}`.toLowerCase(); if (!keys.some(k => hay.includes(k))) return false; }
  if (cond.minAge != null && (age == null || age < cond.minAge)) return false;
  if (cond.maxAge != null && (age == null || age > cond.maxAge)) return false;
  return true;
}
export function facilityForVisit(v: MedVisit, st: StKey, pin = false): FacItem[] {
  const ver = versionFor(v.id, st, pin); const items = (ver?.items || []).filter(i => i.station === st);
  const ids = new Set(items.map(i => i.id)); const auto = autoItems(st).filter(i => !ids.has(i.id));
  return [...items.map(fresh), ...auto].filter(i => matchesVisit(v, i.cond));
}
export function matches(c: A.AscCase, cond?: Cond): boolean {
  if (!cond) return true; const p = medRepo.patient(c.pid); const age = p?.dob ? ageFrom(p.dob) : undefined;
  if (cond.rooms?.length && !cond.rooms.includes(c.room)) return false;
  if (cond.surgeons?.length && !cond.surgeons.includes(c.surgeon)) return false;
  if (cond.procedures?.trim()) { const keys = cond.procedures.toLowerCase().split(/[,;]+/).map(x => x.trim()).filter(Boolean); const hay = `${c.procedure} ${c.cpt || ''}`.toLowerCase(); if (!keys.some(k => hay.includes(k))) return false; }
  if (cond.anes?.length && !cond.anes.includes(anesType(c))) return false;
  if (cond.minAge != null && (age == null || age < cond.minAge)) return false;
  if (cond.maxAge != null && (age == null || age > cond.maxAge)) return false;
  return true;
}
/** Facility items shown for a case at a station (published version + auto items from assigned forms not overridden). */
/** v10.8: a facility item linked to a form field shows the field's current published wording and options. */
const fresh = (i: FacItem): FacItem => { if (!i.link) return i; const d = FL.publishedDef(i.link.file); const f = d?.sections.flatMap(s => s.fields).find(x => x.name === i.link!.field); if (!f) return i;
  const k = kindOf(f.type, (f.options || []).length); return { ...i, label: f.label || i.label, opts: f.type === 'yesno' ? ['Yes', 'No'] : f.options?.length ? f.options : i.opts, kind: k || i.kind }; };
export function facilityFor(c: A.AscCase, st: StKey, pin = false): FacItem[] {
  const v = versionFor(c.id, st, pin); const items = (v?.items || []).filter(i => i.station === st);
  const ids = new Set(items.map(i => i.id)); const auto = autoItems(st).filter(i => !ids.has(i.id));
  return [...items.map(fresh), ...auto].filter(i => matches(c, i.cond));
}
export const condText = (cond?: Cond) => { if (!cond) return ''; const p: string[] = []; if (cond.rooms?.length) p.push(cond.rooms.join(', ')); if (cond.surgeons?.length) p.push(cond.surgeons.map(s => `Dr. ${s.replace(/,.*$/, '').split(' ').slice(-1)[0]}`).join(', ')); if (cond.procedures?.trim()) p.push(cond.procedures); if (cond.anes?.length) p.push(cond.anes.join(', ')); if (cond.minAge != null || cond.maxAge != null) p.push(`age ${cond.minAge ?? 0}–${cond.maxAge ?? '∞'}`); return p.join(' · '); };
/** Write an answer into the linked form field so the form prints complete. */
export function fillLinked(c: A.AscCase, it: FacItem, value: any) {
  if (!it.link) return; const rec = repo.getForm(c.visitId, it.link.file); if ((rec as any).status === 'locked') return;
  const v = Array.isArray(value) ? value.join(', ') : typeof value === 'boolean' ? (value ? 'Yes' : '') : String(value ?? '');
  repo.saveForm({ ...rec, values: { ...rec.values, [it.link.field]: v }, labels: { ...rec.labels, [it.link.field]: it.label } } as any);
}

/* ---------------- one control, used by every station ---------------- */
export const FacControl: React.FC<{ it: FacItem; v: any; on: (v: any) => void; locked?: boolean; tid?: string }> = ({ it, v, on, locked, tid }) => {
  const id = tid || `fac-${it.id}`; const [t, setT] = useState<string>(v ?? ''); React.useEffect(() => setT(v ?? ''), [v]);
  switch (it.kind) {
    case 'check': return <button type="button" role="checkbox" aria-checked={!!v} className={`k7-check ${v ? 'on' : ''}`} disabled={locked} onClick={() => on(!v)} data-testid={id}><span className="box">{v ? <Check size={15} /> : null}</span><span>{it.label}</span></button>;
    case 'radio': return <div className="k7-seg" role="radiogroup" aria-label={it.label}>{(it.opts || []).map(o => <button key={o} type="button" role="radio" aria-checked={v === o} className={v === o ? 'on' : ''} disabled={locked} onClick={() => on(o)} data-testid={`${id}-${o}`}>{o}</button>)}</div>;
    case 'multi': { const arr: string[] = Array.isArray(v) ? v : typeof v === 'string' && v ? v.split(/\s*,\s*/) : []; return <div className="k7-chips">{(it.opts || []).map(o => <button key={o} type="button" aria-pressed={arr.includes(o)} className={arr.includes(o) ? 'on' : ''} disabled={locked} onClick={() => on(arr.includes(o) ? arr.filter(x => x !== o) : [...arr, o])} data-testid={`${id}-${o}`}>{arr.includes(o) && <Check size={13} />}{o}</button>)}</div>; }
    case 'dropdown': return <select className="k7-in" value={v || ''} disabled={locked} onChange={e => on(e.target.value)} data-testid={id}><option value="">Choose…</option>{(it.opts || []).map(o => <option key={o}>{o}</option>)}</select>;
    case 'select': { const opts = Array.from(new Set([...(v ? [v] : []), ...peopleIn(it.roles || ['Circulating RN', 'RN', 'Pre-op RN', 'PACU RN', 'Scrub tech']).map(x => x.name)])); return <select className="k7-in" value={v || ''} disabled={locked} onChange={e => on(e.target.value)} data-testid={id}><option value="">Choose…</option>{opts.map(o => <option key={o}>{o}</option>)}</select>; }
    case 'number': return <div className="k7-num">{(it.quick || []).length > 0 && <div className="k7-chips">{it.quick!.map(q => <button key={q} type="button" className={String(v) === q ? 'on' : ''} disabled={locked} onClick={() => on(q)} data-testid={`${id}-q-${q}`}>{q}{it.unit ? ` ${it.unit}` : ''}</button>)}</div>}<span className="k7-unit"><input className="k7-in sm" inputMode="decimal" value={(it.quick || []).includes(String(t)) ? '' : t} placeholder={(it.quick || []).length ? 'Other' : ''} disabled={locked} onChange={e => setT(e.target.value.replace(/[^\d.]/g, ''))} onBlur={() => t !== (v ?? '') && on(t)} data-testid={id} />{it.unit && <span>{it.unit}</span>}</span></div>;
    case 'time': return v ? <span className="k7-time"><b>{String(v).replace(/^0/, '')}</b>{!locked && <button type="button" className="k7-clear" onClick={() => on("")}>Clear</button>}</span> : <button type="button" className="k7-stamp" disabled={locked} onClick={() => on(S.nowTime())} data-testid={id}>Stamp now</button>;
    default: return <div className="k7-txt">{(it.quick || []).length > 0 && <div className="k7-chips">{it.quick!.map(q => <button key={q} type="button" className={v === q ? 'on' : ''} disabled={locked} onClick={() => on(q)}>{q}</button>)}</div>}<input className="k7-in" value={t} placeholder="Type…" disabled={locked} onChange={e => setT(e.target.value)} onBlur={() => t !== (v ?? '') && on(t)} data-testid={id} /></div>;
  }
};
export const filledV = (it: FacItem, v: any) => it.kind === 'multi' ? (Array.isArray(v) ? v.length > 0 : !!v) : v !== undefined && v !== null && v !== '' && v !== false;
export const FacTag: React.FC<{ it: FacItem }> = ({ it }) => <><span className="k7-tag fac" title={it.link ? `Fills ${it.link.title}${it.edited ? ' · wording edited by the practice' : ''}` : 'Added by the facility'}>{it.src === 'form' ? (it.edited ? 'Edited in form' : 'From form') : 'Facility'}</span>{it.cond && condText(it.cond) && <span className="k7-tag why">{condText(it.cond)}</span>}</>;

/* ---------------- editor (Practice settings › Station checklists) ---------------- */
const BLANK = (st: StKey, group: string): FacItem => ({ id: uid('fac'), station: st, group, label: 'New item', kind: 'check', req: false, src: 'manual' });
const ANES = ['General', 'MAC', 'Regional', 'Local'];

export const ChecklistsPage: React.FC = () => {
  useMedTick(); const [actor] = useActor(); const [st, setSt] = useState<StKey>(isAscEd ? 'or' : 'office-nurse'); const [sel, setSel] = useState<string>(''); const [grp, setGrp] = useState<string>(''); const [pick, setPick] = useState(false); const [msg, setMsg] = useState('');
  const store = read(); const doc = store[st] || { versions: [] }; const pub = latest(doc); const items = doc.draft ?? pub?.items ?? [];
  const auto = useMemo(() => autoItems(st), [st, JSON.stringify(items.map(i => i.id))]); const ids = new Set(items.map(i => i.id)); const autoShown = auto.filter(a => !ids.has(a.id));
  const groups = groupsOf(st, [...items, ...autoShown]); const g = grp && groups.some(x => x.id === grp) ? grp : groups[0]?.id || '';
  const setDraft = (next: FacItem[]) => { const s = read(); s[st] = { ...(s[st] || { versions: [] }), draft: next, draftAt: new Date().toISOString() }; write(s); setMsg(''); };
  const upd = (id: string, patch: Partial<FacItem>) => setDraft(items.map(i => i.id === id ? { ...i, ...patch } : i));
  const move = (id: string, d: -1 | 1) => { const inG = items.filter(i => i.group === g); const ix = inG.findIndex(i => i.id === id); const sw = inG[ix + d]; if (!sw) return; const a = items.indexOf(inG[ix]), b = items.indexOf(sw); const n = items.slice(); [n[a], n[b]] = [n[b], n[a]]; setDraft(n); };
  const publish = () => { const s = read(); const d = s[st] || { versions: [] }; const v = (latest(d)?.v || 0) + 1; s[st] = { versions: [...d.versions, { v, items: d.draft ?? items, at: new Date().toISOString(), by: actor.name, note: `${(d.draft ?? items).length} facility item(s)` }] }; write(s);
    repo.audit({ caseId: 'practice', user: actor.name, role: actor.role, action: 'asc107.checklist.publish' as any, detail: `${STATIONS.find(x => x.k === st)!.label} checklist v${v} published (${(d.draft ?? items).length} facility items)` }); setMsg(`Published v${v}. Cases already started keep their version.`); };
  const discard = () => { const s = read(); if (s[st]) { s[st] = { versions: s[st]!.versions }; write(s); } setSel(''); };
  const cur = items.find(i => i.id === sel);
  const stdGroups = st === 'or' ? null : STANDARD[st] || [];
  const inGroup = items.filter(i => i.group === g); const autoInGroup = autoShown.filter(a => a.group === g);
  const orStd = st === 'or' ? OR_STD.find(p => p.id === g)?.items || [] : [];
  const surgeons = peopleIn(['Surgeon', 'Physician', 'Surgeon (MD/DO)', 'Doctor', 'Nurse practitioner']).map(p => p.name); const surgOpts = !isAscEd ? Array.from(new Set(medRepo.visits().map(v => v.provider))) : surgeons.length ? surgeons : Array.from(new Set(S.cases().map(c => c.surgeon)));

  return <div className="k7" data-testid="k7-page">
    <div className="k7-stations" role="tablist">{STATIONS.map(x => { const d = store[x.k]; const n = (d?.draft ?? latest(d)?.items ?? []).length + autoItems(x.k).filter(a => !(d?.draft ?? latest(d)?.items ?? []).some(i => i.id === a.id)).length; return <button key={x.k} type="button" role="tab" aria-selected={st === x.k} className={st === x.k ? 'on' : ''} onClick={() => { setSt(x.k); setSel(''); setGrp(''); setMsg(''); }} data-testid={`k7-st-${x.k}`}><b>{x.label}</b><span>{n} facility{d?.draft ? ' · draft' : ''}</span></button>; })}</div>
    <div className="k7-bar"><div><b>{STATIONS.find(x => x.k === st)!.label}</b><span className="k7-mu"> · {pub ? `published v${pub.v} · ${new Date(pub.at).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })} · ${pub.by}` : 'no facility items published yet'}{doc.draft ? ' · draft has changes' : ''}</span></div>
      <span style={{ flex: 1 }} />{doc.draft && <button type="button" className="k7-btn" onClick={discard} data-testid="k7-discard">Discard draft</button>}<button type="button" className="k7-btn pri" disabled={!doc.draft} onClick={publish} data-testid="k7-publish">Publish v{(pub?.v || 0) + 1}</button></div>
    {msg && <p className="k7-ok" data-testid="k7-msg">{msg}</p>}
    <div className="k7-grid">
      <aside className="k7-groups">{groups.map((x, i) => { const n = items.filter(it => it.group === x.id).length + autoShown.filter(a => a.group === x.id).length; return <button key={x.id} type="button" className={g === x.id ? 'on' : ''} onClick={() => { setGrp(x.id); setSel(''); }} data-testid={`k7-g-${i}`}><span className="n">{st === 'or' ? i + 1 : '•'}</span><span className="t">{x.title}</span>{n > 0 && <span className="c">+{n}</span>}</button>; })}
        {st !== 'or' && <button type="button" className="k7-addg" onClick={() => { const name = prompt('New section name'); if (name?.trim()) { setGrp(name.trim()); const it = BLANK(st, name.trim()); setDraft([...items, it]); setSel(it.id); } }} data-testid="k7-add-group"><Plus size={14} /> New section</button>}
        <div className="k7-legend"><span className="k7-tag std"><Lock size={11} /> Standard</span> locked: always asked, cannot be removed.<br /><span className="k7-tag fac">Facility</span> yours: add, reorder, condition, remove.<br /><span className="k7-tag fac">From form</span> fields of forms assigned to this station, added automatically.<br /><span className="k7-tag fac">Edited in form</span> library fields you reworded or gave new options.<br />Only <b>published</b> form versions reach stations; drafts stay in the form editor.</div></aside>
      <section className="k7-items">
        <header><b>{groups.find(x => x.id === g)?.title}</b><span style={{ flex: 1 }} /><button type="button" className="k7-btn sm" onClick={() => setPick(true)} data-testid="k7-pick-open"><FileText size={14} /> Pick from form library</button><button type="button" className="k7-btn sm" onClick={() => { const it = BLANK(st, g); setDraft([...items, it]); setSel(it.id); }} data-testid="k7-new"><Plus size={14} /> New item</button></header>
        {st === 'or' ? orStd.map((it: any) => <div key={it.id} className="k7-it std"><Lock size={14} /><div className="m"><b>{typeof it.label === 'function' ? it.label({ procedure: '[procedure]', pid: '' } as any).replace(/: (\[procedure\]|NKDA)$/, '') : it.label}</b><span>{({ check: 'Checkbox', radio: 'Single choice', multi: 'Multiple choice', select: 'Staff', number: 'Number', text: 'Text', time: 'Time stamp', list: 'Item list', counts: 'Counts grid' } as any)[it.kind]}{it.req ? ' · required' : ''}</span></div><span className="k7-tag std">Standard · AORN</span></div>)
          : null}
        {st !== 'or' && g === 'Facility items' && <details className="k7-stdall"><summary>Standard items at this station ({(stdGroups || []).reduce((n, s) => n + s.items.length, 0)})</summary>{(stdGroups || []).map(s => <div key={s.group} className="k7-stdg"><b>{s.group}</b><span>{s.items.join(' · ')}</span></div>)}</details>}
        {inGroup.map(it => <div key={it.id} className={`k7-it fac ${sel === it.id ? 'sel' : ''}`} onClick={() => setSel(it.id)} data-testid="k7-item"><GripVertical size={14} /><div className="m"><b>{it.label}</b><span>{KIND_LABEL[it.kind]}{it.opts?.length ? ` · ${it.opts.length} options` : ''} · {it.req ? 'required' : 'optional'}{it.link ? <> · <FileText size={12} /> {it.link.title}</> : null}</span></div>{it.cond && condText(it.cond) && <span className="k7-tag why">{condText(it.cond)}</span>}<span className="k7-tag fac">{it.src === 'form' ? 'From form' : 'Facility'}</span>
          <span className="k7-mv"><button type="button" aria-label="Move up" onClick={e => { e.stopPropagation(); move(it.id, -1); }}><ChevronUp size={15} /></button><button type="button" aria-label="Move down" onClick={e => { e.stopPropagation(); move(it.id, 1); }}><ChevronDown size={15} /></button></span></div>)}
        {autoInGroup.map(it => <div key={it.id} className="k7-it auto" data-testid="k7-auto"><FileText size={14} /><div className="m"><b>{it.label}</b><span>{KIND_LABEL[it.kind]} · {it.req ? 'required' : 'optional'} · from {it.link?.title} (assigned to this station)</span></div><span className="k7-tag fac">From form</span><button type="button" className="k7-btn sm" onClick={() => { setDraft([...items, { ...it }]); setSel(it.id); }} data-testid="k7-auto-customize">Customize</button></div>)}
        {!inGroup.length && !autoInGroup.length && <p className="k7-mu" style={{ padding: '10px 14px' }}>No facility items here yet. Pick fields from your form library, or create a new one.</p>}
      </section>
      <aside className="k7-edit" data-testid="k7-editor">{cur ? <ItemEditor key={cur.id} it={cur} st={st} groups={groups} surgeons={surgOpts} onChange={p => upd(cur.id, p)} onRemove={() => { setDraft(items.filter(i => i.id !== cur.id)); setSel(''); }} />
        : <div className="k7-empty"><b>Select a facility item to edit it</b><p>Standard items are locked. Facility items can be moved, limited to a room, surgeon, procedure, anesthesia type or age, and given phrases for Talk mode.</p><p>New fields are created in the <b>Form library</b> (Form Studio) and come here when the form is assigned to a station.</p></div>}</aside>
    </div>
    <section className="k7-hist"><b>Versions</b>{doc.versions.length ? doc.versions.slice().reverse().map(v => <div key={v.v} className="k7-hrow"><b>v{v.v}</b><span>{new Date(v.at).toLocaleString('en-US', { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' })} · {v.by}</span><span className="k7-mu">{v.note || `${v.items.length} facility item(s)`}</span></div>) : <span className="k7-mu"> · none published</span>}</section>
    {pick && <PickFromLibrary st={st} group={g} have={new Set([...items, ...auto].map(i => i.id))} onClose={() => setPick(false)} onAdd={add => { setDraft([...items, ...add]); setPick(false); setSel(add[0]?.id || ''); }} />}
  </div>;
};

const ItemEditor: React.FC<{ it: FacItem; st: StKey; groups: { id: string; title: string }[]; surgeons: string[]; onChange: (p: Partial<FacItem>) => void; onRemove: () => void }> = ({ it, st, groups, surgeons, onChange, onRemove }) => {
  const [lab, setLab] = useState(it.label); const [opts, setOpts] = useState((it.opts || []).join(', ')); const [quick, setQuick] = useState((it.quick || []).join(', ')); const [talk, setTalk] = useState((it.talk || []).join(', ')); const [proc, setProc] = useState(it.cond?.procedures || '');
  const c = it.cond || {}; const tog = (k: 'rooms' | 'surgeons' | 'anes', v: string) => { const l = c[k] || []; onChange({ cond: { ...c, [k]: l.includes(v) ? l.filter(x => x !== v) : [...l, v] } }); };
  const split = (s: string) => s.split(',').map(x => x.trim()).filter(Boolean);
  return <div className="k7-form">
    <div className="k7-eh"><b>Edit facility item</b><span className="k7-tag fac">{it.src === 'form' ? 'From form' : 'Facility'}</span></div>
    <label><span>Label staff see</span><input className="k7-in" value={lab} onChange={e => setLab(e.target.value)} onBlur={() => onChange({ label: lab.trim() || it.label })} data-testid="k7-e-label" /></label>
    <div><span className="k7-l">Control</span><div className="k7-seg wrap">{(Object.keys(KIND_LABEL) as Kind[]).map(k => <button key={k} type="button" className={it.kind === k ? 'on' : ''} onClick={() => onChange({ kind: k })} data-testid={`k7-e-kind-${k}`}>{KIND_LABEL[k]}</button>)}</div></div>
    {['radio', 'multi', 'dropdown'].includes(it.kind) && <label><span>Options (comma separated)</span><input className="k7-in" value={opts} onChange={e => setOpts(e.target.value)} onBlur={() => onChange({ opts: split(opts) })} placeholder="e.g. None, Contact, Droplet" data-testid="k7-e-opts" /></label>}
    {['number', 'text'].includes(it.kind) && <div className="k7-two"><label><span>Quick values</span><input className="k7-in" value={quick} onChange={e => setQuick(e.target.value)} onBlur={() => onChange({ quick: split(quick) })} placeholder="e.g. 250, 300" /></label>{it.kind === 'number' && <label><span>Unit</span><input className="k7-in" value={it.unit || ''} onChange={e => onChange({ unit: e.target.value })} placeholder="mmHg" /></label>}</div>}
    <div className="k7-two"><div><span className="k7-l">Required</span><div className="k7-seg">{[['Required', true], ['Optional', false]].map(([l, v]) => <button key={String(l)} type="button" className={it.req === v ? 'on' : ''} onClick={() => onChange({ req: v as boolean })} data-testid={`k7-e-req-${l}`}>{l as string}</button>)}</div></div>
      <label><span>{st === 'or' ? 'Phase' : OFFICE_PHASES[st] ? 'Step' : 'Section'}</span><select className="k7-in" value={it.group} onChange={e => onChange({ group: e.target.value })} data-testid="k7-e-group">{groups.map(g => <option key={g.id} value={g.id}>{g.title}</option>)}</select></label></div>
    <div><span className="k7-l">Show this item when (all that apply; none = every case)</span>
      <div className="k7-cond"><span>Room</span><div className="k7-chips">{(isAscEd ? S.ROOMS : Array.from(new Set(medRepo.visits().map(v => v.room).filter(Boolean)))).map(r => <button key={r} type="button" className={(c.rooms || []).includes(r) ? 'on' : ''} onClick={() => tog('rooms', r)} data-testid={`k7-e-room-${r}`}>{r}</button>)}</div></div>
      <div className="k7-cond"><span>{isAscEd ? 'Surgeon' : 'Provider'}</span><div className="k7-chips">{surgeons.map(r => <button key={r} type="button" className={(c.surgeons || []).includes(r) ? 'on' : ''} onClick={() => tog('surgeons', r)}>{r}</button>)}</div></div>
      {isAscEd && <div className="k7-cond"><span>Anesthesia</span><div className="k7-chips">{ANES.map(r => <button key={r} type="button" className={(c.anes || []).includes(r) ? 'on' : ''} onClick={() => tog('anes', r)}>{r}</button>)}</div></div>}
      <div className="k7-cond"><span>{isAscEd ? 'Procedure / CPT' : 'Visit type / reason'}</span><input className="k7-in" value={proc} onChange={e => setProc(e.target.value)} onBlur={() => onChange({ cond: { ...c, procedures: proc } })} placeholder={isAscEd ? 'keywords or CPT, comma separated' : 'e.g. diabetes, annual, new patient'} data-testid="k7-e-proc" /></div>
      <div className="k7-cond"><span>Age</span><div className="k7-two"><input className="k7-in sm" inputMode="numeric" placeholder="min" value={c.minAge ?? ''} onChange={e => onChange({ cond: { ...c, minAge: e.target.value === '' ? undefined : +e.target.value } })} /><input className="k7-in sm" inputMode="numeric" placeholder="max" value={c.maxAge ?? ''} onChange={e => onChange({ cond: { ...c, maxAge: e.target.value === '' ? undefined : +e.target.value } })} /></div></div></div>
    <label><span><Mic size={13} /> Talk mode listens for</span><input className="k7-in" value={talk} onChange={e => setTalk(e.target.value)} onBlur={() => onChange({ talk: split(talk) })} placeholder="e.g. laser, goggles" data-testid="k7-e-talk" /></label>
    <div><span className="k7-l">Fills this form field</span><div className="k7-link"><FileText size={14} />{it.link ? <span><b>{it.link.title}</b> › {it.link.field}</span> : <span className="k7-mu">Not linked: the answer is kept in the station record only.</span>}</div></div>
    <div className="k7-acts"><button type="button" className="k7-btn sm danger" onClick={onRemove} data-testid="k7-e-remove"><X size={14} /> Remove</button></div>
  </div>;
};

const PickFromLibrary: React.FC<{ st: StKey; group: string; have: Set<string>; onClose: () => void; onAdd: (l: FacItem[]) => void }> = ({ st, group, have, onClose, onAdd }) => {
  const forms = useMemo(() => { const l = [...VITYLS_FORM_CATALOG.map(f => ({ file: f.file, title: f.title })), ...Object.values(FL.entries()).map(e => ({ file: e.file, title: e.title }))]; const seen = new Set<string>(); return l.filter(f => !seen.has(f.file) && seen.add(f.file)).sort((a, b) => a.title.localeCompare(b.title)); }, []);
  const [q, setQ] = useState(''); const [file, setFile] = useState(''); const [chosen, setChosen] = useState<string[]>([]);
  const def = useMemo(() => { if (!file) return null; try { return FL.publishedDef(file) || FL.originalDef(file); } catch { return null; } }, [file]);
  const title = forms.find(f => f.file === file)?.title || ''; const fields = def ? def.sections.flatMap(s => s.fields.map(f => ({ f, sec: s.title }))).filter(x => !SKIP.has(x.f.type)) : [];
  const add = () => onAdd(fields.filter(x => chosen.includes(x.f.name)).map(x => ({ ...formItem(file, title, x.f, st, group)!, src: 'form' as const })));
  return <div className="a81-modal" onMouseDown={e => { if (e.target === e.currentTarget) onClose(); }}><div className="a81-dialog k7-pick" role="dialog" aria-label="Pick fields from your form library" data-testid="k7-pick">
    <div className="a81-dhead"><b>Pick fields from your form library</b><span style={{ marginLeft: 'auto' }} /><button type="button" className="k7-btn" onClick={onClose}>Cancel</button><button type="button" className="k7-btn pri" disabled={!chosen.length} onClick={add} data-testid="k7-pick-add">Add {chosen.length || ''} item{chosen.length === 1 ? '' : 's'}</button></div>
    <div className="k7-pgrid">
      <div className="k7-forms"><input className="k7-in" placeholder="Search forms…" value={q} onChange={e => setQ(e.target.value)} />{forms.filter(f => !q || f.title.toLowerCase().includes(q.toLowerCase())).map(f => <button key={f.file} type="button" className={file === f.file ? 'on' : ''} onClick={() => { setFile(f.file); setChosen([]); }} data-testid="k7-pick-form"><FileText size={14} /><span>{f.title}</span></button>)}</div>
      <div className="k7-fields">{!file ? <p className="k7-mu">Choose a form. Its fields appear here; fields already on a station checklist are marked.</p> : fields.map(({ f, sec }) => { const id = `form:${file}:${f.name}`; const inL = have.has(id); const k = kindOf(f.type, (f.options || []).length);
        return <label key={f.id || f.name} className={`k7-frow ${inL ? 'in' : ''}`}><input type="checkbox" disabled={inL || !k} checked={chosen.includes(f.name)} onChange={e => setChosen(e.target.checked ? [...chosen, f.name] : chosen.filter(x => x !== f.name))} data-testid="k7-pick-field" /><span className="m"><b>{f.label || f.name}</b><span>{sec} · {FL.TYPE_LABEL[f.type]}{k ? ` → ${KIND_LABEL[k]}` : ''}</span></span>{inL && <span className="k7-tag std">In checklist</span>}</label>; })}</div>
    </div></div></div>;
};
