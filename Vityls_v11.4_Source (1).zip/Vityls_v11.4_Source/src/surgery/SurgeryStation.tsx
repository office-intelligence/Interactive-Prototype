import { RxSetButton } from './episodes/EpisodeViews';
/*
 * Surgery.Vityls station workflow (one visit, room to room). Tablet-first (768×1024, 1180×820).
 * Intake links → Check-in (ASC check-in model) → Nurse intake (short native admission form) → Surgeon (simulated ambient
 * scribe; Nightingale drafts, the clinician reviews, edits, initials and signs with PIN) → Checkout (surgery booking at the
 * network ASC, follow-up, pre-op clearance, AVS, invoice) → Visit record.
 * Nothing leaves the device: links, booking requests and letters are simulated and audited. Nightingale never signs or orders.
 */
import { isMedical } from '../edition';
import { QuoteList } from './quotes';
import React, { useEffect, useRef, useState } from 'react';
import { repo } from '../v6/dataLayer';
import { FormPage } from '../v6/FormPage';
import { stationPlan } from '../v7/myForms';
import { VITYLS_FORM_CATALOG } from '../data/formWorkspaceCatalog';
import { medRepo, MedVisit, MedPatient, Vitals, VisitNote, visitAsCase, vitalsText, usDate, ageFrom, fmtDateTime, fmtDate, addDays, isoDay, uid, bmiFrom, patientKey, PROVIDER_ROLES } from '../med/record';
import { advanceVisit, StepForms, stamp, VisitRecord } from '../med/MedVisit';
import { useActor, useMedTick, printHtml, esc } from '../med/ui';
import { getSettings } from '../med/settings';
import { effectiveAllergy } from '../v7/allergy';
import { modules, nurseAdmission, saveNurseAdmission, NurseAdmission, scribeSession, saveScribe, ScribeLine, ScribeSuggestion, ScribeDraft, checkoutOrders, saveOrder, CheckoutOrder, intakeLinks, queueIntakeLink, ascBlocks, requestBooking, activeVisitTypes, visitTypeDef, edgeOf, ascCasesFor } from './store';
import { STATION_LABEL, R, nextAscCase } from './nightingale';
import { HoldToInitial, initialsOf, useSv, hhmm } from './ui';
import { PinSign, Signer } from './sign';
import { ROLE_GROUP } from './staff';
import { AllergyVerify, allergyStatus } from './allergy';
import { ChargesPanel } from './charges';
import { SendToAsc, AscSentList } from './SendToAsc';
import { Ico } from './icons';
import { MediaStep, SurgeonMediaBand, mediaForVisit } from './media';
import { FD } from './fd/flag';
import { FdStationForms } from './fd/StationForms';
import { takeFdStationStep } from './fd/stationStep';
import { ModeIcon, modeOf, isRemote, modeLabel } from './flow/apptMode';
import { useWsSaver } from './flow/wsSave';
const noteHash = (s: string) => { let h = 5381; for (const c of s) h = ((h << 5) + h + c.charCodeAt(0)) >>> 0; return h.toString(16); };
/** v0.4: stations are open to everyone on the shared tablet. Only the signature asks for a PIN. Office steps can be attested by
 *  any care-team member (small offices: the front desk may room the patient); the surgeon step / visit note needs a provider PIN. */
const SIGN_ROLES: Record<string, string[]> = { 'check-in': ROLE_GROUP.everyone, rooming: ROLE_GROUP.everyone, provider: ROLE_GROUP.provider, checkout: ROLE_GROUP.everyone };
/** Sign the visit note as this provider (same rule as MED: fingerprint + lock, Nightingale cannot sign). */
export function signNote(v: MedVisit, w: Signer) {
  const n = medRepo.note(v.id); if (!n) throw new Error('Save the note draft first.');
  const h = noteHash([n.subjective, n.objective, n.assessment, n.plan].join('\u241e'));
  medRepo.saveNote({ ...n, status: 'signed', signedBy: w.name, signedAt: w.at, contentHash: h });
  repo.audit({ caseId: v.id, user: w.name, role: w.role, action: 'visit.note.sign', detail: `Visit note signed with ${w.name}’s own PIN · fingerprint ${h}` });
}

type StepId = 'intake' | 'check-in' | 'rooming' | 'provider' | 'media' | 'checkout' | 'record';
const STEPS: { id: StepId; label: string }[] = [{ id: 'intake', label: 'Intake forms' }, { id: 'check-in', label: 'Check-in' }, { id: 'rooming', label: 'Nurse intake' }, { id: 'provider', label: 'Surgeon' }, { id: 'media', label: 'Charts & photos' }, { id: 'checkout', label: 'Checkout' }, { id: 'record', label: 'Visit record' }];
const NEXT: Record<string, StepId> = { intake: 'check-in', 'check-in': 'rooming', rooming: 'provider', provider: 'checkout', checkout: 'record' };
const ANTITHROMBOTIC = /clopidogrel|plavix|aspirin|prasugrel|ticagrelor|warfarin|coumadin|apixaban|eliquis|rivaroxaban|xarelto|dabigatran|enoxaparin|heparin/i;
const GLP1 = /semaglutide|ozempic|wegovy|tirzepatide|mounjaro|zepbound|liraglutide|dulaglutide|trulicity/i;
const isProvider = (role: string) => PROVIDER_ROLES.includes(role);
const formItem = (f: string) => VITYLS_FORM_CATALOG.find(x => x.file === f) || { title: f.replace(/\.html$/, '').replace(/_/g, ' '), file: f, category: 'Form', stage: '' };

import { cardStatus } from './v12/cards';
import { CardsPanel } from './v12/Cards';
import { SurgeonDx } from './v12/SurgeonDx';
export const SurgeryStation: React.FC<{ visitId: string; onBack: () => void }> = ({ visitId, onBack }) => {
  useMedTick(); const [actor] = useActor(); const { go, toast, openPanel } = useSv();
  const v = medRepo.visit(visitId); const p = v ? medRepo.patient(v.patientId) : undefined;
  const initial: StepId = !v ? 'check-in' : v.step === 'complete' ? 'record' : v.step === 'scheduled' ? (visitTypeDef(v.visitType).category === 'new' ? 'intake' : 'check-in') : v.step as StepId;
  const [step, setStep] = useState<StepId>(() => (FD && takeFdStationStep() as StepId) || initial);
  useEffect(() => { window.scrollTo(0, 0); }, [step]);
  if (!v || !p) return <p className="sv-muted">Visit not found. <button type="button" className="sv-link" onClick={onBack}>Back to today</button></p>;
  const ver = repo.getStationVerification(v.id); const vt = visitTypeDef(v.visitType);
  const al = allergyStatus(p); const [signing, setSigning] = useState<StepId | null>(null);
  const verify = (s: StepId, w: Signer) => {
    if (s === 'check-in') { stamp(v, 'visit.arrived', 'Arrived'); stamp(v, 'visit.checkedIn', 'Checked in'); }
    if (s === 'rooming') stamp(v, 'visit.roomed', 'Roomed');
    if (s === 'provider') stamp(v, 'visit.providerOut', 'Provider out');
    if (s === 'checkout') stamp(v, 'visit.checkedOut', 'Checked out');
    advanceVisit(medRepo.visit(v.id)!, s, w.name, w.role); repo.audit({ caseId: v.id, user: w.name, role: w.role, action: 'staff.pin', detail: `${STEPS.find(x => x.id === s)?.label} attested with ${w.name}’s own PIN (session: ${actor.name})` });
    setSigning(null); toast(`${STEPS.find(x => x.id === s)?.label} verified by ${w.name}.`); setStep(NEXT[s]);
  };
  const done = (s: StepId) => s === 'intake' ? intakeLinks(v.id).length > 0 || stationPlan('patientPortal').required.every(f => repo.getForm(v.id, f).status === 'locked') && stationPlan('patientPortal').required.length > 0 : s === 'record' ? v.step === 'complete' : s === 'media' ? mediaForVisit(v.id) : !!ver[s];
  const verifiable = ['check-in', 'rooming', 'provider', 'checkout'].includes(step);
  return <div className="sv-page" data-testid="sv-station">
    <div className="sv-hdr" style={{ borderBottom: 0, paddingBottom: 2 }}>
      <h1 className="nm" data-testid="station-name">{p.name}</h1>
      <span className="sv-sub">{ageFrom(p.dob)} · {p.sex} · DOB {p.dob} · {p.id} · {p.phone}</span>
      <span className="text-[13px]" data-testid="station-allergy"><b className="text-[var(--crit)] text-[11px] tracking-[.07em] uppercase mr-1">Allergies</b><span className={al.a.state === 'nkda' ? '' : 'text-[var(--crit)]'}>{al.a.state === 'not-reported' ? 'Not reported' : al.a.text}</span>{al.verified ? <span className="sv-muted"> · verified</span> : <span className="text-[var(--warn)]"> · not verified</span>}</span>
      <span className="ml-auto flex gap-3 text-[13px]"><button type="button" className="sv-link inline-flex items-center gap-1" onClick={() => go({ type: 'chart', pid: p.id })} data-testid="station-open-chart"><Ico k="note" />Open chart</button><button type="button" className="sv-link" onClick={onBack}>Back to today</button></span>
    </div>
    <div className="text-[13.5px] flex flex-wrap items-center gap-x-3 gap-y-1 mt-1" data-testid="station-visit">
      <span className="inline-flex items-center gap-1.5"><span className="sv-dot" style={{ background: vt.color, border: `1px solid ${edgeOf(vt.color)}` }} />{v.visitType}</span>
      <ModeIcon mode={modeOf(v)} label testId="station-mode" />{isRemote(v) && <span className="sv-muted" data-testid="station-remote-note">{modeLabel(modeOf(v))} · no arrival or rooming</span>}
      <span>{usDate(v.date)} {v.time}</span><span>{v.provider}</span><span>{v.room}</span>{v.reason && <span className="sv-muted">· {v.reason}</span>}
      <span className="sv-tag" data-testid="station-now">{STATION_LABEL[v.step]}</span>
    </div>
    <nav className="sv-steps" aria-label="Station steps" role="tablist">{STEPS.map(s => <button key={s.id} type="button" role="tab" aria-selected={step === s.id} aria-current={step === s.id ? 'step' : undefined} className={s.id === 'media' ? 'feature' : undefined} onClick={() => setStep(s.id)} data-testid={`st-${s.id}`}>{s.id === 'media' && <Ico k="photo" />}{done(s.id) && <span className="ck" aria-label="done">✓</span>}{s.label}</button>)}</nav>
    {step === 'intake' && <IntakeStep v={v} p={p} onNext={() => setStep('check-in')} />}
    {step === 'check-in' && <CheckInStep v={v} p={p} />}
    {step === 'rooming' && <NurseStep v={v} p={p} />}
    {step === 'provider' && <SurgeonStep v={v} p={p} onMedia={() => setStep('media')} />}
    {step === 'media' && <MediaStep p={p} visitId={v.id} />}
    {step === 'checkout' && <CheckoutStep v={v} p={p} />}
    {step === 'record' && <RecordStep v={v} p={p} />}
    {FD && step === 'rooming' && <FdStationForms v={v} station="nursing" step="rooming" />}
    {FD && step === 'provider' && <FdStationForms v={v} station="surgeon" step="provider" />}
    {FD && step === 'checkout' && <FdStationForms v={v} station="frontOffice" step="checkout" />}
    {verifiable && <div className="sv-verify" data-testid="station-verify">
      <span className="text-[13.5px]">{ver[step] ? <span className="text-[var(--ok)] font-semibold">✓ {STEPS.find(x => x.id === step)?.label} verified by {ver[step].by} · {fmtDateTime(ver[step].at)}</span> : <>When this step is done, verify it with your own PIN. Your name and the time are recorded{step === 'provider' && medRepo.note(v.id)?.status !== 'signed' ? <span className="text-[var(--warn)]"> · note not signed yet</span> : ''}.</>}</span>
      <button type="button" className="sv-btn primary" onClick={() => setSigning(step)} data-testid={`verify-${step}`}>{ver[step] ? 'Verify again' : `Verify ${STEPS.find(x => x.id === step)?.label.toLowerCase()} → ${STEPS.find(x => x.id === NEXT[step])?.label}`}</button>
    </div>}
    {signing && <PinSign title={`Verify ${STEPS.find(x => x.id === signing)?.label.toLowerCase()}`} statement={<>I attest that the {STEPS.find(x => x.id === signing)?.label.toLowerCase()} step for {p.name} is complete.</>} roles={SIGN_ROLES[signing]} confirmLabel="Verify" onClose={() => setSigning(null)} onSigned={w => verify(signing, w)} />}
    <p className="sv-muted text-[12px] mt-3">Tablet session: {actor.name} ({actor.role}) · signatures use each person’s own PIN. <button type="button" className="sv-link" onClick={() => openPanel(R('audit', 'Audit trail', p.id))}>Patient audit trail</button></p>
  </div>;
};

/* ---------------- Intake forms: send links from My Forms (simulated outbox) ---------------- */
export const IntakeStep: React.FC<{ v: MedVisit; p: MedPatient; onNext: () => void }> = ({ v, p, onNext }) => {
  useMedTick(); const [actor] = useActor(); const { toast } = useSv();
  const plan = stationPlan('patientPortal'); const files = Array.from(new Set([...plan.required, ...plan.asNeeded]));
  const [pick, setPick] = useState<string[]>(plan.required.length ? plan.required : files.slice(0, 3));
  const [channel, setChannel] = useState<'email' | 'text'>(p.email ? 'email' : 'text'); const [open, setOpen] = useState<string | null>(null);
  const to = channel === 'email' ? (p.email || '') : p.phone; const sent = intakeLinks(v.id).slice().reverse();
  if (open) return <div className="sv-flat"><FormPage patient={visitAsCase(v)} form={formItem(open)} station="patientPortal" onClose={() => setOpen(null)} /></div>;
  const queue = () => { if (!pick.length) { toast('Choose at least one form.'); return; } queueIntakeLink({ patientId: p.id, visitId: v.id, forms: pick, channel, to, by: actor.name }, actor.role); toast('Link queued in the simulated outbox. Nothing was sent.'); };
  return <div className="sv-two" data-testid="st-intake-body">
    <section>
      <h2 className="sv-h">New-patient intake · from My Forms (Portal / At-home)</h2>
      <p className="text-[13px] sv-muted mb-2">{isMedical ? 'Smart intake forms.' : 'The same smart forms ASC.Vityls uses.'} Send a link before the visit, or hand the tablet to the patient in the office.</p>
      {files.length === 0 ? <p className="sv-muted text-[13.5px]">No forms are assigned to the patient portal. Practice → Forms &amp; workflow.</p> :
        <table className="sv-table" data-testid="intake-forms"><thead><tr><th style={{ width: 28 }}></th><th>Form</th><th>Status</th><th></th></tr></thead><tbody>{files.map(f => { const r = repo.getForm(v.id, f); const req = plan.required.includes(f); return <tr key={f}>
          <td><input type="checkbox" checked={pick.includes(f)} onChange={e => setPick(e.target.checked ? [...pick, f] : pick.filter(x => x !== f))} aria-label={`Include ${formItem(f).title}`} /></td>
          <td>{formItem(f).title}<div className="sv-muted text-[11.5px]">{req ? 'Required' : 'As needed'}</div></td>
          <td>{r.status === 'locked' ? <span className="sv-tag ok">Signed</span> : r.status === 'not-started' ? <span className="sv-muted">Not started</span> : <span className="sv-tag warn">{r.status === 'draft' ? 'Draft' : 'Partly signed'}</span>}</td>
          <td className="text-right"><button type="button" className="sv-btn sm" onClick={() => setOpen(f)} data-testid={`intake-open-${f}`}>{r.status === 'not-started' ? 'Fill in office' : 'Open'}</button></td></tr>; })}</tbody></table>}
    </section>
    <section>
      <h2 className="sv-h">Send the link</h2>
      <div className="flex flex-wrap items-end gap-2 mb-2">
        <div className="sv-seg" role="group" aria-label="Channel">{(['email', 'text'] as const).map(c => <button key={c} type="button" aria-pressed={channel === c} onClick={() => setChannel(c)}>{c === 'email' ? 'Email' : 'Text message'}</button>)}</div>
        <span className="text-[13.5px]">to <b>{to || '(no address on file)'}</b></span>
      </div>
      <button type="button" className="sv-btn primary" onClick={queue} disabled={!to} data-testid="intake-send">Queue link · {pick.length} form{pick.length === 1 ? '' : 's'} (simulated)</button>
      <p className="text-[12px] sv-muted mt-1">Simulation: nothing is emailed or texted. The link is recorded in the outbox and the audit trail.</p>
      <h2 className="sv-h mt-4">Outbox</h2>
      {sent.length === 0 ? <p className="sv-muted text-[13px]">No links yet for this visit.</p> : <ul className="text-[13px] space-y-1.5" data-testid="intake-outbox">{sent.map(l => <li key={l.id}><b>{fmtDateTime(l.createdAt)}</b> · {l.channel} to {l.to} · {l.forms.length} form(s) · <span className="sv-tag warn">simulated, not sent</span><div className="sv-muted text-[11.5px] break-all">{l.link} · by {l.by}</div></li>)}</ul>}
      <button type="button" className="sv-btn mt-4" onClick={onNext}>Go to check-in →</button>
    </section>
  </div>;
};

/* ---------------- Check-in: identity, automatic timestamps, front-office forms. No medical history at the front desk. ---------------- */
export const CheckInStep: React.FC<{ v: MedVisit; p: MedPatient }> = ({ v, p }) => {
  useMedTick(); const [actor] = useActor(); const { toast } = useSv();
  const idOk = repo.getAudit(v.id).find(x => x.action === 'checkin.identity'); const facts = repo.getFacts(v.id);
  const confirmId = () => repo.audit({ caseId: v.id, user: actor.name, role: actor.role, action: 'checkin.identity', detail: 'Identity confirmed with the patient (name + date of birth, photo ID)' });
  const t = (id: string) => facts[id]?.value ? { at: String(facts[id].value), by: facts[id].source?.by } : null; const arr = t('visit.arrived'); const chk = t('visit.checkedIn');
  return <div className="sv-two">
    <section data-testid="checkin-identity">
      <h2 className="sv-h">Confirm who the patient is</h2>
      <table className="sv-table"><tbody>{([['Name', p.name], ['Date of birth', p.dob], ['Phone', p.phone], ['Email', p.email || '—'], ['Language', p.language], ['Insurance', p.insurance || 'Self-pay / not recorded'], ['Emergency contact', p.emergencyContact || 'Not recorded']] as const).map(([k, x]) => <tr key={k}><td className="sv-muted" style={{ width: 150 }}>{k}</td><td>{x}</td></tr>)}</tbody></table>
      <div className="mt-2">{idOk ? <span className="sv-tag ok">✓ Identity confirmed by {idOk.user} · {fmtDateTime(idOk.at)}</span> : <button type="button" className="sv-btn" onClick={confirmId} data-testid="checkin-id">Identity confirmed (name, DOB, photo ID)</button>}</div>
      <FrontDeskCards p={p} />
      <h2 className="sv-h mt-4">Times (recorded automatically)</h2>
      <div className="flex flex-wrap gap-2 items-center text-[13.5px]" data-testid="checkin-times">
        {arr ? <span className="sv-tag ok">Arrived {arr.at}{arr.by ? ` · ${arr.by}` : ''}</span> : <button type="button" className="sv-btn sm" onClick={() => { arriveVisit(v, actor.name, actor.role); toast('Arrival time recorded.'); }} data-testid="checkin-arrive">Patient arrived · record time</button>}
        {chk ? <span className="sv-tag ok">Checked in {chk.at}{chk.by ? ` · ${chk.by}` : ''}</span> : <button type="button" className="sv-btn sm primary" onClick={() => { checkInVisit(v, actor.name, actor.role); toast('Check-in time recorded.'); }} data-testid="checkin-now">Check in · record time</button>}
      </div>
      <p className="text-[12px] sv-muted mt-2">No time pickers: the tablet stamps the time when you tap. Allergies and medical history are verified with the patient at the nursing or physician station, not at the front desk.</p>
    </section>
    <section className="sv-flat space-y-3"><StepForms v={v} step="check-in" /></section>
  </div>;
};
/** Arrival / check-in with automatic timestamps (shared by Today and the check-in step). */
export function arriveVisit(v: MedVisit, by: string, role: string) { if (repo.getFacts(v.id)['visit.arrived']?.value) return; stamp(v, 'visit.arrived', 'Arrived'); repo.audit({ caseId: v.id, user: by, role, action: 'visit.arrive', detail: `Arrival recorded at ${hhmm(new Date().toISOString())} (automatic timestamp)` }); }
export function checkInVisit(v: MedVisit, by: string, role: string) {
  arriveVisit(v, by, role); if (!repo.getFacts(v.id)['visit.checkedIn']?.value) { stamp(v, 'visit.checkedIn', 'Checked in'); repo.audit({ caseId: v.id, user: by, role, action: 'visit.checkin', detail: `Checked in at ${hhmm(new Date().toISOString())} (automatic timestamp)` }); }
  const cur = medRepo.visit(v.id)!; if (cur.step === 'scheduled') medRepo.saveVisit({ ...cur, step: 'check-in' });
}

/** v0.12 · Front desk: card status; capture/upload any missing ID or insurance card right here. */
export const FrontDeskCards: React.FC<{ p: MedPatient }> = ({ p }) => { useMedTick(); const st = cardStatus(p.id); const [all, setAll] = useState(false);
  return <div className="mt-4" data-testid="checkin-cards"><h2 className="sv-h">ID &amp; insurance cards</h2>
    <div className="v12-cardline" data-testid="checkin-cards-status">{st.items.map(x => <span key={x.key} className={`v12-chip ${x.ok ? 'ok' : 'miss'}`}>{x.ok ? '✓' : '○'} {x.label}</span>)}</div>
    {st.missing.length > 0 ? <><p className="text-[12.5px] mt-2" style={{ color: 'var(--warn)' }}>{st.missing.length} missing. Capture with the tablet camera or upload a picture.</p><div className="mt-2"><CardsPanel p={p} via="front desk" only={all ? undefined : 'missing'} /></div></>
      : <p className="text-[12.5px] mt-2 sv-muted" data-testid="checkin-cards-ok">✓ All cards on file.</p>}
    <button type="button" className="sv-link text-[12.5px] mt-1" onClick={() => setAll(a => !a)} data-testid="checkin-cards-all">{all ? 'Show only missing' : 'Show all cards'}</button>{all && !st.missing.length && <div className="mt-2"><CardsPanel p={p} via="front desk" /></div>}</div>; };
/* ---------------- Nurse intake: short admission form + simulated ambient voice ---------------- */
type NurseF = { chiefComplaint: string; pain: string; bpSys: string; bpDia: string; hr: string; rr: string; spo2: string; tempF: string; heightIn: string; weightLb: string; medsReviewed: boolean; npo: string; nurseNote: string };
interface NurseLine { speaker: ScribeLine['speaker']; text: string; f?: Partial<NurseF> }
function nurseScript(v: MedVisit, p: MedPatient): NurseLine[] {
  const last = medRepo.vitals(p.id).slice(-1)[0]; const meds = medRepo.meds(p.id).filter(m => m.status === 'active'); const first = p.name.split(/\s+/)[0];
  const bs = (last?.bpSys ?? 128) + 4, bd = (last?.bpDia ?? 80) + 2, hr = (last?.hr ?? 74) + 2, w = last?.weightLb ?? 165;
  const L: NurseLine[] = [
    { speaker: 'Nurse', text: `Hi ${first}, I’m going to get you settled. What brings you in today?` },
    { speaker: 'Patient', text: `I’m here for my ${v.visitType.toLowerCase()}${v.reason && v.reason.length < 40 ? `, ${v.reason.toLowerCase()}` : ''}.`, f: { chiefComplaint: v.reason || v.visitType } },
    { speaker: 'Nurse', text: 'Any pain right now, zero to ten?' },
    { speaker: 'Patient', text: 'Maybe a two.', f: { pain: '2' } },
    { speaker: 'Nurse', text: `Blood pressure is ${bs} over ${bd}, pulse ${hr}, breathing 14, oxygen 98 percent, temperature 98.4.`, f: { bpSys: String(bs), bpDia: String(bd), hr: String(hr), rr: '14', spo2: '98', tempF: '98.4' } },
    { speaker: 'Nurse', text: `And the scale says ${w} pounds.`, f: { weightLb: String(w), ...(last?.heightIn ? { heightIn: String(last.heightIn) } : {}) } },
    { speaker: 'Nurse', text: meds.length ? `Are you still taking ${meds.map(m => m.name.replace(/\s*\(.*\)/, '').toLowerCase()).join(', ')}?` : 'Are you taking any medicines, vitamins or supplements?' },
    { speaker: 'Patient', text: meds.length ? 'Yes, same as before. Nothing new.' : 'No, nothing.', f: { medsReviewed: true } },
  ];
  if (visitTypeDef(v.visitType).category === 'procedure') L.push({ speaker: 'Nurse', text: 'When did you last eat or drink?' }, { speaker: 'Patient', text: 'Just water at seven this morning.', f: { npo: 'Water 7:00 AM' } });
  L.push({ speaker: 'Nurse', text: 'Thank you. The doctor will be right in.', f: { nurseNote: `Roomed for ${v.visitType.toLowerCase()}. Pain 2/10. Medications reviewed with the patient, no changes.` } });
  return L;
}
export const NurseStep: React.FC<{ v: MedVisit; p: MedPatient }> = ({ v, p }) => {
  useMedTick(); const [actor] = useActor(); const { toast, openPanel } = useSv();
  const saved = nurseAdmission(v.id); const meds = medRepo.meds(p.id).filter(m => m.status === 'active');
  const last = medRepo.vitals(p.id).filter(x => x.visitId !== v.id).slice(-1)[0];
  const mine = saved?.vitalsId ? medRepo.vitals(p.id).find(x => x.id === saved.vitalsId) : undefined;
  const [f, setF] = useState<NurseF>(() => ({ chiefComplaint: saved?.chiefComplaint ?? v.reason ?? '', pain: saved?.pain ?? '', bpSys: mine?.bpSys?.toString() ?? '', bpDia: mine?.bpDia?.toString() ?? '', hr: mine?.hr?.toString() ?? '', rr: mine?.rr?.toString() ?? '', spo2: mine?.spo2?.toString() ?? '', tempF: mine?.tempF?.toString() ?? '', heightIn: (mine?.heightIn ?? last?.heightIn)?.toString() ?? '', weightLb: mine?.weightLb?.toString() ?? '', medsReviewed: saved?.medsReviewed ?? false, npo: saved?.npo ?? '', nurseNote: saved?.nurseNote ?? '' }));
  const set = (k: keyof NurseF) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => setF({ ...f, [k]: k === 'chiefComplaint' || k === 'nurseNote' || k === 'npo' ? e.target.value : e.target.value.replace(/[^\d.]/g, '') });
  const bmi = bmiFrom(+f.heightIn || undefined, +f.weightLb || undefined);
  const procedureToday = visitTypeDef(v.visitType).category === 'procedure';
  /* ambient voice (simulated, scripted; no microphone, no audio) */
  const key = `${v.id}#nurse`; const amb = scribeSession(key); const script = useRef(nurseScript(v, p)).current; const applied = useRef(amb.lines.length); const [agree, setAgree] = useState(!!amb.startedAt); const trRef = useRef<HTMLDivElement>(null);
  useEffect(() => { trRef.current?.scrollTo({ top: 99999 }); }, [amb.lines.length]);
  useEffect(() => {
    if (amb.status !== 'listening') return;
    const t = setInterval(() => { const cur = scribeSession(key); if (cur.status !== 'listening') return; const i = cur.lines.length;
      if (i >= script.length) { saveScribe({ ...cur, status: 'stopped', stoppedAt: new Date().toISOString() }); repo.audit({ caseId: v.id, user: actor.name, role: actor.role, action: 'nurse.ambient', detail: 'Nurse ambient voice stopped (end of simulated conversation)' }); return; }
      saveScribe({ ...cur, lines: [...cur.lines, { at: new Date().toISOString(), speaker: script[i].speaker, text: script[i].text }] }); }, 700);
    return () => clearInterval(t);
  }, [amb.status, key, script, v.id, actor.name, actor.role]);
  useEffect(() => { const n = amb.lines.length; if (n > applied.current) { const patch = Object.assign({}, ...script.slice(applied.current, n).map(l => l.f || {})); applied.current = n; setF(prev => ({ ...prev, ...patch })); } }, [amb.lines.length, script]);
  const ambStart = () => { if (!agree) { toast('Confirm the patient agreed to ambient documentation first.'); return; } saveScribe({ ...amb, status: 'listening', startedAt: amb.startedAt || new Date().toISOString(), startedBy: actor.name }); repo.audit({ caseId: v.id, user: actor.name, role: actor.role, action: 'nurse.ambient', detail: 'Nurse ambient voice started · SIMULATED (scripted, no microphone, no audio stored) · patient agreement noted' }); };
  const ambFinish = () => { saveScribe({ ...scribeSession(key), status: 'stopped', startedAt: amb.startedAt || new Date().toISOString(), startedBy: amb.startedBy || actor.name, stoppedAt: new Date().toISOString(), lines: script.map(l => ({ at: new Date().toISOString(), speaker: l.speaker, text: l.text })) }); repo.audit({ caseId: v.id, user: actor.name, role: actor.role, action: 'nurse.ambient', detail: 'Nurse ambient voice: skipped to the end of the simulated conversation' }); };
  const save = () => {
    const num = (x: string) => x.trim() ? +x : undefined; let vitalsId = saved?.vitalsId;
    if ([f.bpSys, f.bpDia, f.hr, f.rr, f.spo2, f.tempF, f.weightLb].some(x => x.trim())) { const rec: Vitals = { id: uid('vit'), patientId: p.id, visitId: v.id, at: new Date().toISOString(), by: actor.name, source: 'manual', bpSys: num(f.bpSys), bpDia: num(f.bpDia), hr: num(f.hr), rr: num(f.rr), spo2: num(f.spo2), tempF: num(f.tempF), heightIn: num(f.heightIn), weightLb: num(f.weightLb), bmi }; medRepo.addVitals(rec); vitalsId = rec.id; }
    const n: NurseAdmission = { visitId: v.id, patientId: p.id, chiefComplaint: f.chiefComplaint.trim(), pain: f.pain, vitalsId, allergiesConfirmed: allergyStatus(medRepo.patient(p.id)!).verified, medsReviewed: f.medsReviewed, anticoagulantLastDose: '', npo: f.npo.trim(), escort: '', fallRisk: '', nurseNote: f.nurseNote.trim(), by: actor.name, role: actor.role, at: new Date().toISOString() };
    saveNurseAdmission(n); f0.current = JSON.stringify(f); toast('Nurse admission saved.');
  };
  const f0 = useRef(JSON.stringify(f)); useWsSaver(() => { if (JSON.stringify(f) !== f0.current) save(); });
  const V = ([['bpSys', 'BP sys'], ['bpDia', 'BP dia'], ['hr', 'Pulse'], ['rr', 'Resp rate'], ['spo2', 'SpO₂ %'], ['tempF', 'Temp °F'], ['heightIn', 'Height in'], ['weightLb', 'Weight lb']] as const);
  return <div data-testid="nurse-form">
    <section className="sv-amb" data-testid="nurse-ambient">
      <div className="flex flex-wrap items-center gap-2">
        <Ico k="monitoring" size={16} /><b className="text-[13.5px]">Ambient voice · nurse</b><span className="sv-muted text-[12px]">simulation · no microphone · no audio stored</span>
        <span className="ml-auto flex flex-wrap items-center gap-2">
          {amb.status === 'listening' ? <span className="sv-rec" data-testid="nurse-listening"><span className="r" />Listening… <span className="sv-muted">{amb.lines.length}/{script.length}</span></span> : amb.status === 'stopped' ? <span className="sv-tag ok">Captured · {amb.lines.length} lines · fields filled for review</span> : null}
          {amb.status === 'idle' && <label className="flex items-center gap-1.5 text-[13px]"><input type="checkbox" checked={agree} onChange={e => setAgree(e.target.checked)} data-testid="nurse-amb-consent" />Patient agreed</label>}
          {(amb.status === 'idle' || amb.status === 'paused') && <button type="button" className="sv-btn sm primary" onClick={ambStart} data-testid="nurse-amb-start">Start listening</button>}
          {amb.status === 'listening' && <button type="button" className="sv-btn sm" onClick={() => saveScribe({ ...amb, status: 'paused' })}>Pause</button>}
          {amb.status !== 'stopped' && <button type="button" className="sv-link text-[12.5px]" onClick={() => { if (amb.status === 'idle' && !agree) { toast('Confirm the patient agreed to ambient documentation first.'); return; } ambFinish(); }} data-testid="nurse-amb-skip">Demo: skip to the end</button>}
        </span>
      </div>
      {amb.lines.length > 0 && <div className="sv-transcript mt-2" ref={trRef} style={{ maxHeight: 130 }} aria-live="polite" data-testid="nurse-transcript">{amb.lines.map((l, i) => <p key={i}><span className="sp">{l.speaker}</span>{l.text}</p>)}</div>}
      <p className="text-[11.5px] sv-muted mt-1">Nightingale fills the form from the conversation; the nurse reviews every field and saves. It never signs.</p>
    </section>
    <div className="sv-two mt-3">
    <section>
      <h2 className="sv-h">Nurse admission · short form</h2>
      {saved && <p className="text-[12.5px] mb-2"><span className="sv-tag ok">Saved by {saved.by} · {fmtDateTime(saved.at)}</span></p>}
      <label className="block mb-2"><span className="sv-label">Reason for visit (in the patient’s words)</span><input className="sv-input" value={f.chiefComplaint} onChange={set('chiefComplaint')} data-testid="nurse-cc" /></label>
      <div className="mb-2"><span className="sv-label">Pain now (0–10)</span><div className="sv-seg" role="group" aria-label="Pain score">{Array.from({ length: 11 }, (_, i) => String(i)).map(n => <button key={n} type="button" aria-pressed={f.pain === n} onClick={() => setF({ ...f, pain: n })} style={{ minWidth: 30 }}>{n}</button>)}</div></div>
      <span className="sv-label">Vitals</span>
      <div className="grid grid-cols-4 gap-2">{V.map(([k, l]) => <label key={k}><span className="text-[11.5px] sv-muted">{l}</span><input className="sv-input" inputMode="decimal" value={f[k]} onChange={set(k)} data-testid={`nurse-${k}`} /></label>)}
        <div><span className="text-[11.5px] sv-muted">BMI (calc.)</span><div className="sv-input" style={{ background: '#f8f9fa' }} data-testid="nurse-bmi">{bmi ?? '—'}</div></div></div>
      {last && <p className="text-[12px] sv-muted mt-1">Last recorded: {vitalsText(last)} ({fmtDate(last.at)}). No thresholds are built in.</p>}
      <label className="block mt-3"><span className="sv-label">Nurse note</span><textarea className="sv-input" rows={3} value={f.nurseNote} onChange={set('nurseNote')} data-testid="nurse-note" /></label>
    </section>
    <section>
      <h2 className="sv-h">With the patient</h2>
      <div className="mb-3"><AllergyVerify p={p} /></div>
      <label className="flex gap-2 items-start text-[13.5px] mb-1"><input type="checkbox" checked={f.medsReviewed} onChange={e => setF({ ...f, medsReviewed: e.target.checked })} data-testid="nurse-meds" /><span>Medications reviewed ({meds.length}): {meds.map(m => `${m.name} ${m.dose}`).join(', ') || 'none recorded'} <button type="button" className="sv-link text-[12px]" onClick={() => openPanel(R('meds', 'Medications', p.id))}>reconcile</button></span></label>
      {procedureToday && <label className="block mb-2 mt-2"><span className="sv-label">Last food / drink (procedure today)</span><input className="sv-input" value={f.npo} onChange={set('npo')} /></label>}
      <button type="button" className="sv-btn primary mt-2" onClick={save} data-testid="nurse-save">Save nurse admission</button>
      <p className="text-[12px] sv-muted mt-2">Medical history and conditions are verified here or by the physician: <button type="button" className="sv-link" onClick={() => openPanel(R('intake', 'Intake answers', p.id))}>open intake</button> · <button type="button" className="sv-link" onClick={() => openPanel(R('problems', 'Problem list', p.id))}>problem list</button> · Forms for this step: <StepFormsLink v={v} /></p>
    </section>
    </div>
    <ChargesPanel v={v} station="Nurse" roles={ROLE_GROUP.everyone} />
  </div>;
};
const StepFormsLink: React.FC<{ v: MedVisit }> = ({ v }) => { const [o, setO] = useState(false); return o ? <div className="sv-flat mt-2"><StepForms v={v} step="rooming" /></div> : <button type="button" className="sv-link" onClick={() => setO(true)}>My Forms (nursing)</button>; };

/* ---------------- Surgeon: simulated ambient scribe ---------------- */
interface ScriptLine { speaker: ScribeLine['speaker']; text: string; d?: Partial<ScribeDraft>; s?: Omit<ScribeSuggestion, 'id' | 'status'> }
function scriptFor(v: MedVisit, p: MedPatient): ScriptLine[] {
  const nc = nextAscCase(p.id); const cat = visitTypeDef(v.visitType).category; const meds = medRepo.meds(p.id).filter(m => m.status === 'active');
  const anti = meds.filter(m => ANTITHROMBOTIC.test(m.name)); const glp = meds.filter(m => GLP1.test(m.name)); const last = p.name.split(/\s+/).slice(-1)[0];
  const title = p.sex === 'Female' ? 'Ms.' : p.sex === 'Male' ? 'Mr.' : ''; const age = ageFrom(p.dob); const who = `${age}-year-old ${p.sex.toLowerCase()}`;
  const proc = nc?.procedure || v.reason || 'the planned procedure'; const asc = nc?.ascName || getSettings().ascName; const when = nc ? usDate(nc.date) : 'a date to be set';
  const bleph = /bleph|eyelid|lid/i.test(proc + ' ' + v.reason); const cg = medRepo.caregivers(p.id).find(c => !c.revokedAt);
  const vit = medRepo.vitals(p.id).filter(x => x.visitId === v.id).slice(-1)[0]; const exam0 = vit ? `Vitals from nurse intake: ${vitalsText(vit)}. ` : '';
  const L: ScriptLine[] = [];
  if (cat === 'post-op') {
    L.push({ speaker: 'Surgeon', text: `Hi ${title} ${last}, how have you been feeling since surgery?`, d: { hpi: `${who} seen for post-operative follow-up${v.reason ? ` (${v.reason})` : ''}.` } });
    L.push({ speaker: 'Patient', text: 'Much better. A little tightness, the swelling is going down, and I only need Tylenol at night.', d: { hpi: 'Reports improving swelling and mild tightness; acetaminophen at night only.' } });
    L.push({ speaker: 'Surgeon', text: 'Let me look at the incisions… they are healing nicely, no redness or drainage.', d: { exam: `${exam0}Incisions clean, dry and intact; no erythema or drainage. Expected swelling. (Simulated exam dictation.)` } });
    L.push({ speaker: 'Surgeon', text: 'Keep the scar care going. Let’s see you again in about six weeks.', d: { assessment: 'Expected post-operative course.', plan: 'Continue scar care and activity as instructed. Follow-up in about six weeks.' }, s: { kind: 'follow-up', text: 'Post-op follow-up in about 6 weeks', detail: 'Post-op follow-up · about 6 weeks' } });
    L.push({ speaker: 'Patient', text: 'Great, thank you.' });
    return L;
  }
  L.push({ speaker: 'Surgeon', text: `Good morning ${title} ${last}. ${nc ? `We’re here to go over your ${proc.toLowerCase()} on ${when}.` : `Tell me what brings you in today.`}`, d: { hpi: nc ? `${who} seen for ${v.visitType.toLowerCase()} before ${proc.toLowerCase()} planned ${when} at ${asc}.` : `${who} seen for ${v.visitType.toLowerCase()}${v.reason ? `: ${v.reason}` : ''}.` } });
  L.push({ speaker: 'Patient', text: bleph ? 'My upper lids keep getting heavier. By the evening they block the top of my vision.' : `It’s about ${(v.reason || 'my concern').toLowerCase()}. It has been bothering me for a while.`, d: { hpi: bleph ? 'Reports progressive upper-lid heaviness obstructing the superior visual field by evening.' : 'Reports the concern has been present for some time.' } });
  L.push({ speaker: 'Surgeon', text: 'Any changes in your health? Any new medicines?' });
  L.push({ speaker: 'Patient', text: meds.length ? `No changes. I take ${meds.map(m => m.name.toLowerCase()).join(', ')}.` : 'No, nothing new and no medicines.', d: { hpi: meds.length ? `No interval changes reported. Medications reviewed with the patient: ${meds.map(m => `${m.name} ${m.dose}`).join(', ')}.` : 'No interval changes; no medications.' } });
  if (cg) L.push({ speaker: 'Family', text: `I’m ${cg.name.split(/\s+/)[0]}, ${p.sex === 'Female' ? 'her' : p.sex === 'Male' ? 'his' : 'their'} ${cg.relationship.toLowerCase()}. I can drive home after the surgery.`, d: { hpi: `${cg.relationship} present; will provide transportation home.` } });
  L.push({ speaker: 'Surgeon', text: bleph ? 'Let me take a look. Close your eyes gently… and open. Look up for me.' : 'Let me examine the area.', d: { exam: `${exam0}${bleph ? 'Upper eyelids: bilateral dermatochalasis with skin resting on the lashes. Extraocular movements full.' : 'Focused examination of the area of concern.'} (Simulated exam dictation.)` } });
  if (anti.length) L.push({ speaker: 'Surgeon', text: `Because of the ${anti.map(m => m.name.toLowerCase()).join(' and ')}, I want your cardiologist’s opinion before surgery.`, d: { plan: `Pre-operative clearance requested regarding ${anti.map(m => m.name).join(', ')}; the surgeon decides after the reply.` }, s: { kind: 'clearance', text: 'Request pre-op clearance (cardiology)', detail: `Question: management of ${anti.map(m => m.name).join(', ')} around ${proc.toLowerCase()}. No hold window is built in; the surgeon decides.` } });
  if (glp.length) L.push({ speaker: 'Surgeon', text: 'The surgery center will want to know about the weekly injection. We’ll go over timing with them.', d: { plan: `${glp.map(m => m.name).join(', ')} noted for anesthesia; timing per surgeon and ASC policy (not configured in this build).` } });
  if (cat === 'new' || cat === 'pre-op' || nc) L.push({ speaker: 'Surgeon', text: nc ? `If everything checks out, we keep ${when}. I’ll confirm with the surgery center.` : `I think surgery is a good option. We’ll find a date at the surgery center.`, d: { assessment: `${bleph ? 'Dermatochalasis of the upper eyelids. ' : ''}Candidate for ${proc.toLowerCase()}${anti.length ? ', pending clearance' : ''} (surgeon’s assessment, simulated).`, plan: `${nc ? 'Proceed with' : 'Schedule'} ${proc.toLowerCase()} at ${asc}${nc ? ` on ${when}` : ''}.` }, s: { kind: 'surgery-booking', text: `${nc ? 'Confirm' : 'Book'} ${proc} at ${asc}`, detail: `${proc} · ${v.provider}${nc ? ` · ${when} ${nc.time}` : ''}` } });
  L.push({ speaker: 'Surgeon', text: 'We’ll see you about a week after surgery to check the incisions.', d: { plan: 'Post-operative visit about one week after surgery.' }, s: { kind: 'follow-up', text: 'Post-op visit about 1 week after surgery', detail: 'Post-op follow-up · 15 min' } });
  L.push({ speaker: 'Patient', text: 'Thank you, that sounds good.' });
  return L;
}
const joinDraft = (lines: ScriptLine[]): ScribeDraft => { const d: ScribeDraft = { hpi: '', exam: '', assessment: '', plan: '' }; lines.forEach(l => (Object.keys(l.d || {}) as (keyof ScribeDraft)[]).forEach(k => { d[k] = (d[k] ? d[k] + (k === 'plan' ? '\n' : ' ') : '') + (k === 'plan' ? '• ' : '') + l.d![k]; })); return d; };

export const SurgeonStep: React.FC<{ v: MedVisit; p: MedPatient; onMedia: () => void }> = ({ v, p, onMedia }) => {
  useMedTick(); const [actor] = useActor(); const { toast } = useSv();
  const on = modules().ambientScribe; const s = scribeSession(v.id); const script = useRef(scriptFor(v, p)).current;
  const [consent, setConsent] = useState(!!s.startedAt); const [edit, setEdit] = useState<ScribeDraft | null>(null); const [sign, setSign] = useState(false);
  /** v0.4: anyone may dictate / edit; saving to the record needs a provider PIN. `save` holds what is waiting for that PIN. */
  const [save, setSave] = useState<{ d: ScribeDraft; andSign: boolean } | null>(null); const [sugPin, setSugPin] = useState<ScribeSuggestion | null>(null); const prov = isProvider(actor.role);
  const note = medRepo.note(v.id); const signed = note?.status === 'signed'; const nurse = nurseAdmission(v.id);
  const listRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (s.status !== 'listening') return;
    const t = setInterval(() => {
      const cur = scribeSession(v.id); if (cur.status !== 'listening') return; const i = cur.lines.length;
      if (i >= script.length) { saveScribe({ ...cur, status: 'stopped', stoppedAt: new Date().toISOString() }); repo.audit({ caseId: v.id, user: actor.name, role: actor.role, action: 'scribe.stop', detail: 'Ambient scribe stopped (end of simulated conversation)' }); window.dispatchEvent(new Event('vityls-med-updated')); return; }
      const L = script[i]; const heard = script.slice(0, i + 1);
      const sug = L.s && !cur.suggestions.some(x => x.text === L.s!.text) ? [...cur.suggestions, { ...L.s, id: uid('sg'), status: 'pending' as const }] : cur.suggestions;
      saveScribe({ ...cur, lines: [...cur.lines, { at: new Date().toISOString(), speaker: L.speaker, text: L.text }], draft: joinDraft(heard), suggestions: sug }); window.dispatchEvent(new Event('vityls-med-updated'));
    }, 900);
    return () => clearInterval(t);
  }, [s.status, v.id, script, actor.name, actor.role]);
  useEffect(() => { listRef.current?.scrollTo({ top: 99999 }); }, [s.lines.length]);
  const start = () => { if (!consent) { toast('Confirm the patient agreed to ambient documentation first.'); return; } saveScribe({ ...s, status: 'listening', startedAt: s.startedAt || new Date().toISOString(), startedBy: actor.name }); repo.audit({ caseId: v.id, user: actor.name, role: actor.role, action: 'scribe.start', detail: 'Ambient scribe started · SIMULATED (scripted transcript, no microphone, no audio stored) · patient agreement noted' }); window.dispatchEvent(new Event('vityls-med-updated')); };
  const pause = () => { saveScribe({ ...s, status: 'paused' }); window.dispatchEvent(new Event('vityls-med-updated')); };
  const finish = () => { const heard = script; const sug: ScribeSuggestion[] = [...s.suggestions]; heard.forEach(L => { if (L.s && !sug.some(x => x.text === L.s!.text)) sug.push({ ...L.s, id: uid('sg'), status: 'pending' }); }); saveScribe({ ...s, status: 'stopped', startedAt: s.startedAt || new Date().toISOString(), stoppedAt: new Date().toISOString(), lines: heard.map(L => ({ at: new Date().toISOString(), speaker: L.speaker, text: L.text })), draft: joinDraft(heard), suggestions: sug }); repo.audit({ caseId: v.id, user: actor.name, role: actor.role, action: 'scribe.stop', detail: 'Ambient scribe stopped (demo: skipped to end of the scripted conversation)' }); window.dispatchEvent(new Event('vityls-med-updated')); };
  const restart = () => { saveScribe({ visitId: v.id, status: 'idle', lines: [], draft: { hpi: '', exam: '', assessment: '', plan: '' }, suggestions: [] }); window.dispatchEvent(new Event('vityls-med-updated')); };
  const draft = edit || s.draft;
  useWsSaver(() => { if (edit) keepDraft(edit); });
  const toNote = (d: ScribeDraft, w: Signer) => { const n: VisitNote = { visitId: v.id, template: on ? 'Ambient scribe draft (simulated) · reviewed by clinician' : v.visitType, subjective: d.hpi, objective: d.exam, assessment: d.assessment, plan: d.plan, status: 'draft', updatedAt: new Date().toISOString(), updatedBy: w.name, addenda: note?.addenda || [] }; medRepo.saveNote(n); stamp(v, 'visit.providerIn', 'Provider in'); saveScribe({ ...scribeSession(v.id), draft: d, noteCreatedAt: new Date().toISOString() }); repo.audit({ caseId: v.id, user: w.name, role: w.role, action: 'scribe.draft', detail: `Visit note saved to the record with ${w.name}’s own PIN (not signed)${edit ? ' · edited on the tablet' : ''} · tablet session: ${actor.name} (${actor.role})` }); };
  const keepDraft = (d: ScribeDraft) => { saveScribe({ ...scribeSession(v.id), draft: d }); repo.audit({ caseId: v.id, user: actor.name, role: actor.role, action: 'scribe.draft.keep', detail: `Working draft kept on the tablet by ${actor.name} (not in the record; a provider PIN is needed to save it)` }); window.dispatchEvent(new Event('vityls-med-updated')); };
  const saveRefused = () => { repo.audit({ caseId: v.id, user: actor.name, role: actor.role, action: 'visit.note.denied', detail: `Visit note NOT saved: no provider PIN (tablet session: ${actor.name}, ${actor.role}). The draft stays on the tablet.` }); setSave(null); toast('Not saved. A physician’s PIN is needed to save the note to the record. Your draft is still here.'); };
  const initialSug = (g: ScribeSuggestion, w: { name: string; role: string } = actor) => {
    const all = scribeSession(v.id); saveScribe({ ...all, suggestions: all.suggestions.map(x => x.id === g.id ? { ...x, status: 'initialed', by: w.name, at: new Date().toISOString() } : x) });
    const o: CheckoutOrder = { id: uid('ord'), visitId: v.id, patientId: p.id, kind: g.kind, text: g.text, detail: g.detail, status: 'to-do', source: `Ambient scribe suggestion, initialed by ${w.name}`, createdBy: w.name, createdAt: new Date().toISOString() };
    saveOrder(o, w.name, w.role, `Checkout to-do from initialed scribe suggestion: ${g.text}`); repo.audit({ caseId: v.id, user: w.name, role: w.role, action: 'scribe.suggestion.initial', detail: `${initialsOf(w.name)} initialed: ${g.text}${w.name !== actor.name ? ` (provider PIN; tablet session ${actor.name})` : ''}` }); toast(`Sent to checkout: ${g.text}`);
  };
  const dismissSug = (g: ScribeSuggestion) => { const all = scribeSession(v.id); saveScribe({ ...all, suggestions: all.suggestions.map(x => x.id === g.id ? { ...x, status: 'dismissed', by: actor.name, at: new Date().toISOString() } : x) }); repo.audit({ caseId: v.id, user: actor.name, role: actor.role, action: 'scribe.suggestion.dismiss', detail: `Dismissed: ${g.text}` }); window.dispatchEvent(new Event('vityls-med-updated')); };
  return <><SurgeonMediaBand p={p} onOpen={onMedia} />{!isMedical && <div className="flex flex-wrap items-center gap-2 my-2" data-testid="rx-sets"><RxSetButton p={p} /><span className="sv-muted text-[12.5px]">Quick post-op prescriptions (pain + antibiotic) · draft until signed with your PIN · simulated eRx</span></div>}<div className="sv-scribe" data-testid="scribe">
    <section className="sv-scribe-l">
      <div className="sv-banner" data-testid="scribe-banner"><b>Ambient scribe · simulation.</b> No microphone is used and no audio is captured or stored. The conversation below is scripted from the chart. A live scribe needs a BAA and patient consent at go-live.</div>
      {nurse && <p className="text-[12.5px] sv-muted mb-2">Nurse intake ({nurse.by}): {nurse.chiefComplaint || '—'} · pain {nurse.pain || '—'}{nurse.medsReviewed ? ' · meds reviewed' : ''}</p>}
      {!on ? <p className="text-[13px] sv-muted">Ambient scribe is switched off (Practice → Visit types & colors · surgical modules). Write the note on the right.</p> : <>
        <div className="flex flex-wrap items-center gap-2 mb-2">
          {s.status === 'listening' ? <span className="sv-rec" data-testid="scribe-listening"><span className="r" />Listening… <span className="sv-muted">{s.lines.length}/{script.length}</span></span> : s.status === 'stopped' ? <span className="sv-tag ok">Conversation captured · {s.lines.length} lines</span> : s.status === 'paused' ? <span className="sv-tag warn">Paused</span> : null}
          {s.status === 'idle' && <label className="flex items-center gap-1.5 text-[13px]"><input type="checkbox" checked={consent} onChange={e => setConsent(e.target.checked)} data-testid="scribe-consent" />Patient agreed to ambient documentation</label>}
          {(s.status === 'idle' || s.status === 'paused') && <button type="button" className="sv-btn primary" onClick={start} data-testid="scribe-start">{s.status === 'paused' ? 'Resume' : 'Start listening'}</button>}
          {s.status === 'listening' && <button type="button" className="sv-btn" onClick={pause} data-testid="scribe-pause">Pause</button>}
          {s.status !== 'stopped' && s.status !== 'idle' && <button type="button" className="sv-btn" onClick={finish} data-testid="scribe-finish">End visit conversation</button>}
          {s.status === 'idle' && <button type="button" className="sv-link text-[12.5px]" onClick={() => { if (!consent) { toast('Confirm the patient agreed to ambient documentation first.'); return; } finish(); }} data-testid="scribe-skip">Demo: skip to the end</button>}
          {s.status === 'stopped' && !note && <button type="button" className="sv-link text-[12.5px]" onClick={restart}>Start over</button>}
        </div>
        {s.suggestions.length > 0 && <div className="mb-3" data-testid="scribe-suggestions"><h2 className="sv-h">Nightingale heard possible orders · initial to send to checkout</h2>
          <div className="space-y-1.5">{s.suggestions.map(g => <HoldToInitial key={g.id} testId={`sug-${g.kind}`} label={<><b>{g.text}</b><span className="sv-muted"> · {g.detail}</span></>} onDone={() => prov ? initialSug(g) : setSugPin(g)} onDismiss={() => dismissSug(g)} done={g.status === 'initialed' ? <>initialed {initialsOf(g.by || '')} · sent to checkout</> : undefined} gone={g.status === 'dismissed'} />)}</div>
          <p className="text-[11.5px] sv-muted mt-1">Hold to initial (or Enter). Swipe left or Delete to dismiss. The surgeon’s PIN on the note signature attests these. Nightingale never orders on its own.</p></div>}
        <div className="sv-transcript" ref={listRef} aria-live="polite" data-testid="scribe-transcript">{s.lines.length === 0 ? <p className="sv-muted">The live transcript appears here as the surgeon and patient talk.</p> : s.lines.map((l, i) => <p key={i}><span className="sp">{l.speaker}</span>{l.text}</p>)}</div>
      </>}
    </section>
    <section className="sv-sheet sv-scribe-r" data-testid="scribe-draft">
      <div className="flex items-baseline justify-between gap-2"><h2 className="sv-h" style={{ color: 'var(--n)' }}>{note ? (signed ? 'Visit note · signed' : 'Visit note · draft') : on ? 'Nightingale draft · not reviewed' : 'Visit note'}</h2>
        {signed ? <span className="sv-tag ok">Signed {note!.signedBy} · {fmtDateTime(note!.signedAt)}</span> : note ? <span className="sv-tag warn">Not signed</span> : on && s.lines.length > 0 ? <span className="sv-tag n">drafting from transcript</span> : null}</div>
      {(['hpi', 'exam', 'assessment', 'plan'] as const).map(k => { const label = { hpi: 'History of present illness', exam: 'Exam', assessment: 'Assessment', plan: 'Plan' }[k]; const val = note && !edit ? ({ hpi: note.subjective, exam: note.objective, assessment: note.assessment, plan: note.plan })[k] : draft[k];
        return <div key={k} className="mt-2"><div className="text-[11px] font-bold tracking-[.06em] uppercase text-[var(--ink3)]">{label}</div>
          {edit ? <textarea className="sv-input" rows={k === 'plan' ? 4 : 3} value={edit[k]} onChange={e => setEdit({ ...edit, [k]: e.target.value })} data-testid={`draft-${k}`} /> : <p className="whitespace-pre-wrap text-[13px] min-h-[1.2em]" data-testid={`draft-view-${k}`}>{val || <span className="sv-muted">—</span>}</p>}</div>; })}
      <div className="flex flex-wrap gap-2 mt-3">
        {!signed && !edit && <button type="button" className="sv-btn sm" onClick={() => setEdit(note ? { hpi: note.subjective, exam: note.objective, assessment: note.assessment, plan: note.plan } : { ...s.draft })} data-testid="draft-edit">Review & edit</button>}
        {edit && <><button type="button" className="sv-btn sm primary" onClick={() => setSave({ d: edit, andSign: false })} data-testid="draft-save">Save note (provider PIN)</button><button type="button" className="sv-btn sm primary" onClick={() => setSave({ d: edit, andSign: true })} data-testid="draft-save-sign">Save &amp; sign</button><button type="button" className="sv-btn sm" onClick={() => { keepDraft(edit); setEdit(null); toast('Working draft kept on this tablet (not in the record yet).'); }} data-testid="draft-keep">Keep working draft</button><button type="button" className="sv-btn sm" onClick={() => setEdit(null)}>Cancel</button></>}
        {!signed && !edit && !note && (s.lines.length > 0 || !on) && <button type="button" className="sv-btn sm" onClick={() => setSave({ d: s.draft, andSign: false })} data-testid="draft-accept">Accept draft as note (provider PIN)</button>}
        {!signed && note && !edit && <button type="button" className="sv-btn sm primary" onClick={() => setSign(true)} data-testid="draft-sign">Sign with PIN</button>}
      </div>
      {!signed && !prov && <p className="text-[12px] mt-2 text-[var(--warn)]" data-testid="note-open-hint">{actor.name} ({actor.role}) can dictate and edit this draft. {note ? 'Signing' : 'Saving it to the record'} needs a physician’s or surgeon’s own PIN.</p>}
      <p className="text-[11.5px] sv-muted mt-2">{on ? 'Drafted by Nightingale from the simulated transcript. The clinician reviews, edits and signs. Nightingale cannot sign.' : 'Nightingale cannot sign.'} The signing provider enters their own PIN.</p>
    </section>
    {save && <PinSign title={save.andSign ? 'Save and sign the visit note' : 'Save the visit note'} statement={<>{save.andSign ? 'Saving and signing locks the note' : 'This saves the note to the record (not signed yet)'} for {p.name}. Only a physician or surgeon can do this, with their own PIN. Dictating and editing are open to anyone on the tablet.</>} roles={ROLE_GROUP.provider} confirmLabel={save.andSign ? 'Save & sign' : 'Save'} onClose={saveRefused} onSigned={w => { toNote(save.d, w); setEdit(null); if (save.andSign) { try { signNote(v, w); if (!repo.getStationVerification(v.id)['provider']) { stamp(v, 'visit.providerOut', 'Provider out'); advanceVisit(medRepo.visit(v.id)!, 'provider', w.name, w.role); } toast(`Note saved and signed by ${w.name}.`); } catch (e) { toast((e as Error).message); } } else toast(`Visit note saved to the record by ${w.name} (not signed).`); setSave(null); }} />}
    {sugPin && <PinSign title="Initial this order" statement={<>I initial <b>{sugPin.text}</b> for {p.name} and send it to checkout.</>} roles={ROLE_GROUP.provider} confirmLabel="Initial" onClose={() => setSugPin(null)} onSigned={w => { initialSug(sugPin, w); setSugPin(null); }} />}
    {sign && <PinSign title="Sign the visit note" statement={<>Signing locks the note for {p.name}. Changes after signing are addenda. This also verifies the surgeon step.</>} roles={ROLE_GROUP.provider} onClose={() => setSign(false)} onSigned={w => { try { signNote(v, w); if (!repo.getStationVerification(v.id)['provider']) { stamp(v, 'visit.providerOut', 'Provider out'); advanceVisit(medRepo.visit(v.id)!, 'provider', w.name, w.role); } setSign(false); toast(`Note signed by ${w.name} and locked.`); } catch (e) { toast((e as Error).message); } }} />}
  </div>
    <SurgeonDx v={v} p={p} />
    <div className="mt-4"><AllergyVerify p={p} compact /><ChargesPanel v={v} station="Physician" roles={ROLE_GROUP.everyone} />{!isMedical && medRepo.patient(v.patientId) && <div className="mt-3" data-testid="surgeon-quotes"><QuoteList p={medRepo.patient(v.patientId)!} compact /></div>}</div>
  </>;
};

/* ---------------- Checkout: surgical scheduling, follow-up, pre-op clearance ---------------- */
const KIND_LABEL: Record<CheckoutOrder['kind'], string> = { 'surgery-booking': 'Surgery booking', 'follow-up': 'Follow-up visit', clearance: 'Pre-op clearance', other: 'Other' };
export const CheckoutStep: React.FC<{ v: MedVisit; p: MedPatient }> = ({ v, p }) => {
  useMedTick(); const [actor] = useActor(); const { toast, openPanel } = useSv(); const mods = modules();
  const orders = checkoutOrders(v.id); const [add, setAdd] = useState<CheckoutOrder['kind'] | ''>(''); const [ascOpen, setAscOpen] = useState(false);
  const newOrder = (kind: CheckoutOrder['kind']) => { const o: CheckoutOrder = { id: uid('ord'), visitId: v.id, patientId: p.id, kind, text: KIND_LABEL[kind], detail: '', status: 'to-do', source: `Added at checkout by ${actor.name}`, createdBy: actor.name, createdAt: new Date().toISOString() }; saveOrder(o, actor.name, actor.role, `Checkout to-do added: ${KIND_LABEL[kind]}`); setAdd(''); };
  const avs = () => { const n = medRepo.note(v.id); printHtml(`After-visit summary · ${p.name}`, `<h1>After-visit summary</h1><p>${esc(p.name)} · DOB ${esc(p.dob)} · ${esc(v.visitType)} with ${esc(v.provider)} · ${usDate(v.date)}</p><h2>Plan from your visit</h2><p>${n?.status === 'signed' ? esc(n.plan).replace(/\n/g, '<br>') : '<i>The visit note is not signed yet.</i>'}</p><h2>What happens next</h2><ul>${orders.filter(o => o.status === 'done').map(o => `<li>${esc(o.text)}: ${esc(o.result || '')}</li>`).join('') || '<li>Nothing scheduled yet.</li>'}</ul><h2>Medications on file</h2><ul>${medRepo.meds(p.id).filter(m => m.status === 'active').map(m => `<li>${esc(m.name)} ${esc(m.dose)} ${esc(m.frequency)}</li>`).join('') || '<li>None recorded</li>'}</ul>`); };
  const allowed = (k: CheckoutOrder['kind']) => k === 'surgery-booking' ? mods.surgeryBooking && mods.networkAsc : k === 'clearance' ? mods.preopClearance : true;
  return <div data-testid="checkout">
    <h2 className="sv-h">To do before the patient leaves · {orders.filter(o => o.status === 'to-do').length} open</h2>
    {orders.length === 0 && <p className="text-[13px] sv-muted">Nothing came from the surgeon yet. Initialed scribe suggestions arrive here; you can also add one.</p>}
    <div className="divide-y divide-[var(--line)]">{orders.map(o => <OrderRow key={o.id} o={o} v={v} p={p} allowed={allowed(o.kind)} />)}</div>
    {mods.networkAsc && mods.surgeryBooking && !orders.some(o => o.kind === 'surgery-booking' && o.status === 'to-do') && (ascOpen ? <SendToAsc v={v} p={p} onClose={() => setAscOpen(false)} /> : <button type="button" className="sv-btn mt-2 inline-flex items-center gap-1.5" onClick={() => setAscOpen(true)} data-testid="open-send-asc"><Ico k="send" />Send request to ASC</button>)}
    <AscSentList v={v} p={p} />
    <div className="flex flex-wrap items-center gap-2 mt-2"><span className="text-[13px] sv-muted">Add:</span>{(['surgery-booking', 'follow-up', 'clearance', 'other'] as const).filter(allowed).map(k => <button key={k} type="button" className="sv-btn sm" onClick={() => newOrder(k)} data-testid={`add-order-${k}`}>{KIND_LABEL[k]}</button>)}{add && null}</div>
    <div className="sv-two mt-5">
      <section><h2 className="sv-h">After-visit summary</h2><p className="text-[13px] mb-2">Printed or saved as PDF only on demand.</p><button type="button" className="sv-btn" onClick={avs} data-testid="print-avs">Print / Save as PDF</button>
        <p className="text-[12.5px] mt-3">{!isMedical && <><button type="button" className="sv-link" onClick={() => openPanel(R('asc', 'Network ASC', p.id))}>Network ASC thread</button> · </>}<button type="button" className="sv-link" onClick={() => openPanel(R('careplan', 'Care plan', p.id))}>Care plan</button></p></section>
      <section><ChargesPanel v={v} station="Checkout" roles={ROLE_GROUP.everyone} /></section>
      {!isMedical && medRepo.patient(v.patientId) && <section className="mt-3" data-testid="checkout-quotes"><QuoteList p={medRepo.patient(v.patientId)!} compact /></section>}
    </div>
  </div>;
};
const OrderRow: React.FC<{ o: CheckoutOrder; v: MedVisit; p: MedPatient; allowed: boolean }> = ({ o, v, p, allowed }) => {
  const [actor] = useActor(); const { toast } = useSv(); const nc = nextAscCase(p.id);
  const surgeon = v.provider; const blocks = ascBlocks().filter(b => b.surgeon === surgeon && b.date >= isoDay()).sort((a, b) => a.date.localeCompare(b.date));
  const procGuess = (o.detail.split(' · ')[0] || nc?.procedure || v.reason || '').trim();
  const [f, setF] = useState(() => ({ procedure: procGuess, block: blocks[0]?.id || '', time: blocks[0]?.start || '07:30 AM', duration: '90', fuDate: addDays(isoDay(), /6 weeks/.test(o.text) ? 42 : nc ? Math.max(7, Math.round((new Date(nc.date).getTime() - Date.now()) / 864e5) + 7) : 14), fuTime: '09:00 AM', fuType: o.kind === 'follow-up' ? (activeVisitTypes().find(t => t.category === 'post-op') || activeVisitTypes()[0])?.name || 'Follow-up visit' : 'Follow-up visit', to: (p => { const pcp = p?.careTeam.find(c => /primary care|internal/i.test(c.role)); return pcp ? `${pcp.name} · ${pcp.role}` : 'Primary care physician (patient’s PCP)'; })(medRepo.patient(o.patientId)), question: o.detail }));
  const finish = (result: string) => { saveOrder({ ...o, status: 'done', doneBy: actor.name, doneAt: new Date().toISOString(), result }, actor.name, actor.role, `Checkout done: ${o.text} → ${result}`); toast(result); };
  const fu = () => { const nv: MedVisit = { id: uid('visit'), patientId: p.id, date: f.fuDate, time: f.fuTime, durationMin: visitTypeDef(f.fuType).durationMin, provider: v.provider, room: v.room, visitType: f.fuType, reason: o.text, step: 'scheduled', problemIds: v.problemIds, createdAt: new Date().toISOString(), createdBy: actor.name }; medRepo.saveVisit(nv); repo.audit({ caseId: nv.id, user: actor.name, role: actor.role, action: 'visit.create', detail: `${f.fuType} booked ${usDate(nv.date)} ${nv.time} at checkout` }); finish(`${f.fuType} booked ${usDate(nv.date)} ${nv.time}`); };
  const letter = () => { printHtml(`Pre-op clearance request · ${p.name}`, `<h1>Request for pre-operative evaluation</h1><p>To: ${esc(f.to)}<br>From: ${esc(v.provider)}, ${esc(getSettings().practiceName)}<br>Date: ${usDate(isoDay())}</p><p>Patient: ${esc(p.name)} · DOB ${esc(p.dob)}</p><p>Planned procedure: ${esc(nc?.procedure || f.procedure || '')}${nc ? ` on ${usDate(nc.date)} at ${esc(nc.ascName)}` : ''}</p><h2>Question</h2><p>${esc(f.question)}</p><h2>Active medications</h2><ul>${medRepo.meds(p.id).filter(m => m.status === 'active').map(m => `<li>${esc(m.name)} ${esc(m.dose)} ${esc(m.frequency)}</li>`).join('')}</ul><p><i>Fictional test data · Surgery.Vityls simulation · not sent</i></p>`); finish(`Clearance request prepared for ${f.to} (printed; sending is simulated)`); };
  return <div className="py-3" data-testid={`order-${o.kind}`}>
    <div className="flex flex-wrap items-baseline gap-2"><b className="text-[14px]">{o.text}</b><span className="sv-tag">{KIND_LABEL[o.kind]}</span>{o.status === 'done' ? <span className="sv-tag ok">Done · {o.doneBy}</span> : o.status === 'cancelled' ? <span className="sv-tag">Cancelled</span> : <span className="sv-tag warn">To do</span>}<span className="text-[11.5px] sv-muted">{o.source}</span></div>
    {o.status === 'done' && <p className="text-[13px] mt-0.5">{o.result}</p>}
    {o.status === 'to-do' && !allowed && <p className="text-[12.5px] sv-muted">This module is switched off for the practice.</p>}
    {o.status === 'to-do' && allowed && <div className="mt-2">
      {o.kind === 'surgery-booking' && <>
        {nc && <p className="text-[12.5px] sv-muted mb-1">Already on an ASC schedule: {nc.procedure} {usDate(nc.date)} {nc.time} ({nc.status}). <button type="button" className="sv-link" onClick={() => finish(`Confirmed existing case: ${nc.procedure} ${usDate(nc.date)} ${nc.time}`)} data-testid="book-confirm-existing">Confirm the existing case instead</button></p>}
        <SendToAsc v={v} p={p} onSent={pk => finish(`Sent to ${pk.facilityName}: scheduling form + ${pk.docs.length} document(s) for ${pk.form.procedure} (simulated)`)} />
      </>}
      {o.kind === 'follow-up' && <div className="flex flex-wrap items-end gap-2">
        <label><span className="sv-label">Visit type</span><select className="sv-input" value={f.fuType} onChange={e => setF({ ...f, fuType: e.target.value })} data-testid="fu-type">{activeVisitTypes().map(t => <option key={t.id} value={t.name}>{t.name}</option>)}</select></label>
        <label><span className="sv-label">Date</span><input type="date" className="sv-input" value={f.fuDate} onChange={e => setF({ ...f, fuDate: e.target.value })} data-testid="fu-date" /></label>
        <label style={{ width: 110 }}><span className="sv-label">Time</span><input className="sv-input" value={f.fuTime} onChange={e => setF({ ...f, fuTime: e.target.value })} /></label>
        <button type="button" className="sv-btn primary" onClick={fu} data-testid="fu-book">Book follow-up</button></div>}
      {o.kind === 'clearance' && <div className="grid gap-2" style={{ gridTemplateColumns: 'minmax(0,1fr) minmax(0,2fr) auto', alignItems: 'end' }}>
        <label><span className="sv-label">To</span><input className="sv-input" value={f.to} onChange={e => setF({ ...f, to: e.target.value })} data-testid="clr-to" /></label>
        <label><span className="sv-label">Question for the clinician</span><input className="sv-input" value={f.question} onChange={e => setF({ ...f, question: e.target.value })} /></label>
        <button type="button" className="sv-btn primary" onClick={letter} data-testid="clr-letter">Prepare request letter</button></div>}
      {o.kind === 'other' && <div className="flex gap-2"><input className="sv-input" placeholder="What was done" value={f.question} onChange={e => setF({ ...f, question: e.target.value })} /><button type="button" className="sv-btn" onClick={() => finish(f.question || 'Done')}>Mark done</button></div>}
      <button type="button" className="sv-link text-[12px] mt-1" onClick={() => saveOrder({ ...o, status: 'cancelled', doneBy: actor.name, doneAt: new Date().toISOString() }, actor.name, actor.role, `Checkout to-do cancelled: ${o.text}`)}>Cancel this to-do</button>
    </div>}
  </div>;
};

/* ---------------- Visit record ---------------- */
export const RecordStep: React.FC<{ v: MedVisit; p: MedPatient }> = ({ v, p }) => {
  useMedTick(); const n = nurseAdmission(v.id); const s = scribeSession(v.id); const orders = checkoutOrders(v.id); const cases = ascCasesFor(p.id).filter(c => (c as any).visitId === v.id);
  return <div className="space-y-4" data-testid="visit-record-sv">
    <div className="sv-two">
      <section><h2 className="sv-h">Nurse admission</h2>{n ? <p className="text-[13px]">{n.chiefComplaint || '—'} · pain {n.pain || '—'} · allergies {n.allergiesConfirmed ? 'confirmed' : 'not confirmed'} · meds {n.medsReviewed ? 'reviewed' : 'not reviewed'}{n.anticoagulantLastDose ? ` · last dose ${n.anticoagulantLastDose}` : ''}{n.escort ? ` · escort ${n.escort}` : ''} · {n.by} {fmtDateTime(n.at)}</p> : <p className="sv-muted text-[13px]">Not recorded.</p>}
        <h2 className="sv-h mt-3">Ambient scribe (simulated)</h2><p className="text-[13px]">{s.startedAt ? `${s.lines.length} transcript lines · started by ${s.startedBy} ${fmtDateTime(s.startedAt)} · ${s.suggestions.filter(x => x.status === 'initialed').length} suggestion(s) initialed, ${s.suggestions.filter(x => x.status === 'dismissed').length} dismissed` : 'Not used.'}</p></section>
      <section><h2 className="sv-h">Checkout</h2>{orders.length ? <ul className="text-[13px] space-y-0.5">{orders.map(o => <li key={o.id}>{o.status === 'done' ? '✓' : o.status === 'cancelled' ? '✕' : '○'} {o.text}{o.result ? ` — ${o.result}` : ''}</li>)}</ul> : <p className="sv-muted text-[13px]">No to-dos.</p>}
        {cases.length > 0 && <p className="text-[12.5px] sv-muted mt-1">{cases.length} booking request(s) visible on the schedule and the ASC thread.</p>}</section>
    </div>
    <div className="sv-flat"><VisitRecord v={v} p={p} /></div>
  </div>;
};

/* ---------------- v1.5 · moved from the retired station page into the new workspaces ---------------- */
export type VStep = 'check-in' | 'rooming' | 'provider' | 'checkout';
const VLABEL: Record<VStep, string> = { 'check-in': 'Check-in', rooming: 'Nurse intake', provider: 'Surgeon', checkout: 'Checkout' };
/** Verify-with-PIN sign-off for a station (same rule as the old station page: your own PIN, name + time recorded). Never required to move on. */
/** v11: the PIN sign-off of an office station (stamps the time, advances the visit). Shared by StationVerify and the core station engine. */
export function verifyVisitStep(v: MedVisit, step: VStep, w: { name: string; role: string }, session: string) {
  if (step === 'check-in') { stamp(v, 'visit.arrived', 'Arrived'); stamp(v, 'visit.checkedIn', 'Checked in'); }
  if (step === 'rooming') stamp(v, 'visit.roomed', 'Roomed'); if (step === 'provider') stamp(v, 'visit.providerOut', 'Provider out'); if (step === 'checkout') stamp(v, 'visit.checkedOut', 'Checked out');
  advanceVisit(medRepo.visit(v.id)!, step, w.name, w.role); repo.audit({ caseId: v.id, user: w.name, role: w.role, action: 'staff.pin', detail: `${VLABEL[step]} attested with ${w.name}’s own PIN (session: ${session})` });
}
export const VISIT_SIGN_ROLES = (step: VStep) => SIGN_ROLES[step];
export const StationVerify: React.FC<{ v: MedVisit; step: VStep }> = ({ v, step }) => {
  useMedTick(); const [actor] = useActor(); const { toast } = useSv(); const [signing, setSigning] = useState(false); const ver = repo.getStationVerification(v.id)[step];
  const verify = (w: Signer) => { verifyVisitStep(v, step, w, actor.name); setSigning(false); toast(`${VLABEL[step]} verified by ${w.name}.`); };
  return <div className="sv-verify" data-testid={`ws-verify-${step}`}>
    <span className="text-[13.5px]">{ver ? <span className="text-[var(--ok)] font-semibold" data-testid="ws-verified">✓ {VLABEL[step]} verified by {ver.by} · {fmtDateTime(ver.at)}</span> : <>Sign off this step with your own PIN when it is done. Your name and the time are recorded. Optional: nothing waits on it.</>}</span>
    <button type="button" className="sv-btn" onClick={() => setSigning(true)} data-testid={`verify-${step}`}>{ver ? 'Verify again' : `Verify ${VLABEL[step].toLowerCase()} with PIN`}</button>
    {signing && <PinSign title={`Verify ${VLABEL[step].toLowerCase()}`} statement={<>I attest that the {VLABEL[step].toLowerCase()} step for {medRepo.patient(v.patientId)?.name} is complete.</>} roles={SIGN_ROLES[step]} confirmLabel="Verify" onClose={() => setSigning(false)} onSigned={verify} />}
  </div>;
};
/** Identity confirmation (name, DOB, photo ID) with the demographics table. */
export const IdentityCheck: React.FC<{ v: MedVisit; p: MedPatient }> = ({ v, p }) => {
  useMedTick(); const [actor] = useActor(); const idOk = repo.getAudit(v.id).find(x => x.action === 'checkin.identity');
  return <div data-testid="ws-identity"><table className="sv-table"><tbody>{([['Name', p.name], ['Date of birth', p.dob], ['Phone', p.phone], ['Email', p.email || '—'], ['Language', p.language], ['Insurance', p.insurance || 'Self-pay / not recorded'], ['Emergency contact', p.emergencyContact || 'Not recorded']] as const).map(([k, x]) => <tr key={k}><td className="sv-muted" style={{ width: 150 }}>{k}</td><td>{x}</td></tr>)}</tbody></table>
    <div className="mt-2">{idOk ? <span className="sv-tag ok" data-testid="ws-id-ok">✓ Identity confirmed by {idOk.user} · {fmtDateTime(idOk.at)}</span> : <button type="button" className="sv-btn" onClick={() => { repo.audit({ caseId: v.id, user: actor.name, role: actor.role, action: 'checkin.identity', detail: 'Identity confirmed with the patient (name + date of birth, photo ID)' }); window.dispatchEvent(new Event('vityls-med-updated')); }} data-testid="checkin-id">Identity confirmed (name, DOB, photo ID)</button>}</div></div>;
};
/** Arrived / Check-in buttons that stamp the time (no time pickers). */
export const CheckInTimes: React.FC<{ v: MedVisit }> = ({ v }) => {
  useMedTick(); const [actor] = useActor(); const { toast } = useSv(); const facts = repo.getFacts(v.id);
  const t = (id: string) => facts[id]?.value ? { at: String(facts[id].value), by: facts[id].source?.by } : null; const arr = t('visit.arrived'); const chk = t('visit.checkedIn');
  return <div className="flex flex-wrap gap-2 items-center text-[13.5px]" data-testid="checkin-times">
    {arr ? <span className="sv-tag ok" data-testid="ws-arrived">Arrived {arr.at}{arr.by ? ` · ${arr.by}` : ''}</span> : <button type="button" className="btn" onClick={() => { arriveVisit(v, actor.name, actor.role); toast('Arrival time recorded.'); }} data-testid="checkin-arrive">Patient arrived · record time</button>}
    {chk ? <span className="sv-tag ok" data-testid="ws-checkedin">Checked in {chk.at}{chk.by ? ` · ${chk.by}` : ''}</span> : <button type="button" className="btn pri" onClick={() => { checkInVisit(medRepo.visit(v.id) || v, actor.name, actor.role); toast('Check-in time recorded.'); }} data-testid="checkin-now">Check in · record time</button>}
    <span className="flp-note">The tablet stamps the time when you tap.</span></div>;
};
