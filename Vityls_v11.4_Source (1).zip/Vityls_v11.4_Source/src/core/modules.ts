/*
 * Vityls Core · module registry (core-modules v1.0).
 * Every fundamental function is a module on top of Vityls Core. A module declares what it needs from Core, what other
 * modules it depends on (hard) or enhances (soft), and every surface it contributes: nav entries, routes (app tabs),
 * Practice panels, chart tabs/cards, Nightingale commands and station steps. The app shell renders a surface only when
 * its module is entitled for the active practice (src/core/entitlements.ts).
 * Editions (ASC, Surgery, Medical, later MedSpa, Chiropractic) are bundles of these modules + terminology + templates.
 */
export type ModuleId = 'email-intake' | 'scheduling' | 'chart' | 'stations-workflow' | 'forms' | 'messages' | 'billing' | 'records-packets' | 'reports' | 'photos-bodycharts' | 'asc-perioperative' | 'portal-link' | 'patient-portal' | 'surgical-planning';
export type CoreService = 'tenant' | 'users-pins' | 'patients' | 'documents' | 'audit' | 'nightingale' | 'outbox' | 'entitlements';

export interface ModuleDef {
  id: ModuleId; name: string; short: string; description: string; pitch: string[];
  core: CoreService[]; requires: ModuleId[]; enhances: ModuleId[];
  nav: { tab: string; label: string; order: number }[];
  routes: string[];                      // app tabs this module owns
  practicePanels: string[];              // Practice › items (tab ids)
  chartSurfaces: string[];               // chart tabs / cards / buttons
  nightingale: string[];                 // Nightingale commands / chips it contributes
  stationSteps: string[];                // station workflow steps
  storage: string[];                     // storage key prefixes (for Henry's per-module tables)
  standalone: string;                    // what it does when it is the only module (or without the chart)
  trialDays: number; priceHint: string;
  audience?: 'practice' | 'patient';      // patient = a patient-facing app on Core with patient_entitlements (Portal)
}

export const MODULES: ModuleDef[] = [
  { id: 'email-intake', name: 'AI Email Intake', short: 'Email intake', description: 'Nightingale reads the practice inbox, pulls surgery and appointment requests out of referral emails, files the attachments and drafts the reply.',
    pitch: ['Requests from referring offices become a review card: patient, procedure, requested date, surgeon, attachments.', 'One click files H&P, labs and insurance cards to the patient’s Documents.', 'Nightingale drafts the reply; nothing goes out until you approve it.'],
    core: ['patients', 'documents', 'nightingale', 'outbox', 'audit'], requires: [], enhances: ['scheduling', 'chart'],
    nav: [{ tab: 'email', label: 'Email intake', order: 5 }], routes: ['email'], practicePanels: [], chartSurfaces: [], nightingale: ['Review new requests', 'Draft a reply'], stationSteps: [],
    storage: ['vityls:mod:email-intake:'], standalone: 'Works alone: accepted requests create or match a minimal Core patient, file attachments to Core documents and queue a scheduling request (an appointment when Scheduling is on).',
    trialDays: 14, priceHint: 'Starter module' },
  { id: 'scheduling', name: 'Scheduling & reminders', short: 'Scheduling', description: 'Provider schedule, Today board, double-booking, block time, appointment notes, schedule PDF and automatic reminders.',
    pitch: ['Drag-free day and week schedule for every provider, with visit-type colors.', 'Today board: arrivals, check-in and who needs attention.', 'Automatic reminders by text and email (simulated).'],
    core: ['patients', 'users-pins', 'outbox', 'audit', 'nightingale'], requires: [], enhances: ['chart', 'forms', 'stations-workflow', 'email-intake'],
    nav: [{ tab: 'home', label: 'Today', order: 10 }, { tab: 'schedule', label: 'Schedule', order: 20 }], routes: ['home', 'schedule', 'surgery-settings'], practicePanels: ['surgery-settings'], chartSurfaces: ['Overview › Next visit / Past visits'], nightingale: ['Today’s schedule', 'Book a visit', 'Send reminders'], stationSteps: [],
    storage: ['vityls:med:visits', 'vityls:surgery:reminders', 'vityls:surgery:appt-notes', 'vityls:surgery:blocks', 'vityls:surgery:visittypes'], standalone: 'Works with a minimal Core patient (name, DOB, contact) when the Chart is off: opening a patient shows the Core record, not the chart.',
    trialDays: 14, priceHint: 'Per provider' },
  { id: 'chart', name: 'Patient chart', short: 'Chart', description: 'Nightingale-led patient chart: living summary, clinical record, diagnoses, notes, documents UI and timeline.',
    pitch: ['A living summary Nightingale keeps current from every document and visit.', 'Diagnoses with ICD-10, notes, labs, documents and activity in one place.'],
    core: ['patients', 'documents', 'audit', 'nightingale', 'users-pins'], requires: [], enhances: ['scheduling', 'messages', 'billing'],
    nav: [], routes: ['chart'], practicePanels: ['records-admin'], chartSurfaces: ['Overview', 'Clinical record', 'Documents', 'Notes', 'Activity'], nightingale: ['Ask about this chart', 'Summarize records'], stationSteps: [],
    storage: ['vityls:med:problems', 'vityls:med:meds', 'vityls:med:vitals', 'vityls:med:labs', 'vityls:med:intake', 'vityls:med:notes', 'vityls:surgery:diagnoses', 'vityls:surgery:contact-notes', 'vityls:surgery:doctor-notes'], standalone: 'Without Scheduling it is a records chart: documents, notes and diagnoses, with visits shown read-only.',
    trialDays: 14, priceHint: 'Per provider' },
  { id: 'stations-workflow', name: 'Stations workflow', short: 'Stations', description: 'Visit workflow from Portal/At-home and Front desk through Nursing to the provider and checkout, with ambient scribe (simulated) and PIN signing.',
    pitch: ['Every visit moves station by station with the right forms at each step.', 'Ambient scribe drafts the note; the provider signs with a PIN.'],
    core: ['users-pins', 'patients', 'audit', 'nightingale'], requires: ['scheduling', 'chart'], enhances: ['forms', 'billing'],
    nav: [], routes: ['station'], practicePanels: [], chartSurfaces: ['Visit workflow links'], nightingale: ['Open visit workflow', 'Start check-in'], stationSteps: ['Front desk', 'Nursing', 'Provider', 'Checkout'],
    storage: ['vityls:surgery:nurse', 'vityls:surgery:scribe', 'vityls:surgery:orders', 'vityls:surgery:stations'], standalone: 'Needs a visit (Scheduling) and a chart to write into; enabling it starts those too.',
    trialDays: 14, priceHint: 'Included in clinical bundles' },
  { id: 'forms', name: 'Forms & at-home', short: 'Forms', description: 'Form library, My Forms, the form editor, at-home/portal intake links and signed forms filed to Documents.',
    pitch: ['Registration, consents, HIPAA release and histories, completed at home before the visit.', 'Edit any form in the editor; signed copies file themselves.'],
    core: ['patients', 'documents', 'users-pins', 'audit', 'outbox'], requires: ['scheduling'], enhances: ['stations-workflow', 'chart'],
    nav: [], routes: ['forms', 'form-editor'], practicePanels: ['forms'], chartSurfaces: ['Signed forms'], nightingale: ['Send intake forms', 'Edit a form'], stationSteps: ['Portal/At-home forms', 'Station forms'],
    storage: ['vityls:forms', 'vityls:my-forms', 'vityls:form-'], standalone: 'With Scheduling and a minimal Core patient: send the at-home link for an appointment and file the signed form to Documents.',
    trialDays: 14, priceHint: 'Per practice' },
  { id: 'messages', name: 'Secure messages', short: 'Messages', description: 'Portal and staff messages with attachments filed straight to Documents.',
    pitch: ['One inbox for patient portal messages and staff replies.', 'Attachments file to the patient’s Documents in one click.'],
    core: ['patients', 'documents', 'outbox', 'audit', 'nightingale'], requires: [], enhances: ['chart', 'portal-link'],
    nav: [{ tab: 'messages', label: 'Messages', order: 40 }], routes: ['messages'], practicePanels: [], chartSurfaces: ['Portal messages card'], nightingale: ['Unread messages', 'Draft a reply'], stationSteps: [],
    storage: ['vityls:med:messages', 'vityls:surgery:msg-'], standalone: 'Works with Core patients; “Open chart” opens the minimal Core record when the Chart is off.',
    trialDays: 14, priceHint: 'Per practice' },
  { id: 'billing', name: 'Billing, payments & quotes', short: 'Billing', description: 'Invoices, payments, ledger, charges at checkout and cosmetic price quotes.',
    pitch: ['Quotes, deposits and payments with a running ledger.', 'Charges captured at checkout.'],
    core: ['patients', 'audit', 'outbox'], requires: [], enhances: ['chart', 'stations-workflow'],
    nav: [], routes: ['billing-hub'], practicePanels: ['billing-hub'], chartSurfaces: ['Documents › Quotes', 'Overview › Balance / Pay'], nightingale: ['Open balances', 'Make a quote'], stationSteps: ['Checkout charges'],
    storage: ['vityls:billing', 'vityls:surgery:quotes', 'vityls:surgery:payments', 'vityls:surgery:charges'], standalone: 'Invoices and payments against Core patients.',
    trialDays: 14, priceHint: 'Per practice' },
  { id: 'records-packets', name: 'Records packets (Print / Send)', short: 'Records packets', description: 'Build a records packet from documents, notes and encounters: pre-op clearance, consult report, referral; print or send, with HIPAA release check.',
    pitch: ['Presets for pre-op clearance, consult report and referral packets.', 'One PDF with cover letter, contents and page numbers; every send logged.'],
    core: ['documents', 'outbox', 'audit', 'nightingale'], requires: ['chart'], enhances: ['forms'],
    nav: [], routes: [], practicePanels: [], chartSurfaces: ['Print / Send button', 'Records sent log'], nightingale: ['Send records'], stationSteps: [],
    storage: ['vityls:surgery:packets'], standalone: 'Lives on the chart; enabling it starts the Chart too.',
    trialDays: 7, priceHint: 'Add-on' },
  { id: 'reports', name: 'Reports & performance', short: 'Reports', description: 'Practice performance: visits, diagnoses & procedures, coordinators, collections and exports.',
    pitch: ['See visits, conversions and collections at a glance.'],
    core: ['audit', 'patients'], requires: [], enhances: ['scheduling', 'billing', 'chart'],
    nav: [], routes: ['ops-hub'], practicePanels: ['ops-hub'], chartSurfaces: [], nightingale: ['Practice performance'], stationSteps: [],
    storage: [], standalone: 'Reports on whatever modules are on.',
    trialDays: 7, priceHint: 'Add-on' },
  { id: 'photos-bodycharts', name: 'Photos & body charts', short: 'Photos', description: 'Clinical photos (before/after compare), body charts and patient photo.',
    pitch: ['Before/after photos side by side; body charts drawn on the tablet.'],
    core: ['patients', 'documents', 'audit'], requires: ['chart'], enhances: ['records-packets'],
    nav: [], routes: [], practicePanels: [], chartSurfaces: ['Photos & charts tab'], nightingale: [], stationSteps: ['Body chart at the provider station'],
    storage: ['vityls:surgery:photos', 'vityls:surgery:bodycharts'], standalone: 'Lives on the chart; enabling it starts the Chart too.',
    trialDays: 7, priceHint: 'Add-on' },
  { id: 'surgical-planning', name: 'Surgical planning (2D & 3D)', short: 'Surgical planning', description: 'Plan on the patient’s photos: gentian-violet markings, excision ellipses and tension vectors in true millimeters, and a 3D view from the 6-angle photo series. Plans are filed to the chart.',
    pitch: ['Mark incisions and measure in millimeters on the pre-op photo, then review it in 3D with the patient.'],
    core: ['patients', 'documents', 'audit'], requires: ['chart'], enhances: ['photos-bodycharts'],
    nav: [], routes: [], practicePanels: [], chartSurfaces: ['Photos & charts tab: Surgical plans'], nightingale: ['“surgical plan for Ellen”'], stationSteps: ['Surgical plan step at the surgeon station'],
    storage: ['vityls:surgery:planner-plans'], standalone: 'Lives on the chart; enabling it starts the Chart too.',
    trialDays: 14, priceHint: 'Add-on' },
  { id: 'asc-perioperative', name: 'ASC perioperative', short: 'ASC periop', description: 'ASC-only: OR schedule, pre-op clearance, anesthesia, OR team, PACU, facility fees; in Surgery, sending cases to the affiliated ASC.',
    pitch: ['Operating rooms, PACU and facility fees for a surgery center.'],
    core: ['patients', 'documents', 'users-pins', 'audit'], requires: ['scheduling'], enhances: ['chart', 'forms'],
    nav: [], routes: [], practicePanels: [], chartSurfaces: ['Send to ASC'], nightingale: [], stationSteps: ['Pre-op', 'OR', 'PACU'],
    storage: ['vityls:network:'], standalone: 'Part of the ASC.Vityls full bundle.',
    trialDays: 14, priceHint: 'ASC bundle' },
  { id: 'portal-link', name: 'Patient Portal link', short: 'Portal', description: 'Connects the practice to the Vityls Patient Portal: at-home check-in, forms, messages, results and bills for patients.',
    pitch: ['Patients check in, sign forms and pay from their phone.'],
    core: ['patients', 'outbox', 'audit'], requires: [], enhances: ['forms', 'messages', 'billing'],
    nav: [{ tab: 'portal-hub', label: 'Portal', order: 45 }], routes: ['portal', 'portal-hub'], practicePanels: [], chartSurfaces: ['Portal access'], nightingale: [], stationSteps: ['Portal/At-home'],
    storage: ['vityls:med:caregivers', 'vityls:med:portal', 'vityls:portal:hub:'], standalone: 'Portal account linked to the Core patient.',
    trialDays: 14, priceHint: 'Free for patients' },
  { id: 'patient-portal', name: 'Vityls Patient Portal', short: 'Patient Portal', audience: 'patient', description: 'Standalone, patient-owned account and AI-first health journal on Vityls Core. Patients sign up without a practice; Vityls practices connect through portal-link.',
    pitch: ['Nightingale explains labs and documents and asks the right follow-up questions.', 'Connect my doctor (FHIR), records requests and provider upload links bring in records from any provider.'],
    core: ['patients', 'documents', 'nightingale', 'outbox', 'audit', 'entitlements'], requires: [], enhances: ['portal-link', 'messages', 'forms', 'billing'],
    nav: [], routes: ['portal-app'], practicePanels: [], chartSurfaces: [], nightingale: ['Explain my labs', 'Check my medications', 'Prepare for my visit', 'Connect my doctor'], stationSteps: [],
    storage: ['vityls:portal:'], standalone: 'Fully standalone: patient account, records, Nightingale. Entitlements are per patient (Free / Plus) in patient_entitlements, never per practice.',
    trialDays: 14, priceHint: 'Free + Portal Plus' },
];
export const MOD: Record<ModuleId, ModuleDef> = Object.fromEntries(MODULES.map(m => [m.id, m])) as any;
/** Practice modules only (patient apps such as the Portal are entitled per patient, not per practice). */
export const ALL_MODULE_IDS = MODULES.filter(m => m.audience !== 'patient').map(m => m.id);
export const PATIENT_MODULE_IDS = MODULES.filter(m => m.audience === 'patient').map(m => m.id);

/** Editions = bundles (+ terminology/templates, see src/edition.ts and src/surgery/medical). */
export const EDITION_BUNDLES: Record<'ASC' | 'SURGERY' | 'MEDICAL', ModuleId[]> = {
  ASC: ALL_MODULE_IDS.filter(m => m !== 'email-intake' && m !== 'surgical-planning'), // the frozen ASC.Vityls app; Email Intake is offered on top
  SURGERY: ['scheduling', 'chart', 'stations-workflow', 'forms', 'messages', 'billing', 'records-packets', 'reports', 'photos-bodycharts', 'asc-perioperative', 'portal-link', 'surgical-planning'],
  MEDICAL: ['scheduling', 'chart', 'stations-workflow', 'forms', 'messages', 'billing', 'records-packets', 'reports', 'photos-bodycharts', 'portal-link'],
};
/** Which module owns an app tab. Tabs not listed are Core (Patients list, Practice, staff, providers, profile …). */
export const TAB_MODULE: Record<string, ModuleId> = {
  email: 'email-intake', home: 'scheduling', schedule: 'scheduling', 'surgery-settings': 'scheduling', station: 'stations-workflow',
  forms: 'forms', 'form-editor': 'forms', messages: 'messages', 'billing-hub': 'billing', 'ops-hub': 'reports', portal: 'portal-link', 'portal-hub': 'portal-link', 'records-admin': 'chart',
};
/** Which module owns a storage key (for Henry's table mapping). Unmatched keys belong to Core. */
export function moduleOfKey(k: string): ModuleId | 'core' {
  let best: ModuleId | 'core' = 'core'; let len = 0;
  MODULES.forEach(m => m.storage.forEach(p => { if (k.startsWith(p) && p.length > len) { best = m.id; len = p.length; } }));
  return best;
}
/** All hard dependencies, transitively. */
export function requiresDeep(id: ModuleId, seen = new Set<ModuleId>()): ModuleId[] {
  MOD[id].requires.forEach(r => { if (!seen.has(r)) { seen.add(r); requiresDeep(r, seen); } });
  return [...seen];
}
export const dependents = (id: ModuleId) => MODULES.filter(m => m.requires.includes(id)).map(m => m.id);
