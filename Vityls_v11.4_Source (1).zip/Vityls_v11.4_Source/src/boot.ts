/* Vityls OS v11.2 · entry point: connect to the database (when configured) before the app reads its first record. */
import './edition';
import { startRemote } from './os/data/remote';
startRemote().catch(() => undefined).finally(() => { import('./main'); });
