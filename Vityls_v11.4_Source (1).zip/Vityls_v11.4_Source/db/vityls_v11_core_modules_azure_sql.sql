/* Vityls OS v11.4 · phase 2: one database for every edition (ASC, Surgery, Medical) and the patient portal.

   Schemas: core (tenant, people, patients, documents, audit), sched, chart, stations, forms, bank, billing, msg, notify,

   surgery (office surgical episodes), office (visits), asc (perioperative: the v10.8 asc schema stays as delivered), portal.

   Every table carries tenant_id; row-level security limits each request to its practice. Typed key columns for search and

   reporting, plus data_json with the full record so the app can move one family at a time from app.record. */

CREATE SCHEMA core;
GO
CREATE SCHEMA sched;
GO
CREATE SCHEMA chart;
GO
CREATE SCHEMA stations;
GO
CREATE SCHEMA forms;
GO
CREATE SCHEMA bank;
GO
CREATE SCHEMA billing;
GO
CREATE SCHEMA msg;
GO
CREATE SCHEMA notify;
GO
CREATE SCHEMA office;
GO
CREATE SCHEMA surgery;
GO
CREATE SCHEMA portal;
GO

CREATE TABLE core.tenant (  -- a practice; the edition decides the interface (one app)
  id NVARCHAR(64) NOT NULL PRIMARY KEY,
  name NVARCHAR(200) NOT NULL,
  edition NVARCHAR(10) NOT NULL CHECK (edition IN (N'ASC', N'SURGERY', N'MEDICAL')),
  plan NVARCHAR(20) NULL,
  status NVARCHAR(20) NOT NULL DEFAULT N'sandbox',
  logo_blob_url NVARCHAR(400) NULL,
  data_json NVARCHAR(MAX) NULL CHECK (data_json IS NULL OR ISJSON(data_json) = 1),
  created_at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME(), created_by NVARCHAR(200) NULL, updated_at DATETIME2(3) NULL, updated_by NVARCHAR(200) NULL
);
GO

CREATE TABLE core.tenant_module (  -- entitlements (see report/Vityls_Core_Modules_Architecture.md)
  tenant_id NVARCHAR(64) NOT NULL REFERENCES core.tenant(id),
  module_id NVARCHAR(40) NOT NULL,
  state NVARCHAR(10) NOT NULL CHECK (state IN (N'off', N'trial', N'active', N'expired')),
  trial_end DATETIME2 NULL,
  PRIMARY KEY (tenant_id, module_id)
);
GO

CREATE TABLE core.app_user (  -- one login across practices
  id UNIQUEIDENTIFIER NOT NULL PRIMARY KEY DEFAULT NEWSEQUENTIALID(),
  email NVARCHAR(320) NOT NULL UNIQUE,
  display_name NVARCHAR(200) NOT NULL,
  identity_subject NVARCHAR(200) NULL,
  created_at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME(), created_by NVARCHAR(200) NULL, updated_at DATETIME2(3) NULL, updated_by NVARCHAR(200) NULL
);
GO

CREATE TABLE core.membership (  -- a person's role in one practice (a surgeon in an office and at an ASC = two rows)
  id UNIQUEIDENTIFIER NOT NULL PRIMARY KEY DEFAULT NEWSEQUENTIALID(),
  tenant_id NVARCHAR(64) NOT NULL REFERENCES core.tenant(id),
  user_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.app_user(id),
  role NVARCHAR(60) NOT NULL,
  pin_hash NVARCHAR(200) NULL,
  active BIT NOT NULL DEFAULT 1,
  created_at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME(), created_by NVARCHAR(200) NULL, updated_at DATETIME2(3) NULL, updated_by NVARCHAR(200) NULL
);
GO

CREATE TABLE core.provider (  -- 
  id UNIQUEIDENTIFIER NOT NULL PRIMARY KEY DEFAULT NEWSEQUENTIALID(),
  tenant_id NVARCHAR(64) NOT NULL,
  user_id UNIQUEIDENTIFIER NULL REFERENCES core.app_user(id),
  display_name NVARCHAR(200) NOT NULL,
  role NVARCHAR(40) NOT NULL,
  npi NVARCHAR(10) NULL,
  email NVARCHAR(320) NULL,
  data_json NVARCHAR(MAX) NULL CHECK (data_json IS NULL OR ISJSON(data_json) = 1),
  created_at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME(), created_by NVARCHAR(200) NULL, updated_at DATETIME2(3) NULL, updated_by NVARCHAR(200) NULL
);
GO

CREATE TABLE core.patient (  -- 
  id UNIQUEIDENTIFIER NOT NULL PRIMARY KEY DEFAULT NEWSEQUENTIALID(),
  tenant_id NVARCHAR(64) NOT NULL,
  mrn NVARCHAR(40) NOT NULL,
  name NVARCHAR(200) NOT NULL,
  dob DATE NULL,
  sex NVARCHAR(10) NULL,
  phone NVARCHAR(40) NULL,
  email NVARCHAR(320) NULL,
  portal_account_id UNIQUEIDENTIFIER NULL,
  photo_blob_url NVARCHAR(400) NULL,
  data_json NVARCHAR(MAX) NULL CHECK (data_json IS NULL OR ISJSON(data_json) = 1),
  created_at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME(), created_by NVARCHAR(200) NULL, updated_at DATETIME2(3) NULL, updated_by NVARCHAR(200) NULL,
  CONSTRAINT uq_patient_mrn UNIQUE (tenant_id, mrn)
);
GO

CREATE TABLE core.document (  -- uploads, faxes, generated PDFs (bytes in Azure Blob Storage)
  id UNIQUEIDENTIFIER NOT NULL PRIMARY KEY DEFAULT NEWSEQUENTIALID(),
  tenant_id NVARCHAR(64) NOT NULL,
  patient_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.patient(id),
  subject_id UNIQUEIDENTIFIER NULL,
  doc_type NVARCHAR(80) NOT NULL,
  title NVARCHAR(300) NOT NULL,
  blob_url NVARCHAR(400) NULL,
  mime NVARCHAR(100) NULL,
  source NVARCHAR(30) NULL,
  data_json NVARCHAR(MAX) NULL CHECK (data_json IS NULL OR ISJSON(data_json) = 1),
  created_at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME(), created_by NVARCHAR(200) NULL, updated_at DATETIME2(3) NULL, updated_by NVARCHAR(200) NULL
);
GO

CREATE TABLE core.fact (  -- time stamps per visit/case
  id UNIQUEIDENTIFIER NOT NULL PRIMARY KEY DEFAULT NEWSEQUENTIALID(),
  tenant_id NVARCHAR(64) NOT NULL,
  subject_id NVARCHAR(80) NOT NULL,
  fact_key NVARCHAR(80) NOT NULL,
  value NVARCHAR(400) NULL,
  by_name NVARCHAR(200) NULL,
  at DATETIME2(3) NOT NULL
);
GO

CREATE TABLE core.flag (  -- 
  id UNIQUEIDENTIFIER NOT NULL PRIMARY KEY DEFAULT NEWSEQUENTIALID(),
  tenant_id NVARCHAR(64) NOT NULL,
  patient_id UNIQUEIDENTIFIER NULL,
  subject_id NVARCHAR(80) NULL,
  to_team NVARCHAR(40) NOT NULL,
  text NVARCHAR(1000) NOT NULL,
  status NVARCHAR(10) NOT NULL DEFAULT N'open',
  data_json NVARCHAR(MAX) NULL CHECK (data_json IS NULL OR ISJSON(data_json) = 1),
  created_at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME(), created_by NVARCHAR(200) NULL, updated_at DATETIME2(3) NULL, updated_by NVARCHAR(200) NULL
);
GO

CREATE TABLE core.audit_event (  -- append-only (no UPDATE/DELETE grants)
  id BIGINT IDENTITY PRIMARY KEY,
  tenant_id NVARCHAR(64) NOT NULL,
  subject_id NVARCHAR(80) NULL,
  action NVARCHAR(80) NOT NULL,
  detail NVARCHAR(2000) NOT NULL,
  user_name NVARCHAR(200) NOT NULL,
  role NVARCHAR(60) NULL,
  at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME()
);
GO

CREATE TABLE sched.appointment (  -- office visits (Surgery, Medical); ASC cases stay in asc.surgical_case
  id UNIQUEIDENTIFIER NOT NULL PRIMARY KEY DEFAULT NEWSEQUENTIALID(),
  tenant_id NVARCHAR(64) NOT NULL,
  patient_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.patient(id),
  provider_id UNIQUEIDENTIFIER NULL REFERENCES core.provider(id),
  starts_at DATETIME2 NOT NULL,
  duration_min INT NOT NULL,
  room NVARCHAR(40) NULL,
  visit_type NVARCHAR(80) NOT NULL,
  mode NVARCHAR(10) NOT NULL DEFAULT N'office',
  reason NVARCHAR(400) NULL,
  step NVARCHAR(20) NOT NULL,
  data_json NVARCHAR(MAX) NULL CHECK (data_json IS NULL OR ISJSON(data_json) = 1),
  created_at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME(), created_by NVARCHAR(200) NULL, updated_at DATETIME2(3) NULL, updated_by NVARCHAR(200) NULL
);
GO

CREATE TABLE sched.reminder (  -- 
  id UNIQUEIDENTIFIER NOT NULL PRIMARY KEY DEFAULT NEWSEQUENTIALID(),
  tenant_id NVARCHAR(64) NOT NULL,
  appointment_id UNIQUEIDENTIFIER NOT NULL,
  channel NVARCHAR(10) NOT NULL,
  sent_at DATETIME2 NOT NULL,
  result NVARCHAR(40) NULL,
  data_json NVARCHAR(MAX) NULL CHECK (data_json IS NULL OR ISJSON(data_json) = 1)
);
GO

CREATE TABLE chart.item (  -- clinical lists; one row per item (split per kind later if reporting needs it)
  id UNIQUEIDENTIFIER NOT NULL PRIMARY KEY DEFAULT NEWSEQUENTIALID(),
  tenant_id NVARCHAR(64) NOT NULL,
  patient_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.patient(id),
  kind NVARCHAR(20) NOT NULL CHECK (kind IN (N'problem', N'medication', N'allergy', N'vitals', N'lab', N'intake', N'care_plan', N'caregiver', N'surgical_history', N'order')),
  status NVARCHAR(20) NULL,
  recorded_at DATETIME2 NOT NULL,
  data_json NVARCHAR(MAX) NULL CHECK (data_json IS NULL OR ISJSON(data_json) = 1),
  created_at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME(), created_by NVARCHAR(200) NULL, updated_at DATETIME2(3) NULL, updated_by NVARCHAR(200) NULL
);
GO

CREATE TABLE chart.note (  -- visit notes, scribe drafts, jots, contact notes; signed notes are locked, corrections are addenda
  id UNIQUEIDENTIFIER NOT NULL PRIMARY KEY DEFAULT NEWSEQUENTIALID(),
  tenant_id NVARCHAR(64) NOT NULL,
  patient_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.patient(id),
  subject_id NVARCHAR(80) NULL,
  kind NVARCHAR(20) NOT NULL,
  status NVARCHAR(10) NOT NULL DEFAULT N'draft',
  signed_by NVARCHAR(200) NULL,
  signed_at DATETIME2 NULL,
  content_hash NVARCHAR(80) NULL,
  data_json NVARCHAR(MAX) NULL CHECK (data_json IS NULL OR ISJSON(data_json) = 1),
  created_at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME(), created_by NVARCHAR(200) NULL, updated_at DATETIME2(3) NULL, updated_by NVARCHAR(200) NULL
);
GO

CREATE TABLE chart.surgical_plan (  -- Surgical Planning module: markings, measurements and calibration in plan_json; images in Azure Blob Storage
  id UNIQUEIDENTIFIER NOT NULL PRIMARY KEY DEFAULT NEWSEQUENTIALID(),
  tenant_id NVARCHAR(64) NOT NULL,
  patient_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.patient(id),
  visit_id UNIQUEIDENTIFIER NULL,
  document_id UNIQUEIDENTIFIER NULL REFERENCES core.document(id),
  procedure_name NVARCHAR(300) NULL,
  surgeon NVARCHAR(200) NULL,
  marked_blob_url NVARCHAR(400) NULL,
  base_photo_blob_url NVARCHAR(400) NULL,
  plan_json NVARCHAR(MAX) NULL CHECK (plan_json IS NULL OR ISJSON(plan_json) = 1),
  data_json NVARCHAR(MAX) NULL CHECK (data_json IS NULL OR ISJSON(data_json) = 1),
  created_at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME(), created_by NVARCHAR(200) NULL, updated_at DATETIME2(3) NULL, updated_by NVARCHAR(200) NULL
);
GO

CREATE TABLE stations.station_record (  -- one per visit/case per station (ASC and office)
  id UNIQUEIDENTIFIER NOT NULL PRIMARY KEY DEFAULT NEWSEQUENTIALID(),
  tenant_id NVARCHAR(64) NOT NULL,
  subject_id NVARCHAR(80) NOT NULL,
  station NVARCHAR(30) NOT NULL,
  data_json NVARCHAR(MAX) NULL CHECK (data_json IS NULL OR ISJSON(data_json) = 1),
  created_at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME(), created_by NVARCHAR(200) NULL, updated_at DATETIME2(3) NULL, updated_by NVARCHAR(200) NULL,
  CONSTRAINT uq_station_record UNIQUE (tenant_id, subject_id, station)
);
GO

CREATE TABLE stations.station_record_value (  -- every answer change (talk/manual), append-only
  id BIGINT IDENTITY PRIMARY KEY,
  record_id UNIQUEIDENTIFIER NOT NULL REFERENCES stations.station_record(id),
  item_key NVARCHAR(120) NOT NULL,
  value_json NVARCHAR(MAX) NULL,
  source NVARCHAR(6) NOT NULL,
  heard_quote NVARCHAR(1000) NULL,
  confirmed BIT NOT NULL DEFAULT 1,
  by_name NVARCHAR(200) NULL,
  at DATETIME2(3) NOT NULL
);
GO

CREATE TABLE stations.station_signoff (  -- PIN signatures
  id UNIQUEIDENTIFIER NOT NULL PRIMARY KEY DEFAULT NEWSEQUENTIALID(),
  record_id UNIQUEIDENTIFIER NOT NULL REFERENCES stations.station_record(id),
  sign_key NVARCHAR(40) NOT NULL DEFAULT N'main',
  by_name NVARCHAR(200) NOT NULL,
  role NVARCHAR(60) NOT NULL,
  at DATETIME2(3) NOT NULL,
  exceptions_json NVARCHAR(MAX) NULL
);
GO

CREATE TABLE stations.checklist_version (  -- facility items per station, append-only versions
  id UNIQUEIDENTIFIER NOT NULL PRIMARY KEY DEFAULT NEWSEQUENTIALID(),
  tenant_id NVARCHAR(64) NOT NULL,
  station NVARCHAR(30) NOT NULL,
  version INT NOT NULL,
  items_json NVARCHAR(MAX) NOT NULL,
  published_by NVARCHAR(200) NOT NULL,
  published_at DATETIME2 NOT NULL
);
GO

CREATE TABLE forms.form_template (  -- form library; versions in forms.form_template_version
  id UNIQUEIDENTIFIER NOT NULL PRIMARY KEY DEFAULT NEWSEQUENTIALID(),
  tenant_id NVARCHAR(64) NOT NULL,
  file NVARCHAR(200) NOT NULL,
  title NVARCHAR(300) NOT NULL,
  published_version INT NULL,
  data_json NVARCHAR(MAX) NULL CHECK (data_json IS NULL OR ISJSON(data_json) = 1),
  created_at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME(), created_by NVARCHAR(200) NULL, updated_at DATETIME2(3) NULL, updated_by NVARCHAR(200) NULL
);
GO

CREATE TABLE forms.form_instance (  -- a filled form; signatures in forms.form_signature
  id UNIQUEIDENTIFIER NOT NULL PRIMARY KEY DEFAULT NEWSEQUENTIALID(),
  tenant_id NVARCHAR(64) NOT NULL,
  patient_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.patient(id),
  subject_id NVARCHAR(80) NULL,
  file NVARCHAR(200) NOT NULL,
  template_version INT NULL,
  status NVARCHAR(20) NOT NULL,
  data_json NVARCHAR(MAX) NULL CHECK (data_json IS NULL OR ISJSON(data_json) = 1),
  created_at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME(), created_by NVARCHAR(200) NULL, updated_at DATETIME2(3) NULL, updated_by NVARCHAR(200) NULL
);
GO

CREATE TABLE bank.answer (  -- question bank answers, once per patient (office) or case (ASC)
  id UNIQUEIDENTIFIER NOT NULL PRIMARY KEY DEFAULT NEWSEQUENTIALID(),
  tenant_id NVARCHAR(64) NOT NULL,
  patient_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.patient(id),
  question_id NVARCHAR(20) NOT NULL,
  value NVARCHAR(MAX) NULL,
  source NVARCHAR(20) NOT NULL,
  station NVARCHAR(4) NULL,
  by_name NVARCHAR(200) NULL,
  at DATETIME2(3) NOT NULL,
  confirms_json NVARCHAR(MAX) NULL
);
GO

CREATE TABLE bank.practice_override (  -- 
  tenant_id NVARCHAR(64) NOT NULL PRIMARY KEY,
  groups_json NVARCHAR(MAX) NOT NULL,
  overrides_json NVARCHAR(MAX) NOT NULL,
  version INT NOT NULL,
  created_at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME(), created_by NVARCHAR(200) NULL, updated_at DATETIME2(3) NULL, updated_by NVARCHAR(200) NULL
);
GO

CREATE TABLE billing.quote (  -- versions inside data_json
  id UNIQUEIDENTIFIER NOT NULL PRIMARY KEY DEFAULT NEWSEQUENTIALID(),
  tenant_id NVARCHAR(64) NOT NULL,
  patient_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.patient(id),
  number NVARCHAR(40) NOT NULL,
  status NVARCHAR(20) NOT NULL,
  total DECIMAL(12,2) NOT NULL,
  data_json NVARCHAR(MAX) NULL CHECK (data_json IS NULL OR ISJSON(data_json) = 1),
  created_at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME(), created_by NVARCHAR(200) NULL, updated_at DATETIME2(3) NULL, updated_by NVARCHAR(200) NULL
);
GO

CREATE TABLE billing.invoice (  -- 
  id UNIQUEIDENTIFIER NOT NULL PRIMARY KEY DEFAULT NEWSEQUENTIALID(),
  tenant_id NVARCHAR(64) NOT NULL,
  patient_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.patient(id),
  number NVARCHAR(40) NOT NULL,
  total DECIMAL(12,2) NOT NULL,
  paid DECIMAL(12,2) NOT NULL DEFAULT 0,
  status NVARCHAR(30) NOT NULL,
  data_json NVARCHAR(MAX) NULL CHECK (data_json IS NULL OR ISJSON(data_json) = 1),
  created_at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME(), created_by NVARCHAR(200) NULL, updated_at DATETIME2(3) NULL, updated_by NVARCHAR(200) NULL
);
GO

CREATE TABLE billing.payment (  -- no card numbers: processor tokens only
  id UNIQUEIDENTIFIER NOT NULL PRIMARY KEY DEFAULT NEWSEQUENTIALID(),
  tenant_id NVARCHAR(64) NOT NULL,
  patient_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.patient(id),
  receipt NVARCHAR(40) NOT NULL,
  amount DECIMAL(12,2) NOT NULL,
  method NVARCHAR(20) NOT NULL,
  processor_ref NVARCHAR(100) NULL,
  data_json NVARCHAR(MAX) NULL CHECK (data_json IS NULL OR ISJSON(data_json) = 1),
  created_at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME(), created_by NVARCHAR(200) NULL, updated_at DATETIME2(3) NULL, updated_by NVARCHAR(200) NULL
);
GO

CREATE TABLE msg.message (  -- 
  id UNIQUEIDENTIFIER NOT NULL PRIMARY KEY DEFAULT NEWSEQUENTIALID(),
  tenant_id NVARCHAR(64) NOT NULL,
  patient_id UNIQUEIDENTIFIER NULL,
  thread_id NVARCHAR(80) NULL,
  author NVARCHAR(200) NOT NULL,
  body NVARCHAR(MAX) NOT NULL,
  at DATETIME2(3) NOT NULL,
  data_json NVARCHAR(MAX) NULL CHECK (data_json IS NULL OR ISJSON(data_json) = 1)
);
GO

CREATE TABLE notify.outbox (  -- email / SMS / fax queue (2 PM schedule email: kind = daily-schedule)
  id UNIQUEIDENTIFIER NOT NULL PRIMARY KEY DEFAULT NEWSEQUENTIALID(),
  tenant_id NVARCHAR(64) NOT NULL,
  channel NVARCHAR(10) NOT NULL,
  to_address NVARCHAR(400) NOT NULL,
  subject NVARCHAR(400) NULL,
  body NVARCHAR(MAX) NOT NULL,
  kind NVARCHAR(40) NOT NULL,
  status NVARCHAR(20) NOT NULL DEFAULT N'queued',
  sent_at DATETIME2 NULL,
  created_at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME(), created_by NVARCHAR(200) NULL, updated_at DATETIME2(3) NULL, updated_by NVARCHAR(200) NULL
);
GO

CREATE TABLE surgery.episode (  -- consult to surgery to post-op in the surgeon's office; links to the ASC case by explicit hand-off
  id UNIQUEIDENTIFIER NOT NULL PRIMARY KEY DEFAULT NEWSEQUENTIALID(),
  tenant_id NVARCHAR(64) NOT NULL,
  patient_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.patient(id),
  surgeon_id UNIQUEIDENTIFIER NULL REFERENCES core.provider(id),
  status NVARCHAR(30) NOT NULL,
  asc_tenant_id NVARCHAR(64) NULL,
  asc_case_id UNIQUEIDENTIFIER NULL,
  data_json NVARCHAR(MAX) NULL CHECK (data_json IS NULL OR ISJSON(data_json) = 1),
  created_at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME(), created_by NVARCHAR(200) NULL, updated_at DATETIME2(3) NULL, updated_by NVARCHAR(200) NULL
);
GO

CREATE TABLE portal.account (  -- the patient's own account (not owned by a practice)
  id UNIQUEIDENTIFIER NOT NULL PRIMARY KEY DEFAULT NEWSEQUENTIALID(),
  email NVARCHAR(320) NOT NULL UNIQUE,
  identity_subject NVARCHAR(200) NULL,
  data_json NVARCHAR(MAX) NULL CHECK (data_json IS NULL OR ISJSON(data_json) = 1),
  created_at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME(), created_by NVARCHAR(200) NULL, updated_at DATETIME2(3) NULL, updated_by NVARCHAR(200) NULL
);
GO

CREATE TABLE portal.practice_link (  -- consent: which practices may deliver to / read from the account
  account_id UNIQUEIDENTIFIER NOT NULL REFERENCES portal.account(id),
  tenant_id NVARCHAR(64) NOT NULL,
  patient_id UNIQUEIDENTIFIER NOT NULL,
  scopes NVARCHAR(400) NOT NULL,
  granted_at DATETIME2 NOT NULL,
  revoked_at DATETIME2 NULL,
  PRIMARY KEY (account_id, tenant_id)
);
GO

CREATE TABLE portal.item (  -- forms, check-in, bills, messages, results, refills, appointment requests between a practice and a patient
  id UNIQUEIDENTIFIER NOT NULL PRIMARY KEY DEFAULT NEWSEQUENTIALID(),
  account_id UNIQUEIDENTIFIER NOT NULL REFERENCES portal.account(id),
  tenant_id NVARCHAR(64) NOT NULL,
  kind NVARCHAR(20) NOT NULL,
  direction NVARCHAR(10) NOT NULL CHECK (direction IN (N'practice', N'patient')),
  title NVARCHAR(300) NOT NULL,
  body NVARCHAR(MAX) NULL,
  amount DECIMAL(12,2) NULL,
  status NVARCHAR(20) NOT NULL,
  answers_json NVARCHAR(MAX) NULL,
  reply_to UNIQUEIDENTIFIER NULL,
  data_json NVARCHAR(MAX) NULL CHECK (data_json IS NULL OR ISJSON(data_json) = 1),
  created_at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME(), created_by NVARCHAR(200) NULL, updated_at DATETIME2(3) NULL, updated_by NVARCHAR(200) NULL
);
GO

CREATE TABLE portal.interaction (  -- append-only Portal history (no UPDATE/DELETE grants)
  seq BIGINT IDENTITY PRIMARY KEY,
  account_id UNIQUEIDENTIFIER NOT NULL,
  tenant_id NVARCHAR(64) NULL,
  actor NVARCHAR(200) NOT NULL,
  role NVARCHAR(10) NOT NULL,
  action NVARCHAR(60) NOT NULL,
  item_id UNIQUEIDENTIFIER NULL,
  detail NVARCHAR(2000) NOT NULL,
  at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME()
);
GO

CREATE TABLE portal.upload_link (  -- a link a patient gives an outside doctor to upload records
  token NVARCHAR(64) NOT NULL PRIMARY KEY,
  account_id UNIQUEIDENTIFIER NOT NULL REFERENCES portal.account(id),
  recipient NVARCHAR(300) NOT NULL,
  expires_at DATETIME2 NOT NULL,
  uploads INT NOT NULL DEFAULT 0,
  revoked_at DATETIME2 NULL,
  created_at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME(), created_by NVARCHAR(200) NULL, updated_at DATETIME2(3) NULL, updated_by NVARCHAR(200) NULL
);
GO

CREATE TABLE portal.notification (  -- to the patient and each active caregiver
  id UNIQUEIDENTIFIER NOT NULL PRIMARY KEY DEFAULT NEWSEQUENTIALID(),
  to_account_id UNIQUEIDENTIFIER NOT NULL,
  profile_account_id UNIQUEIDENTIFIER NOT NULL,
  kind NVARCHAR(20) NOT NULL,
  text NVARCHAR(1000) NOT NULL,
  read_at DATETIME2 NULL,
  at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME()
);
GO

CREATE TABLE portal.caregiver_access (  -- family access with the signed consent
  id UNIQUEIDENTIFIER NOT NULL PRIMARY KEY DEFAULT NEWSEQUENTIALID(),
  owner_account_id UNIQUEIDENTIFIER NOT NULL REFERENCES portal.account(id),
  caregiver_account_id UNIQUEIDENTIFIER NULL,
  email NVARCHAR(320) NOT NULL,
  relation NVARCHAR(40) NOT NULL,
  consent_text NVARCHAR(2000) NOT NULL,
  status NVARCHAR(10) NOT NULL,
  invited_at DATETIME2 NOT NULL,
  accepted_at DATETIME2 NULL,
  revoked_at DATETIME2 NULL
);
GO

/* Row-level security: every query runs with SESSION_CONTEXT(N'tenant_id') set by the API from the signed-in user. */
CREATE SCHEMA sec;
GO
CREATE FUNCTION sec.fn_tenant(@tenant_id NVARCHAR(64)) RETURNS TABLE WITH SCHEMABINDING AS RETURN SELECT 1 AS ok WHERE @tenant_id = CAST(SESSION_CONTEXT(N'tenant_id') AS NVARCHAR(64));
GO
/* Apply to each table: CREATE SECURITY POLICY sec.tenant_policy ADD FILTER PREDICATE sec.fn_tenant(tenant_id) ON core.patient, ADD BLOCK PREDICATE sec.fn_tenant(tenant_id) ON core.patient, ... WITH (STATE = ON); */
