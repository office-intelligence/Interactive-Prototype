/* Vityls OS v11.4 · phase 1 record store (live today): server.ts /api/v1/store writes here when AZURE_SQL_CONNECTION_STRING is set.
   The server creates these on first start; this file is the same DDL for DBA review. */
IF SCHEMA_ID(N'app') IS NULL EXEC(N'CREATE SCHEMA app');
GO
IF OBJECT_ID(N'app.record') IS NULL
CREATE TABLE app.record (
  tenant_id   NVARCHAR(64)  NOT NULL,
  record_key  NVARCHAR(400) NOT NULL,
  value_json  NVARCHAR(MAX) NULL,           -- NULL = deleted (kept so other devices learn about the delete)
  updated_at  DATETIME2(3)  NOT NULL,
  updated_by  NVARCHAR(200) NOT NULL,
  CONSTRAINT pk_app_record PRIMARY KEY (tenant_id, record_key)
);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'ix_app_record_changes')
CREATE INDEX ix_app_record_changes ON app.record (tenant_id, updated_at);
GO
IF OBJECT_ID(N'app.record_history') IS NULL
CREATE TABLE app.record_history (
  history_id  BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT pk_app_record_history PRIMARY KEY,
  tenant_id   NVARCHAR(64)  NOT NULL,
  record_key  NVARCHAR(400) NOT NULL,
  value_json  NVARCHAR(MAX) NULL,
  changed_at  DATETIME2(3)  NOT NULL,
  changed_by  NVARCHAR(200) NOT NULL
);
GO
