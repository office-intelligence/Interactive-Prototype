/**
 * Utility for prefilling intake forms with known patient data and previously submitted form values.
 * Allows the patient / clinic staff to only review and update new information or modifications.
 */

export interface PatientInfoPayload {
  id?: string;
  patientId?: string;
  name?: string;
  firstName?: string;
  lastName?: string;
  dob?: string;
  age?: number | string;
  gender?: string;
  sex?: string;
  phone?: string;
  email?: string;
  address?: string;
  emergencyContact?: any;
  emergencyName?: string;
  emergencyPhone?: string;
  emergencyRelation?: string;
  insurance?: any;
  insuranceCompany?: string;
  memberId?: string;
  groupNumber?: string;
  planType?: string;
  doctor?: string;
  surgeon?: string;
  procedure?: string;
  procedureDate?: string;
  surgeryDate?: string;
  date?: string;
  pcp?: string;
  primaryPhysician?: string;
  height?: string;
  weight?: string;
  allergies?: string[] | string;
  medications?: string[] | string;
  preferredPharmacy?: any;
  [key: string]: any;
}

/**
 * Returns an enriched HTML template with all known patient fields pre-filled at the top and throughout the form.
 */
export function getPrefilledIntakeHtml(
  htmlTemplate: string,
  patient?: PatientInfoPayload | null,
  previousSavedValues?: Record<string, string | boolean>
): string {
  if (!htmlTemplate) return '';

  const ptName =
    patient?.name ||
    (patient?.firstName && patient?.lastName ? `${patient.firstName} ${patient.lastName}` : 'Sarah Wilson');
  
  const ptDob = patient?.dob || '1988-04-12';
  const ptPhone = patient?.phone || '(310) 555-0192';
  const ptEmail = patient?.email || 'sarah.wilson@example.com';
  const ptAddress = patient?.address || '10484 Wilshire Blvd, Apt 8B, Los Angeles, CA 90024';
  
  const emName =
    patient?.emergencyName ||
    (typeof patient?.emergencyContact === 'string'
      ? patient.emergencyContact.split('-')[0].replace(/\(.*?\)/g, '').trim()
      : patient?.emergencyContact?.name || 'Mark Wilson');

  const emPhone =
    patient?.emergencyPhone ||
    (typeof patient?.emergencyContact === 'string'
      ? (patient.emergencyContact.match(/[\(\d\)\s\-]{10,}/) || ['(310) 555-0199'])[0]
      : patient?.emergencyContact?.phone || '(310) 555-0199');

  const emRelation =
    patient?.emergencyRelation ||
    (patient?.emergencyContact?.relationship || 'Spouse');

  let insCompany = 'Blue Shield of California PPO';
  let insMemberId = 'XEH90218492';
  let insGroup = '882941';
  let insPlan = 'PPO Premier Choice';

  if (patient?.insurance) {
    if (typeof patient.insurance === 'string') {
      insCompany = patient.insurance.split('(')[0].trim() || insCompany;
      const memMatch = patient.insurance.match(/Member ID:?\s*([A-Za-z0-9]+)/i);
      if (memMatch) insMemberId = memMatch[1];
      const grpMatch = patient.insurance.match(/Group:?\s*([A-Za-z0-9]+)/i);
      if (grpMatch) insGroup = grpMatch[1];
    } else if (typeof patient.insurance === 'object') {
      insCompany = patient.insurance.provider || patient.insurance.company || insCompany;
      insMemberId = patient.insurance.policyNumber || patient.insurance.memberId || insMemberId;
      insGroup = patient.insurance.groupNumber || patient.insurance.group || insGroup;
      insPlan = patient.insurance.planName || patient.insurance.planType || insPlan;
    }
  }

  const doctor = patient?.surgeon || patient?.doctor || 'Dr. Alistair Sterling, MD';
  const procedure = patient?.procedure || 'Deep Plane Facelift & Neck Lift + SMAS Plication';
  const procDate = patient?.surgeryDate || patient?.procedureDate || patient?.date || '2026-08-17';
  const pcp = patient?.pcp || patient?.primaryPhysician || 'Dr. Marcus Chen, MD (Cedars-Sinai Medical Group)';
  const age = String(patient?.age || '38');
  const sex = patient?.gender || patient?.sex || 'Female';
  const height = patient?.height || `5'7"`;
  const weight = patient?.weight || '138 lbs';

  let html = htmlTemplate;

  // 1. Pre-fill Patient Name fields
  html = html.replace(
    /(<input[^>]*?(?:id|name)=["'](?:patientName|fullName|ptName|clientName|printName|certPrint|ackPrint)["'][^>]*?)(>)/gi,
    (match, p1) => {
      if (p1.includes('value=')) return match;
      return `${p1} value="${ptName}">`;
    }
  );

  // 2. Pre-fill DOB fields
  html = html.replace(
    /(<input[^>]*?(?:id|name)=["'](?:dob|ptDob|birthDate)["'][^>]*?)(>)/gi,
    (match, p1) => {
      if (p1.includes('value=')) return match;
      return `${p1} value="${ptDob}">`;
    }
  );

  // 3. Pre-fill Phone fields
  html = html.replace(
    /(<input[^>]*?(?:id|name)=["'](?:phone|ptPhone|tel|telephone)["'][^>]*?)(>)/gi,
    (match, p1) => {
      if (p1.includes('value=')) return match;
      return `${p1} value="${ptPhone}">`;
    }
  );

  // 4. Pre-fill Email fields
  html = html.replace(
    /(<input[^>]*?(?:id|name)=["'](?:email|ptEmail)["'][^>]*?)(>)/gi,
    (match, p1) => {
      if (p1.includes('value=')) return match;
      return `${p1} value="${ptEmail}">`;
    }
  );

  // 5. Pre-fill Address fields
  html = html.replace(
    /(<input[^>]*?(?:id|name)=["'](?:address|streetAddress|patientAddress)["'][^>]*?)(>)/gi,
    (match, p1) => {
      if (p1.includes('value=')) return match;
      return `${p1} value="${ptAddress}">`;
    }
  );

  // 6. Pre-fill Age
  html = html.replace(
    /(<input[^>]*?(?:id|name)=["'](?:age|ptAge)["'][^>]*?)(>)/gi,
    (match, p1) => {
      if (p1.includes('value=')) return match;
      return `${p1} value="${age}">`;
    }
  );

  // 7. Pre-fill Sex / Gender select options
  if (sex.toLowerCase().includes('female')) {
    html = html.replace(
      /(<option[^>]*?value=["']Female["'][^>]*?)(>)/gi,
      (match, p1) => (p1.includes('selected') ? match : `${p1} selected>`)
    );
  } else if (sex.toLowerCase().includes('male')) {
    html = html.replace(
      /(<option[^>]*?value=["']Male["'][^>]*?)(>)/gi,
      (match, p1) => (p1.includes('selected') ? match : `${p1} selected>`)
    );
  }

  // 8. Pre-fill Height & Weight
  html = html.replace(
    /(<input[^>]*?(?:id|name)=["']height["'][^>]*?)(>)/gi,
    (match, p1) => (p1.includes('value=') ? match : `${p1} value="${height}">`)
  );
  html = html.replace(
    /(<input[^>]*?(?:id|name)=["']weight["'][^>]*?)(>)/gi,
    (match, p1) => (p1.includes('value=') ? match : `${p1} value="${weight}">`)
  );

  // 9. Pre-fill Primary Care Physician / Referring Doctor
  html = html.replace(
    /(<input[^>]*?(?:id|name)=["'](?:primaryPhysician|pcp|physician|referringDoc)["'][^>]*?)(>)/gi,
    (match, p1) => (p1.includes('value=') ? match : `${p1} value="${pcp}">`)
  );

  // 10. Pre-fill Emergency Contact Info
  html = html.replace(
    /(<input[^>]*?(?:id|name)=["'](?:emergencyName|emContactName|emName)["'][^>]*?)(>)/gi,
    (match, p1) => (p1.includes('value=') ? match : `${p1} value="${emName}">`)
  );
  html = html.replace(
    /(<input[^>]*?(?:id|name)=["'](?:emergencyPhone|emContactPhone|emPhone)["'][^>]*?)(>)/gi,
    (match, p1) => (p1.includes('value=') ? match : `${p1} value="${emPhone}">`)
  );
  html = html.replace(
    /(<input[^>]*?(?:id|name)=["'](?:certRelation|emergencyRelation|relation)["'][^>]*?)(>)/gi,
    (match, p1) => (p1.includes('value=') ? match : `${p1} value="${emRelation}">`)
  );

  // 11. Pre-fill Insurance fields
  html = html.replace(
    /(<input[^>]*?(?:id|name)=["'](?:insCompany|insuranceCompany|carrier)["'][^>]*?)(>)/gi,
    (match, p1) => (p1.includes('value=') ? match : `${p1} value="${insCompany}">`)
  );
  html = html.replace(
    /(<input[^>]*?(?:id|name)=["'](?:memberId|subscriberId|policyNumber)["'][^>]*?)(>)/gi,
    (match, p1) => (p1.includes('value=') ? match : `${p1} value="${insMemberId}">`)
  );
  html = html.replace(
    /(<input[^>]*?(?:id|name)=["'](?:groupNumber|groupNum|secGroup)["'][^>]*?)(>)/gi,
    (match, p1) => (p1.includes('value=') ? match : `${p1} value="${insGroup}">`)
  );
  html = html.replace(
    /(<input[^>]*?(?:id|name)=["'](?:planName|planType)["'][^>]*?)(>)/gi,
    (match, p1) => (p1.includes('value=') ? match : `${p1} value="${insPlan}">`)
  );

  // 12. Pre-fill Surgeon and Procedure Date
  html = html.replace(
    /(<input[^>]*?(?:id|name)=["'](?:surgeon|doctor)["'][^>]*?)(>)/gi,
    (match, p1) => (p1.includes('value=') ? match : `${p1} value="${doctor}">`)
  );
  html = html.replace(
    /(<input[^>]*?(?:id|name)=["'](?:procedureDate|surgDate|procDate|surgeryDate)["'][^>]*?)(>)/gi,
    (match, p1) => (p1.includes('value=') ? match : `${p1} value="${procDate}">`)
  );

  // 13. Pre-fill Cardholder Name for CC Auth
  html = html.replace(
    /(<input[^>]*?(?:id|name)=["']cardName["'][^>]*?)(>)/gi,
    (match, p1) => (p1.includes('value=') ? match : `${p1} value="${ptName}">`)
  );
  html = html.replace(
    /(<input[^>]*?(?:id|name)=["']zip["'][^>]*?)(>)/gi,
    (match, p1) => (p1.includes('value=') ? match : `${p1} value="90024">`)
  );

  // 14. Check default checkboxes (Advance Directives acknowledgement, HIPAA acknowledgment)
  html = html.replace(
    /(<input[^>]*?id=["'](?:advUnderstood|advNo|ackHipaa|ackInfo)["'][^>]*?)(>)/gi,
    (match, p1) => (p1.includes('checked') ? match : `${p1} checked>`)
  );

  // 15. Apply any previous user inputs if passed
  if (previousSavedValues) {
    Object.entries(previousSavedValues).forEach(([key, val]) => {
      if (typeof val === 'boolean') {
        if (val) {
          html = html.replace(
            new RegExp(`(<input[^>]*?(?:id|name)=["']${key}["'][^>]*?)(>)`, 'gi'),
            (match, p1) => (p1.includes('checked') ? match : `${p1} checked>`)
          );
        }
      } else if (typeof val === 'string' && val.trim()) {
        html = html.replace(
          new RegExp(`(<input[^>]*?(?:id|name)=["']${key}["'][^>]*?)(>)`, 'gi'),
          (match, p1) => {
            if (p1.includes('value=')) {
              return p1.replace(/value=["'][^"']*?["']/, `value="${val}"`) + '>';
            }
            return `${p1} value="${val}">`;
          }
        );
      }
    });
  }

  return html;
}
