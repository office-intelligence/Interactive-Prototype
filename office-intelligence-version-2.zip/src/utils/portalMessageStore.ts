import { PortalMessage } from '../data/portalData';

// Multi-patient initial default seed messages for the entire practice network
export const SEED_PORTAL_MESSAGES: PortalMessage[] = [
  // Danielle Vance (114202)
  {
    id: 'msg-vance-1',
    patientId: '114202',
    providerId: 'dr-sterling',
    practiceName: 'Aura Vanguard Surgical & Aesthetic Pavilion',
    sender: 'provider',
    senderName: 'Camila Rojas, RN',
    senderTitle: 'Lead Surgical Coordinator (Dr. Sterling)',
    timestamp: '9:15 AM',
    date: 'July 10, 2026',
    category: 'Clinical Question',
    content: 'Good morning Danielle! We have reviewed your laboratory results from Quest and your 12-lead EKG. Everything looks completely normal and cleared. Please remember to complete the remaining two intake questionnaires on your portal before Sunday.',
    read: true
  },
  {
    id: 'msg-vance-2',
    patientId: '114202',
    providerId: 'dr-sterling',
    practiceName: 'Aura Vanguard Surgical & Aesthetic Pavilion',
    sender: 'patient',
    senderName: 'Danielle Vance',
    timestamp: '11:20 AM',
    date: 'July 10, 2026',
    category: 'Clinical Question',
    content: 'Thank you Camila! I have filled out the privacy forms and will finish the surgical consent today. Should I still take my regular morning blood pressure medication on Monday morning with a small sip of water?',
    read: true
  },
  {
    id: 'msg-vance-3',
    patientId: '114202',
    providerId: 'dr-cruz',
    practiceName: 'Vanguard Anesthesia & Perioperative Consultants',
    sender: 'provider',
    senderName: 'Dr. Raymond Cruz, MD',
    senderTitle: 'Attending Anesthesiologist',
    timestamp: '1:45 PM',
    date: 'July 10, 2026',
    category: 'Clinical Question',
    content: 'Hello Danielle, yes! You may take your morning blood pressure medication at 5:30 AM with no more than one small tablespoon of water. Otherwise, maintain strict fasting (no other liquids, coffee, or food) from midnight onward. See you Monday morning in Pre-Op Bay 1!',
    read: true
  },
  {
    id: 'msg-vance-4',
    patientId: '114202',
    providerId: 'dr-chen',
    practiceName: 'Chen Dermatology & Cutaneous Laser Center',
    sender: 'provider',
    senderName: 'Dr. Evelyn Chen, MD',
    senderTitle: 'Consulting Dermatologist',
    timestamp: '3:10 PM',
    date: 'July 09, 2026',
    category: 'Clinical Question',
    content: 'Hi Danielle, I have uploaded your post-surgical scar care protocol to your portal documents. We will schedule your vascular laser check-in 4 weeks following Dr. Sterling’s surgical procedure. Wishing you a smooth recovery!',
    read: true
  },
  {
    id: 'msg-vance-5',
    patientId: '114202',
    providerId: 'dr-sterling',
    practiceName: 'Aura Vanguard Surgical & Aesthetic Pavilion',
    sender: 'patient',
    senderName: 'Danielle Vance',
    timestamp: '7:40 AM',
    date: 'July 12, 2026',
    category: 'Prescription Refill',
    content: 'Hi Dr. Sterling team, I wanted to double check if my Celebrex and anti-nausea medication prescriptions were called into Walgreens on Wilshire Blvd so my husband can pick them up ahead of time.',
    read: false
  },

  // Elena Rostova (115088)
  {
    id: 'msg-rostova-1',
    patientId: '115088',
    providerId: 'dr-mercer',
    practiceName: 'Vanguard Facial Aesthetics & Rhinology Institute',
    sender: 'patient',
    senderName: 'Elena Rostova',
    timestamp: '8:30 AM',
    date: 'July 12, 2026',
    category: 'Clinical Question',
    content: 'Good morning Dr. Mercer. I completed all 9 clinical forms on the portal. For my rhinoplasty tomorrow, should I stop using my topical nasal saline spray tonight or continue it through the morning?',
    read: false
  },
  {
    id: 'msg-rostova-2',
    patientId: '115088',
    providerId: 'dr-mercer',
    practiceName: 'Vanguard Facial Aesthetics & Rhinology Institute',
    sender: 'provider',
    senderName: 'Dr. Julian Mercer, MD',
    senderTitle: 'Attending Facial Surgeon',
    timestamp: '9:05 AM',
    date: 'July 12, 2026',
    category: 'Clinical Question',
    content: 'Elena, thank you for completing the full packet. Please stop the saline spray tonight at 10 PM. We will perform gentle mucosal preparation in the OR tomorrow. Get good rest!',
    read: true
  },
  {
    id: 'msg-rostova-3',
    patientId: '115088',
    providerId: 'dr-mercer',
    practiceName: 'Vanguard Facial Aesthetics & Rhinology Institute',
    sender: 'patient',
    senderName: 'Elena Rostova',
    timestamp: '1:10 PM',
    date: 'July 12, 2026',
    category: 'Scheduling',
    content: 'Understood. Also, my brother Mikhail will be picking me up after recovery. Can he wait in the Vanguard 3rd floor lounge?',
    read: false
  },

  // Sarah Kensington (113561)
  {
    id: 'msg-kensington-1',
    patientId: '113561',
    providerId: 'dr-sterling',
    practiceName: 'Aura Vanguard Surgical & Aesthetic Pavilion',
    sender: 'patient',
    senderName: 'Sarah Kensington',
    timestamp: '6:50 AM',
    date: 'July 11, 2026',
    category: 'Clinical Question',
    content: 'Hello Dr. Sterling, I reviewed the 3D Vectra implant exchange sizing notes. I am very confident with the Mentor cohesive gel 375cc moderate plus profile. Are those secured in the sterile supply room for my case?',
    read: true
  },
  {
    id: 'msg-kensington-2',
    patientId: '113561',
    providerId: 'dr-sterling',
    practiceName: 'Aura Vanguard Surgical & Aesthetic Pavilion',
    sender: 'provider',
    senderName: 'Camila Rojas, RN',
    senderTitle: 'Lead Surgical Coordinator',
    timestamp: '8:15 AM',
    date: 'July 11, 2026',
    category: 'Clinical Question',
    content: 'Hi Sarah! Yes, Mentor has confirmed delivery of both primary and secondary size sets (350cc, 375cc, 400cc) to our OR sterile repository. Dr. Sterling will mark and finalize during your pre-op holding encounter.',
    read: true
  },
  {
    id: 'msg-kensington-3',
    patientId: '113561',
    providerId: 'dr-sterling',
    practiceName: 'Aura Vanguard Surgical & Aesthetic Pavilion',
    sender: 'patient',
    senderName: 'Sarah Kensington',
    timestamp: '4:25 PM',
    date: 'July 12, 2026',
    category: 'Billing',
    content: 'Hi Billing Team, I submitted my insurance copay through the portal credit card terminal. Can you verify receipt and send an itemized statement to my portal vault?',
    read: false
  },

  // Patricia Holloway (113850)
  {
    id: 'msg-holloway-1',
    patientId: '113850',
    providerId: 'dr-sterling',
    practiceName: 'Aura Vanguard Surgical & Aesthetic Pavilion',
    sender: 'patient',
    senderName: 'Patricia Holloway',
    timestamp: '7:15 AM',
    date: 'July 12, 2026',
    category: 'Clinical Question',
    content: 'Urgent: I saw on my portal check-in that my 12-lead EKG report from Pacific Coast Cardiology was still listed as pending. My cardiologist Dr. Vance said she faxed it yesterday at 3 PM. Can you please confirm you received it?',
    read: false
  },

  // Sophia Caldwell (114091)
  {
    id: 'msg-caldwell-1',
    patientId: '114091',
    providerId: 'dr-sterling',
    practiceName: 'Aura Vanguard Surgical & Aesthetic Pavilion',
    sender: 'patient',
    senderName: 'Sophia Caldwell',
    timestamp: '10:45 AM',
    date: 'July 11, 2026',
    category: 'Clinical Question',
    content: 'Hi care team, I uploaded my updated photo of the abdominal incision site from last week. There is minimal redness. Looking forward to tomorrow morning!',
    read: true
  },
  {
    id: 'msg-caldwell-2',
    patientId: '114091',
    providerId: 'dr-sterling',
    practiceName: 'Aura Vanguard Surgical & Aesthetic Pavilion',
    sender: 'provider',
    senderName: 'Dr. Alistair Sterling, MD',
    senderTitle: 'Attending Surgeon',
    timestamp: '11:30 AM',
    date: 'July 11, 2026',
    category: 'Clinical Question',
    content: 'Sophia, wound review looks excellent with healthy granulation tissue and clean margins. We will perform the layered scar revision and cosmetic closure as planned at 8:45 AM.',
    read: true
  }
];

const STORAGE_PREFIX = 'portal_msgs_';
const ALL_MESSAGES_KEY = 'portal_all_messages_v2';
const EVENT_NAME = 'portal_messages_updated';

// Initialize global storage if not present
export function initMessageStore(): void {
  if (typeof window === 'undefined') return;

  const existingAll = localStorage.getItem(ALL_MESSAGES_KEY);
  if (!existingAll) {
    localStorage.setItem(ALL_MESSAGES_KEY, JSON.stringify(SEED_PORTAL_MESSAGES));
  }

  // Also seed per-patient keys for backwards compatibility with portal page
  const patientIds = Array.from(new Set(SEED_PORTAL_MESSAGES.map((m) => m.patientId)));
  patientIds.forEach((pid) => {
    const existing = localStorage.getItem(`${STORAGE_PREFIX}${pid}`);
    if (!existing) {
      const patientMsgs = SEED_PORTAL_MESSAGES.filter((m) => m.patientId === pid);
      localStorage.setItem(`${STORAGE_PREFIX}${pid}`, JSON.stringify(patientMsgs));
    }
  });
}

// Get all messages across the entire practice
export function getAllPortalMessages(): PortalMessage[] {
  if (typeof window === 'undefined') return SEED_PORTAL_MESSAGES;
  try {
    initMessageStore();
    const stored = localStorage.getItem(ALL_MESSAGES_KEY);
    if (stored) {
      return JSON.parse(stored);
    }
  } catch (err) {
    console.error('Failed to parse all portal messages', err);
  }
  return SEED_PORTAL_MESSAGES;
}

// Case ID to MRN normalization map
export function normalizePatientId(id?: string): string {
  if (!id) return '114202';
  const mapping: Record<string, string> = {
    'case-new-1': '115088',
    'case-0': '113561',
    'case-1': '114202',
    'case-2': '113850',
    'case-3': '114091',
    'case-4': '114320',
  };
  return mapping[id] || id;
}

// Get messages for a specific patient
export function getMessagesForPatient(patientId: string): PortalMessage[] {
  const normId = normalizePatientId(patientId);
  if (typeof window === 'undefined') {
    return SEED_PORTAL_MESSAGES.filter((m) => m.patientId === normId || m.patientId === patientId);
  }
  try {
    // Try normalized and raw per-patient keys
    const perPatient = localStorage.getItem(`${STORAGE_PREFIX}${normId}`) || localStorage.getItem(`${STORAGE_PREFIX}${patientId}`);
    if (perPatient) {
      return JSON.parse(perPatient);
    }

    // Fallback to filtering from all messages
    const all = getAllPortalMessages();
    const filtered = all.filter((m) => m.patientId === normId || m.patientId === patientId);
    if (filtered.length > 0) {
      localStorage.setItem(`${STORAGE_PREFIX}${normId}`, JSON.stringify(filtered));
      return filtered;
    }
  } catch (err) {
    console.error(`Failed to get messages for patient ${patientId}`, err);
  }
  return SEED_PORTAL_MESSAGES.filter((m) => m.patientId === normId || m.patientId === patientId);
}

// Save messages for a specific patient & update master store
export function saveMessagesForPatient(patientId: string, messages: PortalMessage[]): void {
  if (typeof window === 'undefined') return;
  const normId = normalizePatientId(patientId);
  try {
    localStorage.setItem(`${STORAGE_PREFIX}${normId}`, JSON.stringify(messages));
    if (normId !== patientId) {
      localStorage.setItem(`${STORAGE_PREFIX}${patientId}`, JSON.stringify(messages));
    }

    // Update the master list
    const all = getAllPortalMessages().filter((m) => m.patientId !== normId && m.patientId !== patientId);
    const updatedAll = [...all, ...messages];
    localStorage.setItem(ALL_MESSAGES_KEY, JSON.stringify(updatedAll));

    // Broadcast update event
    window.dispatchEvent(new CustomEvent(EVENT_NAME, { detail: { patientId: normId, rawId: patientId, messages } }));
  } catch (err) {
    console.error(`Failed to save messages for patient ${patientId}`, err);
  }
}

// Send a reply from provider/clinic staff to patient portal
export function sendProviderReply(
  patientId: string,
  replyData: {
    senderName: string;
    senderTitle?: string;
    providerId?: string;
    practiceName?: string;
    category?: PortalMessage['category'];
    content: string;
    attachment?: { name: string; size: string };
  }
): PortalMessage {
  const normId = normalizePatientId(patientId);
  const currentMessages = getMessagesForPatient(normId);
  const now = new Date();
  const timeStr = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  const dateStr = now.toLocaleDateString('en-US', { month: 'short', day: '2-digit', year: 'numeric' });

  const newMsg: PortalMessage = {
    id: `msg-staff-${Date.now()}`,
    patientId: normId,
    providerId: replyData.providerId || 'dr-sterling',
    practiceName: replyData.practiceName || 'Aura Vanguard Surgical & Aesthetic Pavilion',
    sender: 'provider',
    senderName: replyData.senderName,
    senderTitle: replyData.senderTitle || 'Attending Clinical Staff',
    timestamp: timeStr,
    date: 'Today, ' + dateStr,
    category: replyData.category || 'Clinical Question',
    content: replyData.content.trim(),
    read: true,
    attachment: replyData.attachment
  };

  const updated = [...currentMessages, newMsg];
  saveMessagesForPatient(normId, updated);
  return newMsg;
}

// Send a message from patient to clinic
export function sendPatientMessage(
  patientId: string,
  msgData: {
    senderName: string;
    category?: PortalMessage['category'];
    content: string;
    providerId?: string;
    attachment?: { name: string; size: string };
  }
): PortalMessage {
  const normId = normalizePatientId(patientId);
  const currentMessages = getMessagesForPatient(normId);
  const now = new Date();
  const timeStr = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  const dateStr = now.toLocaleDateString('en-US', { month: 'short', day: '2-digit', year: 'numeric' });

  const newMsg: PortalMessage = {
    id: `msg-pt-${Date.now()}`,
    patientId: normId,
    providerId: msgData.providerId || 'dr-sterling',
    practiceName: 'Aura Vanguard Surgical & Aesthetic Pavilion',
    sender: 'patient',
    senderName: msgData.senderName,
    timestamp: timeStr,
    date: 'Today, ' + dateStr,
    category: msgData.category || 'Clinical Question',
    content: msgData.content.trim(),
    read: false, // Unread for clinic staff
    attachment: msgData.attachment
  };

  const updated = [...currentMessages, newMsg];
  saveMessagesForPatient(normId, updated);
  return newMsg;
}

// Mark a message as read/unread
export function markMessageReadStatus(patientId: string, messageId: string, read: boolean): void {
  const currentMessages = getMessagesForPatient(patientId);
  const updated = currentMessages.map((m) => (m.id === messageId ? { ...m, read } : m));
  saveMessagesForPatient(patientId, updated);
}

// Delete a message
export function deletePortalMessage(patientId: string, messageId: string): void {
  const currentMessages = getMessagesForPatient(patientId);
  const updated = currentMessages.filter((m) => m.id !== messageId);
  saveMessagesForPatient(patientId, updated);
}

// Subscribe to message changes across components
export function subscribeToMessageUpdates(callback: (e?: CustomEvent) => void): () => void {
  if (typeof window === 'undefined') return () => {};

  const handler = (e: Event) => {
    callback(e as CustomEvent);
  };

  window.addEventListener(EVENT_NAME, handler);
  window.addEventListener('storage', handler);

  return () => {
    window.removeEventListener(EVENT_NAME, handler);
    window.removeEventListener('storage', handler);
  };
}

// Helper to get total unread messages across all patients or for one patient
export function getUnreadCount(patientId?: string): number {
  if (patientId) {
    const msgs = getMessagesForPatient(patientId);
    return msgs.filter((m) => m.sender === 'patient' && !m.read).length;
  }
  const all = getAllPortalMessages();
  return all.filter((m) => m.sender === 'patient' && !m.read).length;
}
