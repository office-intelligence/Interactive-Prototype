import React, { useState } from 'react';
import { 
  Lock, 
  Sparkles, 
  ShieldCheck, 
  ArrowRight, 
  Eye, 
  EyeOff, 
  CheckCircle2, 
  AlertCircle, 
  User, 
  KeyRound, 
  ArrowLeft
} from 'lucide-react';

interface LoginPageProps {
  onLoginSuccess: (user: { email: string; name: string; role: string }) => void;
  onNavigateRegister: () => void;
  onNavigateLanding: () => void;
}

export const LoginPage: React.FC<LoginPageProps> = ({
  onLoginSuccess,
  onNavigateRegister,
  onNavigateLanding
}) => {
  const [identifier, setIdentifier] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(true);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  
  // Modals for Forgot Username / Password
  const [forgotPasswordModal, setForgotPasswordModal] = useState(false);
  const [forgotUsernameModal, setForgotUsernameModal] = useState(false);
  const [recoveryEmail, setRecoveryEmail] = useState('');
  const [recoverySentMessage, setRecoverySentMessage] = useState<string | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    // Validation
    if (!identifier.trim()) {
      setErrorMessage('Please enter your username or registered practice email address.');
      return;
    }
    if (!password) {
      setErrorMessage('Please enter your secure password.');
      return;
    }

    if (password.length < 4) {
      setErrorMessage('Password must be at least 4 characters long.');
      return;
    }

    setIsLoading(true);

    // Simulate secure authentication verify
    setTimeout(() => {
      setIsLoading(false);
      let name = 'Dr. Alistair Sterling, MD';
      let role = 'Attending Plastic Surgeon & Medical Director';

      if (identifier.toLowerCase().includes('vance')) {
        name = 'Dr. Evelyn Vance, MD';
        role = 'Attending Surgeon - Ophthalmic & Facial Plastics';
      } else if (identifier.toLowerCase().includes('mercer')) {
        name = 'Dr. Julian Mercer, MD';
        role = 'Attending Facial Plastic & Reconstructive Surgeon';
      } else if (identifier.toLowerCase().includes('cruz')) {
        name = 'Dr. Raymond Cruz, MD';
        role = 'Director of Anesthesiology & Surgical Services';
      } else if (identifier.toLowerCase().includes('admin') || identifier.toLowerCase().includes('office')) {
        name = 'Camila Rojas';
        role = 'Practice Administrator & Clinical Operations Director';
      } else if (identifier.includes('@')) {
        const parts = identifier.split('@')[0].replace('.', ' ');
        name = parts.charAt(0).toUpperCase() + parts.slice(1);
      }

      onLoginSuccess({
        email: identifier,
        name,
        role
      });
    }, 600);
  };

  const handleSendPasswordReset = (e: React.FormEvent) => {
    e.preventDefault();
    if (!recoveryEmail.trim()) return;
    setRecoverySentMessage(`Password reset link and temporary security code sent to ${recoveryEmail}. Please check your inbox.`);
  };

  const handleSendUsernameLookup = (e: React.FormEvent) => {
    e.preventDefault();
    if (!recoveryEmail.trim()) return;
    setRecoverySentMessage(`Your practice username and registered provider NPI association have been sent to ${recoveryEmail}.`);
  };

  return (
    <div className="min-h-screen bg-stone-100 flex flex-col justify-between font-sans selection:bg-teal-500/20 selection:text-teal-900">
      
      {/* Top Header */}
      <header className="p-6 flex items-center justify-between max-w-7xl w-full mx-auto">
        <button
          onClick={onNavigateLanding}
          className="flex items-center gap-2.5 text-xs font-semibold text-stone-600 hover:text-stone-950 transition-colors cursor-pointer group"
        >
          <ArrowLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" />
          <span>Back to Office Intelligence Website</span>
        </button>

        <div className="flex items-center gap-2">
          <ShieldCheck className="w-4 h-4 text-emerald-600" />
          <span className="text-[11px] font-bold text-stone-500 uppercase tracking-wider">HIPAA Encrypted Portal</span>
        </div>
      </header>

      {/* Main Login Card Container */}
      <main className="flex-1 flex items-center justify-center p-4 sm:p-6">
        <div className="w-full max-w-md bg-white rounded-3xl border border-stone-300 shadow-xl p-8 sm:p-10 space-y-6 animate-in fade-in zoom-in-95 duration-200">
          
          {/* Logo & Title */}
          <div className="text-center space-y-2">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-slate-900 via-blue-900 to-indigo-800 text-white flex items-center justify-center mx-auto shadow-md">
              <Sparkles className="w-6 h-6 text-teal-300" />
            </div>
            <h1 className="text-2xl font-serif font-bold text-stone-900 tracking-tight">
              Sign In to Office Intelligence
            </h1>
            <p className="text-xs text-stone-500">
              Access your medical practice dashboard, surgical schedule, and AI tools
            </p>
          </div>

          {/* Error Banner */}
          {errorMessage && (
            <div className="p-3.5 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-xs flex items-start gap-2.5 animate-in shake">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* Login Form */}
          <form onSubmit={handleSubmit} className="space-y-4">
            
            {/* Username or Email */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold text-stone-700 flex items-center gap-1.5">
                  <User className="w-3.5 h-3.5 text-stone-500" />
                  <span>Username or Email Address <span className="text-rose-500">*</span></span>
                </label>
                <button
                  type="button"
                  onClick={() => {
                    setRecoveryEmail('');
                    setRecoverySentMessage(null);
                    setForgotUsernameModal(true);
                  }}
                  className="text-[11px] font-semibold text-blue-700 hover:text-blue-900 hover:underline cursor-pointer"
                >
                  Forgot Username?
                </button>
              </div>
              <div className="relative">
                <input
                  type="text"
                  value={identifier}
                  onChange={(e) => setIdentifier(e.target.value)}
                  placeholder="e.g. dr.linder@officeintel.med"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 focus:border-blue-600 focus:ring-2 focus:ring-blue-100 text-xs text-stone-900 outline-hidden transition-all bg-white"
                  autoComplete="username"
                />
              </div>
            </div>

            {/* Password */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold text-stone-700 flex items-center gap-1.5">
                  <Lock className="w-3.5 h-3.5 text-stone-500" />
                  <span>Password <span className="text-rose-500">*</span></span>
                </label>
                <button
                  type="button"
                  onClick={() => {
                    setRecoveryEmail('');
                    setRecoverySentMessage(null);
                    setForgotPasswordModal(true);
                  }}
                  className="text-[11px] font-semibold text-blue-700 hover:text-blue-900 hover:underline cursor-pointer"
                >
                  Forgot Password?
                </button>
              </div>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Enter your password"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 focus:border-blue-600 focus:ring-2 focus:ring-blue-100 text-xs text-stone-900 outline-hidden transition-all pr-10 bg-white"
                  autoComplete="current-password"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-stone-400 hover:text-stone-700 cursor-pointer"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {/* Remember Me Checkbox */}
            <div className="flex items-center justify-between pt-1">
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={rememberMe}
                  onChange={(e) => setRememberMe(e.target.checked)}
                  className="w-4 h-4 rounded-sm border-stone-300 text-blue-600 focus:ring-blue-500 cursor-pointer"
                />
                <span className="text-xs text-stone-600 font-medium">Keep me signed in on this device</span>
              </label>
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              disabled={isLoading}
              id="login-submit-button"
              className="w-full py-3 bg-gradient-to-r from-blue-700 to-indigo-800 hover:from-blue-800 hover:to-indigo-900 text-white font-bold text-xs rounded-xl shadow-md hover:shadow-lg transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
            >
              {isLoading ? (
                <span>Authenticating HIPAA Session...</span>
              ) : (
                <>
                  <KeyRound className="w-4 h-4 text-teal-300" />
                  <span>Log In to Practice System</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>

          </form>

          {/* Link to Registration */}
          <div className="text-center pt-2">
            <p className="text-xs text-stone-600">
              Don't have an Office Intelligence account?{' '}
              <button
                type="button"
                onClick={onNavigateRegister}
                id="login-register-link"
                className="font-bold text-blue-700 hover:text-blue-900 hover:underline cursor-pointer"
              >
                Register or Create Account
              </button>
            </p>
          </div>

        </div>
      </main>

      {/* Forgot Password Modal */}
      {forgotPasswordModal && (
        <div className="fixed inset-0 z-50 bg-stone-950/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl border border-stone-300 shadow-2xl p-6 max-w-md w-full space-y-4 animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between border-b border-stone-200 pb-3">
              <h3 className="text-base font-bold text-stone-900 flex items-center gap-2">
                <KeyRound className="w-4 h-4 text-blue-700" />
                <span>Reset Practice Account Password</span>
              </h3>
              <button
                onClick={() => setForgotPasswordModal(false)}
                className="text-stone-400 hover:text-stone-700 text-xs font-bold"
              >
                ✕
              </button>
            </div>

            {recoverySentMessage ? (
              <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-900 text-xs space-y-2">
                <div className="font-bold flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>Password Reset Request Received</span>
                </div>
                <p>{recoverySentMessage}</p>
                <button
                  onClick={() => setForgotPasswordModal(false)}
                  className="mt-2 w-full py-2 bg-emerald-700 text-white rounded-lg font-bold text-xs cursor-pointer"
                >
                  Return to Sign In
                </button>
              </div>
            ) : (
              <form onSubmit={handleSendPasswordReset} className="space-y-4">
                <p className="text-xs text-stone-600 leading-relaxed">
                  Enter your registered medical practice email address. We will verify your credentials and send a secure single-use recovery link.
                </p>
                <div className="space-y-1">
                  <label className="text-xs font-bold text-stone-700">Practice Email Address</label>
                  <input
                    type="email"
                    required
                    value={recoveryEmail}
                    onChange={(e) => setRecoveryEmail(e.target.value)}
                    placeholder="e.g. physician@mypractice.com"
                    className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 text-xs outline-hidden focus:border-blue-600"
                  />
                </div>
                <div className="flex items-center justify-end gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setForgotPasswordModal(false)}
                    className="px-4 py-2 rounded-xl text-xs font-semibold text-stone-600 hover:bg-stone-100"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 bg-blue-700 hover:bg-blue-800 text-white text-xs font-bold rounded-xl shadow-xs"
                  >
                    Send Recovery Link
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}

      {/* Forgot Username Modal */}
      {forgotUsernameModal && (
        <div className="fixed inset-0 z-50 bg-stone-950/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl border border-stone-300 shadow-2xl p-6 max-w-md w-full space-y-4 animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between border-b border-stone-200 pb-3">
              <h3 className="text-base font-bold text-stone-900 flex items-center gap-2">
                <User className="w-4 h-4 text-indigo-700" />
                <span>Lookup Registered Practice Username</span>
              </h3>
              <button
                onClick={() => setForgotUsernameModal(false)}
                className="text-stone-400 hover:text-stone-700 text-xs font-bold"
              >
                ✕
              </button>
            </div>

            {recoverySentMessage ? (
              <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-900 text-xs space-y-2">
                <div className="font-bold flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>Username Lookup Sent</span>
                </div>
                <p>{recoverySentMessage}</p>
                <button
                  onClick={() => setForgotUsernameModal(false)}
                  className="mt-2 w-full py-2 bg-emerald-700 text-white rounded-lg font-bold text-xs cursor-pointer"
                >
                  Return to Sign In
                </button>
              </div>
            ) : (
              <form onSubmit={handleSendUsernameLookup} className="space-y-4">
                <p className="text-xs text-stone-600 leading-relaxed">
                  Enter your practice contact email or provider NPI associated with your facility.
                </p>
                <div className="space-y-1">
                  <label className="text-xs font-bold text-stone-700">Registered Email or Provider NPI</label>
                  <input
                    type="text"
                    required
                    value={recoveryEmail}
                    onChange={(e) => setRecoveryEmail(e.target.value)}
                    placeholder="e.g. 1982736450 or admin@surgerycenter.com"
                    className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 text-xs outline-hidden focus:border-blue-600"
                  />
                </div>
                <div className="flex items-center justify-end gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setForgotUsernameModal(false)}
                    className="px-4 py-2 rounded-xl text-xs font-semibold text-stone-600 hover:bg-stone-100"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 bg-indigo-700 hover:bg-indigo-800 text-white text-xs font-bold rounded-xl shadow-xs"
                  >
                    Lookup Account
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}

      {/* Footer */}
      <footer className="p-6 text-center text-xs text-stone-500">
        <p>© 2026 Office Intelligence Systems Inc. HIPAA-Compliant Medical Operating Platform.</p>
      </footer>

    </div>
  );
};
