import React, { useState } from 'react';
import { TaskItem } from '../types';
import { CheckSquare, Square, ChevronDown, CheckCircle2, Clock, Calendar } from 'lucide-react';

interface TasksWidgetProps {
  tasks: TaskItem[];
  onToggleTask: (taskId: string) => void;
}

export const TasksWidget: React.FC<TasksWidgetProps> = ({ tasks, onToggleTask }) => {
  const [filterRange, setFilterRange] = useState<'14' | '7' | 'TODAY'>('14');

  const dueTodayTasks = tasks.filter((t) => t.dueDate === 'Today');
  const thisWeekTasks = tasks.filter((t) => t.dueDate === 'This Week');
  const nextWeekTasks = tasks.filter((t) => t.dueDate === 'Next Week');

  const totalTasks = tasks.length;

  const renderTaskSection = (title: string, taskList: TaskItem[]) => {
    if (taskList.length === 0) return null;

    return (
      <div className="space-y-2">
        <div className="text-[11px] font-bold text-stone-400 uppercase tracking-wider flex items-center justify-between">
          <span>{title}</span>
          <span className="text-[10px] text-stone-400 font-medium">{taskList.length}</span>
        </div>
        <div className="space-y-1.5">
          {taskList.map((task) => (
            <div
              key={task.id}
              onClick={() => onToggleTask(task.id)}
              className={`p-2.5 rounded-xl border transition-all cursor-pointer flex items-start gap-2.5 ${
                task.completed
                  ? 'bg-stone-50/60 border-stone-200 text-stone-400 line-through'
                  : 'bg-white border-stone-200/80 hover:border-amber-300 shadow-2xs'
              }`}
            >
              <button
                className="mt-0.5 shrink-0 text-stone-400 hover:text-amber-800 transition-colors"
                onClick={(e) => {
                  e.stopPropagation();
                  onToggleTask(task.id);
                }}
              >
                {task.completed ? (
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                ) : (
                  <Square className="w-4 h-4 text-stone-300" />
                )}
              </button>

              <div className="flex-1 min-w-0">
                <div className={`text-xs font-semibold leading-snug ${task.completed ? 'text-stone-400' : 'text-stone-900'}`}>
                  {task.title}
                </div>
                {task.patientName && (
                  <div className="text-[11px] text-amber-900 font-semibold truncate mt-0.5">
                    Patient: {task.patientName}
                  </div>
                )}
              </div>

              <div className="shrink-0 flex flex-col items-end gap-1">
                <span
                  className={`px-1.5 py-0.2 rounded text-[9px] font-bold ${
                    task.priority === 'High'
                      ? 'bg-rose-100 text-rose-800 border border-rose-200'
                      : task.priority === 'Medium'
                      ? 'bg-amber-100 text-amber-900 border border-amber-200'
                      : 'bg-stone-100 text-stone-600'
                  }`}
                >
                  {task.priority}
                </span>
                <span className="text-[10px] text-stone-400 font-medium">
                  {task.dueDateString || task.dueDate}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  };

  return (
    <div className="bg-white/95 rounded-2xl border border-stone-200/90 shadow-2xs p-5 space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between pb-2 border-b border-stone-200/60">
        <div className="flex items-center gap-2">
          <CheckSquare className="w-4 h-4 text-amber-800" />
          <h3 className="text-sm font-bold text-stone-900 tracking-tight">
            Tasks ({totalTasks})
          </h3>
        </div>

        <select
          value={filterRange}
          onChange={(e) => setFilterRange(e.target.value as any)}
          className="text-xs bg-stone-100 border border-stone-200 rounded-lg px-2 py-1 font-semibold text-stone-700 focus:outline-none"
        >
          <option value="14">Next 14 Days</option>
          <option value="7">Next 7 Days</option>
          <option value="TODAY">Due Today</option>
        </select>
      </div>

      <div className="space-y-4">
        {renderTaskSection('Due Today', dueTodayTasks)}
        {renderTaskSection('This Week', thisWeekTasks)}
        {renderTaskSection('Next Week', nextWeekTasks)}
      </div>
    </div>
  );
};
