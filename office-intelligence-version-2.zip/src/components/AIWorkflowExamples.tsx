import React, { useState } from 'react';
import { 
  Sparkles, 
  CheckCircle2, 
  AlertTriangle, 
  Zap, 
  FileText, 
  Activity, 
  Clock, 
  ArrowRight, 
  ShieldCheck, 
  RefreshCw, 
  FileCheck, 
  Stethoscope, 
  TrendingUp, 
  DollarSign, 
  Calendar,
  Database,
  Cpu,
  Layers,
  Check
} from 'lucide-react';
import { PatientCase } from '../types';

interface AIWorkflowExamplesProps {
  cases?: PatientCase[];
  onRunWorkflow?: (workflowId: string) => void;
  onSelectPatient?: (patientId: string) => void;
  onShowToast?: (msg: string) => void;
}

export interface WorkflowItem {
  id: string;
  title: string;
  category: 'Clinical Clearance' | 'Risk Assessment' | 'OR Optimization' | 'Auto-Documentation' | 'Revenue Cycle';
  badge: string;
  description: string;
  timeSavings: string;
  accuracy: string;
  steps: { title: string; detail: string; icon: any }[];
  inputData: string;
  aiOutput: string;
  impactMetrics: { label: string; value: string; trend: string }[];
}

export const WORKFLOW_EXAMPLES: WorkflowItem[] = [
  {
    id: 'wf-ekg-fasttrack',
    title: 'EKG & Cardiology Fast-Track Clearance',
    category: 'Clinical Clearance',
    badge: 'Automated Fax Ingestion',
    description: 'Ingests faxes from external cardiology, extracts sinus rhythm status via medical OCR, clears pre-op holds, and updates readiness score to 98% in under 5 seconds.',
    timeSavings: '45 mins saved per hold',
    accuracy: '99.4% OCR precision',
    inputData: 'Beverly Hills Cardiology faxed 12-lead EKG report for Patricia DePoli (Patient ID: 228940).',
    aiOutput: '12-lead EKG parsed: Normal Sinus Rhythm, HR 72 bpm, QTc 418ms. No ischemic changes. Status: CLEARED FOR OR 1.',
    steps: [
      { title: 'Inbound Fax Received', detail: 'OCR captures 12-lead PDF from fax gateway.', icon: FileText },
      { title: 'NLP Clinical Extraction', detail: 'Identifies physician signature, date, and "Normal Sinus".', icon: Cpu },
      { title: 'EMR Readiness Update', detail: 'Clears EKG bottleneck & updates AI readiness score to 98%.', icon: CheckCircle2 },
    ],
    impactMetrics: [
      { label: 'Turnaround Time', value: '< 5 sec', trend: 'vs 45 min manual' },
      { label: 'Readiness Boost', value: '72% ➔ 98%', trend: 'Cleared for OR' },
      { label: 'Staff Calls Saved', value: '3 calls', trend: 'No fax chasing' },
    ],
  },
  {
    id: 'wf-risk-assessment',
    title: 'Pre-Op Intake & Anesthesia Risk Screening',
    category: 'Risk Assessment',
    badge: 'Automated Airway & Allergy Shield',
    description: 'Analyzes patient intake, identifies Mallampati Class, penicillin allergy warnings, calculates Caprini VTE score, and generates anesthesia prep notes.',
    timeSavings: '20 mins per patient intake',
    accuracy: '100% allergy cross-check',
    inputData: 'Sarah Wilson (ID: 113561) completed pre-op portal questionnaire & history.',
    aiOutput: 'Penicillin allergy flagged (hives). Ancef 1g approved. Loose molar noted for intubation safety. Caprini VTE Score: 2 (Low risk).',
    steps: [
      { title: 'Portal Data Extraction', detail: 'Scans patient-submitted responses & prior history.', icon: Database },
      { title: 'Cross-Allergy Screening', detail: 'Cross-checks beta-lactam sensitivities & order sets.', icon: ShieldCheck },
      { title: 'Anesthesia Brief Generated', detail: 'Pushes Mallampati I & dental notes to Dr. Raymond Cruz.', icon: Stethoscope },
    ],
    impactMetrics: [
      { label: 'Allergy Collisions', value: '0 Event', trend: '100% prevented' },
      { label: 'Risk Score Accuracy', value: '99.8%', trend: 'AORN compliant' },
      { label: 'Anesthesiologist Prep', value: '2 mins', trend: 'vs 15 mins manual' },
    ],
  },
  {
    id: 'wf-or-optimization',
    title: 'OR Schedule & Turnover Bottleneck Optimization',
    category: 'OR Optimization',
    badge: 'Real-Time Dynamic Rescheduling',
    description: 'Predicts procedure duration overruns using surgeon-specific historic velocity, optimizes OR 1 to OR 2 turnover, and eliminates staff overtime.',
    timeSavings: '32 mins OR delay reduced',
    accuracy: '94% prediction accuracy',
    inputData: 'Dr. Alistair Sterling OR 1 case running 12 mins ahead; OR 2 PACU bed availability confirmed.',
    aiOutput: 'Recommendation: Advance Eleanor Vance to OR 2 prep bay 15 mins early. Reduces total facility idle time by 32 minutes.',
    steps: [
      { title: 'Velocity Tracking', detail: 'Monitors incision-to-closure time against benchmark.', icon: Activity },
      { title: 'Turnover AI Engine', detail: 'Predicts PACU bed clearance & nursing bay status.', icon: Layers },
      { title: 'Schedule Auto-Adjust', detail: 'Notifies holding RNs and updates live board.', icon: Calendar },
    ],
    impactMetrics: [
      { label: 'Idle OR Time', value: '- 32 mins', trend: 'Saved today' },
      { label: 'Overtime Cost', value: '- $1,850', trend: 'Daily savings' },
      { label: 'Schedule On-Time', value: '96.2%', trend: '+14% improvement' },
    ],
  },
  {
    id: 'wf-auto-docs',
    title: 'Ambient Dictation & Clinical Note Auto-Structuring',
    category: 'Auto-Documentation',
    badge: 'Voice-to-H&P Generation',
    description: 'Converts clinician voice recordings or brief dictation notes into complete H&P, Operative Notes, or Discharge summaries with automated ICD-10 tags.',
    timeSavings: '12 mins per operative report',
    accuracy: '98.9% medical terminology',
    inputData: '30-second clinician voice snippet describing bilateral breast implant revision & capsulectomy.',
    aiOutput: 'Generated Operative Note: Subglandular pocket dissected, 275cc smooth implants placed, hemostasis achieved, closed in 3 layers. ICD-10: T85.44XA.',
    steps: [
      { title: 'Voice / Text Capture', detail: 'Captures raw dictation from app microphone or ambient scribe.', icon: Zap },
      { title: 'Clinical Structuring', detail: 'Organizes into SOAP format with surgical details.', icon: FileText },
      { title: 'EMR Integration', detail: 'Attaches draft note to chart for instant 1-click sign-off.', icon: FileCheck },
    ],
    impactMetrics: [
      { label: 'Chart Completion', value: 'Same Day', trend: 'vs 48 hr lag' },
      { label: 'Physician Time Saved', value: '1.8 hrs/day', trend: 'Reduced admin' },
      { label: 'Billing Ready', value: 'Instant', trend: 'Coded at sign-off' },
    ],
  },
  {
    id: 'wf-revenue-cycle',
    title: 'AI Revenue Cycle & CPT Prior Auth Auto-Verification',
    category: 'Revenue Cycle',
    badge: 'Automated Billing & Estimate Engine',
    description: 'Cross-checks insurance eligibility, verifies prior authorization requirements for cosmetic/reconstructive procedure codes, and generates patient financial estimates.',
    timeSavings: '25 mins per billing claim',
    accuracy: '99.1% clean claim rate',
    inputData: 'Blue Shield PPO policy #W99284102 for CPT 15823 (Blepharoplasty) & CPT 19342.',
    aiOutput: 'Prior Authorization Approved. Facility fee: $8,500. Patient copay: $500. Clean claim pre-validated for instant electronic submission.',
    steps: [
      { title: 'CPT Code Extraction', detail: 'Reads surgical procedure & match with fee schedule.', icon: DollarSign },
      { title: 'Payer Portal Check', detail: 'Queries Blue Shield ERA for authorization & deductible.', icon: ShieldCheck },
      { title: 'Invoice Auto-Creation', detail: 'Generates itemized claim with facility & anesthesia fees.', icon: TrendingUp },
    ],
    impactMetrics: [
      { label: 'Clean Claim Rate', value: '99.1%', trend: 'Zero rejections' },
      { label: 'Days in A/R', value: '11 Days', trend: 'vs 34 industry avg' },
      { label: 'Patient Pre-Pay', value: '100%', trend: 'Paid prior to OR' },
    ],
  }
];

export const AIWorkflowExamples: React.FC<AIWorkflowExamplesProps> = ({
  cases = [],
  onRunWorkflow,
  onSelectPatient,
  onShowToast
}) => {
  const [selectedWorkflowId, setSelectedWorkflowId] = useState<string>('wf-ekg-fasttrack');
  const [isRunningSim, setIsRunningSim] = useState<boolean>(false);
  const [simStep, setSimStep] = useState<number>(0);
  const [completedWorkflows, setCompletedWorkflows] = useState<Record<string, boolean>>({});

  const activeWorkflow = WORKFLOW_EXAMPLES.find((w) => w.id === selectedWorkflowId) || WORKFLOW_EXAMPLES[0];

  const handleTriggerSimulation = () => {
    setIsRunningSim(true);
    setSimStep(1);

    if (onShowToast) {
      onShowToast(`Running Nightingale AI Simulation: ${activeWorkflow.title}...`);
    }

    setTimeout(() => {
      setSimStep(2);
    }, 1200);

    setTimeout(() => {
      setSimStep(3);
    }, 2400);

    setTimeout(() => {
      setIsRunningSim(false);
      setCompletedWorkflows((prev) => ({ ...prev, [activeWorkflow.id]: true }));
      if (onRunWorkflow) {
        onRunWorkflow(activeWorkflow.id);
      }
      if (onShowToast) {
        onShowToast(`⚡ ${activeWorkflow.title} completed successfully! EMR state updated.`);
      }
    }, 3200);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 p-6 rounded-3xl text-white shadow-xl border border-indigo-900/50 flex flex-wrap items-center justify-between gap-6 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />
        
        <div className="space-y-2 max-w-2xl z-10">
          <div className="flex items-center gap-2.5">
            <div className="px-3 py-1 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-400/30 text-xs font-bold flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
              <span>Nightingale AI Clinical & Administrative Suite</span>
            </div>
            <span className="text-xs font-medium text-slate-400">Version 3.0</span>
          </div>

          <h2 className="text-2xl font-bold text-white tracking-tight">
            AI Workflow Intelligence Examples
          </h2>

          <p className="text-sm text-slate-300 leading-relaxed font-normal">
            Automating clinical clearances, anesthesia risk screening, OR turnover optimization, ambient documentation, and revenue cycle verification in real time.
          </p>
        </div>

        <div className="flex flex-col sm:flex-row items-center gap-3 z-10">
          <button
            onClick={handleTriggerSimulation}
            disabled={isRunningSim}
            className={`px-5 py-3 rounded-2xl font-bold text-xs shadow-lg flex items-center gap-2 transition-all cursor-pointer ${
              isRunningSim
                ? 'bg-indigo-800 text-indigo-200 cursor-not-allowed'
                : 'bg-indigo-600 hover:bg-indigo-500 text-white hover:scale-102 active:scale-98 shadow-indigo-600/30'
            }`}
          >
            {isRunningSim ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin" />
                <span>Running Live Simulation...</span>
              </>
            ) : (
              <>
                <Zap className="w-4 h-4 text-amber-300 fill-amber-300" />
                <span>Run Selected AI Workflow</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Workflow Navigation Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
        {WORKFLOW_EXAMPLES.map((wf) => {
          const isSelected = wf.id === selectedWorkflowId;
          const isDone = completedWorkflows[wf.id];

          return (
            <button
              key={wf.id}
              onClick={() => {
                setSelectedWorkflowId(wf.id);
                setSimStep(0);
              }}
              className={`p-4 rounded-2xl border text-left transition-all cursor-pointer relative overflow-hidden flex flex-col justify-between ${
                isSelected
                  ? 'bg-white border-indigo-600 ring-2 ring-indigo-500/30 shadow-md'
                  : 'bg-white/80 hover:bg-white border-stone-200/90 hover:border-stone-300 shadow-2xs'
              }`}
            >
              {isDone && (
                <div className="absolute top-2 right-2 p-1 bg-emerald-100 text-emerald-700 rounded-full">
                  <Check className="w-3.5 h-3.5" />
                </div>
              )}

              <div className="space-y-2">
                <span className="text-[10px] font-bold text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded-md border border-indigo-200/60 inline-block truncate max-w-full">
                  {wf.category}
                </span>

                <h3 className="text-xs font-bold text-stone-900 line-clamp-2 leading-snug">
                  {wf.title}
                </h3>
              </div>

              <div className="mt-3 pt-2 border-t border-stone-100 flex items-center justify-between text-[11px] text-stone-500 font-medium">
                <span className="text-emerald-700 font-semibold">{wf.timeSavings}</span>
                <ArrowRight className={`w-3.5 h-3.5 ${isSelected ? 'text-indigo-600' : 'text-stone-400'}`} />
              </div>
            </button>
          );
        })}
      </div>

      {/* Active Selected Workflow Detail Panel */}
      <div className="bg-white rounded-3xl border border-stone-200/90 shadow-sm overflow-hidden">
        
        {/* Detail Header */}
        <div className="p-6 bg-stone-50/80 border-b border-stone-200/80 flex flex-wrap items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-full bg-indigo-100 text-indigo-800 font-bold text-xs">
                {activeWorkflow.badge}
              </span>
              <span className="text-xs font-semibold text-emerald-700 bg-emerald-50 px-2.5 py-0.5 rounded-full border border-emerald-200">
                Precision {activeWorkflow.accuracy}
              </span>
            </div>
            <h3 className="text-lg font-bold text-stone-900">{activeWorkflow.title}</h3>
            <p className="text-xs text-stone-600 max-w-3xl leading-relaxed">
              {activeWorkflow.description}
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={handleTriggerSimulation}
              disabled={isRunningSim}
              className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-xl shadow-xs transition-all flex items-center gap-2 cursor-pointer"
            >
              <Zap className="w-4 h-4 text-amber-300 fill-amber-300" />
              <span>{completedWorkflows[activeWorkflow.id] ? 'Re-Run Simulation' : 'Simulate Live Execution'}</span>
            </button>
          </div>
        </div>

        {/* Workflow Simulation Progress Bar */}
        {isRunningSim && (
          <div className="bg-indigo-900 text-white p-4 px-6 border-b border-indigo-800 animate-in fade-in duration-200 space-y-2">
            <div className="flex items-center justify-between text-xs font-bold">
              <span className="flex items-center gap-2 text-indigo-200">
                <RefreshCw className="w-4 h-4 animate-spin text-indigo-300" />
                <span>Executing Stage {simStep} of 3: {activeWorkflow.steps[simStep - 1]?.title || 'Processing...'}</span>
              </span>
              <span className="text-indigo-300">{simStep === 1 ? '33%' : simStep === 2 ? '66%' : '100%'} Complete</span>
            </div>
            <div className="w-full bg-indigo-950 h-2 rounded-full overflow-hidden">
              <div
                className="bg-gradient-to-r from-indigo-400 to-emerald-400 h-full transition-all duration-700 ease-out"
                style={{ width: `${(simStep / 3) * 100}%` }}
              />
            </div>
          </div>
        )}

        {/* Content Body: 3 Pipeline Steps + Input/Output + Impact Metrics */}
        <div className="p-6 space-y-6">
          
          {/* Step Pipeline Visualization */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold text-stone-400 uppercase tracking-wider">
              Automated AI Pipeline Architecture
            </h4>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {activeWorkflow.steps.map((step, idx) => {
                const StepIcon = step.icon;
                const isCurrentStep = simStep === idx + 1;
                const isPassedStep = simStep > idx + 1 || completedWorkflows[activeWorkflow.id];

                return (
                  <div
                    key={idx}
                    className={`p-4 rounded-2xl border transition-all ${
                      isCurrentStep
                        ? 'bg-indigo-50/90 border-indigo-300 ring-2 ring-indigo-400/30 shadow-xs'
                        : isPassedStep
                        ? 'bg-emerald-50/60 border-emerald-200'
                        : 'bg-stone-50/60 border-stone-200/80'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <div
                          className={`w-7 h-7 rounded-lg flex items-center justify-center text-xs font-bold ${
                            isCurrentStep
                              ? 'bg-indigo-600 text-white'
                              : isPassedStep
                              ? 'bg-emerald-600 text-white'
                              : 'bg-stone-200 text-stone-700'
                          }`}
                        >
                          {isPassedStep ? <Check className="w-4 h-4" /> : idx + 1}
                        </div>
                        <span className="text-xs font-bold text-stone-900">{step.title}</span>
                      </div>
                      <StepIcon
                        className={`w-4 h-4 ${
                          isCurrentStep ? 'text-indigo-600 animate-pulse' : isPassedStep ? 'text-emerald-600' : 'text-stone-400'
                        }`}
                      />
                    </div>
                    <p className="text-xs text-stone-600 font-medium leading-relaxed">
                      {step.detail}
                    </p>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Input vs Output Data Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Input Payload */}
            <div className="p-4 bg-slate-900 text-slate-100 rounded-2xl border border-slate-800 space-y-2">
              <div className="flex items-center justify-between text-xs font-bold text-slate-300 border-b border-slate-800 pb-2">
                <span className="flex items-center gap-1.5 text-slate-200">
                  <Database className="w-4 h-4 text-indigo-400" />
                  <span>Unstructured Data Input</span>
                </span>
                <span className="text-[10px] bg-slate-800 text-slate-400 px-2 py-0.5 rounded">Raw Clinical Fax / Portal</span>
              </div>
              <p className="text-xs text-slate-300 font-mono leading-relaxed pt-1">
                {activeWorkflow.inputData}
              </p>
            </div>

            {/* AI Structuring & Action */}
            <div className="p-4 bg-indigo-950 text-indigo-50 rounded-2xl border border-indigo-900 space-y-2">
              <div className="flex items-center justify-between text-xs font-bold text-indigo-200 border-b border-indigo-900/80 pb-2">
                <span className="flex items-center gap-1.5 text-indigo-100">
                  <Sparkles className="w-4 h-4 text-amber-300" />
                  <span>Structured Nightingale AI Output</span>
                </span>
                <span className="text-[10px] bg-emerald-900/60 text-emerald-300 px-2 py-0.5 rounded font-semibold">EMR Action Applied</span>
              </div>
              <p className="text-xs text-indigo-100 font-mono leading-relaxed pt-1">
                {activeWorkflow.aiOutput}
              </p>
            </div>
          </div>

          {/* Impact Metrics Row */}
          <div className="pt-2">
            <h4 className="text-xs font-bold text-stone-400 uppercase tracking-wider mb-3">
              Measured Clinical & Operational Impact
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              {activeWorkflow.impactMetrics.map((metric, idx) => (
                <div key={idx} className="p-4 bg-stone-50 rounded-2xl border border-stone-200/80 flex items-center justify-between">
                  <div>
                    <span className="text-xs font-medium text-stone-500 block">{metric.label}</span>
                    <span className="text-xl font-extrabold text-stone-900 block mt-0.5">{metric.value}</span>
                  </div>
                  <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-200">
                    {metric.trend}
                  </span>
                </div>
              ))}
            </div>
          </div>

        </div>

        {/* Detail Footer */}
        <div className="p-4 bg-stone-50 border-t border-stone-200/80 flex items-center justify-between text-xs text-stone-500 font-medium">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-indigo-600" />
            <span>Fully HIPAA compliant & audit-logged in Aura Vanguard EMR.</span>
          </div>
          {onSelectPatient && (
            <button
              onClick={() => onSelectPatient('case-1')}
              className="text-indigo-700 hover:text-indigo-900 font-bold flex items-center gap-1 cursor-pointer"
            >
              <span>View Sarah Wilson's Chart</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

      </div>

    </div>
  );
};
