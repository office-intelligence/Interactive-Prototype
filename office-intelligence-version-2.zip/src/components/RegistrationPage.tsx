import React, { useState } from 'react';
import { 
  UserPlus, 
  Sparkles, 
  ShieldCheck, 
  ArrowRight, 
  Eye, 
  EyeOff, 
  CheckCircle2, 
  AlertCircle, 
  Building2, 
  User, 
  Mail, 
  Phone, 
  Lock, 
  ArrowLeft, 
  FileText,
  Check,
  Stethoscope
} from 'lucide-react';
import { AuthUser } from '../types';

interface RegistrationPageProps {
  onRegisterSuccess: (newUser: {
    firstName: string;
    lastName: string;
    email: string;
    telephone: string;
  }) => void;
  onNavigateLogin: () => void;
  onNavigateLanding: () => void;
}

export const RegistrationPage: React.FC<RegistrationPageProps> = ({
  onRegisterSuccess,
  onNavigateLogin,
  onNavigateLanding
}) => {
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [email, setEmail] = useState('');
  const [telephone, setTelephone] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [agreeTerms, setAgreeTerms] = useState(false);

  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [showTermsModal, setShowTermsModal] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    // Validation
    if (!firstName.trim() || !lastName.trim()) {
      setErrorMessage('Please enter both your first and last name.');
      return;
    }

    if (!email.trim() || !email.includes('@')) {
      setErrorMessage('Please enter a valid practice email address.');
      return;
    }

    if (!telephone.trim()) {
      setErrorMessage('Please enter your direct telephone number for 2-factor authentication & notifications.');
      return;
    }

    if (!password || password.length < 6) {
      setErrorMessage('Password must be at least 6 characters long.');
      return;
    }

    if (password !== confirmPassword) {
      setErrorMessage('Passwords do not match. Please re-enter your password.');
      return;
    }

    if (!agreeTerms) {
      setErrorMessage('You must agree to the Terms of Service and HIPAA Business Associate Agreement to continue.');
      return;
    }

    setIsLoading(true);

    setTimeout(() => {
      setIsLoading(false);
      onRegisterSuccess({
        firstName: firstName.trim(),
        lastName: lastName.trim(),
        email: email.trim(),
        telephone: telephone.trim()
      });
    }, 600);
  };

  return (
    <div className="min-h-screen bg-stone-100 flex flex-col justify-between font-sans selection:bg-teal-500/20 selection:text-teal-900">
      
      {/* Top Header */}
      <header className="p-6 flex items-center justify-between max-w-7xl w-full mx-auto">
        <button
          onClick={onNavigateLanding}
          className="flex items-center gap-2.5 text-xs font-semibold text-stone-600 hover:text-stone-950 transition-colors cursor-pointer group"
        >
          <ArrowLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" />
          <span>Back to Office Intelligence Website</span>
        </button>

        <div className="flex items-center gap-2">
          <ShieldCheck className="w-4 h-4 text-emerald-600" />
          <span className="text-[11px] font-bold text-stone-500 uppercase tracking-wider">HIPAA Verified Onboarding</span>
        </div>
      </header>

      {/* Main Registration Container */}
      <main className="flex-1 flex items-center justify-center p-4 sm:p-6">
        <div className="w-full max-w-xl bg-white rounded-3xl border border-stone-300 shadow-xl p-8 sm:p-10 space-y-6 animate-in fade-in zoom-in-95 duration-200">
          
          {/* Logo & Title */}
          <div className="text-center space-y-2">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-slate-900 via-blue-900 to-indigo-800 text-white flex items-center justify-center mx-auto shadow-md">
              <Sparkles className="w-6 h-6 text-teal-300" />
            </div>
            <h1 className="text-2xl sm:text-3xl font-serif font-bold text-stone-900 tracking-tight">
              Create Practice Account
            </h1>
            <p className="text-xs text-stone-500 max-w-md mx-auto">
              Get started with Office Intelligence. After creating your account, you will be guided directly to Configure Practice setup.
            </p>
          </div>

          {/* Error Banner */}
          {errorMessage && (
            <div className="p-3.5 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-xs flex items-start gap-2.5 animate-in shake">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* Registration Form */}
          <form onSubmit={handleSubmit} className="space-y-4">
            
            {/* First & Last Name Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-stone-700 flex items-center gap-1">
                  <span>First Name</span> <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={firstName}
                  onChange={(e) => setFirstName(e.target.value)}
                  placeholder="e.g. Stuart"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 focus:border-blue-600 focus:ring-2 focus:ring-blue-100 text-xs text-stone-900 outline-hidden transition-all bg-white"
                  autoComplete="given-name"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-bold text-stone-700 flex items-center gap-1">
                  <span>Last Name</span> <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={lastName}
                  onChange={(e) => setLastName(e.target.value)}
                  placeholder="e.g. Sterling"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 focus:border-blue-600 focus:ring-2 focus:ring-blue-100 text-xs text-stone-900 outline-hidden transition-all bg-white"
                  autoComplete="family-name"
                />
              </div>
            </div>

            {/* Email Address */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-stone-700 flex items-center gap-1">
                <Mail className="w-3.5 h-3.5 text-stone-500" />
                <span>Practice / Provider Email Address</span> <span className="text-rose-500">*</span>
              </label>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="e.g. dr.linder@summitsurgical.com"
                className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 focus:border-blue-600 focus:ring-2 focus:ring-blue-100 text-xs text-stone-900 outline-hidden transition-all bg-white"
                autoComplete="email"
              />
            </div>

            {/* Telephone Number */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-stone-700 flex items-center gap-1">
                <Phone className="w-3.5 h-3.5 text-stone-500" />
                <span>Direct Telephone Number</span> <span className="text-rose-500">*</span>
              </label>
              <input
                type="tel"
                required
                value={telephone}
                onChange={(e) => setTelephone(e.target.value)}
                placeholder="e.g. (310) 859-2000"
                className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 focus:border-blue-600 focus:ring-2 focus:ring-blue-100 text-xs text-stone-900 outline-hidden transition-all bg-white"
                autoComplete="tel"
              />
              <p className="text-[11px] text-stone-500">Required for multi-factor authentication & clinical text alerts.</p>
            </div>

            {/* Password & Confirm Password Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-stone-700 flex items-center gap-1">
                  <Lock className="w-3.5 h-3.5 text-stone-500" />
                  <span>Create Password</span> <span className="text-rose-500">*</span>
                </label>
                <div className="relative">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Min 6 characters"
                    className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 focus:border-blue-600 focus:ring-2 focus:ring-blue-100 text-xs text-stone-900 outline-hidden transition-all pr-10 bg-white"
                    autoComplete="new-password"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-stone-400 hover:text-stone-700 cursor-pointer"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-bold text-stone-700 flex items-center gap-1">
                  <Lock className="w-3.5 h-3.5 text-stone-500" />
                  <span>Confirm Password</span> <span className="text-rose-500">*</span>
                </label>
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="Re-enter password"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 focus:border-blue-600 focus:ring-2 focus:ring-blue-100 text-xs text-stone-900 outline-hidden transition-all bg-white"
                  autoComplete="new-password"
                />
              </div>
            </div>

            {/* Terms and Conditions Checkbox */}
            <div className="pt-2">
              <label className="flex items-start gap-2.5 cursor-pointer bg-stone-50 p-3 rounded-xl border border-stone-200">
                <input
                  type="checkbox"
                  required
                  checked={agreeTerms}
                  onChange={(e) => setAgreeTerms(e.target.checked)}
                  className="mt-0.5 w-4 h-4 rounded-sm border-stone-300 text-blue-600 focus:ring-blue-500 cursor-pointer"
                />
                <span className="text-xs text-stone-600 leading-relaxed">
                  I agree to the{' '}
                  <button
                    type="button"
                    onClick={(e) => {
                      e.preventDefault();
                      setShowTermsModal(true);
                    }}
                    className="font-bold text-blue-700 hover:text-blue-900 hover:underline cursor-pointer"
                  >
                    Terms of Service
                  </button>{' '}
                  and the{' '}
                  <button
                    type="button"
                    onClick={(e) => {
                      e.preventDefault();
                      setShowTermsModal(true);
                    }}
                    className="font-bold text-blue-700 hover:text-blue-900 hover:underline cursor-pointer"
                  >
                    HIPAA Business Associate Agreement (BAA)
                  </button>
                  .
                </span>
              </label>
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              disabled={isLoading}
              id="registration-submit-btn"
              className="w-full py-3.5 bg-gradient-to-r from-blue-700 via-blue-800 to-indigo-900 hover:from-blue-800 hover:to-indigo-950 text-white font-bold text-xs rounded-xl shadow-md hover:shadow-lg transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
            >
              {isLoading ? (
                <span>Creating Practice Account & Provisioning Security...</span>
              ) : (
                <>
                  <UserPlus className="w-4 h-4 text-teal-300" />
                  <span>Create Account & Configure Practice</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>

          </form>

          {/* Link to Log In */}
          <div className="text-center pt-2 border-t border-stone-200">
            <p className="text-xs text-stone-600">
              Already have an Office Intelligence account?{' '}
              <button
                type="button"
                onClick={onNavigateLogin}
                id="registration-login-link"
                className="font-bold text-blue-700 hover:text-blue-900 hover:underline cursor-pointer"
              >
                Log In
              </button>
            </p>
          </div>

        </div>
      </main>

      {/* Terms & Conditions Modal */}
      {showTermsModal && (
        <div className="fixed inset-0 z-50 bg-stone-950/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl border border-stone-300 shadow-2xl p-6 max-w-lg w-full space-y-4 max-h-[85vh] flex flex-col">
            <div className="flex items-center justify-between border-b border-stone-200 pb-3">
              <h3 className="text-base font-bold text-stone-900 flex items-center gap-2">
                <FileText className="w-4 h-4 text-blue-700" />
                <span>Terms of Service & HIPAA BAA</span>
              </h3>
              <button
                onClick={() => setShowTermsModal(false)}
                className="text-stone-400 hover:text-stone-700 text-xs font-bold"
              >
                ✕
              </button>
            </div>

            <div className="flex-1 overflow-y-auto text-xs text-stone-600 space-y-3 pr-2">
              <p className="font-semibold text-stone-800">
                1. HIPAA Business Associate Agreement (BAA) Summary
              </p>
              <p>
                Office Intelligence operates as a Business Associate for covered entities under 45 CFR § 164.502(e) and § 164.504(e). All Protected Health Information (PHI) and electronic health records stored or processed within Office Intelligence are encrypted using AES-256 at rest and TLS 1.3 in transit.
              </p>
              <p className="font-semibold text-stone-800">
                2. Practice Operational Configuration & Data Ownership
              </p>
              <p>
                Your medical practice retains 100% ownership of all patient charts, surgical schedules, billing claims, and provider credentialing records. Exporting full data archives is supported at any time in standardized HL7 FHIR and PDF formats.
              </p>
              <p className="font-semibold text-stone-800">
                3. Automated AI Agent Boundaries
              </p>
              <p>
                Office Intelligence provides automated suggestions, readiness scoring, and administrative triage. All clinical care decisions remain under the authoritative discretion of the licensed attending physician and medical director.
              </p>
            </div>

            <div className="border-t border-stone-200 pt-3 flex justify-end">
              <button
                onClick={() => {
                  setAgreeTerms(true);
                  setShowTermsModal(false);
                }}
                className="px-4 py-2 bg-blue-700 text-white rounded-xl text-xs font-bold hover:bg-blue-800 cursor-pointer"
              >
                I Agree & Accept Terms
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Footer */}
      <footer className="p-6 text-center text-xs text-stone-500">
        <p>© 2026 Office Intelligence Systems Inc. HIPAA-Compliant Medical Operating Platform.</p>
      </footer>

    </div>
  );
};
