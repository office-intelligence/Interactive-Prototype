import React, { useState, useEffect } from 'react';
import { 
  Home, 
  Calendar, 
  FileText, 
  CreditCard, 
  Settings, 
  Sparkles, 
  Activity,
  ChevronRight,
  Layout,
  PanelLeftOpen,
  PanelLeftClose,
  Zap,
  Sliders,
  LogOut,
  Globe,
  Stethoscope,
  Users,
  MessageSquare,
  X
} from 'lucide-react';
import { AuthUser, PracticeConfig } from '../types';
import { AdminActiveSection } from './AdministrationPage';
import { getUnreadCount, subscribeToMessageUpdates } from '../utils/portalMessageStore';

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onOpenAIChat: () => void;
  needsAttentionCount: number;
  isCollapsed?: boolean;
  onToggleCollapse?: () => void;
  currentUser?: AuthUser | null;
  onLogout?: () => void;
  onNavigateLanding?: () => void;
  onNavigatePortal?: () => void;
  onNavigateAdminSection?: (section: AdminActiveSection) => void;
  practiceConfig?: PracticeConfig;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  setActiveTab,
  onOpenAIChat,
  needsAttentionCount,
  isCollapsed = false,
  onToggleCollapse,
  currentUser,
  onLogout,
  onNavigateLanding,
  onNavigatePortal,
  onNavigateAdminSection,
  practiceConfig,
}) => {
  const [unreadPortalMessages, setUnreadPortalMessages] = useState<number>(() => getUnreadCount());

  useEffect(() => {
    const updateCount = () => {
      setUnreadPortalMessages(getUnreadCount());
    };
    updateCount();
    const unsubscribe = subscribeToMessageUpdates(updateCount);
    return () => unsubscribe();
  }, []);

  const navItems: { id: string; label: string; icon: any; badge?: number }[] = [
    { id: 'home', label: 'Home Dashboard', icon: Home },
    { 
      id: 'messages', 
      label: 'Patient Messages', 
      icon: MessageSquare, 
      badge: unreadPortalMessages > 0 ? unreadPortalMessages : undefined 
    },
    { id: 'ai-home', label: 'AI Intelligence Hub', icon: Sparkles },
    { id: 'workflows', label: 'AI Workflows', icon: Zap },
    { id: 'schedule', label: 'Schedule Matrix', icon: Calendar },
    { id: 'patients', label: 'Patient Chart', icon: FileText, badge: needsAttentionCount > 0 ? needsAttentionCount : undefined },
    { id: 'billing', label: 'Billing & Invoices', icon: CreditCard },
    { id: 'admin', label: 'Administration', icon: Settings },
  ];

  const userInitials = currentUser 
    ? `${currentUser.firstName[0] || ''}${currentUser.lastName[0] || ''}`.toUpperCase()
    : 'AS';

  const userDisplayName = currentUser
    ? `${currentUser.firstName} ${currentUser.lastName}`
    : 'Dr. Alistair Sterling, MD';

  const practiceDisplayName = practiceConfig?.practiceName || 'Aura Vanguard Surgical & Aesthetic Pavilion';
  const practiceLocation = practiceConfig?.city && practiceConfig?.state 
    ? `${practiceConfig.city}, ${practiceConfig.state}` 
    : 'Beverly Hills, California';

  const handleItemClick = (id: string) => {
    setActiveTab(id);
    // On small screens, automatically close the sidebar drawer
    if (window.innerWidth < 1024 && onToggleCollapse && !isCollapsed) {
      onToggleCollapse();
    }
  };

  if (isCollapsed) {
    return (
      <aside className="hidden md:flex h-screen w-16 bg-white border-r border-stone-200/80 flex-col justify-between items-center shrink-0 select-none py-4 px-2 sticky top-0 z-30 transition-all duration-300 shadow-2xs">
        {/* Top Icon Header with Expand Toggle */}
        <div className="flex flex-col items-center gap-4 w-full">
          <button
            onClick={onToggleCollapse}
            className="w-10 h-10 rounded-xl bg-slate-900 hover:bg-slate-800 text-white flex items-center justify-center shadow-md transition-all hover:scale-105 active:scale-95 cursor-pointer relative group"
            title="Expand Navigation Drawer"
            id="sidebar-expand-btn"
          >
            <Activity className="w-5 h-5 text-teal-300 group-hover:hidden" />
            <PanelLeftOpen className="w-5 h-5 text-teal-300 hidden group-hover:block animate-in fade-in" />
            
            {/* Tooltip */}
            <span className="absolute left-14 top-1/2 -translate-y-1/2 px-2.5 py-1 bg-slate-900 text-white text-[11px] font-bold rounded-lg shadow-xl opacity-0 pointer-events-none group-hover:opacity-100 transition-opacity whitespace-nowrap z-50">
              Expand Navigation
            </span>
          </button>

          <div className="w-8 h-[1px] bg-stone-200/80 my-1" />

          {/* Icon Navigation List */}
          <nav className="flex flex-col items-center gap-2 w-full">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => handleItemClick(item.id)}
                  className={`relative w-11 h-11 rounded-xl flex items-center justify-center transition-all cursor-pointer group ${
                    isActive
                      ? 'bg-blue-700 text-white shadow-md shadow-blue-700/30'
                      : 'text-stone-500 hover:text-stone-900 hover:bg-stone-100'
                  }`}
                  id={`sidebar-icon-nav-${item.id}`}
                >
                  <Icon className="w-5 h-5" />

                  {/* Badge Notification Indicator */}
                  {item.badge && (
                    <span className="absolute top-1.5 right-1.5 w-2.5 h-2.5 bg-amber-500 rounded-full border-2 border-white ring-1 ring-amber-300" />
                  )}

                  {/* Hover Tooltip Label */}
                  <span className="absolute left-14 top-1/2 -translate-y-1/2 px-2.5 py-1 bg-slate-900 text-white text-[11px] font-bold rounded-lg shadow-xl opacity-0 pointer-events-none group-hover:opacity-100 transition-opacity whitespace-nowrap z-50 flex items-center gap-1.5">
                    <span>{item.label}</span>
                    {item.badge && (
                      <span className="px-1.5 py-0.2 bg-amber-500 text-white rounded-full text-[9px] font-bold">
                        {item.badge}
                      </span>
                    )}
                  </span>
                </button>
              );
            })}
          </nav>
        </div>

        {/* Bottom Profile Avatar Icon */}
        <div className="flex flex-col items-center gap-2 w-full pt-3 border-t border-stone-200/80">
          <button
            onClick={() => {
              if (onNavigateAdminSection) {
                onNavigateAdminSection('configure-practice');
              } else {
                handleItemClick('admin');
              }
            }}
            className="w-10 h-10 rounded-full bg-gradient-to-tr from-slate-900 to-blue-900 text-white font-bold text-xs flex items-center justify-center shadow-xs cursor-pointer group relative hover:ring-2 hover:ring-blue-400 transition-all"
            title="Configure Practice / Profile"
          >
            {userInitials}
            <span className="absolute left-14 top-1/2 -translate-y-1/2 px-2.5 py-1 bg-slate-900 text-white text-[11px] font-bold rounded-lg shadow-xl opacity-0 pointer-events-none group-hover:opacity-100 transition-opacity whitespace-nowrap z-50">
              {userDisplayName} (Configure Practice)
            </span>
          </button>
        </div>
      </aside>
    );
  }

  return (
    <>
      {/* Backdrop for click-outside on small/tablet screens */}
      <div 
        onClick={onToggleCollapse}
        className="fixed inset-0 z-40 bg-slate-950/40 backdrop-blur-xs transition-opacity lg:hidden animate-in fade-in"
      />

      <aside className="fixed lg:sticky top-0 left-0 z-50 h-screen w-72 sm:w-64 max-w-[85vw] bg-white border-r border-stone-200/80 flex flex-col justify-between shrink-0 select-none p-4 shadow-2xl lg:shadow-none transition-all duration-300 animate-in slide-in-from-left">
        <div className="space-y-4 overflow-y-auto">
          
          {/* Brand Header with Collapse / Close Button */}
          <div className="px-1 py-1">
            <div className="flex items-start justify-between gap-2">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-slate-900 via-blue-900 to-indigo-900 flex items-center justify-center text-white shadow-md shrink-0">
                  <Sparkles className="w-5 h-5 text-teal-300" />
                </div>
                <div>
                  <h1 className="font-bold text-stone-900 tracking-tight text-sm leading-snug">
                    Office Intelligence
                  </h1>
                  <div className="flex items-center gap-1 text-[11px] font-semibold text-blue-700">
                    <Activity className="w-3 h-3 text-teal-600" />
                    <span>Medical OS</span>
                  </div>
                </div>
              </div>

              {/* Close/Collapse Button */}
              {onToggleCollapse && (
                <button
                  onClick={onToggleCollapse}
                  className="p-2 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-600 hover:text-stone-900 transition-colors cursor-pointer shrink-0"
                  title="Close Navigation Drawer"
                  aria-label="Close Navigation Drawer"
                  id="sidebar-collapse-btn"
                >
                  <X className="w-5 h-5 text-stone-600 lg:hidden" />
                  <PanelLeftClose className="w-5 h-5 text-stone-600 hidden lg:block" />
                </button>
              )}
            </div>

            {/* Facility Selection Pill (Click to Configure Practice) */}
            <button
              type="button"
              onClick={() => {
                if (onNavigateAdminSection) {
                  onNavigateAdminSection('configure-practice');
                } else {
                  handleItemClick('admin');
                }
              }}
              className="w-full mt-3.5 p-2.5 bg-stone-50 hover:bg-blue-50/70 rounded-xl border border-stone-200 hover:border-blue-300 shadow-2xs transition-all cursor-pointer text-left group"
              title="Click to Configure Practice"
            >
              <div className="text-xs font-bold text-stone-900 group-hover:text-blue-950 flex items-center justify-between">
                <span className="truncate">{practiceDisplayName}</span>
                <span className="w-2 h-2 rounded-full bg-emerald-500 shrink-0"></span>
              </div>
              <div className="text-[11px] text-stone-500 group-hover:text-blue-700 mt-0.5 flex items-center justify-between">
                <span className="truncate">{practiceLocation}</span>
                <Sliders className="w-3 h-3 text-stone-400 group-hover:text-blue-600 group-hover:rotate-45 transition-transform shrink-0" />
              </div>
            </button>
          </div>

          {/* Navigation Items */}
          <div className="space-y-1">
            <div className="px-3 text-[10px] font-bold text-stone-400 tracking-wider uppercase mb-1">
              Workspace Navigation
            </div>
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => handleItemClick(item.id)}
                  className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-medium transition-all cursor-pointer ${
                    isActive
                      ? 'bg-slate-900 text-white shadow-sm font-bold'
                      : 'text-stone-700 hover:text-stone-950 hover:bg-stone-100'
                  }`}
                  id={`sidebar-nav-${item.id}`}
                >
                  <div className="flex items-center gap-2.5">
                    <Icon className={`w-4 h-4 ${isActive ? 'text-teal-300' : 'text-stone-500'}`} />
                    <span>{item.label}</span>
                  </div>
                  {item.badge && (
                    <span
                      className={`px-1.5 py-0.5 rounded-full text-[10px] font-bold ${
                        isActive
                          ? 'bg-amber-500 text-white'
                          : 'bg-amber-100 text-amber-900 border border-amber-200'
                      }`}
                    >
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>

        {/* User Footer Profile & Landing Page Jump */}
        <div className="pt-3 pb-1 border-t border-stone-200/80 space-y-2 bg-white">
          <div className="flex items-center justify-between px-1">
            <div className="flex items-center gap-2.5 overflow-hidden">
              <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-slate-900 to-blue-900 text-white font-bold text-xs flex items-center justify-center shadow-xs shrink-0">
                {userInitials}
              </div>
              <div className="overflow-hidden text-left">
                <p className="text-xs font-bold text-stone-900 truncate leading-snug">
                  {userDisplayName}
                </p>
                <p className="text-[10px] font-medium text-stone-500 truncate">Attending Physician / Admin</p>
              </div>
            </div>

            {onLogout && (
              <button
                onClick={onLogout}
                className="p-1.5 text-stone-400 hover:text-rose-600 rounded-lg hover:bg-rose-50 transition-colors cursor-pointer"
                title="Log Out"
              >
                <LogOut className="w-4 h-4" />
              </button>
            )}
          </div>

          {onNavigatePortal && (
            <button
              onClick={() => {
                if (window.innerWidth < 1024 && onToggleCollapse) {
                  onToggleCollapse();
                }
                onNavigatePortal();
              }}
              id="sidebar-patient-portal-btn"
              className="w-full py-2 px-2 bg-gradient-to-r from-teal-500/10 via-cyan-500/10 to-blue-500/10 hover:from-teal-500/20 hover:to-blue-500/20 text-teal-800 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer border border-teal-500/30 shadow-2xs group"
              title="Open Patient Portal View"
            >
              <Users className="w-3.5 h-3.5 text-teal-600 group-hover:scale-110 transition-transform" />
              <span>Patient Portal View</span>
            </button>
          )}

          {onNavigateLanding && (
            <button
              onClick={() => {
                if (window.innerWidth < 1024 && onToggleCollapse) {
                  onToggleCollapse();
                }
                onNavigateLanding();
              }}
              className="w-full py-1.5 px-2 bg-stone-50 hover:bg-stone-100 text-stone-600 hover:text-stone-900 rounded-lg text-[11px] font-semibold flex items-center justify-center gap-1.5 transition-colors cursor-pointer border border-stone-200/60"
            >
              <Globe className="w-3.5 h-3.5 text-blue-700" />
              <span>View Public Website</span>
            </button>
          )}
        </div>
      </aside>
    </>
  );
};
