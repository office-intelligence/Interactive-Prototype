import React from 'react';
import { CommunicationStats } from '../types';
import { Clock, MessageSquare, ShieldCheck, FileCheck, Package, PenTool, Inbox, ArrowUpRight } from 'lucide-react';

interface CommunicationWidgetProps {
  stats: CommunicationStats;
  onSelectCategory: (category: string) => void;
}

export const CommunicationWidget: React.FC<CommunicationWidgetProps> = ({
  stats,
  onSelectCategory,
}) => {
  const waitingTotal = stats.insuranceApproval + stats.labResults + stats.implantShipment + stats.physicianSignature;
  const commTotal = stats.patientMessages + stats.referrals + stats.insuranceQueries + stats.labNotifications;

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      {/* Waiting For Box */}
      <div className="bg-white/95 rounded-2xl border border-stone-200/90 shadow-2xs p-4 space-y-3">
        <div className="flex items-center justify-between border-b border-stone-200/60 pb-2">
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4 text-amber-800" />
            <h4 className="text-xs font-bold text-stone-900 tracking-tight">
              Waiting For ({waitingTotal})
            </h4>
          </div>
        </div>

        <div className="space-y-1.5 text-xs">
          {[
            { label: 'Insurance approval', count: stats.insuranceApproval, icon: ShieldCheck },
            { label: 'Lab results', count: stats.labResults, icon: FileCheck },
            { label: 'Implant shipment', count: stats.implantShipment, icon: Package },
            { label: 'Physician signature', count: stats.physicianSignature, icon: PenTool },
          ].map((item, idx) => {
            const Icon = item.icon;
            return (
              <button
                key={idx}
                onClick={() => onSelectCategory(item.label)}
                className="w-full flex items-center justify-between p-2 rounded-xl hover:bg-amber-50/60 transition-colors text-stone-700 font-medium group"
              >
                <div className="flex items-center gap-2">
                  <Icon className="w-3.5 h-3.5 text-stone-400 group-hover:text-amber-800 transition-colors" />
                  <span>{item.label}</span>
                </div>
                <span className="w-5 h-5 rounded-full bg-amber-100/90 text-amber-950 font-bold text-[10px] flex items-center justify-center border border-amber-200">
                  {item.count}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Communication Center Box */}
      <div className="bg-white/95 rounded-2xl border border-stone-200/90 shadow-2xs p-4 space-y-3">
        <div className="flex items-center justify-between border-b border-stone-200/60 pb-2">
          <div className="flex items-center gap-2">
            <MessageSquare className="w-4 h-4 text-amber-800" />
            <h4 className="text-xs font-bold text-stone-900 tracking-tight">
              Communication Center ({commTotal})
            </h4>
          </div>
        </div>

        <div className="space-y-1.5 text-xs">
          {[
            { label: 'Patient messages', count: stats.patientMessages, icon: MessageSquare },
            { label: 'Referrals', count: stats.referrals, icon: ArrowUpRight },
            { label: 'Insurance', count: stats.insuranceQueries, icon: ShieldCheck },
            { label: 'Lab notifications', count: stats.labNotifications, icon: Inbox },
          ].map((item, idx) => {
            const Icon = item.icon;
            return (
              <button
                key={idx}
                onClick={() => onSelectCategory(item.label)}
                className="w-full flex items-center justify-between p-2 rounded-xl hover:bg-amber-50/60 transition-colors text-stone-700 font-medium group"
              >
                <div className="flex items-center gap-2">
                  <Icon className="w-3.5 h-3.5 text-stone-400 group-hover:text-amber-800 transition-colors" />
                  <span>{item.label}</span>
                </div>
                <span className="w-5 h-5 rounded-full bg-amber-100/90 text-amber-950 font-bold text-[10px] flex items-center justify-center border border-amber-200">
                  {item.count}
                </span>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
