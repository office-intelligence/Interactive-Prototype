import React, { useState } from 'react';
import { 
  Printer, 
  X, 
  Download, 
  Check, 
  FileText, 
  CreditCard, 
  Tag, 
  User, 
  ShieldCheck, 
  Phone, 
  Calendar, 
  Building2, 
  Stethoscope, 
  AlertCircle, 
  Copy,
  ExternalLink
} from 'lucide-react';
import { PatientCase } from '../types';
import { 
  generateSampleDriverLicense, 
  generateSampleInsuranceFront, 
  generateSampleInsuranceBack 
} from '../utils/cardTemplates';

export type PrintOptionType = 'labels' | 'facesheet' | 'visit-summary' | 'cards';

interface PatientChartPrintModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialOption: PrintOptionType;
  patient: PatientCase;
  onShowToast?: (msg: string) => void;
  dos?: string;
}

export const PatientChartPrintModal: React.FC<PatientChartPrintModalProps> = ({
  isOpen,
  onClose,
  initialOption = 'facesheet',
  patient,
  onShowToast,
  dos = '05/06/2026'
}) => {
  const [selectedTab, setSelectedTab] = useState<PrintOptionType>(initialOption);
  const [labelQuantity, setLabelQuantity] = useState<number>(30); // Standard Avery 5150 sheet has 30 labels
  const [labelFormat, setLabelFormat] = useState<'sheet' | 'single'>('sheet');

  if (!isOpen || !patient) return null;

  // Derived patient details
  const patientDob = patient.dob || '02/11/1972';
  const providerName = patient.surgeon || 'Dr. Alistair Sterling, MD';
  const anesthesiologist = patient.anesthesiologist || 'Dr. Raymond Cruz, MD';
  const dateOfService = dos || '05/06/2026';
  const patientMrn = patient.patientId || '113561';
  const patientPhone = patient.phone || '(310) 555-0164';
  const patientAddress = '435 N Bedford Dr, Suite 400, Beverly Hills, CA 90210';
  const insuranceCarrier = patient.paymentType === 'Self-Pay' ? 'Self-Pay (Private Direct)' : 'Blue Shield of California';
  const policyNumber = patient.patientId === '115088' ? 'ANT-8819203' : 'XEN98127340';
  const groupNumber = patient.patientId === '115088' ? 'GRP-77210' : 'GRP-88120';
  const procedureName = patient.procedure || 'Bilateral Gel Implant Exchange & Pocket Capsulorrhaphy';
  const allergiesList = patient.allergies && patient.allergies.length > 0 ? patient.allergies : ['Penicillin (Hives/Urticaria)'];

  // Card URLs
  const idCardSrc = patient.idCardUrl || generateSampleDriverLicense(patient.name.toUpperCase(), patientDob, `C${patientMrn}45`, patientAddress);
  const insFrontSrc = patient.insuranceCardFrontUrl || generateSampleInsuranceFront(patient.name.toUpperCase(), insuranceCarrier, policyNumber, groupNumber);
  const insBackSrc = patient.insuranceCardBackUrl || generateSampleInsuranceBack(insuranceCarrier, '1-800-555-0199');

  const handlePrint = () => {
    window.print();
    if (onShowToast) {
      onShowToast(`Sent ${getOptionTitle(selectedTab)} to system print dialog.`);
    }
  };

  function getOptionTitle(opt: PrintOptionType): string {
    switch (opt) {
      case 'labels': return 'Avery 5150 Labels';
      case 'facesheet': return 'Patient Facesheet';
      case 'visit-summary': return 'Visit Summary Report';
      case 'cards': return 'ID & Insurance Cards';
    }
  }

  return (
    <div className="fixed inset-0 z-50 bg-stone-950/75 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4 overflow-y-auto print:p-0 print:bg-white">
      
      {/* Print Specific CSS to ensure clean paper output */}
      <style>{`
        @media print {
          body * {
            visibility: hidden;
          }
          #printable-patient-chart-content, #printable-patient-chart-content * {
            visibility: visible;
          }
          #printable-patient-chart-content {
            position: absolute;
            left: 0;
            top: 0;
            width: 100%;
            margin: 0;
            padding: 10px;
            background: white !important;
            color: black !important;
          }
          .no-print {
            display: none !important;
          }
        }
      `}</style>

      <div className="bg-white rounded-2xl border border-stone-300 shadow-2xl max-w-5xl w-full max-h-[94vh] flex flex-col overflow-hidden animate-in fade-in zoom-in-95 print:border-none print:shadow-none print:max-w-none print:max-h-none">
        
        {/* Modal Header & Options Navigation Bar (hidden on physical print) */}
        <div className="p-4 sm:p-5 border-b border-stone-200 bg-stone-50 flex flex-wrap items-center justify-between gap-4 no-print">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-slate-900 text-white shadow-2xs">
              <Printer className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-bold text-stone-900">
                  Print Patient Chart Documentation
                </h3>
                <span className="px-2 py-0.5 rounded-md text-[11px] font-bold bg-sky-100 text-sky-800">
                  MRN #{patientMrn}
                </span>
              </div>
              <p className="text-xs text-stone-500">
                Patient: <span className="font-semibold text-stone-800">{patient.name}</span> · DOB: <span className="font-semibold text-stone-800">{patientDob}</span> · DOS: <span className="font-semibold text-stone-800">{dateOfService}</span>
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handlePrint}
              id="print-modal-trigger-btn"
              className="px-4 py-2 bg-gradient-to-r from-sky-600 to-blue-700 hover:from-sky-700 hover:to-blue-800 text-white text-xs font-bold rounded-xl shadow-xs flex items-center gap-1.5 cursor-pointer transition-all"
            >
              <Printer className="w-4 h-4" />
              <span>Print Document</span>
            </button>
            <button
              type="button"
              onClick={onClose}
              className="p-2 rounded-xl text-stone-400 hover:text-stone-700 hover:bg-stone-200/70 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* 4 Print Tabs (Labels, Facesheet, Visit Summary, ID & Insurance Cards) */}
        <div className="px-4 sm:px-6 py-2.5 bg-stone-100/80 border-b border-stone-200 flex items-center gap-2 overflow-x-auto text-xs no-print">
          <button
            type="button"
            onClick={() => setSelectedTab('labels')}
            id="print-tab-labels"
            className={`px-3.5 py-2 rounded-xl font-bold flex items-center gap-2 transition-all cursor-pointer whitespace-nowrap ${
              selectedTab === 'labels'
                ? 'bg-white text-slate-900 shadow-xs border border-stone-200'
                : 'text-stone-600 hover:text-stone-900 hover:bg-stone-200/60'
            }`}
          >
            <Tag className="w-3.5 h-3.5 text-sky-600" />
            <span>1. Avery 5150 Labels</span>
          </button>

          <button
            type="button"
            onClick={() => setSelectedTab('facesheet')}
            id="print-tab-facesheet"
            className={`px-3.5 py-2 rounded-xl font-bold flex items-center gap-2 transition-all cursor-pointer whitespace-nowrap ${
              selectedTab === 'facesheet'
                ? 'bg-white text-slate-900 shadow-xs border border-stone-200'
                : 'text-stone-600 hover:text-stone-900 hover:bg-stone-200/60'
            }`}
          >
            <User className="w-3.5 h-3.5 text-indigo-600" />
            <span>2. Facesheet (with ID & Insurance)</span>
          </button>

          <button
            type="button"
            onClick={() => setSelectedTab('visit-summary')}
            id="print-tab-visit-summary"
            className={`px-3.5 py-2 rounded-xl font-bold flex items-center gap-2 transition-all cursor-pointer whitespace-nowrap ${
              selectedTab === 'visit-summary'
                ? 'bg-white text-slate-900 shadow-xs border border-stone-200'
                : 'text-stone-600 hover:text-stone-900 hover:bg-stone-200/60'
            }`}
          >
            <FileText className="w-3.5 h-3.5 text-emerald-600" />
            <span>3. Visit Summary (PDF)</span>
          </button>

          <button
            type="button"
            onClick={() => setSelectedTab('cards')}
            id="print-tab-cards"
            className={`px-3.5 py-2 rounded-xl font-bold flex items-center gap-2 transition-all cursor-pointer whitespace-nowrap ${
              selectedTab === 'cards'
                ? 'bg-white text-slate-900 shadow-xs border border-stone-200'
                : 'text-stone-600 hover:text-stone-900 hover:bg-stone-200/60'
            }`}
          >
            <CreditCard className="w-3.5 h-3.5 text-amber-600" />
            <span>4. ID & Insurance Cards</span>
          </button>
        </div>

        {/* Scrollable Printable Workspace */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 bg-stone-100/60 print:bg-white print:p-0">
          
          <div id="printable-patient-chart-content" className="max-w-4xl mx-auto space-y-6">
            
            {/* ======================================================== */}
            {/* TAB 1: AVERY 5150 LABELS TEMPLATE                        */}
            {/* ======================================================== */}
            {selectedTab === 'labels' && (
              <div className="space-y-4">
                
                {/* Configuration Controls Bar (no-print) */}
                <div className="p-3.5 rounded-xl bg-white border border-stone-200 shadow-2xs flex flex-wrap items-center justify-between gap-3 text-xs no-print">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-stone-800">Format: Standard Avery 5150 (1" × 2-5/8", 30 per sheet)</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <label className="flex items-center gap-1.5 cursor-pointer font-medium text-stone-700">
                      <input
                        type="radio"
                        name="labelFormat"
                        checked={labelFormat === 'sheet'}
                        onChange={() => {
                          setLabelFormat('sheet');
                          setLabelQuantity(30);
                        }}
                        className="text-sky-600"
                      />
                      <span>Full Sheet (30 Labels)</span>
                    </label>
                    <label className="flex items-center gap-1.5 cursor-pointer font-medium text-stone-700">
                      <input
                        type="radio"
                        name="labelFormat"
                        checked={labelFormat === 'single'}
                        onChange={() => {
                          setLabelFormat('single');
                          setLabelQuantity(6);
                        }}
                        className="text-sky-600"
                      />
                      <span>Sample Strip (6 Labels)</span>
                    </label>
                  </div>
                </div>

                {/* Simulated Avery 5150 Sheet (8.5 x 11 inches layout, 3 columns x 10 rows) */}
                <div className="bg-white p-6 sm:p-8 rounded-xl border border-stone-300 shadow-sm text-stone-900 print:shadow-none print:border-none print:p-2">
                  <div className="text-[10px] text-stone-400 font-mono text-center pb-3 border-b border-stone-200 mb-4 print:hidden">
                    AVERY 5150 / 8160 COMPLIANT MEDICAL CHART & SPECIMEN LABELS
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3 print:grid-cols-3">
                    {Array.from({ length: labelQuantity }).map((_, idx) => (
                      <div
                        key={idx}
                        className="p-3 rounded-lg border border-dashed border-stone-300 bg-white hover:border-sky-400 hover:shadow-2xs transition-all flex flex-col justify-between h-[105px] text-left select-none relative overflow-hidden"
                      >
                        {/* Label Header */}
                        <div>
                          <div className="flex items-center justify-between border-b border-stone-200 pb-1">
                            <span className="font-extrabold text-[12px] text-stone-900 tracking-tight leading-tight truncate">
                              {patient.name.toUpperCase()}
                            </span>
                            <span className="text-[9px] font-mono font-bold text-sky-700 shrink-0 ml-1">
                              #{patientMrn}
                            </span>
                          </div>

                          {/* DOB, DOS, Provider */}
                          <div className="mt-1 space-y-0.5 text-[10px] font-medium text-stone-700 leading-snug">
                            <div className="flex justify-between">
                              <span>DOB: <strong className="text-stone-900 font-bold">{patientDob}</strong></span>
                              <span>DOS: <strong className="text-stone-900 font-bold">{dateOfService}</strong></span>
                            </div>
                            <div className="truncate text-stone-800 font-semibold">
                              Prov: {providerName}
                            </div>
                          </div>
                        </div>

                        {/* Label Footer: Barcode representation & Room */}
                        <div className="pt-1 border-t border-stone-100 flex items-center justify-between">
                          <div className="font-mono text-[8px] text-stone-400 tracking-widest uppercase">
                            ||| | |||| | ||| ||||
                          </div>
                          <span className="text-[8px] font-bold text-stone-500 uppercase">
                            {patient.room || 'OR-2'}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

              </div>
            )}

            {/* ======================================================== */}
            {/* TAB 2: FACESHEET WITH KEY CLINICAL DATA & CARDS          */}
            {/* ======================================================== */}
            {selectedTab === 'facesheet' && (
              <div className="bg-white p-6 sm:p-8 rounded-xl border border-stone-300 shadow-sm text-stone-900 space-y-6 print:shadow-none print:border-none print:p-2">
                
                {/* Facility Header */}
                <div className="border-b-2 border-stone-900 pb-4 flex flex-wrap items-center justify-between gap-4">
                  <div className="space-y-0.5">
                    <div className="text-[10px] font-black tracking-widest text-sky-800 uppercase flex items-center gap-1.5">
                      <Building2 className="w-3.5 h-3.5 text-sky-600" />
                      <span>AURA VANGUARD SURGICAL & AESTHETIC PAVILION</span>
                    </div>
                    <h2 className="text-xl font-black text-stone-900 uppercase tracking-tight">
                      PATIENT CLINICAL FACESHEET
                    </h2>
                    <p className="text-[11px] text-stone-500">
                      435 N Bedford Dr, Suite 400, Beverly Hills, CA 90210 · (310) 555-0100
                    </p>
                  </div>

                  <div className="text-right text-[11px] space-y-0.5">
                    <div className="font-mono font-bold text-stone-900">
                      MRN: <span className="text-sky-700 font-extrabold">#{patientMrn}</span>
                    </div>
                    <div className="text-stone-500">
                      Printed: {new Date().toLocaleDateString('en-US', { month: 'short', day: '2-digit', year: 'numeric' })} {new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </div>
                    <div className="inline-block px-2 py-0.5 bg-emerald-50 text-emerald-800 font-bold rounded-sm border border-emerald-200 text-[10px]">
                      CONFIDENTIAL MEDICAL RECORD
                    </div>
                  </div>
                </div>

                {/* Section 1: Patient ID / Demographics */}
                <div className="space-y-2">
                  <div className="bg-stone-900 text-white px-3 py-1 text-xs font-bold uppercase tracking-wider rounded-xs flex items-center justify-between">
                    <span>1. Patient Identification & Demographics</span>
                    <span className="text-[10px] font-normal text-stone-300">Status: Active</span>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-3 bg-stone-50/70 border border-stone-200 rounded-lg text-xs">
                    <div>
                      <span className="text-[10px] text-stone-500 font-bold uppercase block">Legal Name</span>
                      <span className="font-bold text-stone-900 text-sm">{patient.name}</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-stone-500 font-bold uppercase block">Date of Birth / Age</span>
                      <span className="font-bold text-stone-800">{patientDob} ({patient.age || '54'}y)</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-stone-500 font-bold uppercase block">Gender / SSN</span>
                      <span className="font-semibold text-stone-800">{patient.gender || 'Female'} · ***-**-6102</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-stone-500 font-bold uppercase block">Primary Phone</span>
                      <span className="font-bold text-stone-900">{patientPhone}</span>
                    </div>
                    <div className="col-span-2 sm:col-span-3">
                      <span className="text-[10px] text-stone-500 font-bold uppercase block">Residential Address</span>
                      <span className="font-semibold text-stone-800">{patientAddress}</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-stone-500 font-bold uppercase block">Preferred Language</span>
                      <span className="font-semibold text-stone-800">English (No Interpreter Req)</span>
                    </div>
                  </div>
                </div>

                {/* Section 2: Visit & Encounter Details */}
                <div className="space-y-2">
                  <div className="bg-stone-900 text-white px-3 py-1 text-xs font-bold uppercase tracking-wider rounded-xs flex items-center justify-between">
                    <span>2. Visit & Surgical Admission Details (Most Recent DOS)</span>
                    <span className="text-[10px] font-normal text-stone-300">Encounter: Elective Outpatient</span>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-3 bg-stone-50/70 border border-stone-200 rounded-lg text-xs">
                    <div>
                      <span className="text-[10px] text-stone-500 font-bold uppercase block">Date of Service (DOS)</span>
                      <span className="font-bold text-sky-800">{dateOfService}</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-stone-500 font-bold uppercase block">Admission / Arrival Time</span>
                      <span className="font-bold text-stone-800">{patient.arrivalTime || '07:15 AM'} (Sched: {patient.scheduledTime || '10:30 AM'})</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-stone-500 font-bold uppercase block">Attending Surgeon</span>
                      <span className="font-bold text-stone-900">{providerName}</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-stone-500 font-bold uppercase block">Anesthesiologist</span>
                      <span className="font-bold text-stone-800">{anesthesiologist}</span>
                    </div>
                    <div className="col-span-2 sm:col-span-4">
                      <span className="text-[10px] text-stone-500 font-bold uppercase block">Scheduled Surgical Procedure</span>
                      <span className="font-bold text-stone-900 text-xs">{procedureName}</span>
                    </div>
                  </div>
                </div>

                {/* Section 3: Clinical Codes, Diagnoses & Allergies */}
                <div className="space-y-2">
                  <div className="bg-stone-900 text-white px-3 py-1 text-xs font-bold uppercase tracking-wider rounded-xs flex items-center justify-between">
                    <span>3. Clinical Codes & Diagnoses</span>
                    <span className="text-[10px] font-normal text-stone-300">ICD-10 / CPT</span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 p-3 bg-stone-50/70 border border-stone-200 rounded-lg text-xs">
                    <div>
                      <span className="text-[10px] text-stone-500 font-bold uppercase block">Admitting Diagnosis (ICD-10)</span>
                      <span className="font-bold text-stone-900">Z41.1 / N64.4</span>
                      <p className="text-[10px] text-stone-500 mt-0.5">Encounter for elective breast revision & capsular contracture</p>
                    </div>
                    <div>
                      <span className="text-[10px] text-stone-500 font-bold uppercase block">Chief Complaint</span>
                      <span className="font-semibold text-stone-800">Bilateral capsular firmness & elective exchange</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-stone-500 font-bold uppercase block">Documented Allergies</span>
                      <div className="flex flex-wrap gap-1 mt-0.5">
                        {allergiesList.map((alg, i) => (
                          <span key={i} className="px-2 py-0.5 rounded-sm bg-rose-100 text-rose-800 font-bold text-[10px] border border-rose-200">
                            {alg.toUpperCase()}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Section 4: Insurance Data */}
                <div className="space-y-2">
                  <div className="bg-stone-900 text-white px-3 py-1 text-xs font-bold uppercase tracking-wider rounded-xs flex items-center justify-between">
                    <span>4. Primary & Secondary Insurance Data</span>
                    <span className="text-[10px] font-normal text-stone-300">Verified by Eligibility Gateway</span>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-3 bg-stone-50/70 border border-stone-200 rounded-lg text-xs">
                    <div>
                      <span className="text-[10px] text-stone-500 font-bold uppercase block">Payer / Plan Name</span>
                      <span className="font-bold text-stone-900">{insuranceCarrier}</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-stone-500 font-bold uppercase block">Policy / Member ID</span>
                      <span className="font-mono font-bold text-sky-800">{policyNumber}</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-stone-500 font-bold uppercase block">Group Number</span>
                      <span className="font-mono font-bold text-stone-800">{groupNumber}</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-stone-500 font-bold uppercase block">Prior Authorization #</span>
                      <span className="font-mono font-bold text-emerald-800">AUTH-2026-99210</span>
                    </div>
                  </div>
                </div>

                {/* Section 5: Emergency Contacts & Next of Kin */}
                <div className="space-y-2">
                  <div className="bg-stone-900 text-white px-3 py-1 text-xs font-bold uppercase tracking-wider rounded-xs flex items-center justify-between">
                    <span>5. Emergency Contacts & Next of Kin</span>
                    <span className="text-[10px] font-normal text-stone-300">Responsible Chaperone</span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 p-3 bg-stone-50/70 border border-stone-200 rounded-lg text-xs">
                    <div>
                      <span className="text-[10px] text-stone-500 font-bold uppercase block">Primary Contact (Next of Kin / Spouse)</span>
                      <div className="font-bold text-stone-900">David Kensington (Spouse)</div>
                      <div className="text-stone-600 font-medium">(310) 555-0188 · Authorized for post-op discharge transport</div>
                    </div>
                    <div>
                      <span className="text-[10px] text-stone-500 font-bold uppercase block">Secondary Emergency Contact</span>
                      <div className="font-bold text-stone-900">Melissa Vance (Sister)</div>
                      <div className="text-stone-600 font-medium">(310) 555-0144 · Alternate emergency contact</div>
                    </div>
                  </div>
                </div>

                {/* Section 6: COPIES OF ID CARD & INSURANCE CARD (FRONT & BACK) AT BOTTOM OF FACESHEET */}
                <div className="space-y-2 pt-2 border-t-2 border-stone-200">
                  <div className="bg-stone-900 text-white px-3 py-1 text-xs font-bold uppercase tracking-wider rounded-xs flex items-center justify-between">
                    <span>6. Scanned Patient Photo Identification & Insurance Card Copies (DOS: {dateOfService})</span>
                    <span className="text-[10px] font-normal text-stone-300">Front & Back On File</span>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-1">
                    
                    {/* ID Card / Driver License */}
                    <div className="p-2.5 rounded-xl bg-stone-50 border border-stone-300 space-y-1 text-center">
                      <div className="text-[10px] font-bold text-stone-700 uppercase">
                        State Photo ID / Driver License
                      </div>
                      <div className="rounded-lg overflow-hidden border border-stone-200 shadow-2xs bg-white">
                        <img 
                          src={idCardSrc} 
                          alt="Patient Driver License" 
                          className="w-full h-auto object-contain"
                          referrerPolicy="no-referrer"
                        />
                      </div>
                    </div>

                    {/* Insurance Card - Front */}
                    <div className="p-2.5 rounded-xl bg-stone-50 border border-stone-300 space-y-1 text-center">
                      <div className="text-[10px] font-bold text-stone-700 uppercase">
                        Primary Insurance Card (Front)
                      </div>
                      <div className="rounded-lg overflow-hidden border border-stone-200 shadow-2xs bg-white">
                        <img 
                          src={insFrontSrc} 
                          alt="Insurance Card Front" 
                          className="w-full h-auto object-contain"
                          referrerPolicy="no-referrer"
                        />
                      </div>
                    </div>

                    {/* Insurance Card - Back */}
                    <div className="p-2.5 rounded-xl bg-stone-50 border border-stone-300 space-y-1 text-center">
                      <div className="text-[10px] font-bold text-stone-700 uppercase">
                        Primary Insurance Card (Back)
                      </div>
                      <div className="rounded-lg overflow-hidden border border-stone-200 shadow-2xs bg-white">
                        <img 
                          src={insBackSrc} 
                          alt="Insurance Card Back" 
                          className="w-full h-auto object-contain"
                          referrerPolicy="no-referrer"
                        />
                      </div>
                    </div>

                  </div>
                </div>

                {/* Facesheet Signoff Footer */}
                <div className="pt-4 border-t border-stone-300 grid grid-cols-2 gap-6 text-xs text-stone-600">
                  <div>
                    <span className="block text-[10px] font-bold uppercase text-stone-400">Intake Registrar / Coordinator Signature</span>
                    <div className="border-b border-stone-400 mt-4 pb-1 font-semibold text-stone-800">
                      Sarah Jenkins, CPAR (Verified DOS: {dateOfService})
                    </div>
                  </div>
                  <div>
                    <span className="block text-[10px] font-bold uppercase text-stone-400">Attending Physician Review Attestation</span>
                    <div className="border-b border-stone-400 mt-4 pb-1 font-semibold text-stone-800">
                      {providerName} (Electronic Signature on File)
                    </div>
                  </div>
                </div>

              </div>
            )}

            {/* ======================================================== */}
            {/* TAB 3: VISIT SUMMARY IN PRINT / PDF FORMAT               */}
            {/* ======================================================== */}
            {selectedTab === 'visit-summary' && (
              <div className="bg-white p-6 sm:p-8 rounded-xl border border-stone-300 shadow-sm text-stone-900 space-y-6 print:shadow-none print:border-none print:p-2">
                
                {/* Clinical Report Header */}
                <div className="border-b-2 border-stone-900 pb-4 flex flex-wrap items-center justify-between gap-4">
                  <div className="space-y-0.5">
                    <div className="text-[10px] font-black tracking-widest text-emerald-800 uppercase flex items-center gap-1.5">
                      <FileText className="w-3.5 h-3.5 text-emerald-600" />
                      <span>AURA VANGUARD SURGICAL & AESTHETIC PAVILION</span>
                    </div>
                    <h2 className="text-xl font-black text-stone-900 uppercase tracking-tight">
                      CLINICAL VISIT SUMMARY REPORT
                    </h2>
                    <p className="text-[11px] text-stone-500">
                      Encounter Date: {dateOfService} · Ambulatory Surgery Center Admission
                    </p>
                  </div>

                  <div className="text-right text-[11px] space-y-0.5">
                    <div className="font-bold text-stone-900">Encounter ID: <span className="font-mono text-emerald-700">#ENC-2026-0506</span></div>
                    <div className="text-stone-500">Patient MRN: #{patientMrn}</div>
                    <div className="font-semibold text-stone-700">Provider: {providerName}</div>
                  </div>
                </div>

                {/* Patient Summary Strip */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-3.5 bg-stone-50 border border-stone-200 rounded-lg text-xs">
                  <div>
                    <span className="text-[10px] text-stone-400 font-bold uppercase block">Patient</span>
                    <span className="font-bold text-stone-900">{patient.name}</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-stone-400 font-bold uppercase block">DOB / Age / Gender</span>
                    <span className="font-semibold text-stone-800">{patientDob} ({patient.age}y) · {patient.gender}</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-stone-400 font-bold uppercase block">Admit Vitals</span>
                    <span className="font-semibold text-stone-800">BP 122/78 · P 68 · SpO2 99%</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-stone-400 font-bold uppercase block">Allergies</span>
                    <span className="font-bold text-rose-700">{allergiesList.join(', ')}</span>
                  </div>
                </div>

                {/* Clinical Notes & History */}
                <div className="space-y-4 text-xs text-stone-800 leading-relaxed">
                  
                  {/* Subjective & HPI */}
                  <div className="space-y-1.5">
                    <h4 className="font-bold text-stone-900 uppercase border-b border-stone-200 pb-1 text-xs flex items-center justify-between">
                      <span>1. Subjective & History of Present Illness (HPI)</span>
                      <span className="text-[10px] font-normal text-stone-500">Documented by Attending</span>
                    </h4>
                    <p className="text-stone-700">
                      Patient is a {patient.age}-year-old {patient.gender?.toLowerCase() || 'female'} presenting on {dateOfService} for scheduled outpatient surgical intervention: <strong>{procedureName}</strong>. 
                      Pre-operative medical clearance reviewed. Patient confirms compliance with strict NPO fasting protocol since midnight. No cardiopulmonary symptoms, fever, active infection, or anticoagulant use reported.
                    </p>
                  </div>

                  {/* Physical Exam & Pre-Op Assessment */}
                  <div className="space-y-1.5">
                    <h4 className="font-bold text-stone-900 uppercase border-b border-stone-200 pb-1 text-xs">
                      2. Pre-Operative Physical Examination & Airway
                    </h4>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 p-3 bg-stone-50 border border-stone-200 rounded-lg">
                      <div>
                        <span className="font-bold text-stone-800 block text-[11px]">General & Cardiopulmonary</span>
                        <p className="text-[11px] text-stone-600">Alert, oriented × 4, in no acute distress. RRR without murmurs. Lungs clear to auscultation bilaterally.</p>
                      </div>
                      <div>
                        <span className="font-bold text-stone-800 block text-[11px]">Airway & Surgical Site</span>
                        <p className="text-[11px] text-stone-600">Mallampati Class I airway, full cervical range of motion. Surgical site marked and verified with patient during time-out.</p>
                      </div>
                    </div>
                  </div>

                  {/* Reconciled Medications & Labs */}
                  <div className="space-y-1.5">
                    <h4 className="font-bold text-stone-900 uppercase border-b border-stone-200 pb-1 text-xs">
                      3. Reconciled Medications & Diagnostic Labs
                    </h4>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div className="p-2.5 bg-stone-50 border border-stone-200 rounded-lg space-y-1">
                        <span className="font-bold text-stone-800 block text-[11px]">Pre-Operative Medications Administered</span>
                        <ul className="list-disc list-inside text-[11px] text-stone-600 space-y-0.5">
                          <li>Cefazolin (Ancef) 1g IV in 100mL NS (30 min prior to incision)</li>
                          <li>Ondansetron (Zofran) 4mg IV push</li>
                          <li>Dexamethasone 8mg IV for PONV prophylaxis</li>
                        </ul>
                      </div>
                      <div className="p-2.5 bg-stone-50 border border-stone-200 rounded-lg space-y-1">
                        <span className="font-bold text-stone-800 block text-[11px]">Diagnostic Laboratory Findings</span>
                        <ul className="list-disc list-inside text-[11px] text-stone-600 space-y-0.5">
                          <li>CBC: Hemoglobin 13.4 g/dL, Platelets 248k (Normal)</li>
                          <li>BMP: Creatinine 0.8, Electrolytes normal</li>
                          <li>Coagulation: PT/INR 1.0 (Normal)</li>
                        </ul>
                      </div>
                    </div>
                  </div>

                  {/* Operative Plan & Discharge Instructions */}
                  <div className="space-y-1.5">
                    <h4 className="font-bold text-stone-900 uppercase border-b border-stone-200 pb-1 text-xs">
                      4. Plan, Post-Op Care & Follow-Up Schedule
                    </h4>
                    <div className="p-3 bg-stone-50 border border-stone-200 rounded-lg space-y-2 text-[11px] text-stone-700">
                      <div>
                        <strong>Procedural Plan:</strong> Execute {procedureName} under General Anesthesia with endotracheal intubation.
                      </div>
                      <div>
                        <strong>Discharge Criteria:</strong> Aldrete score &gt; 9, stable vital signs, minimal pain controlled by oral analgesics, tolerating fluids, voided, accompanied by designated responsible adult (David Kensington).
                      </div>
                      <div>
                        <strong>Follow-Up:</strong> Post-operative appointment scheduled at the Pavilion for Day 5 at 10:00 AM for suture inspection and dressing evaluation.
                      </div>
                    </div>
                  </div>

                </div>

                {/* Attestation Signature */}
                <div className="pt-4 border-t border-stone-300 flex flex-wrap items-center justify-between gap-4 text-xs">
                  <div>
                    <div className="text-[10px] text-stone-400 font-bold uppercase">Attending Physician Electronic Signature</div>
                    <div className="font-bold text-stone-900 mt-1 flex items-center gap-1.5">
                      <Check className="w-4 h-4 text-emerald-600" />
                      <span>{providerName} (NPI #1982734102)</span>
                    </div>
                    <div className="text-[10px] text-stone-500">
                      Signed Electronically on {dateOfService} at 08:30 AM PST
                    </div>
                  </div>

                  <div className="text-right text-[10px] text-stone-400">
                    Aura Vanguard Pavilion EMR · Validated Clinical Record
                  </div>
                </div>

              </div>
            )}

            {/* ======================================================== */}
            {/* TAB 4: DEDICATED ID & INSURANCE CARDS PRINTOUT           */}
            {/* ======================================================== */}
            {selectedTab === 'cards' && (
              <div className="bg-white p-6 sm:p-8 rounded-xl border border-stone-300 shadow-sm text-stone-900 space-y-6 print:shadow-none print:border-none print:p-2">
                
                {/* Header */}
                <div className="border-b-2 border-stone-900 pb-3 flex items-center justify-between">
                  <div>
                    <div className="text-[10px] font-black tracking-widest text-amber-800 uppercase flex items-center gap-1.5">
                      <CreditCard className="w-3.5 h-3.5 text-amber-600" />
                      <span>AURA VANGUARD SURGICAL & AESTHETIC PAVILION</span>
                    </div>
                    <h2 className="text-xl font-black text-stone-900 uppercase tracking-tight">
                      PATIENT IDENTIFICATION & INSURANCE CARDS
                    </h2>
                    <p className="text-[11px] text-stone-500">
                      Verified Scans for Billing, Clinical Records & Registration File (DOS: {dateOfService})
                    </p>
                  </div>

                  <div className="text-right text-xs">
                    <div className="font-bold text-stone-900">MRN: #{patientMrn}</div>
                    <div className="text-stone-500 font-semibold">{patient.name}</div>
                  </div>
                </div>

                {/* Cards Container */}
                <div className="space-y-6">
                  
                  {/* Card 1: State Driver License */}
                  <div className="p-4 rounded-xl bg-stone-50 border border-stone-300 space-y-2">
                    <div className="flex items-center justify-between text-xs font-bold text-stone-800">
                      <span>1. Government Photo ID / Driver License</span>
                      <span className="text-[10px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-sm border border-emerald-200">
                        Identity Verified (Real ID)
                      </span>
                    </div>
                    <div className="max-w-lg mx-auto rounded-xl overflow-hidden border border-stone-300 shadow-sm bg-white">
                      <img 
                        src={idCardSrc} 
                        alt="State Driver License" 
                        className="w-full h-auto object-contain"
                        referrerPolicy="no-referrer"
                      />
                    </div>
                  </div>

                  {/* Card 2 & 3: Primary Insurance Card (Front & Back) */}
                  <div className="p-4 rounded-xl bg-stone-50 border border-stone-300 space-y-3">
                    <div className="flex items-center justify-between text-xs font-bold text-stone-800">
                      <span>2. Primary Health Insurance Card (Front & Back)</span>
                      <span className="text-[10px] font-semibold text-sky-700 bg-sky-50 px-2 py-0.5 rounded-sm border border-sky-200">
                        Carrier: {insuranceCarrier}
                      </span>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-1 text-center">
                        <span className="text-[10px] font-bold text-stone-500 uppercase">Card Front</span>
                        <div className="rounded-xl overflow-hidden border border-stone-300 shadow-sm bg-white">
                          <img 
                            src={insFrontSrc} 
                            alt="Insurance Card Front" 
                            className="w-full h-auto object-contain"
                            referrerPolicy="no-referrer"
                          />
                        </div>
                      </div>

                      <div className="space-y-1 text-center">
                        <span className="text-[10px] font-bold text-stone-500 uppercase">Card Back</span>
                        <div className="rounded-xl overflow-hidden border border-stone-300 shadow-sm bg-white">
                          <img 
                            src={insBackSrc} 
                            alt="Insurance Card Back" 
                            className="w-full h-auto object-contain"
                            referrerPolicy="no-referrer"
                          />
                        </div>
                      </div>
                    </div>
                  </div>

                </div>

                {/* Verification Stamp Footer */}
                <div className="p-3.5 bg-stone-50 border border-stone-200 rounded-xl flex items-center justify-between text-xs text-stone-600">
                  <div className="flex items-center gap-2">
                    <ShieldCheck className="w-4 h-4 text-emerald-600" />
                    <span>Eligibility & Photo Identity verified by Admissions Desk on {dateOfService}</span>
                  </div>
                  <div className="font-mono text-[10px] text-stone-400">
                    AUTH-HASH: 9918-2026-AV-CA
                  </div>
                </div>

              </div>
            )}

          </div>

        </div>

        {/* Modal Bottom Controls (no-print) */}
        <div className="p-4 border-t border-stone-200 bg-white flex items-center justify-between gap-3 no-print">
          <div className="text-xs text-stone-500">
            Selected: <strong className="text-stone-800">{getOptionTitle(selectedTab)}</strong> · Prepared for standard 8.5" × 11" paper
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-xs font-semibold text-stone-600 hover:bg-stone-100 cursor-pointer transition-colors"
            >
              Close
            </button>
            <button
              type="button"
              onClick={handlePrint}
              className="px-5 py-2 bg-gradient-to-r from-sky-600 to-blue-700 hover:from-sky-700 hover:to-blue-800 text-white text-xs font-bold rounded-xl shadow-xs flex items-center gap-1.5 cursor-pointer transition-all"
            >
              <Printer className="w-4 h-4" />
              <span>Print {getOptionTitle(selectedTab)}</span>
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
