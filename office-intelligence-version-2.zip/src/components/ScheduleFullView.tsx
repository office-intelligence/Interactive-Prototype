import React, { useState, useEffect, useRef } from 'react';
import { 
  ChevronLeft, 
  ChevronRight, 
  Calendar as CalendarIcon, 
  Printer, 
  BookOpen, 
  Search, 
  ChevronDown, 
  Save, 
  Clock,
  Plus,
  User,
  X,
  CheckCircle2,
  Sparkles,
  Trash2,
  ExternalLink,
  Edit3,
  FileText,
  Phone
} from 'lucide-react';
import { PatientCase, PAYMENT_TYPE_OPTIONS, PracticeConfig } from '../types';
import { 
  searchPatientsByLastName, 
  getPatientAppointmentHistory, 
  PatientAppointmentHistoryRecord, 
  MasterPatientRecord 
} from '../utils/patientDirectory';
import { SchedulePrintModal } from './SchedulePrintModal';

export interface AppointmentItem {
  id: string;
  dayIndex: number;
  room: string;
  startHour: number;
  durationHours: number;
  title: string;
  surgeon: string;
  details: string;
  bgColor: string;
  caseId?: string;
  isBlock?: boolean;

  // 13 fields for popup modal
  dos: string;
  startTime: string;
  length: string;
  patientName: string;
  dob: string;
  age: string;
  phone: string;
  procedure: string;
  anesthesiologist: string;
  anesthesiaType: string;
  paymentType?: string;
  notes: string;
}

interface ScheduleFullViewProps {
  cases: PatientCase[];
  onSelectPatient: (patient: PatientCase) => void;
  practiceConfig?: PracticeConfig;
}

const initialAppointments: AppointmentItem[] = [
  // Mon 07/13/26
  {
    dayIndex: 0,
    room: 'OR#1',
    startHour: 8,
    durationHours: 1.5,
    title: 'Martinez, M',
    id: '107793',
    surgeon: 'Dr. Evelyn Vance, MD',
    details: '[Aura Vanguard Pavilion] Bilateral Blepharoplasty',
    bgColor: 'bg-rose-500 text-white border-rose-600',
    caseId: 'case-1',
    dos: '07/13/2026',
    startTime: '08:00 AM',
    length: '1.5 Hours',
    patientName: 'Patricia Martinez',
    dob: '04/12/1972',
    age: '54',
    phone: '(310) 555-0142',
    procedure: 'Bilateral Blepharoplasty & Upper Lid Revision',
    anesthesiologist: 'Raymond Cruz, MD',
    anesthesiaType: 'General Anesthesia',
    notes: 'Fast-track pre-op EKG clearance verified on file. Patient requested post-op cold therapy.'
  },
  {
    dayIndex: 0,
    room: 'OR#1',
    startHour: 9.5,
    durationHours: 1,
    title: 'Toney, M',
    id: '113885',
    surgeon: 'Dr. Evelyn Vance, MD',
    details: '[Aura Vanguard Pavilion] Bilateral revision ptosis',
    bgColor: 'bg-pink-600 text-white border-pink-700',
    caseId: 'case-1',
    dos: '07/13/2026',
    startTime: '09:30 AM',
    length: '1.0 Hour',
    patientName: 'Michael Toney',
    dob: '09/25/1968',
    age: '57',
    phone: '(310) 555-0819',
    procedure: 'Bilateral Revision Ptosis Repair',
    anesthesiologist: 'Raymond Cruz, MD',
    anesthesiaType: 'MAC / IV Sedation',
    notes: 'Mild history of asthma. Albuterol inhaler verified in pre-op suite.'
  },
  {
    dayIndex: 0,
    room: 'OR#1',
    startHour: 12,
    durationHours: 2,
    title: 'Manesh, H',
    id: '112788',
    surgeon: 'Dr. Evelyn Vance, MD',
    details: '[Aura Vanguard Pavilion] Facelift & necklift',
    bgColor: 'bg-pink-600 text-white border-pink-700',
    caseId: 'case-1',
    dos: '07/13/2026',
    startTime: '12:00 PM',
    length: '2.0 Hours',
    patientName: 'Hassan Manesh',
    dob: '11/04/1961',
    age: '64',
    phone: '(424) 555-9012',
    procedure: 'Facelift & Necklift with SMAS Plication',
    anesthesiologist: 'Raymond Cruz, MD',
    anesthesiaType: 'General Anesthesia',
    notes: 'Autologous fat transfer prepared. Pre-op photograph consent verified.'
  },

  // Tue 07/14/26
  {
    dayIndex: 1,
    room: 'OR#1',
    startHour: 8,
    durationHours: 3,
    title: 'Matias, S',
    id: '114115',
    surgeon: 'Dr. Julian Mercer, MD',
    details: '[Aura Vanguard Pavilion] Rhinoplasty 6/16 email, nf',
    bgColor: 'bg-sky-600 text-white border-sky-700',
    caseId: 'case-2',
    dos: '07/14/2026',
    startTime: '08:00 AM',
    length: '3.0 Hours',
    patientName: 'Sofia Matias',
    dob: '06/18/1985',
    age: '41',
    phone: '(310) 555-3341',
    procedure: 'Primary Septorhinoplasty & Cartilage Grafting',
    anesthesiologist: 'Raymond Cruz, MD',
    anesthesiaType: 'General Anesthesia',
    notes: 'Requires 3D pre-op imaging review prior to incision.'
  },
  {
    dayIndex: 1,
    room: 'OR#2',
    startHour: 7,
    durationHours: 4.5,
    title: 'Time slot blocked for:',
    id: 'BLOCK-01',
    surgeon: 'Alistair Sterling, MD',
    details: '[Aura Vanguard Pavilion]',
    bgColor: 'bg-blue-800 text-white border-blue-900',
    isBlock: true,
    dos: '07/14/2026',
    startTime: '07:00 AM',
    length: '4.5 Hours',
    patientName: 'OR Block Reservation',
    dob: 'N/A',
    age: 'N/A',
    phone: 'N/A',
    procedure: 'OR Block Reserved - Dr. Alistair Sterling',
    anesthesiologist: 'Raymond Cruz, MD',
    anesthesiaType: 'Block Reservation',
    notes: 'OR 2 morning block reserved for Dr. Alistair Sterling cases.'
  },
  {
    dayIndex: 1,
    room: 'OR#1',
    startHour: 12,
    durationHours: 3.5,
    title: 'Jamehdashti, S',
    id: '114114',
    surgeon: 'Julian Mercer, MD',
    details: '[Aura Vanguard Pavilion] Rhinoplasty 6/16 email, nf',
    bgColor: 'bg-sky-600 text-white border-sky-700',
    caseId: 'case-2',
    dos: '07/14/2026',
    startTime: '12:00 PM',
    length: '3.5 Hours',
    patientName: 'Shirin Jamehdashti',
    dob: '03/30/1990',
    age: '36',
    phone: '(310) 555-8822',
    procedure: 'Revision Rhinoplasty & Osteotomies',
    anesthesiologist: 'Marcus Vance, MD',
    anesthesiaType: 'General Anesthesia',
    notes: 'Pre-op lab clearance confirmed. Post-op nasal splint in room.'
  },

  // Wed 07/15/26
  {
    dayIndex: 2,
    room: 'OR#1',
    startHour: 8,
    durationHours: 4.5,
    title: 'Rodrigues, L',
    id: '114115',
    surgeon: 'Dr. Julian Mercer, MD',
    details: '[Aura Vanguard Pavilion] Rhino 6/16 email, nf',
    bgColor: 'bg-sky-600 text-white border-sky-700',
    caseId: 'case-2',
    dos: '07/15/2026',
    startTime: '08:00 AM',
    length: '4.5 Hours',
    patientName: 'Livia Rodrigues',
    dob: '07/22/1983',
    age: '43',
    phone: '(310) 555-9104',
    procedure: 'Complex Revision Rhinoplasty & Ear Cartilage Harvest',
    anesthesiologist: 'Raymond Cruz, MD',
    anesthesiaType: 'General Anesthesia',
    notes: 'Ear cartilage harvest consent signed and verified.'
  },
  {
    dayIndex: 2,
    room: 'OR#2',
    startHour: 8,
    durationHours: 1.5,
    title: 'Isralsky, K',
    id: '114071',
    surgeon: 'Dr. Evelyn Vance, MD',
    details: '[Aura Vanguard Pavilion]',
    bgColor: 'bg-pink-600 text-white border-pink-700',
    caseId: 'case-1',
    dos: '07/15/2026',
    startTime: '08:00 AM',
    length: '1.5 Hours',
    patientName: 'Karen Isralsky',
    dob: '05/14/1965',
    age: '61',
    phone: '(424) 555-2018',
    procedure: 'Upper & Lower Eyelid Revision',
    anesthesiologist: 'Raymond Cruz, MD',
    anesthesiaType: 'MAC / IV Sedation',
    notes: 'Patient sensitivity to adhesive paper tape. Use silicone tape.'
  },
  {
    dayIndex: 2,
    room: 'OR#3',
    startHour: 9,
    durationHours: 2.5,
    title: 'Israel, K',
    id: '112954',
    surgeon: 'Dr. Julian Mercer, MD',
    details: '[Aura Vanguard Pavilion] Rhino',
    bgColor: 'bg-emerald-600 text-white border-emerald-700',
    caseId: 'case-3',
    dos: '07/15/2026',
    startTime: '09:00 AM',
    length: '2.5 Hours',
    patientName: 'Kimberly Israel',
    dob: '10/10/1989',
    age: '36',
    phone: '(310) 555-7733',
    procedure: 'Primary Rhinoplasty & Alar Base Reduction',
    anesthesiologist: 'Raymond Cruz, MD',
    anesthesiaType: 'General Anesthesia',
    notes: 'Pre-op photographs completed in clinical suite.'
  },
  {
    dayIndex: 2,
    room: 'OR#1',
    startHour: 12,
    durationHours: 3.5,
    title: 'Bari, I',
    id: '114116',
    surgeon: 'Dr. Julian Mercer, MD',
    details: '[Aura Vanguard Pavilion] Rhino 6/16 email, nf',
    bgColor: 'bg-sky-600 text-white border-sky-700',
    caseId: 'case-2',
    dos: '07/15/2026',
    startTime: '12:00 PM',
    length: '3.5 Hours',
    patientName: 'Imran Bari',
    dob: '01/15/1978',
    age: '48',
    phone: '(310) 555-4040',
    procedure: 'Septorhinoplasty & Endoscopic Sinus Surgery',
    anesthesiologist: 'Raymond Cruz, MD',
    anesthesiaType: 'General Anesthesia',
    notes: 'ENT medical clearance attached to electronic chart.'
  },
  {
    dayIndex: 2,
    room: 'OR#2',
    startHour: 13,
    durationHours: 2.5,
    title: 'Powers, C',
    id: '111769',
    surgeon: 'Dr. Evelyn Vance, MD',
    details: '[Aura Vanguard Pavilion] Bilateral orbital decompression',
    bgColor: 'bg-cyan-600 text-white border-cyan-700',
    caseId: 'case-3',
    dos: '07/15/2026',
    startTime: '01:00 PM',
    length: '2.5 Hours',
    patientName: 'Christopher Powers',
    dob: '12/03/1970',
    age: '55',
    phone: '(310) 555-8120',
    procedure: 'Bilateral Endoscopic Orbital Decompression',
    anesthesiologist: 'Raymond Cruz, MD',
    anesthesiaType: 'General Anesthesia',
    notes: 'Specialty orbital micro-tray requested in OR 2.'
  },
  {
    dayIndex: 2,
    room: 'OR#3',
    startHour: 13,
    durationHours: 2.5,
    title: 'Wang, L',
    id: '114153',
    surgeon: 'Dr. Evelyn Vance, MD',
    details: '[Aura Vanguard Pavilion] Upper Blepharoplasty',
    bgColor: 'bg-emerald-700 text-white border-emerald-800',
    caseId: 'case-3',
    dos: '07/15/2026',
    startTime: '01:00 PM',
    length: '2.5 Hours',
    patientName: 'Lucy Wang',
    dob: '08/29/1982',
    age: '43',
    phone: '(424) 555-6677',
    procedure: 'Bilateral Upper Blepharoplasty & Epicanthoplasty',
    anesthesiologist: 'Raymond Cruz, MD',
    anesthesiaType: 'MAC / IV Sedation',
    notes: 'Translator services scheduled for discharge instructions.'
  },
  {
    dayIndex: 2,
    room: 'OR#2',
    startHour: 15.5,
    durationHours: 1.5,
    title: 'York, J',
    id: '113961',
    surgeon: 'Dr. Evelyn Vance, MD',
    details: '[Aura Vanguard Pavilion]',
    bgColor: 'bg-cyan-600 text-white border-cyan-700',
    caseId: 'case-3',
    dos: '07/15/2026',
    startTime: '03:30 PM',
    length: '1.5 Hours',
    patientName: 'Jennifer York',
    dob: '05/05/1975',
    age: '51',
    phone: '(310) 555-9090',
    procedure: 'Eyelid Retraction Repair & Canthoplasty',
    anesthesiologist: 'Raymond Cruz, MD',
    anesthesiaType: 'MAC / IV Sedation',
    notes: 'Clear for same-day discharge following 60 min PACU observation.'
  },

  // Thu 07/16/26
  {
    dayIndex: 3,
    room: 'OR#1',
    startHour: 8,
    durationHours: 4.5,
    title: 'Khan, A',
    id: '114117',
    surgeon: 'Dr. Julian Mercer, MD',
    details: '[Aura Vanguard Pavilion] Rhino 6/16 email, nf',
    bgColor: 'bg-sky-600 text-white border-sky-700',
    caseId: 'case-2',
    dos: '07/16/2026',
    startTime: '08:00 AM',
    length: '4.5 Hours',
    patientName: 'Ahsan Khan',
    dob: '11/11/1986',
    age: '39',
    phone: '(310) 555-1234',
    procedure: 'Primary Rhinoplasty & Turbinoplasty',
    anesthesiologist: 'Raymond Cruz, MD',
    anesthesiaType: 'General Anesthesia',
    notes: 'Pre-op ECG and chest x-ray cleared.'
  },
  {
    dayIndex: 3,
    room: 'OR#2',
    startHour: 8,
    durationHours: 4.5,
    title: 'Vingsbo, C',
    id: '113477',
    surgeon: 'Dr. Alistair Sterling, MD',
    details: '[Aura Vanguard Pavilion] Abdominal liposuction, flank, removal and replacement bilateral breast implants 3/11 email, nf',
    bgColor: 'bg-amber-600 text-white border-amber-700',
    caseId: 'case-4',
    dos: '07/16/2026',
    startTime: '08:00 AM',
    length: '4.5 Hours',
    patientName: 'Christina Vingsbo',
    dob: '02/14/1979',
    age: '47',
    phone: '(310) 555-7890',
    procedure: 'Abdominal & Flank Liposuction, Removal and Replacement Bilateral Breast Implants',
    anesthesiologist: 'Raymond Cruz, MD',
    anesthesiaType: 'General Anesthesia',
    notes: 'Garment sizing confirmed in pre-op.'
  },

  // Fri 07/17/26
  {
    dayIndex: 4,
    room: 'OR#3',
    startHour: 8,
    durationHours: 2.5,
    title: 'Billauer, F',
    id: '98358',
    surgeon: 'Dr. Alistair Sterling, MD',
    details: '[Aura Vanguard Pavilion]',
    bgColor: 'bg-blue-700 text-white border-blue-800',
    caseId: 'case-2',
    dos: '07/17/2026',
    startTime: '08:00 AM',
    length: '2.5 Hours',
    patientName: 'Frank Billauer',
    dob: '09/09/1963',
    age: '62',
    phone: '(310) 555-4321',
    procedure: 'Gynecomastia Revision & Chest Liposuction',
    anesthesiologist: 'Raymond Cruz, MD',
    anesthesiaType: 'General Anesthesia',
    notes: 'Post-op compression vest in room.'
  },
  {
    dayIndex: 4,
    room: 'OR#1',
    startHour: 8,
    durationHours: 3,
    title: 'Sprong, J',
    id: '113603',
    surgeon: 'Dr. Evelyn Vance, MD',
    details: '[Aura Vanguard Pavilion] Bilateral endoscopic browlift, bilateral upper...',
    bgColor: 'bg-fuchsia-600 text-white border-fuchsia-700',
    caseId: 'case-1',
    dos: '07/17/2026',
    startTime: '08:00 AM',
    length: '3.0 Hours',
    patientName: 'Jesse Sprong',
    dob: '01/20/1967',
    age: '59',
    phone: '(424) 555-5678',
    procedure: 'Bilateral Endoscopic Browlift & Bilateral Upper Blepharoplasty',
    anesthesiologist: 'Raymond Cruz, MD',
    anesthesiaType: 'General Anesthesia',
    notes: 'Endoscopic camera system requested in OR 1.'
  },
  {
    dayIndex: 4,
    room: 'OR#2',
    startHour: 7,
    durationHours: 5,
    title: 'Correll, N',
    id: '114185',
    surgeon: 'Dr. Alistair Sterling, MD',
    details: '[Aura Vanguard Pavilion] Breast revision',
    bgColor: 'bg-blue-800 text-white border-blue-900',
    caseId: 'case-2',
    dos: '07/17/2026',
    startTime: '07:00 AM',
    length: '5.0 Hours',
    patientName: 'Nancy Correll',
    dob: '06/06/1974',
    age: '52',
    phone: '(310) 555-8765',
    procedure: 'Complex Breast Revision & Capsular Contracture Release',
    anesthesiologist: 'Raymond Cruz, MD',
    anesthesiaType: 'General Anesthesia',
    notes: 'Smooth gel implants staged in OR 2.'
  },
  {
    dayIndex: 4,
    room: 'OR#1',
    startHour: 11,
    durationHours: 2,
    title: 'Danek, H',
    id: '114068',
    surgeon: 'Dr. Evelyn Vance, MD',
    details: '[Aura Vanguard Pavilion]',
    bgColor: 'bg-pink-600 text-white border-pink-700',
    caseId: 'case-1',
    dos: '07/17/2026',
    startTime: '11:00 AM',
    length: '2.0 Hours',
    patientName: 'Helen Danek',
    dob: '12/12/1959',
    age: '66',
    phone: '(310) 555-2468',
    procedure: 'Lower Eyelid Blepharoplasty & Fat Repositioning',
    anesthesiologist: 'Raymond Cruz, MD',
    anesthesiaType: 'MAC / IV Sedation',
    notes: 'Pre-op ocular pressure check normal.'
  },

  // Sat 07/18/26
  {
    dayIndex: 5,
    room: 'OR#3',
    startHour: 8,
    durationHours: 5,
    title: 'Time slot blocked for:',
    id: 'BLOCK-02',
    surgeon: 'Dr. Alistair Sterling, MD',
    details: '[Aura Vanguard Pavilion]',
    bgColor: 'bg-fuchsia-400 text-white border-fuchsia-500',
    isBlock: true,
    dos: '07/18/2026',
    startTime: '08:00 AM',
    length: '5.0 Hours',
    patientName: 'OR Block Reservation',
    dob: 'N/A',
    age: 'N/A',
    phone: 'N/A',
    procedure: 'OR Block Reserved - Dr. Alistair Sterling',
    anesthesiologist: 'Assigned on arrival',
    anesthesiaType: 'Block Reservation',
    notes: 'OR 3 Saturday morning block reserved.'
  }
];

export const ScheduleFullView: React.FC<ScheduleFullViewProps> = ({
  cases,
  onSelectPatient,
  practiceConfig,
}) => {
  const [selectedDayIndex, setSelectedDayIndex] = useState<number>(0); // 0 = Monday (Today)
  const [viewMode, setViewMode] = useState<'WK' | 'DAY'>('WK');
  const [selectedSubTab, setSelectedSubTab] = useState('Schedule');
  const [searchTerm, setSearchTerm] = useState('');
  const [isPrintModalOpen, setIsPrintModalOpen] = useState(false);

  // Weekly notes state keyed by the specific schedule week indicated
  const activeWeekKey = 'Week of July 13, 2026';
  const [weeklyNotes, setWeeklyNotes] = useState<{ [week: string]: string }>(() => {
    const saved = localStorage.getItem('schedule_weekly_notes_db');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        // Fallback default
      }
    }
    return {
      'Week of July 13, 2026': '• OR 2 afternoon turnover delayed by 15 mins.\n• Fast-track EKG for Patricia DePoli completed.\n• Special micro-instrument orbital tray reserved for Dr. Vance on Wed (OR 2).\n• Anesthesia coverage confirmed with Dr. Raymond Cruz for Fri afternoon block.'
    };
  });
  const [noteDraft, setNoteDraft] = useState<string>(weeklyNotes[activeWeekKey] || '');
  const [savedNotesTimestamp, setSavedNotesTimestamp] = useState<string | null>(null);

  // Interactive Appointments State
  const [appointmentsList, setAppointmentsList] = useState<AppointmentItem[]>(initialAppointments);
  const [activeAppointmentModal, setActiveAppointmentModal] = useState<AppointmentItem | null>(null);
  const [deleteConfirmAppointment, setDeleteConfirmAppointment] = useState<AppointmentItem | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [draggedAptId, setDraggedAptId] = useState<string | null>(null);
  const [dragOverTarget, setDragOverTarget] = useState<{ dIdx: number; hour: number; room: string } | null>(null);

  // Dynamic Patient Search State in Appointment Modal
  const [patientSearchQuery, setPatientSearchQuery] = useState('');
  const [showPatientSuggestions, setShowPatientSuggestions] = useState(false);

  // Dedicated Schedule Matrix Patient Search & Appointment Dates State
  const [schedulePatientSearchQuery, setSchedulePatientSearchQuery] = useState('');
  const [isScheduleSearchFocused, setIsScheduleSearchFocused] = useState(false);
  const scheduleSearchContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (scheduleSearchContainerRef.current && !scheduleSearchContainerRef.current.contains(event.target as Node)) {
        setIsScheduleSearchFocused(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleSelectAppointmentDate = (aptRecord: PatientAppointmentHistoryRecord) => {
    const targetDayIndex = aptRecord.dayIndex !== undefined ? aptRecord.dayIndex : 0;
    const aptItem: AppointmentItem = {
      id: aptRecord.id,
      dayIndex: targetDayIndex,
      room: aptRecord.room || 'OR #1',
      startHour: aptRecord.startHour || 8,
      durationHours: aptRecord.durationHours || 2,
      title: aptRecord.title || `${aptRecord.patientName}`,
      surgeon: aptRecord.surgeon || 'Dr. Alistair Sterling, MD',
      details: `[Aura Vanguard Pavilion] ${aptRecord.procedure}`,
      bgColor: aptRecord.bgColor || (aptRecord.status === 'Scheduled' ? 'bg-blue-700 text-white border-blue-800' : 'bg-slate-700 text-white border-slate-800'),
      caseId: aptRecord.caseId,
      dos: aptRecord.date,
      startTime: aptRecord.startTime || '08:00 AM',
      length: aptRecord.length || '2.0 Hours',
      patientName: aptRecord.patientName,
      dob: aptRecord.dob,
      age: `${aptRecord.age}`,
      phone: aptRecord.phone,
      procedure: aptRecord.procedure,
      anesthesiologist: aptRecord.anesthesiologist || 'Raymond Cruz, MD',
      anesthesiaType: aptRecord.anesthesiaType || 'General Anesthesia',
      paymentType: aptRecord.paymentType || 'Self-Pay',
      notes: aptRecord.notes || `Appointment record for ${aptRecord.patientName} on ${aptRecord.date}.`
    };

    if (aptRecord.dayIndex !== undefined) {
      setSelectedDayIndex(aptRecord.dayIndex);
    }
    setActiveAppointmentModal(aptItem);
    setIsScheduleSearchFocused(false);
    showToast(`Loaded appointment details for ${aptRecord.patientName} (${aptRecord.date} • ${aptRecord.startTime})`);
  };

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  const dayDosMap: { [key: number]: string } = {
    0: '07/13/2026',
    1: '07/14/2026',
    2: '07/15/2026',
    3: '07/16/2026',
    4: '07/17/2026',
    5: '07/18/2026',
    6: '07/19/2026',
  };

  const formatHourString = (hourNum: number) => {
    const h = Math.floor(hourNum);
    const m = Math.round((hourNum - h) * 60);
    const mStr = m < 10 ? `0${m}` : `${m}`;
    const period = h >= 12 ? 'PM' : 'AM';
    const displayH = h % 12 === 0 ? 12 : h % 12;
    const hStr = displayH < 10 ? `0${displayH}` : `${displayH}`;
    return `${hStr}:${mStr} ${period}`;
  };

  // Schedule starts on MONDAY
  const daysOfWeek = [
    { label: 'Mon, 07/13/26', dayName: 'Monday', date: '07/13/26', isToday: true, fullDateStr: 'Monday, July 13, 2026', dayNum: 13 },
    { label: 'Tue, 07/14/26', dayName: 'Tuesday', date: '07/14/26', isToday: false, fullDateStr: 'Tuesday, July 14, 2026', dayNum: 14 },
    { label: 'Wed, 07/15/26', dayName: 'Wednesday', date: '07/15/26', isToday: false, fullDateStr: 'Wednesday, July 15, 2026', dayNum: 15 },
    { label: 'Thu, 07/16/26', dayName: 'Thursday', date: '07/16/26', isToday: false, fullDateStr: 'Thursday, July 16, 2026', dayNum: 16 },
    { label: 'Fri, 07/17/26', dayName: 'Friday', date: '07/17/26', isToday: false, fullDateStr: 'Friday, July 17, 2026', dayNum: 17 },
    { label: 'Sat, 07/18/26', dayName: 'Saturday', date: '07/18/26', isToday: false, fullDateStr: 'Saturday, July 18, 2026', dayNum: 18 },
    { label: 'Sun, 07/19/26', dayName: 'Sunday', date: '07/19/26', isToday: false, fullDateStr: 'Sunday, July 19, 2026', dayNum: 19 },
  ];

  const currentHeaderDisplay = viewMode === 'DAY' 
    ? daysOfWeek[selectedDayIndex]?.fullDateStr 
    : 'Monday, July 13, 2026 - Sunday, July 19, 2026';

  const rooms = ['OR#1', 'OR#2', 'OR#3'];
  
  // 15-Minute interval slots generation from 6 AM to 10 PM
  const timeSlots: { hourNum: number; displayLabel: string; isHourMark: boolean; minute: number }[] = [];
  for (let h = 6; h <= 21; h++) {
    for (let m = 0; m < 60; m += 15) {
      const hourNum = h + m / 60;
      const period = h >= 12 ? 'PM' : 'AM';
      const displayH = h % 12 === 0 ? 12 : h % 12;
      const mStr = m === 0 ? '00' : `${m}`;
      const displayLabel = m === 0 ? `${displayH}:${mStr} ${period}` : `:${mStr}`;
      timeSlots.push({
        hourNum,
        displayLabel,
        isHourMark: m === 0,
        minute: m,
      });
    }
  }

  const parseTimeToDecimalHour = (timeStr: string): number => {
    if (!timeStr) return 8;
    const match = timeStr.match(/(\d{1,2}):(\d{2})\s*(AM|PM)?/i);
    if (!match) return 8;
    let h = parseInt(match[1], 10);
    const m = parseInt(match[2], 10);
    const period = match[3]?.toUpperCase();
    if (period === 'PM' && h < 12) h += 12;
    if (period === 'AM' && h === 12) h = 0;
    return h + m / 60;
  };

  const parseLengthToHours = (lengthStr: string): number => {
    if (!lengthStr) return 1;
    const numMatch = lengthStr.match(/(\d+(\.\d+)?)/);
    if (!numMatch) return 1;
    const val = parseFloat(numMatch[1]);
    if (lengthStr.toLowerCase().includes('min')) {
      return val / 60;
    }
    return val;
  };

  const handleOpenAppointmentModal = (apt: AppointmentItem) => {
    setPatientSearchQuery(apt.patientName || '');
    setShowPatientSuggestions(false);
    setActiveAppointmentModal({ ...apt });
  };

  const handleSlotClick = (dIdx: number, startHourNum: number, roomName: string) => {
    const targetDayIndex = viewMode === 'DAY' ? selectedDayIndex : dIdx;
    const dosString = dayDosMap[targetDayIndex] || '07/13/2026';
    const startTimeStr = formatHourString(startHourNum);

    const newApt: AppointmentItem = {
      id: `APT-${Math.floor(100000 + Math.random() * 900000)}`,
      dayIndex: targetDayIndex,
      room: roomName,
      startHour: startHourNum,
      durationHours: 1.5,
      title: '',
      surgeon: 'Dr. Alistair Sterling, MD',
      details: '[Aura Vanguard Pavilion] Elective Surgical Procedure',
      bgColor: 'bg-emerald-600 text-white border-emerald-700',
      dos: dosString,
      startTime: startTimeStr,
      length: '1.5 Hours',
      patientName: '',
      dob: '',
      age: '',
      phone: '',
      procedure: 'Elective Surgical Procedure',
      anesthesiologist: 'Raymond Cruz, MD',
      anesthesiaType: 'General Anesthesia',
      paymentType: 'Self-Pay',
      notes: `Scheduled for ${roomName} on ${dosString} at ${startTimeStr}`
    };
    setPatientSearchQuery('');
    setShowPatientSuggestions(false);
    setActiveAppointmentModal(newApt);
  };

  const handleDragStart = (e: React.DragEvent, id: string) => {
    e.dataTransfer.setData('text/plain', id);
    e.dataTransfer.effectAllowed = 'move';
    setDraggedAptId(id);
  };

  const handleDragEnd = () => {
    setDraggedAptId(null);
    setDragOverTarget(null);
  };

  const handleDropOnSlot = (e: React.DragEvent, dIdx: number, startHourNum: number, roomName: string) => {
    const id = e.dataTransfer.getData('text/plain') || draggedAptId;
    if (!id) return;

    const apt = appointmentsList.find((a) => a.id === id);
    if (!apt) return;

    const targetDayIndex = viewMode === 'DAY' ? selectedDayIndex : dIdx;
    const dosString = dayDosMap[targetDayIndex] || '07/13/2026';
    const startTimeStr = formatHourString(startHourNum);

    const updatedApt: AppointmentItem = {
      ...apt,
      dayIndex: targetDayIndex,
      room: roomName,
      startHour: startHourNum,
      dos: dosString,
      startTime: startTimeStr,
    };

    setAppointmentsList((prev) => prev.map((a) => (a.id === id ? updatedApt : a)));
    const dayName = daysOfWeek[targetDayIndex]?.label?.split(',')[0] || `Day ${targetDayIndex}`;
    showToast(`Rescheduled ${apt.patientName || apt.title} to ${roomName} (${dayName} at ${startTimeStr})`);
    setDraggedAptId(null);
    setDragOverTarget(null);
  };

  const handleCreateNewAppointment = () => {
    const targetDay = viewMode === 'DAY' ? selectedDayIndex : 0;
    const newApt: AppointmentItem = {
      id: `APT-${Math.floor(100000 + Math.random() * 900000)}`,
      dayIndex: targetDay, // Monday 07/13/26 or active selected day
      room: 'OR#1',
      startHour: 8,
      durationHours: 1.5,
      title: '',
      surgeon: 'Dr. Alistair Sterling, MD',
      details: '[Aura Vanguard Pavilion] Elective Surgical Procedure',
      bgColor: 'bg-emerald-600 text-white border-emerald-700',
      dos: dayDosMap[targetDay] || '07/13/2026',
      startTime: '08:00 AM',
      length: '1.5 Hours',
      patientName: '',
      dob: '',
      age: '',
      phone: '',
      procedure: 'Elective Surgical Procedure',
      anesthesiologist: 'Raymond Cruz, MD',
      anesthesiaType: 'General Anesthesia',
      paymentType: 'Self-Pay',
      notes: 'New appointment scheduled from schedule toolbar.'
    };
    setPatientSearchQuery('');
    setShowPatientSuggestions(false);
    setActiveAppointmentModal(newApt);
  };

  const handleFormChange = (field: keyof AppointmentItem, value: string) => {
    if (!activeAppointmentModal) return;
    setActiveAppointmentModal((prev) => {
      if (!prev) return null;
      let newDayIndex = prev.dayIndex;
      if (field === 'dos') {
        if (value.includes('13')) newDayIndex = 0;
        else if (value.includes('14')) newDayIndex = 1;
        else if (value.includes('15')) newDayIndex = 2;
        else if (value.includes('16')) newDayIndex = 3;
        else if (value.includes('17')) newDayIndex = 4;
        else if (value.includes('18')) newDayIndex = 5;
        else if (value.includes('19')) newDayIndex = 6;
      }
      let newStartHour = prev.startHour;
      let newDurationHours = prev.durationHours;
      if (field === 'startTime') {
        const parsedH = parseTimeToDecimalHour(value);
        if (parsedH !== null && !isNaN(parsedH)) newStartHour = parsedH;
      }
      if (field === 'length') {
        const parsedDur = parseLengthToHours(value);
        if (parsedDur !== null && !isNaN(parsedDur)) newDurationHours = parsedDur;
      }
      return {
        ...prev,
        [field]: value,
        dayIndex: newDayIndex,
        startHour: newStartHour,
        durationHours: newDurationHours,
        ...(field === 'patientName' ? { title: value } : {}),
        ...(field === 'procedure' ? { details: `[Aura Vanguard Pavilion] ${value}` } : {}),
      };
    });
  };

  const handleSaveAppointment = () => {
    if (!activeAppointmentModal) return;
    const updated = activeAppointmentModal;
    setAppointmentsList((prev) => {
      const exists = prev.some((a) => a.id === updated.id);
      if (exists) {
        return prev.map((a) => (a.id === updated.id ? updated : a));
      } else {
        return [...prev, updated];
      }
    });
    setActiveAppointmentModal(null);
    showToast(`Saved appointment for ${updated.patientName || updated.title}.`);
  };

  const handleDeleteAppointment = () => {
    if (!activeAppointmentModal) return;
    setDeleteConfirmAppointment(activeAppointmentModal);
  };

  const handleConfirmDeleteAppointment = () => {
    if (!deleteConfirmAppointment) return;
    const targetId = deleteConfirmAppointment.id;
    const targetName = deleteConfirmAppointment.patientName;
    setAppointmentsList((prev) => prev.filter((a) => a.id !== targetId));
    setDeleteConfirmAppointment(null);
    setActiveAppointmentModal(null);
    showToast(`Deleted appointment for ${targetName} from schedule.`);
  };

  const handleOpenChartFromModal = () => {
    if (!activeAppointmentModal) return;
    const matchedCase = cases.find(
      (c) => c.id === activeAppointmentModal.caseId || c.name.toLowerCase().includes(activeAppointmentModal.patientName.toLowerCase())
    ) || cases[0];
    
    setActiveAppointmentModal(null);
    if (matchedCase) {
      onSelectPatient(matchedCase);
    }
  };

  // Handler to navigate days or weeks
  const handlePrev = () => {
    if (viewMode === 'DAY') {
      setSelectedDayIndex((prev) => (prev - 1 + 7) % 7);
    } else {
      showToast('Viewing active week: Week of July 13, 2026');
    }
  };

  const handleNext = () => {
    if (viewMode === 'DAY') {
      setSelectedDayIndex((prev) => (prev + 1) % 7);
    } else {
      showToast('Viewing active week: Week of July 13, 2026');
    }
  };

  const handleToday = () => {
    setSelectedDayIndex(0); // Monday July 13
    showToast('Jumped to Monday, July 13, 2026 (Today)');
  };

  // Weekly Notes Save Functionality
  const handleSaveWeeklyNotes = () => {
    const updated = { ...weeklyNotes, [activeWeekKey]: noteDraft };
    setWeeklyNotes(updated);
    localStorage.setItem('schedule_weekly_notes_db', JSON.stringify(updated));
    const now = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    setSavedNotesTimestamp(now);
    showToast(`Notes saved for ${activeWeekKey}`);
  };

  const handleAppendNoteTemplate = (templateText: string) => {
    setNoteDraft((prev) => (prev ? `${prev}\n• ${templateText}` : `• ${templateText}`));
  };

  const monthCalendarDays = Array.from({ length: 31 }, (_, i) => i + 1);

  // Filtered appointments for Day vs Week mode
  const displayedAppointments = viewMode === 'DAY'
    ? appointmentsList.filter((a) => a.dayIndex === selectedDayIndex)
    : appointmentsList;

  return (
    <div className="w-full bg-slate-100 text-slate-800 font-sans text-xs min-h-screen flex flex-col border border-slate-300 shadow-md rounded-xl overflow-hidden relative">
      
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-6 right-6 z-50 bg-[#2b3a4a] text-white text-xs font-semibold px-4 py-3 rounded-xl shadow-2xl border border-slate-700 flex items-center gap-2.5 animate-in slide-in-from-top duration-300">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Date Header Controls & Main Content Area with reduced side padding */}
      <div className="flex-1 p-1.5 sm:p-2.5 flex flex-col gap-2">

        {/* Dynamic Schedule Patient & Appointment Dates Lookup Bar */}
        <div className="bg-white px-3 py-2 rounded-xl border border-slate-200 shadow-2xs">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div ref={scheduleSearchContainerRef} className="relative flex-1 max-w-3xl">
              <div className="relative">
                <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                <input
                  type="text"
                  value={schedulePatientSearchQuery}
                  onChange={(e) => {
                    setSchedulePatientSearchQuery(e.target.value);
                    setIsScheduleSearchFocused(true);
                  }}
                  onFocus={() => setIsScheduleSearchFocused(true)}
                  onKeyDown={(e) => {
                    if (e.key === 'Escape') {
                      setIsScheduleSearchFocused(false);
                    }
                  }}
                  placeholder="Enter first 3 letters of patient last name (e.g. 'Ros', 'Ken', 'Van', 'Bro', 'Mar', 'Hol')..."
                  className="w-full pl-10 pr-9 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-semibold text-slate-900 placeholder:text-slate-400 focus:outline-hidden focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all shadow-2xs"
                  autoComplete="off"
                  id="schedule-patient-dynamic-search-input"
                />
                {schedulePatientSearchQuery && (
                  <button
                    type="button"
                    onClick={() => {
                      setSchedulePatientSearchQuery('');
                      setIsScheduleSearchFocused(false);
                    }}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 p-0.5 cursor-pointer"
                    title="Clear search"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>

              {/* Dynamic Search Results Dropdown */}
              {isScheduleSearchFocused && (
                <>
                  {schedulePatientSearchQuery.trim().length >= 3 ? (() => {
                    const matches = searchPatientsByLastName(schedulePatientSearchQuery, cases, { minChars: 3 });
                    return (
                      <div className="absolute left-0 top-full mt-1.5 w-full bg-white rounded-2xl border border-indigo-300 shadow-2xl z-50 p-3 max-h-96 overflow-y-auto animate-in fade-in zoom-in-95 duration-150">
                        <div className="px-3 py-2 text-[11px] font-bold text-indigo-950 bg-indigo-50/90 rounded-xl flex items-center justify-between mb-2.5 border border-indigo-200">
                          <span className="flex items-center gap-1.5">
                            <Search className="w-3.5 h-3.5 text-indigo-600" />
                            Matching Patients ({matches.length})
                          </span>
                          <span className="text-[10px] text-indigo-700 font-semibold bg-white px-2 py-0.5 rounded-md border border-indigo-200">
                            Click an appointment date to view details
                          </span>
                        </div>

                        {matches.length === 0 ? (
                          <div className="p-4 text-center text-xs text-slate-500">
                            <p className="font-semibold text-slate-700">No patient records found matching "{schedulePatientSearchQuery}".</p>
                            <p className="text-[11px] text-slate-400 mt-1">Please check the spelling of the patient's last name.</p>
                          </div>
                        ) : (
                          <div className="space-y-3">
                            {matches.map((patient) => {
                              const appointmentHistory = getPatientAppointmentHistory(patient, appointmentsList);
                              return (
                                <div
                                  key={patient.id || patient.patientId}
                                  className="p-3 bg-slate-50/90 rounded-xl border border-slate-200 hover:border-indigo-300 transition-all space-y-2.5"
                                >
                                  {/* Patient Header Summary */}
                                  <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-200/90 pb-2">
                                    <div className="flex items-center gap-2.5">
                                      <div className="w-7 h-7 rounded-full bg-indigo-100 text-indigo-900 font-bold text-xs flex items-center justify-center shrink-0 border border-indigo-200">
                                        {patient.name.split(' ').map((n) => n[0]).join('')}
                                      </div>
                                      <div>
                                        <div className="flex items-center gap-2">
                                          <span className="font-bold text-sm text-slate-900">{patient.name}</span>
                                          <span className="text-[10px] text-slate-500 font-medium">MRN: #{patient.patientId}</span>
                                        </div>
                                        <div className="flex items-center gap-3 text-[11px] text-slate-600 font-medium">
                                          <span className="flex items-center gap-1"><Phone className="w-3 h-3 text-indigo-600" />{patient.phone}</span>
                                          <span className="flex items-center gap-1"><CalendarIcon className="w-3 h-3 text-indigo-600" />DOB: {patient.dob}</span>
                                        </div>
                                      </div>
                                    </div>
                                    <span className="text-[10px] font-bold px-2.5 py-1 rounded-lg bg-slate-200 text-slate-700">
                                      Age {patient.age} · {patient.gender || 'Female'}
                                    </span>
                                  </div>

                                  {/* Prior & Scheduled Appointment Dates */}
                                  <div>
                                    <div className="text-[10px] font-bold text-slate-600 uppercase tracking-wider mb-1.5 flex items-center gap-1">
                                      <CalendarIcon className="w-3 h-3 text-indigo-600" />
                                      <span>Appointment Dates & Visit History ({appointmentHistory.length}):</span>
                                    </div>

                                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                                      {appointmentHistory.map((apt) => (
                                        <button
                                          key={apt.id}
                                          type="button"
                                          onClick={() => handleSelectAppointmentDate(apt)}
                                          className={`text-left p-2.5 rounded-xl border transition-all cursor-pointer group flex flex-col justify-between ${
                                            apt.status === 'Scheduled'
                                              ? 'bg-indigo-50/90 hover:bg-indigo-100 border-indigo-200 hover:border-indigo-300 ring-1 ring-indigo-300/40 shadow-2xs'
                                              : 'bg-white hover:bg-slate-100/90 border-slate-200 hover:border-slate-300'
                                          }`}
                                        >
                                          <div className="flex items-center justify-between gap-1 mb-1">
                                            <span className="font-bold text-xs text-indigo-950 flex items-center gap-1.5">
                                              <CalendarIcon className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
                                              {apt.date} ({apt.dayName?.slice(0, 3)})
                                            </span>
                                            <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded-full ${
                                              apt.status === 'Scheduled'
                                                ? 'bg-indigo-600 text-white'
                                                : 'bg-slate-200 text-slate-700'
                                            }`}>
                                              {apt.status === 'Scheduled' ? 'SCHEDULED' : 'PRIOR VISIT'}
                                            </span>
                                          </div>

                                          <div className="text-[11px] text-slate-700 font-semibold truncate group-hover:text-indigo-900">
                                            {apt.procedure || apt.title}
                                          </div>

                                          <div className="flex items-center justify-between text-[10px] text-slate-500 mt-1.5 pt-1.5 border-t border-slate-100">
                                            <span className="flex items-center gap-1 font-medium">
                                              <Clock className="w-3 h-3 text-slate-400" />
                                              {apt.startTime} • {apt.room}
                                            </span>
                                            <span className="font-bold text-indigo-600 group-hover:translate-x-0.5 transition-transform flex items-center gap-0.5">
                                              View Details →
                                            </span>
                                          </div>
                                        </button>
                                      ))}
                                    </div>
                                  </div>
                                </div>
                              );
                            })}
                          </div>
                        )}
                      </div>
                    );
                  })() : schedulePatientSearchQuery.trim().length > 0 ? (
                    <div className="absolute left-0 top-full mt-1.5 w-full bg-white rounded-xl border border-indigo-200 shadow-lg z-50 p-3 text-xs text-slate-600 animate-in fade-in zoom-in-95 duration-100">
                      <div className="flex items-center gap-2 text-indigo-800 font-semibold">
                        <Search className="w-4 h-4 text-indigo-600 shrink-0" />
                        <span>Type at least 3 letters of patient's last name to search schedule</span>
                      </div>
                      <p className="text-[11px] text-slate-400 mt-1 pl-6">
                        Examples: <span className="font-semibold text-slate-700">"Ros"</span> (Rostova), <span className="font-semibold text-slate-700">"Ken"</span> (Kensington), <span className="font-semibold text-slate-700">"Van"</span> (Vance), <span className="font-semibold text-slate-700">"Bro"</span> (Brody), <span className="font-semibold text-slate-700">"Mar"</span> (Martinez)
                      </p>
                    </div>
                  ) : null}
                </>
              )}
            </div>

            {/* Quick Practice Filter Badges */}
            <div className="flex items-center gap-1.5 flex-wrap">
              <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">
                Quick Patients:
              </span>
              {[
                { label: 'Rostova', search: 'Ros' },
                { label: 'Kensington', search: 'Ken' },
                { label: 'Vance', search: 'Van' },
                { label: 'Brody', search: 'Bro' },
                { label: 'Martinez', search: 'Mar' },
                { label: 'Holloway', search: 'Hol' },
              ].map((p) => (
                <button
                  key={p.search}
                  type="button"
                  onClick={() => {
                    setSchedulePatientSearchQuery(p.search);
                    setIsScheduleSearchFocused(true);
                  }}
                  className="px-2 py-1 rounded-lg text-[11px] font-bold bg-slate-100 hover:bg-indigo-50 hover:text-indigo-900 border border-slate-200 transition-colors cursor-pointer text-slate-700"
                >
                  {p.label}
                </button>
              ))}
            </div>
          </div>
        </div>
        
        {/* Calendar Header Control Row (Appointment Books button removed as requested) */}
        <div className="flex flex-wrap items-center justify-between px-1.5 py-1 gap-2 bg-white rounded-lg border border-slate-200 shadow-2xs">
          <div className="flex items-center gap-2">
            <button 
              onClick={handlePrev}
              className="p-1.5 border border-slate-300 rounded-md bg-white hover:bg-slate-100 text-slate-700 shadow-2xs transition-colors cursor-pointer"
              title={viewMode === 'DAY' ? 'Previous Day' : 'Previous Week'}
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button 
              onClick={handleToday}
              className="px-3 py-1.5 bg-[#2b3a4a] hover:bg-[#1e2936] text-white font-bold rounded-md shadow-2xs text-xs transition-colors cursor-pointer tracking-wider uppercase"
            >
              Today
            </button>
            <button 
              onClick={handleNext}
              className="p-1.5 border border-slate-300 rounded-md bg-white hover:bg-slate-100 text-slate-700 shadow-2xs transition-colors cursor-pointer"
              title={viewMode === 'DAY' ? 'Next Day' : 'Next Week'}
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          <div className="flex items-center gap-2">
            <CalendarIcon className="w-4 h-4 text-rose-700" />
            <div className="text-base sm:text-lg font-serif font-bold text-rose-900 tracking-tight">
              {currentHeaderDisplay}
            </div>
            {viewMode === 'DAY' && (
              <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                daysOfWeek[selectedDayIndex]?.isToday ? 'bg-emerald-100 text-emerald-800 border border-emerald-300' : 'bg-slate-100 text-slate-700 border border-slate-300'
              }`}>
                {daysOfWeek[selectedDayIndex]?.isToday ? 'TODAY' : daysOfWeek[selectedDayIndex]?.dayName}
              </span>
            )}
          </div>

          <div className="flex items-center gap-2">
            <button 
              type="button"
              onClick={() => setIsPrintModalOpen(true)}
              className="px-3 py-1.5 bg-[#2b3a4a] text-white rounded-md font-bold text-xs hover:bg-slate-800 transition-colors shadow-2xs flex items-center gap-1.5 cursor-pointer"
              title={viewMode === 'DAY' ? 'Print Day Schedule' : 'Print Week Schedule'}
              id="schedule-toolbar-print-btn"
            >
              <Printer className="w-3.5 h-3.5 text-teal-300" />
              <span>Print {viewMode === 'DAY' ? 'Day' : 'Week'} Schedule</span>
            </button>
            <button
              onClick={handleCreateNewAppointment}
              className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-md font-bold text-xs transition-colors shadow-2xs flex items-center gap-1.5 cursor-pointer border border-emerald-500"
            >
              <Plus className="w-3.5 h-3.5 text-white" />
              <span>Add New Appointment</span>
            </button>

            <div className="h-5 w-px bg-slate-300 mx-1" />

            {/* DAY and WK View Mode Switcher */}
            <div className="flex items-center gap-1 bg-slate-100 p-0.5 rounded-md border border-slate-300">
              <button 
                onClick={() => setViewMode('DAY')}
                className={`px-2.5 py-1 rounded font-bold text-xs flex items-center gap-1 transition-all cursor-pointer ${
                  viewMode === 'DAY' 
                    ? 'bg-[#2b3a4a] text-white shadow-2xs' 
                    : 'text-slate-700 hover:bg-slate-200'
                }`}
                title="View schedule for selected day only"
              >
                <span>DAY</span>
              </button>
              <button 
                onClick={() => setViewMode('WK')}
                className={`px-2.5 py-1 rounded font-bold text-xs flex items-center gap-1 transition-all cursor-pointer ${
                  viewMode === 'WK' 
                    ? 'bg-[#2b3a4a] text-white shadow-2xs' 
                    : 'text-slate-700 hover:bg-slate-200'
                }`}
                title="View 7-day week schedule starting Monday"
              >
                <span>WK</span>
              </button>
            </div>
          </div>
        </div>

        {/* DAY MODE QUICK SELECTOR BAR: Allows fast switching between Mon-Sun when in DAY mode */}
        {viewMode === 'DAY' && (
          <div className="flex items-center gap-1.5 overflow-x-auto py-1 px-2 bg-slate-200/80 rounded-lg border border-slate-300">
            <span className="text-[11px] font-bold text-slate-700 uppercase tracking-wider pr-1 flex items-center gap-1">
              <Clock className="w-3.5 h-3.5 text-slate-600" />
              Select Day:
            </span>
            {daysOfWeek.map((day, idx) => {
              const isSelected = selectedDayIndex === idx;
              const count = appointmentsList.filter((a) => a.dayIndex === idx).length;
              return (
                <button
                  key={day.date}
                  onClick={() => setSelectedDayIndex(idx)}
                  className={`px-3 py-1 rounded-md text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer whitespace-nowrap ${
                    isSelected
                      ? 'bg-[#2b3a4a] text-white shadow-xs font-bold ring-1 ring-slate-800'
                      : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-300/80'
                  }`}
                >
                  <span>{day.label}</span>
                  {day.isToday && (
                    <span className={`text-[9px] px-1.5 py-0.2 rounded-full font-bold ${
                      isSelected ? 'bg-amber-400 text-slate-950' : 'bg-amber-100 text-amber-900'
                    }`}>
                      Today
                    </span>
                  )}
                  <span className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono font-bold ${
                    isSelected ? 'bg-slate-700 text-slate-100' : 'bg-slate-100 text-slate-600'
                  }`}>
                    {count} {count === 1 ? 'case' : 'cases'}
                  </span>
                </button>
              );
            })}
          </div>
        )}

        {/* Main Grid + Sidebar Split with reduced margins */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-2.5 items-start flex-1">
          
          {/* Calendar Matrix View (10 Cols in LG) */}
          <div className="lg:col-span-10 bg-white border border-slate-300 rounded shadow-2xs overflow-x-auto">
            <div className={viewMode === 'DAY' ? 'min-w-[700px] w-full' : 'min-w-[960px] w-full'}>
              
              {/* Quick Interactive Tip Banner */}
              <div className="bg-slate-50 border-b border-slate-200 px-3 py-1.5 flex items-center justify-between text-[11px] text-slate-600 select-none">
                <div className="flex items-center gap-1.5 font-medium">
                  <span className="text-emerald-700 font-bold flex items-center gap-1">
                    <Plus className="w-3 h-3 text-emerald-600" />
                    {viewMode === 'DAY' ? `Schedule for ${daysOfWeek[selectedDayIndex]?.fullDateStr}:` : 'Interactive 7-Day Matrix (Mon - Sun):'}
                  </span>
                  <span>
                    {viewMode === 'DAY' 
                      ? 'Viewing OR#1, OR#2, and OR#3. Click any 15-min slot to schedule a case or drag to reschedule.'
                      : 'Schedule begins Monday. Click any slot or drag appointment blocks to adjust times and rooms.'}
                  </span>
                </div>
                <div className="text-[10px] text-slate-600 font-semibold bg-slate-200/80 px-2.5 py-0.5 rounded-full">
                  {displayedAppointments.length} {displayedAppointments.length === 1 ? 'Case' : 'Cases'} {viewMode === 'DAY' ? 'on this day' : 'this week'}
                </div>
              </div>
              
              {/* ========================================================================= */}
              {/* VIEW MODE: DAY ONLY (10 Cols: Time col-span-1, OR#1 col-span-3, OR#2 col-span-3, OR#3 col-span-3) */}
              {/* ========================================================================= */}
              {viewMode === 'DAY' && (
                <div>
                  {/* Header Rooms Row */}
                  <div className="grid grid-cols-10 border-b border-slate-300 bg-slate-100 text-center text-xs font-bold text-slate-700">
                    <div className="col-span-1 p-2 border-r border-slate-300 bg-slate-200 text-slate-800">
                      Time
                    </div>
                    {rooms.map((roomName, rIdx) => (
                      <div 
                        key={roomName} 
                        className={`col-span-3 border-r border-slate-300 py-2 px-2 ${
                          rIdx === 0 ? 'bg-indigo-50/80 text-indigo-950' : rIdx === 1 ? 'bg-sky-50/80 text-sky-950' : 'bg-emerald-50/80 text-emerald-950'
                        } ${rIdx === 2 ? 'border-r-0' : ''}`}
                      >
                        <div className="text-sm font-bold tracking-tight">{roomName}</div>
                        <div className="text-[10px] text-slate-500 font-normal mt-0.5">
                          {daysOfWeek[selectedDayIndex]?.dayName} Flow & Utilization
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* 15-Minute Rows Grid for DAY Mode */}
                  <div className="relative">
                    {timeSlots.map((slot, sIdx) => {
                      return (
                        <div 
                          key={sIdx} 
                          className={`grid grid-cols-10 min-h-[24px] max-h-[24px] text-[10px] ${
                            slot.isHourMark 
                              ? 'border-t-2 border-slate-300 bg-slate-50/90' 
                              : 'border-t border-slate-100 border-dashed'
                          }`}
                        >
                          {/* Time Label */}
                          <div className={`col-span-1 border-r border-slate-300 pr-2 select-none flex items-center justify-end ${
                            slot.isHourMark ? 'bg-slate-200/90 text-slate-800 font-bold text-[10.5px]' : 'bg-slate-50/70 text-slate-400 font-medium text-[8.5px]'
                          }`}>
                            {slot.displayLabel}
                          </div>

                          {/* 3 Room Columns for the selected day */}
                          {rooms.map((roomName, rIdx) => {
                            const isHoveredTarget = 
                              dragOverTarget?.dIdx === selectedDayIndex && 
                              Math.abs((dragOverTarget?.hour ?? -1) - slot.hourNum) < 0.01 && 
                              dragOverTarget?.room === roomName;

                            return (
                              <div
                                key={roomName}
                                onClick={() => handleSlotClick(selectedDayIndex, slot.hourNum, roomName)}
                                onDragOver={(e) => {
                                  e.preventDefault();
                                  setDragOverTarget({ dIdx: selectedDayIndex, hour: slot.hourNum, room: roomName });
                                }}
                                onDragLeave={() => {
                                  setDragOverTarget(null);
                                }}
                                onDrop={(e) => {
                                  e.preventDefault();
                                  setDragOverTarget(null);
                                  handleDropOnSlot(e, selectedDayIndex, slot.hourNum, roomName);
                                }}
                                className={`col-span-3 border-r border-slate-200/80 transition-all cursor-pointer group flex items-center justify-between px-2 relative ${
                                  rIdx === 2 ? 'border-r-0' : ''
                                } ${
                                  isHoveredTarget 
                                    ? 'bg-emerald-200/90 ring-2 ring-emerald-500 ring-inset z-10' 
                                    : 'hover:bg-sky-50/90 hover:border-sky-300'
                                }`}
                                title={`Click to add appointment or drop here (${daysOfWeek[selectedDayIndex]?.dayName} - ${roomName} at ${slot.displayLabel})`}
                              >
                                <span className="opacity-0 group-hover:opacity-100 text-[8px] font-bold text-sky-700 bg-sky-100 px-1.5 py-0.5 rounded transition-opacity pointer-events-none select-none shadow-2xs">
                                  + Schedule {roomName} ({slot.displayLabel})
                                </span>
                              </div>
                            );
                          })}
                        </div>
                      );
                    })}

                    {/* Scheduled Appointment Overlays for DAY mode (spacious 30% width per room) */}
                    {displayedAppointments.map((apt, aIdx) => {
                      const topPx = (apt.startHour - 6) * 96; // 24px per 15min * 4 = 96px per hour
                      const heightPx = Math.max(apt.durationHours * 96, 26);

                      const roomIndex = apt.room === 'OR#1' ? 0 : apt.room === 'OR#2' ? 1 : 2;
                      const colOffset = 1 + roomIndex * 3;
                      const leftPercent = (colOffset / 10) * 100;
                      const widthPercent = (3 / 10) * 100;

                      const isBeingDragged = draggedAptId === apt.id;

                      return (
                        <div
                          key={apt.id + '-' + aIdx}
                          draggable={true}
                          onDragStart={(e) => handleDragStart(e, apt.id)}
                          onDragEnd={handleDragEnd}
                          onClick={(e) => {
                            e.stopPropagation();
                            handleOpenAppointmentModal(apt);
                          }}
                          style={{
                            top: `${topPx}px`,
                            height: `${heightPx}px`,
                            left: `${leftPercent}%`,
                            width: `${widthPercent}%`,
                          }}
                          className={`absolute p-2 rounded border text-[11px] leading-tight overflow-hidden shadow-md cursor-grab active:cursor-grabbing hover:z-30 hover:scale-[1.01] transition-transform select-none ${apt.bgColor} ${
                            isBeingDragged ? 'opacity-40 border-dashed border-2 ring-2 ring-amber-400 z-40' : ''
                          }`}
                          title={`Drag to reschedule or click to view/edit (${apt.patientName || apt.title})`}
                        >
                          <div className="font-bold flex items-center justify-between text-xs border-b border-white/20 pb-0.5 mb-1">
                            <span className="flex items-center gap-1">
                              <Clock className="w-3 h-3 opacity-80" />
                              <span>{apt.startTime || formatHourString(apt.startHour)} ({apt.length || `${apt.durationHours} hrs`})</span>
                            </span>
                            {!apt.isBlock && <span className="text-[9px] opacity-90 font-mono bg-black/20 px-1.5 py-0.2 rounded">#{apt.id}</span>}
                          </div>
                          
                          <div className="font-black text-sm truncate tracking-tight">{apt.patientName || apt.title}</div>
                          
                          <div className="text-[10px] font-semibold opacity-95 truncate mt-0.5 flex items-center gap-1.5">
                            <span>Surgeon: {apt.surgeon}</span>
                            {apt.anesthesiologist && <span className="opacity-80">• Anesth: {apt.anesthesiologist}</span>}
                          </div>

                          {/* Details & Notes */}
                          {heightPx >= 48 && (
                            <div className="border-t border-white/20 pt-1 mt-1 text-[10px] font-medium leading-normal opacity-95 line-clamp-3">
                              <span className="font-bold">Procedure: </span>{apt.procedure || apt.details}
                              {apt.notes && <div className="text-[9.5px] italic mt-0.5 opacity-90">Note: {apt.notes}</div>}
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* ========================================================================= */}
              {/* VIEW MODE: WEEK (22 Cols: Time col-span-1, 7 Days x 3 Rooms = 21 cols) */}
              {/* Starts on MONDAY */}
              {/* ========================================================================= */}
              {viewMode === 'WK' && (
                <div>
                  {/* Header Days Row Starting on MONDAY */}
                  <div className="grid grid-cols-22 border-b border-slate-300 bg-slate-100 text-center text-[11px] font-bold text-slate-700">
                    <div className="col-span-1 p-2 border-r border-slate-300 bg-slate-200">
                      Time
                    </div>
                    {daysOfWeek.map((day, dIdx) => (
                      <div 
                        key={dIdx} 
                        onClick={() => {
                          setSelectedDayIndex(dIdx);
                          setViewMode('DAY');
                        }}
                        className={`col-span-3 border-r border-slate-300 py-1 px-1 cursor-pointer hover:bg-slate-200 transition-colors ${
                          day.isToday ? 'bg-amber-100/90 text-slate-900 border-b-2 border-b-amber-500' : 'bg-slate-100'
                        }`}
                        title={`Click to focus on ${day.label}`}
                      >
                        <div className="flex items-center justify-center gap-1">
                          <span>{day.label}</span>
                          {day.isToday && <span className="text-[8px] bg-amber-300 text-amber-950 font-bold px-1 rounded-xs">Today</span>}
                        </div>
                        <div className="grid grid-cols-3 text-[10px] text-slate-500 font-semibold border-t border-slate-200 mt-1 pt-0.5">
                          <div>OR#1</div>
                          <div>OR#2</div>
                          <div>OR#3</div>
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* 15-Minute Rows Grid for Week Mode */}
                  <div className="relative">
                    {timeSlots.map((slot, sIdx) => {
                      return (
                        <div 
                          key={sIdx} 
                          className={`grid grid-cols-22 min-h-[22px] max-h-[22px] text-[10px] ${
                            slot.isHourMark 
                              ? 'border-t-2 border-slate-300 bg-slate-50/90' 
                              : 'border-t border-slate-100 border-dashed'
                          }`}
                        >
                          {/* Time Label */}
                          <div className={`col-span-1 border-r border-slate-300 pr-1.5 select-none flex items-center justify-end ${
                            slot.isHourMark ? 'bg-slate-200/90 text-slate-800 font-bold text-[10px]' : 'bg-slate-50/70 text-slate-400 font-medium text-[8px]'
                          }`}>
                            {slot.displayLabel}
                          </div>

                          {/* 7 Day Columns Starting on Monday */}
                          {daysOfWeek.map((day, dIdx) => (
                            <div 
                              key={dIdx} 
                              className={`col-span-3 grid grid-cols-3 border-r border-slate-300 relative ${
                                day.isToday ? (slot.isHourMark ? 'bg-amber-100/25' : 'bg-amber-50/20') : 'bg-white'
                              }`}
                            >
                              {rooms.map((roomName, rIdx) => {
                                const isHoveredTarget = 
                                  dragOverTarget?.dIdx === dIdx && 
                                  Math.abs((dragOverTarget?.hour ?? -1) - slot.hourNum) < 0.01 && 
                                  dragOverTarget?.room === roomName;

                                return (
                                  <div
                                    key={roomName}
                                    onClick={() => handleSlotClick(dIdx, slot.hourNum, roomName)}
                                    onDragOver={(e) => {
                                      e.preventDefault();
                                      setDragOverTarget({ dIdx, hour: slot.hourNum, room: roomName });
                                    }}
                                    onDragLeave={() => {
                                      setDragOverTarget(null);
                                    }}
                                    onDrop={(e) => {
                                      e.preventDefault();
                                      setDragOverTarget(null);
                                      handleDropOnSlot(e, dIdx, slot.hourNum, roomName);
                                    }}
                                    className={`border-r border-slate-100/60 transition-all cursor-pointer group flex items-center justify-center relative ${
                                      rIdx === 2 ? 'border-r-0' : ''
                                    } ${
                                      isHoveredTarget 
                                        ? 'bg-emerald-200/90 ring-2 ring-emerald-500 ring-inset z-10' 
                                        : 'hover:bg-sky-50/80 hover:border-sky-300'
                                    }`}
                                    title={`Click to add appointment or drop here (${day.label.split(',')[0]} - ${roomName} at ${slot.displayLabel})`}
                                  >
                                    <span className="opacity-0 group-hover:opacity-100 text-[7px] font-bold text-sky-700 bg-sky-100 px-0.5 py-0 rounded transition-opacity pointer-events-none select-none shadow-2xs">
                                      +
                                    </span>
                                  </div>
                                );
                              })}
                            </div>
                          ))}
                        </div>
                      );
                    })}

                    {/* Scheduled Appointment Overlays for Week mode */}
                    {displayedAppointments.map((apt, aIdx) => {
                      const topPx = (apt.startHour - 6) * 88;
                      const heightPx = Math.max(apt.durationHours * 88, 20);

                      const roomIndex = apt.room === 'OR#1' ? 0 : apt.room === 'OR#2' ? 1 : 2;
                      const colOffset = 1 + apt.dayIndex * 3 + roomIndex;
                      const leftPercent = (colOffset / 22) * 100;
                      const widthPercent = (1 / 22) * 100;

                      const isBeingDragged = draggedAptId === apt.id;

                      return (
                        <div
                          key={apt.id + '-' + aIdx}
                          draggable={true}
                          onDragStart={(e) => handleDragStart(e, apt.id)}
                          onDragEnd={handleDragEnd}
                          onClick={(e) => {
                            e.stopPropagation();
                            handleOpenAppointmentModal(apt);
                          }}
                          style={{
                            top: `${topPx}px`,
                            height: `${heightPx}px`,
                            left: `${leftPercent}%`,
                            width: `${widthPercent}%`,
                          }}
                          className={`absolute p-1 rounded-xs border text-[9.5px] leading-tight overflow-hidden shadow-2xs cursor-grab active:cursor-grabbing hover:z-30 hover:scale-[1.02] transition-transform select-none ${apt.bgColor} ${
                            isBeingDragged ? 'opacity-40 border-dashed border-2 ring-2 ring-amber-400 z-40' : ''
                          }`}
                          title={`Drag to reschedule or click to view/edit (${apt.patientName || apt.title})`}
                        >
                          <div className="font-bold flex items-center justify-between text-[10px]">
                            <span className="truncate">{apt.startTime || formatHourString(apt.startHour)}</span>
                            {!apt.isBlock && <span className="text-[8px] opacity-90 font-mono">#{apt.id}</span>}
                          </div>
                          <div className="font-black text-[10.5px] truncate mt-0.5">{apt.patientName || apt.title}</div>
                          <div className="text-[9px] font-semibold opacity-95 truncate">{apt.surgeon}</div>

                          {/* Details section if height allows */}
                          {heightPx >= 36 && (
                            <div className="border-t border-white/25 pt-0.5 mt-0.5 text-[8.5px] font-medium leading-tight opacity-90 line-clamp-2">
                              {apt.procedure || apt.details}
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

            </div>
          </div>

          {/* Right Sidebar: Mini Calendar & NEW WEEK-SPECIFIC NOTES SECTION (2 Cols in LG) */}
          <div className="lg:col-span-2 space-y-2.5">
            
            {/* Mini Month Calendar */}
            <div className="bg-white border border-slate-300 rounded p-2.5 shadow-2xs">
              <div className="flex items-center justify-between text-xs font-bold text-slate-800 mb-2 border-b pb-1">
                <button 
                  onClick={() => showToast('Previous month')}
                  className="hover:text-[#2b3a4a] px-1 cursor-pointer font-bold"
                >
                  &lt;
                </button>
                <span className="font-serif">July 2026</span>
                <button 
                  onClick={() => showToast('Next month')}
                  className="hover:text-[#2b3a4a] px-1 cursor-pointer font-bold"
                >
                  &gt;
                </button>
              </div>

              <div className="grid grid-cols-7 text-center text-[10px] font-bold text-slate-500 mb-1">
                <div>Mo</div>
                <div>Tu</div>
                <div>We</div>
                <div>Th</div>
                <div>Fr</div>
                <div>Sa</div>
                <div>Su</div>
              </div>

              <div className="grid grid-cols-7 text-center text-[10px] gap-y-1 text-slate-700 font-medium">
                {/* June trailing days */}
                <div className="text-slate-300">29</div>
                <div className="text-slate-300">30</div>
                {monthCalendarDays.map((day) => {
                  const isToday = day === 13;
                  // Map day 13-19 to our week
                  const isInActiveWeek = day >= 13 && day <= 19;
                  const dayOffset = day - 13;

                  return (
                    <div
                      key={day}
                      onClick={() => {
                        if (isInActiveWeek) {
                          setSelectedDayIndex(dayOffset);
                          setViewMode('DAY');
                          showToast(`Selected ${daysOfWeek[dayOffset]?.fullDateStr}`);
                        } else {
                          showToast(`July ${day}, 2026 selected.`);
                        }
                      }}
                      className={`py-0.5 rounded cursor-pointer transition-colors ${
                        isToday 
                          ? 'bg-[#2b3a4a] text-white font-bold shadow-xs' 
                          : isInActiveWeek 
                          ? 'bg-amber-100/70 text-slate-900 font-semibold hover:bg-amber-200' 
                          : 'hover:bg-slate-200'
                      }`}
                      title={isInActiveWeek ? `Click to view schedule for July ${day}` : `July ${day}, 2026`}
                    >
                      {day}
                    </div>
                  );
                })}
              </div>
            </div>

            {/* NEW WEEK-SPECIFIC NOTES SECTION BENEATH THE CALENDAR */}
            <div className="bg-white border border-slate-300 rounded p-3 shadow-2xs space-y-2">
              <div className="flex items-center justify-between border-b border-slate-200 pb-1.5">
                <div className="flex items-center gap-1.5 font-bold text-xs text-slate-900">
                  <FileText className="w-3.5 h-3.5 text-rose-700" />
                  <span>Week Schedule Notes</span>
                </div>
                <span className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-rose-50 text-rose-800 border border-rose-200">
                  July 13 - 19
                </span>
              </div>

              <div className="text-[10px] text-slate-500 font-medium">
                Notes for <strong className="text-slate-700">{activeWeekKey}</strong> only:
              </div>

              {/* Textarea for typing week notes */}
              <div className="relative">
                <textarea
                  value={noteDraft}
                  onChange={(e) => setNoteDraft(e.target.value)}
                  placeholder="Type clinical staffing notes, OR turnover alerts, surgeon availability, or equipment reservations for this week..."
                  className="w-full h-32 p-2 border border-slate-300 rounded-md text-[11px] font-sans leading-relaxed text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-1 focus:ring-[#2b3a4a] focus:border-[#2b3a4a] bg-slate-50/50 resize-y"
                />
              </div>

              {/* Quick note insertion tags */}
              <div className="flex flex-wrap gap-1">
                <button
                  type="button"
                  onClick={() => handleAppendNoteTemplate('OR 2 turnover delayed 15m.')}
                  className="px-1.5 py-0.5 rounded text-[9.5px] bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200 cursor-pointer"
                >
                  + Turnover
                </button>
                <button
                  type="button"
                  onClick={() => handleAppendNoteTemplate('Special instrument tray staged in OR 1.')}
                  className="px-1.5 py-0.5 rounded text-[9.5px] bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200 cursor-pointer"
                >
                  + Equipment
                </button>
                <button
                  type="button"
                  onClick={() => handleAppendNoteTemplate('Anesthesia clearance verified on chart.')}
                  className="px-1.5 py-0.5 rounded text-[9.5px] bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200 cursor-pointer"
                >
                  + Clearance
                </button>
              </div>

              {/* Save Notes Button & Status */}
              <div className="flex items-center justify-between pt-1 border-t border-slate-100">
                <div className="text-[9.5px] text-slate-500">
                  {savedNotesTimestamp ? (
                    <span className="text-emerald-700 font-bold flex items-center gap-1">
                      <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                      Saved at {savedNotesTimestamp}
                    </span>
                  ) : (
                    <span>Auto-saved to week</span>
                  )}
                </div>

                <button
                  type="button"
                  onClick={handleSaveWeeklyNotes}
                  className="px-3 py-1.5 bg-[#2b3a4a] hover:bg-[#1e2936] text-white font-bold text-xs rounded-md shadow-2xs transition-colors flex items-center gap-1.5 cursor-pointer"
                >
                  <Save className="w-3 h-3 text-emerald-300" />
                  <span>Save Notes</span>
                </button>
              </div>
            </div>

          </div>

        </div>

      </div>

      {/* APPOINTMENT DETAILS POP-UP MODAL */}
      {activeAppointmentModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-200">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-300 w-full max-w-3xl overflow-hidden animate-in zoom-in-95 duration-200 flex flex-col">
            
            {/* Modal Header */}
            <div className="px-6 py-4 bg-slate-800 text-white flex items-center justify-between border-b border-slate-700">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-slate-700 flex items-center justify-center text-slate-200">
                  <CalendarIcon className="w-4 h-4 text-emerald-400" />
                </div>
                <div>
                  <h3 className="font-bold text-sm text-white flex items-center gap-2">
                    <span>Appointment Details</span>
                    {activeAppointmentModal.room && (
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-700 text-emerald-300 border border-slate-600">
                        {activeAppointmentModal.room}
                      </span>
                    )}
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-indigo-900 text-indigo-200 border border-indigo-700 flex items-center gap-1">
                      💳 {activeAppointmentModal.paymentType || 'Self-Pay'}
                    </span>
                  </h3>
                  <p className="text-[11px] text-slate-300 font-medium">
                    Modify appointment fields, update patient notes, or open chart
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setActiveAppointmentModal(null)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-700 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Body: 5 Lines of Fields */}
            <div className="p-6 space-y-4 text-xs font-sans text-slate-800 max-h-[75vh] overflow-y-auto">
              
              {/* LINE 1: Date of Service (DOS), Start Time, Length of Surgery / Appointment, Operating Room */}
              <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
                <div>
                  <label className="block text-[11px] font-bold text-slate-600 uppercase tracking-wider mb-1">
                    Date of Service (DOS)
                  </label>
                  <input
                    type="text"
                    value={activeAppointmentModal.dos || ''}
                    onChange={(e) => handleFormChange('dos', e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs font-semibold text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all shadow-2xs"
                    placeholder="MM/DD/YYYY"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-600 uppercase tracking-wider mb-1">
                    Start Time
                  </label>
                  <input
                    type="text"
                    value={activeAppointmentModal.startTime || ''}
                    onChange={(e) => handleFormChange('startTime', e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs font-semibold text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all shadow-2xs"
                    placeholder="08:00 AM"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-600 uppercase tracking-wider mb-1">
                    Length of Surgery
                  </label>
                  <select
                    value={activeAppointmentModal.length || '1.5 Hours'}
                    onChange={(e) => handleFormChange('length', e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs font-semibold text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all shadow-2xs cursor-pointer"
                  >
                    {!['15 Minutes', '30 Minutes', '45 Minutes', '1.0 Hour', '1.25 Hours', '1.5 Hours', '1.75 Hours', '2.0 Hours', '2.5 Hours', '3.0 Hours', '3.5 Hours', '4.0 Hours', '5.0 Hours', '6.0 Hours'].includes(activeAppointmentModal.length || '') && activeAppointmentModal.length && (
                      <option value={activeAppointmentModal.length}>{activeAppointmentModal.length}</option>
                    )}
                    <option value="15 Minutes">15 Minutes (0.25 Hrs)</option>
                    <option value="30 Minutes">30 Minutes (0.5 Hrs)</option>
                    <option value="45 Minutes">45 Minutes (0.75 Hrs)</option>
                    <option value="1.0 Hour">1.0 Hour (60 Mins)</option>
                    <option value="1.25 Hours">1.25 Hours (75 Mins)</option>
                    <option value="1.5 Hours">1.5 Hours (90 Mins)</option>
                    <option value="1.75 Hours">1.75 Hours (105 Mins)</option>
                    <option value="2.0 Hours">2.0 Hours (120 Mins)</option>
                    <option value="2.5 Hours">2.5 Hours (150 Mins)</option>
                    <option value="3.0 Hours">3.0 Hours (180 Mins)</option>
                    <option value="3.5 Hours">3.5 Hours (210 Mins)</option>
                    <option value="4.0 Hours">4.0 Hours (240 Mins)</option>
                    <option value="5.0 Hours">5.0 Hours (300 Mins)</option>
                    <option value="6.0 Hours">6.0 Hours (360 Mins)</option>
                  </select>
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-600 uppercase tracking-wider mb-1">
                    Operating Room
                  </label>
                  <select
                    value={activeAppointmentModal.room || 'OR#1'}
                    onChange={(e) => handleFormChange('room', e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs font-semibold text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all shadow-2xs cursor-pointer"
                  >
                    <option value="OR#1">OR#1</option>
                    <option value="OR#2">OR#2</option>
                    <option value="OR#3">OR#3</option>
                  </select>
                </div>
              </div>

              {/* LINE 2: Patient's Name, Date of Birth, Age, Phone Number */}
              <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
                <div className="relative">
                  <div className="flex items-center justify-between mb-1">
                    <label className="block text-[11px] font-bold text-slate-600 uppercase tracking-wider">
                      Patient Name
                    </label>
                    <span className="text-[10px] text-indigo-600 font-semibold">
                      Type 3+ letters to search
                    </span>
                  </div>
                  <div className="relative">
                    <input
                      type="text"
                      value={activeAppointmentModal.patientName || ''}
                      onChange={(e) => {
                        const val = e.target.value;
                        handleFormChange('patientName', val);
                        setPatientSearchQuery(val);
                        setShowPatientSuggestions(val.trim().length >= 3);
                      }}
                      onFocus={() => {
                        if ((activeAppointmentModal.patientName || '').trim().length >= 3) {
                          setShowPatientSuggestions(true);
                        }
                      }}
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs font-semibold text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all shadow-2xs"
                      placeholder="Type patient last name..."
                      autoComplete="off"
                    />
                    {activeAppointmentModal.patientName && (
                      <button
                        type="button"
                        onClick={() => {
                          handleFormChange('patientName', '');
                          setPatientSearchQuery('');
                          setShowPatientSuggestions(false);
                        }}
                        className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 p-0.5"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>

                  {/* Dynamic Patient Dropdown */}
                  {showPatientSuggestions && activeAppointmentModal.patientName && activeAppointmentModal.patientName.trim().length >= 3 && (() => {
                    const matches = searchPatientsByLastName(activeAppointmentModal.patientName, cases, { minChars: 3 });
                    return (
                      <div className="absolute left-0 top-full mt-1.5 w-[320px] sm:w-[380px] bg-white rounded-xl border border-indigo-200 shadow-2xl z-50 p-2 max-h-64 overflow-y-auto animate-in fade-in zoom-in-95 duration-150">
                        <div className="px-2.5 py-1.5 text-[10px] font-bold text-indigo-800 bg-indigo-50 rounded-lg flex items-center justify-between mb-1.5 border border-indigo-100">
                          <span>Matching Patients ({matches.length})</span>
                          <span className="text-[9px] text-indigo-600 font-semibold">Select to auto-fill</span>
                        </div>

                        {matches.length === 0 ? (
                          <div className="p-3 text-center text-xs text-slate-500">
                            No matching patient found for "{activeAppointmentModal.patientName}".
                            <p className="text-[10px] text-slate-400 mt-0.5">You can keep typing to create a new patient entry.</p>
                          </div>
                        ) : (
                          <div className="space-y-1">
                            {matches.map((p) => (
                              <button
                                key={p.id || p.patientId}
                                type="button"
                                onClick={() => {
                                  setActiveAppointmentModal((prev) => {
                                    if (!prev) return null;
                                    return {
                                      ...prev,
                                      patientName: p.name,
                                      title: p.name,
                                      dob: p.dob,
                                      age: `${p.age}`,
                                      phone: p.phone,
                                      procedure: p.procedure || prev.procedure,
                                      surgeon: p.surgeon || prev.surgeon,
                                      anesthesiologist: p.anesthesiologist || prev.anesthesiologist,
                                      anesthesiaType: p.anesthesiaType || prev.anesthesiaType,
                                      paymentType: p.paymentType || prev.paymentType || 'Self-Pay',
                                      caseId: p.id
                                    };
                                  });
                                  setPatientSearchQuery(p.name);
                                  setShowPatientSuggestions(false);
                                  showToast(`Auto-filled: ${p.name} • DOB: ${p.dob} • Age: ${p.age} • Phone: ${p.phone}`);
                                }}
                                className="w-full text-left p-2.5 hover:bg-indigo-50/90 rounded-lg transition-all cursor-pointer border border-transparent hover:border-indigo-200 group"
                              >
                                <div className="flex items-center justify-between">
                                  <div className="flex items-center gap-2">
                                    <div className="w-6 h-6 rounded-full bg-indigo-100 text-indigo-800 font-bold text-[10px] flex items-center justify-center">
                                      {p.name.split(' ').map((n) => n[0]).join('')}
                                    </div>
                                    <span className="font-bold text-xs text-slate-900 group-hover:text-indigo-950">
                                      {p.name}
                                    </span>
                                  </div>
                                  <div className="flex items-center gap-1.5">
                                    <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-slate-100 text-slate-700 group-hover:bg-indigo-100 group-hover:text-indigo-900">
                                      Age: {p.age}
                                    </span>
                                  </div>
                                </div>

                                <div className="grid grid-cols-2 gap-2 mt-1.5 text-[11px] text-slate-500 font-medium">
                                  <span className="flex items-center gap-1 text-slate-600">
                                    <Phone className="w-3 h-3 text-indigo-500 shrink-0" />
                                    {p.phone}
                                  </span>
                                  <span className="flex items-center gap-1 text-slate-600 justify-end">
                                    <CalendarIcon className="w-3 h-3 text-indigo-500 shrink-0" />
                                    DOB: {p.dob}
                                  </span>
                                </div>

                                {p.procedure && (
                                  <div className="text-[10px] text-slate-400 truncate mt-1 pt-1 border-t border-slate-100">
                                    {p.procedure}
                                  </div>
                                )}
                              </button>
                            ))}
                          </div>
                        )}
                      </div>
                    );
                  })()}
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-600 uppercase tracking-wider mb-1">
                    Date of Birth (DOB)
                  </label>
                  <input
                    type="text"
                    value={activeAppointmentModal.dob || ''}
                    onChange={(e) => handleFormChange('dob', e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs font-semibold text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all shadow-2xs"
                    placeholder="MM/DD/YYYY"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-600 uppercase tracking-wider mb-1">
                    Age
                  </label>
                  <input
                    type="text"
                    value={activeAppointmentModal.age || ''}
                    onChange={(e) => handleFormChange('age', e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs font-semibold text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all shadow-2xs"
                    placeholder="54"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-600 uppercase tracking-wider mb-1">
                    Phone Number
                  </label>
                  <input
                    type="text"
                    value={activeAppointmentModal.phone || ''}
                    onChange={(e) => handleFormChange('phone', e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs font-semibold text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all shadow-2xs"
                    placeholder="(310) 555-0100"
                  />
                </div>
              </div>

              {/* LINE 3: Full-length text field for Procedure */}
              <div>
                <label className="block text-[11px] font-bold text-slate-600 uppercase tracking-wider mb-1">
                  Procedure
                </label>
                <input
                  type="text"
                  value={activeAppointmentModal.procedure || ''}
                  onChange={(e) => handleFormChange('procedure', e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs font-semibold text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all shadow-2xs"
                  placeholder="Full procedure description"
                />
              </div>

              {/* LINE 4: Surgeon's Name, Anesthesiologist, Type of Anesthesia, Payment Type Drop-down */}
              <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
                <div>
                  <label className="block text-[11px] font-bold text-slate-600 uppercase tracking-wider mb-1">
                    Surgeon's Name
                  </label>
                  <input
                    type="text"
                    value={activeAppointmentModal.surgeon || ''}
                    onChange={(e) => handleFormChange('surgeon', e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs font-semibold text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all shadow-2xs"
                    placeholder="Dr. Surgeon Name"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-600 uppercase tracking-wider mb-1">
                    Anesthesiologist
                  </label>
                  <input
                    type="text"
                    value={activeAppointmentModal.anesthesiologist || ''}
                    onChange={(e) => handleFormChange('anesthesiologist', e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs font-semibold text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all shadow-2xs"
                    placeholder="Dr. Anesthesiologist Name"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-600 uppercase tracking-wider mb-1">
                    Type of Anesthesia
                  </label>
                  <input
                    type="text"
                    value={activeAppointmentModal.anesthesiaType || ''}
                    onChange={(e) => handleFormChange('anesthesiaType', e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs font-semibold text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all shadow-2xs"
                    placeholder="General / MAC / Local"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-indigo-900 uppercase tracking-wider mb-1 flex items-center justify-between">
                    <span>Payment Type</span>
                    <span className="text-[9px] text-indigo-700 bg-indigo-50 px-1 py-0.2 rounded font-extrabold border border-indigo-200">Required</span>
                  </label>
                  <select
                    value={activeAppointmentModal.paymentType || 'Self-Pay'}
                    onChange={(e) => handleFormChange('paymentType', e.target.value)}
                    className="w-full px-3 py-2 bg-indigo-50/50 border border-indigo-300 rounded-lg text-xs font-bold text-indigo-950 focus:outline-hidden focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all shadow-2xs cursor-pointer"
                  >
                    {!PAYMENT_TYPE_OPTIONS.includes((activeAppointmentModal.paymentType || '') as any) && activeAppointmentModal.paymentType && (
                      <option value={activeAppointmentModal.paymentType}>{activeAppointmentModal.paymentType}</option>
                    )}
                    {PAYMENT_TYPE_OPTIONS.map((opt) => (
                      <option key={opt} value={opt}>
                        {opt}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* LINE 5: Full-length box for Notes */}
              <div>
                <label className="block text-[11px] font-bold text-slate-600 uppercase tracking-wider mb-1">
                  Notes
                </label>
                <textarea
                  rows={3}
                  value={activeAppointmentModal.notes || ''}
                  onChange={(e) => handleFormChange('notes', e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs font-medium text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all resize-none shadow-2xs"
                  placeholder="Clinical notes, pre-op instructions, or patient preferences..."
                />
              </div>

              {/* LINE 6: Buttons for deleting, saving, and opening the chart */}
              <div className="pt-4 border-t border-slate-200 flex items-center justify-between gap-3">
                <button
                  type="button"
                  onClick={handleDeleteAppointment}
                  className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs rounded-xl transition-colors flex items-center gap-1.5 shadow-xs cursor-pointer"
                >
                  <Trash2 className="w-4 h-4" />
                  <span>Delete</span>
                </button>

                <div className="flex items-center gap-2.5">
                  <button
                    type="button"
                    onClick={handleOpenChartFromModal}
                    className="px-4 py-2 bg-slate-700 hover:bg-slate-800 text-white font-bold text-xs rounded-xl transition-colors flex items-center gap-1.5 shadow-xs cursor-pointer"
                  >
                    <ExternalLink className="w-4 h-4 text-slate-300" />
                    <span>Open Chart</span>
                  </button>
                  <button
                    type="button"
                    onClick={handleSaveAppointment}
                    className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl transition-colors flex items-center gap-1.5 shadow-md cursor-pointer"
                  >
                    <Save className="w-4 h-4" />
                    <span>Save</span>
                  </button>
                </div>
              </div>

            </div>

          </div>
        </div>
      )}

      {/* Delete Appointment Confirmation Modal */}
      {deleteConfirmAppointment && (
        <div className="fixed inset-0 bg-stone-900/80 backdrop-blur-xs flex items-center justify-center z-[100000] p-4 animate-in fade-in duration-150">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 border border-stone-200 shadow-2xl space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-rose-100 border border-rose-200 text-rose-600 flex items-center justify-center shrink-0">
                <Trash2 className="w-5 h-5 text-rose-600" />
              </div>
              <div>
                <h3 className="text-base font-extrabold text-stone-900">Confirm Appointment Deletion</h3>
                <p className="text-xs text-stone-500 font-medium">Please confirm before deleting this scheduled appointment.</p>
              </div>
            </div>

            <div className="p-3.5 bg-rose-50/80 border border-rose-200/90 rounded-xl space-y-1.5 text-xs text-stone-800">
              <div className="font-extrabold text-rose-950 flex items-center justify-between">
                <span>Patient Name:</span>
                <span className="text-stone-900 font-bold">{deleteConfirmAppointment.patientName}</span>
              </div>
              <div className="flex justify-between text-stone-600">
                <span>Date & Time:</span>
                <span className="font-bold text-stone-800">{deleteConfirmAppointment.dos} at {deleteConfirmAppointment.startTime}</span>
              </div>
              <div className="flex justify-between text-stone-600">
                <span>Room / Location:</span>
                <span className="font-bold text-stone-800">{deleteConfirmAppointment.room}</span>
              </div>
              <div className="flex justify-between text-stone-600">
                <span>Procedure:</span>
                <span className="font-bold text-stone-800">{deleteConfirmAppointment.procedure}</span>
              </div>
              <div className="flex justify-between text-stone-600">
                <span>Payment Type:</span>
                <span className="font-bold text-indigo-900 bg-indigo-50 px-1.5 py-0.5 rounded border border-indigo-200">{deleteConfirmAppointment.paymentType || 'Self-Pay'}</span>
              </div>
            </div>

            <p className="text-xs text-stone-500 leading-relaxed font-medium">
              ⚠️ <strong>Warning:</strong> Deleting this appointment will permanently remove it from the OR schedule and patient itinerary. This action cannot be undone.
            </p>

            <div className="pt-2 flex items-center justify-end gap-2.5">
              <button
                type="button"
                onClick={() => setDeleteConfirmAppointment(null)}
                className="px-4 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 font-bold text-xs rounded-xl border border-stone-200 transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmDeleteAppointment}
                className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs rounded-xl shadow-md transition-colors flex items-center gap-1.5 cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Confirm Delete Appointment</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Footer Copyright */}
      <div className="bg-slate-200 px-4 py-2 border-t border-slate-300 text-[10px] text-slate-600 font-medium flex items-center justify-between">
        <span>2026 © iMARSMED</span>
        <span>Aura Vanguard Surgical & Aesthetic Pavilion • Version 4.8.2</span>
      </div>

      {/* Schedule Print / PDF Modal */}
      <SchedulePrintModal
        isOpen={isPrintModalOpen}
        onClose={() => setIsPrintModalOpen(false)}
        initialViewMode={viewMode}
        selectedDayIndex={selectedDayIndex}
        appointmentsList={appointmentsList}
        daysOfWeek={daysOfWeek}
        rooms={rooms}
        practiceConfig={practiceConfig}
        onShowToast={showToast}
      />

    </div>
  );
};

