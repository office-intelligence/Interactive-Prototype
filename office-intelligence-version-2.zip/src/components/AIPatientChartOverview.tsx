import React, { useState } from 'react';
import { 
  Sparkles, 
  Zap, 
  ShieldCheck, 
  AlertTriangle, 
  CheckCircle2, 
  Stethoscope, 
  FileText, 
  Mic, 
  Activity, 
  DollarSign, 
  Clock, 
  RefreshCw, 
  FileCheck, 
  Check, 
  Lock, 
  ArrowRight,
  ChevronDown,
  Layers,
  Database
} from 'lucide-react';
import { PatientCase } from '../types';

interface AIPatientChartOverviewProps {
  patient: PatientCase;
  onTriggerEKGFastTrack?: (caseId: string) => void;
  onShowToast?: (msg: string) => void;
  onUpdateAiSummary?: (newSummary: string) => void;
}

export const AIPatientChartOverview: React.FC<AIPatientChartOverviewProps> = ({
  patient,
  onTriggerEKGFastTrack,
  onShowToast,
  onUpdateAiSummary
}) => {
  const [activeToolTab, setActiveToolTab] = useState<'ANESTHESIA' | 'DICTATION' | 'SAFETY' | 'FINANCIAL'>('ANESTHESIA');
  const [dictationText, setDictationText] = useState('');
  const [isDictating, setIsDictating] = useState(false);
  const [generatedNote, setGeneratedNote] = useState<string | null>(null);
  const [isGeneratingNote, setIsGeneratingNote] = useState(false);

  const isCleared = patient.readinessLevel === 'CLEARED';

  const handleSimulateDictation = () => {
    setIsDictating(true);
    if (onShowToast) onShowToast('Listening to clinician ambient dictation...');

    setTimeout(() => {
      setDictationText(
        `Patient ${patient.name}, age ${patient.age}, undergoing ${patient.procedure} with Dr. ${patient.surgeon}. Pre-op vitals stable. Airway Mallampati Class I. No cardiac contraindications. Patient consented and cleared for OR.`
      );
      setIsDictating(false);
      if (onShowToast) onShowToast('Captured 22-second voice dictation snippet.');
    }, 1800);
  };

  const handleGenerateAINote = () => {
    setIsGeneratingNote(true);
    if (onShowToast) onShowToast('Nightingale AI structuring H&P / Operative note with ICD-10 codes...');

    setTimeout(() => {
      setIsGeneratingNote(false);
      const note = `PATIENT CLINICAL SUMMARY & PRE-OP EVALUATION
Patient Name: ${patient.name} | DOB/Age: ${patient.age} y.o. | Gender: ${patient.gender}
Surgical Procedure: ${patient.procedure}
Attending Surgeon: ${patient.surgeon} | Room: ${patient.room}

CLINICAL IMPRESSION & RISK MATRIX:
- Airway: Mallampati Class I (Predictive easy intubation)
- Cardiac: EKG ${isCleared ? 'Normal Sinus Rhythm' : 'Pending Clearance'}
- Allergies: ${patient.allergies.join(', ')}
- VTE Caprini Score: 2 (Low Risk - Early ambulation recommended)
- Fasting Status: NPO since 00:00 (12+ hours)

RECOMMENDED EMR ORDERS:
1. Pre-op Cefazolin 2g IV within 60 mins of incision.
2. Sequential Compression Devices (SCDs) bilaterally in pre-op.
3. Discharge instruction bundle for peri-orbital surgical care.

ICD-10 Diagnostic Tag: Z01.818 (Encounter for pre-procedural examination)
CPT Primary Code: 15823 (Blepharoplasty / Reconstructive Peri-Orbital)`;

      setGeneratedNote(note);
      if (onShowToast) onShowToast('✨ Generated structured clinical note ready for 1-click EMR sign-off.');
    }, 2200);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      
      {/* Top Patient AI Header Card */}
      <div className="p-6 bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 rounded-3xl text-white shadow-xl border border-indigo-900/50 flex flex-col md:flex-row md:items-center justify-between gap-6 relative overflow-hidden">
        <div className="space-y-2 max-w-2xl z-10">
          <div className="flex items-center gap-2">
            <span className="px-3 py-1 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-400/30 text-xs font-bold flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
              <span>Nightingale AI Chart Intelligence</span>
            </span>
            <span
              className={`text-xs font-bold px-2.5 py-0.5 rounded-full border ${
                isCleared
                  ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30'
                  : 'bg-amber-500/20 text-amber-300 border-amber-500/30'
              }`}
            >
              {isCleared ? 'READINESS CLEARED' : 'PRE-OP HOLD ACTIVE'}
            </span>
          </div>

          <h2 className="text-2xl font-black text-white tracking-tight">
            {patient.name} ({patient.age}y {patient.gender}) · ID #{patient.patientId}
          </h2>

          <p className="text-xs text-slate-300 font-medium leading-relaxed">
            <span className="font-bold text-amber-300">AI Clinical Summary: </span>
            {patient.aiSummary}
          </p>
        </div>

        <div className="flex flex-col items-end gap-3 z-10 shrink-0">
          <div className="flex items-center gap-3 bg-slate-800/80 p-3 rounded-2xl border border-slate-700">
            <div className="text-right">
              <span className="text-[10px] font-bold text-slate-400 block uppercase">AI Readiness Index</span>
              <span className={`text-2xl font-black ${isCleared ? 'text-emerald-400' : 'text-amber-400'}`}>
                {patient.readinessScore}%
              </span>
            </div>
            <div
              className={`w-12 h-12 rounded-xl flex items-center justify-center font-bold text-sm ${
                isCleared ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-400/30' : 'bg-amber-500/20 text-amber-300 border border-amber-400/30'
              }`}
            >
              <ShieldCheck className="w-6 h-6" />
            </div>
          </div>

          {!isCleared && onTriggerEKGFastTrack && (
            <button
              onClick={() => onTriggerEKGFastTrack(patient.id)}
              className="px-4 py-2 bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-xs rounded-xl shadow-md transition-all flex items-center gap-1.5 cursor-pointer hover:scale-102"
            >
              <Zap className="w-4 h-4 fill-slate-950" />
              <span>Fast-Track Clear EKG Report</span>
            </button>
          )}
        </div>
      </div>

      {/* AI Tool Sub-Tabs Navigation */}
      <div className="flex flex-wrap items-center gap-2 border-b border-stone-200 pb-2">
        <button
          onClick={() => setActiveToolTab('ANESTHESIA')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer ${
            activeToolTab === 'ANESTHESIA'
              ? 'bg-indigo-600 text-white shadow-xs'
              : 'bg-white text-stone-600 hover:bg-stone-100 border border-stone-200'
          }`}
        >
          <Stethoscope className="w-4 h-4" />
          <span>Anesthesia Risk Screening</span>
        </button>

        <button
          onClick={() => setActiveToolTab('DICTATION')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer ${
            activeToolTab === 'DICTATION'
              ? 'bg-indigo-600 text-white shadow-xs'
              : 'bg-white text-stone-600 hover:bg-stone-100 border border-stone-200'
          }`}
        >
          <Mic className="w-4 h-4 text-amber-300" />
          <span>Ambient Voice Scribe & Note Builder</span>
        </button>

        <button
          onClick={() => setActiveToolTab('SAFETY')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer ${
            activeToolTab === 'SAFETY'
              ? 'bg-indigo-600 text-white shadow-xs'
              : 'bg-white text-stone-600 hover:bg-stone-100 border border-stone-200'
          }`}
        >
          <ShieldCheck className="w-4 h-4" />
          <span>Pre-Op Safety Shield</span>
        </button>

        <button
          onClick={() => setActiveToolTab('FINANCIAL')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer ${
            activeToolTab === 'FINANCIAL'
              ? 'bg-indigo-600 text-white shadow-xs'
              : 'bg-white text-stone-600 hover:bg-stone-100 border border-stone-200'
          }`}
        >
          <DollarSign className="w-4 h-4" />
          <span>Financial & Prior Auth Check</span>
        </button>
      </div>

      {/* TOOL 1: ANESTHESIA RISK SCREENING */}
      {activeToolTab === 'ANESTHESIA' && (
        <div className="bg-white rounded-3xl p-6 border border-stone-200/90 shadow-2xs space-y-5">
          <div className="flex items-center justify-between border-b border-stone-100 pb-3">
            <div>
              <h3 className="text-sm font-bold text-stone-900 flex items-center gap-2">
                <Stethoscope className="w-4 h-4 text-indigo-600" />
                <span>Automated Pre-Op Anesthesia Risk Profile</span>
              </h3>
              <p className="text-xs text-stone-500">Cross-analyzed with AORN and ASA physical status guidelines</p>
            </div>
            <span className="px-2.5 py-1 bg-emerald-50 text-emerald-700 font-bold text-xs rounded-full border border-emerald-200">
              ASA Class II (Low Complexity)
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="p-4 bg-stone-50 rounded-2xl border border-stone-200/80 space-y-1">
              <span className="text-[11px] font-semibold text-stone-500 block">Airway Assessment</span>
              <span className="text-sm font-extrabold text-stone-900 block">Mallampati Class I</span>
              <span className="text-[10px] text-emerald-700 font-bold block">✓ Full uvula visibility</span>
            </div>

            <div className="p-4 bg-stone-50 rounded-2xl border border-stone-200/80 space-y-1">
              <span className="text-[11px] font-semibold text-stone-500 block">VTE Prophylaxis</span>
              <span className="text-sm font-extrabold text-stone-900 block">Caprini Score: 2</span>
              <span className="text-[10px] text-indigo-700 font-bold block">✓ Early ambulation order</span>
            </div>

            <div className="p-4 bg-stone-50 rounded-2xl border border-stone-200/80 space-y-1">
              <span className="text-[11px] font-semibold text-stone-500 block">Allergy Cross-Check</span>
              <span className="text-sm font-extrabold text-stone-900 block">
                {patient.allergies.join(', ') || 'NKDA'}
              </span>
              <span className="text-[10px] text-emerald-700 font-bold block">✓ Ancef & Propofol safe</span>
            </div>

            <div className="p-4 bg-stone-50 rounded-2xl border border-stone-200/80 space-y-1">
              <span className="text-[11px] font-semibold text-stone-500 block">Cardiac Clearance</span>
              <span className="text-sm font-extrabold text-stone-900 block">
                {isCleared ? 'Cleared (Normal Sinus)' : 'Pending EKG Fax'}
              </span>
              <span className={`text-[10px] font-bold block ${isCleared ? 'text-emerald-700' : 'text-amber-600'}`}>
                {isCleared ? '✓ QTc 418ms normal' : '⚠ Action required'}
              </span>
            </div>
          </div>
        </div>
      )}

      {/* TOOL 2: AMBIENT VOICE SCRIBE */}
      {activeToolTab === 'DICTATION' && (
        <div className="bg-white rounded-3xl p-6 border border-stone-200/90 shadow-2xs space-y-5">
          <div className="flex items-center justify-between border-b border-stone-100 pb-3">
            <div>
              <h3 className="text-sm font-bold text-stone-900 flex items-center gap-2">
                <Mic className="w-4 h-4 text-amber-500" />
                <span>Ambient Clinical Voice Dictation & Note Builder</span>
              </h3>
              <p className="text-xs text-stone-500">Record spoken notes and auto-format into structured EMR documentation</p>
            </div>
          </div>

          <div className="space-y-4">
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
              <button
                onClick={handleSimulateDictation}
                disabled={isDictating}
                className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-xl shadow-xs transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <Mic className={`w-4 h-4 ${isDictating ? 'animate-pulse text-amber-300' : ''}`} />
                <span>{isDictating ? 'Listening...' : 'Simulate 20-Sec Dictation'}</span>
              </button>

              <button
                onClick={handleGenerateAINote}
                disabled={isGeneratingNote || !dictationText}
                className={`px-4 py-2.5 font-bold text-xs rounded-xl transition-all flex items-center justify-center gap-2 cursor-pointer ${
                  dictationText
                    ? 'bg-slate-900 hover:bg-slate-800 text-white shadow-xs'
                    : 'bg-stone-200 text-stone-400 cursor-not-allowed'
                }`}
              >
                <Sparkles className="w-4 h-4 text-amber-300" />
                <span>Generate Structured Note</span>
              </button>
            </div>

            {dictationText && (
              <div className="p-4 bg-stone-50 rounded-2xl border border-stone-200/80 space-y-1">
                <span className="text-[11px] font-bold text-stone-500 uppercase block">Captured Audio Transcript</span>
                <p className="text-xs text-stone-800 font-mono leading-relaxed">{dictationText}</p>
              </div>
            )}

            {generatedNote && (
              <div className="p-4 bg-slate-900 text-slate-100 rounded-2xl border border-slate-800 space-y-2">
                <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                  <span className="text-xs font-bold text-indigo-300 flex items-center gap-1.5">
                    <FileCheck className="w-4 h-4 text-emerald-400" />
                    <span>Nightingale AI Generated Note (H&P)</span>
                  </span>
                  <span className="text-[10px] bg-emerald-950 text-emerald-300 border border-emerald-800 px-2 py-0.5 rounded font-bold">
                    Ready for Sign-Off
                  </span>
                </div>
                <pre className="text-xs font-mono whitespace-pre-wrap text-slate-300 leading-relaxed overflow-x-auto">
                  {generatedNote}
                </pre>
              </div>
            )}
          </div>
        </div>
      )}

      {/* TOOL 3: PRE-OP SAFETY SHIELD */}
      {activeToolTab === 'SAFETY' && (
        <div className="bg-white rounded-3xl p-6 border border-stone-200/90 shadow-2xs space-y-4">
          <h3 className="text-sm font-bold text-stone-900 flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            <span>Pre-Operative Safety & Infection Control Checklist</span>
          </h3>

          <div className="space-y-2">
            {patient.actionItems.map((action) => (
              <div
                key={action.id}
                className={`p-3 rounded-xl border text-xs flex items-center justify-between gap-3 ${
                  action.done ? 'bg-emerald-50/60 border-emerald-200 text-emerald-900' : 'bg-stone-50 border-stone-200 text-stone-800'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <div
                    className={`w-5 h-5 rounded-md flex items-center justify-center text-xs ${
                      action.done ? 'bg-emerald-600 text-white' : 'bg-stone-200 text-stone-500'
                    }`}
                  >
                    {action.done && <Check className="w-3.5 h-3.5" />}
                  </div>
                  <span className="font-semibold">{action.text}</span>
                </div>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-stone-200 text-stone-700">
                  {action.type}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TOOL 4: FINANCIAL & PRIOR AUTH */}
      {activeToolTab === 'FINANCIAL' && (
        <div className="bg-white rounded-3xl p-6 border border-stone-200/90 shadow-2xs space-y-4">
          <h3 className="text-sm font-bold text-stone-900 flex items-center gap-2">
            <DollarSign className="w-4 h-4 text-indigo-600" />
            <span>AI Revenue Cycle & Payer Authorization Verification</span>
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="p-4 bg-stone-50 rounded-2xl border border-stone-200/80 space-y-1">
              <span className="text-[11px] font-semibold text-stone-500 block">Payer Status</span>
              <span className="text-sm font-extrabold text-stone-900 block">Blue Shield PPO</span>
              <span className="text-[10px] font-bold text-emerald-700 block">✓ Eligibility Verified</span>
            </div>

            <div className="p-4 bg-stone-50 rounded-2xl border border-stone-200/80 space-y-1">
              <span className="text-[11px] font-semibold text-stone-500 block">Prior Authorization</span>
              <span className="text-sm font-extrabold text-emerald-700 block">Auth #AUTH-99201</span>
              <span className="text-[10px] font-bold text-stone-500 block">CPT 15823 Approved</span>
            </div>

            <div className="p-4 bg-stone-50 rounded-2xl border border-stone-200/80 space-y-1">
              <span className="text-[11px] font-semibold text-stone-500 block">Estimated Copay / Pre-Pay</span>
              <span className="text-sm font-extrabold text-stone-900 block">$500.00</span>
              <span className="text-[10px] font-bold text-emerald-700 block">✓ Paid in Pre-Op</span>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
