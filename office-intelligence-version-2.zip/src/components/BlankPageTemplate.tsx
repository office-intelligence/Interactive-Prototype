import React from 'react';
import { Layout, Plus, FileCode, Sparkles } from 'lucide-react';

interface BlankPageTemplateProps {
  title?: string;
  subtitle?: string;
}

export const BlankPageTemplate: React.FC<BlankPageTemplateProps> = ({
  title = 'Blank Page Template',
  subtitle = 'This clean workspace container is ready to host future modules, widgets, or customized workflow views.',
}) => {
  return (
    <div className="w-full space-y-6 animate-in fade-in duration-300">
      {/* Module Title Banner */}
      <div className="bg-white p-6 rounded-2xl border border-stone-200/90 shadow-2xs flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-stone-900 font-bold text-lg">
            <div className="p-2 rounded-xl bg-slate-900 text-white">
              <Layout className="w-5 h-5" />
            </div>
            <h2>{title}</h2>
          </div>
          <p className="text-xs text-stone-500 mt-1">{subtitle}</p>
        </div>

        <div className="flex items-center gap-2.5">
          <button 
            onClick={() => alert('New widget placeholder action clicked!')}
            className="px-3.5 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-50 text-xs font-semibold flex items-center gap-1.5 transition-colors shadow-2xs"
          >
            <Plus className="w-4 h-4" />
            <span>Add Module / Widget</span>
          </button>
        </div>
      </div>

      {/* Blank Workspace Content Cards in 2/3 and 1/3 Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Column: 2/3 of page (8 cols) */}
        <div className="lg:col-span-8 space-y-6">
          <div className="bg-white/80 border-2 border-dashed border-stone-300 rounded-2xl p-12 text-center min-h-[420px] flex flex-col items-center justify-center space-y-4">
            <div className="w-14 h-14 rounded-2xl bg-stone-100 text-slate-900 flex items-center justify-center border border-stone-200 shadow-2xs">
              <FileCode className="w-7 h-7 text-slate-800" />
            </div>
            
            <div className="max-w-md space-y-1">
              <h3 className="text-sm font-bold text-stone-900">Primary Workspace Canvas (2/3)</h3>
              <p className="text-xs text-stone-500 leading-relaxed">
                Main body content is intentionally blank. Connect your custom EHR APIs, forms, data tables, or reporting components here.
              </p>
            </div>

            <div className="pt-2 flex flex-wrap items-center justify-center gap-2">
              <span className="px-3 py-1 rounded-full bg-slate-100 text-slate-800 text-[11px] font-semibold border border-slate-300">
                Navy Accent Theme
              </span>
              <span className="px-3 py-1 rounded-full bg-stone-100 text-stone-700 text-[11px] font-semibold border border-stone-200">
                2/3 Width Column
              </span>
            </div>
          </div>
        </div>

        {/* Right Column: 1/3 of page (4 cols) */}
        <div className="lg:col-span-4 space-y-6">
          <div className="bg-white/80 border-2 border-dashed border-stone-300 rounded-2xl p-8 text-center min-h-[420px] flex flex-col items-center justify-center space-y-4">
            <div className="w-12 h-12 rounded-2xl bg-stone-100 text-slate-900 flex items-center justify-center border border-stone-200 shadow-2xs">
              <Sparkles className="w-6 h-6 text-slate-800" />
            </div>
            
            <div className="space-y-1">
              <h3 className="text-sm font-bold text-stone-900">Sidebar Panel (1/3)</h3>
              <p className="text-xs text-stone-500 leading-relaxed">
                Secondary column container ready for quick actions, auxiliary stats, AI briefs, or task lists.
              </p>
            </div>

            <div className="pt-2 flex flex-wrap items-center justify-center gap-2">
              <span className="px-3 py-1 rounded-full bg-stone-100 text-stone-700 text-[11px] font-semibold border border-stone-200">
                1/3 Width Column
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
