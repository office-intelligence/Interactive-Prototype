import React, { useState, useEffect } from 'react';
import {
  MessageSquare,
  Search,
  CheckCircle2,
  Clock,
  User,
  ArrowRight,
  Send,
  Sparkles,
  AlertTriangle,
  FileText,
  Phone,
  Check,
  Stethoscope,
  Building2,
  ChevronRight,
  Eye,
  EyeOff,
  Plus,
  RefreshCw,
  Zap,
  Layers,
  Inbox,
  Filter,
  ShieldCheck,
  Trash2,
  Paperclip,
  Calendar,
  ExternalLink,
  MessageCircle,
  Activity,
  AlertCircle
} from 'lucide-react';
import { PortalMessage } from '../data/portalData';
import {
  getAllPortalMessages,
  getMessagesForPatient,
  markMessageReadStatus,
  sendProviderReply,
  subscribeToMessageUpdates,
  getUnreadCount,
  deletePortalMessage,
  normalizePatientId
} from '../utils/portalMessageStore';
import { PatientCase } from '../types';

interface MessagesPageProps {
  cases?: PatientCase[];
  onOpenPatientChart?: (patientId: string, sectionKey?: string) => void;
  onShowToast?: (msg: string) => void;
  onNavigateTab?: (tab: string) => void;
}

export const MessagesPage: React.FC<MessagesPageProps> = ({
  cases = [],
  onOpenPatientChart,
  onShowToast,
  onNavigateTab
}) => {
  const [messages, setMessages] = useState<PortalMessage[]>(() => getAllPortalMessages());
  const [selectedTab, setSelectedTab] = useState<'ALL' | 'UNREAD' | 'CLINICAL' | 'REFILL' | 'SCHEDULING' | 'BILLING'>('ALL');
  const [selectedProviderFilter, setSelectedProviderFilter] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [activeMessageId, setActiveMessageId] = useState<string | null>(null);

  // Quick Reply & Active Composer State
  const [replyText, setReplyText] = useState<string>('');
  const [selectedStaffAuthor, setSelectedStaffAuthor] = useState<string>('Dr. Alistair Sterling, MD');
  const [selectedStaffRole, setSelectedStaffRole] = useState<string>('Attending Surgeon & Medical Director');
  const [sendSmsNotification, setSendSmsNotification] = useState<boolean>(true);
  const [selectedAttachment, setSelectedAttachment] = useState<{ name: string; size: string } | null>(null);
  const [isGeneratingAiDraft, setIsGeneratingAiDraft] = useState<boolean>(false);
  const [aiDraftSummary, setAiDraftSummary] = useState<string | null>(null);

  // Subscribe to updates across app
  useEffect(() => {
    const refresh = () => {
      const all = getAllPortalMessages();
      setMessages(all);
    };
    refresh();
    const unsubscribe = subscribeToMessageUpdates(refresh);
    return () => unsubscribe();
  }, []);

  // Filter messages (patient inbound primarily for triage, plus all conversation threads)
  const patientInboundMessages = messages.filter((m) => m.sender === 'patient');
  const unreadMessages = patientInboundMessages.filter((m) => !m.read);

  const filteredMessages = patientInboundMessages.filter((m) => {
    // Tab filtering
    if (selectedTab === 'UNREAD' && m.read) return false;
    if (selectedTab === 'CLINICAL' && m.category !== 'Clinical Question') return false;
    if (selectedTab === 'REFILL' && m.category !== 'Prescription Refill') return false;
    if (selectedTab === 'SCHEDULING' && m.category !== 'Scheduling') return false;
    if (selectedTab === 'BILLING' && m.category !== 'Billing') return false;

    // Provider filtering
    if (selectedProviderFilter !== 'ALL') {
      if (selectedProviderFilter === 'sterling' && m.providerId !== 'dr-sterling') return false;
      if (selectedProviderFilter === 'mercer' && m.providerId !== 'dr-mercer') return false;
      if (selectedProviderFilter === 'cruz' && m.providerId !== 'dr-cruz') return false;
      if (selectedProviderFilter === 'chen' && m.providerId !== 'dr-chen') return false;
    }

    // Search query
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchName = m.senderName.toLowerCase().includes(q);
      const matchContent = m.content.toLowerCase().includes(q);
      const matchCategory = m.category?.toLowerCase().includes(q);
      const matchPatientId = m.patientId.includes(q);
      if (!matchName && !matchContent && !matchCategory && !matchPatientId) return false;
    }

    return true;
  });

  // Auto-select first message if none selected or if active one no longer exists
  useEffect(() => {
    if (filteredMessages.length > 0 && (!activeMessageId || !filteredMessages.some((m) => m.id === activeMessageId))) {
      setActiveMessageId(filteredMessages[0].id);
    }
  }, [filteredMessages, activeMessageId]);

  const activeMessage = filteredMessages.find((m) => m.id === activeMessageId) || filteredMessages[0] || null;

  // Get full thread for active message's patient
  const activeThread = activeMessage ? getMessagesForPatient(activeMessage.patientId) : [];

  // Associated case data if found
  const associatedCase = activeMessage
    ? cases.find(
        (c) =>
          normalizePatientId(c.id) === normalizePatientId(activeMessage.patientId) ||
          normalizePatientId(c.patientId) === normalizePatientId(activeMessage.patientId)
      )
    : null;

  const handleToggleRead = (msg: PortalMessage, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    markMessageReadStatus(msg.patientId, msg.id, !msg.read);
    setMessages(getAllPortalMessages());
  };

  const handleMarkAllRead = () => {
    unreadMessages.forEach((m) => {
      markMessageReadStatus(m.patientId, m.id, true);
    });
    setMessages(getAllPortalMessages());
    if (onShowToast) onShowToast('All inbound portal messages marked as triaged.');
  };

  const handleOpenChart = (patientId: string, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    if (onOpenPatientChart) {
      onOpenPatientChart(patientId, 'portalMessages');
    }
  };

  const handleSendReply = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeMessage || !replyText.trim()) return;

    sendProviderReply(activeMessage.patientId, {
      senderName: selectedStaffAuthor,
      senderTitle: selectedStaffRole,
      category: activeMessage.category,
      content: replyText.trim(),
      attachment: selectedAttachment || undefined
    });

    // Mark active message read if unread
    if (!activeMessage.read) {
      markMessageReadStatus(activeMessage.patientId, activeMessage.id, true);
    }

    const patientName = activeMessage.senderName;
    setReplyText('');
    setSelectedAttachment(null);
    setAiDraftSummary(null);
    setMessages(getAllPortalMessages());

    if (onShowToast) {
      onShowToast(`Response successfully transmitted to ${patientName}'s MyHealth portal inbox.`);
    }
  };

  // Quick Clinical Templates
  const clinicalTemplates = [
    {
      title: 'Pre-Op Fasting & Morning Meds',
      category: 'Clinical Question' as const,
      text: `Hello, you may take approved morning cardiovascular/blood pressure medications with a single small sip of water at 5:30 AM. Strictly avoid all other liquids, coffee, and solid foods from midnight onward. Please arrive at the ASC on time.`
    },
    {
      title: 'Prescription Transmitted to Pharmacy',
      category: 'Prescription Refill' as const,
      text: `Hi, your surgical prescriptions (including post-op analgesia, anti-emetic prophylaxis, and surgical antibiotic) have been electronically transmitted to your pharmacy on file. They are verified and ready for pickup prior to surgery.`
    },
    {
      title: '12-Lead EKG & Clearance Verified',
      category: 'Clinical Question' as const,
      text: `Good day, we have received and reviewed your 12-lead EKG report from cardiology. The rhythm interpretation has been signed off by Dr. Sterling and your surgical clearance is 100% complete.`
    },
    {
      title: 'Post-Op Follow-Up Reminder',
      category: 'Scheduling' as const,
      text: `Hello, your post-operative dressing evaluation and follow-up appointment is confirmed. Please wear comfortable, loose-fitting clothing with front-button closures and bring your support garment.`
    },
    {
      title: 'Billing & Account Cleared',
      category: 'Billing' as const,
      text: `Thank you for your inquiry. Your surgical facility and anesthesia pre-authorizations have been processed, and your current patient balance is $0.00. Detailed receipts are available in your portal billing documents.`
    }
  ];

  const handleGenerateAiDraft = () => {
    if (!activeMessage) return;
    setIsGeneratingAiDraft(true);

    setTimeout(() => {
      setIsGeneratingAiDraft(false);
      const firstName = activeMessage.senderName.split(' ')[0];
      const contentLower = activeMessage.content.toLowerCase();

      if (
        activeMessage.category === 'Prescription Refill' ||
        contentLower.includes('prescription') ||
        contentLower.includes('walgreens') ||
        contentLower.includes('medication') ||
        contentLower.includes('refill')
      ) {
        setReplyText(
          `Hi ${firstName}, Dr. Sterling's clinical team has confirmed your surgical prescriptions (Celebrex 200mg and Zofran 4mg) were electronically transmitted to your pharmacy on Wilshire Blvd. They are verified and ready for pickup prior to surgery.`
        );
        setAiDraftSummary(`Generated pharmacy verification reply for ${activeMessage.senderName}.`);
      } else if (contentLower.includes('ekg') || contentLower.includes('cardiology')) {
        setReplyText(
          `Dear ${firstName}, we have verified receipt of your 12-lead EKG fax directly from Pacific Coast Cardiology. The rhythm report has been reviewed and cleared by Dr. Sterling. Your surgical clearance is now complete!`
        );
        setAiDraftSummary(`Generated clearance confirmation addressing external EKG fax.`);
      } else if (contentLower.includes('water') || contentLower.includes('fasting') || contentLower.includes('morning')) {
        setReplyText(
          `Hi ${firstName}, you may take your morning blood pressure medication at 5:30 AM with a small sip of water. Maintain strict fasting from midnight onward otherwise. Let us know if you have any questions before arrival.`
        );
        setAiDraftSummary(`Generated fasting & morning medication guidance.`);
      } else {
        setReplyText(
          `Hello ${firstName}, thank you for contacting us through the patient portal. Dr. Sterling's surgical team has reviewed your chart notes and confirmed all details for your upcoming procedure. Please let us know if you experience any changes in symptoms prior to arrival.`
        );
        setAiDraftSummary(`Generated empathetic clinical triage response.`);
      }

      if (onShowToast) {
        onShowToast('✨ Nightingale AI drafted context-aware reply.');
      }
    }, 450);
  };

  const totalInboundCount = patientInboundMessages.length;
  const unreadCount = unreadMessages.length;
  const clinicalCount = patientInboundMessages.filter((m) => m.category === 'Clinical Question').length;
  const refillCount = patientInboundMessages.filter((m) => m.category === 'Prescription Refill').length;
  const billingCount = patientInboundMessages.filter((m) => m.category === 'Billing').length;

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      
      {/* Top Banner & Metrics Overview */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-stone-900 rounded-3xl p-6 md:p-8 text-white shadow-xl border border-slate-800">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="space-y-2 max-w-2xl">
            <div className="flex items-center gap-2.5 flex-wrap">
              <div className="w-10 h-10 rounded-2xl bg-indigo-500/20 border border-indigo-400/30 text-indigo-300 flex items-center justify-center shadow-inner">
                <MessageSquare className="w-5 h-5" />
              </div>
              <h1 className="text-xl md:text-2xl font-bold tracking-tight text-white font-serif">
                Patient Portal Messages & Triage Center
              </h1>
              {unreadCount > 0 && (
                <span className="px-3 py-1 rounded-full bg-amber-400 text-slate-950 text-xs font-black tracking-wide animate-pulse">
                  {unreadCount} Action Required
                </span>
              )}
            </div>
            <p className="text-xs md:text-sm text-slate-300 leading-relaxed">
              Unified communication hub for two-way secure EHR messaging with patients. Triage clinical questions, verify prescription refill requests, confirm pre-op clearances, and dispatch SMS alerts in real time.
            </p>
          </div>

          {/* Quick Metrics Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="p-3.5 rounded-2xl bg-slate-800/80 border border-slate-700/80 text-center">
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">Total Inquiries</span>
              <span className="text-lg font-black text-white">{totalInboundCount}</span>
            </div>

            <div className="p-3.5 rounded-2xl bg-amber-500/20 border border-amber-400/30 text-center">
              <span className="text-[10px] font-bold uppercase tracking-wider text-amber-300 block">Unread / Urgent</span>
              <span className="text-lg font-black text-amber-300">{unreadCount}</span>
            </div>

            <div className="p-3.5 rounded-2xl bg-indigo-500/20 border border-indigo-400/30 text-center">
              <span className="text-[10px] font-bold uppercase tracking-wider text-indigo-300 block">Clinical Inquiries</span>
              <span className="text-lg font-black text-indigo-200">{clinicalCount}</span>
            </div>

            <div className="p-3.5 rounded-2xl bg-teal-500/20 border border-teal-400/30 text-center">
              <span className="text-[10px] font-bold uppercase tracking-wider text-teal-300 block">Rx Refills</span>
              <span className="text-lg font-black text-teal-200">{refillCount}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Main Two-Column Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* Left Column: Inbox List & Filter Bar (5 cols) */}
        <div className="lg:col-span-5 space-y-4">
          
          {/* Filter, Search & Category Navigation Card */}
          <div className="bg-white rounded-2xl border border-stone-200/90 shadow-2xs p-4 space-y-3">
            
            {/* Search Input */}
            <div className="relative">
              <Search className="w-4 h-4 text-stone-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search patient, MRN, topic, or keyword..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-3.5 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs font-medium text-stone-900 placeholder:text-stone-400 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
              {searchQuery && (
                <button
                  type="button"
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-stone-400 hover:text-stone-600 font-bold"
                >
                  ✕
                </button>
              )}
            </div>

            {/* Category Filter Pills */}
            <div className="flex flex-wrap items-center gap-1.5 pt-1">
              {[
                { key: 'ALL', label: 'All Inbound', count: totalInboundCount },
                { key: 'UNREAD', label: 'Unread', count: unreadCount, isAlert: unreadCount > 0 },
                { key: 'CLINICAL', label: 'Clinical', count: clinicalCount },
                { key: 'REFILL', label: 'Rx Refills', count: refillCount },
                { key: 'BILLING', label: 'Billing', count: billingCount },
              ].map((tab) => {
                const isActive = selectedTab === tab.key;
                return (
                  <button
                    key={tab.key}
                    type="button"
                    onClick={() => setSelectedTab(tab.key as any)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                      isActive
                        ? 'bg-slate-900 text-white shadow-2xs'
                        : 'bg-stone-100 hover:bg-stone-200/80 text-stone-600 border border-stone-200/60'
                    }`}
                  >
                    <span>{tab.label}</span>
                    <span
                      className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono font-bold ${
                        isActive
                          ? 'bg-slate-700 text-slate-100'
                          : tab.isAlert
                          ? 'bg-amber-200 text-amber-950 border border-amber-300'
                          : 'bg-stone-200 text-stone-700'
                      }`}
                    >
                      {tab.count}
                    </span>
                  </button>
                );
              })}
            </div>

            {/* Provider Filter & Mark All Read Toolbar */}
            <div className="flex items-center justify-between pt-2 border-t border-stone-100 gap-2">
              <select
                value={selectedProviderFilter}
                onChange={(e) => setSelectedProviderFilter(e.target.value)}
                className="bg-stone-50 border border-stone-200 rounded-xl px-2.5 py-1 text-xs font-semibold text-stone-700 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="ALL">All Attending Providers</option>
                <option value="sterling">Dr. Alistair Sterling, MD</option>
                <option value="mercer">Dr. Julian Mercer, MD</option>
                <option value="cruz">Dr. Elena Cruz, MD</option>
                <option value="chen">Dr. Marcus Chen, MD</option>
              </select>

              {unreadCount > 0 && (
                <button
                  type="button"
                  onClick={handleMarkAllRead}
                  className="px-2.5 py-1 text-xs font-bold text-indigo-700 hover:text-indigo-900 hover:bg-indigo-50 rounded-lg transition-colors cursor-pointer flex items-center gap-1 shrink-0"
                >
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Mark All Triaged</span>
                </button>
              )}
            </div>

          </div>

          {/* Patient Inbound Threads List */}
          <div className="space-y-2.5 max-h-[620px] overflow-y-auto pr-1">
            {filteredMessages.length === 0 ? (
              <div className="p-8 bg-white rounded-2xl border border-stone-200 text-center space-y-2">
                <Inbox className="w-8 h-8 text-stone-300 mx-auto" />
                <p className="text-xs font-bold text-stone-600">No portal messages match your filter</p>
                <p className="text-[11px] text-stone-400">Try clearing the search query or selecting a different category.</p>
              </div>
            ) : (
              filteredMessages.map((msg) => {
                const isSelected = activeMessage?.id === msg.id;
                return (
                  <div
                    key={msg.id}
                    onClick={() => setActiveMessageId(msg.id)}
                    className={`p-4 rounded-2xl border transition-all cursor-pointer text-left space-y-2 relative group ${
                      isSelected
                        ? 'bg-indigo-50/80 border-indigo-300 shadow-sm ring-1 ring-indigo-200'
                        : msg.read
                        ? 'bg-white hover:bg-stone-50 border-stone-200/90 shadow-2xs'
                        : 'bg-amber-50/60 hover:bg-amber-50/90 border-amber-200 shadow-xs'
                    }`}
                  >
                    {/* Unread Indicator Bar */}
                    {!msg.read && (
                      <span className="absolute left-1.5 top-4 bottom-4 w-1 bg-amber-500 rounded-full" />
                    )}

                    <div className="flex items-start justify-between gap-2 pl-2">
                      <div className="flex items-center gap-2">
                        <div className="w-7 h-7 rounded-xl bg-gradient-to-tr from-slate-800 to-indigo-900 text-white font-bold text-xs flex items-center justify-center shadow-2xs shrink-0">
                          {msg.senderName[0]}
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <h4 className="text-xs font-bold text-stone-900 leading-tight">
                              {msg.senderName}
                            </h4>
                            {!msg.read && (
                              <span className="px-1.5 py-0.2 rounded text-[9px] font-black bg-amber-500 text-white uppercase tracking-wider">
                                New
                              </span>
                            )}
                          </div>
                          <span className="text-[10px] text-stone-500 font-medium">
                            MRN: #{msg.patientId}
                          </span>
                        </div>
                      </div>

                      <div className="flex items-center gap-1.5 text-[10px] text-stone-500 shrink-0">
                        <Clock className="w-3 h-3 text-stone-400" />
                        <span>{msg.date || msg.timestamp}</span>
                      </div>
                    </div>

                    {/* Category & Subject */}
                    <div className="pl-2 flex items-center justify-between gap-2">
                      {msg.category && (
                        <span
                          className={`text-[10px] px-2 py-0.5 rounded-md font-bold uppercase tracking-wider ${
                            msg.category === 'Prescription Refill'
                              ? 'bg-teal-100 text-teal-900 border border-teal-200'
                              : msg.category === 'Clinical Question'
                              ? 'bg-indigo-100 text-indigo-900 border border-indigo-200'
                              : 'bg-stone-100 text-stone-800 border border-stone-200'
                          }`}
                        >
                          {msg.category}
                        </span>
                      )}

                      <button
                        type="button"
                        onClick={(e) => handleToggleRead(msg, e)}
                        className="text-[10px] text-stone-400 hover:text-stone-700 font-medium cursor-pointer"
                        title={msg.read ? 'Mark Unread' : 'Mark Read'}
                      >
                        {msg.read ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3 text-amber-600" />}
                      </button>
                    </div>

                    {/* Message Preview Snippet */}
                    <p className="text-xs text-stone-700 line-clamp-2 leading-relaxed pl-2 font-medium">
                      {msg.content}
                    </p>

                    {/* Action Footer */}
                    <div className="pt-1.5 border-t border-stone-100/90 pl-2 flex items-center justify-between text-[11px]">
                      <span className="text-stone-500 font-medium truncate max-w-[170px]">
                        Attending: {msg.providerId === 'dr-mercer' ? 'Dr. Mercer' : 'Dr. Sterling'}
                      </span>
                      <span className="text-indigo-600 group-hover:text-indigo-900 font-bold flex items-center gap-0.5">
                        <span>Open Thread</span>
                        <ChevronRight className="w-3 h-3" />
                      </span>
                    </div>
                  </div>
                );
              })
            )}
          </div>

        </div>

        {/* Right Column: Active Message Thread & Response Composer (7 cols) */}
        <div className="lg:col-span-7 space-y-4">
          {activeMessage ? (
            <div className="space-y-4">
              
              {/* Active Conversation Card */}
              <div className="bg-white rounded-2xl border border-stone-200/90 shadow-2xs overflow-hidden">
                
                {/* Thread Header */}
                <div className="p-4 bg-stone-50 border-b border-stone-200/80 flex flex-wrap items-center justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-slate-900 to-indigo-900 text-white font-bold text-sm flex items-center justify-center shadow-xs">
                      {activeMessage.senderName[0]}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h3 className="text-sm font-bold text-stone-900">
                          {activeMessage.senderName}
                        </h3>
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-stone-200 text-stone-700">
                          MRN: #{activeMessage.patientId}
                        </span>
                        {!activeMessage.read && (
                          <span className="px-2 py-0.5 rounded text-[10px] font-black bg-amber-500 text-white uppercase">
                            Unread
                          </span>
                        )}
                      </div>
                      <p className="text-[11px] text-stone-500 font-medium mt-0.5">
                        Portal Thread ID: {activeMessage.id} · Received {activeMessage.date || 'Today'} at {activeMessage.timestamp}
                      </p>
                    </div>
                  </div>

                  {/* Actions Header */}
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => handleOpenChart(activeMessage.patientId)}
                      className="px-3 py-1.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer shadow-2xs"
                      title="Open Full EHR Patient Chart"
                    >
                      <FileText className="w-3.5 h-3.5 text-teal-300" />
                      <span>Open Patient Chart</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => handleToggleRead(activeMessage)}
                      className="p-1.5 bg-white hover:bg-stone-100 border border-stone-200 rounded-xl text-stone-600 transition-colors cursor-pointer"
                      title={activeMessage.read ? 'Mark as Unread' : 'Mark as Read'}
                    >
                      {activeMessage.read ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4 text-amber-600" />}
                    </button>
                  </div>
                </div>

                {/* Patient Procedure & Status Quick Context Bar */}
                {associatedCase && (
                  <div className="px-4 py-2 bg-indigo-50/70 border-b border-indigo-100 flex flex-wrap items-center justify-between text-xs font-medium text-indigo-950 gap-2">
                    <div className="flex items-center gap-2">
                      <Stethoscope className="w-3.5 h-3.5 text-indigo-700" />
                      <span>Scheduled Procedure: <strong className="font-bold">{associatedCase.procedure}</strong></span>
                    </div>
                    <div className="flex items-center gap-3">
                      <span>Room: <strong>{associatedCase.operatingRoom}</strong></span>
                      <span>Surgeon: <strong>{associatedCase.surgeon}</strong></span>
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-900 border border-emerald-300">
                        {associatedCase.readinessScore}% AI Cleared
                      </span>
                    </div>
                  </div>
                )}

                {/* Full Message History Thread Flow */}
                <div className="p-5 space-y-4 max-h-[380px] overflow-y-auto bg-stone-50/40">
                  {activeThread.map((item) => {
                    const isStaff = item.sender === 'provider';
                    return (
                      <div
                        key={item.id}
                        className={`flex flex-col ${isStaff ? 'items-end' : 'items-start'} space-y-1`}
                      >
                        <div className="flex items-center gap-1.5 text-[11px] text-stone-500 font-medium px-1">
                          <span className="font-bold text-stone-800">{item.senderName}</span>
                          <span>({isStaff ? item.senderTitle || 'Clinical Staff' : 'Patient'})</span>
                          <span>·</span>
                          <span>{item.date || 'Today'} {item.timestamp}</span>
                        </div>

                        <div
                          className={`p-4 rounded-2xl max-w-xl text-xs leading-relaxed font-medium shadow-2xs ${
                            isStaff
                              ? 'bg-slate-900 text-white rounded-tr-xs'
                              : 'bg-white border border-stone-200 text-stone-800 rounded-tl-xs'
                          }`}
                        >
                          <p className="whitespace-pre-line">{item.content}</p>

                          {item.attachment && (
                            <div
                              className={`mt-2.5 p-2 rounded-xl flex items-center justify-between text-[11px] font-medium ${
                                isStaff
                                  ? 'bg-slate-800 text-teal-300 border border-slate-700'
                                  : 'bg-stone-100 text-stone-700 border border-stone-200'
                              }`}
                            >
                              <div className="flex items-center gap-1.5">
                                <Paperclip className="w-3.5 h-3.5" />
                                <span className="font-bold">{item.attachment.name}</span>
                              </div>
                              <span className="text-[10px] opacity-75">{item.attachment.size}</span>
                            </div>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Response Composer & AI Assist */}
              <div className="bg-white rounded-2xl border border-stone-200/90 shadow-2xs p-5 space-y-4">
                <div className="flex flex-wrap items-center justify-between border-b border-stone-200/80 pb-3 gap-2">
                  <div className="flex items-center gap-2">
                    <Send className="w-4 h-4 text-indigo-600" />
                    <h4 className="text-xs font-bold text-stone-900 uppercase tracking-wider">
                      Compose Clinical Reply to {activeMessage.senderName}
                    </h4>
                  </div>
                  <span className="text-[11px] text-stone-500 font-medium">
                    Delivered to Patient Portal & SMS Push
                  </span>
                </div>

                {/* Quick Clinical Templates Carousel */}
                <div className="space-y-1.5">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-stone-400 block">
                    Quick Clinical Templates
                  </span>
                  <div className="flex flex-wrap gap-1.5">
                    {clinicalTemplates.map((tpl, i) => (
                      <button
                        key={i}
                        type="button"
                        onClick={() => {
                          setReplyText(tpl.text);
                          if (onShowToast) onShowToast(`Loaded template: "${tpl.title}"`);
                        }}
                        className="px-2.5 py-1 bg-stone-100 hover:bg-indigo-50 hover:text-indigo-900 border border-stone-200/80 rounded-xl text-[11px] font-semibold text-stone-700 transition-colors cursor-pointer"
                      >
                        {tpl.title}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Nightingale AI Assistant Draft Generator */}
                <div className="p-3 bg-gradient-to-r from-indigo-50 via-teal-50/50 to-blue-50 border border-indigo-100 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div className="flex items-start gap-2.5">
                    <div className="p-1.5 bg-indigo-600 text-white rounded-lg shrink-0 shadow-2xs">
                      <Sparkles className="w-3.5 h-3.5 animate-spin-slow" />
                    </div>
                    <div>
                      <div className="text-xs font-bold text-indigo-950 flex items-center gap-1.5">
                        <span>Nightingale AI Clinical Drafting</span>
                        <span className="px-1.5 py-0.2 rounded text-[9px] bg-indigo-200 text-indigo-900 font-bold uppercase">
                          Context Aware
                        </span>
                      </div>
                      <p className="text-[11px] text-indigo-800 leading-snug font-medium mt-0.5">
                        Analyzes the patient inquiry, chart records, and surgery readiness to draft an accurate clinical response.
                      </p>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={handleGenerateAiDraft}
                    disabled={isGeneratingAiDraft}
                    className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all shadow-2xs shrink-0 cursor-pointer disabled:opacity-50"
                  >
                    <Sparkles className="w-3 h-3" />
                    <span>{isGeneratingAiDraft ? 'Analyzing & Drafting...' : 'Draft Response'}</span>
                  </button>
                </div>

                {aiDraftSummary && (
                  <div className="p-2.5 bg-emerald-50 border border-emerald-200 rounded-xl flex items-center justify-between text-xs text-emerald-900 font-medium">
                    <div className="flex items-center gap-1.5">
                      <Check className="w-3.5 h-3.5 text-emerald-700" />
                      <span>{aiDraftSummary}</span>
                    </div>
                    <button
                      type="button"
                      onClick={() => setAiDraftSummary(null)}
                      className="text-emerald-700 hover:text-emerald-950 font-bold text-xs"
                    >
                      ✕
                    </button>
                  </div>
                )}

                {/* Reply Form */}
                <form onSubmit={handleSendReply} className="space-y-3">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                    <div>
                      <label className="text-[10px] font-bold text-stone-500 uppercase tracking-wider block mb-1">
                        Authoring Clinician / Staff
                      </label>
                      <select
                        value={selectedStaffAuthor}
                        onChange={(e) => {
                          setSelectedStaffAuthor(e.target.value);
                          if (e.target.value.includes('Sterling')) {
                            setSelectedStaffRole('Attending Surgeon & Medical Director');
                          } else if (e.target.value.includes('Mercer')) {
                            setSelectedStaffRole('Attending Facial Surgeon');
                          } else {
                            setSelectedStaffRole('Lead Surgical Coordinator, RN');
                          }
                        }}
                        className="w-full p-2 bg-stone-50 border border-stone-200 rounded-xl text-xs font-semibold text-stone-800 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                      >
                        <option value="Dr. Alistair Sterling, MD">Dr. Alistair Sterling, MD (Attending)</option>
                        <option value="Dr. Julian Mercer, MD">Dr. Julian Mercer, MD (Attending)</option>
                        <option value="Nurse Evelyn Brooks, RN">Nurse Evelyn Brooks, RN (Surgical Coordinator)</option>
                      </select>
                    </div>

                    <div>
                      <label className="text-[10px] font-bold text-stone-500 uppercase tracking-wider block mb-1">
                        Author Role & Credentials
                      </label>
                      <input
                        type="text"
                        value={selectedStaffRole}
                        onChange={(e) => setSelectedStaffRole(e.target.value)}
                        className="w-full p-2 bg-stone-50 border border-stone-200 rounded-xl text-xs font-medium text-stone-800 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                      />
                    </div>
                  </div>

                  <div>
                    <textarea
                      rows={4}
                      value={replyText}
                      onChange={(e) => setReplyText(e.target.value)}
                      placeholder={`Type clinical response to ${activeMessage.senderName}...`}
                      className="w-full p-3.5 bg-stone-50 border border-stone-300 rounded-xl text-xs font-medium text-stone-900 focus:outline-none focus:ring-2 focus:ring-indigo-500 leading-relaxed placeholder:text-stone-400"
                    />
                  </div>

                  {/* Attachment Pill if Selected */}
                  {selectedAttachment && (
                    <div className="flex items-center justify-between p-2 bg-stone-100 rounded-xl text-xs text-stone-800 font-medium">
                      <div className="flex items-center gap-1.5">
                        <Paperclip className="w-3.5 h-3.5 text-stone-500" />
                        <span>{selectedAttachment.name} ({selectedAttachment.size})</span>
                      </div>
                      <button
                        type="button"
                        onClick={() => setSelectedAttachment(null)}
                        className="text-stone-400 hover:text-stone-700 font-bold"
                      >
                        ✕
                      </button>
                    </div>
                  )}

                  {/* Bottom Controls */}
                  <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
                    <div className="flex items-center gap-4">
                      <button
                        type="button"
                        onClick={() => {
                          setSelectedAttachment({
                            name: 'PreOp_Surgical_Instructions_Packet.pdf',
                            size: '1.4 MB'
                          });
                          if (onShowToast) onShowToast('Attached Pre-Op Instructions PDF.');
                        }}
                        className="text-xs font-bold text-stone-600 hover:text-stone-900 flex items-center gap-1.5 cursor-pointer"
                      >
                        <Paperclip className="w-3.5 h-3.5" />
                        <span>Attach Document</span>
                      </button>

                      <label className="flex items-center gap-2 text-xs text-stone-600 font-medium cursor-pointer">
                        <input
                          type="checkbox"
                          checked={sendSmsNotification}
                          onChange={(e) => setSendSmsNotification(e.target.checked)}
                          className="rounded border-stone-300 text-indigo-600 focus:ring-indigo-500"
                        />
                        <span>Send Instant SMS Push Alert</span>
                      </label>
                    </div>

                    <button
                      type="submit"
                      disabled={!replyText.trim()}
                      className="px-5 py-2.5 bg-slate-900 hover:bg-slate-800 disabled:opacity-40 text-white rounded-xl text-xs font-bold flex items-center gap-2 transition-all shadow-md cursor-pointer disabled:cursor-not-allowed"
                    >
                      <Send className="w-3.5 h-3.5 text-teal-300" />
                      <span>Transmit Reply to Portal</span>
                    </button>
                  </div>
                </form>
              </div>

            </div>
          ) : (
            <div className="p-12 bg-white rounded-2xl border border-stone-200 text-center space-y-3">
              <MessageSquare className="w-10 h-10 text-stone-300 mx-auto" />
              <h3 className="text-sm font-bold text-stone-700">Select a Message to Triage</h3>
              <p className="text-xs text-stone-500 max-w-sm mx-auto">
                Choose a conversation from the inbound inbox on the left to read full details and send context-aware replies.
              </p>
            </div>
          )}
        </div>

      </div>

    </div>
  );
};
