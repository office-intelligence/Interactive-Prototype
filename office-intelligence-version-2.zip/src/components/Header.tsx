import React, { useState, useRef, useEffect } from 'react';
import { 
  Home,
  Calendar,
  FileText,
  CreditCard,
  Settings,
  Sparkles,
  Zap,
  MessageSquare,
  RefreshCw, 
  Plus, 
  Check, 
  LogOut,
  ShieldCheck,
  ChevronDown,
  KeyRound,
  Eye,
  EyeOff,
  CheckCircle2,
  Lock,
  Users,
  Activity,
  Sliders,
  Building2
} from 'lucide-react';
import { AuthUser, PracticeConfig } from '../types';
import { AdminActiveSection } from './AdministrationPage';
import { getUnreadCount, subscribeToMessageUpdates } from '../utils/portalMessageStore';

interface HeaderProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onRefresh: () => void;
  onAppointmentBooks?: () => void;
  onPrint?: () => void;
  searchQuery?: string;
  setSearchQuery?: (query: string) => void;
  onAddPatient?: () => void;
  onOpenAIChat?: () => void;
  needsAttentionCount?: number;
  currentUser?: AuthUser | null;
  onLogout?: () => void;
  onNavigateLanding?: () => void;
  onNavigatePortal?: () => void;
  onNavigateAdminSection?: (section: AdminActiveSection) => void;
  practiceConfig?: PracticeConfig;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  onRefresh,
  onAppointmentBooks,
  onPrint,
  searchQuery,
  setSearchQuery,
  onAddPatient,
  onOpenAIChat,
  needsAttentionCount = 0,
  currentUser,
  onLogout,
  onNavigateLanding,
  onNavigatePortal,
  onNavigateAdminSection,
  practiceConfig
}) => {
  const [unreadPortalMessages, setUnreadPortalMessages] = useState<number>(() => getUnreadCount());
  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);
  const [isChangePasswordOpen, setIsChangePasswordOpen] = useState(false);
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showCurrentPw, setShowCurrentPw] = useState(false);
  const [showNewPw, setShowNewPw] = useState(false);
  const [passwordError, setPasswordError] = useState<string | null>(null);
  const [passwordSuccess, setPasswordSuccess] = useState(false);

  const userMenuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const updateCount = () => {
      setUnreadPortalMessages(getUnreadCount());
    };
    updateCount();
    const unsubscribe = subscribeToMessageUpdates(updateCount);
    return () => unsubscribe();
  }, []);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (userMenuRef.current && !userMenuRef.current.contains(event.target as Node)) {
        setIsUserMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const navItems: { id: string; label: string; icon: React.ComponentType<{ className?: string }>; badge?: number; badgeColor?: string }[] = [
    { id: 'home', label: 'Dashboard', icon: Home },
    { id: 'schedule', label: 'Schedule', icon: Calendar },
    { 
      id: 'patients', 
      label: 'Patient Chart', 
      icon: FileText, 
      badge: needsAttentionCount > 0 ? needsAttentionCount : undefined,
      badgeColor: 'bg-amber-500 text-white'
    },
    { 
      id: 'messages', 
      label: 'Messages', 
      icon: MessageSquare, 
      badge: unreadPortalMessages > 0 ? unreadPortalMessages : undefined,
      badgeColor: 'bg-teal-500 text-white'
    },
    { id: 'billing', label: 'Billing', icon: CreditCard },
    { id: 'ai-home', label: 'AI Hub', icon: Sparkles },
    { id: 'workflows', label: 'Workflow', icon: Zap },
    { id: 'admin', label: 'Admin', icon: Settings },
  ];

  const handleChangePasswordSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setPasswordError(null);

    if (!currentPassword) {
      setPasswordError('Please enter your current password.');
      return;
    }
    if (newPassword.length < 8) {
      setPasswordError('New password must be at least 8 characters long.');
      return;
    }
    if (newPassword !== confirmPassword) {
      setPasswordError('New passwords do not match.');
      return;
    }

    setPasswordSuccess(true);
    setTimeout(() => {
      setPasswordSuccess(false);
      setIsChangePasswordOpen(false);
      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');
    }, 1800);
  };

  const userInitials = currentUser 
    ? `${currentUser.firstName[0] || ''}${currentUser.lastName[0] || ''}`.toUpperCase()
    : 'AS';

  const userDisplayName = currentUser
    ? `${currentUser.firstName} ${currentUser.lastName}`
    : 'Dr. Alistair Sterling, MD';

  const practiceDisplayName = practiceConfig?.practiceName || 'Aura Vanguard Surgical Pavilion';

  return (
    <header className="sticky top-0 z-30 bg-white border-b border-stone-200/90 shadow-xs">
      {/* Top Bar: Brand, Facility, Actions & User Account */}
      <div className="w-full px-3 sm:px-6 lg:px-8 border-b border-stone-100">
        <div className="flex items-center justify-between h-15 gap-2 sm:gap-4">
          
          {/* Left: Branding & Facility Pill */}
          <div className="flex items-center gap-3 min-w-0">
            {/* Logo / Brand */}
            <button
              type="button"
              onClick={() => setActiveTab('home')}
              className="flex items-center gap-2.5 text-left group cursor-pointer"
            >
              <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-slate-900 via-blue-900 to-indigo-900 flex items-center justify-center text-white shadow-md shadow-blue-950/20 shrink-0 group-hover:scale-105 transition-transform">
                <Activity className="w-5 h-5 text-teal-300" />
              </div>
              <div className="min-w-0">
                <div className="flex items-center gap-1.5">
                  <span className="font-bold text-stone-900 text-sm tracking-tight truncate leading-none">
                    Office Intelligence
                  </span>
                  <span className="px-1.5 py-0.2 rounded-md text-[9px] font-bold bg-blue-50 text-blue-900 border border-blue-200 uppercase font-mono">
                    v2.0
                  </span>
                  <span className="hidden sm:inline-flex items-center gap-1 px-1.5 py-0.2 rounded-md text-[9px] font-bold bg-emerald-50 text-emerald-800 border border-emerald-200 font-mono">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                    HIPAA
                  </span>
                </div>
                <div className="text-[11px] text-stone-500 flex items-center gap-1 truncate mt-0.5">
                  <span className="text-blue-700 font-semibold truncate">Medical OS</span>
                  <span className="text-stone-300">•</span>
                  <span className="truncate">{practiceDisplayName}</span>
                </div>
              </div>
            </button>
          </div>

          {/* Right: Quick Action Buttons & User Menu */}
          <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
            
            {/* Nightingale AI Assistant Trigger */}
            {onOpenAIChat && (
              <button
                onClick={onOpenAIChat}
                className="px-2.5 sm:px-3 py-1.5 rounded-xl bg-gradient-to-r from-blue-700 via-blue-800 to-indigo-900 hover:from-blue-800 hover:to-indigo-950 text-white text-xs font-bold flex items-center gap-1.5 transition-all shadow-xs hover:shadow-md cursor-pointer"
                title="Open Nightingale AI Assistant"
                id="header-ai-assistant-btn"
              >
                <Sparkles className="w-3.5 h-3.5 text-teal-300 animate-pulse" />
                <span className="hidden sm:inline">Ask AI</span>
              </button>
            )}

            {/* Add Patient Button */}
            {activeTab === 'patients' && onAddPatient && (
              <button
                onClick={onAddPatient}
                className="px-2.5 sm:px-3.5 py-1.5 rounded-xl bg-blue-700 hover:bg-blue-800 text-white text-xs font-semibold flex items-center gap-1.5 transition-colors shadow-2xs cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span className="hidden sm:inline">Add Patient</span>
              </button>
            )}

            {/* Patient Portal Switcher */}
            {onNavigatePortal && (
              <button
                onClick={onNavigatePortal}
                id="header-patient-portal-switch-btn"
                className="px-2.5 py-1.5 rounded-xl bg-teal-50 hover:bg-teal-100 text-teal-900 border border-teal-200 text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer shadow-2xs"
                title="Switch to Patient Portal View"
              >
                <Users className="w-3.5 h-3.5 text-teal-700" />
                <span className="hidden md:inline">Patient Portal</span>
              </button>
            )}

            {/* Refresh Live Schedule Button */}
            <button
              onClick={onRefresh}
              className="p-1.5 sm:p-2 rounded-xl bg-stone-50 hover:bg-stone-100 border border-stone-200 text-stone-600 hover:text-stone-900 transition-colors shadow-2xs cursor-pointer"
              title="Refresh Real-time Schedule & Status"
            >
              <RefreshCw className="w-4 h-4" />
            </button>

            {/* User Profile Dropdown */}
            <div className="relative" ref={userMenuRef}>
              <button
                onClick={() => setIsUserMenuOpen(!isUserMenuOpen)}
                className={`flex items-center gap-1.5 sm:gap-2 px-2 sm:px-2.5 py-1.5 bg-stone-50 hover:bg-stone-100 border rounded-xl transition-all shadow-2xs cursor-pointer ${
                  isUserMenuOpen ? 'border-blue-500 ring-2 ring-blue-500/20 bg-blue-50/50' : 'border-stone-200/90'
                }`}
                id="header-user-menu-btn"
              >
                <div className="w-7 h-7 rounded-lg bg-gradient-to-tr from-slate-900 to-blue-900 text-white font-bold text-xs flex items-center justify-center shadow-xs">
                  {userInitials}
                </div>
                <div className="text-left hidden lg:block max-w-[130px]">
                  <div className="text-xs font-bold text-stone-900 truncate leading-tight">
                    {userDisplayName}
                  </div>
                  <div className="text-[10px] text-stone-500 truncate leading-tight font-mono">
                    {currentUser?.role || 'Practice Admin'}
                  </div>
                </div>
                <ChevronDown className={`w-3.5 h-3.5 text-stone-500 transition-transform duration-150 ${isUserMenuOpen ? 'rotate-180 text-blue-700' : ''}`} />
              </button>

              {/* User Dropdown Menu */}
              {isUserMenuOpen && (
                <div className="absolute right-0 mt-2 w-68 max-w-[calc(100vw-1.5rem)] bg-white rounded-2xl border border-stone-200 shadow-2xl p-2 z-50 animate-in fade-in slide-in-from-top-2 duration-150 space-y-1">
                  <div className="p-3 bg-stone-50 rounded-xl border border-stone-100 mb-1">
                    <p className="text-xs font-bold text-stone-900 truncate">{userDisplayName}</p>
                    <p className="text-[11px] text-stone-500 truncate">{currentUser?.email || 'admin@auravanguardsurgical.com'}</p>
                    <div className="flex items-center gap-1 text-[10px] font-bold text-emerald-700 mt-1">
                      <ShieldCheck className="w-3 h-3" />
                      <span>Authenticated • HIPAA Session</span>
                    </div>
                  </div>

                  {/* Configure Practice shortcut */}
                  {onNavigateAdminSection && (
                    <button
                      type="button"
                      onClick={() => {
                        setIsUserMenuOpen(false);
                        onNavigateAdminSection('configure-practice');
                      }}
                      className="w-full px-3 py-2 rounded-xl text-xs font-semibold text-stone-800 hover:bg-stone-50 flex items-center gap-2.5 transition-colors cursor-pointer text-left"
                    >
                      <Sliders className="w-4 h-4 text-blue-700" />
                      <span>Configure Practice</span>
                    </button>
                  )}

                  {/* Switch to Patient Portal */}
                  {onNavigatePortal && (
                    <button
                      type="button"
                      onClick={() => {
                        setIsUserMenuOpen(false);
                        onNavigatePortal();
                      }}
                      className="w-full px-3 py-2 rounded-xl text-xs font-semibold text-teal-800 hover:bg-teal-50 flex items-center gap-2.5 transition-colors cursor-pointer text-left"
                      id="header-user-menu-patient-portal"
                    >
                      <Users className="w-4 h-4 text-teal-600" />
                      <span>Switch to Patient Portal</span>
                    </button>
                  )}

                  {/* Change Password */}
                  <button
                    type="button"
                    onClick={() => {
                      setIsUserMenuOpen(false);
                      setPasswordError(null);
                      setPasswordSuccess(false);
                      setIsChangePasswordOpen(true);
                    }}
                    className="w-full px-3 py-2 rounded-xl text-xs font-semibold text-stone-800 hover:bg-stone-50 flex items-center gap-2.5 transition-colors cursor-pointer text-left"
                    id="header-user-menu-change-password"
                  >
                    <KeyRound className="w-4 h-4 text-stone-600" />
                    <span>Change Password</span>
                  </button>

                  {/* Logout */}
                  {onLogout && (
                    <div className="pt-1 border-t border-stone-100">
                      <button
                        type="button"
                        onClick={() => {
                          setIsUserMenuOpen(false);
                          onLogout();
                        }}
                        className="w-full px-3 py-2 rounded-xl text-xs font-semibold text-rose-700 hover:bg-rose-50 flex items-center gap-2.5 transition-colors cursor-pointer text-left"
                        id="header-user-menu-logout"
                      >
                        <LogOut className="w-4 h-4 text-rose-600" />
                        <span>Log Out</span>
                      </button>
                    </div>
                  )}
                </div>
              )}
            </div>

          </div>

        </div>
      </div>

      {/* Bottom Row: Top Navigation Header with Shortened Links */}
      <div className="w-full px-3 sm:px-6 lg:px-8 bg-stone-50/80">
        <nav className="flex items-center gap-1 sm:gap-1.5 overflow-x-auto py-2 scrollbar-none snap-x" aria-label="Main Navigation">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                id={`header-nav-${item.id}`}
                className={`px-3 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 whitespace-nowrap cursor-pointer shrink-0 snap-start select-none ${
                  isActive
                    ? 'bg-blue-700 text-white shadow-sm shadow-blue-700/20 font-black'
                    : 'text-stone-600 hover:text-stone-900 hover:bg-stone-200/70'
                }`}
              >
                <Icon className={`w-4 h-4 ${isActive ? 'text-white' : 'text-stone-500'}`} />
                <span>{item.label}</span>
                {item.badge !== undefined && (
                  <span className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono font-bold ${
                    isActive 
                      ? 'bg-white text-blue-900' 
                      : item.badgeColor || 'bg-amber-500 text-white'
                  }`}>
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>
      </div>

      {/* Change Password Modal */}
      {isChangePasswordOpen && (
        <div className="fixed inset-0 z-50 bg-stone-950/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl border border-stone-200 shadow-2xl p-6 max-w-md w-full space-y-4 animate-in fade-in zoom-in-95 duration-200">
            <div className="flex items-center justify-between border-b border-stone-200 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-blue-50 text-blue-700 flex items-center justify-center">
                  <KeyRound className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-stone-900">Change Account Password</h3>
                  <p className="text-[11px] text-stone-500">Update your HIPAA secure credentials</p>
                </div>
              </div>
              <button
                onClick={() => setIsChangePasswordOpen(false)}
                className="text-stone-400 hover:text-stone-700 text-xs font-bold p-1 rounded-lg hover:bg-stone-100 transition-colors cursor-pointer"
              >
                ✕
              </button>
            </div>

            {passwordSuccess ? (
              <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-900 text-xs space-y-2 text-center py-6">
                <CheckCircle2 className="w-8 h-8 text-emerald-600 mx-auto animate-bounce" />
                <h4 className="font-bold text-sm text-emerald-950">Password Updated Successfully</h4>
                <p className="text-stone-600">Your practice account password has been updated.</p>
              </div>
            ) : (
              <form onSubmit={handleChangePasswordSubmit} className="space-y-3.5">
                {passwordError && (
                  <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-xs font-medium">
                    {passwordError}
                  </div>
                )}

                {/* Current Password */}
                <div className="space-y-1">
                  <label className="text-xs font-bold text-stone-700 flex items-center gap-1.5">
                    <Lock className="w-3.5 h-3.5 text-stone-500" />
                    <span>Current Password</span>
                  </label>
                  <div className="relative">
                    <input
                      type={showCurrentPw ? 'text' : 'password'}
                      required
                      value={currentPassword}
                      onChange={(e) => setCurrentPassword(e.target.value)}
                      placeholder="Enter current password"
                      className="w-full px-3.5 py-2 rounded-xl border border-stone-300 text-xs outline-hidden focus:border-blue-600 pr-10"
                    />
                    <button
                      type="button"
                      onClick={() => setShowCurrentPw(!showCurrentPw)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-stone-400 hover:text-stone-700 cursor-pointer"
                    >
                      {showCurrentPw ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                {/* New Password */}
                <div className="space-y-1">
                  <label className="text-xs font-bold text-stone-700 flex items-center gap-1.5">
                    <KeyRound className="w-3.5 h-3.5 text-stone-500" />
                    <span>New Password</span>
                  </label>
                  <div className="relative">
                    <input
                      type={showNewPw ? 'text' : 'password'}
                      required
                      value={newPassword}
                      onChange={(e) => setNewPassword(e.target.value)}
                      placeholder="At least 8 characters"
                      className="w-full px-3.5 py-2 rounded-xl border border-stone-300 text-xs outline-hidden focus:border-blue-600 pr-10"
                    />
                    <button
                      type="button"
                      onClick={() => setShowNewPw(!showNewPw)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-stone-400 hover:text-stone-700 cursor-pointer"
                    >
                      {showNewPw ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                {/* Confirm New Password */}
                <div className="space-y-1">
                  <label className="text-xs font-bold text-stone-700">Confirm New Password</label>
                  <input
                    type="password"
                    required
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    placeholder="Re-enter new password"
                    className="w-full px-3.5 py-2 rounded-xl border border-stone-300 text-xs outline-hidden focus:border-blue-600"
                  />
                </div>

                <div className="flex items-center justify-end gap-2 pt-2 border-t border-stone-100">
                  <button
                    type="button"
                    onClick={() => setIsChangePasswordOpen(false)}
                    className="px-4 py-2 rounded-xl text-xs font-semibold text-stone-600 hover:bg-stone-100 cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 bg-blue-700 hover:bg-blue-800 text-white text-xs font-bold rounded-xl shadow-xs transition-colors cursor-pointer"
                  >
                    Update Password
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}
    </header>
  );
};

