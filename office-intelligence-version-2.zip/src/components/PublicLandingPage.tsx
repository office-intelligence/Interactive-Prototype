import React, { useState } from 'react';
import { 
  ShieldCheck, 
  Sparkles, 
  Calendar, 
  FileText, 
  Activity, 
  Lock, 
  ArrowRight, 
  CheckCircle2, 
  Building2, 
  Zap, 
  Mail, 
  Phone, 
  MessageSquare, 
  Layers, 
  Stethoscope, 
  Clock, 
  ChevronRight, 
  Cpu, 
  Check, 
  Globe, 
  HeartHandshake, 
  BarChart3, 
  KeyRound, 
  UserPlus, 
  LogIn,
  Eye,
  Sliders,
  FileCheck,
  Send,
  Workflow,
  CheckCircle,
  Users,
  CreditCard,
  ClipboardCheck,
  TrendingUp,
  Inbox,
  Menu,
  X
} from 'lucide-react';

interface PublicLandingPageProps {
  onNavigateLogin: () => void;
  onNavigateRegister: () => void;
  onEnterApp: () => void;
  onNavigatePortal?: () => void;
}

export const PublicLandingPage: React.FC<PublicLandingPageProps> = ({
  onNavigateLogin,
  onNavigateRegister,
  onEnterApp,
  onNavigatePortal
}) => {
  const [activeWorkflowTab, setActiveWorkflowTab] = useState<'email' | 'schedule' | 'clearance' | 'communication'>('email');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const workflowDetails = {
    email: {
      title: 'Autonomous Clinical Inbox & Document OCR Parsing',
      tag: 'Zero-Touch Ingestion',
      description: 'Office Intelligence continuously scans incoming practice emails, e-faxes, lab portals, and referral pipelines. Incoming lab panels, cardiology clearances, specialty referral notes, EKG tracings, and radiology PDFs are automatically parsed, OCR-indexed, and filed directly into the corresponding patient chart with zero manual clerical intervention.',
      bullets: [
        'Automatic recognition of PDF lab reports, imaging summaries, and specialist consults',
        'Intelligent chart reconciliation via patient DOB, MRN, name, and encounter date',
        'Extracts abnormal diagnostic values and elevates urgent clinical alerts to providers',
        'Reduces practice inbox triage and manual scanning time by over 88%'
      ],
      icon: Mail,
      metric: '99.6%',
      metricLabel: 'Parsing Accuracy',
      color: 'from-blue-500 to-cyan-400'
    },
    schedule: {
      title: 'Predictive Multi-Room & Provider Schedule Orchestration',
      tag: 'Dynamic Practice Flow',
      description: 'Intelligent scheduling engine that coordinates appointment types, examination rooms, surgical suites, and physician availability. The platform dynamically recalibrates clinic queues, flags pending pre-visit requirements, and prevents bottleneck delays before they impact office throughput.',
      bullets: [
        'Concurrent multi-room visual matrix with live patient progression tracking',
        'Physician and procedure-specific historical duration models for optimized booking',
        'Real-time exam room, pre-op bay, and recovery bed status indicators',
        'Automated multi-channel alerts for room readiness and check-in milestones'
      ],
      icon: Calendar,
      metric: '28 min',
      metricLabel: 'Daily Practice Time Saved',
      color: 'from-teal-400 to-emerald-400'
    },
    clearance: {
      title: 'Autonomous Pre-Visit & Pre-Procedure Readiness Scoring',
      tag: 'Zero Day-Of Cancellations',
      description: 'Every scheduled appointment and procedure receives an AI Readiness Score (0–100%) computed in real time from completed medical history, insurance eligibility, outside diagnostic clearances, signed consents, and necessary order sets.',
      bullets: [
        'Automated 7-day, 48-hour, and 24-hour pre-visit verification audits',
        'One-click automated fast-track resolution faxes to outside PCP and cardiology clinics',
        'Seamless digital patient intake with real-time biometric and photo validation',
        'Pre-screened allergy cross-checks and medical contraindication alerts'
      ],
      icon: Zap,
      metric: '98.5%',
      metricLabel: 'On-Time Encounter Starts',
      color: 'from-amber-400 to-orange-500'
    },
    communication: {
      title: 'Omnichannel HIPAA-Compliant Patient & Vendor Messaging',
      tag: 'Secure Medical Communication',
      description: 'Two-way HIPAA-compliant SMS, email, and portal communication for arrival directions, digital check-in links, pre-visit instructions, prescription notifications, and post-encounter care tracking. Automated coordination with pharmacies, labs, and medical suppliers.',
      bullets: [
        'Automated appointment confirmations and arrival texts with 1-touch response',
        'Direct digital e-Prescribing with Surescripts routing and pharmacy updates',
        'Medical supply order tracking with automated serial & lot number verification',
        'Interactive patient messaging with automated AI-assisted clinical triage'
      ],
      icon: MessageSquare,
      metric: '100%',
      metricLabel: 'HIPAA & TCPA Compliant',
      color: 'from-purple-400 to-pink-500'
    }
  };

  const useCases = [
    {
      title: 'Primary Care & Multi-Specialty Clinics',
      icon: Building2,
      description: 'High-volume outpatient practices requiring streamlined patient check-in, real-time insurance verification, automated chart filing, and rapid documentation.',
      features: ['Automated intake & digital kiosk sync', 'Real-time 270/271 eligibility checks', 'Surescripts e-Prescribing integration'],
      accent: 'border-cyan-500/30 hover:border-cyan-400 text-cyan-400'
    },
    {
      title: 'Ambulatory Surgical Centers (ASC)',
      icon: Activity,
      description: 'Multi-OR surgical facilities requiring surgical block scheduling, anesthesia risk pre-scrubbing, turnover optimization, and AAAASF/Joint Commission compliance.',
      features: ['Multi-OR visual schedule matrix', 'WHO/AORN surgical safety checklists', 'Aldrete PACU flowsheet scoring'],
      accent: 'border-teal-500/30 hover:border-teal-400 text-teal-400'
    },
    {
      title: 'Specialty Surgical & Medical Practices',
      icon: Stethoscope,
      description: 'Plastic surgery, ophthalmology, orthopedics, ENT, and dermatology suites balancing consultative office visits with office-based procedures.',
      features: ['Longitudinal photographic records', 'Specialty operative note builders', 'Custom consent pathway automation'],
      accent: 'border-blue-500/30 hover:border-blue-400 text-blue-400'
    },
    {
      title: 'Aesthetic, Wellness & Concierge Centers',
      icon: Sparkles,
      description: 'Bespoke medical aesthetic clinics and concierge wellness centers seeking premium patient experiences, point-of-sale billing, and automated follow-ups.',
      features: ['Digital photo baseline review', 'Doctor-to-pay & self-pay ledger', 'Automated SMS post-treatment care'],
      accent: 'border-purple-500/30 hover:border-purple-400 text-purple-400'
    }
  ];

  return (
    <div className="min-h-screen bg-[#070B14] text-slate-100 font-sans selection:bg-teal-500/30 selection:text-teal-200">
      
      {/* 1. Public Top Navigation Bar (Dark Glass) */}
      <header className="sticky top-0 z-50 bg-[#0A0F1D]/85 backdrop-blur-xl border-b border-slate-800/80 shadow-xl">
        <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 h-16 sm:h-18 flex items-center justify-between gap-2 sm:gap-4">
          
          {/* Mobile Hamburger Menu Button & Logo */}
          <div className="flex items-center gap-2.5 sm:gap-3 min-w-0">
            <button
              type="button"
              onClick={() => setIsMobileMenuOpen(true)}
              className="p-2 rounded-xl bg-slate-800/80 hover:bg-slate-700/80 text-slate-300 hover:text-white border border-slate-700/60 transition-colors cursor-pointer md:hidden shrink-0"
              title="Open Navigation Menu"
              aria-label="Open Navigation Menu"
              id="landing-mobile-menu-btn"
            >
              <Menu className="w-5 h-5 text-teal-400" />
            </button>

            <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-gradient-to-tr from-teal-500 via-cyan-500 to-blue-600 flex items-center justify-center text-slate-950 shadow-lg shadow-teal-500/20 shrink-0">
              <Sparkles className="w-4 h-4 sm:w-5 sm:h-5 text-slate-950 stroke-[2.5]" />
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-1.5 sm:gap-2">
                <span className="font-serif text-base sm:text-xl font-bold text-white tracking-tight truncate">Office Intelligence</span>
                <span className="hidden sm:inline-block px-2 py-0.5 rounded-full text-[10px] font-bold bg-teal-500/20 text-teal-300 border border-teal-500/30 uppercase tracking-wider shrink-0">
                  Medical AI OS
                </span>
              </div>
              <p className="text-[10px] sm:text-[11px] text-slate-400 font-medium truncate max-w-[200px] sm:max-w-none">Practice Management & Clinical Intelligence</p>
            </div>
          </div>

          {/* Desktop Center Nav Links */}
          <nav className="hidden md:flex items-center gap-6 lg:gap-8 text-xs font-semibold text-slate-300">
            <a href="#features" className="hover:text-teal-300 transition-colors">Core Capabilities</a>
            <a href="#workflows" className="hover:text-teal-300 transition-colors">AI Workflows</a>
            <a href="#specialties" className="hover:text-teal-300 transition-colors">Specialties & Clinics</a>
            <a href="#hipaa" className="hover:text-teal-300 transition-colors">HIPAA & Security</a>
            <a href="#administration" className="hover:text-teal-300 transition-colors">Practice Setup</a>
          </nav>

          {/* Action Buttons */}
          <div className="flex items-center gap-1.5 sm:gap-3 shrink-0">
            {onNavigatePortal && (
              <button
                onClick={onNavigatePortal}
                id="public-nav-portal-btn"
                className="hidden sm:flex px-3 py-1.5 sm:px-3.5 sm:py-2 text-xs font-bold text-teal-300 bg-teal-950/60 hover:bg-teal-900/80 rounded-xl transition-all items-center gap-1.5 cursor-pointer border border-teal-500/40 shadow-sm"
                title="Open Patient Portal (Review Sample Fictitious Data)"
              >
                <Users className="w-4 h-4 text-teal-400" />
                <span className="hidden md:inline">Patient Portal</span>
                <span className="md:hidden">Portal</span>
                <span className="hidden lg:inline px-1.5 py-0.2 rounded text-[9px] font-bold bg-teal-400 text-slate-950 uppercase tracking-tight">New</span>
              </button>
            )}

            <button
              onClick={onNavigateLogin}
              id="public-nav-login-btn"
              className="px-3 py-1.5 sm:px-4 sm:py-2 text-xs font-bold text-slate-300 hover:text-white hover:bg-slate-800/80 rounded-xl transition-all flex items-center gap-1.5 cursor-pointer border border-slate-700/60"
            >
              <LogIn className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-teal-400" />
              <span>Log In</span>
            </button>

            <button
              onClick={onNavigateRegister}
              id="public-nav-register-btn"
              className="px-3 py-1.5 sm:px-4 sm:py-2 bg-gradient-to-r from-teal-500 via-cyan-500 to-blue-600 hover:from-teal-400 hover:to-blue-500 text-slate-950 text-xs font-bold rounded-xl shadow-lg shadow-cyan-500/20 hover:shadow-cyan-500/35 transition-all flex items-center gap-1.5 cursor-pointer transform hover:-translate-y-0.5"
            >
              <UserPlus className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-slate-950" />
              <span className="hidden sm:inline">Get Started</span>
              <span className="sm:hidden">Join</span>
            </button>

            <button
              onClick={onEnterApp}
              id="public-nav-demo-btn"
              className="hidden lg:flex px-3.5 py-2 bg-slate-800/90 hover:bg-slate-700 text-white text-xs font-semibold rounded-xl transition-all items-center gap-1.5 shadow-md border border-slate-700 cursor-pointer"
              title="Launch Live Practice Dashboard Demo"
            >
              <Eye className="w-3.5 h-3.5 text-teal-400" />
              <span>Live Demo</span>
            </button>
          </div>
        </div>
      </header>

      {/* Mobile Off-Canvas Drawer (Slides in from the left edge when tapped) */}
      {isMobileMenuOpen && (
        <div className="fixed inset-0 z-50 md:hidden animate-in fade-in duration-200">
          {/* Backdrop Overlay */}
          <div 
            onClick={() => setIsMobileMenuOpen(false)}
            className="fixed inset-0 bg-black/75 backdrop-blur-xs transition-opacity"
          />

          {/* Off-Canvas Left Drawer */}
          <aside className="fixed inset-y-0 left-0 z-50 w-76 max-w-[85vw] bg-[#0A0F1D] border-r border-slate-800/90 shadow-2xl p-5 flex flex-col justify-between overflow-y-auto animate-in slide-in-from-left duration-300">
            <div className="space-y-6">
              
              {/* Drawer Top Header with Brand & Close Button */}
              <div className="flex items-center justify-between pb-4 border-b border-slate-800/80">
                <div className="flex items-center gap-2.5">
                  <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-teal-500 via-cyan-500 to-blue-600 flex items-center justify-center text-slate-950 shadow-md">
                    <Sparkles className="w-4 h-4 text-slate-950 stroke-[2.5]" />
                  </div>
                  <div>
                    <h2 className="font-serif text-base font-bold text-white tracking-tight">Office Intelligence</h2>
                    <span className="px-1.5 py-0.2 rounded text-[9px] font-bold bg-teal-500/20 text-teal-300 border border-teal-500/30 uppercase tracking-wider">
                      Medical AI OS
                    </span>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => setIsMobileMenuOpen(false)}
                  className="p-2 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors cursor-pointer border border-slate-700/60"
                  title="Close navigation menu"
                  id="landing-drawer-close-btn"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Vertical Navigation Links */}
              <div className="space-y-1">
                <p className="text-[10px] font-mono uppercase tracking-wider text-slate-400 px-3 py-1 font-bold">
                  Navigation
                </p>
                <a
                  href="#features"
                  onClick={() => setIsMobileMenuOpen(false)}
                  className="flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-semibold text-slate-200 hover:text-white hover:bg-slate-800/70 transition-colors"
                >
                  <Zap className="w-4 h-4 text-cyan-400" />
                  <span>Core Capabilities</span>
                </a>
                <a
                  href="#workflows"
                  onClick={() => setIsMobileMenuOpen(false)}
                  className="flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-semibold text-slate-200 hover:text-white hover:bg-slate-800/70 transition-colors"
                >
                  <Cpu className="w-4 h-4 text-teal-400" />
                  <span>AI Workflows</span>
                </a>
                <a
                  href="#specialties"
                  onClick={() => setIsMobileMenuOpen(false)}
                  className="flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-semibold text-slate-200 hover:text-white hover:bg-slate-800/70 transition-colors"
                >
                  <Stethoscope className="w-4 h-4 text-blue-400" />
                  <span>Specialties &amp; Clinics</span>
                </a>
                <a
                  href="#hipaa"
                  onClick={() => setIsMobileMenuOpen(false)}
                  className="flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-semibold text-slate-200 hover:text-white hover:bg-slate-800/70 transition-colors"
                >
                  <ShieldCheck className="w-4 h-4 text-emerald-400" />
                  <span>HIPAA &amp; Security</span>
                </a>
                <a
                  href="#administration"
                  onClick={() => setIsMobileMenuOpen(false)}
                  className="flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-semibold text-slate-200 hover:text-white hover:bg-slate-800/70 transition-colors"
                >
                  <Sliders className="w-4 h-4 text-purple-400" />
                  <span>Practice Setup</span>
                </a>
              </div>

              {/* Action Buttons in Drawer */}
              <div className="space-y-2.5 pt-4 border-t border-slate-800/80">
                <p className="text-[10px] font-mono uppercase tracking-wider text-slate-400 px-3 py-1 font-bold">
                  Quick Access
                </p>

                {onNavigatePortal && (
                  <button
                    onClick={() => {
                      setIsMobileMenuOpen(false);
                      onNavigatePortal();
                    }}
                    className="w-full py-2.5 px-3.5 text-xs font-bold text-teal-300 bg-teal-950/70 hover:bg-teal-900/90 rounded-xl transition-all flex items-center justify-between cursor-pointer border border-teal-500/40 shadow-sm"
                  >
                    <div className="flex items-center gap-2">
                      <Users className="w-4 h-4 text-teal-400" />
                      <span>Patient Portal</span>
                    </div>
                    <span className="px-1.5 py-0.2 rounded text-[9px] font-bold bg-teal-400 text-slate-950 uppercase">New</span>
                  </button>
                )}

                <button
                  onClick={() => {
                    setIsMobileMenuOpen(false);
                    onEnterApp();
                  }}
                  className="w-full py-2.5 px-3.5 bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold rounded-xl transition-all flex items-center gap-2 shadow-md border border-slate-700 cursor-pointer"
                >
                  <Eye className="w-4 h-4 text-teal-400" />
                  <span>Live Practice Demo</span>
                </button>

                <button
                  onClick={() => {
                    setIsMobileMenuOpen(false);
                    onNavigateLogin();
                  }}
                  className="w-full py-2.5 px-3.5 text-xs font-bold text-slate-300 hover:text-white hover:bg-slate-800/80 rounded-xl transition-all flex items-center gap-2 cursor-pointer border border-slate-700/60"
                >
                  <LogIn className="w-4 h-4 text-teal-400" />
                  <span>Log In to Practice</span>
                </button>

                <button
                  onClick={() => {
                    setIsMobileMenuOpen(false);
                    onNavigateRegister();
                  }}
                  className="w-full py-2.5 px-3.5 bg-gradient-to-r from-teal-500 via-cyan-500 to-blue-600 hover:from-teal-400 hover:to-blue-500 text-slate-950 text-xs font-bold rounded-xl shadow-lg shadow-cyan-500/20 transition-all flex items-center justify-center gap-2 cursor-pointer"
                >
                  <UserPlus className="w-4 h-4 text-slate-950" />
                  <span>Get Started / Create Account</span>
                </button>
              </div>
            </div>

            {/* Drawer Footer */}
            <div className="pt-4 border-t border-slate-800/80 mt-6 text-center text-[11px] text-slate-500">
              <div className="flex items-center justify-center gap-1.5 text-emerald-400 font-semibold mb-1">
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>256-Bit Encrypted • HIPAA Verified</span>
              </div>
              <p>© 2026 Office Intelligence OS</p>
            </div>
          </aside>
        </div>
      )}

      {/* 2. Hero Section (Clean High-Contrast Dark Backdrop) */}
      <section className="relative overflow-hidden pt-16 pb-24 lg:pt-24 lg:pb-32 border-b border-indigo-900/60 bg-[#040711]">
        
        {/* Subtle Ambient Radial Glow & Dark Backdrop */}
        <div className="absolute inset-0 z-0 overflow-hidden pointer-events-none">
          <div className="absolute -top-32 left-1/2 -translate-x-1/2 w-[800px] h-[450px] bg-gradient-to-r from-cyan-600/15 via-indigo-600/15 to-purple-600/15 blur-[140px] rounded-full" />
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-slate-900/50 via-[#040711] to-[#040711]" />
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          
          <div className="text-center max-w-4xl mx-auto space-y-6">
            
            {/* High-Visibility AI Status Pill with Neon Border & Pulsing Synapse */}
            <div className="inline-flex items-center gap-2.5 px-4 py-1.5 rounded-full bg-slate-950/85 text-slate-200 shadow-2xl shadow-cyan-500/25 text-xs font-semibold border border-cyan-400/50 backdrop-blur-md hover:border-cyan-300 transition-colors">
              <span className="relative flex h-2.5 w-2.5">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-gradient-to-r from-cyan-400 to-amber-400"></span>
              </span>
              <Sparkles className="w-4 h-4 text-cyan-400 animate-pulse" />
              <span className="font-bold tracking-wide text-white">Autonomous Clinical Intelligence Engine</span>
              <span className="w-1.5 h-1.5 rounded-full bg-cyan-400" />
              <span className="text-amber-300 font-mono text-[11px] font-bold">HIPAA Compliant</span>
            </div>

            {/* Main Headline with Vibrant AI Gradient Typography and Text Shadow for Readability */}
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-serif font-black text-white tracking-tight leading-[1.12] drop-shadow-[0_4px_16px_rgba(0,0,0,0.8)]">
              Super-Intelligent AI for <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-300 via-teal-200 via-amber-300 to-orange-400">Medical &amp; Surgical Practices</span>
            </h1>

            {/* Sub-headline with High-Contrast Crisp Readability */}
            <div className="bg-slate-950/60 backdrop-blur-xs p-3.5 sm:p-4 rounded-2xl border border-white/10 max-w-3xl mx-auto shadow-2xl">
              <p className="text-base sm:text-lg text-slate-100 font-normal leading-relaxed">
                Office Intelligence is the unified clinical AI operating system built for medical practices, outpatient clinics, specialty centers, and surgical suites. From autonomous email &amp; fax parsing and dynamic multi-room scheduling to automated patient check-in, EMR charting, and HIPAA-compliant communication — elevate every healthcare practice with seamless clinical precision.
              </p>
            </div>

            {/* Primary Action Buttons */}
            <div className="flex flex-wrap items-center justify-center gap-4 pt-4">
              <button
                onClick={onNavigateRegister}
                id="hero-register-cta-btn"
                className="px-6 py-3.5 bg-gradient-to-r from-cyan-400 via-teal-400 to-blue-500 hover:from-cyan-300 hover:to-blue-400 text-slate-950 font-black text-sm rounded-xl shadow-xl shadow-cyan-500/30 hover:shadow-cyan-400/50 transition-all flex items-center gap-2 cursor-pointer transform hover:-translate-y-0.5 active:scale-95"
              >
                <UserPlus className="w-4 h-4 text-slate-950" />
                <span>Register Practice & Start Setup</span>
                <ArrowRight className="w-4 h-4 ml-0.5" />
              </button>

              <button
                onClick={onNavigateLogin}
                id="hero-login-cta-btn"
                className="px-6 py-3.5 bg-slate-900/90 hover:bg-slate-800 text-white font-bold text-sm rounded-xl border border-indigo-500/40 hover:border-indigo-400 shadow-lg shadow-indigo-950/40 backdrop-blur-md transition-all flex items-center gap-2 cursor-pointer"
              >
                <LogIn className="w-4 h-4 text-cyan-400" />
                <span>Sign In to Dashboard</span>
              </button>

              {onNavigatePortal && (
                <button
                  onClick={onNavigatePortal}
                  id="hero-patient-portal-cta-btn"
                  className="px-5 py-3.5 bg-indigo-950/80 hover:bg-indigo-900/90 text-cyan-300 font-bold text-sm rounded-xl border border-cyan-500/40 hover:border-cyan-400 shadow-lg shadow-cyan-950/50 backdrop-blur-md transition-all flex items-center gap-2 cursor-pointer"
                >
                  <Users className="w-4 h-4 text-cyan-400" />
                  <span>Patient Portal (Demo Data)</span>
                </button>
              )}

              <button
                onClick={onEnterApp}
                id="hero-enter-demo-btn"
                className="px-5 py-3.5 bg-slate-800/90 hover:bg-slate-700 text-slate-300 font-semibold text-sm rounded-xl border border-slate-700 shadow-md backdrop-blur-md transition-all flex items-center gap-2 cursor-pointer"
              >
                <Eye className="w-4 h-4 text-cyan-400" />
                <span>Explore Live Demo</span>
              </button>
            </div>

            {/* Trust Badges */}
            <div className="pt-8 flex flex-wrap items-center justify-center gap-6 text-xs text-slate-400 font-medium">
              <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-900/70 border border-slate-800">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <span className="text-slate-200">HIPAA & BAA Ready</span>
              </div>
              <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-900/70 border border-slate-800">
                <Lock className="w-4 h-4 text-cyan-400" />
                <span className="text-slate-200">256-Bit TLS & At-Rest Encryption</span>
              </div>
              <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-900/70 border border-slate-800">
                <Building2 className="w-4 h-4 text-blue-400" />
                <span className="text-slate-200">Joint Commission / AAAASF Compliant</span>
              </div>
              <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-900/70 border border-slate-800">
                <CheckCircle2 className="w-4 h-4 text-teal-400" />
                <span className="text-slate-200">Surescripts & Quest Integrated</span>
              </div>
            </div>

          </div>

          {/* Hero Visual Mockup: Office Intelligence Medical OS Command Window */}
          <div className="mt-14 max-w-5xl mx-auto rounded-2xl bg-slate-900/90 border border-slate-700/80 shadow-2xl shadow-cyan-950/40 overflow-hidden backdrop-blur-md">
            
            {/* Window Header */}
            <div className="bg-slate-950 px-5 py-3.5 flex items-center justify-between border-b border-slate-800">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-rose-500/80" />
                <div className="w-3 h-3 rounded-full bg-amber-500/80" />
                <div className="w-3 h-3 rounded-full bg-emerald-500/80" />
                <span className="ml-2 text-xs font-mono text-slate-300 font-semibold">Office Intelligence Medical OS v2.4 • Active Practice Command</span>
              </div>

              <div className="flex items-center gap-3 text-xs">
                <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-medium flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                  Clinical AI Engine Live
                </span>
                <span className="text-slate-400 hidden sm:inline">Aura Vanguard Pavilion &amp; Medical Institute</span>
              </div>
            </div>

            {/* Dashboard Snapshot Content */}
            <div className="p-6 bg-slate-900/95 space-y-5">
              
              {/* Live Intelligence Banner */}
              <div className="bg-gradient-to-r from-slate-900 via-blue-950 to-indigo-950 rounded-xl p-4 text-white flex flex-wrap items-center justify-between gap-4 border border-blue-500/30 shadow-lg">
                <div className="flex items-center gap-3.5">
                  <div className="p-2.5 rounded-xl bg-teal-400/20 border border-teal-400/30 text-teal-300">
                    <Sparkles className="w-5 h-5" />
                  </div>
                  <div>
                    <h2 className="text-sm font-bold tracking-wide flex items-center gap-2 text-white">
                      Nightingale AI Morning Operational Brief
                      <span className="text-[10px] px-2 py-0.5 bg-teal-500/30 text-teal-200 border border-teal-400/30 rounded-full font-mono uppercase">Live</span>
                    </h2>
                    <p className="text-xs text-slate-300 mt-0.5">
                      18 clinical encounters scheduled today. 6 surgical cases staged across OR 1 &amp; OR 2. 98% average readiness score. E-Prescribe gateway active.
                    </p>
                  </div>
                </div>

                <button 
                  onClick={onEnterApp}
                  className="px-3.5 py-1.5 rounded-lg bg-teal-400 hover:bg-teal-300 text-slate-950 font-bold text-xs transition-colors cursor-pointer shadow-md"
                >
                  Launch Live Dashboard
                </button>
              </div>

              {/* Sample Live Patient Encounters Grid */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                
                {/* Case 1 */}
                <div className="bg-slate-950/80 p-4 rounded-xl border border-slate-800 hover:border-slate-700 transition-all space-y-2.5">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-white">Dr. Alistair Sterling</span>
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                      OR 1 • 07:00 AM
                    </span>
                  </div>
                  <div className="text-xs text-slate-200 font-semibold">
                    Danielle Vance (53F)
                  </div>
                  <div className="text-[11px] text-slate-400">
                    Bilateral Revision &amp; Tissue Reconstruction
                  </div>
                  <div className="pt-1 flex items-center justify-between text-[11px]">
                    <span className="text-emerald-400 font-bold flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5" /> 98% Readiness
                    </span>
                    <span className="px-2 py-0.5 rounded bg-blue-500/20 text-blue-300 border border-blue-500/30 font-semibold">
                      IN PRE-OP
                    </span>
                  </div>
                </div>

                {/* Case 2 */}
                <div className="bg-slate-950/80 p-4 rounded-xl border border-slate-800 hover:border-slate-700 transition-all space-y-2.5">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-white">Dr. Evelyn Vance</span>
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                      OR 1 • 08:30 AM
                    </span>
                  </div>
                  <div className="text-xs text-slate-200 font-semibold">
                    Patricia Holloway (66F)
                  </div>
                  <div className="text-[11px] text-slate-400">
                    Blepharoplasty, Fat Repositioning &amp; Ptosis
                  </div>
                  <div className="pt-1 flex items-center justify-between text-[11px]">
                    <span className="text-amber-400 font-bold flex items-center gap-1">
                      <Zap className="w-3.5 h-3.5 text-amber-400" /> Fast-Track Resolved
                    </span>
                    <span className="px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30 font-semibold">
                      CHECKED IN
                    </span>
                  </div>
                </div>

                {/* Case 3 */}
                <div className="bg-slate-950/80 p-4 rounded-xl border border-slate-800 hover:border-slate-700 transition-all space-y-2.5">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-white">Dr. Julian Mercer</span>
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                      CLINIC BAY 2 • 10:15 AM
                    </span>
                  </div>
                  <div className="text-xs text-slate-200 font-semibold">
                    Elena Rostova (36F)
                  </div>
                  <div className="text-[11px] text-slate-400">
                    Comprehensive Outpatient Consultation
                  </div>
                  <div className="pt-1 flex items-center justify-between text-[11px]">
                    <span className="text-teal-400 font-bold flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5" /> Digital Intake Ingested
                    </span>
                    <span className="px-2 py-0.5 rounded bg-teal-500/20 text-teal-300 border border-teal-500/30 font-semibold">
                      CHART READY
                    </span>
                  </div>
                </div>

              </div>

            </div>

          </div>

        </div>
      </section>

      {/* 3. Features Section: The AI-Powered Healthcare Operating System */}
      <section id="features" className="py-20 bg-[#0A0F1D] border-b border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="text-center max-w-3xl mx-auto space-y-3">
            <span className="text-xs font-bold text-teal-400 uppercase tracking-widest">
              Core Capabilities
            </span>
            <h2 className="text-3xl sm:text-4xl font-serif font-bold text-white">
              The AI Practice OS Built for Modern Healthcare
            </h2>
            <p className="text-sm text-slate-300 leading-relaxed">
              Eliminate administrative fatigue and manual chart logging with autonomous clinical intelligence engineered for medical clinics, specialist practices, and surgical pavilions.
            </p>
          </div>

          <div className="mt-14 grid grid-cols-1 md:grid-cols-3 gap-8">
            
            {/* Feature 1 */}
            <div className="bg-slate-900/70 p-6 rounded-2xl border border-slate-800 hover:border-teal-500/50 hover:shadow-xl hover:shadow-teal-500/10 transition-all space-y-4">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-tr from-teal-500 to-cyan-600 text-slate-950 flex items-center justify-center shadow-md font-bold">
                <FileText className="w-6 h-6 stroke-[2.5]" />
              </div>
              <h3 className="text-lg font-bold text-white">Longitudinal EMR &amp; Digital Charting</h3>
              <p className="text-xs text-slate-300 leading-relaxed">
                Comprehensive patient medical records with interactive intake forms, nursing care pathways, digital consent signatures, and automatic PDF export.
              </p>
              <ul className="space-y-1.5 text-xs text-slate-300 font-medium">
                <li className="flex items-center gap-2"><Check className="w-4 h-4 text-teal-400" /> Specialty operative &amp; encounter note templates</li>
                <li className="flex items-center gap-2"><Check className="w-4 h-4 text-teal-400" /> Live vital signs flowsheet &amp; PACU tracking</li>
                <li className="flex items-center gap-2"><Check className="w-4 h-4 text-teal-400" /> Clinical photography &amp; diagnostic image review</li>
              </ul>
            </div>

            {/* Feature 2 */}
            <div className="bg-slate-900/70 p-6 rounded-2xl border border-slate-800 hover:border-cyan-500/50 hover:shadow-xl hover:shadow-cyan-500/10 transition-all space-y-4">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-tr from-cyan-500 to-blue-600 text-slate-950 flex items-center justify-center shadow-md font-bold">
                <Cpu className="w-6 h-6 stroke-[2.5]" />
              </div>
              <h3 className="text-lg font-bold text-white">Autonomous Practice Oversight</h3>
              <p className="text-xs text-slate-300 leading-relaxed">
                Nightingale AI acts as an omnipresent clinical manager, identifying schedule gaps, detecting expired provider credentials, and monitoring order sets.
              </p>
              <ul className="space-y-1.5 text-xs text-slate-300 font-medium">
                <li className="flex items-center gap-2"><Check className="w-4 h-4 text-cyan-400" /> Daily Morning Brief with high-priority action items</li>
                <li className="flex items-center gap-2"><Check className="w-4 h-4 text-cyan-400" /> Continuous compliance &amp; accreditation monitoring</li>
                <li className="flex items-center gap-2"><Check className="w-4 h-4 text-cyan-400" /> Natural language chat queries across practice records</li>
              </ul>
            </div>

            {/* Feature 3 */}
            <div className="bg-slate-900/70 p-6 rounded-2xl border border-slate-800 hover:border-blue-500/50 hover:shadow-xl hover:shadow-blue-500/10 transition-all space-y-4">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-tr from-blue-500 to-indigo-600 text-slate-950 flex items-center justify-center shadow-md font-bold">
                <CreditCard className="w-6 h-6 stroke-[2.5]" />
              </div>
              <h3 className="text-lg font-bold text-white">Revenue Cycle &amp; Claim Scrubbing</h3>
              <p className="text-xs text-slate-300 leading-relaxed">
                Integrated medical billing engine supporting CMS-1500 and UB-04 EDI claims, 270/271 real-time eligibility verification, and multi-tier fee allocations.
              </p>
              <ul className="space-y-1.5 text-xs text-slate-300 font-medium">
                <li className="flex items-center gap-2"><Check className="w-4 h-4 text-blue-400" /> Pre-submission AI claim validation engine</li>
                <li className="flex items-center gap-2"><Check className="w-4 h-4 text-blue-400" /> Doctor-to-Pay, Self-Pay &amp; Insurance splits</li>
                <li className="flex items-center gap-2"><Check className="w-4 h-4 text-blue-400" /> Credit card terminal integration with line item invoices</li>
              </ul>
            </div>

          </div>

          {/* Dedicated Interactive Patient Portal Showcase Card */}
          <div className="mt-12 bg-gradient-to-r from-teal-950/70 via-slate-900/90 to-blue-950/70 p-7 rounded-3xl border border-teal-500/40 shadow-2xl relative overflow-hidden backdrop-blur-md">
            <div className="absolute -right-10 -bottom-10 w-72 h-72 bg-teal-500/10 rounded-full blur-3xl pointer-events-none" />
            <div className="flex flex-col lg:flex-row items-center justify-between gap-6 relative z-10">
              <div className="space-y-3 text-left max-w-2xl">
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-teal-500/20 text-teal-300 border border-teal-500/30 text-xs font-bold">
                  <Users className="w-3.5 h-3.5" />
                  <span>Interactive Patient Portal Connected to Main EMR</span>
                </div>
                <h3 className="text-2xl font-serif font-bold text-white">
                  Empower Patients with Seamless Self-Service, Intake Forms &amp; Direct Messaging
                </h3>
                <p className="text-xs text-slate-300 leading-relaxed">
                  Patients register using their registered email and set up a secure password to view appointment timelines, submit emailed intake forms, send HIPAA-encrypted messages to their care team, upload diagnostic records into the main OI document folder, and request new visits.
                </p>
                <div className="flex flex-wrap items-center gap-4 text-xs font-semibold text-teal-300 pt-1">
                  <span className="flex items-center gap-1.5"><CheckCircle2 className="w-4 h-4 text-teal-400" /> Digital Intake Form Submissions</span>
                  <span className="flex items-center gap-1.5"><CheckCircle2 className="w-4 h-4 text-teal-400" /> Real-time Document Sync to EMR</span>
                  <span className="flex items-center gap-1.5"><CheckCircle2 className="w-4 h-4 text-teal-400" /> Pre-loaded Fictitious Review Accounts</span>
                </div>
              </div>

              {onNavigatePortal && (
                <div className="flex flex-col items-center sm:items-end gap-3 shrink-0">
                  <button
                    onClick={onNavigatePortal}
                    id="features-patient-portal-launch-btn"
                    className="px-6 py-3.5 bg-gradient-to-r from-teal-400 via-cyan-400 to-blue-500 hover:from-teal-300 hover:to-blue-400 text-slate-950 font-bold text-sm rounded-2xl shadow-xl shadow-teal-500/20 transition-all flex items-center gap-2 cursor-pointer transform hover:-translate-y-0.5"
                  >
                    <Users className="w-4 h-4 text-slate-950" />
                    <span>Launch Patient Portal Demo</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                  <p className="text-[11px] text-slate-400 text-center sm:text-right font-medium">
                    Try sample profiles: <span className="text-slate-200">danielle.vance@example.com</span> or <span className="text-slate-200">elena.rostova@example.com</span>
                  </p>
                </div>
              )}
            </div>
          </div>

        </div>
      </section>

      {/* 4. Workflow Section: Emails, Attachments, Schedules, Communications */}
      <section id="workflows" className="py-20 bg-[#070B14] border-b border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="text-center max-w-3xl mx-auto space-y-3">
            <span className="text-xs font-bold text-teal-400 uppercase tracking-widest">
              Intelligent Healthcare Workflows
            </span>
            <h2 className="text-3xl sm:text-4xl font-serif font-bold text-white">
              How Office Intelligence Automates Daily Operations
            </h2>
            <p className="text-sm text-slate-300 leading-relaxed">
              Watch how incoming emails, medical faxes, appointment requests, diagnostic lab panels, and patient communications flow autonomously.
            </p>
          </div>

          {/* Workflow Tabs */}
          <div className="mt-10 flex flex-wrap justify-center gap-2 p-1.5 bg-slate-900/90 rounded-2xl max-w-3xl mx-auto border border-slate-800">
            <button
              onClick={() => setActiveWorkflowTab('email')}
              className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-2 ${
                activeWorkflowTab === 'email'
                  ? 'bg-blue-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Mail className="w-4 h-4 text-cyan-300" />
              <span>Email &amp; Fax Parsing</span>
            </button>

            <button
              onClick={() => setActiveWorkflowTab('schedule')}
              className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-2 ${
                activeWorkflowTab === 'schedule'
                  ? 'bg-teal-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Calendar className="w-4 h-4 text-teal-200" />
              <span>Schedule Matrix</span>
            </button>

            <button
              onClick={() => setActiveWorkflowTab('clearance')}
              className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-2 ${
                activeWorkflowTab === 'clearance'
                  ? 'bg-amber-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Zap className="w-4 h-4 text-amber-200" />
              <span>Readiness Scoring</span>
            </button>

            <button
              onClick={() => setActiveWorkflowTab('communication')}
              className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-2 ${
                activeWorkflowTab === 'communication'
                  ? 'bg-purple-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <MessageSquare className="w-4 h-4 text-purple-200" />
              <span>Secure Messaging</span>
            </button>
          </div>

          {/* Active Workflow Card (Dark Glass) */}
          <div className="mt-8 bg-slate-900/90 p-8 rounded-2xl border border-slate-800 shadow-2xl max-w-4xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-8 items-center backdrop-blur-md">
            
            <div className="lg:col-span-8 space-y-4">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-slate-800 border border-slate-700 text-teal-300 text-xs font-bold">
                <Sparkles className="w-3.5 h-3.5 text-teal-400" />
                <span>{workflowDetails[activeWorkflowTab].tag}</span>
              </div>
              <h3 className="text-2xl font-serif font-bold text-white">
                {workflowDetails[activeWorkflowTab].title}
              </h3>
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                {workflowDetails[activeWorkflowTab].description}
              </p>
              <div className="pt-2 space-y-2">
                {workflowDetails[activeWorkflowTab].bullets.map((bullet, idx) => (
                  <div key={idx} className="flex items-start gap-2 text-xs text-slate-300 font-medium">
                    <CheckCircle2 className="w-4 h-4 text-teal-400 shrink-0 mt-0.5" />
                    <span>{bullet}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="lg:col-span-4 bg-slate-950 p-6 rounded-xl border border-slate-800 space-y-4 text-center">
              <div className={`text-4xl font-bold font-mono bg-clip-text text-transparent bg-gradient-to-r ${workflowDetails[activeWorkflowTab].color}`}>
                {workflowDetails[activeWorkflowTab].metric}
              </div>
              <div className="text-xs font-semibold text-slate-300">
                {workflowDetails[activeWorkflowTab].metricLabel}
              </div>
              <div className="pt-2">
                <button
                  onClick={onEnterApp}
                  className="w-full py-2.5 bg-gradient-to-r from-teal-500 via-cyan-500 to-blue-600 hover:from-teal-400 hover:to-blue-500 text-slate-950 rounded-lg text-xs font-bold transition-all shadow-md cursor-pointer"
                >
                  Test In Live Environment
                </button>
              </div>
            </div>

          </div>

        </div>
      </section>

      {/* 5. Specialties & Practice Environments Section */}
      <section id="specialties" className="py-20 bg-[#0A0F1D] border-b border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="text-center max-w-3xl mx-auto space-y-3">
            <span className="text-xs font-bold text-cyan-400 uppercase tracking-widest">
              Versatile Healthcare Solutions
            </span>
            <h2 className="text-3xl sm:text-4xl font-serif font-bold text-white">
              Built for Every Medical &amp; Surgical Environment
            </h2>
            <p className="text-sm text-slate-300 leading-relaxed">
              From high-throughput outpatient clinics and ambulatory surgery centers to private specialist offices, Office Intelligence adapts effortlessly to your clinical specialty.
            </p>
          </div>

          <div className="mt-14 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {useCases.map((uc, i) => {
              const Icon = uc.icon;
              return (
                <div key={i} className={`bg-slate-900/70 p-6 rounded-2xl border ${uc.accent} hover:shadow-2xl transition-all space-y-4 flex flex-col justify-between`}>
                  <div className="space-y-3">
                    <div className="w-10 h-10 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-center shadow-xs">
                      <Icon className="w-5 h-5" />
                    </div>
                    <h3 className="text-base font-bold text-white">{uc.title}</h3>
                    <p className="text-xs text-slate-300 leading-relaxed">{uc.description}</p>
                  </div>
                  <div className="pt-3 border-t border-slate-800 space-y-1.5 text-[11px] text-slate-300 font-medium">
                    {uc.features.map((f, fi) => (
                      <div key={fi} className="flex items-center gap-1.5">
                        <span className="w-1.5 h-1.5 rounded-full bg-teal-400" />
                        <span>{f}</span>
                      </div>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>

        </div>
      </section>

      {/* 6. HIPAA & Enterprise Security Section */}
      <section id="hipaa" className="py-20 bg-[#070B14] border-b border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="bg-gradient-to-br from-slate-950 via-slate-900 to-blue-950 rounded-3xl p-8 sm:p-12 text-white shadow-2xl border border-teal-500/30 relative overflow-hidden">
            
            <div className="relative z-10 max-w-3xl space-y-5">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-teal-500/20 text-teal-300 text-xs font-bold border border-teal-400/30">
                <ShieldCheck className="w-4 h-4 text-teal-400" />
                <span>Enterprise Healthcare Security Standard</span>
              </div>

              <h2 className="text-3xl sm:text-4xl font-serif font-bold tracking-tight text-white">
                HIPAA-Compliant by Design. Absolute Privacy for Clinical Data.
              </h2>

              <p className="text-sm text-slate-300 leading-relaxed">
                Office Intelligence executes strict end-to-end encryption protocols, granular role-based access control (RBAC), automated Business Associate Agreements (BAAs), and immutable tamper-proof audit trails ensuring total compliance with federal and state healthcare regulations.
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-4 text-xs font-medium text-slate-200">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-teal-400" />
                  <span>256-Bit TLS in transit &amp; AES-256 at rest</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-teal-400" />
                  <span>Signed BAA automatically provisioned</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-teal-400" />
                  <span>Immutable audit logging for all ePHI access</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-teal-400" />
                  <span>Two-factor EPCS authentication for e-Prescribe</span>
                </div>
              </div>

              <div className="pt-4 flex flex-wrap items-center gap-4">
                <button
                  onClick={onNavigateRegister}
                  className="px-6 py-3 bg-gradient-to-r from-teal-400 to-cyan-500 hover:from-teal-300 hover:to-cyan-400 text-slate-950 font-bold text-xs rounded-xl transition-all shadow-lg cursor-pointer"
                >
                  Create Secure Practice Account
                </button>
                <button
                  onClick={() => alert('HIPAA Compliance Verification: Office Intelligence maintains strict adherence to HIPAA Security & Privacy Rules, ISO 27001, and SOC 2 Type II with signed BAAs for all clinical workflows.')}
                  className="px-5 py-3 bg-slate-900 hover:bg-slate-800 text-white font-semibold text-xs rounded-xl border border-slate-700 transition-all cursor-pointer"
                >
                  Download Security Whitepaper
                </button>
              </div>
            </div>

          </div>

        </div>
      </section>

      {/* 7. Practice Administration & Onboarding Teaser Section */}
      <section id="administration" className="py-16 bg-[#0A0F1D] border-b border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-8 flex flex-wrap items-center justify-between gap-6 backdrop-blur-md">
            <div className="space-y-2 max-w-2xl">
              <div className="flex items-center gap-2 text-xs font-bold text-teal-400">
                <Sliders className="w-4 h-4" />
                <span>Rapid Practice Setup</span>
              </div>
              <h2 className="text-2xl font-serif font-bold text-white">
                Configure Your Facility, Providers, and Calendar in Minutes
              </h2>
              <p className="text-xs text-slate-300 leading-relaxed">
                Define your practice profile, provider NPI credentials, appointment visit types, exam rooms, operating suites, and intake forms with unified ease.
              </p>
            </div>

            <div className="flex items-center gap-3">
              <button
                onClick={onNavigateRegister}
                className="px-5 py-3 bg-gradient-to-r from-teal-500 via-cyan-500 to-blue-600 hover:from-teal-400 hover:to-blue-500 text-slate-950 font-bold text-xs rounded-xl shadow-lg transition-all flex items-center gap-2 cursor-pointer"
              >
                <UserPlus className="w-4 h-4 text-slate-950" />
                <span>Start Practice Setup</span>
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* 8. Public Footer (Dark Theme) */}
      <footer className="bg-[#05080F] text-slate-400 py-12 border-t border-slate-800/80">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
          
          <div className="flex flex-wrap items-center justify-between gap-6 pb-8 border-b border-slate-800">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-teal-500 to-blue-600 flex items-center justify-center text-slate-950 font-bold">
                <Sparkles className="w-4 h-4 text-slate-950 stroke-[2.5]" />
              </div>
              <div>
                <span className="font-serif text-lg font-bold text-white tracking-tight">Office Intelligence</span>
                <p className="text-[11px] text-slate-400">HIPAA-Compliant AI Medical Practice Management System</p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              {onNavigatePortal && (
                <button
                  onClick={onNavigatePortal}
                  className="px-3.5 py-2 bg-teal-950/80 hover:bg-teal-900 text-teal-300 text-xs font-bold rounded-lg transition-colors cursor-pointer border border-teal-500/40 flex items-center gap-1.5"
                >
                  <Users className="w-3.5 h-3.5 text-teal-400" />
                  <span>Patient Portal</span>
                </button>
              )}
              <button
                onClick={onNavigateLogin}
                className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-slate-200 text-xs font-bold rounded-lg transition-colors cursor-pointer border border-slate-700"
              >
                Log In
              </button>
              <button
                onClick={onNavigateRegister}
                className="px-4 py-2 bg-teal-400 hover:bg-teal-300 text-slate-950 text-xs font-bold rounded-lg transition-colors cursor-pointer font-semibold"
              >
                Register Practice
              </button>
            </div>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-xs text-slate-400">
            <div className="space-y-2">
              <div className="font-bold text-slate-200 uppercase tracking-wider text-[11px]">Product</div>
              <div><a href="#features" className="hover:text-teal-300 transition-colors">EMR &amp; Electronic Forms</a></div>
              <div><a href="#workflows" className="hover:text-teal-300 transition-colors">Schedule Matrix &amp; Multi-Room</a></div>
              <div><a href="#workflows" className="hover:text-teal-300 transition-colors">Pre-Visit Readiness Scoring</a></div>
              <div><a href="#workflows" className="hover:text-teal-300 transition-colors">Email &amp; Fax OCR Parsing</a></div>
            </div>

            <div className="space-y-2">
              <div className="font-bold text-slate-200 uppercase tracking-wider text-[11px]">Administration</div>
              <div><a href="#administration" className="hover:text-teal-300 transition-colors">Configure Practice</a></div>
              <div><a href="#administration" className="hover:text-teal-300 transition-colors">Provider Roster &amp; NPI</a></div>
              <div><a href="#administration" className="hover:text-teal-300 transition-colors">User &amp; Staff Roles</a></div>
              <div><a href="#administration" className="hover:text-teal-300 transition-colors">E-Prescribe Setup</a></div>
            </div>

            <div className="space-y-2">
              <div className="font-bold text-slate-200 uppercase tracking-wider text-[11px]">Security &amp; Legal</div>
              <div><a href="#hipaa" className="hover:text-teal-300 transition-colors">HIPAA Compliance</a></div>
              <div><a href="#hipaa" className="hover:text-teal-300 transition-colors">Business Associate Agreement</a></div>
              <div><a href="#hipaa" className="hover:text-teal-300 transition-colors">Data Privacy Policy</a></div>
              <div><a href="#hipaa" className="hover:text-teal-300 transition-colors">Terms of Service</a></div>
            </div>

            <div className="space-y-2">
              <div className="font-bold text-slate-200 uppercase tracking-wider text-[11px]">Support &amp; Contact</div>
              <div><span>Priority Clinical Support: 24/7</span></div>
              <div><span>Email: support@officeintelligence.med</span></div>
              <div><span>Phone: 1 (800) 592-MED-AI</span></div>
              <div><span>Encrypted Server: US-West-2 Tier 4</span></div>
            </div>
          </div>

          <div className="pt-6 border-t border-slate-900 flex flex-wrap items-center justify-between text-[11px] text-slate-500">
            <p>© 2026 Office Intelligence Systems Inc. All rights reserved. HIPAA Certified.</p>
            <p>Engineered for Outpatient Medical Clinics, Surgical Pavilions &amp; Multi-Specialty Practices.</p>
          </div>

        </div>
      </footer>

    </div>
  );
};
