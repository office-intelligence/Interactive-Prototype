import React, { useState } from 'react';
import { X, Sparkles, Send, Bot, User, RefreshCw, AlertTriangle, ShieldCheck, Zap } from 'lucide-react';
import { PatientCase } from '../types';

interface NightingaleAIChatDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  scheduleCases: PatientCase[];
}

interface Message {
  id: string;
  sender: 'ai' | 'user';
  text: string;
  timestamp: string;
}

export const NightingaleAIChatDrawer: React.FC<NightingaleAIChatDrawerProps> = ({
  isOpen,
  onClose,
  scheduleCases,
}) => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'm1',
      sender: 'ai',
      text: "Hello Kevin. I'm **Nightingale AI**, your ASC Surgical Operations Assistant. Today you have 5 cases scheduled across OR 1 and OR 2.\n\n⚠️ **Urgent Operational Note:** Patricia DePoli's EKG is currently pending for her 8:00 AM Blepharoplasty in OR 1. I recommend fast-tracking cardiology sign-off to prevent a 25-minute turnaround delay for Sophia Diaz.\n\nHow can I assist you with today's surgical workflow?",
      timestamp: '07:05 AM',
    },
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);

  if (!isOpen) return null;

  const quickPrompts = [
    'How do we resolve Patricia DePoli EKG delay?',
    'Show OR 1 vs OR 2 turnaround times',
    'Summarize all patient drug allergies today',
    'Simulate arrival delay for 10:30 AM case',
  ];

  const handleSendMessage = async (textToSend?: string) => {
    const query = textToSend || input;
    if (!query.trim()) return;

    const userMsg: Message = {
      id: Date.now().toString(),
      sender: 'user',
      text: query,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    if (!textToSend) setInput('');
    setLoading(true);

    try {
      const res = await fetch('/api/ai/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: query,
          context: {
            casesCount: scheduleCases.length,
            cases: scheduleCases.map((c) => ({
              id: c.patientId,
              name: c.name,
              time: c.scheduledTime,
              room: c.room,
              readiness: c.readinessScore,
              status: c.readinessLevel,
              summary: c.aiSummary,
            })),
          },
        }),
      });

      const data = await res.json();
      const aiMsg: Message = {
        id: (Date.now() + 1).toString(),
        sender: 'ai',
        text: data.reply || 'No response available.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages((prev) => [...prev, aiMsg]);
    } catch (err) {
      console.error('Chat error:', err);
      const errorMsg: Message = {
        id: (Date.now() + 1).toString(),
        sender: 'ai',
        text: 'Nightingale AI is analyzing the schedule offline: Patricia DePoli (8:00 AM) requires instant EKG clearance from Beverly Hills Cardiology. Pre-op transport for Danielle Weaver (7:00 AM) is recommended immediately.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages((prev) => [...prev, errorMsg]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-stone-900/40 backdrop-blur-xs flex justify-end transition-opacity animate-in fade-in duration-200">
      <div className="w-full max-w-lg bg-white h-full shadow-2xl flex flex-col justify-between overflow-hidden">
        
        {/* Drawer Header */}
        <div className="p-4 border-b border-stone-200 bg-stone-50/90 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-amber-800 to-stone-900 text-amber-100 flex items-center justify-center shadow-xs">
              <Sparkles className="w-4 h-4 text-amber-200" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-stone-900 flex items-center gap-1.5">
                <span>Nightingale AI Assistant</span>
                <span className="w-2 h-2 rounded-full bg-sky-600 animate-pulse"></span>
              </h2>
              <p className="text-[11px] text-stone-500">
                ASC Clinical & Workflow Intelligence
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-stone-400 hover:text-stone-700 hover:bg-stone-200/60 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Message Stream */}
        <div className="p-4 space-y-4 overflow-y-auto flex-1 bg-stone-50/50">
          {messages.map((m) => (
            <div
              key={m.id}
              className={`flex gap-3 ${m.sender === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              {m.sender === 'ai' && (
                <div className="w-7 h-7 rounded-lg bg-amber-800 text-amber-100 flex items-center justify-center shrink-0 mt-0.5">
                  <Bot className="w-4 h-4" />
                </div>
              )}

              <div
                className={`p-3.5 rounded-2xl max-w-[85%] text-xs leading-relaxed ${
                  m.sender === 'user'
                    ? 'bg-amber-800 text-amber-50 rounded-tr-none font-medium'
                    : 'bg-white border border-stone-200/90 text-stone-800 rounded-tl-none shadow-2xs'
                }`}
              >
                <div className="whitespace-pre-wrap">{m.text}</div>
                <div
                  className={`text-[9px] mt-1 text-right font-mono ${
                    m.sender === 'user' ? 'text-amber-200' : 'text-stone-400'
                  }`}
                >
                  {m.timestamp}
                </div>
              </div>

              {m.sender === 'user' && (
                <div className="w-7 h-7 rounded-lg bg-stone-900 text-amber-100 flex items-center justify-center shrink-0 mt-0.5 font-bold text-xs">
                  KT
                </div>
              )}
            </div>
          ))}

          {loading && (
            <div className="flex gap-2 items-center text-xs text-amber-800 font-semibold p-2">
              <RefreshCw className="w-4 h-4 animate-spin text-amber-700" />
              <span>Nightingale AI is analyzing surgical schedule...</span>
            </div>
          )}
        </div>

        {/* Quick Prompt Chips */}
        <div className="px-4 py-2 bg-white border-t border-stone-200/80 flex items-center gap-1.5 overflow-x-auto text-[11px]">
          {quickPrompts.map((chip, i) => (
            <button
              key={i}
              onClick={() => handleSendMessage(chip)}
              className="px-2.5 py-1 rounded-full bg-amber-100/70 hover:bg-amber-200/80 text-amber-950 font-medium whitespace-nowrap transition-colors border border-amber-300 shrink-0"
            >
              {chip}
            </button>
          ))}
        </div>

        {/* Input Bar */}
        <div className="p-3 bg-white border-t border-stone-200 flex items-center gap-2">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
            placeholder="Ask Nightingale about schedule, bottlenecks, lab clearance..."
            className="flex-1 py-2 px-3 bg-stone-100 rounded-xl text-xs text-stone-800 placeholder-stone-400 focus:outline-none focus:ring-2 focus:ring-amber-500/20 focus:bg-white border border-transparent focus:border-amber-600 transition-all"
          />
          <button
            onClick={() => handleSendMessage()}
            disabled={loading || !input.trim()}
            className="p-2 rounded-xl bg-amber-800 hover:bg-amber-900 disabled:opacity-50 text-amber-50 transition-colors"
          >
            <Send className="w-4 h-4" />
          </button>
        </div>

      </div>
    </div>
  );
};
