import React from 'react';
import { Sparkles, ArrowRight } from 'lucide-react';
import { PatientCase } from '../types';

interface NightingaleBriefBannerProps {
  cases: PatientCase[];
  onActionClick: () => void;
  onFilterNeedsAttention?: () => void;
}

export const NightingaleBriefBanner: React.FC<NightingaleBriefBannerProps> = ({
  cases,
  onActionClick,
}) => {
  return (
    <div className="bg-gradient-to-br from-amber-50/90 via-stone-50 to-amber-100/40 rounded-2xl border border-amber-200/80 p-5 shadow-2xs space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-amber-200/80 pb-3">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-lg bg-amber-800 text-amber-100 flex items-center justify-center shadow-xs">
            <Sparkles className="w-4 h-4 text-amber-200" />
          </div>
          <h2 className="text-sm font-bold text-stone-900 tracking-tight flex items-center gap-1.5">
            <span>Nightingale morning brief</span>
            <span className="px-1.5 py-0.2 rounded text-[10px] font-bold bg-amber-200/80 text-amber-950">
              AI
            </span>
          </h2>
        </div>
        <span className="text-[11px] font-medium text-stone-500">07:00 AM Sync</span>
      </div>

      {/* Bullet Points */}
      <div className="space-y-2 text-xs text-stone-800 font-medium">
        <div className="flex items-start gap-2">
          <span className="w-1.5 h-1.5 rounded-full bg-amber-600 mt-1.5 shrink-0"></span>
          <span>Five procedures scheduled today across OR 1 and OR 2.</span>
        </div>
        <div className="flex items-start gap-2">
          <span className="w-1.5 h-1.5 rounded-full bg-slate-900 mt-1.5 shrink-0"></span>
          <span>Four patients fully pre-cleared for surgical transport.</span>
        </div>
        <div className="flex items-start gap-2">
          <span className="w-1.5 h-1.5 rounded-full bg-orange-600 mt-1.5 shrink-0"></span>
          <span className="font-semibold text-stone-950">
            One patient requires an EKG result and pre-op baseline photo review.
          </span>
        </div>
        <div className="flex items-start gap-2">
          <span className="w-1.5 h-1.5 rounded-full bg-amber-600 mt-1.5 shrink-0"></span>
          <span>Operating rooms are currently on schedule.</span>
        </div>
      </div>

      {/* Recommended Action Box */}
      <div className="p-3.5 bg-white/95 rounded-xl border border-amber-200/80 shadow-2xs space-y-2">
        <div className="text-[10px] font-bold tracking-wider text-amber-800/70 uppercase">
          Recommended Action
        </div>
        <p className="text-xs text-stone-900 font-medium leading-snug">
          Request Patricia DePoli's EKG result before the 8:00 AM case to prevent OR 1 cascade delay.
        </p>
        <button
          onClick={onActionClick}
          className="w-full py-1.5 px-3 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-50 text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors shadow-2xs"
        >
          <span>View day details & resolve</span>
          <ArrowRight className="w-3.5 h-3.5 text-sky-300" />
        </button>
      </div>
    </div>
  );
};
