export interface NursingHtmlForm {
  id: string;
  order: number;
  title: string;
  category: string;
  episode: string;
  status: 'Completed' | 'In Progress' | 'Signed & Verified' | 'Pending Entry';
  aiStatus: string;
  aiStatusType: 'success' | 'warning' | 'info';
  fileName: string;
  summary: string;
  htmlTemplate: string;
}

export const SURGICAL_EPISODES = [
  { id: 'ep-current', name: 'Episode #2026-0506 (May 06, 2026 - Primary Outpatient Surgery)', date: 'May 06, 2026', status: 'Active Surgical Episode' },
  { id: 'ep-prev-1', name: 'Episode #2026-0118 (Jan 18, 2026 - Pre-Op Consultation)', date: 'Jan 18, 2026', status: 'Archived Episode' },
  { id: 'ep-prev-0', name: 'Episode #2025-0912 (Sep 12, 2025 - Initial Evaluation)', date: 'Sep 12, 2025', status: 'Archived Episode' }
];

export const INITIAL_NURSING_HTML_FORMS: NursingHtmlForm[] = [
  {
    id: 'nursing-preop-checklist',
    order: 1,
    title: 'Pre-Operative Checklist and Assessment',
    category: 'Pre-Op Admission',
    episode: 'ep-current',
    status: 'Signed & Verified',
    aiStatus: 'AI Verified · Vitals & NPO Clear',
    aiStatusType: 'success',
    fileName: 'Pre_Operative_Checklist_and_Assessment.html',
    summary: 'Admission vitals, transport details, NPO status verification, pre-op checklist, and orders.',
    htmlTemplate: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Pre-Operative Checklist and Assessment</title>
  <style>
    :root { --primary:#1a365d; --accent:#2b6cb0; --border:#cbd5e0; --bg:#f7fafc; --text:#2d3748; }
    * { box-sizing:border-box; }
    body { font-family:Georgia,"Times New Roman",serif; line-height:1.5; color:var(--text); background:var(--bg); margin:0; padding:0 0 40px; }
    .page { max-width:860px; margin:20px auto; background:#fff; border:1px solid var(--border); box-shadow:0 4px 16px rgba(0,0,0,.07); padding:28px 36px 36px; }
    h1 { margin:0 0 18px; font-size:1.3rem; color:var(--primary); text-align:center; border-bottom:3px solid var(--primary); padding-bottom:10px; }
    h2 { font-size:1rem; color:var(--primary); border-bottom:2px solid var(--accent); padding-bottom:4px; margin:22px 0 12px; text-transform:uppercase; letter-spacing:.03em; }
    .grid { display:grid; grid-template-columns:1fr 1fr; gap:12px 20px; margin:8px 0; }
    .grid.three { grid-template-columns:1fr 1fr 1fr; }
    .grid.full { grid-template-columns:1fr; }
    .grid.six { grid-template-columns:repeat(6,1fr); }
    label { display:block; font-size:.78rem; font-weight:600; color:#4a5568; margin-bottom:2px; }
    input[type=text], input[type=date], input[type=time], input[type=number], select, textarea {
      width:100%; padding:7px 10px; border:1px solid var(--border); border-radius:4px; font-size:.9rem; font-family:inherit;
    }
    input:focus, select:focus, textarea:focus { outline:2px solid var(--accent); border-color:var(--accent); }
    textarea { resize:vertical; min-height:50px; }
    .check-row { display:flex; align-items:center; gap:8px; margin:5px 0; font-size:.9rem; }
    .check-row input { width:15px; height:15px; }
    .check-grid { display:grid; grid-template-columns:1fr 1fr; gap:4px 16px; }
    .yn-grid { display:grid; grid-template-columns:1fr auto auto auto; gap:4px 10px; align-items:center; font-size:.88rem; margin:6px 0; }
    .yn-grid .hdr { font-weight:600; font-size:.75rem; color:#4a5568; text-align:center; }
    .btn-row { text-align:center; margin-top:24px; }
    button { background:var(--primary); color:#fff; border:none; padding:11px 26px; font-size:.95rem; border-radius:6px; cursor:pointer; font-family:inherit; }
    button:hover { background:#2c5282; }
    button.secondary { background:#718096; margin-left:8px; }
    .powered { text-align:center; font-size:.8rem; color:#718096; margin-top:28px; padding-top:12px; border-top:1px solid var(--border); }
    @media print { body{background:#fff;} .page{box-shadow:none;border:none;margin:0;padding:12px;} button{display:none;} input,textarea,select{border:none;border-bottom:1px solid #999;border-radius:0;} }
    @media (max-width:640px){ .page{padding:16px 12px;margin:8px;} .grid,.grid.three,.grid.six,.check-grid{grid-template-columns:1fr;} }
  </style>
</head>
<body>
<form onsubmit="event.preventDefault();alert('Submitted (demo)');">
<div class="page">
  <h1>Pre-Operative Checklist and Assessment</h1>

  <div class="grid three">
    <div><label>Date</label><input type="date" name="date" required></div>
    <div><label>Patient Name</label><input type="text" name="patientName" required></div>
    <div><label>DOB</label><input type="date" name="dob"></div>
  </div>

  <div class="grid">
    <div><label>Who will provide transportation?</label><input type="text" name="transport"></div>
    <div><label>Contact #</label><input type="text" name="transportPhone"></div>
    <div><label>Who will care for you at home?</label><input type="text" name="homeCare"></div>
    <div><label>How can we reach you tomorrow?</label><input type="text" name="reachTomorrow"></div>
  </div>

  <h2>Admission Vitals</h2>
  <div class="grid six">
    <div><label>Ht</label><input type="text" name="ht"></div>
    <div><label>Wt</label><input type="text" name="wt"></div>
    <div><label>Temp</label><input type="text" name="temp"></div>
    <div><label>BP</label><input type="text" name="bp"></div>
    <div><label>RR</label><input type="text" name="rr"></div>
    <div><label>SpO₂</label><input type="text" name="spo2"></div>
  </div>

  <div class="grid full">
    <div><label>Allergies (including soy & sulfites)</label><input type="text" name="allergies"></div>
  </div>

  <h2>Checklist</h2>
  <div class="yn-grid">
    <span></span><span class="hdr">Yes</span><span class="hdr">No</span><span class="hdr">N/A</span>
    <span>H&P in chart</span>
    <input type="radio" name="hp" value="Yes"><input type="radio" name="hp" value="No"><input type="radio" name="hp" value="N/A">
    <span>Surgical consent signed</span>
    <input type="radio" name="consent" value="Yes"><input type="radio" name="consent" value="No"><input type="radio" name="consent" value="N/A">
    <span>Patient verbalized surgical site</span>
    <input type="radio" name="site" value="Yes"><input type="radio" name="site" value="No"><input type="radio" name="site" value="N/A">
    <span>NPO (time: <input type="text" name="npoTime" style="width:90px;display:inline;padding:2px 6px;">)</span>
    <input type="radio" name="npo" value="Yes"><input type="radio" name="npo" value="No"><input type="radio" name="npo" value="N/A">
    <span>Dentures / Loose teeth / Bridges</span>
    <input type="radio" name="dental" value="Yes"><input type="radio" name="dental" value="No"><input type="radio" name="dental" value="N/A">
    <span>Jewelry removed</span>
    <input type="radio" name="jewelry" value="Yes"><input type="radio" name="jewelry" value="No"><input type="radio" name="jewelry" value="N/A">
    <span>Metal implants</span>
    <input type="radio" name="metal" value="Yes"><input type="radio" name="metal" value="No"><input type="radio" name="metal" value="N/A">
    <span>Labs</span>
    <input type="radio" name="labs" value="Yes"><input type="radio" name="labs" value="No"><input type="radio" name="labs" value="N/A">
    <span>Urine HCG (Neg / Pos)</span>
    <input type="radio" name="hcg" value="Yes"><input type="radio" name="hcg" value="No"><input type="radio" name="hcg" value="N/A">
    <span>LMP documented</span>
    <input type="radio" name="lmp" value="Yes"><input type="radio" name="lmp" value="No"><input type="radio" name="lmp" value="N/A">
    <span>Contact lenses</span>
    <input type="radio" name="contacts" value="Yes"><input type="radio" name="contacts" value="No"><input type="radio" name="contacts" value="N/A">
    <span>Pre-op visit with MD</span>
    <input type="radio" name="preopMD" value="Yes"><input type="radio" name="preopMD" value="No"><input type="radio" name="preopMD" value="N/A">
    <span>Discharge instructions given</span>
    <input type="radio" name="dcInstr" value="Yes"><input type="radio" name="dcInstr" value="No"><input type="radio" name="dcInstr" value="N/A">
  </div>

  <div class="grid full" style="margin-top:12px;">
    <div><label>Medications / Herbals / OTC</label><textarea name="meds" rows="2"></textarea></div>
  </div>
  <div class="grid">
    <div><label>IV Site</label><input type="text" name="ivSite"></div>
    <div><label>Inserted by</label><input type="text" name="ivBy"></div>
  </div>

  <h2>Initial Assessment</h2>
  <div class="grid">
    <div><label>Respiratory</label><input type="text" name="resp" placeholder="WNL / Other"></div>
    <div><label>Cardiovascular</label><input type="text" name="cv" placeholder="WNL / Pulses×4 / SR / Other"></div>
    <div><label>Skin</label><input type="text" name="skin" placeholder="WNL / Cold/Clammy / Rash / Scar / Bruises"></div>
    <div><label>Color</label><input type="text" name="color" placeholder="WNL / Pale / Pink / Dusky / Ruddy"></div>
    <div><label>LOC</label><input type="text" name="loc" placeholder="A&O×4 / Disoriented / Other"></div>
    <div><label>MAF / Sensation</label><input type="text" name="maf" placeholder="WNL / Other"></div>
  </div>
  <div class="check-row">
    <span style="font-weight:600;font-size:.9rem;">Bleeding tendencies:</span>
    <label class="check-row" style="margin:0;"><input type="radio" name="bleed" value="Yes"> Yes</label>
    <label class="check-row" style="margin:0;"><input type="radio" name="bleed" value="No"> No</label>
  </div>

  <div class="grid full">
    <div><label>Nurse Notes</label><textarea name="nurseNotes" rows="3"></textarea></div>
  </div>

  <h2>Pre-Operative Orders</h2>
  <div class="check-grid">
    <label class="check-row"><input type="checkbox" name="ord_zofran"> Emend 40 mg PO</label>
<label class="check-row"><input type="checkbox" name="ord_journavx"> Journavx 50 mg PO</label>
    <label class="check-row"><input type="checkbox" name="ord_versed"> Valium <input type="text" name="versedDose" style="width:60px;display:inline;padding:2px 6px;"> mg PO</label>
    <label class="check-row"><input type="checkbox" name="ord_afrin"> Afrin 3 puffs each nare ×2</label>
    <label class="check-row"><input type="checkbox" name="ord_celebrex"> Celebrex 200 mg PO </label>
  </div>
  <div class="grid">
    <div><label>Other order</label><input type="text" name="ordOther"></div>
    <div><label>Administered by</label><input type="text" name="adminBy"></div>
    <div><label>V/O Dr.</label><input type="text" name="voDr"></div>
    <div><label>Time given</label><input type="time" name="timeGiven"></div>
  </div>

  <div class="grid" style="margin-top:16px;">
    <div><label>Nurse / MA Signature</label><input type="text" name="sig" required></div>
    <div><label>Date / Time</label><input type="text" name="sigDT"></div>
  </div>

  <div class="btn-row">
    <button type="submit">Submit</button>
    <button type="button" class="secondary" onclick="window.print()">Print</button>
  </div>
  <div class="powered">Powered by Office Intelligence</div>
</div>
</form>
</body>
</html>`
  },
  {
    id: 'nursing-perioperative-assessment',
    order: 2,
    title: 'Peri-Operative Nursing Assessment',
    category: 'Intra-Op Nursing',
    episode: 'ep-current',
    status: 'Signed & Verified',
    aiStatus: 'AI Verified · Surgical Team Logged',
    aiStatusType: 'success',
    fileName: 'Peri_Operative_Nursing_Assessment.html',
    summary: 'Identification checks, site/consent verification, OR timing log, surgical team, and anesthesia details.',
    htmlTemplate: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Peri-Operative Nursing Assessment</title>
  <style>
    :root { --primary:#1a365d; --accent:#2b6cb0; --border:#cbd5e0; --bg:#f7fafc; --text:#2d3748; }
    * { box-sizing:border-box; }
    body { font-family:Georgia,"Times New Roman",serif; line-height:1.45; color:var(--text); background:var(--bg); margin:0; padding:0 0 40px; }
    .page { max-width:900px; margin:20px auto; background:#fff; border:1px solid var(--border); box-shadow:0 4px 16px rgba(0,0,0,.07); padding:24px 30px 32px; }
    h1 { margin:0 0 14px; font-size:1.25rem; color:var(--primary); text-align:center; border-bottom:3px solid var(--primary); padding-bottom:10px; }
    h2 { font-size:.95rem; color:var(--primary); border-bottom:2px solid var(--accent); padding-bottom:3px; margin:16px 0 8px; text-transform:uppercase; }
    .grid { display:grid; grid-template-columns:1fr 1fr; gap:10px 16px; }
    .grid.three { grid-template-columns:1fr 1fr 1fr; }
    .grid.full { grid-template-columns:1fr; }
    label { display:block; font-size:.75rem; font-weight:600; color:#4a5568; margin-bottom:1px; }
    input[type=text], input[type=date], input[type=time], select, textarea { width:100%; padding:6px 8px; border:1px solid var(--border); border-radius:3px; font-size:.88rem; font-family:inherit; }
    .check-row { display:flex; align-items:center; gap:6px; margin:3px 0; font-size:.86rem; }
    .check-row input { width:14px; height:14px; }
    .check-grid { display:grid; grid-template-columns:1fr 1fr; gap:2px 12px; }
    .btn-row { text-align:center; margin-top:18px; }
    button { background:var(--primary); color:#fff; border:none; padding:10px 24px; font-size:.9rem; border-radius:6px; cursor:pointer; font-family:inherit; }
    button.secondary { background:#718096; margin-left:8px; }
    .powered { text-align:center; font-size:.8rem; color:#718096; margin-top:22px; padding-top:10px; border-top:1px solid var(--border); }
    @media print { body{background:#fff;} .page{box-shadow:none;border:none;} button{display:none;} }
  </style>
</head>
<body>
<form onsubmit="event.preventDefault();alert('Submitted (demo)');">
<div class="page">
  <h1>Peri-Operative Nursing Assessment & Documentation</h1>
  <div class="grid three">
    <div><label>Patient Name</label><input type="text" name="patientName" required></div>
    <div><label>Date</label><input type="date" name="date" required></div>
    <div><label>SS# / MRN</label><input type="text" name="mrn"></div>
  </div>

  <h2>Pre-Op Assessment</h2>
  <div class="grid three">
    <div>
      <label>Patient Identification</label>
      <label class="check-row"><input type="checkbox" name="id_verbal"> Verbal</label>
      <label class="check-row"><input type="checkbox" name="id_chart"> Chart</label>
      <label class="check-row"><input type="checkbox" name="id_band"> ID Band</label>
      <label class="check-row"><input type="checkbox" name="id_photo"> Photo / Other</label>
    </div>
    <div>
      <label>Verification of Procedure / Location</label>
      <label class="check-row"><input type="checkbox" name="ver_oriented"> Oriented</label>
      <label class="check-row"><input type="checkbox" name="ver_verbal"> Verbal</label>
      <label class="check-row"><input type="checkbox" name="ver_consent"> Consent Form</label>
    </div>
    <div>
      <label>NPO after midnight</label>
      <label class="check-row"><input type="radio" name="npo" value="Yes"> Yes</label>
      <label class="check-row"><input type="radio" name="npo" value="No"> No</label>
      <label>Chart verified</label>
      <label class="check-row"><input type="checkbox" name="chart_hp"> H&P</label>
      <label class="check-row"><input type="checkbox" name="chart_lab"> Lab</label>
    </div>
  </div>

  <div class="grid">
    <div>
      <label>Mental / Emotional Status</label>
      <div class="check-grid">
        <label class="check-row"><input type="checkbox" name="me_alert"> Alert</label>
        <label class="check-row"><input type="checkbox" name="me_oriented"> Oriented</label>
        <label class="check-row"><input type="checkbox" name="me_sleepy"> Sleepy</label>
        <label class="check-row"><input type="checkbox" name="me_agitated"> Agitated</label>
        <label class="check-row"><input type="checkbox" name="me_disoriented"> Disoriented</label>
        <label class="check-row"><input type="checkbox" name="me_apprehensive"> Apprehensive</label>
      </div>
    </div>
    <div>
      <label>Limitations</label>
      <div class="check-grid">
        <label class="check-row"><input type="checkbox" name="lim_none"> None</label>
        <label class="check-row"><input type="checkbox" name="lim_auditory"> Auditory</label>
        <label class="check-row"><input type="checkbox" name="lim_visual"> Visual</label>
        <label class="check-row"><input type="checkbox" name="lim_mobility"> Mobility</label>
        <label class="check-row"><input type="checkbox" name="lim_language"> Language</label>
      </div>
      <label style="margin-top:6px;">Interpreter</label>
      <input type="text" name="interpreter">
    </div>
  </div>

  <div class="grid">
    <div><label>Personal Items / Disposition</label><input type="text" name="personalItems"></div>
    <div><label>Comfort Measures</label><input type="text" name="comfort" placeholder="Pillow, warm blanket, etc."></div>
  </div>
  <div class="grid full">
    <div><label>Allergies</label><input type="text" name="allergies" placeholder="NKA or list"></div>
  </div>

  <h2>Times & Team</h2>
  <div class="grid three">
    <div><label>In Room</label><input type="time" name="inRoom"></div>
    <div><label>Anesthesia Start</label><input type="time" name="anesStart"></div>
    <div><label>Surgery Start</label><input type="time" name="surgStart"></div>
    <div><label>Out of Room</label><input type="time" name="outRoom"></div>
    <div><label>Anesthesia Stop</label><input type="time" name="anesStop"></div>
    <div><label>Surgery Stop</label><input type="time" name="surgStop"></div>
  </div>
  <div class="grid">
    <div><label>Surgeon</label><input type="text" name="surgeon"></div>
    <div><label>Anesthesiologist</label><input type="text" name="anesthesiologist"></div>
    <div><label>Assistants</label><input type="text" name="assistants"></div>
    <div><label>Scrub / Circulating Nurses</label><input type="text" name="nurses"></div>
  </div>

  <h2>Anesthesia & Procedure</h2>
  <div class="check-grid">
    <label class="check-row"><input type="checkbox" name="anes_ga"> General</label>
    <label class="check-row"><input type="checkbox" name="anes_lma"> LMA / Mask</label>
    <label class="check-row"><input type="checkbox" name="anes_ett"> Intubation</label>
    <label class="check-row"><input type="checkbox" name="anes_spinal"> Spinal</label>
    <label class="check-row"><input type="checkbox" name="anes_epidural"> Epidural</label>
    <label class="check-row"><input type="checkbox" name="anes_mac"> MAC</label>
    <label class="check-row"><input type="checkbox" name="anes_block"> Blocks / Local</label>
  </div>
  <div class="grid">
    <div><label>Pre-Op Diagnosis</label><input type="text" name="preopDx"></div>
    <div><label>Surgical Procedure</label><input type="text" name="procedure"></div>
    <div><label>Post-Op Diagnosis</label><input type="text" name="postopDx" placeholder="Same as pre-op or specify"></div>
    <div><label>Specimens</label><input type="text" name="specimens"></div>
  </div>

  <div class="grid" style="margin-top:12px;">
    <div><label>Nurse Signature</label><input type="text" name="sig" required></div>
    <div><label>Date / Time</label><input type="text" name="sigDT"></div>
  </div>

  <div class="btn-row">
    <button type="submit">Submit</button>
    <button type="button" class="secondary" onclick="window.print()">Print</button>
  </div>
  <div class="powered">Powered by Office Intelligence</div>
</div>
</form>
</body>
</html>`
  },
  {
    id: 'nursing-surgical-checklist',
    order: 3,
    title: 'Comprehensive Surgical Checklist',
    category: 'Safety Protocol',
    episode: 'ep-current',
    status: 'Signed & Verified',
    aiStatus: 'AI Verified · AORN 4-Stage Timeout Passed',
    aiStatusType: 'success',
    fileName: 'Comprehensive_Surgical_Checklist.html',
    summary: '4-phase WHO/AORN surgical safety protocol: Pre-Procedure, Sign-In, Time-Out, and Sign-Out.',
    htmlTemplate: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Comprehensive Surgical Checklist</title>
  <style>
    :root { --primary:#1a365d; --accent:#2b6cb0; --border:#cbd5e0; --bg:#f7fafc; --text:#2d3748; }
    * { box-sizing:border-box; }
    body { font-family:Georgia,"Times New Roman",serif; line-height:1.45; color:var(--text); background:var(--bg); margin:0; padding:0 0 40px; }
    .page { max-width:920px; margin:20px auto; background:#fff; border:1px solid var(--border); box-shadow:0 4px 16px rgba(0,0,0,.07); padding:24px 28px 32px; }
    h1 { margin:0 0 16px; font-size:1.25rem; color:var(--primary); text-align:center; border-bottom:3px solid var(--primary); padding-bottom:10px; }
    h2 { font-size:.95rem; color:#fff; background:var(--primary); padding:6px 10px; margin:16px 0 8px; }
    .grid { display:grid; grid-template-columns:1fr 1fr; gap:8px 16px; }
    .grid.full { grid-template-columns:1fr; }
    label { display:block; font-size:.75rem; font-weight:600; color:#4a5568; margin-bottom:1px; }
    input[type=text], input[type=date], textarea { width:100%; padding:6px 8px; border:1px solid var(--border); border-radius:3px; font-size:.88rem; font-family:inherit; }
    .check-row { display:flex; align-items:center; gap:6px; margin:4px 0; font-size:.88rem; }
    .check-row input { width:14px; height:14px; }
    .col4 { display:grid; grid-template-columns:repeat(4,1fr); gap:10px; }
    .phase { border:1px solid var(--border); border-radius:4px; padding:10px; background:#f8fafc; }
    .btn-row { text-align:center; margin-top:20px; }
    button { background:var(--primary); color:#fff; border:none; padding:10px 24px; font-size:.9rem; border-radius:6px; cursor:pointer; font-family:inherit; }
    button.secondary { background:#718096; margin-left:8px; }
    .powered { text-align:center; font-size:.8rem; color:#718096; margin-top:24px; padding-top:10px; border-top:1px solid var(--border); }
    @media print { body{background:#fff;} .page{box-shadow:none;border:none;} button{display:none;} }
    @media (max-width:700px){ .col4{grid-template-columns:1fr;} }
  </style>
</head>
<body>
<form onsubmit="event.preventDefault();alert('Submitted (demo)');">
<div class="page">
  <h1>Comprehensive Surgical Checklist</h1>
  <div class="grid">
    <div><label>Patient Name</label><input type="text" name="patientName" required></div>
    <div><label>Date</label><input type="date" name="date" required></div>
  </div>

  <div class="col4" style="margin-top:14px;">
    <!-- PRE-PROCEDURE -->
    <div class="phase">
      <h2 style="margin-top:0;">Pre-Procedure Check-In</h2>
      <p style="font-size:.8rem;margin:0 0 6px;">In Holding Area</p>
      <label class="check-row"><input type="checkbox" name="pre_id"> Identity confirmed</label>
      <label class="check-row"><input type="checkbox" name="pre_proc"> Procedure & site confirmed</label>
      <label class="check-row"><input type="checkbox" name="pre_consent"> Consent(s)</label>
      <label class="check-row"><input type="checkbox" name="pre_marked"> Site marked</label>
      <label class="check-row"><input type="checkbox" name="pre_hp"> H&P present</label>
      <label class="check-row"><input type="checkbox" name="pre_anes"> Preanesthesia assessment</label>
      <label class="check-row"><input type="checkbox" name="pre_tests"> Diagnostic / radiologic results</label>
      <label class="check-row"><input type="checkbox" name="pre_blood"> Blood products</label>
      <label class="check-row"><input type="checkbox" name="pre_equip"> Special equipment / implants</label>
      <label class="check-row"><input type="checkbox" name="pre_te"> Thromboembolism prophylaxis</label>
      <label class="check-row"><input type="checkbox" name="pre_normo"> Normothermia measures</label>
    </div>

    <!-- SIGN-IN -->
    <div class="phase">
      <h2 style="margin-top:0;">Sign-In</h2>
      <p style="font-size:.8rem;margin:0 0 6px;">Before Induction of Anesthesia</p>
      <label class="check-row"><input type="checkbox" name="si_confirm"> ID / procedure / site / consent</label>
      <label class="check-row"><input type="checkbox" name="si_marked"> Site marked</label>
      <label class="check-row"><input type="checkbox" name="si_allergy"> Patient allergies reviewed</label>
      <label class="check-row"><input type="checkbox" name="si_airway"> Difficult airway / aspiration risk assessed</label>
      <label class="check-row"><input type="checkbox" name="si_blood"> Risk of blood loss >500 ml</label>
      <label class="check-row"><input type="checkbox" name="si_safety"> Anesthesia safety check completed</label>
      <label class="check-row"><input type="checkbox" name="si_brief"> Team briefing completed</label>
    </div>

    <!-- TIME-OUT -->
    <div class="phase">
      <h2 style="margin-top:0;">Time-Out</h2>
      <p style="font-size:.8rem;margin:0 0 6px;">Before Skin Incision</p>
      <label class="check-row"><input type="checkbox" name="to_intro"> Team members introduced</label>
      <label class="check-row"><input type="checkbox" name="to_confirm"> ID / procedure / site / consent</label>
      <label class="check-row"><input type="checkbox" name="to_marked"> Site marked & visible</label>
      <label class="check-row"><input type="checkbox" name="to_images"> Relevant images displayed</label>
      <label class="check-row"><input type="checkbox" name="to_equip"> Equipment concerns addressed</label>
      <label class="check-row"><input type="checkbox" name="to_crit"> Critical steps / duration / EBL stated</label>
      <label class="check-row"><input type="checkbox" name="to_abx"> Antibiotic within 1 hr before incision</label>
      <label class="check-row"><input type="checkbox" name="to_sterile"> Sterilization indicators confirmed</label>
    </div>

    <!-- SIGN-OUT -->
    <div class="phase">
      <h2 style="margin-top:0;">Sign-Out</h2>
      <p style="font-size:.8rem;margin:0 0 6px;">Before Patient Leaves OR</p>
      <label class="check-row"><input type="checkbox" name="so_name"> Name of operative procedure</label>
      <label class="check-row"><input type="checkbox" name="so_counts"> Sponge / sharp / instrument counts</label>
      <label class="check-row"><input type="checkbox" name="so_spec"> Specimens identified & labeled</label>
      <label class="check-row"><input type="checkbox" name="so_equip"> Equipment problems noted</label>
      <div style="margin-top:8px;">
        <label>Key concerns for recovery</label>
        <textarea name="so_recovery" rows="3"></textarea>
      </div>
    </div>
  </div>

  <div class="grid" style="margin-top:16px;">
    <div><label>RN Signature</label><input type="text" name="rnSig"></div>
    <div><label>Anesthesia Signature</label><input type="text" name="anesSig"></div>
    <div><label>Surgeon Signature</label><input type="text" name="surgSig"></div>
    <div><label>Date / Time</label><input type="text" name="dt"></div>
  </div>

  <div class="btn-row">
    <button type="submit">Submit</button>
    <button type="button" class="secondary" onclick="window.print()">Print</button>
  </div>
  <div class="powered">Powered by Office Intelligence</div>
</div>
</form>
</body>
</html>`
  },
  {
    id: 'nursing-doctors-standing-orders',
    order: 4,
    title: 'Doctors Standing Orders',
    category: 'Physician Orders',
    episode: 'ep-current',
    status: 'Signed & Verified',
    aiStatus: 'AI Verified · Orders Executed',
    aiStatusType: 'success',
    fileName: 'Doctors_Standing_Orders.html',
    summary: 'Postoperative routine orders, pain management, wound care, IV discharge criteria, and follow-up.',
    htmlTemplate: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Doctors Standing Orders</title>
  <style>
    :root { --primary:#1a365d; --accent:#2b6cb0; --border:#cbd5e0; --bg:#f7fafc; --text:#2d3748; }
    * { box-sizing:border-box; }
    body { font-family:Georgia,"Times New Roman",serif; line-height:1.5; color:var(--text); background:var(--bg); margin:0; padding:0 0 40px; }
    .page { max-width:860px; margin:20px auto; background:#fff; border:1px solid var(--border); box-shadow:0 4px 16px rgba(0,0,0,.07); padding:28px 36px 36px; }
    h1 { margin:0 0 6px; font-size:1.3rem; color:var(--primary); text-align:center; }
    h2 { font-size:1rem; color:var(--primary); border-bottom:2px solid var(--accent); padding-bottom:4px; margin:22px 0 12px; text-transform:uppercase; }
    .grid { display:grid; grid-template-columns:1fr 1fr; gap:12px 20px; margin:8px 0; }
    .grid.full { grid-template-columns:1fr; }
    label { display:block; font-size:.78rem; font-weight:600; color:#4a5568; margin-bottom:2px; }
    input[type=text], input[type=date], textarea { width:100%; padding:7px 10px; border:1px solid var(--border); border-radius:4px; font-size:.9rem; font-family:inherit; }
    input:focus, textarea:focus { outline:2px solid var(--accent); border-color:var(--accent); }
    textarea { resize:vertical; min-height:48px; }
    .check-row { display:flex; align-items:flex-start; gap:8px; margin:7px 0; font-size:.92rem; }
    .check-row input { width:15px; height:15px; margin-top:3px; flex-shrink:0; }
    .btn-row { text-align:center; margin-top:24px; }
    button { background:var(--primary); color:#fff; border:none; padding:11px 26px; font-size:.95rem; border-radius:6px; cursor:pointer; font-family:inherit; }
    button:hover { background:#2c5282; }
    button.secondary { background:#718096; margin-left:8px; }
    .powered { text-align:center; font-size:.8rem; color:#718096; margin-top:28px; padding-top:12px; border-top:1px solid var(--border); }
    @media print { body{background:#fff;} .page{box-shadow:none;border:none;} button{display:none;} }
  </style>
</head>
<body>
<form onsubmit="event.preventDefault();alert('Submitted (demo)');">
<div class="page">
  <h1>Doctors Standing Orders</h1>
  <div class="grid">
    <div><label>Patient Name</label><input type="text" name="patientName" required></div>
    <div><label>Date</label><input type="date" name="date" required></div>
  </div>


  <h2>Postoperative Orders</h2>
  <label class="check-row"><input type="checkbox" name="post_vs"> Routine Vital Signs</label>
<label class="check-row"><input type="checkbox" name="post_pn"> Pain Control Per Anesthesia</label>
<label class="check-row"><input type="checkbox" name="post_wd"> Routine Wound Checks</label>
<label class="check-row"><input type="checkbox" name="post_ic"> Apply Ice</label>
  <label class="check-row"><input type="checkbox" name="post_dciv"> D/C IV when patient tolerating PO fluids without nausea and stable</label>
  <div class="grid full">
    <div><label>Take-home meds</label><input type="text" name="takeHome"></div>
  </div>
  <label class="check-row"><input type="checkbox" name="post_dcanes"> D/C patient per Anesthesiologist</label>
  <div class="grid full">
    <div><label>Additional Orders</label><textarea name="addOrders" rows="2"></textarea></div>
    <div><label>Office follow-up</label><input type="text" name="fup"></div>
  </div>

  <div class="grid" style="margin-top:20px;">
    <div><label>M.D. Signature</label><input type="text" name="mdSig" required></div>
    <div><label>Date</label><input type="date" name="mdDate" required></div>
    <div><label>Noted by</label><input type="text" name="notedBy"></div>
  </div>

  <div class="btn-row">
    <button type="submit">Submit</button>
    <button type="button" class="secondary" onclick="window.print()">Print</button>
  </div>
  <div class="powered">Powered by Office Intelligence</div>
</div>
</form>
</body>
</html>`
  },
  {
    id: 'nursing-brief-op-summary',
    order: 5,
    title: 'Brief Operative Summary Note',
    category: 'Surgical Summary',
    episode: 'ep-current',
    status: 'Signed & Verified',
    aiStatus: 'AI Verified · EBL & Fluid Logged',
    aiStatusType: 'success',
    fileName: 'Brief_Operative_Summary_Note.html',
    summary: 'Pre-op diagnosis, procedure, surgical team, EBL, fluid balance, drains, and complications summary.',
    htmlTemplate: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Brief Operative Summary Note</title>
  <style>
    :root { --primary:#1a365d; --accent:#2b6cb0; --border:#cbd5e0; --bg:#f7fafc; --text:#2d3748; }
    * { box-sizing:border-box; }
    body { font-family:Georgia,"Times New Roman",serif; line-height:1.5; color:var(--text); background:var(--bg); margin:0; padding:0 0 40px; }
    .page { max-width:800px; margin:20px auto; background:#fff; border:1px solid var(--border); box-shadow:0 4px 16px rgba(0,0,0,.07); padding:28px 36px 36px; }
    h1 { margin:0 0 18px; font-size:1.3rem; color:var(--primary); text-align:center; border-bottom:3px solid var(--primary); padding-bottom:10px; }
    .row { margin:12px 0; }
    label { display:block; font-size:.8rem; font-weight:600; color:#4a5568; margin-bottom:3px; }
    input[type=text], input[type=date], textarea { width:100%; padding:8px 10px; border:1px solid var(--border); border-radius:4px; font-size:.92rem; font-family:inherit; }
    input:focus, textarea:focus { outline:2px solid var(--accent); border-color:var(--accent); }
    textarea { resize:vertical; min-height:48px; }
    .grid { display:grid; grid-template-columns:1fr 1fr; gap:12px 18px; }
    .btn-row { text-align:center; margin-top:24px; }
    button { background:var(--primary); color:#fff; border:none; padding:11px 26px; font-size:.95rem; border-radius:6px; cursor:pointer; font-family:inherit; }
    button.secondary { background:#718096; margin-left:8px; }
    .powered { text-align:center; font-size:.8rem; color:#718096; margin-top:28px; padding-top:12px; border-top:1px solid var(--border); }
    @media print { body{background:#fff;} .page{box-shadow:none;border:none;} button{display:none;} }
  </style>
</head>
<body>
<form onsubmit="event.preventDefault();alert('Submitted (demo)');">
<div class="page">
  <h1>Brief Operative Summary Note</h1>
  <div class="grid">
    <div><label>Patient Name</label><input type="text" name="patientName" required></div>
    <div><label>Date</label><input type="date" name="date" required></div>
  </div>

  <div class="row"><label>1. Pre-op diagnosis</label><input type="text" name="preopDx"></div>
  <div class="row"><label>2. Surgical Procedure(s)</label><input type="text" name="procedure"></div>
  <div class="row"><label>3. Surgeon(s)</label><input type="text" name="surgeons"></div>
  <div class="row"><label>4. Type of Anesthesia</label><input type="text" name="anesthesia"></div>
  <div class="grid">
    <div><label>5. EBL</label><input type="text" name="ebl"></div>
    <div><label>Tourniquet Time</label><input type="text" name="tourniquet"></div>
    <div><label>6. Fluid In</label><input type="text" name="fluidIn"></div>
    <div><label>Fluid Out</label><input type="text" name="fluidOut"></div>
  </div>
  <div class="row"><label>7. Drains</label><input type="text" name="drains"></div>
  <div class="row"><label>8. Complications</label><textarea name="complications" rows="2"></textarea></div>
  <div class="row"><label>9. Additional Notes</label><textarea name="notes" rows="3"></textarea></div>

  <div class="grid" style="margin-top:16px;">
    <div><label>Surgeon Signature</label><input type="text" name="sig" required></div>
    <div><label>Date</label><input type="date" name="sigDate" required></div>
  </div>

  <div class="btn-row">
    <button type="submit">Submit</button>
    <button type="button" class="secondary" onclick="window.print()">Print</button>
  </div>
  <div class="powered">Powered by Office Intelligence</div>
</div>
</form>
</body>
</html>`
  },
  {
    id: 'nursing-recovery-room-record',
    order: 6,
    title: 'Recovery Room Record (PACU)',
    category: 'Post-Op Recovery',
    episode: 'ep-current',
    status: 'Signed & Verified',
    aiStatus: 'AI Verified · Aldrete Score 10/10',
    aiStatusType: 'success',
    fileName: 'Recovery_Room_Record.html',
    summary: 'PACU recovery record, Aldrete scores (LOC, Respiration, SaO2, BP, Extremities), meds, and discharge readiness.',
    htmlTemplate: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Recovery Room Record</title>
  <style>
    :root { --primary:#1a365d; --accent:#2b6cb0; --border:#cbd5e0; --bg:#f7fafc; --text:#2d3748; }
    * { box-sizing:border-box; }
    body { font-family:Georgia,"Times New Roman",serif; line-height:1.45; color:var(--text); background:var(--bg); margin:0; padding:0 0 40px; }
    .page { max-width:900px; margin:20px auto; background:#fff; border:1px solid var(--border); box-shadow:0 4px 16px rgba(0,0,0,.07); padding:24px 30px 32px; }
    h1 { margin:0 0 14px; font-size:1.25rem; color:var(--primary); text-align:center; border-bottom:3px solid var(--primary); padding-bottom:10px; }
    h2 { font-size:.95rem; color:var(--primary); border-bottom:2px solid var(--accent); padding-bottom:3px; margin:16px 0 8px; text-transform:uppercase; }
    .grid { display:grid; grid-template-columns:1fr 1fr; gap:10px 16px; }
    .grid.three { grid-template-columns:1fr 1fr 1fr; }
    .grid.four { grid-template-columns:1fr 1fr 1fr 1fr; }
    .grid.full { grid-template-columns:1fr; }
    label { display:block; font-size:.75rem; font-weight:600; color:#4a5568; margin-bottom:1px; }
    input[type=text], input[type=date], input[type=time], input[type=number], textarea { width:100%; padding:6px 8px; border:1px solid var(--border); border-radius:3px; font-size:.88rem; font-family:inherit; }
    table { width:100%; border-collapse:collapse; font-size:.85rem; margin:8px 0; }
    th, td { border:1px solid var(--border); padding:5px 6px; text-align:center; }
    th { background:#edf2f7; font-size:.75rem; }
    td input { border:none; padding:4px; text-align:center; }
    .btn-row { text-align:center; margin-top:18px; }
    button { background:var(--primary); color:#fff; border:none; padding:10px 24px; font-size:.9rem; border-radius:6px; cursor:pointer; font-family:inherit; }
    button.secondary { background:#718096; margin-left:8px; }
    .powered { text-align:center; font-size:.8rem; color:#718096; margin-top:22px; padding-top:10px; border-top:1px solid var(--border); }
    @media print { body{background:#fff;} .page{box-shadow:none;border:none;} button{display:none;} }
  </style>
</head>
<body>
<form onsubmit="event.preventDefault();alert('Submitted (demo)');">
<div class="page">
  <h1>Recovery Room Record</h1>
  <div class="grid three">
    <div><label>Patient Name</label><input type="text" name="patientName" required></div>
    <div><label>M.D.</label><input type="text" name="md"></div>
    <div><label>Date</label><input type="date" name="date" required></div>
    <div><label>Surgery</label><input type="text" name="surgery"></div>
    <div><label>Anesthesia</label><input type="text" name="anesthesia"></div>
    <div><label>Time of Arrival</label><input type="time" name="arrival"></div>
  </div>
  <div class="grid full"><div><label>Allergies</label><input type="text" name="allergies"></div></div>

  <h2>Aldrete Score</h2>
  <table>
    <thead>
      <tr><th></th><th>Admit</th><th>+30 min</th><th>+60 min</th><th>Discharge</th></tr>
    </thead>
    <tbody>
      <tr><td style="text-align:left;">LOC (Awake=2, Arouses=1, Unresponsive=0)</td>
        <td><input type="text" name="loc_a"></td><td><input type="text" name="loc_30"></td><td><input type="text" name="loc_60"></td><td><input type="text" name="loc_dc"></td></tr>
      <tr><td style="text-align:left;">Respiration</td>
        <td><input type="text" name="resp_a"></td><td><input type="text" name="resp_30"></td><td><input type="text" name="resp_60"></td><td><input type="text" name="resp_dc"></td></tr>
      <tr><td style="text-align:left;">SaO₂</td>
        <td><input type="text" name="sao2_a"></td><td><input type="text" name="sao2_30"></td><td><input type="text" name="sao2_60"></td><td><input type="text" name="sao2_dc"></td></tr>
      <tr><td style="text-align:left;">B/P</td>
        <td><input type="text" name="bp_a"></td><td><input type="text" name="bp_30"></td><td><input type="text" name="bp_60"></td><td><input type="text" name="bp_dc"></td></tr>
      <tr><td style="text-align:left;">Extremities</td>
        <td><input type="text" name="ext_a"></td><td><input type="text" name="ext_30"></td><td><input type="text" name="ext_60"></td><td><input type="text" name="ext_dc"></td></tr>
      <tr><td style="text-align:left;font-weight:600;">Total</td>
        <td><input type="text" name="tot_a"></td><td><input type="text" name="tot_30"></td><td><input type="text" name="tot_60"></td><td><input type="text" name="tot_dc"></td></tr>
    </tbody>
  </table>

  <h2>Post-Operative Orders & Meds</h2>
  <div class="grid">
    <div><label>IV rate</label><input type="text" name="ivRate" placeholder="cc/hr"></div>
    <div><label>O₂</label><input type="text" name="o2" placeholder="L / mask / NC"></div>
    <div><label>PRN Pain</label><input type="text" name="prnPain"></div>
    <div><label>PRN Nausea</label><input type="text" name="prnNausea"></div>
    <div><label>Additional Orders</label><input type="text" name="addOrders"></div>
    <div><label>Meds Given</label><input type="text" name="medsGiven"></div>
  </div>

  <h2>Initial Assessment</h2>
  <div class="grid three">
    <div><label>Vitals / Color / LOC</label><input type="text" name="initVS"></div>
    <div><label>Respiratory</label><input type="text" name="initResp"></div>
    <div><label>Dressing / Skin</label><input type="text" name="initDress"></div>
  </div>
  <div class="grid">
    <div><label>Drains (type / location / output)</label><input type="text" name="drains"></div>
    <div><label>I/O (OR In / PACU In-Out)</label><input type="text" name="io"></div>
  </div>

  <div class="grid full"><div><label>Nurse’s Notes</label><textarea name="notes" rows="3"></textarea></div></div>

  <h2>Discharge</h2>
  <div class="grid three">
    <div><label>Awake / Oriented</label><input type="text" name="dcOriented"></div>
    <div><label>B/P · P · R · SaO₂</label><input type="text" name="dcVS"></div>
    <div><label>Voided / Stable</label><input type="text" name="dcVoid"></div>
  </div>
  <div class="grid">
    <div><label>Discharged to</label><input type="text" name="dcTo" placeholder="wheelchair / car / etc."></div>
    <div><label>Valuables received by</label><input type="text" name="valuables"></div>
    <div><label>Post-Op instructions reviewed</label><input type="text" name="instrReviewed"></div>
    <div><label>Time discharged</label><input type="time" name="dcTime"></div>
  </div>
  <div class="grid">
    <div><label>RN Signature</label><input type="text" name="rnSig" required></div>
    <div><label>M.D. Signature (discharge)</label><input type="text" name="mdSig"></div>
  </div>

  <div class="btn-row">
    <button type="submit">Submit</button>
    <button type="button" class="secondary" onclick="window.print()">Print</button>
  </div>
  <div class="powered">Powered by Office Intelligence</div>
</div>
</form>
</body>
</html>`
  },
  {
    id: 'nursing-postop-instructions',
    order: 7,
    title: 'Post Operative Instructions',
    category: 'Discharge & Care',
    episode: 'ep-current',
    status: 'Signed & Verified',
    aiStatus: 'AI Verified · Patient & Caregiver Signed',
    aiStatusType: 'success',
    fileName: 'Post_Operative_Instructions.html',
    summary: 'Comprehensive 16-point post-operative patient instructions and signed nurse/caregiver/patient acknowledgments.',
    htmlTemplate: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Post Operative Instructions</title>
  <style>
    :root { --primary:#1a365d; --accent:#2b6cb0; --border:#cbd5e0; --bg:#f7fafc; --text:#2d3748; }
    * { box-sizing:border-box; }
    body { font-family:Georgia,"Times New Roman",serif; line-height:1.55; color:var(--text); background:var(--bg); margin:0; padding:0 0 40px; }
    .page { max-width:800px; margin:20px auto; background:#fff; border:1px solid var(--border); box-shadow:0 4px 16px rgba(0,0,0,.07); padding:28px 36px 36px; }
    h1 { margin:0 0 16px; font-size:1.3rem; color:var(--primary); text-align:center; border-bottom:3px solid var(--primary); padding-bottom:10px; }
    ol { padding-left:1.4em; margin:8px 0 16px; }
    li { margin-bottom:8px; font-size:.92rem; }
    .grid { display:grid; grid-template-columns:1fr 1fr; gap:12px 18px; margin:10px 0; }
    .grid.three { grid-template-columns:1fr 1fr 1fr; }
    label { display:block; font-size:.78rem; font-weight:600; color:#4a5568; margin-bottom:2px; }
    input[type=text], input[type=date], input[type=time] { width:100%; padding:7px 10px; border:1px solid var(--border); border-radius:4px; font-size:.9rem; font-family:inherit; }
    .notice { background:#edf2f7; border-left:4px solid var(--accent); padding:10px 14px; margin:14px 0; font-size:.9rem; }
    .btn-row { text-align:center; margin-top:22px; }
    button { background:var(--primary); color:#fff; border:none; padding:11px 26px; font-size:.95rem; border-radius:6px; cursor:pointer; font-family:inherit; }
    button.secondary { background:#718096; margin-left:8px; }
    .powered { text-align:center; font-size:.8rem; color:#718096; margin-top:26px; padding-top:12px; border-top:1px solid var(--border); }
    @media print { body{background:#fff;} .page{box-shadow:none;border:none;} button{display:none;} }
  </style>
</head>
<body>
<form onsubmit="event.preventDefault();alert('Submitted (demo)');">
<div class="page">
  <h1>Post Operative Instructions</h1>
  <div class="grid">
    <div><label>Patient Name</label><input type="text" name="patientName" required></div>
    <div><label>Procedure Date</label><input type="date" name="procDate"></div>
  </div>

  <ol>
    <li>Follow the specific instructions pertaining to your procedure which was given to you by your physician.</li>
    <li>Follow the instructions for your medications. Do not take any on an empty stomach. Take all the antibiotic medication until completed, or otherwise instructed. Do not consume alcoholic beverages while taking any medication.</li>
    <li>Pain medication may cause constipation. It is advisable to drink plenty of fluids and include roughage in your diet. An over-the-counter stool softener may also help prevent constipation.</li>
    <li>Do not take aspirin or ibuprofen containing medications unless directed by your physician.</li>
    <li>Avoid strenuous exercise (anything that will increase your heart rate, including sexual activity) until advised otherwise by your doctor.</li>
    <li>For the first 48 hours do not do anything that will cause straining (bending over, straining with bowel movements, etc.).</li>
    <li>Avoid overheated rooms or direct sunlight, as this increases likelihood of swelling.</li>
    <li>Do not drive, make important decisions, or sign legal documents while taking pain medications.</li>
    <li>Do not vacuum or lift heavy objects, including children.</li>
    <li>Keep your surgical dressing clean and dry. Do not remove dressings or garments until seen at your first post-operative appointment or advised otherwise.</li>
    <li>If you have surgical drains, empty the reservoirs as needed and record output. You and your caregiver will be shown how to do this prior to leaving.</li>
    <li>Call your surgeon if you have signs of infection (redness, swelling, unusual drainage, fever greater than 101°F). Surgeon contact: <input type="text" name="surgeonPhone" style="width:160px;display:inline;padding:2px 6px;"></li>
    <li>If you have undergone gynecological procedures: nothing in the vagina until cleared by your surgeon (tampons, douches, intercourse). Vaginal bleeding should not exceed two pads in an hour.</li>
    <li>Your postoperative follow-up appointment is: <input type="text" name="fupAppt" style="width:220px;display:inline;padding:2px 6px;"></li>
    <li>You should have a responsible adult with you for 24 hours post-operatively.</li>
    <li>Call 911 or go to the nearest Emergency Department for: difficult breathing, persistent dizziness, severe bleeding, very pale or grayish color, or difficulty awakening.</li>
  </ol>

  <div class="notice">Signing below acknowledges that you have received and understand these instructions.</div>

  <div class="grid three">
    <div>
      <label>Nurse Name / Signature</label>
      <input type="text" name="nurseSig" required>
      <label style="margin-top:6px;">Date & Time</label>
      <input type="text" name="nurseDT">
    </div>
    <div>
      <label>Responsible Adult Name / Signature</label>
      <input type="text" name="adultSig" required>
      <label style="margin-top:6px;">Date & Time</label>
      <input type="text" name="adultDT">
    </div>
    <div>
      <label>Patient Signature</label>
      <input type="text" name="patientSig" required>
      <label style="margin-top:6px;">Date & Time</label>
      <input type="text" name="patientDT">
    </div>
  </div>

  <div class="btn-row">
    <button type="submit">Submit</button>
    <button type="button" class="secondary" onclick="window.print()">Print</button>
  </div>
  <div class="powered">Powered by Office Intelligence</div>
</div>
</form>
</body>
</html>`
  },
  {
    id: 'nursing-consent-operation',
    order: 8,
    title: 'Consent to Procedure',
    category: 'Consent & Agreements',
    episode: 'ep-current',
    status: 'Signed & Verified',
    aiStatus: 'AI Verified · Patient Signed & Witnessed',
    aiStatusType: 'success',
    fileName: 'Consent_to_Procedure.html',
    summary: 'Surgical authorization, pathologist tissue permission, blood transfusion consent, photo/video consent, anesthesia consent, and discharge requirements.',
    htmlTemplate: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Consent to Procedure</title>
  <style>
    :root { --primary:#1a365d; --accent:#2b6cb0; --border:#cbd5e0; --bg:#f7fafc; --text:#2d3748; }
    * { box-sizing:border-box; }
    body { font-family:Georgia,"Times New Roman",serif; line-height:1.55; color:var(--text); background:var(--bg); margin:0; padding:0 0 40px; }
    .page { max-width:860px; margin:20px auto; background:#fff; border:1px solid var(--border); box-shadow:0 4px 16px rgba(0,0,0,.07); padding:28px 36px 36px; }
    h1 { margin:0 0 16px; font-size:1.2rem; color:var(--primary); text-align:center; border-bottom:3px solid var(--primary); padding-bottom:10px; line-height:1.35; }
    h2 { font-size:1rem; color:var(--primary); border-bottom:2px solid var(--accent); padding-bottom:4px; margin:20px 0 10px; text-transform:uppercase; letter-spacing:.03em; }
    p, li { font-size:.9rem; margin:7px 0; }
    ol { padding-left:1.35em; }
    .grid { display:grid; grid-template-columns:1fr 1fr; gap:12px 20px; margin:10px 0; }
    .grid.full { grid-template-columns:1fr; }
    label { display:block; font-size:.78rem; font-weight:600; color:#4a5568; margin-bottom:2px; }
    input[type=text], input[type=date], input[type=time], textarea {
      width:100%; padding:7px 10px; border:1px solid var(--border); border-radius:4px; font-size:.9rem; font-family:inherit;
    }
    input:focus, textarea:focus { outline:2px solid var(--accent); border-color:var(--accent); }
    textarea { resize:vertical; min-height:48px; }
    .auth-line { display:flex; flex-wrap:wrap; align-items:center; gap:8px; font-size:.9rem; margin:12px 0; }
    .auth-line input { width:auto; min-width:180px; flex:1; }
    .btn-row { text-align:center; margin-top:22px; }
    button { background:var(--primary); color:#fff; border:none; padding:11px 26px; font-size:.95rem; border-radius:6px; cursor:pointer; font-family:inherit; }
    button:hover { background:#2c5282; }
    button.secondary { background:#718096; margin-left:8px; }
    .powered { text-align:center; font-size:.8rem; color:#718096; margin-top:26px; padding-top:12px; border-top:1px solid var(--border); }
    @media print { body{background:#fff;} .page{box-shadow:none;border:none;} button{display:none;} input,textarea{border:none;border-bottom:1px solid #999;border-radius:0;} }
    @media (max-width:640px){ .page{padding:16px 12px;} .grid{grid-template-columns:1fr;} }
  </style>
</head>
<body>
<form onsubmit="event.preventDefault();alert('Submitted (demo)');">
<div class="page">
  <h1>Consent to Procedure</h1>

  <div class="grid">
    <div><label>Patient Name</label><input type="text" name="patientName" required></div>
    <div><label>Date</label><input type="date" name="date" required></div>
  </div>

  <div class="auth-line">
    <span>I hereby authorize and direct Doctor</span>
    <input type="text" name="doctor" placeholder="Surgeon name" style="min-width:160px;">
    <span>and if necessary assistant of his/her choice to perform the following operation on me:</span>
  </div>
  <div class="grid full">
    <div><label>Procedure(s)</label><textarea name="procedure" rows="2" required placeholder="Describe the operation(s)"></textarea></div>
  </div>

  <ol>
    <li>I understand that during the operation unforeseen conditions may make it necessary to perform additional or different therapeutic procedures than those stated above. This may also include pathology or radiology services. I hereby authorize the above-named physician to perform or authorize those procedures or services deemed necessary or advisable in his/her professional judgment.</li>
    <li>I certify that my physician has informed me of the nature and character of the proposed treatment, of the anticipated results of the proposed treatment, of the possible alternative forms of treatment, and the recognized serious possible risks, complications, and the anticipated benefits involved in the proposed treatment and in the alternative forms of treatment, including non-treatment.</li>
    <li>I give my permission for any tissue surgically removed to be examined by a pathologist and to be retained or disposed of by the laboratory according to accustomed and required standards of practice.</li>
    <li>I agree to the transfusion of blood and/or blood products if deemed necessary by my physician.</li>
    <li>I consent to photograph, filming, or videotaping of the treatment or procedure for educational/diagnostic use.</li>
    <li>I consent that equipment technicians and specialists may be present during my surgery as deemed necessary by my physician.</li>
    <li>I understand that my insurance may deny payment for any lab work. I agree to be personally and fully responsible for payment in that event.</li>
  </ol>

  <h2>Anesthesia Consent</h2>
  <p>I understand that the operating surgeon will be occupied solely with the surgery and the administration of anesthesia is an independent function. I consent to the administration of anesthesia and/or drugs as may be necessary to be administered by or under the direction of an anesthesiologist. I understand that all anesthetics involve risks and complications from both known and unknown causes, including, but not limited to, sore throat, lip injury, dental damage, stroke, heart attack, muscle ache, pneumonia, nerve damage, bleeding, infection, intraoperative awareness, and death. I understand these risks and complications, and my questions have been answered. I wish to proceed.</p>

  <h2>Personal Items and Valuables</h2>
  <ol>
    <li>I will remove and take responsibility for all prosthetic devices, such as glasses, contact lenses, and dental prosthesis if so directed.</li>
    <li>I shall not hold the facility liable for loss or damage to any money or article of value unless that item has been placed in safekeeping.</li>
  </ol>

  <h2>Discharge Instructions</h2>
  <ol>
    <li>If I have received an anesthetic other than simple local infiltration, I will not drive, drink alcoholic beverages, sign legal documents, or take full responsibility for the care of another individual for a period of 24 hours following my surgery.</li>
    <li>I understand that I must have a responsible adult escort to take me home after surgery.</li>
  </ol>

  <p style="font-size:.9rem;margin-top:16px;">The following undersigned certifies that she/he has read the foregoing, and is the patient, or is duly authorized by the patient as the patient’s agent to execute the above and accept its terms.</p>

  <div class="grid">
    <div><label>Date</label><input type="date" name="sigDate" required></div>
    <div><label>Time</label><input type="time" name="sigTime"></div>
    <div><label>Signature (Patient or legally responsible person)</label><input type="text" name="patientSig" required placeholder="Type full name as signature"></div>
    <div><label>Witness</label><input type="text" name="witness" placeholder="Witness signature"></div>
  </div>

  <div class="btn-row">
    <button type="submit">Submit</button>
    <button type="button" class="secondary" onclick="window.print()">Print</button>
  </div>
  <div class="powered">Powered by Office Intelligence</div>
</div>
</form>
</body>
</html>`
  },
  {
    id: 'nursing-patient-consent-anesthesia',
    order: 9,
    title: 'Consent for Anesthesia',
    category: 'Anesthesia Consent',
    episode: 'ep-current',
    status: 'Signed & Verified',
    aiStatus: 'AI Verified · Anesthesia Informed Consent',
    aiStatusType: 'success',
    fileName: 'Consent_for_Anesthesia.html',
    summary: 'Comprehensive definitions for General, Regional, IV Sedation, and Local anesthesia, risks and complications disclosure, and patient/anesthesiologist signatures.',
    htmlTemplate: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Consent for Anesthesia</title>
  <style>
    :root { --primary:#1a365d; --accent:#2b6cb0; --border:#cbd5e0; --bg:#f7fafc; --text:#2d3748; }
    * { box-sizing:border-box; }
    body { font-family:Georgia,"Times New Roman",serif; line-height:1.55; color:var(--text); background:var(--bg); margin:0; padding:0 0 40px; }
    .page { max-width:860px; margin:20px auto; background:#fff; border:1px solid var(--border); box-shadow:0 4px 16px rgba(0,0,0,.07); padding:28px 36px 36px; }
    h1 { margin:0 0 16px; font-size:1.3rem; color:var(--primary); text-align:center; border-bottom:3px solid var(--primary); padding-bottom:10px; }
    h2 { font-size:1.05rem; color:var(--primary); margin:18px 0 8px; }
    h3 { font-size:.92rem; color:var(--accent); margin:12px 0 4px; }
    p, li { font-size:.9rem; margin:6px 0; }
    ol, ul { padding-left:1.35em; }
    .grid { display:grid; grid-template-columns:1fr 1fr; gap:12px 20px; margin:12px 0; }
    label { display:block; font-size:.78rem; font-weight:600; color:#4a5568; margin-bottom:2px; }
    input[type=text], input[type=date] { width:100%; padding:7px 10px; border:1px solid var(--border); border-radius:4px; font-size:.9rem; font-family:inherit; }
    input:focus { outline:2px solid var(--accent); border-color:var(--accent); }
    .notice { background:#edf2f7; border-left:4px solid var(--accent); padding:12px 14px; margin:14px 0; font-size:.9rem; }
    .btn-row { text-align:center; margin-top:22px; }
    button { background:var(--primary); color:#fff; border:none; padding:11px 26px; font-size:.95rem; border-radius:6px; cursor:pointer; font-family:inherit; }
    button:hover { background:#2c5282; }
    button.secondary { background:#718096; margin-left:8px; }
    .powered { text-align:center; font-size:.8rem; color:#718096; margin-top:26px; padding-top:12px; border-top:1px solid var(--border); }
    @media print { body{background:#fff;} .page{box-shadow:none;border:none;} button{display:none;} input{border:none;border-bottom:1px solid #999;border-radius:0;} }
    @media (max-width:640px){ .page{padding:16px 12px;} .grid{grid-template-columns:1fr;} }
  </style>
</head>
<body>
<form onsubmit="event.preventDefault();alert('Submitted (demo)');">
<div class="page">
  <h1>Consent for Anesthesia</h1>

  <div class="grid">
    <div><label>Patient Name</label><input type="text" name="patientName" required></div>
    <div><label>Date of Procedure</label><input type="date" name="procDate"></div>
  </div>

  <h2>Types of Anesthesia and Definitions</h2>

  <h3>A. General Anesthesia</h3>
  <ol>
    <li><strong>Endotracheal anesthesia:</strong> Anesthetic and respiratory gases are passed through a tube placed in the trachea (windpipe) via the nose or mouth.</li>
    <li><strong>Mask anesthesia:</strong> Gases are passed through a mask which covers the nose and mouth.</li>
  </ol>

  <h3>B. Regional Anesthesia</h3>
  <ol>
    <li><strong>Epidural anesthesia:</strong> A small catheter is inserted into the epidural (spinal) space so that the anesthetizing agents may be given to prolong the duration of anesthesia.</li>
    <li><strong>Spinal anesthesia:</strong> The anesthetic agent is injected into the spinal subarachnoid space to produce loss of sensation.</li>
    <li><strong>Nerve Blocks:</strong> Local anesthetizing agents are injected into specified areas to inhibit nerve transmission.</li>
  </ol>

  <h3>C. IV Sedation</h3>
  <p>Includes the monitoring of at least blood pressure, oxygenation, pulse and mental state, supplementing sedation and analgesia as needed.</p>

  <h3>D. Local Anesthesia</h3>
  <ol>
    <li><strong>Local anesthesia:</strong> Anesthetizing agents are injected or infiltrated directly into a small area of the body, for example, the surgical site.</li>
    <li><strong>Topical anesthesia:</strong> Surface anesthesia is produced by direct application of anesthetizing agents on skin or mucous membranes.</li>
  </ol>

  <h2>Risks and Complications</h2>
  <p>May include but are not limited to: allergic/adverse reaction, aspiration, backache, brain damage, coma, dental injury, headache, inability to reverse the effects of anesthesia, infection, localized swelling and/or redness, muscle aches, nausea, ophthalmic (eye) injury, pain, paralysis, pneumonia, position nerve injury, recall of sound/noise/speech by others, seizures, sore throat, wrong site for injection of anesthesia, and death.</p>

  <div class="notice">
    <strong>I understand that:</strong>
    <ul>
      <li>I will need anesthesia services for the surgical procedures and that the type of anesthesia to be used will depend upon the procedure and my physical condition.</li>
      <li>Anesthesia is a specialty medical service which manages patients who are rendered unconscious or with diminished response to pain and stress during the course of a medical, surgical, or obstetrical procedure.</li>
      <li>During the course of the surgical procedure, conditions may require additional or different anesthetic monitoring or techniques, and I ask that the anesthesiologist provide any other necessary services for my benefit and well-being.</li>
      <li>In addition to the anesthesiologist whose name appears on this document, my anesthetic services may be provided by other anesthesiologists or by certified registered nurse anesthetists (CRNA) under the medical direction of the anesthesiologist.</li>
      <li>No guarantees have been made by anyone regarding the anesthesia services which I am agreeing to have.</li>
    </ul>
    <p style="margin-top:10px;">I have been given the opportunity to ask questions about my anesthesia and I feel that I have sufficient information to give this informed consent. I agree to the administration of the anesthesia prescribed for me. I recognize the alternative to acceptance of anesthesia might be no anesthesia for the procedure.</p>
  </div>

  <div class="grid">
    <div><label>Patient Signature</label><input type="text" name="patientSig" required placeholder="Type full name as signature"></div>
    <div><label>Date</label><input type="date" name="patientDate" required></div>
    <div><label>Anesthesiologist Signature</label><input type="text" name="anesSig" placeholder="Type full name as signature"></div>
    <div><label>Date</label><input type="date" name="anesDate"></div>
  </div>

  <div class="btn-row">
    <button type="submit">Submit</button>
    <button type="button" class="secondary" onclick="window.print()">Print</button>
  </div>
  <div class="powered">Powered by Office Intelligence</div>
</div>
</form>
</body>
</html>`
  },
  {
    id: 'nursing-anesthesia-preop-evaluation',
    order: 10,
    title: 'Anesthesia Pre-Op Evaluation',
    category: 'Anesthesia Assessment',
    episode: 'ep-current',
    status: 'Signed & Verified',
    aiStatus: 'AI Verified · Anesthesiologist Cleared',
    aiStatusType: 'success',
    fileName: 'Anesthesia_PreOp_Evaluation.html',
    summary: 'Anesthesia pre-operative medical evaluation, vital signs, physical exam, airway classification, ASA status, and plan.',
    htmlTemplate: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Anesthesia Pre-Op Evaluation</title>
  <style>
    :root { --primary:#1a365d; --accent:#2b6cb0; --border:#cbd5e0; --bg:#f7fafc; --text:#2d3748; }
    * { box-sizing:border-box; }
    body { font-family:Georgia,"Times New Roman",serif; line-height:1.5; color:var(--text); background:var(--bg); margin:0; padding:0 0 40px; }
    .page { max-width:860px; margin:20px auto; background:#fff; border:1px solid var(--border); box-shadow:0 4px 16px rgba(0,0,0,.07); padding:28px 36px 36px; }
    h1 { margin:0 0 4px; font-size:1.3rem; color:var(--primary); text-align:center; }
    .sub { text-align:center; font-size:.85rem; color:#718096; margin-bottom:14px; padding-bottom:10px; border-bottom:3px solid var(--primary); }
    h2 { font-size:.95rem; color:var(--primary); border-bottom:2px solid var(--accent); padding-bottom:3px; margin:16px 0 8px; text-transform:uppercase; }
    .grid { display:grid; grid-template-columns:1fr 1fr; gap:10px 18px; margin:8px 0; }
    .grid.three { grid-template-columns:1fr 1fr 1fr; }
    .grid.five { grid-template-columns:repeat(5,1fr); }
    .grid.full { grid-template-columns:1fr; }
    label { display:block; font-size:.78rem; font-weight:600; color:#4a5568; margin-bottom:2px; }
    input[type=text], input[type=date], textarea { width:100%; padding:7px 10px; border:1px solid var(--border); border-radius:4px; font-size:.9rem; font-family:inherit; }
    input:focus, textarea:focus { outline:2px solid var(--accent); border-color:var(--accent); }
    textarea { resize:vertical; min-height:48px; }
    .check-row { display:flex; align-items:center; gap:7px; margin:5px 0; font-size:.9rem; }
    .check-row input { width:15px; height:15px; }
    .pe-line { font-size:.88rem; margin:4px 0; color:#4a5568; }
    .btn-row { text-align:center; margin-top:20px; }
    button { background:var(--primary); color:#fff; border:none; padding:11px 26px; font-size:.95rem; border-radius:6px; cursor:pointer; font-family:inherit; }
    button.secondary { background:#718096; margin-left:8px; }
    .powered { text-align:center; font-size:.8rem; color:#718096; margin-top:24px; padding-top:12px; border-top:1px solid var(--border); }
    @media print { body{background:#fff;} .page{box-shadow:none;border:none;} button{display:none;} }
    @media (max-width:640px){ .grid,.grid.three,.grid.five{grid-template-columns:1fr;} }
  </style>
</head>
<body>
<form onsubmit="event.preventDefault();alert('Submitted (demo)');">
<div class="page">
  <h1>Anesthesia Pre-Op Evaluation</h1>
  <p class="sub">For Anesthesiologist Use Only</p>

  <div class="grid">
    <div><label>Patient Name</label><input type="text" name="patientName" required></div>
    <div><label>Date</label><input type="date" name="date" required></div>
  </div>

  <div class="grid five">
    <div><label>BP</label><input type="text" name="bp" placeholder="/"></div>
    <div><label>P</label><input type="text" name="p"></div>
    <div><label>R</label><input type="text" name="r"></div>
    <div><label>T</label><input type="text" name="t"></div>
    <div><label>O₂ Sat</label><input type="text" name="o2sat"></div>
  </div>
  <div class="grid">
    <div><label>Height</label><input type="text" name="height"></div>
    <div><label>Weight</label><input type="text" name="weight"></div>
  </div>

  <h2>History</h2>
  <label class="check-row"><input type="checkbox" name="pmh_none"> NO PAST MEDICAL HISTORY — No history of cardiac, pulmonary, liver, or kidney disease</label>
  <div class="grid full"><div><label>PMH (if any)</label><input type="text" name="pmh"></div></div>

  <label class="check-row"><input type="checkbox" name="psh_none"> NO PAST SURGICAL HISTORY — No history of any surgical or anesthesia-related complications</label>
  <label class="check-row"><input type="checkbox" name="ga_none"> NO COMPLICATIONS WITH GA</label>
  <div class="grid full"><div><label>PSH / Anesthesia complications (if any)</label><input type="text" name="psh"></div></div>

  <label class="check-row"><input type="checkbox" name="nkda"> NKDA</label>
  <div class="grid full"><div><label>Allergies (if any)</label><input type="text" name="allergies"></div></div>

  <label class="check-row"><input type="checkbox" name="nomeds"> NO MEDICATIONS</label>
  <div class="grid full"><div><label>Medications (if any)</label><input type="text" name="meds"></div></div>

  <h2>Physical Exam</h2>
  <p class="pe-line"><strong>General:</strong> Well-Developed, Well-nourished, In No Acute Distress, Alert and Oriented.</p>
  <p class="pe-line"><strong>Head &amp; Neck:</strong> Normocephalic, Atraumatic, Neck Supple with No Adenopathy or Masses, Thyroid Midline.</p>
  <p class="pe-line"><strong>Teeth:</strong> Grossly Intact</p>
  <div style="margin:8px 0;">
    <span style="font-size:.88rem;font-weight:600;">Airway Class:</span>
    <label class="check-row" style="display:inline-flex;margin-left:12px;"><input type="radio" name="airway" value="I"> I</label>
    <label class="check-row" style="display:inline-flex;margin-left:10px;"><input type="radio" name="airway" value="II"> II</label>
    <label class="check-row" style="display:inline-flex;margin-left:10px;"><input type="radio" name="airway" value="III"> III</label>
    <label class="check-row" style="display:inline-flex;margin-left:10px;"><input type="radio" name="airway" value="IV"> IV</label>
  </div>
  <p class="pe-line"><strong>Heart:</strong> Regular Rate and Rhythm, S1, S2, No Murmurs</p>
  <p class="pe-line"><strong>Lungs:</strong> Clear To Auscultation, No Wheezes, Rales or Rhonchi</p>
  <p class="pe-line"><strong>Abdomen:</strong> Soft and Non-tender</p>
  <p class="pe-line"><strong>Extremities:</strong> Atraumatic, Without any Tenderness, Deformity, Swelling or Erythema</p>
  <p class="pe-line"><strong>Neuro:</strong> Alert and Oriented. Motor and Sensory Grossly Intact.</p>
  <div class="grid full"><div><label>Notes / Exceptions</label><textarea name="examNotes" rows="2"></textarea></div></div>

  <h2>Plan</h2>
  <div style="display:flex;flex-wrap:wrap;gap:12px 20px;margin:8px 0;">
    <label class="check-row"><input type="checkbox" name="plan_ga"> GA</label>
    <label class="check-row"><input type="checkbox" name="plan_mac"> MAC</label>
    <label class="check-row"><input type="checkbox" name="plan_et"> ET</label>
    <label class="check-row"><input type="checkbox" name="plan_lma"> LMA</label>
  </div>
  <div style="margin:8px 0;">
    <span style="font-size:.88rem;font-weight:600;">ASA:</span>
    <label class="check-row" style="display:inline-flex;margin-left:12px;"><input type="radio" name="asa" value="I"> I</label>
    <label class="check-row" style="display:inline-flex;margin-left:10px;"><input type="radio" name="asa" value="II"> II</label>
    <label class="check-row" style="display:inline-flex;margin-left:10px;"><input type="radio" name="asa" value="III"> III</label>
    <label class="check-row" style="display:inline-flex;margin-left:10px;"><input type="radio" name="asa" value="E"> E</label>
  </div>

  <label class="check-row"><input type="checkbox" name="noChange"> Upon examination, there have been no changes in the patient’s condition since the H&amp;P was completed. The condition requiring this procedure is still present. An assessment relating to anesthetic risk and procedural risk was performed.</label>
  <label class="check-row"><input type="checkbox" name="updateNote"> This update note reflects changes in the patient’s status since the H&amp;P during the first visit of this series was performed.</label>

  <div class="grid" style="margin-top:16px;">
    <div><label>Doctor Signature</label><input type="text" name="sig" required></div>
    <div><label>Date</label><input type="date" name="sigDate" required></div>
  </div>

  <div class="btn-row">
    <button type="submit">Submit</button>
    <button type="button" class="secondary" onclick="window.print()">Print</button>
  </div>
  <div class="powered">Powered by Office Intelligence</div>
</div>
</form>
</body>
</html>`
  },
  {
    id: 'nursing-liposuction-treatment-areas',
    order: 11,
    title: 'Liposuction Treatment Areas',
    category: 'Intra-Op Nursing',
    episode: 'ep-current',
    status: 'Signed & Verified',
    aiStatus: 'AI Verified · Intra-Op Infiltration & Suction Log',
    aiStatusType: 'success',
    fileName: 'Liposuction_Treatment_Areas.html',
    summary: 'Surgical documentation of tumescent infiltration volume, lipoaspirate output, and fat graft volume per anatomical area.',
    htmlTemplate: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Liposuction Treatment Areas</title>
  <style>
    :root { --primary:#1a365d; --accent:#2b6cb0; --border:#cbd5e0; --bg:#f7fafc; --text:#2d3748; }
    * { box-sizing:border-box; }
    body { font-family:Georgia,"Times New Roman",serif; line-height:1.45; color:var(--text); background:var(--bg); margin:0; padding:0 0 40px; }
    .page { max-width:900px; margin:20px auto; background:#fff; border:1px solid var(--border); box-shadow:0 4px 16px rgba(0,0,0,.07); padding:24px 30px 32px; }
    h1 { margin:0 0 14px; font-size:1.25rem; color:var(--primary); text-align:center; border-bottom:3px solid var(--primary); padding-bottom:10px; }
    h2 { font-size:.95rem; color:var(--primary); margin:16px 0 8px; text-transform:uppercase; }
    .grid { display:grid; grid-template-columns:1fr 1fr; gap:10px 18px; margin:8px 0; }
    .grid.three { grid-template-columns:1fr 1fr 1fr; }
    label { display:block; font-size:.75rem; font-weight:600; color:#4a5568; margin-bottom:1px; }
    input[type=text], input[type=date], input[type=number], textarea { width:100%; padding:6px 8px; border:1px solid var(--border); border-radius:3px; font-size:.88rem; font-family:inherit; }
    table { width:100%; border-collapse:collapse; font-size:.85rem; margin:8px 0 16px; }
    th, td { border:1px solid var(--border); padding:5px 6px; }
    th { background:#edf2f7; font-size:.75rem; text-align:left; }
    td input { border:none; padding:4px; width:100%; }
    .btn-row { text-align:center; margin-top:18px; }
    button { background:var(--primary); color:#fff; border:none; padding:10px 24px; font-size:.9rem; border-radius:6px; cursor:pointer; font-family:inherit; }
    button.secondary { background:#718096; margin-left:8px; }
    .powered { text-align:center; font-size:.8rem; color:#718096; margin-top:22px; padding-top:10px; border-top:1px solid var(--border); }
    @media print { body{background:#fff;} .page{box-shadow:none;border:none;} button{display:none;} }
  </style>
</head>
<body>
<form onsubmit="event.preventDefault();alert('Submitted (demo)');">
<div class="page">
  <h1>Liposuction Treatment Areas</h1>

  <div class="grid three">
    <div><label>Patient</label><input type="text" name="patient" required></div>
    <div><label>Surgeon</label><input type="text" name="surgeon"></div>
    <div><label>Date of Service</label><input type="date" name="dos"></div>
  </div>

  <h2>Anterior / Front</h2>
  <table>
    <thead>
      <tr><th>Area</th><th>Side</th><th>Tumescent In (ml)</th><th>Volume Out (ml)</th><th>Graft (ml)</th></tr>
    </thead>
    <tbody>
      <tr><td>Chin / Neck</td><td>—</td><td><input type="number" name="chin_in" step="any"></td><td><input type="number" name="chin_out" step="any"></td><td><input type="number" name="chin_graft" step="any"></td></tr>
      <tr><td>Upper Arm</td><td>R</td><td><input type="number" name="uarm_r_in" step="any"></td><td><input type="number" name="uarm_r_out" step="any"></td><td><input type="number" name="uarm_r_graft" step="any"></td></tr>
      <tr><td></td><td>L</td><td><input type="number" name="uarm_l_in" step="any"></td><td><input type="number" name="uarm_l_out" step="any"></td><td><input type="number" name="uarm_l_graft" step="any"></td></tr>
      <tr><td>Subaxillary</td><td>R</td><td><input type="number" name="subax_r_in" step="any"></td><td><input type="number" name="subax_r_out" step="any"></td><td><input type="number" name="subax_r_graft" step="any"></td></tr>
      <tr><td></td><td>L</td><td><input type="number" name="subax_l_in" step="any"></td><td><input type="number" name="subax_l_out" step="any"></td><td><input type="number" name="subax_l_graft" step="any"></td></tr>
      <tr><td>Chest</td><td>R</td><td><input type="number" name="chest_r_in" step="any"></td><td><input type="number" name="chest_r_out" step="any"></td><td><input type="number" name="chest_r_graft" step="any"></td></tr>
      <tr><td></td><td>L</td><td><input type="number" name="chest_l_in" step="any"></td><td><input type="number" name="chest_l_out" step="any"></td><td><input type="number" name="chest_l_graft" step="any"></td></tr>
      <tr><td>Upper Abd.</td><td>R</td><td><input type="number" name="uabd_r_in" step="any"></td><td><input type="number" name="uabd_r_out" step="any"></td><td><input type="number" name="uabd_r_graft" step="any"></td></tr>
      <tr><td></td><td>L</td><td><input type="number" name="uabd_l_in" step="any"></td><td><input type="number" name="uabd_l_out" step="any"></td><td><input type="number" name="uabd_l_graft" step="any"></td></tr>
      <tr><td>Lower Abd.</td><td>R</td><td><input type="number" name="labd_r_in" step="any"></td><td><input type="number" name="labd_r_out" step="any"></td><td><input type="number" name="labd_r_graft" step="any"></td></tr>
      <tr><td></td><td>L</td><td><input type="number" name="labd_l_in" step="any"></td><td><input type="number" name="labd_l_out" step="any"></td><td><input type="number" name="labd_l_graft" step="any"></td></tr>
      <tr><td>Pubis</td><td>—</td><td><input type="number" name="pubis_in" step="any"></td><td><input type="number" name="pubis_out" step="any"></td><td><input type="number" name="pubis_graft" step="any"></td></tr>
      <tr><td>Flank</td><td>R</td><td><input type="number" name="flank_r_in" step="any"></td><td><input type="number" name="flank_r_out" step="any"></td><td><input type="number" name="flank_r_graft" step="any"></td></tr>
      <tr><td></td><td>L</td><td><input type="number" name="flank_l_in" step="any"></td><td><input type="number" name="flank_l_out" step="any"></td><td><input type="number" name="flank_l_graft" step="any"></td></tr>
      <tr><td>Hip</td><td>R</td><td><input type="number" name="hip_r_in" step="any"></td><td><input type="number" name="hip_r_out" step="any"></td><td><input type="number" name="hip_r_graft" step="any"></td></tr>
      <tr><td></td><td>L</td><td><input type="number" name="hip_l_in" step="any"></td><td><input type="number" name="hip_l_out" step="any"></td><td><input type="number" name="hip_l_graft" step="any"></td></tr>
      <tr><td>Outer Thigh</td><td>R</td><td><input type="number" name="othigh_r_in" step="any"></td><td><input type="number" name="othigh_r_out" step="any"></td><td><input type="number" name="othigh_r_graft" step="any"></td></tr>
      <tr><td></td><td>L</td><td><input type="number" name="othigh_l_in" step="any"></td><td><input type="number" name="othigh_l_out" step="any"></td><td><input type="number" name="othigh_l_graft" step="any"></td></tr>
      <tr><td>Inner Thigh</td><td>R</td><td><input type="number" name="ithigh_r_in" step="any"></td><td><input type="number" name="ithigh_r_out" step="any"></td><td><input type="number" name="ithigh_r_graft" step="any"></td></tr>
      <tr><td></td><td>L</td><td><input type="number" name="ithigh_l_in" step="any"></td><td><input type="number" name="ithigh_l_out" step="any"></td><td><input type="number" name="ithigh_l_graft" step="any"></td></tr>
      <tr><td>Knee</td><td>R</td><td><input type="number" name="knee_r_in" step="any"></td><td><input type="number" name="knee_r_out" step="any"></td><td><input type="number" name="knee_r_graft" step="any"></td></tr>
      <tr><td></td><td>L</td><td><input type="number" name="knee_l_in" step="any"></td><td><input type="number" name="knee_l_out" step="any"></td><td><input type="number" name="knee_l_graft" step="any"></td></tr>
      <tr><td>Calf / Ankle</td><td>R</td><td><input type="number" name="calf_r_in" step="any"></td><td><input type="number" name="calf_r_out" step="any"></td><td><input type="number" name="calf_r_graft" step="any"></td></tr>
      <tr><td></td><td>L</td><td><input type="number" name="calf_l_in" step="any"></td><td><input type="number" name="calf_l_out" step="any"></td><td><input type="number" name="calf_l_graft" step="any"></td></tr>
    </tbody>
  </table>

  <h2>Posterior / Back</h2>
  <table>
    <thead>
      <tr><th>Area</th><th>Side</th><th>Tumescent In (ml)</th><th>Volume Out (ml)</th><th>Graft (ml)</th></tr>
    </thead>
    <tbody>
      <tr><td>Scapula</td><td>R</td><td><input type="number" name="scap_r_in" step="any"></td><td><input type="number" name="scap_r_out" step="any"></td><td><input type="number" name="scap_r_graft" step="any"></td></tr>
      <tr><td></td><td>L</td><td><input type="number" name="scap_l_in" step="any"></td><td><input type="number" name="scap_l_out" step="any"></td><td><input type="number" name="scap_l_graft" step="any"></td></tr>
      <tr><td>Upper Back</td><td>R</td><td><input type="number" name="uback_r_in" step="any"></td><td><input type="number" name="uback_r_out" step="any"></td><td><input type="number" name="uback_r_graft" step="any"></td></tr>
      <tr><td></td><td>L</td><td><input type="number" name="uback_l_in" step="any"></td><td><input type="number" name="uback_l_out" step="any"></td><td><input type="number" name="uback_l_graft" step="any"></td></tr>
      <tr><td>Lower Back</td><td>R</td><td><input type="number" name="lback_r_in" step="any"></td><td><input type="number" name="lback_r_out" step="any"></td><td><input type="number" name="lback_r_graft" step="any"></td></tr>
      <tr><td></td><td>L</td><td><input type="number" name="lback_l_in" step="any"></td><td><input type="number" name="lback_l_out" step="any"></td><td><input type="number" name="lback_l_graft" step="any"></td></tr>
      <tr><td>Hip / Flank</td><td>R</td><td><input type="number" name="hflank_r_in" step="any"></td><td><input type="number" name="hflank_r_out" step="any"></td><td><input type="number" name="hflank_r_graft" step="any"></td></tr>
      <tr><td></td><td>L</td><td><input type="number" name="hflank_l_in" step="any"></td><td><input type="number" name="hflank_l_out" step="any"></td><td><input type="number" name="hflank_l_graft" step="any"></td></tr>
      <tr><td>Buttocks</td><td>R</td><td><input type="number" name="butt_r_in" step="any"></td><td><input type="number" name="butt_r_out" step="any"></td><td><input type="number" name="butt_r_graft" step="any"></td></tr>
      <tr><td></td><td>L</td><td><input type="number" name="butt_l_in" step="any"></td><td><input type="number" name="butt_l_out" step="any"></td><td><input type="number" name="butt_l_graft" step="any"></td></tr>
      <tr><td>Upper Thigh</td><td>R</td><td><input type="number" name="uthigh_r_in" step="any"></td><td><input type="number" name="uthigh_r_out" step="any"></td><td><input type="number" name="uthigh_r_graft" step="any"></td></tr>
      <tr><td></td><td>L</td><td><input type="number" name="uthigh_l_in" step="any"></td><td><input type="number" name="uthigh_l_out" step="any"></td><td><input type="number" name="uthigh_l_graft" step="any"></td></tr>
      <tr><td>Calf / Ankle</td><td>R</td><td><input type="number" name="calfp_r_in" step="any"></td><td><input type="number" name="calfp_r_out" step="any"></td><td><input type="number" name="calfp_r_graft" step="any"></td></tr>
      <tr><td></td><td>L</td><td><input type="number" name="calfp_l_in" step="any"></td><td><input type="number" name="calfp_l_out" step="any"></td><td><input type="number" name="calfp_l_graft" step="any"></td></tr>
    </tbody>
  </table>

  <div class="grid">
    <div><label>Total Volume Out (ml)</label><input type="number" name="totalOut" step="any"></div>
    <div><label>Notes</label><input type="text" name="notes"></div>
  </div>

  <div class="grid">
    <div><label>Signature</label><input type="text" name="sig" required></div>
    <div><label>Date</label><input type="date" name="sigDate"></div>
  </div>

  <div class="btn-row">
    <button type="submit">Submit</button>
    <button type="button" class="secondary" onclick="window.print()">Print</button>
  </div>
  <div class="powered">Powered by Office Intelligence</div>
</div>
</form>
</body>
</html>`
  },
  {
    id: 'nursing-injection-local-anesthesia',
    order: 12,
    title: 'Injection of Local Anesthesia',
    category: 'Procedural Notes',
    episode: 'ep-current',
    status: 'Signed & Verified',
    aiStatus: 'AI Verified · Local Infiltration Log',
    aiStatusType: 'success',
    fileName: 'Injection_of_Local_Anesthesia.html',
    summary: 'Documentation of local anesthetic dosage, epinephrine concentration, sterile technique, and patient response.',
    htmlTemplate: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Injection of Local Anesthesia</title>
  <style>
    :root { --primary:#1a365d; --accent:#2b6cb0; --border:#cbd5e0; --bg:#f7fafc; --text:#2d3748; }
    * { box-sizing:border-box; }
    body { font-family:Georgia,"Times New Roman",serif; line-height:1.5; color:var(--text); background:var(--bg); margin:0; padding:0 0 40px; }
    .page { max-width:800px; margin:20px auto; background:#fff; border:1px solid var(--border); box-shadow:0 4px 16px rgba(0,0,0,.07); padding:28px 36px 36px; }
    h1 { margin:0 0 18px; font-size:1.3rem; color:var(--primary); text-align:center; border-bottom:3px solid var(--primary); padding-bottom:10px; }
    .grid { display:grid; grid-template-columns:1fr 1fr; gap:12px 20px; margin:8px 0; }
    .grid.full { grid-template-columns:1fr; }
    label { display:block; font-size:.78rem; font-weight:600; color:#4a5568; margin-bottom:2px; }
    input[type=text], input[type=date], textarea { width:100%; padding:7px 10px; border:1px solid var(--border); border-radius:4px; font-size:.9rem; font-family:inherit; }
    input:focus, textarea:focus { outline:2px solid var(--accent); border-color:var(--accent); }
    textarea { resize:vertical; min-height:60px; }
    .section { margin:14px 0; }
    .section-title { font-size:.85rem; font-weight:700; color:var(--primary); margin-bottom:4px; }
    .btn-row { text-align:center; margin-top:22px; }
    button { background:var(--primary); color:#fff; border:none; padding:11px 26px; font-size:.95rem; border-radius:6px; cursor:pointer; font-family:inherit; }
    button.secondary { background:#718096; margin-left:8px; }
    .powered { text-align:center; font-size:.8rem; color:#718096; margin-top:26px; padding-top:12px; border-top:1px solid var(--border); }
    @media print { body{background:#fff;} .page{box-shadow:none;border:none;} button{display:none;} }
  </style>
</head>
<body>
<form onsubmit="event.preventDefault();alert('Submitted (demo)');">
<div class="page">
  <h1>Injection of Local Anesthesia</h1>

  <div class="grid">
    <div><label>Date</label><input type="date" name="date" required></div>
    <div><label>Patient Name</label><input type="text" name="patientName" required></div>
  </div>

  <div class="section">
    <div class="section-title">PROCEDURE</div>
    <input type="text" name="procedure" value="1) Infiltration of Local Anesthesia">
  </div>

  <div class="grid">
    <div><label>Reason for Procedure</label><input type="text" name="reason" value="Electrolysis"></div>
    <div><label>Physician</label><input type="text" name="physician"></div>
  </div>

  <div class="section">
    <div class="section-title">LOCAL ANESTHETICS</div>
    <textarea name="anesthetics" rows="5">20 ml of 1% lidocaine plain
20 ml 0.25% Marcaine plain
20 ml Saline
0.6 ml Epinephrine
Total volume 60.6 ml</textarea>
  </div>

  <div class="grid">
    <div><label>Sedation Medications</label><input type="text" name="sedation" value="None"></div>
    <div><label>Estimated Blood Loss</label><input type="text" name="ebl" value="None"></div>
    <div><label>Complications</label><input type="text" name="complications" value="None"></div>
  </div>

  <div class="section">
    <div class="section-title">TECHNIQUE</div>
    <textarea name="technique" rows="6">Patient was interviewed and the correct procedure and the area of injection was determined prior to starting the procedure. With the patient lying in a supine position, the injection area was prepped using alcohol swabs. The above-named area was then infiltrated using a 25 gauge needle on a 10 cc syringe. After repeated negative aspirations to make sure that there was no intravascular placement, enough of the anesthetic solution was injected slowly to cover the area.

The procedure was completed without complications and was tolerated well. The injection area was monitored for deep anesthetic effect to needle sticks. The patient was given post-procedure instructions and discharged to the electrolysis center in stable condition.</textarea>
  </div>

  <div class="grid">
    <div><label>Physician Signature</label><input type="text" name="sig" required></div>
    <div><label>Date</label><input type="date" name="sigDate" required></div>
  </div>

  <div class="btn-row">
    <button type="submit">Submit</button>
    <button type="button" class="secondary" onclick="window.print()">Print</button>
  </div>
  <div class="powered">Powered by Office Intelligence</div>
</div>
</form>
</body>
</html>`
  }
];
