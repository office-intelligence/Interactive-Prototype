import { PatientCase } from '../types';

export interface PortalProvider {
  id: string;
  name: string;
  shortName: string;
  title: string;
  specialty: string;
  practiceName: string;
  practiceShortName: string;
  location: string;
  phone: string;
  email: string;
  initials: string;
  badgeColor: string;
  borderColor: string;
  bgLightColor: string;
  accentColor: string;
  avatarBg: string;
  summary: string;
  bio: string;
}

export const PORTAL_PROVIDERS: PortalProvider[] = [
  {
    id: 'dr-sterling',
    name: 'Dr. Alistair Sterling, MD',
    shortName: 'Dr. Sterling',
    title: 'Board-Certified Plastic & Reconstructive Surgeon',
    specialty: 'Plastic & Reconstructive Surgery',
    practiceName: 'Aura Vanguard Surgical & Aesthetic Pavilion',
    practiceShortName: 'Aura Vanguard Surgical',
    location: '1000 Vanguard Way, Suite 400, Beverly Hills, CA 90210',
    phone: '(310) 555-0100',
    email: 'dr.sterling@auravanguard.com',
    initials: 'AS',
    badgeColor: 'bg-teal-100 text-teal-800 border-teal-300',
    borderColor: 'border-teal-500',
    bgLightColor: 'bg-teal-50/70',
    accentColor: 'text-teal-600',
    avatarBg: 'bg-gradient-to-tr from-teal-700 to-teal-500 text-white',
    summary: 'Lead Attending Surgeon overseeing surgical reconstruction, revisions, and perioperative surgical management.',
    bio: 'Lead Attending Surgeon overseeing surgical reconstruction, revisions, and perioperative surgical management.'
  },
  {
    id: 'dr-mercer',
    name: 'Dr. Julian Mercer, MD',
    shortName: 'Dr. Mercer',
    title: 'Facial Plastic & Craniofacial Surgeon',
    specialty: 'Facial Aesthetics & Rhinology',
    practiceName: 'Vanguard Facial Aesthetics & Rhinology Institute',
    practiceShortName: 'Vanguard Facial Aesthetics',
    location: '1000 Vanguard Way, Suite 350, Beverly Hills, CA 90210',
    phone: '(310) 555-0120',
    email: 'dr.mercer@vanguardfacial.com',
    initials: 'JM',
    badgeColor: 'bg-indigo-100 text-indigo-800 border-indigo-300',
    borderColor: 'border-indigo-500',
    bgLightColor: 'bg-indigo-50/70',
    accentColor: 'text-indigo-600',
    avatarBg: 'bg-gradient-to-tr from-indigo-700 to-indigo-500 text-white',
    summary: 'Facial aesthetics specialist providing 3D facial simulations, rhinoplasty evaluations, and craniofacial consulting.',
    bio: 'Facial aesthetics specialist providing 3D facial simulations, rhinoplasty evaluations, and craniofacial consulting.'
  },
  {
    id: 'dr-cruz',
    name: 'Dr. Raymond Cruz, MD',
    shortName: 'Dr. Cruz',
    title: 'Director of Perioperative & Ambulatory Anesthesia',
    specialty: 'Anesthesiology & Perioperative Pain Medicine',
    practiceName: 'Vanguard Anesthesia & Perioperative Consultants',
    practiceShortName: 'Vanguard Anesthesia Care',
    location: '1000 Vanguard Way, OR Wing 2, Beverly Hills, CA 90210',
    phone: '(310) 555-0180',
    email: 'dr.cruz@vanguardanesthesia.com',
    initials: 'RC',
    badgeColor: 'bg-cyan-100 text-cyan-800 border-cyan-300',
    borderColor: 'border-cyan-500',
    bgLightColor: 'bg-cyan-50/70',
    accentColor: 'text-cyan-600',
    avatarBg: 'bg-gradient-to-tr from-cyan-700 to-cyan-500 text-white',
    summary: 'Attending Anesthesiologist directing perioperative safety, pre-anesthesia clearance, multimodal analgesia, and airway management.',
    bio: 'Attending Anesthesiologist directing perioperative safety, pre-anesthesia clearance, multimodal analgesia, and airway management.'
  },
  {
    id: 'dr-chen',
    name: 'Dr. Evelyn Chen, MD',
    shortName: 'Dr. Chen',
    title: 'Consulting Dermatologist & Laser Specialist',
    specialty: 'Dermatology & Cutaneous Surgery',
    practiceName: 'Chen Dermatology & Cutaneous Laser Center',
    practiceShortName: 'Chen Dermatology & Laser',
    location: '9600 Wilshire Blvd, Suite 210, Beverly Hills, CA 90212',
    phone: '(310) 555-0145',
    email: 'info@chendermatology.com',
    initials: 'EC',
    badgeColor: 'bg-purple-100 text-purple-800 border-purple-300',
    borderColor: 'border-purple-500',
    bgLightColor: 'bg-purple-50/70',
    accentColor: 'text-purple-600',
    avatarBg: 'bg-gradient-to-tr from-purple-700 to-purple-500 text-white',
    summary: 'Dermatologic surgeon managing post-surgical scar modulation, fractional laser resurfacing, and skin barrier optimization.',
    bio: 'Dermatologic surgeon managing post-surgical scar modulation, fractional laser resurfacing, and skin barrier optimization.'
  }
];

export interface PortalAppointment {
  id: string;
  patientId: string;
  providerId?: string;
  practiceName?: string;
  title: string;
  doctor: string;
  specialty: string;
  facility: string;
  location: string;
  date: string;
  time: string;
  duration: string;
  status: 'UPCOMING' | 'COMPLETED' | 'REQUESTED' | 'CANCELLED';
  room?: string;
  instructions?: string;
  checklist?: { text: string; done: boolean }[];
  summaryNote?: string;
  canCheckIn?: boolean;
}

export interface PortalIntakeForm {
  id: string;
  patientId: string;
  providerId?: string;
  practiceName?: string;
  doctor?: string;
  title: string;
  category: string;
  sentDate: string;
  dueDate: string;
  status: 'PENDING' | 'IN_PROGRESS' | 'COMPLETED';
  completedDate?: string;
  description: string;
  questionsCount: number;
  signedBy?: string;
  data?: Record<string, any>;
}

export interface PortalDocument {
  id: string;
  patientId: string;
  providerId?: string;
  practiceName?: string;
  doctor?: string;
  title: string;
  fileName: string;
  category: 'Clinical Notes' | 'Lab Results' | 'Consents' | 'Patient Uploads' | 'Imaging' | 'Billing';
  uploadDate: string;
  uploadedBy: 'Practice' | 'Patient';
  fileSize: string;
  fileType: 'pdf' | 'png' | 'jpg' | 'doc';
  previewUrl?: string;
  summary: string;
  isNew?: boolean;
}

export interface PortalMessage {
  id: string;
  patientId: string;
  providerId?: string;
  practiceName?: string;
  sender: 'patient' | 'provider' | 'system';
  senderName: string;
  senderTitle?: string;
  timestamp: string;
  date: string;
  category?: 'Clinical Question' | 'Prescription Refill' | 'Scheduling' | 'Billing' | 'General';
  content: string;
  read: boolean;
  attachment?: {
    name: string;
    size: string;
  };
}

export interface PortalPrescription {
  id: string;
  patientId: string;
  providerId?: string;
  practiceName?: string;
  medicationName: string;
  dosage: string;
  instructions: string;
  prescribedBy: string;
  datePrescribed: string;
  refillsRemaining: number;
  pharmacy: string;
  status: 'ACTIVE' | 'REFILL_REQUESTED' | 'COMPLETED' | 'EXPIRED';
}

export interface PortalBill {
  id: string;
  patientId: string;
  providerId?: string;
  practiceName?: string;
  doctor?: string;
  statementDate: string;
  dueDate: string;
  totalAmount: number;
  insurancePaid: number;
  patientBalance: number;
  status: 'PAID' | 'UNPAID' | 'PENDING_INSURANCE';
  description: string;
  items: { description: string; charge: number; insuranceDiscount: number; patientOwes: number }[];
  receiptId?: string;
}

export interface PortalPatientProfile {
  id: string;
  patientId: string;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  dob: string;
  gender: 'Female' | 'Male' | 'Other';
  mrn: string;
  address: string;
  emergencyContact: {
    name: string;
    relationship: string;
    phone: string;
  };
  primarySurgeon: string;
  allergies: string[];
  vitals: {
    bloodPressure: string;
    heartRate: string;
    height: string;
    weight: string;
    bmi: string;
    temperature: string;
    oxygenSat: string;
  };
  preferredPharmacy: {
    name: string;
    address: string;
    phone: string;
  };
  insurance: {
    provider: string;
    policyNumber: string;
    groupNumber: string;
    status: 'ACTIVE_VERIFIED' | 'PENDING';
  };
}

// Sample Fictitious Patient Profiles connected to Office Intelligence
export const DEFAULT_PORTAL_PROFILES: PortalPatientProfile[] = [
  {
    id: 'profile-danielle',
    patientId: '114202',
    firstName: 'Danielle',
    lastName: 'Vance',
    email: 'danielle.vance@example.com',
    phone: '(424) 555-0199',
    dob: '05/19/1973',
    gender: 'Female',
    mrn: 'OI-114202',
    address: '10880 Wilshire Blvd, Los Angeles, CA 90024',
    emergencyContact: {
      name: 'Robert Vance',
      relationship: 'Spouse',
      phone: '(424) 555-0198'
    },
    primarySurgeon: 'Dr. Alistair Sterling, MD',
    allergies: ['Penicillin (Hives/Rash)', 'Latex Sensitivity (Mild)'],
    vitals: {
      bloodPressure: '122/78 mmHg',
      heartRate: '68 bpm',
      height: '5\' 7"',
      weight: '138 lbs',
      bmi: '21.6',
      temperature: '98.6 °F',
      oxygenSat: '99%'
    },
    preferredPharmacy: {
      name: 'Walgreens Pharmacy #1192',
      address: '9000 Wilshire Blvd, Beverly Hills, CA 90211',
      phone: '(310) 555-0191'
    },
    insurance: {
      provider: 'Anthem Blue Cross PPO',
      policyNumber: 'ANT-98210492',
      groupNumber: 'GRP-77210',
      status: 'ACTIVE_VERIFIED'
    }
  },
  {
    id: 'profile-elena',
    patientId: '115088',
    firstName: 'Elena',
    lastName: 'Rostova',
    email: 'elena.rostova@icloud.com',
    phone: '(310) 555-0142',
    dob: '08/14/1988',
    gender: 'Female',
    mrn: 'OI-115088',
    address: '1000 Vanguard Way, Beverly Hills, CA 90210',
    emergencyContact: {
      name: 'Mikhail Rostov',
      relationship: 'Brother',
      phone: '(310) 555-0149'
    },
    primarySurgeon: 'Dr. Julian Mercer, MD',
    allergies: ['Latex', 'Codeine'],
    vitals: {
      bloodPressure: '118/74 mmHg',
      heartRate: '72 bpm',
      height: '5\' 6"',
      weight: '128 lbs',
      bmi: '20.7',
      temperature: '98.4 °F',
      oxygenSat: '99%'
    },
    preferredPharmacy: {
      name: 'CVS Pharmacy #9481',
      address: '9600 Wilshire Blvd, Beverly Hills, CA 90212',
      phone: '(310) 555-0177'
    },
    insurance: {
      provider: 'Blue Shield of California PPO',
      policyNumber: 'XEN-8819203',
      groupNumber: 'GRP-88120',
      status: 'ACTIVE_VERIFIED'
    }
  },
  {
    id: 'profile-sarah',
    patientId: '113561',
    firstName: 'Sarah',
    lastName: 'Kensington',
    email: 'sarah.k@beverlyhills.net',
    phone: '(310) 555-0164',
    dob: '02/11/1972',
    gender: 'Female',
    mrn: 'OI-113561',
    address: '435 N Bedford Dr, Beverly Hills, CA 90210',
    emergencyContact: {
      name: 'David Kensington',
      relationship: 'Spouse',
      phone: '(310) 555-0165'
    },
    primarySurgeon: 'Dr. Alistair Sterling, MD',
    allergies: ['Penicillin'],
    vitals: {
      bloodPressure: '124/80 mmHg',
      heartRate: '66 bpm',
      height: '5\' 8"',
      weight: '142 lbs',
      bmi: '21.6',
      temperature: '98.6 °F',
      oxygenSat: '98%'
    },
    preferredPharmacy: {
      name: 'Beverly Hills Medical Pharmacy',
      address: '435 N Roxbury Dr, Beverly Hills, CA 90210',
      phone: '(310) 555-0122'
    },
    insurance: {
      provider: 'Aetna Open Choice PPO',
      policyNumber: 'AET-4910284',
      groupNumber: 'GRP-99412',
      status: 'ACTIVE_VERIFIED'
    }
  }
];

// Sample Appointments Timeline
export const DEFAULT_PORTAL_APPOINTMENTS: PortalAppointment[] = [
  {
    id: 'apt-up-1',
    patientId: '114202',
    providerId: 'dr-sterling',
    practiceName: 'Aura Vanguard Surgical & Aesthetic Pavilion',
    title: 'Surgical Procedure: Bilateral Revision & Capsulectomy',
    doctor: 'Dr. Alistair Sterling, MD',
    specialty: 'Plastic & Reconstructive Surgery',
    facility: 'Aura Vanguard Surgical & Aesthetic Pavilion',
    location: '1000 Vanguard Way, Suite 400, Beverly Hills, CA (OR Suite 1)',
    date: 'Monday, July 13, 2026',
    time: '7:00 AM PST (Arrival: 6:00 AM)',
    duration: '110 minutes',
    status: 'UPCOMING',
    room: 'OR #1',
    canCheckIn: true,
    instructions: 'Please remember: Absolutely nothing to eat or drink after midnight (NPO). Wear loose, comfortable clothing with a front-zipper or button-up shirt. Bring a responsible adult driver to take you home.',
    checklist: [
      { text: 'NPO Fasting: No food or liquids after midnight', done: true },
      { text: 'Complete Electronic Pre-Op Intake Forms', done: false },
      { text: 'Bring Government Photo ID & Insurance Card', done: true },
      { text: 'Arrange responsible adult ride and caregiver', done: true },
      { text: 'Take prescribed Hibiclens pre-op antibacterial shower', done: false }
    ]
  },
  {
    id: 'apt-up-2',
    patientId: '114202',
    providerId: 'dr-sterling',
    practiceName: 'Aura Vanguard Surgical & Aesthetic Pavilion',
    title: 'Post-Operative Day 1 Dressing Check & Drain Evaluation',
    doctor: 'Dr. Alistair Sterling, MD & Camila Rojas, RN',
    specialty: 'Post-Operative Care',
    facility: 'Aura Vanguard Surgical Pavilion — Clinic Wing',
    location: '1000 Vanguard Way, Suite 400, Exam Room 2',
    date: 'Tuesday, July 14, 2026',
    time: '2:30 PM PST',
    duration: '30 minutes',
    status: 'UPCOMING',
    instructions: 'Keep surgical bra and compression garments intact. Do not remove dressings prior to appointment. Bring your post-op medication log.',
    checklist: [
      { text: 'Log medication doses taken in morning', done: false },
      { text: 'Record drain output measurements', done: false }
    ]
  },
  {
    id: 'apt-up-3',
    patientId: '114202',
    providerId: 'dr-cruz',
    practiceName: 'Vanguard Anesthesia & Perioperative Consultants',
    title: 'Pre-Anesthesia Airway & Sedation Consult',
    doctor: 'Dr. Raymond Cruz, MD',
    specialty: 'Anesthesiology & Perioperative Medicine',
    facility: 'Vanguard Anesthesia & Perioperative Consultants',
    location: '1000 Vanguard Way, OR Wing Consult Bay 3, Beverly Hills, CA',
    date: 'Friday, July 10, 2026',
    time: '3:00 PM PST',
    duration: '25 minutes',
    status: 'COMPLETED',
    summaryNote: 'Mallampati Class 1 airway verified. No history of malignant hyperthermia or difficult intubation. General endotracheal anesthesia plan approved.'
  },
  {
    id: 'apt-up-4',
    patientId: '114202',
    providerId: 'dr-chen',
    practiceName: 'Chen Dermatology & Cutaneous Laser Center',
    title: 'Post-Surgical Cutaneous Healing & Laser Scar Assessment',
    doctor: 'Dr. Evelyn Chen, MD',
    specialty: 'Dermatology & Cutaneous Surgery',
    facility: 'Chen Dermatology & Laser Center',
    location: '9600 Wilshire Blvd, Suite 210, Beverly Hills, CA',
    date: 'Wednesday, August 12, 2026',
    time: '11:00 AM PST',
    duration: '40 minutes',
    status: 'UPCOMING',
    instructions: 'Please bring your current silicone scar sheets and topical regimen. We will evaluate for vascular laser intervention to minimize erythema.'
  },
  {
    id: 'apt-up-5',
    patientId: '114202',
    providerId: 'dr-mercer',
    practiceName: 'Vanguard Facial Aesthetics & Rhinology Institute',
    title: 'Facial Symmetry & Aesthetic Harmony Evaluation',
    doctor: 'Dr. Julian Mercer, MD',
    specialty: 'Facial Aesthetics & Rhinology',
    facility: 'Vanguard Facial Aesthetics Institute',
    location: '1000 Vanguard Way, Suite 350, Beverly Hills, CA',
    date: 'Thursday, August 27, 2026',
    time: '1:15 PM PST',
    duration: '45 minutes',
    status: 'UPCOMING',
    instructions: 'Comprehensive Vectra 3D photographic profiling and facial structural assessment.'
  },
  {
    id: 'apt-past-1',
    patientId: '114202',
    providerId: 'dr-sterling',
    practiceName: 'Aura Vanguard Surgical & Aesthetic Pavilion',
    title: 'Pre-Operative History & Physical Clearance Encounter',
    doctor: 'Dr. Alistair Sterling, MD',
    specialty: 'Plastic & Reconstructive Surgery',
    facility: 'Aura Vanguard Surgical Pavilion — Consult Suite',
    location: '1000 Vanguard Way, Suite 400, Beverly Hills, CA',
    date: 'Wednesday, June 24, 2026',
    time: '10:00 AM PST',
    duration: '45 minutes',
    status: 'COMPLETED',
    summaryNote: 'Comprehensive pre-operative clearance completed. Laboratory studies reviewed and within normal limits. 12-lead EKG normal sinus rhythm. Surgical marking plan reviewed and consented.'
  },
  {
    id: 'apt-past-2',
    patientId: '114202',
    providerId: 'dr-sterling',
    practiceName: 'Aura Vanguard Surgical & Aesthetic Pavilion',
    title: 'Aesthetic Consultation & Surgical Planning',
    doctor: 'Dr. Alistair Sterling, MD',
    specialty: 'Plastic & Reconstructive Surgery',
    facility: 'Aura Vanguard Surgical Pavilion',
    location: '1000 Vanguard Way, Suite 400, Beverly Hills, CA',
    date: 'Friday, May 15, 2026',
    time: '11:15 AM PST',
    duration: '60 minutes',
    status: 'COMPLETED',
    summaryNote: 'Initial consultation to discuss bilateral implant exchange options. 3D imaging simulation rendered. Surgical goals aligned and scheduled.'
  }
];

// Sample Intake Forms sent to patient via email from OI
export const DEFAULT_PORTAL_FORMS: PortalIntakeForm[] = [
  {
    id: 'form-intake-1',
    patientId: '114202',
    providerId: 'dr-sterling',
    doctor: 'Dr. Alistair Sterling, MD',
    practiceName: 'Aura Vanguard Surgical & Aesthetic Pavilion',
    title: 'Comprehensive Pre-Operative Medical History & Systems Review',
    category: 'Clinical Intake',
    sentDate: 'July 05, 2026',
    dueDate: 'July 12, 2026 (Before Surgery)',
    status: 'PENDING',
    description: 'Detailed medical history questionnaire covering past surgical history, cardiovascular risks, current medications, anesthesia sensitivity, and allergies required for surgical clearance.',
    questionsCount: 16
  },
  {
    id: 'form-intake-2',
    patientId: '114202',
    providerId: 'dr-sterling',
    doctor: 'Dr. Alistair Sterling, MD',
    practiceName: 'Aura Vanguard Surgical & Aesthetic Pavilion',
    title: 'Informed Surgical & Anesthesia Consent Agreement',
    category: 'Legal & Consents',
    sentDate: 'July 05, 2026',
    dueDate: 'July 12, 2026',
    status: 'PENDING',
    description: 'Official consent for bilateral surgical procedure and general anesthesia administration at Aura Vanguard Surgical Pavilion with digital signature acknowledgement.',
    questionsCount: 8
  },
  {
    id: 'form-intake-3',
    patientId: '114202',
    providerId: 'dr-sterling',
    doctor: 'Dr. Alistair Sterling, MD',
    practiceName: 'Aura Vanguard Surgical & Aesthetic Pavilion',
    title: "Patient's Rights, Responsibilities & Financial Assignment",
    category: 'Practice Disclosures',
    sentDate: 'July 01, 2026',
    dueDate: 'July 10, 2026',
    status: 'COMPLETED',
    completedDate: 'July 08, 2026',
    signedBy: 'Danielle Vance',
    description: 'Patient rights acknowledgement, emergency contact assignment, and direct billing assignment agreement.',
    questionsCount: 6
  },
  {
    id: 'form-intake-4',
    patientId: '114202',
    providerId: 'dr-cruz',
    doctor: 'Dr. Raymond Cruz, MD',
    practiceName: 'Vanguard Anesthesia & Perioperative Consultants',
    title: 'Pre-Anesthesia Airway & Medication Clearance Form',
    category: 'Anesthesia Safety',
    sentDate: 'July 05, 2026',
    dueDate: 'July 12, 2026',
    status: 'PENDING',
    description: 'Specialist anesthesia questionnaire detailing past sedation reactions, intubation history, and dental/airway assessment.',
    questionsCount: 10
  },
  {
    id: 'form-intake-5',
    patientId: '114202',
    providerId: 'dr-chen',
    doctor: 'Dr. Evelyn Chen, MD',
    practiceName: 'Chen Dermatology & Cutaneous Laser Center',
    title: 'Cutaneous Health & Fitzpatrick Phototype Questionnaire',
    category: 'Dermatology Assessment',
    sentDate: 'July 07, 2026',
    dueDate: 'August 10, 2026',
    status: 'PENDING',
    description: 'Skin barrier evaluation, scar tendency history (keloid/hypertrophic), and topical retinoid use survey for post-op laser scar planning.',
    questionsCount: 7
  },
  {
    id: 'form-intake-6',
    patientId: '114202',
    providerId: 'dr-mercer',
    doctor: 'Dr. Julian Mercer, MD',
    practiceName: 'Vanguard Facial Aesthetics & Rhinology Institute',
    title: 'Facial Aesthetics & Photographic Consent Form',
    category: 'Facial Aesthetics',
    sentDate: 'July 08, 2026',
    dueDate: 'August 20, 2026',
    status: 'COMPLETED',
    completedDate: 'July 09, 2026',
    signedBy: 'Danielle Vance',
    description: 'Vectra 3D computerized facial imaging authorization, aesthetic priority questionnaire, and medical photo documentation consent.',
    questionsCount: 6
  }
];

// Sample Clinical & Uploaded Documents
export const DEFAULT_PORTAL_DOCUMENTS: PortalDocument[] = [
  {
    id: 'doc-lab-1',
    patientId: '114202',
    providerId: 'dr-sterling',
    doctor: 'Dr. Alistair Sterling, MD',
    practiceName: 'Aura Vanguard Surgical & Aesthetic Pavilion',
    title: 'Complete Blood Count (CBC) & Metabolic Panel Lab Report',
    fileName: 'Quest_Diagnostics_CBC_BMP_July2026.pdf',
    category: 'Lab Results',
    uploadDate: 'July 09, 2026',
    uploadedBy: 'Practice',
    fileSize: '480 KB',
    fileType: 'pdf',
    summary: 'Quest Diagnostics report: WBC 6.8, Hemoglobin 13.8 g/dL, Platelets 245k, BMP normal, PT/INR 1.0. All parameters cleared for surgery.',
    isNew: true
  },
  {
    id: 'doc-ekg-1',
    patientId: '114202',
    providerId: 'dr-cruz',
    doctor: 'Dr. Raymond Cruz, MD',
    practiceName: 'Vanguard Anesthesia & Perioperative Consultants',
    title: '12-Lead Electrocardiogram (EKG) Tracing & Anesthesia Clearance',
    fileName: 'EKG_12Lead_Clearance_Jul2026.pdf',
    category: 'Clinical Notes',
    uploadDate: 'July 08, 2026',
    uploadedBy: 'Practice',
    fileSize: '1.1 MB',
    fileType: 'pdf',
    summary: 'Normal Sinus Rhythm at 68 bpm. Normal axis, no ST-T abnormalities. Anesthesia cardiac clearance approved for general anesthesia.'
  },
  {
    id: 'doc-inst-1',
    patientId: '114202',
    providerId: 'dr-sterling',
    doctor: 'Dr. Alistair Sterling, MD',
    practiceName: 'Aura Vanguard Surgical & Aesthetic Pavilion',
    title: 'Dr. Sterling Pre & Post-Operative Patient Care Instructions',
    fileName: 'Pre_Post_Op_Patient_Guide_SterlingMD.pdf',
    category: 'Clinical Notes',
    uploadDate: 'July 02, 2026',
    uploadedBy: 'Practice',
    fileSize: '820 KB',
    fileType: 'pdf',
    summary: 'Comprehensive surgical preparation guidelines, fasting timeline, medication hold instructions, and post-operative garment care.'
  },
  {
    id: 'doc-chen-1',
    patientId: '114202',
    providerId: 'dr-chen',
    doctor: 'Dr. Evelyn Chen, MD',
    practiceName: 'Chen Dermatology & Cutaneous Laser Center',
    title: 'Dr. Chen Cutaneous Wound Care & Scar Optimization Protocol',
    fileName: 'ChenDerm_Scar_Optimization_Protocol.pdf',
    category: 'Clinical Notes',
    uploadDate: 'July 07, 2026',
    uploadedBy: 'Practice',
    fileSize: '640 KB',
    fileType: 'pdf',
    summary: 'Evidence-based topical silicone, SPF 50+ mineral UV defense, and vascular laser schedule to minimize surgical scar erythema.'
  },
  {
    id: 'doc-mercer-1',
    patientId: '114202',
    providerId: 'dr-mercer',
    doctor: 'Dr. Julian Mercer, MD',
    practiceName: 'Vanguard Facial Aesthetics & Rhinology Institute',
    title: 'Vectra 3D Facial Topography & Volumetric Analysis',
    fileName: 'Mercer_Vectra3D_Analysis_Vance.pdf',
    category: 'Imaging',
    uploadDate: 'July 08, 2026',
    uploadedBy: 'Practice',
    fileSize: '3.4 MB',
    fileType: 'pdf',
    summary: 'Digital volumetric simulation and facial proportion mapping for upcoming aesthetic consultation.'
  },
  {
    id: 'doc-up-id',
    patientId: '114202',
    title: "California Driver's License (Photo Identification)",
    fileName: 'Danielle_Vance_Drivers_License.png',
    category: 'Patient Uploads',
    uploadDate: 'July 08, 2026',
    uploadedBy: 'Patient',
    fileSize: '2.4 MB',
    fileType: 'png',
    summary: 'Verified Government Photo ID on file for check-in identity matching.'
  },
  {
    id: 'doc-up-ins',
    patientId: '114202',
    title: 'Anthem Blue Cross Insurance Card (Front & Back)',
    fileName: 'Anthem_PPO_Card_Vance.png',
    category: 'Patient Uploads',
    uploadDate: 'July 08, 2026',
    uploadedBy: 'Patient',
    fileSize: '1.9 MB',
    fileType: 'png',
    summary: 'Primary PPO Insurance Card with policy #ANT-98210492.'
  }
];

// Sample Messages Thread
export const DEFAULT_PORTAL_MESSAGES: PortalMessage[] = [
  {
    id: 'msg-1',
    patientId: '114202',
    providerId: 'dr-sterling',
    practiceName: 'Aura Vanguard Surgical & Aesthetic Pavilion',
    sender: 'provider',
    senderName: 'Camila Rojas, RN',
    senderTitle: 'Lead Surgical Coordinator (Dr. Sterling)',
    timestamp: '9:15 AM',
    date: 'July 10, 2026',
    category: 'Clinical Question',
    content: 'Good morning Danielle! We have reviewed your laboratory results from Quest and your 12-lead EKG. Everything looks completely normal and cleared. Please remember to complete the remaining two intake questionnaires on your portal before Sunday.',
    read: true
  },
  {
    id: 'msg-2',
    patientId: '114202',
    providerId: 'dr-sterling',
    practiceName: 'Aura Vanguard Surgical & Aesthetic Pavilion',
    sender: 'patient',
    senderName: 'Danielle Vance',
    timestamp: '11:20 AM',
    date: 'July 10, 2026',
    category: 'Clinical Question',
    content: 'Thank you Camila! I have filled out the privacy forms and will finish the surgical consent today. Should I still take my regular morning blood pressure medication on Monday morning with a small sip of water?',
    read: true
  },
  {
    id: 'msg-3',
    patientId: '114202',
    providerId: 'dr-cruz',
    practiceName: 'Vanguard Anesthesia & Perioperative Consultants',
    sender: 'provider',
    senderName: 'Dr. Raymond Cruz, MD',
    senderTitle: 'Attending Anesthesiologist',
    timestamp: '1:45 PM',
    date: 'July 10, 2026',
    category: 'Clinical Question',
    content: 'Hello Danielle, yes! You may take your morning blood pressure medication at 5:30 AM with no more than one small tablespoon of water. Otherwise, maintain strict fasting (no other liquids, coffee, or food) from midnight onward. See you Monday morning in Pre-Op Bay 1!',
    read: true
  },
  {
    id: 'msg-4',
    patientId: '114202',
    providerId: 'dr-chen',
    practiceName: 'Chen Dermatology & Cutaneous Laser Center',
    sender: 'provider',
    senderName: 'Dr. Evelyn Chen, MD',
    senderTitle: 'Consulting Dermatologist',
    timestamp: '3:10 PM',
    date: 'July 09, 2026',
    category: 'Clinical Question',
    content: 'Hi Danielle, I have uploaded your post-surgical scar care protocol to your portal documents. We will schedule your vascular laser check-in 4 weeks following Dr. Sterling’s surgical procedure. Wishing you a smooth recovery!',
    read: true
  },
  {
    id: 'msg-5',
    patientId: '114202',
    providerId: 'dr-mercer',
    practiceName: 'Vanguard Facial Aesthetics & Rhinology Institute',
    sender: 'provider',
    senderName: 'Dr. Julian Mercer, MD',
    senderTitle: 'Facial Aesthetics Surgeon',
    timestamp: '10:00 AM',
    date: 'July 08, 2026',
    category: 'General',
    content: 'Danielle, your 3D Vectra facial topography file is now uploaded and ready in your documents vault. We look forward to our consultation in late August once you have fully healed from your primary surgery.',
    read: true
  }
];

// Sample Prescriptions
export const DEFAULT_PORTAL_PRESCRIPTIONS: PortalPrescription[] = [
  {
    id: 'rx-1',
    patientId: '114202',
    providerId: 'dr-sterling',
    practiceName: 'Aura Vanguard Surgical & Aesthetic Pavilion',
    medicationName: 'Cefazolin / Keflex (Cephalexin)',
    dosage: '500 mg Capsule',
    instructions: 'Take 1 capsule orally every 6 hours starting the morning after surgery for 7 days until finished.',
    prescribedBy: 'Dr. Alistair Sterling, MD',
    datePrescribed: 'July 05, 2026',
    refillsRemaining: 0,
    pharmacy: 'Walgreens Pharmacy #1192 (Beverly Hills)',
    status: 'ACTIVE'
  },
  {
    id: 'rx-2',
    patientId: '114202',
    providerId: 'dr-sterling',
    practiceName: 'Aura Vanguard Surgical & Aesthetic Pavilion',
    medicationName: 'Celebrex (Celecoxib)',
    dosage: '200 mg Capsule',
    instructions: 'Take 1 capsule orally every 12 hours with food as needed for post-operative inflammation and discomfort.',
    prescribedBy: 'Dr. Alistair Sterling, MD',
    datePrescribed: 'July 05, 2026',
    refillsRemaining: 1,
    pharmacy: 'Walgreens Pharmacy #1192 (Beverly Hills)',
    status: 'ACTIVE'
  },
  {
    id: 'rx-3',
    patientId: '114202',
    providerId: 'dr-cruz',
    practiceName: 'Vanguard Anesthesia & Perioperative Consultants',
    medicationName: 'Zofran (Ondansetron ODT)',
    dosage: '4 mg Orally Disintegrating Tablet',
    instructions: 'Dissolve 1 tablet on tongue every 8 hours as needed for post-anesthesia nausea.',
    prescribedBy: 'Dr. Raymond Cruz, MD',
    datePrescribed: 'July 05, 2026',
    refillsRemaining: 2,
    pharmacy: 'Walgreens Pharmacy #1192 (Beverly Hills)',
    status: 'ACTIVE'
  },
  {
    id: 'rx-4',
    patientId: '114202',
    providerId: 'dr-chen',
    practiceName: 'Chen Dermatology & Cutaneous Laser Center',
    medicationName: 'Silvadene & Medical Grade Silicone Gel (Biocorneum SPF 30)',
    dosage: 'Topical Application Tube (20g)',
    instructions: 'Apply ultra-thin film to healed surgical incisions twice daily once sutures/steri-strips are removed.',
    prescribedBy: 'Dr. Evelyn Chen, MD',
    datePrescribed: 'July 07, 2026',
    refillsRemaining: 3,
    pharmacy: 'Beverly Hills Medical Pharmacy',
    status: 'ACTIVE'
  }
];

// Sample Billing Statements
export const DEFAULT_PORTAL_BILLS: PortalBill[] = [
  {
    id: 'bill-2026-07',
    patientId: '114202',
    providerId: 'dr-sterling',
    doctor: 'Dr. Alistair Sterling, MD',
    practiceName: 'Aura Vanguard Surgical & Aesthetic Pavilion',
    statementDate: 'July 01, 2026',
    dueDate: 'July 13, 2026 (Date of Service)',
    totalAmount: 4850.00,
    insurancePaid: 4700.00,
    patientBalance: 150.00,
    status: 'UNPAID',
    description: 'Outpatient Surgical Facility & Specialist Surgical Fee for DOS 07/13/2026',
    items: [
      { description: 'Ambulatory Surgical Suite Facility Fee (OR 1)', charge: 3500.00, insuranceDiscount: 3400.00, patientOwes: 100.00 },
      { description: 'Reconstructive Surgical Specialist Operating Fee', charge: 1200.00, insuranceDiscount: 1150.00, patientOwes: 50.00 },
      { description: 'Pre-Operative Medication & Sterile Supply Kit', charge: 150.00, insuranceDiscount: 150.00, patientOwes: 0.00 }
    ]
  },
  {
    id: 'bill-2026-cruz',
    patientId: '114202',
    providerId: 'dr-cruz',
    doctor: 'Dr. Raymond Cruz, MD',
    practiceName: 'Vanguard Anesthesia & Perioperative Consultants',
    statementDate: 'July 05, 2026',
    dueDate: 'July 13, 2026',
    totalAmount: 1800.00,
    insurancePaid: 1725.00,
    patientBalance: 75.00,
    status: 'UNPAID',
    description: 'Specialist Anesthesia Administration & Intraoperative Monitoring',
    items: [
      { description: 'Board-Certified General Anesthesia Management (120 min)', charge: 1500.00, insuranceDiscount: 1450.00, patientOwes: 50.00 },
      { description: 'Ultrasound Guided Pectoral Nerve Block (PECS II)', charge: 300.00, insuranceDiscount: 275.00, patientOwes: 25.00 }
    ]
  },
  {
    id: 'bill-2026-chen',
    patientId: '114202',
    providerId: 'dr-chen',
    doctor: 'Dr. Evelyn Chen, MD',
    practiceName: 'Chen Dermatology & Cutaneous Laser Center',
    statementDate: 'July 07, 2026',
    dueDate: 'July 25, 2026',
    totalAmount: 320.00,
    insurancePaid: 320.00,
    patientBalance: 0.00,
    status: 'PAID',
    description: 'Dermatologic Scar Evaluation & Pre-Laser Skin Mapping',
    items: [
      { description: 'Comprehensive Dermatological Consult', charge: 320.00, insuranceDiscount: 320.00, patientOwes: 0.00 }
    ]
  }
];
