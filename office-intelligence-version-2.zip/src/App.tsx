import React, { useState } from 'react';
import { Header } from './components/Header';
import { NightingaleBriefBanner } from './components/NightingaleBriefBanner';

import { ScheduleIntelligenceBox } from './components/ScheduleIntelligenceBox';
import { ScheduleFullView } from './components/ScheduleFullView';
import { BlankPageTemplate } from './components/BlankPageTemplate';
import { PatientChartPage } from './components/PatientChartPage';
import { AdministrationPage, AdminActiveSection } from './components/AdministrationPage';
import { BillingModulePage } from './components/BillingModulePage';
import { TasksWidget } from './components/TasksWidget';
import { CommunicationWidget } from './components/CommunicationWidget';
import { PatientDetailModal } from './components/PatientDetailModal';
import { AddPatientModal } from './components/AddPatientModal';
import { NightingaleAIChatDrawer } from './components/NightingaleAIChatDrawer';
import { AIWorkflowExamples } from './components/AIWorkflowExamples';
import { AIHomePage } from './components/AIHomePage';
import { MessagesPage } from './components/MessagesPage';
import { PublicLandingPage } from './components/PublicLandingPage';
import { LoginPage } from './components/LoginPage';
import { RegistrationPage } from './components/RegistrationPage';
import { PatientPortalPage } from './components/PatientPortalPage';
import { 
  initialPatientCases, 
  initialTasks, 
  initialStats, 
  initialBottleneckAlerts 
} from './data/mockData';
import { getCasesForDateKey } from './utils/dateCases';
import { PatientCase, PatientStage, TaskItem, AuthUser, PracticeConfig } from './types';
import { ScheduleViewMode } from './components/ScheduleIntelligenceBox';
import { 
  CheckCircle2, 
  AlertTriangle, 
  Sparkles, 
  Plus, 
  Calendar, 
  FileText, 
  CreditCard, 
  Settings, 
  Zap, 
  ChevronLeft, 
  ChevronRight, 
  Building2,
  Layers,
  Sliders,
  LogOut,
  Globe,
  Home,
  MessageSquare,
  MapPin,
  ChevronDown,
  Check
} from 'lucide-react';

const TODAY_DATE = new Date(2026, 6, 13); // Monday, July 13, 2026

export const INITIAL_PRACTICES: PracticeConfig[] = [
  {
    id: 'loc-1',
    practiceName: 'Aura Vanguard Surgical & Aesthetic Pavilion',
    locationName: 'Beverly Hills - Main Surgical Pavilion',
    isPrimary: true,
    isSatellite: false,
    practiceType: 'ASC',
    specialty: 'Plastic & Reconstructive Surgery',
    streetAddress: '1000 Vanguard Way, Suite 400',
    city: 'Beverly Hills',
    state: 'CA',
    zipCode: '90210',
    country: 'United States',
    telephone: '(310) 555-0180',
    email: 'info@auravanguardsurgical.com',
    website: 'https://auravanguardsurgical.com',
    primaryProvider: {
      firstName: 'Alistair',
      lastName: 'Sterling',
      degree: 'MD',
      cellPhone: '(310) 555-0185',
      email: 'dr.sterling@auravanguardsurgical.com',
      npi: '1982736450'
    },
    calendarSettings: {
      startTime: '07:00 AM',
      endTime: '07:00 PM',
      visitTypes: [
        { id: 'vt-1', name: 'New Patient', color: '#3b82f6', durationMins: 45 },
        { id: 'vt-2', name: 'Follow Up', color: '#10b981', durationMins: 20 },
        { id: 'vt-3', name: 'Post-op', color: '#8b5cf6', durationMins: 30 },
        { id: 'vt-4', name: 'Pre-op', color: '#f59e0b', durationMins: 45 },
        { id: 'vt-5', name: 'Consultation', color: '#06b6d4', durationMins: 60 },
      ],
      rooms: [
        { id: 'rm-1', name: 'OR #1', color: '#0284c7', type: 'OR' },
        { id: 'rm-2', name: 'OR #2', color: '#0d9488', type: 'OR' },
      ]
    }
  },
  {
    id: 'loc-2',
    practiceName: 'Aura Vanguard Medical Spa & Laser Center',
    locationName: 'Century City - Laser & Clinical Pavilion',
    isPrimary: false,
    isSatellite: true,
    practiceType: 'Medspa',
    specialty: 'Aesthetic Medicine & Minimally Invasive',
    streetAddress: '1900 Avenue of the Stars, Suite 2200',
    city: 'Los Angeles',
    state: 'CA',
    zipCode: '90067',
    country: 'United States',
    telephone: '(310) 555-0220',
    email: 'centurycity@auravanguardsurgical.com',
    website: 'https://auravanguardsurgical.com/century-city',
    primaryProvider: {
      firstName: 'Evelyn',
      lastName: 'Vance',
      degree: 'MD',
      cellPhone: '(310) 555-0192',
      email: 'dr.vance@auravanguardsurgical.com',
      npi: '1827364501'
    },
    calendarSettings: {
      startTime: '08:00 AM',
      endTime: '06:00 PM',
      visitTypes: [
        { id: 'vt-cc-1', name: 'Laser Skin Resurfacing', color: '#06b6d4', durationMins: 45 },
        { id: 'vt-cc-2', name: 'Neuromodulator & Fillers', color: '#8b5cf6', durationMins: 30 },
        { id: 'vt-cc-3', name: 'Aesthetic Consultation', color: '#ec4899', durationMins: 30 },
      ],
      rooms: [
        { id: 'rm-cc-1', name: 'Laser Suite A', color: '#06b6d4', type: 'Procedure' },
        { id: 'rm-cc-2', name: 'Injectables Bay 1', color: '#8b5cf6', type: 'Consult' },
      ]
    }
  },
  {
    id: 'loc-3',
    practiceName: 'Aura Vanguard Outpatient Surgical Annex',
    locationName: 'Newport Beach - Coastal Annex',
    isPrimary: false,
    isSatellite: true,
    practiceType: 'ASC',
    specialty: 'Outpatient Facial & Body Surgery',
    streetAddress: '400 Newport Center Dr, Suite 500',
    city: 'Newport Beach',
    state: 'CA',
    zipCode: '92660',
    country: 'United States',
    telephone: '(949) 555-0340',
    email: 'newport@auravanguardsurgical.com',
    website: 'https://auravanguardsurgical.com/newport',
    primaryProvider: {
      firstName: 'Julian',
      lastName: 'Mercer',
      degree: 'MD',
      cellPhone: '(310) 555-0194',
      email: 'dr.mercer@auravanguardsurgical.com',
      npi: '1728394019'
    },
    calendarSettings: {
      startTime: '06:30 AM',
      endTime: '05:30 PM',
      visitTypes: [
        { id: 'vt-nb-1', name: 'Surgical Consult', color: '#3b82f6', durationMins: 45 },
        { id: 'vt-nb-2', name: 'Outpatient Procedure', color: '#10b981', durationMins: 90 },
      ],
      rooms: [
        { id: 'rm-nb-1', name: 'OR Coastal #1', color: '#0284c7', type: 'OR' },
        { id: 'rm-nb-2', name: 'Recovery Bay A', color: '#10b981', type: 'Recovery' },
      ]
    }
  }
];

export default function App() {
  // Authentication & Public Pages View State: 'app' | 'landing' | 'login' | 'register' | 'portal' (Defaults to front landing page)
  const [authView, setAuthView] = useState<'app' | 'landing' | 'login' | 'register' | 'portal'>('landing');
  
  // Current Authenticated User (Defaults to Dr. Alistair Sterling demo account)
  const [currentUser, setCurrentUser] = useState<AuthUser | null>({
    id: 'user-demo-1',
    firstName: 'Alistair',
    lastName: 'Sterling',
    email: 'dr.sterling@auravanguardsurgical.com',
    role: 'PRACTICE_ADMIN',
    telephone: '(310) 555-0185',
    title: 'Attending Surgeon & Medical Director',
    practiceName: 'Aura Vanguard Surgical & Aesthetic Pavilion'
  });

  // Multiple Practices & Locations State
  const [practicesList, setPracticesList] = useState<PracticeConfig[]>(INITIAL_PRACTICES);
  const [selectedPracticeId, setSelectedPracticeId] = useState<string>('loc-1');
  const [isPracticeDropdownOpen, setIsPracticeDropdownOpen] = useState<boolean>(false);

  // Global Active Practice Configuration
  const [practiceConfig, setPracticeConfig] = useState<PracticeConfig>(INITIAL_PRACTICES[0]);

  const handleSelectPractice = (practiceId: string) => {
    const target = practicesList.find(p => p.id === practiceId);
    if (target) {
      setSelectedPracticeId(practiceId);
      setPracticeConfig(target);
      if (currentUser) {
        setCurrentUser(prev => prev ? {
          ...prev,
          practiceName: target.practiceName
        } : null);
      }
      showToast(`Switched view to practice: ${target.practiceName} (${target.locationName || target.city})`);
    }
  };

  const handleAddPractice = (newPractice: PracticeConfig) => {
    setPracticesList(prev => [...prev, newPractice]);
    setSelectedPracticeId(newPractice.id || `loc-${Date.now()}`);
    setPracticeConfig(newPractice);
    showToast(`Added and switched to ${newPractice.practiceName}!`);
  };

  const handleUpdatePracticeConfig = (updated: PracticeConfig) => {
    setPracticeConfig(updated);
    setPracticesList(prev => prev.map(p => (p.id === updated.id ? updated : p)));
    showToast('Practice configuration updated across Office Intelligence.');
  };

  const [activeTab, setActiveTab] = useState<string>('home');
  const [adminActiveSection, setAdminActiveSection] = useState<AdminActiveSection>('configure-practice');
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState<boolean>(false);

  // Date navigation & view mode state
  const [selectedDate, setSelectedDate] = useState<Date>(TODAY_DATE);
  const [dateCasesMap, setDateCasesMap] = useState<Record<string, PatientCase[]>>({});
  const [scheduleViewMode, setScheduleViewMode] = useState<ScheduleViewMode>('PRIORITY');

  const [tasks, setTasks] = useState<TaskItem[]>(initialTasks);
  const [stats, setStats] = useState(initialStats);
  const [searchQuery, setSearchQuery] = useState('');
  
  const [selectedPatient, setSelectedPatient] = useState<PatientCase | null>(null);
  const [selectedChartPatientId, setSelectedChartPatientId] = useState<string>('case-1');
  const [selectedChartSection, setSelectedChartSection] = useState<string | undefined>(undefined);
  const [isAddPatientModalOpen, setIsAddPatientModalOpen] = useState(false);
  const [isAIChatOpen, setIsAIChatOpen] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const formatDateKey = (d: Date) => {
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  };

  const formatDisplayDate = (d: Date) => {
    return d.toLocaleDateString('en-US', {
      weekday: 'long',
      month: 'long',
      day: 'numeric',
      year: 'numeric',
    });
  };

  const activeDateKey = formatDateKey(selectedDate);
  const activeDateCases = dateCasesMap[activeDateKey] || getCasesForDateKey(activeDateKey, formatDisplayDate(selectedDate));

  const isToday =
    selectedDate.getFullYear() === TODAY_DATE.getFullYear() &&
    selectedDate.getMonth() === TODAY_DATE.getMonth() &&
    selectedDate.getDate() === TODAY_DATE.getDate();

  const handlePrevDay = () => {
    setSelectedDate((prev) => {
      const d = new Date(prev);
      d.setDate(d.getDate() - 1);
      showToast(`Schedule view: ${formatDisplayDate(d)}`);
      return d;
    });
  };

  const handleNextDay = () => {
    setSelectedDate((prev) => {
      const d = new Date(prev);
      d.setDate(d.getDate() + 1);
      showToast(`Schedule view: ${formatDisplayDate(d)}`);
      return d;
    });
  };

  const handleToday = () => {
    const d = new Date(TODAY_DATE);
    setSelectedDate(d);
    showToast(`Schedule view reset to Today (${formatDisplayDate(d)})`);
  };

  const updateActiveCases = (updater: (prev: PatientCase[]) => PatientCase[]) => {
    setDateCasesMap((prevMap) => {
      const current = prevMap[activeDateKey] || getCasesForDateKey(activeDateKey, formatDisplayDate(selectedDate));
      return {
        ...prevMap,
        [activeDateKey]: updater(current),
      };
    });
  };

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 4000);
  };

  const handleOpenPatientChart = (patient: PatientCase, sectionKey?: string) => {
    setSelectedChartPatientId(patient.id);
    setSelectedChartSection(sectionKey);
    setActiveTab('patients');
    showToast(`Opening Patient Chart for ${patient.name}...`);
  };

  const handleOpenPatientChartById = (patientId: string, sectionKey?: string) => {
    const found = activeDateCases.find((c) => c.id === patientId || c.patientId === patientId);
    setSelectedChartPatientId(found ? found.id : patientId);
    setSelectedChartSection(sectionKey || 'portalMessages');
    setActiveTab('patients');
    showToast(`Opening Patient Chart for ${found ? found.name : patientId}...`);
  };

  // EKG resolution fast-track
  const handleTriggerEKGFastTrack = (caseId: string) => {
    updateActiveCases((prev) =>
      prev.map((c) => {
        if (c.id === caseId) {
          const updatedLabs = c.labs.map((l) =>
            l.name === 'EKG' ? { name: 'EKG', value: 'Fax Received - Normal Sinus', status: 'normal' as const } : l
          );
          return {
            ...c,
            readinessScore: 98,
            readinessLevel: 'CLEARED' as const,
            aiSummary: 'EKG report received from Beverly Hills Cardiology via fast-track fax. Pre-op photo review cleared. Patient fully ready for OR 1.',
            labs: updatedLabs,
            bottlenecks: [],
            actionItems: c.actionItems.map((a) => ({ ...a, done: true })),
          };
        }
        return c;
      })
    );

    setTasks((prev) =>
      prev.map((t) => (t.id === 'task-4' ? { ...t, completed: true } : t))
    );

    showToast('⚡ EKG Fast-Track: EKG report received & cleared for Patricia DePoli! AI Readiness updated to 98.');
  };

  // Update patient stage (Check-In -> Pre-Op -> In OR -> PACU -> Discharged)
  const handleUpdateStage = (caseId: string, newStage: PatientStage) => {
    updateActiveCases((prev) =>
      prev.map((c) => {
        if (c.id === caseId) {
          return { ...c, stage: newStage };
        }
        return c;
      })
    );
    showToast(`Updated patient flow stage to ${newStage.replace('_', ' ')}.`);
  };

  // Action checklist toggle
  const handleResolveAction = (caseId: string, actionId: string) => {
    updateActiveCases((prev) =>
      prev.map((c) => {
        if (c.id === caseId) {
          const updatedItems = c.actionItems.map((a) =>
            a.id === actionId ? { ...a, done: !a.done } : a
          );
          return { ...c, actionItems: updatedItems };
        }
        return c;
      })
    );
  };

  // Toggle Task Completion
  const handleToggleTask = (taskId: string) => {
    setTasks((prev) =>
      prev.map((t) => (t.id === taskId ? { ...t, completed: !t.completed } : t))
    );
  };

  // Search filtered cases
  const displayedCases = activeDateCases.filter((c) => {
    if (!searchQuery) return true;
    const q = searchQuery.toLowerCase();
    return (
      c.name.toLowerCase().includes(q) ||
      c.patientId.includes(q) ||
      c.procedure.toLowerCase().includes(q) ||
      c.surgeon.toLowerCase().includes(q)
    );
  });

  const needsAttentionCount = activeDateCases.filter(
    (c) => c.readinessLevel === 'NEEDS_ATTENTION' || c.readinessLevel === 'CRITICAL_HOLD'
  ).length;

  // Handle User Registration
  const handleRegisterSuccess = (newUser: {
    firstName: string;
    lastName: string;
    email: string;
    telephone: string;
  }) => {
    const authRecord: AuthUser = {
      id: `user-${Date.now()}`,
      firstName: newUser.firstName,
      lastName: newUser.lastName,
      email: newUser.email,
      role: 'PRACTICE_ADMIN',
      telephone: newUser.telephone,
      title: 'Attending Physician / Practice Owner',
      practiceName: `${newUser.lastName} Surgical Practice`
    };

    setCurrentUser(authRecord);

    // Update Practice Config Primary Provider with new registrant info
    setPracticeConfig((prev) => ({
      ...prev,
      practiceName: `${newUser.lastName} Surgical Practice & Institute`,
      primaryProvider: {
        ...prev.primaryProvider,
        firstName: newUser.firstName,
        lastName: newUser.lastName,
        email: newUser.email,
        cellPhone: newUser.telephone
      }
    }));

    // Redirect user directly to Configure Practice in Administration
    setAuthView('app');
    setActiveTab('admin');
    setAdminActiveSection('configure-practice');

    showToast(`✓ Welcome Dr. ${newUser.lastName}! Account created. Please complete your Practice Configuration.`);
  };

  // Handle Login Success
  const handleLoginSuccess = (user: AuthUser) => {
    setCurrentUser(user);
    setAuthView('app');
    showToast(`Welcome back, ${user.firstName} ${user.lastName}!`);
  };

  // Handle Logout
  const handleLogout = () => {
    setCurrentUser(null);
    setAuthView('landing');
    showToast('Logged out securely. HIPAA session terminated.');
  };

  // Handle Navigation to specific Administration section
  const handleNavigateAdminSection = (section: AdminActiveSection) => {
    setActiveTab('admin');
    setAdminActiveSection(section);
  };

  // ========================================================
  // ROUTING VIEW: 1. PUBLIC LANDING PAGE
  // ========================================================
  if (authView === 'landing') {
    return (
      <PublicLandingPage
        onNavigateLogin={() => setAuthView('login')}
        onNavigateRegister={() => setAuthView('register')}
        onNavigatePortal={() => setAuthView('portal')}
        onEnterApp={() => {
          setIsSidebarCollapsed(false);
          setAuthView('app');
          showToast('Entered Office Intelligence Live Interactive Demo with full navigation.');
        }}
      />
    );
  }

  // ========================================================
  // ROUTING VIEW: 2. LOGIN PAGE
  // ========================================================
  if (authView === 'login') {
    return (
      <LoginPage
        onLoginSuccess={handleLoginSuccess}
        onNavigateRegister={() => setAuthView('register')}
        onNavigateLanding={() => setAuthView('landing')}
      />
    );
  }

  // ========================================================
  // ROUTING VIEW: 3. REGISTRATION PAGE
  // ========================================================
  if (authView === 'register') {
    return (
      <RegistrationPage
        onRegisterSuccess={handleRegisterSuccess}
        onNavigateLogin={() => setAuthView('login')}
        onNavigateLanding={() => setAuthView('landing')}
      />
    );
  }

  // ========================================================
  // ROUTING VIEW: 4. PATIENT PORTAL PAGE
  // ========================================================
  if (authView === 'portal') {
    return (
      <PatientPortalPage
        onBackToOIApp={() => {
          setAuthView('app');
          showToast('Switched back to Office Intelligence Practice Management OS.');
        }}
        onNavigateLanding={() => setAuthView('landing')}
      />
    );
  }

  // ========================================================
  // ROUTING VIEW: 4. MAIN OFFICE INTELLIGENCE OPERATING APP
  // ========================================================
  return (
    <div className="min-h-screen bg-stone-100/90 text-slate-900 font-sans antialiased flex flex-col overflow-x-hidden selection:bg-teal-500/20 selection:text-teal-900">
      
      {/* Toast Notification Banner */}
      {toastMessage && (
        <div className="fixed top-4 right-4 z-50 bg-slate-900 text-white text-xs font-semibold px-4 py-3 rounded-2xl shadow-2xl border border-slate-700 flex items-center gap-2.5 animate-in slide-in-from-top duration-300 max-w-md">
          <Sparkles className="w-4 h-4 text-teal-300 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Top Header Navigation Bar */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onRefresh={() => showToast('Refreshed real-time surgical schedule & OR status.')}
        onAppointmentBooks={() => {
          setActiveTab('schedule');
          showToast('Switched to Schedule Appointment Books view.');
        }}
        onPrint={() => {
          showToast('Opening print dialog for surgical schedule...');
          window.print();
        }}
        onAddPatient={() => {
          setIsAddPatientModalOpen(true);
        }}
        onOpenAIChat={() => setIsAIChatOpen(true)}
        searchQuery={searchQuery}
        setSearchQuery={setSearchQuery}
        needsAttentionCount={needsAttentionCount}
        currentUser={currentUser}
        onLogout={handleLogout}
        onNavigateLanding={() => setAuthView('landing')}
        onNavigatePortal={() => setAuthView('portal')}
        onNavigateAdminSection={handleNavigateAdminSection}
        practiceConfig={practiceConfig}
      />

      {/* Main Workspace (Full Width to Maximize Screen Real Estate) */}
      <div className="flex-1 flex flex-col min-w-0 pb-20 lg:pb-12">
        {/* Dashboard Body Content */}
        <main className={`w-full mx-auto transition-all ${
          activeTab === 'schedule' 
            ? 'px-1 sm:px-2 py-2 max-w-[99.5vw]' 
            : 'px-3 sm:px-6 lg:px-8 py-4 sm:py-6 space-y-4 sm:space-y-6 max-w-[1700px]'
        }`}>
          
          {/* TAB 1: HOME DASHBOARD */}
          {activeTab === 'home' && (
            <div className="space-y-6">
              
              {/* Practice & Location Dropdown Selector on Main Dashboard */}
              <div className="bg-white rounded-2xl border border-stone-200/90 p-4 shadow-2xs flex flex-wrap items-center justify-between gap-4">
                <div className="flex items-center gap-3">
                  <div className="w-11 h-11 rounded-xl bg-blue-50 text-blue-700 border border-blue-200/80 flex items-center justify-center shrink-0 shadow-2xs">
                    <Building2 className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-[11px] font-bold uppercase tracking-wider text-stone-500">
                        Active Practice Dashboard
                      </span>
                      {practiceConfig.isPrimary && (
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-300">
                          Main Campus
                        </span>
                      )}
                      {practiceConfig.isSatellite && (
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-800 border border-amber-300">
                          Satellite Location
                        </span>
                      )}
                      <span className="text-[10px] font-bold bg-blue-50 text-blue-800 px-2 py-0.5 rounded-full border border-blue-200">
                        {practiceConfig.practiceType}
                      </span>
                    </div>
                    <h1 className="text-lg font-bold text-stone-900 leading-snug">
                      {practiceConfig.practiceName}
                    </h1>
                    <p className="text-xs text-stone-500 flex items-center gap-1.5 mt-0.5 flex-wrap">
                      <MapPin className="w-3.5 h-3.5 text-stone-400 shrink-0" />
                      <span className="font-semibold text-stone-700">{practiceConfig.locationName || `${practiceConfig.city} Facility`}</span>
                      <span>•</span>
                      <span>{practiceConfig.streetAddress}, {practiceConfig.city}, {practiceConfig.state}</span>
                      <span>•</span>
                      <span>Tel: {practiceConfig.telephone}</span>
                    </p>
                  </div>
                </div>

                {/* Dropdown Selector */}
                <div className="relative">
                  <button
                    onClick={() => setIsPracticeDropdownOpen(!isPracticeDropdownOpen)}
                    id="dashboard-practice-selector-btn"
                    className="px-4 py-2.5 bg-stone-50 hover:bg-stone-100 border border-stone-300 hover:border-blue-400 rounded-xl text-xs font-bold text-stone-800 flex items-center gap-2.5 transition-all shadow-2xs cursor-pointer group"
                    title="Choose which practice location to view"
                  >
                    <Building2 className="w-4 h-4 text-blue-700" />
                    <div className="text-left">
                      <div className="text-[10px] text-stone-500 font-normal">Choose Practice Location</div>
                      <div className="text-xs font-bold text-stone-900 truncate max-w-[210px]">
                        {practiceConfig.locationName || practiceConfig.practiceName}
                      </div>
                    </div>
                    <ChevronDown className={`w-4 h-4 text-stone-500 group-hover:text-stone-800 transition-transform ${isPracticeDropdownOpen ? 'rotate-180' : ''}`} />
                  </button>

                  {/* Dropdown Menu */}
                  {isPracticeDropdownOpen && (
                    <div className="absolute right-0 mt-2 w-80 sm:w-96 bg-white rounded-2xl border border-stone-200 shadow-2xl z-30 py-2 animate-in fade-in zoom-in-95">
                      <div className="px-4 py-2.5 border-b border-stone-100 flex items-center justify-between">
                        <span className="text-xs font-bold text-stone-800 uppercase tracking-wider">Select Practice Location</span>
                        <span className="text-[11px] font-semibold text-blue-700 bg-blue-50 px-2 py-0.5 rounded-full border border-blue-200">
                          {practicesList.length} Locations
                        </span>
                      </div>

                      <div className="max-h-72 overflow-y-auto py-1 divide-y divide-stone-100">
                        {practicesList.map((loc) => {
                          const isSelected = loc.id === (practiceConfig.id || selectedPracticeId);
                          return (
                            <button
                              key={loc.id || loc.practiceName}
                              onClick={() => {
                                handleSelectPractice(loc.id || 'loc-1');
                                setIsPracticeDropdownOpen(false);
                              }}
                              className={`w-full text-left px-4 py-3 flex items-start gap-3 hover:bg-stone-50 transition-colors cursor-pointer ${
                                isSelected ? 'bg-blue-50/80' : ''
                              }`}
                            >
                              <div className={`p-2 rounded-lg mt-0.5 shrink-0 ${isSelected ? 'bg-blue-700 text-white' : 'bg-stone-100 text-stone-600'}`}>
                                <Building2 className="w-4 h-4" />
                              </div>
                              <div className="flex-1 min-w-0">
                                <div className="flex items-center justify-between gap-1">
                                  <span className={`text-xs font-bold truncate ${isSelected ? 'text-blue-950' : 'text-stone-900'}`}>
                                    {loc.locationName || loc.practiceName}
                                  </span>
                                  {isSelected && (
                                    <Check className="w-4 h-4 text-blue-700 shrink-0" />
                                  )}
                                </div>
                                <div className="text-[11px] text-stone-600 truncate mt-0.5">
                                  {loc.practiceName}
                                </div>
                                <div className="text-[11px] text-stone-500 flex items-center gap-1.5 mt-1 flex-wrap">
                                  <span className="flex items-center gap-1">
                                    <MapPin className="w-3 h-3 text-stone-400" />
                                    {loc.city}, {loc.state}
                                  </span>
                                  <span>•</span>
                                  <span className="font-semibold text-stone-700">{loc.practiceType}</span>
                                  {loc.isSatellite && (
                                    <span className="text-[9px] bg-amber-100 text-amber-800 px-1.5 py-0.2 rounded-sm font-bold">
                                      Satellite
                                    </span>
                                  )}
                                </div>
                              </div>
                            </button>
                          );
                        })}
                      </div>

                      <div className="p-2 border-t border-stone-100 bg-stone-50/70">
                        <button
                          onClick={() => {
                            setIsPracticeDropdownOpen(false);
                            setActiveTab('admin');
                            setAdminActiveSection('configure-practice');
                          }}
                          className="w-full py-2 px-3 bg-white hover:bg-stone-100 border border-stone-300 rounded-xl text-xs font-bold text-stone-800 flex items-center justify-center gap-1.5 transition-colors cursor-pointer shadow-2xs"
                        >
                          <Plus className="w-3.5 h-3.5 text-blue-700" />
                          <span>Add or Manage Practice Locations</span>
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {/* Top Date Navigation Bar on Home Page */}
              <div className="bg-white rounded-2xl border border-stone-200/90 p-4 shadow-2xs flex flex-wrap items-center justify-between gap-4">
                <div className="flex items-center gap-3.5 flex-wrap">
                  {/* Previous, TODAY, Next Buttons */}
                  <div className="flex items-center gap-2">
                    <button
                      onClick={handlePrevDay}
                      className="p-1.5 border border-stone-300 rounded-lg bg-white hover:bg-stone-100 text-stone-700 shadow-2xs transition-colors cursor-pointer flex items-center justify-center"
                      title="Previous Day"
                    >
                      <ChevronLeft className="w-5 h-5" />
                    </button>

                    <button
                      onClick={handleToday}
                      className="px-4 py-1.5 bg-[#2b3a4a] hover:bg-[#1e2936] text-white font-bold rounded-lg shadow-2xs text-xs transition-colors cursor-pointer tracking-wider uppercase"
                    >
                      TODAY
                    </button>

                    <button
                      onClick={handleNextDay}
                      className="p-1.5 border border-stone-300 rounded-lg bg-white hover:bg-stone-100 text-stone-700 shadow-2xs transition-colors cursor-pointer flex items-center justify-center"
                      title="Next Day"
                    >
                      <ChevronRight className="w-5 h-5" />
                    </button>
                  </div>

                  {/* Current Date Display */}
                  <div className="flex items-center gap-3">
                    <h2 className="text-xl font-serif font-bold text-stone-900 tracking-tight">
                      {formatDisplayDate(selectedDate)}
                    </h2>

                    {isToday ? (
                      <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800 border border-emerald-300 shadow-2xs">
                        Today
                      </span>
                    ) : (
                      <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-stone-100 text-stone-700 border border-stone-200">
                        Scheduled Day
                      </span>
                    )}

                    <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-indigo-50 text-indigo-700 border border-indigo-200">
                      {activeDateCases.length} {activeDateCases.length === 1 ? 'Case' : 'Cases'} Listed
                    </span>

                    {/* View Mode Switcher Bubbles next to Cases Listed tag */}
                    <div className="flex flex-wrap items-center gap-1.5 p-1 bg-stone-100 border border-stone-200/90 rounded-full text-xs font-semibold">
                      <button
                        onClick={() => setScheduleViewMode('PRIORITY')}
                        className={`px-3 py-1 rounded-full transition-all flex items-center gap-1.5 cursor-pointer ${
                          scheduleViewMode === 'PRIORITY'
                            ? 'bg-emerald-900 text-emerald-50 shadow-2xs font-bold'
                            : 'text-stone-700 hover:bg-stone-200/60 hover:text-stone-950'
                        }`}
                      >
                        <Sparkles className="w-3.5 h-3.5 text-emerald-300" />
                        <span>Priority</span>
                      </button>

                      <button
                        onClick={() => setScheduleViewMode('ROOM_FLOW')}
                        className={`px-3 py-1 rounded-full transition-all flex items-center gap-1.5 cursor-pointer ${
                          scheduleViewMode === 'ROOM_FLOW'
                            ? 'bg-emerald-900 text-emerald-50 shadow-2xs font-bold'
                            : 'text-stone-700 hover:bg-stone-200/60 hover:text-stone-950'
                        }`}
                      >
                        <Building2 className="w-3.5 h-3.5 text-emerald-300" />
                        <span>Room Grid</span>
                      </button>

                      <button
                        onClick={() => setScheduleViewMode('BOTTLENECKS')}
                        className={`px-3 py-1 rounded-full transition-all flex items-center gap-1.5 cursor-pointer ${
                          scheduleViewMode === 'BOTTLENECKS'
                            ? 'bg-amber-600 text-white shadow-2xs font-bold'
                            : 'text-stone-700 hover:bg-stone-200/60 hover:text-stone-950'
                        }`}
                      >
                        <AlertTriangle className="w-3.5 h-3.5" />
                        <span>Bottlenecks</span>
                      </button>

                      <button
                        onClick={() => setScheduleViewMode('PIPELINE')}
                        className={`px-3 py-1 rounded-full transition-all flex items-center gap-1.5 cursor-pointer ${
                          scheduleViewMode === 'PIPELINE'
                            ? 'bg-emerald-900 text-emerald-50 shadow-2xs font-bold'
                            : 'text-stone-700 hover:bg-stone-200/60 hover:text-stone-950'
                        }`}
                      >
                        <Layers className="w-3.5 h-3.5 text-emerald-300" />
                        <span>Pipeline</span>
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              {/* Home Dashboard Main Grid */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
                
                {/* Left Column: 2/3 of page (8 cols) */}
                <div className="lg:col-span-8 space-y-6">
                  {/* Today's Surgical Schedule */}
                  <ScheduleIntelligenceBox
                    cases={displayedCases}
                    viewMode={scheduleViewMode}
                    onViewModeChange={setScheduleViewMode}
                    onSelectPatient={handleOpenPatientChart}
                    onUpdateStage={handleUpdateStage}
                    onResolveAction={handleResolveAction}
                    onTriggerEKGFastTrack={handleTriggerEKGFastTrack}
                  />

                  {/* Communication & Waiting For Stats */}
                  <CommunicationWidget
                    stats={stats}
                    onSelectCategory={(cat) => {
                      if (cat.toLowerCase().includes('patient')) {
                        setActiveTab('messages');
                        showToast('Opening Patient Portal Messages & Triage Center...');
                      } else {
                        showToast(`Filtering communication records for ${cat}...`);
                      }
                    }}
                  />
                </div>

                {/* Right Column: 1/3 of page (4 cols) */}
                <div className="lg:col-span-4 space-y-6">
                  {/* Nightingale AI Morning Brief */}
                  <NightingaleBriefBanner
                    cases={activeDateCases}
                    onActionClick={() => handleTriggerEKGFastTrack('case-2')}
                    onFilterNeedsAttention={() => setSearchQuery('DePoli')}
                  />

                  {/* Tasks Widget */}
                  <TasksWidget
                    tasks={tasks}
                    onToggleTask={handleToggleTask}
                  />
                </div>

              </div>
            </div>
          )}

          {/* TAB: PATIENT PORTAL MESSAGES & TRIAGE CENTER */}
          {activeTab === 'messages' && (
            <MessagesPage
              cases={activeDateCases}
              onOpenPatientChart={(patientId, sectionKey) => handleOpenPatientChartById(patientId, sectionKey)}
              onShowToast={showToast}
              onNavigateTab={(tab) => setActiveTab(tab)}
            />
          )}

          {/* TAB 1.5: AI OPERATIONS HOME */}
          {activeTab === 'ai-home' && (
            <AIHomePage
              cases={activeDateCases}
              onSelectPatient={handleOpenPatientChart}
              onOpenPatientChartById={handleOpenPatientChartById}
              onTriggerEKGFastTrack={handleTriggerEKGFastTrack}
              onUpdateStage={handleUpdateStage}
              onShowToast={showToast}
              onNavigateTab={(tab) => setActiveTab(tab)}
            />
          )}

          {/* TAB 2: FULL SCHEDULE MATRIX VIEW */}
          {activeTab === 'schedule' && (
            <ScheduleFullView
              cases={activeDateCases}
              onSelectPatient={handleOpenPatientChart}
              practiceConfig={practiceConfig}
            />
          )}

          {/* TAB 3: BLANK PAGE TEMPLATE */}
          {activeTab === 'template' && (
            <BlankPageTemplate />
          )}

          {/* TAB 4: PATIENT CHARTS */}
          {activeTab === 'patients' && (
            <PatientChartPage
              cases={activeDateCases}
              initialSelectedPatientId={selectedChartPatientId}
              initialSelectedSection={selectedChartSection}
              onOpenPatientModal={(patient) => setSelectedPatient(patient)}
              onNavigateToPortalTab={() => setAuthView('portal')}
            />
          )}

          {/* TAB 5: ADMINISTRATION */}
          {activeTab === 'admin' && (
            <AdministrationPage
              onShowToast={showToast}
              activeSection={adminActiveSection}
              onSectionChange={setAdminActiveSection}
              practiceConfig={practiceConfig}
              practicesList={practicesList}
              activePracticeId={selectedPracticeId}
              onSelectPractice={handleSelectPractice}
              onAddPractice={handleAddPractice}
              onDeletePractice={(practiceId) => {
                if (practicesList.length <= 1) {
                  showToast('Cannot delete the only practice location.');
                  return;
                }
                const remaining = practicesList.filter(p => p.id !== practiceId);
                setPracticesList(remaining);
                if (selectedPracticeId === practiceId) {
                  handleSelectPractice(remaining[0].id || 'loc-1');
                }
                showToast('Practice location removed.');
              }}
              onUpdatePracticeConfig={handleUpdatePracticeConfig}
            />
          )}

          {/* TAB 6: BILLING & INVOICES */}
          {activeTab === 'billing' && (
            <BillingModulePage
              cases={activeDateCases}
              onShowToast={showToast}
            />
          )}

          {/* TAB 7: AI WORKFLOW INTELLIGENCE SUITE */}
          {activeTab === 'workflows' && (
            <AIWorkflowExamples
              cases={activeDateCases}
              onSelectPatient={(patientId) => {
                setSelectedChartPatientId(patientId);
                setActiveTab('patients');
              }}
              onRunWorkflow={(workflowId) => {
                if (workflowId === 'wf-ekg-fasttrack') {
                  handleTriggerEKGFastTrack('case-2');
                }
              }}
              onShowToast={showToast}
            />
          )}

        </main>
      </div>

      {/* Mobile Primary Bottom Navigation Bar (Visible on mobile/tablet < lg) */}
      <nav className="fixed bottom-0 left-0 right-0 z-30 bg-white/95 backdrop-blur-md border-t border-stone-200/90 lg:hidden px-3 py-1.5 flex items-center justify-around shadow-lg">
        <button
          onClick={() => setActiveTab('home')}
          className={`flex flex-col items-center justify-center py-1 px-2 rounded-xl transition-all cursor-pointer ${
            activeTab === 'home' ? 'text-blue-700 font-bold' : 'text-stone-500 hover:text-stone-900'
          }`}
        >
          <Home className={`w-5 h-5 ${activeTab === 'home' ? 'text-blue-700' : 'text-stone-500'}`} />
          <span className="text-[10px] mt-0.5">Home</span>
        </button>

        <button
          onClick={() => setActiveTab('messages')}
          className={`flex flex-col items-center justify-center py-1 px-2 rounded-xl transition-all cursor-pointer relative ${
            activeTab === 'messages' ? 'text-blue-700 font-bold' : 'text-stone-500 hover:text-stone-900'
          }`}
        >
          <MessageSquare className={`w-5 h-5 ${activeTab === 'messages' ? 'text-blue-700' : 'text-stone-500'}`} />
          <span className="text-[10px] mt-0.5">Messages</span>
        </button>

        <button
          onClick={() => setActiveTab('schedule')}
          className={`flex flex-col items-center justify-center py-1 px-2 rounded-xl transition-all cursor-pointer ${
            activeTab === 'schedule' ? 'text-blue-700 font-bold' : 'text-stone-500 hover:text-stone-900'
          }`}
        >
          <Calendar className={`w-5 h-5 ${activeTab === 'schedule' ? 'text-blue-700' : 'text-stone-500'}`} />
          <span className="text-[10px] mt-0.5">Schedule</span>
        </button>

        <button
          onClick={() => setActiveTab('patients')}
          className={`flex flex-col items-center justify-center py-1 px-2 rounded-xl transition-all cursor-pointer relative ${
            activeTab === 'patients' ? 'text-blue-700 font-bold' : 'text-stone-500 hover:text-stone-900'
          }`}
        >
          <FileText className={`w-5 h-5 ${activeTab === 'patients' ? 'text-blue-700' : 'text-stone-500'}`} />
          {needsAttentionCount > 0 && (
            <span className="absolute top-0 right-1 w-2 h-2 bg-amber-500 rounded-full ring-2 ring-white" />
          )}
          <span className="text-[10px] mt-0.5">Patients</span>
        </button>

        <button
          onClick={() => setIsSidebarCollapsed(false)}
          className="flex flex-col items-center justify-center py-1 px-2 rounded-xl transition-all cursor-pointer text-stone-500 hover:text-stone-900"
        >
          <Sliders className="w-5 h-5 text-stone-500" />
          <span className="text-[10px] mt-0.5">More</span>
        </button>
      </nav>

      {/* Floating AI Super-Intelligence Button */}
      {!isAIChatOpen && (
        <button
          onClick={() => setIsAIChatOpen(true)}
          className="fixed bottom-16 lg:bottom-6 right-4 sm:right-6 z-40 bg-gradient-to-r from-blue-700 via-blue-800 to-indigo-900 hover:from-blue-800 hover:to-indigo-950 text-white p-3 rounded-full sm:p-3.5 shadow-2xl hover:shadow-indigo-500/50 flex items-center gap-2.5 transition-all duration-300 hover:scale-105 active:scale-95 cursor-pointer border border-white/20 group"
          title="Open Nightingale AI Assistant"
          id="floating-ai-assistant-trigger"
        >
          <div className="relative">
            <Sparkles className="w-5 h-5 text-teal-300 animate-spin-slow group-hover:rotate-12 transition-transform" />
            <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-emerald-400 rounded-full ring-2 ring-blue-700 animate-ping" />
            <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-emerald-400 rounded-full ring-2 ring-blue-700" />
          </div>
          <span className="text-xs font-bold tracking-wide pr-1 hidden sm:inline">Ask AI</span>
        </button>
      )}

      {/* Patient Detail Modal */}
      <PatientDetailModal
        patient={selectedPatient}
        onClose={() => setSelectedPatient(null)}
        onUpdateStage={handleUpdateStage}
        onToggleAction={handleResolveAction}
        onTriggerEKGFastTrack={handleTriggerEKGFastTrack}
        onOpenChart={handleOpenPatientChart}
      />

      {/* Nightingale AI Chat Drawer */}
      <NightingaleAIChatDrawer
        isOpen={isAIChatOpen}
        onClose={() => setIsAIChatOpen(false)}
        scheduleCases={activeDateCases}
      />

      {/* Add New Patient Record Modal */}
      <AddPatientModal
        isOpen={isAddPatientModalOpen}
        onClose={() => setIsAddPatientModalOpen(false)}
        onAddPatient={(newPatient) => {
          updateActiveCases((prev) => [newPatient, ...prev]);
          setSelectedChartPatientId(newPatient.id);
          setActiveTab('patients');
          showToast(`Created patient record for ${newPatient.name}!`);
        }}
      />

    </div>
  );
}
