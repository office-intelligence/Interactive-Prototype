import React, { useState } from 'react';
import { Timer } from 'lucide-react';
import { repo, nowIso } from './dataLayer';
import { nowHHMM } from './formRules';

/* One shared OR event-time bar. Each event is tapped once by whoever is free
 * (circulator or anesthesia) and appears on every intra-op form and the op note.
 * v7.5: after a time exists, staff can edit to a corrected clock time (not only replace-with-now). */
export const OR_EVENTS: { id: string; label: string }[] = [
  { id: 'time.inOR', label: 'In room' }, { id: 'time.anesStart', label: 'Anesthesia start' }, { id: 'time.incision', label: 'Incision' },
  { id: 'time.closure', label: 'Closure' }, { id: 'time.anesEnd', label: 'Anesthesia end' }, { id: 'time.outOR', label: 'Out of room' },
];

const HHMM = /^([01]?\d|2[0-3]):([0-5]\d)$/;
function normalizeHHMM(raw: string): string | null {
  const t = String(raw || '').trim();
  const m = t.match(HHMM);
  if (!m) return null;
  return `${m[1].padStart(2, '0')}:${m[2]}`;
}

/** MED v0.1: `events` / `title` let the office visit reuse the bar for visit timestamps; ASC defaults are unchanged. */
export const EventBar: React.FC<{ caseId: string; disabled?: boolean; onStamp?: (concept: string, value: string) => void; events?: { id: string; label: string }[]; title?: string }> = ({ caseId, disabled, onStamp, events = OR_EVENTS, title = 'OR event times' }) => {
  const barLabel = title === 'OR event times' ? 'OR event bar' : title;
  const [, force] = useState(0);
  const [editing, setEditing] = useState<string | null>(null);
  const [draft, setDraft] = useState('');
  const [err, setErr] = useState('');
  const facts = repo.getFacts(caseId);

  const write = (id: string, label: string, v: string, prev?: string, action: 'event.time' | 'event.time.edit' = 'event.time') => {
    const a = repo.getActor();
    repo.putFacts(caseId, [{ concept: id, value: v, source: { kind: 'event', label: `${barLabel} · ${label}`, formTitle: barLabel, by: a.name, at: nowIso() } }]);
    const detail = prev && prev !== v ? `${label}: ${prev} → ${v}` : `${label} = ${v}`;
    repo.audit({ caseId, user: a.name, role: a.role, action, detail });
    onStamp?.(id, v); force(x => x + 1);
  };

  const stampNow = (id: string, label: string) => {
    const cur = facts[id]?.value as string | undefined;
    const v = nowHHMM();
    if (cur) {
      // Prefer the edit panel when a time already exists
      setEditing(id); setDraft(cur); setErr(''); return;
    }
    write(id, label, v);
  };

  const openEdit = (id: string, cur: string) => {
    if (disabled) return;
    setEditing(id); setDraft(cur); setErr('');
  };

  const saveEdit = (id: string, label: string) => {
    const cur = facts[id]?.value as string | undefined;
    const v = normalizeHHMM(draft);
    if (!v) { setErr('Enter time as HH:MM (24-hour)'); return; }
    write(id, label, v, cur, 'event.time.edit');
    setEditing(null); setDraft(''); setErr('');
  };

  return <section className="bg-white border border-[#dfe5e1] rounded-lg p-4" aria-label={title}>
    <div className="flex items-center gap-2 flex-wrap"><Timer size={18} className="text-[#1f6e52]" /><b className="text-[16px]">{title}</b><span className="text-[14px] text-[#4a5750]">— tap once to stamp; tap again to edit a corrected time</span></div>
    <div className="grid grid-cols-3 lg:grid-cols-6 gap-2 mt-3">{events.map(e => {
      const v = facts[e.id]?.value as string | undefined;
      const isEdit = editing === e.id;
      if (isEdit) {
        return <div key={e.id} className="min-h-[56px] rounded-lg border border-[#1f6e52] bg-[#f3faf6] px-2 py-2 text-left col-span-1" data-testid={`event-edit-${e.id}`}>
          <div className="text-[12px] font-bold text-[#4a5750] uppercase tracking-wide">{e.label}</div>
          <input type="time" className="v6-input mt-1 w-full min-h-[36px] text-[16px] font-bold" value={draft} onChange={ev => { setDraft(ev.target.value); setErr(''); }} aria-label={`Edit ${e.label}`} data-testid={`event-input-${e.id}`} disabled={disabled} />
          {err && <div className="text-[12px] text-[#8A1F1F] mt-0.5">{err}</div>}
          <div className="flex flex-wrap gap-1 mt-1">
            <button type="button" disabled={disabled} className="v6-btn vy-btn-confirm !min-h-[32px] !px-2 !text-[13px]" data-testid={`event-save-${e.id}`} onClick={() => saveEdit(e.id, e.label)}>Save</button>
            <button type="button" disabled={disabled} className="v6-btn v6-btn-secondary !min-h-[32px] !px-2 !text-[13px]" onClick={() => { const n = nowHHMM(); setDraft(n); setErr(''); }} data-testid={`event-now-${e.id}`}>Now</button>
            <button type="button" disabled={disabled} className="v6-btn v6-btn-secondary !min-h-[32px] !px-2 !text-[13px]" onClick={() => { setEditing(null); setErr(''); }}>Cancel</button>
          </div>
        </div>;
      }
      return <button key={e.id} type="button" disabled={disabled} onClick={() => v ? openEdit(e.id, v) : stampNow(e.id, e.label)} data-testid={`event-${e.id}`} className={`min-h-[56px] rounded-lg border px-2 py-2 text-left ${v ? 'border-[#bcd9ca] bg-[#f3faf6]' : 'border-[#9aa8a0] bg-white'}`}>
        <div className="text-[13px] font-bold text-[#4a5750] uppercase tracking-wide">{e.label}</div>
        <div className="text-[18px] font-bold text-[#10241b]">{v || 'Tap'}</div>
        {v && <div className="text-[12px] text-[#1f6e52] font-semibold mt-0.5">Edit</div>}
      </button>;
    })}</div>
  </section>;
};
