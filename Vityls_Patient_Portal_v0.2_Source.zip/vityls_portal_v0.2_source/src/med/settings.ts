/*
 * MED practice settings (test build: browser storage, MED namespace). Server: practice_settings.
 * Nothing here ships with a clinical number: numeric risk triggers and result bands start EMPTY and DISABLED,
 * and need a named medical-director approval before they do anything.
 */
import { repo } from '../v6/dataLayer';
import { ping } from './record';

export interface NumericTrigger { id: 'bmi' | 'a1c' | 'bpSys' | 'bpDia'; label: string; unit: string; source: 'vitals' | 'lab'; labTest?: string; enabled: boolean; operator: '>=' | '<='; value: number | null; approvedBy: string; approvedOn: string }
export interface ResultBand { test: string; low: number | null; high: number | null; approvedBy: string; approvedOn: string }
export interface FeeItem { id: string; name: string; visitType?: string; price: number; code: string; active: boolean }
export interface MedSettings {
  autoReleaseResults: boolean;
  triggers: NumericTrigger[];
  bands: ResultBand[];
  labDescriptions: Record<string, string>;
  fees: FeeItem[];
  features: { chronicRegistries: boolean; remoteMonitoring: boolean };
  practiceName: string; ascName: string;
}
export const DEFAULT_SETTINGS: MedSettings = {
  autoReleaseResults: false,
  triggers: [
    { id: 'bmi', label: 'BMI', unit: 'kg/m²', source: 'vitals', enabled: false, operator: '>=', value: null, approvedBy: '', approvedOn: '' },
    { id: 'a1c', label: 'Hemoglobin A1c', unit: '%', source: 'lab', labTest: 'Hemoglobin A1c', enabled: false, operator: '>=', value: null, approvedBy: '', approvedOn: '' },
    { id: 'bpSys', label: 'Systolic blood pressure', unit: 'mmHg', source: 'vitals', enabled: false, operator: '>=', value: null, approvedBy: '', approvedOn: '' },
    { id: 'bpDia', label: 'Diastolic blood pressure', unit: 'mmHg', source: 'vitals', enabled: false, operator: '>=', value: null, approvedBy: '', approvedOn: '' },
  ],
  bands: [],
  // Plain-English "what this test is" text. Practice-editable; describes the test only, never a range or a verdict.
  labDescriptions: {
    'Hemoglobin A1c': 'A blood test that reflects your average blood sugar over the past few months.',
    'Hemoglobin': 'The protein in red blood cells that carries oxygen around the body.',
    'Platelets': 'Blood cells that help your blood clot.',
    'Creatinine': 'A waste product filtered by the kidneys; it is used to check how well the kidneys are working.',
    'Potassium': 'A mineral that helps nerves and muscles, including the heart, work properly.',
    'INR': 'Measures how long your blood takes to clot. It is often used to monitor blood-thinning medicine.',
    'LDL cholesterol': 'One type of cholesterol carried in the blood.',
    'Glucose': 'The amount of sugar in your blood at the time of the test.',
  },
  fees: [
    { id: 'fee-cosmetic', name: 'Cosmetic consultation', visitType: 'Cosmetic consultation', price: 150, code: '', active: true },
    { id: 'fee-presurg', name: 'Pre-surgical consult', visitType: 'Pre-surgical consult', price: 200, code: '', active: true },
    { id: 'fee-postop', name: 'Post-op follow-up (global period)', visitType: 'Post-op follow-up', price: 0, code: '', active: true },
    { id: 'fee-inject', name: 'Injectables / filler visit', visitType: 'Injectables / filler', price: 100, code: '', active: true },
    { id: 'fee-skin', name: 'Skin check', visitType: 'Skin check', price: 125, code: '', active: true },
    { id: 'fee-est', name: 'Established patient visit', visitType: 'Established patient visit', price: 125, code: '', active: true },
    { id: 'fee-product', name: 'Product / supply (enter amount)', price: 0, code: '', active: true },
  ],
  features: { chronicRegistries: false, remoteMonitoring: false },
  practiceName: 'Coastline Plastic Surgery (fictional)', ascName: 'Harborview Surgery Center (fictional network ASC)',
};
const KEY = 'vityls:med:settings';
export function getSettings(): MedSettings {
  try { const r = localStorage.getItem(KEY); if (r) { const s = JSON.parse(r); return { ...DEFAULT_SETTINGS, ...s, features: { ...DEFAULT_SETTINGS.features, ...(s.features || {}) } }; } } catch { /* */ }
  return DEFAULT_SETTINGS;
}
export function saveSettings(s: MedSettings, by: string, role: string, what: string, action: 'risk.settings' | 'lab.settings' | 'fee.schedule' = 'lab.settings') {
  localStorage.setItem(KEY, JSON.stringify(s)); ping();
  repo.audit({ caseId: 'practice', user: by, role, action, detail: what });
}
export const fmtMoney = (n: number) => `$${(n || 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
