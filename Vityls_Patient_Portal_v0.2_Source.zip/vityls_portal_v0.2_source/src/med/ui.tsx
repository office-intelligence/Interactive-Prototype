/* MED v0.1 shared UI bits. Vityls green palette; teal (#0f766e family) is reserved for Nightingale. */
import React, { useEffect, useState } from 'react';
import { repo, Actor } from '../v6/dataLayer';

export const MED_ACTORS: Actor[] = [
  { name: 'Front Desk Tester', role: 'Front desk', kind: 'human' },
  { name: 'Morgan Avery', role: 'Medical assistant', credentials: 'MA', kind: 'human' },
  { name: 'Casey Morgan', role: 'RN', credentials: 'RN', kind: 'human' },
  { name: 'Sam Patel, MD', role: 'Surgeon', credentials: 'MD', kind: 'human' },
  { name: 'Dana Whitfield, MD', role: 'Surgeon', credentials: 'MD', kind: 'human' },
  { name: 'Jamie Ortiz, NP', role: 'Nurse practitioner', credentials: 'NP', kind: 'human' },
  { name: 'Pat Quinn', role: 'Practice Manager', kind: 'human' },
  { name: 'Practice Administrator', role: 'Practice Administrator', kind: 'human' },
];
/** Re-render on MED / billing / form updates. */
export function useMedTick() {
  const [t, setT] = useState(0);
  useEffect(() => { const f = () => setT(x => x + 1); const ev = ['vityls-med-updated', 'vityls-billing-updated', 'vityls-actor-updated', 'storage']; ev.forEach(e => window.addEventListener(e, f)); return () => ev.forEach(e => window.removeEventListener(e, f)); }, []);
  return t;
}
export function useActor(): [Actor, (a: Actor) => void] {
  useMedTick();
  const a = repo.getActor();
  return [a, (n: Actor) => { repo.setActor(n); window.dispatchEvent(new Event('vityls-actor-updated')); }];
}
export const ActingAs: React.FC<{ compact?: boolean }> = ({ compact }) => {
  const [a, setA] = useActor();
  return <label className={`flex items-center gap-2 ${compact ? 'text-[13.5px]' : 'text-[14px]'}`} data-testid="acting-as"><span className="font-semibold text-[#39443E] whitespace-nowrap">Acting as</span>
    <select className="vy-input !min-h-[38px] !py-1 !text-[14px] max-w-[230px]" value={a.name} onChange={e => { const n = MED_ACTORS.find(x => x.name === e.target.value); if (n) setA(n); }}>
      {!MED_ACTORS.some(x => x.name === a.name) && <option value={a.name}>{a.name} ({a.role})</option>}
      {MED_ACTORS.map(x => <option key={x.name} value={x.name}>{x.name} · {x.role}</option>)}
    </select></label>;
};
export const Chip: React.FC<{ tone?: 'ok' | 'warn' | 'bad' | 'info' | 'muted'; children: React.ReactNode; testId?: string }> = ({ tone = 'muted', children, testId }) => <span className={`vy-chip vy-chip-${tone}`} data-testid={testId}>{children}</span>;
export const Card: React.FC<{ title?: React.ReactNode; kicker?: string; right?: React.ReactNode; children: React.ReactNode; className?: string; testId?: string; tone?: 'nightingale' }> = ({ title, kicker, right, children, className = '', testId, tone }) =>
  <section className={`vy-card p-4 ${tone === 'nightingale' ? '!border-[#99d5cf] !bg-[#f2fbfa]' : ''} ${className}`} data-testid={testId}>
    {(title || kicker || right) && <div className="flex items-start justify-between gap-3 mb-3"><div className="min-w-0">{kicker && <div className={`vy-kicker ${tone === 'nightingale' ? '!text-[#0f766e]' : ''}`}>{kicker}</div>}{title && <h3 className="vy-card-title">{title}</h3>}</div>{right && <div className="flex-none flex gap-2 flex-wrap justify-end">{right}</div>}</div>}
    {children}
  </section>;
export const SimBadge: React.FC<{ text?: string }> = ({ text = 'Simulated until the backend exists' }) => <span className="inline-flex items-center rounded-md border border-[#e3c27c] bg-[#fff3dc] text-[#5c3d05] px-2 py-0.5 text-[12.5px] font-semibold" data-testid="sim-badge">{text}</span>;
export const Empty: React.FC<{ children: React.ReactNode }> = ({ children }) => <p className="text-[14px] text-[#5f6862] italic">{children}</p>;

/** Simple SVG trend line. Optional practice band (shaded) only when configured; otherwise neutral. */
export const TrendChart: React.FC<{ points: { date: string; value: number }[]; unit?: string; band?: { low: number | null; high: number | null } | null; height?: number; testId?: string; color?: string; second?: { date: string; value: number }[] }> = ({ points, unit = '', band, height = 140, testId, color = '#1f6e52', second }) => {
  if (!points.length) return <Empty>No values recorded.</Empty>;
  const W = 560, H = height, P = 34;
  const all = [...points, ...(second || [])].map(p => p.value).concat(band ? [band.low, band.high].filter((x): x is number => x != null) : []);
  let min = Math.min(...all), max = Math.max(...all); if (min === max) { min -= 1; max += 1; } const pad = (max - min) * 0.15; min -= pad; max += pad;
  const ts = [...points, ...(second || [])].map(p => new Date(p.date).getTime()); let t0 = Math.min(...ts), t1 = Math.max(...ts); if (t0 === t1) { t0 -= 864e5; t1 += 864e5; }
  const x = (d: string) => P + (W - P - 10) * ((new Date(d).getTime() - t0) / (t1 - t0)); const y = (v: number) => H - 22 - (H - 34) * ((v - min) / (max - min));
  const path = (pts: { date: string; value: number }[]) => pts.map((p, i) => `${i ? 'L' : 'M'}${x(p.date).toFixed(1)},${y(p.value).toFixed(1)}`).join(' ');
  return <svg viewBox={`0 0 ${W} ${H}`} className="w-full h-auto" role="img" aria-label={`Trend ${unit}`} data-testid={testId}>
    {band && (band.low != null || band.high != null) && <rect x={P} width={W - P - 10} y={y(band.high ?? max)} height={Math.max(0, y(band.low ?? min) - y(band.high ?? max))} fill="#e3f2e9" />}
    <line x1={P} x2={W - 10} y1={H - 22} y2={H - 22} stroke="#cfd8d2" />
    {[min + pad, max - pad].map((v, i) => <text key={i} x={2} y={y(v) + 4} fontSize="11" fill="#5f6862">{Math.round(v * 10) / 10}</text>)}
    {second && <path d={path(second)} fill="none" stroke="#7a8a80" strokeWidth={2} strokeDasharray="5 4" />}
    <path d={path(points)} fill="none" stroke={color} strokeWidth={2.5} />
    {points.map((p, i) => <g key={i}><circle cx={x(p.date)} cy={y(p.value)} r={4} fill={color} /><text x={x(p.date)} y={y(p.value) - 8} fontSize="11.5" textAnchor="middle" fill="#1f2b25">{p.value}</text><text x={x(p.date)} y={H - 6} fontSize="10.5" textAnchor="middle" fill="#5f6862">{new Date(p.date).toLocaleDateString([], { month: 'numeric', year: '2-digit' })}</text></g>)}
  </svg>;
};
/** Print-on-demand helper (PDF via the browser's Print > Save as PDF). Never automatic. */
export function printHtml(title: string, body: string) {
  const w = window.open('', '_blank'); if (!w) { alert('Allow pop-ups to print.'); return; }
  w.document.write(`<!doctype html><html><head><meta charset="utf-8"><title>${title}</title><style>body{font-family:'Source Sans 3',system-ui,sans-serif;color:#1f2b25;margin:28px;font-size:14px}h1{font-family:'Cormorant Garamond',Georgia,serif;font-size:26px;margin:0 0 4px}h2{font-size:15px;text-transform:uppercase;letter-spacing:.06em;color:#1d5f47;margin:18px 0 6px}table{border-collapse:collapse;width:100%}td,th{border:1px solid #cfd8d2;padding:5px 7px;text-align:left;vertical-align:top}.muted{color:#5f6862}.wallet{width:3.4in;border:1px solid #999;padding:8px;font-size:11px}</style></head><body>${body}<p class="muted" style="margin-top:24px">MED.Vityls test build · fictional data · printed ${new Date().toLocaleString()}</p><script>setTimeout(function(){window.print()},300)</script></body></html>`);
  w.document.close();
}
export const esc = (s: string) => String(s ?? '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' } as any)[c]);
