/*
 * Surgery.Vityls v0.6 · Appointment detail (click a visit on the schedule).
 * Same layout as New appointment, filled in: patient, visit type, date, time, provider, room, reason, plus status
 * (station step, confirmation/reminders). A visit that has not started can be edited (moving it clears the
 * confirmation and restarts reminders) or deleted. Buttons: Open chart, Visit workflow, Save changes, Delete.
 * Delete asks for a reason and the PIN of whoever deletes it (anyone on the care team), and is audited.
 * Visits that have started belong to the medical record and cannot be deleted.
 * Henry: PATCH /visits/{id}; DELETE /visits/{id} {reason} → soft-cancel row (`visits.cancelled_at/by/reason`),
 * cancel pending reminders, clear confirmation.
 */
import React, { useState } from 'react';
import { Trash2, FolderOpen, Stethoscope } from 'lucide-react';
import { DialogShell } from '../v7/ui';
import { repo } from '../v6/dataLayer';
import { medRepo, MedVisit, usDate, toMin, ageFrom, patientKey, fmtDateTime, ping } from '../med/record';
import { MED_ROOMS } from '../med/seed';
import { useActor } from '../med/ui';
import { activeVisitTypes, ascBlocks, edgeOf, modules, svRead, svWrite } from './store';
import { notesOf, ApptNotesEditor } from './v11/apptNotes';
import { VisitLength } from './v10/VisitLength';
import { STATION_LABEL } from './nightingale';
import { ConfBadge, ReminderDialog, reminderSends, confirmationOf } from './reminders';
import { PinSign } from './sign';
import { ROLE_GROUP } from './staff';
import { useSv } from './ui';

const at = (t: string) => +toMin(t);
const norm = (s: string) => s.toLowerCase().replace(/^dr\.?\s+/, '').replace(/,.*$/, '').trim();
const TIME = /^\d{1,2}:\d{2}\s?(AM|PM)$/i;
export const DELETE_REASONS = ['Patient cancelled', 'Booked in error', 'Duplicate appointment', 'No-show', 'Provider unavailable', 'Other'];
export interface DeletedVisit { visit: MedVisit; reason: string; note: string; by: string; role: string; at: string; session: string }

/** Clear the confirmation and park the old reminder history so the scheduler starts fresh for the new time. */
function resetReminders(visitId: string) {
  const sends = reminderSends(); const mine = sends.filter(s => s.visitId === visitId);
  if (mine.length) { svWrite('reminder-sends-archive', [...svRead<unknown[]>('reminder-sends-archive', []), ...mine]); svWrite('reminder-sends', sends.filter(s => s.visitId !== visitId)); }
  const c = svRead<Record<string, unknown>>('appt-confirm', {}); if (c[visitId]) { delete c[visitId]; svWrite('appt-confirm', c); }
}
export function deleteVisit(v: MedVisit, reason: string, note: string, w: { name: string; role: string; at: string }, session: string) {
  if (v.step !== 'scheduled') throw new Error('This visit has started and is part of the medical record; it cannot be deleted.');
  const list = JSON.parse(localStorage.getItem('vityls:med:visits') || '[]') as MedVisit[];
  localStorage.setItem('vityls:med:visits', JSON.stringify(list.filter(x => x.id !== v.id)));
  resetReminders(v.id);
  svWrite('deleted-visits', [...svRead<DeletedVisit[]>('deleted-visits', []), { visit: v, reason, note, by: w.name, role: w.role, at: w.at, session }]);
  repo.audit({ caseId: patientKey(v.patientId), user: w.name, role: w.role, action: 'appointment.delete', detail: `Appointment deleted: ${v.visitType} ${usDate(v.date)} ${v.time} with ${v.provider} · ${reason}${note ? ` · ${note}` : ''} · confirmed with ${w.name}’s PIN (tablet session: ${session}). Pending reminders cancelled.` });
  ping();
}

export const AppointmentDetail: React.FC<{ visitId: string; providers: string[]; onClose: () => void }> = ({ visitId, providers, onClose }) => {
  const [actor] = useActor(); const { go, toast } = useSv(); const v0 = medRepo.visit(visitId);
  const [f, setF] = useState(() => v0 ? { date: v0.date, time: v0.time, provider: v0.provider, room: v0.room, visitType: v0.visitType, reason: v0.reason, notes: notesOf(v0), duration: v0.durationMin } : null);
  const [err, setErr] = useState(''); const [del, setDel] = useState(false); const [delReason, setDelReason] = useState(''); const [delNote, setDelNote] = useState(''); const [pin, setPin] = useState(false); const [rm, setRm] = useState(false);
  if (!v0 || !f) return null;
  const pt = medRepo.patient(v0.patientId); const editable = v0.step === 'scheduled'; const types = activeVisitTypes();
  const typeList = types.some(t => t.name === f.visitType) ? types : [...types, { id: 'cur', name: f.visitType, color: '#F1F5F9', durationMin: f.duration } as any];
  const dirty = f.date !== v0.date || f.time.trim().toUpperCase() !== v0.time || f.provider !== v0.provider || f.room !== v0.room || f.visitType !== v0.visitType || f.reason !== v0.reason || f.duration !== v0.durationMin || f.notes.trim() !== notesOf(v0);
  const moved = f.date !== v0.date || f.time.trim().toUpperCase() !== v0.time;
  const save = () => {
    if (!TIME.test(f.time.trim())) { setErr('Time must look like 09:30 AM.'); return; }
    const v: MedVisit = { ...v0, date: f.date, time: f.time.trim().toUpperCase(), provider: f.provider, room: f.room, visitType: f.visitType, reason: f.reason, durationMin: f.duration, notes: f.notes.trim() || undefined } as MedVisit;
    medRepo.saveVisit(v); if (moved) resetReminders(v.id);
    const ch = [v0.date !== v.date || v0.time !== v.time ? `moved ${usDate(v0.date)} ${v0.time} → ${usDate(v.date)} ${v.time}` : '', v0.provider !== v.provider ? `provider ${v0.provider} → ${v.provider}` : '', v0.room !== v.room ? `room ${v.room}` : '', v0.visitType !== v.visitType ? `type ${v.visitType}` : '', v0.reason !== v.reason ? 'reason edited' : ''].filter(Boolean).join(' · ');
    repo.audit({ caseId: patientKey(v.patientId), user: actor.name, role: actor.role, action: 'appointment.update', detail: `Appointment updated (${pt?.name}): ${ch || 'details edited'}${moved ? ' · confirmation cleared, reminders restart' : ''}` });
    toast(moved ? 'Appointment moved. Confirmation cleared; reminders restart for the new time (simulated).' : 'Appointment updated.'); onClose();
  };
  const blk = modules().blockTime && TIME.test(f.time.trim()) ? ascBlocks().find(b => b.date === f.date && norm(b.surgeon) === norm(f.provider) && at(f.time) < at(b.end) && at(f.time) + f.duration > at(b.start)) : undefined;
  const clash = TIME.test(f.time.trim()) ? medRepo.visits().find(x => x.id !== v0.id && x.date === f.date && norm(x.provider) === norm(f.provider) && at(x.time) < at(f.time) + f.duration && at(x.time) + x.durationMin > at(f.time)) : undefined;
  const c = confirmationOf(v0.id); const sent = reminderSends(v0.id).length;
  return <div className="sv-flat sv-dlg"><DialogShell title="Appointment" subtitle={`${new Date(v0.date + 'T12:00').toLocaleDateString([], { weekday: 'long', month: 'long', day: 'numeric' })} · ${v0.time.replace(/^0/, '')} · ${v0.provider}`} onClose={onClose} size="md" testId="appt-detail"
    footer={<div className="flex flex-wrap items-center gap-2 w-full">
      <button type="button" className="sv-btn danger inline-flex items-center gap-1" onClick={() => setDel(true)} disabled={!editable} title={editable ? 'Delete this appointment' : 'This visit has started; it is part of the record'} data-testid="appt-delete"><Trash2 size={15} />Delete appointment</button>
      <span className="flex-1" />
      <button type="button" className="sv-btn inline-flex items-center gap-1" onClick={() => { onClose(); go({ type: 'chart', pid: v0.patientId }); }} data-testid="appt-open-chart"><FolderOpen size={15} />Open chart</button>
      <button type="button" className="sv-btn inline-flex items-center gap-1" onClick={() => { onClose(); go({ type: 'station', visitId: v0.id }); }} data-testid="appt-open-workflow"><Stethoscope size={15} />Visit workflow</button>
      {editable && <button type="button" className="sv-btn primary" disabled={!dirty} onClick={save} data-testid="appt-save">Save changes</button>}
    </div>}>
    <div className="grid sm:grid-cols-2 gap-3">
      <div className="sm:col-span-2"><span className="sv-label">Patient</span><div className="flex flex-wrap items-center gap-2 text-[14px]"><b data-testid="appt-patient">{pt?.name || 'Unknown patient'}</b>{pt && <span className="sv-muted">DOB {pt.dob} · {ageFrom(pt.dob)} · {pt.sex} · {pt.id} · {pt.phone}</span>}</div></div>
      <div className="sm:col-span-2 flex flex-wrap items-center gap-2 text-[13px]" data-testid="appt-status"><span className="sv-tag">{STATION_LABEL[v0.step]}</span>{v0.step === 'scheduled' && <button type="button" className="contents" onClick={() => setRm(true)}><ConfBadge v={v0} /></button>}<span className="sv-muted">{sent} reminder{sent === 1 ? '' : 's'} sent{c ? ` · confirmed ${fmtDateTime(c.at)}` : ''} · booked by {v0.createdBy} {fmtDateTime(v0.createdAt)}</span>{v0.step === 'scheduled' && <button type="button" className="sv-link sv-small" onClick={() => setRm(true)} data-testid="appt-reminders">Reminders</button>}</div>
      <div className="sm:col-span-2"><span className="sv-label">Visit type</span><div className="flex flex-wrap gap-1.5" role="radiogroup" aria-label="Visit type">{typeList.map(t => <button key={t.id} type="button" role="radio" disabled={!editable} aria-checked={f.visitType === t.name} onClick={() => setF({ ...f, visitType: t.name, duration: t.durationMin })} className="text-[13px] px-2.5 py-1.5 rounded" style={{ background: t.color, border: `1px solid ${f.visitType === t.name ? '#111418' : edgeOf(t.color)}`, fontWeight: f.visitType === t.name ? 700 : 400, boxShadow: f.visitType === t.name ? '0 0 0 1px #111418' : undefined, opacity: !editable && f.visitType !== t.name ? .45 : 1 }}>{t.name} · {t.durationMin}m</button>)}</div></div>
      <label><span className="sv-label">Date</span><input type="date" className="sv-input" disabled={!editable} value={f.date} onChange={e => setF({ ...f, date: e.target.value })} data-testid="appt-date" /></label>
      <label><span className="sv-label">Time</span><input className="sv-input" disabled={!editable} value={f.time} onChange={e => setF({ ...f, time: e.target.value })} data-testid="appt-time" /></label>
      <VisitLength prefix="appt" disabled={!editable} start={f.time} duration={f.duration} onChange={n => setF(x => x && ({ ...x, duration: n }))} />
      <label><span className="sv-label">Provider</span><select className="sv-input" disabled={!editable} value={f.provider} onChange={e => setF({ ...f, provider: e.target.value })}>{[...new Set([f.provider, ...providers])].map(p => <option key={p}>{p}</option>)}</select></label>
      <label><span className="sv-label">Room</span><select className="sv-input" disabled={!editable} value={f.room} onChange={e => setF({ ...f, room: e.target.value })}>{[...new Set([f.room, ...MED_ROOMS])].map(r => <option key={r}>{r}</option>)}</select></label>
      <label className="sm:col-span-2"><span className="sv-label">Reason for visit</span><input className="sv-input" disabled={!editable} value={f.reason} onChange={e => setF({ ...f, reason: e.target.value })} data-testid="appt-reason" /></label>
      {editable ? <label className="sm:col-span-2"><span className="sv-label">Appointment notes</span><textarea className="sv-input" rows={2} value={f.notes} onChange={e => setF({ ...f, notes: e.target.value })} data-testid="appt-notes" style={{ width: '100%', resize: 'vertical' }} /></label> : <div className="sm:col-span-2"><ApptNotesEditor v={v0} testId="appt-notes-ed" /></div>}
      {editable && moved && <p className="text-[12.5px] sv-muted sm:col-span-2">Moving the appointment clears its confirmation and restarts reminders for the new time.</p>}
      {blk && <p className="text-[13px] text-[var(--warn)] sm:col-span-2">Heads-up: {f.provider.replace(/,.*$/, '')} is at the ASC ({blk.start.replace(/^0/, '')}–{blk.end.replace(/^0/, '')}, {blk.room}) at this time.</p>}
      {clash && <p className="text-[13px] text-[var(--warn)] sm:col-span-2">Overlaps {clash.time.replace(/^0/, '')} · {medRepo.patient(clash.patientId)?.name} ({clash.visitType}).</p>}
      {!editable && <p className="text-[12.5px] sv-muted sm:col-span-2">This visit has started ({STATION_LABEL[v0.step]}), so it is part of the medical record: it can be opened but not edited or deleted here.</p>}
      {err && <p className="text-[13px] text-[var(--crit)] sm:col-span-2">{err}</p>}
    </div>
    {del && <div className="sv-modal" role="dialog" aria-modal="true" aria-label="Delete appointment" data-testid="appt-delete-confirm"><div className="sv-modal-scrim" onClick={() => setDel(false)} /><div className="sv-modal-box">
      <b className="text-[15px] flex items-center gap-1.5"><Trash2 size={16} />Delete this appointment?</b>
      <p className="text-[13px] my-2"><b>{pt?.name}</b> · {v0.visitType} · {usDate(v0.date)} {v0.time.replace(/^0/, '')} · {v0.provider}</p>
      <label className="block mb-2"><span className="sv-label">Reason</span><select className="sv-input" value={delReason} onChange={e => setDelReason(e.target.value)} data-testid="appt-del-reason"><option value="">Choose…</option>{DELETE_REASONS.map(r => <option key={r}>{r}</option>)}</select></label>
      <label className="block"><span className="sv-label">Note (optional)</span><input className="sv-input" value={delNote} onChange={e => setDelNote(e.target.value)} data-testid="appt-del-note" /></label>
      <p className="text-[11.5px] sv-muted mt-2">The slot opens up, pending reminders stop and the deletion is audited. No cancellation message is sent to the patient in this build. You confirm with your own PIN.</p>
      <div className="flex justify-end gap-2 mt-3"><button type="button" className="sv-btn" onClick={() => setDel(false)}>Keep appointment</button><button type="button" className="sv-btn danger" disabled={!delReason} onClick={() => setPin(true)} data-testid="appt-del-continue">Delete…</button></div>
    </div></div>}
    {pin && <PinSign title="Confirm: delete appointment" statement={<>I am deleting {pt?.name}’s {v0.visitType.toLowerCase()} on {usDate(v0.date)} at {v0.time.replace(/^0/, '')} · {delReason}.</>} roles={ROLE_GROUP.everyone} confirmLabel="Delete" onClose={() => setPin(false)}
      onSigned={w => { try { deleteVisit(v0, delReason, delNote.trim(), w, actor.name); setPin(false); setDel(false); toast(`Appointment deleted (${delReason}). The slot is open again.`); onClose(); } catch (e: any) { setPin(false); setErr(e?.message || 'Could not delete.'); } }} />}
    {rm && <ReminderDialog visitId={v0.id} onClose={() => setRm(false)} />}
  </DialogShell></div>;
};
