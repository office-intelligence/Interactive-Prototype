/* Right-panel content for every citation / destination. House style: white, small type, minimal (the lab slip). Heavy
   MED v0.1 tools (medications, results entry, care plan, caregivers, billing, audit) open here too, so nothing from
   the 14-tab MED chart is lost; they are pulls instead of permanent cards. */
import React, { useState } from 'react';
import { Watch } from 'lucide-react';
import { repo } from '../v6/dataLayer';
import { AllergyStatus } from '../v7/ui';
import { medRepo, MedPatient, patientKey, usDate, fmtDate, fmtDateTime, vitalsText, uid, PROVIDER_ROLES } from '../med/record';
import { reviewLab, releaseLab } from '../med/portal';
import { RiskPanel } from '../med/RiskPanel';
import { NetworkThread } from '../med/NetworkThread';
import { setSharingConsent } from '../med/network';
import { MedInvoicePanel } from '../med/MedBilling';
import { AllergyCard, IntakeCard } from '../med/MedVisit';
import { Journal, Trends, Meds, Labs, CarePlanEditor, Visits, Caregivers, AuditTab, Conditions } from '../med/MedChart';
import { useActor, useMedTick } from '../med/ui';
import { Ref, labSlips, slipRef, relDay, R, surgicalHistoryLines } from './nightingale';
import { ascCasesFor, nurseAdmission, scribeSession, modules } from './store';
import { PanelShell, useSv, Cite } from './ui';
import { AllergyVerify } from './allergy';
import { ascPackets, receivePending } from './asc';
import { Ico, KIND_ICON } from './icons';
import { PatientAccount } from './payments';
import { BodyChartPanel, PhotosPanel } from './media';
import { PinSign } from './sign';

import { PayerLine } from './profile';
import { DocViewer, DocumentsSection } from './documents';
import { ContactNotesPanel } from './contactNotes';
import { QuotePanel, QuoteList } from './quotes';
const WIDE: Ref['kind'][] = ['documents', 'doc', 'photos', 'meds', 'labs', 'careplan', 'caregivers', 'billing', 'audit', 'journal', 'trends', 'conditions', 'visits'];
const TITLE: Partial<Record<Ref['kind'], string>> = { meds: 'Medications, allergies & intake', labs: 'All results', careplan: 'Care plan', caregivers: 'Caregiver access', billing: 'Billing', audit: 'Audit trail', journal: 'Medical journal', trends: 'Trends', conditions: 'Conditions', visits: 'Visits & notes', risk: 'Risk awareness', careteam: 'Care team', monitoring: 'Remote monitoring', history: 'Surgical history', messages: 'Portal messages', allergies: 'Allergies', intake: 'Intake answers', vitals: 'Vitals', problems: 'Problem list', asc: 'Affiliated ASC', ascchart: 'Sent to ASC · ASC chart', bodychart: 'Body chart', photos: 'Clinical photos', documents: 'Documents folder', contactnotes: 'Contact notes' };

export const RightPanel: React.FC = () => {
  useMedTick(); const { panel, closePanel, patientId } = useSv();
  if (!panel) return null;
  const pid = panel.pid || patientId; const p = medRepo.patient(pid);
  if (!p) return <PanelShell title={panel.label} onClose={closePanel}><p className="sv-muted">Open a patient chart first.</p></PanelShell>;
  const wide = WIDE.includes(panel.kind);
  const title = panel.kind === 'labslip' || panel.kind === 'note' ? panel.label : TITLE[panel.kind] || panel.label;
  return <PanelShell title={title} icon={KIND_ICON[panel.kind]} sub={<>{p.name} · DOB {p.dob}</>} wide={wide} onClose={closePanel}>
    <PanelBody r={panel} p={p} />
  </PanelShell>;
};

const PanelBody: React.FC<{ r: Ref; p: MedPatient }> = ({ r, p }) => {
  const { toast } = useSv();
  switch (r.kind) {
    case 'labslip': return <LabSlip date={r.id || ''} p={p} />;
    case 'note': return <NoteSheet visitId={r.id || ''} p={p} />;
    case 'labs': return <div className="sv-flat"><Labs p={p} onToast={toast} /></div>;
    case 'meds': return <div className="sv-flat"><Meds p={p} onToast={toast} /></div>;
    case 'careplan': return <div className="sv-flat"><CarePlanEditor p={p} onToast={toast} /></div>;
    case 'caregivers': return <div className="sv-flat"><Caregivers p={p} onToast={toast} /></div>;
    case 'audit': return <div className="sv-flat"><AuditTab p={p} /></div>;
    case 'journal': return <div className="sv-flat"><Journal p={p} /></div>;
    case 'trends': return <div className="sv-flat"><Trends p={p} /></div>;
    case 'conditions': case 'problems': return <div className="sv-flat"><Conditions p={p} /></div>;
    case 'visits': return <div className="sv-flat"><Visits p={p} onOpenVisit={() => {}} /></div>;
    case 'risk': return <div className="sv-flat"><RiskPanel patient={p} /></div>;
    case 'allergies': return <div className="sv-flat"><AllergyVerify p={p} /><p className="sv-small sv-muted mt-3">Confirmed once with the patient by a nurse or physician (PIN). It stays verified for the whole care team until the patient reports a change.</p></div>;
    case 'ascchart': return <AscChartSheet p={p} />;
    case 'intake': return <div className="sv-flat"><IntakeCard p={p} /></div>;
    case 'billing': return <div className="sv-flat"><PayerLine p={p} /><PatientAccount p={p} /><div className="my-4"><QuoteList p={p} compact /></div>{medRepo.visits(p.id).filter(v => v.step !== 'scheduled').map(v => <div key={v.id} className="mb-4"><div className="sv-h">{usDate(v.date)} · {v.visitType}</div><MedInvoicePanel visit={v} onToast={toast} /></div>)}{!medRepo.visits(p.id).some(v => v.step !== 'scheduled') && <p className="sv-muted">No visits to bill yet.</p>}</div>;
    case 'asc': return <AscSheet p={p} caseId={r.id} />;
    case 'careteam': return <div><table className="sv-table"><tbody>{p.careTeam.map(c => <tr key={c.name}><td><b>{c.name}</b><div className="sv-muted">{c.role}</div></td><td>{c.phone || '—'}</td></tr>)}</tbody></table>{p.emergencyContact && <p className="mt-3"><span className="sv-h">Emergency contact</span><br />{p.emergencyContact}</p>}<p className="sv-small sv-muted mt-3">Outside clinicians are fictional. Edit the care team on the Patient Registration form.</p></div>;
    case 'monitoring': return <div data-testid="rpm-coming-later"><p className="flex items-center gap-2 font-semibold"><Watch size={16} />Remote monitoring (wearables): coming later</p><p className="sv-muted">The data model has a hook for device readings (blood pressure cuffs, glucose meters, watches). Nothing connects in this build, and no readings are shown.</p></div>;
    case 'history': return <HistorySheet p={p} />;
    case 'messages': return <MessagesSheet p={p} />;
    case 'vitals': return <VitalsSheet p={p} />;
    case 'bodychart': return <BodyChartPanel p={p} id={r.id} />;
    case 'photos': return <PhotosPanel p={p} />;
    case 'documents': return <DocumentsSection p={p} inPanel />;
    case 'doc': return <DocViewer p={p} id={r.id} />;
    case 'quote': return <QuotePanel p={p} id={r.id} />;
    case 'contactnotes': return <ContactNotesPanel p={p} id={r.id} />;
    case 'summary': return <p className="sv-muted">The living summary is the chart’s first page.</p>;
    default: return <p className="sv-muted">Nothing to show.</p>;
  }
};

const LabSlip: React.FC<{ date: string; p: MedPatient }> = ({ date, p }) => {
  useMedTick(); const [actor] = useActor(); const { openPanel } = useSv(); const [note, setNote] = useState(''); const [labSign, setLabSign] = useState<'release' | 'hold' | 'release-reviewed' | null>(null);
  const slips = labSlips(p.id); const s = slips.find(x => x.date === date) || slips[0];
  if (!s) return <p className="sv-muted">No lab results recorded.</p>;
  const canReview = true; /* v0.4: anyone opens it; the reviewing provider signs with their own PIN */ const pending = s.labs.filter(l => l.status === 'awaiting-review'); const reviewed = s.labs.filter(l => l.status === 'reviewed');
  const prior = s.labs.map(l => { const all = medRepo.labs(p.id).filter(x => x.test === l.test && x.collectedAt <= l.collectedAt); return all.length > 1 ? `${l.test}: ${all.map(x => x.value).join(' → ')}` : ''; }).filter(Boolean);
  const idx = slips.findIndex(x => x.date === s.date);
  return <div data-testid="lab-slip">
    <div className="flex justify-between items-baseline mb-2"><span className="sv-muted sv-small">{s.labs[0].source}</span><span className="sv-muted sv-small">collected {usDate(s.date)} · {relDay(s.date)}</span></div>
    <table className="sv-slip"><thead><tr><th>TEST</th><th>RESULT</th><th>REF (lab-printed)</th><th>STATUS</th></tr></thead><tbody>
      {s.labs.map(l => <tr key={l.id}><td>{l.test}</td><td><b>{l.value}</b> {l.unit}</td><td>{l.reportedRange || '—'}</td><td>{l.status === 'awaiting-review' ? <span className="sv-warn">awaiting review</span> : l.status === 'reviewed' ? 'reviewed' : `released${l.reviewedBy ? ` · ${l.reviewedBy.replace(/,.*$/, '')}` : ''}`}</td></tr>)}
    </tbody></table>
    <div className="sv-ex">EXAMPLE DATA · ranges as printed by the fictional lab (blank when not entered) · office ranges not configured</div>
    {prior.length > 0 && <div className="sv-ann"><b>Nightingale</b>Values over time (no interpretation): {prior.join(' · ')}. {pending.length ? `${pending.length} result${pending.length === 1 ? '' : 's'} on this slip await clinician review before the patient can see them.` : ''}</div>}
    {pending.length > 0 && <div className="mt-3" data-testid="slip-review">
      <label className="sv-label" htmlFor="slip-note">Message to the patient with these results (optional, plain English)</label>
      <textarea id="slip-note" className="sv-input" rows={2} value={note} onChange={e => setNote(e.target.value)} data-testid="slip-note" />
      <div className="flex gap-2 mt-2 flex-wrap"><button type="button" className="sv-btn primary sm" disabled={!canReview} onClick={() => setLabSign('release')} data-testid="slip-release">Reviewed · release to portal</button><button type="button" className="sv-btn sm" disabled={!canReview} onClick={() => setLabSign('hold')}>Reviewed, don’t release yet</button></div>
      <p className="sv-small sv-muted mt-1">The reviewing provider confirms with their own PIN.</p>
    </div>}
    {reviewed.length > 0 && canReview && <button type="button" className="sv-btn sm mt-2" onClick={() => setLabSign('release-reviewed')}>Release {reviewed.length} reviewed result{reviewed.length === 1 ? '' : 's'}</button>}
    {labSign && <PinSign title={labSign === 'hold' ? 'Mark results reviewed' : 'Review and release results'} statement={<>I reviewed {labSign === 'release-reviewed' ? reviewed.length : pending.length} result(s) from {usDate(s.date)} for {p.name}{labSign === 'hold' ? '' : ' and release them to the portal'}.</>} roles={PROVIDER_ROLES} confirmLabel="Sign" onClose={() => setLabSign(null)} onSigned={w => { if (labSign === 'release') { pending.forEach(l => reviewLab(l, w.name, w.role, '', true, note)); setNote(''); } else if (labSign === 'hold') pending.forEach(l => reviewLab(l, w.name, w.role, '', false)); else reviewed.forEach(l => releaseLab(l, w.name, w.role)); setLabSign(null); }} />}
    <div className="flex gap-3 mt-4 sv-small">{idx < slips.length - 1 && <button type="button" className="sv-link" onClick={() => openPanel(slipRef(slips[idx + 1].date, p.id))}>← Older slip</button>}{idx > 0 && <button type="button" className="sv-link" onClick={() => openPanel(slipRef(slips[idx - 1].date, p.id))}>Newer slip →</button>}<button type="button" className="sv-link" onClick={() => openPanel(R('labs', 'All results', p.id))}>All results · enter a result</button><button type="button" className="sv-link" onClick={() => openPanel(R('trends', 'Trends', p.id))}>Trends</button></div>
  </div>;
};

const NoteSheet: React.FC<{ visitId: string; p: MedPatient }> = ({ visitId, p }) => {
  useMedTick(); const v = medRepo.visit(visitId); const n = v ? medRepo.note(v.id) : undefined; const na = nurseAdmission(visitId); const sc = scribeSession(visitId);
  if (!v) return <p className="sv-muted">Visit not found.</p>;
  const vit = medRepo.vitals(p.id).filter(x => x.visitId === v.id).slice(-1)[0];
  return <div data-testid="note-sheet">
    <p className="sv-muted sv-small">{v.visitType} · {usDate(v.date)} {v.time} · {v.provider} · {v.room}</p>
    {n ? <>{(['subjective', 'objective', 'assessment', 'plan'] as const).map(k => <div key={k} className="mb-2"><div className="sv-h">{k}</div><div className="sv-typed">{n[k] || '—'}</div></div>)}
      <p className="sv-small mt-2">{n.status === 'signed' ? <span className="sv-ok">Signed by {n.signedBy} · {fmtDateTime(n.signedAt)} · fingerprint {n.contentHash}</span> : <span className="sv-warn">Draft, not signed</span>}</p>
      {n.addenda.map((a, i) => <p key={i} className="sv-small">Addendum {fmtDateTime(a.at)} · {a.by}: {a.text}</p>)}</> : <p className="sv-muted">No note yet for this visit.</p>}
    {sc.lines.length > 0 && <p className="sv-small sv-muted mt-2">Drafted from an ambient-scribe session (simulated, {sc.lines.length} transcript lines). Reviewed and signed by a clinician; Nightingale cannot sign.</p>}
    {vit && <><div className="sv-h mt-3">Vitals at this visit</div><p>{vitalsText(vit)}</p></>}
    {na && <><div className="sv-h mt-3">Nurse admission</div><p>{na.chiefComplaint} · pain {na.pain || '—'} · {na.by} · {fmtDateTime(na.at)}</p></>}
  </div>;
};

const AscSheet: React.FC<{ p: MedPatient; caseId?: string }> = ({ p, caseId }) => {
  useMedTick(); const [actor] = useActor(); const cases = ascCasesFor(p.id).sort((a, b) => (a.id === caseId ? -1 : b.id === caseId ? 1 : a.date.localeCompare(b.date))); const c = p.recordSharingConsent;
  if (!modules().networkAsc) return <p className="sv-muted">The affiliated-ASC module is switched off for this practice (Practice › Surgery settings).</p>;
  return <div data-testid="asc-sheet">
    <p className="sv-tag warn">Simulated network link · nothing is sent</p>
    <p className="mt-2">{c?.granted ? <>Record-sharing consent on file: <b>{c.scope}</b> · {c.by}, {fmtDate(c.at)}</> : 'No consent to share records with the ASC is recorded.'} {' '}
      {c?.granted ? <button type="button" className="sv-link sv-small" onClick={() => setSharingConsent(p, false, actor.name, actor.role, c.scope)}>Withdraw</button> : <button type="button" className="sv-link sv-small" onClick={() => setSharingConsent(p, true, actor.name, actor.role, 'Surgical records for the booked procedure')} data-testid="consent-record">Record consent</button>}</p>
    {cases.length === 0 ? <p className="sv-muted">No ASC case is linked to this chart (simulated match on name + date of birth).</p> : cases.map(x => <div key={x.id} className="mt-4 pt-3 sv-rule"><div className="flex justify-between gap-2 flex-wrap"><b>{x.procedure}</b><span className="sv-tag">{x.status}</span></div><p className="sv-muted sv-small">{usDate(x.date)} {x.time} · {x.room} · {x.surgeon} · {x.ascName} · {x.date >= new Date().toISOString().slice(0, 10) ? relDay(x.date) : 'past'}</p><div className="sv-flat"><NetworkThread c={x} /></div></div>)}
  </div>;
};

const HistorySheet: React.FC<{ p: MedPatient }> = ({ p }) => {
  const h = surgicalHistoryLines(p); const intake = medRepo.intake(p.id);
  return <div><div className="sv-h">Surgical history</div>{h.length ? <ul className="mb-3">{h.map((x, i) => <li key={i} className="py-1 border-b border-[var(--line)]">{x.text}{x.detail && <div className="sv-muted sv-small">{x.detail}</div>}</li>)}</ul> : <p className="sv-muted">None recorded.</p>}
    <div className="sv-h mt-3">From the Medical History form (patient-reported)</div>{intake.length ? <table className="sv-table"><tbody>{intake.map(i => <tr key={i.key}><td>{i.key.replace(/([A-Z])/g, ' $1').toLowerCase()}</td><td><b>{i.value}</b>{i.detail ? <div className="sv-muted">{i.detail}</div> : null}</td><td className="sv-muted">{fmtDate(i.recordedAt)}</td></tr>)}</tbody></table> : <p className="sv-muted">No answers recorded.</p>}</div>;
};

const VitalsSheet: React.FC<{ p: MedPatient }> = ({ p }) => {
  const { openPanel } = useSv(); const v = [...medRepo.vitals(p.id)].reverse();
  return <div><table className="sv-slip"><thead><tr><th>DATE</th><th>VITALS</th><th>BY</th></tr></thead><tbody>{v.map(x => <tr key={x.id}><td>{fmtDate(x.at)}</td><td>{vitalsText(x)}</td><td>{x.by}</td></tr>)}</tbody></table><div className="sv-ex">No vital-sign thresholds are built in.</div><button type="button" className="sv-link sv-small mt-3" onClick={() => openPanel(R('trends', 'Trends', p.id))}>Open trends</button></div>;
};

const MessagesSheet: React.FC<{ p: MedPatient }> = ({ p }) => {
  useMedTick(); const [actor] = useActor(); const [t, setT] = useState(''); const msgs = medRepo.messages(p.id);
  const send = () => { if (!t.trim()) return; medRepo.addMessage({ id: uid('pm'), patientId: p.id, from: 'office', author: actor.name, text: t.trim(), at: new Date().toISOString() }); setT(''); };
  return <div data-testid="messages-sheet">{msgs.length === 0 ? <p className="sv-muted">No portal messages.</p> : msgs.map(m => <div key={m.id} className={`mb-2 p-2 rounded ${m.from === 'office' ? 'bg-[var(--wash)] ml-8' : 'border border-[var(--line)]'}`}><div className="sv-small sv-muted">{m.author} · {fmtDateTime(m.at)}</div><div>{m.text}</div></div>)}
    <label className="sv-label mt-3" htmlFor="pm-reply">Reply in the portal (test build: stays on this device)</label><textarea id="pm-reply" className="sv-input" rows={3} value={t} onChange={e => setT(e.target.value)} data-testid="pm-reply" /><button type="button" className="sv-btn sm primary mt-2" onClick={send}>Send reply</button>
    <p className="sv-small sv-muted mt-2">Nightingale does not draft clinical advice. Peri-operative medication instructions come from the surgeon.</p></div>;
};

/* What each ASC received (simulated): the packet as it lands in the patient's chart at that facility. */
const AscChartSheet: React.FC<{ p: MedPatient }> = ({ p }) => {
  useMedTick(); receivePending(); const list = ascPackets(p.id).slice().reverse();
  if (!list.length) return <p className="sv-muted">Nothing has been sent to a surgery center for this patient yet. Use Checkout › Send request to ASC.</p>;
  return <div data-testid="asc-chart">{list.map(pk => <section key={pk.id} className="mb-4 pb-3 border-b border-[var(--line)]">
    <div className="flex items-center gap-2"><Ico k="asc" size={16} /><b>{pk.facilityName}</b><span className={`sv-tag ${pk.status === 'received' ? 'ok' : ''}`} data-testid="asc-chart-status">{pk.status === 'received' ? `Received · in ASC chart ${pk.ascChartId}` : 'Sent · waiting for the ASC'}</span></div>
    <div className="sv-small sv-muted mt-0.5">Sent by {pk.sentBy} · {fmtDateTime(pk.sentAt)}{pk.receivedAt ? ` · received ${fmtDateTime(pk.receivedAt)}` : ''} · {pk.surgeon}</div>
    <div className="mt-2 text-[13.5px]"><b>{pk.form.procedure}</b>{pk.form.laterality !== 'N/A' ? ` · ${pk.form.laterality}` : ''} · {pk.form.anesthesia} · {pk.form.durationMin} min · {pk.form.admission}<div className="sv-muted">Dx: {pk.form.diagnosis || '—'}{pk.form.icd10 ? ` (${pk.form.icd10})` : ''}{pk.form.implants ? ` · implants: ${pk.form.implants}` : ''}{pk.form.equipment ? ` · equipment: ${pk.form.equipment}` : ''}</div></div>
    <ul className="mt-2 text-[13px]">{[{ id: 'form', kind: 'form', title: 'Surgery scheduling form', detail: 'filed' }, ...pk.docs].map(d => <li key={d.id} className="flex gap-1.5 items-baseline py-0.5"><Ico k={d.kind === 'clearance' ? 'document' : d.kind === 'nurse' ? 'form' : d.kind === 'scribe' ? 'note' : d.kind === 'history' ? 'surgery' : d.kind} /><span>{d.title}</span><span className="sv-muted ml-auto">{pk.status === 'received' ? 'in ASC chart' : 'sent'}</span></li>)}</ul>
  </section>)}<p className="sv-small sv-muted">Simulated: in this build nothing leaves the browser and the ASC reply is automatic. ASC.Vityls itself is not changed.</p></div>;
};
