/* Surgery.Vityls v0.13 · Print / Send records packet (UI): button on the chart tab row → packet builder
 * (Choose → Organize → Recipient → Preview & send), plus the "Records sent" log (Activity and Documents tabs) with resend. */
import React, { useEffect, useMemo, useRef, useState } from 'react';
import * as pdfjsLib from 'pdfjs-dist';
// @ts-ignore no types for the worker build
import * as pdfjsWorkerModule from 'pdfjs-dist/build/pdf.worker.min.mjs';
import { ArrowDown, ArrowUp, GripVertical, Printer, Download, Send, Sparkles, X, FileText, ShieldCheck, ShieldAlert, Info } from 'lucide-react';
import { DialogShell } from '../../v7/ui';
import { repo } from '../../v6/dataLayer';
import { MedPatient, patientKey, fmtDateTime, usDate } from '../../med/record';
import { useActor, useMedTick } from '../../med/ui';
import { useSv } from '../ui';
import { PinSign } from '../sign';
import { ROLE_GROUP } from '../staff';
import { ascFacilities } from '../asc';
import { nextAscCase } from '../nightingale';
import { RECIPIENT_KINDS } from './packet';
import { packetItems, PItem, GROUPS, Group, PRESETS, PresetId, Recipient, RECIPIENT_LABEL, directory, referringFor, draftCover, buildPacketPdf, Built, deliver, recordsSent, SentRec, pdfBytesOf, fileName, logAction, methodLabel, Method } from './packet';
import { checkHipaa, hipaaAuths, HipaaAuth, PURPOSES, OVERRIDE_REASONS, RecipientKind, revokeAuth, HipaaResult } from './hipaa';
import './v13.css';

export async function renderPdfPages(bytes: Uint8Array, el: HTMLElement, width = 520, max = 40) {
  const g = globalThis as any; const had = g.pdfjsWorker; g.pdfjsWorker = pdfjsWorkerModule; let doc: any;
  try { doc = await pdfjsLib.getDocument({ data: bytes.slice() }).promise; } finally { if (had === undefined) delete g.pdfjsWorker; else g.pdfjsWorker = had; }
  el.innerHTML = '';
  for (let i = 1; i <= Math.min(doc.numPages, max); i++) { const pg = await doc.getPage(i); const v1 = pg.getViewport({ scale: 1 }); const sc = width / v1.width; const vp = pg.getViewport({ scale: sc * (window.devicePixelRatio || 1) });
    const c = document.createElement('canvas'); c.width = vp.width; c.height = vp.height; c.style.width = `${width}px`; c.className = 'v13-page'; c.setAttribute('data-testid', 'pk-page'); c.setAttribute('aria-label', `Page ${i}`);
    el.appendChild(c); await pg.render({ canvasContext: c.getContext('2d')!, viewport: vp }).promise; }
  return doc.numPages as number;
}
const blobUrl = (b: Uint8Array) => URL.createObjectURL(new Blob([b as BlobPart], { type: 'application/pdf' }));
function printBytes(b: Uint8Array) { const u = blobUrl(b); const f = document.createElement('iframe'); f.style.cssText = 'position:fixed;right:0;bottom:0;width:1px;height:1px;border:0;opacity:0'; f.src = u; document.body.appendChild(f);
  f.onload = () => { try { f.contentWindow?.focus(); f.contentWindow?.print(); } catch { window.open(u, '_blank'); } setTimeout(() => f.remove(), 60000); }; }
function downloadBytes(b: Uint8Array, name: string) { const a = document.createElement('a'); a.href = blobUrl(b); a.download = name; document.body.appendChild(a); a.click(); a.remove(); }

export const PrintSendButton: React.FC<{ p: MedPatient }> = ({ p }) => { const [open, setOpen] = useState(false);
  return <><button type="button" className="sv-btn sm v13-ps-btn" onClick={() => setOpen(true)} data-testid="chart-print-send"><Printer size={15} />Print / Send</button>{open && <PacketBuilder p={p} onClose={() => setOpen(false)} />}</>; };

type Step = 'choose' | 'organize' | 'recipient' | 'preview';
const STEPS: [Step, string][] = [['choose', '1 · Choose'], ['organize', '2 · Organize'], ['recipient', '3 · Recipient'], ['preview', '4 · Preview & send']];
const PURPOSE_FOR: Record<RecipientKind, string> = { referring: 'Referral or consultation report', doctor: 'Treatment / continuity of care', asc: 'Surgery scheduling and pre-op clearance', patient: 'At the patient’s request', free: 'At the patient’s request' };

export const PacketBuilder: React.FC<{ p: MedPatient; onClose: () => void }> = ({ p, onClose }) => {
  useMedTick(); const [actor] = useActor(); const { toast } = useSv();
  const all = useMemo(() => packetItems(p), [p.id]); const byId = useMemo(() => new Map(all.map(i => [i.id, i])), [all]);
  const [step, setStep] = useState<Step>('choose'); const [preset, setPreset] = useState<PresetId>('custom'); const [order, setOrder] = useState<string[]>([]);
  const [coverSheet, setCoverSheet] = useState(true); const [useLetter, setUseLetter] = useState(true); const [letter, setLetter] = useState(''); const [letterBy, setLetterBy] = useState<'nightingale' | 'edited' | ''>('');
  const ref = referringFor(p); const facs = ascFacilities().filter(f => f.active); const ascCase = nextAscCase(p.id);
  const [kind, setKind] = useState<RecipientKind>('referring'); const [purpose, setPurpose] = useState<string>(PURPOSE_FOR.referring);
  const [rc, setRc] = useState<Recipient>(() => ({ kind: 'referring', name: ref?.name || '', org: ref?.org || '', method: ref?.fax ? 'fax' : 'email', address: ref?.fax || ref?.email || '' }));
  const [reason, setReason] = useState(''); const [note, setNote] = useState('');
  const [built, setBuilt] = useState<Built | null>(null); const [busy, setBusy] = useState(false); const [err, setErr] = useState(''); const [confirm, setConfirm] = useState(false); const [sign, setSign] = useState(false); const [sent, setSent] = useState<SentRec | null>(null);
  const prevRef = useRef<HTMLDivElement>(null); const dragFrom = useRef<number | null>(null);
  const title = PRESETS.find(x => x.id === preset)?.id === 'custom' ? 'Medical records' : PRESETS.find(x => x.id === preset)!.label;
  const items = order.map(id => byId.get(id)).filter(Boolean) as PItem[];
  const hipaa: HipaaResult = useMemo(() => checkHipaa(p.id, kind, rc.name, purpose), [p.id, kind, rc.name, purpose, hipaaAuths(p.id).map(a => a.status).join()]);
  useEffect(() => { setReason(hipaa.needsReason ? hipaa.defaultReason || '' : ''); }, [hipaa.code]);
  const toggle = (id: string, on: boolean) => setOrder(o => on ? (o.includes(id) ? o : [...o, id]) : o.filter(x => x !== id));
  const pick = (id: PresetId) => { const pr = PRESETS.find(x => x.id === id)!; setPreset(id); setOrder(pr.pick(all)); chooseKind(pr.recipient, pr.purpose); setLetterBy(''); setLetter(''); repo.audit({ caseId: patientKey(p.id), user: actor.name, role: actor.role, action: 'records.packet.preset' as any, detail: `Packet preset “${pr.label}” · ${pr.pick(all).length} item(s) pre-selected` }); };
  function chooseKind(k: RecipientKind, pur?: string) { setKind(k); setPurpose(pur || PURPOSE_FOR[k]);
    if (k === 'referring') setRc({ kind: k, name: ref?.name || '', org: ref?.org || '', method: ref?.fax ? 'fax' : 'email', address: ref?.fax || ref?.email || '' });
    else if (k === 'doctor') { const sp = pur && /specialist/i.test(pur) ? directory().find(d => d.name !== ref?.name) : undefined; // Medical: referral preset suggests a specialist from the directory
      setRc(sp ? { kind: k, name: sp.name, org: sp.org, method: 'fax', address: sp.fax } : { kind: k, name: '', org: '', method: 'fax', address: '' }); }
    else if (k === 'asc') { const f = facs.find(x => x.primary) || facs[0]; setRc({ kind: k, name: f?.name || '', org: f?.city || '', ascId: f?.id, method: ascCase ? 'network' : 'fax', address: ascCase ? '' : '(555) 014-9000' }); }
    else if (k === 'patient') setRc({ kind: k, name: p.name, org: '', method: 'portal', address: p.email || '' });
    else setRc({ kind: k, name: '', org: '', method: 'email', address: '' }); }
  const draft = () => { setLetter(draftCover(p, items, rc, purpose, actor.name)); setLetterBy('nightingale'); repo.audit({ caseId: patientKey(p.id), user: 'Nightingale (simulated)', role: 'AI assistant', action: 'nightingale.cover.draft' as any, detail: `Drafted a cover letter for “${title}” to ${rc.name || RECIPIENT_LABEL[kind]} (${items.length} items) for ${actor.name} to edit · SIMULATED` }); };
  useEffect(() => { if (step === 'organize' && useLetter && !letter) draft(); if (step === 'preview') build(); }, [step]);
  const build = async () => { setBusy(true); setErr(''); try { const b = await buildPacketPdf({ p, ids: order, recipient: rc, purpose, coverSheet, coverLetter: useLetter ? letter : '', from: actor.name, fromRole: actor.role, title }); setBuilt(b); logAction(p, actor.name, actor.role, 'preview', title, order.length);
      setTimeout(() => { if (prevRef.current) renderPdfPages(b.bytes, prevRef.current, Math.min(560, (prevRef.current.clientWidth || 560) - 24)).catch(e => setErr(`Preview failed: ${e?.message || e}`)); }, 0); } catch (e) { setErr((e as Error).message); } finally { setBusy(false); } };
  const move = (i: number, d: number) => setOrder(o => { const j = i + d; if (j < 0 || j >= o.length) return o; const n = o.slice(); [n[i], n[j]] = [n[j], n[i]]; return n; });
  const drop = (to: number) => { const from = dragFrom.current; dragFrom.current = null; if (from === null || from === to) return; setOrder(o => { const n = o.slice(); const [x] = n.splice(from, 1); n.splice(to, 0, x); return n; }); };
  const canNext = step === 'choose' ? order.length > 0 : step === 'recipient' ? !!rc.name.trim() && (!hipaa.needsReason || (!!reason && (!reason.startsWith('Other') || !!note.trim()))) : true;
  const idx = STEPS.findIndex(s => s[0] === step);
  const doSend = async (by: { name: string; role: string }) => { setSign(false); setBusy(true); try { if (!built) throw new Error('Build the PDF first.'); const r = await deliver({ p, built, title, preset, purpose, recipient: rc, ids: order, coverLetter: useLetter ? letter : undefined, coverSheet, hipaa, reason: reason || undefined, note, by: by.name, role: by.role }); setSent(r); setConfirm(false); toast(`Records sent to ${rc.name}. ${r.delivery}.`); } catch (e) { setErr((e as Error).message); setConfirm(false); } finally { setBusy(false); } };
  const footer = sent ? <button type="button" className="sv-btn primary" onClick={onClose} data-testid="pk-done">Done</button> : <>
    <span className="mr-auto sv-small sv-muted" data-testid="pk-count">{order.length} item{order.length === 1 ? '' : 's'}{built && step === 'preview' ? ` · ${built.pages} pages` : ''}</span>
    {idx > 0 && <button type="button" className="sv-btn" onClick={() => setStep(STEPS[idx - 1][0])} data-testid="pk-back">Back</button>}
    {step !== 'preview' ? <button type="button" className="sv-btn primary" disabled={!canNext} onClick={() => setStep(STEPS[idx + 1][0])} data-testid="pk-next">Next</button> : <>
      <button type="button" className="sv-btn" disabled={!built || busy} onClick={() => { built && printBytes(built.bytes); logAction(p, actor.name, actor.role, 'print', title, order.length); }} data-testid="pk-print"><Printer size={15} />Print</button>
      <button type="button" className="sv-btn" disabled={!built || busy} onClick={() => { built && downloadBytes(built.bytes, fileName(p, title)); logAction(p, actor.name, actor.role, 'download', title, order.length); }} data-testid="pk-download"><Download size={15} />Download</button>
      <button type="button" className="sv-btn primary" disabled={!built || busy || !canNext} onClick={() => setConfirm(true)} data-testid="pk-send"><Send size={15} />Send…</button></>}</>;
  return <div className="sv-flat sv-dlg"><DialogShell size="xl" kicker={`${p.name} · DOB ${p.dob} · ${p.id}`} title="Print / Send records" subtitle="Build one PDF packet from this chart, preview it, then print, download or send it. Sending is simulated, so nothing leaves this browser." onClose={onClose} testId="pk-dialog" footer={footer}>
    {sent ? <div className="v13-sent" data-testid="pk-sent"><ShieldCheck size={22} /><div><b>Sent to {sent.recipient.name}</b><p>{sent.delivery}. {sent.items.length} items, {sent.pages} pages · {fmtDateTime(sent.at)} by {sent.by}.</p><p className="sv-small sv-muted">Saved to Records sent (Activity and Documents tabs). You can resend it from there.</p></div></div> : <>
    <nav className="v13-steps" aria-label="Packet steps">{STEPS.map(([k, l], i) => <button key={k} type="button" aria-current={step === k ? 'step' : undefined} disabled={i > idx && !(i === idx + 1 && canNext) && i > idx} onClick={() => (i <= idx || canNext) && setStep(k)} data-testid={`pk-step-${k}`}>{l}</button>)}</nav>
    {err && <p className="v13-err" role="alert" data-testid="pk-error">{err}</p>}
    {step === 'choose' && <div data-testid="pk-choose">
      <div className="sv-label">Quick templates</div>
      <div className="v13-presets">{PRESETS.map(pr => <button key={pr.id} type="button" aria-pressed={preset === pr.id} onClick={() => pick(pr.id)} data-testid={`pk-preset-${pr.id}`}><b>{pr.label}</b><span>{pr.hint}</span></button>)}</div>
      {GROUPS.map(([g, label, opt]) => { const l = all.filter(i => i.group === g); if (!l.length) return null; const on = l.filter(i => order.includes(i.id)).length;
        return <section key={g} className="v13-group" data-testid={`pk-group-${g}`}><header><label className="flex items-center gap-2"><input type="checkbox" checked={on === l.length} ref={el => { if (el) el.indeterminate = on > 0 && on < l.length; }} onChange={e => l.forEach(i => toggle(i.id, e.target.checked))} aria-label={`All ${label}`} /><b>{label}</b></label>{opt && <span className="v13-opt">optional</span>}<span className="sv-small sv-muted ml-auto">{on}/{l.length}</span></header>
          {g === 'results' && <p className="sv-small sv-muted -mt-1 mb-1">Lab, pathology, imaging and ECG documents from the Documents folder are listed here.</p>}
          {(g === 'documents' ? Array.from(new Set(l.map(i => i.sub || ''))) : ['']).map(sub => <div key={sub}>{sub && <div className="v13-sub">{sub}</div>}{l.filter(i => !sub || i.sub === sub).map(i => <label key={i.id} className="v13-item" data-testid="pk-item" data-id={i.id}><input type="checkbox" checked={order.includes(i.id)} onChange={e => toggle(i.id, e.target.checked)} /><span><b>{i.title}</b><i>{i.detail}{i.date ? ` · ${usDate(i.date)}` : ''}</i></span></label>)}</div>)}</section>; })}
    </div>}
    {step === 'organize' && <div className="v13-two" data-testid="pk-organize">
      <section><div className="sv-label">Order in the PDF: drag, or use the arrows</div>
        <ol className="v13-order" data-testid="pk-order">{coverSheet && <li className="v13-fixed"><FileText size={14} />Cover page (letterhead, recipient, confidentiality notice)</li>}{useLetter && <li className="v13-fixed"><FileText size={14} />Cover letter</li>}<li className="v13-fixed"><FileText size={14} />Table of contents</li>
          {items.map((i, n) => <li key={i.id} draggable onDragStart={() => { dragFrom.current = n; }} onDragOver={e => e.preventDefault()} onDrop={() => drop(n)} data-testid="pk-order-item" data-id={i.id}>
            <GripVertical size={15} className="grip" aria-hidden /><span className="n">{n + 1}</span><span className="t">{i.title}</span>
            <button type="button" aria-label={`Move ${i.title} up`} disabled={n === 0} onClick={() => move(n, -1)} data-testid="pk-up"><ArrowUp size={14} /></button>
            <button type="button" aria-label={`Move ${i.title} down`} disabled={n === items.length - 1} onClick={() => move(n, 1)} data-testid="pk-down"><ArrowDown size={14} /></button>
            <button type="button" aria-label={`Remove ${i.title}`} onClick={() => toggle(i.id, false)} data-testid="pk-remove"><X size={14} /></button></li>)}</ol></section>
      <section><div className="sv-label">Cover</div>
        <label className="v13-check"><input type="checkbox" checked={coverSheet} onChange={e => setCoverSheet(e.target.checked)} data-testid="pk-cover-sheet" />Cover page (fax-style sheet with recipient, sender, purpose and confidentiality notice)</label>
        <label className="v13-check"><input type="checkbox" checked={useLetter} onChange={e => { setUseLetter(e.target.checked); if (e.target.checked && !letter) draft(); }} data-testid="pk-cover-letter" />Cover letter</label>
        {useLetter && <div className="v13-letter" data-testid="pk-letter-box"><div className="flex items-center gap-2 mb-1"><span className="v13-ng"><Sparkles size={13} />{letterBy === 'nightingale' ? 'Drafted by Nightingale (simulated). Edit before sending.' : letterBy === 'edited' ? 'Nightingale draft, edited by you' : 'Cover letter'}</span>
          <button type="button" className="sv-link sv-small ml-auto" onClick={draft} data-testid="pk-letter-draft">Redraft with Nightingale</button></div>
          <textarea className="sv-input" rows={14} value={letter} onChange={e => { setLetter(e.target.value); setLetterBy('edited'); }} data-testid="pk-letter" aria-label="Cover letter text" /></div>}
      </section></div>}
    {step === 'recipient' && <div className="v13-two" data-testid="pk-recipient">
      <section>
        <div className="sv-label">Send to</div>
        <div className="v13-seg" role="group" aria-label="Recipient type">{RECIPIENT_KINDS.map(k => <button key={k} type="button" aria-pressed={kind === k} onClick={() => chooseKind(k)} data-testid={`pk-rcpt-${k}`}>{RECIPIENT_LABEL[k]}</button>)}</div>
        {kind === 'referring' && <p className="sv-small sv-muted mt-2" data-testid="pk-ref-note">{ref ? <>Prefilled from the referral on the profile: <b>{ref.name}</b>{ref.specialty ? ` · ${ref.specialty}` : ''}.</> : 'No referring physician on the profile. Enter one, or choose Other doctor.'}</p>}
        {kind === 'doctor' && <label className="block mt-2"><span className="sv-label">Directory</span><select className="sv-input" value="" onChange={e => { const d = directory().find(x => x.id === e.target.value); if (d) setRc({ ...rc, name: d.name, org: `${d.specialty} · ${d.org}`, address: rc.method === 'email' ? d.email : d.fax }); }} data-testid="pk-dir"><option value="">Choose from the directory, or type below…</option>{directory().map(d => <option key={d.id} value={d.id}>{d.name} · {d.specialty}</option>)}</select></label>}
        {kind === 'asc' && <label className="block mt-2"><span className="sv-label">Surgery center</span><select className="sv-input" value={rc.ascId} onChange={e => { const f = facs.find(x => x.id === e.target.value); f && setRc({ ...rc, ascId: f.id, name: f.name, org: f.city }); }} data-testid="pk-asc">{facs.map(f => <option key={f.id} value={f.id}>{f.name}{f.primary ? ' · primary' : ''}</option>)}</select>
          <span className="sv-small sv-muted">{ascCase ? 'This patient has an open ASC case, so the packet goes to that case thread (the same network link Send to ASC uses).' : 'No open ASC case yet, so it’s sent by fax. To book the case with a scheduling form, use Send to ASC.'}</span></label>}
        <div className="grid sm:grid-cols-2 gap-2 mt-2">
          <label><span className="sv-label">Name</span><input className="sv-input" value={rc.name} onChange={e => setRc({ ...rc, name: e.target.value })} disabled={kind === 'patient'} data-testid="pk-rcpt-name" /></label>
          <label><span className="sv-label">Organization (optional)</span><input className="sv-input" value={rc.org || ''} onChange={e => setRc({ ...rc, org: e.target.value })} disabled={kind === 'patient'} data-testid="pk-rcpt-org" /></label></div>
        <div className="sv-label mt-2">Send by</div>
        <div className="v13-seg" role="group" aria-label="Delivery method">{((kind === 'patient' ? ['portal', 'email'] : kind === 'asc' ? (ascCase ? ['network', 'fax', 'email'] : ['fax', 'email']) : ['fax', 'email']) as Method[]).map(m => <button key={m} type="button" aria-pressed={rc.method === m} onClick={() => { const d = directory().find(x => x.name === rc.name); setRc({ ...rc, method: m, address: m === 'email' ? (kind === 'patient' ? p.email || '' : d?.email || (rc.method === 'email' ? rc.address : '')) : m === 'fax' ? (d?.fax || (rc.method === 'fax' ? rc.address : '')) : '' }); }} data-testid={`pk-method-${m}`}>{m === 'portal' ? 'Patient portal' : m === 'network' ? 'ASC case thread' : m === 'fax' ? 'Fax' : 'Email'}</button>)}</div>
        {(rc.method === 'email' || rc.method === 'fax') && <label className="block mt-2"><span className="sv-label">{rc.method === 'fax' ? 'Fax number' : 'Email address'}</span><input className="sv-input" value={rc.address} onChange={e => setRc({ ...rc, address: e.target.value })} inputMode={rc.method === 'fax' ? 'tel' : 'email'} data-testid="pk-rcpt-address" /></label>}
        <label className="block mt-2"><span className="sv-label">Purpose</span><select className="sv-input" value={purpose} onChange={e => setPurpose(e.target.value)} data-testid="pk-purpose">{PURPOSES.map(x => <option key={x}>{x}</option>)}</select></label>
      </section>
      <section><HipaaPanel p={p} r={hipaa} reason={reason} setReason={setReason} note={note} setNote={setNote} /></section></div>}
    {step === 'preview' && <div data-testid="pk-preview-step">
      <div className="v13-prevbar"><span><b>{title}</b> to {rc.name || '—'} · {methodLabel(rc)}</span><span className={`v13-pill ${hipaa.level}`} data-testid="pk-hipaa-pill">{hipaa.level === 'ok' ? 'HIPAA: OK' : hipaa.level === 'info' ? 'HIPAA: treatment disclosure' : 'HIPAA: override with reason'}</span></div>
      {busy && !built && <p className="sv-muted">Building the PDF…</p>}
      <div className="v13-preview" ref={prevRef} data-testid="pk-preview" aria-label="PDF preview" />
      {built && <details className="mt-2"><summary className="sv-small">Table of contents ({built.toc.length})</summary><ol className="sv-small" data-testid="pk-toc">{built.toc.map((t, i) => <li key={i}>{t.title} · page {t.page}</li>)}</ol></details>}
    </div>}
    </>}
    {confirm && built && <SendConfirm p={p} title={title} r={rc} purpose={purpose} items={items} pages={built.pages} hipaa={hipaa} reason={reason} note={note} busy={busy} onCancel={() => setConfirm(false)} onSend={() => { setConfirm(false); setSign(true); }} />}
    {sign && <div className="v13-pin"><PinSign title="Sign to send records" statement={<>I am disclosing {items.length} item{items.length === 1 ? '' : 's'} ({built?.pages} pages) from {p.name}’s record to <b>{rc.name}</b> for {purpose.toLowerCase()}.</>} roles={ROLE_GROUP.everyone} confirmLabel="Sign & send" onSigned={doSend} onClose={() => setSign(false)} /></div>}
  </DialogShell></div>;
};

export const HipaaPanel: React.FC<{ p: MedPatient; r: HipaaResult; reason: string; setReason: (s: string) => void; note: string; setNote: (s: string) => void }> = ({ p, r, reason, setReason, note, setNote }) => {
  const [actor] = useActor(); const auths = hipaaAuths(p.id); const [rv, setRv] = useState<HipaaAuth | null>(null); const [rvNote, setRvNote] = useState(''); const [err, setErr] = useState('');
  const Icon = r.level === 'ok' ? ShieldCheck : r.level === 'info' ? Info : ShieldAlert;
  return <div>
    <div className={`v13-hipaa ${r.level}`} role={r.level === 'warn' ? 'alert' : 'status'} data-testid="pk-hipaa" data-code={r.code}><Icon size={18} /><div><b>{r.title}</b><p>{r.text}</p>
      {r.sensitive.length > 0 && <p className="sv-small">Sensitive categories this authorization allows: {r.sensitive.join(', ')}. Others are not authorized.</p>}
      {r.needsReason && <div className="mt-2"><label className="block"><span className="sv-label">{r.level === 'info' ? 'Basis for sending (recorded in the audit trail)' : 'Reason for sending anyway (required, audited)'}</span><select className="sv-input" value={reason} onChange={e => setReason(e.target.value)} data-testid="pk-hipaa-reason"><option value="">Choose…</option>{OVERRIDE_REASONS.map(x => <option key={x}>{x}</option>)}</select></label>
        <label className="block mt-1"><span className="sv-label">Note {reason.startsWith('Other') ? '(required)' : '(optional)'}</span><input className="sv-input" value={note} onChange={e => setNote(e.target.value)} data-testid="pk-hipaa-note" /></label></div>}</div></div>
    <div className="sv-label mt-3">HIPAA authorizations on file</div>
    {auths.length === 0 ? <p className="sv-small sv-muted" data-testid="pk-auths-none">None signed. The patient can sign the HIPAA Release at the portal or the front desk.</p> :
      <ul className="v13-auths" data-testid="pk-auths">{auths.map(a => <li key={a.key} data-testid="pk-auth"><span className={`v13-pill ${a.status === 'active' ? 'ok' : 'warn'}`}>{a.status}</span> Signed {usDate(a.signedAt.slice(0, 10))} by {a.signedBy}{a.rep ? ` (rep. ${a.rep})` : ''} · until {usDate(a.until)}{a.expiresEvent ? ` or ${a.expiresEvent}` : ''}
        <div className="sv-small sv-muted">To: {a.recipients.join(', ') || '—'}{a.recipientNames.length ? ` · ${a.recipientNames.join('; ')}` : ''}</div><div className="sv-small sv-muted">Purpose: {a.purposes.join(', ') || '—'} · Info: {a.info.join(', ') || '—'}{a.sensitive.length ? ` · Sensitive: ${a.sensitive.join(', ')}` : ''}</div>
        {a.status === 'active' && <button type="button" className="sv-link sv-small" onClick={() => { setRv(a); setRvNote(''); setErr(''); }} data-testid="pk-revoke">Record written revocation…</button>}
        {a.revoked && <div className="sv-small">Revoked {fmtDateTime(a.revoked.at)} · {a.revoked.note} ({a.revoked.by})</div>}</li>)}</ul>}
    {rv && <div className="v13-revoke" data-testid="pk-revoke-box"><label className="block"><span className="sv-label">How was the written revocation received?</span><input className="sv-input" value={rvNote} onChange={e => setRvNote(e.target.value)} placeholder="e.g. signed letter received at the front desk today" data-testid="pk-revoke-note" /></label>{err && <p className="v13-err">{err}</p>}
      <div className="flex gap-2 justify-end mt-1"><button type="button" className="sv-btn sm" onClick={() => setRv(null)}>Cancel</button><button type="button" className="sv-btn sm danger" onClick={() => { try { revokeAuth(rv, rvNote, actor.name, actor.role); setRv(null); } catch (e) { setErr((e as Error).message); } }} data-testid="pk-revoke-save">Record revocation</button></div></div>}
    <p className="sv-small sv-muted mt-2">This check is a soft warning, never a block. Treatment disclosures between providers don’t need an authorization (45 CFR 164.506). Every send records its basis, and the Records sent log works as the accounting of disclosures.</p>
  </div>;
};

const SendConfirm: React.FC<{ p: MedPatient; title: string; r: Recipient; purpose: string; items: PItem[]; pages: number; hipaa: HipaaResult; reason: string; note: string; busy: boolean; onCancel: () => void; onSend: () => void }> = ({ p, title, r, purpose, items, pages, hipaa, reason, note, busy, onCancel, onSend }) =>
  <DialogShell zIndex={160} size="md" kicker="Send records" title={`Send to ${r.name}`} onClose={onCancel} testId="pk-send-dialog" footer={<><button type="button" className="sv-btn" onClick={onCancel}>Cancel</button><button type="button" className="sv-btn primary" disabled={busy} onClick={onSend} data-testid="pk-send-confirm"><Send size={15} />Sign &amp; send</button></>}>
    <dl className="v13-dl"><dt>Packet</dt><dd>{title} · {items.length} items · {pages} pages</dd><dt>Patient</dt><dd>{p.name} · DOB {p.dob} · {p.id}</dd><dt>To</dt><dd>{r.name}{r.org ? `, ${r.org}` : ''} ({RECIPIENT_LABEL[r.kind]})</dd><dt>By</dt><dd>{methodLabel(r)}</dd><dt>Purpose</dt><dd>{purpose}</dd>
      <dt>HIPAA</dt><dd><span className={`v13-pill ${hipaa.level}`}>{hipaa.title}</span>{hipaa.needsReason && <div className="sv-small mt-1">Basis: {reason || '—'}{note ? ` · ${note}` : ''}</div>}</dd></dl>
    <ol className="v13-mini">{items.map(i => <li key={i.id}>{i.title}</li>)}</ol>
    <p className="sv-small sv-muted">You confirm with your own PIN. Simulated: {r.method === 'portal' ? 'the PDF is posted to the patient’s portal messages' : r.method === 'network' ? 'the PDF summary is shared to the ASC case thread' : 'the message goes to the local outbox'}, and nothing leaves this browser.</p>
  </DialogShell>;

/* ---------------- Records sent log ---------------- */
export const RecordsSentLog: React.FC<{ p: MedPatient; compact?: boolean }> = ({ p, compact }) => {
  useMedTick(); const [actor] = useActor(); const l = recordsSent(p.id); const [open, setOpen] = useState<string | null>(null); const [re, setRe] = useState<SentRec | null>(null);
  return <section className="v7-card mb-4 v13-log" style={{ padding: '16px 18px' }} data-testid="records-sent"><div className="flex items-center gap-2"><h3 className="v7-h3 m-0">Records sent</h3><span className="sv-small sv-muted">{l.length} disclosure{l.length === 1 ? '' : 's'} · use Print / Send above the tabs</span></div>
    {l.length === 0 ? <p className="sv-small sv-muted mt-1">No records have been sent from this chart.</p> :
    <div className="v13-tablewrap"><table className="sv-table mt-2"><thead><tr><th>When</th><th>Recipient</th><th>Contents</th>{!compact && <th>HIPAA basis</th>}<th>Sent by</th><th></th></tr></thead><tbody>{l.map(r => <React.Fragment key={r.id}><tr data-testid="rs-row" data-id={r.id}>
      <td className="whitespace-nowrap">{fmtDateTime(r.at)}{r.resendOf && <div className="sv-small sv-muted">resend</div>}</td><td><b>{r.recipient.name}</b><div className="sv-small sv-muted">{RECIPIENT_LABEL[r.recipient.kind]} · {methodLabel(r.recipient)}</div></td>
      <td>{r.title}<div className="sv-small sv-muted">{r.items.length} items · {r.pages} pages · {r.purpose}</div></td>{!compact && <td><span className={`v13-pill ${r.hipaa.level}`}>{r.hipaa.code === 'authorized' ? 'Authorization on file' : r.hipaa.code === 'patient' ? 'Patient' : r.hipaa.code === 'treatment' ? 'Treatment' : 'Override'}</span>{r.hipaa.reason && <div className="sv-small sv-muted">{r.hipaa.reason}{r.hipaa.note ? ` · ${r.hipaa.note}` : ''}</div>}</td>}
      <td>{r.by}<div className="sv-small sv-muted">{r.role}</div></td>
      <td className="whitespace-nowrap text-right"><button type="button" className="sv-link sv-small" onClick={() => setOpen(open === r.id ? null : r.id)} data-testid="rs-view">{open === r.id ? 'Hide' : 'Contents'}</button>{' · '}
        <button type="button" className="sv-link sv-small" onClick={() => { const b = pdfBytesOf(r); if (b) { downloadBytes(b, fileName(p, r.title)); logAction(p, actor.name, actor.role, 'download', r.title, r.items.length); } }} data-testid="rs-download">PDF</button>{' · '}
        <button type="button" className="sv-link sv-small" onClick={() => setRe(r)} data-testid="rs-resend">Resend</button></td></tr>
      {open === r.id && <tr><td colSpan={6} className="v13-contents" data-testid="rs-contents"><ol>{r.items.map(i => <li key={i.id}>{i.title}</li>)}</ol><div className="sv-small sv-muted">{r.delivery}{r.coverLetter ? ' · with cover letter' : ''}{r.coverSheet ? ' · cover page' : ''}</div></td></tr>}</React.Fragment>)}</tbody></table></div>}
    {re && <ResendDialog p={p} r={re} onClose={() => setRe(null)} />}
  </section>;
};

const ResendDialog: React.FC<{ p: MedPatient; r: SentRec; onClose: () => void }> = ({ p, r, onClose }) => {
  const { toast } = useSv(); const [address, setAddress] = useState(r.recipient.address); const hipaa = checkHipaa(p.id, r.recipient.kind, r.recipient.name, r.purpose);
  const [reason, setReason] = useState(hipaa.defaultReason || ''); const [note, setNote] = useState(''); const [sign, setSign] = useState(false); const [err, setErr] = useState('');
  const send = async (by: { name: string; role: string }) => { setSign(false); try { const b = pdfBytesOf(r); if (!b) throw new Error('The stored PDF is missing in this browser. Build a new packet with Print / Send.');
    await deliver({ p, built: { bytes: b, pages: r.pages, toc: [] }, title: r.title, preset: r.preset, purpose: r.purpose, recipient: { ...r.recipient, address }, ids: r.items.map(i => i.id), coverLetter: r.coverLetter, coverSheet: r.coverSheet, hipaa, reason: reason || undefined, note, by: by.name, role: by.role, resendOf: r });
    toast(`Resent to ${r.recipient.name}.`); onClose(); } catch (e) { setErr((e as Error).message); } };
  return <DialogShell zIndex={150} size="lg" kicker="Records sent" title={`Resend “${r.title}”`} subtitle={`The same PDF (${r.pages} pages) sent ${fmtDateTime(r.at)} by ${r.by}. The HIPAA check runs again.`} onClose={onClose} testId="rs-resend-dialog"
    footer={<><button type="button" className="sv-btn" onClick={onClose}>Cancel</button><button type="button" className="sv-btn primary" disabled={hipaa.needsReason && !reason} onClick={() => setSign(true)} data-testid="rs-resend-send"><Send size={15} />Sign &amp; resend</button></>}>
    <p className="text-[13.5px]"><b>{r.recipient.name}</b> · {methodLabel(r.recipient)}</p>
    {(r.recipient.method === 'email' || r.recipient.method === 'fax') && <label className="block mt-1"><span className="sv-label">{r.recipient.method === 'fax' ? 'Fax number' : 'Email'}</span><input className="sv-input" value={address} onChange={e => setAddress(e.target.value)} data-testid="rs-resend-address" /></label>}
    <div className="mt-2"><HipaaPanel p={p} r={hipaa} reason={reason} setReason={setReason} note={note} setNote={setNote} /></div>{err && <p className="v13-err" role="alert">{err}</p>}
    {sign && <div className="v13-pin"><PinSign title="Sign to resend records" statement={<>I am resending {r.items.length} items from {p.name}’s record to <b>{r.recipient.name}</b>.</>} roles={ROLE_GROUP.everyone} confirmLabel="Sign & resend" onSigned={send} onClose={() => setSign(false)} /></div>}
  </DialogShell>;
};
