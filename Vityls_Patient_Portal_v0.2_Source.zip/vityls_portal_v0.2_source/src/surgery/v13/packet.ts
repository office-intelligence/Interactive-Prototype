/*
 * Surgery.Vityls v0.13 · Print / Send records packet: the data side.
 *  - packetItems(p): everything in the chart that can go in a packet, grouped (summary, documents by type, encounters,
 *    contact notes, results, photos/body charts, signed forms, quotes).
 *  - PRESETS: quick selections (pre-op clearance for ASC, consult report to referring physician, records for patient, custom).
 *  - draftCover(): the Nightingale cover letter (SIMULATED; template-based on the chart and the chosen items). A person edits it.
 *  - buildPacketPdf(): one combined PDF (pdf-lib) with letterhead, cover page, optional cover letter, table of contents,
 *    page numbers, and the patient's name, DOB and MRN on every page. Uploaded PDFs are merged page-for-page, and images embedded.
 *  - sendPacket()/resend(): simulated delivery (email/fax outbox, patient portal message with the PDF attached, or the ASC
 *    network thread). It saves the "Records sent" log entry (contents, recipient, HIPAA basis, who, when) and audits every step.
 * Backend: POST /patients/:id/disclosures {items, recipient, purpose, hipaa_basis, pdf_key}. The log doubles as the HIPAA
 * accounting of disclosures (45 CFR 164.528).
 */
import { isMedical } from '../../edition';
import { PDFDocument, StandardFonts, rgb, PDFFont, PDFPage } from 'pdf-lib';
import { repo } from '../../v6/dataLayer';
import { VITYLS_FORM_CATALOG } from '../../data/formWorkspaceCatalog';
import { medRepo, MedPatient, patientKey, uid, usDate, fmtDateTime, isoDay, addDays, vitalsText, ageFrom } from '../../med/record';
import { networkRepo } from '../../med/network';
import { getSettings } from '../../med/settings';
import { riskFlags } from '../../med/risk';
import { svRead, svWrite, surgicalHistory, nurseAdmission } from '../store';
import { labSlips, nextAscCase } from '../nightingale';
import { docsOf, DocRec } from '../documents';
import { contactNotes } from '../contactNotes';
import { photosOf, photoSrc, bodyCharts } from '../media';
import { quotesFor, cur, money, quoteSettings } from '../quotes';
import { dxList } from '../v10/dx';
import { SvPatient } from '../profile';
import { imgGet, imgPut } from '../v12/img';
import { saveAtts } from '../v12/msgAtt';
import { HipaaResult, RecipientKind, caseIdsFor, HIPAA_FILE } from './hipaa';

export type Group = 'summary' | 'documents' | 'encounters' | 'notes' | 'results' | 'photos' | 'forms' | 'quotes';
export const GROUPS: [Group, string, string?][] = [['summary', 'Summary sheet'], ['encounters', 'Encounters & visit notes'], ['notes', 'Contact / doctor notes'], ['results', 'Labs, pathology & imaging'], ['documents', 'Documents folder'], ['forms', 'Signed forms'], ['photos', 'Photos & body charts', 'optional'], ['quotes', 'Price quotes', 'optional']];
export interface PItem { id: string; group: Group; title: string; detail: string; date: string; tags: string[]; sub?: string }
const RESULT_DOC = /lab|patho|imag|x-?ray|mri|ultra|ecg|ekg/i;
const lastVisitWithNote = (pid: string) => medRepo.visits(pid).filter(v => medRepo.note(v.id)).sort((a, b) => (b.date + b.time).localeCompare(a.date + a.time))[0];

export function packetItems(p: MedPatient): PItem[] {
  const out: PItem[] = []; const T = isoDay();
  out.push({ id: 'summary', group: 'summary', title: 'Summary sheet', detail: 'Demographics, allergies, medications, PMH/PSH, risk factors, diagnoses', date: T, tags: ['summary', 'meds', 'allergies', 'hp'] });
  out.push({ id: 'meds', group: 'summary', title: 'Medication list', detail: `${medRepo.meds(p.id).filter(m => m.status === 'active').length} active`, date: T, tags: ['meds'] });
  out.push({ id: 'allergies', group: 'summary', title: 'Allergy list', detail: (p.allergies || []).join(', ') || 'not recorded', date: T, tags: ['allergies'] });
  const lv = lastVisitWithNote(p.id);
  medRepo.visits(p.id).filter(v => medRepo.note(v.id)).sort((a, b) => b.date.localeCompare(a.date)).forEach(v => { const n = medRepo.note(v.id)!; const st = n.status === 'signed' ? `signed by ${n.signedBy}` : 'draft, not signed';
    const hp = /consult|new|pre-?op|h&p|history/i.test(`${v.visitType} ${v.reason}`) || v.id === lv?.id;
    out.push({ id: `enc:${v.id}`, group: 'encounters', title: `Encounter record · ${v.visitType} · ${usDate(v.date)}`, detail: `Vitals, HPI / exam, assessment & plan, diagnosis & procedure · ${st}`, date: v.date, tags: ['encounter-full', ...(hp ? ['hp'] : []), ...(v.id === lv?.id ? ['latest'] : [])] });
    out.push({ id: `note:${v.id}`, group: 'encounters', title: `Visit note · ${v.visitType} · ${usDate(v.date)}`, detail: `SOAP note only · ${v.provider} · ${st}`, date: v.date, tags: ['encounter', ...(v.id === lv?.id ? ['latest'] : [])] }); });
  if (lv) out.push({ id: `ap:${lv.id}`, group: 'encounters', title: `Assessment & plan · ${usDate(lv.date)}`, detail: `${lv.visitType} · ${lv.provider}`, date: lv.date, tags: ['ap', 'latest'] });
  contactNotes(p.id).forEach(c => out.push({ id: `cn:${c.id}`, group: 'notes', title: `${c.channel}${c.reason ? ` · ${c.reason}` : ''}`, detail: `${c.direction} · ${c.author} · ${(c.text || '').slice(0, 70)}`, date: (c.contactAt || c.at).slice(0, 10), tags: ['contact'] }));
  labSlips(p.id).forEach((s, i) => out.push({ id: `lab:${s.date}`, group: 'results', title: `Lab results · ${usDate(s.date.slice(0, 10))}`, detail: s.labs.map(l => l.test).join(', '), date: s.date.slice(0, 10), tags: ['labs', ...(i === 0 ? ['latest'] : [])] }));
  docsOf(p.id).forEach(d => { const res = RESULT_DOC.test(d.type) || /patholog|biopsy/i.test(d.title); const t = `${d.type} ${d.title}`;
    out.push({ id: `doc:${d.id}`, group: res ? 'results' : 'documents', sub: d.type, title: d.title, detail: `${d.type} · ${d.source}${d.mime ? ` · ${d.mime.split('/')[1]}` : ''}`, date: d.docDate,
      tags: [/ecg|ekg/i.test(t) ? 'ecg' : '', /lab/i.test(t) ? 'labs' : '', /patholog|biopsy/i.test(t) ? 'path' : '', /imag|x-?ray|mri|ultra/i.test(t) ? 'imaging' : '', /clearance|consult/i.test(t) ? 'clearance' : '', /operat|op note|procedure note/i.test(t) ? 'opnote' : '', /h&p|history and physical/i.test(t) ? 'hp' : '', /consent/i.test(t) ? 'consent' : '', /referr/i.test(t) ? 'referral' : ''].filter(Boolean) }); });
  photosOf(p.id).forEach(ph => out.push({ id: `ph:${ph.id}`, group: 'photos', title: `Photo · ${ph.area} · ${ph.view}`, detail: `${ph.phase === 'before' ? 'Before' : 'After'} · ${ph.note || ph.by}`, date: ph.date, tags: ['photo'] }));
  bodyCharts(p.id).forEach(c => out.push({ id: `bc:${c.id}`, group: 'photos', title: `Body chart · ${c.title}`, detail: `v${c.version} · ${c.by}`, date: c.at.slice(0, 10), tags: ['bodychart'] }));
  caseIdsFor(p.id).forEach(cid => repo.listForms(cid).filter(f => f.status === 'locked' || f.status === 'partially-signed').forEach(f => { const c = VITYLS_FORM_CATALOG.find(y => y.file === f.file); const v = medRepo.visit(cid); const t = `${c?.title || f.file} ${f.file}`;
    out.push({ id: `form:${cid}:${f.file}`, group: 'forms', title: c?.title || f.file.replace(/\.html$/, '').replace(/_/g, ' '), detail: `${f.status === 'locked' ? 'signed' : 'partly signed'}${f.signatures[0] ? ` by ${f.signatures.map(s => s.signerName).join(', ')}` : ''} · ${v ? usDate(v.date) : 'portal'}`, date: (f.lockedAt || v?.date || isoDay()).slice(0, 10),
      tags: [/consent/i.test(t) ? 'consent' : '', /h&p|history|clearance|preop/i.test(t) ? 'hp' : '', f.file === HIPAA_FILE ? 'hipaa' : ''].filter(Boolean) }); }));
  quotesFor(p.id).forEach(q => out.push({ id: `q:${q.id}`, group: 'quotes', title: `Price quote ${q.number}`, detail: `${cur(q).procedure} · ${money(cur(q).total)} · ${q.status}`, date: cur(q).date, tags: ['quote'] }));
  return out;
}

/* ---------------- presets ---------------- */
export type PresetId = 'preop' | 'referral' | 'consult' | 'patient' | 'custom';
export interface Preset { id: PresetId; label: string; hint: string; recipient: RecipientKind; purpose: string; pick: (l: PItem[]) => string[] }
const has = (i: PItem, ...t: string[]) => t.some(x => i.tags.includes(x));
const ALL_PRESETS: Preset[] = [
  { id: 'referral', label: 'Referral packet to specialist', hint: 'Summary, problem list, med list, allergies, latest visit note, recent labs and imaging', recipient: 'doctor', purpose: 'Referral to specialist (treatment)',
    pick: l => l.filter(i => i.id === 'summary' || i.id === 'meds' || i.id === 'allergies' || i.id === 'problems' || (i.group === 'encounters' && has(i, 'latest') && (has(i, 'encounter') || has(i, 'ap'))) || (i.group === 'results' && (has(i, 'imaging') || (has(i, 'labs') && (has(i, 'latest') || i.date >= addDays(isoDay(), -180)))))).map(i => i.id) },
  { id: 'preop', label: 'Pre-op clearance packet for ASC', hint: 'H&P, consent, labs, ECG, clearance letters, med list, allergies', recipient: 'asc', purpose: 'Surgery scheduling and pre-op clearance',
    pick: l => l.filter(i => i.id === 'meds' || i.id === 'allergies' || (i.group === 'encounters' && has(i, 'encounter-full') && has(i, 'latest')) || has(i, 'consent', 'ecg', 'clearance') || (i.group === 'results' && has(i, 'labs') && (has(i, 'latest') || i.date >= addDays(isoDay(), -90))) || (i.group !== 'encounters' && has(i, 'hp') && i.id !== 'summary')).map(i => i.id) },
  { id: 'consult', label: 'Consult report to referring physician', hint: isMedical ? 'Encounter note, assessment / plan, labs, pathology' : 'Encounter note, assessment / plan, labs, pathology, op note', recipient: 'referring', purpose: 'Referral or consultation report',
    pick: l => l.filter(i => (i.group === 'encounters' && has(i, 'latest') && (has(i, 'encounter') || has(i, 'ap'))) || (i.group === 'results' && has(i, 'labs', 'path')) || has(i, 'opnote')).map(i => i.id) },
  { id: 'patient', label: 'Records for patient', hint: 'Summary, visit notes, results, signed forms, documents', recipient: 'patient', purpose: 'At the patient’s request',
    pick: l => l.filter(i => i.id === 'summary' || (i.group === 'encounters' && has(i, 'encounter')) || i.group === 'results' || i.group === 'forms' || i.group === 'documents').map(i => i.id) },
  { id: 'custom', label: 'Custom', hint: 'Start empty and choose items yourself', recipient: 'referring', purpose: 'Treatment / continuity of care', pick: () => [] },
];
/** Surgery: pre-op clearance for the ASC. Medical.Vityls: no ASC, so the first preset is a referral packet to a specialist. */
export const PRESETS: Preset[] = ALL_PRESETS.filter(p => isMedical ? p.id !== 'preop' : p.id !== 'referral');
/** Recipient types offered in the builder (Medical.Vityls has no ASC). */
export const RECIPIENT_KINDS: RecipientKind[] = isMedical ? ['referring', 'doctor', 'patient', 'free'] : ['referring', 'doctor', 'asc', 'patient', 'free'];

/* ---------------- recipients ---------------- */
export interface OutsideDoctor { id: string; name: string; specialty: string; org: string; fax: string; email: string; phone: string }
export const DEFAULT_DIRECTORY: OutsideDoctor[] = [
  { id: 'od-brooks', name: 'Lena Brooks, MD (fictional)', specialty: 'Primary care', org: 'Harbor Family Medicine', fax: '(555) 014-2201', email: 'lena.brooks@example.test', phone: '(555) 014-2200' },
  { id: 'od-haddad', name: 'Omar Haddad, MD (fictional)', specialty: 'Cardiology', org: 'Coastal Heart Associates', fax: '(555) 014-3301', email: 'omar.haddad@example.test', phone: '(555) 014-3300' },
  { id: 'od-lin', name: 'Grace Lin, MD (fictional)', specialty: 'Ophthalmology', org: 'Bayside Eye Group', fax: '(555) 014-4401', email: 'grace.lin@example.test', phone: '(555) 014-4400' },
  { id: 'od-okafor', name: 'Chidi Okafor, DO (fictional)', specialty: 'Dermatology', org: 'Coastline Dermatology', fax: '(555) 014-5501', email: 'chidi.okafor@example.test', phone: '(555) 014-5500' },
];
export const directory = () => svRead<OutsideDoctor[]>('outside-doctors', DEFAULT_DIRECTORY);
export const referringFor = (p: MedPatient): OutsideDoctor | null => { const sp = p as SvPatient; if (!sp.referredBy || !/physician|doctor|md/i.test(`${sp.referralSource} ${sp.referredBy}`)) return null;
  const ln = sp.referredBy.replace(/\(.*?\)/g, '').replace(/,.*$/, '').trim().split(/\s+/).pop()?.toLowerCase() || '';
  return directory().find(d => d.name.toLowerCase().includes(ln)) || { id: 'od-ref', name: sp.referredBy, specialty: 'Referring physician', org: '', fax: '', email: '', phone: '' }; };
export type Method = 'email' | 'fax' | 'portal' | 'network';
export interface Recipient { kind: RecipientKind; name: string; org?: string; method: Method; address: string; ascId?: string }
export const RECIPIENT_LABEL: Record<RecipientKind, string> = { referring: 'Referring physician', doctor: 'Other doctor', asc: 'Surgery center (ASC)', patient: 'Patient', free: 'Email or fax number' };
export const methodLabel = (r: Recipient) => r.method === 'portal' ? 'Patient portal' : r.method === 'network' ? 'Vityls network (ASC chart)' : r.method === 'fax' ? `Fax ${r.address}` : `Email ${r.address}`;

/* ---------------- cover letter (Nightingale, simulated) ---------------- */
export function draftCover(p: MedPatient, items: PItem[], r: Recipient, purpose: string, from: string): string {
  const sp = p as SvPatient; const dx = dxList(p)[0]; const s = getSettings(); const practice = s.practiceName.replace(/\s*\(fictional\)/, '');
  const greet = r.kind === 'patient' ? `Dear ${p.name.split(' ')[0]},` : r.kind === 'asc' ? `Dear ${r.name.replace(/\s*\(.*\)/, '')} scheduling and pre-admission team,` : `Dear Dr. ${r.name.replace(/\(.*?\)/g, '').replace(/,.*$/, '').trim().split(/\s+/).pop()},`;
  const why = r.kind === 'patient' ? `As you requested, here is a copy of your records from ${practice}.`
    : purpose.startsWith('Surgery') ? `Please find the pre-operative packet for our mutual patient, ${p.name} (DOB ${p.dob}), scheduled for ${dx?.procedures.find(x => x.status !== 'performed')?.name || dx?.procedures[0]?.name || 'surgery'}${dx ? ` for ${dx.diagnosis.toLowerCase()}` : ''}.`
    : purpose.startsWith('Referral to specialist') ? `I am referring our patient, ${p.name} (DOB ${p.dob}), for your evaluation${dx ? ` of ${dx.diagnosis.toLowerCase()}${dx.icd ? ` (${dx.icd})` : ''}` : ''}. The relevant records are enclosed.`
    : purpose.startsWith('Referral') ? `Thank you for referring ${p.name} (DOB ${p.dob}). Below is my consultation report${dx ? `: ${dx.diagnosis}${dx.icd ? ` (${dx.icd})` : ''}` : ''}.`
    : `Enclosed are records for ${p.name} (DOB ${p.dob}) for ${purpose.toLowerCase()}.`;
  const al = (p.allergies || []).join(', ');
  const ctx = r.kind === 'patient' ? '' : `\n\nKey points: ${al ? `allergies ${al}; ` : 'no allergies recorded; '}${medRepo.meds(p.id).filter(m => m.status === 'active').slice(0, 4).map(m => m.name).join(', ') || 'no active medications'}${sp.referredBy && r.kind !== 'referring' ? `; referred by ${sp.referredBy}` : ''}.`;
  const list = items.map((i, n) => `${n + 1}. ${i.title}`).join('\n');
  return `${greet}\n\n${why}${ctx}\n\nEnclosed (${items.length} item${items.length === 1 ? '' : 's'}):\n${list}\n\nPlease call ${quoteSettings().phone || 'the office'} with any questions.\n\nSincerely,\n${from}\n${practice}`;
}

/* ---------------- PDF ---------------- */
const MAP: Record<string, string> = { '’': "'", '‘': "'", '“': '"', '”': '"', '–': '-', '—': '-', '…': '...', '•': '·', '≤': '<=', '≥': '>=', '→': '->', '×': 'x', '✓': 'v', '\u00a0': ' ' };
export const safe = (s: string) => String(s ?? '').replace(/[’‘“”–—…•≤≥→×✓\u00a0]/g, c => MAP[c] || '').replace(/[^\x20-\x7E\xA0-\xFF\n]/g, '');
function wrap(t: string, f: PDFFont, size: number, w: number): string[] { const out: string[] = []; for (const para of safe(t).split('\n')) { let line = ''; if (!para.trim()) { out.push(''); continue; }
  for (const word of para.split(/\s+/)) { const tryL = line ? `${line} ${word}` : word; if (f.widthOfTextAtSize(tryL, size) <= w) line = tryL; else { if (line) out.push(line); line = word; while (f.widthOfTextAtSize(line, size) > w && line.length > 1) { let k = line.length - 1; while (k > 1 && f.widthOfTextAtSize(line.slice(0, k), size) > w) k--; out.push(line.slice(0, k)); line = line.slice(k); } } }
  out.push(line); } return out; }
interface Sec { title: string; lines: { t: string; b?: boolean; s?: number; gap?: number }[] }
export function itemContent(p: MedPatient, id: string): { title: string; blocks: Sec[]; doc?: DocRec; image?: string } {
  const [kind, ...rest] = id.split(':'); const key = rest.join(':'); const L = (t: string, b = false) => ({ t, b });
  if (kind === 'summary') { const sp = p as SvPatient; const meds = medRepo.meds(p.id).filter(m => m.status === 'active'); const pmh = medRepo.problems(p.id).filter(x => x.status === 'active'); const psh = surgicalHistory(p.id); const rf = riskFlags(p); const dx = dxList(p);
    return { title: 'Summary sheet', blocks: [
      { title: 'Demographics', lines: [L(`${p.name} · DOB ${p.dob} · ${ageFrom(p.dob)} y · ${p.sex} · MRN ${p.id}`), L(`Phone ${p.phone}${p.email ? ` · ${p.email}` : ''} · Language ${p.language}`), ...(sp.address ? [L(`${sp.address}, ${sp.city || ''} ${sp.state || ''} ${sp.zip || ''}`)] : []), L(`Surgeon / primary provider: ${p.primaryProvider}`), ...(sp.paymentType ? [L(`Payment: ${sp.paymentType}${sp.insuranceCarrier ? ` · ${sp.insuranceCarrier}` : ''}`)] : []), ...(sp.referredBy ? [L(`Referral: ${sp.referralSource || ''} · ${sp.referredBy}`)] : []), ...(sp.emergencyName ? [L(`Emergency contact: ${sp.emergencyName} (${sp.emergencyRelation || ''}) ${sp.emergencyPhone || ''}`)] : [])] },
      { title: 'Allergies', lines: [L((p.allergies || []).join(', ') || 'None recorded')] },
      { title: 'Medications', lines: meds.length ? meds.map(m => L(`${m.name} ${m.dose} ${m.frequency}`)) : [L('No active medications')] },
      { title: 'Past medical history', lines: pmh.length ? pmh.map(x => L(x.description)) : [L('None recorded')] },
      { title: 'Past surgical history', lines: psh.length ? psh.map(h => L(`${h.text}${h.year ? ` (${h.year})` : ''}`)) : [L('None recorded')] },
      { title: 'Risk factors', lines: rf.length ? rf.map(f => L(`${f.label}: ${f.detail}`)) : [L('None flagged')] },
      { title: 'Diagnoses & procedures', lines: dx.length ? dx.flatMap(d => [L(`${d.diagnosis}${d.icd ? ` (${d.icd})` : ''}`, true), ...d.procedures.map(x => L(`   ${x.name} · ${x.status}${x.date ? ` · ${usDate(x.date)}` : ''}${x.surgeon ? ` · ${x.surgeon}` : ''}`))]) : [L('None recorded')] }] }; }
  if (kind === 'meds') { const meds = medRepo.meds(p.id).filter(m => m.status === 'active'); return { title: 'Medication list', blocks: [{ title: `Active medications (${meds.length})`, lines: meds.length ? meds.map(m => L(`${m.name} ${m.dose} ${m.frequency}${m.startedAt ? ` · since ${usDate(m.startedAt.slice(0, 10))}` : ''}`)) : [L('No active medications')] }] }; }
  if (kind === 'allergies') return { title: 'Allergy list', blocks: [{ title: 'Allergies', lines: [L((p.allergies || []).join(', ') || 'None recorded'), ...(p.allergiesConfirmedAt ? [L(`Verified ${fmtDateTime(p.allergiesConfirmedAt)} by ${p.allergiesConfirmedBy}`)] : [])] }] };
  if (kind === 'enc' || kind === 'note' || kind === 'ap') { const v = medRepo.visit(key); const n = medRepo.note(key); if (!v || !n) return { title: 'Visit', blocks: [] };
    const head = { title: `${v.visitType} · ${usDate(v.date)} ${v.time} · ${v.provider}`, lines: [L(`Reason: ${v.reason || '—'}`), L(n.status === 'signed' ? `Signed by ${n.signedBy} · ${fmtDateTime(n.signedAt || '')}` : 'DRAFT: not signed')] };
    if (kind === 'ap') return { title: `Assessment & plan · ${usDate(v.date)}`, blocks: [head, { title: 'Assessment', lines: [L(n.assessment || '—')] }, { title: 'Plan', lines: [L(n.plan || '—')] }] };
    const soap = [{ title: 'History (HPI) / subjective', lines: [L(n.subjective || '—')] }, { title: 'Exam / objective', lines: [L(n.objective || '—')] }, { title: 'Assessment', lines: [L(n.assessment || '—')] }, { title: 'Plan', lines: [L(n.plan || '—')] }, ...(n.addenda || []).map(a => ({ title: `Addendum · ${fmtDateTime(a.at)} · ${a.by}`, lines: [L(a.text)] }))];
    if (kind === 'note') return { title: `Visit note · ${v.visitType} · ${usDate(v.date)}`, blocks: [head, ...soap] };
    const vit = medRepo.vitals(p.id).filter(x => x.visitId === v.id); const na = nurseAdmission(v.id); const dx = dxList(p);
    return { title: `Encounter record · ${v.visitType} · ${usDate(v.date)}`, blocks: [head, { title: 'Vitals', lines: vit.length ? vit.map(x => L(`${fmtDateTime(x.at)} · ${vitalsText(x)}`)) : [L('No vitals recorded at this visit')] },
      ...(na ? [{ title: 'Nursing intake', lines: [L(`Chief complaint: ${na.chiefComplaint}`), L(`Pain: ${na.pain} · NPO: ${na.npo} · Escort: ${na.escort}`), L(`Nurse note: ${na.nurseNote}`)] }] : []), ...soap,
      { title: 'Diagnosis & procedure', lines: dx.length ? dx.flatMap(d => [L(`${d.diagnosis}${d.icd ? ` (${d.icd})` : ''}`, true), ...d.procedures.map(x => L(`   ${x.name} · ${x.status}${x.date ? ` · ${usDate(x.date)}` : ''}`))]) : [L('None recorded')] }] }; }
  if (kind === 'cn') { const c = contactNotes(p.id).find(x => x.id === key); return { title: c ? `Contact note · ${c.channel}` : 'Contact note', blocks: c ? [{ title: `${fmtDateTime(c.contactAt || c.at)} · ${c.direction} · ${c.author} (${c.authorRole})`, lines: [L(`Reason: ${c.reason}`), L(c.text)] }] : [] }; }
  if (kind === 'lab') { const s = labSlips(p.id).find(x => x.date === key); return { title: `Lab results · ${usDate(key.slice(0, 10))}`, blocks: s ? [{ title: `Collected ${usDate(key.slice(0, 10))}`, lines: s.labs.map(l => L(`${l.test}: ${l.value} ${l.unit || ''}  (ref ${l.reportedRange || '—'}) · ${l.status}${l.reviewedBy ? ` · reviewed by ${l.reviewedBy}` : ''}`)) }] : [] }; }
  if (kind === 'doc') { const d = docsOf(p.id).find(x => x.id === key); if (!d) return { title: 'Document', blocks: [] };
    const meta = { title: `${d.type} · from ${d.source} · dated ${usDate(d.docDate)}`, lines: [L(`Filed ${fmtDateTime(d.receivedAt)} by ${d.receivedBy}`)] };
    return { title: d.title, doc: d, blocks: [meta, { title: 'Content', lines: (d.lines?.length ? d.lines : [d.text || d.description || d.summary?.text || '(no text)']).map(t => L(t)) }] }; }
  if (kind === 'ph') { const ph = photosOf(p.id).find(x => x.id === key); return { title: ph ? `Photo · ${ph.area} · ${ph.view}` : 'Photo', image: ph ? photoSrc(ph) : undefined, blocks: ph ? [{ title: `${ph.phase === 'before' ? 'Before' : 'After'} · ${usDate(ph.date)} · ${ph.by}`, lines: [L(ph.note || '')] }] : [] }; }
  if (kind === 'bc') { const c = bodyCharts(p.id).find(x => x.id === key); return { title: c ? `Body chart · ${c.title}` : 'Body chart', blocks: c ? [{ title: `Version ${c.version} · ${fmtDateTime(c.at)} · ${c.by}`, lines: [L(`${c.strokes.length} drawn mark${c.strokes.length === 1 ? '' : 's'} on the ${c.diagram} diagram (the drawing is in the chart).`), ...c.texts.map(t => L(`Label: ${t.t}`))] }] : [] }; }
  if (kind === 'form') { const [cid, ...f] = key.split(':'); const file = f.join(':'); const r = repo.getForm(cid, file); const c = VITYLS_FORM_CATALOG.find(y => y.file === file);
    const vals = Object.keys(r.values).filter(k => r.values[k] !== '' && r.values[k] !== false).map(k => L(`${(r.labels[k] || k).replace(/\s+/g, ' ').slice(0, 120)}: ${r.values[k] === true ? 'Yes' : String(r.values[k])}`));
    return { title: c?.title || file, blocks: [{ title: 'Answers', lines: vals.length ? vals : [L('(no answers recorded)')] }, { title: 'Signatures', lines: r.signatures.length ? r.signatures.map(s => L(`${s.signerName}${s.credentials ? `, ${s.credentials}` : ''} · ${s.role} · ${fmtDateTime(s.at)} · ${s.method}`)) : [L('Not signed')] }] }; }
  if (kind === 'q') { const q = quotesFor(p.id).find(x => x.id === key); if (!q) return { title: 'Quote', blocks: [] }; const v = cur(q);
    return { title: `Price quote ${q.number}`, blocks: [{ title: `${v.procedure} · ${v.surgeon} · valid until ${usDate(v.validUntil)} · ${q.status}`, lines: [...v.lines.map(l => L(`${l.label}  x${l.qty}  ${money(l.unit * l.qty)}`)), L(`Total ${money(v.total)}`, true)] }] }; }
  return { title: id, blocks: [] };
}

async function rasterize(src: string): Promise<string> { return new Promise(res => { const im = new Image(); im.onload = () => { try { const s = Math.min(1, 1400 / Math.max(im.width || 1, im.height || 1)); const c = document.createElement('canvas'); c.width = Math.max(1, Math.round((im.width || 800) * s)); c.height = Math.max(1, Math.round((im.height || 600) * s)); const g = c.getContext('2d')!; g.fillStyle = '#fff'; g.fillRect(0, 0, c.width, c.height); g.drawImage(im, 0, 0, c.width, c.height); res(c.toDataURL('image/jpeg', .85)); } catch { res(''); } }; im.onerror = () => res(''); im.src = src; }); }
const b64 = (d: string) => Uint8Array.from(atob(d.split(',')[1] || ''), c => c.charCodeAt(0));

export interface BuildOpts { p: MedPatient; ids: string[]; recipient?: Recipient; purpose: string; coverSheet: boolean; coverLetter?: string; from: string; fromRole: string; title?: string }
export interface Built { bytes: Uint8Array; pages: number; toc: { title: string; page: number }[] }
export async function buildPacketPdf(o: BuildOpts): Promise<Built> {
  const { p } = o; const s = getSettings(); const qs = quoteSettings(); const practice = safe(s.practiceName.replace(/\s*\(fictional\)/, ''));
  const doc = await PDFDocument.create(); doc.setTitle(safe(`${o.title || 'Records'} · ${p.name}`)); doc.setAuthor(practice); doc.setSubject('Protected health information · fictional test data');
  const F = await doc.embedFont(StandardFonts.Helvetica), B = await doc.embedFont(StandardFonts.HelveticaBold), I = await doc.embedFont(StandardFonts.HelveticaOblique);
  const W = 612, H = 792, M = 54, TOP = H - 70, BOT = 60; const green = rgb(.12, .43, .32), ink = rgb(.08, .1, .11), mute = rgb(.38, .42, .44);
  let page: PDFPage = doc.addPage([W, H]); let y = TOP;
  const letterhead = () => { page.drawRectangle({ x: 0, y: H - 8, width: W, height: 8, color: green }); page.drawText(practice, { x: M, y: H - 52, size: 17, font: B, color: ink }); const sub = safe(`${qs.address || ''}${qs.phone ? `  |  ${qs.phone}` : ''}`); page.drawText(sub, { x: M, y: H - 67, size: 9, font: F, color: mute }); page.drawLine({ start: { x: M, y: H - 76 }, end: { x: W - M, y: H - 76 }, thickness: 1, color: green }); y = H - 100; };
  const newPage = () => { page = doc.addPage([W, H]); y = TOP; };
  const ensure = (h: number) => { if (y - h < BOT) newPage(); };
  const para = (t: string, size = 10.5, font = F, color = ink, indent = 0, lh = 1.38) => { for (const ln of wrap(t, font, size, W - 2 * M - indent)) { ensure(size * lh); if (ln) page.drawText(ln, { x: M + indent, y: y - size, size, font, color }); y -= size * lh; } };
  const h1 = (t: string) => { ensure(40); page.drawText(safe(t).slice(0, 90), { x: M, y: y - 16, size: 15, font: B, color: ink }); y -= 22; page.drawLine({ start: { x: M, y }, end: { x: W - M, y }, thickness: .8, color: green }); y -= 12; };
  const h2 = (t: string) => { ensure(30); y -= 4; para(t, 11, B, green); y -= 2; };
  const rcp = o.recipient; const toLine = rcp ? `${rcp.name}${rcp.org ? `, ${rcp.org}` : ''}` : '(preview, no recipient yet)';
  const tocAt: { title: string; idx: number }[] = [];
  // 1. cover page
  if (o.coverSheet) { letterhead(); page.drawText('MEDICAL RECORDS', { x: M, y: y - 26, size: 26, font: B, color: ink }); y -= 40; page.drawText(safe(o.title || 'Records packet'), { x: M, y: y - 14, size: 14, font: F, color: green }); y -= 36;
    const row = (k: string, v: string) => { page.drawText(safe(k), { x: M, y: y - 11, size: 10, font: B, color: mute }); const ls = wrap(v, F, 11, W - 2 * M - 120); ls.forEach((l, i) => page.drawText(l, { x: M + 120, y: y - 11 - i * 14, size: 11, font: F, color: ink })); y -= Math.max(1, ls.length) * 14 + 8; };
    row('To', toLine); if (rcp) row('Sent by', methodLabel(rcp)); row('From', `${o.from} (${o.fromRole}), ${practice}`); row('Date', new Date().toLocaleString('en-US', { dateStyle: 'long', timeStyle: 'short' })); row('Patient', `${p.name} · DOB ${p.dob} · MRN ${p.id}`); row('Purpose', o.purpose); row('Contents', `${o.ids.length} item${o.ids.length === 1 ? '' : 's'}; see the table of contents. Pages: see the footer.`);
    y -= 10; page.drawRectangle({ x: M, y: y - 92, width: W - 2 * M, height: 92, borderColor: rgb(.75, .55, .2), borderWidth: 1, color: rgb(1, .98, .94) }); y -= 14;
    for (const l of wrap('CONFIDENTIAL HEALTH INFORMATION. This packet contains protected health information disclosed under HIPAA (45 CFR Parts 160 and 164) and the California Confidentiality of Medical Information Act. It is intended only for the recipient named above. If you received it in error, notify the sender immediately and destroy all copies. Redisclosure may be prohibited by law (including 42 CFR Part 2 for substance use disorder records).', F, 9.5, W - 2 * M - 20)) { page.drawText(l, { x: M + 10, y: y - 9, size: 9.5, font: F, color: rgb(.42, .29, .07) }); y -= 13; }
    newPage(); }
  // 2. cover letter
  if (o.coverLetter?.trim()) { if (o.coverSheet) { /* fresh page already */ } letterhead(); para(new Date().toLocaleDateString('en-US', { dateStyle: 'long' }), 10.5, F, mute); y -= 8; para(toLine, 10.5, B); y -= 4; para(`Re: ${p.name} · DOB ${p.dob} · MRN ${p.id}`, 10.5, B, green); y -= 10; para(o.coverLetter, 11); newPage(); }
  // 3. TOC placeholder index
  const tocIndex = doc.getPageCount() - 1; // current blank page becomes the first content page; TOC pages are inserted before it
  // 4. items
  let first = true;
  for (const id of o.ids) { const c = itemContent(p, id);
    if (!first) newPage(); first = false; tocAt.push({ title: c.title, idx: doc.getPageCount() - 1 }); h1(c.title);
    const d = c.doc;
    if (d?.dataUrl && /pdf/.test(d.mime || '')) { try { const src = await PDFDocument.load(b64(d.dataUrl), { ignoreEncryption: true }); para(`${d.type} · from ${d.source} · dated ${usDate(d.docDate)} · original ${src.getPageCount()} page${src.getPageCount() === 1 ? '' : 's'} follow${src.getPageCount() === 1 ? 's' : ''}.`, 10, I, mute);
      const pages = await doc.copyPages(src, src.getPageIndices()); pages.forEach(pg => doc.addPage(pg)); newPage(); first = true; continue; } catch { para('(The original PDF could not be merged; text follows.)', 10, I, mute); } }
    let img = c.image || (d?.dataUrl && /image\//.test(d.mime || '') ? d.dataUrl : '') || (d && (d as any).fromAttachmentId ? '' : '');
    if (img) { try { if (!/^data:image\/(jpeg|png)/.test(img)) img = await rasterize(img); if (img) { const e = /png/.test(img.slice(0, 30)) ? await doc.embedPng(b64(img)) : await doc.embedJpg(b64(img)); const maxW = W - 2 * M, maxH = y - BOT - 60; const sc = Math.min(maxW / e.width, maxH / e.height, 1); ensure(e.height * sc + 10); page.drawImage(e, { x: M, y: y - e.height * sc, width: e.width * sc, height: e.height * sc }); y -= e.height * sc + 12; } } catch { para('(image could not be embedded)', 10, I, mute); } }
    for (const b of c.blocks) { h2(b.title); for (const l of b.lines) para(l.t, 10.5, l.b ? B : F); y -= 4; }
  }
  if (!o.ids.length) { h1('No items selected'); para('Choose items in the packet builder.', 11, I, mute); }
  // 5. table of contents (inserted)
  const perPage = 30; const tocPages = Math.max(1, Math.ceil(tocAt.length / perPage));
  const toc = tocAt.map(t => ({ title: t.title, page: t.idx + 1 + tocPages }));
  for (let k = 0; k < tocPages; k++) { const pg = doc.insertPage(tocIndex + k, [W, H]); let ty = TOP; pg.drawText(k ? 'Table of contents (continued)' : 'Table of contents', { x: M, y: ty - 16, size: 15, font: B, color: ink }); ty -= 24; pg.drawLine({ start: { x: M, y: ty }, end: { x: W - M, y: ty }, thickness: .8, color: green }); ty -= 16;
    toc.slice(k * perPage, (k + 1) * perPage).forEach((t, i) => { const n = k * perPage + i + 1; const label = safe(`${n}.  ${t.title}`).slice(0, 88); pg.drawText(label, { x: M, y: ty - 10, size: 10.5, font: F, color: ink }); const pn = String(t.page); const wpn = F.widthOfTextAtSize(pn, 10.5); const lw = F.widthOfTextAtSize(label, 10.5);
      let dots = ''; while (F.widthOfTextAtSize(dots + ' .', 10.5) < W - 2 * M - lw - wpn - 16) dots += ' .'; pg.drawText(dots, { x: M + lw + 4, y: ty - 10, size: 10.5, font: F, color: rgb(.7, .72, .72) }); pg.drawText(pn, { x: W - M - wpn, y: ty - 10, size: 10.5, font: B, color: ink }); ty -= 18; }); }
  // 6. header + footer on every page (patient identifiers + page numbers)
  const all = doc.getPages(); const N = all.length; const idLine = safe(`${p.name}  |  DOB ${p.dob}  |  MRN ${p.id}`);
  all.forEach((pg, i) => { const { width, height } = pg.getSize(); pg.drawRectangle({ x: 0, y: 0, width, height: 34, color: rgb(1, 1, 1) }); pg.drawLine({ start: { x: 36, y: 34 }, end: { x: width - 36, y: 34 }, thickness: .5, color: rgb(.8, .8, .8) });
    pg.drawText(idLine, { x: 36, y: 20, size: 8.5, font: B, color: ink }); pg.drawText(safe(`${practice} | Confidential PHI | Fictional test data`), { x: 36, y: 9, size: 7, font: F, color: mute });
    const pn = `Page ${i + 1} of ${N}`; pg.drawText(pn, { x: width - 36 - B.widthOfTextAtSize(pn, 9), y: 16, size: 9, font: B, color: ink });
    const tw = F.widthOfTextAtSize(idLine, 7.5); pg.drawRectangle({ x: width - 36 - tw - 8, y: height - 24, width: tw + 8, height: 14, color: rgb(1, 1, 1), opacity: .85 }); pg.drawText(idLine, { x: width - 36 - tw - 4, y: height - 20, size: 7.5, font: F, color: mute }); });
  return { bytes: await doc.save(), pages: N, toc };
}

/* ---------------- send + log ---------------- */
export interface SentRec { id: string; patientId: string; at: string; by: string; role: string; title: string; preset: PresetId; purpose: string; recipient: Recipient; items: { id: string; title: string }[]; pages: number; size: number; coverLetter?: string; coverSheet: boolean;
  hipaa: { code: HipaaResult['code']; level: HipaaResult['level']; title: string; authKey?: string; reason?: string; note?: string }; resendOf?: string; delivery: string; pdfKey: string }
export const recordsSent = (pid?: string) => { const l = svRead<SentRec[]>('records-sent', []); return (pid ? l.filter(x => x.patientId === pid) : l).sort((a, b) => b.at.localeCompare(a.at)); };
export interface OutMail { id: string; at: string; to: string; channel: Method; subject: string; body: string; attachment: string; pages: number; patientId: string }
export const recordsOutbox = () => svRead<OutMail[]>('records-outbox', []);
const toDataUrl = (b: Uint8Array) => { let s = ''; for (let i = 0; i < b.length; i += 0x8000) s += String.fromCharCode(...b.subarray(i, i + 0x8000)); return `data:application/pdf;base64,${btoa(s)}`; };
export const pdfOf = (r: SentRec) => imgGet(r.pdfKey);
export const fileName = (p: MedPatient, title: string) => `${p.name.replace(/\s+/g, '_')}_${title.replace(/[^\w]+/g, '_').replace(/_+$/, '')}_${isoDay()}.pdf`;
export function logAction(p: MedPatient, by: string, role: string, what: 'preview' | 'print' | 'download', title: string, n: number) { repo.audit({ caseId: patientKey(p.id), user: by, role, action: `records.packet.${what}` as any, detail: `${what === 'preview' ? 'Previewed' : what === 'print' ? 'Printed' : 'Downloaded'} records packet “${title}” · ${n} item(s)` }); }

export async function deliver(a: { p: MedPatient; built: Built; title: string; preset: PresetId; purpose: string; recipient: Recipient; ids: string[]; coverLetter?: string; coverSheet: boolean; hipaa: HipaaResult; reason?: string; note?: string; by: string; role: string; resendOf?: SentRec }): Promise<SentRec> {
  const { p, recipient: r } = a;
  if (!r.name.trim()) throw new Error('Enter the recipient’s name.');
  if ((r.method === 'email' || r.method === 'fax') && !r.address.trim()) throw new Error(r.method === 'fax' ? 'Enter the fax number.' : 'Enter the email address.');
  if (r.method === 'email' && !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(r.address.trim())) throw new Error('That email address doesn’t look right.');
  if (r.method === 'fax' && r.address.replace(/\D/g, '').length < 10) throw new Error('Enter a 10-digit fax number.');
  if (a.hipaa.needsReason && !a.reason) throw new Error('Choose why you are sending without a signed authorization.');
  if (a.reason?.startsWith('Other') && !a.note?.trim()) throw new Error('Explain the reason.');
  const id = uid('rs'); const at = new Date().toISOString(); const pdfKey = `pkt:${id}`; const data = toDataUrl(a.built.bytes); await imgPut(pdfKey, data);
  const items = a.ids.map(i => ({ id: i, title: itemContent(p, i).title })); const fname = fileName(p, a.title);
  let delivery = '';
  if (r.method === 'portal') { const mid = uid('msg'); medRepo.addMessage({ id: mid, patientId: p.id, from: 'office', author: `${a.by} (office)`, text: `Your records are attached: ${a.title} (${a.built.pages} pages). Please keep them private.`, at });
    await saveAtts(mid, p.id, a.by, a.role, [{ tmp: id, name: fname, mime: 'application/pdf', size: a.built.bytes.length, kind: 'pdf', data }]); delivery = 'Posted to the patient portal (message with the PDF attached)'; }
  else if (r.method === 'network') { const c = nextAscCase(p.id); if (c) { networkRepo.share({ id: uid('nd'), caseId: c.id, at, fromOrg: 'office', sharedBy: a.by, title: `${a.title} (${a.built.pages} pages)`, text: items.map((x, n) => `${n + 1}. ${x.title}`).join('\n') } as any);
      networkRepo.post({ id: uid('nm'), caseId: c.id, at, fromOrg: 'office', author: a.by, role: a.role, text: `Records packet sent: ${a.title} · ${items.length} item(s), ${a.built.pages} pages.` } as any); delivery = `Shared to the ASC case thread (${r.name}) over the Vityls network (simulated)`; }
    else delivery = `No open ASC case for this patient: queued as a fax to ${r.name} (simulated)`; }
  if (r.method === 'email' || r.method === 'fax' || (r.method === 'network' && delivery.startsWith('No open'))) {
    const subject = `${a.title} · ${p.name.split(' ').map(w => w[0]).join('')} · from ${getSettings().practiceName.replace(/\s*\(fictional\)/, '')}`;
    const body = r.method === 'email' ? `To ${r.name}${r.org ? `, ${r.org}` : ''}\n\nA secure records packet (${a.built.pages} pages) is attached for ${a.purpose.toLowerCase()}. It contains protected health information; if you are not the intended recipient, delete it and tell us.\n\n(Production: sent through the practice's encrypted email gateway; recipients open it with a one-time code. Nothing left this browser.)`
      : `FAX COVER · ${a.built.pages} pages · to ${r.name} at ${r.address}. Confidential health information. (Simulated fax: nothing was sent.)`;
    svWrite('records-outbox', [...recordsOutbox(), { id: uid('ob'), at, to: `${r.name} <${r.address || r.name}>`, channel: r.method === 'network' ? 'fax' : r.method, subject, body, attachment: fname, pages: a.built.pages, patientId: p.id }]);
    if (!delivery) delivery = r.method === 'fax' ? `Fax queued to ${r.address} (simulated outbox)` : `Encrypted email queued to ${r.address} (simulated outbox)`; }
  const rec: SentRec = { id, patientId: p.id, at, by: a.by, role: a.role, title: a.title, preset: a.preset, purpose: a.purpose, recipient: r, items, pages: a.built.pages, size: a.built.bytes.length, coverLetter: a.coverLetter, coverSheet: a.coverSheet,
    hipaa: { code: a.hipaa.code, level: a.hipaa.level, title: a.hipaa.title, authKey: a.hipaa.auth?.key, reason: a.reason, note: a.note?.trim() || undefined }, resendOf: a.resendOf?.id, delivery, pdfKey };
  svWrite('records-sent', [...svRead<SentRec[]>('records-sent', []), rec]);
  if (a.hipaa.needsReason) repo.audit({ caseId: patientKey(p.id), user: a.by, role: a.role, action: 'records.hipaa.override' as any, detail: `Sent without a covering HIPAA authorization (${a.hipaa.code === 'treatment' ? 'treatment disclosure' : 'warning'}) to ${r.name}: ${a.reason}${a.note ? ` · ${a.note.trim()}` : ''}` });
  repo.audit({ caseId: patientKey(p.id), user: a.by, role: a.role, action: (a.resendOf ? 'records.packet.resend' : 'records.packet.send') as any, detail: `${a.resendOf ? 'Resent' : 'Sent'} “${a.title}” to ${r.name} (${RECIPIENT_LABEL[r.kind]}) · ${methodLabel(r)} · purpose ${a.purpose} · ${items.length} item(s), ${a.built.pages} pages: ${items.map(x => x.title).join('; ')} · HIPAA: ${a.hipaa.title} · SIMULATED, nothing left this browser` });
  window.dispatchEvent(new Event('vityls-med-updated'));
  return rec;
}
export const pdfBytesOf = (r: SentRec): Uint8Array | null => { const d = pdfOf(r); return d ? b64(d) : null; };
