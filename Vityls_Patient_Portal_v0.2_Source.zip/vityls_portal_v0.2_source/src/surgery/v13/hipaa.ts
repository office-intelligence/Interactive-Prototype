/*
 * Surgery.Vityls v0.13 · HIPAA Release of Medical Information.
 *
 * 1. Template: "Authorization for Use and Disclosure of Protected Health Information (HIPAA Release)"
 *    (HIPAA_Authorization_Release.html, bundled by Surgery only). It covers the 45 CFR 164.508(c) core elements and
 *    California CMIA (Civil Code 56.11) language. It's a normal practice template: editable in the form editor, versioned,
 *    and signed through the station signer setup (Patient / Guardian; optional staff witness).
 * 2. Default workflow: added once to My Forms at Portal / At-home and Front desk as "As needed". It is never "Required"
 *    because treatment can't be conditioned on signing an authorization (164.508(b)(4)).
 * 3. Recognition: signed (locked) copies on any of the patient's visits or portal forms are read back into structured
 *    authorizations (recipients, purposes, information, sensitive categories, expiry, revocation). The Print / Send
 *    packet's HIPAA check uses them.
 *
 * HIPAA CHECK LOGIC (soft warning, never a hard block; documented in the v0.13 changelog):
 *   - Recipient is the patient → no authorization needed (right of access, 45 CFR 164.524).
 *   - An active, signed authorization lists the recipient (by category, or by name in "Names of recipients") and
 *     the purpose → "Authorization on file". Purpose "At my request" covers any purpose.
 *   - Otherwise, the recipient is a provider (referring physician, other doctor, ASC) and the purpose is treatment
 *     (treatment, referral/consult, surgery scheduling/clearance) → soft notice. HIPAA permits treatment disclosures
 *     between providers without authorization (45 CFR 164.506(c)), and so does CMIA (Civil Code 56.10(c)(1)). The
 *     sender records a reason (pre-filled) to proceed.
 *   - Otherwise (a non-provider, or a non-treatment purpose) → warning: authorization is generally required
 *     (164.508). The sender can still override with a reason, which is audited.
 *   - An expired or revoked authorization doesn't count, and the check says so.
 *   - Sensitive categories (HIV, mental health, Part 2 SUD, genetic, reproductive) are shown so the sender can leave
 *     such records out. Records are not auto-classified in this build.
 */
import { isMedical } from '../../edition';
import { repo, FormRecord } from '../../v6/dataLayer';
import { registerBundledForm, getFormHtmlSync } from '../../v6/formSource';
import { indexFields } from '../../v6/formEnhancer';
import { VITYLS_FORM_CATALOG, workflowStorageKey } from '../../data/formWorkspaceCatalog';
import { medRepo, patientKey, isoDay, addDays, usDate } from '../../med/record';
import { svRead, svWrite } from '../store';
import html from './HIPAA_Authorization_Release.html?raw';

export const HIPAA_FILE = 'HIPAA_Authorization_Release.html';
export const HIPAA_TITLE = 'HIPAA Release: Authorization for Use and Disclosure of PHI';
registerBundledForm(HIPAA_FILE, html);
if (!VITYLS_FORM_CATALOG.some(f => f.file === HIPAA_FILE)) VITYLS_FORM_CATALOG.push({ title: HIPAA_TITLE, file: HIPAA_FILE, category: 'Consent / legal', audience: 'Patient / Front Desk', stage: 'Pre-arrival' });

/** Once per data set: My Forms + Portal/At-home + Front desk (As needed) + signer setup (Patient / Guardian, optional witness). */
export function ensureHipaaWorkflow(): boolean {
  if (svRead<boolean>('hipaa-v013', false)) return false;
  try {
    const k = 'vityls-my-forms:default-practice'; const mine = JSON.parse(localStorage.getItem(k) || '[]') as string[];
    if (!mine.includes(HIPAA_FILE)) localStorage.setItem(k, JSON.stringify([...mine, HIPAA_FILE]));
    const wf: Record<string, { enabled: boolean }> = {}; ['patientPortal', 'frontOffice', 'nursing', 'anesthesia', 'orTeam', 'surgeon', 'pacu'].forEach(s => wf[s] = { enabled: s === 'patientPortal' || s === 'frontOffice' });
    localStorage.setItem(workflowStorageKey(HIPAA_FILE), JSON.stringify(wf));
    localStorage.setItem(`vityls-form-requirement:${HIPAA_FILE}`, 'As needed');
    if (!repo.getSignerConfig(HIPAA_FILE)) repo.saveSignerConfig({ file: HIPAA_FILE, sequential: true, initials: [], updatedAt: new Date().toISOString(), updatedBy: 'Surgery.Vityls v0.13 default',
      signers: [{ id: 'patient', role: 'Patient / Guardian', label: 'Patient or personal representative', attestation: 'I authorize the uses and disclosures described in this form. If I am signing as the patient’s personal representative, I have the legal authority described in section 9.', required: true, patient: true },
        { id: 'witness', role: 'Front desk', label: 'Staff witness (optional)', attestation: 'I witnessed the patient or representative sign this authorization and offered them a copy.', required: false, patient: false }] } as any);
    repo.audit({ caseId: 'practice', user: 'System', role: 'System', action: 'forms.workflow' as any, detail: 'v0.13: HIPAA Release (Authorization for Use and Disclosure of PHI) added to My Forms at Portal / At-home and Front desk, as needed. Signed by Patient / Guardian (staff witness optional).' });
  } catch (e) { console.warn('hipaa workflow', e); }
  svWrite('hipaa-v013', true); window.dispatchEvent(new Event('vityls-med-updated')); return true;
}

/* ---------------- reading signed authorizations back ---------------- */
export interface HipaaAuth { key: string; caseId: string; patientId: string; signedAt: string; signedBy: string; rep?: string; recipients: string[]; recipientNames: string[]; info: string[]; sensitive: string[]; purposes: string[]; expiresOn?: string; expiresEvent?: string; until: string; status: 'active' | 'expired' | 'revoked'; revoked?: Revocation; seeded?: boolean }
export interface Revocation { key: string; at: string; by: string; role: string; note: string }
const revocations = () => svRead<Revocation[]>('hipaa-revocations', []);
const group = (r: FormRecord, name: string) => Object.keys(r.values).filter(k => k.startsWith(`${name}::`) && r.values[k] === true).map(k => (r.labels[k] || k.split('::')[1]).replace(/\s+/g, ' ').trim());
const text = (r: FormRecord, name: string) => { const k = Object.keys(r.values).find(x => x === name || x.startsWith(`${name}~`)); return k ? String(r.values[k] || '').trim() : ''; };
export const caseIdsFor = (pid: string) => [...medRepo.visits(pid).map(v => v.id), `portal-forms:${pid}`];
export function parseAuth(r: FormRecord, pid: string): HipaaAuth {
  const sig = r.signatures.find(s => s.slotId === 'patient') || r.signatures[0]; const signedAt = r.lockedAt || sig?.at || r.updatedAt || new Date().toISOString();
  const expiresOn = text(r, 'expires_on') || undefined; const until = expiresOn || addDays(signedAt.slice(0, 10), 365);
  const key = `${r.caseId}|${signedAt}`; const rv = revocations().find(x => x.key === key);
  return { key, caseId: r.caseId, patientId: pid, signedAt, signedBy: sig?.signerName || '—', rep: text(r, 'rep_name') || undefined, recipients: group(r, 'recipients'), recipientNames: text(r, 'recipient_names').split(/\n|;/).map(s => s.trim()).filter(Boolean), info: group(r, 'info'), sensitive: group(r, 'sensitive'), purposes: group(r, 'purpose'), expiresOn, expiresEvent: text(r, 'expires_event') || undefined, until,
    status: rv ? 'revoked' : until < isoDay() ? 'expired' : 'active', revoked: rv, seeded: !!(r as any).seeded };
}
export function hipaaAuths(pid: string): HipaaAuth[] {
  return caseIdsFor(pid).map(c => repo.getForm(c, HIPAA_FILE)).filter(r => r.status === 'locked').map(r => parseAuth(r, pid)).sort((a, b) => b.signedAt.localeCompare(a.signedAt));
}
export function revokeAuth(a: HipaaAuth, note: string, by: string, role: string) {
  if (!note.trim()) throw new Error('Describe the written revocation (how and when it was received).');
  svWrite('hipaa-revocations', [...revocations().filter(x => x.key !== a.key), { key: a.key, at: new Date().toISOString(), by, role, note: note.trim() }]);
  repo.audit({ caseId: patientKey(a.patientId), user: by, role, action: 'hipaa.revoke' as any, detail: `HIPAA authorization signed ${usDate(a.signedAt.slice(0, 10))} recorded as revoked in writing: ${note.trim()}` });
  window.dispatchEvent(new Event('vityls-med-updated'));
}

/* ---------------- the check ---------------- */
export type RecipientKind = 'referring' | 'doctor' | 'asc' | 'patient' | 'free';
export const PURPOSES = (isMedical ? ['Treatment / continuity of care', 'Referral or consultation report', 'Referral to specialist (treatment)', 'Insurance or payment', 'At the patient’s request', 'Legal', 'Other'] : ['Treatment / continuity of care', 'Referral or consultation report', 'Surgery scheduling and pre-op clearance', 'Insurance or payment', 'At the patient’s request', 'Legal', 'Other']) as readonly string[];
export const TREATMENT_PURPOSES = new Set<string>(['Treatment / continuity of care', 'Referral or consultation report', 'Surgery scheduling and pre-op clearance', 'Referral to specialist (treatment)']);
const CAT: Record<RecipientKind, RegExp> = { referring: /referr/i, doctor: /other doctors|treating|provider/i, asc: /surgery center|asc/i, patient: /$^/, free: /$^/ };
const PURP: Record<string, RegExp> = { 'Treatment / continuity of care': /treatment|continuity/i, 'Referral or consultation report': /referral|consult|treatment/i, 'Referral to specialist (treatment)': /referral|consult|treatment/i, 'Surgery scheduling and pre-op clearance': /surgery scheduling|clearance|treatment/i, 'Insurance or payment': /payment|insur/i, 'At the patient’s request': /request/i, Legal: /legal/i, Other: /$^/ };
const lastName = (n: string) => n.replace(/\(.*?\)/g, '').replace(/,.*$/, '').trim().split(/\s+/).filter(w => w.length > 1).pop()?.toLowerCase() || '';
export function authCovers(a: HipaaAuth, kind: RecipientKind, name: string, purpose: string): { recipient: boolean; purpose: boolean } {
  const ln = lastName(name); const byName = !!ln && a.recipientNames.some(r => r.toLowerCase().includes(ln));
  const byCat = a.recipients.some(r => CAT[kind].test(r)) && (kind !== 'doctor' || byName || !a.recipientNames.length);
  const purposeOk = a.purposes.some(x => /request/i.test(x)) || a.purposes.some(x => (PURP[purpose] || /$^/).test(x));
  return { recipient: byCat || byName, purpose: purposeOk };
}
export interface HipaaResult { level: 'ok' | 'info' | 'warn'; code: 'patient' | 'authorized' | 'treatment' | 'no-auth'; title: string; text: string; auth?: HipaaAuth; lapsed?: HipaaAuth; needsReason: boolean; defaultReason?: string; sensitive: string[] }
export const OVERRIDE_REASONS = ['Treatment disclosure to a provider (45 CFR 164.506(c))', 'Patient asked in person or by phone (documented in a contact note)', 'Signed authorization is on paper and not yet scanned', 'Required by law (45 CFR 164.512)', 'Other (explain)'];
export function checkHipaa(pid: string, kind: RecipientKind, name: string, purpose: string): HipaaResult {
  if (kind === 'patient') return { level: 'ok', code: 'patient', title: 'Patient’s own records', text: 'Patients have the right to their own records (45 CFR 164.524). No authorization is needed. Verify identity before release.', needsReason: false, sensitive: [] };
  const all = hipaaAuths(pid); const fits = (a: HipaaAuth) => { const c = authCovers(a, kind, name, purpose); return c.recipient && c.purpose; };
  const ok = all.find(a => a.status === 'active' && fits(a)); const lapsed = all.find(a => a.status !== 'active' && fits(a));
  if (ok) return { level: 'ok', code: 'authorized', title: 'Signed HIPAA authorization on file', text: `Signed ${usDate(ok.signedAt.slice(0, 10))} by ${ok.signedBy}${ok.rep ? ` (personal representative ${ok.rep})` : ''}. It covers this recipient and purpose and is valid until ${ok.expiresOn ? usDate(ok.until) : `${usDate(ok.until)} (one year, no date given)`}${ok.expiresEvent ? ` or ${ok.expiresEvent}` : ''}.`, auth: ok, needsReason: false, sensitive: ok.sensitive };
  const lap = lapsed ? ` The authorization signed ${usDate(lapsed.signedAt.slice(0, 10))} would have covered it, but it is ${lapsed.status === 'revoked' ? `revoked (${lapsed.revoked?.note})` : `expired (${usDate(lapsed.until)})`}.` : '';
  const provider = kind === 'referring' || kind === 'doctor' || kind === 'asc';
  if (provider && TREATMENT_PURPOSES.has(purpose)) return { level: 'info', code: 'treatment', title: 'No signed authorization on file: allowed for treatment', text: `HIPAA lets you share records with another provider for the patient’s treatment without a signed authorization (45 CFR 164.506(c)), and so does California law (Civil Code 56.10(c)(1)). Send only what this recipient needs. Psychotherapy notes, substance use disorder records (42 CFR Part 2) and HIV test results still need the patient’s specific written consent.${lap}`, lapsed, needsReason: true, defaultReason: OVERRIDE_REASONS[0], sensitive: [] };
  return { level: 'warn', code: 'no-auth', title: 'No signed HIPAA authorization covers this recipient', text: `${provider ? 'This purpose isn’t treatment.' : 'This recipient isn’t a treating provider.'} A disclosure like this usually needs the patient’s signed authorization (45 CFR 164.508; Cal. Civil Code 56.11). Ask the patient to sign the HIPAA Release first, or record why you’re sending anyway.${lap}`, lapsed, needsReason: true, sensitive: [] };
}

/* ---------------- fictional seed: Ellen has a signed release on file ---------------- */
export function seedHipaa() {
  if (svRead<boolean>('hipaa-seeded', false)) return; svWrite('hipaa-seeded', true);
  try {
    const p = medRepo.patient('MED-1001'); if (!p) return; const v = medRepo.visits(p.id).filter(x => x.date < isoDay()).sort((a, b) => b.date.localeCompare(a.date))[0]; if (!v) return;
    const doc = new DOMParser().parseFromString(getFormHtmlSync(HIPAA_FILE) || html, 'text/html'); const fields = indexFields(doc.body);
    const values: Record<string, string | boolean> = {}; const labels: Record<string, string> = {};
    const want: Record<string, string[] | string> = { disclosers: ['This practice'], recipients: isMedical ? ['Referring physician', 'Other doctors', 'Family'] : ['Referring physician', 'Surgery center', 'Family'], info: isMedical ? ['Visit notes', 'Results', 'Medications and allergies'] : ['Visit notes', 'Results', 'Operative reports', 'Medications and allergies'], purpose: isMedical ? ['Treatment', 'Referral or consultation', 'At my request'] : ['Treatment', 'Surgery scheduling', 'At my request'], ack: ['Read', 'Revoke', 'Not conditioned', 'Redisclosure'],
      recipient_names: isMedical ? 'Lena Brooks, MD (fictional) · referring physician · fax (555) 014-2201\nOmar Haddad, MD (fictional) · cardiology\nGene Testwood · daughter · gene@example.test' : 'Lena Brooks, MD (fictional) · primary care · referring physician · fax (555) 014-2201\nHarborview Surgery Center (fictional)\nGene Testwood · daughter · gene@example.test', expires_on: addDays(isoDay(), 300), patient_contact: p.phone };
    fields.forEach(f => { const el = f.el as HTMLInputElement; const nm = el.getAttribute('name') || ''; const w = want[nm]; labels[f.key] = f.label;
      if (Array.isArray(w)) values[f.key] = w.includes(el.value); else if (typeof w === 'string') values[f.key] = w; else values[f.key] = (el.type === 'checkbox' || el.type === 'radio') ? false : ''; });
    const at = new Date(`${v.date}T${v.time || '09:00'}:00`).toISOString();
    repo.saveForm({ caseId: v.id, file: HIPAA_FILE, values, labels, provenance: {}, addenda: [], status: 'locked', lockedAt: at, updatedAt: at, updatedBy: p.name,
      signatures: [{ slotId: 'patient', role: 'Patient / Guardian', signerName: p.name, attestation: 'I authorize the uses and disclosures described in this form.', at, method: 'typed', contentHash: 'seed' }], seeded: true } as any);
  } catch (e) { console.warn('hipaa seed', e); }
}
