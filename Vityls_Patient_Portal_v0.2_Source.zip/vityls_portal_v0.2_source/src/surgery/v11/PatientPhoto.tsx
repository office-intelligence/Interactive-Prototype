/* v0.11 · Patient photo on the chart header (and small avatars on Patients / Today). Initials when no photo.
 * v0.12 fix: upload uses a real <label> file input (no hidden-input programmatic click), drag & drop onto the photo,
 * live camera with a picker fallback; the picture is decoded EXIF-aware, downscaled to 512px JPEG and stored in
 * IndexedDB (see ../v12/img.ts) instead of inside the patients list in localStorage (quota). Errors say what happened.
 * Every change audited (patient.photo). */
import React, { useState } from 'react';
import { Camera, Upload, Trash2, Pencil } from 'lucide-react';
import { repo } from '../../v6/dataLayer';
import { medRepo, MedPatient, patientKey } from '../../med/record';
import { useActor, useMedTick } from '../../med/ui';
import { useSv } from '../ui';
import { imgGet, imgPut, imgDel } from '../v12/img';
import { UploadLabel, useDrop, CameraDialog } from '../v12/capture';
export const photoOf = (p?: MedPatient) => p ? imgGet(`photo:${p.id}`) || (p as MedPatient & { photo?: string }).photo || '' : '';
const initials = (n: string) => n.split(/\s+/).filter(Boolean).map(x => x[0]).slice(0, 2).join('').toUpperCase();
export async function setPhoto(p: MedPatient, photo: string | undefined, by: string, role: string, how: string) {
  if (photo) await imgPut(`photo:${p.id}`, photo); else await imgDel(`photo:${p.id}`);
  const cur = medRepo.patient(p.id) || p; if ((cur as any).photo) { const { photo: _old, ...rest } = cur as any; try { medRepo.savePatient(rest as MedPatient); } catch { /* */ } }
  repo.audit({ caseId: patientKey(p.id), user: by, role, action: 'patient.photo' as any, detail: `Patient photo ${how}` });
}
export const Avatar: React.FC<{ p: MedPatient; size?: number }> = ({ p, size = 28 }) => { useMedTick(); const ph = photoOf(p);
  return <span className="v11-av" style={{ width: size, height: size, fontSize: size * 0.4 }} aria-hidden="true" data-testid="avatar">{ph ? <img src={ph} alt="" /> : initials(p.name)}</span>; };
export const PatientPhoto: React.FC<{ p: MedPatient }> = ({ p }) => {
  useMedTick(); const [actor] = useActor(); const { toast } = useSv(); const [menu, setMenu] = useState(false); const [cam, setCam] = useState(false);
  const ph = photoOf(p);
  const onData = async (d: string, how: string) => { const had = !!photoOf(p); try { await setPhoto(p, d, actor.name, actor.role, had ? `replaced (${how})` : `added (${how})`); toast(had ? 'Photo replaced.' : 'Photo added.'); } catch (e) { toast((e as Error).message); } setMenu(false); };
  const onErr = (m: string) => { toast(m); setMenu(false); };
  const dz = useDrop(onData, onErr);
  return <div className={`v11-photo ${dz.over ? 'v12-over' : ''}`} data-testid="chart-photo" data-has={ph ? 'true' : 'false'} {...dz.props}>
    <button type="button" className="v11-photo-btn" onClick={() => setMenu(m => !m)} aria-haspopup="menu" aria-expanded={menu} aria-label={ph ? `Edit ${p.name}'s photo` : `Add a photo of ${p.name}`} data-testid="photo-edit" title="Click, or drag a JPG/PNG here">
      {ph ? <img src={ph} alt={`${p.name}`} data-testid="photo-img" /> : <span className="v11-photo-ini">{initials(p.name)}</span>}
      <span className="v11-photo-ov"><Pencil size={14} />{ph ? 'Edit' : 'Add photo'}</span></button>
    {menu && <div className="v11-photo-menu" role="menu" data-testid="photo-menu">
      <UploadLabel role="menuitem" className="v12-mi" testId="photo-upload" onData={onData} onError={onErr}><Upload size={14} />{ph ? 'Replace (upload)' : 'Upload photo'}</UploadLabel>
      <button type="button" role="menuitem" onClick={() => setCam(true)} data-testid="photo-camera"><Camera size={14} />{ph ? 'Replace (take photo)' : 'Take photo'}</button>
      {ph && <button type="button" role="menuitem" onClick={async () => { await setPhoto(p, undefined, actor.name, actor.role, 'removed'); toast('Photo removed.'); setMenu(false); }} data-testid="photo-remove"><Trash2 size={14} />Remove photo</button>}
      <span className="v11-photo-hint">JPG/PNG · or drag onto the photo · resized to 512px · audited</span></div>}
    {cam && <CameraDialog title={`Take a photo of ${p.name}`} facing="user" onClose={() => { setCam(false); setMenu(false); }} onError={onErr} onShot={d => { setCam(false); onData(d, 'camera'); }} />}
  </div>;
};
