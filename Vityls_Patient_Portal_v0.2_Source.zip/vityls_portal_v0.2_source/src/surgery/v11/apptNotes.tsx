/* v0.11 · Free-text appointment notes (front desk / scheduling notes, not clinical documentation). Stored on the visit
 * row as `notes` (Surgery namespace), audited. Shown in New/Edit appointment, the Today panel and the schedule PDF. */
import React, { useEffect, useState } from 'react';
import { repo } from '../../v6/dataLayer';
import { medRepo, MedVisit } from '../../med/record';
import { useActor } from '../../med/ui';
export type SvVisit = MedVisit & { notes?: string };
export const notesOf = (v: MedVisit) => ((v as SvVisit).notes || '').trim();
export function saveApptNotes(v: MedVisit, text: string, by: string, role: string) {
  const cur = medRepo.visits().find(x => x.id === v.id) || v; medRepo.saveVisit({ ...cur, notes: text.trim() } as SvVisit);
  repo.audit({ caseId: v.id, user: by, role, action: 'visit.notes' as any, detail: text.trim() ? `Appointment notes updated: “${text.trim().slice(0, 120)}”` : 'Appointment notes cleared' });
}
export const ApptNotesEditor: React.FC<{ v: MedVisit; testId: string; onSaved?: () => void; compact?: boolean }> = ({ v, testId, onSaved, compact }) => {
  const [actor] = useActor(); const [t, setT] = useState(notesOf(v)); useEffect(() => setT(notesOf(v)), [v.id, notesOf(v)]);
  const dirty = t.trim() !== notesOf(v);
  return <div data-testid={testId}><span className="sv-label">Appointment notes</span>
    <textarea className="sv-input" rows={compact ? 2 : 3} value={t} onChange={e => setT(e.target.value)} placeholder="e.g. Bring prior op report · prefers afternoon · interpreter (Spanish)" data-testid={`${testId}-text`} style={{ width: '100%', resize: 'vertical' }} />
    {dirty && <div className="flex gap-2 mt-1"><button type="button" className="sv-btn sm primary" onClick={() => { saveApptNotes(v, t, actor.name, actor.role); onSaved?.(); }} data-testid={`${testId}-save`}>Save notes</button><button type="button" className="sv-btn sm" onClick={() => setT(notesOf(v))}>Cancel</button></div>}</div>;
};
/** Fictional seed: two of today's appointments carry notes so the Today panel and schedule PDF show them. */
export function ensureV11ApptNotes() {
  try { const k = 'vityls-surgery-v11-apptnotes'; if (localStorage.getItem(k)) return; const d0 = new Date(); const today = `${d0.getFullYear()}-${String(d0.getMonth() + 1).padStart(2, '0')}-${String(d0.getDate()).padStart(2, '0')}`;
    const vs = medRepo.visits().filter(v => v.date >= today && v.step === 'scheduled').slice(0, 3);
    const txt = ['Daughter will drive · bring prior eyelid photos', 'Interpreter (Spanish) requested · prefers text reminders', 'Running 10 min late per phone call'];
    vs.forEach((v, i) => { if (!notesOf(v)) medRepo.saveVisit({ ...v, notes: txt[i] } as SvVisit); }); localStorage.setItem(k, '1'); } catch { /* */ }
}
