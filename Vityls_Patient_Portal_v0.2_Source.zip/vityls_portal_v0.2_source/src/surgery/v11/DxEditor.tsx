/* v0.11 · Chart › Overview › Diagnoses & procedures: add / edit / remove surgical diagnoses (optional ICD-10 text), each
 * with linked procedures (planned / performed, date, surgeon, ASC). Any role may edit; every change is audited
 * (patient.dx). Feeds the Patients list column + filter and Practice › Reports › Diagnoses & procedures. */
import { isMedical } from '../../edition';
import React, { useState } from 'react';
import { Plus, Pencil, Trash2 } from 'lucide-react';
import { repo } from '../../v6/dataLayer';
import { MedPatient, patientKey, uid, usDate } from '../../med/record';
import { useActor, useMedTick } from '../../med/ui';
import { getProviders, displayName } from '../../v7/providers';
import { PROVIDER_ROLES } from '../../med/record';
import { ascFacilities } from '../asc';
import { useSv } from '../ui';
import { DialogShell } from '../../v7/ui';
import { dxList, saveDxList, DxEntry, DxProc, DX_STATUS_LABEL, dxPairs } from '../v10/dx';
export const dxAudit = (p: MedPatient, by: string, role: string, detail: string) => repo.audit({ caseId: patientKey(p.id), user: by, role, action: 'patient.dx' as any, detail });
const blankProc = (surgeon = ''): DxProc => ({ id: uid('pr'), name: '', status: 'planned', surgeon });
export const DxCard: React.FC<{ p: MedPatient }> = ({ p }) => {
  useMedTick(); const [actor] = useActor(); const { toast } = useSv(); const [ed, setEd] = useState<{ d: DxEntry; isNew: boolean } | null>(null); const [del, setDel] = useState<DxEntry | null>(null);
  const l = dxList(p);
  return <div data-testid="dx-card">
    {l.length ? l.map(d => <div key={d.id} className="flex items-start gap-2 py-1.5 border-b border-[#eef0ee] last:border-0" data-testid="dx-entry">
      <div className="flex-1 min-w-0"><b className="text-[14px]">{d.diagnosis}</b>{d.icd && <span className="v7-muted text-[12.5px]"> · ICD-10 {d.icd}</span>}
        {d.procedures.map(x => <div key={x.id} className="text-[13px]">{x.name || '(procedure)'} · <span className={`v7-pill ${x.status === 'performed' ? 'green' : 'gray'}`}>{DX_STATUS_LABEL[x.status]}</span>{x.date ? ` · ${usDate(x.date)}` : ''}{x.surgeon ? ` · ${x.surgeon}` : ''}{x.asc ? ` · ${x.asc}` : ''}</div>)}</div>
      <button type="button" className="sv-btn sm" onClick={() => setEd({ d: JSON.parse(JSON.stringify(d)), isNew: false })} data-testid="dx-edit" aria-label={`Edit ${d.diagnosis}`}><Pencil size={13} /></button>
      <button type="button" className="sv-btn sm" onClick={() => setDel(d)} data-testid="dx-remove" aria-label={`Remove ${d.diagnosis}`}><Trash2 size={13} /></button></div>) : <span className="v7-muted text-[13px]">No surgical diagnosis recorded.</span>}
    <button type="button" className="v7-quiet mt-2 inline-flex items-center gap-1" onClick={() => setEd({ d: { id: uid('dx'), diagnosis: '', procedures: [blankProc(p.primaryProvider)] }, isNew: true })} data-testid="dx-add"><Plus size={14} />Add diagnosis</button>
    {ed && <DxDialog p={p} init={ed.d} isNew={ed.isNew} onClose={() => setEd(null)} onSave={d => { const next = ed.isNew ? [...l, d] : l.map(x => x.id === d.id ? d : x); saveDxList(p, next); dxAudit(p, actor.name, actor.role, `${ed.isNew ? 'Diagnosis added' : 'Diagnosis edited'}: ${d.diagnosis}${d.icd ? ` (${d.icd})` : ''} · ${d.procedures.map(x => `${x.name} ${DX_STATUS_LABEL[x.status]}${x.date ? ` ${x.date}` : ''}`).join('; ') || 'no procedure'}`); toast(ed.isNew ? 'Diagnosis added.' : 'Diagnosis updated.'); setEd(null); }} />}
    {del && <div className="sv-modal" role="dialog" aria-modal="true" aria-label="Remove diagnosis" data-testid="dx-remove-confirm"><div className="sv-modal-scrim" onClick={() => setDel(null)} /><div className="sv-modal-box" style={{ width: 'min(460px, calc(100vw - 24px))' }}>
      <b className="text-[15px]">Remove “{del.diagnosis}”?</b><p className="sv-small sv-muted mt-1">Its linked procedures are removed from this list too. The change is recorded in the audit trail.</p>
      <div className="flex gap-2 justify-end mt-3"><button type="button" className="sv-btn" onClick={() => setDel(null)}>Cancel</button><button type="button" className="sv-btn primary" onClick={() => { saveDxList(p, l.filter(x => x.id !== del.id)); dxAudit(p, actor.name, actor.role, `Diagnosis removed: ${del.diagnosis}`); toast('Diagnosis removed.'); setDel(null); }} data-testid="dx-remove-ok">Remove</button></div></div></div>}
  </div>;
};
export const DxDialog: React.FC<{ p: MedPatient; init: DxEntry; isNew: boolean; onClose: () => void; onSave: (d: DxEntry) => void }> = ({ p, init, isNew, onClose, onSave }) => {
  const [d, setD] = useState<DxEntry>(init); const [err, setErr] = useState('');
  const surgeons = getProviders().filter(x => x.active && PROVIDER_ROLES.includes(x.role as string)).map(displayName); const ascs = ascFacilities().filter(a => a.active).map(a => a.name);
  const known = Array.from(new Set(dxPairs().map(x => x.d.diagnosis))).sort(); const knownP = Array.from(new Set(dxPairs().flatMap(x => x.d.procedures.map(y => y.name)))).filter(Boolean).sort();
  const up = (i: number, patch: Partial<DxProc>) => setD({ ...d, procedures: d.procedures.map((x, k) => k === i ? { ...x, ...patch } : x) });
  const save = () => { if (!d.diagnosis.trim()) { setErr('Enter the diagnosis or condition.'); return; } const procs = d.procedures.filter(x => x.name.trim()).map(x => ({ ...x, name: x.name.trim(), date: x.date || undefined }));
    if (procs.some(x => x.status === 'performed' && !x.date)) { setErr('Add the date for each performed procedure.'); return; } onSave({ ...d, diagnosis: d.diagnosis.trim(), icd: d.icd?.trim() || undefined, procedures: procs }); };
  return <div className="sv-flat sv-dlg"><DialogShell size="lg" title={isNew ? 'Add diagnosis' : 'Edit diagnosis'} subtitle={`${p.name} · surgical diagnosis or condition and its procedures`} onClose={onClose} testId="dx-dialog"
    footer={<><button type="button" className="sv-btn" onClick={onClose}>Cancel</button><button type="button" className="sv-btn primary" onClick={save} data-testid="dx-save">Save</button></>}>
    <div className="grid sm:grid-cols-3 gap-3">
      <label className="sm:col-span-2"><span className="sv-label">Diagnosis / condition</span><input className="sv-input" list="dx-known" value={d.diagnosis} onChange={e => setD({ ...d, diagnosis: e.target.value })} data-testid="dx-name" /><datalist id="dx-known">{known.map(k => <option key={k} value={k} />)}</datalist></label>
      <label><span className="sv-label">ICD-10 (optional)</span><input className="sv-input" value={d.icd || ''} onChange={e => setD({ ...d, icd: e.target.value })} placeholder="e.g. H02.834" data-testid="dx-icd" /></label>
    </div>
    <div className="sv-label mt-4">Procedures</div>
    <datalist id="proc-known">{knownP.map(k => <option key={k} value={k} />)}</datalist>
    {d.procedures.map((x, i) => <div key={x.id} className="grid sm:grid-cols-6 gap-2 items-end mb-2 p-2 border border-[#e5e7eb] rounded-[3px]" data-testid="dx-proc">
      <label className="sm:col-span-2"><span className="sv-label">Procedure</span><input className="sv-input" list="proc-known" value={x.name} onChange={e => up(i, { name: e.target.value })} data-testid="dx-proc-name" /></label>
      <label><span className="sv-label">Status</span><select className="sv-input" value={x.status} onChange={e => up(i, { status: e.target.value as any })} data-testid="dx-proc-status"><option value="planned">Planned / not performed</option><option value="performed">Performed</option></select></label>
      <label><span className="sv-label">Date</span><input type="date" className="sv-input" value={x.date || ''} onChange={e => up(i, { date: e.target.value })} data-testid="dx-proc-date" /></label>
      <label><span className="sv-label">Surgeon</span><select className="sv-input" value={x.surgeon || ''} onChange={e => up(i, { surgeon: e.target.value || undefined })}><option value="">—</option>{Array.from(new Set([...(x.surgeon ? [x.surgeon] : []), ...surgeons])).map(s => <option key={s}>{s}</option>)}</select></label>
      <label><span className="sv-label">{isMedical ? 'Where' : 'ASC'}</span><span className="flex gap-1"><select className="sv-input" value={x.asc || ''} onChange={e => up(i, { asc: e.target.value || undefined })}><option value="">—</option>{Array.from(new Set([...(x.asc ? [x.asc] : []), ...ascs, 'In office', ...(isMedical ? ['Outside lab', 'Specialist', 'Hospital'] : [])])).map(s => <option key={s}>{s}</option>)}</select>
        <button type="button" className="sv-btn sm" onClick={() => setD({ ...d, procedures: d.procedures.filter((_, k) => k !== i) })} aria-label="Remove procedure" data-testid="dx-proc-remove"><Trash2 size={13} /></button></span></label></div>)}
    <button type="button" className="sv-link text-[13px]" onClick={() => setD({ ...d, procedures: [...d.procedures, blankProc(p.primaryProvider)] })} data-testid="dx-proc-add">+ Add procedure</button>
    {err && <p className="text-[13px] mt-2" style={{ color: 'var(--v7-red)' }} role="alert">{err}</p>}
  </DialogShell></div>;
};
