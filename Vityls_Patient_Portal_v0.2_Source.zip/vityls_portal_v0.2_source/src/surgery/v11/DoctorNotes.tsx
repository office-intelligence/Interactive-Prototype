/* v0.11 · Chart › Notes: every doctor / provider note, written or dictated, newest first.
 * Sources: visit (encounter) notes and their addenda, op / procedure notes (procedure visits and filed operative or
 * procedure-note documents), and contact notes written by providers. Open shows the note; Print prints it alone. */
import React from 'react';
import { medRepo, MedPatient, PROVIDER_ROLES, usDate } from '../../med/record';
import { useSv } from '../ui';
import { R, noteRef } from '../nightingale';
import { contactNotes } from '../contactNotes';
import { docsOf } from '../documents';
import { getSettings } from '../../med/settings';
export interface NoteRow { id: string; at: string; type: string; title: string; author: string; status: 'Signed' | 'Draft' | 'Filed' | 'Addendum'; dictated: boolean; text: string; open: () => void }
const PROC = /procedure|op\b|operative|surgery|injection|excision|laser/i;
export function doctorNotes(p: MedPatient, openPanel: (r: any) => void): NoteRow[] {
  const out: NoteRow[] = [];
  medRepo.visits(p.id).forEach(v => { const n = medRepo.note(v.id); if (!n) return;
    const text = [['Subjective', n.subjective], ['Objective', n.objective], ['Assessment', n.assessment], ['Plan', n.plan]].filter(([, t]) => t).map(([k, t]) => `${k}: ${t}`).join('\n\n');
    out.push({ id: v.id, at: n.signedAt || n.updatedAt || v.date, type: PROC.test(v.visitType) ? 'Procedure note' : 'Encounter note', title: `${v.visitType}${v.reason ? ` · ${v.reason}` : ''}`, author: n.signedBy || n.updatedBy || v.provider, status: n.status === 'signed' ? 'Signed' : 'Draft', dictated: /scribe|dictat/i.test(n.template || ''), text, open: () => openPanel(noteRef(v)) });
    (n.addenda || []).forEach((a, i) => out.push({ id: `${v.id}-a${i}`, at: a.at, type: 'Addendum', title: `Addendum to ${v.visitType} (${usDate(v.date)})`, author: a.by, status: 'Addendum', dictated: false, text: a.text, open: () => openPanel(noteRef(v)) })); });
  contactNotes(p.id).filter(c => PROVIDER_ROLES.includes(c.authorRole) || /md|do|np|pa-c/i.test(c.author)).forEach(c => out.push({ id: c.id, at: c.contactAt || c.at, type: 'Contact note', title: `${c.channel}${c.reason ? ` · ${c.reason}` : ''}`, author: c.author, status: 'Signed', dictated: c.dictated, text: c.text, open: () => openPanel(R('contactnotes', 'Contact notes', p.id, c.id)) }));
  docsOf(p.id).filter(d => /operative|op note|procedure note|op report/i.test(`${d.type} ${d.title}`)).forEach(d => out.push({ id: d.id, at: d.docDate, type: 'Op / procedure note', title: d.title, author: d.source, status: 'Filed', dictated: false, text: d.description || d.title, open: () => openPanel(R('doc', d.title, p.id, d.id)) }));
  return out.sort((a, b) => b.at.localeCompare(a.at));
}
const esc = (s: string) => s.replace(/&/g, '&amp;').replace(/</g, '&lt;');
function printNote(p: MedPatient, n: NoteRow) {
  const w = window.open('', '_blank', 'width=820,height=900'); if (!w) return;
  w.document.write(`<!doctype html><title>${esc(n.type)} · ${esc(p.name)}</title><style>body{font:13px/1.5 "Public Sans",Arial,sans-serif;margin:36px;color:#111}h1{font-size:18px;margin:0}h2{font-size:14px;margin:14px 0 4px}.m{color:#555;font-size:12px}pre{white-space:pre-wrap;font:inherit}hr{border:0;border-top:1px solid #999}</style>
  <h1>${esc(getSettings().practiceName.replace(/\s*\(fictional\)/, ''))}</h1><div class="m">${esc(p.name)} · DOB ${esc(p.dob)} · MRN ${esc(p.id)}</div><hr><h2>${esc(n.type)} · ${esc(n.title)}</h2><div class="m">${esc(usDate(n.at.slice(0, 10)))} · ${esc(n.author)} · ${n.status}${n.dictated ? ' · dictated' : ''}</div><pre>${esc(n.text || '(no text)')}</pre><hr><div class="m">Fictional test data · printed ${esc(new Date().toLocaleString())}</div>`);
  w.document.close(); w.focus(); w.print();
}
export const DoctorNotes: React.FC<{ p: MedPatient }> = ({ p }) => {
  const { openPanel } = useSv(); const rows = doctorNotes(p, openPanel);
  return <div className="flex flex-col gap-3" data-testid="chart-notes">
    <div className="text-[13px] v7-muted">{rows.length} doctor note{rows.length === 1 ? '' : 's'} · written and dictated · newest first</div>
    <section className="v7-card" style={{ padding: 0 }}><table className="sv-table text-[13px]" style={{ margin: 0 }}><thead><tr><th>Date</th><th>Type</th><th>Note</th><th>Author</th><th>Status</th><th /></tr></thead><tbody>
      {rows.map(n => <tr key={n.id} data-testid="note-row" data-type={n.type}><td className="whitespace-nowrap">{usDate(n.at.slice(0, 10))}</td><td>{n.type}</td><td><button type="button" className="sv-link text-left" onClick={n.open}>{n.title}</button>{n.text && <div className="v7-muted sv-small truncate" style={{ maxWidth: 360 }}>{n.text.split('\n')[0]}</div>}</td><td>{n.author}{n.dictated ? <div className="v7-muted sv-small">dictated</div> : null}</td>
        <td><span className={`v7-pill ${n.status === 'Signed' || n.status === 'Filed' ? 'green' : n.status === 'Draft' ? 'amber' : 'gray'}`}>{n.status}</span></td>
        <td className="whitespace-nowrap"><button type="button" className="sv-btn sm" onClick={n.open} data-testid="note-open">Open</button> <button type="button" className="sv-btn sm" onClick={() => printNote(p, n)} data-testid="note-print">Print</button></td></tr>)}
      {!rows.length && <tr><td colSpan={6} className="v7-muted">No doctor notes yet. Notes written or dictated at the Doctor station, and contact notes by providers, appear here.</td></tr>}</tbody></table></section>
  </div>;
};
