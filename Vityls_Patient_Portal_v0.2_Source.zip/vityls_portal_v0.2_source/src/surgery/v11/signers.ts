/* v0.11 · Surgery signer roles (office only). ASC roles map onto these; existing saved signer setups and built-in rules
 * are migrated once into saved Surgery setups so stations show office roles. ASC storage/rules are untouched. */
import { isMedical } from '../../edition';
import { repo } from '../../v6/dataLayer';
import { ruleFor } from '../../v6/formRules';
import { VITYLS_FORM_CATALOG } from '../../data/formWorkspaceCatalog';
import { svRead, svWrite } from '../store';
export const SURGERY_STAFF_SIGNER_ROLES = ['Front desk', 'Medical assistant', 'Nurse', 'Surgical coordinator', 'Physician assistant / NP', 'Surgeon / Physician'];
export const SURGERY_NON_STAFF_SIGNER_ROLES = ['Patient / Guardian', 'Witness'];
export const SURGERY_SIGNER_ROLES = ['Patient / Guardian', ...SURGERY_STAFF_SIGNER_ROLES, 'Witness'];
const MAP: Record<string, string> = {
  'Patient': 'Patient / Guardian', 'Escort': 'Patient / Guardian', 'Guardian': 'Patient / Guardian', 'Responsible adult': 'Patient / Guardian',
  'Anesthesia': 'Surgeon / Physician', 'Anesthesiologist': 'Surgeon / Physician', 'CRNA': 'Surgeon / Physician', 'Surgeon': 'Surgeon / Physician', 'Physician': 'Surgeon / Physician', 'Clinician': 'Surgeon / Physician',
  'Circulating RN': 'Nurse', 'PACU RN': 'Nurse', 'Pre-op RN': 'Nurse', 'OR RN': 'Nurse', 'OR nurse': 'Nurse', 'Scrub': 'Nurse', 'Scrub tech': 'Nurse', 'RN': 'Nurse',
  'MA': 'Medical assistant', 'Coordinator': 'Surgical coordinator', 'Surgical Coordinator': 'Surgical coordinator', 'Care Coordinator': 'Care coordinator', 'PA': 'Physician assistant / NP', 'NP': 'Physician assistant / NP' };
export const mapSurgeryRole = (r: string) => SURGERY_SIGNER_ROLES.includes(r) ? r : MAP[r] || (/anesth|crna/i.test(r) ? 'Surgeon / Physician' : /rn|nurse|pacu|circulat|scrub|or\b/i.test(r) ? 'Nurse' : /patient|guardian|escort/i.test(r) ? 'Patient / Guardian' : r);
/** Migrate once: every catalog form's effective signer rule (saved or built-in) → saved Surgery setup with office roles. */
export function migrateSurgerySigners(): number {
  if (svRead<boolean>('signers-v011', false)) return 0; let n = 0;
  VITYLS_FORM_CATALOG.forEach(f => { try { const cfg = repo.getSignerConfig(f.file); const r = ruleFor(f.file);
    const src = cfg ? cfg.signers : r.signers.map(x => ({ id: x.id, role: x.role, label: x.label, attestation: x.attestation, required: x.required, patient: !!x.patient }));
    if (!src.some(s => mapSurgeryRole(s.role) !== s.role)) return;
    const signers = src.map(s => { const role = mapSurgeryRole(s.role); return { ...s, role, label: s.label === s.role ? role : s.label }; });
    repo.saveSignerConfig({ file: f.file, signers, sequential: cfg ? cfg.sequential : !!r.sequential, initials: cfg ? cfg.initials : [], updatedAt: new Date().toISOString(), updatedBy: 'Surgery.Vityls v0.11 migration' }); n++;
  } catch { /* skip */ } });
  svWrite('signers-v011', true); if (n) repo.audit({ caseId: 'practice', user: 'System', role: 'System', action: 'form.signers.migrate' as any, detail: isMedical ? `${n} form signer setups mapped to office roles` : `v0.11: ${n} form signer setups mapped to office roles (anesthesia → Surgeon / Physician; circulator / PACU / OR nurse → Nurse)` }); return n;
}
