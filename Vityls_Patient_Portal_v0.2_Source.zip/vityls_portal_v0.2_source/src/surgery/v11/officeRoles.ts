/* v0.11 · Surgery.Vityls has office roles only. OR, PACU and anesthesia roles exist only in ASC.Vityls.
 * One-time migration of Surgery data (namespaced storage; ASC untouched):
 *   providers: Anesthesiologist / CRNA → Physician (Surgeon / Physician)
 *   staff: any OR / PACU / pre-op / circulating / scrub nurse role → RN; anesthesia staff roles → RN (staff cannot hold a
 *          provider role; re-add as a provider if they sign as Surgeon / Physician)
 *   signer setups: see signers.ts. Station keys: see v10/stations.ts. */
import { repo } from '../../v6/dataLayer';
import { getProviders, saveProviders } from '../../v7/providers';
import { staffList, saveStaff } from '../staff';
import { svRead, svWrite } from '../store';
export const ASC_ONLY_ROLE = /anesth|crna|pacu|circulat|scrub|\bor\b|operating room|pre-?op rn|or team/i;
export function migrateOfficeRoles(): { providers: number; staff: number } {
  if (svRead<boolean>('roles-v011', false)) return { providers: 0, staff: 0 }; let pv = 0, st = 0;
  try { const l = getProviders(); const n = l.map(p => ASC_ONLY_ROLE.test(String(p.role)) ? (pv++, { ...p, role: 'Physician' as any }) : p); if (pv) saveProviders(n); } catch { /* */ }
  try { const l = staffList(); const n = l.map(s => ASC_ONLY_ROLE.test(s.role) ? (st++, { ...s, role: 'RN' }) : s); if (st) saveStaff(n); } catch { /* */ }
  svWrite('roles-v011', true);
  if (pv || st) repo.audit({ caseId: 'practice', user: 'System', role: 'System', action: 'roles.migrate' as any, detail: `v0.11: ASC-only roles removed from Surgery · ${pv} provider(s) → Physician, ${st} staff → RN` });
  return { providers: pv, staff: st };
}
