/*
 * Surgery.Vityls v0.3 standard body-chart diagrams and fictional example photos, all generated as SVG in code
 * (no image files, no real people). Diagrams: neutral line art on a 600×800 sheet for the surgeon to draw on.
 * Example photos: flat illustrated figures, clearly stamped EXAMPLE DATA · FICTIONAL · NOT A REAL PERSON.
 */
type P = [number, number];
/** Catmull-Rom through the points → smooth cubic Bézier path. */
export function smooth(pts: P[], closed = false): string {
  if (pts.length < 2) return '';
  const p = closed ? [pts[pts.length - 1], ...pts, pts[0], pts[1]] : [pts[0], ...pts, pts[pts.length - 1]];
  let d = `M${p[1][0].toFixed(1)} ${p[1][1].toFixed(1)}`;
  for (let i = 1; i < p.length - 2; i++) {
    const [x0, y0] = p[i - 1], [x1, y1] = p[i], [x2, y2] = p[i + 1], [x3, y3] = p[i + 2];
    d += ` C${(x1 + (x2 - x0) / 6).toFixed(1)} ${(y1 + (y2 - y0) / 6).toFixed(1)} ${(x2 - (x3 - x1) / 6).toFixed(1)} ${(y2 - (y3 - y1) / 6).toFixed(1)} ${x2.toFixed(1)} ${y2.toFixed(1)}`;
  }
  return closed ? d + ' Z' : d;
}
const T = (pts: P[], dx: number, dy: number, s = 1, flip = false): P[] => pts.map(([x, y]) => [dx + (flip ? -x : x) * s, dy + y * s]);
/** Mirror a right-half outline (x ≥ 0, top → bottom → back to midline) into a closed symmetric outline. */
const mirror = (half: P[]): P[] => [...half, ...half.slice().reverse().map(([x, y]) => [-x, y] as P)];
const path = (d: string, extra = '') => `<path d="${d}" ${extra}/>`;
const ln = 'fill="none" stroke="#4b5563" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"';
const thin = 'fill="none" stroke="#9ca3af" stroke-width="1.5" stroke-linecap="round" stroke-dasharray="5 6"';

/* ---- shared geometry ---- */
const BODY_HALF: P[] = [[0, 118], [22, 121], [26, 146], [70, 158], [100, 172], [118, 198], [126, 260], [133, 330], [141, 400], [148, 462], [160, 500], [158, 530], [140, 532], [130, 490], [120, 440], [108, 380], [100, 300], [92, 222], [86, 280], [80, 335], [92, 400], [98, 450], [92, 530], [80, 610], [82, 690], [66, 758], [84, 784], [36, 786], [34, 758], [30, 690], [26, 610], [18, 520], [0, 462]];
const figure = (cx: number, s: number, dy = 0) => {
  const out = T(mirror(BODY_HALF), cx, dy, s);
  return path(smooth(out, true), ln) + `<circle cx="${cx}" cy="${dy + 72 * s}" r="${46 * s}" ${ln}/>`;
};
const faceFront = (o: { cx?: number; cy?: number; s?: number } = {}) => {
  const cx = o.cx ?? 300, cy = o.cy ?? 360, s = o.s ?? 1; const X = (x: number) => cx + x * s, Y = (y: number) => cy + y * s;
  const head = smooth([[0, -210], [95, -190], [148, -110], [152, 0], [138, 90], [100, 160], [48, 198], [0, 210], [-48, 198], [-100, 160], [-138, 90], [-152, 0], [-148, -110], [-95, -190]].map(([x, y]) => [X(x), Y(y)] as P), true);
  const eye = (ex: number) => path(smooth([[ex - 38, 0], [ex, -16], [ex + 38, 0], [ex, 13], [ex - 38, 0]].map(([x, y]) => [X(x), Y(y - 10)] as P)), ln) + `<circle cx="${X(ex)}" cy="${Y(-10)}" r="${9 * s}" ${ln}/>`;
  const brow = (ex: number) => path(smooth([[ex - 44, -40], [ex, -54], [ex + 44, -42]].map(([x, y]) => [X(x), Y(y)] as P)), ln);
  const ear = (side: number) => path(smooth([[side * 150, -30], [side * 172, -42], [side * 180, 0], [side * 168, 50], [side * 148, 60]].map(([x, y]) => [X(x), Y(y)] as P)), ln);
  return path(head, ln) + eye(-62) + eye(62) + brow(-62) + brow(62) + ear(1) + ear(-1)
    + path(smooth([[-6, 0], [-14, 70], [-30, 92], [-12, 100], [0, 104], [12, 100], [30, 92], [14, 70], [6, 0]].map(([x, y]) => [X(x), Y(y)] as P)), ln)
    + path(smooth([[-48, 140], [-18, 130], [0, 134], [18, 130], [48, 140], [0, 156], [-48, 140]].map(([x, y]) => [X(x), Y(y)] as P)), ln)
    + path(smooth([[-50, 205], [-52, 260]].map(([x, y]) => [X(x), Y(y)] as P)), ln) + path(smooth([[50, 205], [52, 260]].map(([x, y]) => [X(x), Y(y)] as P)), ln)
    + path(smooth([[-110, -150], [0, -175], [110, -150]].map(([x, y]) => [X(x), Y(y)] as P)), thin);
};
const PROFILE: (hump: number, sag: number) => P[] = (hump, sag) => [[-130, -160], [-10, -215], [110, -150], [140, -60], [146, -25], [140, -6], [160 + hump, 30], [196, 72], [200, 86], [176, 96], [178, 116], [164, 130], [172, 146], [160, 158], [156, 200], [120, 222 + sag * 0.4], [70, 236 + sag], [64, 300], [62, 440], [-110, 440], [-100, 260], [-150, 80], [-160, -60]];
const faceProfile = (cx = 280, cy = 340, s = 1, hump = 18, sag = 0) => {
  const pts = PROFILE(hump, sag).map(([x, y]) => [cx + x * s, cy + y * s] as P);
  return path(smooth(pts, true), ln) + `<ellipse cx="${cx - 30 * s}" cy="${cy + 10 * s}" rx="${22 * s}" ry="${38 * s}" ${ln}/>` + path(smooth([[cx + 92 * s, cy - 12 * s], [cx + 110 * s, cy - 18 * s], [cx + 124 * s, cy - 10 * s]]), ln);
};

/* ---- the chart list ---- */
export interface DiagramDef { id: string; label: string; group: 'Face & head' | 'Breast & body' | 'Limbs' | 'Other'; svg: () => string }
const sheet = (inner: string, caption: string) => `${inner}<text x="300" y="788" text-anchor="middle" font-family="Source Sans 3, sans-serif" font-size="15" fill="#6b7280">${caption}</text><text x="18" y="26" font-family="Source Sans 3, sans-serif" font-size="13" fill="#9ca3af">R</text><text x="572" y="26" font-family="Source Sans 3, sans-serif" font-size="13" fill="#9ca3af">L</text>`;
export const DIAGRAMS: DiagramDef[] = [
  { id: 'face-front', label: 'Face · front', group: 'Face & head', svg: () => sheet(faceFront(), 'Face · frontal (patient’s right on the left)') },
  { id: 'face-profile', label: 'Face · profile', group: 'Face & head', svg: () => sheet(faceProfile(), 'Face · right lateral') },
  { id: 'eyes', label: 'Eyes & lids', group: 'Face & head', svg: () => sheet([-1, 1].map(sd => { const cx = 300 + sd * 135; return path(smooth([[cx - 105, 400], [cx, 340], [cx + 105, 400], [cx, 448], [cx - 105, 400]]), ln) + `<circle cx="${cx}" cy="398" r="34" ${ln}/><circle cx="${cx}" cy="398" r="12" ${ln}/>` + path(smooth([[cx - 100, 372], [cx, 318], [cx + 100, 372]]), thin) + path(smooth([[cx - 120, 290], [cx - 20, 250], [cx + 115, 280]]), ln) + path(smooth([[cx - 90, 470], [cx, 488], [cx + 90, 468]]), thin); }).join('') + path(smooth([[300, 360], [292, 520]]), thin), 'Eyes · upper and lower lids, brows (dashed: lid crease, lower-lid line)') },
  { id: 'nose', label: 'Nose (front, profile, base)', group: 'Face & head', svg: () => sheet(
      path(smooth([[150, 120], [142, 260], [118, 330], [104, 360], [128, 372], [150, 366], [172, 372], [196, 360], [182, 330], [158, 260], [150, 120]]), ln) + `<text x="150" y="420" text-anchor="middle" font-family="Source Sans 3" font-size="14" fill="#6b7280">Front</text>`
      + path(smooth([[380, 110], [392, 160], [420, 240], [470, 330], [474, 352], [446, 360], [420, 362], [404, 380]]), ln) + `<text x="430" y="420" text-anchor="middle" font-family="Source Sans 3" font-size="14" fill="#6b7280">Profile</text>`
      + path(smooth([[200, 640], [300, 520], [400, 640], [360, 690], [300, 676], [240, 690], [200, 640]], false), ln) + `<ellipse cx="262" cy="640" rx="24" ry="14" ${ln}/><ellipse cx="338" cy="640" rx="24" ry="14" ${ln}/>` + `<text x="300" y="730" text-anchor="middle" font-family="Source Sans 3" font-size="14" fill="#6b7280">Base</text>`, 'Nose · frontal, right lateral and base views') },
  { id: 'ears', label: 'Ears', group: 'Face & head', svg: () => sheet([150, 450].map((cx, i) => { const f = i === 0 ? -1 : 1; const q = (x: number, y: number): P => [cx + f * x, y]; return path(smooth([q(-40, 220), q(30, 160), q(100, 210), q(110, 330), q(70, 440), q(30, 520), q(-10, 560), q(-40, 540), q(-30, 480), q(-50, 420)]), ln) + path(smooth([q(-10, 250), q(40, 220), q(70, 280), q(50, 380), q(10, 430)]), ln) + `<ellipse cx="${cx + f * -10}" cy="400" rx="22" ry="30" ${ln}/>`; }).join(''), 'Ears · right and left, lateral view') },
  { id: 'breast', label: 'Breast / chest', group: 'Breast & body', svg: () => sheet(
      path(smooth([[40, 130], [140, 110], [230, 128], [300, 140], [370, 128], [460, 110], [560, 130]]), ln) + path(smooth([[60, 150], [70, 420], [110, 640], [130, 760]]), ln) + path(smooth([[540, 150], [530, 420], [490, 640], [470, 760]]), ln)
      + [190, 410].map(cx => path(smooth([[cx - 105, 300], [cx - 112, 420], [cx - 60, 500], [cx, 515], [cx + 60, 500], [cx + 105, 430], [cx + 95, 330]]), ln) + `<circle cx="${cx}" cy="420" r="17" ${ln}/><circle cx="${cx}" cy="420" r="5" fill="#4b5563"/>`).join('')
      + path(smooth([[300, 160], [300, 720]]), thin) + path(smooth([[200, 680], [300, 700], [400, 680]]), thin) + `<circle cx="300" cy="700" r="6" ${ln}/>`, 'Chest and breasts · frontal (dashed: midline, umbilical level)') },
  { id: 'body-front', label: 'Body · front', group: 'Breast & body', svg: () => sheet(figure(300, 0.95, 10) + `<circle cx="300" cy="${10 + 340 * 0.95}" r="4" ${ln}/>` + [-1, 1].map(sd => `<circle cx="${300 + sd * 42}" cy="${10 + 230 * 0.95}" r="4" ${ln}/>`).join(''), 'Body · anterior') },
  { id: 'body-back', label: 'Body · back', group: 'Breast & body', svg: () => sheet(figure(300, 0.95, 10) + path(smooth([[300, 140], [300, 440]]), thin) + [-1, 1].map(sd => path(smooth([[300 + sd * 30, 190], [300 + sd * 70, 200], [300 + sd * 62, 260]]), thin)).join(''), 'Body · posterior (dashed: spine, scapulae)') },
  { id: 'abdomen', label: 'Abdomen & flanks', group: 'Breast & body', svg: () => sheet(path(smooth([[110, 90], [90, 300], [120, 520], [170, 700]]), ln) + path(smooth([[490, 90], [510, 300], [480, 520], [430, 700]]), ln) + `<circle cx="300" cy="380" r="9" ${ln}/>` + path(smooth([[150, 600], [300, 650], [450, 600]]), thin) + path(smooth([[300, 100], [300, 700]]), thin) + path(smooth([[120, 110], [300, 150], [480, 110]]), thin), 'Abdomen · frontal (dashed: costal margin, midline, low transverse line)') },
  { id: 'arms', label: 'Arms', group: 'Limbs', svg: () => sheet([170, 430].map(cx => path(smooth([[cx - 60, 80], [cx + 50, 76], [cx + 62, 200], [cx + 52, 360], [cx + 40, 520], [cx + 50, 640], [cx + 30, 740], [cx - 30, 742], [cx - 36, 640], [cx - 34, 520], [cx - 50, 360], [cx - 62, 200]], true), ln) + path(smooth([[cx - 52, 360], [cx + 52, 360]]), thin)).join('') + `<text x="170" y="770" text-anchor="middle" font-family="Source Sans 3" font-size="14" fill="#6b7280">Anterior</text><text x="430" y="770" text-anchor="middle" font-family="Source Sans 3" font-size="14" fill="#6b7280">Posterior</text>`, 'Upper arm, elbow, forearm (dashed: elbow crease)') },
  { id: 'legs', label: 'Legs', group: 'Limbs', svg: () => sheet([170, 430].map(cx => path(smooth([[cx - 90, 40], [cx + 80, 40], [cx + 74, 200], [cx + 50, 380], [cx + 54, 520], [cx + 36, 700], [cx + 40, 750], [cx - 30, 752], [cx - 28, 700], [cx - 44, 520], [cx - 40, 380], [cx - 70, 200]], true), ln) + `<ellipse cx="${cx}" cy="390" rx="30" ry="22" ${thin}/>`).join('') + `<text x="170" y="776" text-anchor="middle" font-family="Source Sans 3" font-size="14" fill="#6b7280">Anterior</text><text x="430" y="776" text-anchor="middle" font-family="Source Sans 3" font-size="14" fill="#6b7280">Posterior</text>`, 'Thigh, knee, lower leg') },
  { id: 'hands', label: 'Hands', group: 'Limbs', svg: () => sheet([170, 430].map((cx, i) => { const f = i ? 1 : -1; const fingers = [-55, -20, 15, 48].map((dx, k) => path(smooth([[cx + f * dx - 14, 360], [cx + f * dx - 14, 220 + Math.abs(k - 1.5) * 26], [cx + f * dx, 200 + Math.abs(k - 1.5) * 26], [cx + f * dx + 14, 220 + Math.abs(k - 1.5) * 26], [cx + f * dx + 14, 360]]), ln)).join(''); return fingers + path(smooth([[cx - f * 70, 360], [cx - f * 110, 420], [cx - f * 120, 320], [cx - f * 104, 300], [cx - f * 70, 400]]), ln) + path(smooth([[cx - 72, 360], [cx - 70, 520], [cx - 50, 660], [cx + 50, 660], [cx + 72, 520], [cx + 64, 360]]), ln); }).join(''), 'Hands · palmar view, right and left') },
  { id: 'genital', label: 'Genital / perineal region', group: 'Other', svg: () => sheet(path(smooth([[90, 120], [300, 160], [510, 120]]), ln) + path(smooth([[90, 120], [80, 300], [120, 520], [150, 740]]), ln) + path(smooth([[510, 120], [520, 300], [480, 520], [450, 740]]), ln) + path(smooth([[140, 300], [230, 420], [280, 520]]), thin) + path(smooth([[460, 300], [370, 420], [320, 520]]), thin) + path(smooth([[230, 360], [300, 330], [370, 360], [340, 470], [300, 520], [260, 470], [230, 360]], true), ln) + path(smooth([[280, 520], [270, 740]]), ln) + path(smooth([[320, 520], [330, 740]]), ln), 'Lower abdomen, pubic and perineal region · neutral outline (dashed: inguinal lines)') },
  { id: 'face-grid', label: 'Face · injection grid', group: 'Face & head', svg: () => sheet(faceFront() + [-1, 1].flatMap(sd => [[-140, 60, -40], [-120, 10, 40], [-80, 30, 120]].map(([y, x1, x2]) => path(smooth([[300 + sd * x1, 360 + y], [300 + sd * x2, 360 + y]]), thin))).join('') + path(smooth([[300, 140], [300, 600]]), thin), 'Face · frontal with neutral zone grid (forehead, glabella, crow’s feet, mid-face)') },
];
export const diagram = (id: string) => DIAGRAMS.find(d => d.id === id) || DIAGRAMS[0];

/* ---- fictional example photos ---- */
export type SynthView = 'frontal' | 'profile' | 'eyes';
export interface SynthSpec { view: SynthView; phase: 'before' | 'after'; tone: number; hair: number; label: string; date: string; procedure: 'facelift' | 'bleph' | 'rhino' }
const TONES = ['#e8c4a8', '#d9a98a', '#c8916f', '#a8714f', '#f0d2bc'];
const HAIRS = ['#5b4636', '#8a8a8a', '#2f2622', '#b08a5a', '#d6d3cf'];
export function synthPhotoSvg(sp: SynthSpec): string {
  const tone = TONES[sp.tone % TONES.length], hair = HAIRS[sp.hair % HAIRS.length], shade = '#00000022', line = '#00000055';
  const before = sp.phase === 'before'; const aging = (sp.procedure === 'facelift' && before) || (sp.procedure === 'bleph' && sp.hair === 1);
  let fig = '';
  if (sp.view === 'frontal') {
    fig += `<path d="M60 800 C90 660 210 610 300 610 C390 610 510 660 540 800 Z" fill="#5b6b7d"/>`;
    fig += `<path d="M245 500 L245 640 Q300 668 355 640 L355 500 Z" fill="${tone}"/><path d="M245 590 Q300 610 355 590 L355 640 Q300 668 245 640 Z" fill="${shade}"/>`;
    const jaw: P[] = sp.procedure === 'facelift' && before ? [[0, -210], [95, -190], [148, -110], [152, 0], [146, 96], [126, 150], [122, 180], [86, 196], [44, 214], [0, 222], [-44, 214], [-86, 196], [-122, 180], [-126, 150], [-146, 96], [-152, 0], [-148, -110], [-95, -190]] : [[0, -210], [95, -190], [148, -110], [152, 0], [138, 90], [100, 160], [48, 198], [0, 210], [-48, 198], [-100, 160], [-138, 90], [-152, 0], [-148, -110], [-95, -190]];
    fig += `<ellipse cx="148" cy="370" rx="22" ry="40" fill="${tone}"/><ellipse cx="452" cy="370" rx="22" ry="40" fill="${tone}"/>`;
    fig += `<path d="${smooth(jaw.map(([x, y]) => [300 + x, 360 + y] as P), true)}" fill="${tone}"/>`;
    fig += `<path d="${smooth([[-158, -40], [-150, -150], [-80, -222], [0, -236], [80, -222], [150, -150], [158, -40], [130, -120], [40, -170], [-60, -160], [-130, -110]].map(([x, y]) => [300 + x, 360 + y] as P), true)}" fill="${hair}"/>`;
    [-62, 62].forEach(ex => {
      fig += `<path d="${smooth([[ex - 38, 0], [ex, -16], [ex + 38, 0], [ex, 13], [ex - 38, 0]].map(([x, y]) => [300 + x, 350 + y] as P))}" fill="#fff" stroke="${line}" stroke-width="2"/><circle cx="${300 + ex}" cy="350" r="10" fill="#4b3a2e"/>`;
      fig += `<path d="${smooth([[ex - 44, -36], [ex, -50], [ex + 44, -38]].map(([x, y]) => [300 + x, 350 + y] as P))}" fill="none" stroke="${hair}" stroke-width="7" stroke-linecap="round"/>`;
      if (aging || (sp.procedure === 'bleph' && before)) fig += `<path d="${smooth([[ex - 42, -6], [ex, -26], [ex + 44, -4]].map(([x, y]) => [300 + x, 350 + y] as P))}" fill="none" stroke="${line}" stroke-width="3"/><path d="${smooth([[ex - 30, 22], [ex, 32], [ex + 30, 22]].map(([x, y]) => [300 + x, 350 + y] as P))}" fill="none" stroke="${line}" stroke-width="2"/>`;
      if (sp.procedure === 'bleph' && before) fig += `<path d="${smooth([[ex - 40, -2], [ex - 10, -12], [ex + 20, -10], [ex + 42, 2]].map(([x, y]) => [300 + x, 350 + y] as P))}" fill="${tone}" stroke="${line}" stroke-width="2"/>`;
    });
    fig += `<path d="M294 360 L284 430 Q300 444 316 430 L306 360" fill="none" stroke="${line}" stroke-width="2.5"/>`;
    fig += `<path d="M252 500 Q300 ${before && sp.procedure === 'facelift' ? 506 : 492} 348 500 Q300 520 252 500 Z" fill="#b5655a"/>`;
    if (sp.procedure === 'facelift' && before) fig += `<path d="M232 420 Q224 470 238 500" fill="none" stroke="${line}" stroke-width="3"/><path d="M368 420 Q376 470 362 500" fill="none" stroke="${line}" stroke-width="3"/><path d="M268 560 L262 640 M332 560 L338 640" stroke="${line}" stroke-width="3"/>`;
  } else if (sp.view === 'profile') {
    const hump = sp.procedure === 'rhino' && before ? 26 : sp.procedure === 'rhino' ? -6 : 8; const sag = sp.procedure === 'facelift' && before ? 46 : 0;
    fig += `<path d="M40 800 C80 690 200 660 300 660 C380 660 470 700 500 800 Z" fill="#5b6b7d"/>`;
    fig += `<path d="${smooth(PROFILE(hump, sag).map(([x, y]) => [280 + x, 340 + y] as P), true)}" fill="${tone}"/>`;
    fig += `<path d="${smooth([[-150, 80], [-170, -60], [-130, -170], [-10, -232], [110, -170], [130, -110], [40, -150], [-60, -120], [-100, -40], [-110, 60]].map(([x, y]) => [280 + x, 340 + y] as P), true)}" fill="${hair}"/>`;
    fig += `<ellipse cx="252" cy="350" rx="22" ry="38" fill="${tone}" stroke="${line}" stroke-width="2"/>`;
    fig += `<path d="M374 326 Q390 318 404 328" fill="none" stroke="${line}" stroke-width="3"/><path d="M372 300 Q392 290 412 300" stroke="${hair}" stroke-width="7" fill="none" stroke-linecap="round"/>`;
    if (sag) fig += `<path d="M380 560 Q350 600 345 640" stroke="${line}" stroke-width="3" fill="none"/>`;
  } else {
    fig += `<rect x="0" y="180" width="600" height="440" fill="${tone}"/>`;
    [-1, 1].forEach(sd => { const cx = 300 + sd * 140;
      fig += `<path d="${smooth([[cx - 110, 320], [cx, 260], [cx + 110, 310]])}" fill="none" stroke="${hair}" stroke-width="16" stroke-linecap="round"/>`;
      fig += `<path d="${smooth([[cx - 95, 420], [cx, 370], [cx + 95, 420], [cx, 462], [cx - 95, 420]])}" fill="#fff" stroke="${line}" stroke-width="3"/><circle cx="${cx}" cy="418" r="30" fill="#5d4433"/><circle cx="${cx}" cy="418" r="12" fill="#1f1a17"/>`;
      if (before) fig += `<path d="${smooth([[cx - 100, 418], [cx - 40, 382], [cx + 30, 380], [cx + 100, 414]])}" fill="${tone}" stroke="${line}" stroke-width="3"/><path d="${smooth([[cx - 70, 490], [cx, 510], [cx + 70, 488]])}" fill="none" stroke="${line}" stroke-width="3"/>`;
      else fig += `<path d="${smooth([[cx - 90, 386], [cx, 352], [cx + 90, 384]])}" fill="none" stroke="${line}" stroke-width="2.5"/>`;
    });
  }
  const tag = before ? '#b45309' : '#047857';
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 600 800" width="600" height="800">
<defs><linearGradient id="bg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#cfd8e3"/><stop offset="1" stop-color="#aab6c4"/></linearGradient><pattern id="g" width="50" height="50" patternUnits="userSpaceOnUse"><path d="M50 0 L0 0 0 50" fill="none" stroke="#ffffff33" stroke-width="1"/></pattern></defs>
<rect width="600" height="800" fill="url(#bg)"/><rect width="600" height="800" fill="url(#g)"/>${fig}
<rect x="0" y="0" width="600" height="40" fill="#111418cc"/><text x="300" y="26" text-anchor="middle" font-family="Arial, sans-serif" font-size="15" font-weight="700" fill="#fde68a" letter-spacing="1">EXAMPLE DATA · FICTIONAL ILLUSTRATION · NOT A REAL PERSON</text>
<rect x="0" y="752" width="600" height="48" fill="#111418cc"/><rect x="14" y="762" width="${before ? 92 : 78}" height="28" rx="4" fill="${tag}"/><text x="${before ? 60 : 53}" y="782" text-anchor="middle" font-family="Arial, sans-serif" font-size="15" font-weight="700" fill="#fff">${before ? 'BEFORE' : 'AFTER'}</text><text x="122" y="782" font-family="Arial, sans-serif" font-size="16" fill="#fff">${sp.date} · ${sp.label}</text>
<g transform="translate(560,120)"><rect x="0" y="0" width="10" height="200" fill="#ffffffcc"/>${[0, 1, 2, 3, 4].map(i => `<rect x="0" y="${i * 40}" width="10" height="20" fill="#111418"/>`).join('')}</g></svg>`;
}
export const svgUrl = (svg: string) => `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`;
