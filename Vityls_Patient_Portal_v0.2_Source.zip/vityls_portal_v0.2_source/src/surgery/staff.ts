/*
 * Surgery.Vityls staff directory and per-person signing PINs (v0.2).
 * Busy-office model: a tablet can stay signed in under a shared session ("Acting as" in this test build);
 * nobody signs in and out all day. Each person's own PIN is asked only when they sign or attest
 * (station verification, nurse admission, visit note, allergy verification, summary initial, send to ASC).
 * Several people per role. Providers use their existing provider signature PIN (v7 provider directory).
 * Test PIN for every fictional person: 1234. Swap point for Henry's identity service.
 */
import { repo, Actor } from '../v6/dataLayer';
import { getProviders, displayName, hashPin } from '../v7/providers';
import { verifyProviderPin } from '../v7/SimulatedRx';
import { PROVIDER_ROLES, patientKey } from '../med/record';
import { getSettings } from '../med/settings';
import { USERNAME_RULE, passwordProblems, pinProblems } from '../v7/invitations';
import { svRead, svWrite } from './store';
import { MED_ACTORS } from '../med/ui';
import { isMedical } from '../edition';

/** v0.3: status 'invited' = added by a manager, invitation link sent (simulated), account not created yet (cannot sign).
 *  Seeded people have no status (treated as active). email is where the invitation goes. */
export interface StaffMember { id: string; name: string; role: string; credentials?: string; pinHash: string; active: boolean; fails: number; locked?: boolean; email?: string; status?: 'invited' | 'active'; username?: string; pwHash?: string; invitedAt?: string; activatedAt?: string }
export const COORDINATOR_ROLE = isMedical ? 'Care Coordinator' : 'Surgical Coordinator';
/** Roles a manager can register on the staff page (providers are added under Practice › Providers with their own invitation). */
export const STAFF_ROLES = ['Front desk', 'Medical assistant', 'RN', COORDINATOR_ROLE, 'Practice Manager', 'Practice Administrator'];
const K = 'vityls:surgery:staff';
const SEED: Omit<StaffMember, 'pinHash' | 'fails'>[] = [
  { id: 'st-fd1', name: 'Front Desk Tester', role: 'Front desk', active: true },
  { id: 'st-fd2', name: 'Taylor Brooks', role: 'Front desk', active: true },
  { id: 'st-ma1', name: 'Morgan Avery', role: 'Medical assistant', credentials: 'MA', active: true },
  { id: 'st-ma2', name: 'Jesse Kim', role: 'Medical assistant', credentials: 'MA', active: true },
  { id: 'st-rn1', name: 'Casey Morgan', role: 'RN', credentials: 'RN', active: true },
  { id: 'st-rn2', name: 'Alex Rivera', role: 'RN', credentials: 'RN', active: true },
  { id: 'st-sc1', name: 'Riley Shaw', role: COORDINATOR_ROLE, email: 'riley.shaw@example.test', active: true },
  { id: 'st-sc2', name: 'Jordan Blake', role: COORDINATOR_ROLE, email: 'jordan.blake@example.test', active: true },
  { id: 'st-pm', name: 'Pat Quinn', role: 'Practice Manager', active: true },
  { id: 'st-adm', name: 'Practice Administrator', role: 'Practice Administrator', active: true },
];
export function staffList(): StaffMember[] {
  const seed = () => SEED.map(s => ({ ...s, pinHash: hashPin('1234'), fails: 0 }));
  try { const r = localStorage.getItem(K); if (r) { const l = JSON.parse(r) as StaffMember[]; const missing = seed().filter(x => !l.some(y => y.id === x.id)); return [...l, ...missing]; } } catch { /* */ }
  return seed();
}
export function saveStaff(l: StaffMember[]) { localStorage.setItem(K, JSON.stringify(l)); window.dispatchEvent(new Event('vityls-med-updated')); }
export const providersAsPeople = () => getProviders().filter(p => p.active && PROVIDER_ROLES.includes(p.role as string)).map(p => ({ name: displayName(p), role: p.role as string }));
/** Everyone who can sign anything here: office staff + active providers. */
export function people(): { name: string; role: string }[] { return [...staffList().filter(s => s.active).map(s => ({ name: s.name, role: s.role })), ...providersAsPeople()]; }
/** Session users for the shared-tablet "Acting as" test control. */
export function sessionUsers(): Actor[] {
  const seen = new Set<string>(); const out: Actor[] = [];
  [...MED_ACTORS, ...people().map(p => ({ name: p.name, role: p.role, kind: 'human' as const }))].forEach(a => { if (!seen.has(a.name)) { seen.add(a.name); out.push(a); } });
  return out;
}
export const ROLE_GROUP = {
  /** v0.4: open stations. Anyone on the care team may attest an office step (check-in, rooming, checkout) with their own PIN. */
  everyone: ['Front desk', 'Medical assistant', 'RN', COORDINATOR_ROLE, 'Practice Manager', 'Practice Administrator', ...PROVIDER_ROLES],
  front: ['Front desk', 'Medical assistant', 'RN', COORDINATOR_ROLE, 'Practice Manager', 'Practice Administrator', ...PROVIDER_ROLES],
  clinical: ['Medical assistant', 'RN', ...PROVIDER_ROLES],
  provider: PROVIDER_ROLES,
  billing: ['Front desk', 'Medical assistant', 'RN', COORDINATOR_ROLE, 'Practice Manager', 'Practice Administrator', ...PROVIDER_ROLES],
  /** v0.3: who may collect a payment at any time (front desk, coordinators, managers). */
  payments: ['Front desk', COORDINATOR_ROLE, 'Medical assistant', 'RN', 'Practice Manager', 'Practice Administrator'],
  coordinator: [COORDINATOR_ROLE],
  admin: ['Practice Manager', 'Practice Administrator'],
};
export const peopleIn = (roles: string[]) => people().filter(p => roles.includes(p.role));
export function verifyPersonPin(name: string, pin: string): string {
  if (!name) return 'Choose who is signing.';
  if (/nightingale|\bai\b/i.test(name)) return 'Nightingale (AI) cannot sign.';
  const st = staffList(); const s = st.find(x => x.name === name);
  if (!s) return verifyProviderPin(name, pin);
  if (!s.active) return `${name} is deactivated.`;
  if (s.status === 'invited') return `${name} has not finished account setup from the invitation link yet, so there is no PIN to sign with.`;
  if (s.locked) return `${name}’s PIN is locked after too many wrong tries. A practice manager can reset it.`;
  if (s.pinHash !== hashPin(pin)) { const fails = s.fails + 1; saveStaff(st.map(x => x.id === s.id ? { ...x, fails, locked: fails >= 5 } : x)); return fails >= 5 ? `Too many wrong PINs. ${name}’s PIN is locked.` : `That PIN doesn’t match ${name}’s PIN. ${5 - fails} tr${5 - fails === 1 ? 'y' : 'ies'} left.`; }
  if (s.fails) saveStaff(st.map(x => x.id === s.id ? { ...x, fails: 0 } : x));
  return '';
}
export function setStaffPin(id: string, pin: string, by: string, role: string) {
  if (!/^\d{4,8}$/.test(pin)) throw new Error('A PIN is 4 to 8 digits.');
  const st = staffList(); const s = st.find(x => x.id === id); if (!s) throw new Error('Unknown person.');
  saveStaff(st.map(x => x.id === id ? { ...x, pinHash: hashPin(pin), fails: 0, locked: false } : x));
  repo.audit({ caseId: 'practice', user: by, role, action: 'staff.pin', detail: `Signing PIN set for ${s.name} (${s.role})` });
}
export function addStaff(name: string, role: string, email: string, by: string, byRole: string): StaffInvite {
  if (!name.trim()) throw new Error('Enter a name.'); const st = staffList(); if (st.some(x => x.name.toLowerCase() === name.trim().toLowerCase())) throw new Error('That name is already in the list.');
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email.trim())) throw new Error('Enter an email address for the invitation link.');
  if (!STAFF_ROLES.includes(role)) throw new Error('Choose a role.');
  const id = `st-${Date.now().toString(36)}`;
  saveStaff([...st, { id, name: name.trim(), role, email: email.trim(), active: true, pinHash: '', fails: 0, status: 'invited', invitedAt: new Date().toISOString() }]);
  repo.audit({ caseId: 'practice', user: by, role: byRole, action: 'staff.pin', detail: `Staff member registered: ${name.trim()} (${role}) · no PIN until they accept the invitation` });
  return sendStaffInvite(id, by, byRole);
}

export function setStaffActive(id: string, active: boolean, by: string, byRole: string) { const st = staffList(); const s = st.find(x => x.id === id); saveStaff(st.map(x => x.id === id ? { ...x, active } : x)); repo.audit({ caseId: 'practice', user: by, role: byRole, action: 'staff.pin', detail: `${s?.name} ${active ? 'reactivated' : 'deactivated'}` }); }

/* ---------------- v0.3 staff invitations (one link: username + password + PIN) ----------------
 * Same rules as the v7 provider invitation (src/v7/invitations.ts): managers never see or set passwords or PINs; the link
 * is single use, expires in 14 days, and resending revokes the earlier link. Email is SIMULATED: the message is built in
 * full and kept in a local outbox. Henry: POST /api/staff-invitations sends it (SES/SendGrid/Postmark); GET
 * /api/staff-invite/:token validates; POST /api/staff-invite/:token/accept creates the IdP account and stores a salted PIN hash. */
export interface StaffInvite { token: string; staffId: string; to: string; toName: string; role: string; link: string; subject: string; body: string; sentAt: string; sentBy: string; expiresAt: string; usedAt?: string; revokedAt?: string; transport: 'simulated-outbox' }
const KI = 'vityls:surgery:staff-invites';
export const staffInvites = (staffId?: string): StaffInvite[] => { try { const l = JSON.parse(localStorage.getItem(KI) || '[]') as StaffInvite[]; return staffId ? l.filter(x => x.staffId === staffId) : l; } catch { return []; } };
const putInvites = (l: StaffInvite[]) => { localStorage.setItem(KI, JSON.stringify(l)); window.dispatchEvent(new Event('vityls-med-updated')); };
const tok = () => { const a = new Uint8Array(16); try { crypto.getRandomValues(a); } catch { for (let i = 0; i < 16; i++) a[i] = Math.floor(Math.random() * 256); } return Array.from(a, b => b.toString(16).padStart(2, '0')).join(''); };
export const staffInviteLink = (token: string) => `${location.href.split('#')[0].split('?')[0]}#staff-invite=${token}`;
export const parseStaffInviteHash = (h = location.hash) => { const m = h.match(/^#staff-invite=([a-f0-9]{16,64})$/i); return m ? m[1] : null; };
export function sendStaffInvite(staffId: string, by: string, byRole: string, resend = false): StaffInvite {
  const st = staffList(); const s = st.find(x => x.id === staffId); if (!s) throw new Error('Unknown person.'); if (!s.email) throw new Error(`Add ${s.name}’s email address first.`);
  const practice = getSettings().practiceName; const sentAt = new Date().toISOString(); const expiresAt = new Date(Date.now() + 14 * 864e5).toISOString(); const token = tok(); const link = staffInviteLink(token);
  const subject = `${practice} — create your Surgery.Vityls account`;
  const body = `Hello ${s.name},\n\n${practice} has added you to Surgery.Vityls as ${s.role}.\n\nUse this personal link to create your username, password and signing PIN. It can be used once and expires on ${new Date(expiresAt).toLocaleDateString()}.\n${link}\n\nYour PIN is how you sign and attest your own work on the shared office tablets. Nobody at ${practice} will ever ask for your password or PIN.\n\nThank you.\n${practice}`;
  const inv: StaffInvite = { token, staffId, to: s.email, toName: s.name, role: s.role, link, subject, body, sentAt, sentBy: by, expiresAt, transport: 'simulated-outbox' };
  putInvites([...staffInvites().map(x => x.staffId === staffId && !x.usedAt && !x.revokedAt ? { ...x, revokedAt: sentAt } : x), inv]);
  saveStaff(st.map(x => x.id === staffId ? { ...x, invitedAt: sentAt } : x));
  repo.audit({ caseId: 'practice', user: by, role: byRole, action: 'staff.invite', detail: `${resend ? 'Invitation resent' : 'Invitation sent'} to ${s.name} (${s.role}) <${s.email}> · one link: username, password, PIN · SIMULATED outbox, nothing sent${resend ? ' · earlier link revoked' : ''}` });
  return inv;
}
export type StaffInviteCheck = { state: 'ok' | 'used' | 'revoked' | 'expired' | 'invalid'; inv?: StaffInvite; staff?: StaffMember };
export function resolveStaffInvite(token: string): StaffInviteCheck {
  const inv = staffInvites().find(x => x.token === token); if (!inv) return { state: 'invalid' };
  const staff = staffList().find(x => x.id === inv.staffId); if (!staff) return { state: 'invalid' };
  return { state: inv.revokedAt ? 'revoked' : inv.usedAt ? 'used' : Date.parse(inv.expiresAt) < Date.now() ? 'expired' : 'ok', inv, staff };
}
export function acceptStaffInvite(token: string, username: string, password: string, pin: string) {
  const c = resolveStaffInvite(token); if (c.state !== 'ok' || !c.staff) throw new Error('This invitation link is not valid any more. Ask your practice manager to resend it.');
  if (!USERNAME_RULE.test(username)) throw new Error('Username: 4–32 letters, numbers, dot, dash or underscore.');
  if (staffList().some(x => x.id !== c.staff!.id && (x.username || '').toLowerCase() === username.toLowerCase())) throw new Error('That username is taken.');
  const pe = [...passwordProblems(password, username), ...pinProblems(pin)]; if (pe.length) throw new Error(pe.join('; '));
  const now = new Date().toISOString();
  saveStaff(staffList().map(x => x.id === c.staff!.id ? { ...x, username, pwHash: hashPin(`pw|${username.toLowerCase()}|${password}`), pinHash: hashPin(pin), status: 'active', activatedAt: now, fails: 0, locked: false } : x));
  putInvites(staffInvites().map(x => x.token === token ? { ...x, usedAt: now } : x));
  repo.audit({ caseId: 'practice', user: c.staff.name, role: c.staff.role, action: 'staff.account', detail: `Account created from the invitation link (username ${username}); signing PIN set by the person. Managers never see it.` });
}

/* ---------------- v0.3 surgical coordinator per patient (optional) ---------------- */
export const coordinators = () => staffList().filter(s => s.role === COORDINATOR_ROLE && s.active);
export const coordinatorFor = (pid: string): StaffMember | undefined => { const id = svRead<Record<string, string>>('coordinators', {})[pid]; return id ? staffList().find(s => s.id === id) : undefined; };
export function assignCoordinator(pid: string, staffId: string, by: string, byRole: string) {
  const m = svRead<Record<string, string>>('coordinators', {}); const before = m[pid] ? staffList().find(s => s.id === m[pid])?.name : '';
  if (staffId) m[pid] = staffId; else delete m[pid]; svWrite('coordinators', m);
  const after = staffId ? staffList().find(s => s.id === staffId)?.name : '';
  repo.audit({ caseId: patientKey(pid), user: by, role: byRole, action: 'coordinator.assign', detail: after ? `Surgical coordinator ${before ? `changed from ${before} to` : 'assigned:'} ${after}` : `Surgical coordinator removed${before ? ` (was ${before})` : ''} · optional` });
}
export const patientsOfCoordinator = (staffId: string) => Object.entries(svRead<Record<string, string>>('coordinators', {})).filter(([, id]) => id === staffId).map(([pid]) => pid);
