/* v0.8: Messages in the v0.7 design language (same data + behavior as MED's MedMessages: portal threads stored through the
   MED record layer, office replies recorded, network ASC threads simulated). Nightingale does not draft clinical replies. */
import { isMedical } from '../../edition';
import React, { useState } from 'react';
import { medRepo, uid, fmtDateTime, usDate, isoDay } from '../../med/record';
import { networkRepo, matchPatient } from '../../med/network';
import { useActor, useMedTick } from '../../med/ui';
import { useSv } from '../ui';
import { R } from '../nightingale';
import { AttChips, AttachButton, PendingChips, usePending, sendWithAtts } from '../v12/MsgAttach';
import '../v12/v12.css';
export const Messages8: React.FC<{ onOpenChart: (pid: string, s?: string) => void }> = ({ onOpenChart }) => {
  useMedTick(); const [actor] = useActor();
  const threads = medRepo.patients().map(p => ({ p, msgs: medRepo.messages(p.id) })).filter(x => x.msgs.length).sort((a, b) => b.msgs[b.msgs.length - 1].at.localeCompare(a.msgs[a.msgs.length - 1].at));
  const [sel, setSel] = useState(threads[0]?.p.id || ''); const [t, setT] = useState(''); const { toast, openPanel } = useSv(); const pend = usePending(m => toast(m));
  const cur = threads.find(x => x.p.id === sel);
  const send = async () => { if ((!t.trim() && !pend.l.length) || !cur) return; try { await sendWithAtts({ patientId: cur.p.id, from: 'office', author: `${actor.name} (office)`, text: t }, pend, actor.name, actor.role); setT(''); } catch (e) { toast((e as Error).message); } };
  const net = networkRepo.cases().filter(c => c.date >= isoDay()).map(c => ({ c, n: networkRepo.thread(c.id).length })).filter(x => x.n > 0);
  return <div className="m8" data-testid="med-messages">
    <h1 className="sv-title mb-3">Messages</h1>
    <div className="m8-grid">
      <div className="m8-col">
        <section className="v7-card m8-list"><div className="m8-k">PORTAL MESSAGES · {threads.length}</div>
          {threads.length === 0 ? <p className="sv-muted sv-small">No messages.</p> : threads.map(x => { const last = x.msgs[x.msgs.length - 1]; const wait = last.from !== 'office';
            return <button key={x.p.id} type="button" onClick={() => setSel(x.p.id)} aria-current={sel === x.p.id ? 'true' : undefined} className="m8-row" data-testid="msg-thread">
              <span className="t"><b>{x.p.name}</b>{wait && <span className="v7-pill amber ml-2">awaiting reply</span>}</span><span className="s">{last.author.replace(/\s*\(.*\)/, '')}: {last.text}</span></button>; })}</section>
        {!isMedical && <section className="v7-card m8-list"><div className="m8-k">NETWORK ASC THREADS · {net.length} <span className="v7-pill gray ml-1">simulated</span></div>
          {net.length === 0 ? <p className="sv-muted sv-small">No ASC threads.</p> : net.map(x => { const m = matchPatient(x.c); return <button key={x.c.id} type="button" disabled={!m} onClick={() => m && onOpenChart(m.id, 'network')} className="m8-row">
            <span className="t"><b>{x.c.patientName}</b></span><span className="s">{x.c.procedure} · {usDate(x.c.date)} · {x.n} message{x.n === 1 ? '' : 's'}</span></button>; })}</section>}
      </div>
      {cur ? <section className="v7-card m8-thread" aria-label={`Thread with ${cur.p.name}`}>
        <div className="flex items-center gap-2 mb-3"><div><div className="m8-k">THREAD</div><b className="text-[17px]">{cur.p.name}</b></div><button type="button" className="sv-btn sm ml-auto" onClick={() => onOpenChart(cur.p.id)} data-testid="msg-open-chart">Open chart</button></div>
        <div className="m8-msgs">{cur.msgs.map(m => <div key={m.id} className={`m8-msg ${m.from === 'office' ? 'me' : ''}`}><div className="h">{m.author} · {m.from} · {fmtDateTime(m.at)}</div>{m.text}<AttChips msgId={m.id} staff incoming={m.from !== 'office'} toast={toast} onOpenDoc={(pid, id) => openPanel(R('doc', 'Document', pid, id))} /></div>)}</div>
        <div className="flex gap-2 mt-3"><input className="sv-input" placeholder={`Reply as ${actor.name}`} value={t} onChange={e => setT(e.target.value)} onKeyDown={e => { if (e.key === 'Enter') send(); }} data-testid="office-reply" /><AttachButton pend={pend} testId="office-attach" /><button type="button" className="sv-btn primary" onClick={send} data-testid="office-send">Send</button></div>
        <PendingChips pend={pend} /><p className="sv-small sv-muted mt-1.5">Attach PDF, JPG, PNG, HEIC or DOC (photos are compressed; other files up to 3 MB). Replies are recorded in the chart. Portal delivery is simulated. Nightingale does not draft clinical replies.</p></section>
        : <section className="v7-card m8-thread"><p className="sv-muted">Choose a thread.</p></section>}
    </div></div>;
};
