/*
 * Surgery.Vityls v0.7 Patient Chart (Kevin's design A): Nightingale card (who the patient is) → ‹ Patients →
 * one header card (identity, why here, Add / dictate note · Profile · Hide / delete · More, five-column brief history)
 * → tabs: Overview · Clinical record · Documents · Photos & charts · Activity. Secondary detail opens on demand in
 * the right panel; nothing from v0.6 is removed (see the v0.7 changelog for where each capability lives).
 */
import { quotesFor, money, QuoteStatusPill, NewQuoteButton, QuoteList } from '../quotes';
import React, { useEffect, useRef, useState } from 'react';
import { ChevronDown, ChevronLeft, Mic } from 'lucide-react';
import { medRepo, MedPatient, ageFrom, usDate, fmtDate, isoDay, vitalsText } from '../../med/record';
import { useActor, useMedTick } from '../../med/ui';
import { R, Ref, labSlips, slipRef, relDay, todayVisit, nextAscCase, STATION_LABEL, lastFrom, chartNextSteps, first } from '../nightingale';
import { keptNotes, removeKeptNote, summaryInitials, initialSummary, modules } from '../store';
import { HoldToInitial, useSv, hhmm, initialsOf } from '../ui';
import { AllergyVerify, allergyStatus } from '../allergy';
import { PinSign } from '../sign';
import { ROLE_GROUP, coordinatorFor, coordinators, assignCoordinator } from '../staff';
import { ascPackets } from '../asc';
import { CollectPayment, accountFor } from '../payments';
import { PhotoGallery, PhotoGate, BodyChartsSection, photoCount, bodyCharts } from '../media';
import { PacketLine, formsPackets } from '../newPatient';
import { DocumentsSection, docsOf } from '../documents';
import { ContactNoteDialog, contactNotes } from '../contactNotes';
import { HideDeleteDialog } from '../patientAdmin';
import { EditProfileDialog, SvPatient, emergencyParts } from '../profile';
import { ReminderDialog, visitStart } from '../reminders';
import { PatientList, build, whoNarrative, timeline, Ev, ChartData } from '../SurgeryChart';
import { Chip, NightingaleCard } from './NightingaleCard';
import { DoctorNotes } from '../v11/DoctorNotes';
import { PatientPhoto } from '../v11/PatientPhoto';
import { DxCard } from '../v11/DxEditor';
import '../v11/v11.css';
import { PastVisits } from '../v12/PastVisits';
import { CardsStatus, CardsPanel } from '../v12/Cards';
import '../v12/v12.css';
import { PrintSendButton, RecordsSentLog } from '../v13/PrintSend';
import { Pill, visitStatus, Tone, prov } from './Today7';

type Tab = 'overview' | 'clinical' | 'documents' | 'photos' | 'notes' | 'activity';
import { modVisible } from '../../core/useCore';
const TABS_ALL: [Tab, string][] = [['overview', 'Overview'], ['clinical', 'Clinical record'], ['documents', 'Documents'], ['photos', 'Photos & charts'], ['notes', 'Notes'], ['activity', 'Activity']];
/** core-modules: Photos & charts belongs to the photos-bodycharts module. */
const tabsOn = (): [Tab, string][] => TABS_ALL.filter(([k]) => k !== 'photos' || modVisible('photos-bodycharts'));
const clean = (s: string) => s.replace(/\s*\(.*\)/, '');

export const Chart7: React.FC<{ patientId: string }> = ({ patientId }) => {
  useMedTick(); const { go, toast } = useSv(); const [actor] = useActor();
  const [tab, setTabRaw] = useState<Tab>('overview'); // v0.8: every (re)open of a chart starts at Overview
  const setTab = (t: Tab) => { setTabRaw(t); };
  const [pay, setPay] = useState(false); const [prof, setProf] = useState(false); const [note, setNote] = useState(false); const [hide, setHide] = useState(false);
  const last = useRef(patientId); useEffect(() => { if (last.current !== patientId) { last.current = patientId; setTab('overview'); } }, [patientId]);
  const p = medRepo.patient(patientId); const data = p ? build(p) : null;
  if (!p || !data) return <PatientList />;
  const steps = chartNextSteps(p, actor.role);
  const chips: Chip[] = steps.map(s => ({ label: s.label, act: s.act }));
  return <div className="v7-page" data-testid="sv-chart">
    <NightingaleCard patientId={p.id} reads="Reads this chart" placeholder={`Ask about ${first(p.name)}’s chart — “latest A1c”, “blood thinners”, “care team”`} summary={whoNarrative(p, data)} summaryTestId="chart-who" chips={chips} />
    <button type="button" className="v7-back" onClick={() => go({ type: 'tab', tab: 'patients' })} data-testid="chart-back"><ChevronLeft size={14} />Patients</button>
    <Header p={p} data={data} onProfile={() => setProf(true)} onNote={() => setNote(true)} onHide={() => setHide(true)} onPay={() => setPay(true)} />
    <div className="v13-tabrow">    <div className="v7-tabs" role="tablist" aria-label="Chart sections" data-testid="chart-tabs">{tabsOn().map(([k, l]) => <button key={k} type="button" role="tab" aria-selected={tab === k} onClick={() => setTab(k)} data-testid={`chart-tab-${k}`}>{l}{k === 'documents' ? <span className="c">{docsOf(p.id).length}</span> : k === 'photos' ? <span className="c">{photoCount(p.id) + bodyCharts(p.id).length}</span> : null}</button>)}</div>{modVisible('records-packets') && <PrintSendButton p={p} />}</div>
    <div role="tabpanel" aria-label={(TABS_ALL.find(t => t[0] === tab) || TABS_ALL[0])[1]}>
      {tab === 'overview' && <Overview p={p} data={data} onPay={() => setPay(true)} onProfile={() => setProf(true)} />}
      {tab === 'clinical' && <Clinical p={p} data={data} />}
      {tab === 'documents' && <div className="v7-docs"><section className="v7-card mb-4" style={{ padding: '16px 18px' }} data-testid="docs-cards"><h3 className="v7-h3">ID &amp; insurance cards</h3><CardsPanel p={p} via="chart" /></section>{modVisible('billing') && <div className="v7-card mb-4" style={{ padding: '16px 18px' }}><QuoteList p={p} /></div>}<DocumentsSection p={p} /><div className="mt-4">{modVisible('records-packets') && <RecordsSentLog p={p} compact />}</div></div>}
      {tab === 'photos' && modVisible('photos-bodycharts') && <Photos p={p} />}
      {tab === 'notes' && <DoctorNotes p={p} />}
      {tab === 'activity' && <>{modVisible('records-packets') && <RecordsSentLog p={p} />}<Activity p={p} onNotes={() => setTab('notes')} /></>}
    </div>
    {prof && <EditProfileDialog pid={p.id} onClose={() => setProf(false)} />}
    {note && <ContactNoteDialog p={p} onClose={() => setNote(false)} onSaved={n => { setNote(false); toast(`Note saved to ${p.name}’s chart${n.signed ? ` and signed by ${n.signed.by}` : ''}.`); }} />}
    {hide && <HideDeleteDialog p={p} session={actor.name} onClose={() => setHide(false)} onDone={m => { setHide(false); toast(m === 'delete' ? `${p.name}’s chart was permanently deleted. The audit trail is kept.` : `${p.name}’s chart is hidden. Restore it in Practice › Patient records.`); go({ type: 'tab', tab: 'patients' }); }} />}
    {pay && <CollectPayment p={p} onClose={() => setPay(false)} />}
  </div>;
};

/* ---------------- header card ---------------- */
const Header: React.FC<{ p: MedPatient; data: ChartData; onProfile: () => void; onNote: () => void; onHide: () => void; onPay: () => void }> = ({ p, data, onProfile, onNote, onHide, onPay }) => {
  const { openPanel, go } = useSv(); const al = allergyStatus(p); const v = todayVisit(p.id); const newMsg = lastFrom(p.id);
  const encounter = v || medRepo.visits(p.id).filter(x => x.date < isoDay()).sort((x, y) => y.date.localeCompare(x.date))[0];
  const meds = medRepo.meds(p.id).filter(m => m.status === 'active'); const pmh = medRepo.problems(p.id).filter(x => x.status === 'active');
  const Col: React.FC<{ label: string; r: Ref; tid: string; children: React.ReactNode }> = ({ label, r, tid, children }) => <div className="v7-brief-col" data-testid={tid}>
    <button type="button" className="glabel" onClick={() => openPanel(r)} title={`Open ${r.label}`}>{label}</button><div className="items">{children}</div></div>;
  const items = (l: string[], empty = 'None recorded') => l.length ? l.map((x, i) => <span key={i}>{x}</span>) : <span className="v7-muted">{empty}</span>;
  return <header className="v7-card v7-head" data-testid="chart-header">
    <div className="v7-head-top">
      <div className="v11-headrow min-w-0"><PatientPhoto p={p} /><div className="min-w-0">
        <h1 className="v7-name" data-testid="chart-name">{p.name}</h1>
        <div className="v7-demo" data-testid="chart-demo"><span>{ageFrom(p.dob)} years · {p.sex}</span><i>·</i><span>DOB {p.dob}</span><i>·</i><span className="mono">MRN {p.id}</span>{p.language && p.language !== 'English' && <><i>·</i><span>{p.language}</span></>}</div>
        <div className="v7-why" data-testid="chart-why"><b>Why here:</b> {data.why}
          {v ? <button type="button" className="v7-quiet ml-2" onClick={() => go({ type: 'station', visitId: v.id })} data-testid="chart-station">{v.step === 'scheduled' ? 'Open visit workflow' : v.step === 'complete' ? 'Visit record' : `Continue · ${STATION_LABEL[v.step]}`} →</button>
            : encounter && <button type="button" className="v7-quiet ml-2" onClick={() => go({ type: 'station', visitId: encounter.id })} data-testid="chart-workflow-link">Last visit workflow · {usDate(encounter.date)} →</button>}</div>
        {newMsg && <button type="button" className="v7-newmsg" onClick={() => openPanel(R('messages', 'Portal messages', p.id))} data-testid="chart-new-message"><span className="v7-dot red" aria-hidden="true" /><b>New message</b><span className="min-w-0 truncate">from {clean(newMsg.author)} · {relDay(newMsg.at.slice(0, 10))} · “{newMsg.text.slice(0, 80)}{newMsg.text.length > 80 ? '…' : ''}”</span><span className="go">Read &amp; reply →</span></button>}
      </div></div>
      <div className="v7-head-acts">
        <button type="button" className="v7-btn" onClick={onNote} data-testid="chart-add-note" title="Document a phone call, portal message or walk-in (any staff member)"><Mic size={14} />Add / dictate note</button>
        <button type="button" className="v7-btn" onClick={onProfile} data-testid="chart-profile-btn" title="Edit profile & contact information">Profile</button>
        <MoreMenu p={p} onPay={onPay} />
      </div>
    </div>
    <div className="v7-brief">
      <div className="v7-brief-col" data-testid="chart-allergy">
        <button type="button" className="glabel" onClick={() => openPanel(R('allergies', 'Allergies', p.id))}>ALLERGIES</button>
        <div className="items">{al.a.state === 'allergies' ? al.a.items.map((x, i) => { const m = x.match(/^(.*?)\s*\((.*)\)\s*$/); return <span key={i} className="al">{m ? m[1] : x}{m && <span className="rx"> — {m[2]}</span>}</span>; }) : <span className={al.a.state === 'not-reported' ? 'v7-amber' : ''}>{al.a.state === 'nkda' ? 'NKDA' : 'Not reported'}</span>}</div>
        {al.verified ? <span className="v7-verified" data-testid="allergy-verified" title={`Verified by ${al.by} · ${al.at ? fmtDate(al.at) : ''}`}>✓ Verified</span> : <button type="button" className="v7-verify" onClick={() => openPanel(R('allergies', 'Allergies', p.id))} data-testid="allergy-needs">✓ Verify</button>}
      </div>
      <Col label={`MEDICATIONS (${meds.length})`} r={R('meds', 'Medications', p.id)} tid="ph-meds">{items(meds.map(m => m.name))}</Col>
      <Col label="PAST MEDICAL HISTORY" r={R('problems', 'Problem list', p.id)} tid="ph-pmh">{items(pmh.map(x => x.description))}</Col>
      <Col label="PAST SURGICAL HISTORY" r={R('history', 'Surgical history', p.id)} tid="ph-psh">{items(data.history.map(h => h.text.replace(/\s*\((\d{4}|\d\d\/\d\d\/\d{4})\)$/, '')))}</Col>
      {modules().riskAwareness && <Col label="SIGNIFICANT RISK FACTORS" r={R('risk', 'Risk awareness', p.id)} tid="ph-risks">{items(data.risks.map(r => r.label), data.alsoFromProblems.length ? `Problem list: ${data.alsoFromProblems.join(', ')}` : 'None flagged')}</Col>}
    </div>
  </header>;
};

/** Everything design A doesn't show on the page itself: one quiet menu, same panels as v0.6. */
const MoreMenu: React.FC<{ p: MedPatient; onPay: () => void }> = ({ p, onPay }) => {
  const { openPanel, go } = useSv(); const [open, setOpen] = useState(false); const ref = useRef<HTMLDivElement>(null);
  useEffect(() => { if (!open) return; const f = (e: Event) => { if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false); }; const k = (e: KeyboardEvent) => { if (e.key === 'Escape') setOpen(false); }; document.addEventListener('pointerdown', f); window.addEventListener('keydown', k); return () => { document.removeEventListener('pointerdown', f); window.removeEventListener('keydown', k); }; }, [open]);
  const encounter = todayVisit(p.id) || medRepo.visits(p.id).filter(x => x.date < isoDay()).sort((x, y) => y.date.localeCompare(x.date))[0];
  const I = (label: string, f: () => void, tid?: string) => <button type="button" role="menuitem" onClick={() => { setOpen(false); f(); }} data-testid={tid}>{label}</button>;
  return <div className="v7-menu" ref={ref}>
    <button type="button" className="v7-btn" aria-haspopup="menu" aria-expanded={open} onClick={() => setOpen(o => !o)} data-testid="chart-more">More <ChevronDown size={14} /></button>
    {open && <div className="v7-menu-pop" role="menu" data-testid="chart-more-menu">
      <div className="g">People &amp; messages</div>
      {I('Portal messages', () => openPanel(R('messages', 'Portal messages', p.id)), 'more-messages')}
      {I(`Contact notes (${contactNotes(p.id).length})`, () => openPanel(R('contactnotes', 'Contact notes', p.id)), 'more-contactnotes')}
      {I('Care team', () => openPanel(R('careteam', 'Care team', p.id)), 'more-careteam')}
      {I('Caregiver access', () => openPanel(R('caregivers', 'Caregiver access', p.id)), 'more-caregivers')}
      {modules().networkAsc && <><div className="g">Surgery center</div>
        {I('ASC case & thread', () => openPanel(R('asc', 'ASC case & thread', p.id)), 'more-asc')}
        {I(`Sent to ASC · ${ascPackets(p.id).length} packet${ascPackets(p.id).length === 1 ? '' : 's'}`, () => openPanel(R('ascchart', 'Sent to ASC · ASC chart', p.id)), 'rec-ascchart')}</>}
      <div className="g">Record</div>
      {encounter && I(`Visit workflow · ${usDate(encounter.date)}`, () => go({ type: 'station', visitId: encounter.id }), 'more-workflow')}
      {I(`Price quotes (${quotesFor(p.id).length})`, () => openPanel(R('quote', 'Price quotes', p.id)), 'more-quotes')}
      {I('Medical journal (everything)', () => openPanel(R('journal', 'Journal', p.id)), 'more-journal')}
      {I('Remote monitoring', () => openPanel(R('monitoring', 'Remote monitoring', p.id)), 'more-monitoring')}
      {I('Audit trail', () => openPanel(R('audit', 'Audit trail', p.id)), 'more-audit')}
      <div className="g">Office</div>
      {I('Collect payment', onPay, 'more-collect')}
      {I('Billing', () => openPanel(R('billing', 'Billing', p.id)), 'more-billing')}
    </div>}
  </div>;
};

/* ---------------- Overview ---------------- */
const Card: React.FC<{ title?: React.ReactNode; tid?: string; className?: string; children: React.ReactNode }> = ({ title, tid, className, children }) => <section className={`v7-card v7-sec ${className || ''}`} data-testid={tid}>{title && <h3 className="v7-h3">{title}</h3>}{children}</section>;
const Side: React.FC<{ k: string; tid?: string; children: React.ReactNode }> = ({ k, tid, children }) => <section className="v7-card v7-side" data-testid={tid}><div className="k">{k}</div>{children}</section>;

const Overview: React.FC<{ p: MedPatient; data: ChartData; onPay: () => void; onProfile: () => void }> = ({ p, data, onPay, onProfile }) => {
  const { openPanel, go, toast } = useSv(); const [actor] = useActor(); const [signSum, setSignSum] = useState(false); const [rm, setRm] = useState('');
  const inits = summaryInitials(p.id); const lastInit = inits[inits.length - 1]; const changed = lastInit && lastInit.fingerprint !== data.fingerprint;
  const kept = keptNotes(p.id); const v = todayVisit(p.id); const now = new Date();
  const next = medRepo.visits(p.id).filter(x => x.step === 'scheduled' && visitStart(x) > now && x.id !== v?.id).sort((a, b) => visitStart(a).getTime() - visitStart(b).getTime())[0];
  const nc = nextAscCase(p.id); const coord = coordinatorFor(p.id); const acct = accountFor(p.id); const sp = p as SvPatient; const ec = emergencyParts(sp);
  const toneOf = (k?: string): Tone => k === 'labslip' || k === 'contactnotes' || k === 'allergies' ? 'red' : k === 'messages' ? 'blue' : 'amber';
  return <div className="v7-cols">
    <div className="v7-main">
      {data.attention.length > 0 && <Card title="Worth your attention" tid="summary-attention">
        <div className="v7-lines">{data.attention.map((x, i) => <button type="button" key={i} className="v7-line" onClick={() => x.cites[0] && openPanel(x.cites[0])}><span className={`v7-dot ${toneOf(x.cites[0]?.kind)}`} aria-hidden="true" /><span>{x.text}</span></button>)}</div>
        <div className="v7-foot">Nightingale flags; you decide. No score and no go/no-go.</div></Card>}
      <Card title="Diagnoses & procedures" tid="ov-dx"><DxCard p={p} /></Card>
      <Card title="Active problems" tid="ov-problems">
        <div className="v7-chips">{data.problems.length ? data.problems.map(x => <button key={x.id} type="button" className="v7-chip" onClick={() => openPanel(R('problems', 'Problem list', p.id))}>{x.description}</button>) : <span className="v7-muted text-[13px]">None recorded.</span>}</div></Card>
      {modules().riskAwareness && <Card title={<>Surgical risk factors <span className="v7-h3-sub">· {data.reviewed} of {data.riskTotal} reviewed by the surgeon</span></>} tid="summary-risks">
        <div className="v7-bullets">{data.risks.map((r, i) => <div key={i}><span className={`v7-dot ${r.reviewed ? 'gray' : 'amber'}`} aria-hidden="true" /><span>{r.label}{r.detail && <> — {r.detail}</>}{r.reviewed && <span className="v7-muted"> · reviewed</span>}</span></div>)}
          {!data.risks.length && <div className="v7-muted">None flagged in the recorded data (that is not a clearance).</div>}
          {data.alsoFromProblems.length > 0 && <div className="v7-muted text-[12.5px]">Also flagged from the problem list: {data.alsoFromProblems.join(', ')}</div>}</div>
        <button type="button" className="v7-quiet mt-3" onClick={() => openPanel(R('risk', 'Risk awareness', p.id))} data-testid="ov-risk-open">Review risk factors →</button></Card>}
      {kept.length > 0 && <Card title="Kept from Nightingale" tid="kept-notes">{kept.map(k => <div key={k.id} className="text-[13px] py-1.5 border-b border-[var(--v7-line2)] last:border-0"><span className="v7-muted">“{k.question}”</span> {k.text}<span className="v7-muted text-[12px]"> · kept by {k.keptBy} {fmtDate(k.keptAt)} </span><button type="button" className="v7-quiet" onClick={() => removeKeptNote(k.id)}>remove</button></div>)}</Card>}
      <Card tid="ov-initial" className="v7-initial">
        <HoldToInitial testId="summary-initial" label={lastInit && !changed ? <>Chart summary initialed by <b>{lastInit.by}</b> · {fmtDate(lastInit.at)} {hhmm(lastInit.at)}</> : <>{changed ? 'The summary changed since it was initialed. ' : ''}I reviewed this chart summary <span className="v7-muted">· your PIN · Nightingale cannot sign</span></>}
          done={lastInit && !changed ? `${initialsOf(lastInit.by)} · ${hhmm(lastInit.at)}` : undefined} onDone={() => setSignSum(true)} />
      </Card>
      {signSum && <PinSign title="Initial the chart summary" statement={<>I reviewed the chart summary for {p.name}.</>} roles={ROLE_GROUP.provider} confirmLabel="Initial" onClose={() => setSignSum(false)} onSigned={w => { initialSummary({ patientId: p.id, by: w.name, role: w.role, at: w.at, fingerprint: data.fingerprint }); setSignSum(false); toast(`Summary initialed by ${w.name}.`); }} />}
    </div>
    <aside className="v7-aside">
      {v && <Side k="TODAY’S VISIT" tid="chart-encounter"><div className="t">{v.visitType}</div><div className="s">{v.time.replace(/^0/, '')} · {prov(v.provider)} · {v.room}</div>
        <div className="flex items-center gap-2 mt-2 flex-wrap"><Pill s={visitStatus(v)} /><button type="button" className="v7-quiet" onClick={() => go({ type: 'station', visitId: v.id })} data-testid="chart-encounter-open">{v.step === 'scheduled' ? 'Visit workflow' : v.step === 'complete' ? 'Visit record' : `Continue · ${STATION_LABEL[v.step]}`} →</button></div></Side>}
      <Side k="NEXT APPOINTMENT" tid="chart-next-appt">{next ? <><div className="t">{next.visitType}</div><div className="s">{new Date(next.date + 'T12:00').toLocaleDateString('en-US', { month: 'short', day: 'numeric' })} · {next.time.replace(/^0/, '')} · {prov(next.provider)}</div>
        <div className="flex items-center gap-3 mt-2 flex-wrap"><Pill s={visitStatus(next)} testId="conf-badge" /><button type="button" className="v7-quiet" onClick={() => setRm(next.id)} data-testid="chart-reminders">Send reminder</button></div></> : <div className="s">None booked. <button type="button" className="v7-quiet" onClick={() => go({ type: 'tab', tab: 'schedule' })}>Schedule →</button></div>}</Side>
      <PastVisits p={p} />
      <Side k="ID & INSURANCE CARDS" tid="chart-cards"><CardsStatus p={p} /></Side>
      {nc && <Side k="SURGERY" tid="chart-surgery"><div className="t">{nc.procedure}</div><div className="s">{usDate(nc.date)} · {nc.time.replace(/^0/, '')} · {clean(nc.ascName)}</div><div className="s">{nc.status}</div><button type="button" className="v7-quiet mt-2" onClick={() => openPanel(R('asc', 'ASC case', p.id, nc.id))}>ASC case &amp; thread →</button></Side>}
      <Side k="CARE COORDINATOR" tid="chart-coordinator-row">
        <select className="v7-select" value={coord?.id || ''} onChange={e => { assignCoordinator(p.id, e.target.value, actor.name, actor.role); toast(e.target.value ? 'Surgical coordinator assigned.' : 'Coordinator removed (optional).'); }} aria-label="Surgical coordinator (optional)" data-testid="chart-coordinator"><option value="">None (optional)</option>{coordinators().map(c => <option key={c.id} value={c.id}>{c.name}</option>)}</select></Side>
      <Side k="ACCOUNT" tid="chart-account"><div className={`t ${acct.due > acct.credit ? 'v7-amber' : 'v7-green'}`} data-testid="account-badge">{acct.label === 'No balance' ? 'No balance due' : acct.label}</div>
        <div className="flex gap-4 mt-1.5"><button type="button" className="v7-quiet" onClick={onPay} data-testid="chart-collect">Collect payment</button><button type="button" className="v7-quiet" onClick={() => openPanel(R('billing', 'Billing', p.id))} data-testid="chart-billing">Billing</button></div></Side>
      <Side k="PRICE QUOTES" tid="chart-quotes">{(() => { const q = quotesFor(p.id)[0]; return q ? <><div className="t">{q.number}{q.versions.length > 1 ? ` v${q.versions.length}` : ''} · {money(q.versions[q.versions.length - 1].total)}</div><div className="s"><QuoteStatusPill q={q} /> <span className="ml-1">{quotesFor(p.id).length} on file · estimate, not payable</span></div></> : <div className="s">No quotes yet</div>; })()}
        <div className="flex gap-4 mt-1.5"><NewQuoteButton p={p} className="v7-quiet" label="New quote" testId="chart-quote-new" />{quotesFor(p.id).length > 0 && <button type="button" className="v7-quiet" onClick={() => openPanel(R('quote', 'Price quotes', p.id))} data-testid="chart-quotes-all">All quotes</button>}</div></Side>
      <Side k="CONTACT" tid="chart-profile-line">
        <div className="mono text-[13px]">{p.phone || <span className="v7-muted">no phone</span>}</div>{p.email && <div className="text-[13px]">{p.email}</div>}
        {ec.name && <div className="s">Emergency: {ec.name}{ec.relation ? ` (${ec.relation})` : ''}</div>}
        <div className="s" data-testid="chart-payment">Payment: {sp.paymentType || <span className="v7-amber">not recorded</span>}{sp.insuranceCarrier ? ` · ${sp.insuranceCarrier}` : ''}</div>
        <div className="s" data-testid="chart-referral">Referral: {sp.referralSource ? `${sp.referralSource}${sp.referredBy ? ` · ${sp.referredBy}` : ''}` : '—'}</div>
        <button type="button" className="v7-quiet mt-1.5" onClick={onProfile} data-testid="chart-edit-profile">Edit profile &amp; contact</button></Side>
      {(formsPackets(p.id).length > 0 || !medRepo.visits(p.id).length) && <section className="v7-card v7-side v7-packet"><PacketLine p={p} /></section>}
    </aside>
    {rm && <ReminderDialog visitId={rm} onClose={() => setRm('')} />}
  </div>;
};

/* ---------------- Clinical record ---------------- */
const Clinical: React.FC<{ p: MedPatient; data: ChartData }> = ({ p, data }) => {
  const { openPanel, go } = useSv(); const meds = medRepo.meds(p.id).filter(m => m.status === 'active'); const probs = medRepo.problems(p.id).filter(x => x.status === 'active');
  const slips = labSlips(p.id); const visits = medRepo.visits(p.id).slice().sort((a, b) => b.date.localeCompare(a.date)); const vit = medRepo.vitals(p.id); const lastV = vit[vit.length - 1];
  const Open: React.FC<{ r: Ref; children: React.ReactNode; tid?: string }> = ({ r, children, tid }) => <button type="button" className="v7-quiet" onClick={() => openPanel(r)} data-testid={tid}>{children}</button>;
  return <div className="v7-grid2" data-testid="chart-records">
    <Card title={<>Medications <span className="v7-h3-sub">({meds.length} active)</span></>} tid="cr-meds">
      <div className="v7-tbl">{meds.map(m => <div key={m.id} className="tr"><b>{m.name}</b><span>{m.dose} · {m.frequency}</span></div>)}{!meds.length && <div className="v7-muted">None recorded.</div>}</div>
      <Open r={R('meds', 'Medications', p.id)} tid="cr-meds-open">Manage medications →</Open></Card>
    <Card title="Allergies" tid="cr-allergies"><AllergyVerify p={p} /></Card>
    <Card title="Problem list" tid="cr-problems"><div className="v7-tbl rules">{probs.map(x => <div key={x.id} className="tr"><span>{x.description}</span><span className="v7-muted mono text-[12px]">{x.onset || ''}</span></div>)}{!probs.length && <div className="v7-muted">None recorded.</div>}</div>
      <Open r={R('problems', 'Problem list', p.id)}>Open problem list →</Open></Card>
    <Card title="Surgical history" tid="cr-history"><div className="v7-tbl">{data.history.map((h, i) => { const m = h.text.match(/^(.*?)\s*\((\d{4})\)$/); return <div key={i} className="tr"><span>{m ? m[1] : h.text}{h.detail && <span className="v7-muted"> · {h.detail}</span>}</span><span className="mono v7-muted text-[12px]">{m ? m[2] : ''}</span></div>; })}{!data.history.length && <div className="v7-muted">None recorded.</div>}</div>
      <Open r={R('history', 'Surgical history', p.id)}>Open history form →</Open></Card>
    <Card title="Results" tid="cr-results"><div className="v7-tbl">{slips.slice(0, 5).map(sl => <button key={sl.date} type="button" className="tr link" onClick={() => openPanel(slipRef(sl.date, p.id))} data-testid="rec-lab"><span>{sl.labs.map(l => l.test.replace('Hemoglobin A1c', 'A1c').replace('LDL cholesterol', 'LDL')).join(', ')}{sl.labs.some(l => l.status === 'awaiting-review') && <span className="v7-pill amber ml-2">To review</span>}</span><span className="mono v7-muted text-[12px]">{usDate(sl.date)}</span></button>)}{!slips.length && <div className="v7-muted">No results.</div>}</div>
      <div className="flex gap-4 flex-wrap"><Open r={R('labs', 'Results', p.id)}>All results →</Open><Open r={R('trends', 'Trends', p.id)}>Trends →</Open></div></Card>
    <Card title="Visits & notes" tid="cr-visits"><div className="v7-tbl">{visits.slice(0, 5).map(v => <button key={v.id} type="button" className="tr link" onClick={() => go({ type: 'station', visitId: v.id })} data-testid="rec-visit"><span>{v.visitType}<span className="v7-muted"> · {medRepo.note(v.id)?.status === 'signed' ? 'note signed' : v.date > isoDay() ? 'upcoming' : 'workflow'}</span></span><span className="mono v7-muted text-[12px]">{usDate(v.date)}</span></button>)}</div>
      <Open r={R('visits', 'Visits & notes', p.id)}>All visits &amp; notes →</Open></Card>
    <Card title="More in the clinical record" tid="cr-more" className="v7-span2"><div className="flex flex-wrap gap-x-5 gap-y-2">
      <Open r={R('vitals', 'Vitals', p.id)} tid="rec-vitals">Vitals{lastV ? ` · ${vitalsText(lastV).split(' · ').slice(0, 2).join(' · ')}` : ''}</Open>
      <Open r={R('intake', 'Intake answers', p.id)}>Intake answers</Open>
      {modules().riskAwareness && <Open r={R('risk', 'Risk awareness', p.id)}>Risk awareness</Open>}
      <Open r={R('careplan', 'Care plan', p.id)}>Care plan</Open>
      <Open r={R('journal', 'Journal', p.id)}>Medical journal</Open></div></Card>
  </div>;
};

/* ---------------- Photos & charts ---------------- */
const Photos: React.FC<{ p: MedPatient }> = ({ p }) => <div className="flex flex-col gap-4" data-testid="chart-media">
  <Card title={<>Clinical photos <span className="v7-h3-sub">· before / after · select up to four to compare full screen</span></>} tid="rec-photos"><PhotoGate p={p} where="chart"><PhotoGallery p={p} /></PhotoGate></Card>
  <Card title="Body charts" tid="rec-media"><BodyChartsSection p={p} /></Card>
</div>;

/* ---------------- Activity ---------------- */
const TAG: Record<string, [string, Tone]> = { visit: ['VISIT', 'green'], lab: ['RESULT', 'gray'], message: ['MESSAGE', 'green'], contact: ['CALL', 'amber'], asc: ['ASC', 'blue'], surgery: ['SURGERY', 'blue'], vitals: ['VITALS', 'gray'], careplan: ['CARE PLAN', 'gray'], caregiver: ['CAREGIVER', 'gray'] };
function tagOf(e: Ev, upcoming: boolean): [string, Tone] {
  if (upcoming) return ['UPCOMING', 'blue'];
  if (e.ref.kind === 'doc') return ['DOCUMENT', 'gray'];
  if (e.icon === 'contact') return [/^phone/i.test(e.title) ? 'CALL' : 'NOTE', 'amber'];
  return TAG[e.icon] || ['RECORD', 'gray'];
}
const Activity: React.FC<{ p: MedPatient; onNotes: () => void }> = ({ p, onNotes }) => {
  const { openPanel, panel } = useSv(); const t = timeline(p);
  const rows: { e: Ev; up: boolean; today: boolean }[] = [...t.upcoming.map(e => ({ e, up: true, today: false })), ...t.today.map(e => ({ e, up: false, today: true })), ...t.past.map(e => ({ e, up: false, today: false }))];
  const same = (r: Ref) => panel && panel.kind === r.kind && (panel.id || '') === (r.id || '');
  return <div className="flex flex-col gap-3">
    <div className="flex flex-wrap gap-x-5 gap-y-1 items-center text-[13px]"><span className="v7-muted">{rows.length} events · newest first after upcoming</span>
      <span className="ml-auto flex gap-4 flex-wrap"><button type="button" className="v7-quiet" onClick={onNotes} data-testid="rec-notes">Notes</button><button type="button" className="v7-quiet" onClick={() => openPanel(R('contactnotes', 'Contact notes', p.id))} data-testid="rec-contactnotes">Contact notes ({contactNotes(p.id).length})</button><button type="button" className="v7-quiet" onClick={() => openPanel(R('messages', 'Portal messages', p.id))} data-testid="rec-messages">Portal messages{lastFrom(p.id) ? ' · new' : ''}</button><button type="button" className="v7-quiet" onClick={() => openPanel(R('journal', 'Journal', p.id))}>Full journal</button></span></div>
    <section className="v7-card v7-activity" aria-label="Activity" data-testid="chart-timeline">
      {rows.map(({ e, up, today }, i) => { const [tag, tone] = tagOf(e, up); return <button key={i} type="button" className="v7-act" onClick={() => openPanel(e.ref)} aria-current={same(e.ref) ? 'true' : undefined} data-testid="timeline-item" data-kind={e.icon}>
        <span className={`v7-dot ${tone}`} aria-hidden="true" />
        <span className="min-w-0 flex-1"><span className="flex items-center gap-2 flex-wrap"><b className="t">{e.title}</b><span className={`v7-tag ${tone}`}>{today ? 'TODAY' : tag}</span>{e.isNew && <span className="v7-new">NEW</span>}</span>
          <span className="m">{[e.sub, `${usDate(e.date)} · ${relDay(e.date)}`].filter(Boolean).join(' · ')}</span></span></button>; })}
      {!rows.length && <p className="v7-empty">Nothing recorded yet.</p>}
    </section>
  </div>;
};
