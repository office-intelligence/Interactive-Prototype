/*
 * Surgery.Vityls v0.7: Nightingale card for the redesigned Today and Patient Chart pages (Kevin's design A/B).
 * Same scripted, on-device answers as the v0.6 NightingaleBar (chartAnswer / globalAnswer), same audit, same
 * "never signs or orders" rule. The summary paragraph stays visible; an answer opens under the ask box.
 */
import React, { useEffect, useRef, useState } from 'react';
import { Mic, Search, X } from 'lucide-react';
import { repo } from '../../v6/dataLayer';
import { medRepo, patientKey, uid } from '../../med/record';
import { useActor } from '../../med/ui';
import { Act, Answer, chartAnswer, globalAnswer } from '../nightingale';
import { keepNote } from '../store';
import { Cites, useSv } from '../ui';

export interface Chip { label: string; act?: Act; run?: () => void; testId?: string }
const Spark = () => <svg aria-hidden="true" width="16" height="16" viewBox="0 0 24 24" fill="#4338CA"><path d="M12 2l1.8 5.6L19 9l-5.2 1.4L12 16l-1.8-5.6L5 9l5.2-1.4L12 2z" /><path d="M19 14l.8 2.4L22 17l-2.2.6L19 20l-.8-2.4L16 17l2.2-.6L19 14z" /></svg>;

export const NightingaleCard: React.FC<{ patientId?: string; reads: string; placeholder: string; summary: React.ReactNode; summaryTestId?: string; chips: Chip[] }> = ({ patientId, reads, placeholder, summary, summaryTestId, chips }) => {
  const { go, toast } = useSv(); const [actor] = useActor();
  const [q, setQ] = useState(''); const [log, setLog] = useState<Answer[]>([]); const [busy, setBusy] = useState(false); const [listening, setListening] = useState(false); const [more, setMore] = useState(false);
  const inp = useRef<HTMLInputElement>(null);
  useEffect(() => { setLog([]); }, [patientId]);
  useEffect(() => { const f = (e: KeyboardEvent) => { const t = e.target as HTMLElement; if (e.key === '/' && !/input|textarea|select/i.test(t.tagName) && !t.isContentEditable) { e.preventDefault(); inp.current?.focus(); } }; window.addEventListener('keydown', f); return () => window.removeEventListener('keydown', f); }, []);
  const ask = (text = q) => {
    if (!text.trim()) return; setBusy(true); setQ('');
    window.setTimeout(() => {
      const a = patientId ? chartAnswer(patientId, text) : globalAnswer(text);
      setLog(l => [...l, a].slice(-8)); setBusy(false);
      if (patientId) repo.audit({ caseId: patientKey(patientId), user: actor.name, role: actor.role, action: 'nightingale.answer', detail: `Q: ${text.slice(0, 80)}` });
      if (a.act) go(a.act);
    }, 260);
  };
  const micUp = () => { if (!listening) return; setListening(false); setQ(patientId ? 'What changed since her last visit?' : 'Who’s next?'); toast('Simulated voice: nothing was recorded. A sample question was typed for you.'); window.setTimeout(() => inp.current?.focus(), 30); };
  const last = log[log.length - 1];
  const keep = (a: Answer) => { if (!a.pid) return; keepNote({ id: uid('kn'), patientId: a.pid, question: a.q, text: a.text, cites: a.cites, keptBy: actor.name, keptAt: new Date().toISOString() }, actor.role); toast('Kept in the chart (marked as a Nightingale note you kept).'); };
  return <section className="v7-ng" aria-label="Nightingale AI" data-testid="nightingale-bar">
    <div className="v7-ng-head" data-testid="nightingale-header"><span className="t"><Spark />NIGHTINGALE AI</span><span className="m">{reads} · never signs or orders</span></div>
    <form className="v7-ng-ask" role="search" onSubmit={e => { e.preventDefault(); ask(); }}>
      <Search size={15} className="ic" aria-hidden="true" />
      <label htmlFor="v7-ask" className="sr-only">Ask Nightingale</label>
      <input id="v7-ask" ref={inp} value={q} onChange={e => setQ(e.target.value)} placeholder={placeholder} autoComplete="off" data-testid="nightingale-input" onKeyDown={e => { if (e.key === 'Escape') { setQ(''); (e.target as HTMLInputElement).blur(); } }} />
      {(busy || listening) && <span className="v7-ng-busy">{listening ? 'listening (simulated)…' : 'reading…'}</span>}
      <button type="button" className={`mic ${listening ? 'on' : ''}`} aria-label="Hold to speak (simulated)" title="Hold to speak (simulated; nothing is recorded)" onPointerDown={() => setListening(true)} onPointerUp={micUp} onPointerLeave={() => listening && micUp()} onKeyDown={e => { if (e.key === ' ' || e.key === 'Enter') { e.preventDefault(); setListening(true); window.setTimeout(micUp, 900); } }}><Mic size={14} /></button>
    </form>
    {last && <div className="v7-ng-ans" aria-live="polite" data-testid="nightingale-answer">
      <button type="button" onClick={() => setLog([])} aria-label="Close answer" className="x"><X size={14} /></button>
      <div className="q">You asked: {last.q}</div>
      <div>{last.text} <Cites list={last.cites} pid={last.pid} /></div>
      <div className="tools">{last.pid && patientId && <button type="button" onClick={() => keep(last)} data-testid="keep-answer">Keep in chart</button>}<button type="button" onClick={() => setLog([])}>Clear</button><span>On-device, from recorded data only. Nightingale never signs, orders or scores risk.</span></div>
    </div>}
    <p className={`v7-ng-sum ${more ? '' : 'clamp'}`} data-testid={summaryTestId || 'nightingale-brief'}>{summary}</p>
    {typeof summary === 'string' && summary.length > 330 && <button type="button" className="v7-ng-more" onClick={() => setMore(m => !m)} aria-expanded={more} data-testid="ng-sum-more">{more ? 'Show less' : 'Read the full summary'}</button>}
    {chips.length > 0 && <nav className="v7-ng-chips" aria-label="Likely next" data-testid="likely-next">{chips.map((c, i) => <button key={i} type="button" onClick={() => { if (c.run) c.run(); else if (c.act) go(c.act); }} data-testid={c.testId || 'ng-chip'}>{c.label} →</button>)}</nav>}
  </section>;
};
export const pname = (pid?: string) => pid ? medRepo.patient(pid)?.name || '' : '';
