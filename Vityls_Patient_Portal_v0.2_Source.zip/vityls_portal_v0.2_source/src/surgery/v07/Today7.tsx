/*
 * Surgery.Vityls v0.7 Today (Kevin's design B + his markup): greeting with day navigation, four counts, the
 * Nightingale card, the day's appointment list with a right-side Appointment panel (Arrived · Check-in · Open chart),
 * and "Worth your attention". All live v0.6 data; Arrived / Check-in keep the automatic timestamps and Check-in
 * starts the station workflow exactly as before.
 */
import { ApptNotesEditor } from '../v11/apptNotes';
import { Avatar } from '../v11/PatientPhoto';
import '../v11/v11.css';
import React, { useEffect, useMemo, useRef, useState } from 'react';
import { ChevronLeft, ChevronRight, X } from 'lucide-react';
import { medRepo, MedVisit, isoDay, addDays, usDate, ageFrom, toMin } from '../../med/record';
import { useActor, useMedTick } from '../../med/ui';
import { repo } from '../../v6/dataLayer';
import { ascBlocks, ascCases, checkoutOrders, modules } from '../store';
import { STATION_LABEL, R, awaitingLabs, lastFrom, nextAscCase, openRisks, relDay, slipRef, daysFrom, todayNextSteps, first, Act } from '../nightingale';
import { useSv } from '../ui';
import { arriveVisit, checkInVisit } from '../SurgeryStation';
import { AddNewPatientButton } from '../newPatient';
import { ReminderDialog, reminderStatus } from '../reminders';
import { flaggedNotes } from '../contactNotes';
import { svPatient } from '../profile';
import { Chip, NightingaleCard } from './NightingaleCard';

const hm = (t: string) => { const m = +toMin(t); return m >= 9999 ? t : `${String(Math.floor(m / 60)).padStart(2, '0')}:${String(m % 60).padStart(2, '0')}`; };
const plural = (n: number, w: string) => `${n} ${w}${n === 1 ? '' : 's'}`;
const words = ['No', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine', 'Ten'];
export const prov = (s: string) => /,\s*(MD|DO)\b/.test(s) ? `Dr. ${s.replace(/,.*$/, '')}` : s.replace(/,.*$/, '');
const cnt = (n: number) => (n < words.length ? words[n] : String(n));
export const isNewPatientVisit = (v: MedVisit) => /new/i.test(v.visitType);

export type Tone = 'amber' | 'red' | 'blue' | 'green' | 'gray';
export interface StatusPill { label: string; tone: Tone }
export function visitStatus(v: MedVisit): StatusPill {
  const f = repo.getFacts(v.id);
  if (v.step === 'complete') return { label: 'Done', tone: 'gray' };
  if (v.step !== 'scheduled') return { label: v.step === 'check-in' ? 'Checked in' : STATION_LABEL[v.step], tone: 'blue' };
  if (f['visit.arrived']?.value) return { label: 'Arrived', tone: 'blue' };
  const st = reminderStatus(v).state;
  return st === 'confirmed' ? { label: 'Confirmed', tone: 'green' } : st === 'waiting' ? { label: 'Not confirmed', tone: 'amber' } : st === 'call' ? { label: 'Call to confirm', tone: 'amber' } : st === 'reschedule' ? { label: 'Reschedule', tone: 'red' } : { label: 'Scheduled', tone: 'gray' };
}
export const Pill: React.FC<{ s: StatusPill; testId?: string }> = ({ s, testId }) => <span className={`v7-pill ${s.tone}`} data-testid={testId}>{s.label}</span>;
const unconfirmed = (v: MedVisit) => v.step === 'scheduled' && !repo.getFacts(v.id)['visit.arrived']?.value && ['waiting', 'call', 'reschedule'].includes(reminderStatus(v).state);

interface Att { key: string; title: string; sub: string; tone: Tone; act?: Act; select?: string }
function attention(dayVisits: MedVisit[], day: string): Att[] {
  const out: Att[] = []; const T = isoDay(); const now = new Date(); const mods = modules();
  dayVisits.filter(unconfirmed).forEach(v => { const p = medRepo.patient(v.patientId); const st = reminderStatus(v); const mins = Math.round((+toMin(v.time) - (now.getHours() * 60 + now.getMinutes())));
    const when = day === T ? (mins > 0 && mins <= 180 ? `Visit in ${mins} minutes` : mins > 0 ? `Visit at ${hm(v.time)}` : `Was due at ${hm(v.time)}`) : `Visit ${relDay(day)} at ${hm(v.time)}`;
    out.push({ key: 'u' + v.id, title: `${p?.name} — ${st.state === 'reschedule' ? 'asked to reschedule' : st.state === 'call' ? 'call to confirm' : 'not confirmed'}`, sub: `${when} · ${st.sends.length ? `${cnt(st.sends.length).toLowerCase()} reminder${st.sends.length === 1 ? '' : 's'} already sent` : 'no reminder sent yet'}`, tone: st.state === 'reschedule' ? 'red' : 'amber', select: v.id }); });
  medRepo.patients().forEach(p => flaggedNotes(p.id).forEach(n => out.push({ key: 'n' + n.id, title: `${p.name} — flagged ${n.channel.toLowerCase().replace(/ \(.*\)/, '')}`, sub: n.text.length > 90 ? n.text.slice(0, 90) + '…' : n.text, tone: 'red', act: { type: 'chart', pid: p.id, ref: R('contactnotes', 'Contact note', p.id, n.id) } })));
  const labs = awaitingLabs(); Array.from(new Set(labs.map(l => l.patientId))).forEach(pid => { const l = labs.filter(x => x.patientId === pid); out.push({ key: 'l' + pid, title: `${plural(l.length, 'lab result')} awaiting review`, sub: `${medRepo.patient(pid)?.name} — ${l.map(x => x.test.replace('Hemoglobin A1c', 'A1c').replace('LDL cholesterol', 'LDL')).join(', ')}`, tone: 'red', act: { type: 'chart', pid, ref: slipRef(l[l.length - 1].collectedAt, pid) } }); });
  medRepo.patients().forEach(p => { const m = lastFrom(p.id); if (m) out.push({ key: 'm' + p.id, title: `${p.name} — new portal message`, sub: `${m.author.replace(/\s*\(.*\)/, '')}: “${m.text.slice(0, 70)}${m.text.length > 70 ? '…' : ''}”`, tone: 'blue', act: { type: 'chart', pid: p.id, ref: R('messages', 'Portal messages', p.id) } }); });
  medRepo.visits().filter(v => { const n = medRepo.note(v.id); return n && n.status !== 'signed'; }).forEach(v => out.push({ key: 's' + v.id, title: `${medRepo.patient(v.patientId)?.name} — unsigned note`, sub: `${v.visitType} · ${usDate(v.date)} · needs the provider’s PIN`, tone: 'amber', act: { type: 'station', visitId: v.id } }));
  checkoutOrders().filter(o => o.status === 'to-do').forEach(o => out.push({ key: 'o' + o.id, title: `${medRepo.patient(o.patientId)?.name} — checkout to-do`, sub: o.text, tone: 'amber', act: { type: 'station', visitId: o.visitId } }));
  if (mods.riskAwareness && mods.networkAsc) medRepo.patients().forEach(p => { const nc = nextAscCase(p.id); const r = openRisks(p); if (nc && daysFrom(nc.date) <= 21 && r.length) out.push({ key: 'r' + p.id, title: `${p.name} — ${plural(r.length, 'risk factor')} to review`, sub: `Surgery ${relDay(nc.date)} · ${nc.procedure} · surgeon reviews`, tone: 'amber', act: { type: 'chart', pid: p.id, ref: R('risk', 'Risk awareness', p.id) } }); });
  return out;
}

/* v0.8: a sensible display name — "Dr. Patel" for physicians, the first name for a real person, otherwise the full name
   (test / desk accounts such as "Front Desk Tester" are never cut to "Front"); the role if no name. */
export function displayName(name: string, role?: string) {
  const n = (name || '').replace(/,.*$/, '').replace(/\s*\(.*\)/, '').trim(); if (!n) return role || 'there';
  const w = n.replace(/^Dr\.?\s+/, 'Dr. ').split(/\s+/);
  if (w[0] === 'Dr.') return `Dr. ${w[w.length - 1]}`;
  if (/\b(desk|tester|test|front|admin|staff|office|team|user|manager|nurse|assistant|coordinator|billing|reception)\b/i.test(n) || w.length === 1) return n;
  return w[0];
}
export const Today7: React.FC = () => {
  useMedTick(); const [actor] = useActor(); const { go, setTab, toast } = useSv();
  const T = isoDay(); const [day, setDay] = useState(() => sessionStorage.getItem('sv-today-day') || T);
  const pickDay = (d: string) => { if (!d) return; setDay(d); sessionStorage.setItem('sv-today-day', d); };
  const visits = medRepo.visits().filter(v => v.date === day).sort((a, b) => toMin(a.time).localeCompare(toMin(b.time)));
  const [sel, setSel] = useState<string>(''); const [closed, setClosed] = useState(false); const [showAll, setShowAll] = useState(false);
  const panelRef = useRef<HTMLDivElement>(null);
  const selected = visits.find(v => v.id === sel) || (closed ? undefined : visits.find(v => v.step !== 'complete') || visits[0]);
  useEffect(() => { setSel(''); setClosed(false); }, [day]);
  const pick = (id: string, scroll = true) => { setSel(id); setClosed(false); if (scroll && window.innerWidth < 900) window.setTimeout(() => panelRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' }), 60); };
  const att = attention(visits, day);
  const kpi = { visits: visits.length, unconf: visits.filter(unconfirmed).length, att: att.length, newPts: visits.filter(isNewPatientVisit).length };
  const h = new Date().getHours(); const hello = h < 12 ? 'Good morning' : h < 17 ? 'Good afternoon' : 'Good evening';
  const greetName = displayName(actor.name, actor.role);
  const dateLabel = new Date(day + 'T12:00').toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' });
  // Nightingale brief + chips, from the same data
  const brief = useMemo(() => {
    const isT = day === T; const parts: string[] = [];
    parts.push(visits.length ? `${cnt(visits.length)} visit${visits.length === 1 ? '' : 's'} ${isT ? 'today' : `on ${new Date(day + 'T12:00').toLocaleDateString('en-US', { weekday: 'long' })}`}${kpi.newPts ? `, including ${kpi.newPts === 1 ? 'one' : cnt(kpi.newPts).toLowerCase()} new patient consult${kpi.newPts === 1 ? '' : 's'}` : ''}.` : `No visits ${isT ? 'today' : 'on this day'}.`);
    const u = visits.filter(unconfirmed); if (u.length) { const v = u[0]; const st = reminderStatus(v); parts.push(`${medRepo.patient(v.patientId)?.name}’s ${hm(v.time)} ${v.visitType.toLowerCase()} still isn’t confirmed${st.sends.length ? ` — ${cnt(st.sends.length).toLowerCase()} reminder${st.sends.length === 1 ? ' has' : 's have'} gone out` : ''}.${u.length > 1 ? ` ${u.length - 1} more unconfirmed.` : ''}`); }
    const inOffice = visits.filter(v => v.step !== 'scheduled' && v.step !== 'complete'); if (isT && inOffice.length) parts.push(`${plural(inOffice.length, 'patient')} in the office now.`);
    const fl = medRepo.patients().flatMap(p => flaggedNotes(p.id).map(n => ({ p, n }))); if (fl.length) { const { p, n } = fl[0]; const nc = nextAscCase(p.id); parts.push(`${p.name} has a flagged ${n.channel.toLowerCase().replace(/ \(.*\)/, '')} (${n.reason.toLowerCase()})${nc ? ` ahead of ${p.sex === 'Male' ? 'his' : p.sex === 'Female' ? 'her' : 'the'} ${nc.procedure.toLowerCase()} ${relDay(nc.date)}` : ''}.`); }
    const labs = awaitingLabs(); if (labs.length) { const pts = Array.from(new Set(labs.map(l => l.patientId))); parts.push(`${plural(labs.length, 'lab result')} ${labs.length === 1 ? 'is' : 'are'} waiting on review${pts.length === 1 ? ` (${medRepo.patient(pts[0])?.name})` : ` across ${pts.length} patients`}.`); }
    const msgs = medRepo.patients().filter(p => lastFrom(p.id)).length; if (msgs) parts.push(`${plural(msgs, 'portal message')} waiting.`);
    return parts.join(' ');
  }, [visits, day, T, kpi.newPts]);
  const chips: Chip[] = [];
  const u0 = visits.find(unconfirmed); if (u0) chips.push({ label: `Confirm ${first(medRepo.patient(u0.patientId)?.name || '')}’s visit`, run: () => pick(u0.id), testId: 'ng-chip-confirm' });
  const l0 = awaitingLabs()[0]; if (l0) chips.push({ label: `Review ${first(medRepo.patient(l0.patientId)?.name || '')}’s labs`, act: { type: 'chart', pid: l0.patientId, ref: slipRef(awaitingLabs(l0.patientId).slice(-1)[0].collectedAt, l0.patientId) }, testId: 'ng-chip-labs' });
  const fl0 = medRepo.patients().map(p => ({ p, n: flaggedNotes(p.id)[0] })).find(x => x.n); if (fl0) chips.push({ label: `Reply to ${first(fl0.p.name)}’s ${fl0.n!.channel === 'Phone call' ? 'call' : 'note'}`, act: { type: 'chart', pid: fl0.p.id, ref: R('contactnotes', 'Contact note', fl0.p.id, fl0.n!.id) }, testId: 'ng-chip-flag' });
  todayNextSteps().forEach(s => { if (chips.length < 4 && !(l0 && /result/i.test(s.label))) chips.push({ label: s.label, act: s.act }); });
  // ASC next 7 days (moved from the v0.6 right column into a quiet disclosure)
  const mods = modules();
  const asc = [...(mods.blockTime ? ascBlocks().filter(b => b.date >= T && b.date <= addDays(T, 7)).map(b => ({ k: b.date + toMin(b.start), date: b.date, text: `Block · ${b.surgeon.replace(/,.*$/, '')} · ${b.start.replace(/^0/, '')}–${b.end.replace(/^0/, '')} · ${b.room}`, pid: '' })) : []),
    ...(mods.networkAsc ? ascCases().filter(c => c.date >= T && c.date <= addDays(T, 7)).map(c => ({ k: c.date + toMin(c.time), date: c.date, text: `${c.time.replace(/^0/, '')} · ${c.patientName} · ${c.procedure}`, pid: medRepo.patients().find(p => p.name === c.patientName && p.dob === c.dob)?.id || '' })) : [])].sort((a, b) => a.k.localeCompare(b.k));
  const shown = showAll ? att : att.slice(0, 3);
  return <div className="v7-page" data-testid="sv-dashboard">
    <div className="v7-today-head">
      <div className="min-w-0">
        <h1 className="v7-h1" data-testid="today-greeting">{hello}, {greetName}</h1>
        <div className="v7-daynav" data-testid="today-datenav">
          <span className="v7-date" data-testid="today-title">{dateLabel}</span>
          <button type="button" className="v7-icon-btn" onClick={() => pickDay(addDays(day, -1))} aria-label="Previous day" data-testid="today-prev"><ChevronLeft size={16} /></button>
          <button type="button" className="v7-icon-btn" onClick={() => pickDay(addDays(day, 1))} aria-label="Next day" data-testid="today-next"><ChevronRight size={16} /></button>
          <button type="button" className="v7-btn sm" onClick={() => pickDay(T)} aria-pressed={day === T} disabled={day === T} data-testid="today-today">Today</button>
          <input type="date" className="v7-input date" value={day} onChange={e => pickDay(e.target.value)} aria-label="Jump to a date" data-testid="today-date" />
        </div>
      </div>
      <div className="flex gap-2.5 flex-wrap"><AddNewPatientButton label="Add patient" btnClass="v7-btn" /></div>
    </div>
    <div className="v7-kpis" data-testid="today-kpis">
      <div className="v7-kpi" data-testid="kpi-visits"><div className="k">{day === T ? 'VISITS TODAY' : 'VISITS'}</div><div className="n">{kpi.visits}</div></div>
      <div className="v7-kpi" data-testid="kpi-unconfirmed"><div className="k">NOT CONFIRMED</div><div className={`n ${kpi.unconf ? 'amber' : ''}`}>{kpi.unconf}</div></div>
      <div className="v7-kpi" data-testid="kpi-attention"><div className="k">NEEDS ATTENTION</div><div className={`n ${kpi.att ? 'red' : ''}`}>{kpi.att}</div></div>
      <div className="v7-kpi" data-testid="kpi-new"><div className="k">NEW PATIENTS</div><div className="n">{kpi.newPts}</div></div>
    </div>
    <NightingaleCard reads={day === T ? 'Reads today’s schedule and messages' : `Reads the schedule for ${usDate(day)} and messages`} placeholder="Ask Nightingale — “who’s unconfirmed”, “what needs my attention”" summary={brief} chips={chips.slice(0, 4)} />
    <div className="v7-split">
      <section className="v7-card v7-list" aria-label="Appointments" data-testid="dash-patients">
        {visits.length === 0 ? <p className="v7-empty">No patients scheduled {day === T ? 'today' : 'on this day'}. <button type="button" className="sv-link" onClick={() => setTab('schedule')}>Open the schedule</button></p> :
          visits.map(v => { const p = medRepo.patient(v.patientId); if (!p) return null; const on = selected?.id === v.id;
            return <button key={v.id} type="button" className={`v7-row ${on ? 'on' : ''} ${v.step === 'complete' ? 'done' : ''}`} aria-pressed={on} onClick={() => pick(v.id)} data-testid="dash-card" aria-label={`${p.name}, ${v.time}`}>
              <span className="tm">{hm(v.time)}</span>
              <span className="min-w-0 flex-1"><span className="nm">{p.name}</span><span className="sub">{v.visitType} · {prov(v.provider)} · {v.room}</span></span>
              <Pill s={visitStatus(v)} testId="dash-card-step" />
            </button>; })}
      </section>
      {selected && <div ref={panelRef} className="v7-card v7-appt" data-testid="today-appt"><ApptPanel v={selected} isToday={day === T} onClose={() => { setClosed(true); setSel(''); }} /></div>}
    </div>
    <section aria-label="Worth your attention" data-testid="dash-attention">
      <div className="flex items-baseline gap-3 mb-3"><h2 className="v7-h2 m-0">Worth your attention</h2>{att.length > 3 && <button type="button" className="v7-quiet" onClick={() => setShowAll(s => !s)} data-testid="att-all">{showAll ? 'Show fewer' : `Show all ${att.length}`}</button>}</div>
      {att.length === 0 ? <p className="v7-muted text-[13px]">Nothing waiting.</p> : <div className="v7-att">{shown.map(a => <button key={a.key} type="button" className="v7-att-card" onClick={() => a.select ? pick(a.select) : a.act && go(a.act)} data-testid="att-card"><span className={`v7-dot ${a.tone}`} aria-hidden="true" /><span className="min-w-0"><span className="t">{a.title}</span><span className="s">{a.sub}</span></span></button>)}</div>}
    </section>
    {(mods.networkAsc || mods.blockTime) && <details className="v7-more" data-testid="dash-asc"><summary>At the ASC · next 7 days ({asc.length})</summary>
      {asc.length === 0 ? <p className="v7-muted text-[13px] mt-2">Nothing booked.</p> : <ul className="mt-2">{asc.map((x, i) => <li key={i}><span className="d">{x.date === T ? 'Today' : usDate(x.date).slice(0, 5)}</span>{x.pid ? <button type="button" className="sv-link" onClick={() => go({ type: 'chart', pid: x.pid, ref: R('asc', 'Network ASC', x.pid) })}>{x.text}</button> : <span className="v7-muted">{x.text}</span>}</li>)}</ul>}
    </details>}
  </div>;
};

const ApptPanel: React.FC<{ v: MedVisit; isToday: boolean; onClose: () => void }> = ({ v, isToday, onClose }) => {
  const { go, toast } = useSv(); const [actor] = useActor(); const [rm, setRm] = useState(false);
  const p = svPatient(v.patientId); if (!p) return null;
  const facts = repo.getFacts(v.id); const arrived = facts['visit.arrived']?.value as string | undefined; const checked = facts['visit.checkedIn']?.value as string | undefined;
  const st = reminderStatus(v); const s = visitStatus(v);
  const note = arrived || checked ? [arrived && `Arrived at ${arrived}`, checked && `checked in at ${checked}`].filter(Boolean).join(' · ') : st.state === 'confirmed' ? `${st.conf?.via === 'staff-call' ? 'Confirmed by phone' : 'Confirmed'}${st.sends.length ? ` · ${plural(st.sends.length, 'reminder')} sent` : ''}` : st.state === 'none' ? '' : st.sends.length ? `${cnt(st.sends.length)} reminder${st.sends.length === 1 ? '' : 's'} sent` : 'No reminder sent yet';
  const ckLabel = v.step === 'scheduled' ? 'Check-in' : v.step === 'complete' ? 'Visit record' : `Continue · ${STATION_LABEL[v.step]}`;
  const ckDisabled = v.step === 'scheduled' && !isToday;
  const Row: React.FC<{ k: string; children: React.ReactNode }> = ({ k, children }) => <div className="r"><span className="k">{k}</span><span className="v">{children}</span></div>;
  return <div className="flex flex-col gap-4" data-testid="appt-panel">
    <div className="flex items-center justify-between"><h2 className="v7-h2 m-0">Appointment</h2><button type="button" className="v7-x" onClick={onClose} aria-label="Close appointment" data-testid="today-appt-close"><X size={16} /></button></div>
    <div className="flex gap-3 items-start"><Avatar p={p} size={44} /><div><button type="button" className="v7-appt-name" onClick={() => go({ type: 'chart', pid: p.id })} data-testid="today-appt-name">{p.name}</button>
      <div className="v7-meta">{ageFrom(p.dob)} years · {p.sex} · DOB {p.dob}{p.paymentType ? ` · ${p.paymentType}` : ''}</div>
      {p.phone && <div className="v7-meta mono">{p.phone}</div>}</div></div>
    <div className="flex items-center gap-2 flex-wrap"><Pill s={s} testId="today-appt-status" />{note && <span className="v7-meta" data-testid="today-appt-note">{note}</span>}
      {st.state !== 'none' && v.step === 'scheduled' && <button type="button" className="v7-quiet ml-auto" onClick={() => setRm(true)} data-testid="conf-open">Reminders</button>}</div>
    <div className="v7-kv">
      <Row k="Visit type">{v.visitType}</Row><Row k="Time">{hm(v.time)}{isToday ? '' : ` · ${usDate(v.date)}`}</Row><Row k="Provider">{prov(v.provider)}</Row><Row k="Room">{v.room}</Row>
      <div className="r"><span className="k flex-none">Reason</span><span className="v text-right">{v.reason || '—'}</span></div>
    </div>
    <ApptNotesEditor v={v} testId="today-appt-notes" compact onSaved={() => toast('Appointment notes saved.')} />
    <div className="v7-appt-acts">
      <div className="grid grid-cols-2 gap-2">
        <button type="button" className="v7-btn" disabled={!!arrived || v.step !== 'scheduled' || !isToday} title={!isToday ? 'Arrival is recorded on the day of the visit' : undefined} onClick={() => { arriveVisit(v, actor.name, actor.role); toast(`${p.name} arrived · time recorded.`); }} data-testid="dash-arrive">{arrived ? `Arrived ${arrived}` : 'Arrived'}</button>
        <button type="button" className={`v7-btn ${v.step === 'scheduled' ? 'primary' : ''}`} disabled={ckDisabled} title={ckDisabled ? 'Check-in opens on the day of the visit' : undefined} onClick={() => { if (v.step === 'scheduled') { checkInVisit(v, actor.name, actor.role); toast(`${p.name} checked in · time recorded.`); } go({ type: 'station', visitId: v.id }); }} data-testid="dash-checkin">{ckLabel}</button>
      </div>
      <button type="button" className={`v7-btn w-full ${v.step === 'scheduled' ? '' : 'primary'}`} onClick={() => go({ type: 'chart', pid: p.id })} data-testid="dash-open">Open chart</button>
    </div>
    {rm && <ReminderDialog visitId={v.id} onClose={() => setRm(false)} />}
  </div>;
};
