/* v0.8: one-paragraph Nightingale brief for every page that isn't Today or the chart (same data as v0.6/v0.7). */
import { medRepo, isoDay, toMin } from '../../med/record';
import { awaitingLabs, lastFrom, STATION_LABEL, first } from '../nightingale';
import { ascCases } from '../store';
const pl = (n: number, w: string) => `${n} ${w}${n === 1 ? '' : 's'}`;
export function pageBrief(tab: string, pid?: string): { reads: string; placeholder: string; summary: string } {
  const T = isoDay(); const today = medRepo.visits().filter(v => v.date === T);
  const by = (f: (s: string) => boolean) => today.filter(v => f(v.step)).length;
  if (pid && tab === 'station') {
    const p = medRepo.patient(pid); const v = today.find(x => x.patientId === pid) || medRepo.visits(pid).slice(-1)[0];
    return { reads: 'Reads this visit and chart', placeholder: `Ask about ${first(p?.name || '')} — “allergies”, “blood thinners”, “what changed”`, summary: `${p?.name} · ${v ? `${v.visitType} with ${v.provider.replace(/,.*$/, '')} · now at ${STATION_LABEL[v.step]}` : 'visit workflow'}. Every station is open to anyone on the tablet; signing asks for the signer’s own PIN. Nightingale drafts and flags — it never signs, orders or decides go / no-go.` };
  }
  const msgs = medRepo.patients().filter(p => lastFrom(p.id)).length; const labs = awaitingLabs().length;
  const base = `${pl(today.length, 'visit')} today: ${by(s => s === 'scheduled')} not arrived, ${by(s => s !== 'scheduled' && s !== 'complete')} in the office, ${by(s => s === 'complete')} done.`;
  if (tab === 'schedule') { const nx = ascCases().filter(c => c.date >= T).sort((a, b) => (a.date + toMin(a.time)).localeCompare(b.date + toMin(b.time)))[0];
    return { reads: 'Reads the schedule', placeholder: 'Ask Nightingale — “who’s next”, “upcoming surgeries”, “open Marisol”', summary: `${base}${nx ? ` Next ASC case: ${nx.patientName}, ${nx.procedure.toLowerCase()} on ${nx.date.slice(5).replace('-', '/')}.` : ''} Click an open slot to book; click a visit for its details.` }; }
  if (tab === 'messages') return { reads: 'Reads portal messages', placeholder: 'Ask Nightingale — “messages”, “open Ellen”', summary: msgs ? `${pl(msgs, 'portal conversation')} waiting for a reply. Replies are simulated and recorded.` : 'No portal messages are waiting.' };
  if (tab === 'patients') return { reads: 'Reads the patient list', placeholder: 'Ask Nightingale — “open Ellen”, “results to review”', summary: `${pl(medRepo.patients().length, 'fictional chart')}. ${labs ? `${pl(labs, 'result')} await review. ` : ''}Search by name or ask me to open a chart.` };
  return { reads: 'Reads practice settings', placeholder: 'Ask Nightingale — “fee schedule”, “quote terms”, “staff PINs”, “visit types”', summary: 'Practice settings are commands: ask for a setting and I’ll open it. Opening Practice needs a Practice Manager, Practice Administrator or provider PIN.' };
}
