/*
 * Surgery.Vityls v0.5 · appointment reminders and confirmation (SIMULATED: nothing is texted or emailed).
 *  - Every booked office visit gets confirmation requests at a regular interval (practice setting, default every 48 h,
 *    up to 4 requests) until the patient confirms, plus one reminder the day before the appointment (default 10:00 AM),
 *    confirmed or not. No automatic messages in quiet hours (8 PM – 8 AM); a send due then waits for 8 AM.
 *  - Channel follows the patient's preferred contact (profile): text, email, both, or "phone call only" (no automatic
 *    messages; the visit shows "Call to confirm").
 *  - The patient confirms by replying C (simulated button), in the portal (Appointments › Confirm), or the front desk
 *    marks it confirmed after a call. R = asks to reschedule (stops requests, shows on the schedule).
 *  - In this browser build the scheduler runs while the app is open (on load and every minute) and catches up on
 *    anything that came due while it was closed. In production this is a server job (Henry, see the changelog).
 *  - Every send is kept in the outbox (`reminder-sends`) with the exact message, and audited (`reminder.send`).
 */
import React, { useState } from 'react';
import { BellRing, Check, X } from 'lucide-react';
import { repo } from '../v6/dataLayer';
import { medRepo, MedVisit, isoDay, addDays, usDate, toMin, uid, patientKey, fmtDateTime } from '../med/record';
import { getSettings } from '../med/settings';
import { useActor, useMedTick } from '../med/ui';
import { svRead, svWrite, seedHooks } from './store';
import { preferredOf, svPatient, SvPatient, PREFERRED_LABEL } from './profile';
import { useSv } from './ui';

/* ---------------- settings ---------------- */
export interface ReminderSettings { enabled: boolean; intervalHours: number; maxRequests: number; dayBefore: boolean; dayBeforeTime: string; quietStart: number; quietEnd: number }
export const DEFAULT_REMINDERS: ReminderSettings = { enabled: true, intervalHours: 48, maxRequests: 4, dayBefore: true, dayBeforeTime: '10:00', quietStart: 20, quietEnd: 8 };
export const reminderSettings = (): ReminderSettings => ({ ...DEFAULT_REMINDERS, ...svRead<Partial<ReminderSettings>>('reminder-settings', {}) });
export function saveReminderSettings(s: ReminderSettings, by: string, role: string) {
  svWrite('reminder-settings', s);
  repo.audit({ caseId: 'practice', user: by, role, action: 'reminder.settings', detail: `Appointment reminders ${s.enabled ? 'on' : 'off'} · confirmation request every ${s.intervalHours} h, up to ${s.maxRequests}, until confirmed · day-before reminder ${s.dayBefore ? `at ${hm(s.dayBeforeTime)}` : 'off'} · quiet hours ${s.quietStart}:00–${s.quietEnd}:00` });
}
const hm = (t: string) => { const [h, m] = t.split(':').map(Number); return `${((h + 11) % 12) + 1}:${String(m).padStart(2, '0')} ${h < 12 ? 'AM' : 'PM'}`; };

/* ---------------- records ---------------- */
export type ConfirmState = 'confirmed' | 'reschedule';
export interface ApptConfirm { visitId: string; status: ConfirmState; at: string; by: string; via: 'patient-reply' | 'portal' | 'staff-call' | 'staff' }
export type ReminderKind = 'confirm-request' | 'day-before' | 'manual';
export interface ReminderSend { id: string; visitId: string; patientId: string; kind: ReminderKind; channels: ('text' | 'email')[]; to: string; message: string; at: string; attempt: number; by: string; transport: 'simulated-outbox' }
export const confirmations = () => svRead<Record<string, ApptConfirm>>('appt-confirm', {});
export const confirmationOf = (visitId: string) => confirmations()[visitId];
export const reminderSends = (visitId?: string) => { const l = svRead<ReminderSend[]>('reminder-sends', []); return visitId ? l.filter(x => x.visitId === visitId) : l; };
const VIA: Record<ApptConfirm['via'], string> = { 'patient-reply': 'patient replied C (simulated)', portal: 'patient confirmed in the portal', 'staff-call': 'confirmed by phone', staff: 'marked by staff' };

/* ---------------- timing helpers ---------------- */
export const visitStart = (v: MedVisit) => { const m = +toMin(v.time); const d = new Date(`${v.date}T00:00:00`); d.setMinutes(m >= 9999 ? 9 * 60 : m); return d; };
const dayBeforeAt = (v: MedVisit, s: ReminderSettings) => new Date(`${addDays(v.date, -1)}T${s.dayBeforeTime}:00`);
/** Move a send out of quiet hours (no automatic texts 8 PM – 8 AM by default). */
const quiet = (d: Date, s: ReminderSettings) => { const x = new Date(d); const h = x.getHours(); if (h >= s.quietStart) { x.setDate(x.getDate() + 1); x.setHours(s.quietEnd, 0, 0, 0); } else if (h < s.quietEnd) x.setHours(s.quietEnd, 0, 0, 0); return x; };
const channelsFor = (p: SvPatient): ('text' | 'email')[] => { const pref = preferredOf(p); const c: ('text' | 'email')[] = pref === 'text' ? ['text'] : pref === 'email' ? ['email'] : pref === 'text+email' ? ['text', 'email'] : []; return c.filter(x => x === 'text' ? !!p.phone : !!p.email); };
const toLine = (p: SvPatient, ch: ('text' | 'email')[]) => ch.map(c => c === 'text' ? `text ${p.phone}` : `email ${p.email}`).join(' + ');
const longDate = (iso: string) => new Date(iso + 'T12:00').toLocaleDateString([], { weekday: 'long', month: 'long', day: 'numeric' });
const portalLink = (v: MedVisit) => `${location.href.split('#')[0].split('?')[0]}#confirm=${v.id}`;

function message(kind: ReminderKind, v: MedVisit, p: SvPatient, confirmed: boolean) {
  const first = (p.firstName || p.name.split(' ')[0]); const office = getSettings().practiceName.replace(/\s*\(fictional\)/, ''); const who = v.provider.replace(/,.*$/, '').replace(/^(\w)\w*\s/, 'Dr. ').replace(/^Dr\. Dr\./, 'Dr.');
  const when = `${longDate(v.date)} at ${v.time.replace(/^0/, '')}`;
  if (kind === 'day-before') return `Reminder from ${office}: your ${v.visitType.toLowerCase()} with ${who} is tomorrow, ${when}. ${confirmed ? 'You are confirmed. See you then.' : `Please reply C to confirm or R to reschedule, or confirm here: ${portalLink(v)}`} Questions? Call the office.`;
  return `Hi ${first}, this is ${office}. You have a ${v.visitType.toLowerCase()} with ${who} on ${when}. Reply C to confirm or R to reschedule, or confirm here: ${portalLink(v)}`;
}

/* ---------------- the scheduler (simulated) ---------------- */
const upcoming = (now: Date) => medRepo.visits().filter(v => v.step === 'scheduled' && visitStart(v) > now);
/** What is due for one visit at `now` (and when the next one would go). Pure: no writes. */
export function plan(v: MedVisit, now = new Date()) {
  const s = reminderSettings(); const p = svPatient(v.patientId); const out: { kind: ReminderKind; at: Date }[] = [];
  if (!p || !s.enabled) return { due: out, next: null as null | { kind: ReminderKind; at: Date }, channels: [] as ('text' | 'email')[] };
  const ch = channelsFor(p); const sends = reminderSends(v.id); const conf = confirmationOf(v.id); const start = visitStart(v);
  if (!ch.length || v.step !== 'scheduled' || start <= now) return { due: out, next: null, channels: ch };
  const since = new Date(svRead<string>('reminders-since', new Date().toISOString())); const created = new Date(v.createdAt || since.toISOString());
  const dbAt = dayBeforeAt(v, s); const dbApplies = s.dayBefore && created < new Date(`${v.date}T00:00:00`);
  let next: null | { kind: ReminderKind; at: Date } = null;
  if (!conf) {
    let reqs = sends.filter(x => x.kind === 'confirm-request').length; let last = sends.filter(x => x.kind === 'confirm-request').slice(-1)[0];
    let due = quiet(last ? new Date(+new Date(last.at) + s.intervalHours * 3600e3) : new Date(Math.max(+created, +since)), s);
    while (reqs < s.maxRequests && due < start && !(dbApplies && due >= dbAt)) {
      if (due > now) { next = { kind: 'confirm-request', at: due }; break; }
      out.push({ kind: 'confirm-request', at: due }); reqs++; due = quiet(new Date(+due + s.intervalHours * 3600e3), s);
    }
  }
  if (dbApplies && !sends.some(x => x.kind === 'day-before')) {
    const at = quiet(new Date(Math.max(+dbAt, +created, +since)), s);
    if (at < start) { if (at <= now) out.push({ kind: 'day-before', at }); else if (!next || at < next.at) next = { kind: 'day-before', at }; }
  }
  return { due: out, next, channels: ch };
}
/** Run once: record every send that has come due (catch-up included). Returns how many went to the outbox. */
export function runReminders(now = new Date()): number {
  if (!svRead<string | null>('reminders-since', null)) svWrite('reminders-since', now.toISOString());
  const list = reminderSends(); let n = 0;
  upcoming(now).forEach(v => { const p = svPatient(v.patientId); if (!p) return; const r = plan(v, now);
    r.due.forEach(d => { const attempt = d.kind === 'confirm-request' ? list.filter(x => x.visitId === v.id && x.kind === 'confirm-request').length + 1 : 1;
      const rec: ReminderSend = { id: uid('rm'), visitId: v.id, patientId: p.id, kind: d.kind, channels: r.channels, to: toLine(p, r.channels), message: message(d.kind, v, p, !!confirmationOf(v.id)), at: d.at.toISOString(), attempt, by: 'Scheduler (automatic)', transport: 'simulated-outbox' };
      list.push(rec); n++;
      repo.audit({ caseId: patientKey(p.id), user: 'Scheduler (automatic)', role: 'System', action: 'reminder.send', at: rec.at, detail: `${d.kind === 'day-before' ? 'Day-before reminder' : `Confirmation request #${attempt}`} for ${v.visitType} ${usDate(v.date)} ${v.time} · ${rec.to} · SIMULATED, nothing sent` }); }); });
  if (n) svWrite('reminder-sends', list);
  return n;
}
export function sendNow(v: MedVisit, by: string, role: string): ReminderSend {
  const p = svPatient(v.patientId); if (!p) throw new Error('Patient not found.');
  const ch = channelsFor(p); if (!ch.length) throw new Error(`No ${preferredOf(p) === 'phone' ? 'automatic channel: the patient prefers a phone call' : 'phone or email on file'}.`);
  const rec: ReminderSend = { id: uid('rm'), visitId: v.id, patientId: p.id, kind: 'manual', channels: ch, to: toLine(p, ch), message: message('manual', v, p, !!confirmationOf(v.id)), at: new Date().toISOString(), attempt: 1, by, transport: 'simulated-outbox' };
  svWrite('reminder-sends', [...reminderSends(), rec]);
  repo.audit({ caseId: patientKey(p.id), user: by, role, action: 'reminder.send', detail: `Reminder sent now (manual) for ${v.visitType} ${usDate(v.date)} ${v.time} · ${rec.to} · SIMULATED, nothing sent` });
  return rec;
}
export function setConfirmation(v: MedVisit, status: ConfirmState | null, via: ApptConfirm['via'], by: string, role: string) {
  const all = confirmations();
  if (status) all[v.id] = { visitId: v.id, status, at: new Date().toISOString(), by, via }; else delete all[v.id];
  svWrite('appt-confirm', all);
  repo.audit({ caseId: patientKey(v.patientId), user: by, role, action: status ? 'appointment.confirm' : 'appointment.unconfirm', detail: `${v.visitType} ${usDate(v.date)} ${v.time}: ${status === 'confirmed' ? `confirmed · ${VIA[via]}` : status === 'reschedule' ? `patient asked to reschedule · ${VIA[via]}` : 'confirmation cleared; reminders resume'}` });
}

/* ---------------- status ---------------- */
export type BadgeState = 'confirmed' | 'reschedule' | 'waiting' | 'call' | 'off' | 'none';
export function reminderStatus(v: MedVisit, now = new Date()) {
  const p = svPatient(v.patientId); const c = confirmationOf(v.id); const sends = reminderSends(v.id); const s = reminderSettings(); const r = plan(v, now);
  const state: BadgeState = c?.status === 'confirmed' ? 'confirmed' : c?.status === 'reschedule' ? 'reschedule' : v.step !== 'scheduled' || visitStart(v) <= now ? 'none' : !s.enabled ? 'off' : p && !channelsFor(p).length ? 'call' : 'waiting';
  const label = state === 'confirmed' ? 'Confirmed' : state === 'reschedule' ? 'Reschedule requested' : state === 'call' ? 'Call to confirm' : state === 'off' ? 'Reminders off' : state === 'none' ? '' : `Not confirmed · ${sends.length} sent`;
  return { state, label, conf: c, sends, next: r.next, channels: r.channels, p };
}
export const ConfBadge: React.FC<{ v: MedVisit; onClick?: () => void; compact?: boolean }> = ({ v, onClick, compact }) => {
  const st = reminderStatus(v); if (st.state === 'none') return null;
  const cls = st.state === 'confirmed' ? 'ok' : st.state === 'reschedule' ? 'no' : st.state === 'waiting' ? 'wait' : 'off';
  const txt = compact ? (st.state === 'confirmed' ? '✓ Confirmed' : st.state === 'reschedule' ? 'Reschedule' : st.state === 'waiting' ? `? ${st.sends.length} sent` : st.label) : st.label;
  const inner = <span className={`sv-conf ${cls}`} data-testid="conf-badge" data-state={st.state} title={st.label}>{txt}</span>;
  return onClick ? <button type="button" className="inline-flex" style={{ minHeight: 0, padding: 0, border: 0, background: 'none' }} onClick={e => { e.stopPropagation(); onClick(); }} aria-label={`Reminders: ${st.label}`}>{inner}</button> : inner;
};

/* ---------------- reminder dialog ---------------- */
export const ReminderDialog: React.FC<{ visitId: string; onClose: () => void }> = ({ visitId, onClose }) => {
  useMedTick(); const [actor] = useActor(); const { toast } = useSv(); const v = medRepo.visit(visitId); const [err, setErr] = useState('');
  if (!v) return null; const st = reminderStatus(v); const p = st.p; const s = reminderSettings();
  const act = (f: () => void) => { setErr(''); try { f(); } catch (e) { setErr((e as Error).message); } };
  return <div className="sv-modal" role="dialog" aria-modal="true" aria-label="Appointment reminders" data-testid="reminder-dialog" onKeyDown={e => { if (e.key === 'Escape') onClose(); }}>
    <div className="sv-modal-scrim" onClick={onClose} />
    <div className="sv-modal-box" style={{ width: 'min(640px, 96vw)', maxHeight: '90vh', overflow: 'auto' }}>
      <div className="flex items-center gap-2 mb-1"><BellRing size={16} /><b className="text-[15px]">Reminders · {p?.name}</b><button type="button" className="ml-auto sv-link" onClick={onClose} aria-label="Close"><X size={16} /></button></div>
      <p className="text-[13.5px]">{v.visitType} · {longDate(v.date)} {v.time.replace(/^0/, '')} · {v.provider} · {v.room}</p>
      <div className="flex flex-wrap items-center gap-2 mt-2 text-[13px]"><ConfBadge v={v} />
        {st.conf && <span className="sv-muted">{VIA[st.conf.via]} · {fmtDateTime(st.conf.at)} · {st.conf.by}</span>}
        {!st.conf && st.next && <span className="sv-muted" data-testid="reminder-next">Next: {st.next.kind === 'day-before' ? 'day-before reminder' : 'confirmation request'} {fmtDateTime(st.next.at.toISOString())}</span>}
        {!st.conf && !st.next && st.state === 'waiting' && <span className="sv-muted">No more automatic requests (limit {s.maxRequests}); the day-before reminder still goes out if due.</span>}
      </div>
      <p className="text-[12.5px] sv-muted mt-1">Channel: {p ? PREFERRED_LABEL[preferredOf(p)] : '—'}{st.channels.length ? ` · ${p && toLine(p, st.channels)}` : ''} · every {s.intervalHours} h until confirmed (up to {s.maxRequests}) + day before at {hm(s.dayBeforeTime)}</p>
      <div className="flex flex-wrap gap-2 mt-3">
        {st.conf?.status !== 'confirmed' && <button type="button" className="sv-btn sm primary" onClick={() => act(() => { setConfirmation(v, 'confirmed', 'staff-call', actor.name, actor.role); toast('Appointment confirmed (by phone). Requests stop; the day-before reminder still goes out.'); })} data-testid="rm-mark-confirmed"><Check size={14} />Mark confirmed (called)</button>}
        {!st.conf && <button type="button" className="sv-btn sm" onClick={() => act(() => { setConfirmation(v, 'confirmed', 'patient-reply', `${p?.name} (patient)`, 'Patient'); toast('Simulated patient reply “C”: confirmed.'); })} data-testid="rm-sim-reply">Simulate patient reply “C”</button>}
        {!st.conf && <button type="button" className="sv-btn sm" onClick={() => act(() => { setConfirmation(v, 'reschedule', 'patient-reply', `${p?.name} (patient)`, 'Patient'); toast('Simulated patient reply “R”: reschedule requested.'); })} data-testid="rm-sim-r">Simulate reply “R”</button>}
        {st.conf && <button type="button" className="sv-btn sm" onClick={() => act(() => { setConfirmation(v, null, 'staff', actor.name, actor.role); toast('Confirmation cleared. Reminders resume.'); })} data-testid="rm-clear">Clear confirmation</button>}
        <button type="button" className="sv-btn sm" onClick={() => act(() => { const r = sendNow(v, actor.name, actor.role); toast(`Reminder queued to ${r.to} (simulated, nothing sent).`); })} data-testid="rm-send-now">Send reminder now</button>
      </div>
      {err && <p className="text-[12.5px] text-[var(--crit)] mt-2" role="alert">{err}</p>}
      <div className="sv-h mt-4">Sent ({st.sends.length})</div>
      {st.sends.length === 0 ? <p className="sv-muted text-[13px]">Nothing sent yet.</p> : <ol className="text-[13px] space-y-2" data-testid="reminder-log">{[...st.sends].reverse().map(x => <li key={x.id} className="border-b border-[var(--line)] pb-1.5">
        <div><b>{x.kind === 'day-before' ? 'Day-before reminder' : x.kind === 'manual' ? 'Sent now (manual)' : `Confirmation request #${x.attempt}`}</b> · {fmtDateTime(x.at)} · {x.to} · {x.by.replace(/,.*$/, '')} <span className="sv-tag warn">simulated</span></div>
        <div className="sv-muted">{x.message}</div></li>)}</ol>}
      <p className="text-[11.5px] sv-muted mt-2">Simulation: nothing is texted or emailed. Messages are kept in the outbox and the audit trail.</p>
    </div>
  </div>;
};

/* ---------------- confirmations list (schedule page) ---------------- */
export const ConfirmationsList: React.FC<{ from: string; days?: number }> = ({ from, days = 14 }) => {
  useMedTick(); const [open, setOpen] = useState(''); const [only, setOnly] = useState(false); const { go } = useSv(); const now = new Date();
  const l = medRepo.visits().filter(v => v.date >= from && v.date <= addDays(from, days) && v.step === 'scheduled' && visitStart(v) > now).map(v => ({ v, st: reminderStatus(v, now) })).filter(x => !only || x.st.state !== 'confirmed');
  const c = { ok: l.filter(x => x.st.state === 'confirmed').length };
  return <section className="mt-4" data-testid="confirmations">
    <div className="flex flex-wrap items-baseline gap-3"><h2 className="sv-h">Appointment confirmations · next {days} days</h2><span className="sv-small sv-muted">{c.ok} of {l.length} confirmed · reminders simulated</span>
      <label className="ml-auto text-[13px] inline-flex items-center gap-1.5"><input type="checkbox" checked={only} onChange={e => setOnly(e.target.checked)} data-testid="conf-only-open" />Not confirmed only</label></div>
    {l.length === 0 ? <p className="sv-muted text-[13px]">No upcoming office visits.</p> : <table className="sv-table"><thead><tr><th>When</th><th>Patient</th><th>Visit</th><th>Status</th><th>Sent</th><th>Next</th><th /></tr></thead><tbody>
      {l.map(({ v, st }) => <tr key={v.id} data-testid="conf-row"><td className="whitespace-nowrap">{v.date === isoDay() ? 'Today' : usDate(v.date)} {v.time.replace(/^0/, '')}</td><td><button type="button" className="sv-link" onClick={() => go({ type: 'chart', pid: v.patientId })}>{st.p?.name}</button></td><td>{v.visitType}<div className="sv-muted sv-small">{v.provider.replace(/,.*$/, '')}</div></td><td><ConfBadge v={v} /></td><td>{st.sends.length}</td>
        <td className="sv-small">{st.conf ? '—' : st.next ? `${st.next.kind === 'day-before' ? 'Day before' : 'Request'} · ${fmtDateTime(st.next.at.toISOString())}` : st.state === 'call' ? 'Phone call' : '—'}</td>
        <td className="text-right"><button type="button" className="sv-btn sm" onClick={() => setOpen(v.id)} data-testid="conf-open">Reminders</button></td></tr>)}
    </tbody></table>}
    {open && <ReminderDialog visitId={open} onClose={() => setOpen('')} />}
  </section>;
};

/* ---------------- chart line: next appointment + confirmation ---------------- */
export const NextApptLine: React.FC<{ pid: string }> = ({ pid }) => {
  useMedTick(); const [open, setOpen] = useState(''); const now = new Date();
  const v = medRepo.visits(pid).find(x => x.step === 'scheduled' && visitStart(x) > now); if (!v) return null;
  return <div className="py-1.5 border-b border-[var(--line)] text-[13px] flex flex-wrap items-center gap-x-3 gap-y-1" data-testid="chart-next-appt">
    <b className="text-[11px] tracking-[.07em] uppercase">Next appointment</b><span>{v.date === isoDay() ? 'Today' : usDate(v.date)} {v.time.replace(/^0/, '')} · {v.visitType}</span>
    <ConfBadge v={v} onClick={() => setOpen(v.id)} />
    <button type="button" className="sv-link" onClick={() => setOpen(v.id)} data-testid="chart-reminders">Reminders</button>
    {open && <ReminderDialog visitId={open} onClose={() => setOpen('')} />}
  </div>;
};

/* ---------------- portal: confirm an upcoming appointment ---------------- */
export const PortalConfirm: React.FC<{ v: MedVisit }> = ({ v }) => {
  useMedTick(); const c = confirmationOf(v.id); const p = svPatient(v.patientId);
  if (v.step !== 'scheduled' || visitStart(v) <= new Date()) return null;
  if (c?.status === 'confirmed') return <span className="text-[13px] text-[#14532d] font-semibold ml-2" data-testid="portal-confirmed">✓ Confirmed</span>;
  return <button type="button" className="vy-btn vy-btn-secondary ml-2" onClick={() => setConfirmation(v, 'confirmed', 'portal', `${p?.name} (patient)`, 'Patient')} data-testid="portal-confirm">Confirm</button>;
};

/* ---------------- Practice settings section ---------------- */
export const ReminderSettingsSection: React.FC<{ can: boolean; actor: { name: string; role: string } }> = ({ can, actor }) => {
  useMedTick(); const { toast } = useSv(); const cur = reminderSettings(); const [s, setS] = useState(cur); const dirty = JSON.stringify(s) !== JSON.stringify(cur);
  return <section className="mt-6" data-testid="reminder-settings">
    <h2 className="sv-h">Appointment reminders</h2>
    <p className="text-[13px] sv-muted mb-2">Confirmation requests go out at a regular interval until the patient confirms, then one reminder the day before. Channel follows each patient’s preferred contact. Simulated in this build: nothing is sent.</p>
    <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3 text-[13.5px]">
      <label className="flex items-center gap-2"><input type="checkbox" checked={s.enabled} disabled={!can} onChange={e => setS({ ...s, enabled: e.target.checked })} data-testid="rs-enabled" />Send appointment reminders</label>
      <label><span className="sv-label">Confirmation request every</span><select className="sv-input" value={s.intervalHours} disabled={!can} onChange={e => setS({ ...s, intervalHours: +e.target.value })} data-testid="rs-interval">{[12, 24, 48, 72, 96].map(h => <option key={h} value={h}>{h % 24 === 0 ? `${h / 24} day${h === 24 ? '' : 's'} (${h} h)` : `${h} hours`}</option>)}</select></label>
      <label><span className="sv-label">Stop after (requests)</span><select className="sv-input" value={s.maxRequests} disabled={!can} onChange={e => setS({ ...s, maxRequests: +e.target.value })} data-testid="rs-max">{[1, 2, 3, 4, 5, 6, 8].map(n => <option key={n}>{n}</option>)}</select></label>
      <label className="flex items-center gap-2"><input type="checkbox" checked={s.dayBefore} disabled={!can} onChange={e => setS({ ...s, dayBefore: e.target.checked })} data-testid="rs-daybefore" />Reminder the day before</label>
      <label><span className="sv-label">Day-before send time</span><input type="time" className="sv-input" value={s.dayBeforeTime} disabled={!can || !s.dayBefore} onChange={e => e.target.value && setS({ ...s, dayBeforeTime: e.target.value })} data-testid="rs-time" /></label>
      <div><span className="sv-label">Quiet hours</span><div className="sv-muted">No automatic messages {hm(`${s.quietStart}:00`)} – {hm(`${s.quietEnd}:00`)}</div></div>
    </div>
    {can && <div className="flex flex-wrap gap-2 mt-2"><button type="button" className="sv-btn sm" onClick={() => setS(DEFAULT_REMINDERS)}>Restore defaults</button><button type="button" className="sv-btn sm primary" disabled={!dirty} onClick={() => { saveReminderSettings(s, actor.name, actor.role); runReminders(); toast('Reminder settings saved.'); }} data-testid="rs-save">Save reminders</button></div>}
  </section>;
};

/* ---------------- fictional seed: a few upcoming visits with reminder history ---------------- */
seedHooks.push(() => {
  const T = isoDay(); const now = Date.now(); const ago = (h: number) => new Date(now - h * 3600e3).toISOString();
  const PATEL = 'Sam Patel, MD', WHIT = 'Dana Whitfield, MD';
  svWrite('reminders-since', ago(24 * 10));
  const vis = (id: string, pid: string, d: number, time: string, provider: string, room: string, visitType: string, reason: string, createdH: number): MedVisit => ({ id, patientId: pid, date: addDays(T, d), time, durationMin: 15, provider, room, visitType, reason, step: 'scheduled', problemIds: [], createdAt: ago(createdH), createdBy: 'Front Desk Tester' });
  [vis('visit-m-fu', 'MED-1003', 1, '10:00 AM', WHIT, 'Exam 2', 'Follow-up visit', 'Review abdominoplasty quote and questions', 24 * 6),
   vis('visit-g-po', 'MED-1006', 2, '02:00 PM', PATEL, 'Exam 1', 'Post-op follow-up', 'Wound check after cheek lesion excision', 24 * 3),
   vis('visit-t-pre', 'MED-1007', 5, '11:00 AM', PATEL, 'Exam 2', 'Pre-surgical consult', 'Rhinoplasty plan and photos', 20)].forEach(v => medRepo.saveVisit(v));
  // backdate earlier visits' booking so the history reads naturally
  ['visit-e', 'visit-r', 'visit-p', 'visit-g', 'visit-m', 'visit-t'].forEach((id, i) => { const v = medRepo.visit(id); if (v) medRepo.saveVisit({ ...v, createdAt: ago(24 * (7 + i)) }); });
  const e = medRepo.visit('visit-e-next'); if (e) medRepo.saveVisit({ ...e, createdAt: ago(24 * 2) });
  // Let the scheduler itself write the history: replay it at each confirmation time, confirm, then carry on (the app runs it to "now" on load).
  const ev: [number, string, ApptConfirm['via'], string][] = [[24 * 6, 'visit-e', 'patient-reply', ''], [24 * 5, 'visit-r', 'portal', ''], [24 * 4, 'visit-p', 'staff-call', 'Front Desk Tester'], [24 * 2, 'visit-g', 'patient-reply', ''], [24 * 3 - 2, 'visit-g-po', 'patient-reply', '']];
  ev.sort((a, b) => b[0] - a[0]).forEach(([h, visitId, via, by]) => { const v = medRepo.visit(visitId); if (!v) return; const at = new Date(now - h * 3600e3); runReminders(at);
    const all = confirmations(); all[visitId] = { visitId, status: 'confirmed', at: at.toISOString(), by: by || `${svPatient(v.patientId)?.name} (patient)`, via }; svWrite('appt-confirm', all); });
});
