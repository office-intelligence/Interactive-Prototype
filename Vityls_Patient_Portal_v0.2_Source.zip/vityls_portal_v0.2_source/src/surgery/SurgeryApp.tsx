/*
 * Surgery.Vityls v0.6 app shell (edition SURGERY, src/edition.ts). Built on MED.Vityls v0.1; ASC.Vityls is untouched.
 * One thin top bar (wordmark, five text links, Acting as, portal, simulation stamp), the Nightingale header in the same
 * place on every primary page, the page, and one right panel for every source / secondary view.
 */
import { runReminders } from './reminders';
import { installHiddenFilter, PatientRecordsAdmin } from './patientAdmin';
import { ensureV06Seed } from './documents';
import { ensureV12Seed } from './v12/seed';
import { ensureHipaaWorkflow, seedHipaa } from './v13/hipaa';
import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { AdminActiveSection } from '../components/AdministrationPage';
import { SurgeryFormsWorkspace } from './v10/SurgeryFormsWorkspace';
import { migrateSurgeryStations } from './v10/stations';
import { migrateSurgerySigners } from './v11/signers';
import { migrateOfficeRoles } from './v11/officeRoles';
import { ensureV11ApptNotes } from './v11/apptNotes';
import { ProvidersAdmin } from '../v7/ProvidersAdmin';
import { PracticeConfig } from '../types';
import { MED_ROOMS } from '../med/seed';
import { getSettings, saveSettings } from '../med/settings';
import { medRepo } from '../med/record';
import { useActor, useMedTick } from '../med/ui';
import { AdministrationPage } from '../components/AdministrationPage';
import { BillingHub } from '../v7/Hubs';
import { SurgeryPerformance } from './SurgeryPerformance';
import { sessionUsers } from './staff';
import { PracticeHome, StaffPins, PracticeProfile, practiceNext } from './SurgeryPractice';
import { receivePending } from './asc';
import { Messages8 } from './v07/Messages8';
import { PracticePortalHub } from '../portal/PracticePortalHub';
import { MedPortal } from '../med/MedPortal';
import { MedPracticeSettings } from '../med/MedPracticeSettings';
import { SurgerySchedule } from './SurgerySchedule';
import { SurgerySettings } from './SurgerySettings';
import { SurgeryChart } from './SurgeryChart';
import { SurgeryStation } from './SurgeryStation';
import { Act, Ref, Step, chartNextSteps, todayNextSteps } from './nightingale';
import { Ctx, NightingaleBar, SvTab } from './ui';
import { RightPanel } from './panel';
import { PracticeGate } from './PracticeGate';
import { practiceUnlocked, practiceEditor, lockPractice, touchPractice } from './practiceLock';
import './surgery.css';
import './v07/v7.css';
import './v07/v8.css';
import './v09/v9.css';
import { installSurgeryForms } from './v09/formChrome';
installSurgeryForms();
import { migrateLegalStored } from './v12/legal';
import { initImages } from './v12/img';
import './v12/v12.css';
let booted = false;
import { EmailIntakePage } from '../modules/email-intake/EmailIntake';
import { MinimalPatient, ModulesPlan, Teaser, TrialBanner } from '../core/ui';
import { isCoreBuild, modOn, modReadOnly, modVisible, tabModule, teasersInNav, useCoreTick, corePractice } from '../core/useCore';
import { MOD, ModuleId } from '../core/modules';
import { Lock } from 'lucide-react';
import { NightingaleCard } from './v07/NightingaleCard';
import { pageBrief } from './v07/brief';
import { Today7 } from './v07/Today7';
import { Chart7 } from './v07/Chart7';

const practice = (): PracticeConfig => ({
  id: 'default-practice', practiceName: getSettings().practiceName, locationName: 'Main office', isPrimary: true, isSatellite: false, practiceType: 'General Medical/Surgical', specialty: 'Plastic Surgery',
  streetAddress: '', city: '', state: 'CA', zipCode: '', country: 'United States', telephone: '', email: '', website: '',
  primaryProvider: { firstName: 'Sam', lastName: 'Patel', degree: 'MD', cellPhone: '', email: '', npi: '' },
  calendarSettings: { startTime: '07:00 AM', endTime: '05:00 PM', visitTypes: [], rooms: MED_ROOMS.map((n, i) => ({ id: `room-exam-${i + 1}`, name: n, color: '#64748b', type: n.startsWith('Procedure') ? 'Procedure' : 'Exam', active: true, sortOrder: i + 1 })) },
} as PracticeConfig);

const NAV_ALL: { id: SvTab; label: string }[] = [{ id: 'email', label: 'Email intake' }, { id: 'home', label: 'Today' }, { id: 'schedule', label: 'Schedule' }, { id: 'patients', label: 'Patients' }, { id: 'messages', label: 'Messages' }, ...(isCoreBuild ? [{ id: 'portal-hub' as SvTab, label: 'Portal' }] : []), { id: 'practice', label: 'Practice' }];
/** core-modules: nav entries of enabled modules (+ calm teasers for locked ones when the practice wants them). Core: Patients, Practice. */
const navItems = () => NAV_ALL.map(n => { const m = tabModule(n.id); return { ...n, locked: !!m && !modVisible(m) }; }).filter(n => !n.locked || teasersInNav());
const firstTab = (): SvTab => (navItems().find(n => !n.locked)?.id || 'patients') as SvTab;

// v0.6: hidden charts are filtered at the repository; fictional documents + contact notes seeded once on top of v0.5 data.
installHiddenFilter();

export const SurgeryApp: React.FC = () => {
  if (!booted) { booted = true; try { migrateLegalStored(); } catch { /* */ } try { const cp = corePractice(); if (cp && cp.namespace.startsWith('vityls-p-') && !getSettings().practiceName.startsWith(cp.name)) saveSettings({ ...getSettings(), practiceName: `${cp.name} (fictional)` }, 'Vityls Core', 'System', 'Practice name from Vityls Core'); } catch { /* */ } void initImages(); }
  useMedTick(); useCoreTick(); const [actor, setActor] = useActor();
  const [tab, setTabRaw] = useState<SvTab>(firstTab); const [teaserMod, setTeaserMod] = useState<ModuleId | null>(null); const [patientId, setPatientId] = useState(''); const [visitId, setVisitId] = useState('');
  const [panel, setPanel] = useState<Ref | null>(null); const [toastMsg, setToast] = useState(''); const [portal, setPortal] = useState(false);
  const [practiceConfig, setPracticeConfig] = useState<PracticeConfig>(practice);
  useEffect(() => { document.title = 'Surgery.Vityls v0.13 (test build)'; try { ensureV06Seed(); ensureV12Seed(); ensureHipaaWorkflow(); seedHipaa(); migrateSurgeryStations(); migrateSurgerySigners(); migrateOfficeRoles(); ensureV11ApptNotes(); } catch (e) { console.warn('v0.6 seed', e); } receivePending(); runReminders(); const i = setInterval(() => runReminders(), 60000); return () => clearInterval(i); }, []);
  useEffect(() => { if (!toastMsg) return; const t = setTimeout(() => setToast(''), 3800); return () => clearTimeout(t); }, [toastMsg]);
  const setTab = useCallback((t: SvTab) => { setTeaserMod(null); setTabRaw(t); setPanel(null); window.scrollTo(0, 0); }, []);
  const openChart = useCallback((pid: string, r?: Ref) => { setPatientId(pid); setVisitId(''); setTabRaw('patients'); setPanel(r ? { ...r, pid } : null); window.scrollTo(0, 0); }, []);
  const openStation = useCallback((vid: string) => { const v = medRepo.visit(vid); if (!v) return; setPatientId(v.patientId); setVisitId(vid); setTabRaw('station'); setPanel(null); window.scrollTo(0, 0); }, []);
  const go = useCallback((a: Act) => { if (a.type === 'panel') setPanel(a.ref); else if (a.type === 'chart') openChart(a.pid, a.ref); else if (a.type === 'station') openStation(a.visitId); else { if (a.tab === 'patients') setPatientId(''); setTab(a.tab as SvTab); } }, [openChart, openStation, setTab]);
  const ctx = useMemo(() => ({ tab, patientId, panel, openPanel: (r: Ref) => setPanel({ ...r, pid: r.pid || patientId }), closePanel: () => setPanel(null), go, toast: setToast, setTab }), [tab, patientId, panel, go, setTab]);
  // v0.4: Practice needs an access PIN. Re-lock on leaving Practice, after 5 min idle, or on reload.
  const PRACTICE_TABS = ['modules', 'practice', 'forms', 'med-settings', 'surgery-settings', 'staff', 'profile', 'billing-hub', 'ops-hub', 'people', 'documents', 'records-admin', 'form-editor'];
  const inPractice = PRACTICE_TABS.includes(tab) && !portal;
  useEffect(() => { if (!inPractice && practiceUnlocked()) lockPractice('left Practice'); }, [inPractice]);
  useEffect(() => { const t = () => touchPractice(); window.addEventListener('pointerdown', t, true); window.addEventListener('keydown', t, true); const i = setInterval(() => { practiceUnlocked(); }, 15000); return () => { window.removeEventListener('pointerdown', t, true); window.removeEventListener('keydown', t, true); clearInterval(i); }; }, []);
  if (portal) return <div className="sv8-portal" data-edition="SURGERY"><MedPortal onExit={() => setPortal(false)} /></div>;

  const chartPid = (tab === 'patients' || tab === 'station') ? patientId : '';
  const nextAll: Step[] = chartPid && medRepo.patient(chartPid) ? chartNextSteps(medRepo.patient(chartPid)!, actor.role) : tab === 'home' || tab === 'schedule' || tab === 'messages' || (tab === 'patients' && !patientId) ? todayNextSteps() : practiceNext();
  // core-modules: Nightingale chips only for enabled modules
  const next = nextAll.filter(x => { const a: any = x.act; return a.type === 'tab' ? (!tabModule(a.tab) || modOn(tabModule(a.tab)!)) : a.type === 'station' ? modOn('stations-workflow') : true; });
  const chartOn = modVisible('chart'); const brand = corePractice()?.brand || 'Surgery';
  const lockedMod: ModuleId | null = teaserMod || ((m => m && !modVisible(m) ? m : null)(tabModule(tab) || null));
  const roMod: ModuleId | null = !lockedMod && tabModule(tab) && modReadOnly(tabModule(tab)!) ? tabModule(tab)! : null;
  const trialMod: ModuleId | null = isCoreBuild && !lockedMod && tabModule(tab) ? tabModule(tab)! : null;
  const activeNav = tab === 'station' ? 'home' : PRACTICE_TABS.includes(tab) ? 'practice' : tab; const unlocked = inPractice && practiceUnlocked(); const editor = practiceEditor();
  const ctxLabel = chartPid ? `${medRepo.patient(chartPid)?.name} · ${tab === 'station' ? 'visit workflow' : 'chart'}` : tab === 'home' ? 'Today · front office' : tab === 'schedule' ? 'Schedule' : tab === 'messages' ? 'Messages' : tab === 'patients' ? 'Patients' : 'Practice · settings are commands';
  // v0.7: Today and the Patient Chart are redesigned (Kevin's design A/B) and carry their own Nightingale card.
  const v7page = !portal && (!!lockedMod || tab === 'email' || tab === 'modules' || tab === 'home' || (tab === 'patients' && !!patientId && !!medRepo.patient(patientId)));
  return <Ctx.Provider value={ctx}>
    <div className={`sv ${v7page ? 'sv7-on' : ''}`} data-edition="SURGERY" data-testid="surgery-app">
      <a href="#sv-main" className="sr-only focus:not-sr-only">Skip to content</a>
      <header className="sv-top">
        <button type="button" className="sv-mark" onClick={() => setTab(firstTab())} data-testid="sv-logo">{brand}<span>.Vityls</span></button>
        <nav className="sv-nav" aria-label="Primary">{navItems().map(n => <button key={n.id} type="button" className={n.locked ? 'core-locked' : undefined} title={n.locked ? `Not in your plan · try ${MOD[tabModule(n.id)!].name} free` : undefined} aria-current={activeNav === n.id ? 'page' : undefined} onClick={() => { if (n.id === 'patients') setPatientId(''); setTab(n.id); }} data-testid={`sv-nav-${n.id}`}>{n.locked && <Lock size={12} />}{n.label}</button>)}</nav>
        <div className="sv-top-right">
          <label className="flex items-center gap-1.5 text-[12.5px] text-[var(--ink3)]"><span className="hidden lg:inline">Session</span><select className="sv-select" value={actor.name} onChange={e => { const a = sessionUsers().find(x => x.name === e.target.value); if (a) setActor(a); }} aria-label="Tablet session (test build)" title="Shared tablet session. Signing always asks for the signer’s own PIN." data-testid="acting-as">{sessionUsers().map(a => <option key={a.name} value={a.name}>{a.name} · {a.role}</option>)}</select></label>
          {unlocked && editor && <span className="sv-tag warn whitespace-nowrap" data-testid="practice-unlocked" title="Practice re-locks when you leave it or after 5 minutes without activity">Practice open · {editor.name.replace(/,.*$/, '')} <button type="button" className="sv-link ml-1" onClick={() => { lockPractice('locked by user'); setTab('home'); }} data-testid="practice-lock">Lock</button></span>}
          {modOn('portal-link') && <button type="button" className="sv-link text-[13px] whitespace-nowrap" onClick={() => setPortal(true)} data-testid="open-portal">Portal</button>}
          <span className="sv-stamp" title="Fictional data · scripted, on-device Nightingale · nothing is sent">SIMULATION · fictional</span>
        </div>
      </header>
      {trialMod && !v7page && <div className="core-banner-wrap"><TrialBanner m={trialMod} /></div>}
      {!v7page && (() => { const b = pageBrief(tab, chartPid); return <div className="v8-ngwrap"><NightingaleCard patientId={chartPid || undefined} reads={b.reads} placeholder={b.placeholder} summary={b.summary} chips={next.map(x => ({ label: x.label, act: x.act }))} /></div>; })()}
      <main id="sv-main" className={`sv-main${roMod ? ' core-readonly' : ''}`} data-readonly={roMod || undefined}>
        {lockedMod ? <Teaser m={lockedMod} onStarted={() => { setTeaserMod(null); setToast(`${MOD[lockedMod].name}: free trial started.`); }} /> : <>
        {(tab === 'home' || tab === 'patients') && trialMod && <div className="mb-3"><TrialBanner m={trialMod} /></div>}
        {inPractice && !unlocked && <PracticeGate />}
        {tab === 'email' && <EmailIntakePage onOpenPatient={pid => openChart(pid)} onOpenSchedule={() => setTab('schedule')} toast={setToast} />}
        {unlocked && tab === 'modules' && <ModulesPlan onOpen={m => setTeaserMod(m)} onBack={() => setTab('practice')} />}
        {tab === 'home' && <Today7 />}
        {tab === 'schedule' && <SurgerySchedule />}
        {unlocked && tab === 'surgery-settings' && <SurgerySettings />}
        {tab === 'patients' && (patientId && medRepo.patient(patientId) ? (chartOn ? <Chart7 patientId={patientId} /> : <MinimalPatient pid={patientId} onBack={() => { setPatientId(''); setTab('patients'); }} onTryChart={() => setTeaserMod('chart')} />) : <SurgeryChart patientId={patientId} />)}
        {tab === 'station' && visitId && <SurgeryStation key={visitId} visitId={visitId} onBack={() => setTab('home')} />}
        {tab === 'messages' && <Messages8 onOpenChart={pid => openChart(pid)} />}
        {tab === 'portal-hub' && <PracticePortalHub by={actor.name} />}
        {/* v0.11: the form editor is reached from Forms & workflow › Edit form; old links land there */}
        {unlocked && (tab === 'forms' || tab === 'form-editor') && <SurgeryFormsWorkspace activePracticeId="default-practice" onShowToast={setToast} onBack={() => setTab('practice')} />}
        {unlocked && tab === 'med-settings' && <MedPracticeSettings onBack={() => setTab('practice')} onToast={setToast} />}
        {unlocked && tab === 'practice' && <PracticeHome />}
        {unlocked && tab === 'staff' && <StaffPins />}
        {unlocked && tab === 'profile' && <PracticeProfile />}
        {unlocked && tab === 'billing-hub' && <BillingHub onBack={() => setTab('practice')} onToast={setToast} />}
        {unlocked && tab === 'ops-hub' && <SurgeryPerformance />}
        {unlocked && tab === 'records-admin' && <PatientRecordsAdmin />}
        {unlocked && tab === 'people' && <div className="sv-legacy" data-testid="surgery-providers"><button type="button" className="sv-link text-[13px] mb-2" onClick={() => setTab('practice')}>‹ Practice</button><ProvidersAdmin practice={practiceConfig.practiceName} onToast={setToast} sub="Surgeons, physicians, nurse practitioners and physician assistants. Adding a provider sends one invitation (simulated) with the membership application, username and signature PIN setup." /></div>}
        {unlocked && tab === 'documents' && <div className="sv-legacy"><button type="button" className="sv-link text-[13px] mb-2" onClick={() => setTab('practice')}>‹ Practice</button><AdministrationPage onShowToast={setToast} practiceConfig={practiceConfig} practicesList={[practiceConfig]} activePracticeId="default-practice" onSelectPractice={() => {}} onAddPractice={() => setToast('Additional locations are not part of this test build.')} onDeletePractice={() => {}} onUpdatePracticeConfig={setPracticeConfig} activeSection={tab as AdminActiveSection} onSectionChange={sec => { if (sec === 'home') setTab('practice'); else if (sec === 'people' || sec === 'documents') setTab(sec); }} onOpenFormsWorkspace={() => setTab('forms')} onNavigateBilling={() => setTab('billing-hub')} /></div>}
        </>}
      </main>
      <RightPanel />
      {toastMsg && <div role="status" className="fixed bottom-5 left-1/2 -translate-x-1/2 z-[90] bg-[#111418] text-white px-4 py-2.5 rounded-lg shadow-lg text-[14px] max-w-[90vw]" data-testid="sv-toast">{toastMsg}</div>}
    </div>
  </Ctx.Provider>;
};
