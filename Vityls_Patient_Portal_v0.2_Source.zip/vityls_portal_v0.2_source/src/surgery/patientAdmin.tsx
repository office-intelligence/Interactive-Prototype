/*
 * Surgery.Vityls v0.6 · Hide or delete a patient chart (charts added by mistake, duplicates, test entries).
 *  - Hide (default, reversible): the chart disappears from Patients, Today, Schedule, search and Nightingale, but
 *    nothing is erased. {mode === 'delete' ? 'An administrator (Practice Manager, Practice Administrator or a provider with admin rights) confirms with their own PIN.' : '{mode === 'delete' ? 'An administrator (Practice Manager, Practice Administrator or a provider with admin rights) confirms with their own PIN.' : 'A Practice Manager, Practice Administrator or provider confirms with their own PIN.'}'}
 *    Hidden charts are listed in Practice › Patient records admin, where they can be restored.
 *  - Delete permanently: erases the chart and everything filed under it in this browser (visits, notes, results,
 *    documents, contact notes, photos, body charts…). Same PIN roles, plus typing DELETE. The audit trail and a
 *    minimal tombstone (MRN, name, who, when, why) are kept, as they must be.
 * Hidden charts are filtered at the repository (medRepo) so every screen honours it without per-screen checks.
 * Henry: `patients.hidden_at/hidden_by/hidden_reason` (soft) and a hard-delete job that is blocked when the chart has
 * signed clinical notes or financial history unless an administrator overrides (retention rules); audit is immutable.
 */
import React, { useState } from 'react';
import { EyeOff, Trash2, RotateCcw } from 'lucide-react';
import { repo } from '../v6/dataLayer';
import { medRepo, MedPatient, patientKey, fmtDateTime, ping } from '../med/record';
import { useMedTick } from '../med/ui';
import { svRead, svWrite } from './store';
import { PinSign, Signer } from './sign';
import { PRACTICE_ROLES } from './practiceLock';
import { useSv } from './ui';
import { useActor as useActor0 } from '../med/ui';
/** v0.12 · Permanent delete needs an administrator: Practice Manager, Practice Administrator, or a provider with admin
 * rights (Surgery list `provider-admins`, seeded with the practice owner Sam Patel, MD). Hide is unchanged. */
export const ADMIN_STAFF_ROLES = ['Practice Manager', 'Practice Administrator'];
export const providerAdmins = () => svRead<string[]>('provider-admins', ['Sam Patel, MD']);
export const isDeleteAdmin = (p: { name: string; role: string }) => ADMIN_STAFF_ROLES.includes(p.role) || providerAdmins().includes(p.name);

export const HIDE_REASONS = ['Duplicate chart', 'Added by mistake', 'Test / training entry', 'Patient request (no care given)', 'Other'];
export interface HiddenRec { pid: string; name: string; dob: string; reason: string; note: string; by: string; role: string; at: string }
export interface DeletedRec { pid: string; name: string; dob: string; reason: string; note: string; by: string; role: string; at: string; removed: number }
export const hiddenMap = () => svRead<Record<string, HiddenRec>>('hidden-patients', {});
export const isHidden = (pid: string) => !!hiddenMap()[pid];
export const deletedPatients = () => svRead<DeletedRec[]>('deleted-patients', []);

/* ---------------- repository filter (installed once by the Surgery app) ---------------- */
const RAW = 'vityls:med:patients';
export const allPatientsRaw = (): MedPatient[] => { try { return JSON.parse(localStorage.getItem(RAW) || '[]'); } catch { return []; } };
let installed = false;
export function installHiddenFilter() {
  if (installed) return; installed = true;
  const r = medRepo as any; const proto = Object.getPrototypeOf(medRepo);
  const hid = () => hiddenMap();
  r.patients = function () { const h = hid(); return proto.patients.call(this).filter((p: MedPatient) => !h[p.id]); };
  r.patient = function (id: string) { return hid()[id] ? undefined : proto.patient.call(this, id); };
  r.visits = function (pid?: string) { const h = hid(); if (pid && h[pid]) return []; return proto.visits.call(this, pid).filter((v: { patientId: string }) => !h[v.patientId]); };
  r.labs = function (pid?: string) { const h = hid(); return proto.labs.call(this, pid).filter((v: { patientId: string }) => !h[v.patientId]); };
  r.messages = function (pid?: string) { const h = hid(); return proto.messages.call(this, pid).filter((v: { patientId: string }) => !h[v.patientId]); };
  r.caregivers = function (pid?: string) { const h = hid(); return proto.caregivers.call(this, pid).filter((v: { patientId: string }) => !h[v.patientId]); };
}

export function hidePatient(p: MedPatient, reason: string, note: string, w: Signer, session: string) {
  const m = hiddenMap(); m[p.id] = { pid: p.id, name: p.name, dob: p.dob, reason, note, by: w.name, role: w.role, at: w.at }; svWrite('hidden-patients', m);
  repo.audit({ caseId: patientKey(p.id), user: w.name, role: w.role, action: 'patient.hide', detail: `Chart hidden from view: ${p.name} (${p.id}) · ${reason}${note ? ` · ${note}` : ''} · confirmed with ${w.name}’s PIN (tablet session: ${session}). Nothing erased; restore in Practice › Patient records.` });
}
export function restorePatient(pid: string, w: Signer) {
  const m = hiddenMap(); const h = m[pid]; if (!h) return; delete m[pid]; svWrite('hidden-patients', m);
  repo.audit({ caseId: patientKey(pid), user: w.name, role: w.role, action: 'patient.restore', detail: `Chart restored to view: ${h.name} (${pid}) · confirmed with ${w.name}’s PIN` });
}
/** Erase the chart and everything filed under it (patientId / its visit ids) in the office stores. Audit is kept. */
export function deletePatientPermanently(pid: string, reason: string, note: string, w: Signer, session: string): number {
  const p = allPatientsRaw().find(x => x.id === pid); if (!p) throw new Error('Chart not found.');
  const visitIds = new Set<string>((() => { try { return (JSON.parse(localStorage.getItem('vityls:med:visits') || '[]') as { id: string; patientId: string }[]).filter(v => v.patientId === pid).map(v => v.id); } catch { return []; } })());
  const KEEP = ['vityls:surgery:hidden-patients', 'vityls:surgery:deleted-patients', 'vityls:surgery:staff', 'vityls:surgery:staff-invites', 'vityls:surgery:settings', 'vityls:med:settings'];
  const mine = (x: any) => x && typeof x === 'object' && (x.patientId === pid || x.pid === pid || (x.visitId && visitIds.has(x.visitId)));
  let removed = 0; const keys: string[] = []; for (let i = 0; i < localStorage.length; i++) { const k = localStorage.key(i); if (k && /^vityls:(med|surgery):/.test(k) && !KEEP.includes(k)) keys.push(k); }
  keys.forEach(k => {
    let v: any; try { v = JSON.parse(localStorage.getItem(k) || 'null'); } catch { return; }
    if (Array.isArray(v)) { const n = v.filter(x => !(mine(x) || (k === RAW && x?.id === pid) || (k === 'vityls:med:visits' && visitIds.has(x?.id)))); if (n.length !== v.length) { removed += v.length - n.length; localStorage.setItem(k, JSON.stringify(n)); } }
    else if (v && typeof v === 'object') { let ch = 0; Object.keys(v).forEach(key => { if (key === pid || visitIds.has(key) || mine(v[key])) { delete v[key]; ch++; } }); if (ch) { removed += ch; localStorage.setItem(k, JSON.stringify(v)); } }
  });
  const m = hiddenMap(); if (m[pid]) { delete m[pid]; svWrite('hidden-patients', m); }
  svWrite('deleted-patients', [...deletedPatients(), { pid, name: p.name, dob: p.dob, reason, note, by: w.name, role: w.role, at: w.at, removed }]);
  repo.audit({ caseId: patientKey(pid), user: w.name, role: w.role, action: 'patient.delete', detail: `Chart permanently deleted: ${p.name} (${pid}) · ${reason}${note ? ` · ${note}` : ''} · ${removed} record(s) erased from this device · confirmed with ${w.name}’s PIN (tablet session: ${session}). Audit trail kept.` });
  ping(); return removed;
}

/* ---------------- dialog: Hide or delete (from the chart header) ---------------- */
export const HideDeleteDialog: React.FC<{ p: MedPatient; list?: MedPatient[]; session: string; initialMode?: 'hide' | 'delete'; onClose: () => void; onDone: (mode: 'hide' | 'delete') => void }> = ({ p, list, session, initialMode = 'hide', onClose, onDone }) => {
  const [sess] = useActor0(); const admin = isDeleteAdmin(sess); const all = list && list.length ? list : [p];
  const [mode, setMode] = useState<'hide' | 'delete'>(initialMode === 'delete' && !isDeleteAdmin(sess) ? 'hide' : initialMode); const [reason, setReason] = useState(''); const [note, setNote] = useState(''); const [typed, setTyped] = useState(''); const [pin, setPin] = useState(false); const [err, setErr] = useState('');
  const visits = all.reduce((n, x) => n + medRepo.visits(x.id).length, 0); const signed = all.reduce((n, x) => n + medRepo.visits(x.id).filter(v => medRepo.note(v.id)?.status === 'signed').length, 0);
  const next = () => { if (!reason) { setErr('Choose a reason.'); return; } if (reason === 'Other' && !note.trim()) { setErr('Describe the reason.'); return; } if (mode === 'delete' && typed.trim().toUpperCase() !== 'DELETE') { setErr('Type DELETE to confirm permanent deletion.'); return; } setErr(''); setPin(true); };
  return <div className="sv-modal" role="dialog" aria-modal="true" aria-label="Hide or delete chart" data-testid="hide-delete-dialog">
    <div className="sv-modal-scrim" onClick={onClose} />
    <div className="sv-modal-box" style={{ width: 'min(520px, calc(100vw - 24px))' }}>
      <b className="text-[15px] block mb-1">Hide or delete this chart</b>
      <p className="text-[13px] mb-2" data-testid="hd-who">{all.length > 1 ? <b>{all.length} charts: {all.map(x => x.name).join(', ')}</b> : <><b>{p.name}</b> · DOB {p.dob} · {p.id}</>} · {visits} visit{visits === 1 ? '' : 's'}{signed ? ` · ${signed} signed note${signed === 1 ? '' : 's'}` : ''}</p>
      <div className="grid gap-2 mb-2" role="radiogroup" aria-label="Action">
        <label className={`sv-choice ${mode === 'hide' ? 'on' : ''}`}><input type="radio" name="hd" checked={mode === 'hide'} onChange={() => setMode('hide')} data-testid="hd-mode-hide" /><EyeOff size={16} /><span><b>Hide from view</b> (recommended)<br /><span className="sv-small sv-muted">Removed from Patients, Today, Schedule and search. Nothing is erased. Restore any time in Practice › Patient records.</span></span></label>
        <label className={`sv-choice danger ${mode === 'delete' ? 'on' : ''}`} style={admin ? undefined : { opacity: .55 }} title={admin ? undefined : 'Only an administrator can delete permanently'}><input type="radio" name="hd" checked={mode === 'delete'} disabled={!admin} onChange={() => setMode('delete')} data-testid="hd-mode-delete" /><Trash2 size={16} /><span><b>Delete permanently</b><br /><span className="sv-small sv-muted">Erases the chart and everything filed under it (visits, notes, results, documents, photos). Cannot be undone. The audit trail is kept.</span>{!admin && <span className="sv-small block mt-0.5" style={{ color: 'var(--warn)' }} data-testid="hd-delete-hint">Only an administrator (Practice Manager, Practice Administrator or a provider with admin rights) can delete. Switch the Session to an administrator, or hide the chart instead.</span>}</span></label>
      </div>
      <label className="block mb-2"><span className="sv-label">Reason</span><select className="sv-input" value={reason} onChange={e => setReason(e.target.value)} data-testid="hd-reason"><option value="">Choose…</option>{HIDE_REASONS.map(r => <option key={r}>{r}</option>)}</select></label>
      <label className="block mb-2"><span className="sv-label">Note {reason === 'Other' ? '' : '(optional)'} · e.g. “duplicate of MED-1001”</span><input className="sv-input" value={note} onChange={e => setNote(e.target.value)} data-testid="hd-note" /></label>
      {mode === 'delete' && <>{signed > 0 && <p className="text-[12.5px] sv-warn mb-1">This chart has signed clinical notes. Medical-record retention rules usually require keeping them; hiding is safer.</p>}
        <label className="block"><span className="sv-label">Type DELETE to confirm</span><input className="sv-input" value={typed} onChange={e => setTyped(e.target.value)} autoComplete="off" data-testid="hd-typed" /></label></>}
      {err && <p className="text-[12.5px] text-[var(--crit)] mt-2" role="alert">{err}</p>}
      <p className="text-[11.5px] sv-muted mt-2">{mode === 'delete' ? 'An administrator (Practice Manager, Practice Administrator or a provider with admin rights) confirms with their own PIN.' : 'A Practice Manager, Practice Administrator or provider confirms with their own PIN.'}</p>
      <div className="flex justify-end gap-2 mt-3"><button type="button" className="sv-btn" onClick={onClose}>Cancel</button><button type="button" className={`sv-btn ${mode === 'delete' ? 'danger' : 'primary'}`} onClick={next} data-testid="hd-continue">{mode === 'delete' ? 'Delete permanently…' : 'Hide chart…'}</button></div>
    </div>
    {pin && <PinSign title={mode === 'delete' ? 'Confirm permanent deletion' : 'Confirm hiding this chart'} statement={<>{mode === 'delete' ? 'I am permanently deleting' : 'I am hiding'} the chart{all.length > 1 ? 's' : ''} of {all.map(x => `${x.name} (${x.id})`).join(', ')} · {reason}.</>} roles={PRACTICE_ROLES} allow={mode === 'delete' ? isDeleteAdmin : undefined} confirmLabel={mode === 'delete' ? 'Delete' : 'Hide'} onClose={() => setPin(false)}
      onSigned={w => { try { if (mode === 'delete' && !isDeleteAdmin(w)) throw new Error('Only an administrator can delete permanently.'); all.forEach(x => { if (mode === 'delete') deletePatientPermanently(x.id, reason, note.trim(), w, session); else hidePatient(x, reason, note.trim(), w, session); }); setPin(false); onDone(mode); } catch (e: any) { setPin(false); setErr(e?.message || 'Could not complete.'); } }} />}
  </div>;
};

/* ---------------- Practice › Patient records: hidden charts + deletions ---------------- */
export const HiddenPatientsAdmin: React.FC<{ session: string }> = ({ session }) => {
  useMedTick(); const { toast } = useSv(); const hidden = Object.values(hiddenMap()).sort((a, b) => b.at.localeCompare(a.at)); const del = deletedPatients().slice().reverse();
  const [act, setAct] = useState<{ pid: string; mode: 'restore' | 'delete' } | null>(null);
  const target = act ? allPatientsRaw().find(x => x.id === act.pid) : undefined;
  return <section data-testid="hidden-patients-admin">
    <h2 className="sv-h mt-1">Hidden charts ({hidden.length})</h2>
    {hidden.length === 0 ? <p className="sv-muted text-[13px]">No hidden charts. Hide a chart from the Patients list (⋯ › Hide).</p> :
      <table className="sv-table"><thead><tr><th>Patient</th><th>Reason</th><th>Hidden by</th><th className="text-right">Actions</th></tr></thead><tbody>{hidden.map(h => <tr key={h.pid} data-testid="hidden-row"><td><b>{h.name}</b><div className="sv-small sv-muted">DOB {h.dob} · {h.pid}</div></td><td>{h.reason}{h.note && <div className="sv-small sv-muted">{h.note}</div>}</td><td>{h.by}<div className="sv-small sv-muted">{fmtDateTime(h.at)}</div></td>
        <td className="text-right whitespace-nowrap"><button type="button" className="sv-btn sm inline-flex items-center gap-1" onClick={() => setAct({ pid: h.pid, mode: 'restore' })} data-testid="hidden-restore"><RotateCcw size={13} />Restore</button> <button type="button" className="sv-btn sm danger inline-flex items-center gap-1" onClick={() => setAct({ pid: h.pid, mode: 'delete' })} data-testid="hidden-delete"><Trash2 size={13} />Delete permanently</button></td></tr>)}</tbody></table>}
    <h2 className="sv-h mt-4">Permanently deleted ({del.length})</h2>
    {del.length === 0 ? <p className="sv-muted text-[13px]">None.</p> : <table className="sv-table"><thead><tr><th>Chart</th><th>Reason</th><th>Deleted by</th><th>Records erased</th></tr></thead><tbody>{del.map((d, i) => <tr key={i} data-testid="deleted-row"><td><b>{d.name}</b><div className="sv-small sv-muted">{d.pid}</div></td><td>{d.reason}{d.note && <div className="sv-small sv-muted">{d.note}</div>}</td><td>{d.by}<div className="sv-small sv-muted">{fmtDateTime(d.at)}</div></td><td>{d.removed}</td></tr>)}</tbody></table>}
    <p className="sv-small sv-muted mt-2">Kept after deletion: the audit trail and this one-line tombstone. Billing ledger entries in the shared billing store are not erased (financial-record retention).</p>
    {act?.mode === 'restore' && <PinSign title="Restore chart" statement={<>I am restoring the chart of {hiddenMap()[act.pid]?.name} to view.</>} roles={PRACTICE_ROLES} confirmLabel="Restore" onClose={() => setAct(null)} onSigned={w => { restorePatient(act.pid, w); setAct(null); toast('Chart restored. It is visible again.'); }} />}
    {act?.mode === 'delete' && target && <HideDeleteDialog p={target} session={session} initialMode="delete" onClose={() => setAct(null)} onDone={() => { setAct(null); toast('Chart permanently deleted. The audit trail is kept.'); }} />}
  </section>;
};

/* ---------------- Practice › Patient records (document types + hidden / deleted charts) ---------------- */
import { docTypes, saveDocTypes, DEFAULT_DOC_TYPES } from './documents';
import { practiceActor } from './practiceLock';
import { useActor } from '../med/ui';
export const PatientRecordsAdmin: React.FC = () => {
  useMedTick(); const [session] = useActor(); const { setTab, toast } = useSv(); const who = practiceActor(session);
  const [types, setTypes] = useState(docTypes().join('\n'));
  return <div className="sv-page" data-testid="sv-records-admin">
    <button type="button" className="sv-link text-[13px] mb-2" onClick={() => setTab('practice')}>‹ Practice</button>
    <h1 className="sv-title">Patient records</h1><div className="sv-sub mb-3">Document types for the chart’s Documents folder, and charts that were hidden or deleted.</div>
    <section className="mb-5" data-testid="doc-types-settings"><h2 className="sv-h">Document types</h2>
      <p className="sv-small sv-muted mb-1">One per line. They order the Documents folder filter and the Add document list. Removing a type does not change documents already filed under it.</p>
      <textarea className="sv-input" rows={8} style={{ maxWidth: 460 }} value={types} onChange={e => setTypes(e.target.value)} data-testid="doc-types-text" />
      <div className="flex gap-2 mt-2"><button type="button" className="sv-btn sm primary" onClick={() => { const l: string[] = [...new Set<string>(types.split('\n').map(x => x.trim()).filter(Boolean))]; if (!l.length) { toast('Keep at least one type.'); return; } saveDocTypes(l, who.name, who.role); toast('Document types saved.'); }} data-testid="doc-types-save">Save types</button><button type="button" className="sv-btn sm" onClick={() => setTypes(DEFAULT_DOC_TYPES.join('\n'))}>Defaults</button></div>
    </section>
    <HiddenPatientsAdmin session={session.name} />
  </div>;
};
