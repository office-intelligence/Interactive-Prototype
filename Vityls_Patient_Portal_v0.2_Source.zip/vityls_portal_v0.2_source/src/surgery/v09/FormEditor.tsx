/*
 * Surgery.Vityls v0.9 — Form templates & editor (practice-scoped).
 * Library of every template → editor with palette, outline, canvas (drag & drop + keyboard), properties panel,
 * live preview (tablet + print), undo/redo, search, versions (draft / publish / restore original), JSON import/export.
 * v0.10: no Signature/Initials field types (signatures come from the station signer setup); no Clone (add the same template to as many stations as needed).
 */
import React, { useEffect, useMemo, useRef, useState } from 'react';
import { ArrowLeft, ChevronUp, ChevronDown, Copy, Trash2, Undo2, Redo2, Search, GripVertical, Plus, Eye, Pencil, Printer, Download, Upload, History, RotateCcw, Tablet } from 'lucide-react';
import { uid } from '../../med/record';
import { useActor, useMedTick } from '../../med/ui';
import { useSv } from '../ui';
import { applyChrome } from './formChrome';
import { stripSignatures, catalog, entry, statusOf, workingDef, originalDef, saveDraft, publish, discardDraft, restoreOriginal, republish, exportJson, importJson, logImport, renderHtml, FormDef, Field, Section, FieldType, TYPE_LABEL, PREFILL, Cond } from './formLib';

const PALETTE: { t: FieldType; hint: string }[] = [
  { t: 'text', hint: 'One line' }, { t: 'longtext', hint: 'Paragraph' }, { t: 'number', hint: '123' }, { t: 'date', hint: 'MM/DD/YYYY' }, { t: 'yesno', hint: 'Yes · No' },
  { t: 'single', hint: 'Pick one' }, { t: 'multi', hint: 'Pick many' }, { t: 'dropdown', hint: 'Menu' }, { t: 'checkbox', hint: 'Tick box' },
  { t: 'grid', hint: 'Rows × columns' }, { t: 'heading', hint: 'Sub-heading' }, { t: 'instruction', hint: 'Read-only text' }, { t: 'prefill', hint: 'From the chart' }];
const newField = (t: FieldType, taken: Set<string>): Field => { const base = TYPE_LABEL[t]; let n = t, i = 2; while (taken.has(n)) n = `${t}_${i++}` as any;
  return { id: uid('f'), type: t, name: n, label: t === 'heading' ? 'New heading' : t === 'instruction' ? 'Please read' : t === 'prefill' ? 'Patient name' : `New ${base.toLowerCase()} field`, width: t === 'longtext' || t === 'grid' || t === 'instruction' || t === 'heading' ? 3 : 1,
    options: ['single', 'multi', 'dropdown'].includes(t) ? ['Option 1', 'Option 2', 'Option 3'] : undefined, columns: t === 'grid' ? ['Item', 'Dose', 'Notes'] : undefined, rows: t === 'grid' ? 3 : undefined, prefill: t === 'prefill' ? 'patientName' : undefined, help: t === 'instruction' ? 'Instruction text shown to the patient.' : undefined }; };
const clone = <T,>(x: T): T => JSON.parse(JSON.stringify(x));
const SAMPLE = { name: 'Ellen Testwood', first: 'Ellen', last: 'Testwood', dob: '04/18/1954', age: '72', sex: 'Female', mrn: 'MED-1001', phone: '(555) 014-1001', email: 'ellen@example.test', address: '12 Sample Way', city: 'Bayview', state: 'CA', zip: '94000', emergencyName: '', emergencyPhone: '', procedure: 'Bilateral upper blepharoplasty', surgeon: 'Sam Patel, MD', anesProvider: '', anesType: '', room: 'Exam 1', dateUs: new Date().toLocaleDateString('en-US'), dateIso: '', time: '', allergies: 'Penicillin, Codeine', meds: 'Clopidogrel 75 mg daily', pmh: [], height: '', weight: '' } as any;

/* ---------------- library ---------------- */
export const FormLibraryPage: React.FC<{ onBack: () => void }> = ({ onBack }) => {
  useMedTick(); const [actor] = useActor(); const { toast } = useSv(); const [q, setQ] = useState(''); const [open, setOpen] = useState<string | null>(null); const [cat, setCat] = useState('All');
  const list = catalog(); const cats = ['All', ...Array.from(new Set(list.map(f => f.category)))];
  const shown = list.filter(f => (cat === 'All' || f.category === cat) && `${f.title} ${f.category}`.toLowerCase().includes(q.toLowerCase()));
  if (open) return <FormEditor file={open} onBack={() => setOpen(null)} />;
  return <div className="fe-lib" data-testid="form-library">
    <button type="button" className="sv-link text-[13px] mb-2" onClick={onBack}>‹ Practice</button>
    <h1 className="sv-title">Form templates</h1>
    <p className="sv-sub mb-3">Every form starts as a Vityls template. Your practice edits its own copy — drafts stay private until you publish; the original is always restorable, and forms already started keep the version they began with. Station placement and signers stay in Forms &amp; workflow: signatures and initials are captured at the station by the signers set up for each form, so the editor has no signature fields.</p>
    <div className="flex flex-wrap gap-2 mb-3"><div className="fe-search"><Search size={14} /><input className="sv-input" placeholder="Search templates" value={q} onChange={e => setQ(e.target.value)} data-testid="fl-search" /></div>
      <select className="sv-input" style={{ width: 'auto' }} value={cat} onChange={e => setCat(e.target.value)} aria-label="Category">{cats.map(c => <option key={c}>{c}</option>)}</select><span className="sv-small sv-muted self-center">{shown.length} of {list.length}</span></div>
    <table className="sv-table" data-testid="fl-table"><thead><tr><th>Template</th><th>Category</th><th>Status</th><th>Last change</th><th /></tr></thead><tbody>{shown.map(f => { const st = statusOf(f.file); const e = entry(f.file); const last = e?.events[e.events.length - 1];
      return <tr key={f.file} data-testid="fl-row" data-file={f.file}><td><button type="button" className="sv-link" onClick={() => setOpen(f.file)}><b>{e?.title || f.title}</b></button></td><td className="sv-small">{f.category}</td>
        <td><span className={`v7-pill ${st.s === 'published' ? 'green' : st.s === 'draft' ? 'amber' : 'gray'}`} data-testid="fl-status">{st.s === 'published' ? `Published v${st.v}` : st.s === 'draft' ? 'Draft' : 'Original'}</span>{st.s === 'published' && st.draft && <span className="v7-pill amber ml-1">draft pending</span>}</td>
        <td className="sv-small sv-muted">{last ? `${new Date(last.at).toLocaleDateString()} · ${last.by}` : '—'}</td>
        <td className="whitespace-nowrap"><button type="button" className="sv-btn sm" onClick={() => setOpen(f.file)} data-testid="fl-edit"><Pencil size={13} />Edit</button></td></tr>; })}</tbody></table>
  </div>;
};

/* ---------------- editor ---------------- */
type Sel = { kind: 'field'; id: string } | { kind: 'section'; id: string } | null;
export const FormEditor: React.FC<{ file: string; onBack: () => void }> = ({ file, onBack }) => {
  useMedTick(); const [actor] = useActor(); const { toast } = useSv();
  const [def, setDefRaw] = useState<FormDef>(() => clone(workingDef(file))); const [past, setPast] = useState<FormDef[]>([]); const [future, setFuture] = useState<FormDef[]>([]);
  const [sel, setSel] = useState<Sel>(null); const [mode, setMode] = useState<'edit' | 'tablet' | 'print'>('edit'); const [q, setQ] = useState(''); const [dirty, setDirty] = useState(false);
  const [hist, setHist] = useState(false); const [confirm, setConfirm] = useState<'restore' | 'publish' | null>(null); const [note, setNote] = useState(''); const [err, setErr] = useState<string[]>([]); const [drag, setDrag] = useState<{ id?: string; t?: FieldType } | null>(null); const [over, setOver] = useState<string>('');
  const fileIn = useRef<HTMLInputElement>(null); const e = entry(file); const st = statusOf(file);
  const setDef = (d: FormDef) => { setPast(p => [...p.slice(-59), def]); setFuture([]); setDefRaw(d); setDirty(true); };
  const undo = () => { if (!past.length) return; setFuture(f => [def, ...f]); setDefRaw(past[past.length - 1]); setPast(p => p.slice(0, -1)); setDirty(true); };
  const redo = () => { if (!future.length) return; setPast(p => [...p, def]); setDefRaw(future[0]); setFuture(f => f.slice(1)); setDirty(true); };
  const allFields = def.sections.flatMap(s => s.fields.map(f => ({ s, f })));
  const find = (id: string) => allFields.find(x => x.f.id === id);
  const names = new Set<string>(allFields.map(x => x.f.name));
  const mut = (fn: (d: FormDef) => void) => { const d = clone(def); fn(d); setDef(d); };
  const locate = (d: FormDef, id: string) => { for (const s of d.sections) { const i = s.fields.findIndex(f => f.id === id); if (i >= 0) return { s, i }; } return null; };
  const moveField = (id: string, dir: -1 | 1) => mut(d => { const L = locate(d, id); if (!L) return; const { s, i } = L; const j = i + dir; if (j >= 0 && j < s.fields.length) { [s.fields[i], s.fields[j]] = [s.fields[j], s.fields[i]]; return; }
    const si = d.sections.indexOf(s); const ns = d.sections[si + dir]; if (!ns) return; const [f] = s.fields.splice(i, 1); if (dir < 0) ns.fields.push(f); else ns.fields.unshift(f); });
  const dupField = (id: string) => mut(d => { const L = locate(d, id); if (!L) return; const f = clone(L.s.fields[L.i]); f.id = uid('f'); let n = `${f.name}_copy`, k = 2; while (names.has(n)) n = `${f.name}_copy${k++}`; f.name = n; f.label = `${f.label} (copy)`; L.s.fields.splice(L.i + 1, 0, f); setTimeout(() => setSel({ kind: 'field', id: f.id })); });
  const delField = (id: string) => { mut(d => { const L = locate(d, id); if (L) L.s.fields.splice(L.i, 1); }); setSel(null); };
  const addField = (t: FieldType, secId?: string, beforeId?: string) => { const f = newField(t, names); mut(d => { let s = d.sections.find(x => x.id === secId) || (sel?.kind === 'field' ? locate(d, sel.id)?.s : sel?.kind === 'section' ? d.sections.find(x => x.id === sel.id) : undefined) || d.sections[d.sections.length - 1];
    if (!s) { s = { id: uid('s'), title: 'New section', columns: 2, fields: [] }; d.sections.push(s); }
    const bi = beforeId ? s.fields.findIndex(x => x.id === beforeId) : sel?.kind === 'field' && !secId ? s.fields.findIndex(x => x.id === sel.id) + 1 : -1; if (bi >= 0) s.fields.splice(bi, 0, f); else s.fields.push(f); }); setSel({ kind: 'field', id: f.id }); };
  const dropOn = (secId: string, beforeId?: string) => { const dg = drag; setDrag(null); setOver(''); if (!dg) return; if (dg.t) { addField(dg.t, secId, beforeId); return; } if (!dg.id || dg.id === beforeId) return;
    mut(d => { const L = locate(d, dg.id!); if (!L) return; const [f] = L.s.fields.splice(L.i, 1); const s = d.sections.find(x => x.id === secId)!; const bi = beforeId ? s.fields.findIndex(x => x.id === beforeId) : -1; if (bi >= 0) s.fields.splice(bi, 0, f); else s.fields.push(f); }); };
  const addSection = () => { const s: Section = { id: uid('s'), title: 'New section', columns: 2, fields: [] }; mut(d => { const i = sel?.kind === 'section' ? d.sections.findIndex(x => x.id === sel.id) : sel?.kind === 'field' ? d.sections.findIndex(x => x.fields.some(f => f.id === sel.id)) : d.sections.length - 1; d.sections.splice(i + 1, 0, s); }); setSel({ kind: 'section', id: s.id }); };
  const moveSec = (id: string, dir: -1 | 1) => mut(d => { const i = d.sections.findIndex(s => s.id === id); const j = i + dir; if (j < 0 || j >= d.sections.length) return; [d.sections[i], d.sections[j]] = [d.sections[j], d.sections[i]]; });
  const validate = (d: FormDef) => { const out: string[] = []; const seen = new Set<string>(); const fs = d.sections.flatMap(s => s.fields);
    fs.forEach(f => { if (!f.label.trim() && f.type !== 'instruction') out.push(`A ${TYPE_LABEL[f.type].toLowerCase()} field has no label.`); if (!/^[A-Za-z][\w-]*$/.test(f.name)) out.push(`“${f.label}”: field key must start with a letter (letters, numbers, _ or -).`); if (seen.has(f.name)) out.push(`Field key “${f.name}” is used twice.`); seen.add(f.name);
      if (['single', 'multi', 'dropdown'].includes(f.type) && !(f.options || []).filter(Boolean).length) out.push(`“${f.label}” needs at least one option.`);
      if (f.cond?.field && !fs.some(x => x.name === f.cond!.field)) out.push(`“${f.label}” shows only if “${f.cond.field}”, which no longer exists.`); });
    if (!d.title.trim()) out.push('The form needs a title.'); return out; };
  // Tablet: the properties drawer covers the lower part of the screen, so keep the selected field above it.
  useEffect(() => { if (!sel || window.innerWidth >= 1100) return; const t = setTimeout(() => { const el = document.querySelector('[data-testid=fe-field].sel, [data-testid=fe-section].sel') as HTMLElement | null; if (!el) return; const r = el.getBoundingClientRect(); const L = document.querySelector('.fe-left'); const off = (L ? L.getBoundingClientRect().bottom : 120) + 12; const limit = window.innerHeight * 0.42; if (r.top < off || r.top > limit) window.scrollBy({ top: r.top - off, behavior: 'instant' as ScrollBehavior }); }, 30); return () => clearTimeout(t); }, [sel]);
  useEffect(() => { const k = (ev: KeyboardEvent) => { const tag = (ev.target as HTMLElement)?.tagName; const typing = tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT';
      if ((ev.ctrlKey || ev.metaKey) && ev.key.toLowerCase() === 'z' && !typing) { ev.preventDefault(); ev.shiftKey ? redo() : undo(); }
      else if ((ev.ctrlKey || ev.metaKey) && ev.key.toLowerCase() === 'y' && !typing) { ev.preventDefault(); redo(); }
      else if (sel?.kind === 'field' && !typing && ev.altKey && (ev.key === 'ArrowUp' || ev.key === 'ArrowDown')) { ev.preventDefault(); moveField(sel.id, ev.key === 'ArrowUp' ? -1 : 1); }
      else if (sel?.kind === 'field' && !typing && (ev.ctrlKey || ev.metaKey) && ev.key.toLowerCase() === 'd') { ev.preventDefault(); dupField(sel.id); } };
    window.addEventListener('keydown', k); return () => window.removeEventListener('keydown', k); });
  const match = (f: Field) => !q || `${f.label} ${f.name} ${TYPE_LABEL[f.type]}`.toLowerCase().includes(q.toLowerCase());
  const doSave = () => { saveDraft(file, def, actor.name, actor.role); setDirty(false); toast('Draft saved — not live until you publish.'); };
  const doPublish = () => { const v = validate(def); setErr(v); if (v.length) { setConfirm(null); return; } const n = publish(file, def, actor.name, actor.role, note.trim() || undefined); setDirty(false); setConfirm(null); setNote(''); toast(`Published v${n}. New forms use it; forms already started keep their version.`); };
  const doExport = () => { const blob = new Blob([exportJson(file, def)], { type: 'application/json' }); const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = `${def.title.replace(/[^\w]+/g, '_')}.vityls-form.json`; a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 2000); toast('Template exported as JSON.'); };
  const doImport = async (f: File | undefined) => { if (!f) return; try { const d = importJson(await f.text()); setDef(d); logImport(file, actor.name, actor.role); toast(`Imported “${d.title}” into the draft. Review, then save or publish.`); } catch (x: any) { setErr([x.message || 'Could not read that file.']); } };
  const selField = sel?.kind === 'field' ? find(sel.id)?.f : undefined; const selSec = sel?.kind === 'section' ? def.sections.find(s => s.id === sel.id) : undefined;
  const updField = (patch: Partial<Field>) => selField && mut(d => { const L = locate(d, selField.id); if (L) Object.assign(L.s.fields[L.i], patch); });
  const updSec = (patch: Partial<Section>) => selSec && mut(d => { Object.assign(d.sections.find(s => s.id === selSec.id)!, patch); });
  const before = (id: string) => { const out: Field[] = []; for (const s of def.sections) for (const f of s.fields) { if (f.id === id) return out; out.push(f); } return out; };
  return <div className="fe" data-testid="form-editor" data-mode={mode}>
    <div className="fe-top">
      <button type="button" className="sv-btn sm" onClick={() => { if (dirty && !window.confirm('Leave without saving the draft?')) return; onBack(); }} data-testid="fe-back"><ArrowLeft size={14} />Templates</button>
      <div className="fe-tt"><input className="fe-title" value={def.title} onChange={x => setDef({ ...def, title: x.target.value })} aria-label="Form title" data-testid="fe-title" />
        <div className="sv-small sv-muted">{st.s === 'published' ? `Published v${st.v}` : st.s === 'draft' ? 'Draft (not live)' : 'Original template'}{dirty ? ' · unsaved changes' : st.draft ? ' · draft saved' : ''}</div></div>
      <div className="fe-tools">
        <button type="button" className="sv-btn sm" onClick={undo} disabled={!past.length} aria-label="Undo" title="Undo (Ctrl+Z)" data-testid="fe-undo"><Undo2 size={14} /></button>
        <button type="button" className="sv-btn sm" onClick={redo} disabled={!future.length} aria-label="Redo" title="Redo (Ctrl+Y)" data-testid="fe-redo"><Redo2 size={14} /></button>
        <div className="sv-seg" role="group" aria-label="Mode"><button type="button" aria-pressed={mode === 'edit'} onClick={() => setMode('edit')} data-testid="fe-mode-edit"><Pencil size={13} />Edit</button><button type="button" aria-pressed={mode === 'tablet'} onClick={() => setMode('tablet')} data-testid="fe-mode-tablet"><Tablet size={13} />Tablet</button><button type="button" aria-pressed={mode === 'print'} onClick={() => setMode('print')} data-testid="fe-mode-print"><Printer size={13} />Print</button></div>
        <div className="fe-menu"><button type="button" className="sv-btn sm" onClick={() => setHist(h => !h)} aria-expanded={hist} data-testid="fe-more"><History size={14} />Versions &amp; more</button>
          {hist && <div className="v7-menu-pop fe-pop" role="menu" data-testid="fe-more-pop">
            <div className="g">Versions</div>
            {(e?.versions || []).length === 0 && <div className="sv-small sv-muted px-2 py-1">No published versions yet.</div>}
            {[...(e?.versions || [])].reverse().map(v => <div key={v.v} className="fe-ver" data-testid="fe-version"><b>v{v.v}</b>{v.v === e?.published && <span className="v7-pill green ml-1">live</span>}<span className="sv-small sv-muted ml-1">{new Date(v.at).toLocaleDateString()} · {v.by}{v.note ? ` · ${v.note}` : ''}</span>
              <span className="ml-auto flex gap-2"><button type="button" className="sv-link text-[12px]" onClick={() => { setDef(clone(stripSignatures(v.def))); setHist(false); toast(`Loaded v${v.v} into the editor (draft).`); }}>Load</button>{v.v !== e?.published && <button type="button" className="sv-link text-[12px]" onClick={() => { republish(file, v.v, actor.name, actor.role); setHist(false); toast(`v${v.v} published again as a new version.`); }}>Republish</button>}</span></div>)}
            <div className="g">Template</div>
            <button type="button" role="menuitem" onClick={() => { setHist(false); setConfirm('restore'); }} data-testid="fe-restore"><RotateCcw size={13} /> Restore the original template…</button>
            {st.draft && <button type="button" role="menuitem" onClick={() => { discardDraft(file, actor.name); setDefRaw(clone(workingDef(file))); setDirty(false); setHist(false); toast('Draft discarded.'); }}>Discard saved draft</button>}
            <button type="button" role="menuitem" onClick={() => { setHist(false); doExport(); }} data-testid="fe-export"><Download size={13} /> Export JSON</button>
            <button type="button" role="menuitem" onClick={() => { setHist(false); fileIn.current?.click(); }} data-testid="fe-import"><Upload size={13} /> Import JSON…</button>
            <div className="g">Activity</div>{(e?.events || []).slice(-6).reverse().map((x, i) => <div key={i} className="sv-small sv-muted px-2">{new Date(x.at).toLocaleString()} · {x.what} · {x.by}</div>)}
          </div>}</div>
        <input ref={fileIn} type="file" accept=".json,application/json" className="hidden" onChange={x => { doImport(x.target.files?.[0]); x.target.value = ''; }} data-testid="fe-import-file" />
        <button type="button" className="sv-btn sm" onClick={doSave} data-testid="fe-save">Save draft</button>
        <button type="button" className="sv-btn sm primary" onClick={() => { const v = validate(def); setErr(v); if (!v.length) setConfirm('publish'); }} data-testid="fe-publish">Publish</button>
      </div>
    </div>
    {err.length > 0 && <div className="fe-err" role="alert" data-testid="fe-errors"><b>Fix before publishing:</b><ul>{err.map((x, i) => <li key={i}>{x}</li>)}</ul><button type="button" className="sv-link text-[12px]" onClick={() => setErr([])}>dismiss</button></div>}
    {mode === 'edit' ? <div className="fe-body">
      <aside className="fe-left" aria-label="Field types and outline">
        <div className="fe-k">ADD A FIELD</div>
        <div className="fe-pal" data-testid="fe-palette">{PALETTE.map(p => <button key={p.t} type="button" draggable onDragStart={() => setDrag({ t: p.t })} onDragEnd={() => setDrag(null)} onClick={() => addField(p.t)} data-testid={`pal-${p.t}`} title={`${TYPE_LABEL[p.t]} — click to add after the selected field, or drag onto the form`}><b>{TYPE_LABEL[p.t]}</b><span>{p.hint}</span></button>)}</div>
        <button type="button" className="sv-btn sm w-full mt-2" onClick={addSection} data-testid="fe-add-section"><Plus size={13} />Section</button>
        <div className="fe-k mt-4">OUTLINE</div>
        <div className="fe-search"><Search size={13} /><input className="sv-input" placeholder="Search fields" value={q} onChange={x => setQ(x.target.value)} data-testid="fe-search" /></div>
        <ol className="fe-outline" data-testid="fe-outline">{def.sections.map(s => <li key={s.id}><button type="button" className={sel?.kind === 'section' && sel.id === s.id ? 'on' : ''} onClick={() => setSel({ kind: 'section', id: s.id })}><b>{s.title}</b> <span>{s.fields.length}</span></button>
          <ol>{s.fields.filter(match).map(f => <li key={f.id}><button type="button" className={sel?.kind === 'field' && sel.id === f.id ? 'on' : ''} onClick={() => { setSel({ kind: 'field', id: f.id }); document.getElementById(`fe-${f.id}`)?.scrollIntoView({ block: 'center', behavior: 'smooth' }); }} data-testid="fe-outline-item">{f.label || TYPE_LABEL[f.type]}</button></li>)}</ol></li>)}</ol>
        <p className="sv-small sv-muted mt-3">Keyboard: select a field, then Alt+↑/↓ to move, Ctrl+D to duplicate, Ctrl+Z / Ctrl+Y to undo / redo.</p>
      </aside>
      <main className="fe-canvas" aria-label="Form canvas" data-testid="fe-canvas">
        {def.intro !== undefined && <div className="fe-intro"><span className="fe-k">INTRO TEXT</span><textarea className="sv-input" rows={2} value={def.intro} onChange={x => setDef({ ...def, intro: x.target.value })} /></div>}
        {def.sections.map((s, si) => <section key={s.id} className={`fe-sec ${sel?.kind === 'section' && sel.id === s.id ? 'sel' : ''}`} data-testid="fe-section"
          onDragOver={x => { if (drag) { x.preventDefault(); setOver(`s:${s.id}`); } }} onDrop={x => { x.preventDefault(); dropOn(s.id); }}>
          <div className="fe-sec-h" onClick={() => setSel({ kind: 'section', id: s.id })}><input className="fe-sec-t" value={s.title} onChange={x => mut(d => { d.sections[si].title = x.target.value; })} aria-label="Section title" />
            <select className="sv-input fe-cols" value={s.columns} onChange={x => mut(d => { d.sections[si].columns = Number(x.target.value) as any; })} aria-label="Columns" data-testid="fe-sec-cols"><option value={1}>1 column</option><option value={2}>2 columns</option><option value={3}>3 columns</option></select>
            {s.cond?.field && <span className="v7-pill gray">conditional</span>}
            <span className="fe-acts"><button type="button" onClick={() => moveSec(s.id, -1)} aria-label="Move section up" disabled={si === 0}><ChevronUp size={14} /></button><button type="button" onClick={() => moveSec(s.id, 1)} aria-label="Move section down" disabled={si === def.sections.length - 1}><ChevronDown size={14} /></button><button type="button" onClick={() => { if (!s.fields.length || window.confirm(`Delete “${s.title}” and its ${s.fields.length} field(s)?`)) { mut(d => { d.sections.splice(si, 1); }); setSel(null); } }} aria-label="Delete section"><Trash2 size={14} /></button></span></div>
          <div className={`fe-grid c${s.columns}`}>
            {s.fields.map(f => <div key={f.id} id={`fe-${f.id}`} className={`fe-f w${Math.min(f.width || 1, s.columns)} ${sel?.kind === 'field' && sel.id === f.id ? 'sel' : ''} ${q && !match(f) ? 'dim' : ''} ${over === `f:${f.id}` ? 'over' : ''}`} data-testid="fe-field" data-type={f.type} data-name={f.name} tabIndex={0} role="button" aria-label={`${TYPE_LABEL[f.type]}: ${f.label}`}
              draggable onDragStart={x => { x.stopPropagation(); setDrag({ id: f.id }); }} onDragEnd={() => { setDrag(null); setOver(''); }} onDragOver={x => { if (drag) { x.preventDefault(); x.stopPropagation(); setOver(`f:${f.id}`); } }} onDrop={x => { x.preventDefault(); x.stopPropagation(); dropOn(s.id, f.id); }}
              onClick={() => setSel({ kind: 'field', id: f.id })} onKeyDown={x => { if (x.key === 'Enter' || x.key === ' ') { x.preventDefault(); setSel({ kind: 'field', id: f.id }); } }}>
              <div className="fe-f-h"><GripVertical size={13} className="fe-grip" aria-hidden="true" /><span className="fe-type">{TYPE_LABEL[f.type]}</span>{f.required && <span className="fe-req">required</span>}{f.prefill && <span className="fe-badge">prefill · {PREFILL[f.prefill]}</span>}{f.cond?.field && <span className="fe-badge">shows if {f.cond.field}</span>}
                <span className="fe-acts"><button type="button" onClick={x => { x.stopPropagation(); moveField(f.id, -1); }} aria-label="Move up" data-testid="fe-up"><ChevronUp size={13} /></button><button type="button" onClick={x => { x.stopPropagation(); moveField(f.id, 1); }} aria-label="Move down" data-testid="fe-down"><ChevronDown size={13} /></button><button type="button" onClick={x => { x.stopPropagation(); dupField(f.id); }} aria-label="Duplicate" data-testid="fe-dup"><Copy size={13} /></button><button type="button" onClick={x => { x.stopPropagation(); delField(f.id); }} aria-label="Delete" data-testid="fe-del"><Trash2 size={13} /></button></span></div>
              <div className="fe-f-l">{f.label}{f.required ? ' *' : ''}</div>
              <FieldMock f={f} />
              {f.help && f.type !== 'instruction' && <div className="fe-f-help">{f.help}</div>}
            </div>)}
            <div className={`fe-drop w3 ${over === `s:${s.id}` ? 'over' : ''}`} aria-hidden="true">{drag ? 'Drop here' : s.fields.length ? '' : 'Empty section — add a field from the left or drag one here'}</div>
          </div>
        </section>)}
        <button type="button" className="sv-btn" onClick={addSection}><Plus size={13} />Add section</button>
      </main>
      <aside className={`fe-props ${sel ? 'open' : ''}`} aria-label="Properties" data-testid="fe-props">
        {selField ? <FieldProps f={selField} upd={updField} earlier={before(selField.id)} publishedNames={new Set((e?.versions || []).flatMap(v => v.def.sections.flatMap(s => s.fields.map(x => x.name))))} onClose={() => setSel(null)} />
          : selSec ? <div><div className="fe-k">SECTION</div><label className="block mb-2"><span className="sv-label">Title</span><input className="sv-input" value={selSec.title} onChange={x => updSec({ title: x.target.value })} /></label>
            <label className="block mb-2"><span className="sv-label">Layout</span><select className="sv-input" value={selSec.columns} onChange={x => updSec({ columns: Number(x.target.value) as any })}><option value={1}>1 column</option><option value={2}>2 columns</option><option value={3}>3 columns</option></select></label>
            <CondEditor c={selSec.cond} earlier={allFields.map(x => x.f).filter(f => !selSec.fields.includes(f))} set={c => updSec({ cond: c })} /><button type="button" className="sv-btn sm mt-3 fe-close" onClick={() => setSel(null)}>Done</button></div>
          : <div className="sv-small sv-muted" data-testid="fe-props-empty"><div className="fe-k">PROPERTIES</div>Select a field or section to edit its label, type, help text, required, default, options, width, prefill and show-if logic.</div>}
      </aside>
    </div> : <Preview def={def} mode={mode} file={file} />}
    {confirm === 'publish' && <div className="sv-modal" role="dialog" aria-modal="true" aria-label="Publish template" data-testid="fe-publish-dlg"><div className="sv-modal-scrim" onClick={() => setConfirm(null)} /><div className="sv-modal-box" style={{ width: 'min(520px, calc(100vw - 24px))' }}>
      <b className="text-[16px]">Publish {def.title} v{(e?.versions[e.versions.length - 1]?.v || 0) + 1}?</b><p className="sv-small sv-muted mt-1">New forms will use this version. Forms already started (and every signed form) keep the version they began with. You can restore the original or any earlier version later.</p>
      <label className="block mt-2"><span className="sv-label">What changed (optional)</span><input className="sv-input" value={note} onChange={x => setNote(x.target.value)} data-testid="fe-publish-note" /></label>
      <div className="flex gap-2 justify-end mt-3"><button type="button" className="sv-btn" onClick={() => setConfirm(null)}>Cancel</button><button type="button" className="sv-btn primary" onClick={doPublish} data-testid="fe-publish-confirm">Publish</button></div></div></div>}
    {confirm === 'restore' && <div className="sv-modal" role="dialog" aria-modal="true" aria-label="Restore original" data-testid="fe-restore-dlg"><div className="sv-modal-scrim" onClick={() => setConfirm(null)} /><div className="sv-modal-box" style={{ width: 'min(520px, calc(100vw - 24px))' }}>
      <b className="text-[16px]">Restore the original template?</b><p className="sv-small sv-muted mt-1">New forms go back to the Vityls original. Your practice versions are kept in history and can be republished; past forms are unchanged.</p>
      <div className="flex gap-2 justify-end mt-3"><button type="button" className="sv-btn" onClick={() => setConfirm(null)}>Cancel</button><button type="button" className="sv-btn primary" onClick={() => { restoreOriginal(file, actor.name, actor.role); setDefRaw(clone(originalDef(file))); setPast([]); setFuture([]); setDirty(false); setConfirm(null); toast('Original template restored.'); }} data-testid="fe-restore-confirm">Restore original</button></div></div></div>}
  </div>;
};

const FieldMock: React.FC<{ f: Field }> = ({ f }) => {
  switch (f.type) {
    case 'longtext': return <div className="fe-mock tall">{f.defaultValue || f.placeholder || ''}</div>;
    case 'yesno': return <div className="fe-opts"><span>○ Yes</span><span>○ No</span></div>;
    case 'single': return <div className="fe-opts">{(f.options || []).slice(0, 6).map(o => <span key={o}>○ {o}</span>)}{(f.options || []).length > 6 && <span>+{(f.options || []).length - 6}</span>}</div>;
    case 'multi': return <div className="fe-opts">{(f.options || []).slice(0, 6).map(o => <span key={o}>☐ {o}</span>)}{(f.options || []).length > 6 && <span>+{(f.options || []).length - 6}</span>}</div>;
    case 'checkbox': return <div className="fe-opts"><span>☐ {f.label}</span></div>;
    case 'dropdown': return <div className="fe-mock">{f.defaultValue || 'Choose…'} ▾</div>;
    case 'signature': return <div className="fe-mock sig">Sign here</div>;
    case 'initials': return <div className="fe-mock" style={{ width: 80 }}>Initials</div>;
    case 'grid': return <table className="fe-gridm"><thead><tr>{(f.columns || []).map(c => <th key={c}>{c}</th>)}</tr></thead><tbody>{Array.from({ length: Math.min(f.rows || 3, 3) }, (_, i) => <tr key={i}>{(f.columns || []).map(c => <td key={c} />)}</tr>)}</tbody></table>;
    case 'heading': return null;
    case 'instruction': return <div className="fe-instr">{f.help}</div>;
    case 'prefill': return <div className="fe-mock pre">↳ {PREFILL[f.prefill || 'patientName']} (from the chart)</div>;
    case 'date': return <div className="fe-mock">MM/DD/YYYY</div>;
    default: return <div className="fe-mock">{f.defaultValue || f.placeholder || ''}</div>;
  }
};

const CondEditor: React.FC<{ c?: Cond; earlier: Field[]; set: (c?: Cond) => void }> = ({ c, earlier, set }) => {
  const src = earlier.filter(f => !['heading', 'instruction', 'grid', 'signature', 'initials'].includes(f.type)); const sf = src.find(f => f.name === c?.field);
  return <div className="fe-cond" data-testid="fe-cond"><span className="sv-label">Show this only if…</span>
    <select className="sv-input" value={c?.field || ''} onChange={x => set(x.target.value ? { field: x.target.value, op: 'eq', value: (src.find(f => f.name === x.target.value)?.type === 'yesno' ? 'Yes' : src.find(f => f.name === x.target.value)?.options?.[0]) || '' } : undefined)} data-testid="fe-cond-field"><option value="">Always shown</option>{src.map(f => <option key={f.id} value={f.name}>{f.label.slice(0, 50)}</option>)}</select>
    {c?.field && <div className="flex gap-2 mt-1.5"><select className="sv-input" value={c.op} onChange={x => set({ ...c, op: x.target.value as any })} data-testid="fe-cond-op"><option value="eq">is</option><option value="neq">is not</option><option value="filled">is answered</option><option value="checked">is ticked</option></select>
      {(c.op === 'eq' || c.op === 'neq') && (sf && (sf.type === 'yesno' || sf.options?.length) ? <select className="sv-input" value={c.value || ''} onChange={x => set({ ...c, value: x.target.value })} data-testid="fe-cond-value">{(sf.type === 'yesno' ? ['Yes', 'No'] : sf.type === 'checkbox' ? ['Yes'] : sf.options || []).map(o => <option key={o}>{o}</option>)}</select> : <input className="sv-input" value={c.value || ''} onChange={x => set({ ...c, value: x.target.value })} data-testid="fe-cond-value" />)}</div>}
  </div>;
};

const FieldProps: React.FC<{ f: Field; upd: (p: Partial<Field>) => void; earlier: Field[]; publishedNames: Set<string>; onClose: () => void }> = ({ f, upd, earlier, publishedNames, onClose }) => {
  const choice = ['single', 'multi', 'dropdown'].includes(f.type);
  return <div data-testid="fe-field-props"><div className="flex items-center"><div className="fe-k">FIELD · {TYPE_LABEL[f.type].toUpperCase()}</div><button type="button" className="sv-link text-[12px] ml-auto fe-close" onClick={onClose}>Done</button></div>
    <label className="block mb-2"><span className="sv-label">{f.type === 'instruction' ? 'Title (optional)' : 'Label'}</span><input className="sv-input" value={f.label} onChange={x => upd({ label: x.target.value })} data-testid="fp-label" /></label>
    <label className="block mb-2"><span className="sv-label">Type</span><select className="sv-input" value={f.type} onChange={x => { const t = x.target.value as FieldType; upd({ type: t, options: ['single', 'multi', 'dropdown'].includes(t) ? (f.options?.length ? f.options : ['Option 1', 'Option 2']) : f.options, columns: t === 'grid' ? (f.columns || ['Item', 'Notes']) : f.columns, rows: t === 'grid' ? (f.rows || 3) : f.rows, prefill: t === 'prefill' ? (f.prefill || 'patientName') : f.prefill }); }} data-testid="fp-type">{Object.entries(TYPE_LABEL).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</select></label>
    {f.type === 'prefill' && <label className="block mb-2"><span className="sv-label">Fill from the chart</span><select className="sv-input" value={f.prefill} onChange={x => upd({ prefill: x.target.value, label: f.label === PREFILL[f.prefill || ''] || f.label === 'Patient name' ? PREFILL[x.target.value] : f.label })} data-testid="fp-prefill">{Object.entries(PREFILL).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</select><span className="sv-small sv-muted">Filled when the form opens; staff can still correct it.</span></label>}
    <label className="block mb-2"><span className="sv-label">{f.type === 'instruction' ? 'Text' : 'Help text'}</span><textarea className="sv-input" rows={f.type === 'instruction' ? 5 : 2} value={f.help || ''} onChange={x => upd({ help: x.target.value || undefined })} data-testid="fp-help" /></label>
    {!['heading', 'instruction'].includes(f.type) && <label className="flex items-center gap-2 mb-2 text-[13px]"><input type="checkbox" checked={!!f.required} onChange={x => upd({ required: x.target.checked })} data-testid="fp-required" />Required</label>}
    {choice && <label className="block mb-2"><span className="sv-label">Options (one per line)</span><textarea className="sv-input" rows={5} value={(f.options || []).join('\n')} onChange={x => upd({ options: x.target.value.split('\n') })} onBlur={x => upd({ options: x.target.value.split('\n').map(s => s.trim()).filter(Boolean) })} data-testid="fp-options" /></label>}
    {f.type === 'grid' && <><label className="block mb-2"><span className="sv-label">Columns (comma-separated)</span><input className="sv-input" value={(f.columns || []).join(', ')} onChange={x => upd({ columns: x.target.value.split(',').map(s => s.trim()).filter(Boolean) })} data-testid="fp-columns" /></label>
      <label className="block mb-2"><span className="sv-label">Rows</span><input className="sv-input" inputMode="numeric" value={f.rows || 3} onChange={x => upd({ rows: Math.max(1, Math.min(30, Number(x.target.value) || 1)) })} /></label></>}
    {['text', 'longtext', 'number', 'date', 'dropdown', 'single', 'checkbox'].includes(f.type) && <label className="block mb-2"><span className="sv-label">Default value</span>{choice && f.type !== 'multi' ? <select className="sv-input" value={f.defaultValue || ''} onChange={x => upd({ defaultValue: x.target.value || undefined })}><option value="">None</option>{(f.options || []).map(o => <option key={o}>{o}</option>)}</select> : f.type === 'checkbox' ? <select className="sv-input" value={f.defaultValue || ''} onChange={x => upd({ defaultValue: x.target.value || undefined })}><option value="">Unticked</option><option value="Yes">Ticked</option></select> : <input className="sv-input" type={f.type === 'date' ? 'date' : 'text'} value={f.defaultValue || ''} onChange={x => upd({ defaultValue: x.target.value || undefined })} data-testid="fp-default" />}</label>}
    {['text', 'longtext', 'number'].includes(f.type) && <label className="block mb-2"><span className="sv-label">Placeholder</span><input className="sv-input" value={f.placeholder || ''} onChange={x => upd({ placeholder: x.target.value || undefined })} /></label>}
    <span className="sv-label">Width</span><div className="sv-seg mb-2" role="group" aria-label="Width">{([1, 2, 3] as const).map(w => <button key={w} type="button" aria-pressed={(f.width || 1) === w} onClick={() => upd({ width: w })} data-testid={`fp-width-${w}`}>{w === 1 ? '⅓' : w === 2 ? '⅔' : 'Full'}</button>)}</div>
    <CondEditor c={f.cond} earlier={earlier} set={c => upd({ cond: c })} />
    <details className="mt-3"><summary className="text-[12.5px] font-semibold cursor-pointer">Advanced</summary><label className="block mt-1"><span className="sv-label">Field key (stored data name)</span><input className="sv-input mono" value={f.name} onChange={x => upd({ name: x.target.value.replace(/\s+/g, '_') })} data-testid="fp-name" /></label>
      {publishedNames.has(f.name) && <p className="sv-small mt-1" style={{ color: 'var(--v7-amber)' }}>This key exists in a published version. Changing it starts a new data column; past answers stay under the old key.</p>}</details>
  </div>;
};

/* Live preview: the exact HTML the station will open, with the Surgery letterhead, in a tablet or letter frame. */
const Preview: React.FC<{ def: FormDef; mode: 'tablet' | 'print'; file: string }> = ({ def, mode, file }) => {
  const host = useRef<HTMLDivElement>(null);
  useEffect(() => { const h = host.current; if (!h) return; const root = h.shadowRoot || h.attachShadow({ mode: 'open' }); const html = renderHtml(def); const doc = new DOMParser().parseFromString(html, 'text/html');
    root.innerHTML = `<style>${Array.from(doc.querySelectorAll('style')).map(s => s.textContent).join('\n')}</style><style>.vk-root{padding:${mode === 'print' ? '0' : '18px'};font-size:14px;color:#16211f}.packet-container{max-width:none}</style><div class="vk-root">${doc.body.innerHTML}</div>`;
    applyChrome(root, SAMPLE, { file, title: def.title }); }, [def, mode, file]);
  return <div className={`fe-prev ${mode}`} data-testid={`fe-preview-${mode}`}>
    <div className="fe-prev-bar"><Eye size={14} /><b>{mode === 'tablet' ? 'Tablet preview · 768 px' : 'Print preview · US Letter'}</b><span className="sv-small sv-muted">Sample patient (fictional). Show-if logic is live — try answering.</span>{mode === 'print' && <button type="button" className="sv-btn sm ml-auto" onClick={() => window.print()} data-testid="fe-print-go"><Printer size={13} />Print</button>}</div>
    <div className="fe-prev-scroll"><div className="fe-frame"><div ref={host} /></div></div></div>;
};
