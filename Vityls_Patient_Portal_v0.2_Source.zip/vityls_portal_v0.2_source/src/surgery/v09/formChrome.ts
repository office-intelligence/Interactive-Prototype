/* v0.9: Surgery form header (letterhead) + section headings in the app's design language, on screen and in print.
   Also wires prefill-bound fields and conditional show/hide for practice templates. Form bodies are otherwise untouched. */
import type { CaseContext } from '../../v6/formRules';
import { getSettings } from '../../med/settings';
import { quoteSettings } from '../quotes';
import { formEngineHooks } from '../../v6/formEngine';
import { formSourceHooks } from '../../v6/formSource';
import { dropLegal, patchLegalInMemory, fixLegalDom } from '../v12/legal';
import { mountRegistrationCards } from '../v12/regCards';
import { htmlFor, entry, pinnedVersion } from './formLib';

const esc = (s: string) => String(s ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
export const HEADER_CSS = `
:host{--lh-ink:#16211f;--lh-mut:#55645f;--lh-line:#e2e6e1;--lh-acc:#1f5d52}
.vk-root, .vk-root *:not(code){font-family:'Public Sans',system-ui,-apple-system,sans-serif!important}
.sv9-lh{display:block;background:#fff;border:1px solid var(--lh-line);border-radius:3px;padding:18px 22px 14px;margin:0 0 14px;color:var(--lh-ink)}
.sv9-lh .r1{display:flex;justify-content:space-between;align-items:flex-start;gap:16px;flex-wrap:wrap}
.sv9-lh .prac{font-size:13px;font-weight:800;color:var(--lh-acc);letter-spacing:-.005em}.sv9-lh .addr{font-size:11px;color:var(--lh-mut);margin-top:2px}
.sv9-lh .kind{font-size:10.5px;font-weight:700;letter-spacing:.08em;color:var(--lh-mut);text-transform:uppercase;text-align:right}
.sv9-lh h1.sv9-title{font-size:22px;font-weight:800;letter-spacing:-.01em;margin:10px 0 10px;color:var(--lh-ink);line-height:1.2;border:0;padding:0;background:none}
.sv9-lh .pt{display:flex;flex-wrap:wrap;gap:6px 22px;border-top:1px solid var(--lh-line);padding-top:9px;font-size:12.5px}
.sv9-lh .pt span{color:var(--lh-mut);font-size:10.5px;font-weight:700;letter-spacing:.05em;text-transform:uppercase;margin-right:6px}
.sv9-lh .ver{font-size:10.5px;color:var(--lh-mut);margin-top:6px}
.vk-root .header-block > h1, .vk-root .page > h1:first-child, .vk-root .page .top h1, .vk-root .form-page > h1:first-child{display:none!important}
.vk-root .header-block{background:none!important;border:0!important;box-shadow:none!important;padding:0!important;margin:0 0 10px!important}
.vk-root .compliance-note{font-size:12.5px!important;color:var(--lh-mut)!important;background:#f6f7f4!important;border:1px solid var(--lh-line)!important;border-left-width:1px!important;border-radius:3px!important;padding:8px 10px!important}
.vk-root .section-banner, .vk-root .section-title, .vk-root .section-header, .vk-root .sheet .banner{background:none!important;color:var(--lh-acc)!important;border:0!important;border-bottom:1px solid var(--lh-line)!important;border-radius:0!important;padding:4px 0 5px!important;margin:18px 0 10px!important;font-size:11.5px!important;font-weight:800!important;letter-spacing:.07em!important;text-transform:uppercase!important;box-shadow:none!important}
.vk-root .packet-container, .vk-root .form-page, .vk-root .page{border-radius:3px!important}
.vk-root input, .vk-root select, .vk-root textarea, .vk-root button{border-radius:3px!important}
.vk-root .who, .vk-root .vityls-patient-header{display:none!important}
.vk-root .sheet > .page-head{background:none!important;color:var(--lh-mut,#5b6763)!important;padding:0 22px!important;margin:0 0 6px!important;border:0!important}.vk-root .sheet > .page-head h1{display:none!important}.vk-root .sheet > .page-head p{opacity:1!important;font-size:12.5px!important;margin:0!important;color:inherit!important}.vk-root .sheet .banner{color:var(--lh-acc)!important}.vk-root .sheet .banner.warn,.vk-root .sheet .banner.alert{color:#8a4b0f!important}
@media print{.sv9-lh{border:0;border-bottom:1px solid #16211f;border-radius:0;padding:0 0 10px;margin-bottom:12px}.sv9-lh h1.sv9-title{font-size:18px}}
`;
function letterhead(ctx: CaseContext, title: string, file: string) {
  const s = getSettings(); const q = quoteSettings(); const e = entry(file); const pv = ctx && (ctx as any).__pid ? pinnedVersion(file, (ctx as any).__pid) : undefined;
  const ver = typeof pv === 'number' ? `Practice template v${pv}` : e?.published ? '' : '';
  const date = ctx.dateUs || new Date().toLocaleDateString('en-US');
  return `<header class="sv9-lh" data-testid="form-letterhead"><div class="r1"><div><div class="prac">${esc(s.practiceName.replace(/\s*\(fictional\)/, ''))}</div><div class="addr">${esc(q.address)} · ${esc(q.phone)}</div></div><div class="kind">Patient form</div></div>
  <h1 class="sv9-title">${esc(title)}</h1>
  <div class="pt"><div><span>Patient</span><b>${esc(ctx.name || '—')}</b></div><div><span>DOB</span>${esc(ctx.dob || '—')}</div><div><span>MRN</span>${esc(ctx.mrn || '—')}</div><div><span>Date</span>${esc(date)}</div></div>${ver ? `<div class="ver">${ver}</div>` : ''}</header>`;
}
function wireConditions(root: ShadowRoot) {
  const els = Array.from(root.querySelectorAll<HTMLElement>('[data-show-if]')); if (!els.length) return;
  const val = (name: string) => { const c = Array.from(root.querySelectorAll<HTMLInputElement>(`[name="${CSS.escape(name)}"]`)); if (!c.length) return { v: '', checked: false };
    if (c[0].type === 'radio') { const x = c.find(i => i.checked); return { v: x?.value || '', checked: !!x }; } if (c[0].type === 'checkbox') { const xs = c.filter(i => i.checked).map(i => i.value); return { v: xs.join(','), checked: xs.length > 0 }; } return { v: c[0].value, checked: !!c[0].value }; };
  const run = () => els.forEach(el => { try { const c = JSON.parse(el.dataset.showIf || '{}'); const x = val(c.field); const show = c.op === 'eq' ? x.v.split(',').includes(c.value || '') || x.v === c.value : c.op === 'neq' ? x.v !== (c.value || '') : c.op === 'checked' ? x.checked : !!x.v; el.classList.toggle('sv9-hidden', !show); } catch { /* ignore */ } });
  root.addEventListener('input', run, true); root.addEventListener('change', run, true); run();
}
function prefill(root: ShadowRoot, ctx: CaseContext) { root.querySelectorAll<HTMLInputElement>('[data-prefill]').forEach(i => { if (i.value) return; const k = i.dataset.prefill || ''; const v = k === 'patientName' ? ctx.name : (ctx as any)[k]; if (v) { i.value = String(v); i.dataset.vkBound = 'patient'; } }); }
export function applyChrome(root: ShadowRoot, ctx: CaseContext, o: { file: string; title: string }) {
  const st = document.createElement('style'); st.textContent = HEADER_CSS; root.appendChild(st);
  const box = root.querySelector('.vk-root'); if (box && !box.querySelector('.sv9-lh')) box.insertAdjacentHTML('afterbegin', letterhead(ctx, o.title, o.file));
  prefill(root, ctx); wireConditions(root);
  try { fixLegalDom(root); if (/^Patient_Registration\.html$/i.test(o.file)) mountRegistrationCards(root, ctx.mrn, ctx.name); } catch { /* */ }
}
/** Called once by the Surgery app. */
/** v0.10 Surgery wording: the Patient Registration asks for First Name / Last Name (not “Legal …”). */
export const surgeryWording = (_file: string, html: string) => dropLegal(html);
export function installSurgeryForms() { patchLegalInMemory(); formEngineHooks.afterMount = applyChrome; formSourceHooks.override = (file, pid) => htmlFor(file, pid); formSourceHooks.transform = surgeryWording; }
