/*
 * Surgery.Vityls v0.9 — practice-scoped form templates.
 * Every bundled form is a template. A practice works on its own copy (draft), publishes numbered versions, and can
 * restore the original at any time. Filled forms are pinned to the version they were started on, so publishing a new
 * version never changes a past record. Storage: Surgery namespace (`form-lib`, `form-pins`); audited.
 * Backend swap point: /practices/:id/form-templates/:file/versions.
 */
import { repo } from '../../v6/dataLayer';
import { uid } from '../../med/record';
import { getBundledFormHtml } from '../../v6/formSource';
import { VITYLS_FORM_CATALOG } from '../../data/formWorkspaceCatalog';
import { svRead, svWrite } from '../store';

export const PRACTICE_ID = 'default-practice';
export type FieldType = 'text' | 'longtext' | 'number' | 'date' | 'yesno' | 'single' | 'multi' | 'dropdown' | 'checkbox' | 'signature' | 'initials' | 'grid' | 'heading' | 'instruction' | 'prefill';
export const PREFILL: Record<string, string> = { patientName: 'Patient name', dob: 'Date of birth', mrn: 'MRN', age: 'Age', sex: 'Sex', phone: 'Phone', email: 'Email', address: 'Address', allergies: 'Allergies', meds: 'Current medications', surgeon: 'Surgeon / provider', procedure: 'Procedure', dateUs: 'Visit date' };
export interface Cond { field: string; op: 'eq' | 'neq' | 'checked' | 'filled'; value?: string }
export interface Field { id: string; type: FieldType; name: string; label: string; help?: string; required?: boolean; defaultValue?: string; options?: string[]; width?: 1 | 2 | 3; prefill?: string; cond?: Cond; columns?: string[]; rows?: number; placeholder?: string }
export interface Section { id: string; title: string; columns: 1 | 2 | 3; fields: Field[]; cond?: Cond }
export interface FormDef { title: string; intro?: string; sections: Section[] }
export interface Ver { v: number; def: FormDef; at: string; by: string; note?: string }
export interface LibEntry { file: string; title: string; clonedFrom?: string; versions: Ver[]; published?: number; draft?: FormDef; draftAt?: string; events: { at: string; by: string; what: string }[] }
export const TYPE_LABEL: Record<FieldType, string> = { text: 'Short text', longtext: 'Long text', number: 'Number', date: 'Date', yesno: 'Yes / No', single: 'Single choice', multi: 'Multiple choice', dropdown: 'Dropdown', checkbox: 'Checkbox', signature: 'Signature', initials: 'Initials', grid: 'Table / grid', heading: 'Heading', instruction: 'Instruction text', prefill: 'Prefilled from chart' };

const lib = (): Record<string, Record<string, LibEntry>> => svRead('form-lib', {});
const save = (l: Record<string, Record<string, LibEntry>>) => svWrite('form-lib', l);
export const entries = (pid = PRACTICE_ID) => lib()[pid] || {};
export const entry = (file: string, pid = PRACTICE_ID): LibEntry | undefined => entries(pid)[file];
function put(e: LibEntry, pid = PRACTICE_ID) { const l = lib(); l[pid] = { ...(l[pid] || {}), [e.file]: e }; save(l); }
const audit = (action: 'form.template.save' | 'form.template.publish' | 'form.template.restore' | 'form.template.import' | 'form.template.clone', by: string, role: string, detail: string) => repo.audit({ caseId: 'practice', user: by, role, action, detail });
export const catalog = () => [...VITYLS_FORM_CATALOG.map(f => ({ ...f, clone: false })), ...Object.values(entries()).filter(e => e.clonedFrom && false).map(e => ({ title: e.title, file: e.file, category: 'Practice copy', audience: 'Practice-defined', stage: 'Practice-defined', clone: true }))];
export const titleOf = (file: string) => catalog().find(f => f.file === file)?.title || file.replace(/\.html$/, '').replace(/_/g, ' ');

/* ---------- parse a bundled HTML template into the editable schema ---------- */
const clean = (s: string | null | undefined) => (s || '').replace(/\s+/g, ' ').replace(/\*\s*$/, '').trim();
const slug = (s: string) => s.toLowerCase().replace(/[^a-z0-9]+/g, '_').replace(/^_|_$/g, '').slice(0, 40) || 'field';
export function parseTemplate(html: string, title: string): FormDef {
  const doc = new DOMParser().parseFromString(html || '<body></body>', 'text/html'); const body = doc.body;
  const sections: Section[] = []; let cur: Section | null = null;
  const sec = (t: string) => { cur = { id: uid('s'), title: t, columns: 2, fields: [] }; sections.push(cur); return cur; };
  const ensure = () => cur || sec('General');
  const usedNames = new Set<string>(); const nm = (n: string) => { let b = n || 'field', k = b, i = 2; while (usedNames.has(k)) k = `${b}_${i++}`; usedNames.add(k); return k; };
  const labelFor = (el: Element) => { const id = el.getAttribute('id'); const l = id ? doc.querySelector(`label[for="${CSS.escape(id)}"]`) : null; if (l) return clean(l.textContent);
    const w = el.closest('.form-group,.fg,.field,.form-field,.field-row,.input-group,label,td'); if (w) { const lab = w.querySelector('label'); const t = clean((lab && !lab.contains(el) ? lab.textContent : (w.tagName === 'LABEL' ? w.textContent : lab?.textContent)) || ''); if (t) return t; }
    return clean(el.getAttribute('placeholder') || el.getAttribute('aria-label') || el.getAttribute('name') || ''); };
  const intro = clean(body.querySelector('.compliance-note,.header-block p,.subtitle,.sub')?.textContent).slice(0, 600);
  const seenGroups = new Set<string>(); const seenTables = new Set<Element>();
  const walker = doc.createTreeWalker(body, NodeFilter.SHOW_ELEMENT); let n: Node | null = walker.currentNode;
  while ((n = walker.nextNode())) { const el = n as HTMLElement; const tag = el.tagName; const cls = el.className && typeof el.className === 'string' ? el.className : '';
    if (/\bsv9-instr\b/.test(cls)) { const lab = clean(el.querySelector('b')?.textContent); const all = clean(el.textContent); ensure().fields.push({ id: uid('f'), type: 'instruction', name: nm(slug('note_' + (lab || all.slice(0, 30)))), label: lab, help: (lab && all.startsWith(lab) ? all.slice(lab.length) : all).trim().slice(0, 1600), width: 3 }); continue; }
    if (/section-banner|section-title|section-header|banner/.test(cls) || tag === 'H2' || tag === 'H3' || tag === 'LEGEND') { const t = clean(el.textContent); if (t && t.length < 90 && !el.closest('table')) sec(t); continue; }
    if (tag === 'TABLE' && !seenTables.has(el)) { seenTables.add(el); const ths = Array.from(el.querySelectorAll('thead th, tr:first-child th')).map(x => clean(x.textContent)).filter(Boolean); const rows = Math.max(1, el.querySelectorAll('tbody tr').length - (el.querySelector('thead') ? 0 : 1)); const ctl = el.querySelectorAll('input,select,textarea').length;
      if (ctl && ths.length >= 2) { ensure().fields.push({ id: uid('f'), type: 'grid', name: nm(slug(ths[0] + '_table')), label: clean(el.querySelector('caption')?.textContent) || `${ths.slice(0, 3).join(' / ')} table`, columns: ths, rows: Math.min(rows, 12), width: 3 }); el.querySelectorAll('input,select,textarea').forEach(c => (c as any).__skip = true); }
      continue; }
    if (tag !== 'INPUT' && tag !== 'SELECT' && tag !== 'TEXTAREA') continue; if ((el as any).__skip || el.closest('table')) continue;
    const type = (el.getAttribute('type') || '').toLowerCase(); if (['hidden', 'submit', 'button', 'reset', 'file'].includes(type)) continue;
    const name = el.getAttribute('name') || ''; const label = labelFor(el);
    if (type === 'radio' || type === 'checkbox') { const key = `${type}:${name || label}`; if (name && seenGroups.has(key)) continue;
      const group = name ? Array.from(body.querySelectorAll(`input[name="${CSS.escape(name)}"]`)) : [el];
      const container = el.closest('.checkbox-group,.radio-group,.options,.inline-group,.check-row,.form-group,.fg') || el.parentElement;
      const sibs = type === 'checkbox' && group.length === 1 && container ? Array.from(container.querySelectorAll('input[type=checkbox]')) : group;
      sibs.forEach(s => (s as any).__skip = s !== el ? true : (s as any).__skip); if (name) seenGroups.add(key);
      const opts = sibs.map(s => clean((s.closest('label')?.textContent) || (s as HTMLInputElement).value || '')).filter(Boolean);
      const qLabel = clean(container?.querySelector(':scope > label:not(:has(input))')?.textContent || container?.previousElementSibling?.textContent || '') || label;
      if (sibs.length <= 1) ensure().fields.push({ id: uid('f'), type: 'checkbox', name: nm(slug(name || label)), label: label || 'Checkbox', width: 1 });
      else { const yn = opts.length === 2 && /^yes$/i.test(opts[0]) && /^no$/i.test(opts[1]); ensure().fields.push({ id: uid('f'), type: yn ? 'yesno' : type === 'radio' ? 'single' : 'multi', name: nm(slug(name || qLabel)), label: (qLabel || label || 'Choose').slice(0, 140), options: yn ? undefined : opts.slice(0, 30), width: opts.length > 4 ? 2 : 1 }); }
      continue; }
    const base = { id: uid('f'), name: nm(slug(name || label)), label: (label || 'Field').slice(0, 160), required: el.hasAttribute('required') };
    const nl = `${name} ${label}`.toLowerCase();
    if (tag === 'SELECT') ensure().fields.push({ ...base, type: 'dropdown', options: Array.from(el.querySelectorAll('option')).map(o => clean(o.textContent)).filter(o => o && !/^(select|choose)/i.test(o)), width: 1 });
    else if (tag === 'TEXTAREA') ensure().fields.push({ ...base, type: (el.textContent || '').length > 200 ? 'instruction' : 'longtext', defaultValue: (el.textContent || '').length > 200 ? undefined : clean(el.textContent) || undefined, help: (el.textContent || '').length > 200 ? clean(el.textContent).slice(0, 1200) : undefined, width: 3 });
    else if (/signature|\binitials\b/.test(nl)) { /* v0.10: signatures & initials are captured by the station signer setup, not by form fields */ }
    else ensure().fields.push({ ...base, type: type === 'date' ? 'date' : type === 'number' ? 'number' : 'text', width: 1 });
  }
  sections.forEach(s => { if (s.fields.length && s.fields.every(f => f.type === 'longtext' || f.type === 'instruction' || f.width === 3)) s.columns = 1; });
  return { title, intro: intro || undefined, sections: sections.filter(s => s.fields.length) };
}
/** v0.10: signature / initials fields are not form fields any more; the station's signer setup captures them. */
export const SIG_TYPES = new Set<string>(['signature', 'initials']);
export function stripSignatures(d: FormDef): FormDef { const gone = new Set<string>(); const sections = d.sections.map(s => ({ ...s, fields: s.fields.filter(f => { if (SIG_TYPES.has(f.type)) { gone.add(f.name); return false; } return true; }) }));
  sections.forEach(s => { if (s.cond && gone.has(s.cond.field)) s.cond = undefined; s.fields.forEach(f => { if (f.cond && gone.has(f.cond.field)) f.cond = undefined; }); });
  return gone.size ? { ...d, sections: sections.filter(s => s.fields.length) } : d; }
export const originalDef = (file: string): FormDef => parseTemplate(getBundledFormHtml(file), titleOf(file));
export const workingDef = (file: string): FormDef => { const e = entry(file); if (e?.draft) return stripSignatures(e.draft); if (e?.published) return stripSignatures(e.versions.find(v => v.v === e.published)!.def); return originalDef(file); };
export type Status = 'original' | 'draft' | 'published';
export const statusOf = (file: string): { s: Status; v?: number; draft: boolean } => { const e = entry(file); return { s: e?.published ? 'published' : e?.draft ? 'draft' : 'original', v: e?.published, draft: !!e?.draft }; };

/* ---------- lifecycle ---------- */
const blank = (file: string, title: string, clonedFrom?: string): LibEntry => ({ file, title, clonedFrom, versions: [], events: [] });
export function saveDraft(file: string, def: FormDef, by: string, role: string) { const e = entry(file) || blank(file, def.title); const at = new Date().toISOString(); put({ ...e, title: def.title, draft: def, draftAt: at, events: [...e.events, { at, by, what: 'Draft saved' }] }); audit('form.template.save', by, role, `Form template draft saved: ${def.title} (${file})`); }
export function publish(file: string, def: FormDef, by: string, role: string, note?: string) { const e = entry(file) || blank(file, def.title); const v = (e.versions[e.versions.length - 1]?.v || 0) + 1; const at = new Date().toISOString();
  def = stripSignatures(def); put({ ...e, title: def.title, versions: [...e.versions, { v, def, at, by, note }], published: v, draft: undefined, draftAt: undefined, events: [...e.events, { at, by, what: `Published v${v}${note ? ` · ${note}` : ''}` }] }); audit('form.template.publish', by, role, `Form template published: ${def.title} v${v} (${file}). Forms already started keep their version.`); return v; }
export function discardDraft(file: string, by: string) { const e = entry(file); if (!e) return; put({ ...e, draft: undefined, draftAt: undefined, events: [...e.events, { at: new Date().toISOString(), by, what: 'Draft discarded' }] }); }
export function restoreOriginal(file: string, by: string, role: string) { const e = entry(file); if (!e) return; put({ ...e, published: undefined, draft: undefined, events: [...e.events, { at: new Date().toISOString(), by, what: 'Restored the original template (versions kept)' }] }); audit('form.template.restore', by, role, `Form template restored to the original: ${e.title} (${file}); ${e.versions.length} practice version(s) kept`); }
export function republish(file: string, v: number, by: string, role: string) { const e = entry(file); const ver = e?.versions.find(x => x.v === v); if (!e || !ver) return; publish(file, ver.def, by, role, `restored from v${v}`); }
export function cloneTemplate(file: string, by: string, role: string): string { const def = workingDef(file); const nf = `practice-${uid('form')}.html`; const title = `${def.title} (practice copy)`; put({ ...blank(nf, title, file), draft: { ...def, title }, draftAt: new Date().toISOString(), events: [{ at: new Date().toISOString(), by, what: `Cloned from ${titleOf(file)}` }] }); audit('form.template.clone', by, role, `Form template cloned: ${titleOf(file)} → ${title}`); return nf; }
export function exportJson(file: string, def: FormDef) { return JSON.stringify({ format: 'vityls-form-template', version: 1, file, exportedAt: new Date().toISOString(), def }, null, 2); }
export function importJson(text: string): FormDef { const j = JSON.parse(text); const d: FormDef = j.def || j; if (!d || !Array.isArray(d.sections) || typeof d.title !== 'string') throw new Error('Not a Vityls form template (needs title and sections).');
  d.sections.forEach(s => { if (!Array.isArray(s.fields)) throw new Error(`Section “${s.title}” has no fields list.`); s.id = s.id || uid('s'); s.columns = ([1, 2, 3].includes(s.columns) ? s.columns : 2) as any; s.fields.forEach(f => { f.id = f.id || uid('f'); if (!TYPE_LABEL[f.type]) throw new Error(`Unknown field type “${f.type}”.`); f.name = f.name || slug(f.label); }); }); return stripSignatures(d); }
export const logImport = (file: string, by: string, role: string) => audit('form.template.import', by, role, `Form template imported from JSON into the draft of ${titleOf(file)}`);

/* ---------- render to HTML (same classes the bundled templates use, so the form engine treats it the same) ---------- */
const esc = (s: string) => String(s ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
const condAttr = (c?: Cond) => c?.field ? ` data-show-if="${esc(JSON.stringify(c))}"` : '';
function fieldHtml(f: Field): string {
  const req = f.required ? ' required' : ''; const lab = `<label>${esc(f.label)}${f.required ? ' <span class="sv9-req">*</span>' : ''}</label>`; const help = f.help && f.type !== 'instruction' ? `<div class="sv9-help">${esc(f.help)}</div>` : '';
  const dv = f.defaultValue ? ` value="${esc(f.defaultValue)}"` : ''; const ph = f.placeholder ? ` placeholder="${esc(f.placeholder)}"` : '';
  const wrap = (inner: string, extra = '') => `<div class="form-group sv9-f w${f.width || 1}${extra}" data-field="${esc(f.name)}"${condAttr(f.cond)}>${inner}</div>`;
  const choices = (t: 'radio' | 'checkbox', opts: string[]) => `<div class="sv9-opts">${opts.map(o => `<label class="sv9-opt"><input type="${t}" name="${esc(f.name)}" value="${esc(o)}"${f.defaultValue === o ? ' checked' : ''}${t === 'radio' ? req : ''}> ${esc(o)}</label>`).join('')}</div>`;
  switch (f.type) {
    case 'heading': return `<div class="sv9-subhead w3"${condAttr(f.cond)}>${esc(f.label)}</div>`;
    case 'instruction': return `<div class="sv9-instr w3"${condAttr(f.cond)}>${f.label ? `<b>${esc(f.label)}</b> ` : ''}${esc(f.help || '')}</div>`;
    case 'longtext': return wrap(`${lab}<textarea name="${esc(f.name)}" rows="4"${req}${ph}>${esc(f.defaultValue || '')}</textarea>${help}`);
    case 'number': return wrap(`${lab}<input type="number" name="${esc(f.name)}"${dv}${req}${ph}>${help}`);
    case 'date': return wrap(`${lab}<input type="date" name="${esc(f.name)}"${dv}${req}>${help}`);
    case 'yesno': return wrap(`${lab}${choices('radio', ['Yes', 'No'])}${help}`);
    case 'single': return wrap(`${lab}${choices('radio', f.options || [])}${help}`);
    case 'multi': return wrap(`${lab}${choices('checkbox', f.options || [])}${help}`);
    case 'dropdown': return wrap(`${lab}<select name="${esc(f.name)}"${req}><option value="">Choose…</option>${(f.options || []).map(o => `<option${f.defaultValue === o ? ' selected' : ''}>${esc(o)}</option>`).join('')}</select>${help}`);
    case 'checkbox': return wrap(`<label class="sv9-opt"><input type="checkbox" name="${esc(f.name)}" value="Yes"${f.defaultValue === 'Yes' ? ' checked' : ''}${req}> ${esc(f.label)}${f.required ? ' <span class="sv9-req">*</span>' : ''}</label>${help}`);
    case 'signature': return wrap(`${lab}<input type="text" class="sv9-sig" name="${esc(f.name)}" placeholder="Type full name to sign"${req}><div class="sv9-sigline"></div>${help}`);
    case 'initials': return wrap(`${lab}<input type="text" class="sv9-init" name="${esc(f.name)}" maxlength="4" placeholder="Initials"${req}>${help}`);
    case 'grid': { const cols = f.columns?.length ? f.columns : ['Item', 'Details']; return wrap(`${lab}<table class="sv9-grid-t"><thead><tr>${cols.map(c => `<th>${esc(c)}</th>`).join('')}</tr></thead><tbody>${Array.from({ length: f.rows || 3 }, (_, r) => `<tr>${cols.map((_, c) => `<td><input type="text" name="${esc(f.name)}_r${r + 1}_c${c + 1}" aria-label="${esc(cols[c])} row ${r + 1}"></td>`).join('')}</tr>`).join('')}</tbody></table>${help}`, ' sv9-gridf'); }
    case 'prefill': return wrap(`${lab}<input type="text" name="${esc(f.name)}" data-prefill="${esc(f.prefill || 'patientName')}"${req}>${help}`);
    default: return wrap(`${lab}<input type="text" name="${esc(f.name)}"${dv}${req}${ph}>${help}`);
  }
}
export function renderHtml(def: FormDef): string {
  return `<!doctype html><html><head><style>${GEN_CSS}</style></head><body><div class="packet-container sv9-gen"><div class="header-block"><h1>${esc(def.title)}</h1>${def.intro ? `<p class="compliance-note">${esc(def.intro)}</p>` : ''}</div>${def.sections.map(s => `<div class="sv9-sec"${condAttr(s.cond)}><div class="section-banner">${esc(s.title)}</div><div class="sv9-grid c${s.columns}">${s.fields.map(fieldHtml).join('')}</div></div>`).join('')}</div></body></html>`;
}
const GEN_CSS = `.sv9-grid{display:grid;gap:10px 16px;margin:8px 0 16px}.sv9-grid.c1{grid-template-columns:1fr}.sv9-grid.c2{grid-template-columns:repeat(2,minmax(0,1fr))}.sv9-grid.c3{grid-template-columns:repeat(3,minmax(0,1fr))}
.sv9-grid.c2 .w2,.sv9-grid.c2 .w3,.sv9-grid.c3 .w3{grid-column:1/-1}.sv9-grid.c3 .w2{grid-column:span 2}
@media(max-width:640px){.sv9-grid.c2,.sv9-grid.c3{grid-template-columns:1fr}.sv9-grid .w2,.sv9-grid .w3{grid-column:auto}}
.sv9-f label{display:block;font-size:12.5px;font-weight:600;margin-bottom:4px}.sv9-f input[type=text],.sv9-f input[type=number],.sv9-f input[type=date],.sv9-f select,.sv9-f textarea{width:100%;box-sizing:border-box;border:1px solid #cfd5ce;border-radius:3px;padding:8px 10px;font:inherit;min-height:40px}
.sv9-opts{display:flex;flex-wrap:wrap;gap:6px 16px}.sv9-opt{display:inline-flex!important;align-items:center;gap:6px;font-weight:400!important;font-size:14px!important;min-height:36px}
.sv9-help{font-size:12px;color:#55645f;margin-top:3px}.sv9-req{color:#b23b32}.sv9-subhead{font-weight:700;font-size:14px;margin-top:6px}.sv9-instr{font-size:13px;color:#2a3530;background:#f6f7f4;border:1px solid #e2e6e1;border-radius:3px;padding:8px 10px;white-space:pre-wrap}
.sv9-sigline{border-bottom:1px solid #16211f;height:4px;margin-top:2px}.sv9-sig{font-style:italic}.sv9-init{max-width:90px}
.sv9-grid-t{width:100%;border-collapse:collapse}.sv9-grid-t th{font-size:11px;text-align:left;color:#55645f;border-bottom:1px solid #cfd5ce;padding:4px}.sv9-grid-t td{padding:3px}.sv9-grid-t input{width:100%;box-sizing:border-box;border:1px solid #e2e6e1;border-radius:3px;padding:6px}
.sv9-hidden{display:none!important}`;

/* ---------- which HTML a patient's form opens with (version pinning) ---------- */
const pins = () => svRead<Record<string, number | 'orig'>>('form-pins', {});
export function htmlFor(file: string, patientId?: string): string | undefined {
  const e = entry(file); if (!e) return undefined;
  const pub = e.published ? e.versions.find(v => v.v === e.published) : undefined;
  if (!patientId) return pub ? renderHtml(pub.def) : undefined;
  const key = `${patientId}|${file}`; const all = pins(); let pin = all[key];
  if (pin === undefined) { const rec = repo.getForm(patientId, file); const started = rec && rec.status && rec.status !== 'not-started'; pin = started ? 'orig' : (pub ? pub.v : 'orig'); if (started || pub) { svWrite('form-pins', { ...all, [key]: pin }); } }
  if (pin === 'orig') return undefined; const ver = e.versions.find(v => v.v === pin); return ver ? renderHtml(ver.def) : undefined;
}
export const pinnedVersion = (file: string, patientId: string) => pins()[`${patientId}|${file}`];
