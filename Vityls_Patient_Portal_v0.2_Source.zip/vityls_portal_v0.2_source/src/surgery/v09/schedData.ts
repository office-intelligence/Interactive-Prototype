/* v0.9 scheduler data: schedulable columns (people + rooms) and office-wide events. Surgery namespace, audited. */
import { repo } from '../../v6/dataLayer';
import { uid, addDays } from '../../med/record';
import { getProviders, displayName } from '../../v7/providers';
import { MED_ROOMS } from '../../med/seed';
import { staffList } from '../staff';
import { svRead, svWrite } from '../store';

export interface SchedResource { id: string; kind: 'person' | 'room'; name: string; role: string; schedulable: boolean; custom?: boolean }
export function resources(): SchedResource[] {
  const saved = svRead<SchedResource[] | null>('sched-resources', null); if (saved) return saved;
  const prov = getProviders().filter(p => p.active).map(p => ({ id: `r-${p.id}`, kind: 'person' as const, name: displayName(p), role: p.role as string, schedulable: true }));
  const team = staffList().filter(s => s.active && ['RN', 'Medical assistant', 'Surgical Coordinator', 'Care Coordinator'].includes(s.role)).map(s => ({ id: `r-${s.id}`, kind: 'person' as const, name: s.name, role: s.role, schedulable: true }));
  const rooms = MED_ROOMS.map(r => ({ id: `r-room-${r.replace(/\W+/g, '-').toLowerCase()}`, kind: 'room' as const, name: r, role: 'Room', schedulable: true }));
  return [...prov, ...team, ...rooms];
}
export function saveResources(l: SchedResource[], by: string, role: string, what: string) { svWrite('sched-resources', l); repo.audit({ caseId: 'practice', user: by, role, action: 'schedule.columns', detail: what }); }
export const bookable = () => resources().filter(r => r.schedulable);

export type Recur = 'none' | 'daily' | 'weekly' | 'monthly';
export interface OfficeEvent { id: string; title: string; kind: string; date: string; start: string; end: string; allDay: boolean; recur: Recur; until?: string; notes?: string; createdBy: string; createdAt: string }
export const EVENT_KINDS = ['Staff meeting', 'In-service / training', 'Luncheon', 'Office closed', 'Holiday', 'Other'];
const all = () => svRead<OfficeEvent[]>('office-events', []);
export const officeEvents = all;
export function saveEvent(e: OfficeEvent, by: string, role: string, isNew: boolean) { svWrite('office-events', [...all().filter(x => x.id !== e.id), e]); repo.audit({ caseId: 'practice', user: by, role, action: 'schedule.event', detail: `${isNew ? 'Office event added' : 'Office event edited'}: ${e.title} · ${e.date}${e.allDay ? ' all day' : ` ${e.start}–${e.end}`}${e.recur !== 'none' ? ` · repeats ${e.recur}${e.until ? ` until ${e.until}` : ''}` : ''}` }); }
export function deleteEvent(e: OfficeEvent, by: string, role: string) { svWrite('office-events', all().filter(x => x.id !== e.id)); repo.audit({ caseId: 'practice', user: by, role, action: 'schedule.event', detail: `Office event deleted: ${e.title} (${e.date})` }); }
export function occursOn(e: OfficeEvent, day: string) {
  if (day < e.date || (e.until && day > e.until)) return false; if (day === e.date) return true;
  const a = new Date(e.date + 'T12:00'), b = new Date(day + 'T12:00');
  if (e.recur === 'daily') return b.getDay() !== 0 && b.getDay() !== 6;
  if (e.recur === 'weekly') return a.getDay() === b.getDay();
  if (e.recur === 'monthly') return a.getDate() === b.getDate();
  return false;
}
export const eventsOn = (day: string) => all().filter(e => occursOn(e, day));
export const newEvent = (date: string, by: string): OfficeEvent => ({ id: uid('ev'), title: 'Staff meeting', kind: 'Staff meeting', date, start: '12:00 PM', end: '01:00 PM', allDay: false, recur: 'none', createdBy: by, createdAt: new Date().toISOString() });
export const weekStart = (d: string) => { const x = new Date(d + 'T12:00'); const dow = (x.getDay() + 6) % 7; return addDays(d, -dow); };
