/* Send Request to ASC (v0.2): scheduling form + document picker + facility dropdown, signed with the sender's PIN. */
import React, { useMemo, useState } from 'react';
import { MedVisit, MedPatient, usDate, isoDay, fmtDateTime } from '../med/record';
import { setSharingConsent } from '../med/network';
import { getProviders, displayName } from '../v7/providers';
import { PROVIDER_ROLES } from '../med/record';
import { useActor, useMedTick } from '../med/ui';
import { ascBlocks } from './store';
import { ascFacilities, availableDocs, defaultForm, sendPacket, ascPackets, receivePending, SchedulingForm, AscPacket } from './asc';
import { PinSign } from './sign';
import { ROLE_GROUP } from './staff';
import { Ico } from './icons';
import { useSv } from './ui';
import { R } from './nightingale';

const DOC_ICON: Record<string, string> = { note: 'note', clearance: 'document', lab: 'lab', vitals: 'vitals', meds: 'meds', allergy: 'allergy', problems: 'problems', history: 'surgery', form: 'form', nurse: 'form', intake: 'form', scribe: 'note' };

export const SendToAsc: React.FC<{ v: MedVisit; p: MedPatient; onSent?: (pk: AscPacket) => void; onClose?: () => void }> = ({ v, p, onSent, onClose }) => {
  useMedTick(); receivePending(); const [actor] = useActor(); const { toast, openPanel } = useSv();
  const facs = ascFacilities().filter(f => f.active);
  const surgeons = getProviders().filter(x => x.active && PROVIDER_ROLES.includes(x.role as string)).map(x => displayName(x));
  const [facId, setFacId] = useState(facs[0]?.id || ''); const fac = facs.find(f => f.id === facId);
  const [surgeon, setSurgeon] = useState(surgeons.includes(v.provider) ? v.provider : surgeons[0] || v.provider);
  const [f, setF] = useState<SchedulingForm>(() => defaultForm(p, v, v.provider));
  const docs = useMemo(() => availableDocs(p, v), [p, v]);
  const [pick, setPick] = useState<string[]>(() => docs.filter(d => d.recommended).map(d => d.id));
  const [consent, setConsent] = useState(!!p.recordSharingConsent?.granted); const [sign, setSign] = useState(false);
  const blocks = fac?.primary ? ascBlocks().filter(b => b.surgeon.replace(/,.*$/, '') === surgeon.replace(/,.*$/, '') && b.date >= isoDay()).sort((a, b) => a.date.localeCompare(b.date)) : [];
  const blk = blocks.find(b => b.id === f.blockId);
  const S = <K extends keyof SchedulingForm>(k: K) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => setF({ ...f, [k]: (k === 'durationMin' ? +e.target.value.replace(/\D/g, '') || 0 : e.target.value) as SchedulingForm[K] });
  const check = () => { if (!fac) return 'Choose the surgery center.'; if (!f.procedure.trim()) return 'Enter the procedure.'; if (!blk && !f.preferredDate) return 'Choose block time or a preferred date.'; if (pick.length && !consent) return 'Record the patient’s consent to share records with the surgery center.'; return ''; };
  const trySend = () => { const e = check(); if (e) { toast(e); return; } setSign(true); };
  const doSend = (w: { name: string; role: string }) => {
    try {
      if (pick.length && !p.recordSharingConsent?.granted) setSharingConsent(p, true, w.name, w.role, `Records for surgery scheduling at ${fac!.name}`);
      const pk = sendPacket({ p, v, facility: fac!, surgeon, form: f, docs: docs.filter(d => pick.includes(d.id)), date: blk?.date || f.preferredDate, time: blk?.start || f.preferredTime, room: blk?.room || '', by: w.name, role: w.role });
      setSign(false); toast(`Sent to ${fac!.name.replace(/\s*\(.*\)/, '')} (simulated). Waiting for the ASC…`); onSent?.(pk);
    } catch (err) { setSign(false); toast((err as Error).message); }
  };
  return <div className="sv-send" data-testid="send-to-asc">
    <div className="flex flex-wrap items-center gap-2 mb-2"><Ico k="send" size={16} /><h2 className="sv-h !m-0">Send request to ASC · scheduling form, documents and notes</h2>{onClose && <button type="button" className="sv-link text-[12.5px] ml-auto" onClick={onClose}>Close</button>}</div>
    <div className="sv-send-grid">
      <section data-testid="asc-form">
        <div className="grid gap-2" style={{ gridTemplateColumns: 'repeat(auto-fill,minmax(170px,1fr))' }}>
          <label style={{ gridColumn: '1/-1' }}><span className="sv-label">Surgery center (ASC)</span><select className="sv-input" value={facId} onChange={e => { setFacId(e.target.value); setF({ ...f, blockId: '' }); }} data-testid="asc-facility">{facs.map(x => <option key={x.id} value={x.id}>{x.name} · {x.city}</option>)}</select></label>
          <label><span className="sv-label">Surgeon</span><select className="sv-input" value={surgeon} onChange={e => { setSurgeon(e.target.value); setF({ ...f, blockId: '' }); }} data-testid="asc-surgeon">{surgeons.map(s => <option key={s} value={s}>{s}</option>)}</select></label>
          <label style={{ gridColumn: 'span 2' }}><span className="sv-label">Procedure</span><input className="sv-input" value={f.procedure} onChange={S('procedure')} data-testid="asc-proc" /></label>
          <label><span className="sv-label">CPT (optional)</span><input className="sv-input" value={f.cpt} onChange={S('cpt')} /></label>
          <label style={{ gridColumn: 'span 2' }}><span className="sv-label">Diagnosis</span><input className="sv-input" value={f.diagnosis} onChange={S('diagnosis')} data-testid="asc-dx" /></label>
          <label><span className="sv-label">ICD-10 (optional)</span><input className="sv-input" value={f.icd10} onChange={S('icd10')} /></label>
          <label><span className="sv-label">Laterality</span><select className="sv-input" value={f.laterality} onChange={S('laterality')}>{['N/A', 'Left', 'Right', 'Bilateral'].map(x => <option key={x}>{x}</option>)}</select></label>
          <label><span className="sv-label">Anesthesia requested</span><select className="sv-input" value={f.anesthesia} onChange={S('anesthesia')} data-testid="asc-anesthesia">{['General', 'MAC / sedation', 'Regional', 'Local', 'Surgeon to discuss'].map(x => <option key={x}>{x}</option>)}</select></label>
          <label><span className="sv-label">Est. minutes</span><input className="sv-input" inputMode="numeric" value={f.durationMin || ''} onChange={S('durationMin')} /></label>
          <label><span className="sv-label">Admission</span><select className="sv-input" value={f.admission} onChange={S('admission')}>{['Outpatient (same day)', '23-hour observation'].map(x => <option key={x}>{x}</option>)}</select></label>
          <label style={{ gridColumn: '1/-1' }}><span className="sv-label">{surgeon.replace(/,.*$/, '')}’s block time at this ASC</span><select className="sv-input" value={f.blockId} onChange={S('blockId')} data-testid="asc-block"><option value="">{blocks.length ? 'Choose block time… (or a preferred date below)' : 'No published block time here · use a preferred date'}</option>{blocks.map(b => <option key={b.id} value={b.id}>{usDate(b.date)} · {b.start}–{b.end} · {b.room}</option>)}</select></label>
          {!blk && <><label><span className="sv-label">Preferred date</span><input type="date" className="sv-input" value={f.preferredDate} min={isoDay()} onChange={S('preferredDate')} data-testid="asc-date" /></label><label><span className="sv-label">Preferred time</span><input className="sv-input" placeholder="07:30 AM" value={f.preferredTime} onChange={S('preferredTime')} /></label></>}
          <label style={{ gridColumn: 'span 2' }}><span className="sv-label">Equipment / instruments</span><input className="sv-input" value={f.equipment} onChange={S('equipment')} /></label>
          <label><span className="sv-label">Implants</span><input className="sv-input" value={f.implants} onChange={S('implants')} /></label>
          <label style={{ gridColumn: '1/-1' }}><span className="sv-label">Special needs (interpreter, mobility, etc.)</span><input className="sv-input" value={f.specialNeeds} onChange={S('specialNeeds')} /></label>
          <div style={{ gridColumn: '1/-1' }} className="text-[13px]"><b className="sv-label !inline">Allergies (from chart): </b><span className={/nkda|no known/i.test(f.allergies) ? '' : 'text-[var(--crit)]'}>{f.allergies}</span>{f.latexAllergy && <span className="sv-tag warn ml-2">Latex</span>}</div>
          <label style={{ gridColumn: '1/-1' }}><span className="sv-label">Note to the ASC scheduler</span><textarea className="sv-input" rows={2} value={f.notes} onChange={S('notes')} data-testid="asc-notes" /></label>
        </div>
      </section>
      <section data-testid="asc-docs">
        <div className="flex items-baseline gap-2"><span className="sv-label !m-0">Supporting documents to include</span><span className="sv-muted text-[12px] ml-auto">{pick.length} of {docs.length}</span></div>
        <div className="flex gap-3 text-[12px] my-1"><button type="button" className="sv-link" onClick={() => setPick(docs.filter(d => d.recommended).map(d => d.id))}>Recommended</button><button type="button" className="sv-link" onClick={() => setPick(docs.map(d => d.id))}>All</button><button type="button" className="sv-link" onClick={() => setPick([])}>None</button></div>
        <ul className="sv-docpick">{docs.map(d => <li key={d.id}><label><input type="checkbox" checked={pick.includes(d.id)} onChange={e => setPick(e.target.checked ? [...pick, d.id] : pick.filter(x => x !== d.id))} data-testid="asc-doc" data-doc={d.id} /><Ico k={DOC_ICON[d.kind] || 'document'} /><span className="min-w-0"><span className="block">{d.title}</span><span className="block sv-muted text-[11.5px]">{d.detail}</span></span></label></li>)}</ul>
        {!p.recordSharingConsent?.granted && pick.length > 0 && <label className="flex gap-2 items-start text-[13px] mt-2"><input type="checkbox" checked={consent} onChange={e => setConsent(e.target.checked)} data-testid="asc-consent" /><span>The patient agreed to share these records with {fac?.name.replace(/\s*\(.*\)/, '') || 'the surgery center'} for scheduling and care.</span></label>}
        <button type="button" className="sv-btn primary w-full mt-3" onClick={trySend} data-testid="asc-send">Send to {fac?.name.replace(/\s*\(.*\)/, '') || 'ASC'} · form + {pick.length} document{pick.length === 1 ? '' : 's'}</button>
        <p className="text-[11.5px] sv-muted mt-1">You sign with your PIN. Simulated: nothing leaves this browser; the ASC’s “received” reply is automatic.</p>
      </section>
    </div>
    {sign && <PinSign title={`Send to ${fac?.name.replace(/\s*\(.*\)/, '')}`} statement={<>I am sending the scheduling form for <b>{f.procedure}</b> and {pick.length} supporting document{pick.length === 1 ? '' : 's'} for {p.name} to {fac?.name}.</>} roles={ROLE_GROUP.billing} confirmLabel="Sign & send" onClose={() => setSign(false)} onSigned={doSend} />}
  </div>;
};

/* What was sent from this visit and whether the ASC has received it (simulated). */
export const AscSentList: React.FC<{ v: MedVisit; p: MedPatient }> = ({ v, p }) => {
  useMedTick(); receivePending(); const { openPanel } = useSv(); const sent = ascPackets(p.id).filter(x => x.visitId === v.id).slice().reverse();
  if (!sent.length) return null;
  return <div className="mt-3" data-testid="asc-sent"><h2 className="sv-h">Sent to ASC</h2>{sent.map(pk => <div key={pk.id} className="flex flex-wrap items-center gap-2 text-[13px] py-1.5 border-t border-[var(--line)]"><Ico k="asc" /><b>{pk.facilityName.replace(/\s*\(.*\)/, '')}</b><span>{pk.form.procedure} · {pk.form.preferredDate ? usDate(pk.form.preferredDate) : 'block time'}</span>{pk.status === 'received' ? <span className="sv-tag ok" data-testid="asc-received">✓ Received by ASC · added to ASC chart {pk.ascChartId}</span> : <span className="sv-tag warn" data-testid="asc-waiting">Sent · waiting for the ASC…</span>}<span className="sv-muted text-[12px]">{pk.sentBy} · {fmtDateTime(pk.sentAt)} · form + {pk.docs.length} doc(s)</span><button type="button" className="sv-link text-[12px] ml-auto" onClick={() => openPanel(R('ascchart', 'Sent to ASC', p.id))} data-testid="asc-view-chart">View in ASC chart</button></div>)}</div>;
};
