/* v0.10 · Surgery.Vityls workflow stations (4). Keys reuse the shared WorkflowKey storage so existing assignments carry over:
 *   patientPortal → Portal / At-home · frontOffice → Front desk (check-in AND checkout) · nursing → Nursing · surgeon → Doctor.
 *   ASC-only keys (anesthesia, orTeam, pacu) are never shown in Surgery; any old assignment there is folded into the closest
 *   Surgery station by migrateSurgeryStations() (anesthesia → Doctor, orTeam/pacu → Nursing). */
import type { WorkflowKey } from '../../data/formWorkspaceCatalog';
import { workflowStorageKey } from '../../data/formWorkspaceCatalog';
import { svRead, svWrite } from '../store';
export const SURGERY_WORKFLOWS: { key: WorkflowKey; label: string; note: string }[] = [
  { key: 'patientPortal', label: 'Portal / At-home', note: 'Forms the patient completes at home or in the portal before the visit.' },
  { key: 'frontOffice', label: 'Front desk', note: 'Check-in and checkout: registration, insurance, consents for photos, payment.' },
  { key: 'nursing', label: 'Nursing', note: 'Nurse intake: medical history review, vitals and nursing forms.' },
  { key: 'surgeon', label: 'Doctor', note: 'Surgeon / physician visit: procedure consents and provider documentation.' }];
export const SURGERY_STATION_LABEL: Record<string, string> = { patientPortal: 'Portal / At-home', frontOffice: 'Front desk', nursing: 'Nursing', surgeon: 'Doctor' };
const FOLD: Partial<Record<WorkflowKey, WorkflowKey>> = { anesthesia: 'surgeon', orTeam: 'nursing', pacu: 'nursing' };
export function migrateSurgeryStations() {
  if (svRead<boolean>('stations-v010', false)) return; let moved = 0;
  try { for (let i = 0; i < localStorage.length; i++) { const k = localStorage.key(i)!; if (!k.startsWith(workflowStorageKey(''))) continue; const raw = JSON.parse(localStorage.getItem(k) || 'null'); if (!raw) continue;
    (Object.keys(FOLD) as WorkflowKey[]).forEach(a => { if (raw[a]?.enabled) { raw[FOLD[a]!] = { enabled: true }; raw[a] = { enabled: false }; moved++; } }); localStorage.setItem(k, JSON.stringify(raw)); } } catch { /* ignore */ }
  svWrite('stations-v010', true); return moved;
}
