/* v0.10: free appointment length. Duration in minutes (any value, 5-min stepper) and End time, kept in sync. */
import React, { useEffect, useState } from 'react';
import { toMin } from '../../med/record';
const TIME = /^\d{1,2}:\d{2}\s?(AM|PM)$/i;
const fmt = (m: number) => { m = ((m % 1440) + 1440) % 1440; const h = Math.floor(m / 60), mm = m % 60; return `${String(((h + 11) % 12) + 1).padStart(2, '0')}:${String(mm).padStart(2, '0')} ${h < 12 ? 'AM' : 'PM'}`; };
export const endOf = (start: string, dur: number) => TIME.test(start.trim()) ? fmt(+toMin(start.trim().toUpperCase()) + dur) : '';
export const VisitLength: React.FC<{ start: string; duration: number; onChange: (min: number) => void; disabled?: boolean; prefix: string }> = ({ start, duration, onChange, disabled, prefix }) => {
  const [d, setD] = useState(String(duration)); const [end, setEnd] = useState(endOf(start, duration)); const [err, setErr] = useState('');
  useEffect(() => { setD(String(duration)); setEnd(endOf(start, duration)); }, [start, duration]);
  const setDur = (n: number) => { if (!Number.isFinite(n) || n < 1 || n > 720) { setErr('Length must be 1–720 minutes.'); return; } setErr(''); onChange(Math.round(n)); };
  const onEnd = () => { if (!TIME.test(end.trim()) || !TIME.test(start.trim())) { setErr('End time must look like 10:15 AM.'); return; } const n = +toMin(end.trim().toUpperCase()) - +toMin(start.trim().toUpperCase()); if (n <= 0) { setErr('End time must be after the start.'); return; } setDur(n); };
  return <><label><span className="sv-label">Length (minutes)</span><span className="flex items-center gap-1">
      <button type="button" className="sv-btn sm" disabled={disabled || duration <= 5} onClick={() => setDur(Math.max(5, Math.ceil(duration / 5) * 5 - 5))} aria-label="5 minutes shorter" data-testid={`${prefix}-len-minus`}>−5</button>
      <input type="number" min={1} max={720} step={5} inputMode="numeric" className="sv-input" style={{ width: 90 }} disabled={disabled} value={d} onChange={e => { setD(e.target.value); if (e.target.value) setDur(+e.target.value); }} data-testid={`${prefix}-duration`} />
      <button type="button" className="sv-btn sm" disabled={disabled} onClick={() => setDur(Math.floor(duration / 5) * 5 + 5)} aria-label="5 minutes longer" data-testid={`${prefix}-len-plus`}>+5</button></span></label>
    <label><span className="sv-label">End time</span><input className="sv-input" disabled={disabled} value={end} onChange={e => setEnd(e.target.value)} onBlur={onEnd} onKeyDown={e => { if (e.key === 'Enter') onEnd(); }} data-testid={`${prefix}-end`} /></label>
    {err && <p className="text-[12.5px] text-[var(--crit)] sm:col-span-2" role="alert">{err}</p>}</>;
};
