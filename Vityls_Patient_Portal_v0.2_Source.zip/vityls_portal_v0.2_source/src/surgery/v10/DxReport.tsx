/* v0.10 · Practice › Reports › Diagnoses & procedures: count by diagnosis, performed vs not performed, drill-down, print, CSV. */
import React, { useState } from 'react';
import { ageFrom, usDate } from '../../med/record';
import { useSv } from '../ui';
import { dxPairs, csv, downloadCsv, DX_STATUS_LABEL, DxStatus } from './dx';
export const DxReport: React.FC = () => {
  const { go } = useSv(); const [open, setOpen] = useState<{ dx: string; st?: DxStatus } | null>(null);
  const rows = dxPairs().map(r => ({ p: r.p, d: { diagnosis: r.d.diagnosis, icd: r.d.icd, status: (r.performed ? 'performed' : 'planned') as DxStatus, procedure: r.d.procedures.map(x => x.name).join('; '), date: r.d.procedures.filter(x => x.status === 'performed').map(x => x.date).filter(Boolean).sort().pop() } })); const m = new Map<string, { perf: number; plan: number }>();
  rows.forEach(({ d }) => { const x = m.get(d!.diagnosis) || { perf: 0, plan: 0 }; d!.status === 'performed' ? x.perf++ : x.plan++; m.set(d!.diagnosis, x); });
  const g = [...m.entries()].sort((a, b) => (b[1].perf + b[1].plan) - (a[1].perf + a[1].plan) || a[0].localeCompare(b[0]));
  const tot = g.reduce((a, [, x]) => ({ perf: a.perf + x.perf, plan: a.plan + x.plan }), { perf: 0, plan: 0 });
  const drill = open ? rows.filter(r => r.d!.diagnosis === open.dx && (!open.st || r.d!.status === open.st)) : [];
  const exportCsv = () => downloadCsv(`Diagnoses-procedures-${new Date().toISOString().slice(0, 10)}.csv`, csv([['Diagnosis / condition', 'Performed', 'Not performed', 'Total'], ...g.map(([k, x]) => [k, x.perf, x.plan, x.perf + x.plan]), ['Total', tot.perf, tot.plan, tot.perf + tot.plan], [], ['Patient', 'MRN', 'DOB', 'Diagnosis / condition', 'ICD-10', 'Procedure(s)', 'Status', 'Date performed'], ...rows.map(({ p, d }) => [p.name, p.id, p.dob, d!.diagnosis, d!.icd || '', d!.procedure, DX_STATUS_LABEL[d!.status], d!.date || ''])]));
  const N = (dx: string, st: DxStatus | undefined, n: number) => n ? <button type="button" className="sv-link" onClick={() => setOpen({ dx, st })} data-testid="dx-drill">{n}</button> : <span className="sv-muted">0</span>;
  return <section className="sv-report" data-testid="report-view"><div data-testid="dx-report">
    <div className="flex items-center gap-3 flex-wrap"><h3 className="sv-h">Diagnoses &amp; procedures</h3><span className="sv-small sv-muted">{new Set(rows.map(r => r.p.id)).size} patients · {rows.length} diagnoses · fictional data</span>
      <button type="button" className="sv-btn sm ml-auto" onClick={exportCsv} data-testid="dx-csv">Export CSV</button><button type="button" className="sv-btn sm" onClick={() => window.print()} data-testid="dx-print">Print</button></div>
    <table className="sv-table text-[13px] mt-2"><thead><tr><th>Diagnosis / condition</th><th className="text-right">Performed</th><th className="text-right">Not performed</th><th className="text-right">Total</th><th style={{ width: 140 }} /></tr></thead><tbody>
      {g.map(([k, x]) => <tr key={k} data-testid="dx-row"><td>{k}</td><td className="text-right">{N(k, 'performed', x.perf)}</td><td className="text-right">{N(k, 'planned', x.plan)}</td><td className="text-right font-semibold">{N(k, undefined, x.perf + x.plan)}</td><td><span className="sv-bar"><i style={{ width: `${(x.perf / Math.max(1, x.perf + x.plan)) * 100}%` }} /></span></td></tr>)}
      <tr className="font-semibold"><td>Total</td><td className="text-right">{tot.perf}</td><td className="text-right">{tot.plan}</td><td className="text-right">{tot.perf + tot.plan}</td><td /></tr></tbody></table>
    {open && <div className="mt-3" data-testid="dx-drilldown"><div className="flex items-center"><b className="text-[14px]">{open.dx}{open.st ? ` · ${DX_STATUS_LABEL[open.st]}` : ''} · {drill.length} patient{drill.length === 1 ? '' : 's'}</b><button type="button" className="sv-link sv-small ml-auto" onClick={() => setOpen(null)}>close</button></div>
      <table className="sv-table text-[13px] mt-1"><thead><tr><th>Patient</th><th>Age · sex</th><th>Procedure</th><th>Status</th></tr></thead><tbody>{drill.map(({ p, d }) => <tr key={p.id}><td><button type="button" className="sv-link" onClick={() => go({ type: 'chart', pid: p.id })}>{p.name}</button> <span className="sv-muted sv-small">{p.id}</span></td><td>{ageFrom(p.dob)} · {p.sex}</td><td>{d!.procedure}</td><td>{DX_STATUS_LABEL[d!.status]}{d!.date && d!.status === 'performed' ? ` · ${usDate(d!.date)}` : ''}</td></tr>)}</tbody></table></div>}
  </div></section>;
};
