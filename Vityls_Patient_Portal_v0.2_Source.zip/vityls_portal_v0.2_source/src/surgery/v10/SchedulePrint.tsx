/*
 * v0.10 · Schedule print, following the ASC schedule print logic (popup → Day or Week, filter, print / download).
 * Surgery generates a real PDF (pdf-lib) shown in the popup: Date, Start, End, Patient name, Age, Gender,
 * Reason for visit, Notes. Grouped by provider, sorted by date and time. Print from the popup or download the PDF.
 */
import React, { useEffect, useMemo, useState } from 'react';
import { PDFDocument, StandardFonts, rgb, PDFFont } from 'pdf-lib';
import { DialogShell } from '../../v7/ui';
import { repo } from '../../v6/dataLayer';
import { medRepo, MedVisit, addDays, toMin, ageFrom, usDate } from '../../med/record';
import { getSettings } from '../../med/settings';
import { useActor } from '../../med/ui';
import { weekStart, eventsOn, SchedResource } from '../v09/schedData';
import { confirmationOf } from '../reminders';
import { notesOf } from '../v11/apptNotes';
import { endOf } from './VisitLength';

const norm = (s: string) => s.toLowerCase().replace(/^dr\.?\s+/, '').replace(/,.*$/, '').trim();
export type PrintRow = { date: string; start: string; end: string; patient: string; age: string; gender: string; reason: string; notes: string; provider: string };

export function printRows(scope: 'day' | 'week', day: string, people: string[]): { days: string[]; groups: { provider: string; rows: PrintRow[] }[]; events: string[] } {
  const days = scope === 'day' ? [day] : Array.from({ length: 7 }, (_, i) => addDays(weekStart(day), i));
  const vs = medRepo.visits().filter(v => days.includes(v.date));
  const row = (v: MedVisit): PrintRow => { const p = medRepo.patient(v.patientId); const c = confirmationOf(v.id);
    const dbl = vs.some(o => o.id !== v.id && o.date === v.date && norm(o.provider) === norm(v.provider) && +toMin(o.time) < +toMin(v.time) + v.durationMin && +toMin(o.time) + o.durationMin > +toMin(v.time));
    return { date: usDate(v.date), start: v.time.replace(/^0/, ''), end: endOf(v.time, v.durationMin).replace(/^0/, ''), patient: p?.name || 'Unknown', age: p ? String(ageFrom(p.dob)).replace(/\D.*$/, '') : '', gender: p?.sex || '',
      reason: v.reason ? (v.reason === v.visitType ? v.reason : `${v.visitType}: ${v.reason}`) : v.visitType, notes: [notesOf(v), dbl ? 'Double-booked' : ''].filter(Boolean).join(' · '), provider: v.provider }; };
  const groups = people.map(pr => ({ provider: pr, rows: vs.filter(v => norm(v.provider) === norm(pr)).sort((a, b) => (a.date + String(toMin(a.time)).padStart(5, '0')).localeCompare(b.date + String(toMin(b.time)).padStart(5, '0'))).map(row) }));
  const events = days.flatMap(d => eventsOn(d).map(e => `${usDate(d)} · ${e.title} · ${e.allDay ? 'all day' : `${e.start.replace(/^0/, '')}–${e.end.replace(/^0/, '')}`}`));
  return { days, groups, events };
}

const COLS: [keyof PrintRow, string, number][] = [['date', 'Date', 62], ['start', 'Start time', 54], ['end', 'End time', 54], ['patient', 'Patient name', 118], ['age', 'Age', 30], ['gender', 'Gender', 46], ['reason', 'Reason for visit', 168], ['notes', 'Notes', 200]];
function wrap(t: string, f: PDFFont, size: number, w: number) { const out: string[] = []; let line = ''; for (const word of t.split(/\s+/)) { const tryL = line ? line + ' ' + word : word; if (f.widthOfTextAtSize(tryL, size) <= w) line = tryL; else { if (line) out.push(line); line = word; while (f.widthOfTextAtSize(line, size) > w && line.length > 1) { let k = line.length; while (k > 1 && f.widthOfTextAtSize(line.slice(0, k), size) > w) k--; out.push(line.slice(0, k)); line = line.slice(k); } } } if (line) out.push(line); return out.length ? out : ['']; }
const clean = (s: string) => s.replace(/[–—]/g, '-').replace(/[·•]/g, '|').replace(/[^\x20-\x7E]/g, '');

export async function buildSchedulePdf(title: string, sub: string, data: ReturnType<typeof printRows>): Promise<Uint8Array> {
  const doc = await PDFDocument.create(); doc.setTitle(title); const F = await doc.embedFont(StandardFonts.Helvetica), B = await doc.embedFont(StandardFonts.HelveticaBold);
  const W = 792, Hh = 612, M = 36; let page = doc.addPage([W, Hh]); let y = Hh - M; let pageNo = 1;
  const practice = clean(getSettings().practiceName.replace(/\s*\(fictional\)/, ''));
  const head = () => { page.drawText(practice, { x: M, y: y - 12, size: 14, font: B, color: rgb(.07, .09, .1) }); page.drawText(clean(title), { x: M, y: y - 28, size: 11, font: B, color: rgb(.12, .43, .32) }); page.drawText(clean(sub), { x: M, y: y - 41, size: 8.5, font: F, color: rgb(.35, .38, .4) });
    page.drawLine({ start: { x: M, y: y - 48 }, end: { x: W - M, y: y - 48 }, thickness: 1, color: rgb(.2, .2, .2) }); y -= 58; };
  const foot = () => page.drawText(`Page ${pageNo} | Printed ${clean(new Date().toLocaleString())} | Fictional test data | Confidential`, { x: M, y: 20, size: 7.5, font: F, color: rgb(.45, .45, .45) });
  const newPage = () => { foot(); page = doc.addPage([W, Hh]); pageNo++; y = Hh - M; head(); };
  const thead = () => { let x = M; page.drawRectangle({ x: M, y: y - 14, width: W - 2 * M, height: 15, color: rgb(.9, .93, .92) }); COLS.forEach(([, l, w]) => { page.drawText(l, { x: x + 3, y: y - 10, size: 8, font: B }); x += w; }); y -= 16; };
  head();
  for (const g of data.groups) {
    if (y < 100) newPage();
    page.drawText(clean(`${g.provider}  (${g.rows.length} appointment${g.rows.length === 1 ? '' : 's'})`), { x: M, y: y - 11, size: 10, font: B }); y -= 16; thead();
    if (!g.rows.length) { page.drawText('No appointments in this period.', { x: M + 3, y: y - 10, size: 8.5, font: F, color: rgb(.4, .4, .4) }); y -= 18; }
    g.rows.forEach((r, i) => { const cells = COLS.map(([k, , w]) => wrap(clean(r[k]), k === 'patient' ? B : F, 8, w - 6)); const h = Math.max(...cells.map(c => c.length)) * 10 + 4;
      if (y - h < 40) { newPage(); page.drawText(clean(`${g.provider} (continued)`), { x: M, y: y - 11, size: 10, font: B }); y -= 16; thead(); }
      if (i % 2) page.drawRectangle({ x: M, y: y - h, width: W - 2 * M, height: h, color: rgb(.97, .98, .98) });
      let x = M; cells.forEach((ls, ci) => { ls.forEach((l, li) => page.drawText(l, { x: x + 3, y: y - 10 - li * 10, size: 8, font: COLS[ci][0] === 'patient' ? B : F })); x += COLS[ci][2]; });
      page.drawLine({ start: { x: M, y: y - h }, end: { x: W - M, y: y - h }, thickness: .4, color: rgb(.8, .8, .8) }); y -= h; });
    y -= 10;
  }
  if (data.events.length) { if (y < 80) newPage(); page.drawText('Office events', { x: M, y: y - 11, size: 10, font: B }); y -= 16; data.events.forEach(e => { if (y < 40) newPage(); page.drawText(clean(e), { x: M + 3, y: y - 9, size: 8.5, font: F }); y -= 12; }); }
  foot(); return doc.save();
}

export const SchedulePrintDialog: React.FC<{ day: string; view: 'day' | 'week'; people: SchedResource[]; initial: string[]; onClose: () => void }> = ({ day, view, people, initial, onClose }) => {
  const [actor] = useActor(); const [scope, setScope] = useState<'day' | 'week'>(view); const [d, setD] = useState(day);
  const [sel, setSel] = useState<string[]>(initial.length ? initial : people.map(p => p.name)); const [url, setUrl] = useState(''); const [busy, setBusy] = useState(false);
  const all = sel.length === people.length;
  const wk = weekStart(d); const title = scope === 'day' ? `Office schedule | ${new Date(d + 'T12:00').toLocaleDateString([], { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' })}` : `Office schedule | Week of ${usDate(wk)} - ${usDate(addDays(wk, 6))}`;
  const fileName = `Schedule-${scope === 'day' ? d : `week-${wk}`}.pdf`;
  const data = useMemo(() => printRows(scope, d, people.filter(p => sel.includes(p.name)).map(p => p.name)), [scope, d, sel.join('|')]);
  const n = data.groups.reduce((a, g) => a + g.rows.length, 0);
  useEffect(() => { let live = true; setBusy(true); buildSchedulePdf(title, `${all ? 'All providers & team' : sel.join(', ')} | ${n} appointment${n === 1 ? '' : 's'}`, data).then(b => { if (!live) return; const u = URL.createObjectURL(new Blob([b as BlobPart], { type: 'application/pdf' })); setUrl(o => { if (o) URL.revokeObjectURL(o); return u; }); setBusy(false); }); return () => { live = false; }; }, [title, data]);
  const audit = (what: string) => repo.audit({ caseId: 'practice', user: actor.name, role: actor.role, action: 'schedule.print', detail: `${what} ${scope} schedule PDF · ${title} · ${all ? 'all' : sel.join(', ')}` });
  const print = () => { const f = document.getElementById('s10-pdf') as HTMLIFrameElement | null; audit('Printed'); try { f?.contentWindow?.focus(); f?.contentWindow?.print(); } catch { window.open(url, '_blank'); } };
  return <div className="sv-flat sv-dlg"><DialogShell size="xl" title="Print schedule" kicker="Scheduler" subtitle="Choose Day or Week and the providers to include. A PDF table is generated below — print it or download it." onClose={onClose} testId="sched-print-dialog"
    footer={<><span className="mr-auto sv-small sv-muted" data-testid="print-count">{n} appointment{n === 1 ? '' : 's'} · {data.groups.length} provider{data.groups.length === 1 ? '' : 's'}</span>
      <button type="button" className="sv-btn" onClick={onClose}>Close</button>
      <a className={`sv-btn${url ? '' : ' disabled'}`} href={url || undefined} download={fileName} onClick={() => audit('Downloaded')} data-testid="print-download">Download PDF</a>
      <button type="button" className="sv-btn primary" disabled={!url || busy} onClick={print} data-testid="print-pdf">Print</button></>}>
    <div className="flex flex-wrap items-end gap-3 mb-3">
      <div><span className="sv-label">Print</span><div className="sv-seg" role="group" aria-label="Day or week"><button type="button" aria-pressed={scope === 'day'} onClick={() => setScope('day')} data-testid="print-scope-day">Day</button><button type="button" aria-pressed={scope === 'week'} onClick={() => setScope('week')} data-testid="print-scope-week">Week</button></div></div>
      <label><span className="sv-label">{scope === 'day' ? 'Date' : 'Any day in the week'}</span><input type="date" className="sv-input" value={d} onChange={e => e.target.value && setD(e.target.value)} data-testid="print-date" /></label>
    </div>
    <div className="mb-3"><span className="sv-label">Providers</span><div className="flex flex-wrap gap-x-4 gap-y-1 text-[13.5px]" data-testid="print-providers">
      <label className="flex items-center gap-1.5 font-semibold"><input type="checkbox" checked={all} onChange={e => setSel(e.target.checked ? people.map(p => p.name) : [])} data-testid="print-all" />All</label>
      {people.map(p => <label key={p.id} className="flex items-center gap-1.5"><input type="checkbox" checked={sel.includes(p.name)} onChange={e => setSel(e.target.checked ? [...sel, p.name] : sel.filter(x => x !== p.name))} data-testid="print-prov" data-name={p.name} />{p.name} <i className="sv-muted not-italic text-[12px]">{p.role}</i></label>)}</div></div>
    {sel.length === 0 ? <p className="sv-muted">Choose at least one provider.</p> : <iframe id="s10-pdf" title="Schedule PDF" src={url} style={{ width: '100%', height: 'min(60vh, 560px)', border: '1px solid #d1d5db', borderRadius: 3, background: '#f3f4f6' }} data-testid="print-pdf-frame" />}
  </DialogShell></div>;
};
