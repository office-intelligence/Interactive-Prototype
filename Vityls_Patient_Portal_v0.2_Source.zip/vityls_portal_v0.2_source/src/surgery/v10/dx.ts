/* v0.10 · Primary surgical diagnosis / condition + procedure (planned or performed) per patient. Surgery namespace.
 * Fictional seed: the demo patients get varied diagnoses deterministically (by MRN order); new patients get one derived
 * from their next ASC case when available. Backend swap point: patients.primary_dx / procedures. */
import { medRepo, MedPatient } from '../../med/record';
import { svRead, svWrite } from '../store';
import { ascCasesFor } from '../store';
import { isMedical } from '../../edition';
import { medTerm } from '../medical/terms';
import { MEDICAL_DX_BY_NAME, MEDICAL_DX_POOL, MedDx } from '../medical/data';
export type DxStatus = 'performed' | 'planned';
export interface PatientDx { diagnosis: string; procedure: string; status: DxStatus; date?: string }
const SEED: PatientDx[] = [
  { diagnosis: 'Dermatochalasis of upper eyelids', procedure: 'Bilateral upper blepharoplasty', status: 'planned' },
  { diagnosis: 'Facial rhytides / jowling', procedure: 'Facelift / necklift', status: 'performed', date: '2026-10-05' },
  { diagnosis: 'Basal cell carcinoma, cheek', procedure: 'Mohs reconstruction, local flap', status: 'planned' },
  { diagnosis: 'Nasal deformity', procedure: 'Rhinoplasty', status: 'planned' },
  { diagnosis: 'Abdominal wall laxity / diastasis', procedure: 'Abdominoplasty', status: 'planned' },
  { diagnosis: 'Dynamic forehead rhytides', procedure: 'Neuromodulator injection', status: 'performed', date: '2026-09-22' },
  { diagnosis: 'Dermatochalasis of upper eyelids', procedure: 'Bilateral upper blepharoplasty', status: 'performed', date: '2026-08-14' },
  { diagnosis: 'Breast hypertrophy', procedure: 'Reduction mammaplasty', status: 'performed', date: '2026-07-30' },
  { diagnosis: 'Nasal deformity', procedure: 'Rhinoplasty', status: 'performed', date: '2026-06-18' },
  { diagnosis: 'Abdominal wall laxity / diastasis', procedure: 'Abdominoplasty', status: 'performed', date: '2026-09-02' }];
const BY_NAME: Record<string, PatientDx> = {
  'Ellen Testwood': { diagnosis: 'Dermatochalasis of upper eyelids', procedure: 'Bilateral upper blepharoplasty', status: 'planned' },
  'Marisol Sampleton': { diagnosis: 'Abdominal wall laxity / diastasis', procedure: 'Abdominoplasty', status: 'planned' },
  'Robert Fictus': { diagnosis: 'Facial rhytides / jowling', procedure: 'Facelift / necklift', status: 'performed', date: '2026-10-05' },
  'Priya Demoshah': { diagnosis: 'Dynamic forehead rhytides', procedure: 'Neuromodulator injection', status: 'performed', date: '2026-07-14' },
  'Grace Placeholder': { diagnosis: 'Basal cell carcinoma, cheek', procedure: 'Mohs reconstruction, local flap', status: 'planned' },
  'Tomas Exampleton': { diagnosis: 'Nasal deformity', procedure: 'Rhinoplasty', status: 'planned' } };
const all = () => svRead<Record<string, PatientDx>>('patient-dx', {});
/* ---------- v0.11: several diagnoses per patient, each with linked procedures ---------- */
export interface DxProc { id: string; name: string; status: DxStatus; date?: string; surgeon?: string; asc?: string }
export interface DxEntry { id: string; diagnosis: string; icd?: string; procedures: DxProc[]; primary?: boolean }
const EXTRA: Record<string, DxEntry[]> = {
  'Robert Fictus': [{ id: 'dx-rf2', diagnosis: 'Dermatochalasis of upper eyelids', icd: 'H02.834', procedures: [{ id: 'pr-rf2', name: 'Bilateral upper blepharoplasty', status: 'performed', date: '2025-03-12', surgeon: 'Sam Patel, MD', asc: 'Bayview Surgery Center' }] }],
  'Priya Demoshah': [{ id: 'dx-pd2', diagnosis: 'Nasal deformity', icd: 'M95.0', procedures: [{ id: 'pr-pd2', name: 'Rhinoplasty', status: 'performed', date: '2024-11-02', surgeon: 'Sam Patel, MD', asc: 'Bayview Surgery Center' }] }],
  'Grace Placeholder': [{ id: 'dx-gp2', diagnosis: 'Facial rhytides / jowling', icd: 'L90.8', procedures: [{ id: 'pr-gp2', name: 'Facelift / necklift', status: 'planned', surgeon: 'Dana Whitfield, MD' }] }],
  'Marisol Sampleton': [{ id: 'dx-ms2', diagnosis: 'Breast hypertrophy', icd: 'N62', procedures: [{ id: 'pr-ms2', name: 'Reduction mammaplasty', status: 'performed', date: '2024-05-10', surgeon: 'Dana Whitfield, MD', asc: 'Bayview Surgery Center' }] }] };
const ICD: Record<string, string> = { 'Dermatochalasis of upper eyelids': 'H02.834', 'Abdominal wall laxity / diastasis': 'M62.08', 'Facial rhytides / jowling': 'L90.8', 'Dynamic forehead rhytides': 'L90.8', 'Basal cell carcinoma, cheek': 'C44.319', 'Nasal deformity': 'M95.0' };
const store2 = () => svRead<Record<string, DxEntry[]>>('patient-dx2', {});
/** Medical.Vityls: diagnoses with plan items (treatments, orders, referrals) from the medical seed. */
function medicalDx(p: MedPatient): DxEntry[] {
  const ids = medRepo.patients().map(x => x.id).sort(); const i = ids.indexOf(p.id);
  const l: MedDx[] = MEDICAL_DX_BY_NAME[p.name] || (/^MED-\d+$/.test(p.id) && i >= 0 ? [MEDICAL_DX_POOL[i % MEDICAL_DX_POOL.length]] : []);
  return l.map((d, j) => ({ id: `dx-${p.id}-${j}`, diagnosis: d.diagnosis, icd: d.icd, primary: j === 0, procedures: d.plan.map(([name, status, date], k) => ({ id: `pl-${p.id}-${j}-${k}`, name, status, date, surgeon: status === 'performed' ? p.primaryProvider : undefined })) }));
}
export function dxList(p: MedPatient): DxEntry[] {
  const s = store2()[p.id]; if (s) return s;
  if (isMedical) return medicalDx(p);
  const one = dxFor(p); const base: DxEntry[] = one ? [{ id: `dx-${p.id}`, diagnosis: one.diagnosis, icd: ICD[one.diagnosis], primary: true, procedures: [{ id: `pr-${p.id}`, name: one.procedure, status: one.status, date: one.date, surgeon: p.primaryProvider }] }] : [];
  return [...base, ...(EXTRA[p.name] || [])];
}
export function saveDxList(p: MedPatient, l: DxEntry[]) { svWrite('patient-dx2', { ...store2(), [p.id]: l }); }
/** One row per (patient, diagnosis): performed when any linked procedure is performed. Feeds list, filter and report. */
export function dxPairs() { return medRepo.patients().flatMap(p => dxList(p).map(d => ({ p, d, performed: d.procedures.some(x => x.status === 'performed') }))); }

export function dxFor(p: MedPatient): PatientDx | undefined {
  const s = all()[p.id]; if (s) return s;
  if (isMedical) { const d = medicalDx(p)[0]; if (!d) return undefined; const pl = d.procedures.find(x => x.status === 'planned') || d.procedures[0]; return pl ? { diagnosis: d.diagnosis, procedure: pl.name, status: d.procedures.some(x => x.status === 'performed') ? 'performed' : 'planned', date: pl.date } : undefined; } if (BY_NAME[p.name]) return BY_NAME[p.name];
  const ids = medRepo.patients().map(x => x.id).sort(); const i = ids.indexOf(p.id);
  if (/^MED-\d+$/.test(p.id) && i >= 0 && i < SEED.length) return SEED[i];
  const c = ascCasesFor(p.id)[0]; return c ? { diagnosis: c.procedure, procedure: c.procedure, status: c.date < new Date().toISOString().slice(0, 10) ? 'performed' : 'planned', date: c.date } : undefined;
}
export const saveDx = (pid: string, d: PatientDx) => svWrite('patient-dx', { ...all(), [pid]: d });
export const DX_STATUS_LABEL: Record<DxStatus, string> = { performed: 'Performed', planned: 'Not performed' };
export function dxIndex() { const rows = medRepo.patients().map(p => ({ p, d: dxFor(p) })); return rows; }
export const csv = (rows: (string | number)[][]) => rows.map(r => r.map(x => { const s = String(x ?? ''); return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s; }).join(',')).join('\r\n');
export function downloadCsv(name: string, text: string) { if (isMedical) text = medTerm(text); const u = URL.createObjectURL(new Blob([text], { type: 'text/csv' })); const a = document.createElement('a'); a.href = u; a.download = name; document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(u), 1000); }
