/*
 * Surgery.Vityls office schedule: day grid by provider, office visits in the practice's configured visit-type colors,
 * the surgeon's ASC block time (dashed band) and ASC cases (hatched) placed automatically from the network link.
 * Desktop-oriented (front desk / manager), still usable on a tablet.
 * v0.6: click a visit for Appointment detail (edit, open chart, visit workflow, delete with reason + PIN).
 * v0.5: click (or tap) an open time slot to open New appointment pre-filled with that date, time and provider column;
 *       the patient search can create a new patient on the spot. Each visit shows its confirmation status, and the
 *       page lists appointment confirmations for the next 14 days (reminders are simulated, see reminders.tsx).
 */
import { isMedical } from '../edition';
import React, { useState } from 'react';
import { DialogShell } from '../v7/ui';
import { getProviders, displayName } from '../v7/providers';
import { repo } from '../v6/dataLayer';
import { medRepo, MedVisit, isoDay, addDays, usDate, toMin, uid, ageFrom } from '../med/record';
import { MED_ROOMS } from '../med/seed';
import { matchPatient, NetworkCase } from '../med/network';
import { NetworkCaseDialog } from '../med/MedSchedule';
import { useActor, useMedTick } from '../med/ui';
import { activeVisitTypes, ascBlocks, ascCases, edgeOf, modules, visitTypeDef, visitTypes, svRead, svWrite } from './store';
import { PROVIDER_ROLES } from '../med/record';
import { Ico } from './icons';
import { STATION_LABEL, R } from './nightingale';
import { useSv } from './ui';
import { ConfBadge, ConfirmationsList, ReminderDialog, runReminders, reminderSettings } from './reminders';
import { AddNewPatientButton } from './newPatient';
import { AppointmentDetail } from './apptDetail';
import { getSettings } from '../med/settings';
import { staffList } from './staff';
import { SchedulePrintDialog } from './v10/SchedulePrint';
import { VisitLength } from './v10/VisitLength';
import { resources, saveResources, bookable, SchedResource, OfficeEvent, EVENT_KINDS, eventsOn, saveEvent, deleteEvent, newEvent, weekStart, Recur } from './v09/schedData';

const START = 7 * 60, END = 18 * 60, PX = 1.6;
const at = (t: string) => +toMin(t);
const fmt = (m: number) => { const h = Math.floor(m / 60), mm = m % 60; return `${String(((h + 11) % 12) + 1).padStart(2, '0')}:${String(mm).padStart(2, '0')} ${h < 12 ? 'AM' : 'PM'}`; };
const norm = (s: string) => s.toLowerCase().replace(/^dr\.?\s+/, '').replace(/,.*$/, '').trim();

type Col = { key: string; title: string; sub: string; kind: 'person' | 'room' | 'day'; date: string; match: (v: MedVisit) => boolean; person?: string };
/** Greedy lanes so overlapping visits sit side by side (double-booking is allowed, shown, never blocked). */
function lanes<T extends { s: number; e: number }>(items: T[]): (T & { lane: number; of: number })[] {
  const sorted = [...items].sort((a, b) => a.s - b.s); const out: (T & { lane: number; of: number })[] = []; let cluster: (T & { lane: number; of: number })[] = []; let end = -1;
  const flush = () => { const n = Math.max(1, ...cluster.map(c => c.lane + 1)); cluster.forEach(c => c.of = n); out.push(...cluster); cluster = []; };
  sorted.forEach(it => { if (it.s >= end && cluster.length) { flush(); end = -1; } const used = new Set(cluster.filter(c => c.e > it.s).map(c => c.lane)); let l = 0; while (used.has(l)) l++; cluster.push({ ...it, lane: l, of: 1 }); end = Math.max(end, it.e); });
  if (cluster.length) flush(); return out;
}
const shortDay = (d: string) => new Date(d + 'T12:00:00').toLocaleDateString([], { weekday: 'short', month: 'numeric', day: 'numeric' });

export const SurgerySchedule: React.FC = () => {
  useMedTick(); const [actor] = useActor(); const { go, toast, setTab } = useSv(); const mods = modules();
  const [day, setDay] = useState(isoDay()); const [asc, setAsc] = useState(true); const [adding, setAdding] = useState<{ provider: string; time: string; date?: string; room?: string } | null>(null); const [sel, setSel] = useState<NetworkCase | null>(null); const [hover, setHover] = useState<{ col: string; m: number } | null>(null); const [rm, setRm] = useState(''); const [detail, setDetail] = useState('');
  const [view, setView] = useState<'day' | 'week'>(() => (svRead<string>('schedule-view', 'day') === 'week' ? 'week' : 'day'));
  const [pick, setPick] = useState(false); const [printing, setPrinting] = useState(false); const [manage, setManage] = useState(false); const [ev, setEv] = useState<{ e: OfficeEvent; isNew: boolean } | null>(null);
  const res = bookable(); const people = res.filter(r => r.kind === 'person');
  const saved = svRead<string[] | null>('schedule-columns', null);
  const cols = saved ? saved.filter(n => res.some(p => p.name === n)) : res.filter(p => p.kind === 'person' && PROVIDER_ROLES.includes(p.role)).map(p => p.name);
  const shown = cols.map(n => res.find(p => p.name === n)!); 
  const setCols = (next: string[], what: string) => { svWrite('schedule-columns', next); repo.audit({ caseId: 'practice', user: actor.name, role: actor.role, action: 'schedule.columns', detail: what }); };
  const setV = (v: 'day' | 'week') => { setView(v); svWrite('schedule-view', v); };
  const showAsc = asc && mods.networkAsc; const showBlocks = asc && mods.blockTime;
  const H = (END - START) * PX; const types = visitTypes().filter(t => t.active);
  const wk = weekStart(day); const days = view === 'week' ? Array.from({ length: 7 }, (_, i) => addDays(wk, i)) : [day];
  const matchR = (r: SchedResource) => (v: MedVisit) => r.kind === 'room' ? v.room === r.name : norm(v.provider) === norm(r.name);
  const columns: Col[] = view === 'day' ? shown.map(r => ({ key: r.name, title: r.name, sub: r.role, kind: r.kind, date: day, match: matchR(r), person: r.kind === 'person' ? r.name : undefined }))
    : days.map(d => ({ key: d, title: shortDay(d), sub: d === isoDay() ? 'Today' : '', kind: 'day', date: d, match: (v: MedVisit) => shown.some(r => matchR(r)(v)), person: shown.find(r => r.kind === 'person')?.name }));
  const dayVisits = (d: string) => medRepo.visits().filter(v => v.date === d);
  const visitsN = days.reduce((n, d) => n + dayVisits(d).filter(v => view === 'day' || shown.some(r => matchR(r)(v))).length, 0);
  const blocksOn = (d: string) => showBlocks ? ascBlocks().filter(b => b.date === d) : []; const casesOn = (d: string) => showAsc ? ascCases().filter(c => c.date === d) : [];
  const inBlock = (v: MedVisit) => blocksOn(v.date).some(b => norm(b.surgeon) === norm(v.provider) && at(v.time) < at(b.end) && at(v.time) + v.durationMin > at(b.start));
  const upcoming = [...(showBlocks ? ascBlocks().filter(b => b.date >= isoDay() && b.date <= addDays(isoDay(), 21)).map(b => ({ date: b.date, time: b.start, line: `Block time · ${b.surgeon} · ${b.start}–${b.end} · ${b.room}`, kind: 'block' as const, c: undefined as NetworkCase | undefined })) : []),
    ...(showAsc ? ascCases().filter(c => c.date >= isoDay() && c.date <= addDays(isoDay(), 21)).map(c => ({ date: c.date, time: c.time, line: `${c.procedure} · ${c.patientName} · ${c.surgeon} · ${c.room} · ${c.status}`, kind: 'case' as const, c })) : [])].sort((a, b) => (a.date + toMin(a.time)).localeCompare(b.date + toMin(b.time)));
  const openCase = (c: NetworkCase) => { const m = matchPatient(c); if (m) go({ type: 'panel', ref: R('asc', `Network ASC · ${c.procedure}`, m.id) }); else setSel(c); };
  const allDay = days.flatMap(d => eventsOn(d).filter(e => e.allDay).map(e => ({ e, d })));
  const title = view === 'day' ? new Date(day + 'T12:00:00').toLocaleDateString([], { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' }) : `Week of ${new Date(wk + 'T12:00:00').toLocaleDateString([], { month: 'long', day: 'numeric', year: 'numeric' })}`;
  const step = view === 'week' ? 7 : 1; const CW = view === 'week' ? 150 : 190;
  return <div className="sv-page s9" data-testid="sv-schedule" data-view={view}>
    <div className="flex flex-wrap items-end justify-between gap-3 mb-2 s9-ctl">
      <div><h1 className="sv-title" data-testid="sched-title">{title}</h1>
        <div className="sv-sub">{visitsN} office visit{visitsN === 1 ? '' : 's'}{view === 'day' && showBlocks ? ` · ${blocksOn(day).length} ASC block${blocksOn(day).length === 1 ? '' : 's'}` : ''}{view === 'day' && showAsc ? ` · ${casesOn(day).length} ASC case${casesOn(day).length === 1 ? '' : 's'}` : ''}{eventsOn(day).length && view === 'day' ? ` · ${eventsOn(day).length} office event${eventsOn(day).length === 1 ? '' : 's'}` : ''}</div></div>
      <div className="flex flex-wrap items-center gap-2">
        <div className="sv-seg" role="group" aria-label="View"><button type="button" aria-pressed={view === 'day'} onClick={() => setV('day')} data-testid="view-day">Day</button><button type="button" aria-pressed={view === 'week'} onClick={() => setV('week')} data-testid="view-week">Week</button></div>
        <button type="button" className="sv-btn sm" onClick={() => setDay(addDays(day, -step))} aria-label={`Previous ${view}`} data-testid="sched-prev">‹</button><button type="button" className="sv-btn sm" onClick={() => setDay(isoDay())}>Today</button><button type="button" className="sv-btn sm" onClick={() => setDay(addDays(day, step))} aria-label={`Next ${view}`} data-testid="sched-next">›</button>
        <input type="date" className="sv-input" style={{ width: 150 }} value={day} onChange={e => e.target.value && setDay(e.target.value)} aria-label="Go to date" />
        <div className="s9-pick"><button type="button" className="sv-btn sm" aria-haspopup="true" aria-expanded={pick} onClick={() => setPick(o => !o)} data-testid="sched-cols">Columns · {shown.length} ▾</button>
          {pick && <div className="s9-pop" role="dialog" aria-label="Choose columns" data-testid="sched-cols-pop">
            {(['person', 'room'] as const).map(k => <div key={k}><div className="g">{k === 'person' ? 'Providers & team' : 'Rooms'}</div>{res.filter(r => r.kind === k).map(r => <label key={r.id} className="o"><input type="checkbox" checked={cols.includes(r.name)} onChange={e => setCols(e.target.checked ? [...cols, r.name] : cols.filter(n => n !== r.name), `Schedule column ${e.target.checked ? 'shown' : 'hidden'}: ${r.name}`)} data-testid="sched-col-opt" data-name={r.name} /><span>{r.name}</span><i>{r.role}</i></label>)}</div>)}
            <div className="flex gap-2 mt-2"><button type="button" className="sv-link text-[12px]" onClick={() => setCols(res.filter(r => r.kind === 'person' && PROVIDER_ROLES.includes(r.role)).map(r => r.name), 'Schedule columns reset to providers')}>Providers only</button><button type="button" className="sv-link text-[12px] ml-auto" onClick={() => { setPick(false); setManage(true); }} data-testid="sched-manage">Manage columns…</button></div></div>}</div>
        {(mods.networkAsc || mods.blockTime) && <label className="flex items-center gap-1.5 text-[13px]"><input type="checkbox" checked={asc} onChange={e => setAsc(e.target.checked)} data-testid="toggle-asc" />ASC layer</label>}
        <button type="button" className="sv-btn sm" onClick={() => setEv({ e: newEvent(day, actor.name), isNew: true })} data-testid="event-add">+ Office event</button>
        <button type="button" className="sv-btn sm" onClick={() => setPrinting(true)} data-testid="sched-print">Print</button>
        <button type="button" className="sv-btn sm primary" onClick={() => setAdding({ provider: shown.find(r => r.kind === 'person')?.name || people[0]?.name || '', time: '09:00 AM' })} data-testid="add-visit">Add visit</button>
      </div>
    </div>
    <div className="sv-legend mb-2 s9-ctl" data-testid="sched-legend">{types.map(t => <span key={t.id}><i style={{ background: t.color, borderColor: edgeOf(t.color) }} />{t.name}</span>)}
      {showBlocks && <span><i className="sv-block" />ASC block time</span>}{showAsc && <span><i className="sv-hatch" />ASC case</span>}<span><i className="s9-ev-sw" />Office event</span>
      <button type="button" className="sv-link text-[12px]" onClick={() => setTab('surgery-settings')} data-testid="legend-edit">edit colors</button></div>
    {allDay.length > 0 && <div className="s9-band" data-testid="event-band">{allDay.map(({ e, d }) => <button key={e.id + d} type="button" className="s9-band-i" onClick={() => setEv({ e, isNew: false })} data-testid="office-event">{view === 'week' ? `${shortDay(d)} · ` : ''}<b>{e.title}</b> · all day{e.recur !== 'none' ? ` · repeats ${e.recur}` : ''}</button>)}</div>}
    <div className="sv-grid-wrap">
      <div className="grid" style={{ gridTemplateColumns: `56px repeat(${columns.length}, minmax(${CW}px, 1fr))`, minWidth: 56 + columns.length * CW, ['--s9n' as string]: Math.max(1, columns.length) } as React.CSSProperties}>
        <div className="sv-gh" style={{ position: 'sticky', left: 0, background: '#fff', zIndex: 3 }} />
        {columns.map(c => <div key={c.key} className="sv-gh flex items-center gap-1" data-testid="sched-col" data-kind={c.kind}>{c.kind !== 'day' && <Ico k={c.kind === 'room' ? 'block' : 'careteam'} />}<b className="truncate">{c.title}</b> <span className="sv-muted truncate">{c.sub}</span>{c.kind !== 'day' && <button type="button" className="sv-colx s9-ctl" onClick={() => setCols(cols.filter(n => n !== c.key), `Schedule column removed: ${c.key}`)} aria-label={`Remove ${c.title} from the schedule`} title="Hide column" data-testid="col-remove">×</button>}</div>)}
        {columns.length === 0 && <div className="sv-gh sv-muted">No columns. Choose some with “Columns”.</div>}
        <div className="relative" style={{ height: H, position: 'sticky', left: 0, background: '#fff', zIndex: 3 }}>{Array.from({ length: (END - START) / 60 + 1 }, (_, i) => <div key={i} className="absolute right-2 text-[11px] sv-muted" style={{ top: i * 60 * PX - 7 }}>{fmt(START + i * 60).replace(':00', '')}</div>)}</div>
        {columns.map(c => { const slotAt = (e: React.MouseEvent) => { const r = (e.currentTarget as HTMLDivElement).getBoundingClientRect(); return Math.min(END - 15, Math.max(START, START + Math.floor(((e.clientY - r.top) / PX) / 15) * 15)); };
          const onItem = (e: React.MouseEvent) => !!(e.target as HTMLElement).closest('button');
          const blocks = blocksOn(c.date).filter(b => c.kind === 'day' ? shown.some(r => r.kind === 'person' && norm(r.name) === norm(b.surgeon)) : c.kind === 'person' && norm(b.surgeon) === norm(c.key));
          const cases = casesOn(c.date).filter(x => c.kind === 'day' ? shown.some(r => r.kind === 'person' && norm(r.name) === norm(x.surgeon)) : c.kind === 'person' && norm(x.surgeon) === norm(c.key));
          const vs = lanes(dayVisits(c.date).filter(c.match).map(v => ({ v, s: at(v.time), e: at(v.time) + v.durationMin })));
          const evs = eventsOn(c.date).filter(e => !e.allDay);
          return <div key={c.key} className="relative sv-col" style={{ height: H }} data-testid="sched-slots" data-provider={c.person || c.key} data-date={c.date}
            onClick={e => { if (onItem(e)) return; const room = c.kind === 'room' ? c.key : undefined; setAdding({ provider: c.kind === 'person' ? c.key : (c.person || people[0]?.name || ''), time: fmt(slotAt(e)), date: c.date, room }); }}
            onMouseMove={e => { if (onItem(e)) { if (hover) setHover(null); return; } const m = slotAt(e); if (!hover || hover.m !== m || hover.col !== c.key) setHover({ col: c.key, m }); }} onMouseLeave={() => setHover(null)}
            title="Click an open time to book an appointment">
          {hover?.col === c.key && <div className="sv-slot-ghost" style={{ top: (hover.m - START) * PX, height: 15 * PX }} aria-hidden="true">+ {fmt(hover.m).replace(/^0/, '')}</div>}
          {Array.from({ length: (END - START) / 30 }, (_, i) => <div key={i} className="absolute left-0 right-0" style={{ top: i * 30 * PX, borderTop: `1px solid ${i % 2 ? '#f3f4f6' : '#e5e7eb'}` }} />)}
          {evs.map(e => <div key={e.id} className="absolute left-0 right-0 s9-ev" style={{ top: (at(e.start) - START) * PX, height: Math.max(18, (at(e.end) - at(e.start)) * PX) }}><button type="button" className="s9-ev-l" onClick={() => setEv({ e, isNew: false })} data-testid="office-event" title={`${e.title} · ${e.start}–${e.end} (office-wide)`}>{e.title} · {e.start.replace(/^0/, '')}–{e.end.replace(/^0/, '')}{e.recur !== 'none' ? ' ↻' : ''}</button></div>)}
          {blocks.map(b => <div key={b.id} className="absolute left-0 right-0 sv-block" style={{ top: (at(b.start) - START) * PX, height: (at(b.end) - at(b.start)) * PX }} data-testid="asc-block"><div className="text-[11px] px-1.5 py-0.5 text-[var(--ink2)]"><b>At the ASC · block {b.start.replace(/^0/, '')}–{b.end.replace(/^0/, '')}</b>{c.kind === 'day' ? ` · ${b.surgeon.replace(/,.*$/, '')}` : ''} · {b.room}{b.source === 'fictional-seed' ? ' · fictional' : ''}</div></div>)}
          {cases.map(x => <button type="button" key={x.id} onClick={() => openCase(x)} data-testid="asc-case" className="absolute sv-hatch text-left px-1.5 py-1 overflow-hidden text-[12px]" style={{ left: '50%', right: 3, top: (at(x.time) - START) * PX + 16, height: Math.max(34, x.durationMin * PX - 16), border: '1px solid #6b7280', borderRadius: 3 }}>
            <div className="font-bold truncate">{x.time.replace(/^0/, '')} · {x.patientName}</div><div className="truncate">{x.procedure}</div><div className="truncate sv-muted">{x.status}</div></button>)}
          {vs.map(({ v, lane, of }) => { const pt = medRepo.patient(v.patientId); const t = visitTypeDef(v.visitType); const conflict = showBlocks && inBlock(v);
            const caseOverlap = cases.some(x => at(v.time) < at(x.time) + x.durationMin && at(v.time) + v.durationMin > at(x.time));
            const span = caseOverlap ? 50 : 100; const w = span / of;
            return <button type="button" key={v.id} onClick={() => setDetail(v.id)} data-testid="visit-block" data-time={v.time} data-double={of > 1 ? 'true' : undefined} title={`${v.visitType} · ${pt?.name} · ${v.provider}`} className="absolute text-left px-1.5 py-1 overflow-hidden text-[12px] sv-vblock" style={{ left: `calc(${lane * w}% + 3px)`, width: `calc(${w}% - 5px)`, top: (at(v.time) - START) * PX + 1, height: Math.max(24, v.durationMin * PX - 2), background: t.color, borderLeft: `1px solid ${edgeOf(t.color)}` }}>
              <div className="font-bold truncate flex items-center gap-1"><span className="truncate">{v.time.replace(/^0/, '')} · {pt?.name}</span>{v.step === 'scheduled' && of === 1 && <span className="ml-auto flex-none" onClick={e => { e.stopPropagation(); setRm(v.id); }}><ConfBadge v={v} compact /></span>}</div>
              {v.durationMin * PX >= 40 && <div className="truncate">{c.kind !== 'person' ? `${v.provider.replace(/,.*$/, '')} · ` : ''}{v.visitType}{v.step !== 'scheduled' ? ` · ${STATION_LABEL[v.step]}` : ''}</div>}
              {of > 1 && lane === 0 && <div className="s9-dbl" data-testid="double-booked">Double-booked</div>}
              {conflict && <div className="truncate text-[var(--crit)] font-semibold">During ASC block</div>}</button>; })}
        </div>; })}
      </div>
    </div>
    <p className="text-[12px] sv-muted mt-1 s9-ctl">Click an open time in a column to book there — providers, team members (nurse, coordinator, MA…) and rooms can all be booked. Double-booking is allowed and shown side by side. Office events show across every column.{isMedical ? '' : ' Block time and ASC cases come from the affiliated ASC (simulated network link).'}</p>
    <div className="s9-ctl"><ConfirmationsList from={day < isoDay() ? isoDay() : day} /></div>
    {rm && <ReminderDialog visitId={rm} onClose={() => setRm('')} />}
    {detail && <AppointmentDetail visitId={detail} providers={people.map(p => p.name)} onClose={() => setDetail('')} />}
    {upcoming.length > 0 && <section className="mt-4 s9-ctl" data-testid="sched-upcoming"><h2 className="sv-h">At the ASC · next 3 weeks</h2>
      <table className="sv-table"><tbody>{upcoming.map((u, i) => <tr key={i}><td style={{ width: 120 }} className="whitespace-nowrap">{usDate(u.date)}</td><td style={{ width: 90 }}>{u.time.replace(/^0/, '')}</td><td>{u.kind === 'block' ? <span className="sv-muted">{u.line}</span> : <button type="button" className="sv-link" onClick={() => openCase(u.c!)}>{u.line}</button>}</td><td className="text-right"><button type="button" className="sv-link text-[12px]" onClick={() => { setV('day'); setDay(u.date); }}>show day</button></td></tr>)}</tbody></table></section>}
    {adding && <AddVisit initial={adding} day={adding.date || day} providers={people.map(p => p.name)} onClose={() => setAdding(null)} onSaved={v => { setAdding(null); repo.audit({ caseId: v.id, user: actor.name, role: actor.role, action: 'visit.create', detail: `${v.visitType} ${usDate(v.date)} ${v.time} with ${v.provider} in ${v.room}` }); runReminders(); toast(`Appointment booked for ${medRepo.patient(v.patientId)?.name}.${reminderSettings().enabled ? ' Confirmation reminders scheduled (simulated).' : ''}`); }} />}
    {sel && <div className="sv-flat"><NetworkCaseDialog c={sel} onClose={() => setSel(null)} onOpenChart={pid => { setSel(null); go({ type: 'chart', pid }); }} /></div>}
    {printing && <SchedulePrintDialog day={day} view={view} people={people} initial={shown.filter(r => r.kind === 'person').map(r => r.name)} onClose={() => setPrinting(false)} />}
    {ev && <EventDialog e={ev.e} isNew={ev.isNew} onClose={() => setEv(null)} />}
    {manage && <div className="sv-modal" role="dialog" aria-modal="true" aria-label="Manage schedule columns" data-testid="manage-cols"><div className="sv-modal-scrim" onClick={() => setManage(false)} /><div className="sv-modal-box" style={{ width: 'min(760px, calc(100vw - 24px))', maxHeight: 'calc(100vh - 40px)', overflowY: 'auto' }}><div className="flex items-center mb-2"><b className="text-[16px]">Schedule columns</b><button type="button" className="sv-btn sm ml-auto" onClick={() => setManage(false)} data-testid="manage-close">Done</button></div><ResourceManager /></div></div>}
  </div>;
};

const EventDialog: React.FC<{ e: OfficeEvent; isNew: boolean; onClose: () => void }> = ({ e, isNew, onClose }) => {
  const [actor] = useActor(); const { toast } = useSv(); const [f, setF] = useState<OfficeEvent>(e); const [err, setErr] = useState(''); const [del, setDel] = useState(false);
  const ok = (t: string) => /^\d{1,2}:\d{2}\s?(AM|PM)$/i.test(t.trim());
  const save = () => { if (!f.title.trim()) { setErr('Give the event a title.'); return; } if (!f.allDay && (!ok(f.start) || !ok(f.end) || at(f.end) <= at(f.start))) { setErr('Times must look like 12:00 PM and end after the start.'); return; }
    saveEvent({ ...f, title: f.title.trim(), start: f.start.trim().toUpperCase(), end: f.end.trim().toUpperCase() }, actor.name, actor.role, isNew); toast(`${isNew ? 'Office event added' : 'Office event updated'}: ${f.title}`); onClose(); };
  return <div className="sv-modal" role="dialog" aria-modal="true" aria-label="Office event" data-testid="event-dialog"><div className="sv-modal-scrim" onClick={onClose} />
    <div className="sv-modal-box" style={{ width: 'min(560px, calc(100vw - 24px))' }}>
      <div className="flex items-center gap-2 mb-1"><b className="text-[16px]">{isNew ? 'New office event' : 'Office event'}</b><span className="v7-pill gray">shown across every column</span></div>
      <p className="sv-small sv-muted mb-3">Staff meetings, in-services, luncheons, closures. Anyone on staff can add, edit or delete; every change is in the audit. Appointments can still be booked over an event.</p>
      <div className="grid sm:grid-cols-2 gap-2">
        <label className="sm:col-span-2"><span className="sv-label">Title</span><input className="sv-input" value={f.title} onChange={x => setF({ ...f, title: x.target.value })} data-testid="ev-title" /></label>
        <label><span className="sv-label">Kind</span><select className="sv-input" value={f.kind} onChange={x => setF({ ...f, kind: x.target.value, title: f.title === f.kind || !f.title ? x.target.value : f.title })} data-testid="ev-kind">{EVENT_KINDS.map(k => <option key={k}>{k}</option>)}</select></label>
        <label><span className="sv-label">Date</span><input type="date" className="sv-input" value={f.date} onChange={x => setF({ ...f, date: x.target.value })} data-testid="ev-date" /></label>
        <label className="flex items-center gap-2 sm:col-span-2 text-[13px]"><input type="checkbox" checked={f.allDay} onChange={x => setF({ ...f, allDay: x.target.checked })} data-testid="ev-allday" />All day (shown as a band above the schedule)</label>
        {!f.allDay && <><label><span className="sv-label">Start</span><input className="sv-input" value={f.start} onChange={x => setF({ ...f, start: x.target.value })} data-testid="ev-start" /></label>
          <label><span className="sv-label">End</span><input className="sv-input" value={f.end} onChange={x => setF({ ...f, end: x.target.value })} data-testid="ev-end" /></label></>}
        <label><span className="sv-label">Repeats</span><select className="sv-input" value={f.recur} onChange={x => setF({ ...f, recur: x.target.value as Recur })} data-testid="ev-recur"><option value="none">Does not repeat</option><option value="daily">Every weekday</option><option value="weekly">Weekly</option><option value="monthly">Monthly (same date)</option></select></label>
        {f.recur !== 'none' && <label><span className="sv-label">Until (optional)</span><input type="date" className="sv-input" value={f.until || ''} onChange={x => setF({ ...f, until: x.target.value || undefined })} /></label>}
        <label className="sm:col-span-2"><span className="sv-label">Notes</span><input className="sv-input" value={f.notes || ''} onChange={x => setF({ ...f, notes: x.target.value })} /></label>
      </div>
      {err && <p className="text-[13px] mt-2" style={{ color: 'var(--v7-red)' }} role="alert">{err}</p>}
      <div className="flex gap-2 mt-4">{!isNew && (del ? <><span className="text-[13px] self-center">Delete{f.recur !== 'none' ? ' the whole series' : ''}?</span><button type="button" className="sv-btn" onClick={() => { deleteEvent(e, actor.name, actor.role); toast(`Office event deleted: ${e.title}`); onClose(); }} data-testid="ev-delete-confirm">Delete</button></> : <button type="button" className="sv-btn" onClick={() => setDel(true)} data-testid="ev-delete">Delete…</button>)}
        <button type="button" className="sv-btn ml-auto" onClick={onClose}>Cancel</button><button type="button" className="sv-btn primary" onClick={save} data-testid="ev-save">Save event</button></div>
    </div></div>;
};

/** Practice-configurable schedulable columns: providers, team members and rooms. Also shown in Practice settings. */
export const ResourceManager: React.FC = () => {
  useMedTick(); const [actor] = useActor(); const { toast } = useSv(); const [l, setL] = useState<SchedResource[]>(resources); const [nm, setNm] = useState(''); const [role, setRole] = useState('RN'); const [kind, setKind] = useState<'person' | 'room'>('person');
  const staff = staffList().filter(s => s.active && !l.some(r => r.name === s.name));
  const commit = (next: SchedResource[], what: string) => { setL(next); saveResources(next, actor.name, actor.role, what); };
  return <div data-testid="resource-manager">
    <p className="sv-small sv-muted mb-2">Everyone and every room listed here can be booked from the schedule. Show or hide columns with “Columns” on the schedule.</p>
    <table className="sv-table"><thead><tr><th>Column</th><th>Kind</th><th>Role</th><th>Bookable</th><th /></tr></thead><tbody>{l.map((r, i) => <tr key={r.id} data-testid="res-row">
      <td><input className="sv-input" value={r.name} onChange={e => setL(l.map((x, j) => j === i ? { ...x, name: e.target.value } : x))} onBlur={() => commit(l, `Schedule column renamed: ${r.name}`)} aria-label="Column name" /></td>
      <td>{r.kind === 'room' ? 'Room' : 'Person'}</td><td>{r.kind === 'room' ? '—' : r.role}</td>
      <td><input type="checkbox" checked={r.schedulable} onChange={e => commit(l.map((x, j) => j === i ? { ...x, schedulable: e.target.checked } : x), `${r.name} ${e.target.checked ? 'bookable' : 'not bookable'}`)} aria-label={`${r.name} bookable`} /></td>
      <td>{r.custom && <button type="button" className="sv-link text-[12px]" onClick={() => commit(l.filter((_, j) => j !== i), `Schedule column removed: ${r.name}`)}>remove</button>}</td></tr>)}</tbody></table>
    <div className="flex flex-wrap items-end gap-2 mt-3">
      {staff.length > 0 && <label><span className="sv-label">Add a team member</span><select className="sv-input" style={{ width: 'auto' }} value="" onChange={e => { const s = staffList().find(x => x.name === e.target.value); if (s) { commit([...l, { id: `r-${s.id}`, kind: 'person', name: s.name, role: s.role, schedulable: true, custom: true }], `Schedule column added: ${s.name} (${s.role})`); toast(`${s.name} can now be booked`); } }} data-testid="res-add-staff"><option value="">Choose from staff…</option>{staff.map(s => <option key={s.id} value={s.name}>{s.name} · {s.role}</option>)}</select></label>}
      <label><span className="sv-label">Or add</span><select className="sv-input" style={{ width: 'auto' }} value={kind} onChange={e => setKind(e.target.value as any)}><option value="person">Person</option><option value="room">Room</option></select></label>
      <label className="flex-1 min-w-[160px]"><span className="sv-label">Name</span><input className="sv-input" value={nm} onChange={e => setNm(e.target.value)} placeholder={kind === 'room' ? 'e.g. Laser room' : 'e.g. Pat Lin, PA-C'} data-testid="res-name" /></label>
      {kind === 'person' && <label><span className="sv-label">Role</span><select className="sv-input" style={{ width: 'auto' }} value={role} onChange={e => setRole(e.target.value)}>{['Physician Assistant', 'Nurse Practitioner', 'RN', 'Medical assistant', 'Surgical Coordinator', 'Aesthetician', 'Patient Coordinator', 'Other'].map(x => <option key={x}>{x}</option>)}</select></label>}
      <button type="button" className="sv-btn" onClick={() => { if (!nm.trim()) return; commit([...l, { id: uid('res'), kind, name: nm.trim(), role: kind === 'room' ? 'Room' : role, schedulable: true, custom: true }], `Schedule column added: ${nm.trim()}`); setNm(''); }} data-testid="res-add">Add column</button>
    </div></div>;
};

const AddVisit: React.FC<{ initial: { provider: string; time: string; room?: string }; day: string; providers: string[]; onClose: () => void; onSaved: (v: MedVisit) => void }> = ({ initial, day, providers, onClose, onSaved }) => {
  const [actor] = useActor(); const types = activeVisitTypes();
  const [f, setF] = useState({ patientId: '', q: '', date: day, time: initial.time, provider: initial.provider, room: initial.room || MED_ROOMS[0], visitType: types[0]?.name || 'Follow-up visit', reason: '', notes: '', duration: types[0]?.durationMin || 30 });
  const [err, setErr] = useState(''); const pt = medRepo.patient(f.patientId);
  const matches = f.q.trim().length >= 2 ? medRepo.patients().filter(p => p.name.toLowerCase().includes(f.q.toLowerCase())).slice(0, 6) : [];
  const save = () => { if (!pt) { setErr('Choose a patient.'); return; } if (!/^\d{1,2}:\d{2}\s?(AM|PM)$/i.test(f.time.trim())) { setErr('Time must look like 09:30 AM.'); return; }
    const v: MedVisit & { notes?: string } = { id: uid('visit'), patientId: pt.id, date: f.date, time: f.time.trim().toUpperCase(), durationMin: f.duration, provider: f.provider, room: f.room, visitType: f.visitType, reason: f.reason, notes: f.notes.trim() || undefined, step: 'scheduled', problemIds: [], createdAt: new Date().toISOString(), createdBy: actor.name }; medRepo.saveVisit(v); onSaved(v); };
  const blk = modules().blockTime ? ascBlocks().find(b => b.date === f.date && norm(b.surgeon) === norm(f.provider) && /^\d{1,2}:\d{2}\s?(AM|PM)$/i.test(f.time.trim()) && at(f.time) < at(b.end) && at(f.time) + f.duration > at(b.start)) : undefined;
  const clash = /^\d{1,2}:\d{2}\s?(AM|PM)$/i.test(f.time.trim()) ? medRepo.visits().find(v => v.date === f.date && norm(v.provider) === norm(f.provider) && at(v.time) < at(f.time) + f.duration && at(v.time) + v.durationMin > at(f.time)) : undefined;
  return <div className="sv-flat sv-dlg"><DialogShell title="New appointment" subtitle={`${f.date ? new Date(f.date + 'T12:00').toLocaleDateString([], { weekday: 'long', month: 'long', day: 'numeric' }) : 'No date'} · ${f.time.replace(/^0/, '')} · ${f.provider}`} onClose={onClose} size="md" testId="add-visit-dialog" footer={<><button type="button" className="sv-btn" onClick={onClose}>Cancel</button><button type="button" className="sv-btn primary" onClick={save} data-testid="save-visit">Book appointment</button></>}>
    <div className="grid sm:grid-cols-2 gap-3">
      <div className="sm:col-span-2"><span className="sv-label">Patient</span>{pt ? <div className="flex items-center gap-2 text-[14px]"><b>{pt.name}</b><span className="sv-muted">DOB {pt.dob} · {ageFrom(pt.dob)}</span><button type="button" className="sv-link" onClick={() => setF({ ...f, patientId: '' })}>change</button></div> :
        <><div className="flex flex-wrap items-center gap-2"><input className="sv-input flex-1 min-w-[200px]" placeholder="Type 2+ letters of the name" value={f.q} onChange={e => setF({ ...f, q: e.target.value })} data-testid="visit-patient-search" /><AddNewPatientButton small label="New patient" onCreated={np => setF(x => ({ ...x, patientId: np.id, q: '' }))} /></div>{matches.map(m => <button key={m.id} type="button" className="block w-full text-left px-2 py-1.5 hover:bg-[#f3f4f6] text-[14px]" onClick={() => setF({ ...f, patientId: m.id, q: '' })} data-testid="visit-patient-match">{m.name} · DOB {m.dob}</button>)}{f.q.trim().length >= 2 && !matches.length && <p className="sv-small sv-muted mt-1">No match. Use “New patient” to create the chart.</p>}</>}</div>
      <div className="sm:col-span-2"><span className="sv-label">Visit type</span><div className="flex flex-wrap gap-1.5" role="radiogroup" aria-label="Visit type">{types.map(t => <button key={t.id} type="button" role="radio" aria-checked={f.visitType === t.name} onClick={() => setF({ ...f, visitType: t.name, duration: t.durationMin })} className="text-[13px] px-2.5 py-1.5 rounded" style={{ background: t.color, border: `1px solid ${f.visitType === t.name ? '#111418' : edgeOf(t.color)}`, fontWeight: f.visitType === t.name ? 700 : 400, boxShadow: f.visitType === t.name ? '0 0 0 1px #111418' : undefined }} data-testid={`vt-${t.id}`}>{t.name} · {t.durationMin}m</button>)}</div><p className="sv-small sv-muted mt-1">The visit type sets a default length; change it below to any number of minutes.</p></div>
      <label><span className="sv-label">Date</span><input type="date" className="sv-input" value={f.date} onChange={e => setF({ ...f, date: e.target.value })} /></label>
      <label><span className="sv-label">Time</span><input className="sv-input" value={f.time} onChange={e => setF({ ...f, time: e.target.value })} data-testid="visit-time" /></label>
      <VisitLength prefix="visit" start={f.time} duration={f.duration} onChange={n => setF(x => ({ ...x, duration: n }))} />
      <label><span className="sv-label">Provider</span><select className="sv-input" value={f.provider} onChange={e => setF({ ...f, provider: e.target.value })}>{providers.map(p => <option key={p}>{p}</option>)}</select></label>
      <label><span className="sv-label">Room</span><select className="sv-input" value={f.room} onChange={e => setF({ ...f, room: e.target.value })}>{Array.from(new Set([...MED_ROOMS, ...bookable().filter(r => r.kind === 'room').map(r => r.name)])).map(r => <option key={r}>{r}</option>)}</select></label>
      <label className="sm:col-span-2"><span className="sv-label">Reason for visit</span><input className="sv-input" value={f.reason} onChange={e => setF({ ...f, reason: e.target.value })} data-testid="visit-reason" /></label>
      <label className="sm:col-span-2"><span className="sv-label">Appointment notes</span><textarea className="sv-input" rows={2} value={f.notes} onChange={e => setF({ ...f, notes: e.target.value })} placeholder="e.g. Bring prior op report · interpreter (Spanish)" data-testid="visit-notes" style={{ width: '100%', resize: 'vertical' }} /></label>
      {blk && <p className="text-[13px] text-[var(--warn)] sm:col-span-2" data-testid="visit-in-block">Heads-up: {f.provider.replace(/,.*$/, '')} is at the ASC ({blk.start.replace(/^0/, '')}–{blk.end.replace(/^0/, '')}, {blk.room}) at this time.</p>}
      {clash && <p className="text-[13px] text-[var(--warn)] sm:col-span-2" data-testid="visit-clash">Double-booking: overlaps {clash.time.replace(/^0/, '')} · {medRepo.patient(clash.patientId)?.name} ({clash.visitType}). That’s allowed — both will show side by side.</p>}
      {reminderSettings().enabled && <p className="text-[12px] sv-muted sm:col-span-2">Confirmation reminders go out automatically until the patient confirms, plus one the day before (simulated).</p>}
      {err && <p className="text-[13px] text-[var(--crit)] sm:col-span-2">{err}</p>}
    </div></DialogShell></div>;
};
