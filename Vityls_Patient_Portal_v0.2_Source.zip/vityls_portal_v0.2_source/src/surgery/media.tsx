/*
 * Surgery.Vityls v0.3 · Body charts & clinical photos (surgeon workflow).
 *  - Body charts: standard diagrams (diagrams.ts). The surgeon picks one, draws and writes freehand (pointer events:
 *    finger, stylus or mouse), saves it to the patient record with date, author and chart type, and can reopen and edit
 *    it later (each save is a new version; earlier versions are kept). Saved charts are documents in the chart that the
 *    care team can view; v0.4: anyone on the care team can draw.
 *  - Clinical photos: take with the tablet camera or upload, mark BEFORE or AFTER and the date, store in the patient
 *    record. View one full screen, or compare 2 (side by side) or 3–4 (four squares) full screen.
 *    v0.4: open to the whole care team (capture and review); every add, change and view is audited.
 * Test build: stored in this browser (photos downscaled to ≤1280 px JPEG). Henry: photos belong in encrypted object
 * storage (S3 + KMS) behind a practice-staff policy (v0.4; was surgeon-only in v0.3), with signed short-lived URLs and access logging; never in the DB row.
 * The seeded photos are generated illustrations stamped EXAMPLE DATA · FICTIONAL · NOT A REAL PERSON.
 */
import React, { useEffect, useMemo, useRef, useState } from 'react';
import { X, Camera, Upload, Lock, Undo2, Trash2, Type, Columns2, Grid2x2, Square, Plus } from 'lucide-react';
import { repo } from '../v6/dataLayer';
import { medRepo, MedPatient, patientKey, uid, isoDay, addDays, usDate, fmtDateTime } from '../med/record';
import { useActor, useMedTick } from '../med/ui';
import { svRead, svWrite, seedHooks } from './store';
import { DIAGRAMS, diagram, synthPhotoSvg, svgUrl, SynthSpec } from './diagrams';
import { useSv } from './ui';
import { R } from './nightingale';
import { Ico } from './icons';

/* ---------------- access ---------------- */
/** v0.4 (Kevin): photos and body charts are open to the whole care team on the shared tablet. The same person often takes
 *  the pre- and post-op photos; surgeons review them with the patient. Every add, change and view stays audited.
 *  Only the AI is excluded. (Henry: still a server-side policy, but practice staff rather than surgeon-only.) */
export const PHOTO_ROLES = ['*'];
const notAi = (role: string) => !/^(ai|nightingale)/i.test((role || '').trim());
export const canSeePhotos = (role: string) => notAi(role);
export const canDrawCharts = (role: string) => notAi(role);

/* ---------------- body charts ---------------- */
export interface Stroke { c: string; w: number; pts: number[] }
export interface ChartText { x: number; y: number; t: string; c: string }
export interface BodyChartRec { id: string; seriesId: string; version: number; patientId: string; visitId?: string; diagram: string; title: string; strokes: Stroke[]; texts: ChartText[]; by: string; role: string; at: string; example?: boolean }
const allCharts = () => svRead<BodyChartRec[]>('body-charts', []);
/** Latest version of each chart for the patient, newest first. */
export const bodyCharts = (pid: string) => { const l = allCharts().filter(c => c.patientId === pid); const latest = new Map<string, BodyChartRec>(); l.forEach(c => { const x = latest.get(c.seriesId); if (!x || c.version > x.version) latest.set(c.seriesId, c); }); return [...latest.values()].sort((a, b) => b.at.localeCompare(a.at)); };
export const chartVersions = (seriesId: string) => allCharts().filter(c => c.seriesId === seriesId).sort((a, b) => b.version - a.version);
export const bodyChart = (id: string) => allCharts().find(c => c.id === id);
export function saveBodyChart(x: Omit<BodyChartRec, 'id' | 'version' | 'at' | 'seriesId'> & { seriesId?: string }): BodyChartRec {
  if (!canDrawCharts(x.role)) throw new Error('Nightingale cannot draw body charts.');
  if (!x.strokes.length && !x.texts.length) throw new Error('Draw or write something first.');
  const prev = x.seriesId ? chartVersions(x.seriesId)[0] : undefined;
  const rec: BodyChartRec = { ...x, id: uid('bc'), seriesId: x.seriesId || uid('bcs'), version: (prev?.version || 0) + 1, at: new Date().toISOString() };
  svWrite('body-charts', [...allCharts(), rec]);
  repo.audit({ caseId: patientKey(x.patientId), user: x.by, role: x.role, action: 'bodychart.save', detail: `Body chart “${x.title}” (${diagram(x.diagram).label}) saved as version ${rec.version} · ${x.strokes.length} stroke(s), ${x.texts.length} label(s)${x.visitId ? ` · visit ${x.visitId}` : ''}` });
  return rec;
}

/* ---------------- photos ---------------- */
export type Phase = 'before' | 'after';
export interface PhotoRec { id: string; patientId: string; visitId?: string; src?: string; synth?: SynthSpec; phase: Phase; date: string; area: string; view: string; note: string; by: string; role: string; at: string; example?: boolean }
const allPhotos = () => svRead<PhotoRec[]>('photos', []);
/** Never call this to render without the role gate (PhotoGate). */
export const photosOf = (pid: string) => allPhotos().filter(p => p.patientId === pid).sort((a, b) => b.date.localeCompare(a.date) || b.at.localeCompare(a.at));
export const photoCount = (pid: string) => allPhotos().filter(p => p.patientId === pid).length;
export const mediaForVisit = (visitId: string) => allPhotos().some(p => p.visitId === visitId) || allCharts().some(c => c.visitId === visitId);
export const photoSrc = (p: PhotoRec) => p.src || (p.synth ? svgUrl(synthPhotoSvg(p.synth)) : '');
export function addPhoto(x: Omit<PhotoRec, 'id' | 'at'>): PhotoRec {
  if (!canSeePhotos(x.role)) throw new Error('Nightingale cannot add or change clinical photos.');
  const rec: PhotoRec = { ...x, id: uid('ph'), at: new Date().toISOString() };
  try { svWrite('photos', [...allPhotos(), rec]); } catch { throw new Error('This browser’s test storage is full. Delete test photos or reset test data (?reset-test-data).'); }
  repo.audit({ caseId: patientKey(x.patientId), user: x.by, role: x.role, action: 'photo.add', detail: `Clinical photo added · ${x.phase.toUpperCase()} · ${usDate(x.date)} · ${x.area}${x.view ? ` · ${x.view}` : ''}` });
  return rec;
}
export function updatePhoto(id: string, patch: Partial<Pick<PhotoRec, 'phase' | 'date' | 'area' | 'view' | 'note'>>, by: string, role: string) {
  if (!canSeePhotos(role)) throw new Error('Nightingale cannot add or change clinical photos.');
  const l = allPhotos(); const p = l.find(x => x.id === id); if (!p) return; svWrite('photos', l.map(x => x.id === id ? { ...x, ...patch } : x));
  repo.audit({ caseId: patientKey(p.patientId), user: by, role, action: 'photo.update', detail: `Photo ${usDate(p.date)} ${p.area} updated: ${Object.entries(patch).map(([k, v]) => `${k} → ${v}`).join(', ')}` });
}
/** Downscale a camera/upload file to a JPEG data URL (≤1280 px) so the test build can keep it in browser storage. */
export function fileToJpeg(f: File, max = 1280): Promise<string> {
  return new Promise((res, rej) => { const url = URL.createObjectURL(f); const img = new Image(); img.onload = () => { const k = Math.min(1, max / Math.max(img.width, img.height)); const c = document.createElement('canvas'); c.width = Math.round(img.width * k); c.height = Math.round(img.height * k); c.getContext('2d')!.drawImage(img, 0, 0, c.width, c.height); URL.revokeObjectURL(url); res(c.toDataURL('image/jpeg', 0.82)); }; img.onerror = () => { URL.revokeObjectURL(url); rej(new Error('That file is not an image this browser can read.')); }; img.src = url; });
}
export const AREAS = ['Face', 'Eyes / lids', 'Nose', 'Ears', 'Neck', 'Breast / chest', 'Abdomen', 'Back / flanks', 'Arms', 'Thighs / legs', 'Buttocks', 'Hands', 'Genital region', 'Other'];
export const VIEWS = ['Frontal', 'Oblique right', 'Oblique left', 'Profile right', 'Profile left', 'Close-up', 'Posterior'];

/** v0.4: everyone on the care team passes; only an AI session would see the lock. */
export const PhotoGate: React.FC<{ p: MedPatient; where: string; children: React.ReactNode }> = ({ p, where, children }) => {
  const [actor] = useActor(); const ok = canSeePhotos(actor.role); const logged = useRef('');
  useEffect(() => { if (!ok && logged.current !== actor.name + where) { logged.current = actor.name + where; repo.audit({ caseId: patientKey(p.id), user: actor.name, role: actor.role, action: 'photo.denied', detail: `Clinical photos not shown (${where}): surgeon-only` }); } }, [ok, actor.name, actor.role, p.id, where]);
  if (ok) return <>{children}</>;
  return <div className="sv-lock" data-testid="photo-gate-denied"><Lock size={18} /><div><b>Clinical photos are not available to this session.</b><div className="sv-small sv-muted">{actor.name} ({actor.role}) can’t view or add photos for {p.name}. {photoCount(p.id)} photo{photoCount(p.id) === 1 ? '' : 's'} on file. This attempt is recorded in the audit trail. A surgeon opens them in the visit workflow › Charts &amp; photos.</div></div></div>;
};

/* ---------------- body-chart rendering + drawing ---------------- */
const ptsToD = (p: number[]) => { if (p.length < 2) return ''; let d = `M${p[0]} ${p[1]}`; for (let i = 2; i < p.length; i += 2) d += ` L${p[i]} ${p[i + 1]}`; if (p.length === 2) d += ` L${p[0] + 0.1} ${p[1] + 0.1}`; return d; };
export const ChartSvg: React.FC<{ c?: Pick<BodyChartRec, 'diagram' | 'strokes' | 'texts'>; diagramId?: string; className?: string; title?: string; children?: React.ReactNode; svgRef?: React.Ref<SVGSVGElement>; style?: React.CSSProperties } & React.SVGProps<SVGSVGElement>> = ({ c, diagramId, className, title, children, svgRef, style, ...rest }) => {
  const d = diagram(c?.diagram || diagramId || ''); const inner = useMemo(() => d.svg(), [d]);
  return <svg ref={svgRef} viewBox="0 0 600 800" className={className} style={{ background: '#fff', ...style }} role="img" aria-label={title || d.label} {...rest}>
    <g dangerouslySetInnerHTML={{ __html: inner }} />
    {c?.strokes.map((s, i) => <path key={i} d={ptsToD(s.pts)} fill="none" stroke={s.c} strokeWidth={s.w} strokeLinecap="round" strokeLinejoin="round" />)}
    {c?.texts.map((t, i) => <text key={i} x={t.x} y={t.y} fill={t.c} fontSize={22} fontFamily="'Source Sans 3', sans-serif" fontWeight={600}>{t.t}</text>)}
    {children}
  </svg>;
};
const INKS = [{ c: '#111418', n: 'Black' }, { c: '#b42318', n: 'Red' }, { c: '#1d4ed8', n: 'Blue' }, { c: '#047857', n: 'Green' }];
const WIDTHS = [2.5, 5, 10];

/** Full-screen drawing sheet. Pointer events (finger / stylus / mouse); text tool for typed labels. */
export const BodyChartEditor: React.FC<{ p: MedPatient; visitId?: string; diagramId: string; from?: BodyChartRec; onClose: (saved?: BodyChartRec) => void }> = ({ p, visitId, diagramId, from, onClose }) => {
  const [actor] = useActor(); const { toast } = useSv(); const can = canDrawCharts(actor.role);
  const [strokes, setStrokes] = useState<Stroke[]>(from?.strokes || []); const [texts, setTexts] = useState<ChartText[]>(from?.texts || []);
  const [ink, setInk] = useState(INKS[1].c); const [w, setW] = useState(WIDTHS[1]); const [tool, setTool] = useState<'pen' | 'text'>('pen');
  const [title, setTitle] = useState(from?.title || `${diagram(diagramId).label} · plan`); const [pending, setPending] = useState<{ x: number; y: number } | null>(null); const [pt, setPt] = useState('');
  const [history, setHistory] = useState<('s' | 't')[]>([]);
  const svg = useRef<SVGSVGElement>(null); const cur = useRef<Stroke | null>(null); const [, force] = useState(0);
  const toXY = (e: React.PointerEvent) => { const s = svg.current!; const m = s.getScreenCTM(); if (!m) return [0, 0]; const q = s.createSVGPoint(); q.x = e.clientX; q.y = e.clientY; const r = q.matrixTransform(m.inverse()); return [Math.round(r.x * 10) / 10, Math.round(r.y * 10) / 10]; };
  const down = (e: React.PointerEvent) => { if (!can) return; const [x, y] = toXY(e); if (tool === 'text') { setPending({ x, y }); setPt(''); return; } (e.target as Element).setPointerCapture?.(e.pointerId); cur.current = { c: ink, w: e.pointerType === 'pen' && e.pressure ? Math.max(1.5, w * (0.5 + e.pressure)) : w, pts: [x, y] }; force(n => n + 1); };
  const move = (e: React.PointerEvent) => { if (!cur.current) return; const [x, y] = toXY(e); const p = cur.current.pts; const dx = x - p[p.length - 2], dy = y - p[p.length - 1]; if (dx * dx + dy * dy < 4) return; p.push(x, y); force(n => n + 1); };
  const up = () => { if (!cur.current) return; const s = cur.current; cur.current = null; setStrokes(l => [...l, s]); setHistory(h => [...h, 's']); };
  const addText = () => { if (pending && pt.trim()) { setTexts(l => [...l, { x: pending.x, y: pending.y, t: pt.trim(), c: ink }]); setHistory(h => [...h, 't']); } setPending(null); setPt(''); };
  const undo = () => { const last = history[history.length - 1]; if (!last) { if (strokes.length) setStrokes(l => l.slice(0, -1)); return; } setHistory(h => h.slice(0, -1)); if (last === 's') setStrokes(l => l.slice(0, -1)); else setTexts(l => l.slice(0, -1)); };
  const save = () => { try { const rec = saveBodyChart({ patientId: p.id, visitId, diagram: diagramId, title: title.trim() || diagram(diagramId).label, strokes, texts, by: actor.name, role: actor.role, seriesId: from?.seriesId }); toast(`Body chart saved to ${p.name}’s record (version ${rec.version}).`); onClose(rec); } catch (e) { toast((e as Error).message); } };
  useEffect(() => { const f = (e: KeyboardEvent) => { if (e.key === 'Escape' && !pending) onClose(); if ((e.metaKey || e.ctrlKey) && e.key === 'z') { e.preventDefault(); undo(); } }; window.addEventListener('keydown', f); return () => window.removeEventListener('keydown', f); });
  const live = cur.current;
  return <div className="sv-draw" role="dialog" aria-modal="true" aria-label="Body chart drawing" data-testid="bodychart-editor">
    <div className="sv-draw-bar">
      <b className="inline-flex items-center gap-1.5"><Ico k="bodychart" size={16} />{diagram(diagramId).label}</b><span className="sv-muted sv-small">{p.name}{from ? ` · editing v${from.version} → new version` : ''}</span>
      <input className="sv-input" style={{ width: 240, minHeight: 34 }} value={title} onChange={e => setTitle(e.target.value)} aria-label="Chart title" data-testid="bodychart-title" />
      <span className="sv-draw-tools" role="toolbar" aria-label="Pen">
        {INKS.map(k => <button key={k.c} type="button" className={`sw ${ink === k.c ? 'on' : ''}`} style={{ background: k.c }} onClick={() => setInk(k.c)} aria-label={`${k.n} ink`} aria-pressed={ink === k.c} />)}
        {WIDTHS.map(x => <button key={x} type="button" className={`wd ${w === x && tool === 'pen' ? 'on' : ''}`} onClick={() => { setW(x); setTool('pen'); }} aria-label={`Pen ${x}px`} aria-pressed={w === x && tool === 'pen'}><i style={{ width: x + 2, height: x + 2 }} /></button>)}
        <button type="button" className={`tl ${tool === 'text' ? 'on' : ''}`} onClick={() => setTool(tool === 'text' ? 'pen' : 'text')} aria-pressed={tool === 'text'} data-testid="bodychart-text-tool"><Type size={15} />Text</button>
        <button type="button" className="tl" onClick={undo} data-testid="bodychart-undo"><Undo2 size={15} />Undo</button>
        <button type="button" className="tl" onClick={() => { setStrokes([]); setTexts([]); setHistory([]); }}><Trash2 size={15} />Clear</button>
      </span>
      <span className="ml-auto flex gap-2"><button type="button" className="sv-btn" onClick={() => onClose()}>Cancel</button><button type="button" className="sv-btn primary" onClick={save} disabled={!can} data-testid="bodychart-save">Save to record</button></span>
    </div>
    {!can && <p className="sv-banner m-2">View only.</p>}
    <div className="sv-draw-stage">
      <ChartSvg svgRef={svg} c={{ diagram: diagramId, strokes: live ? [...strokes, live] : strokes, texts }} className="sv-draw-svg" style={{ touchAction: 'none', cursor: tool === 'text' ? 'text' : 'crosshair' }} onPointerDown={down} onPointerMove={move} onPointerUp={up} onPointerCancel={up} onPointerLeave={up} data-testid="bodychart-canvas">
        {pending && <circle cx={pending.x} cy={pending.y} r={5} fill={ink} />}
      </ChartSvg>
      {pending && <div className="sv-draw-text"><input autoFocus className="sv-input" value={pt} onChange={e => setPt(e.target.value)} onKeyDown={e => { if (e.key === 'Enter') addText(); if (e.key === 'Escape') setPending(null); }} placeholder="Type a label, Enter to place" data-testid="bodychart-text-input" /><button type="button" className="sv-btn sm primary" onClick={addText}>Place</button></div>}
    </div>
    <div className="sv-draw-foot sv-small sv-muted">Draw with a finger, stylus or mouse. Text tool: tap where the label goes. Saved with your name, the date and the chart type; editing later keeps every earlier version.</div>
  </div>;
};

/* ---------------- photo viewer: 1 full / 2 side by side / 3–4 four squares ---------------- */
export const PhotoViewer: React.FC<{ p: MedPatient; ids: string[]; onClose: () => void }> = ({ p, ids: start, onClose }) => {
  useMedTick(); const [actor] = useActor(); const { toast } = useSv(); const [ids, setIds] = useState(start.slice(0, 4)); const [tray, setTray] = useState(start.length < 2);
  const all = photosOf(p.id); const shown = ids.map(id => all.find(x => x.id === id)).filter(Boolean) as PhotoRec[];
  useEffect(() => { repo.audit({ caseId: patientKey(p.id), user: actor.name, role: actor.role, action: 'photo.view', detail: `Viewed ${shown.length} clinical photo(s) full screen: ${shown.map(x => `${x.phase} ${usDate(x.date)}`).join(', ')}` }); }, [ids.join(',')]); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => { const f = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose(); }; window.addEventListener('keydown', f); return () => window.removeEventListener('keydown', f); }, [onClose]);
  if (!canSeePhotos(actor.role)) return null;
  const n = shown.length; const layout = n <= 1 ? 'one' : n === 2 ? 'two' : 'four';
  return <div className="sv-pv" role="dialog" aria-modal="true" aria-label="Clinical photos" data-testid="photo-viewer" data-layout={layout}>
    <div className="sv-pv-bar">
      <b>{p.name}</b><span className="opacity-70">Clinical photos · {n} of 4</span>
      <span className="opacity-70 inline-flex items-center gap-1">{n <= 1 ? <Square size={14} /> : n === 2 ? <Columns2 size={14} /> : <Grid2x2 size={14} />}{n <= 1 ? 'Full screen' : n === 2 ? 'Side by side' : 'Four squares'}</span>
      <span className="ml-auto flex gap-2">{n < 4 && <button type="button" className="sv-pv-btn" onClick={() => setTray(t => !t)} data-testid="pv-add"><Plus size={15} />{tray ? 'Hide photos' : 'Add a photo to compare'}</button>}<button type="button" className="sv-pv-btn" onClick={onClose} aria-label="Close" data-testid="pv-close"><X size={16} />Close</button></span>
    </div>
    <div className={`sv-pv-grid ${layout}`}>
      {shown.map(x => <figure key={x.id} className="sv-pv-cell" data-testid="pv-cell">
        <img src={photoSrc(x)} alt={`${x.phase} photo ${usDate(x.date)} ${x.area}`} />
        <figcaption><span className={`ph ${x.phase}`}>{x.phase === 'before' ? 'BEFORE' : 'AFTER'}</span><b>{usDate(x.date)}</b><span>{x.area}{x.view ? ` · ${x.view}` : ''}</span>{x.example && <span className="ex">EXAMPLE DATA</span>}
          {n === 1 && <span className="edit"><button type="button" onClick={() => { updatePhoto(x.id, { phase: x.phase === 'before' ? 'after' : 'before' }, actor.name, actor.role); toast('Marked ' + (x.phase === 'before' ? 'after' : 'before') + '.'); }} data-testid="pv-toggle-phase">Mark {x.phase === 'before' ? 'after' : 'before'}</button><input type="date" value={x.date} onChange={e => e.target.value && updatePhoto(x.id, { date: e.target.value }, actor.name, actor.role)} aria-label="Photo date" /></span>}
          {n > 1 && <button type="button" className="rm" onClick={() => setIds(ids.filter(i => i !== x.id))} aria-label="Remove from comparison">×</button>}</figcaption>
      </figure>)}
      {n === 3 && <div className="sv-pv-cell empty"><button type="button" onClick={() => setTray(true)}><Plus size={22} />Add a fourth photo</button></div>}
    </div>
    {tray && n < 4 && <div className="sv-pv-tray" data-testid="pv-tray">{all.filter(x => !ids.includes(x.id)).map(x => <button key={x.id} type="button" onClick={() => { const next = [...ids, x.id]; setIds(next); if (next.length >= 4) setTray(false); }} data-testid="pv-tray-item"><img src={photoSrc(x)} alt="" /><span className={`ph ${x.phase}`}>{x.phase === 'before' ? 'B' : 'A'}</span><span className="d">{usDate(x.date)}</span></button>)}{all.length === ids.length && <span className="opacity-70 text-[13px] px-2">No other photos for this patient.</span>}</div>}
  </div>;
};

/* ---------------- gallery + capture ---------------- */
export const PhotoGallery: React.FC<{ p: MedPatient; visitId?: string; compact?: boolean }> = ({ p, visitId, compact }) => {
  useMedTick(); const [actor] = useActor(); const { toast } = useSv();
  const [phase, setPhase] = useState<Phase>('before'); const [date, setDate] = useState(isoDay()); const [area, setArea] = useState('Face'); const [view, setView] = useState('Frontal');
  const [filter, setFilter] = useState<'all' | Phase>('all'); const [sel, setSel] = useState<string[]>([]); const [open, setOpen] = useState<string[] | null>(null); const [busy, setBusy] = useState(false);
  const all = photosOf(p.id); const list = all.filter(x => filter === 'all' || x.phase === filter);
  const onFiles = async (fl: FileList | null) => { if (!fl?.length) return; setBusy(true); let n = 0; for (const f of Array.from(fl).slice(0, 8)) { try { const src = await fileToJpeg(f); addPhoto({ patientId: p.id, visitId, src, phase, date, area, view, note: '', by: actor.name, role: actor.role }); n++; } catch (e) { toast((e as Error).message); } } setBusy(false); if (n) toast(`${n} photo${n === 1 ? '' : 's'} added · ${phase.toUpperCase()} · ${usDate(date)}.`); };
  const toggle = (id: string) => setSel(s => s.includes(id) ? s.filter(x => x !== id) : s.length >= 4 ? s : [...s, id]);
  const byDate = list.reduce<Record<string, PhotoRec[]>>((m, x) => { (m[x.date] = m[x.date] || []).push(x); return m; }, {});
  return <div data-testid="photo-gallery">
    <div className="sv-cap" data-testid="photo-capture">
      <div className="sv-seg" role="radiogroup" aria-label="Before or after">{(['before', 'after'] as Phase[]).map(x => <button key={x} type="button" role="radio" aria-checked={phase === x} className={phase === x ? `on ${x}` : ''} onClick={() => setPhase(x)} data-testid={`cap-${x}`}>{x === 'before' ? 'Before' : 'After'}</button>)}</div>
      <label><span className="sv-label">Date</span><input type="date" className="sv-input" value={date} onChange={e => setDate(e.target.value || isoDay())} data-testid="cap-date" /></label>
      <label><span className="sv-label">Area</span><select className="sv-input" value={area} onChange={e => setArea(e.target.value)}>{AREAS.map(a => <option key={a}>{a}</option>)}</select></label>
      <label><span className="sv-label">View</span><select className="sv-input" value={view} onChange={e => setView(e.target.value)}>{VIEWS.map(a => <option key={a}>{a}</option>)}</select></label>
      <label className="sv-btn primary sv-file"><Camera size={16} />Take photo<input type="file" accept="image/*" capture="environment" onChange={e => { void onFiles(e.target.files); e.target.value = ''; }} data-testid="cap-camera" /></label>
      <label className="sv-btn sv-file"><Upload size={16} />Upload<input type="file" accept="image/*" multiple onChange={e => { void onFiles(e.target.files); e.target.value = ''; }} data-testid="cap-upload" /></label>
      {busy && <span className="sv-small sv-muted">Saving…</span>}
    </div>
    <div className="flex flex-wrap items-center gap-2 mt-3 mb-2">
      <div className="sv-seg sm">{(['all', 'before', 'after'] as const).map(x => <button key={x} type="button" className={filter === x ? 'on' : ''} onClick={() => setFilter(x)}>{x === 'all' ? `All ${all.length}` : `${x === 'before' ? 'Before' : 'After'} ${all.filter(y => y.phase === x).length}`}</button>)}</div>
      <span className="sv-small sv-muted">Tap a photo to open it full screen. Tick up to 4 to compare.</span>
      <button type="button" className="sv-btn sm primary ml-auto" disabled={sel.length < 1} onClick={() => setOpen(sel)} data-testid="photo-compare">Compare{sel.length ? ` (${sel.length})` : ''}</button>
      {sel.length > 0 && <button type="button" className="sv-link sv-small" onClick={() => setSel([])}>clear</button>}
    </div>
    {!list.length ? <p className="sv-muted text-[13px]">No photos yet. Take or upload one above.</p> : Object.entries(byDate).map(([d, xs]) => <div key={d} className="mb-2"><div className="sv-small sv-muted mb-1">{usDate(d)}</div>
      <div className={`sv-thumbs ${compact ? 'compact' : ''}`}>{xs.map(x => <div key={x.id} className={`sv-thumb ${sel.includes(x.id) ? 'sel' : ''}`} data-testid="photo-thumb">
        <button type="button" className="img" onClick={() => setOpen([x.id])} aria-label={`Open ${x.phase} photo ${usDate(x.date)} ${x.area}`}><img src={photoSrc(x)} alt="" loading="lazy" /></button>
        <span className={`ph ${x.phase}`}>{x.phase === 'before' ? 'Before' : 'After'}</span>
        <label className="ck"><input type="checkbox" checked={sel.includes(x.id)} onChange={() => toggle(x.id)} aria-label="Select for comparison" data-testid="photo-select" /></label>
        <div className="cap">{x.area} · {x.view}</div>
      </div>)}</div></div>)}
    {open && <PhotoViewer p={p} ids={open} onClose={() => setOpen(null)} />}
  </div>;
};

/* ---------------- body charts list + picker ---------------- */
export const BodyChartsSection: React.FC<{ p: MedPatient; visitId?: string }> = ({ p, visitId }) => {
  useMedTick(); const [actor] = useActor(); const { openPanel } = useSv(); const can = canDrawCharts(actor.role);
  const [edit, setEdit] = useState<{ d: string; from?: BodyChartRec } | null>(null); const saved = bodyCharts(p.id);
  const groups = Array.from(new Set(DIAGRAMS.map(d => d.group)));
  return <div data-testid="bodycharts">
    {saved.length > 0 && <><div className="sv-h">On file for {p.name.split(' ')[0]} ({saved.length})</div>
      <div className="sv-charts-saved">{saved.map(c => <div key={c.id} className="sv-chart-card" data-testid="bodychart-saved">
        <button type="button" onClick={() => can ? setEdit({ d: c.diagram, from: c }) : openPanel(R('bodychart', c.title, p.id, c.id))} aria-label={`${can ? 'Edit' : 'View'} ${c.title}`}><ChartSvg c={c} className="w-full h-auto" /></button>
        <div className="t"><b>{c.title}</b><div className="sv-muted sv-small">{diagram(c.diagram).label} · v{c.version} · {c.by.replace(/,.*$/, '')} · {fmtDateTime(c.at)}{c.example ? ' · example' : ''}</div><div className="flex gap-3 sv-small">{can && <button type="button" className="sv-link" onClick={() => setEdit({ d: c.diagram, from: c })} data-testid="bodychart-edit">Edit</button>}<button type="button" className="sv-link" onClick={() => openPanel(R('bodychart', c.title, p.id, c.id))}>View</button></div></div>
      </div>)}</div></>}
    <div className="sv-h mt-3">{can ? 'New body chart · choose a diagram' : 'Standard diagrams'}</div>
    {!can && <p className="sv-small sv-muted mb-1">Surgeons draw on body charts. Saved charts are part of the record, so the care team can view them.</p>}
    {groups.map(g => <div key={g} className="mb-2"><div className="sv-small sv-muted mb-1">{g}</div><div className="sv-diagrams">{DIAGRAMS.filter(d => d.group === g).map(d => <button key={d.id} type="button" className="sv-diagram" disabled={!can} onClick={() => setEdit({ d: d.id })} data-testid={`diagram-${d.id}`}><ChartSvg diagramId={d.id} /><span>{d.label}</span></button>)}</div></div>)}
    {edit && <BodyChartEditor p={p} visitId={visitId} diagramId={edit.d} from={edit.from} onClose={() => setEdit(null)} />}
  </div>;
};

/** The station step: the surgeon's prominent body-chart and photo workspace. */
export const MediaStep: React.FC<{ p: MedPatient; visitId: string }> = ({ p, visitId }) => {
  useMedTick(); const [actor] = useActor();
  return <div className="sv-media" data-testid="st-media-body">
    <section className="sv-media-col"><h2 className="sv-media-h"><Ico k="bodychart" size={18} />Body charts</h2><p className="sv-small sv-muted mb-2">Draw and write on a standard diagram to explain the plan, then save it to the record.</p><BodyChartsSection p={p} visitId={visitId} /></section>
    <section className="sv-media-col"><h2 className="sv-media-h"><Ico k="photo" size={18} />Clinical photos</h2><p className="sv-small sv-muted mb-2">Before and after photos are part of the medical record. Anyone on the care team can take and review them; every view is recorded.</p>
      <PhotoGate p={p} where="visit workflow"><PhotoGallery p={p} visitId={visitId} /></PhotoGate></section>
    <p className="sv-small sv-muted" style={{ gridColumn: '1/-1' }}>Session: {actor.name} ({actor.role}). Seeded photos are generated illustrations marked EXAMPLE DATA, not real people.</p>
  </div>;
};

/** Prominent band at the top of the surgeon step. */
export const SurgeonMediaBand: React.FC<{ p: MedPatient; onOpen: () => void }> = ({ p, onOpen }) => {
  useMedTick(); const [actor] = useActor(); const ok = canSeePhotos(actor.role); const charts = bodyCharts(p.id); const photos = ok ? photosOf(p.id) : [];
  return <section className="sv-band" data-testid="surgeon-media-band">
    <div className="min-w-0"><div className="sv-band-k">Body charts &amp; photos</div><div className="text-[13.5px]">{charts.length} body chart{charts.length === 1 ? '' : 's'} · {ok ? `${photos.length} photo${photos.length === 1 ? '' : 's'} (${photos.filter(x => x.phase === 'before').length} before, ${photos.filter(x => x.phase === 'after').length} after)` : 'photos'}</div></div>
    {ok && photos.length > 0 && <div className="sv-band-strip" aria-hidden="true">{photos.slice(0, 4).map(x => <img key={x.id} src={photoSrc(x)} alt="" />)}</div>}
    <div className="flex flex-wrap gap-2 ml-auto"><button type="button" className="sv-btn primary" onClick={onOpen} data-testid="band-open"><Ico k="bodychart" size={15} />Draw on a body chart</button><button type="button" className="sv-btn primary" onClick={onOpen} data-testid="band-photos"><Camera size={15} />Photos &amp; compare</button></div>
  </section>;
};

/* ---------------- chart (records) + right panel ---------------- */
export const MediaRecords: React.FC<{ p: MedPatient }> = ({ p }) => {
  useMedTick(); const [actor] = useActor(); const { openPanel } = useSv(); const charts = bodyCharts(p.id); const ok = canSeePhotos(actor.role);
  return <div data-testid="rec-media"><div className="k">Body charts &amp; photos</div><ul>
    {charts.slice(0, 3).map(c => <li key={c.id}><button type="button" className="sv-rec-link" onClick={() => openPanel(R('bodychart', c.title, p.id, c.id))} data-testid="rec-bodychart"><Ico k="bodychart" /><span>{c.title}</span><span className="m">{usDate(c.at.slice(0, 10))}</span></button></li>)}
    {!charts.length && <li className="sv-muted sv-small px-1">No body charts yet</li>}
    <li><button type="button" className="sv-rec-link" onClick={() => openPanel(R('photos', 'Clinical photos', p.id))} data-testid="rec-photos">{ok ? <Ico k="photo" /> : <Lock size={14} className="sv-ico" />}<span>Clinical photos</span><span className="m">{ok ? `${photoCount(p.id)}` : 'not available'}</span></button></li>
  </ul></div>;
};
export const BodyChartPanel: React.FC<{ p: MedPatient; id?: string }> = ({ p, id }) => {
  useMedTick(); const [actor] = useActor(); const { openPanel } = useSv(); const [edit, setEdit] = useState(false);
  const list = bodyCharts(p.id); const c = (id && bodyChart(id)) || list[0];
  if (!c) return <p className="sv-muted">No body charts for this patient yet. Draw them in the visit workflow › Charts &amp; photos.</p>;
  const vers = chartVersions(c.seriesId);
  return <div data-testid="bodychart-panel">
    <ChartSvg c={c} className="w-full h-auto border border-[var(--line)]" />
    <p className="mt-2"><b>{c.title}</b></p><p className="sv-small sv-muted">{diagram(c.diagram).label} · version {c.version} of {vers.length} · {c.by} · {fmtDateTime(c.at)}{c.example ? ' · fictional example' : ''}</p>
    {canDrawCharts(actor.role) && <button type="button" className="sv-btn sm primary mt-2" onClick={() => setEdit(true)}>Edit (saves a new version)</button>}
    {vers.length > 1 && <div className="mt-3"><div className="sv-h">Versions</div>{vers.map(v => <button key={v.id} type="button" className="sv-link sv-small block" onClick={() => openPanel(R('bodychart', v.title, p.id, v.id))}>v{v.version} · {v.by.replace(/,.*$/, '')} · {fmtDateTime(v.at)}</button>)}</div>}
    {list.length > 1 && <div className="mt-3"><div className="sv-h">Other body charts</div>{list.filter(x => x.seriesId !== c.seriesId).map(x => <button key={x.id} type="button" className="sv-link sv-small block" onClick={() => openPanel(R('bodychart', x.title, p.id, x.id))}>{x.title} · {usDate(x.at.slice(0, 10))}</button>)}</div>}
    {edit && <BodyChartEditor p={p} diagramId={c.diagram} from={c} onClose={() => setEdit(false)} />}
  </div>;
};
export const PhotosPanel: React.FC<{ p: MedPatient }> = ({ p }) => <PhotoGate p={p} where="chart"><PhotoGallery p={p} compact /></PhotoGate>;

/* ---------------- fictional seed (EXAMPLE DATA) ---------------- */
seedHooks.push(() => {
  const T = isoDay(); const at = (d: string, hh = '10:00') => new Date(`${d}T${hh}:00`).toISOString();
  const PATEL = 'Sam Patel, MD', WHIT = 'Dana Whitfield, MD';
  const ph = (pid: string, by: string, d: string, phase: Phase, area: string, view: string, s: Omit<SynthSpec, 'phase' | 'date' | 'label'>): PhotoRec => ({ id: uid('ph'), patientId: pid, synth: { ...s, phase, date: usDate(d), label: `${area} · ${view}` }, phase, date: d, area, view, note: 'Fictional example photo (generated illustration).', by, role: 'Surgeon', at: at(d), example: true });
  svWrite('photos', [
    ph('MED-1001', PATEL, addDays(T, -30), 'before', 'Face', 'Frontal', { view: 'frontal', tone: 4, hair: 1, procedure: 'bleph' }),
    ph('MED-1001', PATEL, addDays(T, -30), 'before', 'Eyes / lids', 'Close-up', { view: 'eyes', tone: 4, hair: 1, procedure: 'bleph' }),
    ph('MED-1001', PATEL, addDays(T, -2), 'before', 'Eyes / lids', 'Close-up', { view: 'eyes', tone: 4, hair: 1, procedure: 'bleph' }),
    ph('MED-1001', PATEL, addDays(T, -2), 'before', 'Face', 'Frontal', { view: 'frontal', tone: 4, hair: 1, procedure: 'bleph' }),
    // Ellen's earlier office procedure (fictional, see surgical history sh-e4): a before/after pair so compare works on her chart too.
    ph('MED-1001', PATEL, addDays(T, -215), 'before', 'Eyes / lids', 'Close-up', { view: 'eyes', tone: 4, hair: 1, procedure: 'bleph' }),
    ph('MED-1001', PATEL, addDays(T, -190), 'after', 'Eyes / lids', 'Close-up', { view: 'eyes', tone: 4, hair: 1, procedure: 'bleph' }),
    ph('MED-1004', WHIT, addDays(T, -45), 'before', 'Face', 'Frontal', { view: 'frontal', tone: 1, hair: 4, procedure: 'facelift' }),
    ph('MED-1004', WHIT, addDays(T, -45), 'before', 'Face', 'Profile right', { view: 'profile', tone: 1, hair: 4, procedure: 'facelift' }),
    ph('MED-1004', WHIT, addDays(T, -1), 'after', 'Face', 'Frontal', { view: 'frontal', tone: 1, hair: 4, procedure: 'facelift' }),
    ph('MED-1004', WHIT, addDays(T, -1), 'after', 'Face', 'Profile right', { view: 'profile', tone: 1, hair: 4, procedure: 'facelift' }),
    ph('MED-1007', PATEL, addDays(T, -14), 'before', 'Nose', 'Profile right', { view: 'profile', tone: 2, hair: 2, procedure: 'rhino' }),
    ph('MED-1007', PATEL, addDays(T, -14), 'before', 'Face', 'Frontal', { view: 'frontal', tone: 2, hair: 2, procedure: 'rhino' }),
  ]);
  // Ellen: upper-lid excision marks on the Eyes diagram (fictional example by Dr. Patel at the consult).
  const ell = (cx: number): number[] => { const o: number[] = []; for (let i = 0; i <= 24; i++) { const a = Math.PI * 2 * i / 24; o.push(Math.round(cx + 80 * Math.cos(a)), Math.round(352 + 22 * Math.sin(a))); } return o; };
  const strokes: Stroke[] = [{ c: '#b42318', w: 4, pts: ell(165) }, { c: '#b42318', w: 4, pts: ell(435) }, { c: '#1d4ed8', w: 3, pts: [165, 330, 165, 230, 230, 200] }];
  svWrite('body-charts', [{ id: uid('bc'), seriesId: 'bcs-seed-ellen', version: 1, patientId: 'MED-1001', visitId: 'visit-e-old', diagram: 'eyes', title: 'Upper blepharoplasty · skin excision plan', strokes, texts: [{ x: 238, y: 205, t: '≈10 mm skin, both upper lids', c: '#1d4ed8' }, { x: 120, y: 560, t: 'Preserve brow position', c: '#111418' }], by: PATEL, role: 'Surgeon', at: at(addDays(T, -30), '10:40'), example: true }]);
});
