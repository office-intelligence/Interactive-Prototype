/*
 * Surgery.Vityls patient chart: one white canvas with bold headings, no stacked cards.
 * Left: a small timeline of past (and upcoming) events; one click opens the source in the right panel.
 * Centre: the living summary, written and kept current by Nightingale from recorded data, every line cited:
 * who / why / significant conditions / surgical history / major risks / active problems, plus what is worth the
 * surgeon's attention. The clinician initials it; Nightingale cannot. No score, no go/no-go.
 * Everything else (care team, caregivers, ASC, monitoring, journal, trends, meds, care plan, billing, audit) is a
 * right-panel pull from the Nightingale header, a citation or the "Also in this chart" line.
 */
import { isMedical } from '../edition';
import { quotesFor, quoteStatus, money } from './quotes';
import React, { useEffect, useRef, useState } from 'react';
import { isDeleteAdmin } from './patientAdmin';
import { Search } from 'lucide-react';
import { repo } from '../v6/dataLayer';
import { effectiveAllergy } from '../v7/allergy';
import { medRepo, MedPatient, patientKey, ageFrom, usDate, fmtDate, conditionLabel, isoDay, vitalsText } from '../med/record';
import { riskFlags, reviewState } from '../med/risk';
import { networkRepo } from '../med/network';
import { activeCaregivers } from '../med/portal';
import { getSettings } from '../med/settings';
import { useActor, useMedTick } from '../med/ui';
import { Ref, R, labSlips, slipRef, noteRef, relDay, todayVisit, nextAscCase, surgicalHistoryLines, STATION_LABEL, first, awaitingLabs } from './nightingale';
import { ascCasesFor, keptNotes, removeKeptNote, summaryInitials, initialSummary, modules, visitTypeDef, edgeOf } from './store';
import { HoldToInitial, useSv, hhmm, initialsOf } from './ui';
import { Ico, IconKind, KIND_ICON } from './icons';
import { AllergyVerify } from './allergy';
import { dxList, DX_STATUS_LABEL } from './v10/dx';
import { Avatar } from './v11/PatientPhoto';
import './v11/v11.css';
import { PinSign } from './sign';
import { ROLE_GROUP } from './staff';
import { lastFrom } from './nightingale';
import { ascPackets } from './asc';
import { coordinatorFor, coordinators, assignCoordinator, } from './staff';
import { CollectPayment, AccountBadge } from './payments';
import { MediaRecords } from './media';
import { AddNewPatientButton, PacketLine } from './newPatient';
import { DocumentsSection, DocsRecordLink, recordsNarrative, docsOf, docIcon } from './documents';
import { ContactNoteDialog, contactNotes, flaggedNotes } from './contactNotes';
import { HideDeleteDialog } from './patientAdmin';
import { allergyStatus } from './allergy';
import { EditProfileDialog, ProfileLine, SvPatient } from './profile';
import { NextApptLine } from './reminders';
import { UserCog, Mic, EyeOff, Sparkles } from 'lucide-react';

const RISK_TYPES = ['diabetes', 'heart', 'hypertension', 'osa', 'ckd', 'bleeding', 'lung'];
const short = (iso: string) => { const m = iso.match(/^(\d{4})-(\d{2})-(\d{2})/); return m ? `${m[2]}/${m[3]}/${m[1].slice(2)}` : iso; };
const fp = (s: string) => { let h = 5381; for (const c of s) h = ((h << 5) + h + c.charCodeAt(0)) >>> 0; return h.toString(16); };

/** v0.12 · Patients list row actions (moved from the chart header): Open chart, Hide…, Delete permanently… (admins). */
const RowMenu: React.FC<{ p: MedPatient; onHide: () => void; onDelete: () => void }> = ({ p, onHide, onDelete }) => {
  const { go } = useSv(); const [actor] = useActor(); const [open, setOpen] = useState(false); const ref = useRef<HTMLDivElement>(null); const admin = isDeleteAdmin(actor);
  useEffect(() => { if (!open) return; const f = (e: Event) => { if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false); }; document.addEventListener('pointerdown', f); return () => document.removeEventListener('pointerdown', f); }, [open]);
  return <div className="v7-menu" ref={ref} style={{ position: 'relative' }}><button type="button" className="sv-btn sm" aria-haspopup="menu" aria-expanded={open} aria-label={`Actions for ${p.name}`} onClick={() => setOpen(o => !o)} data-testid="pl-row-menu">⋯</button>
    {open && <div className="v7-menu-pop" role="menu" style={{ right: 0, left: 'auto', minWidth: 230 }} data-testid="pl-row-menu-pop">
      <button type="button" role="menuitem" onClick={() => { setOpen(false); go({ type: 'chart', pid: p.id }); }}>Open chart</button>
      <button type="button" role="menuitem" onClick={() => { setOpen(false); onHide(); }} data-testid="pl-hide">Hide chart…</button>
      <button type="button" role="menuitem" disabled={!admin} onClick={() => { setOpen(false); onDelete(); }} data-testid="pl-delete" style={admin ? { color: 'var(--crit)' } : { opacity: .5 }}>Delete permanently…</button>
      {!admin && <div className="sv-small sv-muted px-3 pb-2" data-testid="pl-delete-hint">Delete needs an administrator (Practice Manager, Practice Administrator or a provider with admin rights).</div>}
    </div>}</div>;
};
export const PatientList: React.FC = () => {
  useMedTick(); const { go, toast } = useSv(); const [actor] = useActor(); const [sel, setSel] = useState<string[]>([]); const [hd, setHd] = useState<{ ids: string[]; mode: 'hide' | 'delete' } | null>(null); const [q, setQ] = useState(''); const [payFor, setPayFor] = useState(''); const [fdx, setFdx] = useState(''); const [fpr, setFpr] = useState(''); const [fst, setFst] = useState<'all' | 'performed' | 'planned'>('all');
  const allP = medRepo.patients(); const dxs = Array.from(new Set(allP.flatMap(p => dxList(p).map(d => d.diagnosis)))).sort();
  const prs = Array.from(new Set(allP.flatMap(p => dxList(p).filter(d => !fdx || d.diagnosis === fdx).flatMap(d => d.procedures.map(x => x.name))))).sort();
  const filtering = !!fdx || !!fpr || fst !== 'all';
  const list = allP.filter(x => x.name.toLowerCase().includes(q.toLowerCase())).filter(x => !filtering || dxList(x).some(d => (!fdx || d.diagnosis === fdx) && (fpr || fst !== 'all' ? d.procedures.some(pr => (!fpr || pr.name === fpr) && (fst === 'all' || pr.status === fst)) : true)));
  return <div data-testid="sv-patient-list">
    <div className="flex items-end justify-between gap-3 flex-wrap mb-3"><div><h1 className="sv-title">Patients</h1><div className="sv-sub">{medRepo.patients().length} fictional charts · ask Nightingale by name, e.g. “open Ellen”</div></div>
      <div className="flex flex-wrap items-center gap-2"><AddNewPatientButton /><label className="relative w-[280px] max-w-full"><span className="sr-only">Search by name</span><Search size={15} className="absolute left-2.5 top-2.5 text-[var(--ink3)]" /><input className="sv-input !pl-8" placeholder="Search by name" value={q} onChange={e => setQ(e.target.value)} data-testid="patient-search" /></label></div></div>
    <div className="flex flex-wrap items-end gap-2 mb-3" data-testid="dx-filter">
      <label><span className="sv-label">Diagnosis / condition</span><select className="sv-input" style={{ width: 'auto', maxWidth: 280 }} value={fdx} onChange={e => { setFdx(e.target.value); setFpr(''); }} data-testid="dx-filter-dx"><option value="">All diagnoses</option>{dxs.map(d => <option key={d}>{d}</option>)}</select></label>
      <label><span className="sv-label">Procedure (optional)</span><select className="sv-input" style={{ width: 'auto', maxWidth: 260 }} value={fpr} onChange={e => setFpr(e.target.value)} data-testid="dx-filter-proc"><option value="">Any procedure</option>{prs.map(d => <option key={d}>{d}</option>)}</select></label>
      <label><span className="sv-label">Status</span><select className="sv-input" style={{ width: 'auto' }} value={fst} onChange={e => setFst(e.target.value as any)} data-testid="dx-filter-status"><option value="all">All</option><option value="performed">Procedure performed</option><option value="planned">Not performed</option></select></label>
      <span className="text-[14px] self-center" data-testid="dx-count"><b>{list.length}</b> patient{list.length === 1 ? '' : 's'}{filtering ? ' match' : ''}</span>
      {filtering && <button type="button" className="sv-link sv-small self-center" onClick={() => { setFdx(''); setFpr(''); setFst('all'); }} data-testid="dx-filter-clear">Clear filter</button>}</div>
    <table className="sv-table"><thead><tr><th style={{ width: 34 }}><input type="checkbox" aria-label="Select all" checked={list.length > 0 && list.every(x => sel.includes(x.id))} onChange={e => setSel(e.target.checked ? list.map(x => x.id) : [])} data-testid="pl-select-all" /></th><th>Patient</th><th>Age · sex</th><th>Surgeon</th><th>Diagnosis / Procedure</th><th>Next visit</th>{!isMedical && <th>Next surgery</th>}<th>Coordinator</th><th>Account</th><th style={{ width: 44 }}><span className="sr-only">Actions</span></th></tr></thead><tbody>
      {list.map(p => { const nv = medRepo.visits(p.id).find(v => v.date >= isoDay() && v.step !== 'complete'); const nc = nextAscCase(p.id); const a = effectiveAllergy(p.allergies, patientKey(p.id));
        return <tr key={p.id} className="cursor-pointer hover:bg-[var(--hover)]" onClick={() => go({ type: 'chart', pid: p.id })} data-testid={`patient-${p.id}`}><td onClick={e => e.stopPropagation()}><input type="checkbox" aria-label={`Select ${p.name}`} checked={sel.includes(p.id)} onChange={e => setSel(x => e.target.checked ? [...x, p.id] : x.filter(y => y !== p.id))} data-testid="pl-select" /></td><td><div className="flex items-center gap-2"><Avatar p={p} size={32} /><div><button type="button" className="font-semibold text-left hover:underline" onClick={e => { e.stopPropagation(); go({ type: 'chart', pid: p.id }); }}>{p.name}</button><div className="sv-muted sv-small">DOB {p.dob}</div></div></div></td><td>{ageFrom(p.dob)} · {p.sex}</td><td>{p.primaryProvider}</td><td data-testid="dx-cell">{dxList(p).length ? dxList(p).map(d => <div key={d.id} className="mb-1"><b className="font-semibold">{d.diagnosis}</b>{d.icd && <span className="sv-muted sv-small"> · {d.icd}</span>}{d.procedures.map(pr => <div key={pr.id} className="sv-small">{pr.name} · <span className={`v7-pill ${pr.status === 'performed' ? 'green' : 'gray'}`}>{DX_STATUS_LABEL[pr.status]}{pr.date && pr.status === 'performed' ? ` ${usDate(pr.date)}` : ''}</span></div>)}</div>) : <span className="sv-muted">—</span>}</td><td>{nv ? <>{nv.date === isoDay() ? 'Today' : usDate(nv.date)} {nv.time}<div className="sv-muted sv-small">{nv.visitType}</div></> : '—'}</td>{!isMedical && <td>{nc ? <>{usDate(nc.date)}<div className="sv-muted sv-small">{nc.procedure}</div></> : '—'}</td>}<td>{coordinatorFor(p.id)?.name || <span className="sv-muted">—</span>}</td><td><AccountBadge pid={p.id} />{(p as SvPatient).paymentType && <div className="sv-muted sv-small" data-testid="list-payment">{(p as SvPatient).paymentType}</div>}<div><button type="button" className="sv-link sv-small" onClick={e => { e.stopPropagation(); setPayFor(p.id); }} data-testid={`collect-${p.id}`}>Collect payment</button></div></td><td onClick={e => e.stopPropagation()}><RowMenu p={p} onHide={() => setHd({ ids: [p.id], mode: 'hide' })} onDelete={() => setHd({ ids: [p.id], mode: 'delete' })} /></td></tr>; })}
    </tbody></table>
    {sel.length > 0 && <div className="v12-bulk" data-testid="pl-bulk"><b>{sel.length} selected</b><button type="button" className="sv-btn sm" onClick={() => setHd({ ids: sel, mode: 'hide' })} data-testid="pl-bulk-hide">Hide…</button><button type="button" className="sv-btn sm danger" onClick={() => setHd({ ids: sel, mode: 'delete' })} disabled={!isDeleteAdmin(actor)} title={isDeleteAdmin(actor) ? undefined : 'Only an administrator can delete permanently'} data-testid="pl-bulk-delete">Delete permanently…</button><button type="button" className="sv-link text-[12.5px]" onClick={() => setSel([])}>Clear</button></div>}
    {hd && (() => { const ps = hd.ids.map(id => medRepo.patient(id)).filter(Boolean) as MedPatient[]; return ps.length ? <HideDeleteDialog p={ps[0]} list={ps} session={actor.name} initialMode={hd.mode} onClose={() => setHd(null)} onDone={m => { setHd(null); setSel([]); toast(m === 'delete' ? `${ps.length > 1 ? `${ps.length} charts` : `${ps[0].name}’s chart`} permanently deleted. The audit trail is kept.` : `${ps.length > 1 ? `${ps.length} charts` : `${ps[0].name}’s chart`} hidden. Restore in Practice › Patient records.`); }} /> : null; })()}
    {payFor && medRepo.patient(payFor) && <CollectPayment p={medRepo.patient(payFor)!} onClose={() => setPayFor('')} />}
  </div>;
};

/* ---------------- timeline ---------------- */
export interface Ev { date: string; title: string; sub?: string; ref: Ref; isNew?: boolean; icon: IconKind }
export function timeline(p: MedPatient): { upcoming: Ev[]; today: Ev[]; past: Ev[] } {
  const T = isoDay(); const up: Ev[] = []; const td: Ev[] = []; const past: Ev[] = [];
  if (modules().networkAsc) ascCasesFor(p.id).forEach(c => (c.date >= T ? up : past).push({ icon: 'surgery', date: c.date, title: `Surgery · ${c.procedure}`, sub: `${c.ascName.replace(/\s*\(.*\)/, '')} · ${c.status}`, ref: R('asc', 'ASC case', p.id, c.id) }));
  medRepo.visits(p.id).forEach(v => { const ev: Ev = { icon: 'visit', date: v.date, title: v.visitType, sub: `${v.provider.replace(/,.*$/, '')}${v.date === T ? ` · ${v.time} · ${STATION_LABEL[v.step]}` : v.date > T ? ` · ${v.time}` : medRepo.note(v.id)?.status === 'signed' ? ' · note signed' : ''}`, ref: noteRef(v) }; (v.date > T ? up : v.date === T ? td : past).push(ev); });
  labSlips(p.id).forEach(s => past.push({ icon: 'lab', date: s.date, title: `Lab slip · ${s.labs.map(l => l.test.replace('Hemoglobin A1c', 'A1c').replace('LDL cholesterol', 'LDL')).join(', ')}`, sub: s.labs.some(l => l.status === 'awaiting-review') ? 'awaiting review' : 'reviewed', ref: slipRef(s.date, p.id), isNew: s.labs.some(l => l.status === 'awaiting-review') }));
  medRepo.vitals(p.id).filter(v => !v.visitId).forEach(v => past.push({ icon: 'vitals', date: v.at.slice(0, 10), title: 'Vitals', sub: vitalsText(v).split(' · ').slice(0, 2).join(' · '), ref: R('vitals', 'Vitals', p.id) }));
  medRepo.messages(p.id).forEach(m => past.push({ icon: 'message', date: m.at.slice(0, 10), title: `Message · ${m.author.replace(/\s*\(.*\)/, '')}`, sub: m.text.slice(0, 42) + '…', ref: R('messages', 'Portal messages', p.id), isNew: m.from !== 'office' && medRepo.messages(p.id).slice(-1)[0]?.id === m.id }));
  if (modules().networkAsc) ascCasesFor(p.id).forEach(c => networkRepo.thread(c.id).forEach(m => past.push({ icon: 'asc', date: m.at.slice(0, 10), title: `ASC · ${m.fromOrg === 'asc' ? 'from the ASC' : 'from the office'}`, sub: m.text.slice(0, 42) + '…', ref: R('asc', 'ASC case', p.id, c.id) })));
  contactNotes(p.id).forEach(n => { const d = isoDay(new Date(n.contactAt)); const ev: Ev = { icon: 'contact', date: d, title: `${n.channel} · ${n.reason}`, sub: `${n.author.replace(/,.*$/, '')}${n.flagged && !n.reviewed ? ' · for review' : ''}`, ref: R('contactnotes', 'Contact notes', p.id, n.id), isNew: n.flagged && !n.reviewed }; (d === T ? td : past).push(ev); });
  quotesFor(p.id).forEach(q => { const v = q.versions[q.versions.length - 1]; const d = isoDay(new Date(v.createdAt)); past.push({ icon: 'invoice', date: d, title: `Price quote · ${q.number}${q.versions.length > 1 ? ` v${v.v}` : ''}`, sub: `${quoteStatus(q)} · ${money(v.total)}${v.procedure ? ` · ${v.procedure}` : ''} · estimate`, ref: R('quote', q.number, p.id, q.id), isNew: d === T }); });
  docsOf(p.id).forEach(dc => { const d = isoDay(new Date(dc.receivedAt)); const ev: Ev = { icon: docIcon(dc.type), date: d, title: `Document · ${dc.title}`, sub: `${dc.type} · ${dc.source.replace(/\s*\(.*\)/, '').replace(/\s*·.*$/, '')}`, ref: R('doc', dc.title, p.id, dc.id) }; (d === T ? td : past).push(ev); });
  const cp = medRepo.carePlan(p.id); if (cp?.published) past.push({ icon: 'careplan', date: cp.published.signedAt.slice(0, 10), title: `Care plan v${cp.published.version} signed`, sub: cp.published.signedBy.replace(/,.*$/, ''), ref: R('careplan', 'Care plan', p.id) });
  activeCaregivers(p.id).forEach(c => past.push({ icon: 'caregiver', date: c.grantedAt.slice(0, 10), title: `Caregiver access · ${c.name}`, sub: c.relationship, ref: R('caregivers', 'Caregiver access', p.id) }));
  return { upcoming: up.sort((a, b) => a.date.localeCompare(b.date)), today: td, past: past.filter(e => e.date < T || e.isNew).sort((a, b) => b.date.localeCompare(a.date)) };
}
const Timeline: React.FC<{ p: MedPatient }> = ({ p }) => {
  const { openPanel, panel } = useSv(); const t = timeline(p);
  const same = (r: Ref) => panel && panel.kind === r.kind && (panel.id || '') === (r.id || '');
  const item = (e: Ev, i: number) => <li key={i}><button type="button" onClick={() => openPanel(e.ref)} aria-current={same(e.ref) ? 'true' : undefined} data-testid="timeline-item" data-kind={e.icon}><Ico k={e.icon} /><span className="min-w-0"><span className="d block">{short(e.date)} · {e.date >= isoDay() ? relDay(e.date) : relDay(e.date)}{e.isNew && <span className="new"> · new</span>}</span><span className="block">{e.title}</span>{e.sub && <span className="d block">{e.sub}</span>}</span></button></li>;
  return <aside className="sv-tl" aria-label="Timeline" data-testid="chart-timeline">
    {t.upcoming.length > 0 && <><div className="k">Upcoming</div><ol>{t.upcoming.map(item)}</ol></>}
    {t.today.length > 0 && <><div className="k">Today</div><ol>{t.today.map(item)}</ol></>}
    <div className="k">Past</div><ol>{t.past.map(item)}</ol>
  </aside>;
};

/* ---------------- living summary ---------------- */
export const SurgeryChart: React.FC<{ patientId: string }> = ({ patientId }) => {
  useMedTick(); const { go, openPanel, toast } = useSv(); const [actor] = useActor(); const [signSum, setSignSum] = useState(false); const [pay, setPay] = useState(false); const [prof, setProf] = useState(false); const [note, setNote] = useState(false); const [hide, setHide] = useState(false);
  const p = medRepo.patient(patientId);
  const data = p ? build(p) : null;
  if (!p || !data) return <PatientList />;
  const v = todayVisit(p.id); const vt = v ? visitTypeDef(v.visitType) : null;
  const inits = summaryInitials(p.id); const lastInit = inits[inits.length - 1]; const changed = lastInit && lastInit.fingerprint !== data.fingerprint;
  const kept = keptNotes(p.id); const newMsg = lastFrom(p.id);
  const encounter = v || medRepo.visits(p.id).filter(x => x.date < isoDay()).sort((x, y) => y.date.localeCompare(x.date))[0];
  return <div className="sv-chart" data-testid="sv-chart">
    <Timeline p={p} />
    <article className="sv-sum" aria-label={`Living summary for ${p.name}`}>
      <ChartHeader p={p} data={data} onProfile={() => setProf(true)} onNote={() => setNote(true)} onHide={() => setHide(true)} />
      <div className="flex flex-wrap items-center gap-x-4 gap-y-1 py-1.5 border-b border-[var(--line)] text-[13px]" data-testid="chart-coordinator-row">
        <label className="inline-flex items-center gap-1.5"><Ico k="careteam" /><b className="text-[11px] tracking-[.07em] uppercase">Coordinator</b><select className="sv-select" value={coordinatorFor(p.id)?.id || ''} onChange={e => { assignCoordinator(p.id, e.target.value, actor.name, actor.role); toast(e.target.value ? 'Surgical coordinator assigned.' : 'Coordinator removed (optional).'); }} aria-label="Surgical coordinator (optional)" data-testid="chart-coordinator"><option value="">None (optional)</option>{coordinators().map(c => <option key={c.id} value={c.id}>{c.name}</option>)}</select></label>
        <span className="inline-flex items-center gap-1.5"><Ico k="invoice" /><b className="text-[11px] tracking-[.07em] uppercase">Account</b><AccountBadge pid={p.id} /></span>
        <button type="button" className="sv-link" onClick={() => setPay(true)} data-testid="chart-collect">Collect payment</button>
        <button type="button" className="sv-link" onClick={() => openPanel(R('billing', 'Billing', p.id))}>Billing</button>
        {encounter && <button type="button" className="sv-link ml-auto inline-flex items-center gap-1" onClick={() => go({ type: 'station', visitId: encounter.id })} data-testid="chart-workflow-link"><Ico k="visit" />{encounter.date === isoDay() ? 'Today’s visit workflow' : `Visit workflow · ${usDate(encounter.date)}`} →</button>}
      </div>
      <ProfileLine p={p as SvPatient} onEdit={() => setProf(true)} />
      <NextApptLine pid={p.id} />
      <PacketLine p={p} />
      {prof && <EditProfileDialog pid={p.id} onClose={() => setProf(false)} />}
      {note && <ContactNoteDialog p={p} onClose={() => setNote(false)} onSaved={n => { setNote(false); toast(`Note saved to ${p.name}’s chart${n.signed ? ` and signed by ${n.signed.by}` : ''}.`); }} />}
      {hide && <HideDeleteDialog p={p} session={actor.name} onClose={() => setHide(false)} onDone={m => { setHide(false); toast(m === 'delete' ? `${p.name}’s chart was permanently deleted. The audit trail is kept.` : `${p.name}’s chart is hidden. Restore it in Practice › Patient records.`); go({ type: 'tab', tab: 'patients' }); }} />}
      {pay && <CollectPayment p={p} onClose={() => setPay(false)} />}
      {newMsg && <button type="button" className="sv-newmsg" onClick={() => openPanel(R('messages', 'Portal messages', p.id))} data-testid="chart-new-message"><Ico k="message" size={16} /><b>New message</b><span className="min-w-0 truncate">from {newMsg.author.replace(/\s*\(.*\)/, '')} · {relDay(newMsg.at.slice(0, 10))} · “{newMsg.text.slice(0, 90)}{newMsg.text.length > 90 ? '…' : ''}”</span><span className="go">Read &amp; reply →</span></button>}
      {v && <div className="flex flex-wrap items-center gap-x-3 gap-y-1 py-2 border-b border-[var(--line)] text-[13.5px]" data-testid="chart-encounter">
        <span className="sv-dot" style={{ background: vt!.color, border: `1px solid ${edgeOf(vt!.color)}` }} aria-hidden="true" /><b>Today {v.time}</b><span>{v.visitType} · {v.provider} · {v.room}</span><span className="sv-tag">{STATION_LABEL[v.step]}</span>
        <button type="button" className="sv-btn sm primary ml-auto" onClick={() => go({ type: 'station', visitId: v.id })} data-testid="chart-station">{v.step === 'scheduled' ? 'Open visit workflow' : v.step === 'complete' ? 'Visit record' : `Continue · ${STATION_LABEL[v.step]}`}</button>
      </div>}
      <div className="flex items-baseline justify-between gap-3 mt-3 flex-wrap"><div className="sv-h" style={{ color: 'var(--ng)' }}>Living summary · Nightingale · kept current {hhmm(new Date().toISOString())}</div><span className="sv-small sv-muted">from recorded data · sources below</span></div>
      <h2 className="sr-only" data-testid="summary-headline">{data.headline}</h2>
      <div className="sv-sum-grid">
        <section className="sv-sec" aria-labelledby="h-cond"><h3 id="h-cond" className="sv-h">Significant conditions</h3><ul>{data.conditions.map((c, i) => <li key={i}><b>{c.text}</b>{c.detail && <span className="m"> · {c.detail}</span>}</li>)}{!data.conditions.length && <li className="sv-muted">None recorded.</li>}
          <li className="pt-1"><span className="m">Medications ({data.meds.length}):</span> {data.meds.join(', ') || 'none'}</li></ul></section>
        <section className="sv-sec" aria-labelledby="h-hist"><h3 id="h-hist" className="sv-h">Surgical history</h3><ul>{data.history.map((h, i) => <li key={i}>{h.text}{h.detail && <span className="m"> · {h.detail}</span>}</li>)}{!data.history.length && <li className="sv-muted">None recorded.</li>}</ul></section>
        {modules().riskAwareness && <section className="sv-sec" aria-labelledby="h-risk" data-testid="summary-risks"><h3 id="h-risk" className="sv-h">Major risk factors <span className="font-normal normal-case tracking-normal sv-muted">· {data.reviewed} of {data.riskTotal} reviewed by the surgeon</span></h3><ul>{data.risks.map((r, i) => <li key={i}><span className="sv-dot" style={{ background: r.reviewed ? '#9aa1aa' : '#b54708' }} aria-hidden="true" />{r.label}{r.detail && <span className="m"> · {r.detail}</span>}{r.reviewed && <span className="m"> · reviewed</span>}</li>)}{data.alsoFromProblems.length > 0 && <li className="m">Also flagged from the problem list: {data.alsoFromProblems.join(', ')}</li>}</ul></section>}
        <section className="sv-sec" aria-labelledby="h-prob"><h3 id="h-prob" className="sv-h">Active problems</h3><ul>{data.problems.map((x, i) => <li key={i}>{x.description} <span className="m">· {conditionLabel(x.conditionType)}</span></li>)}</ul></section>
      </div>
      {data.attention.length > 0 && <div className="sv-attn" data-testid="summary-attention"><b className="k">Worth your attention</b>{data.attention.map((x, i) => <button type="button" key={i} className="sv-attn-line" onClick={() => x.cites[0] && openPanel(x.cites[0])}><Ico k={KIND_ICON[x.cites[0]?.kind] || 'note'} />{x.text}</button>)}<div className="sv-small sv-muted mt-1">I flag; you decide. No score and no go/no-go.</div></div>}
      {kept.length > 0 && <div className="mt-3" data-testid="kept-notes"><h3 className="sv-h">Kept from Nightingale</h3>{kept.map(k => <div key={k.id} className="text-[13.5px] py-1 border-b border-[var(--line)]"><span className="sv-muted">“{k.question}”</span> {k.text}<span className="sv-small sv-muted"> · kept by {k.keptBy} {fmtDate(k.keptAt)} </span><button type="button" className="sv-link sv-small" onClick={() => removeKeptNote(k.id)}>remove</button></div>)}</div>}
      <DocumentsSection p={p} />
      <Records p={p} />
      <div className="mt-3">
        <HoldToInitial testId="summary-initial" label={lastInit && !changed ? <>Summary initialed by <b>{lastInit.by}</b> · {fmtDate(lastInit.at)} {hhmm(lastInit.at)}</> : <>{changed ? 'The summary changed since it was initialed. ' : ''}I reviewed this summary <span className="sv-muted">· your PIN · Nightingale cannot sign</span></>}
          done={lastInit && !changed ? `${initialsOf(lastInit.by)} · ${hhmm(lastInit.at)}` : undefined}
          onDone={() => setSignSum(true)} />
      </div>
      {signSum && <PinSign title="Initial the living summary" statement={<>I reviewed the living summary for {p.name}.</>} roles={ROLE_GROUP.provider} confirmLabel="Initial" onClose={() => setSignSum(false)} onSigned={w => { initialSummary({ patientId: p.id, by: w.name, role: w.role, at: w.at, fingerprint: data.fingerprint }); setSignSum(false); toast(`Summary initialed by ${w.name}.`); }} />}
    </article>
  </div>;
};

/* One place for every supporting record, instead of links scattered through the summary. */
const Records: React.FC<{ p: MedPatient }> = ({ p }) => {
  const { openPanel, go } = useSv(); const slips = labSlips(p.id); const visits = medRepo.visits(p.id).slice().sort((a, b) => b.date.localeCompare(a.date));
  const vit = medRepo.vitals(p.id); const lastV = vit[vit.length - 1]; const msgs = medRepo.messages(p.id); const nm = lastFrom(p.id); const packets = ascPackets(p.id);
  const L = (k: string, label: string, r: Ref, extra?: React.ReactNode, tid?: string) => <li key={label + (r.id || '')}><button type="button" className="sv-rec-link" onClick={() => openPanel(r)} data-testid={tid}><Ico k={k} /><span>{label}</span>{extra && <span className="m">{extra}</span>}</button></li>;
  return <section className="sv-records" aria-labelledby="h-rec" data-testid="chart-records">
    <h3 id="h-rec" className="sv-h">Records &amp; documents</h3>
    <div className="sv-records-grid">
      <div><div className="k">Results</div><ul>{slips.slice(0, 4).map(sl => L('lab', `Lab slip ${short(sl.date)}`, slipRef(sl.date, p.id), <>{sl.labs.map(l => l.test.replace('Hemoglobin A1c', 'A1c').replace('LDL cholesterol', 'LDL')).join(', ')}{sl.labs.some(l => l.status === 'awaiting-review') && <b className="text-[var(--warn)]"> · to review</b>}</>, 'rec-lab'))}{L('lab', 'All results', R('labs', 'Results', p.id))}{L('trends', 'Trends', R('trends', 'Trends', p.id))}</ul></div>
      <div><div className="k">Visits &amp; notes</div><ul>{visits.slice(0, 4).map(v => <li key={v.id}><button type="button" className="sv-rec-link" onClick={() => go({ type: 'station', visitId: v.id })} data-testid="rec-visit"><Ico k="visit" /><span>{v.visitType}</span><span className="m">{usDate(v.date)} · {medRepo.note(v.id)?.status === 'signed' ? 'note signed' : v.date > isoDay() ? 'upcoming' : 'workflow'}</span></button></li>)}{L('note', 'All visits & notes', R('visits', 'Visits & notes', p.id))}</ul></div>
      <div><div className="k">Clinical record</div><ul>{L('vitals', 'Vitals', R('vitals', 'Vitals', p.id), lastV ? vitalsText(lastV).split(' · ').slice(0, 2).join(' · ') : undefined)}{L('meds', 'Medications', R('meds', 'Medications', p.id), `${medRepo.meds(p.id).filter(m => m.status === 'active').length} active`)}{L('problems', 'Problem list', R('problems', 'Problem list', p.id))}{L('surgery', 'Surgical history', R('history', 'Surgical history', p.id))}{L('form', 'Intake answers', R('intake', 'Intake answers', p.id))}{modules().riskAwareness && L('risk', 'Risk awareness', R('risk', 'Risk awareness', p.id))}{L('careplan', 'Care plan', R('careplan', 'Care plan', p.id))}</ul></div>
      <div><div className="k">People &amp; messages</div><ul>{L('message', 'Portal messages', R('messages', 'Portal messages', p.id), nm ? <b className="text-[var(--crit)]">new</b> : `${msgs.length}`, 'rec-messages')}{L('careteam', 'Care team', R('careteam', 'Care team', p.id))}{L('caregiver', 'Caregivers', R('caregivers', 'Caregiver access', p.id))}{L('contact', 'Contact notes', R('contactnotes', 'Contact notes', p.id), `${contactNotes(p.id).length}`, 'rec-contactnotes')}{L('journal', 'Journal', R('journal', 'Journal', p.id))}{L('monitoring', 'Remote monitoring', R('monitoring', 'Remote monitoring', p.id))}</ul></div>
      {modules().networkAsc && <div><div className="k">Surgery center</div><ul>{L('asc', 'ASC case & thread', R('asc', 'ASC case & thread', p.id))}{L('send', 'Sent to ASC', R('ascchart', 'Sent to ASC · ASC chart', p.id), `${packets.length} packet${packets.length === 1 ? '' : 's'}`, 'rec-ascchart')}</ul></div>}
      <MediaRecords p={p} />
      <div><div className="k">Documents</div><ul><DocsRecordLink p={p} /></ul></div>
      <div><div className="k">Office</div><ul>{L('invoice', 'Billing', R('billing', 'Billing', p.id))}{L('audit', 'Audit trail', R('audit', 'Audit trail', p.id))}</ul></div>
    </div>
  </section>;
};

export function build(p: MedPatient) {
  const T = isoDay(); const v = todayVisit(p.id); const nc = nextAscCase(p.id); const f = first(p.name);
  const problems = medRepo.problems(p.id).filter(x => x.status === 'active'); const meds = medRepo.meds(p.id).filter(m => m.status === 'active'); const labs = medRepo.labs(p.id); const vit = medRepo.vitals(p.id);
  const ascN = getSettings().ascName.replace(/\s*\(.*\)/, '');
  const headline = nc ? `${p.name}, ${ageFrom(p.dob)} — ${nc.procedure.toLowerCase().replace(/^\w/, c => c.toUpperCase())} at ${nc.ascName.replace(/\s*\(.*\)/, '')} ${relDay(nc.date)}` : v ? `${p.name}, ${ageFrom(p.dob)} — ${v.visitType.toLowerCase()} today` : `${p.name}, ${ageFrom(p.dob)}`;
  const why = [v ? `${v.visitType} today${v.reason ? `: ${v.reason}` : ''}.` : 'No visit today.', nc ? `Surgery ${usDate(nc.date)} ${nc.time} · ${nc.room} · ${nc.surgeon.replace(/,.*$/, '')} · ${nc.status.toLowerCase()}.` : ''].filter(Boolean).join(' ');
  const whyCites: Ref[] = [...(v ? [noteRef(v)] : []), ...(nc ? [R('asc', 'ASC booking', p.id, nc.id)] : [])];
  const conditions = problems.filter(x => RISK_TYPES.includes(x.conditionType)).map(x => {
    const cites: Ref[] = [R('problems', 'Problem list', p.id)]; let detail = x.onset ? `since ${x.onset}` : '';
    if (x.conditionType === 'diabetes') { const a = labs.filter(l => l.test === 'Hemoglobin A1c'); const last = a[a.length - 1]; if (last) { detail = `A1c ${last.value}% (${short(last.collectedAt)}${last.status === 'awaiting-review' ? ', awaiting review' : ''})${a.length > 1 ? `, ${a[a.length - 2].value}% before` : ''}`; cites.splice(0, 1, slipRef(last.collectedAt, p.id)); } }
    if (x.conditionType === 'hypertension') { const b = [...vit].reverse().find(y => y.bpSys); if (b) { detail = `BP ${b.bpSys}/${b.bpDia} (${short(b.at.slice(0, 10))})`; cites.push(R('vitals', 'Vitals', p.id)); } }
    const linked = meds.filter(m => m.problemIds.includes(x.id)); if (linked.length) { detail += `${detail ? ' · ' : ''}${linked.map(m => `${m.name.replace(/\s*\(.*\)/, '')} ${m.dose}`).join(', ')}`; cites.push(R('meds', 'Med list', p.id)); }
    return { text: x.description, detail, cites };
  });
  const history = surgicalHistoryLines(p);
  const flags = riskFlags(p); const reviews = medRepo.riskReviews(p.id);
  const rs = flags.map(fl => ({ fl, reviewed: (() => { const r = reviewState(fl, reviews); return !!r.review && !r.changedSinceReview; })() }));
  const risks = rs.filter(x => x.fl.category !== 'Problem list').map(x => ({ label: x.fl.label, detail: x.fl.category === 'Medications' || x.fl.category === 'Intake' ? x.fl.detail.replace(/\s*\(patient-reported\)/, '') : '', reviewed: x.reviewed }));
  const alsoFromProblems = rs.filter(x => x.fl.category === 'Problem list').map(x => x.fl.label.replace(' on problem list', '').toLowerCase());
  const attention: { text: string; cites: Ref[] }[] = [];
  const aw = awaitingLabs(p.id); if (aw.length) attention.push({ text: `${aw.length} result${aw.length === 1 ? '' : 's'} from ${short(aw[0].collectedAt)} await review before ${f} can see them: ${aw.map(l => `${l.test.replace('Hemoglobin A1c', 'A1c')} ${l.value}${l.unit ? ' ' + l.unit : ''}`).join(', ')}.`, cites: [slipRef(aw[0].collectedAt, p.id)] });
  const lm = medRepo.messages(p.id).slice(-1)[0]; if (lm && lm.from !== 'office') attention.push({ text: `${lm.author.replace(/\s*\(.*\)/, '')} wrote ${relDay(lm.at.slice(0, 10))}: “${lm.text.length > 110 ? lm.text.slice(0, 110) + '…' : lm.text}” No reply yet.`, cites: [R('messages', 'Portal message', p.id)] });
  if (modules().networkAsc) ascCasesFor(p.id).forEach(c => { const m = networkRepo.thread(c.id).slice(-1)[0]; if (m && m.fromOrg === 'asc') attention.push({ text: `${ascN} asked ${relDay(m.at.slice(0, 10))}: “${m.text.replace(/\s*\(Fictional seed message\)/, '').slice(0, 110)}${m.text.length > 110 ? '…' : ''}”`, cites: [R('asc', 'ASC thread', p.id, c.id)] }); });
  if (nc && !p.recordSharingConsent?.granted) attention.push({ text: `No record-sharing consent is on file, so documents cannot go to ${ascN} for the ${short(nc.date)} case.`, cites: [R('asc', 'ASC case', p.id, nc.id)] });
  flaggedNotes(p.id).forEach(n => attention.push({ text: `${n.author.replace(/,.*$/, '')} flagged a ${n.channel.toLowerCase()} ${relDay(isoDay(new Date(n.contactAt)))} for provider review (${n.reason}): “${n.text.length > 100 ? n.text.slice(0, 100) + '…' : n.text}”`, cites: [R('contactnotes', 'Contact note', p.id, n.id)] }));
  const a = effectiveAllergy(p.allergies, patientKey(p.id)); if (a.pendingConfirm) attention.push({ text: `Allergies reported on intake are not yet confirmed: ${a.text}.`, cites: [R('allergies', 'Allergies', p.id)] }); if (a.state === 'not-reported') attention.push({ text: 'Allergy status is not reported. Ask and record allergies or NKDA.', cites: [R('allergies', 'Allergies', p.id)] });
  const fingerprint = fp(JSON.stringify([headline, why, conditions.map(c => c.text + c.detail), history.map(h => h.text), risks.map(r => r.label), problems.map(x => x.id), meds.map(m => m.id)]));
  return { headline, why, whyCites, conditions, history, risks, alsoFromProblems, reviewed: rs.filter(x => x.reviewed).length, riskTotal: rs.length, problems, attention, meds: meds.map(m => `${m.name.replace(/\s*\(.*\)/, '')} ${m.dose}`), fingerprint };
}

/* ---------------- v0.6 chart heading (ASC-style): identity → why here → who (Nightingale) → brief history ---------------- */
export type ChartData = NonNullable<ReturnType<typeof build>>;
export function whoNarrative(p: MedPatient, data: ChartData): string {
  const f = first(p.name); const age = ageFrom(p.dob); const sex = p.sex === 'Female' ? 'woman' : p.sex === 'Male' ? 'man' : 'patient';
  const c = coordinatorFor(p.id); const sp = p as SvPatient;
  const conds = medRepo.problems(p.id).filter(x => x.status === 'active' && RISK_TYPES.includes(x.conditionType)).map(x => x.description.replace(/,.*$/, '').replace(/\s*\(.*\)/, '').toLowerCase());
  const base = `${f} is a ${age}-year-old ${sex}${p.language && p.language !== 'English' ? ` (prefers ${p.language})` : ''}, ${p.primaryProvider.replace(/,.*$/, '')}’s patient${sp.referralSource ? `, ${/referral/i.test(sp.referralSource) && sp.referredBy ? `referred by ${sp.referredBy}` : `found us via ${sp.referralSource.toLowerCase()}`}` : ''}${c ? `; coordinator ${c.name}` : ''}.`;
  const health = conds.length ? ` Lives with ${conds.slice(0, 4).join(', ')}${data.meds.length ? `; takes ${data.meds.length} medication${data.meds.length === 1 ? '' : 's'}` : ''}.` : data.meds.length ? ` Takes ${data.meds.length} medication${data.meds.length === 1 ? '' : 's'}.` : ' No chronic conditions recorded.';
  const rec = recordsNarrative(p.id);
  return `${base}${health}${rec ? ` ${rec}` : ''}`;
}
const ChartHeader: React.FC<{ p: MedPatient; data: ChartData; onProfile: () => void; onNote: () => void; onHide: () => void }> = ({ p, data, onProfile, onNote, onHide }) => {
  const { openPanel } = useSv(); const al = allergyStatus(p); const nDocs = docsOf(p.id).length;
  const meds = medRepo.meds(p.id).filter(m => m.status === 'active'); const pmh = medRepo.problems(p.id).filter(x => x.status === 'active'); const psh = data.history; const risks = data.risks;
  const Cell: React.FC<{ k: string; label: string; onClick: () => void; tid: string; tone?: 'crit' | ''; children: React.ReactNode }> = ({ k, label, onClick, tid, tone, children }) =>
    <button type="button" className={`sv-ph-cell ${tone || ''}`} onClick={onClick} data-testid={tid}><span className="h"><Ico k={k} size={12} />{label}</span><span className="v">{children}</span></button>;
  return <header className="sv-phead" data-testid="chart-header">
    <div className="sv-ph-top">
      <div className="min-w-0"><h1 className="nm" data-testid="chart-name">{p.name}</h1>
        <div className="sv-ph-demo" data-testid="chart-demo"><b>{ageFrom(p.dob)} y</b> · {p.sex} · DOB {p.dob} · {p.id}{p.language && p.language !== 'English' ? ` · ${p.language}` : ''}</div></div>
      <div className="sv-ph-actions">
        <button type="button" className="sv-btn sm primary inline-flex items-center gap-1" onClick={onNote} data-testid="chart-add-note" title="Document a phone call, portal message or walk-in (any staff member)"><Mic size={14} />Add / dictate note</button>
        <button type="button" className="sv-btn sm inline-flex items-center gap-1" onClick={onProfile} data-testid="chart-profile-btn" title="Edit profile & contact information"><UserCog size={14} />Profile</button>
        {/* v0.12: Hide/delete moved to the Patients list row menu */}
      </div>
    </div>
    <p className="sv-ph-why" data-testid="chart-why"><b>Why here</b>{data.why}</p>
    <p className="sv-ph-who" data-testid="chart-who"><b><Sparkles size={11} className="inline -mt-0.5" /> Who · Nightingale</b>{whoNarrative(p, data)}{nDocs > 0 && <button type="button" className="sv-link sv-small ml-1" onClick={() => openPanel(R('documents', 'Documents', p.id))} data-testid="chart-who-docs">{nDocs} document{nDocs === 1 ? '' : 's'} →</button>}</p>
    <div className="sv-ph-grid">
      <Cell k="allergy" label="Allergies" tone={al.a.state === 'allergies' ? 'crit' : ''} onClick={() => openPanel(R('allergies', 'Allergies', p.id))} tid="chart-allergy"><AllergyVerify p={p} compact /></Cell>
      <Cell k="meds" label={`Medications (${meds.length})`} onClick={() => openPanel(R('meds', 'Medications', p.id))} tid="ph-meds">{meds.length ? meds.map(m => `${m.name.replace(/\s*\(.*\)/, '')} ${m.dose}`).join(', ') : 'None recorded'}</Cell>
      <Cell k="problems" label="Past medical history" onClick={() => openPanel(R('problems', 'Problem list', p.id))} tid="ph-pmh">{pmh.length ? pmh.map(x => x.description).join('; ') : 'None recorded'}</Cell>
      <Cell k="surgery" label="Past surgical history" onClick={() => openPanel(R('history', 'Surgical history', p.id))} tid="ph-psh">{psh.length ? psh.map(h => h.text).join('; ') : 'None recorded'}</Cell>
      {modules().riskAwareness && <Cell k="risk" label="Significant risk factors" tone={risks.length ? 'crit' : ''} onClick={() => openPanel(R('risk', 'Risk awareness', p.id))} tid="ph-risks">{risks.length ? risks.map(r => r.label).join('; ') : 'None flagged'}{data.alsoFromProblems.length > 0 && <span className="sv-muted"> · also {data.alsoFromProblems.join(', ')}</span>}</Cell>}
    </div>
  </header>;
};
