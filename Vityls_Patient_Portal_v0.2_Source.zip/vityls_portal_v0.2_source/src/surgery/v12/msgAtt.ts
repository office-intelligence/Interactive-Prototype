/* v0.12 · Message attachments (Surgery). Files are kept in IndexedDB (./img), metadata in the Surgery namespace.
 * Accepts PDF, JPG/PNG (compressed to ≤1600px JPEG), HEIC (kept as-is; most browsers can't preview it), DOC/DOCX, TXT.
 * Limits: images ≤ 20 MB before compression; other files ≤ 3 MB (same as the Documents folder); ≤ 5 files per message.
 * "File to Documents" copies the attachment into the patient's Documents folder (linked to the message) and runs the
 * existing simulated Nightingale summary. Everything audited (message.attach / .download / .file). */
import { repo } from '../../v6/dataLayer';
import { medRepo, patientKey, uid, isoDay, fmtDateTime } from '../../med/record';
import { svRead, svWrite } from '../store';
import { compressImage, imgGet, imgPut } from './img';
import { addDoc, ensureSummary, docById, DocRec } from '../documents';
export interface Att { id: string; msgId: string; patientId: string; name: string; mime: string; size: number; at: string; by: string; kind: 'image' | 'pdf' | 'doc' | 'heic' | 'text'; filed?: { docId: string; type: string; at: string; by: string } }
export const MAX_FILES = 5; export const MAX_DOC = 3 * 1024 * 1024; export const MAX_IMG = 20 * 1024 * 1024;
export const ACCEPT = 'application/pdf,image/jpeg,image/png,image/heic,image/heif,.heic,.heif,.pdf,.jpg,.jpeg,.png,.doc,.docx,.txt,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document,text/plain';
const all = () => svRead<Att[]>('msg-att', []);
export const attsOf = (msgId: string) => all().filter(a => a.msgId === msgId);
export const attData = (a: Att) => imgGet(`att:${a.id}`);
const kindOf = (f: File): Att['kind'] | null => { const n = f.name.toLowerCase(); const t = f.type;
  if (/hei[cf]/.test(t) || /\.hei[cf]$/.test(n)) return 'heic'; if (/^image\/(jpeg|png)$/.test(t) || /\.(jpe?g|png)$/.test(n)) return 'image';
  if (t === 'application/pdf' || n.endsWith('.pdf')) return 'pdf'; if (/msword|wordprocessing/.test(t) || /\.docx?$/.test(n)) return 'doc'; if (t === 'text/plain' || n.endsWith('.txt')) return 'text'; return null; };
const readUrl = (f: Blob) => new Promise<string>((res, rej) => { const r = new FileReader(); r.onload = () => res(String(r.result)); r.onerror = () => rej(r.error); r.readAsDataURL(f); });
export interface Pending { tmp: string; name: string; mime: string; size: number; kind: Att['kind']; data: string }
/** Validate + compress one picked file (before sending). Throws a clear message. */
export async function prepare(f: File): Promise<Pending> {
  const k = kindOf(f); if (!k) throw new Error(`${f.name}: use PDF, JPG, PNG, HEIC, DOC/DOCX or TXT.`);
  if (k === 'image') { if (f.size > MAX_IMG) throw new Error(`${f.name} is over 20 MB.`); const data = await compressImage(f, 1600); return { tmp: uid('tmp'), name: f.name.replace(/\.(png|jpe?g)$/i, '.jpg'), mime: 'image/jpeg', size: Math.round(data.length * 0.75), kind: k, data }; }
  if (f.size > MAX_DOC) throw new Error(`${f.name} is over 3 MB. Scan at a lower resolution or split it.`);
  return { tmp: uid('tmp'), name: f.name, mime: f.type || (k === 'pdf' ? 'application/pdf' : 'application/octet-stream'), size: f.size, kind: k, data: await readUrl(f) };
}
export async function saveAtts(msgId: string, patientId: string, by: string, role: string, l: Pending[]) {
  const out: Att[] = [];
  for (const p of l) { const a: Att = { id: uid('att'), msgId, patientId, name: p.name, mime: p.mime, size: p.size, at: new Date().toISOString(), by, kind: p.kind }; await imgPut(`att:${a.id}`, p.data); out.push(a); }
  svWrite('msg-att', [...all(), ...out]);
  if (out.length) repo.audit({ caseId: patientKey(patientId), user: by, role, action: 'message.attach' as any, detail: `${out.length} attachment${out.length === 1 ? '' : 's'} on a portal message: ${out.map(a => `${a.name} (${Math.round(a.size / 1024)} KB)`).join(', ')}` });
}
export function downloadAtt(a: Att, by: string, role: string) { const d = attData(a); if (!d) return; const x = document.createElement('a'); x.href = d; x.download = a.name; document.body.appendChild(x); x.click(); x.remove();
  repo.audit({ caseId: patientKey(a.patientId), user: by, role, action: 'message.attachment.download' as any, detail: `Downloaded message attachment ${a.name}` }); }
export function fileToDocuments(a: Att, type: string, title: string, docDate: string, by: string, role: string): DocRec {
  const m = medRepo.messages(a.patientId).find(x => x.id === a.msgId); const data = attData(a);
  const desc = `Received as an attachment to a portal message from ${m?.author || 'the patient'} on ${m ? fmtDateTime(m.at) : '—'}${m?.text ? `: “${m.text.slice(0, 200)}”` : ''}.`;
  const d: DocRec & { fromMessageId?: string; fromAttachmentId?: string } = { id: uid('doc'), patientId: a.patientId, type, title: title.trim() || a.name.replace(/\.[^.]+$/, ''), source: `Portal message · ${m?.author || 'patient'}`, docDate: docDate || isoDay(), receivedAt: new Date().toISOString(), receivedBy: by, receivedRole: role, description: desc, fileName: a.name, mime: a.mime, size: a.size, dataUrl: data || undefined, text: [m?.text || '', title].join('\n'), fromMessageId: a.msgId, fromAttachmentId: a.id };
  addDoc(d);
  svWrite('msg-att', all().map(x => x.id === a.id ? { ...x, filed: { docId: d.id, type, at: d.receivedAt, by } } : x));
  repo.audit({ caseId: patientKey(a.patientId), user: by, role, action: 'message.attachment.file' as any, detail: `Message attachment ${a.name} filed to Documents as ${type} (“${d.title}”), linked to message ${a.msgId}` });
  ensureSummary(docById(d.id)!, by, role); return docById(d.id)!;
}
