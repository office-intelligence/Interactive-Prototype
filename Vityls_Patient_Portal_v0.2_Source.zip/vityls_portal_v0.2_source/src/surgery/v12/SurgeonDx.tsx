/* v0.12 · Surgeon (Doctor) station: "Diagnosis & procedure" section on the same data model as the chart editor
 * (v10/dx.ts · DxEntry), plus Nightingale "Suggest from note & history" (simulated). Suggestions are never saved by
 * Nightingale: the clinician accepts, edits (opens the chart's diagnosis dialog pre-filled) or dismisses each one.
 * Saving follows the chart rule (any role, no PIN, audited as patient.dx); suggestion events are audited too. */
import React, { useState } from 'react';
import { Sparkles, Check, Pencil, X } from 'lucide-react';
import { repo } from '../../v6/dataLayer';
import { MedPatient, MedVisit, patientKey, uid } from '../../med/record';
import { useActor, useMedTick } from '../../med/ui';
import { useSv } from '../ui';
import { DxCard, DxDialog, dxAudit } from '../v11/DxEditor';
import { dxList, saveDxList, DxEntry, DX_STATUS_LABEL } from '../v10/dx';
import { suggestDx, DxSuggestion } from './suggest';
const toEntry = (s: DxSuggestion, p: MedPatient): DxEntry => { const ex = dxList(p).find(d => d.diagnosis.toLowerCase() === s.diagnosis.toLowerCase());
  const proc = { id: uid('pr'), name: s.procedure, status: 'planned' as const, surgeon: p.primaryProvider };
  return ex ? { ...JSON.parse(JSON.stringify(ex)), icd: ex.icd || s.icd, procedures: [...ex.procedures, proc] } : { id: uid('dx'), diagnosis: s.diagnosis, icd: s.icd, procedures: [proc] }; };
export const SurgeonDx: React.FC<{ v: MedVisit; p: MedPatient }> = ({ v, p }) => {
  useMedTick(); const [actor] = useActor(); const { toast } = useSv(); const [sug, setSug] = useState<DxSuggestion[] | null>(null); const [ed, setEd] = useState<{ s: DxSuggestion; d: DxEntry } | null>(null);
  const evt = (action: string, detail: string) => { repo.audit({ caseId: v.id, user: actor.name, role: actor.role, action: action as any, detail }); repo.audit({ caseId: patientKey(p.id), user: actor.name, role: actor.role, action: action as any, detail }); };
  const run = () => { const l = suggestDx(v, p); setSug(l); evt('nightingale.dx.suggest', `Nightingale suggested ${l.length} diagnosis/procedure${l.length === 1 ? '' : 's'} from the note & history (simulated): ${l.map(x => x.diagnosis).join('; ') || 'none'}. Nothing saved.`); };
  const saveEntry = (d: DxEntry, how: string, s: DxSuggestion) => { const l = dxList(p); const isNew = !l.some(x => x.id === d.id); saveDxList(p, isNew ? [...l, d] : l.map(x => x.id === d.id ? d : x));
    dxAudit(p, actor.name, actor.role, `${isNew ? 'Diagnosis added' : 'Diagnosis edited'} at the surgeon station: ${d.diagnosis}${d.icd ? ` (${d.icd})` : ''} · ${d.procedures.map(x => `${x.name} ${DX_STATUS_LABEL[x.status]}`).join('; ')}`);
    evt(`nightingale.dx.${how}`, `Nightingale suggestion ${how === 'accept' ? 'accepted' : 'edited and saved'} by ${actor.name}: ${s.diagnosis} → ${s.procedure}`);
    setSug(x => x && x.filter(y => y.key !== s.key)); toast(`${d.diagnosis} saved to the chart.`); };
  return <section className="sv-sheet mt-4" data-testid="surgeon-dx">
    <div className="flex items-baseline justify-between gap-2 flex-wrap"><h2 className="sv-h">Diagnosis &amp; procedure</h2>
      <button type="button" className="sv-btn sm" onClick={run} data-testid="dx-suggest" style={{ color: 'var(--n)' }}><Sparkles size={14} /> Nightingale · Suggest from note &amp; history</button></div>
    <p className="text-[12px] sv-muted mb-2">Same list as the chart (Overview › Diagnoses &amp; procedures). Any team member can record it; every change is audited.</p>
    <DxCard p={p} />
    {sug && <div className="v12-sug" data-testid="dx-suggestions" aria-live="polite">
      <div className="flex items-baseline justify-between gap-2"><b className="text-[13.5px]" style={{ color: 'var(--n)' }}>Nightingale suggestions · simulated · nothing saved until you accept</b><button type="button" className="sv-link text-[12px]" onClick={() => setSug(null)}>Close</button></div>
      {sug.length === 0 ? <p className="text-[13px] mt-1" data-testid="dx-sug-none">Nothing new found in the note, transcript or intake forms. Add a diagnosis yourself if needed.</p> : sug.map(s =>
        <div key={s.key} className="v12-sug-row" data-testid="dx-sug">
          <div><b className="text-[14px]">{s.diagnosis}</b> <span className="v7-muted text-[12.5px]">· ICD-10 {s.icd}</span></div>
          <div className="text-[13px]">Planned procedure: <b>{s.procedure}</b></div>
          <ul className="mt-1">{s.sources.map((x, i) => <li key={i} className="v12-src">From <b>{x.from}</b>: “{x.text}”</li>)}</ul>
          <div className="flex gap-2 mt-1.5 flex-wrap">
            <button type="button" className="sv-btn sm primary" onClick={() => saveEntry(toEntry(s, p), 'accept', s)} data-testid="dx-sug-accept"><Check size={13} /> Accept</button>
            <button type="button" className="sv-btn sm" onClick={() => setEd({ s, d: toEntry(s, p) })} data-testid="dx-sug-edit"><Pencil size={13} /> Edit</button>
            <button type="button" className="sv-btn sm" onClick={() => { evt('nightingale.dx.dismiss', `Nightingale suggestion dismissed by ${actor.name}: ${s.diagnosis}`); setSug(x => x && x.filter(y => y.key !== s.key)); }} data-testid="dx-sug-dismiss"><X size={13} /> Dismiss</button></div>
        </div>)}
      <p className="text-[11.5px] sv-muted mt-1">Suggestions come from keywords in the visit note, transcript, nurse intake and the patient’s medical-history and intake forms. Nightingale never saves, signs or decides; verify the ICD-10 code.</p></div>}
    {ed && <DxDialog p={p} init={ed.d} isNew={!dxList(p).some(x => x.id === ed.d.id)} onClose={() => setEd(null)} onSave={d => { saveEntry(d, 'edit', ed.s); setEd(null); }} />}
  </section>;
};
