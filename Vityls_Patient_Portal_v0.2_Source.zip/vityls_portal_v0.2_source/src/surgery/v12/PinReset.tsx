/* v0.12 · Forgot PIN UI: request panel (inside every PIN prompt), simulated email preview, reset landing page. */
import React, { useState } from 'react';
import { KeyRound, Mail } from 'lucide-react';
import { useActor } from '../../med/ui';
import { getSettings } from '../../med/settings';
import { requestPinReset, resolveReset, checkLogin, completeReset, OutMail, RESET_MINUTES } from './pinReset';
import '../surgery.css';
export const MailPreview: React.FC<{ m: OutMail; onClose: () => void }> = ({ m, onClose }) => <div className="sv-modal" role="dialog" aria-modal="true" aria-label="Simulated email" data-testid="pin-reset-email"><div className="sv-modal-scrim" onClick={onClose} />
  <div className="sv-modal-box" style={{ width: 'min(600px, calc(100vw - 24px))' }}>
    <div className="flex items-center gap-2"><Mail size={16} /><b className="text-[15px]">Email sent · simulated outbox</b></div>
    <p className="sv-small sv-muted mt-1">Test build: nothing leaves this browser. In production this goes to the person’s inbox.</p>
    <div className="text-[13px] mt-2 border border-[#e2e6e1] rounded-[3px] p-3"><div><b>To:</b> {m.toName} &lt;{m.to}&gt;</div><div><b>Subject:</b> {m.subject}</div>
      <pre className="whitespace-pre-wrap font-sans mt-2" data-testid="pin-reset-email-body">{m.body}</pre></div>
    <div className="flex justify-end gap-2 mt-3"><button type="button" className="sv-btn" onClick={onClose}>Close</button>{m.link && <a className="sv-btn primary" href={m.link} data-testid="pin-reset-open-link">Open the link (test)</a>}</div>
  </div></div>;
/** Shown inside PinSign when the person taps "Forgot PIN?". */
export const ForgotPin: React.FC<{ names: string[]; who: string; onBack: () => void }> = ({ names, who, onBack }) => {
  const [actor] = useActor(); const [n, setN] = useState(who); const [err, setErr] = useState(''); const [m, setM] = useState<OutMail | null>(null);
  const send = () => { setErr(''); try { setM(requestPinReset(n, actor.name, actor.role, 'self')); } catch (e) { setErr((e as Error).message); } };
  return <div data-testid="pin-forgot">
    <div className="flex items-center gap-2 mb-1"><KeyRound size={16} /><b className="text-[15px]">Forgot your PIN?</b></div>
    <p className="text-[13px] mb-3">We’ll email you a one-time link (valid {RESET_MINUTES} minutes). Open it, sign in with your username and password, and create a new PIN. Your current PIN keeps working until you finish. Practice administrators are notified.</p>
    <label className="block"><span className="sv-label">Your name</span><select className="sv-input" value={n} onChange={e => setN(e.target.value)} data-testid="pin-forgot-who"><option value="">Choose your name…</option>{names.map(x => <option key={x}>{x}</option>)}</select></label>
    {err && <p className="text-[12.5px] text-[var(--crit)] mt-2" role="alert" data-testid="pin-forgot-error">{err}</p>}
    {m && <p className="text-[12.5px] mt-2" style={{ color: 'var(--ok)' }} data-testid="pin-forgot-sent">Reset link emailed to {m.to}. Check your email.</p>}
    <div className="flex justify-end gap-2 mt-3"><button type="button" className="sv-btn" onClick={onBack} data-testid="pin-forgot-back">Back</button><button type="button" className="sv-btn primary" disabled={!n} onClick={send} data-testid="pin-forgot-send">Email me a reset link</button></div>
    {m && <MailPreview m={m} onClose={() => setM(null)} />}
  </div>;
};
export const PinResetLanding: React.FC<{ token: string }> = ({ token }) => {
  const [c, setC] = useState(() => resolveReset(token)); const [u, setU] = useState(''); const [pw, setPw] = useState(''); const [signed, setSigned] = useState(false); const [pin, setPin] = useState(''); const [pin2, setPin2] = useState(''); const [err, setErr] = useState(''); const [done, setDone] = useState(false);
  const back = () => { history.replaceState(null, '', location.href.split('#')[0]); location.reload(); };
  return <div className="sv" data-testid="pin-reset-landing" style={{ background: '#e2e5ea', minHeight: '100vh' }}>
    <div className="sv-main" style={{ maxWidth: 520, minHeight: 0, marginTop: 40 }}>
      <div className="sv-mark mb-1">Surgery<span>.Vityls</span></div>
      <div className="sv-sub mb-4">{getSettings().practiceName} · reset signing PIN · SIMULATION (fictional)</div>
      {done ? <div data-testid="pin-reset-done"><h1 className="sv-title">New PIN saved</h1><p className="mt-2 text-[14px]">Use your new PIN from now on. The old one no longer works. Your practice administrators were notified.</p><button type="button" className="sv-btn primary mt-3" onClick={back}>Back to Surgery.Vityls</button></div>
        : c.state !== 'ok' ? <div data-testid="pin-reset-invalid"><h1 className="sv-title">This link can’t be used</h1><p className="mt-2">{c.state === 'used' ? 'It was already used.' : c.state === 'revoked' ? 'A newer reset email replaced it. Use the most recent one.' : c.state === 'expired' ? `It expired (links last ${RESET_MINUTES} minutes). Ask for a new one with “Forgot PIN?”.` : 'It isn’t a valid reset link.'}</p><button type="button" className="sv-btn mt-3" onClick={back}>Back</button></div>
        : !signed ? <form onSubmit={e => { e.preventDefault(); setErr(''); try { checkLogin(token, u.trim(), pw); setSigned(true); } catch (x) { setErr((x as Error).message); setC(resolveReset(token)); } }} data-testid="pin-reset-signin">
          <h1 className="sv-title">Hello, {c.p!.name}</h1><p className="sv-sub mb-3">Sign in to confirm it’s you.</p>
          <label className="block mb-2"><span className="sv-label">Username</span><input className="sv-input" value={u} onChange={e => setU(e.target.value)} autoComplete="username" data-testid="pin-reset-username" /></label>
          <label className="block"><span className="sv-label">Password</span><input className="sv-input" type="password" value={pw} onChange={e => setPw(e.target.value)} autoComplete="current-password" data-testid="pin-reset-password" /></label>
          {err && <p className="text-[13px] text-[var(--crit)] mt-2" role="alert" data-testid="pin-reset-error">{err}</p>}
          <button type="submit" className="sv-btn primary mt-3" data-testid="pin-reset-signin-btn">Sign in</button></form>
        : <form onSubmit={e => { e.preventDefault(); setErr(''); try { completeReset(token, u.trim(), pw, pin, pin2); setDone(true); } catch (x) { setErr((x as Error).message); } }} data-testid="pin-reset-create">
          <h1 className="sv-title">Create a new PIN</h1><p className="sv-sub mb-3">{c.p!.name} · {c.p!.role}</p>
          <div className="grid grid-cols-2 gap-2"><label><span className="sv-label">New PIN (4–6 digits)</span><input className="sv-input" type="password" inputMode="numeric" value={pin} onChange={e => setPin(e.target.value.replace(/\D/g, ''))} data-testid="pin-reset-pin" /></label>
            <label><span className="sv-label">Repeat new PIN</span><input className="sv-input" type="password" inputMode="numeric" value={pin2} onChange={e => setPin2(e.target.value.replace(/\D/g, ''))} data-testid="pin-reset-pin2" /></label></div>
          <p className="sv-small sv-muted mt-2">Avoid repeated or sequential digits, and don’t reuse your current PIN. Nobody at the practice will ever ask for it.</p>
          {err && <p className="text-[13px] text-[var(--crit)] mt-2" role="alert" data-testid="pin-reset-error">{err}</p>}
          <button type="submit" className="sv-btn primary mt-3" data-testid="pin-reset-save">Save new PIN</button></form>}
    </div></div>;
};
