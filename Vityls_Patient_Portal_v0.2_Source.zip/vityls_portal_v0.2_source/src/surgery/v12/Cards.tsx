/* v0.12 · Photo ID + insurance cards UI: full panel (chart Documents, dialog, front desk) and a compact status line. */
import React, { useState } from 'react';
import { Plus, Trash2, CreditCard } from 'lucide-react';
import { MedPatient } from '../../med/record';
import { useActor, useMedTick } from '../../med/ui';
import { useSv } from '../ui';
import { DialogShell } from '../../v7/ui';
import { ImageSlot } from './capture';
import { cardsFor, cardImg, setCardImage, updateIns, addIns, removeIns, cardStatus, Side, CardImg, InsCard } from './cards';
const meta = (m?: CardImg) => m ? `${m.by} · ${new Date(m.at).toLocaleDateString('en-US')} · ${m.via}` : undefined;

export const CardsPanel: React.FC<{ p: MedPatient; via: string; only?: 'missing' }> = ({ p, via, only }) => {
  useMedTick(); const [actor] = useActor(); const { toast } = useSv(); const c = cardsFor(p.id);
  const set = (slot: string, side: Side) => async (d: string, how: string) => { try { await setCardImage(p.id, slot, side, d, actor.name, actor.role, `${via}, ${how}`); toast('Card saved to the chart.'); } catch (e) { toast((e as Error).message); } };
  const rm = (slot: string, side: Side) => async () => { await setCardImage(p.id, slot, side, undefined, actor.name, actor.role, via); toast('Card picture removed.'); };
  const slot = (s: string, side: Side, label: string, m?: CardImg) => { const v = cardImg(p.id, s, side); if (only === 'missing' && v) return null;
    return <ImageSlot key={`${s}-${side}`} label={label} value={v} meta={meta(m)} testId={`card-${s === 'id' ? 'id' : s}-${side}`} onSet={set(s, side)} onRemove={rm(s, side)} onError={toast} compact={only === 'missing'} />; };
  return <div data-testid="cards-panel">
    {(() => { const f = slot('id', 'front', 'Photo ID · front', c.photoId.front), b = slot('id', 'back', 'Photo ID · back', c.photoId.back); return (f || b) && <><div className="sv-label">Photo ID (driver’s license, state ID or passport)</div>
    <div className="v12-slots" data-testid="cards-id">{f}{b}</div></>; })()}
    {c.insurance.map((i, k) => <InsBlock key={i.id} p={p} i={i} canRemove={k > 0}>{slot(i.id, 'front', `${i.rank} insurance · front`, i.front)}{slot(i.id, 'back', `${i.rank} insurance · back`, i.back)}</InsBlock>)}
    <button type="button" className="v7-quiet mt-2 inline-flex items-center gap-1" onClick={() => { const n = addIns(p.id, actor.name, actor.role); toast(`${n.rank} insurance added.`); }} data-testid="cards-add-ins"><Plus size={14} />{c.insurance.length === 1 ? 'Add secondary insurance' : 'Add another insurance'}</button>
    <p className="v7-muted text-[12px] mt-2">Pictures are resized to 512px and saved on this device’s test storage. Each change is recorded in the audit trail.</p>
  </div>;
};
const InsBlock: React.FC<{ p: MedPatient; i: InsCard; canRemove: boolean; children: React.ReactNode }> = ({ p, i, canRemove, children }) => {
  const [actor] = useActor(); const { toast } = useSv(); const [d, setD] = useState({ carrier: i.carrier || '', memberId: i.memberId || '', group: i.group || '' });
  const dirty = d.carrier !== (i.carrier || '') || d.memberId !== (i.memberId || '') || d.group !== (i.group || '');
  return <div className="v12-ins" data-testid="cards-ins" data-rank={i.rank}>
    <div className="v12-ins-h"><b className="text-[13.5px] mr-2" style={{ alignSelf: 'center' }}>{i.rank} insurance</b>
      <label><span className="sv-label">Carrier</span><input className="sv-input" value={d.carrier} onChange={e => setD({ ...d, carrier: e.target.value })} data-testid="ins-carrier" /></label>
      <label><span className="sv-label">Member ID</span><input className="sv-input" value={d.memberId} onChange={e => setD({ ...d, memberId: e.target.value })} data-testid="ins-member" /></label>
      <label><span className="sv-label">Group</span><input className="sv-input" value={d.group} onChange={e => setD({ ...d, group: e.target.value })} /></label>
      {dirty && <button type="button" className="sv-btn sm primary" onClick={() => { updateIns(p.id, { ...i, carrier: d.carrier || undefined, memberId: d.memberId || undefined, group: d.group || undefined }, actor.name, actor.role); toast('Insurance details saved.'); }} data-testid="ins-save">Save</button>}
      {canRemove && <button type="button" className="sv-btn sm" onClick={async () => { await removeIns(p.id, i.id, actor.name, actor.role); toast(`${i.rank} insurance removed.`); }} aria-label={`Remove ${i.rank} insurance`} data-testid="ins-remove"><Trash2 size={13} /></button>}</div>
    <div className="v12-slots">{children}</div></div>;
};
/** Compact chips + Manage button (chart Overview "Cards", front desk). */
export const CardsStatus: React.FC<{ p: MedPatient; testId?: string }> = ({ p, testId = 'cards-status' }) => {
  useMedTick(); const [open, setOpen] = useState(false); const st = cardStatus(p.id);
  return <div data-testid={testId}>
    <div className={`t ${st.missing.length ? 'v7-amber' : 'v7-green'}`} data-testid={`${testId}-summary`}>{st.missing.length ? `${st.missing.length} missing` : 'All on file'}{st.selfPay ? ' · self-pay' : ''}</div>
    <div className="v12-cardline">{st.items.map(x => <span key={x.key} className={`v12-chip ${x.ok ? 'ok' : 'miss'}`}>{x.ok ? '✓' : '○'} {x.label}</span>)}</div>
    <button type="button" className="v7-quiet mt-1.5 inline-flex items-center gap-1" onClick={() => setOpen(true)} data-testid={`${testId}-open`}><CreditCard size={14} />ID &amp; insurance cards</button>
    {open && <div className="sv-flat sv-dlg"><DialogShell size="lg" title="ID & insurance cards" subtitle={`${p.name} · photo ID and insurance cards, front and back`} onClose={() => setOpen(false)} testId="cards-dialog"
      footer={<button type="button" className="sv-btn" onClick={() => setOpen(false)}>Done</button>}><CardsPanel p={p} via="chart" /></DialogShell></div>}
  </div>;
};
