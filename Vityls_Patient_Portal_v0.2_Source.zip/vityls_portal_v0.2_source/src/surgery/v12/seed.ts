/* v0.12 · Fictional past visits so the chart "Past visits" card has history (once per test data set). */
import { isMedical } from '../../edition';
import { medRepo, addDays, isoDay } from '../../med/record';
import { svRead, svWrite } from '../store';
const SURG_H: [number, string, string, string, string][] = [ // daysAgo, time, type, reason, assessment
  [21, '10:00', 'Follow-up visit', 'Eyelid heaviness follow-up', 'Dermatochalasis of upper eyelids, symptomatic. Visual field testing ordered.'],
  [64, '09:30', 'New patient consultation', 'Cosmetic consultation', 'Facial aging concerns discussed; jowling noted.'],
  [130, '14:15', 'Office procedure', 'Neuromodulator, forehead lines', 'Dynamic forehead rhytides treated with neuromodulator.'],
  [210, '11:00', 'Post-op follow-up', 'Post-op check', 'Expected post-operative course.'],
  [320, '08:45', 'Follow-up visit', 'Annual review', 'Stable; no new concerns.'],
  [400, '15:00', 'Pre-op clearance consult', 'Clearance review', 'Clearance letter reviewed.'],
];
/** Medical.Vityls: primary-care past visits. */
const MED_H: [number, string, string, string, string][] = [
  [21, '10:00', 'Follow-up visit', 'Blood pressure follow-up', 'Hypertension, improved on current regimen. Continue home BP log.'],
  [64, '09:30', 'New patient visit', 'Establish care', 'Health maintenance reviewed; screening labs ordered.'],
  [130, '14:15', 'Chronic care visit', 'Diabetes 3-month check', 'Type 2 diabetes, A1c at goal. Continue metformin.'],
  [210, '11:00', 'Same-day sick visit', 'Cough and congestion', 'Viral upper respiratory infection. Supportive care.'],
  [320, '08:45', 'Follow-up visit', 'Annual review', 'Stable; no new concerns.'],
  [400, '15:00', 'Annual wellness / physical', 'Annual physical', 'Preventive care up to date; vaccines reviewed.'],
];
const H = isMedical ? MED_H : SURG_H;
export function ensureV12Seed() {
  if (svRead<boolean>('v12-seeded', false)) return; const pts = medRepo.patients(); const T = isoDay();
  pts.forEach((p, i) => { const n = i === 0 ? 6 : (i % 3) + 2; H.slice(0, n).forEach(([d, time, type, reason, ax], k) => {
    const id = `v12-${p.id}-${k}`; if (medRepo.visit(id)) return; const date = addDays(T, -(d + i * 3));
    medRepo.saveVisit({ id, patientId: p.id, date, time, durationMin: 30, provider: p.primaryProvider, room: 'Exam 1', visitType: type, reason, step: k === 4 ? 'scheduled' : 'complete', problemIds: [], createdAt: new Date().toISOString(), createdBy: 'Fictional seed' });
    if (k !== 4) medRepo.saveNote({ visitId: id, template: type, subjective: `${reason}.`, objective: 'Exam documented (fictional).', assessment: ax, plan: 'As discussed.', status: k % 2 ? 'draft' : 'signed', updatedAt: new Date(date + 'T17:00').toISOString(), updatedBy: p.primaryProvider, signedBy: k % 2 ? undefined : p.primaryProvider, signedAt: k % 2 ? undefined : new Date(date + 'T17:00').toISOString(), addenda: [] });
  }); });
  svWrite('v12-seeded', true);
}
