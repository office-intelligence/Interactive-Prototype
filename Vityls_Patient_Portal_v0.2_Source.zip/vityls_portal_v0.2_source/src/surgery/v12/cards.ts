/* v0.12 · Photo ID and insurance cards per patient. Photo ID front/back; insurance primary + secondary (+ more), each
 * front/back with carrier / member ID. Images are compressed (512px JPEG) and stored via ./img (IndexedDB); this record
 * keeps only metadata. Every change audited (patient.card). Backend swap point: /patients/:id/cards. */
import { repo } from '../../v6/dataLayer';
import { MedPatient, patientKey, uid, medRepo } from '../../med/record';
import { svRead, svWrite } from '../store';
import { imgGet, imgPut, imgDel } from './img';
export type Side = 'front' | 'back';
export interface CardImg { at: string; by: string; via: string }
export interface InsCard { id: string; rank: string; carrier?: string; memberId?: string; group?: string; front?: CardImg; back?: CardImg }
export interface PatientCards { photoId: { front?: CardImg; back?: CardImg }; insurance: InsCard[] }
const all = () => svRead<Record<string, PatientCards>>('patient-cards', {});
export const RANKS = ['Primary', 'Secondary', 'Tertiary', 'Additional'];
export function cardsFor(pid: string): PatientCards {
  const c = all()[pid]; if (c) return { photoId: c.photoId || {}, insurance: c.insurance?.length ? c.insurance : defaultIns(pid) };
  return { photoId: {}, insurance: defaultIns(pid) };
}
function defaultIns(pid: string): InsCard[] { const p = medRepo.patient(pid) as (MedPatient & { insuranceCarrier?: string; paymentType?: string }) | undefined;
  return [{ id: `ins-${pid}-1`, rank: 'Primary', carrier: p?.insuranceCarrier || p?.insurance || undefined }]; }
const save = (pid: string, c: PatientCards) => svWrite('patient-cards', { ...all(), [pid]: c });
export const imgKey = (pid: string, slot: string, side: Side) => `card:${pid}:${slot}:${side}`;
export const cardImg = (pid: string, slot: string, side: Side) => imgGet(imgKey(pid, slot, side));
const label = (slot: string, side: Side, c: PatientCards) => slot === 'id' ? `Photo ID ${side}` : `${c.insurance.find(x => x.id === slot)?.rank || 'Insurance'} insurance card ${side}`;
const aud = (pid: string, by: string, role: string, detail: string) => repo.audit({ caseId: patientKey(pid), user: by, role, action: 'patient.card' as any, detail });
export async function setCardImage(pid: string, slot: string, side: Side, data: string | undefined, by: string, role: string, via: string) {
  const c = cardsFor(pid); const had = !!cardImg(pid, slot, side);
  if (data) await imgPut(imgKey(pid, slot, side), data); else await imgDel(imgKey(pid, slot, side));
  const meta = data ? { at: new Date().toISOString(), by, via } : undefined;
  if (slot === 'id') c.photoId = { ...c.photoId, [side]: meta }; else c.insurance = c.insurance.map(x => x.id === slot ? { ...x, [side]: meta } : x);
  save(pid, c); aud(pid, by, role, `${label(slot, side, c)} ${data ? (had ? 'replaced' : 'added') : 'removed'}${data ? ` (${via})` : ''}`);
}
export function updateIns(pid: string, ins: InsCard, by: string, role: string) { const c = cardsFor(pid); c.insurance = c.insurance.map(x => x.id === ins.id ? ins : x); save(pid, c); aud(pid, by, role, `${ins.rank} insurance details updated: ${ins.carrier || '—'} · member ${ins.memberId || '—'}`); }
export function addIns(pid: string, by: string, role: string) { const c = cardsFor(pid); const rank = RANKS[Math.min(c.insurance.length, RANKS.length - 1)]; const n: InsCard = { id: uid('ins'), rank }; c.insurance = [...c.insurance, n]; save(pid, c); aud(pid, by, role, `${rank} insurance added`); return n; }
export async function removeIns(pid: string, id: string, by: string, role: string) { const c = cardsFor(pid); const x = c.insurance.find(i => i.id === id); if (!x) return; await imgDel(imgKey(pid, id, 'front')); await imgDel(imgKey(pid, id, 'back'));
  c.insurance = c.insurance.filter(i => i.id !== id).map((i, k) => ({ ...i, rank: RANKS[Math.min(k, RANKS.length - 1)] })); save(pid, c); aud(pid, by, role, `${x.rank} insurance removed`); }
/** Status for chips: which required pictures exist. Self-pay patients don't need insurance cards. */
export function cardStatus(pid: string) {
  const c = cardsFor(pid); const p = medRepo.patient(pid) as (MedPatient & { paymentType?: string }) | undefined; const selfPay = /self|cash/i.test(p?.paymentType || '') && !c.insurance.some(i => i.carrier || i.front);
  const items: { key: string; label: string; ok: boolean; slot: string; side: Side }[] = [
    { key: 'id-front', label: 'Photo ID front', ok: !!cardImg(pid, 'id', 'front'), slot: 'id', side: 'front' }, { key: 'id-back', label: 'Photo ID back', ok: !!cardImg(pid, 'id', 'back'), slot: 'id', side: 'back' }];
  if (!selfPay) c.insurance.forEach(i => (['front', 'back'] as Side[]).forEach(s => items.push({ key: `${i.id}-${s}`, label: `${i.rank} ins. ${s}`, ok: !!cardImg(pid, i.id, s), slot: i.id, side: s })));
  return { items, missing: items.filter(x => !x.ok), selfPay };
}
