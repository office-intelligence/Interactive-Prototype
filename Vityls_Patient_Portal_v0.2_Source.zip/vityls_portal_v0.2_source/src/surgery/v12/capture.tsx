/* v0.12 · Reliable picture input: a real <label>-wrapped file input (works on iPad/Android/desktop without a programmatic
 * click), drag-and-drop, and "Take photo" that uses the live camera (getUserMedia) when available and falls back to the
 * device's camera picker (<input capture>) or a plain file picker when there is no camera / permission is denied. */
import React, { useEffect, useRef, useState } from 'react';
import { Camera, Upload } from 'lucide-react';
import { compressImage, compressVideoFrame, ImageError } from './img';

export const errText = (e: unknown) => e instanceof ImageError ? e.message : (e as Error)?.message?.includes('storage') ? (e as Error).message : 'The picture could not be saved. Try a JPG or PNG photo.';

/** Visually hidden but real, clickable through its <label>. */
const HIDE: React.CSSProperties = { position: 'absolute', width: 1, height: 1, opacity: 0, overflow: 'hidden', clip: 'rect(0 0 0 0)', pointerEvents: 'none' };
export const UploadLabel: React.FC<{ onData: (d: string, how: string) => void; onError: (m: string) => void; testId: string; className?: string; children: React.ReactNode; capture?: 'user' | 'environment'; role?: string }> = ({ onData, onError, testId, className, children, capture, role }) => {
  const [busy, setBusy] = useState(false);
  return <label className={className} role={role} data-testid={testId} aria-busy={busy}>
    <input type="file" accept="image/*,.jpg,.jpeg,.png" capture={capture} style={HIDE} tabIndex={-1} data-testid={`${testId}-input`}
      onChange={async e => { const f = e.target.files?.[0]; e.target.value = ''; if (!f) return; setBusy(true); try { onData(await compressImage(f), capture ? 'camera' : 'upload'); } catch (x) { onError(errText(x)); } finally { setBusy(false); } }} />
    {busy ? 'Saving…' : children}</label>;
};
/** Drop zone wrapper: drag a JPG/PNG onto it. */
export function useDrop(onData: (d: string, how: string) => void, onError: (m: string) => void) {
  const [over, setOver] = useState(false);
  return { over, props: {
    onDragOver: (e: React.DragEvent) => { if (Array.from(e.dataTransfer.types).includes('Files')) { e.preventDefault(); e.dataTransfer.dropEffect = 'copy'; setOver(true); } },
    onDragLeave: () => setOver(false),
    onDrop: async (e: React.DragEvent) => { e.preventDefault(); setOver(false); const f = e.dataTransfer.files?.[0]; if (!f) return; try { onData(await compressImage(f), 'drag & drop'); } catch (x) { onError(errText(x)); } } } };
}
/** Live camera dialog; calls onFallback() when the camera can't be opened. */
export const CameraDialog: React.FC<{ title: string; facing?: 'user' | 'environment'; onShot: (d: string) => void; onClose: () => void; onError: (m: string) => void }> = ({ title, facing = 'user', onShot, onClose, onError }) => {
  const vid = useRef<HTMLVideoElement>(null); const [st, setSt] = useState<'opening' | 'live' | 'failed'>('opening'); const stream = useRef<MediaStream | null>(null);
  useEffect(() => { let off = false;
    (async () => { try { if (!navigator.mediaDevices?.getUserMedia) throw new Error('no camera api'); const s = await navigator.mediaDevices.getUserMedia({ video: { facingMode: facing, width: { ideal: 1280 } }, audio: false }); if (off) { s.getTracks().forEach(t => t.stop()); return; } stream.current = s; if (vid.current) { vid.current.srcObject = s; await vid.current.play().catch(() => {}); } setSt('live'); } catch { if (!off) setSt('failed'); } })();
    return () => { off = true; stream.current?.getTracks().forEach(t => t.stop()); }; }, [facing]);
  return <div className="sv-modal" role="dialog" aria-modal="true" aria-label={title} data-testid="camera-dialog"><div className="sv-modal-scrim" onClick={onClose} />
    <div className="sv-modal-box" style={{ width: 'min(560px, calc(100vw - 24px))' }}>
      <b className="text-[15px]">{title}</b>
      {st !== 'failed' ? <video ref={vid} playsInline muted className="v12-cam mt-2" data-testid="camera-video" /> :
        <p className="text-[13px] mt-2" data-testid="camera-fallback">The camera could not be opened here (no camera, or permission was not given). Choose a picture instead. On a tablet this opens the camera.</p>}
      <div className="flex gap-2 justify-end mt-3 flex-wrap">
        <button type="button" className="sv-btn" onClick={onClose}>Cancel</button>
        {st === 'failed' ? <UploadLabel className="sv-btn primary" capture={facing} testId="camera-fallback-pick" onData={d => onShot(d)} onError={onError}><Camera size={14} /> Choose / take picture</UploadLabel>
          : <button type="button" className="sv-btn primary" disabled={st !== 'live'} onClick={() => { const v = vid.current; if (!v || !v.videoWidth) { onError('The camera is not ready yet.'); return; } onShot(compressVideoFrame(v)); }} data-testid="camera-shoot"><Camera size={14} /> Capture</button>}
      </div></div></div>;
};
/** One card/photo slot: shows the picture or a placeholder; upload, drag & drop, take photo, replace, remove. */
export const ImageSlot: React.FC<{ label: string; value?: string; meta?: string; testId: string; facing?: 'user' | 'environment'; onSet: (d: string, how: string) => void; onRemove?: () => void; onError: (m: string) => void; compact?: boolean }> = ({ label, value, meta, testId, facing = 'environment', onSet, onRemove, onError, compact }) => {
  const [cam, setCam] = useState(false); const dz = useDrop(onSet, onError);
  return <div className={`v12-slot ${value ? 'has' : ''} ${dz.over ? 'over' : ''} ${compact ? 'compact' : ''}`} data-testid={testId} data-has={value ? 'true' : 'false'} {...dz.props}>
    <div className="v12-slot-k">{label}</div>
    <div className="v12-slot-img">{value ? <img src={value} alt={label} data-testid={`${testId}-img`} /> : <span className="v12-slot-ph">Missing<br /><span>drop a JPG/PNG here</span></span>}</div>
    {meta && value && <div className="v12-slot-meta">{meta}</div>}
    <div className="v12-slot-acts">
      <UploadLabel className="sv-btn sm" testId={`${testId}-upload`} onData={onSet} onError={onError}><Upload size={13} />{value ? 'Replace' : 'Upload'}</UploadLabel>
      <button type="button" className="sv-btn sm" onClick={() => setCam(true)} data-testid={`${testId}-camera`}><Camera size={13} />Capture</button>
      {value && onRemove && <button type="button" className="sv-btn sm" onClick={onRemove} data-testid={`${testId}-remove`}>Remove</button>}
    </div>
    {cam && <CameraDialog title={`Capture · ${label}`} facing={facing} onClose={() => setCam(false)} onError={m => { onError(m); }} onShot={d => { setCam(false); onSet(d, 'camera'); }} />}
  </div>;
};
