/* v0.12 · BUG fix: Patient Registration must say "First Name" / "Last Name", never "Legal …".
 * v0.10 only rewrote the HTML on its way into the form engine. Remaining sources, all fixed here (Surgery only):
 *  1. stored state: practice template copies (draft + every published version in `form-lib`), Form Studio/legacy
 *     `vityls-master-form-template:*` / `vityls-form-template:*` copies, and saved form records whose `labels` were
 *     captured with the old wording (shown in print and the record) → one-time rewrite of the Surgery namespace;
 *  2. in-memory structured libraries (OFFICIAL_HTML_FORM_LIBRARY field labels, ASC_DEFAULT_FORM_PRESENTATIONS) that the
 *     portal and the library cards read → patched at start-up in the Surgery app only (ASC packages never run this);
 *     (audit entries are history and are left as recorded)
 *  3. a last-line DOM pass on every mounted form (formChrome.applyChrome) for anything that slipped through. */
import { rawStorage, SURGERY_NAMESPACE, MEDICAL_NAMESPACE, isMedical } from '../../edition';
import { OFFICIAL_HTML_FORM_LIBRARY } from '../../data/officialHtmlFormLibrary';
import { ASC_DEFAULT_FORM_PRESENTATIONS } from '../../data/ascDefaultFormPresentations';
import { repo } from '../../v6/dataLayer';
export const LEGAL_RE = /\bLegal\s+(First\s+and\s+Last|First|Last)\s+Name\b/gi;
const fix = (m: string, w: string) => /and/i.test(w) ? 'First and Last Name' : /first/i.test(w) ? 'First Name' : 'Last Name';
export const dropLegal = (s: string) => s.replace(LEGAL_RE, fix);
export function patchLegalInMemory() {
  OFFICIAL_HTML_FORM_LIBRARY.forEach(t => { if (!/Registration/i.test(t.title + t.sourceFile)) return; t.fields.forEach(f => { f.label = dropLegal(f.label); }); });
  Object.keys(ASC_DEFAULT_FORM_PRESENTATIONS).forEach(k => { if (/Registration/i.test(k)) ASC_DEFAULT_FORM_PRESENTATIONS[k] = dropLegal(ASC_DEFAULT_FORM_PRESENTATIONS[k]); });
}
/** Rewrites stored Surgery data. Idempotent; returns how many stored entries changed. */
export function migrateLegalStored(): number {
  let n = 0; const keys: string[] = []; try { for (let i = 0; i < rawStorage.length; i++) { const k = rawStorage.key(i); if (k && k.startsWith(isMedical ? MEDICAL_NAMESPACE : SURGERY_NAMESPACE) && !/audit/i.test(k)) keys.push(k); } } catch { return 0; }
  keys.forEach(k => { try { const v = rawStorage.getItem(k); if (!v || !/Legal\s+(First|Last)/i.test(v)) return; const nv = dropLegal(v); if (nv !== v) { rawStorage.setItem(k, nv); n++; } } catch { /* storage full: leave it */ } });
  if (n) try { repo.audit({ caseId: 'practice', user: 'Vityls (migration)', role: 'System', action: 'forms.migrate' as any, detail: `v0.12: Patient Registration name fields reworded to “First Name” / “Last Name” (the old “Legal …” prefix removed) in ${n} saved item${n === 1 ? '' : 's'} (practice template copies, versions, saved form labels)` }); } catch { /* */ }
  return n;
}
/** DOM safety net inside a mounted form (shadow root). */
export function fixLegalDom(root: ParentNode) {
  root.querySelectorAll('label, .label, th, td, span, b, strong, p, div.field-label, legend').forEach(el => { el.childNodes.forEach(c => { if (c.nodeType === 3 && /Legal\s+(First|Last)/i.test(c.nodeValue || '')) c.nodeValue = dropLegal(c.nodeValue || ''); }); });
}
