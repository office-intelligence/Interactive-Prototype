/* v0.12 · Nightingale "Suggest from note & history" (SIMULATED, deterministic, no AI service): keyword rules over the
 * doctor's visit note / ambient-scribe draft and transcript, the nurse intake, the visit reason and the patient's
 * incoming medical-history and intake forms. Proposes surgical diagnoses (ICD-10 text) and planned procedures with the
 * sentences they came from. Nothing is saved: the clinician accepts, edits or dismisses each one. */
import { isMedical } from '../../edition';
import { repo } from '../../v6/dataLayer';
import { medRepo, MedPatient, MedVisit } from '../../med/record';
import { scribeSession, nurseAdmission } from '../store';
import { dxList } from '../v10/dx';
export interface DxSuggestion { key: string; diagnosis: string; icd: string; procedure: string; sources: { from: string; text: string }[] }
type Rule = { key: string; re: RegExp; diagnosis: string; icd: string; procedure: string };
/** Medical.Vityls: primary-care diagnoses; `procedure` holds the suggested plan item (treatment, order or referral). */
const MEDICAL_RULES: Rule[] = [
  { key: 'dm2', re: /type 2 diabetes|diabetes|\ba1c\b|metformin|high (blood )?sugars?|hyperglycemi/i, diagnosis: 'Type 2 diabetes mellitus without complications', icd: 'E11.9', procedure: 'Hemoglobin A1c every 3 months' },
  { key: 'htn', re: /hypertension|high blood pressure|\bbp\b.*(high|elevated)|lisinopril|amlodipine/i, diagnosis: 'Essential hypertension', icd: 'I10', procedure: 'Home blood pressure log, review in 4 weeks' },
  { key: 'lipid', re: /hyperlipidemia|high cholesterol|\bldl\b|statin|atorvastatin/i, diagnosis: 'Hyperlipidemia', icd: 'E78.5', procedure: 'Fasting lipid panel' },
  { key: 'thyroid', re: /hypothyroid|levothyroxine|\btsh\b/i, diagnosis: 'Hypothyroidism', icd: 'E03.9', procedure: 'TSH in 6 weeks' },
  { key: 'afib', re: /atrial fibrillation|\bafib\b|palpitations|apixaban/i, diagnosis: 'Atrial fibrillation', icd: 'I48.91', procedure: 'Referral to cardiology' },
  { key: 'asthma', re: /asthma|wheez|inhaler/i, diagnosis: 'Asthma, uncomplicated', icd: 'J45.909', procedure: 'Spirometry' },
  { key: 'copd', re: /\bcopd\b|emphysema|chronic bronchitis/i, diagnosis: 'Chronic obstructive pulmonary disease', icd: 'J44.9', procedure: 'Spirometry' },
  { key: 'osa', re: /sleep apnea|\bcpap\b|snoring/i, diagnosis: 'Obstructive sleep apnea', icd: 'G47.33', procedure: 'Continue CPAP; sleep medicine follow-up' },
  { key: 'uri', re: /sore throat|pharyngitis|cough|congestion|\buri\b/i, diagnosis: 'Acute upper respiratory infection', icd: 'J06.9', procedure: 'Supportive care; rapid strep if indicated' },
  { key: 'dep', re: /depress|low mood|anhedonia|\bphq-?9\b/i, diagnosis: 'Depression, unspecified', icd: 'F32.A', procedure: 'Referral to behavioral health' },
  { key: 'gerd', re: /reflux|heartburn|\bgerd\b/i, diagnosis: 'Gastroesophageal reflux disease', icd: 'K21.9', procedure: 'Omeprazole 20 mg daily trial' },
  { key: 'ckd', re: /chronic kidney|\bckd\b|\begfr\b/i, diagnosis: 'Chronic kidney disease, unspecified', icd: 'N18.9', procedure: 'Referral to nephrology' },
  { key: 'tob', re: /smok|tobacco|cigarette/i, diagnosis: 'Nicotine dependence, cigarettes', icd: 'F17.210', procedure: 'Smoking cessation counseling' },
  { key: 'lesion', re: /skin lesion|suspicious (mole|lesion)|changing mole|nevus/i, diagnosis: 'Neoplasm of uncertain behavior of skin', icd: 'D48.5', procedure: 'Referral to dermatology' },
];
const SURGERY_RULES: Rule[] = [
  { key: 'derm', re: /dermatochalasis|heav(y|ier) (upper )?(eye)?lids|(upper )?lids? (keep getting|are) heav|hooding|excess (upper )?eyelid skin|skin resting on the lashes|blepharoplasty/i, diagnosis: 'Dermatochalasis of upper eyelids', icd: 'H02.831, H02.834', procedure: 'Bilateral upper blepharoplasty' },
  { key: 'ptosis', re: /(eyelid|blepharo)\s*ptosis|droopy eyelid|ptosis repair/i, diagnosis: 'Blepharoptosis, bilateral', icd: 'H02.403', procedure: 'Bilateral ptosis repair' },
  { key: 'face', re: /jowl|facial rhytid|sagging (face|neck|jaw)|neck laxity|turkey neck|face ?lift|neck ?lift/i, diagnosis: 'Facial rhytides / jowling', icd: 'L90.8', procedure: 'Facelift / necklift' },
  { key: 'neuro', re: /forehead (lines|rhytid)|frown lines|glabellar|crow'?s feet|botox|neuromodulator|dynamic rhytid/i, diagnosis: 'Dynamic forehead rhytides', icd: 'L90.8', procedure: 'Neuromodulator injection' },
  { key: 'bcc', re: /basal cell|\bbcc\b|mohs/i, diagnosis: 'Basal cell carcinoma, cheek', icd: 'C44.319', procedure: 'Mohs reconstruction, local flap' },
  { key: 'septum', re: /deviated septum|nasal (airway )?obstruction|can'?t breathe through (my|the) nose/i, diagnosis: 'Deviated nasal septum', icd: 'J34.2', procedure: 'Septoplasty' },
  { key: 'nose', re: /nasal deformity|dorsal hump|rhinoplasty|shape of (my|the) nose/i, diagnosis: 'Nasal deformity', icd: 'M95.0', procedure: 'Rhinoplasty' },
  { key: 'abdo', re: /diastasis|abdominal (wall )?(laxity|skin)|loose (belly|abdominal) skin|tummy tuck|abdominoplasty/i, diagnosis: 'Abdominal wall laxity / diastasis', icd: 'M62.08', procedure: 'Abdominoplasty' },
  { key: 'redux', re: /breast hypertrophy|macromastia|breast reduction|reduction mammaplasty|shoulder grooving/i, diagnosis: 'Breast hypertrophy', icd: 'N62', procedure: 'Reduction mammaplasty' },
  { key: 'masto', re: /breast ptosis|sagging breasts?|mastopexy|breast lift/i, diagnosis: 'Ptosis of breast', icd: 'N64.81', procedure: 'Mastopexy' },
  { key: 'gyn', re: /gynecomastia/i, diagnosis: 'Gynecomastia', icd: 'N62', procedure: 'Excision of gynecomastia' },
  { key: 'lipo', re: /localized (fat|adiposity)|lipodystrophy|stubborn fat|liposuction/i, diagnosis: 'Localized adiposity', icd: 'E65', procedure: 'Suction-assisted lipectomy (liposuction)' },
  { key: 'scar', re: /keloid|hypertrophic scar|scar revision|painful scar/i, diagnosis: 'Hypertrophic scar / keloid', icd: 'L91.0', procedure: 'Scar revision' },
  { key: 'lesion', re: /skin lesion|suspicious (mole|lesion)|changing mole|nevus/i, diagnosis: 'Neoplasm of uncertain behavior of skin', icd: 'D48.5', procedure: 'Excision of skin lesion' },
  { key: 'ctr', re: /carpal tunnel/i, diagnosis: 'Carpal tunnel syndrome', icd: 'G56.00', procedure: 'Carpal tunnel release' },
];
const RULES: Rule[] = isMedical ? MEDICAL_RULES : SURGERY_RULES;
const str = (v: unknown) => typeof v === 'string' ? v : Array.isArray(v) ? v.filter(x => typeof x === 'string').join(', ') : typeof v === 'boolean' ? '' : v == null ? '' : String(v);
/** All text Nightingale reads, tagged by where it came from. */
export function sourcesFor(v: MedVisit, p: MedPatient): { from: string; text: string }[] {
  const out: { from: string; text: string }[] = []; const add = (from: string, text?: string) => { if (text && text.trim()) out.push({ from, text: text.trim() }); };
  const n = medRepo.note(v.id); if (n) { add('Visit note · HPI', n.subjective); add('Visit note · exam', n.objective); add('Visit note · assessment', n.assessment); add('Visit note · plan', n.plan); }
  const s = scribeSession(v.id); if (!n) { add('Scribe draft · HPI', s.draft.hpi); add('Scribe draft · exam', s.draft.exam); add('Scribe draft · assessment', s.draft.assessment); add('Scribe draft · plan', s.draft.plan); }
  s.lines.forEach(l => add(`Transcript · ${l.speaker}`, l.text));
  const nu = nurseAdmission(v.id); if (nu) { add('Nurse intake · chief complaint', nu.chiefComplaint); add('Nurse intake · note', nu.nurseNote); }
  add('Visit reason', v.reason);
  const cases = [v.id, `portal-forms:${p.id}`, ...medRepo.visits(p.id).filter(x => x.id !== v.id).map(x => x.id)];
  const seen = new Set<string>();
  cases.forEach(c => repo.listForms(c).forEach(f => { if (seen.has(`${c}|${f.file}`)) return; seen.add(`${c}|${f.file}`); const title = f.file.replace(/\.html$/, '').replace(/_/g, ' ');
    Object.entries(f.values || {}).forEach(([k, val]) => { const t = str(val); if (t.length > 2 && !/^(yes|no|on|true|false)$/i.test(t)) add(`${title} · ${f.labels?.[k] || k}`, t); }); }));
  medRepo.problems(p.id).filter(x => x.status === 'active').forEach(x => add('Problem list', x.description));
  return out;
}
const snippet = (t: string, re: RegExp) => { const m = t.match(re); if (!m || m.index == null) return t.slice(0, 120); const a = Math.max(0, m.index - 50); return `${a ? '…' : ''}${t.slice(a, m.index + m[0].length + 60)}${m.index + m[0].length + 60 < t.length ? '…' : ''}`; };
export function suggestDx(v: MedVisit, p: MedPatient): DxSuggestion[] {
  const src = sourcesFor(v, p); const have = dxList(p);
  return RULES.flatMap(r => { const hits = src.filter(x => r.re.test(x.text)); if (!hits.length) return [];
    const ex = have.find(d => d.diagnosis.toLowerCase() === r.diagnosis.toLowerCase()); if (ex && ex.procedures.some(x => x.name.toLowerCase() === r.procedure.toLowerCase())) return [];
    return [{ key: r.key, diagnosis: r.diagnosis, icd: r.icd, procedure: r.procedure, sources: hits.slice(0, 3).map(h => ({ from: h.from, text: snippet(h.text, r.re) })) }]; });
}
