/* v0.12 · Chart › Overview right column: "Past visits" card, newest first (date, type, provider, status), each opening its
 * visit workflow / visit record. Shows 3, "Show more" adds 5, "Show all" lists everything. Before v0.12 past visits were
 * only in Clinical record › "Visits & notes" (5 most recent) and the header's single "Last visit workflow" link. */
import React, { useState } from 'react';
import { medRepo, MedPatient, MedVisit, isoDay, usDate } from '../../med/record';
import { useMedTick } from '../../med/ui';
import { useSv } from '../ui';
import { STATION_LABEL } from '../nightingale';
import { prov } from '../v07/Today7';
export function pastVisits(pid: string): MedVisit[] { const t = isoDay(); return medRepo.visits(pid).filter(v => v.date < t || (v.date === t && v.step === 'complete')).sort((a, b) => (b.date + b.time).localeCompare(a.date + a.time)); }
const status = (v: MedVisit): [string, string] => { const n = medRepo.note(v.id);
  if (v.step === 'complete') return [n?.status === 'signed' ? 'Completed · note signed' : 'Completed', 'gray'];
  if (v.step === 'scheduled') return ['Not checked in', 'amber'];
  return [`Open · ${STATION_LABEL[v.step] || v.step}`, 'blue']; };
export const PastVisits: React.FC<{ p: MedPatient }> = ({ p }) => {
  useMedTick(); const { go } = useSv(); const [n, setN] = useState(3); const l = pastVisits(p.id); const shown = l.slice(0, n);
  return <section className="v7-card v7-side" data-testid="chart-past-visits"><div className="k">PAST VISITS{l.length ? ` (${l.length})` : ''}</div>
    {l.length === 0 ? <div className="s">No past visits yet.</div> : <ul className="v12-pv">{shown.map(v => { const [s, tone] = status(v);
      return <li key={v.id}><button type="button" className="row" onClick={() => go({ type: 'station', visitId: v.id })} data-testid="past-visit" title="Open the visit workflow">
        <div className="t">{usDate(v.date)} · {v.visitType}</div><div className="s">{prov(v.provider)} · <span className={`v7-pill ${tone}`}>{s}</span> <span className="v7-quiet">{v.step === 'complete' ? 'Visit record' : 'Workflow'} →</span></div></button></li>; })}</ul>}
    {l.length > n && <div className="flex gap-4 mt-1.5"><button type="button" className="v7-quiet" onClick={() => setN(n + 5)} data-testid="past-more">Show more</button><button type="button" className="v7-quiet" onClick={() => setN(l.length)} data-testid="past-all">Show all {l.length}</button></div>}
    {n > 3 && l.length <= n && l.length > 3 && <button type="button" className="v7-quiet mt-1.5" onClick={() => setN(3)} data-testid="past-less">Show fewer</button>}
  </section>;
};
