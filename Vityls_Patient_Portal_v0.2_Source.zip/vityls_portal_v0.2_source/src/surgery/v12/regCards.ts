/* v0.12 · Patient Registration template: photo ID + insurance card capture block (front/back, primary + secondary).
 * Mounted into the form (shadow root) by formChrome for Patient_Registration.html wherever it opens: portal at home,
 * front desk station, chart. Pictures go straight to the chart (cards.ts, compressed, audited), not into form values,
 * so the signed form stays small and the chart Cards spot updates immediately. */
import { medRepo } from '../../med/record';
import { repo } from '../../v6/dataLayer';
import { compressImage } from './img';
import { errText } from './capture';
import { cardsFor, cardImg, setCardImage, addIns, Side } from './cards';
const CSS = `.sv12-reg{border:1px solid #e2e6e1;border-radius:3px;padding:14px 16px;margin:14px 0;background:#fff}
.sv12-reg h3{font-size:13px;font-weight:800;color:#1f5d52;letter-spacing:.04em;text-transform:uppercase;margin:0 0 4px}
.sv12-reg .note{font-size:12px;color:#55645f;margin:0 0 10px}
.sv12-reg .g{display:grid;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:10px}
.sv12-reg .s{border:1px solid #e2e6e1;border-radius:3px;padding:8px;display:flex;flex-direction:column;gap:6px}
.sv12-reg .k{font-size:11px;font-weight:700;color:#55645f;text-transform:uppercase;letter-spacing:.04em}
.sv12-reg .im{height:90px;border:1px dashed #cfd6d1;border-radius:3px;display:flex;align-items:center;justify-content:center;overflow:hidden;background:#f7f8f6;font-size:12px;color:#a16207}
.sv12-reg .im img{max-width:100%;max-height:100%}
.sv12-reg label.b{display:inline-flex;justify-content:center;align-items:center;border:1px solid #c9d1cc;border-radius:3px;padding:6px 8px;font-size:12.5px;cursor:pointer;background:#fff;position:relative;min-height:36px}
.sv12-reg label.b input{position:absolute;width:1px;height:1px;opacity:0;pointer-events:none}
.sv12-reg .msg{font-size:12px;margin-top:8px;color:#166534}
@media print{.sv12-reg label.b{display:none}}`;
const SLOTS: { slot: 'id' | 'ins1' | 'ins2'; side: Side; label: string }[] = [
  { slot: 'id', side: 'front', label: 'Photo ID · front' }, { slot: 'id', side: 'back', label: 'Photo ID · back' },
  { slot: 'ins1', side: 'front', label: 'Primary insurance · front' }, { slot: 'ins1', side: 'back', label: 'Primary insurance · back' },
  { slot: 'ins2', side: 'front', label: 'Secondary insurance · front' }, { slot: 'ins2', side: 'back', label: 'Secondary insurance · back' }];
function realSlot(pid: string, s: 'id' | 'ins1' | 'ins2', create: boolean, by: string, role: string): string | undefined {
  if (s === 'id') return 'id'; const c = cardsFor(pid); const i = s === 'ins1' ? 0 : 1;
  if (c.insurance[i]) return c.insurance[i].id; if (!create) return undefined; if (i === 1) return addIns(pid, by, role).id; return c.insurance[0]?.id;
}
export function mountRegistrationCards(root: ShadowRoot, mrn: string, name?: string) {
  const pid = mrn && medRepo.patient(mrn) ? mrn : medRepo.patients().find(x => x.name === name)?.id || '';
  if (!pid || root.querySelector('.sv12-reg')) return;
  const box = root.querySelector('.vk-root') || root; const st = document.createElement('style'); st.textContent = CSS; root.appendChild(st);
  const portal = !!document.querySelector('[data-testid=portal]'); const who = () => { const a = repo.getActor(); return portal ? { name: medRepo.patient(pid)?.name || 'Patient', role: 'Patient (portal)' } : { name: a.name, role: a.role }; };
  const sec = document.createElement('section'); sec.className = 'sv12-reg'; sec.setAttribute('data-testid', 'reg-cards');
  sec.innerHTML = `<h3>Photo ID &amp; insurance cards</h3><p class="note">Take a picture of the front and back of your photo ID and each insurance card, or upload a JPG/PNG. Pictures are saved to your chart at the office. Secondary insurance is optional.</p><div class="g"></div><div class="msg" aria-live="polite"></div>`;
  const g = sec.querySelector('.g')!; const msg = sec.querySelector('.msg') as HTMLElement;
  const render = () => { g.innerHTML = ''; SLOTS.forEach(S => { const real = realSlot(pid, S.slot, false, '', ''); const v = real ? cardImg(pid, real, S.side) : '';
    const d = document.createElement('div'); d.className = 's'; d.setAttribute('data-testid', `reg-card-${S.slot}-${S.side}`); d.setAttribute('data-has', v ? 'true' : 'false');
    d.innerHTML = `<div class="k">${S.label}</div><div class="im">${v ? `<img alt="${S.label}" src="${v}">` : 'Not added'}</div><label class="b">${v ? 'Replace' : 'Take photo / upload'}<input type="file" accept="image/*,.jpg,.jpeg,.png" capture="environment" data-testid="reg-card-${S.slot}-${S.side}-input"></label>`;
    d.querySelector('input')!.addEventListener('change', async e => { const inp = e.target as HTMLInputElement; const f = inp.files?.[0]; inp.value = ''; if (!f) return; msg.style.color = '#55645f'; msg.textContent = 'Saving…';
      try { const data = await compressImage(f); const w = who(); const rs = realSlot(pid, S.slot, true, w.name, w.role)!; await setCardImage(pid, rs, S.side, data, w.name, w.role, portal ? 'Patient Registration form (portal)' : 'Patient Registration form'); msg.style.color = '#166534'; msg.textContent = `${S.label} saved to the chart.`; render(); }
      catch (x) { msg.style.color = '#b91c1c'; msg.textContent = errText(x); } });
    g.appendChild(d); }); };
  render();
  const anchor = Array.from(box.querySelectorAll('.sig-pad, .signature, [class*=sign]')).find(el => !(el as HTMLElement).closest('.sv12-reg')) as HTMLElement | undefined;
  const sectionOf = anchor?.closest('.section, section, .form-section, .card') as HTMLElement | null;
  if (sectionOf && sectionOf.parentElement) sectionOf.parentElement.insertBefore(sec, sectionOf); else (box.querySelector('form') || box).appendChild(sec);
}
