/* v0.12 · Attachment picker, chips (view / download / File to Documents) and the Surgery portal messages card. */
import React, { useState } from 'react';
import { Paperclip, Eye, Download, FolderInput, X, FileText } from 'lucide-react';
import { medRepo, MedPatient, uid, fmtDateTime, isoDay } from '../../med/record';
import { useActor, useMedTick } from '../../med/ui';
import { docTypes } from '../documents';
import { prepare, saveAtts, attsOf, attData, downloadAtt, fileToDocuments, Pending, Att, ACCEPT, MAX_FILES } from './msgAtt';
const kb = (n: number) => n > 1048576 ? `${(n / 1048576).toFixed(1)} MB` : `${Math.max(1, Math.round(n / 1024))} KB`;
export function usePending(onError: (m: string) => void) {
  const [l, setL] = useState<Pending[]>([]); const [busy, setBusy] = useState(false);
  const add = async (fs: FileList | null) => { if (!fs) return; setBusy(true); const out: Pending[] = [];
    for (const f of Array.from(fs)) { if (l.length + out.length >= MAX_FILES) { onError(`Up to ${MAX_FILES} files per message.`); break; } try { out.push(await prepare(f)); } catch (e) { onError((e as Error).message); } }
    setL(x => [...x, ...out]); setBusy(false); };
  return { l, busy, add, remove: (t: string) => setL(x => x.filter(y => y.tmp !== t)), clear: () => setL([]) };
}
export const AttachButton: React.FC<{ pend: ReturnType<typeof usePending>; testId: string; className?: string }> = ({ pend, testId, className = 'sv-btn' }) =>
  <label className={`${className} v12-attach`} data-testid={testId} title="Attach PDF, JPG, PNG, HEIC, DOC (images are compressed; other files up to 3 MB)"><Paperclip size={15} />{pend.busy ? 'Adding…' : 'Attach'}
    <input type="file" multiple accept={ACCEPT} style={{ position: 'absolute', width: 1, height: 1, opacity: 0, pointerEvents: 'none' }} tabIndex={-1} data-testid={`${testId}-input`} onChange={e => { void pend.add(e.target.files); e.target.value = ''; }} /></label>;
export const PendingChips: React.FC<{ pend: ReturnType<typeof usePending> }> = ({ pend }) => pend.l.length ? <div className="v12-chips mt-2" data-testid="att-pending">{pend.l.map(p =>
  <span key={p.tmp} className="v12-att"><FileText size={13} />{p.name} · {kb(p.size)}<button type="button" onClick={() => pend.remove(p.tmp)} aria-label={`Remove ${p.name}`}><X size={12} /></button></span>)}</div> : null;
export async function sendWithAtts(m: { patientId: string; from: 'patient' | 'caregiver' | 'office'; author: string; text: string }, pend: ReturnType<typeof usePending>, by: string, role: string) {
  const id = uid('pm'); const text = m.text.trim() || (pend.l.length ? `(${pend.l.length} attachment${pend.l.length === 1 ? '' : 's'})` : '');
  await saveAtts(id, m.patientId, by, role, pend.l); medRepo.addMessage({ id, ...m, text, at: new Date().toISOString() }); pend.clear();
}
/** Chips under a message. Staff see "File to Documents" on attachments from the patient / caregiver. */
export const AttChips: React.FC<{ msgId: string; staff?: boolean; incoming?: boolean; toast?: (m: string) => void; onOpenDoc?: (pid: string, docId: string) => void }> = ({ msgId, staff, incoming, toast, onOpenDoc }) => {
  useMedTick(); const [actor] = useActor(); const l = attsOf(msgId); const [view, setView] = useState<Att | null>(null); const [file, setFile] = useState<Att | null>(null);
  if (!l.length) return null; const who = staff ? actor : { name: 'Patient', role: 'Patient (portal)' };
  return <div className="v12-chips mt-1.5" data-testid="msg-atts">{l.map(a => <span key={a.id} className="v12-att" data-testid="msg-att" data-filed={a.filed ? 'true' : 'false'}>
    <FileText size={13} /><b>{a.name}</b> · {kb(a.size)}
    <button type="button" onClick={() => setView(a)} data-testid="att-view" aria-label={`View ${a.name}`}><Eye size={13} /></button>
    <button type="button" onClick={() => downloadAtt(a, who.name, who.role)} data-testid="att-download" aria-label={`Download ${a.name}`}><Download size={13} /></button>
    {staff && incoming && (a.filed ? <button type="button" className="v12-filed" onClick={() => onOpenDoc?.(a.patientId, a.filed!.docId)} data-testid="att-filed" title={`Filed by ${a.filed.by} · ${fmtDateTime(a.filed.at)}`}>✓ Filed · {a.filed.type}</button>
      : <button type="button" className="v12-tofile" onClick={() => setFile(a)} data-testid="att-file"><FolderInput size={13} /> File to Documents</button>)}
    {staff && incoming && !a.filed && <span className="v12-notfiled" data-testid="att-notfiled">not filed</span>}
  </span>)}
    {view && <div className="sv-modal" role="dialog" aria-modal="true" aria-label={view.name} data-testid="att-viewer"><div className="sv-modal-scrim" onClick={() => setView(null)} /><div className="sv-modal-box" style={{ width: 'min(820px, calc(100vw - 24px))' }}>
      <div className="flex items-center gap-2 mb-2"><b className="text-[14px]">{view.name}</b><button type="button" className="ml-auto" onClick={() => setView(null)} aria-label="Close"><X size={16} /></button></div>
      {view.kind === 'image' ? <img src={attData(view)} alt={view.name} style={{ maxWidth: '100%', maxHeight: '70vh' }} /> : view.kind === 'pdf' ? <iframe title={view.name} src={attData(view)} style={{ width: '100%', height: '70vh', border: 0 }} />
        : <p className="text-[13px]">{view.kind === 'heic' ? 'HEIC photos can’t be previewed in this browser.' : 'Word documents can’t be previewed here.'} Use Download to open it.</p>}
      <div className="flex justify-end mt-2"><button type="button" className="sv-btn" onClick={() => downloadAtt(view, who.name, who.role)}><Download size={14} /> Download</button></div></div></div>}
    {file && <FileDialog a={file} onClose={() => setFile(null)} onDone={d => { setFile(null); toast?.(`Filed to ${medRepo.patient(file.patientId)?.name || 'the patient'}’s Documents as ${d}. Nightingale summary ready.`); }} />}
  </div>;
};
const FileDialog: React.FC<{ a: Att; onClose: () => void; onDone: (type: string) => void }> = ({ a, onClose, onDone }) => {
  const [actor] = useActor(); const types = docTypes(); const [type, setType] = useState(types.includes('Outside records') ? 'Outside records' : types[0]); const [title, setTitle] = useState(a.name.replace(/\.[^.]+$/, '')); const [date, setDate] = useState(isoDay()); const [err, setErr] = useState('');
  return <div className="sv-modal" role="dialog" aria-modal="true" aria-label="File to Documents" data-testid="att-file-dialog"><div className="sv-modal-scrim" onClick={onClose} /><div className="sv-modal-box" style={{ width: 'min(480px, calc(100vw - 24px))' }}>
    <b className="text-[15px]">File to Documents</b><p className="sv-small sv-muted mt-1">{a.name} goes into {medRepo.patient(a.patientId)?.name}’s Documents folder, linked to this message. Nightingale then reads it (simulated).</p>
    <label className="block mt-2"><span className="sv-label">Document type</span><select className="sv-input" value={type} onChange={e => setType(e.target.value)} data-testid="att-file-type">{types.map(t => <option key={t}>{t}</option>)}</select></label>
    <label className="block mt-2"><span className="sv-label">Title</span><input className="sv-input" value={title} onChange={e => setTitle(e.target.value)} data-testid="att-file-title" /></label>
    <label className="block mt-2"><span className="sv-label">Document date</span><input type="date" className="sv-input" value={date} onChange={e => setDate(e.target.value)} /></label>
    {err && <p className="text-[12.5px] mt-2" style={{ color: 'var(--crit)' }} role="alert">{err}</p>}
    <div className="flex justify-end gap-2 mt-3"><button type="button" className="sv-btn" onClick={onClose}>Cancel</button><button type="button" className="sv-btn primary" onClick={() => { try { fileToDocuments(a, type, title, date, actor.name, actor.role); onDone(type); } catch (e) { setErr((e as Error).message); } }} data-testid="att-file-save">File it</button></div>
  </div></div>;
};
/** Surgery portal Messages card (patients and caregivers can attach to new messages and replies). */
export const SurgeryPortalMessages: React.FC<{ p: MedPatient; author: string; from: 'patient' | 'caregiver' }> = ({ p, author, from }) => {
  useMedTick(); const [t, setT] = useState(''); const [err, setErr] = useState(''); const pend = usePending(setErr); const msgs = medRepo.messages(p.id);
  const send = async () => { setErr(''); if (!t.trim() && !pend.l.length) return; try { await sendWithAtts({ patientId: p.id, from, author, text: t }, pend, author, from === 'patient' ? 'Patient (portal)' : 'Caregiver (portal)'); setT(''); } catch (e) { setErr((e as Error).message); } };
  return <div className="vy-card p-4" data-testid="portal-messages"><div className="text-[12px] font-bold tracking-[.08em] uppercase text-[#5f6862]">Messages</div><div className="text-[18px] font-bold mb-2">Your care team</div>
    <div className="space-y-2 max-h-[420px] overflow-y-auto mb-2">{msgs.length ? msgs.map(m => <div key={m.id} className={`rounded-[3px] px-3 py-2 text-[14.5px] max-w-[85%] ${m.from === 'office' ? 'bg-white border border-[#dfe5e1]' : 'ml-auto bg-[#e3f2e9]'}`} data-testid="portal-msg-item"><div className="text-[12.5px] text-[#5f6862]">{m.author} · {fmtDateTime(m.at)}</div>{m.text}<AttChips msgId={m.id} /></div>) : <p className="text-[14px] text-[#5f6862]">No messages.</p>}</div>
    <div className="flex gap-2 items-center"><input className="vy-input flex-1" placeholder="Write a message (not for emergencies)" value={t} onChange={e => setT(e.target.value)} data-testid="portal-msg" /><AttachButton pend={pend} testId="portal-attach" className="vy-btn" /><button type="button" className="vy-btn vy-btn-primary" onClick={send} data-testid="portal-send">Send</button></div>
    <PendingChips pend={pend} />{err && <p className="text-[13px] mt-1" style={{ color: '#b91c1c' }} role="alert" data-testid="portal-attach-error">{err}</p>}
    <p className="text-[12.5px] text-[#5f6862] mt-1.5">You can attach PDFs, photos (JPG, PNG, HEIC) and Word documents. Photos are made smaller before sending. Other files up to 3 MB.</p></div>;
};
