/* v0.12 · Image capture helpers shared by the patient photo, ID and insurance cards.
 * - compressImage: decode (EXIF-aware), downscale to ≤512px on the long side, JPEG ~0.8, step down until ≤160 KB.
 * - imgStore: images live in IndexedDB (large quota), with a synchronous in-memory cache for rendering. The v0.11 photo
 *   was kept inside the patients list in localStorage, which shares a ~5 MB quota with every Vityls test build opened
 *   from file:// on the same computer; when that was full the save threw and the user saw "That file is not an image."
 *   Falls back to localStorage only when IndexedDB is unavailable, with a clear "storage full" message.
 * Backend swap point: POST /patients/:id/images (blob storage). */
import { isMedical } from '../../edition';
import { svRead, svWrite } from '../store';
import { ping } from '../../med/record';

export class ImageError extends Error {}
const isImageName = (n: string) => /\.(jpe?g|png|gif|webp|bmp)$/i.test(n);
async function decode(file: Blob): Promise<{ src: CanvasImageSource; w: number; h: number; close?: () => void }> {
  try { if (typeof createImageBitmap === 'function') { const b = await createImageBitmap(file, { imageOrientation: 'from-image' } as ImageBitmapOptions); return { src: b, w: b.width, h: b.height, close: () => b.close() }; } } catch { /* fall back to <img> */ }
  const url = URL.createObjectURL(file);
  try { const img = await new Promise<HTMLImageElement>((res, rej) => { const i = new Image(); i.onload = () => res(i); i.onerror = () => rej(new Error('decode')); i.src = url; }); return { src: img, w: img.naturalWidth, h: img.naturalHeight, close: () => URL.revokeObjectURL(url) }; }
  catch { URL.revokeObjectURL(url); throw new ImageError('This file could not be read as a picture. Use a JPG or PNG photo.'); }
}
export async function compressImage(file: Blob & { name?: string }, max = 512): Promise<string> {
  const name = file.name || ''; const type = file.type || '';
  if (/hei[cf]/i.test(type) || /\.hei[cf]$/i.test(name)) throw new ImageError('HEIC photos from an iPhone can’t be read by this browser. Use a JPG or PNG (iPhone: Settings › Camera › Formats › Most Compatible).');
  if (type && !/^image\//.test(type)) throw new ImageError('That file is not an image. Use a JPG or PNG photo.');
  if (!type && name && !isImageName(name)) throw new ImageError('That file is not an image. Use a JPG or PNG photo.');
  if (file.size > 40 * 1024 * 1024) throw new ImageError('That photo is larger than 40 MB. Use a smaller photo.');
  const d = await decode(file);
  try {
    let side = max; let out = '';
    for (let tries = 0; tries < 6; tries++) {
      const sc = Math.min(1, side / Math.max(d.w, d.h)); const c = document.createElement('canvas'); c.width = Math.max(1, Math.round(d.w * sc)); c.height = Math.max(1, Math.round(d.h * sc));
      const g = c.getContext('2d')!; g.fillStyle = '#fff'; g.fillRect(0, 0, c.width, c.height); g.drawImage(d.src, 0, 0, c.width, c.height);
      out = c.toDataURL('image/jpeg', tries < 2 ? 0.8 - tries * 0.1 : 0.6);
      if (out.length <= 160 * 1024 * 1.37) break; side = Math.round(side * 0.8);
    }
    return out;
  } finally { d.close?.(); }
}
/** Snapshot a <video> frame (live camera) with the same compression. */
export function compressVideoFrame(v: HTMLVideoElement, max = 512): string {
  const sc = Math.min(1, max / Math.max(v.videoWidth, v.videoHeight)); const c = document.createElement('canvas'); c.width = Math.round(v.videoWidth * sc); c.height = Math.round(v.videoHeight * sc);
  c.getContext('2d')!.drawImage(v, 0, 0, c.width, c.height); return c.toDataURL('image/jpeg', 0.8);
}

/* ---------------- storage ---------------- */
const DB = isMedical ? 'vityls-medical-images' : 'vityls-surgery-images'; const OS = 'img';
const cache = new Map<string, string>(); let db: IDBDatabase | null = null; let ready = false; let idbOk = true;
const gen = (): string => { let g = svRead<string>('img-gen', ''); if (!g) { g = `g${Date.now().toString(36)}`; try { svWrite('img-gen', g); } catch { /* */ } } return g; };
const open = () => new Promise<IDBDatabase>((res, rej) => { try { const r = indexedDB.open(DB, 1); r.onupgradeneeded = () => r.result.createObjectStore(OS); r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error); } catch (e) { rej(e); } });
const tx = (mode: IDBTransactionMode) => db!.transaction(OS, mode).objectStore(OS);
const req = <T,>(r: IDBRequest<T>) => new Promise<T>((res, rej) => { r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error); });
/** Load every stored image into the cache once (called at app start). Stale generations (after ?reset-test-data) are purged. */
export async function initImages(): Promise<void> {
  if (ready) return; const g = gen();
  try { db = await open(); const keys = await req(tx('readonly').getAllKeys()) as string[];
    for (const k of keys) { if (!k.startsWith(g + '|')) { tx('readwrite').delete(k); continue; } const v = await req(tx('readonly').get(k)) as string; if (typeof v === 'string') cache.set(k.slice(g.length + 1), v); } }
  catch { idbOk = false; }
  ready = true; ping();
}
export const imagesReady = () => ready;
export const imgGet = (key: string): string => cache.get(key) || (!idbOk ? svRead<Record<string, string>>('img-fallback', {})[key] || '' : '');
export async function imgPut(key: string, data: string): Promise<void> {
  if (!ready) await initImages();
  if (idbOk && db) { try { await req(tx('readwrite').put(data, `${gen()}|${key}`)); cache.set(key, data); ping(); return; } catch (e) { if ((e as DOMException)?.name === 'QuotaExceededError') throw new ImageError('This computer’s browser storage is full. Remove old test photos or reset test data (?reset-test-data).'); idbOk = false; } }
  try { svWrite('img-fallback', { ...svRead<Record<string, string>>('img-fallback', {}), [key]: data }); cache.set(key, data); ping(); }
  catch { throw new ImageError('This browser’s test storage is full (other Vityls test builds opened from this computer share it). Remove old test photos or reset test data (?reset-test-data).'); }
}
export async function imgDel(key: string): Promise<void> {
  cache.delete(key); try { if (idbOk && db) await req(tx('readwrite').delete(`${gen()}|${key}`)); } catch { /* */ }
  const f = svRead<Record<string, string>>('img-fallback', {}); if (f[key]) { delete f[key]; try { svWrite('img-fallback', f); } catch { /* */ } } ping();
}
