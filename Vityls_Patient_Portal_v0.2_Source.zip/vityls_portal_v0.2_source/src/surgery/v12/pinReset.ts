/* v0.12 · Self-service Forgot PIN (Surgery only). SIMULATED email (local outbox; nothing is sent).
 * Flow: "Forgot PIN?" on any PIN prompt → choose your name → a one-time link (expires in 30 min) is emailed to you →
 * open it, sign in with your username + password → create a new PIN (twice; same PIN rules as invitations; not the same
 * as your current PIN). The OLD PIN KEEPS WORKING UNTIL THE RESET IS COMPLETED (so a stray or malicious request can't
 * lock anyone out); completing the reset replaces it, clears wrong-PIN counts and unlocks. A new request revokes earlier
 * links. Practice administrators/managers get a heads-up email for every request and completion.
 * Admin "Reset PIN" on a staff row sends the same link: admins never see or type anyone's PIN.
 * Rate limit: ≥60 s between requests and ≤3 requests per person per hour. Everything audited (pin.reset.*).
 * Test build: seeded fictional people have no real account yet, so they sign in with the test username shown in the
 * email (first.last) and the test password `vityls-test-2026`. Henry: POST /api/pin-reset, GET/POST /api/pin-reset/:token. */
import { repo } from '../../v6/dataLayer';
import { getProviders, saveProviders, displayName, hashPin } from '../../v7/providers';
import { accountFor, verifyLogin, pinProblems } from '../../v7/invitations';
import { PROVIDER_ROLES } from '../../med/record';
import { getSettings } from '../../med/settings';
import { staffList, saveStaff, ROLE_GROUP } from '../staff';
import { svRead, svWrite } from '../store';
export const TEST_PASSWORD = 'vityls-test-2026';
export const RESET_MINUTES = 30;
export interface Person { kind: 'staff' | 'provider'; id: string; name: string; role: string; email: string; username: string; seeded: boolean; locked: boolean }
export interface OutMail { id: string; to: string; toName: string; subject: string; body: string; at: string; kind: 'pin-reset' | 'pin-reset-admin'; link?: string; transport: 'simulated-outbox' }
export interface ResetReq { token: string; personKey: string; name: string; at: string; expiresAt: string; by: string; via: 'self' | 'admin'; usedAt?: string; revokedAt?: string }
const testUser = (name: string) => name.toLowerCase().replace(/,.*$/, '').replace(/[^a-z0-9]+/g, '.').replace(/^\.|\.$/g, '');
export function findPerson(name: string): Person | undefined {
  const s = staffList().find(x => x.name === name && x.active);
  if (s) { const u = s.username || testUser(s.name); return { kind: 'staff', id: s.id, name: s.name, role: s.role, email: s.email || `${u}@example.test`, username: u, seeded: !s.pwHash, locked: !!s.locked }; }
  const p = getProviders().find(x => displayName(x) === name && x.active && PROVIDER_ROLES.includes(x.role as string));
  if (p) { const a = accountFor(p.id); const u = a?.username || testUser(displayName(p)); return { kind: 'provider', id: p.id, name: displayName(p), role: p.role as string, email: p.email || `${u}@example.test`, username: u, seeded: !a, locked: !!p.locked }; }
  return undefined;
}
const key = (p: Person) => `${p.kind}:${p.id}`;
export const outbox = () => svRead<OutMail[]>('pin-outbox', []);
const mail = (m: Omit<OutMail, 'id' | 'at' | 'transport'>) => { const o: OutMail = { ...m, id: `m${Date.now().toString(36)}${Math.random().toString(36).slice(2, 5)}`, at: new Date().toISOString(), transport: 'simulated-outbox' }; svWrite('pin-outbox', [...outbox(), o]); return o; };
export const resets = () => svRead<ResetReq[]>('pin-resets', []);
const putResets = (l: ResetReq[]) => svWrite('pin-resets', l);
const tok = () => { const a = new Uint8Array(16); crypto.getRandomValues(a); return Array.from(a, b => b.toString(16).padStart(2, '0')).join(''); };
export const resetLink = (t: string) => `${location.href.split('#')[0].split('?')[0]}#pin-reset=${t}`;
export const parsePinResetHash = (h = location.hash) => { const m = h.match(/^#pin-reset=([a-f0-9]{32})$/i); return m ? m[1] : null; };
const aud = (user: string, role: string, action: string, detail: string) => repo.audit({ caseId: 'practice', user, role, action: action as any, detail });
const admins = () => staffList().filter(s => s.active && ROLE_GROUP.admin.includes(s.role));
function notifyAdmins(subject: string, line: string) { const pr = getSettings().practiceName; admins().forEach(a => { const u = a.username || testUser(a.name); mail({ kind: 'pin-reset-admin', to: a.email || `${u}@example.test`, toName: a.name, subject, body: `Hello ${a.name},\n\n${line}\n\nNo action is needed if this was expected. You never see or set anyone’s PIN. If you don’t recognise this, review Practice › Staff and the audit trail.\n\n${pr} · Surgery.Vityls (simulated email)` }); }); }
/** Request a reset email. Throws a friendly message when rate-limited. Returns the email that "was sent". */
export function requestPinReset(name: string, by: string, byRole: string, via: 'self' | 'admin' = 'self'): OutMail {
  const p = findPerson(name); if (!p) throw new Error('Choose your name from the list.');
  const now = Date.now(); const mine = resets().filter(r => r.personKey === key(p));
  const last = mine[mine.length - 1]; if (last && now - Date.parse(last.at) < 60e3) { aud(by, byRole, 'pin.reset.limited', `PIN reset request for ${p.name} refused: less than 60 s since the last one`); throw new Error('A reset email was just sent. Wait a minute before asking again.'); }
  if (mine.filter(r => now - Date.parse(r.at) < 3600e3).length >= 3) { aud(by, byRole, 'pin.reset.limited', `PIN reset request for ${p.name} refused: 3 requests in the last hour`); throw new Error('Too many reset requests for this person in the last hour. Try again later or ask a practice administrator.'); }
  const at = new Date(now).toISOString(); const expiresAt = new Date(now + RESET_MINUTES * 60e3).toISOString(); const token = tok(); const link = resetLink(token);
  putResets([...resets().map(r => r.personKey === key(p) && !r.usedAt && !r.revokedAt ? { ...r, revokedAt: at } : r), { token, personKey: key(p), name: p.name, at, expiresAt, by, via }]);
  const pr = getSettings().practiceName;
  const m = mail({ kind: 'pin-reset', to: p.email, toName: p.name, link, subject: `${pr} — reset your Surgery.Vityls signing PIN`,
    body: `Hello ${p.name},\n\n${via === 'admin' ? `${by} (${byRole}) started a PIN reset for you.` : 'Someone asked to reset your signing PIN on an office tablet.'} Use this one-time link to sign in with your username and password and create a new PIN. It works once and expires in ${RESET_MINUTES} minutes (${new Date(expiresAt).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' })}).\n${link}\n\nYour current PIN keeps working until you finish. If you didn’t ask for this, ignore this email.\n${p.seeded ? `\nTest build: this fictional account signs in with username ${p.username} and password ${TEST_PASSWORD}.\n` : ''}\n${pr} · Surgery.Vityls (simulated email; nothing was sent)` });
  aud(by, byRole, 'pin.reset.request', `PIN reset link emailed to ${p.name} (${p.role}) <${p.email}> · ${via === 'admin' ? 'started by an administrator' : 'self-service “Forgot PIN?”'} · expires in ${RESET_MINUTES} min · earlier links revoked · SIMULATED outbox`);
  notifyAdmins(`PIN reset requested for ${p.name}`, `A PIN reset link was emailed to ${p.name} (${p.role}) at ${new Date(at).toLocaleString()}${via === 'admin' ? ` by ${by}` : ' from an office tablet (Forgot PIN?)'}.`);
  return m;
}
export type ResetCheck = { state: 'ok' | 'used' | 'revoked' | 'expired' | 'invalid'; r?: ResetReq; p?: Person };
export function resolveReset(token: string): ResetCheck { const r = resets().find(x => x.token === token); if (!r) return { state: 'invalid' }; const p = findPerson(r.name);
  if (!p) return { state: 'invalid' }; return { state: r.revokedAt ? 'revoked' : r.usedAt ? 'used' : Date.parse(r.expiresAt) < Date.now() ? 'expired' : 'ok', r, p }; }
export function checkLogin(token: string, username: string, password: string) {
  const c = resolveReset(token); if (c.state !== 'ok' || !c.p) throw new Error('This link is not valid any more. Ask for a new one.');
  const p = c.p; let ok = false;
  if (p.kind === 'staff') { const s = staffList().find(x => x.id === p.id)!; ok = s.pwHash ? (s.username || '').toLowerCase() === username.toLowerCase() && s.pwHash === hashPin(`pw|${username.toLowerCase()}|${password}`) : username.toLowerCase() === p.username && password === TEST_PASSWORD; }
  else ok = p.seeded ? username.toLowerCase() === p.username && password === TEST_PASSWORD : verifyLogin(p.id, username, password);
  aud(p.name, p.role, ok ? 'pin.reset.signin' : 'pin.reset.signin.fail', ok ? 'Signed in on the PIN reset page' : 'Wrong username or password on the PIN reset page');
  if (!ok) throw new Error('That username and password don’t match.');
}
export function completeReset(token: string, username: string, password: string, pin: string, pin2: string) {
  checkLogin(token, username, password); const c = resolveReset(token); const p = c.p!;
  if (pin !== pin2) throw new Error('The two PINs don’t match.');
  const h = hashPin(pin); const now = new Date().toISOString();
  const cur = p.kind === 'staff' ? staffList().find(x => x.id === p.id)?.pinHash : getProviders().find(x => x.id === p.id)?.pinHash;
  if (cur === h) throw new Error('Choose a PIN different from your current one.');
  const pe = pinProblems(pin); if (pe.length) throw new Error(pe.join('; '));
  if (p.kind === 'staff') { const l = staffList(); if (l.find(x => x.id === p.id)?.pinHash === h) throw new Error('Choose a PIN different from your current one.'); saveStaff(l.map(x => x.id === p.id ? { ...x, pinHash: h, fails: 0, locked: false } : x)); }
  else { const l = getProviders(); if (l.find(x => x.id === p.id)?.pinHash === h) throw new Error('Choose a PIN different from your current one.'); saveProviders(l.map(x => x.id === p.id ? { ...x, pinHash: h, pinFailures: 0, locked: false, lockedAt: undefined } : x)); }
  putResets(resets().map(r => r.token === token ? { ...r, usedAt: now } : r));
  aud(p.name, p.role, 'pin.reset.complete', 'New signing PIN created from the reset link; the old PIN no longer works; wrong-PIN count cleared');
  notifyAdmins(`PIN reset completed by ${p.name}`, `${p.name} (${p.role}) created a new signing PIN at ${new Date(now).toLocaleString()}. Their old PIN no longer works.`);
}
export function unlockPerson(name: string, by: string, byRole: string) { const p = findPerson(name); if (!p) return;
  if (p.kind === 'staff') saveStaff(staffList().map(x => x.id === p.id ? { ...x, fails: 0, locked: false } : x)); else saveProviders(getProviders().map(x => x.id === p.id ? { ...x, pinFailures: 0, locked: false, lockedAt: undefined } : x));
  aud(by, byRole, 'pin.unlock', `Unlocked ${p.name} (${p.role}); the PIN itself was not changed`); }
