/*
 * Surgery.Vityls v0.3: collect a payment from any patient at any time (phone call before a visit, at the desk, after
 * surgery), with or without an open invoice. The money posts to the patient's account as unapplied credit; staff can
 * apply that credit to an invoice later (or it stays on account). Card entry is SIMULATED: nothing is charged, the full
 * card number is never stored (brand + last 4 only). Henry: swap takeCard() for the processor's hosted fields / terminal
 * (Stripe Terminal, Square, Authorize.net…) so card data never touches Vityls; post /api/patients/:id/payments.
 */
import React, { useState } from 'react';
import { repo } from '../v6/dataLayer';
import { getInvoices, recordPayment, Invoice } from '../v7/billing';
import { medRepo, patientKey, uid, fmtDateTime, MedPatient } from '../med/record';
import { useActor, useMedTick } from '../med/ui';
import { svRead, svWrite } from './store';
import { ROLE_GROUP } from './staff';
import { useSv } from './ui';
import { Ico } from './icons';
import { PinSign, Signer } from './sign';

export type PayMethod = 'card' | 'cash' | 'check' | 'financing' | 'other';
export const METHOD_LABEL: Record<PayMethod, string> = { card: 'Credit / debit card', cash: 'Cash', check: 'Check', financing: 'Patient financing', other: 'Other' };
export interface Application { invoiceId: string; invoiceNumber: string; amount: number; at: string; by: string }
export interface PatientPayment { id: string; receipt: string; patientId: string; amount: number; method: PayMethod; card?: { brand: string; last4: string; exp: string }; reference: string; reason: string; takenBy: string; role: string; at: string; channel: 'in person' | 'phone' | 'portal link'; applied: Application[]; status: 'posted (simulated)' }

export const patientPayments = (pid?: string) => { const l = svRead<PatientPayment[]>('patient-payments', []); return pid ? l.filter(x => x.patientId === pid) : l; };
const put = (l: PatientPayment[]) => svWrite('patient-payments', l);
const r2 = (n: number) => Math.round(n * 100) / 100;
export const unapplied = (x: PatientPayment) => r2(x.amount - x.applied.reduce((s, a) => s + a.amount, 0));
/** Invoices for this patient (all visits). */
export const patientInvoices = (pid: string) => getInvoices().filter(i => i.patientId === pid);
/** Account summary: charges invoiced, paid on invoices, unapplied credit, balance due. */
export function accountFor(pid: string) {
  const inv = patientInvoices(pid); const billed = r2(inv.reduce((s, i) => s + i.total, 0)); const paid = r2(inv.reduce((s, i) => s + i.paid, 0));
  const due = r2(Math.max(0, billed - paid)); const credit = r2(patientPayments(pid).reduce((s, x) => s + unapplied(x), 0));
  return { billed, paid, due, credit, net: r2(due - credit), label: credit > 0 && due > 0 ? `$${due.toFixed(2)} due · $${credit.toFixed(2)} credit` : credit > 0 ? `$${credit.toFixed(2)} credit on account` : due > 0 ? `$${due.toFixed(2)} due` : 'No balance' };
}

const luhn = (n: string) => { let s = 0, d = false; for (let i = n.length - 1; i >= 0; i--) { let x = +n[i]; if (d) { x *= 2; if (x > 9) x -= 9; } s += x; d = !d; } return s % 10 === 0; };
const brandOf = (n: string) => /^4/.test(n) ? 'Visa' : /^(5[1-5]|2[2-7])/.test(n) ? 'Mastercard' : /^3[47]/.test(n) ? 'Amex' : /^6/.test(n) ? 'Discover' : 'Card';
/** SIMULATED card authorization. Production: a processor token from hosted fields; Vityls never sees the number. */
export function takeCard(num: string, exp: string, cvc: string, zip: string) {
  const n = num.replace(/\D/g, ''); if (n.length < 13 || n.length > 19 || !luhn(n)) throw new Error('That card number isn’t valid. Test card: 4242 4242 4242 4242.');
  const m = exp.match(/^(\d{2})\s*\/\s*(\d{2})$/); if (!m || +m[1] < 1 || +m[1] > 12) throw new Error('Expiry as MM/YY.');
  const end = new Date(2000 + +m[2], +m[1], 1); if (end.getTime() < Date.now()) throw new Error('That card has expired.');
  if (!/^\d{3,4}$/.test(cvc)) throw new Error('Security code: 3 or 4 digits.'); if (!/^\d{5}$/.test(zip)) throw new Error('Billing ZIP: 5 digits.');
  if (n.endsWith('0002')) throw new Error('Declined by the (simulated) processor. Try another card.');
  return { brand: brandOf(n), last4: n.slice(-4), exp: `${m[1]}/${m[2]}` };
}
export function collectPayment(x: Omit<PatientPayment, 'id' | 'receipt' | 'applied' | 'status' | 'at'>): PatientPayment {
  if (!(x.amount > 0) || x.amount > 100000) throw new Error('Enter an amount.');
  const rec: PatientPayment = { ...x, amount: r2(x.amount), id: uid('pay'), receipt: `RCPT-${new Date().getFullYear()}-${String(patientPayments().length + 1).padStart(4, '0')}`, applied: [], status: 'posted (simulated)', at: new Date().toISOString() };
  put([...patientPayments(), rec]);
  repo.audit({ caseId: patientKey(x.patientId), user: x.takenBy, role: x.role, action: 'payment.collect', detail: `Payment ${rec.receipt} $${rec.amount.toFixed(2)} · ${METHOD_LABEL[x.method]}${x.card ? ` ${x.card.brand} ••${x.card.last4}` : ''}${x.reference ? ` · ref ${x.reference}` : ''} · ${x.channel} · posted as credit on account · SIMULATED, nothing charged${x.reason ? ` · “${x.reason}”` : ''}` });
  return rec;
}
/** Apply unapplied credit (oldest first) to an invoice. */
export function applyCredit(pid: string, inv: Invoice, amount: number, by: string, role: string) {
  const open = r2(inv.total - inv.paid); let left = r2(Math.min(amount, open, accountFor(pid).credit)); if (left <= 0) throw new Error('Nothing to apply.');
  const total = left; const at = new Date().toISOString();
  put(patientPayments().map(p => { if (p.patientId !== pid || left <= 0) return p; const u = unapplied(p); if (u <= 0) return p; const take = r2(Math.min(u, left)); left = r2(left - take); return { ...p, applied: [...p.applied, { invoiceId: inv.id, invoiceNumber: inv.number, amount: take, at, by }] }; }));
  recordPayment(inv.id, total, by);
  repo.audit({ caseId: patientKey(pid), user: by, role, action: 'credit.apply', detail: `$${total.toFixed(2)} of credit on account applied to ${inv.number}` });
  return total;
}

/** The front-desk dialog. Opens from Patients, the chart header, Today and the Billing panel. */
export const CollectPayment: React.FC<{ p: MedPatient; onClose: () => void; invoice?: Invoice }> = ({ p, onClose }) => {
  const [actor] = useActor(); const { toast } = useSv(); const can = true; /* v0.4: anyone on the tablet takes a payment; the collector confirms with their own PIN */ const [signPay, setSignPay] = useState(false);
  const acc = accountFor(p.id);
  const [amt, setAmt] = useState(acc.due > 0 ? acc.net > 0 ? acc.net.toFixed(2) : '' : ''); const [method, setMethod] = useState<PayMethod>('card'); const [channel, setChannel] = useState<PatientPayment['channel']>('phone');
  const [num, setNum] = useState(''); const [exp, setExp] = useState(''); const [cvc, setCvc] = useState(''); const [zip, setZip] = useState(''); const [ref, setRef] = useState(''); const [reason, setReason] = useState('Deposit / payment on account');
  const [err, setErr] = useState(''); const [done, setDone] = useState<PatientPayment | null>(null);
  const go = (w: Signer) => { setErr(''); setSignPay(false); try { const card = method === 'card' ? takeCard(num, exp, cvc, zip) : undefined; if (method !== 'card' && method !== 'cash' && !ref.trim()) throw new Error('Enter a check number or reference.'); const rec = collectPayment({ patientId: p.id, amount: +amt, method, card, reference: ref.trim(), reason: reason.trim(), takenBy: w.name, role: w.role, channel }); setDone(rec); setNum(''); setCvc(''); toast(`$${rec.amount.toFixed(2)} posted to ${p.name}’s account as credit (simulated).`); } catch (e) { setErr((e as Error).message); } };
  return <div className="sv-modal" role="dialog" aria-modal="true" aria-label="Collect payment" data-testid="collect-payment" onKeyDown={e => { if (e.key === 'Escape') onClose(); }}>
    <div className="sv-modal-scrim" onClick={onClose} />
    {signPay && <PinSign title="Confirm payment" statement={<>I am collecting <b>${(+amt || 0).toFixed(2)}</b> ({method}) from {p.name}. It posts as credit on the patient’s account.</>} roles={ROLE_GROUP.everyone} confirmLabel="Confirm" onClose={() => setSignPay(false)} onSigned={go} />}
    <div className="sv-modal-box" style={{ width: 'min(520px, 94vw)' }}>
      <div className="flex items-center gap-2 mb-1"><Ico k="invoice" size={16} /><b className="text-[15px]">Collect payment · {p.name}</b></div>
      <p className="sv-small sv-muted mb-2">Any time, with or without an invoice. Posts to the patient’s account as credit; apply it to an invoice now or later. <b>Simulated: no card is charged.</b></p>
      <div className="sv-acct mb-2" data-testid="pay-account"><span>Invoiced <b>${acc.billed.toFixed(2)}</b></span><span>Paid <b>${acc.paid.toFixed(2)}</b></span><span>Due <b className={acc.due > 0 ? 'sv-warn' : ''}>${acc.due.toFixed(2)}</b></span><span>Credit <b className={acc.credit > 0 ? 'sv-ok' : ''}>${acc.credit.toFixed(2)}</b></span></div>
      {!can ? <p className="sv-banner">Front desk, surgical coordinators, nurses and managers collect payments. Switch the Session.</p> : done ? <div data-testid="pay-receipt">
        <p className="text-[14px]"><span className="sv-ok font-semibold">✓ Posted</span> · receipt <b>{done.receipt}</b> · ${done.amount.toFixed(2)} · {METHOD_LABEL[done.method]}{done.card ? ` ${done.card.brand} ••${done.card.last4}` : ''} · {fmtDateTime(done.at)} · {done.takenBy}</p>
        <p className="sv-small sv-muted mt-1">Now ${accountFor(p.id).credit.toFixed(2)} credit on account. Apply it to an invoice from Billing (chart › Records › Billing).</p>
        <div className="flex justify-end gap-2 mt-3"><button type="button" className="sv-btn" onClick={() => setDone(null)}>Take another</button><button type="button" className="sv-btn primary" onClick={onClose} data-testid="pay-close">Done</button></div>
      </div> : <>
        <div className="grid grid-cols-2 gap-2">
          <label><span className="sv-label">Amount ($)</span><input className="sv-input" inputMode="decimal" value={amt} onChange={e => setAmt(e.target.value.replace(/[^\d.]/g, ''))} placeholder="0.00" data-testid="pay-amount" autoFocus /></label>
          <label><span className="sv-label">How the patient is paying</span><select className="sv-input" value={channel} onChange={e => setChannel(e.target.value as any)} data-testid="pay-channel"><option value="phone">By phone</option><option value="in person">In person</option><option value="portal link">Portal payment link</option></select></label>
          <label className="col-span-2"><span className="sv-label">Method</span><select className="sv-input" value={method} onChange={e => setMethod(e.target.value as PayMethod)} data-testid="pay-method">{(Object.keys(METHOD_LABEL) as PayMethod[]).map(m => <option key={m} value={m}>{METHOD_LABEL[m]}</option>)}</select></label>
          {method === 'card' ? <>
            <label className="col-span-2"><span className="sv-label">Card number (simulated · test 4242 4242 4242 4242)</span><input className="sv-input" inputMode="numeric" autoComplete="off" value={num} onChange={e => setNum(e.target.value.replace(/[^\d ]/g, '').slice(0, 23))} placeholder="•••• •••• •••• ••••" data-testid="pay-card" /></label>
            <label><span className="sv-label">Expiry (MM/YY)</span><input className="sv-input" value={exp} onChange={e => setExp(e.target.value.slice(0, 5))} placeholder="12/29" data-testid="pay-exp" /></label>
            <div className="grid grid-cols-2 gap-2"><label><span className="sv-label">CVC</span><input className="sv-input" inputMode="numeric" autoComplete="off" value={cvc} onChange={e => setCvc(e.target.value.replace(/\D/g, '').slice(0, 4))} data-testid="pay-cvc" /></label><label><span className="sv-label">ZIP</span><input className="sv-input" inputMode="numeric" value={zip} onChange={e => setZip(e.target.value.replace(/\D/g, '').slice(0, 5))} data-testid="pay-zip" /></label></div>
          </> : method !== 'cash' && <label className="col-span-2"><span className="sv-label">{method === 'check' ? 'Check number' : 'Reference'}</span><input className="sv-input" value={ref} onChange={e => setRef(e.target.value)} data-testid="pay-ref" /></label>}
          <label className="col-span-2"><span className="sv-label">For (shows on the receipt)</span><input className="sv-input" value={reason} onChange={e => setReason(e.target.value)} data-testid="pay-reason" /></label>
        </div>
        {err && <p className="text-[12.5px] text-[var(--crit)] mt-2" role="alert" data-testid="pay-error">{err}</p>}
        <p className="text-[11.5px] sv-muted mt-2">Only the card brand and last 4 digits are kept. Taken by {actor.name} ({actor.role}); audited.</p>
        <div className="flex justify-end gap-2 mt-3"><button type="button" className="sv-btn" onClick={onClose}>Cancel</button><button type="button" className="sv-btn primary" onClick={() => { setErr(''); if (method !== 'card' && method !== 'cash' && !ref.trim()) { setErr('Enter a check number or reference.'); return; } setSignPay(true); }} disabled={!(+amt > 0)} data-testid="pay-submit">{method === 'card' ? 'Charge card (simulated)' : 'Record payment'} {+amt > 0 ? `$${(+amt).toFixed(2)}` : ''}</button></div>
      </>}
    </div>
  </div>;
};

/** Patient account (top of the chart's Billing panel): credit on account, payments, and apply-credit per invoice. */
export const PatientAccount: React.FC<{ p: MedPatient }> = ({ p }) => {
  useMedTick(); const [actor] = useActor(); const { toast } = useSv(); const [open, setOpen] = useState(false);
  const acc = accountFor(p.id); const pays = patientPayments(p.id).slice().reverse(); const invs = patientInvoices(p.id); const can = true; /* v0.4: open to the whole care team */
  return <section className="mb-4" data-testid="patient-account">
    <div className="flex items-center justify-between gap-2 flex-wrap"><div className="sv-h">Patient account</div>{can && <button type="button" className="sv-btn sm primary" onClick={() => setOpen(true)} data-testid="account-collect">Collect payment</button>}</div>
    <div className="sv-acct" data-testid="account-summary"><span>Invoiced <b>${acc.billed.toFixed(2)}</b></span><span>Paid on invoices <b>${acc.paid.toFixed(2)}</b></span><span>Due <b className={acc.due > 0 ? 'sv-warn' : ''}>${acc.due.toFixed(2)}</b></span><span>Credit on account <b className={acc.credit > 0 ? 'sv-ok' : ''} data-testid="account-credit">${acc.credit.toFixed(2)}</b></span></div>
    {invs.some(i => i.total - i.paid > 0) && acc.credit > 0 && can && <div className="mt-2" data-testid="apply-credit"><div className="sv-small sv-muted mb-1">Apply credit on account to an open invoice:</div>{invs.filter(i => i.total - i.paid > 0).map(i => <div key={i.id} className="flex items-center gap-2 text-[13px] py-0.5"><Ico k="invoice" /><b>{i.number}</b><span>{i.dos} · ${(i.total - i.paid).toFixed(2)} open</span><button type="button" className="sv-btn sm ml-auto" onClick={() => { try { const n = applyCredit(p.id, i, i.total - i.paid, actor.name, actor.role); toast(`$${n.toFixed(2)} of credit applied to ${i.number}.`); } catch (e) { toast((e as Error).message); } }} data-testid="apply-credit-btn">Apply ${Math.min(acc.credit, i.total - i.paid).toFixed(2)}</button></div>)}</div>}
    <table className="sv-table text-[13px] mt-2" data-testid="payments-table"><thead><tr><th>Date</th><th>Receipt</th><th>Method</th><th className="text-right">Amount</th><th className="text-right">Unapplied</th></tr></thead><tbody>
      {pays.map(x => <tr key={x.id}><td>{fmtDateTime(x.at)}<div className="sv-muted sv-small">{x.takenBy} · {x.channel}</div></td><td>{x.receipt}{x.reason && <div className="sv-muted sv-small">{x.reason}</div>}</td><td>{METHOD_LABEL[x.method]}{x.card ? ` ${x.card.brand} ••${x.card.last4}` : x.reference ? ` · ${x.reference}` : ''}</td><td className="text-right">${x.amount.toFixed(2)}</td><td className="text-right">${unapplied(x).toFixed(2)}{x.applied.length > 0 && <div className="sv-muted sv-small">applied to {x.applied.map(a => a.invoiceNumber).join(', ')}</div>}</td></tr>)}
      {!pays.length && <tr><td colSpan={5} className="sv-muted">No payments on account yet.</td></tr>}
    </tbody></table>
    {open && <CollectPayment p={p} onClose={() => setOpen(false)} />}
  </section>;
};
/** A one-line account badge for chart headers / lists. */
export const AccountBadge: React.FC<{ pid: string }> = ({ pid }) => { useMedTick(); const a = accountFor(pid); return <span className={`sv-small ${a.due > a.credit ? 'sv-warn' : a.credit > 0 ? 'sv-ok' : 'sv-muted'}`} data-testid="account-badge">{a.label}</span>; };
export const patientName = (pid: string) => medRepo.patient(pid)?.name || pid;
