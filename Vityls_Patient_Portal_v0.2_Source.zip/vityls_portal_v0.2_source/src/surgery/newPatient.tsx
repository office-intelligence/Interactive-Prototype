/*
 * Surgery.Vityls v0.4 · + Add New Patient (the ASC.Vityls routine) and the new-patient forms prompt.
 *  1. "+ Add New Patient" on Today, Patients and the chart header opens the same Add New Patient dialog ASC.Vityls uses
 *     (first/last name, DOB, gender, mobile phone, optional email; MRN assigned automatically).
 *  2. Create Patient Chart makes the Surgery chart (no visit yet) and audits `patient.create`.
 *  3. Then a prompt offers to send Patient Registration, Admission Form and Medical History by text and/or email and
 *     to post them to the patient portal. Sending is SIMULATED: nothing leaves the device; the packet, the message
 *     text and the link are kept in an outbox and audited (`forms.packet.send`). The portal shows the posted forms.
 * Henry: POST /patients, then POST /patients/{id}/form-packets {forms, channels, portal}; SMS/email via a BAA vendor.
 * v0.5: the dialog is Surgery's own copy of the ASC fields (ASC's shared AddPatientModal is untouched) plus Payment type
 *       and Referral source (configurable lists, see profile.tsx). `onCreated` lets the scheduler book the new patient
 *       straight into the slot instead of opening the chart.
 */
import React, { useState } from 'react';
import { UserPlus, Send, X } from 'lucide-react';
import { repo } from '../v6/dataLayer';
import { PatientCase } from '../types';
import { SvAddPatientDialog, NewPatientInput, SvPatient, isInsurance } from './profile';
import { FormPage } from '../v6/FormPage';
import { VITYLS_FORM_CATALOG } from '../data/formWorkspaceCatalog';
import { medRepo, MedPatient, patientKey, uid, fmtDateTime, PROVIDER_ROLES } from '../med/record';
import { getSettings } from '../med/settings';
import { useActor, useMedTick } from '../med/ui';
import { getProviders, displayName } from '../v7/providers';
import { svRead, svWrite } from './store';
import { useSv } from './ui';
import { stationPlan } from '../v7/myForms';
import { HIPAA_FILE } from './v13/hipaa';

export const NEW_PATIENT_FORMS = ['Patient_Registration.html', 'Admission_Form.html', 'Medical_History.html'];
export const formTitle = (f: string) => VITYLS_FORM_CATALOG.find(x => x.file === f)?.title || f.replace(/\.html$/, '').replace(/_/g, ' ');
export interface FormsPacket { id: string; patientId: string; forms: string[]; text?: string; email?: string; portal: boolean; message: string; link: string; sentAt: string; by: string; role: string; transport: 'simulated-outbox' }
export const formsPackets = (pid?: string) => { const l = svRead<FormsPacket[]>('forms-packets', []); return pid ? l.filter(x => x.patientId === pid) : l; };

const defaultSurgeon = () => { const l = getProviders().filter(p => p.active && PROVIDER_ROLES.includes(p.role as string)); return displayName((l.find(p => p.role === 'Surgeon') || l[0])!) || 'Unassigned'; };
const firstName = (n: string) => n.split(' ')[0];

export function createPatientFromCase(pc: PatientCase, by: string, role: string, extra: Partial<SvPatient> = {}): MedPatient {
  let id = `MED-${pc.patientId}`; while (medRepo.patient(id)) id = `MED-${Math.floor(100000 + Math.random() * 900000)}`;
  const surgeon = defaultSurgeon();
  const p: SvPatient = { id, name: pc.name, dob: pc.dob || '', sex: (pc.gender as MedPatient['sex']) || 'Other', phone: pc.phone, email: pc.email, language: 'English', allergies: [], primaryProvider: surgeon, careTeam: [{ name: surgeon, role: 'Surgeon' }], fictional: true, ...extra };
  medRepo.savePatient(p);
  repo.audit({ caseId: patientKey(id), user: by, role, action: 'patient.create', detail: `New patient chart created (Add New Patient): ${p.name}, DOB ${p.dob}, ${p.sex} · MRN ${id} · surgeon ${surgeon}${p.paymentType ? ` · payment ${p.paymentType}` : ''}${p.referralSource ? ` · referral ${p.referralSource}${p.referredBy ? ` (${p.referredBy})` : ''}` : ''}` });
  window.dispatchEvent(new Event('vityls-med-updated'));
  return p;
}

export function sendFormsPacket(p: MedPatient, x: { forms: string[]; text: boolean; email: boolean; portal: boolean }, by: string, role: string): FormsPacket {
  if (!x.forms.length) throw new Error('Choose at least one form.');
  if (!x.text && !x.email && !x.portal) throw new Error('Choose text, email or the portal.');
  if (x.email && !p.email) throw new Error('There is no email address on file.');
  const id = uid('fp'); const link = `${location.href.split('#')[0].split('?')[0]}#portal-forms=${id}`;
  const message = `Hi ${firstName(p.name)}, ${getSettings().practiceName} has created your chart. Please complete your ${x.forms.map(formTitle).join(', ')} before your visit: ${link}${x.portal ? ' (also in your patient portal)' : ''}. Questions? Call the office.`;
  const rec: FormsPacket = { id, patientId: p.id, forms: x.forms, text: x.text ? p.phone : undefined, email: x.email ? p.email : undefined, portal: x.portal, message, link, sentAt: new Date().toISOString(), by, role, transport: 'simulated-outbox' };
  svWrite('forms-packets', [...formsPackets(), rec]);
  const ch = [x.text && `text to ${p.phone}`, x.email && `email to ${p.email}`, x.portal && 'posted to the patient portal'].filter(Boolean).join(' · ');
  repo.audit({ caseId: patientKey(p.id), user: by, role, action: 'forms.packet.send', detail: `${x.forms.length} form(s) (${x.forms.map(formTitle).join(', ')}) · ${ch} · SIMULATED, nothing sent` });
  window.dispatchEvent(new Event('vityls-med-updated'));
  return rec;
}

/** v0.5: Surgery's Add New Patient → MedPatient with payment type + referral source. */
export function createPatient(x: NewPatientInput, by: string, role: string): MedPatient {
  const pc = { patientId: `${Math.floor(100000 + Math.random() * 900000)}`, name: `${x.first} ${x.last}`, dob: x.dob, gender: x.sex, phone: x.phone, email: x.email || undefined } as PatientCase;
  const r = x.payRef; const t = (s: string) => s.trim() || undefined;
  return createPatientFromCase(pc, by, role, { firstName: x.first, lastName: x.last, paymentType: r.paymentType, insuranceCarrier: isInsurance(r.paymentType) ? t(r.insuranceCarrier) : undefined, memberId: isInsurance(r.paymentType) ? t(r.memberId) : undefined, referralSource: t(r.referralSource), referredBy: t(r.referredBy),
    insurance: isInsurance(r.paymentType) ? [r.paymentType, r.insuranceCarrier.trim(), r.memberId.trim() && `ID ${r.memberId.trim()}`].filter(Boolean).join(' · ') : r.paymentType });
}

/** The button + the whole routine (Add New Patient → chart → forms prompt → open chart, or hand the patient back via onCreated). */
export const AddNewPatientButton: React.FC<{ className?: string; small?: boolean; link?: boolean; label?: string; btnClass?: string; onCreated?: (p: MedPatient) => void }> = ({ className = '', small, link, label = 'Add New Patient', btnClass, onCreated }) => {
  const [actor] = useActor(); const { go, toast } = useSv(); const [open, setOpen] = useState(false); const [made, setMade] = useState<MedPatient | null>(null);
  return <>
    <button type="button" className={btnClass ? `${btnClass} ${className}` : link ? `sv-link inline-flex items-center gap-1 ${className}` : `sv-btn ${small ? 'sm' : ''} primary inline-flex items-center gap-1.5 ${className}`} onClick={() => setOpen(true)} data-testid="add-new-patient"><UserPlus size={link ? 14 : 15} />{label}</button>
    {open && <SvAddPatientDialog onClose={() => setOpen(false)} onCreate={x => { const p = createPatient(x, actor.name, actor.role); setOpen(false); setMade(p); toast(`Chart created for ${p.name} (${p.id}).`); }} />}
    {made && <FormsPrompt p={made} doneLabel={onCreated ? 'Back to the appointment' : undefined} onDone={() => { const m = made; setMade(null); if (onCreated) onCreated(m); else go({ type: 'chart', pid: m.id }); }} />}
  </>;
};

export const FormsPrompt: React.FC<{ p: MedPatient; onDone: () => void; doneLabel?: string }> = ({ p, onDone, doneLabel }) => {
  const [actor] = useActor(); const { toast } = useSv();
  const [forms, setForms] = useState<string[]>(NEW_PATIENT_FORMS); const [text, setText] = useState(!!p.phone); const [email, setEmail] = useState(!!p.email); const [portal, setPortal] = useState(true);
  const [err, setErr] = useState(''); const [sent, setSent] = useState<FormsPacket | null>(null);
  const send = () => { setErr(''); try { const r = sendFormsPacket(p, { forms, text, email, portal }, actor.name, actor.role); setSent(r); toast('Forms queued in the simulated outbox. Nothing was sent.'); } catch (e) { setErr((e as Error).message); } };
  const skip = () => { repo.audit({ caseId: patientKey(p.id), user: actor.name, role: actor.role, action: 'forms.packet.send', detail: 'New-patient forms prompt: Not now (nothing queued)' }); onDone(); };
  return <div className="sv-modal" role="dialog" aria-modal="true" aria-label="Send new-patient forms" data-testid="forms-prompt" onKeyDown={e => { if (e.key === 'Escape') (sent ? onDone : skip)(); }}>
    <div className="sv-modal-scrim" />
    <div className="sv-modal-box" style={{ width: 'min(560px, 94vw)' }}>
      <div className="flex items-center gap-2 mb-1"><Send size={16} /><b className="text-[15px]">{sent ? 'Forms queued' : `Send forms to ${p.name}?`}</b><button type="button" className="ml-auto sv-link" onClick={sent ? onDone : skip} aria-label="Close"><X size={16} /></button></div>
      {!sent ? <>
        <p className="text-[13px] mb-2">The chart for <b>{p.name}</b> ({p.id}) is ready. Send the new-patient forms now so they can be completed before the visit.</p>
        <div className="sv-label">Forms</div>
        <div className="space-y-1 mb-2">{NEW_PATIENT_FORMS.map(f => <label key={f} className="flex items-center gap-2 text-[13.5px]"><input type="checkbox" checked={forms.includes(f)} onChange={e => setForms(e.target.checked ? [...forms, f] : forms.filter(x => x !== f))} data-testid={`fp-form-${f}`} />{formTitle(f)}</label>)}</div>
        <div className="sv-label">How</div>
        <div className="space-y-1">
          <label className="flex items-center gap-2 text-[13.5px]"><input type="checkbox" checked={text} disabled={!p.phone} onChange={e => setText(e.target.checked)} data-testid="fp-text" />Text message to <b>{p.phone || '(no mobile on file)'}</b></label>
          <label className="flex items-center gap-2 text-[13.5px]"><input type="checkbox" checked={email} disabled={!p.email} onChange={e => setEmail(e.target.checked)} data-testid="fp-email" />Email to <b>{p.email || '(no email on file)'}</b></label>
          <label className="flex items-center gap-2 text-[13.5px]"><input type="checkbox" checked={portal} onChange={e => setPortal(e.target.checked)} data-testid="fp-portal" />Post to the patient portal</label>
        </div>
        {err && <p className="text-[12.5px] text-[var(--crit)] mt-2" role="alert">{err}</p>}
        <p className="text-[11.5px] sv-muted mt-2">Simulation: nothing is texted or emailed. The message and link are kept in the outbox and the audit trail.</p>
        <div className="flex justify-end gap-2 mt-3"><button type="button" className="sv-btn" onClick={skip} data-testid="fp-skip">Not now</button><button type="button" className="sv-btn primary" onClick={send} data-testid="fp-send">Send {forms.length} form{forms.length === 1 ? '' : 's'} (simulated)</button></div>
      </> : <>
        <p className="text-[13px]">{[sent.text && `Text to ${sent.text}`, sent.email && `Email to ${sent.email}`, sent.portal && 'Posted to the portal'].filter(Boolean).join(' · ')} · <span className="sv-tag warn">simulated, not sent</span></p>
        <div className="sv-mail mt-2 text-[13px]" data-testid="fp-preview"><div className="sv-muted sv-small">Message as it would be sent</div>{sent.message}</div>
        <div className="flex justify-end gap-2 mt-3"><button type="button" className="sv-btn primary" onClick={onDone} data-testid="fp-open-chart">{doneLabel || `Open ${firstName(p.name)}’s chart`}</button></div>
      </>}
    </div>
  </div>;
};

/** Chart line: what was sent to a new patient, with a resend. */
export const PacketLine: React.FC<{ p: MedPatient }> = ({ p }) => {
  useMedTick(); const l = formsPackets(p.id); const [prompt, setPrompt] = useState(false);
  if (!l.length && medRepo.visits(p.id).length) return null;
  const last = l[l.length - 1];
  return <div className="py-1.5 border-b border-[var(--line)] text-[13px] flex flex-wrap items-center gap-x-3 gap-y-1" data-testid="chart-forms-packet">
    <b className="text-[11px] tracking-[.07em] uppercase">New-patient forms</b>
    {last ? <span>{last.forms.map(formTitle).join(', ')} · {[last.text && 'text', last.email && 'email', last.portal && 'portal'].filter(Boolean).join(' + ')} · {fmtDateTime(last.sentAt)} · {last.by.replace(/,.*$/, '')} <span className="sv-tag warn">simulated</span></span> : <span className="sv-muted">Not sent yet</span>}
    <button type="button" className="sv-link" onClick={() => setPrompt(true)} data-testid="chart-send-forms">{last ? 'Send again' : 'Send forms'}</button>
    {prompt && <FormsPrompt p={p} onDone={() => setPrompt(false)} />}
  </div>;
};

/** Patient portal card (Surgery edition only): the forms the office posted. */
export const PortalForms: React.FC<{ p: MedPatient }> = ({ p }) => {
  useMedTick(); const l = formsPackets(p.id).filter(x => x.portal); const [open, setOpen] = useState<string | null>(null);
  const hip = stationPlan('patientPortal'); const extra = [...hip.required, ...hip.asNeeded].filter(f => f === HIPAA_FILE); // v0.13: the HIPAA Release is always offered in the portal when placed at Portal / At-home
  if (!l.length && !extra.length) return null;
  const files = Array.from(new Set([...l.flatMap(x => x.forms), ...extra]));
  const pc = { id: `portal-forms:${p.id}`, patientId: p.id, name: p.name, age: 0, gender: p.sex, dob: p.dob, phone: p.phone, email: p.email, scheduledTime: '', estimatedDurationMins: 0, room: '', surgeon: p.primaryProvider, procedure: 'New-patient forms', aiSummary: '', readinessScore: 0, readinessLevel: 'IN_PROGRESS', allergies: p.allergies, labs: [], stage: 'CHECK_IN', arrivalStatus: 'EN_ROUTE', arrivalTime: '', bottlenecks: [], actionItems: [] } as unknown as PatientCase;
  if (open) return <div className="vy-card p-2"><FormPage patient={pc} form={{ title: formTitle(open), file: open, category: 'Intake', stage: '' } as any} station="patientPortal" onClose={() => setOpen(null)} /></div>;
  return <div className="vy-card p-4" data-testid="portal-forms"><div className="text-[12px] font-bold tracking-[.08em] uppercase text-[#5f6862]">Forms from your surgeon’s office</div>
    <ul className="mt-2 space-y-2">{files.map(f => { const r = repo.getForm(pc.id, f); return <li key={f} className="flex items-center gap-2 text-[15px]"><span className="flex-1">{formTitle(f)}</span><span className="text-[13px] text-[#5f6862]">{r.status === 'locked' ? 'Completed' : r.status === 'not-started' ? 'To complete' : 'In progress'}</span><button type="button" className="vy-btn vy-btn-secondary" onClick={() => setOpen(f)} data-testid={`portal-form-${f}`}>Open</button></li>; })}</ul>
    <p className="text-[13px] text-[#5f6862] mt-2">{l.length ? `Posted ${fmtDateTime(l[l.length - 1].sentAt)}.` : 'Optional: authorize the office to share your records with people you choose.'} Test build: fictional data.</p></div>;
};
