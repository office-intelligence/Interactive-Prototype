/* AI Email Intake (simulated). Fictional inbox of referral emails; Nightingale (scripted, on-device) extracts the
 * request; accepting it creates or matches a Core patient, files attachments to Core documents and creates a
 * scheduling request, or an appointment when the Scheduling module is on. Replies go to the simulated outbox only. */
import { moduleStore, queueOutbox } from '../../core/store';
import { medRepo, MedPatient, MedVisit, addDays, isoDay, uid, patientKey } from '../../med/record';
import { addDoc } from '../../surgery/documents';
import { repo } from '../../v6/dataLayer';
import { now } from '../../core/practices';

const S = moduleStore('email-intake');
export interface Attachment { id: string; name: string; kind: 'H&P' | 'Labs' | 'Insurance' | 'Imaging' | 'Referral'; docType: string; text: string }
export interface Extraction { patient: string; dob: string; phone: string; procedure: string; requestedDate: string; surgeon: string; referring: string; insurance: string; urgency: string; confidence: Record<string, 'high' | 'medium' | 'low'> }
export interface Email { id: string; from: string; fromName: string; org: string; subject: string; body: string; receivedAt: string; attachments: Attachment[]; kind: 'request' | 'other'; extraction?: Extraction;
  status: 'new' | 'accepted' | 'replied' | 'dismissed'; patientId?: string; matched?: boolean; filedDocs?: string[]; requestId?: string; visitId?: string; reply?: { text: string; at: string; by: string; outboxId: string } }
export interface SchedRequest { id: string; emailId: string; patientId: string; patient: string; procedure: string; requestedDate: string; surgeon: string; referring: string; status: 'awaiting-scheduling' | 'booked'; visitId?: string; createdAt: string; createdBy: string }

const hp = (n: string, dob: string, dx: string, plan: string) => `HISTORY & PHYSICAL (fictional)\nPatient: ${n}  DOB: ${dob}\nAssessment: ${dx}\nPlan: ${plan}\nPMH: hypertension, controlled. No prior anesthesia problems. NKDA.\nExam: alert, oriented; heart RRR; lungs clear.`;
const labs = (n: string) => `LABORATORY REPORT (fictional)\nPatient: ${n}\nCBC: WBC 6.8, Hgb 13.9, Plt 241\nBMP: Na 139, K 4.2, Cr 0.9, Glucose 98\nPT/INR: 1.0`;
const ins = (n: string, plan: string) => `INSURANCE CARD (front/back, fictional)\nMember: ${n}\nPlan: ${plan}\nMember ID: FIC-${Math.abs(n.length * 7919) % 100000}\nGroup: 4410`;

export function seedInbox(): Email[] {
  const T = isoDay(now()); const at = (d: number, h: number) => { const x = new Date(now()); x.setDate(x.getDate() + d); x.setHours(h, 12, 0, 0); return x.toISOString(); };
  const ex = (o: Omit<Extraction, 'confidence'>, low: string[] = []): Extraction => ({ ...o, confidence: Object.fromEntries(Object.keys(o).map(k => [k, low.includes(k) ? 'medium' : 'high'])) as any });
  return [
    { id: 'em-1', from: 'scheduling@pacific-ortho.example', fromName: 'Linda Cho', org: 'Pacific Orthopedic Group', subject: 'Surgery scheduling request: Maria Delgado, R knee arthroscopy', receivedAt: at(0, 8), kind: 'request', status: 'new',
      body: `Good morning,\n\nPlease schedule our patient Maria Delgado (DOB 04/12/1968, cell 555-0142) for a right knee arthroscopy with partial medial meniscectomy (CPT 29881) with Dr. Sam Patel. She would like ${addDays(T, 9)} if possible; mornings work best.\n\nAttached are her H&P, pre-op labs and insurance card (Blue Harbor PPO).\n\nThank you,\nLinda Cho\nSurgical scheduler, Pacific Orthopedic Group\n(fictional test email)`,
      attachments: [{ id: 'a1', name: 'Delgado_HP.pdf', kind: 'H&P', docType: 'Outside records', text: hp('Maria Delgado', '04/12/1968', 'Right knee medial meniscus tear', 'Arthroscopy with partial medial meniscectomy') }, { id: 'a2', name: 'Delgado_preop_labs.pdf', kind: 'Labs', docType: 'Laboratory', text: labs('Maria Delgado') }, { id: 'a3', name: 'Delgado_insurance.jpg', kind: 'Insurance', docType: 'Insurance', text: ins('Maria Delgado', 'Blue Harbor PPO') }],
      extraction: ex({ patient: 'Maria Delgado', dob: '04/12/1968', phone: '555-0142', procedure: 'Right knee arthroscopy, partial medial meniscectomy (CPT 29881)', requestedDate: addDays(T, 9), surgeon: 'Sam Patel, MD', referring: 'Pacific Orthopedic Group · Linda Cho', insurance: 'Blue Harbor PPO', urgency: 'Elective' }) },
    { id: 'em-2', from: 'referrals@valley-ent.example', fromName: 'Dr. Aaron Mbeki', org: 'Valley ENT Associates', subject: 'Request: tonsillectomy for Owen Brightwater (age 15)', receivedAt: at(-1, 15), kind: 'request', status: 'new',
      body: `Hello,\n\nWe'd like to book Owen Brightwater, DOB 09/03/2011, for tonsillectomy and adenoidectomy with Dr. Dana Whitfield. Recurrent tonsillitis, 7 episodes this year. Family prefers the week of ${addDays(T, 14)}. Mother (Jenna Brightwater, 555-0177) is the guardian and contact.\n\nH&P and insurance attached; labs to follow.\n\nAaron Mbeki, MD\nValley ENT Associates (fictional)`,
      attachments: [{ id: 'b1', name: 'Brightwater_HP.pdf', kind: 'H&P', docType: 'Outside records', text: hp('Owen Brightwater', '09/03/2011', 'Recurrent acute tonsillitis', 'Tonsillectomy and adenoidectomy') }, { id: 'b2', name: 'Brightwater_insurance_front_back.jpg', kind: 'Insurance', docType: 'Insurance', text: ins('Owen Brightwater', 'Sunline HMO') }],
      extraction: ex({ patient: 'Owen Brightwater', dob: '09/03/2011', phone: '555-0177 (mother, Jenna Brightwater)', procedure: 'Tonsillectomy and adenoidectomy', requestedDate: addDays(T, 14), surgeon: 'Dana Whitfield, MD', referring: 'Valley ENT Associates · Dr. Aaron Mbeki', insurance: 'Sunline HMO', urgency: 'Elective · minor, guardian consent needed' }, ['requestedDate']) },
    { id: 'em-3', from: 'office@harborview-gi.example', fromName: 'Rosa Lin', org: 'Harborview GI', subject: 'Robert Fictus: follow-up procedure booking', receivedAt: at(-1, 10), kind: 'request', status: 'new',
      body: `Hi team,\n\nRobert Fictus (DOB 01/27/1965) needs a surveillance colonoscopy with Dr. Whitfield, any day after ${addDays(T, 20)}. He's an existing patient of yours. Referral letter attached.\n\nRosa Lin, Harborview GI (fictional)`,
      attachments: [{ id: 'c1', name: 'Fictus_referral.pdf', kind: 'Referral', docType: 'Referral', text: `REFERRAL (fictional)\nPatient: Robert Fictus  DOB 01/27/1965\nReason: surveillance colonoscopy, history of adenomatous polyps (2021).` }],
      extraction: ex({ patient: 'Robert Fictus', dob: '01/27/1965', phone: '', procedure: 'Surveillance colonoscopy', requestedDate: addDays(T, 21), surgeon: 'Dana Whitfield, MD', referring: 'Harborview GI · Rosa Lin', insurance: 'On file', urgency: 'Routine' }, ['requestedDate', 'phone']) },
    { id: 'em-4', from: 'news@medsupply.example', fromName: 'MedSupply Weekly', org: 'MedSupply', subject: 'October specials on sterile drapes', receivedAt: at(-2, 9), kind: 'other', status: 'new', body: 'Save 15% on drapes and gowns this month. (fictional newsletter)', attachments: [] },
  ];
}
export const inbox = (): Email[] => { const l = S.read<Email[] | null>('inbox', null); if (l) return l; const s = seedInbox(); S.write('inbox', s); return s; };
const saveEmail = (e: Email) => S.write('inbox', inbox().map(x => x.id === e.id ? e : x));
export const requests = () => S.read<SchedRequest[]>('requests', []);
const saveReq = (r: SchedRequest) => { const l = requests(); S.write('requests', l.some(x => x.id === r.id) ? l.map(x => x.id === r.id ? r : x) : [...l, r]); };
export function resetInbox() { S.write('inbox', seedInbox()); S.write('requests', []); }

const usDateI = (iso: string) => { const m = iso.match(/^(\d{4})-(\d{2})-(\d{2})/); return m ? `${m[2]}/${m[3]}/${m[1]}` : iso; };
const norm = (s: string) => s.toLowerCase().replace(/[^a-z]/g, '');
export const findPatient = (name: string, dob: string): MedPatient | undefined => medRepo.patients().find(p => norm(p.name) === norm(name) && p.dob === dob);

export function acceptExtraction(id: string, x: Extraction, by: string, role: string, schedulingOn: boolean): Email {
  const e = inbox().find(m => m.id === id)!; let p = findPatient(x.patient, x.dob); const matched = !!p;
  if (!p) { p = { id: uid('pt'), name: x.patient, dob: x.dob, sex: 'Other', phone: x.phone.replace(/\s*\(.*\)/, ''), language: 'English', allergies: [], primaryProvider: x.surgeon, careTeam: [{ name: x.surgeon, role: 'Surgeon' }], insurance: x.insurance, fictional: true } as MedPatient; medRepo.savePatient(p);
    repo.audit({ caseId: patientKey(p.id), user: by, role, action: 'patient.create', detail: `Core patient created from email intake (${e.org}): ${p.name}, DOB ${p.dob}` }); }
  const filed: string[] = [];
  e.attachments.forEach(a => { const did = uid('doc'); addDoc({ id: did, patientId: p!.id, type: a.docType, title: `${a.kind} · ${a.name}`, source: `${e.org} (email intake)`, docDate: isoDay(new Date(e.receivedAt)), receivedAt: now().toISOString(), receivedBy: by, receivedRole: role, fileName: a.name, mime: 'text/plain', text: a.text, lines: a.text.split('\n'), description: `Attached to “${e.subject}”` }); filed.push(did); });
  const req: SchedRequest = { id: uid('req'), emailId: id, patientId: p.id, patient: p.name, procedure: x.procedure, requestedDate: x.requestedDate, surgeon: x.surgeon, referring: x.referring, status: 'awaiting-scheduling', createdAt: now().toISOString(), createdBy: by };
  saveReq(req); let visitId: string | undefined;
  if (schedulingOn) visitId = bookRequest(req.id, by, role);
  repo.audit({ caseId: patientKey(p.id), user: by, role, action: 'email-intake.accept', detail: `Accepted request from ${e.org}: ${x.procedure} on ${x.requestedDate} with ${x.surgeon}; ${filed.length} attachment(s) filed; ${visitId ? 'appointment booked' : 'scheduling request queued'}` });
  const out = { ...e, status: 'accepted' as const, extraction: x, patientId: p.id, matched, filedDocs: filed, requestId: req.id, visitId }; saveEmail(out); return out;
}
export function bookRequest(rid: string, by: string, role: string): string {
  const r = requests().find(x => x.id === rid)!; const taken = medRepo.visits().filter(v => v.date === r.requestedDate && v.provider === r.surgeon).map(v => v.time);
  const time = ['07:30 AM', '08:00 AM', '08:30 AM', '09:00 AM', '10:00 AM', '11:00 AM', '01:00 PM'].find(t => !taken.includes(t)) || '07:00 AM';
  const v: MedVisit = { id: uid('visit'), patientId: r.patientId, date: r.requestedDate, time, durationMin: 45, provider: r.surgeon, room: 'Exam 1', visitType: 'Pre-surgical consult', reason: `${r.procedure} · referred by ${r.referring} (email intake)`, step: 'scheduled', problemIds: [], createdAt: now().toISOString(), createdBy: by };
  medRepo.saveVisit(v); saveReq({ ...r, status: 'booked', visitId: v.id });
  const e = inbox().find(m => m.id === r.emailId); if (e) saveEmail({ ...e, visitId: v.id });
  repo.audit({ caseId: patientKey(r.patientId), user: by, role, action: 'visit.create', detail: `Booked from email request: ${r.procedure} · ${r.requestedDate} ${time} · ${r.surgeon}` });
  return v.id;
}
export function draftReply(e: Email, practiceName: string, booked?: { date: string; time: string }): string {
  if (!e.extraction) return `Thank you for your email. We'll follow up shortly.\n\n${practiceName}`;
  const x = e.extraction; const first = e.fromName.replace(/^Dr\.\s*/, 'Dr. ');
  return `Hello ${first},\n\nThank you for referring ${x.patient}. We received the request for ${(t => t.charAt(0).toLowerCase() + t.slice(1))(x.procedure.replace(/\s*\(CPT.*\)/, ''))} with ${x.surgeon.replace(/, MD$/, '')}${e.attachments.length ? ` and the attached ${e.attachments.map(a => a.kind).join(', ')}` : ''}.\n\n${booked ? `We have reserved ${booked.date} at ${booked.time}. Our coordinator will call ${x.patient.split(' ')[0]} to confirm and send the pre-op forms.` : `Our scheduling team will confirm a date close to ${usDateI(x.requestedDate)} and contact ${x.patient.split(' ')[0]} directly.`}${/labs to follow/i.test(e.body) ? '\n\nPlease send the pre-op labs when they are ready.' : ''}\n\nBest regards,\n${practiceName}`;
}
export function sendReply(id: string, text: string, by: string, role: string): Email {
  const e = inbox().find(m => m.id === id)!; const o = queueOutbox({ module: 'email-intake', to: e.from, subject: `Re: ${e.subject}`, body: text, by }, now().toISOString());
  repo.audit({ caseId: e.patientId ? patientKey(e.patientId) : 'practice', user: by, role, action: 'email-intake.reply', detail: `Reply approved and placed in the simulated outbox to ${e.from} (nothing was sent)` });
  const out = { ...e, status: 'replied' as const, reply: { text, at: now().toISOString(), by, outboxId: o.id } }; saveEmail(out); return out;
}
export function dismiss(id: string, by: string, role: string) { const e = inbox().find(m => m.id === id)!; saveEmail({ ...e, status: 'dismissed' }); repo.audit({ caseId: 'practice', user: by, role, action: 'email-intake.dismiss', detail: `Not a request: ${e.subject}` }); }
