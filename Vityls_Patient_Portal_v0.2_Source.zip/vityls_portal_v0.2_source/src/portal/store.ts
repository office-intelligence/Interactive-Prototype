/*
 * Vityls Patient Portal v0.1 · data layer (browser test build, all fictitious).
 * Patient-owned accounts, independent of any practice. Keys live under `vityls:portal:` (module `patient-portal`).
 * Every connection (FHIR, fax/Direct, upload link, practice link) is SIMULATED until a BAA is signed.
 */
import { rawStorage } from '../edition';
import * as H from './hub';
export interface Lab { id: string; name: string; code: string; value: number; unit: string; low: number; high: number; date: string; source: string; fromPractice?: boolean; }
export interface Doc { id: string; title: string; type: string; date: string; source: string; size?: string; dataUrl?: string; note?: string; explained?: string; fromPractice?: boolean; }
export interface Med { id: string; name: string; dose: string; how: string; source: string; }
export interface Allergy { id: string; name: string; reaction: string; }
export interface Source { id: string; kind: 'fhir' | 'fax' | 'upload-link' | 'patient-upload' | 'practice'; name: string; vendor?: string; connectedAt: string; lastSync?: string; }
export interface RecordsRequest { id: string; provider: string; fax: string; scope: string; returnFax: string; returnDirect: string; createdAt: string; due: string; status: 'draft' | 'sent (simulated)' | 'received'; }
export interface LinkedPractice { id: string; name: string; doctor: string; scopes: string[]; since: string; }
export interface Msg { id: string; practiceId: string; from: 'me' | 'practice'; text: string; at: string; }
export interface Refill { id: string; med: string; practiceId: string; at: string; status: string; }
export interface Reminder { id: string; title: string; due: string; repeat: string; done?: boolean; fromPractice?: boolean; }
export interface Chat { id: string; who: 'ng' | 'me'; text: string; at: string; }
export interface Plan { state: 'free' | 'trial' | 'active'; trialEnd?: string; explainUsed: number; month: string; }
export interface Account {
  id: string; email: string; password: string; name: string; dob: string; createdAt: string;
  plan: Plan; labs: Lab[]; docs: Doc[]; meds: Med[]; medsConfirmed: boolean; allergies: Allergy[]; allergiesVerified: boolean;
  history: string[] | null; symptoms: { id: string; text: string; at: string }[];
  sources: Source[]; requests: RecordsRequest[]; practices: LinkedPractice[]; messages: Msg[]; refills: Refill[]; reminders: Reminder[];
  chat: Chat[]; dismissed: string[]; answered: string[]; audit: { at: string; what: string }[];
  outside?: { id: string; name: string; specialty: string; phone: string }[]; hubSynced?: string[];
}
export interface UploadLink { token: string; acctId: string; patient: string; recipient: string; created: string; expires: string; uploads: number; revoked?: boolean; }

const K = { accts: 'vityls:portal:accounts', session: 'vityls:portal:session', links: 'vityls:portal:upload-links', seed: 'vityls:portal:seed', viewing: 'vityls:portal:viewing', guest: 'vityls:portal:guest' };
const SEED_VERSION = 'portal-v0.2';
(window as any).__vitylsRawStorage = rawStorage; // test hook (test build only)
const read = <T,>(k: string, d: T): T => { try { const v = rawStorage.getItem(k); return v ? JSON.parse(v) as T : d; } catch { return d; } };
const write = (k: string, v: unknown) => rawStorage.setItem(k, JSON.stringify(v));
export const uid = (p = '') => p + Math.random().toString(36).slice(2, 10);
export const nowIso = () => new Date().toISOString();
export const today = () => new Date().toISOString().slice(0, 10);
const daysFrom = (n: number) => new Date(Date.now() + n * 864e5).toISOString().slice(0, 10);

export const accounts = (): Account[] => read<Account[]>(K.accts, []);
const saveAll = (l: Account[]) => write(K.accts, l);
export function saveAccount(a: Account) { const l = accounts(); const i = l.findIndex(x => x.id === a.id); if (i < 0) l.push(a); else l[i] = a; saveAll(l); }
export const getAccount = (id: string) => accounts().find(a => a.id === id) || null;
export const session = () => read<string | null>(K.session, null);
export const setSession = (id: string | null) => { if (id) write(K.session, id); else rawStorage.removeItem(K.session); rawStorage.removeItem(K.viewing); };
/** Caregiver profile switch: which account the signed-in user is viewing. */
export const viewing = () => read<string | null>(K.viewing, null);
export const setViewing = (id: string) => write(K.viewing, id);

export function blankAccount(name: string, email: string, password: string, dob: string): Account {
  return { id: uid('vp-'), email: email.trim().toLowerCase(), password, name, dob, createdAt: nowIso(), plan: { state: 'free', explainUsed: 0, month: today().slice(0, 7) },
    labs: [], docs: [], meds: [], medsConfirmed: false, allergies: [], allergiesVerified: false, history: null, symptoms: [], sources: [], requests: [], practices: [],
    messages: [], refills: [], reminders: [], chat: [], dismissed: [], answered: [], audit: [{ at: nowIso(), what: 'Account created (no practice needed)' }] };
}
export function signUp(name: string, email: string, password: string, dob: string): Account | string {
  if (!name.trim() || !email.includes('@') || password.length < 8 || !dob) return 'Please enter your name, a valid email, your date of birth and a password of at least 8 characters.';
  if (accounts().some(a => a.email === email.trim().toLowerCase())) return 'An account with that email already exists. Sign in instead.';
  const a = blankAccount(name.trim(), email, password, dob);
  a.chat.push({ id: uid(), who: 'ng', at: nowIso(), text: `Welcome, ${a.name.split(' ')[0]}. I'm Nightingale. This account is yours, not any doctor's office. I'll help you collect your records, explain them in plain language and keep track of your health. I don't diagnose or tell you whether to do something; I help you understand and ask good questions.` });
  adoptGuest(a); saveAccount(a); setSession(a.id); return a;
}
export function signIn(email: string, password: string): Account | string {
  const a = accounts().find(x => x.email === email.trim().toLowerCase());
  if (!a || a.password !== password) return 'Email or password is not right.';
  setSession(a.id); return a;
}

/* ---------- Plan / patient entitlements ---------- */
export const FREE_EXPLAIN_LIMIT = 10;
export const isPlus = (a: Account) => a.plan.state === 'active' || (a.plan.state === 'trial' && (a.plan.trialEnd || '') >= today());
export function canExplain(a: Account, fromPractice = false) { if (fromPractice || isPlus(a)) return true; rollMonth(a); return a.plan.explainUsed < FREE_EXPLAIN_LIMIT; }
function rollMonth(a: Account) { const m = today().slice(0, 7); if (a.plan.month !== m) { a.plan.month = m; a.plan.explainUsed = 0; } }
export function useExplain(a: Account, fromPractice = false) { rollMonth(a); if (!fromPractice && !isPlus(a)) a.plan.explainUsed++; }

/* ---------- Lab explanations (scripted, never a diagnosis) ---------- */
const LAB_INFO: Record<string, string> = {
  ALT: 'ALT is a liver enzyme. It can rise for many reasons, including some medicines (for example statins, acetaminophen at high doses, some antibiotics), alcohol, recent hard exercise, a fatty liver or a viral illness.',
  AST: 'AST is an enzyme found in the liver and muscles. Hard exercise and some medicines can raise it.',
  'LDL cholesterol': 'LDL is the cholesterol that can build up in arteries. Diet, genetics, thyroid function and some medicines affect it.',
  'Hemoglobin A1c': 'A1c reflects your average blood sugar over about three months.',
  Glucose: 'Glucose is your blood sugar at the time of the draw. Eating before the test raises it.',
  TSH: 'TSH is the signal from the brain that tells the thyroid how hard to work. Biotin supplements can interfere with this test.',
  Potassium: 'Potassium helps muscles and the heart work. Water pills (diuretics), ACE inhibitors and some supplements change it.',
  Creatinine: 'Creatinine is a waste product the kidneys clear; it is used to estimate kidney function. Muscle mass, hydration and some medicines (for example ibuprofen) affect it.',
  Hemoglobin: 'Hemoglobin carries oxygen in red blood cells.',
};
/** Latest value per test. */
export function latestLabs(labs: Lab[]) { const m: Record<string, Lab> = {}; labs.forEach(l => { if (!m[l.name] || m[l.name].date < l.date) m[l.name] = l; }); return Object.values(m); }
export const labFlag = (l: Lab) => l.value > l.high ? 'high' : l.value < l.low ? 'low' : 'normal';
export function explainLab(l: Lab) {
  const f = labFlag(l); const base = LAB_INFO[l.name] || `${l.name} is one of the values your care team uses to follow your health.`;
  const where = f === 'normal' ? `Your result, ${l.value} ${l.unit}, is inside the lab's reference range (${l.low}–${l.high}).` : `Your result, ${l.value} ${l.unit}, is ${f === 'high' ? 'above' : 'below'} the lab's reference range (${l.low}–${l.high}). One value outside the range is common and does not by itself mean something is wrong.`;
  return `${where} ${base} This is general information, not a diagnosis; your doctor can tell you what it means for you.`;
}
/** Medicines commonly known to affect a lab (general education only). */
const MED_EFFECTS: { med: RegExp; labs: string[]; note: string }[] = [
  { med: /statin|atorvastatin|simvastatin|rosuvastatin|pravastatin/i, labs: ['ALT', 'AST'], note: 'Statins are known to sometimes raise liver enzymes (ALT/AST).' },
  { med: /acetaminophen|tylenol/i, labs: ['ALT', 'AST'], note: 'Acetaminophen, especially in larger amounts, can raise liver enzymes.' },
  { med: /ibuprofen|naproxen|advil|aleve/i, labs: ['Creatinine', 'Potassium'], note: 'Anti-inflammatory pain relievers can affect kidney numbers such as creatinine.' },
  { med: /lisinopril|losartan|spironolactone/i, labs: ['Potassium', 'Creatinine'], note: 'Some blood pressure medicines can raise potassium and creatinine.' },
  { med: /hydrochlorothiazide|furosemide|hctz/i, labs: ['Potassium', 'Glucose'], note: 'Water pills can lower potassium and sometimes raise glucose.' },
  { med: /biotin/i, labs: ['TSH'], note: 'Biotin supplements can make thyroid test results look abnormal.' },
  { med: /prednisone|steroid/i, labs: ['Glucose', 'Hemoglobin A1c'], note: 'Steroids such as prednisone can raise blood sugar.' },
  { med: /amoxicillin|clavulanate|augmentin/i, labs: ['ALT'], note: 'Some antibiotics, such as amoxicillin-clavulanate, can raise liver enzymes.' },
];
export function medLabLinks(meds: string[], labs: Lab[]) {
  const abn = latestLabs(labs).filter(l => labFlag(l) !== 'normal').map(l => l.name);
  const out: string[] = [];
  meds.forEach(m => MED_EFFECTS.forEach(e => { if (e.med.test(m) && e.labs.some(x => abn.includes(x))) out.push(`${m}: ${e.note}`); }));
  return out;
}
export function explainDoc(d: Doc) {
  const t = d.type.toLowerCase();
  if (t.includes('imaging')) return `This is an imaging report. The "Impression" section is the radiologist's summary. In plain words, the report for "${d.title}" describes what the images showed; terms like "mild" and "degenerative" are common with age. Ask your doctor which findings matter for you. (Simulated summary.)`;
  if (t.includes('lab')) return `This document contains lab results. I've added any values I could read to your Labs page so you can see trends. (Simulated extraction.)`;
  if (t.includes('visit') || t.includes('note')) return `This is a visit note. It usually has: why you came in, what was found on exam, the assessment and the plan. The plan section lists what you and your doctor agreed to do next. (Simulated summary.)`;
  return `I've filed "${d.title}" under ${d.type}. I can explain any part of it; just ask. (Simulated summary.)`;
}

/* ---------- Fictional FHIR sources (SIMULATED patient-access APIs) ---------- */
export const FHIR_DIRECTORY = [
  { id: 'northshore', name: 'Northshore Health System', vendor: 'Epic · MyChart', city: 'Seaview, CA' },
  { id: 'redwood', name: 'Redwood Valley Medical Group', vendor: 'athenahealth', city: 'Redwood Valley, CA' },
  { id: 'harborview', name: 'Harbor Point Hospital', vendor: 'Oracle Health (Cerner)', city: 'Harbor Point, CA' },
];
export function simulatedFhirImport(a: Account, srcId: string): { labs: number; meds: number; docs: number; allergies: number; dupes: number } {
  const s = FHIR_DIRECTORY.find(x => x.id === srcId)!; const src = `${s.name} (${s.vendor}, FHIR, simulated)`;
  const d1 = daysFrom(-3), d0 = daysFrom(-200);
  const bundles: Record<string, { labs: Omit<Lab, 'id' | 'source'>[]; meds: Omit<Med, 'id' | 'source'>[]; docs: Omit<Doc, 'id' | 'source'>[]; allergies: Omit<Allergy, 'id'>[] }> = {
    northshore: { labs: [
      { name: 'ALT', code: 'LOINC 1742-6', value: 68, unit: 'U/L', low: 7, high: 56, date: d1 }, { name: 'AST', code: 'LOINC 1920-8', value: 41, unit: 'U/L', low: 10, high: 40, date: d1 },
      { name: 'LDL cholesterol', code: 'LOINC 13457-7', value: 96, unit: 'mg/dL', low: 0, high: 100, date: d1 }, { name: 'Glucose', code: 'LOINC 2345-7', value: 94, unit: 'mg/dL', low: 70, high: 99, date: d1 },
      { name: 'ALT', code: 'LOINC 1742-6', value: 31, unit: 'U/L', low: 7, high: 56, date: d0 }],
      meds: [{ name: 'Atorvastatin', dose: '40 mg', how: 'once daily' }], docs: [{ title: 'Lumbar spine MRI report', type: 'Imaging report', date: daysFrom(-20) }, { title: 'Primary care visit note', type: 'Visit note', date: d1 }], allergies: [] },
    redwood: { labs: [{ name: 'Hemoglobin A1c', code: 'LOINC 4548-4', value: 5.9, unit: '%', low: 4, high: 5.6, date: daysFrom(-10) }, { name: 'TSH', code: 'LOINC 3016-3', value: 2.1, unit: 'mIU/L', low: 0.4, high: 4.0, date: daysFrom(-10) }],
      meds: [{ name: 'Lisinopril', dose: '10 mg', how: 'once daily' }], docs: [{ title: 'Annual physical summary', type: 'Visit note', date: daysFrom(-10) }], allergies: [{ name: 'Penicillin', reaction: 'Hives' }] },
    harborview: { labs: [{ name: 'Hemoglobin', code: 'LOINC 718-7', value: 13.9, unit: 'g/dL', low: 13.5, high: 17.5, date: daysFrom(-60) }],
      meds: [], docs: [{ title: 'Emergency visit discharge summary', type: 'Visit note', date: daysFrom(-60) }], allergies: [] },
  };
  const b = bundles[srcId]; let dupes = 0; const r = { labs: 0, meds: 0, docs: 0, allergies: 0, dupes: 0 };
  b.labs.forEach(l => { if (a.labs.some(x => x.name === l.name && x.date === l.date && x.value === l.value)) { dupes++; return; } a.labs.push({ ...l, id: uid('lab-'), source: src }); r.labs++; });
  b.meds.forEach(m => { if (a.meds.some(x => x.name.toLowerCase() === m.name.toLowerCase())) { dupes++; return; } a.meds.push({ ...m, id: uid('med-'), source: src }); r.meds++; });
  b.docs.forEach(d => { if (a.docs.some(x => x.title === d.title && x.date === d.date)) { dupes++; return; } a.docs.push({ ...d, id: uid('doc-'), source: src, size: 'FHIR DocumentReference' }); r.docs++; });
  b.allergies.forEach(x => { if (a.allergies.some(y => y.name === x.name)) { dupes++; return; } a.allergies.push({ ...x, id: uid('al-') }); r.allergies++; });
  r.dupes = dupes;
  const newAbn = a.labs.filter(l => l.source === src && labFlag(l) !== 'normal' && latestLabs(a.labs).includes(l));
  if (r.labs && newAbn.length) H.notify(a.id, a.name, 'abnormal', `New results from ${s.name} outside the range: ${newAbn.map(l => `${l.name} ${l.value} ${l.unit}`).join(', ')}.`);
  const ex = a.sources.find(x => x.id === srcId);
  if (ex) ex.lastSync = nowIso(); else a.sources.push({ id: srcId, kind: 'fhir', name: s.name, vendor: s.vendor, connectedAt: nowIso(), lastSync: nowIso() });
  a.audit.push({ at: nowIso(), what: `Connect my doctor: imported from ${src} (${r.labs} labs, ${r.meds} meds, ${r.docs} documents, ${dupes} duplicates skipped)` });
  return r;
}

/* ---------- Records requests + upload links ---------- */
export function newRecordsRequest(a: Account, provider: string, fax: string, scope: string): RecordsRequest {
  const id = 'RR-' + Math.random().toString(36).slice(2, 8).toUpperCase();
  return { id, provider, fax, scope, returnFax: `(555) 010-${String(1000 + Math.floor(Math.random() * 8999)).slice(0, 4)} ext ${id}`, returnDirect: `${id.toLowerCase()}@direct.records.vityls.test`, createdAt: nowIso(), due: daysFrom(30), status: 'draft' };
}
export const uploadLinks = () => read<UploadLink[]>(K.links, []);
export function newUploadLink(a: Account, recipient: string, days = 7): UploadLink {
  const l: UploadLink = { token: Math.random().toString(36).slice(2, 10) + Math.random().toString(36).slice(2, 10), acctId: a.id, patient: a.name, recipient, created: nowIso(), expires: daysFrom(days), uploads: 0 };
  write(K.links, [...uploadLinks(), l]); return l;
}
export function saveLink(l: UploadLink) { write(K.links, uploadLinks().map(x => x.token === l.token ? l : x)); }
export function linkStatus(l: UploadLink | undefined) { if (!l) return 'missing'; if (l.revoked) return 'revoked'; if (l.expires < today()) return 'expired'; return 'ok'; }

/* ---------- Proactive Nightingale prompts (data-driven) ---------- */
export interface Prompt { id: string; kind: 'labs-meds' | 'allergies' | 'meds' | 'history' | 'connect' | 'doc' | 'visit'; title: string; text: string; }
export function prompts(a: Account): Prompt[] {
  const out: Prompt[] = []; const done = (id: string) => a.dismissed.includes(id) || a.answered.includes(id);
  const abn = latestLabs(a.labs).filter(l => labFlag(l) !== 'normal').sort((x, y) => y.date.localeCompare(x.date));
  if (abn.length) { const id = 'labs-meds:' + abn.map(l => l.id).join(','); if (!done(id)) out.push({ id, kind: 'labs-meds', title: 'About your latest labs', text: `Now that I've seen your latest labs (${abn.slice(0, 3).map(l => `${l.name} ${labFlag(l)}`).join(', ')}), tell me about your medications so I can check whether any could explain the abnormal results.` }); }
  if (!a.allergiesVerified && !a.allergies.length && !done('allergies')) out.push({ id: 'allergies', kind: 'allergies', title: 'Allergies', text: "I don't have your allergies yet. Are you allergic to any medicines, foods or latex?" });
  if (!a.meds.length && !a.medsConfirmed && !done('meds') && !abn.length) out.push({ id: 'meds', kind: 'meds', title: 'Medications', text: 'What medicines, vitamins or supplements do you take? Even occasional ones like pain relievers count.' });
  if (a.history === null && !done('history')) out.push({ id: 'history', kind: 'history', title: 'Health history', text: 'Have you had any surgeries or ongoing conditions (for example high blood pressure, asthma, diabetes)?' });
  if (!a.sources.some(s => s.kind === 'fhir') && !done('connect')) out.push({ id: 'connect', kind: 'connect', title: 'Bring in your records', text: 'Do you use MyChart or another patient portal? I can connect to it and bring your labs and notes here.' });
  a.docs.filter(d => !d.explained).slice(0, 1).forEach(d => { const id = 'doc:' + d.id; if (!done(id)) out.push({ id, kind: 'doc', title: 'New document', text: `"${d.title}" arrived from ${d.source.split(' (')[0]}. Want a plain-language summary?` }); });
  return out;
}

/* ---------- Scripted chat (never diagnoses; red flags escalate) ---------- */
const RED = /chest pain|can'?t breathe|trouble breathing|shortness of breath|suicid|stroke|face droop|severe bleeding|passing out|faint/i;
export function nightingaleReply(a: Account, q: string): string {
  if (RED.test(q)) return 'That could be urgent. Please call 911 or your local emergency number now, or your doctor right away. I can’t assess emergencies.';
  const s = q.toLowerCase();
  if (/should i|is it safe|can i stop|ok to (take|stop)|go ahead/.test(s)) return "I can't tell you whether to do that; that decision belongs to you and your doctor. I can help you write the question to send to your doctor.";
  if (/lab|result/.test(s)) { const abn = latestLabs(a.labs).filter(l => labFlag(l) !== 'normal'); return a.labs.length ? `You have ${a.labs.length} lab values on file. ${abn.length ? `Latest values outside the range: ${abn.map(l => `${l.name} ${l.value} ${l.unit} (${labFlag(l)}, ${l.date})`).join('; ')}.` : 'All are inside their reference ranges.'} Open Labs to see trends, or tap a value and I'll explain it.` : 'I don’t have any labs yet. Connect my doctor can bring them in, or you can upload a lab report.'; }
  if (/med|pill|drug|statin/.test(s)) { const links = medLabLinks(a.meds.map(m => m.name), a.labs); return a.meds.length ? `Your medicines: ${a.meds.map(m => `${m.name} ${m.dose}`).join(', ')}.${links.length ? ' Worth asking your doctor about: ' + links.join(' ') : ''} I don't tell you to start or stop anything; that's for you and your doctor.` : 'I don’t have your medicines yet. Tell me what you take, or open Medications.'; }
  if (/allerg/.test(s)) return a.allergies.length ? `Allergies on file: ${a.allergies.map(x => `${x.name} (${x.reaction})`).join(', ')}.` : a.allergiesVerified ? 'You told me you have no known allergies.' : 'No allergies recorded yet. Do you have any?';
  if (/visit|appointment|prepare/.test(s)) return `For your next visit, I'd bring: ${[a.labs.some(l => labFlag(l) !== 'normal') ? 'questions about your out-of-range labs' : '', a.meds.length ? 'your medication list (' + a.meds.length + ')' : 'a list of your medicines', a.symptoms.length ? 'your symptom notes' : ''].filter(Boolean).join(', ')}. Portal Plus can draft a one-page visit summary.`;
  if (/headache|pain|tired|dizzy|nause|cough|fever|symptom/.test(s)) { a.symptoms.push({ id: uid(), text: q, at: nowIso() }); return "I've noted that in your symptom journal with today's date. I'll check back in a few days to ask how it's going. If it gets worse or worries you, contact your doctor."; }
  return "I can explain your labs and documents, keep your medicines and allergies current, help you request records and prepare for visits. What would you like to do?";
}

/* ---------- Seed: one fictional demo patient ---------- */
export function seedPortal(force = false) {
  if (!force && rawStorage.getItem(K.seed) === SEED_VERSION) return;
  const a = blankAccount('Jordan Rivera', 'jordan.rivera@example.test', 'portal2026', '1979-05-14'); a.id = 'vp-demo-jordan';
  const bay = 'Uploaded by me (results letter photos)';
  const L = (name: string, code: string, unit: string, low: number, high: number, pts: [number, number][]) => pts.forEach(([d, v]) => a.labs.push({ id: uid('lab-'), name, code, value: v, unit, low, high, date: daysFrom(d), source: bay }));
  L('LDL cholesterol', 'LOINC 13457-7', 'mg/dL', 0, 100, [[-560, 162], [-380, 148], [-200, 121]]);
  L('Glucose', 'LOINC 2345-7', 'mg/dL', 70, 99, [[-560, 97], [-380, 92], [-200, 95]]);
  L('Creatinine', 'LOINC 2160-0', 'mg/dL', 0.7, 1.3, [[-380, 0.9], [-200, 1.0]]);
  L('Potassium', 'LOINC 2823-3', 'mmol/L', 3.5, 5.1, [[-380, 4.2], [-200, 4.4]]);
  a.reminders = [{ id: uid(), title: 'Take morning medicines', due: today(), repeat: 'daily' }];
  a.chat = [{ id: uid(), who: 'ng', at: nowIso(), text: 'Good to see you, Jordan. I keep your records from every doctor in one place. Ask me anything, or answer one of my questions below.' }];
  const cg = blankAccount('Alex Rivera', 'alex.rivera@example.test', 'portal2026', '1985-08-21'); cg.id = 'vp-demo-alex';
  cg.chat.push({ id: uid(), who: 'ng', at: nowIso(), text: 'Hi Alex. If a family member invites you, you can switch to their profile from the top of the menu.' });
  const l = accounts().filter(x => x.id !== a.id && x.id !== cg.id); l.push(a, cg); saveAll(l);
  Object.values(H.HUB_KEYS).filter(k => k !== H.HUB_KEYS.accts).forEach(k => rawStorage.removeItem(k));
  rawStorage.setItem(K.seed, SEED_VERSION);
}
export function resetPortal() { [K.accts, K.session, K.links, K.seed, K.viewing, K.guest].forEach(k => rawStorage.removeItem(k)); seedPortal(true); }

/* ---------- v0.2: practice items → account (results, documents), trend alerts ---------- */
export function syncFromHub(a: Account): boolean {
  a.hubSynced ||= []; let ch = false;
  H.itemsFor(a.id).filter(i => i.from === 'practice' && (i.kind === 'result' || i.kind === 'document') && !a.hubSynced!.includes(i.id)).forEach(i => {
    a.hubSynced!.push(i.id); ch = true; const src = `${i.practiceName} (Vityls practice)`;
    if (i.kind === 'result' && i.lab) { const prev = a.labs.filter(l => l.name === i.lab!.name).sort((x, y) => y.date.localeCompare(x.date)); const nl: Lab = { ...i.lab, id: uid('lab-'), source: src, fromPractice: true }; a.labs.push(nl); trendAlert(a, nl, prev); }
    else a.docs.unshift({ id: uid('doc-'), title: i.title, type: 'From practice', date: today(), source: src, fromPractice: true, note: i.body || undefined });
  });
  return ch;
}
/** Worsening: the latest value is outside the range and further from it than the previous value, or a 3-point rise/fall toward or past a limit. */
export function trendAlert(a: Account, nl: Lab, prev: Lab[]) {
  const dist = (l: Lab) => l.value > l.high ? l.value - l.high : l.value < l.low ? l.low - l.value : 0;
  if (prev.length && dist(nl) > 0 && dist(nl) > dist(prev[0])) H.notify(a.id, a.name, 'trend', `${nl.name} is moving further outside the range: ${prev[0].value} → ${nl.value} ${nl.unit}. Worth discussing with the doctor.`);
  else if (prev.length >= 2 && ((nl.value > prev[0].value && prev[0].value > prev[1].value) || (nl.value < prev[0].value && prev[0].value < prev[1].value)) && dist(nl) > 0) H.notify(a.id, a.name, 'trend', `${nl.name} has changed in the same direction three times in a row (${prev[1].value} → ${prev[0].value} → ${nl.value} ${nl.unit}).`);
}
export const GUEST_LIMIT = 3;
export interface Guest { used: number; chat: Chat[]; labs: Lab[]; }
export const guest = () => read<Guest>(K.guest, { used: 0, chat: [], labs: [] });
export const saveGuest = (g: Guest) => write(K.guest, g);
export function adoptGuest(a: Account) { const g = guest(); if (!g.chat.length && !g.labs.length) return; a.chat = [...g.chat, ...a.chat]; g.labs.forEach(l => a.labs.push({ ...l, source: 'Entered as a guest' })); a.audit.push({ at: nowIso(), what: `Guest session carried into the account (${g.labs.length} labs, ${g.chat.length} messages)` }); rawStorage.removeItem(K.guest); }
