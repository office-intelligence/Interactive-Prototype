/* React side of Vityls Core entitlements. Outside the combined Core build every module is on (identical to the
 * per-edition packages). */
import React, { useEffect, useState } from 'react';
import { ACTIVE_PRACTICE, IS_CORE_BUILD } from '../edition';
import { entitlement, practice, usable, ModState, Practice } from './practices';
import { MOD, ModuleId, TAB_MODULE } from './modules';

export function useCoreTick() { const [t, setT] = useState(0); useEffect(() => { const f = () => setT(x => x + 1); window.addEventListener('vityls-core-updated', f); return () => window.removeEventListener('vityls-core-updated', f); }, []); return t; }
export const corePractice = (): Practice | undefined => ACTIVE_PRACTICE ? practice(ACTIVE_PRACTICE.id) || ACTIVE_PRACTICE : undefined;
export function modState(m: ModuleId): ModState { const p = corePractice(); return p ? entitlement(p, m).state : 'active'; }
/** Usable: active or in trial. */
export const modOn = (m: ModuleId) => usable(modState(m));
/** Visible: usable, or expired-and-read-only. */
export function modVisible(m: ModuleId) { const s = modState(m); const p = corePractice(); return usable(s) || (s === 'expired' && p?.expired === 'read-only'); }
export const modReadOnly = (m: ModuleId) => modState(m) === 'expired' && corePractice()?.expired === 'read-only';
export const tabModule = (tab: string): ModuleId | undefined => TAB_MODULE[tab];
export const tabOn = (tab: string) => { const m = tabModule(tab); return !m || modVisible(m); };
export const isCoreBuild = IS_CORE_BUILD && !!ACTIVE_PRACTICE;
/** Locked modules surface as teasers in nav (configurable per practice). */
export const teasersInNav = () => corePractice()?.locked === 'teaser';
export const modName = (m: ModuleId) => MOD[m].name;
/** Only render children when the module is usable or read-only-visible. */
export const IfMod: React.FC<{ m: ModuleId; children: React.ReactNode }> = ({ m, children }) => { useCoreTick(); return modVisible(m) ? <>{children}</> : null; };
