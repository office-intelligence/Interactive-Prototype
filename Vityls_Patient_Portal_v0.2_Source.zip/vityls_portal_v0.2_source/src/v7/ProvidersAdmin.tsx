import { isMed } from '../edition';
import React, { useEffect, useMemo, useState } from 'react';
import { UserPlus, Pencil, ChevronRight, ShieldCheck, Mail, Send, ExternalLink, CheckCircle2, Circle, KeyRound, Unlock, UserX, UserCheck, Lock } from 'lucide-react';
import { Btn, CardTitle, DialogShell, MaskedField, fieldErrors } from './ui';
import { CRED_STEPS, Provider, contrast, normalizeHex, ProviderRole, advanceApp, displayName, getProviders, newApp, textOn, upsertProvider, searchProviders as searchProvidersSafe } from './providers';
import { OutboxEmail, PURPOSES, PURPOSE_LABEL, activeTransport, getOutbox, onboardingTrail, outboxFor, sendProviderInvitation, sendPinReset, unlockAccount, setProviderActive, practiceAudit } from './invitations';
import { MAX_PIN_FAILURES } from './providers';

const ROLES: ProviderRole[] = isMed ? ['Surgeon', 'Physician', 'Nurse practitioner', 'Physician assistant', 'Other provider'] : ['Surgeon', 'Anesthesiologist', 'CRNA', 'Other provider'];
const chip = (s: string) => s === 'Privileges approved' ? 'vy-chip-ok' : s === 'Declined' ? 'vy-chip-bad' : s === 'Queued' ? 'vy-chip-muted' : 'vy-chip-warn';
const fmt = (iso: string) => { try { return new Date(iso).toLocaleString(undefined, { month: '2-digit', day: '2-digit', year: 'numeric', hour: 'numeric', minute: '2-digit' }); } catch { return iso; } };

/** Administration → Providers (item 8). */
export const ProvidersAdmin: React.FC<{ actor?: string; practice?: string; onToast?: (m: string) => void; sub?: string }> = ({ actor = 'Practice administrator', practice, onToast, sub }) => {
  const [list, setList] = useState<Provider[]>(getProviders);
  const [outbox, setOutbox] = useState<OutboxEmail[]>(getOutbox);
  const [preview, setPreview] = useState<OutboxEmail | null>(null);
  const [account, setAccount] = useState<string | null>(null);
  useEffect(() => { const f = () => { setList(getProviders()); setOutbox(getOutbox()); }; window.addEventListener('vityls-outbox-updated', f); window.addEventListener('storage', f); return () => { window.removeEventListener('vityls-outbox-updated', f); window.removeEventListener('storage', f); }; }, []);
  const invite = (p: Provider, resend: boolean) => { try { const m = sendProviderInvitation(p.id, { by: actor, practice, resend }); setPreview(m); onToast?.(`${resend ? 'Invitation resent' : 'Invitation sent'} to ${p.email} (simulated; see Outbox).`); } catch (e: any) { onToast?.(e.message); } };
  const [edit, setEdit] = useState<Provider | 'new' | null>(null);
  const [filter, setFilter] = useState<'all' | ProviderRole>('all');
  useEffect(() => { const f = () => setList(getProviders()); window.addEventListener('vityls-providers-updated', f); return () => window.removeEventListener('vityls-providers-updated', f); }, []);
  const shown = list.filter(p => filter === 'all' || p.role === filter);
  const queue = list.filter(p => p.app.status !== 'Privileges approved' && p.app.status !== 'Declined');
  const next = (p: Provider) => { const i = CRED_STEPS.indexOf(p.app.status as any); return i >= 0 && i < CRED_STEPS.length - 1 ? CRED_STEPS[i + 1] : null; };
  return <div className="space-y-5" data-testid="providers-admin">
    <section className="vy-card p-5">
      <CardTitle kicker="Administration" title="Providers" sub={sub ?? "Surgeons, anesthesiologists and other providers. Adding a provider sends one invitation email with three links: the membership & privileges application, username and password setup, and signature PIN setup."} right={<Btn variant="add" icon={<UserPlus size={18} />} onClick={() => setEdit('new')} data-testid="add-provider">Add provider</Btn>} />
      <div className="flex flex-wrap gap-2 mt-4" role="tablist">{(['all', ...ROLES] as const).map(r => <button key={r} type="button" onClick={() => setFilter(r)} className={`vy-btn ${filter === r ? 'vy-btn-primary' : 'vy-btn-secondary'}`}>{r === 'all' ? 'All' : r === 'Other provider' ? 'Other' : r + 's'}</button>)}</div>
      <div className="overflow-x-auto mt-4"><table className="vy-table" data-testid="providers-table"><thead><tr><th>Provider</th><th>Role</th><th>Scheduler color</th><th>Onboarding</th><th>Credentialing</th><th className="text-right">Actions</th></tr></thead>
        <tbody>{shown.map(p => <tr key={p.id}><td><div className="font-semibold">{displayName(p)}</div>{(!p.active || p.locked) && <div className="flex gap-1 mt-0.5">{!p.active && <span className="vy-chip-muted" data-testid={`badge-inactive-${p.id}`}>Deactivated</span>}{p.locked && <span className="vy-chip-bad" data-testid={`badge-locked-${p.id}`}>Locked</span>}</div>}<div className="text-[13.5px] text-[#4a5750]">{p.specialty || '—'}{p.npi ? ` · NPI ${p.npi}` : ''}</div></td><td>{p.role}</td>
          <td><span className="inline-flex items-center gap-2"><span className="w-6 h-6 rounded border border-black/10" style={{ background: p.color }} aria-hidden />{p.color}</span></td>
          <td><OnboardingTrail p={p} /></td><td><span className={chip(p.app.status)}>{p.app.status}</span></td>
          <td className="text-right"><div className="flex flex-wrap justify-end gap-2">
            {outboxFor(p.id)[0] && <Btn variant="secondary" icon={<Mail size={16} />} onClick={() => setPreview(outboxFor(p.id)[0])} data-testid={`view-invite-${p.id}`}>Email</Btn>}
            {p.email && p.onboarding?.invitedAt && !(p.onboarding.applicationAt && p.onboarding.accountAt && p.onboarding.pinAt) && <Btn variant="secondary" icon={<Send size={16} />} onClick={() => invite(p, true)} data-testid={`resend-invite-${p.id}`}>Resend invitation</Btn>}
            {p.email && !p.onboarding?.invitedAt && <Btn variant="primary" icon={<Send size={16} />} onClick={() => invite(p, false)} data-testid={`send-invite-${p.id}`}>Send invitation</Btn>}
            <Btn variant="secondary" icon={<KeyRound size={16} />} onClick={() => setAccount(p.id)} data-testid={`account-${p.id}`}>Account</Btn>
            <Btn variant="edit" icon={<Pencil size={16} />} onClick={() => setEdit(p)} data-testid={`edit-provider-${p.id}`}>Edit</Btn></div></td></tr>)}</tbody></table></div>
    </section>
    <section className="vy-card p-5" data-testid="cred-queue">
      <CardTitle kicker="Credentialing" title={`Credentialing queue (${queue.length})`} sub="Adding a provider queues a membership & privileges application and invites the provider. The application moves to ‘Application received’ when they submit it from the email link. Verify credentials, then the Medical Director approves privileges. Nightingale never approves." />
      {!queue.length ? <p className="mt-3 text-[15px] text-[#4a5750]">No open applications.</p> :
        <ul className="mt-3 divide-y divide-[#e3e8e4]">{queue.map(p => { const n = next(p); return <li key={p.id} className="py-3 flex flex-wrap gap-3 items-center justify-between">
          <div><div className="font-semibold">{displayName(p)} · {p.role}</div><div className="text-[13.5px] text-[#4a5750]">{p.app.id} · opened {fmt(p.app.createdAt)} · last: {p.app.history[p.app.history.length - 1]?.status} by {p.app.history[p.app.history.length - 1]?.by}</div>
            <ol className="flex flex-wrap gap-1 mt-2">{CRED_STEPS.map((s, i) => <li key={s} className={`text-[13px] px-2 py-0.5 rounded ${CRED_STEPS.indexOf(p.app.status as any) >= i ? 'bg-[#E7F4EC] text-[#14532d]' : 'bg-[#F3F4F2] text-[#4a5750]'}`}>{i + 1}. {s}</li>)}</ol></div>
          <div className="flex gap-2">{n && <Btn variant={n === 'Privileges approved' ? 'confirm' : 'primary'} icon={n === 'Privileges approved' ? <ShieldCheck size={16} /> : <ChevronRight size={16} />} onClick={() => { advanceApp(p.id, n, n === 'Privileges approved' ? 'Medical Director (human)' : actor); onToast?.(`${displayName(p)}: ${n}`); }} data-testid={`advance-${p.id}`}>{n === 'Privileges approved' ? 'Approve privileges' : `Mark: ${n}`}</Btn>}
            <Btn variant="danger" onClick={() => advanceApp(p.id, 'Declined', actor)}>Decline</Btn></div></li>; })}</ul>}
    </section>
    <section className="vy-card p-5" data-testid="outbox">
      <CardTitle kicker={activeTransport().id === 'simulated-outbox' ? 'Simulated email · nothing leaves this device' : `Email via ${activeTransport().label}`} title={`Outbox (${outbox.length})`} sub="Every invitation email, exactly as the provider would receive it." />
      {!outbox.length ? <p className="mt-3 text-[15px] text-[#4a5750]">No emails yet. Adding a provider sends their invitation.</p> :
        <div className="overflow-x-auto mt-3"><table className="vy-table"><thead><tr><th>Sent</th><th>To</th><th>Subject</th><th className="text-right">Preview</th></tr></thead>
          <tbody>{outbox.slice(0, 12).map(m => <tr key={m.id}><td className="whitespace-nowrap">{fmt(m.sentAt)}{m.resend && <div className="text-[13px] text-[#4a5750]">Resent</div>}</td><td>{m.toName}<div className="text-[13.5px] text-[#4a5750]">{m.to}</div></td><td>{m.subject}</td>
            <td className="text-right"><Btn variant="secondary" icon={<Mail size={16} />} onClick={() => setPreview(m)} data-testid={`outbox-view-${m.id}`}>View</Btn></td></tr>)}</tbody></table></div>}
    </section>
    {edit && <ProviderDialog p={edit === 'new' ? null : edit} actor={actor} onClose={() => setEdit(null)} onResend={p => { setEdit(null); invite(p, !!p.onboarding?.invitedAt); }} onSaved={(p, isNew) => { setEdit(null); if (isNew) invite(p, false); else onToast?.(`${displayName(p)} updated.`); }} />}
    <section className="vy-card p-5" data-testid="provider-audit">
      <CardTitle kicker="Append-only" title="Provider account & credentialing audit" sub="Invitations, applications, accounts, PIN resets, lockouts, unlocks, deactivations and reactivations." />
      {(() => { const a = practiceAudit().slice().reverse().slice(0, 15); return !a.length ? <p className="mt-3 text-[15px] text-[#4a5750]">No provider account events yet.</p> :
        <ul className="mt-3 divide-y divide-[#e3e8e4] text-[14.5px]">{a.map(e => <li key={e.id} className="py-2 flex flex-wrap gap-x-3"><span className="text-[#4a5750] whitespace-nowrap">{fmt(e.at)}</span><span className="font-semibold">{e.action.replace('provider.', '')}</span><span>{e.detail}</span><span className="text-[#4a5750]">· {e.user} ({e.role})</span></li>)}</ul>; })()}
    </section>
    {account && <AccountDialog id={account} actor={actor} practice={practice} onClose={() => setAccount(null)} onEmail={m => { setAccount(null); setPreview(m); }} onToast={onToast} />}
    {preview && <EmailPreview m={preview} onClose={() => setPreview(null)} />}
  </div>;
};

export const ProviderDialog: React.FC<{ p: Provider | null; actor: string; onClose: () => void; onSaved: (p: Provider, isNew: boolean) => void; onResend?: (p: Provider) => void }> = ({ p, actor, onClose, onSaved, onResend }) => {
  const [f, setF] = useState({ firstName: p?.firstName || '', lastName: p?.lastName || '', degree: p?.degree || '', role: (p?.role || '') as ProviderRole | '', specialty: p?.specialty || '', npi: p?.npi || '', email: p?.email || '', phone: p?.phone || '', color: p?.color || '', active: p?.active ?? true });
  const [tried, setTried] = useState(false);
  const set = (k: keyof typeof f, v: any) => setF(x => ({ ...x, [k]: v }));
  const errs = useMemo(() => {
    const e: string[] = [];
    if (!f.firstName.trim()) e.push('First name is required'); if (!f.lastName.trim()) e.push('Last name is required'); if (!f.role) e.push('Role is required');
    if (!f.color) e.push('Choose a scheduler color'); else if (!normalizeHex(f.color)) e.push('Scheduler color must be a hex value like #1f6e52');
    if (!p && !f.email.trim()) e.push('Email is required: the invitation is sent there');
    if (f.npi && !/^\d{10}$/.test(f.npi)) e.push('NPI must be 10 digits');
    return [...e, ...fieldErrors([{ kind: 'email', value: f.email }, { kind: 'phone', value: f.phone }])];
  }, [f, p]);
  const save = (e?: React.FormEvent) => { e?.preventDefault(); setTried(true); if (errs.length) return;
    const out: Provider = { ...(p || {} as Provider), id: p?.id || `prov-${Date.now().toString(36)}`, ...f, active: p ? p.active : true, color: normalizeHex(f.color) || f.color, role: f.role as ProviderRole, pinHash: p?.pinHash || '', app: p?.app || newApp(actor), onboarding: p?.onboarding || {} };
    upsertProvider(out); onSaved(out, !p); };
  return <DialogShell as="form" onSubmit={save} size="lg" testId="provider-dialog" kicker="Providers" title={p ? `Edit ${displayName(p)}` : 'Add provider'} subtitle={p ? undefined : 'Saving queues a membership & privileges application and sends ONE invitation email (simulated) with three links: application, username & password, signature PIN.'} onClose={onClose}
    footer={<><Btn variant="secondary" onClick={onClose}>Cancel</Btn><Btn type="submit" variant={p ? 'confirm' : 'add'} data-testid="save-provider">{p ? 'Save changes' : 'Add provider & send invitation'}</Btn></>}>
    <div className="grid sm:grid-cols-3 gap-3">
      <label className="vy-label">First name *<input className="vy-input" value={f.firstName} onChange={e => set('firstName', e.target.value)} data-testid="pv-first" autoComplete="off" /></label>
      <label className="vy-label">Last name *<input className="vy-input" value={f.lastName} onChange={e => set('lastName', e.target.value)} data-testid="pv-last" autoComplete="off" /></label>
      <label className="vy-label">Degree<input className="vy-input" value={f.degree} onChange={e => set('degree', e.target.value)} placeholder="MD, DO, CRNA" /></label>
      <label className="vy-label">Role *<select className="vy-input" value={f.role} onChange={e => set('role', e.target.value)} data-testid="pv-role"><option value="">Select…</option>{ROLES.map(r => <option key={r}>{r}</option>)}</select></label>
      <label className="vy-label">Specialty<input className="vy-input" value={f.specialty} onChange={e => set('specialty', e.target.value)} /></label>
      <label className="vy-label">NPI<input className="vy-input" value={f.npi} inputMode="numeric" maxLength={10} onChange={e => set('npi', e.target.value.replace(/\D/g, ''))} placeholder="10 digits" /></label>
 <MaskedField label={p ? 'Email' : 'Email *'} kind="email" value={f.email} onChange={v => set('email', v)} showErrors={tried} />
      <MaskedField label="Phone" kind="phone" value={f.phone} onChange={v => set('phone', v)} showErrors={tried} />
    </div>
    <fieldset className="mt-4" data-testid="pv-color"><legend className="vy-label">Scheduler color * <span className="font-normal">(appointments for this provider use it; any color)</span></legend>
      <div className="flex flex-wrap items-center gap-3 mt-2">
        <input type="color" aria-label="Pick scheduler color" className="w-14 h-11 rounded-lg border border-[#c4cfc8] bg-white p-1 cursor-pointer" value={normalizeHex(f.color) || '#1f6e52'} onChange={e => set('color', e.target.value)} data-testid="pv-color-picker" />
        <label className="vy-label !mb-0 flex items-center gap-2">Hex<input className="vy-input w-32 font-mono" value={f.color} placeholder="#1f6e52" maxLength={7} onChange={e => set('color', e.target.value.trim())} onBlur={() => { const n = normalizeHex(f.color); if (n) set('color', n); }} data-testid="pv-color-hex" /></label>
        {normalizeHex(f.color) && <span className="px-3 py-2 rounded-lg text-[14px] font-semibold" style={{ background: normalizeHex(f.color)!, color: textOn(f.color) }} data-testid="pv-color-sample">Sample appointment · {textOn(f.color) === '#ffffff' ? 'light' : 'dark'} text · {contrast(f.color, textOn(f.color)).toFixed(1)}:1</span>}
      </div>
      <p className="text-[13.5px] text-[#4a5750] mt-1">Text on the appointment switches between light and dark automatically to stay readable (AA, at least 4.5:1).</p></fieldset>
    <div className="mt-4 p-3 rounded-lg bg-[#F3F6F4] border border-[#dfe6e1] text-[14.5px]" data-testid="pv-pin-note"><b className="font-semibold">Signature PIN:</b> {p?.pinHash ? `set by the provider${p.onboarding?.pinAt ? ` on ${fmt(p.onboarding.pinAt)}` : ''}.` : 'the provider creates it from the PIN link in their invitation email. Administrators never see or set PINs.'}</div>
    {p && <div className="mt-3"><div className="vy-label">Onboarding</div><div className="mt-1 flex flex-wrap items-center gap-3"><OnboardingTrail p={p} wide />{p.email && onResend && !(p.onboarding?.applicationAt && p.onboarding?.accountAt && p.onboarding?.pinAt) && <Btn variant="secondary" icon={<Send size={16} />} onClick={() => onResend(p)} data-testid="pv-resend">{p.onboarding?.invitedAt ? 'Resend invitation' : 'Send invitation'}</Btn>}</div></div>}
    {p && <p className="mt-3 text-[14px] text-[#4a5750]">Status: <b className="font-semibold">{p.active ? 'Active' : 'Deactivated'}</b>{p.locked ? ' · Locked' : ''}. Reset PIN, unlock and deactivate are under <b className="font-semibold">Account</b> on the provider row.</p>}
    {p && <div className="mt-4"><div className="vy-label">Credentialing history ({p.app.id})</div><ul className="mt-1 text-[14px] space-y-0.5">{p.app.history.map((h, i) => <li key={i}>{fmt(h.at)} · <b className="font-semibold">{h.status}</b> · {h.by}{h.note ? ` · ${h.note}` : ''}</li>)}</ul></div>}
    {tried && errs.length > 0 && <div className="mt-4 p-3 rounded-lg bg-[#FDECEC] border border-[#f1b9b9] text-[#7f1d1d] text-[15px]" role="alert" data-testid="pv-errors"><b>Please fix:</b><ul className="list-disc ml-5">{errs.map(e => <li key={e}>{e}</li>)}</ul></div>}
  </DialogShell>;
};

/** v7.4 Account actions: Reset PIN (emails a reset link via the outbox), Unlock, Deactivate / Reactivate (confirmed). */
export const AccountDialog: React.FC<{ id: string; actor: string; practice?: string; onClose: () => void; onEmail: (m: OutboxEmail) => void; onToast?: (m: string) => void }> = ({ id, actor, practice, onClose, onEmail, onToast }) => {
  const [, tick] = useState(0); useEffect(() => { const f = () => tick(x => x + 1); window.addEventListener('vityls-providers-updated', f); return () => window.removeEventListener('vityls-providers-updated', f); }, []);
  const p = getProviders().find(x => x.id === id); const [confirm, setConfirm] = useState(false); const [reason, setReason] = useState('');
  if (!p) return null;
  const row = (k: string, v: React.ReactNode) => <div className="flex justify-between gap-3 py-2 border-b border-[#e3e8e4] text-[15px]"><span className="text-[#4a5750]">{k}</span><span className="font-semibold text-right">{v}</span></div>;
  return <DialogShell size="md" testId="account-dialog" kicker="Provider account" title={displayName(p)} icon={<KeyRound size={20} />} onClose={onClose}
    footer={confirm ? <><Btn variant="secondary" onClick={() => setConfirm(false)}>Keep active</Btn><Btn variant="danger" icon={<UserX size={16} />} onClick={() => { setProviderActive(p.id, false, actor, reason.trim() || undefined); setConfirm(false); onToast?.(`${displayName(p)} deactivated.`); }} data-testid="confirm-deactivate">Deactivate account</Btn></> : <Btn variant="primary" onClick={onClose} data-testid="close-account">Done</Btn>}>
    {row('Status', p.active ? <span className="vy-chip-ok">Active</span> : <span className="vy-chip-muted" data-testid="acct-status-inactive">Deactivated{p.deactivatedAt ? ` · ${fmt(p.deactivatedAt)}` : ''}</span>)}
    {row('Sign-in', p.locked ? <span className="vy-chip-bad" data-testid="acct-locked">Locked{p.lockedAt ? ` · ${fmt(p.lockedAt)}` : ''}</span> : <span>Unlocked{p.pinFailures ? ` · ${p.pinFailures} of ${MAX_PIN_FAILURES} wrong PINs` : ''}</span>)}
    {row('Signature PIN', p.pinHash ? 'Set by the provider' : 'Not set (provider creates it from an emailed link)')}
    {row('Username', p.onboarding?.username || '—')}
    {confirm ? <div className="mt-4 p-4 rounded-lg bg-[#FDECEC] border border-[#f1b9b9] text-[#5c1717]" data-testid="deactivate-confirm"><b>Deactivate {displayName(p)}?</b><p className="text-[15px] mt-1">They will not be able to sign, and the Scheduler will not offer or accept them for new appointments. Their records stay in history. You can reactivate later.</p>
        <label className="vy-label mt-3 text-[#33423a]">Reason (optional, saved in the audit log)<input className="vy-input" value={reason} onChange={e => setReason(e.target.value)} data-testid="deactivate-reason" /></label></div>
      : <div className="mt-4 flex flex-wrap gap-2">
        <Btn variant="secondary" icon={<KeyRound size={16} />} disabled={!p.email || !p.onboarding?.accountAt} title={!p.onboarding?.accountAt ? 'The provider has not created an account yet' : undefined} onClick={() => { try { const m = sendPinReset(p.id, { by: actor, practice }); onToast?.(`PIN reset link sent to ${p.email} (simulated; see Outbox).`); onEmail(m); } catch (e: any) { onToast?.(e.message); } }} data-testid="reset-pin">Reset PIN</Btn>
        {p.locked && <Btn variant="confirm" icon={<Unlock size={16} />} onClick={() => { unlockAccount(p.id, actor); onToast?.(`${displayName(p)} unlocked.`); }} data-testid="unlock-account">Unlock account</Btn>}
        {p.active ? <Btn variant="danger" icon={<UserX size={16} />} onClick={() => setConfirm(true)} data-testid="deactivate-account">Deactivate account</Btn>
          : <Btn variant="confirm" icon={<UserCheck size={16} />} onClick={() => { setProviderActive(p.id, true, actor); onToast?.(`${displayName(p)} reactivated.`); }} data-testid="reactivate-account">Reactivate account</Btn>}
      </div>}
    <p className="mt-3 text-[13.5px] text-[#4a5750] flex items-center gap-1.5"><Lock size={14} aria-hidden />Every action here is written to the audit log and the credentialing history.</p>
  </DialogShell>;
};

/** Invited / Application received / Account created / PIN set. */
export const OnboardingTrail: React.FC<{ p: Provider; wide?: boolean }> = ({ p, wide }) => <ol className={`flex ${wide ? 'flex-wrap gap-2' : 'flex-col gap-0.5'}`} data-testid={`onboarding-${p.id}`}>
  {onboardingTrail(p).map(s => <li key={s.label} className={`flex items-center gap-1.5 text-[13.5px] ${s.at ? 'text-[#14532d]' : 'text-[#4a5750]'}`} data-done={s.at ? 'yes' : 'no'} title={s.at ? fmt(s.at) : 'Not yet'}>{s.at ? <CheckCircle2 size={15} className="shrink-0" aria-hidden /> : <Circle size={15} className="shrink-0" aria-hidden />}{s.label}</li>)}</ol>;

/** Simulated email preview: the full message as the provider would receive it. */
export const EmailPreview: React.FC<{ m: OutboxEmail; onClose: () => void }> = ({ m, onClose }) => {
  const parts = m.body.split(/(\S+#invite=\S+|https?:\/\/\S+\/invite\/\S+)/g);
  const purposeOf = (u: string) => PURPOSES.find(x => m.links[x] === u);
  return <DialogShell size="xl" testId="email-preview" kicker={activeTransport().id === 'simulated-outbox' ? 'Simulated email · not delivered' : 'Email'} title={m.kind === 'pin-reset' ? 'PIN reset email' : 'Invitation email'} icon={<Mail size={20} />} onClose={onClose}
    footer={<><span className="text-[13.5px] text-[#4a5750]">Evaluation build: the email is shown here instead of being delivered.</span><Btn variant="primary" onClick={onClose} data-testid="close-email-preview">Close</Btn></>}>
    <dl className="grid grid-cols-[90px_1fr] gap-x-3 gap-y-1 text-[15px]">
      <dt className="text-[#4a5750]">From</dt><dd>{m.from}</dd><dt className="text-[#4a5750]">To</dt><dd data-testid="email-to">{m.toName} &lt;{m.to}&gt;</dd>
      <dt className="text-[#4a5750]">Subject</dt><dd className="font-semibold" data-testid="email-subject">{m.subject}</dd><dt className="text-[#4a5750]">Sent</dt><dd>{fmt(m.sentAt)} · by {m.sentBy}{m.resend ? ' · resent (earlier links revoked)' : ''}</dd>
    </dl>
    <div className="mt-4 p-4 rounded-lg border border-[#d4ddd7] bg-white text-[15px] leading-relaxed whitespace-pre-wrap break-words" data-testid="email-body">{parts.map((t, i) => { const pu = purposeOf(t); return pu ? <a key={i} href={t} target="_blank" rel="noopener" className="text-[#1D4ED8] underline" data-testid={`email-link-${pu}`}>{t}</a> : <React.Fragment key={i}>{t}</React.Fragment>; })}</div>
    <div className="mt-3 flex flex-wrap gap-2">{PURPOSES.filter(x => m.links[x]).map((x, i) => <a key={x} href={m.links[x]} target="_blank" rel="noopener" className="vy-btn vy-btn-secondary" data-testid={`open-link-${x}`}><ExternalLink size={16} />{i + 1}. {PURPOSE_LABEL[x]}</a>)}</div>
    <p className="mt-2 text-[13.5px] text-[#4a5750]">Links open in a new tab and work in this local build. Each link works once and expires on {new Date(m.expiresAt).toLocaleDateString()}.</p>
  </DialogShell>;
};

/** Typeahead used by the Scheduler for surgeon / anesthesiologist (same pattern as its patient picker: matches after 3 characters). */
export const ProviderTypeahead: React.FC<{ label: string; value: string; roles: ProviderRole[]; onChange: (v: string) => void; testId: string; placeholder?: string }> = ({ label, value, roles, onChange, testId, placeholder }) => {
  const [open, setOpen] = useState(false);
  const matches = useMemo(() => open ? searchProvidersSafe(value, roles) : [], [value, roles, open]);
  return <div className="relative">
    <label className="block text-[13px] font-semibold text-slate-700 uppercase tracking-wide mb-1">{label}</label>
    <input type="text" value={value} autoComplete="off" data-testid={testId} placeholder={placeholder || 'Type 3+ letters of the name'}
      onChange={e => { onChange(e.target.value); setOpen(e.target.value.trim().length >= 3); }} onFocus={() => setOpen(value.trim().length >= 3)} onBlur={() => setTimeout(() => setOpen(false), 150)}
      className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-[14px] text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-indigo-500 focus:bg-white min-h-[44px]" />
    {open && value.trim().length >= 3 && <div className="absolute left-0 top-full mt-1.5 w-[300px] bg-white rounded-xl border border-indigo-200 shadow-2xl z-50 p-2 max-h-64 overflow-y-auto" data-testid={`${testId}-matches`}>
      <div className="px-2.5 py-1.5 text-[13px] font-semibold text-indigo-900 bg-indigo-50 rounded-lg mb-1.5">Matching {roles[0] === 'Surgeon' ? 'surgeons' : 'anesthesia providers'} ({matches.length})</div>
      {!matches.length ? <div className="p-3 text-[14px] text-slate-600">No match for “{value}”. Add providers in Practice → Administration → Providers.</div> :
        matches.map(p => <button key={p.id} type="button" onMouseDown={e => e.preventDefault()} onClick={() => { onChange(displayName(p)); setOpen(false); }} className="w-full text-left p-2.5 hover:bg-indigo-50 rounded-lg flex items-center gap-2 min-h-[44px]">
          <span className="w-4 h-4 rounded" style={{ background: p.color }} aria-hidden /><span className="text-[14px] font-semibold text-slate-900">{displayName(p)}</span><span className="text-[13px] text-slate-600">{p.role}{p.specialty ? ` · ${p.specialty}` : ''}</span></button>)}
    </div>}
  </div>;
};
