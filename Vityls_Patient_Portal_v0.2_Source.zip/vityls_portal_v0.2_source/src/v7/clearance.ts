/*
 * v7 item 11: pre-op clearance files, Nightingale review summary and human clearance.
 * Summaries go through a pluggable adapter. With no AI key the local rule-based summarizer runs and is
 * labelled as such. Nightingale never signs or clears: review confirmation and clearance need a named person.
 */
import type { PatientCase } from '../types';
import { allergyState } from './allergy';
import { repo } from '../v6/dataLayer';

export const DOC_TYPES = ['History & Physical (H&P)', 'Labs', 'ECG / EKG', 'Imaging', 'Consult / clearance letter', 'Medication list', 'Other record'] as const;
export type DocType = typeof DOC_TYPES[number];
export interface ClearanceDoc { id: string; caseId: string; type: DocType; title: string; source: string; docDate: string; receivedAt: string; receivedBy: string; fileName?: string; mime?: string; dataUrl?: string; text: string; status: 'Received' | 'Reviewed' }
export interface Finding { text: string; doc?: string; severity: 'info' | 'attention' | 'critical' }
export interface ClearanceSummary { engine: string; engineKind: 'rule-based' | 'ai'; generatedAt: string; narrative: string[]; history: Finding[]; allergies: Finding[]; abnormal: Finding[]; missing: Finding[]; concerns: Finding[]; docsReviewed: string[] }
export interface ClearanceState { review?: { by: string; at: string; note?: string }; cleared?: { by: string; at: string; note?: string }; summary?: ClearanceSummary }

const kDocs = (c: string) => `vityls:v7:clearance-docs:${c}`; const kState = (c: string) => `vityls:v7:clearance-state:${c}`;
const read = <T,>(k: string, f: T): T => { try { const r = localStorage.getItem(k); return r ? JSON.parse(r) : f; } catch { return f; } };
const write = (k: string, v: unknown) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { throw new Error('Browser storage is full; attach smaller files.'); } };
const ping = () => { try { window.dispatchEvent(new Event('vityls-clearance-updated')); } catch { /* */ } };
export const getDocs = (caseId: string) => read<ClearanceDoc[]>(kDocs(caseId), []);
export function addDoc(d: ClearanceDoc) { write(kDocs(d.caseId), [...getDocs(d.caseId), d]); repo.audit({ caseId: d.caseId, user: d.receivedBy, role: 'Staff', action: 'form.save', detail: `Clearance document received: ${d.type} · ${d.title}` }); ping(); }
export function removeDoc(caseId: string, id: string, by: string) { const d = getDocs(caseId); write(kDocs(caseId), d.filter(x => x.id !== id)); repo.audit({ caseId, user: by, role: 'Staff', action: 'form.save', detail: `Clearance document removed: ${d.find(x => x.id === id)?.title}` }); ping(); }
export const getState = (caseId: string) => read<ClearanceState>(kState(caseId), {});
export function setState(caseId: string, s: ClearanceState) { write(kState(caseId), s); ping(); }
const human = (by: string) => { if (!by.trim() || /nightingale|\bai\b/i.test(by)) throw new Error('A named person must confirm. Nightingale cannot review-confirm or clear a patient.'); };
export function confirmReview(caseId: string, by: string, note?: string) { human(by); const s = getState(caseId); setState(caseId, { ...s, review: { by, at: new Date().toISOString(), note } }); getDocs(caseId).length && write(kDocs(caseId), getDocs(caseId).map(d => ({ ...d, status: 'Reviewed' }))); repo.audit({ caseId, user: by, role: 'Clinician', action: 'station.verify', detail: 'Clearance documents reviewed (human confirmation of Nightingale summary)' }); ping(); }
export function markCleared(caseId: string, by: string, note?: string) { human(by); const s = getState(caseId); if (!s.review) throw new Error('Confirm the document review first.'); setState(caseId, { ...s, cleared: { by, at: new Date().toISOString(), note } }); repo.audit({ caseId, user: by, role: 'Clinician', action: 'station.verify', detail: `Cleared for surgery${note ? `: ${note}` : ''}` }); }
export function undoCleared(caseId: string, by: string) { const s = getState(caseId); setState(caseId, { ...s, cleared: undefined }); repo.audit({ caseId, user: by, role: 'Clinician', action: 'station.verify', detail: 'Clearance withdrawn' }); }

/* ---------- pluggable summarizer adapter ---------- */
export interface SummarizerAdapter { id: string; label: string; kind: 'rule-based' | 'ai'; available: () => boolean; summarize: (p: PatientCase, docs: ClearanceDoc[]) => Promise<ClearanceSummary> }
const adapters: SummarizerAdapter[] = [];
/** Register an AI adapter (e.g. a backend proxy that holds the key). It is used only when available() is true. */
export const registerSummarizer = (a: SummarizerAdapter) => { adapters.unshift(a); };
export const activeSummarizer = (): SummarizerAdapter => adapters.find(a => a.kind === 'ai' && a.available()) || RULE_BASED;

/* ---------- local rule-based summarizer ---------- */
const HISTORY: [RegExp, string, Finding['severity']][] = [
  [/\b(hypertension|htn)\b/i, 'Hypertension', 'info'], [/\b(diabetes|dm2?|t2dm|type 2 diabetes)\b/i, 'Diabetes', 'attention'],
  [/\b(cad|coronary artery disease|myocardial infarction|\bmi\b|stent|cabg)\b/i, 'Coronary artery disease / prior MI or stent', 'attention'],
  [/\b(chf|heart failure|reduced ejection|ef\s*(<|of)?\s*[1-3]\d\s*%)/i, 'Heart failure / reduced ejection fraction', 'attention'],
  [/\b(atrial fibrillation|a-?fib)\b/i, 'Atrial fibrillation', 'attention'], [/\b(copd|emphysema)\b/i, 'COPD', 'attention'], [/\basthma\b/i, 'Asthma', 'info'],
  [/\b(osa|obstructive sleep apnea|sleep apnea|cpap)\b/i, 'Obstructive sleep apnea', 'attention'], [/\b(ckd|chronic kidney|renal insufficiency|dialysis)\b/i, 'Chronic kidney disease', 'attention'],
  [/\b(stroke|cva|tia)\b/i, 'Prior stroke / TIA', 'attention'], [/\b(seizure|epilepsy)\b/i, 'Seizure disorder', 'info'], [/\b(hypothyroid|hyperthyroid|thyroid)\b/i, 'Thyroid disease', 'info'],
  [/\b(malignant hyperthermia)\b/i, 'Malignant hyperthermia (personal or family)', 'critical'], [/\b(difficult airway|difficult intubation)\b/i, 'Difficult airway history', 'critical'],
  [/\b(ponv|postoperative nausea)\b/i, 'Prior PONV', 'info'], [/\b(current smoker|smokes|tobacco use|pack[- ]?years?)\b/i, 'Tobacco use', 'info'], [/\bpregnan/i, 'Pregnancy mentioned', 'attention'],
];
export const MEDS: [RegExp, string][] = [
  [/\b(warfarin|coumadin|apixaban|eliquis|rivaroxaban|xarelto|dabigatran|pradaxa|enoxaparin|lovenox)\b/i, 'Anticoagulant'], [/\b(clopidogrel|plavix|prasugrel|ticagrelor|brilinta)\b/i, 'Antiplatelet (P2Y12)'],
  [/\b(semaglutide|ozempic|wegovy|tirzepatide|mounjaro|zepbound|liraglutide|victoza|saxenda|dulaglutide|trulicity)\b/i, 'GLP-1 receptor agonist'], [/\b(insulin)\b/i, 'Insulin'],
  [/\b(empagliflozin|jardiance|dapagliflozin|farxiga|canagliflozin|invokana)\b/i, 'SGLT2 inhibitor'],
];
/** Reference ranges for common pre-op labs (adult; flags only, not diagnoses). */
const LABS: { re: RegExp; name: string; lo?: number; hi?: number; critLo?: number; critHi?: number; unit: string }[] = [
  { re: /\b(hgb|hemoglobin)\b\s*(?:level|,?\s*serum)?\s*[:=]?\s*(\d+(\.\d+)?)/i, name: 'Hemoglobin', lo: 12, hi: 17.5, critLo: 8, unit: 'g/dL' },
  { re: /\b(hct|hematocrit)\b\s*(?:level|,?\s*serum)?\s*[:=]?\s*(\d+(\.\d+)?)/i, name: 'Hematocrit', lo: 36, hi: 52, unit: '%' },
  { re: /\b(wbc|white blood cell)s?\b\s*(?:level|,?\s*serum)?\s*[:=]?\s*(\d+(\.\d+)?)/i, name: 'WBC', lo: 4, hi: 11, critHi: 20, unit: 'K/µL' },
  { re: /\b(plt|platelets?)\b\s*(?:level|,?\s*serum)?\s*[:=]?\s*(\d+(\.\d+)?)/i, name: 'Platelets', lo: 150, hi: 400, critLo: 50, unit: 'K/µL' },
  { re: /\b(na|sodium)\b\s*(?:level|,?\s*serum)?\s*[:=]?\s*(\d+(\.\d+)?)/i, name: 'Sodium', lo: 135, hi: 145, critLo: 125, critHi: 155, unit: 'mmol/L' },
  { re: /\b(k|potassium)\b\s*(?:level|,?\s*serum)?\s*[:=]?\s*(\d+(\.\d+)?)/i, name: 'Potassium', lo: 3.5, hi: 5.1, critLo: 3.0, critHi: 6.0, unit: 'mmol/L' },
  { re: /\b(cr|creatinine)\b\s*(?:level|,?\s*serum)?\s*[:=]?\s*(\d+(\.\d+)?)/i, name: 'Creatinine', lo: 0.6, hi: 1.3, critHi: 3, unit: 'mg/dL' },
  { re: /\b(bun)\b\s*(?:level|,?\s*serum)?\s*[:=]?\s*(\d+(\.\d+)?)/i, name: 'BUN', lo: 7, hi: 20, unit: 'mg/dL' },
  { re: /\b(glucose|glu)\b\s*(?:level|,?\s*serum)?\s*[:=]?\s*(\d+(\.\d+)?)/i, name: 'Glucose', lo: 70, hi: 140, critLo: 50, critHi: 300, unit: 'mg/dL' },
  { re: /\b(hba1c|a1c|hemoglobin a1c)\b\s*(?:level|,?\s*serum)?\s*[:=]?\s*(\d+(\.\d+)?)/i, name: 'HbA1c', hi: 6.4, critHi: 8.5, unit: '%' },
  { re: /\b(inr)\b\s*(?:level|,?\s*serum)?\s*[:=]?\s*(\d+(\.\d+)?)/i, name: 'INR', hi: 1.2, critHi: 1.6, unit: '' },
  { re: /\b(ptt|aptt)\b\s*(?:level|,?\s*serum)?\s*[:=]?\s*(\d+(\.\d+)?)/i, name: 'PTT', lo: 25, hi: 38, unit: 's' },
];
const ECG_FLAGS: [RegExp, string, Finding['severity']][] = [
  [/atrial fibrillation|a-?fib/i, 'ECG: atrial fibrillation', 'attention'], [/st[- ]?(segment )?(elevation|depression)/i, 'ECG: ST-segment changes', 'critical'],
  [/\b(lbbb|left bundle branch block)\b/i, 'ECG: left bundle branch block', 'attention'], [/\b(rbbb|right bundle branch block)\b/i, 'ECG: right bundle branch block', 'info'],
  [/\bq waves?\b/i, 'ECG: Q waves', 'attention'], [/\b(av block|heart block|second degree|third degree)\b/i, 'ECG: AV block', 'attention'], [/\babnormal (ecg|ekg)\b/i, 'ECG read as abnormal', 'attention'],
];
const daysSince = (us: string) => { const m = us.match(/^(\d{2})\/(\d{2})\/(\d{4})$/); if (!m) return null; return Math.floor((Date.now() - new Date(+m[3], +m[1] - 1, +m[2]).getTime()) / 864e5); };
const uniq = (f: Finding[]) => f.filter((x, i) => f.findIndex(y => y.text === x.text) === i);
export const RULE_BASED: SummarizerAdapter = {
  id: 'local-rules', label: 'Rule-based summary (no AI key) — local keyword and reference-range rules', kind: 'rule-based', available: () => true,
  async summarize(p, docs) {
    const history: Finding[] = [], abnormal: Finding[] = [], missing: Finding[] = [], concerns: Finding[] = [], allergies: Finding[] = [];
    for (const d of docs) {
      const t = d.text || ''; const ref = `${d.type}${d.docDate ? `, ${d.docDate}` : ''}`;
      HISTORY.forEach(([re, label, sev]) => { if (re.test(t) && !new RegExp(`(no|denies|negative for)\\s+(history of\\s+)?(?:${re.source.replace(/^\\b\(|\)\\b$/g, '')})`, 'i').test(t)) history.push({ text: label, doc: ref, severity: sev }); });
      MEDS.forEach(([re, label]) => { const m = t.match(re); if (m) concerns.push({ text: `${label} on medication list (${m[0]}): confirm hold/continue instructions with the surgeon and anesthesia`, doc: ref, severity: 'attention' }); });
      if (/lab/i.test(d.type) || /cbc|bmp|cmp|panel/i.test(t)) LABS.forEach(l => { const m = t.match(l.re); if (!m) return; const v = parseFloat(m[2]); if (isNaN(v)) return;
        const crit = (l.critLo != null && v < l.critLo) || (l.critHi != null && v > l.critHi); const ab = crit || (l.lo != null && v < l.lo) || (l.hi != null && v > l.hi);
        if (ab) abnormal.push({ text: `${l.name} ${v}${l.unit ? ' ' + l.unit : ''} (${l.lo != null && v < l.lo ? 'low' : 'high'}; reference ${l.lo != null ? `${l.lo}–${l.hi}` : `≤ ${l.hi}`})`, doc: ref, severity: crit ? 'critical' : 'attention' }); });
      if (/ecg|ekg/i.test(d.type)) { let any = false; ECG_FLAGS.forEach(([re, label, sev]) => { if (re.test(t)) { abnormal.push({ text: label, doc: ref, severity: sev }); any = true; } }); const q = t.match(/qtc[^\d]{0,8}(\d{3})/i); if (q && +q[1] > 470) { abnormal.push({ text: `ECG: prolonged QTc ${q[1]} ms`, doc: ref, severity: 'attention' }); any = true; } }
      const al = t.match(/allerg(?:y|ies)\s*[:\-]\s*([^\n.]+)/i); if (al) allergies.push({ text: `Document lists: ${al[1].trim()}`, doc: ref, severity: /nkda|no known/i.test(al[1]) ? 'info' : 'attention' });
      if (/\b(abnormal|critical|positive|elevated)\b/i.test(t) && /lab/i.test(d.type) && !abnormal.some(a => a.doc === ref)) abnormal.push({ text: 'Lab report contains the words abnormal/critical/elevated: read the original', doc: ref, severity: 'attention' });
      if (d.type === 'History & Physical (H&P)') { const n = daysSince(d.docDate); if (n != null && n > 30) concerns.push({ text: `H&P is ${n} days old (older than 30 days): an update may be required`, doc: ref, severity: 'attention' }); }
      if (!t.trim()) concerns.push({ text: `No readable text for “${d.title}”: open the original (scanned file or image)`, doc: ref, severity: 'info' });
    }
    const st = allergyState(p.allergies).state;
    allergies.unshift({ text: st === 'nkda' ? 'Chart: NKDA recorded' : st === 'not-reported' ? 'Chart: allergy status not reported' : `Chart: ${(p.allergies || []).join(', ')}`, severity: st === 'not-reported' ? 'attention' : st === 'allergies' ? 'attention' : 'info' });
    const docAllergyText = allergies.slice(1).map(a => a.text.toLowerCase()).join(' ');
    if (st === 'nkda' && docAllergyText && !/nkda|no known/.test(docAllergyText)) concerns.push({ text: 'Chart says NKDA but a clearance document lists allergies: reconcile', severity: 'critical' });
    const has = (t: DocType) => docs.some(d => d.type === t);
    const age = Number(p.age) || 0; const cardiac = history.some(h => /coronary|heart failure|atrial|stroke/i.test(h.text));
    if (!has('History & Physical (H&P)')) missing.push({ text: 'History & Physical (H&P)', severity: 'attention' });
    if ((age >= 50 || cardiac) && !has('ECG / EKG')) missing.push({ text: `ECG (practice rule: age ≥ 50 or cardiac history${age ? `; patient is ${age}` : ''})`, severity: 'attention' });
    if ((age >= 50 || history.length > 0) && !has('Labs')) missing.push({ text: 'Pre-op labs (practice rule: age ≥ 50 or significant history)', severity: 'attention' });
    if (cardiac && !has('Consult / clearance letter')) missing.push({ text: 'Cardiology clearance letter (cardiac history found)', severity: 'attention' });
    if (st === 'not-reported') missing.push({ text: 'Allergy status (record allergies or NKDA)', severity: 'attention' });
    if (/female/i.test(p.gender || '') && age >= 12 && age <= 50 && !docs.some(d => /hcg|pregnan/i.test(d.text))) missing.push({ text: 'Pregnancy test result (practice rule: female 12–50)', severity: 'info' });
    if (!docs.length) missing.unshift({ text: 'No clearance documents received yet', severity: 'attention' });
    const H = uniq(history), A = uniq(abnormal), C = uniq(concerns), M = uniq(missing), AL = uniq(allergies);
    const list = (f: Finding[]) => f.map(x => x.text.replace(/^ECG: /, '')).join('; ');
    const narrative = [
      `${p.name}${age ? `, a ${age}-year-old${p.gender ? ` ${String(p.gender).toLowerCase()}` : ''},` : ''} is booked for ${p.procedure || 'a procedure'}${p.appointmentDate ? ` on ${p.appointmentDate}` : ''}${p.surgeon ? ` with ${p.surgeon}` : ''}. ${docs.length ? `${docs.length} clearance document${docs.length > 1 ? 's were' : ' was'} reviewed: ${docs.map(d => `${d.type}${d.docDate ? ` (${d.docDate})` : ''}`).join(', ')}.` : 'No clearance documents have been received.'}`,
      H.length ? `Significant history found in the records: ${list(H)}.` : docs.length ? 'No significant history terms were found in the readable text.' : '',
      `Allergies: ${list(AL)}.`,
      A.length ? `Abnormal findings: ${list(A)}.` : docs.some(d => /lab|ecg/i.test(d.type)) ? 'No abnormal lab values or ECG findings were detected by the rules.' : '',
      M.length ? `Missing information: ${list(M)}.` : 'No required items appear to be missing under the current practice rules.',
      C.length ? `Other clearance concerns: ${list(C)}.` : '',
      'This is a draft for a clinician. It was produced on this device by keyword and reference-range rules from the document text listed above; it can miss findings in scanned images or unusual wording. Read the originals before confirming. Nightingale does not sign or clear patients.',
    ].filter(Boolean);
    return { engine: this.label, engineKind: 'rule-based', generatedAt: new Date().toISOString(), narrative, history: H, allergies: AL, abnormal: A, missing: M, concerns: C, docsReviewed: docs.map(d => d.id) };
  },
};

/** Fictional clearance documents seeded for Demo Patient-Two so the review can be tried immediately. */
export function seedClearanceDocs(caseId: string, us: string) {
  if (getDocs(caseId).length) return;
  const base = { caseId, source: 'Fictional test clinic', docDate: us, receivedAt: new Date().toISOString(), receivedBy: 'Seed data', status: 'Received' as const };
  write(kDocs(caseId), [
    { ...base, id: 'seed-hp', type: 'History & Physical (H&P)', title: '[Fictional] H&P — primary care', text: 'FICTIONAL TEST DOCUMENT. 64-year-old male. PMH: hypertension, type 2 diabetes, obstructive sleep apnea on CPAP. Medications: lisinopril 20 mg daily, metformin 1000 mg BID, semaglutide (Ozempic) weekly. Allergies: Penicillin (hives). Exam unremarkable. Airway Mallampati II.' },
    { ...base, id: 'seed-lab', type: 'Labs', title: '[Fictional] CBC + BMP + A1c', text: 'FICTIONAL TEST DOCUMENT. CBC: WBC 7.2, Hgb 13.8, Hct 41, Platelets 245. BMP: Sodium 139, Potassium 5.6, BUN 18, Creatinine 1.1, Glucose 182. HbA1c 7.9 %.' },
    { ...base, id: 'seed-ecg', type: 'ECG / EKG', title: '[Fictional] 12-lead ECG', text: 'FICTIONAL TEST DOCUMENT. Normal sinus rhythm, rate 72. QTc 452 ms. No acute ST changes.' },
  ] as ClearanceDoc[]);
}

/** v7.3: a fictional case already reviewed and cleared, so the dashboard shows all three case colors on first open. */
export function seedClearedCase(caseId: string, us: string) {
  if (getDocs(caseId).length) return;
  const at = new Date().toISOString();
  write(kDocs(caseId), [{ caseId, source: 'Fictional test clinic', docDate: us, receivedAt: at, receivedBy: 'Seed data', status: 'Received', id: 'seed3-hp', type: 'History & Physical (H&P)', title: '[Fictional] H&P — primary care', text: 'FICTIONAL TEST DOCUMENT. 37-year-old female. No significant past medical history. Medications: none. Allergies: NKDA. Exam unremarkable. hCG negative.' }] as ClearanceDoc[]);
  write(kState(caseId), { review: { by: 'Test clinician (seed data)', at, note: 'Fictional seed: review confirmed' }, cleared: { by: 'Test clinician (seed data)', at, note: 'Fictional seed: cleared for surgery' } });
}
