/*
 * Administration > Practice Configuration > Edition (both editions).
 * A practice uses ASC or MED, never both. Switching is admin-only, confirmed and audited.
 */
import React, { useState } from 'react';
import { createPortal } from 'react-dom';
import { Layers } from 'lucide-react';
import { Btn, CardTitle, DialogShell } from './ui';
import { EDITION, EDITION_ADMIN_ROLES, EDITION_EXPLAIN, EDITION_LABEL, Edition, editionAudit, switchEdition } from '../edition';

const ROLES = ['Practice Administrator', 'Practice Manager', 'Front desk', 'Nurse', 'Provider'];

export const EditionCard: React.FC = () => {
  const [open, setOpen] = useState(false);
  const ALL: Edition[] = ['ASC', 'MED', 'SURGERY', 'MEDICAL']; const others = ALL.filter(e => e !== EDITION);
  const [other, setOther] = useState<Edition>(others[0]);
  const [by, setBy] = useState(''); const [role, setRole] = useState('Practice Administrator'); const [typed, setTyped] = useState(''); const [reason, setReason] = useState(''); const [err, setErr] = useState('');
  const isAdmin = EDITION_ADMIN_ROLES.some(r => r.toLowerCase() === role.toLowerCase());
  const log = editionAudit().slice(-5).reverse();
  const confirm = () => {
    if (!isAdmin) { setErr('Only a practice administrator can change the edition.'); return; }
    if (typed.trim().toUpperCase() !== other) { setErr(`Type ${other} to confirm.`); return; }
    try { switchEdition(other, by, role, reason); } catch (e: any) { setErr(e.message); }
  };
  return <div className="vy-card p-5 sm:p-6 space-y-4" data-testid="edition-card">
    <CardTitle kicker="Practice edition" title={<span>This practice uses <b>{EDITION_LABEL[EDITION]}</b></span>} sub="A practice uses one edition, never both. A multi-surgeon or multi-specialty surgery center uses ASC. A surgeon with an in-office operating room can pick either." right={<span className="vy-chip vy-chip-ok" data-testid="edition-current">{EDITION}</span>} />
    <div className="grid sm:grid-cols-3 gap-3">
      {ALL.map(e => <div key={e} className={`rounded-lg border p-3 ${e === EDITION ? 'border-[#7fbf98] bg-[#f3faf6]' : 'border-[#dfe5e1]'}`}><div className="font-semibold text-[15px]">{EDITION_LABEL[e]}{e === EDITION && <span className="ml-2 text-[13px] text-[#14532f]">(current)</span>}</div><p className="text-[14px] text-[#39443E] mt-1">{EDITION_EXPLAIN[e]}</p></div>)}
    </div>
    <div className="flex flex-wrap items-center gap-3"><Btn variant="secondary" icon={<Layers />} onClick={() => { setErr(''); setOpen(true); }} data-testid="edition-switch">Change edition…</Btn><span className="text-[13.5px] text-[#39443E]">Administrators only. Confirmed and audited. Test switch: add <code>?edition=med</code>, <code>?edition=surgery</code> or <code>?edition=asc</code> to the address.</span></div>
    {log.length > 0 && <div><div className="vy-section-title">Edition changes</div><ul className="text-[13.5px] text-[#39443E] space-y-1">{log.map((l, i) => <li key={i}>{new Date(l.at).toLocaleString()} · {l.from} → {l.to} · {l.by} ({l.role}) · {l.reason}</li>)}</ul></div>}
    {open && createPortal(<DialogShell title={`Switch this practice to ${EDITION_LABEL[other]}?`} subtitle="The app reloads in the other edition." icon={<Layers />} onClose={() => setOpen(false)} size="md" testId="edition-dialog"
      footer={<><Btn onClick={() => setOpen(false)}>Cancel</Btn><Btn variant="primary" onClick={confirm} disabled={!isAdmin} data-testid="edition-confirm">Switch to {other}</Btn></>}>
      {others.length > 1 && <label className="block mb-2"><span className="vy-label">Switch to</span><select className="vy-input" value={other} onChange={e => setOther(e.target.value as Edition)} data-testid="edition-target">{others.map(e => <option key={e} value={e}>{EDITION_LABEL[e]}</option>)}</select></label>}
      <p className="text-[14.5px] text-[#39443E]">{EDITION_EXPLAIN[other]}</p>
      <p className="text-[14px] text-[#39443E] mt-2">In this test build each edition keeps its own test data in this browser; switching does not delete anything.</p>
      <div className="grid sm:grid-cols-2 gap-3 mt-4">
        <label><span className="vy-label">Your name</span><input className="vy-input" value={by} onChange={e => setBy(e.target.value)} data-testid="edition-by" /></label>
        <label><span className="vy-label">Your role</span><select className="vy-input" value={role} onChange={e => setRole(e.target.value)}>{ROLES.map(r => <option key={r}>{r}</option>)}</select></label>
        <label className="sm:col-span-2"><span className="vy-label">Reason</span><input className="vy-input" value={reason} onChange={e => setReason(e.target.value)} data-testid="edition-reason" /></label>
        <label className="sm:col-span-2"><span className="vy-label">Type {other} to confirm</span><input className="vy-input" value={typed} onChange={e => setTyped(e.target.value)} data-testid="edition-typed" /></label>
      </div>
      {!isAdmin && <p className="vy-field-error mt-2">Only a practice administrator can change the edition.</p>}
      {err && <p className="vy-field-error mt-2" role="alert">{err}</p>}
    </DialogShell>, document.body)}
  </div>;
};
