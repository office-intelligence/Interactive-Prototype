/*
 * Safety fix (both editions, MED v0.1 / proposed ASC v7.6): the e-prescribe screen is a SIMULATION.
 * This test build is not connected to any pharmacy, e-prescribing network or clearinghouse; nothing is sent.
 * A registered, active provider must enter their signature PIN. Nightingale (AI) can never prescribe or sign.
 */
import React, { useState } from 'react';
import { Pill, AlertTriangle, CheckCircle2 } from 'lucide-react';
import { Btn, DialogShell } from './ui';
import { checkSignerPin, displayName, getProviders } from './providers';
import { recordPinFailure, recordPinSuccess } from './invitations';
import { repo } from '../v6/dataLayer';

export interface SimulatedRx { medication: string; dose: string; instructions: string; quantity: string; refills: string; pharmacy: string; prescriber: string; at: string }

/** Shared PIN check used by simulated prescriptions and MED signatures. Returns an error message or '' when OK. */
export function verifyProviderPin(name: string, pin: string): string {
  if (!name.trim()) return 'Choose the prescribing/signing provider.';
  if (/nightingale|\bai\b|artificial intelligence/i.test(name)) return 'Nightingale (AI) cannot prescribe, order or sign.';
  const r = checkSignerPin(name, pin);
  if (r === 'ok') { recordPinSuccess(name); return ''; }
  if (r === 'wrong') { const left = recordPinFailure(name); return left > 0 ? `That PIN doesn’t match ${name}’s signature PIN. ${left} attempt${left === 1 ? '' : 's'} left before the account locks.` : `Too many wrong PINs. ${name}’s account is locked; an administrator can unlock it in Providers.`; }
  if (r === 'unregistered') return `${name} is not a registered provider. Only registered providers with a signature PIN can do this.`;
  if (r === 'locked') return `${name}’s account is locked after too many wrong PINs.`;
  if (r === 'inactive') return `${name} is deactivated and cannot sign.`;
  return `${name} has not set a signature PIN yet.`;
}

export const SimulatedRxDialog: React.FC<{ patientName: string; dob?: string; auditKey: string; defaultPrescriber?: string; onClose: () => void; onRecorded?: (rx: SimulatedRx) => void }> = ({ patientName, dob, auditKey, defaultPrescriber, onClose, onRecorded }) => {
  const providers = getProviders().filter(p => p.active);
  const [rx, setRx] = useState({ medication: '', dose: '', instructions: '', quantity: '', refills: '0', pharmacy: '', prescriber: defaultPrescriber && providers.some(p => displayName(p) === defaultPrescriber) ? defaultPrescriber : '' });
  const [pin, setPin] = useState(''); const [err, setErr] = useState(''); const [done, setDone] = useState<SimulatedRx | null>(null);
  const set = (k: keyof typeof rx) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => setRx({ ...rx, [k]: e.target.value });
  const submit = () => {
    if (!rx.medication.trim() || !rx.instructions.trim()) { setErr('Enter the medication and the instructions.'); return; }
    const e = verifyProviderPin(rx.prescriber, pin); if (e) { setErr(e); setPin(''); return; }
    const rec: SimulatedRx = { ...rx, at: new Date().toISOString() };
    repo.audit({ caseId: auditKey, user: rx.prescriber, role: 'Prescriber', action: 'erx.simulated', detail: `SIMULATED prescription recorded (not sent): ${rx.medication} ${rx.dose} · ${rx.instructions} · qty ${rx.quantity || '—'} · refills ${rx.refills || '0'}${rx.pharmacy ? ` · pharmacy entered: ${rx.pharmacy}` : ''}` });
    onRecorded?.(rec); setDone(rec);
  };
  return <DialogShell title="Prescription (simulated, not sent)" subtitle={`${patientName}${dob ? ` · DOB ${dob}` : ''}`} icon={<Pill />} kicker="Test build" onClose={onClose} size="md" testId="simulated-rx"
    footer={done ? <Btn variant="primary" onClick={onClose}>Done</Btn> : <><Btn onClick={onClose}>Cancel</Btn><Btn variant="primary" onClick={submit} data-testid="rx-record">Sign with PIN and record (not sent)</Btn></>}>
    <div className="flex gap-2 items-start rounded-lg border border-[#e3c27c] bg-[#fff3dc] p-3 text-[14.5px] text-[#5c3d05]" data-testid="rx-simulated-banner"><AlertTriangle size={18} className="flex-none mt-0.5" /><div><b>Simulated. Nothing is sent.</b> This test build is not connected to any pharmacy or e-prescribing network. The prescription is only recorded in this chart’s audit trail{onRecorded ? ' and medication list' : ''}. Real e-prescribing needs a certified vendor.</div></div>
    {done ? <div className="mt-4 text-center space-y-2" data-testid="rx-done"><CheckCircle2 className="w-10 h-10 mx-auto text-[#1f6e52]" /><div className="text-[17px] font-bold">Recorded as a simulated prescription</div><p className="text-[14.5px] text-[#39443E]"><b>Not sent to any pharmacy.</b> {done.medication} {done.dose} · {done.instructions}. Signed with {done.prescriber}’s PIN.</p></div> :
      <div className="grid sm:grid-cols-2 gap-3 mt-4">
        <label className="sm:col-span-2"><span className="vy-label">Medication</span><input className="vy-input" value={rx.medication} onChange={set('medication')} data-testid="rx-med" /></label>
        <label><span className="vy-label">Strength / form</span><input className="vy-input" value={rx.dose} onChange={set('dose')} /></label>
        <label><span className="vy-label">Quantity</span><input className="vy-input" value={rx.quantity} onChange={set('quantity')} /></label>
        <label className="sm:col-span-2"><span className="vy-label">Instructions (sig)</span><input className="vy-input" value={rx.instructions} onChange={set('instructions')} data-testid="rx-sig" /></label>
        <label><span className="vy-label">Refills</span><input className="vy-input" value={rx.refills} onChange={set('refills')} /></label>
        <label><span className="vy-label">Pharmacy (text only, not contacted)</span><input className="vy-input" value={rx.pharmacy} onChange={set('pharmacy')} /></label>
        <label><span className="vy-label">Prescribing provider</span><select className="vy-input" value={rx.prescriber} onChange={set('prescriber')} data-testid="rx-prescriber"><option value="">Choose…</option>{providers.map(p => <option key={p.id} value={displayName(p)}>{displayName(p)}</option>)}</select></label>
        <label><span className="vy-label">Provider signature PIN</span><input className="vy-input" type="password" inputMode="numeric" autoComplete="off" value={pin} onChange={e => setPin(e.target.value)} data-testid="rx-pin" /></label>
        {err && <p className="sm:col-span-2 vy-field-error" role="alert">{err}</p>}
      </div>}
  </DialogShell>;
};
