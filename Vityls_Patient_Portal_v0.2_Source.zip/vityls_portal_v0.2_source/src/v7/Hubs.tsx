import { isMed } from '../edition';
import { MedBillingInvoices, MedFeeScheduleEditor, MedOpsLive } from '../med/MedBilling';
import React, { useEffect, useState } from 'react';
import { ArrowLeft } from 'lucide-react';
import type { PatientCase } from '../types';
import { ApprovedDesignPage } from '../components/ApprovedDesignPage';
import { Btn, CardTitle, PageHeader } from './ui';
import { FeeScheduleEditor, CaseInvoicesTable, InvoicePanel, invoiceEligibility, useBilling } from './InvoicePanel';
import { balanceFor, isCashPay } from './billing';
import { repo } from '../v6/dataLayer';
import { getState } from './clearance';
import { allStationForms } from './myForms';

/** All cases in this browser's evaluation storage (every date). */
export function allCases(): PatientCase[] {
  try { const d = JSON.parse(localStorage.getItem('vityls:evaluation:date-cases') || '{}'); return Object.values(d).flat() as PatientCase[]; } catch { return []; }
}
const hm = (v?: unknown) => { const m = String(v || '').match(/^(\d{1,2}):(\d{2})/); return m ? +m[1] * 60 + +m[2] : null; };

/**
 * v7.4: Kevin's ORIGINAL v5 Billing & Payments page (ApprovedDesignPage kind="billing", unchanged markup and styles)
 * is the main page again. v7's live pieces are ADDITIONS slotted where they fit:
 *  - after his "Patient accounts" card: case invoices + invoice generation with the manager override (his "Create invoice" button jumps here);
 *  - after his "Billing configuration" card: the time-based fee schedules (his "Fee schedules" command jumps here).
 */
export const BillingHub: React.FC<{ onBack: () => void; onToast?: (m: string) => void }> = ({ onBack, onToast }) => {
  useBilling(); const cases = allCases();
  const cash = cases.filter(isCashPay);
  if (isMed) return <div className="bg-[#e8ece8] min-h-full" data-testid="billing-hub">
    <ApprovedDesignPage kind="billing" onBack={onBack} slots>
      <div slot="v7-invoices" data-testid="billing-live-invoices" className="space-y-3 scroll-mt-4"><MedBillingInvoices onToast={onToast} /></div>
      <div slot="v7-fees" data-testid="billing-live-fees" className="scroll-mt-4"><MedFeeScheduleEditor onToast={onToast} /></div>
    </ApprovedDesignPage>
  </div>;
  return <div className="bg-[#e8ece8] min-h-full" data-testid="billing-hub">
    <ApprovedDesignPage kind="billing" onBack={onBack} slots>
      <div slot="v7-invoices" data-testid="billing-live-invoices" className="space-y-3 scroll-mt-4">
        <CaseInvoicesTable />
        <section className="vy-card p-5"><CardTitle kicker="Live · this browser" title={`Create invoice · cash-pay cases (${cash.length})`} sub="Generated from the time-based fee schedule once the procedure is done and documentation is complete. A practice manager can issue earlier with a recorded override." />
          <div className="mt-3 space-y-3">{!cash.length ? <p className="text-[15px] text-[#4a5750]">No self-pay / cash-pay cases.</p> : cash.map(c => <details key={c.id} className="border border-[#dfe5e1] rounded-lg bg-white" data-testid={`billing-case-${c.id}`}><summary data-focus-target tabIndex={0} className="min-h-[48px] px-4 py-2 flex flex-wrap items-center gap-3 cursor-pointer"><span className="font-semibold">{c.name}</span><span className="text-[14px] text-[#4a5750]">{c.appointmentDate} · {c.procedure}</span><span className={invoiceEligibility(c).ok ? 'vy-chip-ok' : 'vy-chip-muted'}>{invoiceEligibility(c).ok ? 'Ready to invoice' : 'Not ready'}</span><span className="vy-chip-info">{balanceFor(c.id).label}</span></summary><div className="p-3"><InvoicePanel patient={c} actor="Practice Administrator" role="Practice Administrator" compact /></div></details>)}</div></section>
      </div>
      <div slot="v7-fees" data-testid="billing-live-fees" className="scroll-mt-4"><FeeScheduleEditor onToast={onToast} /></div>
    </ApprovedDesignPage>
  </div>;
};

/** Operations Intelligence: live per-case operations table from station data (item 16) above the design reference. */
/**
 * v7.3: Kevin's Operations Intelligence page (v5 design: ApprovedDesignPage kind="operations", unchanged) is the page again.
 * v7's live case-flow figures are kept only as an ADDITION below his page; nothing of his is replaced or hidden.
 */
export const OpsHub: React.FC<{ onBack: () => void }> = ({ onBack }) => <div data-testid="ops-hub" className="bg-[#e8ece8] min-h-full">
  <ApprovedDesignPage kind="operations" onBack={onBack} />
  <div className="max-w-[1280px] mx-auto px-4 sm:px-6 pb-8">{isMed ? <MedOpsLive /> : <OpsLiveSection />}</div>
</div>;

/** v7 item 16 addition: live case flow from the workstations in this browser. */
export const OpsLiveSection: React.FC = () => {
  const [, f] = useState(0); useEffect(() => { const t = setInterval(() => f(x => x + 1), 30000); return () => clearInterval(t); }, []);
  const cases = allCases(); const files = allStationForms();
  const rows = cases.map(c => { const facts = repo.getFacts(c.id); const inn = hm(facts['time.inOR']?.value), out = hm(facts['time.outOR']?.value); const room = inn != null && out != null ? (out - inn + 1440) % 1440 : null;
    const locked = files.filter(x => repo.getForm(c.id, x).status === 'locked').length; const ver = Object.keys(repo.getStationVerification(c.id)).length;
    return { c, room, booked: c.estimatedDurationMins || 0, locked, ver, clr: getState(c.id), bal: balanceFor(c.id) }; });
  const done = rows.filter(r => r.room != null); const avg = done.length ? Math.round(done.reduce((a, r) => a + (r.room || 0), 0) / done.length) : null;
  return <div className="space-y-4" data-testid="ops-live">
    <div className="pt-2"><div className="vy-kicker">Added in v7 · live from this browser</div><h2 className="vy-card-title">Today’s case flow</h2><p className="vy-card-sub">Real cases and workstation data on this device, alongside the evaluation above.</p></div>
    <section className="grid sm:grid-cols-4 gap-3">{([['Cases', String(cases.length)], ['Cleared for surgery', `${rows.filter(r => r.clr.cleared).length}`], ['Average room time', avg == null ? '—' : `${avg} min`], ['Open balance', `$${rows.reduce((a, r) => a + r.bal.due, 0).toFixed(2)}`]] as const).map(([k, v]) => <div key={k} className="vy-card p-4"><div className="vy-kicker">{k}</div><div className="text-[24px] font-semibold mt-1">{v}</div></div>)}</section>
    <section className="vy-card p-5"><CardTitle title="Case flow" sub="Stations verified, documents locked, room time against booked time, clearance and balance." />
      <div className="overflow-x-auto mt-3"><table className="vy-table" data-testid="ops-table"><thead><tr><th>Patient</th><th>Date</th><th>Stations verified</th><th>Documents locked</th><th>Room time</th><th>Clearance</th><th>Balance</th></tr></thead>
        <tbody>{rows.map(r => <tr key={r.c.id}><td className="font-semibold">{r.c.name}</td><td>{r.c.appointmentDate} {r.c.scheduledTime}</td><td>{r.ver} / 7</td><td>{r.locked} / {files.length}</td><td>{r.room == null ? '—' : <span className={r.booked && r.room > r.booked ? 'vy-chip-warn' : 'vy-chip-ok'}>{r.room} min (booked {r.booked})</span>}</td><td>{r.clr.cleared ? <span className="vy-chip-ok">Cleared</span> : r.clr.review ? <span className="vy-chip-warn">Reviewed</span> : <span className="vy-chip-muted">Not reviewed</span>}</td><td>{r.bal.label}</td></tr>)}</tbody></table></div></section>
  </div>;
};
