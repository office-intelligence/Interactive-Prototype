/*
 * Safety fix (both editions): Nightingale chart Q&A answers ONLY from what is recorded in the chart,
 * names the source, and says plainly when something is not recorded. It never states invented facts,
 * never clears, signs or orders.
 */
import { PatientCase } from '../types';
import { effectiveAllergy } from './allergy';
import { getDocs, getState } from './clearance';
import { repo } from '../v6/dataLayer';

const NOT = (what: string) => `${what} is not recorded in this chart.`;

export function answerFromLegacyChart(p: PatientCase, question: string): string {
  const q = question.toLowerCase();
  if (/allerg|penicillin|reaction/.test(q)) {
    const a = effectiveAllergy(p.allergies, p.id);
    if (a.state === 'not-reported') return 'Nightingale: Allergy status is Not Reported in this chart. Ask the patient and record it.';
    return `Nightingale: Allergies recorded in the chart: ${a.text}${a.pendingConfirm ? ` (patient-reported on ${a.sourceForm || 'intake'}, not yet confirmed by staff)` : ''}. I have not checked any orders against them.`;
  }
  if (/lab|cbc|bmp|blood|hemoglobin|coag|inr|a1c/.test(q)) {
    const labs = (p.labs || []) as any[];
    const docs = getDocs(p.id).filter(d => /lab/i.test(d.type));
    if (!labs.length && !docs.length) return `Nightingale: ${NOT('No lab result')}`;
    const parts = labs.slice(0, 8).map(l => `${l.name || l.test || 'Result'} ${l.value ?? ''}${l.unit ? ' ' + l.unit : ''}${l.date ? ` (${l.date})` : ''}`.trim());
    return `Nightingale: From the chart${parts.length ? `, lab entries: ${parts.join('; ')}` : ''}${docs.length ? `${parts.length ? '. ' : ': '}${docs.length} lab document${docs.length === 1 ? '' : 's'} filed in Clearance Files (${docs.map(d => d.title).slice(0, 3).join(', ')})` : ''}. I don't interpret results; a clinician reviews them.`;
  }
  if (/implant|mentor|supplier|lot|serial/.test(q)) return `Nightingale: ${NOT('Implant information')}`;
  if (/consent|signed|signature/.test(q)) {
    const signed = repo.listForms(p.id).filter(f => f.signatures.length > 0);
    const name = (f: string) => f.replace(/\.html$/i, '').replace(/_/g, ' ');
    return signed.length ? `Nightingale: Forms with signatures in the chart: ${signed.map(f => `${name(f.file)} (${f.status === 'locked' ? 'fully signed' : 'partially signed'}, last signature ${new Date(f.signatures[f.signatures.length - 1].at).toLocaleDateString()})`).join('; ')}.` : `Nightingale: No signed forms or consents are recorded in this chart yet.`;
  }
  if (/clear|cardiac|airway|ekg|ecg|mallampati/.test(q)) {
    const s = getState(p.id);
    if (s.cleared) return `Nightingale: Marked cleared by ${s.cleared.by} on ${new Date(s.cleared.at).toLocaleDateString()} (Review & alerts).`;
    if (s.review) return `Nightingale: The clearance review was confirmed by ${s.review.by}; the patient has not been marked cleared yet.`;
    return 'Nightingale: Clearance has not been reviewed or recorded in this chart. A named clinician reviews and clears; I cannot.';
  }
  if (/procedure|surgeon|room|time|scheduled/.test(q)) return `Nightingale: From the booking: ${p.procedure || 'procedure not recorded'}, surgeon ${p.surgeon || 'not recorded'}, room ${p.room || 'not recorded'}, ${p.appointmentDate || ''} ${p.scheduledTime || ''}.`.replace(/\s+\./, '.');
  if (/med|drug|rx|prescri/.test(q)) {
    const meds = ((p as any).medications || []) as any[];
    return meds.length ? `Nightingale: Medications recorded: ${meds.map(m => typeof m === 'string' ? m : `${m.name || ''} ${m.dose || ''}`.trim()).join('; ')}.` : `Nightingale: ${NOT('A medication list')}`;
  }
  return 'Nightingale: I can only answer from what is recorded in this chart, and I didn’t find that. Try allergies, labs, consents, clearance, medications or the procedure.';
}
