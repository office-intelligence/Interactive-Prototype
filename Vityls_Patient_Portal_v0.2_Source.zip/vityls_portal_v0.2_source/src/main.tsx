import './edition'; // must be first: resolves ASC/MED and (MED) namespaces browser storage
import {StrictMode, useEffect, useState} from 'react';
import { InviteLanding } from './v7/InviteLanding';
import { parseInviteHash } from './v7/invitations';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import { seedTestData } from './v6/seed';
import { isMed, isSurgery, isMedical } from './edition';
import { installMedicalTerms, seedMedicalOverrides, MEDICAL_SEED_VERSION } from './surgery/medical';
import { seedMedData } from './med/seed';
import { MedApp } from './med/MedApp';
import { SurgeryApp } from './surgery/SurgeryApp';
import { seedSurgeryExtras, SURGERY_SEED_VERSION } from './surgery/store';
import { StaffInviteLanding } from './surgery/StaffInviteLanding';
import { parseStaffInviteHash } from './surgery/staff';
import { parsePinResetHash } from './surgery/v12/pinReset';
import { PinResetLanding } from './surgery/v12/PinReset';
import { AdminConsole } from './core/AdminConsole';
import { CoreTestBar } from './core/TestBar';
import { IS_CORE_BUILD } from './edition';
import { PortalApp, ProviderUploadPage } from './portal/PortalApp';
/** Portal v0.1: the Patient Portal build (VITE_PORTAL=1) opens the Portal by default; any build opens it at #portal. */
const IS_PORTAL_BUILD = String((import.meta as any).env?.VITE_PORTAL || '') === '1';
// Surgery.Vityls reuses the MED seed (own namespace + version) and adds its own data once.
// Medical.Vityls v1.0 runs the Surgery code with its own seed version, a primary-care data pass and the terminology layer.
if (isMedical) { installMedicalTerms(); seedMedData({ version: MEDICAL_SEED_VERSION, after: () => { seedSurgeryExtras(); seedMedicalOverrides(); } }); }
else if (isSurgery) seedMedData({ version: SURGERY_SEED_VERSION, after: seedSurgeryExtras }); else if (isMed) seedMedData(); else seedTestData();
import './v6/fonts.css';
import './index.css';

/** v7.3: the provider invitation links (#invite=…) open the onboarding pages instead of the app. */
function Root() {
  const [hash, setHash] = useState(location.hash);
  useEffect(() => { const f = () => setHash(location.hash); window.addEventListener('hashchange', f); return () => window.removeEventListener('hashchange', f); }, []);
  if (hash.startsWith('#portal-upload=')) return <ProviderUploadPage key={hash} token={hash.slice('#portal-upload='.length)} />;
  // v0.2: the Portal build opens the Portal unless a practice is asked for (?practice=coastline or #practice): same file, same browser storage.
  const wantPractice = hash.startsWith('#practice') || hash.startsWith('#vityls-admin') || new URLSearchParams(location.search).has('practice');
  if ((IS_PORTAL_BUILD && !wantPractice) || hash.startsWith('#portal')) return <PortalApp />;
  if (IS_CORE_BUILD && hash.startsWith('#vityls-admin')) return <AdminConsole />;
  const staffTok = isSurgery ? parseStaffInviteHash(hash) : null; // Surgery.Vityls v0.3 staff invitations
  if (staffTok) return <StaffInviteLanding key={hash} token={staffTok} />;
  const pinTok = isSurgery ? parsePinResetHash(hash) : null; // Surgery.Vityls v0.12 Forgot PIN
  if (pinTok) return <PinResetLanding key={hash} token={pinTok} />;
  const app = parseInviteHash(hash) ? <InviteLanding key={hash} /> : isSurgery ? <SurgeryApp /> : isMed ? <MedApp /> : <App />;
  return IS_CORE_BUILD ? <>{app}<CoreTestBar /></> : app;
}
createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <Root />
  </StrictMode>,
);
