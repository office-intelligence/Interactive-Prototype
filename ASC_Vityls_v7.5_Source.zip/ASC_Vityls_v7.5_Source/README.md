# ASC.Vityls — v7.5 source

ASC.Vityls is a test build of an ambulatory surgery center workspace: dashboard, scheduler, patient chart, workstations with smart forms, multi-signer signing, clearance review, providers and credentialing, and billing.
**It is test scaffolding only.** All data is fictional, and everything is stored in the browser (`localStorage`). There is no backend or database yet. See `report/ASC_Vityls_Database_Schema.sql` and `report/ASC_Vityls_Database_Handoff.md` in the delivery folder.

## Run it

Prerequisites: **Node.js 20+** (tested with 20.19) and npm.

```bash
npm install
npm run dev
```

Then open **http://localhost:3000**. `npm run dev` starts `server.ts` (Express + Vite middleware). Before it starts, `predev` regenerates the reference form catalog.

Optional: copy `.env.example` to `.env` and set `GEMINI_API_KEY` to enable live Nightingale chat answers. Without a key the app uses built-in offline answers. **No secrets are included in this package.**

### Other scripts

| Command | What it does |
|---|---|
| `npm run build` | Production build (`dist/`) + bundled server (`dist/server.cjs`) |
| `npm start` | Runs the production build on port 3000 |
| `node scripts/package-v7.mjs` | After `npm run build`: writes the single-file, double-click build to `release/ASC_Vityls_v7/index.html` (works from `file://`) |
| `npm run lint` | TypeScript check (`tsc --noEmit`). A few older files still report type errors; they don't affect the build |
| `python scripts/strip_template_signatures.py public/forms/*.html` | v7.4 tool that removes signature fields and blocks from HTML templates (needs `beautifulsoup4`). Used for v7.4; templates stay signature-free in v7.5 |

## Test data

- First open (or a new seed version) loads three fictional cases for today and four fictional providers. The signature PIN for every seeded provider is **1234**.
- To reset: clear site data for `localhost:3000`, or open the browser console and run `localStorage.clear()`, then reload.

## Where things are

| Path | What |
|---|---|
| `src/App.tsx` | Shell, navigation, routes |
| `src/v6/dataLayer.ts` | **Encounter data layer** (`repo`): forms, values + provenance, facts (carry-forward), signatures, addenda, audit. Swap point for the backend |
| `src/v6/formEngine.ts`, `formRules.ts`, `formEnhancer.ts` | Smart-form engine: prefill, carry-forward, defaults, normals, calcs, initials from signer setup |
| `src/v6/SignaturePanel.tsx`, `SignerSetup.tsx` | Multi-signer panel and Form Studio signer setup (the only source of signatures) |
| `src/v7/` | v7 modules: providers & credentialing, invitations/outbox, clearance, billing, hubs, dashboard status |
| `src/components/ApprovedDesignPage.tsx` + `src/designReference/` | Kevin's approved v5 Billing & Payments and Operations Intelligence pages |
| `public/forms/*.html` | Form templates (signature-free as of v7.4) |
| `src/v6/fonts.css` | Local fonts (Source Sans 3, Cormorant Garamond, IBM Plex Mono via `@fontsource`). No Google Fonts requests |

## Version

v7.5 (2026-10-05). See `ASC_Vityls_v7_Changelog.md` in the delivery folder for the item-by-item changes.
