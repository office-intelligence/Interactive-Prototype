# Final Patient Chart Right Column Update — 2026-10-02

- Restored the prior Nightingale Clinical Coordinator experience in the Patient Chart right column.
- Restored Common Actions: Chart Documents, Intake Forms, Billing, Collect Payment, Provider Notes, Messages, Print, E-Prescribe, and Dictate Note.
- Connected evaluation-build behavior for commands; Print invokes browser print, Intake opens Patient Portal/Intake, other commands surface active test content pending Henry API integration.
- Restored Appointment History/current encounter card beneath Nightingale.
- Preserved the approved longitudinal patient chart as the main patient page.
- Added the pre-day-of-surgery Care Pathway sequence: Scheduling, Patient Packet, Records, Nightingale Review & Alerts, Clearance.
- Preserved Day-of-Surgery station workflow below the pre-op pathway.
