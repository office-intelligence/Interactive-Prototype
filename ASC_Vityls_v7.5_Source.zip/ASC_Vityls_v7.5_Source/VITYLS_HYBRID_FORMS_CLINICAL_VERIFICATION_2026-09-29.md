# ASC.Vityls Hybrid Forms + Clinical Verification Evaluation

This build restores the strongest part of the earlier structured workflow while keeping traditional forms as the familiar/legal record.

## Station model
Each station now presents, in order:
1. Shared clinical verification summary (known + unknown items)
2. Responsible owner for each verification item
3. Explicit Verify action
4. Station attestation/authentication after required items are verified
5. Traditional forms assigned to that workflow, always available below

Stations: At Home/Intake, Pre-Op Nursing, Anesthesia, Surgeon, OR Team/Time-Out, Intra-Op, PACU, Discharge, Final Case Record.

## Authentication principle
A station attestation authenticates the station review; it does not substitute for a separately required patient consent, physician order authentication, anesthesia authentication, surgeon attestation, or other signature embedded in a legal form.

## OR Team
OR Team is now a distinct patient-journey card rather than being merged into Surgeon/Procedure. It opens the OR Team / Time-Out station and shows its separately assigned Form Studio forms.

## Evaluation notes
This is an evaluation UI. Verification/authentication state persists in browser localStorage. Production should persist each verification event with encounter, concept/value reference, source/version, signer identity/role, timestamp, authentication method, and audit history.
