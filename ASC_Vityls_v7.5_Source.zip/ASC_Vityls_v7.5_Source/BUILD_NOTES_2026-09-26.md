# ASC.Vityls Frontend V1.1 — Workflow Integration Update

Changes in this build:
- Add Patient: DOB restored and required; age calculated; phone required; email optional.
- Scheduler: appointment Save publishes the scheduled encounter back to shared application case state and moves the active date to the booked DOS.
- Scheduler: surgeon is a searchable practice-provider field; anesthesia type is a dropdown with General Anesthesia as default.
- Scheduler: removed patient-search help text; weekly notes now follow the selected schedule week.
- Patient Chart: legacy Intake Forms card now opens the unified At-Home Intake workspace instead of the old form list.
- Clinical Configuration: added functional Practice Document Library with Welcome Letter, Patient Rights, HIPAA Privacy Notice, Arbitration Agreement, Fee Disclosure, Pre-Op Instructions, Surgical Consent, Anesthesia Consent and Discharge Instructions. Documents can be created/edited/versioned and configured for information-only, acknowledgment, patient signature, response, or clinician countersignature.

Build validation note: source changes were completed, but the packaged environment does not contain the Vite executable, so `npm run build` cannot execute locally (`vite: not found`).
