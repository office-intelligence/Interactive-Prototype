# Vityls Database Boundary Review — 2026-09-13

## Finalized UX/domain decisions before backend table work

1. **Forms are one domain, regardless of format.** HTML templates and uploaded practice PDFs are both `FormDefinition` records with a `Format`/`SourceType` attribute. Do not create separate clinical workflow tables for HTML vs PDF.
2. **Workflow assignment is the source of truth.** A form can be assigned to Patient Portal, Front Office, Nursing, Anesthesia, Surgeon/Physician, OR Team, and PACU/Discharge. A single form may appear in several workflows without creating duplicate clinical records.
3. **“Intake Form” is not a separate template type.** It is simply a form assigned to the **Patient Portal** workflow. The Patient Chart Intake Forms section should query Patient Portal assignments. Remove legacy standalone Intake Forms repository/schema concepts.
4. **Practice PDF forms use the same workflow-assignment model as HTML forms.** Preserve the original PDF blob; annotations/signatures/completed instances are separate records.
5. **Completed forms are instances, not template mutations.** Suggested split: `FormDefinition` -> `FormVersion` -> `PracticeFormConfiguration` -> `FormWorkflowAssignment` -> `PatientFormRequest/FormInstance` -> `FormResponse` + `Signature`.
6. **Billing is a separate bounded context, not Administration.** Administration owns fee-schedule configuration references; operational invoices, claims, payments, credits/deposits and AR belong to Billing.
7. **Providers and staff users are related but not the same entity.** Setup UI can combine them, but DB should retain `Person/User`, `PracticeMembership`, `Provider`, `ProviderCredential` separately because not every user is a provider and providers may have multiple practice relationships. Invitations need email/mobile and status.
8. **Integrations have two scopes.** Company-level tables own vendor definitions/platform credentials/contracts (`IntegrationProvider`, `CompanyIntegrationConnection`). Practice-level tables own tenant-specific bindings/configuration (`PracticeIntegrationBinding`: merchant account, prescriber enrollment, EHR endpoint/facility IDs, enabled features). Never duplicate platform secrets per practice.
9. **Document Intake Queue should not be a primary Practice module.** Patient-matched documents and extraction issues belong in the patient chart. Keep a small system-level `DocumentProcessingException` concept for unmatched/unrouteable documents because those cannot yet belong to a patient. Nightingale alerts staff to these exceptions.
10. **Document provenance is immutable.** `Document`/`SourceArtifact` keeps original blob, tenant, uploader/source, checksum, received time. Extraction/classification is versioned and reviewable.
11. **Credentialing documents use version history.** Provider license/DEA/malpractice/etc. should be `ProviderCredential` + `ProviderCredentialDocumentVersion`, with issue/expiration/license/authority fields and current/superseded status.
12. **Signatures are universal evidence records.** Store signer identity, role, patient/encounter, form/document version, timestamp, intent/attestation, signature image/blob reference, and audit/integrity evidence. Do not infer signature requirements from workflow assignment.

## UI cleanup reflected in this build
- Billing removed from Administration destinations; use the dedicated Billing & Payments workspace.
- Legacy Intake Forms administration repository removed from navigation.
- Document Intake Queue removed from Administration navigation.
- Company-managed E-Prescribe/payment/EMR vendor setup removed from primary Practice Administration destinations.
- Duplicate Administration header/navigation removed.
- Practice setup now points users toward providers/credentialing and staff invitations without creating separate onboarding concepts.
- Practice PDFs can now be selected and assigned to the same workflows as HTML templates.
- Patient Chart Intake Forms language now means Patient Portal-assigned forms only.

## Recommended minimum tables / aggregates
`Tenant`, `Practice`, `Location`, `User`, `PracticeMembership`, `Provider`, `ProviderCredential`, `ProviderCredentialDocumentVersion`, `Invitation`, `FormDefinition`, `FormVersion`, `PracticeFormConfiguration`, `FormWorkflowAssignment`, `PatientFormRequest`, `FormInstance`, `FormResponse`, `Signature`, `SourceArtifact`, `Document`, `DocumentExtraction`, `DocumentProcessingException`, `Encounter`, `FeeSchedule`, `FeeScheduleItem`, `Invoice`, `InvoiceLine`, `Payment`, `PatientCredit`, `CreditApplication`, `Claim`, `IntegrationProvider`, `CompanyIntegrationConnection`, `PracticeIntegrationBinding`, `AuditEvent`.

This document intentionally separates UI grouping from database normalization. A screen being combined does not imply its underlying entities should be collapsed into one table.

---

## Addendum — 2026-09-13 workflow cleanup

See `PRE_DATABASE_WORKFLOW_PATIENT_NOTES_CLEANUP_20260913.md`.

Key schema decisions confirmed after final UI testing:

1. **No separate IntakeForm table.** Intake is a Patient Portal workflow assignment on a common form definition/version.
2. **HTML and PDF are formats of the same form concept.** Workflow assignments apply identically to both.
3. **No hard-coded role packet tables.** Front Office, Nursing, Anesthesia, Surgeon/OR and PACU workspaces query `FormWorkflowAssignment`.
4. **Doctor notes are a clinical-note domain**, with note type, draft/final/amended versioning, author and signature/audit metadata.
5. **Patient edit and patient create use one demographic model.** Do not preserve the prototype's contact-override concept as a production entity.
6. **Practice PDF templates and patient document instances are different records.** Preserve the source Blob/version and create patient/encounter instances separately.

## Form revision rule added 2026-09-13

Form versions must be immutable after publication/use. When a practice edits its existing customized form months later, Vityls should open the current practice version and create a new `FormVersion` on save. Do not force the practice to restart from the Vityls master template, and do not overwrite the version already used by historical encounters. Completed form instances must remain pinned to the exact form version presented and signed.
