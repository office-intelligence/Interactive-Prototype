# Final Form Viewer / Template Discovery Update — 2026-09-13

## Patient Chart HTML form viewer
- The Patient Chart Intake Forms Open/Review actions now render the full-screen HTML viewer directly in the chart component tree instead of relying on a React portal.
- Intake Open/Review buttons are explicitly `type="button"` so they cannot accidentally submit a surrounding form.
- Patient Portal assignments remain the only source of the Intake Forms list.

## Anesthesia Consent editable language
- Existing practice schemas are migrated/merged with the current Vityls standard field metadata when opened in Form Studio.
- Older saved Anesthesia Consent schemas now regain the two current editable policy blocks without resetting the rest of the practice customization:
  - Risks and complications
  - Informed consent language
- Saving creates the next practice revision and writes the edited text back into the practice HTML template.

## Reference-form discovery
- `public/forms` is now the reference-template folder for the source package.
- `scripts/generate-reference-form-catalog.mjs` scans all `.html` files in that folder.
- It runs automatically before `npm run dev` and `npm run build`.
- Existing curated forms keep their curated metadata. A newly added HTML file appears automatically in Form Studio as a `Custom / Practice-defined` template after restart/rebuild.
- For a newly discovered template that does not yet have a curated schema, Form Studio derives its basic controls from the HTML in the browser so it can be customized and assigned without adding TypeScript by hand.

## Production database recommendation
The source-folder auto-discovery is convenient for the Vityls package, but production should ultimately support an administrator-controlled template import/publish process backed by FormDefinition + FormVersion records. A deployed practice should not require a source-code rebuild just to add a new template.
