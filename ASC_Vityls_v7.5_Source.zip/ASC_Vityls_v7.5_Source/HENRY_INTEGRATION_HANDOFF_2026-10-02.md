# ASC.Vityls — Clinical UX v1.0 Integration Handoff for Henry

## Status
Clinical UX concept is frozen and approved for integration. This package replaces the iframe-based evaluation concepts with native React components for the Dashboard patient cards, Patient Chart, and Station Workspace.

## Frontend/API boundary
Keep database table shapes behind the API/service layer. The frontend consumes stable semantic objects for patient, encounter, clinical concepts, provenance, workflow requirements, forms/documents, authentication, tasks/events, gates and audit.

## First connection path
Patient/Encounter → Dashboard card → Patient Chart → Front Office → Nursing → Anesthesia → Surgeon/Physician → OR Team → PACU/Discharge → Case Record.

## Station forms
Evidence Forms are not hard-coded. At runtime return every active Practice Form assigned to the current station and applicable to the encounter. Required metadata: practiceFormId, definition/version, title, station assignment, requirement mode (required/optional/conditional), completion method (electronic/paper/either), status, signature/auth requirements, gate relationship, document instance id when completed.

Paper completion is a completion method. Uploads must create immutable document artifacts with encounter, station, uploader, timestamp, source/completion method and verification metadata. AI/OCR may propose extracted values but must not silently verify or overwrite clinical data.

## Required API adapter operations
- getDashboard(date/location): cases + current station + readiness + exceptions + Nightingale brief
- getPatient(patientId): demographics + longitudinal profile + provenance
- getEncounter(encounterId): procedure/version, surgeon, room/time, workflow state
- getStationWorkspace(encounterId, station): known facts, missing/discrepant requirements, assigned forms, gate state, handoff state
- saveClinicalValue / verifyClinicalValue / resolveDiscrepancy
- authenticateStationReview
- getPracticeForms(station) / getEncounterFormInstances
- uploadCompletedDocument
- advanceEncounter / placeHold / clearHold
- getCaseRecord

## Invariants
- Collect once; verify when appropriate; reuse everywhere.
- Longitudinal patient facts and encounter facts remain distinct.
- Corrections preserve history/provenance.
- Authentication binds exact reviewed content/state, signer, role, timestamp, method and hash.
- Deterministic rules/gates control readiness; AI may assist but is not sole authority.
- Material upstream changes re-evaluate dependent requirements.
- Case Record is an encounter destination, not an eighth station.
- Canonical stations: Patient Portal, Front Office, Nursing, Anesthesia, Surgeon/Physician, OR Team, PACU/Discharge.

## Test before backend connection
Use fictitious patients only. Confirm Dashboard compact/expanded cards, station buttons route to the correct patient+station, Patient Chart routes into stations, Evidence Forms reflect station assignments, paper PDF upload is available, Back to Chart preserves patient context, and Save & Verify does not imply a PDF/document signature unless that exact document was reviewed.
