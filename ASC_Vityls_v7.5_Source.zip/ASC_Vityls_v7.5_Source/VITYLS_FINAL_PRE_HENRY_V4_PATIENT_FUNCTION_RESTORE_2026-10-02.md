# Vityls Final Pre-Henry v4 — Patient Function Restore

- Restored the mature PatientChartPage as the primary Patient workspace so the established Nightingale command functions remain testable.
- Chart Documents, Intake Forms, Billing, Collect Payment, Provider Notes, Messages, Print, E-Prescribe and Dictate Note again route to their established interactive chart functions rather than the temporary concept-only command panel.
- Retained the new station workspace routing from the patient chart.
- Fixed Billing & Payments and ASC Operations embedded styling by scoping the supplied standalone `:root` design variables to the Shadow DOM `:host`. This restores the intended section/card/table surfaces and Nightingale header colors.
- Health Journey redesign notes remain authoritative for the next patient-page presentation pass: journey content belongs in the main content area; Before the Day of Surgery appears for scheduled cases; Day of Surgery appears on DOS; top journey cards will carry richer event/task summaries.
