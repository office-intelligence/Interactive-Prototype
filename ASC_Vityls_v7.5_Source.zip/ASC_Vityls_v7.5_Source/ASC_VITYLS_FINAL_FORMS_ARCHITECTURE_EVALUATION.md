# ASC.Vityls — Forms-Based Architecture Evaluation Build

This build intentionally returns the user-facing clinical workflow to Forms + Form Studio while preserving the newer Vityls architecture underneath.

## Evaluation architecture
- Forms are the human interface; structured concepts remain the intended data architecture.
- The 27-template starter library is practice-configurable. No form is globally mandatory merely because Vityls supplies it.
- Form Studio is restored as the first-class administrator experience.
- Clinical stations are full-width, tablet-oriented Forms workspaces; the permanent Case Readiness right rail is removed.
- Every station form supports: Complete Electronically, Print PDF/browser print rendering, and Upload Completed for paper/scanned completion.
- Paper/scanned and electronic are completion methods of the same workflow requirement.
- Per-case form completion state and electronic drafts persist in browser storage for meaningful multi-session evaluation.
- Schedule/date case state also persists in browser storage for evaluation.
- Nightingale is represented as an intelligence layer behind forms rather than a competing user interface.

## Important evaluation limitation
Persistence is browser-local, not Henry's production database. Uploaded paper files are represented by completion metadata/file name in this evaluation build; the binary upload is not yet a durable chart artifact. Production should store the scanned artifact, immutable metadata, provenance, and optional human-confirmed Nightingale extraction.

## Product rule
Practice administrators decide which forms are active, assigned, required/optional/conditional, and whether electronic, paper, or either completion is accepted. Regulatory/compliance recommendations may be surfaced as guidance, but the SaaS configuration is practice-controlled.
