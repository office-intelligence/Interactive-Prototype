# ASC.Vityls — Database Handoff (v7.4)

*For Kevin Tehrani · prepared 2026-10-04 (PT) · goes with `ASC_Vityls_Database_Schema.sql`*

## What this is

Today the app keeps everything in the browser (`localStorage`, plus one IndexedDB database for uploaded PDF templates). That's fine for testing with made-up data, but it can't be used for real patients. This document shows **where each piece of browser data should live in PostgreSQL** and **which API calls the app needs**. Once those calls exist, you can swap the storage layer without redesigning the screens.

### How the swap works

- Encounter data already goes through one interface: `src/v6/dataLayer.ts` → `EncounterRepository`, used through the exported `repo` object. Write an `HttpRepository` that implements the same methods with `fetch()` calls, then change the single line `export const repo = new LocalStorageRepository()`.
- The v7 modules (`src/v7/providers.ts`, `invitations.ts`, `clearance.ts`, `billing.ts`, `myForms.ts`) each read and write their own keys through small `read()`/`write()` helpers. Each module gets its own HTTP client, and its public functions keep the same names.
- **Server-side only:** signatures, locks, content hashes, PIN checks, lockouts, token checks, invoice numbers and audit timestamps. In the test build the browser produces these values for demo purposes only. The real server should never trust a time or hash sent by the browser.
- **Multi-tenant:** every table has `practice_id`, and row-level security policies are already in the SQL. On each request the API runs `SET LOCAL app.practice_id = …` and `SET LOCAL app.user_id = …`, using the signed-in user's session.
- **PHI:** PHI columns carry a `COMMENT … 'PHI: …'`. `SELECT * FROM phi_columns;` lists them, so you can set up encryption, masking and access logging from that list.

## 1. Storage key → table map

`<case>` = case id. `<file>` = form template file, e.g. `Nursing_Admission.html`. `P` = `vityls:v6`.

### Encounter data (`src/v6/dataLayer.ts`, `repo`)

| Browser key | What it holds | PostgreSQL table(s) | Notes |
|---|---|---|---|
| `P:form:<case>:<file>` | One form on one case: values, labels, provenance, signatures, addenda, status, lock | `form_instances`, `form_values`, `form_value_history`, `signatures`, `addenda` | `values[key]` + `provenance[key]` → one `form_values` row for each field key. Every change also adds a `form_value_history` row. `signatures[]` → `signatures` (append-only). `addenda[]` → `addenda`. `lockedAt`/`lockedHash` → `form_instances.locked_at/locked_hash` |
| `P:forms:<case>` | List of forms started on the case | `form_instances` (query by `case_id`) | Becomes an index query, so no separate table |
| `P:facts:<case>` | Carry-forward facts (allergies, NPO, escort, vitals, PMH) and where each came from | `case_facts` | One row per `(case_id, concept)`. Powers prefill and carry-forward |
| `P:audit:<case>` | Append-only audit trail for the case | `audit_log` | `case_id` = the case. Hash-chained; the trigger blocks UPDATE and DELETE |
| `P:audit:practice` | Practice-level audit (provider invites, PIN reset, lock, unlock, deactivate, reactivate, account) | `audit_log` with `case_id IS NULL` | Written by `providerAudit()` in `src/v7/invitations.ts` |
| `P:stations:<case>` | Station verification (who verified, when) | `station_verifications` | Includes the "advance with exception" reason |
| `P:signers:<file>` | Signer setup from Form Studio (slots, sequential, initials pages) | `signer_configs`, `signer_slots`, `signer_initials_pages` | Initials statements: one line per clause, each line gets its own initials box (Admission cash-fee page = 2) |
| `P:actor` | Current demo user | Session (`users` + `user_roles`) | Comes from the auth token, not stored |

### Practice, providers, accounts (`src/v7/providers.ts`, `src/v7/invitations.ts`, `AdministrationPage.tsx`)

| Browser key | What it holds | Table(s) | Notes |
|---|---|---|---|
| `vityls:v7:providers` | Providers: name, degree, role, NPI, email, color, PIN hash, active, locked, pinFailures, deactivated*, credentialing app + history, onboarding | `providers`, `credential_applications`, `credential_status_history`, `credential_documents` | `color` → `color_hex` (any `#RRGGBB`; text color is worked out for AA contrast). Deactivated providers can't sign or be booked. Enforce this in the API too |
| `vityls:practice-providers:v1` | Short provider list mirrored for older screens | View on `providers` | Not stored separately |
| `vityls:v7:outbox` | Simulated outgoing email (invitation, PIN reset) | `invitations` | `transport` = 'smtp'/ESP in production |
| `vityls:v7:invite-tokens` | One-time link tokens (application, account, pin, pin-reset) with expiry and used/revoked | `invite_tokens` | Store **sha256(token)** only. Check and consume on the server |
| `vityls:v7:accounts` | Provider username and password hash | `users` (+ `providers.user_id`) | Use argon2id on the server; the browser hash is demo-only |
| `vityls:access-records:v1` | Older account-status records shown in Administration | `users` / `providers` status columns | Status values can be derived |
| `vityls:practice-users:v1` | Practice staff users | `users`, `user_roles`, `roles` | |
| `vityls:medical-director-provider:v1` | Which provider is Medical Director | `providers.is_medical_director` | |
| `vityls:station-config:v1` | Station list and switches | `stations` (`config` jsonb) | |
| `vityls:document-library:v1` | Practice document library | `form_templates` (+ object storage) | |
| `vityls:v7:application-draft:<provider>` | Autosaved membership application draft | `credential_applications.answers` (status 'Invited') | |
| Practice configuration (`PracticeConfig` in App state, seeded in `App.tsx`) | Name, address, phone, header style | `practices` (+ `settings` jsonb) | |

### Patients, cases, schedule

| Browser key | What it holds | Table(s) | Notes |
|---|---|---|---|
| `vityls:evaluation:date-cases` | All `PatientCase` records, grouped by date | `patients` + `cases` (+ `case_events`) | Patient demographics → `patients` (PHI). Encounter → `cases`. `encounterWorkflow` → `cases.workflow` jsonb |
| `vityls:evaluation:appointments` | Scheduler blocks (`AppointmentItem`) including block time | `appointments` | `isBlock` → `is_block`; `caseId` → `case_id`; day/hour → `starts_at/ends_at` |
| `vityls:evaluation:selected-date` | UI state (chosen day) | none (keep in browser) | |
| `vityls:schedule-visible-rooms:<…>` | Rooms shown in the scheduler | `rooms.visible_in_schedule` (or a per-user preference) | |
| `schedule_weekly_notes_db` | Weekly scheduler notes | `appointments` (notes) or a small `schedule_notes` table | Optional |
| `vityls:station-data:<patient>` | Older per-patient station scratch data | `form_values` / `case_facts` | Move it during migration, then drop |
| `vityls:case-form-status:*`, `vityls:case-form-draft:*`, `vityls:encounter-form:*`, `vityls:station-review:*` | Older form-status, draft and review data | `form_instances`, `form_values`, `station_verifications` | |
| `portal_apts_*`, `portal_forms_*`, `portal_intake_html_forms_*`, `portal_docs_*`, `portal_msgs_*`, `portal_rx_*`, `portal_bills_*` | Patient-portal demo data | `appointments`, `form_instances`, `clearance_documents`, (messages table, future), `invoices` | Patient-portal requests also filter by `patient_id` |

### Forms library and Form Studio

| Browser key | What it holds | Table(s) | Notes |
|---|---|---|---|
| Bundled `public/forms/*.html` | Library templates (as of v7.4, no signature fields) | `form_templates` (practice_id NULL) + `form_template_versions` | Load them once with a seed script |
| `vityls-form-template:<file>`, `vityls-master-form-template:<file>` | A practice's customized template HTML | `form_template_versions` (new version, `is_custom`) | Published versions can't be changed. A form instance points at the version it was filled on |
| `vityls-form-schema:<file>`, `vityls-master-form-schema:<file>` | Form Studio field schema | `form_template_versions.schema` | No `signature` field type |
| `vityls-master-form-history:<file>`, `vityls-form-revisions:<file>` | Template revision history | `form_template_versions` | |
| `vityls-form-workflow:<file>`, `vityls-form-assignments-v2`, `vityls-form-requirement:<file>` | Which station collects or reviews a form, and whether it's required | `form_station_assignments` | |
| `vityls-my-forms:<…>` | My Forms (forms the practice uses) | `form_station_assignments` | |
| IndexedDB `office-intelligence-local-test` | Uploaded PDF templates | `form_templates` + object storage (`storage_key`) | |

### Clearance, alerts, reviews (`src/v7/clearance.ts`)

| Browser key | What it holds | Table(s) | Notes |
|---|---|---|---|
| `vityls:v7:clearance-docs:<case>` | Received documents (labs, EKG, H&P…) incl. text and dataUrl | `clearance_documents` (+ object storage) | Don't store base64 in the database. Save the file to object storage and keep its `storage_key` |
| `vityls:v7:clearance-state:<case>` | Summary, clinician review, cleared | `clearance_summaries`, `clinical_alerts`, `clearance_reviews` | Drives the dashboard color: hold → pending → clear |

### Billing (`src/v7/billing.ts`)

| Browser key | What it holds | Table(s) | Notes |
|---|---|---|---|
| `vityls:v7:fee-schedules` | Time-based fee schedules (facility and anesthesia base + increments, surgeon fee, match rule) | `fee_schedules` | Add effective dates in production |
| `vityls:v7:invoices` | Invoices with lines, minutes, status, paid, manager override | `invoices`, `payments` | `paid` = sum of `payments`. `override` → `override_*` columns + `audit_log` 'invoice.override'. Invoice numbers are assigned by the server |

### UI-only keys (no table)

`vityls:v7:dashboard-open-cards` (which dashboard cards are expanded), `vityls-standard-header-style`, `vityls-patient-header`, `vityls:seed-version` (resets demo data), and the window events `vityls-*-updated`. These stay in the browser or become per-user preferences.

## 2. API endpoints the data layer needs

All paths are under `/api/v1`. The server takes the practice from the session. Every write adds an `audit_log` row on the server.

### Auth and accounts
| Method | Path | Used by |
|---|---|---|
| POST | `/auth/login` · `/auth/logout` · `/auth/refresh` | Sign-in |
| GET | `/me` | Current user, role, practice (replaces `P:actor`) |
| GET | `/invite/:token` | `resolveToken()` — check the link (ok/used/expired/revoked) |
| POST | `/invite/:token/application` | `submitApplication()` |
| POST | `/auth/activate` | `createAccount()` — username + password from an account link |
| POST | `/auth/signature-pin` | `setSignaturePin()` — from a pin or pin-reset link |
| POST | `/signatures/verify-pin` | PIN check at signing. The server counts failures and locks after 5 |

### Providers and credentialing
| Method | Path | Used by |
|---|---|---|
| GET/POST | `/providers` | Providers list / Add New Provider |
| GET/PATCH | `/providers/:id` | Edit (the server keeps fields the screen didn't send) |
| POST | `/providers/:id/invitations` | `sendCredentialInvite()` / Resend (sends the email, creates tokens) |
| POST | `/providers/:id/pin-reset` | Reset PIN (clears the PIN, emails a pin-reset link) |
| POST | `/providers/:id/unlock` | Unlock account |
| POST | `/providers/:id/deactivate` `{reason}` · `/providers/:id/reactivate` | Deactivate / Reactivate |
| GET/PATCH | `/providers/:id/application` | Credentialing steps |
| POST | `/providers/:id/application/documents` | Credential uploads (signed upload URL) |
| GET | `/outbox?providerId=` | Email preview / Outbox list |
| GET | `/audit?scope=practice` | "Provider account & credentialing audit" |

### Practice configuration
| Method | Path | Used by |
|---|---|---|
| GET/PUT | `/practice` | Practice Configuration page |
| GET/POST/PATCH | `/users`, `/roles` | Practice users |
| GET/PUT | `/rooms`, `/stations` | Rooms, station switches |

### Patients, cases, schedule
| Method | Path | Used by |
|---|---|---|
| GET/POST | `/patients` · GET/PATCH `/patients/:id` | Add Patient, chart header |
| GET | `/cases?date=YYYY-MM-DD` | Dashboard, Schedule (replaces `date-cases`) |
| POST/PATCH | `/cases` · `/cases/:id` | Book or update a case; stage and workflow changes |
| GET/POST/PATCH/DELETE | `/appointments?from=&to=&room=` · `/appointments/:id` | Scheduler grid, Block time (the server rejects deactivated providers) |
| POST | `/cases/:id/events` | OR event-time bar |
| GET/PUT | `/cases/:id/stations/:station/verification` | `get/setStationVerification()` |

### Forms (`EncounterRepository`)
| Method | Path | Repo method |
|---|---|---|
| GET | `/cases/:caseId/forms` | `listForms()` |
| GET | `/cases/:caseId/forms/:file` | `getForm()` |
| PUT | `/cases/:caseId/forms/:file` | `saveForm()` — values + provenance (the server rejects edits once locked) |
| POST | `/cases/:caseId/forms/:file/signatures` | Sign in the multi-signer panel (server time, PIN check, content hash; locks when all required signers are done) |
| POST | `/cases/:caseId/forms/:file/addenda` | Addendum after lock |
| GET/PUT | `/cases/:caseId/facts` | `getFacts()` / `putFacts()` (carry-forward) |
| POST | `/cases/:caseId/audit` · GET `/cases/:caseId/audit` | `audit()` / `getAudit()` |
| GET | `/form-templates` · `/form-templates/:file` | `getFormHtmlSync()` / `loadFormHtml()` (current published version) |
| POST | `/form-templates/:file/versions` | Save or publish from Form Studio |
| GET/PUT/DELETE | `/form-templates/:file/signers` | `get/save/clearSignerConfig()` |
| GET/PUT | `/form-templates/:file/assignments` | Forms & Workflow → stations / My Forms |

### Clearance
| Method | Path | Used by |
|---|---|---|
| GET/POST | `/cases/:id/clearance/documents` (signed upload URL) | Add clearance document |
| POST | `/cases/:id/clearance/summary` | Run the summarizer (rule-based or AI adapter, on the server) |
| POST | `/cases/:id/clearance/review` · `/cases/:id/clearance/clear` | Clinician review, Cleared |
| GET | `/cases/:id/clearance` | State, alerts, summary (dashboard color) |

### Billing
| Method | Path | Used by |
|---|---|---|
| GET/PUT | `/fee-schedules` | Fee schedules editor (on Kevin's Billing page) |
| GET | `/invoices?caseId=` · `/invoices` | Case invoices table |
| POST | `/cases/:id/invoices` `{facilityMin, anesthesiaMin, override?:{reason}}` | Generate invoice. Manager override is checked against the user's role on the server |
| PATCH | `/invoices/:id` | Mark sent / void |
| POST | `/invoices/:id/payments` | Record payment |

## 3. Suggested order of work

1. Auth + `/me`, then `practices`, `users`, `roles` with RLS turned on.
2. `HttpRepository` for forms, facts, audit and signatures. This is the clinical core, and prefill, carry-forward and locking depend on it.
3. Patients, cases, appointments (Dashboard and Schedule).
4. Providers, invitations, tokens, real email (replace `registerEmailTransport` with your email provider).
5. Clearance documents (object storage), summaries.
6. Billing.
7. A one-time import of a test browser's `localStorage` for QA. Not for production data, which must never come from a browser.
