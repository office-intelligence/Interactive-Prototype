import React, { useEffect, useRef } from 'react';
import billing from '../designReference/billing-embedded.json';
import operations from '../designReference/operations-embedded.json';

/** v7.4: `slots` lets live sections sit inside Kevin's page (light-DOM children with slot="v7-invoices" / slot="v7-fees") without changing his markup. */
export const ApprovedDesignPage: React.FC<{kind:'billing'|'operations'; onBack?:()=>void; slots?: boolean; children?: React.ReactNode}> = ({kind,onBack,slots,children}) => {
  const host = useRef<HTMLDivElement>(null);
  useEffect(()=>{
    if(!host.current) return;
    const shadow = host.current.shadowRoot || host.current.attachShadow({mode:'open'});
    const data = kind==='billing' ? billing : operations;
    // The supplied standalone HTML defines its palette on :root. Inside a ShadowRoot,
    // those custom properties must live on :host or var(--*) declarations resolve
    // incorrectly, which strips the intended white cards/table surfaces and green
    // Nightingale header. Preserve the supplied design exactly by translating only
    // that scope selector for embedding.
    const scopedStyle = data.style.replace(/:root\s*\{/g, ':host {');
    let main = data.main;
    if (slots && kind === 'billing') {
      const cfg = main.search(/<section class="card">\s*<div class="hd"><h2>Billing configuration/);
      if (cfg > 0) main = main.slice(0, cfg) + '<slot name="v7-invoices"></slot>\n' + main.slice(cfg);
      main = main + '<slot name="v7-fees"></slot>';
    }
    shadow.innerHTML = `<style>${scopedStyle}\n:host{display:block;background:var(--paper,#e8ece8);min-height:100%} .page{padding-top:22px!important;max-width:1280px!important} .card,.stat,.rep{background:var(--white,#fbfcfb)!important} ::slotted(*){display:block;margin-bottom:12px}</style><main class="page">${main}</main>`;
    if (slots && kind === 'billing') {
      const go = (name: string) => () => { const el = host.current?.querySelector(`[slot="${name}"]`) as HTMLElement | null; el?.scrollIntoView({ behavior: 'smooth', block: 'start' }); (el?.querySelector('[data-focus-target]') as HTMLElement | null)?.focus({ preventScroll: true }); };
      shadow.querySelectorAll('button').forEach((b) => {
        const t = (b.textContent || '').trim();
        if (t === 'Create invoice' || t === 'Patient invoices & self-pay') { b.addEventListener('click', go('v7-invoices')); b.setAttribute('data-wired', 'v7-invoices'); }
        if (t === 'Fee schedules') { b.addEventListener('click', go('v7-fees')); b.setAttribute('data-wired', 'v7-fees'); }
      });
    }
    const back=shadow.querySelector('.back');
    const handler=(e:Event)=>{e.preventDefault(); onBack?.();};
    back?.addEventListener('click',handler);
    // Preserve simple evaluation interactions from the supplied pages.
    shadow.querySelectorAll('.period button').forEach((b)=>b.addEventListener('click',()=>{
      shadow.querySelectorAll('.period button').forEach(x=>x.classList.remove('on')); b.classList.add('on');
      const custom=shadow.querySelector('#customRange') as HTMLElement|null;
      if(custom && (b as HTMLElement).id==='customRangeBtn'){custom.hidden=false;custom.style.display='inline-flex';}
    }));
    return ()=>back?.removeEventListener('click',handler);
  },[kind,onBack,slots]);
  return <div ref={host} className="w-full">{children}</div>;
};
