import React from 'react';
import { AlertTriangle, CheckCircle2, ChevronRight, Circle, Clock3, ShieldCheck } from 'lucide-react';
import type { PatientCase } from '../types';
import type { LocalFormTemplate, LocalPdfTemplate } from '../utils/localFormStudioDb';
import { useClearance } from '../v7/ClearanceWorkspace';
import { stationPlan } from '../v7/myForms';
import { repo } from '../v6/dataLayer';

type StepState = 'complete' | 'attention' | 'pending' | 'blocked';

interface Props {
  patient: PatientCase;
  htmlForms: LocalFormTemplate[];
  pdfForms: LocalPdfTemplate[];
  onOpenPreArrival: () => void;
  onOpenCheckIn: () => void;
  onOpenNursing: () => void;
  onOpenAnesthesia: () => void;
  onOpenSurgeon: () => void;
  onOpenOrTeam: () => void;
  onOpenPacu: () => void;
  onOpenFinal: () => void;
  workflowCounts?: Partial<Record<'patientPortal'|'frontOffice'|'nursing'|'anesthesia'|'surgeon'|'orTeam'|'pacu', number>>;
  onOpenIntake?: () => void; onOpenClearanceFiles?: () => void; onOpenReview?: () => void; onOpenScheduler?: () => void;
  showDayOfSurgery?: boolean; onOpenDayOfSurgery?: () => void; onHideDayOfSurgery?: () => void;
}

export const DayOfSurgeryJourney: React.FC<Props> = ({
  patient, htmlForms, pdfForms,
  onOpenPreArrival, onOpenCheckIn, onOpenNursing, onOpenAnesthesia, onOpenSurgeon, onOpenOrTeam, onOpenPacu, onOpenFinal, workflowCounts,
  onOpenIntake, onOpenClearanceFiles, onOpenReview, onOpenScheduler, showDayOfSurgery, onOpenDayOfSurgery, onHideDayOfSurgery,
}) => {
  const { docs: clrDocs, state: clr } = useClearance(patient.id);
  const intakeFiles = [...stationPlan('patientPortal').required, ...stationPlan('patientPortal').asNeeded];
  const intakeDone = intakeFiles.filter(f => repo.getForm(patient.id, f).status === 'locked').length;
  const journey=patient.encounterWorkflow?.status || 'ARRIVED';
  const appointmentDate = (patient.appointmentDate || '').trim();
  const scheduled = Boolean(appointmentDate || (patient.scheduledTime && !/not scheduled|hold/i.test(patient.scheduledTime)));
  const normalizeDate = (value:string) => {
    if (!value) return '';
    const d = new Date(value);
    if (Number.isNaN(d.getTime())) return value;
    return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
  };
  const now = new Date();
  const todayKey = `${now.getFullYear()}-${String(now.getMonth()+1).padStart(2,'0')}-${String(now.getDate()).padStart(2,'0')}`;
  const isDayOfSurgery = scheduled && normalizeDate(appointmentDate) === todayKey;
  const hasCriticalLab=patient.labs?.some(l=>l.status==='critical') || false;
  const portalComplete=patient.checkInStatus==='PORTAL_COMPLETE' || patient.checkInStatus==='OFFICE_VERIFIED';
  const officeVerified=patient.checkInStatus==='OFFICE_VERIFIED';
  const inOrOrLater=['READY_FOR_OR','IN_OR','PACU','READY_FOR_DISCHARGE','DISCHARGED','RECORD_COMPLETION','CASE_COMPLETE'].includes(journey);
  const pacuOrLater=['PACU','READY_FOR_DISCHARGE','DISCHARGED','RECORD_COMPLETION','CASE_COMPLETE'].includes(journey);
  const discharged=['DISCHARGED','RECORD_COMPLETION','CASE_COMPLETE'].includes(journey);

  const countFor=(workflow:'patientPortal'|'frontOffice'|'nursing'|'anesthesia'|'surgeon'|'orTeam'|'pacu') =>
    workflowCounts?.[workflow] ?? 0;

  const steps:Array<{
    id:string; title:string; owner:string; state:StepState; forms:number; action:()=>void;
  }>=[
    { id:'prearrival', title:'1. Pre-arrival Intake', owner:'Patient + Front Office', state:portalComplete?'complete':'attention', forms:countFor('patientPortal'), action:onOpenPreArrival },
    { id:'checkin', title:'2. Check-In → Nursing Review', owner:'Front Office', state:officeVerified || !['ARRIVED','CHECKING_IN'].includes(journey)?'complete':'attention', forms:0, action:onOpenCheckIn },
    { id:'nursing', title:'3. Pre-op Nursing', owner:'Nursing', state:hasCriticalLab?'blocked':['READY_FOR_ANESTHESIA','ANESTHESIA_EVALUATION','READY_FOR_OR','IN_OR','PACU','READY_FOR_DISCHARGE','DISCHARGED','RECORD_COMPLETION','CASE_COMPLETE'].includes(journey)?'complete':journey==='PREOP_NURSING'?'attention':'pending', forms:countFor('nursing'), action:onOpenNursing },
    { id:'anesthesia', title:'4. Anesthesia Readiness', owner:'Anesthesia', state:hasCriticalLab?'blocked':inOrOrLater?'complete':['READY_FOR_ANESTHESIA','ANESTHESIA_EVALUATION'].includes(journey)?'attention':'pending', forms:countFor('anesthesia'), action:onOpenAnesthesia },
    { id:'surgeon', title:'5. Surgeon / Procedure', owner:'Surgeon', state:inOrOrLater?'complete':['READY_FOR_OR'].includes(journey)?'attention':'pending', forms:countFor('surgeon'), action:onOpenSurgeon },
    { id:'orTeam', title:'6. OR Team / Time-Out', owner:'OR Team', state:['IN_OR','PACU','READY_FOR_DISCHARGE','DISCHARGED','RECORD_COMPLETION','CASE_COMPLETE'].includes(journey)?'complete':journey==='READY_FOR_OR'?'attention':'pending', forms:countFor('orTeam'), action:onOpenOrTeam },
    { id:'pacu', title:'7. PACU & Discharge', owner:'PACU / Nursing', state:discharged?'complete':pacuOrLater?'attention':'pending', forms:countFor('pacu'), action:onOpenPacu },
    { id:'final', title:'8. Final Case Record', owner:'Nightingale + Admin', state:journey==='CASE_COMPLETE'?'complete':discharged?'attention':'pending', forms:0, action:onOpenFinal },
  ];

  const complete=steps.filter(s=>s.state==='complete').length;

  const icon=(state:StepState)=>{
    if(state==='complete') return <CheckCircle2 className="w-4 h-4 text-emerald-700"/>;
    if(state==='blocked') return <AlertTriangle className="w-4 h-4 text-rose-700"/>;
    if(state==='attention') return <Clock3 className="w-4 h-4 text-amber-700"/>;
    return <Circle className="w-4 h-4 text-stone-400"/>;
  };
  const cls=(state:StepState)=>
    state==='complete'?'border-emerald-200 bg-emerald-50/70':
    state==='blocked'?'border-rose-200 bg-rose-50/70':
    state==='attention'?'border-amber-200 bg-amber-50/70':
    'border-stone-200 bg-white';

  if (!scheduled) return null;

  const intakeOk = !intakeFiles.length || intakeDone === intakeFiles.length;
  const ready = !!clr.cleared && intakeOk;
  const preSteps: { k: string; title: string; summary: string; tone: string; action?: () => void; testId: string }[] = [
    { k: '01 · Booking', title: 'Case booked', summary: appointmentDate ? `${appointmentDate} · ${patient.scheduledTime || 'time pending'}${patient.surgeon ? ` · ${patient.surgeon}` : ''}` : 'Scheduling hold: date required', tone: appointmentDate ? 'clear' : 'amber', action: onOpenScheduler, testId: 'ct-booking' },
    { k: '02 · Intake', title: 'Intake / at-home check-in', summary: !intakeFiles.length ? 'No intake forms in My Forms yet' : `${intakeDone} of ${intakeFiles.length} intake form${intakeFiles.length > 1 ? 's' : ''} complete`, tone: intakeFiles.length && intakeDone === intakeFiles.length ? 'clear' : intakeFiles.length ? 'amber' : 'neutral', action: onOpenIntake, testId: 'ct-intake' },
    { k: '03 · Clearance files', title: 'Pre-op clearance files', summary: clrDocs.length ? `${clrDocs.length} original document${clrDocs.length > 1 ? 's' : ''}: ${Array.from(new Set(clrDocs.map(d => d.type.replace(/ \(.*\)$/, '')))).join(', ')}` : 'No documents received yet', tone: clrDocs.length ? 'clear' : 'amber', action: onOpenClearanceFiles, testId: 'ct-files' },
    { k: '04 · Review & alerts', title: 'Nightingale review', summary: clr.review ? `Reviewed by ${clr.review.by}` : clrDocs.length ? 'Summary drafted · clinician review needed' : 'Waiting for documents', tone: clr.review ? 'clear' : 'amber', action: onOpenReview, testId: 'ct-review' },
    { k: '05 · Clearance', title: ready ? 'Ready for surgery' : clr.cleared ? 'Cleared · intake still open' : 'Cleared for surgery?', summary: clr.cleared ? `Cleared by ${clr.cleared!.by}` : clr.review ? 'Clinician decision pending' : 'After review is confirmed', tone: ready ? 'clear' : 'amber', action: onOpenReview, testId: 'ct-clearance' },
    { k: '06 · Day of surgery', title: 'Day of surgery stations', summary: `${steps.filter(s => s.id !== 'final' && s.state === 'complete').length} of ${steps.filter(s => s.id !== 'final').length} stations complete${isDayOfSurgery ? ' · today' : ''}`, tone: steps.filter(s => s.id !== 'final').every(s => s.state === 'complete') ? 'clear' : 'amber', action: onOpenDayOfSurgery, testId: 'ct-dayof' },
  ];

  return (
    <section id="day-of-surgery-journey-section" className="vy-card overflow-hidden" data-testid="case-tracker">
      <div className="px-5 py-4 border-b border-[#dfe5e1] flex items-center justify-between gap-3 flex-wrap">
        <div>
          <div className="vy-kicker">Case Tracker</div>
          <h3 className="vy-card-title">Booking to surgery readiness</h3>
        </div>
        <span className={ready ? 'vy-chip-ok' : 'vy-chip-warn'} data-testid="ct-status">{ready ? 'Ready for surgery' : clr.cleared ? 'Cleared · intake open' : 'In progress'}</span>
      </div>

      <div className="px-5 pt-4">
        <div className="vy-section-title">Before the day of surgery</div>
        <p className="text-[14px] text-[#3a463f] mt-1">Follows the case from booking through intake, clearance documents, review and the clinician’s clearance decision. Tap a stage to open it.</p>
      </div>
      <div className="p-4 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 2xl:grid-cols-6 gap-2">
        {preSteps.map(step => <button type="button" key={step.k} data-testid={step.testId} onClick={step.action} disabled={!step.action} className={`text-left min-h-[112px] border rounded-lg p-3 transition-shadow hover:shadow-sm ${step.tone==='clear'?'bg-[#f3faf6] border-[#c5e3d3]':step.tone==='amber'?'bg-[#fbf4e6] border-[#ead9b0]':'bg-white border-[#dfe5e1]'}`}>
          <div className="vy-kicker">{step.k}</div>
          <div className="text-[15px] font-semibold text-[#14211a] mt-1.5">{step.title}</div>
          <div className="text-[13.5px] leading-snug text-[#3a463f] mt-1.5">{step.summary}</div>
        </button>)}
      </div>

      {showDayOfSurgery && <div id="dayOfSurgery-section" className="scroll-mt-4" data-testid="day-of-surgery">
        <div className="px-4 pt-1 border-t border-stone-200 flex items-start justify-between gap-3">
          <div><div className="vy-section-title mt-4">Day of surgery</div>
          <p className="text-[14px] text-[#3a463f] mt-1">{isDayOfSurgery ? 'Today is the procedure date.' : 'The procedure date is not today; stations can still be reviewed.'} Each station confirms carried-forward information, resolves exceptions, records key events and authenticates responsibility. Tap a station to open its workstation.</p></div>
          {onHideDayOfSurgery && <button type="button" className="vy-btn vy-btn-ghost mt-3 shrink-0" onClick={onHideDayOfSurgery} data-testid="hide-dayOfSurgery">Hide</button>}
        </div>
        <div className="p-4 grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-2.5">
          {steps.filter(s=>s.id!=='final').map(step=><button key={step.id} onClick={step.action} className={`text-left rounded-[3px] border p-3 hover:shadow-sm transition-all ${cls(step.state)}`}>
            <div className="flex items-start justify-between gap-2">
              <div className="flex items-center gap-2 min-w-0">{icon(step.state)}<div className="text-xs font-black text-stone-900">{step.title.replace(/^\d+\.\s*/, '')}</div></div>
              <ChevronRight className="w-4 h-4 text-stone-400 shrink-0"/>
            </div>
            <div className="text-[10px] text-stone-500 mt-2">Owner: {step.owner}</div>
            <div className="text-[10px] text-stone-600 mt-1">{step.state==='complete'?'Completed and carried forward to the next station.':step.state==='attention'?'Current station requires review or completion.':step.state==='blocked'?'A blocking exception must be resolved before advancing.':'Waiting for prior workflow stages.'}</div>
            <div className="flex items-center justify-between gap-2 mt-2">
              <span className="text-[9px] uppercase tracking-wide font-black text-stone-500">{step.state==='complete'?'Complete':step.state==='attention'?'Needs attention':step.state==='blocked'?'Blocked':'Not started'}</span>
              {step.forms>0 && <span className="text-[9.5px] font-bold text-indigo-700">{step.forms} requirement{step.forms===1?'':'s'}</span>}
            </div>
          </button>)}
        </div>
      </div>}
    </section>
  );
};
