import React, { useEffect, useMemo, useState } from 'react';
import { bundledFetch } from '../v6/formSource';
import { ArrowLeft, CheckCircle2, Eye, GripVertical, Plus, Save, Trash2, WandSparkles, History } from 'lucide-react';
import { ASC_DEFAULT_FORM_LIBRARY, type AscDefaultField } from '../data/ascDefaultFormLibrary';

type WorkflowKey = 'patientPortal' | 'frontOffice' | 'nursing' | 'anesthesia' | 'surgeon' | 'orTeam' | 'pacu';
type WorkflowRule = { enabled: boolean };
type WorkflowMap = Record<WorkflowKey, WorkflowRule>;

export interface CustomizerFormRef {
  title: string;
  file: string;
  category: string;
  audience: string;
  stage: string;
}

interface Props {
  form: CustomizerFormRef;
  onBack: () => void;
  onShowToast?: (message: string) => void;
}

const WORKFLOWS: { key: WorkflowKey; label: string; note: string }[] = [
  { key: 'patientPortal', label: 'Patient Portal', note: 'Patient completes or reviews remotely.' },
  { key: 'frontOffice', label: 'Front Office', note: 'Registration, demographics and administrative intake.' },
  { key: 'nursing', label: 'Nursing', note: 'Pre-op, OR, PACU and nursing documentation.' },
  { key: 'anesthesia', label: 'Anesthesia', note: 'Anesthesia questionnaires, evaluations, consents and records.' },
  { key: 'surgeon', label: 'Surgeon / Physician', note: 'Provider clearances, orders, consents and operative documentation.' },
  { key: 'orTeam', label: 'OR Team', note: 'Procedure room / time-out / intra-op workflow.' },
  { key: 'pacu', label: 'PACU / Discharge', note: 'Recovery and discharge workflow.' },
];

const blankWorkflow = (): WorkflowMap => ({
  patientPortal: { enabled: false },
  frontOffice: { enabled: false },
  nursing: { enabled: false },
  anesthesia: { enabled: false },
  surgeon: { enabled: false },
  orTeam: { enabled: false },
  pacu: { enabled: false },
});

function defaultWorkflow(_form: CustomizerFormRef): WorkflowMap { return blankWorkflow(); }

const schemaKey = (file: string) => `vityls-form-schema:${file}`;
const workflowKey = (file: string) => `vityls-form-workflow:${file}`;
const htmlTemplateKey = (file: string) => `vityls-form-template:${file}`;
const masterHtmlKey = (file: string) => `vityls-master-form-template:${file}`;
const masterSchemaKey = (file: string) => `vityls-master-form-schema:${file}`;
const masterHistoryKey = (file: string) => `vityls-master-form-history:${file}`;
const revisionHistoryKey = (file: string) => `vityls-form-revisions:${file}`;

type PracticeFormRevision = {
  revision: string;
  title: string;
  fields: AscDefaultField[];
  html: string;
  savedAt: string;
};

function nextMinorRevision(value?: string) {
  if (!value) return '1.0';
  const match = value.match(/^(\d+)\.(\d+)$/);
  if (!match) return '1.0';
  return `${match[1]}.${Number(match[2]) + 1}`;
}

function escapeRegExp(value: string) { return value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); }
function escapeTextareaValue(value: string) { return value.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;'); }
function applyEditableTextToHtml(html: string, fields: AscDefaultField[]) {
  let next = html;
  fields.filter(f => f.type === 'textarea' && f.name).forEach(field => {
    const pattern = new RegExp(`(<textarea\\b[^>]*\\bname=[\"']${escapeRegExp(field.name!)}[\"'][^>]*>)([\\s\\S]*?)(</textarea>)`, 'i');
    if (pattern.test(next)) next = next.replace(pattern, (_m, open, _old, close) => `${open}${escapeTextareaValue(field.defaultValue || '')}${close}`);
  });
  return next;
}

const choiceType = (type: string) => ['checkbox','radio','select'].includes(type);
function applySchemaToHtml(html: string, fields: AscDefaultField[], originalFields: AscDefaultField[]) {
  if (typeof DOMParser === 'undefined') return applyEditableTextToHtml(html, fields);
  const doc = new DOMParser().parseFromString(html, 'text/html');
  const currentNames = new Set(fields.map(f => f.name).filter(Boolean));
  // Only remove controls that belonged to the known template schema. This protects
  // the standard patient/encounter header and other structural controls.
  originalFields.filter(f => f.name && !currentNames.has(f.name)).forEach(f => {
    doc.querySelectorAll(`[name="${CSS.escape(f.name!)}"]`).forEach(el => {
      const id = (el as HTMLElement).id;
      if (id) doc.querySelectorAll(`label[for="${CSS.escape(id)}"]`).forEach(l => l.remove());
      const wrapper = el.closest('.field, .form-field, .field-row, .input-group');
      (wrapper || el).remove();
    });
  });
  fields.forEach(field => {
    if (!field.name) return;
    const controls = Array.from(doc.querySelectorAll<HTMLElement>(`[name="${CSS.escape(field.name)}"]`));
    controls.forEach(el => {
      const id = el.id;
      if (id) {
        const label = doc.querySelector(`label[for="${CSS.escape(id)}"]`);
        if (label && field.label) label.textContent = field.label + (field.required ? ' *' : '');
      }
      if (field.required) el.setAttribute('required',''); else el.removeAttribute('required');
    });
  });
  let out = '<!doctype html>\n' + doc.documentElement.outerHTML;
  return applyEditableTextToHtml(out, fields);
}


function mergeTemplateMetadata(savedFields: AscDefaultField[], templateFields: AscDefaultField[], file: string): AscDefaultField[] {
  const merged = savedFields.map(saved => {
    const base = templateFields.find(t => t.id === saved.id || (saved.name && t.name === saved.name) || t.label === saved.label);
    if (!base) return saved;
    return {
      ...base,
      ...saved,
      name: saved.name ?? base.name,
      defaultValue: saved.defaultValue ?? base.defaultValue,
      options: saved.options ?? (base.options ? [...base.options] : undefined),
    };
  });

  // Migration for forms that gained practice-editable policy/consent blocks after an earlier
  // practice schema had already been saved. Preserve the practice schema, but add the new
  // editable text blocks so the administrator does not have to reset the form to Standard.
  if (file === 'Anesthesia_Consent.html') {
    for (const base of templateFields.filter(t => ['anesthesia-consent-risks','anesthesia-consent-consentlanguage'].includes(t.id))) {
      if (!merged.some(f => f.id === base.id || (base.name && f.name === base.name))) merged.push({ ...base, options: base.options ? [...base.options] : undefined });
    }
  }
  return merged;
}

function deriveFieldsFromHtml(html: string): AscDefaultField[] {
  if (typeof DOMParser === 'undefined' || !html) return [];
  const doc = new DOMParser().parseFromString(html, 'text/html');
  const controls = Array.from(doc.querySelectorAll<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>('input, textarea, select'));
  const seen = new Set<string>();
  const fields: AscDefaultField[] = [];
  controls.forEach((el, index) => {
    const typeAttr = (el.getAttribute('type') || '').toLowerCase();
    if (typeAttr === 'hidden' || typeAttr === 'button' || typeAttr === 'submit') return;
    const name = el.getAttribute('name') || el.id || `field-${index+1}`;
    const dedupe = `${el.tagName}:${name}`;
    if (seen.has(dedupe)) return;
    seen.add(dedupe);
    const labelEl = el.id ? doc.querySelector(`label[for="${CSS.escape(el.id)}"]`) : null;
    const wrappingLabel = el.closest('label');
    const label = (labelEl?.textContent || wrappingLabel?.textContent || el.getAttribute('aria-label') || name)
      .replace(/\s+/g, ' ').trim().replace(/^[-•]\s*/, '');
    let type: AscDefaultField['type'] = 'text';
    if (el.tagName === 'TEXTAREA') type = 'textarea';
    else if (el.tagName === 'SELECT') type = 'select';
    else if (typeAttr === 'checkbox') type = 'checkbox';
    else if (typeAttr === 'radio') type = 'radio';
    else if (typeAttr === 'date') type = 'date';
    const options = el.tagName === 'SELECT'
      ? Array.from((el as HTMLSelectElement).options).map(o => o.textContent?.trim() || o.value).filter(Boolean)
      : (type === 'checkbox' || type === 'radio')
      ? controls.filter(c => (c.getAttribute('name') || c.id) === name).map(c => c.getAttribute('value') || c.closest('label')?.textContent?.replace(/\s+/g,' ').trim() || 'Option')
      : undefined;
    fields.push({
      id: `auto-${name.replace(/[^a-z0-9]+/gi,'-').toLowerCase()}-${index}`,
      label: label || name,
      type,
      required: el.hasAttribute('required'),
      owner: 'Practice-defined',
      source: 'Patient',
      name,
      defaultValue: el.tagName === 'TEXTAREA' ? (el.textContent || '') : undefined,
      options: options?.length ? Array.from(new Set(options)) : undefined,
    });
  });
  return fields;
}

export const FullScreenFormCustomizer: React.FC<Props> = ({ form, onBack, onShowToast }) => {
  const template = useMemo(() => ASC_DEFAULT_FORM_LIBRARY.find(t => t.sourceFile === form.file || t.title === form.title), [form]);
  const [title, setTitle] = useState(form.title);
  const [fields, setFields] = useState<AscDefaultField[]>(() => template?.fields.map(f => ({ ...f, options: f.options ? [...f.options] : undefined })) || []);
  const [workflow, setWorkflow] = useState<WorkflowMap>(() => defaultWorkflow(form));
  const [preview, setPreview] = useState(false);
  const [dirty, setDirty] = useState(false);
  const [revision, setRevision] = useState<string>('Standard');
  const [revisionHistory, setRevisionHistory] = useState<PracticeFormRevision[]>([]);
  const [workflowSaved, setWorkflowSaved] = useState(true);
  const [lastAction, setLastAction] = useState('No unpublished changes');

  useEffect(() => {
    try {
      const savedSchema = JSON.parse(localStorage.getItem(masterSchemaKey(form.file)) || localStorage.getItem(schemaKey(form.file)) || 'null');
      const savedWorkflow = JSON.parse(localStorage.getItem(workflowKey(form.file)) || 'null');
      if (savedSchema?.fields) {
        setTitle(savedSchema.title || form.title);
        setFields(template?.fields ? mergeTemplateMetadata(savedSchema.fields, template.fields, form.file) : savedSchema.fields);
        setRevision(savedSchema.revision || '1.0');
      } else {
        setRevision('Standard');
        if (!template?.fields?.length) {
          bundledFetch(form.file).then(r => r.ok ? r.text() : '').then(html => {
            const derived = deriveFieldsFromHtml(html);
            if (derived.length) setFields(derived);
          }).catch(() => {});
        }
      }
      const savedHistory = JSON.parse(localStorage.getItem(revisionHistoryKey(form.file)) || '[]');
      if (Array.isArray(savedHistory)) setRevisionHistory(savedHistory);
      if (savedWorkflow) { const migrated = blankWorkflow(); WORKFLOWS.forEach(w => { migrated[w.key].enabled = Boolean(savedWorkflow[w.key]?.enabled ?? savedWorkflow[w.key] === true); }); setWorkflow(migrated); }
    } catch {/* keep defaults */}
  }, [form.file, form.title, template]);

  const markFields = (next: AscDefaultField[]) => { setFields(next); setDirty(true); };
  const updateField = (id: string, patch: Partial<AscDefaultField>) => markFields(fields.map(f => f.id === id ? { ...f, ...patch } : f));
  const removeField = (id: string) => markFields(fields.filter(f => f.id !== id));
  const addField = () => markFields([...fields, { id: `custom-${Date.now()}`, label: 'New field', type: 'text', required: false, owner: 'Practice-defined', source: 'Patient' }]);
  const addOption = (id: string) => markFields(fields.map(f => f.id === id ? { ...f, options: [...(f.options || []), `Option ${(f.options?.length || 0) + 1}`] } : f));
  const updateOption = (id: string, index: number, value: string) => markFields(fields.map(f => {
    if (f.id !== id) return f;
    const options = [...(f.options || [])]; options[index] = value; return { ...f, options };
  }));
  const removeOption = (id: string, index: number) => markFields(fields.map(f => f.id === id ? { ...f, options: (f.options || []).filter((_, i) => i !== index) } : f));

  const setRule = (key: WorkflowKey, enabled: boolean) => {
    setWorkflow(prev => ({ ...prev, [key]: { enabled } }));
    setWorkflowSaved(false);
  };

  const save = async () => {
    const savedAt = new Date().toISOString();
    const priorSchema = JSON.parse(localStorage.getItem(schemaKey(form.file)) || 'null');
    const nextRevision = priorSchema?.fields ? nextMinorRevision(priorSchema.revision || '1.0') : '1.0';

    let revisedHtml = '';
    try {
      const existing = localStorage.getItem(masterHtmlKey(form.file)) || localStorage.getItem(htmlTemplateKey(form.file)) || await bundledFetch(form.file).then(r => r.text());
      revisedHtml = applySchemaToHtml(existing, fields, template?.fields || []);
      localStorage.setItem(htmlTemplateKey(form.file), revisedHtml);
    } catch {
      // Schema/workflow still save even if the static HTML preview is temporarily unavailable.
    }

    const schemaRecord = { title, file: form.file, fields, revision: nextRevision, savedAt };
    localStorage.setItem(schemaKey(form.file), JSON.stringify(schemaRecord));
    localStorage.setItem(workflowKey(form.file), JSON.stringify(workflow));

    const assignments = Object.entries(workflow).filter(([, r]) => r.enabled).map(([key]) => ({
      form: title, file: form.file, workflow: key, savedAt
    }));
    const all = JSON.parse(localStorage.getItem('vityls-form-assignments-v2') || '{}');
    all[form.file] = assignments;
    localStorage.setItem('vityls-form-assignments-v2', JSON.stringify(all));
    window.dispatchEvent(new Event('vityls-form-workflow-updated'));

    const priorHistory = JSON.parse(localStorage.getItem(revisionHistoryKey(form.file)) || '[]');
    const history: PracticeFormRevision[] = Array.isArray(priorHistory) ? priorHistory : [];
    const record: PracticeFormRevision = {
      revision: nextRevision,
      title,
      fields: fields.map(f => ({ ...f, options: f.options ? [...f.options] : undefined })),
      html: revisedHtml,
      savedAt,
    };
    const updatedHistory = [...history.filter(r => r.revision !== nextRevision), record];
    localStorage.setItem(revisionHistoryKey(form.file), JSON.stringify(updatedHistory));
    setRevisionHistory(updatedHistory);
    setRevision(nextRevision);

    setDirty(false);
    setLastAction(`Draft v${nextRevision} saved — not yet active in patient care`);
    onShowToast?.(`${title}: Draft v${nextRevision} saved. The published clinical form has NOT changed.`);
  };

  const publishMaster = async () => {
    const savedAt = new Date().toISOString();
    const source = localStorage.getItem(masterHtmlKey(form.file)) || localStorage.getItem(htmlTemplateKey(form.file)) || await bundledFetch(form.file).then(r => r.text());
    const revisedHtml = applySchemaToHtml(source, fields, template?.fields || []);
    const prior = JSON.parse(localStorage.getItem(masterSchemaKey(form.file)) || 'null');
    const nextRevision = prior?.revision ? nextMinorRevision(prior.revision) : '1.0';
    const record = { title, file: form.file, fields, revision: nextRevision, savedAt, status: 'Published Master' };
    localStorage.setItem(masterHtmlKey(form.file), revisedHtml);
    localStorage.setItem(masterSchemaKey(form.file), JSON.stringify(record));
    localStorage.setItem(htmlTemplateKey(form.file), revisedHtml); // compatibility with runtime renderers
    localStorage.setItem(schemaKey(form.file), JSON.stringify(record));
    const history = JSON.parse(localStorage.getItem(masterHistoryKey(form.file)) || '[]');
    localStorage.setItem(masterHistoryKey(form.file), JSON.stringify([...(Array.isArray(history)?history:[]), { ...record, html: revisedHtml }]));
    setRevision(nextRevision);
    setDirty(false);
    window.dispatchEvent(new Event('vityls-master-forms-updated'));
    setLastAction(`Published v${nextRevision} — active for new form instances`);
    onShowToast?.(`${title}: Version ${nextRevision} published. Existing completed/signed records remain unchanged; new form instances use this version.`);
  };

  const saveWorkflowAssignments = () => {
    const savedAt = new Date().toISOString();
    localStorage.setItem(workflowKey(form.file), JSON.stringify(workflow));
    const assignments = Object.entries(workflow).filter(([, r]) => r.enabled).map(([key]) => ({ form: title, file: form.file, workflow: key, savedAt }));
    const all = JSON.parse(localStorage.getItem('vityls-form-assignments-v2') || '{}');
    all[form.file] = assignments;
    localStorage.setItem('vityls-form-assignments-v2', JSON.stringify(all));
    window.dispatchEvent(new Event('vityls-form-workflow-updated'));
    setWorkflowSaved(true);
    const labels = WORKFLOWS.filter(w => workflow[w.key].enabled).map(w => w.label);
    setLastAction(`Workflow assignments saved — ${labels.length ? labels.join(', ') : 'not assigned'}`);
    onShowToast?.(`${title}: workflow assignments saved${labels.length ? ` to ${labels.join(', ')}` : ' (no active workflow)'}.`);
  };

  const exportMasterSet = () => {
    const payload: Record<string, unknown> = { exportedAt: new Date().toISOString(), format: 'Vityls ASC Master Form Template Set', templates: {} };
    const templates = payload.templates as Record<string, unknown>;
    Object.keys(localStorage).filter(k => k.startsWith('vityls-master-form-')).forEach(k => {
      const raw = localStorage.getItem(k);
      try { templates[k] = JSON.parse(raw || 'null'); } catch { templates[k] = raw; }
    });
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob); const a = document.createElement('a');
    a.href = url; a.download = `Vityls_ASC_Master_Form_Template_Set_${new Date().toISOString().slice(0,10)}.json`; a.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
    onShowToast?.('Exported the current Vityls master form template set. Keep this file as the portable source for the next build.');
  };

  const requiredCount = fields.filter(f => f.required).length;
  const enabledCount = Object.values(workflow).filter(r => r.enabled).length;

  return (
    <div className="fixed inset-0 z-[120] bg-[#F7F8F5] overflow-y-auto">
      <div className="sticky top-0 z-20 bg-[#14432E] text-white border-b border-[#0D3323] shadow-sm">
        <div className="px-5 sm:px-7 py-3 flex items-center gap-3">
          <button onClick={onBack} className="p-2 rounded-lg hover:bg-white/10" title="Back to Form Library"><ArrowLeft className="w-5 h-5"/></button>
          <div className="min-w-0">
            <div className="text-[13px] uppercase tracking-[0.14em] text-[#F0D89A] font-black">Form Studio · Full-screen customization</div>
            <h1 className="text-lg sm:text-xl font-black text-white truncate">{title}</h1>
          </div>
          <div className="ml-auto flex items-center gap-2">
            <span className="hidden sm:inline text-[13px] text-white/70">{dirty ? 'Unsaved changes' : 'Saved'}</span>
            <button onClick={() => setPreview(v => !v)} className="px-3 py-2 rounded-lg bg-white/10 border border-white/15 text-[13px] font-bold flex items-center gap-1.5"><Eye className="w-4 h-4"/>{preview ? 'Edit' : 'Preview'}</button>
            <button onClick={save} className="px-3 py-2 rounded-lg bg-white/10 border border-white/15 text-white text-[13px] font-black flex items-center gap-1.5"><Save className="w-4 h-4"/>Save Draft</button>
            <button onClick={publishMaster} className="px-3 py-2 rounded-lg bg-[#D9A448] text-[#26382D] text-[13px] font-black">Publish Update</button>
            <button onClick={exportMasterSet} className="px-3 py-2 rounded-lg bg-[#1F6E52] border border-white/10 text-white text-[13px] font-black">Export Master Set</button>
          </div>
        </div>
      </div>

      <main className="max-w-[1500px] mx-auto p-5 sm:p-7 space-y-5">
        <div className="grid grid-cols-1 xl:grid-cols-[1.1fr_1fr] gap-4">
          <section className="bg-white rounded-xl border border-[#DCE3DD] p-4 sm:p-5">
            <div className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-[#1F6E52]"/><h2 className="font-black text-sm text-[#20352B]">Form identity & automation</h2></div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mt-4">
              <label className="text-[13px] font-bold text-[#59675F]">Form title<input value={title} onChange={e=>{setTitle(e.target.value);setDirty(true)}} className="mt-1 w-full px-3 py-2.5 rounded-lg border border-[#DCE3DD] text-sm font-semibold"/></label>
              <div><div className="text-[13px] font-bold text-[#59675F]">Source template</div><div className="mt-1 px-3 py-2.5 rounded-lg bg-[#F4EFE3] border border-[#E7D9B6] text-[13px] font-bold text-[#765B24]">{template ? `${template.title} · ${template.sourceFile}` : form.file}</div></div>
            </div>
            <div className="mt-3 rounded-lg border border-[#DCE3DD] bg-[#FAFBF9] px-3 py-2.5 flex items-start gap-2">
              <History className="w-4 h-4 text-[#1F6E52] mt-0.5 shrink-0"/>
              <div>
                <div className="text-[13px] font-black text-[#20352B]">FORM STATUS · {dirty ? 'UNSAVED CHANGES' : revision === 'Standard' ? 'VITYLS STARTER' : `VERSION ${revision}`} · {workflowSaved ? 'WORKFLOW SAVED' : 'WORKFLOW CHANGES NOT SAVED'}</div>
                <div className="text-[13px] text-[#56625a] mt-0.5">Save Draft preserves changes without affecting patient care. Publish Update activates a new version for new form instances; completed/signed records remain tied to their original version. Workflow assignments are saved separately and persist across later form edits.</div>
                {revisionHistory.length > 0 && <div className="text-[13px] text-[#1F6E52] mt-1 font-bold">{revisionHistory.length} saved practice revision{revisionHistory.length===1?'':'s'} retained.</div>}
              </div>
            </div>
            <div className="flex flex-wrap gap-2 mt-4 text-[13px] font-bold"><span className="px-2 py-1 rounded-full bg-[#E7F1F3] text-[#1F6E52]">{fields.length} fields</span><span className="px-2 py-1 rounded-full bg-[#F4EFE3] text-[#765B24]">{requiredCount} required</span><span className="px-2 py-1 rounded-full bg-[#F1F3EC] text-[#425149]">{enabledCount} workflow{enabledCount===1?'':'s'}</span></div>
          </section>

          <section className="bg-[#EAF8F3] rounded-xl border border-[#BFE6D6] p-4 sm:p-5">
            <div className="flex items-center gap-2 text-[#14432E] font-black text-sm"><WandSparkles className="w-4 h-4"/>Nightingale design checks</div>
            <div className="mt-3 rounded-lg border border-[#B7DDD0] bg-[#F1FAF6] px-3 py-2 text-[13px] font-bold text-[#1F6E52]">✓ {lastAction}</div><div className="mt-3 flex items-center justify-between gap-3"><div className="text-[13px] text-[#66736C]">Workflow assignment controls where the same published form appears. Editing/publishing later does not require reassignment.</div><button onClick={saveWorkflowAssignments} className="shrink-0 px-3 py-2 rounded-lg bg-[#1F6E52] text-white text-[13px] font-black flex items-center gap-1.5"><Save className="w-4 h-4"/>Save Workflow Assignments</button></div><div className="mt-3 space-y-2 text-[13px] text-[#294A3A]"><div>✓ A form can appear at more than one care-team gate without duplicating the clinical record.</div><div>✓ Opening and reviewing the same record serves the review/verification function; a separate Verify assignment is unnecessary.</div><div>✓ Signature requirements are derived from the signature fields already built into each form.</div><div>✓ Workflow assignment only controls where the form is available.</div></div>
          </section>
        </div>

        <section className="bg-white rounded-xl border border-[#DCE3DD] overflow-hidden">
          <div className="px-4 py-3 bg-[#F6F8F5] border-b border-[#DCE3DD] flex items-center justify-between gap-3"><div><h2 className="font-black text-sm text-[#20352B]">Workflow access</h2><p className="text-[13px] text-[#66736C] mt-0.5">Check each care-team workflow where this form should be available. Review is implicit when the record is opened; signatures are determined by the signature fields in the form.</p></div></div>
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-0">
            {WORKFLOWS.map(w => { const rule = workflow[w.key]; return <label key={w.key} className={`p-4 border-b border-r border-[#EEF0ED] flex items-start gap-3 cursor-pointer ${rule.enabled?'bg-[#EAF8F3]':''}`}><input aria-label={`Use in ${w.label}`} type="checkbox" checked={rule.enabled} onChange={e=>setRule(w.key,e.target.checked)} className="w-4 h-4 mt-0.5 accent-[#1F6E52]"/><span><span className="block font-bold text-[13px] text-[#20352B]">{w.label}</span><span className="block text-[13px] text-[#7A857F] mt-0.5">{w.note}</span></span></label>})}
          </div>
        </section>

        {!preview ? <section className="bg-white rounded-xl border border-[#DCE3DD] overflow-hidden">
          <div className="px-4 py-3 bg-[#F6F8F5] border-b border-[#DCE3DD] flex items-center justify-between"><div className="font-black text-sm text-[#20352B]">Form schema & choice options</div><button onClick={addField} className="px-3 py-1.5 rounded-lg bg-[#14432E] text-white text-[13px] font-bold flex items-center gap-1"><Plus className="w-3.5 h-3.5"/>Add Field</button></div>
          <div className="divide-y divide-[#EEF0ED]">{fields.map(field => <div key={field.id} className="p-3 space-y-2">
            <div className="grid grid-cols-[20px_1fr] lg:grid-cols-[20px_2fr_1fr_1fr_auto] gap-3 items-center"><GripVertical className="w-4 h-4 text-[#BAC3BD]"/><input value={field.label} onChange={e=>updateField(field.id,{label:e.target.value})} className="px-2.5 py-2 rounded-lg border border-[#DCE3DD] text-[13px] font-semibold"/><select value={field.type} onChange={e=>updateField(field.id,{type:e.target.value as any, options:choiceType(e.target.value)?(field.options?.length?field.options:['Yes','No']):undefined})} className="px-2 py-2 rounded-lg border border-[#DCE3DD] bg-white text-[13px]"><option>text</option><option>textarea</option><option>checkbox</option><option>radio</option><option>select</option><option>date</option><option>clinical-list</option><option>score</option></select><input value={field.owner || ''} onChange={e=>updateField(field.id,{owner:e.target.value})} className="px-2.5 py-2 rounded-lg border border-[#DCE3DD] text-[13px]"/><div className="flex items-center gap-2"><label className="flex items-center gap-1 text-[13px] font-bold text-[#59675F]"><input type="checkbox" checked={field.required} onChange={e=>updateField(field.id,{required:e.target.checked})}/>Required</label><button onClick={()=>removeField(field.id)} className="p-1.5 text-[#9AA49E] hover:text-red-600"><Trash2 className="w-3.5 h-3.5"/></button></div></div>
            {field.type === 'textarea' && (field.defaultValue !== undefined || field.name) && <div className="ml-8 rounded-xl bg-[#F8FAF7] border border-[#E2E7E2] p-3"><div className="flex items-center justify-between gap-2 mb-2"><div><div className="text-[13px] font-black text-[#59675F]">Practice-editable text</div><div className="text-[13px] text-[#8A948E] mt-0.5">This text appears in the live HTML form. Edit the policy/language here for this practice.</div></div><span className="text-[13px] font-bold text-[#1F6E52]">{(field.defaultValue || '').length.toLocaleString()} characters</span></div><textarea value={field.defaultValue || ''} onChange={e=>updateField(field.id,{defaultValue:e.target.value})} rows={Math.min(18, Math.max(6, Math.ceil((field.defaultValue || '').length / 240)))} className="w-full px-3 py-2.5 rounded-lg border border-[#CCD7CF] bg-white text-[13px] leading-relaxed resize-y min-h-[150px]" /></div>}
            {choiceType(field.type) && <div className="ml-8 rounded-xl bg-[#F8FAF7] border border-[#E2E7E2] p-2.5"><div className="flex items-center justify-between gap-2 mb-2"><div className="text-[13px] font-black text-[#59675F]">Choice options</div><button onClick={()=>addOption(field.id)} className="px-2 py-1 rounded-lg bg-[#1F6E52] text-white text-[13px] font-bold flex items-center gap-1"><Plus className="w-3 h-3"/>Add option</button></div><div className="space-y-1.5">{(field.options || []).map((opt,index)=><div key={`${field.id}-${index}`} className="flex items-center gap-2"><span className="w-5 text-[13px] text-[#9AA49E] font-bold">{index+1}</span><input value={opt} onChange={e=>updateOption(field.id,index,e.target.value)} className="flex-1 px-2.5 py-2 rounded-lg border border-[#DCE3DD] bg-white text-[13px]"/><button onClick={()=>removeOption(field.id,index)} className="p-1.5 text-[#9AA49E] hover:text-red-600"><Trash2 className="w-3.5 h-3.5"/></button></div>)}</div></div>}
          </div>)}</div>
        </section> : <section className="max-w-4xl mx-auto bg-white border border-[#DCE3DD] rounded-xl shadow-sm p-6 space-y-4"><div className="border-b border-[#DCE3DD] pb-3"><div className="text-[13px] uppercase tracking-wider font-black text-[#1F6E52]">Practice Preview</div><h3 className="text-xl font-black text-[#20352B]">{title}</h3></div>{fields.map(f=><div key={f.id} className="space-y-1"><label className="text-[13px] font-bold text-[#425149]">{f.label}{f.required&&<span className="text-red-500"> *</span>} <span className="text-[13px] font-medium text-[#9AA49E]">· {f.owner}</span></label>{f.type==='signature'?<div className="rounded-lg border bg-[#FAFBF9] px-3 py-5 text-[13px] text-[#7A857F]">Signature capture + signer identity + date/time</div>:f.type==='textarea' && f.defaultValue !== undefined?<div className="rounded-lg border bg-[#FAFBF9] px-3 py-3 text-[13px] leading-relaxed text-[#4C5B53] whitespace-pre-wrap max-h-64 overflow-auto">{f.defaultValue}</div>:choiceType(f.type)?<div className="flex flex-wrap gap-2">{(f.options||[]).map(opt=><label key={opt} className="inline-flex items-center gap-1.5 px-2.5 py-2 rounded-lg border bg-[#FAFBF9] text-[13px]"><input type={f.type==='radio'?'radio':'checkbox'} name={f.id}/>{opt}</label>)}</div>:<div className="min-h-9 rounded-lg border bg-[#FAFBF9] px-3 py-2 text-[13px] text-[#9AA49E]">Input: {f.type}</div>}</div>)}</section>}
      </main>
    </div>
  );
};
