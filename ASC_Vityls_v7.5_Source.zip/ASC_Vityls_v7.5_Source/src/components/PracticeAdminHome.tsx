import React, { useMemo, useState } from 'react';
import {
  Building2, CreditCard, Users, ShieldCheck, FileText, FolderOpen,
  Plug, Pill, Search, Sparkles, ArrowRight, CheckCircle2, Stethoscope, BadgeDollarSign
} from 'lucide-react';
import type { AdminActiveSection } from './AdministrationPage';
import { PracticeConfig } from '../types';

interface Props {
  practiceConfig: PracticeConfig;
  onNavigate: (section: AdminActiveSection) => void;
  onNavigateBilling?: () => void;
  onNavigateAI?: () => void;
  onOpenForms?: () => void;
  onShowToast?: (message: string) => void;
}

type Destination = {
  section?: AdminActiveSection;
  title: string;
  description: string;
  tag: string;
  group: string;
  keywords: string;
  icon: React.ComponentType<{ className?: string }>;
  action?: 'billing' | 'ai' | 'forms';
};

const destinations: Destination[] = [
  { section: 'configure-practice', title: 'Practice Configuration', description: 'Facility identity, rooms, and scheduling settings.', tag: 'Setup', group: 'Practice setup', keywords: 'practice location address rooms scheduler medical director setup', icon: Building2 },
  { section: 'people', title: 'Providers', description: 'One workspace for medical staff, clinical employees, administrative staff, access, signatures, credentials, and workforce status.', tag: 'People', group: 'People & compliance', keywords: 'provider doctor surgeon anesthesia nurse rn ma front desk billing administrator credential license malpractice user staff signature payroll', icon: Users },
  { action: 'forms', title: 'Online Forms', description: 'Editable HTML templates, practice PDF forms, workflow assignments, and Form Studio.', tag: 'Forms', group: 'Clinical configuration', keywords: 'forms html pdf form studio intake templates consent questionnaire', icon: FileText },
  { section: 'documents', title: 'Facility Accreditation & Document Center', description: 'Accreditation, policies, manuals, HR and credential files with Nightingale extraction, renewal tracking, and version history.', tag: 'Compliance', group: 'People & compliance', keywords: 'quad a compliance documents policies manuals accreditation hr credentials expiration renewal history', icon: FolderOpen },
];

const groups = ['Practice setup', 'Clinical configuration', 'People & compliance'];

export const PracticeAdminHome: React.FC<Props> = ({ practiceConfig, onNavigate, onNavigateBilling, onNavigateAI, onOpenForms, onShowToast }) => {
  const [query, setQuery] = useState('');
  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return destinations;
    return destinations.filter((d) => `${d.title} ${d.description} ${d.tag} ${d.keywords}`.toLowerCase().includes(q));
  }, [query]);

  const go = (d: Destination) => {
    if (d.action === 'billing') { onNavigateBilling?.(); return; }
    if (d.action === 'ai') { onNavigateAI?.(); return; }
    if (d.action === 'forms') { onOpenForms?.(); return; }
    if (d.section) onNavigate(d.section);
  };

  const quick = (term: string) => { setQuery(term); onShowToast?.(`Showing administration destinations for “${term}”.`); };

  return (
    <div className="-mx-3 sm:-mx-6 lg:-mx-8 -mt-4 sm:-mt-5 bg-[#F4F6F5] min-h-[calc(100vh-7rem)]">
      <section className="bg-gradient-to-br from-[#14432E] via-[#1F6E52] to-[#2D8B69] text-white px-5 sm:px-8 py-9">
        <div className="max-w-3xl mx-auto text-center">
          <div className="inline-flex items-center gap-2 text-[11px] font-bold uppercase tracking-[0.15em] text-[#F4E3BD] mb-3"><Sparkles className="w-4 h-4" /> Guided setup</div>
          <h2 className="text-2xl sm:text-3xl font-bold tracking-tight !text-white">What would you like to configure?</h2>
          <p className="text-sm text-white/85 mt-2">Search by task. Vityls takes you directly to the correct workspace.</p>
          <div className="mt-6 bg-white rounded-xl p-1.5 shadow-xl flex gap-2 max-w-xl mx-auto">
            <Search className="w-5 h-5 text-[#7C8880] ml-3 mt-3 shrink-0" />
            <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Try: forms, add a provider, payment setup…" className="flex-1 min-w-0 px-2 py-2.5 text-sm text-[#20352B] outline-none" />
            <button className="px-4 py-2.5 rounded-lg bg-[#1F6E52] text-white text-xs font-bold" onClick={() => undefined}>Search</button>
          </div>
          <div className="flex flex-wrap justify-center gap-2 mt-4">
            {['Clinical forms','People & credentials','Medical Director','Accreditation docs'].map(tag => (
              <button key={tag} onClick={() => quick(tag)} className="px-3 py-1.5 rounded-full bg-white/12 hover:bg-white/20 border border-white/20 text-xs">{tag}</button>
            ))}
          </div>
        </div>
      </section>

      <main className="max-w-6xl mx-auto px-5 sm:px-8 py-7 pb-16">
        <div className="flex items-center justify-between gap-3 mb-5">
          <div>
            <h3 className="font-bold text-[#20352B]">Administration destinations</h3>
            <p className="text-xs text-[#66736C] mt-1">Grouped by job, not by software module.</p>
          </div>
          <div className="hidden sm:flex items-center gap-2 text-xs text-[#1F6E52] font-semibold"><CheckCircle2 className="w-4 h-4" /> Start anywhere</div>
        </div>

        {groups.map(group => {
          const items = filtered.filter(d => d.group === group);
          if (!items.length) return null;
          return (
            <section key={group} className="mb-7">
              <div className="text-[11px] font-bold tracking-[0.12em] uppercase text-[#7A867E] mb-2.5">{group}</div>
              <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3">
                {items.map((d, i) => {
                  const Icon = d.icon;
                  return (
                    <button key={`${d.title}-${i}`} onClick={() => go(d)} className="group text-left bg-white border border-[#DCE3DD] rounded-xl p-4 hover:border-[#1F6E52] hover:shadow-md transition-all min-h-[128px]">
                      <div className="flex items-start justify-between gap-3">
                        <div className="w-9 h-9 rounded-lg bg-[#E7F1F3] text-[#1F6E52] flex items-center justify-center"><Icon className="w-4.5 h-4.5" /></div>
                        <span className="text-[10px] font-bold uppercase tracking-[0.08em] text-[#1F6E52] bg-[#F1F3EC] px-2 py-1 rounded-full">{d.tag}</span>
                      </div>
                      <h4 className="text-sm font-bold text-[#20352B] mt-3 group-hover:text-[#14432E]">{d.title}</h4>
                      <p className="text-xs text-[#66736C] leading-relaxed mt-1">{d.description}</p>
                      <div className="flex items-center gap-1 text-[11px] font-bold text-[#1F6E52] mt-3 opacity-0 group-hover:opacity-100 transition-opacity">Open <ArrowRight className="w-3.5 h-3.5" /></div>
                    </button>
                  );
                })}
              </div>
            </section>
          );
        })}
        {!filtered.length && <div className="bg-white border border-dashed border-[#C7D1C9] rounded-xl p-12 text-center text-sm text-[#66736C]">No administration destination matches “{query}”.</div>}
      </main>
    </div>
  );
};
