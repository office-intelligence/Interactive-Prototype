/*
 * Add / Edit patient (v7 items 2, 3, 4).
 *  - Every field opens blank unless the user (or the existing record, when editing) supplies it. No fictitious defaults.
 *  - Masks + validation: DOB MM/DD/YYYY (not in the future), phone (000) 000-0000, SSN 000-00-0000, email, ZIP.
 *  - Uses the shared DialogShell header/footer.
 *  - Allergies: blank = "Not Reported"; NKDA only when explicitly ticked.
 */
import React, { useState, useMemo, useEffect } from 'react';
import { PatientCase, PAYMENT_TYPE_OPTIONS } from '../types';
import { UserPlus, UserCog } from 'lucide-react';
import { DialogShell, Btn, MaskedField, fieldErrors } from '../v7/ui';
import { allergyState } from '../v7/allergy';

interface AddPatientModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddPatient: (newPatient: PatientCase) => void;
  initialPatient?: PatientCase | null;
  onSavePatient?: (updatedPatient: PatientCase) => void;
}

function calculateAgeFromDob(dob: string): number | null {
  const match = dob.trim().match(/^(\d{2})\/(\d{2})\/(\d{4})$/);
  if (!match) return null;
  const [, mm, dd, yyyy] = match;
  const dobDate = new Date(Number(yyyy), Number(mm) - 1, Number(dd));
  if (Number.isNaN(dobDate.getTime())) return null;
  const today = new Date();
  let age = today.getFullYear() - dobDate.getFullYear();
  if (today.getMonth() < dobDate.getMonth() || (today.getMonth() === dobDate.getMonth() && today.getDate() < dobDate.getDate())) age -= 1;
  return age >= 0 && age < 130 ? age : null;
}
const newMrn = () => `${Math.floor(100000 + Math.random() * 900000)}`;

const Text: React.FC<{ label: string; value: string; onChange: (v: string) => void; required?: boolean; showErrors?: boolean; testId?: string; className?: string; maxLength?: number }> = ({ label, value, onChange, required, showErrors, testId, className = '', maxLength }) => {
  const [t, setT] = useState(false); const bad = required && !value.trim() && (t || showErrors);
  return <div className={className}><label className="vy-label">{label}{required && <span className="text-[#B42318]" aria-hidden> *</span>}</label>
    <input value={value} maxLength={maxLength} onChange={e => onChange(e.target.value)} onBlur={() => setT(true)} className={`vy-input ${bad ? 'vy-input-invalid' : ''}`} autoComplete="off" data-testid={testId} aria-invalid={bad || undefined} />
    {bad && <p className="vy-field-error" role="alert">Required</p>}</div>;
};
const Select: React.FC<{ label: string; value: string; onChange: (v: string) => void; options: readonly string[]; required?: boolean; showErrors?: boolean; testId?: string; className?: string }> = ({ label, value, onChange, options, required, showErrors, testId, className = '' }) => {
  const bad = required && !value && showErrors;
  return <div className={className}><label className="vy-label">{label}{required && <span className="text-[#B42318]" aria-hidden> *</span>}</label>
    <select value={value} onChange={e => onChange(e.target.value)} className={`vy-input ${bad ? 'vy-input-invalid' : ''}`} data-testid={testId}><option value="">Select…</option>{options.map(o => <option key={o} value={o}>{o}</option>)}</select>
    {bad && <p className="vy-field-error" role="alert">Required</p>}</div>;
};

export const AddPatientModal: React.FC<AddPatientModalProps> = ({ isOpen, onClose, onAddPatient, initialPatient, onSavePatient }) => {
  const [firstName, setFirstName] = useState(''); const [lastName, setLastName] = useState('');
  const [patientId, setPatientId] = useState(''); const [dob, setDob] = useState('');
  const [gender, setGender] = useState(''); const [ethnicity, setEthnicity] = useState(''); const [maritalStatus, setMaritalStatus] = useState('');
  const [phone, setPhone] = useState(''); const [email, setEmail] = useState('');
  const [address, setAddress] = useState(''); const [city, setCity] = useState(''); const [state, setState] = useState(''); const [zipCode, setZipCode] = useState(''); const [country, setCountry] = useState('');
  const [ssn, setSsn] = useState(''); const [driversLicenseNumber, setDriversLicenseNumber] = useState('');
  const [occupation, setOccupation] = useState(''); const [employer, setEmployer] = useState('');
  const [emergencyContactName, setEmergencyContactName] = useState(''); const [emergencyContactPhone, setEmergencyContactPhone] = useState('');
  const [referralSource, setReferralSource] = useState(''); const [allergiesText, setAllergiesText] = useState(''); const [nkda, setNkda] = useState(false);
  const [paymentType, setPaymentType] = useState(''); const [notes, setNotes] = useState(''); const [showErrors, setShowErrors] = useState(false);

  useEffect(() => {
    if (!isOpen) return;
    const p = initialPatient; setShowErrors(false);
    const parts = (p?.name || '').trim().split(/\s+/).filter(Boolean);
    setFirstName(parts[0] || ''); setLastName(parts.length > 1 ? parts.slice(1).join(' ') : '');
    setPatientId(p?.patientId || newMrn()); setDob(p?.dob || ''); setGender(p?.gender || '');
    setEthnicity(p?.ethnicity || ''); setMaritalStatus(p?.maritalStatus || ''); setPhone(p?.phone || ''); setEmail(p?.email || '');
    setAddress(p?.address || ''); setCity(p?.city || ''); setState(p?.state || ''); setZipCode(p?.zipCode || ''); setCountry(p?.country || '');
    setSsn(p?.ssn || ''); setDriversLicenseNumber(p?.driversLicenseNumber || ''); setOccupation(p?.occupation || ''); setEmployer(p?.employer || '');
    setEmergencyContactName(p?.emergencyContactName || ''); setEmergencyContactPhone(p?.emergencyContactPhone || ''); setReferralSource(p?.referralSource || '');
    const a = allergyState(p?.allergies); setNkda(a.state === 'nkda'); setAllergiesText(a.items.join(', '));
    setPaymentType(p?.paymentType || ''); setNotes(p?.notes || '');
  }, [isOpen, initialPatient]);

  const age = useMemo(() => calculateAgeFromDob(dob), [dob]);
  const fullName = [firstName.trim(), lastName.trim()].filter(Boolean).join(' ');
  if (!isOpen) return null;

  const minimalErrors = [...fieldErrors([{ kind: 'date', value: dob, required: true, past: true }, { kind: 'phone', value: phone, required: true }, { kind: 'email', value: email }]),
    ...(!firstName.trim() ? ['first'] : []), ...(!lastName.trim() ? ['last'] : []), ...(!gender ? ['gender'] : [])];

  const handleMinimalCreate = (e?: React.FormEvent) => {
    e?.preventDefault(); setShowErrors(true);
    if (minimalErrors.length) return;
    const p: PatientCase = {
      id: `case-${Date.now()}`, patientId: patientId || newMrn(), name: fullName, age: age ?? 0, gender: gender as PatientCase['gender'],
      dob: dob.trim(), phone: phone.trim(), email: email.trim() || undefined,
      scheduledTime: 'Not Scheduled', estimatedDurationMins: 0, room: 'Unassigned', surgeon: 'Unassigned', procedure: 'Procedure Not Yet Scheduled',
      aiSummary: `${fullName} has a newly created Vityls chart. Registration is pending completion of At-Home Intake.`,
      readinessScore: 0, readinessLevel: 'IN_PROGRESS', allergies: [], labs: [], stage: 'CHECK_IN', arrivalStatus: 'EN_ROUTE', arrivalTime: '',
      bottlenecks: ['At-Home Intake not yet completed'], actionItems: [], checkInStatus: 'NOT_STARTED',
    };
    onAddPatient(p); onClose();
  };

  if (!initialPatient) {
    return <DialogShell as="form" onSubmit={handleMinimalCreate} testId="add-patient-dialog" size="md" icon={<UserPlus />} title="Add New Patient" subtitle="Create the chart, then send At-Home Intake" onClose={onClose}
      footer={<><Btn variant="secondary" onClick={onClose}>Cancel</Btn><Btn type="submit" variant="add" icon={<UserPlus />} data-testid="create-patient">Create Patient Chart</Btn></>}>
      <p className="text-[14px] text-[#3a463f] mb-4">Only what's needed to create the chart and contact the patient. Address, insurance, allergies and history are completed through At-Home Intake.</p>
      <div className="vy-section-title">Patient identity</div>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <Text label="First name" value={firstName} onChange={setFirstName} required showErrors={showErrors} testId="ap-first" />
        <Text label="Last name" value={lastName} onChange={setLastName} required showErrors={showErrors} testId="ap-last" />
        <MaskedField label="Date of birth" kind="date" past value={dob} onChange={setDob} required showErrors={showErrors} testId="ap-dob" />
        <div><label className="vy-label">Age</label><input value={age ?? ''} readOnly placeholder="Calculated from date of birth" className="vy-input bg-[#f2f4f3]" tabIndex={-1} /></div>
        <Select label="Gender" value={gender} onChange={setGender} options={['Female', 'Male', 'Other']} required showErrors={showErrors} testId="ap-gender" />
      </div>
      <p className="text-[13.5px] text-[#3a463f] mt-2">MRN <span className="font-mono font-semibold">{patientId}</span> is assigned automatically.</p>
      <div className="vy-section-title mt-5">Contact for intake</div>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <MaskedField label="Mobile phone" kind="phone" value={phone} onChange={setPhone} required showErrors={showErrors} testId="ap-phone" />
        <MaskedField label="Email (optional)" kind="email" value={email} onChange={setEmail} showErrors={showErrors} testId="ap-email" />
      </div>
      <p className="text-[13.5px] text-[#3a463f] mt-2">The phone number receives the secure At-Home Intake link by text message (simulated in this test build).</p>
      {showErrors && minimalErrors.length > 0 && <p className="vy-field-error mt-3" role="alert" data-testid="ap-errors">Please fix the highlighted fields.</p>}
    </DialogShell>;
  }

  const fullErrors = [...fieldErrors([{ kind: 'date', value: dob, past: true }, { kind: 'phone', value: phone }, { kind: 'phone', value: emergencyContactPhone }, { kind: 'email', value: email }, { kind: 'ssn', value: ssn }, { kind: 'zip', value: zipCode }]),
    ...(!firstName.trim() ? ['first'] : []), ...(!lastName.trim() ? ['last'] : [])];
  const handleSubmit = (e?: React.FormEvent) => {
    e?.preventDefault(); setShowErrors(true);
    if (fullErrors.length || !onSavePatient) return;
    const typed = allergiesText.split(',').map(a => a.trim()).filter(Boolean);
    const u = (s: string) => s.trim() || undefined;
    onSavePatient({
      ...initialPatient, patientId: patientId || initialPatient.patientId, name: fullName || initialPatient.name,
      age: age ?? initialPatient.age, gender: (gender || initialPatient.gender) as PatientCase['gender'], dob: dob.trim(), phone: phone.trim(),
      allergies: typed.length ? typed : nkda ? ['NKDA'] : [], notes, paymentType: paymentType || undefined, ethnicity: u(ethnicity), email: u(email),
      address: u(address), city: u(city), state: u(state), zipCode: u(zipCode), country: u(country), ssn: u(ssn), driversLicenseNumber: u(driversLicenseNumber),
      maritalStatus: (maritalStatus || undefined) as PatientCase['maritalStatus'], occupation: u(occupation), employer: u(employer),
      emergencyContactName: u(emergencyContactName), emergencyContactPhone: u(emergencyContactPhone), referralSource: u(referralSource),
    });
    onClose();
  };
  return <DialogShell as="form" onSubmit={handleSubmit} testId="edit-patient-dialog" size="lg" icon={<UserCog />} title="Edit Patient Record" subtitle="Demographics, contact, identification and registration details" onClose={onClose}
    footer={<><Btn variant="secondary" onClick={onClose}>Cancel</Btn><Btn type="submit" variant="primary">Save Patient Changes</Btn></>}>
    <div className="vy-section-title">Patient identity</div>
    <div className="grid grid-cols-1 sm:grid-cols-6 gap-3">
      <Text className="sm:col-span-3" label="First name" value={firstName} onChange={setFirstName} required showErrors={showErrors} />
      <Text className="sm:col-span-3" label="Last name" value={lastName} onChange={setLastName} required showErrors={showErrors} />
      <MaskedField className="sm:col-span-2" label="Date of birth" kind="date" past value={dob} onChange={setDob} showErrors={showErrors} />
      <div className="sm:col-span-1"><label className="vy-label">Age</label><input value={age ?? ''} readOnly className="vy-input bg-[#f2f4f3]" tabIndex={-1} /></div>
      <Select className="sm:col-span-1" label="Gender" value={gender} onChange={setGender} options={['Female', 'Male', 'Other']} />
      <Select className="sm:col-span-2" label="Ethnicity" value={ethnicity} onChange={setEthnicity} options={['Prefer not to say', 'American Indian or Alaska Native', 'Asian', 'Black or African American', 'Hispanic or Latino', 'Native Hawaiian or Other Pacific Islander', 'White', 'Two or More Races', 'Other']} />
      <Select className="sm:col-span-3" label="Marital status" value={maritalStatus} onChange={setMaritalStatus} options={['Single', 'Married', 'Divorced', 'Widowed', 'Domestic Partner', 'Prefer not to say']} />
      <Text className="sm:col-span-3" label="Medical record number (MRN)" value={patientId} onChange={setPatientId} />
    </div>
    <div className="vy-section-title mt-5">Contact & address</div>
    <div className="grid grid-cols-1 sm:grid-cols-6 gap-3">
      <MaskedField className="sm:col-span-3" label="Phone" kind="phone" value={phone} onChange={setPhone} showErrors={showErrors} />
      <MaskedField className="sm:col-span-3" label="Email" kind="email" value={email} onChange={setEmail} showErrors={showErrors} />
      <Text className="sm:col-span-6" label="Street address" value={address} onChange={setAddress} />
      <Text className="sm:col-span-2" label="City" value={city} onChange={setCity} />
      <Text className="sm:col-span-1" label="State" value={state} onChange={v => setState(v.toUpperCase())} maxLength={2} />
      <MaskedField className="sm:col-span-1" label="ZIP" kind="zip" value={zipCode} onChange={setZipCode} showErrors={showErrors} />
      <Text className="sm:col-span-2" label="Country" value={country} onChange={setCountry} />
    </div>
    <div className="vy-section-title mt-5">Identification</div>
    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
      <MaskedField label="Social Security number" kind="ssn" value={ssn} onChange={setSsn} showErrors={showErrors} />
      <Text label="Driver's license number" value={driversLicenseNumber} onChange={setDriversLicenseNumber} />
    </div>
    <div className="vy-section-title mt-5">Occupation, emergency contact & referral</div>
    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
      <Text label="Occupation" value={occupation} onChange={setOccupation} />
      <Text label="Employer" value={employer} onChange={setEmployer} />
      <Text label="Emergency contact name" value={emergencyContactName} onChange={setEmergencyContactName} />
      <MaskedField label="Emergency contact phone" kind="phone" value={emergencyContactPhone} onChange={setEmergencyContactPhone} showErrors={showErrors} />
      <Select className="sm:col-span-2" label="Referral source" value={referralSource} onChange={setReferralSource} options={['Patient Referral', 'Physician Referral', 'Google Search', 'Instagram / Social Media', 'Insurance Directory', 'Walk-In', 'Other']} />
    </div>
    <div className="vy-section-title mt-5">Payment, allergies & notes</div>
    <div className="grid grid-cols-1 gap-3">
      <Select label="Payment type" value={paymentType} onChange={setPaymentType} options={PAYMENT_TYPE_OPTIONS} />
      <div><label className="vy-label">Documented drug allergies (comma-separated)</label>
        <input value={allergiesText} onChange={e => { setAllergiesText(e.target.value); if (e.target.value.trim()) setNkda(false); }} className="vy-input" placeholder="Leave blank if not reported" />
        <label className="flex items-center gap-2 min-h-[44px] text-[15px]"><input type="checkbox" checked={nkda} disabled={!!allergiesText.trim()} onChange={e => setNkda(e.target.checked)} className="w-5 h-5 accent-[#1f6e52]" /> Patient reports no known drug allergies (NKDA)</label>
        <p className="text-[13.5px] text-[#3a463f]">Blank and not ticked = “Not Reported”.</p></div>
      <div><label className="vy-label">Registration notes</label><textarea rows={2} value={notes} onChange={e => setNotes(e.target.value)} className="vy-input" /></div>
    </div>
    {showErrors && fullErrors.length > 0 && <p className="vy-field-error mt-3" role="alert">Please fix the highlighted fields.</p>}
  </DialogShell>;
};
