import React, { useEffect, useRef } from 'react';

interface Props {
  html: string;
  className?: string;
  autosaveKey?: string;
  onSaveState?: (state: 'saving' | 'saved') => void;
  patientContext?: { name?: string; dob?: string; age?: string | number; gender?: string; mrn?: string; provider?: string; procedure?: string };
}

/**
 * Renders styled clinical HTML in an isolated Shadow DOM.
 *
 * Signature upgrade rules:
 * - Only explicit signature canvases/components authored in the master template are upgraded.
 * - Ordinary text, checkbox, date/time, select and textarea fields are never inferred as signatures.
 * - The original template scripts are never executed.
 */
export const IsolatedHtmlFormRenderer: React.FC<Props> = ({ html, className = '', autosaveKey, onSaveState, patientContext }) => {
  const hostRef = useRef<HTMLDivElement>(null);
  const saveStateRef = useRef(onSaveState);
  saveStateRef.current = onSaveState;

  useEffect(() => {
    const host = hostRef.current;
    if (!host) return;

    const root = host.shadowRoot || host.attachShadow({ mode: 'open' });
    const parser = new DOMParser();
    const doc = parser.parseFromString(html || '<div></div>', 'text/html');

    doc.querySelectorAll('script,iframe,object,embed').forEach((node) => node.remove());
    doc.querySelectorAll<HTMLElement>('*').forEach((node) => {
      [...node.attributes].forEach((attr) => {
        if (/^on/i.test(attr.name)) node.removeAttribute(attr.name);
      });
    });

    const rewriteCss = (css: string) =>
      css.replace(/\bhtml\b/g, ':host').replace(/\bbody\b/g, '.oi-shadow-body');

    const styleText = Array.from(doc.querySelectorAll('style'))
      .map((style) => rewriteCss(style.textContent || ''))
      .join('\n');

    const bodyClass = doc.body.getAttribute('class') || '';
    const bodyStyle = doc.body.getAttribute('style') || '';

    root.innerHTML = `
      <style>
        :host { display:block; width:100%; max-width:100%; box-sizing:border-box; contain:content; }
        *, *::before, *::after { box-sizing:border-box; }
        .oi-shadow-body { display:block; width:100%; max-width:100%; min-height:0!important; height:auto!important; margin:0!important; padding:0!important; background:#fff!important; overflow:visible!important; scrollbar-width:none!important; -ms-overflow-style:none!important; }
        .oi-shadow-body::-webkit-scrollbar,*::-webkit-scrollbar{display:none!important;width:0!important;height:0!important}
        .page { width:100%!important; max-width:100%!important; min-height:0!important; height:auto!important; margin:0 auto!important; box-shadow:none!important; border:none!important; overflow:visible!important; }
        img,svg,canvas,video{max-width:100%;height:auto} table{max-width:100%} input,textarea,select,button{max-width:100%}
        ${styleText}
        .oi-universal-signature{margin-top:7px;border:1px solid #b7ddd0;border-radius:10px;background:#f6fbf9;padding:11px;box-shadow:0 1px 2px rgba(20,67,46,.04)}
        .oi-universal-signature .oi-sig-head{display:flex;align-items:center;justify-content:space-between;gap:8px;margin-bottom:7px;font:700 11px/1.3 -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;color:#33443c}
        .oi-universal-signature .oi-sig-badge{font:700 9px/1 -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;color:#1f6e52;background:#e4f4ed;border-radius:999px;padding:4px 7px;text-transform:uppercase;letter-spacing:.04em}
        .oi-universal-signature canvas{display:block!important;width:100%!important;height:132px!important;min-height:132px!important;background:#fff!important;border:1px dashed #a7b6ae!important;border-radius:8px!important;cursor:crosshair!important;touch-action:none!important;pointer-events:auto!important;opacity:1!important}
        .oi-universal-signature.oi-signed canvas{border-style:solid!important;border-color:#8dccb5!important;background:#fff!important}
        .oi-sig-intent{display:flex!important;align-items:flex-start!important;gap:7px!important;margin:8px 0 6px!important;font:500 10.5px/1.35 -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif!important;color:#536159!important}
        .oi-sig-intent input{width:15px!important;height:15px!important;margin:1px 0 0!important;pointer-events:auto!important;accent-color:#1f6e52!important;flex:0 0 auto!important}
        .oi-sig-actions{display:flex;align-items:center;justify-content:space-between;gap:8px;flex-wrap:wrap;margin-top:6px}
        .oi-sig-help{font:500 10px/1.3 -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;color:#7a857f}
        .oi-sig-buttons{display:flex;gap:6px;margin-left:auto}
        .oi-sig-buttons button{pointer-events:auto!important;border:1px solid #cad3ce!important;border-radius:7px!important;background:#fff!important;color:#536159!important;padding:6px 10px!important;font:700 10.5px/1 -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif!important;cursor:pointer!important}
        .oi-sig-buttons button.oi-accept{background:#1f6e52!important;border-color:#1f6e52!important;color:#fff!important}
        .oi-sig-buttons button.oi-accept:disabled{opacity:.42!important;cursor:not-allowed!important}
        .oi-sig-status{margin-top:5px;font:700 10px/1.3 -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;color:#1f6e52;display:none}
        .oi-universal-signature.oi-signed .oi-sig-status{display:block}
        @media print{.oi-sig-intent,.oi-sig-actions{display:none!important}.oi-universal-signature{border:0;padding:0;background:#fff}}
      </style>
      <div class="oi-shadow-body ${bodyClass}" style="${bodyStyle.replace(/"/g, '&quot;')}">${doc.body.innerHTML}</div>
    `;

    const cleanups: Array<() => void> = [];

    const labelFor = (el: Element): string => {
      const aria = el.getAttribute('aria-label');
      if (aria) return aria;
      const id = el.getAttribute('id');
      if (id) {
        const explicit = root.querySelector(`label[for="${CSS.escape(id)}"]`);
        if (explicit?.textContent?.trim()) return explicit.textContent.trim();
      }
      const group = el.closest('.form-group,.field,.signature-block,.grid-2,.grid-3');
      const label = group?.querySelector('label');
      return label?.textContent?.trim() || '';
    };

    const initializePad = (canvas: HTMLCanvasElement, storage: HTMLInputElement | null, label: string) => {
      if (canvas.dataset.oiSignatureReady === '1') return;
      canvas.dataset.oiSignatureReady = '1';

      let panel = canvas.closest('.oi-universal-signature') as HTMLElement | null;
      if (!panel) {
        const oldWrap = canvas.closest('.sig-pad-wrap') as HTMLElement | null;
        panel = root.ownerDocument.createElement('div');
        panel.className = 'oi-universal-signature';
        const parent = oldWrap?.parentElement || canvas.parentElement;
        if (!parent) return;
        if (oldWrap) {
          parent.insertBefore(panel, oldWrap);
          panel.appendChild(canvas);
          oldWrap.remove();
        } else {
          parent.insertBefore(panel, canvas);
          panel.appendChild(canvas);
        }
      }

      // Remove legacy per-template controls/status so every form uses exactly one UI.
      panel.parentElement?.querySelectorAll(':scope > .sig-pad-actions,:scope > .sig-status').forEach(n => n.remove());

      const head = root.ownerDocument.createElement('div');
      head.className = 'oi-sig-head';
      head.innerHTML = `<span>${label || 'Signature'}</span><span class="oi-sig-badge">Freehand e-signature</span>`;
      panel.insertBefore(head, canvas);

      const intent = root.ownerDocument.createElement('label');
      intent.className = 'oi-sig-intent';
      const intentBox = root.ownerDocument.createElement('input');
      intentBox.type = 'checkbox';
      const intentText = root.ownerDocument.createElement('span');
      intentText.textContent = 'I intend the freehand signature above to be my electronic signature on this record.';
      intent.append(intentBox, intentText);

      const actions = root.ownerDocument.createElement('div');
      actions.className = 'oi-sig-actions';
      const help = root.ownerDocument.createElement('span');
      help.className = 'oi-sig-help';
      help.textContent = 'Draw with a finger, stylus, or mouse.';
      const buttons = root.ownerDocument.createElement('div');
      buttons.className = 'oi-sig-buttons';
      const clear = root.ownerDocument.createElement('button');
      clear.type = 'button'; clear.textContent = 'Clear';
      const accept = root.ownerDocument.createElement('button');
      accept.type = 'button'; accept.textContent = 'Accept Signature'; accept.className = 'oi-accept'; accept.disabled = true;
      buttons.append(clear, accept); actions.append(help, buttons);
      const status = root.ownerDocument.createElement('div');
      status.className = 'oi-sig-status'; status.textContent = '✓ Signature accepted';
      panel.append(intent, actions, status);

      const rect = canvas.getBoundingClientRect();
      const dpr = Math.max(window.devicePixelRatio || 1, 1);
      const cssW = Math.max(320, Math.round(rect.width || 520));
      const cssH = 132;
      canvas.width = Math.round(cssW * dpr); canvas.height = Math.round(cssH * dpr);
      const ctx = canvas.getContext('2d');
      if (!ctx) return;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.strokeStyle = '#1B4332'; ctx.lineWidth = 2.2; ctx.lineCap = 'round'; ctx.lineJoin = 'round';

      let drawing = false; let hasStroke = false; let last: {x:number;y:number}|null = null; let locked = false;
      const point = (ev: PointerEvent) => {
        const r = canvas.getBoundingClientRect();
        return { x: (ev.clientX-r.left)*(cssW/r.width), y:(ev.clientY-r.top)*(cssH/r.height) };
      };
      const updateAccept = () => { accept.disabled = !hasStroke || !intentBox.checked || locked; };
      const down = (ev: PointerEvent) => { if (locked) return; ev.preventDefault(); drawing=true; last=point(ev); canvas.setPointerCapture?.(ev.pointerId); };
      const move = (ev: PointerEvent) => { if (!drawing || locked || !last) return; ev.preventDefault(); const p=point(ev); ctx.beginPath();ctx.moveTo(last.x,last.y);ctx.lineTo(p.x,p.y);ctx.stroke();last=p;hasStroke=true;updateAccept(); };
      const up = (ev: PointerEvent) => { drawing=false; last=null; try{canvas.releasePointerCapture?.(ev.pointerId);}catch{} };
      canvas.addEventListener('pointerdown',down); canvas.addEventListener('pointermove',move); canvas.addEventListener('pointerup',up); canvas.addEventListener('pointercancel',up); intentBox.addEventListener('change',updateAccept);

      const dispatchStored = () => { if (!storage) return; storage.dispatchEvent(new Event('input',{bubbles:true,composed:true})); storage.dispatchEvent(new Event('change',{bubbles:true,composed:true})); };
      const clearFn = () => { locked=false; drawing=false;hasStroke=false;last=null;ctx.clearRect(0,0,cssW,cssH);intentBox.checked=false;panel!.classList.remove('oi-signed');canvas.style.pointerEvents='auto'; if(storage)storage.value=''; dispatchStored();updateAccept(); };
      const acceptFn = () => { if(!hasStroke || !intentBox.checked)return; locked=true;panel!.classList.add('oi-signed');canvas.style.pointerEvents='none';if(storage)storage.value=canvas.toDataURL('image/png');dispatchStored();updateAccept(); };
      clear.addEventListener('click',clearFn); accept.addEventListener('click',acceptFn);
      cleanups.push(()=>{canvas.removeEventListener('pointerdown',down);canvas.removeEventListener('pointermove',move);canvas.removeEventListener('pointerup',up);canvas.removeEventListener('pointercancel',up);intentBox.removeEventListener('change',updateAccept);clear.removeEventListener('click',clearFn);accept.removeEventListener('click',acceptFn);});
    };

    // Upgrade ONLY explicit signature canvases authored in the master template.
    // Ordinary text/date/checkbox/select fields are never inferred or promoted
    // to signatures. This prevents unlabeled clinical inputs from becoming pads.
    Array.from(root.querySelectorAll<HTMLCanvasElement>('canvas')).forEach((canvas) => {
      const aria = (canvas.getAttribute('aria-label') || '').toLowerCase();
      const id = (canvas.id || '').toLowerCase();
      const explicitSignature =
        id.startsWith('sig') ||
        /signature/.test(aria) ||
        Boolean(canvas.closest('.signature-block,.sig-pad-wrap,.sig-wrap,[data-field-type="signature"],[data-vityls-type="signature"]'));
      if (!explicitSignature) return;
      const storageId = canvas.dataset.storageId;
      const storage = storageId ? root.getElementById(storageId) as HTMLInputElement | null : null;
      initializePad(canvas, storage, labelFor(canvas) || canvas.getAttribute('aria-label') || 'Signature');
    });

    // IMPORTANT: Do not convert text inputs to signatures by label/name heuristics.
    // Signature components must be explicit in the master template/schema.

    let autosaveTimer: number | null = null;
    const fieldNodes = () => Array.from(root.querySelectorAll<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>('input,textarea,select'));
    const fieldKey = (el: HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement, index: number) => el.getAttribute('name') || el.id || `field-${index}`;
    const restoreDraft = () => {
      if (!autosaveKey) return;
      try {
        const draft = JSON.parse(localStorage.getItem(autosaveKey) || '{}');
        fieldNodes().forEach((el, index) => {
          const key = fieldKey(el, index);
          if (!(key in draft)) return;
          if (el instanceof HTMLInputElement && (el.type === 'checkbox' || el.type === 'radio')) el.checked = Boolean(draft[key]);
          else el.value = draft[key] ?? '';
        });
      } catch {}
    };
    const saveDraft = () => {
      if (!autosaveKey) return;
      const draft: Record<string, unknown> = {};
      fieldNodes().forEach((el, index) => {
        const key = fieldKey(el, index);
        draft[key] = el instanceof HTMLInputElement && (el.type === 'checkbox' || el.type === 'radio') ? el.checked : el.value;
      });
      localStorage.setItem(autosaveKey, JSON.stringify(draft));
      saveStateRef.current?.('saved');
    };
    const scheduleSave = () => {
      if (!autosaveKey) return;
      saveStateRef.current?.('saving');
      if (autosaveTimer) window.clearTimeout(autosaveTimer);
      autosaveTimer = window.setTimeout(saveDraft, 450);
    };
    // Populate the standard Patient / Encounter header from shared patient/encounter truth.
    const contextMap: Record<string, string> = {
      'patient.name': patientContext?.name || '', 'patient.dob': patientContext?.dob || '',
      'patient.age': patientContext?.age == null ? '' : String(patientContext.age), 'patient.gender': patientContext?.gender || '',
      'patient.mrn': patientContext?.mrn || '', 'encounter.provider': patientContext?.provider || '',
      'encounter.procedure': patientContext?.procedure || ''
    };
    Object.entries(contextMap).forEach(([key,val]) => {
      if (!val) return;
      root.querySelectorAll<HTMLElement>(`[data-vityls="${key}"]`).forEach(el => el.textContent = val);
    });
    // For templates with explicit page containers, repeat the patient header on every page.
    const standardHeader = root.querySelector<HTMLElement>('[data-vityls-standard-header="true"]');
    const pages = Array.from(root.querySelectorAll<HTMLElement>('.page,.form-page,[data-vityls-page]'));
    if (standardHeader && pages.length > 1) {
      pages.forEach((page, idx) => {
        if (idx === 0 || page.querySelector('[data-vityls-standard-header="true"]')) return;
        const clone = standardHeader.cloneNode(true) as HTMLElement; clone.setAttribute('data-vityls-repeated-header','true'); page.insertBefore(clone,page.firstChild);
      });
    }

    restoreDraft();
    root.addEventListener('input', scheduleSave);
    root.addEventListener('change', scheduleSave);

    return () => {
      if (autosaveTimer) window.clearTimeout(autosaveTimer);
      root.removeEventListener('input', scheduleSave);
      root.removeEventListener('change', scheduleSave);
      cleanups.forEach(fn => fn());
      root.innerHTML = '';
    };
  }, [html, autosaveKey, patientContext?.name, patientContext?.dob, patientContext?.age, patientContext?.gender, patientContext?.mrn, patientContext?.provider, patientContext?.procedure]);

  return <div ref={hostRef} className={`w-full min-w-0 ${className}`} />;
};
