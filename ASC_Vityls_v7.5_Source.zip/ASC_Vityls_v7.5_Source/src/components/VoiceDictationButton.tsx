import React, { useEffect, useRef, useState } from 'react';
import { Mic, MicOff, AlertCircle } from 'lucide-react';
const ALLOW_BROWSER_DICTATION = false;

interface VoiceDictationButtonProps {
  onTranscript: (text: string) => void;
  label?: string;
  className?: string;
}

// Thin wrapper over the browser's Web Speech API (SpeechRecognition) for
// voice-activated dictation/form-filling. Degrades gracefully with an inline
// notice in browsers that don't support it (e.g. Firefox) rather than failing
// silently — dictation is optional, never required, everywhere it's used.
export const VoiceDictationButton: React.FC<VoiceDictationButtonProps> = ({
  onTranscript,
  label = 'Dictate',
  className = '',
}) => {
  const [isListening, setIsListening] = useState(false);
  const [isSupported, setIsSupported] = useState(true);
  const [showUnsupportedNote, setShowUnsupportedNote] = useState(false);
  const recognitionRef = useRef<any>(null);

  useEffect(() => {
    // v6: browser dictation streams audio to Google/Apple with no BAA, so it is off.
    // Voice capture now goes through the push-to-talk adapter on each form (src/v6/voice.ts).
    if (!ALLOW_BROWSER_DICTATION) { setIsSupported(false); return; }
    const SpeechRecognitionCtor =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognitionCtor) {
      setIsSupported(false);
      return;
    }
    const recognition = new SpeechRecognitionCtor();
    recognition.continuous = true;
    recognition.interimResults = false;
    recognition.lang = 'en-US';

    recognition.onresult = (event: any) => {
      let finalText = '';
      for (let i = event.resultIndex; i < event.results.length; i++) {
        if (event.results[i].isFinal) {
          finalText += event.results[i][0].transcript;
        }
      }
      if (finalText.trim()) onTranscript(finalText.trim());
    };
    recognition.onerror = () => setIsListening(false);
    recognition.onend = () => setIsListening(false);

    recognitionRef.current = recognition;
    return () => {
      try { recognition.stop(); } catch { /* no-op */ }
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const toggleListening = () => {
    if (!isSupported) {
      setShowUnsupportedNote(true);
      setTimeout(() => setShowUnsupportedNote(false), 3500);
      return;
    }
    const recognition = recognitionRef.current;
    if (!recognition) return;
    if (isListening) {
      recognition.stop();
      setIsListening(false);
    } else {
      try {
        recognition.start();
        setIsListening(true);
      } catch {
        setIsListening(false);
      }
    }
  };

  return (
    <div className="relative inline-block">
      <button
        type="button"
        onClick={toggleListening}
        className={`px-2.5 py-1 rounded-lg text-[13px] min-h-[44px] font-bold flex items-center gap-1.5 transition-all cursor-pointer border ${
          isListening
            ? 'bg-rose-600 hover:bg-rose-700 text-white border-rose-700 animate-pulse'
            : 'bg-[#E7F1F3] hover:bg-[#DCEEF1] text-[#1D4E5A] border-[#3E8FA6]/50'
        } ${className}`}
        title={isSupported ? 'Voice-activated dictation' : 'Browser dictation is off (no HIPAA agreement)'}
      >
        {isListening ? <MicOff className="w-3 h-3" /> : <Mic className="w-3 h-3" />}
        <span>{isListening ? 'Listening… (tap to stop)' : label}</span>
      </button>

      {showUnsupportedNote && (
        <div className="absolute left-0 top-full mt-1.5 w-56 bg-stone-900 text-white text-[13px] font-medium rounded-lg p-2 shadow-lg z-50 flex items-start gap-1.5 animate-in fade-in duration-150">
          <AlertCircle className="w-3.5 h-3.5 text-amber-400 shrink-0 mt-0.5" />
          <span>Browser dictation is off in this build because it sends audio to Google/Apple without a HIPAA agreement. Open the form and use “Hold to talk”, or type directly.</span>
        </div>
      )}
    </div>
  );
};
