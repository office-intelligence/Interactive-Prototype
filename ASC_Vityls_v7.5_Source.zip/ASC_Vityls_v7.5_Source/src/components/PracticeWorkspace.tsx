import React, { useState, useEffect } from 'react';
import { BillingHub, OpsHub } from '../v7/Hubs';
import { PageHeader } from '../v7/ui';
import {
  CreditCard,
  Settings,
  Sparkles,
  Building2,
  ShieldCheck,
  Layers,
  Zap,
  DollarSign,
  Inbox,
  Sliders,
  SlidersHorizontal,
  CheckCircle2,
  Calendar,
  Users,
  Search,
  ArrowRight,
  Activity
} from 'lucide-react';
import { PatientCase, PracticeConfig } from '../types';
import { BillingModulePage } from './BillingModulePage';
import { AdministrationPage, AdminActiveSection } from './AdministrationPage';
import { AIHomePage } from './AIHomePage';
import { AIWorkflowExamples } from './AIWorkflowExamples';
import { ApprovedDesignPage } from './ApprovedDesignPage';

// Note: Messages moved out to a standalone top-level page (see MessagesPage.tsx,
// rendered directly from App.tsx) — it's used by nearly every employee and was
// hard to find buried as a Practice sub-tab, so it no longer lives here.
export type PracticeSubModule = 'billing' | 'admin' | 'workflows';

interface PracticeWorkspaceProps {
  navKey?: number;
  initialSubModule?: PracticeSubModule;
  cases: PatientCase[];
  onShowToast: (message: string) => void;
  onOpenPatientChartById: (patientId: string, sectionKey?: string) => void;
  onOpenPatientChart: (patient: PatientCase, sectionKey?: string) => void;
  onTriggerEKGFastTrack: (caseId: string) => void;
  onUpdateStage: (caseId: string, newStage: any) => void;
  practiceConfig: PracticeConfig;
  practicesList: PracticeConfig[];
  activePracticeId: string;
  onSelectPractice: (practiceId: string) => void;
  onAddPractice: (newPractice: PracticeConfig) => void;
  onDeletePractice: (practiceId: string) => void;
  onUpdatePracticeConfig: (updated: PracticeConfig) => void;
  adminActiveSection: AdminActiveSection;
  onAdminSectionChange: (section: AdminActiveSection) => void;
  onNavigateTab: (tab: string, subModule?: string) => void;
  onOpenLocalPracticeDashboard?: (practice: { id: string; name: string; createdAt: string }) => void;
}

export const PracticeWorkspace: React.FC<PracticeWorkspaceProps> = ({
  initialSubModule = 'billing',
  cases,
  onShowToast,
  onOpenPatientChartById,
  onOpenPatientChart,
  onTriggerEKGFastTrack,
  onUpdateStage,
  practiceConfig,
  practicesList,
  activePracticeId,
  onSelectPractice,
  onAddPractice,
  onDeletePractice,
  onUpdatePracticeConfig,
  adminActiveSection,
  onAdminSectionChange,
  onNavigateTab,
  onOpenLocalPracticeDashboard,
  navKey,
}) => {
  const [activeSubModule, setActiveSubModule] = useState<PracticeSubModule>(initialSubModule);

  useEffect(() => {
    if (initialSubModule) {
      setActiveSubModule(initialSubModule);
    }
  }, [initialSubModule, navKey]);

  const subModules: {
    id: PracticeSubModule;
    label: string;
    description: string;
    icon: React.ComponentType<{ className?: string }>;
    badge?: number;
    badgeColor?: string;
  }[] = [
    {
      id: 'billing',
      label: 'Billing & Payments',
      description: 'Claims, fee schedules, electronic scrubbing, and ledger',
      icon: CreditCard,
    },
    {
      id: 'admin',
      label: 'Administration & Locations',
      description: 'Practice configuration, locations, provider credentials, and OR suite settings',
      icon: Settings,
    },
    {
      id: 'workflows',
      label: 'Operations Intelligence',
      description: 'Operational performance, exceptions, trends and Nightingale insights',
      icon: Sparkles,
    },
  ];

  const openAdmin = (section: AdminActiveSection) => { onAdminSectionChange(section); };
  if (activeSubModule === 'billing') return <BillingHub onBack={()=>setActiveSubModule('admin')} onToast={onShowToast} />;
  if (activeSubModule === 'workflows') return <OpsHub onBack={()=>setActiveSubModule('admin')} />;
  if (adminActiveSection !== 'home') return <AdministrationPage
    onShowToast={onShowToast} practiceConfig={practiceConfig}
    practicesList={practicesList} activePracticeId={activePracticeId}
    onSelectPractice={onSelectPractice} onAddPractice={onAddPractice} onDeletePractice={onDeletePractice}
    onUpdatePracticeConfig={onUpdatePracticeConfig} activeSection={adminActiveSection}
    onSectionChange={onAdminSectionChange} onOpenFormsWorkspace={()=>onNavigateTab('form-studio')} onNavigateBilling={()=>setActiveSubModule('billing')}
    onOpenLocalPracticeDashboard={onOpenLocalPracticeDashboard}
  />;
  return <div className="max-w-5xl mx-auto py-8 space-y-6">
    <PageHeader kicker="Practice workspace" title="Administration" sub="Practice setup, providers, forms & workflow, billing and operations." testId="practice-header" />
    <section className="bg-[#f6f1e7] border border-[#e5d9c5] rounded-lg overflow-hidden">
      <header className="bg-[#1c5b45] text-white px-5 py-4 flex items-center justify-between"><span className="font-display text-xl">Nightingale</span><span className="text-[10px] uppercase tracking-widest">Guided setup · command</span></header>
      <div className="p-5 space-y-5">
        <div className="flex gap-2"><input className="vds-input flex-1" placeholder="Ask or instruct: forms, add a provider, payment setup…"/><button onClick={()=>onShowToast('Nightingale command captured for this evaluation build.')} className="vds-btn vds-btn-primary">Ask</button></div>
        <div><div className="vds-kicker mb-2">Workspaces</div><div className="flex flex-wrap gap-2"><button onClick={()=>openAdmin('configure-practice')} className="vds-btn vds-btn-secondary">Administration & Locations</button><button onClick={()=>setActiveSubModule('billing')} className="vds-btn vds-btn-secondary">Billing & Payments</button><button onClick={()=>setActiveSubModule('workflows')} className="vds-btn vds-btn-secondary">Operations Intelligence</button></div></div>
        <div><div className="vds-kicker mb-2">Practice setup</div><div className="flex flex-wrap gap-2"><button onClick={()=>openAdmin('configure-practice')} className="vds-btn vds-btn-secondary">Practice configuration</button><button onClick={()=>openAdmin('people')} className="vds-btn vds-btn-secondary">Medical Director</button><button onClick={()=>openAdmin('configure-practice')} className="vds-btn vds-btn-secondary">Rooms & Schedule settings</button></div></div>
        <div><div className="vds-kicker mb-2">Clinical configuration</div><div className="flex flex-wrap gap-2"><button onClick={()=>onNavigateTab('form-studio')} className="vds-btn vds-btn-secondary">Forms & Workflow</button><button onClick={()=>onNavigateTab('form-studio')} className="vds-btn vds-btn-secondary">My Forms</button><button onClick={()=>onNavigateTab('form-studio')} className="vds-btn vds-btn-secondary">Stations & Assignments</button></div></div>
        <div><div className="vds-kicker mb-2">People & compliance</div><div className="flex flex-wrap gap-2"><button onClick={()=>openAdmin('people')} className="vds-btn vds-btn-secondary">Providers</button><button onClick={()=>openAdmin('documents')} className="vds-btn vds-btn-secondary">Facility Accreditation & Documents</button><button onClick={()=>openAdmin('documents')} className="vds-btn vds-btn-secondary">Policies & Manuals</button></div></div>
      </div>
    </section>
  </div>;

};
