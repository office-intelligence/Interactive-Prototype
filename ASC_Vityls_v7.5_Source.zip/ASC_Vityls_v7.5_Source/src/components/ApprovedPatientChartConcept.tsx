import React from 'react';
export const ApprovedPatientChartConcept: React.FC = () => (
  <div className="w-full bg-[#e8ece8]" style={{minHeight:'calc(100vh - 112px)'}}>
    <iframe title="Vityls Patient Chart — Approved Concept" src="concepts/patient-chart.html" className="w-full border-0 block" style={{height:'calc(100vh - 74px)',minHeight:900}} />
  </div>
);
