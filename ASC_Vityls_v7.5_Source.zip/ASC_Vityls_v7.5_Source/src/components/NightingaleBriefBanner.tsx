import React, { useState } from 'react';
import { Sparkles, ArrowRight, ChevronDown, ChevronUp } from 'lucide-react';
import { PatientCase, CommunicationStats } from '../types';
import { CommunicationWidget } from './CommunicationWidget';
import { allergyState } from '../v7/allergy';
import { getDocs, getState } from '../v7/clearance';
import { balanceFor } from '../v7/billing';
import { getMyForms } from '../v7/myForms';

interface NightingaleBriefBannerProps {
  cases: PatientCase[];
  onActionClick: () => void;
  onFilterNeedsAttention?: () => void;
  stats?: CommunicationStats;
  onSelectCategory?: (category: string) => void;
  /** v7: open the chart for the case Nightingale recommends */
  onOpenCase?: (c: PatientCase, sectionKey?: string) => void;
}
const n = (v: unknown) => (typeof v === 'number' && Number.isFinite(v) ? v : 0);

/** v7 item 10: same design as the patient-page Nightingale AI panel (green header), built from real case data. */
export const NightingaleBriefBanner: React.FC<NightingaleBriefBannerProps> = ({ cases, onActionClick, stats, onSelectCategory, onOpenCase }) => {
  const [isWaitingExpanded, setIsWaitingExpanded] = useState(false);
  const rooms = Array.from(new Set(cases.map(c => c.room).filter(Boolean)));
  const cleared = cases.filter(c => getState(c.id).cleared);
  const noDocs = cases.filter(c => !getDocs(c.id).length);
  const notReviewed = cases.filter(c => getDocs(c.id).length && !getState(c.id).review);
  const noAllergy = cases.filter(c => allergyState(c.allergies).state === 'not-reported');
  const due = cases.filter(c => balanceFor(c.id).due > 0);
  const myForms = getMyForms().length;
  const next = notReviewed[0] ? { c: notReviewed[0], text: `Review the clearance summary for ${notReviewed[0].name} (${notReviewed[0].scheduledTime}).`, key: 'clearanceReview' }
    : noAllergy[0] ? { c: noAllergy[0], text: `Record allergy status for ${noAllergy[0].name}: it is not reported.`, key: 'medications' }
    : noDocs[0] ? { c: noDocs[0], text: `Request pre-op clearance documents for ${noDocs[0].name}.`, key: 'clearanceFiles' } : null;
  const s = stats ? { ins: n(stats.insuranceApproval), labs: n(stats.labResults), msgs: n(stats.patientMessages), other: n(stats.implantShipment) + n(stats.physicianSignature) + n(stats.referrals) + n(stats.insuranceQueries) + n(stats.labNotifications) } : null;
  const total = s ? s.ins + s.labs + s.msgs + s.other : 0;
  const bullets: [string, string][] = [
    [cases.length ? `${cases.length} procedure${cases.length === 1 ? '' : 's'} scheduled${rooms.length ? ` across ${rooms.join(' and ')}` : ''}.` : 'No procedures scheduled for this day.', 'ok'],
    [`${cleared.length} of ${cases.length} cleared for surgery by a clinician.`, cleared.length === cases.length && cases.length ? 'ok' : 'info'],
    ...(notReviewed.length ? [[`${notReviewed.length} clearance summar${notReviewed.length === 1 ? 'y needs' : 'ies need'} a clinician review.`, 'warn'] as [string, string]] : []),
    ...(noDocs.length ? [[`${noDocs.length} case${noDocs.length === 1 ? ' has' : 's have'} no clearance documents yet.`, 'warn'] as [string, string]] : []),
    ...(noAllergy.length ? [[`${noAllergy.length} patient${noAllergy.length === 1 ? '' : 's'} with allergy status not reported.`, 'warn'] as [string, string]] : []),
    ...(due.length ? [[`${due.length} case${due.length === 1 ? '' : 's'} with a balance due.`, 'warn'] as [string, string]] : []),
    ...(!myForms ? [['No forms in My Forms yet. Stations stay empty until forms are added in Forms & Workflow.', 'info'] as [string, string]] : []),
  ];
  const dot = (t: string) => t === 'warn' ? 'bg-[#9a5b13]' : t === 'ok' ? 'bg-[#1F6E52]' : 'bg-[#4a5750]';
  return (
    <section className="bg-[#F1F3EC] text-[#1A2E22] rounded-xl border border-[#3E8FA6]/50 shadow-2xs overflow-hidden nightingale-highlight-border" data-testid="dashboard-nightingale">
      <div className="nightingale-ai-header px-4 py-3 flex items-center justify-between gap-3">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-[#F4EFE3]/10 border border-[#D9A448]/70 flex items-center justify-center"><Sparkles className="w-4 h-4 text-[#D9A448]" /></div>
          <div><h2 className="text-[16px] font-semibold text-[#F4EFE3] leading-tight">Nightingale AI</h2><div className="text-[13px] text-[#F4EFE3]/90">Daily brief · from today’s cases</div></div>
        </div>
        <span className="text-[13px] text-[#F4EFE3]/90">Updated {new Date().toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' })}</span>
      </div>
      <div className="p-4 space-y-4">
        <ul className="space-y-2 text-[14.5px] text-[#1A2E22]">{bullets.map(([t, tone], i) => <li key={i} className="flex items-start gap-2"><span className={`w-2 h-2 rounded-full mt-2 shrink-0 ${dot(tone)}`} /><span className={tone === 'warn' ? 'text-[#6b3f0c]' : ''}>{t}</span></li>)}</ul>
        <div className="p-3.5 bg-white rounded-xl border border-[#E1E4DC] space-y-2">
          <div className="vy-kicker">Recommended action</div>
          <p className="text-[14.5px] leading-snug">{next ? next.text : 'Nothing urgent. All cases have documents reviewed and allergy status recorded.'}</p>
          <button onClick={() => next ? onOpenCase?.(next.c, next.key) : onActionClick()} className="vy-btn vy-btn-primary w-full" data-testid="brief-action">{next ? `Open ${next.c.name}` : 'View day details'} <ArrowRight className="w-4 h-4" /></button>
        </div>
        {s && <div className="rounded-xl border border-[#E1E4DC] overflow-hidden">
          <button type="button" onClick={() => setIsWaitingExpanded(v => !v)} className="w-full min-h-[44px] px-3.5 py-2.5 bg-white hover:bg-[#F1F3EC] flex items-center justify-between gap-2 text-[14px] text-[#1A2E22]" data-testid="waiting-line">
            <span>{total ? `${total} item${total === 1 ? '' : 's'} waiting on you today: insurance ${s.ins}, labs ${s.labs}, messages ${s.msgs}` : 'Nothing waiting on you today (insurance, labs, messages)'}</span>
            {isWaitingExpanded ? <ChevronUp className="w-4 h-4 shrink-0" /> : <ChevronDown className="w-4 h-4 shrink-0" />}
          </button>
          {isWaitingExpanded && <div className="p-3 bg-[#F1F3EC] border-t border-[#E1E4DC]"><CommunicationWidget stats={stats!} onSelectCategory={onSelectCategory || (() => {})} /></div>}
        </div>}
      </div>
    </section>
  );
};
