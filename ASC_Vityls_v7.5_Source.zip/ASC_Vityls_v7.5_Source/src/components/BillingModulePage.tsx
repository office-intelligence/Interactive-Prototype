import React, { useState } from 'react';
import { FeeScheduleEditor, CaseInvoicesTable } from '../v7/InvoicePanel';
import { PatientCase } from '../types';
import {
  CreditCard,
  DollarSign,
  FileText,
  Building2,
  User,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  Sparkles,
  Send,
  Download,
  Printer,
  RefreshCw,
  ShieldCheck,
  Search,
  Filter,
  Plus,
  Clock,
  TrendingUp,
  BarChart3,
  PieChart,
  Layers,
  Settings,
  Link as LinkIcon,
  Lock,
  FileSpreadsheet,
  AlertCircle,
  Calendar,
  ChevronRight,
  ArrowRight,
  Upload,
  Activity,
  Tag,
  Edit3,
  Sliders,
  CheckSquare,
  Square,
  Mail,
  HelpCircle,
  FileCheck
} from 'lucide-react';

interface BillingModulePageProps {
  cases: PatientCase[];
  onShowToast: (message: string) => void;
}

export type BillingTab =
  | 'overview'
  | 'scrubbing'
  | 'claims'
  | 'invoices'
  | 'eligibility'
  | 'posting'
  | 'clearinghouse'
  | 'implants'
  | 'denials'
  | 'fees';

export interface ClaimItem {
  id: string;
  claimType: 'CMS-1500 (Professional)' | 'UB-04 (ASC Facility)';
  patientName: string;
  patientId: string;
  dos: string;
  payer: string;
  payerId: string;
  surgeon: string;
  procedure: string;
  cptCodes: string[];
  icd10Codes: string[];
  revenueCodes?: string[];
  totalCharge: number;
  expectedReimbursement: number;
  readinessScore: number;
  status: 'Ready to Submit' | 'Scrubbing Errors' | 'Submitted' | 'Accepted' | 'Denied' | 'Paid';
  scrubErrors: Array<{ field: string; message: string; severity: 'Critical' | 'Warning' }>;
  placeOfService: string;
  npi: string;
  taxId: string;
  priorAuthNumber?: string;
  accountType: 'Commercial' | 'Medicare' | 'Medicaid' | 'Self-Pay' | 'Workers Comp';
}

export interface PatientInvoiceItem {
  id: string;
  invoiceNumber: string;
  patientName: string;
  patientId: string;
  email: string;
  guarantor: string;
  guarantorAddress?: string;
  dob?: string;
  dos: string;
  surgeon: string;
  anesthesiologist?: string;
  procedure: string;
  facilityFee: number;
  surgeonFee: number;
  anesthesiaFee?: number;
  implantCharges: number;
  medicationCharges: number;
  discounts: number;
  paymentsReceived: number;
  balanceDue: number;
  status: 'Draft' | 'Sent via Email' | 'Opened' | 'Partially Paid' | 'Paid in Full' | 'Payment Plan' | 'Overdue';
  agingDays: number;
  invoiceDate?: string;
  dueDate?: string;
  lastPaymentDate?: string;
  lastPaymentAmount?: number;
}

export interface ImplantItem {
  id: string;
  implantName: string;
  manufacturer: string;
  lotNumber: string;
  serialNumber: string;
  purchaseCost: number;
  billedCharge: number;
  carveOutEligible: boolean;
  usedInCase: string;
  patientName: string;
}

export const BillingModulePage: React.FC<BillingModulePageProps> = ({ cases, onShowToast }) => {
  const [activeTab, setActiveTab] = useState<BillingTab>('overview');
  const [cashBillingMethod, setCashBillingMethod] = useState<'time' | 'procedure'>('time');
  const [cashHourlyRate, setCashHourlyRate] = useState(0);
  const [insuranceMultiplier, setInsuranceMultiplier] = useState(0);
  const [anesthesiaBillingMethod, setAnesthesiaBillingMethod] = useState<'time' | 'procedure'>('time');
  const [anesthesiaBaseFee, setAnesthesiaBaseFee] = useState(0);
  const [anesthesiaPer15Minute, setAnesthesiaPer15Minute] = useState(0);

  // Filter & Search states
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedPayerFilter, setSelectedPayerFilter] = useState('ALL');

  // Selected Item Modals / Viewers
  const [selectedClaimForScrub, setSelectedClaimForScrub] = useState<ClaimItem | null>(null);
  const [selectedInvoice, setSelectedInvoice] = useState<PatientInvoiceItem | null>(null);
  const [isInvoiceModalOpen, setIsInvoiceModalOpen] = useState(false);
  const [isClearinghouseModalOpen, setIsClearinghouseModalOpen] = useState(false);
  const [isStandalonePaymentModalOpen, setIsStandalonePaymentModalOpen] = useState(false);
  const [standalonePayment, setStandalonePayment] = useState({ patientName: '', patientId: '', amount: 0, method: 'Credit Card', reference: '', notes: '' });
  const [unappliedCredits, setUnappliedCredits] = useState<Array<{id:string;patientName:string;patientId:string;amount:number;date:string;method:string}>>([]);
  const [sendInvoiceAfterSave, setSendInvoiceAfterSave] = useState(false);

  // Clearinghouse Integration Form State
  const [clearinghouseVendor, setClearinghouseVendor] = useState('');
  const [clearinghouseEndpoint, setClearinghouseEndpoint] = useState('');
  const [tradingPartnerId, setTradingPartnerId] = useState('');
  const [submitterId, setSubmitterId] = useState('');
  const [clearinghouseMode, setClearinghouseMode] = useState<'Production' | 'Test'>('Production');

  // Eligibility Form State
  const [eligibilityPatientId, setEligibilityPatientId] = useState(cases[0]?.id || '');
  const [eligibilityResult, setEligibilityResult] = useState<{
    status: 'ACTIVE' | 'AUTH_REQUIRED' | 'INACTIVE';
    payerName: string;
    copay: number;
    deductibleRemaining: number;
    coinsurance: string;
    authRequired: boolean;
    preAuthNumber?: string;
  } | null>({
    status: 'ACTIVE',
    payerName: 'Blue Cross Blue Shield PPO',
    copay: 50,
    deductibleRemaining: 350,
    coinsurance: '20% after deductible',
    authRequired: true,
    preAuthNumber: 'PA-2026-99218',
  });

  // Mock Claims Database
  const [claims, setClaims] = useState<ClaimItem[]>([]);

  // Modal and Aging filter states
  const [isCreateInvoiceModalOpen, setIsCreateInvoiceModalOpen] = useState(false);
  const [isRecordPaymentModalOpen, setIsRecordPaymentModalOpen] = useState(false);
  const [paymentTargetInvoice, setPaymentTargetInvoice] = useState<PatientInvoiceItem | null>(null);
  const [paymentAmountInput, setPaymentAmountInput] = useState<string>('');
  const [paymentMethodInput, setPaymentMethodInput] = useState<string>('Credit Card (Online Portal)');
  const [paymentRefInput, setPaymentRefInput] = useState<string>('');

  // Search & Filter for Account Aging
  const [agingSearchQuery, setAgingSearchQuery] = useState('');
  const [agingFilterBucket, setAgingFilterBucket] = useState('ALL');

  // New Invoice Form State
  const [newInvoicePatientId, setNewInvoicePatientId] = useState('');
  const [newInvoicePatientName, setNewInvoicePatientName] = useState('');
  const [newInvoiceGuarantor, setNewInvoiceGuarantor] = useState('');
  const [newInvoiceEmail, setNewInvoiceEmail] = useState('');
  const [newInvoiceDos, setNewInvoiceDos] = useState('');
  const [newInvoiceSurgeon, setNewInvoiceSurgeon] = useState('');
  const [newInvoiceAnesthesiologist, setNewInvoiceAnesthesiologist] = useState('');
  const [newInvoiceProcedure, setNewInvoiceProcedure] = useState('');
  const [newInvoiceFacilityFee, setNewInvoiceFacilityFee] = useState<number>(0);
  const [newInvoiceSurgeonFee, setNewInvoiceSurgeonFee] = useState<number>(0);
  const [newInvoiceAnesthesiaFee, setNewInvoiceAnesthesiaFee] = useState<number>(0);
  const [newInvoiceImplantCharges, setNewInvoiceImplantCharges] = useState<number>(0);
  const [newInvoiceMedicationCharges, setNewInvoiceMedicationCharges] = useState<number>(0);
  const [newInvoiceDiscounts, setNewInvoiceDiscounts] = useState<number>(0);
  const [newInvoicePaymentsReceived, setNewInvoicePaymentsReceived] = useState<number>(0);

  // Mock Patient Invoices (Self-Pay & Patient Responsibility)
  const [invoices, setInvoices] = useState<PatientInvoiceItem[]>([]);

  // Mock Implant Catalog
  const [implants] = useState<ImplantItem[]>([]);

  // Action handlers
  const handleFixClaimWithAI = (claimId: string) => {
    setClaims((prev) =>
      prev.map((c) => {
        if (c.id === claimId) {
          let updatedCpt = [...c.cptCodes];
          if (c.id === 'CLM-8802') {
            updatedCpt = ['67904-50', '67950-50'];
          }
          return {
            ...c,
            cptCodes: updatedCpt,
            readinessScore: 98,
            status: 'Ready to Submit',
            scrubErrors: [],
          };
        }
        return c;
      })
    );
    onShowToast(`⚡ AI Claim Scrubbing: Auto-applied required modifiers & NCCI rules for ${claimId}. Readiness score updated to 98%!`);
  };

  const handleSubmitClaimToClearinghouse = (claimId: string) => {
    setClaims((prev) =>
      prev.map((c) => (c.id === claimId ? { ...c, status: 'Submitted' } : c))
    );
    onShowToast(`✉ Claim ${claimId} transmitted to ${clearinghouseVendor} via HIPAA X12 837 EDI!`);
  };

  const handleSendInvoiceEmail = (invId: string) => {
    setInvoices((prev) =>
      prev.map((inv) => (inv.id === invId ? { ...inv, status: 'Sent via Email' } : inv))
    );
    onShowToast(`✉ Sent itemized invoice PDF & Patient Portal payment link to patient!`);
  };

  // Account Aging Data Structures & Derived Aggregations
  interface PatientAgingAggregate {
    patientId: string;
    patientName: string;
    guarantor: string;
    payer: string;
    dos: string;
    bucket0to30: number;
    bucket31to60: number;
    bucket61to90: number;
    bucket91to120: number;
    bucket120Plus: number;
    totalBalance: number;
    lastPaymentDate?: string;
    lastPaymentAmount?: number;
    status: string;
    invoicesList: PatientInvoiceItem[];
  }

  const patientAgingAggregatesMap: { [key: string]: PatientAgingAggregate } = {};

  invoices.forEach((inv) => {
    if (!patientAgingAggregatesMap[inv.patientId]) {
      patientAgingAggregatesMap[inv.patientId] = {
        patientId: inv.patientId,
        patientName: inv.patientName,
        guarantor: inv.guarantor,
        payer: inv.status === 'Paid in Full' ? 'Self-Pay (Settled)' : 'Patient Responsibility',
        dos: inv.dos,
        bucket0to30: 0,
        bucket31to60: 0,
        bucket61to90: 0,
        bucket91to120: 0,
        bucket120Plus: 0,
        totalBalance: 0,
        lastPaymentDate: inv.lastPaymentDate,
        lastPaymentAmount: inv.lastPaymentAmount,
        status: inv.status,
        invoicesList: [],
      };
    }

    const row = patientAgingAggregatesMap[inv.patientId];
    row.invoicesList.push(inv);
    row.totalBalance += inv.balanceDue;

    if (inv.agingDays <= 30) row.bucket0to30 += inv.balanceDue;
    else if (inv.agingDays <= 60) row.bucket31to60 += inv.balanceDue;
    else if (inv.agingDays <= 90) row.bucket61to90 += inv.balanceDue;
    else if (inv.agingDays <= 120) row.bucket91to120 += inv.balanceDue;
    else row.bucket120Plus += inv.balanceDue;

    if (new Date(inv.dos) > new Date(row.dos)) {
      row.dos = inv.dos;
    }
  });

  const patientAgingList = Object.values(patientAgingAggregatesMap);

  // Filtered Per-Patient Aging Rows
  const filteredPatientAgingList = patientAgingList.filter((row) => {
    const matchesQuery =
      row.patientName.toLowerCase().includes(agingSearchQuery.toLowerCase()) ||
      row.patientId.toLowerCase().includes(agingSearchQuery.toLowerCase()) ||
      row.guarantor.toLowerCase().includes(agingSearchQuery.toLowerCase());

    if (!matchesQuery) return false;

    if (agingFilterBucket === '0-30') return row.bucket0to30 > 0;
    if (agingFilterBucket === '31-60') return row.bucket31to60 > 0;
    if (agingFilterBucket === '61-90') return row.bucket61to90 > 0;
    if (agingFilterBucket === '91-120') return row.bucket91to120 > 0;
    if (agingFilterBucket === '120+') return row.bucket120Plus > 0;
    if (agingFilterBucket === 'PLAN') return row.status === 'Payment Plan';
    return true;
  });

  // Totals for Practice Aging Table
  const practicePatientAgingTotals = {
    b0to30: patientAgingList.reduce((acc, r) => acc + r.bucket0to30, 0),
    b31to60: patientAgingList.reduce((acc, r) => acc + r.bucket31to60, 0),
    b61to90: patientAgingList.reduce((acc, r) => acc + r.bucket61to90, 0),
    b91to120: patientAgingList.reduce((acc, r) => acc + r.bucket91to120, 0),
    b120Plus: patientAgingList.reduce((acc, r) => acc + r.bucket120Plus, 0),
    total: patientAgingList.reduce((acc, r) => acc + r.totalBalance, 0),
  };

  const handleRecordPayment = () => {
    if (!paymentTargetInvoice) return;
    const amount = parseFloat(paymentAmountInput);
    if (isNaN(amount) || amount <= 0) {
      onShowToast('⚠️ Please enter a valid payment amount!');
      return;
    }

    setInvoices((prev) =>
      prev.map((inv) => {
        if (inv.id === paymentTargetInvoice.id) {
          const newPayments = inv.paymentsReceived + amount;
          const newBalance = Math.max(0, inv.balanceDue - amount);
          const newStatus = newBalance === 0 ? 'Paid in Full' : 'Partially Paid';
          return {
            ...inv,
            paymentsReceived: newPayments,
            balanceDue: newBalance,
            status: newStatus,
            lastPaymentDate: new Date().toISOString().split('T')[0],
            lastPaymentAmount: amount,
          };
        }
        return inv;
      })
    );

    if (selectedInvoice && selectedInvoice.id === paymentTargetInvoice.id) {
      const newPayments = selectedInvoice.paymentsReceived + amount;
      const newBalance = Math.max(0, selectedInvoice.balanceDue - amount);
      setSelectedInvoice({
        ...selectedInvoice,
        paymentsReceived: newPayments,
        balanceDue: newBalance,
        status: newBalance === 0 ? 'Paid in Full' : 'Partially Paid',
        lastPaymentDate: new Date().toISOString().split('T')[0],
        lastPaymentAmount: amount,
      });
    }

    setIsRecordPaymentModalOpen(false);
    onShowToast(`💳 Payment of $${amount.toLocaleString()} recorded for ${paymentTargetInvoice.patientName}! Receipt transmitted via portal.`);
  };

  const handleCreateInvoice = (e: React.FormEvent) => {
    e.preventDefault();
    const totalCharges = newInvoiceFacilityFee + newInvoiceSurgeonFee + newInvoiceAnesthesiaFee + newInvoiceImplantCharges + newInvoiceMedicationCharges;
    const balance = Math.max(0, totalCharges - newInvoiceDiscounts - newInvoicePaymentsReceived);
    const newInvNum = `INV-90210-${100 + invoices.length + 1}`;
    
    const newInv: PatientInvoiceItem = {
      id: `INV-2026-${Date.now()}`,
      invoiceNumber: newInvNum,
      patientName: newInvoicePatientName,
      patientId: newInvoicePatientId || `p-${Math.floor(100000 + Math.random() * 900000)}`,
      email: newInvoiceEmail,
      guarantor: newInvoiceGuarantor,
      guarantorAddress: '9400 Wilshire Blvd, Beverly Hills, CA 90212',
      dob: '08/14/1988',
      dos: newInvoiceDos,
      surgeon: newInvoiceSurgeon,
      anesthesiologist: newInvoiceAnesthesiologist,
      procedure: newInvoiceProcedure,
      facilityFee: newInvoiceFacilityFee,
      surgeonFee: newInvoiceSurgeonFee,
      anesthesiaFee: newInvoiceAnesthesiaFee,
      implantCharges: newInvoiceImplantCharges,
      medicationCharges: newInvoiceMedicationCharges,
      discounts: newInvoiceDiscounts,
      paymentsReceived: newInvoicePaymentsReceived,
      balanceDue: balance,
      status: balance === 0 ? 'Paid in Full' : (sendInvoiceAfterSave ? 'Sent via Email' : 'Draft'),
      agingDays: 1,
      invoiceDate: new Date().toISOString().split('T')[0],
      dueDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      lastPaymentDate: newInvoicePaymentsReceived > 0 ? new Date().toISOString().split('T')[0] : undefined,
      lastPaymentAmount: newInvoicePaymentsReceived > 0 ? newInvoicePaymentsReceived : undefined,
    };

    setInvoices((prev) => [newInv, ...prev]);
    setIsCreateInvoiceModalOpen(false);
    setSelectedInvoice(newInv);
    setIsInvoiceModalOpen(true);
    onShowToast(sendInvoiceAfterSave ? `📄 Invoice ${newInvNum} saved and emailed to ${newInv.patientName}.` : `📄 Invoice ${newInvNum} saved as Draft. Review it, then send when ready.`);
  };

  // Calculating AR Totals
  const totalBilledClaims = claims.reduce((acc, c) => acc + c.totalCharge, 0);
  const totalExpectedReimbursement = claims.reduce((acc, c) => acc + c.expectedReimbursement, 0);
  const totalPatientBalanceDue = invoices.reduce((acc, inv) => acc + inv.balanceDue, 0);
  const cleanClaimRate = Math.round(
    (claims.filter((c) => c.readinessScore >= 90).length / claims.length) * 100
  );

  return (
    <div className="space-y-6 font-sans">
      
      {/* MODULE HEADER BAR */}
      <div className="p-6 bg-gradient-to-r from-emerald-900 via-emerald-900 to-emerald-900 text-white rounded-3xl shadow-xl border border-emerald-800 flex flex-wrap items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2.5">
            <div className="p-2.5 bg-indigo-500/20 text-indigo-400 rounded-2xl border border-indigo-500/30">
              <CreditCard className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-xl font-black tracking-tight text-white flex items-center gap-2">
                Outpatient Surgical Facility & ASC Billing Module
                <span className="px-3 py-0.5 rounded-full bg-indigo-500/30 text-indigo-200 text-xs font-bold border border-indigo-400/30">
                  Revenue Cycle Management
                </span>
              </h2>
              <p className="text-xs text-indigo-200 font-medium">
                Self-Pay Invoicing · CMS-1500 Professional · UB-04 Facility · X12 EDI Clearinghouse · Claim Scrubbing Engine
              </p>
            </div>
          </div>
        </div>

        {/* Quick Action Header Buttons */}
        <div className="flex flex-wrap items-center gap-2.5">
          <button
            onClick={() => {
              setIsClearinghouseModalOpen(true);
            }}
            className="px-4 py-2 bg-white/10 hover:bg-white/20 text-white font-bold text-xs rounded-xl border border-white/20 transition-all cursor-pointer flex items-center gap-2 shadow-2xs"
          >
            <Settings className="w-4 h-4 text-indigo-300" />
            <span>Clearinghouse Admin</span>
          </button>

          <button
            onClick={() => {
              setActiveTab('scrubbing');
              onShowToast('Running enterprise claim scrubbing engine across all un-submitted claims...');
            }}
            className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs rounded-xl transition-all cursor-pointer flex items-center gap-2 shadow-md shadow-indigo-900/40"
          >
            <Sparkles className="w-4 h-4 text-indigo-200" />
            <span>Run AI Claim Scrubbing ({claims.filter(c => c.scrubErrors.length > 0).length})</span>
          </button>
        </div>
      </div>

      {/* TOP METRICS SUMMARY CARDS */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Card 1: Total Billed AR */}
        <div className="p-4 bg-white rounded-2xl border border-stone-200 shadow-2xs space-y-2">
          <div className="flex items-center justify-between text-xs font-bold text-stone-500">
            <span>Total Outstanding AR</span>
            <DollarSign className="w-4 h-4 text-indigo-600" />
          </div>
          <div className="text-2xl font-black text-stone-900 font-mono">
            ${(totalBilledClaims + totalPatientBalanceDue).toLocaleString()}
          </div>
          <div className="text-[11px] text-stone-500 font-medium flex items-center justify-between">
            <span>Insurance: ${totalExpectedReimbursement.toLocaleString()}</span>
            <span>Self-Pay: ${totalPatientBalanceDue.toLocaleString()}</span>
          </div>
        </div>

        {/* Card 2: Clean Claim Rate */}
        <div className="p-4 bg-white rounded-2xl border border-stone-200 shadow-2xs space-y-2">
          <div className="flex items-center justify-between text-xs font-bold text-stone-500">
            <span>First-Pass Clean Claim Rate</span>
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-2xl font-black text-emerald-700 font-mono flex items-center gap-2">
            <span>{cleanClaimRate}%</span>
            <span className="text-xs font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
              Target &gt;95%
            </span>
          </div>
          <div className="text-[11px] text-stone-500 font-medium">
            {claims.filter((c) => c.readinessScore >= 90).length} of {claims.length} claims ready for 1-click transmittal
          </div>
        </div>

        {/* Card 3: Days in A/R */}
        <div className="p-4 bg-white rounded-2xl border border-stone-200 shadow-2xs space-y-2">
          <div className="flex items-center justify-between text-xs font-bold text-stone-500">
            <span>Average Days in A/R</span>
            <Clock className="w-4 h-4 text-amber-600" />
          </div>
          <div className="text-2xl font-black text-stone-900 font-mono">
            21.4 Days
          </div>
          <div className="text-[11px] text-emerald-700 font-bold flex items-center gap-1">
            <span>↓ 4.2 days vs ASC national benchmark (28 days)</span>
          </div>
        </div>

        {/* Card 4: Net Revenue Per OR Case */}
        <div className="p-4 bg-white rounded-2xl border border-stone-200 shadow-2xs space-y-2">
          <div className="flex items-center justify-between text-xs font-bold text-stone-500">
            <span>Net Revenue per OR Case</span>
            <TrendingUp className="w-4 h-4 text-indigo-600" />
          </div>
          <div className="text-2xl font-black text-indigo-900 font-mono">
            $6,840
          </div>
          <div className="text-[11px] text-stone-500 font-medium">
            Facility Fee: $4,200 · Professional: $2,640
          </div>
        </div>
      </div>

      {/* MODULE MAIN NAVIGATION TABS */}
      <div className="bg-white p-2 rounded-2xl border border-stone-200 shadow-2xs flex flex-wrap items-center gap-1.5 overflow-x-auto text-xs font-bold">
        {[
          { id: 'overview', label: '1. Financial Overview & AR', icon: BarChart3 },
          { id: 'fees', label: '2. Fee Schedules', icon: Sliders },
          { id: 'scrubbing', label: `2. AI Claim Scrubbing (${claims.filter(c => c.scrubErrors.length > 0).length})`, icon: Sparkles },
          { id: 'claims', label: '3. CMS-1500 & UB-04 Claims', icon: FileText },
          { id: 'invoices', label: '4. Patient Invoices & Self-Pay', icon: DollarSign },
          { id: 'eligibility', label: '5. Real-Time Eligibility (270/271)', icon: ShieldCheck },
          { id: 'posting', label: '6. Payment Posting & ERA (835)', icon: CreditCard },
          { id: 'implants', label: '7. ASC Implants & Case Costing', icon: Tag },
          { id: 'clearinghouse', label: '8. Clearinghouse EDI Admin', icon: Settings },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as BillingTab)}
              className={`px-3.5 py-2 rounded-xl transition-all cursor-pointer flex items-center gap-2 whitespace-nowrap ${
                isActive
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'bg-stone-50 text-stone-700 hover:bg-stone-100 hover:text-stone-900 border border-stone-200'
              }`}
            >
              <Icon className={`w-4 h-4 ${isActive ? 'text-indigo-300' : 'text-stone-500'}`} />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {activeTab === 'overview' && (
        <div className="bg-white rounded-2xl border border-stone-200 shadow-2xs p-5 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div><h3 className="font-bold text-base text-stone-900">Nightingale Billing Worklist</h3><p className="text-xs text-stone-500 mt-1">Cases and balances that need financial follow-up. Nightingale can surface these from case, invoice, claim and payment status.</p></div>
            <span className="px-3 py-1 rounded-full bg-emerald-50 border border-emerald-200 text-emerald-800 text-[11px] font-bold">Live financial exceptions</span>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <button onClick={()=>setActiveTab('invoices')} className="text-left p-4 rounded-xl border border-amber-200 bg-amber-50 hover:bg-amber-100"><div className="text-[10px] uppercase font-bold text-amber-800">Needs Invoice</div><div className="text-2xl font-black text-stone-900 mt-1">{Math.max(0, cases.length - invoices.length)}</div><div className="text-xs text-stone-600 mt-1">Completed/active cases with no invoice yet.</div></button>
            <button onClick={()=>setActiveTab('invoices')} className="text-left p-4 rounded-xl border border-rose-200 bg-rose-50 hover:bg-rose-100"><div className="text-[10px] uppercase font-bold text-rose-800">Awaiting Payment</div><div className="text-2xl font-black text-stone-900 mt-1">{invoices.filter(i=>i.balanceDue>0).length}</div><div className="text-xs text-stone-600 mt-1">Invoices with an outstanding patient balance.</div></button>
            <button onClick={()=>setActiveTab('invoices')} className="text-left p-4 rounded-xl border border-emerald-200 bg-emerald-50 hover:bg-emerald-100"><div className="text-[10px] uppercase font-bold text-emerald-800">Unapplied Credits / Deposits</div><div className="text-2xl font-black text-stone-900 mt-1">${unappliedCredits.reduce((a,c)=>a+c.amount,0).toLocaleString()}</div><div className="text-xs text-stone-600 mt-1">Payments collected before an invoice or awaiting application.</div></button>
          </div>
        </div>
      )}

      {/* v7 item 12: persistent time-based fee schedules with alternates (replaces the unsaved v6 fee form) */}
      {activeTab === 'fees' && <FeeScheduleEditor onToast={(m) => onShowToast(m)} />}

      {/* TAB 1: FINANCIAL OVERVIEW & ACCOUNT AGING */}
      {activeTab === 'overview' && (
        <div className="space-y-6">
          
          {/* Linked Billing Account Architecture Diagram */}
          <div className="p-5 bg-white rounded-2xl border border-stone-200 shadow-2xs space-y-4">
            <div className="flex items-center justify-between border-b border-stone-100 pb-3">
              <div className="flex items-center gap-2">
                <Layers className="w-5 h-5 text-indigo-600" />
                <h3 className="font-bold text-sm text-stone-900">
                  ASC Core Billing Architecture (4-Tier Linked Financial Accounts)
                </h3>
              </div>
              <span className="text-xs text-stone-500 font-mono">Practice · Revenue Cycle Engine</span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-4 gap-3 text-xs">
              {/* Account 1 */}
              <div className="p-3.5 bg-stone-50 rounded-xl border border-stone-200 space-y-2">
                <div className="font-bold text-stone-900 flex items-center justify-between">
                  <span>1. Patient Financial</span>
                  <User className="w-4 h-4 text-indigo-600" />
                </div>
                <div className="text-[11px] text-stone-600 space-y-1">
                  <div>• Self-pay invoices</div>
                  <div>• Copays, deductibles, coinsurance</div>
                  <div>• Deposits & payment plans</div>
                  <div>• Refunds & credit balances</div>
                </div>
                <div className="pt-2 border-t border-stone-200 font-bold font-mono text-stone-900">
                  Balance: ${totalPatientBalanceDue.toLocaleString()}
                </div>
              </div>

              {/* Account 2 */}
              <div className="p-3.5 bg-stone-50 rounded-xl border border-stone-200 space-y-2">
                <div className="font-bold text-stone-900 flex items-center justify-between">
                  <span>2. Insurance Account</span>
                  <Building2 className="w-4 h-4 text-emerald-600" />
                </div>
                <div className="text-[11px] text-stone-600 space-y-1">
                  <div>• Primary, Secondary, Tertiary</div>
                  <div>• X12 837P / 837I Electronic Claims</div>
                  <div>• Contractual write-offs</div>
                  <div>• Denial management & appeals</div>
                </div>
                <div className="pt-2 border-t border-stone-200 font-bold font-mono text-stone-900">
                  Pending: ${totalExpectedReimbursement.toLocaleString()}
                </div>
              </div>

              {/* Account 3 */}
              <div className="p-3.5 bg-stone-50 rounded-xl border border-stone-200 space-y-2">
                <div className="font-bold text-stone-900 flex items-center justify-between">
                  <span>3. ASC Facility Account</span>
                  <Building2 className="w-4 h-4 text-indigo-600" />
                </div>
                <div className="text-[11px] text-stone-600 space-y-1">
                  <div>• UB-04 / 837I Facility Fees</div>
                  <div>• OR & Recovery time charges</div>
                  <div>• Implant carve-out billing</div>
                  <div>• Pharmacy & supply charges</div>
                </div>
                <div className="pt-2 border-t border-stone-200 font-bold font-mono text-stone-900">
                  OR Case Avg: $0
                </div>
              </div>

              {/* Account 4 */}
              <div className="p-3.5 bg-stone-50 rounded-xl border border-stone-200 space-y-2">
                <div className="font-bold text-stone-900 flex items-center justify-between">
                  <span>4. Professional Fees</span>
                  <User className="w-4 h-4 text-purple-600" />
                </div>
                <div className="text-[11px] text-stone-600 space-y-1">
                  <div>• CMS-1500 / 837P Surgeon Fees</div>
                  <div>• Assistant surgeon charges</div>
                  <div>• Anesthesia professional fees</div>
                  <div>• Pre-op consultation fees</div>
                </div>
                <div className="pt-2 border-t border-stone-200 font-bold font-mono text-stone-900">
                  Pro Avg: $0
                </div>
              </div>
            </div>
          </div>

          {/* Account Aging Buckets Table: Practice Summary & Per-Patient Aging */}
          <div className="space-y-6">
            
            {/* 1. Practice Overall Account Aging Summary Table */}
            <div className="p-5 bg-white rounded-2xl border border-stone-200 shadow-2xs space-y-4">
              <div className="flex flex-wrap items-center justify-between border-b border-stone-100 pb-3 gap-2">
                <div>
                  <h3 className="font-bold text-base text-stone-900 flex items-center gap-2">
                    <BarChart3 className="w-5 h-5 text-indigo-600" />
                    <span>Overall Practice Account Receivables Aging Breakdown</span>
                  </h3>
                  <p className="text-xs text-stone-500 font-medium">
                    Aggregated financial portfolio aging across Commercial Insurance, Medicare/Medicaid, Injury Liens, and Patient Self-Pay accounts
                  </p>
                </div>
                <span className="text-xs font-bold text-indigo-700 bg-indigo-50 px-3 py-1 rounded-full border border-indigo-200 flex items-center gap-1.5">
                  <Calendar className="w-3.5 h-3.5" />
                  <span>Aging Calculation Date: {new Date().toLocaleDateString()}</span>
                </span>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-xs text-left border-collapse">
                  <thead className="bg-stone-100/90 text-stone-700 uppercase font-bold border-b border-stone-200">
                    <tr>
                      <th className="p-3 pl-4">Receivables Payer Category</th>
                      <th className="p-3 font-mono">0–30 Days (Current)</th>
                      <th className="p-3 font-mono">31–60 Days</th>
                      <th className="p-3 font-mono">61–90 Days</th>
                      <th className="p-3 font-mono">91–120 Days</th>
                      <th className="p-3 font-mono">120+ Days (Overdue)</th>
                      <th className="p-3 font-mono text-right pr-4">Total Outstanding AR</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-stone-200 font-medium text-stone-800">
                    <tr className="hover:bg-stone-50 transition-colors">
                      <td className="p-3 pl-4 font-bold text-stone-900 flex items-center gap-2">
                        <User className="w-4 h-4 text-indigo-600 shrink-0" />
                        <span>Patient Self-Pay & Co-pays (Direct)</span>
                      </td>
                      <td className="p-3 font-mono text-emerald-700 font-bold">${practicePatientAgingTotals.b0to30.toLocaleString()}</td>
                      <td className="p-3 font-mono text-stone-800">${practicePatientAgingTotals.b31to60.toLocaleString()}</td>
                      <td className="p-3 font-mono text-amber-700 font-bold">${practicePatientAgingTotals.b61to90.toLocaleString()}</td>
                      <td className="p-3 font-mono text-amber-800 font-bold">${practicePatientAgingTotals.b91to120.toLocaleString()}</td>
                      <td className="p-3 font-mono text-red-700 font-bold">${practicePatientAgingTotals.b120Plus.toLocaleString()}</td>
                      <td className="p-3 font-mono text-right pr-4 font-black text-stone-900 text-sm">${practicePatientAgingTotals.total.toLocaleString()}</td>
                    </tr>
                  </tbody>
                  <tfoot className="bg-stone-900 text-white font-bold border-t-2 border-stone-900">
                    <tr>
                      <td className="p-3 pl-4 text-indigo-200 uppercase font-black tracking-wide">PRACTICE OVERALL AR TOTAL</td>
                      <td className="p-3 font-mono text-emerald-300">${practicePatientAgingTotals.b0to30.toLocaleString()}</td>
                      <td className="p-3 font-mono text-stone-200">${practicePatientAgingTotals.b31to60.toLocaleString()}</td>
                      <td className="p-3 font-mono text-amber-300">${practicePatientAgingTotals.b61to90.toLocaleString()}</td>
                      <td className="p-3 font-mono text-amber-300">${practicePatientAgingTotals.b91to120.toLocaleString()}</td>
                      <td className="p-3 font-mono text-red-300">${practicePatientAgingTotals.b120Plus.toLocaleString()}</td>
                      <td className="p-3 font-mono text-right pr-4 text-yellow-300 text-base font-black">${practicePatientAgingTotals.total.toLocaleString()}</td>
                    </tr>
                  </tfoot>
                </table>
              </div>
            </div>

            {/* 2. Per-Patient Account Aging Details Table */}
            <div className="p-5 bg-white rounded-2xl border border-stone-200 shadow-2xs space-y-4">
              <div className="flex flex-wrap items-center justify-between border-b border-stone-100 pb-3 gap-3">
                <div>
                  <h3 className="font-bold text-base text-stone-900 flex items-center gap-2">
                    <User className="w-5 h-5 text-indigo-600" />
                    <span>Per-Patient Account Aging Details & Statement Manager</span>
                  </h3>
                  <p className="text-xs text-stone-500 font-medium">
                    Detailed patient-by-patient account balance breakdown across standard aging buckets (0–30, 31–60, 61–90, 91–120, 120+ days)
                  </p>
                </div>

                <div className="flex flex-wrap items-center gap-2">
                  <button
                    onClick={() => setIsCreateInvoiceModalOpen(true)}
                    className="px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-xl transition-colors cursor-pointer flex items-center gap-1.5 shadow-2xs"
                  >
                    <Plus className="w-4 h-4" />
                    <span>+ Create Patient Invoice</span>
                  </button>
                </div>
              </div>

              {/* Search & Aging Bucket Controls */}
              <div className="flex flex-wrap items-center justify-between gap-3 bg-stone-50 p-3 rounded-xl border border-stone-200 text-xs">
                <div className="flex items-center gap-2 flex-1 min-w-[240px]">
                  <Search className="w-4 h-4 text-stone-400 shrink-0" />
                  <input
                    type="text"
                    placeholder="Search patient name, ID, or guarantor..."
                    value={agingSearchQuery}
                    onChange={(e) => setAgingSearchQuery(e.target.value)}
                    className="w-full bg-white border border-stone-300 rounded-lg px-3 py-1.5 font-medium text-stone-900 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>

                <div className="flex items-center gap-2">
                  <Filter className="w-4 h-4 text-stone-500 shrink-0" />
                  <span className="font-bold text-stone-700">Filter Aging Bucket:</span>
                  <select
                    value={agingFilterBucket}
                    onChange={(e) => setAgingFilterBucket(e.target.value)}
                    className="bg-white border border-stone-300 rounded-lg px-3 py-1.5 font-bold text-stone-900 focus:outline-none focus:ring-2 focus:ring-indigo-500 cursor-pointer"
                  >
                    <option value="ALL">All Patient Accounts ({patientAgingList.length})</option>
                    <option value="0-30">Current (0–30 Days)</option>
                    <option value="31-60">Past Due 31–60 Days</option>
                    <option value="61-90">Past Due 61–90 Days</option>
                    <option value="91-120">Past Due 91–120 Days</option>
                    <option value="120+">Severely Overdue (120+ Days)</option>
                    <option value="PLAN">Payment Plan Active</option>
                  </select>
                </div>
              </div>

              {/* Per-Patient Table */}
              <div className="overflow-x-auto border border-stone-200 rounded-xl">
                <table className="w-full text-xs text-left border-collapse">
                  <thead className="bg-stone-100 text-stone-700 font-bold uppercase border-b border-stone-200 text-[11px]">
                    <tr>
                      <th className="p-3 pl-4">Patient & Guarantor</th>
                      <th className="p-3">DOS / Service</th>
                      <th className="p-3 font-mono">0–30d</th>
                      <th className="p-3 font-mono">31–60d</th>
                      <th className="p-3 font-mono">61–90d</th>
                      <th className="p-3 font-mono">91–120d</th>
                      <th className="p-3 font-mono">120+d</th>
                      <th className="p-3 font-mono">Total Balance</th>
                      <th className="p-3">Last Payment</th>
                      <th className="p-3">Aging Status</th>
                      <th className="p-3 text-right pr-4">Quick Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-stone-200 font-medium">
                    {filteredPatientAgingList.length === 0 ? (
                      <tr>
                        <td colSpan={11} className="p-8 text-center text-stone-500 font-medium">
                          No patient accounts match the current filter or search criteria.
                        </td>
                      </tr>
                    ) : (
                      filteredPatientAgingList.map((pt) => {
                        const targetInvoice = pt.invoicesList[0];

                        return (
                          <tr key={pt.patientId} className="hover:bg-stone-50/90 transition-colors">
                            <td className="p-3 pl-4">
                              <div className="font-bold text-stone-900 flex items-center gap-1.5">
                                <span>{pt.patientName}</span>
                                <span className="px-1.5 py-0.2 rounded bg-stone-100 text-stone-600 font-mono text-[10px] border border-stone-200">
                                  {pt.patientId}
                                </span>
                              </div>
                              <div className="text-[11px] text-stone-500 font-medium line-clamp-1">
                                Guarantor: {pt.guarantor}
                              </div>
                            </td>

                            <td className="p-3">
                              <div className="font-mono text-stone-800 font-bold">{pt.dos}</div>
                              <div className="text-[10px] text-stone-500 truncate max-w-[140px]">
                                {targetInvoice?.procedure || 'Outpatient Procedure'}
                              </div>
                            </td>

                            <td className={`p-3 font-mono font-bold ${pt.bucket0to30 > 0 ? 'text-emerald-700' : 'text-stone-300'}`}>
                              ${pt.bucket0to30.toLocaleString()}
                            </td>
                            <td className={`p-3 font-mono font-bold ${pt.bucket31to60 > 0 ? 'text-stone-800' : 'text-stone-300'}`}>
                              ${pt.bucket31to60.toLocaleString()}
                            </td>
                            <td className={`p-3 font-mono font-bold ${pt.bucket61to90 > 0 ? 'text-amber-700' : 'text-stone-300'}`}>
                              ${pt.bucket61to90.toLocaleString()}
                            </td>
                            <td className={`p-3 font-mono font-bold ${pt.bucket91to120 > 0 ? 'text-amber-800' : 'text-stone-300'}`}>
                              ${pt.bucket91to120.toLocaleString()}
                            </td>
                            <td className={`p-3 font-mono font-bold ${pt.bucket120Plus > 0 ? 'text-red-700' : 'text-stone-300'}`}>
                              ${pt.bucket120Plus.toLocaleString()}
                            </td>

                            <td className="p-3 font-mono font-black text-indigo-950 text-sm">
                              ${pt.totalBalance.toLocaleString()}
                            </td>

                            <td className="p-3 text-[11px]">
                              {pt.lastPaymentAmount && pt.lastPaymentAmount > 0 ? (
                                <div>
                                  <span className="font-bold text-emerald-800 font-mono">${pt.lastPaymentAmount.toLocaleString()}</span>
                                  <div className="text-[10px] text-stone-400 font-mono">{pt.lastPaymentDate}</div>
                                </div>
                              ) : (
                                <span className="text-stone-400 italic">No payments yet</span>
                              )}
                            </td>

                            <td className="p-3">
                              <span
                                className={`px-2.5 py-1 rounded-full text-[10px] font-bold border flex items-center gap-1 w-fit ${
                                  pt.status === 'Paid in Full'
                                    ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                                    : pt.status === 'Payment Plan'
                                    ? 'bg-purple-50 text-purple-800 border-purple-200'
                                    : pt.status === 'Overdue' || pt.bucket120Plus > 0 || pt.bucket91to120 > 0
                                    ? 'bg-red-50 text-red-800 border-red-200'
                                    : pt.bucket61to90 > 0 || pt.bucket31to60 > 0
                                    ? 'bg-amber-50 text-amber-800 border-amber-200'
                                    : 'bg-emerald-50 text-emerald-800 border-emerald-200'
                                }`}
                              >
                                {pt.status}
                              </span>
                            </td>

                            <td className="p-3 text-right pr-4">
                              <div className="flex items-center justify-end gap-1.5">
                                <button
                                  onClick={() => {
                                    if (targetInvoice) {
                                      setSelectedInvoice(targetInvoice);
                                      setIsInvoiceModalOpen(true);
                                    }
                                  }}
                                  title="View Standard Invoice Template"
                                  className="px-2.5 py-1 bg-white hover:bg-stone-100 text-stone-800 font-bold rounded-lg border border-stone-300 transition-colors cursor-pointer flex items-center gap-1"
                                >
                                  <FileText className="w-3.5 h-3.5 text-indigo-600" />
                                  <span>Standard Invoice</span>
                                </button>

                                <button
                                  onClick={() => {
                                    if (targetInvoice) {
                                      setPaymentTargetInvoice(targetInvoice);
                                      setPaymentAmountInput(targetInvoice.balanceDue.toString());
                                      setIsRecordPaymentModalOpen(true);
                                    }
                                  }}
                                  title="Record Payment"
                                  className="px-2.5 py-1 bg-emerald-700 hover:bg-emerald-800 text-white font-bold rounded-lg transition-colors cursor-pointer flex items-center gap-1"
                                >
                                  <CreditCard className="w-3.5 h-3.5" />
                                  <span>Record Pay</span>
                                </button>
                              </div>
                            </td>
                          </tr>
                        );
                      })
                    )}
                  </tbody>
                  <tfoot className="bg-stone-100 font-bold border-t-2 border-stone-300 text-stone-900">
                    <tr>
                      <td colSpan={2} className="p-3 pl-4 uppercase font-black">Filtered Patients Summary ({filteredPatientAgingList.length})</td>
                      <td className="p-3 font-mono text-emerald-800">${filteredPatientAgingList.reduce((a, r) => a + r.bucket0to30, 0).toLocaleString()}</td>
                      <td className="p-3 font-mono text-stone-800">${filteredPatientAgingList.reduce((a, r) => a + r.bucket31to60, 0).toLocaleString()}</td>
                      <td className="p-3 font-mono text-amber-800">${filteredPatientAgingList.reduce((a, r) => a + r.bucket61to90, 0).toLocaleString()}</td>
                      <td className="p-3 font-mono text-amber-800">${filteredPatientAgingList.reduce((a, r) => a + r.bucket91to120, 0).toLocaleString()}</td>
                      <td className="p-3 font-mono text-red-800">${filteredPatientAgingList.reduce((a, r) => a + r.bucket120Plus, 0).toLocaleString()}</td>
                      <td className="p-3 font-mono text-indigo-950 font-black text-sm">${filteredPatientAgingList.reduce((a, r) => a + r.totalBalance, 0).toLocaleString()}</td>
                      <td colSpan={3}></td>
                    </tr>
                  </tfoot>
                </table>
              </div>
            </div>

          </div>
        </div>
      )}

      {/* TAB 2: STEP 4A ADVANCED AI CLAIM SCRUBBING & VALIDATION ENGINE */}
      {activeTab === 'scrubbing' && (
        <div className="space-y-6">
          <div className="p-5 bg-white rounded-2xl border border-stone-200 shadow-2xs space-y-4">
            <div className="flex flex-wrap items-center justify-between border-b border-stone-100 pb-3 gap-3">
              <div>
                <div className="flex items-center gap-2">
                  <Sparkles className="w-5 h-5 text-indigo-600" />
                  <h3 className="font-bold text-base text-stone-900">
                    Step 4A: Advanced Claim Scrubbing & Validation Engine
                  </h3>
                  <span className="px-2.5 py-0.5 rounded-full bg-indigo-100 text-indigo-800 text-xs font-bold border border-indigo-200">
                    NCCI & LCD/NCD Rules Active
                  </span>
                </div>
                <p className="text-xs text-stone-500 font-medium mt-1">
                  Automated pre-submission validation checking demographics, insurance eligibility, NPI credentialing, CPT modifiers, diagnosis-to-procedure linkage, and POS 24 ASC rules before clearinghouse transmission.
                </p>
              </div>

              <button
                onClick={() => {
                  claims.forEach((c) => {
                    if (c.scrubErrors.length > 0) handleFixClaimWithAI(c.id);
                  });
                }}
                className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-xl shadow-2xs transition-colors cursor-pointer flex items-center gap-1.5"
              >
                <Sparkles className="w-4 h-4 text-indigo-200" />
                <span>1-Click Auto-Fix All Scrubbing Errors</span>
              </button>
            </div>

            {/* Error Queue & Work Items */}
            <div className="space-y-3">
              {claims.map((claim) => {
                const hasErrors = claim.scrubErrors.length > 0;

                return (
                  <div
                    key={claim.id}
                    className={`p-4 rounded-2xl border transition-all ${
                      hasErrors
                        ? 'bg-amber-50/50 border-amber-300 shadow-2xs'
                        : 'bg-white border-stone-200'
                    }`}
                  >
                    <div className="flex flex-wrap items-start justify-between gap-3 border-b border-stone-200 pb-3">
                      <div className="space-y-1">
                        <div className="flex flex-wrap items-center gap-2">
                          <span className="font-bold text-sm text-stone-900">{claim.id}</span>
                          <span className="px-2.5 py-0.5 rounded-full bg-stone-100 text-stone-800 font-bold text-xs border border-stone-200">
                            {claim.claimType}
                          </span>
                          <span className="text-xs font-bold text-indigo-700 font-mono">
                            ${claim.totalCharge.toLocaleString()}
                          </span>
                        </div>
                        <div className="text-xs text-stone-600">
                          Patient: <strong className="text-stone-900">{claim.patientName}</strong> ({claim.patientId}) · DOS: {claim.dos} · Payer: <strong className="text-stone-900">{claim.payer}</strong>
                        </div>
                      </div>

                      {/* AI Readiness Score Badge */}
                      <div className="flex items-center gap-2">
                        <div className="text-right">
                          <div className="text-[10px] font-bold text-stone-400 uppercase">AI Readiness Score</div>
                          <div
                            className={`text-base font-black font-mono ${
                              claim.readinessScore >= 90
                                ? 'text-emerald-700'
                                : claim.readinessScore >= 70
                                ? 'text-amber-700'
                                : 'text-red-700'
                            }`}
                          >
                            {claim.readinessScore}%
                          </div>
                        </div>

                        {hasErrors ? (
                          <button
                            onClick={() => handleFixClaimWithAI(claim.id)}
                            className="px-3.5 py-1.5 bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs rounded-xl transition-colors cursor-pointer flex items-center gap-1 shadow-2xs"
                          >
                            <Sparkles className="w-3.5 h-3.5" />
                            <span>AI Auto-Fix ({claim.scrubErrors.length})</span>
                          </button>
                        ) : (
                          <button
                            onClick={() => handleSubmitClaimToClearinghouse(claim.id)}
                            disabled={claim.status === 'Submitted'}
                            className="px-3.5 py-1.5 bg-emerald-700 hover:bg-emerald-800 disabled:opacity-50 text-white font-bold text-xs rounded-xl transition-colors cursor-pointer flex items-center gap-1 shadow-2xs"
                          >
                            <Send className="w-3.5 h-3.5" />
                            <span>{claim.status === 'Submitted' ? 'Submitted' : 'Submit EDI 837'}</span>
                          </button>
                        )}
                      </div>
                    </div>

                    {/* Scrubbing Error Cards if any */}
                    {hasErrors && (
                      <div className="mt-3 space-y-2">
                        <div className="text-[11px] font-bold text-amber-900 uppercase tracking-wider flex items-center gap-1">
                          <AlertTriangle className="w-3.5 h-3.5 text-amber-600" />
                          <span>Validation Errors Requiring Attention:</span>
                        </div>
                        {claim.scrubErrors.map((err, idx) => (
                          <div
                            key={idx}
                            className="p-2.5 bg-white rounded-xl border border-amber-200 text-xs text-stone-800 flex items-start justify-between gap-2"
                          >
                            <div>
                              <strong className="text-stone-900 font-semibold">{err.field}:</strong> {err.message}
                            </div>
                            <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-100 text-amber-900 border border-amber-200">
                              {err.severity}
                            </span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: CMS-1500 & UB-04 CLAIMS */}
      {activeTab === 'claims' && (
        <div className="space-y-6">
          <div className="p-5 bg-white rounded-2xl border border-stone-200 shadow-2xs space-y-4">
            <div className="flex items-center justify-between border-b border-stone-100 pb-3">
              <div>
                <h3 className="font-bold text-base text-stone-900">
                  Electronic Claims Management (CMS-1500 Professional & UB-04 ASC Facility)
                </h3>
                <p className="text-xs text-stone-500 font-medium">
                  Generating X12 837P (Professional) and X12 837I (Institutional) compliant electronic claims
                </p>
              </div>

              <button
                onClick={() => onShowToast('Created new CMS-1500 / UB-04 claim entry from operative note!')}
                className="px-3.5 py-1.5 bg-indigo-600 text-white font-bold text-xs rounded-xl hover:bg-indigo-700 transition-colors cursor-pointer flex items-center gap-1"
              >
                <Plus className="w-4 h-4" />
                <span>+ Create New Claim</span>
              </button>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left">
                <thead className="bg-stone-50 text-stone-700 uppercase font-bold border-b border-stone-200">
                  <tr>
                    <th className="p-3">Claim ID & Type</th>
                    <th className="p-3">Patient & DOS</th>
                    <th className="p-3">Payer</th>
                    <th className="p-3">CPT / Revenue Codes</th>
                    <th className="p-3 font-mono">Charge</th>
                    <th className="p-3">Readiness</th>
                    <th className="p-3">Status</th>
                    <th className="p-3 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-200 font-medium">
                  {claims.map((c) => (
                    <tr key={c.id} className="hover:bg-stone-50">
                      <td className="p-3 font-bold text-stone-900">
                        <div>{c.id}</div>
                        <div className="text-[10px] text-indigo-700 font-semibold">{c.claimType}</div>
                      </td>
                      <td className="p-3">
                        <div className="font-bold text-stone-900">{c.patientName}</div>
                        <div className="text-[10px] text-stone-500 font-mono">{c.dos}</div>
                      </td>
                      <td className="p-3 font-bold text-stone-800">
                        {c.payer}
                      </td>
                      <td className="p-3">
                        <div className="flex flex-wrap gap-1">
                          {c.cptCodes.map((code) => (
                            <span key={code} className="px-1.5 py-0.5 bg-stone-100 text-stone-800 rounded font-mono text-[10px] border border-stone-200">
                              {code}
                            </span>
                          ))}
                        </div>
                      </td>
                      <td className="p-3 font-mono font-bold text-stone-900">
                        ${c.totalCharge.toLocaleString()}
                      </td>
                      <td className="p-3 font-bold font-mono">
                        <span className={c.readinessScore >= 90 ? 'text-emerald-700' : 'text-amber-700'}>
                          {c.readinessScore}%
                        </span>
                      </td>
                      <td className="p-3">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          c.status === 'Submitted'
                            ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                            : c.status === 'Ready to Submit'
                            ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                            : 'bg-amber-50 text-amber-800 border border-amber-200'
                        }`}>
                          {c.status}
                        </span>
                      </td>
                      <td className="p-3 text-right">
                        <button
                          onClick={() => handleSubmitClaimToClearinghouse(c.id)}
                          disabled={c.status === 'Submitted'}
                          className="px-2.5 py-1 bg-indigo-50 hover:bg-indigo-100 text-indigo-800 font-bold text-xs rounded-lg border border-indigo-200 transition-colors cursor-pointer"
                        >
                          Transmit 837 EDI
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: PATIENT INVOICES & CASH-PAY BILLING */}
      {activeTab === 'invoices' && (
        <div className="space-y-6">
          <CaseInvoicesTable />
          <div className="p-5 bg-white rounded-2xl border border-stone-200 shadow-2xs space-y-4">
            <div className="flex flex-wrap items-center justify-between border-b border-stone-100 pb-3 gap-3">
              <div>
                <h3 className="font-bold text-base text-stone-900 flex items-center gap-2">
                  <DollarSign className="w-5 h-5 text-indigo-600" />
                  <span>Patient Standard Itemized Invoices & Self-Pay Billing</span>
                </h3>
                <p className="text-xs text-stone-500 font-medium">
                  Standardized invoice templates, facility fees, surgeon fees, prompt-pay discounts, and instant payment recording
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => setIsStandalonePaymentModalOpen(true)}
                  className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs rounded-xl shadow-2xs transition-colors cursor-pointer flex items-center gap-1.5"
                >
                  <CreditCard className="w-4 h-4" />
                  <span>Collect / Record Payment</span>
                </button>
                <button
                  onClick={() => setIsCreateInvoiceModalOpen(true)}
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-xl shadow-2xs transition-colors cursor-pointer flex items-center gap-1.5"
                >
                  <Plus className="w-4 h-4" />
                  <span>+ Create Standard Patient Invoice</span>
                </button>
              </div>
            </div>

            {/* Invoices List */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {invoices.map((inv) => (
                <div key={inv.id} className="p-4 bg-stone-50/80 rounded-2xl border border-stone-200 hover:border-stone-300 transition-all space-y-3.5 shadow-2xs">
                  <div className="flex items-start justify-between border-b border-stone-200 pb-2.5">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-xs font-bold text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded border border-indigo-200">
                          {inv.invoiceNumber}
                        </span>
                        <span className="text-[11px] text-stone-400 font-mono font-medium">
                          DOS: {inv.dos}
                        </span>
                      </div>
                      <h4 className="font-bold text-sm text-stone-900 mt-1">{inv.patientName}</h4>
                      <p className="text-[11px] text-stone-600 font-medium">{inv.procedure}</p>
                    </div>

                    <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold border ${
                      inv.status === 'Paid in Full'
                        ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                        : inv.status === 'Sent via Email'
                        ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                        : inv.status === 'Overdue'
                        ? 'bg-red-50 text-red-800 border-red-200'
                        : 'bg-amber-50 text-amber-800 border-amber-200'
                    }`}>
                      {inv.status}
                    </span>
                  </div>

                  {/* Financial Breakdown Grid */}
                  <div className="grid grid-cols-2 gap-2 text-xs font-medium">
                    <div className="bg-white p-2.5 rounded-xl border border-stone-200">
                      <span className="text-[10px] text-stone-400 font-bold uppercase block">Facility Fee</span>
                      <span className="font-bold text-stone-900 font-mono">${inv.facilityFee.toLocaleString()}</span>
                    </div>
                    <div className="bg-white p-2.5 rounded-xl border border-stone-200">
                      <span className="text-[10px] text-stone-400 font-bold uppercase block">Surgeon Fee</span>
                      <span className="font-bold text-stone-900 font-mono">${inv.surgeonFee.toLocaleString()}</span>
                    </div>
                    <div className="bg-white p-2.5 rounded-xl border border-stone-200">
                      <span className="text-[10px] text-stone-400 font-bold uppercase block">Anesthesia / Supplies</span>
                      <span className="font-bold text-stone-900 font-mono">${(inv.anesthesiaFee + inv.implantCharges + inv.medicationCharges).toLocaleString()}</span>
                    </div>
                    <div className="bg-white p-2.5 rounded-xl border border-stone-200">
                      <span className="text-[10px] text-emerald-700 font-bold uppercase block">Total Balance Due</span>
                      <span className="font-black text-indigo-950 font-mono text-sm">${inv.balanceDue.toLocaleString()}</span>
                    </div>
                  </div>

                  {/* Invoice Actions */}
                  <div className="flex items-center justify-between pt-2 border-t border-stone-200 text-xs">
                    <div className="text-[11px] text-stone-500 font-medium">
                      Guarantor: <strong className="text-stone-800">{inv.guarantor}</strong>
                    </div>

                    <div className="flex items-center gap-1.5">
                      <button
                        onClick={() => {
                          setSelectedInvoice(inv);
                          setIsInvoiceModalOpen(true);
                        }}
                        className="px-3 py-1.5 bg-white hover:bg-stone-100 text-stone-800 font-bold rounded-xl border border-stone-300 transition-colors cursor-pointer flex items-center gap-1 shadow-2xs"
                      >
                        <FileText className="w-3.5 h-3.5 text-indigo-600" />
                        <span>Standard Template</span>
                      </button>

                      <button
                        onClick={() => {
                          setPaymentTargetInvoice(inv);
                          setPaymentAmountInput(inv.balanceDue.toString());
                          setIsRecordPaymentModalOpen(true);
                        }}
                        className="px-3 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white font-bold rounded-xl transition-colors cursor-pointer flex items-center gap-1 shadow-2xs"
                      >
                        <CreditCard className="w-3.5 h-3.5" />
                        <span>Record Pay</span>
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 5: REAL-TIME ELIGIBILITY (X12 270/271) */}
      {activeTab === 'eligibility' && (
        <div className="space-y-6">
          <div className="p-5 bg-white rounded-2xl border border-stone-200 shadow-2xs space-y-4">
            <div className="flex items-center justify-between border-b border-stone-100 pb-3">
              <div>
                <h3 className="font-bold text-base text-stone-900">
                  Real-Time Insurance Eligibility & Benefits Inquiry (X12 270/271 EDI)
                </h3>
                <p className="text-xs text-stone-500 font-medium">
                  Instant eligibility verification, copay/deductible lookup, and pre-authorization requirement checks
                </p>
              </div>

              <span className="px-3 py-1 bg-emerald-50 text-emerald-800 font-bold text-xs rounded-full border border-emerald-200">
                ● Live 270 Inquiry API Connected
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
              {/* Form Input */}
              <div className="md:col-span-5 p-4 bg-stone-50 rounded-2xl border border-stone-200 space-y-3 text-xs">
                <div className="font-bold text-stone-900">Run Real-Time Benefit Check</div>

                <div className="space-y-1">
                  <label className="font-bold text-stone-700">Select Scheduled Patient</label>
                  <select
                    value={eligibilityPatientId}
                    onChange={(e) => setEligibilityPatientId(e.target.value)}
                    className="w-full p-2 bg-white border border-stone-300 rounded-xl font-bold text-stone-900 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  >
                    {cases.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.name} — {c.procedure}
                      </option>
                    ))}
                  </select>
                </div>

                <button
                  onClick={() => {
                    onShowToast('Transmitted X12 270 Eligibility Inquiry... 271 Response received in 0.8s!');
                  }}
                  className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl transition-colors cursor-pointer flex items-center justify-center gap-2"
                >
                  <RefreshCw className="w-4 h-4" />
                  <span>Transmit X12 270 Benefit Inquiry</span>
                </button>
              </div>

              {/* 271 Eligibility Result Card */}
              {eligibilityResult && (
                <div className="md:col-span-7 p-4 bg-emerald-50/60 rounded-2xl border border-emerald-200 space-y-3 text-xs">
                  <div className="flex items-center justify-between border-b border-emerald-200 pb-2">
                    <span className="font-bold text-emerald-900 text-sm flex items-center gap-1.5">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                      <span>X12 271 Response: Coverage Active</span>
                    </span>
                    <span className="font-mono text-[10px] text-emerald-700 font-bold">Latency: 780ms</span>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div className="bg-white p-2.5 rounded-xl border border-emerald-200">
                      <span className="text-[10px] font-bold text-stone-400 block uppercase">Payer Name</span>
                      <strong className="text-stone-900">{eligibilityResult.payerName}</strong>
                    </div>
                    <div className="bg-white p-2.5 rounded-xl border border-emerald-200">
                      <span className="text-[10px] font-bold text-stone-400 block uppercase">Prior Auth Status</span>
                      <strong className="text-indigo-900">{eligibilityResult.preAuthNumber || 'Auth Required'}</strong>
                    </div>
                    <div className="bg-white p-2.5 rounded-xl border border-emerald-200">
                      <span className="text-[10px] font-bold text-stone-400 block uppercase">Deductible Remaining</span>
                      <strong className="text-stone-900 font-mono">${eligibilityResult.deductibleRemaining}</strong>
                    </div>
                    <div className="bg-white p-2.5 rounded-xl border border-emerald-200">
                      <span className="text-[10px] font-bold text-stone-400 block uppercase">Coinsurance</span>
                      <strong className="text-stone-900 font-mono">{eligibilityResult.coinsurance}</strong>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* TAB 8: CLEARINGHOUSE EDI ADMIN MODAL / PANEL */}
      {activeTab === 'clearinghouse' && (
        <div className="p-5 bg-white rounded-2xl border border-stone-200 shadow-2xs space-y-4">
          <div className="flex items-center justify-between border-b border-stone-100 pb-3">
            <div>
              <h3 className="font-bold text-base text-stone-900">
                Clearinghouse & EDI Integration Administration
              </h3>
              <p className="text-xs text-stone-500 font-medium">
                Configure X12 837P, 837I, 835 ERA, and 270/271 endpoints for ASC electronic claim transmittal
              </p>
            </div>

            <span className="px-3 py-1 bg-indigo-50 text-indigo-800 text-xs font-bold rounded-full border border-indigo-200">
              Environment: {clearinghouseMode}
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
            <div className="space-y-1">
              <label className="font-bold text-stone-800">Clearinghouse Vendor Partner</label>
              <select
                value={clearinghouseVendor}
                onChange={(e) => setClearinghouseVendor(e.target.value)}
                className="w-full p-2.5 bg-stone-50 border border-stone-300 rounded-xl font-bold text-stone-900"
              >
                <option value="Change Healthcare">Change Healthcare</option>
                <option value="Availity">Availity Essentials EDI</option>
                <option value="Office Ally">Office Ally Revenue Cycle</option>
                <option value="TriZetto">TriZetto Provider Solutions</option>
                <option value="Waystar">Waystar Healthcare Billing</option>
                <option value="Ability Network">Ability Network (Medicare Specialist)</option>
              </select>
            </div>

            <div className="space-y-1">
              <label className="font-bold text-stone-800">Trading Partner ID</label>
              <input
                type="text"
                value={tradingPartnerId}
                onChange={(e) => setTradingPartnerId(e.target.value)}
                className="w-full p-2.5 bg-stone-50 border border-stone-300 rounded-xl font-mono text-stone-900"
              />
            </div>

            <div className="space-y-1 md:col-span-2">
              <label className="font-bold text-stone-800">API Endpoint URL (X12 837 Batch Transmittal)</label>
              <input
                type="text"
                value={clearinghouseEndpoint}
                onChange={(e) => setClearinghouseEndpoint(e.target.value)}
                className="w-full p-2.5 bg-stone-50 border border-stone-300 rounded-xl font-mono text-stone-900"
              />
            </div>
          </div>

          <button
            onClick={() => onShowToast(`Updated Clearinghouse EDI connection parameters for ${clearinghouseVendor}!`)}
            className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-xs cursor-pointer"
          >
            Save EDI Connection Settings
          </button>
        </div>
      )}

      {/* STANDARD PATIENT INVOICE TEMPLATE MODAL */}
      {isInvoiceModalOpen && selectedInvoice && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-3xl w-full p-8 shadow-2xl border border-stone-300 space-y-6 my-8 animate-in fade-in zoom-in-95 duration-200">
            
            {/* Modal Header Actions */}
            <div className="flex items-center justify-between border-b border-stone-200 pb-4">
              <div className="flex items-center gap-2">
                <FileText className="w-5 h-5 text-indigo-600" />
                <div>
                  <h3 className="font-bold text-base text-stone-900">Standard Patient Financial Statement</h3>
                  <p className="text-xs text-stone-500 font-medium">Standard Itemized Medical Invoice Layout</p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => window.print()}
                  className="px-3 py-1.5 bg-stone-100 hover:bg-stone-200 text-stone-800 font-bold text-xs rounded-xl border border-stone-300 flex items-center gap-1 cursor-pointer transition-colors"
                >
                  <Printer className="w-4 h-4" />
                  <span>Print</span>
                </button>
                <button
                  onClick={() => setIsInvoiceModalOpen(false)}
                  className="p-1.5 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-600 cursor-pointer"
                >
                  ✕
                </button>
              </div>
            </div>

            {/* PRINTABLE STANDARD INVOICE BODY */}
            <div className="p-6 bg-white border-2 border-stone-200 rounded-2xl shadow-2xs font-sans space-y-6 text-stone-900">
              
              {/* Invoice Header / Letterhead */}
              <div className="flex flex-wrap justify-between items-start border-b-2 border-stone-900 pb-6 gap-4">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <Building2 className="w-6 h-6 text-indigo-700" />
                    <span className="font-black text-xl tracking-tight text-stone-900 uppercase">Practice LLC</span>
                  </div>
                  <div className="text-xs text-stone-600 font-medium leading-relaxed">
                    1000 Practice Way, Suite 500<br />
                    Los Angeles, CA 90024<br />
                    Phone: (310) 555-0180 · Tax ID: 95-4819201 · NPI: 1982736450
                  </div>
                </div>

                <div className="text-right space-y-1">
                  <div className="font-black text-lg text-indigo-950 tracking-wider">PATIENT STATEMENT & INVOICE</div>
                  <div className="font-mono text-xs font-bold text-stone-700">
                    Invoice #: <span className="text-indigo-600">{selectedInvoice.invoiceNumber}</span>
                  </div>
                  <div className="font-mono text-xs text-stone-600">
                    Invoice Date: {selectedInvoice.invoiceDate || selectedInvoice.dos}
                  </div>
                  <div className="font-mono text-xs font-bold text-red-700">
                    Payment Due Date: {selectedInvoice.dueDate || selectedInvoice.dos}
                  </div>
                </div>
              </div>

              {/* Patient & Guarantor Billing Info Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                {/* Patient Box */}
                <div className="p-3.5 bg-stone-50 rounded-xl border border-stone-200 space-y-1">
                  <div className="font-bold text-stone-400 text-[10px] uppercase tracking-wider">Patient Information</div>
                  <div className="font-bold text-stone-900 text-sm">{selectedInvoice.patientName}</div>
                  <div className="text-stone-600">Patient ID: <span className="font-mono font-bold text-stone-800">{selectedInvoice.patientId}</span></div>
                  <div className="text-stone-600">DOB: <span className="font-mono">{selectedInvoice.dob}</span></div>
                  <div className="text-stone-600">Email: {selectedInvoice.email}</div>
                </div>

                {/* Guarantor / Account Box */}
                <div className="p-3.5 bg-stone-50 rounded-xl border border-stone-200 space-y-1">
                  <div className="font-bold text-stone-400 text-[10px] uppercase tracking-wider">Responsible Guarantor</div>
                  <div className="font-bold text-stone-900 text-sm">{selectedInvoice.guarantor}</div>
                  <div className="text-stone-600">{selectedInvoice.guarantorAddress}</div>
                  <div className="pt-1 text-stone-600">
                    Date of Service (DOS): <strong className="font-mono text-stone-900">{selectedInvoice.dos}</strong>
                  </div>
                </div>
              </div>

              {/* Case & Clinical Details Banner */}
              <div className="p-3 bg-indigo-50/70 rounded-xl border border-indigo-200 text-xs flex flex-wrap justify-between gap-2">
                <div>
                  <span className="font-bold text-indigo-900">Surgical Procedure: </span>
                  <span className="font-semibold text-stone-800">{selectedInvoice.procedure}</span>
                </div>
                <div>
                  <span className="font-bold text-indigo-900">Surgeon: </span>
                  <span className="font-semibold text-stone-800">{selectedInvoice.surgeon}</span>
                </div>
                <div>
                  <span className="font-bold text-indigo-900">Anesthesiologist: </span>
                  <span className="font-semibold text-stone-800">{selectedInvoice.anesthesiologist}</span>
                </div>
              </div>

              {/* Itemized Services Standard Table */}
              <div className="overflow-x-auto">
                <table className="w-full text-xs text-left border-collapse">
                  <thead className="bg-stone-100 text-stone-700 font-bold uppercase border-b-2 border-stone-300">
                    <tr>
                      <th className="p-2.5">Service Line Description</th>
                      <th className="p-2.5 font-mono">CPT / Rev</th>
                      <th className="p-2.5 font-mono text-right">Gross Charge</th>
                      <th className="p-2.5 font-mono text-right">Ins. Adjustment</th>
                      <th className="p-2.5 font-mono text-right">Net Charge</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-stone-200 font-medium">
                    <tr>
                      <td className="p-2.5 font-bold text-stone-900">ASC Facility Fee (Operating Room & PACU Time)</td>
                      <td className="p-2.5 font-mono text-stone-600">Rev 0360 / CPT 29881</td>
                      <td className="p-2.5 font-mono text-right">${selectedInvoice.facilityFee.toLocaleString()}</td>
                      <td className="p-2.5 font-mono text-right text-stone-400">-$0.00</td>
                      <td className="p-2.5 font-mono text-right font-bold text-stone-900">${selectedInvoice.facilityFee.toLocaleString()}</td>
                    </tr>
                    <tr>
                      <td className="p-2.5 font-bold text-stone-900">Attending Surgeon Professional Fee</td>
                      <td className="p-2.5 font-mono text-stone-600">CPT 29881-50</td>
                      <td className="p-2.5 font-mono text-right">${selectedInvoice.surgeonFee.toLocaleString()}</td>
                      <td className="p-2.5 font-mono text-right text-stone-400">-$0.00</td>
                      <td className="p-2.5 font-mono text-right font-bold text-stone-900">${selectedInvoice.surgeonFee.toLocaleString()}</td>
                    </tr>
                    {selectedInvoice.anesthesiaFee > 0 && (
                      <tr>
                        <td className="p-2.5 font-bold text-stone-900">Anesthesia Professional & Drug Supplies</td>
                        <td className="p-2.5 font-mono text-stone-600">CPT 00142</td>
                        <td className="p-2.5 font-mono text-right">${selectedInvoice.anesthesiaFee.toLocaleString()}</td>
                        <td className="p-2.5 font-mono text-right text-stone-400">-$0.00</td>
                        <td className="p-2.5 font-mono text-right font-bold text-stone-900">${selectedInvoice.anesthesiaFee.toLocaleString()}</td>
                      </tr>
                    )}
                    {selectedInvoice.implantCharges > 0 && (
                      <tr>
                        <td className="p-2.5 font-bold text-stone-900">Surgical Implants & Hardware Carve-Out</td>
                        <td className="p-2.5 font-mono text-stone-600">HCPCS C1713</td>
                        <td className="p-2.5 font-mono text-right">${selectedInvoice.implantCharges.toLocaleString()}</td>
                        <td className="p-2.5 font-mono text-right text-stone-400">-$0.00</td>
                        <td className="p-2.5 font-mono text-right font-bold text-stone-900">${selectedInvoice.implantCharges.toLocaleString()}</td>
                      </tr>
                    )}
                    {selectedInvoice.medicationCharges > 0 && (
                      <tr>
                        <td className="p-2.5 font-bold text-stone-900">Pharmacy & Post-Op Medications</td>
                        <td className="p-2.5 font-mono text-stone-600">Rev 0250</td>
                        <td className="p-2.5 font-mono text-right">${selectedInvoice.medicationCharges.toLocaleString()}</td>
                        <td className="p-2.5 font-mono text-right text-stone-400">-$0.00</td>
                        <td className="p-2.5 font-mono text-right font-bold text-stone-900">${selectedInvoice.medicationCharges.toLocaleString()}</td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>

              {/* Summary Calculation Box */}
              <div className="flex justify-end pt-2">
                <div className="w-full md:w-72 bg-stone-50 p-3.5 rounded-xl border border-stone-200 text-xs space-y-1.5 font-mono">
                  <div className="flex justify-between">
                    <span className="text-stone-600 font-sans">Total Billed Charges:</span>
                    <span className="font-bold">${(selectedInvoice.facilityFee + selectedInvoice.surgeonFee + selectedInvoice.anesthesiaFee + selectedInvoice.implantCharges + selectedInvoice.medicationCharges).toLocaleString()}</span>
                  </div>
                  {selectedInvoice.discounts > 0 && (
                    <div className="flex justify-between text-emerald-700 font-bold">
                      <span className="font-sans">Prompt-Pay Discount:</span>
                      <span>-${selectedInvoice.discounts.toLocaleString()}</span>
                    </div>
                  )}
                  <div className="flex justify-between text-emerald-800 font-bold">
                    <span className="font-sans">Payments Received:</span>
                    <span>-${selectedInvoice.paymentsReceived.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between pt-2 border-t-2 border-stone-900 text-sm font-black text-indigo-950">
                    <span className="font-sans">PATIENT BALANCE DUE:</span>
                    <span>${selectedInvoice.balanceDue.toLocaleString()}</span>
                  </div>
                </div>
              </div>

              {/* Remittance Tear-off Stub */}
              <div className="border-t-2 border-dashed border-stone-300 pt-4 space-y-3">
                <div className="text-[10px] font-bold text-stone-400 uppercase tracking-widest text-center">
                  ✂ DETACH AND RETURN THIS REMITTANCE STUB WITH PAYMENT ✂
                </div>
                <div className="bg-stone-50 p-3 rounded-xl border border-stone-200 text-xs flex flex-wrap justify-between items-center gap-2 font-mono">
                  <div>
                    <strong>Patient:</strong> {selectedInvoice.patientName} ({selectedInvoice.patientId})<br />
                    <strong>Invoice #:</strong> {selectedInvoice.invoiceNumber}
                  </div>
                  <div>
                    <strong>Make Check Payable To:</strong> Practice LLC<br />
                    <strong>Mail To:</strong> 1000 Practice Way, Suite 500, Los Angeles CA 90024
                  </div>
                  <div className="text-right">
                    <strong>Amount Enclosed:</strong> $_________________
                  </div>
                </div>
              </div>

            </div>

            {/* Modal Bottom Toolbar Actions */}
            <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
              <div className="flex items-center gap-2">
                <button
                  onClick={() => {
                    handleSendInvoiceEmail(selectedInvoice.id);
                    setIsInvoiceModalOpen(false);
                  }}
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-xl shadow-2xs flex items-center gap-1.5 cursor-pointer transition-colors"
                >
                  <Mail className="w-4 h-4" />
                  <span>Transmit Statement via Portal & Email</span>
                </button>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => {
                    setPaymentTargetInvoice(selectedInvoice);
                    setPaymentAmountInput(selectedInvoice.balanceDue.toString());
                    setIsInvoiceModalOpen(false);
                    setIsRecordPaymentModalOpen(true);
                  }}
                  className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs rounded-xl shadow-2xs flex items-center gap-1.5 cursor-pointer transition-colors"
                >
                  <CreditCard className="w-4 h-4" />
                  <span>Record Payment for Invoice</span>
                </button>
              </div>
            </div>

          </div>
        </div>
      )}

      {/* CREATE PATIENT INVOICE MODAL */}
      {isCreateInvoiceModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-xl w-full p-6 shadow-2xl border border-stone-300 space-y-5 my-8">
            <div className="flex items-center justify-between border-b border-stone-200 pb-3">
              <div className="flex items-center gap-2">
                <Plus className="w-5 h-5 text-indigo-600" />
                <h3 className="font-bold text-base text-stone-900">Create Standard Itemized Invoice</h3>
              </div>
              <button
                onClick={() => setIsCreateInvoiceModalOpen(false)}
                className="p-1.5 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-600 cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateInvoice} className="space-y-4 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="font-bold text-stone-700">Patient Name *</label>
                  <input
                    type="text"
                    required
                    value={newInvoicePatientName}
                    onChange={(e) => setNewInvoicePatientName(e.target.value)}
                    className="w-full p-2 bg-stone-50 border border-stone-300 rounded-xl font-bold text-stone-900"
                  />
                </div>

                <div className="space-y-1">
                  <label className="font-bold text-stone-700">Guarantor Name *</label>
                  <input
                    type="text"
                    required
                    value={newInvoiceGuarantor}
                    onChange={(e) => setNewInvoiceGuarantor(e.target.value)}
                    className="w-full p-2 bg-stone-50 border border-stone-300 rounded-xl font-bold text-stone-900"
                  />
                </div>

                <div className="space-y-1">
                  <label className="font-bold text-stone-700">Patient Email *</label>
                  <input
                    type="email"
                    required
                    value={newInvoiceEmail}
                    onChange={(e) => setNewInvoiceEmail(e.target.value)}
                    className="w-full p-2 bg-stone-50 border border-stone-300 rounded-xl font-bold text-stone-900"
                  />
                </div>

                <div className="space-y-1">
                  <label className="font-bold text-stone-700">Date of Service (DOS) *</label>
                  <input
                    type="date"
                    required
                    value={newInvoiceDos}
                    onChange={(e) => setNewInvoiceDos(e.target.value)}
                    className="w-full p-2 bg-stone-50 border border-stone-300 rounded-xl font-bold text-stone-900"
                  />
                </div>

                <div className="space-y-1 md:col-span-2">
                  <label className="font-bold text-stone-700">Surgical Procedure Description *</label>
                  <input
                    type="text"
                    required
                    value={newInvoiceProcedure}
                    onChange={(e) => setNewInvoiceProcedure(e.target.value)}
                    className="w-full p-2 bg-stone-50 border border-stone-300 rounded-xl font-bold text-stone-900"
                  />
                </div>

                <div className="space-y-1">
                  <label className="font-bold text-stone-700">Surgeon</label>
                  <input
                    type="text"
                    value={newInvoiceSurgeon}
                    onChange={(e) => setNewInvoiceSurgeon(e.target.value)}
                    className="w-full p-2 bg-stone-50 border border-stone-300 rounded-xl font-bold text-stone-900"
                  />
                </div>

                <div className="space-y-1">
                  <label className="font-bold text-stone-700">Anesthesiologist</label>
                  <input
                    type="text"
                    value={newInvoiceAnesthesiologist}
                    onChange={(e) => setNewInvoiceAnesthesiologist(e.target.value)}
                    className="w-full p-2 bg-stone-50 border border-stone-300 rounded-xl font-bold text-stone-900"
                  />
                </div>
              </div>

              {/* Financial Charges Grid */}
              <div className="p-3 bg-stone-50 rounded-2xl border border-stone-200 space-y-2">
                <div className="font-bold text-stone-900 border-b border-stone-200 pb-1">Itemized Financial Charges ($)</div>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-stone-600 uppercase">Facility Fee ($)</label>
                    <input
                      type="number"
                      value={newInvoiceFacilityFee}
                      onChange={(e) => setNewInvoiceFacilityFee(parseFloat(e.target.value) || 0)}
                      className="w-full p-2 bg-white border border-stone-300 rounded-lg font-mono font-bold text-stone-900"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-stone-600 uppercase">Surgeon Fee ($)</label>
                    <input
                      type="number"
                      value={newInvoiceSurgeonFee}
                      onChange={(e) => setNewInvoiceSurgeonFee(parseFloat(e.target.value) || 0)}
                      className="w-full p-2 bg-white border border-stone-300 rounded-lg font-mono font-bold text-stone-900"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-stone-600 uppercase">Anesthesia Fee ($)</label>
                    <input
                      type="number"
                      value={newInvoiceAnesthesiaFee}
                      onChange={(e) => setNewInvoiceAnesthesiaFee(parseFloat(e.target.value) || 0)}
                      className="w-full p-2 bg-white border border-stone-300 rounded-lg font-mono font-bold text-stone-900"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-stone-600 uppercase">Implants ($)</label>
                    <input
                      type="number"
                      value={newInvoiceImplantCharges}
                      onChange={(e) => setNewInvoiceImplantCharges(parseFloat(e.target.value) || 0)}
                      className="w-full p-2 bg-white border border-stone-300 rounded-lg font-mono font-bold text-stone-900"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-stone-600 uppercase">Medications ($)</label>
                    <input
                      type="number"
                      value={newInvoiceMedicationCharges}
                      onChange={(e) => setNewInvoiceMedicationCharges(parseFloat(e.target.value) || 0)}
                      className="w-full p-2 bg-white border border-stone-300 rounded-lg font-mono font-bold text-stone-900"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-emerald-700 uppercase">Prompt Discount ($)</label>
                    <input
                      type="number"
                      value={newInvoiceDiscounts}
                      onChange={(e) => setNewInvoiceDiscounts(parseFloat(e.target.value) || 0)}
                      className="w-full p-2 bg-white border border-emerald-300 rounded-lg font-mono font-bold text-emerald-800"
                    />
                  </div>
                </div>

                <div className="pt-2 border-t border-stone-200 flex justify-between items-center text-sm font-black text-indigo-950">
                  <span>Net Invoice Balance Due:</span>
                  <span className="font-mono">${Math.max(0, (newInvoiceFacilityFee + newInvoiceSurgeonFee + newInvoiceAnesthesiaFee + newInvoiceImplantCharges + newInvoiceMedicationCharges) - newInvoiceDiscounts - newInvoicePaymentsReceived).toLocaleString()}</span>
                </div>
              </div>

              <label className="flex items-start gap-2 p-3 rounded-xl border border-stone-200 bg-stone-50 text-xs text-stone-700">
                <input type="checkbox" checked={sendInvoiceAfterSave} onChange={e=>setSendInvoiceAfterSave(e.target.checked)} className="mt-0.5"/>
                <span><strong>Email invoice immediately after saving.</strong> Leave unchecked to save as Draft for staff review. When the payment gateway is connected, emailed invoices can include a secure <strong>Pay Online</strong> link for the designated payer.</span>
              </label>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsCreateInvoiceModalOpen(false)}
                  className="px-4 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 font-bold rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl shadow-2xs"
                >
                  Generate Standard Invoice
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* STANDALONE DEPOSIT / ACCOUNT CREDIT MODAL */}
      {isStandalonePaymentModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-stone-300 space-y-4">
            <div className="flex items-center justify-between border-b border-stone-200 pb-3"><div className="flex items-center gap-2"><CreditCard className="w-5 h-5 text-emerald-700"/><div><h3 className="font-bold text-base text-stone-900">Collect / Record Payment</h3><p className="text-[11px] text-stone-500">Deposit or account credit before an invoice exists.</p></div></div><button onClick={()=>setIsStandalonePaymentModalOpen(false)} className="p-1.5 rounded-xl bg-stone-100">✕</button></div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <label className="font-bold text-stone-700">Patient Name<input value={standalonePayment.patientName} onChange={e=>setStandalonePayment({...standalonePayment,patientName:e.target.value})} className="mt-1 w-full p-2.5 border rounded-xl"/></label>
              <label className="font-bold text-stone-700">Patient ID<input value={standalonePayment.patientId} onChange={e=>setStandalonePayment({...standalonePayment,patientId:e.target.value})} className="mt-1 w-full p-2.5 border rounded-xl"/></label>
              <label className="font-bold text-stone-700">Amount ($)<input type="number" min="0" step="0.01" value={standalonePayment.amount} onChange={e=>setStandalonePayment({...standalonePayment,amount:Number(e.target.value)||0})} className="mt-1 w-full p-2.5 border rounded-xl font-mono"/></label>
              <label className="font-bold text-stone-700">Method<select value={standalonePayment.method} onChange={e=>setStandalonePayment({...standalonePayment,method:e.target.value})} className="mt-1 w-full p-2.5 border rounded-xl bg-white"><option>Credit Card</option><option>Debit Card</option><option>Cash</option><option>Check</option><option>ACH / Bank Transfer</option></select></label>
            </div>
            <label className="block text-xs font-bold text-stone-700">Reference / Transaction #<input value={standalonePayment.reference} onChange={e=>setStandalonePayment({...standalonePayment,reference:e.target.value})} className="mt-1 w-full p-2.5 border rounded-xl"/></label>
            <label className="block text-xs font-bold text-stone-700">Notes<textarea value={standalonePayment.notes} onChange={e=>setStandalonePayment({...standalonePayment,notes:e.target.value})} rows={2} className="mt-1 w-full p-2.5 border rounded-xl"/></label>
            <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-xs text-emerald-950">This is recorded as an <strong>unapplied patient credit</strong> until a future invoice is created or staff applies it to an existing balance.</div>
            <div className="flex justify-end gap-2"><button onClick={()=>setIsStandalonePaymentModalOpen(false)} className="px-4 py-2 bg-stone-100 rounded-xl text-xs font-bold">Cancel</button><button onClick={()=>{if(!standalonePayment.patientName || standalonePayment.amount<=0){onShowToast('Enter a patient and payment amount.');return;} const credit={id:`CR-${Date.now()}`,patientName:standalonePayment.patientName,patientId:standalonePayment.patientId||'unassigned',amount:standalonePayment.amount,date:new Date().toISOString().split('T')[0],method:standalonePayment.method}; setUnappliedCredits(prev=>[credit,...prev]); onShowToast(`💳 $${standalonePayment.amount.toLocaleString()} recorded as unapplied credit for ${standalonePayment.patientName}.`); setStandalonePayment({patientName:'',patientId:'',amount:0,method:'Credit Card',reference:'',notes:''}); setIsStandalonePaymentModalOpen(false);}} className="px-5 py-2 bg-emerald-700 text-white rounded-xl text-xs font-bold">Record Credit & Issue Receipt</button></div>
          </div>
        </div>
      )}

      {/* RECORD PAYMENT MODAL */}
      {isRecordPaymentModalOpen && paymentTargetInvoice && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-stone-300 space-y-4">
            <div className="flex items-center justify-between border-b border-stone-200 pb-3">
              <div className="flex items-center gap-2">
                <CreditCard className="w-5 h-5 text-emerald-600" />
                <h3 className="font-bold text-base text-stone-900">Record Patient Payment</h3>
              </div>
              <button
                onClick={() => setIsRecordPaymentModalOpen(false)}
                className="p-1.5 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-600 cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="p-3 bg-stone-50 rounded-xl border border-stone-200 text-xs space-y-1">
              <div><strong>Patient:</strong> {paymentTargetInvoice.patientName} ({paymentTargetInvoice.patientId})</div>
              <div><strong>Invoice #:</strong> {paymentTargetInvoice.invoiceNumber}</div>
              <div><strong>Current Balance Due:</strong> <span className="font-mono font-bold text-indigo-900">${paymentTargetInvoice.balanceDue.toLocaleString()}</span></div>
            </div>

            <div className="space-y-3 text-xs">
              <div className="space-y-1">
                <label className="font-bold text-stone-700">Payment Amount ($) *</label>
                <input
                  type="number"
                  step="0.01"
                  value={paymentAmountInput}
                  onChange={(e) => setPaymentAmountInput(e.target.value)}
                  className="w-full p-2.5 bg-white border border-stone-300 rounded-xl font-mono text-base font-bold text-stone-900 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div className="space-y-1">
                <label className="font-bold text-stone-700">Payment Method</label>
                <select className="w-full p-2.5 bg-stone-50 border border-stone-300 rounded-xl font-bold text-stone-900">
                  <option>Credit Card (Stripe / Patient Portal)</option>
                  <option>Debit Card</option>
                  <option>Personal Check</option>
                  <option>Cash</option>
                  <option>ACH Direct Bank Transfer</option>
                  <option>CareCredit / Medical Financing</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="font-bold text-stone-700">Transaction / Check Reference #</label>
                <input
                  type="text"
                  placeholder="e.g. TXN-991823"
                  className="w-full p-2.5 bg-stone-50 border border-stone-300 rounded-xl font-mono text-stone-900"
                />
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2 border-t border-stone-200">
              <button
                type="button"
                onClick={() => setIsRecordPaymentModalOpen(false)}
                className="px-4 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 font-bold text-xs rounded-xl cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={handleRecordPayment}
                className="px-5 py-2 bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs rounded-xl shadow-2xs cursor-pointer"
              >
                Post Payment & Issue Receipt
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
