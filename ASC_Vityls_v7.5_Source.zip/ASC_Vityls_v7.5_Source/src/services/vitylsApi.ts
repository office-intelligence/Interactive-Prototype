import type { EncounterSummary } from '../vityls-next.types';

export interface VitylsApi {
  getEncounterSummary(encounterId: string): Promise<EncounterSummary>;
}

const mockEncounter: EncounterSummary = {
  encounterId: 'enc-reference-001',
  patientId: 'patient-reference-001',
  displayName: 'Reference Patient 001',
  age: 67,
  procedure: 'Bilateral blepharoplasty & upper lid revision',
  procedureVersion: 1,
  surgeon: 'Robert Jones, MD',
  anesthesia: 'General anesthesia',
  room: 'OR #1',
  scheduledTime: '09:00 AM',
  journey: [
    { id: 'intake', label: 'At Home', state: 'complete', detail: 'Intake + patient documents complete' },
    { id: 'front-desk', label: 'Front Desk', state: 'complete', detail: 'Administrative readiness complete' },
    { id: 'nursing', label: 'Pre-Op RN', state: 'active', detail: 'Clinical review in progress' },
    { id: 'anesthesia', label: 'Anesthesia', state: 'waiting' },
    { id: 'surgeon', label: 'Surgeon', state: 'waiting' },
    { id: 'or-gate', label: 'OR Gate', state: 'locked', detail: 'Awaiting clinical authentication' },
    { id: 'procedure', label: 'Procedure', state: 'later' },
    { id: 'pacu', label: 'PACU', state: 'later' },
    { id: 'discharge', label: 'Discharge', state: 'later' },
  ],
  allergies: [
    { conceptId: 'patient.allergies.ciprofloxacin', label: 'Ciprofloxacin (Cipro)', value: 'Reaction needs clarification', status: 'needs_review', attention: 'Clarify reaction with patient', provenance: { source: 'patient', label: 'Patient reported at home', recordedAt: 'Yesterday 7:41 PM' } },
  ],
  medications: [
    { conceptId: 'patient.medications.omeprazole', label: 'Omeprazole', value: 'Dose/frequency on file', status: 'complete', provenance: { source: 'patient', label: 'Patient intake', recordedAt: 'Yesterday 7:44 PM' } },
    { conceptId: 'encounter.medications.anticoagulant_screen', label: 'Anticoagulant / antiplatelet', value: 'None documented', status: 'needs_review', provenance: { source: 'patient', label: 'Patient intake', recordedAt: 'Yesterday 7:45 PM' } },
    { conceptId: 'encounter.medications.glp1_screen', label: 'GLP-1 / GIP medication', value: 'None documented', status: 'needs_review', provenance: { source: 'patient', label: 'Patient intake', recordedAt: 'Yesterday 7:45 PM' } },
  ],
  history: [
    { conceptId: 'patient.conditions.prediabetes', label: 'Prediabetes', value: 'Reported / outside record', status: 'complete', provenance: { source: 'outside_record', label: 'Medical clearance', recordedAt: 'Pre-admission' } },
    { conceptId: 'patient.conditions.obesity', label: 'Obesity', value: 'History noted', status: 'complete', provenance: { source: 'outside_record', label: 'Medical clearance', recordedAt: 'Pre-admission' } },
    { conceptId: 'patient.surgical_history.gastric_sleeve', label: 'Gastric sleeve', value: 'Prior surgery', status: 'complete', provenance: { source: 'patient', label: 'Patient intake', recordedAt: 'Yesterday' } },
  ],
  readiness: [
    { label: 'Patient intake', state: 'complete' },
    { label: 'Required documents', state: 'complete' },
    { label: 'Nursing clinical review', state: 'needs_review', detail: '1 clarification remains' },
    { label: 'Anesthesia evaluation', state: 'blocked', detail: 'Waiting for RN handoff' },
    { label: 'Surgeon assessment', state: 'blocked', detail: 'Waiting' },
    { label: 'Final OR gate', state: 'blocked', detail: 'Clinical authentication incomplete' },
  ],
  vte: { factors: [{ label: 'Age 60–74', points: 2 }, { label: 'Obesity', points: 1 }, { label: 'Surgery >45 minutes', points: 2 }], total: 5, risk: 'High' },
  mh: { positiveResponses: 0, totalQuestions: 16, result: 'No positive MH risk indicators reported' },
};

export const mockVitylsApi: VitylsApi = {
  async getEncounterSummary() {
    await new Promise(resolve => setTimeout(resolve, 120));
    return structuredClone(mockEncounter);
  },
};
