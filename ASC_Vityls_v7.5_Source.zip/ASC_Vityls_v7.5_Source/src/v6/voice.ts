/*
 * Nightingale voice capture — push-to-talk, pluggable, local by default.
 *
 * Nothing in this file sends audio or text off the device. The default
 * TranscriptionAdapter is a LOCAL MOCK: it never opens the microphone; it returns
 * a scripted sample sentence for the open form (or what the tester types), so the
 * review-and-confirm flow can be evaluated safely. The default ExtractionAdapter
 * is a local rule-based extractor.
 *
 * To go live later, register adapters that call BAA-covered services from the
 * SERVER (e.g. AWS Transcribe Medical + Bedrock, Azure Speech + Azure OpenAI,
 * Google Cloud STT + Vertex AI), with audio retention ≤ 7 days / until signing.
 * Never use the browser's built-in dictation (webkitSpeechRecognition) with PHI:
 * it streams audio to Google/Apple without a BAA.
 */
import type { FieldInfo } from './formEnhancer';

export interface Transcript { text: string; startedAt: string; endedAt: string; speaker: string; device: string; adapter: string }
export interface Suggestion {
  id: string; key: string; label: string; value: string | boolean; confidence: number; snippet: string;
  alwaysConfirm: boolean;   // allergies, doses, laterality, counts
  status: 'pending' | 'accepted' | 'rejected';
}
export interface TranscriptionAdapter { id: string; label: string; offDevice: boolean; start(): Promise<void>; stop(sampleHint?: string): Promise<Omit<Transcript, 'speaker' | 'device'>> }
export interface ExtractionAdapter { id: string; label: string; offDevice: boolean; extract(t: Transcript, fields: FieldInfo[]): Promise<{ suggestions: Suggestion[]; unfiled: string[] }> }

export const CONFIDENCE = { suggest: 0.9, check: 0.7 } as const; // below 0.70 → not filled (left in the "heard but not filed" tray)

/* ---------- default local mock transcription ---------- */
export const localMockTranscriber: TranscriptionAdapter = {
  id: 'local-mock', label: 'Local mock (no microphone, nothing leaves this device)', offDevice: false,
  async start() { /* intentionally does not call getUserMedia */ },
  async stop(sampleHint) { const now = new Date().toISOString(); return { text: sampleHint || '', startedAt: now, endedAt: now, adapter: 'local-mock' }; },
};

/* ---------- default local rule-based extraction ---------- */
const WORDNUM: Record<string, number> = { one: 1, two: 2, three: 3, four: 4, five: 5, six: 6, seven: 7, eight: 8, nine: 9, ten: 10, eleven: 11, twelve: 12 };
const toTime = (h: string, m?: string, ap?: string) => {
  let hh = Number(h); const mm = m ? Number(m) : 0;
  if (ap && /p/i.test(ap) && hh < 12) hh += 12;
  if (ap && /a/i.test(ap) && hh === 12) hh = 0;
  return `${String(hh).padStart(2, '0')}:${String(mm).padStart(2, '0')}`;
};
type Rule = { re: RegExp; field: RegExp; value: (m: RegExpMatchArray) => string | boolean; conf: number; confirm?: boolean; section?: RegExp };
const T = String.raw`(\d{1,2})(?::|\s)?(\d{2})?\s*(am|pm|a\.m\.|p\.m\.)?`;
const RULES: Rule[] = [
  { re: new RegExp(String.raw`(?:last )?(?:ate|solid|food|toast|meal)[^.]*?(?:at|around)\s+(\w+|\d{1,2})(?::(\d{2}))?\s*(?:o'clock)?\s*(last night|this morning|am|pm)?`, 'i'), field: /^last solid food/i, value: m => { const h = WORDNUM[m[1]?.toLowerCase()] ?? Number(m[1]); return toTime(String(h), m[2], /night|pm/i.test(m[3] || '') ? 'pm' : 'am'); }, conf: 0.93 },
  { re: new RegExp(String.raw`(?:clear|water|liquid|drink)[^.]*?(?:at|around)\s+(\w+|\d{1,2})(?::(\d{2}))?\s*(this morning|last night|am|pm)?`, 'i'), field: /^last clear liquid/i, value: m => { const h = WORDNUM[m[1]?.toLowerCase()] ?? Number(m[1]); return toTime(String(h), m[2], /night|pm/i.test(m[3] || '') ? 'pm' : 'am'); }, conf: 0.92 },
  { re: /(?:her|his|their)?\s*(husband|wife|son|daughter|mother|father|partner|friend|brother|sister)\s+(\w+)?\s*(?:is )?driving/i, field: /responsible adult.*driver|^responsible adult name$/i, value: m => `${m[2] ? m[2] + ' ' : ''}(${m[1].toLowerCase()})`.trim(), conf: 0.91 },
  { re: /(\w+) foot (\w+)/i, field: /^height$/i, value: m => `${WORDNUM[m[1].toLowerCase()] ?? m[1]}' ${WORDNUM[m[2].toLowerCase()] ?? m[2]}"`, conf: 0.94 },
  { re: /(\d{2,3})\s*(?:pounds|lbs?)/i, field: /^weight$/i, value: m => `${m[1]} lb`, conf: 0.95 },
  { re: /\bBP\s*(\d{2,3})\s*(?:over|\/)\s*(\d{2,3})/i, field: /^(initial )?bp( \(mmhg\))?$|^bp · row 1$/i, value: m => `${m[1]}/${m[2]}`, conf: 0.95 },
  { re: /(?:pulse|heart rate|HR)\s*(\d{2,3})/i, field: /^(heart rate( \(bpm\))?|hr( \(bpm\))?|hr · row 1)$/i, value: m => m[1], conf: 0.94 },
  { re: /(?:resp|respirations|RR)\s*(\d{1,2})/i, field: /^(respiratory rate|rr|rr · row 1)$/i, value: m => m[1], conf: 0.9 },
  { re: /(?:sats?|spo2|saturation)\s*(\d{2,3})/i, field: /^(spo2( \(%\))?|spo2 · row 1)$/i, value: m => m[1], conf: 0.94 },
  { re: /on (room air|\d+ liters?)/i, field: /^oxygen delivery$/i, value: m => /room/i.test(m[1]) ? 'Room air' : `${m[1].replace(/liters?/i, 'L')} NC`, conf: 0.8 },
  { re: /pain (\d{1,2})/i, field: /^initial pain level/i, value: m => m[1], conf: 0.9 },
  { re: new RegExp(String.raw`arrived to pacu\s+${T}`, 'i'), field: /^time of admission/i, value: m => toTime(m[1], m[2], m[3]), conf: 0.93 },
  { re: new RegExp(String.raw`in room\s+${T}`, 'i'), field: /^patient in (or|room)$/i, value: m => toTime(m[1], m[2], m[3]), conf: 0.93 },
  { re: new RegExp(String.raw`anesthesia start\s+${T}`, 'i'), field: /^anesthesia start$/i, value: m => toTime(m[1], m[2], m[3]), conf: 0.92 },
  { re: new RegExp(String.raw`incision\s+${T}`, 'i'), field: /^(surgery start( \(incision\))?|incision \/ start time)$/i, value: m => toTime(m[1], m[2], m[3]), conf: 0.93 },
  { re: new RegExp(String.raw`clos(?:ing|ure|e)\s+${T}`, 'i'), field: /^(surgery (end|stop)( \(close\))?|close \/ stop time)$/i, value: m => toTime(m[1], m[2], m[3]), conf: 0.9 },
  { re: new RegExp(String.raw`\bout\s+${T}`, 'i'), field: /^(out of or \/ to pacu|or out \/ transfer out)$/i, value: m => toTime(m[1], m[2], m[3]), conf: 0.88 },
  { re: /EBL (?:about |approximately |of )?(\d{1,4})/i, field: /^estimated blood loss/i, value: m => m[1], conf: 0.92 },
  { re: /wound class (one|two|three|four|i{1,3}|iv|\d)/i, field: /^wound classification$/i, value: m => ({ one: 'I', two: 'II', three: 'III', four: 'IV', '1': 'I', '2': 'II', '3': 'III', '4': 'IV' } as Record<string, string>)[m[1].toLowerCase()] || m[1].toUpperCase(), conf: 0.85 },
  { re: /no change since h(?:\s*and\s*|&)?p/i, field: /^no change in history since prior h&p$/i, value: () => true, conf: 0.95 },
  { re: /lungs (clear[^,.]*)/i, field: /^lungs$/i, value: m => m[1].replace(/^clear$/i, 'Clear bilaterally'), conf: 0.92 },
  { re: /heart (regular[^,.]*)/i, field: /^heart$/i, value: m => m[1].replace(/^regular$/i, 'Regular rate and rhythm'), conf: 0.92 },
  { re: /proceed as planned/i, field: /^proceed as planned$/i, value: () => true, conf: 0.95 },
  { re: /no complications/i, field: /^none$/i, value: () => true, conf: 0.9, section: /complication|findings/i },
  { re: /\buneventful\b/i, field: /^uneventful$/i, value: () => true, conf: 0.92 },
  { re: /findings:\s*([^.]+)/i, field: /^findings$/i, value: m => m[1].trim(), conf: 0.9 },
  { re: /technique:\s*([^.]+(?:\.[^.]+)?)/i, field: /^technique/i, value: m => m[1].trim(), conf: 0.86 },
  { re: /allerg(?:y|ic) to ([^.,]+)/i, field: /allerg/i, value: m => m[1].trim(), conf: 0.9, confirm: true },
];

export const localRuleExtractor: ExtractionAdapter = {
  id: 'local-rules', label: 'Local rules (on this device)', offDevice: false,
  async extract(t, fields) {
    const suggestions: Suggestion[] = []; const usedSpans: string[] = [];
    const sentences = t.text.split(/(?<=[.!?])\s+/);
    for (const r of RULES) {
      const m = t.text.match(r.re); if (!m) continue;
      const target = fields.find(f => r.field.test(f.label) && (!r.section || r.section.test(f.section)) && !f.el.closest('.vk-ignore') && !(f.el as HTMLInputElement).disabled);
      if (!target) continue;
      if (suggestions.some(s => s.key === target.key)) continue;
      const snippet = sentences.find(s => s.includes(m[0].trim().split(' ')[0])) || m[0];
      usedSpans.push(m[0]);
      suggestions.push({ id: `${target.key}-${suggestions.length}`, key: target.key, label: target.label, value: r.value(m), confidence: r.conf, snippet: snippet.trim(), alwaysConfirm: !!r.confirm || /allerg|dose|mg\b|side|laterality|count/i.test(target.label), status: 'pending' });
    }
    const unfiled = sentences.filter(s => s.trim() && !usedSpans.some(u => s.includes(u.trim().slice(0, 12))));
    return { suggestions: suggestions.filter(s => s.confidence >= CONFIDENCE.check), unfiled };
  },
};

/* Registry: swap these when BAA-covered adapters exist. The UI shows which are active. */
export const voiceConfig = { transcriber: localMockTranscriber as TranscriptionAdapter, extractor: localRuleExtractor as ExtractionAdapter };
