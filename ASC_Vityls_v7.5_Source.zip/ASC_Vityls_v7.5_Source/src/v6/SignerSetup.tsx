/*
 * Form Studio · signer setup step. Defines who signs a form at its station(s):
 * role, label, order, required/optional, attestation, and (multi-page forms) which pages need initials.
 * Saved through repo.saveSignerConfig (browser storage in this build); ruleFor() uses it before FORM_RULES.
 * Nightingale can never be a signer.
 */
import React, { useMemo } from 'react';
import { ArrowDown, ArrowUp, Plus, Trash2, AlertTriangle, PenLine } from 'lucide-react';
import type { StoredSignerSlot, StoredInitialsPage } from './dataLayer';
import { STAFF_SIGNER_ROLES, NON_STAFF_SIGNER_ROLES, isAiSigner } from './formRules';

/** baseIds: slot ids that already existed when the step opened. They are kept stable so signatures on existing records still match. */
export interface SignerDraft { signers: StoredSignerSlot[]; sequential: boolean; initials: StoredInitialsPage[]; source?: string; baseIds?: string[] }
export interface TemplatePage { index: number; title: string; hasInitialLines: boolean }

/** Pages of a multi-page template (section.page[data-title]); [] for single-page forms. */
export function templatePages(html: string): TemplatePage[] {
  try {
    const doc = new DOMParser().parseFromString(html || '', 'text/html');
    const pages = Array.from(doc.querySelectorAll<HTMLElement>('section.page'));
    if (pages.length < 2) return [];
    return pages.map((p, i) => ({ index: i, title: p.dataset.title || `Page ${i + 1}`, hasInitialLines: Array.from(p.querySelectorAll('input')).some(x => /^initials?$/i.test(x.getAttribute('placeholder') || '')) }));
  } catch { return []; }
}

const DEFAULT_ATTEST: Record<string, string> = {
  Patient: 'I have read (or had read to me) and understand this document, and I agree to it.',
  Escort: 'I received these instructions and will accompany the patient home.',
  Witness: 'I witnessed the signer sign this document.',
};
const slug = (t: string) => t.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') || 'signer';

export function validateSigners(d: SignerDraft): string[] {
  const e: string[] = [];
  if (!d.signers.length) e.push('Add at least one signer.');
  if (d.signers.length && !d.signers.some(s => s.required)) e.push('At least one signer must be required, or the form can never lock.');
  d.signers.forEach((s, i) => {
    if (isAiSigner(s)) e.push(`Signer ${i + 1}: Nightingale cannot be a signer. Only a person can attest and sign.`);
    if (!s.role.trim()) e.push(`Signer ${i + 1}: choose a role.`);
    if (!s.label.trim()) e.push(`Signer ${i + 1}: add a label.`);
    if (s.attestation.trim().length < 10) e.push(`Signer ${i + 1}: write the attestation the signer agrees to.`);
  });
  d.initials.forEach(p => { if (!d.signers.some(s => s.id === p.slot)) e.push(`Page ${p.pageIndex + 1} initials: choose who initials.`); });
  return e;
}

export const SignerSetup: React.FC<{ value: SignerDraft; onChange: (d: SignerDraft) => void; pages: TemplatePage[] }> = ({ value, onChange, pages }) => {
  const d = value;
  const roles = useMemo(() => Array.from(new Set([...STAFF_SIGNER_ROLES, ...NON_STAFF_SIGNER_ROLES, ...d.signers.map(s => s.role)])).filter(r => r && !isAiSigner({ role: r })), [d.signers]);
  const errors = validateSigners(d);
  const set = (signers: StoredSignerSlot[], extra: Partial<SignerDraft> = {}) => onChange({ ...d, signers, ...extra });
  const upd = (i: number, patch: Partial<StoredSignerSlot>) => set(d.signers.map((s, k) => k === i ? { ...s, ...patch } : s));
  const move = (i: number, dir: -1 | 1) => { const n = [...d.signers]; const j = i + dir; if (j < 0 || j >= n.length) return; [n[i], n[j]] = [n[j], n[i]]; set(n); };
  const add = () => {
    const role = 'Witness'; let id = slug(role); let k = 2; while (d.signers.some(s => s.id === id) || d.baseIds?.includes(id)) id = `${slug(role)}-${k++}`;
    set([...d.signers, { id, role, label: role, attestation: DEFAULT_ATTEST[role], required: true, patient: true }]);
  };
  const remove = (i: number) => { const gone = d.signers[i].id; onChange({ ...d, signers: d.signers.filter((_, k) => k !== i), initials: d.initials.filter(p => p.slot !== gone) }); };
  const changeRole = (i: number, role: string) => {
    const s = d.signers[i]; const ext = NON_STAFF_SIGNER_ROLES.includes(role);
    const labelWasDefault = !s.label.trim() || s.label === s.role; const attWasDefault = !s.attestation.trim() || Object.values(DEFAULT_ATTEST).includes(s.attestation);
    let id = s.id;
    if (!d.baseIds?.includes(s.id)) { const taken = new Set(d.signers.filter((_, k) => k !== i).map(x => x.id)); id = slug(role); let n = 2; while (taken.has(id)) id = `${slug(role)}-${n++}`; }
    onChange({ ...d, signers: d.signers.map((x, k) => k === i ? { ...x, id, role, patient: ext, label: labelWasDefault ? role : x.label, attestation: attWasDefault ? (DEFAULT_ATTEST[role] || 'I attest this document is accurate and complete.') : x.attestation } : x), initials: d.initials.map(p => p.slot === s.id ? { ...p, slot: id } : p) });
  };
  const pageInit = (idx: number) => d.initials.find(p => p.pageIndex === idx);
  const togglePage = (pg: TemplatePage, on: boolean) => {
    const rest = d.initials.filter(p => p.pageIndex !== pg.index);
    const first = d.signers.find(s => s.patient) || d.signers[0];
    onChange({ ...d, initials: on ? [...rest, { pageIndex: pg.index, pageTitle: pg.title, slot: first?.id || '', existing: pg.hasInitialLines || undefined, statement: pg.hasInitialLines ? undefined : `I have read this page (${pg.title}).` }].sort((a, b) => a.pageIndex - b.pageIndex) : rest });
  };
  const setPage = (idx: number, patch: Partial<StoredInitialsPage>) => onChange({ ...d, initials: d.initials.map(p => p.pageIndex === idx ? { ...p, ...patch } : p) });

  return <div className="space-y-4 text-[14px]" data-testid="signer-setup">
    <div className="vds-alert vds-alert-info"><PenLine /><div><b>Signers for this form</b><p className="text-[13px]">{d.source === 'saved' ? 'Loaded from this practice’s saved setup.' : d.source === 'built-in' ? 'Prefilled from the Vityls built-in rule for this form. Adjust it for your practice.' : 'This form has no built-in signer rule yet. Define who signs it.'} The signature block appears once, at the end of the form. Nightingale prepares forms but can never sign.</p></div></div>

    <div><h3 className="vds-field-title !text-[14px]">Signing order</h3>
      <div className="flex flex-wrap gap-2">{([[true, 'In this order', 'Each signer waits for the one above'], [false, 'Any order', 'Signers can sign in any sequence']] as const).map(([v, t, n]) =>
        <label key={String(v)} className={`vds-choice compact min-h-[44px] ${d.sequential === v ? 'selected' : ''}`}><input type="radio" name="signer-order" checked={d.sequential === v} onChange={() => onChange({ ...d, sequential: v })} data-testid={`order-${v ? 'seq' : 'any'}`} /><span><b className="text-[14px]">{t}</b><small className="text-[13px]">{n}</small></span></label>)}</div></div>

    <div><h3 className="vds-field-title !text-[14px]">Signer slots ({d.signers.length})</h3>
      <ol className="space-y-2">{d.signers.map((s, i) => <li key={s.id} className="bg-white border border-[#dce3de] rounded-lg p-3 space-y-2" data-testid={`signer-row-${i}`}>
        <div className="flex flex-wrap items-end gap-2">
          <span className="text-[14px] font-bold text-[#1f6e52] w-6">{i + 1}.</span>
          <label className="flex-1 min-w-[150px] text-[13px] font-bold text-[#4a5750]">Role<select value={s.role} onChange={e => changeRole(i, e.target.value)} className="vds-input mt-1" data-testid={`signer-role-${i}`}>
            <optgroup label="Staff">{roles.filter(r => !NON_STAFF_SIGNER_ROLES.includes(r)).map(r => <option key={r}>{r}</option>)}</optgroup>
            <optgroup label="Patient side / other">{NON_STAFF_SIGNER_ROLES.map(r => <option key={r}>{r}</option>)}</optgroup></select></label>
          <label className="flex-[2] min-w-[200px] text-[13px] font-bold text-[#4a5750]">Label shown to signers<input value={s.label} onChange={e => upd(i, { label: e.target.value })} className="vds-input mt-1" data-testid={`signer-label-${i}`} /></label>
          <label className="flex items-center gap-2 min-h-[44px] px-2 text-[14px] font-semibold"><input type="checkbox" checked={s.required} onChange={e => upd(i, { required: e.target.checked })} className="w-5 h-5 accent-[#1f6e52]" data-testid={`signer-required-${i}`} />Required</label>
          <div className="flex gap-1">
            <button type="button" onClick={() => move(i, -1)} disabled={i === 0} className="vds-btn vds-btn-secondary !px-3 disabled:opacity-40" aria-label="Move up"><ArrowUp className="w-4 h-4" /></button>
            <button type="button" onClick={() => move(i, 1)} disabled={i === d.signers.length - 1} className="vds-btn vds-btn-secondary !px-3 disabled:opacity-40" aria-label="Move down"><ArrowDown className="w-4 h-4" /></button>
            <button type="button" onClick={() => remove(i)} className="vds-btn vds-btn-danger !px-3" aria-label={`Remove signer ${i + 1}`}><Trash2 className="w-4 h-4" /></button>
          </div>
        </div>
        <label className="block text-[13px] font-bold text-[#4a5750]">Attestation (what the signer agrees to)<textarea value={s.attestation} onChange={e => upd(i, { attestation: e.target.value })} className="vds-input mt-1 min-h-[64px]" data-testid={`signer-attest-${i}`} /></label>
        <p className="text-[13px] text-[#525e57]">{s.patient ? 'Signs with their own name; no staff PIN.' : 'Staff signer: re-confirms identity (PIN) when signing.'}{!s.required ? ' Optional: the form can lock without this signature.' : ''}</p>
      </li>)}</ol>
      <button type="button" onClick={add} className="vds-btn vds-btn-secondary mt-2" data-testid="add-signer"><Plus className="w-4 h-4" /> Add signer</button>
    </div>

    {pages.length > 1 && <div><h3 className="vds-field-title !text-[14px]">Pages that need initials ({pages.length}-page form)</h3>
      <p className="text-[13px] text-[#525e57] mb-2">The full signature is collected once, on the last page. Tick only pages the original form asks to be initialed (for example arbitration or financial clauses). A ticked page shows a compact initials field tied to the chosen signer, who can’t sign until it is filled.</p>
      <ul className="space-y-1.5">{pages.map(pg => { const pi = pageInit(pg.index); return <li key={pg.index} className={`border rounded-lg p-2.5 bg-white ${pi ? 'border-[#5a987f]' : 'border-[#dce3de]'}`}>
        <div className="flex flex-wrap items-center gap-2">
          <label className="flex items-center gap-2 min-h-[44px] flex-1 min-w-[220px] text-[14px]"><input type="checkbox" checked={!!pi} onChange={e => togglePage(pg, e.target.checked)} className="w-5 h-5 flex-none accent-[#1f6e52]" data-testid={`initials-page-${pg.index}`} /><b>{pg.index + 1}. {pg.title}</b>{pg.hasInitialLines && <span className="text-[13px] text-[#7a4e17]">has initial lines in the template</span>}</label>
          {pi && <label className="text-[13px] font-bold text-[#4a5750] flex items-center gap-2">Initialed by<select value={pi.slot} onChange={e => setPage(pg.index, { slot: e.target.value })} className="vds-input !w-auto">{d.signers.map(s => <option key={s.id} value={s.id}>{s.label}</option>)}</select></label>}
        </div>
        {pi && <><textarea value={pi.statement || ''} onChange={e => setPage(pg.index, { statement: e.target.value, existing: undefined })} rows={Math.max(2, (pi.statement || '').split('\n').length)} className="vds-input mt-1" placeholder="Statement next to the initials box" aria-label={`Initials statement for page ${pg.index + 1}`} data-testid={`initials-statement-${pg.index}`} /><p className="text-[13px] text-[#4a5750] mt-1">One line per clause: each line gets its own initials box on this page.</p></>}
      </li>; })}</ul></div>}

    {errors.length > 0 && <div className="rounded-lg border border-[#e6cf9f] bg-[#fffaf0] p-3 text-[14px] text-[#6b4a10]" data-testid="signer-errors"><b className="flex items-center gap-1"><AlertTriangle className="w-4 h-4" /> Fix before saving</b><ul className="list-disc ml-5 mt-1">{errors.map(e => <li key={e}>{e}</li>)}</ul></div>}
  </div>;
};
