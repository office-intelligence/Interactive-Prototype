import { DialogShell, Btn } from '../v7/ui';
import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { X, Printer, Save, Mic, Check, Ban, Info, PenLine } from 'lucide-react';
import type { PatientCase } from '../types';
import { getFormHtmlSync } from './formSource';
import { mountForm, FormController } from './formEngine';
import { repo, FormRecord, Provenance, fingerprint, nowIso, fmtTime, fmtDateTime, FieldValue } from './dataLayer';
import { ruleFor, conceptFor, STATIONS } from './formRules';
import { SignaturePanel, SignDialog, AddendumDialog, SignRequest } from './SignaturePanel';
import { EventBar } from './EventBar';
import { voiceConfig, Suggestion, Transcript, CONFIDENCE } from './voice';
import { getVal } from './formEnhancer';

export interface FormItem { title: string; file: string; category: string; stage: string }

/** Detect the on-screen keyboard (iPad): visualViewport shrinks, or a text field is focused on a touch screen. */
function useKeyboardOpen() {
  const [open, setOpen] = useState(false);
  useEffect(() => {
    const vv = window.visualViewport; const coarse = window.matchMedia?.('(pointer: coarse)').matches || 'ontouchstart' in window;
    let focused = false;
    const update = () => { const shrink = vv ? window.innerHeight - vv.height > 140 : false; setOpen(shrink || (coarse && focused)); };
    const isText = (el: any) => el && el.matches?.('input:not([type=checkbox]):not([type=radio]):not([type=button]),textarea,select');
    const fin = (e: FocusEvent) => { const t = (e.composedPath?.()[0] || e.target) as any; focused = isText(t); update(); };
    const fout = () => { focused = false; setTimeout(update, 60); };
    vv?.addEventListener('resize', update); document.addEventListener('focusin', fin); document.addEventListener('focusout', fout);
    return () => { vv?.removeEventListener('resize', update); document.removeEventListener('focusin', fin); document.removeEventListener('focusout', fout); };
  }, []);
  return open;
}

export const FormPage: React.FC<{ patient: PatientCase; form: FormItem; station: string; onClose: () => void }> = ({ patient, form, station, onClose }) => {
  const hostRef = useRef<HTMLDivElement>(null); const ctlRef = useRef<FormController | null>(null);
  const [rec, setRec] = useState<FormRecord>(() => repo.getForm(patient.id, form.file));
  const [dirty, setDirty] = useState(false); const [savedAt, setSavedAt] = useState(''); const [tick, setTick] = useState(0);
  const [signing, setSigning] = useState<ReturnType<typeof ruleFor>['signers'][number] | null>(null);
  const [source, setSource] = useState<{ p: Provenance; label: string } | null>(null);
  const [addendum, setAddendum] = useState<{ original: Record<string, FieldValue>; dialog: boolean } | null>(null);
  const [voice, setVoice] = useState<{ listening: boolean; review?: { t: Transcript; items: Suggestion[]; unfiled: string[] }; text: string } | null>(null);
  const [actor, setActor] = useState(repo.getActor());
  const rule = useMemo(() => ruleFor(form.file), [form.file]);
  const kb = useKeyboardOpen();
  const stationLabel = STATIONS.find(s => s.key === station)?.label || station;

  useEffect(() => {
    if (!hostRef.current) return;
    const html = getFormHtmlSync(form.file) || `<div style="padding:24px"><h2>${form.title}</h2><p>The form template could not be loaded.</p></div>`;
    ctlRef.current = mountForm({ host: hostRef.current, file: form.file, title: form.title, patient, station, html, onDirty: () => setDirty(true), onShowSource: (p, label) => setSource({ p, label }), onChange: () => setTick(t => t + 1) });
    repo.audit({ caseId: patient.id, user: actor.name, role: actor.role, action: 'form.open', form: form.file, detail: `Opened ${form.title} at ${stationLabel}` });
    setTick(t => t + 1);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [form.file, patient.id]);

  const persist = useCallback((next?: Partial<FormRecord>) => {
    const ctl = ctlRef.current; if (!ctl) return rec;
    const { values, labels } = ctl.collect();
    const base = repo.getForm(patient.id, form.file);
    const r: FormRecord = { ...base, ...next, values: next?.values || values, labels, provenance: { ...ctl.prov }, status: next?.status || (base.status === 'not-started' ? 'draft' : base.status), updatedAt: nowIso(), updatedBy: actor.name };
    repo.saveForm(r); repo.putFacts(patient.id, ctl.facts(actor, form.title));
    setRec(r); setDirty(false); setSavedAt(fmtTime(r.updatedAt));
    return r;
  }, [actor, form.file, form.title, patient.id, rec]);

  const save = () => {
    if (addendum) { setAddendum({ ...addendum, dialog: true }); return; }
    persist(); repo.audit({ caseId: patient.id, user: actor.name, role: actor.role, action: 'form.save', form: form.file, detail: `Saved ${form.title}` });
  };
  const close = () => { if (dirty && !window.confirm('You have unsaved changes. Close this form without saving?')) return; onClose(); };

  const doSign = (req: SignRequest) => {
    if (/nightingale/i.test(req.signerName)) return; // AI never signs (also blocked in the dialog)
    const r0 = persist();
    const hash = fingerprint({ file: form.file, values: r0.values });
    const inits = (ctlRef.current?.initials() || []).filter(x => x.slot === req.slot.id).map(x => ({ page: `${x.pageIndex + 1}. ${x.page}`, value: x.value }));
    const sig = { slotId: req.slot.id, role: req.slot.role, signerName: req.signerName, credentials: req.credentials, attestation: req.slot.attestation, at: nowIso(), method: req.method, image: req.image, contentHash: hash, ...(inits.length ? { initials: inits } : {}) };
    const signatures = [...r0.signatures, sig];
    const allRequired = rule.signers.filter(s => s.required).every(s => signatures.some(x => x.slotId === s.id));
    const status = allRequired ? 'locked' : 'partially-signed';
    const r: FormRecord = { ...r0, signatures, status, lockedAt: allRequired ? sig.at : r0.lockedAt, lockedHash: allRequired ? hash : r0.lockedHash };
    repo.saveForm(r); setRec(r); setSigning(null);
    repo.audit({ caseId: patient.id, user: req.signerName, role: req.slot.role, action: 'form.sign', form: form.file, detail: `${req.slot.label} signed (${req.method})${inits.length ? `; initials ${inits.map(x => `${x.page} “${x.value}”`).join(', ')}` : ''}; content fingerprint ${hash}` });
    if (allRequired) repo.audit({ caseId: patient.id, user: req.signerName, role: req.slot.role, action: 'form.lock', form: form.file, detail: `All required signers complete — record locked` });
    ctlRef.current?.applyLocks(r);
  };

  const startAddendum = () => {
    const ctl = ctlRef.current; if (!ctl) return;
    setAddendum({ original: ctl.collect().values, dialog: false });
    ctl.applyLocks({ ...rec, status: 'draft', signatures: [] });
  };
  const addendumChanges = () => {
    const ctl = ctlRef.current; if (!ctl || !addendum) return [];
    const { values, labels } = ctl.collect();
    return Object.keys(values).filter(k => values[k] !== addendum.original[k] && !(values[k] === '' && addendum.original[k] === undefined)).map(k => ({ key: k, label: labels[k] || k, from: addendum.original[k], to: values[k] }));
  };
  const saveAddendum = (reason: string, name: string) => {
    const changes = addendumChanges();
    const r0 = persist({ status: 'locked' });
    const a = { id: `ad-${Date.now()}`, at: nowIso(), by: name, role: actor.role, reason, changes, signed: true };
    const r: FormRecord = { ...r0, status: 'locked', addenda: [...(r0.addenda || []), a] };
    repo.saveForm(r); setRec(r); setAddendum(null);
    repo.audit({ caseId: patient.id, user: name, role: actor.role, action: 'form.addendum', form: form.file, detail: `Addendum (${changes.length} change${changes.length === 1 ? '' : 's'}): ${reason}` });
    ctlRef.current?.applyLocks(r);
  };

  /* ---------- voice (push-to-talk, local mock by default) ---------- */
  const startTalk = async () => { await voiceConfig.transcriber.start(); setVoice(v => ({ text: v?.text ?? (rule.voiceSample || ''), listening: true })); };
  const stopTalk = async () => {
    const ctl = ctlRef.current; if (!ctl || !voice) return;
    const raw = await voiceConfig.transcriber.stop(voice.text);
    const t: Transcript = { ...raw, speaker: `${actor.name} (${actor.role})`, device: 'this device' };
    const { suggestions, unfiled } = await voiceConfig.extractor.extract(t, ctl.fields);
    repo.audit({ caseId: patient.id, user: 'Nightingale', role: 'AI assistant', action: 'voice.suggest', form: form.file, detail: `${suggestions.length} suggestion(s) from push-to-talk (${voiceConfig.transcriber.id} + ${voiceConfig.extractor.id}); nothing filed until a person accepts` });
    setVoice({ ...voice, listening: false, review: { t, items: suggestions, unfiled } });
  };
  const decide = (s: Suggestion, accept: boolean, value?: string | boolean) => {
    const ctl = ctlRef.current; if (!ctl || !voice?.review) return;
    if (accept) {
      const finalV = value ?? s.value;
      ctl.applyValue(s.key, finalV, { kind: 'voice', label: `Nightingale heard ${voice.review.t.speaker} at ${fmtTime(voice.review.t.endedAt)}; accepted by ${actor.name}`, at: nowIso(), by: actor.name, snippet: s.snippet, confirmed: true });
      repo.audit({ caseId: patient.id, user: actor.name, role: actor.role, action: 'voice.accept', form: form.file, detail: `${s.label}: AI value “${String(s.value)}” → final “${String(finalV)}” (confidence ${s.confidence.toFixed(2)}; transcript: “${s.snippet}”)` });
    } else repo.audit({ caseId: patient.id, user: actor.name, role: actor.role, action: 'voice.reject', form: form.file, detail: `${s.label}: rejected “${String(s.value)}”` });
    setVoice(v => v && v.review ? { ...v, review: { ...v.review, items: v.review.items.map(x => x.id === s.id ? { ...x, status: accept ? 'accepted' : 'rejected', value: value ?? x.value } : x) } } : v);
  };

  const ctl = ctlRef.current;
  const pending = ctl ? ctl.unconfirmed().length : 0; void tick;
  const goPending = () => { const f = ctlRef.current?.unconfirmed()[0]; f?.el.scrollIntoView({ block: 'center', behavior: 'smooth' }); };
  const confirmAll = () => { const n = ctlRef.current?.confirmAll() || 0; repo.audit({ caseId: patient.id, user: actor.name, role: actor.role, action: 'form.confirm', form: form.file, detail: `Confirmed ${n} prefilled values` }); setDirty(true); setTick(x => x + 1); };
  const locked = rec.status === 'locked' && !addendum;
  // Multi-page packets (Admission Form): one signature block, at the end of the last page. Other pages show a short pointer,
  // plus a compact initials field where the original packet asks for initials.
  const paging = ctl?.paging || null;
  const pageNo = paging ? paging.index() : 0;
  const onLastPage = !paging || pageNo === paging.count - 1;
  const initials = ctl ? ctl.initials() : [];
  const missingInitials: Record<string, { page: string; pageIndex: number }[]> = {};
  initials.filter(x => !x.value).forEach(x => { (missingInitials[x.slot] ||= []).push({ page: x.page, pageIndex: x.pageIndex }); });
  const pageInitials = initials.filter(x => x.pageIndex === pageNo);
  const goPage = (i: number) => { paging?.go(i); setTick(t => t + 1); };
  const goSignatures = () => { if (paging && !onLastPage) paging.go(paging.count - 1, false); setTick(t => t + 1); setTimeout(() => document.getElementById('v6-signatures')?.scrollIntoView({ behavior: 'smooth' }), 60); };
  const stamp = (concept: string, v: string) => { const c = ctlRef.current; if (!c) return; c.fields.forEach(f => { const k = conceptFor(f.label, f.el.getAttribute('name') || '', f.type, f.inTable); if (k?.id === concept) c.applyValue(f.key, v, { kind: 'event', label: `OR event bar · ${actor.name} · ${v}`, at: nowIso(), by: actor.name }); }); };

  return <div className="fixed inset-0 z-[120] bg-[#f4f6f4] overflow-y-auto v6-scope" data-testid="v6-form-page" data-kb={kb ? '1' : ''}>
    <header className={`sticky top-0 z-20 bg-white border-b border-[#dfe5e1] px-4 sm:px-6 ${kb ? 'py-1.5' : 'py-3'}`}>
      <div className="max-w-6xl mx-auto flex items-center justify-between gap-3">
        <div className="min-w-0">{!kb && <div className="v6-kicker">{stationLabel} · Encounter form</div>}<h1 className={`${kb ? 'text-[17px]' : 'text-[21px]'} font-bold truncate`}>{form.title}</h1>
          {!kb && <p className="text-[14px] text-[#3f4c45] truncate" data-testid="v6-form-patient">{patient.name} · DOB {patient.dob || 'not documented'} · MRN {patient.patientId} · {patient.procedure}</p>}</div>
        <button onClick={close} className="v6-icon-btn" aria-label="Close form"><X /></button>
      </div>
    </header>
    <main className="max-w-6xl mx-auto px-3 sm:px-6 py-4 pb-40 space-y-4">
      {!locked && (pending > 0) && <div className="flex flex-wrap items-center gap-3 p-3 rounded-lg bg-[#fff8e8] border border-[#e6cf9f]"><Info size={18} className="text-[#7a5414]" /><span className="text-[15px] text-[#5c3f0c] flex-1">Nightingale prefilled this form from the case and earlier stations. <b>{pending}</b> value{pending > 1 ? 's' : ''} (amber) need{pending > 1 ? '' : 's'} your confirmation; green and blue values came from the case or another signed entry.</span><button onClick={confirmAll} className="v6-btn v6-btn-secondary" data-testid="confirm-all">Confirm all {pending}</button></div>}
      {rule.eventBar && <EventBar caseId={patient.id} disabled={locked} onStamp={stamp} />}
      {addendum && <div className="p-3 rounded-lg bg-[#fffaf0] border border-[#e6cf9f] text-[15px]"><b>Addendum mode.</b> Change only what needs correcting, then tap “Save addendum”. The original values are kept and shown with the addendum.</div>}
      <div ref={hostRef} className="bg-white border border-[#dfe5e1] rounded-lg p-[clamp(12px,2.5vw,28px)]" data-testid="v6-form-host" />
      {paging && !onLastPage && rule.signers.length > 0 && <div className="bg-white border border-[#dfe5e1] rounded-lg px-4 py-3 flex flex-wrap items-center gap-3 print:hidden" data-testid="v6-sig-pointer">
        <PenLine size={18} className="text-[#1f6e52]" />
        <span className="text-[15px] flex-1 min-w-[220px]">Page {pageNo + 1} of {paging.count}. {pageInitials.length ? <><b>This page needs {pageInitials.length > 1 ? `${pageInitials.length} initials` : 'initials'}</b> (above). </> : ''}{rec.status === 'locked' ? 'This packet is signed and locked. The signatures are' : 'Signatures are collected once,'} at the end of the last page ({paging.count}. {paging.titles[paging.count - 1]}).</span>
        <button type="button" onClick={goSignatures} className="v6-btn v6-btn-secondary">Go to last page</button>
      </div>}
      <div className={onLastPage ? '' : 'hidden print:block'} data-testid="v6-sig-wrap">
        <SignaturePanel slots={rule.signers} sequential={rule.sequential} rec={rec} pendingConfirm={pending} addendumMode={!!addendum} onSignClick={s => setSigning(s)} onAddendum={startAddendum} onShowPending={goPending} missingInitials={missingInitials} onGoPage={goPage} />
      </div>
    </main>
    {!kb && <footer className="fixed bottom-0 inset-x-0 z-20 bg-white border-t border-[#dfe5e1] px-3 sm:px-6 py-2.5 pb-[max(10px,env(safe-area-inset-bottom))]">
      <div className="max-w-6xl mx-auto flex items-center gap-2 flex-wrap">
        {!locked && <button type="button" onPointerDown={startTalk} onPointerUp={stopTalk} onPointerLeave={() => voice?.listening && stopTalk()} onKeyDown={e => { if (e.key === ' ' && !voice?.listening) startTalk(); }} onKeyUp={e => { if (e.key === ' ') stopTalk(); }} className={`min-h-[64px] min-w-[64px] px-4 rounded-full border-2 flex items-center gap-2 font-bold text-[15px] select-none touch-none ${voice?.listening ? 'bg-[#b42318] border-[#b42318] text-white' : 'bg-white border-[#1f6e52] text-[#1f6e52]'}`} aria-label="Hold to talk to Nightingale" data-testid="ptt"><Mic size={22} /> {voice?.listening ? 'Listening…' : 'Hold to talk'}</button>}
        <span className="text-[14px] text-[#3f4c45] flex-1 min-w-[120px]">{locked ? `Locked · ${rec.signatures.length} signature${rec.signatures.length === 1 ? '' : 's'}` : savedAt ? `Saved ${savedAt}` : dirty ? 'Unsaved changes' : 'No unsaved changes'}</span>
        <button onClick={close} className="v6-btn v6-btn-secondary">Close</button>
        <button onClick={() => window.print()} className="v6-btn v6-btn-secondary"><Printer size={18} /> Print</button>
        {!locked && <button onClick={save} className="v6-btn v6-btn-primary" data-testid="save-form"><Save size={18} /> {addendum ? 'Save addendum' : 'Save'}</button>}
        {!locked && rule.signers.length > 0 && <button onClick={() => { save(); goSignatures(); }} className="v6-btn v6-btn-secondary">Save & go to signatures</button>}
      </div>
    </footer>}
    {voice?.listening && <div className="fixed bottom-24 left-1/2 -translate-x-1/2 z-[150] bg-white border-2 border-[#b42318] rounded-xl p-4 w-[min(560px,92vw)] shadow-xl"><div className="flex items-center gap-2 text-[#b42318] font-bold"><span className="w-3 h-3 rounded-full bg-[#b42318] animate-pulse" /> Listening — release to stop</div><p className="text-[14px] text-[#3f4c45] mt-1">Test build: {voiceConfig.transcriber.label}. Edit the sample below to simulate what was said.</p><textarea value={voice.text} onChange={e => setVoice({ ...voice, text: e.target.value })} onPointerDown={e => e.stopPropagation()} className="v6-input mt-2 min-h-[88px]" /></div>}
    {voice?.review && <VoiceReview review={voice.review} onDecide={decide} onClose={() => setVoice(null)} />}
    {signing && <SignDialog slot={signing} actor={actor} patientName={patient.name} formTitle={form.title} initials={Object.values(initials.filter(x => x.slot === signing.id && x.value).reduce((m, x) => { const k = `${x.pageIndex + 1}. ${x.page}`; (m[k] ||= { page: k, value: '' }).value += (m[k].value ? ', ' : '') + x.value; return m; }, {} as Record<string, { page: string; value: string }>))} onCancel={() => setSigning(null)} onSign={doSign} />}
    {addendum?.dialog && <AddendumDialog changes={addendumChanges()} actor={actor} onCancel={() => setAddendum({ ...addendum, dialog: false })} onSave={saveAddendum} />}
    {source && <DialogShell zIndex={160} size="sm" kicker="Where this value came from" title={source.label} onClose={() => setSource(null)} footer={<Btn variant="primary" onClick={() => setSource(null)}>Close</Btn>}><div className="space-y-2"><p className="text-[15px]">{source.p.kind === 'case' ? 'From the booked case / patient record' : source.p.kind === 'carried' ? 'Carried forward from an earlier entry' : source.p.kind === 'default' ? 'Practice default — confirm or change it' : source.p.kind === 'calc' ? 'Calculated by the app' : source.p.kind === 'voice' ? 'Suggested by Nightingale from push-to-talk and accepted by a person' : source.p.kind === 'normal' ? '“All normal” shortcut tapped by a person' : 'Event time'}</p><p className="text-[15px]"><b>Source:</b> {source.p.label}</p>{source.p.snippet && <p className="text-[15px]"><b>Transcript:</b> “{source.p.snippet}”</p>}<p className="text-[14px] text-[#4a5750]">{fmtDateTime(source.p.at)}{source.p.confirmed ? ' · confirmed' : ''}</p></div></DialogShell>}
  </div>;
};

const VoiceReview: React.FC<{ review: { t: Transcript; items: Suggestion[]; unfiled: string[] }; onDecide: (s: Suggestion, accept: boolean, value?: string | boolean) => void; onClose: () => void }> = ({ review, onDecide, onClose }) => {
  const [edits, setEdits] = useState<Record<string, string>>({});
  const pending = review.items.filter(i => i.status === 'pending');
  const bulk = pending.filter(i => !i.alwaysConfirm && i.confidence >= CONFIDENCE.suggest);
  return <DialogShell zIndex={170} size="lg" testId="voice-review" kicker="Nightingale · review before anything is saved" title={`${review.items.length} suggested value${review.items.length === 1 ? '' : 's'}`} onClose={onClose}
    footer={<>{bulk.length > 0 && <Btn variant="secondary" onClick={() => bulk.forEach(s => onDecide(s, true, edits[s.id] ?? s.value))}>Accept {bulk.length} high-confidence</Btn>}<Btn variant="primary" onClick={onClose} data-testid="voice-done">Done</Btn></>}>
    <div className="space-y-3">
      <p className="text-[14px] text-[#3f4c45]">Heard from {review.t.speaker} on {review.t.device} at {fmtTime(review.t.endedAt)} · processed on this device ({voiceConfig.transcriber.id}, {voiceConfig.extractor.id}). Audio is not recorded in this build. Nothing is filed until you accept it; Nightingale never signs.</p>
      <blockquote className="text-[15px] bg-[#f7f9f7] border-l-4 border-[#9aa8a0] p-3">“{review.t.text}”</blockquote>
      <ul className="space-y-2">{review.items.map(s => <li key={s.id} className={`border rounded-lg p-3 ${s.status === 'accepted' ? 'border-[#bcd9ca] bg-[#f3faf6]' : s.status === 'rejected' ? 'opacity-50' : s.confidence < CONFIDENCE.suggest || s.alwaysConfirm ? 'border-[#e6cf9f] bg-[#fffaf0]' : 'border-[#dfe5e1]'}`}>
        <div className="flex flex-wrap gap-2 items-center justify-between"><b className="text-[15px]">{s.label}</b><span className="text-[13px] font-bold px-2 py-0.5 rounded-full bg-[#eef2ef]">{s.alwaysConfirm ? 'Must confirm individually' : s.confidence >= CONFIDENCE.suggest ? 'Suggested' : 'Please check'} · {Math.round(s.confidence * 100)}%</span></div>
        <div className="text-[14px] text-[#3f4c45] mt-1">Source: “{s.snippet}”</div>
        {s.status === 'pending' ? <div className="flex flex-wrap gap-2 mt-2 items-center">{typeof s.value === 'boolean' ? <span className="text-[15px] font-semibold">Tick this box</span> : <input className="v6-input flex-1 min-w-[160px]" value={edits[s.id] ?? String(s.value)} onChange={e => setEdits({ ...edits, [s.id]: e.target.value })} aria-label={`Value for ${s.label}`} />}
          <button className="v6-btn v6-btn-primary" onClick={() => onDecide(s, true, typeof s.value === 'boolean' ? true : (edits[s.id] ?? String(s.value)))}><Check size={18} /> Accept</button><button className="v6-btn v6-btn-secondary" onClick={() => onDecide(s, false)}><Ban size={18} /> Reject</button></div>
          : <div className="text-[14px] font-semibold mt-1">{s.status === 'accepted' ? `✓ Filed: ${String(s.value)}` : '✗ Rejected'}</div>}
      </li>)}</ul>
      {review.unfiled.length > 0 && <div className="border border-dashed rounded-lg p-3"><b className="text-[15px]">Nightingale heard but did not file</b><ul className="list-disc ml-5 text-[14px] mt-1">{review.unfiled.map((u, i) => <li key={i}>{u}</li>)}</ul></div>}
    </div>
  </DialogShell>;
};
