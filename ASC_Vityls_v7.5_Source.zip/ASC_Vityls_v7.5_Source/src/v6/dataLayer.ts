/*
 * Vityls v6 — encounter data-access layer.
 *
 * Every station screen, form page, signature panel and voice review talks to the
 * `repo` object below and never to localStorage directly. Today `repo` is a
 * LocalStorageRepository (test scaffolding, fictitious data only). When the real
 * backend arrives, implement `EncounterRepository` with HTTP calls
 * (e.g. GET/PUT /encounters/:caseId/forms/:file, POST /audit) and swap the
 * export at the bottom of this file. Nothing else in the UI needs to change.
 *
 * Backend notes (deferred, see changelog):
 *  - signatures, locks, hashes and audit entries must be written server-side with
 *    server timestamps; the browser values here are for evaluation only;
 *  - store values by stable field key (done here) — never by position.
 */

export type FieldValue = string | boolean;

export type SourceKind =
  | 'case'        // booked case / patient header (procedure, surgeon, DOB…)
  | 'carried'     // recorded earlier on another form or station
  | 'default'     // practice default, needs confirmation
  | 'normal'      // set by an "All normal / no change" tap
  | 'calc'        // calculated by the app (Aldrete total, BMI, length of stay)
  | 'voice'       // Nightingale suggestion from push-to-talk, accepted by a person
  | 'event'       // OR event-time bar tap
  | 'manual';     // typed by a person

export interface Provenance {
  kind: SourceKind;
  label: string;          // human readable, e.g. "Nursing Admission · Pre-op RN · 07:14"
  at: string;             // ISO timestamp
  by?: string;            // user who entered/accepted it
  snippet?: string;       // voice transcript snippet
  confirmed?: boolean;    // true once a person confirmed a prefilled/default value
  needsConfirm?: boolean; // allergies, meds, patient-reported history, defaults, voice
}

export interface Actor { name: string; role: string; credentials?: string; kind: 'human' }

export interface SignatureEvent {
  slotId: string;
  role: string;
  signerName: string;
  credentials?: string;
  attestation: string;
  at: string;
  method: 'drawn' | 'typed';
  image?: string;
  contentHash: string;    // fingerprint of the form values at the moment of signing
  initials?: { page: string; value: string }[];  // per-page initials made by this signer (multi-page packets)
}

export interface Addendum {
  id: string;
  at: string;
  by: string;
  role: string;
  reason: string;
  changes: { key: string; label: string; from: FieldValue | undefined; to: FieldValue }[];
  note?: string;
  signed: boolean;
}

export type FormStatus = 'not-started' | 'draft' | 'partially-signed' | 'locked';

export interface FormRecord {
  caseId: string;
  file: string;
  values: Record<string, FieldValue>;
  labels: Record<string, string>;
  provenance: Record<string, Provenance>;
  signatures: SignatureEvent[];
  addenda: Addendum[];
  status: FormStatus;
  lockedAt?: string;
  lockedHash?: string;
  updatedAt?: string;
  updatedBy?: string;
}

export interface Fact {
  concept: string;
  value: FieldValue;
  source: Provenance & { form?: string; formTitle?: string; station?: string };
}

export interface AuditEntry {
  id: string;
  at: string;
  caseId: string;
  user: string;
  role: string;
  action:
    | 'form.open' | 'form.save' | 'form.confirm' | 'form.normal' | 'form.sign' | 'form.lock'
    | 'form.addendum' | 'voice.suggest' | 'voice.accept' | 'voice.reject' | 'station.verify'
    | 'event.time' | 'fact.confirm' | 'invoice.save' | 'invoice.override'
    | 'provider.invite' | 'provider.application' | 'provider.account' | 'provider.pin-set' | 'provider.pin-reset'
    | 'provider.pin-failure' | 'provider.lock' | 'provider.unlock' | 'provider.deactivate' | 'provider.reactivate';
  form?: string;
  detail: string;
}

/** Signer setup saved from Form Studio (Forms & Workflow → Add / Edit → Signers). Overrides the built-in FORM_RULES signers. */
export interface StoredSignerSlot { id: string; role: string; label: string; attestation: string; required: boolean; patient?: boolean }
export interface StoredInitialsPage { pageIndex: number; pageTitle: string; slot: string; statement?: string; existing?: boolean }
export interface SignerConfig {
  file: string;
  signers: StoredSignerSlot[];
  sequential: boolean;
  initials: StoredInitialsPage[];
  updatedAt: string; updatedBy: string;
}

export interface EncounterRepository {
  getForm(caseId: string, file: string): FormRecord;
  saveForm(rec: FormRecord): void;
  listForms(caseId: string): FormRecord[];
  getFacts(caseId: string): Record<string, Fact>;
  putFacts(caseId: string, facts: Fact[]): void;
  audit(entry: Omit<AuditEntry, 'id' | 'at'> & { at?: string }): AuditEntry;
  getAudit(caseId: string): AuditEntry[];
  getStationVerification(caseId: string): Record<string, { by: string; role: string; at: string }>;
  setStationVerification(caseId: string, station: string, v: { by: string; role: string; at: string }): void;
  getActor(): Actor;
  setActor(a: Actor): void;
  /** Form Studio signer setup (practice configuration, not encounter data). Backend: GET/PUT /practices/:id/forms/:file/signers */
  getSignerConfig(file: string): SignerConfig | null;
  saveSignerConfig(cfg: SignerConfig): void;
  clearSignerConfig(file: string): void;
}

const P = 'vityls:v6';
const read = <T,>(k: string, fallback: T): T => {
  try { const raw = localStorage.getItem(k); return raw ? (JSON.parse(raw) as T) : fallback; } catch { return fallback; }
};
const write = (k: string, v: unknown) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch { /* quota: evaluation build */ } };

export const emptyForm = (caseId: string, file: string): FormRecord => ({
  caseId, file, values: {}, labels: {}, provenance: {}, signatures: [], addenda: [], status: 'not-started',
});

class LocalStorageRepository implements EncounterRepository {
  getForm(caseId: string, file: string) { return { ...emptyForm(caseId, file), ...read<Partial<FormRecord>>(`${P}:form:${caseId}:${file}`, {}) } as FormRecord; }
  saveForm(rec: FormRecord) {
    write(`${P}:form:${rec.caseId}:${rec.file}`, rec);
    const idx = read<string[]>(`${P}:forms:${rec.caseId}`, []);
    if (!idx.includes(rec.file)) write(`${P}:forms:${rec.caseId}`, [...idx, rec.file]);
  }
  listForms(caseId: string) { return read<string[]>(`${P}:forms:${caseId}`, []).map(f => this.getForm(caseId, f)); }
  getFacts(caseId: string) { return read<Record<string, Fact>>(`${P}:facts:${caseId}`, {}); }
  putFacts(caseId: string, facts: Fact[]) {
    if (!facts.length) return;
    const cur = this.getFacts(caseId);
    facts.forEach(f => { cur[f.concept] = f; });
    write(`${P}:facts:${caseId}`, cur);
  }
  audit(entry: Omit<AuditEntry, 'id' | 'at'> & { at?: string }) {
    const full: AuditEntry = { id: `a-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`, at: entry.at || new Date().toISOString(), ...entry } as AuditEntry;
    const list = read<AuditEntry[]>(`${P}:audit:${entry.caseId}`, []);
    list.push(full); // append-only
    write(`${P}:audit:${entry.caseId}`, list);
    return full;
  }
  getAudit(caseId: string) { return read<AuditEntry[]>(`${P}:audit:${caseId}`, []); }
  getStationVerification(caseId: string) { return read<Record<string, { by: string; role: string; at: string }>>(`${P}:stations:${caseId}`, {}); }
  setStationVerification(caseId: string, station: string, v: { by: string; role: string; at: string }) {
    const cur = this.getStationVerification(caseId); cur[station] = v; write(`${P}:stations:${caseId}`, cur);
  }
  getActor(): Actor { return read<Actor>(`${P}:actor`, { name: 'Test User', role: 'Pre-op RN', credentials: 'RN', kind: 'human' }); }
  setActor(a: Actor) { write(`${P}:actor`, { ...a, kind: 'human' }); }
  getSignerConfig(file: string) { const c = read<SignerConfig | null>(`${P}:signers:${file}`, null); return c && Array.isArray(c.signers) ? c : null; }
  saveSignerConfig(cfg: SignerConfig) { write(`${P}:signers:${cfg.file}`, cfg); }
  clearSignerConfig(file: string) { try { localStorage.removeItem(`${P}:signers:${file}`); } catch { /* ignore */ } }
}

export const repo: EncounterRepository = new LocalStorageRepository();

/** Small, dependency-free fingerprint (FNV-1a, 2×32-bit). Evaluation only; the
 *  backend must compute a real SHA-256 over the stored document version. */
export function fingerprint(input: unknown): string {
  const s = JSON.stringify(input);
  let h1 = 0x811c9dc5, h2 = 0x01000193;
  for (let i = 0; i < s.length; i++) {
    const c = s.charCodeAt(i);
    h1 ^= c; h1 = Math.imul(h1, 16777619) >>> 0;
    h2 ^= c; h2 = Math.imul(h2 ^ (h2 >>> 13), 2246822519) >>> 0;
  }
  return (h1.toString(16).padStart(8, '0') + h2.toString(16).padStart(8, '0')).toUpperCase();
}

export const nowIso = () => new Date().toISOString();
export const fmtTime = (iso?: string) => iso ? new Date(iso).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '';
export const fmtDateTime = (iso?: string) => iso ? new Date(iso).toLocaleString([], { month: '2-digit', day: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' }) : '';
