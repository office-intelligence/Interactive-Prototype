/*
 * Vityls v6 — form knowledge: shared concept dictionary (collect once, show
 * everywhere), practice defaults, "All normal / no change" shortcuts, linked
 * (de-duplicated) sections, station plans and the multi-signer matrix.
 * Everything here is data, so a backend/Form Studio can own it later.
 * Clinical defaults are EXAMPLES for evaluation; the medical director must
 * approve the practice's own values before real use.
 */
import type { PatientCase } from '../types';
import type { WorkflowKey } from '../data/formWorkspaceCatalog';
import { repo, type SignerConfig, type StoredSignerSlot } from './dataLayer';

export type StationKey = WorkflowKey | 'caseRecord';

/* ---------------- case context (what the app already knows) ---------------- */
export interface CaseContext {
  name: string; first: string; last: string; dob: string; age: string; sex: string; mrn: string; phone: string; email: string;
  address: string; city: string; state: string; zip: string; emergencyName: string; emergencyPhone: string;
  procedure: string; surgeon: string; anesProvider: string; anesType: string; room: string; dateUs: string; dateIso: string; time: string;
  allergies: string; meds: string; pmh: string[]; height: string; weight: string;
}
const clean = (v?: string | null) => { const s = (v || '').trim(); return /^(unassigned|procedure not yet scheduled|none|n\/a|—|-)$/i.test(s) ? '' : s; };
export function caseContext(p: PatientCase): CaseContext {
  let anesType = '';
  try {
    const apts = JSON.parse(localStorage.getItem('vityls:evaluation:appointments') || '[]');
    const a = Array.isArray(apts) ? apts.find((x: any) => x.caseId === p.id) : null;
    anesType = clean(a?.anesthesiaType);
  } catch { /* scaffolding */ }
  const parts = (p.name || '').trim().split(/\s+/);
  const d = p.appointmentDate || '';
  const m = d.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
  const today = new Date();
  const dateUs = m ? d : `${String(today.getMonth() + 1).padStart(2, '0')}/${String(today.getDate()).padStart(2, '0')}/${today.getFullYear()}`;
  const dateIso = m ? `${m[3]}-${m[1].padStart(2, '0')}-${m[2].padStart(2, '0')}` : today.toISOString().slice(0, 10);
  const mp = p.medicalProfile;
  return {
    name: p.name, first: parts[0] || '', last: parts.slice(1).join(' '), dob: p.dob || '', age: p.age ? String(p.age) : '', sex: p.gender || '',
    mrn: p.patientId || '', phone: p.phone || '', email: p.email || '', address: p.address || '', city: p.city || '', state: p.state || '', zip: p.zipCode || '',
    emergencyName: p.emergencyContactName || '', emergencyPhone: p.emergencyContactPhone || '',
    procedure: clean(p.procedure), surgeon: clean(p.surgeon), anesProvider: clean(p.anesthesiologist), anesType, room: clean(p.room),
    dateUs, dateIso, time: p.scheduledTime || '',
    allergies: (p.allergies || []).filter(a => a && !/^(none known|nkda)$/i.test(a)).join(', '),
    meds: (mp?.medications || []).map(x => [x.name, (x as any).dose].filter(Boolean).join(' ')).join('; '),
    pmh: mp?.pastMedicalHistory || [], height: mp?.height || '', weight: mp?.weight || '',
  };
}

/* ---------------- concept dictionary ---------------- */
export interface Concept {
  id: string;
  label: RegExp;               // matched against the control's label
  name?: RegExp;               // or its name attribute
  not?: RegExp;                // exclusions
  types?: string[];            // control types allowed (default: non-checkbox)
  fromCase?: (c: CaseContext) => string;
  carry?: boolean;             // value recorded on one form is shown on the others
  needsConfirm?: boolean;      // allergies, doses, laterality: always explicit confirmation
  tables?: boolean;            // allow inside tables
}
const TXT = ['text', 'textarea', 'tel', 'email', 'number', 'date', 'time', 'select', 'select-one'];
export const CONCEPTS: Concept[] = [
  { id: 'patient.name', label: /^(patient(’s|'s)? )?(full |legal )?name$|^patient name\b/i, name: /^(patientName|patient_name|ptName)$/, not: /adult|escort|driver|witness|contact|holder|insured|nurse|physician|surgeon/i, fromCase: c => c.name },
  { id: 'patient.first', label: /^(legal )?first name$/i, not: /contact|holder/i, fromCase: c => c.first },
  { id: 'patient.last', label: /^(legal )?last name$/i, not: /contact|holder/i, fromCase: c => c.last },
  { id: 'patient.dob', label: /^(patient )?(date of birth|dob|birth ?date)$/i, not: /holder|insured|subscriber/i, fromCase: c => c.dob },
  { id: 'patient.age', label: /^age$/i, fromCase: c => c.age },
  { id: 'patient.sex', label: /^(sex|gender)$/i, fromCase: c => c.sex },
  { id: 'patient.mrn', label: /\bmrn\b|medical record (number|#)/i, fromCase: c => c.mrn },
  { id: 'patient.phone', label: /^(telephone|phone|mobile phone|cell phone|patient (tele)?phone)$/i, fromCase: c => c.phone },
  { id: 'patient.email', label: /^email( \(optional\))?$/i, fromCase: c => c.email },
  { id: 'patient.address', label: /^street address$/i, fromCase: c => c.address },
  { id: 'patient.city', label: /^city$/i, fromCase: c => c.city },
  { id: 'patient.state', label: /^state$/i, fromCase: c => c.state },
  { id: 'patient.zip', label: /^zip( code)?$/i, fromCase: c => c.zip },
  { id: 'patient.emergencyName', label: /^emergency contact name$/i, fromCase: c => c.emergencyName },
  { id: 'patient.emergencyPhone', label: /^emergency contact (tele)?phone$/i, fromCase: c => c.emergencyPhone },
  { id: 'case.procedure', label: /^(planned |proposed |scheduled )?procedure(\(s\))?$|^procedure \/ visit context$|^pre-operative diagnosis \/ procedure planned$|^procedure \(if started \/ completed\)$/i, carry: false, fromCase: c => c.procedure },
  { id: 'case.procedurePerformed', label: /^(procedure\(s\) performed.*|procedure performed|surgical procedure\(s\) performed.*|post-operative diagnosis \/ procedure performed)$/i, carry: true, fromCase: c => c.procedure },
  { id: 'case.surgeon', label: /^((operating|attending) )?surgeon$|^surgeon \/ clinician$|^operating surgeon$|^i hereby authorize and direct doctor$/i, carry: false, fromCase: c => c.surgeon },
  { id: 'case.anesProvider', label: /^(anesthesia provider|anesthesiologist( \/ crna)?)$/i, fromCase: c => c.anesProvider },
  { id: 'case.anesType', label: /^(type of anesthesia|anesthesia type|anesthesia planned)$/i, fromCase: c => c.anesType },
  { id: 'case.date', label: /^(date of procedure|procedure date|date of service|admission date|scheduled surgery date|date of procedure \/ event|date of this examination|date)$/i, types: ['date', 'text'], fromCase: c => c.dateUs },
  { id: 'case.room', label: /^(or room( \/ suite)?|admitted from)$/i, fromCase: c => c.room },
  { id: 'case.allergies', label: /^(verbalized allergies.*|allergies confirmed|allergy details \(if any\)|reaction details \/ other allergens)$/i, carry: true, needsConfirm: true, fromCase: c => c.allergies },
  { id: 'case.meds', label: /^(current medications confirmed|medication list \(name, dose, frequency\).*)$/i, carry: true, needsConfirm: true, fromCase: c => c.meds },
  // carried facts (entered once, shown everywhere)
  { id: 'npo.solid', label: /^last solid food( intake)?$/i, carry: true },
  { id: 'npo.clear', label: /^last clear liquid( intake)?$/i, carry: true },
  { id: 'adult.driver', label: /^responsible adult( discharge)? driver$|^responsible adult name$|^escort name$/i, carry: true },
  { id: 'vitals.height', label: /^height$/i, carry: true, fromCase: c => c.height },
  { id: 'vitals.weight', label: /^weight$/i, carry: true, fromCase: c => c.weight },
  { id: 'case.asa', label: /^asa (class|classification|physical status( classification)?)$/i, carry: true },
  { id: 'time.inOR', label: /^patient in (or|room)$/i, carry: true },
  { id: 'time.anesStart', label: /^anesthesia start$/i, carry: true },
  { id: 'time.incision', label: /^(surgery start( \(incision\))?|incision \/ start time)$/i, carry: true },
  { id: 'time.closure', label: /^(surgery (end|stop)( \(close\))?|close \/ stop time)$/i, carry: true },
  { id: 'time.anesEnd', label: /^anesthesia end$/i, carry: true },
  { id: 'time.outOR', label: /^(out of or \/ to pacu|or out \/ transfer out)$/i, carry: true },
  { id: 'time.handoff', label: /^hand-off \/ transfer time$/i, carry: true },
  { id: 'case.ebl', label: /^estimated blood loss( \(ebl\)| \(ml\))?$/i, carry: true },
  { id: 'case.woundClass', label: /^wound classification$/i, carry: true },
  { id: 'case.specimens', label: /^(specimens \/ cultures sent|specimen \/ culture details.*)$/i, carry: true },
  { id: 'case.implants', label: /^implants \/ devices \/ grafts.*$/i, carry: true },
  { id: 'team.assistant', label: /^assistant surgeon(\(s\))?$/i, carry: true },
  { id: 'team.scrub', label: /^scrub nurse \/ tech$/i, carry: true },
  { id: 'team.circulator', label: /^or circulating nurse$/i, carry: true },
  { id: 'team.nurses', label: /^scrub \/ circulating nurse$/i, carry: true },
  { id: 'timeout.time', label: /^(time-out time|time-out execution time.*)$/i, carry: true },
  { id: 'abx.time', label: /^(antibiotic infusion time|antibiotic given within last 60 minutes.*time:?)$/i, carry: true },
  { id: 'pacu.nurse', label: /^receiving pacu nurse name$/i, carry: true },
  { id: 'dx.pre', label: /^pre-operative diagnosis$/i, carry: true },
  { id: 'dx.post', label: /^(post-operative diagnosis|primary discharge diagnosis)$/i, carry: true },
  { id: 'followup', label: /^follow-up appointment$/i, carry: true },
  { id: 'pacu.admitTime', label: /^time of admission( \(military\))?$/i, carry: true },
];
export function conceptFor(label: string, name: string, type: string, inTable: boolean): Concept | undefined {
  for (const c of CONCEPTS) {
    if (inTable && !c.tables) continue;
    const allowed = c.types || TXT;
    if (!allowed.includes(type)) continue;
    if (c.not && c.not.test(label)) continue;
    if (c.label.test(label) || (c.name && name && c.name.test(name))) return c;
  }
  return undefined;
}

/* Past-medical-history checkbox dictionary (patient answers carried to anesthesia / H&P). */
export const PMH: { id: string; re: RegExp }[] = [
  { id: 'htn', re: /^hypertension$/i }, { id: 'cad', re: /^(coronary artery disease|cad \/ prior mi)$/i },
  { id: 'chf', re: /^heart failure/i }, { id: 'arrhythmia', re: /^arrhythmia/i }, { id: 'pacemaker', re: /^pacemaker/i },
  { id: 'stroke', re: /^stroke \/ tia$/i }, { id: 'osa', re: /^sleep apnea/i }, { id: 'cpap', re: /^(cpap at home|uses cpap \/ bipap)$/i },
  { id: 'uri', re: /^(recent upper respiratory infection|recent uri \/ pneumonia)$/i }, { id: 'thyroid', re: /^thyroid disorder$/i },
  { id: 'ckd', re: /^(kidney disease|chronic kidney disease)$/i }, { id: 'liver', re: /^liver disease/i }, { id: 'gerd', re: /reflux/i },
  { id: 'seizure', re: /^seizure disorder$/i }, { id: 'bleeding', re: /^bleeding \/ clotting disorder$/i }, { id: 'dvt', re: /^history of dvt \/ pe$/i },
  { id: 'nkda', re: /^no known drug allergies( \(nkda\))?$/i },
];
export const PMH_SECTION = /history|conditions|allerg/i;

/* ---------------- per-form rules ---------------- */
export interface NormalSet { section: RegExp; button: string; check?: RegExp[]; fill?: [RegExp, string][]; selectNormal?: boolean; stamp?: [RegExp, 'now' | 'actor'][] }
export interface Default { label: RegExp; value: string | ((c: CaseContext) => string); section?: RegExp }
export interface SignerSlot { id: string; role: string; label: string; attestation: string; required: boolean; patient?: boolean; sections?: RegExp }
export interface FormRule {
  normals?: NormalSet[];
  defaults?: Default[];
  linkedTimeout?: boolean;        // IntraOp nursing: time-out recorded once in Universal Protocol
  aldrete?: boolean; vte?: boolean; bmi?: boolean; pacuLos?: boolean;
  chartChecks?: boolean;          // Nursing admission section 6: tick from signed chart documents
  eventBar?: boolean;             // shared OR event-time bar
  voiceSample?: string;           // mock transcript used by the local voice adapter
  signers: SignerSlot[];
  sequential?: boolean;
  /** Multi-page packets: pages that need the signer's initials (compact field), bound to a signer slot. The full signature appears once, on the last page. */
  initials?: InitialsSpec[];
}
export interface InitialsSpec { page: RegExp; pageIndex?: number; slot: string; statement?: string; existing?: boolean }

const NOW = () => { const d = new Date(); return `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`; };
export const nowHHMM = NOW;

const S = (id: string, role: string, label: string, attestation: string, required = true, extra: Partial<SignerSlot> = {}): SignerSlot => ({ id, role, label, attestation, required, ...extra });
const PATIENT = (label = 'Patient / legally responsible person') => S('patient', 'Patient', label, 'I have read (or had read to me) and understand this document, and I agree to it.', true, { patient: true });

export const FORM_RULES: Record<string, FormRule> = {
  'Patient_Registration.html': { signers: [PATIENT(), S('frontdesk', 'Front desk', 'Front desk verifier', 'I verified this registration against the patient’s photo ID and insurance card.')], sequential: true },
  'Insurance_Information.html': { signers: [PATIENT(), S('frontdesk', 'Front desk', 'Front desk verifier', 'I verified the insurance information and eligibility.')], sequential: true },
  'Admission_Form.html': {
    signers: [
      S('patient', 'Patient', 'Patient / legally responsible person — whole admission packet', 'I have received and read (or had read to me) every page of this admission packet: patient rights and responsibilities, privacy rights and notice, disclosure of ownership, complaint/grievance and advance-directive policies, the facility arbitration agreement and the cash payment fee disclosure. I agree to them, and my initials appear where required.', true, { patient: true }),
      S('frontdesk', 'Front desk', 'Front desk witness / facility representative', 'I witnessed the patient (or legally responsible person) complete this packet, confirm the notices were provided before the procedure, and countersign the arbitration agreement for the facility.'),
    ],
    sequential: true,
    // From the original packet (reference-forms/Patient Intake Forms/Admission Form.html): the arbitration agreement carried its own
    // patient signature and the cash-fee page has two clause initials. Those pages get compact initials fields generated from this
    // signer setup (never template fields); the one full signature is made in the multi-signer panel.
    initials: [
      { page: /arbitration/i, slot: 'patient', statement: 'I have read this arbitration agreement, including the NOTICE above, and I agree to it.' },
      // v7.4: the two cash-fee clause initials are configured here / in Signer setup (one line per clause), no longer hard-coded in the template.
      { page: /cash payment fee/i, slot: 'patient', statement: 'I have read and understand the fee disclosure, including responsibility for charges in excess of the time estimate.\nI understand the insurance payment assignment and 30-day remittance requirement if payment is sent to me.' },
    ],
  },
  'Billing_Fee_Disclosure.html': { signers: [PATIENT()] },
  'Credit_Card_Authorization.html': { signers: [PATIENT('Cardholder')] },
  'Photography_Media_Research_Consent.html': { signers: [PATIENT(), S('witness', 'RN', 'Witness', 'I witnessed the patient sign this consent.', false)] },
  'Patient_Satisfaction_Survey.html': { signers: [] },
  'Medical_History.html': {
    signers: [PATIENT('Patient or guardian'), S('rnreview', 'Pre-op RN', 'Pre-op RN review (recorded, not re-signed by patient)', 'I reviewed this history with the patient.', false), S('anesreview', 'Anesthesia', 'Anesthesia review', 'I reviewed this history.', false)],
    sequential: true,
  },
  'Anesthesia_Questionnaire.html': { signers: [PATIENT('Patient or guardian'), S('anesreview', 'Anesthesia', 'Anesthesia review', 'I reviewed the patient’s answers.', false)], sequential: true },
  'Procedure_Consent.html': {
    signers: [S('surgeon', 'Surgeon', 'Surgeon — informed-consent discussion', 'I discussed the nature, risks, benefits and alternatives of the procedure with the patient and answered their questions.'), PATIENT(), S('witness', 'RN', 'Witness (RN)', 'I witnessed the patient’s signature.')],
    sequential: true,
  },
  'Anesthesia_Consent.html': { signers: [PATIENT(), S('anes', 'Anesthesia', 'Anesthesiologist / CRNA', 'I discussed the anesthesia plan, risks and alternatives with the patient.'), S('witness', 'RN', 'Witness', 'I witnessed the patient’s signature.', false)] },
  'Nursing_Admission.html': {
    chartChecks: true,
    voiceSample: 'Last ate toast at 10 last night, clear water at 5 this morning. Her husband John is driving her home. Five foot four, 140 pounds. BP 128 over 76, pulse 72, sats 98 on room air.',
    defaults: [{ label: /^location \/ unit$/i, value: 'Pre-op' }, { label: /^arrival time/i, value: () => NOW() }, { label: /^isolation precautions$/i, value: 'None' }],
    normals: [
      { section: /day-of-surgery targeted nursing assessment/i, button: 'All systems normal', selectNormal: true },
      { section: /physical preparation/i, button: 'All prep done', check: [/./] },
      { section: /critical check-in/i, button: 'All remaining items verified', check: [/./] },
      { section: /initial check-in/i, button: 'ID band verified', check: [/^id band applied/i] },
    ],
    signers: [S('preoprn', 'Pre-op RN', 'Admitting pre-op RN', 'I completed this pre-operative nursing admission and verified the information above.'), S('circ', 'Circulating RN', 'OR circulating RN — custody accepted', 'I received the patient and this record for transfer to the OR.')],
    sequential: true,
  },
  'MH_and_VTE_Assessment.html': {
    vte: true,
    signers: [S('rn', 'Pre-op RN', 'RN', 'I completed this MH and VTE screening with the patient.'), S('surgeon', 'Surgeon', 'Surgeon', 'I reviewed the VTE score and prophylaxis plan.'), S('anes', 'Anesthesia', 'Anesthesiologist', 'I reviewed the MH screening.', false)],
    sequential: true,
  },
  'Anesthesia_Evaluation.html': {
    bmi: true,
    normals: [
      { section: /physical examination/i, button: 'Airway / exam normal', selectNormal: true },
      { section: /focused review of systems/i, button: 'ROS negative', check: [/^none of the above/i] },
    ],
    defaults: [],
    signers: [S('pre', 'Anesthesia', 'Anesthesia provider — pre-anesthesia evaluation', 'I personally evaluated this patient and the plan above is appropriate.', true, { sections: /^(?!assessment notes).*/i }), S('reeval', 'Anesthesia', 'Anesthesia provider — immediate pre-induction re-evaluation', 'I re-evaluated the patient immediately before induction.', true, { sections: /assessment notes/i })],
    sequential: true,
  },
  'PreOp_HP_Clearance.html': { bmi: true, normals: [{ section: /physical examination/i, button: 'Exam normal', selectNormal: true }, { section: /focused review of systems/i, button: 'ROS negative', check: [/^none of the above/i] }], signers: [S('md', 'Surgeon', 'Examining physician', 'I personally performed this history and physical examination.')] },
  'DayOf_Interval_HP_Update.html': {
    voiceSample: 'No change since H and P. Lungs clear, heart regular. Proceed as planned.',
    defaults: [{ label: /^date \/ time of this update$/i, value: c => `${c.dateUs} ${NOW()}` }],
    normals: [
      { section: /interval history/i, button: 'No interval change', check: [/^no change in history/i] },
      { section: /focused physical examination/i, button: 'Exam unchanged from H&P', fill: [[/^general/i, 'No change from H&P'], [/^heart$/i, 'No change from H&P'], [/^lungs$/i, 'No change from H&P'], [/^abdomen/i, 'No change from H&P'], [/^airway/i, 'No change from H&P']] },
      { section: /assessment & plan|assessment and plan/i, button: 'Proceed as planned', check: [/^patient remains a suitable candidate/i, /^no new contraindications/i, /^proceed as planned/i] },
    ],
    signers: [S('surgeon', 'Surgeon', 'Surgeon (or qualified practitioner)', 'I examined the patient today; the H&P is current and the patient remains a candidate for the planned procedure.')],
  },
  'Surgeon_PreOp_Clearance.html': { signers: [S('surgeon', 'Surgeon', 'Surgeon', 'I attest the H&P and informed consent are complete before incision.')] },
  'Universal_Protocol_Safety_Checklist.html': {
    normals: [
      { section: /before patient enters/i, button: 'All verified', check: [/./], stamp: [[/^verified by/i, 'actor']] },
      { section: /time-out/i, button: 'Time-out complete — all confirmed aloud', check: [/./], stamp: [[/^time-out time$/i, 'now'], [/^circulator \/ leader/i, 'actor']] },
      { section: /sign-out/i, button: 'Sign-out complete', check: [/./] },
    ],
    signers: [S('circ', 'Circulating RN', 'Circulating RN', 'I led and documented the sign-in, time-out and sign-out.'), S('surgeon', 'Surgeon', 'Surgeon', 'I participated in the time-out and confirm patient, procedure, site and side.'), S('anes', 'Anesthesia', 'Anesthesia', 'I participated in the time-out.')],
  },
  'IntraOp_Nursing_Record_TO.html': {
    linkedTimeout: true, eventBar: true,
    voiceSample: 'In room 7:42, incision 8:05, closing 8:51, out 9:02. EBL about 50, wound class two.',
    defaults: [{ label: /^patient position$/i, value: 'Supine' }],
    normals: [
      { section: /pre-procedure skin/i, button: 'Skin intact', check: [/^no pre-existing skin breakdown/i] },
      { section: /transfer to pacu/i, button: 'Standard hand-off done', check: [/^patient awake, stable/i, /^verbal hand-off completed/i, /^chart, consents/i], stamp: [[/^hand-off \/ transfer time$/i, 'now']] },
      { section: /allergies & medications/i, button: 'Allergies & meds reviewed', check: [/^allergies listed on chart/i, /^medication list reviewed/i, /^see anesthesia record/i] },
      { section: /patient identification method/i, button: 'Band + verbal', check: [/^verbal/i, /^id band checked/i] },
    ],
    signers: [S('circ', 'Circulating RN', 'Circulating RN', 'I documented this intra-operative nursing record.'), S('pacurn', 'PACU RN', 'PACU RN — hand-off received', 'I received the patient and verbal hand-off.')],
    sequential: true,
  },
  'Anesthesia_IntraOp_Record.html': {
    eventBar: true,
    voiceSample: 'In room 7:42, anesthesia start 7:45, incision 8:05, closing 8:51, out 9:02. EBL about 50, uneventful.',
    normals: [{ section: /events & complications/i, button: 'Uneventful', check: [/^uneventful$/i] }],
    signers: [S('anes', 'Anesthesia', 'Anesthesiologist / CRNA', 'I administered and documented this anesthetic.'), S('super', 'Anesthesiologist', 'Supervising anesthesiologist (if CRNA)', 'I supervised this anesthetic.', false)],
  },
  'Surgeon_Operative_Report.html': {
    voiceSample: 'Findings: as expected, no complications. Technique: standard approach per preference card, closed in layers. EBL about 50, wound class two.',
    normals: [{ section: /operative findings/i, button: 'No complications', check: [/^none$/i] }],
    signers: [S('surgeon', 'Surgeon', 'Operating surgeon', 'I performed this procedure and this report is accurate.')],
  },
  'Physician_Discharge_Order.html': {
    defaults: [{ label: /^follow-up appointment$/i, value: 'Office follow-up in 1 week (office will call to confirm)' }],
    normals: [{ section: /discharge order/i, button: 'Discharge home when criteria met', check: [/^patient may be released when nursing criteria are met/i] }],
    signers: [S('md', 'Surgeon', 'Operating or covering physician', 'I order this discharge.'), S('pacurn', 'PACU RN', 'PACU RN acknowledges', 'I acknowledge this order.', false)],
    sequential: true,
  },
  'PACU_Recovery_Record.html': {
    aldrete: true, pacuLos: true,
    voiceSample: 'Arrived to PACU 9:10, BP 128 over 76, pulse 72, resp 14, sats 98 on 2 liters, pain 2.',
    defaults: [
      { label: /^mode of transfer$/i, value: 'Stretcher' }, { label: /^pain scale used$/i, value: 'Numeric 0–10' },
      { label: /^surgical dressing status$/i, value: 'Clean, dry, intact' }, { label: /^disposition$/i, value: 'Home' },
    ],
    normals: [
      { section: /admission to pacu/i, button: 'Hand-off received', check: [/^verbal handoff/i, /^report included/i, /^written anesthesia record/i] },
      { section: /nausea/i, button: 'No nausea / vomiting', check: [/^no nausea/i] },
      { section: /discharge \/ transfer disposition/i, button: 'Meds + follow-up reviewed', check: [/^discharge medications reviewed/i, /^follow-up appointment instructions/i] },
    ],
    signers: [S('monitor', 'PACU RN', 'PACU RN — ongoing monitoring & care', 'I attest to the vital signs, medications and interval assessments recorded above.', true, { sections: /^(?!discharge).*/i }), S('discharge', 'PACU RN', 'RN confirming discharge criteria met', 'I confirm the discharge criteria above were met at the time recorded.', true, { sections: /discharge/i })],
    sequential: true,
  },
  'PostOp_Discharge.html': {
    normals: [
      { section: /criteria-based discharge/i, button: 'All criteria met', check: [/./] },
      { section: /discharge logistics/i, button: 'Standard instructions given', check: [/^written, individualized/i, /^emergency contact phone/i, /^patient explicitly instructed not to drive/i] },
    ],
    signers: [PATIENT('Patient / representative'), S('escort', 'Escort', 'Responsible adult escort', 'I will accompany the patient home and stay with them as instructed.', true, { patient: true }), S('rn', 'PACU RN', 'Discharging RN', 'I discharged the patient per the criteria above.')],
    sequential: true,
  },
  'Written_Discharge_Instructions.html': {
    defaults: [{ label: /^follow-up appointment$/i, value: 'Office follow-up in 1 week (office will call to confirm)' }],
    normals: [
      { section: /general instructions/i, button: 'Standard 24-hour instructions', check: [/^a responsible adult must stay/i, /^do not drive/i, /^do not drink alcohol/i, /^start with clear liquids/i] },
      { section: /warning signs/i, button: 'Standard warning signs', check: [/^fever/i, /^increasing pain/i, /^excessive bleeding/i, /^difficulty breathing/i, /^persistent vomiting/i] },
    ],
    signers: [PATIENT('Patient / responsible adult'), S('rn', 'PACU RN', 'Nurse — instructions reviewed', 'I reviewed these instructions with the patient and responsible adult.')],
    sequential: true,
  },
  'Emergency_Transfer_Form.html': { signers: [S('md', 'Physician', 'Physician authorizing transfer', 'I authorize this transfer.'), S('rn', 'RN', 'RN documenting transfer', 'I documented this transfer.')], sequential: true },
  'AMA_Refusal_Form.html': { signers: [PATIENT(), S('witness', 'RN', 'RN witness', 'I witnessed this refusal discussion.'), S('surgeon', 'Surgeon', 'Surgeon', 'I discussed the risks of refusal with the patient.', false)], sequential: true },
  'Anesthesia_Order_Form.html': { signers: [S('anes', 'Anesthesia', 'Ordering anesthesiologist', 'I am the ordering provider.')] },
  'PACU_Doctor_Orders.html': { signers: [S('md', 'Physician', 'Ordering physician', 'I am the ordering provider.'), S('rn', 'PACU RN', 'RN acknowledges', 'I acknowledge these orders.', false)], sequential: true },
  'Surgeon_Orders.html': { signers: [S('surgeon', 'Surgeon', 'Ordering surgeon', 'I am the ordering provider.')] },
};
const GENERIC_RULE = (): FormRule => ({ signers: [S('staff', 'Clinician', 'Authenticating clinician', 'I attest this document is accurate.')] });

/** Roles offered in Form Studio's signer setup: staff roles plus people who are not staff users. */
export const STAFF_SIGNER_ROLES = ['Front desk', 'Pre-op RN', 'RN', 'Circulating RN', 'PACU RN', 'Anesthesia', 'Anesthesiologist', 'Surgeon', 'Physician', 'Clinician'];
export const NON_STAFF_SIGNER_ROLES = ['Patient', 'Escort', 'Witness'];
/** Nightingale (the AI) can never hold a signer slot. */
export const isAiSigner = (s: { role?: string; label?: string }) => /nightingale|\bai\b|artificial intelligence/i.test(`${s.role || ''} ${s.label || ''}`);
const escRe = (t: string) => t.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

/** Apply a Form Studio signer setup over the built-in rule (keeps normals/defaults/etc. and any slot extras such as `sections`). */
export function applySignerConfig(base: FormRule | undefined, cfg: SignerConfig): FormRule | null {
  const slots = cfg.signers.filter(x => x && x.id && x.role && !isAiSigner(x));
  if (!slots.length || !slots.some(x => x.required)) return null;
  const signers: SignerSlot[] = slots.map(x => {
    const prior = base?.signers.find(b => b.id === x.id);
    return { ...(prior || {}), id: x.id, role: x.role, label: x.label || x.role, attestation: x.attestation || 'I attest this document is accurate.', required: !!x.required, patient: x.patient ?? NON_STAFF_SIGNER_ROLES.includes(x.role) };
  });
  const ids = new Set(signers.map(x => x.id));
  const initials: InitialsSpec[] = (cfg.initials || []).filter(p => ids.has(p.slot)).map(p => ({ page: new RegExp(`^${escRe(p.pageTitle || '')}$`, 'i'), pageIndex: p.pageIndex, slot: p.slot, statement: p.statement, existing: p.existing }));
  return { ...(base || {}), signers, sequential: !!cfg.sequential, initials };
}

/** Signer rule for a form: saved Form Studio setup → built-in FORM_RULES → generic fallback. */
export const ruleFor = (file: string): FormRule => {
  const base = FORM_RULES[file];
  const cfg = repo.getSignerConfig(file);
  if (cfg) { const r = applySignerConfig(base, cfg); if (r) return r; }
  return base || GENERIC_RULE();
};

/** Prefill for Form Studio's signer step (same chain as ruleFor). `pageTitles` are the template's pages (section.page[data-title]). */
export function signerSetupFor(file: string, pageTitles: string[]): { signers: StoredSignerSlot[]; sequential: boolean; initials: SignerConfig['initials']; source: 'saved' | 'built-in' | 'generic' } {
  const cfg = repo.getSignerConfig(file);
  const source = cfg && applySignerConfig(FORM_RULES[file], cfg) ? 'saved' : FORM_RULES[file] ? 'built-in' : 'generic';
  const r = ruleFor(file);
  const signers = r.signers.map(x => ({ id: x.id, role: x.role, label: x.label, attestation: x.attestation, required: x.required, patient: !!x.patient }));
  const initials: SignerConfig['initials'] = [];
  (r.initials || []).forEach(sp => {
    const idx = sp.pageIndex ?? pageTitles.findIndex(t => sp.page.test(t));
    if (idx >= 0 && idx < pageTitles.length) initials.push({ pageIndex: idx, pageTitle: pageTitles[idx], slot: sp.slot, statement: sp.statement, existing: sp.existing });
  });
  return { signers, sequential: !!r.sequential, initials, source };
}

/* ---------------- station plans ---------------- */
export const STATIONS: { key: StationKey; label: string; short: string }[] = [
  { key: 'patientPortal', label: 'Patient Portal', short: 'Portal' }, { key: 'frontOffice', label: 'Front Office', short: 'Front' },
  { key: 'nursing', label: 'Pre-op Nursing', short: 'Pre-op RN' }, { key: 'anesthesia', label: 'Anesthesia', short: 'Anesthesia' },
  { key: 'surgeon', label: 'Surgeon / Physician', short: 'Surgeon' }, { key: 'orTeam', label: 'OR Team', short: 'OR' },
  { key: 'pacu', label: 'PACU / Discharge', short: 'PACU' }, { key: 'caseRecord', label: 'Case Record', short: 'Record' },
];
export const STATION_PLAN: Record<WorkflowKey, { required: string[]; asNeeded: string[] }> = {
  patientPortal: { required: ['Patient_Registration.html', 'Insurance_Information.html', 'Medical_History.html', 'Anesthesia_Questionnaire.html', 'Admission_Form.html', 'Procedure_Consent.html', 'Anesthesia_Consent.html'], asNeeded: ['Billing_Fee_Disclosure.html', 'Credit_Card_Authorization.html', 'Photography_Media_Research_Consent.html', 'Written_Discharge_Instructions.html', 'Patient_Satisfaction_Survey.html'] },
  frontOffice: { required: ['Patient_Registration.html', 'Insurance_Information.html', 'Admission_Form.html'], asNeeded: ['Billing_Fee_Disclosure.html', 'Credit_Card_Authorization.html'] },
  nursing: { required: ['Nursing_Admission.html', 'MH_and_VTE_Assessment.html'], asNeeded: ['Medical_History.html', 'AMA_Refusal_Form.html', 'Emergency_Transfer_Form.html'] },
  anesthesia: { required: ['Anesthesia_Evaluation.html', 'Anesthesia_Consent.html'], asNeeded: ['Anesthesia_Questionnaire.html', 'Medical_History.html', 'MH_and_VTE_Assessment.html', 'Anesthesia_Order_Form.html', 'Universal_Protocol_Safety_Checklist.html', 'Anesthesia_IntraOp_Record.html', 'PreOp_HP_Clearance.html', 'Emergency_Transfer_Form.html'] },
  surgeon: { required: ['DayOf_Interval_HP_Update.html', 'Surgeon_PreOp_Clearance.html', 'Procedure_Consent.html', 'Surgeon_Operative_Report.html', 'Physician_Discharge_Order.html'], asNeeded: ['PreOp_HP_Clearance.html', 'MH_and_VTE_Assessment.html', 'Universal_Protocol_Safety_Checklist.html', 'Surgeon_Orders.html', 'AMA_Refusal_Form.html', 'Emergency_Transfer_Form.html'] },
  orTeam: { required: ['Universal_Protocol_Safety_Checklist.html', 'IntraOp_Nursing_Record_TO.html', 'Anesthesia_IntraOp_Record.html'], asNeeded: ['Emergency_Transfer_Form.html'] },
  pacu: { required: ['PACU_Recovery_Record.html', 'PostOp_Discharge.html', 'Written_Discharge_Instructions.html'], asNeeded: ['Physician_Discharge_Order.html', 'PACU_Doctor_Orders.html', 'AMA_Refusal_Form.html', 'Emergency_Transfer_Form.html'] },
};
/** The signer slots a station is responsible for on each required form. */
export const STATION_ROLES: Record<WorkflowKey, RegExp> = {
  patientPortal: /^Patient$|^Escort$/, frontOffice: /Front desk/, nursing: /Pre-op RN|^RN$/, anesthesia: /Anesthesi/, surgeon: /Surgeon|Physician|^Patient$/, orTeam: /Circulating RN|^RN$|Surgeon|Anesthesia/, pacu: /PACU RN|^Patient$|^Escort$/,
};
export const NEXT_STATUS: Partial<Record<WorkflowKey, string>> = {
  frontOffice: 'READY_FOR_PREOP', nursing: 'READY_FOR_ANESTHESIA', anesthesia: 'READY_FOR_OR', surgeon: 'READY_FOR_OR', orTeam: 'PACU', pacu: 'DISCHARGED',
};
