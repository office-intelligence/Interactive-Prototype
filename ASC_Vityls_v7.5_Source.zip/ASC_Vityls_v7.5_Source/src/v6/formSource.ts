/*
 * Form template source. Templates are bundled into the app at build time so the
 * packaged test build works from file:// (no web server, no network fetch).
 * A practice-customized template saved in Form Studio wins over the bundled one,
 * so customizations now reach the day-of-surgery station (baseline review 5b.6).
 * Backend: replace with GET /practices/:id/form-templates/:file (versioned).
 */
import { stripTemplateSignatures } from '../v7/stripSignatures';
const bundled = import.meta.glob('../../public/forms/*.html', { query: '?raw', import: 'default', eager: true }) as Record<string, string>;

const BY_FILE: Record<string, string> = {};
Object.entries(bundled).forEach(([path, html]) => { BY_FILE[path.split('/').pop() as string] = html; });

export function bundledFormFiles(): string[] { return Object.keys(BY_FILE); }

export function getFormHtmlSync(file: string): string {
  try {
    const custom = localStorage.getItem(`vityls-master-form-template:${file}`) || localStorage.getItem(`vityls-form-template:${file}`);
    if (custom && /<(input|select|textarea|form|div)/i.test(custom)) return stripTemplateSignatures(custom);
  } catch { /* ignore */ }
  return BY_FILE[file] || '';
}

/** Drop-in replacement for `fetch('/forms/'+file).then(r=>r.text())`. */
export async function loadFormHtml(file: string): Promise<string> {
  const local = getFormHtmlSync(file);
  if (local) return local;
  try { const r = await fetch(`forms/${file}`); return r.ok ? await r.text() : ''; } catch { return ''; }
}

/** Bundled (uncustomized) template only. */
export function getBundledFormHtml(file: string): string { return BY_FILE[file] || ''; }

/** Response-shaped shim so legacy `fetch('/forms/x').then(r=>r.text())` chains work from file://. */
export function bundledFetch(file: string): Promise<{ ok: boolean; text: () => Promise<string> }> {
  const t = getBundledFormHtml(file);
  return Promise.resolve({ ok: !!t, text: () => Promise.resolve(t) });
}
