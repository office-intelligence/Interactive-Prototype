/**
 * v6 date helpers. Fixes the baseline 2-digit-year bug: the schedule produced "10/04/26",
 * which the app then filed under the year 0026/1926. Everything is stored as MM/DD/YYYY.
 */
export function normalizeUsDate(input: string | undefined | null): string {
  const s = String(input || '').trim();
  if (!s) return '';
  let m = s.match(/^(\d{4})-(\d{1,2})-(\d{1,2})/);
  if (m) return `${m[2].padStart(2, '0')}/${m[3].padStart(2, '0')}/${m[1]}`;
  m = s.match(/^(\d{1,2})[/.-](\d{1,2})[/.-](\d{2}|\d{4})$/);
  if (!m) return s;
  let y = Number(m[3]);
  if (m[3].length === 2) y += 2000; // dates of service are always this century
  return `${m[1].padStart(2, '0')}/${m[2].padStart(2, '0')}/${y}`;
}
/** MM/DD/YYYY -> YYYY-MM-DD (storage key), or '' if not a full date. */
export function usDateToKey(input: string | undefined | null): string {
  const n = normalizeUsDate(input);
  const m = n.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);
  return m ? `${m[3]}-${m[1]}-${m[2]}` : '';
}
