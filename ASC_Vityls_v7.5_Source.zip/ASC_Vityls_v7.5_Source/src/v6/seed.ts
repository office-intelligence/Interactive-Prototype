/*
 * v6 test scaffolding: on first open (empty browser storage) load three FICTIONAL cases for today so the
 * build can be tried immediately. No real patient data. Open the app with ?reset-test-data in the address
 * bar to wipe this browser's test data and start over.
 * Backend: delete this file; cases come from the scheduling API.
 */
import { seedClearanceDocs, seedClearedCase } from '../v7/clearance';
const pad = (n: number) => String(n).padStart(2, '0');
export const SEED_VERSION = 'v7.5';
export function seedTestData() {
  try {
    const params = new URLSearchParams(location.search);
    // v7 item 18: the default fresh state is a clean slate (3 fictional patients, nothing in My Forms, no form
    // records, no signer setups). It is applied on first open of this build and again with ?reset-test-data.
    if (params.has('reset-test-data') || localStorage.getItem('vityls:seed-version') !== SEED_VERSION) {
      localStorage.clear();
      localStorage.setItem('vityls:seed-version', SEED_VERSION);
      if (params.has('reset-test-data')) history.replaceState(null, '', location.pathname);
    }
    const existing = JSON.parse(localStorage.getItem('vityls:evaluation:date-cases') || '{}');
    if (Object.values(existing).some((l: any) => Array.isArray(l) && l.length)) return;
    const d = new Date(); const key = `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
    const us = `${pad(d.getMonth() + 1)}/${pad(d.getDate())}/${d.getFullYear()}`;
    const dayIndex = (d.getDay() + 6) % 7;
    const people = [
      { n: 'Testa Fictional', g: 'Female', dob: '03/14/1975', age: 51, t: '08:00 AM', h: 8, room: 'OR #1', proc: 'Right knee arthroscopy (fictional test case)', anes: 'General Anesthesia', allergies: [] as string[], mrn: '900101' },
      { n: 'Demo Patient-Two', g: 'Male', dob: '07/02/1962', age: 64, t: '10:00 AM', h: 10, room: 'OR #2', proc: 'Left carpal tunnel release (fictional test case)', anes: 'MAC / Deep Sedation', allergies: ['Penicillin (hives) — test'], mrn: '900102' },
      { n: 'Sample Third', g: 'Female', dob: '11/23/1988', age: 37, t: '01:00 PM', h: 13, room: 'OR #1', proc: 'Excision of benign skin lesion, back (fictional test case)', anes: 'General Anesthesia', allergies: ['NKDA'], mrn: '900103', sg: 'Riley Nguyen, MD' },
    ];
    const cases = people.map((p, i) => ({
      id: `case-test-${i + 1}`, patientId: p.mrn, name: p.n, age: p.age, gender: p.g, dob: p.dob, phone: `(555) 010-010${i}`,
      scheduledTime: p.t, estimatedDurationMins: 90, room: p.room, surgeon: (p as any).sg || 'Sam Patel, MD', anesthesiologist: 'Jordan Lee, MD',
      procedure: p.proc, aiSummary: `${p.n} (fictional) is scheduled for ${p.proc} on ${us} at ${p.t} in ${p.room}.`,
      readinessScore: 0, readinessLevel: 'IN_PROGRESS', allergies: p.allergies, labs: [], stage: 'CHECK_IN', arrivalStatus: 'EN_ROUTE',
      arrivalTime: '', bottlenecks: ['At-Home Intake not yet completed'], actionItems: [], checkInStatus: 'NOT_STARTED', appointmentDate: us, paymentType: 'Self-Pay',
    }));
    const apts = people.map((p, i) => ({
      id: `APT-TEST-${i + 1}`, dayIndex, room: p.room, startHour: p.h, durationHours: 1.5, title: p.n, surgeon: (p as any).sg || 'Sam Patel, MD',
      details: `[Fictional test case] ${p.proc}`, bgColor: 'bg-emerald-600 text-white border-emerald-700', dos: us, startTime: p.t, length: '1.5 Hours',
      patientName: p.n, dob: p.dob, age: String(p.age), phone: `(555) 010-010${i}`, procedure: p.proc, anesthesiologist: 'Jordan Lee, MD',
      anesthesiaType: p.anes, paymentType: 'Self-Pay', notes: 'Fictional test case loaded by the v7 test build.', caseId: `case-test-${i + 1}`,
    }));
    localStorage.setItem('vityls:evaluation:date-cases', JSON.stringify({ [key]: cases }));
    localStorage.setItem('vityls:evaluation:appointments', JSON.stringify(apts));
    localStorage.setItem('vityls:evaluation:selected-date', key);
    seedClearanceDocs('case-test-2', us); // fictional H&P, labs and ECG so Review & alerts can be tried
    seedClearedCase('case-test-3', us); // v7.3: one fictional case already reviewed + cleared (blue on the dashboard)
  } catch { /* storage unavailable: app still opens empty */ }
}
