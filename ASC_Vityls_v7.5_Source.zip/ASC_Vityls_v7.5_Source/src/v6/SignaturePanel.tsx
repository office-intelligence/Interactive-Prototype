import React, { useEffect, useRef, useState } from 'react';
import { Lock, PenLine, ShieldCheck, FilePlus2, Clock } from 'lucide-react';
import type { FormRecord, SignatureEvent, Actor } from './dataLayer';
import { fmtDateTime } from './dataLayer';
import { DialogShell, Btn } from '../v7/ui';
import { checkSignerPin, findProvider, signBlock } from '../v7/providers';
import { recordPinFailure, recordPinSuccess } from '../v7/invitations';
import type { SignerSlot } from './formRules';

/* Simple, glove-friendly signature canvas (44px+ controls, 16px text). */
export const DrawPad: React.FC<{ onChange: (dataUrl: string | null) => void }> = ({ onChange }) => {
  const ref = useRef<HTMLCanvasElement>(null); const drawing = useRef(false); const [has, setHas] = useState(false);
  const pt = (e: React.PointerEvent) => { const c = ref.current!; const r = c.getBoundingClientRect(); return { x: (e.clientX - r.left) * (c.width / r.width), y: (e.clientY - r.top) * (c.height / r.height) }; };
  const down = (e: React.PointerEvent) => { const ctx = ref.current!.getContext('2d')!; drawing.current = true; const p = pt(e); ctx.beginPath(); ctx.moveTo(p.x, p.y); (e.target as Element).setPointerCapture?.(e.pointerId); };
  const move = (e: React.PointerEvent) => { if (!drawing.current) return; const ctx = ref.current!.getContext('2d')!; ctx.lineWidth = 3; ctx.lineCap = 'round'; ctx.strokeStyle = '#10241b'; const p = pt(e); ctx.lineTo(p.x, p.y); ctx.stroke(); if (!has) setHas(true); };
  const up = () => { if (!drawing.current) return; drawing.current = false; onChange(ref.current!.toDataURL('image/png')); };
  const clear = () => { const c = ref.current!; c.getContext('2d')!.clearRect(0, 0, c.width, c.height); setHas(false); onChange(null); };
  return <div>
    <canvas ref={ref} width={900} height={220} onPointerDown={down} onPointerMove={move} onPointerUp={up} onPointerLeave={up}
      className="w-full h-[140px] bg-white border-2 border-dashed border-[#9aa8a0] rounded-lg touch-none" aria-label="Draw signature" />
    <div className="flex justify-between items-center mt-2"><span className="text-[14px] text-[#4a5750]">Sign with finger or stylus</span><button type="button" onClick={clear} className="v6-btn v6-btn-secondary">Clear</button></div>
  </div>;
};

export interface SignRequest { slot: SignerSlot; signerName: string; credentials: string; method: 'drawn' | 'typed'; image?: string }

export const nameInitials = (n: string) => n.replace(/,.*$/, '').split(/[\s-]+/).filter(Boolean).map(w => w[0]).join('').toUpperCase();

export const SignDialog: React.FC<{ slot: SignerSlot; actor: Actor; patientName: string; formTitle: string; initials?: { page: string; value: string }[]; onCancel: () => void; onSign: (r: SignRequest) => void }> = ({ slot, actor, patientName, formTitle, initials, onCancel, onSign }) => {
  const [name, setName] = useState(slot.patient ? (slot.role === 'Patient' ? patientName : '') : actor.name);
  const [cred, setCred] = useState(slot.patient ? '' : (actor.credentials || ''));
  const [attest, setAttest] = useState(false); const [method, setMethod] = useState<'drawn' | 'typed'>('drawn');
  const [img, setImg] = useState<string | null>(null); const [typed, setTyped] = useState(''); const [pin, setPin] = useState('');
  const isAi = /nightingale/i.test(name);
  const registered = !slot.patient && !!findProvider(name);
  // v7: a registered provider's degree comes from Providers, not from the station login
  React.useEffect(() => { const pv = !slot.patient ? findProvider(name) : undefined; if (pv?.degree) setCred(pv.degree); }, [name, slot.patient]);
  // v7.4: the PIN is checked when Sign is pressed (no live PIN oracle); 5 wrong PINs lock the provider's account.
  const block = slot.patient ? null : signBlock(name);
  const [pinErr, setPinErr] = useState('');
  const ok = !!name.trim() && attest && !isAi && !block && (method === 'drawn' ? !!img : typed.trim().toLowerCase() === name.trim().toLowerCase()) && (slot.patient || pin.length >= 4);
  const doSign = () => {
    if (!slot.patient && registered) {
      const r = checkSignerPin(name, pin);
      if (r === 'wrong') { const left = recordPinFailure(name); setPin(''); setPinErr(left > 0 ? `That PIN doesn’t match ${name.trim()}’s signature PIN. ${left} attempt${left === 1 ? '' : 's'} left before the account locks.` : `Too many wrong PINs. ${name.trim()}’s account is locked; an administrator can unlock it in Providers.`); return; }
      if (r !== 'ok') return;
      recordPinSuccess(name);
    }
    onSign({ slot, signerName: name.trim(), credentials: cred.trim(), method, image: method === 'drawn' ? img || undefined : undefined });
  };
  return <DialogShell zIndex={200} size="md" testId="sign-dialog" kicker={`Sign · ${formTitle}`} title={slot.label} onClose={onCancel}
    footer={<><Btn variant="secondary" onClick={onCancel}>Cancel</Btn><Btn variant="confirm" disabled={!ok} onClick={doSign} icon={<PenLine size={18} />}>Sign</Btn></>}>
    <div className="space-y-4">
      <div className="grid sm:grid-cols-2 gap-3">
        <label className="v6-field">Signer full name<input value={name} onChange={e => setName(e.target.value)} className="v6-input" autoComplete="off" /></label>
        {!slot.patient && <label className="v6-field">Credentials<input value={cred} onChange={e => setCred(e.target.value)} className="v6-input" placeholder="RN, MD, CRNA…" /></label>}
      </div>
      {!!initials?.length && <div className="p-3 rounded-lg border border-[#dfe5e1] bg-[#f7faf8] text-[15px]" data-testid="sign-initials"><b>Initials on this packet</b><ul className="mt-1 space-y-0.5">{initials.map((x, k) => <li key={k}>{x.page}: <b className="tracking-wider">{x.value}</b></li>)}</ul>
        {name.trim() && initials.some(x => x.value.split(',').some(v => v.replace(/[^A-Z]/gi, '').toUpperCase() !== nameInitials(name))) && <p className="mt-2 text-[14px] text-[#7a5414]">These initials don’t match “{name.trim()}” ({nameInitials(name)}). That is fine if a legally responsible person initialed and is signing; otherwise go back and correct them.</p>}</div>}
      {isAi && <p className="text-[15px] text-[#8a2a2a] font-semibold">Nightingale cannot sign. Only a person can attest and sign.</p>}
      <label className="flex gap-3 items-start min-h-[44px] p-3 bg-[#f4f7f5] border border-[#dfe5e1] rounded-lg cursor-pointer">
        <input type="checkbox" checked={attest} onChange={e => setAttest(e.target.checked)} className="w-6 h-6 mt-0.5 accent-[#1f6e52] flex-none" />
        <span className="text-[15px] leading-snug"><b>Attestation.</b> {slot.attestation}</span>
      </label>
      <div className="flex gap-2" role="tablist">{(['drawn', 'typed'] as const).map(m => <button key={m} type="button" onClick={() => setMethod(m)} className={`v6-btn ${method === m ? 'v6-btn-primary' : 'v6-btn-secondary'}`}>{m === 'drawn' ? 'Draw signature' : 'Type full name'}</button>)}</div>
      {method === 'drawn' ? <DrawPad onChange={setImg} /> : <label className="v6-field">Type your full name exactly<input value={typed} onChange={e => setTyped(e.target.value)} className="v6-input" autoComplete="off" /></label>}
      {!slot.patient && <label className="v6-field">Re-confirm identity: signature PIN{registered ? ' (set in Administration → Providers)' : ' (staff not in the provider list: any 4+ digits in this build)'}<input value={pin} onChange={e => setPin(e.target.value.replace(/\D/g, ''))} inputMode="numeric" type="password" className="v6-input" maxLength={8} data-testid="sign-pin" /></label>}
      {block && <p className="text-[15px] text-[#8a2a2a]" role="alert" data-testid="sign-blocked">{block === 'inactive' ? `${name.trim()} is deactivated in Providers and cannot sign.` : block === 'locked' ? `${name.trim()}’s account is locked after too many wrong PINs. An administrator can unlock it in Providers.` : `${name.trim()} has not created a signature PIN yet. They set it from the PIN link in their invitation email.`}</p>}
      {pinErr && !block && <p className="text-[15px] text-[#8a2a2a]" role="alert" data-testid="sign-pin-error">{pinErr}</p>}
      <p className="text-[13.5px] text-[#4a5750]">Date and time are recorded automatically. In this test build the time comes from this device; the backend will use the server clock and a verified login.</p>
    </div>
  </DialogShell>;
};

export function slotState(slots: SignerSlot[], rec: FormRecord, sequential?: boolean) {
  return slots.map((s, i) => {
    const sig = rec.signatures.find(x => x.slotId === s.id);
    const blocker = sequential ? slots.slice(0, i).find(p => p.required && !rec.signatures.some(x => x.slotId === p.id)) : undefined;
    return { slot: s, sig, blocker };
  });
}

export const SignaturePanel: React.FC<{
  slots: SignerSlot[]; sequential?: boolean; rec: FormRecord; pendingConfirm: number; addendumMode: boolean;
  onSignClick: (s: SignerSlot) => void; onAddendum: () => void; onShowPending: () => void;
  /** multi-page packets: pages whose initials are still empty, per signer slot */
  missingInitials?: Record<string, { page: string; pageIndex: number }[]>; onGoPage?: (i: number) => void;
}> = ({ slots, sequential, rec, pendingConfirm, addendumMode, onSignClick, onAddendum, onShowPending, missingInitials, onGoPage }) => {
  const st = slotState(slots, rec, sequential);
  const locked = rec.status === 'locked';
  return <section className="mt-4 bg-white border border-[#dfe5e1] rounded-lg p-5" id="v6-signatures">
    <div className="flex flex-wrap justify-between gap-3 items-start">
      <div><div className="v6-kicker">Review & signatures</div><h2 className="text-[20px] font-bold mt-1">{slots.length ? `${slots.length} signer${slots.length > 1 ? 's' : ''}${sequential ? ', in order' : ''}` : 'No signature required'}</h2>
        <p className="text-[14px] text-[#4a5750] mt-1">Nightingale prepares and routes this form. It never signs, attests, accepts its own suggestions or unlocks a record.</p></div>
      {locked ? <span className="v6-pill v6-pill-ok"><Lock size={16} /> Locked {fmtDateTime(rec.lockedAt)} · fingerprint {rec.lockedHash?.slice(0, 8)}</span> : rec.status === 'partially-signed' ? <span className="v6-pill v6-pill-warn">Partially signed — signed sections are locked</span> : <span className="v6-pill">Draft</span>}
    </div>
    {pendingConfirm > 0 && !locked && <button type="button" onClick={onShowPending} className="mt-3 w-full text-left p-3 rounded-lg bg-[#fff8e8] border border-[#e6cf9f] text-[15px] text-[#6b4a10] min-h-[44px]"><b>{pendingConfirm} prefilled value{pendingConfirm > 1 ? 's' : ''} need a person to confirm</b> (defaults, allergies, medications or patient-reported history) before signing. Tap to go to the first one.</button>}
    <ol className="mt-4 space-y-2">
      {st.map(({ slot, sig, blocker }, i) => <li key={slot.id} className={`border rounded-lg p-3 flex flex-wrap gap-3 items-center justify-between ${sig ? 'border-[#bcd9ca] bg-[#f3faf6]' : 'border-[#dfe5e1]'}`}>
        <div className="min-w-0"><div className="text-[13px] font-bold text-[#4a5750] uppercase tracking-wide">{i + 1}. {slot.role}{slot.required ? '' : ' · optional'}{slot.sections ? ' · signs its own sections' : ''}</div>
          <div className="text-[16px] font-semibold">{slot.label}</div>
          {sig ? <SigLine sig={sig} /> : <div className="text-[14px] text-[#4a5750] mt-0.5">“{slot.attestation}”</div>}
        </div>
        {!sig && !locked && !!missingInitials?.[slot.id]?.length && <div className="basis-full p-3 rounded-lg bg-[#fff8e8] border border-[#e6cf9f] text-[15px] text-[#5c3f0c]" data-testid={`initials-needed-${slot.id}`}><b>Initials needed before {slot.role.toLowerCase()} signs:</b> <span className="inline-flex flex-wrap gap-2 mt-1">{missingInitials[slot.id].filter((x, k, a) => a.findIndex(y => y.pageIndex === x.pageIndex) === k).map(x => <button key={x.pageIndex} type="button" onClick={() => onGoPage?.(x.pageIndex)} className="v6-btn v6-btn-secondary">Go to {x.pageIndex + 1}. {x.page}</button>)}</span></div>}
        {!sig && !locked && <button type="button" disabled={!!blocker || pendingConfirm > 0 || addendumMode || !!missingInitials?.[slot.id]?.length} onClick={() => onSignClick(slot)} className="v6-btn v6-btn-primary disabled:opacity-40" data-testid={`sign-${slot.id}`}>
          <PenLine size={18} /> {blocker ? `Waits for ${blocker.role}` : `Sign as ${slot.role}`}</button>}
      </li>)}
    </ol>
    {locked && <div className="mt-4 flex flex-wrap gap-3 items-center"><button type="button" onClick={onAddendum} disabled={addendumMode} className="v6-btn v6-btn-secondary disabled:opacity-40"><FilePlus2 size={18} /> Add addendum</button><span className="text-[14px] text-[#4a5750]">Signed content can’t be edited. Changes become a dated, signed addendum; the original stays visible.</span></div>}
    {rec.addenda.length > 0 && <div className="mt-4"><h3 className="text-[16px] font-bold">Addenda</h3><ul className="mt-2 space-y-2">{rec.addenda.map(a => <li key={a.id} className="border border-[#e6cf9f] bg-[#fffaf0] rounded-lg p-3 text-[15px]"><div className="font-semibold"><Clock size={15} className="inline mr-1" />{fmtDateTime(a.at)} · {a.by} ({a.role})</div><div className="mt-1">Reason: {a.reason}</div><ul className="mt-1 text-[14px]">{a.changes.map(c => <li key={c.key}>{c.label}: <s className="text-[#8a2a2a]">{String(c.from ?? '—') || '—'}</s> → <b>{String(c.to)}</b></li>)}</ul></li>)}</ul></div>}
  </section>;
};
const SigLine: React.FC<{ sig: SignatureEvent }> = ({ sig }) => <div className="text-[14px] text-[#1f5c46] mt-0.5 flex items-center gap-2 flex-wrap"><ShieldCheck size={16} /> Signed by <b>{sig.signerName}{sig.credentials ? `, ${sig.credentials}` : ''}</b> · {fmtDateTime(sig.at)} · {sig.method === 'drawn' ? 'drawn signature' : 'typed name'}{sig.initials?.length ? ` · initialed ${Array.from(new Set(sig.initials.map(x => x.page))).join(', ')} (${Array.from(new Set(sig.initials.map(x => x.value))).join(', ')})` : ''}{sig.image && <img src={sig.image} alt="signature" className="h-8 border rounded bg-white" />}</div>;

export const AddendumDialog: React.FC<{ changes: { key: string; label: string; from: any; to: any }[]; actor: Actor; onCancel: () => void; onSave: (reason: string, name: string) => void }> = ({ changes, actor, onCancel, onSave }) => {
  const [reason, setReason] = useState(''); const [name, setName] = useState(actor.name); const [attest, setAttest] = useState(false); const [typed, setTyped] = useState('');
  useEffect(() => { setName(actor.name); }, [actor.name]);
  const ok = changes.length > 0 && reason.trim().length > 3 && attest && typed.trim().toLowerCase() === name.trim().toLowerCase();
  return <DialogShell zIndex={200} size="md" testId="addendum-dialog" kicker="Addendum" title="Sign the addendum" onClose={onCancel}
    footer={<><Btn variant="secondary" onClick={onCancel}>Back to form</Btn><Btn variant="confirm" disabled={!ok} onClick={() => onSave(reason.trim(), name.trim())}>Sign addendum</Btn></>}>
    <div className="space-y-4">
      {changes.length ? <ul className="text-[15px] space-y-1 border rounded-lg p-3 bg-[#f7f9f7]">{changes.map(c => <li key={c.key}>{c.label}: <s>{String(c.from ?? '') || '—'}</s> → <b>{String(c.to) || '—'}</b></li>)}</ul> : <p className="text-[15px]">No changes yet. Close this, change the fields, then save the addendum.</p>}
      <label className="v6-field">Reason for the change<textarea value={reason} onChange={e => setReason(e.target.value)} className="v6-input min-h-[88px]" /></label>
      <label className="flex gap-3 items-start min-h-[44px] p-3 bg-[#f4f7f5] border rounded-lg"><input type="checkbox" checked={attest} onChange={e => setAttest(e.target.checked)} className="w-6 h-6 accent-[#1f6e52] flex-none" /><span className="text-[15px]">I attest this addendum is accurate. The original entries remain part of the record.</span></label>
      <label className="v6-field">Type your full name ({name}) to sign<input value={typed} onChange={e => setTyped(e.target.value)} className="v6-input" /></label>
    </div>
  </DialogShell>;
};
