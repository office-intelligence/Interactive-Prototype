import { attachMask, maskForLabel } from '../v7/masks';
/*
 * Turns a bundled HTML form template into a tablet-friendly, data-bound form.
 * Runs on a Shadow DOM root, so template CSS can no longer leak into the app
 * (addendum 4.1) and app CSS can no longer distort the template.
 *  - stable field keys (name / label based, never position based)
 *  - label + section discovery for every control
 *  - inputmode / type hints so iPads open the number keypad (addendum 5.1)
 *  - tap-anywhere rows for checkboxes that have no <label> (addendum 5.1)
 *  - template <script>s are never executed; paging and scores are app code
 */
export type Ctl = HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement;
export interface FieldInfo { el: Ctl; key: string; label: string; section: string; type: string; inTable: boolean; group?: string }

const norm = (s: string) => (s || '').replace(/\s+/g, ' ').replace(/[\u200b]/g, '').trim();
export const slug = (s: string) => norm(s).toLowerCase().replace(/&/g, 'and').replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 60);

export const SECTION_SELECTOR = '.section-banner, .banner, h2, h3, legend, .section-title, .signature-title, .section > h2';

export function prepareTemplate(raw: string): { css: string; body: string } {
  const styles = (raw.match(/<style[^>]*>[\s\S]*?<\/style>/gi) || [])
    .map(s => s.replace(/<\/?style[^>]*>/gi, ''))
    .join('\n')
    .replace(/@import[^;]+;/g, '')                         // no external stylesheet/font requests
    .replace(/(^|[\s,{}>])(html|body|:root)(?=[\s,{.:#\[>])/g, '$1:host');
  let body = raw.match(/<body[^>]*>([\s\S]*?)<\/body>/i)?.[1] || raw;
  body = body
    .replace(/<script[\s\S]*?<\/script>/gi, '')          // never run template scripts
    .replace(/<link[^>]*>/gi, '')                          // no external requests from templates
    .replace(/\son[a-z]+\s*=\s*"[^"]*"/gi, '')            // strip inline handlers
    .replace(/\son[a-z]+\s*=\s*'[^']*'/gi, '');
  return { css: styles, body };
}

function textOf(el: Element | null | undefined, exclude?: Element): string {
  if (!el) return '';
  if (!exclude) return norm((el as HTMLElement).textContent || '');
  const clone = el.cloneNode(true) as HTMLElement;
  clone.querySelectorAll('input,select,textarea,button,.vk-chip,.vk-src').forEach(n => n.remove());
  return norm(clone.textContent || '');
}

function prevLabelish(el: Element): string {
  // walk previous siblings (and parent's previous siblings) for a label-like node
  let node: Element | null = el;
  for (let depth = 0; depth < 3 && node; depth++) {
    let sib = node.previousElementSibling;
    while (sib) {
      if (sib.matches('input,select,textarea,br')) { sib = sib.previousElementSibling; continue; }
      const t = textOf(sib, sib);
      if (t && t.length < 160) return t;
      break;
    }
    node = node.parentElement;
    if (node && node.matches('.form-group,.fg,.field,.q,td,th,li,p')) {
      const lbl = node.querySelector('label,.field-label,p,strong,span');
      if (lbl && !lbl.contains(el)) { const t = textOf(lbl, lbl); if (t) return t; }
    }
  }
  return '';
}

function tableLabel(el: Element): string {
  const td = el.closest('td,th'); const tr = el.closest('tr'); const table = el.closest('table');
  if (!td || !tr || !table) return '';
  const idx = Array.from(tr.children).indexOf(td);
  const headRow = table.querySelector('thead tr') || table.querySelector('tr');
  const head = headRow && headRow !== tr ? textOf(headRow.children[idx] as Element) : '';
  const rowHead = textOf(tr.children[0] as Element, tr.children[0] as Element);
  const rows = Array.from(table.querySelectorAll('tbody tr, tr')).filter(r => r.querySelector('input,select,textarea'));
  const rowNo = rows.indexOf(tr) + 1;
  const rowName = rowHead && !tr.children[0].contains(el) ? rowHead : `row ${rowNo}`;
  return norm(`${head || 'col ' + (idx + 1)} · ${rowName}`);
}

export function labelFor(el: Ctl, root: ParentNode): string {
  const aria = el.getAttribute('aria-label'); if (aria) return norm(aria);
  const wrap = el.closest('label');
  if (wrap) { const t = textOf(wrap, wrap); if (t) return t; }
  if (el.id) { const l = (root as Element).querySelector?.(`label[for="${CSS.escape(el.id)}"]`); if (l) { const t = textOf(l, l); if (t) return t; } }
  if (el.closest('td')) { const t = tableLabel(el); if (t) return t; }
  if (el instanceof HTMLInputElement && (el.type === 'checkbox' || el.type === 'radio')) {
    // checkbox followed by text in the same container
    const parent = el.parentElement; const t = parent ? textOf(parent, parent) : '';
    if (t && t.length < 220) return t;
  }
  const p = prevLabelish(el); if (p) return p;
  const ph = el.getAttribute('placeholder'); if (ph) return norm(ph);
  return norm(el.getAttribute('name') || el.id || 'Field');
}

export function indexFields(root: ShadowRoot | HTMLElement): FieldInfo[] {
  const all = Array.from(root.querySelectorAll<HTMLElement>(`${SECTION_SELECTOR}, input, select, textarea`));
  const out: FieldInfo[] = []; let section = 'General';
  const used = new Map<string, number>();
  const nameCount = new Map<string, number>();
  root.querySelectorAll<Ctl>('input[name],select[name],textarea[name]').forEach(e => { const n = e.getAttribute('name')!; nameCount.set(n, (nameCount.get(n) || 0) + 1); });
  for (const node of all) {
    if (!node.matches('input,select,textarea')) { const t = textOf(node, node); if (t) section = t.slice(0, 80); continue; }
    const el = node as Ctl;
    const type = (el instanceof HTMLInputElement ? el.type : el.tagName.toLowerCase()) || 'text';
    if (['hidden', 'button', 'submit', 'reset', 'file', 'image'].includes(type)) continue;
    if (el.closest('.vk-ignore')) continue;
    const label = labelFor(el, root);
    const name = el.getAttribute('name') || '';
    let base: string;
    if (type === 'checkbox' || type === 'radio') base = `${name || slug(section)}::${slug(label)}`;
    else if (name && nameCount.get(name) === 1) base = name;
    else if (el.id) base = `#${el.id}`;
    else base = `${slug(section)}::${slug(label)}`;
    const n = (used.get(base) || 0) + 1; used.set(base, n);
    const key = n === 1 ? base : `${base}~${n}`;
    el.dataset.vk = key;
    out.push({ el, key, label, section, type, inTable: !!el.closest('td'), group: type === 'radio' ? name : undefined });
  }
  return out;
}

export function getVal(el: Ctl): string | boolean {
  if (el instanceof HTMLInputElement && (el.type === 'checkbox' || el.type === 'radio')) return el.checked;
  return el.value;
}
export function setVal(el: Ctl, v: string | boolean) {
  if (el instanceof HTMLInputElement && (el.type === 'checkbox' || el.type === 'radio')) { el.checked = !!v; return; }
  if (el instanceof HTMLSelectElement) {
    const s = String(v); const opt = Array.from(el.options).find(o => o.value === s || norm(o.text).toLowerCase() === s.toLowerCase())
      || Array.from(el.options).find(o => s && norm(o.text).toLowerCase().startsWith(s.toLowerCase().slice(0, 4)));
    if (opt) el.value = opt.value; return;
  }
  if (el instanceof HTMLInputElement && el.type === 'date') { el.value = toIsoDate(String(v)); return; }
  if (el instanceof HTMLInputElement && el.type === 'time') { el.value = toTime24(String(v)); return; }
  el.value = String(v ?? '');
}
export const isEmpty = (el: Ctl) => { const v = getVal(el); return v === false || v === ''; };

export function toIsoDate(s: string): string {
  if (/^\d{4}-\d{2}-\d{2}$/.test(s)) return s;
  const m = s.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/); if (m) return `${m[3]}-${m[1].padStart(2, '0')}-${m[2].padStart(2, '0')}`;
  return '';
}
export function toTime24(s: string): string {
  if (/^\d{2}:\d{2}$/.test(s)) return s;
  const m = s.match(/^(\d{1,2}):(\d{2})\s*([AaPp][Mm])?$/); if (!m) return '';
  let h = Number(m[1]); const ap = (m[3] || '').toUpperCase();
  if (ap === 'PM' && h < 12) h += 12; if (ap === 'AM' && h === 12) h = 0;
  return `${String(h).padStart(2, '0')}:${m[2]}`;
}

/* ---------- keyboard hints (addendum 5.2) ---------- */
const NUMERIC = /\b(hr|heart rate|pulse|rr|resp(iratory)?( rate)?|spo2|sp02|o2 sat|sat(uration)?|temp(erature)?|pain|score|ebl|blood loss|weight|height|bmi|dose|mg|mcg|ml|units?|count|age|mmhg|bpm|asa|aldrete|glucose|fsbs|length of stay|minutes|min\b|qty|quantity|fio2|etco2|o2 flow|flow|urine|output|intake|iv fluid|crystalloid|kg|lbs?|cm|in\b|%)/i;
const BP = /\b(bp|blood pressure)\b/i;
const PHONE = /phone|telephone|mobile|cell\b|fax/i;
const NOT_NUMERIC = /name|initials|signature|route|medication|drug|site|comment|note|describe|explain|type|location|reaction|scale used|goal|measures|relationship|address|email|delivery|status|mode|disposition|from|vital signs$|loc\b|effect|time\b/i;
export function applyKeyboardHints(fields: FieldInfo[]) {
  for (const f of fields) {
    if (f.el instanceof HTMLInputElement && f.el.type === 'email') { attachMask(f.el, 'email'); continue; }
    if (f.el instanceof HTMLInputElement && f.el.type === 'tel') { attachMask(f.el, 'phone'); continue; }
    if (!(f.el instanceof HTMLInputElement) || f.el.type !== 'text') continue;
    const l = f.label;
    // v7 masks: dates MM/DD/YYYY, SSN, phone, email, ZIP (formatted while typing, validated on blur)
    const mk = f.inTable && /date/i.test(l) && !/birth|dob/i.test(l) ? null : maskForLabel(l, f.el.name || '');
    if (mk) { attachMask(f.el, mk, { past: /birth|dob/i.test(l) }); continue; }
    if (PHONE.test(l) && !/time/i.test(l)) { f.el.type = 'tel'; f.el.inputMode = 'tel'; f.el.autocomplete = 'off'; continue; }
    if (BP.test(l) && !/med|goal/i.test(l)) { f.el.inputMode = 'numeric'; f.el.dataset.vkBp = '1'; f.el.placeholder = f.el.placeholder || '120 80'; continue; }
    if (/^time\b|\btime$|time ·|· time/i.test(l) && f.inTable) { f.el.type = 'time'; continue; }
    if (NUMERIC.test(l) && !NOT_NUMERIC.test(l.replace(/\(.*?\)/g, ''))) {
      f.el.inputMode = /temp|weight|height|bmi|dose|mg|ml|kg|fio2|flow/i.test(l) ? 'decimal' : 'numeric';
      f.el.autocomplete = 'off';
    }
  }
}
/** "128 76" or "128.76" → "128/76" when the field loses focus. */
export function formatBp(el: HTMLInputElement) {
  const m = el.value.trim().match(/^(\d{2,3})[\s.,\-]+(\d{2,3})$/); if (m) el.value = `${m[1]}/${m[2]}`;
}

/* ---------- touch: make label-less checkbox rows tappable ---------- */
export function makeRowsTappable(root: ShadowRoot | HTMLElement) {
  root.querySelectorAll<HTMLInputElement>('input[type=checkbox],input[type=radio]').forEach(cb => {
    if (cb.closest('label')) return;
    if (cb.id && root.querySelector(`label[for="${CSS.escape(cb.id)}"]`)) return;
    const row = cb.parentElement; if (!row) return;
    if (row.querySelectorAll('input[type=checkbox],input[type=radio]').length !== 1) {
      // wrap the box + its following text node(s) in a label
      const label = document.createElement('label'); label.className = 'vk-wrap';
      cb.parentNode!.insertBefore(label, cb); label.appendChild(cb);
      let n = label.nextSibling;
      while (n && !(n instanceof HTMLInputElement) && !(n instanceof HTMLBRElement) && !(n instanceof HTMLElement && n.querySelector('input'))) {
        const next = n.nextSibling; label.appendChild(n); n = next;
      }
      return;
    }
    row.classList.add('vk-tap');
  });
}

/* ---------- multi-page templates (Admission packet) ---------- */
export function setupPaging(root: ShadowRoot, onChange?: (i: number, n: number) => void) {
  const pages = Array.from(root.querySelectorAll<HTMLElement>('section.page'));
  if (pages.length < 2) return null;
  let i = Math.max(0, pages.findIndex(p => p.classList.contains('on')));
  const title = root.getElementById('title'); const lbl = root.getElementById('pgLabel'); const dots = root.getElementById('dots');
  const prev = root.getElementById('prev') as HTMLButtonElement | null; const next = root.getElementById('next') as HTMLButtonElement | null;
  const nav = document.createElement('div'); nav.className = 'vk-pages vk-ignore';
  pages.forEach((p, n) => { const b = document.createElement('button'); b.type = 'button'; b.textContent = `${n + 1}. ${p.dataset.title || 'Page'}`; b.onclick = () => { i = n; show(true); }; nav.appendChild(b); });
  const firstPage = pages[0]; firstPage.parentElement?.insertBefore(nav, firstPage);
  function show(scroll = false) {
    pages.forEach((p, n) => p.classList.toggle('on', n === i));
    if (title) title.textContent = pages[i].dataset.title || '';
    if (lbl) lbl.textContent = `Page ${i + 1} of ${pages.length}`;
    if (dots) dots.textContent = `${i + 1} / ${pages.length}`;
    if (prev) prev.disabled = i === 0;
    if (next) next.textContent = i === pages.length - 1 ? 'Last page' : 'Next';
    Array.from(nav.children).forEach((b, n) => b.classList.toggle('on', n === i));
    if (scroll) (root.host as HTMLElement).scrollIntoView({ block: 'start' });
    onChange?.(i, pages.length);
  }
  if (prev) prev.onclick = () => { i = Math.max(0, i - 1); show(true); };
  if (next) next.onclick = () => { i = Math.min(pages.length - 1, i + 1); show(true); };
  show();
  pages.forEach((p, n) => { if (p.querySelector('[data-vk-initials]')) { const b = nav.children[n] as HTMLElement; b.dataset.initials = '1'; b.title = 'This page needs initials'; } });
  return { count: pages.length, go: (n: number, scroll = true) => { i = Math.max(0, Math.min(pages.length - 1, n)); show(scroll); } };
}

/* ---------- legacy template signature controls are replaced by the app panel ---------- */
export function hideLegacySignatures(root: ShadowRoot) {
  root.querySelectorAll<HTMLElement>('.signature-block, .sig, .sign, .sig-pad-wrap, .sig-pad-actions, .sig-status, .signature-section, .signatures, canvas').forEach(el => { el.classList.add('vk-legacy-sig', 'vk-ignore'); });
  root.querySelectorAll<HTMLElement>('.signature-title').forEach(el => { el.classList.add('vk-legacy-sig'); });
}

/* ---------- override stylesheet: readability + tablet (addendum 4.2 / 5.2) ---------- */
export const OVERRIDE_CSS = `
:host{display:block;color:#1c2a24;font-size:16px;-webkit-text-size-adjust:100%}
*{box-sizing:border-box}
.packet-container,.sheet{max-width:none!important;margin:0!important;box-shadow:none!important;border:0!important}
.who{font-size:15px!important;color:#2f3b35!important;background:#eef5f1!important;border-left:4px solid #1f6e52}
.who strong{color:#10241b}
label,.field-label,.q-label,.q>p{font-size:15px!important;line-height:1.4!important;color:#26332c!important}
.form-group>label,.fg>label{font-weight:600}
p,li,td,.prose,.notice,.note,.alert{font-size:15px;line-height:1.5}
th{font-size:13px!important;letter-spacing:.02em;color:#26332c!important}
.section-banner,.banner{font-size:14px!important;line-height:1.35!important;color:#10241b!important}
.sub,.hint,small,.subtle,.compliance-note{font-size:13.5px!important;color:#4a5750!important}
.regulatory-footer,.foot{font-size:13px!important;color:#4f5b55!important;line-height:1.45!important}
.header-block>p,.header-block * p,.header-block p.compliance-note,.header-block .compliance-note,#pgLabel,.dots{font-size:13.5px!important}
.page-head p,.page-head>p{font-size:13.5px!important;opacity:1!important}
table select{min-width:96px}
input:not([type=checkbox]):not([type=radio]):not([type=hidden]),select,textarea{font-size:16px!important;min-height:44px;line-height:1.3;max-width:100%;color:#14211a;border-color:#9aa8a0}
input::placeholder,textarea::placeholder{color:#6b7770;opacity:1}
textarea{min-height:88px}
input[type=checkbox],input[type=radio]{width:24px!important;height:24px!important;min-width:24px;min-height:24px;margin:0!important;flex:none;accent-color:#1f6e52;vertical-align:middle;position:static!important;float:none!important}
label:has(>input[type=checkbox]),label:has(>input[type=radio]),.vk-wrap,.vk-tap,.checkbox-item,.check-row,.check{display:flex!important;align-items:flex-start!important;gap:10px!important;min-height:44px;padding:10px 6px!important;margin:0!important;cursor:pointer;width:auto!important;text-transform:none!important;letter-spacing:normal!important;font-weight:500!important}
label:has(>input[type=checkbox])>input,label:has(>input[type=radio])>input,.vk-wrap>input,.vk-tap>input,.checkbox-item>input,.check-row>input{margin-top:-2px!important}
.checkbox-item>label{min-height:0!important;padding:0!important}
.opts,.checks,.choices,.likert{display:flex;flex-wrap:wrap;gap:4px 18px}
.opts br,.checks br{display:none}
td>label:has(>input[type=checkbox]){display:inline-flex!important;padding:6px!important}
.vk-table-scroll{overflow-x:auto;-webkit-overflow-scrolling:touch;margin:0 0 12px;border:1px solid #dfe5e1;border-radius:6px}
.vk-table-scroll table{margin:0!important;min-width:100%}
.vk-table-scroll td input:not([type=checkbox]):not([type=radio]){min-width:72px}
.vk-table-scroll td input[type=time]{min-width:112px}
.vk-legacy-sig{display:none!important}
button{min-height:44px;font-size:15px}
.nav{position:static!important}
.vk-invalid{border-color:#c0392b!important;background:#fff7f6!important;outline:2px solid #f2b8b0}
.vk-pages{display:flex;flex-wrap:wrap;gap:6px;padding:12px 0}
.vk-pages button{border:1px solid #c9d3cd;background:#fff;border-radius:6px;padding:8px 12px;font-size:14px;color:#26332c}
.vk-pages button.on{background:#1f6e52;color:#fff;border-color:#1f6e52}
.vk-pages button[data-initials]::after{content:" · initials";font-weight:700}
.vk-initials{margin:18px 0 6px;padding:12px 14px;border:1px solid #c9d3cd;border-left:4px solid #1f6e52;border-radius:8px;background:#f7faf8;max-width:640px}
.vk-initials label{display:flex;flex-wrap:wrap;align-items:center;gap:8px 12px;font-size:15px;line-height:1.4;color:#1d2a23}
.vk-initials-who{font-weight:700;font-size:14px;color:#26332c}
input.vk-initials-input{width:96px!important;min-width:96px;min-height:44px;font-size:18px!important;font-weight:700;letter-spacing:.08em;text-transform:uppercase;text-align:center;border:1.5px solid #6d7d74!important;border-radius:6px;background:#fff}
input.vk-initials-input:placeholder-shown{border-color:#b7791f!important;background:#fffaf0}
[data-vk-src]{box-shadow:inset 3px 0 0 #2f7d62;background-color:#f3faf6!important}
[data-vk-src="default"],[data-vk-src="voice"]{box-shadow:inset 3px 0 0 #c48a2b;background-color:#fff8e8!important}
[data-vk-src="carried"]{box-shadow:inset 3px 0 0 #3b6ea8;background-color:#f1f6fc!important}
[data-vk-src="calc"]{box-shadow:inset 3px 0 0 #6b5aa8;background-color:#f5f3fc!important}
input[type=checkbox][data-vk-src],input[type=radio][data-vk-src]{outline:3px solid #9fd0bb;outline-offset:1px}
input[type=checkbox][data-vk-src="default"],input[type=checkbox][data-vk-src="voice"]{outline-color:#e6c27a}
.vk-src{display:inline-flex;align-items:center;min-height:44px;margin:-6px 0 -14px;padding:0 2px;background:none;border:0;cursor:pointer;font:600 13px/1.3 system-ui,sans-serif;position:relative;z-index:1}
.vk-src>span{display:inline-block;color:#1f5c46;background:#e4f1ea;border:1px solid #bcd9ca;border-radius:999px;padding:3px 10px}
.vk-src[data-kind="default"]>span,.vk-src[data-kind="voice"]>span{color:#7a5414;background:#fbf0d9;border-color:#e6cf9f}
.vk-src[data-kind="carried"]>span{color:#24507f;background:#e7eff9;border-color:#bcd0ea}
.vk-src[data-kind="calc"]>span{color:#4b3d86;background:#efecfa;border-color:#cfc7ef}
.vk-src[data-confirmed="1"]>span{opacity:.8}
[style*="font-size:11px"],[style*="font-size: 11px"],[style*="font-size:12px"],[style*="font-size: 12px"],[style*="font-size:10px"],[style*="font-size: 10px"]{font-size:13.5px!important}
[style*="color:#718096"],[style*="color: #718096"],[style*="color:#95a5a6"],[style*="color:#7f8c8d"],[style*="color:#a0aec0"],[style*="color:#999"],[style*="color:#888"],[style*="color:#aaa"]{color:#4a5568!important}
button:disabled{opacity:1!important;color:#5f6b66!important;background:#eef1ef!important}
.vk-section-tools{display:flex;flex-wrap:wrap;gap:8px;margin:6px 0 10px}
.vk-section-tools button{min-height:44px;border-radius:8px;border:1px solid #1f6e52;background:#fff;color:#1f6e52;font:700 14px system-ui,sans-serif;padding:8px 14px;cursor:pointer}
.vk-section-tools button.vk-normal{background:#1f6e52;color:#fff}
.vk-section-tools .vk-done{font:600 13px system-ui,sans-serif;color:#1f5c46;align-self:center}
.vk-linked{border:1px solid #bcd0ea;background:#f1f6fc;border-radius:8px;padding:14px 16px;margin:8px 0 14px;font:15px/1.45 system-ui,sans-serif;color:#1c2a24}
.vk-linked b{color:#24507f}
.vk-collapsed{display:none!important}
.vk-seg{display:inline-flex;gap:4px;flex-wrap:nowrap}
.vk-seg button{min-width:44px;min-height:44px;border:1px solid #9aa8a0;background:#fff;border-radius:8px;font:700 16px system-ui,sans-serif;color:#26332c;cursor:pointer}
.vk-seg button.on{background:#1f6e52;color:#fff;border-color:#1f6e52}
.vk-total{font:800 18px system-ui,sans-serif;color:#10241b}
.vk-gate{margin-top:8px;font:700 14px system-ui,sans-serif;padding:8px 12px;border-radius:8px;display:inline-block}
.vk-gate.ok{background:#e4f1ea;color:#1f5c46}.vk-gate.no{background:#fbeeee;color:#8a2a2a}
:host([data-locked="1"]) input,:host([data-locked="1"]) select,:host([data-locked="1"]) textarea{pointer-events:none;background:#f6f7f6!important;color:#2a352f}
:host([data-locked="1"]) .vk-section-tools,:host([data-locked="1"]) .vk-seg button:not(.on){display:none}
@media (max-width:900px){.grid-4,.grid4{grid-template-columns:1fr 1fr!important}.grid-3,.grid3{grid-template-columns:1fr 1fr!important}}
@media (max-width:600px){.grid-2,.grid2,.grid-3,.grid3,.grid-4,.grid4{grid-template-columns:1fr!important}}
@media print{.vk-section-tools,.vk-src,.vk-pages{display:none!important}section.page{display:block!important}}
`;

/** Wrap wide tables so they scroll sideways instead of squeezing inputs below 44 px. */
export function wrapTables(root: ShadowRoot) {
  root.querySelectorAll('table').forEach(t => {
    if (!t.querySelector('input,select,textarea') || t.parentElement?.classList.contains('vk-table-scroll')) return;
    const w = document.createElement('div'); w.className = 'vk-table-scroll';
    t.parentNode!.insertBefore(w, t); w.appendChild(t);
  });
}
