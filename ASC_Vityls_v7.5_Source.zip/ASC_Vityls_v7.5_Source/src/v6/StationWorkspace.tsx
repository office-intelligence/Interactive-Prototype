import React, { useMemo, useState } from 'react';
import { ArrowLeft, FileText, CheckCircle2, Lock, ChevronDown, ChevronUp, UserRound, ShieldCheck, AlertTriangle } from 'lucide-react';
import type { PatientCase } from '../types';
import { VITYLS_FORM_CATALOG, isAssignedToWorkflow, WorkflowKey } from '../data/formWorkspaceCatalog';
import { STATIONS, STATION_PLAN, STATION_ROLES, NEXT_STATUS, ruleFor, StationKey } from './formRules';
import { repo, fmtDateTime, fmtTime, Actor, nowIso } from './dataLayer';
import { FormPage, FormItem } from './FormPage';
import { EventBar } from './EventBar';
import { slotState } from './SignaturePanel';
import { ALLERGY_STYLE, effectiveAllergy, parseAllergyList, type AllergyState } from '../v7/allergy';
import { stationPlan, allStationForms } from '../v7/myForms';
import { CaseRecordTable } from '../v7/CaseRecordTable';
import { OpsStrip } from '../v7/OpsStrip';

export const TEST_STAFF: Record<string, Actor> = {
  patientPortal: { name: 'Front Desk Tester', role: 'Front desk', credentials: '', kind: 'human' },
  frontOffice: { name: 'Front Desk Tester', role: 'Front desk', credentials: '', kind: 'human' },
  nursing: { name: 'Alex Rivera', role: 'Pre-op RN', credentials: 'RN', kind: 'human' },
  anesthesia: { name: 'Jordan Lee', role: 'Anesthesia', credentials: 'MD', kind: 'human' },
  surgeon: { name: 'Sam Patel', role: 'Surgeon', credentials: 'MD', kind: 'human' },
  orTeam: { name: 'Casey Morgan', role: 'Circulating RN', credentials: 'RN', kind: 'human' },
  pacu: { name: 'Taylor Brooks', role: 'PACU RN', credentials: 'RN', kind: 'human' },
  caseRecord: { name: 'Practice Administrator', role: 'Administrator', credentials: '', kind: 'human' },
  manager: { name: 'Pat Quinn', role: 'Practice Manager', credentials: '', kind: 'human' }, // v7.1 test actor for invoice overrides
};
const ROLE_OPTIONS = Array.from(new Map(Object.values(TEST_STAFF).map(a => [a.role, a])).values());

const catalogItem = (file: string): FormItem => { const c = VITYLS_FORM_CATALOG.find(f => f.file === file); return { title: c?.title || file.replace(/_/g, ' ').replace('.html', ''), file, category: c?.category || 'Form', stage: c?.stage || '' }; };

function formStatus(caseId: string, file: string, station?: WorkflowKey) {
  const rec = repo.getForm(caseId, file); const rule = ruleFor(file);
  const req = rule.signers.filter(s => s.required);
  const done = req.filter(s => rec.signatures.some(x => x.slotId === s.id));
  const mine = station ? rule.signers.filter(s => s.required && STATION_ROLES[station]?.test(s.role)) : [];
  const mineDone = mine.filter(s => rec.signatures.some(x => x.slotId === s.id));
  const missing = req.filter(s => !rec.signatures.some(x => x.slotId === s.id)).map(s => s.role);
  return { rec, req: req.length, done: done.length, mine: mine.length, mineDone: mineDone.length, missing };
}
const StatusPill: React.FC<{ s: ReturnType<typeof formStatus> }> = ({ s }) => s.rec.status === 'locked'
  ? <span className="v6-pill v6-pill-ok"><Lock size={14} /> Signed & locked</span>
  : s.rec.status === 'partially-signed' ? <span className="v6-pill v6-pill-warn">{s.done}/{s.req} signed · waiting: {s.missing.join(', ')}</span>
    : s.rec.status === 'draft' ? <span className="v6-pill">Draft saved {fmtTime(s.rec.updatedAt)}</span> : <span className="v6-pill v6-pill-muted">Not started</span>;

export const StationWorkspace: React.FC<{ patient: PatientCase; initial: WorkflowKey | 'caseRecord'; onBack: () => void; onAdvance?: (toStatus: string, reason?: string, unresolved?: string[]) => void; onUpdatePatient?: (p: PatientCase) => void }> = ({ patient, initial, onBack, onAdvance, onUpdatePatient }) => {
  const [station, setStationRaw] = useState<StationKey>(initial);
  const [active, setActive] = useState<FormItem | null>(null);
  const [showMore, setShowMore] = useState(false);
  const [actor, setActorState] = useState<Actor>(() => { const a = TEST_STAFF[initial] || repo.getActor(); repo.setActor(a); return a; });
  const [mineChecked, setMineChecked] = useState(false); const [exception, setException] = useState(''); const [askException, setAskException] = useState(false);
  const [editAllergy, setEditAllergy] = useState<string | null>(null); const [, force] = useState(0);
  const setStation = (s: StationKey) => { setStationRaw(s); const a = TEST_STAFF[s]; if (a) { repo.setActor(a); setActorState(a); } setMineChecked(false); setAskException(false); setShowMore(false); };
  const setActor = (a: Actor) => { repo.setActor(a); setActorState(a); };

  // v7: only forms in My Forms, at the stations chosen in Forms & Workflow.
  const plan = station !== 'caseRecord' ? stationPlan(station as WorkflowKey) : null;
  const extra: string[] = [];
  const facts = repo.getFacts(patient.id);
  const verifications = repo.getStationVerification(patient.id);

  if (active) return <FormPage patient={patient} form={active} station={station} onClose={() => { setActive(null); force(x => x + 1); }} />;

  const stationLabel = STATIONS.find(s => s.key === station)?.label || '';
  const required = plan?.required || [];
  const statuses = required.map(f => ({ file: f, s: formStatus(patient.id, f, station as WorkflowKey) }));
  const missingMine = statuses.filter(x => x.s.mine > x.s.mineDone).map(x => catalogItem(x.file).title);
  // v6 multi-provider sign-off: forms started at another station that now wait for a signer of this station's role.
  const cosign = station === 'caseRecord' ? [] : allStationForms().filter(f => !required.includes(f) && !(plan?.asNeeded || []).includes(f)).filter(f => {
    const rec = formStatus(patient.id, f, station as WorkflowKey).rec; const rule = ruleFor(f);
    if (rec.status === 'not-started' || rec.status === 'locked' || !rec.signatures.length) return false;
    return slotState(rule.signers, rec, rule.sequential).some(x => !x.sig && !x.blocker && x.slot.required && STATION_ROLES[station as WorkflowKey].test(x.slot.role));
  });
  const verified = verifications[station];
  const canVerify = station !== 'patientPortal' && station !== 'caseRecord';

  const verify = (reason?: string) => {
    const v = { by: actor.name, role: actor.role, at: nowIso() };
    repo.setStationVerification(patient.id, station, v);
    repo.audit({ caseId: patient.id, user: actor.name, role: actor.role, action: 'station.verify', detail: `${stationLabel} verified${reason ? ` with exception: ${reason} (open: ${missingMine.join(', ')})` : ''}` });
    const next = NEXT_STATUS[station as WorkflowKey]; if (next) onAdvance?.(next, reason, reason ? missingMine : []);
    setAskException(false); setException(''); force(x => x + 1);
  };
  const confirmFact = (label: string, value: string) => { repo.audit({ caseId: patient.id, user: actor.name, role: actor.role, action: 'fact.confirm', detail: `${label} confirmed at ${stationLabel}: ${value}` }); force(x => x + 1); };

  const FormRow: React.FC<{ file: string; requiredForm?: boolean }> = ({ file, requiredForm }) => { const it = catalogItem(file); const s = formStatus(patient.id, file, station as WorkflowKey); const rule = ruleFor(file);
    return <li className="p-3 sm:p-4 flex flex-wrap items-center justify-between gap-3">
      <div className="min-w-0 flex-1"><div className="flex items-center gap-2 flex-wrap"><b className="text-[16px]">{it.title}</b>{requiredForm && <span className="text-[13px] font-bold uppercase tracking-wide text-[#1f5c46] bg-[#e4f1ea] px-2 py-0.5 rounded">For this case</span>}</div>
        <div className="text-[14px] text-[#4a5750] mt-1 flex flex-wrap gap-2 items-center"><StatusPill s={s} /><span>{rule.signers.length ? `Signers: ${rule.signers.map(x => x.role + (x.required ? '' : ' (opt.)')).join(' → ')}` : 'No signature'}</span></div></div>
      <button onClick={() => setActive(it)} className="v6-btn v6-btn-primary" data-testid={`open-${file}`}><FileText size={18} /> {s.rec.status === 'locked' ? 'View' : s.rec.status === 'not-started' ? 'Open' : 'Continue'}</button>
    </li>; };

  return <div className="max-w-7xl mx-auto space-y-4 pb-28 v6-scope" data-testid="v6-station">
    <section className="bg-white border border-[#d9e0db] rounded-lg overflow-hidden">
      <div className="bg-[#124f3b] text-white px-4 sm:px-5 py-3 flex flex-wrap items-center gap-3 justify-between">
        <div className="min-w-0"><div className="text-[13px] uppercase tracking-[.1em] opacity-90 font-bold">Day of surgery · {stationLabel}</div>
          <div className="text-[20px] font-bold truncate" data-testid="v6-station-patient">{patient.name}</div>
          <div className="text-[14px] opacity-95">DOB {patient.dob || 'not documented'} · MRN {patient.patientId} · {patient.procedure}</div></div>
        <label className="flex items-center gap-2 text-[14px] bg-white/10 rounded-lg px-3 min-h-[44px]"><UserRound size={18} /> Acting as
          <select value={actor.role} onChange={e => setActor(ROLE_OPTIONS.find(a => a.role === e.target.value) || actor)} className="bg-transparent text-white font-bold text-[15px] min-h-[44px] outline-none" aria-label="Acting user (test build)">
            {ROLE_OPTIONS.map(a => <option key={a.role} value={a.role} className="text-black">{a.name} · {a.role}</option>)}</select></label>
      </div>
      <nav className="grid grid-cols-4 lg:grid-cols-8 border-b border-[#d9e0db]" aria-label="Stations">
        {STATIONS.map(s => { const v = verifications[s.key]; return <button key={s.key} onClick={() => setStation(s.key)} data-testid={`tab-${s.key}`} className={`min-h-[52px] px-2 py-2 text-[14px] font-bold border-b-[3px] leading-tight ${s.key === station ? 'border-[#1f6e52] text-[#10241b] bg-[#f3faf6]' : 'border-transparent text-[#3f4c45]'}`}>{s.label}{v && <CheckCircle2 size={14} className="inline ml-1 text-[#1f6e52]" />}</button>; })}
      </nav>
      <div className="px-4 py-2 flex items-center gap-3 flex-wrap"><button onClick={onBack} className="v6-btn v6-btn-secondary"><ArrowLeft size={18} /> Back to chart</button>
        {verified && <span className="text-[14px] text-[#1f5c46]"><ShieldCheck size={16} className="inline" /> Station verified by {verified.by} ({verified.role}) · {fmtDateTime(verified.at)}</span>}
        <span className="text-[13.5px] text-[#4a5750]">Test build: “Acting as” stands in for a real login; signatures use the name you enter.</span></div>
    </section>

    <OpsStrip patient={patient} station={station} />
    {station === 'caseRecord' ? <CaseRecordTable patient={patient} actor={actor.name} actorRole={actor.role} onOpen={f => setActive(catalogItem(f))} /> : <>
      {station === 'orTeam' && <EventBar caseId={patient.id} />}
      <section className="bg-white border border-[#d9e0db] rounded-lg overflow-hidden">
        <div className="p-4 sm:px-5 border-b border-[#d9e0db]"><h2 className="text-[20px] font-bold">Forms for this case</h2><p className="text-[14px] text-[#4a5750] mt-0.5">Prefilled from the case and earlier stations. Open, confirm what’s amber, add what’s new, then sign.</p></div>
        <ul className="divide-y divide-[#e3e8e5]">{required.map(f => <FormRow key={f} file={f} requiredForm />)}</ul>
        {required.length === 0 && (plan?.asNeeded.length || 0) === 0 && cosign.length === 0 && <div className="p-5 text-[15px] text-[#3a463f]" data-testid="station-empty"><b>No forms at this station yet.</b> Stations show only forms in <b>My Forms</b>. Add forms in Practice → Forms &amp; Workflow → Form Library → Add to My Forms, choose this station and set the signers.</div>}
        {cosign.length > 0 && <div className="border-t-2 border-[#e6cf9f] bg-[#fffaf0]"><div className="px-4 sm:px-5 pt-3 text-[15px] font-bold text-[#6b4a10]">Waiting for your co-signature ({cosign.length})</div><ul className="divide-y divide-[#efe2c4]">{cosign.map(f => <FormRow key={'c' + f} file={f} />)}</ul></div>}
        {(plan!.asNeeded.length + extra.length) > 0 && <div className="border-t border-[#d9e0db]"><button onClick={() => setShowMore(x => !x)} className="w-full min-h-[52px] px-4 sm:px-5 text-left text-[15px] font-bold flex items-center justify-between" data-testid="as-needed-toggle">As needed ({plan!.asNeeded.length + extra.length}) — reviews, co-signatures, transfer, AMA {showMore ? <ChevronUp /> : <ChevronDown />}</button>
          {showMore && <ul className="divide-y divide-[#e3e8e5] border-t border-[#e3e8e5]">{[...plan!.asNeeded, ...extra].map(f => <FormRow key={f} file={f} />)}</ul>}</div>}
      </section>

      <section className="bg-white border border-[#d9e0db] rounded-lg p-4 sm:p-5">
        <h2 className="text-[18px] font-bold">Known clinical facts</h2><p className="text-[14px] text-[#4a5750] mt-0.5">Collected once and carried to every form. Confirm or Edit instead of re-entering.</p>
        <div className="mt-3 grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {(() => { const ea = effectiveAllergy(patient.allergies, patient.id); const display = ea.state === 'not-reported' ? 'Not Reported — ask and record' : ea.pendingConfirm ? `${ea.text} — confirm` : ea.text; const src = ea.pendingConfirm && ea.sourceForm ? ea.sourceForm : undefined; return <FactCard label="Allergies" allergy={ea.state} value={display} source={src} sourceNote={ea.pendingConfirm ? 'Patient-reported · confirm or Edit' : undefined}
            onConfirm={() => { const list = ea.pendingConfirm ? ea.rawList : (patient.allergies?.length ? patient.allergies : ea.rawList); if (onUpdatePatient && list.length) onUpdatePatient({ ...patient, allergies: list }); confirmFact('Allergies', list.join(', ') || ea.text || 'not documented'); }}
            onEdit={onUpdatePatient ? () => setEditAllergy(ea.state === 'not-reported' && !ea.pendingConfirm ? '' : (patient.allergies?.join(', ') || ea.rawList.join(', ') || ea.text)) : undefined} />; })()}
          <FactCard label="Procedure / surgeon" value={`${patient.procedure} · ${patient.surgeon || 'Surgeon not assigned'}`} onConfirm={() => confirmFact('Procedure', patient.procedure)} />
          <FactCard label="NPO (solids / clears)" value={facts['npo.solid'] || facts['npo.clear'] ? `${facts['npo.solid']?.value || '—'} / ${facts['npo.clear']?.value || '—'}` : 'Not yet recorded (Nursing Admission)'} source={facts['npo.solid']?.source.formTitle} />
          <FactCard label="Responsible adult / driver" value={(facts['adult.driver']?.value as string) || 'Not yet recorded'} source={facts['adult.driver']?.source.formTitle} />
          <FactCard label="ASA class" value={(facts['case.asa']?.value as string) || 'Not yet recorded (Anesthesia)'} source={facts['case.asa']?.source.formTitle} />
          <FactCard label="EBL / wound class" value={facts['case.ebl'] ? `${facts['case.ebl'].value} mL · class ${facts['case.woundClass']?.value || '—'}` : 'Not yet recorded (OR)'} source={facts['case.ebl']?.source.formTitle} />
        </div>
        {editAllergy !== null && <div className="mt-3 flex flex-wrap gap-2 items-end"><label className="v6-field flex-1">Allergies (comma-separated; NKDA or leave blank = not documented)<input className="v6-input" value={editAllergy} onChange={e => setEditAllergy(e.target.value)} data-testid="allergy-edit-input" /></label><button className="v6-btn v6-btn-primary" data-testid="allergy-edit-save" onClick={() => { const list = parseAllergyList(editAllergy); onUpdatePatient?.({ ...patient, allergies: list }); repo.audit({ caseId: patient.id, user: actor.name, role: actor.role, action: 'fact.edit', detail: `Allergies edited at ${stationLabel}: ${list.join(', ') || 'not documented'}` }); setEditAllergy(null); }}>Save</button><button className="v6-btn v6-btn-secondary" onClick={() => setEditAllergy(null)}>Cancel</button></div>}
      </section>

      {canVerify && <section className="sticky bottom-[calc(76px+env(safe-area-inset-bottom))] z-10 bg-white border-2 border-[#1f6e52] rounded-lg p-3 sm:p-4 flex flex-wrap items-center gap-3 shadow-lg" data-testid="verify-bar">
        <label className="flex gap-3 items-center text-[15px] min-h-[44px] flex-1 min-w-[220px] cursor-pointer"><input type="checkbox" checked={mineChecked} onChange={e => setMineChecked(e.target.checked)} className="w-6 h-6 accent-[#1f6e52] flex-none" /> I reviewed this station and it is mine ({actor.name}, {actor.role}).</label>
        {missingMine.length > 0 && <span className="text-[14px] text-[#7a5414] flex items-center gap-1"><AlertTriangle size={16} /> Unsigned here: {missingMine.join(', ')}</span>}
        {askException ? <div className="flex flex-wrap gap-2 w-full"><input className="v6-input flex-1" placeholder="Reason for advancing with open items" value={exception} onChange={e => setException(e.target.value)} /><button disabled={exception.trim().length < 4} onClick={() => verify(exception.trim())} className="v6-btn v6-btn-primary disabled:opacity-40">Advance with exception</button><button onClick={() => setAskException(false)} className="v6-btn v6-btn-secondary">Cancel</button></div>
          : <button disabled={!mineChecked} onClick={() => missingMine.length ? setAskException(true) : verify()} className="v6-btn v6-btn-primary disabled:opacity-40" data-testid="verify-station"><CheckCircle2 size={18} /> Save & verify station</button>}
      </section>}
    </>}
  </div>;
};

const FactCard: React.FC<{ label: string; value: string; source?: string; sourceNote?: string; warn?: boolean; allergy?: AllergyState; onConfirm?: () => void; onEdit?: () => void }> = ({ label, value, source, sourceNote, warn, allergy, onConfirm, onEdit }) =>
  <div className={`border rounded-lg p-3 ${allergy ? ALLERGY_STYLE[allergy].box : warn ? 'border-[#e6cf9f] bg-[#fffaf0]' : 'border-[#dfe5e1]'}`} data-allergy-state={allergy} data-testid={allergy ? 'fact-allergies' : undefined}><div className="text-[13px] font-bold uppercase tracking-wide text-[#4a5750]">{label}</div><div className={`text-[16px] font-semibold mt-1 ${allergy ? ALLERGY_STYLE[allergy].text : ''}`}>{value}</div>{source && <div className="text-[13.5px] text-[#24507f] mt-1">From {source}</div>}{sourceNote && <div className="text-[13px] text-[#39443E] mt-0.5">{sourceNote}</div>}
    {(onConfirm || onEdit) && <div className="flex gap-2 mt-2">{onConfirm && <button type="button" onClick={onConfirm} className="v6-btn vy-btn-confirm" data-testid="allergy-confirm">Confirm</button>}{onEdit && <button type="button" onClick={onEdit} className="v6-btn vy-btn-edit" data-testid="allergy-edit">Edit</button>}</div>}</div>;

const CaseRecord: React.FC<{ patient: PatientCase; onOpen: (file: string) => void }> = ({ patient, onOpen }) => {
  const files = allStationForms();
  const audit = repo.getAudit(patient.id).slice().reverse();
  const rows = files.map(f => ({ f, s: formStatus(patient.id, f) }));
  const open = rows.filter(r => r.s.rec.status !== 'locked');
  return <div className="space-y-4" data-testid="case-record">
    <section className="bg-white border border-[#d9e0db] rounded-lg overflow-hidden">
      <div className="p-4 sm:px-5 border-b"><h2 className="text-[20px] font-bold">Case record</h2><p className="text-[14px] text-[#4a5750]">{rows.length - open.length} of {rows.length} documents signed and locked. Missing signatures are listed per document.</p></div>
      <ul className="divide-y divide-[#e3e8e5]">{rows.map(({ f, s }) => <li key={f} className="p-3 sm:px-5 flex flex-wrap gap-3 items-center justify-between"><div className="min-w-0"><b className="text-[16px]">{catalogItem(f).title}</b><div className="text-[14px] text-[#4a5750] mt-1 flex gap-2 flex-wrap items-center"><StatusPill s={s} />{s.rec.lockedHash && <span>fingerprint {s.rec.lockedHash.slice(0, 8)}</span>}{s.rec.addenda.length > 0 && <span>{s.rec.addenda.length} addend{s.rec.addenda.length > 1 ? 'a' : 'um'}</span>}{s.missing.length > 0 && s.rec.status !== 'locked' && <span className="text-[#7a5414]">Needs: {s.missing.join(', ')}</span>}</div></div><button className="v6-btn v6-btn-secondary" onClick={() => onOpen(f)}>Open</button></li>)}</ul>
    </section>
    <section className="bg-white border border-[#d9e0db] rounded-lg p-4 sm:p-5"><h2 className="text-[18px] font-bold">Audit trail ({audit.length})</h2><p className="text-[14px] text-[#4a5750]">Append-only in this test build (browser storage). The backend must keep it server-side with server time.</p>
      <ol className="mt-3 space-y-1 max-h-[60vh] overflow-y-auto">{audit.slice(0, 300).map(a => <li key={a.id} className="text-[14px] border-b border-[#eef2ef] py-1.5"><b>{fmtDateTime(a.at)}</b> · {a.user} ({a.role}) · <span className="font-semibold">{a.action}</span>{a.form ? ` · ${catalogItem(a.form).title}` : ''} — {a.detail}</li>)}{!audit.length && <li className="text-[14px]">No activity yet.</li>}</ol></section>
  </div>;
};
