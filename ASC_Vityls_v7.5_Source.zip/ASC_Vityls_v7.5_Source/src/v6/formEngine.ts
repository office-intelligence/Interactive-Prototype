/*
 * Mounts a form template into a Shadow DOM host and wires: prefill from the case,
 * carry-forward facts, defaults, "All normal" shortcuts, auto-calculations,
 * provenance chips, confirmation, locking, and value collection by stable key.
 */
import type { PatientCase } from '../types';
import { FieldInfo, Ctl, OVERRIDE_CSS, SECTION_SELECTOR, prepareTemplate, indexFields, getVal, setVal, isEmpty, applyKeyboardHints, formatBp, makeRowsTappable, setupPaging, hideLegacySignatures, wrapTables, slug } from './formEnhancer';
import { CaseContext, caseContext, conceptFor, Concept, PMH, PMH_SECTION, ruleFor, FormRule, nowHHMM, FORM_RULES } from './formRules';
import { repo, Fact, FieldValue, FormRecord, Provenance, SourceKind, fmtTime, nowIso, Actor } from './dataLayer';

export interface MountOptions {
  host: HTMLElement; file: string; title: string; patient: PatientCase; station: string; html: string;
  onDirty: () => void; onShowSource: (p: Provenance, label: string) => void; onChange?: () => void;
}
export interface FormController {
  fields: FieldInfo[]; record: FormRecord; prov: Record<string, Provenance>; rule: FormRule; ctx: CaseContext;
  collect(): { values: Record<string, FieldValue>; labels: Record<string, string> };
  facts(actor: Actor, formTitle: string): Fact[];
  unconfirmed(): FieldInfo[];
  confirmAll(): number;
  applyValue(key: string, value: FieldValue, p: Provenance): void;
  applyLocks(rec: FormRecord): void;
  sections(): string[];
  stats(): { total: number; filled: number; byKind: Record<string, number> };
  /** multi-page packets: page state (null for single-page forms) */
  paging: { count: number; index: () => number; titles: string[]; go: (n: number, scroll?: boolean) => void } | null;
  /** per-page initials fields and which signer slot they belong to */
  initials(): { key: string; slot: string; page: string; pageIndex: number; value: string }[];
}

const KIND_LABEL: Record<SourceKind, string> = { case: 'From case', carried: 'Carried', default: 'Default — confirm', normal: 'All normal', calc: 'Calculated', voice: 'Voice — reviewed', event: 'Event time', manual: 'Entered' };

function chipFor(f: FieldInfo, p: Provenance, onClick: () => void) {
  const host = f.el.getRootNode() as ShadowRoot;
  host.querySelectorAll(`.vk-src[data-for="${CSS.escape(f.key)}"]`).forEach(n => n.remove());
  const chip = document.createElement('button');
  chip.type = 'button'; chip.className = 'vk-src'; chip.dataset.for = f.key; chip.dataset.kind = p.kind;
  if (p.confirmed) chip.dataset.confirmed = '1';
  const pending = (p.kind === 'default' || p.needsConfirm) && !p.confirmed;
  const pill = document.createElement('span'); chip.appendChild(pill);
  pill.textContent = `${p.kind === 'carried' ? 'Carried · ' + p.label : KIND_LABEL[p.kind]}${pending && p.kind !== 'default' ? ' — confirm' : ''}${p.confirmed ? ' ✓' : ''}`;
  chip.title = `${KIND_LABEL[p.kind]}: ${p.label}${p.snippet ? ` — “${p.snippet}”` : ''}`;
  chip.onclick = (e) => { e.preventDefault(); e.stopPropagation(); onClick(); };
  const isBox = f.el instanceof HTMLInputElement && (f.el.type === 'checkbox' || f.el.type === 'radio');
  const anchor = isBox ? (f.el.closest('label,.vk-tap') || f.el) : f.el;
  if (isBox && anchor !== f.el) anchor.appendChild(chip); else anchor.insertAdjacentElement('afterend', chip);
}
function markField(f: FieldInfo, p: Provenance | undefined) {
  if (p) f.el.dataset.vkSrc = (p.kind === 'carried' && p.needsConfirm && !p.confirmed) ? 'default' : p.kind; else delete f.el.dataset.vkSrc;
}

export function headingElements(root: ShadowRoot): HTMLElement[] {
  return Array.from(root.querySelectorAll<HTMLElement>(SECTION_SELECTOR)).filter(h => !h.closest('.vk-legacy-sig') && (h.textContent || '').trim());
}

/** Controls that sit between a heading and the next heading, in document order. */
function controlsUnder(root: ShadowRoot, heading: HTMLElement): Ctl[] {
  const all = Array.from(root.querySelectorAll<HTMLElement>(`${SECTION_SELECTOR}, input, select, textarea`));
  const i = all.indexOf(heading); const out: Ctl[] = [];
  for (let j = i + 1; j < all.length; j++) { if (!all[j].matches('input,select,textarea')) break; out.push(all[j] as Ctl); }
  return out;
}

function parseHeightIn(s: string): number | null {
  const t = s.toLowerCase().replace(/\s+/g, ' ').trim(); if (!t) return null;
  let m = t.match(/(\d)\s*(?:'|ft|foot|feet)\s*(\d{1,2})?/); if (m) return Number(m[1]) * 12 + Number(m[2] || 0);
  m = t.match(/([\d.]+)\s*cm/); if (m) return Number(m[1]) / 2.54;
  m = t.match(/([\d.]+)\s*(in|")/); if (m) return Number(m[1]);
  const n = Number(t); if (!isNaN(n)) return n > 100 ? n / 2.54 : n; return null;
}
function parseWeightLb(s: string): number | null {
  const t = s.toLowerCase().trim(); if (!t) return null;
  let m = t.match(/([\d.]+)\s*kg/); if (m) return Number(m[1]) * 2.20462;
  m = t.match(/([\d.]+)/); return m ? Number(m[1]) : null;
}

/* Multi-page packets: a compact initials field on pages that need one, bound to a signer slot (never a full signature). */
function addInitials(root: ShadowRoot, rule: FormRule, file = '') {
  (rule.initials || []).forEach((spec, n) => {
    const all = Array.from(root.querySelectorAll<HTMLElement>('section.page'));
    const page = (spec.pageIndex != null && all[spec.pageIndex]) || all.find(p => spec.page.test(p.dataset.title || ''));
    if (!page) return;
    if (spec.existing) {
      const found = Array.from(page.querySelectorAll<HTMLInputElement>('input')).filter(inp => /^initials?$/i.test(inp.placeholder || ''));
      found.forEach((inp, k) => {
        inp.dataset.vkInitials = spec.slot; inp.name = inp.name || `initials-p${n}-${k}`; inp.maxLength = 5; inp.autocomplete = 'off';
        inp.setAttribute('autocapitalize', 'characters'); inp.classList.add('vk-initials-input'); inp.removeAttribute('style'); inp.placeholder = 'Initials';
      });
      if (found.length) return; // a practice's own custom template may still carry initials lines
    }
    // v7.4: initials come from Signer setup. One initials box per statement line (e.g. the two cash-fee clauses).
    const fallback = FORM_RULES[file]?.initials?.find(x => x.slot === spec.slot && x.page.test(page.dataset.title || ''))?.statement;
    const lines = String(spec.statement || fallback || 'Initials').split(/\n+/).map(x => x.trim()).filter(Boolean);
    const who = escapeHtml((rule.signers.find(x => x.id === spec.slot)?.role || 'Signer') + ' initials');
    const box = document.createElement('div'); box.className = 'vk-initials';
    box.innerHTML = lines.map((l, k) => `<label${k ? ' style="margin-top:10px"' : ''}>${escapeHtml(l)} <span class="vk-initials-who">${who}</span><input name="${lines.length > 1 ? `initials-p${n}-${k}` : `initials-p${n}`}" data-vk-initials="${escapeHtml(spec.slot)}" class="vk-initials-input" maxlength="5" autocomplete="off" autocapitalize="characters" placeholder="Initials"></label>`).join('');
    const legacy = page.querySelector('.vk-legacy-sig'); if (legacy) legacy.insertAdjacentElement('beforebegin', box); else page.appendChild(box);
  });
}

export function mountForm(o: MountOptions): FormController {
  const root = o.host.shadowRoot || o.host.attachShadow({ mode: 'open' });
  const t = prepareTemplate(o.html);
  root.innerHTML = `<style>${t.css}</style><style>${OVERRIDE_CSS}</style><div class="vk-root">${t.body}</div>`;
  const rule = ruleFor(o.file); const ctx = caseContext(o.patient);
  const record = repo.getForm(o.patient.id, o.file);
  const facts = repo.getFacts(o.patient.id);
  const prov: Record<string, Provenance> = { ...(record.provenance || {}) };
  const actor = repo.getActor();

  // 1. the patient strip shows the OPEN patient (wrong-patient fix)
  root.querySelectorAll<HTMLElement>('.who, .vityls-patient-header').forEach(w => {
    w.innerHTML = `<strong>${escapeHtml(ctx.name)}</strong> · DOB ${escapeHtml(ctx.dob || 'not documented')}${ctx.age ? ` · Age ${escapeHtml(ctx.age)}` : ''} · MRN ${escapeHtml(ctx.mrn)}${ctx.procedure ? ` · ${escapeHtml(ctx.procedure)}` : ''} · DOS ${escapeHtml(ctx.dateUs)}`;
    w.dataset.vkBound = 'patient';
  });
  hideLegacySignatures(root); addInitials(root, rule, o.file); wrapTables(root); makeRowsTappable(root);
  let pageIndex = 0;
  const pager = setupPaging(root, (i) => { pageIndex = i; o.onChange?.(); });
  const pageTitles = Array.from(root.querySelectorAll<HTMLElement>('section.page')).map(p => p.dataset.title || 'Page');

  // 2. de-duplicated time-out: recorded once in the Universal Protocol checklist
  if (rule.linkedTimeout) {
    const h = headingElements(root).find(x => /time-out/i.test(x.textContent || ''));
    if (h) {
      const ctls = controlsUnder(root, h);
      ctls.forEach(c => {
        const lbl = (c.closest('label')?.textContent || c.closest('.fg,.form-group')?.textContent || '').trim();
        if (/antibiotic agent|antibiotic infusion/i.test(lbl)) return;
        const box = c.closest<HTMLElement>('label,.vk-tap,.checkbox-item,.check-row,.fg,.form-group') || c;
        box.classList.add('vk-collapsed', 'vk-ignore');
      });
      root.querySelectorAll<HTMLElement>('.checks,.col').forEach(el => { if (el.querySelectorAll('input').length && !el.querySelector('input:not(.vk-ignore input)') && Array.from(el.querySelectorAll('input')).every(i => i.closest('.vk-ignore'))) el.classList.add('vk-collapsed'); });
      const up = repo.getForm(o.patient.id, 'Universal_Protocol_Safety_Checklist.html');
      const tKeys = Object.keys(up.values).filter(k => k.startsWith('t::'));
      const done = tKeys.filter(k => up.values[k] === true).length;
      const card = document.createElement('div'); card.className = 'vk-linked vk-ignore';
      const tt = up.values['timeoutTime'] as string; const who = up.values['timeoutLeader'] as string;
      card.innerHTML = done
        ? `<b>Time-out recorded once — Universal Protocol Safety Checklist.</b><br>${done} of ${Math.max(tKeys.length, done)} items confirmed${tt ? ` at <b>${escapeHtml(tt)}</b>` : ''}${who ? ` by ${escapeHtml(who)}` : ''}. ${up.signatures.length ? `Signed by ${up.signatures.map(s => escapeHtml(s.role)).join(', ')}.` : 'Awaiting team signatures.'}<br><span style="font-size:13px;color:#4a5750">To change it, open the Universal Protocol checklist. It is no longer entered twice.</span>`
        : `<b>Time-out is documented once, in the Universal Protocol Safety Checklist.</b><br>Not yet recorded for this case. Open the checklist from the OR Team station and tap “Time-out complete”. It will show here automatically.`;
      h.insertAdjacentElement('afterend', card);
    }
  }

  // 3. Aldrete: 15 typed boxes → tap choices with an automatic total
  if (rule.aldrete) setupAldrete(root);

  const fields = indexFields(root);
  const byKey = new Map(fields.map(f => [f.key, f]));
  const concepts = new Map<string, Concept>();
  const pmhIds = new Map<string, string>();
  fields.forEach(f => {
    const c = conceptFor(f.label, f.el.getAttribute('name') || '', f.type, f.inTable); if (c) concepts.set(f.key, c);
    if ((f.type === 'checkbox') && PMH_SECTION.test(f.section)) { const p = PMH.find(x => x.re.test(f.label)); if (p) pmhIds.set(f.key, p.id); }
  });

  // 4. restore saved values (by stable key, never by position)
  Object.entries(record.values || {}).forEach(([k, v]) => { const f = byKey.get(k); if (f) setVal(f.el, v); });

  const locked = record.status === 'locked';
  const setP = (f: FieldInfo, p: Provenance) => { prov[f.key] = p; };
  const sourceLabel = (fact: Fact) => `${fact.source.formTitle || fact.source.label}${fact.source.by ? ' · ' + fact.source.by : ''}${fact.source.at ? ' · ' + fmtTime(fact.source.at) : ''}`;

  if (!locked) {
    // 5. carry-forward, case prefill, PMH, defaults — only into empty fields
    fields.forEach(f => {
      if (!isEmpty(f.el)) return;
      const c = concepts.get(f.key);
      if (c) {
        let fact = facts[c.id];
        if (!fact && c.id === 'pacu.admitTime') fact = facts['time.handoff'] || facts['time.outOR'];
        if (!fact && c.id === 'team.nurses' && (facts['team.scrub'] || facts['team.circulator'])) {
          const v = [facts['team.scrub']?.value, facts['team.circulator']?.value].filter(Boolean).join(' / ');
          fact = { concept: c.id, value: v, source: { ...(facts['team.circulator'] || facts['team.scrub'])!.source } };
        }
        if (fact && fact.value !== '' && fact.source.form !== o.file) {
          setVal(f.el, fact.value);
          if (!isEmpty(f.el)) { setP(f, { kind: fact.source.kind === 'event' ? 'event' : 'carried', label: sourceLabel(fact), at: fact.source.at, by: fact.source.by, snippet: fact.source.snippet, needsConfirm: !!c.needsConfirm }); return; }
        }
        const v = c.fromCase?.(ctx);
        if (v) { setVal(f.el, f.el instanceof HTMLInputElement && f.el.type === 'date' ? ctx.dateIso && c.id === 'case.date' ? ctx.dateIso : v : v); if (!isEmpty(f.el)) { setP(f, { kind: 'case', label: c.id === 'case.allergies' || c.id === 'case.meds' ? 'Patient chart' : 'Booked case / patient record', at: nowIso(), needsConfirm: !!c.needsConfirm }); return; } }
      }
      const pid = pmhIds.get(f.key);
      if (pid) {
        const fact = facts[`pmh.${pid}`] || (ctx.pmh.some(x => PMH.find(p => p.id === pid)?.re.test(x)) ? { concept: `pmh.${pid}`, value: true, source: { kind: 'case', label: 'Patient chart', at: nowIso() } } as Fact : undefined);
        if (fact && fact.value === true && fact.source.form !== o.file) { setVal(f.el, true); setP(f, { kind: 'carried', label: `Patient-reported · ${sourceLabel(fact)}`, at: fact.source.at, needsConfirm: true }); return; }
      }
    });
    // anesthesia technique checkboxes from the booked anesthesia type
    if (ctx.anesType) fields.filter(f => f.type === 'checkbox' && /anesthesia type|technique/i.test(f.section) && isEmpty(f.el)).forEach(f => {
      const want = /general/i.test(ctx.anesType) ? /^general( anesthesia)?$/i : /mac|sedation/i.test(ctx.anesType) ? /^mac/i : /local/i.test(ctx.anesType) ? /^local/i : /regional|block|spinal/i.test(ctx.anesType) ? /^regional/i : null;
      if (want && want.test(f.label) && !Object.values(record.values || {}).length) { setVal(f.el, true); setP(f, { kind: 'case', label: `Booked anesthesia type: ${ctx.anesType}`, at: nowIso() }); }
    });
    (rule.defaults || []).forEach(d => fields.filter(f => d.label.test(f.label) && (!d.section || d.section.test(f.section)) && isEmpty(f.el) && !f.inTable).forEach(f => {
      setVal(f.el, typeof d.value === 'function' ? d.value(ctx) : d.value);
      if (!isEmpty(f.el)) setP(f, { kind: 'default', label: 'Practice default (example — medical director to approve)', at: nowIso(), needsConfirm: true });
    }));
    if (rule.chartChecks) chartChecks(fields, o.patient.id, facts, setP);
  }

  // 6. auto-calculations
  const recalc = () => {
    if (rule.aldrete) aldreteTotals(root, fields, prov);
    if (rule.vte) vteTotal(root, fields, prov);
    if (rule.bmi) bmiCalc(fields, prov);
    if (rule.pacuLos) pacuLos(fields, prov);
    fields.forEach(f => { const p = prov[f.key]; markField(f, p); if (p && p.kind !== 'manual') chipFor(f, p, () => o.onShowSource(p, f.label)); else root.querySelectorAll(`.vk-src[data-for="${CSS.escape(f.key)}"]`).forEach(n => n.remove()); });
  };
  applyKeyboardHints(fields);
  root.addEventListener('focusout', (e) => { const el = e.target as HTMLInputElement; if (el?.dataset?.vkBp) formatBp(el); }, true);
  root.addEventListener('focusin', (e) => {
    const el = e.target as HTMLElement; if (!el.matches?.('input,select,textarea')) return;
    // keep the focused field visible above the on-screen keyboard
    setTimeout(() => el.scrollIntoView({ block: 'center', behavior: 'smooth' }), 250);
  });
  const onUser = (e: Event) => {
    const el = e.target as Ctl; const key = el?.dataset?.vk; if (!key) return;
    if (prov[key] && prov[key].kind !== 'calc') delete prov[key];
    if (el instanceof HTMLInputElement && el.type === 'radio' && el.name) fields.filter(f => f.group === el.name).forEach(f => { if (prov[f.key]?.kind !== 'calc') delete prov[f.key]; });
    recalc(); o.onDirty(); o.onChange?.();
  };
  root.addEventListener('input', onUser); root.addEventListener('change', onUser);
  // tap anywhere on a label-less checkbox row
  root.addEventListener('click', (e) => {
    const target = e.target as HTMLElement; const row = target.closest?.('.vk-tap') as HTMLElement | null;
    if (!row || target.matches('input,select,textarea,button,a,label')) return;
    const cb = row.querySelector<HTMLInputElement>('input[type=checkbox],input[type=radio]'); if (!cb || cb.disabled) return;
    cb.checked = cb.type === 'radio' ? true : !cb.checked; cb.dispatchEvent(new Event('change', { bubbles: true }));
  });

  // 7. section shortcut bars ("All normal", "Confirm")
  const ctl: FormController = {
    fields, record, prov, rule, ctx,
    collect() {
      const values: Record<string, FieldValue> = {}; const labels: Record<string, string> = {};
      fields.forEach(f => { if (f.el.closest('.vk-ignore')) return; values[f.key] = getVal(f.el); labels[f.key] = f.label; });
      return { values, labels };
    },
    facts(a, formTitle) {
      const out: Fact[] = []; const at = nowIso();
      fields.forEach(f => {
        if (f.el.closest('.vk-ignore')) return;
        const c = concepts.get(f.key); const v = getVal(f.el);
        const p = prov[f.key];
        if (p && (p.kind === 'carried' || p.kind === 'event' || p.kind === 'case')) return; // don't re-publish what we received
        if (c?.carry && v !== '' && v !== false) out.push({ concept: c.id, value: v, source: { kind: p?.kind === 'voice' ? 'voice' : 'manual', label: formTitle, formTitle, form: o.file, station: o.station, by: a.name, at, snippet: p?.snippet } });
        const pid = pmhIds.get(f.key); if (pid && v === true) out.push({ concept: `pmh.${pid}`, value: true, source: { kind: 'manual', label: formTitle, formTitle, form: o.file, station: o.station, by: a.name, at } });
      });
      // Patient-reported allergies (Medical History rows / NKDA box) -> one fact the stations must confirm.
      const rows: string[] = []; let nkda = false;
      fields.forEach(f => {
        const v = getVal(f.el); const m = f.label.match(/^allergen \/ agent · row (\d+)/i);
        if (m && typeof v === 'string' && v.trim()) { const r = fields.find(x => new RegExp(`^reaction · row ${m[1]}$`, 'i').test(x.label)); const rv = r ? String(getVal(r.el) || '').trim() : ''; rows.push(rv ? `${v.trim()} (${rv})` : v.trim()); }
        if (/^no known drug allergies/i.test(f.label) && v === true) nkda = true;
      });
      if (rows.length || nkda) out.push({ concept: 'patient.reportedAllergies', value: rows.length ? rows.join('; ') : 'NKDA', source: { kind: 'manual', label: formTitle, formTitle, form: o.file, station: o.station, by: a.name, at } });
      return out;
    },
    unconfirmed() { return fields.filter(f => { const p = prov[f.key]; return p && !p.confirmed && (p.kind === 'default' || p.needsConfirm) && !isEmpty(f.el) && !f.el.closest('.vk-ignore'); }); },
    confirmAll() { const list = ctl.unconfirmed(); list.forEach(f => { prov[f.key] = { ...prov[f.key], confirmed: true }; }); recalc(); return list.length; },
    applyValue(key, value, p) { const f = byKey.get(key); if (!f) return; setVal(f.el, value); prov[key] = p; recalc(); o.onDirty(); },
    applyLocks(rec) {
      const signedSections = rule.signers.filter(s => rec.signatures.some(x => x.slotId === s.id));
      const all = rec.status === 'locked' || signedSections.some(s => !s.sections);
      o.host.dataset.locked = all ? '1' : '';
      fields.forEach(f => {
        const lock = all || signedSections.some(s => s.sections && s.sections.test(f.section));
        f.el.toggleAttribute('disabled', lock); f.el.closest('label,.vk-tap')?.classList.toggle('vk-locked', lock);
      });
      root.querySelectorAll<HTMLElement>('.vk-section-tools').forEach(t => { const sec = t.dataset.section || ''; const lock = all || signedSections.some(s => s.sections && s.sections.test(sec)); t.style.display = lock ? 'none' : ''; });
      root.querySelectorAll<HTMLButtonElement>('.vk-seg button').forEach(b => { b.disabled = all || signedSections.some(s => s.sections && s.sections.test(b.dataset.section || '')); });
    },
    sections() { return Array.from(new Set(fields.map(f => f.section))); },
    paging: pager ? { count: pager.count, index: () => pageIndex, titles: pageTitles, go: (n: number, scroll = true) => pager.go(n, scroll) } : null,
    initials() {
      const pages = Array.from(root.querySelectorAll<HTMLElement>('section.page'));
      return fields.filter(f => f.el.dataset.vkInitials).map(f => { const pg = f.el.closest<HTMLElement>('section.page'); return { key: f.key, slot: f.el.dataset.vkInitials!, page: pg?.dataset.title || '', pageIndex: pg ? pages.indexOf(pg) : -1, value: String(getVal(f.el) || '').trim() }; });
    },
    stats() {
      const live = fields.filter(f => !f.el.closest('.vk-ignore'));
      const byKind: Record<string, number> = {};
      live.forEach(f => { const p = prov[f.key]; const k = p ? p.kind : (isEmpty(f.el) ? 'empty' : 'manual'); byKind[k] = (byKind[k] || 0) + 1; });
      return { total: live.length, filled: live.filter(f => !isEmpty(f.el)).length, byKind };
    },
  };
  buildSectionTools(root, fields, rule, prov, ctl, () => { recalc(); o.onDirty(); o.onChange?.(); }, actor);
  recalc();
  ctl.applyLocks(record);
  return ctl;
}

function buildSectionTools(root: ShadowRoot, fields: FieldInfo[], rule: FormRule, prov: Record<string, Provenance>, ctl: FormController, after: () => void, actor: Actor) {
  const heads = headingElements(root);
  const secNames = Array.from(new Set(fields.filter(f => !f.el.closest('.vk-ignore')).map(f => f.section)));
  secNames.forEach(sec => {
    const inSec = fields.filter(f => f.section === sec && !f.el.closest('.vk-ignore'));
    const normals = (rule.normals || []).filter(n => n.section.test(sec));
    const hasPending = () => inSec.some(f => { const p = prov[f.key]; return p && !p.confirmed && (p.kind === 'default' || p.needsConfirm); });
    if (!normals.length && !hasPending()) return;
    const bar = document.createElement('div'); bar.className = 'vk-section-tools vk-ignore'; bar.dataset.section = sec;
    normals.forEach(n => {
      const b = document.createElement('button'); b.type = 'button'; b.className = 'vk-normal'; b.textContent = `✓ ${n.button}`;
      b.onclick = () => {
        const p: Provenance = { kind: 'normal', label: `${n.button} — tapped by ${actor.name}`, at: nowIso(), by: actor.name, confirmed: true };
        let changed = 0;
        inSec.forEach(f => {
          if (n.check && f.el instanceof HTMLInputElement && f.el.type === 'checkbox' && !f.el.checked && n.check.some(r => r.test(f.label))) { f.el.checked = true; prov[f.key] = p; changed++; }
          if (n.selectNormal && f.el instanceof HTMLSelectElement && !f.el.value) {
            const opt = Array.from(f.el.options).find(o => /^(normal|wnl|within normal|no acute|intact|unremarkable|negative|clear|regular|alert)/i.test(o.text.trim()));
            if (opt) { f.el.value = opt.value; prov[f.key] = p; changed++; }
          }
          (n.fill || []).forEach(([re, v]) => { if (re.test(f.label) && !(f.el as HTMLInputElement).value) { (f.el as HTMLInputElement).value = v; prov[f.key] = p; changed++; } });
          (n.stamp || []).forEach(([re, what]) => { if (re.test(f.label) && !(f.el as HTMLInputElement).value) { (f.el as HTMLInputElement).value = what === 'now' ? nowHHMM() : `${actor.name}${actor.credentials ? ', ' + actor.credentials : ''} (${actor.role})`; prov[f.key] = { ...p, kind: what === 'now' ? 'event' : 'normal' }; changed++; } });
        });
        // confirming a normal set also confirms prefilled values in that section
        inSec.forEach(f => { const q = prov[f.key]; if (q && (q.kind === 'default' || q.needsConfirm) && !q.confirmed) prov[f.key] = { ...q, confirmed: true }; });
        const done = document.createElement('span'); done.className = 'vk-done'; done.textContent = changed ? `${changed} item${changed > 1 ? 's' : ''} set — change any that differ` : 'Already complete';
        bar.querySelector('.vk-done')?.remove(); bar.appendChild(done);
        repo.audit({ caseId: ctl.record.caseId, user: actor.name, role: actor.role, action: 'form.normal', form: ctl.record.file, detail: `${n.button} (${sec}): ${changed} values` });
        after();
      };
      bar.appendChild(b);
    });
    const c = document.createElement('button'); c.type = 'button'; c.className = 'vk-confirm';
    const refresh = () => { const n = inSec.filter(f => { const p = prov[f.key]; return p && !p.confirmed && (p.kind === 'default' || p.needsConfirm); }).length; c.textContent = `Confirm ${n} prefilled`; c.style.display = n ? '' : 'none'; };
    c.onclick = () => { inSec.forEach(f => { const q = prov[f.key]; if (q && !q.confirmed) prov[f.key] = { ...q, confirmed: true }; }); repo.audit({ caseId: ctl.record.caseId, user: actor.name, role: actor.role, action: 'form.confirm', form: ctl.record.file, detail: `Confirmed prefilled values in “${sec}”` }); after(); refresh(); };
    refresh(); root.addEventListener('change', refresh); root.addEventListener('click', () => setTimeout(refresh, 0));
    bar.appendChild(c);
    const h = heads.find(x => (x.textContent || '').replace(/\s+/g, ' ').trim().slice(0, 80) === sec);
    if (h) h.insertAdjacentElement('afterend', bar);
    else {
      const who = root.querySelector('.who');
      if (who) { let after: Element = who; const nx = who.nextElementSibling; if (nx && /notice|compliance|alert/.test(nx.className) && !nx.querySelector('input')) after = nx; after.insertAdjacentElement('afterend', bar); }
      else { let el: Element | null = inSec[0]?.el || null; while (el && el.parentElement && !/(^|\s)(body|vk-root|packet-container|sheet|page)(\s|$)/.test(el.parentElement.className)) el = el.parentElement; el?.parentElement?.insertBefore(bar, el); }
    }
  });
}

/* ---------- chart-derived checks (Nursing admission section 6) ---------- */
function chartChecks(fields: FieldInfo[], caseId: string, facts: Record<string, Fact>, setP: (f: FieldInfo, p: Provenance) => void) {
  const signed = (file: string, role?: RegExp) => { const r = repo.getForm(caseId, file); const s = r.signatures.find(x => !role || role.test(x.role)); return s ? s : null; };
  const rules: [RegExp, () => string | null][] = [
    [/^consents completed/i, () => { const a = signed('Procedure_Consent.html', /Patient/); const b = signed('Anesthesia_Consent.html', /Patient/); return a && b ? `Procedure + anesthesia consents signed ${fmtTime(a.at)}` : null; }],
    [/^history & physical \(h&p\) present/i, () => { const s = signed('PreOp_HP_Clearance.html') || signed('Surgeon_PreOp_Clearance.html'); return s ? `H&P signed ${fmtTime(s.at)}` : null; }],
    [/^pre-anesthesia evaluation present/i, () => { const s = signed('Anesthesia_Evaluation.html'); return s ? `Anesthesia evaluation signed ${fmtTime(s.at)}` : null; }],
    [/^day-of-surgery h&p update documented/i, () => { const s = signed('DayOf_Interval_HP_Update.html'); return s ? `Interval H&P signed ${fmtTime(s.at)}` : null; }],
    [/^npo status verified/i, () => facts['npo.solid'] && facts['npo.clear'] ? `NPO times recorded (${facts['npo.solid'].value} / ${facts['npo.clear'].value})` : null],
    [/^responsible adult driver confirmed/i, () => facts['adult.driver'] ? `Driver recorded: ${facts['adult.driver'].value}` : null],
  ];
  fields.forEach(f => {
    if (!(f.el instanceof HTMLInputElement) || f.el.type !== 'checkbox' || f.el.checked) return;
    const r = rules.find(([re]) => re.test(f.label)); if (!r) return;
    const why = r[1](); if (why) { f.el.checked = true; setP(f, { kind: 'carried', label: `From chart: ${why}`, at: nowIso() }); }
  });
}

/* ---------- Aldrete ---------- */
function setupAldrete(root: ShadowRoot) {
  const h = headingElements(root).find(x => /aldrete/i.test(x.textContent || '')); if (!h) return;
  let table: HTMLTableElement | null = null; let n: Element | null = h.nextElementSibling;
  while (n && !table) { table = n.matches('table') ? n as HTMLTableElement : n.querySelector('table'); n = n.nextElementSibling; }
  if (!table) return;
  table.classList.add('vk-aldrete');
  const rows = Array.from(table.querySelectorAll('tbody tr'));
  rows.forEach((tr, ri) => {
    const inputs = Array.from(tr.querySelectorAll<HTMLInputElement>('input'));
    const isTotal = /composite|total/i.test(tr.textContent || '');
    inputs.forEach((inp, ci) => {
      inp.inputMode = 'numeric';
      if (isTotal) { inp.readOnly = true; inp.classList.add('vk-total'); inp.dataset.aldreteTotal = String(ci); inp.placeholder = '—'; return; }
      inp.dataset.aldrete = `${ri}:${ci}`; inp.style.display = 'none';
      const seg = document.createElement('div'); seg.className = 'vk-seg';
      [2, 1, 0].forEach(v => { const b = document.createElement('button'); b.type = 'button'; b.textContent = String(v); b.dataset.section = 'Discharge-Readiness Scoring (Modified Aldrete)'; b.setAttribute('aria-label', `Score ${v}`);
        b.onclick = () => { inp.value = inp.value === String(v) ? '' : String(v); inp.dispatchEvent(new Event('input', { bubbles: true })); };
        seg.appendChild(b); });
      inp.insertAdjacentElement('afterend', seg);
    });
  });
}
function aldreteTotals(root: ShadowRoot, fields: FieldInfo[], prov: Record<string, Provenance>) {
  const cols: Record<string, { sum: number; n: number }> = {};
  root.querySelectorAll<HTMLInputElement>('input[data-aldrete]').forEach(inp => {
    const [, ci] = inp.dataset.aldrete!.split(':'); cols[ci] = cols[ci] || { sum: 0, n: 0 };
    if (inp.value !== '') { cols[ci].sum += Number(inp.value) || 0; cols[ci].n++; }
    inp.nextElementSibling?.querySelectorAll('button').forEach(b => b.classList.toggle('on', b.textContent === inp.value));
  });
  root.querySelectorAll<HTMLInputElement>('input[data-aldrete-total]').forEach(inp => {
    const c = cols[inp.dataset.aldreteTotal!]; const f = fields.find(x => x.el === inp);
    inp.value = c && c.n === 5 ? String(c.sum) : c && c.n ? `${c.sum} (${c.n}/5 scored)` : '';
    if (f) { if (inp.value) prov[f.key] = { kind: 'calc', label: 'Automatic Aldrete total', at: nowIso() }; else delete prov[f.key]; }
  });
  const adm = fields.find(f => /^aldrete score at admission$/i.test(f.label));
  const admTotal = cols['0'] && cols['0'].n === 5 ? String(cols['0'].sum) : '';
  if (adm && admTotal && (adm.el.value === '' || prov[adm.key]?.kind === 'calc')) { adm.el.value = admTotal; prov[adm.key] = { kind: 'calc', label: 'From the Aldrete table (admission column)', at: nowIso() }; }
  // discharge gate indicator
  let gate = root.querySelector<HTMLElement>('.vk-gate');
  const crit = fields.find(f => /^patient has met all of above discharge criteria/i.test(f.label));
  if (crit) {
    if (!gate) { gate = document.createElement('div'); gate.className = 'vk-gate vk-ignore'; (crit.el.closest('label') || crit.el).insertAdjacentElement('beforebegin', gate); }
    const d = cols['2']; const ok = d && d.n === 5 && d.sum >= 9;
    gate.className = `vk-gate vk-ignore ${ok ? 'ok' : 'no'}`;
    gate.textContent = d && d.n === 5 ? `Discharge Aldrete ${d.sum}/10 — ${ok ? 'meets the ≥ 9 threshold' : 'below the ≥ 9 threshold'}` : 'Discharge Aldrete not yet scored (needs all 5 items)';
  }
}

/* ---------- VTE / Caprini-style total (template script never runs) ---------- */
function vteTotal(root: ShadowRoot, fields: FieldInfo[], prov: Record<string, Provenance>) {
  let total = 0; root.querySelectorAll<HTMLInputElement>('input[type=checkbox][data-pts]').forEach(cb => { if (cb.checked) total += Number(cb.dataset.pts) || 0; });
  const out = root.getElementById('totalScore') as HTMLInputElement | null; if (!out) return;
  out.value = String(total); out.readOnly = true;
  const f = fields.find(x => x.el === out); if (f) prov[f.key] = { kind: 'calc', label: 'Automatic VTE risk total', at: nowIso() };
  const lbl = root.getElementById('riskLabel');
  if (lbl) lbl.innerHTML = total <= 1 ? '<strong style="color:#276749">Low risk</strong> (0–1) · Moderate: 2 · High: 3+' : total === 2 ? 'Low: 0–1 · <strong style="color:#9c4a12">Moderate risk</strong> (2) · High: 3+' : 'Low: 0–1 · Moderate: 2 · <strong style="color:#b42318">High risk</strong> (3+)';
}
function bmiCalc(fields: FieldInfo[], prov: Record<string, Provenance>) {
  const h = fields.find(f => /^height$/i.test(f.label)); const w = fields.find(f => /^weight$/i.test(f.label)); const b = fields.find(f => /^bmi/i.test(f.label));
  if (!h || !w || !b) return;
  const hi = parseHeightIn((h.el as HTMLInputElement).value); const lb = parseWeightLb((w.el as HTMLInputElement).value);
  if (hi && lb && hi > 30 && hi < 100) { if (!b.el.value || prov[b.key]?.kind === 'calc') { b.el.value = (703 * lb / (hi * hi)).toFixed(1); prov[b.key] = { kind: 'calc', label: 'BMI from height and weight', at: nowIso() }; } }
}
function pacuLos(fields: FieldInfo[], prov: Record<string, Provenance>) {
  const a = fields.find(f => /^time of admission/i.test(f.label)); const d = fields.find(f => /^time of discharge/i.test(f.label)); const los = fields.find(f => /^total pacu length of stay$/i.test(f.label));
  if (!a || !d || !los) return; const pa = a.el.value.split(':').map(Number); const pd = d.el.value.split(':').map(Number);
  if (pa.length === 2 && pd.length === 2 && !isNaN(pa[0]) && !isNaN(pd[0]) && a.el.value && d.el.value) {
    let m = (pd[0] * 60 + pd[1]) - (pa[0] * 60 + pa[1]); if (m < 0) m += 1440;
    if (!los.el.value || prov[los.key]?.kind === 'calc') { los.el.value = `${Math.floor(m / 60)} h ${m % 60} min`; prov[los.key] = { kind: 'calc', label: 'Discharge time minus admission time', at: nowIso() }; }
  }
  // discharge vitals from the last flowsheet row
  const dv = fields.find(f => /^discharge vital signs$/i.test(f.label));
  if (dv && (!dv.el.value || prov[dv.key]?.kind === 'calc')) {
    const rows: Record<string, string>[] = [];
    fields.filter(f => f.inTable && /vital signs flowsheet/i.test(f.section)).forEach(f => { const m = f.label.match(/^(.*) · row (\d+)$/); if (!m) return; const r = Number(m[2]) - 1; rows[r] = rows[r] || {}; rows[r][m[1]] = f.el.value; });
    const last = rows.filter(r => r && r['BP'] && r['HR']).pop();
    if (last) { dv.el.value = `BP ${last['BP']}, HR ${last['HR']}${last['RR'] ? ', RR ' + last['RR'] : ''}${last['SpO2'] ? ', SpO2 ' + last['SpO2'] + '%' : ''}`; prov[dv.key] = { kind: 'calc', label: 'Last flowsheet row', at: nowIso() }; }
  }
}

export function escapeHtml(s: string) { return String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c] as string)); }
export { slug };
