/*
 * v7 item 12: fee schedules with time-based facility + anesthesia fees, alternate schedules chosen by a
 * configurable parameter, and invoices generated from case times. Browser storage in this build;
 * backend: /practices/:id/fee-schedules and /cases/:id/invoices.
 */
import type { PatientCase } from '../types';
import { repo } from '../v6/dataLayer';

export interface TimeFee { base: number; includedMin: number; perIncrement: number; incrementMin: number }
export type MatchKind = 'default' | 'procedure' | 'surgeon' | 'anesthesiaType' | 'room';
export interface FeeSchedule { id: string; name: string; match: { kind: MatchKind; value: string }; facility: TimeFee; anesthesia: TimeFee; surgeonFee: number; notes?: string }
export interface InvoiceLine { label: string; detail: string; amount: number }
export interface Invoice {
  id: string; number: string; caseId: string; patientName: string; patientId: string; dos: string; procedure: string; surgeon: string; anesthesiologist?: string;
  paymentType: string; scheduleId: string; scheduleName: string; facilityMin: number; anesthesiaMin: number; lines: InvoiceLine[]; total: number; paid: number;
  status: 'Draft' | 'Sent (simulated)' | 'Partially paid' | 'Paid in full'; createdAt: string; createdBy: string;
  /** v7.1: issued by a manager before the normal eligibility rule was met. */
  override?: { by: string; role: string; reason: string; at: string; unmet: string[] };
}
/**
 * v7.1 feature switches. alternateSchedules: coming later — schedules chosen by procedure / surgeon /
 * anesthesia type / room. The data model, matching code and editor are kept; while false, the UI shows
 * only the time-based default schedule and every invoice uses it.
 */
export const BILLING_FEATURES = { alternateSchedules: false };
const K_SCHED = 'vityls:v7:fee-schedules'; const K_INV = 'vityls:v7:invoices';
const read = <T,>(k: string, f: T): T => { try { const r = localStorage.getItem(k); return r ? JSON.parse(r) : f; } catch { return f; } };
const write = (k: string, v: unknown) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch { /* ignore */ } };
const notify = () => { try { window.dispatchEvent(new Event('vityls-billing-updated')); } catch { /* ignore */ } };

/** Example starting schedules (editable in Administration → Billing & Payments → Fee Schedules). Amounts are placeholders, not advice. */
export const DEFAULT_SCHEDULES: FeeSchedule[] = [
  { id: 'std', name: 'Standard cash-pay', match: { kind: 'default', value: '' }, facility: { base: 1500, includedMin: 60, perIncrement: 250, incrementMin: 15 }, anesthesia: { base: 600, includedMin: 30, perIncrement: 125, incrementMin: 15 }, surgeonFee: 0, notes: 'Used when no alternate schedule matches.' },
  { id: 'minor', name: 'Minor procedure (alternate)', match: { kind: 'procedure', value: 'lesion' }, facility: { base: 800, includedMin: 30, perIncrement: 150, incrementMin: 15 }, anesthesia: { base: 400, includedMin: 30, perIncrement: 90, incrementMin: 15 }, surgeonFee: 0, notes: 'Example: procedures containing “lesion”.' },
];
export const getSchedules = (): FeeSchedule[] => { const s = read<FeeSchedule[]>(K_SCHED, []); return s.length ? s : DEFAULT_SCHEDULES; };
export const saveSchedules = (s: FeeSchedule[]) => { write(K_SCHED, s); notify(); };

export function timeFee(t: TimeFee, minutes: number) {
  const extra = Math.max(0, minutes - t.includedMin); const inc = t.incrementMin > 0 ? Math.ceil(extra / t.incrementMin) : 0;
  return { amount: Math.round((t.base + inc * t.perIncrement) * 100) / 100, increments: inc };
}
const field = (c: Partial<PatientCase> & Record<string, any>, k: MatchKind) => String(k === 'anesthesiaType' ? c.anesthesiaType || c.anesthesia || '' : (c as any)[k] || '');
export const defaultSchedule = (list = getSchedules()): FeeSchedule => list.find(s => s.match.kind === 'default') || list[0];
export function scheduleFor(c: Partial<PatientCase>, list = getSchedules()): FeeSchedule {
  if (!BILLING_FEATURES.alternateSchedules) return defaultSchedule(list);
  const alt = list.find(s => s.match.kind !== 'default' && s.match.value.trim() && field(c as any, s.match.kind).toLowerCase().includes(s.match.value.trim().toLowerCase()));
  return alt || list.find(s => s.match.kind === 'default') || list[0];
}
const hm = (v?: unknown) => { const m = String(v || '').match(/^(\d{1,2}):(\d{2})/); return m ? Number(m[1]) * 60 + Number(m[2]) : null; };
const span = (a?: unknown, b?: unknown) => { const x = hm(a), y = hm(b); return x != null && y != null ? (y >= x ? y - x : y + 1440 - x) : null; };
/** Case times from the OR event bar (in/out of room, anesthesia start/end); falls back to the scheduled length. */
export function caseTimes(c: PatientCase) {
  const f = repo.getFacts(c.id); const sched = c.estimatedDurationMins || 90;
  const fac = span(f['time.inOR']?.value, f['time.outOR']?.value); const an = span(f['time.anesStart']?.value, f['time.anesEnd']?.value);
  return { facilityMin: fac ?? sched, anesthesiaMin: an ?? Math.max(0, (fac ?? sched) - 10), fromEvents: fac != null, events: { inOR: f['time.inOR']?.value, outOR: f['time.outOR']?.value, anesStart: f['time.anesStart']?.value, anesEnd: f['time.anesEnd']?.value } as Record<string, unknown> };
}
export const isCashPay = (c: Partial<PatientCase>) => /self|cash/i.test(c.paymentType || '');
export function buildInvoice(c: PatientCase, opts: { facilityMin: number; anesthesiaMin: number; schedule?: FeeSchedule; by: string }): Invoice {
  const s = opts.schedule || scheduleFor(c);
  const f = timeFee(s.facility, opts.facilityMin), a = timeFee(s.anesthesia, opts.anesthesiaMin);
  const inc = (t: TimeFee, n: number) => n ? ` + ${n} × ${t.incrementMin} min @ $${t.perIncrement}` : '';
  const lines: InvoiceLine[] = [
    { label: 'Facility fee', detail: `${opts.facilityMin} min: base $${s.facility.base} (first ${s.facility.includedMin} min)${inc(s.facility, f.increments)}`, amount: f.amount },
    { label: 'Anesthesia fee', detail: `${opts.anesthesiaMin} min: base $${s.anesthesia.base} (first ${s.anesthesia.includedMin} min)${inc(s.anesthesia, a.increments)}`, amount: a.amount },
  ];
  if (s.surgeonFee) lines.push({ label: 'Surgeon fee', detail: 'Flat', amount: s.surgeonFee });
  const all = getInvoices();
  return { id: `inv-${Date.now()}`, number: `INV-${new Date().getFullYear()}-${String(all.length + 1).padStart(4, '0')}`, caseId: c.id, patientName: c.name, patientId: c.patientId, dos: c.appointmentDate || '', procedure: c.procedure, surgeon: c.surgeon, anesthesiologist: c.anesthesiologist,
    paymentType: c.paymentType || 'Self-Pay', scheduleId: s.id, scheduleName: s.name, facilityMin: opts.facilityMin, anesthesiaMin: opts.anesthesiaMin, lines, total: lines.reduce((x, l) => x + l.amount, 0), paid: 0, status: 'Draft', createdAt: new Date().toISOString(), createdBy: opts.by };
}
export const getInvoices = (): Invoice[] => read<Invoice[]>(K_INV, []);
export const invoicesForCase = (caseId: string) => getInvoices().filter(i => i.caseId === caseId);
export function saveInvoice(inv: Invoice) { const all = getInvoices().filter(i => i.id !== inv.id); write(K_INV, [inv, ...all]); notify(); repo.audit({ caseId: inv.caseId, user: inv.createdBy, role: 'Billing', action: 'invoice.save', detail: `Invoice ${inv.number} ${inv.status}: $${inv.total.toFixed(2)} (${inv.scheduleName})${inv.override ? ' · issued by manager override' : ''}` }); }
export function recordPayment(id: string, amount: number, by: string) {
  const inv = getInvoices().find(i => i.id === id); if (!inv) return;
  inv.paid = Math.round((inv.paid + amount) * 100) / 100; inv.status = inv.paid >= inv.total ? 'Paid in full' : 'Partially paid';
  saveInvoice({ ...inv, createdBy: by });
}
/** Balance summary used on the patient page and Scheduler (item 16). */
export function balanceFor(caseId: string) {
  const inv = invoicesForCase(caseId); const total = inv.reduce((x, i) => x + i.total, 0); const paid = inv.reduce((x, i) => x + i.paid, 0);
  return { invoices: inv.length, total, paid, due: Math.max(0, total - paid), label: !inv.length ? 'No invoice' : total - paid <= 0 ? 'Paid in full' : `$${(total - paid).toFixed(2)} due` };
}
/** Documentation complete = every required signer on every My Forms form for the case has signed. */
export function documentationComplete(caseId: string, files: string[], ruleFor: (f: string) => { signers: { id: string; required: boolean }[] }) {
  if (!files.length) return { ok: false, open: ['No forms in My Forms'] };
  const open = files.filter(f => { const r = repo.getForm(caseId, f); return r.status !== 'locked' && ruleFor(f).signers.some(s => s.required); });
  return { ok: open.length === 0, open };
}
