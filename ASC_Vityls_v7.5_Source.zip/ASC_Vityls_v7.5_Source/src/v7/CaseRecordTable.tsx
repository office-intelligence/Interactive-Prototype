import React, { useState } from 'react';
import { Printer, Download, FileText } from 'lucide-react';
import type { PatientCase } from '../types';
import { repo, fmtDateTime } from '../v6/dataLayer';
import { ruleFor, STATIONS } from '../v6/formRules';
import { VITYLS_FORM_CATALOG } from '../data/formWorkspaceCatalog';
import { allStationForms, stationsOf, requirementOf } from './myForms';
import { effectiveAllergy } from './allergy';
import { getDocs, getState } from './clearance';
import { invoicesForCase } from './billing';
import { InvoicePanel, useBilling } from './InvoicePanel';
import { Btn, CardTitle } from './ui';
import { OR_EVENTS } from '../v6/EventBar';

const title = (f: string) => VITYLS_FORM_CATALOG.find(c => c.file === f)?.title || f.replace(/_/g, ' ').replace('.html', '');
const stLabel = (k: string) => STATIONS.find(s => s.key === k)?.label || k;
const money = (n: number) => `$${n.toFixed(2)}`;
type Tone = 'ok' | 'warn' | 'bad' | 'muted';
type Row = { section: string; item: string; value: string; by: string; when: string; status: string; tone: Tone };

/** Item 14: one consolidated table of the complete case record (audit / accreditation). */
export function caseRecordRows(p: PatientCase): Row[] {
  const facts = repo.getFacts(p.id); const ver = repo.getStationVerification(p.id); const rows: Row[] = [];
  const add = (r: Partial<Row> & { section: string; item: string }) => rows.push({ value: '', by: '', when: '', status: '', tone: 'muted', ...r });
  const al = effectiveAllergy(p.allergies, p.id);
  const caseRows: [string, string][] = [['Patient', `${p.name} · DOB ${p.dob || '—'} · MRN ${p.patientId}`], ['Procedure', p.procedure], ['Date / time / room', `${p.appointmentDate || '—'} · ${p.scheduledTime || '—'} · ${p.room || '—'}`], ['Surgeon', p.surgeon || '—'], ['Anesthesia', `${p.anesthesiologist || '—'}${(p as any).anesthesiaType ? ` · ${(p as any).anesthesiaType}` : ''}`], ['Payment type', p.paymentType || '—']];
  caseRows.forEach(([i, v]) => add({ section: 'Case', item: i, value: v, status: v && v !== '—' ? 'Recorded' : 'Missing', tone: v && v !== '—' ? 'ok' : 'warn' }));
  if (al.pendingConfirm) add({ section: 'Case', item: 'Allergy status', value: `${al.text} (patient-reported on ${al.sourceForm || 'intake'})`, status: 'Not confirmed by clinician', tone: 'warn' });
  else add({ section: 'Case', item: 'Allergy status', value: al.text, status: al.state === 'not-reported' ? 'Not reported' : 'Recorded', tone: al.state === 'not-reported' ? 'warn' : 'ok' });
  const docs = getDocs(p.id); const cs = getState(p.id);
  docs.forEach(d => add({ section: 'Pre-op clearance', item: d.type, value: d.title, by: d.receivedBy, when: fmtDateTime(d.receivedAt), status: d.status, tone: d.status === 'Reviewed' ? 'ok' : 'warn' }));
  if (!docs.length) add({ section: 'Pre-op clearance', item: 'Clearance documents', value: 'None received', status: 'Missing', tone: 'warn' });
  add({ section: 'Pre-op clearance', item: 'Clinician review of documents', value: cs.review ? 'Confirmed' : 'Not confirmed', by: cs.review?.by || '', when: fmtDateTime(cs.review?.at), status: cs.review ? 'Done' : 'Open', tone: cs.review ? 'ok' : 'warn' });
  add({ section: 'Pre-op clearance', item: 'Cleared for surgery', value: cs.cleared?.note || (cs.cleared ? 'Cleared' : 'Not cleared'), by: cs.cleared?.by || '', when: fmtDateTime(cs.cleared?.at), status: cs.cleared ? 'Done' : 'Open', tone: cs.cleared ? 'ok' : 'warn' });
  allStationForms().forEach(f => {
    const r = repo.getForm(p.id, f); const req = ruleFor(f).signers.filter(s => s.required);
    const missing = req.filter(s => !r.signatures.some(x => x.slotId === s.id)).map(s => s.role);
    const extra = `${r.lockedHash ? ` · fingerprint ${r.lockedHash.slice(0, 8)}` : ''}${r.addenda.length ? ` · ${r.addenda.length} addend${r.addenda.length > 1 ? 'a' : 'um'}` : ''}`;
    const status = r.status === 'locked' ? 'Signed & locked' : r.status === 'not-started' ? 'Not started' : `${r.status === 'draft' ? 'Draft' : 'Partially signed'}${missing.length ? ` · needs ${missing.join(', ')}` : ''}`;
    add({ section: 'Documents', item: title(f), value: `${stationsOf(f).map(stLabel).join(', ')} · ${requirementOf(f)}${extra}`, by: r.signatures.map(s => `${s.signerName}${s.credentials ? `, ${s.credentials}` : ''} (${s.role})`).join('; '), when: r.lockedAt ? fmtDateTime(r.lockedAt) : fmtDateTime(r.updatedAt), status, tone: r.status === 'locked' ? 'ok' : requirementOf(f) === 'Required' ? 'bad' : 'muted' });
  });
  OR_EVENTS.forEach(e => { const f = facts[e.id]; add({ section: 'Key times', item: e.label, value: (f?.value as string) || '—', by: f?.source.by || '', when: fmtDateTime(f?.source.at), status: f ? 'Recorded' : 'Missing', tone: f ? 'ok' : 'warn' }); });
  const factRows: [string, string][] = [['ASA class', 'case.asa'], ['NPO solids', 'npo.solid'], ['Responsible adult / driver', 'adult.driver'], ['EBL (mL)', 'case.ebl'], ['Wound class', 'case.woundClass']];
  factRows.forEach(([i, k]) => { const f = facts[k]; add({ section: 'Clinical facts', item: i, value: (f?.value as string) || '—', by: f?.source.by || '', when: fmtDateTime(f?.source.at), status: f ? `From ${f.source.formTitle || f.source.label}` : 'Not recorded', tone: f ? 'ok' : 'muted' }); });
  STATIONS.filter(s => s.key !== 'caseRecord').forEach(s => { const v = ver[s.key]; add({ section: 'Station verification', item: s.label, value: v ? v.role : '—', by: v?.by || '', when: fmtDateTime(v?.at), status: v ? 'Verified' : 'Not verified', tone: v ? 'ok' : 'muted' }); });
  const inv = invoicesForCase(p.id);
  inv.forEach(i => {
    add({ section: 'Billing', item: i.number, value: `${i.scheduleName} · total ${money(i.total)} · paid ${money(i.paid)}${i.override ? ' · issued by manager override' : ''}`, by: i.createdBy, when: fmtDateTime(i.createdAt), status: i.status, tone: i.status === 'Paid in full' ? 'ok' : 'warn' });
    if (i.override) add({ section: 'Billing', item: `${i.number} · manager override`, value: `Issued by manager override. Reason: ${i.override.reason}. Open at the time: ${i.override.unmet.join('; ') || '—'}`, by: `${i.override.by} (${i.override.role})`, when: fmtDateTime(i.override.at), status: 'Override', tone: 'warn' });
  });
  if (!inv.length) add({ section: 'Billing', item: 'Invoice', value: /self|cash/i.test(p.paymentType || '') ? 'Not generated yet' : 'Not a cash-pay case', status: 'Open', tone: 'muted' });
  add({ section: 'Audit', item: 'Audit trail entries', value: String(repo.getAudit(p.id).length), status: 'Append-only (browser storage in this build)', tone: 'muted' });
  return rows;
}
const toCsv = (rows: Row[]) => ['Section,Item,Value,By,When,Status', ...rows.map(r => [r.section, r.item, r.value, r.by, r.when, r.status].map(x => `"${String(x).replace(/"/g, '""')}"`).join(','))].join('\n');
const chip = (t: Tone) => t === 'ok' ? 'vy-chip-ok' : t === 'warn' ? 'vy-chip-warn' : t === 'bad' ? 'vy-chip-bad' : 'vy-chip-muted';

export const CaseRecordTable: React.FC<{ patient: PatientCase; actor: string; actorRole?: string; onOpen: (file: string) => void }> = ({ patient, actor, actorRole, onOpen }) => {
  useBilling(); const [showAudit, setShowAudit] = useState(false);
  const rows = caseRecordRows(patient); const audit = repo.getAudit(patient.id).slice().reverse();
  const docs = rows.filter(r => r.section === 'Documents'); const open = rows.filter(r => r.tone === 'bad' || r.tone === 'warn');
  const sections = Array.from(new Set(rows.map(r => r.section)));
  const exportCsv = () => { const a = document.createElement('a'); a.href = 'data:text/csv;charset=utf-8,' + encodeURIComponent(toCsv(rows)); a.download = `Case_Record_${patient.patientId}.csv`; a.click(); };
  const openDoc = (item: string) => { const f = allStationForms().find(x => title(x) === item); if (f) onOpen(f); };
  return <div className="space-y-4" data-testid="case-record">
    <section className="vy-card p-5">
      <CardTitle kicker="Final station" title="Case Record" sub={`Consolidated record for audits and accreditation inspections. ${docs.filter(d => d.tone === 'ok').length} of ${docs.length} documents signed and locked · ${open.length} open item${open.length === 1 ? '' : 's'}.`}
        right={<div className="flex gap-2 flex-wrap"><Btn variant="secondary" icon={<Printer size={18} />} onClick={() => window.print()}>Print</Btn><Btn variant="secondary" icon={<Download size={18} />} onClick={exportCsv} data-testid="export-case-record">Export CSV</Btn></div>} />
      <div className="overflow-x-auto mt-4"><table className="vy-table" data-testid="case-record-table"><thead><tr><th>Item</th><th>Value / detail</th><th>By</th><th>When</th><th>Status</th></tr></thead>
        <tbody>{sections.map(sec => <React.Fragment key={sec}><tr className="vy-table-section"><th colSpan={5}>{sec}</th></tr>
          {rows.filter(r => r.section === sec).map((r, i) => <tr key={sec + i}><td className="font-semibold">{sec === 'Documents' ? <button type="button" className="underline text-left" onClick={() => openDoc(r.item)}><FileText size={14} className="inline mr-1" />{r.item}</button> : r.item}</td><td>{r.value}</td><td>{r.by}</td><td className="whitespace-nowrap">{r.when}</td><td><span className={chip(r.tone)}>{r.status}</span></td></tr>)}</React.Fragment>)}</tbody></table></div>
    </section>
    <InvoicePanel patient={patient} actor={actor} role={actorRole} />
    <section className="vy-card p-5"><CardTitle title={`Audit trail (${audit.length})`} sub="Append-only in this test build (browser storage). The backend must keep it server-side with server time." right={<Btn variant="secondary" onClick={() => setShowAudit(x => !x)}>{showAudit ? 'Hide' : 'Show'}</Btn>} />
      {showAudit && <ol className="mt-3 space-y-1 max-h-[60vh] overflow-y-auto">{audit.slice(0, 300).map(a => <li key={a.id} className="text-[14px] border-b border-[#eef2ef] py-1.5"><span className="font-semibold">{fmtDateTime(a.at)}</span> · {a.user} ({a.role}) · {a.action}{a.form ? ` · ${title(a.form)}` : ''} · {a.detail}</li>)}{!audit.length && <li className="text-[14px]">No activity yet.</li>}</ol>}</section>
  </div>;
};
