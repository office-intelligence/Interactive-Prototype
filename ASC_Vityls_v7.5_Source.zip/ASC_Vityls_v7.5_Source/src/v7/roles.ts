/**
 * v7.1 manager roles. In this test build there is no login: the station "Acting as" role (or the app
 * user's role) stands in. Production: the server checks the signed-in user's role before accepting an
 * override.
 */
export const MANAGER_ROLES = ['Practice Manager', 'Administrator', 'Practice Administrator', 'PRACTICE_ADMIN', 'CEO'];
export const isManagerRole = (role?: string) => !!role && MANAGER_ROLES.some(r => r.toLowerCase() === role.trim().toLowerCase());
