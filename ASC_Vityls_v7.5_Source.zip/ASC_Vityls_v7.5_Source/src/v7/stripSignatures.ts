/**
 * v7.4 item 5: signatures come only from Signer setup + the multi-signer panel.
 * The bundled templates were cleaned once by scripts/strip_template_signatures.py; this runtime twin applies the same
 * rules to practice-customized templates saved in Form Studio (localStorage), so an older custom copy can't bring
 * signature pads, typed-signature fields or hard-coded initials back.
 */
const PAD = '.sig-pad-wrap,.sig-pad-actions,.sig-actions,.sig-status,canvas,[data-field-type="signature"],[data-vityls-type="signature"]';
const BLOCK = '.signature-block,.signature-section,.signatures,.sig-block,div.sig,div.sign';
const SIG_LABEL = /signature|\binitials\b/i;
const NOT_SIG = /initial (count|bp|pain|check)/i;
const BLOCK_FIELD = /signature|\bsigned\b|\binitials?\b|print(ed)?\s*name|^\s*date\s*(\/\s*time)?\s*$|^\s*time\s*$/i;
const SIG_NAME = /^(sig|sign)|signature|print$|^(patient|clinician|witness|nurse|rn|md)Print/i;
const SIGNY_TEXT = /signature|sign-off|\bsign(ed|s)?\b|attest|authenticat|certif|acknowledg|initials/i;

export function stripTemplateSignatures(html: string): string {
  if (!html || typeof DOMParser === 'undefined') return html;
  if (!/sig|initial|canvas/i.test(html)) return html;
  const doc = new DOMParser().parseFromString(html, 'text/html');
  const body = doc.body; let changed = false;
  const rm = (el: Element) => { el.remove(); changed = true; };
  body.querySelectorAll(PAD).forEach(rm);
  body.querySelectorAll<HTMLInputElement>('input[type=hidden]').forEach(i => { if (SIG_NAME.test((i.name || '') + (i.id || ''))) rm(i); });
  body.querySelectorAll('.form-group,.field,.fg').forEach(g => {
    if (!g.isConnected) return;
    const inputs = Array.from(g.querySelectorAll<HTMLInputElement>('input,textarea,select'));
    if (inputs.some(i => /refus/i.test((i.name || '') + (i.placeholder || '')))) return;
    const lab = (g.querySelector('label,b,strong')?.textContent || '').trim();
    if (lab && SIG_LABEL.test(lab) && !NOT_SIG.test(lab)) { rm(g); return; }
    if (g.closest(BLOCK) && (BLOCK_FIELD.test(lab) || inputs.some(i => SIG_NAME.test(i.name || '')))) rm(g);
  });
  body.querySelectorAll(BLOCK).forEach(b => {
    if (!b.isConnected) return;
    if (!SIGNY_TEXT.test(b.textContent || '')) return;
    b.querySelectorAll('.form-group,.field,.fg').forEach(g => { if (g.querySelector('input,textarea,select')) b.before(g); });
    rm(b);
  });
  body.querySelectorAll<HTMLInputElement>('input').forEach(i => { if (/^initials?$/i.test((i.placeholder || '').trim())) rm(i.closest('p') || i); });
  if (!changed) return html;
  const dt = /^\s*<!doctype/i.test(html) ? '<!DOCTYPE html>\n' : '';
  return dt + doc.documentElement.outerHTML;
}

/** Form Studio field schemas: signature-type fields are not template fields any more. */
export const withoutSignatureFields = <T extends { type?: string }>(fields: T[]): T[] => (fields || []).filter(f => f.type !== 'signature');
