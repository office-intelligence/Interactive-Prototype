/*
 * v7 item 6: Appointment History on the patient chart.
 *  - Opens expanded on the current appointment (today); if none, the most recent one.
 *  - Shows every record for that encounter: appointment details, forms with status/signatures, station
 *    verifications, payment/invoice status and the latest audit events.
 *  - Choosing another encounter date in the dropdown shows only that encounter's records.
 * Encounters come from the cases and appointments stored in this browser (no mock visits).
 */
import React, { useMemo, useState } from 'react';
import { Calendar, ChevronDown, Lock, FileText, ShieldCheck, Receipt } from 'lucide-react';
import type { PatientCase } from '../types';
import { repo, fmtDateTime } from '../v6/dataLayer';
import { ruleFor } from '../v6/formRules';
import { VITYLS_FORM_CATALOG } from '../data/formWorkspaceCatalog';
import { usDateToKey } from '../v6/dates';
import { invoicesForCase } from './billing';
import { useBilling } from './InvoicePanel';

export interface Encounter { key: string; caseId?: string; date: string; time: string; procedure: string; surgeon: string; anesthesiologist?: string; room?: string; status?: string; payment?: string }
const todayKey = () => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; };
const title = (f: string) => VITYLS_FORM_CATALOG.find(c => c.file === f)?.title || f.replace(/_/g, ' ').replace('.html', '');

export function encountersFor(patient: PatientCase, cases: PatientCase[]): Encounter[] {
  const same = (c: Partial<PatientCase>) => (c.patientId && c.patientId === patient.patientId) || c.id === patient.id;
  const out: Encounter[] = [];
  cases.filter(same).forEach(c => out.push({ key: `case:${c.id}`, caseId: c.id, date: c.appointmentDate || '', time: c.scheduledTime || '', procedure: c.procedure, surgeon: c.surgeon, anesthesiologist: c.anesthesiologist, room: c.room, status: (c.encounterWorkflow?.status || c.stage || '').replace(/_/g, ' '), payment: c.paymentType }));
  try {
    (JSON.parse(localStorage.getItem('vityls:evaluation:appointments') || '[]') as any[])
      .filter(a => a.caseId ? cases.some(c => c.id === a.caseId && same(c)) || a.caseId === patient.id : a.patientName === patient.name)
      .forEach(a => { if (a.caseId && out.some(e => e.caseId === a.caseId)) { const e = out.find(x => x.caseId === a.caseId)!; e.date ||= a.dos; e.time ||= a.startTime; e.anesthesiologist ||= a.anesthesiologist; return; }
        out.push({ key: `apt:${a.id}`, caseId: a.caseId, date: a.dos || '', time: a.startTime || '', procedure: a.procedure || a.details || '', surgeon: a.surgeon || '', anesthesiologist: a.anesthesiologist, room: a.room, status: 'Scheduled', payment: a.paymentType }); });
  } catch { /* ignore */ }
  return out.filter(e => e.date || e.caseId).sort((a, b) => (usDateToKey(b.date) || '').localeCompare(usDateToKey(a.date) || ''));
}
export function defaultEncounter(list: Encounter[]): Encounter | undefined {
  const t = todayKey();
  return list.find(e => usDateToKey(e.date) === t) || list.find(e => (usDateToKey(e.date) || '') <= t) || list[list.length - 1];
}

export const AppointmentHistory: React.FC<{ patient: PatientCase; cases: PatientCase[]; onOpenWorkstations?: () => void }> = ({ patient, cases, onOpenWorkstations }) => {
  const list = useMemo(() => encountersFor(patient, cases), [patient, cases]);
  useBilling(); const [open, setOpen] = useState(true);
  const [sel, setSel] = useState<string | undefined>(() => defaultEncounter(list)?.key);
  const enc = list.find(e => e.key === sel) || defaultEncounter(list);
  const t = todayKey();
  const label = (e: Encounter) => `${e.date || 'Date not set'}${e.time ? ` · ${e.time}` : ''}${usDateToKey(e.date) === t ? ' (current)' : ''}`;
  const forms = enc?.caseId ? repo.listForms(enc.caseId).filter(r => r.status !== 'not-started') : [];
  const verif = enc?.caseId ? repo.getStationVerification(enc.caseId) : {};
  const audit = enc?.caseId ? repo.getAudit(enc.caseId).slice(-6).reverse() : [];
  const inv = enc?.caseId ? invoicesForCase(enc.caseId) : [];
  return <section id="appointments-section" className="scroll-mt-6 bg-white rounded-2xl border border-stone-200 overflow-hidden" data-testid="appointment-history">
    <button type="button" onClick={() => setOpen(o => !o)} className="w-full p-4 flex items-center justify-between gap-3 text-left min-h-[56px]" aria-expanded={open}>
      <div className="flex items-center gap-3 min-w-0"><span className="vy-dialog-icon"><Calendar /></span>
        <div className="min-w-0"><h3 className="vy-card-title">Appointment History <span className="vy-chip vy-chip-muted ml-1 align-middle">{list.length} encounter{list.length === 1 ? '' : 's'}</span></h3>
          <p className="vy-card-sub truncate">{enc ? `Showing ${label(enc)}` : 'No appointments yet'}</p></div></div>
      <ChevronDown className={`w-5 h-5 transition-transform ${open ? 'rotate-180' : ''}`} />
    </button>
    {open && <div className="px-4 pb-4 border-t border-stone-200 pt-4 space-y-4">
      {!enc ? <p className="text-[15px] text-[#3a463f]">No appointments for this patient yet. Schedule one from the Scheduler.</p> : <>
        <label className="flex flex-wrap items-center gap-2 text-[15px] font-semibold">Encounter date
          <select value={enc.key} onChange={e => setSel(e.target.value)} className="vy-input !w-auto min-w-[260px]" data-testid="encounter-select">{list.map(e => <option key={e.key} value={e.key}>{label(e)}</option>)}</select></label>
        {/* v7.2: one compact text summary instead of boxed cards */}
        <p className="text-[15px] leading-snug text-[#1f2a24]" data-testid="encounter-details">
          {[enc.procedure || 'Procedure not set', enc.surgeon || 'Surgeon unassigned', `Anesthesia ${enc.anesthesiologist || 'unassigned'}`, enc.room || 'Room not set', (enc.status ? String(enc.status).replace(/_/g, '-').toLowerCase().replace(/^\w/, c => c.toUpperCase()) : 'Scheduled'), enc.payment || 'Payment type not recorded'].join(' · ')}
        </p>
        <div><h4 className="vy-section-title flex items-center gap-1"><FileText className="w-4 h-4" /> Records for this encounter ({forms.length})</h4>
          {forms.length ? <div className="overflow-x-auto"><table className="vy-table" data-testid="encounter-records"><thead><tr><th>Form</th><th>Status</th><th>Signatures</th><th>Last change</th></tr></thead><tbody>
            {forms.map(r => { const rule = ruleFor(r.file); const req = rule.signers.filter(s => s.required); return <tr key={r.file}><td className="font-semibold">{title(r.file)}</td>
              <td>{r.status === 'locked' ? <span className="vy-chip vy-chip-ok"><Lock className="w-3.5 h-3.5" /> Signed & locked</span> : r.status === 'partially-signed' ? <span className="vy-chip vy-chip-warn">Partially signed</span> : <span className="vy-chip vy-chip-muted">Draft</span>}</td>
              <td>{r.signatures.length ? r.signatures.map(x => `${x.role}: ${x.signerName}`).join('; ') : `0 of ${req.length}`}</td><td>{fmtDateTime(r.lockedAt || r.updatedAt)}{r.updatedBy ? ` · ${r.updatedBy}` : ''}</td></tr>; })}
          </tbody></table></div> : <p className="text-[15px] text-[#3a463f]">No forms started for this encounter yet.</p>}
        </div>
        <div className="grid md:grid-cols-2 gap-3">
          <div><h4 className="vy-section-title flex items-center gap-1"><ShieldCheck className="w-4 h-4" /> Station verifications</h4>
            {Object.keys(verif).length ? <ul className="text-[14px] space-y-1">{Object.entries(verif).map(([k, v]) => <li key={k}><b>{k}</b> · {v.by} ({v.role}) · {fmtDateTime(v.at)}</li>)}</ul> : <p className="text-[14px] text-[#3a463f]">None yet.</p>}</div>
          <div><h4 className="vy-section-title flex items-center gap-1"><Receipt className="w-4 h-4" /> Invoices & payments</h4>
            {inv.length ? <ul className="text-[14px] space-y-1">{inv.map(i => <li key={i.id}><b>{i.number}</b> · ${i.total.toFixed(2)} · {i.status}{i.paid ? ` · paid $${i.paid.toFixed(2)}` : ''}</li>)}</ul> : <p className="text-[14px] text-[#3a463f]">No invoice yet.</p>}</div>
        </div>
        {audit.length > 0 && <div><h4 className="vy-section-title">Latest activity</h4><ul className="text-[14px] space-y-0.5">{audit.map(a => <li key={a.id}>{fmtDateTime(a.at)} · {a.user} — {a.detail}</li>)}</ul></div>}
        {onOpenWorkstations && enc.caseId && <button type="button" className="vy-btn vy-btn-secondary" onClick={onOpenWorkstations}>Review this encounter in the workstations</button>}
      </>}
    </div>}
  </section>;
};
