import React, { useCallback, useEffect, useState } from 'react';
import * as pdfjsLib from 'pdfjs-dist';
import { FilePlus2, FileText, Sparkles, ShieldCheck, Trash2, Eye, RefreshCw } from 'lucide-react';
import type { PatientCase } from '../types';
import { Btn, CardTitle, DialogShell, MaskedField, fieldErrors } from './ui';
import { ClearanceDoc, ClearanceSummary, DOC_TYPES, DocType, Finding, activeSummarizer, addDoc, confirmReview, getDocs, getState, markCleared, removeDoc, undoCleared } from './clearance';

const fmt = (iso?: string) => { if (!iso) return ''; try { return new Date(iso).toLocaleString(undefined, { month: '2-digit', day: '2-digit', year: 'numeric', hour: 'numeric', minute: '2-digit' }); } catch { return iso; } };
export function useClearance(caseId: string) {
  const [v, setV] = useState(0);
  useEffect(() => { const f = () => setV(x => x + 1); window.addEventListener('vityls-clearance-updated', f); return () => window.removeEventListener('vityls-clearance-updated', f); }, []);
  return { docs: getDocs(caseId), state: getState(caseId), v };
}
async function pdfText(file: File): Promise<string> {
  const doc = await pdfjsLib.getDocument({ data: new Uint8Array(await file.arrayBuffer()) }).promise; let out = '';
  for (let i = 1; i <= Math.min(doc.numPages, 20); i++) { const pg = await doc.getPage(i); const c = await pg.getTextContent(); out += c.items.map((x: any) => x.str).join(' ') + '\n'; }
  return out.trim();
}

/** 03 · Pre-op clearance files: reference table of every original document received (item 11). */
export const ClearanceFiles: React.FC<{ patient: PatientCase; actor?: string; onHide?: () => void }> = ({ patient, actor = 'Front Desk Tester', onHide }) => {
  const { docs, state } = useClearance(patient.id);
  const [adding, setAdding] = useState(false); const [viewing, setViewing] = useState<ClearanceDoc | null>(null);
  return <section id="clearanceFiles-section" className="vy-card p-5 scroll-mt-4" data-testid="clearance-files">
    <CardTitle kicker="Case Tracker · 03" title="Pre-op clearance files" sub="Every original clearance document received for this case (H&P, labs, ECG, consults, other records). Originals stay unchanged; Nightingale reads them for the review in 04."
      right={<div className="flex gap-2 flex-wrap"><Btn variant="add" icon={<FilePlus2 size={18} />} onClick={() => setAdding(true)} data-testid="add-clearance-doc">Add document</Btn>{onHide && <Btn variant="ghost" onClick={onHide} data-testid="hide-clearanceFiles">Hide</Btn>}</div>} />
    <div className="overflow-x-auto mt-4"><table className="vy-table" data-testid="clearance-table"><thead><tr><th>Type</th><th>Document</th><th>Source</th><th>Document date</th><th>Received</th><th>Status</th><th className="text-right">Original</th></tr></thead>
      <tbody>{!docs.length ? <tr><td colSpan={7} className="text-[#4a5750]">No clearance documents yet. Add the H&P, labs, ECG and any other records as they arrive.</td></tr> : docs.map(d => <tr key={d.id}>
        <td>{d.type}</td><td className="font-semibold">{d.title}{d.fileName ? <div className="text-[13px] font-normal text-[#4a5750]">{d.fileName}</div> : null}</td><td>{d.source || '—'}</td><td>{d.docDate || '—'}</td><td>{fmt(d.receivedAt)}<div className="text-[13px] text-[#4a5750]">{d.receivedBy}</div></td>
        <td><span className={d.status === 'Reviewed' ? 'vy-chip-ok' : 'vy-chip-info'}>{d.status}</span></td>
        <td className="text-right whitespace-nowrap"><Btn variant="secondary" icon={<Eye size={16} />} onClick={() => setViewing(d)}>View</Btn>{!state.review && <Btn variant="ghost" aria-label={`Remove ${d.title}`} icon={<Trash2 size={16} />} onClick={() => { if (confirm(`Remove “${d.title}”? This is logged.`)) removeDoc(patient.id, d.id, actor); }} />}</td></tr>)}</tbody></table></div>
    {adding && <AddDocDialog caseId={patient.id} actor={actor} onClose={() => setAdding(false)} />}
    {viewing && <DialogShell size="lg" kicker={viewing.type} title={viewing.title} subtitle={`${viewing.source || 'Source not recorded'} · ${viewing.docDate || 'date not recorded'}`} onClose={() => setViewing(null)} footer={<Btn variant="primary" onClick={() => setViewing(null)}>Close</Btn>}>
      {viewing.dataUrl && (/pdf/.test(viewing.mime || '') ? <iframe title="original" src={viewing.dataUrl} className="w-full h-[50vh] border rounded" /> : /image/.test(viewing.mime || '') ? <img src={viewing.dataUrl} alt={viewing.title} className="max-w-full border rounded" /> : <a className="underline" href={viewing.dataUrl} download={viewing.fileName}>Download original</a>)}
      {!viewing.dataUrl && viewing.fileName && <p className="text-[14px] text-[#4a5750]">The original file was too large to keep in this browser build; only its text is stored.</p>}
      <div className="vy-label mt-3">Text used for the review</div><pre className="whitespace-pre-wrap text-[15px] font-sans p-3 rounded-lg bg-[#f5f8f6] border border-[#dfe5e1]">{viewing.text || '(no readable text)'}</pre>
    </DialogShell>}
  </section>;
};

const AddDocDialog: React.FC<{ caseId: string; actor: string; onClose: () => void }> = ({ caseId, actor, onClose }) => {
  const [f, setF] = useState({ type: '' as DocType | '', title: '', source: '', docDate: '', text: '' });
  const [file, setFile] = useState<{ name: string; mime: string; dataUrl?: string } | null>(null); const [msg, setMsg] = useState(''); const [tried, setTried] = useState(false);
  const errs = [...(!f.type ? ['Choose the document type'] : []), ...(!f.title.trim() ? ['Enter a document title'] : []), ...(!f.text.trim() && !file ? ['Attach the file or enter its text'] : []), ...fieldErrors([{ kind: 'date', value: f.docDate, past: true }])];
  const onFile = async (fl?: File) => {
    if (!fl) return; setMsg('Reading file…');
    const dataUrl = fl.size < 1.5e6 ? await new Promise<string>(r => { const rd = new FileReader(); rd.onload = () => r(String(rd.result)); rd.readAsDataURL(fl); }) : undefined;
    setFile({ name: fl.name, mime: fl.type, dataUrl }); setF(x => ({ ...x, title: x.title || fl.name.replace(/\.[^.]+$/, '') }));
    try { const t = /text|json|csv/.test(fl.type) || /\.txt$/i.test(fl.name) ? await fl.text() : /pdf/.test(fl.type) ? await pdfText(fl) : '';
      if (t) { setF(x => ({ ...x, text: t })); setMsg(`Read ${t.length.toLocaleString()} characters of text from the file. Check it below.`); } else setMsg('No text could be read (image or scan). Type or paste the key findings below so the review can use them.');
    } catch { setMsg('This browser build could not read text from the file. Type or paste the key findings below.'); }
  };
  const save = (e?: React.FormEvent) => { e?.preventDefault(); setTried(true); if (errs.length) return;
    try { addDoc({ id: `doc-${Date.now()}`, caseId, type: f.type as DocType, title: f.title.trim(), source: f.source.trim(), docDate: f.docDate, receivedAt: new Date().toISOString(), receivedBy: actor, fileName: file?.name, mime: file?.mime, dataUrl: file?.dataUrl, text: f.text, status: 'Received' }); onClose(); } catch (er: any) { setMsg(er.message); } };
  return <DialogShell as="form" onSubmit={save} size="lg" testId="clearance-doc-dialog" kicker="Pre-op clearance files" title="Add clearance document" onClose={onClose}
    footer={<><Btn variant="secondary" onClick={onClose}>Cancel</Btn><Btn type="submit" variant="add" data-testid="save-clearance-doc">Add to clearance file</Btn></>}>
    <div className="grid sm:grid-cols-2 gap-3">
      <label className="vy-label">Document type *<select className="vy-input" value={f.type} onChange={e => setF({ ...f, type: e.target.value as DocType })} data-testid="cd-type"><option value="">Select…</option>{DOC_TYPES.map(t => <option key={t}>{t}</option>)}</select></label>
      <label className="vy-label">Title *<input className="vy-input" value={f.title} onChange={e => setF({ ...f, title: e.target.value })} data-testid="cd-title" /></label>
      <label className="vy-label">Source (sender)<input className="vy-input" value={f.source} onChange={e => setF({ ...f, source: e.target.value })} placeholder="Clinic, lab or physician" /></label>
      <MaskedField label="Document date" kind="date" past value={f.docDate} onChange={v => setF({ ...f, docDate: v })} showErrors={tried} testId="cd-date" />
    </div>
    <label className="vy-label mt-3 block">Original file (PDF, image or text)<input type="file" accept=".pdf,.txt,image/*" className="vy-input" onChange={e => onFile(e.target.files?.[0])} data-testid="cd-file" /></label>
    {msg && <p className="text-[14px] text-[#4a5750] mt-1" role="status">{msg}</p>}
    <label className="vy-label mt-3 block">Document text / key findings<textarea className="vy-input min-h-[140px]" value={f.text} onChange={e => setF({ ...f, text: e.target.value })} data-testid="cd-text" placeholder="Filled automatically from text and PDF files; type or paste for scans." /></label>
    {tried && errs.length > 0 && <div className="mt-3 p-3 rounded-lg bg-[#FDECEC] border border-[#f1b9b9] text-[#7f1d1d] text-[15px]" role="alert"><ul className="list-disc ml-5">{errs.map(e => <li key={e}>{e}</li>)}</ul></div>}
  </DialogShell>;
};

const sevChip = (s: Finding['severity']) => s === 'critical' ? 'vy-chip-bad' : s === 'attention' ? 'vy-chip-warn' : 'vy-chip-muted';
const FindingList: React.FC<{ title: string; items: Finding[]; empty: string; testId: string }> = ({ title, items, empty, testId }) => <div data-testid={testId}>
  <h4 className="vy-section-title">{title} ({items.length})</h4>
  {!items.length ? <p className="text-[14px] text-[#4a5750] mt-1">{empty}</p> : <ul className="mt-1 space-y-1">{items.map((x, i) => <li key={i} className="flex gap-2 items-start text-[15px]"><span className={sevChip(x.severity)}>{x.severity === 'critical' ? 'Critical' : x.severity === 'attention' ? 'Review' : 'Info'}</span><span>{x.text}{x.doc ? <span className="text-[13.5px] text-[#4a5750]"> · {x.doc}</span> : null}</span></li>)}</ul>}
</div>;

/** 04 · Review & alerts (Nightingale summary) and 05 · Clearance (human only). */
export const ClearanceReview: React.FC<{ patient: PatientCase; onHide?: () => void }> = ({ patient, onHide }) => {
  const { docs, state, v } = useClearance(patient.id);
  const [sum, setSum] = useState<ClearanceSummary | null>(state.summary || null); const [busy, setBusy] = useState(false);
  const [name, setName] = useState(''); const [read, setRead] = useState(false); const [err, setErr] = useState(''); const [clearNote, setClearNote] = useState(''); const [attest, setAttest] = useState(false);
  const eng = activeSummarizer();
  const run = useCallback(async () => { setBusy(true); try { const s = await eng.summarize(patient, getDocs(patient.id)); setSum(s); } finally { setBusy(false); } }, [patient, eng]);
  useEffect(() => { run(); }, [v, patient.id]); // re-run when documents change
  const stale = !!state.review && !!sum && docs.some(d => !sum.docsReviewed.includes(d.id));
  const act = (fn: () => void) => { setErr(''); try { fn(); } catch (e: any) { setErr(e.message); } };
  return <section id="clearanceReview-section" className="vy-card p-5 scroll-mt-4" data-testid="clearance-review">
    <CardTitle kicker="Case Tracker · 04" title="Review & alerts" sub="Nightingale reads the clearance file and drafts a summary for a clinician. A person confirms the review and clears the patient; Nightingale never signs or clears."
      right={<div className="flex gap-2 flex-wrap"><Btn variant="secondary" icon={<RefreshCw size={16} />} onClick={run} disabled={busy}>Re-run review</Btn>{onHide && <Btn variant="ghost" onClick={onHide} data-testid="hide-clearanceReview">Hide</Btn>}</div>} />
    <div className="mt-3 inline-flex items-center gap-2 px-3 py-1.5 rounded-lg bg-[#F3F4F2] border border-[#d6ded9] text-[14px]" data-testid="summary-engine"><Sparkles size={16} className="text-[#1f6e52]" /> {eng.kind === 'rule-based' ? 'Rule-based summary (no AI key)' : eng.label}</div>
    {sum && <>
      <div className="mt-3 p-4 rounded-lg bg-[#f7faf8] border border-[#dfe5e1] space-y-2 text-[16px] leading-relaxed" data-testid="summary-narrative">{sum.narrative.map((t, i) => <p key={i} className={i === sum.narrative.length - 1 ? 'text-[14px] text-[#4a5750]' : ''}>{t}</p>)}</div>
      <div className="grid md:grid-cols-2 gap-4 mt-4">
        <FindingList testId="sum-abnormal" title="Abnormal findings" items={sum.abnormal} empty="None detected by the rules." />
        <FindingList testId="sum-missing" title="Missing information" items={sum.missing} empty="Nothing missing under current rules." />
        <FindingList testId="sum-concerns" title="Other clearance concerns" items={sum.concerns} empty="None found." />
        <FindingList testId="sum-history" title="Significant history" items={sum.history} empty="None found in readable text." />
        <FindingList testId="sum-allergies" title="Allergies" items={sum.allergies} empty="—" />
      </div>
      <p className="text-[13.5px] text-[#4a5750] mt-2">Generated {fmt(sum.generatedAt)} from {docs.length} document{docs.length === 1 ? '' : 's'}.</p>
    </>}
    <div className="mt-5 grid lg:grid-cols-2 gap-4">
      <div className="p-4 rounded-lg border border-[#dfe5e1]" data-testid="review-confirm">
        <h4 className="vy-section-title">Clinician review</h4>
        {state.review ? <p className="mt-1 text-[15px]"><span className="vy-chip-ok">Reviewed</span> by <b className="font-semibold">{state.review.by}</b> · {fmt(state.review.at)}{stale && <span className="block mt-1 text-[#7a5414]">New documents arrived after this review. Review them and confirm again.</span>}</p> : <p className="text-[14px] text-[#4a5750] mt-1">Read the original documents, then confirm.</p>}
        {(!state.review || stale) && <div className="mt-2 space-y-2"><label className="vy-label">Your name and credentials<input className="vy-input" value={name} onChange={e => setName(e.target.value)} placeholder="e.g. Jordan Lee, MD" data-testid="review-name" /></label>
          <label className="flex gap-2 items-start text-[15px] min-h-[44px]"><input type="checkbox" className="w-5 h-5 mt-0.5" checked={read} onChange={e => setRead(e.target.checked)} data-testid="review-read" /> I reviewed the original clearance documents, not only this summary.</label>
          <Btn variant="confirm" icon={<ShieldCheck size={18} />} disabled={!name.trim() || !read} onClick={() => act(() => confirmReview(patient.id, name.trim()))} data-testid="confirm-review">Confirm review</Btn></div>}
      </div>
      <div className="p-4 rounded-lg border border-[#dfe5e1]" data-testid="clearance-decision">
        <h4 className="vy-section-title">Case Tracker · 05 · Clearance decision</h4>
        {state.cleared ? <><p className="mt-1 text-[15px]"><span className="vy-chip-ok">Cleared for surgery</span> by <b className="font-semibold">{state.cleared.by}</b> · {fmt(state.cleared.at)}{state.cleared.note ? ` · ${state.cleared.note}` : ''}</p><Btn variant="danger" className="mt-2" onClick={() => act(() => undoCleared(patient.id, name || state.cleared!.by))}>Withdraw clearance</Btn></> :
          <div className="mt-2 space-y-2"><p className="text-[14px] text-[#4a5750]">{state.review ? 'A clinician decides. Missing items and alerts above should be resolved or documented first.' : 'Available after the clinician review is confirmed.'}</p>
            <label className="vy-label">Clearance note (optional)<input className="vy-input" value={clearNote} onChange={e => setClearNote(e.target.value)} disabled={!state.review} /></label>
            <label className="flex gap-2 items-start text-[15px] min-h-[44px]"><input type="checkbox" className="w-5 h-5 mt-0.5" checked={attest} onChange={e => setAttest(e.target.checked)} disabled={!state.review} data-testid="clear-attest" /> I am clearing this patient for surgery based on my own review.</label>
            <Btn variant="confirm" disabled={!state.review || !attest || !(name.trim() || state.review?.by)} onClick={() => act(() => markCleared(patient.id, (name.trim() || state.review!.by), clearNote.trim()))} data-testid="mark-cleared">Mark cleared for surgery</Btn></div>}
      </div>
    </div>
    {err && <p className="mt-3 text-[15px] text-[#8a2a2a]" role="alert">{err}</p>}
  </section>;
};
