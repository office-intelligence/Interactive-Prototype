/*
 * v7 items 7–9: one provider registry (surgeons, anesthesiologists, other providers) used by
 * Administration → Providers, the Scheduler typeaheads, appointment colors and staff signature PINs.
 * Credentialing applications: v7.3 sends one (simulated) invitation email per provider; see invitations.ts.
 */
export type ProviderRole = 'Surgeon' | 'Anesthesiologist' | 'CRNA' | 'Other provider';
export const CRED_STEPS = ['Queued', 'Invited', 'Application received', 'Credentials verified', 'Medical Director review', 'Privileges approved'] as const;
export type CredStatus = typeof CRED_STEPS[number] | 'Declined';
/** history.status is a CredStatus or a v7.3 onboarding event: 'Invitation resent' · 'Account created' · 'PIN set'. */
export interface CredApp { id: string; status: CredStatus; createdAt: string; history: { status: CredStatus | string; at: string; by: string; note?: string }[] }
/** v7.3 self-service onboarding milestones (set from the three invitation links). */
export interface Onboarding { invitedAt?: string; applicationAt?: string; accountAt?: string; pinAt?: string; username?: string; inviteCount?: number; lastInviteId?: string; application?: Record<string, string | string[]> }
export interface Provider { id: string; firstName: string; lastName: string; degree: string; role: ProviderRole; specialty: string; npi: string; email: string; phone: string; color: string; pinHash: string; active: boolean; app: CredApp; onboarding?: Onboarding;
  /** v7.4 account controls */ locked?: boolean; pinFailures?: number; lockedAt?: string; deactivatedAt?: string; deactivatedBy?: string; deactivationReason?: string }
const KEY = 'vityls:v7:providers';
/** Accessible appointment colors (white text ≥ 4.5:1 on each). */
export const PROVIDER_COLORS = ['#1F6E52', '#1D4ED8', '#7C3AED', '#B45309', '#BE123C', '#0F766E', '#4338CA', '#9D174D', '#475569', '#A16207'];
export const displayName = (p: Pick<Provider, 'firstName' | 'lastName' | 'degree'>) => `${p.firstName} ${p.lastName}`.trim() + (p.degree ? `, ${p.degree}` : '');
/** Evaluation-only PIN hash (not cryptographic). Production: server-side salted hash + re-authentication. */
export const hashPin = (pin: string) => { let h = 5381; for (const c of `vy7|${pin}`) h = ((h << 5) + h + c.charCodeAt(0)) >>> 0; return `e7${h.toString(16)}`; };
const now = () => new Date().toISOString();
const seedApp = (id: string, status: CredStatus): CredApp => ({ id: `APP-${id}`, status, createdAt: now(), history: [{ status: 'Queued', at: now(), by: 'Seed data' }, ...(status !== 'Queued' ? [{ status, at: now(), by: 'Seed data' }] : [])] });
export const SEED_PROVIDERS: Provider[] = [
  { id: 'prov-patel', firstName: 'Sam', lastName: 'Patel', degree: 'MD', role: 'Surgeon', specialty: 'Plastic Surgery', npi: '', email: '', phone: '', color: '#1D4ED8', pinHash: hashPin('1234'), active: true, app: seedApp('patel', 'Privileges approved') },
  { id: 'prov-lee', firstName: 'Jordan', lastName: 'Lee', degree: 'MD', role: 'Anesthesiologist', specialty: 'Anesthesiology', npi: '', email: '', phone: '', color: '#0F766E', pinHash: hashPin('1234'), active: true, app: seedApp('lee', 'Privileges approved') },
  { id: 'prov-nguyen', firstName: 'Riley', lastName: 'Nguyen', degree: 'MD', role: 'Surgeon', specialty: 'General Surgery', npi: '', email: '', phone: '', color: '#B45309', pinHash: hashPin('1234'), active: true, app: seedApp('nguyen', 'Credentials verified') },
  { id: 'prov-chen', firstName: 'Morgan', lastName: 'Chen', degree: 'CRNA', role: 'CRNA', specialty: 'Nurse Anesthesia', npi: '', email: '', phone: '', color: '#7C3AED', pinHash: hashPin('1234'), active: true, app: seedApp('chen', 'Privileges approved') },
];
/** Seeded providers were onboarded before this build: account and PIN already exist. */
const SEEDED_ONBOARDING = (): Onboarding => ({ invitedAt: now(), applicationAt: now(), accountAt: now(), pinAt: now(), username: '(seeded)' });
const migrate = (p: Provider): Provider => {
  const app = p.app.status === ('Application sent (simulated)' as any) ? { ...p.app, status: 'Invited' as CredStatus } : p.app;
  return { ...p, app, onboarding: p.onboarding || (p.pinHash ? SEEDED_ONBOARDING() : {}) };
};
export function getProviders(): Provider[] { try { const r = localStorage.getItem(KEY); if (r) return (JSON.parse(r) as Provider[]).map(migrate); } catch { /* */ } return SEED_PROVIDERS.map(migrate); }
export function saveProviders(list: Provider[]) {
  try { localStorage.setItem(KEY, JSON.stringify(list)); localStorage.setItem('vityls:practice-providers:v1', JSON.stringify(list.map(p => ({ id: p.id, name: displayName(p), specialty: p.specialty, color: p.color, credentialStatus: p.app.status })))); } catch { /* */ }
  try { window.dispatchEvent(new Event('vityls-providers-updated')); } catch { /* */ }
}
export function upsertProvider(p: Provider) { const l = getProviders(); const i = l.findIndex(x => x.id === p.id); if (i >= 0) l[i] = p; else l.push(p); saveProviders(l); }
export function advanceApp(id: string, to: CredStatus, by: string, note?: string) {
  const l = getProviders(); const p = l.find(x => x.id === id); if (!p) return;
  p.app = { ...p.app, status: to, history: [...p.app.history, { status: to, at: now(), by, note }] }; saveProviders(l);
}
export const newApp = (by: string): CredApp => ({ id: `APP-${Date.now().toString(36).toUpperCase()}`, status: 'Queued', createdAt: now(), history: [{ status: 'Queued', at: now(), by, note: 'Membership & privileges application created and queued.' }] });
const norm = (s: string) => s.toLowerCase().replace(/[^a-z0-9 ]/g, ' ').replace(/\s+/g, ' ').trim();
export function findProvider(name?: string): Provider | undefined {
  if (!name) return; const n = norm(name.replace(/^dr\.?\s+/i, '').replace(/,.*$/, ''));
  return getProviders().find(p => norm(`${p.firstName} ${p.lastName}`) === n || norm(displayName(p)) === norm(name));
}
export function searchProviders(q: string, roles: ProviderRole[]) {
  const n = norm(q.replace(/^dr\.?\s*/i, '')); if (n.length < 3) return [];
  return getProviders().filter(p => p.active && roles.includes(p.role) && norm(`${p.firstName} ${p.lastName} ${p.specialty} ${p.npi}`).includes(n));
}
/** v7.4: relative luminance of a #rrggbb color. */
export function luminance(hex: string) {
  const m = normalizeHex(hex)?.slice(1).match(/.{2}/g); if (!m) return 0;
  const [r, g, b] = m.map(x => { const c = parseInt(x, 16) / 255; return c <= 0.03928 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4; });
  return 0.2126 * r + 0.7152 * g + 0.0722 * b;
}
export const contrast = (a: string, b: string) => { const x = luminance(a), y = luminance(b); return (Math.max(x, y) + 0.05) / (Math.min(x, y) + 0.05); };
/** Accepts #rgb or #rrggbb (with or without #); returns lower-case #rrggbb or null. */
export function normalizeHex(v: string): string | null {
  const t = (v || '').trim().replace(/^#?/, '#');
  if (/^#[0-9a-f]{3}$/i.test(t)) return ('#' + t.slice(1).split('').map(c => c + c).join('')).toLowerCase();
  return /^#[0-9a-f]{6}$/i.test(t) ? t.toLowerCase() : null;
}
/** Readable text on any provider color: white or near-black, whichever contrasts more (always ≥ 4.5:1). */
export function textOn(hex: string) {
  if (!normalizeHex(hex)) return '#ffffff';
  const dark = contrast(hex, '#0f1a14') >= 4.5 ? '#0f1a14' : '#000000';
  return contrast(hex, '#ffffff') >= contrast(hex, dark) ? '#ffffff' : dark;
}
export const colorForSurgeon = (name?: string) => findProvider(name)?.color;
/** A staff signer whose name matches a registered provider must enter that provider's PIN. */
export type PinCheck = 'ok' | 'wrong' | 'unregistered' | 'locked' | 'inactive' | 'nopin';
/** Reasons a registered provider cannot sign at all (checked before any PIN is typed). */
export function signBlock(signerName: string): Exclude<PinCheck, 'ok' | 'wrong' | 'unregistered'> | null {
  const p = findProvider(signerName); if (!p) return null;
  if (!p.active) return 'inactive'; if (p.locked) return 'locked'; if (!p.pinHash) return 'nopin'; return null;
}
export function checkSignerPin(signerName: string, pin: string): PinCheck {
  const p = findProvider(signerName); if (!p) return 'unregistered';
  const b = signBlock(signerName); if (b) return b;
  return p.pinHash === hashPin(pin) ? 'ok' : 'wrong';
}
export const MAX_PIN_FAILURES = 5;
