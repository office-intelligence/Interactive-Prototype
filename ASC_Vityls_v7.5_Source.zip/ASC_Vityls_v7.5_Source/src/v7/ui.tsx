/*
 * v7 shared UI (items 4, 15, 19, 20): one dialog shell (header + footer), one semantic button set,
 * one card title and one page header modelled on the Workstation header. Styling lives in index.css
 * under the `vy-` prefix so non-React screens (and legacy dialogs) can use the same tokens.
 */
import React, { useEffect, useId, useState } from 'react';
import { X } from 'lucide-react';
import { MaskKind, MASK_ATTRS, formatFor, validate } from './masks';
import { ALLERGY_STYLE, effectiveAllergy } from './allergy';

export type BtnVariant = 'primary' | 'secondary' | 'confirm' | 'edit' | 'add' | 'danger' | 'ghost';
export const btnClass = (v: BtnVariant = 'secondary', extra = '') => `vy-btn vy-btn-${v} ${extra}`.trim();
export const Btn: React.FC<React.ButtonHTMLAttributes<HTMLButtonElement> & { variant?: BtnVariant; icon?: React.ReactNode }> = ({ variant = 'secondary', icon, className = '', children, type = 'button', ...rest }) =>
  <button type={type} className={btnClass(variant as BtnVariant, className as string)} {...rest}>{icon}{children}</button>;

/** The one dialog used app-wide: dim backdrop, shared header (icon, title, subtitle, close) and footer. */
export const DialogShell: React.FC<{
  title: React.ReactNode; subtitle?: React.ReactNode; icon?: React.ReactNode; kicker?: string;
  onClose: () => void; footer?: React.ReactNode; children: React.ReactNode; size?: 'sm' | 'md' | 'lg' | 'xl';
  testId?: string; as?: 'div' | 'form'; onSubmit?: (e: React.FormEvent) => void; zIndex?: number;
}> = ({ title, subtitle, icon, kicker, onClose, footer, children, size = 'md', testId, as = 'div', onSubmit, zIndex }) => {
  const id = useId();
  useEffect(() => { const k = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose(); }; window.addEventListener('keydown', k); return () => window.removeEventListener('keydown', k); }, [onClose]);
  const Body = as as any;
  return <div className="vy-backdrop" style={zIndex ? { zIndex } : undefined} onMouseDown={e => { if (e.target === e.currentTarget) onClose(); }}>
    <Body className={`vy-dialog vy-dialog-${size}`} role="dialog" aria-modal="true" aria-labelledby={id} data-testid={testId} onSubmit={onSubmit} noValidate={as === 'form' ? true : undefined}>
      <DialogHeader id={id} title={title} subtitle={subtitle} icon={icon} kicker={kicker} onClose={onClose} />
      <div className="vy-dialog-body">{children}</div>
      {footer && <DialogFooter>{footer}</DialogFooter>}
    </Body>
  </div>;
};
export const DialogHeader: React.FC<{ id?: string; title: React.ReactNode; subtitle?: React.ReactNode; icon?: React.ReactNode; kicker?: string; onClose?: () => void }> = ({ id, title, subtitle, icon, kicker, onClose }) =>
  <header className="vy-dialog-header">
    {icon && <span className="vy-dialog-icon" aria-hidden>{icon}</span>}
    <div className="min-w-0 flex-1">{kicker && <div className="vy-kicker">{kicker}</div>}<h2 id={id} className="vy-dialog-title">{title}</h2>{subtitle && <p className="vy-dialog-subtitle">{subtitle}</p>}</div>
    {onClose && <button type="button" onClick={onClose} className="vy-icon-btn" aria-label="Close"><X className="w-5 h-5" /></button>}
  </header>;
/** Footer: optional left content (e.g. destructive), then actions right-aligned; primary goes last (far right). */
export const DialogFooter: React.FC<{ children: React.ReactNode; left?: React.ReactNode }> = ({ children, left }) =>
  <footer className="vy-dialog-footer">{left && <div className="mr-auto flex gap-2">{left}</div>}<div className="ml-auto flex flex-wrap gap-2 justify-end">{children}</div></footer>;

/** Standard card title (item 20). */
export const CardTitle: React.FC<{ kicker?: string; title: React.ReactNode; sub?: React.ReactNode; right?: React.ReactNode; as?: 'h2' | 'h3' }> = ({ kicker, title, sub, right, as = 'h2' }) => {
  const H = as as any;
  return <div className="vy-card-head"><div className="min-w-0">{kicker && <div className="vy-kicker">{kicker}</div>}<H className="vy-card-title">{title}</H>{sub && <p className="vy-card-sub">{sub}</p>}</div>{right && <div className="flex-none">{right}</div>}</div>;
};
/** Page header modelled on the Workstation header (item 15). */
export const PageHeader: React.FC<{ kicker?: string; title: React.ReactNode; sub?: React.ReactNode; right?: React.ReactNode; testId?: string }> = ({ kicker, title, sub, right, testId }) =>
  <div className="vy-page-header" data-testid={testId}><div className="min-w-0">{kicker && <div className="vy-page-kicker">{kicker}</div>}<div className="vy-page-title">{title}</div>{sub && <div className="vy-page-sub">{sub}</div>}</div>{right && <div className="flex-none flex gap-2 flex-wrap">{right}</div>}</div>;

/** Label + masked input + validation message. `required` shows an error only after the user leaves the field (or `showErrors`). */
export const MaskedField: React.FC<{ label: React.ReactNode; kind: MaskKind; value: string; onChange: (v: string) => void; required?: boolean; past?: boolean; showErrors?: boolean; testId?: string; className?: string; inputClassName?: string; name?: string }> = ({ label, kind, value, onChange, required, past, showErrors, testId, className = '', inputClassName = 'vy-input', name }) => {
  const [touched, setTouched] = useState(false); const id = useId(); const a = MASK_ATTRS[kind];
  const err = validate(kind, value, { past }) || (required && !value.trim() ? 'Required' : '');
  const show = !!err && (touched || showErrors);
  return <div className={className}>
    <label htmlFor={id} className="vy-label">{label}{required && <span className="text-[#B42318]" aria-hidden> *</span>}</label>
    <input id={id} name={name} type={a.type} inputMode={a.inputMode} maxLength={a.maxLength} placeholder={a.placeholder} autoComplete="off" value={value}
      onChange={e => onChange(kind === 'email' ? e.target.value : formatFor(kind, e.target.value))} onBlur={() => { setTouched(true); if (kind === 'email') onChange(value.trim()); }}
      aria-invalid={show || undefined} aria-describedby={show ? `${id}-e` : undefined} className={`${inputClassName} ${show ? 'vy-input-invalid' : ''}`} data-testid={testId} />
    {show && <p id={`${id}-e`} className="vy-field-error" role="alert">{err}</p>}
  </div>;
};
export const fieldErrors = (fields: { kind: MaskKind; value: string; required?: boolean; past?: boolean }[]) => fields.map(f => validate(f.kind, f.value, { past: f.past }) || (f.required && !f.value.trim() ? 'Required' : '')).filter(Boolean);

/** Allergy status chip/box (item 1 / v7.5). Reported allergies replace Not Reported; never concatenate. */
export const AllergyStatus: React.FC<{ allergies?: string[] | string | null; label?: string; compact?: boolean; testId?: string; patientId?: string }> = ({ allergies, label = 'Drug allergies', compact, testId, patientId }) => {
  const a = effectiveAllergy(allergies, patientId);
  const note = a.pendingConfirm ? `Patient-reported on ${a.sourceForm || 'intake'} · confirm at Pre-op Nursing` : '';
  const s = ALLERGY_STYLE[a.state];
  if (compact) return <span className={`inline-flex items-center gap-1 border rounded-md px-2 py-0.5 text-[13px] font-semibold ${s.box} ${s.text}`} data-testid={testId} data-allergy-state={a.state}>{a.state === 'allergies' ? `Allergies: ${a.text}` : a.text}</span>;
  return <div className={`border rounded-md px-4 py-3 ${s.box}`} data-testid={testId} data-allergy-state={a.state}><div className="vy-kicker !text-[#39443E]">{label}</div><div className={`mt-1 text-[15px] font-semibold ${s.text}`}>{a.text}</div>{note && <div className="mt-0.5 text-[13px] text-[#39443E]" data-testid="allergy-reported-note">{note}</div>}</div>;
};
