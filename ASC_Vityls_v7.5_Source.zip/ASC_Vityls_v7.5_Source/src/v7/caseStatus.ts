/*
 * v7.3 Dashboard case colors. Derived from the same sources as the Case Tracker (DayOfSurgeryJourney: booking,
 * intake forms from My Forms, clearance files, Review & alerts, Clearance) and the allergy rules (allergy.ts).
 *   hold    (light red)  : hard stop — clearance documents received but the Review & alerts not cleared by a
 *                          clinician, patient-reported allergies awaiting clinician confirmation, or a critical lab.
 *   pending (amber)      : something missing or waiting — no clearance documents, allergy status not reported,
 *                          intake forms incomplete, clearance decision pending, no date of service.
 *   clear   (light blue) : cleared for surgery by a clinician and nothing missing — moving forward.
 */
import type { PatientCase } from '../types';
import { getDocs, getState } from './clearance';
import { effectiveAllergy } from './allergy';
import { stationPlan } from './myForms';
import { repo } from '../v6/dataLayer';

export type CaseTone = 'clear' | 'pending' | 'hold';
export interface CaseStatus { tone: CaseTone; label: string; reasons: string[] }
export const TONE_LABEL: Record<CaseTone, string> = { clear: 'Cleared · moving forward', pending: 'Missing or pending items', hold: 'Hold' };
/** Background / border / chip colors. All text on these backgrounds is #17271f or #3a463f (≥ 7:1). */
export const TONE_STYLE: Record<CaseTone, { bg: string; border: string; chipBg: string; chipText: string; bar: string }> = {
  clear: { bg: '#E7F0FB', border: '#B4CDEB', chipBg: '#CFE0F6', chipText: '#163A63', bar: '#2F6DB5' },
  pending: { bg: '#FCF1D6', border: '#E8CD86', chipBg: '#F6DFA3', chipText: '#5C3D05', bar: '#B7791F' },
  hold: { bg: '#FBE6E6', border: '#EBB3B3', chipBg: '#F5CACA', chipText: '#7A1C1C', bar: '#C0392B' },
};

export function caseStatus(p: PatientCase): CaseStatus {
  const docs = getDocs(p.id), st = getState(p.id);
  const hold: string[] = [], pend: string[] = [];
  if (p.labs?.some(l => l.status === 'critical') || p.readinessLevel === 'CRITICAL_HOLD') hold.push('Critical lab result');
  if (docs.length && !st.review) hold.push('Review & alerts not cleared by a clinician');
  const al = effectiveAllergy(p.allergies, p.id);
  if (al.pendingConfirm) hold.push('Allergy confirmation needed (patient-reported)');
  if (!docs.length) pend.push('No clearance documents yet');
  if (al.state === 'not-reported') pend.push('Allergy status not reported');
  const intake = [...stationPlan('patientPortal').required, ...stationPlan('patientPortal').asNeeded];
  const intakeDone = intake.filter(f => repo.getForm(p.id, f).status === 'locked').length;
  if (intake.length && intakeDone < intake.length) pend.push(`Intake forms ${intakeDone} of ${intake.length} complete`);
  if (docs.length && st.review && !st.cleared) pend.push('Clearance decision pending');
  if (!(p.appointmentDate || '').trim() && (!p.scheduledTime || /not scheduled|hold/i.test(p.scheduledTime))) pend.push('Date of service missing');
  if (!st.cleared && !hold.length && !pend.length) pend.push('Not cleared for surgery yet');
  const tone: CaseTone = hold.length ? 'hold' : st.cleared && !pend.length ? 'clear' : 'pending';
  return { tone, label: TONE_LABEL[tone], reasons: tone === 'hold' ? [...hold, ...pend] : tone === 'pending' ? pend : [`Cleared by ${st.cleared!.by}`] };
}
