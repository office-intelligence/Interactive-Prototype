/*
 * v7.3 Provider onboarding pages opened from the invitation email's three links (#invite=<purpose>&t=<token>).
 * Production: these become portal routes (/invite/<purpose>/<token>) backed by the token, application and auth
 * endpoints described in invitations.ts.
 */
import React, { useMemo, useState } from 'react';
import { CheckCircle2, ClipboardList, KeyRound, Lock, AlertTriangle, ArrowRight } from 'lucide-react';
import { Btn, MaskedField, fieldErrors } from './ui';
import { displayName } from './providers';
import { InvitePurpose, PURPOSE_LABEL, PURPOSES, TokenCheck, createAccount, parseInviteHash, passwordProblems, pinProblems, resolveToken, setSignaturePin, submitApplication, usernameTaken, USERNAME_RULE, accountFor } from './invitations';
import { IsolatedHtmlFormRenderer } from '../components/IsolatedHtmlFormRenderer';
import { getFormHtmlSync, getBundledFormHtml } from '../v6/formSource';

const DOC_CATEGORIES = ['Medical License', 'DEA Registration', 'Malpractice Insurance', 'Board Certification', 'NPI / Enumeration', 'CV', 'Photo ID', 'Other Credential']; // same list as the v5/v6 credentialing portal
const ICON: Record<InvitePurpose, React.ReactNode> = { application: <ClipboardList size={20} />, account: <Lock size={20} />, pin: <KeyRound size={20} /> };
const go = (href?: string) => { if (href) location.href = href; };

export const InviteLanding: React.FC = () => {
  const route = parseInviteHash();
  const [v, setV] = useState(0);
  const check: TokenCheck = useMemo(() => route ? resolveToken(route.token, route.purpose) : { state: 'invalid' }, [route?.token, route?.purpose, v]);
  const [done, setDone] = useState(false);
  const p = check.provider; const ob = p?.onboarding || {};
  const stepDone: Record<InvitePurpose, boolean> = { application: !!ob.applicationAt, account: !!ob.accountAt, pin: !!ob.pinAt };
  const nextPurpose = PURPOSES.find(x => !stepDone[x] && x !== route?.purpose);
  const practice = check.tok?.practice || 'Your surgery center';
  const finish = () => { setDone(true); setV(x => x + 1); window.scrollTo(0, 0); };
  return <div className="min-h-screen bg-[#EEF2EE] text-[#17271f]" data-testid="invite-landing">
    <header className="bg-[#14432E] text-white"><div className="max-w-3xl mx-auto px-5 py-4 flex items-center gap-3">
      <div className="w-10 h-10 rounded-lg bg-white text-[#14432E] grid place-items-center font-bold">V</div>
      <div><div className="text-[13px] uppercase tracking-wider text-[#F4DFA7]">Vityls · Provider onboarding</div><div className="text-[17px] font-semibold">{practice}</div></div>
    </div></header>
    <main className="max-w-3xl mx-auto px-5 py-6 space-y-5">
      {p && <ol className="grid grid-cols-3 gap-2" data-testid="invite-steps">{PURPOSES.map((x, i) => <li key={x} className={`rounded-lg border p-3 text-[14px] ${x === route?.purpose ? 'border-[#1F6E52] bg-white' : 'border-[#d4ddd7] bg-white/70'}`}>
        <div className="flex items-center gap-2 font-semibold">{stepDone[x] ? <CheckCircle2 size={18} className="text-[#1F6E52]" /> : <span className="w-[18px] text-center">{i + 1}</span>}{PURPOSE_LABEL[x]}</div>
        <div className="text-[13px] text-[#4a5750] mt-0.5">{stepDone[x] ? 'Done' : x === route?.purpose ? 'This page' : 'Not started'}</div></li>)}</ol>}
      <section className="bg-white rounded-xl border border-[#d4ddd7] shadow-sm p-5 sm:p-6">
        {check.state !== 'ok' && !done ? <Problem check={check} purpose={route?.purpose} next={nextPurpose && check.siblings?.[nextPurpose]} nextLabel={nextPurpose && PURPOSE_LABEL[nextPurpose]} />
          : done ? <div data-testid="invite-success"><div className="flex items-center gap-2 text-[#14532d]"><CheckCircle2 /><h1 className="text-[22px] font-semibold">{route!.purpose === 'application' ? 'Application submitted' : route!.purpose === 'account' ? 'Account created' : 'Signature PIN created'}</h1></div>
              <p className="mt-2 text-[15px] text-[#33423a]">{route!.purpose === 'application' ? 'The Medical Staff Office will verify your credentials. The Medical Director reviews and approves privileges.' : route!.purpose === 'account' ? 'You can sign in to Vityls with this username and password.' : 'You will enter this PIN to confirm your identity when you sign clinical documents.'}</p>
              {nextPurpose && !stepDone[nextPurpose] && check.siblings?.[nextPurpose] ? <Btn variant="primary" className="mt-4" icon={<ArrowRight size={18} />} onClick={() => { setDone(false); go(check.siblings![nextPurpose]); }} data-testid="invite-next">Next: {PURPOSE_LABEL[nextPurpose]}</Btn>
                : PURPOSES.every(x => stepDone[x]) ? <p className="mt-4 p-3 rounded-lg bg-[#E7F4EC] text-[#14532d] text-[15px]" data-testid="invite-all-done">All three steps are complete. Thank you.</p> : null}</div>
          : route!.purpose === 'application' ? <ApplicationForm check={check} onDone={finish} />
          : route!.purpose === 'account' ? <AccountForm check={check} onDone={finish} />
          : <PinForm check={check} onDone={finish} />}
      </section>
      <p className="text-[13px] text-[#4a5750]">Evaluation build: this page runs locally from the invitation link. No data leaves this device. {practice} staff will never ask for your password or PIN.</p>
    </main>
  </div>;
};

const Problem: React.FC<{ check: TokenCheck; purpose?: InvitePurpose; next?: string; nextLabel?: string }> = ({ check, purpose, next, nextLabel }) => {
  const msg = check.state === 'used' ? `${purpose ? PURPOSE_LABEL[purpose] : 'This step'} is already complete. Each link works once.`
    : check.state === 'revoked' ? 'A newer invitation was sent to you. Please use the links in the most recent email.'
    : check.state === 'expired' ? 'This link has expired. Ask the Medical Staff Office to resend your invitation.'
    : 'This link is not valid. Check that you opened the full link from your invitation email.';
  return <div data-testid={`invite-${check.state}`}><div className="flex items-center gap-2 text-[#7a4a06]"><AlertTriangle /><h1 className="text-[20px] font-semibold">{check.state === 'used' ? 'Already done' : 'Link can’t be used'}</h1></div>
    <p className="mt-2 text-[15px]">{msg}</p>{check.state === 'used' && next && <Btn variant="primary" className="mt-4" icon={<ArrowRight size={18} />} onClick={() => go(next)}>Next: {nextLabel}</Btn>}</div>;
};

const Err: React.FC<{ list: string[] }> = ({ list }) => list.length ? <div className="mt-4 p-3 rounded-lg bg-[#FDECEC] border border-[#f1b9b9] text-[#7f1d1d] text-[15px]" role="alert" data-testid="invite-errors"><b>Please fix:</b><ul className="list-disc ml-5">{list.map(e => <li key={e}>{e}</li>)}</ul></div> : null;
const Head: React.FC<{ purpose: InvitePurpose; name: string; sub: string }> = ({ purpose, name, sub }) => <div className="flex items-start gap-3 mb-4"><div className="w-10 h-10 rounded-lg bg-[#E7F4EC] text-[#1F6E52] grid place-items-center shrink-0">{ICON[purpose]}</div><div><h1 className="text-[22px] font-semibold leading-tight">{PURPOSE_LABEL[purpose]}</h1><p className="text-[15px] text-[#33423a] mt-0.5">{name} · {sub}</p></div></div>;

const ApplicationForm: React.FC<{ check: TokenCheck; onDone: () => void }> = ({ check, onDone }) => {
  const p = check.provider!;
  const [f, setF] = useState({ specialty: p.specialty || '', npi: p.npi || '', license: '', licenseState: '', licenseExp: '', dea: '', board: '', carrier: '', privileges: '' });
  const [docs, setDocs] = useState<Record<string, string>>({}); const [attest, setAttest] = useState(false); const [tried, setTried] = useState(false); const [err, setErr] = useState('');
  const set = (k: keyof typeof f, val: string) => setF(x => ({ ...x, [k]: val }));
  const html = useMemo(() => getFormHtmlSync('Surgeon_Membership_Application.html') || getBundledFormHtml('Surgeon_Membership_Application.html'), []);
  const errs = [
    ...(!f.specialty.trim() ? ['Specialty is required'] : []), ...(!/^\d{10}$/.test(f.npi) ? ['NPI must be 10 digits'] : []),
    ...(!f.license.trim() ? ['State medical license number is required'] : []), ...(!/^[A-Z]{2}$/.test(f.licenseState) ? ['License state: 2-letter code'] : []),
    ...fieldErrors([{ kind: 'date', value: f.licenseExp, required: true }]).map(e => `License expiration: ${e}`),
    ...(!f.carrier.trim() ? ['Malpractice carrier is required'] : []), ...(!f.privileges.trim() ? ['List the privileges you are requesting'] : []),
    ...(!attest ? ['Confirm the attestation'] : []),
  ];
  const submit = (e: React.FormEvent) => { e.preventDefault(); setTried(true); setErr(''); if (errs.length) return;
    try { submitApplication(check.tok!.token, { ...f, documents: Object.entries(docs).map(([k, n]) => `${k}: ${n}`) }); onDone(); } catch (x: any) { setErr(x.message); } };
  const inp = 'vy-input';
  return <form onSubmit={submit} data-testid="invite-application" noValidate>
    <Head purpose="application" name={displayName(p)} sub={`${p.role} · ${p.email}`} />
    <div className="grid sm:grid-cols-2 gap-3">
      <label className="vy-label">Specialty *<input className={inp} value={f.specialty} onChange={e => set('specialty', e.target.value)} data-testid="ap-specialty" /></label>
      <label className="vy-label">NPI * (10 digits)<input className={inp} value={f.npi} inputMode="numeric" maxLength={10} onChange={e => set('npi', e.target.value.replace(/\D/g, ''))} data-testid="ap-npi" /></label>
      <label className="vy-label">State medical license # *<input className={inp} value={f.license} onChange={e => set('license', e.target.value)} data-testid="ap-license" /></label>
      <label className="vy-label">License state *<input className={inp} value={f.licenseState} maxLength={2} onChange={e => set('licenseState', e.target.value.toUpperCase().replace(/[^A-Z]/g, ''))} placeholder="CA" data-testid="ap-state" /></label>
      <MaskedField label="License expiration *" kind="date" value={f.licenseExp} onChange={x => set('licenseExp', x)} showErrors={tried} testId="ap-exp" />
      <label className="vy-label">DEA # (if applicable)<input className={inp} value={f.dea} onChange={e => set('dea', e.target.value.toUpperCase())} /></label>
      <label className="vy-label">Board certification<input className={inp} value={f.board} onChange={e => set('board', e.target.value)} /></label>
      <label className="vy-label">Malpractice carrier *<input className={inp} value={f.carrier} onChange={e => set('carrier', e.target.value)} data-testid="ap-carrier" /></label>
      <label className="vy-label sm:col-span-2">Privileges requested *<textarea className={inp} rows={2} value={f.privileges} onChange={e => set('privileges', e.target.value)} placeholder="e.g. Arthroscopy, knee and shoulder; minor soft-tissue procedures" data-testid="ap-privileges" /></label>
    </div>
    <details className="mt-5 rounded-lg border border-[#d4ddd7]" data-testid="ap-full-form"><summary className="cursor-pointer px-4 py-3 font-semibold text-[15px] min-h-[44px]">Full Membership & Privileges Application form (from Forms library)</summary>
      <div className="max-h-[520px] overflow-auto border-t border-[#d4ddd7] bg-[#F4F6F3] p-3">{html ? <IsolatedHtmlFormRenderer html={html} autosaveKey={`vityls:v7:application-draft:${p.id}`} /> : <p className="text-[15px]">Form template not found.</p>}</div></details>
    <fieldset className="mt-5"><legend className="vy-label">Credential documents</legend><p className="text-[14px] text-[#4a5750]">Upload what you have now; the Medical Staff Office will request anything missing.</p>
      <div className="grid sm:grid-cols-2 gap-2 mt-2">{DOC_CATEGORIES.map(c => <label key={c} className="flex items-center justify-between gap-2 p-3 rounded-lg border border-[#d4ddd7] text-[14px] cursor-pointer min-h-[44px]"><span><span className="font-semibold">{c}</span>{docs[c] && <span className="block text-[13px] text-[#1F6E52]">{docs[c]}</span>}</span>
        <span className="vy-btn vy-btn-secondary shrink-0">{docs[c] ? 'Replace' : 'Upload'}</span><input type="file" className="sr-only" onChange={e => { const n = e.target.files?.[0]?.name; if (n) setDocs(d => ({ ...d, [c]: n })); }} /></label>)}</div></fieldset>
    <label className="flex items-start gap-2 mt-5 text-[15px]"><input type="checkbox" className="w-5 h-5 mt-0.5" checked={attest} onChange={e => setAttest(e.target.checked)} data-testid="ap-attest" />I attest that the information in this application is true and complete, and I authorize verification of my credentials.</label>
    {tried && <Err list={[...errs, ...(err ? [err] : [])]} />}
    <div className="mt-5 flex justify-end"><Btn type="submit" variant="confirm" data-testid="ap-submit">Submit application</Btn></div>
  </form>;
};

const AccountForm: React.FC<{ check: TokenCheck; onDone: () => void }> = ({ check, onDone }) => {
  const p = check.provider!;
  const [u, setU] = useState(''); const [pw, setPw] = useState(''); const [pw2, setPw2] = useState(''); const [tried, setTried] = useState(false); const [err, setErr] = useState('');
  const errs = [...(!USERNAME_RULE.test(u) ? ['Username: 4–32 letters, numbers, dot, dash or underscore'] : usernameTaken(u, p.id) ? ['That username is taken'] : []), ...passwordProblems(pw, u).map(x => `Password: ${x}`), ...(pw !== pw2 ? ['Passwords do not match'] : [])];
  const submit = (e: React.FormEvent) => { e.preventDefault(); setTried(true); setErr(''); if (errs.length) return; try { createAccount(check.tok!.token, u, pw); onDone(); } catch (x: any) { setErr(x.message); } };
  return <form onSubmit={submit} data-testid="invite-account" noValidate>
    <Head purpose="account" name={displayName(p)} sub="Choose the username and password you will use to sign in to Vityls." />
    <div className="grid gap-3 max-w-md">
      <label className="vy-label">Username *<input className="vy-input" value={u} onChange={e => setU(e.target.value.trim())} autoComplete="username" data-testid="ac-username" /></label>
      <label className="vy-label">Password *<input className="vy-input" type="password" value={pw} onChange={e => setPw(e.target.value)} autoComplete="new-password" data-testid="ac-password" /></label>
      <label className="vy-label">Confirm password *<input className="vy-input" type="password" value={pw2} onChange={e => setPw2(e.target.value)} autoComplete="new-password" data-testid="ac-password2" /></label>
      <p className="text-[14px] text-[#4a5750]">At least 10 characters, with letters and at least one number.</p>
    </div>
    {tried && <Err list={[...errs, ...(err ? [err] : [])]} />}
    <div className="mt-5 flex justify-end"><Btn type="submit" variant="confirm" data-testid="ac-submit">Create account</Btn></div>
  </form>;
};

const PinForm: React.FC<{ check: TokenCheck; onDone: () => void }> = ({ check, onDone }) => {
  const p = check.provider!; const hasAccount = !!accountFor(p.id);
  const [u, setU] = useState(''); const [pw, setPw] = useState(''); const [pin, setPin] = useState(''); const [pin2, setPin2] = useState(''); const [tried, setTried] = useState(false); const [err, setErr] = useState('');
  const errs = [...(!u || !pw ? ['Enter your Vityls username and password'] : []), ...pinProblems(pin), ...(pin !== pin2 ? ['PINs do not match'] : [])];
  const submit = (e: React.FormEvent) => { e.preventDefault(); setTried(true); setErr(''); if (errs.length) return; try { setSignaturePin(check.tok!.token, u, pw, pin); onDone(); } catch (x: any) { setErr(x.message); } };
  if (!hasAccount) return <div data-testid="invite-pin-needs-account"><Head purpose="pin" name={displayName(p)} sub="Your PIN is tied to your Vityls account." />
    <p className="text-[15px]">Create your username and password first, then come back to this link.</p>
    {check.siblings?.account && <Btn variant="primary" className="mt-4" icon={<ArrowRight size={18} />} onClick={() => go(check.siblings!.account)}>Create username and password</Btn>}</div>;
  return <form onSubmit={submit} data-testid="invite-pin" noValidate>
    <Head purpose="pin" name={displayName(p)} sub="Confirm it’s you, then choose a 4–6 digit PIN for signing." />
    <div className="grid sm:grid-cols-2 gap-3">
      <label className="vy-label">Username *<input className="vy-input" value={u} onChange={e => setU(e.target.value.trim())} autoComplete="username" data-testid="pn-username" /></label>
      <label className="vy-label">Password *<input className="vy-input" type="password" value={pw} onChange={e => setPw(e.target.value)} autoComplete="current-password" data-testid="pn-password" /></label>
      <label className="vy-label">New signature PIN *<input className="vy-input" type="password" inputMode="numeric" maxLength={6} value={pin} onChange={e => setPin(e.target.value.replace(/\D/g, ''))} autoComplete="new-password" data-testid="pn-pin" /></label>
      <label className="vy-label">Confirm PIN *<input className="vy-input" type="password" inputMode="numeric" maxLength={6} value={pin2} onChange={e => setPin2(e.target.value.replace(/\D/g, ''))} autoComplete="new-password" data-testid="pn-pin2" /></label>
    </div>
    <p className="text-[14px] text-[#4a5750] mt-2">Avoid repeated or sequential digits. Administrators never see your PIN.</p>
    {tried && <Err list={[...errs, ...(err ? [err] : [])]} />}
    <div className="mt-5 flex justify-end"><Btn type="submit" variant="confirm" data-testid="pn-submit">Create PIN</Btn></div>
  </form>;
};
