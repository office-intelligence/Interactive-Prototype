/*
 * v7 item 18: stations show ONLY forms the practice has added to My Forms (Practice → Forms & Workflow),
 * placed at the stations chosen there. Required vs As-needed follows the "Requirement" chosen when adding.
 * Storage keys are the ones Forms & Workflow already writes.
 */
import { isAssignedToWorkflow, WorkflowKey } from '../data/formWorkspaceCatalog';
import { STATION_PLAN } from '../v6/formRules';

export function getMyForms(): string[] {
  const out = new Set<string>();
  try { Object.keys(localStorage).filter(k => k.startsWith('vityls-my-forms:')).forEach(k => { (JSON.parse(localStorage.getItem(k) || '[]') as string[]).forEach(f => out.add(f)); }); } catch { /* ignore */ }
  return Array.from(out);
}
export const requirementOf = (file: string) => { try { return localStorage.getItem(`vityls-form-requirement:${file}`) || 'Required'; } catch { return 'Required'; } };
const order = (station: WorkflowKey) => { const p = STATION_PLAN[station]; return [...(p?.required || []), ...(p?.asNeeded || [])]; };
const byOrder = (station: WorkflowKey) => (a: string, b: string) => { const o = order(station); const ia = o.indexOf(a), ib = o.indexOf(b); return (ia < 0 ? 999 : ia) - (ib < 0 ? 999 : ib) || a.localeCompare(b); };
/** Forms for one station, from My Forms only. */
export function stationPlan(station: WorkflowKey): { required: string[]; asNeeded: string[] } {
  const mine = getMyForms().filter(f => isAssignedToWorkflow(f, station)).sort(byOrder(station));
  return { required: mine.filter(f => requirementOf(f) === 'Required'), asNeeded: mine.filter(f => requirementOf(f) !== 'Required') };
}
/** Every form in My Forms that is placed at any station (Case Record / co-sign lists). */
export function allStationForms(): string[] {
  const st: WorkflowKey[] = ['patientPortal', 'frontOffice', 'nursing', 'anesthesia', 'surgeon', 'orTeam', 'pacu'];
  return Array.from(new Set(st.flatMap(s => { const p = stationPlan(s); return [...p.required, ...p.asNeeded]; })));
}
/** Required forms only (As-needed forms never block completion). */
export function requiredStationForms(): string[] {
  const st: WorkflowKey[] = ['patientPortal', 'frontOffice', 'nursing', 'anesthesia', 'surgeon', 'orTeam', 'pacu'];
  return Array.from(new Set(st.flatMap(s => stationPlan(s).required)));
}
/** Stations a form is placed at. */
export function stationsOf(file: string): WorkflowKey[] {
  const st: WorkflowKey[] = ['patientPortal', 'frontOffice', 'nursing', 'anesthesia', 'surgeon', 'orTeam', 'pacu'];
  return st.filter(s => { const p = stationPlan(s); return p.required.includes(file) || p.asNeeded.includes(file); });
}
