/*
 * v7.3 Provider onboarding invitation: ONE email with three tokenized links
 *   (a) Membership & Privileges Application  (b) create username + password  (c) create Signature PIN.
 *
 * Reused from the earlier People & Credentials invitation (v5 → v6, src/components/AdministrationPage.tsx):
 *   - sendCredentialInvite(): the email wording, the credentialing link + account-activation link pair and the
 *     "configure your Signature Authentication PIN" step → now three separate links in one email.
 *   - sendAccessInvitation() / AccessRecord + localStorage 'vityls:access-records:v1': account status
 *     (Invitation Pending → Active, username, passwordSetup, signaturePinSetup) is written to that same store.
 *   - The credentialing portal: forms/Surgeon_Membership_Application.html + the credential upload categories.
 *   - VITYLS_USER_ACCESS_AND_PROVIDER_INVITATION_2026-09-28.md: administrators never see or set passwords/PINs.
 * The old builds opened a mailto: link. This build has no backend, so the email is SIMULATED: it is generated in
 * full, previewed, and logged in a local outbox. Nothing leaves the device.
 *
 * WHERE THE REAL SERVICES PLUG IN
 *   1. Email service: registerEmailTransport({ id, send }). Default transport 'simulated-outbox' only stores the
 *      message. Production: send() POSTs to your server (e.g. POST /api/provider-invitations) which renders the
 *      same subject/body and sends via SES / SendGrid / Postmark. API keys never live in the browser.
 *   2. Tokens: issueToken(). Production: the server creates random single-use tokens, stores only a hash,
 *      sets expiry (INVITE_TTL_DAYS) and validates them (GET /api/invite/:token) — resolveToken() here.
 *   3. Auth backend: createAccount() and setSignaturePin(). Production: POST /api/auth/activate (your IdP —
 *      Cognito / Auth0 / Entra ID — or a server with argon2id) and POST /api/auth/signature-pin (server-side salted
 *      hash, requires re-authentication). The evaluation hashes below are NOT cryptographic.
 *   4. Link base: set window.VITYLS_INVITE_BASE_URL (e.g. 'https://portal.vityls.com') and links become
 *      <base>/invite/<purpose>/<token>. Without it, links point at this local build: index.html#invite=<purpose>&t=<token>.
 */
import { Provider, displayName, getProviders, hashPin, saveProviders, CRED_STEPS, findProvider, MAX_PIN_FAILURES } from './providers';
import { repo, AuditEntry } from '../v6/dataLayer';

export type InvitePurpose = 'application' | 'account' | 'pin';
export const PURPOSES: InvitePurpose[] = ['application', 'account', 'pin'];
export const PURPOSE_LABEL: Record<InvitePurpose, string> = { application: 'Membership & Privileges Application', account: 'Create username and password', pin: 'Create signature PIN' };
export const INVITE_TTL_DAYS = 14;
export interface InviteToken { token: string; providerId: string; purpose: InvitePurpose; inviteId: string; practice: string; issuedAt: string; expiresAt: string; usedAt?: string; revokedAt?: string }
export interface OutboxEmail { id: string; kind: 'provider-invitation' | 'pin-reset'; providerId: string; to: string; toName: string; from: string; subject: string; body: string; links: Partial<Record<InvitePurpose, string>>; sentAt: string; sentBy: string; transport: string; resend: boolean; expiresAt: string }
export interface EmailTransport { id: string; label: string; send: (m: OutboxEmail) => Promise<void> | void }

const K_OUT = 'vityls:v7:outbox', K_TOK = 'vityls:v7:invite-tokens', K_ACC = 'vityls:v7:accounts', K_ACCESS = 'vityls:access-records:v1';
const read = <T,>(k: string, d: T): T => { try { const r = localStorage.getItem(k); return r ? JSON.parse(r) : d; } catch { return d; } };
const write = (k: string, v: unknown) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch { /* */ } try { window.dispatchEvent(new Event('vityls-outbox-updated')); } catch { /* */ } };
const now = () => new Date().toISOString();

/* ---------- 1. email transport ---------- */
const SIMULATED: EmailTransport = { id: 'simulated-outbox', label: 'Simulated (local outbox, nothing is sent)', send: () => { /* stored by sendProviderInvitation */ } };
let transport: EmailTransport = SIMULATED;
export const registerEmailTransport = (t: EmailTransport) => { transport = t; };
export const activeTransport = () => transport;
export const getOutbox = (): OutboxEmail[] => read<OutboxEmail[]>(K_OUT, []);
export const outboxFor = (providerId: string) => getOutbox().filter(m => m.providerId === providerId);

/* ---------- 2. tokens ---------- */
const randomToken = () => { const a = new Uint8Array(16); try { crypto.getRandomValues(a); } catch { for (let i = 0; i < 16; i++) a[i] = Math.floor(Math.random() * 256); } return Array.from(a, b => b.toString(16).padStart(2, '0')).join(''); };
const tokens = () => read<InviteToken[]>(K_TOK, []);
export function inviteLink(purpose: InvitePurpose, token: string) {
  const base = (window as any).VITYLS_INVITE_BASE_URL as string | undefined;
  if (base) return `${base.replace(/\/$/, '')}/invite/${purpose}/${token}`;
  return `${location.href.split('#')[0].split('?')[0]}#invite=${purpose}&t=${token}`; // never carry ?reset-test-data into a link
}
export function parseInviteHash(hash = location.hash): { purpose: InvitePurpose; token: string } | null {
  const m = hash.match(/^#invite=(application|account|pin)&t=([a-f0-9]{16,64})$/i); return m ? { purpose: m[1].toLowerCase() as InvitePurpose, token: m[2] } : null;
}
export type TokenCheck = { state: 'ok' | 'used' | 'revoked' | 'expired' | 'invalid'; tok?: InviteToken; provider?: Provider; siblings?: Partial<Record<InvitePurpose, string>> };
export function resolveToken(token: string, purpose?: InvitePurpose): TokenCheck {
  const all = tokens(); const tok = all.find(t => t.token === token && (!purpose || t.purpose === purpose));
  if (!tok) return { state: 'invalid' };
  const provider = getProviders().find(p => p.id === tok.providerId);
  if (!provider) return { state: 'invalid' };
  const siblings: Partial<Record<InvitePurpose, string>> = {}; all.filter(t => t.inviteId === tok.inviteId).forEach(t => { siblings[t.purpose] = inviteLink(t.purpose, t.token); });
  const state = tok.revokedAt ? 'revoked' : tok.usedAt ? 'used' : Date.parse(tok.expiresAt) < Date.now() ? 'expired' : 'ok';
  return { state, tok, provider, siblings };
}
const consumeToken = (token: string) => write(K_TOK, tokens().map(t => t.token === token ? { ...t, usedAt: now() } : t));

/* ---------- provider record helpers ---------- */
function updateProvider(id: string, fn: (p: Provider) => Provider) { const l = getProviders(); const i = l.findIndex(p => p.id === id); if (i < 0) return; l[i] = fn(l[i]); saveProviders(l); }
const addHistory = (p: Provider, status: string, by: string, note?: string, advanceTo?: Provider['app']['status']): Provider => {
  let st = p.app.status;
  if (advanceTo && st !== 'Declined' && CRED_STEPS.indexOf(st as any) < CRED_STEPS.indexOf(advanceTo as any)) st = advanceTo;
  return { ...p, app: { ...p.app, status: st, history: [...p.app.history, { status, at: now(), by, note }] } };
};
function setAccess(id: string, patch: Record<string, unknown>) { const a = read<Record<string, any>>(K_ACCESS, {}); a[id] = { ...(a[id] || { status: 'Invitation Pending' }), ...patch }; try { localStorage.setItem(K_ACCESS, JSON.stringify(a)); } catch { /* */ } }

/** v7.4: provider/account events go to the append-only audit log (practice-level stream 'practice'). */
export const PRACTICE_AUDIT = 'practice';
export function providerAudit(user: string, action: AuditEntry['action'], detail: string, role = 'Administrator') { try { repo.audit({ caseId: PRACTICE_AUDIT, user, role, action, detail }); } catch { /* */ } }
export const practiceAudit = () => { try { return repo.getAudit(PRACTICE_AUDIT); } catch { return []; } };

/* ---------- the email ---------- */
export function buildInvitationEmail(p: Provider, practice: string, links: Record<InvitePurpose, string>, expiresAt: string) {
  const exp = new Date(expiresAt).toLocaleDateString(undefined, { month: '2-digit', day: '2-digit', year: 'numeric' });
  const greet = p.degree && /^(MD|DO|DPM|DDS|DMD)$/i.test(p.degree) ? `Dr. ${p.lastName}` : displayName(p);
  const subject = `${practice} — Membership & Privileges Application and your Vityls account`;
  const body = `Dear ${greet},

${practice} is requesting your membership / privileges application and has invited you to Vityls.

Please complete the three steps below. Each link is personal to you, can be used once, and expires on ${exp}.

1. Membership & Privileges Application
Complete the online Surgeon Membership & Privileges Application and upload the requested credential documents, including your medical license, DEA registration (if applicable), malpractice insurance, and other requested credentials.
${links.application}

2. Create your Vityls username and password
${links.account}

3. Create your Signature Authentication PIN
Your PIN confirms your identity for clinical attestations and Quick Sign. Create your username and password first.
${links.pin}

After your application and credentials are verified, the Medical Director must review and approve your privileges before privileging is complete. ${practice} staff will never ask for your password or PIN.

Thank you.
${practice} · Medical Staff Office`;
  return { subject, body };
}

/** Send (simulate) the single onboarding email. Resending revokes the previous links. */
export function sendProviderInvitation(providerId: string, opts: { by: string; practice?: string; resend?: boolean }): OutboxEmail {
  const p = getProviders().find(x => x.id === providerId); if (!p) throw new Error('Provider not found');
  if (!p.email) throw new Error('Add the provider’s email address before sending the invitation.');
  const practice = (opts.practice || '').trim() || 'Our surgery center';
  const issuedAt = now(), expiresAt = new Date(Date.now() + INVITE_TTL_DAYS * 864e5).toISOString(), inviteId = `INV-${Date.now().toString(36).toUpperCase()}`;
  const fresh: InviteToken[] = PURPOSES.map(purpose => ({ token: randomToken(), providerId, purpose, inviteId, practice, issuedAt, expiresAt }));
  write(K_TOK, [...tokens().map(t => t.providerId === providerId && !t.usedAt && !t.revokedAt ? { ...t, revokedAt: issuedAt } : t), ...fresh]);
  const links = Object.fromEntries(fresh.map(t => [t.purpose, inviteLink(t.purpose, t.token)])) as Record<InvitePurpose, string>;
  const { subject, body } = buildInvitationEmail(p, practice, links, expiresAt);
  const msg: OutboxEmail = { id: inviteId, kind: 'provider-invitation', providerId, to: p.email, toName: displayName(p), from: `${practice} Medical Staff Office <no-reply@vityls.local>`, subject, body, links, sentAt: issuedAt, sentBy: opts.by, transport: transport.id, resend: !!opts.resend, expiresAt };
  write(K_OUT, [msg, ...getOutbox()]);
  try { void transport.send(msg); } catch { /* production: surface delivery failure */ }
  updateProvider(providerId, x => addHistory({ ...x, onboarding: { ...x.onboarding, invitedAt: issuedAt, inviteCount: (x.onboarding?.inviteCount || 0) + 1, lastInviteId: inviteId } },
    opts.resend ? 'Invitation resent' : 'Invited', opts.by, `One email with 3 links to ${p.email} (${transport.id === 'simulated-outbox' ? 'simulated, outbox' : transport.label} ${inviteId})${opts.resend ? '; earlier links revoked' : ''}`, 'Invited'));
  setAccess(providerId, { status: 'Invitation Pending', invitedAt: new Date().toLocaleDateString() });
  providerAudit(opts.by, 'provider.invite', `${opts.resend ? 'Invitation resent' : 'Invitation sent'} to ${displayName(p)} <${p.email}> (${inviteId}, ${transport.id})`);
  return msg;
}

/* ---------- link (a): application ---------- */
export function submitApplication(token: string, data: Record<string, string | string[]>) {
  const c = resolveToken(token, 'application'); if (c.state !== 'ok' || !c.provider) throw new Error('This application link is not valid any more.');
  consumeToken(token);
  providerAudit(displayName(c.provider), 'provider.application', 'Membership & privileges application submitted via invitation link', 'Provider');
  updateProvider(c.provider.id, x => addHistory({ ...x, npi: x.npi || String(data.npi || ''), specialty: x.specialty || String(data.specialty || ''), onboarding: { ...x.onboarding, applicationAt: now(), application: { ...data, submittedAt: now() } } },
    'Application received', `${displayName(x)} (via invitation link)`, `Application submitted${Array.isArray(data.documents) && data.documents.length ? ` with ${data.documents.length} credential document(s)` : ''}`, 'Application received'));
}

/* ---------- 3. auth backend (evaluation stand-in) ---------- */
type Account = { providerId: string; username: string; pwHash: string; createdAt: string };
const accounts = () => read<Record<string, Account>>(K_ACC, {});
const pwHash = (u: string, pw: string) => hashPin(`pw|${u.toLowerCase()}|${pw}`); // evaluation only
export const USERNAME_RULE = /^[a-z0-9][a-z0-9._-]{3,31}$/i;
export function passwordProblems(pw: string, username = '') {
  const e: string[] = [];
  if (pw.length < 10) e.push('At least 10 characters'); if (!/[A-Za-z]/.test(pw) || !/\d/.test(pw)) e.push('Use letters and at least one number');
  if (username && pw.toLowerCase().includes(username.toLowerCase())) e.push('Must not contain your username');
  return e;
}
export const usernameTaken = (u: string, providerId?: string) => Object.values(accounts()).some(a => a.username.toLowerCase() === u.toLowerCase() && a.providerId !== providerId);
export const accountFor = (providerId: string) => Object.values(accounts()).find(a => a.providerId === providerId);
export function createAccount(token: string, username: string, password: string) {
  const c = resolveToken(token, 'account'); if (c.state !== 'ok' || !c.provider) throw new Error('This account link is not valid any more.');
  if (!USERNAME_RULE.test(username)) throw new Error('Username: 4–32 letters, numbers, dot, dash or underscore.');
  if (usernameTaken(username, c.provider.id)) throw new Error('That username is taken.');
  const pe = passwordProblems(password, username); if (pe.length) throw new Error(pe.join('; '));
  const a = accounts(); a[c.provider.id] = { providerId: c.provider.id, username, pwHash: pwHash(username, password), createdAt: now() }; write(K_ACC, a);
  consumeToken(token);
  setAccess(c.provider.id, { status: 'Active', username, passwordSetup: true });
  providerAudit(displayName(c.provider), 'provider.account', `Account created (username ${username})`, 'Provider');
  updateProvider(c.provider.id, x => addHistory({ ...x, onboarding: { ...x.onboarding, accountAt: now(), username } }, 'Account created', `${displayName(x)} (via invitation link)`, `Username ${username}`));
}
export function verifyLogin(providerId: string, username: string, password: string) { const a = accountFor(providerId); return !!a && a.username.toLowerCase() === username.toLowerCase() && a.pwHash === pwHash(a.username, password); }
export function pinProblems(pin: string) {
  const e: string[] = []; if (!/^\d{4,6}$/.test(pin)) e.push('PIN must be 4–6 digits');
  else if (/^(\d)\1+$/.test(pin) || '0123456789'.includes(pin) || '9876543210'.includes(pin)) e.push('Avoid repeated or sequential digits');
  return e;
}
export function setSignaturePin(token: string, username: string, password: string, pin: string) {
  const c = resolveToken(token, 'pin'); if (c.state !== 'ok' || !c.provider) throw new Error('This PIN link is not valid any more.');
  if (!accountFor(c.provider.id)) throw new Error('Create your username and password first (step 2 in the email).');
  if (!verifyLogin(c.provider.id, username, password)) throw new Error('Username or password is not correct.');
  const pe = pinProblems(pin); if (pe.length) throw new Error(pe.join('; '));
  consumeToken(token);
  setAccess(c.provider.id, { signaturePinSetup: true });
  providerAudit(displayName(c.provider), 'provider.pin-set', 'Signature PIN created by the provider', 'Provider');
  updateProvider(c.provider.id, x => addHistory({ ...x, pinHash: hashPin(pin), pinFailures: 0, onboarding: { ...x.onboarding, pinAt: now() } }, 'PIN set', `${displayName(x)} (via invitation link)`, 'Signature PIN created by the provider; administrators never see it'));
}

/** The four-step onboarding trail shown to administrators. */
export const onboardingTrail = (p: Provider) => [
  { label: 'Invited', at: p.onboarding?.invitedAt }, { label: 'Application received', at: p.onboarding?.applicationAt },
  { label: 'Account created', at: p.onboarding?.accountAt }, { label: 'PIN set', at: p.onboarding?.pinAt },
];

/* ---------- v7.4 account controls ---------- */
/** Reset PIN: clears the current PIN and emails a single PIN-reset link through the same (simulated) outbox. */
export function sendPinReset(providerId: string, opts: { by: string; practice?: string }): OutboxEmail {
  const p = getProviders().find(x => x.id === providerId); if (!p) throw new Error('Provider not found');
  if (!p.email) throw new Error('Add the provider’s email address first.');
  const practice = (opts.practice || '').trim() || 'Our surgery center';
  const issuedAt = now(), expiresAt = new Date(Date.now() + 2 * 864e5).toISOString(), inviteId = `PIN-${Date.now().toString(36).toUpperCase()}`;
  const tok: InviteToken = { token: randomToken(), providerId, purpose: 'pin', inviteId, practice, issuedAt, expiresAt };
  write(K_TOK, [...tokens().map(t => t.providerId === providerId && t.purpose === 'pin' && !t.usedAt && !t.revokedAt ? { ...t, revokedAt: issuedAt } : t), tok]);
  const link = inviteLink('pin', tok.token);
  const exp = new Date(expiresAt).toLocaleDateString(undefined, { month: '2-digit', day: '2-digit', year: 'numeric' });
  const greet = p.degree && /^(MD|DO|DPM|DDS|DMD)$/i.test(p.degree) ? `Dr. ${p.lastName}` : displayName(p);
  const body = `Dear ${greet},\n\nAn administrator at ${practice} reset your Vityls Signature Authentication PIN. Your previous PIN no longer works.\n\nCreate a new PIN (you will sign in with your username and password first). This link works once and expires on ${exp}:\n${link}\n\nIf you did not expect this, contact the Medical Staff Office. ${practice} staff will never ask for your password or PIN.\n\nThank you.\n${practice} · Medical Staff Office`;
  const msg: OutboxEmail = { id: inviteId, kind: 'pin-reset', providerId, to: p.email, toName: displayName(p), from: `${practice} Medical Staff Office <no-reply@vityls.local>`, subject: `${practice} — Reset your Vityls signature PIN`, body, links: { pin: link }, sentAt: issuedAt, sentBy: opts.by, transport: transport.id, resend: false, expiresAt };
  write(K_OUT, [msg, ...getOutbox()]);
  try { void transport.send(msg); } catch { /* */ }
  updateProvider(providerId, x => addHistory({ ...x, pinHash: '', pinFailures: 0, onboarding: { ...x.onboarding, pinAt: undefined } }, 'PIN reset', opts.by, `Previous PIN cleared; reset link emailed to ${p.email} (${inviteId})`));
  setAccess(providerId, { signaturePinSetup: false });
  providerAudit(opts.by, 'provider.pin-reset', `Signature PIN reset for ${displayName(p)}; reset link sent to ${p.email} (${inviteId})`);
  return msg;
}
/** Wrong PIN at signing. Returns attempts left; locks the account at MAX_PIN_FAILURES. */
export function recordPinFailure(signerName: string): number {
  const p = findProvider(signerName); if (!p) return MAX_PIN_FAILURES;
  const n = (p.pinFailures || 0) + 1; const lock = n >= MAX_PIN_FAILURES;
  updateProvider(p.id, x => { const y = { ...x, pinFailures: n, locked: lock || x.locked, lockedAt: lock ? now() : x.lockedAt }; return lock ? addHistory(y, 'Account locked', 'System', `${n} wrong signature PINs`) : y; });
  providerAudit(displayName(p), lock ? 'provider.lock' : 'provider.pin-failure', lock ? `Account locked after ${n} wrong signature PINs` : `Wrong signature PIN (${n} of ${MAX_PIN_FAILURES})`, 'Provider');
  return Math.max(0, MAX_PIN_FAILURES - n);
}
export function recordPinSuccess(signerName: string) { const p = findProvider(signerName); if (p && p.pinFailures) updateProvider(p.id, x => ({ ...x, pinFailures: 0 })); }
export function unlockAccount(providerId: string, by: string) {
  const p = getProviders().find(x => x.id === providerId); if (!p) return;
  updateProvider(providerId, x => addHistory({ ...x, locked: false, pinFailures: 0, lockedAt: undefined }, 'Account unlocked', by));
  providerAudit(by, 'provider.unlock', `Account unlocked for ${displayName(p)}`);
}
/** Deactivate / reactivate. Deactivated providers cannot sign and are not offered in (or accepted by) the Scheduler. */
export function setProviderActive(providerId: string, active: boolean, by: string, reason?: string) {
  const p = getProviders().find(x => x.id === providerId); if (!p) return;
  updateProvider(providerId, x => addHistory({ ...x, active, deactivatedAt: active ? undefined : now(), deactivatedBy: active ? undefined : by, deactivationReason: active ? undefined : reason }, active ? 'Account reactivated' : 'Account deactivated', by, reason));
  setAccess(providerId, { status: active ? 'Active' : 'Inactive' });
  providerAudit(by, active ? 'provider.reactivate' : 'provider.deactivate', `${displayName(p)} ${active ? 'reactivated' : 'deactivated'}${reason ? `: ${reason}` : ''}`);
}
