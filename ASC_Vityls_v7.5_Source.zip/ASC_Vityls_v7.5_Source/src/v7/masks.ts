/*
 * v7 input masks + validation (item 3). One implementation used by React inputs (MaskedInput)
 * and by the form engine (attachMask) so every date, SSN, phone and email field behaves the same.
 * Number keypad on tablets: date/SSN use inputMode=numeric, phone uses tel, email uses email.
 */
export type MaskKind = 'date' | 'ssn' | 'phone' | 'email' | 'zip';

const digits = (s: string) => s.replace(/\D/g, '');
export function formatDate(v: string) { const d = digits(v).slice(0, 8); if (d.length <= 2) return d; if (d.length <= 4) return `${d.slice(0, 2)}/${d.slice(2)}`; return `${d.slice(0, 2)}/${d.slice(2, 4)}/${d.slice(4)}`; }
export function formatSsn(v: string) { const d = digits(v).slice(0, 9); if (d.length <= 3) return d; if (d.length <= 5) return `${d.slice(0, 3)}-${d.slice(3)}`; return `${d.slice(0, 3)}-${d.slice(3, 5)}-${d.slice(5)}`; }
export function formatPhone(v: string) { let d = digits(v); if (d.length === 11 && d[0] === '1') d = d.slice(1); d = d.slice(0, 10); if (!d) return ''; if (d.length <= 3) return `(${d}`; if (d.length <= 6) return `(${d.slice(0, 3)}) ${d.slice(3)}`; return `(${d.slice(0, 3)}) ${d.slice(3, 6)}-${d.slice(6)}`; }
export function formatZip(v: string) { const d = digits(v).slice(0, 9); return d.length > 5 ? `${d.slice(0, 5)}-${d.slice(5)}` : d; }
export const EMAIL_RE = /^[A-Za-z0-9.!#$%&'*+/=?^_`{|}~-]+@[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?(?:\.[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?)*\.[A-Za-z]{2,}$/;

export function formatFor(kind: MaskKind, v: string) {
  return kind === 'date' ? formatDate(v) : kind === 'ssn' ? formatSsn(v) : kind === 'phone' ? formatPhone(v) : kind === 'zip' ? formatZip(v) : v.trim();
}
export function isRealDate(v: string, opts: { past?: boolean } = {}) {
  const m = v.match(/^(\d{2})\/(\d{2})\/(\d{4})$/); if (!m) return false;
  const [mm, dd, yy] = [Number(m[1]), Number(m[2]), Number(m[3])];
  const d = new Date(yy, mm - 1, dd);
  if (d.getFullYear() !== yy || d.getMonth() !== mm - 1 || d.getDate() !== dd) return false;
  if (yy < 1900 || yy > 2100) return false;
  if (opts.past && d.getTime() > Date.now()) return false;
  return true;
}
/** '' when valid or empty; otherwise a short message. Required-ness is checked separately. */
export function validate(kind: MaskKind, v: string, opts: { past?: boolean } = {}): string {
  const s = (v || '').trim(); if (!s) return '';
  switch (kind) {
    case 'date': return isRealDate(s, opts) ? '' : opts.past && /^\d{2}\/\d{2}\/\d{4}$/.test(s) && isRealDate(s) ? 'Date can’t be in the future' : 'Use MM/DD/YYYY';
    case 'ssn': return /^\d{3}-\d{2}-\d{4}$/.test(s) && !/^(000|666|9)/.test(s) && !/-00-/.test(s) && !/-0000$/.test(s) ? '' : 'Use 000-00-0000 (a valid SSN)';
    case 'phone': return /^\(\d{3}\) \d{3}-\d{4}$/.test(s) && !/^\([01]/.test(s) ? '' : 'Use (000) 000-0000';
    case 'email': return EMAIL_RE.test(s) ? '' : 'Enter an email like name@example.com';
    case 'zip': return /^\d{5}(-\d{4})?$/.test(s) ? '' : 'Use 00000 or 00000-0000';
  }
}
export const MASK_ATTRS: Record<MaskKind, { inputMode: 'numeric' | 'tel' | 'email'; placeholder: string; maxLength?: number; type: string }> = {
  date: { inputMode: 'numeric', placeholder: 'MM/DD/YYYY', maxLength: 10, type: 'text' },
  ssn: { inputMode: 'numeric', placeholder: '000-00-0000', maxLength: 11, type: 'text' },
  phone: { inputMode: 'tel', placeholder: '(000) 000-0000', maxLength: 14, type: 'tel' },
  email: { inputMode: 'email', placeholder: 'name@example.com', type: 'email' },
  zip: { inputMode: 'numeric', placeholder: '00000', maxLength: 10, type: 'text' },
};

/** DOM version for template forms (shadow DOM). Formats while typing, validates on blur. */
export function attachMask(el: HTMLInputElement, kind: MaskKind, opts: { past?: boolean } = {}) {
  if (el.dataset.vkMask) return; el.dataset.vkMask = kind;
  const a = MASK_ATTRS[kind]; el.inputMode = a.inputMode; if (a.type !== 'text' || el.type === 'text') el.type = a.type;
  if (!el.placeholder) el.placeholder = a.placeholder; if (a.maxLength) el.maxLength = a.maxLength; el.autocomplete = 'off';
  const fmt = () => { if (kind === 'email') return; const p = el.value; const n = formatFor(kind, p); if (n !== p) { el.value = n; } };
  const check = () => { const msg = validate(kind, el.value, opts); el.setCustomValidity(msg); el.toggleAttribute('aria-invalid', !!msg); el.classList.toggle('vk-invalid', !!msg); el.title = msg; };
  el.addEventListener('input', () => { fmt(); if (el.classList.contains('vk-invalid')) check(); });
  el.addEventListener('blur', () => { if (kind === 'email') el.value = el.value.trim(); check(); });
  if (el.value) { fmt(); check(); }
}
/** Pick a mask for a form field from its label / name. */
export function maskForLabel(label: string, name = ''): MaskKind | null {
  const l = `${label} ${name}`;
  if (/\bssn\b|social security/i.test(l)) return 'ssn';
  if (/e-?mail/i.test(l)) return 'email';
  if (/phone|telephone|mobile|\bcell\b|\bfax\b/i.test(l) && !/time/i.test(l)) return 'phone';
  if (/\bzip\b|postal code/i.test(l)) return 'zip';
  if (/\b(dob|date of birth|birth ?date|date)\b/i.test(l) && !/time|update|signature/i.test(l)) return 'date';
  return null;
}
