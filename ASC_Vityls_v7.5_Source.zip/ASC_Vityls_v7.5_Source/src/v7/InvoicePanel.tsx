import React, { useEffect, useMemo, useState } from 'react';
import { Receipt, Plus, Trash2, CreditCard, Save, ShieldAlert } from 'lucide-react';
import type { PatientCase } from '../types';
import { Btn, CardTitle, DialogShell } from './ui';
import { BILLING_FEATURES, FeeSchedule, Invoice, MatchKind, TimeFee, buildInvoice, caseTimes, documentationComplete, getInvoices, getSchedules, invoicesForCase, isCashPay, recordPayment, saveInvoice, saveSchedules, scheduleFor, timeFee } from './billing';
import { requiredStationForms } from './myForms';
import { ruleFor } from '../v6/formRules';
import { repo } from '../v6/dataLayer';
import { isManagerRole } from './roles';

const money = (n: number) => `$${n.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
export function useBilling() { const [v, setV] = useState(0); useEffect(() => { const f = () => setV(x => x + 1); window.addEventListener('vityls-billing-updated', f); return () => window.removeEventListener('vityls-billing-updated', f); }, []); return v; }
const statusChip = (s: Invoice['status']) => s === 'Paid in full' ? 'vy-chip-ok' : s === 'Draft' ? 'vy-chip-muted' : 'vy-chip-warn';

/** Eligibility for a cash-pay invoice: self/cash pay, procedure done, documentation complete. */
export function invoiceEligibility(p: PatientCase) {
  const f = repo.getFacts(p.id); const v = repo.getStationVerification(p.id);
  const done = !!f['time.outOR']?.value || !!v['pacu'];
  const docs = documentationComplete(p.id, requiredStationForms(), ruleFor as any);
  return { cash: isCashPay(p), done, docs, ok: isCashPay(p) && done && docs.ok };
}

/** Per-case invoice panel: Case Record station, patient page billing (items 12, 16). */
export const InvoicePanel: React.FC<{ patient: PatientCase; actor: string; role?: string; compact?: boolean }> = ({ patient, actor, role = '', compact }) => {
  useBilling(); const [open, setOpen] = useState<null | 'normal' | 'override'>(null); const [pay, setPay] = useState<Invoice | null>(null);
  const el = invoiceEligibility(patient); const list = invoicesForCase(patient.id); const manager = isManagerRole(role);
  const action = el.ok ? <Btn variant="add" icon={<Receipt size={18} />} onClick={() => setOpen('normal')} data-testid="generate-invoice">Generate invoice</Btn>
    : manager ? <Btn variant="edit" icon={<ShieldAlert size={18} />} onClick={() => setOpen('override')} data-testid="override-invoice">Issue with manager override</Btn>
    : <Btn variant="add" icon={<Receipt size={18} />} disabled data-testid="generate-invoice">Generate invoice</Btn>;
  return <section className="vy-card p-5" data-testid="invoice-panel">
    <CardTitle kicker="Billing & Payments" title="Cash-pay invoice" sub="Generated after the procedure is done and documentation is complete. Uses the time-based fee schedule and this case’s times." right={action} />
    <ul className="mt-3 grid sm:grid-cols-3 gap-2 text-[14.5px]">
      <li className={el.cash ? 'vy-chip-ok' : 'vy-chip-muted'}>{el.cash ? '✓' : '—'} Self-pay / cash-pay ({patient.paymentType || 'not set'})</li>
      <li className={el.done ? 'vy-chip-ok' : 'vy-chip-warn'}>{el.done ? '✓ Procedure done' : 'Procedure not finished (out-of-room time or PACU verification)'}</li>
      <li className={el.docs.ok ? 'vy-chip-ok' : 'vy-chip-warn'} title={el.docs.open.join(', ')}>{el.docs.ok ? '✓ Documentation complete' : `Documentation open: ${el.docs.open.length > 2 ? `${el.docs.open.length} items` : el.docs.open.map(x => x.replace(/_/g, ' ').replace('.html', '')).join(', ')}`}</li>
    </ul>
    {!el.ok && <p className="text-[14px] text-[#39443E] mt-2" data-testid="invoice-rule-note">{manager ? `You are acting as ${role}: you can issue this invoice now with a reason. The override is recorded on the invoice, in the audit trail and in the Case Record.` : 'Available when all three are complete. A practice manager can issue it earlier with a recorded override.'}</p>}
    {!compact || list.length ? <div className="overflow-x-auto mt-4"><table className="vy-table" data-testid="case-invoices"><thead><tr><th>Invoice</th><th>Fee schedule</th><th>Times</th><th className="text-right">Total</th><th className="text-right">Paid</th><th>Status</th><th /></tr></thead>
      <tbody>{!list.length ? <tr><td colSpan={7} className="text-[#4a5750]">No invoice for this case yet.</td></tr> : list.map(i => <tr key={i.id}><td className="font-semibold">{i.number}<div className="text-[13px] font-normal text-[#4a5750]">{new Date(i.createdAt).toLocaleDateString()} · {i.createdBy}</div>{i.override && <OverrideNote o={i.override} testId={`override-note-${i.number}`} />}</td><td>{i.scheduleName}</td><td>Facility {i.facilityMin} min · Anesthesia {i.anesthesiaMin} min</td><td className="text-right">{money(i.total)}</td><td className="text-right">{money(i.paid)}</td><td><span className={statusChip(i.status)}>{i.status}</span></td>
        <td className="text-right whitespace-nowrap">{i.status === 'Draft' && (el.ok || i.override) && <Btn variant="primary" onClick={() => saveInvoice({ ...i, status: 'Sent (simulated)', createdBy: actor })}>Mark sent</Btn>}{i.paid < i.total && <Btn variant="confirm" icon={<CreditCard size={16} />} onClick={() => setPay(i)} data-testid={`pay-${i.number}`}>Record payment</Btn>}</td></tr>)}</tbody></table></div> : null}
    {open && <InvoiceDialog patient={patient} actor={actor} role={role} override={open === 'override' ? el : null} onClose={() => setOpen(null)} />}
    {pay && <PaymentDialog inv={pay} actor={actor} onClose={() => setPay(null)} />}
  </section>;
};

export const OverrideNote: React.FC<{ o: NonNullable<Invoice['override']>; testId?: string }> = ({ o, testId }) =>
  <div className="mt-1 inline-block rounded-md border border-[#E3C27A] bg-[#FFF6E0] px-2 py-1 text-[13.5px] font-normal text-[#5b3d00]" data-testid={testId}><b className="font-semibold">Issued by manager override</b> · {o.by} ({o.role}) · {new Date(o.at).toLocaleString()}<br />Reason: {o.reason}</div>;

const unmetList = (el: ReturnType<typeof invoiceEligibility>) => [!el.cash && `Not a self-pay / cash-pay case`, !el.done && 'Procedure not finished', !el.docs.ok && `Documentation open: ${el.docs.open.map(x => x.replace(/_/g, ' ').replace('.html', '')).join(', ')}`].filter(Boolean) as string[];

const InvoiceDialog: React.FC<{ patient: PatientCase; actor: string; role: string; override: ReturnType<typeof invoiceEligibility> | null; onClose: () => void }> = ({ patient, actor, role, override, onClose }) => {
  const scheds = getSchedules(); const auto = scheduleFor(patient, scheds); const t = caseTimes(patient); const alt = BILLING_FEATURES.alternateSchedules;
  const [sid, setSid] = useState(auto.id); const [fac, setFac] = useState(String(t.facilityMin)); const [an, setAn] = useState(String(t.anesthesiaMin)); const [why, setWhy] = useState(''); const [ovWhy, setOvWhy] = useState('');
  const s = (alt && scheds.find(x => x.id === sid)) || auto; const changed = s.id !== auto.id || +fac !== t.facilityMin || +an !== t.anesthesiaMin;
  const inv = useMemo(() => buildInvoice(patient, { facilityMin: Math.max(0, +fac || 0), anesthesiaMin: Math.max(0, +an || 0), schedule: s, by: actor }), [patient, fac, an, s, actor]);
  const unmet = override ? unmetList(override) : [];
  const allowed = override ? isManagerRole(role) : invoiceEligibility(patient).ok; // re-checked at save time, not only when the button rendered
  const ok = allowed && (!changed || why.trim().length >= 4) && (!override || ovWhy.trim().length >= 8);
  const save = (status: Invoice['status']) => {
    if (!ok) return; const at = new Date().toISOString();
    const rec: Invoice = override ? { ...inv, status, override: { by: actor, role, reason: ovWhy.trim(), at, unmet } } : { ...inv, status };
    if (override) repo.audit({ caseId: patient.id, user: actor, role, action: 'invoice.override', detail: `Manager override: invoice ${inv.number} issued before eligibility was met (${unmet.join('; ')}). Reason: ${ovWhy.trim()}` });
    saveInvoice(rec);
    if (changed) repo.audit({ caseId: patient.id, user: actor, role: role || 'Billing', action: 'invoice.save', detail: `Invoice ${inv.number} adjusted (facility ${fac} min, anesthesia ${an} min${alt ? `, schedule ${s.name}` : ''}): ${why.trim()}` });
    onClose();
  };
  return <DialogShell size="lg" testId="invoice-dialog" kicker={override ? 'Cash-pay invoice · manager override' : 'Cash-pay invoice'} title={`Invoice for ${patient.name}`} subtitle={`${patient.procedure} · ${patient.appointmentDate || ''} · ${patient.paymentType || 'payment type not set'}`} onClose={onClose}
    footer={<><Btn variant="secondary" onClick={onClose}>Cancel</Btn><Btn variant="secondary" icon={<Save size={16} />} disabled={!ok} onClick={() => save('Draft')} data-testid="save-invoice-draft">Save draft</Btn><Btn variant={override ? 'edit' : 'confirm'} disabled={!ok} onClick={() => save('Sent (simulated)')} data-testid="issue-invoice">{override ? 'Issue with override (simulated send)' : 'Issue invoice (simulated send)'}</Btn></>}>
    {override && <div className="mb-4 rounded-lg border border-[#E3C27A] bg-[#FFF6E0] p-3 text-[#5b3d00]" data-testid="override-panel">
      <div className="font-semibold text-[15px]">Issuing before the normal rule is met</div>
      <ul className="list-disc ml-5 mt-1 text-[14px]">{unmet.map(u => <li key={u}>{u}</li>)}</ul>
      {!isManagerRole(role) && <p className="mt-1 text-[14px] text-[#8A1F1F]">Only a practice manager can issue with an override.</p>}
      <label className="vy-label mt-2 block !text-[#5b3d00]">Override reason (required, logged) *<input className="vy-input" value={ovWhy} onChange={e => setOvWhy(e.target.value)} placeholder="e.g. Patient paying at discharge; nurse note pending" data-testid="override-reason" /></label>
      <p className="text-[13.5px] mt-1">Recorded as “Issued by manager override” by {actor} ({role}) on the invoice, in the audit trail and in the Case Record.</p></div>}
    <div className={`grid gap-3 ${alt ? 'sm:grid-cols-3' : 'sm:grid-cols-2'}`}>
      {alt && <label className="vy-label">Fee schedule<select className="vy-input" value={sid} onChange={e => setSid(e.target.value)} data-testid="inv-schedule">{scheds.map(x => <option key={x.id} value={x.id}>{x.name}{x.id === auto.id ? ' (applies to this case)' : ''}</option>)}</select></label>}
      <label className="vy-label">Facility time (min)<input className="vy-input" inputMode="numeric" value={fac} onChange={e => setFac(e.target.value.replace(/\D/g, ''))} data-testid="inv-fac-min" /></label>
      <label className="vy-label">Anesthesia time (min)<input className="vy-input" inputMode="numeric" value={an} onChange={e => setAn(e.target.value.replace(/\D/g, ''))} data-testid="inv-an-min" /></label>
    </div>
    <p className="text-[14px] text-[#4a5750] mt-2" data-testid="inv-schedule-name">Fee schedule: {s.name} (time-based). {t.fromEvents ? `From the OR event bar: in room ${t.events.inOR || '—'} → out ${t.events.outOR || '—'}; anesthesia ${t.events.anesStart || '—'} → ${t.events.anesEnd || '—'}.` : 'No OR event times recorded; prefilled from the scheduled length.'}</p>
    {changed && <label className="vy-label mt-3 block">Reason for changing the times (logged) *<input className="vy-input" value={why} onChange={e => setWhy(e.target.value)} data-testid="inv-reason" /></label>}
    <table className="vy-table mt-4" data-testid="invoice-lines"><thead><tr><th>Line</th><th>How it was calculated</th><th className="text-right">Amount</th></tr></thead>
      <tbody>{inv.lines.map(l => <tr key={l.label}><td className="font-semibold">{l.label}</td><td>{l.detail}</td><td className="text-right">{money(l.amount)}</td></tr>)}<tr><td colSpan={2} className="font-semibold text-right">Total due</td><td className="text-right font-semibold" data-testid="invoice-total">{money(inv.total)}</td></tr></tbody></table>
    <p className="text-[13.5px] text-[#4a5750] mt-2">Fee amounts come from Administration → Billing & Payments → Fee Schedules. Sending is simulated in this build; nothing is emailed.</p>
  </DialogShell>;
};

const PaymentDialog: React.FC<{ inv: Invoice; actor: string; onClose: () => void }> = ({ inv, actor, onClose }) => {
  const [amt, setAmt] = useState((inv.total - inv.paid).toFixed(2)); const n = parseFloat(amt);
  return <DialogShell size="sm" kicker={inv.number} title="Record payment" subtitle={`Balance ${money(inv.total - inv.paid)}`} onClose={onClose}
    footer={<><Btn variant="secondary" onClick={onClose}>Cancel</Btn><Btn variant="confirm" disabled={!(n > 0)} onClick={() => { recordPayment(inv.id, n, actor); onClose(); }} data-testid="confirm-payment">Record {n > 0 ? money(n) : ''}</Btn></>}>
    <label className="vy-label">Amount received<input className="vy-input" inputMode="decimal" value={amt} onChange={e => setAmt(e.target.value.replace(/[^\d.]/g, ''))} /></label>
    <p className="text-[13.5px] text-[#4a5750] mt-2">Records the payment only. No card is charged in this build.</p>
  </DialogShell>;
};

/** All case invoices (Billing & Payments → Invoices). */
export const CaseInvoicesTable: React.FC = () => { useBilling(); const all = getInvoices();
  return <section className="vy-card p-5" data-testid="all-case-invoices"><CardTitle kicker="From completed cases" title={`Case invoices (${all.length})`} sub="Generated from the Case Record station or the patient page after the procedure and documentation are complete." />
    <div className="overflow-x-auto mt-3"><table className="vy-table"><thead><tr><th>Invoice</th><th>Patient</th><th>DOS</th><th>Procedure</th><th>Schedule</th><th className="text-right">Total</th><th className="text-right">Balance</th><th>Status</th></tr></thead>
      <tbody>{!all.length ? <tr><td colSpan={8} className="text-[#4a5750]">No case invoices yet.</td></tr> : all.map(i => <tr key={i.id}><td className="font-semibold">{i.number}</td><td>{i.patientName}</td><td>{i.dos}</td><td>{i.procedure}</td><td>{i.scheduleName}</td><td className="text-right">{money(i.total)}</td><td className="text-right">{money(i.total - i.paid)}</td><td><span className={statusChip(i.status)}>{i.status}</span></td></tr>)}</tbody></table></div></section>; };

/* ---------- Fee schedule editor (Administration → Billing & Payments → Fee Schedules) ---------- */
const KINDS: { k: MatchKind; label: string }[] = [{ k: 'default', label: 'Default (all other cases)' }, { k: 'procedure', label: 'Procedure contains' }, { k: 'surgeon', label: 'Surgeon is' }, { k: 'anesthesiaType', label: 'Anesthesia type contains' }, { k: 'room', label: 'Room is' }];
const TimeFeeEditor: React.FC<{ label: string; v: TimeFee; on: (v: TimeFee) => void; testId: string }> = ({ label, v, on, testId }) => {
  const num = (k: keyof TimeFee) => <input className="vy-input" inputMode="decimal" value={String(v[k])} onChange={e => on({ ...v, [k]: Number(e.target.value.replace(/[^\d.]/g, '')) || 0 })} data-testid={`${testId}-${k}`} />;
  return <fieldset className="p-3 rounded-lg border border-[#dfe5e1]"><legend className="vy-label px-1">{label}</legend>
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-2"><label className="vy-label">Base fee ($){num('base')}</label><label className="vy-label">Includes first (min){num('includedMin')}</label><label className="vy-label">Then per increment ($){num('perIncrement')}</label><label className="vy-label">Increment (min){num('incrementMin')}</label></div>
    <p className="text-[13.5px] text-[#4a5750] mt-1">e.g. 95 min → {money(timeFee(v, 95).amount)} · 120 min → {money(timeFee(v, 120).amount)}</p></fieldset>;
};
export const FeeScheduleEditor: React.FC<{ onToast?: (m: string) => void }> = ({ onToast }) => {
  const [list, setList] = useState<FeeSchedule[]>(getSchedules); const [dirty, setDirty] = useState(false);
  const upd = (i: number, s: FeeSchedule) => { setList(l => l.map((x, j) => j === i ? s : x)); setDirty(true); };
  const add = () => { setList(l => [...l, { ...JSON.parse(JSON.stringify(l[0])), id: `alt-${Date.now().toString(36)}`, name: 'New alternate schedule', match: { kind: 'procedure', value: '' } }]); setDirty(true); };
  const errs = (BILLING_FEATURES.alternateSchedules ? list : list.filter(x => x.match.kind === 'default')).flatMap(s => [...(!s.name.trim() ? ['Every schedule needs a name'] : []), ...(s.match.kind !== 'default' && !s.match.value.trim() ? [`“${s.name}” needs a matching value`] : []), ...(s.facility.incrementMin <= 0 || s.anesthesia.incrementMin <= 0 ? [`“${s.name}”: increment must be at least 1 minute`] : [])]).concat(list.filter(s => s.match.kind === 'default').length !== 1 ? ['Exactly one schedule must be the default'] : []);
  return <div className="space-y-4" data-testid="fee-schedules">
    <section className="vy-card p-5"><CardTitle kicker="Billing & Payments" title="Fee schedules" sub={`Time-based facility and anesthesia fees: a base fee that covers the first minutes, then a fee per increment (for example per 15 minutes).${BILLING_FEATURES.alternateSchedules ? ' Alternate schedules apply when the case matches; the first match wins, otherwise the default applies.' : ' Every invoice uses this schedule.'}`}
      right={<div className="flex gap-2">{BILLING_FEATURES.alternateSchedules && <Btn variant="add" icon={<Plus size={18} />} onClick={add} data-testid="add-schedule">Add alternate schedule</Btn>}<Btn variant="confirm" icon={<Save size={18} />} disabled={!dirty || errs.length > 0} onClick={() => { saveSchedules(list); setDirty(false); onToast?.('Fee schedules saved.'); }} data-testid="save-schedules">Save schedules</Btn></div>} />
      {errs.length > 0 && <ul className="mt-3 p-3 rounded-lg bg-[#FDECEC] text-[#7f1d1d] text-[15px] list-disc ml-5" role="alert">{errs.map(e => <li key={e}>{e}</li>)}</ul>}
      <p className="text-[13.5px] text-[#4a5750] mt-2">Example amounts only; set your practice’s own fees. Production keeps schedules server-side with effective dates.</p></section>
    {list.map((s, i) => (!BILLING_FEATURES.alternateSchedules && s.match.kind !== 'default') ? null : <section key={s.id} className="vy-card p-5 space-y-3" data-testid={`schedule-${i}`}>
      <div className="grid sm:grid-cols-3 gap-3">
        <label className="vy-label">Schedule name<input className="vy-input" value={s.name} onChange={e => upd(i, { ...s, name: e.target.value })} /></label>
        {BILLING_FEATURES.alternateSchedules && <label className="vy-label">Applies when<select className="vy-input" value={s.match.kind} onChange={e => upd(i, { ...s, match: { ...s.match, kind: e.target.value as MatchKind } })} data-testid={`schedule-${i}-kind`}>{KINDS.map(k => <option key={k.k} value={k.k}>{k.label}</option>)}</select></label>}
        {BILLING_FEATURES.alternateSchedules && s.match.kind !== 'default' && <label className="vy-label">Value<input className="vy-input" value={s.match.value} onChange={e => upd(i, { ...s, match: { ...s.match, value: e.target.value } })} placeholder="e.g. lesion, Sam Patel, MAC" data-testid={`schedule-${i}-value`} /></label>}
      </div>
      <TimeFeeEditor label="Facility fee (in room → out of room)" v={s.facility} on={v => upd(i, { ...s, facility: v })} testId={`schedule-${i}-fac`} />
      <TimeFeeEditor label="Anesthesia fee (anesthesia start → end)" v={s.anesthesia} on={v => upd(i, { ...s, anesthesia: v })} testId={`schedule-${i}-an`} />
      <div className="flex flex-wrap gap-3 items-end"><label className="vy-label">Surgeon fee, flat ($, optional)<input className="vy-input" inputMode="decimal" value={String(s.surgeonFee)} onChange={e => upd(i, { ...s, surgeonFee: Number(e.target.value.replace(/[^\d.]/g, '')) || 0 })} /></label>
        {s.match.kind !== 'default' && <Btn variant="danger" icon={<Trash2 size={16} />} onClick={() => { setList(l => l.filter((_, j) => j !== i)); setDirty(true); }}>Remove schedule</Btn>}</div>
    </section>)}
  </div>;
};
