import React from 'react';
import type { PatientCase } from '../types';
import { repo } from '../v6/dataLayer';
import { ruleFor } from '../v6/formRules';
import { stationPlan, allStationForms } from './myForms';
import { balanceFor } from './billing';
import { getState } from './clearance';
import { useBilling } from './InvoicePanel';

const hm = (v?: unknown) => { const m = String(v || '').match(/^(\d{1,2}):(\d{2})/); return m ? +m[1] * 60 + +m[2] : null; };
/** Item 16: Operations Intelligence + Billing signals shown at every station. */
export const OpsStrip: React.FC<{ patient: PatientCase; station: string }> = ({ patient, station }) => {
  useBilling();
  const files = station === 'caseRecord' ? allStationForms() : (() => { const p = stationPlan(station as any); return p.required; })();
  const locked = files.filter(f => repo.getForm(patient.id, f).status === 'locked').length;
  const open = files.filter(f => { const r = repo.getForm(patient.id, f); return r.status !== 'locked' && ruleFor(f).signers.some(x => x.required); }).length;
  const f = repo.getFacts(patient.id); const now = new Date(); const nowMin = now.getHours() * 60 + now.getMinutes();
  const inOR = hm(f['time.inOR']?.value), out = hm(f['time.outOR']?.value);
  const orMin = inOR != null ? ((out ?? nowMin) - inOR + 1440) % 1440 : null;
  const sched = patient.estimatedDurationMins || 0;
  const ver = repo.getStationVerification(patient.id); const verified = Object.keys(ver).length;
  const bal = balanceFor(patient.id); const clr = getState(patient.id);
  const items: [string, string, string][] = [
    [station === 'caseRecord' ? 'Documents locked' : 'Forms signed here', `${locked} / ${files.length}`, open ? 'vy-chip-warn' : 'vy-chip-ok'],
    ['Stations verified', `${verified} / 7`, 'vy-chip-info'],
    ['Room time', orMin == null ? 'Not in room' : `${orMin} min${out == null ? ' (running)' : ''}${sched ? ` · booked ${sched}` : ''}`, orMin != null && sched && orMin > sched ? 'vy-chip-warn' : 'vy-chip-muted'],
    ['Clearance', clr.cleared ? 'Cleared' : clr.review ? 'Reviewed, not cleared' : 'Not reviewed', clr.cleared ? 'vy-chip-ok' : 'vy-chip-warn'],
    ['Balance', `${patient.paymentType || '—'} · ${bal.label}`, bal.due > 0 ? 'vy-chip-warn' : bal.invoices ? 'vy-chip-ok' : 'vy-chip-muted'],
  ];
  return <section className="vy-card px-4 py-3 flex flex-wrap gap-x-5 gap-y-2 items-center" aria-label="Operations and billing" data-testid="ops-strip">
    <span className="vy-kicker">Operations · Billing</span>
    {items.map(([k, v, c]) => <span key={k} className="flex items-center gap-2 text-[14px]"><span className="text-[#3a463f]">{k}</span><span className={c}>{v}</span></span>)}
  </section>;
};

/** Balance / payment status chip for the patient header and Scheduler (item 16). */
export const BalanceChip: React.FC<{ caseId: string; paymentType?: string; onClick?: () => void }> = ({ caseId, paymentType, onClick }) => {
  useBilling(); const b = balanceFor(caseId);
  const cls = b.due > 0 ? 'vy-chip-warn' : b.invoices ? 'vy-chip-ok' : 'vy-chip-muted';
  return <button type="button" onClick={onClick} className={`${cls} min-h-[44px] px-3`} data-testid="balance-chip" title="Billing & Payments status for this case">{paymentType || 'Payment type not set'} · {b.label}</button>;
};
