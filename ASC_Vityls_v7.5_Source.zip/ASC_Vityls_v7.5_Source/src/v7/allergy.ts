import { repo } from '../v6/dataLayer';
/*
 * v7 allergy status (item 1). One rule everywhere:
 *  - NKDA explicitly recorded            → light green
 *  - nothing recorded / not reported     → "Not Reported", neutral grey
 *  - one or more allergies recorded      → light red
 *
 * v7.5: patient-reported allergies (Medical History / intake) REPLACE the
 * Not Reported state everywhere — never show "Not Reported · patient reported: …".
 * Confirm at a station writes them into patient.allergies.
 */
export type AllergyState = 'nkda' | 'not-reported' | 'allergies';
const NKDA = /^(nkda|nka|no known (drug )?allerg(y|ies)( \(nkda\))?|none known|no known allergies)$/i;
export function allergyState(list?: string[] | string | null): { state: AllergyState; text: string; items: string[] } {
  const arr = (Array.isArray(list) ? list : list ? String(list).split(/[;,]/) : []).map(s => String(s || '').trim()).filter(Boolean);
  const real = arr.filter(a => !NKDA.test(a) && !/^(not reported|unknown|none|n\/a)$/i.test(a));
  if (real.length) return { state: 'allergies', text: real.join(', '), items: real };
  if (arr.some(a => NKDA.test(a))) return { state: 'nkda', text: 'NKDA (no known drug allergies)', items: [] };
  return { state: 'not-reported', text: 'Not Reported', items: [] };
}
export const ALLERGY_STYLE: Record<AllergyState, { box: string; text: string; label: string }> = {
  nkda: { box: 'bg-[#E7F4EC] border-[#B5D9C2]', text: 'text-[#17482F]', label: 'NKDA' },
  'not-reported': { box: 'bg-[#F3F4F2] border-[#D3D8D4]', text: 'text-[#39443E]', label: 'Not Reported' },
  allergies: { box: 'bg-[#FDECEC] border-[#EDB5B5]', text: 'text-[#8A1F1F]', label: 'Allergies' },
};
export const allergyBox = (list?: string[] | string | null) => ALLERGY_STYLE[allergyState(list).state];

/** Patient-reported allergies from intake (Medical History) that a clinician has not yet confirmed. */
export function reportedAllergy(patientId?: string): { value: string; form: string } | null {
  if (!patientId) return null;
  try { const f = (repo.getFacts(patientId) as any)['patient.reportedAllergies']; return f && f.value ? { value: String(f.value), form: f.source?.formTitle || 'intake' } : null; } catch { return null; }
}

/**
 * Effective allergy display for chart / stations / case record.
 * Chart allergies win. If still not-reported, patient-reported intake replaces
 * Not Reported (with pendingConfirm) — never concatenate the two.
 */
export function effectiveAllergy(allergies?: string[] | string | null, patientId?: string): {
  state: AllergyState; text: string; items: string[]; pendingConfirm: boolean; sourceForm?: string; rawList: string[];
} {
  const chart = allergyState(allergies);
  if (chart.state !== 'not-reported') {
    const raw = Array.isArray(allergies) ? allergies : chart.items.length ? chart.items : chart.state === 'nkda' ? ['NKDA'] : [];
    return { ...chart, pendingConfirm: false, rawList: raw.map(String) };
  }
  const rep = reportedAllergy(patientId);
  if (rep) {
    const fromRep = allergyState(rep.value);
    const raw = fromRep.state === 'nkda' ? ['NKDA'] : fromRep.items.length ? fromRep.items : String(rep.value).split(/[;,]/).map(s => s.trim()).filter(Boolean);
    return { ...fromRep, pendingConfirm: true, sourceForm: rep.form, rawList: raw };
  }
  return { ...chart, pendingConfirm: false, rawList: [] };
}

/** Parse a free-text allergy list into the array stored on patient.allergies. */
export function parseAllergyList(text: string): string[] {
  const t = String(text || '').trim();
  if (!t) return [];
  if (NKDA.test(t) || /^nkda$/i.test(t)) return ['NKDA'];
  return t.split(/[;,]/).map(x => x.trim()).filter(Boolean);
}
