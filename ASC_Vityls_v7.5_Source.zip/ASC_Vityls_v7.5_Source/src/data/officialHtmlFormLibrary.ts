import type { AscDefaultFormTemplate } from './ascDefaultFormLibrary';
import { ASC_DEFAULT_FORM_LIBRARY } from './ascDefaultFormLibrary';

const CORE_PREOP_TEMPLATE: AscDefaultFormTemplate = {
  title: 'Pre-Operative Assessment & Readiness',
  sourceFile: 'Office_Intelligence_PreOperative_Assessment_Readiness.html',
  group: 'Nursing / Recovery',
  collectionStage: 'Nursing',
  reviewStages: ['Anesthesia','Surgeon'],
  sourceControlCount: 11,
  signatureZones: 2,
  fields: [
    { id:'identity',label:'Patient / procedure / surgeon / date of service',type:'text',required:true,owner:'Front Desk',source:'Chart' },
    { id:'history',label:'Current history / interval change review',type:'textarea',required:true,owner:'Nursing + Provider',source:'Chart' },
    { id:'allergies',label:'Allergies — carried forward; verify/update',type:'clinical-list',required:true,owner:'Nursing',source:'Chart' },
    { id:'meds',label:'Active medications — carried forward; verify/update',type:'clinical-list',required:true,owner:'Nursing',source:'Chart' },
    { id:'npo',label:'NPO status',type:'radio',required:true,owner:'Nursing',source:'Patient',options:['Confirmed','Not confirmed','Exception — explain'] },
    { id:'ride',label:'Responsible adult / transportation',type:'radio',required:true,owner:'Front Desk + Nursing',source:'Patient',options:['Confirmed','Not confirmed','Not applicable'] },
    { id:'clearance',label:'Medical clearance / H&P source reviewed',type:'checkbox',required:true,owner:'Nursing + Provider',source:'Chart',options:['Reviewed and available'] },
    { id:'vte',label:'VTE risk assessment and prophylaxis plan',type:'score',required:true,owner:'Nursing + Surgeon',source:'Provider' },
    { id:'consent',label:'Procedure consent — procedure + named surgeon',type:'signature',required:true,owner:'Patient + Surgeon',source:'Provider' },
    { id:'anesthesiaConsent',label:'Anesthesia / sedation consent',type:'signature',required:true,owner:'Patient + Anesthesia',source:'Provider' },
    { id:'timeout',label:'Time-out verification',type:'checkbox',required:true,owner:'OR Team',source:'Provider',options:['Patient','Procedure','Site/laterality','Implants/equipment'] },
  ],
};


const SURGEON_MEMBERSHIP_TEMPLATE: AscDefaultFormTemplate = {
  title: 'Surgeon Membership & Privileges Application',
  sourceFile: 'Surgeon_Membership_Application.html',
  group: 'Credentialing',
  collectionStage: 'Provider Onboarding',
  reviewStages: ['Administration','Credentialing Committee'],
  sourceControlCount: 34,
  signatureZones: 1,
  fields: [
    { id:'surgeon-full-name',label:'Applicant full name',type:'text',required:true,owner:'Surgeon',source:'Provider' },
    { id:'surgeon-specialty',label:'Specialty',type:'text',required:true,owner:'Surgeon',source:'Provider' },
    { id:'surgeon-license',label:'Medical license number',type:'text',required:true,owner:'Surgeon',source:'Provider' },
    { id:'surgeon-dea',label:'DEA registration',type:'text',required:false,owner:'Surgeon',source:'Provider' },
    { id:'surgeon-malpractice',label:'Malpractice carrier / policy',type:'text',required:true,owner:'Surgeon',source:'Provider' },
    { id:'surgeon-privileges',label:'Requested privileges',type:'textarea',required:true,owner:'Surgeon',source:'Provider' },
    { id:'surgeon-attestation',label:'Applicant attestation and signature',type:'signature',required:true,owner:'Surgeon',source:'Provider' },
  ],
};

const STANDARD_HEADER_FIELD = /(patient\s*(full\s*)?name|date\s*of\s*birth|\bdob\b|\bage\b|gender|\bsex\b|medical\s*record|\bmrn\b)/i;

const normalizeForStandardHeader = (template: AscDefaultFormTemplate): AscDefaultFormTemplate => ({
  ...template,
  fields: template.fields.filter(field => !STANDARD_HEADER_FIELD.test(field.label)),
});

const PATIENT_REGISTRATION_TEMPLATE: AscDefaultFormTemplate = {
  title: 'Patient Registration', sourceFile: 'Patient_Registration.html', group: 'Patient Intake',
  collectionStage: 'Home / Patient Portal', reviewStages: ['Front Desk'], sourceControlCount: 22, signatureZones: 1,
  fields: [
    {id:'registration-first-name',label:'Legal First Name',type:'text',required:true,owner:'Patient',source:'Patient'},
    {id:'registration-last-name',label:'Legal Last Name',type:'text',required:true,owner:'Patient',source:'Patient'},
    {id:'registration-dob',label:'Date of Birth',type:'date',required:true,owner:'Patient',source:'Patient'},
    {id:'registration-gender',label:'Gender',type:'select',required:false,owner:'Patient',source:'Patient',options:['Female','Male','Nonbinary / another identity','Prefer not to answer']},
    {id:'registration-ethnicity',label:'Ethnicity',type:'text',required:false,owner:'Patient',source:'Patient'},
    {id:'registration-language',label:'Preferred Language',type:'text',required:false,owner:'Patient',source:'Patient'},
    {id:'registration-address1',label:'Street Address',type:'text',required:true,owner:'Patient',source:'Patient'},
    {id:'registration-address2',label:'Apartment / Suite',type:'text',required:false,owner:'Patient',source:'Patient'},
    {id:'registration-city',label:'City',type:'text',required:true,owner:'Patient',source:'Patient'},
    {id:'registration-state',label:'State',type:'text',required:true,owner:'Patient',source:'Patient'},
    {id:'registration-zip',label:'ZIP Code',type:'text',required:true,owner:'Patient',source:'Patient'},
    {id:'registration-phone',label:'Telephone',type:'text',required:true,owner:'Patient',source:'Patient'},
    {id:'registration-email',label:'Email (optional)',type:'text',required:false,owner:'Patient',source:'Patient'},
    {id:'registration-occupation',label:'Occupation',type:'text',required:false,owner:'Patient',source:'Patient'},
    {id:'registration-employer',label:'Employer',type:'text',required:false,owner:'Patient',source:'Patient'},
    {id:'registration-employer-phone',label:'Employer Telephone',type:'text',required:false,owner:'Patient',source:'Patient'},
    {id:'registration-emergency-name',label:'Emergency Contact Name',type:'text',required:true,owner:'Patient',source:'Patient'},
    {id:'registration-emergency-relationship',label:'Emergency Contact Relationship',type:'text',required:true,owner:'Patient',source:'Patient'},
    {id:'registration-emergency-phone',label:'Emergency Contact Telephone',type:'text',required:true,owner:'Patient',source:'Patient'},
    {id:'registration-primary-doctor',label:'Primary Doctor',type:'text',required:false,owner:'Patient',source:'Patient'},
    {id:'registration-primary-doctor-phone',label:'Primary Doctor Telephone',type:'text',required:false,owner:'Patient',source:'Patient'},
    {id:'registration-referral-source',label:'Referral Source',type:'text',required:false,owner:'Patient',source:'Patient'},
    {id:'registration-signature',label:'Patient / Responsible Party Signature',type:'signature',required:true,owner:'Patient',source:'Patient'},
  ],
};

const ADMISSION_NORMALIZED: AscDefaultFormTemplate[] = ASC_DEFAULT_FORM_LIBRARY.map(template => {
  const normalized = normalizeForStandardHeader(template);
  if (template.sourceFile === 'Billing_Fee_Disclosure.html') return { ...normalized, title: 'Cash Payment Fee Disclosure' };
  if (template.sourceFile !== 'Admission_Form.html') return normalized;
  const withoutFee = normalized.fields.filter(field => !/(fee disclosure|cash|init1|init2)/i.test(`${field.label} ${field.id}`));
  const withoutSignatures = withoutFee.filter(field => field.type !== 'signature');
  return { ...normalized, fields: withoutSignatures, signatureZones: 0 };
});

/** v7.4 item 5: no signature fields in Form Studio templates (Signer setup + multi-signer panel only). */
export const OFFICIAL_HTML_FORM_LIBRARY: AscDefaultFormTemplate[] = [
  PATIENT_REGISTRATION_TEMPLATE,
  ...ADMISSION_NORMALIZED,
  normalizeForStandardHeader(SURGEON_MEMBERSHIP_TEMPLATE),
].map(t => ({ ...t, fields: t.fields.filter(f => f.type !== 'signature'), signatureZones: 0 }));

export const OFFICIAL_HTML_FORM_TEMPLATE_COUNT = OFFICIAL_HTML_FORM_LIBRARY.length;
