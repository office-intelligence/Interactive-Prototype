import { PatientCase, TaskItem, CommunicationStats, BottleneckAlert } from '../types';
import { 
  generateSampleDriverLicense, 
  generateSampleInsuranceFront, 
  generateSampleInsuranceBack 
} from '../utils/cardTemplates';

export const initialPatientCases: PatientCase[] = [];

export const initialBottleneckAlerts: BottleneckAlert[] = [];

export const initialTasks: TaskItem[] = [];

export const initialStats: CommunicationStats = {
  emails: { total: 0, processed: 0, urgent: 0 },
  faxes: { total: 0, processed: 0, urgent: 0 },
  portal: { total: 0, processed: 0, urgent: 0 },
};
