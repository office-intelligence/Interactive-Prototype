// Registry of documents rendered through the real-PDF viewer (PdfFormViewer)
// rather than the HTML-template system. This is an additive, opt-in layer:
// only documents listed here are migrated off the HTML forms; everything
// else keeps using the existing HTML-template + iframe rendering untouched
// while this approach is validated against real practice documents.
//
// Phase 1 covers exactly the two documents proven against the practice's own
// real PDFs (see the Anesthesia Questionnaire <-> Pre-Op Evaluation prefill
// relationship in pdfPrefillMap.ts). The Consent for Anesthesia and the
// Malignant Hyperthermia & VTE Risk Assessment pages from the same source
// PDF are a deliberate next phase, not yet split out or wired in here.

export interface PdfFormDocument {
  /** Stable id — also used as the localStorage draft/lock key and must be
   *  unique across the whole catalog. */
  id: string;
  title: string;
  pdfUrl: string;
  requiresSignature: boolean;
}

export const PDF_FORM_DOCUMENTS: PdfFormDocument[] = [
  {
    id: 'pdf-anesthesia-questionnaire',
    title: 'Anesthesia Questionnaire',
    pdfUrl: 'pdf-templates/anesthesia-questionnaire.pdf',
    requiresSignature: true,
  },
  {
    id: 'pdf-anesthesia-preop-evaluation',
    title: 'Anesthesia Pre-Op Evaluation',
    pdfUrl: 'pdf-templates/anesthesia-preop-evaluation.pdf',
    requiresSignature: true,
  },
  {
    // Converted from the practice's real "Pre-Operative Checklist and
    // Assessment" PDF, which had no AcroForm fields at all (a flat
    // print-to-PDF document — see the field-injection tooling this was
    // built with, kept for reuse on the rest of the nursing catalog).
    id: 'pdf-nursing-preop-checklist',
    title: 'Pre-Operative Checklist and Assessment',
    pdfUrl: 'pdf-templates/nursing-preop-checklist.pdf',
    requiresSignature: false,
  },
];

export function getPdfFormDocument(id: string): PdfFormDocument | undefined {
  return PDF_FORM_DOCUMENTS.find((d) => d.id === id);
}
