import { PatientCase } from '../types';
import { initialPatientCases } from '../data/mockData';
import { getCasesForDateKey } from './dateCases';
import { 
  generateSampleDriverLicense, 
  generateSampleInsuranceFront, 
  generateSampleInsuranceBack 
} from './cardTemplates';

export interface MasterPatientRecord {
  id: string;
  patientId: string;
  name: string;
  firstName: string;
  lastName: string;
  dob: string;
  age: number | string;
  phone: string;
  gender?: string;
  procedure?: string;
  surgeon?: string;
  anesthesiologist?: string;
  anesthesiaType?: string;
  paymentType?: string;
  allergies?: string[];
  notes?: string;
  arrivalStatus?: string;
  room?: string;
}

export function parseFirstAndLastName(fullName: string): { firstName: string; lastName: string } {
  if (!fullName) return { firstName: '', lastName: '' };
  const cleaned = fullName.replace(/^(Dr\.|Mr\.|Mrs\.|Ms\.)\s+/i, '').trim();
  
  if (cleaned.includes(',')) {
    const parts = cleaned.split(',').map((p) => p.trim());
    return {
      lastName: parts[0] || '',
      firstName: parts[1] || ''
    };
  }
  
  const parts = cleaned.split(/\s+/);
  if (parts.length === 1) {
    return { firstName: parts[0], lastName: parts[0] };
  }
  const lastName = parts[parts.length - 1];
  const firstName = parts.slice(0, parts.length - 1).join(' ');
  return { firstName, lastName };
}

// Built-in directory of all recognized practice patients
export const MASTER_PATIENT_DIRECTORY: MasterPatientRecord[] = [];

export function getAllMasterPatients(customCases?: PatientCase[]): MasterPatientRecord[] {
  const patientMap = new Map<string, MasterPatientRecord>();

  // Add default master list first
  MASTER_PATIENT_DIRECTORY.forEach((p) => {
    patientMap.set(p.name.toLowerCase(), p);
  });

  // Merge with initial cases and date cases
  const dates = ['2026-07-12', '2026-07-13', '2026-07-14', '2026-07-15', '2026-07-16', '2026-07-17', '2026-07-18', '2026-07-19'];
  dates.forEach((dKey) => {
    try {
      const dayCases = getCasesForDateKey(dKey, dKey);
      dayCases.forEach((c) => {
        if (!c.name || c.name.toLowerCase().includes('or block')) return;
        const { firstName, lastName } = parseFirstAndLastName(c.name);
        const existing = patientMap.get(c.name.toLowerCase());
        if (!existing) {
          patientMap.set(c.name.toLowerCase(), {
            id: c.id,
            patientId: c.patientId,
            name: c.name,
            firstName,
            lastName,
            dob: c.dob || '01/15/1980',
            age: c.age || 40,
            phone: c.phone || '',
            gender: c.gender || 'Female',
            procedure: c.procedure,
            surgeon: c.surgeon,
            anesthesiologist: c.anesthesiologist,
            anesthesiaType: 'General Anesthesia',
            paymentType: 'Self-Pay',
            allergies: c.allergies,
            notes: c.notes,
            arrivalStatus: c.arrivalStatus,
            room: c.room
          });
        }
      });
    } catch (e) {
      // Ignore
    }
  });

  // Merge with custom cases if supplied
  if (customCases && Array.isArray(customCases)) {
    customCases.forEach((c) => {
      if (!c.name || c.name.toLowerCase().includes('or block')) return;
      const { firstName, lastName } = parseFirstAndLastName(c.name);
      patientMap.set(c.name.toLowerCase(), {
        id: c.id,
        patientId: c.patientId,
        name: c.name,
        firstName,
        lastName,
        dob: c.dob || '01/15/1980',
        age: c.age || 40,
        phone: c.phone || '',
        gender: c.gender || 'Female',
        procedure: c.procedure,
        surgeon: c.surgeon,
        anesthesiologist: c.anesthesiologist,
        anesthesiaType: 'General Anesthesia',
        paymentType: 'Self-Pay',
        allergies: c.allergies,
        notes: c.notes,
        arrivalStatus: c.arrivalStatus,
        room: c.room
      });
    });
  }

  return Array.from(patientMap.values());
}

/**
 * Converts a MasterPatientRecord into a full PatientCase object
 */
export function convertMasterRecordToPatientCase(
  m: MasterPatientRecord, 
  existingCases: PatientCase[] = []
): PatientCase {
  const existing = existingCases.find(
    (c) => c.id === m.id || c.patientId === m.patientId || c.name.toLowerCase() === m.name.toLowerCase()
  );
  if (existing) return existing;

  const ageNum = typeof m.age === 'number' ? m.age : parseInt(String(m.age), 10) || 40;

  return {
    id: m.id || `case-${m.patientId}`,
    patientId: m.patientId || '114000',
    name: m.name,
    age: ageNum,
    gender: (m.gender as any) || 'Female',
    dob: m.dob || '01/15/1980',
    phone: m.phone || '',
    scheduledTime: '08:00 AM',
    estimatedDurationMins: 120,
    room: m.room || 'OR 1',
    surgeon: m.surgeon || '',
    anesthesiologist: m.anesthesiologist || 'Anesthesia Provider',
    procedure: m.procedure || 'Elective Plastic & Reconstructive Surgery',
    aiSummary: m.notes || `All pre-operative labs and medical clearance verified for ${m.name}. Baseline H&P reviewed.`,
    readinessScore: 98,
    readinessLevel: 'CLEARED',
    allergies: m.allergies || ['None known'],
    labs: [
      { name: 'CBC', value: '13.5 g/dL', status: 'normal' },
      { name: 'BMP', value: 'Normal', status: 'normal' },
      { name: 'PT/INR', value: '1.0', status: 'normal' }
    ],
    stage: 'CHECK_IN',
    arrivalStatus: (m.arrivalStatus as any) || 'ARRIVED',
    arrivalTime: '7:15 AM',
    bottlenecks: [],
    actionItems: [],
    notes: m.notes || `Active longitudinal record for ${m.name}.`,
    idCardUrl: generateSampleDriverLicense(m.name.toUpperCase(), m.dob || '01/15/1980', `D${m.patientId}`, '120 RODEO DR, BEVERLY HILLS, CA'),
    insuranceCardFrontUrl: generateSampleInsuranceFront(m.name.toUpperCase(), 'Blue Shield PPO', `BS-${m.patientId}`, 'GRP-001'),
    insuranceCardBackUrl: generateSampleInsuranceBack('Blue Shield PPO', '1-800-555-0199')
  };
}

/**
 * Searches practice patients by last name (or full query).
 * Specifically matches when the user types the first 3 letters of a patient's last name,
 * as well as general search by name, phone, DOB, or ID.
 */
export function searchPatientsByLastName(
  query: string, 
  customCases?: PatientCase[],
  options?: { minChars?: number; matchAnywhere?: boolean }
): MasterPatientRecord[] {
  if (!query) return [];
  const q = query.trim().toLowerCase();
  const minChars = options?.minChars !== undefined ? options.minChars : 3;
  if (q.length < minChars) return [];

  const allPatients = getAllMasterPatients(customCases);

  return allPatients.filter((patient) => {
    const lastNameLower = patient.lastName.toLowerCase();
    const firstNameLower = patient.firstName.toLowerCase();
    const fullNameLower = patient.name.toLowerCase();
    const cleanPhone = patient.phone.replace(/\D/g, '');
    const cleanQuery = q.replace(/\D/g, '');

    // Check last name starting with query or containing query
    const lastNameStartsWith = lastNameLower.startsWith(q);
    const lastNameContains = lastNameLower.includes(q);
    
    // Check full name / first name
    const fullNameContains = fullNameLower.includes(q);
    const firstNameStartsWith = firstNameLower.startsWith(q);
    
    // Check DOB & Phone & ID
    const dobContains = patient.dob.toLowerCase().includes(q);
    const idContains = patient.patientId.toLowerCase().includes(q);
    const phoneContains = cleanQuery.length >= 3 && cleanPhone.includes(cleanQuery);

    return lastNameStartsWith || lastNameContains || firstNameStartsWith || fullNameContains || dobContains || idContains || phoneContains;
  }).sort((a, b) => {
    // Prioritize exact last name startsWith matches
    const aLastStart = a.lastName.toLowerCase().startsWith(q);
    const bLastStart = b.lastName.toLowerCase().startsWith(q);
    if (aLastStart && !bLastStart) return -1;
    if (!aLastStart && bLastStart) return 1;
    return a.lastName.localeCompare(b.lastName);
  });
}

export interface PatientAppointmentHistoryRecord {
  id: string;
  patientId: string;
  patientName: string;
  dob: string;
  age: string;
  phone: string;
  date: string; // e.g. "07/13/2026"
  dayName: string; // e.g. "Monday"
  startTime: string; // e.g. "08:00 AM"
  length: string; // e.g. "3.5 Hours"
  room: string; // e.g. "OR #1"
  title: string;
  surgeon: string;
  anesthesiologist: string;
  anesthesiaType: string;
  procedure: string;
  paymentType: string;
  notes: string;
  status: 'Scheduled' | 'Completed' | 'Prior Visit' | 'Follow-Up';
  dayIndex?: number; // 0=Mon, 1=Tue, ..., 6=Sun
  caseId?: string;
  bgColor?: string;
  startHour?: number;
  durationHours?: number;
}

// Pre-defined prior historical visits for practice patients
const HISTORICAL_APPOINTMENT_DATA: { [patientKey: string]: Array<Omit<PatientAppointmentHistoryRecord, 'patientId' | 'patientName' | 'dob' | 'age' | 'phone'>> } = {
  'rostova': [
    {
      id: 'hist-ros-1',
      date: '06/22/2026',
      dayName: 'Monday',
      startTime: '09:30 AM',
      length: '1.0 Hour',
      room: 'Exam Room 3',
      title: 'Rostova, E - Pre-Op Clearance',
      surgeon: 'Provider',
      anesthesiologist: 'Anesthesia Provider',
      anesthesiaType: 'N/A (Consultation)',
      procedure: 'Pre-Operative Clearance & 3D Computerized Facial Simulation',
      paymentType: 'Commercial Insurance',
      notes: 'CT Sinus and airway evaluated. 3D simulation approved by patient.',
      status: 'Completed'
    },
    {
      id: 'hist-ros-2',
      date: '05/18/2026',
      dayName: 'Monday',
      startTime: '02:00 PM',
      length: '45 Mins',
      room: 'Consult Suite A',
      title: 'Rostova, E - Initial Consultation',
      surgeon: 'Provider',
      anesthesiologist: 'N/A',
      anesthesiaType: 'N/A',
      procedure: 'Primary Aesthetic Rhinoplasty & Airway Consultation',
      paymentType: 'Commercial Insurance',
      notes: 'Patient presented for nasal obstruction and aesthetic refinement.',
      status: 'Prior Visit'
    }
  ],
  'kensington': [
    {
      id: 'hist-ken-1',
      date: '06/10/2026',
      dayName: 'Wednesday',
      startTime: '10:00 AM',
      length: '1.0 Hour',
      room: 'Exam Room 1',
      title: 'Kensington, S - Ultrasound & Sizing',
      surgeon: '',
      anesthesiologist: 'Anesthesia Provider',
      anesthesiaType: 'N/A',
      procedure: 'High-Resolution Breast Ultrasound & Sizing Verification',
      paymentType: 'Self-Pay',
      notes: 'Subpectoral pocket integrity evaluated. Smooth cohesive gel selected.',
      status: 'Completed'
    },
    {
      id: 'hist-ken-2',
      date: '04/15/2026',
      dayName: 'Wednesday',
      startTime: '11:15 AM',
      length: '45 Mins',
      room: 'Consult Suite B',
      title: 'Kensington, S - Consultation',
      surgeon: '',
      anesthesiologist: 'N/A',
      anesthesiaType: 'N/A',
      procedure: 'Longitudinal Implant Exchange Evaluation',
      paymentType: 'Self-Pay',
      notes: 'Discussed bilateral capsulorrhaphy and revision goals.',
      status: 'Prior Visit'
    }
  ],
  'vance': [
    {
      id: 'hist-van-1',
      date: '06/05/2026',
      dayName: 'Friday',
      startTime: '08:30 AM',
      length: '1.0 Hour',
      room: 'Pre-Op Suite 2',
      title: 'Vance, D - Pre-Op EKG & Labs',
      surgeon: '',
      anesthesiologist: 'Anesthesia Provider',
      anesthesiaType: 'N/A',
      procedure: 'Pre-Operative Comprehensive EKG & Laboratory Clearance',
      paymentType: 'Self-Pay',
      notes: 'EKG normal sinus rhythm. CBC, CMP, and coagulation panel normal.',
      status: 'Completed'
    },
    {
      id: 'hist-van-2',
      date: '05/02/2026',
      dayName: 'Saturday',
      startTime: '01:30 PM',
      length: '45 Mins',
      room: 'Consult Suite A',
      title: 'Vance, D - Initial Consultation',
      surgeon: '',
      anesthesiologist: 'N/A',
      anesthesiaType: 'N/A',
      procedure: 'Saline Implant Removal & Mastopexy Planning',
      paymentType: 'Self-Pay',
      notes: 'Mastopexy vector markings reviewed.',
      status: 'Prior Visit'
    }
  ],
  'holloway': [
    {
      id: 'hist-hol-1',
      date: '05/20/2026',
      dayName: 'Wednesday',
      startTime: '10:30 AM',
      length: '1.0 Hour',
      room: 'Exam Room 2',
      title: 'Holloway, P - Facial Mapping',
      surgeon: 'Provider',
      anesthesiologist: 'Anesthesia Provider',
      anesthesiaType: 'N/A',
      procedure: 'Facial Anatomy & Deep SMAS Vector Mapping',
      paymentType: 'Self-Pay',
      notes: 'High SMAS flap dissection plan reviewed. Medical clearance confirmed.',
      status: 'Completed'
    },
    {
      id: 'hist-hol-2',
      date: '03/12/2026',
      dayName: 'Thursday',
      startTime: '03:00 PM',
      length: '45 Mins',
      room: 'Consult Suite A',
      title: 'Holloway, P - Consultation',
      surgeon: 'Provider',
      anesthesiologist: 'N/A',
      anesthesiaType: 'N/A',
      procedure: 'Facial Rejuvenation & SMAS Rhytidectomy Consultation',
      paymentType: 'Self-Pay',
      notes: 'Comprehensive facial aesthetic workup completed.',
      status: 'Prior Visit'
    }
  ],
  'brody': [
    {
      id: 'hist-bro-1',
      date: '06/28/2026',
      dayName: 'Sunday',
      startTime: '11:00 AM',
      length: '1.0 Hour',
      room: 'Exam Room 4',
      title: 'Brody, M - CT Sinus & Endoscopy',
      surgeon: 'Provider',
      anesthesiologist: 'Anesthesia Provider',
      anesthesiaType: 'N/A',
      procedure: 'Diagnostic Nasal Endoscopy & CT Sinus Staging',
      paymentType: 'Commercial Insurance',
      notes: 'Severe caudal septal deflection documented with right turbinate hypertrophy.',
      status: 'Completed'
    }
  ],
  'caldwell': [
    {
      id: 'hist-cal-1',
      date: '06/18/2026',
      dayName: 'Thursday',
      startTime: '09:00 AM',
      length: '1.0 Hour',
      room: 'Exam Room 2',
      title: 'Caldwell, S - Pre-Op Clearance',
      surgeon: '',
      anesthesiologist: 'Anesthesia Provider',
      anesthesiaType: 'N/A',
      procedure: 'Endoscopic Browlift Sizing & Upper Lid Measurement',
      paymentType: 'Self-Pay',
      notes: 'Upper eyelid skin excess marked. Tear film normal.',
      status: 'Completed'
    }
  ],
  'bennett': [
    {
      id: 'hist-ben-1',
      date: '06/02/2026',
      dayName: 'Tuesday',
      startTime: '02:30 PM',
      length: '1.0 Hour',
      room: 'Consult Suite B',
      title: 'Bennett, C - Cartilage Assessment',
      surgeon: 'Provider',
      anesthesiologist: 'Anesthesia Provider',
      anesthesiaType: 'N/A',
      procedure: 'Septal Cartilage Assessment & 3D Structural Revision Plan',
      paymentType: 'Commercial Insurance',
      notes: 'Structural graft harvest options reviewed.',
      status: 'Completed'
    }
  ],
  'sterling-fox': [
    {
      id: 'hist-fox-1',
      date: '05/12/2026',
      dayName: 'Tuesday',
      startTime: '01:00 PM',
      length: '1.5 Hours',
      room: 'Exam Room 1',
      title: 'Sterling-Fox, A - Pre-Op Workup',
      surgeon: '',
      anesthesiologist: 'Anesthesia Provider',
      anesthesiaType: 'N/A',
      procedure: 'Comprehensive Deep Plane Facelift & Neck Lift Workup',
      paymentType: 'Self-Pay',
      notes: 'Full pre-op diagnostic workup complete.',
      status: 'Completed'
    }
  ],
  'martinez': [
    {
      id: 'hist-mar-1',
      date: '06/08/2026',
      dayName: 'Monday',
      startTime: '10:00 AM',
      length: '1.0 Hour',
      room: 'Exam Room 3',
      title: 'Martinez, P - Pre-Op Clearance',
      surgeon: 'Provider',
      anesthesiologist: 'Anesthesia Provider',
      anesthesiaType: 'N/A',
      procedure: 'Pre-Operative Medical Clearance & EKG Evaluation',
      paymentType: 'Self-Pay',
      notes: 'Cleared for morning blepharoplasty.',
      status: 'Completed'
    }
  ],
  'toney': [
    {
      id: 'hist-ton-1',
      date: '06/03/2026',
      dayName: 'Wednesday',
      startTime: '09:00 AM',
      length: '1.0 Hour',
      room: 'Exam Room 4',
      title: 'Toney, M - Ptosis Evaluation',
      surgeon: 'Provider',
      anesthesiologist: 'Anesthesia Provider',
      anesthesiaType: 'N/A',
      procedure: 'Levator Muscle Excursion & Ptosis Margin Measurements',
      paymentType: 'Self-Pay',
      notes: 'Levator function measured at 12mm bilaterally.',
      status: 'Completed'
    }
  ],
  'billauer': [
    {
      id: 'hist-bil-1',
      date: '06/01/2026',
      dayName: 'Monday',
      startTime: '11:00 AM',
      length: '1.0 Hour',
      room: 'Exam Room 2',
      title: 'Billauer, F - Cardiology Clearance',
      surgeon: '',
      anesthesiologist: 'Anesthesia Provider',
      anesthesiaType: 'N/A',
      procedure: 'Pre-Op Cardiology Workup & EKG Clearance',
      paymentType: 'Commercial Insurance',
      notes: 'Cardiologist clearance note received and attached to chart.',
      status: 'Completed'
    }
  ],
  'sprong': [
    {
      id: 'hist-spr-1',
      date: '06/25/2026',
      dayName: 'Thursday',
      startTime: '08:30 AM',
      length: '1.0 Hour',
      room: 'Consult Suite A',
      title: 'Sprong, J - Pre-Op Consultation',
      surgeon: 'Provider',
      anesthesiologist: 'Anesthesia Provider',
      anesthesiaType: 'N/A',
      procedure: 'Endoscopic Browlift Simulation & Upper Lid Workup',
      paymentType: 'Self-Pay',
      notes: 'Endoscopic vector analysis completed.',
      status: 'Completed'
    }
  ],
  'correll': [
    {
      id: 'hist-cor-1',
      date: '06/17/2026',
      dayName: 'Wednesday',
      startTime: '10:00 AM',
      length: '1.0 Hour',
      room: 'Exam Room 1',
      title: 'Correll, N - Pre-Op Ultrasound',
      surgeon: '',
      anesthesiologist: 'Anesthesia Provider',
      anesthesiaType: 'N/A',
      procedure: 'Capsular Ultrasound & Implant Exchange Workup',
      paymentType: 'Commercial Insurance',
      notes: 'Baker Grade III capsular contracture documented.',
      status: 'Completed'
    }
  ],
  'danek': [
    {
      id: 'hist-dan-1',
      date: '06/15/2026',
      dayName: 'Monday',
      startTime: '01:30 PM',
      length: '1.0 Hour',
      room: 'Exam Room 3',
      title: 'Danek, H - Ophthalmic Evaluation',
      surgeon: 'Provider',
      anesthesiologist: 'Anesthesia Provider',
      anesthesiaType: 'N/A',
      procedure: 'Lower Lid Fat Repositioning Assessment',
      paymentType: 'Self-Pay',
      notes: 'Snapback test normal. Vector marked.',
      status: 'Completed'
    }
  ]
};

/**
 * Retrieves all scheduled appointments and prior historical visits for a patient.
 */
export function getPatientAppointmentHistory(
  patient: MasterPatientRecord,
  currentScheduleAppointments: any[] = []
): PatientAppointmentHistoryRecord[] {
  const records: PatientAppointmentHistoryRecord[] = [];
  const pLastNameKey = patient.lastName.toLowerCase().trim();
  const pFullNameKey = patient.name.toLowerCase().trim();

  // 1. Gather all matching appointments from the current schedule matrix
  currentScheduleAppointments.forEach((apt) => {
    const aptPatientName = (apt.patientName || apt.title || '').toLowerCase();
    const isMatch = 
      aptPatientName.includes(pLastNameKey) ||
      (apt.caseId && apt.caseId === patient.id) ||
      (apt.id && apt.id === patient.patientId);

    if (isMatch) {
      records.push({
        id: apt.id || `apt-${Math.random()}`,
        patientId: patient.patientId,
        patientName: patient.name,
        dob: apt.dob || patient.dob,
        age: `${apt.age || patient.age}`,
        phone: apt.phone || patient.phone,
        date: apt.dos || (apt.dayIndex !== undefined ? ['07/13/2026', '07/14/2026', '07/15/2026', '07/16/2026', '07/17/2026', '07/18/2026', '07/19/2026'][apt.dayIndex] : '07/13/2026'),
        dayName: apt.dayIndex !== undefined ? ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'][apt.dayIndex] : 'Monday',
        startTime: apt.startTime || `${apt.startHour || 8}:00 AM`,
        length: apt.length || `${apt.durationHours || 2.0} Hours`,
        room: apt.room || patient.room || 'OR #1',
        title: apt.title || `${patient.lastName}, ${patient.firstName[0]}`,
        surgeon: apt.surgeon || patient.surgeon || '',
        anesthesiologist: apt.anesthesiologist || patient.anesthesiologist || 'Anesthesia Provider',
        anesthesiaType: apt.anesthesiaType || patient.anesthesiaType || 'General Anesthesia',
        procedure: apt.procedure || patient.procedure || 'Surgical Procedure',
        paymentType: apt.paymentType || patient.paymentType || 'Self-Pay',
        notes: apt.notes || patient.notes || 'Scheduled in active surgical matrix.',
        status: 'Scheduled',
        dayIndex: apt.dayIndex,
        caseId: apt.caseId || patient.id,
        bgColor: apt.bgColor,
        startHour: apt.startHour,
        durationHours: apt.durationHours
      });
    }
  });

  // 2. Gather pre-configured historical appointments
  const matchedHistList = HISTORICAL_APPOINTMENT_DATA[pLastNameKey] || 
    Object.entries(HISTORICAL_APPOINTMENT_DATA).find(([k]) => pFullNameKey.includes(k))?.[1];

  if (matchedHistList && matchedHistList.length > 0) {
    matchedHistList.forEach((h) => {
      records.push({
        ...h,
        patientId: patient.patientId,
        patientName: patient.name,
        dob: patient.dob,
        age: `${patient.age}`,
        phone: patient.phone
      });
    });
  } else {
    // Generate standard prior historical visits if not hardcoded
    records.push({
      id: `gen-hist-${patient.patientId}-1`,
      patientId: patient.patientId,
      patientName: patient.name,
      dob: patient.dob,
      age: `${patient.age}`,
      phone: patient.phone,
      date: '06/15/2026',
      dayName: 'Monday',
      startTime: '10:00 AM',
      length: '1.0 Hour',
      room: 'Exam Room 2',
      title: `${patient.lastName}, ${patient.firstName[0]} - Pre-Op Clearance`,
      surgeon: patient.surgeon || '',
      anesthesiologist: patient.anesthesiologist || 'Anesthesia Provider',
      anesthesiaType: 'N/A (Consultation)',
      procedure: `Pre-Operative Assessment & Clinical Clearance for ${patient.procedure || 'Procedure'}`,
      paymentType: patient.paymentType || 'Self-Pay',
      notes: `Pre-op diagnostic assessment completed. Vital signs within normal limits. Informed consent signed.`,
      status: 'Completed'
    });
    records.push({
      id: `gen-hist-${patient.patientId}-2`,
      patientId: patient.patientId,
      patientName: patient.name,
      dob: patient.dob,
      age: `${patient.age}`,
      phone: patient.phone,
      date: '05/11/2026',
      dayName: 'Monday',
      startTime: '02:00 PM',
      length: '45 Mins',
      room: 'Consult Suite A',
      title: `${patient.lastName}, ${patient.firstName[0]} - Initial Consultation`,
      surgeon: patient.surgeon || '',
      anesthesiologist: 'N/A',
      anesthesiaType: 'N/A',
      procedure: `Initial Aesthetic & Surgical Consultation`,
      paymentType: patient.paymentType || 'Self-Pay',
      notes: `Patient evaluated for surgical goals and candidacy. Treatment plan formulated.`,
      status: 'Prior Visit'
    });
  }

  // Sort: current schedule appointments first, then by descending date
  return records.sort((a, b) => {
    if (a.status === 'Scheduled' && b.status !== 'Scheduled') return -1;
    if (a.status !== 'Scheduled' && b.status === 'Scheduled') return 1;
    return new Date(b.date).getTime() - new Date(a.date).getTime();
  });
}


