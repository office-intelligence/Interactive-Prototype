import { normalizeUsDate } from './v6/dates';
import React, { useState } from 'react';
import { Header } from './components/Header';
import { NightingaleBriefBanner } from './components/NightingaleBriefBanner';
import { VitylsStation } from './components/VitylsNextWorkspace';
import { FormsBasedClinicalWorkspace } from './components/FormsBasedClinicalWorkspace';

import { ScheduleIntelligenceBox } from './components/ScheduleIntelligenceBox';
import { ScheduleFullView } from './components/ScheduleFullView';
import { BlankPageTemplate } from './components/BlankPageTemplate';
import { PatientChartPage } from './components/PatientChartPage';
import { StationWorkspace } from './v6/StationWorkspace';
import { WorkflowKey } from './data/formWorkspaceCatalog';
import { PremierePatientChartPage } from './components/PremierePatientChartPage';
import { ensureLocalPractice, clearPracticeForms } from './utils/localFormStudioDb';
import { AdministrationPage, AdminActiveSection } from './components/AdministrationPage';
import { BillingModulePage } from './components/BillingModulePage';
import { PracticeWorkspace, PracticeSubModule } from './components/PracticeWorkspace';
import { FormsWorkspacePage } from './components/FormsWorkspacePage';
import { TasksWidget } from './components/TasksWidget';
import { DashboardMessagesPanel } from './components/DashboardMessagesPanel';
import { CommunicationWidget } from './components/CommunicationWidget';
import { PatientDetailModal } from './components/PatientDetailModal';
import { AddPatientModal } from './components/AddPatientModal';
import { NightingaleAIChatDrawer } from './components/NightingaleAIChatDrawer';
import { AIWorkflowExamples } from './components/AIWorkflowExamples';
import { AIHomePage } from './components/AIHomePage';
import { MessagesPage } from './components/MessagesPage';
import { PublicLandingPage } from './components/PublicLandingPage';
import { LoginPage } from './components/LoginPage';
import { RegistrationPage } from './components/RegistrationPage';
import { PatientPortalPage } from './components/PatientPortalPage';
import { CeoAdminDashboard } from './components/CeoAdminDashboard';
import { getUnreadCount, subscribeToMessageUpdates } from './utils/portalMessageStore';
import { 
  initialPatientCases, 
  initialTasks, 
  initialStats, 
  initialBottleneckAlerts 
} from './data/mockData';
import { getCasesForDateKey } from './utils/dateCases';
import { PatientCase, PatientStage, TaskItem, AuthUser, PracticeConfig, EncounterJourneyStatus } from './types';
import { ScheduleViewMode } from './components/ScheduleIntelligenceBox';
import { 
  CheckCircle2, 
  AlertTriangle, 
  Sparkles, 
  Plus, 
  Calendar, 
  FileText, 
  CreditCard, 
  Settings, 
  Zap, 
  ChevronLeft, 
  ChevronRight, 
  Building2,
  Layers,
  Sliders,
  LogOut,
  Globe,
  Home,
  MessageSquare,
  MapPin,
  ChevronDown,
  Check
} from 'lucide-react';

const TODAY_DATE = new Date();



const PREMIERE_PRACTICE_ID = 'default-practice';
const PREMIERE_PRACTICE: PracticeConfig = {
  id: PREMIERE_PRACTICE_ID,
  practiceName: 'New Practice',
  locationName: 'Primary Location',
  isPrimary: true,
  isSatellite: false,
  practiceType: 'ASC',
  specialty: 'Unconfigured',
  streetAddress: '',
  city: '',
  state: 'CA',
  zipCode: '',
  country: 'United States',
  telephone: '',
  email: '',
  website: '',
  primaryProvider: { firstName: '', lastName: '', degree: 'MD', cellPhone: '', email: '', npi: '' },
  calendarSettings: {
    startTime: '07:00 AM',
    endTime: '05:00 PM',
    visitTypes: [],
    rooms: [
      { id: 'room-or-1', name: 'OR #1', color: '#64748b', type: 'OR', active: true, sortOrder: 1 },
      { id: 'room-or-2', name: 'OR #2', color: '#64748b', type: 'OR', active: true, sortOrder: 2 },
      { id: 'room-gi-1', name: 'GI Suite #1', color: '#64748b', type: 'Procedure', active: true, sortOrder: 3 },
      { id: 'room-laser-1', name: 'LASER Room', color: '#64748b', type: 'Procedure', active: true, sortOrder: 4 },
    ],
  },
};

export const INITIAL_PRACTICES: PracticeConfig[] = [PREMIERE_PRACTICE];

export default function App() {
  // Authentication & Public Pages View State: 'app' | 'landing' | 'login' | 'register' | 'portal' | 'ceo' (Defaults to front landing page)
  // 'ceo' is the Master CEO business-administration console — architecturally separate from
  // the clinical app shell and PHI, per Developer Requirements' business-admin isolation model.
  const [authView, setAuthView] = useState<'app' | 'landing' | 'login' | 'register' | 'portal' | 'ceo'>('app');
  
  // Current authenticated user placeholder until backend authentication is connected
  const [currentUser, setCurrentUser] = useState<AuthUser | null>({
    id: 'pending-auth-user',
    firstName: 'Practice',
    lastName: 'Administrator',
    email: '',
    role: 'PRACTICE_ADMIN',
    telephone: '',
    title: 'Practice Administrator',
    practiceName: 'New Practice'
  });

  // Multiple Practices & Locations State
  const [practicesList, setPracticesList] = useState<PracticeConfig[]>(INITIAL_PRACTICES);
  const [selectedPracticeId, setSelectedPracticeId] = useState<string>(PREMIERE_PRACTICE_ID);
  const [isPracticeDropdownOpen, setIsPracticeDropdownOpen] = useState<boolean>(false);

  // Global Active Practice Configuration
  const [practiceConfig, setPracticeConfig] = useState<PracticeConfig>(PREMIERE_PRACTICE);

  const handleSelectPractice = (practiceId: string) => {
    const target = practicesList.find(p => p.id === practiceId);
    if (target) {
      setSelectedPracticeId(practiceId);
      setPracticeConfig(target);
      if (currentUser) {
        setCurrentUser(prev => prev ? {
          ...prev,
          practiceName: target.practiceName
        } : null);
      }
      showToast(`Switched view to practice: ${target.practiceName} (${target.locationName || target.city})`);
    }
  };

  const handleAddPractice = (newPractice: PracticeConfig) => {
    setPracticesList(prev => [...prev, newPractice]);
    setSelectedPracticeId(newPractice.id || `loc-${Date.now()}`);
    setPracticeConfig(newPractice);
    showToast(`Added and switched to ${newPractice.practiceName}!`);
  };

  const handleOpenLocalPracticeDashboard = (localPractice: { id: string; name: string; createdAt: string }) => {
    const existing = practicesList.find(p => p.id === localPractice.id);
    const config: PracticeConfig = existing || {
      id: localPractice.id,
      practiceName: localPractice.name,
      locationName: 'Primary Location',
      isPrimary: false,
      isSatellite: false,
      practiceType: 'ASC',
      specialty: 'Unconfigured',
      streetAddress: '',
      city: '',
      state: 'CA',
      zipCode: '',
      country: 'United States',
      telephone: '',
      email: '',
      website: '',
      primaryProvider: { firstName: '', lastName: '', degree: 'MD', cellPhone: '', email: '', npi: '' },
      calendarSettings: {
        startTime: '07:00 AM',
        endTime: '05:00 PM',
        visitTypes: [],
        rooms: [],
      },
    };
    if (!existing) setPracticesList(prev => [...prev, config]);
    setSelectedPracticeId(config.id || localPractice.id);
    setPracticeConfig(config);
    setDateCasesMap(prev => ({ ...prev, [activeDateKey]: [] }));
    setActiveTab('home');
    setPracticeSubModule('admin');
    showToast(`Opened ${localPractice.name} dashboard.`);
  };

  const handleUpdatePracticeConfig = (updated: PracticeConfig) => {
    setPracticeConfig(updated);
    setPracticesList(prev => prev.map(p => (p.id === updated.id ? updated : p)));
    showToast('Practice configuration updated across Office Intelligence.');
  };

  const [activeTab, setActiveTab] = useState<string>('home');
  const [vitylsStation, setVitylsStation] = useState<VitylsStation>('nursing');
  const [practiceSubModule, setPracticeSubModule] = useState<PracticeSubModule>('admin');
  /** v7.4: bumps on every explicit Practice / admin-section navigation so PracticeWorkspace leaves Billing/Ops pages. */
  const [practiceNavKey, setPracticeNavKey] = useState(0);
  const [adminActiveSection, setAdminActiveSection] = useState<AdminActiveSection>('home');
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState<boolean>(false);

  const handleNavigateWorkspace = (workspace: string, subModule?: string, param?: string) => {
    if (workspace === 'billing') {
      setActiveTab('practice');
      setPracticeSubModule('billing');
    } else if (workspace === 'messages') {
      setActiveTab('messages');
    } else if (workspace === 'admin') {
      setActiveTab('practice');
      setPracticeSubModule('admin');
      if (!subModule) setAdminActiveSection('home');
    } else if (workspace === 'form-studio' || workspace === 'forms') {
      setActiveTab('form-studio');
    } else if (workspace === 'ai-home' || workspace === 'workflows') {
      setActiveTab('practice');
      setPracticeSubModule('workflows');
    } else {
      setActiveTab(workspace);
      if (subModule) {
        setPracticeSubModule(subModule as PracticeSubModule);
      }
    }

    if (param && (workspace === 'patients' || workspace === 'chart')) {
      setSelectedChartPatientId(param);
    }
  };

  // Date navigation & view mode state
  const [selectedDate, setSelectedDate] = useState<Date>(() => { const raw=localStorage.getItem('vityls:evaluation:selected-date'); return raw ? new Date(raw+'T12:00:00') : TODAY_DATE; });
  const [dateCasesMap, setDateCasesMap] = useState<Record<string, PatientCase[]>>(() => { try { return JSON.parse(localStorage.getItem('vityls:evaluation:date-cases') || '{}'); } catch { return {}; } });
  const [scheduleViewMode, setScheduleViewMode] = useState<ScheduleViewMode>('PRIORITY');

  React.useEffect(() => { localStorage.setItem('vityls:evaluation:date-cases', JSON.stringify(dateCasesMap)); }, [dateCasesMap]);
  React.useEffect(() => { const y=selectedDate.getFullYear(),m=String(selectedDate.getMonth()+1).padStart(2,'0'),d=String(selectedDate.getDate()).padStart(2,'0'); localStorage.setItem('vityls:evaluation:selected-date', `${y}-${m}-${d}`); }, [selectedDate]);

  const [tasks, setTasks] = useState<TaskItem[]>(initialTasks);
  const [stats, setStats] = useState(initialStats);
  const [searchQuery, setSearchQuery] = useState('');
  
  const [selectedPatient, setSelectedPatient] = useState<PatientCase | null>(null);
  const [selectedChartPatientId, setSelectedChartPatientId] = useState<string>('');
  const [patientWorkspaceStation, setPatientWorkspaceStation] = useState<WorkflowKey | 'caseRecord' | null>(null);
  const [selectedChartSection, setSelectedChartSection] = useState<string | undefined>(undefined);
  const [isAddPatientModalOpen, setIsAddPatientModalOpen] = useState(false);
  const [isAIChatOpen, setIsAIChatOpen] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [unreadPortalMessages, setUnreadPortalMessages] = useState<number>(() => getUnreadCount());

  React.useEffect(() => {
    ensureLocalPractice(PREMIERE_PRACTICE_ID, PREMIERE_PRACTICE.practiceName).catch(() => {});
  }, []);

  React.useEffect(() => {
    const cleanupKey = 'oi-premiere-official-html-library-v27-clean';
    if (localStorage.getItem(cleanupKey) === 'done') return;
    clearPracticeForms(PREMIERE_PRACTICE_ID)
      .then(() => localStorage.setItem(cleanupKey, 'done'))
      .catch(() => {});
  }, []);

  // Pre-database cleanup: remove legacy/default workflow assignments once so
  // only explicit selections made in the new Form Studio drive patient/staff workflows.
  React.useEffect(() => {
    const cleanupKey = 'vityls-explicit-form-workflow-v3-clean';
    if (localStorage.getItem(cleanupKey) === 'done') return;
    const keys = Object.keys(localStorage);
    keys.filter(k => k.startsWith('vityls-form-workflow:')).forEach(k => localStorage.removeItem(k));
    localStorage.removeItem('vityls-form-assignments-v2');
    localStorage.setItem(cleanupKey, 'done');
  }, []);

  React.useEffect(() => {
    const updateCount = () => {
      setUnreadPortalMessages(getUnreadCount());
    };
    updateCount();
    const unsubscribe = subscribeToMessageUpdates(updateCount);
    return () => unsubscribe();
  }, []);

  const formatDateKey = (d: Date) => {
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  };

  const formatDisplayDate = (d: Date) => {
    return d.toLocaleDateString('en-US', {
      weekday: 'long',
      month: 'long',
      day: 'numeric',
      year: 'numeric',
    });
  };

  const activeDateKey = formatDateKey(selectedDate);
  const isPremierePractice = selectedPracticeId === PREMIERE_PRACTICE_ID;
  const activeDateCases = dateCasesMap[activeDateKey] || [];
  // Evaluation-mode patient registry: keep every patient/case available across page and date navigation.
  const allCases = React.useMemo(() => {
    const seen = new Map<string, PatientCase>();
    Object.values(dateCasesMap).flat().forEach(c => seen.set(c.id, c));
    return Array.from(seen.values());
  }, [dateCasesMap]);

  const isToday =
    selectedDate.getFullYear() === TODAY_DATE.getFullYear() &&
    selectedDate.getMonth() === TODAY_DATE.getMonth() &&
    selectedDate.getDate() === TODAY_DATE.getDate();

  const handlePrevDay = () => {
    setSelectedDate((prev) => {
      const d = new Date(prev);
      d.setDate(d.getDate() - 1);
      showToast(`Schedule view: ${formatDisplayDate(d)}`);
      return d;
    });
  };

  const handleNextDay = () => {
    setSelectedDate((prev) => {
      const d = new Date(prev);
      d.setDate(d.getDate() + 1);
      showToast(`Schedule view: ${formatDisplayDate(d)}`);
      return d;
    });
  };

  const handleToday = () => {
    const d = new Date(TODAY_DATE);
    setSelectedDate(d);
    showToast(`Schedule view reset to Today (${formatDisplayDate(d)})`);
  };

  const handleScheduleAppointmentSaved = (apt: any) => {
    apt = { ...apt, dos: normalizeUsDate(apt.dos) }; // v6: 2-digit years were filed under 1926
    const parts = String(apt.dos || '').split('/');
    const targetKey = parts.length === 3 ? `${parts[2]}-${String(parts[0]).padStart(2,'0')}-${String(parts[1]).padStart(2,'0')}` : activeDateKey;
    if (parts.length === 3) { const d = new Date(Number(parts[2]), Number(parts[0])-1, Number(parts[1])); if (!Number.isNaN(d.getTime())) setSelectedDate(d); }
    setDateCasesMap(prev => {
      let source: PatientCase | undefined;
      Object.values(prev).some(list => { source = list.find(c => c.id === apt.caseId || c.name.toLowerCase() === String(apt.patientName||'').toLowerCase()); return !!source; });
      if (!source) {
        const created: PatientCase = {
          id: apt.caseId || `case-${Date.now()}`, patientId: apt.patientId || `MRN-${Date.now()}`,
          name: apt.patientName || 'New Patient', age: 0, gender: 'Other', dob: apt.dob || '', phone: apt.phone || '',
          scheduledTime: apt.startTime, appointmentDate: apt.dos, estimatedDurationMins: Math.round((apt.durationHours || 1.5)*60),
          room: apt.room || 'Unassigned', surgeon: apt.surgeon || 'Unassigned', anesthesiologist: apt.anesthesiologist || undefined,
          procedure: apt.procedure || 'Procedure Not Yet Scheduled', paymentType: apt.paymentType, aiSummary: `${apt.patientName || 'Patient'} is scheduled for ${apt.procedure || 'procedure'} on ${apt.dos} at ${apt.startTime}.`,
          readinessScore: 0, readinessLevel: 'IN_PROGRESS', allergies: [], labs: [], stage: 'CHECK_IN', arrivalStatus: 'EN_ROUTE', arrivalTime: '', bottlenecks: ['At-Home Intake not yet completed'], actionItems: [], checkInStatus: 'NOT_STARTED'
        } as PatientCase;
        return { ...prev, [targetKey]: [...(prev[targetKey] || []), created] };
      }
      const updated: PatientCase = { ...source, appointmentDate: apt.dos, scheduledTime: apt.startTime, estimatedDurationMins: Math.round((apt.durationHours || 1.5)*60), room: apt.room, surgeon: apt.surgeon || 'Unassigned', anesthesiologist: apt.anesthesiologist || undefined, procedure: apt.procedure || 'Procedure Not Yet Scheduled', paymentType: apt.paymentType || source.paymentType, aiSummary: `${source.name} is scheduled for ${apt.procedure || 'procedure'} on ${apt.dos} at ${apt.startTime} in ${apt.room}.`, readinessLevel: 'IN_PROGRESS' };
      const next:any = {};
      for (const [k,list] of Object.entries(prev)) next[k] = list.filter(c => c.id !== source!.id);
      next[targetKey] = [...(next[targetKey] || []), updated];
      return next;
    });
  };

  const updateActiveCases = (updater: (prev: PatientCase[]) => PatientCase[]) => {
    setDateCasesMap((prevMap) => {
      const current = prevMap[activeDateKey] || [];
      return {
        ...prevMap,
        [activeDateKey]: updater(current),
      };
    });
  };

  // v6: update a case whichever schedule date it is filed under.
  const updateCaseEverywhere = (updater: (prev: PatientCase[]) => PatientCase[]) => {
    setDateCasesMap((prevMap) => {
      const next: Record<string, PatientCase[]> = {};
      (Object.entries(prevMap) as [string, PatientCase[]][]).forEach(([k, list]) => { next[k] = updater(list); });
      return next;
    });
  };

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 4000);
  };

  const handleOpenPatientChart = (patient: PatientCase, sectionKey?: string) => {
    setSelectedChartPatientId(patient.id);
    setPatientWorkspaceStation(null);
    setSelectedChartSection(sectionKey);
    setActiveTab('patients');
    showToast(`Opening Patient Chart for ${patient.name}...`);
  };

  const handleOpenPatientChartById = (patientId: string, sectionKey?: string) => {
    const found = allCases.find((c) => c.id === patientId || c.patientId === patientId);
    setSelectedChartPatientId(found ? found.id : patientId);
    setSelectedChartSection(sectionKey || 'portalMessages');
    setActiveTab('patients');
    showToast(`Opening Patient Chart for ${found ? found.name : patientId}...`);
  };

  // EKG resolution fast-track
  const handleTriggerEKGFastTrack = (caseId: string) => {
    updateActiveCases((prev) =>
      prev.map((c) => {
        if (c.id === caseId) {
          const updatedLabs = c.labs.map((l) =>
            l.name === 'EKG' ? { name: 'EKG', value: 'Fax Received - Normal Sinus', status: 'normal' as const } : l
          );
          return {
            ...c,
            readinessScore: 98,
            readinessLevel: 'CLEARED' as const,
            aiSummary: 'EKG report received from Beverly Hills Cardiology via fast-track fax. Pre-op photo review cleared. Patient fully ready for OR 1.',
            labs: updatedLabs,
            bottlenecks: [],
            actionItems: c.actionItems.map((a) => ({ ...a, done: true })),
          };
        }
        return c;
      })
    );

    setTasks((prev) =>
      prev.map((t) => (t.id === 'task-4' ? { ...t, completed: true } : t))
    );

    showToast('Document status updated.');
  };

  // Update patient stage (Check-In -> Pre-Op -> In OR -> PACU -> Discharged)
  const handleUpdateStage = (caseId: string, newStage: PatientStage) => {
    updateActiveCases((prev) =>
      prev.map((c) => {
        if (c.id === caseId) {
          return { ...c, stage: newStage };
        }
        return c;
      })
    );
    showToast(`Updated patient flow stage to ${newStage.replace('_', ' ')}.`);
  };

  // Front-desk arrival gate: completing check-in is an explicit clinical handoff.
  // The patient record (including allergies + medications) is carried forward;
  // Nursing verifies/updates rather than re-entering it.
  const handleCompleteOfficeCheckIn = (caseId: string, exceptionReason?: string, unresolvedItems?: string[]) => {
    const now = new Date().toISOString();
    updateActiveCases((prev) =>
      prev.map((c) =>
        c.id === caseId
          ? {
              ...c,
              checkInStatus: 'OFFICE_VERIFIED' as const,
              checkInCompletedAt: now,
              stage: 'PRE_OP' as const,
              arrivalStatus: 'CHECKED_IN' as const,
              encounterWorkflow: {
                ...(c.encounterWorkflow || { status: 'ARRIVED' as const, currentOwner: 'Front Desk' as const }),
                status: 'READY_FOR_PREOP' as const,
                currentOwner: 'Nursing' as const,
                arrivedAt: c.encounterWorkflow?.arrivedAt || now,
                frontDeskCompletedAt: now,
                nursingNotifiedAt: now,
                lastHandoffNote: exceptionReason
                  ? `Front desk advanced patient with open items: ${exceptionReason}. Allergies and medications carried forward for Nursing review.`
                  : `Front desk completed arrival verification. Allergies and medications carried forward for Nursing review; verify/update only if changed.`,
                exceptions: exceptionReason ? [
                  ...(c.encounterWorkflow?.exceptions || []),
                  {
                    id: `exception-${Date.now()}`,
                    fromGate: (c.encounterWorkflow?.status || 'CHECKING_IN') as EncounterJourneyStatus,
                    toGate: 'READY_FOR_PREOP' as EncounterJourneyStatus,
                    reason: exceptionReason,
                    unresolvedItems: unresolvedItems || [],
                    advancedBy: 'Front Desk Staff',
                    advancedAt: now,
                  },
                ] : (c.encounterWorkflow?.exceptions || []),
              },
            }
          : c
      )
    );
    setSelectedChartPatientId(caseId);
    setSelectedChartSection(undefined);
    setPatientWorkspaceStation('nursing');
    setActiveTab('patients');
    showToast(exceptionReason ? '⚠ Patient advanced to Nursing with documented open items.' : '✓ Check-in complete — opening the V3 Pre-Op Nursing clinical review.');
  };

  const handleAcceptPatientForNursing = (caseId: string) => {
    const now = new Date().toISOString();
    updateActiveCases((prev) =>
      prev.map((c) => {
        if (c.id !== caseId) return c;
        return {
          ...c,
          stage: 'PRE_OP' as const,
          encounterWorkflow: {
            ...(c.encounterWorkflow || { status: 'READY_FOR_PREOP' as const, currentOwner: 'Nursing' as const }),
            status: 'PREOP_NURSING' as const,
            currentOwner: 'Nursing' as const,
            nursingAcceptedAt: now,
            nursingAcceptedBy: 'Assigned RN',
            lastHandoffNote: `Nursing accepted patient. Existing allergies and medications remain active and must be confirmed or updated only if the patient reports a change.`,
          },
        };
      })
    );
    // Do not depend on the React state updater executing synchronously.
    // The prior implementation stored `accepted` inside the updater, so the
    // navigation branch could run before `accepted` had ever been assigned.
    setSelectedChartPatientId(caseId);
    setSelectedChartSection(undefined);
    setPatientWorkspaceStation('nursing');
    setActiveTab('patients');
    showToast('Nursing accepted patient — opening Pre-op Nursing.');
  };

  const handleAdvanceEncounterGate = (
    caseId: string,
    toStatus: EncounterJourneyStatus,
    reason?: string,
    unresolvedItems: string[] = []
  ) => {
    const now = new Date().toISOString();
    const ownerByStatus: Partial<Record<EncounterJourneyStatus, NonNullable<PatientCase['encounterWorkflow']>['currentOwner']>> = {
      READY_FOR_PREOP: 'Nursing', PREOP_NURSING: 'Nursing', READY_FOR_ANESTHESIA: 'Anesthesia',
      ANESTHESIA_EVALUATION: 'Anesthesia', READY_FOR_OR: 'Surgeon/OR Team', IN_OR: 'Surgeon/OR Team',
      PACU: 'PACU', READY_FOR_DISCHARGE: 'PACU', DISCHARGED: 'Administrator', RECORD_COMPLETION: 'Administrator', CASE_COMPLETE: 'Administrator'
    };
    const stageByStatus: Partial<Record<EncounterJourneyStatus, PatientStage>> = {
      READY_FOR_PREOP: 'PRE_OP', PREOP_NURSING: 'PRE_OP', READY_FOR_ANESTHESIA: 'PRE_OP', ANESTHESIA_EVALUATION: 'PRE_OP',
      READY_FOR_OR: 'PRE_OP', IN_OR: 'IN_OR', PACU: 'PACU_RECOVERY', READY_FOR_DISCHARGE: 'PACU_RECOVERY', DISCHARGED: 'DISCHARGED',
      RECORD_COMPLETION: 'DISCHARGED', CASE_COMPLETE: 'DISCHARGED'
    };
    updateCaseEverywhere(prev => prev.map(c => {
      if (c.id !== caseId) return c;
      const fromStatus = c.encounterWorkflow?.status || 'ARRIVED';
      return {
        ...c,
        stage: stageByStatus[toStatus] || c.stage,
        encounterWorkflow: {
          ...(c.encounterWorkflow || { status: fromStatus, currentOwner: 'Front Desk' }),
          status: toStatus,
          currentOwner: ownerByStatus[toStatus] || c.encounterWorkflow?.currentOwner || 'Administrator',
          lastHandoffNote: reason
            ? `Advanced from ${fromStatus.replaceAll('_',' ')} with open items: ${reason}`
            : `Advanced from ${fromStatus.replaceAll('_',' ')} to ${toStatus.replaceAll('_',' ')}.`,
          exceptions: reason ? [
            ...(c.encounterWorkflow?.exceptions || []),
            { id: `exception-${Date.now()}`, fromGate: fromStatus, toGate: toStatus, reason, unresolvedItems, advancedBy: 'Current Staff User', advancedAt: now }
          ] : (c.encounterWorkflow?.exceptions || []),
        }
      };
    }));
    showToast(reason ? `⚠ Advanced to ${toStatus.replaceAll('_',' ')} with documented exception.` : `✓ Advanced to ${toStatus.replaceAll('_',' ')}.`);
  };

  // Action checklist toggle
  const handleResolveAction = (caseId: string, actionId: string) => {
    updateActiveCases((prev) =>
      prev.map((c) => {
        if (c.id === caseId) {
          const updatedItems = c.actionItems.map((a) =>
            a.id === actionId ? { ...a, done: !a.done } : a
          );
          return { ...c, actionItems: updatedItems };
        }
        return c;
      })
    );
  };

  // Toggle Task Completion
  const handleToggleTask = (taskId: string) => {
    setTasks((prev) =>
      prev.map((t) => (t.id === taskId ? { ...t, completed: !t.completed } : t))
    );
  };

  // Search filtered cases
  const displayedCases = activeDateCases.filter((c) => {
    if (!searchQuery) return true;
    const q = searchQuery.toLowerCase();
    return (
      c.name.toLowerCase().includes(q) ||
      c.patientId.includes(q) ||
      c.procedure.toLowerCase().includes(q) ||
      c.surgeon.toLowerCase().includes(q)
    );
  });

  const needsAttentionCount = activeDateCases.filter(
    (c) => c.readinessLevel === 'NEEDS_ATTENTION' || c.readinessLevel === 'CRITICAL_HOLD'
  ).length;

  // Handle User Registration
  const handleRegisterSuccess = (newUser: {
    firstName: string;
    lastName: string;
    email: string;
    telephone: string;
    practiceType?: PracticeConfig['practiceType'];
    specialty?: string;
    agreementAcceptances?: { agreementId: string }[];
  }) => {
    const authRecord: AuthUser = {
      id: `user-${Date.now()}`,
      firstName: newUser.firstName,
      lastName: newUser.lastName,
      email: newUser.email,
      role: 'PRACTICE_ADMIN',
      telephone: newUser.telephone,
      title: 'Attending Physician / Practice Owner',
      practiceName: `${newUser.lastName} Surgical Practice`
    };

    setCurrentUser(authRecord);

    // Update Practice Config Primary Provider with new registrant info,
    // seeded from the registration wizard's practice-type + specialty step
    setPracticeConfig((prev) => ({
      ...prev,
      practiceName: `${newUser.lastName} Surgical Practice & Institute`,
      practiceType: newUser.practiceType || prev.practiceType,
      specialty: newUser.specialty || prev.specialty,
      primaryProvider: {
        ...prev.primaryProvider,
        firstName: newUser.firstName,
        lastName: newUser.lastName,
        email: newUser.email,
        cellPhone: newUser.telephone
      }
    }));

    // Redirect user directly to Configure Practice in Administration
    setAuthView('app');
    setActiveTab('admin');
    setAdminActiveSection('configure-practice');

    const acceptedCount = newUser.agreementAcceptances?.length || 0;
    showToast(`✓ Welcome Dr. ${newUser.lastName}! Account created${acceptedCount ? ` — ${acceptedCount} legal agreements signed and recorded` : ''}. Please complete your Practice Configuration.`);
  };

  // Handle Login Success — a CEO/business-admin demo login (identifier containing "ceo")
  // routes to the isolated Master CEO console instead of the clinical app shell.
  // LoginPage only hands back a loose {email, name, role} shape, so build a full
  // AuthUser record from it here (splitting the display name into first/last).
  const handleLoginSuccess = (loginResult: { email: string; name: string; role: string }) => {
    const nameParts = loginResult.name.trim().split(' ');
    const firstName = nameParts[0] || loginResult.name;
    const lastName = nameParts.slice(1).join(' ') || '';
    const isCeo = loginResult.role.toUpperCase().includes('CEO');

    const authRecord: AuthUser = {
      id: `user-${Date.now()}`,
      firstName,
      lastName,
      email: loginResult.email,
      role: isCeo ? 'CEO' : 'PRACTICE_ADMIN',
      title: loginResult.role,
      practiceName: currentUser?.practiceName || practiceConfig.practiceName
    };

    setCurrentUser(authRecord);

    if (isCeo) {
      setAuthView('ceo');
      showToast(`Welcome, ${firstName} ${lastName} — Business Console.`);
    } else {
      setAuthView('app');
      showToast(`Welcome back, ${firstName} ${lastName}!`);
    }
  };

  // Handle Logout
  const handleLogout = () => {
    setCurrentUser(null);
    setAuthView('landing');
    showToast('Logged out securely. HIPAA session terminated.');
  };

  // Handle Navigation to specific Administration section
  const handleNavigateAdminSection = (section: AdminActiveSection) => {
    setActiveTab('admin');
    setPracticeSubModule('admin');
    setAdminActiveSection(section);
    setPracticeNavKey(k => k + 1);
  };

  // ========================================================
  // ROUTING VIEW: 1. PUBLIC LANDING PAGE
  // ========================================================
  if (authView === 'landing') {
    return (
      <PublicLandingPage
        onNavigateLogin={() => setAuthView('login')}
        onNavigateRegister={() => setAuthView('register')}
        onNavigatePortal={() => setAuthView('portal')}
        onEnterApp={() => {
          setIsSidebarCollapsed(false);
          setAuthView('app');
          showToast('Entered Office Intelligence Live Interactive Demo with full navigation.');
        }}
      />
    );
  }

  // ========================================================
  // ROUTING VIEW: 2. LOGIN PAGE
  // ========================================================
  if (authView === 'login') {
    return (
      <LoginPage
        onLoginSuccess={handleLoginSuccess}
        onNavigateRegister={() => setAuthView('register')}
        onNavigateLanding={() => setAuthView('landing')}
        activePracticeId={selectedPracticeId}
        initialPatientId={undefined}
      />
    );
  }

  // ========================================================
  // ROUTING VIEW: 3. REGISTRATION PAGE
  // ========================================================
  if (authView === 'register') {
    return (
      <RegistrationPage
        onRegisterSuccess={handleRegisterSuccess}
        onNavigateLogin={() => setAuthView('login')}
        onNavigateLanding={() => setAuthView('landing')}
      />
    );
  }

  // ========================================================
  // ROUTING VIEW: 4. PATIENT PORTAL PAGE
  // ========================================================
  if (authView === 'portal') {
    return (
      <PatientPortalPage
        onBackToOIApp={() => {
          setAuthView('app');
          showToast('Switched back to Office Intelligence Practice Management OS.');
        }}
        onNavigateLanding={() => setAuthView('landing')}
        patients={(Object.values(dateCasesMap) as PatientCase[][]).flat()}
      />
    );
  }

  // ========================================================
  // ROUTING VIEW: 5. MASTER CEO / BUSINESS ADMINISTRATION CONSOLE
  // Deliberately rendered standalone here (not inside the clinical app shell
  // below) — it has no access to PatientCase/PHI state at all, only business
  // metrics, per the platform's business-admin isolation requirement.
  // ========================================================
  if (authView === 'ceo') {
    return (
      <CeoAdminDashboard
        currentUser={currentUser}
        onLogout={handleLogout}
      />
    );
  }

  // ========================================================
  // ROUTING VIEW: 6. MAIN OFFICE INTELLIGENCE OPERATING APP
  // ========================================================
  return (
    <div className="min-h-screen bg-[#F1F3EC] text-[#1A2E22] font-sans antialiased flex flex-col overflow-x-hidden selection:bg-[#DCEEE3] selection:text-[#1B4332]">
      
      {/* Toast Notification Banner */}
      {toastMessage && (
        <div className="fixed top-4 right-4 z-50 bg-[#1A2E22] text-white text-xs font-semibold px-4 py-3 rounded-xl shadow-2xl border border-[#5B6B60] flex items-center gap-2.5 animate-in slide-in-from-top duration-300 max-w-md">
          <Sparkles className="w-4 h-4 text-[#DCEEE3] shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Top Header Navigation Bar */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onRefresh={() => showToast('Refreshed real-time surgical schedule & OR status.')}
        onAppointmentBooks={() => {
          setActiveTab('schedule');
          showToast('Switched to Schedule Appointment Books view.');
        }}
        onPrint={() => {
          showToast('Opening print dialog for surgical schedule...');
          window.print();
        }}
        onAddPatient={() => {
          setIsAddPatientModalOpen(true);
        }}
        onOpenAIChat={() => setIsAIChatOpen(true)}
        searchQuery={searchQuery}
        setSearchQuery={setSearchQuery}
        needsAttentionCount={needsAttentionCount}
        currentUser={currentUser}
        onLogout={handleLogout}
        onNavigateLanding={() => setAuthView('landing')}
        onNavigatePortal={() => setAuthView('portal')}
        onNavigateAdminSection={handleNavigateAdminSection}
        practiceConfig={practiceConfig}
      />

      {/* Main Workspace (Full Width to Maximize Screen Real Estate) */}
      <div className="flex-1 flex flex-col min-w-0 pb-24">
        {/* Dashboard Body Content */}
        <main className={`w-full mx-auto transition-all ${
          activeTab === 'schedule' || activeTab === 'form-studio'
            ? 'px-1 sm:px-2 py-2 max-w-[99.5vw]' 
            : 'px-3 sm:px-6 lg:px-8 py-4 sm:py-6 space-y-4 sm:space-y-6 max-w-[1700px]'
        }`}>
          
          {/* VITYLS NEXT: production-oriented clinical workspace */}
          {activeTab === 'vityls-next' && <FormsBasedClinicalWorkspace patient={activeDateCases.find(c => c.id === selectedChartPatientId || c.patientId === selectedChartPatientId) || activeDateCases[0]} initialStation={vitylsStation} onClose={() => setActiveTab('home')} />}

          {/* TAB 1: HOME DASHBOARD */}
          {activeTab === 'home' && (
            <>
              {/* Top Date Navigation Bar on Home Page */}
              <div className="bg-white rounded-xl border border-[#E1E4DC] p-3 sm:p-4 shadow-2xs flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center gap-2.5 sm:gap-3.5 flex-wrap">
                  <div className="flex items-center gap-2 pr-2 sm:pr-4 sm:border-r border-[#E1E4DC]">
                    <Building2 className="w-4 h-4 text-[#1F6E52]"/>
                    <div><div className="text-xs font-bold text-[#1A2E22]">{practiceConfig.practiceName}</div><div className="text-[10px] text-[#5B6B60]">{practiceConfig.locationName || 'Primary Location'} · {practiceConfig.practiceType}</div></div>
                  </div>
                  {/* Previous, TODAY, Next Buttons */}
                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={handlePrevDay}
                      className="p-1.5 border border-[#C9CFC6] rounded-lg bg-white hover:bg-[#F1F3EC] text-[#1A2E22] shadow-2xs transition-colors cursor-pointer flex items-center justify-center"
                      title="Previous Day"
                    >
                      <ChevronLeft className="w-4 h-4 sm:w-5 sm:h-5" />
                    </button>

                    <button
                      onClick={handleToday}
                      className="px-3 sm:px-4 py-1.5 bg-[#1F6E52] hover:bg-[#17553F] text-white font-bold rounded-lg shadow-2xs text-xs transition-colors cursor-pointer tracking-wider uppercase font-sans"
                    >
                      TODAY
                    </button>

                    <button
                      onClick={handleNextDay}
                      className="p-1.5 border border-[#C9CFC6] rounded-lg bg-white hover:bg-[#F1F3EC] text-[#1A2E22] shadow-2xs transition-colors cursor-pointer flex items-center justify-center"
                      title="Next Day"
                    >
                      <ChevronRight className="w-4 h-4 sm:w-5 sm:h-5" />
                    </button>
                  </div>

                  {/* Current Date Display */}
                  <div className="flex items-center gap-2 sm:gap-2.5 flex-wrap">
                    <h2 className="text-lg sm:text-xl font-display font-bold text-[#1A2E22] tracking-tight">
                      {formatDisplayDate(selectedDate)}
                    </h2>

                    {isToday ? (
                      <span className="px-2 py-0.5 rounded-md text-[11px] font-bold bg-[#E4F3EA] text-[#1B4332] border border-[#E1E4DC]">
                        Today
                      </span>
                    ) : (
                      <span className="px-2 py-0.5 rounded-md text-[11px] font-semibold bg-[#F1F3EC] text-[#5B6B60] border border-[#E1E4DC]">
                        Scheduled Day
                      </span>
                    )}

                    <span className="px-2 py-0.5 rounded-md text-[11px] font-semibold bg-[#DCEEE3] text-[#1F6E52] border border-[#E1E4DC] font-mono">
                      {activeDateCases.length} {activeDateCases.length === 1 ? 'Case' : 'Cases'} Listed
                    </span>
                  </div>
                </div>

                {/* View — one label + a small dropdown replaces the 4-button switcher.
                    Ask Nightingale ("switch to room grid", "any bottlenecks today?")
                    works too — handleAskNightingaleDashboardCommand below wires it up. */}
                <div className="flex items-center gap-2">
                  <span className="text-[11px] font-bold text-[#5B6B60] uppercase tracking-wider hidden sm:inline">View:</span>
                  <div className="relative">
                    <select
                      value={scheduleViewMode}
                      onChange={(e) => setScheduleViewMode(e.target.value as ScheduleViewMode)}
                      className="appearance-none pl-3 pr-8 py-1.5 rounded-lg text-xs font-bold bg-[#1F6E52] text-white shadow-2xs cursor-pointer border border-[#1F6E52] focus:outline-hidden focus:ring-2 focus:ring-[#1F6E52]/40"
                      title="Change dashboard view — or just ask Nightingale"
                    >
                      <option value="PRIORITY">Priority</option>
                      <option value="ROOM_FLOW">Room Grid</option>
                      <option value="BOTTLENECKS">Bottlenecks</option>
                      <option value="PIPELINE">Pipeline</option>
                    </select>
                    <ChevronDown className="w-3.5 h-3.5 text-white absolute right-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                  </div>
                </div>
              </div>

              {/* Home Dashboard Main Grid — three columns:
                  1. Today's Patients (schedule + expandable detailed readiness view)
                  2. Messages (incoming portal messages, linking to the full Messages page)
                  3. Nightingale AI Brief + Tasks (unchanged) */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">

                {/* Column 1: Today's Patients */}
                <div className="lg:col-span-5 space-y-6">
                  <ScheduleIntelligenceBox
                    cases={displayedCases}
                    viewMode={scheduleViewMode}
                    onViewModeChange={setScheduleViewMode}
                    onSelectPatient={handleOpenPatientChart}
                    onUpdateStage={handleUpdateStage}
                    onResolveAction={handleResolveAction}
                    onTriggerEKGFastTrack={handleTriggerEKGFastTrack}
                    onOpenCheckIn={(patient) => { setSelectedChartPatientId(patient.id); setPatientWorkspaceStation('frontOffice'); setActiveTab('patients'); }}
                    onAcceptForNursing={handleAcceptPatientForNursing}
                    onOpenStation={(patient, station) => { setSelectedChartPatientId(patient.id); setPatientWorkspaceStation(station); setActiveTab('patients'); }}
                  />
                </div>

                {/* Column 2: Messages */}
                <div className="lg:col-span-3 space-y-6 lg:sticky lg:top-20">
                  <DashboardMessagesPanel
                    onNavigateToMessages={() => setActiveTab('messages')}
                  />
                </div>

                {/* Column 3: Nightingale AI Brief + Tasks — unchanged */}
                <div className="lg:col-span-4 space-y-6">
                  {/* Nightingale AI Morning Brief — Waiting For / Communication
                      Center now live inside here as a collapsed one-liner
                      instead of two always-open panels in the main column. */}
                  <NightingaleBriefBanner
                    cases={activeDateCases}
                    onActionClick={() => setActiveTab('schedule')}
                    onOpenCase={(c, key) => handleOpenPatientChart(c, key)}
                    onFilterNeedsAttention={() => setSearchQuery('DePoli')}
                    stats={stats}
                    onSelectCategory={(cat) => {
                      if (cat.toLowerCase().includes('patient')) {
                        setActiveTab('messages');
                        showToast('Opening Patient Portal Messages & Triage Center...');
                      } else {
                        showToast(`Filtering communication records for ${cat}...`);
                      }
                    }}
                  />

                  {/* Tasks Widget */}
                  <TasksWidget
                    tasks={tasks}
                    onToggleTask={handleToggleTask}
                  />
                </div>

              </div>
            </>
          )}

          {/* TAB 2: FULL SCHEDULE WORKSPACE VIEW */}
          {activeTab === 'schedule' && (
            <ScheduleFullView
              cases={allCases}
              onSelectPatient={handleOpenPatientChart}
              practiceConfig={practiceConfig}
              onAppointmentSaved={handleScheduleAppointmentSaved}
            />
          )}

          {/* TAB 3: PATIENT CHARTS WORKSPACE */}
          {activeTab === 'patients' && allCases.length === 0 && (
            <div className="max-w-3xl mx-auto mt-16 bg-white border border-stone-200 rounded-2xl p-10 text-center shadow-sm">
              <FileText className="w-10 h-10 mx-auto text-[#1F6E52] mb-4" />
              <h2 className="text-xl font-bold text-stone-900">No patients yet</h2>
              <p className="mt-2 text-sm text-stone-500">Patient records will appear here after they are created or loaded from the Vityls database.</p>
              <button onClick={() => setIsAddPatientModalOpen(true)} className="mt-6 px-5 py-2.5 rounded-xl bg-[#1F6E52] text-white font-bold text-sm">Add Patient</button>
            </div>
          )}
          {activeTab === 'patients' && allCases.length > 0 && (() => {
            const chartPatient = allCases.find(c => c.id === selectedChartPatientId || c.patientId === selectedChartPatientId) || allCases[0];
            return patientWorkspaceStation
              ? <StationWorkspace key={chartPatient.id} patient={chartPatient} initial={patientWorkspaceStation} onBack={() => setPatientWorkspaceStation(null)}
                  onAdvance={(to, reason, unresolved) => handleAdvanceEncounterGate(chartPatient.id, to as EncounterJourneyStatus, reason, unresolved)}
                  onUpdatePatient={(updated) => updateCaseEverywhere(list => list.map(c => c.id === updated.id ? updated : c))} />
              : <PatientChartPage
                  cases={allCases}
                  initialSelectedPatientId={chartPatient.id}
                  initialSelectedSection={selectedChartSection}
                  onOpenPatientModal={(patient) => setSelectedChartPatientId(patient.id)}
                  onNavigateToPortalTab={() => setActiveTab('messages')}
                  onOpenAddPatient={() => setIsAddPatientModalOpen(true)}
                  onUpdatePatient={(updated) => {
                    setDateCasesMap(prev => {
                      const next = { ...prev };
                      Object.keys(next).forEach(key => {
                        next[key] = next[key].map(c => (c.id === updated.id ? updated : c));
                      });
                      return next;
                    });
                  }}
                  activePracticeId={selectedPracticeId}
                  onOpenVitylsNext={(patient, station) => {
                    setSelectedChartPatientId(patient.id);
                    const map: Record<string, WorkflowKey> = {
                      intake: 'patientPortal', nursing: 'nursing', anesthesia: 'anesthesia',
                      surgeon: 'surgeon', or: 'orTeam', intraop: 'orTeam', pacu: 'pacu',
                      discharge: 'pacu', final: 'pacu'
                    };
                    setPatientWorkspaceStation(map[station || 'nursing'] || 'nursing');
                  }}
                />;
          })()}

          {/* TAB 4: MESSAGES — a standalone, easy-to-find page (used by nearly every
              employee), promoted out of the Practice workspace where it used to be
              buried under a sub-tab. */}
          {activeTab === 'messages' && (
            <MessagesPage
              cases={activeDateCases}
              onOpenPatientChart={handleOpenPatientChartById}
              onShowToast={showToast}
              onNavigateTab={(tab, subMod) => handleNavigateWorkspace(tab, subMod)}
              onOpenLocalPracticeDashboard={handleOpenLocalPracticeDashboard}
            />
          )}

          {/* FORM STUDIO — standalone first-class workspace */}
          {activeTab === 'form-studio' && (
            <FormsWorkspacePage
              activePracticeId={selectedPracticeId}
              onShowToast={showToast}
              onBack={() => {
                setAdminActiveSection('configure-practice');
                setPracticeSubModule('admin');
                setActiveTab('practice');
              }}
            />
          )}

          {/* TAB 5: PRACTICE WORKSPACE (Billing, Administration, AI Workflows) */}
          {(activeTab === 'practice' || activeTab === 'billing' || activeTab === 'admin' || activeTab === 'ai-home' || activeTab === 'workflows') && (
            <PracticeWorkspace
              navKey={practiceNavKey}
              initialSubModule={
                activeTab === 'billing' ? 'billing' :
                activeTab === 'admin' ? 'admin' :
                (activeTab === 'ai-home' || activeTab === 'workflows') ? 'workflows' :
                practiceSubModule
              }
              cases={activeDateCases}
              onShowToast={showToast}
              onOpenPatientChartById={handleOpenPatientChartById}
              onOpenPatientChart={handleOpenPatientChart}
              onTriggerEKGFastTrack={handleTriggerEKGFastTrack}
              onUpdateStage={handleUpdateStage}
              practiceConfig={practiceConfig}
              practicesList={practicesList}
              activePracticeId={selectedPracticeId}
              onSelectPractice={handleSelectPractice}
              onAddPractice={handleAddPractice}
              onDeletePractice={(practiceId) => {
                if (practicesList.length <= 1) {
                  showToast('Cannot delete the only practice location.');
                  return;
                }
                const remaining = practicesList.filter(p => p.id !== practiceId);
                setPracticesList(remaining);
                if (selectedPracticeId === practiceId) {
                  handleSelectPractice(remaining[0].id || 'loc-1');
                }
                showToast('Practice location removed.');
              }}
              onUpdatePracticeConfig={handleUpdatePracticeConfig}
              adminActiveSection={adminActiveSection}
              onAdminSectionChange={setAdminActiveSection}
              onNavigateTab={(tab, subMod) => handleNavigateWorkspace(tab, subMod)}
              onOpenLocalPracticeDashboard={handleOpenLocalPracticeDashboard}
            />
          )}

        </main>
      </div>

      {/* Fixed Bottom Primary Navigation Bar (Dashboard / Schedule / Patients / Messages / Practice / Nightingale) */}
      <nav
        id="bottom-primary-nav"
        className="fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-[#E1E4DC] px-3 sm:px-6 py-2 flex items-center justify-around sm:justify-center sm:gap-5 md:gap-8 lg:gap-10 shadow-xl"
        aria-label="Primary Workspace Navigation"
      >
        <button
          id="bottom-nav-dashboard"
          onClick={() => setActiveTab('home')}
          className={`flex flex-col sm:flex-row items-center justify-center py-1.5 px-3 sm:px-4 rounded-xl transition-all cursor-pointer gap-1 sm:gap-2 select-none ${
            activeTab === 'home'
              ? 'bg-[#DCEEE3] text-[#1B4332] font-bold border border-[#E1E4DC] shadow-2xs'
              : 'text-[#5B6B60] hover:text-[#1A2E22] hover:bg-[#F1F3EC]'
          }`}
        >
          <Home className={`w-5 h-5 sm:w-4 sm:h-4 ${activeTab === 'home' ? 'text-[#1F6E52]' : 'text-[#5B6B60]'}`} />
          <span className="text-[10px] sm:text-xs font-semibold sm:font-bold">Dashboard</span>
        </button>

        <button
          id="bottom-nav-schedule"
          onClick={() => setActiveTab('schedule')}
          className={`flex flex-col sm:flex-row items-center justify-center py-1.5 px-3 sm:px-4 rounded-xl transition-all cursor-pointer gap-1 sm:gap-2 select-none ${
            activeTab === 'schedule'
              ? 'bg-[#DCEEE3] text-[#1B4332] font-bold border border-[#E1E4DC] shadow-2xs'
              : 'text-[#5B6B60] hover:text-[#1A2E22] hover:bg-[#F1F3EC]'
          }`}
        >
          <Calendar className={`w-5 h-5 sm:w-4 sm:h-4 ${activeTab === 'schedule' ? 'text-[#1F6E52]' : 'text-[#5B6B60]'}`} />
          <span className="text-[10px] sm:text-xs font-semibold sm:font-bold">Schedule</span>
        </button>

        <button
          id="bottom-nav-patients"
          onClick={() => setActiveTab('patients')}
          className={`flex flex-col sm:flex-row items-center justify-center py-1.5 px-3 sm:px-4 rounded-xl transition-all cursor-pointer gap-1 sm:gap-2 select-none relative ${
            activeTab === 'patients'
              ? 'bg-[#DCEEE3] text-[#1B4332] font-bold border border-[#E1E4DC] shadow-2xs'
              : 'text-[#5B6B60] hover:text-[#1A2E22] hover:bg-[#F1F3EC]'
          }`}
        >
          <div className="relative">
            <FileText className={`w-5 h-5 sm:w-4 sm:h-4 ${activeTab === 'patients' ? 'text-[#1F6E52]' : 'text-[#5B6B60]'}`} />
            {needsAttentionCount > 0 && (
              <span className="absolute -top-1 -right-1 w-2 h-2 bg-[#7A4E17] rounded-full ring-2 ring-white" />
            )}
          </div>
          <span className="text-[10px] sm:text-xs font-semibold sm:font-bold">Patients</span>
          {needsAttentionCount > 0 && (
            <span className="hidden sm:inline-flex text-[9px] px-1.5 py-0.2 rounded-full font-mono font-bold bg-[#7A4E17] text-white">
              {needsAttentionCount}
            </span>
          )}
        </button>

        {/* Messages — promoted to its own top-level, always-easy-to-find nav slot
            (used by nearly every employee), no longer buried under Practice. */}
        <button
          id="bottom-nav-messages"
          onClick={() => setActiveTab('messages')}
          className={`flex flex-col sm:flex-row items-center justify-center py-1.5 px-3 sm:px-4 rounded-xl transition-all cursor-pointer gap-1 sm:gap-2 select-none relative ${
            activeTab === 'messages'
              ? 'bg-[#DCEEE3] text-[#1B4332] font-bold border border-[#E1E4DC] shadow-2xs'
              : 'text-[#5B6B60] hover:text-[#1A2E22] hover:bg-[#F1F3EC]'
          }`}
        >
          <div className="relative">
            <MessageSquare className={`w-5 h-5 sm:w-4 sm:h-4 ${activeTab === 'messages' ? 'text-[#1F6E52]' : 'text-[#5B6B60]'}`} />
            {unreadPortalMessages > 0 && (
              <span className="absolute -top-1 -right-1 w-2 h-2 bg-[#1F6E52] rounded-full ring-2 ring-white" />
            )}
          </div>
          <span className="text-[10px] sm:text-xs font-semibold sm:font-bold">Messages</span>
          {unreadPortalMessages > 0 && (
            <span className="hidden sm:inline-flex text-[9px] px-1.5 py-0.2 rounded-full font-mono font-bold bg-[#1F6E52] text-white">
              {unreadPortalMessages}
            </span>
          )}
        </button>

        <button
          id="bottom-nav-practice"
          onClick={() => {
            setActiveTab('practice');
            setPracticeSubModule('admin');
            setAdminActiveSection('home');
            setPracticeNavKey(k => k + 1);
          }}
          className={`flex flex-col sm:flex-row items-center justify-center py-1.5 px-3 sm:px-4 rounded-xl transition-all cursor-pointer gap-1 sm:gap-2 select-none relative ${
            activeTab === 'practice' || activeTab === 'billing' || activeTab === 'admin'
              ? 'bg-[#DCEEE3] text-[#1B4332] font-bold border border-[#E1E4DC] shadow-2xs'
              : 'text-[#5B6B60] hover:text-[#1A2E22] hover:bg-[#F1F3EC]'
          }`}
        >
          <Building2 className={`w-5 h-5 sm:w-4 sm:h-4 ${activeTab === 'practice' || activeTab === 'billing' || activeTab === 'admin' ? 'text-[#1F6E52]' : 'text-[#5B6B60]'}`} />
          <span className="text-[10px] sm:text-xs font-semibold sm:font-bold">Practice</span>
        </button>

        {/* Nightingale — her one consistent entry point across the whole app,
            replacing the floating "Ask AI" bubble that used to duplicate this.
            Styled with the info-highlight treatment (#3E8FA6) used to mark every
            Nightingale AI surface in the app, so she reads as "on staff" AI, not
            just another nav tab. */}
        <button
          id="bottom-nav-nightingale"
          onClick={() => setIsAIChatOpen(true)}
          className={`flex flex-col sm:flex-row items-center justify-center py-1.5 px-3 sm:px-4 rounded-xl transition-all cursor-pointer gap-1 sm:gap-2 select-none relative ${
            isAIChatOpen
              ? 'bg-[#E7F1F3] text-[#1D4E5A] font-bold border border-[#3E8FA6]/50 shadow-2xs'
              : 'text-[#5B6B60] hover:text-[#1D4E5A] hover:bg-[#E7F1F3]'
          }`}
          title="Open Nightingale AI — On duty"
        >
          <div className="relative">
            <Sparkles className={`w-5 h-5 sm:w-4 sm:h-4 ${isAIChatOpen ? 'text-[#3E8FA6]' : 'text-[#5B6B60]'}`} />
            <span className="absolute -top-1 -right-1 w-2 h-2 bg-[#2F9E6E] rounded-full ring-2 ring-white" />
          </div>
          <span className="text-[10px] sm:text-xs font-semibold sm:font-bold">Nightingale</span>
        </button>
      </nav>

      {/* Patient Detail Modal */}
      <PatientDetailModal
        patient={selectedPatient}
        onClose={() => setSelectedPatient(null)}
        onUpdateStage={handleUpdateStage}
        onToggleAction={handleResolveAction}
        onTriggerEKGFastTrack={handleTriggerEKGFastTrack}
        onOpenChart={handleOpenPatientChart}
      />

      {/* Nightingale AI Chat Drawer with Workspace Navigation Directive Engine */}
      <NightingaleAIChatDrawer
        isOpen={isAIChatOpen}
        onClose={() => setIsAIChatOpen(false)}
        scheduleCases={activeDateCases}
        onNavigateWorkspace={handleNavigateWorkspace}
        onSelectPatient={handleOpenPatientChart}
        onShowToast={showToast}
      />

      {/* Add New Patient Record Modal */}
      <AddPatientModal
        isOpen={isAddPatientModalOpen}
        onClose={() => setIsAddPatientModalOpen(false)}
        onAddPatient={(newPatient) => {
          updateActiveCases((prev) => [newPatient, ...prev]);
          setSelectedChartPatientId(newPatient.id);
          setActiveTab('patients');
          showToast(`Created patient record for ${newPatient.name}!`);
        }}
      />

      {/* Legacy form-based Office Check-In removed. Dashboard Check-In now opens the unified V3 Pre-Op Nursing workspace. */}

    </div>
  );
}
