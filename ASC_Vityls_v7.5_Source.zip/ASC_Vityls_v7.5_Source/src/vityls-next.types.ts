export type RequirementState = 'complete' | 'needs_review' | 'discrepancy' | 'not_applicable' | 'blocked' | 'authenticated';
export type JourneyState = 'complete' | 'active' | 'waiting' | 'locked' | 'later';

export interface ProvenanceRef {
  source: 'patient' | 'front_desk' | 'rn' | 'anesthesia' | 'surgeon' | 'outside_record' | 'system';
  label: string;
  recordedAt: string;
  verifiedBy?: string;
  verifiedAt?: string;
}

export interface ClinicalFact<T = string> {
  conceptId: string;
  label: string;
  value: T;
  status: RequirementState;
  provenance: ProvenanceRef;
  attention?: string;
}

export interface JourneyStep {
  id: string;
  label: string;
  state: JourneyState;
  detail?: string;
}

export interface EncounterSummary {
  encounterId: string;
  patientId: string;
  displayName: string;
  age: number;
  procedure: string;
  procedureVersion: number;
  surgeon: string;
  anesthesia: string;
  room: string;
  scheduledTime: string;
  journey: JourneyStep[];
  allergies: ClinicalFact[];
  medications: ClinicalFact[];
  history: ClinicalFact[];
  readiness: { label: string; state: RequirementState; detail?: string }[];
  vte: { factors: { label: string; points: number }[]; total: number; risk: string };
  mh: { positiveResponses: number; totalQuestions: number; result: string };
}
