import {StrictMode, useEffect, useState} from 'react';
import { InviteLanding } from './v7/InviteLanding';
import { parseInviteHash } from './v7/invitations';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import { seedTestData } from './v6/seed';
seedTestData();
import './v6/fonts.css';
import './index.css';

/** v7.3: the provider invitation links (#invite=…) open the onboarding pages instead of the app. */
function Root() {
  const [hash, setHash] = useState(location.hash);
  useEffect(() => { const f = () => setHash(location.hash); window.addEventListener('hashchange', f); return () => window.removeEventListener('hashchange', f); }, []);
  return parseInviteHash(hash) ? <InviteLanding key={hash} /> : <App />;
}
createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <Root />
  </StrictMode>,
);
