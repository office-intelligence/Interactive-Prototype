# Office Intelligence Form Engine & QUAD A Crosswalk Prototype

## Scope
This is a product-design and implementation crosswalk, not a certification opinion. Office Intelligence must allow each facility to select its accreditation/program profile, state requirements, anesthesia classes, specialty rules, and local policy requirements. A published form version must be frozen to the encounter in which it was used.

## Recommended record model
- Structured patient/encounter data is the source of truth.
- Responsive HTML is the working interface for patients and staff.
- Original outside records remain immutable source documents.
- Each completed Office Intelligence clinical document is finalized to a signed/locked PDF rendition.
- Every extracted or carried-forward clinical fact retains provenance, verification status, verifier, and timestamp.
- Allergies and medications are shared chart fields. They are never copied into separate role-specific databases; each gate verifies or updates the same record.

## Day-of-surgery gates implemented in this prototype
1. Scheduled / Pre-arrival
2. Arrived / Checking In
3. Ready for Pre-Op (Front Desk complete; Nursing notified)
4. Pre-Op Nursing (RN accepts patient)
5. Ready for Anesthesia / Anesthesia Evaluation
6. Ready for OR / In OR
7. PACU / Ready for Discharge
8. Discharged / Record Completion / Case Complete

Each transition should record current owner, handoff timestamp, exceptions, required signatures, and Nightingale verification findings.

## Existing Office Intelligence form set reviewed
### Patient/intake
- Admission Form
- Insurance Information
- Medical History
- Anesthesia Questionnaire
- Billing Fee Disclosure
- Credit Card Authorization
- Patient Satisfaction Survey

### Clinical/nursing
- Pre-Operative Checklist and Assessment
- Peri-Operative Nursing Assessment
- Comprehensive Surgical Checklist
- Doctor's Standing Orders
- Brief Operative Summary Note
- Recovery Room Record (PACU)
- Post Operative Instructions
- Consent to Procedure
- Consent for Anesthesia
- Anesthesia Pre-Op Evaluation
- Liposuction Treatment Areas
- Injection of Local Anesthesia

## Prototype crosswalk findings
### Strong existing coverage
- Demographics and registration
- Medical history
- Allergies and medications
- NPO status
- Responsible adult/transportation
- Surgical and anesthesia consents
- Pre-op nursing assessment/checklist
- Standing orders
- Brief operative summary
- PACU/recovery documentation
- Post-operative instructions
- Anesthesia pre-op evaluation

### Areas to strengthen or make explicit
- Same-day current/interval medical-history review before anesthesia/procedure
- Formal linkage and clinician review of H&P / medical clearance when applicable
- Structured VTE risk assessment and prophylaxis decision
- Discrete time-out gate including correct patient, procedure, site/laterality, implants/special equipment, team confirmation, discrepancy resolution
- Structured intra-operative anesthesia record, including medications with date/time/dose/route, fluids, and physiologic monitoring appropriate to the anesthesia class
- PACU transfer handoff from procedure/anesthesia team
- Serial PACU vital signs, consciousness/recovery status, medications and nursing notes
- Standardized discharge score/criteria, responsible clinician authorization, signer and discharge time
- Detailed operative report finalization/authentication
- Source-document links and provider-review attestations for labs, EKG, clearance and consultation notes

## Form Studio customization test
Administration > Clinical Form Studio now includes a schema-driven prototype.

The administrator can switch one core pre-op form between:
- Multispecialty Core
- Plastic Surgery
- Orthopedics
- Ophthalmology

Specialty-specific fields are appended to the same shared core without editing React source. The preview demonstrates the target behavior: chart-sourced fields prefill, clinical lists are verified/updated, signatures carry identity/timestamp metadata, and the completed document is intended to finalize as PDF.

## Current QUAD A source note
As of the product review on August 22, 2026, QUAD A's website states that revised program manuals became effective February 2, 2026 and should be used for upcoming surveys and ongoing compliance. The current accreditation page identifies an Office-Based Surgical Standards Manual v15.2 link. The publicly linked v15.2 DOCX retrieved during this review displays an older cover effective date (February 1, 2023), so Office Intelligence should not embed a hard-coded claim that a specific field set guarantees current QUAD A compliance. Store standards crosswalks as versioned configuration and have the facility administrator validate the applicable current manual/program/state requirements before publishing.

## Next engineering step
Move the prototype form schema out of UI-local state and into database tables/API endpoints for:
- FormTemplate
- FormTemplateVersion
- FormSection
- FormField
- FieldOption
- ValidationRule
- RoleRequirement
- AccreditationCrosswalk
- SpecialtyProfile
- EncounterFormInstance
- FieldResponse
- VerificationEvent
- SignatureEvent
- SourceDocumentLink
- FinalizedPdfArtifact
- Amendment
- AuditEvent
