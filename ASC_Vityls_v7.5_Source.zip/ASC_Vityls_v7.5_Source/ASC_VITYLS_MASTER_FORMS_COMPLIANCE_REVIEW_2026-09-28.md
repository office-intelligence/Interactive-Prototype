# ASC.Vityls Master Forms — 2026-09-28 Review

## Scope and standard set
The uploaded Vityls Master Template Set v1.0 (28 templates) was treated as the authoritative baseline. The review compared the template set with current 2026 QUAD A ASC materials, CMS ASC Conditions for Coverage / survey guidance, and current California Title 22 record requirements. This is a product/compliance design review, not legal advice or a certification that any form set by itself establishes compliance. Facility policy, scope, accreditor, payer, and California counsel/compliance review still control production use.

## Cross-cutting changes applied
- Preserved the standardized Patient / Encounter header and the user's published form text.
- Added Special Needs / Accommodations documentation to Nursing Admission and Pre-Op H&P to support QUAD A 8-B-9.
- Added explicit surgical fire-risk assessment, required-record review, and discrepancy-resolution documentation to Universal Protocol; also added fire-risk/discrepancy disposition to the combined intra-op nursing/time-out record.
- Added explicit mouth opening, neck mobility, dentition/dental risk, and anticipated difficult-airway fields to Anesthesia Evaluation.
- Added Preferred Contact Method to Patient Registration to support text/email/paper intake delivery.
- Retained Vityls signature architecture: electronic authentication timestamps are system-generated; printed versions should render date/time lines automatically rather than requiring redundant manual electronic date fields.
- Forms may be assigned to multiple workflows. Completion, verification, and authentication are role/station events; a prior patient's entry can prepopulate a later form without implying the later clinician authenticated it.

## Per-template review
| Template | Review result / role in final set |
|---|---|
| Against Medical Advice / Refusal of Care | Retain. Strong informed-refusal structure with capacity, risks, alternatives, patient/surrogate and witness/clinician documentation. |
| Admission Form | Retain as administrative rights/acknowledgment packet. Facility-specific rights, privacy, ownership, grievance, advance-directive and arbitration text must remain editable and reviewed locally. |
| Patient Consent for Anesthesia | Retain. Patient consent plus anesthesia-provider authentication; planned technique can prepopulate from anesthesia plan and be verified. |
| Anesthesia Pre-Operative Evaluation | Retain; enhanced focused-airway structure. Should pull allergies, meds, history, vitals/labs already known and require anesthesia verification rather than re-entry. |
| Anesthesia Intra-Operative Record | Retain. Captures anesthesia times, technique/airway, fluids/losses, events, disposition and provider authentication. |
| Anesthesia Questionnaire | Retain for at-home intake. Patient-source answers should populate longitudinal profile as unverified/patient-reported until clinical review. |
| Cash Payment Fee Disclosure | Retain as separate financial form; practice decides applicability. |
| Credit Card Authorization | Retain as optional financial form; keep payment data handling isolated from the clinical record and follow payment-security policy. |
| Day-of-Surgery Interval H&P Update | Retain. Supports day-of change assessment; should prepopulate the prior H&P date/source and allergies. |
| Emergency Transfer Form | Retain. Supports transfer authorization, clinical handoff and departure documentation. |
| Insurance Information | Retain for intake/front office; should prepopulate existing payer/member data. |
| Intra-Operative Nursing Record & Surgical Time-Out Log | Retain; enhanced with explicit fire-risk and discrepancy-resolution documentation. Multi-role time-out verification should be captured as role-specific authentication events. |
| MH and VTE Risk Assessment | Retain. Patient can provide history at home; nursing/anesthesia/surgeon can review/verify relevant portions without duplicating answers. Facility protocol determines scoring/action requirements. |
| Patient Pre-Operative Medical History Questionnaire | Retain as patient-source intake; map to shared clinical concepts for reuse. |
| Day-of-Surgery Nursing Pre-Op Evaluation & Admission | Retain; enhanced with special-needs/accommodations. Should be primarily a review/verification form populated from intake, front desk, clearance and prior profile. |
| PACU Progress & Recovery Record | Retain. Includes admission/recovery data, Aldrete scoring, pain/PONV, orders, discharge criteria and disposition. Authentication should identify the responsible PACU clinician and timestamp automatically. |
| Patient Registration | Retain as the demographic source form; enhanced with preferred contact method. This is the principal exception to the no-redundant-demographics rule. |
| Patient Satisfaction Survey | Retain as optional post-discharge patient form; not a clinical gate. |
| Photography, Media, and Research Consent | Retain as optional standalone consent; do not infer consent from procedure consent. |
| Physician Discharge Order and Diagnosis | Retain. Captures discharge diagnosis, disposition/orders and physician authentication. |
| Post-Operative Discharge Evaluation & Patient Handoff Sign-off | Retain. Nursing discharge/readiness and handoff should remain distinct from physician discharge order. |
| Brief Pre-Operative H&P / Medical Clearance | Retain; enhanced with special-needs/accommodations. Should clearly show date of H&P and ambulatory-surgery suitability decision. |
| Consent to Operation, Anesthetics and Post-Operative Care | Retain as procedure consent template. Practice may separate anesthesia/media/blood language depending local policy; separate dedicated consents remain available. |
| Surgeon Membership & Privileges Application | Retain under provider credentialing, not patient chart workflow. |
| Surgeon Operative Report | Retain. Includes pre/post diagnosis, procedure, findings, technique, implants/specimens, complications and disposition, aligning with California/CMS record-content expectations. |
| Surgeon Pre-Operative Documentation & Clinical Clearance | Retain. Use for immediate surgeon assessment/appropriateness and role-specific authentication. |
| Universal Protocol / Surgical Safety Checklist | Retain; enhanced for 2026 QUAD A time-out requirements. Team confirmation remains separate from individual clinical form completion. |
| Written Discharge Instructions | Retain. Must be delivered to patient/responsible adult; patient and nurse acknowledgment can be configured by practice. |

## Runtime rules for the build
1. Known data prepopulates forms; users verify or update rather than re-enter it.
2. Source/provenance is retained when data flows from patient intake, front desk, prior records, uploaded documents, nursing, anesthesia, surgeon, OR or PACU.
3. A form assigned to multiple workflows is one form definition with multiple role/station interactions—not duplicate records.
4. Each role authenticates only the content/attestation actually presented to that role.
5. Electronic signature/authentication date/time is system-generated. Printable paper forms render signature/date/time lines.
6. Paper/scanned completion remains a supported alternative pathway and is labeled distinctly from structured electronic completion.
7. Readiness gates evaluate requirements independently of whether a form was completed electronically or on paper.

## Patient intake test path restored
Patient Chart → At-Home Intake now exposes forms assigned to the Patient Portal workflow. Staff can select all or individual assigned forms, choose email or SMS, preview the generated portal link, and use **Test as Patient** to open the selected form in the patient-facing full-screen experience.

## Build validation note
The reference-form catalog generator recognizes all 28 templates. Full Vite compilation could not be completed in this environment because the source package does not contain the Vite executable/node_modules (`vite: not found`). Source-level changes and generated catalog were completed; production integration should run the normal dependency install and CI build/test suite.
