# ASC.Vityls Next — Build 0.1

This is the transition build from the frozen ASC frontend into the production-oriented Vityls Next architecture.

## What is new
- `src/vityls-next.types.ts`: typed semantic domain contract.
- `src/services/vitylsApi.ts`: API interface + mock adapter. Replace this adapter with Henry's development API without reshaping clinical components.
- `src/components/VitylsNextWorkspace.tsx`: first real one-page Pre-Op Nursing workspace inside the existing React application.
- Dashboard opens to Vityls Next by default while the prior application remains available in the codebase.

## Architecture boundary
The frontend consumes semantic concepts and domain objects, not legacy iMARS table names. The mock adapter is deliberately the seam for backend integration.

## First integration target
Patient / Encounter → Front Desk → Pre-Op Nursing → Anesthesia → Authentication → Audit → Document Output.

## Run
`npm install`
`npm run dev`

## Validate
`npm run lint`
`npm run build`
