# ASC.Vityls Station Configuration & Stability Fix — 2026-09-26

## Scheduler crash
Root cause identified in ScheduleFullView week-mode appointment rendering. The appointment overlay calculated `leftPercent` and `widthPercent` but referenced out-of-scope `leftCss` / `widthCss`. The error only executed after an appointment existed, explaining why Save appeared to crash the entire application. Week-mode rendering now uses the calculated percent values.

## Clinical Configuration
The prior Clinical Configuration page was a visual scaffold. It is replaced with a functional station configuration editor:
- pick a clinical station
- see all configured fields/requirements for that station
- stable semantic IDs
- field/control type
- required vs optional
- owner
- Core / Conditional / Practice Custom layer
- edit field behavior
- add practice custom field/requirement
- delete custom fields only; Core fields are protected
- local persistence for frontend review

The default field catalog is seeded from the Vityls Data Capture & Sign-Off by Station design.

## Pre-Op Nursing
- Edit buttons now open an edit modal and save the reviewed value in frontend state.
- Added LMP when applicable.
- Added dentures / loose teeth.
- Added contact lenses.
- Added other nursing tasks / observations.
- Added Nursing Notes free-text area.

## Validation note
Source-level fixes were applied. The current sandbox dependency tree does not contain a runnable Vite binary, so a clean Vite production build could not be executed here. The scheduler crash root cause is a direct JavaScript scope error and was corrected at the source location.
