# ASC.Vityls Frontend V1 — Whole-System Review Build

Purpose: one coherent frontend for clinical/product review before Henry database integration.

## Included journey
At-Home Intake → Pre-Op Nursing → Anesthesia → Surgeon → OR Sign-In / Time-Out → Intra-Op → PACU → Discharge → Final Case Record.

All stations use one shared encounter workspace and a consistent role-specific authentication pattern. The Nursing station preserves the approved V3 one-page clinical review philosophy.

## Patient chart cleanup
- Removed the standalone green “Open Pre-Op Nursing Clinical Review” button.
- Removed the standalone Pre-Operative Medical Clearance Checklist from the main chart view.
- Added compact Pre-Op Clearance / Readiness information inside Day of Surgery Journey.
- Journey cards route to the new shared Vityls clinical workspace instead of legacy form-based station viewers.
- Replaced visible “forms” counts in the Journey with “requirements” language.

## Practice configuration
Added Practice → Clinical Configuration with:
- station requirements: Vityls Core / Conditional / Practice Custom
- patient intake configuration
- Documents & Templates
- authentication/signature settings
- rules, gates and calculations
- procedure workflow profiles

## Important development note
This is a frontend review build using mock/shared client state. It is intentionally not yet connected to Henry's development API. The local package dependency installation exceeded the execution window, so a clean Vite/TypeScript production build could not be verified in this environment. Source changes are packaged for review/integration.
