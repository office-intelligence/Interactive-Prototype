# Vityls ASC — Final Provider / Medical Director Database Handoff
Date: 2026-09-15

## Frontend freeze additions
- ASC terminology is **Medical Director**, not Primary Provider.
- Medical Director is a provider role/assignment; do not model it as a separate provider entity.
- New surgeons begin with `Invitation Pending` and receive one onboarding email containing both the Membership & Privileges Application link and a secure Vityls account-activation link.
- Account activation and credentialing/privileging are separate state domains in the backend.
- Credentialing workflow represented in UI: Invitation Pending → Application Pending → Pending Medical Director Review → Privileges Approved.
- Before Medical Director review, administrative verification confirms application completeness and credential documents.
- **Medical Director approval is required** to complete surgeon privileges.
- Persist approval actor, timestamp, decision, privilege scope, effective/expiration dates, and audit history.
- Provider scheduler color belongs to the provider/surgeon, not to the operating room.
- Room assignments should use stable `room_id` values.

## Recommended backend boundaries
Keep separate tables/entities for Provider, ProviderRole/Assignment, UserAccount, CredentialingApplication, CredentialDocument, PrivilegeRequest/Grant, MedicalDirectorReview, and AuditEvent. A provider may have multiple roles; `MEDICAL_DIRECTOR` is one such assignment.

## Scheduler final UI rule
The Day and Week views now share the same fixed 52px Time column. Room/day columns consume the remaining width dynamically.
