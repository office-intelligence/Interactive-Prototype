# Vityls Master Form Studio — Evaluation Build 3

## Purpose
This build restores the preferred Online Forms / three-column card library as the primary Form Studio and turns it into a master-template authoring workspace.

## Master publishing model
- `Edit Master` opens the full-screen editor.
- `Save Draft` preserves work without replacing the published master.
- `Publish Master` promotes the current edited HTML/schema to the browser-local Vityls Master Template Set.
- The Form Library preview reads the published master first.
- Published master HTML is also mirrored to the compatibility template key used by runtime form renderers.
- Master revisions are retained in browser-local history.
- `Export Master Set` downloads a portable JSON snapshot of all published master template HTML/schema/history. This export is the handoff artifact for baking the corrected library into a later source build.

## Editing behavior
- Existing field labels and requiredness can be changed.
- Known template fields removed in the editor are removed from the published HTML when a safe name mapping exists.
- Practice-editable textarea/policy blocks are written into the published HTML.
- Choice options remain editable in schema.
- Workflow assignments remain separate from form content.
- The standard Patient / Encounter header is protected from field-removal logic because it is structural and is not treated as a normal template field.

## Library
- 28 HTML templates are discovered by the prebuild catalog.
- Patient Registration is explicitly categorized as Intake / Registration.
- Billing Fee Disclosure is presented as Cash Payment Fee Disclosure.
- New standardized patient headers and prior Admission Form cleanup are retained from Build 2.

## Validation
`npm run prebuild` succeeds and reports 28 HTML templates.
Full Vite/TypeScript compilation cannot be completed in this container because project dependencies/node_modules are not installed. A global `tsc` run therefore reports missing React/Vite/etc. modules across the existing project and is not a meaningful compile validation.
