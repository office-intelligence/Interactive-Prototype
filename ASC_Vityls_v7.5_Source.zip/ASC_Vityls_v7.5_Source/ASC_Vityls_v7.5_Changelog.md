# ASC.Vityls v7.5 — changelog (2026-10-05)

Built on git tag `v7.4` (commit 5fcdd42). This is still a test build: fictional data only, browser `localStorage`, no backend.

## What changed

### 1. Allergy carry-forward replaces Not Reported (not append)
**Bug:** Medical History allergies carried into stations, but the FactCard showed both, e.g. `Not Reported · patient reported: …`.

**Fix:** `effectiveAllergy()` in `src/v7/allergy.ts` is the single rule:
- Chart `patient.allergies` wins.
- If still not reported, patient-reported intake (`patient.reportedAllergies` fact) **replaces** Not Reported (with a confirm note).
- Never concatenates the two strings.

Applied in StationWorkspace FactCard, chart `AllergyStatus`, Case Record, dashboard case-status, and the chart “not reported” banner.

**Confirm** on the station allergy card writes the reported list into `patient.allergies` (clears the transitional display).

### 2. Light green / light red allergy cards everywhere
Unchanged tokens in `ALLERGY_STYLE`, now used consistently on station FactCard (including value text color), chart AllergyStatus, and related surfaces:
- NKDA → light green `#E7F4EC`
- Allergies → light red `#FDECEC`
- Not Reported → neutral grey

### 3. Confirm / Edit buttons
- **Correct** renamed to **Edit** (Kevin’s choice).
- Confirm → light green (`vy-btn-confirm`).
- Edit → light red (`vy-btn-edit`; CSS tokens updated from amber to light red to match allergy styling).

### 4. Editable OR event times
`src/v6/EventBar.tsx`:
- Empty event: one-tap stamps current HH:MM (unchanged).
- Existing time: tap opens an editor (`type="time"`), with **Save**, **Now**, and **Cancel**.
- Save audits `event.time.edit` with `old → new` and still writes shared facts (`time.inOR`, `time.anesStart`, …) used by billing minutes.

### 5. Seed version
`SEED_VERSION = 'v7.5'` — first open of this build resets test data once (same pattern as prior versions).

## Out of scope (unchanged)
Azure/SQL, email/SMS schedules, Form Studio redesign, Billing/Ops full data bind.

## How to verify
1. Open the double-click build or `npm run dev`. Prefer `?reset-test-data` once for a clean seed.
2. **Allergy replace:** On a case, set Medical History / intake so `patient.reportedAllergies` is filled (or use a patient with only reported allergies). Open any workstation → **Known clinical facts → Allergies**. You should see the allergy text (or NKDA) on a red/green card — **not** `Not Reported · …`. Tap **Confirm** (green); the chart allergy updates and “confirm” note clears. Tap **Edit** (red) to change the list.
3. **OR times:** Open OR Team station → OR event times. Tap **In room** (stamps now). Tap again → edit panel → change time → **Save**. Check Case Record / audit for `event.time.edit` with old → new.

## Packages
- Double-click: `ASC_Vityls_v7.5.zip` → `ASC_Vityls_v7/index.html`
- Source: `ASC_Vityls_v7.5_Source.zip`
