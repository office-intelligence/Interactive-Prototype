# Vityls Approved New UI — Complete Frontend Test Build

This build deliberately uses the October 2 approved UI direction and deprecates the older pages.

## Test path
Dashboard -> compact/expanded patient card -> Patient Chart -> station -> Evidence Forms -> dedicated full-page form -> Save / Authenticate -> return to station.
Practice -> Administration -> Forms & Workflow -> My Forms / Form Library / Stations & Assignments / Practice PDFs.
Practice -> Billing & Payments. Practice -> Operations Intelligence.

## Frozen architecture
Seven stations: Patient Portal, Front Office, Nursing, Anesthesia, Surgeon/Physician, OR Team, PACU/Discharge. Case Record is separate.
Forms are dedicated full application pages, not new browser tabs, modals, drawers, or iframes. The page owns vertical scrolling. A sticky footer provides Close, Print PDF, Save Changes, and Save & Authenticate.
Evidence Forms are derived from active station assignments. Paper-enabled work supports Upload Completed PDF.
Patient Chart is longitudinal. Encounter workflow is one level below the chart. Station work is one level below the encounter.

## Pre-Henry note
This is a frontend evaluation build using local browser persistence for form data. Henry's API/database should replace the persistence adapter without changing the approved UX hierarchy.
