# Vityls Pre-Database Workflow / Patient / Notes Cleanup — 2026-09-13

This revision removes remaining prototype-era duplication before the Azure database schema is finalized.

## 1. Forms: one model, explicit workflow assignment

- There is no separate production `IntakeForm` entity.
- An **Intake Form** is simply an HTML or PDF form assigned to the **Patient Portal** workflow.
- The same form definition may be assigned to Patient Portal, Front Office, Nursing, Anesthesia, Surgeon/Physician, OR Team, and PACU/Discharge without duplicating the clinical record.
- Legacy implicit/default workflow assignments were removed. A form appears in a workflow only after the administrator explicitly selects it in Form Studio.
- The frontend performs a one-time cleanup of legacy local workflow assignment keys so testing starts from the new explicit assignment model.
- Practice PDF uploads are now persisted in the local IndexedDB test store and use the same workflow assignment mechanism as the 27 HTML templates.
- Patient Chart Intake Forms, Patient Portal, Front Office, Nursing, Anesthesia, Surgeon/OR, PACU and Day-of-Surgery form counts now read the new workflow assignment source instead of the old hard-coded intake/nursing form arrays.

### Backend boundary for Henry

Recommended production entities:

- `FormDefinition` — stable form identity, tenant/practice ownership, source format (`HTML`, `PDF`)
- `FormVersion` — immutable versioned HTML/schema or PDF Blob reference
- `FormWorkflowAssignment` — `PracticeId`, `FormDefinitionId`, `WorkflowRole`, active/effective dates
- `PatientFormRequest` — assignment of a form/version to a patient/encounter for completion or review
- `FormInstance` / `FormResponse` — actual completed clinical record
- `Signature` — signer/audit metadata tied to the exact form instance/version

Do **not** create separate `IntakeForms`, `PDFForms`, `NursingForms`, etc. tables. Those are workflow views over the same form model.

## 2. Patient Portal / Front Office / Clinical workflows

All runtime workspaces now use explicit Form Studio assignments. The old built-in seeded intake packet is no longer the source of truth.

For workflow roles, use a stable code set such as:

- `PATIENT_PORTAL`
- `FRONT_OFFICE`
- `NURSING`
- `ANESTHESIA`
- `SURGEON`
- `OR_TEAM`
- `PACU_DISCHARGE`

A form can have many assignments.

## 3. Doctor notes / Dictate Note

The Nightingale **Dictate Note** command again opens the Doctor Notes section and draft workspace. The test patient now has the same note workflow available as other patients.

Current note types include:

- History & Physical (H&P)
- SOAP Note
- Daily / Progress Note

### Backend boundary

Treat notes as a distinct clinical documentation domain, not as generic uploaded documents:

- `ClinicalNote`
- `ClinicalNoteType`
- `ClinicalNoteVersion`
- `ClinicalNoteAuthor`
- `ClinicalNoteSignature` (or shared Signature table)
- status such as Draft / Final / Amended / Superseded
- patient, encounter, author/provider, created/finalized timestamps, provenance and audit trail

Voice/dictation output should populate a draft note and never overwrite a finalized note.

## 4. Patient demographics editing

The pencil icon now opens the same full demographic form used by **Add New Patient**, rather than a separate Contact Info-only popup. This keeps one patient registration model for create and update.

The production patient model therefore needs to support at least:

- legal name / middle initial
- MRN
- DOB / sex or gender field used by the application
- ethnicity and marital status where collected
- phone / email
- full address
- SSN (if the practice elects to collect it; protect appropriately)
- driver's license / identification data
- occupation / employer
- emergency contact
- referral source
- payment type
- allergies / registration notes references

Do not maintain a separate `PatientContactOverride` table merely because the prototype once did. Persist the authoritative patient demographic/contact values in the production patient/domain model with normal audit history.

## 5. PDF handling

Uploaded practice PDFs are form templates, not patient documents until instantiated for a patient/encounter. Preserve the original PDF as an immutable source Blob. A patient completion becomes a separate form/document instance with annotations/signatures and audit evidence.

## 6. What remains prototype-only

The current frontend still uses localStorage/IndexedDB to demonstrate workflow selection, draft customization and PDF persistence. Henry should replace those persistence mechanisms with tenant-scoped API/database/Blob operations while preserving the behavior described above.
