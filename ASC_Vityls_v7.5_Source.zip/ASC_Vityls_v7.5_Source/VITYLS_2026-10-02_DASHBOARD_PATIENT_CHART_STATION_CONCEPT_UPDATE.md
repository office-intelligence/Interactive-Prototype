# Vityls approved Dashboard / Patient Chart / Station concept integration

- Replaced the legacy Today's Patient Flow card surface with the approved larger, quieter patient-card concept.
- Patient cards now emphasize identity, procedure, Nightingale readiness, current status, and the canonical station journey.
- Replaced the legacy patient-chart route with the uploaded approved patient-chart concept for evaluation.
- Bundled the uploaded station-workspace concept next to the patient-chart concept so its station links open the approved station workspace.
- Preserved the approved Source Sans 3 typography direction used by the uploaded concepts.
- This evaluation integration intentionally prioritizes exact review of the approved visual/workflow concepts before deeper backend wiring.
