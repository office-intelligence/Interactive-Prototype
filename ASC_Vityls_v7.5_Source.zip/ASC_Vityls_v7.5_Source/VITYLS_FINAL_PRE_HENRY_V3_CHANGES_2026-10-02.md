# Vityls Final Pre-Henry Test Build v3 — 2026-10-02

## Requested changes implemented
- Replaced simplified Billing & Payments evaluation screen with the supplied Billing & Payments design/content.
- Replaced simplified Operations Intelligence evaluation screen with the supplied ASC Operations / Nightingale design/content.
- Both pages now return to the Administration workspace with a Back to Administration control.
- Administration subpages retain a common Administration Home return control.
- Removed the redundant Practice Configuration header/link card.
- Removed Medical Director designation from Practice Configuration / scheduler settings.
- Medical Director remains managed in People & Credentials.
- Administration Home Medical Director shortcut now routes to People & Credentials.
- Existing Forms & Workflow, Patient Chart, station workflow, forms, signatures, and other approved v2 work preserved.

## Integration note
Insurance claims, eligibility, ERA/payment posting, credit-card processing, live financial metrics, and Nightingale operational analytics remain frontend/evaluation surfaces until Henry connects database services and the appropriate external APIs.

## Validation
`npm run build` was attempted. The source package does not include installed node_modules in this environment, so Vite was unavailable (`vite: not found`). Source-level changes and package structure were preserved; a full dependency-backed compile was not claimed.
