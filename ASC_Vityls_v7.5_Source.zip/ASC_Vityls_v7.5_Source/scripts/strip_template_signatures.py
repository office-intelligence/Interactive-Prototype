"""v7.4 item 5: remove signature fields / signature blocks from the HTML form templates.
Signatures (and Admission initials) come only from Signer setup + the multi-signer panel.
Usage: python scripts/strip_template_signatures.py [--dry] public/forms/*.html
"""
import re, sys
from bs4 import BeautifulSoup, NavigableString
DRY = '--dry' in sys.argv
files = [a for a in sys.argv[1:] if not a.startswith('--')]
PAD = '.sig-pad-wrap, .sig-pad-actions, .sig-actions, .sig-status, canvas, [data-field-type=signature], [data-vityls-type=signature]'
BLOCK = '.signature-block, .signature-section, .signatures, .sig-block, div.sig, div.sign'
SIGLABEL = re.compile(r'signature|\bsigned\b|\binitials?\b(?!\s*(count|bp|pain|check))|print(ed)?\s*name|^\s*date\s*(/\s*time)?\s*$|^\s*time\s*$', re.I)
SIGNAME = re.compile(r'^(sig|sign)|signature|print$|^(patient|clinician|witness|nurse|rn|md)Print', re.I)
KEEP = re.compile(r'refus', re.I)

def label_of(group):
    l = group.find(['label', 'b', 'strong'])
    return l.get_text(' ', strip=True) if l else ''

def strip(html, name):
    soup = BeautifulSoup(html, 'html.parser'); log = []
    body = soup.body or soup
    for el in body.select(PAD): el.decompose()
    for inp in body.select('input[type=hidden]'):
        if SIGNAME.search(inp.get('name', '') + inp.get('id', '')): inp.decompose()
    # field groups that are signature captures (typed-name signature, initials, signer print name, signing date/time)
    for g in body.select('.form-group, .field, .fg'):
        inputs = g.find_all(['input', 'textarea', 'select'])
        lab = label_of(g)
        if any(KEEP.search(i.get('name', '') + (i.get('placeholder') or '')) for i in inputs): continue
        in_block = g.find_parent(class_=re.compile(r'^(signature-block|sig-block|signature-section|signatures|sig|sign)$')) is not None
        if lab and re.search(r'signature|\binitials\b', lab, re.I) and not re.search(r'initial (count|bp|pain|check)', lab, re.I):
            log.append(f'field: {lab[:50]}'); g.decompose(); continue
        if in_block and (SIGLABEL.search(lab) or any(SIGNAME.search(i.get('name', '')) for i in inputs)):
            log.append(f'block field: {lab[:50]}'); g.decompose()
    # whole signature blocks: keep any remaining non-signature control (e.g. "patient refuses to sign" note) just before the block
    for b in body.select(BLOCK):
        if not re.search(r'signature|sign-off|\bsign(ed|s)?\b|attest|authenticat|certif|acknowledg|initials', b.get_text(' ', strip=True), re.I):
            if b.find(['input', 'textarea', 'select']) is None and not b.get_text(strip=True):
                b.decompose(); continue
            # clinical content that only sat in a signature-styled box (e.g. pre-induction re-evaluation time): keep it, un-style as signature
            b['class'] = ['notice' if c in ('signature-block', 'signature-section', 'signatures') else c for c in b.get('class', []) if c not in ('sig', 'sign')] or ['notice']
            for t in b.select('.signature-title'): t['class'] = ['section-title']
            log.append(f'kept as notice: {b.get_text(" ", strip=True)[:60]!r}')
            continue  # e.g. Anesthesia_Evaluation's "sig-block" header (Procedure date / Surgeon) is not a signature block
        keep = [g for g in b.select('.form-group, .field, .fg') if g.find(['input', 'textarea', 'select'])]
        other = [i for i in b.find_all(['input', 'textarea', 'select']) if not any(i in k.descendants for k in keep)]
        for i in other:  # bare typed-signature inputs (Admission/Medical History "Sign or type full name")
            log.append(f'bare input: {(i.get("placeholder") or i.get("name") or "")[:40]}')
        for k in keep:
            b.insert_before(k.extract()); log.append(f'kept: {label_of(k)[:50]}')
        log.append(f'block removed: {(b.get("class") or [""])[0]} {b.get_text(" ", strip=True)[:60]!r}'); b.decompose()
    # flowsheet "RN Initials" columns: author + time of each row are captured automatically (field provenance)
    for table in body.find_all('table'):
        heads = table.find_all('th')
        for th in heads:
            t = th.get_text(' ', strip=True)
            if re.fullmatch(r'Time\s*/\s*RN Initials', t, re.I): th.string = 'Time'; log.append('th renamed: Time / RN Initials -> Time')
        rows = table.find_all('tr'); hdr = next((r for r in rows if r.find('th')), None)
        if not hdr: continue
        cells = hdr.find_all(['th', 'td'])
        idx = [n for n, c in enumerate(cells) if re.fullmatch(r'(RN|Nurse|MD)?\s*Initials', c.get_text(' ', strip=True), re.I)]
        for n in sorted(idx, reverse=True):
            for r in rows:
                cs = r.find_all(['th', 'td'], recursive=False)
                if len(cs) > n and not cs[n].get('colspan'): cs[n].decompose()
            log.append(f'column removed: #{n} Initials')
    # Admission cash-fee clause initials are configured in Signer setup (FORM_RULES initials), not hard-coded
    for inp in body.select('input'):
        if re.fullmatch(r'initials?', (inp.get('placeholder') or '').strip(), re.I):
            p = inp.find_parent('p')
            log.append(f'hard-coded initials removed: {(p.get_text(" ", strip=True) if p else "")[:60]!r}')
            (p or inp).decompose()
    return str(soup), log

for f in files:
    src = open(f, encoding='utf-8').read(); out, log = strip(src, f)
    if log: print('==', f.split('/')[-1]); [print('   ', l) for l in log]
    if not DRY and out != src: open(f, 'w', encoding='utf-8').write(out)
