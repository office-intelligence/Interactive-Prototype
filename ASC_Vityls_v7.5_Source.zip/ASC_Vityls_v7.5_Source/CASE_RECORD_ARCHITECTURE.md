# Office Intelligence — Configurable Surgical Case Record Architecture

## Core decision: structured encounter data first, PDF last

Office Intelligence should not choose between “HTML forms” and “PDF forms” as the master record. The durable model should be a versioned **form/record schema** plus structured encounter data. The application renders that schema as responsive HTML for patients and staff, while a finalized PDF rendition is generated and sealed when the record is signed/locked.

Use original uploaded PDFs as source evidence when a facility receives outside records (clearance notes, laboratory reports, EKGs, imaging, consultation notes). Do not attempt to convert every outside PDF into an editable form. AI/OCR may extract candidate data, but the original remains immutable and linked to every derived field.

## Three layers

1. **Template definition** — facility/specialty/version/effective date, sections, fields, validation, visibility, role ownership, required signatures, dependencies, and final PDF layout.
2. **Encounter instance** — patient/date-of-service values, status, provenance, reviewer identity, timestamps, signatures/authentication, amendments, exceptions, and AI verification results.
3. **Final record artifact** — locked PDF/PDF-A rendition plus cryptographic hash, source-document links, version metadata, and audit trail.

## Practice customization

A facility chooses a workflow profile (ASC, office-based surgery, specialty clinic, etc.) and can add specialty extensions without changing application code. For example, ophthalmology can require laterality/IOL records while orthopedics can require site marking and implant/lot tracking. Historical encounters retain the exact profile/template version effective on the date of service.

The initial TypeScript profile is in `src/data/caseWorkflowProfiles.ts` and is intentionally designed to move to database-backed configuration.

## Nightingale rules

Nightingale may summarize, compare, prefill, extract, reconcile, detect omissions/conflicts, and propose next actions. It must never silently sign, attest, clinically approve, or change an immutable finalized record. Every AI-derived value should retain source/provenance and confidence. High-consequence gaps become workflow blockers until an authorized human resolves or explicitly accepts the exception.

## Completion gates

A stage is complete only when its required records exist and required fields/signatures/reviews are satisfied. Recommended gates:

- Before clinical handoff: identity/intake/source documents verified.
- Before procedure: required pre-op assessments, consents, diagnostic review and provider authentication complete.
- Before discharge: PACU assessment, objective discharge criteria, instructions/acknowledgment and qualified discharge authorization complete.
- Before case close: operative/anesthesia/PACU records finalized, exceptions reconciled, source links intact, case summary generated, and administrator locks the packet.

## Audit record

The audit view should provide one date-of-service index with a completion badge and direct links to both the immutable original source and finalized PDF rendition for every record. The case summary should include patient/procedure metadata, involved clinicians, timeline, diagnoses/procedure, key pre-op findings, anesthesia, recovery/discharge, document/signature index, exceptions/amendments, and audit-log references.

The first UI implementation is `src/components/CaseRecordCommandCenter.tsx`, opened by the new **Case Record** button in the patient chart.
