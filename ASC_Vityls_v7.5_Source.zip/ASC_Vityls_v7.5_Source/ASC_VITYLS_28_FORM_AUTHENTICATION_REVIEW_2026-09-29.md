# ASC.Vityls 28-Form Authentication / Review Matrix — 2026-09-29

## Design rule
For every section ask: **Does this document an action, order, decision, consent, verification, or attestation that requires attribution/authentication?** If yes, bind authentication to the exact content and signer role. If the requirement is only review/verification, record reviewer identity, role, timestamp, status, and any discrepancy rather than adding a gratuitous freehand signature.

## Regulatory basis used for this evaluation
- CMS ASC Conditions for Coverage require complete/correct records including identification, properly executed informed consent, H&P/pre-surgical assessment, allergies, diagnostic studies when performed, anesthesia entries, operative findings, discharge diagnosis, post-surgical assessment, and discharge documentation.
- QUAD A ASC v9.1 is effective 2026-02-02. Current QUAD A guidance requires documented time-out before every operation; pre-op verification includes records/imaging, fire risk and implants, with discrepancies addressed. QUAD A also requires documented surgeon/proceduralist + anesthesia-provider concurrence with the anesthesia plan when applicable.
- California Title 22 §70527 outpatient surgery provisions include pre-op evaluation, informed operative consent, pre-op instructions, medical record requirements and examination before discharge in the covered setting. Facility type and policy determine applicability.

This matrix is a product/compliance design crosswalk, not a statement that every listed authentication is independently mandated by every regulator. Facility policy, scope of practice, accreditor, procedure/anesthesia class and California facility type must remain configurable.

| Form | Primary author / data source | Review / verification | Authentication recommended in Vityls |
|---|---|---|---|
| Patient Registration | Patient / front desk | Front desk verifies identity/demographics | Patient/responsible-party certification when practice uses it; front-desk verification event, not extra signature |
| Admission Form | Patient / front desk | Front desk + admitting RN | Patient acknowledgement only where content is an acknowledgement; RN admission verification separately |
| Insurance Information | Patient / front desk | Front desk | Patient attestation only if practice requires accuracy/assignment acknowledgement; otherwise verification event |
| Credit Card Authorization | Patient/cardholder | Front desk/billing | Cardholder authorization |
| Billing / Fee Disclosure | Patient/responsible party | Front desk/billing | Patient acknowledgement |
| Medical History | Patient | RN verifies; anesthesia reviews clinically relevant history | Patient attestation; RN verification event; anesthesia review event—no duplicate freehand signatures unless policy requires |
| Anesthesia Questionnaire | Patient | Anesthesia provider | Patient attestation; anesthesia-provider review/authentication at evaluation |
| MH & VTE Assessment | Patient + clinical team | RN verifies patient responses; anesthesia reviews MH risk; surgeon/proceduralist owns prophylaxis decision when applicable | Patient attestation; RN verification event; anesthesia review event; surgeon authentication only when documenting prophylaxis/order/decision |
| Photography / Media / Research Consent | Patient | Staff verifies consent scope | Patient consent; witness only if facility policy/consent process requires |
| Procedure Consent | Licensed practitioner + patient | Facility verifies consent present/complete before procedure | Patient/representative consent + practitioner authentication of informed-consent process; witness per policy |
| Anesthesia Consent | Anesthesia provider + patient | Pre-op team verifies complete | Patient/representative consent + anesthesia-provider authentication |
| Pre-Op H&P Clearance | Physician/QHP | RN/anesthesia/surgeon review as applicable | Authoring physician/QHP authentication |
| Day-of-Interval H&P Update | Surgeon/QHP | Pre-op/OR team verifies present | Surgeon/QHP authentication immediately before procedure per policy |
| Surgeon Pre-Op Clearance | Surgeon/proceduralist | RN/anesthesia/OR team | Surgeon/proceduralist authentication |
| Nursing Admission | RN | Subsequent care team reviews | RN authentication of assessment; surgeon authentication for surgeon orders; do not use RN signature to authenticate physician orders |
| Universal Protocol / Safety Checklist | OR team | Entire procedural team participates | Team-member attribution + time-out completion authentication; surgeon/proceduralist and anesthesia concurrence documented when applicable |
| Intra-Op Nursing Record & Time-Out | Circulating RN + OR team | Surgeon/anesthesia/team | RN authentication of nursing record; documented time-out participants; surgeon/anesthesia concurrence where applicable |
| Anesthesia Evaluation | Anesthesia provider | Surgeon/team may review readiness | Anesthesia-provider authentication |
| Anesthesia Intra-Op Record | Anesthesia provider | PACU handoff/review | Anesthesia-provider authentication of anesthesia record |
| Surgeon Operative Report | Surgeon/proceduralist | Clinical/billing teams consume | Surgeon/proceduralist authentication |
| PACU Recovery Record | PACU RN; anesthesia as required | Discharge readiness review | PACU RN authentication; anesthesia/qualified practitioner authentication where required by facility policy/state/CMS role assignment |
| Physician Discharge Order | Physician/QHP | RN verifies order before discharge | Ordering physician/QHP authentication |
| Post-Op Discharge | RN + patient/escort | RN verifies criteria/instructions/transport | RN discharge authentication; patient/representative receipt acknowledgement; responsible-adult acknowledgement where used |
| Written Discharge Instructions | Clinical team; patient receives | RN verifies instructions delivered/understood | Patient/representative receipt acknowledgement when practice uses it; RN documentation of teaching |
| Emergency Transfer Form | Treating clinicians/RN | Receiving handoff | Author/clinician authentication; transfer/handoff attribution; receiving acknowledgement only if workflow supports it |
| AMA Refusal Form | Clinician + patient/representative | Witness/staff per policy | Patient/representative refusal; clinician documentation/authentication; witness when facility policy requires |
| Patient Satisfaction Survey | Patient | Quality team | No clinical signature; optional anonymous/identified submission |
| Surgeon Membership Application | Applicant physician | Credentialing staff + Medical Director/governing body per policy | Applicant attestation; credentialing verification; Medical Director/governing-body approval authentication |

## Vityls implementation rules
1. One universal freehand signature component for all patient/representative/escort/witness signatures.
2. Logged-in clinician authentication uses identity + role + timestamp + PIN/approved authentication method; drawing is optional unless policy requires it.
3. Orders are authenticated by the ordering practitioner; another user's signature must never make an order appear authored by that practitioner.
4. Review/verification is a structured event, not automatically a signature.
5. Completed/signed form instances remain immutable and tied to their template version. Amendments create a new event/version; no silent replacement.
6. Workflow assignment and template versioning are independent. Publishing a new version does not require reassignment.
