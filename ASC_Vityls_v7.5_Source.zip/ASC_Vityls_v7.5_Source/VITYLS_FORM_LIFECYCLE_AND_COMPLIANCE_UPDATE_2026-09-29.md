# Vityls Form Lifecycle + Compliance Update

- Standardized explicit freehand signature placeholders to the universal Vityls signature component.
- MH/VTE RN field changed from an ambiguous signature text field to structured RN Review / Verification; patient attestation remains a true signature.
- Form Studio terminology changed toward Practice Form lifecycle: Save Draft → Assign → Publish Update.
- Added explicit Save Workflow Assignments inside the editor using the same storage key as the Workflow tab.
- Workflow assignment persists across later form edits/published versions.
- Added visible FORM STATUS and last-action feedback so users know whether changes are draft, assigned, or published.
- Added 28-form authentication/review matrix distinguishing author, reviewer/verifier, and authenticator.
