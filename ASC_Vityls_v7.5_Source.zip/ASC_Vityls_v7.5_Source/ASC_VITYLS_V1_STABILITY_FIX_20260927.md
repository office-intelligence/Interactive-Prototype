# ASC.Vityls Frontend V1 — Stability Fix

## Patient chart
- Patient search is permanently visible.
- Removed the Nightingale Compact/Expanded control; chart coordinator remains expanded.
- Removed the duplicate Add Patient button from the global header on the Patients page.
- The Add Patient action remains next to the patient search area.

## Practice
- Fixed the Practice workspace runtime failure caused by the missing `SlidersHorizontal` icon import used by Clinical Configuration.

## Scheduler
- Hardened appointment Save so a malformed/incomplete draft cannot crash the application.
- Requires a patient name before save.
- Normalizes time, duration, room, procedure, clinician, anesthesia, payment, and display fields before inserting/updating schedule state.
- Save is wrapped in a guarded error path so a booking error remains local instead of taking down the application UI.

## Review target
This is a frontend review build using client/mock state. Database persistence remains an API integration milestone.
