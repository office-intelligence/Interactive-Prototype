# ASC.Vityls Evaluation Build — Persistence + Patient Chart + Guided Intake

This evaluation build incorporates the 2026-09-28 annotated Patient Chart review and testing feedback.

## Evaluation persistence
- Schedule appointments persist in browser localStorage.
- Patient/case records persist across page navigation and date changes.
- Newly scheduled cases can create/link an evaluation chart if no existing case is found.
- Practice providers remain stored in browser localStorage and are available to scheduler provider search after navigation back to Schedule.
- Open Chart now resolves the scheduled patient instead of falling back to an unrelated first case.

## Add Patient
- Adds Gender to the minimal chart-creation popup.
- DOB remains source of truth; Age is calculated/read-only.
- Phone required; email optional.

## At-Home Intake
- Test as Patient is a guided multi-form session.
- Selected forms advance with Save & Continue and finish with Complete Intake.
- Progress is shown as form N of total.
- Known patient/encounter values are prepopulated through the existing intake prefill function.
- Browser-local form autosave remains enabled for evaluation.

## Patient Chart annotation changes
- NKDA uses a full green emphasis row; known allergies use full red emphasis.
- Major medications and chronic conditions moved immediately beneath allergy status.
- Print action moved from the patient header into Nightingale common actions.
- Appointment History header shows current appointment/date/time; prior history stays collapsed behind the arrow.
- Clearance no longer opens by default. At-Home Intake is hidden until invoked from the Nightingale Intake Forms command.

## Important
This is an evaluation persistence layer, not the production database. Henry's backend remains the authoritative target for durable multi-user/session persistence.
