# Vityls Universal Signature Commit — 2026-09-12

This build keeps the simplified Forms workflow from the prior revision and completes the shared freehand electronic-signature experience across the application.

## Standard signature experience

Every Vityls signature now uses the same interaction pattern:

1. Freehand signature canvas (finger, stylus, or mouse)
2. Explicit intent-to-sign acknowledgement
3. Clear / re-sign capability
4. Accept Signature action
5. Accepted signature stored as a PNG data URL in the current frontend draft model
6. Existing autosave mechanisms receive an input/change event when a signature is accepted or cleared

Production backend integration should additionally persist authenticated signer ID, signer role, tenant ID, patient/encounter ID, form/document version, UTC timestamp, audit event ID, and integrity/hash evidence.

## HTML forms

All 26 standard HTML templates are routed through `IsolatedHtmlFormRenderer` in the React form viewer/workflow experience. The renderer now upgrades signature fields centrally instead of relying on each legacy form's embedded JavaScript.

- Existing signature canvases are converted to the universal Vityls signature control.
- Older typed signature inputs are automatically converted to the same freehand control.
- Legacy signature scripts and legacy Clear/Accept UI are not executed.
- Standard form preview now uses the same isolated React viewer rather than an iframe, so preview and workflow use the same signature behavior.
- Form-preview field values and signature hidden values autosave to local browser draft storage.

At the time of this commit, 23 of the 26 standard HTML forms contain one or more signature fields. The other three forms remain signature-free because their templates do not request a signature.

## Patient/chart workflow

The old typed-name signature panel on the patient chart HTML intake viewer was replaced with the shared `SignaturePad` component. The signer identity remains the patient identity; the drawing is the electronic signature artifact.

## Clinical workflow

Nursing, anesthesia, surgeon, front-office and patient-facing React signature panels continue to use the shared `SignaturePad`, now with the same required intent-to-sign acknowledgement.

## PDF viewer

AcroForm `/Sig` fields no longer use a separate miniature signature implementation. Clicking a PDF signature field opens the same Vityls `SignaturePad` experience used elsewhere. On acceptance, the signature image is placed back into the PDF field and participates in PDF draft autosave.

PDF documents without a real `/Sig` field are not automatically given a signature location; the practice should define/signature-enable the PDF field where appropriate.

## Registration / legal agreements

The account-registration legal agreement step was also migrated from typed-name signature to the shared freehand signature component. Agreement acceptance records now identify the method as `Drawn Signature`.

## Forms workflow preserved

No changes were made to the workflow model approved immediately before this release:

Form Library -> Preview / Customize / Select -> Workflow

Workflow assignment remains a simple availability decision across Patient Portal, Front Office, Nursing, Anesthesia, Surgeon/Physician, OR Team and PACU/Discharge. There is no separate Verify or Sign workflow checkbox; signature requirements come from the actual fields in the form/document.

## Validation performed

- Confirmed 26 HTML templates remain in `public/forms`.
- Audited signature markers in all standard HTML templates; 23 contain signature fields and are covered by the universal renderer.
- Performed TypeScript syntax transpilation checks on all changed TSX files with TypeScript 5.8.3: passed.
- A full project `tsc --noEmit` could not complete because the recovered package's bundled `node_modules/@types` tree is incomplete. This is an environment/dependency issue rather than a syntax failure in the changed files.

Henry should run a clean dependency install and production build before merging into the Azure/database/auth branch.
