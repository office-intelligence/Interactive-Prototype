# ASC.Vityls Frontend FINAL — Database Ready

Final pre-database UI freeze, September 15, 2026.

## Provider onboarding
- ASC terminology uses **Medical Director**, not Primary Provider, in the user-facing provider/credentialing workflow.
- New surgeon creation is presented as **Add Provider & Send Invitation**.
- The onboarding invitation includes both the Membership & Privileges Application and an account-activation link.
- Provider rows expose credentialing/access status and allow invitation resend.
- Credentialing workflow: Invitation Pending → Application Pending → Pending Medical Director Review → Privileges Approved.
- Medical Director approval is the final privileging gate after administrative credential verification.
- Email delivery, secure activation tokens, authentication, persistence, authorization, and audit records are backend responsibilities.

## Scheduler mini-calendar
- The mini-calendar has previous/next month controls.
- Month arrows browse the mini-calendar without moving the main scheduler.
- Selecting a date moves the scheduler to that date and switches to Day view.
- When the main scheduler date changes, the mini-calendar follows it automatically.
- Day and Week views retain the same narrow Time-column width.

## Database boundary
Henry should keep Provider, Provider Role/Medical Director assignment, User Account, Credentialing Application, Credential Documents, Privilege Decisions, and Audit Events as separate relational concerns. Appointment room assignment should persist stable room IDs rather than display names.
