> **SUPERSEDED FOR RUNTIME CHECK-IN (2026-09-27):** Any legacy form-based Arrival/Office Check-In instructions in this document are no longer active. All day-of-surgery Check-In entry points now open the unified V3 Pre-Op Nursing clinical review. Practice documents/intake templates remain separate document capabilities.

# Day-of-Surgery Patient Gate Workflow

## Front Desk
Patient arrives -> staff clicks the check-in status on Today's Patients -> Arrival & Office Check-In opens.

The page shows a Nightingale arrival review and the existing chart allergies/medications. Front Desk verifies administrative information and intake forms, but does not clinically reconcile medication significance or abnormal results.

Final action: **Complete Check-In & Notify Nursing**.

This changes the encounter to **Ready for Pre-Op**, assigns Nursing as current owner, records the handoff timestamp, and adds the case to the **Pre-Op Queue**.

## Nursing
Today's Patients now includes a **Pre-Op Queue** filter. A patient handed off by Front Desk displays **Accept Patient**.

The nurse clicks Accept Patient. The encounter becomes **Pre-Op Nursing** and the Patient Chart opens directly into the Nursing workflow.

At the top of the Nursing workflow, allergies and medications are carried forward from the patient record. The nurse selects **Confirm unchanged** or **Update in chart**. The target production model propagates any update to Anesthesia, Surgeon, PACU, discharge, and the final Case Record.

## Oversight
The Case Record page displays current owner/status and front-desk/nursing handoff badges. Nightingale continuously identifies unresolved requirements and blocks advancement where configured by facility rules.
