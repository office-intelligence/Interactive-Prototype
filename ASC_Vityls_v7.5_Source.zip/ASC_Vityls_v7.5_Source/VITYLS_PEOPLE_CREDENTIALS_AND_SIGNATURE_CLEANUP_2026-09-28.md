# ASC.Vityls People & Credentials + Signature Cleanup

Evaluation build update, 2026-09-28.

## Practice organization
- Consolidated the visible administration destinations into Practice Configuration, People & Credentials, Forms & Workflows, Compliance/Documents, and future workforce functions.
- Added a People & Credentials workspace with Medical Staff, Clinical Staff, Administrative Staff, and Vendors & Contractors tabs.
- Medical Director is now a designation applied to an existing physician/provider record, not a duplicate person/user.
- Added Medical Director designation to Practice Configuration and People & Credentials. Evaluation selection persists locally.
- Medical Staff shows credentialing, Vityls access, authentication, and Medical Director status together.
- Clinical/administrative staff are represented as people whose credentials/training, account, signature authentication, and workforce status stay attached to one identity.
- Payroll/timekeeping is described as employee-specific; surgeons/independent providers are not automatically treated as payroll employees.

## Signature correction
- Tightened the legacy typed-field-to-signature conversion. A text input is converted into a signature pad only when its visible label explicitly represents a signature.
- Fields whose internal names contain `sig` or similar abbreviations no longer become signature pads merely because of their field name.
- Excluded refusal documentation, printed-name, date/time, witness-name, and similar data-entry fields from automatic signature conversion.
- Existing true signature canvases remain signature controls.

## Clinical form viewing
- Electronic forms in the forms-based clinical journey now open as a full-screen workspace rather than a constrained popup, improving tablet use.

## Validation
- Reference catalog generation recognized 28 HTML templates.
- TypeScript JSX syntax was parsed successfully for the modified AdministrationPage, PracticeAdminHome, IsolatedHtmlFormRenderer, and FormsBasedClinicalWorkspace files.
- Full Vite production compilation could not be run in this container because the extracted package does not contain the Vite executable; this is an environment limitation rather than a reported source parse error.
