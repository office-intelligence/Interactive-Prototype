# Vityls User Access + Provider Invitation Update

## People & Credentials
- Medical Staff retains the Membership & Privileges Application invitation.
- Provider invitation includes account activation for user-created username/password and Signature Authentication PIN setup.
- Medical Staff now exposes Send/Resend Privilege Application, Account Invite, Reset Password, Reset PIN, Deactivate/Reactivate, and Open Record actions.
- Clinical and Administrative Staff use the same person-centered access model.
- New staff are invited to create their own username/password; clinical staff can establish signature authentication.
- Staff actions include Send/Resend Invite, Reset Password, Reset Signature PIN where applicable, Deactivate/Reactivate, and Edit.
- Administrators do not see or assign passwords or signature PINs; reset actions initiate a secure user reset flow.
- Access status is distinct from employment/credential status, so a person can remain in the historical record while application access is disabled.
- Evaluation access records and staff records persist in browser localStorage pending Henry's database integration.

## Intended production model
One Person -> role/relationship -> credentials/privileges -> Vityls account -> RBAC permissions -> signature authentication -> audit history.

## v7.3 update (2026-10-04): provider invitation is one email with three links
- Adding a provider (Administration → Providers) sends ONE invitation email with three single-use, 14-day links: Membership & Privileges Application, create username + password, create Signature PIN. Admins no longer set PINs; scheduler color stays required; email is required.
- Code: `src/v7/invitations.ts` (email, tokens, outbox, account + PIN stand-ins), `src/v7/InviteLanding.tsx` (the three pages, routed from `index.html#invite=<step>&t=<token>`), `src/v7/ProvidersAdmin.tsx` (preview, Outbox, Resend, status trail). Account status still goes to `vityls:access-records:v1`.
- Status trail per provider: Invited → Application received → Account created → PIN set (plus "Invitation resent"), logged in the credentialing history.
- Plug-in points for production:
  1. Email service: `registerEmailTransport({ id, label, send })` → server endpoint (e.g. POST /api/provider-invitations) that sends via SES / SendGrid / Postmark.
  2. Tokens: server-generated, single-use, hashed at rest, expiry enforced; validate with GET /api/invite/:token (replaces `resolveToken`). Set `window.VITYLS_INVITE_BASE_URL` so links read `<base>/invite/<step>/<token>`.
  3. Auth backend: `createAccount` → POST /api/auth/activate (IdP such as Cognito / Auth0 / Entra ID, or server with argon2id); `setSignaturePin` → POST /api/auth/signature-pin (server-side salted hash, re-authentication required). The browser hashes in this build are evaluation-only.
