# Vityls Final Pre-Henry v5 — Patient Header + Current Encounter Restore

Scope intentionally limited to two Patient Chart sections.

- Replaced Patient ID header with the preferred earlier visual design.
- Preserved/added patient photo upload/capture support.
- Added a visible Profile button; Edit and Profile both open the existing patient profile/contact editor.
- Restored the three-column Drug Allergies / Major Medications / Chronic Conditions presentation.
- Restored Account Clear-style status treatment and Nightingale conflict banner treatment.
- Replaced Current Visit Summary with the preferred Current Encounter design: encounter title/status badges, Reason/Surgeon/Anesthesia/DOS columns, Nightingale Brief, and previous-visit summary.
- No Nightingale command, documents, intake, billing, payment, notes, messages, print, e-prescribe, dictation, Health Journey, right-column, Practice, Billing, or Operations/Facility Performance behavior was intentionally changed in this revision.
