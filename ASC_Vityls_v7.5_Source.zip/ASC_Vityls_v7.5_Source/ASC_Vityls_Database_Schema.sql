-- =====================================================================================
-- ASC.Vityls — PostgreSQL schema (v7.4 database-readiness handoff)
-- Target: PostgreSQL 15+.  Generated 2026-10-04 for Kevin Tehrani.
-- Validated: loads cleanly on PostgreSQL 17.6 (37 tables, 40 RLS policies, 37 PHI-flagged columns);
-- append-only trigger and tenant isolation were exercised with a non-superuser role.
--
-- Conventions
--   * Multi-tenant: every tenant-owned table carries practice_id (FK practices.id) and is
--     protected by row-level security (RLS) keyed on the session setting app.practice_id.
--   * Every table has created_at / updated_at (timestamptz, server time). updated_at is
--     maintained by trigger set_updated_at(). Append-only tables (audit_log, signatures,
--     addenda, form_value_history, payments) reject UPDATE/DELETE by trigger.
--   * PHI columns are flagged with  COMMENT ... IS 'PHI: ...'  (and "-- PHI" inline) so a
--     column-level encryption / masking / access-logging policy can be generated from the
--     catalog:  SELECT * FROM phi_columns;  (view at the end of this file).
--   * Ids are uuid (gen_random_uuid()). Human-facing numbers (MRN, invoice number) are
--     separate unique columns per practice.
--   * Timestamps from the browser are never trusted for signatures, locks or audit: the
--     API writes now() server-side.
--
-- Row-level security notes (apply in the API connection, not in app code):
--   * The API opens each request with:   SET LOCAL app.practice_id = '<uuid>';
--                                        SET LOCAL app.user_id     = '<uuid>';
--   * Policies below allow rows where practice_id = current_setting('app.practice_id')::uuid.
--   * The migration/owner role bypasses RLS (BYPASSRLS); the API role (vityls_api) does NOT.
--   * Platform super-admin tooling uses a separate role with explicit, audited access.
--   * Patients using the portal are scoped further by patient_id in the API layer
--     (and optionally a second policy on app.patient_id).
-- =====================================================================================

CREATE EXTENSION IF NOT EXISTS pgcrypto;   -- gen_random_uuid(), digest()
CREATE EXTENSION IF NOT EXISTS citext;     -- case-insensitive email / username

-- ---------- helpers ----------
CREATE OR REPLACE FUNCTION set_updated_at() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN NEW.updated_at := now(); RETURN NEW; END $$;

CREATE OR REPLACE FUNCTION forbid_update_delete() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN RAISE EXCEPTION '% is append-only (% not allowed)', TG_TABLE_NAME, TG_OP; END $$;

CREATE OR REPLACE FUNCTION current_practice() RETURNS uuid LANGUAGE sql STABLE AS $$
  SELECT nullif(current_setting('app.practice_id', true), '')::uuid $$;

-- ---------- enums ----------
CREATE TYPE user_role        AS ENUM ('platform_admin','practice_admin','practice_manager','front_desk','preop_rn','circulating_rn','pacu_rn','surgeon','anesthesiologist','crna','medical_director','billing','patient');
CREATE TYPE provider_role    AS ENUM ('Surgeon','Anesthesiologist','CRNA','Other provider');
CREATE TYPE cred_status      AS ENUM ('Invited','Application received','Primary-source verification','Committee review','Medical Director approval','Credentialed','Declined');
CREATE TYPE invite_purpose   AS ENUM ('application','account','pin','pin-reset');
CREATE TYPE email_kind       AS ENUM ('provider-invitation','pin-reset');
CREATE TYPE case_stage       AS ENUM ('scheduled','pre_arrival','checked_in','preop','anesthesia','intraop','pacu','discharged','cancelled');
CREATE TYPE case_tone        AS ENUM ('clear','pending','hold');
CREATE TYPE form_status      AS ENUM ('not-started','draft','partially-signed','locked');
CREATE TYPE value_source     AS ENUM ('case','carried','default','normal','calc','voice','event','manual');
CREATE TYPE signature_method AS ENUM ('drawn','typed');
CREATE TYPE doc_status       AS ENUM ('Received','Reviewed');
CREATE TYPE alert_severity   AS ENUM ('info','attention','critical');
CREATE TYPE invoice_status   AS ENUM ('Draft','Sent','Partially paid','Paid in full','Void');
CREATE TYPE fee_match_kind   AS ENUM ('default','procedure','surgeon','anesthesiaType','room');

-- =====================================================================================
-- 1. Tenants, users, roles
-- =====================================================================================
CREATE TABLE practices (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name          text NOT NULL,
  legal_name    text,
  npi           text,
  tax_id        text,                 -- sensitive (not PHI), encrypt at rest
  address1      text, address2 text, city text, state char(2), zip text,
  phone         text, fax text, email citext,
  timezone      text NOT NULL DEFAULT 'America/Los_Angeles',
  settings      jsonb NOT NULL DEFAULT '{}'::jsonb,   -- practice configuration page (header style, workflow switches)
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE users (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  practice_id   uuid NOT NULL REFERENCES practices(id),
  username      citext NOT NULL,
  email         citext,
  display_name  text NOT NULL,
  credentials   text,                 -- 'RN', 'MD', 'CRNA'
  password_hash text,                 -- argon2id; never the browser's demo hash
  pin_hash      text,                 -- signature PIN (argon2id), separate from password
  pin_failures  int  NOT NULL DEFAULT 0,
  locked_at     timestamptz,
  deactivated_at timestamptz, deactivated_by uuid, deactivation_reason text,
  last_login_at timestamptz,
  mfa_enabled   boolean NOT NULL DEFAULT false,
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now(),
  UNIQUE (practice_id, username)
);

CREATE TABLE roles (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  practice_id uuid REFERENCES practices(id),          -- NULL = built-in role
  code        user_role NOT NULL,
  label       text NOT NULL,
  permissions jsonb NOT NULL DEFAULT '[]'::jsonb,
  created_at  timestamptz NOT NULL DEFAULT now(),
  updated_at  timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE user_roles (
  practice_id uuid NOT NULL REFERENCES practices(id),
  user_id     uuid NOT NULL REFERENCES users(id),
  role_id     uuid NOT NULL REFERENCES roles(id),
  created_at  timestamptz NOT NULL DEFAULT now(),
  updated_at  timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (user_id, role_id)
);

-- =====================================================================================
-- 2. Providers & credentialing
-- =====================================================================================
CREATE TABLE providers (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  practice_id   uuid NOT NULL REFERENCES practices(id),
  user_id       uuid REFERENCES users(id),            -- set when the provider creates an account
  first_name    text NOT NULL,
  last_name     text NOT NULL,
  degree        text NOT NULL,                        -- MD, DO, CRNA
  role          provider_role NOT NULL,
  specialty     text,
  npi           char(10),
  email         citext NOT NULL,
  phone         text,
  color_hex     char(7) NOT NULL CHECK (color_hex ~ '^#[0-9A-Fa-f]{6}$'),  -- scheduler color (any color; text color derived for AA)
  active        boolean NOT NULL DEFAULT true,        -- deactivated providers cannot sign or be scheduled
  locked        boolean NOT NULL DEFAULT false,       -- 5 wrong PINs
  pin_failures  int NOT NULL DEFAULT 0,
  locked_at     timestamptz,
  deactivated_at timestamptz, deactivated_by uuid REFERENCES users(id), deactivation_reason text,
  is_medical_director boolean NOT NULL DEFAULT false,
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now(),
  UNIQUE (practice_id, email)
);

CREATE TABLE credential_applications (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  practice_id   uuid NOT NULL REFERENCES practices(id),
  provider_id   uuid NOT NULL REFERENCES providers(id),
  status        cred_status NOT NULL DEFAULT 'Invited',
  license_number text, license_state char(2), license_expires date,
  dea_number    text,                                 -- sensitive
  board_certification text,
  malpractice_carrier text,
  privileges_requested text,
  answers       jsonb NOT NULL DEFAULT '{}'::jsonb,   -- full Membership & Privileges Application form values
  submitted_at  timestamptz,
  decided_at    timestamptz, decided_by uuid REFERENCES users(id),
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE credential_status_history (            -- append-only
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  practice_id   uuid NOT NULL REFERENCES practices(id),
  application_id uuid NOT NULL REFERENCES credential_applications(id),
  status        text NOT NULL,
  note          text,
  by_user_id    uuid REFERENCES users(id), by_name text NOT NULL,
  at            timestamptz NOT NULL DEFAULT now(),
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE credential_documents (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  practice_id   uuid NOT NULL REFERENCES practices(id),
  application_id uuid NOT NULL REFERENCES credential_applications(id),
  category      text NOT NULL,                        -- License, DEA, Board, Malpractice COI, CV ...
  file_name     text NOT NULL,
  storage_key   text NOT NULL,                        -- object storage (S3) key, never the bytes
  mime          text,
  expires_on    date,
  verified_at   timestamptz, verified_by uuid REFERENCES users(id),
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now()
);

-- =====================================================================================
-- 3. Invitations, one-time tokens, outbound email
-- =====================================================================================
CREATE TABLE invitations (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  practice_id   uuid NOT NULL REFERENCES practices(id),
  provider_id   uuid NOT NULL REFERENCES providers(id),
  kind          email_kind NOT NULL,
  to_email      citext NOT NULL,
  to_name       text,
  subject       text NOT NULL,
  body          text NOT NULL,
  transport     text NOT NULL DEFAULT 'smtp',        -- 'simulated' in the test build
  is_resend     boolean NOT NULL DEFAULT false,
  sent_at       timestamptz,
  sent_by       uuid REFERENCES users(id),
  provider_message_id text,                           -- ESP id for delivery tracking
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE invite_tokens (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  practice_id   uuid NOT NULL REFERENCES practices(id),
  invitation_id uuid NOT NULL REFERENCES invitations(id),
  provider_id   uuid NOT NULL REFERENCES providers(id),
  purpose       invite_purpose NOT NULL,
  token_hash    bytea NOT NULL UNIQUE,                -- sha256(token); the raw token only exists in the email link
  issued_at     timestamptz NOT NULL DEFAULT now(),
  expires_at    timestamptz NOT NULL,
  used_at       timestamptz,
  revoked_at    timestamptz,
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now()
);

-- =====================================================================================
-- 4. Facility: rooms, stations
-- =====================================================================================
CREATE TABLE rooms (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  practice_id   uuid NOT NULL REFERENCES practices(id),
  name          text NOT NULL,                        -- 'OR #1', 'Minor Proc Bay', 'PACU Bay 1'
  kind          text NOT NULL DEFAULT 'OR',           -- OR | procedure | preop | pacu
  visible_in_schedule boolean NOT NULL DEFAULT true,
  sort_order    int NOT NULL DEFAULT 0,
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now(),
  UNIQUE (practice_id, name)
);

CREATE TABLE stations (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  practice_id   uuid NOT NULL REFERENCES practices(id),
  key           text NOT NULL,                        -- patientPortal, frontOffice, nursing, anesthesia, surgeon, orTeam, pacu, caseRecord
  label         text NOT NULL,
  enabled       boolean NOT NULL DEFAULT true,
  config        jsonb NOT NULL DEFAULT '{}'::jsonb,   -- vityls:station-config:v1
  sort_order    int NOT NULL DEFAULT 0,
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now(),
  UNIQUE (practice_id, key)
);

-- =====================================================================================
-- 5. Patients, cases/encounters, appointments
-- =====================================================================================
CREATE TABLE patients (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  practice_id   uuid NOT NULL REFERENCES practices(id),
  mrn           text NOT NULL,                        -- PHI
  first_name    text NOT NULL,                        -- PHI
  last_name     text NOT NULL,                        -- PHI
  dob           date NOT NULL,                        -- PHI
  sex           text,                                 -- PHI
  phone         text,                                 -- PHI
  email         citext,                               -- PHI
  address       jsonb,                                -- PHI
  emergency_contact jsonb,                            -- PHI
  insurance     jsonb,                                -- PHI (payer, member id, group)
  id_card_key   text, insurance_front_key text, insurance_back_key text,   -- PHI (object storage keys)
  allergies     jsonb NOT NULL DEFAULT '[]'::jsonb,   -- PHI (chart-level, confirmed list)
  portal_user_id uuid REFERENCES users(id),
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now(),
  UNIQUE (practice_id, mrn)
);

CREATE TABLE cases (                                  -- surgical encounter
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  practice_id   uuid NOT NULL REFERENCES practices(id),
  patient_id    uuid NOT NULL REFERENCES patients(id),
  date_of_service date NOT NULL,                      -- PHI (with patient)
  scheduled_start time NOT NULL,
  estimated_minutes int NOT NULL DEFAULT 60,
  room_id       uuid REFERENCES rooms(id),
  surgeon_id    uuid REFERENCES providers(id),
  anesthesiologist_id uuid REFERENCES providers(id),
  procedure     text NOT NULL,                        -- PHI
  cpt_codes     text[],                               -- PHI
  anesthesia_type text,
  payment_type  text,                                 -- Self-Pay / Insurance ...
  stage         case_stage NOT NULL DEFAULT 'scheduled',
  tone          case_tone,                            -- derived dashboard color, cached
  check_in_status text,
  arrival_at    timestamptz,
  workflow      jsonb NOT NULL DEFAULT '{}'::jsonb,   -- encounterWorkflow (current station, timestamps)
  notes         text,                                 -- PHI
  cancelled_at  timestamptz, cancel_reason text,
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX cases_practice_dos ON cases (practice_id, date_of_service);

CREATE TABLE appointments (                           -- scheduler blocks (cases and block time)
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  practice_id   uuid NOT NULL REFERENCES practices(id),
  case_id       uuid REFERENCES cases(id),            -- NULL for block time
  room_id       uuid NOT NULL REFERENCES rooms(id),
  starts_at     timestamptz NOT NULL,
  ends_at       timestamptz NOT NULL CHECK (ends_at > starts_at),
  is_block      boolean NOT NULL DEFAULT false,
  block_title   text,
  block_provider_id uuid REFERENCES providers(id),
  badge_style   text,
  recurrence    jsonb,                                -- days-of-week block patterns
  notes         text,                                 -- PHI when case_id is set
  created_by    uuid REFERENCES users(id),
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX appointments_room_time ON appointments (practice_id, room_id, starts_at);

CREATE TABLE station_verifications (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  practice_id   uuid NOT NULL REFERENCES practices(id),
  case_id       uuid NOT NULL REFERENCES cases(id),
  station_key   text NOT NULL,
  verified_by   uuid REFERENCES users(id), verified_by_name text NOT NULL, verified_role text NOT NULL,
  verified_at   timestamptz NOT NULL DEFAULT now(),
  exception_reason text,                              -- "advance with open items"
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now(),
  UNIQUE (case_id, station_key)
);

CREATE TABLE case_events (                            -- OR event-time bar (in room, incision, close, out)
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  practice_id   uuid NOT NULL REFERENCES practices(id),
  case_id       uuid NOT NULL REFERENCES cases(id),
  event         text NOT NULL,
  at            timestamptz NOT NULL,
  recorded_by   uuid REFERENCES users(id),
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now()
);

-- =====================================================================================
-- 6. Form templates, versions, signer configuration, station assignment (My Forms)
-- =====================================================================================
CREATE TABLE form_templates (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  practice_id   uuid REFERENCES practices(id),        -- NULL = Vityls library template
  file_key      text NOT NULL,                        -- 'Nursing_Admission.html'
  title         text NOT NULL,
  category      text, audience text, stage text,
  is_custom     boolean NOT NULL DEFAULT false,
  current_version_id uuid,
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now(),
  UNIQUE (practice_id, file_key)
);

CREATE TABLE form_template_versions (                 -- immutable once published
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  practice_id   uuid REFERENCES practices(id),
  template_id   uuid NOT NULL REFERENCES form_templates(id),
  version       int NOT NULL,
  html          text NOT NULL,                        -- no signature fields (signatures come from signer config)
  schema        jsonb NOT NULL DEFAULT '[]'::jsonb,   -- Form Studio field schema (no 'signature' type)
  rules         jsonb NOT NULL DEFAULT '{}'::jsonb,   -- defaults, normals, calcs, required
  published_at  timestamptz, published_by uuid REFERENCES users(id),
  change_note   text,
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now(),
  UNIQUE (template_id, version)
);
ALTER TABLE form_templates ADD CONSTRAINT form_templates_current_fk FOREIGN KEY (current_version_id) REFERENCES form_template_versions(id);

CREATE TABLE form_station_assignments (               -- My Forms: which station collects / reviews
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  practice_id   uuid NOT NULL REFERENCES practices(id),
  template_id   uuid NOT NULL REFERENCES form_templates(id),
  station_key   text NOT NULL,
  required      boolean NOT NULL DEFAULT true,
  review_stations text[] NOT NULL DEFAULT '{}',
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now(),
  UNIQUE (template_id, station_key)
);

CREATE TABLE signer_configs (                         -- Form Studio -> Signers step
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  practice_id   uuid NOT NULL REFERENCES practices(id),
  template_id   uuid NOT NULL REFERENCES form_templates(id),
  sequential    boolean NOT NULL DEFAULT false,
  updated_by    uuid REFERENCES users(id),
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now(),
  UNIQUE (template_id)
);

CREATE TABLE signer_slots (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  practice_id   uuid NOT NULL REFERENCES practices(id),
  signer_config_id uuid NOT NULL REFERENCES signer_configs(id) ON DELETE CASCADE,
  slot_key      text NOT NULL,                        -- stable id kept so old signatures still match
  role          text NOT NULL,
  label         text NOT NULL,
  attestation   text NOT NULL,
  required      boolean NOT NULL DEFAULT true,
  is_patient    boolean NOT NULL DEFAULT false,
  sort_order    int NOT NULL DEFAULT 0,
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now(),
  UNIQUE (signer_config_id, slot_key)
);

CREATE TABLE signer_initials_pages (                  -- multi-page packets (Admission): initials by page, from signer setup
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  practice_id   uuid NOT NULL REFERENCES practices(id),
  signer_config_id uuid NOT NULL REFERENCES signer_configs(id) ON DELETE CASCADE,
  page_index    int NOT NULL,
  page_title    text NOT NULL,
  slot_key      text NOT NULL,
  statements    text[] NOT NULL,                      -- one initials box per clause line
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now()
);

-- =====================================================================================
-- 7. Form instances, values with provenance, facts (carry-forward), signatures, addenda
-- =====================================================================================
CREATE TABLE form_instances (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  practice_id   uuid NOT NULL REFERENCES practices(id),
  case_id       uuid NOT NULL REFERENCES cases(id),
  template_version_id uuid NOT NULL REFERENCES form_template_versions(id),
  file_key      text NOT NULL,
  status        form_status NOT NULL DEFAULT 'not-started',
  locked_at     timestamptz,
  locked_hash   text,                                 -- sha256 of canonical values at lock
  updated_by    uuid REFERENCES users(id),
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now(),
  UNIQUE (case_id, file_key)
);

CREATE TABLE form_values (                            -- current value per stable field key
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  practice_id   uuid NOT NULL REFERENCES practices(id),
  form_instance_id uuid NOT NULL REFERENCES form_instances(id),
  field_key     text NOT NULL,                        -- stable key, never position
  field_label   text,
  value         jsonb,                                -- PHI (string | boolean)
  source        value_source NOT NULL,                -- provenance kind
  source_label  text,                                 -- "Nursing Admission · Pre-op RN · 07:14"
  source_form   text, source_station text,
  entered_by    uuid REFERENCES users(id), entered_by_name text,
  entered_at    timestamptz NOT NULL DEFAULT now(),
  needs_confirm boolean NOT NULL DEFAULT false,
  confirmed_by  uuid REFERENCES users(id), confirmed_at timestamptz,
  voice_snippet text,                                 -- PHI
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now(),
  UNIQUE (form_instance_id, field_key)
);

CREATE TABLE form_value_history (                     -- append-only change log of form_values
  id            bigserial PRIMARY KEY,
  practice_id   uuid NOT NULL REFERENCES practices(id),
  form_instance_id uuid NOT NULL REFERENCES form_instances(id),
  field_key     text NOT NULL,
  old_value     jsonb, new_value jsonb,               -- PHI
  source        value_source NOT NULL,
  changed_by    uuid REFERENCES users(id),
  changed_at    timestamptz NOT NULL DEFAULT now(),
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE case_facts (                             -- carry-forward store (allergies, NPO, escort, vitals, PMH)
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  practice_id   uuid NOT NULL REFERENCES practices(id),
  case_id       uuid NOT NULL REFERENCES cases(id),
  concept       text NOT NULL,                        -- e.g. 'allergies', 'escort.name'
  value         jsonb NOT NULL,                       -- PHI
  source        value_source NOT NULL,
  source_form   text, source_station text, source_label text,
  entered_by    uuid REFERENCES users(id),
  entered_at    timestamptz NOT NULL DEFAULT now(),
  confirmed     boolean NOT NULL DEFAULT false,
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now(),
  UNIQUE (case_id, concept)
);

CREATE TABLE signatures (                             -- append-only; made only in the multi-signer panel
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  practice_id   uuid NOT NULL REFERENCES practices(id),
  form_instance_id uuid NOT NULL REFERENCES form_instances(id),
  slot_key      text NOT NULL,
  role          text NOT NULL,
  signer_user_id uuid REFERENCES users(id),           -- NULL for patient / witness without account
  signer_provider_id uuid REFERENCES providers(id),
  signer_name   text NOT NULL,                        -- PHI when the signer is the patient
  credentials   text,
  attestation   text NOT NULL,
  method        signature_method NOT NULL,
  image_key     text,                                 -- PHI: drawn signature image in object storage
  initials      jsonb NOT NULL DEFAULT '[]'::jsonb,   -- [{page, value}] per-page initials (PHI for patient)
  pin_verified  boolean NOT NULL DEFAULT false,       -- provider PIN checked server-side
  content_hash  text NOT NULL,                        -- sha256 of form values at signing
  signed_at     timestamptz NOT NULL DEFAULT now(),   -- server time
  ip_address    inet, user_agent text,
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now(),
  UNIQUE (form_instance_id, slot_key)
);

CREATE TABLE addenda (                                -- append-only; corrections after lock
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  practice_id   uuid NOT NULL REFERENCES practices(id),
  form_instance_id uuid NOT NULL REFERENCES form_instances(id),
  by_user_id    uuid REFERENCES users(id), by_name text NOT NULL, role text NOT NULL,
  reason        text NOT NULL,
  changes       jsonb NOT NULL,                       -- PHI [{key,label,from,to}]
  note          text,                                 -- PHI
  signed        boolean NOT NULL DEFAULT false,
  signature_id  uuid REFERENCES signatures(id),
  at            timestamptz NOT NULL DEFAULT now(),
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now()
);

-- =====================================================================================
-- 8. Clearance documents, summaries, alerts / reviews
-- =====================================================================================
CREATE TABLE clearance_documents (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  practice_id   uuid NOT NULL REFERENCES practices(id),
  case_id       uuid NOT NULL REFERENCES cases(id),
  doc_type      text NOT NULL,                        -- Labs, EKG, H&P, Clearance letter, Imaging ...
  title         text NOT NULL,                        -- PHI
  source        text,                                 -- sending office
  doc_date      date,
  received_at   timestamptz NOT NULL DEFAULT now(),
  received_by   uuid REFERENCES users(id),
  file_name     text, mime text,
  storage_key   text,                                 -- PHI: object storage (never base64 in the DB)
  extracted_text text,                                -- PHI
  status        doc_status NOT NULL DEFAULT 'Received',
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE clearance_summaries (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  practice_id   uuid NOT NULL REFERENCES practices(id),
  case_id       uuid NOT NULL REFERENCES cases(id),
  engine        text NOT NULL, engine_kind text NOT NULL CHECK (engine_kind IN ('rule-based','ai')),
  narrative     jsonb NOT NULL,                       -- PHI
  docs_reviewed uuid[] NOT NULL DEFAULT '{}',
  generated_at  timestamptz NOT NULL DEFAULT now(),
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE clinical_alerts (                        -- abnormal results, allergies, missing items, concerns
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  practice_id   uuid NOT NULL REFERENCES practices(id),
  case_id       uuid NOT NULL REFERENCES cases(id),
  summary_id    uuid REFERENCES clearance_summaries(id),
  category      text NOT NULL CHECK (category IN ('history','allergy','abnormal','missing','concern')),
  severity      alert_severity NOT NULL,
  text          text NOT NULL,                        -- PHI
  document_id   uuid REFERENCES clearance_documents(id),
  resolved_at   timestamptz, resolved_by uuid REFERENCES users(id),
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE clearance_reviews (                      -- "Reviewed" then "Cleared" (drives dashboard color)
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  practice_id   uuid NOT NULL REFERENCES practices(id),
  case_id       uuid NOT NULL REFERENCES cases(id),
  kind          text NOT NULL CHECK (kind IN ('review','clear')),
  by_user_id    uuid REFERENCES users(id), by_name text NOT NULL,
  note          text,                                 -- PHI
  at            timestamptz NOT NULL DEFAULT now(),
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now()
);

-- =====================================================================================
-- 9. Billing: fee schedules, invoices, payments
-- =====================================================================================
CREATE TABLE fee_schedules (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  practice_id   uuid NOT NULL REFERENCES practices(id),
  name          text NOT NULL,
  match_kind    fee_match_kind NOT NULL DEFAULT 'default',
  match_value   text,
  facility_base numeric(12,2) NOT NULL, facility_included_min int NOT NULL, facility_per_increment numeric(12,2) NOT NULL, facility_increment_min int NOT NULL,
  anesthesia_base numeric(12,2) NOT NULL, anesthesia_included_min int NOT NULL, anesthesia_per_increment numeric(12,2) NOT NULL, anesthesia_increment_min int NOT NULL,
  surgeon_fee   numeric(12,2) NOT NULL DEFAULT 0,
  effective_from date NOT NULL DEFAULT current_date,
  effective_to  date,
  notes         text,
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE invoices (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  practice_id   uuid NOT NULL REFERENCES practices(id),
  number        text NOT NULL,
  case_id       uuid NOT NULL REFERENCES cases(id),
  patient_id    uuid NOT NULL REFERENCES patients(id),
  fee_schedule_id uuid NOT NULL REFERENCES fee_schedules(id),
  schedule_name text NOT NULL,                        -- snapshot
  facility_minutes int NOT NULL, anesthesia_minutes int NOT NULL,
  lines         jsonb NOT NULL,                       -- PHI (procedure detail) [{label, detail, amount}]
  total         numeric(12,2) NOT NULL,
  paid          numeric(12,2) NOT NULL DEFAULT 0,
  status        invoice_status NOT NULL DEFAULT 'Draft',
  override_by   uuid REFERENCES users(id),            -- manager override (issued before eligibility)
  override_role text, override_reason text, override_at timestamptz, override_unmet text[],
  created_by    uuid REFERENCES users(id),
  sent_at       timestamptz,
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now(),
  UNIQUE (practice_id, number)
);

CREATE TABLE payments (                               -- append-only (refunds are negative rows)
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  practice_id   uuid NOT NULL REFERENCES practices(id),
  invoice_id    uuid NOT NULL REFERENCES invoices(id),
  amount        numeric(12,2) NOT NULL,
  method        text NOT NULL,                        -- card, cash, check, ACH
  processor_ref text,                                 -- tokenized; never store PAN/CVV
  received_at   timestamptz NOT NULL DEFAULT now(),
  received_by   uuid REFERENCES users(id),
  note          text,
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now()
);

-- =====================================================================================
-- 10. Append-only audit log
-- =====================================================================================
CREATE TABLE audit_log (
  id            bigserial PRIMARY KEY,
  practice_id   uuid NOT NULL REFERENCES practices(id),
  at            timestamptz NOT NULL DEFAULT now(),   -- server time only
  user_id       uuid REFERENCES users(id),
  user_name     text NOT NULL,
  role          text NOT NULL,
  case_id       uuid REFERENCES cases(id),            -- NULL for practice-level (provider.* / settings) events
  entity_type   text,                                 -- 'provider','form','invoice','case'
  entity_id     uuid,
  action        text NOT NULL,                        -- form.open|form.save|form.sign|form.lock|form.addendum|voice.*|station.verify|event.time|
                                                      -- fact.confirm|invoice.save|invoice.override|provider.invite|provider.application|
                                                      -- provider.account|provider.pin-set|provider.pin-reset|provider.pin-failure|
                                                      -- provider.lock|provider.unlock|provider.deactivate|provider.reactivate
  form_key      text,
  detail        text NOT NULL,                        -- may contain PHI
  ip_address    inet,
  user_agent    text,
  prev_hash     bytea,                                -- hash chain for tamper evidence
  row_hash      bytea,
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX audit_case ON audit_log (practice_id, case_id, at);
CREATE INDEX audit_action ON audit_log (practice_id, action, at);

-- hash chain: row_hash = sha256(prev_hash || canonical row)
CREATE OR REPLACE FUNCTION audit_chain() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE p bytea;
BEGIN
  SELECT row_hash INTO p FROM audit_log WHERE practice_id = NEW.practice_id ORDER BY id DESC LIMIT 1;
  NEW.at := now(); NEW.prev_hash := p;
  NEW.row_hash := digest(coalesce(p,''::bytea) || convert_to(concat_ws('|', NEW.practice_id, NEW.at, NEW.user_name, NEW.role, NEW.case_id, NEW.action, NEW.form_key, NEW.detail), 'UTF8'), 'sha256');
  RETURN NEW;
END $$;
CREATE TRIGGER audit_log_chain BEFORE INSERT ON audit_log FOR EACH ROW EXECUTE FUNCTION audit_chain();

-- =====================================================================================
-- Triggers: updated_at everywhere, append-only tables
-- =====================================================================================
DO $$
DECLARE t text;
BEGIN
  FOR t IN SELECT table_name FROM information_schema.columns
           WHERE table_schema = 'public' AND column_name = 'updated_at'
  LOOP
    EXECUTE format('CREATE TRIGGER %I_updated BEFORE UPDATE ON %I FOR EACH ROW EXECUTE FUNCTION set_updated_at()', t, t);
  END LOOP;
  FOREACH t IN ARRAY ARRAY['audit_log','signatures','addenda','form_value_history','payments','credential_status_history']
  LOOP
    EXECUTE format('CREATE TRIGGER %I_append_only BEFORE UPDATE OR DELETE ON %I FOR EACH ROW EXECUTE FUNCTION forbid_update_delete()', t, t);
  END LOOP;
END $$;
-- Also: REVOKE UPDATE, DELETE, TRUNCATE ON audit_log, signatures, addenda, form_value_history, payments FROM vityls_api;

-- =====================================================================================
-- Row-level security: one policy per tenant table
-- =====================================================================================
DO $$
DECLARE t text;
BEGIN
  FOR t IN SELECT c.table_name FROM information_schema.columns c
           JOIN information_schema.tables x ON x.table_name = c.table_name AND x.table_schema = c.table_schema AND x.table_type = 'BASE TABLE'
           WHERE c.table_schema = 'public' AND c.column_name = 'practice_id'
  LOOP
    EXECUTE format('ALTER TABLE %I ENABLE ROW LEVEL SECURITY', t);
    EXECUTE format('ALTER TABLE %I FORCE ROW LEVEL SECURITY', t);
    IF t IN ('roles','form_templates','form_template_versions') THEN
      -- library rows (practice_id IS NULL) are readable by every tenant, writable by none
      EXECUTE format('CREATE POLICY %I_read ON %I FOR SELECT USING (practice_id IS NULL OR practice_id = current_practice())', t, t);
      EXECUTE format('CREATE POLICY %I_write ON %I FOR ALL USING (practice_id = current_practice()) WITH CHECK (practice_id = current_practice())', t, t);
    ELSE
      EXECUTE format('CREATE POLICY %I_tenant ON %I FOR ALL USING (practice_id = current_practice()) WITH CHECK (practice_id = current_practice())', t, t);
    END IF;
  END LOOP;
END $$;
-- practices itself: a tenant sees only its own row
ALTER TABLE practices ENABLE ROW LEVEL SECURITY;
CREATE POLICY practices_self ON practices FOR SELECT USING (id = current_practice());

-- =====================================================================================
-- PHI flags (machine-readable)
-- =====================================================================================
COMMENT ON COLUMN patients.mrn               IS 'PHI: medical record number';
COMMENT ON COLUMN patients.first_name        IS 'PHI: name';
COMMENT ON COLUMN patients.last_name         IS 'PHI: name';
COMMENT ON COLUMN patients.dob               IS 'PHI: date of birth';
COMMENT ON COLUMN patients.sex               IS 'PHI: demographic';
COMMENT ON COLUMN patients.phone             IS 'PHI: contact';
COMMENT ON COLUMN patients.email             IS 'PHI: contact';
COMMENT ON COLUMN patients.address           IS 'PHI: address';
COMMENT ON COLUMN patients.emergency_contact IS 'PHI: contact';
COMMENT ON COLUMN patients.insurance         IS 'PHI: insurance identifiers';
COMMENT ON COLUMN patients.id_card_key       IS 'PHI: photo ID image';
COMMENT ON COLUMN patients.insurance_front_key IS 'PHI: insurance card image';
COMMENT ON COLUMN patients.insurance_back_key  IS 'PHI: insurance card image';
COMMENT ON COLUMN patients.allergies         IS 'PHI: clinical';
COMMENT ON COLUMN cases.date_of_service      IS 'PHI: date of service';
COMMENT ON COLUMN cases.procedure            IS 'PHI: clinical';
COMMENT ON COLUMN cases.cpt_codes            IS 'PHI: clinical';
COMMENT ON COLUMN cases.notes                IS 'PHI: clinical';
COMMENT ON COLUMN appointments.notes         IS 'PHI: when linked to a case';
COMMENT ON COLUMN form_values.value          IS 'PHI: clinical form content';
COMMENT ON COLUMN form_values.voice_snippet  IS 'PHI: voice transcript';
COMMENT ON COLUMN form_value_history.old_value IS 'PHI: clinical form content';
COMMENT ON COLUMN form_value_history.new_value IS 'PHI: clinical form content';
COMMENT ON COLUMN case_facts.value           IS 'PHI: clinical';
COMMENT ON COLUMN signatures.signer_name     IS 'PHI: when signer is the patient';
COMMENT ON COLUMN signatures.image_key       IS 'PHI: signature image';
COMMENT ON COLUMN signatures.initials        IS 'PHI: patient initials';
COMMENT ON COLUMN addenda.changes            IS 'PHI: clinical';
COMMENT ON COLUMN addenda.note               IS 'PHI: clinical';
COMMENT ON COLUMN clearance_documents.title  IS 'PHI: clinical';
COMMENT ON COLUMN clearance_documents.storage_key IS 'PHI: clinical document';
COMMENT ON COLUMN clearance_documents.extracted_text IS 'PHI: clinical';
COMMENT ON COLUMN clearance_summaries.narrative IS 'PHI: clinical';
COMMENT ON COLUMN clinical_alerts.text       IS 'PHI: clinical';
COMMENT ON COLUMN clearance_reviews.note     IS 'PHI: clinical';
COMMENT ON COLUMN invoices.lines             IS 'PHI: procedure on invoice';
COMMENT ON COLUMN audit_log.detail           IS 'PHI: may reference patient data';

CREATE VIEW phi_columns AS
  SELECT c.relname AS table_name, a.attname AS column_name, d.description AS phi_note
  FROM pg_description d
  JOIN pg_class c      ON c.oid = d.objoid AND d.classoid = 'pg_class'::regclass
  JOIN pg_namespace n  ON n.oid = c.relnamespace AND n.nspname = 'public'
  JOIN pg_attribute a  ON a.attrelid = c.oid AND a.attnum = d.objsubid
  WHERE d.description LIKE 'PHI:%';
-- end of schema
