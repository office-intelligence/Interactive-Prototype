> **SUPERSEDED FOR RUNTIME CHECK-IN (2026-09-27):** Any legacy form-based Arrival/Office Check-In instructions in this document are no longer active. All day-of-surgery Check-In entry points now open the unified V3 Pre-Op Nursing clinical review. Practice documents/intake templates remain separate document capabilities.

# Frontend Freeze — Database Handoff
The ASC.Vityls UI frontend is considered frozen for database implementation as of September 14, 2026, subject only to defects discovered during backend integration. Henry should treat the existing UI state shapes and component flows as the frontend contract and map persistence/API services behind them rather than changing user-facing workflow semantics.
