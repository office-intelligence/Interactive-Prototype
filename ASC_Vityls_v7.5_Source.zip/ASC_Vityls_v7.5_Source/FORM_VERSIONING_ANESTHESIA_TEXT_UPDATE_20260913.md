# Form Versioning + Anesthesia Consent Editable Text Update — 2026-09-13

## Practice form revision behavior

The Form Studio customization flow now reopens the practice's latest customized version rather than resetting the user to the original Vityls master template.

- First customization save creates practice revision **v1.0**.
- Each later save creates the next minor practice revision (**v1.1, v1.2, ...**).
- Earlier practice revisions are retained in local test history.
- The protected Vityls Standard master remains unchanged and available as the source template.
- The editor shows the current practice version and retained revision count.

### Production database boundary

Do not overwrite a published form version in place. Recommended production model:

`FormDefinition` -> `FormVersion` -> `PracticeFormConfiguration`

Each published/edit save should create a new immutable `FormVersion`, with the practice configuration pointing to the current active version. Historical completed `FormInstance` records must remain pinned to the exact version that was presented/signed at that time.

Suggested FormVersion fields include:
- FormVersionId
- FormDefinitionId
- TenantId / PracticeId as applicable
- VersionNumber
- HtmlSnapshot / SchemaSnapshot reference
- CreatedAt
- CreatedByUserId
- EffectiveAt / PublishedAt
- SupersedesFormVersionId
- Status (Draft / Active / Superseded / Retired)

## Anesthesia Consent

The Anesthesia Consent template now exposes the large practice-specific text blocks in Form Studio:

1. **Risks and complications**
2. **Informed consent language**

Both are displayed as large editable text areas in the Form Studio editor. In the live patient/staff form they are read-only policy/consent language so a patient cannot alter the facility's approved text.

The standard freehand patient and anesthesia-provider signature fields remain unchanged.
