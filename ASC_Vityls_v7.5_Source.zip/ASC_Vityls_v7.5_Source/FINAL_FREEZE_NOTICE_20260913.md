> **SUPERSEDED FOR RUNTIME CHECK-IN (2026-09-27):** Any legacy form-based Arrival/Office Check-In instructions in this document are no longer active. All day-of-surgery Check-In entry points now open the unified V3 Pre-Op Nursing clinical review. Practice documents/intake templates remain separate document capabilities.

# Vityls Frontend Freeze — Henry Handoff

Date: 2026-09-13

This package is the frozen frontend baseline for database/table/API integration. No further frontend revisions are intended until the database schema, persistence, authentication, and API connections are completed and integration testing begins.

## Final workflow decisions
- Patient Chart **Intake Forms** is a Patient Portal distribution/status area only. It has no Open button.
- Forms unfinished by the patient are resumed in **Arrival & Check-in**.
- Arrival & Check-in receives the union of Patient Portal + Front Office form assignments, deduplicated by form ID.
- HTML and uploaded PDF forms use the same Form Studio workflow-assignment model.
- Form Studio is the canonical form-definition workflow. Legacy intake/nursing seed libraries are not runtime sources.
- Practice form edits create a new practice version while historical form instances remain pinned to the version actually used.
- Universal freehand signatures remain the standard signature component where the form/PDF contains a signature requirement.

## Clean-state decisions
- No seeded patients, appointments, messages, claims, invoices, tasks, billing credits, portal records, nursing packets, surgical episodes, or patient documents are loaded at runtime.
- The default practice is an unconfigured `New Practice` shell with no contact/provider/scheduling data.
- Patient Chart displays an empty-state/Add Patient prompt until real patient data is created or loaded.
- Legacy hard-coded Intake Form and Nursing Form runtime arrays are empty.
- Old PDF/intake packet arrays in the patient chart are empty and are not the workflow source.
- Practice administration provider/user/document repository seeds are empty.
- Billing claim/invoice/implant seeds and financial sample balances are empty/zero.
- Patient form answer fields do not ship with sample patient answers or pre-checked choices. Practice-editable policy/consent language remains as template content.
- References to Summit Surgical Center and the project owners were removed from the delivered source/templates.

## Database boundary
Henry should use the included `HENRY_DATABASE_BOUNDARY_REVIEW_20260913.md` and `HENRY_FINAL_FRONTEND_HANDOFF_20260913.md` as the implementation boundary. In particular, do not create independent IntakeForm/PdfForm/NursingForm persistence models; use versioned forms + workflow assignments + patient form requests/instances/responses/signatures.

## Validation performed
- Reference form catalog regeneration: 27 HTML templates detected.
- TypeScript/TSX syntax transpilation: passed for all source TS/TSX files (excluding declaration files).
- Full Vite production build could not be completed in this environment because the Vite executable is not present in the recovered dependency set. Perform a clean `npm install`/`npm ci` and `npm run build` before merge.
