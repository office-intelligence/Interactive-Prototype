<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://ai.google.dev/static/site-assets/images/share-ais-513315318.png" />
</div>

# Run and deploy your AI Studio app

This contains everything you need to run your app locally.

View your app in AI Studio: https://ai.studio/apps/7feb95ec-e7d5-4538-a618-6ae6024b8209

## Run Locally

**Prerequisites:**  Node.js


1. Install dependencies:
   `npm install`
2. Set the `GEMINI_API_KEY` in [.env.local](.env.local) to your Gemini API key
3. Run the app:
   `npm run dev`

## August 22, 2026 — Gate Workflow + Clinical Form Studio Update

This prototype update adds:
- Front Desk arrival/check-in gate with Nightingale arrival review
- Complete Check-In & Notify Nursing handoff
- Ready for Pre-Op / Pre-Op Nursing journey state and current owner tracking
- Today's Patients Pre-Op Queue and Accept Patient action
- Automatic opening of Nursing workflow on acceptance
- Carried-forward allergy and medication snapshot with verify/update UX
- Case Record ownership/handoff visibility
- Administration > Clinical Form Studio
- Multispecialty / Plastic Surgery / Orthopedics / Ophthalmology customization test
- Existing form crosswalk with covered / partial / gap findings
- PATIENT_GATE_WORKFLOW.md and FORM_ENGINE_QUADA_CROSSWALK.md


## 2026-09-15 final pre-database revision
See `FINAL_PROVIDER_MEDICAL_DIRECTOR_HANDOFF_20260915.md` for the Medical Director privileges approval workflow, surgeon account activation boundary, provider status model, and final Day/Week scheduler time-column rule.
