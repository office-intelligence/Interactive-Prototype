# Vityls final patient chart & authentication update — 2026-10-02

This test build incorporates the final approved patient-chart source supplied on 2026-10-02 as the ASC patient-chart direction, while preserving its MED.Vityls longitudinal design language.

Changes in this build:
- Replaced the interim simplified patient chart with the approved longitudinal chart pattern: patient identity/safety strip, current encounter + Nightingale brief, Health Journey/care pathway, Nightingale coordinator, and appointment history.
- Day-of-surgery station workspaces remain separate from the longitudinal chart.
- Removed the duplicate patient name from the dark-green station header; the patient remains clearly identified in the Nightingale Station Brief.
- Evidence Forms continue to be generated from active forms assigned to the current station.
- Added a Nightingale Attention treatment for forms likely to require special risk review/attestation (including MH/VTE, anesthesia, consent, medication/allergy/risk-related forms). Backend rules should replace this title-based evaluation heuristic.
- Vityls Standard Signature / Authentication is the single visible authentication section at the bottom of the dedicated full-page form experience.
- Legacy template signature sections are suppressed at runtime in the test build so users do not see two competing signature systems. Production normalization should remove legacy signature markup from the canonical templates entirely.
- Full-page form workflow remains: Station → Open Form → Save / Print / Authenticate → Close → return to Station.

This remains a pre-database frontend evaluation build. Local browser persistence is used for form testing until Henry connects the database/API layer.
