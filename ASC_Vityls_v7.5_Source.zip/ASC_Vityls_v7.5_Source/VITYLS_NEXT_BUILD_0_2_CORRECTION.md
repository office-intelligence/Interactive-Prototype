# ASC.Vityls Next — Build 0.2 Integration Correction

This build corrects the Build 0.1 integration error.

## Corrected application behavior
- Dashboard is restored as the default landing workspace and the bottom Dashboard button opens Dashboard.
- Existing Dashboard case-card Check-In remains the entry point for Front Desk Check-In.
- Completing Front Desk Check-In now opens the V3 Pre-Op Nursing one-page clinical review.
- Patient Chart includes an explicit **Open Pre-Op Nursing Clinical Review** button.
- The Patient Chart Surgical Journey Nursing step opens the same V3 React workspace.

## V3 content carried into React
The React nursing workspace now includes the complete V3 structure:
- Everything We Know About This Patient / Nightingale clinical-review banner
- Allergies with clarification and add/edit
- Medication reconciliation + add medication
- Blood thinner and GLP-1/GIP screening
- Significant medical history + interval change
- Past surgery and anesthesia history
- Responsible adult/contact/home care
- NPO and day-of-surgery information
- MH/VTE review with calculated VTE total/risk and MH screen result
- Today's RN observations/vitals and focused assessment
- Preparation/readiness including H&P, diagnostics, surgical consent, anesthesia consent, site marking, dentures, jewelry/contacts, IV
- Open exceptions/handoff
- Scoped RN attestation and Advance to Anesthesia control
- Right-rail case readiness / Nightingale context
- Edit modal with update source/provenance selection

## Architecture
The clinical workspace continues to read through the Vityls semantic API boundary. This build is still a development build; the mock adapter is intended to be replaced by Henry's development API without rewriting the clinical workspace.

## Validation note
Dependency installation in the execution environment did not complete cleanly within the available execution window, so a full local TypeScript/Vite production build could not be certified here. Source-level integration has been completed, but Henry should run `npm install` and `npm run build` in the normal development environment before merging/deploying.
