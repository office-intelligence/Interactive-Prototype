# ASC.Vityls — Legacy Check-In Removal

## Decision
All legacy form-based day-of-surgery check-in entry points have been removed from the active application flow.

## New runtime behavior
- Dashboard case-card **Check-In** opens the unified V3 Pre-Op Nursing clinical review.
- Patient Chart **Open Pre-Op Nursing Clinical Review** opens the same workspace.
- Patient Chart Surgical Journey **Check-In → Nursing Review** opens the same workspace.
- The old `OfficeCheckInPage` / forms viewer is no longer mounted from `App.tsx` or `PatientChartPage.tsx`.
- The check-in journey step no longer advertises Front Office form counts.

## Architecture rule
Practice documents and patient intake documents remain available as document/intake capabilities, but old form-driven check-in is not a clinical runtime path. The active day-of-surgery workflow is the unified clinical workspace model.

## Next integration target
V3 Nursing → Anesthesia → Surgeon → OR Gate, using shared semantic encounter data and authentication events.
