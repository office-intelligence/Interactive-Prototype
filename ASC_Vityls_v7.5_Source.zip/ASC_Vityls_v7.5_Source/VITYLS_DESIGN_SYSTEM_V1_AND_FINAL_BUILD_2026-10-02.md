# Vityls Design System v1.0 + Integrated Final UI Build
Date: 2026-10-02

## Frozen product language
- Practice destination: Forms & Workflow
- Form ownership: My Forms
- Custom starter: Blank Custom Form
- Canonical stations: Patient Portal; Front Office; Nursing; Anesthesia; Surgeon / Physician; OR Team; PACU / Discharge
- Case Record is an encounter record/repository, not a station
- AI Hub naming replaced by Operations Intelligence
- Dashboard direction: compact + expanded cards
- Tablet is a first-class target

## Forms workflow
Form Library -> Open -> review -> Add to My Forms -> assign station(s) + requirement -> Add.
Customization is optional after addition. My Forms is the practice-owned set. Duplicate creation is not the default action.

## Form templates
The attached 2026-10-01 template set was copied into the application form library using the existing canonical filenames so current routing continues to work. Additional attached Anesthesia Orders, PACU Doctor Orders and Surgeon Orders are included. Blank Custom Form is added.

## Signatures
Runtime rendering uses the Vityls Standard signature/authentication presentation. The renderer removes legacy per-template signature controls/status around explicit signature canvases and supplies one standard freehand component. Clinician authentication remains conceptually distinct from patient freehand signature and should bind to signer identity/attestation in backend integration.

## Design system
Vityls Design System v1.0 CSS primitives were added to the shared stylesheet: page anatomy, cards, buttons, statuses, tabs, inputs, empty states, modal, alerts, choices, drawer and table primitives. Small corners and restrained semantic color are the default.

## Important backend boundary
This remains a frontend/evaluation build. Browser persistence is not the production database contract. Henry's backend should remain authoritative for shared clinical concepts, encounter values, versioning, authentication, documents, workflow events and audit/provenance.
