# Vityls UI update — 2026-10-02

- Removed Middle Initial from Add New Patient and Edit Patient UI. Existing imported middle-initial data remains tolerated by the data type for backward compatibility, but is no longer collected or used to construct the display name.
- Practice bottom navigation now defaults to the Practice/Administration view instead of Billing.
- Replaced legacy Practice, Billing & Payments, and AI/Workflow surfaces in PracticeWorkspace with the approved uploaded designs. AI Hub terminology is rendered as Operations Intelligence.
- Updated global UI typography to Source Sans 3 for interface text and Cormorant Garamond for display headings, matching the approved sample pages. System fallbacks remain in place.
- The approved uploaded pages are embedded as design surfaces with their duplicate app bars/footer navigation hidden so they sit inside the existing Vityls shell.

Note: these three approved design surfaces are visual/product integration targets. Their individual commands still need to be wired to production data/actions as backend integration proceeds.
