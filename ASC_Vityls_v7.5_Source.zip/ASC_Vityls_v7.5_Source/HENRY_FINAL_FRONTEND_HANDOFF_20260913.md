# Vityls Final Frontend Handoff — 2026-09-13

This package is the frozen frontend baseline for database/API integration. No further UX revisions are intended until database tables/connections are complete and testing begins.

## Frozen behavior
- Form Studio is the single form-definition source for HTML and uploaded PDF forms.
- Workflow assignments determine availability in Patient Portal, Front Office, Nursing, Anesthesia, Surgeon/Physician, OR Team, and PACU/Discharge.
- “Intake Forms” on the patient chart means forms assigned to Patient Portal. It is a distribution/status panel only; there is no Open button there.
- Incomplete Patient Portal forms are resumed at Arrival & Check-in. Arrival combines Patient Portal + Front Office assignments without duplicating a form.
- Form versions are immutable for completed encounters; later edits create a new practice version.
- Universal freehand signatures apply where a form/PDF contains a signature field.
- Billing, payments/credits, credentialing, source-document provenance, and integration bindings follow the database boundary notes already included.

## Clean-state requirement
- No demo patients, appointments, tasks, portal messages, bills, clinical summaries, bottlenecks, nursing packets, or dated surgical episodes seed at runtime.
- Legacy nursing seed collections are empty.
- Portal sample collections are empty.
- The default practice is intentionally unconfigured (“New Practice”).
- User-entered form fields do not contain patient-specific sample responses. Policy/consent language that is itself the template content remains intact and practice-editable where designed.

## Henry: database implications
Do not create separate IntakeForm/PdfForm/NursingForm tables. Use FormDefinition/FormVersion + FormWorkflowAssignment + PatientFormRequest/FormInstance/FormResponse/Signature. Preserve source artifacts and version history.

Before merge: run a clean install and production build, then wire data stores/API endpoints without reintroducing prototype seeds.
