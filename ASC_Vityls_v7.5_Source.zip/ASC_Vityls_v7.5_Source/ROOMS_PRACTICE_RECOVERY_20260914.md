# Vityls ASC — Scheduler Rooms + Practice Recovery (2026-09-14)

## Base used
This build was rebuilt from `Vityls_FINAL_Henry_Database_Handoff_20260913.zip`, the last known-good frontend supplied by Kevin. The goal was to preserve that working UI and apply only the scheduler-room and ASC Practice-page changes.

## Practice page recovery
- Bottom **Practice** navigation opens directly to **Administration & Locations → Practice & Team Setup**.
- The ASC edition hides multi-location/account controls. Each ASC location is intended to be a separate account and configuration.
- **Add a New Practice or Location**, configured-location switcher, branch subtitle, and primary/satellite classification are hidden in ASC.Vityls.
- **Primary Provider Fields** are hidden in ASC.Vityls. The section remains in source for the future MED.Vityls edition; hidden fields no longer block ASC form submission.
- **Visit Types & Color Coding** remains in source for MED.Vityls but is hidden in ASC.Vityls.
- Room color selection is removed from the ASC room editor. Scheduler color ownership belongs to the surgeon/provider layer.

## Scheduler rooms
Practice configuration is the single source of truth for schedule rooms.

Each room has:
- `id` — stable backend key
- `name` — administrator-controlled display name
- `type` — OR / Procedure / Consult / Recovery
- `active` — controls scheduler availability
- `sortOrder` — controls column/selector order

Default demo configuration:
- OR #1
- OR #2
- GI Suite #1
- LASER Room

The Schedule page now:
- Reads only active rooms from Practice configuration.
- Uses exact configured names as column headings.
- Uses the same room list in the **Rooms** selector.
- Supports any number of configured rooms in Day and Week grids.
- Keeps room filtering as a user-view preference only; it does not alter case assignments.
- Stores visible-room preference per practice in browser local storage for frontend testing.
- Preserves selections through room renames by translating through stable room IDs.
- Prevents a user from hiding every room.
- Renders only one Schedule Rooms modal.
- Sends the same configured-room list to Print Schedule and Block Time dialogs.
- Supports Nightingale commands such as “show only OR #1 and GI Suite #1”, “show all rooms”, and “show all rooms except LASER Room”.

## Henry backend boundary
Appointments should ultimately reference `room_id`, not room display text. Renaming `OR #1` to `Main Operating Room` must not alter the appointment relationship. `room.name` is display data; `room.id` is the relational key.

Provider/surgeon scheduler colors should likewise live on the provider/surgeon record and be applied to case blocks from the assigned surgeon. Room colors should not drive case block colors in ASC.Vityls.

## Validation performed
- Compared scheduler-related source against the prior room-fix build.
- Removed remaining hard-coded OR#1/OR#2/OR#3 labels from Print Schedule and Block Time controls.
- Confirmed only one `Schedule Rooms` modal exists in the React source.
- TypeScript/TSX syntax-transpilation checks passed for all modified source files.
- Full npm/Vite build could not be completed in this sandbox because dependency installation timed out; Henry should run `npm ci` followed by `npm run build` in his normal development environment.
