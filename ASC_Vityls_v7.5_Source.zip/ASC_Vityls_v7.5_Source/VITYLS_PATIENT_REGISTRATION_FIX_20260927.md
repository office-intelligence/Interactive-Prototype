# Patient Registration + JSX Stability Fix — 2026-09-27

- Corrected stray JSX closure in PatientChartPage that prevented Vite/esbuild compilation.
- New patient creation is now intentionally minimal: first name, optional middle initial, last name, telephone, and email.
- MRN is assigned automatically by Vityls and is displayed read-only during creation.
- Address, marital status, ethnicity, SSN, driver's license, occupation, employer, emergency contact, referral source, payment/insurance details, allergies, medical history, and other registration data are not collected when the chart is first created.
- Those details are expected to arrive through At-Home Intake and populate the Patient Profile.
- The existing full Patient Profile editor remains available for an existing patient through the pencil/edit action.
- New patient status begins as registration/intake incomplete rather than clinically cleared.
