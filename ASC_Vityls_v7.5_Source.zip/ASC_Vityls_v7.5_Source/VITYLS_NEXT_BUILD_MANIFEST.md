# Vityls Next Build Manifest — 0.1

Date: 2026-09-27

## Baseline
Forked from `ASC_Vityls_FRONTEND_FINAL_DATABASE_READY_20260915.zip` so the established Vityls shell, scheduler, patients, messages, Practice workspace, and Nightingale entry point are preserved.

## New production-oriented seam
1. Typed domain contract in `src/vityls-next.types.ts`.
2. `VitylsApi` interface and mock adapter in `src/services/vitylsApi.ts`.
3. New `VitylsNextWorkspace` inside the existing application shell.
4. Default Dashboard route now opens Vityls Next.
5. Reference patient is deliberately de-identified (`Reference Patient 001`).

## Current working slice
- Surgical Journey state strip.
- Pre-Op Nursing one-page clinical review pattern.
- Actual upstream clinical facts with provenance.
- Attention state for unresolved allergy reaction.
- Medication risk review placeholders for anticoagulants and GLP-1/GIP.
- Calculated VTE factor list, total, and risk category.
- MH screen summary without inventing a numeric MH risk score.
- Case readiness rail.
- Nursing review attestation control.

## Backend replacement seam
`mockVitylsApi` is temporary. Henry's API adapter should implement the same `VitylsApi` interface. UI components should not be rewritten to match database tables.

## Next build
- Front Desk workspace and handoff event.
- Editable Nursing facts with change/provenance events.
- Nursing authentication event payload.
- Anesthesia one-page workspace using the same shared encounter object.
- Procedure version/dependency reevaluation event.
- Document/consent state objects.
