# Vityls ASC — Final Frontend / Database Handoff
**Date:** September 14, 2026

This package is the final ASC.Vityls React/Vite frontend handoff for database/backend implementation.

## Final UI adjustment
- The primary **Practice** navigation link opens the **Administration Home** guided-setup landing page.
- The guided-setup heading **“What would you like to configure?”** is explicitly white for correct contrast on the green gradient.
- Direct configuration shortcuts (for example Configure Practice from account/profile flows) remain capable of opening Practice & Team Setup directly.

## Scheduler / room model already incorporated
- Active rooms are practice-configured and drive scheduler headings, room selector, block-time room options, print matrix room groups, and Nightingale room filtering.
- Room names are not hard-coded to OR #1 / OR #2 / OR #3.
- Room display selection is a user-view preference and does not change case assignment.
- Stable room IDs are retained for backend mapping; appointments should ultimately reference `room_id` rather than room display text.
- Room colors are not the source of scheduler case color. Surgeon/provider color assignment should own case display color.

## ASC-specific Practice behavior
- ASC.Vityls hides MED-oriented primary-provider and visit-type configuration UI.
- Multi-location creation/switching controls are hidden from the ASC practice-configuration page per the product decision that separate ASC locations will be separate accounts/tenants.

## Backend boundary
Henry can now replace local/mock state with database/API persistence without redesigning the UI contracts. Existing handoff documents in this package describe case records, form normalization/versioning, patient gating, and database/API boundaries.

## Recommended validation before integration
1. `npm ci`
2. `npm run build`
3. Open the app and click **Practice** in the main bottom navigation — Administration Home should be the landing page.
4. Open **Practice & Team Setup**, add/rename rooms, save, and verify the Schedule room selector/grid updates.
5. Verify Block Time and Print Schedule Matrix use the configured room names.
