# Surgery.Vityls v0.7 — redesigned Today and Patient Chart (2026-10-12)

**Built from:** tag `surgery-v0.6` on branch `surgery`. **Tag:** `surgery-v0.7`.
**Scope:** only **Today** and the **Patient Chart** were rebuilt, following Kevin's design concept (design A for the chart, design B plus his red-pen markup for Today).
- **Unchanged:** Schedule, the Patients list, Messages, Practice, every station, the portal and all dialogs work and look as in v0.6.
- **One app-wide change:** the highlighted navigation tab.
- **ASC.Vityls and MED.Vityls are untouched.**
- All data is fictional and test PINs are `1234`.

## What changed

### Shared
- **Top navigation (markup 1).** The active tab is now a highlighted pill (soft green `#E4EEEA`, bold dark-green text, 3px corners), as in the design. This applies on every page because the top bar is shared. The rest of the top bar is unchanged: Session picker, Portal and the simulation stamp.
- **Look of the two redesigned pages.**
  - Warm gray page (`#F6F7F4`) with white cards, Public Sans type, and IBM Plex Mono for times and the MRN.
  - Public Sans is bundled in the app, so nothing loads from the internet.
  - Following markup 4, every section has **3px corners** and **no thick left accent borders**. That covers the Nightingale card, list rows, Worth-your-attention cards, the appointment panel, the chart header, tabs and cards.
  - Where the design used a colored left bar to show urgency, a small colored dot carries that meaning instead.
- **Nightingale card.** It works like the v0.6 Nightingale header: the same scripted on-device answers, citations, "Keep in chart", audit (`nightingale.answer`), simulated hold-to-speak, and "never signs or orders".
  - The summary paragraph stays visible and an answer opens under the ask box.
  - The chips act: they open the chart, panel, appointment or station.
  - The Nightingale header still appears unchanged on the other pages.

### Today (design B + markup)
- **Header.** "Good morning / afternoon / evening, {first name of the tablet session}". Next to the date are **‹ Back**, **Forward ›**, **Today** (greyed out when you are already on today) and a **date picker** (markup 2). This keeps the v0.6 behavior: the chosen day is remembered for the session.
- **Buttons.** **+ Add appointment is removed** (markup 3). **Add patient** stays and opens the same v0.6 Add-New-Patient dialog, then the forms prompt.
- **Four counts.**
  - **Visits** (labeled VISITS TODAY on today).
  - **Not confirmed:** scheduled visits that haven't arrived and whose reminder status is waiting, call-to-confirm or reschedule.
  - **Needs attention:** the number of Worth-your-attention items.
  - **New patients:** visits whose type includes "new".
- **Nightingale card.**
  - A live brief built from the day's data: visits, new consults, the first unconfirmed visit and how many reminders went out, patients in the office, flagged calls, labs waiting, and portal messages.
  - Chips: **Confirm {name}'s visit** (selects that appointment), **Review {name}'s labs** (opens the chart on the lab slip), **Reply to {name}'s call** (opens the contact note), and the v0.6 likely-next steps.
- **Appointment list.** Rows show the time, patient, visit type · provider · room, and a status pill:
  - CONFIRMED, NOT CONFIRMED, CALL TO CONFIRM, RESCHEDULE or SCHEDULED, from the v0.6 reminder engine.
  - ARRIVED, CHECKED IN, NURSE INTAKE, SURGEON, CHECKOUT or DONE, from the station.
  - The selected row is tinted. It has no left bar.
- **Appointment panel** (markup 5 and 6). Clicking a row opens it on the right. At 768 it sits under the list, and the page scrolls to it.
  - **Contents:** patient (the name opens the chart), age · sex · DOB · payment type, phone, status pill, reminder or arrival note, a **Reminders** link (the v0.6 reminder dialog), visit type, time, provider, room and reason.
  - **Only three buttons: Arrived, Check-in, Open chart.** There is no Visit workflow button.
  - **Arrived** stamps the time automatically (`visit.arrive`) and becomes "Arrived 1:14 PM".
  - **Check-in** stamps arrival and check-in (`visit.checkin`) and starts the station workflow, exactly as in v0.6. Once a visit is under way, the same button reads "Continue · {station}". When the visit is complete it reads "Visit record".
  - On other days, Arrived and Check-in are disabled with a tooltip. Open chart always works.
- **Worth your attention.**
  - Three cards, plus **Show all N**.
  - Sources: unconfirmed visits, flagged contact notes, labs awaiting review, new portal messages, unsigned notes, checkout to-dos, and risk factors to review before surgery within 21 days.
  - Each card acts: it selects the appointment or opens the chart panel or the station.

### Patient Chart (design A)
- **Order on the page.**
  1. Nightingale card. The summary is the v0.6 "Who" narrative, including the Outside-records line from the Documents folder. It is clamped to 3 lines, with **Read the full summary**.
  2. **‹ Patients** back link.
  3. **Header card:** name; age · sex · DOB · MRN; **Why here** (today's visit and next surgery); and **Add / dictate note**, **Profile**, **Hide / delete**, plus **More ▾** (new, see below).
  4. The five-column brief: **Allergies** (with ✓ Verified or ✓ Verify), **Medications (n)**, **Past medical history**, **Past surgical history**, **Significant risk factors**. Each column label opens its source in the right panel. At 768 the brief folds to two columns, as in the design.
- **Tabs: Overview · Clinical record · Documents · Photos & charts · Activity.** Documents and Photos show counts. The tab you choose is remembered while you stay on the same patient and goes back to Overview when you open another patient.
  - **Overview.**
    - Left: **Worth your attention** (v0.6 items: labs, messages, ASC questions, consent, flagged notes, allergy confirmation), **Active problems** chips, **Surgical risk factors** ("n of m reviewed by the surgeon", Review risk factors →), **Kept from Nightingale**, and the **hold-to-initial chart summary** (provider PIN).
    - Right: **Today's visit** (status and Visit workflow →, when there is one), **Next appointment** (status pill and **Send reminder**), **Surgery** (next ASC case → ASC case & thread), **Care coordinator** (the picker sits in the card), **Account** (balance, **Collect payment** with PIN, **Billing**), **Contact** (phone, email, emergency contact, payment, referral, **Edit profile & contact**), and the **new-patient forms** packet line when it applies.
  - **Clinical record.** Medications (dose · frequency, manage →), Allergies (the full v0.6 verify / record-a-change with PIN), Problem list, Surgical history (year on the right), Results (lab slips with a To-review flag, All results, Trends), Visits & notes (each opens its workflow), and a quiet line for Vitals · Intake answers · Risk awareness · Care plan · Medical journal.
  - **Documents.** The v0.6 Documents folder, restyled to the design: the Nightingale whole-folder summary, type chips, and rows with view / download / AI summary / delete; Add document; Show removed / Restore.
  - **Photos & charts.** Clinical photos (before/after, date, compare up to four full screen; open to all users, as in v0.6) and body charts (saved charts plus the diagram picker).
  - **Activity.** Every timeline event, newest first after upcoming and today: visits, labs, messages, contact notes, documents, ASC messages, care plan and caregiver events. Each has a type tag (UPCOMING, VISIT, MESSAGE, CALL, DOCUMENT, …) and NEW where it applies, and clicking one opens its source. Quick links at the top: **Contact notes (n)**, **Portal messages**, **Full journal**.

## Where v0.6 capabilities that design A doesn't show now live
| v0.6 capability | v0.7 location |
|---|---|
| Timeline sidebar | **Activity** tab (same events, same panels) |
| Living summary: significant conditions + meds | Header brief (PMH, Medications) + **Clinical record** |
| Living summary: surgical history / risks / problems | Header brief + **Overview** (problems, risk factors) + **Clinical record** |
| "Who · Nightingale" narrative (incl. outside records) | **Nightingale card** summary (Read the full summary) |
| Worth your attention (chart) | **Overview**, top-left card |
| Kept from Nightingale; initial the summary (PIN) | **Overview**, left column |
| Today's encounter strip / Open visit workflow | **Why here** line (Open visit workflow →) + Overview **Today's visit** card |
| Visit workflow link for past encounters | **Why here** line (Last visit workflow →) + **More › Visit workflow** + Clinical record › Visits & notes |
| Red New message banner | Slim red line under Why here (Read & reply →) |
| Coordinator picker | Overview › **Care coordinator** card |
| Account badge, Collect payment, Billing | Overview › **Account** card; also **More › Collect payment / Billing** |
| Profile/contact line, payment & referral | Overview › **Contact** card (Edit profile & contact); header **Profile** |
| Next appointment + reminders | Overview › **Next appointment** card (Send reminder opens the reminder dialog) |
| New-patient forms packet line | Overview, right column (when packets exist or for brand-new charts) |
| Records & documents grid: results, trends, vitals, meds, problems, history, intake, risk, care plan | **Clinical record** tab |
| Records grid: portal messages, contact notes | **Activity** quick links + **More** menu |
| Records grid: care team, caregivers, journal, remote monitoring, audit trail | **More** menu (journal also in Clinical record and Activity) |
| Records grid: ASC case & thread, Sent to ASC | **More** menu + Overview › **Surgery** card |
| Body charts & photos | **Photos & charts** tab |
| Documents folder | **Documents** tab |
| Today: status filters (All / Not arrived / In office / Done) and provider filter | Removed for calm (Kevin's design). The Schedule page keeps provider columns; Nightingale answers "who's next / how many in the office". |
| Today: "At the ASC · next 7 days" | Quiet **At the ASC · next 7 days (n)** disclosure under Worth your attention |
| Today: card details (phone, allergies, surgery tag, labs tag) | Appointment panel (phone, payment), Worth your attention (labs, risks), the chart |

## Deviations from the design files, and why
1. **+ Add appointment removed.** This is Kevin's markup. New appointments are still made from the Schedule (click an open slot).
2. **Appointment panel buttons:** Arrived · Check-in · Open chart (markup 6) instead of Open chart · Visit workflow. Check-in is the primary (green) button until the patient is checked in; after that, Open chart is primary.
3. **3px corners everywhere and no thick left borders** (markup 4). The Nightingale card, the selected row and the attention cards lost their colored left bars. Colored dots keep the meaning. Buttons and inputs also use 3px. Status pills and chips stay rounded, because they are labels rather than sections.
4. **A fifth chart tab, "Photos & charts".** Design A has four tabs. Photos and body charts were a prominent v0.6 surgeon feature, so they have their own tab.
5. **A "More ▾" button in the chart header**, so care team, caregivers, ASC, journal, monitoring, audit, billing and workflow stay reachable without crowding the page.
6. **Overview has more than the design.** Worth your attention, Kept-from-Nightingale and the summary initial were added on the left. Today's visit and Surgery cards appear on the right when they apply, and Contact also shows payment type and referral. They are kept because v0.6 safety and review flows live there.
7. **Top bar.** Only the tab highlight was adopted. The design's wordmark, avatar block and simulation chip were not copied; the v0.6 Session picker (shared-tablet model), Portal and SIMULATION stamp stay so the other pages don't change.
8. **Public Sans is used on the two redesigned pages only.** The other pages keep Source Sans 3 until they are redesigned. The fonts look close, but the switch is visible if you look for it.
9. **The Nightingale summary is generated** from recorded data (the v0.6 Who narrative). It is longer and less polished than the design's hand-written paragraph, so it is clamped to 3 lines with Read the full summary.
10. **Documents rows** keep v0.6's icon actions (view / download / AI summary / delete) and the folder digest, instead of the design's "View · Download" text links. Type is shown with an icon and name rather than a colored badge.
11. **Date nav.** The date text is followed by ‹ › Today [date picker], as marked. The Today button is greyed out (not hidden) when you are already on today.

## Side-by-side check (`report/surgery_v07_screens/side_by_side/`)
`today_768.png`, `today_1180.png`, `chart_768.png` and `chart_1180.png` each place the design file (rendered headless at the same width) on the left and v0.7 on the right. These differences are visible:
- **Data, not mock data.** The design shows Tuesday Oct 13 with Robert checked in and Marisol unconfirmed. v0.7 shows the live fictional schedule for the test day (6 visits, 2 new consults; the times and statuses differ). The Today summary and chips reflect it.
- **Today:**
  - No green **+ Add appointment** button.
  - The **‹ › Today [date]** controls sit next to the date.
  - The appointment panel has **Arrived / Check-in / Open chart**.
  - The Worth-your-attention cards have dots instead of colored left bars.
  - An "At the ASC" disclosure sits at the bottom.
- **Chart:**
  - The Nightingale summary is the generated narrative (3 lines plus Read more).
  - Why here shows today's pre-surgical consult and the booked surgery, with **Open visit workflow →**.
  - A red New-message line appears (Gene Testwood's message).
  - There is an extra **More ▾** button and an extra **Photos & charts** tab.
  - Overview has the extra Worth-your-attention, Today's visit, Surgery and summary-initial cards.
  - Risk factors show the v0.6 labels ("On an Antiplatelet (P2Y12)").
- **Top bar.** The v0.6 wordmark "Surgery.Vityls" and Session picker in place of "● Vityls Surgery" and the avatar. The highlighted tab matches.
- **Corners** are 3px throughout, against 10–16px in the design, per the markup.
- **At 768,** both match the design's stacking: KPIs 4-up, the panel under the list, the brief two columns, and the side cards under the main column. There is no horizontal scroll (tested).

## Tests
- **New v0.7 suite** (`surgwork/v7/smoke7.py`): **114/114 passed** at 768×1024 and 1180×820. It covers:
  - Today: greeting; highlighted tab; no Add appointment; KPIs equal the rows and attention cards; 3px corners and no thick left borders (computed styles); panel buttons exactly Arrived/Check-in/Open chart; the Arrived timestamp; Check-in starting the station and the audit; Continue state; closing the panel; ‹ › Today and the date picker.
  - Nightingale and chips.
  - Chart: the 5 tabs; brief columns; Documents (6 rows, AI summary); Photos & charts; Activity; contact-notes panel; Add-note dialog; More menu (care team); Profile dialog; chart Nightingale answer.
  - Schedule and Messages still on the v0.6 frame; no horizontal overflow; no page errors.
- **v0.6 regression suite** (`smoke6`, adapted only where things moved: tabs instead of one scroll, a white header instead of the tinted one, "72 years"): **136/136**.
- **v0.4 regression** (`reg_reg4`; the only change is `chart-workflow-link` → `chart-station` for a patient with a visit today): **74/74**.
- **v0.5 regression** (`reg_smoke5`) stops at the same step on **v0.6 and v0.7** today: the simulated-reply button in the reminder dialog, which depends on the clock. This is a pre-existing time-of-day dependency, not a v0.7 change. Its later "Today cards show confirmation badge" check no longer applies, because Today shows status pills.
- **TypeScript:** no errors in `src/surgery` (`tsc --noEmit`). Errors elsewhere in the repo are pre-existing.

## How to test (double-click `index.html`; PIN 1234)
1. **Today.** The active tab **Today** is highlighted. Check the greeting, the date with ‹ › Today and the date picker, and that there is no Add appointment button. Press › to see tomorrow (the counts change and the Today button lights up), then press **Today**.
2. Click **Robert Fictus**. The Appointment panel shows only **Arrived · Check-in · Open chart**. Press **Arrived**: the time stamps and the row says ARRIVED. Press **Check-in**: the station opens. Go back to Today: the row says CHECKED IN, and the panel's middle button now reads **Continue · Check-in**.
3. Try the Nightingale chips and a question ("who's next", "results to review"). Click a **Worth your attention** card, and use **Show all**.
4. **Open chart** for Ellen Testwood. Read the Nightingale summary (**Read the full summary**). Click **ALLERGIES** or **MEDICATIONS** in the brief: the right panel opens. Use **More ▾** (care team, ASC, audit trail).
5. Go through the tabs: **Overview** (Send reminder, coordinator, Collect payment, Edit profile & contact, hold to initial), **Clinical record** (verify allergies with PIN, lab slips), **Documents** (AI summary, add, delete or restore), **Photos & charts** (pick two photos → Compare), **Activity** (click any event; Contact notes).
6. Use **Add / dictate note**, **Profile** and **Hide / delete** as in v0.6.
7. Open **Schedule**, **Patients**, **Messages** and **Practice**. They are unchanged except for the highlighted tab.

## Rough edges
- The generated Nightingale summary on the chart reads mechanically next to the design's prose. It is clamped; a production model would write it.
- The two fonts differ between redesigned and unchanged pages (see deviation 8).
- Today's greeting uses the first word of the tablet session's name ("Front Desk Tester" → "Good afternoon, Front").
- The appointment panel is only on Today. The Schedule still uses its v0.6 popup (left as it was on purpose).
- The Today "Needs attention" count is practice-wide (flags, labs, messages, unsigned notes, to-dos, risks) plus the shown day's unconfirmed visits. It is not limited to that day's patients.
- The chart tab is remembered per browser session. Returning to the same patient from a station restores the last tab, not Overview.
- Status pills replace v0.6's confirmation badges on Today. The full reminder history is one tap away (Reminders).
