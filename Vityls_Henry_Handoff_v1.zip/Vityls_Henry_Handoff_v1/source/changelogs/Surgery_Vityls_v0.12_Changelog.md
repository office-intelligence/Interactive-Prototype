# Surgery.Vityls v0.12 — Changelog (2026-10-13)

Built from `surgery-v0.11`. ASC, MED and src_v5 are untouched; all new code is in `src/surgery/v12/`, with small hooks in Surgery files (`Chart7.tsx`, `SurgeryStation.tsx`, `SurgeryApp.tsx`, `v09/formChrome.ts`, `v11/PatientPhoto.tsx`, `v11/DxEditor.tsx`). Fictional data only.

## 1. Chart Overview › Past visits
- **What existed before:** past visits were only reachable through Clinical record › "Visits & notes" (the 5 most recent, each opening its workflow, plus "All visits & notes"), the header's single "Last visit workflow" link, and More › Visit workflow. Overview had no list.
- **New:** a "Past visits" card in the right column, right under Today's visit and Next appointment. Newest first: date, visit type, provider, status (Completed / Completed · note signed / Not checked in / Open · station). Each row opens that visit's workflow or visit record. Shows 3; "Show more" adds 5; "Show all N"; "Show fewer".
- Fictional seed: every test patient gets 2–6 past visits (with signed and draft notes) once, so the card has history.

## 2. Surgeon (Doctor) workflow › Diagnosis & procedure + Nightingale suggestions
- New section on the Surgeon step, using the chart's own diagnosis list and editor (same `DxEntry` data, same Add/Edit/Remove dialog). Changes appear on the chart, the Patients column/filter and the Practice report.
- **Nightingale · Suggest from note & history** (simulated, deterministic keyword rules, no AI service). It reads the visit note (or the scribe draft when there's no note yet), the transcript, nurse intake, visit reason, the problem list, and the patient's medical-history and intake forms (portal and station). It proposes diagnoses with ICD-10 text and a planned procedure, quoting the sentence each came from. About 15 plastic-surgery patterns: dermatochalasis, ptosis, jowling, rhytides, BCC, septum, nasal deformity, diastasis, breast hypertrophy and ptosis, gynecomastia, adiposity, scar, skin lesion, carpal tunnel. Diagnosis + procedure pairs already on the chart are skipped.
- Nothing is saved by Nightingale. Each suggestion is **Accept**, **Edit** (opens the chart diagnosis dialog pre-filled), or **Dismiss**. Saving follows the existing chart rule (any team member, no PIN, audited `patient.dx`). Suggest, accept, edit and dismiss are also audited (`nightingale.dx.*`) on the visit and the patient.

## 3. BUG: "Legal" on Patient Registration first/last name
Sources found:
1. Template HTML `public/forms/Patient_Registration.html` (shared with ASC, so not edited; Surgery rewrites it on load, as in v0.10, now case-insensitive).
2. **Stored state, the likely cause of what Kevin saw:**
   - practice template copies in `form-lib` (draft plus every published version, created by v0.9 before the rename)
   - legacy Form Studio copies `vityls-master-form-template:*` and `vityls-form-template:*`
   - saved form records whose `labels` were captured with the old wording (shown in record and print)
3. Structured libraries in memory: `OFFICIAL_HTML_FORM_LIBRARY` field labels and `ASC_DEFAULT_FORM_PRESENTATIONS`, used by library cards and older portal/chart views.

Fixes (Surgery only, `v12/legal.ts`):
- One-time migration at start-up rewrites every Surgery-namespace stored item, including copies, versions, legacy templates and form labels. Audit entries are history and are left as recorded. The migration itself is audited (`forms.migrate`).
- The in-memory libraries are patched when the Surgery app starts.
- A DOM safety pass runs on every mounted form (portal, station, chart, print).
- Verified on a fresh load (v0.10 checks: workspace preview and editor) and on a stored v0.9-style state (an injected old practice copy, version, legacy template and form labels get rewritten; the front-desk Registration then shows First Name / Last Name only).

## 4. BUG: patient photo upload
- **Cause (most likely):** v0.11 stored the photo inside the patients list in localStorage. On a computer that has opened several Vityls test builds from `file://`, they all share one ~5 MB browser quota. When it was full, the save failed and the app showed the misleading "That file is not an image." The menu also opened a `hidden` input by script, which some tablet browsers refuse.
- **Fix:**
  - Images now go to IndexedDB (much larger quota), kept in memory for display; localStorage is a fallback with a clear "storage full" message.
  - Upload is a real `<label>` file input (no scripted click).
  - Drag & drop works onto the photo.
  - Take photo opens the live camera when there is one and falls back to the device picker/camera when there isn't (or permission is refused).
  - Pictures are decoded with EXIF orientation, downscaled to 512 px, and compressed as JPEG (0.8, stepping down to ≤ 160 KB).
  - HEIC files and non-images get clear messages.
- **Tested at 768 and 1180:**
  - a real 4032×3024 JPG through the file chooser while localStorage is deliberately full (stored as 512×384, ~90 KB)
  - the photo survives a reload
  - drag & drop
  - camera fallback (headless has no camera)
  - non-image message
  - audit

## 5. ID and insurance cards
- **Chart:** an "ID & insurance cards" spot in the Overview right column, with status chips (✓ / ○) and a button that opens the full card dialog. Documents tab: an "ID & insurance cards" section at the top.
- **Placeholders:** photo ID front and back; primary insurance front and back, with carrier, member ID and group. Add secondary insurance, then "Add another insurance" (tertiary, additional). Extra insurances can be removed. Each slot supports upload, drag & drop, capture (camera or fallback), replace and remove, with who / when / where shown.
- **Patient Registration template:** a "Photo ID & insurance cards" block (6 fields: ID, primary, secondary, front/back) is mounted into the form wherever it opens (portal at home, front desk, chart). Pictures go straight to the chart, so a patient filling it in at home fills the chart Cards spot. They're attributed to "Patient (portal)" in the portal.
- **Front desk (Check-in):** shows card status and, when any card is missing, capture/upload fields for the missing ones only ("Show all cards" to see the rest).
- Same compression and storage as the photo; every change audited (`patient.card`). Self-pay patients with no insurance on file aren't asked for insurance cards.

## 6. Self-service Forgot PIN (Surgery only)
- **"Forgot PIN?"** is on every PIN prompt: sign, Practice gate, initial, verify a step, delete, hide, allergy, Send to ASC and the rest. They all use the one Surgery PIN dialog.
- **Request:** choose your name, then "Email me a reset link". A one-time link (`#pin-reset=<token>`, **expires in 30 minutes**) goes to the person's email through the **simulated outbox**; nothing is sent. The email is shown in a preview with "Open the link (test)". A new request revokes earlier unused links.
- **Reset page:**
  - Sign in with username + password.
  - Create the new PIN twice. Same rules as invitations: 4–6 digits, no repeated or sequential digits. It can't be the same as the current PIN.
  - The link works once.
- **Old PIN:** **keeps working until the reset is completed**, then stops working. Completing also clears the wrong-PIN count and unlocks. This way an unwanted request can't lock anyone out.
- **Administrators:** every Practice Manager and Practice Administrator gets a heads-up email (simulated outbox) when a reset is requested and when it is completed.
- **Staff page:**
  - "Change PIN" / "Reset PIN" no longer has a PIN box. **Reset PIN (send link)** emails the person the same reset link, the way providers already work, so admins never see or type anyone's PIN.
  - **Unlock** is kept for locked accounts; it doesn't change the PIN.
  - Provider rows keep the existing Providers › Account › Reset PIN link. Providers can also use Forgot PIN, which updates their provider signature PIN.
- **Rate limit:** at least 60 s between requests and at most 3 requests per person per hour. Refused requests are audited.
- **Audit:**
  - `pin.reset.request`
  - `pin.reset.limited`
  - `pin.reset.signin` / `.signin.fail`
  - `pin.reset.complete`
  - `pin.unlock`
- **Test build:** seeded fictional people have no real account. They sign in with the username shown in the email (first.last, e.g. `morgan.avery`) and the password `vityls-test-2026`. People without an email on file get a fictional `username@example.test` address.
- Shared files touched: `src/main.tsx` (the `#pin-reset=` route, only when the edition is Surgery). ASC behavior is unchanged.

## 7. Message attachments (Surgery only)
- **Staff replies** (Messages): an **Attach** button takes PDF, JPG, PNG, HEIC or DOC/DOCX files, up to 5 per message. Photos can be up to 20 MB and are compressed to 1600 px JPEG before sending. Other files are limited to 3 MB, and HEIC is kept as-is. Pending files show as removable chips before you send.
- **Portal**: patients and caregivers can attach files to new messages and replies, with the same limits and plain-language errors.
- **Chips** on every message have View (in-app viewer) and Download. The file data lives in IndexedDB (`att:<id>`) and the metadata in `msg-att`.
- **File to Documents** on incoming attachments: pick a Documents type, title and date. The file goes into that patient's Documents with `fromMessageId` and `fromAttachmentId`, then the simulated Nightingale document summary runs. Chips show **filed** or **not filed**.
- Audit actions: `message.attach` and `message.attachment.file`.
- Shared-file hook: `med/MedPortal.tsx` switches to `SurgeryPortalMessages` only when `isSurgery`; the MED path is unchanged.

## 8. Hide / delete moved to the Patients list (Surgery only)
- The chart-header **Hide/delete** button is gone. Each Patients list row has a **⋯** menu with Open chart, Hide chart… and Delete permanently…. Checkboxes allow multi-select, with a bulk bar for Hide… and Delete permanently….
- **Hide** works as before. Any staff member can start it; a Practice Manager, Practice Administrator or provider confirms with their PIN, and a reason is required.
- **Permanent delete** needs an administrator: Practice Manager, Practice Administrator, or a provider with admin rights. Provider admins come from the `provider-admins` setting (default Sam Patel, MD). The admin's PIN, a reason and typing DELETE are all required.
  - The PIN prompt lists administrators only, and admin status is checked again after signing.
  - Non-admins see delete disabled, with a hint in both the row menu and the dialog.
- Restore stays in Practice › Patient records. Every hide and delete is audited with its reason.

## Tests
- `surgwork/v12/smoke12.py` = the v0.7–v0.11 suites (adapted for the new photo input) + `v12part.py` (45 new checks per tablet size) + `pinpart` (20 Forgot PIN checks per size) + `attpart` (16 attachment checks) + `hdpart` (10 Hide/delete checks). **Result: 637 / 637 passed** at 768×1024 and 1180×820, including a real 4032×3024 JPG upload by click and by drag-and-drop. Screenshots are in `report/surgery_v012_screens/` at 768 and 1180.
- `npm run build` OK. Typecheck: the same 39 pre-existing errors, none in Surgery code.

## Rough edges
- The Registration card block is injected by Surgery at mount. It is not a field type in the form editor, so a practice can't move or remove it in the editor.
- The Nightingale suggestions are keyword rules (simulated). ICD-10 codes are shown as text for the clinician to verify. Bilateral dermatochalasis is shown as two codes.
- Images are kept in this browser's IndexedDB, per computer and browser like all test data. Clearing site data removes them; `?reset-test-data` starts a new set.
- The live camera needs a secure context on some browsers. When it opens from `file://` without camera access, the fallback picker is used.
- The check-in identity table still shows the older "Insurance" profile text. The card carrier fields are separate.
- The "Forgot PIN?" request can be made from a shared tablet for any listed person. That's safe because the link goes only to that person's email and the old PIN keeps working, but anyone can trigger an email (rate-limited, and admins are notified).
- The test credentials for seeded people are shown in the simulated email. A real build has real accounts.
- Hide still needs a manager or provider PIN to confirm, as before. Staff can start it, but a medical assistant can't confirm it alone.
- Attachments are capped at 5 per message, and DOC files aren't previewed: View offers a download for non-image, non-PDF files.
