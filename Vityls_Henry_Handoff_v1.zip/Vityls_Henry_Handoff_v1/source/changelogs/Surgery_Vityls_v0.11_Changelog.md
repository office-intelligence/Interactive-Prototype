# Surgery.Vityls v0.11 — Changelog (2026-10-12)

Built from `surgery-v0.10` on branch `surgery`, tag `surgery-v0.11`. ASC, MED and src_v5 behavior is unchanged (see "Shared files"). All data is fictional.

## 1. Form templates link removed
- The Practice tile **Form templates & editor** and its Nightingale chip are gone.
- Anything that used to open the old editor library now lands on **Practice › Forms & workflow**: the `form-editor` route, and Nightingale requests such as "form editor" or "form templates". You edit a form with **Edit form** on its My Forms card.

## 2. Patient photo
- The chart header shows a round photo to the left of the patient's name, or the patient's initials when there's no photo.
- Hovering (or tapping on a tablet) shows an **Add photo / Edit** overlay. The menu offers:
  - **Upload photo**
  - **Take photo** (opens the tablet camera, front-facing)
  - **Replace**
  - **Remove**
- Photos are resized to 320 px JPEG, stored in the patient profile, and audited (`patient.photo`).
- The photo (or initials) also appears in the **Patients list** and the **Today** appointment panel. (`src/surgery/v11/PatientPhoto.tsx`)

## 3. Chart "Notes"
- A new **Notes** tab on the chart, also reachable from the **Notes** link on the Activity row, lists every doctor note, written or dictated:
  - encounter notes
  - op/procedure notes (including uploaded operative-note documents)
  - provider contact notes
  - addenda
- Notes are sorted newest first and show date, type, author and signed/draft status, with **Open** and **Print** buttons. (`src/surgery/v11/DoctorNotes.tsx`)

## 4. Appointment notes
- A free-text **Notes** field is in the New appointment and Appointment detail popups and in the Today panel (edit + Save). Saving is audited (`visit.notes`).
- The schedule PDF **Notes** column now prints the real appointment notes, plus a "Double-booked" flag when it applies. It no longer prints room, length or confirmation status. **Reason** shows "visit type: reason".
- Seed: the first three upcoming scheduled visits get sample notes.

## 5. Diagnoses & procedures on the chart
- The Overview has a new **Diagnoses & procedures** card where you can add, edit and remove diagnoses. Each diagnosis has:
  - an optional ICD-10 code
  - any number of linked procedures, each with status (planned/performed), date (required when performed), surgeon and ASC
- Removing a diagnosis asks for confirmation. Every change is audited (`patient.dx`). Any role can edit.
- The Patients list column, the Diagnosis/Procedure filter and the Practice report all read the same data:
  - A patient can now have several diagnoses.
  - The report counts a diagnosis as performed when any of its procedures was performed.
  - The CSV export adds ICD-10 and Procedure(s) columns.
- Seed: second diagnoses were added to existing patients, so the report shows a mix of performed and not performed:
  - Robert: Dermatochalasis, performed
  - Priya: Nasal deformity, performed
  - Grace: Facial rhytides, planned
  - Marisol: Breast hypertrophy, performed

## 6. Signer roles (office only)
- The Surgery signer setup (Forms & workflow › step 2) offers only these roles: Patient / Guardian, Front desk, Medical assistant, Nurse, Surgical coordinator, Physician assistant / NP, Surgeon / Physician, Witness. (`src/surgery/v11/SignerSetup.tsx`, `signers.ts`)
- Migration (runs once): saved signer setups map Anesthesia → Surgeon / Physician and Circulator, PACU or OR nurse → Nurse. Audited as `form.signers.migrate`.

## 7. OR, PACU and Anesthesia roles removed everywhere in Surgery
- These roles now exist only in ASC. They were removed from:
  - staff and user role pickers
  - invitations
  - the Providers page (now a Surgery page with its own subtitle; it no longer reuses the ASC Administration page)
  - signer lists and filters
  - the acting-as list
  - seed staff
  - Nightingale text and labels
- Migration (runs once, `migrateOfficeRoles`):
  - Existing Surgery providers with an anesthesia/CRNA/OR/PACU role become **Physician** (Surgeon / Physician).
  - Staff with OR/PACU/circulator/scrub/pre-op roles become **RN** (Nurse).
  - Audited as `roles.migrate`.
- Clinical fields that aren't roles stay: the anesthesia type on ASC requests and the anesthesia fee on quotes.

## Shared files
- `src/v7/ProvidersAdmin.tsx`: new optional `sub` prop that overrides the subtitle. The default is unchanged, so ASC looks the same.
- From v0.10, still in place: `src/v6/formSource.ts`.
- Every other change is under `src/surgery/`.

## Tests
- The v0.9 and v0.10 suites were adapted: they now open the editor through Forms & workflow › Edit form, because the removed link is gone.
- A new `v11part.py` covers every item above, including:
  - the role scan (providers, staff and invitations, acting-as, signer options)
  - a migration test: a seeded "PACU RN" staff member becomes RN, and an "Anesthesiologist" provider becomes Physician
  - the photo upload/replace/remove audit
  - the PDF Notes text
  - the diagnosis add/edit/remove audit
  - the report mix
- Screenshots are in `report/surgery_v011_screens/` at 768 and 1180.
- Result: 459 / 459 checks pass at 768×1024 and 1180×820, with no page errors. `npm run build` succeeds. Typecheck shows the same 39 pre-existing errors as before, none of them in Surgery code.

## Deviations / rough edges
- **Edit form** works only on forms that are in My Forms. To edit a library form, add it to My Forms first (two steps).
- Staff can't hold provider roles, so staff with an anesthesia role are migrated to RN, not Surgeon / Physician.
- Older audit-history entries still show the old role names as they were recorded. They are history and weren't rewritten.
- Practice › Documents still uses the shared Administration page (it shows no roles).
- The photo hover overlay fades in over 0.15 s. On touch devices it appears when you tap.
