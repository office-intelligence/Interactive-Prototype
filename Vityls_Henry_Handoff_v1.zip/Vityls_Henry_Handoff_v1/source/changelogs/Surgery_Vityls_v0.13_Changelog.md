# Surgery.Vityls v0.13 — Changelog (2026-10-13)

Built from tag `surgery-v0.12`, branch `surgery`. This is a Surgery-only change. ASC, MED and src_v5 are untouched apart from the three small additive hooks listed under "Shared code touched".
All sending is **simulated**. Packets go to a local outbox (`records-outbox`), the portal message list, or the simulated ASC network thread. Nothing leaves the device.

## 1. Print / Send records packet
- **Button:** the "Print / Send" button sits on the chart tab row, next to Activity (`chart-print-send`).
- **Step 1 (Choose):** pick items from these groups:
  - Summary sheet, medication list, allergy list
  - Encounter records (the full visit) and encounter notes / A&P
  - Contact and doctor notes
  - Labs, pathology, imaging and ECG (documents are classified by type)
  - Other documents by type
  - Photos and body charts (optional)
  - Signed forms (locked chart forms and portal forms)
  - Quotes (optional)
- **Presets:**
  - **Pre-op clearance for ASC:** H&P / latest encounter, consent, labs (latest or last 90 days), ECG, clearance letters, med list, allergies. The recipient defaults to the configured ASC.
  - **Consult report to referring physician:** encounter note, A/P, labs, pathology, op note. The recipient is prefilled from the referral.
  - **Records for patient:** the recipient is the patient (portal).
  - **Custom.**
- **Step 2 (Organize):**
  - Reorder by drag or with the up and down arrows; remove items.
  - Optional cover sheet.
  - Optional cover letter. Nightingale drafts it (simulated, local template that uses the recipient, purpose and enclosure list). It is fully editable, and "Redraft" regenerates it.
- **Step 3 (Recipient):**
  - Referring physician (from the referral)
  - Other doctor (from a directory or entered by hand)
  - ASC (from the configured ASC list; the same path as Send to ASC)
  - Patient (portal or email)
  - Free email or fax
  - You also choose a method and a purpose.
- **Step 4 (Review):**
  - One combined PDF (pdf-lib) containing the letterhead, cover sheet, letter, table of contents, item pages and embedded PDFs/images.
  - Every page carries a header and footer with the patient name, DOB and MRN, plus "Page X of N" and a confidentiality line.
  - Actions: Preview (pdf.js canvases plus the TOC), Print, Download, Send. Each one is audited.
- **Send:**
  - A confirm dialog, then a PIN signature by the sender.
  - Delivery by method:
    - Portal: a message with the PDF attached.
    - ASC network: a share on the case thread, or a fax fallback.
    - Email or fax: a simulated outbox entry.
- **History:**
  - "Records sent" appears in Activity (top) and Documents (bottom). Each entry shows the date, recipient, method, purpose, item list, the HIPAA basis and any override reason.
  - Actions: View contents, Download the stored PDF, Resend (optionally to a new address).
  - Audit events: `records.packet.preview|print|download|send|resend` and `records.hipaa.override`.

## 2. HIPAA logic (documented in `src/surgery/v13/hipaa.ts`)
`checkHipaa(patient, recipientKind, recipientName, purpose)` returns:
| code | when | UI |
|---|---|---|
| `patient` | The recipient is the patient (right of access, 164.524) | No warning |
| `authorized` | A signed, unexpired, unrevoked HIPAA Release names this recipient type or name and covers the purpose | Green note naming the authorization and its expiry |
| `treatment` | The recipient is a provider or ASC and the purpose is treatment, referral or scheduling, with no authorization | **Soft** amber warning: this is a treatment disclosure allowed without authorization under 164.506(c), minimum necessary does not apply to treatment, and sensitive records (psychotherapy notes, Part 2 SUD, some HIV/genetic under CA law) still need specific authorization. A reason is prefilled ("Treatment disclosure, 164.506") and can be edited. **Not a block.** |
| `no-auth` | Any other recipient or purpose (family, health plan outside payment, attorney, other) with no matching authorization | Red warning. Sending requires an override reason (picked from a list or written in) and is audited as `records.hipaa.override` |

An authorization counts only if it is locked (signed), it names the recipient's category (Referring physician, Other doctors, Surgery center, Family, Health plan, Other person) or the recipient's name appears in "names", the purpose matches, it is not past `expires_on` (default: one year after signing), and it has not been revoked. Staff can record a revocation from the panel (`hipaa.revoke`).

## 3. HIPAA Release form
**What existed before:** the ASC and Surgery libraries had only `Admission_Form.html`, which contains a Notice of Privacy Practices plus an acknowledgment checkbox. That is an NPP acknowledgment, not an authorization. It lacks the required 164.508(c) elements: a specific description of the information, who may disclose, recipients, purpose, an expiration, revocation rights, a statement that treatment is not conditioned on signing, redisclosure risk, and a signature with date and representative authority. **It is not adequate** for releases to family, attorneys, insurers or other non-treatment recipients. MED's caregiver proxy records only a free-text note.

**New template:** `HIPAA_Authorization_Release.html`, category "Consent / legal". It covers:
- Every 164.508(c)(1) core element: the information, the discloser, the recipients plus names, the purpose, the expiration date or event, and a signature with date and representative authority.
- Every 164.508(c)(2) statement: the right to revoke and how, treatment not conditioned on signing, redisclosure, and the right to a copy.
- Sensitive-information initials and checkboxes: HIV/AIDS test results, mental health, substance-use disorder (42 CFR Part 2 notice), genetic tests, reproductive health. Each comes with California CMIA (Civil Code 56.11) language.
- At least 14-point type, as 56.11(a) requires.
- The banner "**Legal text: practice should have counsel review before use.**"

**How it works in the app:**
- **Workflow:** added to My Forms with the stations Patient portal / at home and Front desk, requirement "As needed". It is never "Required", because treatment can't be conditioned on it.
- **Signers:** patient or guardian (required), from station signer assignment; front-desk witness (optional).
- **Recognition:** once locked it is stored on the chart and recognized by the packet check, including recipients, names, purpose and expiration. Portal-signed copies (`portal-forms:<pid>`) count too.
- **Editing:** it can be edited in the form editor. The instruction and legal blocks now survive a parse.
- **Seed data:** Ellen Testwood (MED-1001) has a signed release covering referring physician, ASC and family, which you can use for testing.

## Shared code touched (additive only)
- `src/v6/formSource.ts`: `registerBundledForm(file, html)` lets an edition bundle a form without touching `public/forms`.
- `src/surgery/v09/formLib.ts`: `.sv9-instr` blocks are parsed as instruction fields, so legal text survives the editor.
- `newPatient.tsx` PortalForms also lists the HIPAA Release when it is placed at the portal.

## How to test
1. Open Ellen Testwood and click Print / Send. Choose "Pre-op clearance for ASC", then Next. Drag or arrow-reorder, keep the cover letter (edit it), then Next. The recipient is the ASC and the green panel shows "Authorized". Review → Preview → Send → enter PIN 1234.
2. Change the recipient to Other doctor, set the purpose to "At my request", and enter an unnamed doctor. You get the red warning, and an override reason is required.
3. Activity tab → Records sent → View / Download / Resend.
4. Open a patient's portal: the HIPAA Release is listed. Sign it, then repeat step 2 for that patient.

## Tests
See the end of this file.

## Rough edges
- Body charts are rendered as text summaries, not drawings. HEIC and Word documents are listed but not embedded (only PDF, PNG and JPEG are).
- The outside-doctor directory is seeded and can't be edited in the UI yet. Free entry works.
- Sensitive records (psych, SUD, HIV) are not auto-classified. The warning is generic.
- The cover letter's enclosure list reflects the order at drafting time. Click "Redraft" after reordering.
- The editor drops the `.counsel` review banner if the form is re-saved from the editor.
- Print opens the browser print dialog. In headless tests only the call is verified.
- The legal text is a draft. The practice should have counsel review it.

## Test results (2026-10-13)
- `npm run build`: OK. Surgery release build (VITE_EDITION=SURGERY): OK.
- Typecheck (`tsc --noEmit`, run with a larger Node stack because the default stack overflows): 39 errors, none in `src/surgery` (all pre-existing elsewhere).
- Full smoke suite (v8–v12 regressions + v13 packet/HIPAA checks), 768x1024 and 1180x820: **739 / 739 PASS**.
- The Today-panel appointment-notes seed now uses the local date instead of UTC, which fixes evening-time failures.
