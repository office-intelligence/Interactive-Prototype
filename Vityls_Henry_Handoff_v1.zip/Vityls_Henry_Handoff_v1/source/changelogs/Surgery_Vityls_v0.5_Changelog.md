# Surgery.Vityls v0.5: changelog (test build, fictional data)

**Date:** 2026-10-11 · **Branch:** `surgery` · **Tag:** `surgery-v0.5` (built on `surgery-v0.4`)
**Unchanged:** ASC.Vityls, `src_v5`, the `med-v0.1` tag and every ASC/MED zip. ASC's shared Add Patient dialog (`src/components/AddPatientModal.tsx`) is **not** modified: Surgery now has its own dialog with the same fields. Shared files touched: `src/med/MedPortal.tsx` (Confirm button on upcoming appointments, behind `isSurgery`) and `src/v6/dataLayer.ts` (new audit action names only).

Surgery.Vityls is still a test build. It runs from `index.html` with no server, all data is fictional, and everything stays in the browser. Texts, emails, reminders, portal posting and card payments are **simulated** and recorded in the outbox and the audit trail. Test PIN for every fictional person: **1234**.

> **First open resets the Surgery test data once** (new fictional upcoming visits with reminder history). ASC and MED test data are not touched.

---

## What changed in v0.5

### A. Add New Patient: payment type and referral source
- The Add New Patient dialog (Today, Patients, chart header and now also the schedule's New appointment dialog) has a new **Payment & referral** section:
  - **Payment type** (required): Self-pay (cosmetic), Private insurance, Medicare, Medicare Advantage, Medicaid, Workers' compensation, Patient financing (e.g. CareCredit), Auto / personal injury (lien), TRICARE / VA, Other.
  - For insurance-type payers, **Insurance / plan** and **Member ID** appear (both optional).
  - **Referral source** (optional): Physician referral, Patient / friend referral, Website / search, Social media, Online reviews, Insurance directory, Advertising, Event / seminar, Returning patient, Other. **Referred by (name)** appears for physician or patient referrals, and a detail field appears for Other.
- **Both lists are configurable:** go to Practice › **Visit types, intake lists & reminders** › **Patient intake lists** (one entry per line, audited as `intake.lists`). Removing an entry does not change patients who already have it.
- Payment type and referral are saved on the patient record and appear in:
  - the chart's **Contact · Payment · Referral** line
  - the Patients list (under Account)
  - the top of **Billing**
  - the `patient.create` audit entry
- The dialog uses the white Surgery style. The v0.4 green ASC look is gone.
- The six seeded patients have fictional payment types and referral sources.

### B. Schedule: click an open time slot to book
- **Click or tap any open time** in a provider column. **New appointment** opens with the **date, time (15-minute slot) and provider column already filled in.** On a desktop, a dashed "+ 3:30 PM" marker follows the pointer.
- Clicking a visit still opens its station, and clicking an ASC case still opens the case.
- **New patient** right inside the dialog: create the chart (same Add New Patient routine), and the patient is put straight into the appointment.
- Warnings, which don't block booking: the provider is **at the ASC** (block time) at that hour, or the time **overlaps** another visit.
- The **Add visit** button still works as before. The double-click from v0.4 is replaced by a single click.

### C. Patient chart: Profile and contact information
- A **Profile** button next to the patient's name, and **Edit profile & contact** on the new Contact line, open **Profile & contact**:
  - Identity: first and last name, date of birth, sex, preferred language.
  - Contact: mobile phone, other phone, email, **preferred contact for reminders** (Text / Email / Text and email / Phone call only), street, city, state, ZIP.
  - Emergency contact: name, relationship, phone. Seeded one-line contacts are split into these fields automatically.
  - Billing & referral: payment type, plan, member ID, referral source, referred by.
- Fields are validated (date, phone and ZIP masks, plus an email when email reminders are chosen).
- **Save is audited** as `patient.profile`. The entry lists the fields that changed, with values for non-sensitive ones (name, payment type, referral, preferred contact). It shows who saved it and when.
- Saving the profile is not a signature, so it doesn't ask for a PIN. It's recorded under the tablet session.

### D. Appointment reminders and confirmation (simulated)
- **Every booked office visit** gets:
  1. **Confirmation requests** at a regular interval **until the patient confirms**. The default is **every 48 h, up to 4 requests**, and the first one goes out when the visit is booked.
  2. **One reminder the day before** the appointment (default **10:00 AM**), whether or not the visit is confirmed. If it isn't confirmed, this message asks again.
  - **Quiet hours:** no automatic messages from 8 PM to 8 AM. A message due then waits until 8 AM.
  - **Channel** follows the patient's preferred contact. "Phone call only" sends nothing automatically, and the visit shows **Call to confirm**.
- **Ways a visit gets confirmed:**
  - The patient replies **C** (simulated with a button), or **R** to ask to reschedule.
  - The patient taps **Confirm** in the portal (Appointments).
  - The front desk marks it **Confirmed (called)**.
  - A confirmation can be cleared, and reminders resume.
- **Where you see it:**
  - Schedule: each visit block shows **✓ Confirmed** or **? N sent**. A new **Appointment confirmations · next 14 days** table shows status, sends, the next send time, a "Not confirmed only" filter and a **Reminders** button.
  - Today: each card has a status badge. Tap it to open the reminder detail.
  - Chart: a **Next appointment** line with the status and a **Reminders** link.
- The **Reminders** dialog shows the visit, status, channel and next scheduled send. It lists every message with the exact text, time, recipient and who sent it. Buttons: Mark confirmed, Simulate reply C / R, Clear confirmation, **Send reminder now**.
- **Settings** (Practice › Visit types, intake lists & reminders › **Appointment reminders**):
  - reminders on or off
  - request interval (12 h / 1 / 2 / 3 / 4 days)
  - stop after N requests
  - day-before reminder on or off, and its time
  - Audited as `reminder.settings`.
- **Audit:** every send (`reminder.send`, including automatic ones under "Scheduler (automatic)") and every confirmation change (`appointment.confirm` / `appointment.unconfirm`).
- **How it runs in this build:** the scheduler runs when the app opens and every minute while it's open. It catches up on anything that came due while the app was closed, and stamps each message with the time it was due. In production this is a server job (see Henry, below).

---

## How to test (double-click `index.html`; PIN 1234)
1. **Today › Add New Patient.** Fill in the name, DOB, gender and phone, then press **Create** without a payment type: it asks for one. Choose **Medicare**, enter a plan and member ID, choose **Physician referral** and a name, then press **Create Patient Chart** (send the forms or **Not now**). The chart's Contact line shows Payment and Referral.
2. **Profile** (next to the name). Add an address, an emergency contact and an email, and set Preferred contact to **Text and email**. **Save**: the Contact line updates. Audit trail: `patient.profile`.
3. **Billing** (chart): the payer line is at the top.
4. **Schedule.** Click an empty spot, e.g. 3:30 PM in Dr. Whitfield's column. New appointment opens with today, 03:30 PM and Dana Whitfield filled in. Search the new patient (or press **New patient**) and press **Book appointment**. The toast says reminders are scheduled, and the block shows **? 1 sent**.
5. Scroll to **Appointment confirmations**. **Marisol Sampleton, tomorrow 10:00 AM** (follow-up) shows several requests and the day-before reminder with no answer. Open **Reminders**, read the messages, then press **Simulate patient reply "C"**: Confirmed.
6. Open your new appointment's **Reminders** › **Send reminder now** › **Mark confirmed (called)**. The schedule block turns **✓ Confirmed**.
7. **Today:** every card shows Confirmed or Not confirmed. Tap a badge to open the details.
8. **Portal › Tomas** › Appointments › **Confirm** next to his pre-surgical consult in 5 days.
9. **Practice** (unlock as Pat Quinn) › **Visit types, intake lists & reminders.** Edit the payment-type or referral list, and change the reminder interval to 1 day. Both are audited.

---

## Notes for Henry (backend contract)
**Patient profile**
- `PATCH /patients/{id}` with `first_name, last_name, dob, sex, language, phone_mobile, phone_other, email, preferred_contact (sms|email|sms_email|phone), address{line1, city, state, zip}, emergency_contact{name, relationship, phone}, payment_type, insurance{carrier, member_id}, referral{source, referred_by}`.
- The server writes the audit row with the changed-field list. Name and DOB edits must re-run the ASC network match (cases are matched by name + DOB).
- `GET/PUT /practice/intake-lists {payment_types[], referral_sources[]}`. Store the chosen value as text on the patient, so retired list entries survive.

**Appointment reminders**
- Tables:
  - `appointment_confirmations(visit_id PK, status confirmed|reschedule, via patient_reply|portal|staff_call|staff, by, at)`
  - `reminder_messages(id, visit_id, patient_id, kind confirm_request|day_before|manual, channels[], to, body, due_at, sent_at, attempt, provider_message_id, delivery_status, sent_by)`
  - `practice_reminder_settings(enabled, interval_hours, max_requests, day_before bool, day_before_time, quiet_start, quiet_end, tz)`
- Job (every 5 min, practice time zone). For each `visits.step='scheduled' AND start > now`:
  - If the visit is unconfirmed and `requests < max`, the next request is due at `last_request + interval` (the first one at booking time). Move it out of quiet hours. Skip it if it lands on or after the day-before time or the visit start.
  - The day-before reminder is due `(visit_date − 1) @ day_before_time`, once. Skip it if the visit was booked on the visit day.
  - Mark rows sent idempotently (`unique(visit_id, kind, attempt)`).
- SMS and email go through a **BAA-covered vendor**. Keep message bodies to the minimum necessary: practice name, date, time and provider, with no diagnosis or procedure detail (this build includes the visit type; review that with compliance). Honor STOP / opt-out (TCPA), and keep quiet hours in the patient's local time.
- **Inbound:** an SMS webhook maps `C`/`Y`/`YES` → confirmed and `R` → reschedule, then notifies the front desk. A portal confirm link uses a single-use signed token (`#confirm=<visit>` is only the test stand-in).
- Moving or cancelling a visit should clear its confirmation and its pending reminders.

## Rough edges / known limits
- **Reminders only run while the app is open** (this is a browser test build). It catches up when reopened and stamps each message with its due time. No real text or email is sent.
- Patient replies are simulated with buttons. The confirm link inside the message opens the app, not a confirm page; patients confirm in **Portal › Appointments**.
- The visit's own time doesn't count as "past" until it starts. A visit whose time has already passed today shows no badge, even if it was never confirmed.
- Quiet hours (8 PM – 8 AM) are fixed, not a setting yet.
- There is still no "move / cancel visit" screen, so the "clear confirmation on reschedule" rule is in the contract, not the UI.
- Message text includes the visit type (e.g. "post-op follow-up"). Decide with compliance whether to drop it.
- Profile edits and appointment confirmations are audited under the tablet session (no PIN). Renaming a patient can unlink a seeded ASC case, which is matched by name + DOB.
- The schedule is still day view only. On a touch tablet there is no hover marker; a tap books directly.
- Payment type is required for new patients only. Older charts show "not recorded" until someone edits the profile.
