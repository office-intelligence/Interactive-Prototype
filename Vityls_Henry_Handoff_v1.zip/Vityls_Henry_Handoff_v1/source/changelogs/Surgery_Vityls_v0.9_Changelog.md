# Surgery.Vityls v0.9 — Changelog (2026-10-12)

Built from tag `surgery-v0.8` on branch `surgery`. ASC, MED, `src_v5`, the med tag and the ASC/MED zips are untouched.
Shared v6 code only received opt-in hooks (inactive unless the Surgery app installs them). Fictional data only, and all sends are simulated.

## 1. Scheduler
| Feature | Where / how |
|---|---|
| Day / Week toggle | Schedule header, `Day · Week`, remembered per browser. The week runs Monday–Sunday, with one column per day showing the selected columns. |
| Print | The **Print** button prints the current day or week in landscape. It adds a clean header (practice, view, columns, printed time) and hides navigation, controls, toasts and Nightingale. Recorded in the audit as `schedule.print`. |
| Column picker | **Columns** shows a multi-select of providers, team members and rooms. It controls which columns appear and is saved per browser. |
| Team-member & room columns | Default columns are the providers, an RN, an MA, the Surgical Coordinator and the rooms. **Manage columns…** (also under Practice › Settings › Schedule columns) adds or removes team members (any role, e.g. PA-C) and rooms. Any column can be booked for itself: click an open slot. |
| Office events | **+ Office event** offers staff meeting, in-service/training, luncheon, office closed, holiday and other. Timed events show as a striped lavender band across every column. All-day events sit in a banner above the grid. Click an event to edit or delete it (delete asks for confirmation). Optional repeat: daily, weekly or monthly, with an optional end date. Recorded as `schedule.event`. |
| Double-booking | Allowed. Overlapping visits are laid out side by side in lanes with a small "double-booked" tag. The booking dialog shows a light notice ("Double-booking: … That's allowed") and never blocks. |
| Kept | Visit popup, click-an-empty-slot booking, reminders/confirmations, ASC block time and cases, type colors. |

## 2. Nightingale card
The card background is now `#dcebe3`, a slightly deeper green, with border `#bcd6c8`, heading `#174a41` and text `#16241f`. It is applied wherever `.v7-ng` renders (Today, chart, stations, portal). Text contrast is above 10:1, well over AA (checked in the tests).

## 3. Form headers
- All 32 bundled templates are kept, and the Surgery catalog still offers the same 10.
- Every Surgery form now has a letterhead header, on screen and in print:
  - practice name, address and phone, plus a "Patient form" label;
  - the form title;
  - a row with patient, DOB, MRN and date.
- Styling: Public Sans, 3px corners, hairline rules.
- Old heavy bars (green page-head blocks, the filled `.who` strip, tinted section banners) become hairline uppercase section labels. This covers the `packet-container`, `sheet` and `vityls-patient-header` template families.
- In print the header turns into a single ruled letterhead.

## 4. Form editor

### 4a. Evaluation of the previous editor (Form Studio / FullScreenFormCustomizer)
1. **Not practice-scoped.** Customizations were stored under one global key per file (`vityls-master-form-template:<file>`), so no per-practice copy existed. This doesn't work for SaaS.
2. **Fragile HTML patching.** Edits rewrote raw template HTML with string and DOM patches. There was no schema, so the structure was easy to break.
3. **Very few operations.** You could rename a label, toggle required and remove a field. You could not add typed fields, add sections, duplicate or reorder.
4. **No layout control.** There were no column or width settings.
5. **No conditional logic, defaults, help text or prefill binding.**
6. **No real preview.** There was no tablet or print preview.
7. **No undo/redo.** Version history was a weak snapshot list with no draft/publish distinction. A save went live immediately.
8. **Past filled forms were not protected.** Changing a template changed the forms patients had already started.
9. **No import/export or cloning.**
10. **Poor on tablets.** It had small targets and no touch-friendly layout.

### 4b. New: Practice › Form templates & editor
- **Library.** Every template in the catalog is listed with status (Original / Draft / Published vN), plus search, Edit and Clone.
- **Practice-scoped storage.** `form-lib[practiceId][file]` holds versions, published, draft, an event log and clonedFrom. The bundled original is never modified, and **Restore original** keeps the version history.
- **Draft → Publish.** **Save draft** is private. **Publish** (with a note) creates version N. Each version is kept and can be republished.
- **Past forms are safe.**
  - Each patient's form is pinned to the version it was started on (`form-pins`); a form started before any practice version is pinned to the original.
  - Publishing never changes a started form. New patients get the current published version.
- **Editing tools:**
  - Add a field by tapping a palette item (it goes after the selected field) or by dragging it onto a section.
  - Reorder with drag and drop, the ↑/↓ buttons or Alt+↑/↓.
  - Duplicate (button or Ctrl+D) and delete fields.
  - Add, reorder and delete sections; each section can be 1/2/3 columns.
- **15 field types:** short text, long text, number, date, yes/no, single choice, multi choice, dropdown, signature, initials, checkbox, checkbox list, table/grid, heading/instruction, and prefill-bound (patient name, DOB, allergies, medications, MRN…).
- **Properties panel:** label, type, prefill source, help text, required, options, default, width (1/2/3), placeholder, show-if (field + equals / not equals / checked / filled + value), and an advanced field key.
- **Live preview:** tablet and print, using the real form chrome and a sample patient. Show-if and prefill work in the preview.
- **Other tools:** undo/redo (Ctrl+Z / Ctrl+Y), field search with an outline, clone template (creates a practice-only copy), and export/import as JSON (`vityls-form-template`).
- **Publish validation** checks for unique keys, options on choice fields and show-if links that point nowhere.
- **Tablet behavior.** Below 1100px:
  - The palette and search become a compact sticky strip.
  - Properties open as a bottom drawer.
  - The selected field auto-scrolls above the drawer.
  - Touch targets are at least 40px.
- **Audit:** `form.template.save | publish | restore | import | clone`.

## Other fixes
- Fixed a v0.8 bug: the quote print CSS hid the whole page for *any* print. It is now scoped to an open quote preview, so schedule and form printing work.
- At widths under 1280px the top bar keeps every nav item visible while the Practice-open pill shows.

## How to test
1. **Schedule:**
   - Toggle Day/Week.
   - Open **Columns** and tick an RN and a room, then click an open slot in the RN column to book her.
   - Book a second visit at a time that's already taken: you get a notice, not a block.
   - Add a weekly staff meeting, then edit and delete it.
   - Press **Print**.
2. **Today:** the Nightingale card is the deeper green.
3. **Forms:** check in a patient, open an intake form and look at the letterhead. Print it.
4. **Practice › Form templates & editor:**
   - Open Medical History.
   - Add a Yes/No field and a Long text field with show-if.
   - Preview it on tablet, then publish.
   - Open the patient's form again: it is still on its pinned version.
   - Restore the original. Clone the template. Export and import JSON.

## Deviations / rough edges
- The old Form Studio (FullScreenFormCustomizer) is still reachable from Practice › Forms & workflow, for continuity. The new editor is the recommended path, and the two don't share storage.
- Cloned templates live in the practice library but are not yet added to the station catalog, so they can't be placed at a station yet.
- Template parsing from legacy HTML is best effort. Complex legacy layouts (multi-column tables, free-text paragraphs) come in as table or instruction blocks. Once a template is published, it renders from the schema with the original template styling.
- Drag and drop is HTML5 (mouse). On touch tablets, use tap-to-add plus the ↑/↓ buttons. Both are fully supported.
- Recurrence is simple: daily, weekly or monthly with an optional end date. There are no exceptions to single occurrences; editing changes the whole series.
- In week view each day is one column, showing the visits of every selected person or room together (side by side when they overlap). Clicking an empty slot books the first selected person; change the provider in the dialog.
- Practice id is fixed to `default-practice` in this single-practice test build. The storage is already keyed by practice.
