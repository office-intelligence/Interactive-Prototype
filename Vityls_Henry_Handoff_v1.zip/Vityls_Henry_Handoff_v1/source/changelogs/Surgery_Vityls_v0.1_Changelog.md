# Surgery.Vityls v0.1 — changelog (test build, fictional data only)

Built 10/09/2026 from MED.Vityls v0.1 (tag `med-v0.1`) on branch `surgery`, tag `surgery-v0.1`.
Repo: `/workspace/vityls/src_v6/vityls_final_build`. ASC.Vityls is untouched (see the end).

## Kevin's decisions this build follows
1. Three applications: ASC.Vityls (own package, frozen), **Surgery.Vityls (this build)**, Medical.Vityls (later).
2. Tablet targets 768×1024 and 1180×820 for the Patient Chart, Today (dashboard) and the Station Workflow. Admin, practice, billing and settings pages are laid out for a desktop.
3. Ambient scribe is simulated: listening indicator, live transcript, Nightingale drafts the note in the right column, the clinician reviews, edits, initials and signs. No microphone, no audio. A real scribe needs a BAA at go-live.
4. Nightingale sits in the same place at the top of every primary page. The chart opens with a living summary.
5. A small timeline sidebar of past and upcoming events sits above the fold; one click opens the result in the right panel. Care team, caregivers, network ASC, remote monitoring, journal and trends are Nightingale destinations or right-panel pulls, not permanent cards.
6. Seamless white canvas, bold headings, no stacked card borders. Print-like, mostly black and white with light-gray rules. Color only for hover, the configurable visit-type colors and clinically important information (allergies, results to review). The right panel uses the lab-slip house style: white, small type, minimal.
7. Scheduler: configurable visit-type colors (light blue = new patient, light green = follow-up). ASC-booked surgeries and the surgeon's block time appear on the office schedule automatically. Today copies the ASC structure, with expanded patient cards and Check in / Open.
8. Stations: new-patient intake = links to ASC Form Studio forms; check-in = ASC check-in model; nurse intake = a short Surgery.Vityls nurse admission form; surgeon = ambient scribe (not forms); checkout = surgical scheduling, follow-up and pre-op clearance.
9. Admin, billing, operations and practice configuration are kept. No dead ends; progressive disclosure; keyboard and screen-reader labels.
10. Surgical features are modules. Brand: Surgery.Vityls. Internal edition flag `SURGERY`.

## New
- **Edition `SURGERY`** (`src/edition.ts`) with its own storage namespace (`vityls-surgery~`), so Surgery, MED and ASC test data never mix. The build defaults to Surgery. `?edition=surgery|med|asc` and `?reset-test-data` work as they do in MED. The edition card lists all three.
- **App shell** (`src/surgery/SurgeryApp.tsx`, `surgery.css`): thin top bar (Today · Schedule · Patients · Messages · Practice, Acting as, Portal, SIMULATION stamp), the Nightingale bar in one fixed place on every page, one right panel for every source (docked at ≥1100 px, slide-over below that, bottom sheet on a portrait tablet).
- **Nightingale** (`nightingale.ts`, `ui.tsx`): on-device and scripted. Answers carry citation chips that open the source in the right panel. "Likely next" steps for each page and role. "Keep in living summary" saves an answer to the chart (audited). Press-and-hold mic shows how voice questions would work (simulated). Destinations include care team, caregivers, monitoring, journal, trends, audit, billing, care plan, ASC, labs, meds, risks, history and notes.
- **Patient chart** (`SurgeryChart.tsx`): a timeline sidebar (Upcoming / Today / Past: ASC cases, visits → notes, lab slips marked *new*, vitals, messages, ASC thread, care plan, caregiver access) and a **living summary**: who and why, significant conditions with their latest values and linked meds, surgical history, major risks (surgeon-reviewed count), active problems, "worth your attention" items, kept Nightingale notes, and hold-to-initial attestation for providers. The fingerprint changes when the summary content changes. Each line cites its source.
- **Right panel** (`panel.tsx`): lab slip in the house style (values over time without interpretation, provider review and release to portal with a patient note, older/newer navigation), visit note sheet, risk awareness, allergies, intake, meds, care plan, caregivers, journal, trends, audit, billing, ASC thread and consent, care team, messages with reply, vitals, conditions, visits. The heavy MED screens are reused inside the panel, so no MED feature was lost.
- **Station workflow** (`SurgeryStation.tsx`). Steps: Intake forms → Check-in → Nurse intake → Surgeon → Checkout → Visit record. Each step is verified with your name and the time.
  - Intake forms: patient-portal forms from My Forms (Form Studio). Queue a link by email or text into a **simulated outbox** (nothing is sent; audited), or fill the forms on the office tablet.
  - Check-in: identity confirmation, Arrived / Checked-in timestamps (ASC event bar), front-office forms, allergy confirmation.
  - Nurse intake: **short native nurse admission form** covering reason in the patient's words, pain 0–10, vitals with calculated BMI, allergies and meds confirmed, last dose of antithrombotic / GLP-1 meds (only when the patient takes them; recorded, no hold window), last food and drink for a procedure, escort, fall question and nurse note. Vitals go into the chart.
  - Surgeon: **simulated ambient scribe**. Requires the patient's agreement. Start, pause, end, or "Demo: skip to the end". The live transcript is scripted from the chart (pre-op, new-patient and post-op scripts). Nightingale fills HPI / Exam / Assessment / Plan as the talk goes on. Possible orders it "heard" (pre-op clearance, surgery booking, follow-up) are **hold-to-initial** for providers and go to checkout as to-dos; swipe left to dismiss. Review & edit, accept as the note draft, sign with PIN (1234). Nightingale cannot sign or order.
  - Checkout: to-dos from initialed suggestions, or add your own. **Surgery booking** picks from the surgeon's ASC block time and sends a booking request (simulated), which appears on the schedule and in the ASC thread; or confirm an existing ASC case. **Follow-up** books a visit by colored visit type. **Pre-op clearance** prints a request letter (sending is simulated). Also AVS (print on demand) and the invoice from the fee schedule.
  - Visit record: nurse admission, scribe use, checkout outcomes, verification, timestamps, signed note fingerprint, full audit.
- **Schedule** (`SurgerySchedule.tsx`): day grid by provider in the practice's **visit-type colors** with a legend. **ASC block time** shows as a dashed band and **ASC cases** as hatched blocks, both placed automatically. Visits that fall inside a block are flagged "During ASC block". There's an "At the ASC · next 3 weeks" list and an add-visit dialog with colored visit-type buttons that set the length.
- **Today** (`SurgeryDashboard.tsx`): expanded patient cards with a color stripe, time, name, age, gender, phone, reason, visit type, provider and room, station status, allergies (red), results to review and days to surgery. **Check in / Continue** opens the station and **Open** opens the chart. Filters: All / Not arrived / In office / Done, plus provider. Also a needs-attention list (results, pre-surgery risk reviews, unsigned notes, checkout to-dos, portal messages) and "At the ASC · next 7 days".
- **Practice → Visit types & colors · surgical modules** (`SurgerySettings.tsx`): edit name, color (palette or picker), minutes, category, surgical flag and active flag. Renaming carries over to booked visits. Practice managers and administrators can edit; others see it read-only. Module switches: risk awareness, affiliated ASC, block time, surgery booking, pre-op clearance, ambient scribe. The **Medical preset** turns the surgical modules off; the Surgery preset turns them on. Changes are audited.
- Data layer additions (`store.ts`): visit types, modules, nurse admissions, scribe sessions, checkout orders, intake-link outbox, surgical history, summary initials and kept notes, ASC blocks, booking requests. New audit actions: intake.link, nurse.admission, scribe.*, checkout.order, summary.initial, visittype.settings, module.settings, network.booking, checkin.identity.

## Reused from MED.Vityls v0.1 (unchanged behavior)
Patient record repository, seed (6 fictional patients, Coastline Plastic Surgery), risk awareness and reviews, labs review/release, care plan, caregivers, portal (Portal link), messages, network ASC thread and consent, billing/invoice and fee schedule, Form Studio / My Forms / FormPage, the ASC event bar, PIN signing (`SignNoteDialog`, PIN 1234), Practice workspace (admin, billing, workflows), MED practice settings (fees, risk triggers, results, portal).

## Revised
- MED visit types were remapped in the Surgery namespace only: New patient consultation, Follow-up visit, Pre-surgical consult, Post-op follow-up, Pre-op clearance consult, Office procedure. The Surgery fee schedule has one line per type (placeholder prices).
- `seedMedData()` takes a version and an after-seed hook. `MedVisit.tsx` / `MedChart.tsx` export existing pieces for reuse; nothing else in them changed.
- Inside Surgery.Vityls, global headings use the sans face and chips are not forced to 44 px (scoped overrides; MED and ASC styles are unchanged).

## Deferred / not in v0.1
- Medical.Vityls package (only the preset exists). Real speech, a BAA-covered scribe vendor, real email/SMS and real ASC booking are all simulated.
- ASC.Vityls does not store block time yet, so blocks are fictional seed data clearly labelled "fictional". If a future ASC build writes `vityls:evaluation:block-time`, Surgery reads it.
- Week and month schedule views, drag to reschedule, rooms as columns.
- Remote monitoring (the panel says "coming later"), registries, e-prescribing, real clearance-letter fax.
- Fee lines are matched to visit types by name. If a visit type is renamed, update the fee schedule too.

## How to test (about 10 minutes)
1. Unzip `Surgery_Vityls_v0.1.zip` and double-click `index.html`. Every provider's PIN is 1234. Use **Acting as** to switch roles.
2. **Today**: look at the colored cards. Tap **Open** on Ellen Testwood. The chart shows the living summary and the timeline on the left. Tap "Lab slip · A1c…" in the timeline; the slip opens on the right.
3. Ask Nightingale: "is she on blood thinners?", "care team", "what changed", "surgical history". Tap a citation chip. Tap "Keep in living summary".
4. Tap **Check in**. Confirm identity → **Verify check-in**. Fill the nurse form → Save → **Verify nurse intake**.
5. Acting as **Sam Patel, MD**: tick the patient agreement → **Start listening**. Watch the transcript and the draft fill in. **End visit conversation**. Hold each suggestion to initial. **Accept draft as note** → **Sign with PIN** (1234) → **Verify surgeon**.
6. Checkout: request the booking in a block (or confirm the existing case), book the follow-up and prepare the clearance letter → **Verify checkout**. The visit record shows the trail.
7. **Schedule**: the colors, the dashed ASC block and the hatched cases; "At the ASC · next 3 weeks" lists your booking request. **Add visit** and pick a colored type.
8. **Practice → Visit types & colors · surgical modules** as **Pat Quinn (Practice Manager)**: change a color and save, and the schedule and Today follow. Try the Medical preset; the ASC layer and surgical checkout options disappear.
9. Tablet: open at 768×1024 or 1180×820 (DevTools device mode). On a portrait tablet the right panel becomes a bottom sheet.

## Verification
- TypeScript (`tsc --noEmit`): 39 errors, the same 39 pre-existing ones as `med-v0.1` (App.tsx, IsolatedHtmlFormRenderer, PatientChartPage…). None in `src/surgery`.
- Headless smoke test (Chrome) at 1180×820 and 768×1024: 36/36 checks passed with no JS errors. Covered: Today → chart → Nightingale answer → lab slip panel → check-in → nurse intake → scribe → initial suggestions → sign with PIN → checkout (booking request, follow-up, clearance) → complete → schedule shows the booking → messages, patients, practice, settings.
- Screenshots: `report/surgery_v01_screens/` (`1180_*` and `768_*`, 13 each).

## ASC.Vityls untouched
No changes to `src_v5`, the `v7.x` tags or any ASC zip. `med-v0.1` is unchanged. All work is on branch `surgery`. The shared `edition.ts` only gains the third edition, and an ASC reset keeps `vityls-surgery~` data, just as it keeps MED data. ASC packages are built from the `v7.x` tags, so the ASC packaging cannot change.
