# Medical.Vityls v1.0 — Changelog (2026-10-13)

## Approach
Medical.Vityls is a fourth **edition** (`VITE_EDITION=MEDICAL`) of the shared Vityls codebase, built from Surgery.Vityls v0.13 on branch `medical` (commits baa6f74..HEAD, tag `medical-v1.0`).
- **Edition switch** (`src/edition.ts`): MEDICAL runs the Surgery code paths with its own storage namespace (`vityls-medical~`) and its own image database, so Surgery, ASC and MED test data in the same browser are untouched.
- **Feature gating** (`isMedical` checks, `src/surgery/medical/index.ts`): ASC features, surgery booking, Send to ASC, ASC threads/notes and the "Next surgery" column are switched off.
- **Terminology layer** (`src/surgery/medical/terms.ts`): surgical wording is translated wherever text leaves the app — live DOM (incl. form iframes), print windows, PDFs (schedule, packets, quotes), page title and dialogs. User-typed text is never changed. Clinical-history terms (e.g. "Past surgical history") are kept on purpose.
- **Medical seed** (`src/surgery/medical/data.ts`): fictional primary-care practice (Bayside Family & Internal Medicine) with chronic-care diagnoses and plans.

## What changed vs Surgery.Vityls v0.13
- Surgeon → Doctor; Surgeon/Physician → Doctor; Surgical coordinator → Care coordinator; Surgical risk → Significant risk.
- Diagnosis & Procedure → **Diagnosis & Plan** (treatments, orders, referrals). Performed → Completed, Not performed → Planned. Patients column, filter and Practice report follow.
- Pre-op clearance packet for ASC → **Referral packet to specialist**; consult-report hint no longer references an operative note.
- Signer and staff roles: office roles only (no OR, PACU, Anesthesia).
- Quotes catalog and terms, HIPAA release seed, Nightingale suggestions and CSV exports use primary-care wording.
- Everything else (Today, Schedule, chart, Notes, photos, ID/insurance cards, stations, forms editor, Forgot PIN, message attachments, hide/delete, Print/Send, HIPAA release) is unchanged from Surgery v0.13.
- Final wrap-up: seed data adjusted so shared diagnoses (hypertension, hyperlipidemia) show a mix of completed and planned in the report.

## Residual terms (kept on purpose)
- **"Past surgical history" / "Surgical history"** on the chart: a standard history section in primary care.
- **"Prior problem with anesthesia (patient-reported)"** in history/risk factors: a real history item a medical office records.
- The built bundle still contains ASC/Surgery strings (ASC library forms, PACU and anesthesia records, surgical consents) because one codebase serves all editions. A runtime audit of Today, Schedule, Patients, Messages, Practice and every chart tab found no other surgical wording on screen.
- Some screenshot filenames from the shared test suite still say "surgeon" (e.g. `1180_78_surgeon_dx_suggestions.png`). Only the filename; the screen says Doctor.

## Tests
- Build: `VITE_EDITION=MEDICAL vite build` + `scripts/package-medical.mjs` → OK (single 6.5 MB index.html).
- Typecheck (`tsc --noEmit`, larger Node stack): 39 errors in 10 files, all in files that the Medical commits didn't touch (PatientPortalPage, VitylsNextWorkspace, mockData…). They were already there and don't affect the Vite build.
- Smoke suite (`surgwork/med10/smoke13.py`, 1180×820): **369 / 370 pass**, no page errors.
  - Fail: "pk: one combined PDF…" expects a `12-lead ECG` document from the Surgery pre-op preset. The Medical referral preset/seed doesn't include it, so this is a mismatch with a Surgery-specific expectation, not an app error. The cover, letter, table of contents, medication list and summary sheet were all present.
- Screenshots: `report/medical_v10_screens/` (166 files; Medical-specific views are prefixed `1180_m…`).

## Rough edges
- The pool of extra generated test diagnoses (`MEDICAL_DX_POOL`) is unused because the Medical seed has no generated `MED-####` patients. Only the named patients carry diagnoses.
- Same as Surgery v0.13: body charts go into packets as text, Word/HEIC files are listed but not embedded, and you have to click Redraft after reordering a packet.
- Images and attachments live in the browser until the real database (Vityls Core) is connected.
- The HIPAA release legal text still needs review by counsel.
