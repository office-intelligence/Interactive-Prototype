# Surgery.Vityls v0.10 — Changelog (2026-10-13)

Built from `surgery-v0.9` on branch `surgery`, tag `surgery-v0.10`. These are Kevin's corrections to v0.9. ASC, MED and src_v5 behavior is unchanged (see "Shared files" below). All data is fictional.

## 1. Scheduler
- **Any appointment length.** The New appointment and Appointment detail popups both have a **Length (minutes)** box, with −5/+5 buttons and free typing from 1 to 720 minutes, plus an **End time** box. Change either one and the other updates. The visit type still sets the starting length, but it's only a default. (`src/surgery/v10/VisitLength.tsx`)
- **One column selector.** The duplicate "+ Column" dropdown is gone. Only the **Columns ▾** selector next to the date remains. It lists all providers and doctors, team members (nurses, MAs, coordinators) and rooms, and links to "Manage columns…". The × on each column header still hides that column.

## 2. Schedule print (replaces the v0.9 window print)
This follows the ASC logic: **Print** opens a popup, you choose the options, and you print or download from the popup. (`src/surgery/v10/SchedulePrint.tsx`)
- **Options:** Day or Week, a date (in Week mode, any day in that week), and providers: **All** or any selection of providers and team members.
- **PDF:** a real PDF is generated with pdf-lib and shown inside the popup in the browser's PDF viewer. It's US Letter landscape, with the practice name, the title (day or week range), the providers included and the count.
  - It has one table per provider with the columns **Date · Start time · End time · Patient name · Age · Gender · Reason for visit · Notes**.
  - Notes carries the visit type, room, length, confirmation status and a double-booked flag. Visits don't have a separate notes field (see Deviations).
  - Office events are listed at the end. The footer has the page number, print time and "fictional test data".
- **Buttons:** **Print** prints the PDF from the popup, and **Download PDF** saves `Schedule-YYYY-MM-DD.pdf` or `Schedule-week-YYYY-MM-DD.pdf`. Both are audited (`schedule.print`).

## 3. Forms
- **Form Studio is replaced.** Practice › Forms & workflow is now a Surgery copy of the ASC Forms & Workflow page (`src/surgery/v10/SurgeryFormsWorkspace.tsx`). It keeps the ASC behavior:
  - My Forms, Form Library and Practice PDFs work as in ASC.
  - "Add to My Forms" is the same two steps: **1. Assign to station + requirement**, **2. Signers** (the same `SignerSetup` component, stored with `repo.saveSignerConfig`).
  - Storage keys are unchanged (`vityls-form-workflow:*`, `vityls-my-forms:*`, the signer config), so existing setups carry over.
  - The only change from ASC is the **Customize / Customize Form** button. It now says **Edit form** and opens the **new form editor**. The old FullScreenFormCustomizer can no longer be reached from Surgery.
  - The Form Library and the editor read the same catalog (`formLib.catalog()`), and published editor versions are what the stations open.
- **No Signature / Initials field types in the editor.**
  - The palette no longer offers them, and imports drop them.
  - When the editor reads an older template, signature-like inputs are skipped.
  - Existing drafts and published versions that contain signature or initials fields have those fields removed when they're opened, published or restored (`stripSignatures`). Any conditions that pointed at them are cleared too.
  - Signatures and initials now come only from each form's station signer setup. Filled forms keep the version they were started on (v0.9 pinning).
- **No Clone.** The Clone button and practice-copy listing are gone. To use a form in more places, assign the same template to as many stations as you need.
- **Patient Registration** now says **First Name** and **Last Name** instead of "Legal First Name" and "Legal Last Name" ("Legal First and Last Name" is handled too).
  - This is a Surgery-only wording transform on all form HTML (`formSourceHooks.transform` → `surgeryWording`), so it applies to the station form, portal, editor, preview and print.
  - Field names and prefill bindings (`firstName`, `lastName`) are unchanged.
  - ASC wording is unchanged.

## 4. Workflow stations (Surgery: 4)
| Surgery station | Storage key | Used by the visit steps |
|---|---|---|
| Portal / At-home | `patientPortal` | Intake forms (portal / text link) |
| Front desk | `frontOffice` | Check-in, and checkout (checkout shares the Front desk; no separate station needed) |
| Nursing | `nursing` | Nurse intake |
| Doctor | `surgeon` | Surgeon / provider visit |

ASC-only stations (Anesthesia, OR Team, PACU / pre-op) are never shown in Surgery's station lists, the Stations & Assignments tab or the assignment step.

A one-time migration (`migrateSurgeryStations`) moves any old Surgery assignment on those keys: anesthesia → Doctor, OR team / PACU → Nursing. Labels and storage are in `src/surgery/v10/stations.ts`.

## 5. Diagnosis / procedure (added scope)
- **Patients list:** the **Allergies** column is replaced by **Diagnosis / Procedure**. It shows the primary surgical diagnosis or condition, the procedure, and a status pill: *Performed* (with date) or *Not performed*. Allergies are still on the chart header and at every station.
- **Filter** above the list:
  - Diagnosis / condition, and optionally a procedure (the list narrows to that diagnosis's procedures).
  - Status: All / Procedure performed / Not performed.
  - It shows the matching patient count and the filtered list, with a Clear filter link. Name search still works alongside it.
- **Practice › Practice performance & reports › Diagnoses & procedures** (new, first in the Reports grid):
  - Count by diagnosis, split into Performed / Not performed / Total, with a bar.
  - Click any count to drill down to those patients, with links to their charts.
  - **Export CSV** gives the summary plus a patient list. **Print** prints the report.
- **Fictional seed** (one per demo patient, consistent with their existing visits and ASC cases):

  | Patient | Diagnosis | Procedure | Status |
  |---|---|---|---|
  | Ellen Testwood | Dermatochalasis | Upper blepharoplasty | Not performed |
  | Marisol Sampleton | Abdominal wall laxity | Abdominoplasty | Not performed |
  | Robert Fictus | Facial rhytides | Facelift / necklift | Performed 10/05/2026 |
  | Priya Demoshah | Dynamic forehead rhytides | Neuromodulator | Performed 07/14/2026 |
  | Grace Placeholder | Basal cell carcinoma, cheek | Mohs reconstruction | Not performed |
  | Tomas Exampleton | Nasal deformity | Rhinoplasty | Not performed |

  New patients get a value derived from their ASC case when they have one.
- Storage is `patient-dx` in the Surgery namespace (`src/surgery/v10/dx.ts`, `DxReport.tsx`). The backend swap point is `patients.primary_dx` / procedures.
- **Rough edge:** there's no UI yet to set or edit a patient's diagnosis/procedure. It's seeded or derived for now; a chart edit (or Nightingale/visit-note pull) is the natural next step. With only 6 demo patients, each diagnosis has 1 patient.

## Shared files touched (ASC behavior unchanged)
- `src/v6/formSource.ts`: adds an optional `formSourceHooks.transform`. It's only set by Surgery, so ASC and MED are unchanged. This is the same pattern as the v0.9 `override` hook.
- No other ASC, MED or src_v5 files changed. `FormsWorkspacePage`, `FullScreenFormCustomizer` and `SchedulePrintModal` are untouched (Surgery uses its own copies).

## Tests
- `surgwork/v10/smoke10.py` runs every prior suite (v0.7 Today/Chart, v8, v9 minus the removed v0.9 print/clone checks) plus the new `v10part.py` at 768×1024 and 1180×820. `quick10.py` runs only the v0.10 part.
- Typecheck: the same 39 old errors, none in Surgery code.

## Deviations / rough edges
- Visits have no Notes field, so the PDF Notes column is built from the visit type, room, length, confirmation and double-booking. If you want a free-text appointment note, it's a small addition to the popups.
- In Chrome and Edge, Print opens the browser's PDF print. If a browser blocks printing from the embedded viewer, use Download PDF and print from there. A headless browser can't confirm the physical print dialog.
- Signer roles in step 2 are the ASC list, kept exactly as asked. Some roles (anesthesia, circulator) don't apply to an office.
- The old v0.9 window-print CSS (`.s9-print-head`) is no longer used. It's harmless and will be removed later.
- Practice copies (clones) made in v0.9 stay in storage but are hidden.
- Practice › Providers / Policies (legacy Administration screens) were not reviewed for Form Studio links. Surgery's own Practice menu no longer links to Form Studio.
