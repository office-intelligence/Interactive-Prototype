# Surgery.Vityls v0.6: changelog (test build, fictional data)

**Date:** 2026-10-11 · **Branch:** `surgery` · **Tag:** `surgery-v0.6` (built on `surgery-v0.5`)
**Unchanged:** ASC.Vityls, `src_v5`, the `med-v0.1` tag and every ASC/MED zip. The only shared file touched is `src/v6/dataLayer.ts` (new audit action names). Everything else is under `src/surgery/` plus `scripts/package-surgery.mjs`.

Surgery.Vityls is still a test build. It runs from `index.html` with no server, all data is fictional, and everything stays in the browser. Texts, emails, dictation and every "Nightingale summary" are **simulated** (on-device, rule-based or scripted; no AI service is called). Test PIN for every fictional person: **1234**.

> **No reset this time.** On first open, v0.6 adds its fictional documents and contact notes **once** on top of your existing v0.5 test data. `?reset-test-data` still starts over and includes them.

---

## What changed in v0.6

### A. Schedule: appointment detail popup
- **Click any visit** on the schedule. **Appointment** opens (instead of jumping straight to the station) with:
  - the patient (name, age, DOB, phone, payment type)
  - status: workflow step, confirmation badge and reminder count
  - the same fields as New appointment: visit type, date, time, provider, room, length and reason. They can be edited while the visit is still **Scheduled**.
- Buttons: **Open chart**, **Visit workflow** (the station, as before), **Save changes** and **Delete appointment**.
- **Saving a new date, time or provider** clears the confirmation and archives the old reminder history, so reminders start fresh for the new time. This is the "move clears confirmation" rule promised in v0.5. Audit: `appointment.update` with the before/after values.
- **Delete appointment:**
  - Opens a confirm step with a **reason** (Patient cancelled, Booked in error, Duplicate appointment, No-show, Provider unavailable, Other) and an optional note.
  - The person then **chooses their name and enters their PIN** (anyone on staff; PIN recommended, so it's required here).
  - The visit leaves the schedule, Today and the chart. A copy is kept in a deleted-appointments list for the record. Audit: `appointment.delete` with the reason, the visit details and who did it.
  - Only visits that haven't started (step **Scheduled**) can be edited or deleted. Once a patient is checked in, the popup is read-only and points to the visit workflow.

### B. Patient chart: Add or dictate a note (contact notes)
- **Add / dictate note** is in the chart heading for **every user** (front desk, MA, nurse, provider, manager). It isn't tied to an appointment.
- The **Contact note** dialog:
  - **Channel:** Phone call, Portal message, In person (walk-in), Email, Text message, Other. Choose **Incoming** or **Outgoing**.
  - **Reason:** Post-op concern, Medication / refill, Question about surgery, Scheduling, Billing / payment, Results, Records request, Other.
  - **Written by** defaults to the tablet session. The writer can pick their own name.
  - Time of contact defaults to now.
  - **Dictate** (simulated): text appears line by line as if spoken, with a per-reason script, then stays editable. No microphone is used and no audio is recorded.
  - **Flag for provider review** puts the note in the chart's "Worth your attention" and on the Records line.
- Each note is saved with the **author, role, tablet session, time of contact, time saved, channel, direction and reason**. It appears in the chart's timeline, in **Records › Contact notes** (right panel), and Nightingale can answer questions like "who called?".
- **PIN choice (documented as requested):**
  - **A staff contact note needs no PIN.** It's a record of a contact, not a clinical signature. Requiring a PIN would slow down the front desk on every call, and v0.5 already records such entries under the tablet session (profile edits, confirmations). The author's name is still stored and audited (`contact.note`).
  - **Optional "Sign as a clinical note (provider PIN)".** When a provider checks this, they choose their name and enter their PIN. The note is then marked **Signed by Dr. …** with a hash, and audited as `contact.note.sign`. Only providers can sign.
  - **Mark reviewed** on a flagged note also takes a provider PIN (`contact.note.review`), because it closes a clinical flag.
- Seeded: Ellen has a flagged post-op phone call from two days ago, and Robert has a text message.

### C. Documents folder on every chart
- A new **Documents** section on every chart (before Records & documents), and **Records › Documents** in the right panel.
- **Organized by type:** filter chips with counts. The default types are Clinical note, Laboratory, ECG, Imaging, Outside records, Referral, Consult / clearance letter, Operative report, Insurance, Consent / legal and Other.
- **The type list is configurable** in Practice › **Patient records** › Document types (one per line; audited as `document.types`). Retired types stay on the files that already use them.
- **The table** lists type, title, source, date and who filed it, with four icon buttons:
  - **View:** opens in the right panel. It shows the Nightingale summary on top, then the document (PDF viewer, image, text, or a fictional rendering for seeded documents).
  - **Download:** the original file. Seeded documents download as a .txt rendering.
  - **AI summary:** expands the Nightingale summary inline.
  - **Delete:** asks for a reason and removes the file from the folder. This is a soft delete: **Show removed** lists it, and it can be **restored**. No PIN is needed because nothing is lost.
  - Every view, download, add, remove and summary is audited (`document.*`).
- **Add document** (any user):
  - Choose a file (PDF, image or text, up to 3 MB in this build), then type, date, title, source and description.
  - On save, **Nightingale reads it right away**. Text and PDF files are read on the device (a PDF's text is extracted with pdf.js). Scanned images aren't read; the summary says so and uses the description.
- **Nightingale summaries (simulated, labeled):**
  - Each document gets a short summary: what it is, from whom and when, key statements, and medications named. It's labeled "Nightingale · on-device rule-based reading (simulated AI)", or "scripted summary" for seeded files.
  - **"Nightingale · all documents read together"** sits at the top of the folder: a few lines covering how many documents there are, the date range, and the facts that matter for surgery.
- **"Who" narrative in the heading:**
  - The chart heading's **Who · Nightingale** paragraph now ends with a brief **Outside records** sentence built from the documents. For Ellen it reads *"Outside records (6 documents, 10/2024–10/2026): Outside labs: glucose 148 (high per lab) …; Cardiology: acceptable cardiac risk, EF 60%; call cardiology before any clopidogrel change; ECG: sinus rhythm 68, no acute changes …; Referred by her PCP for heavy upper lids …"*
  - It **updates immediately** when a document is added, removed or restored.
- **Seeded fictional documents for Ellen Testwood (MED-1001):**
  - referral letter from her PCP (Lena Brooks)
  - 2024 sleep study (moderate OSA)
  - cardiology clearance letter (Omar Haddad)
  - ECG
  - outside labs (CBC/BMP)
  - Medicare card
  - Robert also has an outside operative report.
- Nightingale answers chart questions about documents ("what outside records do we have?", "cardiology letter?").

### D. Chart heading redesigned (ASC style)
- A **tinted heading** (warm parchment background with a gold left edge) sets it apart from the rest of the chart. It contains:
  1. **Name** and **age · DOB · gender** (plus MRN), with buttons for **Add / dictate note**, **Profile** and **Hide / delete**.
  2. **Why here:** the reason for the next or current visit and the planned procedure.
  3. **Who · Nightingale:** the brief narrative, including the outside-records sentence.
  4. **Brief history grid:** **Allergies** (with the verify-allergies control), **Medications**, **PMH**, **PSH** and **Significant risk factors**.
- The coordinator and account row stays underneath and now includes the visit workflow link.
- The small **"Add new patient"** link is **removed from the chart**. Add New Patient is still on Today, Patients and the schedule.
- Layout: the grid uses 3 + 2 columns at 1180 px and 2 columns on a 768 px tablet.

### E. Hide or delete a patient
- **Hide / delete** in the chart heading opens **Hide or delete patient**. **Hide** is the default.
  - **Hide (soft, recoverable):**
    - Choose a reason (Duplicate chart, Added by mistake, Test / training entry, Patient request (no care given), Other) and an optional note, then a **PIN from the Practice Manager, Practice Administrator or a provider**.
    - The patient disappears from every screen: Patients, Today, the schedule, search, the portal and Nightingale. Nothing is erased. Audit: `patient.hide`.
  - **Delete permanently:**
    - A second option in the same dialog. It warns that it can't be undone, and requires typing **DELETE** and the same Practice/provider PIN.
    - It erases the chart's clinical data in this browser: visits, notes, vitals, labs, messages, photos, forms, documents, contact notes and reminders.
    - It keeps a tombstone (name, DOB, reason, who, when, item count) and the audit trail. Audit: `patient.delete`.
- **Recover:** go to Practice › **Patient records** › **Hidden patients**. **Restore** brings the chart back with everything in it (`patient.restore`), and **Delete permanently** is also offered there. Both need the Practice/provider PIN. A **Permanently deleted** table lists the tombstones.

---

## How to test (double-click `index.html`; PIN 1234)
1. **Schedule.** Click Marisol's 10:00 AM follow-up tomorrow. The **Appointment** popup opens. Change the time to 11:00 AM and **Save changes**: the block moves and the confirmation resets. Open it again and press **Open chart**.
2. Back on the schedule, open any unstarted visit › **Delete appointment** › reason **Booked in error** › **Continue** › choose your name, PIN 1234. The visit is gone. Audit trail: `appointment.delete`.
3. **Patients › Ellen Testwood.** Look at the new tinted heading: demographics, Why here, Who (ends with "Outside records …"), then Allergies / Medications / PMH / PSH / Risk factors. There is no "Add new patient" link.
4. **Add / dictate note** › Phone call › Post-op concern › **Dictate**. Watch the text appear, check **Flag for provider review**, then **Save note** (no PIN). It shows in the timeline and in "Worth your attention". Write a second note, check **Sign as a clinical note**, and sign as Dr. Whitfield.
5. **Documents** (scroll down). Read the "all documents read together" summary. Click a type chip, then try **View**, **Download**, **AI summary** and **Delete** (with a reason) on the sleep study. The Who line in the heading changes. **Show removed › Restore** brings it back.
6. **Add document:** choose any PDF or .txt file, type ECG, and **Add to chart**. The summary appears at once and quotes the file's text.
7. **Ask Nightingale** (top of the chart): "what outside records do we have?", "who called?"
8. **Hide / delete** (heading) › reason **Test / training entry** › sign as Pat Quinn. The patient is gone from Patients and Today.
9. **Practice** (unlock as Pat Quinn) › **Patient records:** the patient is in Hidden patients. **Restore** brings the chart back. Try **Delete permanently** on a patient you created yourself; it moves to the Permanently deleted list. Edit the **Document types** list here too.

---

## Notes for Henry (backend contract)
**Appointments**
- `PATCH /visits/{id} {date, time, provider_id, visit_type, minutes, room, reason}` is allowed only while `step='scheduled'`. When date, time or provider changes, delete `appointment_confirmations` for the visit and cancel pending `reminder_messages` (they're kept as history, not deleted).
- `DELETE /visits/{id} {reason, note}` is a **soft cancel**: `visits.cancelled_at, cancelled_by, cancel_reason`. The row stays for the record and billing, and pending reminders are cancelled. Re-authenticate the signer (PIN step-up). Decide whether a "your appointment was cancelled" message goes to the patient; the test build sends none.

**Contact notes**
- Table `contact_notes(id, patient_id, channel, direction, reason, body, author_user_id, session_user_id, contact_at, created_at, dictated bool, flagged bool, reviewed_by, reviewed_at, signed_by, signed_at, signature_hash)`.
- Signing and reviewing need provider step-up auth. Once signed, a note is immutable; corrections are addenda.
- Real dictation goes through a BAA-covered speech service. The test build only simulates it.

**Documents**
- Table `patient_documents(id, patient_id, type, title, source, doc_date, description, storage_key, mime, size, sha256, filed_by, filed_at, removed_at, removed_by, removed_reason)`. Files go in encrypted object storage (no public URLs; short-lived signed download links).
- `GET/PUT /practice/document-types`.
- Summaries: `document_summaries(document_id, engine, model_version, text, created_at)` plus a folder digest per patient, generated server-side by a BAA-covered model (with OCR for scans). Regenerate on add/remove. Always label them as AI, and never let them overwrite clinical fields.
- Audit every view and download (HIPAA access log).

**Hide / delete patient**
- Hide: `patients.hidden_at, hidden_by, hidden_reason`. Every patient query filters `hidden_at IS NULL` by default; restore clears it.
- Hard delete:
  - A queued job with Practice-level step-up auth and a short undo window.
  - It must respect **record-retention law** (medical records usually have to be kept for years). In practice, only charts created in error with no care given should be eligible. Others should be hidden and retained.
  - Keep an audit tombstone. Billing and financial records follow their own retention.

## Rough edges / known limits
- **AI summaries are simulated.** Seeded documents use scripted summaries; uploads use a simple on-device rule-based extractor (key sentences plus medication names). Scanned PDFs and images aren't read (there's no OCR); the summary says so.
- PDF text extraction runs on the main thread (browsers block pdf.js workers from `file://`). It's fast for small files, and the 3 MB limit keeps it that way. It made `index.html` about 1.4 MB bigger (≈5.5 MB).
- Files are kept in the browser's local storage, so each file is capped at 3 MB and a few large PDFs can fill the browser's quota.
- **Dictation is simulated** (scripted text). No microphone is used.
- **Deleting an appointment sends nothing to the patient.** Call them if needed. Visits that have started can't be edited or deleted from the popup.
- Moving a visit archives its reminder history; the new time starts a fresh confirmation cycle.
- **Hard delete keeps the audit trail and the shared billing ledger lines** (financial-record retention). It only erases this browser's copy; ASC cases that were already sent aren't recalled.
- The heading's history grid repeats details also found in the living summary below (on purpose, for a quick glance).
- Contact notes are recorded under the writer's chosen name without a PIN (see B). An unsigned note is not a clinical signature.
