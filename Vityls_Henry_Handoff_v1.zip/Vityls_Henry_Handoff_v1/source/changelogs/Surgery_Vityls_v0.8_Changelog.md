# Surgery.Vityls v0.8 — Changelog

Built from tag `surgery-v0.7`, branch `surgery`, tagged `surgery-v0.8`. ASC.Vityls, MED, src_v5 and the ASC/MED zips are untouched. The only change to shared code is type-only: the new `quote.*` and `settings.quotes` audit action names were added to the audit union in `src/v6/dataLayer.ts`. Fictional data, test build.

## 1. The v0.7 design language across the whole app
- **App-wide shell** (`src/surgery/v07/v8.css`):
  - Warm gray page (#f6f7f4) with a white 1px-bordered sheet, max 1180px.
  - Public Sans everywhere, monospace only where it was mono before.
  - 3px corners on buttons, inputs, tables, cards, dialogs, panels and the shared Tailwind screens.
  - No thick left borders (the old 2–5px colored bars are now 1px hairlines).
  - Calmer table headers and the primary accent #1f5d52.
  - Corner radii in `surgery.css` were normalised to 3px.
- **Nightingale card on every page:**
  - Schedule, Patients, Messages, Practice and every station now show the v0.7 Nightingale card in place of the old gold bar. It has the same scripted answers, audit and likely-next chips.
  - Each page gets a one-paragraph brief (`v07/brief.ts`): schedule counts and the next ASC case, waiting portal threads, chart count and results waiting, the Practice command hint, and the station's visit summary with the never-signs / no go-no-go reminder.
- **Messages:** rebuilt in the v0.7 style (`v07/Messages8.tsx`). The data and behaviour are the same: office replies are recorded, ASC threads are simulated, and the `office-reply` / `office-send` testids are kept. This also fixes a v0.7 layout break at 768px.
- **Practice:** the PIN gate is unchanged. The hub, settings and admin screens use the new shell.
- **Stations** (intake, check-in, nurse, surgeon/scribe, charts & photos, checkout with invoices and collect payment, send to ASC, visit record): new shell and Nightingale card. The form bodies and headers are deliberately unchanged.
- **Portal** uses the same font and corners. It is wrapped in `sv8-portal`, outside the office shell.
- **Dialogs** (add patient, appointment popup, PIN, contact note, profile, hide/delete, payment): 3px, Public Sans, softer shadow and scrim.
- **CSS layer order** is pinned (`@layer theme, base, components, utilities`) so the Tailwind utilities that the shared screens use keep working.

## 2. v0.7 rough edges fixed
- **Greeting:** `displayName()` gives "Dr. Patel" for physicians and the first name for a real person ("Morgan"). Desk and test accounts use the full name ("Good afternoon, Front Desk Tester"), and the role is used if there is no name. It never shows "Front".
- **Chart always opens on Overview** whenever a patient is opened or reopened. The tab is no longer persisted in sessionStorage.
- **"← Patients"** on the chart now really returns to the patient list (in v0.7 it stayed on the chart).

## 3. New: Price Quote / Estimate (`src/surgery/quotes.tsx`)
- **Builder:**
  - Open to any role, with no PIN. The author (from Acting as) is recorded on the quote and in the audit.
  - Fields: procedure/plan, surgeon, quote date, and valid-until (default 90 days, set in Practice).
  - Lines come from the practice price list, grouped as Surgeon fee, Facility/ASC fee, Anesthesia, Implants & supplies, Labs, Garments, Follow-up visits and Discount. They can also come from the existing fee schedule or be custom lines.
  - Category, description, qty and unit are editable. Discounts always subtract.
  - Terms and disclaimer are prefilled from the Practice defaults, with an optional financing note and an optional note to the patient.
- **Not payable:**
  - It is labelled "Price Quote / Estimate · not payable".
  - There is no collect-payment control and no balance posting. The account badge and invoices are unaffected.
  - The sheet states "not a bill, no balance is owed, cannot be paid".
- **Quote sheet / print:**
  - Word-style letter page with letterhead (practice name, address and phone from settings).
  - Shows the quote number `Q-YYYY-0001` with version, the date and the valid-until date.
  - Lines are grouped by category, followed by the estimated total.
  - Terms are included: fees may change if the plan changes; complications and revisions are excluded unless listed; it is not a bill or guarantee; deposit and booking terms follow practice policy; validity. The financing note is optional.
  - Ends with a patient acknowledgement block (signature, printed name, date) and a footer naming the author.
  - The print preview has a Print button; the print CSS prints only the sheet.
- **History:**
  - Every quote is stored. **Revise** creates v2, v3 and so on and keeps every prior version (there is a version picker in the panel).
  - **Edit** is only allowed on a Draft, and edits it in place.
  - **Duplicate** creates a new quote number.
  - Statuses are Draft / Presented / Accepted / Declined, with **Expired** set automatically after valid-until for Draft and Presented quotes.
  - Each quote keeps its own event history.
- **Convert to invoice** (Accepted quotes only): creates a normal Draft invoice (`From price quote Q-… vN`, Self-Pay) through `saveInvoice`. The quote then becomes read-only, with no edit, revise or status changes; duplicating it is still allowed.
- **Where it appears:**
  - Chart Overview side card "Price quotes", showing the latest quote, New quote and All quotes.
  - The chart's Documents tab (quote list above the documents).
  - The Activity timeline (one entry per quote, which opens the quote).
  - More › Price quotes.
  - The Billing panel.
  - The Surgeon and Checkout stations (quote list with New quote).
  - The right panel (`quote` ref kind).
- **Audit:** `quote.create`, `quote.edit`, `quote.revise`, `quote.status`, `quote.print`, `quote.convert` and `settings.quotes`, each with the quote number, version, totals and author.
- **Practice › Visit types, intake lists & reminders › Price quotes:**
  - Settings: default validity (days), default terms and disclaimer (one per line, with "restore default"), financing note, letterhead address and phone, and the editable price list.
  - Nightingale "quote terms" / "estimate" opens it.
  - Existing quotes keep the terms they were written with.

## Tests
- New `surgwork/v8/smoke8.py` (+ `v8part.py`): 202/202 at 768 and 1180.
  - Covers the v0.7 checks.
  - Checks the greeting and the Overview-on-reopen fix.
  - Runs the full quote lifecycle: no PIN, 90-day default, 10 lines and total, presented, sheet disclaimers, print preview and letterhead, revise to v2 with v1 kept, duplicate, declined, accepted, convert, read-only, invoice created, Activity and Documents entries, and the audit.
  - Verifies the restyle on Schedule, Messages, Practice, all 7 station steps and the portal: computed Public Sans, no radius above 3px, no left border above 1px, the Nightingale card, and no horizontal overflow.
- Prior suites against v0.8: see the final report.
- Type check: no errors in `src/surgery` (the only remaining error is the pre-existing `src/data/mockData.ts`).
