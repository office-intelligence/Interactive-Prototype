# Surgery.Vityls v0.2: changelog (test build, fictional data)

**Date:** 2026-10-10 · **Branch:** `surgery` · **Tag:** `surgery-v0.2` (built on `surgery-v0.1`)
**Unchanged:** ASC.Vityls, `src_v5`, the `med-v0.1` tag and every ASC/MED zip.

Surgery.Vityls is still a test build. It runs from `index.html` with no server. All data is fictional and stays in the browser. Links, bookings, Send to ASC, ASC replies, invoices and payments are **simulated** and recorded in the audit trail.

---

## Answer for Kevin: will Surgery and Medical share one database?

**Yes.**
- **Vityls Core is the master database.** It holds patients, encounters, documents, allergies, invoices and the audit trail.
- **ASC.Vityls, Surgery.Vityls and Medical (MED.Vityls) are modules on top of Core.** Feature flags switch each one on or off.
- **The encounter is the shared unit.** One record type covers an office visit, a nurse-only visit and a surgical case.
- **Surgical fields are optional.** A Medical practice leaves them empty and turns the surgical modules off (the "Medical preset" in Practice › Visit types, colors & modules).
- **One patient, one chart.** A surgeon's office, an internist and an ASC that share a patient all work from the same Core records. Each module only adds its own detail.

Appendix A below is the short version for Henry.

---

## What changed in v0.2

### 1. Role-based access and signatures: PIN only when you sign
- **No sign-in or sign-out during the day.** A tablet can stay signed in under the shared front-desk session. A nurse can hand it to the physician mid-visit, and the session does not change. The "Acting as" control is still there for testing and is now labeled **Session**.
- **Each person's own PIN is asked only when they sign or attest.** A dialog asks "Who is signing" and "Your PIN". Several people per role are supported:
  - Front desk: 2 people
  - MAs: 2
  - RNs: 2
  - Manager and administrator
  - Providers: they use the existing provider signature PINs
- **What needs a PIN:**
  - check-in verification (front desk, MA, RN, managers, providers)
  - nurse-intake verification (MA, RN, providers)
  - visit-note signature, which also verifies the surgeon step (providers)
  - living-summary initial (providers)
  - allergy verification (MA, RN, providers)
  - checkout verification and Send to ASC (front desk, MA, RN, managers, providers)
- **What does not need a PIN:** adding charges and creating an invoice. Anyone in an authorized role at the station can do it, and it is audited with the session user.
- **Lockouts:** five wrong PINs lock that person until a manager resets it (Practice › Staff & signing PINs). Test PIN for every fictional person: **1234**.
- **Recommendation: keep PIN-at-sign now and add biometrics later as an option.** The PIN asked only at signing is the secure and efficient approach for a busy office:
  - Every signature is tied to one person.
  - Shared tablets need no logins.
  - Hand-offs cost nothing.

  Later, Face ID or a fingerprint on the tablet (WebAuthn / platform authenticator) can replace typing the PIN in the same dialog, keeping the PIN as a fallback. Nothing else in the workflow changes.

### 2. Send request to ASC (checkout)
- **The Checkout step now shows the full scheduling form:**
  - surgery center
  - surgeon
  - procedure and CPT
  - diagnosis and ICD-10
  - laterality
  - anesthesia requested
  - estimated minutes
  - admission type
  - the surgeon's block time at that ASC, or a preferred date and time
  - equipment, implants and special needs
  - allergies (taken from the chart)
  - a note to the ASC scheduler
- **ASC dropdown:** a surgeon may operate at several centers. Three fictional centers are seeded (Harborview, Bayside, Coastline) and can be edited in Practice › Visit types, colors & modules › *Surgery centers you send to*. Block time shows for the primary center.
- **Document picker:** the surgery office ticks which supporting documents to include. Recommended items are pre-ticked. The list can include:
  - visit notes
  - pre-op clearance request
  - each lab slip
  - latest vitals
  - medication list, allergy list, problem list
  - surgical history
  - nursing admission
  - ambient transcript
  - signed forms
- **Consent and PIN:** if record-sharing consent is not on file, a consent checkbox appears. The sender signs with their PIN.
- **Simulated receipt:** about 2.5 seconds after sending, a simulated "Received by ASC" event arrives. The scheduling form and every selected document are filed in the patient's **ASC chart**. To see them, open Chart › Records & documents › *Sent to ASC*, or *View in ASC chart*. The booking also appears on the schedule and in the ASC case thread.
- **Audit entries:** `asc.packet.send`, `asc.packet.received`, `network.booking`.
- The backend contract for Henry is in Appendix B.

### 3. Visual design
- **Dedicated Nightingale AI section:**
  - It uses the same header as ASC.Vityls: dark-green bar (#14432E), gold rule and border (#D9A448), and the Nightingale icon (`src/assets/nightingale-ai-icon.png`). This reuses the ASC classes `nightingale-ai-header` and `nightingale-highlight-border`.
  - The header shows the title "Nightingale AI" and a context line, for example "Ellen Testwood · chart" or "Practice · settings are commands".
  - The ask box, answers and likely-next steps sit inside this section on every page.
- **Print-layout page:** each page is white "paper" with a border and shadow on a light-gray desk, like Word's Print Layout.
- **Richer visit-type colors** (200–300 tones instead of pastels): blue #93C5FD, green #86EFAC, amber #FCD34D, emerald #6EE7B7, violet #C4B5FD, pink #F9A8D4. They are still editable per practice.
- **Timeline sidebar** has its own tinted background, and each event type has its own icon:
  - visit: stethoscope
  - surgery: scissors
  - labs: flask
  - vitals: heart-pulse
  - message: speech bubble
  - ASC: building
  - care plan: clipboard
  - caregiver: people
- **One icon system everywhere** (`src/surgery/icons.tsx`): timeline, Records & documents, Today's needs-attention list, station headings, charges, document picker, ASC chart and right-panel titles.
- **Allergies are confirmed once and then stay verified.**
  - A nurse or physician confirms them with the patient (PIN), and they show "✓ Verified · by · date" everywhere.
  - Nobody is asked again unless the patient reports a change (for example a new intake answer that differs). In that case the item is flagged "Patient reported a change · verify".
  - "Record a change" edits the allergy list and re-verifies it with a PIN.

### 4. Today page
- **Date navigation:** ‹ and › buttons, a date picker and a Today button. The schedule for the chosen date is listed.
- **Arrived button on each patient card:** records arrival with an automatic timestamp and shows "Arrived 11:35".
- **Check in:** records the check-in time automatically (and the arrival time if it was missing), moves the visit to Check-in and opens the workflow.
- **Removed:**
  - the manual Arrival and Checked-in time pickers. The check-in step shows the recorded times read-only, with tap-to-record buttons if a time is missing.
  - allergy confirmation from check-in. The check-in step says so: allergies and medical history are verified at the nursing or physician station, not by the front desk.

### 5. Nursing admission
- **Ambient voice (simulated, like the surgeon scribe):**
  - It has a patient-agreement checkbox, then Start listening, a live transcript, and "Demo: skip to the end".
  - Nightingale fills the reason, pain, BP, pulse, SpO₂, temperature, weight, "meds reviewed" and the nurse note for review.
  - No microphone is used and no audio is stored.
  - Audit entry: `nurse.ambient`.
- **Removed:** Last dose of medication, Escort / ride home, and Fall in the past year.
- **Allergy:** now the verify-once control.

### 6. Charges and invoice at the nurse, physician and checkout stations
- Each of the three stations has a **Charges & invoice** section that works on the same visit charge list.
- The list starts with the visit-type fee. Anyone authorized at the station can add or remove items from the fee schedule. New seeded items:
  - lab draw (36415)
  - nurse visit (99211)
  - dressing change
  - suture removal
  - injection (96372)
  - compression garment
- **Create invoice** at any of the three stations makes a Draft invoice in the practice invoice store. Items added later join the Draft automatically.
- **Checkout** can **finalize** the invoice (sending is simulated) and **record payment**.
- A nurse-only lab-draw visit can therefore be billed without a physician note.
- **Audit entries:** `charge.add`, `charge.remove`, `invoice.create`, `invoice.save`.

### 7. Patient chart
- **Records & documents:** one section below Significant conditions, Surgical history, Major risk factors and Active problems. It replaces the citation chips scattered through the summary and the "Also in this chart" line. It is grouped with icons:
  - **Results:** lab slips, all results, trends
  - **Visits & notes:** each visit opens its workflow; all visits and notes
  - **Clinical record:** vitals, medications, problem list, surgical history, intake answers, risk awareness, care plan
  - **People & messages:** portal messages, care team, caregivers, journal, remote monitoring
  - **Surgery center:** ASC case and thread; Sent to ASC / ASC chart
  - **Office:** billing, audit trail
- **New message:** when a new portal message has arrived, a red banner under the patient header shows the sender, the time, the first line and **Read & reply →**. The Portal messages link is also marked **new**.
- **Workflow link:** "Today's visit workflow →" (or "Visit workflow · <date>" for the most recent past visit) in the chart header. It also appears as "Open visit workflow" on today's encounter line.
- **Worth your attention:** each line is now clickable and opens its source.

### 8. Practice page
- It keeps the same grouped structure (Workspaces, Practice setup, Clinical configuration, People & compliance), restyled in the Surgery.Vityls look: white paper, plain headings and rows, icons.
- **Removed:** all operating-room and ASC configuration. The shared ASC administration "Administration & Locations" page, which has OR rooms and the ASC practice type, is no longer linked. It is replaced by a Surgery-owned *Practice profile & rooms* page: name, address, phone, hours, exam and procedure rooms.
- **One Nightingale:** the page's own Nightingale panel is gone; the page header is the only Nightingale.
- **Settings as Nightingale commands:** every Surgery.Vityls setting is a command in **Likely next**, and you can also type it, for example "fee schedule", "visit types", "staff PINs", "forms", "providers", "billing".
- **New page:** *Staff & signing PINs*. It lists people and roles, lets you change or reset a PIN, add a person, and deactivate or reactivate someone. It includes a "who signs what" table.

### 9. Scheduler
- The background matches the other pages: white page on the gray desk, with a light header row.
- **Provider columns can be added and removed:** "×" on a column header removes it, and "+ Provider column" adds one. The setting is saved per practice and audited (`schedule.columns`). By default only clinical providers get a column (anesthesia staff are not shown).

---

## How to test (about 10 minutes)

**Setup**
1. Unzip `Surgery_Vityls_v0.2.zip` and open `Surgery_Vityls_v0.2/index.html` in Chrome, Safari or Edge.
2. For a fresh start, add `?reset-test-data` to the end of the address.
3. **Tablet sizes:** use DevTools device mode at 768×1024 and 1180×820.

**Walkthrough**
1. **Today.** Use › and ‹, then the date picker, then **Today**. Tap **Arrived** on Marisol: the card shows "Arrived HH:MM".
2. **Ellen's chart.** Tap **Open** on Ellen. Check:
   - The Nightingale AI header.
   - The allergy line shows "✓ Verified".
   - The red **New message** banner.
   - **Records & documents** at the bottom.
   - The timeline icons.
3. **Ask Nightingale** "is she on blood thinners?", then tap **Clear**.
4. **Check-in.** Tap **Today's visit workflow →**, then:
   - **Check in · record time** (no time pickers, no allergy step).
   - **Verify check-in** opens the PIN dialog. A wrong PIN (9999) is refused; **1234** works.
5. **Nurse intake.**
   - Tick *Patient agreed*, then **Start listening**: the transcript fills the form.
   - Save.
   - In Charges, add **Lab draw**, then **Create invoice** (Draft).
   - **Verify** with PIN.
6. **Surgeon.** Leave the Session alone: the nurse "hands the tablet" to the physician.
   - Consent, then **Demo: skip to the end**.
   - Hold to initial the surgery booking.
   - **Accept draft as note**, then **Sign with PIN**. Choose *Sam Patel, MD* and enter 1234. The surgeon step is verified by Sam Patel while the Session still says Morgan Avery.
   - Add an **Injection** charge: the same invoice updates.
7. **Checkout and Send to ASC.**
   - Choose **Bayside Outpatient Surgery**, set a preferred date, and review the ticked documents.
   - **Send** with your PIN. Within about 3 seconds you see **"✓ Received by ASC · added to ASC chart ASC-1001"**. Tap **View in ASC chart**.
   - **Finalize & send (simulated)**, then **Record payment**, then **Verify checkout**.
8. **Schedule.** Remove a provider column with ×, then add one back with **+ Provider column**.
9. **Practice.**
   - Check there are no OR or ASC configuration items.
   - Ask "fee schedule" or "staff PINs", or tap a Likely-next command.
   - Open **Staff & signing PINs** and change a PIN as *Pat Quinn* (Session → Pat Quinn · Practice Manager).

**Automated headless smoke test** (both tablet sizes, release build): 82/82 checks passed with no JavaScript errors. The same suite passed again against the unzipped release folder. Screenshots are in `report/surgery_v02_screens/`.

---

## Assumptions and limits
- Everything that "sends" is simulated: Send to ASC, the ASC "received" event, invoices and payments. Nothing leaves the browser, and the ASC chart view is simulated. **ASC.Vityls itself is unchanged.**
- **Block time** is shown only for the primary surgery center (the seeded ASC block time). For other centers, the office enters a preferred date.
- **Charges and invoices are recorded under the session user**, which may be the shared front-desk session. Signatures are the only actions tied to a person by PIN.
- **Scribe suggestion "initials"** do not ask for a PIN. They are attested when the physician signs the note with their own PIN.
- **Allergy re-verification** is triggered when the patient reports a change (intake or portal) after the last verification, or when no one has ever verified.
- **Practice profile room list** is saved, but the Add-visit dialog still offers the seeded rooms in this build.
- **Shared audit vocabulary:** Surgery adds new audit action names to the shared type in `src/v6/dataLayer.ts`. It is a type-only change, so there is no runtime change to ASC.

---

## Appendix A — Vityls Core for Henry (one database, three modules)

This describes tables and modules only. Hosting, Azure services and identity provider choices are Henry's.

**Core (master, shared by every module)**

| Table | Purpose / key fields |
|---|---|
| `organization`, `location` | Practice or ASC tenant, address, hours, rooms |
| `person` | Staff and providers: name, role(s), credentials, active, **signing PIN hash**, failed tries, locked |
| `patient` | Demographics, contacts, MRN per organization, record-sharing consent (granted, by, at, scope) |
| `encounter` | **Shared unit.** patient, organization, type (office visit, nurse visit, surgical case…), date/time, provider, room, status/step, reason. *Surgical fields optional* (procedure, laterality, anesthesia, facility, block id) |
| `encounter_event` | Arrived, checked in, roomed, provider in/out, checked out (timestamp, by) |
| `station_verification` | encounter, station, signer person, role, signed_at (PIN-verified) |
| `allergy`, `allergy_verification` | Allergy list; last verification (by, at); patient-reported changes |
| `problem`, `medication`, `vitals`, `lab_result` | Clinical record |
| `note` | encounter, sections, status draft/signed, signed_by, signed_at, content hash, addenda |
| `document` | Any file or text: patient, encounter?, title, kind, source org, mime, storage pointer, hash |
| `charge`, `invoice`, `payment` | Charges per encounter (fee item, qty, amount, station, added_by) → invoice (draft/sent/paid) → payments |
| `fee_item` | Practice fee schedule (code, price, visit type) |
| `audit` | Append-only: who, role, action, object, detail, time |

**Modules (feature flags per organization)**

| Module | Adds |
|---|---|
| **Medical** | Visit types, intake, portal messages, results release, care plans, caregivers, chronic registries |
| **Surgery** | Surgical history, risk awareness, ambient scribe drafts, checkout orders (booking, clearance, follow-up), `asc_packet` (Appendix B), surgery-center list per office |
| **ASC** | Facility cases, block time, OR rooms, pre-op stations, anesthesia, PACU, ASC billing. Receives `asc_packet` into its encounter |

**Rules**
- A Medical-only office simply leaves the surgical columns empty and the surgical modules off.
- One patient may have encounters at a surgeon's office and at an ASC. Each organization sees its own encounters, plus what consent allows to be shared.

---

## Appendix B — Send to ASC backend contract (for Henry)

**`POST /asc-packets`**, sent by the surgery office and signed with the sender's PIN.

```json
{
  "id": "pk_…", "patientId": "…", "encounterId": "<office visit>",
  "facilityId": "asc-bayside", "surgeon": "Sam Patel, MD",
  "form": { "procedure": "Bilateral upper blepharoplasty", "cpt": "", "diagnosis": "Dermatochalasis, upper lids", "icd10": "",
            "laterality": "N/A|Left|Right|Bilateral", "anesthesia": "General|MAC / sedation|Regional|Local|Surgeon to discuss",
            "durationMin": 90, "blockId": "", "preferredDate": "2026-10-27", "preferredTime": "07:30 AM",
            "admission": "Outpatient (same day)|23-hour observation", "equipment": "", "implants": "", "specialNeeds": "",
            "latexAllergy": false, "allergies": "Penicillin (hives), Codeine (nausea)", "notes": "" },
  "documents": [ { "id": "note:<visitId>", "kind": "note|clearance|lab|vitals|meds|allergy|problems|history|form|nurse|scribe",
                   "title": "…", "documentId": "<Core document id>" } ],
  "signedBy": { "personId": "…", "role": "Front desk", "at": "ISO-8601" },
  "consent": { "granted": true, "by": "…", "at": "…", "scope": "Records for surgery scheduling at <facility>" }
}
```

**Server rules**
- Verify the signer and their PIN, and check that consent is on file.
- Create the ASC-side `encounter` (type *surgical case*, status *requested*).
- Link each document to that encounter, readable by the ASC.
- Write `audit` entries (`asc.packet.send`).

**`POST /asc-packets/{id}/received`**, from the ASC system or its intake queue.

```json
{ "receivedAt": "ISO-8601", "ascChartId": "ASC-1001", "ascEncounterId": "…", "by": "Bayside scheduling" }
```

**Effect**
- Packet status becomes `received`.
- The documents and scheduling form appear in the patient's ASC chart.
- The office sees "Received by ASC · added to ASC chart".
- The ASC case thread gets a message.
- Audit entry: `asc.packet.received`.

**Later updates (optional)**
- `PATCH /asc-packets/{id}` with `status: scheduled | needs-info | declined`, plus confirmed date/time/room. This updates the office schedule.

**In this build**
- **Local storage:** packets are stored in localStorage under `vityls-surgery~vityls:surgery:asc-packets`. Documents go to `vityls:network:docs:<caseId>` and messages to `vityls:network:thread:<caseId>`.
- **Simulated receipt:** `receivePending()` in `src/surgery/asc.ts` simulates the `/received` call.
