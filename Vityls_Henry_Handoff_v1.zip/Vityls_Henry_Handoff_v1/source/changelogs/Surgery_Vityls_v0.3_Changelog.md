# Surgery.Vityls v0.3: changelog (test build, fictional data)

**Date:** 2026-10-11 · **Branch:** `surgery` · **Tag:** `surgery-v0.3` (built on `surgery-v0.2`)
**Unchanged:** ASC.Vityls, `src_v5`, the `med-v0.1` tag and every ASC/MED zip. The few shared files that were touched (`src/main.tsx`, `src/med/MedPracticeSettings.tsx`, `src/med/MedBilling.tsx`) change only behind `isSurgery`. `src/v6/dataLayer.ts` gains new audit action names only.

Surgery.Vityls is still a test build. It runs from `index.html` with no server, all data is fictional, and everything stays in the browser. Invitation emails, card payments and the invitation "accept" are **simulated** and recorded in the audit trail. **Every clinical photo in this build is a synthetic illustration** stamped "EXAMPLE DATA · FICTIONAL ILLUSTRATION · NOT A REAL PERSON". No real people or real patient photos are used.

---

## What changed in v0.3

### A. Practice page (Kevin's markups)
- **Practice performance & reports** is now on the same white sheet over gray as the other Surgery pages.
  - The duplicate Nightingale was removed.
  - The **Period** selector stays: Today, This week, This month, Quarter.
- **KPIs, renamed:**
  - "Cases completed" is now **Patient visits**.
  - "Scheduled" is now **Surgeries scheduled**.
  - The rest are Cancellations, ASC block utilization, Coordinator follow-ups and Collections.
- **ASC utilization table:** the "Room" column is now **ASC names**.
- **Staff efficiency** now lists the **surgical coordinators**: patients assigned, follow-ups, surgeries booked and packets sent.
- **Surgeon-office reports** replace the ASC/OR reports:
  - Visit register
  - Coordinator workload
  - Cancellations & no-shows
  - Day sheet
  - Collections & credits
  - Fee activity
  - Referral sources (marked "not captured yet")
  - Credentialing due
  
  Each report opens a table on the same sheet.
- **Settings:** the Practice Edition selector was removed and the page is now titled **Surgery.Vityls settings**. A read-only card says the practice uses Surgery.Vityls and that the product comes with the subscription.

### B. Surgical Coordinator role and staff invitations
- **Practice › Staff, coordinators & invitations** has a registration form: name, role and email.
  - Roles: Surgical Coordinator, Front Desk, MA, RN, Practice Manager, Administrator.
- **Every new person gets an invitation link** to create a **username, password and signing PIN**.
  - The email is simulated. A preview shows exactly what would be sent.
  - The person stays **Invited** until they accept, then becomes **Active**.
  - Invited people cannot sign.
  - Resend and View invitation are available.
  - Everything is audited: `staff.invite` and `staff.account`.
- **Accept page:** opening the link (`#staff-invite=…`) shows the accept page. It uses the same username, password and PIN rules as provider invitations.
- **Coordinators can be assigned to a patient** (optional) from the chart header or the patient list. Assignments are audited (`coordinator.assign`).
- **Seeded coordinators:** Riley Shaw and Jordan Blake (PIN 1234).
- A **"Who signs what"** table lists each role's PIN-signable actions.

### C. Collect payment (front desk, any time, any patient)
- **Collect payment** is on the patient list and on every chart header. No invoice is needed.
  - Methods: card (simulated), cash, check, financing.
  - The amount posts as **credit on the patient's account**.
  - A receipt is shown, and the payment is audited (`payment.collect`).
- **Simulated card:** the number is Luhn-checked. Only the brand and last 4 digits are kept.
  - `4242 4242 4242 4242` is approved.
  - A valid number ending in `0002` is declined.
- **Billing panel › Patient account** shows invoiced, paid on invoices, due and credit on account.
  - **Apply credit** pays open invoices, oldest credit first. It records an invoice payment and is audited (`credit.apply`).
  - Verified: $500 credit applied to a $200 invoice leaves $0 due and $300 credit.
- Allowed roles: front desk, surgical coordinator, MA, RN, practice manager, administrator and providers.

### D. Body charts & photos, a prominent step in the surgeon workflow
- **New station step "Charts & photos"** (highlighted, camera icon), right after Surgeon. The Surgeon step also opens with a band showing the patient's charts and photos.
- **Body charts:**
  - 14 standard line diagrams: face front, face profile, eyes, nose front, nose profile, nose base, ears, breast, body front, body back, abdomen, arms, legs, hands, genital/perineal (neutral), and a face injection grid.
  - **Freehand drawing** on a tablet (pen, finger or mouse): 4 inks, 3 widths, a text tool, Undo and Clear.
  - **Save to the record is versioned.** Each save adds a version and older versions stay viewable. Audited (`bodychart.save`).
  - Saved charts are viewable by the care team. Only surgeons draw.
- **Photos:**
  - **Take photo** uses the tablet camera (`capture="environment"`). **Upload** is also available.
  - Each photo is marked **Before / After** with a **date**, area and view.
  - Uploads are downscaled to JPEG ≤1280 px.
- **Photo viewer:**
  - 1 photo fills the screen.
  - 2 photos show **side by side**.
  - 3–4 photos show in a **four-square grid** (max 4).
  - The tray adds more photos up to 4. In single view, you can change before/after and the date.
  - Each view is audited (`photo.view`).
- **Photos are surgeon-only.** Every other role (including NP, physicians without the Surgeon role, MA, RN, front desk and coordinator) sees a lock, and the attempt is audited (`photo.denied`). Nightingale also answers photo questions with "surgeon-only".
- **Seeded synthetic photos (fictional illustrations):**
  - **Ellen Testwood (MED-1001):** a before/after pair from a fictional prior lower-lid office procedure (−215/−190 days), plus pre-op befores for her upcoming blepharoplasty (−30 and −2 days). She also has a seeded "Upper blepharoplasty · skin excision plan" body chart.
  - **Robert (MED-1004):** frontal and profile before (−45 days) and after (−1 day), so the four-square compare works out of the box.
  - **Tomas (MED-1007):** rhinoplasty before photos (profile and frontal).

---

## How to test (double-click `index.html`; start fresh with `?reset-test-data`; PIN 1234)
1. **Practice › Practice performance & reports:** switch the Period, check the renamed KPIs and the "ASC names" column, and open a report.
2. **Practice › Surgery.Vityls settings:** there is no edition selector.
3. **Practice › Staff, coordinators & invitations:**
   1. Register a Surgical Coordinator with an email and review the invitation preview.
   2. Click **Open link (simulated)**, choose a username, password and PIN, and accept.
   3. The status changes to Active.
4. **Patients › Ellen Testwood:**
   1. Assign a coordinator in the header.
   2. Click **Collect payment**, enter $500 with card 4242 4242 4242 4242, and check the receipt.
   3. Open **Billing**. The credit is shown. After checkout creates an invoice, use **Apply credit**.
5. **Session = a surgeon:**
   1. Open Ellen's station and go to **Surgeon**, then **Charts & photos**.
   2. Open the eyes chart, draw, and save. A new version appears.
   3. Select 2 photos and click Compare (side by side), then 4 (grid), then tap one (full screen).
   4. Open Robert's chart to see 4 before/after photos.
6. **Session = RN, MA, front desk or coordinator:** Photos show the lock, and the denial appears in the audit trail. Charts are view-only.

---

## Notes for Henry (backend)
- **Staff invitations:** `POST /staff` (name, role, email) → invite token (single use, 7-day expiry) → email. `POST /staff-invite/{token}/accept` (username, password, PIN) → hash the password (argon2id) and PIN server-side. Pending users cannot sign.
- **Payments:** use the processor's hosted fields or a card terminal. The browser never sees the PAN. Store only the processor token, brand, last 4, amount, method, collected_by and time. `patient_credits` ledger plus `credit_applications(invoice_id, amount)`.
- **Photos:** object storage (S3 + KMS) with encrypted keys per practice, and short-lived signed URLs. The access policy is **Surgeon role only**, enforced server-side, and every view or denial is written to the audit log. Body charts: `body_charts(series_id, version, diagram_id, svg/strokes, signed_by)`.
- **Coordinators:** `patient_coordinator(patient_id, staff_id, assigned_by, at)`.
- **Reports:** "Referral sources" needs `patients.referral_source`.

## Rough edges / known limits
- Some performance figures (cancellations, ASC block utilization) are **example** values, labeled as such. Visit and coordinator counts come from the test data.
- Invitations and card payments are simulated. No email is sent and no card is charged.
- Photos and charts are stored in browser localStorage, which is limited to about 5–10 MB. Many large uploads can fill it, and the app shows an error if a save fails. Real storage is a backend item.
- I read the "Edition: Show this" markup as "show which product this is, but don't let anyone switch it": a read-only card with no selector.
- Providers (surgeons, NPs) are still invited from Practice › Providers with the existing provider invitation. The new staff invitation covers everyone else.
- Photo access is strictly the **Surgeon** role. NPs and other physicians are denied, which may be stricter than wanted.
- The synthetic photos are stylized illustrations, not photo-realistic.
- Credit is applied to invoices one at a time. There are no partial allocations across several invoices in one step.
- Ellen's prior lower-lid procedure (sh-e4) is fictional and was added so she has an honest before/after pair.
- Commits L–O are logical increments. Only the tagged HEAD was built and smoke-tested.
