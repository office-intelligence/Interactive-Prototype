# Surgery.Vityls v0.4: changelog (test build, fictional data)

**Date:** 2026-10-11 · **Branch:** `surgery` · **Tag:** `surgery-v0.4` (built on `surgery-v0.3`)
**Unchanged:** ASC.Vityls, `src_v5`, the `med-v0.1` tag and every ASC/MED zip. Shared files touched only behind `isSurgery`: `src/med/MedPortal.tsx` (forms card), `src/med/MedPracticeSettings.tsx` and `src/med/MedBilling.tsx` (Practice access PIN). `src/v6/dataLayer.ts` gains new audit action names only.

Surgery.Vityls is still a test build. It runs from `index.html` with no server, all data is fictional, and everything stays in the browser. Texts, emails, portal posting and card payments are **simulated** and recorded in the audit trail. Test PIN for every fictional person: **1234**.

---

## What changed in v0.4

### A. + Add New Patient (the ASC.Vityls routine)
- An **Add New Patient** button is on **Today**, the **Patients** list and every **patient chart** header.
- It opens the same Add New Patient dialog ASC.Vityls uses: first and last name, date of birth (age calculated), gender, mobile phone and optional email. The MRN is assigned automatically.
- **Create Patient Chart** makes the Surgery chart (no visit yet, allergies "Not reported", primary surgeon = the practice's first surgeon). Audited as `patient.create`.
- **Then you're prompted to send the new-patient forms:**
  - Forms (all ticked): **Patient Registration**, **Admission Form**, **Medical History**.
  - How: **Text message** to the mobile number, **Email** (if one was entered), **Post to the patient portal**. Any combination.
  - **Send** shows the exact message and link that would go out. **Not now** skips (also recorded).
  - Sending is **simulated**: nothing is texted or emailed. Each packet is kept in an outbox and audited as `forms.packet.send`.
- The new chart shows a **New-patient forms** line (what was sent, how, when, by whom) with **Send again**.
- **Patient portal:** the patient sees **Forms from your surgeon's office** on the portal home page and can open each form.

### B. Stations are open to everyone on the shared tablet
- Any session (front desk, MA, RN, coordinator, manager, provider) can run **every** step: intake links, check-in, rooming/vitals, nurse intake, ambient scribe, charts & photos and checkout. There are no "switch the session" messages left in the workflow.
- **Charges & invoice** can be added at any station by anyone (audited under the tablet session).
- **Only signatures ask for a PIN, and the audit names the signer, not the tablet session:**
  - Check-in, rooming/nurse intake and checkout verification: **anyone on the care team**, using their own PIN (small offices: the front desk may room the patient).
  - Allergy verification, Send to ASC: anyone on the care team, own PIN.
  - **Collect payment** now asks the collector to confirm with their own PIN, as you suggested.
  - Surgeon step, visit note, living-summary initial: **providers only**.
  - **Lab results review / release** now opens for anyone but is signed with a provider PIN (it used to be greyed out unless the session was a provider).
- **Visit note (your rule):** a front desk person can start the ambient scribe, dictate, and review and edit the draft.
  - **Save note (provider PIN)**, **Save & sign** and **Accept draft as note** all open a PIN box that lists **physicians, surgeons, NPs and PAs only**.
  - A wrong PIN is refused. Cancelling leaves the note out of the record ("Not saved. A physician's PIN is needed…"), keeps the draft on screen, and is audited as `visit.note.denied`.
  - With the physician's PIN, the note is saved under the **physician's** name. The audit also notes the tablet session.
  - **Keep working draft** parks the dictated draft on the tablet (not in the record) for the surgeon to pick up.
  - Initialing a Nightingale order suggestion from a non-provider session asks for a provider PIN.

### C. Photos and body charts open to the care team
- The v0.3 surgeon-only lock is removed. **Anyone** on the tablet can take or upload photos, mark them Before/After with a date, and open the full-screen 1 / 2 / 4 compare. Anyone can draw and save body charts.
- Every photo add, change and view is still audited (`photo.add`, `photo.update`, `photo.view`). Only an AI session is refused.
- Nightingale's photo answer and the Practice "Who signs what" table were updated to match.

### D. Practice needs an access PIN
- Opening **Practice** (or any page under it: staff, providers, settings, fee schedule, Form Studio, billing, reports, profile, documents) shows **Practice is locked** and asks for an access PIN.
- **Who can unlock:** Practice Manager, Practice Administrator, or a provider (surgeon, physician, NP, PA). The front desk, MA, RN and coordinators are not listed. Kevin, you said "doctors and the administrator"; managers are included as the office's administrator role.
- **Once unlocked**, that person can edit everything in Practice even though the tablet session is someone else. Changes are recorded under **the unlocking person's name**.
- **It re-locks** when you leave Practice, after **5 minutes** without a tap or keypress, when you press **Lock** in the top bar ("Practice open · Pat Quinn · Lock"), or on reload. Audited as `practice.unlock`, `practice.lock` and `practice.denied`.

---

## How to test (double-click `index.html`; start fresh with `?reset-test-data`; PIN 1234)
1. **Session = Front Desk Tester.** Today › **Add New Patient**. Enter a name, DOB, gender, mobile phone and email, then **Create Patient Chart**.
2. In the prompt, keep all three forms and all three channels, then press **Send 3 forms (simulated)**. Check the message preview, then **Open chart**. The chart shows the New-patient forms line.
3. **Portal** (top bar) › choose the new patient. **Forms from your surgeon's office** lists the three forms, and **Open** shows the form.
4. Patients › **Ellen Testwood** › visit workflow:
   1. Still as front desk, verify **Check-in** with Front Desk Tester's PIN. Open **Nurse intake**; nothing is locked.
   2. **Surgeon** › tick consent › **Demo: skip to the end** › **Review & edit**, then change the Plan.
   3. **Save note (provider PIN)**: only providers are listed. Try PIN 9999 (refused), then **Cancel** ("Not saved"). Save again with **Sam Patel, MD** and PIN 1234: the note is saved under Sam Patel.
5. **Charts & photos** (still front desk): Upload or take a photo, mark it After, select two, and **Compare**.
6. Ellen's chart › **Collect payment** › $100 cash › confirm with your own PIN.
7. **Practice**: it is locked, and the front desk isn't in the list. Unlock as **Pat Quinn** (or a surgeon) and edit something. Go to Today and back: Practice is locked again. Leave it idle for 5 minutes: it locks again.

---

## Notes for Henry (backend)
- **Add patient:** `POST /patients` (minimal registration). Then `POST /patients/{id}/form-packets {forms[], channels: {sms, email, portal}}`. SMS and email go through a BAA-covered vendor. Use single-use, expiring links. Portal posting = `portal_tasks(patient_id, form_id, status)`.
- **Signatures:** every signed or attested action carries `signed_by` (from the PIN check) **and** `session_user` (who held the tablet). The PIN check is server-side with the lockout after 5 failures. Unsigned visit-note drafts dictated on the tablet stay out of `visit_notes` until a provider signs (`note_drafts` keyed by visit).
- **Practice access:** a step-up token (5-minute sliding expiry, bound to the device and the person who entered the PIN), required on every `/practice/*` write. The roles allowed are Practice Manager, Practice Administrator and providers.
- **Photos:** the v0.3 surgeon-only policy is now practice care-team access. Keep encrypted object storage, signed short-lived URLs and an access log on every view.

## Rough edges / known limits
- Practice unlock lives in memory: a page reload re-locks it (intended), and the 5-minute idle timer is checked every 15 seconds, so it can lock up to 15 seconds late.
- The Add New Patient dialog is the ASC dialog (its green ASC styling), so it looks slightly different from the Surgery pages. The dialog shows the MRN as digits; the chart prefixes it with "MED-".
- New patients have no visit yet. Book one from Schedule. The new-patient intake station still sends its own per-visit links, separate from the chart-level forms packet.
- Portal forms are filled under a patient-level record (`portal-forms:<MRN>`), not attached to a visit. In-office copies at the visit's Intake step are separate.
- Charges, photos, body charts and coordinator changes are audited under the **tablet session** (no PIN), because they aren't signatures. Tell me if you want any of them PIN-confirmed.
- The visit-note PIN list includes NPs and PAs (all providers), not only physicians and surgeons. Easy to narrow if you prefer.
- Nightingale's "likely next" chips on the Practice page are still visible while it's locked; tapping one shows the PIN gate.
- Commits P–R are logical increments. Only the tagged HEAD was built and smoke-tested.

## Checks
- Headless smoke (Chrome, file://) at **768×1024 and 1180×820**: 74/74 passed, no page errors. Covered: add patient → forms prompt → preview → chart line → portal card (plus opening a portal form); front-desk check-in verification; open nurse step; note save refused without a provider PIN, wrong PIN, then saved with the surgeon's PIN; front-desk photo upload and compare; payment PIN; Practice gate (front desk not listed), unlock, re-lock on leave and after 5 minutes idle; audit entries for every new action.
- TypeScript: no errors in `src/surgery` or `src/med`. The project-wide count is unchanged (39 pre-existing errors in ASC/v7/App files).
