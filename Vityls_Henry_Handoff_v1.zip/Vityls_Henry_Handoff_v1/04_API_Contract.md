# 04 · API contract (proposal)

Status: **proposal**. There is no server today: every call below is a function that reads or writes localStorage or IndexedDB. Routes marked **(code)** are already named in a source comment, so keep them unless your ASC backend uses another convention. All others are proposed. Payloads are the TypeScript types listed in `03a_Appendix_Type_Definitions.md`, which become JSON in camelCase. Reconcile with your existing ASC API (see `05`).

## 0. Conventions (all routes)
- Base path `/api/v1`. Auth with a bearer token (Entra ID for staff, External ID for patients). **The tenant comes from the token or session**, never from the body. The server sets `SESSION_CONTEXT('tenant_id')` for row-level security.
- Each route declares a **module**, and the entitlement middleware enforces it (`02` §B4). The errors are `403 module_not_enabled` and `403 module_read_only`.
- The **Role** column below lists who may call each route. Role names in the code: Front desk, Medical assistant, Nurse, Surgeon or Physician (provider), Practice Manager, Practice Administrator, plus Vityls staff (admin console only).
- **Signing:** any route marked ✍ needs a body `{ signerUserId, pin }`. The server checks the PIN hash (argon2id with a pepper from Key Vault), counts wrong attempts and locks out, refuses any signer whose name contains Nightingale, and sets `signed_at` and a `content_sha256` itself. The browser clock is never trusted.
- **Audit:** every write appends to `core.audit_log` (`who, role, action, entity, entity_id, detail, at`) in the **same transaction**. The audit action names already used in the code (e.g. `trial.start`, `reminder.settings`, `event.time.edit`) should be kept.
- **Concurrency:** versioned rows carry `row_version` (rowversion). Send `If-Match`; a mismatch returns `409`.
- **Lists:** `?updatedSince=` for sync into the client cache, plus cursor paging.
- **Soft delete and hide:** DELETE routes set `deleted_at`/`deleted_by` (or hide). Hard delete exists only for patients (admin ✍ + reason + typed confirm) and leaves a tombstone.
- **Files:** `POST …/uploads` returns a short-lived SAS URL; the client uploads to Blob, then `POST` with the `blobId`. Downloads use `GET /blobs/:id` → 302 to SAS.
- **Outbound messages:** nothing is sent directly. The API writes `core.outbox` and a Function sends it (simulated until a BAA).

## 1. Seam map: code function → route
| Code (today) | Route |
|---|---|
| `repo.getForm(caseId,file)` / `saveForm(rec)` / `listForms(caseId)` (`src/v6/dataLayer.ts`) | `GET/PUT /encounters/:caseId/forms/:file` **(code)**, `GET /encounters/:caseId/forms` |
| `repo.getFacts` / `putFacts` | `GET /encounters/:caseId/facts`, `PATCH /encounters/:caseId/facts` (array of Fact, upsert by `concept`) |
| `repo.audit` / `getAudit` | `POST /audit` **(code)** (client-side UI events only; server events are written by the server), `GET /encounters/:caseId/audit` |
| `repo.get/setStationVerification` | `GET /encounters/:caseId/stations`, `PUT /encounters/:caseId/stations/:station/verify` ✍ |
| `repo.getActor/setActor` | client session only (the tablet's "acting as"); `GET /me` |
| `repo.get/save/clearSignerConfig` | `GET/PUT/DELETE /practices/:id/forms/:file/signers` **(code)** |
| `formSource` (`src/v6/formSource.ts`) | `GET /practices/:id/form-templates/:file` (versioned) **(code)** |
| `v6/seed.ts`, `med/seed.ts` | delete; data comes from the API **(code)** |
| `medRepo.*` (`src/med/record.ts`) | `/patients/:id/{problems,meds,vitals,labs,intake,care-plan,caregivers,messages,risk-reviews,device-readings}`, `/visits`, `/visits/:id/note` |
| `svRead/svWrite(key)` (`src/surgery/store.ts`) | per key, as listed in `03_Data_Model.md` §5 (column "owner") |
| `moduleStore(m)` (`src/core/store.ts`) | that module's routes below; `outbox` → `/outbox` |
| `practices.ts` (`vityls:core:*`) | `/tenant`, `/tenant/modules`, `/admin/*` |
| IndexedDB `img` store (`src/surgery/v12/img.ts`) | `POST /patients/:id/images` **(code)** + Blob |

## 2. Core (always on)
| Method & route | Payload | Role | Audit |
|---|---|---|---|
| GET `/me` | → user, roles, tenant, entitlements | any signed-in user | — |
| GET `/tenant` · PATCH `/tenant/settings` | practice settings (`expired`, `locked`, Practice access PIN change ✍) | read: all; write: PM/PA | `tenant.settings` |
| GET `/tenant/modules` | → `Entitlement` per module | all | — |
| POST `/tenant/modules/:id/trial` | `{}` → starts the module plus any missing hard dependencies (`via`) | PM/PA | `trial.start` per module |
| POST `/tenant/modules/:id/activate` · `/deactivate` | `{}`; deactivate → 409 when another enabled module requires it | PM/PA (billing later) | `module.activate` / `module.off` |
| GET/POST `/users` · PATCH `/users/:id` | StaffMember / Provider | PM/PA | `staff.*` |
| POST `/staff-invitations` **(code)** · GET `/staff-invite/:token` · POST `/staff-invite/:token/accept` **(code)** | invite → token (expiring); accept creates the IdP account and saves a salted PIN hash | PM/PA; public with token | `staff.invite`, `staff.accept` |
| POST `/provider-invitations`, GET `/invite/:token`, POST `/auth/activate`, POST `/auth/signature-pin` **(code, v7/invitations.ts)** | provider onboarding | PM/PA; token | `provider.*` |
| POST `/pin-reset` · GET/POST `/pin-reset/:token` **(code)** | Forgot PIN; the token expires after 30 min | self; token | `pin.reset.*` |
| GET `/patients?q=&hidden=` · POST `/patients` **(code)** · PATCH `/patients/:id` **(code)** | MedPatient (minimal Core identity) | all staff | `patient.create/update` |
| POST `/patients/:id/hide` ✍ · POST `/patients/:id/unhide` ✍ | `{reason, note}`; any staff can start; a PM/PA/provider signs | as stated | `patient.hide/unhide` |
| DELETE `/patients/:id` ✍ | `{reason, note, confirm:"DELETE"}`; admin only (PM/PA or a `provider-admins` provider) → tombstone | admin | `patient.delete` |
| GET/POST `/patients/:id/documents` · DELETE (soft) · POST `…/restore` | Document + blobId; Nightingale summary stored as a draft | all staff | `doc.*` |
| GET `/blobs/:id` · POST `/uploads` | SAS | per the owning record | `blob.read` (for PHI) |
| GET `/audit?entity=&from=` | — | PM/PA | — |
| GET `/outbox` | simulated messages | PM/PA | — |
| POST `/nightingale/ask` *(later, after a BAA)* | `{patientId?, question}` → sourced answer; **never** signs or orders | all staff | `ai.ask` (no PHI in logs) |

## 3. Modules
Each route is gated by the module shown. `✍` = PIN at sign.

**email-intake**: `GET /email-intake/inbox`, `GET /email-intake/messages/:id`, `POST /email-intake/messages/:id/extract` (Nightingale proposes and stores an `email_extractions` draft), `POST /email-intake/extractions/:id/accept` (a person edits and accepts → creates or matches a patient, files attachments to documents, creates a scheduling request), `POST /email-intake/messages/:id/reply` (draft → outbox). Role: front desk and up. Inbound mail later via a mailbox webhook (BAA). Audit `email.*`.

**scheduling**: `GET /visits?from=&to=&provider=`, `POST /visits` (double-booking allowed with a warning, as in the UI), `PATCH /visits/:id` (changing date, time or provider clears the confirmation and cancels pending reminders), `DELETE /visits/:id` (`{reason}`; a copy is kept), `POST /visits/:id/check-in`, `GET/PUT /practice/visit-types`, `GET/PUT /practice/intake-lists` **(code)**, `GET/PUT /practice/reminder-settings` (`ReminderSettings`: intervalHours (default 48), maxRequests (default 4), dayBefore, quiet hours), `POST /visits/:id/confirm` (from the patient's link), `GET/POST /schedule/blocks`, `GET/POST /schedule/events`, `GET/POST /visits/:id/notes`. Reminder sending is a Function on a timer → outbox. Audit `visit.*`, `reminder.*`.

**chart**: `/patients/:id/problems|meds|vitals|labs|intake|care-plan|caregivers|diagnoses|notes|contact-notes|allergies` (GET/POST/PATCH). Signing a note: `POST /visits/:id/note/sign` ✍ (then locked; later changes are addenda: `POST …/addenda` ✍). `GET /patients/:id/activity`. Results release: `POST /labs/:id/release` (per the practice's release setting). Risk awareness: `GET/POST /patients/:id/risk-reviews` (findings only; no score). Practice risk triggers: `PUT /practice/risk-triggers`, where enabled triggers need `value`, `approvedBy` and `approvedOn` or the server returns 422. Audit `chart.*`, `risk.settings`.

**stations-workflow**: `GET /visits/:id/workflow`, `POST /visits/:id/workflow/:station/complete` ✍ (station keys `patientPortal`, `frontOffice`, `nursing`, `surgeon`, labelled Portal / At-home, Front desk, Nursing, Doctor, in `src/surgery/v10/stations.ts`; ASC keys `anesthesia`, `orTeam`, `pacu` fold into these), nursing intake and orders `/visits/:id/nursing|orders`, simulated scribe `/visits/:id/scribe` (the transcript is simulated; audio later after a BAA). Audit `station.*`.

**forms**: `GET/POST /practices/:id/form-templates` and `/:file/versions` (publishing a new version never changes signed records), `PUT /practices/:id/forms/:file/stations` (station assignment), signers as in §1, `POST /patients/:id/form-packets` **(code)** (`{forms, channels, portal}` → single-use expiring links → outbox), public `GET/POST /f/:token` (at-home form; patient signature), `POST /encounters/:caseId/forms/:file/sign` ✍, `POST …/addenda` ✍. Audit `form.*`.

**messages**: `GET /threads?patient=`, `POST /threads/:id/messages` (attachments as blobIds), `POST /messages/:id/read`. Delivered to the Portal if a link and the `messages` scope exist, otherwise outbox. Audit `msg.*`.

**billing**: `GET/PUT /practices/:id/fee-schedules` **(code)**, `/cases/:id/invoices` **(code)**, `GET/POST /patients/:id/quotes` (versioned; `POST /quotes/:id/accept` by the patient), `GET/POST /patients/:id/payments` (simulated; a processor is needed later), `GET/POST /visits/:id/charges`. Role: front desk/billing and up. Audit `bill.*`.

**records-packets**: `POST /patients/:id/packets/preview` (→ HIPAA check result `{code: patient|authorized|treatment|no-auth, needsReason}`), `POST /patients/:id/disclosures` **(code)** `{items, recipient, purpose, hipaa_basis, pdf_key}` plus `override_reason` when there is no authorization (**warn, do not block**), `GET /patients/:id/disclosures` (the "Records sent" log = HIPAA accounting of disclosures), `POST /hipaa-authorizations/:id/revoke`. The PDF is built on demand only; **nothing is generated automatically at case close** (confirm with Kevin). Audit `records.sent`.

**reports**: `GET /reports/:name?from=&to=` (read-only views over the modules that are switched on).

**photos-bodycharts**: `POST /patients/:id/images` **(code)** (blob + metadata), `GET /patients/:id/images`, soft DELETE, `GET/PUT /patients/:id/bodycharts/:id`.

**asc-perioperative**: the ASC v7.5 API (your existing backend), plus Send to ASC from Surgery: `POST /asc-packets` (an office → ASC packet; it requires an active office–ASC link and a BAA between them), `GET/POST /asc-packets/:id/messages`.

**portal-link**: `POST /patients/:id/portal-invite`, `GET /portal-links?patient=`, `DELETE /portal-links/:id` (revoke). The Portal app's own API is out of scope until it is built.

## 4. Admin console (Vityls staff only)
`GET /admin/tenants`, `POST /admin/tenants`, `PUT /admin/tenants/:id/modules/:m` (any state; extend a trial), `GET /admin/tenants/:id/data-map`. This is a separate Entra app role, and every call is audited with the Vityls staff user. The simulated "+7 days" clock stays a test feature and is **not** an API.
