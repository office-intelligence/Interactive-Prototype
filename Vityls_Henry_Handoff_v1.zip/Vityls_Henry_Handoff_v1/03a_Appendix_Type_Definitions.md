# Appendix A: TypeScript entity definitions (verbatim from the code)
Generated from `src/` at tag `core-modules-v1.0`. These are the exact shapes the front end stores today; the SQL in `schema_proposed.sql` is derived from them.

## `src/v6/dataLayer.ts`

```ts
export type FieldValue = string | boolean;
export type SourceKind =
  | 'case'        // booked case / patient header (procedure, surgeon, DOB…)
  | 'carried'     // recorded earlier on another form or station
  | 'default'     // practice default, needs confirmation
  | 'normal'      // set by an "All normal / no change" tap
  | 'calc'        // calculated by the app (Aldrete total, BMI, length of stay)
  | 'voice'       // Nightingale suggestion from push-to-talk, accepted by a person
  | 'event'       // OR event-time bar tap
  | 'manual';     // typed by a person

export interface Provenance {
  kind: SourceKind;
export interface Provenance {
  kind: SourceKind;
  label: string;          // human readable, e.g. "Nursing Admission · Pre-op RN · 07:14"
  at: string;             // ISO timestamp
  by?: string;            // user who entered/accepted it
  snippet?: string;       // voice transcript snippet
  confirmed?: boolean;    // true once a person confirmed a prefilled/default value
  needsConfirm?: boolean; // allergies, meds, patient-reported history, defaults, voice
}
export interface Actor { name: string; role: string; credentials?: string; kind: 'human' }
export interface SignatureEvent {
  slotId: string;
  role: string;
  signerName: string;
  credentials?: string;
  attestation: string;
  at: string;
  method: 'drawn' | 'typed';
  image?: string;
  contentHash: string;    // fingerprint of the form values at the moment of signing
  initials?: { page: string; value: string }[];  // per-page initials made by this signer (multi-page packets)
}
export interface Addendum {
  id: string;
  at: string;
  by: string;
  role: string;
  reason: string;
  changes: { key: string; label: string; from: FieldValue | undefined; to: FieldValue }[];
  note?: string;
  signed: boolean;
}
export type FormStatus = 'not-started' | 'draft' | 'partially-signed' | 'locked';
export interface FormRecord {
  caseId: string;
  file: string;
  values: Record<string, FieldValue>;
  labels: Record<string, string>;
  provenance: Record<string, Provenance>;
  signatures: SignatureEvent[];
  addenda: Addendum[];
  status: FormStatus;
  lockedAt?: string;
  lockedHash?: string;
  updatedAt?: string;
  updatedBy?: string;
}
export interface Fact {
  concept: string;
  value: FieldValue;
  source: Provenance & { form?: string; formTitle?: string; station?: string };
}
export interface AuditEntry {
  id: string;
  at: string;
  caseId: string;
  user: string;
  role: string;
  action:
    | 'form.open' | 'form.save' | 'form.confirm' | 'form.normal' | 'form.sign' | 'form.lock'
    | 'form.addendum' | 'voice.suggest' | 'voice.accept' | 'voice.reject' | 'station.verify'
    | 'event.time' | 'fact.confirm' | 'invoice.save' | 'invoice.override'
    | 'provider.invite' | 'provider.application' | 'provider.account' | 'provider.pin-set' | 'provider.pin-reset'
    | 'provider.pin-failure' | 'provider.lock' | 'provider.unlock' | 'provider.deactivate' | 'provider.reactivate'
    // MED v0.1: these two were already written by v7.5 (EventBar edit, station allergy Edit) but missing from the list
    | 'fact.edit' | 'event.time.edit'
    // shared safety fix (both editions): simulated prescription, never transmitted
    | 'erx.simulated'
    // edition switch (practice-level)
    | 'edition.switch'
    // MED v0.1 longitudinal record, visit flow, risk awareness, results, portal, network ASC
    | 'visit.create' | 'visit.step' | 'visit.note.save' | 'visit.note.sign' | 'visit.addendum' | 'visit.recall'
    | 'problem.add' | 'problem.update' | 'med.add' | 'med.update' | 'med.reconcile' | 'vitals.record' | 'intake.record' | 'allergy.confirm'
    | 'risk.review' | 'risk.not-relevant' | 'risk.reopen' | 'risk.settings'
    | 'lab.record' | 'lab.review' | 'lab.release' | 'lab.settings'
    | 'careplan.save' | 'careplan.sign'
    | 'proxy.grant' | 'proxy.revoke' | 'proxy.access' | 'portal.view' | 'portal.message'
    | 'network.message' | 'network.document' | 'network.consent'
    | 'fee.schedule' | 'nightingale.answer'
    // Surgery.Vityls v0.1: intake links, nurse admission, ambient scribe (simulated), checkout orders, summary initials, settings
    | 'intake.link' | 'nurse.admission' | 'scribe.start' | 'scribe.stop' | 'scribe.draft' | 'scribe.suggestion.initial' | 'scribe.suggestion.dismiss'
    | 'checkout.order' | 'summary.initial' | 'visittype.settings' | 'module.settings' | 'network.booking' | 'checkin.identity'
    // Surgery.Vityls v0.2: per-person PINs, arrival, allergy verification, visit charges, ASC packets, settings
    | 'staff.pin' | 'visit.arrive' | 'quote.create' | 'schedule.event' | 'schedule.print' | 'form.template.save' | 'form.template.publish' | 'form.template.restore' | 'form.template.import' | 'form.template.clone' | 'email-intake.accept' | 'email-intake.reply' | 'email-intake.dismiss' | 'quote.edit' | 'quote.revise' | 'quote.status' | 'quote.print' | 'quote.convert' | 'settings.quotes' | 'visit.checkin' | 'allergy.verify' | 'charge.add' | 'charge.remove' | 'invoice.create' | 'asc.packet.send' | 'asc.packet.received' | 'schedule.columns' | 'nurse.ambient'
    // Surgery.Vityls v0.3: staff invitations, surgical coordinators, ad-hoc payments / patient credit, body charts, clinical photos
    | 'staff.invite' | 'staff.account' | 'coordinator.assign' | 'payment.collect' | 'credit.apply' | 'bodychart.save' | 'photo.add' | 'photo.update' | 'photo.view' | 'photo.denied'
    // Surgery.Vityls v0.4: add new patient + forms packet, Practice access PIN, visit-note save needing a physician PIN
    | 'patient.create' | 'forms.packet.send' | 'practice.unlock' | 'practice.lock' | 'practice.denied' | 'visit.note.denied' | 'scribe.draft.keep'
    // Surgery.Vityls v0.5: patient profile edits, payment/referral lists, appointment reminders + confirmation (simulated)
    | 'patient.profile' | 'intake.lists' | 'reminder.send' | 'reminder.settings' | 'appointment.confirm' | 'appointment.unconfirm'
    // Surgery.Vityls v0.6: appointment detail/delete, contact notes, documents folder, hide/delete patient
    | 'appointment.update' | 'appointment.delete' | 'contact.note' | 'contact.note.sign' | 'contact.note.review'
    | 'document.add' | 'document.remove' | 'document.view' | 'document.download' | 'document.summary' | 'document.types'
    | 'patient.hide' | 'patient.restore' | 'patient.delete';
  form?: string;
  detail: string;
}
export interface StoredSignerSlot { id: string; role: string; label: string; attestation: string; required: boolean; patient?: boolean }
export interface StoredInitialsPage { pageIndex: number; pageTitle: string; slot: string; statement?: string; existing?: boolean }
export interface SignerConfig {
  file: string;
  signers: StoredSignerSlot[];
  sequential: boolean;
  initials: StoredInitialsPage[];
  updatedAt: string; updatedBy: string;
}
export interface EncounterRepository {
  getForm(caseId: string, file: string): FormRecord;
  saveForm(rec: FormRecord): void;
  listForms(caseId: string): FormRecord[];
  getFacts(caseId: string): Record<string, Fact>;
  putFacts(caseId: string, facts: Fact[]): void;
  audit(entry: Omit<AuditEntry, 'id' | 'at'> & { at?: string }): AuditEntry;
  getAudit(caseId: string): AuditEntry[];
  getStationVerification(caseId: string): Record<string, { by: string; role: string; at: string }>;
  setStationVerification(caseId: string, station: string, v: { by: string; role: string; at: string }): void;
  getActor(): Actor;
  setActor(a: Actor): void;
  /** Form Studio signer setup (practice configuration, not encounter data). Backend: GET/PUT /practices/:id/forms/:file/signers */
  getSignerConfig(file: string): SignerConfig | null;
  saveSignerConfig(cfg: SignerConfig): void;
  clearSignerConfig(file: string): void;
}
```

## `src/med/record.ts`

```ts
export type ConditionType = 'diabetes' | 'heart' | 'hypertension' | 'osa' | 'ckd' | 'bleeding' | 'lung' | 'thyroid' | 'skin' | 'mental-health' | 'other';
export interface MedPatient { id: string; name: string; dob: string; sex: 'Female' | 'Male' | 'Other'; phone: string; email?: string; language: string; allergies: string[]; allergiesConfirmedAt?: string; allergiesConfirmedBy?: string; primaryProvider: string; careTeam: { name: string; role: string; phone?: string }[]; emergencyContact?: string; insurance?: string; fictional: true; recordSharingConsent?: { granted: boolean; by: string; at: string; scope: string } }
export interface Problem { id: string; patientId: string; description: string; conditionType: ConditionType; status: 'active' | 'resolved'; onset?: string; recordedAt: string; recordedBy: string; source: string; note?: string }
export interface Medication { id: string; patientId: string; name: string; dose: string; frequency: string; status: 'active' | 'stopped'; problemIds: string[]; source: string; recordedAt: string; recordedBy: string; startedAt?: string; stoppedAt?: string; simulatedRx?: boolean }
export interface Vitals { id: string; patientId: string; visitId?: string; at: string; by: string; source: 'manual' | 'simulated-voice' | 'device'; bpSys?: number; bpDia?: number; hr?: number; rr?: number; spo2?: number; tempF?: number; heightIn?: number; weightLb?: number; bmi?: number }
export interface LabResult { id: string; patientId: string; visitId?: string; test: string; value: string; valueNum?: number; unit?: string; reportedRange?: string; collectedAt: string; enteredAt: string; enteredBy: string; source: string; problemIds: string[]; status: 'awaiting-review' | 'reviewed' | 'released'; reviewedBy?: string; reviewedAt?: string; reviewNote?: string; releasedAt?: string; releasedBy?: string; patientNote?: string }
export type IntakeKey = 'smoking' | 'priorAnesthesiaProblems' | 'malignantHyperthermia' | 'bleedingHistory' | 'sleepApnea' | 'bloodClots' | 'pregnancy';
export interface IntakeAnswer { key: IntakeKey; value: string; detail?: string; recordedAt: string; source: string }
export interface CarePlanItem { id: string; kind: 'medication' | 'activity' | 'check'; title: string; instructions: string; times: ('morning' | 'midday' | 'evening' | 'bedtime')[]; days: number[]; medId?: string; problemId?: string }
export interface CarePlanSnapshot { items: CarePlanItem[]; goals: { id: string; text: string; problemId?: string }[]; signedBy: string; signedAt: string; version: number }
export interface CarePlan { patientId: string; items: CarePlanItem[]; goals: { id: string; text: string; problemId?: string }[]; status: 'draft' | 'signed'; updatedAt: string; updatedBy: string; signedBy?: string; signedAt?: string; version: number; published?: CarePlanSnapshot }
export interface Caregiver { id: string; patientId: string; name: string; relationship: string; email?: string; scope: { results: boolean; plan: boolean; appointments: boolean; messages: boolean }; grantedBy: string; grantedVia: 'staff' | 'patient'; authorization: string; grantedAt: string; expiresOn?: string; revokedAt?: string; revokedBy?: string }
export interface PortalMessage { id: string; patientId: string; from: 'patient' | 'caregiver' | 'office'; author: string; text: string; at: string; read?: boolean }
export interface RiskReview { factorId: string; patientId: string; status: 'reviewed' | 'not-relevant'; note: string; by: string; role: string; at: string }
export interface DeviceReading { id: string; patientId: string; device: string; kind: string; value: number; unit: string; at: string; source: 'device' }
export type VisitStep = 'scheduled' | 'check-in' | 'rooming' | 'provider' | 'checkout' | 'complete';
export interface MedVisit { id: string; patientId: string; date: string; time: string; durationMin: number; provider: string; room: string; visitType: string; reason: string; step: VisitStep; problemIds: string[]; createdAt: string; createdBy: string; recall?: { when: string; reason: string; by: string; at: string } }
export interface VisitNote { visitId: string; template: string; subjective: string; objective: string; assessment: string; plan: string; status: 'draft' | 'signed'; updatedAt: string; updatedBy: string; signedBy?: string; signedAt?: string; contentHash?: string; addenda: { at: string; by: string; text: string }[] }
export interface PatientRecordRepository {
  patients(): MedPatient[]; patient(id: string): MedPatient | undefined; savePatient(p: MedPatient): void;
  problems(pid: string): Problem[]; saveProblem(p: Problem, by: string): void;
  meds(pid: string): Medication[]; saveMed(m: Medication, by: string, action?: 'med.add' | 'med.update'): void;
  vitals(pid: string): Vitals[]; addVitals(v: Vitals): void;
  labs(pid?: string): LabResult[]; saveLab(l: LabResult): void;
  intake(pid: string): IntakeAnswer[]; saveIntake(pid: string, a: IntakeAnswer[], by: string): void;
  carePlan(pid: string): CarePlan | undefined; saveCarePlan(c: CarePlan): void;
  caregivers(pid?: string): Caregiver[]; saveCaregiver(c: Caregiver): void;
  messages(pid?: string): PortalMessage[]; addMessage(m: PortalMessage): void;
  riskReviews(pid: string): RiskReview[]; saveRiskReview(r: RiskReview): void;
  visits(pid?: string): MedVisit[]; visit(id: string): MedVisit | undefined; saveVisit(v: MedVisit): void;
  note(visitId: string): VisitNote | undefined; saveNote(n: VisitNote): void;
  deviceReadings(pid: string): DeviceReading[];
}
```

## `src/med/network.ts`

```ts
export interface NetworkCase { id: string; source: 'asc-store' | 'fictional-seed'; ascName: string; date: string; time: string; durationMin: number; surgeon: string; patientName: string; dob: string; procedure: string; room: string; status: string }
export interface NetworkMessage { id: string; caseId: string; at: string; fromOrg: 'office' | 'asc'; author: string; role: string; text: string; simulatedReply?: boolean }
export interface NetworkDocument { id: string; caseId: string; at: string; fromOrg: 'office' | 'asc'; sharedBy: string; title: string; fileName?: string; mime?: string; dataUrl?: string; text?: string }
export interface NetworkRepository {
  cases(): NetworkCase[]; thread(caseId: string): NetworkMessage[]; post(m: NetworkMessage): void;
  documents(caseId: string): NetworkDocument[]; share(d: NetworkDocument): void;
}
```

## `src/med/settings.ts`

```ts
export interface NumericTrigger { id: 'bmi' | 'a1c' | 'bpSys' | 'bpDia'; label: string; unit: string; source: 'vitals' | 'lab'; labTest?: string; enabled: boolean; operator: '>=' | '<='; value: number | null; approvedBy: string; approvedOn: string }
export interface ResultBand { test: string; low: number | null; high: number | null; approvedBy: string; approvedOn: string }
export interface FeeItem { id: string; name: string; visitType?: string; price: number; code: string; active: boolean }
export interface MedSettings {
  autoReleaseResults: boolean;
  triggers: NumericTrigger[];
  bands: ResultBand[];
  labDescriptions: Record<string, string>;
  fees: FeeItem[];
  features: { chronicRegistries: boolean; remoteMonitoring: boolean };
  practiceName: string; ascName: string;
}
```

## `src/med/fees.ts`

```ts
export interface FeeLine { item: FeeItem; qty: number; amount: number }
```

## `src/surgery/store.ts`

```ts
export type VisitCategory = 'new' | 'follow-up' | 'pre-op' | 'post-op' | 'clearance' | 'procedure' | 'other';
export interface VisitTypeDef { id: string; name: string; color: string; durationMin: number; category: VisitCategory; surgical: boolean; active: boolean }
export interface SurgicalModules { riskAwareness: boolean; networkAsc: boolean; blockTime: boolean; surgeryBooking: boolean; preopClearance: boolean; ambientScribe: boolean }
export interface SurgerySettings { visitTypes: VisitTypeDef[]; modules: SurgicalModules }
export interface NurseAdmission { visitId: string; patientId: string; chiefComplaint: string; pain: string; vitalsId?: string; allergiesConfirmed: boolean; medsReviewed: boolean; anticoagulantLastDose: string; npo: string; escort: string; fallRisk: string; nurseNote: string; by: string; role: string; at: string }
export interface ScribeLine { at: string; speaker: 'Surgeon' | 'Patient' | 'Family' | 'Nurse'; text: string }
export interface ScribeSuggestion { id: string; kind: 'surgery-booking' | 'follow-up' | 'clearance' | 'other'; text: string; detail: string; status: 'pending' | 'initialed' | 'dismissed'; by?: string; at?: string }
export interface ScribeDraft { hpi: string; exam: string; assessment: string; plan: string }
export interface ScribeSession { visitId: string; status: 'idle' | 'listening' | 'paused' | 'stopped'; lines: ScribeLine[]; draft: ScribeDraft; suggestions: ScribeSuggestion[]; startedAt?: string; stoppedAt?: string; startedBy?: string; noteCreatedAt?: string }
export interface CheckoutOrder { id: string; visitId: string; patientId: string; kind: 'surgery-booking' | 'follow-up' | 'clearance' | 'other'; text: string; detail: string; status: 'to-do' | 'done' | 'cancelled'; source: string; createdBy: string; createdAt: string; doneBy?: string; doneAt?: string; result?: string }
export interface IntakeLink { id: string; patientId: string; visitId: string; forms: string[]; channel: 'email' | 'text'; to: string; link: string; createdAt: string; by: string; status: 'queued-simulated' }
export interface SurgicalHistoryItem { id: string; patientId: string; text: string; year?: string; detail?: string; source: string; recordedAt: string }
export interface SummaryInitial { patientId: string; by: string; role: string; at: string; fingerprint: string }
export interface KeptNote { id: string; patientId: string; question: string; text: string; cites: { kind: string; id?: string; label: string }[]; keptBy: string; keptAt: string }
export interface AscBlock { id: string; source: 'asc-store' | 'fictional-seed'; surgeon: string; date: string; start: string; end: string; room: string; ascName: string }
export interface BookingRequest extends NetworkCase { requestedBy: string; requestedAt: string; visitId: string; patientId: string }
```

## `src/surgery/staff.ts`

```ts
export interface StaffMember { id: string; name: string; role: string; credentials?: string; pinHash: string; active: boolean; fails: number; locked?: boolean; email?: string; status?: 'invited' | 'active'; username?: string; pwHash?: string; invitedAt?: string; activatedAt?: string }
export interface StaffInvite { token: string; staffId: string; to: string; toName: string; role: string; link: string; subject: string; body: string; sentAt: string; sentBy: string; expiresAt: string; usedAt?: string; revokedAt?: string; transport: 'simulated-outbox' }
export type StaffInviteCheck = { state: 'ok' | 'used' | 'revoked' | 'expired' | 'invalid'; inv?: StaffInvite; staff?: StaffMember };
```

## `src/surgery/asc.ts`

```ts
export interface AscFacility { id: string; name: string; city: string; active: boolean; primary?: boolean }
export type PacketDocKind = 'note' | 'clearance' | 'lab' | 'vitals' | 'meds' | 'allergy' | 'problems' | 'history' | 'form' | 'nurse' | 'intake' | 'scribe';
export interface PacketDoc { id: string; kind: PacketDocKind; title: string; detail: string; text: string; recommended: boolean }
export interface SchedulingForm {
  procedure: string; cpt: string; diagnosis: string; icd10: string; laterality: 'N/A' | 'Left' | 'Right' | 'Bilateral';
  anesthesia: 'General' | 'MAC / sedation' | 'Regional' | 'Local' | 'Surgeon to discuss'; durationMin: number;
  blockId: string; preferredDate: string; preferredTime: string; admission: 'Outpatient (same day)' | '23-hour observation';
  equipment: string; implants: string; specialNeeds: string; latexAllergy: boolean; allergies: string; notes: string;
}
export interface AscPacket {
  id: string; patientId: string; visitId: string; caseId: string; facilityId: string; facilityName: string; surgeon: string;
  form: SchedulingForm; docs: { id: string; kind: PacketDocKind; title: string; detail: string }[];
  sentBy: string; sentRole: string; sentAt: string; status: 'sent' | 'received'; receivedAt?: string; ascChartId?: string;
}
```

## `src/surgery/media.tsx`

```ts
export interface Stroke { c: string; w: number; pts: number[] }
export interface ChartText { x: number; y: number; t: string; c: string }
export interface BodyChartRec { id: string; seriesId: string; version: number; patientId: string; visitId?: string; diagram: string; title: string; strokes: Stroke[]; texts: ChartText[]; by: string; role: string; at: string; example?: boolean }
export type Phase = 'before' | 'after';
export interface PhotoRec { id: string; patientId: string; visitId?: string; src?: string; synth?: SynthSpec; phase: Phase; date: string; area: string; view: string; note: string; by: string; role: string; at: string; example?: boolean }
```

## `src/surgery/charges.tsx`

```ts
export type Station = 'Nurse' | 'Physician' | 'Checkout';
export interface ChargeLine { id: string; visitId: string; patientId: string; feeId: string; label: string; code: string; qty: number; amount: number; addedBy: string; role: string; station: Station | 'Fee schedule'; at: string; invoiceId?: string }
```

## `src/surgery/contactNotes.tsx`

```ts
export interface ContactNote { id: string; patientId: string; channel: string; direction: 'Incoming' | 'Outgoing'; reason: string; text: string; author: string; authorRole: string; session: string; contactAt: string; at: string; dictated: boolean; flagged: boolean; reviewed?: { by: string; at: string }; signed?: { by: string; role: string; at: string; hash: string } }
```

## `src/surgery/patientAdmin.tsx`

```ts
export interface HiddenRec { pid: string; name: string; dob: string; reason: string; note: string; by: string; role: string; at: string }
export interface DeletedRec { pid: string; name: string; dob: string; reason: string; note: string; by: string; role: string; at: string; removed: number }
```

## `src/surgery/apptDetail.tsx`

```ts
export interface DeletedVisit { visit: MedVisit; reason: string; note: string; by: string; role: string; at: string; session: string }
```

## `src/surgery/documents.tsx`

```ts
export interface DocSummary { text: string; facts: string[]; engine: string; at: string; by: string }
export interface DocRec { id: string; patientId: string; type: string; title: string; source: string; docDate: string; receivedAt: string; receivedBy: string; receivedRole: string; description?: string; fileName?: string; mime?: string; size?: number; dataUrl?: string; text?: string; lines?: string[]; scripted?: { text: string; facts: string[] }; summary?: DocSummary; example?: boolean; removedAt?: string; removedBy?: string; removedReason?: string }
```

## `src/surgery/newPatient.tsx`

```ts
export interface FormsPacket { id: string; patientId: string; forms: string[]; text?: string; email?: string; portal: boolean; message: string; link: string; sentAt: string; by: string; role: string; transport: 'simulated-outbox' }
```

## `src/surgery/v13/hipaa.ts`

```ts
export interface HipaaAuth { key: string; caseId: string; patientId: string; signedAt: string; signedBy: string; rep?: string; recipients: string[]; recipientNames: string[]; info: string[]; sensitive: string[]; purposes: string[]; expiresOn?: string; expiresEvent?: string; until: string; status: 'active' | 'expired' | 'revoked'; revoked?: Revocation; seeded?: boolean }
export interface Revocation { key: string; at: string; by: string; role: string; note: string }
export type RecipientKind = 'referring' | 'doctor' | 'asc' | 'patient' | 'free';
export interface HipaaResult { level: 'ok' | 'info' | 'warn'; code: 'patient' | 'authorized' | 'treatment' | 'no-auth'; title: string; text: string; auth?: HipaaAuth; lapsed?: HipaaAuth; needsReason: boolean; defaultReason?: string; sensitive: string[] }
```

## `src/surgery/profile.tsx`

```ts
export interface IntakeLists { paymentTypes: string[]; referralSources: string[] }
export type PreferredContact = 'text' | 'email' | 'text+email' | 'phone';
export interface PatientProfile {
  firstName?: string; lastName?: string; altPhone?: string; preferredContact?: PreferredContact;
  address?: string; city?: string; state?: string; zip?: string;
  emergencyName?: string; emergencyRelation?: string; emergencyPhone?: string;
  paymentType?: string; insuranceCarrier?: string; memberId?: string; referralSource?: string; referredBy?: string;
  profileUpdatedAt?: string; profileUpdatedBy?: string;
}
export type SvPatient = MedPatient & PatientProfile;
export interface PayRef { paymentType: string; insuranceCarrier: string; memberId: string; referralSource: string; referredBy: string }
export interface NewPatientInput { first: string; last: string; dob: string; sex: MedPatient['sex']; phone: string; email: string; payRef: PayRef }
```

## `src/surgery/v12/msgAtt.ts`

```ts
export interface Att { id: string; msgId: string; patientId: string; name: string; mime: string; size: number; at: string; by: string; kind: 'image' | 'pdf' | 'doc' | 'heic' | 'text'; filed?: { docId: string; type: string; at: string; by: string } }
export interface Pending { tmp: string; name: string; mime: string; size: number; kind: Att['kind']; data: string }
```

## `src/surgery/v09/schedData.ts`

```ts
export interface SchedResource { id: string; kind: 'person' | 'room'; name: string; role: string; schedulable: boolean; custom?: boolean }
export type Recur = 'none' | 'daily' | 'weekly' | 'monthly';
export interface OfficeEvent { id: string; title: string; kind: string; date: string; start: string; end: string; allDay: boolean; recur: Recur; until?: string; notes?: string; createdBy: string; createdAt: string }
```

## `src/surgery/v13/packet.ts`

```ts
export type Group = 'summary' | 'documents' | 'encounters' | 'notes' | 'results' | 'photos' | 'forms' | 'quotes';
export interface PItem { id: string; group: Group; title: string; detail: string; date: string; tags: string[]; sub?: string }
export type PresetId = 'preop' | 'referral' | 'consult' | 'patient' | 'custom';
export interface Preset { id: PresetId; label: string; hint: string; recipient: RecipientKind; purpose: string; pick: (l: PItem[]) => string[] }
export interface OutsideDoctor { id: string; name: string; specialty: string; org: string; fax: string; email: string; phone: string }
export type Method = 'email' | 'fax' | 'portal' | 'network';
export interface Recipient { kind: RecipientKind; name: string; org?: string; method: Method; address: string; ascId?: string }
interface Sec { title: string; lines: { t: string; b?: boolean; s?: number; gap?: number }[] }
export interface BuildOpts { p: MedPatient; ids: string[]; recipient?: Recipient; purpose: string; coverSheet: boolean; coverLetter?: string; from: string; fromRole: string; title?: string }
export interface Built { bytes: Uint8Array; pages: number; toc: { title: string; page: number }[] }
export interface SentRec { id: string; patientId: string; at: string; by: string; role: string; title: string; preset: PresetId; purpose: string; recipient: Recipient; items: { id: string; title: string }[]; pages: number; size: number; coverLetter?: string; coverSheet: boolean;
  hipaa: { code: HipaaResult['code']; level: HipaaResult['level']; title: string; authKey?: string; reason?: string; note?: string }; resendOf?: string; delivery: string; pdfKey: string }
export interface OutMail { id: string; at: string; to: string; channel: Method; subject: string; body: string; attachment: string; pages: number; patientId: string }
```

## `src/surgery/v12/cards.ts`

```ts
export type Side = 'front' | 'back';
export interface CardImg { at: string; by: string; via: string }
export interface InsCard { id: string; rank: string; carrier?: string; memberId?: string; group?: string; front?: CardImg; back?: CardImg }
export interface PatientCards { photoId: { front?: CardImg; back?: CardImg }; insurance: InsCard[] }
```

## `src/surgery/v10/dx.ts`

```ts
export type DxStatus = 'performed' | 'planned';
export interface PatientDx { diagnosis: string; procedure: string; status: DxStatus; date?: string }
export interface DxProc { id: string; name: string; status: DxStatus; date?: string; surgeon?: string; asc?: string }
export interface DxEntry { id: string; diagnosis: string; icd?: string; procedures: DxProc[]; primary?: boolean }
```

## `src/surgery/payments.tsx`

```ts
export type PayMethod = 'card' | 'cash' | 'check' | 'financing' | 'other';
export interface Application { invoiceId: string; invoiceNumber: string; amount: number; at: string; by: string }
export interface PatientPayment { id: string; receipt: string; patientId: string; amount: number; method: PayMethod; card?: { brand: string; last4: string; exp: string }; reference: string; reason: string; takenBy: string; role: string; at: string; channel: 'in person' | 'phone' | 'portal link'; applied: Application[]; status: 'posted (simulated)' }
```

## `src/surgery/v12/pinReset.ts`

```ts
export interface Person { kind: 'staff' | 'provider'; id: string; name: string; role: string; email: string; username: string; seeded: boolean; locked: boolean }
export interface OutMail { id: string; to: string; toName: string; subject: string; body: string; at: string; kind: 'pin-reset' | 'pin-reset-admin'; link?: string; transport: 'simulated-outbox' }
export interface ResetReq { token: string; personKey: string; name: string; at: string; expiresAt: string; by: string; via: 'self' | 'admin'; usedAt?: string; revokedAt?: string }
export type ResetCheck = { state: 'ok' | 'used' | 'revoked' | 'expired' | 'invalid'; r?: ResetReq; p?: Person };
```

## `src/surgery/SurgeryPractice.tsx`

```ts
interface Profile { address: string; phone: string; hoursStart: string; hoursEnd: string; rooms: string[] }
```

## `src/surgery/quotes.tsx`

```ts
export type QuoteStatus = 'Draft' | 'Presented' | 'Accepted' | 'Declined' | 'Expired';
export type QuoteCat = typeof SURGERY_QUOTE_CATS[number] | typeof MEDICAL_QUOTE_CATS[number];
export interface QuoteLine { id: string; cat: QuoteCat; label: string; qty: number; unit: number; code?: string }
export interface QuoteVersion { v: number; createdAt: string; createdBy: string; createdRole: string; date: string; validUntil: string; procedure: string; surgeon: string; lines: QuoteLine[]; terms: string; financing: string; note: string; total: number }
export interface QuoteEvent { at: string; by: string; role: string; what: string }
export interface Quote { id: string; number: string; patientId: string; status: QuoteStatus; versions: QuoteVersion[]; events: QuoteEvent[]; invoiceId?: string; invoiceNumber?: string; duplicatedFrom?: string }
export interface CatalogItem { id: string; cat: QuoteCat; label: string; price: number }
export interface QuoteSettings { validDays: number; terms: string; financing: string; address: string; phone: string; catalog: CatalogItem[] }
type QAction = 'quote.create' | 'quote.edit' | 'quote.revise' | 'quote.status' | 'quote.print' | 'quote.convert';
type Mode = { kind: 'new' } | { kind: 'edit' | 'revise' | 'duplicate'; q: Quote };
```

## `src/surgery/reminders.tsx`

```ts
export interface ReminderSettings { enabled: boolean; intervalHours: number; maxRequests: number; dayBefore: boolean; dayBeforeTime: string; quietStart: number; quietEnd: number }
export type ConfirmState = 'confirmed' | 'reschedule';
export interface ApptConfirm { visitId: string; status: ConfirmState; at: string; by: string; via: 'patient-reply' | 'portal' | 'staff-call' | 'staff' }
export type ReminderKind = 'confirm-request' | 'day-before' | 'manual';
export interface ReminderSend { id: string; visitId: string; patientId: string; kind: ReminderKind; channels: ('text' | 'email')[]; to: string; message: string; at: string; attempt: number; by: string; transport: 'simulated-outbox' }
export type BadgeState = 'confirmed' | 'reschedule' | 'waiting' | 'call' | 'off' | 'none';
```

## `src/surgery/v09/formLib.ts`

```ts
export type FieldType = 'text' | 'longtext' | 'number' | 'date' | 'yesno' | 'single' | 'multi' | 'dropdown' | 'checkbox' | 'signature' | 'initials' | 'grid' | 'heading' | 'instruction' | 'prefill';
export interface Cond { field: string; op: 'eq' | 'neq' | 'checked' | 'filled'; value?: string }
export interface Field { id: string; type: FieldType; name: string; label: string; help?: string; required?: boolean; defaultValue?: string; options?: string[]; width?: 1 | 2 | 3; prefill?: string; cond?: Cond; columns?: string[]; rows?: number; placeholder?: string }
export interface Section { id: string; title: string; columns: 1 | 2 | 3; fields: Field[]; cond?: Cond }
export interface FormDef { title: string; intro?: string; sections: Section[] }
export interface Ver { v: number; def: FormDef; at: string; by: string; note?: string }
export interface LibEntry { file: string; title: string; clonedFrom?: string; versions: Ver[]; published?: number; draft?: FormDef; draftAt?: string; events: { at: string; by: string; what: string }[] }
export type Status = 'original' | 'draft' | 'published';
```

## `src/core/modules.ts`

```ts
export type ModuleId = 'email-intake' | 'scheduling' | 'chart' | 'stations-workflow' | 'forms' | 'messages' | 'billing' | 'records-packets' | 'reports' | 'photos-bodycharts' | 'asc-perioperative' | 'portal-link';
export type CoreService = 'tenant' | 'users-pins' | 'patients' | 'documents' | 'audit' | 'nightingale' | 'outbox' | 'entitlements';
export interface ModuleDef {
  id: ModuleId; name: string; short: string; description: string; pitch: string[];
  core: CoreService[]; requires: ModuleId[]; enhances: ModuleId[];
  nav: { tab: string; label: string; order: number }[];
  routes: string[];                      // app tabs this module owns
  practicePanels: string[];              // Practice › items (tab ids)
  chartSurfaces: string[];               // chart tabs / cards / buttons
  nightingale: string[];                 // Nightingale commands / chips it contributes
  stationSteps: string[];                // station workflow steps
  storage: string[];                     // storage key prefixes (for Henry's per-module tables)
  standalone: string;                    // what it does when it is the only module (or without the chart)
  trialDays: number; priceHint: string;
}
```

## `src/core/practices.ts`

```ts
export type ModState = 'off' | 'trial' | 'active' | 'expired';
export interface Entitlement { state: ModState; trialStart?: string; trialEnd?: string; trialDays?: number; via?: ModuleId; since?: string; trialsUsed?: number }
export type CoreEdition = 'ASC' | 'SURGERY' | 'MEDICAL';
export interface Practice {
  id: string; name: string; edition: CoreEdition;
  /** Code path the shell runs. Frozen full-bundle ASC runs the ASC.Vityls app; every other practice runs the modular office shell. */
  runtime: 'ASC' | 'SURGERY' | 'MEDICAL'; namespace: string; brand: string;
  locked: 'teaser' | 'hidden';          // locked modules: calm “Try free” teaser in nav, or only on Modules & plan
  expired: 'read-only' | 'hidden';      // after a trial ends
  frozen?: boolean; note?: string;
  modules: Record<string, Entitlement>;
}
export interface CoreAudit { at: string; practiceId: string; by: string; action: string; module?: ModuleId; detail: string }
```

## `src/core/store.ts`

```ts
export interface OutboxItem { id: string; at: string; module: ModuleId | 'core'; to: string; subject: string; body: string; by: string; attachments?: string[] }
```

## `src/modules/email-intake/data.ts`

```ts
export interface Attachment { id: string; name: string; kind: 'H&P' | 'Labs' | 'Insurance' | 'Imaging' | 'Referral'; docType: string; text: string }
export interface Extraction { patient: string; dob: string; phone: string; procedure: string; requestedDate: string; surgeon: string; referring: string; insurance: string; urgency: string; confidence: Record<string, 'high' | 'medium' | 'low'> }
export interface Email { id: string; from: string; fromName: string; org: string; subject: string; body: string; receivedAt: string; attachments: Attachment[]; kind: 'request' | 'other'; extraction?: Extraction;
  status: 'new' | 'accepted' | 'replied' | 'dismissed'; patientId?: string; matched?: boolean; filedDocs?: string[]; requestId?: string; visitId?: string; reply?: { text: string; at: string; by: string; outboxId: string } }
export interface SchedRequest { id: string; emailId: string; patientId: string; patient: string; procedure: string; requestedDate: string; surgeon: string; referring: string; status: 'awaiting-scheduling' | 'booked'; visitId?: string; createdAt: string; createdBy: string }
```

## `src/utils/localFormStudioDb.ts`

```ts
export interface LocalPractice {
  id: string;
  name: string;
  createdAt: string;
}
export type FormLifecycleStatus = 'Draft' | 'Active' | 'Superseded' | 'Retired';
export interface LocalFormTemplate {
  id: string;
  templateId?: string;
  practiceId: string;
  title: string;
  version: string;
  profile: string;
  collectionStage: string;
  reviewStages: string[];
  fields: unknown[];
  updatedAt: string;
  createdAt?: string;
  status?: FormLifecycleStatus;
  publishedAt?: string;
  supersededAt?: string;
  retiredAt?: string;
  basedOnId?: string;
  sourceTemplate?: string;
  sourceFile?: string;
  presentationHtml?: string;
  sourceCssPreserved?: boolean;
}
export interface LocalPdfTemplate {
  id: string;
  practiceId: string;
  title: string;
  version: string;
  status: 'Template' | 'Active' | 'Retired';
  collectionStage: string;
  reviewStages: string[];
  category: string;
  fileName: string;
  mimeType: string;
  uploadedAt: string;
  updatedAt: string;
  blob: Blob;
}
export interface LocalEncounterDocument {
  id: string;
  practiceId: string;
  patientId: string;
  encounterKey: string;
  title: string;
  sourceType: 'PDF_TEMPLATE' | 'PAPER_SCAN' | 'UPLOADED_PDF' | 'HTML_FINAL';
  templateId?: string;
  fileName: string;
  mimeType: string;
  uploadedAt: string;
  uploadedBy: string;
  blob?: Blob;
  aiStatus: 'Pending Review' | 'Summarized';
  reviewStatus?: 'Pending Review' | 'Reviewed';
  aiSummary: string;
  classification: string;
}
```

## `src/v7/billing.ts`

```ts
export interface TimeFee { base: number; includedMin: number; perIncrement: number; incrementMin: number }
export type MatchKind = 'default' | 'procedure' | 'surgeon' | 'anesthesiaType' | 'room';
export interface FeeSchedule { id: string; name: string; match: { kind: MatchKind; value: string }; facility: TimeFee; anesthesia: TimeFee; surgeonFee: number; notes?: string }
export interface InvoiceLine { label: string; detail: string; amount: number }
export interface Invoice {
  id: string; number: string; caseId: string; patientName: string; patientId: string; dos: string; procedure: string; surgeon: string; anesthesiologist?: string;
  paymentType: string; scheduleId: string; scheduleName: string; facilityMin: number; anesthesiaMin: number; lines: InvoiceLine[]; total: number; paid: number;
  status: 'Draft' | 'Sent (simulated)' | 'Partially paid' | 'Paid in full'; createdAt: string; createdBy: string;
  /** v7.1: issued by a manager before the normal eligibility rule was met. */
  override?: { by: string; role: string; reason: string; at: string; unmet: string[] };
}
```

## `src/v7/providers.ts`

```ts
export type ProviderRole = 'Surgeon' | 'Anesthesiologist' | 'CRNA' | 'Other provider' | 'Physician' | 'Nurse practitioner' | 'Physician assistant'; // last three: MED edition
export const CRED_STEPS = ['Queued', 'Invited', 'Application received', 'Credentials verified', 'Medical Director review', 'Privileges approved'] as const;
export type CredStatus = typeof CRED_STEPS[number] | 'Declined';
export interface CredApp { id: string; status: CredStatus; createdAt: string; history: { status: CredStatus | string; at: string; by: string; note?: string }[] }
export interface Onboarding { invitedAt?: string; applicationAt?: string; accountAt?: string; pinAt?: string; username?: string; inviteCount?: number; lastInviteId?: string; application?: Record<string, string | string[]> }
export interface Provider { id: string; firstName: string; lastName: string; degree: string; role: ProviderRole; specialty: string; npi: string; email: string; phone: string; color: string; pinHash: string; active: boolean; app: CredApp; onboarding?: Onboarding;
  /** v7.4 account controls */ locked?: boolean; pinFailures?: number; lockedAt?: string; deactivatedAt?: string; deactivatedBy?: string; deactivationReason?: string }
export type PinCheck = 'ok' | 'wrong' | 'unregistered' | 'locked' | 'inactive' | 'nopin';
```

## `src/v7/invitations.ts`

```ts
export type InvitePurpose = 'application' | 'account' | 'pin';
export interface InviteToken { token: string; providerId: string; purpose: InvitePurpose; inviteId: string; practice: string; issuedAt: string; expiresAt: string; usedAt?: string; revokedAt?: string }
export interface OutboxEmail { id: string; kind: 'provider-invitation' | 'pin-reset'; providerId: string; to: string; toName: string; from: string; subject: string; body: string; links: Partial<Record<InvitePurpose, string>>; sentAt: string; sentBy: string; transport: string; resend: boolean; expiresAt: string }
export interface EmailTransport { id: string; label: string; send: (m: OutboxEmail) => Promise<void> | void }
export type TokenCheck = { state: 'ok' | 'used' | 'revoked' | 'expired' | 'invalid'; tok?: InviteToken; provider?: Provider; siblings?: Partial<Record<InvitePurpose, string>> };
type Account = { providerId: string; username: string; pwHash: string; createdAt: string };
```

## `src/surgery/v11/apptNotes.tsx`

```ts
export type SvVisit = MedVisit & { notes?: string };
```
