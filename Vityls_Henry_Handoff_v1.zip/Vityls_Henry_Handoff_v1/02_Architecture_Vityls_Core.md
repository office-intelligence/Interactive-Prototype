# 02 · Vityls Core architecture (with backend additions)

**Part A** is the architecture doc shipped with `core-modules-v1.0`, copied verbatim from `report/Vityls_Core_Modules_Architecture.md`. It describes the code as it is.
Note: the SQL sketch in A.5 uses `practices` / `practice_id`. The fuller `schema_proposed.sql` (see 03) renames these to `core.tenants` / `tenant_id`. **Use `schema_proposed.sql` as the reference.**

**Part B** adds what the backend needs: multi-tenancy, splitting patient identity from practice records, Portal consent links, server-side module entitlements, and a recommended Azure stack. Part B is a **proposal**. None of it exists in code yet. The app today is browser-only (localStorage and IndexedDB), with no backend.

---

# Part A: as built (core-modules v1.0)


Branch `core-modules` (from `medical-v1.0`), tag `core-modules-v1.0`. Test build: `Vityls_Core_Modules_v1.0.zip`, one app with a practice switcher (bottom-left) and the internal **Vityls admin console** (`index.html#vityls-admin`).

### A.1. The layers

```
┌───────────────────────── Editions (bundles + terminology + templates) ─────────────────────────┐
│  ASC.Vityls        Surgery.Vityls        Medical.Vityls        (MedSpa, Chiropractic … later)    │
├──────────────────────────────────────── Modules ───────────────────────────────────────────────┤
│ email-intake · scheduling · chart · stations-workflow · forms · messages · billing ·            │
│ records-packets · reports · photos-bodycharts · asc-perioperative · portal-link                 │
├──────────────────────────────────────── Vityls Core (always on) ───────────────────────────────┤
│ tenant/practice · users, roles & PINs · patients (minimal identity) · documents store · audit · │
│ Nightingale shell · notifications/outbox · subscription & entitlements                          │
└─────────────────────────────────────────────────────────────────────────────────────────────────┘
```

Code: `src/core/` (Core: `modules.ts` registry, `practices.ts` tenant + entitlements + simulated clock, `store.ts` module data layer + outbox, `useCore.tsx` React gating, `ui.tsx` teaser / trial banner / Modules & plan / minimal patient, `AdminConsole.tsx`), `src/modules/email-intake/` (new module). The shell (`src/surgery/SurgeryApp.tsx`) asks Core before it renders any nav entry, route, Practice panel, chart tab/card, Nightingale chip or Portal link.

### A.2. Core services

| Service | What it holds | Today in the code |
|---|---|---|
| Tenant / practice | practice id, name, edition, namespace, teaser + expiry options | `src/core/practices.ts` (`vityls:core:practices`) |
| Users, roles & PINs | staff, providers, session, PIN signing, Forgot PIN | `src/surgery/staff.ts`, `v7/providers.ts`, `surgery/v12/pinReset.ts` |
| Patients (minimal identity) | name, DOB, sex, contact, language, insurance, allergies | `medRepo.patients()` (`vityls:med:patients`) |
| Documents store | every filed document (+ Nightingale summary) | `surgery/documents.tsx` (`vityls:surgery:documents`) |
| Audit | every action (practice audit) + entitlement audit | `repo.audit()` + `vityls:core:audit` |
| Nightingale shell | header card, chips, scripted answers | `surgery/v07/NightingaleCard.tsx`, `surgery/nightingale.ts` |
| Notifications / outbox | simulated email/SMS outbox | `vityls:mod:core:outbox` (`core/store.ts`) + legacy reminder outbox |
| Subscription & entitlements | module state per practice, trials, plan history | `core/practices.ts` |

### A.3. Modules

The proposed list was kept with two adjustments, both from how the code really splits:
- **chart** covers notes, documents UI and timeline/activity (they share one page, `Chart7`, and one data set). The Patients **list** and the minimal patient record stay in Core, so every module can open a patient.
- **scheduling** owns Today as well as the Schedule: the Today board is the day's schedule plus arrivals and check-in. Visit types/reminder settings are its Practice panel.
- **portal-link** is a thin module (the Portal button, at-home check-in and portal side of messages/forms); the Patient Portal itself becomes its own app on Core (section 9).

| Module | Hard needs | Enhances | Surfaces it contributes | Alone / without chart | Trial |
|---|---|---|---|---|---|
| email-intake (new) | — | scheduling, chart | nav “Email intake”; Nightingale “Review new requests”, “Draft a reply” | creates/matches a Core patient, files attachments to Core documents, queues a scheduling request | 14 d |
| scheduling (+ reminders) | — | chart, forms, stations, email-intake | nav Today + Schedule; Practice “Visit types, intake lists & reminders”; chart Next/Past visits | patients open as the minimal Core record | 14 d |
| chart | — | scheduling, messages, billing | chart Overview/Clinical/Documents/Notes/Activity; Practice “Patient records” | records chart without scheduling | 14 d |
| stations-workflow | scheduling, chart | forms, billing | station route (visit workflow), station steps Front desk → Nursing → Provider → Checkout | needs a visit and a chart | 14 d |
| forms (+ editor, at-home) | scheduling | stations, chart | Practice “Forms & workflow”, form editor, at-home links, station form steps | with scheduling + minimal patient | 14 d |
| messages | — | chart, portal-link | nav Messages; chart portal messages card | “Open chart” → minimal record | 14 d |
| billing (invoices, payments, quotes) | — | chart, stations | Practice “Billing & payments”; chart quotes | invoices against Core patients | 14 d |
| records-packets | chart | forms | chart Print / Send button, Records sent log | lives on the chart | 7 d |
| reports | — | scheduling, billing, chart | Practice “Practice performance & reports” | reports on what is on | 7 d |
| photos-bodycharts | chart | records-packets | chart “Photos & charts” tab | lives on the chart | 7 d |
| asc-perioperative | scheduling | chart, forms | ASC OR/PACU/anesthesia (ASC app); Send to ASC (Surgery) | part of ASC bundle | 14 d |
| portal-link | — | forms, messages, billing | top-bar Portal link, at-home | — | 14 d |

```mermaid
graph TD
  CORE[Vityls Core: tenant · users/PINs · patients · documents · audit · Nightingale · outbox · entitlements]
  EI[email-intake] --> CORE
  SCH[scheduling] --> CORE
  CH[chart] --> CORE
  MSG[messages] --> CORE
  BIL[billing] --> CORE
  REP[reports] --> CORE
  PL[portal-link] --> CORE
  ST[stations-workflow] -->|requires| SCH
  ST -->|requires| CH
  FO[forms] -->|requires| SCH
  RP[records-packets] -->|requires| CH
  PH[photos-bodycharts] -->|requires| CH
  ASC[asc-perioperative] -->|requires| SCH
  EI -.enhances.-> SCH
  EI -.enhances.-> CH
  FO -.enhances.-> ST
  MSG -.enhances.-> CH
  BIL -.enhances.-> ST
  PL -.enhances.-> FO
  PL -.enhances.-> MSG
```

Solid arrows are hard dependencies; dotted are “enhances” (the module works without it and shows more when it is on).

### A.4. Entitlement model

Per practice, each module has a state:

| State | Meaning | What the user sees |
|---|---|---|
| `off` | not in the plan | nothing, or a calm **“Try free for N days”** teaser (preview, description, Start trial) — per practice: `locked = teaser` (nav entry with a lock) or `hidden` (only on Practice › Modules & plan) |
| `trial` | `trial_start`, `trial_end`, days left | full module + a slim “free trial · N days left · Keep it” banner |
| `active` | paid | full module |
| `expired` | trial ended, data kept | per practice `expired = read-only` (module visible, inputs disabled, banner “Read only … Add to plan”) or `hidden` (teaser “Trial ended … Add to plan”) |

- Trials are evaluated against the clock (`now()`; the admin console can move a simulated clock **+7 days**). Expiry is persisted once and audited (`trial.expire`).
- **Dependency choice: “bring along, shown first.”** Enabling or trialing a module whose hard dependency is off shows the need on the teaser (“Needs Patient chart. The trial starts it too, for the same days.”) and on confirm starts the dependency with the same state and end date, marked `via = <module>`. Nothing starts silently. Switching off a module that another enabled module needs is refused with the reason (“Scheduling is needed by Forms & at-home…”). We chose this over a separate “lite” mode because the code has no second, smaller version of the chart or scheduler to maintain; the minimal standalone behaviour lives in Core (minimal patient record) instead.
- Only a practice manager/administrator can start a trial or add a module from inside the practice; Vityls staff can do everything from the admin console. Every change is audited with who/when/what.
- Outside the combined Core build (the per-edition packages) everything is on; nothing changes.

### A.5. Proposed SQL tables (Azure SQL / T-SQL flavour)

```sql
CREATE TABLE practices (
  practice_id      UNIQUEIDENTIFIER PRIMARY KEY,
  name             NVARCHAR(200) NOT NULL,
  edition          VARCHAR(20) NOT NULL,          -- ASC | SURGERY | MEDICAL | MEDSPA | CHIRO
  plan_id          VARCHAR(40) NULL REFERENCES plans(plan_id),
  locked_display   VARCHAR(10) NOT NULL DEFAULT 'teaser',   -- teaser | hidden
  expired_display  VARCHAR(10) NOT NULL DEFAULT 'read-only',-- read-only | hidden
  created_at       DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME()
);
CREATE TABLE modules (
  module_id        VARCHAR(40) PRIMARY KEY,       -- 'email-intake', 'scheduling', …
  name             NVARCHAR(120) NOT NULL,
  description      NVARCHAR(1000) NOT NULL,
  default_trial_days INT NOT NULL DEFAULT 14,
  is_core          BIT NOT NULL DEFAULT 0
);
CREATE TABLE module_dependencies (
  module_id        VARCHAR(40) REFERENCES modules(module_id),
  depends_on       VARCHAR(40) REFERENCES modules(module_id),
  kind             VARCHAR(10) NOT NULL,          -- requires | enhances
  PRIMARY KEY (module_id, depends_on)
);
CREATE TABLE plans (
  plan_id          VARCHAR(40) PRIMARY KEY,       -- 'asc-full', 'surgery-standard', 'email-starter'
  name             NVARCHAR(120) NOT NULL,
  edition          VARCHAR(20) NULL,
  monthly_price_cents INT NOT NULL DEFAULT 0
);
CREATE TABLE plan_modules (                       -- edition bundles = plans
  plan_id VARCHAR(40) REFERENCES plans(plan_id), module_id VARCHAR(40) REFERENCES modules(module_id),
  PRIMARY KEY (plan_id, module_id)
);
CREATE TABLE practice_modules (                   -- current state, one row per practice × module
  practice_id      UNIQUEIDENTIFIER REFERENCES practices(practice_id),
  module_id        VARCHAR(40) REFERENCES modules(module_id),
  state            VARCHAR(10) NOT NULL,          -- off | trial | active | expired
  since            DATETIME2 NULL,
  via_module_id    VARCHAR(40) NULL,              -- started as a dependency of …
  PRIMARY KEY (practice_id, module_id)
);
CREATE TABLE trials (                             -- history: every trial, extension and outcome
  trial_id         UNIQUEIDENTIFIER PRIMARY KEY,
  practice_id      UNIQUEIDENTIFIER REFERENCES practices(practice_id),
  module_id        VARCHAR(40) REFERENCES modules(module_id),
  started_at       DATETIME2 NOT NULL, ends_at DATETIME2 NOT NULL,
  started_by       NVARCHAR(120) NOT NULL,
  outcome          VARCHAR(12) NULL,              -- converted | expired | cancelled
  outcome_at       DATETIME2 NULL
);
CREATE TABLE entitlement_audit (
  audit_id BIGINT IDENTITY PRIMARY KEY, practice_id UNIQUEIDENTIFIER NULL, module_id VARCHAR(40) NULL,
  action VARCHAR(40) NOT NULL, detail NVARCHAR(1000) NOT NULL, actor NVARCHAR(120) NOT NULL, at DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME()
);
-- a nightly job: UPDATE practice_modules SET state='expired' … WHERE state='trial' AND trial ends_at < now; insert audit rows.
```

Entitlements are checked **on the server** too: every module API route (`/api/m/scheduling/*`, …) rejects writes when `practice_modules.state` is not `trial|active` (reads allowed when `expired` and `expired_display = read-only`). The browser gating in this build is the UI half.

### A.6. Data layer and per-module tables

- New module data goes through `moduleStore(moduleId)` (`src/core/store.ts`), key `vityls:mod:<module>:<key>` inside the practice namespace (one namespace per practice: `vityls-surgery~`, `vityls-medical~`, `vityls-p-sierra~`; ASC runs un-namespaced as before). Email Intake uses it (`inbox`, `requests`); the outbox is `vityls:mod:core:outbox`.
- Existing keys keep their names (renaming would break the frozen Surgery v0.13 / Medical v1.0 test data). Each module declares its key prefixes in `modules.ts › storage`, and `moduleOfKey()` maps any key to its owner. The admin console's **Data map** lists every key of the open practice by owner with size — this is the starting map for Henry's tables:
  - Core tables: `patients`, `documents`, `users`, `providers`, `staff`, `audit`, `outbox`.
  - Per-module tables: `sched_visits`, `sched_reminders`, `sched_appt_notes`, `chart_problems`, `chart_meds`, `chart_vitals`, `chart_labs`, `chart_notes`, `chart_diagnoses`, `station_nurse`, `station_scribe`, `station_orders`, `forms_templates`, `forms_submissions`, `msg_messages`, `bill_quotes`, `bill_payments`, `bill_charges`, `packets_sent`, `photos`, `bodycharts`, `email_inbox`, `email_extractions`, `email_sched_requests`.
- Every table carries `practice_id`; module tables never reference each other directly except along a declared hard dependency, and reference Core ids (patient_id, document_id, user_id) freely.

### A.7. Editions = bundles

| Edition | Bundle (default `active`) | Terminology / templates |
|---|---|---|
| ASC.Vityls | all modules except email-intake (offered as an add-on) — runs the frozen ASC.Vityls app unchanged | ASC forms library, OR/PACU/anesthesia |
| Surgery.Vityls | scheduling, chart, stations-workflow, forms, messages, billing, records-packets, reports, photos-bodycharts, asc-perioperative (Send to ASC), portal-link | Surgeon, procedures, pre-op clearance packet |
| Medical.Vityls | Surgery bundle minus asc-perioperative | Doctor, Diagnosis & Plan, referral packet (`src/surgery/medical/terms.ts`) |
| MedSpa / Chiropractic (future) | pick modules + a terminology file + seed templates | — |

A practice's plan can always differ from its edition bundle: Sierra Vista Surgery Center is an ASC that starts with **AI Email Intake only** and is offered Scheduling, then Forms, as trials.

### A.8. How to add a new module

1. Add an entry to `MODULES` in `src/core/modules.ts` (id, name, description, pitch, Core services, `requires`, `enhances`, nav/routes/Practice panels/chart surfaces/Nightingale/station steps, storage prefix, trial days). Add its tabs to `TAB_MODULE`.
2. Put the code in `src/modules/<id>/`; store data only through `moduleStore('<id>')` and Core services (patients, documents, audit, outbox).
3. Register its page in the shell (`SurgeryApp.tsx`: a nav entry in `NAV_ALL` and a `{tab === '<route>' && <Page/>}` line). The shell's gate shows the teaser, trial banner or read-only state for free.
4. Make it useful alone: when a soft dependency is off, fall back to Core (e.g. `MinimalPatient`) instead of hiding the action.
5. Add it to the edition bundles that should include it, and to the SQL `modules`/`plan_modules` seed.
6. Tests: module only, with/without each soft dependency, trial → expiry → add to plan.

### A.9. The Patient Portal on Core

The Portal is a separate **app** on Core (patient-facing, its own login and Vityls patient ID), and `portal-link` is the practice-side **module** that connects a practice to it:
- Core holds the global patient identity and the consent/link table (`patient_practice_links`: patient_id, practice_id, scopes, granted/revoked).
- With `portal-link` on, the practice's forms, messages, check-in, bills and records packets are delivered to the Portal through that link; with it off, the practice uses the outbox (email/SMS links) only.
- The Portal's own paid features (wearables, trends, unlimited explanations) are entitlements of the **patient** account, modeled the same way (`patient_entitlements` with off/trial/active/expired). Anything a practice sends is never behind the patient's paywall.

### A.10. Known limits of this build

- Gating is at the surface level (nav, routes, Practice panels, chart tabs/cards, Nightingale chips, Portal link). Some deep links inside large legacy pages (e.g. Today's “Check-in” button) still exist; when the target module is off they land on its teaser instead of breaking.
- Station steps contributed by Forms are not removed one by one; the whole station workflow is the stations module.
- The patient photo next to the name is still shown when photos-bodycharts is off (only the Photos & charts tab is gated).
- ASC.Vityls stays one frozen app; modular ASC is shown in the office shell (Sierra Vista).

---

# Part B: backend additions (proposal for Henry)

## B1. Multi-tenancy
- **One tenant = one practice** (today `vityls:core:practices`: `coastline`, `bayview`, `harbor-asc`, `sierra`, all fictional). In the browser, tenants are separated by a localStorage **namespace prefix** (`vityls-surgery~`, `vityls-medical~`, `vityls-p-sierra~`; ASC has none). On the server this becomes a `tenant_id` column on **every** row (`core.tenants`, see `schema_proposed.sql`).
- **Recommended:** one shared Azure SQL database with `tenant_id` on every table, enforced by **row-level security** (a `sec.fn_tenant_predicate` on `SESSION_CONTEXT('tenant_id')`, which the API sets per request from the user's token). Composite indexes lead with `tenant_id`. A tenant can later move to its own database (an elastic pool) without changing the schema.
- The API **never** trusts a tenant id from the request body. It comes from the token or session only. Vityls internal staff (the admin console) use a separate role that can act across tenants, and every cross-tenant action is audited.
- In `schema_proposed.sql`, `core.users` is per tenant (`tenant_id` column, optional `entra_object_id`). If one person must work at several tenants (for example a surgeon at a partner ASC), either create one user row per tenant sharing the same `entra_object_id` (simplest), or add a membership link table. This decision is still open.

## B2. Patient identity vs practice records
- Today each edition keeps its own `patients` list (`medRepo.patients()`, ASC v7 `patients`). The same real person at two practices is two unrelated records.
- **Proposal: two layers.**
  - **`core.vityls_persons`** is a global identity: the Vityls patient ID, the patient's own login (for the future Portal), and verified demographics. No clinical data. It is created only when a patient claims a Portal account, or when a match is confirmed.
  - **`core.patients`** is the practice's own record, scoped by tenant: MRN, demographics as the practice recorded them, insurance and allergies, plus all the clinical module tables. It has an optional `person_id` pointing to `vityls_persons`.
- **Matching is never automatic for clinical data.** A suggested match (name, DOB, phone or email) is shown to staff or the patient, and a person confirms it. That fits the "Nightingale proposes, a human decides" rule.
- Hide and delete apply to the **practice** record (`is_hidden` with reason, by and at; permanent delete leaves a `patient_tombstones` row). They never touch the global identity.

## B3. Portal consent links
- `core.patient_practice_links` (person_id, tenant_id, patient_id, scopes, status, granted_at, revoked_at, granted_by) is created when the patient accepts a practice's invitation or link in the Portal.
- **Scopes** (proposal): `messages`, `forms`, `checkin`, `billing`, `records-receive`, `records-share` (the patient sends their own uploads to the practice), `reminders`.
- The practice can deliver to the Portal only while the link is active and the scope is granted. Otherwise it falls back to the outbox (email or SMS link), which is today's behaviour.
- The **HIPAA authorization** (records release to third parties) is a separate signed form (in the proposed schema it is a `core.form_records` row for the HIPAA form, plus `core.hipaa_revocations`; `m.records_packets.hipaa_code` and `hipaa_override_reason` hold the soft-check result; from Surgery v0.13). A Portal link is **not** a HIPAA authorization.
- Patient-side paid features would be `patient_entitlements` (off, trial, active, expired; **not in `schema_proposed.sql` yet**, add it with the Portal). Items a practice sends are **never** gated by them.

## B4. Module entitlements on the server
- `core.tenant_modules` (tenant_id, module_id, state, trial_start, trial_end, trial_days, via_module, trials_used) mirrors `Entitlement` in `src/core/practices.ts`. `core.module_dependencies` holds `requires` and `enhances`.
- **Every API route is tagged with its module.** A middleware checks the state before the handler runs: `off` or hidden returns 403 `module_not_enabled` (the UI shows the teaser); `expired` with `read-only` allows GET and returns 403 `module_read_only` on writes; `trial` and `active` allow everything.
- **Expiry is computed on the server** from `trial_end` against the server clock (the browser's simulated "+7 days" clock is a test feature only), saved once, and audited as `trial.expire`.
- Starting a trial runs as one transaction that also starts the missing hard dependencies (`via = module`). Switching a module off is refused when another enabled module requires it. Both mirror `startTrial` and `setState` in `practices.ts`.
- **Data is never deleted when a module expires.**

## B5. Recommended Azure stack

| Need | Azure service | Notes |
|---|---|---|
| Relational data | **Azure SQL Database** (General Purpose; elastic pool later) | TDE on by default; row-level security on tenant_id; automated backups and point-in-time restore; `schema_proposed.sql` is T-SQL |
| API | **Azure App Service** (Linux, Node/TypeScript, matching the app's language) | Better for a long-running API with connection pooling than Functions. Use **Azure Functions** for background jobs: reminder scheduler, trial expiry sweep, outbox sender, OCR and AI jobs. |
| Files (photos, documents, packet PDFs, email attachments) | **Azure Blob Storage**, private containers per environment | Paths `tenant/<id>/...`. The DB stores only `blob_objects` (path, sha256, size, mime). Downloads through short-lived SAS links issued by the API. Immutable storage for signed originals. |
| Staff sign-in | **Microsoft Entra ID** (workforce or External ID) | Practice users. Sign-in identifies the user; **the signature PIN stays a separate, server-checked secret** (rule: PIN at sign). |
| Patient sign-in (Portal) | **Entra External ID (successor to Azure AD B2C)** | Consumer accounts, MFA, social or email login |
| Secrets | **Azure Key Vault** + managed identities | No connection strings or keys in code or app settings. PIN hashes use a per-tenant pepper from Key Vault. |
| Async messaging | **Azure Service Bus** queues (or Storage Queues) | Fed by `core.outbox` (transactional outbox pattern) |
| Email and SMS | Azure Communication Services or another vendor | **BAA required before PHI**. Simulated until then. |
| Speech (ambient scribe) and AI (Nightingale) | Azure AI Speech, Azure OpenAI or another BAA-covered vendor | **Later, after a BAA**, with minimum necessary data. Everything is simulated today. |
| Monitoring | Application Insights + Log Analytics | Never log PHI in telemetry. Use ids only. |
| Network | Private endpoints for SQL, Blob and Key Vault; Front Door or App Gateway with WAF | — |

The Microsoft BAA covers many Azure services. Check the current in-scope list before using each one with PHI.

```mermaid
flowchart LR
  subgraph Clients
    T[Office tablets / browsers<br/>Surgery · Medical · ASC]
    P[Patient Portal app - planned]
    A[Vityls admin console]
  end
  T -->|Entra ID token| FD[Front Door + WAF]
  P -->|External ID token| FD
  A -->|Entra ID, Vityls staff role| FD
  FD --> API[App Service API<br/>tenant + module + role middleware<br/>PIN verify, audit]
  API --> SQL[(Azure SQL<br/>RLS by tenant_id)]
  API --> BLOB[(Blob Storage<br/>private, SAS links)]
  API --> KV[Key Vault]
  API --> OUT[core.outbox] --> SB[Service Bus]
  SB --> FN[Functions<br/>reminders · trial expiry · sender · OCR/AI]
  FN --> SQL
  FN --> BLOB
  FN -.after BAA.-> EXT[Email/SMS/Fax vendors<br/>Speech/AI vendors]
  API --> AI[App Insights]
```

## B6. The seam: swapping the browser stores for the API
The UI already reads and writes through a few functions. Replace their bodies with API calls (the details are in `04_API_Contract.md` §1):
- `src/v6/dataLayer.ts` → `repo` (EncounterRepository: forms, facts, audit, stations, signers)
- `src/med/record.ts` → `medRepo` (patients, problems, meds, vitals, labs, intake, care plans, caregivers, messages, visits, notes, RPM readings)
- `src/surgery/store.ts` → `svRead` / `svWrite` (about 59 `vityls:surgery:*` keys)
- `src/core/store.ts` → `moduleStore(module)`, the outbox
- `src/core/practices.ts` → tenants, entitlements, the core audit
- IndexedDB image stores (`vityls-surgery-images`, `vityls-medical-images`) → Blob Storage plus `blob_objects`

These functions are **synchronous** today, but the API is asynchronous. The practical path is a cache layer: load the tenant's working set at sign-in, write through to the API, and update the cache. The alternative is to convert the callers to async one module at a time. That decision belongs to Henry and Kevin.
