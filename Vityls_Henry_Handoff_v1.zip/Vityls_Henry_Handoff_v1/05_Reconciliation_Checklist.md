# 05 · Reconciliation checklist (Henry's ASC backend ↔ this proposal)

Henry's Azure SQL schema and API for ASC v7.5 were **not available** while this package was written. This checklist compares them against `schema_proposed.sql` and `04_API_Contract.md`. **Henry's working ASC backend wins wherever it already works.** Adapt the proposal to it, not the other way round.

Inputs: your ASC schema and API · `schema_proposed.sql` · `03_Data_Model.md` §5–6 (the real storage keys) · `source/reference_prior_ASC_handoff/` (the v7.4 handoff Kevin sent on 2026-10-04: 37 tables written in **PostgreSQL** syntax, plus a storage-key → table map and endpoint list. Your build is T-SQL, so treat it as a map, not as DDL).

## 1. Conventions (decide first)
- [ ] **Tenant column name:** `tenant_id` (proposal) vs `practice_id` (prior handoff and the Core arch doc §A.5). Pick one everywhere.
- [ ] **Primary keys:** `UNIQUEIDENTIFIER` + `NEWSEQUENTIALID()` (proposal) vs your choice (INT identity, or GUID from the app). Keep `legacy_id` columns for the browser ids (`MED-0001`, case ids, etc.).
- [ ] **Schemas:** `core` / `m` / `sec` (proposal) vs `dbo`. Naming: snake_case.
- [ ] **Timestamps:** `DATETIME2(3)`, UTC, server-set; `created_at/by`, `updated_at/by`, `row_version`.
- [ ] **Soft delete and hide:** `deleted_at/by/reason`, plus `is_hidden/hidden_*` for patients only; patient tombstones.
- [ ] **Audit:** one append-only `core.audit_log` (trigger blocks UPDATE and DELETE) vs per-table history. Keep the code's action names.
- [ ] **Row-level security** on `SESSION_CONTEXT('tenant_id')`, or tenant filtering in the API only. RLS is recommended as a second line of defence.
- [ ] **ORM/migrations:** whatever you use for ASC (see the options in `DATABASE_API_HANDOFF.md` in the repo).

## 2. Table-by-table (prior ASC handoff → proposal)
Tick each row once you know the **same / rename / merge / new** status.

| Prior ASC table (v7.4 handoff) | Proposed (`schema_proposed.sql`) | Check |
|---|---|---|
| practices | core.tenants (+ tenant settings) | [ ] name, settings columns (`expired`, `locked`, Practice access PIN hash) |
| users, roles, user_roles, providers | core.users (kind = staff/provider; role as a column) | [ ] does your ASC use a separate roles table? If so keep it and map |
| credential_applications, credential_status_history, credential_documents | *not in the proposal* | [ ] keep yours as is (ASC v7 credentialing) |
| invitations, invite_tokens | core.user_tokens (invites + PIN resets) | [ ] merge, or keep two tables |
| rooms, stations | core.rooms; stations are keys, not a table (`core.form_station_assignments`, `core.station_verifications`) | [ ] the office editions use 4 station keys (`patientPortal`, `frontOffice`, `nursing`, `surgeon`) |
| patients | core.patients (+ core.vityls_persons, core.patient_practice_links) | [ ] **key decision:** add the global identity layer now or with the Portal (`02` §B2) |
| cases, appointments | your ASC cases + m.visits (office) | [ ] one "encounter" table with a type column, or two. The data layer calls both `caseId` |
| station_verifications, case_events, case_facts | core.station_verifications, core.case_facts, audit | [ ] same semantics: facts upsert by `concept` |
| form_templates, form_template_versions, form_station_assignments, signer_configs, signer_slots, signer_initials_pages | core.form_templates / _versions / station assignments / signer configs | [ ] slots and initials pages: the proposal folds them into the config JSON. **Keep your normalized tables if built** |
| form_instances, form_values, form_value_history | core.form_records (values by stable field key) | [ ] **values by key, never by position**. Keep your EAV tables if built; `form_records` can be a view |
| signatures, addenda | core.signatures, core.addenda | [ ] server-set hash and time; PIN checked on the server |
| clearance_documents, clearance_summaries, clinical_alerts, clearance_reviews | core.documents + core.document_summaries; the clearance review/alert tables are *not in the proposal* | [ ] keep your ASC clearance tables; office documents reuse `core.documents` |
| fee_schedules, invoices, payments | m.fee_schedule_items, m.invoices, m.payments, m.payment_applications (+ m.quotes/quote_versions, m.charges) | [ ] the office adds versioned quotes and visit charges |
| audit_log | core.audit_log | [ ] merge into one |
| — | **new:** modules, module_dependencies, tenant_modules, trials, plans, plan_modules | [ ] entitlements are new for ASC; seed the ASC tenant with its full bundle `active` |
| — | **new:** core.blob_objects, patient_images, outbox, hipaa_revocations; m.records_packets, m.email_*, m.messages, m.reminder_* … | [ ] add when each module goes live |

## 3. API
- [ ] Line up your ASC routes with `04` §1–3. Keep yours where they exist. The routes marked **(code)** are what the front-end comments already expect.
- [ ] One auth model for staff (Entra ID); **signature PIN separate from login**, verified on the server, with lockout.
- [ ] Entitlement middleware (`02` §B4) in front of the module routes. For the ASC tenant everything is `active`, so nothing changes for ASC.
- [ ] Swap order at the seam (`02` §B6): `repo` (dataLayer) first. It is shared by ASC and the office stations, so your ASC work carries over directly. Then `medRepo` + `svRead/svWrite` (Surgery/Medical), then `moduleStore` + `practices.ts`, and IndexedDB images → Blob last.
- [ ] Sync vs async: decide between the cache layer and converting callers (`02` §B6).
- [ ] Run Kevin's smoke suites (`06`) against the API-backed build. The ASC sanity test must stay pixel-identical.

## 4. Legacy EMR migration (10,000+ records)
The source system, format and fields of the legacy records are **not documented in this package**. Ask Kevin before you design this. General plan:
1. **Inventory:** export format (CSV, HL7 v2, C-CDA, FHIR, or a vendor dump), record types (demographics, problems, meds, allergies, notes, documents/scans, appointments, billing), counts and date range.
2. **Load into staging** in a separate `stage` schema or database, never straight into the live tables. Keep the raw rows unchanged, with `source_system` and `source_id`.
3. **Map** to the proposed tables. Patients → `core.patients` with `legacy_id` = the source MRN. Scanned documents → Blob + `core.documents` (original unchanged, sha256). Notes → signed historical notes, read-only and marked `imported`, with no new signature. Allergies and meds → chart tables flagged "imported, needs review" (fits the confirm flow for allergies).
4. **Deduplicate** patients within a practice (name + DOB + phone/email), with a report for a person to review. No automatic merging of clinical data.
5. **Audit:** one `migration.import` audit event per batch and per record (batch id, source id). The importer runs as a named service account.
6. **Dry runs** on a copy, with row-count and checksum reconciliation reports (source vs target per table) and a spot check of sampled charts by Kevin's team.
7. **Cut-over:** freeze the legacy system, run a final delta, verify, switch over. Keep the legacy export archived (encrypted, Blob immutable storage) for the retention period.
8. **PHI rules:** migration only after the Azure BAA, in the production subscription, over private endpoints, with no PHI on developer laptops. Use fictional or synthetic data for development.

## 5. Done when
- [ ] Every key in `03` §5–6 has a table or column (or is marked UI-only).
- [ ] Every route in `04` exists or is mapped to one of yours.
- [ ] Kevin's smoke suites pass against the API-backed build.
- [ ] The open questions in `00` are answered.
