# 03 · Data model: inventory of every stored entity, and the proposed Azure SQL schema

Source of truth: the code at tag `core-modules-v1.0` (`source/Vityls_Core_Modules_v1.0_Source.zip`). Field shapes below come from the TypeScript. The verbatim definitions are in **`03a_Appendix_Type_Definitions.md`** and the proposed T-SQL is in **`schema_proposed.sql`**.

> **Reconcile this with Henry's existing ASC Azure SQL schema before you create anything** (see `05_Reconciliation_Checklist.md`). Where Henry's tables already work, they win. This model adds what the office editions (Surgery, Medical), Core and the modules need on top.

All seed data in the builds is fictional. There is no real patient data anywhere in this package.

## 1. How the browser stores data today

| Mechanism | Where | Notes |
|---|---|---|
| `localStorage` JSON values | every edition | One JSON blob per key. Most keys hold an **array of all rows** for the practice, for example `vityls:med:visits` holds every visit. |
| Per-practice namespace | `src/edition.ts › installNamespace()` | The office editions prefix every key: `vityls-surgery~` (Coastline / Surgery), `vityls-medical~` (Bayview / Medical), `vityls-p-sierra~` (Sierra Vista) and `vityls-med~` (old MED v0.1). **ASC runs without a namespace.** In SQL the namespace becomes `tenant_id`, which is the practice. |
| Vityls Core keys (no namespace) | `vityls:core:*` (`src/core/practices.ts`) | Practices and entitlements, the Core audit, the simulated clock and the active practice. |
| Module store | `vityls:mod:<module>:<key>` (`src/core/store.ts › moduleStore`) | Data for new-style modules: Email Intake `inbox` and `requests`, and the Core `outbox`. |
| IndexedDB `vityls-surgery-images` / `vityls-medical-images` | `src/surgery/v12/img.ts` | Object store `img`. The key is `<generation>\|<imageKey>` and the value is a data URL. It holds patient photos (`photo:<pid>`), ID and insurance card images, message attachments and stored packet PDFs. Fallback key: `vityls:surgery:img-fallback`. Moves to **Azure Blob Storage**. |
| IndexedDB `office-intelligence-local-test` v3 | `src/utils/localFormStudioDb.ts` (ASC form studio) | Stores `practices`, `forms`, `pdfTemplates` and `encounterDocuments`, indexed on practiceId and patientId. Blobs move to Blob Storage and metadata to SQL. |
| Browser timestamps, hashes, PIN hashes | everywhere | **For evaluation only.** The server must produce timestamps, content hashes (SHA-256 in place of the FNV `fingerprint()` in `dataLayer.ts`), PIN and password hashes, tokens, and invoice and receipt numbers. |

## 2. The data layers (where the swap happens)

1. **`src/v6/dataLayer.ts › repo: EncounterRepository`**, shared by every edition. It holds:
   - Form records per case or encounter (`FormRecord`: values, labels, provenance, signatures, addenda, status, lock hash).
   - Facts by concept (`Fact`).
   - The **audit log** (`AuditEntry`, append-only, about 150 action codes).
   - Station verifications, the acting user, and the Form Studio signer configuration.

   Keys: `vityls:v6:form:<caseId>:<file>`, `:forms:<caseId>`, `:facts:<caseId>`, `:audit:<caseId>`, `:stations:<caseId>`, `:actor`, `:signers:<file>`. The office editions use `caseId = patient:<pid>` or a visit id.
2. **`src/med/record.ts › medRepo: PatientRecordRepository`**, used by the office editions (Surgery, Medical) with the key prefix `vityls:med:`. It holds patients, problems, medications, vitals, labs, intake answers, care plans, caregivers (proxy access), portal messages, risk reviews, visits (appointments), visit notes and device readings. The same layer also covers `vityls:med:settings` (`src/med/settings.ts`) and the ASC network link `vityls:network:*` (`src/med/network.ts`).
3. **Surgery module stores** (`src/surgery/store.ts › svRead/svWrite`, prefix `vityls:surgery:`): about 60 keys, used by both Surgery and Medical (full table in §5). Staff use `vityls:surgery:staff` and `:staff-invites` (`src/surgery/staff.ts`).
4. **ASC v7 modules** (`src/v7/*.ts`, `src/components/*`): providers, accounts, invitations and outbox, fee schedules, invoices, clearance documents, form templates and workflow. These were **already mapped for ASC** in `source/reference_prior_ASC_handoff/ASC_Vityls_Database_Handoff.md` §1, written on 2026-10-04 for v7.4 and targeting PostgreSQL. Henry's Azure SQL work probably replaces that mapping. Reconcile with it rather than redoing it.

## 3. Core entities (always on)

| Entity | Today (key / type) | Key fields | Relationships | Editions |
|---|---|---|---|---|
| Practice (tenant) | `vityls:core:practices` → `Practice[]` | id, name, edition (ASC/SURGERY/MEDICAL), runtime, namespace, brand, locked (teaser/hidden), expired (read-only/hidden), frozen, modules{} | one practice has many of everything | all (Core build) |
| Module entitlement | `Practice.modules[moduleId]` → `Entitlement` | state off/trial/active/expired, trialStart, trialEnd, trialDays, via (started as a dependency of), since, trialsUsed | one per practice × module | all |
| Core audit | `vityls:core:audit` → `CoreAudit[]` (last 800 kept) | at, practiceId ('*' = global), by, action (trial.start, trial.expire, clock.advance, practice.open, …), module, detail | practice | all |
| Simulated clock | `vityls:core:clock-offset-days` (number) | test only | — | **test only, don't build it** |
| Practice profile | `vityls:surgery:profile` → `{address, phone, hoursStart, hoursEnd, rooms[]}`; `vityls:med:settings` (practiceName, fees, ascName, risk triggers …) | | practice | Surgery, Medical |
| Staff (users) | `vityls:surgery:staff` → `StaffMember[]` | id, name, role, credentials, pinHash, active, fails, locked, email, status invited/active, username, pwHash, invitedAt, activatedAt | practice; signs forms and notes | Surgery, Medical |
| Staff invitations | `vityls:surgery:staff-invites` → `StaffInvite[]` | token, staffId, to, role, link, subject, body, sentAt, expiresAt, usedAt, revokedAt, transport='simulated-outbox' | staff | Surgery, Medical |
| Providers | `vityls:v7:providers` (+ legacy `vityls:practice-providers:v1`) | see Appendix A, `src/v7/providers.ts` (credentials, NPI, status, PIN, lockout, applications) | practice | all |
| Provider admins | `vityls:surgery:provider-admins` → `string[]` | names of providers allowed to permanently delete patients | | Surgery, Medical |
| Coordinators | `vityls:surgery:coordinators` → `Record<patientId, staffName>` | | patient → staff | Surgery (surgical coordinator), Medical (care coordinator) |
| PIN reset | `vityls:surgery:pin-resets` → `ResetReq[]`; emails in `:pin-outbox` → `OutMail[]` | token, personKey, at, expiresAt (30 min), via self/admin, usedAt, revokedAt | staff or provider | Surgery, Medical |
| Patient (minimal identity + profile) | `vityls:med:patients` → `MedPatient & PatientProfile` | id, name, firstName, lastName, dob, sex, phone, altPhone, email, preferredContact, address/city/state/zip, language, allergies[], allergiesConfirmedAt/By, primaryProvider, careTeam[], emergencyContact, insurance, recordSharingConsent, fictional | one patient has many visits, documents, notes … | Surgery, Medical (ASC uses `patients` in v7 / Henry's schema) |
| Hidden patients | `vityls:surgery:hidden-patients` → `Record<pid, HiddenRec>` | reason, note, by, role, at | patient (soft hide) | Surgery, Medical |
| Deleted patients | `vityls:surgery:deleted-patients` → `DeletedRec[]` | pid, name, dob, reason, note, by, role, at, removed (row count) | tombstone | Surgery, Medical |
| ID and insurance cards | `vityls:surgery:patient-cards` → `Record<pid, PatientCards>`; images in IndexedDB | photoId{front, back}, insurance[{rank, carrier, memberId, group, front, back}]; each image is {at, by, via} | patient; image → blob | Surgery, Medical |
| Patient photo | IndexedDB key `photo:<pid>` | data URL, shrunk on upload | patient → blob | Surgery, Medical |
| Documents | `vityls:surgery:documents` → `DocRec[]` | id, patientId, type, title, source, docDate, receivedAt/By/Role, description, fileName, mime, size, dataUrl (→ blob), text, summary{text, facts[], engine, at, by}, removedAt (soft delete) … | patient; linked from messages, packets and Email Intake | Surgery, Medical (ASC: clearance docs) |
| Document types | `vityls:surgery:doc-types` → `string[]` | list the practice can edit | | Surgery, Medical |
| Audit (practice) | `vityls:v6:audit:<caseId>` → `AuditEntry[]` | id, at, caseId, user, role, action, form, detail | case, patient or visit | all |
| Outbox (simulated) | `vityls:mod:core:outbox` → `OutboxItem[]`; legacy: `vityls:v7:outbox`, `pin-outbox`, `records-outbox`, reminder sends | id, at, module, to, subject, body, by, attachments | | all |
| Network link (office ↔ ASC) | `vityls:network:thread:<caseId>`, `:docs:<caseId>`, `vityls:med:network-seed` | `NetworkCase`, `NetworkMessage`, `NetworkDocument` | office practice ↔ ASC practice | Surgery (Medical seeds none) |

## 4. Module entities

### scheduling (Today, Schedule, reminders)
| Entity | Today | Key fields | Notes |
|---|---|---|---|
| Visit / appointment | `vityls:med:visits` → `MedVisit` (plus `notes` text since v0.11, `SvVisit`) | id, patientId, date, time, durationMin, provider, room, visitType, reason, step (scheduled → check-in → rooming → provider → checkout → complete), problemIds, createdAt/By, recall | Double-booking is allowed: an overlap is flagged, not blocked. |
| Deleted visits | `vityls:surgery:deleted-visits` → `DeletedVisit[]` | visit snapshot, reason, note, by, role, at, session | |
| Visit types, colors and feature flags | `vityls:surgery:settings` → `SurgerySettings` | visitTypes[{id, name, color, durationMin, category, surgical, active}], modules{riskAwareness, networkAsc, blockTime, surgeryBooking, preopClearance, ambientScribe} | The `modules` flags predate Core entitlements. Keep them as practice settings. |
| Office events | `vityls:surgery:office-events` → `OfficeEvent[]` | title, kind, date, start, end, allDay, recur none/daily/weekly/monthly, until, notes | |
| Schedule resources | `vityls:surgery:sched-resources` → `SchedResource[]` | kind person/room, name, role, schedulable, custom | These are the schedule columns. |
| Confirmations | `vityls:surgery:appt-confirm` → `Record<visitId, ApptConfirm>` | status confirmed/reschedule, at, by, via | Cleared when the date, time or provider changes. |
| Reminder settings | `vityls:surgery:reminder-settings` → `ReminderSettings` | enabled, intervalHours (default 48), maxRequests (default 4), dayBefore, dayBeforeTime, quietStart, quietEnd | |
| Reminder sends | `vityls:surgery:reminder-sends` (plus `-archive` and `reminders-since`) → `ReminderSend[]` | visitId, patientId, kind confirm-request/day-before/manual, channels, to, message, attempt, transport simulated | |
| Intake lists | `vityls:surgery:intake-lists` → `{paymentTypes[], referralSources[]}` | | A Practice panel. |
| ASC block time | `vityls:surgery:block-seed` → `AscBlock[]`; `vityls:evaluation:block-time` | surgeon, date, start, end, room, ascName, source | Surgery only (asc-perioperative). |

### chart
| Entity | Today | Key fields |
|---|---|---|
| Problems | `vityls:med:problems` → `Problem` | description, conditionType, status active/resolved, onset, recordedAt/By, source, note |
| Medications | `vityls:med:meds` → `Medication` | name, dose, frequency, status, problemIds, source, startedAt, stoppedAt, simulatedRx |
| Vitals | `vityls:med:vitals` → `Vitals` | visitId, at, by, source, bpSys, bpDia, hr, rr, spo2, tempF, heightIn, weightLb, bmi |
| Labs | `vityls:med:labs` → `LabResult` | test, value, valueNum, unit, reportedRange, collectedAt, status awaiting-review/reviewed/released, reviewedBy/At, releasedAt/By, patientNote |
| Intake answers | `vityls:med:intake` → `Record<pid, IntakeAnswer[]>` | key (smoking, priorAnesthesiaProblems, …), value, detail, source |
| Care plans | `vityls:med:careplans` → `Record<pid, CarePlan>` | items, goals, status draft/signed, version, published snapshot |
| Risk reviews | `vityls:med:risk-reviews` → `RiskReview` | factorId, status reviewed/not-relevant, note, by, role, at (no score and no go/no-go) |
| Device readings | `vityls:med:rpm-readings` → `DeviceReading` | device, kind, value, unit, at |
| Visit notes | `vityls:med:notes` → `Record<visitId, VisitNote>` | template, SOAP fields, status, signedBy/At, contentHash, addenda[] |
| Diagnoses and procedures / plan | `vityls:surgery:patient-dx2` → `Record<pid, DxEntry[]>` (legacy single entry: `patient-dx`) | diagnosis, icd, primary, procedures[{name, status performed/planned, date, surgeon, asc}]. Medical labels this "Diagnosis & Plan". |
| Surgical history | `vityls:surgery:surgical-history` | text, year, detail, source |
| Contact notes | `vityls:surgery:contact-notes` → `ContactNote` | channel, direction, reason, text, author, session, contactAt, dictated, flagged, reviewed, signed{by, role, at, hash} |
| Living-summary initials | `vityls:surgery:summary-initials` | by, role, at, fingerprint (Nightingale cannot sign) |
| Kept Nightingale notes | `vityls:surgery:kept-notes` → `KeptNote` | question, text, cites[], keptBy, keptAt |
| Appointment notes | on the visit (`notes`); seeded once (`vityls-surgery-v11-apptnotes`) | |

### stations-workflow
| Entity | Today | Key fields |
|---|---|---|
| Nurse admission | `vityls:surgery:nurse` → `Record<visitId, NurseAdmission>` | chiefComplaint, pain, vitalsId, allergiesConfirmed, medsReviewed, anticoagulantLastDose, npo, escort, fallRisk, nurseNote |
| Ambient scribe session (simulated) | `vityls:surgery:scribe` → `Record<visitId, ScribeSession>` | status, lines[{speaker, text}], draft{hpi, exam, assessment, plan}, suggestions[{kind, status pending/initialed/dismissed}] |
| Checkout orders | `vityls:surgery:orders` → `CheckoutOrder` | kind surgery-booking/follow-up/clearance/other, status to-do/done/cancelled, source, result |
| Station verifications | `vityls:v6:stations:<caseId>` | station → {by, role, at} |
| Form records per visit | `vityls:v6:form:<caseId>:<file>` → `FormRecord` | see §2 |

### forms
| Entity | Today | Key fields |
|---|---|---|
| Form templates (office editor) | `vityls:surgery:form-lib` (versions `Ver{v, def: FormDef, at, by, note}`), `form-pins` | FormDef{title, intro, sections[{fields[{type, name, label, required, options, prefill, cond}]}]} |
| Form templates (HTML library / ASC) | `vityls-form-template:<file>`, `vityls-master-form-template:<file>`, `vityls-form-schema:<file>`, `vityls-form-revisions:<file>`, `vityls-master-form-history:<file>` | HTML or schema per file, plus versions |
| Workflow assignment | `vityls-form-workflow:<file>` | station → enabled. Surgery/Medical stations: patientPortal, frontOffice, nursing, surgeon (shown as "Doctor"). |
| Requirement | `vityls-form-requirement:<file>` | Required / As needed |
| My Forms | `vityls-my-forms:<practiceId>` (`default-practice`) | list of files |
| Signer config | `vityls:v6:signers:<file>` → `SignerConfig` | signers[{role, label, attestation, required, patient}], sequential, initials pages |
| Intake links | `vityls:surgery:intake-links` → `IntakeLink` | patientId, visitId, forms[], channel email/text, to, link, status queued-simulated |
| Forms packets (new patient) | `vityls:surgery:forms-packets` → `FormsPacket` | forms[], email, text, portal, message, link, transport simulated |
| HIPAA authorization | derived from signed form records plus `vityls:surgery:hipaa-revocations` | `HipaaAuth`{recipients, info, sensitive[], purposes, expiresOn/Event, status active/expired/revoked} |

### messages
| Entity | Today | Key fields |
|---|---|---|
| Portal messages | `vityls:med:messages` → `PortalMessage` | patientId, from patient/caregiver/office, author, text, at, read |
| Attachments | `vityls:surgery:msg-att` → `Att`; bytes in IndexedDB | msgId, name, mime, size, kind, filed{docId, type, at, by} (when filed to Documents) |
| Caregivers / proxy | `vityls:med:caregivers` → `Caregiver` | relationship, scope{results, plan, appointments, messages}, authorization, grantedAt, expiresOn, revokedAt |
| ASC-era portal store | `portal_msgs_<pid>`, `portal_*_<pid>` (`components/PatientPortalPage.tsx`, `utils/portalMessageStore.ts`) | ASC only, legacy |

### billing
| Entity | Today | Key fields |
|---|---|---|
| Quotes (versioned) | `vityls:surgery:quotes` → `Quote` | number, status Draft/Presented/Accepted/Declined/Expired, versions[{v, lines[{cat, label, qty, unit, code}], terms, financing, total, validUntil}], events[], invoiceId |
| Quote settings / catalog | `vityls:surgery:quote-settings` | validDays, terms, financing, catalog[] |
| Charges | `vityls:surgery:charges` → `Record<visitId, ChargeLine[]>` | feeId, label, code, qty, amount, station, invoiceId |
| Payments | `vityls:surgery:patient-payments` → `PatientPayment` | receipt, amount, method, card{brand, last4, exp}, reference, channel, applied[{invoiceId, amount}], status 'posted (simulated)' |
| Fee schedules / invoices | `vityls:v7:fee-schedules`, `vityls:v7:invoices` (`src/v7/billing.ts`) | shared with ASC |

### records-packets
| Entity | Today | Key fields |
|---|---|---|
| Records sent | `vityls:surgery:records-sent` → `SentRec` | title, preset preop/referral/consult/patient/custom, purpose, recipient{kind, name, org, method email/fax/portal/network, address}, items[], pages, size, coverLetter, hipaa{code, level, authKey, reason}, resendOf, pdfKey (→ blob) |
| Outside doctors | `vityls:surgery:outside-doctors` → `OutsideDoctor` | name, specialty, org, fax, email, phone (later: the NPI directory) |
| Outbox | `vityls:surgery:records-outbox` | simulated |

### photos-bodycharts
| Entity | Today | Key fields |
|---|---|---|
| Clinical photos | `vityls:surgery:photos` → `PhotoRec` | phase before/after, date, area, view, note, src (→ blob) |
| Body charts (versioned series) | `vityls:surgery:body-charts` → `BodyChartRec` | seriesId, version, diagram, strokes[], texts[] |

### asc-perioperative
- `vityls:surgery:asc-facilities` (`AscFacility`).
- `asc-packets` (`AscPacket`, with a `SchedulingForm`: procedure, CPT, diagnosis, ICD-10, laterality, anesthesia, duration, block, admission, equipment, implants, latex allergy).
- `booking-requests` (`BookingRequest`).

The ASC side itself (cases, OR, PACU, anesthesia, clearance) is Henry's ASC schema.

### email-intake (new in core-modules v1.0, simulated)
| Entity | Today | Key fields |
|---|---|---|
| Inbox email | `vityls:mod:email-intake:inbox` → `Email` | from, fromName, org, subject, body, receivedAt, attachments[], kind request/other, extraction (patient, DOB, contact, procedure, requested date, surgeon, referring office, insurance, urgency, each with a confidence), status new/accepted/replied/dismissed, patientId, matched, filedDocs[], requestId, visitId, reply{text, at, by, outboxId} |
| Scheduling request | `vityls:mod:email-intake:requests` → `SchedRequest` | emailId, patientId, procedure, requestedDate, surgeon, referring, status awaiting-scheduling/booked, visitId |

### reports, portal-link
Neither has storage of its own. Reports reads the other modules. Portal-link uses the caregiver, message and portal keys above.

## 5. Full `vityls:surgery:*` key list (generated from the code)

| Key (`vityls:surgery:` + …) | Stored type | Written in | Owner module |
|---|---|---|---|
| `appt-confirm` | `Record<string, ApptConfirm> / Record<string, unknown>` | surgery/apptDetail.tsx, surgery/reminders.tsx | scheduling |
| `asc-facilities` | `AscFacility[]` | surgery/asc.ts | asc-perioperative |
| `asc-packets` | `AscPacket[]` | surgery/asc.ts | asc-perioperative |
| `block-seed` | `AscBlock[]` | surgery/store.ts | asc-perioperative |
| `body-charts` | `BodyChartRec[]` | surgery/media.tsx | photos-bodycharts |
| `booking-requests` | `BookingRequest[]` | surgery/store.ts | asc-perioperative |
| `charges` | `Record<string, ChargeLine[]>` | surgery/charges.tsx | billing |
| `contact-notes` | `ContactNote[] / unknown[]` | surgery/contactNotes.tsx, surgery/documents.tsx | chart |
| `coordinators` | `Record<string, string>` | surgery/staff.ts, surgery/store.ts | core (users) |
| `deleted-patients` | `DeletedRec[]` | surgery/patientAdmin.tsx | core (patients) |
| `deleted-visits` | `DeletedVisit[]` | surgery/apptDetail.tsx | scheduling |
| `doc-types` | `string[]` | surgery/documents.tsx | core (documents) |
| `documents` | `DocRec[]` | surgery/documents.tsx | core (documents) |
| `form-lib` | `(JSON)` | surgery/v09/formLib.ts | forms |
| `form-pins` | `(JSON)` | surgery/v09/formLib.ts | forms |
| `forms-packets` | `FormsPacket[]` | surgery/newPatient.tsx | forms |
| `hidden-patients` | `Record<string, HiddenRec>` | surgery/patientAdmin.tsx | core (patients) |
| `hipaa-revocations` | `Revocation[]` | surgery/v13/hipaa.ts | forms / records-packets |
| `hipaa-seeded` | `boolean` | surgery/v13/hipaa.ts | seed flag |
| `hipaa-v013` | `boolean` | surgery/v13/hipaa.ts | seed flag |
| `img-fallback` | `Record<string, string>` | surgery/v12/img.ts | core (blob fallback) |
| `img-gen` | `string` | surgery/v12/img.ts | core (blob generation id) |
| `intake-links` | `IntakeLink[]` | surgery/store.ts | forms |
| `intake-lists` | `Partial<IntakeLists>` | surgery/profile.tsx | scheduling (Practice panel) |
| `kept-notes` | `KeptNote[]` | surgery/store.ts | chart (Nightingale) |
| `msg-att` | `Att[]` | surgery/v12/msgAtt.ts | messages |
| `nurse` | `Record<string, NurseAdmission>` | surgery/store.ts | stations-workflow |
| `office-events` | `OfficeEvent[]` | surgery/v09/schedData.ts | scheduling |
| `orders` | `CheckoutOrder[]` | surgery/store.ts | stations-workflow |
| `outside-doctors` | `OutsideDoctor[]` | surgery/v13/packet.ts | records-packets |
| `patient-cards` | `Record<string, PatientCards>` | surgery/v12/cards.ts | core (patients) |
| `patient-dx` | `Record<string, PatientDx>` | surgery/v10/dx.ts | chart (legacy v0.10) |
| `patient-dx2` | `Record<string, DxEntry[]>` | surgery/v10/dx.ts | chart |
| `patient-payments` | `PatientPayment[]` | surgery/payments.tsx | billing |
| `photos` | `PhotoRec[]` | surgery/media.tsx | photos-bodycharts |
| `pin-outbox` | `OutMail[]` | surgery/v12/pinReset.ts | core (users/PINs) |
| `pin-resets` | `ResetReq[]` | surgery/v12/pinReset.ts | core (users/PINs) |
| `profile` | `Profile` | surgery/SurgeryPractice.tsx | core (practice) |
| `provider-admins` | `string[]` | surgery/patientAdmin.tsx | core (users) |
| `quote-settings` | `Partial<QuoteSettings>` | surgery/quotes.tsx | billing |
| `quotes` | `Quote[]` | surgery/quotes.tsx | billing |
| `records-outbox` | `OutMail[]` | surgery/v13/packet.ts | records-packets |
| `records-sent` | `SentRec[]` | surgery/v13/packet.ts | records-packets |
| `reminder-sends` | `ReminderSend[]` | surgery/apptDetail.tsx, surgery/reminders.tsx | scheduling |
| `reminder-sends-archive` | `unknown[]` | surgery/apptDetail.tsx | scheduling |
| `reminder-settings` | `Partial<ReminderSettings>` | surgery/reminders.tsx | scheduling |
| `reminders-since` | `string / string \| null` | surgery/reminders.tsx | scheduling |
| `roles-v011` | `boolean` | surgery/v11/officeRoles.ts | migration flag |
| `sched-resources` | `SchedResource[] \| null` | surgery/v09/schedData.ts | scheduling |
| `schedule-columns` | `string[] \| null` | surgery/SurgerySchedule.tsx | scheduling (UI pref) |
| `schedule-view` | `string` | surgery/SurgerySchedule.tsx | scheduling (UI pref) |
| `scribe` | `Record<string, ScribeSession>` | surgery/store.ts | stations-workflow |
| `settings` | `Partial<SurgerySettings>` | surgery/store.ts | scheduling (visit types) + feature flags |
| `signers-v011` | `boolean` | surgery/v11/signers.ts | migration flag |
| `stations-v010` | `boolean` | surgery/v10/stations.ts | migration flag |
| `summary-initials` | `SummaryInitial[]` | surgery/store.ts | chart |
| `surgical-history` | `SurgicalHistoryItem[]` | surgery/store.ts | chart |
| `v06-seeded` | `boolean` | surgery/documents.tsx | seed flag |
| `v12-seeded` | `boolean` | surgery/v12/seed.ts | seed flag |

Seed, migration and UI-preference flags (`*-seeded`, `*-v010`, `*-v011`, `schedule-view`, `schedule-columns`, `img-gen`) don't need tables. UI preferences can go in a `user_preferences` JSON column.

**Known mismatch in the code:** the `storage` prefixes declared in `src/core/modules.ts` (which drive the admin console's *Data map*) include several names that no code writes: `vityls:surgery:doctor-notes`, `:diagnoses`, `:stations`, `:reminders`, `:msg-`, `:appt-notes`, `:blocks`, `:visittypes`, `:payments`, `:bodycharts`. The real keys are the ones in the table above (`patient-dx2`, `reminder-sends`, `msg-att`, `patient-payments`, `body-charts`, …). As a result, the Data map attributes some real keys to "core". Use **this table**, not the Data map, as the inventory. A small fix to `modules.ts` is still open.

## 6. Other keys (shared / ASC / legacy)

| Key | Owner | Notes |
|---|---|---|
| `vityls:practice-edition:<edition>-package`, `vityls:practice-edition:audit` | Core (edition setting) | becomes `practices.edition` plus audit |
| `vityls:evaluation:appointments`, `:date-cases`, `:selected-date`, `:block-time` | ASC schedule / test seed | ASC cases; Henry's schema |
| `vityls:seed-version`, `vityls-explicit-form-workflow-v3-clean`, `oi-premiere-official-html-library-v27-clean` | seed and migration flags | no table |
| `vityls:v7:accounts`, `:invite-tokens`, `:application-draft:*`, `:clearance-docs:*`, `:clearance-state:*`, `:dashboard-open-cards` | ASC v7 | see the prior ASC handoff §1 |
| `vityls:practice-users:v1`, `:access-records:v1`, `:medical-director-provider:v1`, `:station-config:v1`, `:document-library:v1`, `:station-data:*`, `:station-review:*`, `:case-form-draft:*`, `:case-form-status:*`, `:encounter-form:*`, `vityls-form-assignments-v2`, `schedule_weekly_notes_db`, `vityls:schedule-visible-rooms:*` | ASC components | see the prior ASC handoff §1 |
| `vityls:med:settings` (incl. risk triggers that ship empty and off) | Medical/Surgery practice settings | `practice_settings` JSON |
| `vityls-bare` (sessionStorage), `vityls:core:active`, `sv-today-day` | UI only | no table |

## 7. Proposed SQL schema: principles

See `schema_proposed.sql` (T-SQL for Azure SQL). It is **not yet executed against Azure SQL**. Run it in a scratch database first.

- **`tenant_id` (= practice) on every row**, including child tables, plus a **row-level security** predicate on `SESSION_CONTEXT(N'tenant_id')` that the API sets per request.
- **IDs:** `UNIQUEIDENTIFIER` with a default of `NEWSEQUENTIALID()`. Each table also has a `legacy_id NVARCHAR(100)` column to hold browser ids during import.
- **Audit:** one append-only `audit_log`. A trigger blocks UPDATE and DELETE, and timestamps come from the server (`SYSUTCDATETIME()`). Entitlement changes go to the same table under the actions `trial.*` and `module.*`.
- **Soft delete / hide:** clinical tables carry `hidden_at/by/reason` (patients) or `removed_at/by/reason` (documents, attachments). Permanent patient delete writes a `patient_tombstones` row and is restricted to the admin role in the API (admin PIN, a reason, and typing DELETE).
- **Versioned rows:** `form_templates` + `form_template_versions`, `quotes` + `quote_versions`, `body_charts` (series + version), `care_plans` (version + published snapshot), and signed notes with addenda. A signed or locked row is immutable; changes are addenda.
- **Documents and images are blob references:** `blob_objects(container, path, sha256, mime, size)`. `documents`, `patient_images`, `message_attachments`, `records_packets.pdf_blob_id` and `photos` point to them. No `dataUrl` columns.
- **Patient identity vs practice record:** `vityls_persons` (global, used by the Portal) and `patient_practice_links` (consent and scopes) sit beside `patients` (the practice chart, with an MRN per tenant). See `02_Architecture_Vityls_Core.md`.
- **JSON where the shape is still moving:** form values, provenance, scribe lines and extraction results use `NVARCHAR(MAX)` columns with `ISJSON` checks, so the schema doesn't block UI iteration.
