# Vityls: backend handoff for Henry (v1, 2026-10-14)

From Kevin (Office Intelligence, LLC). This package is for Henry and his Grok Bot assistant, to continue the **database and backend** work for Vityls.

## What Vityls is (30 seconds)
Vityls is the second generation of iMARS: a family of AI-assisted practice apps (**ASC**, **Surgery**, **Medical**, with the **Patient Portal** next) built as switchable **modules** on one platform, **Vityls Core**, and sold per module with free trials. **Nightingale** is the built-in AI assistant. It drafts, summarizes and flags; it never signs, orders or decides. Today every app is a browser-only test build with fictional data and simulated outside services. **Your backend replaces the browser storage behind a few data-layer functions.**

## Status
- **ASC.Vityls v7.5** is frozen (tag `v7.5`, sent 2026-10-05). You are finishing its Azure SQL backend.
- **Surgery.Vityls v0.13** and **Medical.Vityls v1.0** are complete as test builds.
- **Vityls Core + Modules v1.0** (tag `core-modules-v1.0`, 2026-10-14) puts all of them in one shell with 12 modules, entitlements and trials, an internal admin console, and the new AI Email Intake module. **This is the source to build on** (`source/Vityls_Core_Modules_v1.0_Source.zip`; it contains ASC v7.5 unchanged).
- Next on the front end: the Patient Portal (not started).

## Reading order
1. `00_START_HERE.md`: this file
2. `01_Vityls_Project_Overview.md`: company, products, and **Kevin's standing rules** (the backend must enforce them)
3. `02_Architecture_Vityls_Core.md`: Core + modules as built, plus the backend proposal (tenancy, identity, Portal links, entitlements, Azure stack, the data-layer seam)
4. `03_Data_Model.md`: every stored entity and key, generated from the code; `03a_Appendix_Type_Definitions.md`: the TypeScript types verbatim
5. `schema_proposed.sql`: T-SQL proposal, 86 tables (parses with sqlglot's T-SQL dialect; **not yet run against Azure SQL**)
6. `04_API_Contract.md`: routes per module, auth, roles, audit, and the seam map
7. `05_Reconciliation_Checklist.md`: how to line this up with your ASC schema and API, plus legacy EMR migration
8. `06_Builds_and_Versions.md`: tags, how to run, tests, rough edges, open items
9. `source/`: the Core source zip, the ASC v7.5 source zip, the architecture doc, all changelogs, and the prior ASC database handoff (v7.4, PostgreSQL syntax)

## Henry's next tasks
1. Finish and stabilize the **ASC v7.5 backend** on Azure SQL (the current work).
2. Reconcile your ASC schema and API with `schema_proposed.sql` and `04` using `05`. **Your working tables win.** Decide the conventions in `05` §1.
3. Add the **Core** tables: tenants, users with server-side PIN hashing and lockout, patients (and decide on the global identity layer), documents with Blob storage, append-only audit, outbox, modules and entitlements.
4. Put **entitlement and tenant middleware** in front of the API.
5. Replace the seam (`02` §B6) in this order: `repo` → `medRepo`/`svRead` → `moduleStore`/`practices` → images in Blob.
6. Plan the **legacy EMR migration** (10,000+ records) once Kevin supplies the export format (`05` §4).
7. Prepare BAAs (Azure and the messaging, speech and AI vendors) before any real data.

## Ground rules for this package
- **No secrets, no real patient data.** All names and seed data are fictional. `1234` (PIN) and `vityls-test-2026` (password) are test values from the code. `.env.example` has placeholders only.
- The docs describe the code as it is. Anything labelled **proposal** does not exist yet.

## Open questions for Kevin and Henry
- The "no automatic PDF at case close" rule versus the sealed PDF in the older `CASE_RECORD_ARCHITECTURE.md`.
- A global patient identity (`vityls_persons`) now, or with the Portal?
- Users across several tenants: one row per tenant, or a membership table?
- Sync cache layer versus async refactor at the seam.
- The legacy EMR source format.

## Ready-to-paste first prompt (for Henry's Grok Bot)
```
Read the attached Vityls handoff package (Vityls_Henry_Handoff_v1.zip), starting with
00_START_HERE.md and following its reading order through 06_Builds_and_Versions.md,
schema_proposed.sql and the source/ folder. Treat Kevin's standing rules in
01_Vityls_Project_Overview.md as requirements the backend must enforce (PIN at signing
checked on the server, Nightingale never signs or orders, append-only audit, soft
delete/hide, tenant isolation, module entitlements, simulations until BAAs are in place).

Then review my backend files, which I will attach next: my Azure SQL schema and API for ASC.Vityls
v7.5. Using 05_Reconciliation_Checklist.md:
1. Map each of my tables and routes to the proposal (same / rename / merge / new) and
   list any conflicts or gaps.
2. Tell me which conventions to fix first (tenant_id vs practice_id, key types, audit,
   soft delete) without breaking what already works for ASC.
3. Propose the next migration scripts (T-SQL) to add the Vityls Core tables and module
   entitlements, plus the API middleware for tenant and entitlement checks.
Keep my existing working ASC design wherever it works. Do not invent features
that are not in the handoff, and ask me when something is unclear.
```
