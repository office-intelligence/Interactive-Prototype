# 06 · Builds, versions, tests, open items

All builds come from **one git repository** (`vityls_final_build`, React 19 + Vite + TypeScript, with a small Express `server.ts` used only for dev hosting). Every build is a **test build**: fictional data, the browser's localStorage and IndexedDB, no backend, and every outbound action simulated.

## Apps and tags
| App | Git tag / branch | Edition switch | Test package (in Kevin's workspace) |
|---|---|---|---|
| ASC.Vityls v7.5 (**frozen**) | `v7.5` (2026-10-05). Earlier: `v6`, `v7`–`v7.4` | default (`VITE_EDITION` unset = ASC) | `ASC_Vityls_v7.5.zip`, `ASC_Vityls_v7.5_Source.zip` (**included here** in `source/`, the same source you already have) |
| MED.Vityls v0.1 (early internal-medicine prototype; superseded by Medical) | `med-v0.1`, branch `med` | `VITE_EDITION=MED` | — |
| Surgery.Vityls v0.13 | `surgery-v0.1` … `surgery-v0.13`, branch `surgery` | `VITE_EDITION=SURGERY` | `Surgery_Vityls_v0.13.zip` |
| Medical.Vityls v1.0 | `medical-v1.0`, branch `medical` | `VITE_EDITION=MEDICAL` | `Medical_Vityls_v1.0.zip` |
| **Vityls Core + Modules v1.0** (all of the above in one shell, plus the admin console) | **`core-modules-v1.0`** (commit `bea0f0b`), branch `core-modules` | `VITE_CORE=1 VITE_EDITION=SURGERY` | `Vityls_Core_Modules_v1.0.zip`, `Vityls_Core_Modules_v1.0_Source.zip` (**included** in `source/`) |

**Use the `core-modules-v1.0` source for backend work.** It contains ASC v7.5 unchanged (`src/v6`, `src/v7`), Surgery and Medical (`src/surgery`, `src/med`), Core (`src/core`) and the Email Intake module (`src/modules/email-intake`).

## How to run
```bash
npm install
npm run dev                     # tsx server.ts → dev server (ASC edition by default)
VITE_EDITION=SURGERY npm run dev   # or MEDICAL; VITE_CORE=1 for the combined Core shell
npm run lint                    # tsc --noEmit (needs a larger Node stack, e.g. NODE_OPTIONS=--stack-size=8000)
# Release packages: a single self-contained index.html that opens from file://
npm run build && node scripts/package-v7.mjs                                            # ASC
VITE_EDITION=SURGERY npx vite build --outDir dist-surgery && node scripts/package-surgery.mjs
VITE_EDITION=MEDICAL npx vite build --outDir dist-medical && node scripts/package-medical.mjs
VITE_CORE=1 VITE_EDITION=SURGERY npx vite build --outDir dist-core && node scripts/package-core.mjs
```
Test switches (Core build): `?practice=sierra|coastline|bayview|harbor-asc`, `?reset-test-data`, `?bare=1`, and `#vityls-admin` for the admin console. The test PIN for every fictional provider is **1234**; the test staff password is `vityls-test-2026` (test only; not a real secret). `.env.example` contains placeholders only (`GEMINI_API_KEY`, `APP_URL`). The remote AI call is switched off.

## Test suites and latest results
The suites are Python + Playwright headless scripts kept in Kevin's workspace, **not in the repo**. They run at 768×1024 and 1180×820.

| Suite | Against | Result |
|---|---|---|
| Surgery v13 smoke (v8–v12 regressions + packet/HIPAA) | Surgery v0.13 package | 739/739 PASS (2026-10-13, both sizes) |
| Surgery v13 smoke | Core build, Coastline, 1180 | 369/369 PASS (2026-10-14) |
| Medical med10 smoke | Core build, Bayview, 1180 | **369/370**. One fail: "one combined PDF … (12 pages)". The `12-lead ECG` item was missing from the combined packet PDF in that run. Not yet investigated. |
| Core modules (`modtest.py`, 44 checks: gating, trials, dependencies, expiry, read-only, admin console, Email Intake) | Core build | 44/44 PASS |
| ASC sanity (pixel-identical against v7.5 + key flows) | Core build, Harbor | 4/4 PASS |
| `tsc --noEmit` | repo | 39 type errors, all pre-existing outside `src/surgery` (as of v0.13) |

## Rough edges (from the changelogs)
- Body charts go into packets as text, not drawings. HEIC and Word files are listed but not embedded (PDF, PNG and JPEG are).
- The outside-doctor directory is seeded and can't be edited in the UI. Sensitive records (psych, SUD, HIV) are not auto-classified.
- After reordering a packet, the user must click "Redraft" on the cover letter.
- Re-saving a form from the editor drops its `.counsel` review banner.
- Core gating is at the surface level. Some deep links land on a teaser. The patient photo is still shown when photos-bodycharts is off. ASC remains one frozen app (modular ASC is shown via Sierra Vista).
- `modules.ts` `storage` prefixes include names that match no real key (`doctor-notes`, `diagnoses`, `stations`, `reminders`, `msg-`, `appt-notes`, `blocks`, `visittypes`, `payments`, `bodycharts`), so the admin **Data map** files some real keys under "core". **Use `03_Data_Model.md` §5 (generated from the code) as the true key map.**
- Images and attachments live in IndexedDB, and will be lost when the browser storage is cleared.

## Open items
1. **Backend:** Henry's Azure SQL backend for ASC v7.5 (in progress), then extending it to Core and the modules using `schema_proposed.sql` and `04`.
2. **Patient Portal:** the **next build** (Kevin: designed, not started). It needs `vityls_persons`, `patient_practice_links` and `patient_entitlements` on the server.
3. **Forms work is done** for this phase: the editor, versioning, station assignment, signer configuration, at-home links and the HIPAA authorization form.
4. **Counsel review:** the HIPAA release/authorization text (California wording) and the other legal text are drafts.
5. **BAAs** with hosting (Azure), email/SMS/fax, speech and AI vendors, plus the office–ASC BAA for Send to ASC, before any real data is used.
6. Server-side PIN hashing and lockout, trial expiry, entitlement enforcement and reminder scheduling (all client-side today).
7. **"No automatic PDF at case close":** confirm with Kevin. It conflicts with the sealed-PDF idea in the older `CASE_RECORD_ARCHITECTURE.md`.
8. Migrating the 10,000+ legacy EMR records (`05` §4).
9. Later: Doctor Finder (NPI registry), MedSpa and Chiropractic editions, payments processor, e-prescribing.
