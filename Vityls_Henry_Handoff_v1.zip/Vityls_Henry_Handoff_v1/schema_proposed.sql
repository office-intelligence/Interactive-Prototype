/* =====================================================================================================================
   Vityls Core + modules: PROPOSED Azure SQL (T-SQL) schema, handoff v1 (2026-10-14)
   Derived from the front-end code at tag core-modules-v1.0 (see 03_Data_Model.md and 03a_Appendix_Type_Definitions.md).

   STATUS: PROPOSAL. Not yet executed against Azure SQL. Reconcile it with Henry's existing ASC.Vityls Azure SQL
   schema (built from the v7.5 source) before use. Where Henry already has an ASC table (practices, users, providers,
   patients, cases, form templates/instances, signatures, audit, invoices ...), keep his and add only the missing
   columns and tables. See 05_Reconciliation_Checklist.md.

   Conventions
   - Every table has tenant_id (= practice), except the global catalog tables (modules, plans, vityls_persons).
   - IDs: UNIQUEIDENTIFIER DEFAULT NEWSEQUENTIALID(). legacy_id keeps the browser id during import.
   - Times: DATETIME2(3) in UTC, set by the server. Dates of service: DATE. Clock times: TIME(0).
   - PHI columns are marked  -- PHI  (use these for Always Encrypted, Dynamic Data Masking or Purview classification).
   - Blobs (documents, images, PDFs) live in Azure Blob Storage. SQL keeps only blob_objects references.
   - JSON columns: NVARCHAR(MAX) with ISJSON checks where the shape is still changing.
   ===================================================================================================================== */

CREATE SCHEMA core;
GO
CREATE SCHEMA m;   -- module tables
GO

/* ------------------------------------------------ Core: tenancy and catalog ----------------------------------------- */
CREATE TABLE core.modules (
  module_id            VARCHAR(40)    NOT NULL PRIMARY KEY,   -- email-intake, scheduling, chart, stations-workflow, forms, messages, billing, records-packets, reports, photos-bodycharts, asc-perioperative, portal-link
  name                 NVARCHAR(120)  NOT NULL,
  description          NVARCHAR(1000) NOT NULL,
  default_trial_days   INT            NOT NULL DEFAULT 14,
  price_hint           NVARCHAR(60)   NULL
);
CREATE TABLE core.module_dependencies (
  module_id            VARCHAR(40) NOT NULL REFERENCES core.modules(module_id),
  depends_on           VARCHAR(40) NOT NULL REFERENCES core.modules(module_id),
  kind                 VARCHAR(10) NOT NULL CHECK (kind IN ('requires','enhances')),
  PRIMARY KEY (module_id, depends_on)
);
CREATE TABLE core.plans (
  plan_id              VARCHAR(40)   NOT NULL PRIMARY KEY,     -- asc-full, surgery-standard, medical-standard, email-starter
  name                 NVARCHAR(120) NOT NULL,
  edition              VARCHAR(20)   NULL,
  monthly_price_cents  INT           NOT NULL DEFAULT 0
);
CREATE TABLE core.plan_modules (
  plan_id   VARCHAR(40) NOT NULL REFERENCES core.plans(plan_id),
  module_id VARCHAR(40) NOT NULL REFERENCES core.modules(module_id),
  PRIMARY KEY (plan_id, module_id)
);
CREATE TABLE core.tenants (                                       -- a practice or surgery center (Practice in src/core/practices.ts)
  tenant_id            UNIQUEIDENTIFIER NOT NULL DEFAULT NEWSEQUENTIALID() PRIMARY KEY,
  legacy_id            NVARCHAR(100)  NULL,                       -- 'coastline', 'bayview', 'harbor-asc', 'sierra'
  name                 NVARCHAR(200)  NOT NULL,
  edition              VARCHAR(20)    NOT NULL CHECK (edition IN ('ASC','SURGERY','MEDICAL','MEDSPA','CHIRO')),
  plan_id              VARCHAR(40)    NULL REFERENCES core.plans(plan_id),
  locked_display       VARCHAR(10)    NOT NULL DEFAULT 'teaser'    CHECK (locked_display IN ('teaser','hidden')),
  expired_display      VARCHAR(10)    NOT NULL DEFAULT 'read-only' CHECK (expired_display IN ('read-only','hidden')),
  address              NVARCHAR(400)  NULL, phone NVARCHAR(40) NULL,
  hours_start          TIME(0) NULL, hours_end TIME(0) NULL,
  settings_json        NVARCHAR(MAX)  NULL CHECK (settings_json IS NULL OR ISJSON(settings_json) = 1),   -- vityls:med:settings, vityls:surgery:settings (visit types have their own table)
  created_at           DATETIME2(3)   NOT NULL DEFAULT SYSUTCDATETIME()
);
CREATE TABLE core.tenant_modules (                                -- Entitlement: one row per tenant x module
  tenant_id            UNIQUEIDENTIFIER NOT NULL REFERENCES core.tenants(tenant_id),
  module_id            VARCHAR(40)      NOT NULL REFERENCES core.modules(module_id),
  state                VARCHAR(10)      NOT NULL CHECK (state IN ('off','trial','active','expired')),
  trial_start          DATETIME2(3) NULL, trial_end DATETIME2(3) NULL, trial_days INT NULL,
  via_module_id        VARCHAR(40)  NULL REFERENCES core.modules(module_id),   -- started as a dependency of this module
  since                DATETIME2(3) NULL,
  trials_used          INT NOT NULL DEFAULT 0,
  PRIMARY KEY (tenant_id, module_id)
);
CREATE TABLE core.trials (                                        -- history of every trial, extension and outcome
  trial_id             UNIQUEIDENTIFIER NOT NULL DEFAULT NEWSEQUENTIALID() PRIMARY KEY,
  tenant_id            UNIQUEIDENTIFIER NOT NULL REFERENCES core.tenants(tenant_id),
  module_id            VARCHAR(40)      NOT NULL REFERENCES core.modules(module_id),
  started_at           DATETIME2(3) NOT NULL, ends_at DATETIME2(3) NOT NULL,
  started_by           NVARCHAR(120) NOT NULL,
  outcome              VARCHAR(12) NULL CHECK (outcome IN ('converted','expired','cancelled','extended')),
  outcome_at           DATETIME2(3) NULL
);
CREATE TABLE core.rooms (
  room_id UNIQUEIDENTIFIER NOT NULL DEFAULT NEWSEQUENTIALID() PRIMARY KEY,
  tenant_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.tenants(tenant_id),
  name NVARCHAR(80) NOT NULL, active BIT NOT NULL DEFAULT 1
);

/* ------------------------------------------------ Core: people, roles, PINs ----------------------------------------- */
CREATE TABLE core.users (                                         -- staff and providers (StaffMember, v7 Provider)
  user_id              UNIQUEIDENTIFIER NOT NULL DEFAULT NEWSEQUENTIALID() PRIMARY KEY,
  tenant_id            UNIQUEIDENTIFIER NOT NULL REFERENCES core.tenants(tenant_id),
  legacy_id            NVARCHAR(100) NULL,
  entra_object_id      UNIQUEIDENTIFIER NULL,                     -- Entra ID / External ID subject
  kind                 VARCHAR(10)   NOT NULL CHECK (kind IN ('staff','provider')),
  display_name         NVARCHAR(160) NOT NULL,
  role                 NVARCHAR(60)  NOT NULL,                    -- Medical assistant, Nurse, Front desk, Practice Manager, Practice Administrator, Surgeon, Physician ...
  credentials          NVARCHAR(40)  NULL,
  npi                  CHAR(10)      NULL,
  email                NVARCHAR(254) NULL,
  username             NVARCHAR(80)  NULL,
  status               VARCHAR(12)   NOT NULL DEFAULT 'invited' CHECK (status IN ('invited','active','deactivated')),
  is_admin             BIT           NOT NULL DEFAULT 0,          -- provider-admins (may permanently delete patients)
  pin_hash             VARBINARY(64) NULL,                        -- server-side hash only (Argon2/PBKDF2); never sent to the browser
  pin_failures         INT           NOT NULL DEFAULT 0,
  locked_at            DATETIME2(3)  NULL,
  invited_at DATETIME2(3) NULL, activated_at DATETIME2(3) NULL,
  provider_details_json NVARCHAR(MAX) NULL CHECK (provider_details_json IS NULL OR ISJSON(provider_details_json) = 1) -- license, DEA, specialty (v7 providers)
);
CREATE TABLE core.user_tokens (                                   -- staff invites (StaffInvite) and PIN resets (ResetReq); PIN resets expire after 30 min
  token_hash           VARBINARY(32) NOT NULL PRIMARY KEY,
  tenant_id            UNIQUEIDENTIFIER NOT NULL REFERENCES core.tenants(tenant_id),
  user_id              UNIQUEIDENTIFIER NOT NULL REFERENCES core.users(user_id),
  purpose              VARCHAR(12) NOT NULL CHECK (purpose IN ('invite','pin-reset')),
  via                  VARCHAR(10) NULL CHECK (via IN ('self','admin')),
  created_by           UNIQUEIDENTIFIER NULL, created_at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME(),
  expires_at           DATETIME2(3) NOT NULL, used_at DATETIME2(3) NULL, revoked_at DATETIME2(3) NULL
);

/* ------------------------------------------------ Core: patients and identity --------------------------------------- */
CREATE TABLE core.vityls_persons (                                -- global patient identity (Portal account); NOT tenant-scoped
  person_id            UNIQUEIDENTIFIER NOT NULL DEFAULT NEWSEQUENTIALID() PRIMARY KEY,
  external_identity_id NVARCHAR(200) NULL,                        -- Entra External ID (B2C) subject
  first_name NVARCHAR(100) NOT NULL, last_name NVARCHAR(100) NOT NULL,  -- PHI
  dob DATE NOT NULL,                                              -- PHI
  email NVARCHAR(254) NULL, phone NVARCHAR(40) NULL,              -- PHI
  verified_at DATETIME2(3) NULL,
  created_at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME()
);
CREATE TABLE core.patients (                                      -- the practice's chart (MedPatient & PatientProfile)
  patient_id           UNIQUEIDENTIFIER NOT NULL DEFAULT NEWSEQUENTIALID() PRIMARY KEY,
  tenant_id            UNIQUEIDENTIFIER NOT NULL REFERENCES core.tenants(tenant_id),
  legacy_id            NVARCHAR(100) NULL,                        -- browser id or legacy EMR id
  mrn                  NVARCHAR(40)  NULL,
  first_name NVARCHAR(100) NOT NULL, last_name NVARCHAR(100) NOT NULL,   -- PHI
  dob DATE NOT NULL,                                                     -- PHI
  sex VARCHAR(10) NULL, language NVARCHAR(40) NULL,
  phone NVARCHAR(40) NULL, alt_phone NVARCHAR(40) NULL, email NVARCHAR(254) NULL,          -- PHI
  preferred_contact VARCHAR(12) NULL CHECK (preferred_contact IN ('text','email','text+email','phone')),
  address NVARCHAR(200) NULL, city NVARCHAR(80) NULL, state CHAR(2) NULL, zip VARCHAR(10) NULL, -- PHI
  emergency_contact NVARCHAR(300) NULL,                                                   -- PHI
  insurance_summary NVARCHAR(300) NULL,                                                   -- PHI
  primary_provider_id UNIQUEIDENTIFIER NULL REFERENCES core.users(user_id),
  coordinator_user_id UNIQUEIDENTIFIER NULL REFERENCES core.users(user_id),               -- vityls:surgery:coordinators
  allergies_confirmed_at DATETIME2(3) NULL, allergies_confirmed_by UNIQUEIDENTIFIER NULL,
  profile_json NVARCHAR(MAX) NULL CHECK (profile_json IS NULL OR ISJSON(profile_json) = 1), -- payment type, referral source, care team
  photo_blob_id UNIQUEIDENTIFIER NULL,
  hidden_at DATETIME2(3) NULL, hidden_by UNIQUEIDENTIFIER NULL, hidden_reason NVARCHAR(200) NULL, hidden_note NVARCHAR(1000) NULL,
  created_at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME(), created_by UNIQUEIDENTIFIER NULL
);
CREATE UNIQUE INDEX uq_patients_mrn ON core.patients (tenant_id, mrn) WHERE mrn IS NOT NULL;
CREATE TABLE core.patient_tombstones (                            -- permanent delete (DeletedRec): admin PIN, a reason, and typing DELETE
  tombstone_id UNIQUEIDENTIFIER NOT NULL DEFAULT NEWSEQUENTIALID() PRIMARY KEY,
  tenant_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.tenants(tenant_id),
  former_patient_id UNIQUEIDENTIFIER NOT NULL,
  display_label NVARCHAR(200) NOT NULL,                           -- minimal PHI (name/DOB); review retention with counsel
  reason NVARCHAR(200) NOT NULL, note NVARCHAR(1000) NULL,
  deleted_by UNIQUEIDENTIFIER NOT NULL, deleted_at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME(),
  rows_removed INT NOT NULL
);
CREATE TABLE core.patient_practice_links (                        -- Portal consent link: person <-> practice chart
  link_id UNIQUEIDENTIFIER NOT NULL DEFAULT NEWSEQUENTIALID() PRIMARY KEY,
  person_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.vityls_persons(person_id),
  tenant_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.tenants(tenant_id),
  patient_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.patients(patient_id),
  verified_via VARCHAR(20) NOT NULL CHECK (verified_via IN ('invite-code','dob-phone-code','staff')),
  scopes_to_practice NVARCHAR(MAX) NOT NULL CHECK (ISJSON(scopes_to_practice) = 1),   -- e.g. ["documents","meds","allergies","wearables"]
  scopes_from_practice NVARCHAR(MAX) NOT NULL CHECK (ISJSON(scopes_from_practice) = 1),
  granted_at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME(), revoked_at DATETIME2(3) NULL,
  CONSTRAINT uq_link UNIQUE (person_id, tenant_id)
);
CREATE TABLE core.caregivers (                                    -- proxy access (Caregiver)
  caregiver_id UNIQUEIDENTIFIER NOT NULL DEFAULT NEWSEQUENTIALID() PRIMARY KEY,
  tenant_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.tenants(tenant_id),
  patient_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.patients(patient_id),
  name NVARCHAR(160) NOT NULL, relationship NVARCHAR(60) NOT NULL, email NVARCHAR(254) NULL,
  scope_results BIT NOT NULL, scope_plan BIT NOT NULL, scope_appointments BIT NOT NULL, scope_messages BIT NOT NULL,
  granted_by UNIQUEIDENTIFIER NOT NULL, granted_via VARCHAR(10) NOT NULL, authorization_text NVARCHAR(1000) NOT NULL,
  granted_at DATETIME2(3) NOT NULL, expires_on DATE NULL, revoked_at DATETIME2(3) NULL, revoked_by UNIQUEIDENTIFIER NULL
);

/* ------------------------------------------------ Core: blobs, documents, audit, outbox ----------------------------- */
CREATE TABLE core.blob_objects (
  blob_id UNIQUEIDENTIFIER NOT NULL DEFAULT NEWSEQUENTIALID() PRIMARY KEY,
  tenant_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.tenants(tenant_id),
  container NVARCHAR(63) NOT NULL, path NVARCHAR(1024) NOT NULL,
  mime NVARCHAR(100) NOT NULL, size_bytes BIGINT NOT NULL, sha256 BINARY(32) NOT NULL,
  created_by UNIQUEIDENTIFIER NULL, created_at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME()
);
ALTER TABLE core.patients ADD CONSTRAINT fk_patient_photo FOREIGN KEY (photo_blob_id) REFERENCES core.blob_objects(blob_id);
CREATE TABLE core.patient_images (                                -- ID and insurance cards (PatientCards)
  image_id UNIQUEIDENTIFIER NOT NULL DEFAULT NEWSEQUENTIALID() PRIMARY KEY,
  tenant_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.tenants(tenant_id),
  patient_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.patients(patient_id),
  slot VARCHAR(20) NOT NULL CHECK (slot IN ('photo-id','insurance-primary','insurance-secondary')),
  side VARCHAR(5) NOT NULL CHECK (side IN ('front','back')),
  carrier NVARCHAR(120) NULL, member_id NVARCHAR(60) NULL, group_no NVARCHAR(60) NULL,      -- PHI
  blob_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.blob_objects(blob_id),
  captured_via NVARCHAR(40) NOT NULL,                              -- portal, registration form, or front desk
  captured_by UNIQUEIDENTIFIER NULL, captured_at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME(),
  removed_at DATETIME2(3) NULL
);
CREATE TABLE core.document_types (
  tenant_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.tenants(tenant_id),
  name NVARCHAR(80) NOT NULL, sort_order INT NOT NULL DEFAULT 0, PRIMARY KEY (tenant_id, name)
);
CREATE TABLE core.documents (                                     -- DocRec
  document_id UNIQUEIDENTIFIER NOT NULL DEFAULT NEWSEQUENTIALID() PRIMARY KEY,
  tenant_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.tenants(tenant_id),
  patient_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.patients(patient_id),
  legacy_id NVARCHAR(100) NULL,
  doc_type NVARCHAR(80) NOT NULL, title NVARCHAR(300) NOT NULL, source NVARCHAR(200) NOT NULL,
  doc_date DATE NULL, description NVARCHAR(1000) NULL,
  blob_id UNIQUEIDENTIFIER NULL REFERENCES core.blob_objects(blob_id),
  extracted_text NVARCHAR(MAX) NULL,                               -- PHI (OCR/text)
  origin_module VARCHAR(40) NULL REFERENCES core.modules(module_id), -- email-intake, messages, forms ...
  origin_ref UNIQUEIDENTIFIER NULL,                                -- e.g. message attachment id or email id
  received_at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME(), received_by UNIQUEIDENTIFIER NULL,
  removed_at DATETIME2(3) NULL, removed_by UNIQUEIDENTIFIER NULL, removed_reason NVARCHAR(200) NULL
);
CREATE TABLE core.document_summaries (                            -- Nightingale summary (DocSummary); always labelled as AI
  summary_id UNIQUEIDENTIFIER NOT NULL DEFAULT NEWSEQUENTIALID() PRIMARY KEY,
  tenant_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.tenants(tenant_id),
  document_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.documents(document_id),
  engine NVARCHAR(60) NOT NULL, model_version NVARCHAR(60) NULL,
  summary_text NVARCHAR(MAX) NOT NULL, facts_json NVARCHAR(MAX) NULL CHECK (facts_json IS NULL OR ISJSON(facts_json) = 1),
  created_at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME()
);
CREATE TABLE core.audit_log (                                     -- AuditEntry + CoreAudit; append-only
  audit_id BIGINT IDENTITY(1,1) NOT NULL PRIMARY KEY,
  tenant_id UNIQUEIDENTIFIER NULL REFERENCES core.tenants(tenant_id), -- NULL = Vityls-wide (clock, catalog)
  at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME(),
  user_id UNIQUEIDENTIFIER NULL, actor_label NVARCHAR(160) NOT NULL, role NVARCHAR(60) NULL,
  action VARCHAR(60) NOT NULL,                                     -- form.sign, visit.checkin, patient.hide, trial.expire ...
  module_id VARCHAR(40) NULL, case_ref NVARCHAR(100) NULL,         -- caseId, 'patient:<id>' or visit id
  patient_id UNIQUEIDENTIFIER NULL, form_file NVARCHAR(200) NULL,
  detail NVARCHAR(4000) NOT NULL, session_id NVARCHAR(100) NULL, ip VARCHAR(45) NULL
);
GO
CREATE TRIGGER core.trg_audit_append_only ON core.audit_log INSTEAD OF UPDATE, DELETE AS
BEGIN
  THROW 51000, 'audit_log is append-only', 1;
END;
GO
CREATE TABLE core.outbox (                                        -- every outbound email/SMS/fax (simulated until BAA vendors are in place)
  outbox_id UNIQUEIDENTIFIER NOT NULL DEFAULT NEWSEQUENTIALID() PRIMARY KEY,
  tenant_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.tenants(tenant_id),
  module_id VARCHAR(40) NULL REFERENCES core.modules(module_id),
  kind VARCHAR(30) NOT NULL,                                       -- reminder, pin-reset, staff-invite, records, intake-link, email-reply ...
  channel VARCHAR(10) NOT NULL CHECK (channel IN ('email','sms','fax','portal','network')),
  to_address NVARCHAR(300) NOT NULL, to_name NVARCHAR(160) NULL,   -- PHI
  subject NVARCHAR(300) NULL, body NVARCHAR(MAX) NOT NULL,         -- PHI: minimum necessary
  attachment_blob_ids NVARCHAR(MAX) NULL CHECK (attachment_blob_ids IS NULL OR ISJSON(attachment_blob_ids) = 1),
  patient_id UNIQUEIDENTIFIER NULL, created_by UNIQUEIDENTIFIER NULL,
  created_at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME(),
  status VARCHAR(12) NOT NULL DEFAULT 'simulated' CHECK (status IN ('simulated','queued','sent','failed')),
  provider_message_id NVARCHAR(200) NULL, sent_at DATETIME2(3) NULL
);
GO

/* ------------------------------------------------ Encounter data layer (src/v6/dataLayer.ts) ------------------------ */
CREATE TABLE core.form_templates (                                -- HTML library + office FormDef editor
  template_id UNIQUEIDENTIFIER NOT NULL DEFAULT NEWSEQUENTIALID() PRIMARY KEY,
  tenant_id UNIQUEIDENTIFIER NULL REFERENCES core.tenants(tenant_id),  -- NULL = Vityls master library
  file_key NVARCHAR(200) NOT NULL,                                 -- the form's file name in the library
  title NVARCHAR(300) NOT NULL, kind VARCHAR(10) NOT NULL CHECK (kind IN ('html','formdef','pdf')),
  requirement VARCHAR(12) NULL CHECK (requirement IN ('Required','As needed')),
  in_my_forms BIT NOT NULL DEFAULT 0,
  current_version INT NOT NULL DEFAULT 1,
  status VARCHAR(12) NOT NULL DEFAULT 'Active' CHECK (status IN ('Draft','Active','Superseded','Retired'))
);
CREATE TABLE core.form_template_versions (
  template_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.form_templates(template_id),
  version INT NOT NULL,
  definition NVARCHAR(MAX) NOT NULL,                               -- HTML or FormDef JSON
  note NVARCHAR(500) NULL, created_by UNIQUEIDENTIFIER NULL, created_at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME(),
  PRIMARY KEY (template_id, version)
);
CREATE TABLE core.form_station_assignments (                      -- vityls-form-workflow:<file>
  tenant_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.tenants(tenant_id),
  template_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.form_templates(template_id),
  station_key VARCHAR(30) NOT NULL,                               -- patientPortal, frontOffice, nursing, surgeon (shown as "Doctor"); ASC: anesthesia, orTeam, pacu ...
  enabled BIT NOT NULL, PRIMARY KEY (tenant_id, template_id, station_key)
);
CREATE TABLE core.signer_configs (                                -- SignerConfig
  tenant_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.tenants(tenant_id),
  template_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.form_templates(template_id),
  signers_json NVARCHAR(MAX) NOT NULL CHECK (ISJSON(signers_json) = 1),
  initials_json NVARCHAR(MAX) NULL CHECK (initials_json IS NULL OR ISJSON(initials_json) = 1),
  sequential BIT NOT NULL, updated_by UNIQUEIDENTIFIER NULL, updated_at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME(),
  PRIMARY KEY (tenant_id, template_id)
);
CREATE TABLE core.form_records (                                  -- FormRecord (one per case/visit x form)
  form_record_id UNIQUEIDENTIFIER NOT NULL DEFAULT NEWSEQUENTIALID() PRIMARY KEY,
  tenant_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.tenants(tenant_id),
  case_ref NVARCHAR(100) NOT NULL,                                 -- visit id, ASC case id, or 'patient:<id>'
  patient_id UNIQUEIDENTIFIER NULL REFERENCES core.patients(patient_id),
  template_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.form_templates(template_id),
  template_version INT NOT NULL,
  status VARCHAR(20) NOT NULL CHECK (status IN ('not-started','draft','partially-signed','locked')),
  values_json NVARCHAR(MAX) NOT NULL CHECK (ISJSON(values_json) = 1),       -- PHI, by stable field key
  labels_json NVARCHAR(MAX) NULL, provenance_json NVARCHAR(MAX) NULL,
  locked_at DATETIME2(3) NULL, locked_sha256 BINARY(32) NULL, rendition_blob_id UNIQUEIDENTIFIER NULL REFERENCES core.blob_objects(blob_id),
  updated_at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME(), updated_by UNIQUEIDENTIFIER NULL,
  CONSTRAINT uq_form_record UNIQUE (tenant_id, case_ref, template_id)
);
CREATE TABLE core.signatures (                                    -- SignatureEvent (PIN-at-sign; hash and time come from the server)
  signature_id UNIQUEIDENTIFIER NOT NULL DEFAULT NEWSEQUENTIALID() PRIMARY KEY,
  tenant_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.tenants(tenant_id),
  form_record_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.form_records(form_record_id),
  slot_id NVARCHAR(60) NOT NULL, role NVARCHAR(60) NOT NULL,
  signer_user_id UNIQUEIDENTIFIER NULL, signer_name NVARCHAR(160) NOT NULL, credentials NVARCHAR(40) NULL,  -- patient signers have no user_id
  attestation NVARCHAR(1000) NOT NULL, method VARCHAR(6) NOT NULL CHECK (method IN ('drawn','typed')),
  image_blob_id UNIQUEIDENTIFIER NULL REFERENCES core.blob_objects(blob_id),
  content_sha256 BINARY(32) NOT NULL, initials_json NVARCHAR(MAX) NULL,
  signed_at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME()
);
CREATE TABLE core.addenda (
  addendum_id UNIQUEIDENTIFIER NOT NULL DEFAULT NEWSEQUENTIALID() PRIMARY KEY,
  tenant_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.tenants(tenant_id),
  form_record_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.form_records(form_record_id),
  by_user_id UNIQUEIDENTIFIER NOT NULL, role NVARCHAR(60) NOT NULL, reason NVARCHAR(500) NOT NULL,
  changes_json NVARCHAR(MAX) NOT NULL CHECK (ISJSON(changes_json) = 1), note NVARCHAR(2000) NULL, signed BIT NOT NULL,
  at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME()
);
CREATE TABLE core.case_facts (                                    -- Fact (carried forward by concept)
  tenant_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.tenants(tenant_id),
  case_ref NVARCHAR(100) NOT NULL, concept NVARCHAR(200) NOT NULL,
  value NVARCHAR(4000) NOT NULL, source_json NVARCHAR(MAX) NOT NULL CHECK (ISJSON(source_json) = 1),
  updated_at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME(), PRIMARY KEY (tenant_id, case_ref, concept)
);
CREATE TABLE core.station_verifications (
  tenant_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.tenants(tenant_id),
  case_ref NVARCHAR(100) NOT NULL, station NVARCHAR(40) NOT NULL,
  by_user_id UNIQUEIDENTIFIER NOT NULL, role NVARCHAR(60) NOT NULL, at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME(),
  PRIMARY KEY (tenant_id, case_ref, station)
);
CREATE TABLE core.hipaa_revocations (
  tenant_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.tenants(tenant_id),
  form_record_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.form_records(form_record_id),
  revoked_at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME(), revoked_by UNIQUEIDENTIFIER NOT NULL, role NVARCHAR(60) NOT NULL, note NVARCHAR(1000) NULL,
  PRIMARY KEY (tenant_id, form_record_id)
);
CREATE TABLE core.user_preferences (                              -- UI-only keys: schedule view and columns, open cards
  user_id UNIQUEIDENTIFIER NOT NULL PRIMARY KEY REFERENCES core.users(user_id),
  tenant_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.tenants(tenant_id),
  prefs_json NVARCHAR(MAX) NOT NULL CHECK (ISJSON(prefs_json) = 1)
);

/* ================================================ MODULE TABLES (schema m) ========================================= */

/* ---- scheduling ---- */
CREATE TABLE m.visit_types (
  visit_type_id UNIQUEIDENTIFIER NOT NULL DEFAULT NEWSEQUENTIALID() PRIMARY KEY,
  tenant_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.tenants(tenant_id), legacy_id NVARCHAR(60) NULL,
  name NVARCHAR(80) NOT NULL, color CHAR(7) NOT NULL, duration_min INT NOT NULL,
  category VARCHAR(12) NOT NULL CHECK (category IN ('new','follow-up','pre-op','post-op','clearance','procedure','other')),
  surgical BIT NOT NULL DEFAULT 0, active BIT NOT NULL DEFAULT 1
);
CREATE TABLE m.sched_resources (
  resource_id UNIQUEIDENTIFIER NOT NULL DEFAULT NEWSEQUENTIALID() PRIMARY KEY,
  tenant_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.tenants(tenant_id),
  kind VARCHAR(6) NOT NULL CHECK (kind IN ('person','room')), name NVARCHAR(120) NOT NULL, role NVARCHAR(60) NULL,
  user_id UNIQUEIDENTIFIER NULL REFERENCES core.users(user_id), room_id UNIQUEIDENTIFIER NULL REFERENCES core.rooms(room_id),
  schedulable BIT NOT NULL DEFAULT 1, sort_order INT NOT NULL DEFAULT 0
);
CREATE TABLE m.visits (                                           -- MedVisit / SvVisit (double-booking allowed)
  visit_id UNIQUEIDENTIFIER NOT NULL DEFAULT NEWSEQUENTIALID() PRIMARY KEY,
  tenant_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.tenants(tenant_id), legacy_id NVARCHAR(100) NULL,
  patient_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.patients(patient_id),
  provider_user_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.users(user_id),
  visit_type_id UNIQUEIDENTIFIER NULL REFERENCES m.visit_types(visit_type_id),
  room_id UNIQUEIDENTIFIER NULL REFERENCES core.rooms(room_id),
  service_date DATE NOT NULL, start_time TIME(0) NOT NULL, duration_min INT NOT NULL,
  reason NVARCHAR(500) NULL,                                       -- PHI
  appointment_notes NVARCHAR(2000) NULL,                           -- PHI
  step VARCHAR(10) NOT NULL DEFAULT 'scheduled' CHECK (step IN ('scheduled','check-in','rooming','provider','checkout','complete')),
  arrived_at DATETIME2(3) NULL, checked_in_at DATETIME2(3) NULL,
  recall_json NVARCHAR(MAX) NULL,
  source_module VARCHAR(40) NULL,                                  -- e.g. email-intake
  created_at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME(), created_by UNIQUEIDENTIFIER NULL,
  deleted_at DATETIME2(3) NULL, deleted_by UNIQUEIDENTIFIER NULL, deleted_reason NVARCHAR(200) NULL, deleted_note NVARCHAR(1000) NULL
);
CREATE INDEX ix_visits_day ON m.visits (tenant_id, service_date, provider_user_id) WHERE deleted_at IS NULL;
CREATE TABLE m.office_events (
  event_id UNIQUEIDENTIFIER NOT NULL DEFAULT NEWSEQUENTIALID() PRIMARY KEY,
  tenant_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.tenants(tenant_id),
  title NVARCHAR(200) NOT NULL, kind NVARCHAR(40) NOT NULL, event_date DATE NOT NULL,
  start_time TIME(0) NULL, end_time TIME(0) NULL, all_day BIT NOT NULL,
  recur VARCHAR(8) NOT NULL CHECK (recur IN ('none','daily','weekly','monthly')), until_date DATE NULL, notes NVARCHAR(1000) NULL,
  created_by UNIQUEIDENTIFIER NOT NULL, created_at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME()
);
CREATE TABLE m.appointment_confirmations (
  visit_id UNIQUEIDENTIFIER NOT NULL PRIMARY KEY REFERENCES m.visits(visit_id),
  tenant_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.tenants(tenant_id),
  status VARCHAR(12) NOT NULL CHECK (status IN ('confirmed','reschedule')),
  via VARCHAR(14) NOT NULL CHECK (via IN ('patient-reply','portal','staff-call','staff')),
  by_label NVARCHAR(160) NOT NULL, at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME()
);
CREATE TABLE m.reminder_settings (
  tenant_id UNIQUEIDENTIFIER NOT NULL PRIMARY KEY REFERENCES core.tenants(tenant_id),
  enabled BIT NOT NULL DEFAULT 1, interval_hours INT NOT NULL DEFAULT 48, max_requests INT NOT NULL DEFAULT 4,
  day_before BIT NOT NULL DEFAULT 1, day_before_time TIME(0) NULL, quiet_start TINYINT NULL, quiet_end TINYINT NULL
);
CREATE TABLE m.reminder_sends (
  send_id UNIQUEIDENTIFIER NOT NULL DEFAULT NEWSEQUENTIALID() PRIMARY KEY,
  tenant_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.tenants(tenant_id),
  visit_id UNIQUEIDENTIFIER NOT NULL REFERENCES m.visits(visit_id),
  kind VARCHAR(16) NOT NULL CHECK (kind IN ('confirm-request','day-before','manual')),
  attempt INT NOT NULL, outbox_id UNIQUEIDENTIFIER NULL REFERENCES core.outbox(outbox_id),
  cancelled_at DATETIME2(3) NULL, at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME()
);
CREATE TABLE m.intake_lists (
  tenant_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.tenants(tenant_id),
  list VARCHAR(20) NOT NULL CHECK (list IN ('payment-type','referral-source')), value NVARCHAR(120) NOT NULL,
  PRIMARY KEY (tenant_id, list, value)
);

/* ---- chart ---- */
CREATE TABLE m.problems (
  problem_id UNIQUEIDENTIFIER NOT NULL DEFAULT NEWSEQUENTIALID() PRIMARY KEY,
  tenant_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.tenants(tenant_id),
  patient_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.patients(patient_id),
  description NVARCHAR(300) NOT NULL, condition_type VARCHAR(20) NOT NULL, status VARCHAR(10) NOT NULL CHECK (status IN ('active','resolved')),
  onset NVARCHAR(40) NULL, source NVARCHAR(120) NOT NULL, note NVARCHAR(1000) NULL,
  recorded_by UNIQUEIDENTIFIER NULL, recorded_at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME()
);
CREATE TABLE m.medications (
  medication_id UNIQUEIDENTIFIER NOT NULL DEFAULT NEWSEQUENTIALID() PRIMARY KEY,
  tenant_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.tenants(tenant_id),
  patient_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.patients(patient_id),
  name NVARCHAR(200) NOT NULL, dose NVARCHAR(80) NULL, frequency NVARCHAR(80) NULL,
  status VARCHAR(8) NOT NULL CHECK (status IN ('active','stopped')), source NVARCHAR(120) NOT NULL,
  started_at DATE NULL, stopped_at DATE NULL, simulated_rx BIT NOT NULL DEFAULT 0,
  recorded_by UNIQUEIDENTIFIER NULL, recorded_at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME()
);
CREATE TABLE m.allergies (                                        -- MedPatient.allergies[] as rows
  allergy_id UNIQUEIDENTIFIER NOT NULL DEFAULT NEWSEQUENTIALID() PRIMARY KEY,
  tenant_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.tenants(tenant_id),
  patient_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.patients(patient_id),
  substance NVARCHAR(200) NOT NULL, reaction NVARCHAR(300) NULL, source NVARCHAR(120) NULL,
  recorded_at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME(), removed_at DATETIME2(3) NULL
);
CREATE TABLE m.vitals (
  vitals_id UNIQUEIDENTIFIER NOT NULL DEFAULT NEWSEQUENTIALID() PRIMARY KEY,
  tenant_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.tenants(tenant_id),
  patient_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.patients(patient_id),
  visit_id UNIQUEIDENTIFIER NULL REFERENCES m.visits(visit_id),
  at DATETIME2(3) NOT NULL, by_user_id UNIQUEIDENTIFIER NULL, source VARCHAR(16) NOT NULL,
  bp_sys SMALLINT NULL, bp_dia SMALLINT NULL, hr SMALLINT NULL, rr SMALLINT NULL, spo2 TINYINT NULL,
  temp_f DECIMAL(4,1) NULL, height_in DECIMAL(5,1) NULL, weight_lb DECIMAL(6,1) NULL, bmi DECIMAL(4,1) NULL
);
CREATE TABLE m.lab_results (
  lab_id UNIQUEIDENTIFIER NOT NULL DEFAULT NEWSEQUENTIALID() PRIMARY KEY,
  tenant_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.tenants(tenant_id),
  patient_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.patients(patient_id),
  visit_id UNIQUEIDENTIFIER NULL REFERENCES m.visits(visit_id),
  test NVARCHAR(120) NOT NULL, value NVARCHAR(120) NOT NULL, value_num DECIMAL(12,4) NULL, unit NVARCHAR(30) NULL,
  reported_range NVARCHAR(60) NULL, collected_at DATETIME2(3) NOT NULL, source NVARCHAR(120) NOT NULL,
  document_id UNIQUEIDENTIFIER NULL REFERENCES core.documents(document_id),
  status VARCHAR(16) NOT NULL CHECK (status IN ('awaiting-review','reviewed','released')),
  reviewed_by UNIQUEIDENTIFIER NULL, reviewed_at DATETIME2(3) NULL, review_note NVARCHAR(1000) NULL,
  released_by UNIQUEIDENTIFIER NULL, released_at DATETIME2(3) NULL, patient_note NVARCHAR(1000) NULL,
  entered_by UNIQUEIDENTIFIER NULL, entered_at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME()
);
CREATE TABLE m.intake_answers (
  tenant_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.tenants(tenant_id),
  patient_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.patients(patient_id),
  answer_key VARCHAR(40) NOT NULL, value NVARCHAR(200) NOT NULL, detail NVARCHAR(1000) NULL, source NVARCHAR(120) NOT NULL,
  recorded_at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME(), PRIMARY KEY (tenant_id, patient_id, answer_key)
);
CREATE TABLE m.visit_notes (                                      -- VisitNote (+ addenda); scribe drafts land here once kept
  visit_id UNIQUEIDENTIFIER NOT NULL PRIMARY KEY REFERENCES m.visits(visit_id),
  tenant_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.tenants(tenant_id),
  template NVARCHAR(60) NOT NULL, subjective NVARCHAR(MAX) NULL, objective NVARCHAR(MAX) NULL,
  assessment NVARCHAR(MAX) NULL, plan_text NVARCHAR(MAX) NULL,
  status VARCHAR(6) NOT NULL CHECK (status IN ('draft','signed')),
  signed_by UNIQUEIDENTIFIER NULL, signed_at DATETIME2(3) NULL, content_sha256 BINARY(32) NULL,
  updated_by UNIQUEIDENTIFIER NULL, updated_at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME()
);
CREATE TABLE m.visit_note_addenda (
  addendum_id UNIQUEIDENTIFIER NOT NULL DEFAULT NEWSEQUENTIALID() PRIMARY KEY,
  tenant_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.tenants(tenant_id),
  visit_id UNIQUEIDENTIFIER NOT NULL REFERENCES m.visit_notes(visit_id),
  by_user_id UNIQUEIDENTIFIER NOT NULL, text NVARCHAR(MAX) NOT NULL, at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME()
);
CREATE TABLE m.diagnoses (                                        -- DxEntry (Surgery: Diagnosis & Procedure; Medical: Diagnosis & Plan)
  diagnosis_id UNIQUEIDENTIFIER NOT NULL DEFAULT NEWSEQUENTIALID() PRIMARY KEY,
  tenant_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.tenants(tenant_id),
  patient_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.patients(patient_id),
  visit_id UNIQUEIDENTIFIER NULL REFERENCES m.visits(visit_id),
  diagnosis NVARCHAR(300) NOT NULL, icd10 VARCHAR(10) NULL, is_primary BIT NOT NULL DEFAULT 0,
  suggested_by_ai BIT NOT NULL DEFAULT 0, accepted_by UNIQUEIDENTIFIER NULL, accepted_at DATETIME2(3) NULL,
  removed_at DATETIME2(3) NULL
);
CREATE TABLE m.diagnosis_procedures (                             -- DxProc (Medical: treatments, orders, referrals)
  procedure_id UNIQUEIDENTIFIER NOT NULL DEFAULT NEWSEQUENTIALID() PRIMARY KEY,
  tenant_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.tenants(tenant_id),
  diagnosis_id UNIQUEIDENTIFIER NOT NULL REFERENCES m.diagnoses(diagnosis_id),
  name NVARCHAR(300) NOT NULL, cpt VARCHAR(10) NULL, status VARCHAR(10) NOT NULL CHECK (status IN ('performed','planned')),
  proc_date DATE NULL, surgeon_user_id UNIQUEIDENTIFIER NULL, asc_name NVARCHAR(160) NULL
);
CREATE TABLE m.surgical_history (
  item_id UNIQUEIDENTIFIER NOT NULL DEFAULT NEWSEQUENTIALID() PRIMARY KEY,
  tenant_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.tenants(tenant_id),
  patient_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.patients(patient_id),
  text NVARCHAR(300) NOT NULL, year_text VARCHAR(10) NULL, detail NVARCHAR(1000) NULL, source NVARCHAR(120) NOT NULL,
  recorded_at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME()
);
CREATE TABLE m.contact_notes (
  note_id UNIQUEIDENTIFIER NOT NULL DEFAULT NEWSEQUENTIALID() PRIMARY KEY,
  tenant_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.tenants(tenant_id),
  patient_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.patients(patient_id),
  channel NVARCHAR(30) NOT NULL, direction VARCHAR(8) NOT NULL CHECK (direction IN ('Incoming','Outgoing')),
  reason NVARCHAR(120) NOT NULL, text NVARCHAR(MAX) NOT NULL, author_user_id UNIQUEIDENTIFIER NOT NULL,
  contact_at DATETIME2(3) NOT NULL, dictated BIT NOT NULL, flagged BIT NOT NULL,
  reviewed_by UNIQUEIDENTIFIER NULL, reviewed_at DATETIME2(3) NULL,
  signed_by UNIQUEIDENTIFIER NULL, signed_at DATETIME2(3) NULL, signed_sha256 BINARY(32) NULL,
  created_at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME()
);
CREATE TABLE m.care_plans (
  tenant_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.tenants(tenant_id),
  patient_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.patients(patient_id),
  version INT NOT NULL, status VARCHAR(6) NOT NULL CHECK (status IN ('draft','signed')),
  items_json NVARCHAR(MAX) NOT NULL CHECK (ISJSON(items_json) = 1), goals_json NVARCHAR(MAX) NOT NULL CHECK (ISJSON(goals_json) = 1),
  signed_by UNIQUEIDENTIFIER NULL, signed_at DATETIME2(3) NULL, updated_at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME(),
  PRIMARY KEY (tenant_id, patient_id, version)
);
CREATE TABLE m.risk_reviews (                                     -- no scores and no go/no-go: review status only
  tenant_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.tenants(tenant_id),
  patient_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.patients(patient_id),
  factor_id NVARCHAR(60) NOT NULL, status VARCHAR(14) NOT NULL CHECK (status IN ('reviewed','not-relevant')),
  note NVARCHAR(1000) NULL, by_user_id UNIQUEIDENTIFIER NOT NULL, role NVARCHAR(60) NOT NULL, at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME(),
  PRIMARY KEY (tenant_id, patient_id, factor_id)
);
CREATE TABLE m.device_readings (
  reading_id UNIQUEIDENTIFIER NOT NULL DEFAULT NEWSEQUENTIALID() PRIMARY KEY,
  tenant_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.tenants(tenant_id),
  patient_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.patients(patient_id),
  device NVARCHAR(80) NOT NULL, kind NVARCHAR(40) NOT NULL, value DECIMAL(12,4) NOT NULL, unit NVARCHAR(20) NOT NULL, at DATETIME2(3) NOT NULL
);
CREATE TABLE m.summary_attestations (                             -- living-summary initials (Nightingale cannot sign)
  tenant_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.tenants(tenant_id),
  patient_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.patients(patient_id),
  by_user_id UNIQUEIDENTIFIER NOT NULL, role NVARCHAR(60) NOT NULL, summary_sha256 BINARY(32) NOT NULL,
  at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME(), PRIMARY KEY (tenant_id, patient_id, at)
);
CREATE TABLE m.kept_ai_notes (
  kept_id UNIQUEIDENTIFIER NOT NULL DEFAULT NEWSEQUENTIALID() PRIMARY KEY,
  tenant_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.tenants(tenant_id),
  patient_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.patients(patient_id),
  question NVARCHAR(1000) NOT NULL, answer NVARCHAR(MAX) NOT NULL, cites_json NVARCHAR(MAX) NOT NULL CHECK (ISJSON(cites_json) = 1),
  kept_by UNIQUEIDENTIFIER NOT NULL, kept_at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME()
);

/* ---- stations-workflow ---- */
CREATE TABLE m.nurse_admissions (
  visit_id UNIQUEIDENTIFIER NOT NULL PRIMARY KEY REFERENCES m.visits(visit_id),
  tenant_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.tenants(tenant_id),
  chief_complaint NVARCHAR(1000) NULL, pain NVARCHAR(60) NULL, vitals_id UNIQUEIDENTIFIER NULL REFERENCES m.vitals(vitals_id),
  allergies_confirmed BIT NOT NULL, meds_reviewed BIT NOT NULL, anticoagulant_last_dose NVARCHAR(120) NULL,
  npo NVARCHAR(120) NULL, escort NVARCHAR(120) NULL, fall_risk NVARCHAR(60) NULL, nurse_note NVARCHAR(MAX) NULL,
  by_user_id UNIQUEIDENTIFIER NOT NULL, at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME()
);
CREATE TABLE m.scribe_sessions (                                  -- simulated today; real audio only with a BAA vendor
  visit_id UNIQUEIDENTIFIER NOT NULL PRIMARY KEY REFERENCES m.visits(visit_id),
  tenant_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.tenants(tenant_id),
  status VARCHAR(10) NOT NULL CHECK (status IN ('idle','listening','paused','stopped')),
  transcript_json NVARCHAR(MAX) NULL, draft_json NVARCHAR(MAX) NULL, suggestions_json NVARCHAR(MAX) NULL,
  started_by UNIQUEIDENTIFIER NULL, started_at DATETIME2(3) NULL, stopped_at DATETIME2(3) NULL, note_created_at DATETIME2(3) NULL
);
CREATE TABLE m.checkout_orders (
  order_id UNIQUEIDENTIFIER NOT NULL DEFAULT NEWSEQUENTIALID() PRIMARY KEY,
  tenant_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.tenants(tenant_id),
  visit_id UNIQUEIDENTIFIER NOT NULL REFERENCES m.visits(visit_id),
  patient_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.patients(patient_id),
  kind VARCHAR(16) NOT NULL CHECK (kind IN ('surgery-booking','follow-up','clearance','other')),
  text NVARCHAR(500) NOT NULL, detail NVARCHAR(2000) NULL, source NVARCHAR(120) NOT NULL,
  status VARCHAR(10) NOT NULL CHECK (status IN ('to-do','done','cancelled')), result NVARCHAR(500) NULL,
  created_by UNIQUEIDENTIFIER NOT NULL, created_at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME(),
  done_by UNIQUEIDENTIFIER NULL, done_at DATETIME2(3) NULL
);

/* ---- forms ---- */
CREATE TABLE m.form_send_packets (                                -- IntakeLink + FormsPacket (single-use, expiring links)
  packet_id UNIQUEIDENTIFIER NOT NULL DEFAULT NEWSEQUENTIALID() PRIMARY KEY,
  tenant_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.tenants(tenant_id),
  patient_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.patients(patient_id),
  visit_id UNIQUEIDENTIFIER NULL REFERENCES m.visits(visit_id),
  forms_json NVARCHAR(MAX) NOT NULL CHECK (ISJSON(forms_json) = 1),
  channels_json NVARCHAR(MAX) NOT NULL CHECK (ISJSON(channels_json) = 1),   -- email / text / portal
  token_hash VARBINARY(32) NOT NULL, expires_at DATETIME2(3) NOT NULL, used_at DATETIME2(3) NULL,
  message NVARCHAR(2000) NULL, outbox_id UNIQUEIDENTIFIER NULL REFERENCES core.outbox(outbox_id),
  created_by UNIQUEIDENTIFIER NOT NULL, created_at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME()
);

/* ---- messages ---- */
CREATE TABLE m.messages (                                         -- PortalMessage + staff replies
  message_id UNIQUEIDENTIFIER NOT NULL DEFAULT NEWSEQUENTIALID() PRIMARY KEY,
  tenant_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.tenants(tenant_id),
  patient_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.patients(patient_id),
  from_party VARCHAR(10) NOT NULL CHECK (from_party IN ('patient','caregiver','office')),
  author_label NVARCHAR(160) NOT NULL, author_user_id UNIQUEIDENTIFIER NULL, caregiver_id UNIQUEIDENTIFIER NULL REFERENCES core.caregivers(caregiver_id),
  text NVARCHAR(MAX) NOT NULL, at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME(), read_at DATETIME2(3) NULL
);
CREATE TABLE m.message_attachments (                              -- Att; "File to Documents" sets filed_document_id
  attachment_id UNIQUEIDENTIFIER NOT NULL DEFAULT NEWSEQUENTIALID() PRIMARY KEY,
  tenant_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.tenants(tenant_id),
  message_id UNIQUEIDENTIFIER NOT NULL REFERENCES m.messages(message_id),
  patient_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.patients(patient_id),
  name NVARCHAR(260) NOT NULL, kind VARCHAR(5) NOT NULL CHECK (kind IN ('image','pdf','doc','heic','text')),
  blob_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.blob_objects(blob_id),
  filed_document_id UNIQUEIDENTIFIER NULL REFERENCES core.documents(document_id), filed_by UNIQUEIDENTIFIER NULL, filed_at DATETIME2(3) NULL,
  removed_at DATETIME2(3) NULL
);

/* ---- billing ---- */
CREATE TABLE m.fee_schedule_items (
  fee_id UNIQUEIDENTIFIER NOT NULL DEFAULT NEWSEQUENTIALID() PRIMARY KEY,
  tenant_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.tenants(tenant_id),
  code VARCHAR(20) NULL, label NVARCHAR(200) NOT NULL, amount_cents INT NOT NULL, category NVARCHAR(60) NULL, active BIT NOT NULL DEFAULT 1
);
CREATE TABLE m.invoices (
  invoice_id UNIQUEIDENTIFIER NOT NULL DEFAULT NEWSEQUENTIALID() PRIMARY KEY,
  tenant_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.tenants(tenant_id),
  patient_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.patients(patient_id),
  invoice_number VARCHAR(30) NOT NULL,                             -- server-generated sequence per tenant
  visit_id UNIQUEIDENTIFIER NULL REFERENCES m.visits(visit_id), quote_id UNIQUEIDENTIFIER NULL,
  total_cents INT NOT NULL, status VARCHAR(12) NOT NULL, created_by UNIQUEIDENTIFIER NOT NULL, created_at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME(),
  CONSTRAINT uq_invoice_no UNIQUE (tenant_id, invoice_number)
);
CREATE TABLE m.charges (                                          -- ChargeLine
  charge_id UNIQUEIDENTIFIER NOT NULL DEFAULT NEWSEQUENTIALID() PRIMARY KEY,
  tenant_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.tenants(tenant_id),
  visit_id UNIQUEIDENTIFIER NOT NULL REFERENCES m.visits(visit_id),
  patient_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.patients(patient_id),
  fee_id UNIQUEIDENTIFIER NULL REFERENCES m.fee_schedule_items(fee_id), label NVARCHAR(200) NOT NULL, code VARCHAR(20) NULL,
  qty INT NOT NULL, amount_cents INT NOT NULL, station VARCHAR(16) NOT NULL,
  invoice_id UNIQUEIDENTIFIER NULL REFERENCES m.invoices(invoice_id),
  added_by UNIQUEIDENTIFIER NOT NULL, at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME(), removed_at DATETIME2(3) NULL
);
CREATE TABLE m.quotes (
  quote_id UNIQUEIDENTIFIER NOT NULL DEFAULT NEWSEQUENTIALID() PRIMARY KEY,
  tenant_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.tenants(tenant_id),
  patient_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.patients(patient_id),
  quote_number VARCHAR(30) NOT NULL,
  status VARCHAR(10) NOT NULL CHECK (status IN ('Draft','Presented','Accepted','Declined','Expired')),
  current_version INT NOT NULL, invoice_id UNIQUEIDENTIFIER NULL REFERENCES m.invoices(invoice_id),
  duplicated_from UNIQUEIDENTIFIER NULL, CONSTRAINT uq_quote_no UNIQUE (tenant_id, quote_number)
);
CREATE TABLE m.quote_versions (                                   -- immutable once presented
  quote_id UNIQUEIDENTIFIER NOT NULL REFERENCES m.quotes(quote_id), version INT NOT NULL,
  tenant_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.tenants(tenant_id),
  quote_date DATE NOT NULL, valid_until DATE NOT NULL, procedure_text NVARCHAR(300) NOT NULL, surgeon_label NVARCHAR(160) NULL,
  lines_json NVARCHAR(MAX) NOT NULL CHECK (ISJSON(lines_json) = 1), terms NVARCHAR(MAX) NULL, financing NVARCHAR(MAX) NULL,
  note NVARCHAR(2000) NULL, total_cents INT NOT NULL, created_by UNIQUEIDENTIFIER NOT NULL, created_at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME(),
  PRIMARY KEY (quote_id, version)
);
CREATE TABLE m.quote_events (
  event_id BIGINT IDENTITY(1,1) NOT NULL PRIMARY KEY, tenant_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.tenants(tenant_id),
  quote_id UNIQUEIDENTIFIER NOT NULL REFERENCES m.quotes(quote_id),
  what NVARCHAR(300) NOT NULL, by_user_id UNIQUEIDENTIFIER NOT NULL, at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME()
);
CREATE TABLE m.payments (                                         -- PatientPayment; NO card numbers or CVV, processor tokens only
  payment_id UNIQUEIDENTIFIER NOT NULL DEFAULT NEWSEQUENTIALID() PRIMARY KEY,
  tenant_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.tenants(tenant_id),
  patient_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.patients(patient_id),
  receipt_number VARCHAR(30) NOT NULL, amount_cents INT NOT NULL,
  method VARCHAR(10) NOT NULL CHECK (method IN ('card','cash','check','financing','other')),
  card_brand VARCHAR(20) NULL, card_last4 CHAR(4) NULL, processor_ref NVARCHAR(120) NULL,
  reference NVARCHAR(120) NULL, reason NVARCHAR(300) NULL, channel VARCHAR(12) NOT NULL,
  taken_by UNIQUEIDENTIFIER NOT NULL, at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME()
);
CREATE TABLE m.payment_applications (
  payment_id UNIQUEIDENTIFIER NOT NULL REFERENCES m.payments(payment_id),
  invoice_id UNIQUEIDENTIFIER NOT NULL REFERENCES m.invoices(invoice_id),
  tenant_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.tenants(tenant_id), amount_cents INT NOT NULL, at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME(),
  PRIMARY KEY (payment_id, invoice_id)
);

/* ---- records-packets ---- */
CREATE TABLE m.outside_doctors (                                  -- later: link to an NPI directory row
  outside_doctor_id UNIQUEIDENTIFIER NOT NULL DEFAULT NEWSEQUENTIALID() PRIMARY KEY,
  tenant_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.tenants(tenant_id),
  name NVARCHAR(160) NOT NULL, specialty NVARCHAR(80) NULL, org NVARCHAR(160) NULL,
  fax NVARCHAR(40) NULL, email NVARCHAR(254) NULL, phone NVARCHAR(40) NULL, npi CHAR(10) NULL
);
CREATE TABLE m.records_packets (                                  -- SentRec
  packet_id UNIQUEIDENTIFIER NOT NULL DEFAULT NEWSEQUENTIALID() PRIMARY KEY,
  tenant_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.tenants(tenant_id),
  patient_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.patients(patient_id),
  title NVARCHAR(300) NOT NULL, preset VARCHAR(10) NOT NULL CHECK (preset IN ('preop','referral','consult','patient','custom')),
  purpose NVARCHAR(300) NOT NULL,
  recipient_kind VARCHAR(10) NOT NULL CHECK (recipient_kind IN ('referring','doctor','asc','patient','free')),
  recipient_name NVARCHAR(160) NOT NULL, recipient_org NVARCHAR(160) NULL,
  method VARCHAR(8) NOT NULL CHECK (method IN ('email','fax','portal','network')), address NVARCHAR(300) NOT NULL,
  items_json NVARCHAR(MAX) NOT NULL CHECK (ISJSON(items_json) = 1), pages INT NOT NULL,
  cover_letter NVARCHAR(MAX) NULL, cover_sheet BIT NOT NULL,
  hipaa_code VARCHAR(12) NOT NULL CHECK (hipaa_code IN ('patient','authorized','treatment','no-auth')),
  hipaa_auth_form_record_id UNIQUEIDENTIFIER NULL REFERENCES core.form_records(form_record_id),
  hipaa_override_reason NVARCHAR(500) NULL,                       -- soft check: warn, and allow with a reason
  pdf_blob_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.blob_objects(blob_id),
  resend_of UNIQUEIDENTIFIER NULL, outbox_id UNIQUEIDENTIFIER NULL REFERENCES core.outbox(outbox_id),
  sent_by UNIQUEIDENTIFIER NOT NULL, sent_at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME()
);

/* ---- photos-bodycharts ---- */
CREATE TABLE m.clinical_photos (
  photo_id UNIQUEIDENTIFIER NOT NULL DEFAULT NEWSEQUENTIALID() PRIMARY KEY,
  tenant_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.tenants(tenant_id),
  patient_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.patients(patient_id),
  visit_id UNIQUEIDENTIFIER NULL REFERENCES m.visits(visit_id),
  blob_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.blob_objects(blob_id),
  phase VARCHAR(6) NOT NULL CHECK (phase IN ('before','after')), photo_date DATE NOT NULL,
  area NVARCHAR(80) NOT NULL, view_label NVARCHAR(60) NOT NULL, note NVARCHAR(1000) NULL,
  by_user_id UNIQUEIDENTIFIER NOT NULL, at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME(), removed_at DATETIME2(3) NULL
);
CREATE TABLE m.body_charts (                                      -- versioned series
  chart_id UNIQUEIDENTIFIER NOT NULL DEFAULT NEWSEQUENTIALID() PRIMARY KEY,
  tenant_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.tenants(tenant_id),
  series_id UNIQUEIDENTIFIER NOT NULL, version INT NOT NULL,
  patient_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.patients(patient_id),
  visit_id UNIQUEIDENTIFIER NULL REFERENCES m.visits(visit_id),
  diagram NVARCHAR(60) NOT NULL, title NVARCHAR(200) NOT NULL,
  strokes_json NVARCHAR(MAX) NOT NULL CHECK (ISJSON(strokes_json) = 1), texts_json NVARCHAR(MAX) NULL,
  by_user_id UNIQUEIDENTIFIER NOT NULL, at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME(),
  CONSTRAINT uq_chart_ver UNIQUE (series_id, version)
);

/* ---- asc-perioperative (office side; the ASC case tables are Henry's ASC schema) ---- */
CREATE TABLE m.asc_facilities (
  facility_id UNIQUEIDENTIFIER NOT NULL DEFAULT NEWSEQUENTIALID() PRIMARY KEY,
  tenant_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.tenants(tenant_id),
  asc_tenant_id UNIQUEIDENTIFIER NULL REFERENCES core.tenants(tenant_id),   -- set when the ASC is itself a Vityls tenant
  name NVARCHAR(160) NOT NULL, city NVARCHAR(80) NULL, active BIT NOT NULL DEFAULT 1, is_primary BIT NOT NULL DEFAULT 0,
  baa_on_file BIT NOT NULL DEFAULT 0
);
CREATE TABLE m.asc_packets (                                      -- AscPacket (Send to ASC)
  asc_packet_id UNIQUEIDENTIFIER NOT NULL DEFAULT NEWSEQUENTIALID() PRIMARY KEY,
  tenant_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.tenants(tenant_id),
  patient_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.patients(patient_id),
  visit_id UNIQUEIDENTIFIER NULL REFERENCES m.visits(visit_id),
  facility_id UNIQUEIDENTIFIER NOT NULL REFERENCES m.asc_facilities(facility_id),
  surgeon_user_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.users(user_id),
  scheduling_form_json NVARCHAR(MAX) NOT NULL CHECK (ISJSON(scheduling_form_json) = 1),  -- procedure, CPT, dx, ICD-10, laterality, anesthesia, duration, block
  docs_json NVARCHAR(MAX) NOT NULL CHECK (ISJSON(docs_json) = 1),
  status VARCHAR(10) NOT NULL CHECK (status IN ('sent','received')), received_at DATETIME2(3) NULL, asc_case_ref NVARCHAR(100) NULL,
  sent_by UNIQUEIDENTIFIER NOT NULL, sent_at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME()
);
CREATE TABLE m.asc_blocks (
  block_id UNIQUEIDENTIFIER NOT NULL DEFAULT NEWSEQUENTIALID() PRIMARY KEY,
  tenant_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.tenants(tenant_id),
  facility_id UNIQUEIDENTIFIER NOT NULL REFERENCES m.asc_facilities(facility_id),
  surgeon_user_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.users(user_id),
  block_date DATE NOT NULL, start_time TIME(0) NOT NULL, end_time TIME(0) NOT NULL, room NVARCHAR(40) NULL
);
CREATE TABLE m.network_messages (                                 -- office <-> ASC thread per case (requires an active link and a BAA)
  network_message_id UNIQUEIDENTIFIER NOT NULL DEFAULT NEWSEQUENTIALID() PRIMARY KEY,
  tenant_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.tenants(tenant_id),
  asc_packet_id UNIQUEIDENTIFIER NULL REFERENCES m.asc_packets(asc_packet_id), case_ref NVARCHAR(100) NOT NULL,
  from_org VARCHAR(6) NOT NULL CHECK (from_org IN ('office','asc')), author_label NVARCHAR(160) NOT NULL, role NVARCHAR(60) NULL,
  text NVARCHAR(MAX) NULL, document_id UNIQUEIDENTIFIER NULL REFERENCES core.documents(document_id),
  at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME()
);

/* ---- email-intake ---- */
CREATE TABLE m.email_mailboxes (                                  -- the connected practice mailbox (Graph / IMAP); secrets in Key Vault
  mailbox_id UNIQUEIDENTIFIER NOT NULL DEFAULT NEWSEQUENTIALID() PRIMARY KEY,
  tenant_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.tenants(tenant_id),
  address NVARCHAR(254) NOT NULL, provider VARCHAR(20) NOT NULL, key_vault_secret_name NVARCHAR(127) NULL,
  connected_at DATETIME2(3) NULL, active BIT NOT NULL DEFAULT 1
);
CREATE TABLE m.email_messages (                                   -- Email
  email_id UNIQUEIDENTIFIER NOT NULL DEFAULT NEWSEQUENTIALID() PRIMARY KEY,
  tenant_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.tenants(tenant_id),
  mailbox_id UNIQUEIDENTIFIER NULL REFERENCES m.email_mailboxes(mailbox_id),
  provider_message_id NVARCHAR(300) NULL,
  from_address NVARCHAR(254) NOT NULL, from_name NVARCHAR(160) NULL, org NVARCHAR(160) NULL,   -- may contain PHI
  subject NVARCHAR(500) NOT NULL, body NVARCHAR(MAX) NOT NULL,                                -- PHI
  received_at DATETIME2(3) NOT NULL,
  kind VARCHAR(8) NOT NULL CHECK (kind IN ('request','other')),
  status VARCHAR(10) NOT NULL CHECK (status IN ('new','accepted','replied','dismissed')),
  patient_id UNIQUEIDENTIFIER NULL REFERENCES core.patients(patient_id), matched_existing BIT NULL,
  visit_id UNIQUEIDENTIFIER NULL                                   -- no FK: scheduling may be off
);
CREATE TABLE m.email_attachments (
  email_attachment_id UNIQUEIDENTIFIER NOT NULL DEFAULT NEWSEQUENTIALID() PRIMARY KEY,
  tenant_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.tenants(tenant_id),
  email_id UNIQUEIDENTIFIER NOT NULL REFERENCES m.email_messages(email_id),
  name NVARCHAR(260) NOT NULL, blob_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.blob_objects(blob_id),
  filed_document_id UNIQUEIDENTIFIER NULL REFERENCES core.documents(document_id)
);
CREATE TABLE m.email_extractions (                                -- Nightingale review card; a person edits before accepting
  email_id UNIQUEIDENTIFIER NOT NULL PRIMARY KEY REFERENCES m.email_messages(email_id),
  tenant_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.tenants(tenant_id),
  fields_json NVARCHAR(MAX) NOT NULL CHECK (ISJSON(fields_json) = 1),   -- patient, dob, contact, procedure, requestedDate, surgeon, referring, insurance, urgency + confidence
  engine NVARCHAR(60) NOT NULL, model_version NVARCHAR(60) NULL,
  accepted_by UNIQUEIDENTIFIER NULL, accepted_at DATETIME2(3) NULL
);
CREATE TABLE m.email_sched_requests (                             -- SchedRequest
  request_id UNIQUEIDENTIFIER NOT NULL DEFAULT NEWSEQUENTIALID() PRIMARY KEY,
  tenant_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.tenants(tenant_id),
  email_id UNIQUEIDENTIFIER NOT NULL REFERENCES m.email_messages(email_id),
  patient_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.patients(patient_id),
  procedure_text NVARCHAR(300) NULL, requested_date DATE NULL, surgeon_label NVARCHAR(160) NULL, referring NVARCHAR(160) NULL,
  status VARCHAR(20) NOT NULL CHECK (status IN ('awaiting-scheduling','booked')), visit_id UNIQUEIDENTIFIER NULL,
  created_by UNIQUEIDENTIFIER NOT NULL, created_at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME()
);
CREATE TABLE m.email_replies (
  email_id UNIQUEIDENTIFIER NOT NULL PRIMARY KEY REFERENCES m.email_messages(email_id),
  tenant_id UNIQUEIDENTIFIER NOT NULL REFERENCES core.tenants(tenant_id),
  draft_text NVARCHAR(MAX) NOT NULL,                               -- Nightingale draft, edited by a person
  approved_by UNIQUEIDENTIFIER NOT NULL, approved_at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME(),
  outbox_id UNIQUEIDENTIFIER NULL REFERENCES core.outbox(outbox_id)
);
GO

/* ================================================ Row-level security =============================================== */
CREATE SCHEMA sec;
GO
CREATE FUNCTION sec.fn_tenant_predicate(@tenant_id UNIQUEIDENTIFIER)
RETURNS TABLE WITH SCHEMABINDING AS
RETURN SELECT 1 AS ok WHERE @tenant_id = CAST(SESSION_CONTEXT(N'tenant_id') AS UNIQUEIDENTIFIER)
                          OR CAST(SESSION_CONTEXT(N'is_vityls_admin') AS BIT) = 1;
GO
/* The API sets this on every request:  EXEC sp_set_session_context N'tenant_id', @tid, @read_only = 1;
   Add one FILTER + BLOCK predicate per tenant table. Three examples follow; generate the rest with a script
   over every table that has a tenant_id column. */
CREATE SECURITY POLICY sec.tenant_isolation
  ADD FILTER PREDICATE sec.fn_tenant_predicate(tenant_id) ON core.patients,
  ADD BLOCK  PREDICATE sec.fn_tenant_predicate(tenant_id) ON core.patients AFTER INSERT,
  ADD FILTER PREDICATE sec.fn_tenant_predicate(tenant_id) ON core.documents,
  ADD BLOCK  PREDICATE sec.fn_tenant_predicate(tenant_id) ON core.documents AFTER INSERT,
  ADD FILTER PREDICATE sec.fn_tenant_predicate(tenant_id) ON m.visits,
  ADD BLOCK  PREDICATE sec.fn_tenant_predicate(tenant_id) ON m.visits AFTER INSERT
WITH (STATE = ON);
GO

/* ================================================ Catalog seed ===================================================== */
INSERT INTO core.modules (module_id, name, description, default_trial_days, price_hint) VALUES
 ('email-intake','AI Email Intake','Nightingale reads the practice inbox, extracts requests, files attachments and drafts replies.',14,'Starter module'),
 ('scheduling','Scheduling & reminders','Provider schedule, Today board, double-booking, block time, reminders.',14,'Per practice'),
 ('chart','Patient chart','Living summary, diagnoses, notes, documents UI and timeline.',14,'Per provider'),
 ('stations-workflow','Stations workflow','Portal/At-home, Front desk, Nursing, Provider, Checkout; scribe (simulated); PIN signing.',14,'Included in clinical bundles'),
 ('forms','Forms & at-home','Form library, editor, at-home links, signed forms filed to Documents.',14,'Per practice'),
 ('messages','Secure messages','Portal and staff messages with attachments filed to Documents.',14,'Per practice'),
 ('billing','Billing, payments & quotes','Invoices, payments, ledger, checkout charges, quotes.',14,'Per practice'),
 ('records-packets','Records packets (Print / Send)','Pre-op clearance, consult report and referral packets with a HIPAA release check.',7,'Add-on'),
 ('reports','Reports & performance','Visits, diagnoses & procedures, coordinators, collections.',7,'Add-on'),
 ('photos-bodycharts','Photos & body charts','Clinical photos, before/after, body charts.',7,'Add-on'),
 ('asc-perioperative','ASC perioperative','OR, pre-op clearance, anesthesia, PACU, facility fees; Send to ASC.',14,'ASC bundle'),
 ('portal-link','Patient Portal link','Connects the practice to the Vityls Patient Portal.',14,'Free for patients');
INSERT INTO core.module_dependencies (module_id, depends_on, kind) VALUES
 ('stations-workflow','scheduling','requires'),('stations-workflow','chart','requires'),
 ('forms','scheduling','requires'),('records-packets','chart','requires'),
 ('photos-bodycharts','chart','requires'),('asc-perioperative','scheduling','requires'),
 ('email-intake','scheduling','enhances'),('email-intake','chart','enhances'),
 ('forms','stations-workflow','enhances'),('messages','chart','enhances'),('billing','stations-workflow','enhances'),
 ('portal-link','forms','enhances'),('portal-link','messages','enhances');
INSERT INTO core.plans (plan_id, name, edition) VALUES
 ('asc-full','ASC.Vityls full','ASC'),('surgery-standard','Surgery.Vityls','SURGERY'),('medical-standard','Medical.Vityls','MEDICAL'),('email-starter','Email Intake starter',NULL);
INSERT INTO core.plan_modules (plan_id, module_id)
 SELECT 'asc-full', module_id FROM core.modules WHERE module_id <> 'email-intake'
 UNION ALL SELECT 'surgery-standard', module_id FROM core.modules WHERE module_id <> 'email-intake'
 UNION ALL SELECT 'medical-standard', module_id FROM core.modules WHERE module_id NOT IN ('email-intake','asc-perioperative')
 UNION ALL SELECT 'email-starter', 'email-intake';
GO
