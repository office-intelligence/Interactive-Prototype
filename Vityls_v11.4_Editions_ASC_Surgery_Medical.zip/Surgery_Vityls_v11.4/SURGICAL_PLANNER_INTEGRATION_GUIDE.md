# 🩺 Vityls Standalone 2D & 3D Surgical Planning Suite
## Developer & AI Agent Integration Guide

This guide describes how to drop the **Vityls Standalone Surgical Planning Suite** into your working version of Vityls or any clinical EHR application.

---

## 🌟 Overview of Features
1. **Real Patient Photograph Ingestion**:
   - File upload (JPG, PNG, WEBP, DICOM JPEG)
   - Drag-and-drop directly onto the canvas
   - Clipboard paste (`Ctrl+V` / `Cmd+V`) for immediate screenshot intake from PACS/EHR
   - Bundled realistic clinical photo presets (Frontal, Lateral Rhinoplasty, Periorbital Blepharoplasty, Submental Neck)
2. **True Physical Scale Calibration (Millimeters)**:
   - Click 2 points along a known skin ruler or anatomical landmark (e.g. 10mm paper ruler, 11.7mm corneal diameter)
   - Caliper, incision lines, and tension vectors calculate and display true physical millimeter readouts in real-time.
3. **Surgical Marking Suite**:
   - Authentic **Gentian violet** semi-transparent surgical pen (`#552586`)
   - Complete color coding: Gentian violet (Incision), Crimson Red (Excision / Vascular risk), Surgical Blue (SMAS Plication / Sutures), Viridian Green (Graft), Carbon Black (Midline / Reference)
   - Freehand Pen, Straight Incision Line, Vector Tension Arrows, Skin Excision Ellipses, Digital Caliper, Danger Zone Highlighters, Anatomical Labels
4. **3D Multi-Angle Photogrammetry Reconstruction (Three.js)**:
   - Ingests standard 6-angle clinical photographic series:
     * Frontal (0°)
     * Right Oblique (45°)
     * Left Oblique (45°)
     * Right Lateral Profile (90°)
     * Left Lateral Profile (90°)
     * Submental / Basal
   - Generates interactive 3D anatomical surface mesh with 360° rotation and OR lighting rigs
   - 3D surgical incisions, 3D elevation vectors, and interactive 3D volumetric morph simulation (e.g. rhinoplasty hump reduction, SMAS elevation).
5. **Turnkey Integration Contract (`window.postMessage`)**:
   - Zero external build dependencies. Runs in any browser, iframe, web component, or modal.

---

## 🚀 2-Minute Quick Setup

### Step 1: Copy the Standalone File
Copy `public/surgical-planner.html` into your project's `public/` folder:
- **Next.js**: `public/surgical-planner.html` (Accessible at `http://localhost:3000/surgical-planner.html`)
- **Vite / CRA**: `public/surgical-planner.html`
- **Express / Static Server**: Place in your static assets directory.

### Step 2: Use the Drop-in React Component
Copy `src/components/SurgicalPlannerModal.tsx` into your components directory and call it from your patient chart or schedule view:

```tsx
import React, { useState } from 'react';
import { SurgicalPlannerModal } from './components/SurgicalPlannerModal';

export const PatientChart = ({ activePatient }) => {
  const [plannerOpen, setPlannerOpen] = useState(false);

  const handleSavePlan = (payload) => {
    console.log("Plan Saved for MRN:", payload.patient.mrn);
    console.log("High-Res Image Base64:", payload.imageBase64);
    console.log("Vector JSON Data:", payload.planJson);
    
    // 1. Save payload.imageBase64 to your document storage (S3, Cloud Storage, or Firestore)
    // 2. Attach payload.planJson to the patient's surgical record
    setPlannerOpen(false);
  };

  return (
    <div>
      <button 
        onClick={() => setPlannerOpen(true)}
        className="px-4 py-2 bg-sky-600 text-white rounded-lg font-semibold"
      >
        📐 Open Surgical Planner (2D & 3D)
      </button>

      <SurgicalPlannerModal
        isOpen={plannerOpen}
        onClose={() => setPlannerOpen(false)}
        patient={{
          name: activePatient.name,
          mrn: activePatient.id || activePatient.mrn,
          procedure: activePatient.procedure || "Deep Plane Facelift",
          photoUrl: activePatient.preOpPhotoUrl, // Optional: auto-loads patient photo
        }}
        onSavePlan={handleSavePlan}
      />
    </div>
  );
};
```

---

## 📡 Bidirectional `postMessage` Protocol Specification

If your other AI agent is using vanilla JavaScript, Vue, Svelte, or Angular, embed via iframe:

```html
<iframe id="plannerFrame" src="/surgical-planner.html" style="width:100%; height:90vh; border:none;"></iframe>
```

### 1. Inbound Events (Host App ➡️ Surgical Planner)

#### Load Patient Demographics & Photo
```javascript
const frame = document.getElementById('plannerFrame').contentWindow;

frame.postMessage({
  type: 'VITLYS_LOAD_PATIENT',
  patient: {
    name: "Patricia DePoli",
    mrn: "#113850",
    procedure: "Deep Plane Facelift & Rhinoplasty",
    surgeon: "Dr. Guy Massry, MD"
  },
  photoUrl: "https://your-domain.com/patient-preop.jpg" // optional URL or base64
}, '*');
```

#### Load Existing Plan (for Re-editing)
```javascript
frame.postMessage({
  type: 'VITLYS_LOAD_PLAN',
  plan: savedPlanJsonObject // Previously saved plan data
}, '*');
```

---

### 2. Outbound Events (Surgical Planner ➡️ Host App)

#### Planner Ready
Dispatched once the planner has fully booted and is ready to receive patient data:
```javascript
window.addEventListener('message', (event) => {
  if (event.data?.type === 'VITLYS_READY') {
    console.log("Surgical planner is initialized and ready.");
  }
});
```

#### Plan Saved
Dispatched when the surgeon clicks the green **"Save to Vityls"** button:
```javascript
window.addEventListener('message', (event) => {
  if (event.data?.type === 'VITLYS_PLAN_SAVED') {
    const { patient, imageBase64, planJson, timestamp } = event.data.payload;
    
    // Save to your database:
    // - imageBase64: 300-DPI composite with markings, scale bar, and sign-off
    // - planJson: raw vector markings, measurements, calibration, and notes
  }
});
```

#### Planner Closed
Dispatched when the surgeon clicks **"Back to Practice Settings"**:
```javascript
window.addEventListener('message', (event) => {
  if (event.data?.type === 'VITLYS_PLANNER_CLOSE') {
    // Hide or unmount modal
  }
});
```

---

## 📐 How 3D Multi-Angle Reconstruction Works

Surgeons routinely capture standard multi-angle photographs:
- **0° Frontal**
- **45° Right & Left Obliques**
- **90° Right & Left Lateral Profiles**
- **Basal / Submental Angle**

### Architecture in this Suite:
1. **Three.js WebGL Viewport**: Runs an anatomical facial model with high-density vertex distribution along critical surgical landmarks (nasal dorsum, alar base, zygoma, mandible, chin, and neck).
2. **Multi-View Texture Projection**: The multi-angle photos are mapped onto the 3D surface geometry.
3. **OR Surgical Lighting Rig**: Overhead key light, cool soft fill light, and contour-defining rim light allow surgeons to inspect shadows and volumetric contours at any 360° angle.
4. **3D Surface Raycasting**: Incision lines and SMAS elevation vectors can be drawn and inspected directly in true 3D spatial coordinates.
5. **Photogrammetry Pipeline Extension**: For production deployments with 20+ photographic slices, you can stream dense point clouds or OBJ/GLTF files into `threeScene` using standard loaders (`OBJLoader`, `GLTFLoader`).
