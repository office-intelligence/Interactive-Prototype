import React, { useState } from 'react';
import { Sidebar } from './components/Sidebar';
import { Header } from './components/Header';
import { NightingaleBriefBanner } from './components/NightingaleBriefBanner';
import { ScheduleIntelligenceBox } from './components/ScheduleIntelligenceBox';
import { ScheduleFullView } from './components/ScheduleFullView';
import { BlankPageTemplate } from './components/BlankPageTemplate';
import { PatientChartPage } from './components/PatientChartPage';
import { AdministrationPage } from './components/AdministrationPage';
import { BillingModulePage } from './components/BillingModulePage';
import { TasksWidget } from './components/TasksWidget';
import { CommunicationWidget } from './components/CommunicationWidget';
import { PatientDetailModal } from './components/PatientDetailModal';
import { AddPatientModal } from './components/AddPatientModal';
import { NightingaleAIChatDrawer } from './components/NightingaleAIChatDrawer';
import { AIWorkflowExamples } from './components/AIWorkflowExamples';
import { AIHomePage } from './components/AIHomePage';
import { AIPatientChartOverview } from './components/AIPatientChartOverview';
import { 
  initialPatientCases, 
  initialTasks, 
  initialStats, 
  initialBottleneckAlerts 
} from './data/mockData';
import { getCasesForDateKey } from './utils/dateCases';
import { PatientCase, PatientStage, TaskItem } from './types';
import { ScheduleViewMode } from './components/ScheduleIntelligenceBox';
import { 
  CheckCircle2, 
  AlertTriangle, 
  Sparkles, 
  Plus, 
  Calendar, 
  FileText, 
  CreditCard, 
  Settings, 
  Zap, 
  ChevronLeft, 
  ChevronRight, 
  CalendarDays,
  Building2,
  Layers
} from 'lucide-react';

const TODAY_DATE = new Date(2026, 6, 13); // Monday, July 13, 2026

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('home');
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState<boolean>(true);

  // Date navigation & view mode state
  const [selectedDate, setSelectedDate] = useState<Date>(TODAY_DATE);
  const [dateCasesMap, setDateCasesMap] = useState<Record<string, PatientCase[]>>({});
  const [scheduleViewMode, setScheduleViewMode] = useState<ScheduleViewMode>('PRIORITY');

  const [tasks, setTasks] = useState<TaskItem[]>(initialTasks);
  const [stats, setStats] = useState(initialStats);
  const [searchQuery, setSearchQuery] = useState('');
  
  const [selectedPatient, setSelectedPatient] = useState<PatientCase | null>(null);
  const [selectedChartPatientId, setSelectedChartPatientId] = useState<string>('case-1');
  const [isAddPatientModalOpen, setIsAddPatientModalOpen] = useState(false);
  const [isAIChatOpen, setIsAIChatOpen] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const formatDateKey = (d: Date) => {
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  };

  const formatDisplayDate = (d: Date) => {
    return d.toLocaleDateString('en-US', {
      weekday: 'long',
      month: 'long',
      day: 'numeric',
      year: 'numeric',
    });
  };

  const activeDateKey = formatDateKey(selectedDate);
  const activeDateCases = dateCasesMap[activeDateKey] || getCasesForDateKey(activeDateKey, formatDisplayDate(selectedDate));

  const isToday =
    selectedDate.getFullYear() === TODAY_DATE.getFullYear() &&
    selectedDate.getMonth() === TODAY_DATE.getMonth() &&
    selectedDate.getDate() === TODAY_DATE.getDate();

  const handlePrevDay = () => {
    setSelectedDate((prev) => {
      const d = new Date(prev);
      d.setDate(d.getDate() - 1);
      showToast(`Schedule view: ${formatDisplayDate(d)}`);
      return d;
    });
  };

  const handleNextDay = () => {
    setSelectedDate((prev) => {
      const d = new Date(prev);
      d.setDate(d.getDate() + 1);
      showToast(`Schedule view: ${formatDisplayDate(d)}`);
      return d;
    });
  };

  const handleToday = () => {
    const d = new Date(TODAY_DATE);
    setSelectedDate(d);
    showToast(`Schedule view reset to Today (${formatDisplayDate(d)})`);
  };

  const updateActiveCases = (updater: (prev: PatientCase[]) => PatientCase[]) => {
    setDateCasesMap((prevMap) => {
      const current = prevMap[activeDateKey] || getCasesForDateKey(activeDateKey, formatDisplayDate(selectedDate));
      return {
        ...prevMap,
        [activeDateKey]: updater(current),
      };
    });
  };

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 4000);
  };

  const handleOpenPatientChart = (patient: PatientCase) => {
    setSelectedChartPatientId(patient.id);
    setActiveTab('patients');
    showToast(`Opening Patient Chart for ${patient.name}...`);
  };

  // Fast-track EKG resolution handler
  const handleTriggerEKGFastTrack = (caseId: string) => {
    updateActiveCases((prev) =>
      prev.map((c) => {
        if (c.id === caseId) {
          const updatedLabs = c.labs.map((l) =>
            l.name === 'EKG' ? { name: 'EKG', value: 'Fax Received - Normal Sinus', status: 'normal' as const } : l
          );
          return {
            ...c,
            readinessScore: 98,
            readinessLevel: 'CLEARED' as const,
            aiSummary: 'EKG report received from Beverly Hills Cardiology via fast-track fax. Pre-op photo review cleared. Patient fully ready for OR 1.',
            labs: updatedLabs,
            bottlenecks: [],
            actionItems: c.actionItems.map((a) => ({ ...a, done: true })),
          };
        }
        return c;
      })
    );

    // Also mark related task as completed
    setTasks((prev) =>
      prev.map((t) => (t.id === 'task-4' ? { ...t, completed: true } : t))
    );

    showToast('⚡ EKG Fast-Track: EKG report received & cleared for Patricia DePoli! AI Readiness updated to 98.');
  };

  // Update patient stage (Check-In -> Pre-Op -> In OR -> PACU -> Discharged)
  const handleUpdateStage = (caseId: string, newStage: PatientStage) => {
    updateActiveCases((prev) =>
      prev.map((c) => {
        if (c.id === caseId) {
          return { ...c, stage: newStage };
        }
        return c;
      })
    );
    showToast(`Updated patient flow stage to ${newStage.replace('_', ' ')}.`);
  };

  // Action checklist toggle
  const handleResolveAction = (caseId: string, actionId: string) => {
    updateActiveCases((prev) =>
      prev.map((c) => {
        if (c.id === caseId) {
          const updatedItems = c.actionItems.map((a) =>
            a.id === actionId ? { ...a, done: !a.done } : a
          );
          return { ...c, actionItems: updatedItems };
        }
        return c;
      })
    );
  };

  // Toggle Task Completion
  const handleToggleTask = (taskId: string) => {
    setTasks((prev) =>
      prev.map((t) => (t.id === taskId ? { ...t, completed: !t.completed } : t))
    );
  };

  // Simulate new patient arrival
  const handleSimulateArrival = () => {
    const newCase: PatientCase = {
      id: `case-${Date.now()}`,
      patientId: `${Math.floor(100000 + Math.random() * 900000)}`,
      name: 'Eleanor Vance',
      age: 58,
      gender: 'Female',
      phone: '(310) 555-0192',
      scheduledTime: '2:15 PM',
      estimatedDurationMins: 60,
      room: 'Minor Proc Bay',
      surgeon: 'Guy Massry, MD',
      procedure: 'Minor peri-orbital skin revision & cyst excision',
      aiSummary: 'Direct referral check-in. Pre-op vitals normal.',
      readinessScore: 94,
      readinessLevel: 'CLEARED',
      allergies: ['None known'],
      labs: [
        { name: 'CBC', value: '13.0 g/dL', status: 'normal' },
        { name: 'BMP', value: 'Normal', status: 'normal' },
      ],
      stage: 'CHECK_IN',
      arrivalStatus: 'ARRIVED',
      arrivalTime: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      bottlenecks: [],
      actionItems: [{ id: 'a-new', text: 'Obtain minor procedure consent', type: 'CONSENT', done: false }],
    };

    updateActiveCases((prev) => [...prev, newCase]);
    showToast(`Simulated arrival: Eleanor Vance checked in at reception for 2:15 PM procedure.`);
  };

  // AI Optimization Analysis trigger
  const handleTriggerAIAnalysis = async () => {
    showToast('Running Nightingale AI Schedule Bottleneck & Optimization Analysis...');
    try {
      const res = await fetch('/api/ai/analyze-bottlenecks', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ schedule: activeDateCases }),
      });
      const data = await res.json();
      showToast('AI Analysis complete: OR 1 turnover optimized, 1 EKG bottleneck flagged.');
    } catch (e) {
      showToast('Nightingale AI: Schedule optimization complete.');
    }
  };

  // Search filtered cases
  const displayedCases = activeDateCases.filter((c) => {
    if (!searchQuery) return true;
    const q = searchQuery.toLowerCase();
    return (
      c.name.toLowerCase().includes(q) ||
      c.patientId.includes(q) ||
      c.procedure.toLowerCase().includes(q) ||
      c.surgeon.toLowerCase().includes(q)
    );
  });

  const needsAttentionCount = activeDateCases.filter(
    (c) => c.readinessLevel === 'NEEDS_ATTENTION' || c.readinessLevel === 'CRITICAL_HOLD'
  ).length;

  return (
    <div className="min-h-screen bg-slate-100 text-slate-900 font-sans antialiased flex flex-col md:flex-row overflow-x-hidden selection:bg-indigo-500 selection:text-white">
      
      {/* Toast Banner */}
      {toastMessage && (
        <div className="fixed top-4 right-4 z-50 bg-blue-900 text-white text-xs font-semibold px-4 py-3 rounded-2xl shadow-2xl border border-blue-800 flex items-center gap-2.5 animate-in slide-in-from-top duration-300">
          <Sparkles className="w-4 h-4 text-blue-300 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Left Sidebar */}
      <Sidebar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenAIChat={() => setIsAIChatOpen(true)}
        needsAttentionCount={needsAttentionCount}
        isCollapsed={isSidebarCollapsed}
        onToggleCollapse={() => setIsSidebarCollapsed(!isSidebarCollapsed)}
      />

      {/* Main Workspace */}
      <div className="flex-1 flex flex-col min-w-0 bg-stone-100/90 pb-12">
        
        {/* Top Header Bar */}
        <Header
          onRefresh={() => showToast('Refreshed real-time ASC schedule & OR status.')}
          onAppointmentBooks={() => {
            setActiveTab('schedule');
            showToast('Switched to Schedule Appointment Books view.');
          }}
          onPrint={() => {
            showToast('Opening print dialog for ASC surgical schedule...');
            window.print();
          }}
          onAddPatient={() => {
            setIsAddPatientModalOpen(true);
          }}
          searchQuery={searchQuery}
          setSearchQuery={setSearchQuery}
          activeTab={activeTab}
          onToggleSidebar={() => setIsSidebarCollapsed(!isSidebarCollapsed)}
        />



        {/* Dashboard Body Content */}
        <main className="p-6 space-y-6 max-w-7xl w-full mx-auto">
          
          {/* TAB 1: HOME DASHBOARD */}
          {activeTab === 'home' && (
            <div className="space-y-6">
              
              {/* Top Date Navigation Bar on Home Page */}
              <div className="bg-white rounded-2xl border border-stone-200/90 p-4 shadow-2xs flex flex-wrap items-center justify-between gap-4">
                <div className="flex items-center gap-3.5 flex-wrap">
                  {/* Previous, TODAY, Next Buttons */}
                  <div className="flex items-center gap-2">
                    <button
                      onClick={handlePrevDay}
                      className="p-1.5 border border-stone-300 rounded-lg bg-white hover:bg-stone-100 text-stone-700 shadow-2xs transition-colors cursor-pointer flex items-center justify-center"
                      title="Previous Day"
                    >
                      <ChevronLeft className="w-5 h-5" />
                    </button>

                    <button
                      onClick={handleToday}
                      className="px-4 py-1.5 bg-[#2b3a4a] hover:bg-[#1e2936] text-white font-bold rounded-lg shadow-2xs text-xs transition-colors cursor-pointer tracking-wider uppercase"
                    >
                      TODAY
                    </button>

                    <button
                      onClick={handleNextDay}
                      className="p-1.5 border border-stone-300 rounded-lg bg-white hover:bg-stone-100 text-stone-700 shadow-2xs transition-colors cursor-pointer flex items-center justify-center"
                      title="Next Day"
                    >
                      <ChevronRight className="w-5 h-5" />
                    </button>
                  </div>

                  {/* Current Date Display */}
                  <div className="flex items-center gap-3">
                    <h2 className="text-xl font-serif font-bold text-stone-900 tracking-tight">
                      {formatDisplayDate(selectedDate)}
                    </h2>

                    {isToday ? (
                      <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800 border border-emerald-300 shadow-2xs">
                        Today
                      </span>
                    ) : (
                      <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-stone-100 text-stone-700 border border-stone-200">
                        Scheduled Day
                      </span>
                    )}

                    <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-indigo-50 text-indigo-700 border border-indigo-200">
                      {activeDateCases.length} {activeDateCases.length === 1 ? 'Case' : 'Cases'} Listed
                    </span>

                    {/* View Mode Switcher Bubbles next to Cases Listed tag */}
                    <div className="flex flex-wrap items-center gap-1.5 p-1 bg-stone-100 border border-stone-200/90 rounded-full text-xs font-semibold">
                      <button
                        onClick={() => setScheduleViewMode('PRIORITY')}
                        className={`px-3 py-1 rounded-full transition-all flex items-center gap-1.5 cursor-pointer ${
                          scheduleViewMode === 'PRIORITY'
                            ? 'bg-emerald-900 text-emerald-50 shadow-2xs font-bold'
                            : 'text-stone-700 hover:bg-stone-200/60 hover:text-stone-950'
                        }`}
                      >
                        <Sparkles className="w-3.5 h-3.5 text-emerald-300" />
                        <span>Priority</span>
                      </button>

                      <button
                        onClick={() => setScheduleViewMode('ROOM_FLOW')}
                        className={`px-3 py-1 rounded-full transition-all flex items-center gap-1.5 cursor-pointer ${
                          scheduleViewMode === 'ROOM_FLOW'
                            ? 'bg-emerald-900 text-emerald-50 shadow-2xs font-bold'
                            : 'text-stone-700 hover:bg-stone-200/60 hover:text-stone-950'
                        }`}
                      >
                        <Building2 className="w-3.5 h-3.5 text-emerald-300" />
                        <span>Room Grid</span>
                      </button>

                      <button
                        onClick={() => setScheduleViewMode('BOTTLENECKS')}
                        className={`px-3 py-1 rounded-full transition-all flex items-center gap-1.5 cursor-pointer ${
                          scheduleViewMode === 'BOTTLENECKS'
                            ? 'bg-amber-600 text-white shadow-2xs font-bold'
                            : 'text-stone-700 hover:bg-stone-200/60 hover:text-stone-950'
                        }`}
                      >
                        <AlertTriangle className="w-3.5 h-3.5" />
                        <span>Bottlenecks</span>
                      </button>

                      <button
                        onClick={() => setScheduleViewMode('PIPELINE')}
                        className={`px-3 py-1 rounded-full transition-all flex items-center gap-1.5 cursor-pointer ${
                          scheduleViewMode === 'PIPELINE'
                            ? 'bg-emerald-900 text-emerald-50 shadow-2xs font-bold'
                            : 'text-stone-700 hover:bg-stone-200/60 hover:text-stone-950'
                        }`}
                      >
                        <Layers className="w-3.5 h-3.5 text-emerald-300" />
                        <span>Pipeline</span>
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              {/* Home Dashboard Main Grid */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
                
                {/* Left Column: 2/3 of page (8 cols) */}
                <div className="lg:col-span-8 space-y-6">
                  {/* Today's Surgical Schedule */}
                  <ScheduleIntelligenceBox
                    cases={displayedCases}
                    viewMode={scheduleViewMode}
                    onViewModeChange={setScheduleViewMode}
                    onSelectPatient={handleOpenPatientChart}
                    onUpdateStage={handleUpdateStage}
                    onResolveAction={handleResolveAction}
                    onTriggerEKGFastTrack={handleTriggerEKGFastTrack}
                  />

                  {/* Communication & Waiting For Stats */}
                  <CommunicationWidget
                    stats={stats}
                    onSelectCategory={(cat) => showToast(`Filtering communication records for ${cat}...`)}
                  />
                </div>

                {/* Right Column: 1/3 of page (4 cols) */}
                <div className="lg:col-span-4 space-y-6">
                  {/* Nightingale AI Morning Brief */}
                  <NightingaleBriefBanner
                    cases={activeDateCases}
                    onActionClick={() => handleTriggerEKGFastTrack('case-2')}
                    onFilterNeedsAttention={() => setSearchQuery('DePoli')}
                  />

                  {/* Tasks Widget */}
                  <TasksWidget
                    tasks={tasks}
                    onToggleTask={handleToggleTask}
                  />
                </div>

              </div>
            </div>
          )}

          {/* TAB 1.5: AI OPERATIONS HOME */}
          {activeTab === 'ai-home' && (
            <AIHomePage
              cases={activeDateCases}
              onSelectPatient={handleOpenPatientChart}
              onTriggerEKGFastTrack={handleTriggerEKGFastTrack}
              onUpdateStage={handleUpdateStage}
              onShowToast={showToast}
              onNavigateTab={(tab) => setActiveTab(tab)}
            />
          )}

          {/* TAB 2: FULL SCHEDULE MATRIX VIEW */}
          {activeTab === 'schedule' && (
            <ScheduleFullView
              cases={activeDateCases}
              onSelectPatient={handleOpenPatientChart}
            />
          )}

          {/* TAB 3: BLANK PAGE TEMPLATE */}
          {activeTab === 'template' && (
            <BlankPageTemplate />
          )}

          {/* TAB 4: PATIENT CHARTS */}
          {activeTab === 'patients' && (
            <PatientChartPage
              cases={activeDateCases}
              initialSelectedPatientId={selectedChartPatientId}
              onOpenPatientModal={(patient) => setSelectedPatient(patient)}
            />
          )}

          {/* TAB 5: ADMINISTRATION */}
          {activeTab === 'admin' && (
            <AdministrationPage onShowToast={showToast} />
          )}

          {/* TAB 6: BILLING & INVOICES */}
          {activeTab === 'billing' && (
            <BillingModulePage
              cases={activeDateCases}
              onShowToast={showToast}
            />
          )}

          {/* TAB 7: AI WORKFLOW INTELLIGENCE SUITE */}
          {activeTab === 'workflows' && (
            <AIWorkflowExamples
              cases={activeDateCases}
              onSelectPatient={(patientId) => {
                setSelectedChartPatientId(patientId);
                setActiveTab('patients');
              }}
              onRunWorkflow={(workflowId) => {
                if (workflowId === 'wf-ekg-fasttrack') {
                  handleTriggerEKGFastTrack('case-2');
                }
              }}
              onShowToast={showToast}
            />
          )}

        </main>
      </div>

      {/* Patient Detail Modal */}
      <PatientDetailModal
        patient={selectedPatient}
        onClose={() => setSelectedPatient(null)}
        onUpdateStage={handleUpdateStage}
        onToggleAction={handleResolveAction}
        onTriggerEKGFastTrack={handleTriggerEKGFastTrack}
        onOpenChart={handleOpenPatientChart}
      />

      {/* Nightingale AI Chat Drawer */}
      <NightingaleAIChatDrawer
        isOpen={isAIChatOpen}
        onClose={() => setIsAIChatOpen(false)}
        scheduleCases={activeDateCases}
      />

      {/* Add New Patient Record Modal */}
      <AddPatientModal
        isOpen={isAddPatientModalOpen}
        onClose={() => setIsAddPatientModalOpen(false)}
        onAddPatient={(newPatient) => {
          updateActiveCases((prev) => [newPatient, ...prev]);
          setSelectedChartPatientId(newPatient.id);
          setActiveTab('patients');
          showToast(`Created patient record for ${newPatient.name}!`);
        }}
      />

    </div>
  );
}
