import { PatientCase } from '../types';
import { initialPatientCases } from '../data/mockData';
import { 
  generateSampleDriverLicense, 
  generateSampleInsuranceFront, 
  generateSampleInsuranceBack 
} from './cardTemplates';

export function getCasesForDateKey(dateKey: string, dateStr: string): PatientCase[] {
  // dateKey format: '2026-07-13'
  if (dateKey === '2026-07-13') {
    return initialPatientCases;
  }

  if (dateKey === '2026-07-12') {
    return [
      {
        id: 'case-sun-1',
        patientId: '113490',
        name: 'Eleanor Vance',
        age: 48,
        gender: 'Female',
        dob: '04/12/1978',
        phone: '(310) 555-0192',
        scheduledTime: '08:00 AM',
        estimatedDurationMins: 90,
        room: 'OR 1',
        surgeon: 'Stuart Linder, MD',
        anesthesiologist: 'David Chen, MD',
        procedure: 'Bilateral Augmentation & Pre-Op Clearance Review',
        aiSummary: 'Pre-operative clearance completed during Sunday morning review. All vitals and consent packets verified.',
        readinessScore: 96,
        readinessLevel: 'CLEARED',
        allergies: ['Penicillin'],
        labs: [
          { name: 'CBC', value: '13.1 g/dL', status: 'normal' },
          { name: 'BMP', value: 'Normal', status: 'normal' },
        ],
        stage: 'CHECK_IN',
        arrivalStatus: 'ARRIVED',
        arrivalTime: '7:30 AM',
        bottlenecks: [],
        actionItems: [
          { id: 'act-sun-1', text: 'Pre-op clearance confirmation', type: 'CONSENT', done: true },
        ],
        notes: `Scheduled for Sunday ${dateStr}. Pre-op clearance on file.`,
        idCardUrl: generateSampleDriverLicense('ELEANOR VANCE', '04/12/1978', 'E9102934', '120 S BEVERLY DR, BEVERLY HILLS, CA'),
        insuranceCardFrontUrl: generateSampleInsuranceFront('ELEANOR VANCE', 'Aetna PPO', 'AET-991201', 'GRP-102'),
        insuranceCardBackUrl: generateSampleInsuranceBack('Aetna PPO', '1-800-228-6200')
      },
      {
        id: 'case-sun-2',
        patientId: '113561',
        name: 'Sarah Wilson',
        age: 54,
        gender: 'Female',
        dob: '02/11/1972',
        phone: '(310) 829-4011',
        scheduledTime: '10:00 AM',
        estimatedDurationMins: 60,
        room: 'Consult Bay 2',
        surgeon: 'Stuart Linder, MD',
        anesthesiologist: 'David Chen, MD',
        procedure: 'Implant Revision Pre-op Consult & Sizing',
        aiSummary: 'Sunday pre-op consult and implant template sizing session.',
        readinessScore: 100,
        readinessLevel: 'CLEARED',
        allergies: ['Penicillin'],
        labs: [
          { name: 'CBC', value: '13.4 g/dL', status: 'normal' },
        ],
        stage: 'CHECK_IN',
        arrivalStatus: 'ARRIVED',
        arrivalTime: '9:45 AM',
        bottlenecks: [],
        actionItems: [],
        notes: `Sunday pre-op sizing consult completed.`,
        idCardUrl: generateSampleDriverLicense('SARAH WILSON', '02/11/1972', 'C8910245', '435 N BEDFORD DR, BEVERLY HILLS, CA'),
        insuranceCardFrontUrl: generateSampleInsuranceFront('SARAH WILSON', 'Blue Shield', 'XEN98127340', 'GRP-88120'),
        insuranceCardBackUrl: generateSampleInsuranceBack('Blue Shield', '1-800-555-0199')
      }
    ];
  }

  if (dateKey === '2026-07-14') {
    return [
      {
        id: 'case-tue-1',
        patientId: '114099',
        name: 'Jacqueline Geller',
        age: 42,
        gender: 'Female',
        dob: '09/18/1983',
        phone: '(310) 555-3344',
        scheduledTime: '08:00 AM',
        estimatedDurationMins: 150,
        room: 'OR 1',
        surgeon: 'Stuart Linder, MD',
        anesthesiologist: 'David Chen, MD',
        procedure: 'Primary Breast Augmentation with Smooth Gel Implants',
        aiSummary: 'All pre-operative labs and cardiac risk clearance verified for Tuesday morning start in OR 1.',
        readinessScore: 96,
        readinessLevel: 'CLEARED',
        allergies: ['None known'],
        labs: [
          { name: 'CBC', value: '13.6 g/dL', status: 'normal' },
          { name: 'BMP', value: 'Normal', status: 'normal' },
          { name: 'PT/INR', value: '1.0', status: 'normal' }
        ],
        stage: 'CHECK_IN',
        arrivalStatus: 'ARRIVED',
        arrivalTime: '7:15 AM',
        bottlenecks: [],
        actionItems: [
          { id: 'act-tue-1', text: 'Verify Mentor gel implant lot numbers in OR 1', type: 'IMPLANT', done: false, urgent: true },
          { id: 'act-tue-2', text: 'Obtain digital consent signature for photography', type: 'CONSENT', done: true }
        ],
        notes: `Scheduled for Tuesday ${dateStr}. All pre-op labs clear.`,
        idCardUrl: generateSampleDriverLicense('JACQUELINE GELLER', '09/18/1983', 'J8819203', '710 RODEO DR, BEVERLY HILLS, CA'),
        insuranceCardFrontUrl: generateSampleInsuranceFront('JACQUELINE GELLER', 'Cigna PPO', 'CG-771920', 'GRP-[#881]'),
        insuranceCardBackUrl: generateSampleInsuranceBack('Cigna PPO', '1-800-244-6224')
      },
      {
        id: 'case-tue-2',
        patientId: '114102',
        name: 'Chloe Bennett',
        age: 38,
        gender: 'Female',
        dob: '03/24/1988',
        phone: '(310) 555-9988',
        scheduledTime: '09:30 AM',
        estimatedDurationMins: 120,
        room: 'OR 2',
        surgeon: 'Guy Massry, MD',
        anesthesiologist: 'Evelyn Vance, MD',
        procedure: 'Revision Rhinoplasty & Septal Cartilage Graft',
        aiSummary: 'Patient cleared for surgery. Pre-op facial photographs completed. Anesthesia consult complete.',
        readinessScore: 92,
        readinessLevel: 'CLEARED',
        allergies: ['Sulfa'],
        labs: [
          { name: 'CBC', value: '12.9 g/dL', status: 'normal' },
          { name: 'BMP', value: 'Normal', status: 'normal' }
        ],
        stage: 'PRE_OP',
        preOpBay: 'Bay 2',
        arrivalStatus: 'ARRIVED',
        arrivalTime: '8:30 AM',
        bottlenecks: [],
        actionItems: [
          { id: 'act-tue-3', text: 'Confirm nasal splint and packing supplies in OR 2', type: 'IMPLANT', done: true }
        ],
        notes: `Scheduled for Tuesday ${dateStr}. In Pre-Op Bay 2.`,
        idCardUrl: generateSampleDriverLicense('CHLOE BENNETT', '03/24/1988', 'C9018234', '150 WILSHIRE BLVD, LOS ANGELES, CA'),
        insuranceCardFrontUrl: generateSampleInsuranceFront('CHLOE BENNETT', 'UnitedHealthcare', 'UHC-881920', 'GRP-[#552]'),
        insuranceCardBackUrl: generateSampleInsuranceBack('UnitedHealthcare', '1-877-842-3210')
      },
      {
        id: 'case-tue-3',
        patientId: '114110',
        name: 'Marcus Brody',
        age: 45,
        gender: 'Male',
        dob: '11/05/1980',
        phone: '(310) 555-4422',
        scheduledTime: '01:00 PM',
        estimatedDurationMins: 90,
        room: 'OR 1',
        surgeon: 'Dr. Richard Zoumalan',
        anesthesiologist: 'David Chen, MD',
        procedure: 'Septoplasty & Inferior Turbinate Reduction',
        aiSummary: 'Afternoon case scheduled. Pre-op CT sinus scan on file.',
        readinessScore: 98,
        readinessLevel: 'CLEARED',
        allergies: ['None known'],
        labs: [
          { name: 'CBC', value: '14.2 g/dL', status: 'normal' },
          { name: 'PT/INR', value: '1.0', status: 'normal' }
        ],
        stage: 'EN_ROUTE',
        arrivalStatus: 'EN_ROUTE',
        arrivalTime: 'Est. 12:15 PM',
        bottlenecks: [],
        actionItems: [
          { id: 'act-tue-4', text: 'Verify CT Sinus scan loaded on OR 1 navigation monitor', type: 'CONSENT', done: true }
        ],
        notes: `Scheduled for Tuesday ${dateStr}.`,
        idCardUrl: generateSampleDriverLicense('MARCUS BRODY', '11/05/1980', 'M4410293', '300 N CANON DR, BEVERLY HILLS, CA'),
        insuranceCardFrontUrl: generateSampleInsuranceFront('MARCUS BRODY', 'Anthem Blue Cross', 'ANT-551029', 'GRP-[#301]'),
        insuranceCardBackUrl: generateSampleInsuranceBack('Anthem Blue Cross', '1-800-627-0022')
      }
    ];
  }

  if (dateKey === '2026-07-15') {
    return [
      {
        id: 'case-wed-1',
        patientId: '114115',
        name: 'Livia Rodrigues',
        age: 43,
        gender: 'Female',
        dob: '07/22/1983',
        phone: '(310) 555-9104',
        scheduledTime: '08:00 AM',
        estimatedDurationMins: 270,
        room: 'OR 1',
        surgeon: 'Richard Zoumbalakis, MD',
        anesthesiologist: 'David Chen, MD',
        procedure: 'Complex Revision Rhinoplasty & Ear Cartilage Harvest',
        aiSummary: 'Ear cartilage harvest consent signed and verified. All pre-op requirements complete.',
        readinessScore: 95,
        readinessLevel: 'CLEARED',
        allergies: ['Penicillin'],
        labs: [
          { name: 'CBC', value: '13.5 g/dL', status: 'normal' },
          { name: 'BMP', value: 'Normal', status: 'normal' }
        ],
        stage: 'CHECK_IN',
        arrivalStatus: 'ARRIVED',
        arrivalTime: '7:15 AM',
        bottlenecks: [],
        actionItems: [
          { id: 'act-wed-1', text: 'Verify ear cartilage harvest consent form', type: 'CONSENT', done: true }
        ],
        notes: `Scheduled for Wednesday ${dateStr}. Ear cartilage harvest consent signed.`,
        idCardUrl: generateSampleDriverLicense('LIVIA RODRIGUES', '07/22/1983', 'L7710293', '400 S BEVERLY DR, BEVERLY HILLS, CA'),
        insuranceCardFrontUrl: generateSampleInsuranceFront('LIVIA RODRIGUES', 'Aetna Choice', 'AET-331029', 'GRP-[#901]'),
        insuranceCardBackUrl: generateSampleInsuranceBack('Aetna Choice', '1-800-238-6200')
      },
      {
        id: 'case-wed-2',
        patientId: '114071',
        name: 'Karen Isralsky',
        age: 61,
        gender: 'Female',
        dob: '05/14/1965',
        phone: '(424) 555-2018',
        scheduledTime: '08:00 AM',
        estimatedDurationMins: 90,
        room: 'OR 2',
        surgeon: 'Guy Massry, MD',
        anesthesiologist: 'Sarah Jenkins, MD',
        procedure: 'Upper & Lower Eyelid Revision',
        aiSummary: 'Patient sensitivity to adhesive paper tape documented. Silicone tape prepared in OR 2.',
        readinessScore: 98,
        readinessLevel: 'CLEARED',
        allergies: ['Adhesive tape sensitivity'],
        labs: [
          { name: 'CBC', value: '12.8 g/dL', status: 'normal' }
        ],
        stage: 'PRE_OP',
        preOpBay: 'Bay 3',
        arrivalStatus: 'ARRIVED',
        arrivalTime: '7:30 AM',
        bottlenecks: [],
        actionItems: [
          { id: 'act-wed-2', text: 'Use silicone tape for eyelid dressings', type: 'IMPLANT', done: true }
        ],
        notes: `Scheduled for Wednesday ${dateStr}. Silicone tape flag noted.`,
        idCardUrl: generateSampleDriverLicense('KAREN ISRALSKY', '05/14/1965', 'K9018239', '120 MAPLE DR, BEVERLY HILLS, CA'),
        insuranceCardFrontUrl: generateSampleInsuranceFront('KAREN ISRALSKY', 'Blue Shield PPO', 'XEN-441029', 'GRP-[#771]'),
        insuranceCardBackUrl: generateSampleInsuranceBack('Blue Shield PPO', '1-800-555-0199')
      },
      {
        id: 'case-wed-3',
        patientId: '112954',
        name: 'Kimberly Israel',
        age: 36,
        gender: 'Female',
        dob: '10/10/1989',
        phone: '(310) 555-7733',
        scheduledTime: '09:00 AM',
        estimatedDurationMins: 150,
        room: 'OR 3',
        surgeon: 'Kimberly Lee, MD',
        anesthesiologist: 'Elena Rostova, MD',
        procedure: 'Primary Rhinoplasty & Alar Base Reduction',
        aiSummary: 'Pre-op photographs completed in clinical suite. Cleared for OR 3.',
        readinessScore: 100,
        readinessLevel: 'CLEARED',
        allergies: ['None known'],
        labs: [
          { name: 'CBC', value: '13.9 g/dL', status: 'normal' },
          { name: 'BMP', value: 'Normal', status: 'normal' }
        ],
        stage: 'CHECK_IN',
        arrivalStatus: 'ARRIVED',
        arrivalTime: '8:15 AM',
        bottlenecks: [],
        actionItems: [
          { id: 'act-wed-3', text: 'Pre-op photographic consent verified', type: 'PHOTO', done: true }
        ],
        notes: `Scheduled for Wednesday ${dateStr}.`,
        idCardUrl: generateSampleDriverLicense('KIMBERLY ISRAEL', '10/10/1989', 'K1102938', '500 N BEDFORD DR, BEVERLY HILLS, CA'),
        insuranceCardFrontUrl: generateSampleInsuranceFront('KIMBERLY ISRAEL', 'Cigna', 'CG-221092', 'GRP-[#401]'),
        insuranceCardBackUrl: generateSampleInsuranceBack('Cigna', '1-800-244-6224')
      },
      {
        id: 'case-wed-4',
        patientId: '114116',
        name: 'Imran Bari',
        age: 48,
        gender: 'Male',
        dob: '01/15/1978',
        phone: '(310) 555-4040',
        scheduledTime: '12:00 PM',
        estimatedDurationMins: 210,
        room: 'OR 1',
        surgeon: 'Richard Zoumbalakis, MD',
        anesthesiologist: 'Marcus Vance, MD',
        procedure: 'Septorhinoplasty & Endoscopic Sinus Surgery',
        aiSummary: 'ENT medical clearance attached to electronic chart. All pre-op orders active.',
        readinessScore: 94,
        readinessLevel: 'CLEARED',
        allergies: ['Codeine'],
        labs: [
          { name: 'CBC', value: '14.5 g/dL', status: 'normal' },
          { name: 'BMP', value: 'Normal', status: 'normal' }
        ],
        stage: 'EN_ROUTE',
        arrivalStatus: 'EN_ROUTE',
        arrivalTime: 'Est. 11:15 AM',
        bottlenecks: [],
        actionItems: [
          { id: 'act-wed-4', text: 'Confirm sinus micro-debrider handpiece in OR 1', type: 'IMPLANT', done: true }
        ],
        notes: `Scheduled for Wednesday ${dateStr}.`,
        idCardUrl: generateSampleDriverLicense('IMRAN BARI', '01/15/1978', 'I4490129', '600 SANTA MONICA BLVD, SANTA MONICA, CA'),
        insuranceCardFrontUrl: generateSampleInsuranceFront('IMRAN BARI', 'Medicare', 'MED-441092', 'GRP-[#110]'),
        insuranceCardBackUrl: generateSampleInsuranceBack('Medicare', '1-800-633-4227')
      }
    ];
  }

  if (dateKey === '2026-07-16') {
    return [
      {
        id: 'case-thu-1',
        patientId: '114117',
        name: 'Ahsan Khan',
        age: 39,
        gender: 'Male',
        dob: '11/11/1986',
        phone: '(310) 555-1234',
        scheduledTime: '08:00 AM',
        estimatedDurationMins: 270,
        room: 'OR 1',
        surgeon: 'Richard Zoumbalakis, MD',
        anesthesiologist: 'Marcus Vance, MD',
        procedure: 'Primary Rhinoplasty & Turbinoplasty',
        aiSummary: 'Pre-op ECG and chest x-ray cleared. Ready for Thursday start in OR 1.',
        readinessScore: 98,
        readinessLevel: 'CLEARED',
        allergies: ['None known'],
        labs: [
          { name: 'CBC', value: '14.8 g/dL', status: 'normal' },
          { name: 'EKG', value: 'Normal Sinus Rhythm', status: 'normal' }
        ],
        stage: 'CHECK_IN',
        arrivalStatus: 'ARRIVED',
        arrivalTime: '7:15 AM',
        bottlenecks: [],
        actionItems: [
          { id: 'act-thu-1', text: 'Verify pre-op photographic consent', type: 'PHOTO', done: true }
        ],
        notes: `Scheduled for Thursday ${dateStr}. Pre-op ECG cleared.`,
        idCardUrl: generateSampleDriverLicense('AHSAN KHAN', '11/11/1986', 'A8819023', '220 WILSHIRE BLVD, BEVERLY HILLS, CA'),
        insuranceCardFrontUrl: generateSampleInsuranceFront('AHSAN KHAN', 'Anthem Blue Cross', 'ANT-991029', 'GRP-[#220]'),
        insuranceCardBackUrl: generateSampleInsuranceBack('Anthem Blue Cross', '1-800-627-0022')
      },
      {
        id: 'case-thu-2',
        patientId: '113477',
        name: 'Christina Vingsbo',
        age: 47,
        gender: 'Female',
        dob: '02/14/1979',
        phone: '(310) 555-7890',
        scheduledTime: '08:00 AM',
        estimatedDurationMins: 270,
        room: 'OR 2',
        surgeon: 'Robert Rey, MD',
        anesthesiologist: 'David Chen, MD',
        procedure: 'Abdominal & Flank Liposuction, Removal and Replacement Bilateral Breast Implants',
        aiSummary: 'Garment sizing confirmed in pre-op. Medical clearance on file.',
        readinessScore: 94,
        readinessLevel: 'CLEARED',
        allergies: ['Latex'],
        labs: [
          { name: 'CBC', value: '13.0 g/dL', status: 'normal' },
          { name: 'BMP', value: 'Normal', status: 'normal' }
        ],
        stage: 'CHECK_IN',
        arrivalStatus: 'ARRIVED',
        arrivalTime: '7:30 AM',
        bottlenecks: [],
        actionItems: [
          { id: 'act-thu-2', text: 'Ensure latex-free supplies in OR 2', type: 'IMPLANT', done: true }
        ],
        notes: `Scheduled for Thursday ${dateStr}. Latex allergy noted.`,
        idCardUrl: generateSampleDriverLicense('CHRISTINA VINGSBO', '02/14/1979', 'C7710923', '800 RODEO DR, BEVERLY HILLS, CA'),
        insuranceCardFrontUrl: generateSampleInsuranceFront('CHRISTINA VINGSBO', 'Aetna PPO', 'AET-441029', 'GRP-[#880]'),
        insuranceCardBackUrl: generateSampleInsuranceBack('Aetna PPO', '1-800-238-6200')
      }
    ];
  }

  if (dateKey === '2026-07-17') {
    return [
      {
        id: 'case-fri-1',
        patientId: '114185',
        name: 'Nancy Correll',
        age: 52,
        gender: 'Female',
        dob: '06/06/1974',
        phone: '(310) 555-8765',
        scheduledTime: '07:00 AM',
        estimatedDurationMins: 300,
        room: 'OR 2',
        surgeon: 'Stuart Linder, MD',
        anesthesiologist: 'Marcus Vance, MD',
        procedure: 'Complex Breast Revision & Capsular Contracture Release',
        aiSummary: 'Smooth gel implants staged in OR 2. All pre-op labs clear for Friday start.',
        readinessScore: 96,
        readinessLevel: 'CLEARED',
        allergies: ['None known'],
        labs: [
          { name: 'CBC', value: '13.4 g/dL', status: 'normal' },
          { name: 'BMP', value: 'Normal', status: 'normal' }
        ],
        stage: 'CHECK_IN',
        arrivalStatus: 'ARRIVED',
        arrivalTime: '6:30 AM',
        bottlenecks: [],
        actionItems: [
          { id: 'act-fri-1', text: 'Verify capsular tissue pathology jar in OR 2', type: 'IMPLANT', done: true }
        ],
        notes: `Scheduled for Friday ${dateStr}. Smooth gel implants ready.`,
        idCardUrl: generateSampleDriverLicense('NANCY CORRELL', '06/06/1974', 'N9910293', '350 CANON DR, BEVERLY HILLS, CA'),
        insuranceCardFrontUrl: generateSampleInsuranceFront('NANCY CORRELL', 'Blue Shield', 'XEN-881029', 'GRP-[#350]'),
        insuranceCardBackUrl: generateSampleInsuranceBack('Blue Shield', '1-800-555-0199')
      },
      {
        id: 'case-fri-2',
        patientId: '113603',
        name: 'Jesse Sprong',
        age: 59,
        gender: 'Male',
        dob: '01/20/1967',
        phone: '(424) 555-5678',
        scheduledTime: '08:00 AM',
        estimatedDurationMins: 180,
        room: 'OR 1',
        surgeon: 'Guy Massry, MD',
        anesthesiologist: 'David Chen, MD',
        procedure: 'Bilateral Endoscopic Browlift & Bilateral Upper Blepharoplasty',
        aiSummary: 'Endoscopic camera tower requested in OR 1. Cleared for Friday morning.',
        readinessScore: 98,
        readinessLevel: 'CLEARED',
        allergies: ['Sulfa'],
        labs: [
          { name: 'CBC', value: '14.1 g/dL', status: 'normal' }
        ],
        stage: 'PRE_OP',
        preOpBay: 'Bay 1',
        arrivalStatus: 'ARRIVED',
        arrivalTime: '7:15 AM',
        bottlenecks: [],
        actionItems: [
          { id: 'act-fri-2', text: 'Confirm HD endoscopic monitor connection in OR 1', type: 'IMPLANT', done: true }
        ],
        notes: `Scheduled for Friday ${dateStr}.`,
        idCardUrl: generateSampleDriverLicense('JESSE SPRONG', '01/20/1967', 'J5510293', '900 WILSHIRE BLVD, LOS ANGELES, CA'),
        insuranceCardFrontUrl: generateSampleInsuranceFront('JESSE SPRONG', 'Cigna', 'CG-331029', 'GRP-[#900]'),
        insuranceCardBackUrl: generateSampleInsuranceBack('Cigna', '1-800-244-6224')
      },
      {
        id: 'case-fri-3',
        patientId: '98358',
        name: 'Frank Billauer',
        age: 62,
        gender: 'Male',
        dob: '09/09/1963',
        phone: '(310) 555-4321',
        scheduledTime: '08:00 AM',
        estimatedDurationMins: 150,
        room: 'OR 3',
        surgeon: 'Stuart Linder, MD',
        anesthesiologist: 'Sarah Jenkins, MD',
        procedure: 'Gynecomastia Revision & Chest Liposuction',
        aiSummary: 'Post-op compression vest in room. Medical clearance complete.',
        readinessScore: 92,
        readinessLevel: 'CLEARED',
        allergies: ['Penicillin'],
        labs: [
          { name: 'CBC', value: '13.7 g/dL', status: 'normal' }
        ],
        stage: 'CHECK_IN',
        arrivalStatus: 'ARRIVED',
        arrivalTime: '7:20 AM',
        bottlenecks: [],
        actionItems: [
          { id: 'act-fri-3', text: 'Verify chest compression garment size Medium', type: 'IMPLANT', done: true }
        ],
        notes: `Scheduled for Friday ${dateStr}.`,
        idCardUrl: generateSampleDriverLicense('FRANK BILLAUER', '09/09/1963', 'F4410293', '100 BEVERLY DR, BEVERLY HILLS, CA'),
        insuranceCardFrontUrl: generateSampleInsuranceFront('FRANK BILLAUER', 'Medicare', 'MED-110293', 'GRP-[#100]'),
        insuranceCardBackUrl: generateSampleInsuranceBack('Medicare', '1-800-633-4227')
      },
      {
        id: 'case-fri-4',
        patientId: '114068',
        name: 'Helen Danek',
        age: 66,
        gender: 'Female',
        dob: '12/12/1959',
        phone: '(310) 555-2468',
        scheduledTime: '11:00 AM',
        estimatedDurationMins: 120,
        room: 'OR 1',
        surgeon: 'Guy Massry, MD',
        anesthesiologist: 'Sarah Jenkins, MD',
        procedure: 'Lower Eyelid Blepharoplasty & Fat Repositioning',
        aiSummary: 'Pre-op ocular pressure check normal. Ready for late morning start.',
        readinessScore: 97,
        readinessLevel: 'CLEARED',
        allergies: ['None known'],
        labs: [
          { name: 'CBC', value: '12.6 g/dL', status: 'normal' }
        ],
        stage: 'EN_ROUTE',
        arrivalStatus: 'EN_ROUTE',
        arrivalTime: 'Est. 10:15 AM',
        bottlenecks: [],
        actionItems: [],
        notes: `Scheduled for Friday ${dateStr}.`,
        idCardUrl: generateSampleDriverLicense('HELEN DANEK', '12/12/1959', 'H8810293', '250 N CANON DR, BEVERLY HILLS, CA'),
        insuranceCardFrontUrl: generateSampleInsuranceFront('HELEN DANEK', 'UnitedHealthcare', 'UHC-771029', 'GRP-[#250]'),
        insuranceCardBackUrl: generateSampleInsuranceBack('UnitedHealthcare', '1-877-842-3210')
      }
    ];
  }

  if (dateKey === '2026-07-18') {
    return [
      {
        id: 'case-sat-1',
        patientId: 'BLOCK-02',
        name: 'OR Block Reservation - Dr. Suzanne Trott',
        age: 45,
        gender: 'Female',
        dob: 'N/A',
        phone: '(310) 555-9000',
        scheduledTime: '08:00 AM',
        estimatedDurationMins: 300,
        room: 'OR 3',
        surgeon: 'Suzanne Trott, MD',
        anesthesiologist: 'Assigned on arrival',
        procedure: 'OR Block Reserved - Dr. Suzanne Trott (Plastic Surgery)',
        aiSummary: 'OR 3 Saturday morning surgical block reserved for emergency plastic surgery and overflow procedures.',
        readinessScore: 100,
        readinessLevel: 'CLEARED',
        allergies: ['N/A'],
        labs: [],
        stage: 'CHECK_IN',
        arrivalStatus: 'ARRIVED',
        arrivalTime: '8:00 AM',
        bottlenecks: [],
        actionItems: [
          { id: 'act-sat-1', text: 'Confirm staff assignment for Saturday OR 3 block', type: 'CONSENT', done: true }
        ],
        notes: `Saturday ${dateStr} block reservation active.`,
        idCardUrl: generateSampleDriverLicense('DR. SUZANNE TROTT', '01/01/1980', 'ST901823', 'SUMMIT SURGICAL CENTER, BEVERLY HILLS, CA'),
        insuranceCardFrontUrl: generateSampleInsuranceFront('SUMMIT SURGICAL CENTER', 'Facility Reserve', 'FAC-00192', 'GRP-[#001]'),
        insuranceCardBackUrl: generateSampleInsuranceBack('Summit Surgical Center', '1-310-555-0100')
      }
    ];
  }

  // Dynamic fallback for any other date
  return [
    {
      id: `case-gen-1-${dateKey}`,
      patientId: '115201',
      name: 'Victoria Sterling',
      age: 44,
      gender: 'Female',
      dob: '03/15/1982',
      phone: '(310) 555-0144',
      scheduledTime: '08:00 AM',
      estimatedDurationMins: 120,
      room: 'OR 1',
      surgeon: 'Stuart Linder, MD',
      anesthesiologist: 'David Chen, MD',
      procedure: 'Bilateral Primary Breast Augmentation',
      aiSummary: `Scheduled surgical case for ${dateStr}. Complete pre-op medical clearance on file.`,
      readinessScore: 98,
      readinessLevel: 'CLEARED',
      allergies: ['Penicillin'],
      labs: [
        { name: 'CBC', value: '13.4 g/dL', status: 'normal' },
        { name: 'BMP', value: 'Normal', status: 'normal' }
      ],
      stage: 'CHECK_IN',
      arrivalStatus: 'ARRIVED',
      arrivalTime: '07:15 AM',
      bottlenecks: [],
      actionItems: [
        { id: `act-gen-1-${dateKey}`, text: 'Verify implant delivery & lot numbers', type: 'IMPLANT', done: true }
      ],
      notes: `Active schedule item for ${dateStr}.`,
      idCardUrl: generateSampleDriverLicense('VICTORIA STERLING', '03/15/1982', 'V8810293', '450 N BEDFORD DR, BEVERLY HILLS, CA'),
      insuranceCardFrontUrl: generateSampleInsuranceFront('VICTORIA STERLING', 'Aetna PPO', 'AET-102938', 'GRP-502'),
      insuranceCardBackUrl: generateSampleInsuranceBack('Aetna PPO', '1-800-238-6200')
    },
    {
      id: `case-gen-2-${dateKey}`,
      patientId: '115202',
      name: 'Julian Vance',
      age: 51,
      gender: 'Male',
      dob: '09/20/1974',
      phone: '(310) 555-0188',
      scheduledTime: '10:30 AM',
      estimatedDurationMins: 90,
      room: 'OR 2',
      surgeon: 'Guy Massry, MD',
      anesthesiologist: 'Evelyn Vance, MD',
      procedure: 'Bilateral Upper & Lower Blepharoplasty',
      aiSummary: `Scheduled procedure for ${dateStr} with Dr. Massry. Baseline photography completed.`,
      readinessScore: 96,
      readinessLevel: 'CLEARED',
      allergies: ['None known'],
      labs: [
        { name: 'CBC', value: '14.2 g/dL', status: 'normal' }
      ],
      stage: 'CHECK_IN',
      arrivalStatus: 'ARRIVED',
      arrivalTime: '09:45 AM',
      bottlenecks: [],
      actionItems: [],
      notes: `Active schedule item for ${dateStr}.`,
      idCardUrl: generateSampleDriverLicense('JULIAN VANCE', '09/20/1974', 'J1029384', '200 RODEO DR, BEVERLY HILLS, CA'),
      insuranceCardFrontUrl: generateSampleInsuranceFront('JULIAN VANCE', 'Blue Shield', 'XEN-901823', 'GRP-104'),
      insuranceCardBackUrl: generateSampleInsuranceBack('Blue Shield', '1-800-555-0199')
    },
    {
      id: `case-gen-3-${dateKey}`,
      patientId: '115203',
      name: 'Samantha Ross',
      age: 39,
      gender: 'Female',
      dob: '12/04/1986',
      phone: '(310) 555-0199',
      scheduledTime: '01:15 PM',
      estimatedDurationMins: 105,
      room: 'OR 1',
      surgeon: 'Dr. Richard Zoumalan',
      anesthesiologist: 'David Chen, MD',
      procedure: 'Open Septorhinoplasty with Turbinate Reduction',
      aiSummary: `Afternoon surgical case for ${dateStr}. ENT clearance attached.`,
      readinessScore: 95,
      readinessLevel: 'CLEARED',
      allergies: ['Latex'],
      labs: [
        { name: 'CBC', value: '13.0 g/dL', status: 'normal' },
        { name: 'BMP', value: 'Normal', status: 'normal' }
      ],
      stage: 'EN_ROUTE',
      arrivalStatus: 'EN_ROUTE',
      arrivalTime: 'Est. 12:30 PM',
      bottlenecks: [],
      actionItems: [],
      notes: `Active schedule item for ${dateStr}.`,
      idCardUrl: generateSampleDriverLicense('SAMANTHA ROSS', '12/04/1986', 'S9018273', '120 S BEVERLY DR, BEVERLY HILLS, CA'),
      insuranceCardFrontUrl: generateSampleInsuranceFront('SAMANTHA ROSS', 'Cigna', 'CG-881920', 'GRP-302'),
      insuranceCardBackUrl: generateSampleInsuranceBack('Cigna', '1-800-244-6224')
    }
  ];
}
