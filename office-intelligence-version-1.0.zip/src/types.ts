export type PatientStage = 
  | 'CHECK_IN' 
  | 'PRE_OP' 
  | 'IN_OR' 
  | 'PACU_RECOVERY' 
  | 'DISCHARGED' 
  | 'EN_ROUTE';

export type ReadinessLevel = 'CLEARED' | 'NEEDS_ATTENTION' | 'CRITICAL_HOLD' | 'IN_PROGRESS';

export const PAYMENT_TYPE_OPTIONS = [
  'Self-Pay',
  'Private Insurance',
  'Doctor-to-Pay',
  'Medicare',
  'Medicaid',
  "Worker's Compensation",
  'Attorney Lien',
  'TriCare / Military',
  'HMO / PPO Direct Contract',
  'Financial Assistance / Sliding Scale',
] as const;

export type PaymentTypeOption = typeof PAYMENT_TYPE_OPTIONS[number];

export interface LabResult {
  name: string;
  value: string;
  status: 'normal' | 'warning' | 'pending' | 'critical';
}

export interface PatientCase {
  id: string;
  patientId: string;
  name: string;
  age: number;
  gender: 'Female' | 'Male' | 'Other';
  dob?: string;
  phone: string;
  scheduledTime: string;
  estimatedDurationMins: number;
  room: 'OR 1' | 'OR 2' | 'OR 3' | 'Minor Proc Bay' | 'PACU Bay 1' | 'PACU Bay 2' | 'Consult Bay 2' | string;
  surgeon: string;
  anesthesiologist?: string;
  procedure: string;
  aiSummary: string;
  readinessScore: number; // 0 - 100
  readinessLevel: ReadinessLevel;
  allergies: string[];
  labs: LabResult[];
  stage: PatientStage;
  preOpBay?: string;
  pacuBay?: string;
  arrivalStatus: 'ARRIVED' | 'EN_ROUTE' | 'DELAYED' | 'CHECKED_IN';
  arrivalTime: string;
  bottlenecks: string[];
  actionItems: {
    id: string;
    text: string;
    type: 'EKG' | 'PHOTO' | 'ANESTHESIA' | 'IMPLANT' | 'CONSENT' | 'TRANSPORT';
    done: boolean;
    urgent?: boolean;
  }[];
  notes?: string;
  paymentType?: string;
  idCardUrl?: string;
  insuranceCardFrontUrl?: string;
  insuranceCardBackUrl?: string;
}

export interface BottleneckAlert {
  id: string;
  patientId: string;
  patientName: string;
  room: string;
  scheduledTime: string;
  severity: 'high' | 'medium' | 'low';
  title: string;
  impact: string;
  recommendation: string;
  aiConfidence: number;
  timeSensitivity: string;
}

export interface TaskItem {
  id: string;
  title: string;
  patientName?: string;
  patientId?: string;
  dueDate: 'Today' | 'This Week' | 'Next Week';
  priority: 'High' | 'Medium' | 'Low';
  category: 'Labs' | 'Clearance' | 'Implants' | 'Signoff' | 'Follow-up' | 'Vendor';
  completed: boolean;
  dueDateString?: string;
}

export interface CommunicationStats {
  insuranceApproval: number;
  labResults: number;
  implantShipment: number;
  physicianSignature: number;
  patientMessages: number;
  referrals: number;
  insuranceQueries: number;
  labNotifications: number;
}
