export interface NoteHtmlForm {
  id: string;
  order: number;
  title: string;
  subtitle: string;
  author: string;
  date: string;
  status: 'Signed & Cleared' | 'Pending Review' | 'Draft';
  category: string;
  fileName: string;
  summary: string;
  htmlTemplate: string;
}

export const INITIAL_NOTES_HTML_FORMS: NoteHtmlForm[] = [
  {
    id: 'note-hp',
    order: 1,
    title: 'History and Physical (H&P)',
    subtitle: 'Comprehensive Pre-Op Medical & Surgical Evaluation',
    author: 'Stuart Linder, MD',
    date: 'May 06, 2026',
    status: 'Signed & Cleared',
    category: 'History & Physical',
    fileName: 'History_and_Physical.html',
    summary: 'Comprehensive H&P examination covering Chief Complaint, HPI, PMH/PSH, Review of Systems, Physical Exam, Assessment, and Plan.',
    htmlTemplate: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Summit Surgical Center – History & Physical</title>
  <style>
    :root {
      --primary: #1a365d;
      --accent: #2b6cb0;
      --border: #cbd5e0;
      --bg: #f7fafc;
      --white: #ffffff;
      --text: #2d3748;
    }
    * { box-sizing: border-box; }
    body {
      font-family: Georgia, "Times New Roman", serif;
      line-height: 1.5;
      color: var(--text);
      background: var(--bg);
      margin: 0;
      padding: 0 0 50px;
    }
    .page {
      max-width: 860px;
      margin: 20px auto;
      background: var(--white);
      border: 1px solid var(--border);
      box-shadow: 0 4px 20px rgba(0,0,0,.08);
      padding: 32px 40px 44px;
    }
    header {
      text-align: center;
      border-bottom: 3px solid var(--primary);
      padding-bottom: 14px;
      margin-bottom: 22px;
    }
    header h1 { margin: 0 0 4px; font-size: 1.45rem; color: var(--primary); }
    header p { margin: 2px 0; font-size: .9rem; color: #4a5568; }
    h2 {
      font-size: 1.05rem;
      color: var(--primary);
      border-bottom: 2px solid var(--accent);
      padding-bottom: 4px;
      margin: 24px 0 12px;
      text-transform: uppercase;
      letter-spacing: .04em;
    }
    .sig-block {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 12px 20px;
      margin: 8px 0;
      align-items: end;
    }
    .sig-block.three { grid-template-columns: 1fr 1fr 1fr; }
    .sig-block.full { grid-template-columns: 1fr; }
    label {
      display: block;
      font-size: .78rem;
      font-weight: 600;
      color: #4a5568;
      margin-bottom: 2px;
    }
    input[type="text"], input[type="date"], input[type="time"], select, textarea {
      width: 100%;
      padding: 7px 10px;
      border: 1px solid var(--border);
      border-radius: 4px;
      font-size: .92rem;
      font-family: inherit;
      background: #fff;
    }
    input:focus, select:focus, textarea:focus {
      outline: 2px solid var(--accent);
      border-color: var(--accent);
    }
    textarea { resize: vertical; min-height: 56px; }
    .check-grid {
      display: grid;
      grid-template-columns: 1fr 1fr 1fr;
      gap: 3px 14px;
      margin: 6px 0 10px;
    }
    .checkbox-row {
      display: flex;
      align-items: flex-start;
      gap: 6px;
      margin: 3px 0;
    }
    .checkbox-row input { width: 15px; height: 15px; margin-top: 2px; flex-shrink: 0; }
    .checkbox-row label { font-weight: normal; font-size: .88rem; margin: 0; }
    .notice {
      background: #edf2f7;
      border-left: 4px solid var(--accent);
      padding: 8px 12px;
      margin: 10px 0;
      font-size: .88rem;
    }
    .btn-row { text-align: center; margin-top: 28px; }
    button {
      background: var(--primary);
      color: white;
      border: none;
      padding: 12px 28px;
      font-size: .95rem;
      border-radius: 6px;
      cursor: pointer;
      font-family: inherit;
    }
    button:hover { background: #2c5282; }
    button.secondary { background: #718096; margin-left: 8px; }
    .footer-info {
      text-align: center;
      font-size: .75rem;
      color: #718096;
      margin-top: 28px;
      padding-top: 12px;
      border-top: 1px solid var(--border);
    }
    @media print {
      body { background: white; }
      .page { box-shadow: none; border: none; margin: 0; padding: 12px; }
      button { display: none; }
      input, select, textarea { border: none; border-bottom: 1px solid #999; border-radius: 0; }
    }
    @media (max-width: 640px) {
      .page { padding: 18px 14px; margin: 8px; }
      .sig-block, .sig-block.three, .check-grid { grid-template-columns: 1fr; }
    }
  </style>
</head>
<body>
  <form id="hpForm" onsubmit="return handleSubmit(event)">
    <div class="page">
      <header>
        <h1>HISTORY AND PHYSICAL</h1>
      </header>

      <div class="sig-block three">
        <div>
          <label for="patientName">Patient Name *</label>
          <input type="text" id="patientName" name="patientName" required>
        </div>
        <div>
          <label for="dob">DOB *</label>
          <input type="date" id="dob" name="dob" required>
        </div>
        <div>
          <label for="mrn">MRN / Account #</label>
          <input type="text" id="mrn" name="mrn">
        </div>
        <div>
          <label for="dos">Date of Service *</label>
          <input type="date" id="dos" name="dos" required>
        </div>
        <div>
          <label for="surgeon">Surgeon / Attending</label>
          <input type="text" id="surgeon" name="surgeon">
        </div>
        <div>
          <label for="procedure">Proposed Procedure</label>
          <input type="text" id="procedure" name="procedure">
        </div>
      </div>

      <h2>Chief Complaint</h2>
      <div class="sig-block full">
        <div>
          <label for="cc">Chief Complaint</label>
          <input type="text" id="cc" name="cc" placeholder="Primary reason for visit / surgery">
        </div>
      </div>

      <h2>History of Present Illness</h2>
      <div class="sig-block full">
        <div>
          <label for="hpi">HPI</label>
          <textarea id="hpi" name="hpi" rows="5" placeholder="Onset, location, duration, character, aggravating/alleviating factors, radiation, timing, severity, associated symptoms..."></textarea>
        </div>
      </div>

      <h2>Past Medical / Surgical History (Summary)</h2>
      <div class="notice">Refer to full Medical History form for complete details. Summarize pertinent positives here.</div>
      <div class="sig-block full">
        <div>
          <label for="pmh">Pertinent PMH / PSH</label>
          <textarea id="pmh" name="pmh" rows="3"></textarea>
        </div>
      </div>
      <div class="sig-block">
        <div>
          <label for="meds">Current Medications (summary)</label>
          <textarea id="meds" name="meds" rows="2"></textarea>
        </div>
        <div>
          <label for="allergies">Allergies</label>
          <textarea id="allergies" name="allergies" rows="2"></textarea>
        </div>
      </div>

      <h2>Review of Systems</h2>
      <div class="check-grid">
        <div class="checkbox-row"><input type="checkbox" name="ros" value="Constitutional" id="ros1"><label for="ros1">Constitutional (fever, weight)</label></div>
        <div class="checkbox-row"><input type="checkbox" name="ros" value="Eyes" id="ros2"><label for="ros2">Eyes</label></div>
        <div class="checkbox-row"><input type="checkbox" name="ros" value="ENMT" id="ros3"><label for="ros3">ENMT</label></div>
        <div class="checkbox-row"><input type="checkbox" name="ros" value="Cardiovascular" id="ros4"><label for="ros4">Cardiovascular</label></div>
        <div class="checkbox-row"><input type="checkbox" name="ros" value="Respiratory" id="ros5"><label for="ros5">Respiratory</label></div>
        <div class="checkbox-row"><input type="checkbox" name="ros" value="GI" id="ros6"><label for="ros6">Gastrointestinal</label></div>
        <div class="checkbox-row"><input type="checkbox" name="ros" value="GU" id="ros7"><label for="ros7">Genitourinary</label></div>
        <div class="checkbox-row"><input type="checkbox" name="ros" value="Musculoskeletal" id="ros8"><label for="ros8">Musculoskeletal</label></div>
        <div class="checkbox-row"><input type="checkbox" name="ros" value="Skin" id="ros9"><label for="ros9">Skin / Breast</label></div>
        <div class="checkbox-row"><input type="checkbox" name="ros" value="Neuro" id="ros10"><label for="ros10">Neurologic</label></div>
        <div class="checkbox-row"><input type="checkbox" name="ros" value="Psych" id="ros11"><label for="ros11">Psychiatric</label></div>
        <div class="checkbox-row"><input type="checkbox" name="ros" value="Endocrine" id="ros12"><label for="ros12">Endocrine</label></div>
        <div class="checkbox-row"><input type="checkbox" name="ros" value="Heme" id="ros13"><label for="ros13">Hematologic / Lymphatic</label></div>
        <div class="checkbox-row"><input type="checkbox" name="ros" value="Allergic" id="ros14"><label for="ros14">Allergic / Immunologic</label></div>
        <div class="checkbox-row"><input type="checkbox" name="ros" value="All negative" id="ros15"><label for="ros15">All systems negative except as noted in HPI</label></div>
      </div>
      <div class="sig-block full">
        <div>
          <label for="rosDetails">ROS Details / Positives</label>
          <textarea id="rosDetails" name="rosDetails" rows="2"></textarea>
        </div>
      </div>

      <h2>Physical Examination</h2>
      <div class="sig-block three">
        <div>
          <label for="vs_bp">BP</label>
          <input type="text" id="vs_bp" name="vs_bp" placeholder="mmHg">
        </div>
        <div>
          <label for="vs_hr">HR</label>
          <input type="text" id="vs_hr" name="vs_hr" placeholder="bpm">
        </div>
        <div>
          <label for="vs_rr">RR</label>
          <input type="text" id="vs_rr" name="vs_rr">
        </div>
        <div>
          <label for="vs_temp">Temp</label>
          <input type="text" id="vs_temp" name="vs_temp">
        </div>
        <div>
          <label for="vs_spo2">SpO₂</label>
          <input type="text" id="vs_spo2" name="vs_spo2" placeholder="%">
        </div>
        <div>
          <label for="vs_wt">Weight</label>
          <input type="text" id="vs_wt" name="vs_wt">
        </div>
      </div>
      <div class="sig-block full">
        <div>
          <label for="pe_general">General</label>
          <input type="text" id="pe_general" name="pe_general" placeholder="WD/WN, NAD, etc.">
        </div>
      </div>
      <div class="sig-block">
        <div>
          <label for="pe_heent">HEENT</label>
          <textarea id="pe_heent" name="pe_heent" rows="2"></textarea>
        </div>
        <div>
          <label for="pe_neck">Neck</label>
          <textarea id="pe_neck" name="pe_neck" rows="2"></textarea>
        </div>
        <div>
          <label for="pe_cv">Cardiovascular</label>
          <textarea id="pe_cv" name="pe_cv" rows="2"></textarea>
        </div>
        <div>
          <label for="pe_resp">Respiratory</label>
          <textarea id="pe_resp" name="pe_resp" rows="2"></textarea>
        </div>
        <div>
          <label for="pe_abd">Abdomen</label>
          <textarea id="pe_abd" name="pe_abd" rows="2"></textarea>
        </div>
        <div>
          <label for="pe_ext">Extremities</label>
          <textarea id="pe_ext" name="pe_ext" rows="2"></textarea>
        </div>
        <div>
          <label for="pe_neuro">Neurologic</label>
          <textarea id="pe_neuro" name="pe_neuro" rows="2"></textarea>
        </div>
        <div>
          <label for="pe_skin">Skin</label>
          <textarea id="pe_skin" name="pe_skin" rows="2"></textarea>
        </div>
      </div>
      <div class="sig-block full">
        <div>
          <label for="pe_other">Other / Focused Exam</label>
          <textarea id="pe_other" name="pe_other" rows="2"></textarea>
        </div>
      </div>

      <h2>Assessment</h2>
      <div class="sig-block full">
        <div>
          <label for="assessment">Assessment / Diagnoses</label>
          <textarea id="assessment" name="assessment" rows="3" placeholder="1. ... 2. ..."></textarea>
        </div>
      </div>

      <h2>Plan</h2>
      <div class="sig-block full">
        <div>
          <label for="plan">Plan</label>
          <textarea id="plan" name="plan" rows="4" placeholder="Pre-op clearance, labs, consults, procedure plan, follow-up..."></textarea>
        </div>
      </div>

      <div class="notice">
        I have personally performed and documented this history and physical examination. The patient is cleared / not cleared for the proposed procedure as indicated in the Plan.
      </div>
      <div class="sig-block">
        <div>
          <label for="provName">Provider Name / Signature *</label>
          <input type="text" id="provName" name="provName" required>
        </div>
        <div>
          <label for="provCred">Credentials</label>
          <input type="text" id="provCred" name="provCred" placeholder="MD, DO, NP, PA">
        </div>
        <div>
          <label for="provDate">Date *</label>
          <input type="date" id="provDate" name="provDate" required>
        </div>
        <div>
          <label for="provTime">Time</label>
          <input type="time" id="provTime" name="provTime">
        </div>
      </div>

      <div class="btn-row">
        <button type="submit">Submit</button>
        <button type="button" class="secondary" onclick="window.print()">Print</button>
      </div>
      <div class="footer-info">
      <h3>Powered by Office Intelligence</h3>
      </div>
    </div>
  </form>
  <script>
    function handleSubmit(e) {
      e.preventDefault();
      console.log('H&P submitted', Object.fromEntries(new FormData(e.target)));
      alert('History & Physical submitted (demo).');
      return false;
    }
  </script>
</body>
</html>`
  },
  {
    id: 'note-soap',
    order: 2,
    title: 'SOAP Note',
    subtitle: 'Subjective, Objective, Assessment, and Plan Clinical Documentation',
    author: 'Richard Zoumalan, MD',
    date: 'May 06, 2026',
    status: 'Signed & Cleared',
    category: 'SOAP Note',
    fileName: 'SOAP_Note.html',
    summary: 'Standard clinical SOAP note capturing patient-reported history, objective vitals and exam data, assessment, and care plan.',
    htmlTemplate: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Summit Surgical Center – SOAP Note</title>
  <style>
    :root {
      --primary: #1a365d;
      --accent: #2b6cb0;
      --border: #cbd5e0;
      --bg: #f7fafc;
      --white: #ffffff;
      --text: #2d3748;
    }
    * { box-sizing: border-box; }
    body {
      font-family: Georgia, "Times New Roman", serif;
      line-height: 1.5;
      color: var(--text);
      background: var(--bg);
      margin: 0;
      padding: 0 0 50px;
    }
    .page {
      max-width: 860px;
      margin: 20px auto;
      background: var(--white);
      border: 1px solid var(--border);
      box-shadow: 0 4px 20px rgba(0,0,0,.08);
      padding: 32px 40px 44px;
    }
    header {
      text-align: center;
      border-bottom: 3px solid var(--primary);
      padding-bottom: 14px;
      margin-bottom: 22px;
    }
    header h1 { margin: 0 0 4px; font-size: 1.45rem; color: var(--primary); }
    header p { margin: 2px 0; font-size: .9rem; color: #4a5568; }
    h2 {
      font-size: 1.05rem;
      color: var(--primary);
      border-bottom: 2px solid var(--accent);
      padding-bottom: 4px;
      margin: 22px 0 10px;
      text-transform: uppercase;
      letter-spacing: .04em;
    }
    .sig-block {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 12px 20px;
      margin: 8px 0;
      align-items: end;
    }
    .sig-block.three { grid-template-columns: 1fr 1fr 1fr; }
    .sig-block.full { grid-template-columns: 1fr; }
    label {
      display: block;
      font-size: .78rem;
      font-weight: 600;
      color: #4a5568;
      margin-bottom: 2px;
    }
    input[type="text"], input[type="date"], input[type="time"], textarea {
      width: 100%;
      padding: 7px 10px;
      border: 1px solid var(--border);
      border-radius: 4px;
      font-size: .92rem;
      font-family: inherit;
      background: #fff;
    }
    input:focus, textarea:focus {
      outline: 2px solid var(--accent);
      border-color: var(--accent);
    }
    textarea { resize: vertical; min-height: 70px; }
    .soap-letter {
      display: inline-block;
      width: 28px;
      height: 28px;
      line-height: 28px;
      text-align: center;
      background: var(--primary);
      color: white;
      font-weight: 700;
      border-radius: 4px;
      margin-right: 8px;
      font-size: .95rem;
    }
    .btn-row { text-align: center; margin-top: 28px; }
    button {
      background: var(--primary);
      color: white;
      border: none;
      padding: 12px 28px;
      font-size: .95rem;
      border-radius: 6px;
      cursor: pointer;
      font-family: inherit;
    }
    button:hover { background: #2c5282; }
    button.secondary { background: #718096; margin-left: 8px; }
    .footer-info {
      text-align: center;
      font-size: .75rem;
      color: #718096;
      margin-top: 28px;
      padding-top: 12px;
      border-top: 1px solid var(--border);
    }
    @media print {
      body { background: white; }
      .page { box-shadow: none; border: none; margin: 0; padding: 12px; }
      button { display: none; }
      input, textarea { border: none; border-bottom: 1px solid #999; border-radius: 0; }
    }
    @media (max-width: 640px) {
      .page { padding: 18px 14px; margin: 8px; }
      .sig-block, .sig-block.three { grid-template-columns: 1fr; }
    }
  </style>
</head>
<body>
  <form id="soapForm" onsubmit="return handleSubmit(event)">
    <div class="page">
      <header>
        <h1>SOAP NOTE</h1>
      </header>

      <div class="sig-block three">
        <div>
          <label for="patientName">Patient Name *</label>
          <input type="text" id="patientName" name="patientName" required>
        </div>
        <div>
          <label for="dob">DOB *</label>
          <input type="date" id="dob" name="dob" required>
        </div>
        <div>
          <label for="mrn">MRN</label>
          <input type="text" id="mrn" name="mrn">
        </div>
        <div>
          <label for="noteDate">Date *</label>
          <input type="date" id="noteDate" name="noteDate" required>
        </div>
        <div>
          <label for="noteTime">Time</label>
          <input type="time" id="noteTime" name="noteTime">
        </div>
        <div>
          <label for="provider">Provider</label>
          <input type="text" id="provider" name="provider">
        </div>
      </div>

      <h2><span class="soap-letter">S</span> Subjective</h2>
      <div class="sig-block full">
        <div>
          <label for="subjective">Patient-reported history, symptoms, concerns, interval events</label>
          <textarea id="subjective" name="subjective" rows="5" placeholder="CC, HPI elements, patient statements, pain score, interval history..."></textarea>
        </div>
      </div>

      <h2><span class="soap-letter">O</span> Objective</h2>
      <div class="sig-block three">
        <div>
          <label for="bp">BP</label>
          <input type="text" id="bp" name="bp">
        </div>
        <div>
          <label for="hr">HR</label>
          <input type="text" id="hr" name="hr">
        </div>
        <div>
          <label for="temp">Temp</label>
          <input type="text" id="temp" name="temp">
        </div>
        <div>
          <label for="rr">RR</label>
          <input type="text" id="rr" name="rr">
        </div>
        <div>
          <label for="spo2">SpO₂</label>
          <input type="text" id="spo2" name="spo2">
        </div>
        <div>
          <label for="pain">Pain (0–10)</label>
          <input type="text" id="pain" name="pain">
        </div>
      </div>
      <div class="sig-block full">
        <div>
          <label for="objective">Exam findings, vitals narrative, labs, imaging, other data</label>
          <textarea id="objective" name="objective" rows="5" placeholder="Focused exam, wound check, drainage, neurovascular status, lab/imaging results..."></textarea>
        </div>
      </div>

      <h2><span class="soap-letter">A</span> Assessment</h2>
      <div class="sig-block full">
        <div>
          <label for="assessment">Clinical impression / diagnoses</label>
          <textarea id="assessment" name="assessment" rows="3" placeholder="1. ... 2. ..."></textarea>
        </div>
      </div>

      <h2><span class="soap-letter">P</span> Plan</h2>
      <div class="sig-block full">
        <div>
          <label for="plan">Plan – diagnostics, treatments, medications, disposition, follow-up</label>
          <textarea id="plan" name="plan" rows="4" placeholder="Orders, meds, wound care, activity, disposition, next visit..."></textarea>
        </div>
      </div>

      <div class="sig-block">
        <div>
          <label for="sig">Provider Signature *</label>
          <input type="text" id="sig" name="sig" required>
        </div>
        <div>
          <label for="cred">Credentials</label>
          <input type="text" id="cred" name="cred" placeholder="MD / DO / NP / PA">
        </div>
        <div>
          <label for="sigDate">Date *</label>
          <input type="date" id="sigDate" name="sigDate" required>
        </div>
        <div>
          <label for="sigTime">Time</label>
          <input type="time" id="sigTime" name="sigTime">
        </div>
      </div>

      <div class="btn-row">
        <button type="submit">Submit</button>
        <button type="button" class="secondary" onclick="window.print()">Print</button>
      </div>
      <div class="footer-info">
        <h3>Powered by Office Intelligence</h3>
      </div>
    </div>
  </form>
  <script>
    function handleSubmit(e) {
      e.preventDefault();
      console.log('SOAP submitted', Object.fromEntries(new FormData(e.target)));
      alert('SOAP Note submitted (demo).');
      return false;
    }
  </script>
</body>
</html>`
  },
  {
    id: 'note-daily',
    order: 3,
    title: 'Daily Doctor’s Note',
    subtitle: 'Progress Note & Post-Operative / Daily Physician Clinical Review',
    author: 'David Chen, MD',
    date: 'May 06, 2026',
    status: 'Signed & Cleared',
    category: 'Progress Note',
    fileName: 'Daily_Doctors_Note.html',
    summary: 'Daily physician progress note capturing post-op day status, interval history, exam vitals, data reviewed, assessment, and ongoing plan.',
    htmlTemplate: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Summit Surgical Center – Daily Doctor’s Note</title>
  <style>
    :root {
      --primary: #1a365d;
      --accent: #2b6cb0;
      --border: #cbd5e0;
      --bg: #f7fafc;
      --white: #ffffff;
      --text: #2d3748;
    }
    * { box-sizing: border-box; }
    body {
      font-family: Georgia, "Times New Roman", serif;
      line-height: 1.5;
      color: var(--text);
      background: var(--bg);
      margin: 0;
      padding: 0 0 50px;
    }
    .page {
      max-width: 860px;
      margin: 20px auto;
      background: var(--white);
      border: 1px solid var(--border);
      box-shadow: 0 4px 20px rgba(0,0,0,.08);
      padding: 32px 40px 44px;
    }
    header {
      text-align: center;
      border-bottom: 3px solid var(--primary);
      padding-bottom: 14px;
      margin-bottom: 22px;
    }
    header h1 { margin: 0 0 4px; font-size: 1.45rem; color: var(--primary); }
    header p { margin: 2px 0; font-size: .9rem; color: #4a5568; }
    h2 {
      font-size: 1.05rem;
      color: var(--primary);
      border-bottom: 2px solid var(--accent);
      padding-bottom: 4px;
      margin: 22px 0 10px;
      text-transform: uppercase;
      letter-spacing: .04em;
    }
    .sig-block {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 12px 20px;
      margin: 8px 0;
      align-items: end;
    }
    .sig-block.three { grid-template-columns: 1fr 1fr 1fr; }
    .sig-block.full { grid-template-columns: 1fr; }
    label {
      display: block;
      font-size: .78rem;
      font-weight: 600;
      color: #4a5568;
      margin-bottom: 2px;
    }
    input[type="text"], input[type="date"], input[type="time"], select, textarea {
      width: 100%;
      padding: 7px 10px;
      border: 1px solid var(--border);
      border-radius: 4px;
      font-size: .92rem;
      font-family: inherit;
      background: #fff;
    }
    input:focus, select:focus, textarea:focus {
      outline: 2px solid var(--accent);
      border-color: var(--accent);
    }
    textarea { resize: vertical; min-height: 56px; }
    .inline-group {
      display: flex;
      flex-wrap: wrap;
      gap: 12px 20px;
      align-items: center;
      margin: 8px 0;
    }
    .inline-group .radio-item {
      display: flex;
      align-items: center;
      gap: 5px;
    }
    .inline-group .radio-item label { font-weight: normal; margin: 0; font-size: .9rem; }
    .btn-row { text-align: center; margin-top: 28px; }
    button {
      background: var(--primary);
      color: white;
      border: none;
      padding: 12px 28px;
      font-size: .95rem;
      border-radius: 6px;
      cursor: pointer;
      font-family: inherit;
    }
    button:hover { background: #2c5282; }
    button.secondary { background: #718096; margin-left: 8px; }
    .footer-info {
      text-align: center;
      font-size: .75rem;
      color: #718096;
      margin-top: 28px;
      padding-top: 12px;
      border-top: 1px solid var(--border);
    }
    @media print {
      body { background: white; }
      .page { box-shadow: none; border: none; margin: 0; padding: 12px; }
      button { display: none; }
      input, select, textarea { border: none; border-bottom: 1px solid #999; border-radius: 0; }
    }
    @media (max-width: 640px) {
      .page { padding: 18px 14px; margin: 8px; }
      .sig-block, .sig-block.three { grid-template-columns: 1fr; }
    }
  </style>
</head>
<body>
  <form id="dailyForm" onsubmit="return handleSubmit(event)">
    <div class="page">
      <header>
        <h1>PROGRESS NOTE</h1>
      </header>

      <div class="sig-block three">
        <div>
          <label for="patientName">Patient Name *</label>
          <input type="text" id="patientName" name="patientName" required>
        </div>
        <div>
          <label for="dob">DOB *</label>
          <input type="date" id="dob" name="dob" required>
        </div>
        <div>
          <label for="mrn">MRN</label>
          <input type="text" id="mrn" name="mrn">
        </div>
        <div>
          <label for="noteDate">Date *</label>
          <input type="date" id="noteDate" name="noteDate" required>
        </div>
        <div>
          <label for="noteTime">Time *</label>
          <input type="time" id="noteTime" name="noteTime" required>
        </div>
        <div>
          <label for="pod">POD / Hospital Day</label>
          <input type="text" id="pod" name="pod" placeholder="e.g. POD #1">
        </div>
      </div>

      <div class="inline-group">
        <span style="font-weight:600;font-size:.9rem;">Note Type:</span>
        <div class="radio-item">
          <input type="radio" id="typeProg" name="noteType" value="Progress" checked>
          <label for="typeProg">Progress</label>
        </div>
        <div class="radio-item">
          <input type="radio" id="typePostop" name="noteType" value="Post-op">
          <label for="typePostop">Post-operative</label>
        </div>
        <div class="radio-item">
          <input type="radio" id="typeEvent" name="noteType" value="Event">
          <label for="typeEvent">Event / Acute</label>
        </div>
        <div class="radio-item">
          <input type="radio" id="typeDc" name="noteType" value="Discharge">
          <label for="typeDc">Discharge</label>
        </div>
      </div>

      <h2>Interval History</h2>
      <div class="sig-block full">
        <div>
          <label for="interval">Subjective / Interval events since last note</label>
          <textarea id="interval" name="interval" rows="3" placeholder="Patient reports..., overnight events, pain control, diet, ambulation, voiding, etc."></textarea>
        </div>
      </div>

      <h2>Exam / Objective</h2>
      <div class="sig-block three">
        <div>
          <label for="bp">BP</label>
          <input type="text" id="bp" name="bp">
        </div>
        <div>
          <label for="hr">HR</label>
          <input type="text" id="hr" name="hr">
        </div>
        <div>
          <label for="temp">Temp</label>
          <input type="text" id="temp" name="temp">
        </div>
        <div>
          <label for="rr">RR / SpO₂</label>
          <input type="text" id="rr" name="rr">
        </div>
        <div>
          <label for="pain">Pain (0–10)</label>
          <input type="text" id="pain" name="pain">
        </div>
        <div>
          <label for="iO">I/O or other</label>
          <input type="text" id="iO" name="iO">
        </div>
      </div>
      <div class="sig-block full">
        <div>
          <label for="exam">Focused examination</label>
          <textarea id="exam" name="exam" rows="3" placeholder="General, wound, drains, neurovascular, lungs, abdomen, extremities..."></textarea>
        </div>
      </div>

      <h2>Data Reviewed</h2>
      <div class="sig-block full">
        <div>
          <label for="data">Labs, imaging, cultures, other results reviewed today</label>
          <textarea id="data" name="data" rows="2" placeholder="CBC, BMP, wound culture, XR, etc. — or “None new”"></textarea>
        </div>
      </div>

      <h2>Assessment</h2>
      <div class="sig-block full">
        <div>
          <label for="assessment">Assessment</label>
          <textarea id="assessment" name="assessment" rows="3" placeholder="1. Post-op day #… status… 2. …"></textarea>
        </div>
      </div>

      <h2>Plan</h2>
      <div class="sig-block full">
        <div>
          <label for="plan">Plan for today / ongoing</label>
          <textarea id="plan" name="plan" rows="4" placeholder="Continue current management; advance diet; discontinue Foley; wound care; PT; disposition planning; meds changes..."></textarea>
        </div>
      </div>

      <div class="sig-block">
        <div>
          <label for="sig">Provider Signature *</label>
          <input type="text" id="sig" name="sig" required>
        </div>
        <div>
          <label for="cred">Credentials</label>
          <input type="text" id="cred" name="cred" placeholder="MD / DO / NP / PA">
        </div>
        <div>
          <label for="sigDate">Date *</label>
          <input type="date" id="sigDate" name="sigDate" required>
        </div>
        <div>
          <label for="sigTime">Time</label>
          <input type="time" id="sigTime" name="sigTime">
        </div>
      </div>

      <div class="btn-row">
        <button type="submit">Submit</button>
        <button type="button" class="secondary" onclick="window.print()">Print</button>
      </div>
      <div class="footer-info">
       <h3>Powered by Office Intelligence</h3>
      </div>
    </div>
  </form>
  <script>
    function handleSubmit(e) {
      e.preventDefault();
      console.log('Daily note submitted', Object.fromEntries(new FormData(e.target)));
      alert('Daily Doctor’s Note submitted (demo).');
      return false;
    }
  </script>
</body>
</html>`
  }
];
