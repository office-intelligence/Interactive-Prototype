export interface IntakeHtmlForm {
  id: string;
  order: number;
  title: string;
  category: 'Admission' | 'Insurance' | 'Medical' | 'Anesthesia';
  type: string;
  targetAudience: string;
  status: 'Pending Send' | 'Sent via Email' | 'Sent via SMS' | 'Completed in Portal';
  lastSentDate?: string;
  completedDate?: string;
  fileName: string;
  summary: string;
  description: string;
  htmlTemplate: string;
}

export const INITIAL_INTAKE_HTML_FORMS: IntakeHtmlForm[] = [
  {
    id: 'form-admission',
    order: 1,
    title: 'Admission Form',
    category: 'Admission',
    type: 'Interactive HTML Intake Form',
    targetAudience: 'Patient (Self/Guardian)',
    status: 'Sent via Email',
    lastSentDate: 'Jul 29, 2026',
    fileName: 'Admission_Form.html',
    summary: 'Summit Surgical Center Admission packet. Covers Patient Information, Rights & Responsibilities, HIPAA Privacy, Physician Ownership, Grievance, Advance Directives, Facility Arbitration, and Cash Fee Disclosure.',
    description: 'Mandatory pre-surgery admission disclosures, patient rights acknowledgment, advance directives choice, and arbitration agreement.',
    htmlTemplate: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Summit Surgical Center – Admission Form</title>
  <style>
    :root { --primary: #1a365d; --accent: #2b6cb0; --border: #cbd5e0; --bg: #f7fafc; --white: #ffffff; --text: #2d3748; }
    * { box-sizing: border-box; }
    body { font-family: Georgia, "Times New Roman", serif; line-height: 1.55; color: var(--text); background: var(--bg); margin: 0; padding: 20px; }
    .page { max-width: 860px; margin: 0 auto; background: var(--white); border: 1px solid var(--border); border-radius: 12px; box-shadow: 0 4px 20px rgba(0,0,0,.08); padding: 36px 44px; }
    header { text-align: center; border-bottom: 3px solid var(--primary); padding-bottom: 18px; margin-bottom: 28px; }
    header h1 { margin: 0 0 6px; font-size: 1.55rem; color: var(--primary); letter-spacing: .02em; }
    header p { margin: 2px 0; font-size: .95rem; color: #4a5568; }
    h2 { font-size: 1.2rem; color: var(--primary); border-bottom: 2px solid var(--accent); padding-bottom: 6px; margin: 36px 0 16px; text-transform: uppercase; letter-spacing: .04em; }
    h3 { font-size: 1.05rem; color: var(--accent); margin: 22px 0 10px; }
    ul { padding-left: 1.35em; margin: 8px 0 16px; }
    li { margin-bottom: 7px; }
    .notice { background: #edf2f7; border-left: 4px solid var(--accent); padding: 12px 16px; margin: 16px 0; font-size: .95rem; }
    .sig-block { display: grid; grid-template-columns: 1fr 1fr; gap: 20px 28px; margin: 22px 0 10px; align-items: end; }
    label { display: block; font-size: .85rem; font-weight: 600; color: #4a5568; margin-bottom: 4px; }
    input[type="text"], input[type="date"], input[type="email"], input[type="tel"], textarea { width: 100%; padding: 9px 12px; border: 1px solid var(--border); border-radius: 4px; font-size: 1rem; font-family: inherit; background: #fff; }
    .checkbox-row { display: flex; items-center; gap: 10px; margin: 10px 0; }
    .checkbox-row input[type="checkbox"] { width: 18px; height: 18px; flex-shrink: 0; }
    .initial-line { display: flex; align-items: center; gap: 12px; margin: 12px 0; flex-wrap: wrap; }
    .initial-line input { width: 90px; text-align: center; font-weight: 600; }
    .btn-row { text-align: center; margin-top: 36px; }
    button { background: var(--primary); color: white; border: none; padding: 14px 36px; font-size: 1.05rem; border-radius: 6px; cursor: pointer; font-family: inherit; }
    button:hover { background: #2c5282; }
    button.secondary { background: #718096; margin-left: 12px; }
  </style>
</head>
<body>
  <div class="page">
    <header>
      <h1>ADMISSION FORM</h1>
      <p>Summit Surgical Center — Ambulatory Surgical Center</p>
    </header>

    <h2>Patient Information</h2>
    <div class="sig-block">
      <div><label>Patient Full Name</label><input type="text" id="patientName" name="patientName" required></div>
      <div><label>Date of Birth</label><input type="date" id="dob" name="dob"></div>
      <div><label>Phone</label><input type="tel" id="phone" name="phone"></div>
      <div><label>Email</label><input type="email" id="email" name="email"></div>
    </div>

    <h2>Patient's Rights</h2>
    <ul>
      <li>Patients are treated with respect, consideration, dignity and provided appropriate personal privacy.</li>
      <li>Patient disclosures and records are treated confidentially.</li>
      <li>Patients are given the opportunity to participate in decisions involving their health care.</li>
      <li>Be fully informed of the scope of services available at the facility.</li>
      <li>Be informed of charges, fees for service, and receive counseling on available financial resources.</li>
    </ul>

    <h2>Patient's Responsibilities</h2>
    <ul>
      <li>Provide complete and accurate information about health, medications, and allergies.</li>
      <li>Provide a responsible adult to transport home and remain for 24 hours post-procedure.</li>
      <li>Accept personal financial responsibility for any charges not covered by insurance.</li>
    </ul>

    <h2>Statement of Rights & HIPAA Privacy Notice</h2>
    <p>Describes how protected health information (PHI) is used for treatment, payment, and healthcare operations.</p>

    <h2>Disclosure of Ownership</h2>
    <p>Physicians with financial interest in Summit Surgical Center: Shahram Taheri, M.D., Gary Alter, M.D., Kevin Tehrani, M.D., Stuart Linder, M.D.</p>

    <h2>Medical Advance Directives</h2>
    <p>Summit Surgical Center does elective outpatient procedures. In an emergency, ACLS will be instituted and patient transferred to Cedars-Sinai Medical Center.</p>
    <div class="checkbox-row"><input type="checkbox" id="advUnderstood" required><label for="advUnderstood">I have read and understand Advance Directives policy.</label></div>
    <div class="checkbox-row"><input type="checkbox" id="advYes"><label for="advYes">I DO have an Advance Directive.</label></div>
    <div class="checkbox-row"><input type="checkbox" id="advNo"><label for="advNo">I DO NOT have an Advance Directive.</label></div>

    <h2>Facility Arbitration Agreement</h2>
    <p>Disputes regarding medical malpractice will be determined by neutral arbitration under California law rather than court trial.</p>
    <div class="sig-block">
      <div><label>Patient / Responsible Party Signature</label><input type="text" id="arbPatientSig" required placeholder="Type full name"></div>
      <div><label>Date</label><input type="date" id="arbPatientDate" required></div>
    </div>

    <h2>Acknowledgement of Receipt</h2>
    <div class="checkbox-row"><input type="checkbox" id="ackHipaa" required><label for="ackHipaa">I acknowledge receipt of Privacy Notice / HIPAA Policy.</label></div>
    <div class="checkbox-row"><input type="checkbox" id="ackInfo" required><label for="ackInfo">I acknowledge receipt of Patient Rights, Ownership, Grievance & Advance Directives.</label></div>
    <div class="sig-block">
      <div><label>Signature</label><input type="text" id="ackSig" required placeholder="Type full name"></div>
      <div><label>Print Name</label><input type="text" id="ackPrint" required></div>
      <div><label>Date</label><input type="date" id="ackDate" required></div>
    </div>

    <h2>Cash Payment Fee Disclosure</h2>
    <div class="initial-line">
      <span>I understand charges are estimated deposits and I am responsible for excess time charges.</span>
      <label>Initial:</label><input type="text" id="init1" maxlength="5" required>
    </div>
    <div class="sig-block">
      <div><label>Patient Signature</label><input type="text" id="cashPatientSig" required placeholder="Type full name"></div>
      <div><label>Date</label><input type="date" id="cashDate" required></div>
    </div>

    <div class="btn-row">
      <button type="submit" id="submitBtn">Submit Admission Form</button>
      <button type="button" class="secondary" onclick="window.print()">Print Form</button>
    </div>
  </div>
</body>
</html>`
  },
  {
    id: 'form-insurance',
    order: 2,
    title: 'Insurance Information',
    category: 'Insurance',
    type: 'Interactive HTML Intake Form',
    targetAudience: 'Patient / Guarantor',
    status: 'Sent via Email',
    lastSentDate: 'Jul 29, 2026',
    fileName: 'Insurance_Information.html',
    summary: 'Summit Surgical Center Insurance verification intake. Collects primary & secondary insurance details, subscriber info, and front/back card uploads.',
    description: 'Captures primary & secondary carrier, member ID, group number, policyholder relation, and insurance card image scans.',
    htmlTemplate: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Summit Surgical Center – Insurance Information</title>
  <style>
    :root { --primary: #1a365d; --accent: #2b6cb0; --border: #cbd5e0; --bg: #f7fafc; --white: #ffffff; --text: #2d3748; }
    * { box-sizing: border-box; }
    body { font-family: Georgia, "Times New Roman", serif; line-height: 1.55; color: var(--text); background: var(--bg); margin: 0; padding: 20px; }
    .page { max-width: 860px; margin: 0 auto; background: var(--white); border: 1px solid var(--border); border-radius: 12px; box-shadow: 0 4px 20px rgba(0,0,0,.08); padding: 36px 44px; }
    header { text-align: center; border-bottom: 3px solid var(--primary); padding-bottom: 18px; margin-bottom: 28px; }
    header h1 { margin: 0 0 6px; font-size: 1.55rem; color: var(--primary); letter-spacing: .02em; }
    h2 { font-size: 1.15rem; color: var(--primary); border-bottom: 2px solid var(--accent); padding-bottom: 6px; margin: 28px 0 16px; text-transform: uppercase; }
    .sig-block { display: grid; grid-template-columns: 1fr 1fr; gap: 16px 24px; margin: 12px 0 8px; }
    label { display: block; font-size: .82rem; font-weight: 600; color: #4a5568; margin-bottom: 3px; }
    input[type="text"], input[type="date"], select { width: 100%; padding: 8px 11px; border: 1px solid var(--border); border-radius: 4px; font-size: .95rem; font-family: inherit; }
    .upload-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 24px; margin: 16px 0 8px; }
    .upload-box { border: 2px dashed var(--border); border-radius: 8px; padding: 20px 16px; text-align: center; background: #f8fafc; }
    .btn-row { text-align: center; margin-top: 32px; }
    button { background: var(--primary); color: white; border: none; padding: 13px 32px; font-size: 1rem; border-radius: 6px; cursor: pointer; }
    button:hover { background: #2c5282; }
    button.secondary { background: #718096; margin-left: 10px; }
  </style>
</head>
<body>
  <div class="page">
    <header>
      <h1>INSURANCE INFORMATION</h1>
      <p>Summit Surgical Center Intake Portal</p>
    </header>

    <h2>Patient</h2>
    <div class="sig-block">
      <div><label>Patient Full Name *</label><input type="text" id="patientName" required></div>
      <div><label>Date of Birth *</label><input type="date" id="dob" required></div>
    </div>

    <h2>Primary Insurance</h2>
    <div class="sig-block">
      <div><label>Insurance Company *</label><input type="text" id="insCompany" placeholder="e.g. Blue Shield, Aetna" required></div>
      <div><label>Member / Subscriber ID *</label><input type="text" id="memberId" required></div>
      <div><label>Group Number</label><input type="text" id="groupNumber"></div>
      <div><label>Plan Name / Type</label><input type="text" id="planName" placeholder="PPO, HMO"></div>
    </div>

    <h2>Secondary Insurance (Optional)</h2>
    <div class="sig-block">
      <div><label>Insurance Company</label><input type="text" id="secCompany"></div>
      <div><label>Member / Subscriber ID</label><input type="text" id="secMemberId"></div>
      <div><label>Group Number</label><input type="text" id="secGroup"></div>
    </div>

    <h2>Insurance Card Images</h2>
    <div class="upload-grid">
      <div class="upload-box">
        <label>Front of Card *</label>
        <input type="file" id="cardFront" accept="image/*,.pdf" required>
      </div>
      <div class="upload-box">
        <label>Back of Card *</label>
        <input type="file" id="cardBack" accept="image/*,.pdf" required>
      </div>
    </div>

    <h2>Certification</h2>
    <div class="sig-block">
      <div><label>Patient / Guarantor Signature *</label><input type="text" id="sig" required placeholder="Type full name"></div>
      <div><label>Date *</label><input type="date" id="sigDate" required></div>
    </div>

    <div class="btn-row">
      <button type="submit" id="submitBtn">Submit Insurance Form</button>
      <button type="button" class="secondary" onclick="window.print()">Print Form</button>
    </div>
  </div>
</body>
</html>`
  },
  {
    id: 'form-medical',
    order: 3,
    title: 'Medical History',
    category: 'Medical',
    type: 'Interactive HTML Intake Form',
    targetAudience: 'Patient (Self/Guardian)',
    status: 'Pending Send',
    fileName: 'Medical_History.html',
    summary: 'Comprehensive medical history screening form. Captures allergies, active medications table, PMH, surgical history, family history, social history, OB/GYN, and Review of Systems.',
    description: 'Detailed clinical history including drug/food allergies, medication reconciliation, surgical history, and review of systems.',
    htmlTemplate: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Summit Surgical Center – Medical History Form</title>
  <style>
    :root {
      --primary: #1a365d;
      --accent: #2b6cb0;
      --border: #cbd5e0;
      --bg: #f7fafc;
      --white: #ffffff;
      --text: #2d3748;
    }
    * { box-sizing: border-box; }
    body {
      font-family: Georgia, "Times New Roman", serif;
      line-height: 1.55;
      color: var(--text);
      background: var(--bg);
      margin: 0;
      padding: 0 0 60px;
    }
    .page {
      max-width: 860px;
      margin: 24px auto;
      background: var(--white);
      border: 1px solid var(--border);
      box-shadow: 0 4px 20px rgba(0,0,0,.08);
      padding: 36px 44px 48px;
    }
    header {
      text-align: center;
      border-bottom: 3px solid var(--primary);
      padding-bottom: 18px;
      margin-bottom: 28px;
    }
    header h1 {
      margin: 0 0 6px;
      font-size: 1.55rem;
      color: var(--primary);
      letter-spacing: .02em;
    }
    header p {
      margin: 2px 0;
      font-size: .95rem;
      color: #4a5568;
    }
    h2 {
      font-size: 1.15rem;
      color: var(--primary);
      border-bottom: 2px solid var(--accent);
      padding-bottom: 6px;
      margin: 32px 0 16px;
      text-transform: uppercase;
      letter-spacing: .04em;
    }
    h3 {
      font-size: 1rem;
      color: var(--accent);
      margin: 18px 0 10px;
    }
    .sig-block {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 16px 24px;
      margin: 12px 0 8px;
      align-items: end;
    }
    .sig-block.three { grid-template-columns: 1fr 1fr 1fr; }
    .sig-block.full { grid-template-columns: 1fr; }
    label {
      display: block;
      font-size: .82rem;
      font-weight: 600;
      color: #4a5568;
      margin-bottom: 3px;
    }
    input[type="text"],
    input[type="date"],
    input[type="number"],
    input[type="email"],
    input[type="tel"],
    select,
    textarea {
      width: 100%;
      padding: 8px 11px;
      border: 1px solid var(--border);
      border-radius: 4px;
      font-size: .95rem;
      font-family: inherit;
      background: #fff;
    }
    input:focus, select:focus, textarea:focus {
      outline: 2px solid var(--accent);
      border-color: var(--accent);
    }
    textarea { resize: vertical; min-height: 70px; }
    .checkbox-row {
      display: flex;
      align-items: flex-start;
      gap: 8px;
      margin: 6px 0;
    }
    .checkbox-row input[type="checkbox"],
    .checkbox-row input[type="radio"] {
      width: 16px;
      height: 16px;
      margin-top: 3px;
      flex-shrink: 0;
    }
    .checkbox-row label { font-weight: normal; font-size: .92rem; margin-bottom: 0; }
    .check-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 4px 20px;
      margin: 8px 0 12px;
    }
    .check-grid.three { grid-template-columns: 1fr 1fr 1fr; }
    .inline-group {
      display: flex;
      flex-wrap: wrap;
      gap: 16px 28px;
      align-items: center;
      margin: 8px 0;
    }
    .inline-group .radio-item {
      display: flex;
      align-items: center;
      gap: 6px;
    }
    .inline-group .radio-item label { font-weight: normal; margin: 0; }
    .notice {
      background: #edf2f7;
      border-left: 4px solid var(--accent);
      padding: 10px 14px;
      margin: 14px 0;
      font-size: .9rem;
    }
    .female-only {
      background: #faf5ff;
      border: 1px solid #e9d8fd;
      border-radius: 6px;
      padding: 14px 18px;
      margin: 12px 0;
    }
    table.med-table {
      width: 100%;
      border-collapse: collapse;
      margin: 10px 0 16px;
      font-size: .9rem;
    }
    table.med-table th {
      background: #edf2f7;
      color: var(--primary);
      text-align: left;
      padding: 8px 10px;
      border: 1px solid var(--border);
      font-size: .8rem;
    }
    table.med-table td {
      padding: 4px;
      border: 1px solid var(--border);
      vertical-align: middle;
    }
    table.med-table input {
      border: none;
      padding: 6px 8px;
      width: 100%;
      background: transparent;
    }
    table.med-table input:focus { outline: none; background: #ebf8ff; }
    .btn-row { text-align: center; margin-top: 36px; }
    button {
      background: var(--primary);
      color: white;
      border: none;
      padding: 13px 32px;
      font-size: 1rem;
      border-radius: 6px;
      cursor: pointer;
      font-family: inherit;
      letter-spacing: .03em;
    }
    button:hover { background: #2c5282; }
    button.secondary {
      background: #718096;
      margin-left: 10px;
    }
    .footer-info {
      text-align: center;
      font-size: .8rem;
      color: #718096;
      margin-top: 40px;
      padding-top: 16px;
      border-top: 1px solid var(--border);
    }
    @media print {
      body { background: white; }
      .page { box-shadow: none; border: none; margin: 0; padding: 16px; }
      button { display: none; }
      input, select, textarea { border: none; border-bottom: 1px solid #999; border-radius: 0; }
    }
    @media (max-width: 640px) {
      .page { padding: 22px 16px; margin: 10px; }
      .sig-block, .sig-block.three, .check-grid, .check-grid.three { grid-template-columns: 1fr; }
    }
  </style>
</head>
<body>
  <form id="historyForm" onsubmit="return handleSubmit(event)">
    <div class="page">
      <header>
        <h1>GENERAL MEDICAL HISTORY FORM</h1>
      </header>

      <!-- ========== PATIENT INFORMATION ========== -->
      <h2>Patient Information</h2>
      <div class="sig-block">
        <div>
          <label for="patientName">Patient Full Name *</label>
          <input type="text" id="patientName" name="patientName" required>
        </div>
        <div>
          <label for="dob">Date of Birth *</label>
          <input type="date" id="dob" name="dob" required>
        </div>
        <div>
          <label for="age">Age</label>
          <input type="number" id="age" name="age" min="0" max="120">
        </div>
        <div>
          <label for="sex">Sex *</label>
          <select id="sex" name="sex" required onchange="toggleFemaleSection()">
            <option value="">— Select —</option>
            <option value="Female">Female</option>
            <option value="Male">Male</option>
            <option value="Other">Other</option>
          </select>
        </div>
        <div>
          <label for="height">Height (ft/in or cm)</label>
          <input type="text" id="height" name="height" placeholder="e.g. 5'6&quot; or 168 cm">
        </div>
        <div>
          <label for="weight">Weight (lbs or kg)</label>
          <input type="text" id="weight" name="weight" placeholder="e.g. 140 lbs">
        </div>
        <div>
          <label for="phone">Phone</label>
          <input type="tel" id="phone" name="phone">
        </div>
        <div>
          <label for="email">Email</label>
          <input type="email" id="email" name="email">
        </div>
      </div>
      <div class="sig-block full">
        <div>
          <label for="primaryPhysician">Primary Care Physician / Referring Physician</label>
          <input type="text" id="primaryPhysician" name="primaryPhysician">
        </div>
      </div>
      <div class="sig-block">
        <div>
          <label for="emergencyName">Emergency Contact Name</label>
          <input type="text" id="emergencyName" name="emergencyName">
        </div>
        <div>
          <label for="emergencyPhone">Emergency Contact Phone</label>
          <input type="tel" id="emergencyPhone" name="emergencyPhone">
        </div>
      </div>

      <!-- ========== ALLERGIES ========== -->
      <h2>Allergies</h2>
      <div class="inline-group">
        <div class="radio-item">
          <input type="radio" id="allergyNone" name="allergyStatus" value="none" checked onchange="toggleAllergies()">
          <label for="allergyNone">No known allergies</label>
        </div>
        <div class="radio-item">
          <input type="radio" id="allergyYes" name="allergyStatus" value="yes" onchange="toggleAllergies()">
          <label for="allergyYes">Yes – list below</label>
        </div>
      </div>
      <div id="allergyDetails" style="display:none;">
        <div class="sig-block full">
          <div>
            <label for="drugAllergies">Drug / Medication Allergies (include reaction)</label>
            <textarea id="drugAllergies" name="drugAllergies" rows="2" placeholder="e.g. Penicillin – rash; Codeine – nausea"></textarea>
          </div>
        </div>
        <div class="sig-block full">
          <div>
            <label for="otherAllergies">Other Allergies (latex, food, environmental, contrast dye, etc.)</label>
            <textarea id="otherAllergies" name="otherAllergies" rows="2"></textarea>
          </div>
        </div>
      </div>

      <!-- ========== CURRENT MEDICATIONS ========== -->
      <h2>Current Medications</h2>
      <p style="font-size:.9rem;margin:0 0 8px;">Include prescription medications, over-the-counter drugs, vitamins, herbs, and supplements.</p>
      <div class="inline-group" style="margin-bottom:10px;">
        <div class="radio-item">
          <input type="radio" id="medNone" name="medStatus" value="none" checked onchange="toggleMeds()">
          <label for="medNone">None</label>
        </div>
        <div class="radio-item">
          <input type="radio" id="medYes" name="medStatus" value="yes" onchange="toggleMeds()">
          <label for="medYes">Yes – list below</label>
        </div>
      </div>
      <div id="medTableWrap" style="display:none;">
        <table class="med-table">
          <thead>
            <tr>
              <th style="width:32%">Medication Name</th>
              <th style="width:18%">Dose</th>
              <th style="width:20%">Frequency</th>
              <th style="width:30%">Reason / Notes</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td><input type="text" name="med1_name"></td>
              <td><input type="text" name="med1_dose"></td>
              <td><input type="text" name="med1_freq"></td>
              <td><input type="text" name="med1_reason"></td>
            </tr>
            <tr>
              <td><input type="text" name="med2_name"></td>
              <td><input type="text" name="med2_dose"></td>
              <td><input type="text" name="med2_freq"></td>
              <td><input type="text" name="med2_reason"></td>
            </tr>
            <tr>
              <td><input type="text" name="med3_name"></td>
              <td><input type="text" name="med3_dose"></td>
              <td><input type="text" name="med3_freq"></td>
              <td><input type="text" name="med3_reason"></td>
            </tr>
            <tr>
              <td><input type="text" name="med4_name"></td>
              <td><input type="text" name="med4_dose"></td>
              <td><input type="text" name="med4_freq"></td>
              <td><input type="text" name="med4_reason"></td>
            </tr>
            <tr>
              <td><input type="text" name="med5_name"></td>
              <td><input type="text" name="med5_dose"></td>
              <td><input type="text" name="med5_freq"></td>
              <td><input type="text" name="med5_reason"></td>
            </tr>
            <tr>
              <td><input type="text" name="med6_name"></td>
              <td><input type="text" name="med6_dose"></td>
              <td><input type="text" name="med6_freq"></td>
              <td><input type="text" name="med6_reason"></td>
            </tr>
          </tbody>
        </table>
      </div>

      <!-- ========== PAST MEDICAL HISTORY ========== -->
      <h2>Past Medical History</h2>
      <p style="font-size:.9rem;margin:0 0 8px;">Check all that apply. Provide details where indicated.</p>
      <div class="check-grid">
        <div class="checkbox-row"><input type="checkbox" id="pmh_htn" name="pmh" value="Hypertension"><label for="pmh_htn">Hypertension (High Blood Pressure)</label></div>
        <div class="checkbox-row"><input type="checkbox" id="pmh_dm" name="pmh" value="Diabetes"><label for="pmh_dm">Diabetes Mellitus</label></div>
        <div class="checkbox-row"><input type="checkbox" id="pmh_heart" name="pmh" value="Heart Disease"><label for="pmh_heart">Heart Disease / CAD / Heart Attack</label></div>
        <div class="checkbox-row"><input type="checkbox" id="pmh_afib" name="pmh" value="Arrhythmia"><label for="pmh_afib">Arrhythmia / Atrial Fibrillation</label></div>
        <div class="checkbox-row"><input type="checkbox" id="pmh_chf" name="pmh" value="CHF"><label for="pmh_chf">Congestive Heart Failure</label></div>
        <div class="checkbox-row"><input type="checkbox" id="pmh_stroke" name="pmh" value="Stroke / TIA"><label for="pmh_stroke">Stroke / TIA</label></div>
        <div class="checkbox-row"><input type="checkbox" id="pmh_asthma" name="pmh" value="Asthma"><label for="pmh_asthma">Asthma</label></div>
        <div class="checkbox-row"><input type="checkbox" id="pmh_copd" name="pmh" value="COPD"><label for="pmh_copd">COPD / Emphysema</label></div>
        <div class="checkbox-row"><input type="checkbox" id="pmh_sleep" name="pmh" value="Sleep Apnea"><label for="pmh_sleep">Sleep Apnea (CPAP?)</label></div>
        <div class="checkbox-row"><input type="checkbox" id="pmh_thyroid" name="pmh" value="Thyroid"><label for="pmh_thyroid">Thyroid Disease</label></div>
        <div class="checkbox-row"><input type="checkbox" id="pmh_kidney" name="pmh" value="Kidney Disease"><label for="pmh_kidney">Kidney Disease / Failure</label></div>
        <div class="checkbox-row"><input type="checkbox" id="pmh_liver" name="pmh" value="Liver Disease"><label for="pmh_liver">Liver Disease / Hepatitis</label></div>
        <div class="checkbox-row"><input type="checkbox" id="pmh_gerd" name="pmh" value="GERD"><label for="pmh_gerd">GERD / Reflux / Ulcers</label></div>
        <div class="checkbox-row"><input type="checkbox" id="pmh_ibd" name="pmh" value="IBD"><label for="pmh_ibd">Crohn’s / Ulcerative Colitis</label></div>
        <div class="checkbox-row"><input type="checkbox" id="pmh_anemia" name="pmh" value="Anemia"><label for="pmh_anemia">Anemia / Bleeding Disorder</label></div>
        <div class="checkbox-row"><input type="checkbox" id="pmh_clot" name="pmh" value="Blood Clots"><label for="pmh_clot">Blood Clots / DVT / PE</label></div>
        <div class="checkbox-row"><input type="checkbox" id="pmh_cancer" name="pmh" value="Cancer"><label for="pmh_cancer">Cancer (type/year below)</label></div>
        <div class="checkbox-row"><input type="checkbox" id="pmh_seizure" name="pmh" value="Seizures"><label for="pmh_seizure">Seizures / Epilepsy</label></div>
        <div class="checkbox-row"><input type="checkbox" id="pmh_migraine" name="pmh" value="Migraines"><label for="pmh_migraine">Migraines / Chronic Headaches</label></div>
        <div class="checkbox-row"><input type="checkbox" id="pmh_depression" name="pmh" value="Depression / Anxiety"><label for="pmh_depression">Depression / Anxiety</label></div>
        <div class="checkbox-row"><input type="checkbox" id="pmh_arthritis" name="pmh" value="Arthritis"><label for="pmh_arthritis">Arthritis / Joint Disease</label></div>
        <div class="checkbox-row"><input type="checkbox" id="pmh_hiv" name="pmh" value="HIV / AIDS"><label for="pmh_hiv">HIV / AIDS</label></div>
        <div class="checkbox-row"><input type="checkbox" id="pmh_other" name="pmh" value="Other"><label for="pmh_other">Other (specify below)</label></div>
        <div class="checkbox-row"><input type="checkbox" id="pmh_none" name="pmh" value="None"><label for="pmh_none">None of the above</label></div>
      </div>
      <div class="sig-block full">
        <div>
          <label for="pmhDetails">Details / Additional Medical Conditions</label>
          <textarea id="pmhDetails" name="pmhDetails" rows="2" placeholder="Cancer type & year, other conditions, etc."></textarea>
        </div>
      </div>

      <!-- ========== PAST SURGICAL HISTORY ========== -->
      <h2>Past Surgical History</h2>
      <div class="inline-group" style="margin-bottom:10px;">
        <div class="radio-item">
          <input type="radio" id="surgNone" name="surgStatus" value="none" checked onchange="toggleSurg()">
          <label for="surgNone">No prior surgeries</label>
        </div>
        <div class="radio-item">
          <input type="radio" id="surgYes" name="surgStatus" value="yes" onchange="toggleSurg()">
          <label for="surgYes">Yes – list below</label>
        </div>
      </div>
      <div id="surgTableWrap" style="display:none;">
        <table class="med-table">
          <thead>
            <tr>
              <th style="width:45%">Procedure / Surgery</th>
              <th style="width:20%">Year / Approx. Date</th>
              <th style="width:35%">Hospital / Surgeon / Notes</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td><input type="text" name="surg1_name"></td>
              <td><input type="text" name="surg1_year"></td>
              <td><input type="text" name="surg1_notes"></td>
            </tr>
            <tr>
              <td><input type="text" name="surg2_name"></td>
              <td><input type="text" name="surg2_year"></td>
              <td><input type="text" name="surg2_notes"></td>
            </tr>
            <tr>
              <td><input type="text" name="surg3_name"></td>
              <td><input type="text" name="surg3_year"></td>
              <td><input type="text" name="surg3_notes"></td>
            </tr>
            <tr>
              <td><input type="text" name="surg4_name"></td>
              <td><input type="text" name="surg4_year"></td>
              <td><input type="text" name="surg4_notes"></td>
            </tr>
            <tr>
              <td><input type="text" name="surg5_name"></td>
              <td><input type="text" name="surg5_year"></td>
              <td><input type="text" name="surg5_notes"></td>
            </tr>
          </tbody>
        </table>
        <div class="checkbox-row" style="margin-top:8px;">
          <input type="checkbox" id="anesProblems" name="anesProblems" value="yes">
          <label for="anesProblems">Any problems with anesthesia in the past? (describe below if yes)</label>
        </div>
        <div class="sig-block full">
          <div>
            <label for="anesDetails">Anesthesia Problems / Complications</label>
            <textarea id="anesDetails" name="anesDetails" rows="2"></textarea>
          </div>
        </div>
      </div>

      <!-- ========== FAMILY HISTORY ========== -->
      <h2>Family History</h2>
      <p style="font-size:.9rem;margin:0 0 8px;">Indicate if any immediate family members (parents, siblings, children) have had:</p>
      <div class="check-grid three">
        <div class="checkbox-row"><input type="checkbox" id="fh_heart" name="fh" value="Heart Disease"><label for="fh_heart">Heart Disease</label></div>
        <div class="checkbox-row"><input type="checkbox" id="fh_dm" name="fh" value="Diabetes"><label for="fh_dm">Diabetes</label></div>
        <div class="checkbox-row"><input type="checkbox" id="fh_cancer" name="fh" value="Cancer"><label for="fh_cancer">Cancer</label></div>
        <div class="checkbox-row"><input type="checkbox" id="fh_htn" name="fh" value="Hypertension"><label for="fh_htn">Hypertension</label></div>
        <div class="checkbox-row"><input type="checkbox" id="fh_stroke" name="fh" value="Stroke"><label for="fh_stroke">Stroke</label></div>
        <div class="checkbox-row"><input type="checkbox" id="fh_bleeding" name="fh" value="Bleeding Disorder"><label for="fh_bleeding">Bleeding / Clotting Disorder</label></div>
        <div class="checkbox-row"><input type="checkbox" id="fh_anes" name="fh" value="Anesthesia Problems"><label for="fh_anes">Anesthesia Problems / Malignant Hyperthermia</label></div>
        <div class="checkbox-row"><input type="checkbox" id="fh_other" name="fh" value="Other"><label for="fh_other">Other</label></div>
        <div class="checkbox-row"><input type="checkbox" id="fh_none" name="fh" value="None Known"><label for="fh_none">None Known</label></div>
      </div>
      <div class="sig-block full">
        <div>
          <label for="fhDetails">Family History Details</label>
          <textarea id="fhDetails" name="fhDetails" rows="2" placeholder="Relationship and condition, e.g. Mother – breast cancer age 52"></textarea>
        </div>
      </div>

      <!-- ========== SOCIAL HISTORY ========== -->
      <h2>Social History</h2>

      <h3>Tobacco / Smoking</h3>
      <div class="inline-group">
        <div class="radio-item">
          <input type="radio" id="smokeNever" name="smoking" value="Never" checked onchange="toggleSmoke()">
          <label for="smokeNever">Never smoked</label>
        </div>
        <div class="radio-item">
          <input type="radio" id="smokeFormer" name="smoking" value="Former" onchange="toggleSmoke()">
          <label for="smokeFormer">Former smoker</label>
        </div>
        <div class="radio-item">
          <input type="radio" id="smokeCurrent" name="smoking" value="Current" onchange="toggleSmoke()">
          <label for="smokeCurrent">Current smoker</label>
        </div>
      </div>
      <div id="smokeDetails" style="display:none;">
        <div class="sig-block three">
          <div>
            <label for="packYears">Packs per day</label>
            <input type="text" id="packYears" name="packYears" placeholder="e.g. 1">
          </div>
          <div>
            <label for="smokeYears">Years smoked</label>
            <input type="text" id="smokeYears" name="smokeYears">
          </div>
          <div>
            <label for="quitYear">Year quit (if former)</label>
            <input type="text" id="quitYear" name="quitYear">
          </div>
        </div>
      </div>

      <h3>Alcohol</h3>
      <div class="inline-group">
        <div class="radio-item">
          <input type="radio" id="alcNone" name="alcohol" value="None" checked>
          <label for="alcNone">None</label>
        </div>
        <div class="radio-item">
          <input type="radio" id="alcOcc" name="alcohol" value="Occasional">
          <label for="alcOcc">Occasional</label>
        </div>
        <div class="radio-item">
          <input type="radio" id="alcMod" name="alcohol" value="Moderate">
          <label for="alcMod">Moderate (1–7 drinks/week)</label>
        </div>
        <div class="radio-item">
          <input type="radio" id="alcHeavy" name="alcohol" value="Heavy">
          <label for="alcHeavy">Heavy (&gt;7 drinks/week)</label>
        </div>
      </div>

      <h3>Recreational / Illicit Drugs</h3>
      <div class="inline-group">
        <div class="radio-item">
          <input type="radio" id="drugNone" name="illicit" value="None" checked>
          <label for="drugNone">None</label>
        </div>
        <div class="radio-item">
          <input type="radio" id="drugYes" name="illicit" value="Yes">
          <label for="drugYes">Yes (specify)</label>
        </div>
      </div>
      <div class="sig-block full">
        <div>
          <label for="drugDetails">Details (type, frequency, last use)</label>
          <input type="text" id="drugDetails" name="drugDetails">
        </div>
      </div>

      <h3>Exercise</h3>
      <div class="inline-group">
        <div class="radio-item">
          <input type="radio" id="exNone" name="exercise" value="None" checked>
          <label for="exNone">None / Sedentary</label>
        </div>
        <div class="radio-item">
          <input type="radio" id="exLight" name="exercise" value="Light">
          <label for="exLight">Light</label>
        </div>
        <div class="radio-item">
          <input type="radio" id="exMod" name="exercise" value="Moderate">
          <label for="exMod">Moderate</label>
        </div>
        <div class="radio-item">
          <input type="radio" id="exVig" name="exercise" value="Vigorous">
          <label for="exVig">Vigorous</label>
        </div>
      </div>

      <!-- ========== FEMALE PATIENTS ========== -->
      <div id="femaleSection" class="female-only" style="display:none;">
        <h2 style="margin-top:0;border-color:#805ad5;">For Female Patients – Pregnancy &amp; Gynecologic History</h2>
        <div class="sig-block three">
          <div>
            <label for="lmp">Date of Last Menstrual Period (LMP)</label>
            <input type="date" id="lmp" name="lmp">
          </div>
          <div>
            <label for="gravida">Gravida (total pregnancies)</label>
            <input type="number" id="gravida" name="gravida" min="0">
          </div>
          <div>
            <label for="para">Para (live births)</label>
            <input type="number" id="para" name="para" min="0">
          </div>
        </div>
        <div class="inline-group" style="margin-top:12px;">
          <span style="font-weight:600;font-size:.9rem;">Are you currently pregnant or possibly pregnant?</span>
          <div class="radio-item">
            <input type="radio" id="pregNo" name="pregnant" value="No" checked>
            <label for="pregNo">No</label>
          </div>
          <div class="radio-item">
            <input type="radio" id="pregYes" name="pregnant" value="Yes">
            <label for="pregYes">Yes</label>
          </div>
          <div class="radio-item">
            <input type="radio" id="pregUnsure" name="pregnant" value="Unsure">
            <label for="pregUnsure">Unsure</label>
          </div>
        </div>
        <div class="inline-group">
          <span style="font-weight:600;font-size:.9rem;">Are you currently breastfeeding?</span>
          <div class="radio-item">
            <input type="radio" id="bfNo" name="breastfeeding" value="No" checked>
            <label for="bfNo">No</label>
          </div>
          <div class="radio-item">
            <input type="radio" id="bfYes" name="breastfeeding" value="Yes">
            <label for="bfYes">Yes</label>
          </div>
        </div>
        <div class="inline-group">
          <span style="font-weight:600;font-size:.9rem;">Using hormonal contraception or HRT?</span>
          <div class="radio-item">
            <input type="radio" id="hrtNo" name="hrt" value="No" checked>
            <label for="hrtNo">No</label>
          </div>
          <div class="radio-item">
            <input type="radio" id="hrtYes" name="hrt" value="Yes">
            <label for="hrtYes">Yes</label>
          </div>
        </div>
        <div class="sig-block full">
          <div>
            <label for="gynNotes">Additional Gynecologic / Obstetric Notes</label>
            <textarea id="gynNotes" name="gynNotes" rows="2"></textarea>
          </div>
        </div>
      </div>

      <!-- ========== REVIEW OF SYSTEMS (BRIEF) ========== -->
      <h2>Review of Systems (Current Symptoms)</h2>
      <p style="font-size:.9rem;margin:0 0 8px;">Check any symptoms you are currently experiencing.</p>
      <div class="check-grid three">
        <div class="checkbox-row"><input type="checkbox" id="ros_chest" name="ros" value="Chest pain"><label for="ros_chest">Chest pain</label></div>
        <div class="checkbox-row"><input type="checkbox" id="ros_sob" name="ros" value="Shortness of breath"><label for="ros_sob">Shortness of breath</label></div>
        <div class="checkbox-row"><input type="checkbox" id="ros_palp" name="ros" value="Palpitations"><label for="ros_palp">Palpitations</label></div>
        <div class="checkbox-row"><input type="checkbox" id="ros_dizzy" name="ros" value="Dizziness / Fainting"><label for="ros_dizzy">Dizziness / Fainting</label></div>
        <div class="checkbox-row"><input type="checkbox" id="ros_cough" name="ros" value="Chronic cough"><label for="ros_cough">Chronic cough</label></div>
        <div class="checkbox-row"><input type="checkbox" id="ros_fever" name="ros" value="Fever / Chills"><label for="ros_fever">Fever / Chills</label></div>
        <div class="checkbox-row"><input type="checkbox" id="ros_weight" name="ros" value="Unexplained weight change"><label for="ros_weight">Unexplained weight change</label></div>
        <div class="checkbox-row"><input type="checkbox" id="ros_bleed" name="ros" value="Easy bruising / Bleeding"><label for="ros_bleed">Easy bruising / Bleeding</label></div>
        <div class="checkbox-row"><input type="checkbox" id="ros_none" name="ros" value="None"><label for="ros_none">None of the above</label></div>
      </div>
      <div class="sig-block full">
        <div>
          <label for="rosDetails">Other current symptoms or concerns</label>
          <textarea id="rosDetails" name="rosDetails" rows="2"></textarea>
        </div>
      </div>

      <!-- ========== ADDITIONAL NOTES ========== -->
      <h2>Additional Information</h2>
      <div class="sig-block full">
        <div>
          <label for="additionalNotes">Anything else you would like the surgical / anesthesia team to know?</label>
          <textarea id="additionalNotes" name="additionalNotes" rows="3"></textarea>
        </div>
      </div>

      <!-- ========== CERTIFICATION ========== -->
      <h2>Patient Certification</h2>
      <div class="notice">
        I certify that the information provided above is true and complete to the best of my knowledge. I understand that incomplete or inaccurate information may affect my care and safety. I agree to notify Summit Surgical Center of any changes in my health status or medications prior to my procedure.
      </div>
      <div class="sig-block">
        <div>
          <label for="certSig">Patient / Guardian Signature *</label>
          <input type="text" id="certSig" name="certSig" placeholder="Type full name as signature" required>
        </div>
        <div>
          <label for="certPrint">Print Name *</label>
          <input type="text" id="certPrint" name="certPrint" required>
        </div>
        <div>
          <label for="certDate">Date *</label>
          <input type="date" id="certDate" name="certDate" required>
        </div>
        <div>
          <label for="certRelation">Relationship (if not patient)</label>
          <input type="text" id="certRelation" name="certRelation" placeholder="Self / Parent / Guardian / etc.">
        </div>
      </div>

      <div class="btn-row">
        <button type="submit">Submit Form</button>
        <button type="button" class="secondary" onclick="window.print()">Print Form</button>
      </div>

      <div class="footer-info">
      Powered by Office Intelligence
      </div>
    </div>
  </form>

  <script>
    function toggleAllergies() {
      document.getElementById('allergyDetails').style.display =
        document.getElementById('allergyYes').checked ? 'block' : 'none';
    }
    function toggleMeds() {
      document.getElementById('medTableWrap').style.display =
        document.getElementById('medYes').checked ? 'block' : 'none';
    }
    function toggleSurg() {
      document.getElementById('surgTableWrap').style.display =
        document.getElementById('surgYes').checked ? 'block' : 'none';
    }
    function toggleSmoke() {
      const show = document.getElementById('smokeFormer').checked ||
                   document.getElementById('smokeCurrent').checked;
      document.getElementById('smokeDetails').style.display = show ? 'block' : 'none';
    }
    function toggleFemaleSection() {
      const sex = document.getElementById('sex').value;
      document.getElementById('femaleSection').style.display =
        (sex === 'Female') ? 'block' : 'none';
    }

    function handleSubmit(e) {
      e.preventDefault();
      const data = new FormData(document.getElementById('historyForm'));
      console.log('Medical History Form submitted:');
      for (let [k, v] of data.entries()) {
        if (v) console.log(k + ': ' + v);
      }
      alert('Medical History Form submitted successfully!\\n\\n(This is a demonstration. In a live system the data would be securely transmitted to Summit Surgical Center.)');
      return false;
    }
  </script>
</body>
</html>`
  },
  {
    id: 'form-anesthesia',
    order: 4,
    title: 'Anesthesia Questionnaire',
    category: 'Anesthesia',
    type: 'Interactive HTML Intake Form',
    targetAudience: 'Anesthesiologist / Surgical Team',
    status: 'Pending Send',
    fileName: 'Anesthesia_Questionnaire.html',
    summary: 'Pre-anesthetic evaluation questionnaire. Reviews prior GA experience, airway anatomy (teeth, neck mobility), malignant hyperthermia risk, PONV history, recent URIs, NPO fasting times, and blood thinners.',
    description: 'Pre-anesthetic safety questionnaire for patients scheduled for general anesthesia or MAC sedation.',
    htmlTemplate: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Summit Surgical Center – Anesthesia Questionnaire</title>
  <style>
    :root { --primary: #1a365d; --accent: #2b6cb0; --border: #cbd5e0; --bg: #f7fafc; --white: #ffffff; --text: #2d3748; }
    * { box-sizing: border-box; }
    body { font-family: Georgia, "Times New Roman", serif; line-height: 1.55; color: var(--text); background: var(--bg); margin: 0; padding: 20px; }
    .page { max-width: 860px; margin: 0 auto; background: var(--white); border: 1px solid var(--border); border-radius: 12px; box-shadow: 0 4px 20px rgba(0,0,0,.08); padding: 36px 44px; }
    header { text-align: center; border-bottom: 3px solid var(--primary); padding-bottom: 18px; margin-bottom: 28px; }
    header h1 { margin: 0 0 6px; font-size: 1.55rem; color: var(--primary); letter-spacing: .02em; }
    h2 { font-size: 1.15rem; color: var(--primary); border-bottom: 2px solid var(--accent); padding-bottom: 6px; margin: 32px 0 16px; text-transform: uppercase; }
    .sig-block { display: grid; grid-template-columns: 1fr 1fr; gap: 16px 24px; margin: 12px 0 8px; }
    label { display: block; font-size: .82rem; font-weight: 600; color: #4a5568; margin-bottom: 3px; }
    input[type="text"], input[type="date"], select, textarea { width: 100%; padding: 8px 11px; border: 1px solid var(--border); border-radius: 4px; font-size: .95rem; font-family: inherit; }
    .check-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 6px 20px; margin: 8px 0 12px; }
    .checkbox-row { display: flex; align-items: center; gap: 8px; margin: 4px 0; }
    .btn-row { text-align: center; margin-top: 36px; }
    button { background: var(--primary); color: white; border: none; padding: 13px 32px; font-size: 1rem; border-radius: 6px; cursor: pointer; }
    button:hover { background: #2c5282; }
    button.secondary { background: #718096; margin-left: 10px; }
  </style>
</head>
<body>
  <div class="page">
    <header>
      <h1>ANESTHESIA QUESTIONNAIRE</h1>
      <p>For patients scheduled for general anesthesia</p>
    </header>

    <h2>Patient Identification</h2>
    <div class="sig-block">
      <div><label>Patient Full Name *</label><input type="text" id="patientName" required></div>
      <div><label>Date of Birth *</label><input type="date" id="dob" required></div>
      <div><label>Scheduled Procedure Date</label><input type="date" id="procedureDate"></div>
      <div><label>Surgeon</label><input type="text" id="surgeon"></div>
    </div>

    <h2>Prior Anesthesia Experience</h2>
    <div><label>Have you ever had general anesthesia?</label><select id="priorGA"><option value="Never">Never</option><option value="Yes">Yes</option></select></div>
    <div style="margin-top:10px;"><label>History of severe nausea/vomiting or motion sickness?</label><select id="ponv"><option value="No">No</option><option value="Yes">Yes</option></select></div>

    <h2>Airway & Related Anatomy</h2>
    <div class="check-grid">
      <div class="checkbox-row"><input type="checkbox" id="air_loose"><label for="air_loose">Loose, broken, or capped teeth</label></div>
      <div class="checkbox-row"><input type="checkbox" id="air_dentures"><label for="air_dentures">Dentures or partials</label></div>
      <div class="checkbox-row"><input type="checkbox" id="air_tmj"><label for="air_tmj">TMJ problems / limited mouth opening</label></div>
      <div class="checkbox-row"><input type="checkbox" id="air_neck"><label for="air_neck">Limited neck movement</label></div>
    </div>

    <h2>Fasting (NPO) & Blood Thinners</h2>
    <div class="sig-block">
      <div><label>Time of last solid food</label><input type="text" id="lastSolid" placeholder="e.g. Midnight"></div>
      <div><label>Time of last clear liquid</label><input type="text" id="lastClear" placeholder="e.g. 6:00 AM"></div>
    </div>

    <h2>Patient Certification</h2>
    <div class="sig-block">
      <div><label>Patient / Guardian Signature *</label><input type="text" id="certSig" required placeholder="Type full name"></div>
      <div><label>Date *</label><input type="date" id="certDate" required></div>
    </div>

    <div class="btn-row">
      <button type="submit" id="submitBtn">Submit Anesthesia Form</button>
      <button type="button" class="secondary" onclick="window.print()">Print Form</button>
    </div>
  </div>
</body>
</html>`
  },
  {
    id: 'form-billing-fee-disclosure',
    order: 5,
    title: 'Billing Fee Disclosure',
    category: 'Insurance',
    type: 'Interactive HTML Intake Form',
    targetAudience: 'Patient / Representative',
    status: 'Pending Send',
    fileName: 'Billing_Fee_Disclosure.html',
    summary: 'Informs patient of 8% third-party billing fee deducted from insurance reimbursements for facility and anesthesia services.',
    description: 'Notice and disclosure regarding 8% insurance claim processing and reimbursement management fee.',
    htmlTemplate: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Billing Fee Disclosure</title>
  <style>
    :root { --primary:#1a365d; --accent:#2b6cb0; --border:#cbd5e0; --bg:#f7fafc; --text:#2d3748; }
    * { box-sizing:border-box; }
    body { font-family:Georgia,"Times New Roman",serif; line-height:1.55; color:var(--text); background:var(--bg); margin:0; padding:0 0 40px; }
    .page { max-width:700px; margin:20px auto; background:#fff; border:1px solid var(--border); box-shadow:0 4px 16px rgba(0,0,0,.07); padding:28px 36px 36px; }
    h1 { margin:0 0 16px; font-size:1.3rem; color:var(--primary); text-align:center; border-bottom:3px solid var(--primary); padding-bottom:10px; }
    p { font-size:.95rem; margin:12px 0; }
    .highlight { background:#edf2f7; border-left:4px solid var(--accent); padding:12px 14px; margin:16px 0; font-size:.95rem; }
    .grid { display:grid; grid-template-columns:1fr 1fr; gap:12px 18px; margin:16px 0; }
    label { display:block; font-size:.78rem; font-weight:600; color:#4a5568; margin-bottom:2px; }
    input[type=text], input[type=date] { width:100%; padding:7px 10px; border:1px solid var(--border); border-radius:4px; font-size:.9rem; font-family:inherit; }
    input:focus { outline:2px solid var(--accent); border-color:var(--accent); }
    .btn-row { text-align:center; margin-top:22px; }
    button { background:var(--primary); color:#fff; border:none; padding:11px 26px; font-size:.95rem; border-radius:6px; cursor:pointer; font-family:inherit; }
    button.secondary { background:#718096; margin-left:8px; }
    .powered { text-align:center; font-size:.8rem; color:#718096; margin-top:26px; padding-top:12px; border-top:1px solid var(--border); }
    @media print { body{background:#fff;} .page{box-shadow:none;border:none;} button{display:none;} }
  </style>
</head>
<body>
<form onsubmit="event.preventDefault();alert('Submitted (demo)');">
<div class="page">
  <h1>Billing Fee Disclosure</h1>

  <p>Dear Valued Patient,</p>
  <p>We are committed to delivering high-quality care and maintaining transparent communication. As part of our ongoing effort to maintain the efficiency of our billing processes, we are informing you of our insurance billing and collection policy.</p>

  <div class="highlight">
    <strong>An 8% billing fee will be deducted from all monies collected and refunded to YOU by insurance companies for all facility and anesthesia-related services provided.</strong>
  </div>

  <p>This fee covers the third-party services required to process insurance claims, track reimbursements, and manage refunds.</p>
  <p>We understand that changes in billing practices can raise questions, and we are here to assist you. If you would like more information or have any concerns, please contact the billing office.</p>
  <p>Thank you for your continued trust and understanding.</p>

  <div class="grid">
    <div><label>Signature (Patient / Patient Representative)</label><input type="text" name="sig" required placeholder="Type full name as signature"></div>
    <div><label>Print Name</label><input type="text" name="printName" required></div>
    <div><label>Date</label><input type="date" name="date" required></div>
  </div>

  <div class="btn-row">
    <button type="submit">Submit</button>
    <button type="button" class="secondary" onclick="window.print()">Print</button>
  </div>
  <div class="powered">Powered by Office Intelligence</div>
</div>
</form>
</body>
</html>`
  },
  {
    id: 'form-credit-card-auth',
    order: 6,
    title: 'Credit Card Authorization Form',
    category: 'Insurance',
    type: 'Interactive HTML Intake Form',
    targetAudience: 'Patient / Cardholder',
    status: 'Pending Send',
    fileName: 'Credit_Card_Authorization_Form.html',
    summary: 'Authorization for additional OR and anesthesia fees ($300 per additional 15 mins) if surgical duration exceeds estimate.',
    description: 'Pre-authorization agreement to charge credit card for extended operating room and anesthesia time.',
    htmlTemplate: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Credit Card Authorization Form</title>
  <style>
    :root { --primary:#1a365d; --accent:#2b6cb0; --border:#cbd5e0; --bg:#f7fafc; --text:#2d3748; }
    * { box-sizing:border-box; }
    body { font-family:Georgia,"Times New Roman",serif; line-height:1.55; color:var(--text); background:var(--bg); margin:0; padding:0 0 40px; }
    .page { max-width:700px; margin:20px auto; background:#fff; border:1px solid var(--border); box-shadow:0 4px 16px rgba(0,0,0,.07); padding:28px 36px 36px; }
    h1 { margin:0 0 16px; font-size:1.3rem; color:var(--primary); text-align:center; border-bottom:3px solid var(--primary); padding-bottom:10px; }
    p { font-size:.92rem; margin:10px 0; }
    ul { font-size:.92rem; padding-left:1.3em; }
    .grid { display:grid; grid-template-columns:1fr 1fr; gap:12px 18px; margin:12px 0; }
    .grid.full { grid-template-columns:1fr; }
    label { display:block; font-size:.78rem; font-weight:600; color:#4a5568; margin-bottom:2px; }
    input[type=text], input[type=date], input[type=month] { width:100%; padding:7px 10px; border:1px solid var(--border); border-radius:4px; font-size:.9rem; font-family:inherit; }
    input:focus { outline:2px solid var(--accent); border-color:var(--accent); }
    .notice { background:#edf2f7; border-left:4px solid var(--accent); padding:10px 14px; margin:14px 0; font-size:.9rem; }
    .btn-row { text-align:center; margin-top:22px; }
    button { background:var(--primary); color:#fff; border:none; padding:11px 26px; font-size:.95rem; border-radius:6px; cursor:pointer; font-family:inherit; }
    button.secondary { background:#718096; margin-left:8px; }
    .powered { text-align:center; font-size:.8rem; color:#718096; margin-top:26px; padding-top:12px; border-top:1px solid var(--border); }
    @media print { body{background:#fff;} .page{box-shadow:none;border:none;} button{display:none;} }
  </style>
</head>
<body>
<form onsubmit="event.preventDefault();alert('Submitted (demo)');">
<div class="page">
  <h1>Credit Card Authorization Form</h1>

  <p>Your doctor has estimated how long your surgery will take. You agree to give permission to charge your credit card for any additional expenses of anesthesia and operating room fees in the event that your surgery takes longer than your doctor anticipated.</p>

  <div class="notice">
    <strong>Anesthesia and Operating Room rates:</strong>
    <ul style="margin:6px 0 0;">
      <li>$112.50 per 15 minutes for anesthesia</li>
      <li>$187.50 per 15 minutes for operating room fees</li>
    </ul>
    <p style="margin:8px 0 0;">With Operating Room Fees &amp; Anesthesia Fees combined, the total cost of every additional 15 minutes of surgery is <strong>$300</strong>.</p>
  </div>

  <div class="grid">
    <div><label>Date of Surgery</label><input type="date" name="surgDate" required></div>
    <div><label>Cardholder Name</label><input type="text" name="cardName" required></div>
  </div>
  <div class="grid full">
    <div><label>Credit Card Number</label><input type="text" name="cardNumber" required placeholder="•••• •••• •••• ••••" autocomplete="cc-number"></div>
  </div>
  <div class="grid three" style="grid-template-columns:1fr 1fr 1fr;">
    <div><label>Expiration Date</label><input type="text" name="exp" required placeholder="MM/YY"></div>
    <div><label>CVV / Security Code</label><input type="text" name="cvv" required placeholder="•••" autocomplete="cc-csc"></div>
    <div><label>Billing Zip Code</label><input type="text" name="zip" required></div>
  </div>

  <div class="grid">
    <div><label>Cardholder Signature</label><input type="text" name="sig" required placeholder="Type full name as signature"></div>
    <div><label>Date</label><input type="date" name="sigDate" required></div>
  </div>

  <div class="btn-row">
    <button type="submit">Submit</button>
    <button type="button" class="secondary" onclick="window.print()">Print</button>
  </div>
  <div class="powered">Powered by Office Intelligence</div>
</div>
</form>
</body>
</html>`
  },
  {
    id: 'form-patient-satisfaction-survey',
    order: 7,
    title: 'Patient Satisfaction Survey',
    category: 'Admission',
    type: 'Interactive HTML Intake Form',
    targetAudience: 'Patient',
    status: 'Pending Send',
    fileName: 'Patient_Satisfaction_Survey.html',
    summary: 'Post-operative patient experience evaluation rating appointment waiting time, staff courtesy, facility cleanliness, and quality of nursing care.',
    description: 'Feedback questionnaire assessing outpatient surgical experience, waiting times, staff care, and facility recommendations.',
    htmlTemplate: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Patient Satisfaction Survey</title>
  <style>
    :root { --primary:#1a365d; --accent:#2b6cb0; --border:#cbd5e0; --bg:#f7fafc; --text:#2d3748; }
    * { box-sizing:border-box; }
    body { font-family:Georgia,"Times New Roman",serif; line-height:1.5; color:var(--text); background:var(--bg); margin:0; padding:0 0 40px; }
    .page { max-width:860px; margin:20px auto; background:#fff; border:1px solid var(--border); box-shadow:0 4px 16px rgba(0,0,0,.07); padding:28px 36px 36px; }
    h1 { margin:0 0 12px; font-size:1.3rem; color:var(--primary); text-align:center; border-bottom:3px solid var(--primary); padding-bottom:10px; }
    p.intro { font-size:.88rem; margin:0 0 14px; }
    .q { margin:14px 0; }
    .q-label { font-size:.9rem; font-weight:600; margin-bottom:6px; }
    .likert { display:grid; grid-template-columns:2fr repeat(6,1fr); gap:4px; align-items:center; font-size:.8rem; }
    .likert span { text-align:center; font-weight:600; color:#4a5568; font-size:.7rem; }
    .likert label { display:flex; justify-content:center; }
    .likert input { width:15px; height:15px; }
    .opts { display:flex; flex-wrap:wrap; gap:12px 20px; font-size:.88rem; }
    .opts label { display:flex; align-items:center; gap:5px; font-weight:normal; }
    .grid { display:grid; grid-template-columns:1fr 1fr; gap:12px 18px; margin:10px 0; }
    label { display:block; font-size:.78rem; font-weight:600; color:#4a5568; margin-bottom:2px; }
    input[type=text], input[type=date], textarea { width:100%; padding:7px 10px; border:1px solid var(--border); border-radius:4px; font-size:.9rem; font-family:inherit; }
    textarea { resize:vertical; min-height:80px; }
    .btn-row { text-align:center; margin-top:22px; }
    button { background:var(--primary); color:#fff; border:none; padding:11px 26px; font-size:.95rem; border-radius:6px; cursor:pointer; font-family:inherit; }
    button.secondary { background:#718096; margin-left:8px; }
    .powered { text-align:center; font-size:.8rem; color:#718096; margin-top:26px; padding-top:12px; border-top:1px solid var(--border); }
    @media print { body{background:#fff;} .page{box-shadow:none;border:none;} button{display:none;} }
    @media (max-width:700px){ .likert{grid-template-columns:1fr; } .likert span{text-align:left;} }
  </style>
</head>
<body>
<form onsubmit="event.preventDefault();alert('Submitted (demo)');">
<div class="page">
  <h1>Patient Satisfaction Survey</h1>
  <p class="intro">We are pleased that you and your doctor chose our center. Your evaluation will be thoroughly reviewed and kept confidential. Please return this form within 7 days of your procedure. Indicate your overall impression based on the services you received. If your overall impression was not excellent, what would it take to make it excellent?</p>

  <div class="q">
    <div class="q-label">How many days between appointment made and day of procedure?</div>
    <div class="opts">
      <label><input type="radio" name="waitDays" value="Same day"> Same day</label>
      <label><input type="radio" name="waitDays" value="1-2"> 1–2 days</label>
      <label><input type="radio" name="waitDays" value="3-7"> 3–7 days</label>
      <label><input type="radio" name="waitDays" value="8-14"> 8–14 days</label>
      <label><input type="radio" name="waitDays" value="15+"> 15 days or greater</label>
    </div>
  </div>

  <div class="likert" style="margin-bottom:4px;">
    <span></span><span>Strongly<br>agree</span><span>Agree</span><span>Neutral</span><span>Disagree</span><span>Strongly<br>disagree</span><span>N/A</span>
  </div>

  <div class="q">
    <div class="likert">
      <span style="text-align:left;font-weight:600;">This wait time was acceptable</span>
      <label><input type="radio" name="q1" value="5"></label>
      <label><input type="radio" name="q1" value="4"></label>
      <label><input type="radio" name="q1" value="3"></label>
      <label><input type="radio" name="q1" value="2"></label>
      <label><input type="radio" name="q1" value="1"></label>
      <label><input type="radio" name="q1" value="NA"></label>
    </div>
  </div>
  <div class="q">
    <div class="likert">
      <span style="text-align:left;font-weight:600;">Pre-surgery instructions were clear and courteous</span>
      <label><input type="radio" name="q2" value="5"></label>
      <label><input type="radio" name="q2" value="4"></label>
      <label><input type="radio" name="q2" value="3"></label>
      <label><input type="radio" name="q2" value="2"></label>
      <label><input type="radio" name="q2" value="1"></label>
      <label><input type="radio" name="q2" value="NA"></label>
    </div>
  </div>
  <div class="q">
    <div class="likert">
      <span style="text-align:left;font-weight:600;">Registration was prompt and efficient</span>
      <label><input type="radio" name="q3" value="5"></label>
      <label><input type="radio" name="q3" value="4"></label>
      <label><input type="radio" name="q3" value="3"></label>
      <label><input type="radio" name="q3" value="2"></label>
      <label><input type="radio" name="q3" value="1"></label>
      <label><input type="radio" name="q3" value="NA"></label>
    </div>
  </div>
  <div class="q">
    <div class="likert">
      <span style="text-align:left;font-weight:600;">The staff was courteous</span>
      <label><input type="radio" name="q4" value="5"></label>
      <label><input type="radio" name="q4" value="4"></label>
      <label><input type="radio" name="q4" value="3"></label>
      <label><input type="radio" name="q4" value="2"></label>
      <label><input type="radio" name="q4" value="1"></label>
      <label><input type="radio" name="q4" value="NA"></label>
    </div>
  </div>
  <div class="q">
    <div class="likert">
      <span style="text-align:left;font-weight:600;">Billing and insurance clearly explained</span>
      <label><input type="radio" name="q5" value="5"></label>
      <label><input type="radio" name="q5" value="4"></label>
      <label><input type="radio" name="q5" value="3"></label>
      <label><input type="radio" name="q5" value="2"></label>
      <label><input type="radio" name="q5" value="1"></label>
      <label><input type="radio" name="q5" value="NA"></label>
    </div>
  </div>

  <div class="q">
    <div class="q-label">Minutes waited in waiting room before procedure</div>
    <div class="opts">
      <label><input type="radio" name="waitMin" value="0-15"> 0–15 min</label>
      <label><input type="radio" name="waitMin" value="16-30"> 16–30 min</label>
      <label><input type="radio" name="waitMin" value="30+"> Over 30 min</label>
    </div>
  </div>

  <div class="q">
    <div class="likert">
      <span style="text-align:left;font-weight:600;">This wait time was acceptable</span>
      <label><input type="radio" name="q6" value="5"></label>
      <label><input type="radio" name="q6" value="4"></label>
      <label><input type="radio" name="q6" value="3"></label>
      <label><input type="radio" name="q6" value="2"></label>
      <label><input type="radio" name="q6" value="1"></label>
      <label><input type="radio" name="q6" value="NA"></label>
    </div>
  </div>
  <div class="q">
    <div class="likert">
      <span style="text-align:left;font-weight:600;">Clear explanation of any delay</span>
      <label><input type="radio" name="q7" value="5"></label>
      <label><input type="radio" name="q7" value="4"></label>
      <label><input type="radio" name="q7" value="3"></label>
      <label><input type="radio" name="q7" value="2"></label>
      <label><input type="radio" name="q7" value="1"></label>
      <label><input type="radio" name="q7" value="NA"></label>
    </div>
  </div>
  <div class="q">
    <div class="likert">
      <span style="text-align:left;font-weight:600;">Clear explanation of sedation plan</span>
      <label><input type="radio" name="q8" value="5"></label>
      <label><input type="radio" name="q8" value="4"></label>
      <label><input type="radio" name="q8" value="3"></label>
      <label><input type="radio" name="q8" value="2"></label>
      <label><input type="radio" name="q8" value="1"></label>
      <label><input type="radio" name="q8" value="NA"></label>
    </div>
  </div>

  <p style="font-weight:700;font-size:.9rem;margin:16px 0 6px;">The Facility Staff:</p>
  <div class="q"><div class="likert"><span style="text-align:left;font-weight:600;">Responded efficiently to questions/needs</span>
    <label><input type="radio" name="q9" value="5"></label><label><input type="radio" name="q9" value="4"></label><label><input type="radio" name="q9" value="3"></label><label><input type="radio" name="q9" value="2"></label><label><input type="radio" name="q9" value="1"></label><label><input type="radio" name="q9" value="NA"></label></div></div>
  <div class="q"><div class="likert"><span style="text-align:left;font-weight:600;">Showed concern for my comfort</span>
    <label><input type="radio" name="q10" value="5"></label><label><input type="radio" name="q10" value="4"></label><label><input type="radio" name="q10" value="3"></label><label><input type="radio" name="q10" value="2"></label><label><input type="radio" name="q10" value="1"></label><label><input type="radio" name="q10" value="NA"></label></div></div>
  <div class="q"><div class="likert"><span style="text-align:left;font-weight:600;">Showed concern for my privacy</span>
    <label><input type="radio" name="q11" value="5"></label><label><input type="radio" name="q11" value="4"></label><label><input type="radio" name="q11" value="3"></label><label><input type="radio" name="q11" value="2"></label><label><input type="radio" name="q11" value="1"></label><label><input type="radio" name="q11" value="NA"></label></div></div>
  <div class="q"><div class="likert"><span style="text-align:left;font-weight:600;">Maintained appropriate confidentiality</span>
    <label><input type="radio" name="q12" value="5"></label><label><input type="radio" name="q12" value="4"></label><label><input type="radio" name="q12" value="3"></label><label><input type="radio" name="q12" value="2"></label><label><input type="radio" name="q12" value="1"></label><label><input type="radio" name="q12" value="NA"></label></div></div>
  <div class="q"><div class="likert"><span style="text-align:left;font-weight:600;">Clear explanation of discharge instructions</span>
    <label><input type="radio" name="q13" value="5"></label><label><input type="radio" name="q13" value="4"></label><label><input type="radio" name="q13" value="3"></label><label><input type="radio" name="q13" value="2"></label><label><input type="radio" name="q13" value="1"></label><label><input type="radio" name="q13" value="NA"></label></div></div>
  <div class="q"><div class="likert"><span style="text-align:left;font-weight:600;">Quality of nursing care was good</span>
    <label><input type="radio" name="q14" value="5"></label><label><input type="radio" name="q14" value="4"></label><label><input type="radio" name="q14" value="3"></label><label><input type="radio" name="q14" value="2"></label><label><input type="radio" name="q14" value="1"></label><label><input type="radio" name="q14" value="NA"></label></div></div>
  <div class="q"><div class="likert"><span style="text-align:left;font-weight:600;">The facility was clean</span>
    <label><input type="radio" name="q15" value="5"></label><label><input type="radio" name="q15" value="4"></label><label><input type="radio" name="q15" value="3"></label><label><input type="radio" name="q15" value="2"></label><label><input type="radio" name="q15" value="1"></label><label><input type="radio" name="q15" value="NA"></label></div></div>

  <div class="q">
    <div class="q-label">Would you recommend this center to a friend needing outpatient surgery?</div>
    <div class="opts">
      <label><input type="radio" name="recommend" value="Yes"> Yes</label>
      <label><input type="radio" name="recommend" value="No"> No</label>
    </div>
  </div>

  <div class="q">
    <label>Comments (positive or negative)</label>
    <textarea name="comments" rows="4"></textarea>
  </div>

  <div class="grid">
    <div><label>Patient Name</label><input type="text" name="patientName"></div>
    <div><label>Physician’s Name</label><input type="text" name="physician"></div>
    <div><label>Date of Procedure</label><input type="date" name="procDate"></div>
  </div>

  <div class="btn-row">
    <button type="submit">Submit</button>
    <button type="button" class="secondary" onclick="window.print()">Print</button>
  </div>
  <div class="powered">Powered by Office Intelligence</div>
</div>
</form>
</body>
</html>`
  }
];
