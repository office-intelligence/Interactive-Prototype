import React from 'react';
import { 
  Home, 
  Calendar, 
  FileText, 
  CreditCard, 
  Settings, 
  Sparkles, 
  Activity,
  ChevronRight,
  ChevronLeft,
  Layout,
  PanelLeftOpen,
  PanelLeftClose
} from 'lucide-react';

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onOpenAIChat: () => void;
  needsAttentionCount: number;
  isCollapsed?: boolean;
  onToggleCollapse?: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  setActiveTab,
  onOpenAIChat,
  needsAttentionCount,
  isCollapsed = false,
  onToggleCollapse,
}) => {
  const navItems: { id: string; label: string; icon: any; badge?: number }[] = [
    { id: 'home', label: 'Home', icon: Home },
    { id: 'schedule', label: 'Schedule', icon: Calendar },
    { id: 'patients', label: 'Patient Chart', icon: FileText },
    { id: 'billing', label: 'Billing & Invoices', icon: CreditCard },
    { id: 'admin', label: 'Administration', icon: Settings },
    { id: 'template', label: 'Blank Template', icon: Layout },
  ];

  if (isCollapsed) {
    return (
      <aside className="h-screen w-16 bg-white border-r border-stone-200/80 flex flex-col justify-between items-center shrink-0 select-none py-4 px-2 sticky top-0 z-30 transition-all duration-300 shadow-2xs">
        {/* Top Icon Header with Expand Toggle */}
        <div className="flex flex-col items-center gap-4 w-full">
          <button
            onClick={onToggleCollapse}
            className="w-10 h-10 rounded-xl bg-blue-600 hover:bg-blue-700 text-white flex items-center justify-center shadow-md transition-all hover:scale-105 active:scale-95 cursor-pointer relative group"
            title="Expand Navigation Drawer"
          >
            <Activity className="w-5 h-5 text-blue-100 group-hover:hidden" />
            <PanelLeftOpen className="w-5 h-5 text-blue-100 hidden group-hover:block animate-in fade-in" />
            
            {/* Tooltip */}
            <span className="absolute left-14 top-1/2 -translate-y-1/2 px-2.5 py-1 bg-blue-900 text-white text-[11px] font-bold rounded-lg shadow-xl opacity-0 pointer-events-none group-hover:opacity-100 transition-opacity whitespace-nowrap z-50">
              Expand Navigation
            </span>
          </button>

          <div className="w-8 h-[1px] bg-stone-200/80 my-1" />

          {/* Icon Navigation List */}
          <nav className="flex flex-col items-center gap-2 w-full">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id)}
                  className={`relative w-11 h-11 rounded-xl flex items-center justify-center transition-all cursor-pointer group ${
                    isActive
                      ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30 ring-1 ring-blue-400/50'
                      : 'text-stone-500 hover:text-stone-900 hover:bg-stone-100'
                  }`}
                >
                  <Icon className="w-5 h-5" />

                  {/* Badge Notification Indicator */}
                  {item.badge && (
                    <span className="absolute top-1.5 right-1.5 w-2.5 h-2.5 bg-blue-700 rounded-full border-2 border-white ring-1 ring-blue-300" />
                  )}

                  {/* Hover Tooltip Label */}
                  <span className="absolute left-14 top-1/2 -translate-y-1/2 px-2.5 py-1 bg-blue-900 text-white text-[11px] font-bold rounded-lg shadow-xl opacity-0 pointer-events-none group-hover:opacity-100 transition-opacity whitespace-nowrap z-50 flex items-center gap-1.5">
                    <span>{item.label}</span>
                    {item.badge && (
                      <span className="px-1.5 py-0.2 bg-blue-500 text-white rounded-full text-[9px] font-bold">
                        {item.badge}
                      </span>
                    )}
                  </span>
                </button>
              );
            })}
          </nav>
        </div>

        {/* Bottom Profile Avatar Icon */}
        <div className="flex flex-col items-center gap-2 w-full pt-3 border-t border-stone-200/80">
          <button
            onClick={onToggleCollapse}
            className="w-10 h-10 rounded-full bg-blue-600 text-white font-bold text-xs flex items-center justify-center shadow-xs cursor-pointer group relative hover:ring-2 hover:ring-blue-400 transition-all"
          >
            KT
            <span className="absolute left-14 top-1/2 -translate-y-1/2 px-2.5 py-1 bg-blue-900 text-white text-[11px] font-bold rounded-lg shadow-xl opacity-0 pointer-events-none group-hover:opacity-100 transition-opacity whitespace-nowrap z-50">
              Dr. Kevin Tehrani
            </span>
          </button>
        </div>
      </aside>
    );
  }

  return (
    <>
      {/* Backdrop for click-outside on small screens */}
      <div 
        onClick={onToggleCollapse}
        className="fixed inset-0 z-40 bg-slate-900/30 backdrop-blur-xs transition-opacity lg:hidden"
      />

      <aside className="fixed lg:sticky top-0 left-0 z-50 h-screen w-64 bg-white border-r border-stone-200/80 flex flex-col justify-between shrink-0 select-none p-4 shadow-2xl lg:shadow-none transition-all duration-300 animate-in slide-in-from-left">
        <div className="space-y-6 overflow-y-auto">
          {/* Brand Header with Collapse Button */}
          <div className="px-1 py-1">
            <div className="flex items-start justify-between gap-2">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-blue-600 via-blue-700 to-blue-800 flex items-center justify-center text-white shadow-md shadow-blue-600/20 shrink-0">
                  <Activity className="w-5 h-5 text-blue-100" />
                </div>
                <div>
                  <h1 className="font-semibold text-stone-900 tracking-tight text-sm leading-snug flex items-center gap-1.5">
                    Office Intelligence
                  </h1>
                  <div className="flex items-center gap-1 text-[11px] font-semibold text-blue-800">
                    <Sparkles className="w-3 h-3 text-blue-600" />
                    <span>Nightingale AI</span>
                  </div>
                </div>
              </div>

              {/* Collapse Arrow Button */}
              <button
                onClick={onToggleCollapse}
                className="p-1.5 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-600 hover:text-stone-900 transition-colors cursor-pointer shrink-0"
                title="Collapse to Icon Sidebar"
              >
                <PanelLeftClose className="w-5 h-5 text-stone-600" />
              </button>
            </div>

            {/* Facility Selection Pill */}
            <div className="mt-4 p-2.5 bg-blue-50/60 rounded-xl border border-blue-200/80 shadow-2xs hover:border-blue-400 transition-colors cursor-pointer group">
              <div className="text-xs font-semibold text-blue-950 flex items-center justify-between">
                <span>{activeTab === 'template' ? 'Practice Name' : 'Summit Surgical Center'}</span>
                <span className="w-2 h-2 rounded-full bg-blue-600 animate-pulse"></span>
              </div>
              <div className="text-[11px] text-blue-700 mt-0.5 flex items-center justify-between">
                <span>Beverly Hills, California</span>
                <ChevronRight className="w-3 h-3 text-blue-400 group-hover:translate-x-0.5 transition-transform" />
              </div>
            </div>
          </div>

          {/* Navigation Items */}
          <div className="space-y-1">
            <div className="px-3 text-[10px] font-bold text-stone-400 tracking-wider uppercase mb-1">
              Workspace Navigation
            </div>
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    setActiveTab(item.id);
                  }}
                  className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-medium transition-all cursor-pointer ${
                    isActive
                      ? 'bg-blue-600 text-white shadow-sm shadow-blue-600/20 font-semibold'
                      : 'text-stone-700 hover:text-stone-950 hover:bg-stone-100'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <Icon className={`w-4 h-4 ${isActive ? 'text-blue-100' : 'text-stone-500'}`} />
                    <span>{item.label}</span>
                  </div>
                  {item.badge && (
                    <span
                      className={`px-1.5 py-0.5 rounded-full text-[10px] font-bold ${
                        isActive
                          ? 'bg-blue-700 text-white'
                          : 'bg-blue-100 text-blue-900 border border-blue-200'
                      }`}
                    >
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>

        {/* User Footer Profile */}
        <div className="pt-4 pb-1 border-t border-stone-200/80 flex items-center justify-between px-1 bg-white">
          <div className="flex items-center gap-2.5">
            <div className="w-8.5 h-8.5 rounded-full bg-blue-600 text-white font-bold text-xs flex items-center justify-center shadow-xs shrink-0">
              KT
            </div>
            <div className="overflow-hidden text-left">
              <p className="text-xs font-bold text-stone-900 truncate leading-snug">
                Kevin Tehrani, MD
              </p>
              <p className="text-[10px] font-medium text-stone-500 truncate">Owner/Administrator</p>
            </div>
          </div>
        </div>
      </aside>
    </>
  );
};


