import React, { useState } from 'react';
import { 
  Building2, 
  ShieldCheck, 
  FileText, 
  Sparkles, 
  UploadCloud, 
  UserCheck, 
  Award, 
  FileCheck, 
  Scale, 
  Users, 
  Truck, 
  BookOpen, 
  Stethoscope, 
  Wrench, 
  Lock, 
  CheckCircle2, 
  AlertCircle, 
  Clock, 
  Plus, 
  Search, 
  Download, 
  ChevronRight, 
  RefreshCw, 
  Edit3, 
  Save, 
  Server, 
  Activity, 
  Phone, 
  MapPin, 
  Mail, 
  FileSpreadsheet, 
  Database,
  Sliders,
  Check,
  Eye,
  Trash2,
  BellRing,
  Key,
  ShieldAlert
} from 'lucide-react';

interface AdministrationPageProps {
  onShowToast?: (msg: string) => void;
}

export const AdministrationPage: React.FC<AdministrationPageProps> = ({ onShowToast }) => {
  // Practice Setup Form State
  const [practiceInfo, setPracticeInfo] = useState({
    practiceName: 'Summit Surgical Center & Institute',
    legalEntity: 'Summit Surgical Center, LLC',
    groupNpi: '1982736450',
    taxId: '95-4829103',
    cliaId: '05D2091823',
    aaaasfCode: 'AAAASF-S-09182',
    stateLicense: 'CA-SURG-88190',
    address: '435 N Bedford Dr, Suite 300',
    cityStateZip: 'Beverly Hills, CA 90210',
    phone: '(310) 859-2000',
    fax: '(310) 859-2001',
    afterHoursPhone: '(310) 859-2009',
    email: 'admin@summitsurgicalcenter.com',
    operatingHours: 'Mon - Fri: 6:30 AM - 5:00 PM',
  });

  const [isEditingSetup, setIsEditingSetup] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);

  // EMR Integration Toggles
  const [integrations, setIntegrations] = useState({
    eRx: true,
    questLabs: true,
    billingEdi: true,
    patientSms: true,
    intakeKiosk: true,
    prescriptionMonitoring: true,
  });

  const toggleIntegration = (key: keyof typeof integrations) => {
    setIntegrations(prev => {
      const updated = { ...prev, [key]: !prev[key] };
      if (onShowToast) onShowToast(`Integration setting updated.`);
      return updated;
    });
  };

  // Provider Roster State
  const [providers, setProviders] = useState([
    { id: 'p1', name: 'Stuart Linder, MD', title: 'Attending Plastic Surgeon', npi: '1827364910', dea: 'BL9827361', license: 'CA C52918', exp: '10/2027', status: 'Active' },
    { id: 'p2', name: 'David Chen, MD', title: 'Medical Director & Anesthesiologist', npi: '1029384756', dea: 'BC1029384', license: 'CA C61029', exp: '08/2026', status: 'Active' },
    { id: 'p3', name: 'Elena Rostova, FNP-C', title: 'Nurse Practitioner', npi: '1928374650', dea: 'BR1928374', license: 'CA NP99120', exp: '03/2027', status: 'Active' },
    { id: 'p4', name: 'Marcus Vance, RN', title: 'OR Nurse Coordinator', npi: 'N/A', dea: 'N/A', license: 'CA RN88123', exp: '11/2026', status: 'Active' },
  ]);

  // Document Upload State
  const [uploadCategory, setUploadCategory] = useState('Employee Files');
  const [isDragging, setIsDragging] = useState(false);
  const [uploadedFilesList, setUploadedFilesList] = useState<Array<{ name: string; category: string; date: string; size: string }>>([]);

  // Category Tabs State
  const [activeDocTab, setActiveDocTab] = useState<
    | "Employee Files"
    | "Doctor's Credentials"
    | "Accreditation"
    | "Policy and Procedures"
    | "Legal"
    | "HR"
    | "Vendors"
    | "Manuals"
    | "Equipment Records"
    | "Financial & Audit"
  >("Employee Files");

  const [docSearchQuery, setDocSearchQuery] = useState('');

  const docTabs = [
    { id: "Employee Files", label: "Employee Files", icon: Users, count: 14 },
    { id: "Doctor's Credentials", label: "Doctor's Credentials", icon: Stethoscope, count: 8 },
    { id: "Accreditation", label: "Accreditation", icon: ShieldCheck, count: 5 },
    { id: "Policy and Procedures", label: "Policy & Procedures", icon: FileText, count: 18 },
    { id: "Legal", label: "Legal", icon: Scale, count: 6 },
    { id: "HR", label: "HR", icon: UserCheck, count: 12 },
    { id: "Vendors", label: "Vendors", icon: Truck, count: 9 },
    { id: "Manuals", label: "Manuals", icon: BookOpen, count: 11 },
    { id: "Equipment Records", label: "Equipment Records", icon: Wrench, count: 15 },
    { id: "Financial & Audit", label: "Financial & Audit", icon: FileCheck, count: 10 },
  ] as const;

  // Sample Category Files Database
  const sampleCategoryFiles: Record<
    string,
    {
      aiSummary: string;
      files: Array<{
        id: string;
        title: string;
        type: string;
        uploader: string;
        date: string;
        size: string;
        status: 'Active' | 'Verified' | 'Expiring Soon' | 'Pending Review';
        expDate?: string;
      }>;
    }
  > = {
    "Employee Files": {
      aiSummary: "Nightingale AI Audit: 14 active employee personnel binders verified. I-9 verification complete for 100% of staff. All mandatory California OSHA and HIPAA annual training modules completed for Q2 2026.",
      files: [
        { id: 'ef-1', title: 'I-9 Employment Eligibility Verification Master Log', type: 'PDF Scan', uploader: 'Sarah Jenkins (HR)', date: 'May 12, 2026', size: '2.4 MB', status: 'Verified' },
        { id: 'ef-2', title: 'Staff Annual HIPAA Privacy & Security Training Certificates', type: 'PDF Bundle', uploader: 'Sarah Jenkins (HR)', date: 'Jun 01, 2026', size: '14.8 MB', status: 'Active' },
        { id: 'ef-3', title: 'RN & Surgical Tech Annual Competency Assessments', type: 'DOCX Signed', uploader: 'Marcus Vance, RN', date: 'Apr 20, 2026', size: '1.8 MB', status: 'Active' },
        { id: 'ef-4', title: 'Staff Immunization & Hepatitis B Vaccination Records', type: 'PDF Scan', uploader: 'Sarah Jenkins (HR)', date: 'Jan 15, 2026', size: '3.1 MB', status: 'Verified' },
      ],
    },
    "Doctor's Credentials": {
      aiSummary: "Nightingale AI Audit: All 4 surgical center attending physicians and medical directors hold active California medical licenses and DEA registration. Dr. Chen's ACLS certification renewal is due in 32 days (scheduled for Aug 28). Malpractice coverage binder current through July 2027.",
      files: [
        { id: 'dc-1', title: 'Dr. Stuart Linder - Medical License & DEA Certificate 2026-2027', type: 'PDF Signed', uploader: 'Dr. Stuart Linder', date: 'Jan 10, 2026', size: '1.2 MB', status: 'Active', expDate: '10/2027' },
        { id: 'dc-2', title: 'Dr. David Chen - CA Medical License & Anesthesia Board Cert', type: 'PDF Signed', uploader: 'Dr. David Chen', date: 'Feb 14, 2026', size: '2.1 MB', status: 'Expiring Soon', expDate: '08/2026' },
        { id: 'dc-3', title: 'Comprehensive Malpractice Insurance Certificate ($5M/$10M)', type: 'PDF Verified', uploader: 'Practice Admin', date: 'Jul 01, 2026', size: '850 KB', status: 'Verified', expDate: '07/2027' },
        { id: 'dc-4', title: 'Cedars-Sinai & UCLA Hospital Staff Privileges Documentation', type: 'PDF Scan', uploader: 'Dr. Stuart Linder', date: 'Mar 18, 2026', size: '4.5 MB', status: 'Active' },
      ],
    },
    "Accreditation": {
      aiSummary: "Nightingale AI Audit: AAAASF Surgical Facility Accreditation certificate AAAASF-S-09182 is in full standing. Triennial inspection successfully passed with 100% compliance. Next site survey scheduled for September 2027.",
      files: [
        { id: 'ac-1', title: 'AAAASF Accreditation Certificate of Excellence (Class C-M)', type: 'PDF Official', uploader: 'Dr. David Chen', date: 'Sep 15, 2024', size: '3.8 MB', status: 'Active', expDate: '09/2027' },
        { id: 'ac-2', title: 'State Department of Public Health Surgery Center Permit', type: 'PDF Official', uploader: 'Practice Admin', date: 'Jan 05, 2026', size: '1.1 MB', status: 'Active' },
        { id: 'ac-3', title: 'CLIA Certificate of Waiver (Point-of-Care Testing)', type: 'PDF Official', uploader: 'Elena Rostova, FNP', date: 'Nov 12, 2025', size: '920 KB', status: 'Verified', expDate: '11/2027' },
        { id: 'ac-4', title: '2025 AAAASF Inspection Report & Correction Verification', type: 'PDF Final', uploader: 'Practice Admin', date: 'Oct 02, 2024', size: '5.2 MB', status: 'Verified' },
      ],
    },
    "Policy and Procedures": {
      aiSummary: "Nightingale AI Audit: 18 operational P&P modules updated for 2026 CMS Ambulatory Surgery standards. Infection Control manual revised on June 10, 2026 following updated CDC sterilization recommendations.",
      files: [
        { id: 'pp-1', title: 'Infection Control & Sterile Processing Master Protocol 2026', type: 'PDF Master', uploader: 'Marcus Vance, RN', date: 'Jun 10, 2026', size: '4.7 MB', status: 'Active' },
        { id: 'pp-2', title: 'Malignant Hyperthermia & OR Emergency Crisis Protocol', type: 'PDF Guide', uploader: 'Dr. David Chen', date: 'Feb 02, 2026', size: '2.9 MB', status: 'Verified' },
        { id: 'pp-3', title: 'Pre-Operative Patient Intake & Discharge Criteria Standards', type: 'DOCX Approved', uploader: 'Practice Admin', date: 'Jan 22, 2026', size: '1.4 MB', status: 'Active' },
        { id: 'pp-4', title: 'Controlled Substance Ordering, Storage & Waste Discard P&P', type: 'PDF Signed', uploader: 'Dr. David Chen', date: 'Mar 30, 2026', size: '3.3 MB', status: 'Verified' },
      ],
    },
    "Legal": {
      aiSummary: "Nightingale AI Audit: Summit Surgical Center LLC operating agreement and facility lease binder verified. HIPAA Business Associate Agreements (BAAs) on file for all cloud vendors, billing clearinghouses, and lab partners.",
      files: [
        { id: 'lg-1', title: 'Summit Surgical Center LLC Articles of Organization & Lease', type: 'PDF Signed', uploader: 'Legal Counsel', date: 'Jan 15, 2022', size: '8.4 MB', status: 'Active' },
        { id: 'lg-2', title: 'Master BAA Registry (Surescripts, Quest, Change Healthcare)', type: 'PDF Bundle', uploader: 'Practice Admin', date: 'Jan 10, 2026', size: '6.1 MB', status: 'Verified' },
        { id: 'lg-3', title: 'Patient Informed Consent & Financial Liability Legal Templates', type: 'PDF Master', uploader: 'Legal Counsel', date: 'Apr 05, 2026', size: '2.2 MB', status: 'Active' },
      ],
    },
    "HR": {
      aiSummary: "Nightingale AI Audit: Employee handbook updated for 2026 California labor compliance. Emergency contact records and worker's compensation insurance policy active through December 2026.",
      files: [
        { id: 'hr-1', title: '2026 California Employee Handbook & Acknowledgement Forms', type: 'PDF Master', uploader: 'Sarah Jenkins (HR)', date: 'Jan 02, 2026', size: '5.6 MB', status: 'Active' },
        { id: 'hr-2', title: 'Workers Compensation Liability Insurance Policy Certificate', type: 'PDF Signed', uploader: 'Sarah Jenkins (HR)', date: 'Dec 15, 2025', size: '1.9 MB', status: 'Verified', expDate: '12/2026' },
        { id: 'hr-3', title: 'Staff Payroll, Overtime & On-Call Shift Compensation Policy', type: 'PDF Guide', uploader: 'Sarah Jenkins (HR)', date: 'Feb 18, 2026', size: '1.3 MB', status: 'Active' },
      ],
    },
    "Vendors": {
      aiSummary: "Nightingale AI Audit: 9 primary medical supply and pharmaceutical vendor contracts active. Mentor Implant distribution agreement confirmed through 2028. Anesthesia drug supplier pipeline verified.",
      files: [
        { id: 'vn-1', title: 'Mentor Worldwide LLC Silicone/Gel Implant Distribution Contract', type: 'PDF Signed', uploader: 'Supply Chain Mgr', date: 'Aug 10, 2025', size: '3.9 MB', status: 'Active', expDate: '08/2028' },
        { id: 'vn-2', title: 'McKesson Medical-Surgical Supply Agreement & Pricing Tier', type: 'PDF Contract', uploader: 'Supply Chain Mgr', date: 'Jan 20, 2026', size: '4.2 MB', status: 'Active' },
        { id: 'vn-3', title: 'MedPro Medical Waste Disposal & Sharps Service Agreement', type: 'PDF Signed', uploader: 'Practice Admin', date: 'Nov 01, 2025', size: '1.7 MB', status: 'Verified' },
      ],
    },
    "Manuals": {
      aiSummary: "Nightingale AI Audit: Equipment user guides and emergency operating manuals compiled for all OR suites. Includes Steris autoclave, Mindray anesthesia machines, and Stryker laparoscopy towers.",
      files: [
        { id: 'mn-1', title: 'Mindray A7 Anesthesia Delivery System Technical Manual', type: 'PDF Technical', uploader: 'BioMed Tech', date: 'Mar 10, 2025', size: '18.4 MB', status: 'Active' },
        { id: 'mn-2', title: 'Steris Century V116 Steam Sterilizer Operator Guide', type: 'PDF Technical', uploader: 'BioMed Tech', date: 'Jan 15, 2025', size: '12.1 MB', status: 'Active' },
        { id: 'mn-3', title: 'Stryker System 8 Power Tools & OR Light Tower Manual', type: 'PDF Technical', uploader: 'BioMed Tech', date: 'Jun 22, 2025', size: '9.8 MB', status: 'Active' },
      ],
    },
    "Equipment Records": {
      aiSummary: "Nightingale AI Audit: 15 biomedical devices inspected and calibrated by certified BioMed technicians. Next routine preventive maintenance round scheduled for October 2026.",
      files: [
        { id: 'er-1', title: 'OR 1 & OR 2 Anesthesia Machine Calibration & Pressure Certs', type: 'PDF Certified', uploader: 'Pacific BioMed Services', date: 'Apr 12, 2026', size: '3.2 MB', status: 'Verified', expDate: '10/2026' },
        { id: 'er-2', title: 'Sterilizer Autoclave Spore Testing Log & Biological Indicators', type: 'XLSX Sheet', uploader: 'Marcus Vance, RN', date: 'Jul 20, 2026', size: '640 KB', status: 'Active' },
        { id: 'er-3', title: 'Emergency Backup Generator Load Test & Fuel Certificate', type: 'PDF Inspection', uploader: 'Facilities Mgr', date: 'May 05, 2026', size: '2.3 MB', status: 'Verified' },
      ],
    },
    "Financial & Audit": {
      aiSummary: "Nightingale AI Audit: Annual CPA financial review and Medicare billing compliance audit concluded with zero high-risk findings. Merchant processing and insurance fee schedules synced.",
      files: [
        { id: 'fa-1', title: '2025 CPA Certified Financial Audit & Balance Statement', type: 'PDF Audit', uploader: 'Finance Director', date: 'Mar 15, 2026', size: '6.8 MB', status: 'Verified' },
        { id: 'fa-2', title: 'CMS Medicare & Commercial Insurance Fee Schedule Master 2026', type: 'XLSX Master', uploader: 'Billing Mgr', date: 'Jan 01, 2026', size: '1.5 MB', status: 'Active' },
        { id: 'fa-3', title: 'Merchant Account & Credit Card Processing PCI-DSS Compliance', type: 'PDF Cert', uploader: 'Finance Director', date: 'Feb 10, 2026', size: '890 KB', status: 'Active' },
      ],
    },
  };

  const currentTabContent = sampleCategoryFiles[activeDocTab] || sampleCategoryFiles['Employee Files'];

  const filteredFiles = currentTabContent.files.filter(
    f => f.title.toLowerCase().includes(docSearchQuery.toLowerCase()) || f.uploader.toLowerCase().includes(docSearchQuery.toLowerCase())
  );

  const handleSaveSetup = (e: React.FormEvent) => {
    e.preventDefault();
    setIsEditingSetup(false);
    setSaveSuccess(true);
    if (onShowToast) onShowToast('Practice setup & EMR configuration saved successfully!');
    setTimeout(() => setSaveSuccess(false), 3000);
  };

  const handleFileUploadSim = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const fileName = e.target.files[0].name;
      const sizeMb = (e.target.files[0].size / (1024 * 1024)).toFixed(1) + ' MB';
      
      const newFileObj = {
        name: fileName,
        category: uploadCategory,
        date: 'Today',
        size: sizeMb
      };

      setUploadedFilesList(prev => [newFileObj, ...prev]);
      if (onShowToast) onShowToast(`Uploaded ${fileName} to ${uploadCategory} repository.`);
    }
  };

  return (
    <div className="w-full space-y-6 animate-in fade-in duration-300">

      {/* 1. Header Banner & Page Title */}
      <div className="bg-white p-6 rounded-2xl border border-stone-200/90 shadow-2xs flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2.5 text-stone-900 font-bold text-lg">
            <div className="p-2 rounded-xl bg-slate-900 text-white shadow-2xs">
              <Building2 className="w-5 h-5" />
            </div>
            <h2>Administration & Practice Setup</h2>
          </div>
          <p className="text-xs text-stone-500 mt-1">
            Complete facility governance, provider credentialing, EMR configuration, and document repository.
          </p>
        </div>

        {/* Quick Action Controls */}
        <div className="flex items-center gap-2.5">
          <button
            onClick={() => {
              if (onShowToast) onShowToast('Running Nightingale AI Administrative System Audit...');
            }}
            className="px-3.5 py-2 rounded-xl bg-stone-100 hover:bg-stone-200/80 text-stone-800 text-xs font-semibold flex items-center gap-1.5 transition-colors shadow-2xs cursor-pointer border border-stone-200"
          >
            <RefreshCw className="w-3.5 h-3.5 text-stone-600" />
            <span>Run System Audit</span>
          </button>

          <button
            onClick={() => {
              const el = document.getElementById('practice-setup-section');
              if (el) el.scrollIntoView({ behavior: 'smooth' });
            }}
            className="px-3.5 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold flex items-center gap-1.5 transition-colors shadow-2xs cursor-pointer"
          >
            <Sliders className="w-3.5 h-3.5" />
            <span>Configure Practice</span>
          </button>
        </div>
      </div>

      {/* 2. SECTION: Nightingale AI Administrative Brief (Soft Indigo/Purple Tint) */}
      <div className="bg-gradient-to-br from-indigo-50/80 via-white to-purple-50/60 border border-indigo-100 rounded-2xl p-6 shadow-2xs space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-indigo-100/80 pb-3">
          <div className="flex items-center gap-2.5 text-indigo-950 font-bold text-base">
            <div className="w-7 h-7 rounded-lg bg-indigo-600 text-white flex items-center justify-center shadow-2xs">
              <Sparkles className="w-4 h-4" />
            </div>
            <span>Nightingale AI Administrative Brief</span>
          </div>

          <div className="flex items-center gap-2">
            <span className="px-3 py-1 rounded-full bg-emerald-100 text-emerald-900 border border-emerald-200 text-xs font-bold shadow-2xs flex items-center gap-1">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-700" />
              <span>96% Admin Compliance Score</span>
            </span>
            <span className="px-3 py-1 rounded-full bg-indigo-100 text-indigo-900 border border-indigo-200 text-xs font-bold shadow-2xs">
              Daily Sweep: Active
            </span>
          </div>
        </div>

        {/* Narrative & Metrics Row */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-center">
          <div className="lg:col-span-8 space-y-2">
            <p className="text-xs text-stone-700 font-medium leading-relaxed">
              Nightingale AI completed the daily facility sweep for <strong>Summit Surgical Center</strong>. Facility accreditation AAAASF-S-09182 is in good standing. All 4 attending physician credentials are verified with active CA medical licenses. One upcoming renewal detected: Dr. David Chen’s ACLS certification expires in 32 days. CLIA waiver and OSHA safety logs are current for Q3 2026.
            </p>
            
            <div className="flex flex-wrap items-center gap-2 pt-1">
              <button
                onClick={() => {
                  if (onShowToast) onShowToast('Exporting official Credentialing & Accreditation Binder...');
                }}
                className="px-3 py-1.5 rounded-lg bg-white hover:bg-stone-50 border border-stone-200 text-stone-800 text-xs font-bold flex items-center gap-1.5 shadow-2xs transition-colors cursor-pointer"
              >
                <Download className="w-3.5 h-3.5 text-indigo-600" />
                <span>Export Credentialing Binder</span>
              </button>

              <button
                onClick={() => {
                  if (onShowToast) onShowToast('EDI Gateway synced with Medicare & Commercial clearinghouse.');
                }}
                className="px-3 py-1.5 rounded-lg bg-white hover:bg-stone-50 border border-stone-200 text-stone-800 text-xs font-bold flex items-center gap-1.5 shadow-2xs transition-colors cursor-pointer"
              >
                <Server className="w-3.5 h-3.5 text-indigo-600" />
                <span>Sync Clearinghouse EDI</span>
              </button>
            </div>
          </div>

          {/* Quick AI Alert Cards */}
          <div className="lg:col-span-4 space-y-2">
            <div className="p-3 bg-white/90 rounded-xl border border-indigo-100 text-xs space-y-1 shadow-2xs">
              <div className="flex items-center justify-between font-bold text-stone-900">
                <span className="flex items-center gap-1 text-amber-700">
                  <AlertCircle className="w-3.5 h-3.5" />
                  Dr. Chen ACLS Renewal
                </span>
                <span className="text-[10px] text-stone-500 font-semibold">32 Days</span>
              </div>
              <p className="text-[11px] text-stone-600">Renewal course scheduled for Aug 28, 2026.</p>
            </div>

            <div className="p-3 bg-white/90 rounded-xl border border-indigo-100 text-xs space-y-1 shadow-2xs">
              <div className="flex items-center justify-between font-bold text-stone-900">
                <span className="flex items-center gap-1 text-emerald-700">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  BioMed Autoclave Spore Test
                </span>
                <span className="text-[10px] text-emerald-700 font-semibold font-mono">PASSED</span>
              </div>
              <p className="text-[11px] text-stone-600">Biological indicator test passed July 20, 2026.</p>
            </div>
          </div>
        </div>
      </div>

      {/* 3. SECTION: Practice Setup (For new owners / personalized EMR configuration) */}
      <div id="practice-setup-section" className="bg-white p-6 rounded-2xl border border-stone-200/90 shadow-2xs space-y-6">
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-stone-200/80 pb-4">
          <div>
            <div className="flex items-center gap-2">
              <Sliders className="w-5 h-5 text-slate-900" />
              <h3 className="text-base font-bold text-stone-900">Practice Setup & Personalization</h3>
            </div>
            <p className="text-xs text-stone-500 mt-0.5">
              Essential EMR identifiers, provider licenses, contact details, and system integration preferences.
            </p>
          </div>

          <div className="flex items-center gap-2">
            {saveSuccess && (
              <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-3 py-1.5 rounded-xl border border-emerald-200 flex items-center gap-1 animate-in fade-in">
                <Check className="w-3.5 h-3.5" />
                <span>Saved to EMR Backend</span>
              </span>
            )}
            
            <button
              onClick={() => setIsEditingSetup(!isEditingSetup)}
              className="px-3.5 py-2 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-900 text-xs font-bold transition-colors shadow-2xs flex items-center gap-1.5 cursor-pointer border border-stone-200"
            >
              <Edit3 className="w-3.5 h-3.5" />
              <span>{isEditingSetup ? 'Cancel Editing' : 'Edit Practice Settings'}</span>
            </button>
          </div>
        </div>

        <form onSubmit={handleSaveSetup} className="space-y-6">
          {/* Grid 1: Identifiers & Legal Details */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-1">
              <label className="text-[11px] font-bold text-stone-500 uppercase tracking-wide">Practice / Facility Name</label>
              <input
                type="text"
                disabled={!isEditingSetup}
                value={practiceInfo.practiceName}
                onChange={e => setPracticeInfo({ ...practiceInfo, practiceName: e.target.value })}
                className="w-full px-3 py-2 bg-stone-50 disabled:bg-stone-100/70 border border-stone-300 disabled:border-stone-200 rounded-xl text-xs text-stone-900 font-bold focus:outline-none focus:ring-1 focus:ring-slate-900"
              />
            </div>

            <div className="space-y-1">
              <label className="text-[11px] font-bold text-stone-500 uppercase tracking-wide">Legal Entity Name</label>
              <input
                type="text"
                disabled={!isEditingSetup}
                value={practiceInfo.legalEntity}
                onChange={e => setPracticeInfo({ ...practiceInfo, legalEntity: e.target.value })}
                className="w-full px-3 py-2 bg-stone-50 disabled:bg-stone-100/70 border border-stone-300 disabled:border-stone-200 rounded-xl text-xs text-stone-900 font-semibold focus:outline-none"
              />
            </div>

            <div className="space-y-1">
              <label className="text-[11px] font-bold text-stone-500 uppercase tracking-wide">Facility Group NPI</label>
              <input
                type="text"
                disabled={!isEditingSetup}
                value={practiceInfo.groupNpi}
                onChange={e => setPracticeInfo({ ...practiceInfo, groupNpi: e.target.value })}
                className="w-full px-3 py-2 bg-stone-50 disabled:bg-stone-100/70 border border-stone-300 disabled:border-stone-200 rounded-xl text-xs text-stone-900 font-mono font-bold focus:outline-none"
              />
            </div>

            <div className="space-y-1">
              <label className="text-[11px] font-bold text-stone-500 uppercase tracking-wide">Federal Tax ID (EIN)</label>
              <input
                type="text"
                disabled={!isEditingSetup}
                value={practiceInfo.taxId}
                onChange={e => setPracticeInfo({ ...practiceInfo, taxId: e.target.value })}
                className="w-full px-3 py-2 bg-stone-50 disabled:bg-stone-100/70 border border-stone-300 disabled:border-stone-200 rounded-xl text-xs text-stone-900 font-mono font-semibold focus:outline-none"
              />
            </div>

            <div className="space-y-1">
              <label className="text-[11px] font-bold text-stone-500 uppercase tracking-wide">CLIA License #</label>
              <input
                type="text"
                disabled={!isEditingSetup}
                value={practiceInfo.cliaId}
                onChange={e => setPracticeInfo({ ...practiceInfo, cliaId: e.target.value })}
                className="w-full px-3 py-2 bg-stone-50 disabled:bg-stone-100/70 border border-stone-300 disabled:border-stone-200 rounded-xl text-xs text-stone-900 font-semibold focus:outline-none"
              />
            </div>

            <div className="space-y-1">
              <label className="text-[11px] font-bold text-stone-500 uppercase tracking-wide">AAAASF Facility Accreditation ID</label>
              <input
                type="text"
                disabled={!isEditingSetup}
                value={practiceInfo.aaaasfCode}
                onChange={e => setPracticeInfo({ ...practiceInfo, aaaasfCode: e.target.value })}
                className="w-full px-3 py-2 bg-stone-50 disabled:bg-stone-100/70 border border-stone-300 disabled:border-stone-200 rounded-xl text-xs text-stone-900 font-semibold focus:outline-none"
              />
            </div>
          </div>

          {/* Grid 2: Contact & Location */}
          <div className="border-t border-stone-200/80 pt-4 grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="space-y-1">
              <label className="text-[11px] font-bold text-stone-500 uppercase tracking-wide">Facility Address</label>
              <input
                type="text"
                disabled={!isEditingSetup}
                value={practiceInfo.address}
                onChange={e => setPracticeInfo({ ...practiceInfo, address: e.target.value })}
                className="w-full px-3 py-2 bg-stone-50 disabled:bg-stone-100/70 border border-stone-300 disabled:border-stone-200 rounded-xl text-xs text-stone-900 font-semibold focus:outline-none"
              />
            </div>

            <div className="space-y-1">
              <label className="text-[11px] font-bold text-stone-500 uppercase tracking-wide">City, State, Zip</label>
              <input
                type="text"
                disabled={!isEditingSetup}
                value={practiceInfo.cityStateZip}
                onChange={e => setPracticeInfo({ ...practiceInfo, cityStateZip: e.target.value })}
                className="w-full px-3 py-2 bg-stone-50 disabled:bg-stone-100/70 border border-stone-300 disabled:border-stone-200 rounded-xl text-xs text-stone-900 font-semibold focus:outline-none"
              />
            </div>

            <div className="space-y-1">
              <label className="text-[11px] font-bold text-stone-500 uppercase tracking-wide">Main Phone</label>
              <input
                type="text"
                disabled={!isEditingSetup}
                value={practiceInfo.phone}
                onChange={e => setPracticeInfo({ ...practiceInfo, phone: e.target.value })}
                className="w-full px-3 py-2 bg-stone-50 disabled:bg-stone-100/70 border border-stone-300 disabled:border-stone-200 rounded-xl text-xs text-stone-900 font-semibold focus:outline-none"
              />
            </div>

            <div className="space-y-1">
              <label className="text-[11px] font-bold text-stone-500 uppercase tracking-wide">HIPAA Secure Fax</label>
              <input
                type="text"
                disabled={!isEditingSetup}
                value={practiceInfo.fax}
                onChange={e => setPracticeInfo({ ...practiceInfo, fax: e.target.value })}
                className="w-full px-3 py-2 bg-stone-50 disabled:bg-stone-100/70 border border-stone-300 disabled:border-stone-200 rounded-xl text-xs text-stone-900 font-semibold focus:outline-none"
              />
            </div>
          </div>

          {/* Sub-Section: Providers Roster */}
          <div className="border-t border-stone-200/80 pt-4 space-y-3">
            <div className="flex items-center justify-between">
              <div className="font-bold text-xs text-stone-900 flex items-center gap-2">
                <Stethoscope className="w-4 h-4 text-slate-800" />
                <span>Provider & Clinical Staff Roster</span>
              </div>
              <button
                type="button"
                onClick={() => {
                  if (onShowToast) onShowToast('Opening provider roster addition modal...');
                }}
                className="text-xs font-bold text-slate-900 hover:underline flex items-center gap-1 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Provider</span>
              </button>
            </div>

            <div className="overflow-x-auto rounded-xl border border-stone-200/80">
              <table className="w-full text-left text-xs">
                <thead className="bg-stone-100/80 text-stone-500 font-bold uppercase text-[10px] tracking-wider border-b border-stone-200">
                  <tr>
                    <th className="py-2.5 px-3">Provider Name</th>
                    <th className="py-2.5 px-3">Role / Specialty</th>
                    <th className="py-2.5 px-3 font-mono">NPI</th>
                    <th className="py-2.5 px-3 font-mono">DEA #</th>
                    <th className="py-2.5 px-3">License Exp</th>
                    <th className="py-2.5 px-3 text-right">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-100 font-medium">
                  {providers.map(p => (
                    <tr key={p.id} className="hover:bg-stone-50/70">
                      <td className="py-2.5 px-3 font-bold text-stone-900">{p.name}</td>
                      <td className="py-2.5 px-3 text-stone-600">{p.title}</td>
                      <td className="py-2.5 px-3 font-mono text-stone-700">{p.npi}</td>
                      <td className="py-2.5 px-3 font-mono text-stone-700">{p.dea}</td>
                      <td className="py-2.5 px-3 text-stone-700">{p.exp}</td>
                      <td className="py-2.5 px-3 text-right">
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
                          {p.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Sub-Section: EMR Integration Toggles */}
          <div className="border-t border-stone-200/80 pt-4 space-y-3">
            <div className="font-bold text-xs text-stone-900 flex items-center gap-2">
              <Server className="w-4 h-4 text-slate-800" />
              <span>EMR System Integrations & Automated Gateways</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              <div
                onClick={() => toggleIntegration('eRx')}
                className="p-3 bg-stone-50 rounded-xl border border-stone-200 flex items-center justify-between cursor-pointer hover:border-slate-400 transition-colors"
              >
                <div>
                  <div className="text-xs font-bold text-stone-900">Surescripts e-Prescribing (eRx)</div>
                  <div className="text-[10px] text-stone-500 font-medium">EPCS for Schedule II-V</div>
                </div>
                <div className={`w-9 h-5 rounded-full p-0.5 transition-colors ${integrations.eRx ? 'bg-slate-900' : 'bg-stone-300'}`}>
                  <div className={`w-4 h-4 rounded-full bg-white transition-transform ${integrations.eRx ? 'translate-x-4' : 'translate-x-0'}`} />
                </div>
              </div>

              <div
                onClick={() => toggleIntegration('questLabs')}
                className="p-3 bg-stone-50 rounded-xl border border-stone-200 flex items-center justify-between cursor-pointer hover:border-slate-400 transition-colors"
              >
                <div>
                  <div className="text-xs font-bold text-stone-900">Quest / Labcorp Bi-Directional</div>
                  <div className="text-[10px] text-stone-500 font-medium">Automated HL7 Lab Results</div>
                </div>
                <div className={`w-9 h-5 rounded-full p-0.5 transition-colors ${integrations.questLabs ? 'bg-slate-900' : 'bg-stone-300'}`}>
                  <div className={`w-4 h-4 rounded-full bg-white transition-transform ${integrations.questLabs ? 'translate-x-4' : 'translate-x-0'}`} />
                </div>
              </div>

              <div
                onClick={() => toggleIntegration('billingEdi')}
                className="p-3 bg-stone-50 rounded-xl border border-stone-200 flex items-center justify-between cursor-pointer hover:border-slate-400 transition-colors"
              >
                <div>
                  <div className="text-xs font-bold text-stone-900">Change Healthcare Billing EDI</div>
                  <div className="text-[10px] text-stone-500 font-medium">Real-Time Eligibility 270/271</div>
                </div>
                <div className={`w-9 h-5 rounded-full p-0.5 transition-colors ${integrations.billingEdi ? 'bg-slate-900' : 'bg-stone-300'}`}>
                  <div className={`w-4 h-4 rounded-full bg-white transition-transform ${integrations.billingEdi ? 'translate-x-4' : 'translate-x-0'}`} />
                </div>
              </div>
            </div>
          </div>

          {isEditingSetup && (
            <div className="pt-2 flex justify-end">
              <button
                type="submit"
                className="px-5 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold flex items-center gap-2 shadow-2xs cursor-pointer"
              >
                <Save className="w-4 h-4" />
                <span>Save All Practice Settings</span>
              </button>
            </div>
          )}
        </form>
      </div>

      {/* 4. SECTION: Practice-Related Document Upload Zone */}
      <div className="bg-white p-6 rounded-2xl border border-stone-200/90 shadow-2xs space-y-4">
        <div className="flex items-center justify-between border-b border-stone-200/80 pb-3">
          <div>
            <h3 className="text-sm font-bold text-stone-900 flex items-center gap-2">
              <UploadCloud className="w-4 h-4 text-slate-900" />
              <span>Practice Document Upload Portal</span>
            </h3>
            <p className="text-xs text-stone-500 mt-0.5">
              Upload HIPAA-compliant files directly to the practice repository. Nightingale AI automatically indexes & summarizes all uploaded files.
            </p>
          </div>

          {/* Category Selector for Upload */}
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-stone-600">Target Category:</span>
            <select
              value={uploadCategory}
              onChange={e => setUploadCategory(e.target.value)}
              className="bg-stone-50 text-stone-900 text-xs font-bold py-1.5 px-3 rounded-xl border border-stone-300 focus:outline-none cursor-pointer"
            >
              {docTabs.map(t => (
                <option key={t.id} value={t.id}>{t.label}</option>
              ))}
            </select>
          </div>
        </div>

        {/* Upload Drop Zone */}
        <div
          onDragOver={e => { e.preventDefault(); setIsDragging(true); }}
          onDragLeave={() => setIsDragging(false)}
          onDrop={e => {
            e.preventDefault();
            setIsDragging(false);
            if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
              const fileName = e.dataTransfer.files[0].name;
              setUploadedFilesList(prev => [{ name: fileName, category: uploadCategory, date: 'Just now', size: '1.2 MB' }, ...prev]);
              if (onShowToast) onShowToast(`Dropped ${fileName} into ${uploadCategory}.`);
            }
          }}
          className={`p-8 rounded-2xl border-2 border-dashed transition-all text-center space-y-3 cursor-pointer ${
            isDragging
              ? 'border-indigo-600 bg-indigo-50/50'
              : 'border-stone-300 bg-stone-50/50 hover:bg-stone-50 hover:border-stone-400'
          }`}
        >
          <div className="w-12 h-12 rounded-2xl bg-slate-900 text-white flex items-center justify-center mx-auto shadow-2xs">
            <UploadCloud className="w-6 h-6" />
          </div>

          <div>
            <p className="text-xs font-bold text-stone-900">
              Drag & drop administrative files here, or <label htmlFor="doc-file-upload" className="text-indigo-600 hover:underline cursor-pointer">browse from device</label>
            </p>
            <p className="text-[11px] text-stone-500 mt-1">
              Supports PDF, DOCX, XLSX, JPG, PNG (Max 50MB per file). Encrypted in transit & at rest.
            </p>
            <input
              id="doc-file-upload"
              type="file"
              onChange={handleFileUploadSim}
              className="hidden"
            />
          </div>
        </div>

        {/* Recently Uploaded Quick Bar */}
        {uploadedFilesList.length > 0 && (
          <div className="pt-2 space-y-2 border-t border-stone-100">
            <div className="text-[11px] font-bold text-stone-500 uppercase tracking-wide">Recent Session Uploads</div>
            <div className="flex flex-wrap gap-2">
              {uploadedFilesList.map((uf, i) => (
                <div key={i} className="px-3 py-1.5 rounded-xl bg-indigo-50 text-indigo-950 border border-indigo-200 text-xs font-semibold flex items-center gap-2 shadow-2xs">
                  <FileText className="w-3.5 h-3.5 text-indigo-600" />
                  <span>{uf.name} ({uf.category})</span>
                  <span className="text-[10px] text-indigo-600 font-mono">{uf.size}</span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* 5. SECTION: Practice Document Repository (Tabbed Area with Heading Categories) */}
      <div className="bg-white rounded-2xl border border-stone-200/90 shadow-2xs overflow-hidden space-y-0">
        
        {/* Category Heading Tabs Bar */}
        <div className="border-b border-stone-200/80 px-4 pt-3 flex items-center gap-2 overflow-x-auto bg-stone-50/60 no-scrollbar">
          {docTabs.map(t => {
            const Icon = t.icon;
            const isActive = activeDocTab === t.id;
            return (
              <button
                key={t.id}
                onClick={() => setActiveDocTab(t.id)}
                className={`pb-3 px-3 text-xs font-bold transition-all relative flex items-center gap-2 shrink-0 cursor-pointer ${
                  isActive
                    ? 'text-blue-700 border-b-2 border-blue-600'
                    : 'text-stone-500 hover:text-stone-900'
                }`}
              >
                <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-blue-600' : 'text-stone-400'}`} />
                <span>{t.label}</span>
                <span className={`px-1.5 py-0.2 rounded-full text-[9.5px] font-mono font-bold ${
                  isActive ? 'bg-blue-600 text-white' : 'bg-stone-200/80 text-stone-700'
                }`}>
                  {t.count}
                </span>
              </button>
            );
          })}
        </div>

        {/* Repository Tab Content Body */}
        <div className="p-6 space-y-5">
          
          {/* Nightingale AI Summary Card for Selected Folder Category */}
          <div className="p-4 bg-gradient-to-r from-purple-50/90 via-indigo-50/70 to-white rounded-xl border border-indigo-100 flex items-start gap-3 shadow-2xs">
            <div className="p-2 rounded-lg bg-indigo-600 text-white shrink-0 shadow-2xs mt-0.5">
              <Sparkles className="w-4 h-4" />
            </div>
            <div className="space-y-1">
              <div className="text-xs font-bold text-stone-900 flex items-center gap-2">
                <span>Nightingale AI Index Summary — {activeDocTab}</span>
                <span className="px-2 py-0.2 rounded text-[9.5px] font-bold bg-indigo-100 text-indigo-900">Verified Binder</span>
              </div>
              <p className="text-xs text-stone-700 leading-relaxed font-medium">
                {currentTabContent.aiSummary}
              </p>
            </div>
          </div>

          {/* Search & Actions Header inside Repository */}
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="relative flex-1 min-w-[220px]">
              <Search className="w-4 h-4 text-stone-400 absolute left-3 top-2.5" />
              <input
                type="text"
                value={docSearchQuery}
                onChange={e => setDocSearchQuery(e.target.value)}
                placeholder={`Search inside ${activeDocTab}...`}
                className="w-full pl-9 pr-4 py-2 bg-stone-50 rounded-xl border border-stone-300 text-xs text-stone-800 focus:outline-none focus:ring-1 focus:ring-slate-900"
              />
            </div>

            <button
              onClick={() => {
                if (onShowToast) onShowToast(`Downloading complete zipped repository for ${activeDocTab}...`);
              }}
              className="px-3.5 py-2 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-800 text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer border border-stone-200 shadow-2xs"
            >
              <Download className="w-3.5 h-3.5 text-stone-600" />
              <span>Download Binder</span>
            </button>
          </div>

          {/* Sample Files Table */}
          <div className="overflow-x-auto rounded-xl border border-stone-200/90">
            <table className="w-full text-left text-xs">
              <thead className="bg-stone-100/90 text-stone-500 font-bold uppercase text-[10px] tracking-wider border-b border-stone-200">
                <tr>
                  <th className="py-3 px-4">Document Title</th>
                  <th className="py-3 px-4">Format</th>
                  <th className="py-3 px-4">Uploader / Author</th>
                  <th className="py-3 px-4">Date Added</th>
                  <th className="py-3 px-4">File Size</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-100 font-medium">
                {filteredFiles.map(file => (
                  <tr key={file.id} className="hover:bg-stone-50/80 transition-colors">
                    <td className="py-3 px-4">
                      <div className="font-bold text-stone-900 flex items-center gap-2">
                        <FileText className="w-4 h-4 text-slate-800 shrink-0" />
                        <span>{file.title}</span>
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-stone-100 text-stone-700 border border-stone-200">
                        {file.type}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-stone-600">{file.uploader}</td>
                    <td className="py-3 px-4 text-stone-500 font-mono text-[11px]">{file.date}</td>
                    <td className="py-3 px-4 text-stone-500 font-mono text-[11px]">{file.size}</td>
                    <td className="py-3 px-4">
                      <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                        file.status === 'Expiring Soon'
                          ? 'bg-amber-100 text-amber-900 border border-amber-200'
                          : 'bg-emerald-100 text-emerald-900 border border-emerald-200'
                      }`}>
                        {file.status} {file.expDate ? `(${file.expDate})` : ''}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right">
                      <div className="flex items-center justify-end gap-2">
                        <button
                          onClick={() => {
                            if (onShowToast) onShowToast(`Viewing document: ${file.title}`);
                          }}
                          className="p-1.5 rounded-lg bg-stone-100 hover:bg-stone-200 text-stone-700 transition-colors cursor-pointer"
                          title="View Document"
                        >
                          <Eye className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => {
                            if (onShowToast) onShowToast(`Downloading ${file.title}...`);
                          }}
                          className="p-1.5 rounded-lg bg-stone-100 hover:bg-stone-200 text-stone-700 transition-colors cursor-pointer"
                          title="Download"
                        >
                          <Download className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

        </div>

      </div>

      {/* 6. ADDITIONAL PERTINENT SECTION: Facility Compliance, OSHA & Security Logs */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        
        {/* Controlled Substances & Pharmacy Log */}
        <div className="bg-white p-5 rounded-2xl border border-stone-200/90 shadow-2xs space-y-3">
          <div className="flex items-center justify-between border-b border-stone-200/80 pb-2.5">
            <div className="font-bold text-xs text-stone-900 flex items-center gap-2">
              <Lock className="w-4 h-4 text-slate-800" />
              <span>Controlled Substance Schedule II-V Vault Log</span>
            </div>
            <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
              Vault Reconciled
            </span>
          </div>

          <p className="text-xs text-stone-600 leading-relaxed font-medium">
            Bi-daily physical count of Fentanyl, Midazolam, and Propofol completed by Dr. Chen and Nurse Vance at 07:00 AM. Zero discrepancy noted.
          </p>

          <div className="grid grid-cols-2 gap-2 text-xs pt-1">
            <div className="p-2.5 bg-stone-50 rounded-xl border border-stone-200">
              <div className="text-[10px] font-bold text-stone-400 uppercase">Fentanyl 50mcg/2mL</div>
              <div className="text-sm font-black text-stone-900">42 Vials Counted</div>
            </div>
            <div className="p-2.5 bg-stone-50 rounded-xl border border-stone-200">
              <div className="text-[10px] font-bold text-stone-400 uppercase">Versed (Midazolam)</div>
              <div className="text-sm font-black text-stone-900">28 Vials Counted</div>
            </div>
          </div>
        </div>

        {/* HIPAA Security & Cyber Access Logs */}
        <div className="bg-white p-5 rounded-2xl border border-stone-200/90 shadow-2xs space-y-3">
          <div className="flex items-center justify-between border-b border-stone-200/80 pb-2.5">
            <div className="font-bold text-xs text-stone-900 flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 text-slate-800" />
              <span>HIPAA Cyber Access & 2FA Audit Log</span>
            </div>
            <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-sky-100 text-sky-800 border border-sky-200">
              2FA Active (100%)
            </span>
          </div>

          <p className="text-xs text-stone-600 leading-relaxed font-medium">
            All 18 active user accounts utilize mandatory hardware multi-factor authentication. Automatic 15-minute screen lock policy enforced.
          </p>

          <div className="space-y-1.5 text-xs font-medium">
            <div className="flex justify-between items-center py-1 border-b border-stone-100">
              <span className="text-stone-600">Last System Backup:</span>
              <span className="font-bold text-stone-900">Today, 04:00 AM (AES-256 Cloud)</span>
            </div>
            <div className="flex justify-between items-center py-1">
              <span className="text-stone-600">Failed Login Attempts (24h):</span>
              <span className="font-bold text-emerald-700">0 Security Events</span>
            </div>
          </div>
        </div>

      </div>

    </div>
  );
};
