import React, { useState, useEffect } from 'react';
import { 
  FileText, 
  Plus, 
  Sparkles, 
  Search, 
  ChevronRight, 
  ChevronDown,
  ChevronUp, 
  CheckCircle2, 
  AlertCircle, 
  User, 
  UserPlus,
  Calendar, 
  Activity, 
  Pill,
  Mic,
  Send, 
  ExternalLink, 
  ShieldCheck, 
  FileCheck, 
  Clock, 
  CreditCard, 
  MessageSquare, 
  Building2,
  Filter,
  Maximize2,
  X,
  Download,
  Eye,
  Check,
  Printer,
  Upload,
  FolderOpen,
  FolderCheck,
  Save,
  Mail,
  CheckSquare,
  Square,
  Laptop,
  Smartphone,
  Share2,
  Copy,
  Link,
  Lock,
  Trash2,
  DollarSign,
  Zap,
  Layers,
  Stethoscope
} from 'lucide-react';
import { PatientCase } from '../types';
import { 
  generateSampleDriverLicense, 
  generateSampleInsuranceFront, 
  generateSampleInsuranceBack 
} from '../utils/cardTemplates';
import { ElectronicFormsPortal, ClinicalFormTab } from './ElectronicFormsPortal';
import { ClinicalPdfFormsView } from './ClinicalPdfFormsView';
import { IntakeHtmlForm, INITIAL_INTAKE_HTML_FORMS } from '../data/intakeHtmlForms';
import { NoteHtmlForm, INITIAL_NOTES_HTML_FORMS } from '../data/notesHtmlForms';
import { NursingHtmlForm, INITIAL_NURSING_HTML_FORMS, SURGICAL_EPISODES } from '../data/nursingHtmlForms';
import { AIWorkflowExamples } from './AIWorkflowExamples';
import { AIPatientChartOverview } from './AIPatientChartOverview';

export interface DocumentItem {
  id: string;
  title: string;
  fileName: string;
  submissionDate: string;
  type: string;
  status: string;
  summary: string;
  fileSize?: string;
  tags?: string[];
  formTab?: 'standing-orders' | 'preop-checklist' | 'surgical-checklist';
  content?: string;
}

const INITIAL_DOCUMENTS: DocumentItem[] = [
  {
    id: 'pdf-doc-1',
    title: 'Doctors Standing Orders (Pre & PostOp)',
    fileName: 'Doctors_Standing_Orders_May06.pdf',
    type: 'Converted PDF Form',
    submissionDate: 'May 06, 2026',
    status: 'Interactive HTML',
    fileSize: '1.2 MB',
    summary: 'Summit Surgical Center Doctors Standing Orders. Contains pre-op orders (H&P, consents, IV Ancef 1g, labs) and post-op discharge orders signed by Dr. Richard Zoumalan.',
    tags: ['PDF Converted', 'Standing Orders', 'Dr. Zoumalan'],
    formTab: 'standing-orders',
  },
  {
    id: 'pdf-doc-2',
    title: 'Pre-Operative Checklist and Assessment',
    fileName: 'PreOp_Checklist_Assessment.pdf',
    type: 'Converted PDF Form',
    submissionDate: 'May 06, 2026',
    status: 'Interactive HTML',
    fileSize: '980 KB',
    summary: 'Summit Surgical Center Pre-Op Checklist. Documents admission vitals (BP 141/85, SpO2 99%), PCN allergy (hives), loose tooth alert, pre-op meds (Valium 5mg, Celebrex, Emend) administered by U. Kriskier, RN.',
    tags: ['PDF Converted', 'Vitals & Allergies', 'Nursing Assessment'],
    formTab: 'preop-checklist',
  },
  {
    id: 'pdf-doc-3',
    title: 'Comprehensive Surgical Checklist (AORN/WHO)',
    fileName: 'Surgical_Checklist_AORN_WHO.pdf',
    type: 'Converted PDF Form',
    submissionDate: 'May 06, 2026',
    status: 'Interactive HTML',
    fileSize: '1.4 MB',
    summary: 'Comprehensive 4-stage surgical safety checklist covering In Holding, Before Induction (Sign-In), Before Incision (Time-Out), and Before Leaving OR (Sign-Out) signed by Dr. Taheri and Ani Abadjian, RN.',
    tags: ['PDF Converted', 'AORN Checklist', 'Surgical Safety'],
    formTab: 'surgical-checklist',
  },
  {
    id: 'doc-1',
    title: 'Pre-operative History & Physical Examination',
    fileName: 'PreOp_History_Physical_Jul15.pdf',
    type: 'Clinical Note',
    submissionDate: 'Jul 15, 2026',
    status: 'Reviewed',
    fileSize: '840 KB',
    summary: 'Completed July 15, 2026. Medical clearance documented. No new cardiopulmonary symptoms. Medication and allergy lists reconciled.',
    tags: ['AI summary reviewed', 'Source document preserved'],
    content: `PATIENT HISTORY & PHYSICAL EXAMINATION
Patient: Sarah Wilson (ID: 113561) | DOB: 02/11/1972 (Age 54)
Date of Examination: July 15, 2026
Attending Physician: Dr. Richard Zoumalan, M.D.

CHIEF COMPLAINT:
Pre-operative evaluation prior to planned bilateral breast implant revision and capsulectomy.

HISTORY OF PRESENT ILLNESS:
The patient is a 54-year-old female with a history of bilateral breast augmentation in 2018 who presents for scheduled bilateral implant revision. She reports mild capsular contracture Baker Stage II on the left side. No systemic complaints, chest pain, shortness of breath, fever, or weight changes.

PAST MEDICAL HISTORY:
- Mild seasonal allergies
- No hypertension, diabetes, or CAD history

ALLERGIES:
- Penicillin (Hives / Rash)

MEDICATIONS:
- Multivitamin daily
- Celebrex 200mg pre-op as directed

PHYSICAL EXAMINATION:
Vitals: BP 122/78, HR 68, Temp 36.7°C, SpO2 99% on room air.
HEENT: Normocephalic, atraumatic. Airway Mallampati Class I. Loose lower left molar noted.
Cardiovascular: Regular rate and rhythm, normal S1/S2, no murmurs.
Respiratory: Clear to auscultation bilaterally, no wheezes or rales.
Breasts: Bilateral symmetric breast tissue with well-healed inframammary scars. No palpable dominant masses.

ASSESSMENT & PLAN:
1. Patient cleared for outpatient surgical procedure under general anesthesia.
2. Anesthesia consultation completed.
3. Continue current medication regimen; hold blood thinners if any.`,
  },
  {
    id: 'doc-2',
    title: 'Signed Surgical Informed Consent',
    fileName: 'Signed_Surgical_Consent_Jul14.pdf',
    type: 'Consent',
    submissionDate: 'Jul 14, 2026',
    status: 'Signed',
    fileSize: '620 KB',
    summary: 'Surgical consent for bilateral implant revision signed by patient. Risks, benefits, and alternatives discussed in detail.',
    tags: ['Verified signature', 'Legal record active'],
    content: `SUMMIT SURGICAL CENTER — INFORMED CONSENT FOR SURGERY
Patient Name: Sarah Wilson | Patient ID: 113561
Date: July 14, 2026

PROCEDURE AUTHORIZED:
Bilateral Breast Implant Revision, Capsulectomy, and Mentor Gel Implant Placement.

PHYSICIAN: Dr. Richard Zoumalan, M.D.

PATIENT ACKNOWLEDGEMENT:
I hereby authorize Dr. Richard Zoumalan and designated surgical assistants at Summit Surgical Center to perform the procedure listed above. I confirm that the risks, potential complications, alternative treatments, and anesthesia management options have been explained to me in detail.

Complications discussed include, but are not limited to: bleeding, infection, scarring, asymmetry, implant rupture, capsular contracture, and risks inherent to general anesthesia.

Patient Signature: [Digitally Signed by Sarah Wilson] — 07/14/2026 14:22 PST
Witness Signature: [Digitally Signed by Ani Abadjian, RN] — 07/14/2026 14:25 PST`,
  },
  {
    id: 'doc-3',
    title: 'CBC & Complete Metabolic Panel Lab Results',
    fileName: 'Lab_Results_CBC_BMP_Jul13.pdf',
    type: 'Laboratory',
    submissionDate: 'Jul 13, 2026',
    status: 'Reviewed',
    fileSize: '450 KB',
    summary: 'CBC: WBC 6.8, Hgb 13.4 g/dL, Plt 245k. BMP: Sodium 140, Potassium 4.2, Creatinine 0.8. All values within normal reference ranges.',
    tags: ['Labs cleared', 'No critical flags'],
    content: `QUEST DIAGNOSTICS LABORATORY REPORT
Patient: Sarah Wilson (ID: 113561) | Collection Date: July 13, 2026

COMPLETE BLOOD COUNT (CBC WITH DIFFERENTIAL):
- WBC: 6.8 x10^3/uL (Normal Range: 4.5 - 11.0) — NORMAL
- RBC: 4.45 x10^6/uL (Normal Range: 4.0 - 5.2) — NORMAL
- Hemoglobin (Hgb): 13.4 g/dL (Normal Range: 12.0 - 15.5) — NORMAL
- Hematocrit (Hct): 39.8 % (Normal Range: 37.0 - 48.0) — NORMAL
- Platelets: 245 x10^3/uL (Normal Range: 150 - 450) — NORMAL

BASIC METABOLIC PANEL (BMP):
- Sodium: 140 mEq/L (Normal Range: 135 - 145) — NORMAL
- Potassium: 4.2 mEq/L (Normal Range: 3.5 - 5.1) — NORMAL
- Chloride: 102 mEq/L (Normal Range: 96 - 106) — NORMAL
- CO2: 25 mEq/L (Normal Range: 22 - 29) — NORMAL
- BUN: 14 mg/dL (Normal Range: 7 - 20) — NORMAL
- Creatinine: 0.81 mg/dL (Normal Range: 0.6 - 1.1) — NORMAL
- Glucose: 92 mg/dL (Normal Range: 70 - 99) — NORMAL

COAGULATION STUDIES:
- PT: 11.2 sec (Normal Range: 10.0 - 13.0) — NORMAL
- INR: 1.0 (Normal Range: 0.8 - 1.2) — NORMAL
- PTT: 28.5 sec (Normal Range: 25.0 - 35.0) — NORMAL

Lab Director Signature: Dr. Helen Vance, M.D., FCAP`,
  },
  {
    id: 'doc-4',
    title: 'Outside Operative Report (Cedars-Sinai Medical Center)',
    fileName: 'CedarsSinai_OpReport_Aug2018.pdf',
    type: 'Outside Record',
    submissionDate: 'Oct 24, 2018',
    status: 'Source linked',
    fileSize: '1.8 MB',
    summary: 'Previous primary bilateral subglandular breast augmentation operative report retrieved from Cedars-Sinai Medical Center.',
    tags: ['Historical reference', 'External EHR linked'],
    content: `CEDARS-SINAI MEDICAL CENTER — OPERATIVE REPORT
Date of Surgery: August 14, 2018
Surgeon: Dr. Marcus Vance, M.D.
Patient: Sarah Wilson

PREOPERATIVE DIAGNOSIS: Bilateral breast hypoplasia.
POSTOPERATIVE DIAGNOSIS: Bilateral breast hypoplasia.
PROCEDURE PERFORMED: Primary bilateral subglandular breast augmentation with smooth round silicone gel implants (275cc left, 275cc right).

SURGICAL SUMMARY:
The patient was brought to OR #4 and placed in supine position. After successful IV sedation and local anesthetic block, inframammary incisions were made. Subglandular pockets were dissected bilaterally. Hemostasis was achieved. Smooth round silicone implants were placed without difficulty. Incisions were closed in layers. Patient tolerated procedure well and was discharged to PACU in stable condition.`,
  },
  {
    id: 'doc-5',
    title: "Driver's License & Photo Identification Scan",
    fileName: 'Drivers_License_ID_Scan.png',
    type: 'ID & Insurance',
    submissionDate: 'May 05, 2026',
    status: 'Verified OCR',
    fileSize: '2.1 MB',
    summary: 'California Driver License scan for Sarah Wilson. State ID # D8849102 verified against pre-op intake registration.',
    tags: ['Photo ID', 'OCR Verified'],
  },
  {
    id: 'doc-6',
    title: 'Primary Insurance Card (Front & Back)',
    fileName: 'BlueShield_Insurance_Card.png',
    type: 'ID & Insurance',
    submissionDate: 'May 05, 2026',
    status: 'Verified OCR',
    fileSize: '1.6 MB',
    summary: 'Blue Shield PPO Policy # W99284102. Group # 77481. Copay: $25. Auth Status: Approved.',
    tags: ['Insurance PPO', 'Auth Active'],
  }
];

export interface PreOpPdfForm {
  id: string;
  title: string;
  pdfGroup: string;
  subtitle: string;
  pageNumber: string;
  defaultChecked: boolean;
  status: 'Pending Send' | 'Sent via Email' | 'Completed in Portal';
  description: string;
}

export const PRE_OP_INTAKE_PDF_FORMS: PreOpPdfForm[] = [
  {
    id: 'patients-rights',
    title: "Patient's Rights and Responsibilities",
    pdfGroup: 'General Rights & Legal',
    subtitle: 'Patient rights, responsibilities & emergency care disclosures',
    pageNumber: 'PDF 1 — Page 1',
    defaultChecked: true,
    status: 'Sent via Email',
    description: 'Outlines patient dignity, confidentiality, informed consent rights, and patient safety responsibilities.'
  },
  {
    id: 'hipaa-notice',
    title: 'HIPAA Notice of Privacy Practices',
    pdfGroup: 'General Rights & Legal',
    subtitle: 'Protected health information (PHI) disclosure & patient privacy rights',
    pageNumber: 'PDF 1 & 4 — Pages 2-3',
    defaultChecked: true,
    status: 'Completed in Portal',
    description: 'Describes uses and disclosures of PHI for treatment, payment, healthcare operations, and privacy rights.'
  },
  {
    id: 'disclosure-ownership',
    title: 'Disclosure of Ownership',
    pdfGroup: 'General Rights & Legal',
    subtitle: 'CMS 42 C.F.R. 416.50 physician financial interest disclosure',
    pageNumber: 'PDF 1 — Page 4',
    defaultChecked: true,
    status: 'Completed in Portal',
    description: 'Discloses physician ownership interest in Summit Surgical Center prior to procedure date.'
  },
  {
    id: 'complaint-grievance',
    title: 'Patient Complaint or Grievance',
    pdfGroup: 'General Rights & Legal',
    subtitle: 'Filing complaints with LA County Public Health, AAAASF & Medicare Ombudsman',
    pageNumber: 'PDF 1 — Page 5',
    defaultChecked: true,
    status: 'Sent via Email',
    description: 'Provides contact information for LA County Public Health, AAAASF, and Medicare Beneficiary Ombudsman.'
  },
  {
    id: 'advanced-directives',
    title: 'Advanced Directives',
    pdfGroup: 'General Rights & Legal',
    subtitle: 'Facility policy on Advance Directives and elective resuscitation guidelines',
    pageNumber: 'PDF 1 — Page 6',
    defaultChecked: true,
    status: 'Pending Send',
    description: 'Informs patient of facility resuscitation policy and collects advance directive status.'
  },
  {
    id: 'arbitration-agreement',
    title: 'Facility Arbitration Agreement',
    pdfGroup: 'General Rights & Legal',
    subtitle: 'California law binding medical malpractice neutral arbitration contract',
    pageNumber: 'PDF 1 — Page 7',
    defaultChecked: true,
    status: 'Pending Send',
    description: 'Legal agreement submitting any medical malpractice disputes to neutral arbitration.'
  },
  {
    id: 'acknowledgement-receipt',
    title: 'Acknowledgement of Receipt',
    pdfGroup: 'General Rights & Legal',
    subtitle: 'Signature acknowledging receipt of Privacy Notice, Rights & Disclosures',
    pageNumber: 'PDF 1 — Page 8',
    defaultChecked: true,
    status: 'Pending Send',
    description: 'Signed acknowledgement confirming receipt of Patient Rights, Disclosure, Grievance & Advance Directives.'
  },
  {
    id: 'anesthesia-questionnaire',
    title: 'Anesthesia Questionnaire',
    pdfGroup: 'Anesthesia & Medical Screening',
    subtitle: 'Height, weight, allergies, medications, past surgeries & airway screening',
    pageNumber: 'PDF 2 — Page 1',
    defaultChecked: true,
    status: 'Pending Send',
    description: 'Pre-operative screening questionnaire covering drug/latex allergies, airway history, and medical conditions.'
  },
  {
    id: 'consent-anesthesia',
    title: 'Patient Consent for Anesthesia',
    pdfGroup: 'Anesthesia & Medical Screening',
    subtitle: 'Informed consent for General, Regional, IV Sedation & Local Anesthesia',
    pageNumber: 'PDF 2 — Page 2',
    defaultChecked: true,
    status: 'Pending Send',
    description: 'Detailed explanation of anesthesia types, risks, and patient authorization signature.'
  },
  {
    id: 'mh-vte-assessment',
    title: 'Malignant Hyperthermia and Venous Thromboembolism Assessment',
    pdfGroup: 'Anesthesia & Medical Screening',
    subtitle: 'MH risk screening & Caprini VTE/DVT risk score assessment',
    pageNumber: 'PDF 2 — Page 3',
    defaultChecked: true,
    status: 'Pending Send',
    description: 'Patient pre-op risk scoring for malignant hyperthermia triggers and venous thromboembolism prophylaxis.'
  },
  {
    id: 'billing-fee-disclosure',
    title: 'Billing Fee Disclosure',
    pdfGroup: 'Financial & Facility Info',
    subtitle: '8% insurance collection fee disclosure for facility and anesthesia refunds',
    pageNumber: 'PDF 3 — Page 1',
    defaultChecked: true,
    status: 'Completed in Portal',
    description: 'Explains third-party insurance processing and 8% billing fee deduction policies.'
  },
  {
    id: 'welcome-surgical-center',
    title: 'Welcome to Summit Surgical Center',
    pdfGroup: 'Financial & Facility Info',
    subtitle: 'Location map, 461 N. Bedford parking garage, valet & pre-op NPO rules',
    pageNumber: 'PDF 5 — Page 1',
    defaultChecked: true,
    status: 'Sent via Email',
    description: 'Facility address, one-way street directions, parking details, companion info, and midnight NPO rules.'
  }
];

interface PatientChartPageProps {
  cases: PatientCase[];
  initialSelectedPatientId?: string;
  onOpenPatientModal?: (patient: PatientCase) => void;
}

export const PatientChartPage: React.FC<PatientChartPageProps> = ({
  cases,
  initialSelectedPatientId,
  onOpenPatientModal,
}) => {
  // Find selected patient or default to Sarah Wilson / case-0
  const defaultPatient = 
    cases.find((c) => c.id === initialSelectedPatientId || c.patientId === initialSelectedPatientId) ||
    cases.find((c) => c.patientId === '113561') || 
    cases[0];
  const [selectedPatient, setSelectedPatient] = useState<PatientCase>(defaultPatient);

  // Sync selected patient when initialSelectedPatientId changes
  useEffect(() => {
    if (initialSelectedPatientId) {
      const found = cases.find(
        (c) => c.id === initialSelectedPatientId || c.patientId === initialSelectedPatientId
      );
      if (found) {
        setSelectedPatient(found);
      }
    }
  }, [initialSelectedPatientId, cases]);
  
  // Tab states
  const [activeSubTab, setActiveSubTab] = useState<'Documents' | 'Notes' | 'ID & Insurance Cards' | 'Timeline' | 'Labs & Imaging' | 'Billing' | 'Communications'>('Documents');
  const [docSearchQuery, setDocSearchQuery] = useState('');
  const [docList, setDocList] = useState<DocumentItem[]>(INITIAL_DOCUMENTS);
  const [viewingDoc, setViewingDoc] = useState<DocumentItem | null>(null);
  const [docFilterCategory, setDocFilterCategory] = useState<string>('All');
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const [deleteConfirmation, setDeleteConfirmation] = useState<{
    type: 'Document' | 'Doctor Note' | 'Nursing Note' | 'Draft Note';
    id?: string;
    name: string;
    details?: string;
    action: () => void;
  } | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 3500);
  };

  const handleDownloadDoc = (doc: DocumentItem) => {
    const contentToDownload = doc.content || `DOCUMENT REPORT\nTitle: ${doc.title}\nFile Name: ${doc.fileName}\nSubmission Date: ${doc.submissionDate}\nCategory: ${doc.type}\nStatus: ${doc.status}\n\nSummary:\n${doc.summary}`;
    const blob = new Blob([contentToDownload], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = doc.fileName;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);

    showToast(`Downloaded "${doc.fileName}"`);
  };

  const handleDeleteDoc = (id: string) => {
    const target = docList.find((d) => d.id === id);
    if (target) {
      setDeleteConfirmation({
        type: 'Document',
        id: target.id,
        name: target.fileName,
        details: `Category: ${target.type} · Submission Date: ${target.submissionDate} · Status: ${target.status}`,
        action: () => {
          setDocList((prev) => prev.filter((d) => d.id !== id));
          if (viewingDoc?.id === id) {
            setViewingDoc(null);
          }
          showToast(`Deleted document "${target.fileName}" from patient chart.`);
        }
      });
    }
  };

  const handleDeleteDoctorNote = (id: string) => {
    const target = notesFormsList.find((n) => n.id === id);
    if (target) {
      setDeleteConfirmation({
        type: 'Doctor Note',
        id: target.id,
        name: target.title,
        details: `Author: ${target.author} · Date: ${target.date} · Status: ${target.status}`,
        action: () => {
          setNotesFormsList((prev) => prev.filter((n) => n.id !== id));
          if (viewingNoteForm?.id === id) {
            setViewingNoteForm(null);
          }
          showToast(`Deleted Doctor Note "${target.title}"`);
        }
      });
    }
  };

  const handleDeleteNursingNote = (id: string) => {
    const target = nursingFormsList.find((f) => f.id === id);
    if (target) {
      setDeleteConfirmation({
        type: 'Nursing Note',
        id: target.id,
        name: target.title,
        details: `Author: ${target.author} · Date: ${target.date} · Status: ${target.status}`,
        action: () => {
          setNursingFormsList((prev) => prev.filter((f) => f.id !== id));
          if (editingNursingForm?.id === id) {
            setEditingNursingForm(null);
          }
          if (viewingFullNursingForm?.id === id) {
            setViewingFullNursingForm(null);
          }
          showToast(`Deleted Nursing Note "${target.title}"`);
        }
      });
    }
  };

  const handleClearDraftNote = () => {
    if (!draftNoteContent) return;
    setDeleteConfirmation({
      type: 'Draft Note',
      name: 'Draft Physician Note',
      details: 'Unsaved text in the clinical note workspace',
      action: () => {
        setDraftNoteContent('');
        showToast('Cleared draft physician note.');
      }
    });
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    const file = files[0];
    const newDoc: DocumentItem = {
      id: `upload-${Date.now()}`,
      title: file.name.replace(/\.[^/.]+$/, ''),
      fileName: file.name,
      type: 'Uploaded Document',
      submissionDate: new Date().toLocaleDateString('en-US', { month: 'short', day: '2-digit', year: 'numeric' }),
      status: 'Uploaded',
      fileSize: `${(file.size / 1024).toFixed(1)} KB`,
      summary: `Uploaded file by clinician on ${new Date().toLocaleDateString()}. Stored & archived in EHR chart.`,
      tags: ['User Uploaded', 'New Attachment'],
      content: `OFFICIAL EHR PATIENT CHART ATTACHMENT\nFile Name: ${file.name}\nSize: ${file.size} bytes\nType: ${file.type || 'Standard File'}\nUpload Time: ${new Date().toLocaleString()}\nPatient Name: ${selectedPatient.name} (ID: ${selectedPatient.patientId})\n\n[Document archived and verified in patient electronic chart]`
    };

    setDocList((prev) => [newDoc, ...prev]);
    showToast(`Uploaded "${file.name}" successfully!`);
    e.target.value = '';
  };

  const filteredDocList = docList.filter((doc) => {
    const matchesSearch =
      doc.fileName.toLowerCase().includes(docSearchQuery.toLowerCase()) ||
      doc.title.toLowerCase().includes(docSearchQuery.toLowerCase()) ||
      doc.submissionDate.toLowerCase().includes(docSearchQuery.toLowerCase()) ||
      doc.type.toLowerCase().includes(docSearchQuery.toLowerCase());

    const matchesCategory =
      docFilterCategory === 'All' || doc.type === docFilterCategory;

    return matchesSearch && matchesCategory;
  });

  const [selectedDocId, setSelectedDocId] = useState('doc-1');
  const [isDragging, setIsDragging] = useState(false);
  const [isIDModalOpen, setIsIDModalOpen] = useState(false);

  // Section Collapse/Expand state for Patient Chart major sections (Demographics and AI Brief expanded by default)
  const [expandedSections, setExpandedSections] = useState<Record<string, boolean>>({
    demographics: true,
    aiBrief: true,
    aiWorkflows: false,
    docUpload: false,
    documents: false,
    admissionRegistration: false,
    intakeForms: false,
    clinicalNotes: false,
    nursingNotes: false,
    clearance: true,
    admission: false,
    nursingForms: false,
    appointmentHistory: true,
    appointments: true,
    medications: false,
    idInsuranceCards: false,
    surgicalDetails: false,
    quickActions: false,
  });

  const [showEarlierVisits, setShowEarlierVisits] = useState(false);

  const toggleSection = (key: string) => {
    setExpandedSections((prev) => ({
      ...prev,
      [key]: !prev[key],
    }));
  };

  const expandAllSections = () => {
    setExpandedSections({
      demographics: true,
      aiBrief: true,
      docUpload: true,
      docRecords: true,
      clearance: true,
      admission: true,
      clinicalNotes: true,
      nursingForms: true,
      appointmentHistory: true,
      medications: true,
      idInsuranceCards: true,
      surgicalDetails: true,
      quickActions: true,
    });
  };

  const collapseAllSections = () => {
    setExpandedSections({
      demographics: false,
      aiBrief: false,
      docUpload: false,
      docRecords: false,
      clearance: false,
      admission: false,
      clinicalNotes: false,
      nursingForms: false,
      appointmentHistory: false,
      medications: false,
      idInsuranceCards: false,
      surgicalDetails: false,
      quickActions: false,
    });
  };

  // Ask Nightingale AI Chat & Active Result Views state
  const [askAiInput, setAskAiInput] = useState('');
  const [selectedCommandKey, setSelectedCommandKey] = useState<string>('clearance');
  const [aiAskChatLog, setAiAskChatLog] = useState<Array<{ sender: 'user' | 'ai'; text: string; timestamp: string }>>([
    {
      sender: 'ai',
      text: `Hello! I'm Nightingale AI. Select a command below or ask me about ${selectedPatient.name}'s chart to display specific records on demand.`,
      timestamp: 'Just now',
    },
  ]);
  const [activeAiResults, setActiveAiResults] = useState<string[]>(['clearance']);

  const handleExecuteAiCommand = (commandLabel: string, sectionKey: string) => {
    let aiResponse = `Nightingale AI: Displaying details for "${commandLabel}".`;
    if (sectionKey === 'clearance') {
      aiResponse = `Nightingale AI: Displaying Pre-op Clearance status and 6 completed clearance items for ${selectedPatient.name}.`;
    } else if (sectionKey === 'intakeForms') {
      aiResponse = `Nightingale AI: Displaying 9 interactive Intake Forms for ${selectedPatient.name}.`;
    } else if (sectionKey === 'clinicalNotes') {
      aiResponse = `Nightingale AI: Displaying Doctor Notes and Clinical Progress Records for ${selectedPatient.name}.`;
    } else if (sectionKey === 'nursingNotes') {
      aiResponse = `Nightingale AI: Displaying Pre-Op & PACU Nursing Notes for ${selectedPatient.name}.`;
    } else if (sectionKey === 'documents') {
      aiResponse = `Nightingale AI: Displaying 9 verified clinical document records for ${selectedPatient.name}.`;
    } else if (sectionKey === 'medications') {
      aiResponse = `Nightingale AI: Displaying active reconciled medications and E-Prescribe controls.`;
    } else if (sectionKey === 'financial') {
      aiResponse = `Nightingale AI: Displaying Payment & Financial Summary notes and invoice options.`;
    } else if (sectionKey === 'idInsurance') {
      aiResponse = `Nightingale AI: Displaying Driver's License Photo ID and Primary Insurance Cards (Front & Back).`;
    } else if (sectionKey === 'surgicalDetails') {
      aiResponse = `Nightingale AI: Displaying Surgical Team, Surgeon, Anesthesiologist, and OR Location.`;
    } else if (sectionKey === 'quickActions') {
      aiResponse = `Nightingale AI: Displaying Quick Chart Actions & Messaging options.`;
    } else if (sectionKey === 'aiWorkflows') {
      aiResponse = `Nightingale AI: Displaying Chart Intelligence Overview & Ambient Dictation.`;
    } else if (sectionKey === 'all') {
      aiResponse = `Nightingale AI: Displaying all chart sections for ${selectedPatient.name}.`;
    }

    setAiAskChatLog((prev) => [
      ...prev,
      { sender: 'user', text: commandLabel, timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) },
      { sender: 'ai', text: aiResponse, timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) },
    ]);

    setSelectedCommandKey(sectionKey);

    if (sectionKey === 'all') {
      setExpandedSections({
        demographics: true,
        aiBrief: true,
        aiWorkflows: true,
        docUpload: true,
        documents: true,
        intakeForms: true,
        clinicalNotes: true,
        nursingNotes: true,
        clearance: true,
        medications: true,
        financial: true,
        idInsuranceCards: true,
        idInsurance: true,
        surgicalDetails: true,
        quickActions: true,
      });
      setActiveAiResults(['clearance', 'intakeForms', 'clinicalNotes', 'nursingNotes', 'documents', 'medications', 'financial', 'idInsurance', 'surgicalDetails', 'quickActions', 'aiWorkflows']);
    } else {
      setExpandedSections({
        demographics: true,
        aiBrief: true,
        aiWorkflows: sectionKey === 'aiWorkflows',
        docUpload: false,
        documents: sectionKey === 'documents',
        intakeForms: sectionKey === 'intakeForms',
        clinicalNotes: sectionKey === 'clinicalNotes',
        nursingNotes: sectionKey === 'nursingNotes',
        clearance: sectionKey === 'clearance',
        medications: sectionKey === 'medications',
        financial: sectionKey === 'financial',
        idInsuranceCards: sectionKey === 'idInsurance' || sectionKey === 'idInsuranceCards',
        idInsurance: sectionKey === 'idInsurance' || sectionKey === 'idInsuranceCards',
        surgicalDetails: sectionKey === 'surgicalDetails',
        quickActions: sectionKey === 'quickActions',
      });
      setActiveAiResults([sectionKey]);
    }

    // Smooth scroll to the section if element exists
    setTimeout(() => {
      const el = document.getElementById(`${sectionKey}-section`);
      if (el) {
        el.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    }, 100);
  };

  const handleAskAiSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!askAiInput.trim()) return;
    const query = askAiInput.trim();
    setAskAiInput('');

    let matchedKey = 'all';
    const qLower = query.toLowerCase();
    if (qLower.includes('clear') || qLower.includes('pre-op') || qLower.includes('preop')) matchedKey = 'clearance';
    else if (qLower.includes('intake') || qLower.includes('form')) matchedKey = 'intakeForms';
    else if (qLower.includes('doctor') || qLower.includes('clinical') || qLower.includes('h&p')) matchedKey = 'clinicalNotes';
    else if (qLower.includes('nurse') || qLower.includes('nursing')) matchedKey = 'nursingNotes';
    else if (qLower.includes('doc') || qLower.includes('record')) matchedKey = 'documents';
    else if (qLower.includes('med') || qLower.includes('rx') || qLower.includes('prescrip')) matchedKey = 'medications';
    else if (qLower.includes('pay') || qLower.includes('financ') || qLower.includes('bill') || qLower.includes('invoic')) matchedKey = 'financial';
    else if (qLower.includes('insurance') || qLower.includes('card') || qLower.includes('id')) matchedKey = 'idInsurance';
    else if (qLower.includes('surgeon') || qLower.includes('team') || qLower.includes('procedur')) matchedKey = 'surgicalDetails';
    else if (qLower.includes('action') || qLower.includes('quick')) matchedKey = 'quickActions';

    handleExecuteAiCommand(query, matchedKey);
  };

  // Image Zoom Lightbox Modal state
  const [zoomedImage, setZoomedImage] = useState<{ url: string; title: string; subtitle?: string } | null>(null);

  // Clinical Assessment PDF Forms Modal State
  const [isPdfFormsModalOpen, setIsPdfFormsModalOpen] = useState(false);
  const [activePdfFormTab, setActivePdfFormTab] = useState<'standing-orders' | 'preop-checklist' | 'surgical-checklist'>('standing-orders');

  // Pre-Surgery PDF Forms Email & Portal Intake state
  const [selectedPreOpFormIds, setSelectedPreOpFormIds] = useState<string[]>(
    PRE_OP_INTAKE_PDF_FORMS.map((f) => f.id)
  );
  const [formStatuses, setFormStatuses] = useState<Record<string, 'Pending Send' | 'Sent via Email' | 'Completed in Portal'>>({
    'patients-rights': 'Sent via Email',
    'hipaa-notice': 'Completed in Portal',
    'disclosure-ownership': 'Completed in Portal',
    'complaint-grievance': 'Sent via Email',
    'advanced-directives': 'Pending Send',
    'arbitration-agreement': 'Pending Send',
    'acknowledgement-receipt': 'Pending Send',
    'anesthesia-questionnaire': 'Pending Send',
    'consent-anesthesia': 'Pending Send',
    'mh-vte-assessment': 'Pending Send',
    'billing-fee-disclosure': 'Completed in Portal',
    'welcome-surgical-center': 'Sent via Email',
  });
  const [isPreOpEmailModalOpen, setIsPreOpEmailModalOpen] = useState(false);
  const [isPreOpPortalPreviewOpen, setIsPreOpPortalPreviewOpen] = useState(false);
  const [activePortalFormId, setActivePortalFormId] = useState<string>('patients-rights');
  const [preOpEmailSuccessToast, setPreOpEmailSuccessToast] = useState<string | null>(null);
  const [customEmailRecipient, setCustomEmailRecipient] = useState<string>('');

  // Interactive HTML Intake Forms State
  const [intakeFormsList, setIntakeFormsList] = useState<IntakeHtmlForm[]>(INITIAL_INTAKE_HTML_FORMS);
  const [selectedIntakeFormIds, setSelectedIntakeFormIds] = useState<string[]>(
    INITIAL_INTAKE_HTML_FORMS.map((f) => f.id)
  );
  const [viewingHtmlForm, setViewingHtmlForm] = useState<IntakeHtmlForm | null>(null);
  const [sendFormModalItem, setSendFormModalItem] = useState<IntakeHtmlForm | null>(null);
  const [sendChannel, setSendChannel] = useState<'email' | 'sms'>('email');
  const [sendRecipient, setSendRecipient] = useState<string>('');
  const [portalHtmlForm, setPortalHtmlForm] = useState<IntakeHtmlForm | null>(null);

  // Upload Form Modal State
  const [isUploadIntakeModalOpen, setIsUploadIntakeModalOpen] = useState(false);
  const [uploadFormTitle, setUploadFormTitle] = useState('');
  const [uploadFormCategory, setUploadFormCategory] = useState<'Admission' | 'Insurance' | 'Medical' | 'Anesthesia'>('Admission');
  const [uploadFormAudience, setUploadFormAudience] = useState('Patient');
  const [uploadFormContent, setUploadFormContent] = useState('');

  // Electronic Clinical Forms Module State
  const [selectedAppointmentDateForForms, setSelectedAppointmentDateForForms] = useState<string>('May 06, 2026');
  const [activeClinicalFormTab, setActiveClinicalFormTab] = useState<ClinicalFormTab>('asc-1-hp');

  // Notes HTML Forms Module State
  const [notesFormsList, setNotesFormsList] = useState<NoteHtmlForm[]>(INITIAL_NOTES_HTML_FORMS);
  const [viewingNoteForm, setViewingNoteForm] = useState<NoteHtmlForm | null>(null);

  // Nursing Notes HTML Forms Module State
  const [nursingFormsList, setNursingFormsList] = useState<NursingHtmlForm[]>(INITIAL_NURSING_HTML_FORMS);
  const [selectedSurgicalEpisode, setSelectedSurgicalEpisode] = useState<string>('ep-current');
  const [viewingFullNursingForm, setViewingFullNursingForm] = useState<NursingHtmlForm | null>(null);
  const [editingNursingForm, setEditingNursingForm] = useState<NursingHtmlForm | null>(null);
  const [saveEpisodeSuccessToast, setSaveEpisodeSuccessToast] = useState<string | null>(null);

  const handleIframeAutoHeight = (e: React.SyntheticEvent<HTMLIFrameElement>) => {
    const iframe = e.currentTarget;
    if (iframe && iframe.contentWindow && iframe.contentWindow.document) {
      const doc = iframe.contentWindow.document;
      const body = doc.body;
      const html = doc.documentElement;
      if (body) {
        body.style.overflow = 'hidden';
        const height = Math.max(
          body.scrollHeight,
          body.offsetHeight,
          html ? html.clientHeight : 0,
          html ? html.scrollHeight : 0,
          html ? html.offsetHeight : 0
        );
        if (height > 0) {
          iframe.style.height = `${height + 40}px`;
        }
      }
    }
  };

  // Draft Note Workspace state (Image 1)
  const [isNoteWorkspaceOpen, setIsNoteWorkspaceOpen] = useState(false);
  const [draftNoteContent, setDraftNoteContent] = useState('');
  const [viewingHistoryNote, setViewingHistoryNote] = useState<{ id: string; title: string; author: string; date: string; status: string; content: string } | null>(null);

  const openFormsForAppointment = (dateStr: string, defaultTab: ClinicalFormTab = 'asc-1-hp') => {
    setSelectedAppointmentDateForForms(dateStr);
    setActiveClinicalFormTab(defaultTab);
    setActiveSubTab('Documents');
  };

  // E-Prescribe Modal state
  const [isEPrescribeOpen, setIsEPrescribeOpen] = useState(false);
  const [eRxData, setERxData] = useState({
    medication: 'Amoxicillin / Clavulanate (Augmentin)',
    dosage: '875mg / 125mg Oral Tablet',
    instructions: 'Take 1 tablet by mouth twice daily for 7 days',
    quantity: '14',
    refills: '0',
    pharmacy: 'CVS Pharmacy #4820 — 9045 Wilshire Blvd, Beverly Hills, CA',
  });
  const [eRxSuccess, setERxSuccess] = useState(false);

  // Derived card URLs with automatic fallback
  const idCardUrl = selectedPatient.idCardUrl || generateSampleDriverLicense(selectedPatient.name, selectedPatient.dob || '02/11/1972');
  const driverLicenseUrl = idCardUrl;
  const insuranceCardFrontUrl = selectedPatient.insuranceCardFrontUrl || generateSampleInsuranceFront(selectedPatient.name);
  const insuranceCardBackUrl = selectedPatient.insuranceCardBackUrl || generateSampleInsuranceBack();

  // Current Visit To-Do Tasks State
  const [todoTasks, setTodoTasks] = useState([
    { id: 'task-1', text: 'Confirm appointment', completed: true, category: 'Pre-Op Scheduling' },
    { id: 'task-2', text: 'Obtain medical records & clearance', completed: true, category: 'Medical Clearance' },
    { id: 'task-3', text: 'Collect payment', completed: true, category: 'Financial / Billing' },
    { id: 'task-4', text: 'Pre-op phone call', completed: true, category: 'Patient Prep Call' },
    { id: 'task-5', text: 'Patient check-in', completed: true, category: 'Patient Check-In' },
    { id: 'task-6', text: 'Nursing check-in & surgical readiness', completed: false, category: 'Nursing Readiness' },
    { id: 'task-7', text: 'Verified & signed consent', completed: false, category: 'Surgical Consents' },
    { id: 'task-8', text: 'Post-operative paperwork', completed: false, category: 'Post-Op Paperwork' },
    { id: 'task-9', text: 'Patient survey', completed: false, category: 'Patient Survey' },
    { id: 'task-10', text: 'Case finished', completed: false, category: 'Case Complete' },
  ]);

  // Payment & Financial Brief state for Patient Nightingale Brief
  interface PatientPaymentRecord {
    patientId: string;
    source: 'self-pay' | 'doctor-to-pay' | 'insurance' | 'other';
    received: boolean;
    amount: number;
    date: string;
    method: string;
    notes: string;
    invoiceNumber?: string;
  }

  const [patientPayments, setPatientPayments] = useState<{ [key: string]: PatientPaymentRecord }>({
    'p-101': {
      patientId: 'p-101',
      source: 'self-pay',
      received: true,
      amount: 14500,
      date: '2026-07-28',
      method: 'Credit Card (Stripe Patient Portal)',
      notes: 'Pre-op balance paid in full. Facility fee ($8,500) & Surgeon fee ($6,000) settled.',
      invoiceNumber: 'INV-2026-901',
    },
    'p-102': {
      patientId: 'p-102',
      source: 'insurance',
      received: true,
      amount: 18200,
      date: '2026-07-25',
      method: 'Commercial PPO Electronic Remittance (ERA)',
      notes: 'Primary insurance Blue Shield PPO cleared with $500 patient copay.',
      invoiceNumber: 'INV-2026-884',
    },
    'p-103': {
      patientId: 'p-103',
      source: 'doctor-to-pay',
      received: false,
      amount: 9800,
      date: '',
      method: 'Physician Courtesy Account',
      notes: 'Professional courtesy / Doctor house account. Facility fee pending administrative invoice creation.',
      invoiceNumber: '',
    },
    'p-104': {
      patientId: 'p-104',
      source: 'self-pay',
      received: false,
      amount: 16500,
      date: '',
      method: 'Pending Patient Payment',
      notes: 'Self-pay surgical estimate issued. Pre-op deposit outstanding ahead of OR prep.',
      invoiceNumber: '',
    },
  });

  const [isBlankInvoiceModalOpen, setIsBlankInvoiceModalOpen] = useState(false);
  const [isCreateInvoiceModalOpen, setIsCreateInvoiceModalOpen] = useState(false);

  // New Invoice Form State inside Patient Chart
  const [newInvoiceForm, setNewInvoiceForm] = useState({
    patientName: '',
    patientId: '',
    source: 'self-pay' as 'self-pay' | 'doctor-to-pay' | 'insurance' | 'other',
    facilityFee: 8500,
    surgeonFee: 6000,
    anesthesiaFee: 1200,
    implantCharges: 800,
    discounts: 0,
    paymentReceivedAmount: 0,
    paymentDate: new Date().toISOString().split('T')[0],
    notes: '',
  });

  // Blank Invoice Editable Form State
  const [blankInvoiceData, setBlankInvoiceData] = useState({
    invoiceNumber: `INV-BLANK-${Math.floor(1000 + Math.random() * 9000)}`,
    invoiceDate: new Date().toISOString().split('T')[0],
    dueDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    patientName: '',
    patientId: '',
    dob: '',
    guarantor: '',
    dos: new Date().toISOString().split('T')[0],
    surgeon: 'Dr. Richard Zoumalan',
    anesthesiologist: 'Dr. Taheri',
    procedure: '',
    facilityFee: 0,
    surgeonFee: 0,
    anesthesiaFee: 0,
    implantCharges: 0,
    medicationCharges: 0,
    discounts: 0,
    paymentsReceived: 0,
  });

  // Derived current payment record for selected patient
  const currentPayment = patientPayments[selectedPatient.patientId] || {
    patientId: selectedPatient.patientId,
    source: 'self-pay',
    received: false,
    amount: 14500,
    date: '',
    method: 'Pending Payment',
    notes: 'Surgical encounter estimated charges pending payment confirmation.',
    invoiceNumber: '',
  };

  
  // Q&A state for Nightingale patient summary
  const [questionText, setQuestionText] = useState('');
  const [chatLog, setChatLog] = useState<Array<{ sender: 'Clinician' | 'Nightingale'; text: string }>>([
    {
      sender: 'Clinician',
      text: "Anything concerning before today's procedure?",
    },
    {
      sender: 'Nightingale',
      text: "Nothing clinically significant is unresolved. The chart is ready for physician review. Implant confirmation remains an operational exception and does not change the current clinical summary.",
    },
  ]);

  const handleAskQuestion = (e: React.FormEvent) => {
    e.preventDefault();
    if (!questionText.trim()) return;

    const userQ = questionText.trim();
    setChatLog((prev) => [...prev, { sender: 'Clinician', text: userQ }]);
    setQuestionText('');

    // Generate responsive Nightingale answer based on user question
    setTimeout(() => {
      let aiAns = `Nightingale verified: Pre-operative records for ${selectedPatient.name} indicate no unresolved clinical alerts. All vitals and consents are up to date.`;
      const qLower = userQ.toLowerCase();
      
      if (qLower.includes('allergy') || qLower.includes('allergies') || qLower.includes('penicillin')) {
        aiAns = `Nightingale: Documented allergy is ${selectedPatient.allergies.join(', ')}. Pre-op order sets have been screened and verified free of beta-lactams.`;
      } else if (qLower.includes('lab') || qLower.includes('cbc') || qLower.includes('blood')) {
        aiAns = `Nightingale: Pre-op labs (CBC, BMP, Coags) were collected on Jul 13, 2026 and are all within normal limits. Hemoglobin is stable at 13.4 g/dL.`;
      } else if (qLower.includes('implant') || qLower.includes('supplier') || qLower.includes('mentor')) {
        aiAns = `Nightingale: Mentor gel implant tracking number is active. Delivery confirmation to Summit Surgical Center is expected prior to OR 2 prep.`;
      } else if (qLower.includes('consent') || qLower.includes('signed')) {
        aiAns = `Nightingale: Surgical and anesthesia consents were signed digitally by ${selectedPatient.name} on Jul 14, 2026.`;
      }

      setChatLog((prev) => [...prev, { sender: 'Nightingale', text: aiAns }]);
    }, 600);
  };

  return (
    <div className="w-full space-y-6 animate-in fade-in duration-300">

      {/* Top Section Toggle Control Bar (Hidden as requested) */}
      {false && (
        <div className="bg-white p-3.5 rounded-2xl border border-stone-200/90 shadow-2xs flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-blue-50 text-blue-700 rounded-xl border border-blue-200/80">
              <FolderOpen className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-xs font-bold text-stone-900">
                Patient Chart Sections ({Object.values(expandedSections).filter(Boolean).length} / {Object.keys(expandedSections).length} Expanded)
              </h3>
              <p className="text-[11px] text-stone-500 font-medium">
                Click any section title or arrow to toggle view details. All major sections are collapsed by default.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={expandAllSections}
              className="px-3 py-1.5 bg-blue-50 hover:bg-blue-100 text-blue-700 text-xs font-bold rounded-xl border border-blue-200 transition-colors cursor-pointer"
            >
              Expand All Sections
            </button>
            <button
              onClick={collapseAllSections}
              className="px-3 py-1.5 bg-stone-100 hover:bg-stone-200 text-stone-700 text-xs font-bold rounded-xl border border-stone-200 transition-colors cursor-pointer"
            >
              Collapse All Sections
            </button>
          </div>
        </div>
      )}
      
      {/* Main Workspace Layout: 2/3 and 1/3 Grid Columns */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* Left Column: 2/3 of page (8 cols) */}
        <div className="lg:col-span-8 space-y-6">
          
          {/* Patient Demographics Header Card */}
          <div className="bg-white p-5 rounded-2xl border border-stone-200/90 shadow-2xs space-y-3">
            <div className="flex flex-wrap items-start justify-between gap-4">
              <div className="flex items-center gap-3.5">
                <div className="w-14 h-14 rounded-2xl bg-sky-100/90 text-sky-800 font-bold text-lg flex items-center justify-center shrink-0 border border-sky-200 shadow-2xs">
                  {selectedPatient.name.split(' ').map((n) => n[0]).join('')}
                </div>
                <div className="space-y-1">
                  <div className="flex flex-wrap items-center gap-2.5">
                    <h3 className="text-xl font-bold text-stone-900">{selectedPatient.name}</h3>
                  </div>
                  <div className="text-xs text-stone-500 font-medium">
                    {selectedPatient.age} years · {selectedPatient.gender} · DOB {selectedPatient.dob || '02/11/1972'} · Patient ID {selectedPatient.patientId} · {selectedPatient.surgeon}
                  </div>
                  <div className="text-xs text-stone-500 font-medium leading-relaxed pt-0.5">
                    {selectedPatient.aiHistory || `${selectedPatient.age}-year-old ${selectedPatient.gender} presenting for elective facial plastic surgery (${selectedPatient.procedure}) under attending surgeon ${selectedPatient.surgeon}. Baseline H&P reviewed; past medical history unremarkable except documented allergy to Penicillin. Pre-operative cardiac and airway risk stratification completed; cleared for outpatient surgical episode.`}
                  </div>
                </div>
              </div>

              {/* Badges Container */}
              <div className="flex flex-wrap items-center gap-2 ml-auto">
                <span className="px-3 py-1 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200 text-xs font-semibold shadow-2xs flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Portal active</span>
                </span>
                <span className="px-3 py-1 rounded-full bg-sky-50 text-sky-700 border border-sky-200 text-xs font-semibold shadow-2xs flex items-center gap-1">
                  <ShieldCheck className="w-3.5 h-3.5 text-sky-600" />
                  <span>Insurance verified</span>
                </span>
              </div>
            </div>

            {/* Prominent Allergy List */}
            <div className="pt-2.5 border-t border-stone-200/80 space-y-2">
              <div className="flex flex-wrap items-center gap-2 pt-1">
                <span className="font-extrabold text-stone-900 text-xs">Documented Allergies:</span>
                <div className="flex flex-wrap items-center gap-2">
                  {(selectedPatient.allergies && selectedPatient.allergies.length > 0 ? selectedPatient.allergies : ['Penicillin (causes hives/urticaria)']).map((alg, i) => (
                    <span
                      key={i}
                      className="px-4 py-1.5 rounded-full bg-red-600 text-white font-extrabold text-xs shadow-md flex items-center gap-1.5 ring-2 ring-red-300 shrink-0"
                    >
                      <AlertCircle className="w-4 h-4 text-white shrink-0" />
                      <span>{alg.toUpperCase()}</span>
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* AI Summary Card (Placed in Main Area Under Patient Header) */}
          <div className="bg-white rounded-2xl border border-stone-200/90 shadow-2xs overflow-hidden transition-all">
            <button
              onClick={() => toggleSection('aiBrief')}
              className="w-full p-4 flex items-center justify-between gap-4 text-left hover:bg-stone-50/80 transition-colors cursor-pointer"
            >
              <div className="flex items-center gap-2.5 min-w-0">
                <div className="w-8 h-8 rounded-lg bg-indigo-600 text-white flex items-center justify-center shadow-2xs shrink-0">
                  <Sparkles className="w-4 h-4" />
                </div>
                <div className="min-w-0">
                  <h3 className="text-sm font-bold text-stone-900 truncate">
                    Current Visit Summary
                  </h3>
                  <p className="text-[11px] text-stone-500 font-medium truncate">Current Visit · May 06, 2026 · Cleared for Surgery</p>
                </div>
              </div>

              <div className="flex items-center gap-3 shrink-0">
                <span className="px-2.5 py-1 rounded-full bg-indigo-50 text-indigo-700 font-bold text-xs border border-indigo-200/80">
                  Live AI Summary
                </span>
                <div className="p-1.5 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-700 transition-colors">
                  <ChevronDown className={`w-5 h-5 text-stone-600 transition-transform duration-200 ${expandedSections.aiBrief ? 'rotate-180' : ''}`} />
                </div>
              </div>
            </button>

            {expandedSections.aiBrief && (
              <div className="p-5 border-t border-stone-200/80 bg-white space-y-5 animate-in fade-in duration-200">
                {/* Current Visit Brief Overview */}
                <div className="bg-stone-50/80 p-4 rounded-xl border border-stone-200/80 space-y-3">
                  <div className="flex items-center justify-between text-xs font-bold text-stone-900">
                    <span className="flex items-center gap-1.5 text-indigo-950 font-bold">
                      <Building2 className="w-4 h-4 text-indigo-600" />
                      <span>Summit Surgical Center — OR-2</span>
                    </span>
                    <span className="text-xs font-semibold text-emerald-700 bg-emerald-50 px-2.5 py-0.5 rounded-full border border-emerald-200">
                      Pre-Op Cleared
                    </span>
                  </div>

                  {/* Encounter */}
                  <div className="pt-1">
                    <div className="text-base md:text-lg font-black text-stone-950 leading-snug">
                      <span className="text-indigo-900 font-black">Encounter:</span>{' '}
                      <span className="font-extrabold text-stone-900">{selectedPatient.procedure || 'Face & Necklift, Septo-Rhinoplasty, and Turbinates Reduction'}</span>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3 text-xs pt-1 border-t border-stone-200/60">
                    <div className="bg-white p-2.5 rounded-xl border border-stone-200/70">
                      <span className="text-stone-400 font-bold block text-[10px] uppercase">Surgeon</span>
                      <span className="font-bold text-stone-800">{selectedPatient.surgeon || 'Dr. R. Zoumalan'}</span>
                    </div>
                    <div className="bg-white p-2.5 rounded-xl border border-stone-200/70">
                      <span className="text-stone-400 font-bold block text-[10px] uppercase">Anesthesia</span>
                      <span className="font-bold text-stone-800">Dr. Taheri</span>
                    </div>
                  </div>

                  {/* NOTE: Allergy Alert bubble removed from this section as requested */}
                </div>

                {/* Cleared for surgery Banner */}
                <div className="p-3.5 bg-emerald-50 text-emerald-950 rounded-xl border border-emerald-200/90 shadow-2xs flex flex-wrap items-center justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-emerald-600 text-white flex items-center justify-center font-bold text-sm shadow-2xs shrink-0">
                      ✓
                    </div>
                    <div>
                      <h3 className="font-bold text-xs text-emerald-950 flex items-center gap-2">
                        Cleared for surgery
                      </h3>
                      <p className="text-[11px] text-emerald-800 font-medium mt-0.5">
                        All 6 clearance items are complete. Nothing outstanding ahead of surgery.
                      </p>
                    </div>
                  </div>
                  <button
                    onClick={() => handleExecuteAiCommand('Show me the Pre-op Clearance', 'clearance')}
                    className="px-3 py-1.5 bg-white hover:bg-emerald-100/60 text-emerald-900 border border-emerald-300 font-bold text-xs rounded-lg shadow-2xs transition-colors cursor-pointer shrink-0"
                  >
                    Review checklist
                  </button>
                </div>

                {/* Hidden: Payment & Financial Summary Notes */}
                {false && (
                  <div className="p-4 bg-slate-900 text-white rounded-2xl border border-slate-800 shadow-2xs space-y-3.5">
                    <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 pb-3">
                      <div className="flex items-center gap-2.5">
                        <div className="w-8 h-8 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center justify-center shrink-0">
                          <DollarSign className="w-4 h-4" />
                        </div>
                        <div>
                          <h4 className="font-bold text-xs text-white flex items-center gap-2">
                            <span>Payment & Financial Summary Note</span>
                          </h4>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {/* Hidden: Current Visit To-Do Task section */}
                {false && (
                  <div className="space-y-2.5">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-stone-900 flex items-center gap-1.5">
                        <FileCheck className="w-4 h-4 text-indigo-600" />
                        <span>Current Visit To-Do Tasks</span>
                      </span>
                    </div>
                  </div>
                )}

                {/* ASK NIGHTINGALE AI CHAT BOX SECTION */}
                <div className="mt-6 border-t border-stone-200/90 pt-5 space-y-4">
                  <div className="bg-white text-stone-900 p-5 rounded-2xl shadow-2xs border border-stone-200/90 space-y-4">
                    {/* Chat Box Header */}
                    <div className="flex items-center justify-between border-b border-stone-200/80 pb-3">
                      <div className="flex items-center gap-2.5">
                        <div className="w-8 h-8 rounded-xl bg-indigo-50 text-indigo-600 border border-indigo-200/80 flex items-center justify-center shadow-2xs shrink-0">
                          <Sparkles className="w-4 h-4 text-indigo-600" />
                        </div>
                        <div>
                          <h4 className="font-bold text-sm text-stone-900 flex items-center gap-2">
                            <span>Ask Nightingale AI</span>
                            <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-indigo-50 text-indigo-700 border border-indigo-200/80 font-semibold">
                              Live EHR Assistant
                            </span>
                          </h4>
                          <p className="text-[11px] text-stone-500 font-medium">
                            Query patient records, pre-op clearances, intake forms, doctor & nursing notes, medications, and financial summaries
                          </p>
                        </div>
                      </div>
                    </div>

                    {/* Chat Message Stream */}
                    <div className="space-y-3 max-h-56 overflow-y-auto pr-1 text-xs">
                      {aiAskChatLog.map((msg, idx) => (
                        <div
                          key={idx}
                          className={`p-3 rounded-xl max-w-2xl leading-relaxed font-medium ${
                            msg.sender === 'user'
                              ? 'bg-indigo-600 text-white ml-auto text-right shadow-2xs'
                              : 'bg-stone-50 text-stone-900 border border-stone-200/90 shadow-2xs'
                          }`}
                        >
                          <div className={`text-[10px] font-bold mb-1 flex items-center gap-1.5 justify-between ${msg.sender === 'user' ? 'text-indigo-100' : 'text-stone-500'}`}>
                            <span>{msg.sender === 'user' ? 'You' : 'Nightingale AI'}</span>
                            <span className={`text-[9px] font-mono ${msg.sender === 'user' ? 'text-indigo-200' : 'text-stone-400'}`}>{msg.timestamp}</span>
                          </div>
                          <div>{msg.text}</div>
                        </div>
                      ))}
                    </div>

                    {/* Interactive Input Form */}
                    <form onSubmit={handleAskAiSubmit} className="flex items-center gap-2">
                      <input
                        type="text"
                        value={askAiInput}
                        onChange={(e) => setAskAiInput(e.target.value)}
                        placeholder="Ask Nightingale AI (e.g., Show me the Pre-op Clearance, Show me Doctor Notes)..."
                        className="flex-1 bg-stone-50 text-stone-900 border border-stone-200/90 rounded-xl px-4 py-2.5 text-xs font-medium focus:outline-none focus:ring-2 focus:ring-indigo-500 placeholder:text-stone-400"
                      />
                      <button
                        type="submit"
                        className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-xl shadow-2xs transition-colors cursor-pointer flex items-center gap-1.5 shrink-0"
                      >
                        <Send className="w-3.5 h-3.5" />
                        <span>Ask AI</span>
                      </button>
                    </form>

                    {/* Suggested Command Badges */}
                    <div className="pt-3 border-t border-stone-200/80 space-y-2.5">
                      <div className="flex items-center justify-between">
                        <span className="text-[11px] font-extrabold text-stone-700 uppercase tracking-wider flex items-center gap-1.5">
                          <Sparkles className="w-3.5 h-3.5 text-indigo-600" />
                          <span>Suggested Commands (Click to Display Content):</span>
                        </span>
                        {selectedCommandKey && selectedCommandKey !== 'all' && (
                          <span className="text-[10px] font-bold text-indigo-700 bg-indigo-50 px-2.5 py-0.5 rounded-full border border-indigo-200">
                            Filtered View Active
                          </span>
                        )}
                      </div>
                      <div className="flex flex-wrap items-center gap-2">
                        {[
                          { label: 'Pre-op Clearance', key: 'clearance', icon: CheckCircle2 },
                          { label: 'Intake Forms', key: 'intakeForms', icon: FileCheck },
                          { label: 'Doctor Notes', key: 'clinicalNotes', icon: FileText },
                          { label: 'Nursing Notes', key: 'nursingNotes', icon: FileCheck },
                          { label: 'Documents', key: 'documents', icon: FileText },
                          { label: 'Medications', key: 'medications', icon: Stethoscope },
                          { label: 'Payment & Financial', key: 'financial', icon: DollarSign },
                          { label: 'ID & Insurance', key: 'idInsurance', icon: CreditCard },
                          { label: 'Surgical Team', key: 'surgicalDetails', icon: Building2 },
                          { label: 'Quick Actions', key: 'quickActions', icon: Zap },
                          { label: 'Chart Intelligence', key: 'aiWorkflows', icon: Sparkles },
                          { label: 'Show All Sections', key: 'all', icon: Layers },
                        ].map((cmd) => {
                          const IconComp = cmd.icon;
                          const isActive = selectedCommandKey === cmd.key || selectedCommandKey === 'all';
                          return (
                            <button
                              key={cmd.key}
                              type="button"
                              onClick={() => handleExecuteAiCommand(`Show me ${cmd.label}`, cmd.key)}
                              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer border flex items-center gap-1.5 shadow-2xs ${
                                isActive
                                  ? 'bg-indigo-600 text-white border-indigo-700 ring-2 ring-indigo-200 font-extrabold'
                                  : 'bg-stone-50 hover:bg-stone-100 text-stone-700 border-stone-200/90'
                              }`}
                            >
                              <IconComp className={`w-3.5 h-3.5 ${isActive ? 'text-white' : 'text-stone-500'}`} />
                              <span>{cmd.label}</span>
                              {isActive && <Check className="w-3 h-3 text-white ml-0.5" />}
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Active Content Section Display (Shown On-Demand Based on Selected Command) */}

          {/* Section: Pre-op Clearance Checklist */}
          {(expandedSections.clearance || expandedSections.all) && (
            <div id="clearance-section" className="bg-white rounded-2xl border border-stone-200/90 shadow-2xs p-5 space-y-4 animate-in fade-in duration-200">
              <div className="flex items-center justify-between border-b border-stone-200/80 pb-3">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-xl bg-emerald-600 text-white flex items-center justify-center shadow-xs shrink-0">
                    <CheckCircle2 className="w-4.5 h-4.5 text-white" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-stone-900">Pre-Operative Medical Clearance Checklist</h3>
                    <p className="text-xs text-stone-500 font-medium">Real-time status of required pre-op clearances for {selectedPatient.name}</p>
                  </div>
                </div>
                <span className="px-3 py-1 bg-emerald-50 text-emerald-800 text-xs font-bold rounded-full border border-emerald-200 shadow-2xs">
                  ✓ 6 of 6 Cleared
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-1">
                <div className="p-3 bg-emerald-50/70 text-emerald-950 text-xs font-bold rounded-xl border border-emerald-200 flex items-center gap-2.5 shadow-2xs">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>History & Physical (≤ 30 days)</span>
                </div>
                <div className="p-3 bg-emerald-50/70 text-emerald-950 text-xs font-bold rounded-xl border border-emerald-200 flex items-center gap-2.5 shadow-2xs">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>CBC (Complete Blood Count)</span>
                </div>
                <div className="p-3 bg-emerald-50/70 text-emerald-950 text-xs font-bold rounded-xl border border-emerald-200 flex items-center gap-2.5 shadow-2xs">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>BMP (Basic Metabolic Panel)</span>
                </div>
                <div className="p-3 bg-emerald-50/70 text-emerald-950 text-xs font-bold rounded-xl border border-emerald-200 flex items-center gap-2.5 shadow-2xs">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>ECG (12-Lead Electrocardiogram)</span>
                </div>
                <div className="p-3 bg-emerald-50/70 text-emerald-950 text-xs font-bold rounded-xl border border-emerald-200 flex items-center gap-2.5 shadow-2xs">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>Anesthesia Pre-Op Evaluation</span>
                </div>
                <div className="p-3 bg-emerald-50/70 text-emerald-950 text-xs font-bold rounded-xl border border-emerald-200 flex items-center gap-2.5 shadow-2xs">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>Signed Informed Surgical Consent</span>
                </div>
              </div>

              <div className="p-3.5 bg-purple-50/80 border border-purple-200/80 rounded-xl text-xs text-purple-950 flex items-start gap-2.5">
                <Sparkles className="w-4 h-4 text-purple-600 shrink-0 mt-0.5" />
                <p className="leading-relaxed font-medium">
                  <strong className="font-bold text-purple-900">AI Medical Clearance Engine:</strong> All 6 clearance items are verified and active for {selectedPatient.name}. Surgery episode DOS May 06, 2026 is fully cleared.
                </p>
              </div>
            </div>
          )}

          {/* Section: Chart Intelligence Overview */}
          {(expandedSections.aiWorkflows || expandedSections.all) && (
            <div id="aiWorkflows-section">
              <AIPatientChartOverview
                patient={selectedPatient}
                onShowToast={showToast}
              />
            </div>
          )}

          {/* Section 1: Documents */}
          {(expandedSections.documents || expandedSections.all) && (
          <div id="documents-section" className="bg-white rounded-2xl border border-stone-200/90 shadow-2xs overflow-hidden transition-all">
            <button
              onClick={() => toggleSection('documents')}
              className="w-full p-4 flex items-center justify-between gap-4 text-left hover:bg-stone-50/80 transition-colors cursor-pointer"
            >
              <div className="flex items-center gap-3 min-w-0">
                <div className="w-8 h-8 rounded-xl bg-blue-600 text-white flex items-center justify-center shadow-xs shrink-0">
                  <FileText className="w-4 h-4 text-white" />
                </div>
                <div className="min-w-0">
                  <div className="flex items-center gap-2">
                    <h3 className="text-sm font-bold text-stone-900 truncate">Documents</h3>
                    <span className="px-2.5 py-0.5 rounded-full bg-blue-50 text-blue-800 border border-blue-200 text-[10px] font-bold">
                      9 Verified Records
                    </span>
                  </div>
                  <div className="flex items-center gap-1.5 text-xs text-stone-600 font-medium mt-0.5 truncate">
                    <Sparkles className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
                    <span><strong>AI Summary:</strong> 9 Summit Surgical Center PDF records converted into interactive HTML forms for DOS May 06, 2026.</span>
                  </div>
                </div>
              </div>

              <div className="p-1.5 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-700 transition-colors shrink-0">
                <ChevronDown className={`w-5 h-5 text-stone-600 transition-transform duration-200 ${expandedSections.documents ? 'rotate-180' : ''}`} />
              </div>
            </button>

            {expandedSections.documents && (
              <div className="p-5 border-t border-stone-200/80 bg-white space-y-6 animate-in fade-in duration-200">
                {/* Toast Notification Banner */}
                {toastMessage && (
                  <div className="p-3.5 bg-emerald-600 text-white font-bold text-xs rounded-xl shadow-md flex items-center justify-between animate-in fade-in slide-in-from-top-2 duration-200">
                    <div className="flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4 text-emerald-200" />
                      <span>{toastMessage}</span>
                    </div>
                    <button
                      onClick={() => setToastMessage(null)}
                      className="text-emerald-200 hover:text-white text-xs font-bold cursor-pointer"
                    >
                      ✕
                    </button>
                  </div>
                )}

                {/* Section Header & Toolbar */}
                <div className="flex flex-wrap items-center justify-between border-b border-stone-200/80 pb-4 gap-4">
                  <div>
                    <h3 className="font-bold text-base text-stone-900 flex items-center gap-2">
                      <FileText className="w-5 h-5 text-indigo-600" />
                      <span>Uploaded Patient Documents & Clinical Records</span>
                      <span className="px-2.5 py-0.5 rounded-full bg-indigo-100 text-indigo-900 text-xs font-bold border border-indigo-200">
                        {filteredDocList.length} Files
                      </span>
                    </h3>
                    <p className="text-xs text-stone-500 mt-1">
                      Structured index of all uploaded records, converted PDF assessment forms, consents, and lab reports for {selectedPatient.name}
                    </p>
                  </div>

                  <div className="flex items-center gap-2.5">
                    {/* Upload Document Button */}
                    <label className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-xl flex items-center gap-2 shadow-sm transition-colors cursor-pointer">
                      <Upload className="w-4 h-4 text-indigo-200" />
                      <span>Upload Document</span>
                      <input
                        type="file"
                        className="hidden"
                        onChange={handleFileUpload}
                      />
                    </label>
                  </div>
                </div>

                {/* Search Bar & Category Filters */}
                <div className="space-y-3">
                  <div className="flex flex-wrap items-center gap-3">
                    <div className="relative flex-1 min-w-[240px]">
                      <Search className="w-4 h-4 text-stone-400 absolute left-3.5 top-3" />
                      <input
                        type="text"
                        value={docSearchQuery}
                        onChange={(e) => setDocSearchQuery(e.target.value)}
                        placeholder="Search by file name, submission date, or category..."
                        className="w-full pl-10 pr-4 py-2 bg-stone-50 border border-stone-300 rounded-xl text-xs text-stone-800 focus:outline-none focus:ring-2 focus:ring-indigo-500 font-medium"
                      />
                      {docSearchQuery && (
                        <button
                          onClick={() => setDocSearchQuery('')}
                          className="absolute right-3 top-2.5 text-stone-400 hover:text-stone-600 text-xs font-bold"
                        >
                          ✕
                        </button>
                      )}
                    </div>
                  </div>

                  {/* Category Filter Pills */}
                  <div className="flex flex-wrap gap-1.5">
                    {['All', 'Converted PDF Form', 'Clinical Note', 'Consent', 'Laboratory', 'Outside Record', 'ID & Insurance', 'Uploaded Document'].map((cat) => (
                      <button
                        key={cat}
                        onClick={() => setDocFilterCategory(cat)}
                        className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                          docFilterCategory === cat
                            ? 'bg-indigo-900 text-white shadow-xs'
                            : 'bg-stone-100 text-stone-600 hover:bg-stone-200 border border-stone-200'
                        }`}
                      >
                        {cat}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Reorganized Documents Table */}
                <div className="bg-white rounded-2xl border border-stone-200/90 shadow-2xs overflow-hidden max-w-4xl">
                  <div className="overflow-x-auto">
                    <table className="w-full text-left border-collapse">
                      <thead>
                        <tr className="bg-stone-100/90 border-b border-stone-200 text-[11px] font-bold text-stone-600 uppercase tracking-wider">
                          <th className="py-3.5 px-4">File Name & Details</th>
                          <th className="py-3.5 px-4">Submission Date</th>
                          <th className="py-3.5 px-4 text-center">Actions</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-stone-100 text-xs text-stone-700 font-medium">
                        {filteredDocList.map((doc) => (
                          <tr key={doc.id} className="hover:bg-indigo-50/40 transition-colors group">
                            {/* File Name & Details */}
                            <td className="py-3.5 px-4">
                              <div className="flex items-center gap-3">
                                <div className="w-9 h-9 rounded-xl bg-indigo-50 text-indigo-700 border border-indigo-200 flex items-center justify-center shrink-0 shadow-2xs group-hover:bg-indigo-600 group-hover:text-white transition-colors">
                                  <FileText className="w-4.5 h-4.5" />
                                </div>
                                <div className="min-w-0">
                                  <div className="font-bold text-stone-900 flex items-center gap-2 flex-wrap">
                                    <span 
                                      onClick={() => setViewingDoc(doc)}
                                      className="hover:text-indigo-600 transition-colors cursor-pointer"
                                    >
                                      {doc.fileName}
                                    </span>
                                    {doc.status === 'Interactive HTML' && (
                                      <span className="px-1.5 py-0.5 rounded bg-indigo-100 text-indigo-800 text-[9px] font-bold border border-indigo-200">
                                        HTML Form
                                      </span>
                                    )}
                                  </div>
                                  <div className="text-[11px] text-stone-500 font-normal mt-0.5 truncate max-w-md">
                                    {doc.title} {doc.fileSize ? `· ${doc.fileSize}` : ''}
                                  </div>
                                </div>
                              </div>
                            </td>

                            {/* Submission Date */}
                            <td className="py-3.5 px-4 whitespace-nowrap font-semibold text-stone-600">
                              <div className="flex items-center gap-1.5">
                                <Calendar className="w-3.5 h-3.5 text-stone-400" />
                                <span>{doc.submissionDate}</span>
                              </div>
                            </td>

                            {/* Actions: View, Download, Delete (Icons Only) */}
                            <td className="py-3.5 px-4 text-center whitespace-nowrap">
                              <div className="flex items-center justify-center gap-1.5">
                                {/* View Button */}
                                <button
                                  onClick={() => setViewingDoc(doc)}
                                  title="View Document"
                                  className="p-2 rounded-xl bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200 transition-colors cursor-pointer shadow-2xs"
                                >
                                  <Eye className="w-4 h-4 text-indigo-600" />
                                </button>

                                {/* Download Button */}
                                <button
                                  onClick={() => handleDownloadDoc(doc)}
                                  title="Download File"
                                  className="p-2 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-200 transition-colors cursor-pointer shadow-2xs"
                                >
                                  <Download className="w-4 h-4 text-emerald-600" />
                                </button>

                                {/* Delete Button */}
                                <button
                                  onClick={() => handleDeleteDoc(doc.id)}
                                  title="Delete Document"
                                  className="p-2 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 transition-colors cursor-pointer shadow-2xs"
                                >
                                  <Trash2 className="w-4 h-4 text-rose-600" />
                                </button>
                              </div>
                            </td>
                          </tr>
                        ))}

                        {filteredDocList.length === 0 && (
                          <tr>
                            <td colSpan={3} className="py-8 text-center text-stone-500 font-medium">
                              No documents match your search query or selected category filter.
                            </td>
                          </tr>
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* Documents Clearance Summary Card */}
                <div className="p-4 bg-stone-50/50 rounded-xl border border-stone-200/80 space-y-4">
                  <div className="flex items-center justify-between border-b border-stone-100 pb-3">
                    <h4 className="font-bold text-sm text-stone-900">Pre-Operative Clearance Documents Status</h4>
                    <button
                      onClick={() => alert(`Viewing full clearance checklist for ${selectedPatient.name}`)}
                      className="text-xs font-bold text-emerald-700 hover:text-emerald-800 flex items-center gap-1 cursor-pointer"
                    >
                      <span>View full checklist</span>
                      <span>→</span>
                    </button>
                  </div>

                  {/* Clearance Pills */}
                  <div className="flex flex-wrap gap-2">
                    <span className="px-3 py-1.5 bg-emerald-50 text-emerald-800 text-xs font-bold rounded-xl border border-emerald-200 flex items-center gap-1.5 shadow-2xs">
                      <span className="text-emerald-600 font-bold">✓</span> History & Physical (≤ 30 days)
                    </span>
                    <span className="px-3 py-1.5 bg-emerald-50 text-emerald-800 text-xs font-bold rounded-xl border border-emerald-200 flex items-center gap-1.5 shadow-2xs">
                      <span className="text-emerald-600 font-bold">✓</span> CBC
                    </span>
                    <span className="px-3 py-1.5 bg-emerald-50 text-emerald-800 text-xs font-bold rounded-xl border border-emerald-200 flex items-center gap-1.5 shadow-2xs">
                      <span className="text-emerald-600 font-bold">✓</span> BMP
                    </span>
                    <span className="px-3 py-1.5 bg-emerald-50 text-emerald-800 text-xs font-bold rounded-xl border border-emerald-200 flex items-center gap-1.5 shadow-2xs">
                      <span className="text-emerald-600 font-bold">✓</span> ECG (age &gt; 50 or cardiac history)
                    </span>
                    <span className="px-3 py-1.5 bg-emerald-50 text-emerald-800 text-xs font-bold rounded-xl border border-emerald-200 flex items-center gap-1.5 shadow-2xs">
                      <span className="text-emerald-600 font-bold">✓</span> Anesthesia pre-operative review
                    </span>
                    <span className="px-3 py-1.5 bg-emerald-50 text-emerald-800 text-xs font-bold rounded-xl border border-emerald-200 flex items-center gap-1.5 shadow-2xs">
                      <span className="text-emerald-600 font-bold">✓</span> Signed informed consent
                    </span>
                  </div>

                  {/* AI Callout Box */}
                  <div className="p-3.5 bg-purple-50/70 border border-purple-200/80 rounded-xl text-xs text-purple-950 flex items-start gap-2.5">
                    <span className="text-purple-600 font-bold text-sm leading-none pt-0.5">✦</span>
                    <p className="leading-relaxed">
                      <strong className="font-bold text-purple-900">AI keeps this current:</strong> every checklist item updates automatically as new documents arrive, so this reflects the real-time clearance state — not what was true at last chart review.
                    </p>
                  </div>
                </div>
              </div>
            )}
          </div>
          )}

          {/* Section 3: Intake Forms */}
          {(expandedSections.intakeForms || expandedSections.all) && (
          <div id="intakeForms-section" className="bg-white rounded-2xl border border-stone-200/90 shadow-2xs overflow-hidden transition-all">
            <button
              onClick={() => toggleSection('intakeForms')}
              className="w-full p-4 flex items-center justify-between gap-4 text-left hover:bg-stone-50/80 transition-colors cursor-pointer"
            >
              <div className="flex items-center gap-3 min-w-0">
                <div className="w-8 h-8 rounded-xl bg-indigo-600 text-white flex items-center justify-center shadow-xs shrink-0">
                  <FileCheck className="w-4 h-4 text-white" />
                </div>
                <div className="min-w-0">
                  <div className="flex items-center gap-2">
                    <h3 className="text-sm font-bold text-stone-900 truncate">Intake Forms</h3>
                    <span className="px-2.5 py-0.5 rounded-full bg-indigo-50 text-indigo-800 border border-indigo-200 text-[10px] font-bold">
                      {intakeFormsList.length} Active Forms
                    </span>
                  </div>
                  <div className="flex items-center gap-1.5 text-xs text-stone-600 font-medium mt-0.5 truncate">
                    <Sparkles className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
                    <span><strong>Patient Portal Links:</strong> Interactive intake forms ordered by Admission, Insurance, Medical, and Anesthesia. Send links for home completion.</span>
                  </div>
                </div>
              </div>

              <div className="p-1.5 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-700 transition-colors shrink-0">
                <ChevronDown className={`w-5 h-5 text-stone-600 transition-transform duration-200 ${expandedSections.intakeForms ? 'rotate-180' : ''}`} />
              </div>
            </button>

            {expandedSections.intakeForms && (
              <div className="p-5 border-t border-stone-200/80 bg-white space-y-4 animate-in fade-in duration-200">
                {/* Header Actions & Upload Button */}
                <div className="flex flex-wrap items-center justify-between gap-3 border-b border-stone-200/80 pb-3">
                  <div>
                    <h4 className="font-bold text-sm text-stone-900">Pre-Operative Patient Intake Forms</h4>
                    <p className="text-xs text-stone-500 font-medium mt-0.5">
                      Send interactive HTML forms via Email or SMS link for <strong className="text-stone-800">{selectedPatient.name}</strong> to complete at home in the patient portal.
                    </p>
                  </div>

                  <div className="flex flex-wrap items-center gap-2">
                    <button
                      onClick={() => {
                        if (selectedIntakeFormIds.length === 0 && intakeFormsList.length > 0) {
                          setSelectedIntakeFormIds(intakeFormsList.map((f) => f.id));
                        }
                        const firstPending = intakeFormsList.find((f) => selectedIntakeFormIds.includes(f.id)) || intakeFormsList[0];
                        if (firstPending) {
                          setSendFormModalItem(firstPending);
                          setSendRecipient(selectedPatient.email || '');
                        }
                      }}
                      className="px-3.5 py-1.5 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-xl shadow-2xs transition-colors cursor-pointer flex items-center gap-1.5"
                    >
                      <Send className="w-4 h-4" />
                      <span>Send Selected ({selectedIntakeFormIds.length}) via Email/SMS</span>
                    </button>
                  </div>
                </div>

                {/* Toast Notification */}
                {preOpEmailSuccessToast && (
                  <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-xs font-bold text-emerald-900 flex items-center justify-between shadow-2xs">
                    <div className="flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                      <span>{preOpEmailSuccessToast}</span>
                    </div>
                    <button onClick={() => setPreOpEmailSuccessToast(null)} className="text-emerald-700 hover:text-emerald-900 font-bold cursor-pointer">
                      Dismiss
                    </button>
                  </div>
                )}

                {/* Table View of Forms */}
                <div className="overflow-x-auto border border-stone-200 rounded-2xl shadow-2xs max-w-4xl">
                  <table className="w-full text-left border-collapse">
                    <thead>
                      <tr className="bg-stone-100/80 border-b border-stone-200 text-[11px] font-bold text-stone-600 uppercase tracking-wider">
                        <th className="p-3.5 pl-4 w-10 text-center">
                          <input
                            type="checkbox"
                            checked={intakeFormsList.length > 0 && selectedIntakeFormIds.length === intakeFormsList.length}
                            onChange={(e) => {
                              if (e.target.checked) {
                                setSelectedIntakeFormIds(intakeFormsList.map((f) => f.id));
                              } else {
                                setSelectedIntakeFormIds([]);
                              }
                            }}
                            className="w-4 h-4 rounded border-stone-300 text-indigo-600 focus:ring-indigo-500 cursor-pointer"
                            title="Select / Deselect All Forms"
                          />
                        </th>
                        <th className="p-3.5"># & Form Name</th>
                        <th className="p-3.5">Status</th>
                        <th className="p-3.5">Last Activity</th>
                        <th className="p-3.5 text-right pr-4">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-stone-200/80 text-xs">
                      {(() => {
                        if (intakeFormsList.length === 0) {
                          return (
                            <tr>
                              <td colSpan={5} className="p-8 text-center text-stone-500 font-medium">
                                No intake forms found. Click "Upload New Intake Form" to add one.
                              </td>
                            </tr>
                          );
                        }

                        return intakeFormsList.map((form, idx) => (
                          <tr key={form.id} className="hover:bg-stone-50/80 transition-colors">
                            <td className="p-3.5 pl-4 w-10 text-center">
                              <input
                                type="checkbox"
                                checked={selectedIntakeFormIds.includes(form.id)}
                                onChange={() => {
                                  if (selectedIntakeFormIds.includes(form.id)) {
                                    setSelectedIntakeFormIds(selectedIntakeFormIds.filter((id) => id !== form.id));
                                  } else {
                                    setSelectedIntakeFormIds([...selectedIntakeFormIds, form.id]);
                                  }
                                }}
                                className="w-4 h-4 rounded border-stone-300 text-indigo-600 focus:ring-indigo-500 cursor-pointer"
                              />
                            </td>

                            <td className="p-3.5 min-w-[200px]">
                              <div className="flex items-start gap-2.5">
                                <span className="w-5 h-5 rounded-full bg-stone-200 text-stone-800 font-bold text-[10px] flex items-center justify-center shrink-0 mt-0.5">
                                  {idx + 1}
                                </span>
                                <div>
                                  <div className="font-bold text-stone-900 text-xs flex items-center gap-1.5">
                                    <span>{form.title}</span>
                                  </div>
                                  <div className="text-[11px] text-stone-500 font-medium line-clamp-1 mt-0.5">
                                    {form.fileName}
                                  </div>
                                </div>
                              </div>
                            </td>

                            <td className="p-3.5">
                              <span
                                className={`px-2.5 py-1 rounded-full text-[10.5px] font-bold border flex items-center gap-1.5 w-fit ${
                                  form.status === 'Completed in Portal'
                                    ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                                    : form.status === 'Sent via Email'
                                    ? 'bg-blue-50 text-blue-800 border-blue-200'
                                    : form.status === 'Sent via SMS'
                                    ? 'bg-teal-50 text-teal-800 border-teal-200'
                                    : 'bg-amber-50 text-amber-800 border-amber-200'
                                }`}
                              >
                                {form.status === 'Completed in Portal' && <CheckCircle2 className="w-3 h-3 text-emerald-600" />}
                                {form.status === 'Sent via Email' && <Mail className="w-3 h-3 text-blue-600" />}
                                {form.status === 'Sent via SMS' && <Smartphone className="w-3 h-3 text-teal-600" />}
                                {form.status === 'Pending Send' && <Clock className="w-3 h-3 text-amber-600" />}
                                <span>{form.status}</span>
                              </span>
                            </td>

                            <td className="p-3.5 text-stone-500 text-[11px] font-mono">
                              {form.completedDate ? `Completed ${form.completedDate}` : form.lastSentDate ? `Sent ${form.lastSentDate}` : 'Not sent yet'}
                            </td>

                            <td className="p-3.5 text-right pr-4">
                              <div className="flex items-center justify-end gap-1.5">
                                {/* View HTML Form Button */}
                                <button
                                  onClick={() => setViewingHtmlForm(form)}
                                  title="View Form HTML"
                                  className="p-1.5 bg-white hover:bg-stone-100 text-stone-700 hover:text-stone-900 border border-stone-300 rounded-lg transition-colors cursor-pointer shadow-2xs flex items-center gap-1 text-[11px] font-bold"
                                >
                                  <Eye className="w-3.5 h-3.5 text-indigo-600" />
                                  <span className="hidden sm:inline">View</span>
                                </button>

                                {/* Send Link via Email / SMS */}
                                <button
                                  onClick={() => {
                                    if (!selectedIntakeFormIds.includes(form.id)) {
                                      setSelectedIntakeFormIds([...selectedIntakeFormIds, form.id]);
                                    }
                                    setSendFormModalItem(form);
                                    setSendRecipient(selectedPatient.email || '');
                                  }}
                                  title="Send Link via Email or SMS"
                                  className="p-1.5 bg-white hover:bg-stone-100 text-stone-700 hover:text-stone-900 border border-stone-300 rounded-lg transition-colors cursor-pointer shadow-2xs flex items-center gap-1 text-[11px] font-bold"
                                >
                                  <Send className="w-3.5 h-3.5 text-blue-600" />
                                  <span className="hidden sm:inline">Send Link</span>
                                </button>
                              </div>
                            </td>
                          </tr>
                        ));
                      })()}
                    </tbody>
                  </table>
                </div>

                <div className="p-3.5 bg-teal-50/80 border border-teal-200 rounded-xl text-xs text-teal-950 flex items-center justify-between shadow-2xs">
                  <div className="flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-teal-700 shrink-0" />
                    <span>
                      <strong>EHR Documents Integration:</strong> When patients complete any intake form via portal link, it automatically converts to a verified record and is added to the <strong>Documents</strong> section above.
                    </span>
                  </div>
                </div>
              </div>
            )}
          </div>
          )}

          {/* Section 4: Doctor Notes */}
          {(expandedSections.clinicalNotes || expandedSections.all) && (
          <div id="clinicalNotes-section" className="bg-white rounded-2xl border border-stone-200/90 shadow-2xs overflow-hidden transition-all">
            <button
              onClick={() => toggleSection('clinicalNotes')}
              className="w-full p-4 flex items-center justify-between gap-4 text-left hover:bg-stone-50/80 transition-colors cursor-pointer"
            >
              <div className="flex items-center gap-3 min-w-0">
                <div className="w-8 h-8 rounded-xl bg-purple-600 text-white flex items-center justify-center shadow-xs shrink-0">
                  <FileText className="w-4 h-4 text-white" />
                </div>
                <div className="min-w-0">
                  <div className="flex items-center gap-2">
                    <h3 className="text-sm font-bold text-stone-900 truncate">Doctor Notes</h3>
                    <span className="px-2.5 py-0.5 rounded-full bg-purple-50 text-purple-800 border border-purple-200 text-[10px] font-bold">
                      {notesFormsList.length} Doctor Notes Forms
                    </span>
                  </div>
                  <div className="flex items-center gap-1.5 text-xs text-stone-600 font-medium mt-0.5 truncate">
                    <Sparkles className="w-3.5 h-3.5 text-purple-600 shrink-0" />
                    <span><strong>Interactive Physician Notes:</strong> 1. History & Physical, 2. SOAP Note, 3. Daily Doctor's Note HTML forms attached and ready.</span>
                  </div>
                </div>
              </div>

              <div className="p-1.5 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-700 transition-colors shrink-0">
                <ChevronDown className={`w-5 h-5 text-stone-600 transition-transform duration-200 ${expandedSections.clinicalNotes ? 'rotate-180' : ''}`} />
              </div>
            </button>

            {expandedSections.clinicalNotes && (
              <div className="p-5 border-t border-stone-200/80 bg-white space-y-4 animate-in fade-in duration-200">
                <div className="flex flex-wrap items-center justify-between border-b border-stone-200/80 pb-3 gap-2">
                  <div className="flex items-center gap-2">
                    <FileText className="w-4 h-4 text-indigo-600" />
                    <h4 className="font-bold text-sm text-stone-900">Doctor Notes</h4>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    {/* Dictate Notes Button */}
                    <button
                      onClick={() => alert(`Dictating notes for ${selectedPatient.name}...`)}
                      className="px-3.5 py-1.5 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-xl shadow-2xs transition-colors flex items-center gap-1.5 cursor-pointer border border-blue-500"
                    >
                      <Mic className="w-3.5 h-3.5 text-indigo-300" />
                      <span>Dictate Notes</span>
                      <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                    </button>

                    <button
                      onClick={() => setIsNoteWorkspaceOpen(!isNoteWorkspaceOpen)}
                      className="px-3 py-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 text-xs font-bold rounded-xl transition-colors cursor-pointer flex items-center gap-1"
                    >
                      <span>{isNoteWorkspaceOpen ? 'Close workspace' : 'Open draft workspace'}</span>
                    </button>
                  </div>
                </div>

                {/* Table of the 3 Attached HTML Forms in Positions 1, 2, and 3 */}
                <div className="overflow-x-auto border border-stone-200/90 rounded-2xl shadow-2xs bg-white">
                  <table className="w-full text-left border-collapse">
                    <thead>
                      <tr className="bg-stone-100/90 border-b border-stone-200 text-[11px] font-bold text-stone-600 uppercase tracking-wider">
                        <th className="py-3.5 px-4">Position & Form Title</th>
                        <th className="py-3.5 px-4">Author / Provider</th>
                        <th className="py-3.5 px-4">Status</th>
                        <th className="py-3.5 px-4 text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-stone-100 text-xs font-medium text-stone-800">
                      {notesFormsList.map((note) => (
                        <tr key={note.id} className="hover:bg-purple-50/40 transition-colors group">
                          <td className="py-3.5 px-4 min-w-[240px]">
                            <div className="flex items-start gap-3">
                              <span className="w-6 h-6 rounded-lg bg-indigo-600 text-white font-bold text-xs flex items-center justify-center shrink-0 mt-0.5 shadow-2xs">
                                {note.order}
                              </span>
                              <div>
                                <div className="font-bold text-stone-900 text-xs flex items-center gap-2">
                                  <span 
                                    onClick={() => setViewingNoteForm(note)}
                                    className="hover:text-indigo-600 cursor-pointer transition-colors"
                                  >
                                    {note.title}
                                  </span>
                                  <span className="px-1.5 py-0.5 rounded bg-purple-100 text-purple-800 text-[9px] font-bold border border-purple-200">
                                    HTML Form
                                  </span>
                                </div>
                                <div className="text-[11px] text-stone-500 font-normal mt-0.5 max-w-md">
                                  {note.subtitle}
                                </div>
                              </div>
                            </div>
                          </td>

                          <td className="py-3.5 px-4 whitespace-nowrap text-stone-700">
                            <div className="font-bold text-stone-900">{note.author}</div>
                            <div className="text-[10.5px] text-stone-400 font-mono">{note.date}</div>
                          </td>

                          <td className="py-3.5 px-4 whitespace-nowrap">
                            <span className="px-2.5 py-1 rounded-full text-[10.5px] font-bold bg-emerald-50 text-emerald-800 border border-emerald-200 flex items-center gap-1.5 w-fit">
                              <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                              <span>{note.status}</span>
                            </span>
                          </td>

                          <td className="py-3.5 px-4 text-right whitespace-nowrap">
                            <div className="flex items-center justify-end gap-2">
                              {/* Open Button */}
                              <button
                                onClick={() => setViewingNoteForm(note)}
                                className="px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-xl shadow-2xs transition-colors cursor-pointer flex items-center gap-1.5"
                              >
                                <ExternalLink className="w-3.5 h-3.5 text-indigo-200" />
                                <span>Open</span>
                              </button>
                              {/* Delete Button */}
                              <button
                                onClick={() => handleDeleteDoctorNote(note.id)}
                                title="Delete Doctor Note"
                                className="px-2.5 py-1.5 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 font-bold text-xs rounded-xl shadow-2xs transition-colors cursor-pointer flex items-center gap-1"
                              >
                                <Trash2 className="w-3.5 h-3.5 text-rose-600" />
                                <span>Delete</span>
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                {/* Interactive Draft Note Workspace */}
                {isNoteWorkspaceOpen && (
                  <div className="p-5 bg-stone-50/80 border border-stone-200 rounded-2xl space-y-4 animate-in fade-in duration-200 mt-3">
                    <div className="text-[10px] font-bold text-stone-400 uppercase tracking-wider">
                      STRUCTURED DATA PULLED FROM CHART · {selectedPatient.name.toUpperCase()}
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                      <div className="p-3 bg-white/80 border border-stone-200/80 rounded-xl">
                        <span className="text-[9.5px] font-bold text-stone-400 block uppercase tracking-wider">PATIENT</span>
                        <span className="font-bold text-stone-900">{selectedPatient.name} · MRN-{selectedPatient.patientId || '88213'}</span>
                      </div>
                      <div className="p-3 bg-white/80 border border-stone-200/80 rounded-xl">
                        <span className="text-[9.5px] font-bold text-stone-400 block uppercase tracking-wider">PROCEDURE</span>
                        <span className="font-bold text-stone-900">{selectedPatient.procedure || 'Laparoscopic Cholecystectomy'}</span>
                      </div>
                      <div className="p-3 bg-white/80 border border-stone-200/80 rounded-xl">
                        <span className="text-[9.5px] font-bold text-stone-400 block uppercase tracking-wider">ASA CLASS</span>
                        <span className="font-bold text-stone-900">II</span>
                      </div>
                      <div className="p-3 bg-white/80 border border-stone-200/80 rounded-xl">
                        <span className="text-[9.5px] font-bold text-stone-400 block uppercase tracking-wider">ALLERGIES</span>
                        <span className="font-bold text-stone-900">{selectedPatient.allergies && selectedPatient.allergies.length > 0 ? selectedPatient.allergies.join(', ') : 'NKDA'}</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => {
                          setDraftNoteContent(`ADMISSION H&P NOTE - ${selectedPatient.name.toUpperCase()}\nProcedure: ${selectedPatient.procedure}\nASA Class: II | Allergies: ${selectedPatient.allergies && selectedPatient.allergies.length > 0 ? selectedPatient.allergies.join(', ') : 'NKDA'}\n\nClinical Summary:\nPatient presents cleared for surgery. Pre-op vitals stable.`);
                        }}
                        className="px-4 py-2 bg-teal-800 hover:bg-teal-900 text-white font-bold text-xs rounded-xl shadow-xs transition-colors cursor-pointer flex items-center gap-2"
                      >
                        <Sparkles className="w-3.5 h-3.5 text-emerald-300" />
                        <span>Generate draft note</span>
                      </button>

                      {draftNoteContent && (
                        <button
                          onClick={handleClearDraftNote}
                          className="px-3.5 py-2 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 font-bold text-xs rounded-xl transition-colors cursor-pointer flex items-center gap-1.5 shadow-2xs"
                        >
                          <Trash2 className="w-3.5 h-3.5 text-rose-600" />
                          <span>Delete Draft Note</span>
                        </button>
                      )}
                    </div>

                    <textarea
                      value={draftNoteContent}
                      onChange={(e) => setDraftNoteContent(e.target.value)}
                      placeholder="Click &quot;Generate draft note&quot; to have the assistant draft this note from the structured chart data."
                      className="w-full h-32 p-3.5 bg-white border border-stone-300 rounded-xl text-xs text-stone-800 focus:outline-none font-sans"
                    />
                  </div>
                )}
              </div>
            )}
          </div>
          )}

          {/* Section 5: Nursing Notes */}
          {(expandedSections.nursingNotes || expandedSections.all) && (
          <div id="nursingNotes-section" className="bg-white rounded-2xl border border-stone-200/90 shadow-2xs overflow-hidden transition-all">
            <button
              onClick={() => toggleSection('nursingNotes')}
              className="w-full p-4 flex items-center justify-between gap-4 text-left hover:bg-stone-50/80 transition-colors cursor-pointer"
            >
              <div className="flex items-center gap-3 min-w-0">
                <div className="w-8 h-8 rounded-xl bg-emerald-600 text-white flex items-center justify-center shadow-xs shrink-0">
                  <FileCheck className="w-4 h-4 text-white" />
                </div>
                <div className="min-w-0">
                  <div className="flex items-center gap-2">
                    <h3 className="text-sm font-bold text-stone-900 truncate">Nursing Notes</h3>
                    <span className="px-2.5 py-0.5 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-200 text-[10px] font-bold">
                      {nursingFormsList.length} Attached HTML Forms
                    </span>
                  </div>
                  <div className="flex items-center gap-1.5 text-xs text-stone-600 font-medium mt-0.5 truncate">
                    <Sparkles className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                    <span><strong>AI Verified Perioperative Forms:</strong> All 7 nursing HTML forms organized & saved per surgical episode.</span>
                  </div>
                </div>
              </div>

              <div className="p-1.5 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-700 transition-colors shrink-0">
                <ChevronDown className={`w-5 h-5 text-stone-600 transition-transform duration-200 ${expandedSections.nursingNotes ? 'rotate-180' : ''}`} />
              </div>
            </button>

            {expandedSections.nursingNotes && (
              <div className="p-5 border-t border-stone-200/80 bg-white space-y-4 animate-in fade-in duration-200">
                
                {/* Save Confirmation Toast Banner */}
                {saveEpisodeSuccessToast && (
                  <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-xs text-emerald-900 font-medium flex items-center justify-between gap-2 animate-in fade-in slide-in-from-top-1">
                    <div className="flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                      <span>{saveEpisodeSuccessToast}</span>
                    </div>
                    <button 
                      onClick={() => setSaveEpisodeSuccessToast(null)}
                      className="text-emerald-700 hover:text-emerald-950 font-bold text-xs"
                    >
                      Dismiss
                    </button>
                  </div>
                )}

                {/* Surgical Episode Selector & Actions Bar */}
                <div className="p-3.5 bg-stone-50 border border-stone-200/90 rounded-2xl flex flex-wrap items-center justify-between gap-3">
                  <div className="flex items-center gap-2.5 min-w-[280px] flex-1">
                    <FolderCheck className="w-4 h-4 text-emerald-700 shrink-0" />
                    <div className="space-y-0.5 flex-1">
                      <label className="text-[10px] font-bold text-stone-500 uppercase tracking-wider block">
                        Select Surgical Episode
                      </label>
                      <select
                        value={selectedSurgicalEpisode}
                        onChange={(e) => setSelectedSurgicalEpisode(e.target.value)}
                        className="w-full bg-white border border-stone-300 rounded-lg px-2.5 py-1.5 text-xs font-bold text-stone-900 focus:outline-none focus:ring-2 focus:ring-emerald-500 cursor-pointer"
                      >
                        {SURGICAL_EPISODES.map((ep) => (
                          <option key={ep.id} value={ep.id}>
                            {ep.name}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        const activeEpName = SURGICAL_EPISODES.find(ep => ep.id === selectedSurgicalEpisode)?.name || 'Current Episode';
                        setSaveEpisodeSuccessToast(`Saved collection of ${nursingFormsList.length} Nursing Notes forms to ${activeEpName}`);
                        setTimeout(() => setSaveEpisodeSuccessToast(null), 5000);
                      }}
                      className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs rounded-xl shadow-2xs transition-colors cursor-pointer flex items-center gap-1.5"
                    >
                      <Save className="w-3.5 h-3.5 text-emerald-200" />
                      <span>Save Collection to Episode</span>
                    </button>
                  </div>
                </div>

                {/* Table of Attached Nursing HTML Forms */}
                <div className="border border-stone-200/90 rounded-2xl shadow-2xs bg-white overflow-hidden">
                  <table className="w-full text-left border-collapse text-xs">
                    <thead>
                      <tr className="bg-stone-100/90 border-b border-stone-200 text-[10.5px] font-bold text-stone-600 uppercase tracking-wider">
                        <th className="py-2.5 px-3">Position & Form Title</th>
                        <th className="py-2.5 px-3">Form Status</th>
                        <th className="py-2.5 px-3 text-right">Action</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-stone-100 font-medium text-stone-800">
                      {nursingFormsList.map((form) => (
                        <tr key={form.id} className="hover:bg-emerald-50/40 transition-colors group">
                          {/* Position & Title */}
                          <td className="py-2.5 px-3">
                            <div className="flex items-start gap-2.5">
                              <span className="w-5 h-5 rounded-md bg-emerald-700 text-white font-bold text-[11px] flex items-center justify-center shrink-0 mt-0.5 shadow-2xs">
                                {form.order}
                              </span>
                              <div className="min-w-0">
                                <div className="font-bold text-stone-900 text-xs flex items-center gap-1.5 flex-wrap">
                                  <span 
                                    onClick={() => setEditingNursingForm(form)}
                                    className="hover:text-emerald-700 cursor-pointer transition-colors"
                                  >
                                    {form.title}
                                  </span>
                                  <span className="px-1.5 py-0.2 rounded bg-emerald-100 text-emerald-800 text-[9px] font-bold border border-emerald-200">
                                    HTML Form
                                  </span>
                                </div>
                                <div className="text-[10.5px] text-stone-500 font-normal mt-0.5 line-clamp-1">
                                  {form.summary}
                                </div>
                              </div>
                            </div>
                          </td>

                          {/* Form Status */}
                          <td className="py-2.5 px-3 whitespace-nowrap">
                            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-900 border border-emerald-300 flex items-center gap-1 w-fit">
                              <CheckCircle2 className="w-3 h-3 text-emerald-700" />
                              <span>{form.status}</span>
                            </span>
                          </td>

                          {/* Actions */}
                          <td className="py-2.5 px-3 text-right whitespace-nowrap">
                            <div className="flex items-center justify-end gap-1.5">
                              <button
                                type="button"
                                onClick={() => setEditingNursingForm(form)}
                                className="px-3 py-1 bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs rounded-lg shadow-2xs transition-colors cursor-pointer inline-flex items-center gap-1"
                                id="open-nursing-form-btn"
                              >
                                <FileText className="w-3.5 h-3.5 text-emerald-200" />
                                <span>Open</span>
                              </button>
                              <button
                                type="button"
                                onClick={() => handleDeleteNursingNote(form.id)}
                                title="Delete Nursing Note"
                                className="px-2 py-1 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 font-bold text-xs rounded-lg shadow-2xs transition-colors cursor-pointer inline-flex items-center gap-1"
                              >
                                <Trash2 className="w-3.5 h-3.5 text-rose-600" />
                                <span>Delete</span>
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                {/* AI Callout Box */}
                <div className="p-3.5 bg-purple-50/70 border border-purple-200/80 rounded-xl text-xs text-purple-950 flex items-start gap-2.5">
                  <Sparkles className="w-4 h-4 text-purple-600 shrink-0 mt-0.5" />
                  <p className="leading-relaxed">
                    <strong className="font-bold text-purple-900">AI Perioperative Assistant:</strong> All 7 nursing HTML forms are linked and tracked for Episode #2026-0506. AI checks pre-op NPO status, AORN 4-stage safety timeout indicators, PACU Aldrete recovery scores, and discharge criteria before archiving into the surgical episode record.
                  </p>
                </div>

              </div>
            )}
          </div>
          )}

          {/* Section 6: Reconciled Medications */}
          {(expandedSections.medications || expandedSections.all) && (
            <div id="medications-section" className="bg-white rounded-2xl border border-stone-200/90 shadow-2xs p-5 space-y-4 animate-in fade-in duration-200">
              <div className="flex flex-wrap items-center justify-between border-b border-stone-200/80 pb-3 gap-2">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-xl bg-rose-600 text-white flex items-center justify-center shadow-xs shrink-0">
                    <Stethoscope className="w-4.5 h-4.5 text-white" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-stone-900">Reconciled Medications & E-Prescribe Portal</h3>
                    <p className="text-xs text-stone-500 font-medium">Active pre-op and post-op medication orders for {selectedPatient.name}</p>
                  </div>
                </div>
                <button
                  onClick={() => setIsEPrescribeOpen(true)}
                  className="px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-xl shadow-2xs transition-colors flex items-center gap-1.5 cursor-pointer shrink-0"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Open E-Prescribe Portal</span>
                </button>
              </div>

              <div className="p-3 bg-red-50 border border-red-200 rounded-xl text-xs text-red-900 flex items-center gap-2 font-medium">
                <AlertCircle className="w-4 h-4 text-red-600 shrink-0" />
                <span><strong className="font-bold">Documented Allergy Alert:</strong> Penicillin (causes hives/urticaria). Beta-lactams flagged.</span>
              </div>

              <div className="overflow-x-auto border border-stone-200/90 rounded-xl shadow-2xs">
                <table className="w-full text-left text-xs">
                  <thead className="bg-stone-100/90 text-stone-700 uppercase font-bold text-[10px] tracking-wider">
                    <tr>
                      <th className="p-3">Medication</th>
                      <th className="p-3">Dosage / Sig</th>
                      <th className="p-3">Category</th>
                      <th className="p-3 text-right">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-stone-100 font-medium text-stone-800">
                    <tr>
                      <td className="p-3 font-bold text-stone-900">Celebrex (Celecoxib)</td>
                      <td className="p-3">200mg PO QD</td>
                      <td className="p-3 text-stone-600">Pre-op Anti-inflammatory</td>
                      <td className="p-3 text-right"><span className="px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-bold border border-emerald-300">Administered</span></td>
                    </tr>
                    <tr>
                      <td className="p-3 font-bold text-stone-900">Emend (Aprepitant)</td>
                      <td className="p-3">40mg PO 1hr Pre-op</td>
                      <td className="p-3 text-stone-600">PONV Prophylaxis</td>
                      <td className="p-3 text-right"><span className="px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-bold border border-emerald-300">Administered</span></td>
                    </tr>
                    <tr>
                      <td className="p-3 font-bold text-stone-900">Ancef (Cefazolin)</td>
                      <td className="p-3">1g IV Piggyback</td>
                      <td className="p-3 text-stone-600">Surgical Prophylaxis</td>
                      <td className="p-3 text-right"><span className="px-2.5 py-0.5 rounded-full bg-blue-100 text-blue-800 text-[10px] font-bold border border-blue-300">Ordered (Pre-Incision)</span></td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* Section 7: Payment & Financial Summary */}
          {(expandedSections.financial || expandedSections.all) && (
            <div id="financial-section" className="bg-white rounded-2xl border border-stone-200/90 shadow-2xs p-5 space-y-4 animate-in fade-in duration-200">
              <div className="flex flex-wrap items-center justify-between border-b border-stone-200/80 pb-3 gap-2">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-xl bg-emerald-600 text-white flex items-center justify-center shadow-xs shrink-0">
                    <DollarSign className="w-4.5 h-4.5 text-white" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-stone-900">Payment & Financial Summary Note</h3>
                    <p className="text-xs text-stone-500 font-medium">Self-pay / Insurance billing details and invoice manager</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setIsCreateInvoiceModalOpen(true)}
                    className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-2xs transition-colors cursor-pointer"
                  >
                    Create Invoice
                  </button>
                  <button
                    onClick={() => setIsBlankInvoiceModalOpen(true)}
                    className="px-3 py-1.5 bg-stone-100 hover:bg-stone-200 text-stone-800 font-bold text-xs rounded-xl border border-stone-300 transition-colors cursor-pointer"
                  >
                    Blank Invoice Form
                  </button>
                </div>
              </div>

              <div className="p-4 bg-stone-50/80 rounded-xl border border-stone-200/80 space-y-2 text-xs">
                <div className="flex justify-between items-center">
                  <span className="font-bold text-stone-700">Payment Source:</span>
                  <span className="font-extrabold text-stone-900 capitalize">{currentPayment.source}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="font-bold text-stone-700">Status:</span>
                  <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold ${currentPayment.received ? 'bg-emerald-100 text-emerald-800 border border-emerald-300' : 'bg-amber-100 text-amber-800 border border-amber-300'}`}>
                    {currentPayment.received ? '✓ Payment Received' : 'Pending Payment'}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="font-bold text-stone-700">Estimated Total Amount:</span>
                  <span className="font-extrabold text-stone-900 text-sm">${currentPayment.amount.toLocaleString()}</span>
                </div>
                <p className="text-[11px] text-stone-500 font-medium pt-1 border-t border-stone-200">{currentPayment.notes}</p>
              </div>
            </div>
          )}

          {/* Section 8: Patient ID & Insurance Cards */}
          {(expandedSections.idInsuranceCards || expandedSections.idInsurance || expandedSections.all) && (
            <div id="idInsurance-section" className="bg-white rounded-2xl border border-stone-200/90 shadow-2xs p-5 space-y-4 animate-in fade-in duration-200">
              <div className="flex items-center justify-between border-b border-stone-200/80 pb-3">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-xl bg-sky-600 text-white flex items-center justify-center shadow-xs shrink-0">
                    <CreditCard className="w-4.5 h-4.5 text-white" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-stone-900">Driver's License Photo ID & Primary Insurance Cards</h3>
                    <p className="text-xs text-stone-500 font-medium">Verified identity and insurance document scans</p>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div 
                  onClick={() => setZoomedImage({ url: idCardUrl, title: `${selectedPatient.name} — California Driver License`, subtitle: 'Government Issued Photo ID' })}
                  className="p-3 bg-stone-50 rounded-xl border border-stone-200 cursor-pointer hover:border-indigo-400 transition-all group"
                >
                  <div className="text-xs font-bold text-stone-800 mb-2 flex items-center justify-between">
                    <span>Driver's License</span>
                    <Eye className="w-3.5 h-3.5 text-stone-400 group-hover:text-indigo-600" />
                  </div>
                  <div className="aspect-video bg-stone-200 rounded-lg overflow-hidden flex items-center justify-center">
                    <img src={idCardUrl} alt="Driver License" className="w-full h-full object-cover group-hover:scale-105 transition-transform" />
                  </div>
                </div>

                <div 
                  onClick={() => setZoomedImage({ url: insuranceCardFrontUrl, title: `${selectedPatient.name} — Primary Insurance (Front)`, subtitle: 'Blue Shield PPO Member ID' })}
                  className="p-3 bg-stone-50 rounded-xl border border-stone-200 cursor-pointer hover:border-indigo-400 transition-all group"
                >
                  <div className="text-xs font-bold text-stone-800 mb-2 flex items-center justify-between">
                    <span>Insurance Card (Front)</span>
                    <Eye className="w-3.5 h-3.5 text-stone-400 group-hover:text-indigo-600" />
                  </div>
                  <div className="aspect-video bg-stone-200 rounded-lg overflow-hidden flex items-center justify-center">
                    <img src={insuranceCardFrontUrl} alt="Insurance Front" className="w-full h-full object-cover group-hover:scale-105 transition-transform" />
                  </div>
                </div>

                <div 
                  onClick={() => setZoomedImage({ url: insuranceCardBackUrl, title: `${selectedPatient.name} — Primary Insurance (Back)`, subtitle: 'Claims & Rx Bin Information' })}
                  className="p-3 bg-stone-50 rounded-xl border border-stone-200 cursor-pointer hover:border-indigo-400 transition-all group"
                >
                  <div className="text-xs font-bold text-stone-800 mb-2 flex items-center justify-between">
                    <span>Insurance Card (Back)</span>
                    <Eye className="w-3.5 h-3.5 text-stone-400 group-hover:text-indigo-600" />
                  </div>
                  <div className="aspect-video bg-stone-200 rounded-lg overflow-hidden flex items-center justify-center">
                    <img src={insuranceCardBackUrl} alt="Insurance Back" className="w-full h-full object-cover group-hover:scale-105 transition-transform" />
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Section 9: Surgical Team & Room Details */}
          {(expandedSections.surgicalDetails || expandedSections.all) && (
            <div id="surgicalDetails-section" className="bg-white rounded-2xl border border-stone-200/90 shadow-2xs p-5 space-y-4 animate-in fade-in duration-200">
              <div className="flex items-center justify-between border-b border-stone-200/80 pb-3">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-xl bg-amber-600 text-white flex items-center justify-center shadow-xs shrink-0">
                    <Building2 className="w-4.5 h-4.5 text-white" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-stone-900">Surgical Team & Operating Room Assignment</h3>
                    <p className="text-xs text-stone-500 font-medium">Summit Surgical Center staff & room details for DOS May 06, 2026</p>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                <div className="p-3 bg-stone-50 rounded-xl border border-stone-200">
                  <span className="text-[10px] font-bold text-stone-400 block uppercase">Surgeon</span>
                  <span className="font-extrabold text-stone-900">{selectedPatient.surgeon || 'Dr. Richard Zoumalan'}</span>
                </div>
                <div className="p-3 bg-stone-50 rounded-xl border border-stone-200">
                  <span className="text-[10px] font-bold text-stone-400 block uppercase">Anesthesiologist</span>
                  <span className="font-extrabold text-stone-900">Dr. Taheri, M.D.</span>
                </div>
                <div className="p-3 bg-stone-50 rounded-xl border border-stone-200">
                  <span className="text-[10px] font-bold text-stone-400 block uppercase">Operating Room</span>
                  <span className="font-extrabold text-amber-700">{selectedPatient.room || 'OR 2'}</span>
                </div>
                <div className="p-3 bg-stone-50 rounded-xl border border-stone-200">
                  <span className="text-[10px] font-bold text-stone-400 block uppercase">Circulating Nurse</span>
                  <span className="font-extrabold text-stone-900">Nurse Tara, RN</span>
                </div>
              </div>
            </div>
          )}

          {/* Section 10: Quick Chart Actions */}
          {(expandedSections.quickActions || expandedSections.all) && (
            <div id="quickActions-section" className="bg-white rounded-2xl border border-stone-200/90 shadow-2xs p-5 space-y-4 animate-in fade-in duration-200">
              <div className="flex items-center justify-between border-b border-stone-200/80 pb-3">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-xl bg-violet-600 text-white flex items-center justify-center shadow-xs shrink-0">
                    <Zap className="w-4.5 h-4.5 text-white" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-stone-900">Quick Chart Actions</h3>
                    <p className="text-xs text-stone-500 font-medium">1-click actions and communications for {selectedPatient.name}</p>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <button
                  onClick={() => setIsEPrescribeOpen(true)}
                  className="p-3.5 bg-blue-50 hover:bg-blue-100/80 border border-blue-200 rounded-xl text-left cursor-pointer transition-all space-y-1 shadow-2xs"
                >
                  <div className="font-bold text-xs text-blue-900 flex items-center gap-1.5">
                    <Send className="w-3.5 h-3.5 text-blue-600" /> E-Prescribe Medication
                  </div>
                  <div className="text-[10px] text-blue-700 font-medium">Send electronic rx via Surescripts</div>
                </button>

                <button
                  onClick={() => setIsNoteWorkspaceOpen(true)}
                  className="p-3.5 bg-purple-50 hover:bg-purple-100/80 border border-purple-200 rounded-xl text-left cursor-pointer transition-all space-y-1 shadow-2xs"
                >
                  <div className="font-bold text-xs text-purple-900 flex items-center gap-1.5">
                    <Mic className="w-3.5 h-3.5 text-purple-600" /> Dictate Doctor Note
                  </div>
                  <div className="text-[10px] text-purple-700 font-medium">Open ambient voice dictation</div>
                </button>

                <button
                  onClick={() => window.print()}
                  className="p-3.5 bg-stone-50 hover:bg-stone-100 border border-stone-200 rounded-xl text-left cursor-pointer transition-all space-y-1 shadow-2xs"
                >
                  <div className="font-bold text-xs text-stone-900 flex items-center gap-1.5">
                    <Printer className="w-3.5 h-3.5 text-stone-600" /> Print Chart Summary
                  </div>
                  <div className="text-[10px] text-stone-500 font-medium">Generate printable chart brief</div>
                </button>
              </div>
            </div>
          )}

        </div>

        {/* Right Column: 1/3 of page (4 cols) */}
        <div className="lg:col-span-4 space-y-6">
          
          {/* Appointment History Section */}
          <div className="bg-white rounded-2xl border border-stone-200/90 shadow-2xs overflow-hidden transition-all">
            <button
              onClick={() => toggleSection('appointments')}
              className="w-full p-4 flex items-center justify-between gap-3 text-left hover:bg-stone-50/80 transition-colors cursor-pointer"
            >
              <div className="flex items-center gap-2.5 min-w-0">
                <div className="w-8 h-8 rounded-xl bg-blue-600 text-white flex items-center justify-center shadow-xs shrink-0">
                  <Calendar className="w-4 h-4 text-white" />
                </div>
                <div className="min-w-0">
                  <h3 className="text-sm font-bold text-stone-900 flex items-center gap-2 truncate">
                    <span>Appointment History</span>
                    <span className="px-2 py-0.5 rounded-full bg-slate-100 text-slate-800 text-[10px] font-bold border border-slate-200">
                      5 Visits
                    </span>
                  </h3>
                  <p className="text-[11px] text-stone-500 font-medium truncate">
                    Clinical encounter logs for {selectedPatient.name}
                  </p>
                </div>
              </div>

              <div className="p-1.5 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-700 transition-colors shrink-0">
                <ChevronDown className={`w-5 h-5 text-stone-600 transition-transform duration-200 ${expandedSections.appointments ? 'rotate-180' : ''}`} />
              </div>
            </button>

            {expandedSections.appointments && (
              <div className="p-5 border-t border-stone-200/80 bg-white space-y-4 animate-in fade-in duration-200">
                <div className="space-y-3">
                  {/* Visit 1: Active DOS / Current Appointment */}
                  <div className="p-3 bg-blue-50/70 rounded-xl border border-blue-200 space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                        <Clock className="w-3.5 h-3.5 text-blue-600" />
                        <span>May 06, 2026 · 07:30 AM</span>
                      </span>
                      <span className="px-2 py-0.5 rounded-full text-[9.5px] font-bold bg-blue-600 text-white shadow-2xs">
                        Current DOS
                      </span>
                    </div>
                    <div className="text-xs font-bold text-blue-950 leading-snug">
                      Face & Necklift, Septo-Rhinoplasty, Turbinates Reduction
                    </div>
                    <div className="text-[11px] text-stone-600 font-medium pt-1.5 border-t border-blue-100 flex flex-wrap justify-between gap-1">
                      <span>Summit Surgical Center (OR-2)</span>
                      <span className="font-bold text-stone-800">Dr. Zoumalan / Dr. Taheri</span>
                    </div>

                    {/* Attached Electronic Forms Module Badge Button */}
                    <div className="pt-2 border-t border-blue-200/80 flex items-center justify-between">
                      <span className="text-[10px] font-bold text-indigo-900 flex items-center gap-1">
                        <FileCheck className="w-3.5 h-3.5 text-indigo-600" />
                        <span>9 Forms Attached</span>
                      </span>
                      <button
                        onClick={() => openFormsForAppointment('May 06, 2026', 'asc-1-hp')}
                        className="px-2.5 py-1 bg-indigo-600 hover:bg-indigo-700 text-white text-[10px] font-bold rounded-lg transition-colors cursor-pointer flex items-center gap-1 shadow-2xs"
                      >
                        <span>Forms</span>
                        <ChevronRight className="w-3 h-3" />
                      </button>
                    </div>
                  </div>

                  {/* Toggle Button for Earlier Encounters */}
                  <button
                    onClick={() => setShowEarlierVisits((prev) => !prev)}
                    className="w-full py-2 px-3 bg-stone-50 hover:bg-stone-100 text-stone-700 text-xs font-bold rounded-xl border border-stone-200/90 transition-colors cursor-pointer flex items-center justify-between shadow-2xs"
                  >
                    <span className="flex items-center gap-1.5">
                      <Clock className="w-3.5 h-3.5 text-stone-500" />
                      <span>{showEarlierVisits ? 'Hide Earlier Visits' : 'Show 4 Earlier Encounters (May 2026 – Nov 2025)'}</span>
                    </span>
                    <ChevronDown className={`w-4 h-4 text-stone-500 transition-transform duration-200 ${showEarlierVisits ? 'rotate-180' : ''}`} />
                  </button>

                  {/* Earlier Visits List */}
                  {showEarlierVisits && (
                    <div className="space-y-3 pt-1 animate-in fade-in duration-200">
                      {/* Visit 2: Pre-Op Clearance */}
                      <div className="p-3 bg-stone-50 rounded-xl border border-stone-200/80 space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-bold text-stone-900">May 01, 2026 · 10:15 AM</span>
                          <span className="px-2 py-0.5 rounded text-[9.5px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
                            Completed
                          </span>
                        </div>
                        <div className="text-xs font-semibold text-stone-800">
                          Pre-Operative Clearance & Anesthesia Consent
                        </div>
                        <div className="text-[11px] text-stone-500 font-medium flex items-center justify-between pt-1 border-t border-stone-200/60">
                          <span>Summit Suite 400B</span>
                          <span className="font-medium text-stone-700">Dr. Taheri & Nurse Tara</span>
                        </div>

                        <div className="pt-2 border-t border-stone-200/80 flex items-center justify-between">
                          <span className="text-[10px] font-bold text-stone-600 flex items-center gap-1">
                            <FileText className="w-3.5 h-3.5 text-indigo-600" />
                            <span>9 Forms Attached</span>
                          </span>
                          <button
                            onClick={() => openFormsForAppointment('May 01, 2026', 'anesthesia-questionnaire')}
                            className="px-2 py-0.5 bg-stone-200 hover:bg-stone-300 text-stone-800 text-[10px] font-bold rounded-lg transition-colors cursor-pointer flex items-center gap-1"
                          >
                            <span>Forms</span>
                            <ChevronRight className="w-3 h-3" />
                          </button>
                        </div>
                      </div>

                      {/* Visit 3: 3D Simulation */}
                      <div className="p-3 bg-stone-50 rounded-xl border border-stone-200/80 space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-bold text-stone-900">Apr 14, 2026 · 02:00 PM</span>
                          <span className="px-2 py-0.5 rounded text-[9.5px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
                            Completed
                          </span>
                        </div>
                        <div className="text-xs font-semibold text-stone-800">
                          Facial Aesthetics Consultation & 3D Vectra Simulation
                        </div>
                        <div className="text-[11px] text-stone-500 font-medium flex items-center justify-between pt-1 border-t border-stone-200/60">
                          <span>Beverly Hills Surgery</span>
                          <span className="font-medium text-stone-700">Dr. Richard Zoumalan</span>
                        </div>

                        <div className="pt-2 border-t border-stone-200/80 flex items-center justify-between">
                          <span className="text-[10px] font-bold text-stone-600 flex items-center gap-1">
                            <FileText className="w-3.5 h-3.5 text-indigo-600" />
                            <span>9 Forms Attached</span>
                          </span>
                          <button
                            onClick={() => openFormsForAppointment('Apr 14, 2026', 'asc-1-hp')}
                            className="px-2 py-0.5 bg-stone-200 hover:bg-stone-300 text-stone-800 text-[10px] font-bold rounded-lg transition-colors cursor-pointer flex items-center gap-1"
                          >
                            <span>Forms</span>
                            <ChevronRight className="w-3 h-3" />
                          </button>
                        </div>
                      </div>

                      {/* Visit 4: Nasal Endoscopy */}
                      <div className="p-3 bg-stone-50 rounded-xl border border-stone-200/80 space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-bold text-stone-900">Mar 02, 2026 · 09:30 AM</span>
                          <span className="px-2 py-0.5 rounded text-[9.5px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
                            Completed
                          </span>
                        </div>
                        <div className="text-xs font-semibold text-stone-800">
                          ENT Airway Evaluation & Diagnostic Nasal Endoscopy
                        </div>
                        <div className="text-[11px] text-stone-500 font-medium flex items-center justify-between pt-1 border-t border-stone-200/60">
                          <span>Summit Clinic</span>
                          <span className="font-medium text-stone-700">Dr. Richard Zoumalan</span>
                        </div>

                        <div className="pt-2 border-t border-stone-200/80 flex items-center justify-between">
                          <span className="text-[10px] font-bold text-stone-600 flex items-center gap-1">
                            <FileText className="w-3.5 h-3.5 text-indigo-600" />
                            <span>9 Forms Attached</span>
                          </span>
                          <button
                            onClick={() => openFormsForAppointment('Mar 02, 2026', 'asc-1-hp')}
                            className="px-2 py-0.5 bg-stone-200 hover:bg-stone-300 text-stone-800 text-[10px] font-bold rounded-lg transition-colors cursor-pointer flex items-center gap-1"
                          >
                            <span>Forms</span>
                            <ChevronRight className="w-3 h-3" />
                          </button>
                        </div>
                      </div>

                      {/* Visit 5: Allergy & Medical History */}
                      <div className="p-3 bg-stone-50 rounded-xl border border-stone-200/80 space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-bold text-stone-900">Nov 18, 2025 · 11:00 AM</span>
                          <span className="px-2 py-0.5 rounded text-[9.5px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
                            Completed
                          </span>
                        </div>
                        <div className="text-xs font-semibold text-stone-800">
                          Annual Allergy Panel & Medical Pre-Evaluation
                        </div>
                        <div className="text-[11px] text-stone-500 font-medium flex items-center justify-between pt-1 border-t border-stone-200/60">
                          <span>Beverly Hills Pavilion</span>
                          <span className="font-medium text-stone-700">Dr. S. Patel, M.D.</span>
                        </div>

                        <div className="pt-2 border-t border-stone-200/80 flex items-center justify-between">
                          <span className="text-[10px] font-bold text-stone-600 flex items-center gap-1">
                            <FileText className="w-3.5 h-3.5 text-indigo-600" />
                            <span>9 Forms Attached</span>
                          </span>
                          <button
                            onClick={() => openFormsForAppointment('Nov 18, 2025', 'asc-1-hp')}
                            className="px-2 py-0.5 bg-stone-200 hover:bg-stone-300 text-stone-800 text-[10px] font-bold rounded-lg transition-colors cursor-pointer flex items-center gap-1"
                          >
                            <span>Forms</span>
                            <ChevronRight className="w-3 h-3" />
                          </button>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
          </div>
        )}
      </div>



        </div>

      </div>

      {/* Lightbox Zoom Modal for Patient Cards */}
      {zoomedImage && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-200">
          <div className="bg-white rounded-3xl max-w-2xl w-full p-6 space-y-4 shadow-2xl border border-stone-200 relative">
            <div className="flex items-center justify-between border-b border-stone-200 pb-3">
              <div>
                <h3 className="text-base font-bold text-stone-900 flex items-center gap-2">
                  <CreditCard className="w-5 h-5 text-blue-600" />
                  <span>{zoomedImage.title}</span>
                </h3>
                {zoomedImage.subtitle && (
                  <p className="text-xs text-stone-500 font-medium mt-0.5">{zoomedImage.subtitle}</p>
                )}
              </div>
              <button 
                onClick={() => setZoomedImage(null)}
                className="p-2 rounded-full hover:bg-stone-100 text-stone-500 hover:text-stone-800 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="bg-stone-100 rounded-2xl p-4 flex items-center justify-center border border-stone-200 overflow-hidden min-h-[280px]">
              <img 
                src={zoomedImage.url} 
                alt="Enlarged Document" 
                className="max-h-[70vh] w-auto max-w-full rounded-xl object-contain shadow-lg"
              />
            </div>

            <div className="flex items-center justify-between pt-2">
              <span className="text-xs text-stone-500 font-medium flex items-center gap-1">
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                <span>Verified High-Resolution Scan · HIPAA Encrypted</span>
              </span>

              <div className="flex items-center gap-2">
                <button 
                  onClick={() => {
                    const a = document.createElement('a');
                    a.href = zoomedImage.url;
                    a.download = `${selectedPatient.name.replace(/\s+/g, '_')}_card.png`;
                    a.click();
                  }}
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-xl flex items-center gap-2 transition-colors cursor-pointer shadow-2xs"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download Scan</span>
                </button>
                <button 
                  onClick={() => setZoomedImage(null)}
                  className="px-4 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 text-xs font-bold rounded-xl transition-colors cursor-pointer"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* E-Prescribe (New Prescription) Modal */}
      {isEPrescribeOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-200">
          <div className="bg-white rounded-3xl max-w-xl w-full p-6 space-y-5 shadow-2xl border border-stone-200 relative">
            
            {/* Modal Header */}
            <div className="flex items-center justify-between border-b border-stone-200 pb-3.5">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-blue-600 flex items-center justify-center text-white shadow-md shadow-blue-500/20 shrink-0">
                  <svg className="w-5 h-5 text-white" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M 6 4 V 20 M 6 4 H 13 C 15.5 4 15.5 11 13 11 H 6 M 11 10 L 18 19" />
                  </svg>
                </div>
                <div>
                  <h3 className="text-base font-bold text-stone-900 flex items-center gap-2">
                    <span>E-Prescribe Portal</span>
                    <span className="px-2 py-0.5 rounded bg-blue-50 text-blue-700 text-[10px] font-bold border border-blue-200">Surescripts Network</span>
                  </h3>
                  <p className="text-xs text-stone-500 font-medium">New e-Rx for {selectedPatient.name} (DOB: {selectedPatient.dob || '02/11/1972'})</p>
                </div>
              </div>

              <button 
                onClick={() => setIsEPrescribeOpen(false)}
                className="p-2 rounded-full hover:bg-stone-100 text-stone-500 hover:text-stone-800 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {eRxSuccess ? (
              <div className="py-8 text-center space-y-4 animate-in zoom-in-95 duration-200">
                <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto border border-emerald-200 shadow-sm">
                  <CheckCircle2 className="w-10 h-10" />
                </div>
                <div className="space-y-1">
                  <h4 className="text-lg font-bold text-stone-900">Prescription Transmitted Successfully!</h4>
                  <p className="text-xs text-stone-600 max-w-md mx-auto">
                    Electronic prescription for <span className="font-bold text-stone-900">{eRxData.medication}</span> has been signed and routed to <span className="font-bold text-stone-900">{eRxData.pharmacy}</span>.
                  </p>
                </div>
                <div className="p-3 bg-stone-50 rounded-2xl border border-stone-200 text-left text-xs space-y-1 max-w-md mx-auto">
                  <div><span className="text-stone-500 font-semibold">Ref #:</span> <span className="font-mono font-bold text-stone-800">ERX-2026-991823</span></div>
                  <div><span className="text-stone-500 font-semibold">Instructions:</span> <span className="text-stone-800">{eRxData.instructions}</span></div>
                  <div><span className="text-stone-500 font-semibold">Status:</span> <span className="text-emerald-700 font-bold">Confirmed by Pharmacy Clearinghouse</span></div>
                </div>
                <button
                  onClick={() => setIsEPrescribeOpen(false)}
                  className="px-6 py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-xl shadow-xs cursor-pointer transition-colors"
                >
                  Done
                </button>
              </div>
            ) : (
              <form 
                onSubmit={(e) => {
                  e.preventDefault();
                  setERxSuccess(true);
                }}
                className="space-y-4"
              >
                {/* Medication Selection */}
                <div className="space-y-1">
                  <label className="text-xs font-bold text-stone-800 flex items-center justify-between">
                    <span>Medication Name & Formulation</span>
                    <span className="text-[10px] text-blue-600 font-semibold">RxNorm Standard</span>
                  </label>
                  <input 
                    type="text" 
                    value={eRxData.medication}
                    onChange={(e) => setERxData({...eRxData, medication: e.target.value})}
                    className="w-full px-3.5 py-2 bg-stone-50 border border-stone-300 rounded-xl text-xs font-semibold text-stone-900 focus:outline-hidden focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                    required
                  />
                </div>

                {/* Dosage & Quantity Grid */}
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-stone-800">Strength / Dosage</label>
                    <input 
                      type="text" 
                      value={eRxData.dosage}
                      onChange={(e) => setERxData({...eRxData, dosage: e.target.value})}
                      className="w-full px-3.5 py-2 bg-stone-50 border border-stone-300 rounded-xl text-xs font-semibold text-stone-900 focus:outline-hidden focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                      required
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <div className="space-y-1">
                      <label className="text-xs font-bold text-stone-800">Quantity</label>
                      <input 
                        type="text" 
                        value={eRxData.quantity}
                        onChange={(e) => setERxData({...eRxData, quantity: e.target.value})}
                        className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-xl text-xs font-semibold text-stone-900 focus:outline-hidden focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 text-center"
                        required
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-xs font-bold text-stone-800">Refills</label>
                      <input 
                        type="text" 
                        value={eRxData.refills}
                        onChange={(e) => setERxData({...eRxData, refills: e.target.value})}
                        className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-xl text-xs font-semibold text-stone-900 focus:outline-hidden focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 text-center"
                        required
                      />
                    </div>
                  </div>
                </div>

                {/* Sig / Instructions */}
                <div className="space-y-1">
                  <label className="text-xs font-bold text-stone-800">Sig / Patient Instructions</label>
                  <textarea 
                    value={eRxData.instructions}
                    onChange={(e) => setERxData({...eRxData, instructions: e.target.value})}
                    rows={2}
                    className="w-full px-3.5 py-2 bg-stone-50 border border-stone-300 rounded-xl text-xs font-semibold text-stone-900 focus:outline-hidden focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                    required
                  />
                </div>

                {/* Target Pharmacy Selector */}
                <div className="space-y-1">
                  <label className="text-xs font-bold text-stone-800 flex items-center gap-1.5">
                    <Building2 className="w-3.5 h-3.5 text-blue-600" />
                    <span>Destination Pharmacy</span>
                  </label>
                  <select
                    value={eRxData.pharmacy}
                    onChange={(e) => setERxData({...eRxData, pharmacy: e.target.value})}
                    className="w-full px-3.5 py-2 bg-stone-50 border border-stone-300 rounded-xl text-xs font-semibold text-stone-900 focus:outline-hidden focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                  >
                    <option value="CVS Pharmacy #4820 — 9045 Wilshire Blvd, Beverly Hills, CA">CVS Pharmacy #4820 — 9045 Wilshire Blvd, Beverly Hills, CA</option>
                    <option value="Walgreens #5811 — 300 N Canon Dr, Beverly Hills, CA">Walgreens #5811 — 300 N Canon Dr, Beverly Hills, CA</option>
                    <option value="RITE AID #05411 — 484 N Bedford Dr, Beverly Hills, CA">RITE AID #05411 — 484 N Bedford Dr, Beverly Hills, CA</option>
                  </select>
                </div>

                <div className="pt-2 flex items-center justify-between border-t border-stone-200">
                  <span className="text-[11px] text-stone-500 font-medium flex items-center gap-1">
                    <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                    <span>DEA & EPCS Compliant</span>
                  </span>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => setIsEPrescribeOpen(false)}
                      className="px-4 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 text-xs font-bold rounded-xl transition-colors cursor-pointer"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="px-5 py-2 bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-white text-xs font-bold rounded-xl transition-all shadow-2xs cursor-pointer flex items-center gap-2"
                    >
                      <Send className="w-3.5 h-3.5" />
                      <span>Transmit E-Prescribe</span>
                    </button>
                  </div>
                </div>
              </form>
            )}

          </div>
        </div>
      )}

      {/* Interactive Clinical Assessment PDF Forms Pop-up Modal */}
      {isPdfFormsModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6 animate-in fade-in duration-200 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-4xl w-full p-6 space-y-5 shadow-2xl border border-stone-200 relative my-auto max-h-[92vh] flex flex-col overflow-hidden">
            
            {/* Modal Top Nav Bar */}
            <div className="flex flex-wrap items-center justify-between border-b border-stone-200 pb-4 shrink-0 gap-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-indigo-600 text-white flex items-center justify-center shadow-md shadow-indigo-500/20 shrink-0">
                  <FileText className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-stone-900 flex items-center gap-2">
                    <span>Summit Surgical Center — Clinical Assessment Scans</span>
                    <span className="px-2 py-0.5 rounded bg-indigo-50 text-indigo-700 text-[10px] font-bold border border-indigo-200">
                      Converted PDF HTML Forms
                    </span>
                  </h3>
                  <p className="text-xs text-stone-500 font-medium">
                    Patient: <span className="font-bold text-stone-800">{selectedPatient.name}</span> (ID: {selectedPatient.patientId}) · DOS: 05/06/2026 · Dr. Richard Zoumalan
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => window.print()}
                  className="px-3.5 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 text-xs font-bold rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>Print Form</span>
                </button>
                <button 
                  onClick={() => setIsPdfFormsModalOpen(false)}
                  className="p-2 rounded-full hover:bg-stone-100 text-stone-500 hover:text-stone-800 transition-colors cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Sub-Tab Form Switcher Buttons */}
            <div className="flex gap-2 border-b border-stone-200 pb-3 shrink-0 bg-stone-50 p-1.5 rounded-2xl">
              <button
                onClick={() => setActivePdfFormTab('standing-orders')}
                className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold transition-all cursor-pointer text-center ${
                  activePdfFormTab === 'standing-orders'
                    ? 'bg-white text-indigo-900 shadow-2xs border border-indigo-200'
                    : 'text-stone-600 hover:text-stone-900 hover:bg-white/60'
                }`}
              >
                1. Doctors Standing Orders
              </button>
              <button
                onClick={() => setActivePdfFormTab('preop-checklist')}
                className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold transition-all cursor-pointer text-center ${
                  activePdfFormTab === 'preop-checklist'
                    ? 'bg-white text-indigo-900 shadow-2xs border border-indigo-200'
                    : 'text-stone-600 hover:text-stone-900 hover:bg-white/60'
                }`}
              >
                2. Pre-Op Checklist & Assessment
              </button>
              <button
                onClick={() => setActivePdfFormTab('surgical-checklist')}
                className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold transition-all cursor-pointer text-center ${
                  activePdfFormTab === 'surgical-checklist'
                    ? 'bg-white text-indigo-900 shadow-2xs border border-indigo-200'
                    : 'text-stone-600 hover:text-stone-900 hover:bg-white/60'
                }`}
              >
                3. Comprehensive Surgical Checklist
              </button>
            </div>

            {/* Scrollable Form Body Container */}
            <div className="flex-1 overflow-y-auto p-4 sm:p-6 bg-stone-50/70 rounded-2xl border border-stone-200 space-y-6 text-stone-900">
              
              {/* FORM 1: DOCTORS STANDING ORDERS */}
              {activePdfFormTab === 'standing-orders' && (
                <div className="bg-white p-6 sm:p-8 rounded-xl border border-stone-300 shadow-sm space-y-6 font-serif max-w-2xl mx-auto">
                  <div className="text-center space-y-1 border-b border-stone-300 pb-4">
                    <h2 className="text-lg font-bold tracking-wider uppercase text-stone-900">Summit Surgical Center</h2>
                    <p className="text-xs font-sans text-stone-600">416 N. Bedford Drive Suite 400B, Beverly Hills, CA 90210</p>
                    <h3 className="text-sm font-bold tracking-wide uppercase pt-2 text-stone-800 underline">Doctors Standing Orders</h3>
                  </div>

                  {/* Preoperative Orders */}
                  <div className="space-y-3 font-sans">
                    <h4 className="font-bold text-xs uppercase tracking-wider text-stone-900 border-b border-stone-200 pb-1">Preoperative Orders</h4>
                    <div className="space-y-2 text-xs">
                      <div className="flex items-center gap-2">
                        <span className="w-4 h-4 bg-stone-900 text-white rounded flex items-center justify-center font-bold text-xs">✓</span>
                        <span className="font-semibold">History and Physical</span>
                      </div>
                      <div className="flex items-start gap-2">
                        <span className="w-4 h-4 bg-stone-900 text-white rounded flex items-center justify-center font-bold text-xs shrink-0 mt-0.5">✓</span>
                        <div>
                          <span className="font-semibold">Surgery Consents For: </span>
                          <span className="font-mono underline font-bold text-stone-900">Face / Necklift, Septo / Rhinoplasty, Turbinates Reduction</span>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="w-4 h-4 bg-stone-900 text-white rounded flex items-center justify-center font-bold text-xs">✓</span>
                        <span className="font-semibold">IV Per Anesthesia</span>
                      </div>
                      <div className="flex items-start gap-2">
                        <span className="w-4 h-4 bg-stone-900 text-white rounded flex items-center justify-center font-bold text-xs shrink-0 mt-0.5">✓</span>
                        <div>
                          <span className="font-semibold">Labs Ordered: </span>
                          <span>Hgb, Hct, CBC, UA, PT, PTT, Electrolytes, Chest X Ray, EKG, HIV, Hepatitis</span>
                        </div>
                      </div>
                      <div className="flex items-start gap-2">
                        <span className="w-4 h-4 bg-stone-900 text-white rounded flex items-center justify-center font-bold text-xs shrink-0 mt-0.5">✓</span>
                        <div>
                          <span className="font-semibold">PreOP Medication: </span>
                          <span className="font-mono underline font-bold text-stone-900">IV Ancef 1g</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Postoperative Orders */}
                  <div className="space-y-3 font-sans border-t border-stone-300 pt-4">
                    <h4 className="font-bold text-xs uppercase tracking-wider text-stone-900 border-b border-stone-200 pb-1">Postoperative Orders</h4>
                    <div className="space-y-2 text-xs">
                      <div className="flex items-center gap-2">
                        <span className="w-4 h-4 bg-stone-900 text-white rounded flex items-center justify-center font-bold text-xs">✓</span>
                        <span className="font-semibold">Routine Vital Signs.</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="w-4 h-4 bg-stone-900 text-white rounded flex items-center justify-center font-bold text-xs">✓</span>
                        <span className="font-semibold">D/C IV when patient tolerating PO fluids without nausea and stable.</span>
                      </div>
                      <div className="flex items-start gap-2 pl-6">
                        <span className="font-semibold">Take home meds: </span>
                        <span className="font-mono underline font-bold text-stone-900">as prescribed by MD</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="w-4 h-4 bg-stone-900 text-white rounded flex items-center justify-center font-bold text-xs">✓</span>
                        <span className="font-semibold">D/C patient per Anesthesiologist</span>
                      </div>
                    </div>
                  </div>

                  {/* Signatures & Patient Stamp Box */}
                  <div className="border-t-2 border-stone-800 pt-4 grid grid-cols-2 gap-4 font-sans text-xs">
                    <div className="space-y-2">
                      <div><span className="font-bold">M.D. Signature:</span> <span className="font-serif italic font-bold text-blue-900 underline">Dr. Richard Zoumalan</span></div>
                      <div><span className="font-bold">Date:</span> <span className="underline font-bold">5/6/26</span></div>
                      <div><span className="font-bold">Noted by:</span> <span className="underline font-bold">A. Abadjian RN</span></div>
                    </div>

                    <div className="p-3 bg-stone-100 rounded-lg border border-stone-400 text-[11px] font-mono space-y-0.5">
                      <div className="font-bold border-b border-stone-300 pb-1">Mellman, Lori (113691)</div>
                      <div>DOB: 5/20/1965 | Age: 60 | Sex: Female</div>
                      <div>Provider: Richard Zoumalan, M.D.</div>
                      <div>DOS: 05/06/2026</div>
                    </div>
                  </div>
                </div>
              )}

              {/* FORM 2: PRE-OPERATIVE CHECKLIST & ASSESSMENT */}
              {activePdfFormTab === 'preop-checklist' && (
                <div className="bg-white p-6 sm:p-8 rounded-xl border border-stone-300 shadow-sm space-y-5 font-sans max-w-2xl mx-auto text-xs">
                  <div className="text-center border-b-2 border-stone-800 pb-2">
                    <h3 className="text-sm font-bold uppercase tracking-wide">Summit Surgical Center Pre-Operative Checklist and Assessment</h3>
                  </div>

                  <div className="grid grid-cols-2 gap-3 bg-stone-50 p-3 rounded-lg border border-stone-200">
                    <div><span className="font-bold">Date:</span> <span className="underline font-mono">05 / 06 / 2026</span></div>
                    <div><span className="font-bold">Transportation:</span> <span className="underline font-bold">Driver "Imortel"</span> (424-271-0010)</div>
                    <div><span className="font-bold">Home Caregiver:</span> <span className="underline">Nurse Tara (424-285-3701), Anna</span></div>
                    <div><span className="font-bold">Tomorrow Contact:</span> <span className="underline">Husband Tony (818-264-9795)</span></div>
                  </div>

                  {/* Vitals Banner */}
                  <div className="p-3 bg-rose-50 border border-rose-300 rounded-lg space-y-1">
                    <div className="font-bold text-rose-950 flex justify-between">
                      <span>Admission Vitals: Ht: 4'9" | Wt: 117.6 lb | Temp: 36.8°C | BP: 141/85 | RR: 16 | SpO2: 99%</span>
                    </div>
                    <div className="text-rose-900 font-bold underline">
                      Allergies (including soy & sulfites): PCN - Hives
                    </div>
                  </div>

                  {/* Pre-Op Checklist Table */}
                  <div className="grid grid-cols-2 gap-4 border-t border-stone-300 pt-3">
                    <div className="space-y-1.5">
                      <div className="flex justify-between font-bold border-b border-stone-200 pb-1">
                        <span>Checklist Item</span>
                        <span>Status</span>
                      </div>
                      <div className="flex justify-between"><span>H&P in chart</span><span className="font-bold text-emerald-700">✓ Yes</span></div>
                      <div className="flex justify-between"><span>Surgical consent signed</span><span className="font-bold text-emerald-700">✓ Yes</span></div>
                      <div className="flex justify-between"><span>Patient verbalized site</span><span className="font-bold text-emerald-700">✓ Yes</span></div>
                      <div className="flex justify-between"><span>NPO Time</span><span className="font-bold underline">8pm - 5/5/26</span></div>
                      <div className="flex justify-between"><span>Dentures/Loose teeth</span><span className="font-bold text-amber-800">Lower left loose</span></div>
                      <div className="flex justify-between"><span>Jewelry Removed</span><span className="font-bold text-emerald-700">✓ Yes</span></div>
                      <div className="flex justify-between"><span>Metal implants</span><span className="font-bold text-stone-500">No</span></div>
                    </div>

                    <div className="space-y-1.5 border-l border-stone-200 pl-4">
                      <div className="flex justify-between font-bold border-b border-stone-200 pb-1">
                        <span>Initial Assessment</span>
                        <span>Result</span>
                      </div>
                      <div className="flex justify-between"><span>Resp</span><span className="font-bold">WNL</span></div>
                      <div className="flex justify-between"><span>CV</span><span className="font-bold">WNL (Pulsex4, SR)</span></div>
                      <div className="flex justify-between"><span>Skin</span><span className="font-bold">WNL</span></div>
                      <div className="flex justify-between"><span>Color</span><span className="font-bold">Pink / WNL</span></div>
                      <div className="flex justify-between"><span>LOC</span><span className="font-bold">A&O x4</span></div>
                      <div className="flex justify-between"><span>Bleeding Tendencies</span><span className="font-bold text-stone-500">No</span></div>
                    </div>
                  </div>

                  <div className="border-t border-stone-300 pt-3 space-y-1.5">
                    <div className="font-bold">Pre-Operative Orders Administered:</div>
                    <div className="flex flex-wrap gap-2 text-[11px]">
                      <span className="px-2 py-1 bg-stone-100 rounded border font-bold">✓ Celebrex</span>
                      <span className="px-2 py-1 bg-stone-100 rounded border font-bold">✓ Emend</span>
                      <span className="px-2 py-1 bg-stone-100 rounded border font-bold">✓ Journavax</span>
                      <span className="px-2 py-1 bg-blue-100 text-blue-900 rounded border border-blue-300 font-bold">✓ Valium 5mg</span>
                    </div>
                    <div className="pt-2 text-[11px] text-stone-600">
                      IV Site: <span className="font-bold text-stone-900 underline">Left Hand</span> | Inserted by: <span className="font-bold text-stone-900">Dr. Taheri</span> | Nurse: <span className="font-bold text-stone-900">U. Kriskier, RN</span>
                    </div>
                  </div>
                </div>
              )}

              {/* FORM 3: COMPREHENSIVE SURGICAL CHECKLIST */}
              {activePdfFormTab === 'surgical-checklist' && (
                <div className="bg-white p-6 sm:p-8 rounded-xl border border-stone-300 shadow-sm space-y-5 font-sans max-w-3xl mx-auto text-xs">
                  <div className="text-center border-b-2 border-stone-800 pb-2">
                    <h3 className="text-sm font-bold uppercase tracking-wide">Comprehensive Surgical Checklist (AORN / WHO Protocol)</h3>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
                    {/* Phase 1 */}
                    <div className="p-3 bg-stone-50 rounded-lg border border-stone-300 space-y-2">
                      <div className="font-bold text-stone-900 uppercase border-b border-stone-200 pb-1 text-[11px]">
                        In Holding Area
                      </div>
                      <div className="space-y-1 text-[11px]">
                        <div>RN: <span className="font-bold underline">U. Kriskier, RN</span></div>
                        <div className="text-emerald-700 font-bold">✓ Identity Confirmed</div>
                        <div className="text-emerald-700 font-bold">✓ Procedure & Site</div>
                        <div className="text-emerald-700 font-bold">✓ Consents Signed</div>
                        <div className="text-emerald-700 font-bold">✓ Site Marked</div>
                      </div>
                    </div>

                    {/* Phase 2 */}
                    <div className="p-3 bg-stone-50 rounded-lg border border-stone-300 space-y-2">
                      <div className="font-bold text-stone-900 uppercase border-b border-stone-200 pb-1 text-[11px]">
                        Before Induction (Sign-In)
                      </div>
                      <div className="space-y-1 text-[11px]">
                        <div>Anesthesia: <span className="font-bold underline">Dr. Taheri</span></div>
                        <div className="text-rose-700 font-bold">✓ Allergy: PCN (hives)</div>
                        <div className="text-emerald-700 font-bold">✓ Difficult Airway: No</div>
                        <div className="text-emerald-700 font-bold">✓ Equipment Ready</div>
                        <div className="text-emerald-700 font-bold">✓ SCD 40mmHg On</div>
                      </div>
                    </div>

                    {/* Phase 3 */}
                    <div className="p-3 bg-stone-50 rounded-lg border border-stone-300 space-y-2">
                      <div className="font-bold text-stone-900 uppercase border-b border-stone-200 pb-1 text-[11px]">
                        Before Incision (Time-Out)
                      </div>
                      <div className="space-y-1 text-[11px]">
                        <div>Surgeon: <span className="font-bold underline">Dr. Zoumalan</span></div>
                        <div className="text-emerald-700 font-bold">✓ Time-Out Executed</div>
                        <div className="text-emerald-700 font-bold">✓ Abx: IV Ancef 1g</div>
                        <div className="text-emerald-700 font-bold">✓ Sterilization Confirm</div>
                        <div className="text-emerald-700 font-bold">✓ Images Displayed</div>
                      </div>
                    </div>

                    {/* Phase 4 */}
                    <div className="p-3 bg-stone-50 rounded-lg border border-stone-300 space-y-2">
                      <div className="font-bold text-stone-900 uppercase border-b border-stone-200 pb-1 text-[11px]">
                        Before Leaving OR (Sign-Out)
                      </div>
                      <div className="space-y-1 text-[11px]">
                        <div>RN: <span className="font-bold underline">Ani Abadjian, RN</span></div>
                        <div className="text-emerald-700 font-bold">✓ Procedure Name</div>
                        <div className="text-emerald-700 font-bold">✓ Counts Complete</div>
                        <div className="text-emerald-700 font-bold">✓ Specimens Labeled</div>
                        <div className="text-emerald-700 font-bold">✓ PACU Transfer Ready</div>
                      </div>
                    </div>
                  </div>

                  <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-lg text-center font-bold text-emerald-900">
                    Surgical Safety Verification Complete · All 4 Audit Gateways Signed & Recorded
                  </div>
                </div>
              )}

            </div>

            {/* Modal Bottom Footer */}
            <div className="flex items-center justify-between pt-3 border-t border-stone-200 shrink-0">
              <span className="text-xs text-stone-500 font-medium flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                <span>Verified Digital Chart Record · Summit Surgical Center HIPAA Vault</span>
              </span>

              <button
                onClick={() => setIsPdfFormsModalOpen(false)}
                className="px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-xl transition-colors cursor-pointer"
              >
                Close Form Portal
              </button>
            </div>

          </div>
        </div>
      )}

      {/* Note Reader Modal */}
      {viewingHistoryNote && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-200">
          <div className="bg-white rounded-3xl max-w-2xl w-full p-6 shadow-2xl border border-stone-300 space-y-4 relative">
            <div className="flex items-center justify-between border-b border-stone-200 pb-3">
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-base font-bold text-stone-900">{viewingHistoryNote.title}</h3>
                  <span className="px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-bold border border-emerald-200">
                    {viewingHistoryNote.status}
                  </span>
                </div>
                <p className="text-xs text-stone-500 font-medium mt-0.5">
                  Author: <strong className="text-stone-800">{viewingHistoryNote.author}</strong> · {viewingHistoryNote.date}
                </p>
              </div>
              <button
                onClick={() => setViewingHistoryNote(null)}
                className="p-2 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-600 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-4 bg-stone-50 rounded-2xl border border-stone-200 text-xs text-stone-800 leading-relaxed font-mono whitespace-pre-wrap max-h-[60vh] overflow-y-auto">
              {viewingHistoryNote.content}
            </div>

            <div className="flex items-center justify-between pt-2 border-t border-stone-200">
              <span className="text-[11px] text-stone-500 font-medium">Verified in Summit Surgical Center EHR</span>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => alert('Printing note...')}
                  className="px-3 py-1.5 bg-stone-100 hover:bg-stone-200 text-stone-800 font-bold text-xs rounded-xl transition-colors cursor-pointer flex items-center gap-1.5"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>Print Note</span>
                </button>
                <button
                  onClick={() => setViewingHistoryNote(null)}
                  className="px-4 py-1.5 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-xl shadow-xs transition-colors cursor-pointer"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Pre-Op Email Intake Link Modal */}
      {isPreOpEmailModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-200">
          <div className="bg-white rounded-3xl max-w-2xl w-full p-6 shadow-2xl border border-stone-300 space-y-5 relative">
            <div className="flex items-center justify-between border-b border-stone-200 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-indigo-50 text-indigo-700 rounded-xl">
                  <Mail className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-stone-900">Email Pre-Op Intake Forms to Patient</h3>
                  <p className="text-xs text-stone-500 font-medium">
                    Send secure Patient Portal link with selected pre-operative PDF forms
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsPreOpEmailModalOpen(false)}
                className="p-2 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-600 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4 text-xs">
              {/* Recipient Input */}
              <div className="space-y-1">
                <label className="font-bold text-stone-800">Patient Email Address</label>
                <input
                  type="email"
                  value={customEmailRecipient}
                  onChange={(e) => setCustomEmailRecipient(e.target.value)}
                  className="w-full p-2.5 bg-stone-50 border border-stone-300 rounded-xl font-mono text-stone-900 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  placeholder="patient@example.com"
                />
              </div>

              {/* Subject Line */}
              <div className="space-y-1">
                <label className="font-bold text-stone-800">Email Subject Line</label>
                <input
                  type="text"
                  defaultValue={`Action Required: Pre-Operative Intake & Consent Packet for ${selectedPatient.name}`}
                  className="w-full p-2.5 bg-stone-50 border border-stone-300 rounded-xl font-bold text-stone-900 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              {/* Email Body & Portal Link Preview Box */}
              <div className="p-4 bg-stone-50 rounded-2xl border border-stone-200 space-y-3">
                <div className="text-[11px] font-bold text-stone-500 uppercase tracking-wider">
                  PREVIEW OF EMAIL SENT TO PATIENT
                </div>
                <p className="text-stone-800 leading-relaxed font-sans">
                  Dear <strong>{selectedPatient.name}</strong>,<br />
                  Your pre-operative surgical appointment at <strong>Summit Surgical Center</strong> is scheduled for <strong>{selectedPatient.appointmentDate || 'May 06, 2026'}</strong>.
                </p>
                <p className="text-stone-800 leading-relaxed font-sans">
                  Please click the link below to access your confidential Patient Portal. You must review, complete, and electronically sign the <strong>{selectedPreOpFormIds.length} pre-operative intake forms</strong> prior to your surgery date.
                </p>

                {/* Secure Portal Link Callout */}
                <div className="p-3 bg-indigo-50 border border-indigo-200 rounded-xl flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2 min-w-0">
                    <Link className="w-4 h-4 text-indigo-600 shrink-0" />
                    <span className="font-mono text-[11px] text-indigo-900 font-bold truncate">
                      https://portal.summitsurgical.com/intake/{selectedPatient.patientId || 'p-113561'}?token=preop-2026
                    </span>
                  </div>
                  <button
                    onClick={() => {
                      navigator.clipboard.writeText(`https://portal.summitsurgical.com/intake/${selectedPatient.patientId || 'p-113561'}?token=preop-2026`);
                      alert('Portal link copied to clipboard!');
                    }}
                    className="px-2.5 py-1 bg-white hover:bg-stone-100 border border-indigo-200 text-indigo-800 text-[11px] font-bold rounded-lg cursor-pointer flex items-center gap-1 shrink-0"
                  >
                    <Copy className="w-3 h-3" />
                    <span>Copy</span>
                  </button>
                </div>

                {/* Included Forms Badges */}
                <div className="pt-2 border-t border-stone-200">
                  <div className="text-[11px] font-bold text-stone-700 mb-2">
                    {selectedPreOpFormIds.length} Forms Included in This Portal Link:
                  </div>
                  <div className="flex flex-wrap gap-1.5 max-h-36 overflow-y-auto">
                    {PRE_OP_INTAKE_PDF_FORMS.filter((f) => selectedPreOpFormIds.includes(f.id)).map((f) => (
                      <span key={f.id} className="px-2.5 py-1 bg-white border border-stone-200 rounded-lg text-[11px] font-bold text-stone-800 shadow-2xs">
                        ✓ {f.title}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* Modal Bottom Actions */}
            <div className="flex items-center justify-between pt-3 border-t border-stone-200">
              <span className="text-[11px] text-stone-500 font-medium">
                HIPAA Secure Transmittal · Summit Surgical Portal
              </span>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setIsPreOpEmailModalOpen(false)}
                  className="px-4 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 font-bold text-xs rounded-xl transition-colors cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  onClick={() => {
                    const updated = { ...formStatuses };
                    selectedPreOpFormIds.forEach((id) => {
                      updated[id] = 'Sent via Email';
                    });
                    setFormStatuses(updated);
                    setIsPreOpEmailModalOpen(false);
                    setPreOpEmailSuccessToast(
                      `Pre-operative intake email with secure Patient Portal link was sent to ${customEmailRecipient || selectedPatient.name}!`
                    );
                  }}
                  className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-xl shadow-xs transition-colors cursor-pointer flex items-center gap-1.5"
                >
                  <Send className="w-4 h-4" />
                  <span>Send Email with Portal Link</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Patient Portal Interactive Preview Modal */}
      {isPreOpPortalPreviewOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-200">
          <div className="bg-white rounded-3xl max-w-4xl w-full p-6 shadow-2xl border border-stone-300 space-y-4 relative max-h-[92vh] flex flex-col">
            
            {/* Header Bar */}
            <div className="flex items-center justify-between border-b border-stone-200 pb-3 shrink-0">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-emerald-50 text-emerald-700 rounded-xl">
                  <Laptop className="w-5 h-5" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-base font-bold text-stone-900">Summit Surgical Center — Patient Portal Preview</h3>
                    <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-bold border border-emerald-200">
                      LIVE PATIENT PORTAL
                    </span>
                  </div>
                  <p className="text-xs text-stone-500 font-medium">
                    Simulating how <strong className="text-stone-800">{selectedPatient.name}</strong> completes and signs pre-op forms
                  </p>
                </div>
              </div>

              <button
                onClick={() => setIsPreOpPortalPreviewOpen(false)}
                className="p-2 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-600 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Portal Patient Greeting Banner */}
            <div className="p-3 bg-gradient-to-r from-slate-900 to-indigo-950 text-white rounded-2xl flex flex-wrap items-center justify-between gap-3 text-xs shrink-0">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-full bg-indigo-500/30 text-indigo-200 font-bold flex items-center justify-center border border-indigo-400/30">
                  {selectedPatient.name.split(' ').map(n=>n[0]).join('')}
                </div>
                <div>
                  <div className="font-bold text-white text-sm">{selectedPatient.name}</div>
                  <div className="text-indigo-200 text-[11px]">
                    Surgery Date: {selectedPatient.appointmentDate || 'May 06, 2026'} · Surgeon: {selectedPatient.surgeon || 'Dr. Richard Zoumalan'}
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <span className="px-2.5 py-1 bg-white/10 text-emerald-300 font-mono text-[11px] rounded-lg border border-white/20">
                  🔒 Secure SSL Connection
                </span>
              </div>
            </div>

            {/* Main Portal View Layout */}
            <div className="flex-1 overflow-hidden grid grid-cols-1 md:grid-cols-12 gap-4 min-h-[380px]">
              
              {/* Left Sidebar Form Navigation */}
              <div className="md:col-span-4 bg-stone-50 p-3 rounded-2xl border border-stone-200 space-y-2 overflow-y-auto max-h-[460px]">
                <div className="text-[10px] font-bold text-stone-400 uppercase tracking-wider px-2 pt-1">
                  PRE-SURGERY INTAKE PACKET
                </div>

                {PRE_OP_INTAKE_PDF_FORMS.map((form) => {
                  const isActive = activePortalFormId === form.id;
                  const isCheckedInEmail = selectedPreOpFormIds.includes(form.id);
                  const status = formStatuses[form.id] || form.status;

                  return (
                    <button
                      key={form.id}
                      onClick={() => setActivePortalFormId(form.id)}
                      className={`w-full text-left p-2.5 rounded-xl border text-xs transition-all cursor-pointer flex items-center justify-between gap-2 ${
                        isActive
                          ? 'bg-indigo-600 text-white border-indigo-600 shadow-xs'
                          : isCheckedInEmail
                          ? 'bg-white text-stone-800 border-stone-200 hover:bg-stone-100'
                          : 'bg-stone-100/60 text-stone-400 border-stone-200 opacity-60'
                      }`}
                    >
                      <div className="min-w-0 flex-1">
                        <div className="font-bold truncate">{form.title}</div>
                        <div className={`text-[10px] truncate ${isActive ? 'text-indigo-100' : 'text-stone-500'}`}>
                          {form.pdfGroup}
                        </div>
                      </div>

                      <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded shrink-0 ${
                        status === 'Completed in Portal'
                          ? isActive ? 'bg-emerald-500 text-white' : 'bg-emerald-100 text-emerald-800'
                          : isActive ? 'bg-indigo-700 text-white' : 'bg-stone-200 text-stone-700'
                      }`}>
                        {status === 'Completed in Portal' ? '✓ Signed' : 'Pending'}
                      </span>
                    </button>
                  );
                })}
              </div>

              {/* Right Main Form Viewer & Signature Pad */}
              {(() => {
                const currentForm = PRE_OP_INTAKE_PDF_FORMS.find((f) => f.id === activePortalFormId) || PRE_OP_INTAKE_PDF_FORMS[0];
                const isCompleted = formStatuses[currentForm.id] === 'Completed in Portal';

                return (
                  <div className="md:col-span-8 bg-white p-5 rounded-2xl border border-stone-200 space-y-4 overflow-y-auto max-h-[460px] text-xs">
                    
                    {/* Form Header */}
                    <div className="border-b border-stone-200 pb-3 flex items-start justify-between gap-2">
                      <div>
                        <div className="text-[10px] font-bold text-indigo-600 uppercase tracking-wider">
                          SUMMIT SURGICAL CENTER · FORM PACKET
                        </div>
                        <h4 className="font-bold text-base text-stone-900 mt-0.5">{currentForm.title}</h4>
                        <p className="text-stone-500 text-xs font-medium">{currentForm.subtitle}</p>
                      </div>

                      <span className={`px-2.5 py-1 rounded-full text-xs font-bold border shrink-0 ${
                        isCompleted
                          ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                          : 'bg-amber-50 text-amber-800 border-amber-200'
                      }`}>
                        {isCompleted ? '✓ Signed in Portal' : 'Action Required'}
                      </span>
                    </div>

                    {/* Form Description & Content Preview */}
                    <div className="p-3.5 bg-stone-50 rounded-xl border border-stone-200 text-stone-800 leading-relaxed space-y-2 font-sans">
                      <p className="font-bold text-stone-900">{currentForm.description}</p>

                      {currentForm.id === 'patients-rights' && (
                        <div className="space-y-1.5 text-[11px] text-stone-700 pt-2 border-t border-stone-200">
                          <div>• Patients are treated with respect, consideration, and dignity with personal privacy.</div>
                          <div>• Right to be fully informed of scope of services, post-op instructions, and fees.</div>
                          <div>• Responsibility to provide complete medical/medication history and a responsible adult driver.</div>
                        </div>
                      )}

                      {currentForm.id === 'advanced-directives' && (
                        <div className="space-y-2 text-[11px] text-stone-700 pt-2 border-t border-stone-200">
                          <p>Summit Surgical Center performs elective outpatient procedures. In event of emergency, cardiac life support is instituted and patient transferred to Cedars-Sinai Medical Center.</p>
                          <div className="space-y-1 font-bold">
                            <label className="flex items-center gap-2 cursor-pointer">
                              <input type="checkbox" defaultChecked className="rounded border-stone-300 text-indigo-600 focus:ring-indigo-500" />
                              <span>I have read and understand Advanced Directives policy</span>
                            </label>
                            <label className="flex items-center gap-2 cursor-pointer">
                              <input type="checkbox" className="rounded border-stone-300 text-indigo-600 focus:ring-indigo-500" />
                              <span>I DO have an Advance Directive</span>
                            </label>
                            <label className="flex items-center gap-2 cursor-pointer">
                              <input type="checkbox" defaultChecked className="rounded border-stone-300 text-indigo-600 focus:ring-indigo-500" />
                              <span>I DO NOT have an Advance Directive</span>
                            </label>
                          </div>
                        </div>
                      )}

                      {currentForm.id === 'anesthesia-questionnaire' && (
                        <div className="grid grid-cols-2 gap-2 text-[11px] pt-2 border-t border-stone-200 font-sans">
                          <div><strong>Height:</strong> 5' 6"</div>
                          <div><strong>Weight:</strong> 138 lbs</div>
                          <div><strong>Drug Allergies:</strong> Penicillin (Hives)</div>
                          <div><strong>Latex Allergy:</strong> No</div>
                          <div><strong>Past Surgeries:</strong> Appendectomy (2018)</div>
                          <div><strong>Airway History:</strong> Normal</div>
                        </div>
                      )}
                    </div>

                    {/* Electronic Patient Signature Box */}
                    <div className="p-4 bg-stone-50 rounded-2xl border border-stone-300 space-y-3">
                      <div className="flex items-center justify-between">
                        <label className="font-bold text-stone-900 text-xs flex items-center gap-1.5">
                          <CheckCircle2 className="w-4 h-4 text-indigo-600" />
                          <span>Patient Electronic Signature & Date</span>
                        </label>
                        <span className="text-[10px] text-stone-400 font-mono">21 C.F.R. Part 11 Compliant</span>
                      </div>

                      <div className="p-3 bg-white rounded-xl border border-stone-300 text-center font-serif italic font-bold text-lg text-indigo-900 border-dashed min-h-[50px] flex items-center justify-center">
                        {selectedPatient.name}
                      </div>

                      <div className="flex items-center justify-between text-[11px] text-stone-500">
                        <span>Signed by IP: 192.168.1.42</span>
                        <span>Date: May 06, 2026</span>
                      </div>
                    </div>

                    {/* Submit Form Button */}
                    <button
                      onClick={() => {
                        setFormStatuses({
                          ...formStatuses,
                          [currentForm.id]: 'Completed in Portal',
                        });
                        alert(`Successfully submitted and signed "${currentForm.title}" in Patient Portal!`);
                      }}
                      className="w-full py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs rounded-xl shadow-2xs transition-colors cursor-pointer flex items-center justify-center gap-2"
                    >
                      <CheckCircle2 className="w-4 h-4" />
                      <span>{isCompleted ? 'Update Signed Form in Portal' : 'Complete & Sign Form in Patient Portal'}</span>
                    </button>
                  </div>
                );
              })()}
            </div>

            {/* Modal Bottom Footer */}
            <div className="flex items-center justify-between pt-3 border-t border-stone-200 shrink-0">
              <span className="text-xs text-stone-500 font-medium flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                <span>Patient Portal Sync Enabled · Real-time intake feed for Summit Surgical Center</span>
              </span>

              <button
                onClick={() => setIsPreOpPortalPreviewOpen(false)}
                className="px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-xl transition-colors cursor-pointer"
              >
                Close Portal Preview
              </button>
            </div>

          </div>
        </div>
      )}

      {/* Full-Screen Overlay Document Viewer (Blank Page with ONLY a Close Button, NO header or navigation) */}
      {viewingDoc && (
        <div className="fixed inset-0 z-[99999] bg-stone-100 flex flex-col w-screen h-screen overflow-y-auto animate-in fade-in duration-150">
          {/* Floating Corner Close Button */}
          <button
            type="button"
            onClick={() => setViewingDoc(null)}
            className="fixed top-4 right-6 z-[100000] px-4 py-2.5 bg-stone-900/95 hover:bg-stone-900 text-white font-bold text-xs rounded-xl shadow-2xl transition-all cursor-pointer border border-stone-700/80 backdrop-blur-md flex items-center gap-2 group"
          >
            <X className="w-4 h-4 text-stone-300 group-hover:text-white transition-colors" />
            <span>Close Document</span>
          </button>

          {/* Blank Page Document Container */}
          <div className="w-full flex-1 bg-stone-100 p-2 sm:p-6 flex justify-center items-start min-h-screen overflow-x-hidden">
            <div className="w-full max-w-4xl bg-white rounded-2xl shadow-xl border border-stone-200 p-6 sm:p-10 my-4 sm:my-8 flex flex-col justify-between space-y-6">
              {/* If Converted PDF Form Tab */}
              {viewingDoc.formTab === 'standing-orders' && (
                <div className="space-y-6 text-xs text-stone-800">
                  <div className="text-center space-y-1 border-b border-stone-300 pb-4">
                    <h2 className="text-base font-bold tracking-wider uppercase text-stone-900">SUMMIT SURGICAL CENTER</h2>
                    <p className="text-xs text-stone-600">416 N. Bedford Drive Suite 400B, Beverly Hills, CA 90210</p>
                    <h3 className="text-sm font-bold tracking-wide uppercase pt-2 text-stone-800 underline">DOCTORS STANDING ORDERS</h3>
                  </div>
                  <div className="space-y-4">
                    <div className="p-4 bg-stone-50 rounded-xl border border-stone-200 space-y-2">
                      <h4 className="font-bold text-stone-900 uppercase">Preoperative Orders</h4>
                      <p>✓ History and Physical | ✓ Surgery Consents for Face/Necklift, Rhinoplasty | ✓ IV Per Anesthesia | ✓ PreOP Med: IV Ancef 1g</p>
                    </div>
                    <div className="p-4 bg-stone-50 rounded-xl border border-stone-200 space-y-2">
                      <h4 className="font-bold text-stone-900 uppercase">Postoperative Orders</h4>
                      <p>✓ Routine Vital Signs | ✓ D/C IV when patient tolerating PO fluids | ✓ D/C patient per Anesthesiologist</p>
                    </div>
                  </div>
                  <div className="border-t-2 border-stone-800 pt-4 flex justify-between items-center text-xs">
                    <div><strong>MD Signature:</strong> Dr. Richard Zoumalan | <strong>Date:</strong> 5/6/26</div>
                    <div><strong>Noted by:</strong> A. Abadjian, RN</div>
                  </div>
                </div>
              )}

              {viewingDoc.formTab === 'preop-checklist' && (
                <div className="space-y-6 text-xs text-stone-800">
                  <div className="text-center border-b-2 border-stone-800 pb-2">
                    <h3 className="text-base font-bold uppercase tracking-wide">Summit Surgical Center Pre-Operative Checklist and Assessment</h3>
                  </div>
                  <div className="p-4 bg-rose-50 border border-rose-300 rounded-xl space-y-1">
                    <div className="font-bold text-rose-950">Admission Vitals: Ht: 4'9" | Wt: 117.6 lb | BP: 141/85 | RR: 16 | SpO2: 99%</div>
                    <div className="text-rose-900 font-bold underline">Allergies: PCN (Hives)</div>
                  </div>
                  <div className="p-4 bg-stone-50 rounded-xl border border-stone-200 space-y-2">
                    <div className="font-bold text-stone-900">Checklist Summary:</div>
                    <p>✓ H&P in chart | ✓ Surgical consent signed | ✓ Site marked | ✓ NPO since 8pm | Loose lower left tooth noted</p>
                  </div>
                </div>
              )}

              {viewingDoc.formTab === 'surgical-checklist' && (
                <div className="space-y-6 text-xs text-stone-800">
                  <div className="text-center border-b-2 border-stone-800 pb-2">
                    <h3 className="text-base font-bold uppercase tracking-wide">Comprehensive Surgical Checklist (AORN / WHO Protocol)</h3>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="p-3 bg-stone-50 rounded-lg border border-stone-200 space-y-1">
                      <div className="font-bold text-stone-900">1. Holding Area</div>
                      <p>✓ Identity & site confirmed by U. Kriskier, RN</p>
                    </div>
                    <div className="p-3 bg-stone-50 rounded-lg border border-stone-200 space-y-1">
                      <div className="font-bold text-stone-900">2. Before Induction</div>
                      <p>✓ Allergy PCN noted by Dr. Taheri</p>
                    </div>
                    <div className="p-3 bg-stone-50 rounded-lg border border-stone-200 space-y-1">
                      <div className="font-bold text-stone-900">3. Time-Out</div>
                      <p>✓ Executed by Dr. Zoumalan</p>
                    </div>
                    <div className="p-3 bg-stone-50 rounded-lg border border-stone-200 space-y-1">
                      <div className="font-bold text-stone-900">4. Sign-Out</div>
                      <p>✓ Counts complete by Ani Abadjian, RN</p>
                    </div>
                  </div>
                </div>
              )}

              {/* ID & Insurance Scans */}
              {(viewingDoc.id === 'doc-5' || viewingDoc.id === 'doc-6') && (
                <div className="space-y-6 text-center">
                  <h3 className="text-base font-bold text-stone-900">{viewingDoc.title}</h3>
                  <div className="flex justify-center">
                    <img
                      src={viewingDoc.id === 'doc-5' ? idCardUrl : insuranceCardFrontUrl}
                      alt={viewingDoc.title}
                      className="max-h-96 rounded-2xl shadow-lg border border-stone-300 object-contain"
                    />
                  </div>
                  {viewingDoc.id === 'doc-6' && (
                    <div className="flex justify-center">
                      <img
                        src={insuranceCardBackUrl}
                        alt="Insurance Card Back"
                        className="max-h-96 rounded-2xl shadow-lg border border-stone-300 object-contain"
                      />
                    </div>
                  )}
                  <p className="text-xs text-stone-500 font-mono">{viewingDoc.summary}</p>
                </div>
              )}

              {/* Standard text document content view */}
              {!viewingDoc.formTab && viewingDoc.id !== 'doc-5' && viewingDoc.id !== 'doc-6' && (
                <div className="space-y-6">
                  <div className="border-b border-stone-200 pb-4">
                    <h2 className="text-lg font-bold text-stone-900">{viewingDoc.title}</h2>
                    <p className="text-xs text-stone-500 font-medium mt-1">
                      Category: <span className="font-bold text-stone-700">{viewingDoc.type}</span> · Submission Date: <span className="font-bold text-stone-700">{viewingDoc.submissionDate}</span>
                    </p>
                  </div>

                  <div className="p-5 bg-stone-50 rounded-xl border border-stone-200 whitespace-pre-wrap font-mono text-xs text-stone-800 leading-relaxed min-h-[300px]">
                    {viewingDoc.content || viewingDoc.summary}
                  </div>

                  <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-xl flex items-center justify-between text-xs text-emerald-900 font-bold">
                    <span className="flex items-center gap-1.5">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                      <span>Verified EHR Record Attachment</span>
                    </span>
                    <span>Archival ID: #{viewingDoc.id.toUpperCase()}</span>
                  </div>
                </div>
              )}

              {/* Footer inside document card */}
              <div className="pt-6 border-t border-stone-200 flex flex-wrap items-center justify-between gap-4 text-xs text-stone-500">
                <div>Patient: <strong>{selectedPatient.name}</strong> | DOB: <strong>{selectedPatient.dob || '02/11/1972'}</strong> | MRN: <strong>{selectedPatient.patientId}</strong></div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ---------------------------------------------------- */}
      {/* HTML INTAKE FORMS MODALS & OVERLAYS                  */}
      {/* ---------------------------------------------------- */}

      {/* 1. View HTML Form Overlay (Blank Page with ONLY a Close Button, NO header or navigation) */}
      {viewingHtmlForm && (
        <div className="fixed inset-0 z-[99999] bg-stone-100 flex flex-col w-screen h-screen overflow-y-auto animate-in fade-in duration-150">
          {/* Floating Corner Close Button — Just a close button and NO header or navigation! */}
          <button
            type="button"
            onClick={() => setViewingHtmlForm(null)}
            className="fixed top-4 right-6 z-[100000] px-4 py-2.5 bg-stone-900/95 hover:bg-stone-900 text-white font-bold text-xs rounded-xl shadow-2xl transition-all cursor-pointer border border-stone-700/80 backdrop-blur-md flex items-center gap-2 group"
          >
            <X className="w-4 h-4 text-stone-300 group-hover:text-white transition-colors" />
            <span>Close Form</span>
          </button>

          {/* Blank Page Native Form Container */}
          <div className="w-full flex-1 bg-stone-100 p-2 sm:p-6 flex justify-center items-start min-h-screen overflow-x-hidden">
            <div className="w-full max-w-3xl bg-white rounded-2xl shadow-xl border border-stone-200 p-3 sm:p-6 my-2 sm:my-4 relative overflow-x-hidden">
              <style>{`
                .page { max-width: 100% !important; margin: 0 auto !important; box-shadow: none !important; border: none !important; padding: 12px 16px !important; }
                .grid { max-width: 100% !important; }
                table { max-width: 100% !important; width: 100% !important; }
              `}</style>
              <div dangerouslySetInnerHTML={{ __html: viewingHtmlForm.htmlTemplate }} />
            </div>
          </div>
        </div>
      )}

      {/* 2. Send Link via Email / SMS Modal */}
      {sendFormModalItem && (
        <div className="fixed inset-0 z-[120] bg-stone-900/80 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in duration-200">
          <div className="bg-white rounded-2xl max-w-lg w-full shadow-2xl border border-stone-200 overflow-hidden space-y-0">
            {/* Modal Header */}
            <div className="p-5 bg-gradient-to-r from-stone-900 to-indigo-950 text-white flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2.5 bg-blue-500/20 rounded-xl border border-blue-400/30 text-blue-300">
                  <Send className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-base text-white">Send Form Link to Patient</h3>
                  <p className="text-xs text-stone-300">Share secure portal link via Email or SMS</p>
                </div>
              </div>

              <button
                onClick={() => setSendFormModalItem(null)}
                className="p-1.5 rounded-lg bg-stone-800 hover:bg-stone-700 text-stone-300 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-6 space-y-5 text-xs text-stone-800">
              {/* Selected Forms List Box */}
              <div className="p-3.5 bg-indigo-50/80 border border-indigo-200 rounded-xl space-y-2.5">
                <div className="flex items-center justify-between">
                  <label className="font-bold text-stone-900 text-xs flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 text-indigo-600" />
                    <span>Selected Forms ({intakeFormsList.filter((f) => selectedIntakeFormIds.includes(f.id)).length}):</span>
                  </label>
                  <button
                    type="button"
                    onClick={() => {
                      if (selectedIntakeFormIds.length === intakeFormsList.length) {
                        setSelectedIntakeFormIds([]);
                      } else {
                        setSelectedIntakeFormIds(intakeFormsList.map((f) => f.id));
                      }
                    }}
                    className="text-[11px] font-bold text-indigo-600 hover:text-indigo-800 cursor-pointer underline"
                  >
                    {selectedIntakeFormIds.length === intakeFormsList.length ? 'Deselect All' : 'Select All'}
                  </button>
                </div>

                <div className="space-y-1.5 max-h-48 overflow-y-auto pr-1">
                  {intakeFormsList
                    .filter((f) => selectedIntakeFormIds.includes(f.id))
                    .map((form) => (
                      <div key={form.id} className="p-2.5 bg-white border border-indigo-100 rounded-xl flex items-center justify-between gap-2 shadow-2xs">
                        <div className="flex items-center gap-2 min-w-0">
                          <FileText className="w-4 h-4 text-indigo-600 shrink-0" />
                          <div className="min-w-0">
                            <div className="font-bold text-stone-900 text-xs truncate">{form.title}</div>
                            <div className="text-[10.5px] text-stone-500 font-medium truncate">{form.fileName}</div>
                          </div>
                        </div>
                        <button
                          type="button"
                          onClick={() => setSelectedIntakeFormIds((prev) => prev.filter((id) => id !== form.id))}
                          className="p-1 hover:bg-stone-100 rounded-lg text-stone-400 hover:text-stone-600 cursor-pointer transition-colors"
                          title="Remove form from email"
                        >
                          <X className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    ))}

                  {selectedIntakeFormIds.length === 0 && (
                    <div className="p-4 text-center text-amber-800 bg-amber-50 rounded-xl border border-amber-200 font-medium text-xs">
                      No forms selected. Please check at least one form or click "Select All".
                    </div>
                  )}
                </div>
              </div>

              {/* Delivery Channel Selection */}
              <div className="space-y-2">
                <label className="font-bold text-stone-900 block">Select Delivery Method</label>
                <div className="grid grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => {
                      setSendChannel('email');
                      setSendRecipient(selectedPatient.email || `${selectedPatient.name.toLowerCase().replace(/[^a-z]/g, '')}@example.com`);
                    }}
                    className={`p-3 rounded-xl border text-left font-bold flex items-center gap-2 transition-all cursor-pointer ${
                      sendChannel === 'email'
                        ? 'bg-blue-50 border-blue-600 text-blue-900 shadow-2xs'
                        : 'bg-stone-50 border-stone-200 text-stone-700 hover:bg-stone-100'
                    }`}
                  >
                    <Mail className={`w-4 h-4 ${sendChannel === 'email' ? 'text-blue-600' : 'text-stone-400'}`} />
                    <span>Email Address</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setSendChannel('sms');
                      setSendRecipient(selectedPatient.phone || '(310) 555-0199');
                    }}
                    className={`p-3 rounded-xl border text-left font-bold flex items-center gap-2 transition-all cursor-pointer ${
                      sendChannel === 'sms'
                        ? 'bg-teal-50 border-teal-600 text-teal-900 shadow-2xs'
                        : 'bg-stone-50 border-stone-200 text-stone-700 hover:bg-stone-100'
                    }`}
                  >
                    <Smartphone className={`w-4 h-4 ${sendChannel === 'sms' ? 'text-teal-600' : 'text-stone-400'}`} />
                    <span>SMS Text Message</span>
                  </button>
                </div>
              </div>

              {/* Recipient Input */}
              <div className="space-y-1.5">
                <label className="font-bold text-stone-900 block">
                  {sendChannel === 'email' ? 'Patient Email Recipient' : 'Patient Mobile Phone Number'}
                </label>
                <input
                  type={sendChannel === 'email' ? 'email' : 'tel'}
                  value={sendRecipient}
                  onChange={(e) => setSendRecipient(e.target.value)}
                  placeholder={sendChannel === 'email' ? 'patient@example.com' : '(310) 555-0199'}
                  className="w-full p-3 bg-stone-50 border border-stone-300 rounded-xl font-medium text-stone-900 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              {/* Shareable Link Preview */}
              <div className="space-y-1">
                <label className="font-bold text-stone-700 text-[11px] block">Generated Portal Link</label>
                <div className="p-2.5 bg-stone-100 border border-stone-200 rounded-xl font-mono text-[10.5px] text-stone-600 break-all flex items-center justify-between gap-2">
                  <span className="truncate">
                    https://portal.summitsurgical.com/intake?forms={selectedIntakeFormIds.join(',')}&patient={selectedPatient.patientId || '113561'}
                  </span>
                  <button
                    type="button"
                    onClick={() => navigator.clipboard.writeText(`https://portal.summitsurgical.com/intake?forms=${selectedIntakeFormIds.join(',')}&patient=${selectedPatient.patientId || '113561'}`)}
                    className="px-2 py-1 bg-white hover:bg-stone-200 border border-stone-300 text-stone-800 font-bold text-[10px] rounded shrink-0 cursor-pointer"
                  >
                    Copy
                  </button>
                </div>
              </div>
            </div>

            {/* Modal Actions */}
            <div className="p-4 bg-stone-50 border-t border-stone-200 flex items-center justify-end gap-3">
              <button
                type="button"
                onClick={() => setSendFormModalItem(null)}
                className="px-4 py-2 bg-white hover:bg-stone-100 text-stone-700 font-bold rounded-xl border border-stone-300 text-xs transition-colors cursor-pointer"
              >
                Cancel
              </button>

              <button
                type="button"
                disabled={selectedIntakeFormIds.length === 0}
                onClick={() => {
                  const newStatus = sendChannel === 'email' ? 'Sent via Email' : 'Sent via SMS';
                  const dateStr = new Date().toLocaleDateString('en-US', { month: 'short', day: '2-digit', year: 'numeric' });
                  const selectedForms = intakeFormsList.filter((f) => selectedIntakeFormIds.includes(f.id));
                  setIntakeFormsList((prev) =>
                    prev.map((f) => (selectedIntakeFormIds.includes(f.id) ? { ...f, status: newStatus, lastSentDate: dateStr } : f))
                  );
                  const namesList = selectedForms.map((f) => f.title).join(', ');
                  setPreOpEmailSuccessToast(
                    `Link for form(s) "${namesList || 'Selected Forms'}" sent via ${sendChannel.toUpperCase()} to ${sendRecipient || 'patient'}!`
                  );
                  setSendFormModalItem(null);
                }}
                className="px-5 py-2 bg-blue-600 hover:bg-blue-700 disabled:bg-stone-300 disabled:cursor-not-allowed text-white font-bold rounded-xl text-xs shadow-md transition-colors cursor-pointer flex items-center gap-1.5"
              >
                <Send className="w-3.5 h-3.5" />
                <span>Send {sendChannel === 'email' ? 'Email' : 'SMS'} Link ({selectedIntakeFormIds.length})</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 3. Patient Portal Form Completion Simulation Modal */}
      {portalHtmlForm && (
        <div className="fixed inset-0 z-[99999] bg-stone-100 flex flex-col w-screen h-screen overflow-y-auto animate-in fade-in duration-150">
          {/* Floating Corner Close Button */}
          <button
            type="button"
            onClick={() => setPortalHtmlForm(null)}
            className="fixed top-4 right-6 z-[100000] px-4 py-2.5 bg-stone-900/95 hover:bg-stone-900 text-white font-bold text-xs rounded-xl shadow-2xl transition-all cursor-pointer border border-stone-700/80 backdrop-blur-md flex items-center gap-2 group"
          >
            <X className="w-4 h-4 text-stone-300 group-hover:text-white transition-colors" />
            <span>Close Form</span>
          </button>

          {/* Blank Page Native Form Container */}
          <div className="w-full flex-1 bg-stone-100 p-2 sm:p-6 flex justify-center items-start min-h-screen overflow-x-hidden">
            <div className="w-full max-w-3xl bg-white rounded-2xl shadow-xl border border-stone-200 p-3 sm:p-6 my-2 sm:my-4 relative overflow-x-hidden">
              <style>{`
                .page { max-width: 100% !important; margin: 0 auto !important; box-shadow: none !important; border: none !important; padding: 12px 16px !important; }
                .grid { max-width: 100% !important; }
                table { max-width: 100% !important; width: 100% !important; }
              `}</style>
              <div dangerouslySetInnerHTML={{ __html: portalHtmlForm.htmlTemplate }} />
            </div>
          </div>
        </div>
      )}

      {/* 3.5 Note Form Viewer Modal (Blank page with ONLY a close button, NO iframe) */}
      {viewingNoteForm && (
        <div className="fixed inset-0 z-[99999] bg-stone-100 flex flex-col w-screen h-screen overflow-y-auto animate-in fade-in duration-150">
          {/* Floating Corner Close Button — Just a close button and NO header or navigation! */}
          <button
            type="button"
            onClick={() => setViewingNoteForm(null)}
            className="fixed top-4 right-6 z-[100000] px-4 py-2.5 bg-stone-900/95 hover:bg-stone-900 text-white font-bold text-xs rounded-xl shadow-2xl transition-all cursor-pointer border border-stone-700/80 backdrop-blur-md flex items-center gap-2 group"
          >
            <X className="w-4 h-4 text-stone-300 group-hover:text-white transition-colors" />
            <span>Close Form</span>
          </button>

          {/* Blank Page Native Form Container */}
          <div className="w-full flex-1 bg-stone-100 p-2 sm:p-6 flex justify-center items-start min-h-screen overflow-x-hidden">
            <div className="w-full max-w-3xl bg-white rounded-2xl shadow-xl border border-stone-200 p-3 sm:p-6 my-2 sm:my-4 relative overflow-x-hidden">
              <style>{`
                .page { max-width: 100% !important; margin: 0 auto !important; box-shadow: none !important; border: none !important; padding: 12px 16px !important; }
                .grid { max-width: 100% !important; }
                table { max-width: 100% !important; width: 100% !important; }
              `}</style>
              <div dangerouslySetInnerHTML={{ __html: viewingNoteForm.htmlTemplate }} />
            </div>
          </div>
        </div>
      )}

      {/* 3.6 & 3.7 Nursing Form View / Open (Blank page with ONLY a close button, NO iframe) */}
      {(editingNursingForm || viewingFullNursingForm) && (
        <div className="fixed inset-0 z-[99999] bg-stone-100 flex flex-col w-screen h-screen overflow-y-auto animate-in fade-in duration-150">
          {/* Floating Corner Close Button — Just a close button and NO header or navigation! */}
          <button
            type="button"
            onClick={() => {
              setEditingNursingForm(null);
              setViewingFullNursingForm(null);
            }}
            className="fixed top-4 right-6 z-[100000] px-4 py-2.5 bg-stone-900/95 hover:bg-stone-900 text-white font-bold text-xs rounded-xl shadow-2xl transition-all cursor-pointer border border-stone-700/80 backdrop-blur-md flex items-center gap-2 group"
          >
            <X className="w-4 h-4 text-stone-300 group-hover:text-white transition-colors" />
            <span>Close Form</span>
          </button>

          {/* Blank Page Native Form Container */}
          <div className="w-full flex-1 bg-stone-100 p-2 sm:p-6 flex justify-center items-start min-h-screen overflow-x-hidden">
            <div className="w-full max-w-3xl bg-white rounded-2xl shadow-xl border border-stone-200 p-3 sm:p-6 my-2 sm:my-4 relative overflow-x-hidden">
              <style>{`
                .page { max-width: 100% !important; margin: 0 auto !important; box-shadow: none !important; border: none !important; padding: 12px 16px !important; }
                .grid { max-width: 100% !important; }
                table { max-width: 100% !important; width: 100% !important; }
              `}</style>
              <div dangerouslySetInnerHTML={{ __html: (editingNursingForm || viewingFullNursingForm)!.htmlTemplate }} />
            </div>
          </div>
        </div>
      )}

      {/* 4. Upload New Intake Form Modal */}
      {isUploadIntakeModalOpen && (
        <div className="fixed inset-0 z-[120] bg-stone-900/80 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in duration-200">
          <div className="bg-white rounded-2xl max-w-xl w-full shadow-2xl border border-stone-200 overflow-hidden">
            {/* Header */}
            <div className="p-5 bg-gradient-to-r from-stone-900 to-indigo-950 text-white flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2.5 bg-indigo-500/20 rounded-xl border border-indigo-400/30 text-indigo-300">
                  <Upload className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-base text-white">Upload New Intake Form</h3>
                  <p className="text-xs text-stone-300">Add custom pre-op form to patient registration packet</p>
                </div>
              </div>

              <button
                onClick={() => setIsUploadIntakeModalOpen(false)}
                className="p-1.5 rounded-lg bg-stone-800 hover:bg-stone-700 text-stone-300 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Form Body */}
            <form
              onSubmit={(e) => {
                e.preventDefault();
                if (!uploadFormTitle.trim()) return;
                const newForm: IntakeHtmlForm = {
                  id: `form-custom-${Date.now()}`,
                  order: intakeFormsList.length + 1,
                  title: uploadFormTitle.trim(),
                  category: uploadFormCategory,
                  type: 'Interactive HTML Intake Form',
                  targetAudience: uploadFormAudience.trim() || 'Patient',
                  status: 'Pending Send',
                  fileName: `${uploadFormTitle.trim().replace(/\s+/g, '_')}.html`,
                  summary: `Custom uploaded intake form for category ${uploadFormCategory}.`,
                  description: `Uploaded custom intake document for ${uploadFormTitle}.`,
                  htmlTemplate: uploadFormContent || `<!DOCTYPE html><html><head><title>${uploadFormTitle}</title><style>body{font-family:serif;padding:30px;line-height:1.6;}</style></head><body><h2>${uploadFormTitle}</h2><p>Custom intake form for patient ${selectedPatient.name}.</p><label>Signature: </label><input type="text" placeholder="Type full name" /></body></html>`
                };

                setIntakeFormsList((prev) => [...prev, newForm]);
                setUploadFormTitle('');
                setUploadFormContent('');
                setIsUploadIntakeModalOpen(false);
                setPreOpEmailSuccessToast(`New intake form "${newForm.title}" uploaded successfully!`);
              }}
              className="p-6 space-y-4 text-xs text-stone-800"
            >
              <div className="space-y-1">
                <label className="font-bold text-stone-900 block">Form Title *</label>
                <input
                  type="text"
                  required
                  value={uploadFormTitle}
                  onChange={(e) => setUploadFormTitle(e.target.value)}
                  placeholder="e.g. Consent for Photography & Surgical Recording"
                  className="w-full p-3 bg-stone-50 border border-stone-300 rounded-xl font-medium focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="font-bold text-stone-900 block">Category *</label>
                  <select
                    value={uploadFormCategory}
                    onChange={(e) => setUploadFormCategory(e.target.value as any)}
                    className="w-full p-3 bg-stone-50 border border-stone-300 rounded-xl font-medium focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  >
                    <option value="Admission">1. Admission</option>
                    <option value="Insurance">2. Insurance</option>
                    <option value="Medical">3. Medical</option>
                    <option value="Anesthesia">4. Anesthesia</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="font-bold text-stone-900 block">Target Audience</label>
                  <input
                    type="text"
                    value={uploadFormAudience}
                    onChange={(e) => setUploadFormAudience(e.target.value)}
                    placeholder="e.g. Patient / Guarantor"
                    className="w-full p-3 bg-stone-50 border border-stone-300 rounded-xl font-medium focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="font-bold text-stone-900 block">HTML Form Template / Content</label>
                <textarea
                  rows={4}
                  value={uploadFormContent}
                  onChange={(e) => setUploadFormContent(e.target.value)}
                  placeholder="Paste HTML markup or leave blank to auto-generate standard template..."
                  className="w-full p-3 bg-stone-50 border border-stone-300 rounded-xl font-mono text-[11px] focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              {/* Modal Footer */}
              <div className="pt-3 border-t border-stone-200 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setIsUploadIntakeModalOpen(false)}
                  className="px-4 py-2 bg-white hover:bg-stone-100 text-stone-700 font-bold rounded-xl border border-stone-300 transition-colors cursor-pointer"
                >
                  Cancel
                </button>

                <button
                  type="submit"
                  className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl shadow-md transition-colors cursor-pointer flex items-center gap-1.5"
                >
                  <Plus className="w-4 h-4" />
                  <span>Upload Form</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* BLANK PATIENT INVOICE TEMPLATE MODAL */}
      {isBlankInvoiceModalOpen && (
        <div className="fixed inset-0 z-[120] bg-slate-950/80 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto animate-in fade-in duration-200">
          <div className="bg-white rounded-3xl max-w-3xl w-full p-6 sm:p-8 shadow-2xl border border-stone-300 space-y-6 my-8">
            
            {/* Modal Header Actions */}
            <div className="flex items-center justify-between border-b border-stone-200 pb-4">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-indigo-50 text-indigo-600 rounded-xl border border-indigo-200">
                  <FileText className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-base text-stone-900">Blank Patient Invoice & Financial Statement</h3>
                  <p className="text-xs text-stone-500 font-medium">Standard Itemized Medical Invoice Form</p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => window.print()}
                  className="px-3 py-1.5 bg-stone-100 hover:bg-stone-200 text-stone-800 font-bold text-xs rounded-xl border border-stone-300 flex items-center gap-1.5 cursor-pointer transition-colors"
                >
                  <Printer className="w-4 h-4" />
                  <span>Print Blank Template</span>
                </button>
                <button
                  onClick={() => setIsBlankInvoiceModalOpen(false)}
                  className="p-1.5 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-600 cursor-pointer transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Editable Blank Invoice Printable Canvas */}
            <div className="p-6 bg-white border-2 border-stone-200 rounded-2xl shadow-2xs font-sans space-y-6 text-stone-900">
              
              {/* Header Letterhead */}
              <div className="flex flex-wrap justify-between items-start border-b-2 border-stone-900 pb-6 gap-4">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <Building2 className="w-6 h-6 text-indigo-700" />
                    <span className="font-black text-xl tracking-tight text-stone-900 uppercase">Summit Surgical Center LLC</span>
                  </div>
                  <div className="text-xs text-stone-600 font-medium leading-relaxed">
                    9400 Wilshire Blvd, Suite 800<br />
                    Beverly Hills, CA 90212<br />
                    Phone: (310) 858-3000 · Tax ID: 95-4819201 · NPI: 1982736450
                  </div>
                </div>

                <div className="text-right space-y-1">
                  <div className="font-black text-lg text-indigo-950 tracking-wider">ITEMIZED INVOICE STATEMENT</div>
                  <div className="font-mono text-xs font-bold text-stone-700">
                    Invoice #: <input
                      type="text"
                      value={blankInvoiceData.invoiceNumber}
                      onChange={(e) => setBlankInvoiceData({ ...blankInvoiceData, invoiceNumber: e.target.value })}
                      className="border-b border-dashed border-stone-400 text-indigo-600 font-bold focus:outline-none w-32 px-1"
                    />
                  </div>
                  <div className="font-mono text-xs text-stone-600">
                    Invoice Date: <input
                      type="date"
                      value={blankInvoiceData.invoiceDate}
                      onChange={(e) => setBlankInvoiceData({ ...blankInvoiceData, invoiceDate: e.target.value })}
                      className="border-b border-dashed border-stone-400 focus:outline-none px-1"
                    />
                  </div>
                  <div className="font-mono text-xs text-stone-600">
                    Due Date: <input
                      type="date"
                      value={blankInvoiceData.dueDate}
                      onChange={(e) => setBlankInvoiceData({ ...blankInvoiceData, dueDate: e.target.value })}
                      className="border-b border-dashed border-stone-400 focus:outline-none px-1"
                    />
                  </div>
                </div>
              </div>

              {/* Patient & Guarantor Inputs */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                <div className="p-3.5 bg-stone-50 rounded-xl border border-stone-200 space-y-2">
                  <div className="font-bold text-stone-400 text-[10px] uppercase tracking-wider">Patient Information</div>
                  <input
                    type="text"
                    placeholder="Patient Full Name..."
                    value={blankInvoiceData.patientName}
                    onChange={(e) => setBlankInvoiceData({ ...blankInvoiceData, patientName: e.target.value })}
                    className="w-full p-2 bg-white border border-stone-300 rounded-lg font-bold text-stone-900"
                  />
                  <div className="grid grid-cols-2 gap-2">
                    <input
                      type="text"
                      placeholder="Patient ID (e.g. p-101)..."
                      value={blankInvoiceData.patientId}
                      onChange={(e) => setBlankInvoiceData({ ...blankInvoiceData, patientId: e.target.value })}
                      className="p-1.5 bg-white border border-stone-300 rounded-lg font-mono"
                    />
                    <input
                      type="text"
                      placeholder="DOB (MM/DD/YYYY)..."
                      value={blankInvoiceData.dob}
                      onChange={(e) => setBlankInvoiceData({ ...blankInvoiceData, dob: e.target.value })}
                      className="p-1.5 bg-white border border-stone-300 rounded-lg font-mono"
                    />
                  </div>
                </div>

                <div className="p-3.5 bg-stone-50 rounded-xl border border-stone-200 space-y-2">
                  <div className="font-bold text-stone-400 text-[10px] uppercase tracking-wider">Responsible Guarantor</div>
                  <input
                    type="text"
                    placeholder="Guarantor Name (Self / Parent)..."
                    value={blankInvoiceData.guarantor}
                    onChange={(e) => setBlankInvoiceData({ ...blankInvoiceData, guarantor: e.target.value })}
                    className="w-full p-2 bg-white border border-stone-300 rounded-lg font-bold text-stone-900"
                  />
                  <div className="flex items-center gap-2">
                    <span className="font-medium text-stone-600">DOS:</span>
                    <input
                      type="date"
                      value={blankInvoiceData.dos}
                      onChange={(e) => setBlankInvoiceData({ ...blankInvoiceData, dos: e.target.value })}
                      className="p-1.5 bg-white border border-stone-300 rounded-lg font-mono text-stone-900"
                    />
                  </div>
                </div>
              </div>

              {/* Procedure & Clinical Banner */}
              <div className="p-3 bg-stone-50 rounded-xl border border-stone-200 text-xs grid grid-cols-1 md:grid-cols-3 gap-2">
                <div>
                  <label className="font-bold text-stone-600 text-[10px] block uppercase">Procedure</label>
                  <input
                    type="text"
                    placeholder="Surgical Procedure Description..."
                    value={blankInvoiceData.procedure}
                    onChange={(e) => setBlankInvoiceData({ ...blankInvoiceData, procedure: e.target.value })}
                    className="w-full p-1.5 bg-white border border-stone-300 rounded-lg font-medium"
                  />
                </div>
                <div>
                  <label className="font-bold text-stone-600 text-[10px] block uppercase">Surgeon</label>
                  <input
                    type="text"
                    value={blankInvoiceData.surgeon}
                    onChange={(e) => setBlankInvoiceData({ ...blankInvoiceData, surgeon: e.target.value })}
                    className="w-full p-1.5 bg-white border border-stone-300 rounded-lg font-medium"
                  />
                </div>
                <div>
                  <label className="font-bold text-stone-600 text-[10px] block uppercase">Anesthesiologist</label>
                  <input
                    type="text"
                    value={blankInvoiceData.anesthesiologist}
                    onChange={(e) => setBlankInvoiceData({ ...blankInvoiceData, anesthesiologist: e.target.value })}
                    className="w-full p-1.5 bg-white border border-stone-300 rounded-lg font-medium"
                  />
                </div>
              </div>

              {/* Itemized Services Grid */}
              <div className="space-y-2">
                <div className="font-bold text-xs text-stone-900 uppercase tracking-wider">Itemized Medical Charges ($)</div>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3 text-xs">
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-stone-600 uppercase">Facility Fee ($)</label>
                    <input
                      type="number"
                      value={blankInvoiceData.facilityFee}
                      onChange={(e) => setBlankInvoiceData({ ...blankInvoiceData, facilityFee: parseFloat(e.target.value) || 0 })}
                      className="w-full p-2 bg-stone-50 border border-stone-300 rounded-lg font-mono font-bold text-stone-900"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-stone-600 uppercase">Surgeon Fee ($)</label>
                    <input
                      type="number"
                      value={blankInvoiceData.surgeonFee}
                      onChange={(e) => setBlankInvoiceData({ ...blankInvoiceData, surgeonFee: parseFloat(e.target.value) || 0 })}
                      className="w-full p-2 bg-stone-50 border border-stone-300 rounded-lg font-mono font-bold text-stone-900"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-stone-600 uppercase">Anesthesia Fee ($)</label>
                    <input
                      type="number"
                      value={blankInvoiceData.anesthesiaFee}
                      onChange={(e) => setBlankInvoiceData({ ...blankInvoiceData, anesthesiaFee: parseFloat(e.target.value) || 0 })}
                      className="w-full p-2 bg-stone-50 border border-stone-300 rounded-lg font-mono font-bold text-stone-900"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-stone-600 uppercase">Implants & Supplies ($)</label>
                    <input
                      type="number"
                      value={blankInvoiceData.implantCharges}
                      onChange={(e) => setBlankInvoiceData({ ...blankInvoiceData, implantCharges: parseFloat(e.target.value) || 0 })}
                      className="w-full p-2 bg-stone-50 border border-stone-300 rounded-lg font-mono font-bold text-stone-900"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-emerald-700 uppercase">Prompt Discount ($)</label>
                    <input
                      type="number"
                      value={blankInvoiceData.discounts}
                      onChange={(e) => setBlankInvoiceData({ ...blankInvoiceData, discounts: parseFloat(e.target.value) || 0 })}
                      className="w-full p-2 bg-emerald-50 border border-emerald-300 rounded-lg font-mono font-bold text-emerald-800"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-blue-800 uppercase">Payments Received ($)</label>
                    <input
                      type="number"
                      value={blankInvoiceData.paymentsReceived}
                      onChange={(e) => setBlankInvoiceData({ ...blankInvoiceData, paymentsReceived: parseFloat(e.target.value) || 0 })}
                      className="w-full p-2 bg-blue-50 border border-blue-300 rounded-lg font-mono font-bold text-blue-900"
                    />
                  </div>
                </div>
              </div>

              {/* Total Calculation */}
              <div className="flex justify-end pt-2">
                <div className="w-full md:w-80 bg-stone-900 text-white p-4 rounded-xl border border-stone-800 text-xs space-y-2 font-mono">
                  <div className="flex justify-between">
                    <span className="text-stone-400 font-sans">Gross Charges:</span>
                    <span className="font-bold">${(blankInvoiceData.facilityFee + blankInvoiceData.surgeonFee + blankInvoiceData.anesthesiaFee + blankInvoiceData.implantCharges).toLocaleString()}</span>
                  </div>
                  {blankInvoiceData.discounts > 0 && (
                    <div className="flex justify-between text-emerald-400">
                      <span className="font-sans">Prompt Discount:</span>
                      <span>-${blankInvoiceData.discounts.toLocaleString()}</span>
                    </div>
                  )}
                  {blankInvoiceData.paymentsReceived > 0 && (
                    <div className="flex justify-between text-sky-400">
                      <span className="font-sans">Payments Received:</span>
                      <span>-${blankInvoiceData.paymentsReceived.toLocaleString()}</span>
                    </div>
                  )}
                  <div className="flex justify-between pt-2 border-t border-slate-700 text-base font-black text-emerald-400">
                    <span className="font-sans">NET BALANCE DUE:</span>
                    <span>${Math.max(0, (blankInvoiceData.facilityFee + blankInvoiceData.surgeonFee + blankInvoiceData.anesthesiaFee + blankInvoiceData.implantCharges) - blankInvoiceData.discounts - blankInvoiceData.paymentsReceived).toLocaleString()}</span>
                  </div>
                </div>
              </div>

            </div>

            {/* Bottom Actions */}
            <div className="flex justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setIsBlankInvoiceModalOpen(false)}
                className="px-4 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 font-bold text-xs rounded-xl transition-colors cursor-pointer"
              >
                Close
              </button>
              <button
                type="button"
                onClick={() => {
                  window.print();
                }}
                className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-xl shadow-md transition-colors cursor-pointer flex items-center gap-1.5"
              >
                <Printer className="w-4 h-4" />
                <span>Print Statement</span>
              </button>
            </div>

          </div>
        </div>
      )}

      {/* CREATE NEW INVOICE MODAL (ENABLED WHEN PAYMENT NOT YET RECEIVED) */}
      {isCreateInvoiceModalOpen && (
        <div className="fixed inset-0 z-[120] bg-slate-950/80 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto animate-in fade-in duration-200">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-stone-300 space-y-5 my-8">
            <div className="flex items-center justify-between border-b border-stone-200 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-indigo-50 text-indigo-600 rounded-xl border border-indigo-200">
                  <Plus className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-base text-stone-900">Create New Patient Invoice</h3>
                  <p className="text-xs text-stone-500 font-medium">Issue itemized statement for outstanding surgical encounter</p>
                </div>
              </div>
              <button
                onClick={() => setIsCreateInvoiceModalOpen(false)}
                className="p-1.5 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-600 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form
              onSubmit={(e) => {
                e.preventDefault();
                const totalCalculated = (newInvoiceForm.facilityFee + newInvoiceForm.surgeonFee + newInvoiceForm.anesthesiaFee + newInvoiceForm.implantCharges) - newInvoiceForm.discounts;
                const isPaid = newInvoiceForm.paymentReceivedAmount >= totalCalculated;

                setPatientPayments((prev) => ({
                  ...prev,
                  [selectedPatient.patientId]: {
                    patientId: selectedPatient.patientId,
                    source: newInvoiceForm.source,
                    received: isPaid,
                    amount: totalCalculated,
                    date: isPaid ? newInvoiceForm.paymentDate : '',
                    method: isPaid ? 'Credit Card / Recorded Payment' : 'Pending Patient Payment',
                    notes: newInvoiceForm.notes || `Invoice generated for ${selectedPatient.name}. Balance: $${totalCalculated.toLocaleString()}`,
                    invoiceNumber: `INV-2026-${Math.floor(100 + Math.random() * 900)}`,
                  },
                }));

                setIsCreateInvoiceModalOpen(false);
                alert(`New invoice created successfully for ${selectedPatient.name}!`);
              }}
              className="space-y-4 text-xs"
            >
              <div className="p-3 bg-stone-50 rounded-xl border border-stone-200 space-y-1">
                <div><strong>Patient:</strong> {selectedPatient.name} ({selectedPatient.patientId})</div>
                <div><strong>Procedure:</strong> {selectedPatient.procedure}</div>
                <div><strong>Surgeon:</strong> {selectedPatient.surgeon}</div>
              </div>

              <div className="space-y-1">
                <label className="font-bold text-stone-700 block">Payment Source Classification *</label>
                <select
                  value={newInvoiceForm.source}
                  onChange={(e) => setNewInvoiceForm({ ...newInvoiceForm, source: e.target.value as any })}
                  className="w-full p-2.5 bg-stone-50 border border-stone-300 rounded-xl font-bold text-stone-900 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                >
                  <option value="self-pay">💳 Self-Pay (Patient Direct Cash)</option>
                  <option value="doctor-to-pay">🩺 Doctor to Pay (Professional Courtesy)</option>
                  <option value="insurance">🛡️ Insurance (Commercial PPO / Medicare)</option>
                  <option value="other">📋 Other (Lien / Workers' Comp)</option>
                </select>
              </div>

              <div className="p-3.5 bg-stone-50 rounded-2xl border border-stone-200 space-y-2">
                <div className="font-bold text-stone-900 border-b border-stone-200 pb-1">Itemized Financial Breakdown ($)</div>
                <div className="grid grid-cols-2 gap-2">
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-stone-600 uppercase">Facility Fee ($)</label>
                    <input
                      type="number"
                      value={newInvoiceForm.facilityFee}
                      onChange={(e) => setNewInvoiceForm({ ...newInvoiceForm, facilityFee: parseFloat(e.target.value) || 0 })}
                      className="w-full p-2 bg-white border border-stone-300 rounded-lg font-mono font-bold text-stone-900"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-stone-600 uppercase">Surgeon Fee ($)</label>
                    <input
                      type="number"
                      value={newInvoiceForm.surgeonFee}
                      onChange={(e) => setNewInvoiceForm({ ...newInvoiceForm, surgeonFee: parseFloat(e.target.value) || 0 })}
                      className="w-full p-2 bg-white border border-stone-300 rounded-lg font-mono font-bold text-stone-900"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-stone-600 uppercase">Anesthesia Fee ($)</label>
                    <input
                      type="number"
                      value={newInvoiceForm.anesthesiaFee}
                      onChange={(e) => setNewInvoiceForm({ ...newInvoiceForm, anesthesiaFee: parseFloat(e.target.value) || 0 })}
                      className="w-full p-2 bg-white border border-stone-300 rounded-lg font-mono font-bold text-stone-900"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-stone-600 uppercase">Implants & Supplies ($)</label>
                    <input
                      type="number"
                      value={newInvoiceForm.implantCharges}
                      onChange={(e) => setNewInvoiceForm({ ...newInvoiceForm, implantCharges: parseFloat(e.target.value) || 0 })}
                      className="w-full p-2 bg-white border border-stone-300 rounded-lg font-mono font-bold text-stone-900"
                    />
                  </div>
                </div>

                <div className="pt-2 border-t border-stone-200 flex justify-between items-center font-bold text-indigo-950">
                  <span>Calculated Invoice Total:</span>
                  <span className="font-mono text-sm font-black">${((newInvoiceForm.facilityFee + newInvoiceForm.surgeonFee + newInvoiceForm.anesthesiaFee + newInvoiceForm.implantCharges) - newInvoiceForm.discounts).toLocaleString()}</span>
                </div>
              </div>

              <div className="space-y-1">
                <label className="font-bold text-stone-700 block">Record Payment Received Now ($ optional)</label>
                <input
                  type="number"
                  placeholder="Leave 0 if payment is pending..."
                  value={newInvoiceForm.paymentReceivedAmount}
                  onChange={(e) => setNewInvoiceForm({ ...newInvoiceForm, paymentReceivedAmount: parseFloat(e.target.value) || 0 })}
                  className="w-full p-2.5 bg-stone-50 border border-stone-300 rounded-xl font-mono text-stone-900"
                />
              </div>

              <div className="space-y-1">
                <label className="font-bold text-stone-700 block">Billing Notes</label>
                <input
                  type="text"
                  placeholder="e.g. Pre-op payment arrangement confirmed..."
                  value={newInvoiceForm.notes}
                  onChange={(e) => setNewInvoiceForm({ ...newInvoiceForm, notes: e.target.value })}
                  className="w-full p-2.5 bg-stone-50 border border-stone-300 rounded-xl font-medium text-stone-900"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-stone-200">
                <button
                  type="button"
                  onClick={() => setIsCreateInvoiceModalOpen(false)}
                  className="px-4 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 font-bold text-xs rounded-xl transition-colors cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-xl shadow-md transition-colors cursor-pointer flex items-center gap-1.5"
                >
                  <Plus className="w-4 h-4" />
                  <span>Generate & Save Invoice</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Deletion Confirmation Modal */}
      {deleteConfirmation && (
        <div className="fixed inset-0 bg-stone-900/80 backdrop-blur-xs flex items-center justify-center z-[100002] p-4 animate-in fade-in duration-150">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 border border-stone-200 shadow-2xl space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-rose-100 border border-rose-200 text-rose-600 flex items-center justify-center shrink-0">
                <Trash2 className="w-5 h-5 text-rose-600" />
              </div>
              <div>
                <h3 className="text-base font-extrabold text-stone-900">
                  Confirm {deleteConfirmation.type} Deletion
                </h3>
                <p className="text-xs text-stone-500 font-medium">
                  Please confirm before deleting this record.
                </p>
              </div>
            </div>

            <div className="p-3.5 bg-rose-50/80 border border-rose-200/90 rounded-xl space-y-1.5 text-xs text-stone-800">
              <div className="font-extrabold text-rose-950 flex items-center justify-between">
                <span>{deleteConfirmation.type} Name:</span>
                <span className="text-stone-900 font-bold truncate max-w-[200px]">{deleteConfirmation.name}</span>
              </div>
              {deleteConfirmation.details && (
                <div className="text-[11px] text-stone-600 pt-1 border-t border-rose-200/60 font-medium">
                  {deleteConfirmation.details}
                </div>
              )}
            </div>

            <p className="text-xs text-stone-500 leading-relaxed font-medium">
              ⚠️ <strong>Warning:</strong> Deleting this {deleteConfirmation.type.toLowerCase()} will permanently remove it from {selectedPatient.name}'s chart. This action cannot be undone.
            </p>

            <div className="pt-2 flex items-center justify-end gap-2.5">
              <button
                type="button"
                onClick={() => setDeleteConfirmation(null)}
                className="px-4 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 font-bold text-xs rounded-xl border border-stone-200 transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => {
                  deleteConfirmation.action();
                  setDeleteConfirmation(null);
                }}
                className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs rounded-xl shadow-md transition-colors flex items-center gap-1.5 cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Confirm Delete {deleteConfirmation.type}</span>
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
