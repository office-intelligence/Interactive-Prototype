import React, { useState } from 'react';
import { 
  Sparkles, 
  Zap, 
  AlertTriangle, 
  CheckCircle2, 
  Clock, 
  Activity, 
  Users, 
  Calendar, 
  TrendingUp, 
  FileText, 
  ShieldCheck, 
  ArrowRight, 
  RefreshCw, 
  ChevronRight,
  Filter,
  Sliders,
  DollarSign,
  Stethoscope,
  Maximize2
} from 'lucide-react';
import { PatientCase } from '../types';

interface AIHomePageProps {
  cases: PatientCase[];
  onSelectPatient: (patient: PatientCase) => void;
  onTriggerEKGFastTrack: (caseId: string) => void;
  onUpdateStage: (caseId: string, newStage: any) => void;
  onShowToast: (msg: string) => void;
  onNavigateTab: (tab: string) => void;
}

export const AIHomePage: React.FC<AIHomePageProps> = ({
  cases,
  onSelectPatient,
  onTriggerEKGFastTrack,
  onUpdateStage,
  onShowToast,
  onNavigateTab
}) => {
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [filterType, setFilterType] = useState<'ALL' | 'HOLDS' | 'CLEARED'>('ALL');
  const [selectedAIInsight, setSelectedAIInsight] = useState<string | null>(null);

  // Compute metrics
  const totalCases = cases.length;
  const clearedCases = cases.filter(c => c.readinessLevel === 'CLEARED').length;
  const holdCases = cases.filter(c => c.readinessLevel === 'NEEDS_ATTENTION' || c.readinessLevel === 'CRITICAL_HOLD').length;
  const avgReadiness = Math.round(cases.reduce((acc, c) => acc + c.readinessScore, 0) / (totalCases || 1));

  const filteredCases = cases.filter(c => {
    if (filterType === 'HOLDS') return c.readinessLevel !== 'CLEARED';
    if (filterType === 'CLEARED') return c.readinessLevel === 'CLEARED';
    return true;
  });

  const handleRunFullAIScan = () => {
    setIsAnalyzing(true);
    onShowToast('Running Nightingale AI Full ASC Operations Scan...');
    
    setTimeout(() => {
      setIsAnalyzing(false);
      onShowToast('✨ AI Scan Complete: 2 schedule optimizations identified, 1 EKG cleared.');
    }, 2000);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      
      {/* Hero Operational Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 p-6 md:p-8 rounded-3xl text-white shadow-xl border border-indigo-900/50 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-10 -left-10 w-80 h-80 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-3 max-w-2xl">
            <div className="flex flex-wrap items-center gap-2">
              <div className="px-3 py-1 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-400/30 text-xs font-bold flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
                <span>Nightingale AI Operational Suite v3.0</span>
              </div>
              <span className="text-xs font-semibold px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                Live ASC Telemetry
              </span>
            </div>

            <h1 className="text-2xl md:text-3xl font-extrabold tracking-tight text-white">
              ASC Operations & Schedule Intelligence
            </h1>

            <p className="text-sm text-slate-300 leading-relaxed">
              Real-time surgical schedule coordination, automated pre-op clearances, OR turnover prediction, and anesthesia risk management powered by Nightingale AI.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
            <button
              onClick={handleRunFullAIScan}
              disabled={isAnalyzing}
              className="px-5 py-3 rounded-2xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-lg shadow-indigo-600/30 transition-all flex items-center justify-center gap-2 cursor-pointer hover:scale-102 active:scale-98"
            >
              {isAnalyzing ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin text-white" />
                  <span>Scanning ASC Schedule...</span>
                </>
              ) : (
                <>
                  <Zap className="w-4 h-4 text-amber-300 fill-amber-300" />
                  <span>Run Full AI Operations Scan</span>
                </>
              )}
            </button>

            <button
              onClick={() => onNavigateTab('workflows')}
              className="px-4 py-3 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs border border-slate-700 transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              <FileText className="w-4 h-4 text-indigo-400" />
              <span>Explore AI Workflows</span>
            </button>
          </div>
        </div>
      </div>

      {/* Metric Cards Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-5 bg-white rounded-2xl border border-stone-200/90 shadow-2xs flex items-center justify-between">
          <div className="space-y-1">
            <span className="text-xs font-medium text-stone-500 block">Total Scheduled Cases</span>
            <span className="text-2xl font-black text-stone-900 block">{totalCases} Cases</span>
            <span className="text-[11px] font-semibold text-stone-500 flex items-center gap-1">
              <Calendar className="w-3 h-3 text-indigo-600" /> Today's OR Board
            </span>
          </div>
          <div className="w-12 h-12 rounded-2xl bg-indigo-50 border border-indigo-100 flex items-center justify-center text-indigo-600 shrink-0">
            <Users className="w-6 h-6" />
          </div>
        </div>

        <div className="p-5 bg-white rounded-2xl border border-stone-200/90 shadow-2xs flex items-center justify-between">
          <div className="space-y-1">
            <span className="text-xs font-medium text-stone-500 block">AI Clearance Index</span>
            <span className="text-2xl font-black text-emerald-700 block">{avgReadiness}% Ready</span>
            <span className="text-[11px] font-semibold text-emerald-600 flex items-center gap-1">
              <ShieldCheck className="w-3 h-3" /> {clearedCases} Fully Cleared
            </span>
          </div>
          <div className="w-12 h-12 rounded-2xl bg-emerald-50 border border-emerald-100 flex items-center justify-center text-emerald-600 shrink-0">
            <CheckCircle2 className="w-6 h-6" />
          </div>
        </div>

        <div className="p-5 bg-white rounded-2xl border border-stone-200/90 shadow-2xs flex items-center justify-between">
          <div className="space-y-1">
            <span className="text-xs font-medium text-stone-500 block">Pre-Op Holds & Alerts</span>
            <span className="text-2xl font-black text-amber-600 block">{holdCases} Holds</span>
            <span className="text-[11px] font-semibold text-amber-700 flex items-center gap-1">
              <AlertTriangle className="w-3 h-3" /> 1 Fast-track EKG hold
            </span>
          </div>
          <div className="w-12 h-12 rounded-2xl bg-amber-50 border border-amber-100 flex items-center justify-center text-amber-600 shrink-0">
            <Clock className="w-6 h-6" />
          </div>
        </div>

        <div className="p-5 bg-white rounded-2xl border border-stone-200/90 shadow-2xs flex items-center justify-between">
          <div className="space-y-1">
            <span className="text-xs font-medium text-stone-500 block">OR Turnover Velocity</span>
            <span className="text-2xl font-black text-indigo-900 block">18 Mins</span>
            <span className="text-[11px] font-semibold text-indigo-600 flex items-center gap-1">
              <TrendingUp className="w-3 h-3" /> +12% faster than target
            </span>
          </div>
          <div className="w-12 h-12 rounded-2xl bg-indigo-50 border border-indigo-100 flex items-center justify-center text-indigo-600 shrink-0">
            <Activity className="w-6 h-6" />
          </div>
        </div>
      </div>

      {/* AI Quick Resolution Hub */}
      <div className="p-6 bg-gradient-to-br from-indigo-900 via-indigo-950 to-slate-900 rounded-3xl text-white shadow-lg space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-amber-300" />
            <h3 className="text-base font-bold text-white">Nightingale AI Action Hub</h3>
          </div>
          <span className="text-xs font-semibold px-2.5 py-1 bg-amber-400/20 text-amber-300 border border-amber-400/30 rounded-full">
            1 High-Priority Action
          </span>
        </div>

        <div className="p-4 bg-indigo-900/80 rounded-2xl border border-indigo-700/80 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2 text-xs font-bold text-amber-300">
              <AlertTriangle className="w-4 h-4" />
              <span>Patricia DePoli (7:30 AM · OR 1) - Missing EKG Report Clearance</span>
            </div>
            <p className="text-xs text-indigo-200">
              Inbound fax received from Beverly Hills Cardiology. AI matched fax to case #228940 with Normal Sinus Rhythm.
            </p>
          </div>

          <button
            onClick={() => {
              onTriggerEKGFastTrack('case-2');
            }}
            className="px-4 py-2.5 bg-amber-400 hover:bg-amber-300 text-slate-950 font-black text-xs rounded-xl shadow-md transition-all flex items-center justify-center gap-1.5 shrink-0 cursor-pointer hover:scale-102"
          >
            <Zap className="w-4 h-4 text-slate-950 fill-slate-950" />
            <span>Fast-Track Clear EKG (Score 72% ➔ 98%)</span>
          </button>
        </div>
      </div>

      {/* Interactive Surgical Board with AI Filter */}
      <div className="bg-white rounded-3xl border border-stone-200/90 shadow-2xs overflow-hidden">
        
        {/* Board Header & Filter controls */}
        <div className="p-5 bg-stone-50/80 border-b border-stone-200/80 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h2 className="text-base font-bold text-stone-900">
              Today's Surgical Board & Readiness Status
            </h2>
            <p className="text-xs text-stone-500 font-medium">
              Click any patient to view chart details or run AI clinical workflows
            </p>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold text-stone-500 flex items-center gap-1">
              <Filter className="w-3.5 h-3.5" /> Filter:
            </span>
            <button
              onClick={() => setFilterType('ALL')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                filterType === 'ALL'
                  ? 'bg-stone-900 text-white shadow-2xs'
                  : 'bg-white text-stone-600 border border-stone-200 hover:bg-stone-100'
              }`}
            >
              All ({cases.length})
            </button>
            <button
              onClick={() => setFilterType('HOLDS')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                filterType === 'HOLDS'
                  ? 'bg-amber-600 text-white shadow-2xs'
                  : 'bg-white text-stone-600 border border-stone-200 hover:bg-stone-100'
              }`}
            >
              Holds ({holdCases})
            </button>
            <button
              onClick={() => setFilterType('CLEARED')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                filterType === 'CLEARED'
                  ? 'bg-emerald-600 text-white shadow-2xs'
                  : 'bg-white text-stone-600 border border-stone-200 hover:bg-stone-100'
              }`}
            >
              Cleared ({clearedCases})
            </button>
          </div>
        </div>

        {/* Patient Table */}
        <div className="divide-y divide-stone-100 overflow-x-auto">
          {filteredCases.map((patient) => {
            const isCleared = patient.readinessLevel === 'CLEARED';
            const isHold = patient.readinessLevel === 'NEEDS_ATTENTION' || patient.readinessLevel === 'CRITICAL_HOLD';

            return (
              <div
                key={patient.id}
                className="p-4 hover:bg-stone-50/90 transition-colors flex flex-col md:flex-row md:items-center justify-between gap-4"
              >
                {/* Patient Info */}
                <div className="flex items-center gap-3.5 min-w-[240px]">
                  <div
                    className={`w-10 h-10 rounded-2xl flex items-center justify-center font-bold text-xs shrink-0 ${
                      isCleared
                        ? 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                        : 'bg-amber-100 text-amber-800 border border-amber-200'
                    }`}
                  >
                    {patient.readinessScore}%
                  </div>

                  <div>
                    <button
                      onClick={() => onSelectPatient(patient)}
                      className="text-sm font-bold text-stone-900 hover:text-indigo-700 text-left transition-colors cursor-pointer flex items-center gap-1.5"
                    >
                      <span>{patient.name}</span>
                      <ChevronRight className="w-3.5 h-3.5 text-stone-400" />
                    </button>
                    <div className="text-xs text-stone-500 font-medium flex items-center gap-2 mt-0.5">
                      <span>ID: #{patient.patientId}</span>
                      <span>·</span>
                      <span>{patient.scheduledTime} ({patient.room})</span>
                    </div>
                  </div>
                </div>

                {/* Procedure & Surgeon */}
                <div className="min-w-[200px] space-y-0.5">
                  <span className="text-xs font-semibold text-stone-800 block truncate max-w-xs">
                    {patient.procedure}
                  </span>
                  <span className="text-[11px] text-stone-500 block font-medium">
                    {patient.surgeon}
                  </span>
                </div>

                {/* AI Summary Brief */}
                <div className="flex-1 max-w-md">
                  <p className="text-xs text-stone-600 bg-stone-100/80 px-3 py-1.5 rounded-xl border border-stone-200/60 leading-relaxed font-medium">
                    <span className="font-bold text-indigo-700">AI Brief: </span>
                    {patient.aiSummary}
                  </p>
                </div>

                {/* Stage Badges & Actions */}
                <div className="flex items-center gap-2 shrink-0">
                  <span
                    className={`px-3 py-1 rounded-full text-xs font-bold border ${
                      isCleared
                        ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                        : 'bg-amber-50 text-amber-800 border-amber-200'
                    }`}
                  >
                    {isCleared ? 'CLEARED FOR OR' : 'PRE-OP HOLD'}
                  </span>

                  <button
                    onClick={() => onSelectPatient(patient)}
                    className="px-3 py-1.5 bg-stone-900 hover:bg-stone-800 text-white font-bold text-xs rounded-xl transition-all cursor-pointer flex items-center gap-1"
                  >
                    <span>View Chart</span>
                    <ArrowRight className="w-3 h-3" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>

      </div>

    </div>
  );
};
