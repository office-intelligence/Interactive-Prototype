import React, { useState } from 'react';
import { 
  PatientCase, 
  PatientStage, 
  ReadinessLevel 
} from '../types';
import { 
  Clock, 
  Sparkles, 
  AlertTriangle, 
  CheckCircle2, 
  ChevronRight, 
  UserCheck, 
  Filter, 
  Layers, 
  Phone, 
  FileSpreadsheet, 
  Activity, 
  Zap, 
  ArrowUpRight, 
  ArrowRight,
  Check, 
  AlertCircle,
  Building2,
  CalendarDays
} from 'lucide-react';

export type ScheduleViewMode = 'PRIORITY' | 'ROOM_FLOW' | 'BOTTLENECKS' | 'PIPELINE';

interface ScheduleIntelligenceBoxProps {
  cases: PatientCase[];
  onSelectPatient: (patient: PatientCase) => void;
  onUpdateStage: (caseId: string, newStage: PatientStage) => void;
  onResolveAction: (caseId: string, actionId: string) => void;
  onTriggerEKGFastTrack: (caseId: string) => void;
  viewMode?: ScheduleViewMode;
  onViewModeChange?: (mode: ScheduleViewMode) => void;
}

export const ScheduleIntelligenceBox: React.FC<ScheduleIntelligenceBoxProps> = ({
  cases,
  onSelectPatient,
  onUpdateStage,
  onResolveAction,
  onTriggerEKGFastTrack,
  viewMode: externalViewMode,
  onViewModeChange,
}) => {
  const [internalViewMode, setInternalViewMode] = useState<ScheduleViewMode>('PRIORITY');
  const viewMode = externalViewMode !== undefined ? externalViewMode : internalViewMode;
  const setViewMode = onViewModeChange || setInternalViewMode;

  const [roomFilter, setRoomFilter] = useState<string>('ALL');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');

  // Filter cases
  const filteredCases = cases.filter((c) => {
    if (roomFilter !== 'ALL' && c.room !== roomFilter) return false;
    if (statusFilter === 'NEEDS_ATTENTION' && c.readinessLevel === 'CLEARED') return false;
    if (statusFilter === 'CLEARED' && c.readinessLevel !== 'CLEARED') return false;
    return true;
  });

  // Sort cases for AI Arrival Priority Mode
  const prioritySortedCases = [...filteredCases].sort((a, b) => {
    // Put Needs Attention / Low Readiness score first
    if (a.readinessLevel === 'NEEDS_ATTENTION' && b.readinessLevel !== 'NEEDS_ATTENTION') return -1;
    if (b.readinessLevel === 'NEEDS_ATTENTION' && a.readinessLevel !== 'NEEDS_ATTENTION') return 1;
    return a.readinessScore - b.readinessScore;
  });

  const getReadinessBadge = (score: number, level: ReadinessLevel) => {
    if (level === 'NEEDS_ATTENTION' || score < 80) {
      return (
        <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-amber-50 text-amber-800 border border-amber-200/90 text-xs font-bold shadow-2xs">
          <AlertTriangle className="w-3.5 h-3.5 text-amber-600" />
          <span>Needs Attention ({score})</span>
        </div>
      );
    }
    return (
      <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-slate-100 text-slate-900 border border-slate-300 text-xs font-bold shadow-2xs">
        <CheckCircle2 className="w-3.5 h-3.5 text-slate-900" />
        <span>Ready for Surgery ({score})</span>
      </div>
    );
  };

  const getStagePill = (stage: PatientStage) => {
    switch (stage) {
      case 'CHECK_IN':
        return (
          <span className="px-2 py-0.5 rounded-md text-[11px] font-semibold bg-amber-100 text-amber-800 border border-amber-200">
            Arrived • Reception
          </span>
        );
      case 'PRE_OP':
        return (
          <span className="px-2 py-0.5 rounded-md text-[11px] font-semibold bg-indigo-100 text-indigo-800 border border-indigo-200">
            In Pre-Op Bay
          </span>
        );
      case 'IN_OR':
        return (
          <span className="px-2 py-0.5 rounded-md text-[11px] font-semibold bg-sky-100 text-sky-800 border border-sky-200 animate-pulse">
            In Surgery (OR)
          </span>
        );
      case 'PACU_RECOVERY':
        return (
          <span className="px-2 py-0.5 rounded-md text-[11px] font-semibold bg-purple-100 text-purple-800 border border-purple-200">
            In PACU Recovery
          </span>
        );
      case 'DISCHARGED':
        return (
          <span className="px-2 py-0.5 rounded-md text-[11px] font-semibold bg-slate-100 text-slate-700 border border-slate-200">
            Discharged
          </span>
        );
      default:
        return (
          <span className="px-2 py-0.5 rounded-md text-[11px] font-semibold bg-slate-100 text-slate-600">
            En Route
          </span>
        );
    }
  };

  return (
    <div className="bg-white/90 rounded-2xl border border-slate-200/90 shadow-xs overflow-hidden">
      
      {/* Box Header Controls */}
      <div className="p-4 px-5 border-b border-stone-200/80 bg-stone-50/60 flex items-center justify-between gap-3">
        {/* Title */}
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-amber-100 border border-amber-200 text-amber-800 flex items-center justify-center font-bold">
            <Zap className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-bold text-stone-900 tracking-tight flex items-center gap-2">
              <span>Surgical Schedule Workflows</span>
              <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-stone-200/80 text-stone-700 border border-stone-300">
                {cases.length} {cases.length === 1 ? 'Case' : 'Cases'}
              </span>
            </h2>
            <p className="text-xs text-stone-500 font-medium">
              AI-prioritized patient arrivals and real-time workflow bottleneck analysis
            </p>
          </div>
        </div>
      </div>

      {/* Filter Toolbar & Quick Actions */}
      <div className="px-5 py-3 border-b border-slate-200/60 bg-slate-50/30 flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex flex-wrap items-center gap-4">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-500 flex items-center gap-1">
              <Filter className="w-3.5 h-3.5" /> Filter Room:
            </span>
            {['ALL', 'OR 1', 'OR 2'].map((room) => (
              <button
                key={room}
                onClick={() => setRoomFilter(room)}
                className={`px-2.5 py-1 rounded-md font-medium transition-colors ${
                  roomFilter === room
                    ? 'bg-blue-600 text-white'
                    : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-100'
                }`}
              >
                {room}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-500">Status:</span>
            <button
              onClick={() => setStatusFilter('ALL')}
              className={`px-2.5 py-1 rounded-md font-medium transition-colors ${
                statusFilter === 'ALL'
                  ? 'bg-blue-600 text-white'
                  : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-100'
              }`}
            >
              All Cases ({cases.length})
            </button>
            <button
              onClick={() => setStatusFilter('NEEDS_ATTENTION')}
              className={`px-2.5 py-1 rounded-md font-semibold transition-colors ${
                statusFilter === 'NEEDS_ATTENTION'
                  ? 'bg-amber-600 text-white'
                  : 'bg-amber-50 text-amber-800 border border-amber-200 hover:bg-amber-100'
              }`}
            >
              Needs Attention (1)
            </button>
          </div>
        </div>
      </div>

      {/* Patient List Content Area */}
      <div className="p-5 space-y-4">
        
        {/* VIEW 1: AI PRIORITY QUEUE (DEFAULT) */}
        {viewMode === 'PRIORITY' && (
          <div className="space-y-4">
            {prioritySortedCases.map((patient, index) => {
              const isNeedsAttention = patient.readinessLevel === 'NEEDS_ATTENTION';
              
              return (
                <div
                  key={patient.id}
                  className={`rounded-2xl p-5 transition-all relative border ${
                    isNeedsAttention
                      ? 'bg-amber-50/60 border-amber-300 shadow-md ring-1 ring-amber-400/30'
                      : 'bg-white border-slate-200/90 hover:border-slate-300 hover:shadow-xs'
                  }`}
                >
                  {/* Top Priority Ribbon */}
                  {isNeedsAttention && (
                    <div className="mb-3 px-3 py-1.5 rounded-xl bg-amber-100/90 border border-amber-300 text-amber-900 text-xs font-semibold flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
                        <span>
                          <strong className="font-bold">AI Priority Alert:</strong> Patricia DePoli has an urgent pending EKG & Photo review. Potential 25 min turnaround delay.
                        </span>
                      </div>
                      <button
                        onClick={() => onTriggerEKGFastTrack(patient.id)}
                        className="px-2.5 py-1 rounded-lg bg-amber-600 hover:bg-amber-700 text-white font-bold text-[11px] shadow-2xs transition-colors shrink-0"
                      >
                        Fast-Track EKG Call
                      </button>
                    </div>
                  )}

                  {/* Main Grid Row */}
                  <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-start">
                    
                    {/* Col 1: Time, Room & Status (3 Cols) */}
                    <div className="lg:col-span-3 space-y-2">
                      <div className="flex items-center gap-2">
                        <span className="text-xl font-black text-slate-900 tracking-tight">
                          {patient.scheduledTime}
                        </span>
                        <span className="px-2 py-0.5 rounded-md bg-blue-600 text-white text-xs font-bold">
                          {patient.room}
                        </span>
                      </div>

                      <div className="flex flex-wrap items-center gap-1.5">
                        {getStagePill(patient.stage)}
                        <span className="text-[11px] font-medium text-slate-500">
                          Arr: {patient.arrivalTime}
                        </span>
                      </div>

                      <div className="text-xs text-slate-500 font-medium">
                        Est. Duration: <strong className="text-slate-800">{patient.estimatedDurationMins} mins</strong>
                      </div>

                      {/* Prominent Allergies under Est. Duration */}
                      <div className="pt-1.5 space-y-1">
                        <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                          Allergies
                        </div>
                        <div className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-bold border shadow-2xs ${
                          patient.allergies.some(a => a.toLowerCase().includes('none') || a.toLowerCase().includes('nkda'))
                            ? 'bg-slate-100 text-slate-700 border-slate-200'
                            : 'bg-rose-100 text-rose-900 border-rose-300 ring-1 ring-rose-300/50'
                        }`}>
                          <AlertCircle className={`w-3.5 h-3.5 shrink-0 ${
                            patient.allergies.some(a => a.toLowerCase().includes('none') || a.toLowerCase().includes('nkda'))
                              ? 'text-slate-500'
                              : 'text-rose-600'
                          }`} />
                          <span>{patient.allergies.join(', ')}</span>
                        </div>
                      </div>
                    </div>

                    {/* Col 2: Patient Info & Procedure (7 Cols - Expanded for Full-Length Procedure) */}
                    <div className="lg:col-span-7 space-y-2">
                      <div className="flex items-center gap-2">
                        <div className="w-8 h-8 rounded-full bg-indigo-100 text-indigo-800 font-bold text-xs flex items-center justify-center shrink-0">
                          {patient.name.split(' ').map((n) => n[0]).join('')}
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <button
                              onClick={() => onSelectPatient(patient)}
                              className="text-sm font-bold text-slate-900 hover:text-indigo-600 hover:underline transition-colors text-left"
                            >
                              {patient.name}
                            </button>
                            <span className="text-xs text-slate-500 font-medium">
                              {patient.age} • {patient.gender}
                            </span>
                          </div>
                          <div className="text-[11px] text-slate-400 font-mono">
                            ID: {patient.patientId} • {patient.phone}
                          </div>
                        </div>
                      </div>

                      {/* Full Length Procedure Text */}
                      <div className="text-xs sm:text-sm font-semibold text-slate-800 pt-0.5 leading-relaxed">
                        <span className="text-slate-500 font-normal">Procedure: </span>
                        {patient.procedure}
                      </div>

                      <div className="text-xs text-slate-600 flex items-center gap-2">
                        <span>Surgeon: <strong className="text-slate-900">{patient.surgeon}</strong></span>
                      </div>
                    </div>

                    {/* Col 3: Action Buttons (2 Cols) */}
                    <div className="lg:col-span-2 flex flex-col justify-end h-full gap-2 pt-1 lg:pt-0 border-t lg:border-t-0 border-slate-200/60">
                      <button
                        onClick={() => onSelectPatient(patient)}
                        className="group w-full py-2.5 px-3 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold flex items-center justify-center gap-1.5 transition-all shadow-2xs cursor-pointer"
                      >
                        <span>Chart</span>
                        <ArrowRight className="w-3.5 h-3.5 transition-transform group-hover:translate-x-1" />
                      </button>
                    </div>

                  </div>

                  {/* Full-Length AI Summary Banner at the Bottom - Includes AI Readiness & Relevant Labs */}
                  <div className={`mt-3.5 p-3.5 rounded-xl border text-xs leading-relaxed space-y-2.5 ${
                    isNeedsAttention
                      ? 'bg-amber-100/80 text-amber-950 border-amber-300 font-medium shadow-2xs'
                      : 'bg-stone-50/90 text-stone-800 border-stone-200/90 shadow-2xs'
                  }`}>
                    {/* Header Row: Title & AI Readiness Badge */}
                    <div className="flex flex-wrap items-center justify-between gap-2 pb-2 border-b border-stone-200/80">
                      <div className="flex items-center gap-2 font-bold text-xs text-slate-900">
                        <div className="w-5 h-5 rounded-md bg-amber-800 text-amber-100 flex items-center justify-center shrink-0 shadow-2xs">
                          <Sparkles className="w-3 h-3 text-amber-200" />
                        </div>
                        <span className="text-stone-900 font-bold">Nightingale AI Clinical Summary</span>
                      </div>

                      {/* AI Readiness Data */}
                      <div className="flex items-center gap-1.5">
                        <span className="text-[10px] font-bold text-stone-500 uppercase tracking-wider">
                          AI Readiness:
                        </span>
                        {getReadinessBadge(patient.readinessScore, patient.readinessLevel)}
                      </div>
                    </div>

                    {/* AI Clinical Summary Content */}
                    <p className="text-xs text-stone-700 font-medium leading-relaxed pl-1">
                      {patient.aiSummary}
                    </p>

                    {/* Relevant Labs Data */}
                    {patient.labs && patient.labs.length > 0 && (
                      <div className="pt-2 border-t border-stone-200/70 flex flex-wrap items-center gap-2">
                        <span className="text-[10px] font-bold text-stone-500 uppercase tracking-wider shrink-0">
                          Relevant Labs:
                        </span>
                        <div className="flex flex-wrap gap-1.5">
                          {patient.labs.map((lab, i) => (
                            <span
                              key={i}
                              className={`px-2 py-0.5 rounded-md text-[10.5px] font-medium border flex items-center gap-1.5 ${
                                lab.status === 'normal'
                                  ? 'bg-emerald-50/90 text-emerald-800 border-emerald-200'
                                  : lab.status === 'warning'
                                  ? 'bg-amber-50/90 text-amber-900 border-amber-200'
                                  : 'bg-rose-50/90 text-rose-900 border-rose-300 font-bold animate-pulse'
                              }`}
                            >
                              <span className={`w-1.5 h-1.5 rounded-full ${
                                lab.status === 'normal' ? 'bg-emerald-500' : lab.status === 'warning' ? 'bg-amber-500' : 'bg-rose-500'
                              }`}></span>
                              <span>{lab.name}: {lab.status === 'normal' ? 'Normal' : lab.value}</span>
                            </span>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* VIEW 2: OR ROOM FLOW GRID */}
        {viewMode === 'ROOM_FLOW' && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {['OR 1', 'OR 2'].map((roomName) => {
              const roomCases = cases.filter((c) => c.room === roomName);
              return (
                <div key={roomName} className="bg-slate-50/80 rounded-2xl border border-slate-200 p-4 space-y-3">
                  <div className="flex items-center justify-between border-b border-slate-200/80 pb-2">
                    <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                      <Building2 className="w-4 h-4 text-indigo-600" />
                      <span>{roomName} Schedule</span>
                    </h3>
                    <span className="text-xs font-semibold text-slate-500">
                      {roomCases.length} Cases Scheduled
                    </span>
                  </div>

                  <div className="space-y-3">
                    {roomCases.map((patient) => (
                      <div key={patient.id} className="bg-white rounded-xl p-3.5 border border-slate-200/80 shadow-2xs space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-bold text-slate-900">{patient.scheduledTime}</span>
                          {getReadinessBadge(patient.readinessScore, patient.readinessLevel)}
                        </div>
                        <div className="text-xs font-bold text-slate-800">{patient.name}</div>
                        <div className="text-[11px] text-slate-500 line-clamp-1">{patient.procedure}</div>
                        <div className="flex items-center justify-between text-[11px] text-slate-400 pt-1 border-t border-slate-100">
                          <span>Surgeon: {patient.surgeon}</span>
                          <button
                            onClick={() => onSelectPatient(patient)}
                            className="text-indigo-600 font-semibold hover:underline"
                          >
                            View Details
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* VIEW 3: BOTTLENECKS ONLY VIEW */}
        {viewMode === 'BOTTLENECKS' && (
          <div className="space-y-4">
            <div className="p-4 rounded-2xl bg-amber-50 border border-amber-300 space-y-3">
              <div className="flex items-center gap-2 text-amber-900 font-bold text-sm">
                <AlertTriangle className="w-5 h-5 text-amber-600" />
                <span>Urgent ASC Workflow Bottleneck Detected</span>
              </div>
              <p className="text-xs text-amber-800 leading-relaxed">
                Patricia DePoli (8:00 AM - OR 1) is currently missing her pre-op EKG report and facial baseline photos. If not cleared within 20 minutes, OR 1 will experience a 25-minute delay that impacts Dr. Guy Massry's afternoon procedures.
              </p>
              <div className="flex flex-wrap gap-2 pt-1">
                <button
                  onClick={() => onTriggerEKGFastTrack('case-2')}
                  className="px-3 py-1.5 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold shadow-xs transition-colors"
                >
                  Trigger Fast-Track Cardiology EKG Call
                </button>
                <button
                  onClick={() => onSelectPatient(cases.find((c) => c.id === 'case-2')!)}
                  className="px-3 py-1.5 rounded-xl bg-white text-amber-900 border border-amber-300 text-xs font-semibold hover:bg-amber-100 transition-colors"
                >
                  Open Patricia DePoli Chart
                </button>
              </div>
            </div>
          </div>
        )}

        {/* VIEW 4: PIPELINE FLOW */}
        {viewMode === 'PIPELINE' && (
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
            {[
              { stage: 'CHECK_IN', title: 'Check-In / Waiting' },
              { stage: 'PRE_OP', title: 'Pre-Op Bays' },
              { stage: 'IN_OR', title: 'Operating Rooms' },
              { stage: 'PACU_RECOVERY', title: 'PACU Recovery' },
            ].map((col) => {
              const stageCases = cases.filter((c) => c.stage === col.stage);
              return (
                <div key={col.stage} className="bg-slate-50 rounded-xl p-3 border border-slate-200/80 space-y-2">
                  <div className="text-xs font-bold text-slate-700 pb-1 border-b border-slate-200 flex justify-between">
                    <span>{col.title}</span>
                    <span className="text-slate-400">{stageCases.length}</span>
                  </div>
                  <div className="space-y-2">
                    {stageCases.map((p) => (
                      <div key={p.id} className="bg-white p-2.5 rounded-lg border border-slate-200 text-xs space-y-1 shadow-2xs">
                        <div className="font-bold text-slate-900">{p.name}</div>
                        <div className="text-[10px] text-slate-500">{p.scheduledTime} • {p.room}</div>
                        <button
                          onClick={() => onSelectPatient(p)}
                          className="text-[10px] text-indigo-600 font-semibold hover:underline block pt-1"
                        >
                          Open Record →
                        </button>
                      </div>
                    ))}
                    {stageCases.length === 0 && (
                      <div className="text-[11px] text-slate-400 italic py-2 text-center">Empty</div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}

      </div>
    </div>
  );
};
