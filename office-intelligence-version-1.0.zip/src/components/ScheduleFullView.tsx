import React, { useState } from 'react';
import { 
  ChevronLeft, 
  ChevronRight, 
  Calendar as CalendarIcon, 
  Printer, 
  BookOpen, 
  Search, 
  ChevronDown, 
  Save, 
  Clock,
  Plus,
  User,
  X,
  CheckCircle2,
  Sparkles,
  Trash2,
  ExternalLink,
  Edit3,
  FileText
} from 'lucide-react';
import { PatientCase, PAYMENT_TYPE_OPTIONS } from '../types';

export interface AppointmentItem {
  id: string;
  dayIndex: number;
  room: string;
  startHour: number;
  durationHours: number;
  title: string;
  surgeon: string;
  details: string;
  bgColor: string;
  caseId?: string;
  isBlock?: boolean;

  // 13 fields for popup modal
  dos: string;
  startTime: string;
  length: string;
  patientName: string;
  dob: string;
  age: string;
  phone: string;
  procedure: string;
  anesthesiologist: string;
  anesthesiaType: string;
  paymentType?: string;
  notes: string;
}

interface ScheduleFullViewProps {
  cases: PatientCase[];
  onSelectPatient: (patient: PatientCase) => void;
}

const initialAppointments: AppointmentItem[] = [
  // Mon 07/13/26
  {
    dayIndex: 1,
    room: 'OR#1',
    startHour: 8,
    durationHours: 1.5,
    title: 'Martinez, M',
    id: '107793',
    surgeon: 'Guy Massry, MD',
    details: '[Summit Surgical Center] Bilateral Blepharoplasty',
    bgColor: 'bg-rose-500 text-white border-rose-600',
    caseId: 'case-1',
    dos: '07/13/2026',
    startTime: '08:00 AM',
    length: '1.5 Hours',
    patientName: 'Patricia Martinez',
    dob: '04/12/1972',
    age: '54',
    phone: '(310) 555-0142',
    procedure: 'Bilateral Blepharoplasty & Upper Lid Revision',
    anesthesiologist: 'David Chen, MD',
    anesthesiaType: 'General Anesthesia',
    notes: 'Fast-track pre-op EKG clearance verified on file. Patient requested post-op cold therapy.'
  },
  {
    dayIndex: 1,
    room: 'OR#1',
    startHour: 9.5,
    durationHours: 1,
    title: 'Toney, M',
    id: '113885',
    surgeon: 'Guy Massry, MD',
    details: '[Summit Surgical Center] Bilateral revision ptosis',
    bgColor: 'bg-pink-600 text-white border-pink-700',
    caseId: 'case-1',
    dos: '07/13/2026',
    startTime: '09:30 AM',
    length: '1.0 Hour',
    patientName: 'Michael Toney',
    dob: '09/25/1968',
    age: '57',
    phone: '(310) 555-0819',
    procedure: 'Bilateral Revision Ptosis Repair',
    anesthesiologist: 'Sarah Jenkins, MD',
    anesthesiaType: 'MAC / IV Sedation',
    notes: 'Mild history of asthma. Albuterol inhaler verified in pre-op suite.'
  },
  {
    dayIndex: 1,
    room: 'OR#1',
    startHour: 12,
    durationHours: 2,
    title: 'Manesh, H',
    id: '112788',
    surgeon: 'Guy Massry, MD',
    details: '[Summit Surgical Center] Facelift & necklift',
    bgColor: 'bg-pink-600 text-white border-pink-700',
    caseId: 'case-1',
    dos: '07/13/2026',
    startTime: '12:00 PM',
    length: '2.0 Hours',
    patientName: 'Hassan Manesh',
    dob: '11/04/1961',
    age: '64',
    phone: '(424) 555-9012',
    procedure: 'Facelift & Necklift with SMAS Plication',
    anesthesiologist: 'David Chen, MD',
    anesthesiaType: 'General Anesthesia',
    notes: 'Autologous fat transfer prepared. Pre-op photograph consent verified.'
  },

  // Tue 07/14/26
  {
    dayIndex: 2,
    room: 'OR#1',
    startHour: 8,
    durationHours: 3,
    title: 'Matias, S',
    id: '114115',
    surgeon: 'Richard Zoumbalakis, MD',
    details: '[Summit Surgical Center] Rhinoplasty 6/16 email, nf',
    bgColor: 'bg-sky-600 text-white border-sky-700',
    caseId: 'case-2',
    dos: '07/14/2026',
    startTime: '08:00 AM',
    length: '3.0 Hours',
    patientName: 'Sofia Matias',
    dob: '06/18/1985',
    age: '41',
    phone: '(310) 555-3341',
    procedure: 'Primary Septorhinoplasty & Cartilage Grafting',
    anesthesiologist: 'Marcus Vance, MD',
    anesthesiaType: 'General Anesthesia',
    notes: 'Requires 3D pre-op imaging review prior to incision.'
  },
  {
    dayIndex: 2,
    room: 'OR#2',
    startHour: 7,
    durationHours: 4.5,
    title: 'Time slot blocked for:',
    id: 'BLOCK-01',
    surgeon: 'Stuart Linder, MD',
    details: '[Summit Surgical Center]',
    bgColor: 'bg-blue-800 text-white border-blue-900',
    isBlock: true,
    dos: '07/14/2026',
    startTime: '07:00 AM',
    length: '4.5 Hours',
    patientName: 'OR Block Reservation',
    dob: 'N/A',
    age: 'N/A',
    phone: 'N/A',
    procedure: 'OR Block Reserved - Dr. Stuart Linder',
    anesthesiologist: 'Assigned on arrival',
    anesthesiaType: 'Block Reservation',
    notes: 'OR 2 morning block reserved for Dr. Stuart Linder cases.'
  },
  {
    dayIndex: 2,
    room: 'OR#1',
    startHour: 12,
    durationHours: 3.5,
    title: 'Jamehdashti, S',
    id: '114114',
    surgeon: 'Richard Zoumbalakis, MD',
    details: '[Summit Surgical Center] Rhinoplasty 6/16 email, nf',
    bgColor: 'bg-sky-600 text-white border-sky-700',
    caseId: 'case-2',
    dos: '07/14/2026',
    startTime: '12:00 PM',
    length: '3.5 Hours',
    patientName: 'Shirin Jamehdashti',
    dob: '03/30/1990',
    age: '36',
    phone: '(310) 555-8822',
    procedure: 'Revision Rhinoplasty & Osteotomies',
    anesthesiologist: 'Marcus Vance, MD',
    anesthesiaType: 'General Anesthesia',
    notes: 'Pre-op lab clearance confirmed. Post-op nasal splint in room.'
  },

  // Wed 07/15/26
  {
    dayIndex: 3,
    room: 'OR#1',
    startHour: 8,
    durationHours: 4.5,
    title: 'Rodrigues, L',
    id: '114115',
    surgeon: 'Richard Zoumbalakis, MD',
    details: '[Summit Surgical Center] Rhino 6/16 email, nf',
    bgColor: 'bg-sky-600 text-white border-sky-700',
    caseId: 'case-2',
    dos: '07/15/2026',
    startTime: '08:00 AM',
    length: '4.5 Hours',
    patientName: 'Livia Rodrigues',
    dob: '07/22/1983',
    age: '43',
    phone: '(310) 555-9104',
    procedure: 'Complex Revision Rhinoplasty & Ear Cartilage Harvest',
    anesthesiologist: 'David Chen, MD',
    anesthesiaType: 'General Anesthesia',
    notes: 'Ear cartilage harvest consent signed and verified.'
  },
  {
    dayIndex: 3,
    room: 'OR#2',
    startHour: 8,
    durationHours: 1.5,
    title: 'Isralsky, K',
    id: '114071',
    surgeon: 'Guy Massry, MD',
    details: '[Summit Surgical Center]',
    bgColor: 'bg-pink-600 text-white border-pink-700',
    caseId: 'case-1',
    dos: '07/15/2026',
    startTime: '08:00 AM',
    length: '1.5 Hours',
    patientName: 'Karen Isralsky',
    dob: '05/14/1965',
    age: '61',
    phone: '(424) 555-2018',
    procedure: 'Upper & Lower Eyelid Revision',
    anesthesiologist: 'Sarah Jenkins, MD',
    anesthesiaType: 'MAC / IV Sedation',
    notes: 'Patient sensitivity to adhesive paper tape. Use silicone tape.'
  },
  {
    dayIndex: 3,
    room: 'OR#3',
    startHour: 9,
    durationHours: 2.5,
    title: 'Israel, K',
    id: '112954',
    surgeon: 'Kimberly Lee, MD',
    details: '[Summit Surgical Center] Rhino',
    bgColor: 'bg-emerald-600 text-white border-emerald-700',
    caseId: 'case-3',
    dos: '07/15/2026',
    startTime: '09:00 AM',
    length: '2.5 Hours',
    patientName: 'Kimberly Israel',
    dob: '10/10/1989',
    age: '36',
    phone: '(310) 555-7733',
    procedure: 'Primary Rhinoplasty & Alar Base Reduction',
    anesthesiologist: 'Elena Rostova, MD',
    anesthesiaType: 'General Anesthesia',
    notes: 'Pre-op photographs completed in clinical suite.'
  },
  {
    dayIndex: 3,
    room: 'OR#1',
    startHour: 12,
    durationHours: 3.5,
    title: 'Bari, I',
    id: '114116',
    surgeon: 'Richard Zoumbalakis, MD',
    details: '[Summit Surgical Center] Rhino 6/16 email, nf',
    bgColor: 'bg-sky-600 text-white border-sky-700',
    caseId: 'case-2',
    dos: '07/15/2026',
    startTime: '12:00 PM',
    length: '3.5 Hours',
    patientName: 'Imran Bari',
    dob: '01/15/1978',
    age: '48',
    phone: '(310) 555-4040',
    procedure: 'Septorhinoplasty & Endoscopic Sinus Surgery',
    anesthesiologist: 'Marcus Vance, MD',
    anesthesiaType: 'General Anesthesia',
    notes: 'ENT medical clearance attached to electronic chart.'
  },
  {
    dayIndex: 3,
    room: 'OR#2',
    startHour: 13,
    durationHours: 2.5,
    title: 'Powers, C',
    id: '111769',
    surgeon: 'Raymond Douglas, MD',
    details: '[Summit Surgical Center] Bilateral orbital decompression',
    bgColor: 'bg-cyan-600 text-white border-cyan-700',
    caseId: 'case-3',
    dos: '07/15/2026',
    startTime: '01:00 PM',
    length: '2.5 Hours',
    patientName: 'Christopher Powers',
    dob: '12/03/1970',
    age: '55',
    phone: '(310) 555-8120',
    procedure: 'Bilateral Endoscopic Orbital Decompression',
    anesthesiologist: 'David Chen, MD',
    anesthesiaType: 'General Anesthesia',
    notes: 'Specialty orbital micro-tray requested in OR 2.'
  },
  {
    dayIndex: 3,
    room: 'OR#3',
    startHour: 13,
    durationHours: 2.5,
    title: 'Wang, L',
    id: '114153',
    surgeon: 'Aric Park, MD',
    details: '[Summit Surgical Center] Upper Blepharoplasty',
    bgColor: 'bg-emerald-700 text-white border-emerald-800',
    caseId: 'case-3',
    dos: '07/15/2026',
    startTime: '01:00 PM',
    length: '2.5 Hours',
    patientName: 'Lucy Wang',
    dob: '08/29/1982',
    age: '43',
    phone: '(424) 555-6677',
    procedure: 'Bilateral Upper Blepharoplasty & Epicanthoplasty',
    anesthesiologist: 'Sarah Jenkins, MD',
    anesthesiaType: 'MAC / IV Sedation',
    notes: 'Translator services scheduled for discharge instructions.'
  },
  {
    dayIndex: 3,
    room: 'OR#2',
    startHour: 15.5,
    durationHours: 1.5,
    title: 'York, J',
    id: '113961',
    surgeon: 'Raymond Douglas, MD',
    details: '[Summit Surgical Center]',
    bgColor: 'bg-cyan-600 text-white border-cyan-700',
    caseId: 'case-3',
    dos: '07/15/2026',
    startTime: '03:30 PM',
    length: '1.5 Hours',
    patientName: 'Jennifer York',
    dob: '05/05/1975',
    age: '51',
    phone: '(310) 555-9090',
    procedure: 'Eyelid Retraction Repair & Canthoplasty',
    anesthesiologist: 'David Chen, MD',
    anesthesiaType: 'MAC / IV Sedation',
    notes: 'Clear for same-day discharge following 60 min PACU observation.'
  },

  // Thu 07/16/26
  {
    dayIndex: 4,
    room: 'OR#1',
    startHour: 8,
    durationHours: 4.5,
    title: 'Khan, A',
    id: '114117',
    surgeon: 'Richard Zoumbalakis, MD',
    details: '[Summit Surgical Center] Rhino 6/16 email, nf',
    bgColor: 'bg-sky-600 text-white border-sky-700',
    caseId: 'case-2',
    dos: '07/16/2026',
    startTime: '08:00 AM',
    length: '4.5 Hours',
    patientName: 'Ahsan Khan',
    dob: '11/11/1986',
    age: '39',
    phone: '(310) 555-1234',
    procedure: 'Primary Rhinoplasty & Turbinoplasty',
    anesthesiologist: 'Marcus Vance, MD',
    anesthesiaType: 'General Anesthesia',
    notes: 'Pre-op ECG and chest x-ray cleared.'
  },
  {
    dayIndex: 4,
    room: 'OR#2',
    startHour: 8,
    durationHours: 4.5,
    title: 'Vingsbo, C',
    id: '113477',
    surgeon: 'Robert Rey, MD',
    details: '[Summit Surgical Center] Abdominal liposuction, flank, removal and replacement bilateral breast implants 3/11 email, nf',
    bgColor: 'bg-amber-600 text-white border-amber-700',
    caseId: 'case-4',
    dos: '07/16/2026',
    startTime: '08:00 AM',
    length: '4.5 Hours',
    patientName: 'Christina Vingsbo',
    dob: '02/14/1979',
    age: '47',
    phone: '(310) 555-7890',
    procedure: 'Abdominal & Flank Liposuction, Removal and Replacement Bilateral Breast Implants',
    anesthesiologist: 'David Chen, MD',
    anesthesiaType: 'General Anesthesia',
    notes: 'Garment sizing confirmed in pre-op.'
  },

  // Fri 07/17/26
  {
    dayIndex: 5,
    room: 'OR#3',
    startHour: 8,
    durationHours: 2.5,
    title: 'Billauer, F',
    id: '98358',
    surgeon: 'Stuart Linder, MD',
    details: '[Summit Surgical Center]',
    bgColor: 'bg-blue-700 text-white border-blue-800',
    caseId: 'case-2',
    dos: '07/17/2026',
    startTime: '08:00 AM',
    length: '2.5 Hours',
    patientName: 'Frank Billauer',
    dob: '09/09/1963',
    age: '62',
    phone: '(310) 555-4321',
    procedure: 'Gynecomastia Revision & Chest Liposuction',
    anesthesiologist: 'Sarah Jenkins, MD',
    anesthesiaType: 'General Anesthesia',
    notes: 'Post-op compression vest in room.'
  },
  {
    dayIndex: 5,
    room: 'OR#1',
    startHour: 8,
    durationHours: 3,
    title: 'Sprong, J',
    id: '113603',
    surgeon: 'Guy Massry, MD',
    details: '[Summit Surgical Center] Bilateral endoscopic browlift, bilateral upper...',
    bgColor: 'bg-fuchsia-600 text-white border-fuchsia-700',
    caseId: 'case-1',
    dos: '07/17/2026',
    startTime: '08:00 AM',
    length: '3.0 Hours',
    patientName: 'Jesse Sprong',
    dob: '01/20/1967',
    age: '59',
    phone: '(424) 555-5678',
    procedure: 'Bilateral Endoscopic Browlift & Bilateral Upper Blepharoplasty',
    anesthesiologist: 'David Chen, MD',
    anesthesiaType: 'General Anesthesia',
    notes: 'Endoscopic camera system requested in OR 1.'
  },
  {
    dayIndex: 5,
    room: 'OR#2',
    startHour: 7,
    durationHours: 5,
    title: 'Correll, N',
    id: '114185',
    surgeon: 'Stuart Linder, MD',
    details: '[Summit Surgical Center] Breast revision',
    bgColor: 'bg-blue-800 text-white border-blue-900',
    caseId: 'case-2',
    dos: '07/17/2026',
    startTime: '07:00 AM',
    length: '5.0 Hours',
    patientName: 'Nancy Correll',
    dob: '06/06/1974',
    age: '52',
    phone: '(310) 555-8765',
    procedure: 'Complex Breast Revision & Capsular Contracture Release',
    anesthesiologist: 'Marcus Vance, MD',
    anesthesiaType: 'General Anesthesia',
    notes: 'Smooth gel implants staged in OR 2.'
  },
  {
    dayIndex: 5,
    room: 'OR#1',
    startHour: 11,
    durationHours: 2,
    title: 'Danek, H',
    id: '114068',
    surgeon: 'Guy Massry, MD',
    details: '[Summit Surgical Center]',
    bgColor: 'bg-pink-600 text-white border-pink-700',
    caseId: 'case-1',
    dos: '07/17/2026',
    startTime: '11:00 AM',
    length: '2.0 Hours',
    patientName: 'Helen Danek',
    dob: '12/12/1959',
    age: '66',
    phone: '(310) 555-2468',
    procedure: 'Lower Eyelid Blepharoplasty & Fat Repositioning',
    anesthesiologist: 'Sarah Jenkins, MD',
    anesthesiaType: 'MAC / IV Sedation',
    notes: 'Pre-op ocular pressure check normal.'
  },

  // Sat 07/18/26
  {
    dayIndex: 6,
    room: 'OR#3',
    startHour: 8,
    durationHours: 5,
    title: 'Time slot blocked for:',
    id: 'BLOCK-02',
    surgeon: 'Suzanne Trott, MD',
    details: '[Summit Surgical Center]',
    bgColor: 'bg-fuchsia-400 text-white border-fuchsia-500',
    isBlock: true,
    dos: '07/18/2026',
    startTime: '08:00 AM',
    length: '5.0 Hours',
    patientName: 'OR Block Reservation',
    dob: 'N/A',
    age: 'N/A',
    phone: 'N/A',
    procedure: 'OR Block Reserved - Dr. Suzanne Trott',
    anesthesiologist: 'Assigned on arrival',
    anesthesiaType: 'Block Reservation',
    notes: 'OR 3 Saturday morning block reserved.'
  }
];

export const ScheduleFullView: React.FC<ScheduleFullViewProps> = ({
  cases,
  onSelectPatient,
}) => {
  const [currentWeekDate, setCurrentWeekDate] = useState('Monday, July 13, 2026');
  const [notesText, setNotesText] = useState('OR 2 afternoon turnover delayed by 15 mins. Fast-track EKG for Patricia DePoli completed.');
  const [savedNotes, setSavedNotes] = useState(false);
  const [viewMode, setViewMode] = useState<'WK' | 'DAY'>('WK');
  const [selectedSubTab, setSelectedSubTab] = useState('Schedule');
  const [searchTerm, setSearchTerm] = useState('');

  // Interactive Appointments State
  const [appointmentsList, setAppointmentsList] = useState<AppointmentItem[]>(initialAppointments);
  const [activeAppointmentModal, setActiveAppointmentModal] = useState<AppointmentItem | null>(null);
  const [deleteConfirmAppointment, setDeleteConfirmAppointment] = useState<AppointmentItem | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [draggedAptId, setDraggedAptId] = useState<string | null>(null);
  const [dragOverTarget, setDragOverTarget] = useState<{ dIdx: number; hour: number; room: string } | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  const dayDosMap: { [key: number]: string } = {
    0: '07/12/2026',
    1: '07/13/2026',
    2: '07/14/2026',
    3: '07/15/2026',
    4: '07/16/2026',
    5: '07/17/2026',
    6: '07/18/2026',
  };

  const formatHourString = (hourNum: number) => {
    const h = Math.floor(hourNum);
    const m = Math.round((hourNum - h) * 60);
    const mStr = m < 10 ? `0${m}` : `${m}`;
    const period = h >= 12 ? 'PM' : 'AM';
    const displayH = h % 12 === 0 ? 12 : h % 12;
    const hStr = displayH < 10 ? `0${displayH}` : `${displayH}`;
    return `${hStr}:${mStr} ${period}`;
  };

  const daysOfWeek = [
    { label: 'Sun, 07/12/26', date: '07/12/26', isToday: false },
    { label: 'Mon, 07/13/26', date: '07/13/26', isToday: true },
    { label: 'Tue, 07/14/26', date: '07/14/26', isToday: false },
    { label: 'Wed, 07/15/26', date: '07/15/26', isToday: false },
    { label: 'Thu, 07/16/26', date: '07/16/26', isToday: false },
    { label: 'Fri, 07/17/26', date: '07/17/26', isToday: false },
    { label: 'Sat, 07/18/26', date: '07/18/26', isToday: false },
  ];

  const rooms = ['OR#1', 'OR#2', 'OR#3'];
  
  // 15-Minute interval slots generation from 6 AM to 10 PM
  const timeSlots: { hourNum: number; displayLabel: string; isHourMark: boolean; minute: number }[] = [];
  for (let h = 6; h <= 21; h++) {
    for (let m = 0; m < 60; m += 15) {
      const hourNum = h + m / 60;
      const period = h >= 12 ? 'PM' : 'AM';
      const displayH = h % 12 === 0 ? 12 : h % 12;
      const mStr = m === 0 ? '00' : `${m}`;
      const displayLabel = m === 0 ? `${displayH}:${mStr} ${period}` : `:${mStr}`;
      timeSlots.push({
        hourNum,
        displayLabel,
        isHourMark: m === 0,
        minute: m,
      });
    }
  }

  const parseTimeToDecimalHour = (timeStr: string): number => {
    if (!timeStr) return 8;
    const match = timeStr.match(/(\d{1,2}):(\d{2})\s*(AM|PM)?/i);
    if (!match) return 8;
    let h = parseInt(match[1], 10);
    const m = parseInt(match[2], 10);
    const period = match[3]?.toUpperCase();
    if (period === 'PM' && h < 12) h += 12;
    if (period === 'AM' && h === 12) h = 0;
    return h + m / 60;
  };

  const parseLengthToHours = (lengthStr: string): number => {
    if (!lengthStr) return 1;
    const numMatch = lengthStr.match(/(\d+(\.\d+)?)/);
    if (!numMatch) return 1;
    const val = parseFloat(numMatch[1]);
    if (lengthStr.toLowerCase().includes('min')) {
      return val / 60;
    }
    return val;
  };

  const handleOpenAppointmentModal = (apt: AppointmentItem) => {
    setActiveAppointmentModal({ ...apt });
  };

  const handleSlotClick = (dIdx: number, startHourNum: number, roomName: string) => {
    const dosString = dayDosMap[dIdx] || '07/13/2026';
    const startTimeStr = formatHourString(startHourNum);

    const newApt: AppointmentItem = {
      id: `APT-${Math.floor(100000 + Math.random() * 900000)}`,
      dayIndex: dIdx,
      room: roomName,
      startHour: startHourNum,
      durationHours: 1.5,
      title: 'New Patient',
      surgeon: 'Guy Massry, MD',
      details: '[Summit Surgical Center] Elective Surgical Procedure',
      bgColor: 'bg-emerald-600 text-white border-emerald-700',
      dos: dosString,
      startTime: startTimeStr,
      length: '1.5 Hours',
      patientName: 'New Patient',
      dob: '01/15/1982',
      age: '44',
      phone: '(310) 555-0199',
      procedure: 'Elective Surgical Procedure',
      anesthesiologist: 'David Chen, MD',
      anesthesiaType: 'General Anesthesia',
      paymentType: 'Self-Pay',
      notes: `Scheduled for ${roomName} on ${dosString} at ${startTimeStr}`
    };
    setActiveAppointmentModal(newApt);
  };

  const handleDragStart = (e: React.DragEvent, id: string) => {
    e.dataTransfer.setData('text/plain', id);
    e.dataTransfer.effectAllowed = 'move';
    setDraggedAptId(id);
  };

  const handleDragEnd = () => {
    setDraggedAptId(null);
    setDragOverTarget(null);
  };

  const handleDropOnSlot = (e: React.DragEvent, dIdx: number, startHourNum: number, roomName: string) => {
    const id = e.dataTransfer.getData('text/plain') || draggedAptId;
    if (!id) return;

    const apt = appointmentsList.find((a) => a.id === id);
    if (!apt) return;

    const dosString = dayDosMap[dIdx] || '07/13/2026';
    const startTimeStr = formatHourString(startHourNum);

    const updatedApt: AppointmentItem = {
      ...apt,
      dayIndex: dIdx,
      room: roomName,
      startHour: startHourNum,
      dos: dosString,
      startTime: startTimeStr,
    };

    setAppointmentsList((prev) => prev.map((a) => (a.id === id ? updatedApt : a)));
    const dayName = daysOfWeek[dIdx]?.label?.split(',')[0] || `Day ${dIdx}`;
    showToast(`Rescheduled ${apt.patientName || apt.title} to ${roomName} (${dayName} at ${startTimeStr})`);
    setDraggedAptId(null);
    setDragOverTarget(null);
  };

  const handleCreateNewAppointment = () => {
    const newApt: AppointmentItem = {
      id: `APT-${Math.floor(100000 + Math.random() * 900000)}`,
      dayIndex: 1, // Mon 07/13/26 default
      room: 'OR#1',
      startHour: 8,
      durationHours: 1.5,
      title: 'New Patient',
      surgeon: 'Guy Massry, MD',
      details: '[Summit Surgical Center] Elective Surgical Procedure',
      bgColor: 'bg-emerald-600 text-white border-emerald-700',
      dos: '07/13/2026',
      startTime: '08:00 AM',
      length: '1.5 Hours',
      patientName: 'New Patient',
      dob: '01/15/1982',
      age: '44',
      phone: '(310) 555-0199',
      procedure: 'Elective Surgical Procedure',
      anesthesiologist: 'David Chen, MD',
      anesthesiaType: 'General Anesthesia',
      paymentType: 'Self-Pay',
      notes: 'New appointment scheduled from schedule toolbar.'
    };
    setActiveAppointmentModal(newApt);
  };

  const handleFormChange = (field: keyof AppointmentItem, value: string) => {
    if (!activeAppointmentModal) return;
    setActiveAppointmentModal((prev) => {
      if (!prev) return null;
      let newDayIndex = prev.dayIndex;
      if (field === 'dos') {
        if (value.includes('13')) newDayIndex = 1;
        else if (value.includes('14')) newDayIndex = 2;
        else if (value.includes('15')) newDayIndex = 3;
        else if (value.includes('16')) newDayIndex = 4;
        else if (value.includes('17')) newDayIndex = 5;
        else if (value.includes('18')) newDayIndex = 6;
        else if (value.includes('12')) newDayIndex = 0;
      }
      let newStartHour = prev.startHour;
      let newDurationHours = prev.durationHours;
      if (field === 'startTime') {
        const parsedH = parseTimeToDecimalHour(value);
        if (parsedH !== null && !isNaN(parsedH)) newStartHour = parsedH;
      }
      if (field === 'length') {
        const parsedDur = parseLengthToHours(value);
        if (parsedDur !== null && !isNaN(parsedDur)) newDurationHours = parsedDur;
      }
      return {
        ...prev,
        [field]: value,
        dayIndex: newDayIndex,
        startHour: newStartHour,
        durationHours: newDurationHours,
        ...(field === 'patientName' ? { title: value } : {}),
        ...(field === 'procedure' ? { details: `[Summit Surgical Center] ${value}` } : {}),
      };
    });
  };

  const handleSaveAppointment = () => {
    if (!activeAppointmentModal) return;
    const updated = activeAppointmentModal;
    setAppointmentsList((prev) => {
      const exists = prev.some((a) => a.id === updated.id);
      if (exists) {
        return prev.map((a) => (a.id === updated.id ? updated : a));
      } else {
        return [...prev, updated];
      }
    });
    setActiveAppointmentModal(null);
    showToast(`Saved appointment for ${updated.patientName || updated.title}.`);
  };

  const handleDeleteAppointment = () => {
    if (!activeAppointmentModal) return;
    setDeleteConfirmAppointment(activeAppointmentModal);
  };

  const handleConfirmDeleteAppointment = () => {
    if (!deleteConfirmAppointment) return;
    const targetId = deleteConfirmAppointment.id;
    const targetName = deleteConfirmAppointment.patientName;
    setAppointmentsList((prev) => prev.filter((a) => a.id !== targetId));
    setDeleteConfirmAppointment(null);
    setActiveAppointmentModal(null);
    showToast(`Deleted appointment for ${targetName} from schedule.`);
  };

  const handleOpenChartFromModal = () => {
    if (!activeAppointmentModal) return;
    const matchedCase = cases.find(
      (c) => c.id === activeAppointmentModal.caseId || c.name.toLowerCase().includes(activeAppointmentModal.patientName.toLowerCase())
    ) || cases[0];
    
    setActiveAppointmentModal(null);
    if (matchedCase) {
      onSelectPatient(matchedCase);
    }
  };

  const handleSaveNotes = () => {
    setSavedNotes(true);
    setTimeout(() => setSavedNotes(false), 2500);
  };

  const monthCalendarDays = Array.from({ length: 31 }, (_, i) => i + 1);

  return (
    <div className="w-full bg-slate-100 text-slate-800 font-sans text-xs min-h-screen flex flex-col border border-slate-300 shadow-xl rounded-2xl overflow-hidden relative">
      
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-6 right-6 z-50 bg-[#2b3a4a] text-white text-xs font-semibold px-4 py-3 rounded-xl shadow-2xl border border-slate-700 flex items-center gap-2.5 animate-in slide-in-from-top duration-300">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Date Header Controls & Main Content Area */}
      <div className="flex-1 p-3 flex flex-col gap-3">
        
        {/* Calendar Header Control Row */}
        <div className="flex flex-wrap items-center justify-between px-2 py-1 gap-2">
          <div className="flex items-center gap-2">
            <button className="p-1 border border-slate-300 rounded bg-white hover:bg-slate-100 text-slate-700 shadow-2xs">
              <ChevronLeft className="w-5 h-5" />
            </button>
            <button className="px-3 py-1 bg-[#2b3a4a] text-white font-bold rounded shadow-2xs text-xs">
              Today
            </button>
            <button className="p-1 border border-slate-300 rounded bg-white hover:bg-slate-100 text-slate-700 shadow-2xs">
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>

          <div className="text-xl font-serif font-bold text-rose-800 tracking-tight">
            {currentWeekDate}
          </div>

          <div className="flex items-center gap-2">
            <button className="px-3 py-1.5 bg-[#2b3a4a] text-white rounded-md font-bold text-xs hover:bg-slate-800 transition-colors shadow-2xs flex items-center gap-1.5">
              <BookOpen className="w-3.5 h-3.5 text-slate-200" />
              <span>Appointment Books</span>
            </button>
            <button 
              onClick={() => window.print()}
              className="px-3 py-1.5 bg-[#2b3a4a] text-white rounded-md font-bold text-xs hover:bg-slate-800 transition-colors shadow-2xs flex items-center gap-1.5 cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5 text-slate-200" />
              <span>Print</span>
            </button>
            <button
              onClick={handleCreateNewAppointment}
              className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-md font-bold text-xs transition-colors shadow-sm flex items-center gap-1.5 cursor-pointer border border-emerald-500"
            >
              <Plus className="w-3.5 h-3.5 text-white" />
              <span>Add New Appointment</span>
            </button>

            <div className="h-5 w-px bg-slate-300 mx-1" />

            <div className="flex items-center gap-1">
              <button 
                onClick={() => setViewMode('DAY')}
                className={`p-1.5 border border-slate-300 rounded font-bold text-xs flex items-center gap-1 ${
                  viewMode === 'DAY' ? 'bg-[#2b3a4a] text-white' : 'bg-white text-slate-700'
                }`}
              >
                <span>DAY</span>
              </button>
              <button 
                onClick={() => setViewMode('WK')}
                className={`p-1.5 border border-slate-300 rounded font-bold text-xs flex items-center gap-1 ${
                  viewMode === 'WK' ? 'bg-[#2b3a4a] text-white' : 'bg-white text-slate-700'
                }`}
              >
                <span>WK</span>
              </button>
            </div>
          </div>
        </div>

        {/* Main Grid + Sidebar Split */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-3 items-start flex-1">
          
          {/* Calendar Matrix View (10 Cols) */}
          <div className="lg:col-span-10 bg-white border border-slate-300 rounded shadow-2xs overflow-x-auto">
            <div className="min-w-[1000px]">
              
              {/* Quick Interactive Tip Banner */}
              <div className="bg-slate-50 border-b border-slate-200 px-3 py-1.5 flex items-center justify-between text-[11px] text-slate-600 select-none">
                <div className="flex items-center gap-1.5 font-medium">
                  <span className="text-emerald-700 font-bold flex items-center gap-1">
                    <Plus className="w-3 h-3 text-emerald-600" />
                    Interactive 15-Min Schedule:
                  </span>
                  <span>Click any 15-minute slot to schedule a case, or drag & drop appointment blocks to reschedule.</span>
                </div>
                <div className="text-[10px] text-slate-500 font-semibold bg-slate-200/80 px-2 py-0.5 rounded-full">
                  {appointmentsList.length} Scheduled Cases
                </div>
              </div>
              
              {/* Header Days Row */}
              <div className="grid grid-cols-22 border-b border-slate-300 bg-slate-100 text-center text-[11px] font-bold text-slate-700">
                <div className="col-span-1 p-2 border-r border-slate-300 bg-slate-200">
                  Time
                </div>
                {daysOfWeek.map((day, dIdx) => (
                  <div 
                    key={dIdx} 
                    className={`col-span-3 border-r border-slate-300 py-1 px-1 ${
                      day.isToday ? 'bg-amber-100/90 text-slate-900 border-b-2 border-b-amber-500' : 'bg-slate-100'
                    }`}
                  >
                    <div>{day.label}</div>
                    <div className="grid grid-cols-3 text-[10px] text-slate-500 font-semibold border-t border-slate-200 mt-1 pt-0.5">
                      <div>OR#1</div>
                      <div>OR#2</div>
                      <div>OR#3</div>
                    </div>
                  </div>
                ))}
              </div>

              {/* 15-Minute Rows Grid */}
              <div className="relative">
                {timeSlots.map((slot, sIdx) => {
                  return (
                    <div 
                      key={sIdx} 
                      className={`grid grid-cols-22 min-h-[22px] max-h-[22px] text-[10px] ${
                        slot.isHourMark 
                          ? 'border-t-2 border-slate-300 bg-slate-50/90' 
                          : 'border-t border-slate-100 border-dashed'
                      }`}
                    >
                      {/* Time Label */}
                      <div className={`col-span-1 border-r border-slate-300 pr-1.5 select-none flex items-center justify-end ${
                        slot.isHourMark ? 'bg-slate-200/90 text-slate-800 font-bold text-[10px]' : 'bg-slate-50/70 text-slate-400 font-medium text-[8px]'
                      }`}>
                        {slot.displayLabel}
                      </div>

                      {/* Day Columns */}
                      {daysOfWeek.map((day, dIdx) => (
                        <div 
                          key={dIdx} 
                          className={`col-span-3 grid grid-cols-3 border-r border-slate-300 relative ${
                            day.isToday ? (slot.isHourMark ? 'bg-amber-100/25' : 'bg-amber-50/20') : 'bg-white'
                          }`}
                        >
                          {rooms.map((roomName, rIdx) => {
                            const isHoveredTarget = 
                              dragOverTarget?.dIdx === dIdx && 
                              Math.abs((dragOverTarget?.hour ?? -1) - slot.hourNum) < 0.01 && 
                              dragOverTarget?.room === roomName;

                            return (
                              <div
                                key={roomName}
                                onClick={() => handleSlotClick(dIdx, slot.hourNum, roomName)}
                                onDragOver={(e) => {
                                  e.preventDefault();
                                  setDragOverTarget({ dIdx, hour: slot.hourNum, room: roomName });
                                }}
                                onDragLeave={() => {
                                  setDragOverTarget(null);
                                }}
                                onDrop={(e) => {
                                  e.preventDefault();
                                  setDragOverTarget(null);
                                  handleDropOnSlot(e, dIdx, slot.hourNum, roomName);
                                }}
                                className={`border-r border-slate-100/60 transition-all cursor-pointer group flex items-center justify-center relative ${
                                  rIdx === 2 ? 'border-r-0' : ''
                                } ${
                                  isHoveredTarget 
                                    ? 'bg-emerald-200/90 ring-2 ring-emerald-500 ring-inset z-10' 
                                    : 'hover:bg-sky-50/80 hover:border-sky-300'
                                }`}
                                title={`Click to add appointment or drop here (${day.label.split(',')[0]} - ${roomName} at ${slot.displayLabel})`}
                              >
                                <span className="opacity-0 group-hover:opacity-100 text-[7px] font-bold text-sky-700 bg-sky-100 px-0.5 py-0 rounded transition-opacity pointer-events-none select-none shadow-2xs">
                                  +
                                </span>
                              </div>
                            );
                          })}
                        </div>
                      ))}
                    </div>
                  );
                })}

                {/* Scheduled Appointment Overlays (22px per 15 min = 88px per hour) */}
                {appointmentsList.map((apt, aIdx) => {
                  const topPx = (apt.startHour - 6) * 88;
                  const heightPx = Math.max(apt.durationHours * 88, 20);

                  const roomIndex = apt.room === 'OR#1' ? 0 : apt.room === 'OR#2' ? 1 : 2;
                  const colOffset = 1 + apt.dayIndex * 3 + roomIndex;
                  const leftPercent = (colOffset / 22) * 100;
                  const widthPercent = (1 / 22) * 100;

                  const isBeingDragged = draggedAptId === apt.id;

                  return (
                    <div
                      key={apt.id + '-' + aIdx}
                      draggable={true}
                      onDragStart={(e) => handleDragStart(e, apt.id)}
                      onDragEnd={handleDragEnd}
                      onClick={(e) => {
                        e.stopPropagation();
                        handleOpenAppointmentModal(apt);
                      }}
                      style={{
                        top: `${topPx}px`,
                        height: `${heightPx}px`,
                        left: `${leftPercent}%`,
                        width: `${widthPercent}%`,
                      }}
                      className={`absolute p-1 rounded-xs border text-[9.5px] leading-tight overflow-hidden shadow-2xs cursor-grab active:cursor-grabbing hover:z-30 hover:scale-[1.02] transition-transform select-none ${apt.bgColor} ${
                        isBeingDragged ? 'opacity-40 border-dashed border-2 ring-2 ring-amber-400 z-40' : ''
                      }`}
                      title={`Drag to reschedule or click to view/edit (${apt.patientName || apt.title})`}
                    >
                      <div className="font-bold flex items-center justify-between text-[10px]">
                        <span className="truncate">{apt.startTime || formatHourString(apt.startHour)}</span>
                        {!apt.isBlock && <span className="text-[8px] opacity-90 font-mono">#{apt.id}</span>}
                      </div>
                      <div className="font-black text-[10.5px] truncate mt-0.5">{apt.patientName || apt.title}</div>
                      <div className="text-[9px] font-semibold opacity-95 truncate">{apt.surgeon}</div>

                      {/* Details section if height allows */}
                      {heightPx >= 36 && (
                        <div className="border-t border-white/25 pt-0.5 mt-0.5 text-[8.5px] font-medium leading-tight opacity-90 line-clamp-2">
                          {apt.procedure || apt.details}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>

            </div>
          </div>

          {/* Right Sidebar: Mini Calendar & Notes (2 Cols) */}
          <div className="lg:col-span-2 space-y-3">
            
            {/* Mini Month Calendar */}
            <div className="bg-white border border-slate-300 rounded p-2.5 shadow-2xs">
              <div className="flex items-center justify-between text-xs font-bold text-slate-800 mb-2 border-b pb-1">
                <button className="hover:text-[#2b3a4a]">&lt;</button>
                <span>July 2026</span>
                <button className="hover:text-[#2b3a4a]">&gt;</button>
              </div>

              <div className="grid grid-cols-7 text-center text-[10px] font-bold text-slate-500 mb-1">
                <div>Su</div>
                <div>Mo</div>
                <div>Tu</div>
                <div>We</div>
                <div>Th</div>
                <div>Fr</div>
                <div>Sa</div>
              </div>

              <div className="grid grid-cols-7 text-center text-[10px] gap-y-1 text-slate-700 font-medium">
                <div className="text-slate-300">28</div>
                <div className="text-slate-300">29</div>
                <div className="text-slate-300">30</div>
                {monthCalendarDays.map((day) => {
                  const isToday = day === 13;
                  return (
                    <div
                      key={day}
                      className={`py-0.5 rounded cursor-pointer hover:bg-slate-200 ${
                        isToday ? 'bg-[#2b3a4a] text-white font-bold' : ''
                      }`}
                    >
                      {day}
                    </div>
                  );
                })}
              </div>
            </div>

            {/* (Nightingale AI section removed as requested) */}

          </div>

        </div>

      </div>

      {/* APPOINTMENT DETAILS POP-UP MODAL */}
      {activeAppointmentModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-200">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-300 w-full max-w-3xl overflow-hidden animate-in zoom-in-95 duration-200 flex flex-col">
            
            {/* Modal Header */}
            <div className="px-6 py-4 bg-slate-800 text-white flex items-center justify-between border-b border-slate-700">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-slate-700 flex items-center justify-center text-slate-200">
                  <CalendarIcon className="w-4 h-4 text-emerald-400" />
                </div>
                <div>
                  <h3 className="font-bold text-sm text-white flex items-center gap-2">
                    <span>Appointment Details</span>
                    {activeAppointmentModal.room && (
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-700 text-emerald-300 border border-slate-600">
                        {activeAppointmentModal.room}
                      </span>
                    )}
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-indigo-900 text-indigo-200 border border-indigo-700 flex items-center gap-1">
                      💳 {activeAppointmentModal.paymentType || 'Self-Pay'}
                    </span>
                  </h3>
                  <p className="text-[11px] text-slate-300 font-medium">
                    Modify appointment fields, update patient notes, or open chart
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setActiveAppointmentModal(null)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-700 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Body: 5 Lines of Fields */}
            <div className="p-6 space-y-4 text-xs font-sans text-slate-800 max-h-[75vh] overflow-y-auto">
              
              {/* LINE 1: Date of Service (DOS), Start Time, Length of Surgery / Appointment, Operating Room */}
              <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
                <div>
                  <label className="block text-[11px] font-bold text-slate-600 uppercase tracking-wider mb-1">
                    Date of Service (DOS)
                  </label>
                  <input
                    type="text"
                    value={activeAppointmentModal.dos || ''}
                    onChange={(e) => handleFormChange('dos', e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs font-semibold text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all shadow-2xs"
                    placeholder="MM/DD/YYYY"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-600 uppercase tracking-wider mb-1">
                    Start Time
                  </label>
                  <input
                    type="text"
                    value={activeAppointmentModal.startTime || ''}
                    onChange={(e) => handleFormChange('startTime', e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs font-semibold text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all shadow-2xs"
                    placeholder="08:00 AM"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-600 uppercase tracking-wider mb-1">
                    Length of Surgery
                  </label>
                  <select
                    value={activeAppointmentModal.length || '1.5 Hours'}
                    onChange={(e) => handleFormChange('length', e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs font-semibold text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all shadow-2xs cursor-pointer"
                  >
                    {!['15 Minutes', '30 Minutes', '45 Minutes', '1.0 Hour', '1.25 Hours', '1.5 Hours', '1.75 Hours', '2.0 Hours', '2.5 Hours', '3.0 Hours', '3.5 Hours', '4.0 Hours', '5.0 Hours', '6.0 Hours'].includes(activeAppointmentModal.length || '') && activeAppointmentModal.length && (
                      <option value={activeAppointmentModal.length}>{activeAppointmentModal.length}</option>
                    )}
                    <option value="15 Minutes">15 Minutes (0.25 Hrs)</option>
                    <option value="30 Minutes">30 Minutes (0.5 Hrs)</option>
                    <option value="45 Minutes">45 Minutes (0.75 Hrs)</option>
                    <option value="1.0 Hour">1.0 Hour (60 Mins)</option>
                    <option value="1.25 Hours">1.25 Hours (75 Mins)</option>
                    <option value="1.5 Hours">1.5 Hours (90 Mins)</option>
                    <option value="1.75 Hours">1.75 Hours (105 Mins)</option>
                    <option value="2.0 Hours">2.0 Hours (120 Mins)</option>
                    <option value="2.5 Hours">2.5 Hours (150 Mins)</option>
                    <option value="3.0 Hours">3.0 Hours (180 Mins)</option>
                    <option value="3.5 Hours">3.5 Hours (210 Mins)</option>
                    <option value="4.0 Hours">4.0 Hours (240 Mins)</option>
                    <option value="5.0 Hours">5.0 Hours (300 Mins)</option>
                    <option value="6.0 Hours">6.0 Hours (360 Mins)</option>
                  </select>
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-600 uppercase tracking-wider mb-1">
                    Operating Room
                  </label>
                  <select
                    value={activeAppointmentModal.room || 'OR#1'}
                    onChange={(e) => handleFormChange('room', e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs font-semibold text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all shadow-2xs cursor-pointer"
                  >
                    <option value="OR#1">OR#1</option>
                    <option value="OR#2">OR#2</option>
                    <option value="OR#3">OR#3</option>
                  </select>
                </div>
              </div>

              {/* LINE 2: Patient's Name, Date of Birth, Age, Phone Number */}
              <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
                <div>
                  <label className="block text-[11px] font-bold text-slate-600 uppercase tracking-wider mb-1">
                    Patient Name
                  </label>
                  <input
                    type="text"
                    value={activeAppointmentModal.patientName || ''}
                    onChange={(e) => handleFormChange('patientName', e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs font-semibold text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all shadow-2xs"
                    placeholder="Patient Name"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-600 uppercase tracking-wider mb-1">
                    Date of Birth (DOB)
                  </label>
                  <input
                    type="text"
                    value={activeAppointmentModal.dob || ''}
                    onChange={(e) => handleFormChange('dob', e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs font-semibold text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all shadow-2xs"
                    placeholder="MM/DD/YYYY"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-600 uppercase tracking-wider mb-1">
                    Age
                  </label>
                  <input
                    type="text"
                    value={activeAppointmentModal.age || ''}
                    onChange={(e) => handleFormChange('age', e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs font-semibold text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all shadow-2xs"
                    placeholder="54"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-600 uppercase tracking-wider mb-1">
                    Phone Number
                  </label>
                  <input
                    type="text"
                    value={activeAppointmentModal.phone || ''}
                    onChange={(e) => handleFormChange('phone', e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs font-semibold text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all shadow-2xs"
                    placeholder="(310) 555-0100"
                  />
                </div>
              </div>

              {/* LINE 3: Full-length text field for Procedure */}
              <div>
                <label className="block text-[11px] font-bold text-slate-600 uppercase tracking-wider mb-1">
                  Procedure
                </label>
                <input
                  type="text"
                  value={activeAppointmentModal.procedure || ''}
                  onChange={(e) => handleFormChange('procedure', e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs font-semibold text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all shadow-2xs"
                  placeholder="Full procedure description"
                />
              </div>

              {/* LINE 4: Surgeon's Name, Anesthesiologist, Type of Anesthesia, Payment Type Drop-down */}
              <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
                <div>
                  <label className="block text-[11px] font-bold text-slate-600 uppercase tracking-wider mb-1">
                    Surgeon's Name
                  </label>
                  <input
                    type="text"
                    value={activeAppointmentModal.surgeon || ''}
                    onChange={(e) => handleFormChange('surgeon', e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs font-semibold text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all shadow-2xs"
                    placeholder="Dr. Surgeon Name"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-600 uppercase tracking-wider mb-1">
                    Anesthesiologist
                  </label>
                  <input
                    type="text"
                    value={activeAppointmentModal.anesthesiologist || ''}
                    onChange={(e) => handleFormChange('anesthesiologist', e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs font-semibold text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all shadow-2xs"
                    placeholder="Dr. Anesthesiologist Name"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-600 uppercase tracking-wider mb-1">
                    Type of Anesthesia
                  </label>
                  <input
                    type="text"
                    value={activeAppointmentModal.anesthesiaType || ''}
                    onChange={(e) => handleFormChange('anesthesiaType', e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs font-semibold text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all shadow-2xs"
                    placeholder="General / MAC / Local"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-indigo-900 uppercase tracking-wider mb-1 flex items-center justify-between">
                    <span>Payment Type</span>
                    <span className="text-[9px] text-indigo-700 bg-indigo-50 px-1 py-0.2 rounded font-extrabold border border-indigo-200">Required</span>
                  </label>
                  <select
                    value={activeAppointmentModal.paymentType || 'Self-Pay'}
                    onChange={(e) => handleFormChange('paymentType', e.target.value)}
                    className="w-full px-3 py-2 bg-indigo-50/50 border border-indigo-300 rounded-lg text-xs font-bold text-indigo-950 focus:outline-hidden focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all shadow-2xs cursor-pointer"
                  >
                    {!PAYMENT_TYPE_OPTIONS.includes((activeAppointmentModal.paymentType || '') as any) && activeAppointmentModal.paymentType && (
                      <option value={activeAppointmentModal.paymentType}>{activeAppointmentModal.paymentType}</option>
                    )}
                    {PAYMENT_TYPE_OPTIONS.map((opt) => (
                      <option key={opt} value={opt}>
                        {opt}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* LINE 5: Full-length box for Notes */}
              <div>
                <label className="block text-[11px] font-bold text-slate-600 uppercase tracking-wider mb-1">
                  Notes
                </label>
                <textarea
                  rows={3}
                  value={activeAppointmentModal.notes || ''}
                  onChange={(e) => handleFormChange('notes', e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs font-medium text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all resize-none shadow-2xs"
                  placeholder="Clinical notes, pre-op instructions, or patient preferences..."
                />
              </div>

              {/* LINE 6: Buttons for deleting, saving, and opening the chart */}
              <div className="pt-4 border-t border-slate-200 flex items-center justify-between gap-3">
                <button
                  type="button"
                  onClick={handleDeleteAppointment}
                  className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs rounded-xl transition-colors flex items-center gap-1.5 shadow-xs cursor-pointer"
                >
                  <Trash2 className="w-4 h-4" />
                  <span>Delete</span>
                </button>

                <div className="flex items-center gap-2.5">
                  <button
                    type="button"
                    onClick={handleOpenChartFromModal}
                    className="px-4 py-2 bg-slate-700 hover:bg-slate-800 text-white font-bold text-xs rounded-xl transition-colors flex items-center gap-1.5 shadow-xs cursor-pointer"
                  >
                    <ExternalLink className="w-4 h-4 text-slate-300" />
                    <span>Open Chart</span>
                  </button>
                  <button
                    type="button"
                    onClick={handleSaveAppointment}
                    className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl transition-colors flex items-center gap-1.5 shadow-md cursor-pointer"
                  >
                    <Save className="w-4 h-4" />
                    <span>Save</span>
                  </button>
                </div>
              </div>

            </div>

          </div>
        </div>
      )}

      {/* Delete Appointment Confirmation Modal */}
      {deleteConfirmAppointment && (
        <div className="fixed inset-0 bg-stone-900/80 backdrop-blur-xs flex items-center justify-center z-[100000] p-4 animate-in fade-in duration-150">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 border border-stone-200 shadow-2xl space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-rose-100 border border-rose-200 text-rose-600 flex items-center justify-center shrink-0">
                <Trash2 className="w-5 h-5 text-rose-600" />
              </div>
              <div>
                <h3 className="text-base font-extrabold text-stone-900">Confirm Appointment Deletion</h3>
                <p className="text-xs text-stone-500 font-medium">Please confirm before deleting this scheduled appointment.</p>
              </div>
            </div>

            <div className="p-3.5 bg-rose-50/80 border border-rose-200/90 rounded-xl space-y-1.5 text-xs text-stone-800">
              <div className="font-extrabold text-rose-950 flex items-center justify-between">
                <span>Patient Name:</span>
                <span className="text-stone-900 font-bold">{deleteConfirmAppointment.patientName}</span>
              </div>
              <div className="flex justify-between text-stone-600">
                <span>Date & Time:</span>
                <span className="font-bold text-stone-800">{deleteConfirmAppointment.dos} at {deleteConfirmAppointment.startTime}</span>
              </div>
              <div className="flex justify-between text-stone-600">
                <span>Room / Location:</span>
                <span className="font-bold text-stone-800">{deleteConfirmAppointment.room}</span>
              </div>
              <div className="flex justify-between text-stone-600">
                <span>Procedure:</span>
                <span className="font-bold text-stone-800">{deleteConfirmAppointment.procedure}</span>
              </div>
              <div className="flex justify-between text-stone-600">
                <span>Payment Type:</span>
                <span className="font-bold text-indigo-900 bg-indigo-50 px-1.5 py-0.5 rounded border border-indigo-200">{deleteConfirmAppointment.paymentType || 'Self-Pay'}</span>
              </div>
            </div>

            <p className="text-xs text-stone-500 leading-relaxed font-medium">
              ⚠️ <strong>Warning:</strong> Deleting this appointment will permanently remove it from the OR schedule and patient itinerary. This action cannot be undone.
            </p>

            <div className="pt-2 flex items-center justify-end gap-2.5">
              <button
                type="button"
                onClick={() => setDeleteConfirmAppointment(null)}
                className="px-4 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 font-bold text-xs rounded-xl border border-stone-200 transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmDeleteAppointment}
                className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs rounded-xl shadow-md transition-colors flex items-center gap-1.5 cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Confirm Delete Appointment</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Footer Copyright */}
      <div className="bg-slate-200 px-4 py-2 border-t border-slate-300 text-[10px] text-slate-600 font-medium flex items-center justify-between">
        <span>2026 © iMARSMED</span>
        <span>Summit Surgical Center • Version 4.8.2</span>
      </div>

    </div>
  );
};

