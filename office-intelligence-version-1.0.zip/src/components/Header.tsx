import React, { useState, useRef, useEffect } from 'react';
import { Search, RefreshCw, Plus, PanelLeft, Settings, Check, Calendar, CheckSquare, Square } from 'lucide-react';

interface HeaderProps {
  onRefresh: () => void;
  onAppointmentBooks?: () => void;
  onPrint?: () => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  activeTab?: string;
  onAddPatient?: () => void;
  onToggleSidebar?: () => void;
}

const SCHEDULE_VIEW_OPTIONS = [
  { id: 'or-1', label: 'OR #1 (Main Surgical Suite)', category: 'room' },
  { id: 'or-2', label: 'OR #2 (Facial & Aesthetic)', category: 'room' },
  { id: 'or-3', label: 'OR #3 (Outpatient Procedures)', category: 'room' },
  { id: 'minor-proc', label: 'Minor Proc Bay', category: 'room' },
  { id: 'dr-massry', label: 'Dr. Guy Massry, MD', category: 'doctor' },
  { id: 'dr-chen', label: 'Dr. David Chen, MD', category: 'doctor' },
  { id: 'dr-jenkins', label: 'Dr. Sarah Jenkins, MD', category: 'doctor' },
  { id: 'dr-vance', label: 'Dr. Robert Vance, MD', category: 'doctor' },
];

export const Header: React.FC<HeaderProps> = ({
  onRefresh,
  onAppointmentBooks,
  onPrint,
  searchQuery,
  setSearchQuery,
  activeTab,
  onAddPatient,
  onToggleSidebar,
}) => {
  const isTemplate = activeTab === 'template';
  const isPatients = activeTab === 'patients';
  const isAdmin = activeTab === 'admin';

  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [selectedViews, setSelectedViews] = useState<string[]>([
    'or-1', 'or-2', 'or-3', 'dr-massry', 'dr-chen', 'dr-jenkins'
  ]);

  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const toggleOption = (id: string) => {
    setSelectedViews((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const handleSelectAll = () => {
    if (selectedViews.length === SCHEDULE_VIEW_OPTIONS.length) {
      setSelectedViews([]);
    } else {
      setSelectedViews(SCHEDULE_VIEW_OPTIONS.map((opt) => opt.id));
    }
  };

  const handleApplyViews = () => {
    setIsDropdownOpen(false);
    if (onAppointmentBooks) {
      onAppointmentBooks();
    }
  };

  return (
    <header className="sticky top-0 z-20 bg-stone-50/90 backdrop-blur-md border-b border-stone-200/80 px-6 py-4 flex items-center justify-between gap-4 flex-wrap">
      {/* Title & Date with Sidebar Toggle Button */}
      <div className="flex items-center gap-3">
        {onToggleSidebar && (
          <button
            onClick={onToggleSidebar}
            className="p-2 rounded-xl bg-white hover:bg-stone-100 text-stone-700 border border-stone-200/90 shadow-2xs transition-colors cursor-pointer flex items-center justify-center shrink-0"
            title="Toggle Sidebar Navigation"
          >
            <PanelLeft className="w-5 h-5 text-teal-700" />
          </button>
        )}
        <div>
          <h1 className="text-xl font-bold text-stone-900 tracking-tight flex items-center gap-2">
            <span>{isAdmin ? 'Administration' : isPatients ? 'Patient Chart' : isTemplate ? 'Office Intelligence' : 'Office Intelligence Home'}</span>
            {!isPatients && (
              <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-blue-50 text-blue-900 border border-blue-200 flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-blue-600 animate-pulse"></span>
                ASC Live Flow
              </span>
            )}
            <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-indigo-100 text-indigo-900 border border-indigo-300 flex items-center gap-1 shadow-2xs">
              v2.0
            </span>
          </h1>
          <p className="text-xs text-stone-500 font-medium mt-0.5">
            {isAdmin
              ? 'Practice setup, provider credentialing, & administrative document repository'
              : isPatients
              ? 'Longitudinal record with summary-first design'
              : isTemplate
              ? 'Monday, July 13, 2026 • Practice Name'
              : 'Monday, July 13, 2026 • Summit Surgical Center (ASC)'}
          </p>
        </div>
      </div>

      {/* Center Search Bar */}
      <div className="flex-1 max-w-sm relative hidden md:block">
        <Search className="w-4 h-4 text-stone-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder={isPatients ? "Search patients, appointments, tasks..." : "Search patients, appointments, procedures..."}
          className="w-full pl-9 pr-12 py-2 bg-white/90 rounded-full border border-stone-200 text-xs text-stone-800 placeholder-stone-400 focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:border-blue-600 transition-all shadow-2xs"
        />
        <div className="absolute right-3 top-1/2 -translate-y-1/2 text-[10px] font-semibold text-stone-400 bg-stone-100 px-1.5 py-0.5 rounded border border-stone-200">
          ⌘K
        </div>
      </div>

      {/* Quick Action Controls */}
      <div className="flex items-center gap-2">
        {isPatients && (
          <button
            onClick={onAddPatient}
            className="px-3.5 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold flex items-center gap-1.5 transition-colors shadow-2xs cursor-pointer mr-1"
          >
            <Plus className="w-4 h-4" />
            <span>Add Patient</span>
          </button>
        )}

        <button
          onClick={onRefresh}
          className="p-2 rounded-xl bg-white hover:bg-stone-100 border border-stone-200 text-stone-600 transition-colors shadow-2xs cursor-pointer"
          title="Refresh Schedule Status"
        >
          <RefreshCw className="w-4 h-4" />
        </button>

        {/* Appointment Books Settings Gear Icon Button */}
        <div className="relative" ref={dropdownRef}>
          <button
            onClick={() => setIsDropdownOpen(!isDropdownOpen)}
            className={`p-2 rounded-xl border text-xs font-semibold flex items-center gap-1.5 transition-all shadow-2xs cursor-pointer ${
              isDropdownOpen
                ? 'bg-indigo-600 text-white border-indigo-700 shadow-md ring-2 ring-indigo-500/20'
                : 'bg-white hover:bg-stone-100 border-stone-200 text-stone-700'
            }`}
            title="Appointment Books / Schedule Views"
            id="appointment-books-settings-btn"
          >
            <Settings className={`w-4 h-4 ${isDropdownOpen ? 'rotate-90 text-white' : 'text-indigo-600'} transition-transform duration-200`} />
            <span className="font-bold text-xs hidden sm:inline">Settings</span>
          </button>

          {/* Schedule Views Multi-Select Dropdown */}
          {isDropdownOpen && (
            <div className="absolute right-0 mt-2 w-72 bg-white rounded-2xl border border-stone-200 shadow-2xl p-4 z-50 animate-in fade-in slide-in-from-top-2 duration-150 space-y-3">
              <div className="flex items-center justify-between border-b border-stone-100 pb-2.5">
                <div>
                  <h4 className="text-xs font-extrabold text-stone-900 tracking-tight flex items-center gap-1.5">
                    <Calendar className="w-3.5 h-3.5 text-indigo-600" />
                    <span>Appointment Books</span>
                  </h4>
                  <p className="text-[10px] text-stone-500 font-medium">Select potential schedule views</p>
                </div>
                <button
                  type="button"
                  onClick={handleSelectAll}
                  className="text-[10px] font-bold text-indigo-600 hover:text-indigo-800 bg-indigo-50 hover:bg-indigo-100 px-2 py-0.5 rounded-md transition-colors cursor-pointer"
                >
                  {selectedViews.length === SCHEDULE_VIEW_OPTIONS.length ? 'Deselect All' : 'Select All'}
                </button>
              </div>

              {/* Rooms Section */}
              <div className="space-y-1">
                <div className="text-[10px] font-bold uppercase tracking-wider text-stone-400 px-1">
                  Operating Rooms
                </div>
                {SCHEDULE_VIEW_OPTIONS.filter((o) => o.category === 'room').map((opt) => {
                  const isChecked = selectedViews.includes(opt.id);
                  return (
                    <button
                      key={opt.id}
                      type="button"
                      onClick={() => toggleOption(opt.id)}
                      className={`w-full px-2.5 py-1.5 rounded-xl text-xs flex items-center justify-between transition-colors cursor-pointer font-medium ${
                        isChecked
                          ? 'bg-indigo-50/80 text-indigo-950 font-bold'
                          : 'hover:bg-stone-100 text-stone-700'
                      }`}
                    >
                      <span>{opt.label}</span>
                      <div className={`w-4 h-4 rounded border flex items-center justify-center transition-colors shrink-0 ${
                        isChecked
                          ? 'bg-indigo-600 border-indigo-600 text-white'
                          : 'border-stone-300 bg-white'
                      }`}>
                        {isChecked && <Check className="w-3 h-3 stroke-[3]" />}
                      </div>
                    </button>
                  );
                })}
              </div>

              {/* Doctors Section */}
              <div className="space-y-1 pt-1 border-t border-stone-100">
                <div className="text-[10px] font-bold uppercase tracking-wider text-stone-400 px-1">
                  Physicians & Surgeons
                </div>
                {SCHEDULE_VIEW_OPTIONS.filter((o) => o.category === 'doctor').map((opt) => {
                  const isChecked = selectedViews.includes(opt.id);
                  return (
                    <button
                      key={opt.id}
                      type="button"
                      onClick={() => toggleOption(opt.id)}
                      className={`w-full px-2.5 py-1.5 rounded-xl text-xs flex items-center justify-between transition-colors cursor-pointer font-medium ${
                        isChecked
                          ? 'bg-indigo-50/80 text-indigo-950 font-bold'
                          : 'hover:bg-stone-100 text-stone-700'
                      }`}
                    >
                      <span>{opt.label}</span>
                      <div className={`w-4 h-4 rounded border flex items-center justify-center transition-colors shrink-0 ${
                        isChecked
                          ? 'bg-indigo-600 border-indigo-600 text-white'
                          : 'border-stone-300 bg-white'
                      }`}>
                        {isChecked && <Check className="w-3 h-3 stroke-[3]" />}
                      </div>
                    </button>
                  );
                })}
              </div>

              {/* Apply / Switch View Footer */}
              <div className="pt-2 border-t border-stone-100 flex items-center justify-between gap-2">
                <span className="text-[10px] font-semibold text-stone-500">
                  {selectedViews.length} views selected
                </span>
                <button
                  type="button"
                  onClick={handleApplyViews}
                  className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-xl shadow-xs transition-colors cursor-pointer flex items-center gap-1"
                >
                  <span>Open Schedule</span>
                </button>
              </div>
            </div>
          )}
        </div>

        {/* User Initials Badge */}
        <div className="w-8.5 h-8.5 rounded-full bg-blue-600 text-white font-semibold text-xs flex items-center justify-center shadow-xs ml-1" title="User: Kevin T. (KT)">
          KT
        </div>
      </div>
    </header>
  );
}
