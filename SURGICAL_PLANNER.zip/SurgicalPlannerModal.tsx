import React, { useState, useEffect } from "react";

export interface SurgicalPlanPayload {
  patient: {
    name: string;
    mrn: string;
    procedure: string;
    surgeon?: string;
    date?: string;
  };
  imageBase64: string;
  planJson: any;
  timestamp?: string;
}

export interface SurgicalPlannerModalProps {
  isOpen: boolean;
  onClose: () => void;
  patient: {
    name: string;
    mrn: string;
    procedure: string;
    photoUrl?: string;
    dob?: string;
  };
  onSavePlan?: (payload: SurgicalPlanPayload) => void;
  plannerUrl?: string; // defaults to "/surgical-planner.html"
}

/**
 * SurgicalPlannerModal
 * 
 * Standalone embed wrapper for the Vityls 2D & 3D Surgical Planning Suite.
 * Easily added to any version of Vityls or external EHR by another developer or AI agent.
 */
export const SurgicalPlannerModal: React.FC<SurgicalPlannerModalProps> = ({
  isOpen,
  onClose,
  patient,
  onSavePlan,
  plannerUrl = "/surgical-planner.html",
}) => {
  const [iframeRef, setIframeRef] = useState<HTMLIFrameElement | null>(null);

  useEffect(() => {
    if (!isOpen) return;

    const handleMessage = (event: MessageEvent) => {
      const data = event.data;
      if (!data || typeof data !== "object") return;

      // Planner finished initializing: inject active patient demographics
      if (data.type === "VITLYS_READY" && iframeRef?.contentWindow) {
        iframeRef.contentWindow.postMessage(
          {
            type: "VITLYS_LOAD_PATIENT",
            patient: {
              name: patient.name,
              mrn: patient.mrn,
              procedure: patient.procedure,
            },
            photoUrl: patient.photoUrl,
          },
          "*"
        );
      }

      // User clicked "Save to Vityls" inside the planner
      if (data.type === "VITLYS_PLAN_SAVED") {
        if (onSavePlan && data.payload) {
          onSavePlan(data.payload);
        }
      }

      // User clicked "Back to Vityls" inside the planner
      if (data.type === "VITLYS_PLANNER_CLOSE") {
        onClose();
      }
    };

    window.addEventListener("message", handleMessage);
    return () => window.removeEventListener("message", handleMessage);
  }, [isOpen, iframeRef, patient, onSavePlan, onClose]);

  if (!isOpen) return null;

  return (
    <div
      style={{
        position: "fixed",
        inset: 0,
        zIndex: 99999,
        background: "rgba(11, 17, 32, 0.92)",
        display: "flex",
        flexDirection: "column",
        overflow: "hidden",
      }}
    >
      <iframe
        ref={setIframeRef}
        src={plannerUrl}
        title="Vityls Standalone Surgical Planning Suite"
        style={{
          width: "100%",
          height: "100%",
          border: "none",
        }}
        allow="clipboard-read; clipboard-write; camera"
      />
    </div>
  );
};

export default SurgicalPlannerModal;
