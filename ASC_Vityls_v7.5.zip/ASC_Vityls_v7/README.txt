ASC.Vityls v7 (release v7.5, 2026-10-05) — test build (fictional data only)
=========================================================================

WHAT THIS IS
A version of ASC.Vityls you can try on your own computer. It does not need the internet or a server.
Everything stays inside the browser on this computer. No patient information, voice or audio leaves
the device. It opens with three FICTIONAL test patients scheduled for today. Do not enter real patient data.

v7.5 CLINICAL FIXES
- Allergies from Medical History / intake REPLACE "Not Reported" on station FactCards (never append).
- Confirm (light green) writes allergies into the chart; Edit (light red) lets you change them.
- Allergy cards use light green (NKDA) / light red (allergies) / grey (not reported) everywhere.
- OR event times: tap once to stamp; tap again to edit a corrected HH:MM (audited).

HOW TO OPEN IT (Mac)
1. Double-click ASC_Vityls_v7.5.zip to unzip it. You get a folder named ASC_Vityls_v7.
2. Open that folder and double-click index.html. It opens in your default browser.
   Chrome, Safari, Edge and Firefox all work. Chrome or Safari is recommended.
3. If double-clicking opens it in the wrong program: right-click index.html > Open With > Google Chrome (or Safari).

HOW TO OPEN IT (Windows)
1. Right-click ASC_Vityls_v7.5.zip > Extract All… > Extract.
2. Open the extracted ASC_Vityls_v7 folder and double-click index.html. Chrome or Edge is recommended.

TRYING A CASE (clean start)
The build opens clean: three FICTIONAL patients scheduled today (Testa Fictional, Demo Patient-Two,
Sample Third), four fictional providers, default fee schedules, and NO forms in My Forms.
Stations only show forms that are in My Forms, so add forms first.
1. Practice > Forms & Workflow > Form Library. Open a form > Add to My Forms. Step 1: pick its station(s).
   Step 2: set who signs and in what order. Repeat for each form you want to test.
2. Patients > Add Patient or open a seeded chart. On Workstations, Known clinical facts shows Allergies
   with Confirm (green) / Edit (red). Reported intake allergies replace Not Reported until you Confirm.
3. OR Team station: OR event times — tap to stamp; tap again to correct the clock time.
4. Registered providers sign with their PIN. Every seeded provider's PIN is 1234.

START OVER
To wipe the test data, add ?reset-test-data to the end of the address in the browser and press Enter.
Example: .../ASC_Vityls_v7/index.html?reset-test-data
Test data is saved per browser. Chrome and Safari each keep their own copy.

OPTIONAL START SCRIPTS
You do not need these for normal testing. Use them only for the three legacy PDF-template screens,
because browsers block PDFs opened from a double-clicked file.
  Mac:     double-click start-mac.command
  Windows: double-click start-windows.bat
Each script serves the folder at http://127.0.0.1:8765. Close the window to stop it.

WHAT IS NOT REAL YET (by design)
No backend, no real logins, and no real speech recognition. Signatures and the audit trail live in browser storage.
See ASC_Vityls_v7_Changelog.md for the full list.
