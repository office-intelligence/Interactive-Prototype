@echo off
rem ASC.Vityls v7 test build - optional local launcher for Windows.
rem You normally do NOT need this: just double-click index.html.
cd /d "%~dp0"
set PORT=8765
py -3 -c "import http.server" >nul 2>nul
if %errorlevel%==0 goto usepy
python -c "import http.server" >nul 2>nul
if %errorlevel%==0 goto usepython
echo Python 3 is not installed, so opening index.html directly instead.
start "" "%~dp0index.html"
goto :eof
:usepy
echo ASC.Vityls v7 is running at http://127.0.0.1:%PORT%  (only this PC can reach it). Close this window to stop it.
start "" http://127.0.0.1:%PORT%/index.html
py -3 -m http.server %PORT% --bind 127.0.0.1
goto :eof
:usepython
echo ASC.Vityls v7 is running at http://127.0.0.1:%PORT%  (only this PC can reach it). Close this window to stop it.
start "" http://127.0.0.1:%PORT%/index.html
python -m http.server %PORT% --bind 127.0.0.1
