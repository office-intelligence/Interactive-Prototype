Vityls Patient Portal v0.5 (2026-10-15) - test build: Copilot-style Nightingale chat + Kevin's iMARSLINK portal, warm palette. Patient/practice data is fictional; the Doctor Finder uses the bundled snapshot of real public NPPES NPI records.
Unzip, open the folder, double-click index.html (Chrome or Edge).
- index.html -> Nightingale chat (guest mode, 3 free explanations). Use the "Chat | Portal" toggle in the sidebar to switch.
- Portal: Timeline, My Doctors, My Labs, My Health, Messages. Billing, plan, notifications and settings are in the profile menu (gear, bottom left).
- index.html?practice=coastline -> practice app; "Portal" in the top nav is the practice side.
- Deep links (what a text/email opens): index.html#portal/task/<item id>; sections: index.html#portal/view/<section>.
Demo accounts (password portal2026): jordan.rivera@example.test, alex.rivera@example.test.
All delivery (email/text, payments, FHIR, fax, wearables) is SIMULATED. Reset: add ?reset-portal to the address.
