# Medical.Vityls v2.0 — Changelog (Oct 22, 2026)

Medical.Vityls v2.0 is Surgery.Vityls v1.8 with every surgical part switched off. It is built from the same codebase (edition `MEDICAL`), so Surgery.Vityls is unchanged. All data is fictional, and all outside services are simulated.

> Note: an earlier test build was also called "Medical_Vityls_v2.0" (Front Door design, Oct 16). This build replaces it. Its zips were kept as `Medical_Vityls_v2.0_prev-2026-10-16*.zip`.

## What was removed (surgical only)
- Surgical cases. Visits are simple office, video or phone encounters and are not tied to any case.
- Price quotes, deposits, booking and clearance, the PCP checklist, Send to ASC, ASC steps, post-op and block time.
- Surgical coordination tasks. **The Patient Coordinator role stays**: it shares the Nurse/MA view, can receive flags and has its own flag list.
- Wording: "surgeon/surgery/procedure" now reads "doctor/visit" on every screen. The term "past surgical history" is kept, because it is a medical-history heading.

## The workflow: 5 steps
Scheduling → Front desk → Nurse/MA → Doctor → Checkout. Nothing is gated, and Save & close is the only way out of a workspace. Video and phone visits skip vitals.

## Kept from Surgery v1.8
- **Role views:** Front office, Nurse/MA (shared with the Patient Coordinator), Doctor and Practice Manager. Each role opens on the Chat page with its own to-do, and "See all roles" shows everyone's.
- **Flags:** flags go to the front desk, nursing, Medical Assistants, Patient Coordinators or the Practice Manager, and the reply comes back to the sender.
- **The note page:** a near-full-screen page with an H&P, SOAP or Simple note and a Nightingale draft. Missing notes stay on the doctor's to-do and never turn Overdue, and the doctor signs with a PIN.
- **Focused missing-item panels:** vitals, reason for visit, labs and flags.
- **Chat-only mode**, set per user, with a default per role chosen by the Practice Manager.
- **Provider isolation** for two doctors (Sam Patel, MD and Dana Whitfield, MD, both fictional), plus the audited "Cover a colleague's patient" step.
- **The sideways scheduler** with In Office, Video and Phone visits.
- Add Form, My Forms, and body charts and photos (generic tools, never required).

## New for Medical: Nightingale's medical to-dos
- **Labs to review** go to nursing.
- **Referrals to send** go to nursing or coordinators.
- **Follow-ups to book** go to the front office.
- **Refills:** Nightingale drafts the request from the medication list. Only the doctor approves or declines it, in a small panel. Nothing is sent or ordered; staff send approved refills through e-Rx, which is simulated in this build.

## Simpler pages
- Today drops the extra KPI and summary block.
- Unsigned notes appear only on the doctor's to-do, not a second time.
- The doctor workspace has no Price quote or Decision tabs.

## Tests
- Unit tests (node:test): 104/104, including 9 new Medical tests in `tests/medical20.test.ts`.
- Walk-through `scripts/shots_med20.py` at 1440, 1180 and 768: 132/132. Its scan for surgical wording on every visited page found nothing.
- Surgery v1.8 walk-through (`shots_v18`) rebuilt from this branch: 180/180, so Surgery is unchanged.
- Smoke run at 1180 (the Surgery v1.8 regression harness plus the Medical v1.0 part, pointed at this build): 241/260. Most of the 19 failures are legacy checks for retired v1.0 screens or surgical items (price-quote card, Diagnosis/Procedure column, the old station page). A few are not yet confirmed (scheduler column selector, icon rail on tablet, IndexedDB template, Print/Send presets). Log: report/smoke_med20_1180.log.

## For Henry
`Case_Data_Model_for_Henry.md` has a new section, "Medical.Vityls v2.0". It lists the tables Medical leaves unused or optional. The schema is the same as Surgery's.
