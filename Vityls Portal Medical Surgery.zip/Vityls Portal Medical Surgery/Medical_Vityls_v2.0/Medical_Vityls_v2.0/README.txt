Medical.Vityls v2.0 (2026-10-22) - test build for an internal medicine / family practice (fictional data only)
=============================================================================================================

WHAT THIS IS
Medical.Vityls v2.0 is Surgery.Vityls v1.8 with every surgical part switched off. That means no cases, quotes,
booking or clearance, ASC or post-op. Visits are simple office, video or phone encounters, and the workflow is
Scheduling > Front desk > Nurse/MA > Doctor > Checkout.

It runs on your own computer and needs no internet or server. Everything stays in this browser.
Texts, emails, e-Rx, portal delivery, dictation and Nightingale drafts are SIMULATED.
Do not enter real patient data.

HOW TO OPEN IT
1. Unzip Medical_Vityls_v2.0.zip.
2. Open the Medical_Vityls_v2.0 folder.
3. Double-click index.html (Chrome, Safari or Edge).

TRY IT
1. Use the "Session" menu at the top to switch people.
   - Front Desk Tester: front office
   - Casey Morgan: RN
   - Morgan Avery: Medical Assistant
   - Riley Shaw: Patient Coordinator
   - Sam Patel, MD and Dana Whitfield, MD: the two doctors
   - Pat Quinn: Practice Manager
2. Each person opens on the Chat page with their own to-do. "See all roles" shows everyone's.
3. As Dr. Patel, click "Visit note missing". The near-full-screen note page opens with a Nightingale draft.
   Choose H&P, SOAP or Simple, edit the note, then sign with your PIN.
4. As Dr. Patel, click "Refill drafted" to approve or decline the refill. Nothing is ever sent or ordered.
5. Use "Flag a team" to send a flag to the front desk, nursing, MAs, Patient Coordinators or the Practice Manager.
6. Turn on "Chat only" at the top to hide the side menu.

SIGNING
Test PIN for every fictional person: 1234. Nightingale never signs, orders or decides.

TEST SWITCHES (typed at the end of the address)
  ?reset-test-data   start over with fresh fictional Medical data

See Medical_v2.0_Changelog.md in this folder.
