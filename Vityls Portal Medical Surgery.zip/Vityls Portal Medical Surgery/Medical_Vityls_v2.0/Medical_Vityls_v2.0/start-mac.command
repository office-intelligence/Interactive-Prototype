#!/bin/bash
# Medical.Vityls v2.0 test build - optional local launcher for Mac.
# You normally do NOT need this: just double-click index.html.
# Use this only if you want the PDF-template screens, which browsers block from file://.
cd "$(dirname "$0")"
PORT=8767
if python3 -c 'import http.server' >/dev/null 2>&1; then
  echo "Medical.Vityls v2.0 is running at http://127.0.0.1:$PORT  (only this Mac can reach it)."
  echo "Close this window to stop it."
  (sleep 1; open "http://127.0.0.1:$PORT/index.html") &
  python3 -m http.server "$PORT" --bind 127.0.0.1
else
  echo "Python 3 is not installed, so opening index.html directly instead."
  open index.html
fi
