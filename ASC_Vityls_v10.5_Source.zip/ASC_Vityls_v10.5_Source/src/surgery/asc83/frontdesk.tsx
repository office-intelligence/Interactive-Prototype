import { logSched, setReminders, reminders } from '../asc86/store86';
import { ExcBox } from '../asc84/exc';
/* ASC.Vityls v8.3 · front desk: Case details popup (v7.5 style) from Today, the clear Arrival & check-in flow
 * (identity → ID/insurance → responsible adult → front-desk forms → balance → arrival time → "Checked in, handed to nursing"),
 * cancel case with confirmation + reason, and payment collection (at check-in or 7–14 days before surgery). Payments simulated. */
import React, { useState } from 'react';
import { medRepo, ageFrom, isoDay } from '../../med/record';
import { useActor, useMedTick } from '../../med/ui';
import { useSv } from '../ui';
import { repo } from '../../v6/dataLayer';
import { svRead, svWrite } from '../store';
import * as A from '../asc8/logic';
import * as S from '../asc8/store';
import { XClose, CaseCard, FormInPlace } from '../asc82/common';
import { CardCapture } from '../asc82/benches';
import { use81 } from '../asc81/store81';
import { caseMoney, collectPayment, casePays, payTypeOf, toCollect, unpaidCases, inCollectWindow, PAY_LABEL, daysBetween } from './pay';
import { surgeonColor } from './booking';
import { openCardPay } from '../asc88/ui88';

const money = (n: number) => `$${n.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
export const PayChip: React.FC<{ c: A.AscCase }> = ({ c }) => { const m = caseMoney(c); return <span className={`a83-pay ${m.status}`} data-testid="a83-pay-chip" data-status={m.status}>{PAY_LABEL[m.status]}{m.balance > 0 ? ` · ${money(m.balance)} due` : ''}</span>; };
const Modal: React.FC<{ title: string; testId: string; onClose: () => void; children: React.ReactNode; foot?: React.ReactNode; wide?: boolean }> = ({ title, testId, onClose, children, foot, wide }) =>
  <div className="a81-modal a83-modal" onMouseDown={e => { if (e.target === e.currentTarget) onClose(); }}><div className={`a81-dialog a83-dlg ${wide ? 'wide' : ''}`} role="dialog" aria-label={title} data-testid={testId}>
    <div className="a81-dhead"><b>{title}</b><span style={{ marginLeft: 'auto' }} /><XClose onClick={onClose} testId={`${testId}-close`} /></div><div className="a81-dbody">{children}</div>{foot && <div className="a83-foot">{foot}</div>}</div></div>;

/* ---------- collect payment (inline) ---------- */
export const CollectPay: React.FC<{ c: A.AscCase; when: 'check-in' | 'pre-service'; onDone?: () => void }> = ({ c, when, onDone }) => {
  const [actor] = useActor(); const m = caseMoney(c); const [amt, setAmt] = useState(String(m.balance || '')); const [method, setMethod] = useState('Card (simulated)'); const [ref, setRef] = useState(''); const [err, setErr] = useState(''); const [last, setLast] = useState('');
  if (m.balance <= 0) return <div className="a83-paybox ok" data-testid="a83-paid">✓ {m.status === 'none' ? 'No patient balance for this case' : `Paid in full · ${money(m.paid)}`}{last && ` · receipt ${last}`}</div>;
  return <div className="a83-paybox" data-testid="a83-collect"><div className="row"><b>Balance due {money(m.balance)}</b><span className="sv-small sv-muted">Estimate {money(m.due)} ({payTypeOf(c)}) · paid {money(m.paid)}</span></div>
    <div className="a83-grid4"><label className="a83-f"><span className="a83-l">Amount</span><input className="sv-input" inputMode="decimal" value={amt} onChange={e => setAmt(e.target.value)} data-testid="a83-pay-amt" /></label>
      <p className="sv-small sv-muted" style={{ gridColumn: 'span 3', alignSelf: 'end' }}>Collect opens the card-processing window (card, cash or check).</p></div>
    {err && <p className="a81-err">{err}</p>}
    <div className="a81-foot"><button type="button" className="a8-btn pri" onClick={() => openCardPay({ cid: c.id, amount: parseFloat(amt) || m.balance, when, onDone: p => { setLast(p.receipt); setErr(''); onDone?.(); } })} data-testid="a83-pay-collect">Collect {amt ? money(parseFloat(amt) || 0) : ''}</button></div>
    <p className="sv-small sv-muted">Simulated: nothing is charged. A receipt posts to the patient’s Billing &amp; payments.</p></div>;
};

/* ---------- cancel case ---------- */
const REASONS = ['Patient request', 'Medical clearance not obtained', 'Patient ill', 'Surgeon unavailable', 'Insurance / payment', 'No-show', 'Other'];
export function cancelCase(c: A.AscCase, reason: string, note: string, by: string, role: string) {
  if (!reason) throw new Error('Choose a reason.'); const at = new Date().toISOString();
  svWrite('asc83-cancelled', [...svRead<any[]>('asc83-cancelled', []), { ...c, cancelled: { reason, note, by, role, at } }]);
  logSched(c.pid, c.id, { at, by, role, kind: 'cancelled', from: `${c.date} ${c.time} ${c.room}`, reason: `${reason}${note ? ` · ${note}` : ''}`, notices: ['Reminders cancelled (simulated)', 'Cancellation notice to patient (simulated)', 'Open tasks closed'] }); setReminders(c.id, reminders(c.id).map(r => ({ ...r, status: 'cancelled' })));
  svWrite('asc8-cases', S.cases().filter(x => x.id !== c.id)); const v = medRepo.visit(c.visitId); if (v) medRepo.saveVisit({ ...v, step: 'cancelled', cancelled: { reason, by, at } } as any);
  repo.audit({ caseId: `asc8:${c.id}`, user: by, role, action: 'asc83.cancel' as any, detail: `Case cancelled: ${c.procedure} on ${c.date} · ${reason}${note ? ` · ${note}` : ''}` }); window.dispatchEvent(new Event('vityls-med-updated'));
}
export const cancelledCases = (pid?: string) => svRead<any[]>('asc83-cancelled', []).filter(c => !pid || c.pid === pid);

/* ---------- Case details (Today click) ---------- */
export const CaseDetails: React.FC<{ cid: string; onClose: () => void; onCheckIn: () => void; onStation?: () => void }> = ({ cid, onClose, onCheckIn, onStation }) => {
  useMedTick(); const [actor] = useActor(); const { go, toast } = useSv(); const c = S.caseById(cid); const [cx, setCx] = useState(false); const [why, setWhy] = useState(''); const [note, setNote] = useState(''); const [err, setErr] = useState('');
  if (!c) return null; const p = medRepo.patient(c.pid)!; const m = caseMoney(c);
  const Row: React.FC<{ k: string; children: React.ReactNode }> = ({ k, children }) => <div className="a83-kv"><span>{k}</span><b>{children}</b></div>;
  return <Modal title="Case details" testId="a83-case-details" onClose={onClose}
    foot={!cx ? <><button type="button" className="sv-link sv-small a83-cancel-link" onClick={() => setCx(true)} data-testid="a83-cancel-open">Cancel case…</button><span style={{ flex: 1 }} />{onStation && <button type="button" className="a8-btn" onClick={onStation} data-testid="a83-open-station">Station items</button>}<button type="button" className="a8-btn" onClick={() => { onClose(); go({ type: 'chart', pid: c.pid } as any); }} data-testid="a83-open-chart">Open chart</button>{c.loc === 'scheduled' ? <button type="button" className="a8-btn pri" onClick={onCheckIn} data-testid="a83-checkin-open">Check in</button> : <span className="a81-ok">{A.LOC_LABEL[c.loc]}</span>}</> : undefined}>
    <CaseCard c={c} station="front" />
    <div className="a81-stephead v103-bk-head"><span className="a81-sttag" data-testid="v103-booking-tag">Step 1 · Booking</span><span className="a81-progress done">{A.LOC_LABEL[c.loc]}</span></div>
    {(() => { /* v10.5: case fields can hold objects (e.g. nursing's implants check is { none: true }); only text is rendered */
      const txt = (v: any): string => v == null || v === false ? '' : typeof v === 'string' || typeof v === 'number' ? String(v) : Array.isArray(v) ? v.map(txt).filter(Boolean).join(', ') : typeof v === 'object' ? (v.none === true ? 'None' : txt(v.list ?? v.text ?? v.value ?? v.name ?? v.detail ?? '')) : '';
      const booked = c.d.bookedAt || c.audit?.[0]?.at; const bookedBy = c.d.bookedBy || c.audit?.[0]?.by;
      const G: React.FC<{ t: string; children: React.ReactNode; tid?: string }> = ({ t, children, tid }) => <section className="a82-sec v103-bk-sec" data-testid={tid}><h3 className="a81-h3">{t}</h3><div className="a83-kvs">{children}</div></section>;
      return <div className="v103-booking" data-testid="v103-booking">
        <G t="Case" tid="v103-bk-case"><Row k="Procedure">{c.procedure}{c.side && !c.procedure.toLowerCase().includes(c.side.toLowerCase()) ? ` · ${c.side}` : ''}</Row><Row k="CPT">{c.cpt || '—'}</Row><Row k="Surgeon"><i className="a83-dot" style={{ background: surgeonColor(c.surgeon) }} />{c.surgeon}</Row><Row k="Assistant">{txt(c.d.assistant) || '—'}</Row>
          <Row k="Date & time">{new Date(c.date + 'T12:00').toLocaleDateString([], { weekday: 'short', month: 'short', day: 'numeric' })} · {c.time.replace(/^0/, '')} · {c.durationMin} min</Row><Row k="Room">{c.room}</Row>
          <Row k="Anesthesia type">{txt(c.d.anesType) || '—'}</Row><Row k="Anesthesia provider">{c.anesthesia || '—'}</Row><Row k="Special equipment / implants">{txt(c.d.equipment) || txt(c.d.implants) || 'None noted'}</Row></G>
        <G t="Booking" tid="v103-bk-booking"><Row k="Booked">{booked && !isNaN(new Date(booked).getTime()) ? new Date(booked).toLocaleString('en-US', { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' }) : '—'}{bookedBy ? ` · ${txt(bookedBy).replace(/,.*$/, '')}` : ''}</Row><Row k="Booked from">{c.from === 'Surgery.Vityls' ? 'Surgeon office request' : 'ASC scheduler'}</Row>
          <div className="a83-kv" style={{ gridColumn: '1/-1' }}><span>Booking request notes</span><b data-testid="v103-bk-notes">{txt(c.d.bookingNotes) || txt(c.d.requestNotes) || 'No notes on the booking request'}</b></div></G>
        <G t="Patient & payment" tid="v103-bk-patient"><Row k="Age">{ageFrom(p.dob)} years</Row><Row k="Gender">{p.sex}</Row><Row k="Allergies">{p.allergies.length ? <span className="alg">{p.allergies.join('; ')}</span> : 'NKDA'}</Row><Row k="Payment">{payTypeOf(c)} · <PayChip c={c} /></Row><Row k="Status">{A.LOC_LABEL[c.loc]}</Row></G>
      </div>; })()}
    {cx && <div className="a83-cancel" data-testid="a83-cancel"><b>Cancel this case?</b><p className="sv-small">It comes off the schedule and Today; the chart keeps it as cancelled, and the reason is in the audit.</p>
      <div className="a83-grid4"><label className="a83-f" style={{ gridColumn: 'span 2' }}><span className="a83-l">Reason</span><select className="sv-input" value={why} onChange={e => setWhy(e.target.value)} data-testid="a83-cancel-reason"><option value="">Choose…</option>{REASONS.map(r => <option key={r}>{r}</option>)}</select></label><label className="a83-f" style={{ gridColumn: 'span 2' }}><span className="a83-l">Note</span><input className="sv-input" value={note} onChange={e => setNote(e.target.value)} /></label></div>
      {err && <p className="a81-err">{err}</p>}<div className="a81-foot"><button type="button" className="a8-btn" onClick={() => setCx(false)}>Keep case</button><button type="button" className="a8-btn danger" onClick={() => { try { cancelCase(c, why, note, actor.name, actor.role); toast(`${p.name}'s case was cancelled (${why}).`); onClose(); } catch (e: any) { setErr(e.message); } }} data-testid="a83-cancel-confirm">Cancel case</button></div></div>}
  </Modal>;
};

/* ---------- Arrival & check-in flow ---------- */
const FD_FORMS: [string, string, string][] = [['forms', 'Registration & insurance and health questionnaires signed', 'ASC_Registration_Insurance.html'], ['financial', 'Financial: card authorization & cash fee disclosure signed', 'ASC_Financial.html']];
const CiStep: React.FC<{ n: number; t: string; ok: boolean; children: React.ReactNode }> = ({ n, t, ok, children }) => <section className={`a82-sec a83-step ${ok ? 'ok' : ''}`} data-testid="a83-ci-step" data-ok={ok ? '1' : '0'}><div className="a82-sh"><span className="n">{ok ? '✓' : n}</span><h3 className="a81-h3">{t}</h3></div>{children}</section>;
export const CheckInFlow: React.FC<{ cid: string; onDone?: (m: string) => void; embedded?: boolean }> = ({ cid, onDone }) => {
  useMedTick(); use81(); const [actor] = useActor(); const { toast } = useSv(); const c = S.caseById(cid)!; const p = medRepo.patient(c.pid)!; const s = use81(); const cards = s.ai(c.id).v82?.cards || {};
  const [st, setSt] = useState<Record<string, any>>(() => ({ ident: false, idok: !!c.d.id, forms: !!c.d.forms, financial: !!c.d.financial, insurance: !!c.d.insurance, adultName: c.d.adult?.name || '', adultPhone: c.d.adult?.phone || '', present: !!c.d.adult?.present, arrival: c.d.arrival || '' }));
  const [form, setForm] = useState(''); const [err, setErr] = useState(''); const set = (k: string, v: any) => setSt(x => ({ ...x, [k]: v }));
  const nCards = ['idFront', 'insFront'].filter(k => cards[k]).length; const m = caseMoney(c);
  const steps = [{ k: 'Identity', ok: !!st.ident }, { k: 'ID & insurance', ok: !!st.idok }, { k: 'Responsible adult', ok: !!st.adultName && !!st.present }, { k: 'Front-desk forms', ok: st.forms && st.financial && st.insurance }, { k: 'Balance', ok: m.balance <= 0 || !!st.payLater }, { k: 'Arrival time', ok: !!st.arrival }];
  const ready = steps.every(x => x.ok); const done = c.loc !== 'scheduled';
  const miss = steps.filter(x => !x.ok).map(x => x.k);
  const go = () => {
    let x = S.caseById(c.id)!; const by = actor.name, role = actor.role, at = new Date().toISOString(); const put = (k: string, v: any, w: string) => { if (!A.isDone(x, k)) x = S.setValue(x, k, v, by, role, w); };
    if (st.forms) put('forms', { by, at }, 'Patient forms signed'); if (st.financial) put('financial', { by, at }, 'Financial form signed'); if (st.insurance) put('insurance', m.balance <= 0 ? 'Verified · paid' : `Verified · ${st.payLater ? 'balance deferred: ' + st.payLater : 'balance open'}`, 'Insurance verified');
    if (st.idok && st.ident) put('id', { by, at, cards: nCards }, `Identity (2 identifiers) and ID & insurance confirmed${nCards ? ` · ${nCards} card image(s)` : ''}`); if (st.adultName) x = S.setValue(x, 'adult', { name: st.adultName, phone: st.adultPhone, present: !!st.present }, by, role, `Responsible adult: ${st.adultName}`);
    x = S.setValue(x, 'arrival', st.arrival || S.nowTime(), by, role, `Arrived ${st.arrival || S.nowTime()}`);
    if (miss.length) x = S.setValue(x, 'exceptions', { ...(x.d.exceptions || {}), checkin: { items: miss, by, at } }, by, role, `Checked in with exceptions: ${miss.join('; ')}`);
    try { S.move(x, 'arrived', by, role); } catch (e: any) { return setErr(e.message); }
    S.raiseFlag({ from: by, fromRole: role, to: 'preop', pid: c.pid, caseId: c.id, text: `${p.name} is checked in and ready for pre-op nursing.` }); toast(`${p.name} checked in · handed to pre-op nursing.`); onDone?.(`${p.name} checked in · handed to nursing.`); };
  if (done) return <div className="a83-ci-done" data-testid="a83-checked-in"><div className="big">✓ Checked in · handed to nursing</div><p>{p.name} arrived {c.d.arrival || ''}. Pre-op nursing was flagged; the board shows <b>{A.LOC_LABEL[c.loc]}</b>.</p></div>;
  return <div className="a83-checkin" data-testid="a83-checkin">
    {form && <FormInPlace c={c} file={form} station="frontOffice" onClose={() => setForm('')} />}
    <div className="a83-ci-bar" data-testid="a83-ci-progress">{steps.map((x, i) => <span key={x.k} className={x.ok ? 'ok' : ''}>{x.ok ? '✓' : i + 1} {x.k}</span>)}</div>
    <CiStep n={1} t="Identity" ok={!!st.ident}><label className="a82-ck row"><input type="checkbox" checked={st.ident} onChange={e => set('ident', e.target.checked)} data-testid="a83-ci-ident" /><span className="l">Patient states name and date of birth: <b>{p.name}</b>, DOB <b>{p.dob}</b> ({ageFrom(p.dob)} y). Matches the chart and ID.</span></label></CiStep>
    <CiStep n={2} t="ID & insurance cards" ok={!!st.idok}><p className="sv-small">{nCards >= 2 ? '✓ Card images on file.' : 'Capture the cards in ID & insurance cards above.'}</p>
      <label className="a82-ck row"><input type="checkbox" checked={st.idok} onChange={e => set('idok', e.target.checked)} data-testid="a83-ci-idok" /><span className="l">Photo ID and insurance card checked against the chart{nCards ? '' : ' (no images needed if already on file)'}</span></label></CiStep>
    <CiStep n={3} t="Responsible adult" ok={!!st.adultName && !!st.present}><div className="a83-grid4"><label className="a83-f" style={{ gridColumn: 'span 2' }}><span className="a83-l">Name</span><input className="sv-input" value={st.adultName} onChange={e => set('adultName', e.target.value)} data-testid="a83-ci-adult" /></label><label className="a83-f" style={{ gridColumn: 'span 2' }}><span className="a83-l">Phone</span><input className="sv-input" value={st.adultPhone} onChange={e => set('adultPhone', e.target.value)} data-testid="a83-ci-adult-phone" /></label></div>
      <label className="a82-ck row"><input type="checkbox" checked={st.present} onChange={e => set('present', e.target.checked)} data-testid="a83-ci-present" /><span className="l">Present now, or reachable and driving the patient home</span></label></CiStep>
    <CiStep n={4} t="Front-desk forms" ok={st.forms && st.financial && st.insurance}>{FD_FORMS.map(([k, l, f]) => <div key={k} className="a82-ck row a83-formrow"><input type="checkbox" checked={st[k]} onChange={e => set(k, e.target.checked)} data-testid={`a83-ci-${k}`} /><span className="l">{l}{c.d[k] && <span className="a82-onfile">on file</span>}</span><button type="button" className="sv-link sv-small" onClick={() => setForm(f)} data-testid={`a83-ci-open-${k}`}>Open</button></div>)}
      <label className="a82-ck row"><input type="checkbox" checked={st.insurance} onChange={e => set('insurance', e.target.checked)} data-testid="a83-ci-insurance" /><span className="l">Insurance verified with the plan ({payTypeOf(c)})</span></label></CiStep>
    <CiStep n={5} t="Balance" ok={m.balance <= 0 || !!st.payLater}><CollectPay c={c} when="check-in" />{m.balance > 0 && <label className="a82-ck row"><input type="checkbox" checked={!!st.payLater} onChange={e => set('payLater', e.target.checked ? 'approved by manager' : '')} data-testid="a83-ci-paylater" /><span className="l">Don’t collect today (payment plan / approved exception, noted in the audit)</span></label>}</CiStep>
    <CiStep n={6} t="Arrival time" ok={!!st.arrival}><div className="a82-row"><input className="sv-input" style={{ width: 140 }} value={st.arrival} onChange={e => set('arrival', e.target.value)} placeholder="07:05 AM" data-testid="a83-ci-arrival" /><button type="button" className="a8-btn" onClick={() => set('arrival', S.nowTime())} data-testid="a83-ci-now">Now</button></div></CiStep>
    {err && <p className="a81-err" data-testid="a83-ci-err">{err}</p>}
    {!ready && <ExcBox items={miss} tid="a84-ci-exc" note="Not blocking: you can check in now; missing items stay on the to-do list for front desk." />}
    <div className="a81-foot"><span className={`a81-progress ${ready ? 'done' : ''}`}>{steps.filter(x => x.ok).length} of {steps.length} done</span><button type="button" className="a8-btn pri" onClick={go} data-testid="a83-ci-go">{ready ? <>Check in &amp; hand to nursing</> : `Check in with exceptions (${miss.length})`}</button></div>
  </div>;
};
/** v10: every Check in entry point opens the SAME slide-over (Arrival bench: documents present + check-in). */
export const CheckInDialog: React.FC<{ cid: string; onClose: () => void }> = ({ cid, onClose }) => {
  React.useEffect(() => { window.dispatchEvent(new CustomEvent('asc81-bench', { detail: { bench: 'arrival', cid } })); onClose(); }, [cid]); return null; };
export const CheckInDialogLegacy: React.FC<{ cid: string; onClose: () => void }> = ({ cid, onClose }) => { const c = S.caseById(cid); const [msg, setMsg] = useState('');
  return <Modal title="Arrival & check-in" testId="a83-checkin-dialog" onClose={onClose} wide foot={msg ? <button type="button" className="a8-btn pri" onClick={onClose} data-testid="a83-ci-close">Done</button> : undefined}>{c && <div className="a82-dcase" style={{ padding: '0 0 8px' }}><CaseCard c={c} station="front" /></div>}<CheckInFlow cid={cid} onDone={setMsg} /></Modal>; };

/* ---------- 7–14 day collection to-do ---------- */
export const CollectCard: React.FC = () => { useMedTick(); const list = toCollect(); const T = isoDay(); const [open, setOpen] = useState<string>('');
  if (!list.length) return null;
  return <section className="a83-collect" data-testid="a83-collect-card"><div className="a82-sh"><h3 className="a81-h3">Collect before surgery</h3><span className="a83-badge" data-testid="a83-collect-badge">{list.length}</span><span className="sv-small sv-muted">Date of service in 7–14 days with an unpaid or partial balance</span></div>
    {list.map(c => { const p = medRepo.patient(c.pid)!; return <div key={c.id} className="a83-collect-row" data-testid="a83-collect-row"><div className="min-w-0 flex-1"><b>{p.name}</b> <span className="sv-small sv-muted">{c.procedure} · {c.surgeon.replace(/,.*$/, '')} · DOS {new Date(c.date + 'T12:00').toLocaleDateString([], { month: 'short', day: 'numeric' })} (in {daysBetween(T, c.date)} days)</span></div><PayChip c={c} /><button type="button" className="a8-btn" onClick={() => setOpen(open === c.id ? '' : c.id)} data-testid="a83-collect-open">{open === c.id ? 'Hide' : 'Collect'}</button>
      {open === c.id && <div style={{ flexBasis: '100%' }}><CollectPay c={c} when="pre-service" /></div>}</div>; })}</section>; };
export { casePays };
/* Billing → Unpaid cases (ASC): search + filter, collect inline. */
export const UnpaidCases: React.FC = () => { useMedTick(); const [q, setQ] = useState(''); const [f, setF] = useState<'all' | 'window' | 'unpaid' | 'partial'>('all'); const [open, setOpen] = useState(''); const T = isoDay();
  const list = unpaidCases().filter(c => { const m = caseMoney(c); const p = medRepo.patient(c.pid); if (q && !`${p?.name} ${c.procedure} ${c.surgeon} ${p?.id}`.toLowerCase().includes(q.toLowerCase())) return false; if (f === 'window') return inCollectWindow(T, c.date, m.status); if (f === 'unpaid' || f === 'partial') return m.status === f; return true; }).sort((a, b) => a.date.localeCompare(b.date));
  const total = list.reduce((n, c) => n + caseMoney(c).balance, 0);
  return <section className="v14-card" data-testid="billing-unpaid"><h2>Unpaid cases</h2>
    <div className="a83-docbar"><input className="sv-input" placeholder="Search patient, procedure, surgeon, MRN" value={q} onChange={e => setQ(e.target.value)} data-testid="a83-unpaid-q" style={{ flex: 1, minWidth: 180 }} />
      <select className="sv-input" value={f} onChange={e => setF(e.target.value as any)} data-testid="a83-unpaid-filter"><option value="all">All open balances</option><option value="window">Due to collect now (DOS in 7–14 days)</option><option value="unpaid">Unpaid</option><option value="partial">Partially paid</option></select></div>
    <p className="sv-small sv-muted">{list.length} case{list.length === 1 ? '' : 's'} · ${total.toLocaleString('en-US', { minimumFractionDigits: 2 })} open</p>
    <div className="a83-scroll"><table className="sv-table"><thead><tr><th>DOS</th><th>Patient</th><th>Procedure</th><th>Payment type</th><th>Balance</th><th>Status</th><th /></tr></thead><tbody>
      {list.map(c => { const m = caseMoney(c); const p = medRepo.patient(c.pid)!; return <React.Fragment key={c.id}><tr data-testid="a83-unpaid-row"><td>{c.date}{inCollectWindow(T, c.date, m.status) && <span className="a83-badge" style={{ marginLeft: 6 }}>collect</span>}</td><td>{p.name}</td><td>{c.procedure}</td><td>{payTypeOf(c)}</td><td>${m.balance.toFixed(2)}</td><td><span className={`a83-pay ${m.status}`}>{PAY_LABEL[m.status]}</span></td><td><button type="button" className="sv-link sv-small" onClick={() => setOpen(open === c.id ? '' : c.id)} data-testid="a83-unpaid-collect">Collect</button></td></tr>
        {open === c.id && <tr><td colSpan={7}><CollectPay c={c} when="pre-service" /></td></tr>}</React.Fragment>; })}</tbody></table></div></section>; };
