/*
 * Surgery.Vityls Front Door · Chat home (mockups/surgery-home.html). A centered greeting, the ask box and chips; a chat
 * becomes a thread kept on this device. Answers come from the same scripted, on-device Nightingale (globalAnswer) the
 * pages use. Nightingale reads and points; it never signs, orders, diagnoses or gives a go/no-go. Actions open only when
 * the user taps them.
 */
import React, { useEffect, useRef, useState } from 'react';
import { ArrowUp, Mic } from 'lucide-react';
import { useActor, useMedTick } from '../../med/ui';
import { uid, isoDay, medRepo } from '../../med/record';
import { globalAnswer } from '../nightingale';
import { Cites, useSv } from '../ui';
import { FdHero } from '../../frontdoor/FdShell';
import { fdChat, saveFdChat, FdChatRec } from './chats';
import { displayName } from '../v07/Today7';
import { RoleTodo } from '../v17/ui';
import { isAscEd } from '../../edition';
import { AscTodo } from '../asc8/today';

export const SurgeryChat: React.FC<{ chatId: string; onChat: (id: string) => void }> = ({ chatId, onChat }) => {
  useMedTick(); const [actor] = useActor(); const { go, toast, setTab } = useSv();
  const [q, setQ] = useState(''); const [busy, setBusy] = useState(false); const [, bump] = useState(0); const end = useRef<HTMLDivElement>(null);
  useEffect(() => { const f = () => bump(x => x + 1); window.addEventListener('fd-chats', f); return () => window.removeEventListener('fd-chats', f); }, []);
  const chat = chatId ? fdChat(chatId) : undefined;
  useEffect(() => { end.current?.scrollIntoView?.({ block: 'end' }); }, [chat?.msgs.length, busy]);
  const ask = (text: string) => {
    const t = text.trim(); if (!t) return; setQ('');
    const now = new Date().toISOString();
    const c: FdChatRec = chat ? { ...chat, msgs: [...chat.msgs, { who: 'me', text: t, at: now }] } : { id: uid('chat'), title: t.slice(0, 60), at: now, by: actor.name, msgs: [{ who: 'me', text: t, at: now }] };
    saveFdChat(c); if (!chat) onChat(c.id); setBusy(true);
    window.setTimeout(() => { const a = globalAnswer(t); const cur = fdChat(c.id) || c; saveFdChat({ ...cur, msgs: [...cur.msgs, { who: 'ng', text: a.text, cites: a.cites, pid: a.pid, act: a.act, at: a.at }] }); setBusy(false); }, 260);
  };
  const h = new Date().getHours(); const hello = h < 12 ? 'Good morning' : h < 17 ? 'Good afternoon' : 'Good evening';
  const T = isoDay(); const today = medRepo.visits().filter(v => v.date === T);
  const box = <form className="fd-box" role="search" onSubmit={e => { e.preventDefault(); ask(q); }}>
    <label htmlFor="fd-ask" className="sr-only">Ask Nightingale</label>
    <input id="fd-ask" value={q} onChange={e => setQ(e.target.value)} placeholder="Ask Nightingale about today, a patient or the schedule…" autoComplete="off" data-testid="fd-chat-input" />
    <button type="button" className="fd-icon" aria-label="Voice (simulated)" title="Simulated: nothing is recorded" onClick={() => { setQ('Who’s next?'); toast('Simulated voice: nothing was recorded. A sample question was typed for you.'); }}><Mic size={17} /></button>
    <button type="submit" className="fd-send" aria-label="Send" data-testid="fd-chat-send"><ArrowUp size={18} /></button>
  </form>;
  const actLabel = (a: any) => a.type === 'station' ? 'Open workspace' : a.type === 'chart' ? 'Open chart' : a.type === 'panel' ? 'Open source' : 'Open page';
  if (!chat) {
    const chips: { label: string; run: () => void; task?: boolean; id: string }[] = [
      { id: 'today', label: `Today · ${today.length} ${isAscEd ? 'case' : 'visit'}${today.length === 1 ? '' : 's'}`, run: () => setTab('home') },
      { id: 'next', label: 'Who’s next?', run: () => ask('Who’s next?') },
      { id: 'schedule', label: 'Schedule', run: () => setTab('schedule') },
      { id: 'patients', label: 'Find a patient', run: () => setTab('patients') }];
    return <div data-testid="fd-chat-home"><FdHero greet={`${hello}, ${displayName(actor.name, actor.role)}`} sub={<span data-testid="fd-chat-brief">{today.length ? `${today.length} ${isAscEd ? 'case' : 'visit'}${today.length === 1 ? '' : 's'} on today’s ${isAscEd ? 'OR ' : ''}schedule, ${today.filter(v => v.step === 'complete').length} done. Ask about a patient, the schedule or what is waiting.` : 'No visits on today’s schedule. Ask about a patient or the schedule.'}</span>} box={box}
      chips={chips.map(c => <button key={c.id} type="button" className={`fd-chip ${c.task ? 'task' : ''}`} onClick={c.run} data-testid={`fd-chip-${c.id}`}>{c.label}</button>)}
      after={isAscEd ? <AscTodo /> : <RoleTodo />} foot="Nightingale reads your records on this device and points you to the source. It never diagnoses, signs, orders or decides. Fictional data." /></div>;
  }
  return <div data-testid="fd-chat-thread" className="flex flex-col min-h-[calc(100vh-52px)]">
    <div className="fd-thread">{chat.msgs.map((m, i) => <div key={i} className={`fd-msg ${m.who}`} data-testid={m.who === 'ng' ? 'fd-msg-ng' : 'fd-msg-me'}>
      {m.who === 'ng' && <div className="who">Nightingale</div>}
      <div>{m.text} {m.cites && m.cites.length > 0 && <Cites list={m.cites} pid={m.pid} />}</div>
      {m.who === 'ng' && m.act && <div className="acts"><button type="button" className="fd-btn primary" onClick={() => go(m.act!)} data-testid="fd-chat-act">{actLabel(m.act)}</button></div>}
    </div>)}{busy && <div className="fd-msg ng" aria-live="polite"><div className="who">Nightingale</div>reading…</div>}<div ref={end} /></div>
    <div className="fd-dock mt-auto"><div className="fd-col">{box}<div className="fd-disc">On-device, from recorded data only. Nightingale never signs, orders or decides.</div></div></div>
  </div>;
};
