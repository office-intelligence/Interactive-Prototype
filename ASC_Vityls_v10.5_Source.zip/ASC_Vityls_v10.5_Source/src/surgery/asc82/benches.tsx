import { NativeRecord, DictateMic } from '../asc10/native103';
import { ExcBox } from '../asc84/exc';
import { FullOpReportPanel } from '../asc83/opreport';
/* ASC.Vityls v8.2 · workbench benches rebuilt for the day of surgery: booking intake → scheduler, arrival card capture,
 * nursing admission checklist (pre-op bedside merged in), new Anesthesia and Surgeon benches, PACU full form in place,
 * discharge with nurse / patient-or-adult / physician signatures. Drawn signature + own PIN for staff; the patient draws.
 * Fictional data. Externals (fax OCR, ambient capture, email/SMS) simulated. No automatic PDF. */
import { ActiveOrdersCard, Flowsheet, DischargeExtras, WitnessCapture, StatusPill } from '../asc86/ui86';
import * as D86 from '../asc86/store86';
import * as P86 from '../asc86/pure86';
import { openBench } from '../asc81/practice81';
import { HoldMic } from '../asc83/mic';
import React, { useState } from 'react';
import { medRepo, isoDay, PROVIDER_ROLES } from '../../med/record';
import { useActor } from '../../med/ui';
import { useSv } from '../ui';
import { repo } from '../../v6/dataLayer';
import { PinSign } from '../sign';
import * as A from '../asc8/logic';
import * as S from '../asc8/store';
import * as L from '../asc81/ai';
import { use81, s81, mid, SAMPLE_FAXES, SAMPLE_BEDSIDE } from '../asc81/store81';
import { OfficialHistory, StandingChecklist, BriefOpReport, CaptureUpload } from '../asc10/flow10';
import { AnesSummary, ConsentLinks, NursingConsents } from '../asc10/station102';
import { FormalOpPending, pacuOrdersSigned, RX_LINE } from '../asc10/fixes10';
import { snapshotLists, followPrefs, setFollowPrefs } from '../asc10/store10';
import { DEMO } from '../asc10/demo';
import { FileText } from 'lucide-react';
import { SigPad, saveSig, MedSummary, FormInPlace, WK, XClose } from './common';
import { matchPatient, requestedDay, createPatientFromDraft, setPendingBook, normDob, type PtLite } from './intake';

const audit = (cid: string, by: string, role: string, detail: string) => repo.audit({ caseId: `asc8:${cid}`, user: by, role, action: 'asc82.bench' as any, detail });
const stamp = (by: string) => ({ by, at: new Date().toISOString() });
const first = (n: string) => n.split(/\s+/)[0];
const H: React.FC<{ n?: number; children: React.ReactNode; right?: React.ReactNode }> = ({ n, children, right }) => <div className="a82-sh">{n != null && <span className="n">{n}</span>}<h3 className="a81-h3">{children}</h3>{right}</div>;
const Foot: React.FC<{ children: React.ReactNode }> = ({ children }) => <div className="a81-foot">{children}</div>;
const Sim: React.FC<{ children: React.ReactNode }> = ({ children }) => <p className="sv-small sv-muted mt-2">Simulated: {children}</p>;
const Seg: React.FC<{ opts: string[]; v?: string; on: (x: string) => void; tid: string; dis?: boolean }> = ({ opts, v, on, tid, dis }) => <span className="a8-seg" role="radiogroup">{opts.map(o => <button key={o} type="button" role="radio" aria-checked={v === o} disabled={dis} className={v === o ? 'on' : ''} onClick={() => on(o)} data-testid={`${tid}-${o.replace(/\W+/g, '').toLowerCase()}`}>{o}</button>)}</span>;
type Signed = { by: string; at: string; role?: string };
const Signed: React.FC<{ s: Signed; tid: string; what?: string }> = ({ s, tid, what = 'Signed' }) => <span className="a81-ok" data-testid={tid}>✓ {what} by {s.by} · {new Date(s.at).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' })}</span>;
/** Staff signature: drawn signature + own PIN (PinSign shows the pad in ASC2). */
export const Sign: React.FC<{ label?: string; roles: string[]; what: string; testId: string; cid?: string; allow?: (p: { name: string; role: string }) => boolean; disabled?: boolean; onSigned: (by: string, role: string) => void }> = ({ label = 'Lock & sign', roles, what, testId, cid, allow, disabled, onSigned }) => {
  const [o, setO] = useState(false);
  return <><button type="button" className="a8-btn pri a82-sign" disabled={disabled} onClick={() => setO(true)} data-testid={`${testId}-open`}>{label}</button>
    {o && <PinSign title={label} sigCase={cid} statement={<>I reviewed “{what}”. Nightingale drafted; it does not sign.</>} roles={roles} allow={allow} onClose={() => setO(false)} onSigned={s => { setO(false); onSigned(s.name, s.role); }} confirmLabel="Sign" />}</>;
};
const useV82 = (cid: string, k: 'nursing' | 'anes' | 'surg' | 'dc') => { const s = use81(); const cur = (s.ai(cid).v82 || {})[k] || {};
  const up = (x: Record<string, any>) => s.setAi(cid, a => ({ ...a, v82: { ...(a.v82 || {}), [k]: { ...((a.v82 || {}) as any)[k], ...x } } })); return [cur, up, s] as const; };
/** Opens a form in place inside a bench (source links, "Open" buttons). */
const FormOverlay: React.FC<{ c: A.AscCase; file: string; st: A.Station; onClose: () => void }> = ({ c, file, st, onClose }) => <div className="a82-overlay" data-testid="a82-form-overlay"><div className="a82-ovhead"><b>Form</b><XClose onClick={onClose} testId="a82-form-overlay-close" /></div><FormInPlace c={c} file={file} station={WK[st]} onClose={onClose} /></div>;

/* ============ 1 · Booking intake → scheduler "Add appointment" ============ */
const FIELDS: [keyof L.BookingDraft, string][] = [['patientName', 'Patient name'], ['dob', 'Date of birth'], ['phone', 'Phone'], ['email', 'Email'], ['age', 'Age'], ['gender', 'Gender'], ['procedure', 'Procedure'], ['durationMins', 'Duration (min)'], ['surgeon', 'Surgeon'], ['assistant', 'Assistant'], ['paymentType', 'Payment type'], ['anesthesia', 'Anesthesia type'], ['equipment', 'Special equipment'], ['requestedDate', 'Requested surgery day']];
const to12 = (t: string) => { const m = /(\d+):(\d+)\s*(AM|PM)?/i.exec(t); if (!m) return t; let h = +m[1]; const ap = m[3] ? m[3].toUpperCase() : h >= 12 ? 'PM' : 'AM'; if (!m[3] && h > 12) h -= 12; return `${String(h).padStart(2, '0')}:${m[2]} ${ap}`; };
export const Intake82: React.FC<{ onClose: (m?: string) => void }> = ({ onClose }) => {
  const s = use81(); const [actor] = useActor(); const { setTab } = useSv(); const items = s.intake(); const [sel, setSel] = useState<string | null>(items.find(i => i.status === 'new')?.id || null);
  const it = items.find(i => i.id === sel); const [edits, setEdits] = useState<Record<string, L.BookingDraft>>({}); const [choice, setChoice] = useState<Record<string, string>>({});
  const cur = it ? (edits[it.id] || L.parseBooking(it.text, it.source)) : null;
  const day = cur ? requestedDay(cur.requestedDate) : isoDay();
  const busy = S.cases().filter(c => c.date === day).map(c => ({ room: c.room, scheduledTime: c.time, estimatedDurationMins: c.durationMin }));
  const slot = cur ? L.suggestSlot(cur.durationMins || 60, busy, S.ROOMS.filter(r => r.startsWith('OR')), cur.equipment) : null;
  const pts: PtLite[] = medRepo.patients().map(p => ({ id: p.id, name: p.name, dob: p.dob, phone: p.phone }));
  const m = cur ? matchPatient(cur.patientName, cur.dob, pts) : { kind: 'none' as const, candidates: [] as PtLite[] };
  const chosen = it ? (choice[it.id] ?? (m.kind === 'exact' ? m.pick.id : m.kind === 'none' ? 'new' : '')) : '';
  const scan = () => { if (!DEMO) { const i = { id: mid('in-fax'), source: 'fax' as const, from: 'Desk scanner', at: new Date().toISOString(), subject: 'Scanned document · enter the details (document reading is not connected)', text: '', status: 'new' as const }; s.upIntake(i); setSel(i.id); return; } const n = s.faxN(); const text = SAMPLE_FAXES[n % SAMPLE_FAXES.length]; const i = { id: mid('in-fax'), source: 'fax' as const, from: 'Desk scanner', at: new Date().toISOString(), subject: `Scanned fax · ${text.split('\n')[0].replace(/^FAX · /, '').replace(/ · page.*/, '')}`, text, status: 'new' as const }; s.bumpFax(); s.upIntake(i); setSel(i.id); };
  const set = (k: keyof L.BookingDraft, v: string) => { const n: any = { ...cur, [k]: k === 'age' || k === 'durationMins' ? (+v || undefined) : v }; n.missing = FIELDS.filter(([f]) => !['assistant', 'dob', 'requestedDate', 'equipment'].includes(f as string) && !n[f]).map(([, l]) => l); setEdits({ ...edits, [it!.id]: n }); };
  const confirm = () => { if (!cur || !it || !cur.patientName || !cur.procedure || !chosen) return;
    const pid = chosen === 'new' ? '' : chosen; const p = pid ? medRepo.patient(pid) : undefined;
    audit('intake', actor.name, actor.role, `${cur.patientName}: ${chosen === 'new' ? 'new patient (chart created when the case is booked)' : `linked to existing patient ${p?.name} (DOB ${p?.dob})`} from ${it.source} intake`);
    setPendingBook({ intakeId: it.id, patientId: pid, date: day, time: to12(slot?.time || '07:30 AM'), room: slot?.room || 'OR 1', provider: cur.surgeon || S.PATEL, duration: cur.durationMins || 60, reason: cur.procedure, notes: [cur.anesthesia && `Anesthesia: ${cur.anesthesia}`, cur.equipment && `Equipment: ${cur.equipment}`, cur.paymentType && `Payment: ${cur.paymentType}`].filter(Boolean).join(' · '), source: it.source, anesthesia: cur.anesthesia, email: cur.email, phone: cur.phone, draft: { name: cur.patientName, dob: cur.dob, phone: cur.phone, email: cur.email, sex: cur.gender, procedure: cur.procedure, anesthesia: cur.anesthesia, payType: cur.paymentType, duration: cur.durationMins, notes: [cur.equipment && `Equipment: ${cur.equipment}`].filter(Boolean).join(' · '), assistant: cur.assistant && !/none/i.test(cur.assistant) ? cur.assistant : '' } });
    setTab('schedule'); onClose(`Opening the scheduler on ${new Date(day + 'T12:00').toLocaleDateString([], { weekday: 'short', month: 'short', day: 'numeric' })} with the appointment pre-filled.`); };
  return <div className="a81-cols" data-testid="a81-intake">
    <div><button type="button" className="a8-btn pri" style={{ width: '100%' }} onClick={scan} data-testid="a81-scan-fax">Scan paper fax</button>
      <p className="sv-small sv-muted mt-1">Put the fax on the desk scanner. Nightingale reads it (simulated OCR).</p><H>Inbox</H>
      {items.map(i => <button key={i.id} type="button" onClick={() => setSel(i.id)} className={`a81-item ${i.id === sel ? 'on' : ''}`} data-testid="a81-intake-item" data-status={i.status}><span className="sv-small sv-muted">{i.source === 'fax' ? 'Scanned fax' : 'Email'} · {i.status}</span><b>{i.subject}</b></button>)}</div>
    <div>{!it ? <p className="sv-muted">Scan a fax or pick a request.</p> : it.status === 'booked' ? <p data-testid="a81-intake-booked">Booked. Case {it.caseId}.</p> : <>
      <details className="a81-box"><summary>Original {it.source === 'fax' ? 'scanned fax' : 'email'}</summary><pre className="a81-pre">{it.text}</pre></details>
      <p className="mt-2">Nightingale pre-filled {FIELDS.filter(([k]) => cur && cur[k]).length} of {FIELDS.length} fields{cur!.missing.length ? <span className="a81-warn"> · missing: {cur!.missing.join(', ')}</span> : null}. Please check and confirm.</p>
      <div className="a81-grid2">{FIELDS.map(([k, l]) => <label key={String(k)}><span className="sv-label">{l}</span><input className={`sv-input ${cur![k] ? '' : 'a81-missing'}`} value={String(cur![k] ?? '')} onChange={e => set(k, e.target.value)} data-testid={`a81-f-${String(k)}`} /></label>)}</div>
      <div className="a82-match" data-testid="a82-match" data-kind={m.kind}><H>Patient database</H>
        {m.kind === 'exact' && <p className="sv-small">Name and date of birth match a patient on file. Linked; change it below if needed.</p>}
        {m.kind === 'ambiguous' && <p className="sv-small a81-warn">More than one possible match{cur!.dob ? '' : ' (no date of birth on the request)'}. Choose the right chart, or create a new patient.</p>}
        {m.kind === 'none' && <p className="sv-small">No patient on file with this name. A new chart will be created.</p>}
        {[...m.candidates.map(p => ({ id: p.id, t: `${p.name} · DOB ${p.dob}${normDob(p.dob) && normDob(p.dob) === normDob(cur!.dob) ? ' · DOB matches' : ''}${p.phone ? ` · ${p.phone}` : ''}` })), { id: 'new', t: `Create a new patient: ${cur!.patientName || '—'}${cur!.dob ? ` · DOB ${cur!.dob}` : ''}` }].map(o =>
          <label key={o.id} className={`a81-line a82-radio ${chosen === o.id ? 'on' : ''}`} data-testid="a82-match-opt" data-id={o.id}><input type="radio" name={`m-${it.id}`} checked={chosen === o.id} onChange={() => setChoice({ ...choice, [it.id]: o.id })} /><span>{o.id === 'new' ? o.t : <>Link to <b>{o.t}</b></>}</span></label>)}</div>
      <div className="a81-box mt-2" data-testid="a81-slot">Requested day <b>{new Date(day + 'T12:00').toLocaleDateString([], { weekday: 'long', month: 'long', day: 'numeric' })}</b>{cur!.requestedDate ? '' : ' (none on the request: next weekday)'} · suggested slot {slot ? <b>{slot.room} · {slot.time}</b> : 'none open'}{cur!.equipment ? ` · checked for ${cur!.equipment} conflicts` : ''}</div>
      <Foot><button type="button" className="a8-btn" onClick={() => s.upIntake({ ...it, status: 'dismissed' })}>Not a booking</button><button type="button" className="a8-btn pri" onClick={confirm} disabled={!cur!.patientName || !cur!.procedure || !chosen} data-testid="a81-intake-confirm">Confirm &amp; create</button></Foot>
      <p className="sv-small sv-muted">Confirm opens the scheduler’s Add appointment on the requested day, pre-filled. The surgery case is created when you book it there.</p></>}</div>
  </div>;
};

/* ============ 2 · Arrival: ID + insurance card capture (front/back) ============ */
const shrink = (file: File): Promise<string> => new Promise((ok, bad) => { const r = new FileReader(); r.onerror = bad; r.onload = () => { const im = new Image(); im.onload = () => { const k = Math.min(1, 900 / Math.max(im.width, im.height)); const cv = document.createElement('canvas'); cv.width = Math.round(im.width * k); cv.height = Math.round(im.height * k); cv.getContext('2d')!.drawImage(im, 0, 0, cv.width, cv.height); ok(cv.toDataURL('image/jpeg', 0.72)); }; im.onerror = () => ok(String(r.result)); im.src = String(r.result); }; r.readAsDataURL(file); });
export const CARD_SLOTS = [['idFront', 'Photo ID · front'], ['idBack', 'Photo ID · back'], ['insFront', 'Insurance card · front'], ['insBack', 'Insurance card · back']] as const;
export const CardCapture: React.FC<{ c: A.AscCase }> = ({ c }) => {
  const s = use81(); const [actor] = useActor(); const cards = s.ai(c.id).v82?.cards || {}; const onFile = !!c.d.id;
  const put = (k: string, v: string) => { s.setAi(c.id, a => ({ ...a, v82: { ...(a.v82 || {}), cards: { ...(a.v82?.cards || {}), [k]: v } } })); audit(c.id, actor.name, actor.role, `${CARD_SLOTS.find(x => x[0] === k)?.[1]} ${v ? 'captured' : 'removed'}`); };
  const n = CARD_SLOTS.filter(([k]) => cards[k]).length;
  return <section className="a82-cards" data-testid="a82-cards"><H right={<span className={`a81-progress ${n === 4 ? 'done' : ''}`}>{n} of 4 on file</span>}>ID &amp; insurance cards</H>
    {onFile && n === 0 && <p className="sv-small sv-muted">ID and insurance were confirmed earlier. Capture images only if they are not already on file.</p>}
    <div className="a82-cardgrid">{CARD_SLOTS.map(([k, l]) => <div key={k} className={`a82-card ${cards[k] ? 'has' : ''}`} data-testid={`a82-card-${k}`}><div className="t">{l}</div>
      {cards[k] ? <img src={cards[k]} alt={l} /> : <div className="ph">No image</div>}
      <div className="b"><label className="a8-btn sm">📷 Camera<input type="file" accept="image/*" capture="environment" hidden onChange={async e => { const f = e.target.files?.[0]; if (f) put(k, await shrink(f)); e.target.value = ''; }} data-testid={`a82-cam-${k}`} /></label>
        <label className="a8-btn sm">Upload<input type="file" accept="image/*,application/pdf" hidden onChange={async e => { const f = e.target.files?.[0]; if (f) put(k, await shrink(f)); e.target.value = ''; }} data-testid={`a82-up-${k}`} /></label>
        {cards[k] && <button type="button" className="sv-link sv-small" onClick={() => put(k, '')}>Retake</button>}</div></div>)}</div>
    <p className="sv-small sv-muted">On a tablet “Camera” opens the back camera. You can also upload a photo or PDF of each side.</p></section>;
};

/* ============ 4 · Nursing admission (pre-op bedside merged in): checkbox checklist ============ */
import { NURSE_SECTIONS, nurseCounts, AIRWAY, HOME_PLANS, needsFacility, type NI } from './pure';
export const Nursing82: React.FC<{ c: A.AscCase; onClose: (m?: string) => void }> = ({ c, onClose }) => {
  const [actor] = useActor(); const [st, up, s] = useV82(c.id, 'nursing'); const ai = s.ai(c.id); const signed: Signed | undefined = st.signed;
  const checks: Record<string, any> = st.checks || {}; const vals: Record<string, Record<string, string>> = st.vals || {};
  const pre = (i: NI) => i.pre ? i.pre(c) : false;
  const bed = ai.bedside?.drafts?.nursing || [];
  const dflt = (i: NI, k: string) => { if (i.id === 'adult') return c.d.adult?.[k] || ''; if (i.id === 'vitals') return c.d.vitals?.[k] || (k === 'bp' ? (bed.find(l => l.target === 'Vitals')?.text.match(/(\d{2,3}\/\d{2,3})/)?.[1] || '') : ''); if (i.id === 'npo' && portalVal(k === 'solids' ? /last.?(solid|food|meal|ate)/i : /last.?(clear|liquid|drink|water)/i) && !c.d.npo?.[k]) return portalVal(k === 'solids' ? /last.?(solid|food|meal|ate)/i : /last.?(clear|liquid|drink|water)/i); if (i.id === 'npo') { const t = bed.find(l => /\b(toast|ate|eat|water|sip)\b/i.test(l.text) && !/heart rate/i.test(l.text)); return c.d.npo?.[k] || (t ? (k === 'solids' ? '7:00 PM last night' : '5:00 AM') : ''); } if (i.id === 'iv') return c.d.iv?.[k] || ''; if (i.id === 'home' && k === 'plan') return portalVal(/post.?op.*(plan|stay|recover)|overnight/i) || ''; return ''; };
  const portalVal = (re: RegExp) => { const fv: Record<string, any> = { ...(repo.getForm(c.visitId, 'Medical_History.html').values || {}), ...(repo.getForm(c.visitId, 'Anesthesia_Questionnaire.html').values || {}), ...(repo.getForm(c.visitId, 'Patient_Registration.html').values || {}) }; const hit = Object.entries(fv).find(([kk, vv]) => re.test(kk) && typeof vv === 'string' && vv.trim()); return hit ? String(hit[1]) : ''; };
  const v = (i: NI, k: string) => vals[i.id]?.[k] ?? dflt(i, k);
  const tick = (i: NI, b: boolean) => { if (signed) return; up({ checks: { ...checks, [i.id]: b ? stamp(actor.name) : undefined } }); };
  const setVal = (i: NI, k: string, x: string) => up({ vals: { ...vals, [i.id]: { ...(Object.fromEntries((i.vals || []).map(([kk]) => [kk, v(i, kk)]))), [k]: x } } });
  const all = NURSE_SECTIONS.flatMap(x => x.items); const { done, total } = nurseCounts(checks);
  const missingVal = all.filter(i => checks[i.id] && i.vals && (i.id === 'home' ? needsFacility(v(i, 'plan')) && !String(v(i, 'facility')).trim() : i.vals.some(([k]) => !String(v(i, k)).trim())) && i.id !== 'adult').map(i => i.label);
  const exc = [...all.filter(i => !checks[i.id]).map(i => i.label), ...missingVal.map(l => `${l}: value missing`)];
  const capture = () => { const parts = L.splitBedside(SAMPLE_BEDSIDE, { anesthesia: [c.anesthesia], surgeon: [c.surgeon] }); s.setAi(c.id, a => ({ ...a, bedside: { ...(a.bedside || {}), transcript: SAMPLE_BEDSIDE, drafts: parts } })); audit(c.id, actor.name, actor.role, 'Bedside conversation captured (simulated ambient); NPO, vitals and ride home pre-filled'); };
  const fillKnown = () => { const n = { ...checks }; all.forEach(i => { if (pre(i) && !n[i.id]) n[i.id] = { ...stamp(actor.name), pre: true }; }); up({ checks: n }); };
  const sign = (by: string, role: string) => { let x = S.caseById(c.id)!; const at = new Date().toISOString();
    const put = (k: string, val: any, what: string) => { if (!A.isDone(x, k)) x = S.setValue(x, k, val, by, role, what); };
    const g = (id: string) => { const i = all.find(y => y.id === id)!; return Object.fromEntries((i.vals || []).map(([k]) => [k, v(i, k)])); };
    const ck = (id: string) => !!checks[id]; if (ck('vitals')) put('vitals', g('vitals'), `Vitals: BP ${v(all.find(i => i.id === 'vitals')!, 'bp')}`); if (ck('npo')) put('npo', g('npo'), 'NPO confirmed'); if (ck('allergy') && !A.isDone(x, 'allergy')) x = S.confirmAllergies(x, by, role); if (ck('meds')) put('meds', { by, at }, 'Medications reviewed'); if (ck('iv')) put('iv', g('iv'), 'IV started'); if (ck('sitecheck')) put('sitecheck', { by, at }, 'Site-mark check'); if (ck('clearance')) put('clearance', { by, at }, 'Clearance reviewed');
    if (exc.length) x = S.setValue(x, 'exceptions', { ...(x.d.exceptions || {}), nursing: { items: exc, by, at } }, by, role, `Nursing admission signed with exceptions: ${exc.join('; ')}`);
    if (!x.d.adult?.name && v(all.find(i => i.id === 'adult')!, 'name')) x = S.setValue(x, 'adult', { ...g('adult'), present: true }, by, role, 'Responsible adult');
    S.setValue(x, 'nursingForm', { by, at, signed: true }, by, role, 'Nursing admission checklist locked and signed (drawn signature + PIN)');
    up({ signed: { by, at, role }, vals: { ...vals, vitals: g('vitals'), npo: g('npo'), iv: g('iv'), adult: g('adult') } }); onClose('Nursing admission signed and locked.'); };
  React.useEffect(() => { snapshotLists(c.id, c.surgeon); }, [c.id]);
  return <div data-testid="a81-nursing" className="a82-nurse v102-onecheck">
    <OfficialHistory c={c} />
    <StandingChecklist c={c} phase="pre" />
    <NursingConsents c={c} />
    <div className="a82-nhead"><span className={`a81-progress ${done === total ? 'done' : ''}`} data-testid="a82-nurse-progress">{done} of {total} complete</span>
      {!signed && <><button type="button" className="a8-btn" onClick={fillKnown} data-testid="a82-nurse-known">Tick what’s already on file</button>{DEMO && <button type="button" className="a8-btn" onClick={capture} data-testid="a81-listen">{bed.length ? 'Capture bedside again' : 'Capture bedside conversation'}</button>}</>}</div>
    {bed.length > 0 && <Sim>ambient bedside capture used a sample conversation; NPO, vitals and ride home are pre-filled for you to check.</Sim>}
    <div className="a82-sections">{NURSE_SECTIONS.map((sec, si) => { const d = sec.items.filter(i => checks[i.id]).length; return <section key={sec.title} className="a82-sec" data-testid="a82-nurse-sec">
      <div className="a82-sh"><span className="n">{si + 1}</span><h3 className="a81-h3">{sec.title}</h3><span className={`a81-progress ${d === sec.items.length ? 'done' : ''}`}>{d} of {sec.items.length}</span></div>
      {sec.items.map(i => <div key={i.id} className={`a82-ck ${checks[i.id] ? 'on' : ''}`} data-testid="a81-nurse-item" data-id={i.id}>
        <label className="row"><input type="checkbox" checked={!!checks[i.id]} disabled={!!signed} onChange={e => tick(i, e.target.checked)} data-testid={`a81-ver-${i.id}`} /><span className="l">{i.label}</span>{pre(i) && <span className="a82-onfile">{pre(i)}</span>}</label>
        {i.id === 'home' ? <div className="vals"><label><span className="sv-label">Plan</span><select className="sv-input" disabled={!!signed} value={v(i, 'plan') || HOME_PLANS[0]} onChange={e => setVal(i, 'plan', e.target.value)} data-testid="a83-nv-home-plan">{HOME_PLANS.map(x => <option key={x}>{x}</option>)}</select></label>{needsFacility(v(i, 'plan')) && <label><span className="sv-label">Post-op recovery facility name</span><input className="sv-input" readOnly={!!signed} value={v(i, 'facility')} onChange={e => setVal(i, 'facility', e.target.value)} data-testid="a83-nv-home-facility" /></label>}</div> : i.vals && <div className="vals">{i.vals.map(([k, l]) => <label key={k}><span className="sv-label">{l}</span><input className="sv-input" readOnly={!!signed} value={v(i, k)} onChange={e => setVal(i, k, e.target.value)} data-testid={`a82-nv-${i.id}-${k}`} /></label>)}</div>}</div>)}</section>; })}</div>
    {missingVal.length > 0 && !signed && <p className="a81-warn" data-testid="a82-nurse-missing">Values still needed: {missingVal.join(' · ')}</p>}
    {!signed && exc.length > 0 && <ExcBox items={exc} tid="a84-nurse-exc" note="You can sign now; these stay on the to-do list as exceptions." />}
    <Foot>{signed ? <Signed s={signed} tid="a81-nurse-signed" what="Locked & signed" /> : <><button type="button" className="a8-btn" onClick={() => onClose()}>Save &amp; close</button><Sign label={exc.length ? `Sign with exceptions (${exc.length})` : 'Lock & sign'} roles={S.NURSE_ROLES} cid={c.id} what={exc.length ? `Nursing admission checklist (with ${exc.length} exception${exc.length === 1 ? '' : 's'})` : 'Nursing admission checklist'} testId="a81-nurse" onSigned={sign} /></>}</Foot>
    {!signed && done < total && <p className="sv-small sv-muted" style={{ textAlign: 'right' }}>Lock &amp; sign opens when every item is checked.</p>}</div>;
};

/* ============ 5 · Anesthesia (new) ============ */
const EXAM = [['heart', 'Heart: regular rate and rhythm, no murmur'], ['lungs', 'Lungs: clear to auscultation bilaterally'], ['neuro', 'Mental status: alert and oriented'], ['npo', 'NPO status confirmed'], ['iv', 'IV patent']];
const TECH = ['Natural airway', 'LMA', 'ETT', 'Nerve block', 'Spinal', 'Local infiltration'];
export const Anesthesia82: React.FC<{ c: A.AscCase; onClose: (m?: string) => void }> = ({ c, onClose }) => {
  const [actor] = useActor(); const [st, up, s] = useV82(c.id, 'anes'); const ai = s.ai(c.id); const [ov, setOv] = useState(''); const b = L.recordsBrief(s.pages(c.id));
  const roman = (n: number) => ['', 'I', 'II', 'III', 'IV'][n] || String(n);
  const aw = { mallampati: c.d.airway?.mallampati, ...(st.airway || {}) }; const asa = st.asa || c.d.asa || (ai.brief?.asaAccepted?.cls ? roman(ai.brief.asaAccepted.cls) : ''); const exam = st.exam || {}; const type = st.type || c.d.plan?.technique; const tech: string[] = st.tech || [];
  const pre: Signed | undefined = st.pre;
  const evalDone = AIRWAY.every(([k]) => aw[k]) && !!asa && EXAM.every(([k]) => exam[k]) && !!type;
  const saveEval = (by: string, role: string) => { let x = S.caseById(c.id)!; x = S.setValue(x, 'asa', asa, by, role, `ASA ${asa}`); x = S.setValue(x, 'airway', { ...aw, notes: st.awNote || '' }, by, role, `Airway: Mallampati ${aw.mallampati}, TMD ${aw.tmd}, mouth ${aw.mouth}, neck ${aw.neck}, dentition ${aw.teeth}`);
    S.setValue(x, 'plan', { technique: type, tech, notes: st.planNote || '', by, at: new Date().toISOString() }, by, role, `Plan: ${type}${tech.length ? ` (${tech.join(', ')})` : ''}`); up({ evalSigned: { by, at: new Date().toISOString() } }); };
  return <div data-testid="a82-anes" className="a82-two">
    {ov && <FormOverlay c={c} file={ov} st="anesthesia" onClose={() => setOv('')} />}
    <div><OfficialHistory c={c} /><AnesSummary c={c} station="anesthesia" /><ConsentLinks c={c} station="anesthesia" only="anes" />
      {s.pages(c.id).length > 0 && <div className="a81-box mt-2 sv-small" data-testid="a82-anes-brief">Records brief suggests <b>ASA {roman(b.asa.cls)}</b>: {b.asa.why.join(' · ') || 'no findings'}.</div>}</div>
    <div>
      <section className="a82-sec"><H n={1}>Airway evaluation</H>{AIRWAY.map(([k, l, o]) => <div key={k} className="a82-field"><span className="sv-label">{l}</span><Seg opts={o} v={aw[k]} on={x => up({ airway: { ...aw, [k]: x } })} tid={`a82-aw-${k}`} dis={!!st.evalSigned} /></div>)}
        <input className="sv-input mt-1" placeholder="Airway notes (optional)" value={st.awNote || ''} onChange={e => up({ awNote: e.target.value })} readOnly={!!st.evalSigned} /></section>
      <section className="a82-sec"><H n={2}>ASA class &amp; focused exam</H><div className="a82-field"><span className="sv-label">ASA</span><Seg opts={['I', 'II', 'III', 'IV']} v={asa} on={x => up({ asa: x })} tid="a82-asa" dis={!!st.evalSigned} /></div>
        {EXAM.map(([k, l]) => <label key={k} className={`a82-ck row ${exam[k] ? 'on' : ''}`}><input type="checkbox" checked={!!exam[k]} disabled={!!st.evalSigned} onChange={e => up({ exam: { ...exam, [k]: e.target.checked } })} data-testid={`a82-exam-${k}`} /><span className="l">{l}</span></label>)}</section>
      <section className="a82-sec"><H n={3}>Anesthesia type &amp; technique</H><div className="a82-field"><span className="sv-label">Type</span><Seg opts={['General', 'MAC', 'Regional', 'Local + sedation']} v={type} on={x => up({ type: x })} tid="a82-type" dis={!!st.evalSigned} /></div>
        <div className="a82-chips">{TECH.map(t => <label key={t} className={`a82-chipck ${tech.includes(t) ? 'on' : ''}`}><input type="checkbox" checked={tech.includes(t)} disabled={!!st.evalSigned} onChange={e => up({ tech: e.target.checked ? [...tech, t] : tech.filter(y => y !== t) })} data-testid={`a82-tech-${t.replace(/\W+/g, '').toLowerCase()}`} />{t}</label>)}</div>
        <input className="sv-input mt-1" placeholder="Plan notes, e.g. PONV prophylaxis (optional)" value={st.planNote || ''} onChange={e => up({ planNote: e.target.value })} readOnly={!!st.evalSigned} />
        <Foot>{st.evalSigned ? <Signed s={st.evalSigned} tid="a82-anes-eval-signed" what="Evaluation signed" /> : <Sign label="Sign evaluation" roles={S.ANES_ROLES} cid={c.id} what="Pre-anesthesia evaluation" testId="a82-anes-eval" disabled={!evalDone} onSigned={saveEval} />}</Foot></section>

      <section className="a82-sec a82-attest" data-testid="a82-preinduction"><H n={5}>Immediate pre-induction re-evaluation</H>
        <label className="a82-ck row"><input type="checkbox" checked={!!st.attest} disabled={!!pre} onChange={e => up({ attest: e.target.checked })} data-testid="a82-attest" /><span className="l">I re-evaluated the patient immediately before induction. Vitals and airway reviewed; the patient remains a suitable candidate for the planned anesthetic.</span></label>
        <textarea className="sv-input mt-1" rows={2} placeholder="Re-evaluation note (changes since the evaluation, if any)" value={st.preNote || ''} readOnly={!!pre} onChange={e => up({ preNote: e.target.value })} data-testid="a82-pre-note" />
        <Foot>{pre ? <Signed s={pre} tid="a82-pre-signed" /> : <Sign label="Sign re-evaluation" roles={S.ANES_ROLES} cid={c.id} what="Immediate pre-induction re-evaluation" testId="a82-pre" disabled={!st.attest || !st.evalSigned} onSigned={(by, role) => { up({ pre: { by, at: new Date().toISOString() } }); audit(c.id, by, role, `Pre-induction re-evaluation signed${st.preNote ? `: ${st.preNote}` : ''}`); onClose('Pre-induction re-evaluation signed.'); }} />}</Foot></section>
    </div></div>;
};

/* ============ 6 · Surgeon (new) ============ */
export const SURG_PREOP = ['Cefazolin 2 g IV within 60 minutes before incision (clindamycin 900 mg if beta-lactam allergy)', 'Sequential compression devices on before induction', 'Site marked; verify with the patient', 'Hold home anticoagulants per instructions'];
export const SURG_POSTOP = ['Discharge home when PACU criteria are met', 'Diet as tolerated', 'Ice to the site 20 minutes on / 20 off', 'Acetaminophen 1 g PO every 8 h; ibuprofen 600 mg PO every 6 h with food as needed', 'Follow-up in clinic in 10–14 days'];
export const Surgeon82: React.FC<{ c: A.AscCase; onClose: (m?: string) => void }> = ({ c, onClose }) => {
  const [actor] = useActor(); const [st, up] = useV82(c.id, 'surg'); const [ov, setOv] = useState('');
  const isSurg = (p: { name: string }) => p.name === c.surgeon; const R = PROVIDER_ROLES;
  const op = c.d.opReport; const [opText, setOpText] = useState<string>(() => op?.text || A.draftOpReport(S.opCtx(c)));
  const Ord: React.FC<{ k: 'preOrders' | 'postOrders'; title: string; dflt: string[]; n: number }> = ({ k, title, dflt, n }) => { const o = st[k] || {}; const text = o.text ?? dflt.join('\n');
    return <section className="a82-sec" data-testid={`a82-${k}`}><H n={n}>{title}</H><textarea className="sv-input" rows={4} readOnly={!!o.signed} value={text} onChange={e => up({ [k]: { text: e.target.value } })} data-testid={`a82-${k}-text`} />
      <Foot>{o.signed ? <Signed s={o.signed} tid={`a82-${k}-signed`} /> : <Sign label={`Sign ${title.toLowerCase()}`} roles={R} allow={isSurg} cid={c.id} what={title} testId={`a82-${k}`} onSigned={(by, role) => { up({ [k]: { text, signed: { by, at: new Date().toISOString() } } }); audit(c.id, by, role, `${title} signed (drawn signature + PIN)`); }} />}</Foot></section>; };
  return <div data-testid="a82-surgeon" className="a82-two">
    {ov && <FormOverlay c={c} file={ov} st="surgeon" onClose={() => setOv('')} />}
    <div><OfficialHistory c={c} /><ConsentLinks c={c} station="surgeon" only="surg" /></div>
    <div>
      <section className="a82-sec" data-testid="v104-orders-protocol"><H n={1}>Doctor orders</H><p className="v104-protocol">As per facility protocol</p></section>

      <section className="a82-sec" data-testid="a82-hp"><H n={2}>Interval H&amp;P and site marking</H>
        {c.d.hpUpdate ? <Signed s={c.d.hpUpdate} tid="a82-hp-signed" what="Interval H&P" /> : <>
          <label className="a82-ck row"><input type="checkbox" checked={!!st.hpOk} onChange={e => up({ hpUpdate: undefined, hpOk: e.target.checked })} data-testid="a82-hp-ok" /><span className="l">H&amp;P reviewed and the patient examined today: no interval change</span></label>
          <label className="a82-ck row"><input type="checkbox" checked={!!st.markOk || !!c.d.sitemark} disabled={!!c.d.sitemark} onChange={e => up({ markOk: e.target.checked })} data-testid="a82-mark-ok" /><span className="l">Site marked{c.side ? ` (${c.side})` : ''} with the patient awake and agreeing</span></label>
          <input className="sv-input mt-1" placeholder="Interval changes, if any" value={st.hpNote || ''} onChange={e => up({ hpNote: e.target.value })} data-testid="a82-hp-note" />
          <div className="v103-hp" data-testid="v103-hp-checks">
            {([['hpSuitable', 'Patient remains a suitable candidate for the planned procedure and anesthesia'], ['hpNoContra', 'No new contraindications identified'], ['hpProceed', 'Proceed as planned'], ['hpDefer', 'Defer / modify plan (notes below)']] as [string, string][]).map(([k, l]) => <label key={k} className="a82-ck row"><input type="checkbox" checked={!!st[k]} onChange={e => up(k === 'hpProceed' && e.target.checked ? { hpProceed: true, hpDefer: false } : k === 'hpDefer' && e.target.checked ? { hpDefer: true, hpProceed: false } : { [k]: e.target.checked })} data-testid={`v103-${k}`} /><span className="l">{l}</span></label>)}
            <label><span className="sv-label">Plan notes</span><textarea className="sv-input" rows={3} placeholder="Plan, changes or reasons to defer" value={st.hpPlan || ''} onChange={e => up({ hpPlan: e.target.value })} data-testid="v103-hp-plan" /></label>
            <div><DictateMic testId="v103-hp-mic" label="Dictate H&P update" sample="Patient seen and examined today. H and P reviewed, no interval change. Patient remains a suitable candidate for the planned procedure and anesthesia. No new contraindications identified. Proceed as planned." onText={t => up({ hpOk: st.hpOk || /no interval change/i.test(t), hpSuitable: st.hpSuitable || /suitable candidate/i.test(t), hpNoContra: st.hpNoContra || /no new contraindications/i.test(t), ...(/proceed as planned/i.test(t) ? { hpProceed: true, hpDefer: false } : /defer|modify/i.test(t) ? { hpDefer: true, hpProceed: false } : {}), hpPlan: [st.hpPlan, t].filter(Boolean).join('\n'), hpDictated: true })} />{st.hpDictated && <span className="sv-small sv-muted" data-testid="v103-hp-draft"> Filled from dictation: review before you sign.</span>}</div>
          </div>
          <Foot><Sign label="Sign H&P update" roles={R} allow={isSurg} cid={c.id} what="Interval H&P update and site marking" testId="a82-hp" disabled={!st.hpOk || !(st.markOk || c.d.sitemark) || !(st.hpProceed || st.hpDefer)} onSigned={(by, role) => { let x = S.caseById(c.id)!; const at = new Date().toISOString(); if (!x.d.sitemark) x = S.setValue(x, 'sitemark', { by, at }, by, role, `Site marked${c.side ? ` (${c.side})` : ''}`); S.setValue(x, 'hpUpdate', { by, at, signed: true, note: st.hpNote || '', suitable: !!st.hpSuitable, noNewContra: !!st.hpNoContra, plan: st.hpProceed ? 'Proceed as planned' : 'Defer / modify plan', planNotes: st.hpPlan || '' }, by, role, `Interval H&P update signed (drawn signature + PIN) · ${st.hpProceed ? 'Proceed as planned' : 'Defer / modify plan'}`); }} /></Foot></>}</section>
      <BriefOpReport c={c} />
      <FormalOpPending c={c} />
      <Foot><button type="button" className="a8-btn" onClick={() => onClose()} data-testid="a82-surg-close">Save &amp; close</button></Foot>
    </div></div>;
};

/* ============ 7 · PACU: the full PACU record in place + signed orders as tasks ============ */
export const Pacu82: React.FC<{ c: A.AscCase; onClose: (m?: string) => void }> = ({ c, onClose }) => {
  const s = use81(); const [actor] = useActor(); const ai = s.ai(c.id); const tasks = ai.pacu?.tasks || [];
  return <div data-testid="a81-pacu" className="a82-pacu v102-onecheck">
    <NativeRecord c={c} file="PACU_Recovery_Record.html" station="pacu" /><ActiveOrdersCard c={c} phases={['pacu', 'postop']} />
    <StandingChecklist c={c} phase="post" />
    <Flowsheet c={c} />
    
    <details className="a81-box" open={tasks.length > 0 && tasks.some(t => !t.done)}><summary>PACU orders → tasks ({tasks.filter(t => t.done).length} of {tasks.length} done)</summary>{!pacuOrdersSigned(c.id) && !ai.orders?.signed ? <p className="a81-warn" data-testid="v10-pacu-orders-warn">PACU orders (standard anesthesia library form) are not signed yet.</p> : !tasks.length ? <p className="sv-small sv-muted" data-testid="v10-pacu-orders-ok">PACU orders signed. Follow them on the order card above.</p> : tasks.map(t => <label key={t.id} className="a81-line" data-testid="a81-task"><input type="checkbox" checked={!!t.done} onChange={e => { s.setAi(c.id, x => ({ ...x, pacu: { ...(x.pacu || {}), tasks: tasks.map(y => y.id === t.id ? { ...y, done: e.target.checked ? stamp(actor.name) : undefined } : y) } })); if (e.target.checked) audit(c.id, actor.name, actor.role, `PACU order done: ${t.text}`); }} /><span style={{ flex: 1 }}>{t.text}{t.done && <span className="sv-small sv-muted"> · {t.done.by}</span>}</span></label>)}</details>
    
  </div>;
};

/* ============ 8 · Discharge: nurse + patient/responsible adult + physician ============ */
export const Discharge82: React.FC<{ c: A.AscCase; onClose: (m?: string) => void }> = ({ c, onClose }) => {
  const s = use81(); const [actor] = useActor(); const ai = s.ai(c.id); const d = ai.discharge || {}; const [dc, upDc] = useV82(c.id, 'dc'); const p = medRepo.patient(c.pid)!;
  const cg = c.d.adult?.name || ai.v82?.nursing?.vals?.adult?.name || ''; const lang = d.language || 'English';
  const text = d.text ?? L.dischargeDraft({ id: c.id, name: p.name, phone: p.phone, email: p.email, procedure: c.procedure, surgeon: c.surgeon } as any, { language: lang, ride: d.ride ?? cg, meds: [RX_LINE] });
  const up = (x: any) => s.setAi(c.id, a => ({ ...a, discharge: { ...(a.discharge || {}), ...x } }));
  const [png, setPng] = useState(''); const [who, setWho] = useState<'patient' | 'adult'>('patient'); const [err, setErr] = useState('');
  const nurse: Signed | undefined = d.signed; const pt = dc.patient; const doc = c.d.anesDischarge || c.d.dischargeOrder;
  const fp = followPrefs(c.id);
  const finish = () => { let x = S.caseById(c.id)!; const f = L.followups(isoDay(), first(p.name)); const to = p.phone || '[patient phone]';
    if (fp.text) s.addMsg({ id: mid('m'), caseId: c.id, channel: 'sms', to, body: f.nextDayText.body, status: 'scheduled (simulated)', on: f.nextDayText.on, at: new Date().toISOString(), by: 'Nightingale' });
    s.addMsg({ id: mid('m'), caseId: c.id, channel: 'survey', to: p.email || to, subject: f.survey.form, body: `Link to the ${f.survey.form} form (from Form templates).`, status: 'scheduled (simulated)', on: f.survey.on, at: new Date().toISOString(), by: 'Nightingale' });
    const e = (() => { if (x.loc !== 'pacu') return ''; try { S.move(x, 'discharged', actor.name, actor.role); return ''; } catch (er) { return (er as Error).message; } })();
    if (e) setErr(e); else onClose(`${p.name} discharged.${fp.text ? ` Next-day text ${f.nextDayText.on}.` : ''}${fp.call ? ' Day-2 call on the follow-up list.' : ''}`); };
  const all = !!nurse && !!pt && !!doc; const dcMiss = [!nurse && 'Nurse signature', !pt && 'Patient / responsible adult signature', !doc && 'Anesthesia discharge from PACU', ...A.moveWarnings(c, 'discharged')].filter(Boolean) as string[];
  return <div data-testid="a81-discharge">
    <div className="a81-grid3"><label><span className="sv-label">Language</span><select className="sv-input" value={lang} disabled={!!nurse} onChange={e => up({ language: e.target.value, text: undefined })} data-testid="a81-dc-lang"><option>English</option><option>Spanish</option></select></label>
      <div style={{ gridColumn: 'span 2' }}><span className="sv-label">Ride home &amp; caregiver (from check-in)</span><div className="v10-li" data-testid="a81-dc-ride">{cg || c.d.adult?.name ? `${cg || c.d.adult?.name}${c.d.adult?.phone ? ` · ${c.d.adult.phone}` : ''}` : <span className="v10-sub">Not recorded at check-in</span>}</div></div></div>
    <div className="vt-alert vt-alert--info" style={{ marginTop: 10 }} data-testid="v10-rx"><FileText aria-hidden="true" /><div><span className="vt-alert__title">Prescriptions</span>{RX_LINE}</div></div>
    <div className="v10-row" style={{ marginTop: 10 }} data-testid="v10-follow-prefs"><span className="sv-label" style={{ margin: 0 }}>Follow-up (both optional)</span><label className="v10-row sv-small"><input type="checkbox" checked={fp.text} onChange={e => setFollowPrefs(c.id, { ...fp, text: e.target.checked }, actor.name, actor.role)} data-testid="v10-follow-text" /> Next-day text</label><label className="v10-row sv-small"><input type="checkbox" checked={fp.call} onChange={e => setFollowPrefs(c.id, { ...fp, call: e.target.checked }, actor.name, actor.role)} data-testid="v10-follow-call" /> Day-2 call</label></div>
    <H>Instructions Nightingale drafted</H><textarea className="sv-input" rows={9} readOnly={!!nurse} value={text} onChange={e => up({ text: e.target.value })} data-testid="a81-dc-text" />
    <DischargeExtras c={c} />
    <H>Required signatures</H>
    <div className="a82-sigs" data-testid="a82-dc-sigs">
      <div className="a82-sigcard" data-testid="a82-dc-nurse"><b>1 · Discharging nurse</b><p className="sv-small sv-muted">Instructions reviewed with the patient and responsible adult.</p>{nurse ? <Signed s={nurse} tid="a81-dc-signed" /> : <Sign label="Nurse: sign" roles={S.NURSE_ROLES} cid={c.id} what="Discharge instructions reviewed" testId="a81-dc" onSigned={(by, role) => { up({ text, signed: stamp(by) }); S.setValue(S.caseById(c.id)!, 'instructions', stamp(by), by, role, 'Discharge instructions reviewed; nurse signed (drawn signature + PIN)'); }} />}</div>
      <div className="a82-sigcard" data-testid="a82-dc-patient"><b>2 · Patient or responsible adult</b>{pt ? <><Signed s={{ by: pt.name, at: pt.at }} tid="a82-dc-pt-signed" /><img className="a82-sigimg" src={pt.png} alt="Signature" /></> : <>
        <Seg opts={['Patient', 'Responsible adult']} v={who === 'patient' ? 'Patient' : 'Responsible adult'} on={x => setWho(x === 'Patient' ? 'patient' : 'adult')} tid="a82-dc-who" />
        <p className="sv-small">{who === 'patient' ? p.name : cg || 'Responsible adult'}: I received and understand these instructions.</p>
        <SigPad onChange={setPng} label="Sign with your finger" testId="a82-dc-pad" />
        <button type="button" className="a8-btn pri mt-1" disabled={!png} onClick={() => { const nm = who === 'patient' ? p.name : (cg || 'Responsible adult'); const at = new Date().toISOString(); saveSig({ title: 'Discharge instructions · patient/adult', name: nm, role: who === 'patient' ? 'Patient' : 'Responsible adult', at, png, caseId: c.id }); upDc({ patient: { name: nm, who, at, png } }); up({ patientSigned: true }); if (!c.d.handoff?.signedAt) S.setValue(S.caseById(c.id)!, 'handoff', { adult: nm, by: nm, signedAt: at, at }, actor.name, actor.role, `Discharge handoff signed by ${nm}`); audit(c.id, actor.name, actor.role, `Discharge instructions signed on the tablet by ${nm} (${who === 'patient' ? 'patient' : 'responsible adult'})`); }} data-testid="a82-dc-pt-save">Save signature</button></>}</div>
      <div className="a82-sigcard" data-testid="a82-dc-doc"><b>3 · Anesthesia discharge from PACU</b><p className="sv-small sv-muted">Only anesthesia signs the discharge: patient meets PACU discharge criteria.</p>{doc ? <Signed s={doc} tid="a82-dc-doc-signed" /> : <Sign label="Anesthesia: sign discharge" roles={S.ANES_ROLES} cid={c.id} what="Anesthesia discharge from PACU" testId="a82-dc-doc" onSigned={(by, role) => S.setValue(S.caseById(c.id)!, 'anesDischarge', { by, at: new Date().toISOString(), signed: true }, by, role, 'Anesthesia discharge from PACU signed (drawn signature + PIN)')} />}</div>
    </div>
    {err && <p className="a81-err">{err}</p>}
    {dcMiss.length > 0 && c.loc !== 'discharged' && c.loc !== 'closed' && <ExcBox items={dcMiss} tid="a84-dc-exc" note="Discharge is not blocked: these are recorded as exceptions and stay on the to-do list." />}
    <Foot><span className={`a81-progress ${all ? 'done' : ''}`} data-testid="a82-dc-count">{[nurse, pt, doc].filter(Boolean).length} of 3 signatures</span>{c.loc === 'discharged' || c.loc === 'closed' ? <span className="a81-ok" data-testid="a82-dc-done">Discharged</span> : <button type="button" className="a8-btn pri" onClick={() => { if (dcMiss.length) { const x = S.caseById(c.id)!; S.setValue(x, 'exceptions', { ...(x.d.exceptions || {}), discharge: { items: dcMiss, by: actor.name, at: new Date().toISOString() } }, actor.name, actor.role, `Discharged with exceptions: ${dcMiss.join('; ')}`); } finish(); }} data-testid="a82-dc-finish">{dcMiss.length ? `Discharge with exceptions (${dcMiss.length})` : 'Discharge patient'}</button>}</Foot></div>;
};

/** v8.6 · surgeon bench: orders live in the dedicated Orders section (status shown here; legacy free-text kept in history). */
const OrdersLink: React.FC<{ c: A.AscCase }> = ({ c }) => <section className="a82-sec" data-testid="a86-surg-orders"><H n={1} right={<button type="button" className="a8-btn pri" onClick={() => openBench('orders' as any, c.id)} data-testid="a86-open-orders">Open doctor orders</button>}>Doctor orders</H>
  <div className="a82-row">{(['preop', 'postop', 'pacu'] as P86.Phase[]).map(p => { const s = D86.orderSet(c.id, p); return <span key={p} className="sv-small">{P86.PHASE_LABEL[p]}: {s ? <StatusPill s={P86.current(s).status} /> : <span className="sv-muted">none</span>}</span>; })}</div></section>;
