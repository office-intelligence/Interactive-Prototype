/* ASC.Vityls v10.2 · one confirm per station (Kevin, Oct 29): a single checkmark verifies everything on the station at once,
 * replacing the per-item ticks. Plus the anesthesia questionnaire summary and consent links for Anesthesia and Surgeon.
 * Never holds a case: missing items stay as tinted warnings. Fictional data only. */
import React, { useState } from 'react';
import { CheckCircle2, FileText, ExternalLink } from 'lucide-react';
import { useActor, useMedTick } from '../../med/ui';
import { repo } from '../../v6/dataLayer';
import * as A from '../asc8/logic';
import * as S from '../asc8/store';
import { s81, use81 } from '../asc81/store81';
import { NURSE_SECTIONS } from '../asc82/pure';
import { uploads } from '../asc87/store87';
import * as D from './store10';
import { FRONT_DOCS } from './pure10';
import { FormInPlace, WK } from '../asc82/common';

export const CONFIRM_TEXT: Record<string, string> = {
  arrival: 'Everything at check-in is verified: documents on file, photo ID and insurance checked',
  nursing: 'Everything on nursing admission is verified, including the surgeon’s pre-op orders',
  anesthesia: 'Everything at the anesthesia station is reviewed and verified',
  surgeon: 'Everything at the surgeon station is reviewed and verified',
  or: 'Everything in the OR record is verified',
  pacu: 'Everything in PACU is verified, including the surgeon’s post-op orders',
  discharge: 'Everything for discharge is verified',
};
type Stamp = { by: string; role: string; at: string };
export const stationConfirmed = (cid: string, bench: string): Stamp | undefined => ((s81.ai(cid) as any).v102confirm || {})[bench];

/** Confirm all: applies every tick of this station in one step, audited once. */
export function confirmStation(c: A.AscCase, bench: string, by: string, role: string, on: boolean) {
  const at = new Date().toISOString(); const st = { by, role, at };
  s81.setAi(c.id, a => {
    const n: any = { ...a, v102confirm: { ...((a as any).v102confirm || {}), [bench]: on ? st : undefined } };
    if (on && bench === 'arrival') n.v10docs = { ...((a as any).v10docs || {}), ...Object.fromEntries(FRONT_DOCS.map(d => [d.id, true])) };
    if (on && bench === 'nursing') { const v82: any = { ...(a.v82 || {}) }; const cur = v82.nursing || {}; const checks = { ...(cur.checks || {}) }; NURSE_SECTIONS.flatMap(x => x.items).forEach(i => { if (!checks[i.id]) checks[i.id] = { by, at }; }); v82.nursing = { ...cur, checks }; n.v82 = v82; }
    return n;
  });
  if (on && bench === 'arrival') { const x = S.caseById(c.id); if (x && !A.isDone(x, 'id')) S.setValue(x, 'id', { by, at }, by, role, 'ID and insurance confirmed (station confirm)'); }
  if (on && (bench === 'nursing' || bench === 'pacu')) { const ph: D.Phase = bench === 'nursing' ? 'pre' : 'post'; const l = D.viewList(c.id, c.surgeon, ph); l.items.forEach(i => { if (!D.caseList(c.id, ph)?.ticks[i.id]) D.tickItem(c.id, c.surgeon, ph, i.id, true, by, role); }); }
  repo.audit({ caseId: `asc8:${c.id}`, user: by, role, action: 'asc102.confirm' as any, detail: `${bench}: ${on ? 'station verified and confirmed (one check)' : 'station confirmation removed'}` });
  window.dispatchEvent(new Event('vityls-med-updated'));
}

export const ConfirmStation: React.FC<{ c: A.AscCase; bench: string }> = ({ c, bench }) => {
  useMedTick(); use81(); const [actor] = useActor(); const s = stationConfirmed(c.id, bench); if (!CONFIRM_TEXT[bench]) return null;
  return <label className={`v102-confirm ${s ? 'done' : ''}`} data-testid="v102-confirm" data-bench={bench} data-done={s ? '1' : '0'}>
    <input type="checkbox" checked={!!s} onChange={e => confirmStation(c, bench, actor.name, actor.role, e.target.checked)} data-testid="v102-confirm-box" />
    <span style={{ flex: 1 }}><b>{CONFIRM_TEXT[bench]}</b>{s && <span className="sv-small sv-muted" data-testid="v102-confirm-stamp"> · {s.by.replace(/,.*$/, '')} · {new Date(s.at).toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' })}</span>}</span>
    {s && <CheckCircle2 size={20} color="#1a7f4b" aria-hidden="true" />}</label>;
};

/* ---------- Anesthesia questionnaire summary + consent links (Anesthesia and Surgeon stations) ---------- */
const AQ = 'Anesthesia_Questionnaire.html';
const label = (k: string) => k.replace(/[_-]+/g, ' ').replace(/([a-z])([A-Z])/g, '$1 $2').replace(/\s+/g, ' ').trim().replace(/^./, m => m.toUpperCase());
const Overlay: React.FC<{ c: A.AscCase; file: string; st: A.Station; onClose: () => void }> = ({ c, file, st, onClose }) => <div data-testid="v102-form-overlay"><FormInPlace c={c} file={file} station={(WK as any)[st]} onClose={onClose} /></div>;
export function questionnaireAnswers(c: A.AscCase): [string, string][] {
  const v: Record<string, unknown> = repo.getForm(c.visitId, AQ).values || {};
  return Object.entries(v).filter(([k, x]) => typeof x === 'string' && x.trim() && !/^(sig|signature|initial)/i.test(k) && !/^data:/.test(String(x))).map(([k, x]) => [label(k), String(x)] as [string, string]);
}
export const AnesSummary: React.FC<{ c: A.AscCase; station: A.Station }> = ({ c, station }) => {
  useMedTick(); const [ov, setOv] = useState(''); const openForm = (_c: A.AscCase, f: string, _s: A.Station) => setOv(f); const qa = questionnaireAnswers(c); const flag = qa.filter(([, v]) => /^yes\b/i.test(v));
  return <section className="v10-card" data-testid="v102-anes-summary">{ov && <Overlay c={c} file={ov} st={station} onClose={() => setOv('')} />}{station === 'anesthesia' && <HistoryDraft c={c} />}<h3 className="v10-h"><FileText size={18} aria-hidden="true" />{station === 'anesthesia' ? 'Nightingale summary · anesthesia questionnaire' : 'Anesthesia questionnaire'}
    <span className={`v10-chip ${qa.length ? 'ok' : 'warn'}`} style={{ marginLeft: 'auto' }}>{qa.length ? `${qa.length} answers` : 'Not answered yet'}</span></h3>
    {!qa.length ? <p className="v10-sub" data-testid="v102-anes-none">The patient has not answered the anesthesia questionnaire yet. It is sent with the intake forms.</p>
      : <><p className="v10-sub">Nightingale summary (draft): {flag.length ? `${flag.length} “yes” answer${flag.length === 1 ? '' : 's'} to review — ${flag.slice(0, 4).map(([k]) => k).join('; ')}${flag.length > 4 ? '…' : ''}.` : 'no “yes” answers that need review.'}</p>
        <div className="v102-qa" data-testid="v102-anes-qa">{(flag.length ? flag : qa).slice(0, 12).map(([k, v]) => <React.Fragment key={k}><span>{k}</span><b>{v}</b></React.Fragment>)}</div></>}
    <div className="v102-links"><button type="button" className="a8-btn" onClick={() => openForm(c, AQ, station)} data-testid="v102-open-aq"><ExternalLink size={14} style={{ display: 'inline', verticalAlign: '-2px', marginRight: 4 }} />Open the questionnaire</button></div></section>;
};
export const ConsentLinks: React.FC<{ c: A.AscCase; station: A.Station; only?: 'surg' | 'anes' }> = ({ c, station, only }) => {
  useMedTick(); const [ov, setOv] = useState(''); const openForm = (_c: A.AscCase, f: string, _s: A.Station) => setOv(f); const ups = uploads(c.id).filter(u => /consent/i.test(u.name + ' ' + u.type + ' ' + (u.note || '')));
  const row = (title: string, file: string, done: boolean, tid: string) => <div className="v10-li" data-testid={tid} data-signed={done ? '1' : '0'}><span style={{ flex: 1 }}>{title}</span>
    <span className={`v10-chip ${done ? 'ok' : 'warn'}`}>{done ? 'Signed at nursing admission' : 'Not signed yet'}</span>
    <button type="button" className="sv-link sv-small" onClick={() => openForm(c, file, station)} data-testid={`${tid}-open`}>Open</button></div>;
  return <section className="v10-card" data-testid="v102-consents">{ov && <Overlay c={c} file={ov} st={station} onClose={() => setOv('')} />}<h3 className="v10-h">Consents</h3>
    <p className="v10-sub">{only === 'surg' ? 'The surgical consent is signed with the patient at Nursing admission.' : only === 'anes' ? 'The patient signs at Nursing admission. Open the consent full screen to review it and add the anesthesia signature.' : 'Both consents are signed with the patient at Nursing admission.'}</p>
    {only !== 'surg' && row('Anesthesia consent', 'Anesthesia_Consent.html', !!c.d.anesConsent || formSigned(c, 'Anesthesia_Consent.html'), 'v102-consent-anes')}
    {only !== 'anes' && row('Surgical consent', 'Procedure_Consent.html', !!c.d.consentConfirm || formSigned(c, 'Procedure_Consent.html'), 'v102-consent-surg')}
    {ups.map(u => <div key={u.id} className="v10-li sv-small"><FileText size={14} /> Scanned: {u.name}</div>)}</section>;
};
function formSigned(c: A.AscCase, f: string) { const r: any = repo.getForm(c.visitId, f); return !!r && (r.status === 'signed' || r.status === 'completed'); }

/* ---------- Nursing admission: both consents are signed here with the patient ---------- */
import { Sign } from '../asc82/benches';
import { PROVIDER_ROLES } from '../../med/record';
export const NursingConsents: React.FC<{ c: A.AscCase }> = ({ c }) => {
  useMedTick(); const [actor] = useActor(); const x = S.caseById(c.id) || c; const [open, setOpen] = React.useState('');
  const FILES = { anesConsent: 'Anesthesia_Consent.html', consentConfirm: 'Procedure_Consent.html' } as const;
  const patientSig = (file: string) => (repo.getForm(c.visitId, file).signatures || []).find((g: any) => g.slotId === 'patient' || /patient|guardian/i.test(String(g.role)));
  const [, tick] = React.useState(0); React.useEffect(() => { if (!open) return; const t = setInterval(() => tick(x => x + 1), 800); return () => clearInterval(t); }, [open]);
  // The patient's signature is captured inside the consent form itself; the case flag follows it.
  React.useEffect(() => { (Object.keys(FILES) as (keyof typeof FILES)[]).forEach(k => { const g: any = patientSig(FILES[k]); const cur = S.caseById(c.id); if (g && cur && !(cur.d as any)[k]) S.setValue(cur, k, { by: actor.name, at: g.at || new Date().toISOString(), signed: true, at_station: 'nursing', inForm: FILES[k] }, actor.name, actor.role, `${k === 'anesConsent' ? 'Anesthesia' : 'Surgical'} consent signed by the patient inside the form at nursing admission`); }); });
  const row = (k: keyof typeof FILES, title: string, tid: string) => { const d: any = (x.d as any)[k]; const f = FILES[k];
    return <div key={k} data-testid={tid} data-signed={d ? '1' : '0'}><div className="v10-li"><span style={{ flex: 1 }}><b>{title}</b>{d ? <span className="sv-small sv-muted"> · signed {new Date(d.at).toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' })}</span> : <span className="sv-small sv-muted"> · the patient signs inside the form</span>}</span>
      {d && <span className="v10-chip ok">Signed</span>}<button type="button" className="a8-btn" onClick={() => setOpen(open === f ? '' : f)} data-testid={tid + '-open'}>{open === f ? 'Close form' : d ? 'View form' : 'Open & sign'}</button></div>
      {open === f && <div className="v103-consent" data-testid={tid + '-form'}><FormInPlace inline c={x} file={f} station="nursing" onClose={() => setOpen('')} /></div>}</div>; };
  return <section className="v10-card" data-testid="v102-nurse-consents"><h3 className="v10-h">Consents</h3>
    <p className="v10-sub">Open each consent, review it with the patient, and capture the patient's signature in the signature box at the end of the form. Anesthesia and the surgeon see links to both.</p>
    {row('anesConsent', 'Anesthesia consent', 'v102-nc-anes')}{row('consentConfirm', 'Surgical consent', 'v102-nc-surg')}</section>;
};

/** v10.5 · Nightingale draft summary of the medical history for the anesthesia station (drafts only; staff confirm). */
import { medRepo } from '../../med/record';
const HistoryDraft: React.FC<{ c: A.AscCase }> = ({ c }) => { const p = medRepo.patient(c.pid); if (!p) return null;
  const meds = ((medRepo as any).meds?.(p.id) || []).filter((m: any) => m.status === 'active'); const probs = ((medRepo as any).problems?.(p.id) || []).filter((x: any) => x.status === 'active');
  const hx: any = s81.ai(c.id) as any; const conf = !!(hx?.history || c.d.allergy);
  const parts = [p.allergies.length ? `Allergies: ${p.allergies.join('; ')}` : 'No known drug allergies', meds.length ? `Medications: ${meds.slice(0, 5).map((m: any) => m.name).join(', ')}${meds.length > 5 ? '…' : ''}` : 'No active medications on file', probs.length ? `Conditions: ${probs.slice(0, 4).map((x: any) => x.description).join(', ')}` : 'No active conditions recorded', c.d.vitals?.bp ? `Today BP ${c.d.vitals.bp}${c.d.vitals.hr ? `, HR ${c.d.vitals.hr}` : ''}` : '', c.d.npo ? `NPO solids ${c.d.npo.solids}, clears ${c.d.npo.clears}` : ''].filter(Boolean);
  return <div className="v105-hx" data-testid="v105-anes-hx"><div className="v105-k">Nightingale summary · medical history <span className="v10-chip">Draft</span>{conf && <span className="v10-chip ok">History verified</span>}</div><p>{parts.join('. ')}.</p></div>; };
