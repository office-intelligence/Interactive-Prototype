/* PIN-at-sign: the person who signs picks their own name and enters their own PIN. No sign-in/out between patients. */
import React, { useState } from 'react';
import { Lock } from 'lucide-react';
import { useActor } from '../med/ui';
import { peopleIn, verifyPersonPin } from './staff';
import { ForgotPin } from './v12/PinReset';
import { isAscEd } from '../edition';
import { SigPad, saveSig } from './asc82/sigpad';

export interface Signer { name: string; role: string; at: string; sig?: string }
export const PinSign: React.FC<{ title: string; statement: React.ReactNode; roles: string[]; onSigned: (s: Signer) => void; onClose: () => void; confirmLabel?: string; allow?: (p: { name: string; role: string }) => boolean; sigCase?: string }> = ({ sigCase, title, statement, roles, onSigned, onClose, confirmLabel = 'Sign', allow }) => {
  const [actor] = useActor(); const list = peopleIn(roles).filter(p => !allow || allow(p));
  const [who, setWho] = useState(list.some(p => p.name === actor.name) ? actor.name : ''); const [pin, setPin] = useState(''); const [err, setErr] = useState(''); const [forgot, setForgot] = useState(false); const [sig, setSig] = useState(''); const needSig = isAscEd;
  const go = () => { const e = verifyPersonPin(who, pin); if (e) { setErr(e); setPin(''); return; } if (needSig && !sig) { setErr('Draw your signature in the box first.'); return; } const p = list.find(x => x.name === who)!; const at = new Date().toISOString(); if (needSig) saveSig({ title, name: p.name, role: p.role, at, png: sig, caseId: sigCase }); onSigned({ name: p.name, role: p.role, at, ...(needSig ? { sig } : {}) }); };
  return <div className="sv-modal" role="dialog" aria-modal="true" aria-label={title} data-testid="pin-sign" onKeyDown={e => { if (e.key === 'Escape') onClose(); }}>
    <div className="sv-modal-scrim" onClick={onClose} />
    <div className="sv-modal-box">{forgot ? <ForgotPin names={list.map(p => p.name)} who={who} onBack={() => setForgot(false)} /> : <>
      <div className="flex items-center gap-2 mb-1"><Lock size={16} /><b className="text-[15px]">{title}</b></div>
      <p className="text-[13px] mb-3">{statement}</p>
      <label className="block mb-2"><span className="sv-label">Who is signing</span><select className="sv-input" value={who} onChange={e => { setWho(e.target.value); setErr(''); }} data-testid="pin-who"><option value="">Choose your name…</option>{list.map(p => <option key={p.name} value={p.name}>{p.name} · {p.role}</option>)}</select></label>
      <label className="block"><span className="sv-label">Your PIN</span><input className="sv-input" type="password" inputMode="numeric" autoComplete="off" autoFocus value={pin} onChange={e => setPin(e.target.value.replace(/\D/g, ''))} onKeyDown={e => { if (e.key === 'Enter') go(); }} data-testid="pin-input" /></label>
      {needSig && <div className="mt-2"><SigPad onChange={setSig} label="Your signature (finger, stylus or mouse)" testId="pin-sigpad" /></div>}
      <button type="button" className="sv-link text-[12.5px] mt-1" onClick={() => setForgot(true)} data-testid="pin-forgot-link">Forgot PIN?</button>
      {err && <p className="text-[12.5px] text-[var(--crit)] mt-2" role="alert" data-testid="pin-error">{err}</p>}
      <p className="text-[11.5px] sv-muted mt-2">The tablet stays signed in; only signing needs your own PIN. Test PIN for every fictional person: 1234.</p>
      <div className="flex justify-end gap-2 mt-3"><button type="button" className="sv-btn" onClick={onClose}>Cancel</button><button type="button" className="sv-btn primary" onClick={go} disabled={!who || !pin || (needSig && !sig)} data-testid="pin-confirm">{confirmLabel}</button></div>
    </>}</div>
  </div>;
};
