/*
 * Surgery.Vityls v0.5 · patient profile: payment type + referral source (configurable lists), and Edit profile & contact.
 *  - Payment type and referral source are asked in Add New Patient and kept on the patient record (MedPatient + the
 *    optional profile fields below). They show in the chart header line, the Patients list and Billing.
 *  - The lists are practice settings (Practice › Surgery.Vityls settings › Patient intake lists), audited.
 *  - Edit profile & contact (chart header › Profile): name, DOB, sex, language, phones, email, preferred contact for
 *    reminders, address, emergency contact, payment/insurance, referral. Every save is audited with the fields changed
 *    (`patient.profile`). Not a signature, so no PIN.
 * Henry: PATCH /patients/{id} {profile fields}; GET/PUT /practice/intake-lists. Payment type is a registration fact,
 * not a claim: eligibility and claims stay in the billing service.
 */
import React, { useEffect, useMemo, useState } from 'react';
import { UserCog, UserPlus } from 'lucide-react';
import { repo } from '../v6/dataLayer';
import { DialogShell, MaskedField, fieldErrors } from '../v7/ui';
import { medRepo, MedPatient, patientKey, ageFrom } from '../med/record';
import { useActor, useMedTick } from '../med/ui';
import { svRead, svWrite, seedHooks } from './store';
import { useSv } from './ui';

/* ---------------- configurable lists ---------------- */
export const DEFAULT_PAYMENT_TYPES = ['Self-pay (cosmetic)', 'Private insurance', 'Medicare', 'Medicare Advantage', 'Medicaid', 'Workers’ compensation', 'Patient financing (e.g. CareCredit)', 'Auto / personal injury (lien)', 'TRICARE / VA', 'Other'];
export const DEFAULT_REFERRAL_SOURCES = ['Physician referral', 'Patient / friend referral', 'Website / search', 'Social media', 'Online reviews', 'Insurance directory', 'Advertising', 'Event / seminar', 'Returning patient', 'Other'];
export interface IntakeLists { paymentTypes: string[]; referralSources: string[] }
export const intakeLists = (): IntakeLists => { const s = svRead<Partial<IntakeLists>>('intake-lists', {}); return { paymentTypes: s.paymentTypes?.length ? s.paymentTypes : DEFAULT_PAYMENT_TYPES, referralSources: s.referralSources?.length ? s.referralSources : DEFAULT_REFERRAL_SOURCES }; };
export function saveIntakeLists(l: IntakeLists, by: string, role: string, what: string) { svWrite('intake-lists', l); repo.audit({ caseId: 'practice', user: by, role, action: 'intake.lists', detail: what }); }
/** Insurance-type payers ask for a plan and member ID (optional at registration). */
export const isInsurance = (t?: string) => !!t && !/self-pay|financing|other/i.test(t);
/** Referral sources that name a person (who referred). */
export const needsReferrer = (s?: string) => !!s && /physician|patient|friend/i.test(s);

/* ---------------- profile fields on the patient record ---------------- */
export type PreferredContact = 'text' | 'email' | 'text+email' | 'phone';
export const PREFERRED_LABEL: Record<PreferredContact, string> = { text: 'Text message', email: 'Email', 'text+email': 'Text and email', phone: 'Phone call only (no automatic reminders)' };
export interface PatientProfile {
  firstName?: string; lastName?: string; altPhone?: string; preferredContact?: PreferredContact;
  address?: string; city?: string; state?: string; zip?: string;
  emergencyName?: string; emergencyRelation?: string; emergencyPhone?: string;
  paymentType?: string; insuranceCarrier?: string; memberId?: string; referralSource?: string; referredBy?: string;
  profileUpdatedAt?: string; profileUpdatedBy?: string;
}
export type SvPatient = MedPatient & PatientProfile;
export const svPatient = (pid: string) => medRepo.patient(pid) as SvPatient | undefined;
export const preferredOf = (p: SvPatient): PreferredContact => p.preferredContact || (p.phone ? 'text' : p.email ? 'email' : 'phone');
const splitName = (n: string) => { const parts = n.trim().split(/\s+/); return { first: parts[0] || '', last: parts.slice(1).join(' ') }; };
/** Seeded charts keep the emergency contact as one line: "Gene Testwood (daughter) (555) 014-1002". */
export function emergencyParts(p: SvPatient) {
  if (p.emergencyName || p.emergencyPhone) return { name: p.emergencyName || '', relation: p.emergencyRelation || '', phone: p.emergencyPhone || '' };
  const s = p.emergencyContact || ''; const m = s.match(/^(.*?)\s*\(([^)0-9]+)\)\s*(\(\d{3}\)\s*\d{3}-\d{4})?\s*$/);
  return m ? { name: m[1].trim(), relation: m[2].trim(), phone: m[3] || '' } : { name: s, relation: '', phone: '' };
}
export const addressLine = (p: SvPatient) => [p.address, [p.city, [p.state, p.zip].filter(Boolean).join(' ')].filter(Boolean).join(', ')].filter(Boolean).join(', ');

/* ---------------- shared "Billing & referral" fields ---------------- */
export interface PayRef { paymentType: string; insuranceCarrier: string; memberId: string; referralSource: string; referredBy: string }
export const PayRefFields: React.FC<{ v: PayRef; set: (v: PayRef) => void; showErrors: boolean; requirePayment?: boolean }> = ({ v, set, showErrors, requirePayment = true }) => {
  const l = intakeLists(); const badPay = requirePayment && showErrors && !v.paymentType;
  const opts = (list: string[], cur: string) => cur && !list.includes(cur) ? [...list, cur] : list;
  return <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
    <div><label className="vy-label">Payment type{requirePayment && <span className="text-[#B42318]" aria-hidden> *</span>}</label>
      <select className={`vy-input ${badPay ? 'vy-input-invalid' : ''}`} value={v.paymentType} onChange={e => set({ ...v, paymentType: e.target.value })} data-testid="ap-payment"><option value="">Select…</option>{opts(l.paymentTypes, v.paymentType).map(o => <option key={o}>{o}</option>)}</select>
      {badPay && <p className="vy-field-error" role="alert">Required</p>}</div>
    <div><label className="vy-label">Referral source</label>
      <select className="vy-input" value={v.referralSource} onChange={e => set({ ...v, referralSource: e.target.value })} data-testid="ap-referral"><option value="">Select…</option>{opts(l.referralSources, v.referralSource).map(o => <option key={o}>{o}</option>)}</select></div>
    {isInsurance(v.paymentType) && <>
      <div><label className="vy-label">Insurance / plan (optional)</label><input className="vy-input" value={v.insuranceCarrier} onChange={e => set({ ...v, insuranceCarrier: e.target.value })} data-testid="ap-carrier" /></div>
      <div><label className="vy-label">Member ID (optional)</label><input className="vy-input" value={v.memberId} onChange={e => set({ ...v, memberId: e.target.value })} data-testid="ap-member" /></div></>}
    {(needsReferrer(v.referralSource) || v.referralSource === 'Other') && <div className="sm:col-span-2"><label className="vy-label">{v.referralSource === 'Other' ? 'Referral detail' : 'Referred by (name)'}</label><input className="vy-input" value={v.referredBy} onChange={e => set({ ...v, referredBy: e.target.value })} data-testid="ap-referred-by" /></div>}
  </div>;
};

/* ---------------- chart header line ---------------- */
export const ProfileLine: React.FC<{ p: SvPatient; onEdit: () => void }> = ({ p, onEdit }) => {
  const ec = emergencyParts(p);
  return <div className="py-1.5 border-b border-[var(--line)] text-[13px] flex flex-wrap items-center gap-x-3 gap-y-1" data-testid="chart-profile-line">
    <b className="text-[11px] tracking-[.07em] uppercase">Contact</b>
    <span>{p.phone || <span className="sv-muted">no phone</span>}{p.email ? ` · ${p.email}` : ''}</span>
    {ec.name && <span className="sv-muted">Emergency: {ec.name}{ec.relation ? ` (${ec.relation})` : ''}</span>}
    <span data-testid="chart-payment"><b className="text-[11px] tracking-[.07em] uppercase">Payment</b> {p.paymentType || <span className="sv-warn">not recorded</span>}{p.insuranceCarrier ? ` · ${p.insuranceCarrier}` : ''}</span>
    <span data-testid="chart-referral"><b className="text-[11px] tracking-[.07em] uppercase">Referral</b> {p.referralSource ? `${p.referralSource}${p.referredBy ? ` · ${p.referredBy}` : ''}` : <span className="sv-muted">—</span>}</span>
    <button type="button" className="sv-link ml-auto inline-flex items-center gap-1" onClick={onEdit} data-testid="chart-edit-profile"><UserCog size={14} />Edit profile &amp; contact</button>
  </div>;
};

/* ---------------- Edit profile & contact ---------------- */
const LABEL: Record<string, string> = { name: 'Name', dob: 'Date of birth', sex: 'Sex', language: 'Language', phone: 'Mobile phone', altPhone: 'Other phone', email: 'Email', preferredContact: 'Preferred contact', address: 'Street address', city: 'City', state: 'State', zip: 'ZIP', emergencyName: 'Emergency contact', emergencyRelation: 'Emergency relationship', emergencyPhone: 'Emergency phone', paymentType: 'Payment type', insuranceCarrier: 'Insurance / plan', memberId: 'Member ID', referralSource: 'Referral source', referredBy: 'Referred by' };
export const EditProfileDialog: React.FC<{ pid: string; onClose: () => void }> = ({ pid, onClose }) => {
  useMedTick(); const [actor] = useActor(); const { toast } = useSv(); const p = svPatient(pid);
  const init = useMemo(() => { if (!p) return null; const n = splitName(p.name); const ec = emergencyParts(p); return {
    first: p.firstName || n.first, last: p.lastName || n.last, dob: p.dob || '', sex: p.sex as string, language: p.language || 'English', phone: p.phone || '', altPhone: p.altPhone || '', email: p.email || '', preferredContact: preferredOf(p) as string,
    address: p.address || '', city: p.city || '', state: p.state || '', zip: p.zip || '', emergencyName: ec.name, emergencyRelation: ec.relation, emergencyPhone: ec.phone,
    paymentType: p.paymentType || '', insuranceCarrier: p.insuranceCarrier || '', memberId: p.memberId || '', referralSource: p.referralSource || '', referredBy: p.referredBy || '' }; }, [pid]); // eslint-disable-line
  const [f, setF] = useState(init); const [showErrors, setShowErrors] = useState(false);
  useEffect(() => { setF(init); }, [init]);
  if (!p || !f) return null;
  const set = (k: keyof typeof f) => (v: string) => setF({ ...f, [k]: v });
  const errs = [...fieldErrors([{ kind: 'date', value: f.dob, required: true, past: true }, { kind: 'phone', value: f.phone, required: true }, { kind: 'phone', value: f.altPhone }, { kind: 'email', value: f.email }, { kind: 'phone', value: f.emergencyPhone }, { kind: 'zip', value: f.zip }]), ...(!f.first.trim() ? ['first'] : []), ...(!f.last.trim() ? ['last'] : []),
    ...((f.preferredContact === 'email' || f.preferredContact === 'text+email') && !f.email.trim() ? ['email needed'] : [])];
  const save = (e?: React.FormEvent) => {
    e?.preventDefault(); setShowErrors(true); if (errs.length) return;
    const t = (s: string) => s.trim() || undefined; const name = `${f.first.trim()} ${f.last.trim()}`;
    const next: SvPatient = { ...p, name, firstName: f.first.trim(), lastName: f.last.trim(), dob: f.dob.trim(), sex: f.sex as MedPatient['sex'], language: f.language.trim() || 'English', phone: f.phone.trim(), altPhone: t(f.altPhone), email: t(f.email), preferredContact: f.preferredContact as PreferredContact,
      address: t(f.address), city: t(f.city), state: t(f.state), zip: t(f.zip), emergencyName: t(f.emergencyName), emergencyRelation: t(f.emergencyRelation), emergencyPhone: t(f.emergencyPhone),
      emergencyContact: f.emergencyName.trim() ? `${f.emergencyName.trim()}${f.emergencyRelation.trim() ? ` (${f.emergencyRelation.trim()})` : ''}${f.emergencyPhone.trim() ? ` ${f.emergencyPhone.trim()}` : ''}` : undefined,
      paymentType: t(f.paymentType), insuranceCarrier: isInsurance(f.paymentType) ? t(f.insuranceCarrier) : undefined, memberId: isInsurance(f.paymentType) ? t(f.memberId) : undefined, referralSource: t(f.referralSource), referredBy: t(f.referredBy),
      insurance: isInsurance(f.paymentType) ? [f.paymentType, f.insuranceCarrier.trim(), f.memberId.trim() && `ID ${f.memberId.trim()}`].filter(Boolean).join(' · ') : f.paymentType || p.insurance,
      profileUpdatedAt: new Date().toISOString(), profileUpdatedBy: actor.name };
    const changed = (Object.keys(init!) as (keyof typeof f)[]).filter(k => (init as any)[k] !== (f as any)[k]).map(k => k === 'first' || k === 'last' ? 'name' : k);
    const uniq = Array.from(new Set(changed));
    if (!uniq.length) { onClose(); return; }
    medRepo.savePatient(next);
    const show = (k: string) => ['name', 'paymentType', 'referralSource', 'preferredContact', 'language', 'sex'].includes(k);
    repo.audit({ caseId: patientKey(p.id), user: actor.name, role: actor.role, action: 'patient.profile', detail: `Profile & contact updated: ${(uniq as string[]).map(k => show(k) ? `${LABEL[k]} → ${k === 'name' ? name : (next as any)[k] ?? '—'}` : LABEL[k]).join('; ')}` });
    window.dispatchEvent(new Event('vityls-med-updated'));
    toast(`Profile saved for ${name} (${uniq.length} field${uniq.length === 1 ? '' : 's'} changed, audited).`); onClose();
  };
  const T: React.FC<{ k: keyof typeof f; label: string; required?: boolean; className?: string; tid?: string }> = ({ k, label, required, className = '', tid }) => { const bad = required && showErrors && !f[k].trim();
    return <div className={className}><label className="vy-label">{label}{required && <span className="text-[#B42318]" aria-hidden> *</span>}</label><input className={`vy-input ${bad ? 'vy-input-invalid' : ''}`} value={f[k]} onChange={e => set(k)(e.target.value)} data-testid={tid} />{bad && <p className="vy-field-error" role="alert">Required</p>}</div>; };
  return <div className="sv-dlg"><DialogShell as="form" onSubmit={save} testId="edit-profile-dialog" size="lg" icon={<UserCog />} title={`Profile & contact · ${p.name}`} subtitle={`${p.id} · ${ageFrom(p.dob)} · changes are audited`} onClose={onClose}
    footer={<><button type="button" className="sv-btn" onClick={onClose}>Cancel</button><button type="submit" className="sv-btn primary" data-testid="profile-save">Save profile</button></>}>
    <div className="vy-section-title">Identity</div>
    <div className="grid grid-cols-1 sm:grid-cols-6 gap-3">
      {T({ k: 'first', label: 'First name', required: true, className: 'sm:col-span-3', tid: 'pf-first' })}
      {T({ k: 'last', label: 'Last name', required: true, className: 'sm:col-span-3', tid: 'pf-last' })}
      <MaskedField className="sm:col-span-2" label="Date of birth" kind="date" past required value={f.dob} onChange={set('dob')} showErrors={showErrors} testId="pf-dob" />
      <div className="sm:col-span-2"><label className="vy-label">Sex</label><select className="vy-input" value={f.sex} onChange={e => set('sex')(e.target.value)} data-testid="pf-sex">{['Female', 'Male', 'Other'].map(o => <option key={o}>{o}</option>)}</select></div>
      {T({ k: 'language', label: 'Preferred language', className: 'sm:col-span-2' })}
    </div>
    <div className="vy-section-title mt-5">Contact</div>
    <div className="grid grid-cols-1 sm:grid-cols-6 gap-3">
      <MaskedField className="sm:col-span-2" label="Mobile phone" kind="phone" required value={f.phone} onChange={set('phone')} showErrors={showErrors} testId="pf-phone" />
      <MaskedField className="sm:col-span-2" label="Other phone" kind="phone" value={f.altPhone} onChange={set('altPhone')} showErrors={showErrors} testId="pf-altphone" />
      <MaskedField className="sm:col-span-2" label="Email" kind="email" value={f.email} onChange={set('email')} showErrors={showErrors} testId="pf-email" />
      <div className="sm:col-span-6"><label className="vy-label">Preferred contact for reminders</label><select className="vy-input" value={f.preferredContact} onChange={e => set('preferredContact')(e.target.value)} data-testid="pf-preferred">{(Object.keys(PREFERRED_LABEL) as PreferredContact[]).map(k => <option key={k} value={k}>{PREFERRED_LABEL[k]}</option>)}</select>
        {showErrors && errs.includes('email needed') && <p className="vy-field-error" role="alert">Add an email address for email reminders.</p>}</div>
      {T({ k: 'address', label: 'Street address', className: 'sm:col-span-6', tid: 'pf-address' })}
      {T({ k: 'city', label: 'City', className: 'sm:col-span-3', tid: 'pf-city' })}
      {T({ k: 'state', label: 'State', className: 'sm:col-span-1', tid: 'pf-state' })}
      <MaskedField className="sm:col-span-2" label="ZIP" kind="zip" value={f.zip} onChange={set('zip')} showErrors={showErrors} testId="pf-zip" />
    </div>
    <div className="vy-section-title mt-5">Emergency contact</div>
    <div className="grid grid-cols-1 sm:grid-cols-6 gap-3">
      {T({ k: 'emergencyName', label: 'Name', className: 'sm:col-span-3', tid: 'pf-ec-name' })}
      {T({ k: 'emergencyRelation', label: 'Relationship', className: 'sm:col-span-1', tid: 'pf-ec-rel' })}
      <MaskedField className="sm:col-span-2" label="Phone" kind="phone" value={f.emergencyPhone} onChange={set('emergencyPhone')} showErrors={showErrors} testId="pf-ec-phone" />
    </div>
    <div className="vy-section-title mt-5">Billing &amp; referral</div>
    <PayRefFields v={f} set={v => setF({ ...f, ...v })} showErrors={showErrors} requirePayment={false} />
    {p.profileUpdatedAt && <p className="text-[12px] sv-muted mt-3">Last updated {new Date(p.profileUpdatedAt).toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' })} by {p.profileUpdatedBy}.</p>}
    {showErrors && errs.length > 0 && <p className="vy-field-error mt-3" role="alert" data-testid="pf-errors">Please fix the highlighted fields.</p>}
  </DialogShell></div>;
};

/* ---------------- Add New Patient (Surgery): ASC fields + payment type + referral source ---------------- */
export interface NewPatientInput { first: string; last: string; dob: string; sex: MedPatient['sex']; phone: string; email: string; payRef: PayRef }
export const SvAddPatientDialog: React.FC<{ onClose: () => void; onCreate: (x: NewPatientInput) => void }> = ({ onClose, onCreate }) => {
  const [f, setF] = useState({ first: '', last: '', dob: '', sex: '', phone: '', email: '' }); const [pr, setPr] = useState<PayRef>({ paymentType: '', insuranceCarrier: '', memberId: '', referralSource: '', referredBy: '' });
  const [showErrors, setShowErrors] = useState(false); const age = /^\d{2}\/\d{2}\/\d{4}$/.test(f.dob) ? ageFrom(f.dob) : '';
  const errs = [...fieldErrors([{ kind: 'date', value: f.dob, required: true, past: true }, { kind: 'phone', value: f.phone, required: true }, { kind: 'email', value: f.email }]), ...(!f.first.trim() ? ['first'] : []), ...(!f.last.trim() ? ['last'] : []), ...(!f.sex ? ['sex'] : []), ...(!pr.paymentType ? ['payment'] : [])];
  const submit = (e?: React.FormEvent) => { e?.preventDefault(); setShowErrors(true); if (errs.length) return; onCreate({ first: f.first.trim(), last: f.last.trim(), dob: f.dob.trim(), sex: f.sex as MedPatient['sex'], phone: f.phone.trim(), email: f.email.trim(), payRef: pr }); };
  const req = (v: string) => showErrors && !v.trim();
  return <div className="sv-dlg"><DialogShell as="form" onSubmit={submit} testId="add-patient-dialog" size="md" icon={<UserPlus />} title="Add New Patient" subtitle="Create the chart, then send the new-patient forms" onClose={onClose}
    footer={<><button type="button" className="sv-btn" onClick={onClose}>Cancel</button><button type="submit" className="sv-btn primary" data-testid="create-patient"><UserPlus size={15} />Create Patient Chart</button></>}>
    <p className="text-[13.5px] sv-muted mb-3">Only what's needed to create the chart, contact the patient and know how the visit is paid. Address, history and the rest come in with the registration forms.</p>
    <div className="vy-section-title">Patient identity</div>
    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
      <div><label className="vy-label">First name<span className="text-[#B42318]" aria-hidden> *</span></label><input className={`vy-input ${req(f.first) ? 'vy-input-invalid' : ''}`} value={f.first} onChange={e => setF({ ...f, first: e.target.value })} data-testid="ap-first" autoComplete="off" />{req(f.first) && <p className="vy-field-error" role="alert">Required</p>}</div>
      <div><label className="vy-label">Last name<span className="text-[#B42318]" aria-hidden> *</span></label><input className={`vy-input ${req(f.last) ? 'vy-input-invalid' : ''}`} value={f.last} onChange={e => setF({ ...f, last: e.target.value })} data-testid="ap-last" autoComplete="off" />{req(f.last) && <p className="vy-field-error" role="alert">Required</p>}</div>
      <MaskedField label="Date of birth" kind="date" past required value={f.dob} onChange={v => setF({ ...f, dob: v })} showErrors={showErrors} testId="ap-dob" />
      <div className="grid grid-cols-2 gap-3"><div><label className="vy-label">Age</label><input className="vy-input bg-[#f6f7f8]" readOnly tabIndex={-1} value={age} placeholder="from DOB" /></div>
        <div><label className="vy-label">Gender<span className="text-[#B42318]" aria-hidden> *</span></label><select className={`vy-input ${req(f.sex) ? 'vy-input-invalid' : ''}`} value={f.sex} onChange={e => setF({ ...f, sex: e.target.value })} data-testid="ap-gender"><option value="">Select…</option>{['Female', 'Male', 'Other'].map(o => <option key={o}>{o}</option>)}</select>{req(f.sex) && <p className="vy-field-error" role="alert">Required</p>}</div></div>
    </div>
    <p className="text-[12.5px] sv-muted mt-1">MRN is assigned automatically.</p>
    <div className="vy-section-title mt-4">Contact</div>
    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
      <MaskedField label="Mobile phone" kind="phone" required value={f.phone} onChange={v => setF({ ...f, phone: v })} showErrors={showErrors} testId="ap-phone" />
      <MaskedField label="Email (optional)" kind="email" value={f.email} onChange={v => setF({ ...f, email: v })} showErrors={showErrors} testId="ap-email" />
    </div>
    <div className="vy-section-title mt-4">Payment &amp; referral</div>
    <PayRefFields v={pr} set={setPr} showErrors={showErrors} />
    <p className="text-[12.5px] sv-muted mt-1">Lists are set in Practice › Surgery.Vityls settings › Patient intake lists.</p>
    {showErrors && errs.length > 0 && <p className="vy-field-error mt-3" role="alert" data-testid="ap-errors">Please fix the highlighted fields.</p>}
  </DialogShell></div>;
};

/* ---------------- Practice settings section ---------------- */
export const IntakeListsSettings: React.FC<{ can: boolean; actor: { name: string; role: string } }> = ({ can, actor }) => {
  useMedTick(); const { toast } = useSv(); const cur = intakeLists(); const [pt, setPt] = useState(cur.paymentTypes.join('\n')); const [rs, setRs] = useState(cur.referralSources.join('\n'));
  const parse = (s: string) => Array.from(new Set(s.split('\n').map(x => x.trim()).filter(Boolean)));
  const dirty = parse(pt).join('|') !== cur.paymentTypes.join('|') || parse(rs).join('|') !== cur.referralSources.join('|');
  const save = () => { const l = { paymentTypes: parse(pt), referralSources: parse(rs) }; if (!l.paymentTypes.length || !l.referralSources.length) { toast('Each list needs at least one entry.'); return; } saveIntakeLists(l, actor.name, actor.role, `Patient intake lists saved · payment types: ${l.paymentTypes.join(', ')} · referral sources: ${l.referralSources.join(', ')}`); toast('Patient intake lists saved. Add New Patient and profiles use them now.'); };
  return <section className="mt-6 sv-sec" data-testid="intake-lists">
    <h2 className="sv-h">Patient intake lists</h2>
    <p className="text-[13px] sv-muted mb-2">Choices in Add New Patient and Edit profile. One per line. Removing an entry does not change patients who already have it.</p>
    <div className="grid sm:grid-cols-2 gap-4">
      <label><span className="sv-label">Payment types</span><textarea className="sv-input" rows={9} value={pt} disabled={!can} onChange={e => setPt(e.target.value)} data-testid="lists-payment" /></label>
      <label><span className="sv-label">Referral sources</span><textarea className="sv-input" rows={9} value={rs} disabled={!can} onChange={e => setRs(e.target.value)} data-testid="lists-referral" /></label>
    </div>
    {can && <div className="flex flex-wrap gap-2 mt-2"><button type="button" className="sv-btn sm" onClick={() => { setPt(DEFAULT_PAYMENT_TYPES.join('\n')); setRs(DEFAULT_REFERRAL_SOURCES.join('\n')); }}>Restore defaults</button><button type="button" className="sv-btn sm primary" disabled={!dirty} onClick={save} data-testid="lists-save">Save lists</button></div>}
  </section>;
};

/** Billing panel: how this patient pays and who referred them (registration facts, editable in the profile). */
export const PayerLine: React.FC<{ p: MedPatient }> = ({ p }) => {
  const x = p as SvPatient; const [edit, setEdit] = useState(false);
  return <div className="text-[13px] py-1.5 mb-2 border-b border-[var(--line)] flex flex-wrap gap-x-4 gap-y-1 items-center" data-testid="billing-payer">
    <span><b className="text-[11px] tracking-[.07em] uppercase">Payment type</b> {x.paymentType || <span className="sv-warn">not recorded</span>}{x.insuranceCarrier ? ` · ${x.insuranceCarrier}` : ''}{x.memberId ? ` · ID ${x.memberId}` : ''}</span>
    <span><b className="text-[11px] tracking-[.07em] uppercase">Referral</b> {x.referralSource ? `${x.referralSource}${x.referredBy ? ` · ${x.referredBy}` : ''}` : '—'}</span>
    <button type="button" className="sv-link ml-auto" onClick={() => setEdit(true)}>Edit</button>
    {edit && <EditProfileDialog pid={p.id} onClose={() => setEdit(false)} />}
  </div>;
};

/* fictional seed: payment type + referral for the seeded charts (so the chart line is complete) */
seedHooks.push(() => {
  const M: Record<string, Partial<PatientProfile>> = {
    'MED-1001': { paymentType: 'Medicare', insuranceCarrier: 'Medicare Part B (fictional)', referralSource: 'Physician referral', referredBy: 'Lena Brooks, MD (fictional)', preferredContact: 'text+email' },
    'MED-1003': { paymentType: 'Self-pay (cosmetic)', referralSource: 'Social media' },
    'MED-1004': { paymentType: 'Self-pay (cosmetic)', referralSource: 'Patient / friend referral', referredBy: 'Ellen Testwood' },
    'MED-1005': { paymentType: 'Self-pay (cosmetic)', referralSource: 'Website / search' },
    'MED-1006': { paymentType: 'Private insurance', insuranceCarrier: 'Blue Harbor PPO (fictional)', memberId: 'BHX-00418', referralSource: 'Returning patient' },
    'MED-1007': { paymentType: 'Patient financing (e.g. CareCredit)', referralSource: 'Online reviews' },
  };
  Object.entries(M).forEach(([id, x]) => { const p = medRepo.patient(id); if (p) medRepo.savePatient({ ...p, ...x } as SvPatient); });
});
