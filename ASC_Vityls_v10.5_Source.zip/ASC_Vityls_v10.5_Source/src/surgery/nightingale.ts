/*
 * Nightingale for Surgery.Vityls v0.1 — on-device and scripted from recorded chart data only (no remote AI, no PHI
 * leaves the browser). Every answer carries citations (Ref) that open the source in the right panel, optional
 * navigation (Act) and the most likely next steps. Nightingale never signs, orders, clears or scores risk; it says
 * plainly when something is not recorded. Production needs a BAA-covered model grounded in the same sources.
 */
import { repo } from '../v6/dataLayer';
import { effectiveAllergy } from '../v7/allergy';
import { medRepo, MedPatient, MedVisit, LabResult, patientKey, fmtDate, usDate, vitalsText, conditionLabel, ageFrom, isoDay, addDays, PROVIDER_ROLES, RISK_DECIDER_ROLES, toMin } from '../med/record';
import { riskFlags, reviewState } from '../med/risk';
import { networkRepo } from '../med/network';
import { activeCaregivers, scopeText } from '../med/portal';
import { getSettings } from '../med/settings';
import { ascCases, ascCasesFor, ascBlocks, surgicalHistory, modules, nurseAdmission, checkoutOrders } from './store';
import { coordinatorFor } from './staff';

export type RefKind = 'summary' | 'labs' | 'labslip' | 'note' | 'vitals' | 'meds' | 'problems' | 'allergies' | 'intake' | 'risk' | 'asc' | 'careteam' | 'caregivers' | 'careplan' | 'journal' | 'trends' | 'audit' | 'billing' | 'monitoring' | 'nurse' | 'history' | 'messages' | 'conditions' | 'visits' | 'scribe' | 'ascchart' | 'bodychart' | 'photos' | 'documents' | 'doc' | 'contactnotes' | 'quote';
export interface Ref { kind: RefKind; id?: string; label: string; pid?: string }
export type Act = { type: 'panel'; ref: Ref } | { type: 'chart'; pid: string; ref?: Ref } | { type: 'episode'; pid: string } | { type: 'fullchart'; pid: string } | { type: 'station'; visitId: string } | { type: 'tab'; tab: 'home' | 'surgeries' | 'schedule' | 'patients' | 'messages' | 'practice' | 'surgery-settings' | 'forms' | 'med-settings' | 'staff' | 'profile' | 'billing-hub' | 'ops-hub' | 'people' | 'documents' | 'records-admin' | 'form-editor' };
export interface Step { label: string; act: Act; clinical?: boolean }
export interface Answer { q: string; text: string; cites: Ref[]; act?: Act; at: string; pid?: string }

export const STATION_LABEL: Record<string, string> = { scheduled: 'Not arrived', 'check-in': 'Check-in', rooming: 'Nurse intake', provider: 'Surgeon', checkout: 'Checkout', complete: 'Complete' };
export const first = (n: string) => n.split(/\s+/)[0];
const shortDate = (iso: string) => { const m = iso.match(/^(\d{4})-(\d{2})-(\d{2})/); return m ? `${m[2]}/${m[3]}/${m[1].slice(2)}` : iso; };
export const daysFrom = (iso: string) => Math.round((new Date(iso.slice(0, 10) + 'T12:00:00').getTime() - new Date(isoDay() + 'T12:00:00').getTime()) / 864e5);
export const relDay = (iso: string) => { const d = daysFrom(iso); return d === 0 ? 'today' : d === 1 ? 'tomorrow' : d === -1 ? 'yesterday' : d > 0 ? `in ${d} days` : `${-d} days ago`; };

/* ---------------- source helpers ---------------- */
export function labSlips(pid: string): { date: string; labs: LabResult[] }[] {
  const m = new Map<string, LabResult[]>(); medRepo.labs(pid).forEach(l => m.set(l.collectedAt, [...(m.get(l.collectedAt) || []), l]));
  return [...m.entries()].map(([date, labs]) => ({ date, labs })).sort((a, b) => b.date.localeCompare(a.date));
}
export const slipRef = (date: string, pid?: string): Ref => ({ kind: 'labslip', id: date, label: `Lab slip ${shortDate(date)}`, pid });
export const noteRef = (v: MedVisit): Ref => ({ kind: 'note', id: v.id, label: `Visit note ${shortDate(v.date)}`, pid: v.patientId });
export const R = (kind: RefKind, label: string, pid?: string, id?: string): Ref => ({ kind, label, pid, id });
export const todayVisit = (pid: string) => medRepo.visits(pid).find(v => v.date === isoDay() && v.step !== 'complete') || medRepo.visits(pid).find(v => v.date === isoDay());
export const nextAscCase = (pid: string) => modules().networkAsc ? ascCasesFor(pid).filter(c => c.date >= isoDay()).sort((a, b) => a.date.localeCompare(b.date))[0] : undefined;
export const openRisks = (p: MedPatient) => { const rv = medRepo.riskReviews(p.id); return riskFlags(p).filter(f => { const r = reviewState(f, rv); return !r.review || r.changedSinceReview; }); };
export const awaitingLabs = (pid?: string) => medRepo.labs(pid).filter(l => l.status === 'awaiting-review');
export const lastFrom = (pid: string) => { const m = medRepo.messages(pid).slice(-1)[0]; return m && m.from !== 'office' ? m : undefined; };
const ascWaiting = (pid: string) => ascCasesFor(pid).map(c => ({ c, m: networkRepo.thread(c.id).slice(-1)[0] })).filter(x => x.m && x.m.fromOrg === 'asc');

/* ---------------- next steps ---------------- */
export function chartNextSteps(p: MedPatient, role: string): Step[] {
  const out: Step[] = []; const v = todayVisit(p.id); const f = first(p.name);
  if (v && v.step !== 'complete') out.push({ label: v.step === 'scheduled' ? `Check in ${f} · ${v.time} ${v.visitType.toLowerCase()}` : `Continue ${f}'s visit · ${STATION_LABEL[v.step]}`, act: { type: 'station', visitId: v.id } });
  const labs = awaitingLabs(p.id); if (labs.length) out.push({ label: `${PROVIDER_ROLES.includes(role) ? 'Review' : 'Provider review:'} ${labs.length} new result${labs.length === 1 ? '' : 's'} from ${shortDate(labs[labs.length - 1].collectedAt)}`, act: { type: 'panel', ref: slipRef(labs[labs.length - 1].collectedAt, p.id) }, clinical: true });
  const nc = nextAscCase(p.id); const risks = modules().riskAwareness ? openRisks(p) : [];
  if (nc && risks.length) out.push({ label: `Review ${risks.length} risk factor${risks.length === 1 ? '' : 's'} before surgery ${relDay(nc.date)}${RISK_DECIDER_ROLES.includes(role) ? '' : ' (surgeon)'}`, act: { type: 'panel', ref: R('risk', 'Risk awareness', p.id) }, clinical: true });
  const m = lastFrom(p.id); if (m) out.push({ label: `Reply to ${m.author.replace(/\s*\(.*\)/, '')}'s portal message`, act: { type: 'panel', ref: R('messages', 'Portal messages', p.id) } });
  const aw = modules().networkAsc ? ascWaiting(p.id) : []; if (aw.length) out.push({ label: `Answer ${getSettings().ascName.replace(/\s*\(.*\)/, '')}'s request`, act: { type: 'panel', ref: R('asc', 'ASC case thread', p.id, aw[0].c.id) } });
  const a = effectiveAllergy(p.allergies, patientKey(p.id)); if (a.pendingConfirm || a.state === 'not-reported') out.push({ label: a.state === 'not-reported' ? 'Ask and record allergies (not reported)' : 'Confirm patient-reported allergies at nurse intake', act: { type: 'panel', ref: R('allergies', 'Allergies', p.id) }, clinical: true });
  return out.slice(0, 4);
}
export function todayNextSteps(): Step[] {
  const T = isoDay(); const today = medRepo.visits().filter(v => v.date === T).sort((a, b) => toMin(a.time).localeCompare(toMin(b.time)));
  const out: Step[] = [];
  const waiting = today.find(v => v.step === 'scheduled'); const inProg = today.filter(v => v.step !== 'scheduled' && v.step !== 'complete');
  inProg.slice(0, 1).forEach(v => out.push({ label: `Continue ${medRepo.patient(v.patientId)?.name} · ${STATION_LABEL[v.step]}`, act: { type: 'station', visitId: v.id } }));
  if (waiting) out.push({ label: `Check in ${medRepo.patient(waiting.patientId)?.name} · ${waiting.time}`, act: { type: 'station', visitId: waiting.id } });
  const labs = awaitingLabs(); if (labs.length) out.push({ label: `${labs.length} result${labs.length === 1 ? '' : 's'} to review (${medRepo.patient(labs[0].patientId)?.name})`, act: { type: 'chart', pid: labs[0].patientId, ref: slipRef(labs[labs.length - 1].collectedAt, labs[0].patientId) }, clinical: true });
  const msgs = medRepo.patients().filter(p => lastFrom(p.id)); if (msgs.length) out.push({ label: `${msgs.length} portal message${msgs.length === 1 ? '' : 's'} waiting`, act: { type: 'tab', tab: 'messages' } });
  return out.slice(0, 4);
}

/* ---------------- living summary facts (also used by answers) ---------------- */
export function surgicalHistoryLines(p: MedPatient) {
  const out = surgicalHistory(p.id).map(h => ({ text: `${h.text}${h.year ? ` (${h.year})` : ''}`, detail: h.detail || '', ref: R('history', 'Medical history form', p.id) }));
  ascCasesFor(p.id).filter(c => c.date < isoDay() && !out.some(o => o.text.toLowerCase().startsWith(c.procedure.toLowerCase()))).forEach(c => out.push({ text: `${c.procedure} (${usDate(c.date)})`, detail: c.ascName, ref: R('asc', 'ASC case', p.id, c.id) }));
  return out;
}

/* ---------------- answers ---------------- */
/** v0.6: other Surgery modules (documents, contact notes) answer their own questions without an import cycle. */
export const chartAnswerHooks: ((pid: string, q: string) => { text: string; cites: Ref[]; act?: Act } | null)[] = [];
const now = () => new Date().toISOString();
export function chartAnswer(pid: string, question: string): Answer {
  const p = medRepo.patient(pid); const q = question.toLowerCase().trim(); const A = (text: string, cites: Ref[] = [], act?: Act): Answer => ({ q: question, text, cites, act, at: now(), pid });
  if (!p) return A('Open a chart first. I answer only from what is recorded.');
  const f = first(p.name); const her = p.sex === 'Male' ? 'his' : p.sex === 'Female' ? 'her' : 'their';
  // destinations (Kevin: care team, caregivers, network ASC, monitoring, journal, trends are pulls, not cards)
  if (/photo|picture|before.?and.?after|before\/after/.test(q)) return A(`Opening ${f}'s clinical photos. Pick up to four to compare full screen (two side by side, three or four in a grid). Every view is recorded in the audit trail.`, [R('photos', 'Clinical photos', pid)], { type: 'panel', ref: R('photos', 'Clinical photos', pid) });
  if (/body ?chart|diagram|drawing|sketch/.test(q)) return A(`Opening ${f}'s body charts. Surgeons draw new ones in the visit workflow › Charts & photos; saved charts are visible to the care team.`, [R('bodychart', 'Body charts', pid)], { type: 'panel', ref: R('bodychart', 'Body charts', pid) });
  for (const h of chartAnswerHooks) { const r = h(pid, q); if (r) return A(r.text, r.cites, r.act); }
  if (/coordinator/.test(q)) { const c = coordinatorFor(pid); return A(c ? `${f}'s surgical coordinator is ${c.name}. Change it in the chart header (optional).` : `No surgical coordinator is assigned to ${f}. That's optional; assign one in the chart header if your practice uses coordinators.`); }
  if (/care ?team|who (is|are) (her|his|their) (doctor|surgeon|cardiolog|pcp)|primary care|cardiolog/.test(q)) return A(`Care team: ${p.careTeam.map(c => `${c.name} (${c.role}${c.phone ? `, ${c.phone}` : ''})`).join('; ')}.${p.emergencyContact ? ` Emergency contact: ${p.emergencyContact}.` : ''}`, [R('careteam', 'Care team', pid)], { type: 'panel', ref: R('careteam', 'Care team', pid) });
  if (/caregiver|proxy|daughter|\bson\b|husband|wife|family|\bgene\b/.test(q)) { const c = activeCaregivers(pid); return A(c.length ? `Portal access granted by ${f}: ${c.map(x => `${x.name} (${x.relationship}) can see ${scopeText(x.scope)}`).join('; ')}. Every caregiver view is recorded.` : `No caregiver has portal access to ${f}'s record.`, [R('caregivers', 'Caregiver access', pid)], { type: 'panel', ref: R('caregivers', 'Caregiver access', pid) }); }
  if (/monitor|wearable|rpm|device|watch/.test(q)) return A('Remote monitoring (wearables) is coming later. The data model has a hook for device readings; nothing connects in this build.', [R('monitoring', 'Remote monitoring', pid)], { type: 'panel', ref: R('monitoring', 'Remote monitoring', pid) });
  if (/journal|timeline|everything|full (chart|record)|all entries/.test(q)) return A(`Opening ${f}'s full journal: every visit, note, result, medication change, message and ASC event, newest first, filterable by date, condition and type.`, [R('journal', 'Medical journal', pid)], { type: 'panel', ref: R('journal', 'Medical journal', pid) });
  if (/trend|graph|over time|plot/.test(q) && !/a1c|creatinine|hemoglobin|ldl/.test(q)) return A('Opening vitals and lab trends. Bands appear only where your practice configured an approved range; nothing is judged high or low by the app.', [R('trends', 'Trends', pid)], { type: 'panel', ref: R('trends', 'Trends', pid) });
  if (/audit|who (viewed|changed|opened)|access log/.test(q)) return A('Opening the audit trail for this chart and its visits.', [R('audit', 'Audit trail', pid)], { type: 'panel', ref: R('audit', 'Audit trail', pid) });
  if (/bill|invoice|charge|fee|pay/.test(q)) return A('Opening billing: the patient account (credit on account, Collect payment, apply credit) and each visit’s invoice. Invoices use the practice’s flat fee schedule and need a signed note and verified checkout.', [R('billing', 'Billing', pid)], { type: 'panel', ref: R('billing', 'Billing', pid) });
  if (/care ?plan|activities|instructions for (her|him)/.test(q)) { const cp = medRepo.carePlan(pid); return A(cp?.published ? `Signed care plan v${cp.published.version} (${cp.published.signedBy}, ${fmtDate(cp.published.signedAt)}): ${cp.published.items.map(i => i.title).join('; ')}. The portal shows this as ${her} Medications & Activities plan.` : 'No signed care plan is recorded.', [R('careplan', 'Care plan', pid)], { type: 'panel', ref: R('careplan', 'Care plan', pid) }); }
  if (/what changed|since (her|his|their|the) last|new since|anything new/.test(q)) {
    const last = medRepo.visits(pid).filter(v => v.step === 'complete' && v.date < isoDay()).slice(-1)[0]; const since = last?.date || addDays(isoDay(), -30);
    const labs = medRepo.labs(pid).filter(l => l.collectedAt > since); const meds = medRepo.meds(pid).filter(m => m.recordedAt.slice(0, 10) > since); const msgs = medRepo.messages(pid).filter(m => m.at.slice(0, 10) > since);
    const asc = ascCasesFor(pid).flatMap(c => networkRepo.thread(c.id).filter(m => m.at.slice(0, 10) > since).map(m => ({ c, m })));
    const parts = [labs.length ? `${labs.length} lab result${labs.length === 1 ? '' : 's'} (${labs.map(l => `${l.test} ${l.value}${l.unit ? ' ' + l.unit : ''}`).join(', ')}), ${labs.some(l => l.status === 'awaiting-review') ? 'awaiting your review' : 'reviewed'}` : '', meds.length ? `${meds.length} medication change${meds.length === 1 ? '' : 's'}` : '', msgs.length ? `${msgs.length} portal message${msgs.length === 1 ? '' : 's'} (latest from ${msgs[msgs.length - 1].author})` : '', asc.length ? `${asc.length} message${asc.length === 1 ? '' : 's'} from the ASC` : ''].filter(Boolean);
    const cites = [...new Set(labs.map(l => l.collectedAt))].map(d => slipRef(d, pid)); if (msgs.length) cites.push(R('messages', 'Portal messages', pid)); if (asc.length) cites.push(R('asc', 'ASC case thread', pid, asc[0].c.id)); if (meds.length) cites.push(R('meds', 'Medication list', pid));
    return A(parts.length ? `Since ${last ? `the last visit (${usDate(last.date)})` : usDate(since)}: ${parts.join('; ')}.` : `Nothing new is recorded since ${last ? `the last visit (${usDate(last.date)})` : usDate(since)}.`, cites);
  }
  if (/allerg/.test(q)) { const a = effectiveAllergy(p.allergies, patientKey(pid)); return A(a.state === 'not-reported' ? `Allergy status is not reported for ${f}. Ask and record allergies or NKDA.` : `Allergies: ${a.text}${a.pendingConfirm ? ` (patient-reported on ${a.sourceForm || 'intake'}, not yet confirmed)` : p.allergiesConfirmedAt ? ` (confirmed by ${p.allergiesConfirmedBy}, ${fmtDate(p.allergiesConfirmedAt)})` : ''}.`, [R('allergies', 'Allergy record', pid)]); }
  if (/risk|safe|concern|clear(ed|ance)? for|go.?no|ready for surgery/.test(q)) { const fl = riskFlags(p); const open = openRisks(p).length; return A(fl.length ? `${fl.length} recorded factor${fl.length === 1 ? '' : 's'} that may raise surgical risk (${open} not yet reviewed by the surgeon): ${fl.map(x => x.label).join('; ')}. This is awareness only: no score and no go/no-go. The surgeon decides.` : 'No risk factors are found in the recorded data. That is not a clearance; the surgeon decides.', [R('risk', 'Risk awareness', pid)], { type: 'panel', ref: R('risk', 'Risk awareness', pid) }); }
  if (/a1c|lab|result|creatinine|hemoglobin|ldl|inr|platelet|glucose|potassium/.test(q)) {
    const labs = medRepo.labs(pid); if (!labs.length) return A('No lab results are recorded in this chart.');
    const tests = [...new Set(labs.map(l => l.test))]; const want = tests.filter(t => q.includes(t.toLowerCase()) || q.includes(t.toLowerCase().split(' ').slice(-1)[0]));
    if (want.length === 1) { const s = labs.filter(l => l.test === want[0]); const last = s[s.length - 1]; const series = s.map(l => `${l.value} (${shortDate(l.collectedAt)})`).join(' → ');
      return A(`${want[0]}: ${series}${last.unit ? ` ${last.unit}` : ''}. Latest collected ${relDay(last.collectedAt)}, ${last.status === 'awaiting-review' ? 'awaiting clinician review' : last.status}${last.reportedRange ? `; lab-printed range ${last.reportedRange}` : ''}. I don’t interpret results; ranges are not configured by your practice.`, [...new Set(s.map(l => l.collectedAt))].reverse().map(d => slipRef(d, pid)), { type: 'panel', ref: slipRef(last.collectedAt, pid) }); }
    const slips = labSlips(pid); const latest = slips[0];
    return A(`Latest lab slip (${usDate(latest.date)}): ${latest.labs.map(l => `${l.test} ${l.value}${l.unit ? ' ' + l.unit : ''}`).join(', ')}${latest.labs.some(l => l.status === 'awaiting-review') ? ', awaiting your review' : ''}. ${slips.length} slips on file.`, slips.slice(0, 3).map(s => slipRef(s.date, pid)), { type: 'panel', ref: slipRef(latest.date, pid) });
  }
  if (/plavix|clopidogrel|ozempic|semaglutide|glp|eliquis|apixaban|aspirin|blood thinner|anticoag|antiplatelet/.test(q)) {
    const meds = medRepo.meds(pid).filter(m => m.status === 'active' && /clopidogrel|plavix|semaglutide|ozempic|apixaban|eliquis|aspirin|warfarin|rivaroxaban|tirzepatide|liraglutide/i.test(m.name));
    const m = lastFrom(pid);
    return A(meds.length ? `On the list: ${meds.map(x => `${x.name} ${x.dose} ${x.frequency}`).join('; ')}. Your practice has not configured a peri-operative medication policy, so I give no hold window; the surgeon (with cardiology where relevant) decides.${m && /plavix|ozempic|thinner/i.test(m.text) ? ` ${m.author} asked about this ${relDay(m.at)}.` : ''}` : 'No anticoagulant, antiplatelet or GLP-1 medication is on the active list.', [R('meds', 'Medication list', pid), ...(m ? [R('messages', 'Portal messages', pid)] : [])]);
  }
  if (/\bmeds?\b|medication|drug|rx|prescri/.test(q)) { const m = medRepo.meds(pid).filter(x => x.status === 'active'); return A(m.length ? `${m.length} active: ${m.map(x => `${x.name} ${x.dose} ${x.frequency}`).join('; ')}.` : 'No active medications are recorded.', [R('meds', 'Medication list', pid)], { type: 'panel', ref: R('meds', 'Medication list', pid) }); }
  if (/surgical history|prior surg|previous surg|operations|past surg/.test(q)) { const h = surgicalHistoryLines(p); return A(h.length ? `Surgical history: ${h.map(x => x.text + (x.detail ? ` — ${x.detail}` : '')).join('; ')}.` : 'No surgical history is recorded.', [R('history', 'Medical history form', pid)]); }
  if (/problem|condition|diagnos|diabet|heart|hypertens|apnea|history/.test(q)) { const pr = medRepo.problems(pid).filter(x => x.status === 'active'); return A(pr.length ? `Active problems: ${pr.map(x => `${x.description} (${conditionLabel(x.conditionType)}, since ${x.onset || fmtDate(x.recordedAt)})`).join('; ')}.` : 'No active problems are recorded.', [R('problems', 'Problem list', pid)], { type: 'panel', ref: R('conditions', 'Conditions', pid) }); }
  if (/vital|\bbp\b|blood pressure|weight|bmi|pulse|heart rate/.test(q)) { const v = medRepo.vitals(pid).slice(-1)[0]; return A(v ? `Latest vitals (${fmtDate(v.at)}, ${v.by}): ${vitalsText(v)}. BMI has no built-in threshold.` : 'No vitals are recorded.', [R('vitals', 'Vitals', pid)], { type: 'panel', ref: R('trends', 'Trends', pid) }); }
  if (/surgery|asc|procedure|booked|operat|harborview|block/.test(q)) { const c = ascCasesFor(pid); return A(c.length ? `ASC cases (simulated network link): ${c.map(x => `${x.procedure}, ${usDate(x.date)} ${x.time}, ${x.surgeon}, ${x.room} (${x.status})`).join('; ')}.` : 'No ASC case is linked to this chart.', c.length ? [R('asc', 'ASC case', pid, c[0].id)] : [], c.length ? { type: 'panel', ref: R('asc', 'ASC case', pid, c[0].id) } : undefined); }
  if (/note|last visit|plan from|assessment/.test(q)) { const v = medRepo.visits(pid).filter(x => medRepo.note(x.id)?.status === 'signed').slice(-1)[0]; if (!v) return A('No signed visit note is recorded.'); const n = medRepo.note(v.id)!; return A(`Last signed note (${usDate(v.date)}, ${n.signedBy}): ${n.assessment.replace(/\s+/g, ' ').slice(0, 220)} Plan: ${n.plan.replace(/\s+/g, ' ').slice(0, 220)}`, [noteRef(v)], { type: 'panel', ref: noteRef(v) }); }
  if (/intake|smok|anesthesia|hyperthermia|clot|pregnan|bleed/.test(q)) { const i = medRepo.intake(pid); return A(i.length ? `Intake answers: ${i.map(x => `${x.key.replace(/([A-Z])/g, ' $1').toLowerCase()}: ${x.value}${x.detail ? ` (${x.detail})` : ''}`).join('; ')}.` : 'No intake answers are recorded.', [R('intake', 'Intake answers', pid)]); }
  if (/what (should|do) i|next|to ?do|what now/.test(q)) { const n = chartNextSteps(p, repo.getActor().role); return A(n.length ? `Most likely next: ${n.map(x => x.label).join('; ')}.` : `Nothing is waiting in ${f}'s chart.`, []); }
  if (/summar|who is|tell me about|overview/.test(q)) { const v = todayVisit(pid); const nc = nextAscCase(pid); return A(`${p.name}, ${ageFrom(p.dob)}, ${p.sex.toLowerCase()}. ${v ? `Here today for a ${v.visitType.toLowerCase()} (${v.reason}). ` : ''}${nc ? `${nc.procedure} at ${nc.ascName.replace(/\s*\(.*\)/, '')} ${relDay(nc.date)}. ` : ''}${medRepo.problems(pid).filter(x => x.status === 'active').length} active problems; ${riskFlags(p).length} recorded risk factors.`, [R('summary', 'Living summary', pid)]); }
  return A(`I can only answer from what is recorded in ${f}'s chart, and I didn’t find that. Try: what changed since the last visit, latest A1c, blood thinners, surgical history, risk factors, care team, caregivers, the ASC case, the journal or trends.`);
}

export function globalAnswer(question: string): Answer {
  const q = question.toLowerCase().trim(); const A = (text: string, cites: Ref[] = [], act?: Act, pid?: string): Answer => ({ q: question, text, cites, act, at: now(), pid });
  const T = isoDay(); const today = medRepo.visits().filter(v => v.date === T);
  const pt = medRepo.patients().find(p => p.name.toLowerCase().split(/\s+/).some(w => w.length > 2 && new RegExp(`\\b${w}\\b`).test(q)));
  if (pt) {
    const v = todayVisit(pt.id);
    if (/check.?in|start|room|nurse|scribe/.test(q) && v) return A(`Opening ${pt.name}'s ${v.visitType.toLowerCase()} at ${STATION_LABEL[v.step === 'scheduled' ? 'check-in' : v.step]}.`, [], { type: 'station', visitId: v.id }, pt.id);
    const a = chartAnswer(pt.id, /open|chart|show|pull up/.test(q) && q.split(/\s+/).length <= 4 ? 'summary' : question);
    return { ...a, act: a.act && a.act.type === 'panel' ? { type: 'chart', pid: pt.id, ref: a.act.ref } : { type: 'chart', pid: pt.id } };
  }
  if (/who.?s next|next patient|who is next/.test(q)) { const v = today.filter(x => x.step === 'scheduled').sort((a, b) => toMin(a.time).localeCompare(toMin(b.time)))[0]; return v ? A(`Next to arrive: ${medRepo.patient(v.patientId)?.name}, ${v.time}, ${v.visitType.toLowerCase()} with ${v.provider} (${v.reason}).`, [], { type: 'station', visitId: v.id }, v.patientId) : A('Everyone on today’s schedule has arrived.'); }
  if (/lab|result/.test(q)) { const l = awaitingLabs(); return A(l.length ? `${l.length} result${l.length === 1 ? '' : 's'} awaiting clinician review: ${l.map(x => `${medRepo.patient(x.patientId)?.name} · ${x.test} ${x.value}${x.unit ? ' ' + x.unit : ''}`).join('; ')}. They reach the portal only after review.` : 'No results are waiting for review.', l.length ? [slipRef(l[0].collectedAt, l[0].patientId)] : [], l.length ? { type: 'chart', pid: l[0].patientId, ref: slipRef(l[0].collectedAt, l[0].patientId) } : undefined); }
  if (/message|inbox|portal/.test(q)) { const ms = medRepo.patients().map(p => ({ p, m: lastFrom(p.id) })).filter(x => x.m); return A(ms.length ? `${ms.length} waiting: ${ms.map(x => `${x.m!.author}: “${x.m!.text.slice(0, 70)}…”`).join(' ')}` : 'No portal messages are waiting.', [], { type: 'tab', tab: 'messages' }); }
  if (/surger|asc|or block|block time|operating/.test(q)) { const c = ascCases().filter(x => x.date >= T).sort((a, b) => a.date.localeCompare(b.date)).slice(0, 6); const b = ascBlocks().filter(x => x.date >= T).length; return A(c.length ? `Upcoming ASC surgeries: ${c.map(x => `${usDate(x.date)} ${x.time} ${x.patientName} · ${x.procedure} (${x.surgeon.replace(/,.*$/, '')})`).join('; ')}. ${b} block${b === 1 ? '' : 's'} of OR time ahead. All appear on the office schedule automatically (simulated network link).` : 'No upcoming ASC surgeries.', [], { type: 'tab', tab: 'schedule' }); }
  if (/unsigned|sign|notes? (to|not)/.test(q)) { const u = today.filter(v => v.step !== 'scheduled' && medRepo.note(v.id)?.status !== 'signed'); return A(u.length ? `Notes not signed today: ${u.map(v => medRepo.patient(v.patientId)?.name).join(', ')}.` : 'No unsigned notes from today.', [], u[0] ? { type: 'station', visitId: u[0].id } : undefined); }
  if (/schedule|calendar|book|appointment/.test(q)) return A(`${today.length} visits today. Opening the schedule (visit-type colors; ASC cases and block time appear automatically).`, [], { type: 'tab', tab: 'schedule' });
  const cmd = PRACTICE_COMMANDS.find(c => c.re.test(q)); if (cmd) return A(cmd.say, [], { type: 'tab', tab: cmd.tab });
  if (/practice|admin|settings/.test(q)) return A('Opening Practice. Ask me for a setting directly, e.g. “fee schedule”, “visit types”, “staff PINs”, “forms”.', [], { type: 'tab', tab: 'practice' });
  if (/patients|chart|find/.test(q)) return A('Opening the patient list. You can also ask me by name, e.g. “open Ellen”.', [], { type: 'tab', tab: 'patients' });
  if (/today|how many|who.?s (here|in)|status|brief/.test(q)) { const by = (s: string) => today.filter(v => v.step === s).length; return A(`${today.length} visits today: ${by('scheduled')} not arrived, ${by('check-in') + by('rooming')} at check-in or nurse intake, ${by('provider')} with the surgeon, ${by('checkout')} at checkout, ${by('complete')} complete. ${awaitingLabs().length} results await review.`, []); }
  return A('I answer from this practice’s recorded data. Try “who’s next”, “results to review”, “open Ellen”, “check in Marisol”, “upcoming surgeries” or “messages”.');
}
/** Surgery.Vityls practice settings as Nightingale commands (Practice page likely-next + the ask box). */
export const PRACTICE_COMMANDS: { re: RegExp; label: string; tab: Extract<Act, { type: 'tab' }>['tab']; say: string }[] = [
  { re: /colou?r|visit type|module|surgery settings|surgery center|facilit|reminder settings|reminder interval|payment types|referral sources|intake lists/, label: 'Visit types, intake lists & reminders', tab: 'surgery-settings', say: 'Opening visit types and colors, patient intake lists, appointment reminders, surgical modules and the surgery centers you send to.' },
  { re: /quote|estimate/, label: 'Price-quote terms & price list', tab: 'surgery-settings', say: 'Opening Price quotes: default validity, terms and disclaimer, letterhead and the quote price list (bottom of Visit types & intake).' },
  { re: /fee|price|charge|result|trigger|portal setting/, label: 'Surgery.Vityls settings', tab: 'med-settings', say: 'Opening Surgery.Vityls settings: the fee schedule, result release, risk triggers and portal settings.' },
  { re: /pin|staff|signing|signature|coordinator|invit|employee/, label: 'Staff & coordinators', tab: 'staff', say: 'Opening staff, surgical coordinators and invitations. Each person signs with their own PIN; nobody signs in and out all day.' },
  { re: /form editor|edit (a |the )?form|template|form builder|customi[sz]e (a |the )?form|form|workflow|station|intake form/, label: 'Forms & workflow', tab: 'forms', say: 'Opening Forms & workflow: My Forms, stations and signers. Use Edit form on any form to change it.' },
  { re: /provider|surgeon|credential|people/, label: 'Providers', tab: 'people', say: 'Opening providers and staff.' },
  { re: /profile|hours|room|address|location/, label: 'Practice profile & rooms', tab: 'profile', say: 'Opening the practice profile, hours and exam rooms.' },
  { re: /billing|invoice|payment|ledger|claim/, label: 'Billing & payments', tab: 'billing-hub', say: 'Opening billing and payments.' },
  { re: /operation|insight|performance|trend|report|utiliz/, label: 'Performance & reports', tab: 'ops-hub', say: 'Opening practice performance and reports.' },
  { re: /polic|manual|document/, label: 'Policies & manuals', tab: 'documents', say: 'Opening policies and manuals.' },
];
export const nurseDone = (visitId: string) => !!nurseAdmission(visitId);
export const openOrders = (visitId: string) => checkoutOrders(visitId).filter(o => o.status === 'to-do');
