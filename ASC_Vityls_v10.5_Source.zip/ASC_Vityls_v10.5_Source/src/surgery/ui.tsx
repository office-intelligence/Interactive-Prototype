/* Surgery.Vityls shared UI: app context, Nightingale header (same place on every page), citation chips, the right
   panel shell, and hold-to-initial. */
import React, { createContext, useContext, useEffect, useRef, useState } from 'react';
import { Mic, X } from 'lucide-react';
import { repo } from '../v6/dataLayer';
import { medRepo, patientKey, uid } from '../med/record';
import { useActor } from '../med/ui';
import { Act, Answer, Ref, Step, chartAnswer, globalAnswer } from './nightingale';
import { keepNote } from './store';
import nightingaleIcon from '../assets/nightingale-ai-icon.png';
import { Ico } from './icons';
import { XClose } from './asc82/common';

export type SvTab = 'intel' | 'chat' | 'home' | 'surgeries' | 'episode' | 'schedule' | 'patients' | 'messages' | 'practice' | 'forms' | 'med-settings' | 'surgery-settings' | 'station' | 'staff' | 'profile' | 'billing-hub' | 'billing-settings' | 'ops-hub' | 'people' | 'documents' | 'records-admin' | 'form-editor' | 'email' | 'modules' | 'portal-hub' | 'medical-director' | 'audit-pack' | 'v10-lists' | 'v10-connectors' | 'v10-onboard' | 'v10-audit' | 'v10-bank';
export interface SvCtx { tab: SvTab; patientId: string; panel: Ref | null; openPanel: (r: Ref) => void; closePanel: () => void; go: (a: Act) => void; toast: (m: string) => void; setTab: (t: SvTab) => void }
export const Ctx = createContext<SvCtx>(null as any);
export const useSv = () => useContext(Ctx);

export const Cite: React.FC<{ r: Ref; pid?: string }> = ({ r, pid }) => { const { openPanel } = useSv(); return <button type="button" className="sv-cite" onClick={() => openPanel({ ...r, pid: r.pid || pid })} aria-label={`Open source: ${r.label}`} data-testid="cite">{r.label}</button>; };
export const Cites: React.FC<{ list: Ref[]; pid?: string }> = ({ list, pid }) => <>{list.map((r, i) => <Cite key={`${r.kind}-${r.id || ''}-${i}`} r={r} pid={pid} />)}</>;

/** Press and hold (≈0.8 s) to initial. Keyboard: focus + Enter or I. Nightingale can never complete this. */
export const HoldToInitial: React.FC<{ label: React.ReactNode; onDone: () => void; done?: React.ReactNode; gone?: boolean; disabled?: string; testId?: string; onDismiss?: () => void }> = ({ label, onDone, done, gone, disabled, testId, onDismiss }) => {
  const [p, setP] = useState(0); const raf = useRef<number | null>(null); const t0 = useRef(0); const sx = useRef<number | null>(null);
  const stop = () => { if (raf.current) cancelAnimationFrame(raf.current); raf.current = null; setP(0); };
  const start = (e: React.PointerEvent) => { sx.current = e.clientX; if (done || gone || disabled) return; t0.current = performance.now(); const tick = () => { const k = Math.min(1, (performance.now() - t0.current) / 800); setP(k); if (k >= 1) { raf.current = null; setP(0); onDone(); return; } raf.current = requestAnimationFrame(tick); }; raf.current = requestAnimationFrame(tick); };
  useEffect(() => () => { if (raf.current) cancelAnimationFrame(raf.current); }, []);
  const cls = `sv-hold ${done ? 'done' : ''} ${gone ? 'gone' : ''}`;
  return <div role="button" tabIndex={0} className={cls} style={{ ['--p' as any]: p }} aria-disabled={!!disabled || undefined} title={disabled || undefined} data-testid={testId}
    onPointerDown={start} onPointerUp={e => { stop(); if (onDismiss && sx.current != null && sx.current - e.clientX > 80 && !done && !gone) onDismiss(); }} onPointerLeave={stop} onPointerCancel={stop}
    onKeyDown={e => { if (done || gone || disabled) return; if (e.key === 'Enter' || e.key.toLowerCase() === 'i') { e.preventDefault(); onDone(); } if (onDismiss && (e.key === 'Delete' || e.key.toLowerCase() === 'x')) { e.preventDefault(); onDismiss(); } }}>
    <span className="ring"><span>{done ? '✓' : ''}</span></span><span className="txt">{label}</span>
    <span className="how">{done || (gone ? 'dismissed' : disabled ? disabled : `hold to initial${onDismiss ? ' · swipe left to dismiss' : ''}`)}</span>
  </div>;
};
export const initialsOf = (n: string) => n.replace(/,.*$/, '').split(/\s+/).map(x => x[0]).join('').toUpperCase().slice(0, 3);
export const hhmm = (iso: string) => new Date(iso).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });

/** The Nightingale header. Context: a patient chart (answers from that chart) or the practice (today, schedule…). */
export const NightingaleBar: React.FC<{ patientId?: string; placeholder?: string; next: Step[]; brief?: React.ReactNode; context?: string }> = ({ patientId, placeholder, next, brief, context }) => {
  const { go, toast } = useSv(); const [actor] = useActor();
  const [q, setQ] = useState(''); const [log, setLog] = useState<Answer[]>([]); const [busy, setBusy] = useState(false); const [listening, setListening] = useState(false); const [showAll, setShowAll] = useState(false);
  const inp = useRef<HTMLInputElement>(null);
  useEffect(() => { setLog([]); setShowAll(false); }, [patientId]);
  useEffect(() => { const f = (e: KeyboardEvent) => { const t = e.target as HTMLElement; if (e.key === '/' && !/input|textarea|select/i.test(t.tagName) && !t.isContentEditable) { e.preventDefault(); inp.current?.focus(); } }; window.addEventListener('keydown', f); return () => window.removeEventListener('keydown', f); }, []);
  const ask = (text = q) => {
    if (!text.trim()) return; setBusy(true); setQ('');
    window.setTimeout(() => {
      const a = patientId ? chartAnswer(patientId, text) : globalAnswer(text);
      setLog(l => [...l, a].slice(-8)); setBusy(false);
      if (patientId) repo.audit({ caseId: patientKey(patientId), user: actor.name, role: actor.role, action: 'nightingale.answer', detail: `Q: ${text.slice(0, 80)}` });
      if (a.act) go(a.act);
    }, 260);
  };
  const micDown = () => { setListening(true); };
  const micUp = () => { if (!listening) return; setListening(false); const sample = patientId ? 'What changed since her last visit?' : 'Who’s next?'; setQ(sample); toast('Simulated voice: nothing was recorded. A sample question was typed for you.'); window.setTimeout(() => inp.current?.focus(), 30); };
  const last = log[log.length - 1];
  const keep = (a: Answer) => { if (!a.pid) return; keepNote({ id: uid('kn'), patientId: a.pid, question: a.q, text: a.text, cites: a.cites, keptBy: actor.name, keptAt: new Date().toISOString() }, actor.role); toast('Kept in the living summary (marked as a Nightingale note you kept).'); };
  const pname = patientId ? medRepo.patient(patientId)?.name.split(' ')[0] : '';
  return <section className="sv-n" aria-label="Nightingale AI" data-testid="nightingale-bar"><div className="sv-n-card nightingale-highlight-border">
    <div className="sv-n-head nightingale-ai-header" data-testid="nightingale-header">
      <span className={`sv-n-logo ${busy || listening ? 'busy' : ''}`}><img src={nightingaleIcon} alt="" /></span>
      <h2 className="sv-n-title">Nightingale AI</h2>
      <span className="sv-n-ctx">{context || (pname ? `${medRepo.patient(patientId!)?.name} · chart` : 'Practice')}</span>
      <span className="sv-n-meta">on-device · from recorded data · never signs or orders</span>
    </div>
    <div className="sv-n-body">
    <div className="sv-n-row">
      <form className="sv-pill" onSubmit={e => { e.preventDefault(); ask(); }} role="search">
        <label htmlFor="sv-ask" className="sr-only">Ask Nightingale</label>
        <input id="sv-ask" ref={inp} value={q} onChange={e => setQ(e.target.value)} placeholder={placeholder || (pname ? `Ask Nightingale about ${pname}, e.g. “latest A1c”, “blood thinners”, “care team”` : 'Ask Nightingale, e.g. “who’s next”, “results to review”, “open Ellen”')} autoComplete="off" data-testid="nightingale-input" onKeyDown={e => { if (e.key === 'Escape') { setQ(''); (e.target as HTMLInputElement).blur(); } }} />
        {listening ? <span className="sv-wave" aria-label="Listening (simulated)"><i style={{ animationDelay: '0s' }} /><i style={{ animationDelay: '.15s' }} /><i style={{ animationDelay: '.3s' }} /><i style={{ animationDelay: '.45s' }} /><i style={{ animationDelay: '.1s' }} /></span> : null}
        <button type="button" className={`sv-mic ${listening ? 'on' : ''}`} aria-label="Hold to speak (simulated)" title="Hold to speak (simulated; nothing is recorded)" onPointerDown={micDown} onPointerUp={micUp} onPointerLeave={() => listening && micUp()} onKeyDown={e => { if (e.key === ' ' || e.key === 'Enter') { e.preventDefault(); micDown(); window.setTimeout(micUp, 900); } }}><Mic size={15} /></button>
      </form>
    </div>
    {brief && !last && <div className="sv-n-next" style={{ display: 'block' }} data-testid="nightingale-brief">{brief}</div>}
    {last && <div className="sv-n-ans" aria-live="polite" data-testid="nightingale-answer">
      {showAll && log.slice(0, -1).map((a, i) => <div key={i} className="mb-2 opacity-80"><div className="q">You: {a.q}</div><div><span className="who">Nightingale</span>{a.text} <Cites list={a.cites} pid={a.pid} /></div></div>)}
      <div className="q">You: {last.q}</div>
      <div><span className="who">Nightingale</span>{last.text} <Cites list={last.cites} pid={last.pid} /></div>
      <div className="sv-n-tools">{last.pid && patientId && <button type="button" onClick={() => keep(last)} data-testid="keep-answer">Keep in living summary</button>}{log.length > 1 && <button type="button" onClick={() => setShowAll(s => !s)}>{showAll ? 'Hide earlier' : `Earlier (${log.length - 1})`}</button>}<button type="button" onClick={() => setLog([])}>Clear</button><span className="sv-muted">On-device, from recorded data only. Nightingale never signs, orders or scores risk.</span></div>
      <button type="button" onClick={() => setLog([])} aria-label="Close answer" className="absolute right-2 top-2 text-[var(--ink3)] hover:text-[var(--ink)]"><X size={15} /></button>
    </div>}
    {next.length > 0 && <nav className="sv-n-next" aria-label="Likely next" data-testid="likely-next"><b>Likely next</b>{next.map((s, i) => <button key={i} type="button" className={s.clinical ? 'clin' : ''} onClick={() => go(s.act)}>{s.label}</button>)}</nav>}
    </div></div>
  </section>;
};

/** Right panel shell. Docked at ≥1100 px, slide-over at tablet landscape, bottom sheet at tablet portrait. */
export const PanelShell: React.FC<{ title: string; sub?: React.ReactNode; wide?: boolean; icon?: string; onClose: () => void; children: React.ReactNode }> = ({ title, sub, wide, icon, onClose, children }) => {
  const ref = useRef<HTMLDivElement>(null); const y0 = useRef<number | null>(null);
  useEffect(() => { const f = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose(); }; window.addEventListener('keydown', f); ref.current?.focus(); return () => window.removeEventListener('keydown', f); }, [onClose]);
  useEffect(() => { const dock = () => document.body.classList.toggle('sv-panel-docked', window.innerWidth >= 1100 && !wide); dock(); window.addEventListener('resize', dock); return () => { window.removeEventListener('resize', dock); document.body.classList.remove('sv-panel-docked'); }; }, [wide]);
  return <>
    <div className="sv-scrim" onClick={onClose} aria-hidden="true" style={wide ? { display: 'block', inset: 'var(--top) 0 0 0', position: 'fixed', zIndex: 65, background: 'rgba(17,20,24,.22)' } : undefined} />
    <aside ref={ref} tabIndex={-1} className={`sv-panel ${wide ? 'wide' : ''}`} role="dialog" aria-label={title} data-testid="right-panel">
      <div className="sv-grab" onTouchStart={e => { y0.current = e.touches[0].clientY; }} onTouchEnd={e => { if (y0.current != null && e.changedTouches[0].clientY - y0.current > 60) onClose(); y0.current = null; }} />
      <div className="sv-panel-head"><div className="min-w-0"><b className="inline-flex items-center gap-1.5">{icon && <Ico k={icon} size={16} />}{title}</b>{sub && <div className="sv-sub">{sub}</div>}</div><XClose onClick={onClose} testId="panel-close" /></div>
      <div className="sv-panel-body">{children}</div>
    </aside>
  </>;
};
