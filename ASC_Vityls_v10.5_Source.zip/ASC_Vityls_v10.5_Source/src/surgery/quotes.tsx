import { StartEpisodeButton } from './episodes/EpisodeViews';
/*
 * Surgery.Vityls v0.8 — Price Quote / Estimate.
 *  - Built like an invoice (fee schedule + a practice price list by category), but NOT payable: no payment, no balance.
 *  - Open to any role; no PIN to create. The author (Acting as) is recorded on the quote and in the audit.
 *  - Every quote is kept and versioned: Revise adds a new version and keeps the prior ones. Statuses Draft / Presented /
 *    Accepted / Declined / Expired (Expired is automatic after valid-until for Draft / Presented quotes).
 *  - Optional "Convert to invoice" for an Accepted quote: creates a normal Draft invoice; the quote becomes read-only.
 * Fictional data only; stored in the Surgery browser namespace.
 */
import { isMedical } from '../edition';
import React, { useMemo, useState } from 'react';
import { FileText, Printer, Copy, PenLine, X, Plus, Trash2, Receipt } from 'lucide-react';
import { repo } from '../v6/dataLayer';
import { medRepo, MedPatient, patientKey, uid, usDate, isoDay, addDays } from '../med/record';
import { getSettings } from '../med/settings';
import { officeSurgeons } from '../med/network';
import { useActor, useMedTick } from '../med/ui';
import { saveInvoice, getInvoices, Invoice } from '../v7/billing';
import { svRead, svWrite } from './store';
import { useSv } from './ui';
import { R } from './nightingale';

export type QuoteStatus = 'Draft' | 'Presented' | 'Accepted' | 'Declined' | 'Expired';
const SURGERY_QUOTE_CATS = ['Procedure', 'Surgeon fee', 'Facility / ASC fee', 'Anesthesia', 'Implants & supplies', 'Labs', 'Garments', 'Follow-up visits', 'Discount', 'Custom'] as const;
/** Medical.Vityls: neutral self-pay categories ('Procedure' stays as the internal id of the plan line). */
const MEDICAL_QUOTE_CATS = ['Procedure', 'Office visits', 'Labs & tests', 'Vaccines', 'Office treatments', 'Supplies', 'Follow-up visits', 'Discount', 'Custom'] as const;
export type QuoteCat = typeof SURGERY_QUOTE_CATS[number] | typeof MEDICAL_QUOTE_CATS[number];
export const QUOTE_CATS: readonly QuoteCat[] = isMedical ? MEDICAL_QUOTE_CATS : SURGERY_QUOTE_CATS;
export interface QuoteLine { id: string; cat: QuoteCat; label: string; qty: number; unit: number; code?: string }
export interface QuoteVersion { v: number; createdAt: string; createdBy: string; createdRole: string; date: string; validUntil: string; procedure: string; surgeon: string; lines: QuoteLine[]; terms: string; financing: string; note: string; total: number }
export interface QuoteEvent { at: string; by: string; role: string; what: string }
export interface Quote { id: string; number: string; patientId: string; status: QuoteStatus; versions: QuoteVersion[]; events: QuoteEvent[]; invoiceId?: string; invoiceNumber?: string; duplicatedFrom?: string }
export interface CatalogItem { id: string; cat: QuoteCat; label: string; price: number }
export interface QuoteSettings { validDays: number; terms: string; financing: string; address: string; phone: string; catalog: CatalogItem[] }

const SURGERY_TERMS = [
  'This is a price quote / estimate, not a bill and not a guarantee of final fees.',
  'Fees may change if the surgical plan, anesthesia time, facility, implants or supplies change.',
  'Treatment of complications, revisions and additional procedures is not included unless listed above.',
  'Deposit, booking and cancellation terms follow the practice’s financial policy, provided separately.',
  'This estimate is valid until the date shown. After that date a new quote is required.',
].join('\n');
/** Medical.Vityls: neutral wording for self-pay services. */
const MEDICAL_TERMS = [
  'This is a price quote / estimate, not a bill and not a guarantee of final fees.',
  'Fees may change if the planned services, tests or supplies change.',
  'Services not listed above are not included.',
  'Payment and cancellation terms follow the practice’s financial policy, provided separately.',
  'This estimate is valid until the date shown. After that date a new quote is required.',
].join('\n');
export const DEFAULT_TERMS = isMedical ? MEDICAL_TERMS : SURGERY_TERMS;
const MEDICAL_CATALOG: CatalogItem[] = [
  { id: 'qc-visit', cat: 'Office visits', label: 'Office visit (self-pay)', price: 150 },
  { id: 'qc-annual', cat: 'Office visits', label: 'Annual physical (self-pay)', price: 220 },
  { id: 'qc-labs', cat: 'Labs & tests', label: 'Lab panel (CMP, CBC, lipids, A1c)', price: 180 },
  { id: 'qc-ecg', cat: 'Labs & tests', label: 'ECG with interpretation', price: 60 },
  { id: 'qc-vacc', cat: 'Vaccines', label: 'Vaccine (administration + vaccine)', price: 55 },
  { id: 'qc-treat', cat: 'Office treatments', label: 'Office treatment', price: 150 },
  { id: 'qc-sup', cat: 'Supplies', label: 'Supplies / home monitoring device', price: 45 },
  { id: 'qc-fu', cat: 'Follow-up visits', label: 'Follow-up visit (included)', price: 0 },
  { id: 'qc-disc', cat: 'Discount', label: 'Self-pay discount', price: -50 },
];
const SURGERY_CATALOG: CatalogItem[] = [
  { id: 'qc-surg', cat: 'Surgeon fee', label: 'Surgeon fee', price: 6500 },
  { id: 'qc-fac', cat: 'Facility / ASC fee', label: 'Facility fee (network ASC, est. 3 h)', price: 2400 },
  { id: 'qc-anes', cat: 'Anesthesia', label: 'Anesthesia (est. 3 h)', price: 1200 },
  { id: 'qc-impl', cat: 'Implants & supplies', label: 'Implants (pair)', price: 1800 },
  { id: 'qc-sup', cat: 'Implants & supplies', label: 'Surgical supplies', price: 250 },
  { id: 'qc-labs', cat: 'Labs', label: 'Pre-operative labs', price: 180 },
  { id: 'qc-garm', cat: 'Garments', label: 'Post-surgical garment', price: 95 },
  { id: 'qc-fu', cat: 'Follow-up visits', label: 'Post-op visits (90 days)', price: 0 },
  { id: 'qc-disc', cat: 'Discount', label: 'Combined-procedure discount', price: -500 },
];
const DEFAULT_CATALOG: CatalogItem[] = isMedical ? MEDICAL_CATALOG : SURGERY_CATALOG;
const DEF: QuoteSettings = { validDays: 90, terms: DEFAULT_TERMS, financing: 'Financing may be available through a third-party lender, subject to approval. Ask the front desk for details.', address: '1200 Shoreline Drive, Suite 300 · Bayview, CA 94000 (fictional)', phone: '(555) 010-4400', catalog: DEFAULT_CATALOG };
export const quoteSettings = (): QuoteSettings => ({ ...DEF, ...svRead<Partial<QuoteSettings>>('quote-settings', {}) });
export function saveQuoteSettings(s: QuoteSettings, by: string, role: string) { svWrite('quote-settings', s); repo.audit({ caseId: 'practice', user: by, role, action: 'settings.quotes', detail: `Price-quote settings saved · valid ${s.validDays} days · ${s.catalog.length} price-list item(s)` }); }

const all = () => svRead<Quote[]>('quotes', []);
const put = (l: Quote[]) => svWrite('quotes', l);
export const cur = (q: Quote) => q.versions[q.versions.length - 1];
export const quoteStatus = (q: Quote): QuoteStatus => (q.status === 'Draft' || q.status === 'Presented') && cur(q).validUntil < isoDay() ? 'Expired' : q.status;
export const quotesFor = (pid: string) => all().filter(q => q.patientId === pid).sort((a, b) => cur(b).createdAt.localeCompare(cur(a).createdAt));
export const quoteById = (id?: string) => all().find(q => q.id === id);
export const isLocked = (q: Quote) => !!q.invoiceId;
export const lineTotal = (l: QuoteLine) => Math.round(l.qty * l.unit * 100) / 100;
export const sumLines = (l: QuoteLine[]) => Math.round(l.reduce((s, x) => s + lineTotal(x), 0) * 100) / 100;
export const money = (n: number) => `${n < 0 ? '−' : ''}$${Math.abs(n).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
const nextNumber = () => { const y = new Date().getFullYear(); const n = all().filter(q => q.number.startsWith(`Q-${y}-`)).length + 1; return `Q-${y}-${String(n).padStart(4, '0')}`; };
type QAction = 'quote.create' | 'quote.edit' | 'quote.revise' | 'quote.status' | 'quote.print' | 'quote.convert';
const audit = (q: Quote, by: string, role: string, action: QAction, detail: string) => repo.audit({ caseId: patientKey(q.patientId), user: by, role, action, detail: `${q.number} v${cur(q).v} · ${detail}` });
const upsert = (q: Quote) => put([q, ...all().filter(x => x.id !== q.id)]);

export function createQuote(pid: string, v: Omit<QuoteVersion, 'v' | 'createdAt' | 'createdBy' | 'createdRole' | 'total'>, by: string, role: string, status: QuoteStatus = 'Draft', duplicatedFrom?: string): Quote {
  const now = new Date().toISOString();
  const q: Quote = { id: uid('q'), number: nextNumber(), patientId: pid, status, duplicatedFrom, versions: [{ ...v, v: 1, createdAt: now, createdBy: by, createdRole: role, total: sumLines(v.lines) }], events: [{ at: now, by, role, what: duplicatedFrom ? `Created (duplicate of ${duplicatedFrom})` : 'Created' }] };
  upsert(q); audit(q, by, role, 'quote.create', `Price quote created${duplicatedFrom ? ` from ${duplicatedFrom}` : ''} · ${status} · ${v.lines.length} line(s) · ${money(cur(q).total)} · not payable`); return q;
}
export function reviseQuote(q: Quote, v: Omit<QuoteVersion, 'v' | 'createdAt' | 'createdBy' | 'createdRole' | 'total'>, by: string, role: string, inPlace: boolean): Quote {
  if (isLocked(q)) throw new Error('This quote was converted to an invoice and is read-only.');
  const now = new Date().toISOString(); const prev = cur(q);
  const nv: QuoteVersion = { ...v, v: inPlace ? prev.v : prev.v + 1, createdAt: now, createdBy: by, createdRole: role, total: sumLines(v.lines) };
  const n: Quote = { ...q, status: inPlace ? q.status : 'Draft', versions: inPlace ? [...q.versions.slice(0, -1), nv] : [...q.versions, nv], events: [...q.events, { at: now, by, role, what: inPlace ? `Draft v${nv.v} edited` : `Revised to v${nv.v} (v${prev.v} kept)` }] };
  upsert(n); audit(n, by, role, inPlace ? 'quote.edit' : 'quote.revise', inPlace ? `Draft edited · ${money(nv.total)}` : `Revised from v${prev.v} (${money(prev.total)}) to v${nv.v} (${money(nv.total)}); prior version kept`); return n;
}
export function setQuoteStatus(q: Quote, s: QuoteStatus, by: string, role: string) {
  if (isLocked(q)) throw new Error('This quote was converted to an invoice and is read-only.');
  const n = { ...q, status: s, events: [...q.events, { at: new Date().toISOString(), by, role, what: `Marked ${s}` }] }; upsert(n); audit(n, by, role, 'quote.status', `Status ${quoteStatus(q)} → ${s}`); return n;
}
export function logQuotePrint(q: Quote, by: string, role: string) { const n = { ...q, events: [...q.events, { at: new Date().toISOString(), by, role, what: `Printed v${cur(q).v}` }] }; upsert(n); audit(n, by, role, 'quote.print', 'Printed / print preview'); }
export function convertQuote(q: Quote, by: string, role: string): Invoice {
  if (quoteStatus(q) !== 'Accepted') throw new Error('Only an Accepted quote can be converted.');
  if (q.invoiceId) throw new Error('Already converted.');
  const p = medRepo.patient(q.patientId); const v = cur(q); const now = new Date().toISOString();
  const inv: Invoice = { id: `inv-${Date.now()}`, number: `INV-${new Date().getFullYear()}-${String(getInvoices().length + 1).padStart(4, '0')}`, caseId: `quote:${q.id}`, patientName: p?.name || '', patientId: q.patientId, dos: usDate(v.date), procedure: v.procedure || 'Surgical package', surgeon: v.surgeon, paymentType: 'Self-Pay', scheduleId: 'surgery-price-quote', scheduleName: `From price quote ${q.number} v${v.v}`, facilityMin: 0, anesthesiaMin: 0, lines: v.lines.map(l => ({ label: `${l.cat} · ${l.label}`, detail: l.qty !== 1 ? `${l.qty} × ${money(l.unit)}` : (l.code || ''), amount: lineTotal(l) })), total: v.total, paid: 0, status: 'Draft', createdAt: now, createdBy: by };
  saveInvoice(inv);
  const n: Quote = { ...q, invoiceId: inv.id, invoiceNumber: inv.number, events: [...q.events, { at: now, by, role, what: `Converted to invoice ${inv.number}; quote is now read-only` }] }; upsert(n);
  audit(n, by, role, 'quote.convert', `Converted to Draft invoice ${inv.number} (${money(inv.total)}); quote locked read-only`); return inv;
}

/* ---------------- UI ---------------- */
export const QuoteStatusPill: React.FC<{ q: Quote }> = ({ q }) => { const s = quoteStatus(q); const c = s === 'Accepted' ? 'green' : s === 'Declined' || s === 'Expired' ? 'red' : s === 'Presented' ? 'blue' : 'gray';
  return <span className={`v7-pill ${c}`} data-testid="quote-status">{s}{q.invoiceId ? ' · invoiced' : ''}</span>; };

type Mode = { kind: 'new' } | { kind: 'edit' | 'revise' | 'duplicate'; q: Quote };
export const QuoteBuilder: React.FC<{ p: MedPatient; mode?: Mode; onClose: () => void; onSaved?: (q: Quote) => void }> = ({ p, mode = { kind: 'new' } as Mode, onClose, onSaved }) => {
  const [actor] = useActor(); const { toast, openPanel } = useSv(); const st = quoteSettings(); const fees = getSettings().fees.filter(f => f.active);
  const src = mode.kind === 'new' ? undefined : cur(mode.q);
  const surgeons = officeSurgeons();
  const [f, setF] = useState({ procedure: src?.procedure || '', surgeon: src?.surgeon || surgeons[0] || '', date: mode.kind === 'edit' ? src!.date : isoDay(), validUntil: mode.kind === 'edit' ? src!.validUntil : addDays(isoDay(), st.validDays), terms: src?.terms ?? st.terms, financing: src?.financing ?? '', note: src?.note || '' });
  const [lines, setLines] = useState<QuoteLine[]>(() => src ? src.lines.map(l => ({ ...l, id: uid('ql') })) : []);
  const [err, setErr] = useState(''); const [pick, setPick] = useState('');
  const total = sumLines(lines);
  const add = (l: Omit<QuoteLine, 'id'>) => setLines(x => [...x, { ...l, id: uid('ql') }]);
  const addPick = (v: string) => { if (!v) return; if (v === 'custom') add({ cat: 'Custom', label: '', qty: 1, unit: 0 }); else if (v.startsWith('fee:')) { const fe = fees.find(x => x.id === v.slice(4)); if (fe) add({ cat: isMedical ? 'Office visits' : 'Procedure', label: fe.name, qty: 1, unit: fe.price, code: fe.code }); } else { const c = st.catalog.find(x => x.id === v); if (c) add({ cat: c.cat, label: c.label, qty: 1, unit: c.price }); } setPick(''); };
  const upd = (id: string, patch: Partial<QuoteLine>) => setLines(x => x.map(l => l.id === id ? { ...l, ...patch } : l));
  const save = (status: QuoteStatus) => {
    if (!lines.length) { setErr('Add at least one line.'); return; }
    if (lines.some(l => !l.label.trim())) { setErr('Every line needs a description.'); return; }
    if (f.validUntil < f.date) { setErr('Valid-until must be on or after the quote date.'); return; }
    const body = { ...f, lines: lines.map(l => ({ ...l, label: l.label.trim(), unit: l.cat === 'Discount' ? -Math.abs(l.unit) : l.unit })) };
    let q: Quote;
    if (mode.kind === 'edit') { q = reviseQuote(mode.q, body, actor.name, actor.role, true); if (status !== q.status) q = setQuoteStatus(q, status, actor.name, actor.role); }
    else if (mode.kind === 'revise') { q = reviseQuote(mode.q, body, actor.name, actor.role, false); if (status !== 'Draft') q = setQuoteStatus(q, status, actor.name, actor.role); }
    else q = createQuote(p.id, body, actor.name, actor.role, status, mode.kind === 'duplicate' ? mode.q.number : undefined);
    toast(`${q.number} v${cur(q).v} saved · ${status} · ${money(cur(q).total)} (estimate, not payable)`); if (onSaved) onSaved(q); else openPanel(R('quote', q.number, p.id, q.id)); onClose();
  };
  const title = mode.kind === 'new' ? 'New price quote' : mode.kind === 'edit' ? `Edit ${mode.q.number} v${src!.v} (draft)` : mode.kind === 'revise' ? `Revise ${mode.q.number} → v${src!.v + 1}` : `Duplicate ${mode.q.number}`;
  return <div className="sv-modal" role="dialog" aria-modal="true" aria-label={title} data-testid="quote-builder"><div className="sv-modal-scrim" onClick={onClose} />
    <div className="sv-modal-box q-builder" style={{ width: 'min(880px, calc(100vw - 24px))', maxHeight: 'calc(100vh - 32px)', overflowY: 'auto' }}>
      <div className="flex items-center gap-2"><FileText size={16} /><b className="text-[16px]">{title} · {p.name}</b><span className="v7-pill gray">Price Quote / Estimate · not payable</span><button type="button" className="ml-auto" onClick={onClose} aria-label="Close"><X size={16} /></button></div>
      <p className="sv-small sv-muted mt-1 mb-3">Anyone can prepare a quote — no PIN. It’s saved under {actor.name} ({actor.role}) and recorded in the audit. A quote never posts a balance and can’t take a payment.</p>
      <div className="grid sm:grid-cols-4 gap-2">
        <label className="sm:col-span-2"><span className="sv-label">Procedure / plan</span><input className="sv-input" value={f.procedure} onChange={e => setF({ ...f, procedure: e.target.value })} placeholder="e.g. Breast augmentation, silicone, dual plane" data-testid="quote-procedure" /></label>
        <label className="sm:col-span-2"><span className="sv-label">Surgeon</span><select className="sv-input" value={f.surgeon} onChange={e => setF({ ...f, surgeon: e.target.value })} data-testid="quote-surgeon">{surgeons.map(s => <option key={s}>{s}</option>)}<option value="">—</option></select></label>
        <label><span className="sv-label">Quote date</span><input type="date" className="sv-input" value={f.date} onChange={e => setF({ ...f, date: e.target.value, validUntil: addDays(e.target.value, st.validDays) })} data-testid="quote-date" /></label>
        <label><span className="sv-label">Valid until</span><input type="date" className="sv-input" value={f.validUntil} onChange={e => setF({ ...f, validUntil: e.target.value })} data-testid="quote-valid" /></label>
        <div className="sm:col-span-2 sv-small sv-muted self-end pb-2">Default validity {st.validDays} days (Practice › Price quotes).</div>
      </div>
      <div className="flex items-center gap-2 mt-4 mb-1"><b className="text-[13px]">Lines</b>
        <select className="sv-input ml-auto" style={{ width: 'auto', minWidth: 260 }} value={pick} onChange={e => addPick(e.target.value)} data-testid="quote-add">
          <option value="">+ Add a line…</option>
          {QUOTE_CATS.filter(c => c !== 'Custom' && c !== 'Procedure').map(c => { const items = st.catalog.filter(x => x.cat === c); return items.length ? <optgroup key={c} label={c}>{items.map(x => <option key={x.id} value={x.id}>{x.label} · {money(x.price)}</option>)}</optgroup> : null; })}
          <optgroup label="Fee schedule">{fees.map(fe => <option key={fe.id} value={`fee:${fe.id}`}>{fe.name} · {money(fe.price)}</option>)}</optgroup>
          <option value="custom">Custom line…</option>
        </select></div>
      <table className="sv-table q-lines" data-testid="quote-lines"><thead><tr><th style={{ width: 170 }}>Category</th><th>Description</th><th style={{ width: 64 }}>Qty</th><th style={{ width: 110 }}>Unit</th><th style={{ width: 110, textAlign: 'right' }}>Amount</th><th style={{ width: 32 }} /></tr></thead>
        <tbody>{lines.length === 0 && <tr><td colSpan={6} className="sv-muted sv-small">No lines yet — add from the practice price list, the fee schedule, or a custom line.</td></tr>}
          {lines.map(l => <tr key={l.id} data-testid="quote-line">
            <td><select className="sv-input" value={l.cat} onChange={e => upd(l.id, { cat: e.target.value as QuoteCat })}>{QUOTE_CATS.map(c => <option key={c}>{c}</option>)}</select></td>
            <td><input className="sv-input" value={l.label} onChange={e => upd(l.id, { label: e.target.value })} placeholder="Description" data-testid="quote-line-label" /></td>
            <td><input className="sv-input" inputMode="decimal" value={l.qty} onChange={e => upd(l.id, { qty: Number(e.target.value) || 0 })} /></td>
            <td><input className="sv-input" inputMode="decimal" value={l.unit} onChange={e => upd(l.id, { unit: Number(e.target.value.replace(/[^0-9.\-]/g, '')) || 0 })} data-testid="quote-line-unit" /></td>
            <td style={{ textAlign: 'right' }} className="tabular-nums">{money(l.cat === 'Discount' ? -Math.abs(lineTotal(l)) : lineTotal(l))}</td>
            <td><button type="button" aria-label="Remove line" onClick={() => setLines(x => x.filter(y => y.id !== l.id))}><Trash2 size={14} /></button></td></tr>)}</tbody>
        <tfoot><tr><td colSpan={4} style={{ textAlign: 'right' }}><b>Estimated total</b></td><td style={{ textAlign: 'right' }} className="tabular-nums" data-testid="quote-total"><b>{money(sumLines(lines.map(l => l.cat === 'Discount' ? { ...l, unit: -Math.abs(l.unit) } : l)))}</b></td><td /></tr></tfoot></table>
      <details className="mt-3" data-testid="quote-terms-wrap"><summary className="text-[13px] font-semibold cursor-pointer">Terms &amp; disclaimer (from Practice defaults)</summary>
        <textarea className="sv-input mt-1" rows={5} value={f.terms} onChange={e => setF({ ...f, terms: e.target.value })} data-testid="quote-terms" />
        <label className="flex items-center gap-2 mt-2 text-[13px]"><input type="checkbox" checked={!!f.financing} onChange={e => setF({ ...f, financing: e.target.checked ? st.financing : '' })} data-testid="quote-financing" />Include the financing note</label>
        <label className="block mt-2"><span className="sv-label">Note to the patient (optional)</span><input className="sv-input" value={f.note} onChange={e => setF({ ...f, note: e.target.value })} /></label></details>
      {err && <p className="text-[13px] mt-2" style={{ color: 'var(--v7-red)' }} role="alert">{err}</p>}
      <div className="flex flex-wrap gap-2 mt-4 justify-end"><span className="sv-small sv-muted mr-auto self-center">{lines.length} line(s) · estimate only — nothing is billed</span>
        <button type="button" className="sv-btn" onClick={onClose}>Cancel</button>
        <button type="button" className="sv-btn" onClick={() => save('Draft')} data-testid="quote-save-draft">Save draft</button>
        <button type="button" className="sv-btn primary" onClick={() => save('Presented')} data-testid="quote-save-presented">Save &amp; mark presented</button></div>
    </div></div>;
};

const byCat = (lines: QuoteLine[]) => QUOTE_CATS.map(c => [c, lines.filter(l => l.cat === c)] as const).filter(([, l]) => l.length);
/** Word-like print sheet with practice letterhead. */
export const QuoteSheet: React.FC<{ q: Quote; v?: number }> = ({ q, v }) => {
  const ver = q.versions.find(x => x.v === v) || cur(q); const p = medRepo.patient(q.patientId); const s = getSettings(); const st = quoteSettings();
  return <article className="q-sheet" data-testid="quote-sheet">
    <header className="q-lh"><div><div className="q-lh-name">{s.practiceName.replace(/\s*\(fictional\)/, '')}</div><div className="q-lh-sub">{st.address}<br />{st.phone}</div></div>
      <div className="q-lh-right"><div className="q-kind">PRICE QUOTE / ESTIMATE</div><table><tbody><tr><td>Quote no.</td><td><b data-testid="quote-number">{q.number}</b>{q.versions.length > 1 ? ` · v${ver.v}` : ''}</td></tr><tr><td>Date</td><td>{usDate(ver.date)}</td></tr><tr><td>Valid until</td><td><b>{usDate(ver.validUntil)}</b></td></tr></tbody></table></div></header>
    <div className="q-to"><div><span>Prepared for</span><b>{p?.name}</b>{p?.dob ? <> · DOB {p.dob}</> : null}</div><div><span>Procedure / plan</span><b>{ver.procedure || '—'}</b></div><div><span>Surgeon</span><b>{ver.surgeon || '—'}</b></div></div>
    <table className="q-tbl"><thead><tr><th>Description</th><th className="r">Qty</th><th className="r">Unit</th><th className="r">Amount</th></tr></thead>
      <tbody>{byCat(ver.lines).map(([c, ls]) => <React.Fragment key={c}><tr className="q-cat"><td colSpan={4}>{c}</td></tr>{ls.map(l => <tr key={l.id}><td>{l.label}{l.code ? <span className="q-code"> · {l.code}</span> : null}</td><td className="r">{l.qty}</td><td className="r">{money(l.unit)}</td><td className="r">{money(lineTotal(l))}</td></tr>)}</React.Fragment>)}</tbody>
      <tfoot><tr><td colSpan={3} className="r">Estimated total</td><td className="r" data-testid="quote-sheet-total">{money(ver.total)}</td></tr></tfoot></table>
    <p className="q-notpay">This is an estimate only. It is not a bill, no balance is owed from this document, and it cannot be paid.</p>
    {ver.note && <p className="q-note">{ver.note}</p>}
    <section className="q-terms"><h4>Terms of this estimate</h4><ul>{ver.terms.split('\n').filter(Boolean).map((t, i) => <li key={i}>{t}</li>)}</ul>{ver.financing && <p><b>Financing.</b> {ver.financing}</p>}</section>
    <section className="q-sign"><p>I have received and reviewed this estimate. I understand it is not a guarantee of final fees.</p>
      <div className="q-sign-row"><div><span /><label>Patient signature</label></div><div><span /><label>Printed name</label></div><div className="d"><span /><label>Date</label></div></div></section>
    <footer className="q-foot">{q.number}{q.versions.length > 1 ? ` v${ver.v}` : ''} · prepared by {ver.createdBy} · {s.practiceName} · test build, fictional data</footer>
  </article>;
};

export const QuotePrint: React.FC<{ q: Quote; v?: number; onClose: () => void }> = ({ q, v, onClose }) => {
  const [actor] = useActor();
  return <div className="q-print-wrap" role="dialog" aria-modal="true" aria-label="Quote print preview" data-testid="quote-print">
    <div className="q-print-bar"><b>Print preview · {q.number}</b><span className="sv-small sv-muted">Letter · Word-style layout</span>
      <button type="button" className="sv-btn primary ml-auto" onClick={() => { logQuotePrint(q, actor.name, actor.role); window.print(); }} data-testid="quote-print-go"><Printer size={14} />Print</button>
      <button type="button" className="sv-btn" onClick={onClose} data-testid="quote-print-close">Close</button></div>
    <div className="q-print-scroll"><QuoteSheet q={q} v={v} /></div></div>;
};

/** The quote list (Documents, billing, right panel). */
export const QuoteList: React.FC<{ p: MedPatient; compact?: boolean }> = ({ p, compact }) => {
  useMedTick(); const { openPanel } = useSv(); const [b, setB] = useState<Mode | null>(null); const [pr, setPr] = useState<Quote | null>(null); const qs = quotesFor(p.id);
  return <section className="q-list" data-testid="quote-list">
    <div className="flex items-center gap-2 mb-2"><b className="text-[14px]">Price quotes</b><span className="sv-small sv-muted">{qs.length} · estimates, not payable</span>
      <button type="button" className="sv-btn sm ml-auto" onClick={() => setB({ kind: 'new' })} data-testid="quote-new"><Plus size={13} />New quote</button></div>
    {qs.length === 0 ? <p className="sv-small sv-muted">No quotes yet.</p> :
      <table className="sv-table"><thead><tr><th>Quote</th><th>Date</th>{!compact && <th>Procedure</th>}<th style={{ textAlign: 'right' }}>Estimate</th><th>Status</th><th /></tr></thead>
        <tbody>{qs.map(q => { const v = cur(q); return <tr key={q.id} data-testid="quote-row">
          <td><button type="button" className="sv-link" onClick={() => openPanel(R('quote', q.number, p.id, q.id))} data-testid="quote-view"><b>{q.number}</b></button> <span className="sv-small sv-muted">v{v.v}{q.versions.length > 1 ? ` of ${q.versions.length}` : ''}</span></td>
          <td>{usDate(v.date)}</td>{!compact && <td>{v.procedure || '—'}</td>}<td style={{ textAlign: 'right' }} className="tabular-nums">{money(v.total)}</td><td><QuoteStatusPill q={q} /></td>
          <td className="whitespace-nowrap"><button type="button" className="sv-btn sm" onClick={() => setPr(q)} data-testid="quote-print-btn" aria-label={`Print ${q.number}`}><Printer size={13} /></button>{' '}
            <button type="button" className="sv-btn sm" onClick={() => setB({ kind: 'duplicate', q })} data-testid="quote-dup" aria-label={`Duplicate ${q.number}`}><Copy size={13} /></button>{' '}
            {!isLocked(q) && <button type="button" className="sv-btn sm" onClick={() => setB({ kind: q.status === 'Draft' ? 'edit' : 'revise', q })} data-testid="quote-revise">{q.status === 'Draft' ? 'Edit' : 'Revise'}</button>}{!isMedical && quoteStatus(q) === 'Accepted' && <>{' '}<StartEpisodeButton p={p} quoteId={q.id} procedure={v.procedure} total={v.total} /></>}</td></tr>; })}</tbody></table>}
    {b && <QuoteBuilder p={p} mode={b} onClose={() => setB(null)} />}{pr && <QuotePrint q={pr} onClose={() => setPr(null)} />}
  </section>;
};

/** Right-panel view of one quote: sheet, versions, status, actions. */
export const QuotePanel: React.FC<{ p: MedPatient; id?: string }> = ({ p, id }) => {
  useMedTick(); const [actor] = useActor(); const { toast } = useSv(); const q = quoteById(id);
  const [v, setV] = useState<number | undefined>(undefined); const [b, setB] = useState<Mode | null>(null); const [pr, setPr] = useState(false); const [err, setErr] = useState('');
  if (!q) return <QuoteList p={p} compact />;
  const s = quoteStatus(q); const lock = isLocked(q); const shown = q.versions.find(x => x.v === v) || cur(q); const latest = shown.v === cur(q).v;
  const act = (f: () => void) => { try { setErr(''); f(); } catch (e: any) { setErr(e.message); } };
  return <div data-testid="quote-panel">
    <div className="flex flex-wrap items-center gap-2 mb-2"><QuoteStatusPill q={q} />{lock && <span className="v7-pill gray" data-testid="quote-locked">Read-only · {q.invoiceNumber}</span>}
      {q.versions.length > 1 && <select className="sv-input" style={{ width: 'auto' }} value={shown.v} onChange={e => setV(Number(e.target.value))} data-testid="quote-version">{q.versions.map(x => <option key={x.v} value={x.v}>v{x.v} · {usDate(x.createdAt.slice(0, 10))} · {money(x.total)}{x.v === cur(q).v ? ' (current)' : ''}</option>)}</select>}</div>
    <div className="flex flex-wrap gap-1.5 mb-3">
      <button type="button" className="sv-btn sm" onClick={() => setPr(true)} data-testid="quote-panel-print"><Printer size={13} />Print</button>
      <button type="button" className="sv-btn sm" onClick={() => setB({ kind: 'duplicate', q })} data-testid="quote-panel-dup"><Copy size={13} />Duplicate</button>
      {!lock && latest && <button type="button" className="sv-btn sm" onClick={() => setB({ kind: q.status === 'Draft' ? 'edit' : 'revise', q })} data-testid="quote-panel-revise"><PenLine size={13} />{q.status === 'Draft' ? 'Edit draft' : 'Revise'}</button>}
      {!lock && (['Presented', 'Accepted', 'Declined'] as QuoteStatus[]).filter(x => x !== s).map(x => <button key={x} type="button" className="sv-btn sm" onClick={() => act(() => { setQuoteStatus(q, x, actor.name, actor.role); toast(`${q.number} marked ${x}`); })} data-testid={`quote-mark-${x.toLowerCase()}`}>Mark {x.toLowerCase()}</button>)}
      {!lock && s === 'Accepted' && <button type="button" className="sv-btn sm primary" onClick={() => act(() => { const i = convertQuote(q, actor.name, actor.role); toast(`Invoice ${i.number} created as a Draft from ${q.number}`); })} data-testid="quote-convert"><Receipt size={13} />Convert to invoice</button>}
    </div>
    {err && <p className="text-[13px]" role="alert" style={{ color: 'var(--v7-red)' }}>{err}</p>}
    <div className="q-sheet-mini"><QuoteSheet q={q} v={shown.v} /></div>
    <h4 className="sv-h mt-4 mb-1">History</h4>
    <ol className="text-[12.5px] space-y-0.5" data-testid="quote-history">{[...q.events].reverse().map((e, i) => <li key={i}><span className="sv-muted">{new Date(e.at).toLocaleString('en-US', { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' })}</span> · {e.what} · {e.by.replace(/,.*$/, '')} ({e.role})</li>)}</ol>
    {b && <QuoteBuilder p={p} mode={b} onClose={() => setB(null)} />}{pr && <QuotePrint q={q} v={shown.v} onClose={() => setPr(false)} />}
  </div>;
};

export const NewQuoteButton: React.FC<{ p: MedPatient; className?: string; label?: string; testId?: string }> = ({ p, className = 'sv-btn', label = 'Price quote', testId = 'quote-open-builder' }) => {
  const [o, setO] = useState(false); const { openPanel } = useSv();
  return <><button type="button" className={className} onClick={() => setO(true)} data-testid={testId}><FileText size={14} />{label}</button>
    {o && <QuoteBuilder p={p} onClose={() => setO(false)} onSaved={q => openPanel(R('quote', q.number, p.id, q.id))} />}</>;
};

/** Practice › Price quotes. */
export const QuoteSettingsPage: React.FC = () => {
  const [actor] = useActor(); const { toast } = useSv(); const [s, setS] = useState<QuoteSettings>(quoteSettings);
  const upd = (i: number, patch: Partial<CatalogItem>) => setS({ ...s, catalog: s.catalog.map((c, j) => j === i ? { ...c, ...patch } : c) });
  return <div data-testid="quote-settings">
    <h2 className="sv-title" style={{ fontSize: 20 }}>Price quotes</h2>
    <p className="sv-small sv-muted mb-3">Defaults for every new quote. Existing quotes keep the terms they were written with.</p>
    <div className="grid sm:grid-cols-3 gap-2 mb-3">
      <label><span className="sv-label">Valid for (days)</span><input className="sv-input" inputMode="numeric" value={s.validDays} onChange={e => setS({ ...s, validDays: Math.max(1, Number(e.target.value) || 0) })} data-testid="qs-days" /></label>
      <label><span className="sv-label">Letterhead address</span><input className="sv-input" value={s.address} onChange={e => setS({ ...s, address: e.target.value })} /></label>
      <label><span className="sv-label">Letterhead phone</span><input className="sv-input" value={s.phone} onChange={e => setS({ ...s, phone: e.target.value })} /></label></div>
    <label className="block"><span className="sv-label">Default terms &amp; disclaimer (one per line)</span><textarea className="sv-input" rows={6} value={s.terms} onChange={e => setS({ ...s, terms: e.target.value })} data-testid="qs-terms" /></label>
    <label className="block mt-2"><span className="sv-label">Financing note (optional on each quote)</span><input className="sv-input" value={s.financing} onChange={e => setS({ ...s, financing: e.target.value })} /></label>
    <h3 className="sv-h mt-4 mb-1">Price list</h3>
    <table className="sv-table"><thead><tr><th>Category</th><th>Item</th><th style={{ width: 120 }}>Price</th><th /></tr></thead><tbody>{s.catalog.map((c, i) => <tr key={c.id}>
      <td><select className="sv-input" value={c.cat} onChange={e => upd(i, { cat: e.target.value as QuoteCat })}>{QUOTE_CATS.map(x => <option key={x}>{x}</option>)}</select></td>
      <td><input className="sv-input" value={c.label} onChange={e => upd(i, { label: e.target.value })} /></td>
      <td><input className="sv-input" inputMode="decimal" value={c.price} onChange={e => upd(i, { price: Number(e.target.value) || 0 })} /></td>
      <td><button type="button" aria-label="Remove" onClick={() => setS({ ...s, catalog: s.catalog.filter((_, j) => j !== i) })}><Trash2 size={14} /></button></td></tr>)}</tbody></table>
    <div className="flex gap-2 mt-3"><button type="button" className="sv-btn" onClick={() => setS({ ...s, catalog: [...s.catalog, { id: uid('qc'), cat: 'Custom', label: 'New item', price: 0 }] })}><Plus size={13} />Add item</button>
      <button type="button" className="sv-btn" onClick={() => setS({ ...s, terms: DEFAULT_TERMS })}>Restore default terms</button>
      <button type="button" className="sv-btn primary ml-auto" onClick={() => { saveQuoteSettings(s, actor.name, actor.role); toast('Price-quote settings saved'); }} data-testid="qs-save">Save</button></div>
  </div>;
};
