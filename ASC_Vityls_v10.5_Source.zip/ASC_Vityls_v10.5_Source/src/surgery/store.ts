import { modOn } from '../core/useCore';
/*
 * Surgery.Vityls v0.1 data that MED v0.1 does not have yet. Same pattern as src/med/record.ts: a small repository over
 * browser storage (Surgery namespace `vityls-surgery~`, see src/edition.ts). This is the swap point for Henry's API.
 *  - visit types and colors (practice-configurable, audited)
 *  - surgical modules (feature flags so a future Medical.Vityls can hide them)
 *  - nurse admission, ambient-scribe sessions (simulated), checkout orders, intake-link outbox (simulated, nothing sent)
 *  - surgical history, living-summary attestations and kept Nightingale notes
 *  - ASC block time + booking requests (simulated network link; ASC.Vityls itself is never written to)
 * Fictional data only.
 */
import { repo } from '../v6/dataLayer';
import { rawStorage, isMedical, isAscEd } from '../edition';
const EDITION_IS_ASC2 = isAscEd;
import { MEDICAL_VISIT_TYPES, MEDICAL_MODULES, MEDICAL_VT_MAP, MEDICAL_REASONS, MEDICAL_FEES, MEDICAL_PRACTICE } from './medical/data';
import { medRepo, patientKey, uid, isoDay, addDays, ping } from '../med/record';
import { networkRepo, NetworkCase, matchPatient, officeSurgeons } from '../med/network';
import { getSettings } from '../med/settings';

/* ---------------- visit types & colors ---------------- */
export type VisitCategory = 'new' | 'follow-up' | 'pre-op' | 'post-op' | 'clearance' | 'procedure' | 'other';
export interface VisitTypeDef { id: string; name: string; color: string; durationMin: number; category: VisitCategory; surgical: boolean; active: boolean }
export const CATEGORY_LABEL: Record<VisitCategory, string> = { new: 'New patient', 'follow-up': 'Follow-up', 'pre-op': 'Pre-surgical', 'post-op': 'Post-operative', clearance: 'Pre-op clearance', procedure: 'Office procedure', other: 'Other' };
const SURGERY_VISIT_TYPES: VisitTypeDef[] = [
  { id: 'vt-new', name: 'New patient consultation', color: '#93C5FD', durationMin: 30, category: 'new', surgical: false, active: true },
  { id: 'vt-fu', name: 'Follow-up visit', color: '#86EFAC', durationMin: 15, category: 'follow-up', surgical: false, active: true },
  { id: 'vt-presurg', name: 'Pre-surgical consult', color: '#FCD34D', durationMin: 45, category: 'pre-op', surgical: true, active: true },
  { id: 'vt-postop', name: 'Post-op follow-up', color: '#6EE7B7', durationMin: 15, category: 'post-op', surgical: true, active: true },
  { id: 'vt-clear', name: 'Pre-op clearance consult', color: '#C4B5FD', durationMin: 30, category: 'clearance', surgical: true, active: true },
  { id: 'vt-proc', name: 'Office procedure', color: '#F9A8D4', durationMin: 30, category: 'procedure', surgical: false, active: true },
];

/** ASC.Vityls v8.0: OR case types only (no telemedicine, no office consults). Colors follow the case color coding. */
const ASC2_VISIT_TYPES: VisitTypeDef[] = [
  { id: 'vt-case', name: 'Surgery case', color: '#CFE3F7', durationMin: 60, category: 'procedure', surgical: true, active: true },
  { id: 'vt-pat', name: 'Pre-admission testing', color: '#D3F0E1', durationMin: 30, category: 'pre-op', surgical: true, active: true },
  { id: 'vt-proc2', name: 'Procedure room case', color: '#E4DCF7', durationMin: 30, category: 'procedure', surgical: true, active: true },
];
export const DEFAULT_VISIT_TYPES: VisitTypeDef[] = isMedical ? MEDICAL_VISIT_TYPES : EDITION_IS_ASC2 ? ASC2_VISIT_TYPES : SURGERY_VISIT_TYPES;
/* ---------------- surgical modules (feature flags) ---------------- */
export interface SurgicalModules { riskAwareness: boolean; networkAsc: boolean; blockTime: boolean; surgeryBooking: boolean; preopClearance: boolean; ambientScribe: boolean }
export const MODULE_LABEL: Record<keyof SurgicalModules, { label: string; surgical: boolean; explain: string }> = {
  riskAwareness: { label: 'Surgical risk awareness', surgical: true, explain: 'Risk factors with sources in the living summary; the surgeon marks them reviewed.' },
  networkAsc: { label: 'Affiliated ASC (network link)', surgical: true, explain: 'ASC cases on the office schedule, the case thread and document sharing.' },
  blockTime: { label: 'ASC block time on the office schedule', surgical: true, explain: 'The surgeon’s OR block time at the affiliated ASC is shown on the office schedule.' },
  surgeryBooking: { label: 'Surgery booking at checkout', surgical: true, explain: 'Checkout can send a booking request to the affiliated ASC (simulated).' },
  preopClearance: { label: 'Pre-op clearance requests', surgical: true, explain: 'Checkout can request a pre-operative clearance consult (simulated letter).' },
  ambientScribe: { label: 'Ambient scribe for the provider encounter', surgical: false, explain: 'Simulated listening, live transcript and a Nightingale draft note for review. Real speech needs a BAA-covered service.' },
};
export const SURGERY_MODULES: SurgicalModules = { riskAwareness: true, networkAsc: true, blockTime: true, surgeryBooking: true, preopClearance: true, ambientScribe: true };
/** What a future Medical.Vityls preset would look like: surgical modules off, the rest unchanged. */
export const MEDICAL_PRESET: SurgicalModules = { riskAwareness: false, networkAsc: false, blockTime: false, surgeryBooking: false, preopClearance: false, ambientScribe: true };

export interface SurgerySettings { visitTypes: VisitTypeDef[]; modules: SurgicalModules }
const SK = 'vityls:surgery';
const read = <T,>(k: string, f: T): T => { try { const r = localStorage.getItem(`${SK}:${k}`); return r ? JSON.parse(r) : f; } catch { return f; } };
const write = (k: string, v: unknown) => { try { localStorage.setItem(`${SK}:${k}`, JSON.stringify(v)); } catch { throw new Error('Browser storage is full (test build).'); } ping(); };
export { read as svRead, write as svWrite };

/** core-modules: the affiliated-ASC features (network ASC layer, ASC block time) belong to asc-perioperative. */
const ascGate = (m: SurgicalModules): SurgicalModules => modOn('asc-perioperative') ? m : { ...m, networkAsc: false, blockTime: false };
export function surgerySettings(): SurgerySettings {
  const s = read<Partial<SurgerySettings>>('settings', {});
  return { visitTypes: s.visitTypes?.length ? s.visitTypes : DEFAULT_VISIT_TYPES, modules: isMedical ? MEDICAL_MODULES : EDITION_IS_ASC2 ? { ...SURGERY_MODULES, networkAsc: false, surgeryBooking: false, preopClearance: false, blockTime: false } : ascGate({ ...SURGERY_MODULES, ...(s.modules || {}) }) };
}
export function saveSurgerySettings(s: SurgerySettings, by: string, role: string, what: string, action: 'visittype.settings' | 'module.settings') {
  write('settings', s); repo.audit({ caseId: 'practice', user: by, role, action, detail: what });
}
export const modules = () => surgerySettings().modules;
export const visitTypes = () => surgerySettings().visitTypes;
/** Active visit types; surgical ones hide when surgery booking is switched off (Medical.Vityls preset). */
export const activeVisitTypes = () => visitTypes().filter(v => v.active && (!v.surgical || modules().surgeryBooking));
export function visitTypeDef(name: string): VisitTypeDef { return visitTypes().find(v => v.name === name) || { id: 'vt-unknown', name, color: '#F1F5F9', durationMin: 30, category: 'other', surgical: false, active: true }; }
/** Readable text on a light category color: always near-black (all defaults are pastel). */
export const inkOn = (hex: string) => { const m = hex.replace('#', ''); const n = parseInt(m.length === 3 ? m.split('').map(c => c + c).join('') : m, 16); const r = (n >> 16) & 255, g = (n >> 8) & 255, b = n & 255; return (0.299 * r + 0.587 * g + 0.114 * b) > 150 ? '#111827' : '#ffffff'; };
/** A slightly darker edge for a pastel fill (left stripe on cards and blocks). */
export const edgeOf = (hex: string) => { const m = hex.replace('#', ''); const n = parseInt(m, 16); const f = (c: number) => Math.max(0, Math.round(c * 0.72)); const r = f((n >> 16) & 255), g = f((n >> 8) & 255), b = f(n & 255); return `#${[r, g, b].map(x => x.toString(16).padStart(2, '0')).join('')}`; };

/* ---------------- nurse admission (short form) ---------------- */
export interface NurseAdmission { visitId: string; patientId: string; chiefComplaint: string; pain: string; vitalsId?: string; allergiesConfirmed: boolean; medsReviewed: boolean; anticoagulantLastDose: string; npo: string; escort: string; fallRisk: string; nurseNote: string; by: string; role: string; at: string }
export const nurseAdmission = (visitId: string) => read<Record<string, NurseAdmission>>('nurse', {})[visitId];
export function saveNurseAdmission(n: NurseAdmission) {
  const all = read<Record<string, NurseAdmission>>('nurse', {}); all[n.visitId] = n; write('nurse', all);
  repo.audit({ caseId: n.visitId, user: n.by, role: n.role, action: 'nurse.admission', detail: `Nurse admission saved · reason: ${n.chiefComplaint || '—'} · pain ${n.pain || '—'} · allergies ${n.allergiesConfirmed ? 'confirmed' : 'not confirmed'} · meds ${n.medsReviewed ? 'reviewed' : 'not reviewed'}` });
}

/* ---------------- ambient scribe (simulated) ---------------- */
export interface ScribeLine { at: string; speaker: 'Surgeon' | 'Patient' | 'Family' | 'Nurse'; text: string }
export interface ScribeSuggestion { id: string; kind: 'surgery-booking' | 'follow-up' | 'clearance' | 'other'; text: string; detail: string; status: 'pending' | 'initialed' | 'dismissed'; by?: string; at?: string }
export interface ScribeDraft { hpi: string; exam: string; assessment: string; plan: string }
export interface ScribeSession { visitId: string; status: 'idle' | 'listening' | 'paused' | 'stopped'; lines: ScribeLine[]; draft: ScribeDraft; suggestions: ScribeSuggestion[]; startedAt?: string; stoppedAt?: string; startedBy?: string; noteCreatedAt?: string }
export const scribeSession = (visitId: string): ScribeSession => read<Record<string, ScribeSession>>('scribe', {})[visitId] || { visitId, status: 'idle', lines: [], draft: { hpi: '', exam: '', assessment: '', plan: '' }, suggestions: [] };
export function saveScribe(s: ScribeSession) { const all = read<Record<string, ScribeSession>>('scribe', {}); all[s.visitId] = s; write('scribe', all); }

/* ---------------- checkout orders ---------------- */
export interface CheckoutOrder { id: string; visitId: string; patientId: string; kind: 'surgery-booking' | 'follow-up' | 'clearance' | 'other'; text: string; detail: string; status: 'to-do' | 'done' | 'cancelled'; source: string; createdBy: string; createdAt: string; doneBy?: string; doneAt?: string; result?: string }
export const checkoutOrders = (visitId?: string) => { const l = read<CheckoutOrder[]>('orders', []); return visitId ? l.filter(o => o.visitId === visitId) : l; };
export function saveOrder(o: CheckoutOrder, by: string, role: string, what: string) {
  const l = read<CheckoutOrder[]>('orders', []); const i = l.findIndex(x => x.id === o.id); if (i >= 0) l[i] = o; else l.push(o); write('orders', l);
  repo.audit({ caseId: o.visitId, user: by, role, action: 'checkout.order', detail: what });
}

/* ---------------- intake links (simulated outbox, nothing is sent) ---------------- */
export interface IntakeLink { id: string; patientId: string; visitId: string; forms: string[]; channel: 'email' | 'text'; to: string; link: string; createdAt: string; by: string; status: 'queued-simulated' }
export const intakeLinks = (visitId?: string) => { const l = read<IntakeLink[]>('intake-links', []); return visitId ? l.filter(x => x.visitId === visitId) : l; };
export function queueIntakeLink(x: Omit<IntakeLink, 'id' | 'createdAt' | 'status' | 'link'>, role: string): IntakeLink {
  const id = uid('il'); const link = `${location.origin === 'null' ? 'file://' : location.origin}${location.pathname}#intake=${id}`;
  const rec: IntakeLink = { ...x, id, link, createdAt: new Date().toISOString(), status: 'queued-simulated' };
  write('intake-links', [...read<IntakeLink[]>('intake-links', []), rec]);
  repo.audit({ caseId: x.visitId, user: x.by, role, action: 'intake.link', detail: `Intake forms link queued by ${x.channel} to ${x.to || '(no address)'} · ${x.forms.length} form(s) · SIMULATED, nothing sent` });
  return rec;
}

/* ---------------- surgical history ---------------- */
export interface SurgicalHistoryItem { id: string; patientId: string; text: string; year?: string; detail?: string; source: string; recordedAt: string }
export const surgicalHistory = (pid: string) => read<SurgicalHistoryItem[]>('surgical-history', []).filter(x => x.patientId === pid);
export function addSurgicalHistory(x: SurgicalHistoryItem) { write('surgical-history', [...read<SurgicalHistoryItem[]>('surgical-history', []), x]); }

/* ---------------- living summary: attestations + kept Nightingale notes ---------------- */
export interface SummaryInitial { patientId: string; by: string; role: string; at: string; fingerprint: string }
export const summaryInitials = (pid: string) => read<SummaryInitial[]>('summary-initials', []).filter(x => x.patientId === pid);
export function initialSummary(x: SummaryInitial) { write('summary-initials', [...read<SummaryInitial[]>('summary-initials', []), x]); repo.audit({ caseId: patientKey(x.patientId), user: x.by, role: x.role, action: 'summary.initial', detail: `Living summary initialed (fingerprint ${x.fingerprint}). Nightingale cannot sign.` }); }
export interface KeptNote { id: string; patientId: string; question: string; text: string; cites: { kind: string; id?: string; label: string }[]; keptBy: string; keptAt: string }
export const keptNotes = (pid: string) => read<KeptNote[]>('kept-notes', []).filter(x => x.patientId === pid);
export function keepNote(x: KeptNote, role: string) { write('kept-notes', [...read<KeptNote[]>('kept-notes', []), x]); repo.audit({ caseId: patientKey(x.patientId), user: x.keptBy, role, action: 'summary.initial', detail: `Kept a Nightingale answer in the living summary: "${x.question.slice(0, 80)}"` }); }
export function removeKeptNote(id: string) { write('kept-notes', read<KeptNote[]>('kept-notes', []).filter(x => x.id !== id)); }

/* ---------------- ASC: block time + booking requests (simulated network link) ---------------- */
export interface AscBlock { id: string; source: 'asc-store' | 'fictional-seed'; surgeon: string; date: string; start: string; end: string; room: string; ascName: string }
function ascStoreBlocks(): AscBlock[] {
  // ASC.Vityls keeps block time only in screen state today. If a future ASC build stores blocks under this key, they show here.
  try { const raw = JSON.parse(rawStorage.getItem('vityls:evaluation:block-time') || '[]'); const mine = new Set(officeSurgeons().map(s => s.toLowerCase())); return (Array.isArray(raw) ? raw : []).filter((b: any) => b && mine.has(String(b.surgeon || '').toLowerCase().replace(/,.*$/, '').replace(/^dr\.?\s+/, ''))).map((b: any) => ({ id: `asc-block:${b.id}`, source: 'asc-store', surgeon: b.surgeon, date: b.date, start: b.start, end: b.end, room: b.room || '', ascName: 'Network ASC (ASC.Vityls data in this browser)' })); } catch { return []; }
}
export function ascBlocks(): AscBlock[] {
  const asc = ascStoreBlocks(); if (asc.length) return asc;
  const ascName = getSettings().ascName; return read<AscBlock[]>('block-seed', []).map(b => ({ ...b, ascName }));
}
export interface BookingRequest extends NetworkCase { requestedBy: string; requestedAt: string; visitId: string; patientId: string }
export const bookingRequests = () => read<BookingRequest[]>('booking-requests', []);
export function requestBooking(b: Omit<BookingRequest, 'id' | 'source' | 'ascName' | 'status' | 'requestedAt'> & { ascName?: string }, role: string): BookingRequest {
  const rec: BookingRequest = { ...b, id: uid('book'), source: 'fictional-seed', ascName: b.ascName || getSettings().ascName, status: 'Booking requested (simulated)', requestedAt: new Date().toISOString() };
  write('booking-requests', [...bookingRequests(), rec]);
  repo.audit({ caseId: patientKey(b.patientId), user: b.requestedBy, role, action: 'network.booking', detail: `Booking request to ${rec.ascName}: ${b.procedure} on ${b.date} ${b.time} with ${b.surgeon} · SIMULATED, nothing sent` });
  return rec;
}
export function updateBooking(id: string, patch: Partial<BookingRequest>) { write('booking-requests', bookingRequests().map(b => b.id === id ? { ...b, ...patch } : b)); }
/** All ASC cases for this office: network cases (ASC store or seed) + this office's booking requests. */
export const ascCases = (): NetworkCase[] => [...networkRepo.cases(), ...bookingRequests()];
export const ascCasesFor = (pid: string) => { const p = medRepo.patient(pid); return p ? ascCases().filter(c => matchPatient(c, [p])) : []; };

/* ---------------- seed (runs once after the MED seed, Surgery namespace only) ---------------- */
const VT_MAP: Record<string, string> = { 'visit-e': 'Pre-surgical consult', 'visit-m': 'New patient consultation', 'visit-r': 'Post-op follow-up', 'visit-p': 'Office procedure', 'visit-g': 'Follow-up visit', 'visit-t': 'New patient consultation', 'visit-e-next': 'Post-op follow-up', 'visit-e-old': 'New patient consultation', 'visit-r-old': 'Pre-surgical consult' };
export function seedSurgeryExtras() {
  const T = isoDay(); const at = (d: string, hh = '10:00') => new Date(`${d}T${hh}:00`).toISOString();
  const vtMap = isMedical ? MEDICAL_VT_MAP : VT_MAP;
  medRepo.visits().forEach(v => { const vt = vtMap[v.id]; const reason = isMedical ? MEDICAL_REASONS[v.id] : undefined; if (vt) medRepo.saveVisit({ ...v, visitType: vt, durationMin: visitTypeDef(vt).durationMin, ...(reason ? { reason } : {}), ...(isMedical && v.room === 'Procedure room' ? { room: 'Treatment room' } : {}) }); });
  // Surgery fee schedule (placeholder prices, managers edit them): one line per default visit type.
  try {
    const s = getSettings(); const fees = [
      { id: 'fee-new', name: 'New patient consultation', visitType: 'New patient consultation', price: 150, code: '', active: true },
      { id: 'fee-fu', name: 'Follow-up visit', visitType: 'Follow-up visit', price: 100, code: '', active: true },
      { id: 'fee-presurg', name: 'Pre-surgical consult', visitType: 'Pre-surgical consult', price: 200, code: '', active: true },
      { id: 'fee-postop', name: 'Post-op follow-up (global period)', visitType: 'Post-op follow-up', price: 0, code: '', active: true },
      { id: 'fee-clear', name: 'Pre-op clearance consult', visitType: 'Pre-op clearance consult', price: 150, code: '', active: true },
      { id: 'fee-proc', name: 'Office procedure', visitType: 'Office procedure', price: 250, code: '', active: true },
      { id: 'fee-labdraw', name: 'Lab draw (venipuncture)', price: 25, code: '36415', active: true },
      { id: 'fee-nurse', name: 'Nurse visit (no physician)', price: 45, code: '99211', active: true },
      { id: 'fee-dressing', name: 'Dressing change / wound check', price: 40, code: '', active: true },
      { id: 'fee-suture', name: 'Suture removal', price: 60, code: '', active: true },
      { id: 'fee-inject', name: 'Injection (administration)', price: 35, code: '96372', active: true },
      { id: 'fee-garment', name: 'Compression garment (supply)', price: 85, code: '', active: true },
      { id: 'fee-product', name: 'Product / supply (enter amount)', price: 0, code: '', active: true },
    ];
    localStorage.setItem('vityls:med:settings', JSON.stringify(isMedical ? { ...s, fees: MEDICAL_FEES, practiceName: MEDICAL_PRACTICE, ascName: '' } : { ...s, fees }));
  } catch { /* */ }
  const sh = (id: string, pid: string, text: string, year: string, detail = '') => ({ id, patientId: pid, text, year, detail, source: 'Medical History (patient portal), reviewed at prior visit', recordedAt: at(addDays(T, -30)) });
  write('surgical-history', [
    sh('sh-e1', 'MED-1001', 'Coronary stent', '2019', 'Clopidogrel since the stent'), sh('sh-e2', 'MED-1001', 'Laparoscopic cholecystectomy', '2015', 'Nausea and vomiting after anesthesia (patient-reported)'), sh('sh-e3', 'MED-1001', 'Cataract surgery, right eye', '2021'), sh('sh-e4', 'MED-1001', 'Lower-lid skin excision, both eyes (office procedure)', 'last year', 'Before/after photos on file (fictional example)'),
    sh('sh-m1', 'MED-1003', 'Cesarean section ×2', '2010, 2013'), sh('sh-r1', 'MED-1004', 'Facelift / necklift', 'this month', 'Harborview Surgery Center (fictional network ASC)'), sh('sh-g1', 'MED-1006', 'Tonsillectomy', '1980'),
  ]);
  const PATEL = 'Sam Patel, MD', WHIT = 'Dana Whitfield, MD';
  const blk = (id: string, d: number, surgeon: string, start: string, end: string, room: string): AscBlock => ({ id, source: 'fictional-seed', surgeon, date: addDays(T, d), start, end, room, ascName: '' });
  write('block-seed', [blk('blk-1', 0, PATEL, '01:30 PM', '05:00 PM', 'OR 2'), blk('blk-2', 12, PATEL, '07:00 AM', '12:00 PM', 'OR 2'), blk('blk-3', 5, PATEL, '10:30 AM', '03:00 PM', 'OR 3'), blk('blk-4', 21, WHIT, '08:00 AM', '02:00 PM', 'OR 1'), blk('blk-5', -8, WHIT, '07:30 AM', '01:00 PM', 'OR 1'), blk('blk-6', 1, WHIT, '07:30 AM', '11:30 AM', 'OR 1')]);
  if (isMedical) write('block-seed', []);
  write('settings', { visitTypes: DEFAULT_VISIT_TYPES, modules: isMedical ? MEDICAL_MODULES : SURGERY_MODULES });
  // v0.3: optional surgical coordinator per patient (Riley Shaw / Jordan Blake are seeded in staff.ts); Grace, Priya, Tomas left blank on purpose.
  write('coordinators', { 'MED-1001': 'st-sc1', 'MED-1004': 'st-sc1', 'MED-1003': 'st-sc2' });
  seedHooks.forEach(f => { try { f(); } catch (e) { console.warn('Surgery seed hook failed', e); } });
}
/** v0.3: other Surgery modules (photos, body charts) add their fictional seed here without an import cycle. */
export const seedHooks: (() => void)[] = [];
export const SURGERY_SEED_VERSION = 'surgery-v0.5'; // v0.5: upcoming visits with reminder history (resets test data once)
