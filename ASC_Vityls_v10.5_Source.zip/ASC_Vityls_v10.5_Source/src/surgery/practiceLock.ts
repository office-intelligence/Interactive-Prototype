/*
 * Surgery.Vityls v0.4 · Practice access PIN.
 * The tablet session can be anyone (front desk, MA, nurse). Stations are open to everyone; the Practice area
 * (staff, settings, fees, forms, reports) is sensitive, so opening it asks for the PIN of a person who may manage the
 * practice: Practice Manager, Practice Administrator or a provider (surgeon / physician / NP / PA).
 * Unlock lasts while you stay in Practice. It re-locks when you leave Practice, after 5 minutes without activity,
 * on "Lock Practice", or on reload. Henry: server-side this is a short-lived elevated token (step-up auth), not a flag.
 */
import { repo } from '../v6/dataLayer';
import { PROVIDER_ROLES } from '../med/record';
import { isAscEd } from '../edition';

export const PRACTICE_ROLES = ['Practice Manager', 'Practice Administrator', ...PROVIDER_ROLES];
export const PRACTICE_IDLE_MS = 5 * 60 * 1000;
export interface PracticeUnlock { name: string; role: string; at: number; last: number }
let state: PracticeUnlock | null = null;
const emit = () => window.dispatchEvent(new Event('vityls-med-updated'));

export function practiceUnlocked(): boolean {
  if (isAscEd) return true; /* v8.2: the Practice Settings PIN is switched off in ASC.Vityls for now (signing still needs a PIN). */
  if (!state) return false;
  if (Date.now() - state.last > PRACTICE_IDLE_MS) { lockPractice('timeout (5 minutes without activity)'); return false; }
  return true;
}
/** Who unlocked Practice (edits in Practice are attributed to this person). */
export const practiceEditor = (): PracticeUnlock | null => (practiceUnlocked() ? state : null);
export function unlockPractice(w: { name: string; role: string }, session: string) {
  state = { name: w.name, role: w.role, at: Date.now(), last: Date.now() };
  repo.audit({ caseId: 'practice', user: w.name, role: w.role, action: 'practice.unlock', detail: `Practice opened with ${w.name}’s own PIN (tablet session: ${session})` });
  emit();
}
export function lockPractice(reason: string) {
  if (!state) return; const s = state; state = null;
  repo.audit({ caseId: 'practice', user: s.name, role: s.role, action: 'practice.lock', detail: `Practice locked · ${reason}` });
  emit();
}
export function touchPractice() { if (state) state.last = Date.now(); }
/** Test hook: shorten/expire the unlock (used by the headless smoke). */
export function expirePracticeForTest() { if (state) state.last = 0; }
/** Inside Practice: the person who unlocked it (their name/role go on every change), else the tablet session. */
export function practiceActor<T extends { name: string; role: string }>(session: T): T { const e = practiceEditor(); return e ? { ...session, name: e.name, role: e.role } : session; }
