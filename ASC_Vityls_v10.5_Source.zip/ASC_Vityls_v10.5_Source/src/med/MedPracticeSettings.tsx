/*
 * Practice > MED settings. Nothing ships with a clinical number: risk triggers and result bands start empty and
 * disabled and need a named medical-director approval. Managers/administrators change settings; all audited.
 */
import React, { useState } from 'react';
import { isMedical } from '../edition';
import { ArrowLeft } from 'lucide-react';
import { Btn, PageHeader } from '../v7/ui';
import { isManagerRole } from '../v7/roles';
import { EditionCard } from '../v7/EditionCard';
import { practiceActor, practiceUnlocked } from '../surgery/practiceLock';
import { isSurgery, EDITION_LABEL, isAscEd } from '../edition';
import { getSettings, saveSettings, MedSettings, NumericTrigger, ResultBand } from './settings';
import { MedFeeScheduleEditor } from './MedBilling';
import { Card, Chip, useActor, useMedTick } from './ui';

export const MedPracticeSettings: React.FC<{ onBack: () => void; onToast: (m: string) => void }> = ({ onBack, onToast }) => {
  useMedTick(); const [session] = useActor(); const actor = isSurgery ? practiceActor(session) : session; const [s, setS] = useState<MedSettings>(getSettings()); const can = isSurgery ? practiceUnlocked() || isManagerRole(session.role) : isManagerRole(actor.role);
  const [err, setErr] = useState('');
  const save = (what: string, action: 'risk.settings' | 'lab.settings' | 'fee.schedule' = 'lab.settings', next = s) => { if (!can) { setErr('Only a practice manager or administrator can change these settings.'); return; } saveSettings(next, actor.name, actor.role, what, action); setErr(''); onToast('Saved.'); };
  const setT = (i: number, x: Partial<NumericTrigger>) => setS({ ...s, triggers: s.triggers.map((t, j) => j === i ? { ...t, ...x } : t) });
  const saveTriggers = () => { const bad = s.triggers.find(t => t.enabled && (t.value == null || !t.approvedBy.trim() || !t.approvedOn)); if (bad) { setErr(`${bad.label}: an enabled trigger needs a value, the approving medical director’s name and the approval date.`); return; } save(`Risk triggers: ${s.triggers.map(t => `${t.label} ${t.enabled ? `${t.operator} ${t.value} (approved ${t.approvedBy} ${t.approvedOn})` : 'off'}`).join('; ')}`, 'risk.settings'); };
  const setB = (i: number, x: Partial<ResultBand>) => setS({ ...s, bands: s.bands.map((b, j) => j === i ? { ...b, ...x } : b) });
  const saveBands = () => { const bad = s.bands.find(b => (b.low != null || b.high != null) && (!b.approvedBy.trim() || !b.approvedOn)); if (bad) { setErr(`${bad.test}: a range needs the approving medical director’s name and date.`); return; } save(`Result bands: ${s.bands.map(b => `${b.test} ${b.low ?? '—'}–${b.high ?? '—'} (${b.approvedBy})`).join('; ') || 'none'}`); };
  const num = (v: string) => v.trim() === '' ? null : +v;
  // Surgery.Vityls v0.3 (Kevin 10/10): same white sheet as the other Surgery pages, titled Surgery.Vityls settings, and no
  // edition selector (an administrator must not switch products; the edition comes with the subscription).
  return <div className={isSurgery ? 'sv-page sv-legacy-settings space-y-4' : 'max-w-5xl mx-auto space-y-4'} data-testid="med-settings">
    {isSurgery ? <div><button type="button" className="sv-link text-[13px]" onClick={onBack}>‹ Practice</button><h1 className="sv-title mt-1" data-testid="settings-title">{isAscEd ? 'Surgery settings' : 'Surgery.Vityls settings'}</h1><div className="sv-sub">{isAscEd ? 'Surgical risk triggers, results release and portal ranges' : 'Fee schedule, surgical risk triggers, results release and ranges, lab descriptions, portal'}</div></div>
      : <PageHeader kicker="Practice" title="MED settings" sub="Fee schedule, surgical risk triggers, results release and ranges, portal" right={<Btn icon={<ArrowLeft />} onClick={onBack}>Back</Btn>} />}
    {!can && <p className="rounded-md bg-[#f3f4f2] border border-[#d3d8d4] px-3 py-2 text-[14px]">You are acting as {actor.role}. Switch “Acting as” to Practice Manager or Practice Administrator to change settings.</p>}
    {err && <p className="vy-field-error" role="alert">{err}</p>}
    {isMedical ? <Card kicker="Your product" title={<>This practice uses <b>{EDITION_LABEL.MEDICAL}</b></>} testId="edition-readonly"><p className="text-[14px] text-[#39443E]">Medical.Vityls is for an internal medicine or family practice: longitudinal primary and chronic care, a Nightingale-led chart, station workflow from intake to checkout, diagnoses and care plans, body charts and clinical photos. Other Vityls editions are separate products. The product is set by your subscription; it can’t be switched here.</p></Card> : isSurgery && !isAscEd ? <Card kicker="Your product" title={<>This practice uses <b>{EDITION_LABEL.SURGERY}</b></>} testId="edition-readonly"><p className="text-[14px] text-[#39443E]">Surgery.Vityls is for a surgeon’s office: episodic surgical care, a Nightingale-led chart, station workflow from intake to checkout, body charts and clinical photos, and surgeries at your affiliated ASCs on the office schedule. ASC.Vityls (surgery centers) and Medical.Vityls (physician offices) are separate products. The product is set by your subscription; it can’t be switched here.</p></Card> : isAscEd ? null : <EditionCard />}
    <Card kicker="Lab results" title="Release to the patient portal" testId="settings-release">
      <label className="flex items-start gap-3 text-[15px]"><input type="checkbox" className="w-5 h-5 mt-0.5" checked={s.autoReleaseResults} onChange={e => setS({ ...s, autoReleaseResults: e.target.checked })} data-testid="auto-release" /><span><b>Release results automatically when they are entered</b><br /><span className="text-[14px] text-[#39443E]">Off (default): a clinician reviews each result and then releases it. On: results appear in the portal as soon as they are entered.</span></span></label>
      <Btn variant="primary" className="mt-3" onClick={() => save(`Automatic result release ${s.autoReleaseResults ? 'ON' : 'OFF'}`)} data-testid="save-release">Save</Btn></Card>
    <Card kicker="Surgical risk awareness" title="Numeric triggers (off until your medical director approves)" testId="settings-triggers">
      <p className="text-[14px] text-[#39443E] mb-3">The app ships with no clinical thresholds. Presence-based factors (e.g. anticoagulant on the medication list, diabetes on the problem list, current smoker) flag without numbers. A numeric factor flags only if you enable it here with a value approved by your medical director.</p>
      <table className="vy-table"><thead><tr><th>Measure</th><th>On</th><th>Flag when</th><th>Approved by (medical director)</th><th>Approval date</th></tr></thead><tbody>{s.triggers.map((t, i) => <tr key={t.id}><td>{t.label} <span className="text-[12.5px] text-[#5f6862]">({t.unit})</span></td><td><input type="checkbox" className="w-5 h-5" checked={t.enabled} onChange={e => setT(i, { enabled: e.target.checked })} data-testid={`trigger-on-${t.id}`} /></td>
        <td className="flex gap-1"><select className="vy-input !w-20" value={t.operator} onChange={e => setT(i, { operator: e.target.value as any })}><option>{'>='}</option><option>{'<='}</option></select><input className="vy-input !w-24" inputMode="decimal" placeholder="empty" value={t.value ?? ''} onChange={e => setT(i, { value: num(e.target.value) })} data-testid={`trigger-value-${t.id}`} /></td>
        <td><input className="vy-input" value={t.approvedBy} onChange={e => setT(i, { approvedBy: e.target.value })} data-testid={`trigger-by-${t.id}`} /></td><td><input type="date" className="vy-input" value={t.approvedOn} onChange={e => setT(i, { approvedOn: e.target.value })} data-testid={`trigger-on-date-${t.id}`} /></td></tr>)}</tbody></table>
      <Btn variant="primary" className="mt-3" onClick={saveTriggers} data-testid="save-triggers">Save triggers</Btn></Card>
    <Card kicker="Lab results" title="Practice ranges for portal status bands" testId="settings-bands" right={<Chip>{s.bands.length ? `${s.bands.length} configured` : 'None configured'}</Chip>}>
      <p className="text-[14px] text-[#39443E] mb-3">Without a range, the portal shows “Range not configured by your practice” (neutral). The lab’s own printed range is always shown as text. Enter ranges only after your medical director approves them.</p>
      {s.bands.map((b, i) => <div key={i} className="grid grid-cols-2 md:grid-cols-6 gap-2 mb-2"><input className="vy-input md:col-span-2" placeholder="Test name (exact)" value={b.test} onChange={e => setB(i, { test: e.target.value })} /><input className="vy-input" placeholder="Low" value={b.low ?? ''} onChange={e => setB(i, { low: num(e.target.value) })} /><input className="vy-input" placeholder="High" value={b.high ?? ''} onChange={e => setB(i, { high: num(e.target.value) })} /><input className="vy-input" placeholder="Approved by" value={b.approvedBy} onChange={e => setB(i, { approvedBy: e.target.value })} /><input className="vy-input" type="date" value={b.approvedOn} onChange={e => setB(i, { approvedOn: e.target.value })} /></div>)}
      <div className="flex gap-2"><Btn variant="add" onClick={() => setS({ ...s, bands: [...s.bands, { test: '', low: null, high: null, approvedBy: '', approvedOn: '' }] })}>Add range</Btn><Btn variant="primary" onClick={saveBands}>Save ranges</Btn></div></Card>
    {!isAscEd && <Card kicker="Portal" title="Plain-English test descriptions" testId="settings-descriptions">
      <p className="text-[14px] text-[#39443E] mb-2">Shown to patients with each result. Describe the test only; no ranges or verdicts. Review before use.</p>
      {Object.entries(s.labDescriptions).map(([k, v]) => <label key={k} className="block mb-2"><span className="vy-label">{k}</span><input className="vy-input" value={v} onChange={e => setS({ ...s, labDescriptions: { ...s.labDescriptions, [k]: e.target.value } })} /></label>)}
      <Btn variant="primary" onClick={() => save('Plain-English test descriptions updated')}>Save descriptions</Btn></Card>}
    {!isAscEd && <MedFeeScheduleEditor onToast={onToast} />}
    <Card kicker="Coming later" title={isSurgery ? 'Switched off in this version' : 'Switched off in v0.1'} testId="settings-flags">
      <ul className="text-[14.5px] space-y-1"><li><b>Chronic disease registries</b> (diabetes, heart disease): structure exists (condition type on every problem); registries are off. <Chip>off</Chip></li><li><b>Remote patient monitoring (wearables)</b>: data-model hook only. <Chip>coming later</Chip></li><li><b>Email / text reminders</b> for the Medications &amp; Activities plan. <Chip>coming later</Chip></li><li><b>Remote AI for Nightingale</b>: off until a Business Associate Agreement is in place. <Chip>off</Chip></li></ul></Card>
  </div>;
};
