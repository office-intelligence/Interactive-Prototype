/* Vityls Core UI: locked-module teaser, read-only (expired trial) banner, Modules & plan page, minimal Core patient. */
import React, { useState } from 'react';
import { Lock, Sparkles, Clock, Check } from 'lucide-react';
import { MOD, MODULES, ModuleId, requiresDeep } from './modules';
import { activate, coreAudit, entitlement, missingDeps, now, startTrial } from './practices';
import { corePractice, modState, useCoreTick } from './useCore';
import { useActor, useMedTick } from '../med/ui';
import { medRepo, usDate } from '../med/record';
import { docsOf } from '../surgery/documents';
import './core.css';

const MANAGER = /manager|admin|ceo/i;
const fmt = (iso?: string) => iso ? new Date(iso).toLocaleDateString([], { month: 'short', day: 'numeric', year: 'numeric' }) : '';

/** A faux screenshot of the module (no real data), so a locked page still shows what it looks like. */
const Preview: React.FC<{ m: ModuleId }> = ({ m }) => {
  const rows = m === 'scheduling' ? ['8:00 New patient · Surgeon A', '8:30 Post-op · Surgeon A', '9:00 Consultation · Surgeon B', '9:30 Double-booked · Surgeon A'] : m === 'forms' ? ['Patient registration · sent', 'HIPAA authorization · signed', 'Medical history · at home', 'Consent · ready to sign'] : m === 'messages' ? ['Portal · question about my labs', 'Reply drafted by Nightingale', 'Attachment · insurance card'] : m === 'email-intake' ? ['Surgery request · referral office', 'H&P.pdf · labs.pdf · insurance.jpg', 'Draft reply ready'] : MOD[m].pitch;
  return <div className="core-preview" aria-hidden="true" data-testid="teaser-preview"><div className="bar"><i /><i /><i /><span>{MOD[m].name}</span></div>{rows.map((r, i) => <div key={i} className="row"><b style={{ width: `${18 + (i * 7) % 20}%` }} /><span>{r}</span></div>)}</div>;
};

export const Teaser: React.FC<{ m: ModuleId; onStarted?: () => void }> = ({ m, onStarted }) => {
  useCoreTick(); useMedTick(); const [actor] = useActor(); const p = corePractice(); const [err, setErr] = useState('');
  const d = MOD[m]; const st = modState(m); const e = p ? entitlement(p, m) : undefined; const deps = p ? missingDeps(p, m) : [];
  const canStart = MANAGER.test(actor.role); const usedTrial = (e?.trialsUsed || 0) > 0;
  const go = () => { try { startTrial(p!.id, m, actor.name); onStarted?.(); } catch (x) { setErr((x as Error).message); } };
  return <div className="v7-page core-teaser" data-testid="module-teaser" data-module={m}>
    <div className="v7-card core-teaser-card">
      <div className="core-teaser-text">
        <div className="core-kicker"><Lock size={13} /> {st === 'expired' ? 'Trial ended' : 'Not in your plan yet'}</div>
        <h1 className="v7-h1">{d.name}</h1>
        <p className="core-lead">{d.description}</p>
        <ul className="core-pitch">{d.pitch.map(x => <li key={x}><Check size={14} />{x}</li>)}</ul>
        {deps.length > 0 && <p className="core-need" data-testid="teaser-deps">Needs {deps.map(x => MOD[x].name).join(' and ')}. {st === 'expired' ? '' : 'The trial starts them too, for the same days.'}</p>}
        {st === 'expired' ? <div className="core-actions"><p className="core-note" data-testid="teaser-expired">Your {d.trialDays}-day trial ended {fmt(e?.trialEnd)}. Everything you entered is kept and comes back as soon as {d.short} is added to your plan.</p><button type="button" className="v7-btn primary" disabled={!canStart} onClick={() => { activate(p!.id, m, actor.name); onStarted?.(); }} data-testid="teaser-upgrade">Add to plan</button></div>
          : <div className="core-actions"><button type="button" className="v7-btn primary" disabled={!canStart || !p} onClick={go} data-testid="teaser-start-trial"><Sparkles size={15} />Try free for {d.trialDays} days</button><span className="v7-muted">No card needed. Your data is kept if you don’t continue.</span></div>}
        {!canStart && <p className="core-note" data-testid="teaser-manager">A practice manager or administrator can start the trial (switch the Session).</p>}
        {usedTrial && st !== 'expired' && <p className="core-note">This practice tried {d.short} before.</p>}
        {err && <p className="core-err" role="alert">{err}</p>}
      </div>
      <Preview m={m} />
    </div>
  </div>;
};

export const TrialBanner: React.FC<{ m: ModuleId }> = ({ m }) => {
  useCoreTick(); const p = corePractice(); const [actor] = useActor(); if (!p) return null; const e = entitlement(p, m);
  if (e.state === 'trial') return <div className="core-banner trial" data-testid="trial-banner"><Clock size={14} /><span><b>{MOD[m].name}</b> free trial · {e.daysLeft} day{e.daysLeft === 1 ? '' : 's'} left (ends {fmt(e.trialEnd)})</span>{MANAGER.test(actor.role) && <button type="button" className="v7-quiet core-allow" onClick={() => activate(p.id, m, actor.name)} data-testid="trial-keep">Keep it</button>}</div>;
  if (e.state === 'expired') return <div className="core-banner expired" data-testid="expired-banner"><Lock size={14} /><span><b>{MOD[m].name}</b> trial ended {fmt(e.trialEnd)}. Read only: your data is kept. Add it to your plan to keep working.</span>{MANAGER.test(actor.role) && <button type="button" className="v7-btn sm primary core-allow" onClick={() => activate(p.id, m, actor.name)} data-testid="expired-upgrade">Add to plan</button>}</div>;
  return null;
};

/** Practice › Modules & plan. */
export const ModulesPlan: React.FC<{ onOpen: (m: ModuleId) => void; onBack: () => void }> = ({ onOpen, onBack }) => {
  useCoreTick(); const [actor] = useActor(); const p = corePractice();
  if (!p) return <div className="sv-page"><p>Modules are managed by Vityls Core in the combined build.</p></div>;
  const groups: [string, (s: string) => boolean][] = [['In your plan', s => s === 'active'], ['On trial', s => s === 'trial'], ['Trial ended', s => s === 'expired'], ['Available', s => s === 'off']];
  const log = coreAudit(p.id).filter(a => a.practiceId === p.id).slice(-8).reverse();
  return <div className="v7-page" data-testid="modules-plan">
    <div><button type="button" className="v7-quiet" onClick={onBack}>‹ Practice</button><h1 className="v7-h1 mt-1">Modules &amp; plan</h1><div className="v7-meta">{p.name} · {p.edition === 'ASC' ? 'ASC' : p.edition === 'MEDICAL' ? 'Medical' : 'Surgery'} edition · Vityls Core is always included: practice account, users &amp; PINs, patients, documents, audit, Nightingale and notifications.</div></div>
    {groups.map(([t, f]) => { const l = MODULES.filter(m => m.audience !== 'patient' && f(entitlement(p, m.id).state)); if (!l.length) return null; return <section key={t} className="v7-card core-plan-sec" data-testid={`plan-${t.split(' ')[0].toLowerCase()}`}>
      <h2 className="v7-h3">{t} <span className="v7-h3-sub">· {l.length}</span></h2>
      <div className="core-plan-grid">{l.map(m => { const e = entitlement(p, m.id); const deps = requiresDeep(m.id); return <div key={m.id} className={`core-mod ${e.state}`} data-testid={`plan-mod-${m.id}`}>
        <div className="flex items-center justify-between gap-2"><b>{m.name}</b><span className={`v7-pill ${e.state === 'active' ? 'green' : e.state === 'trial' ? 'blue' : e.state === 'expired' ? 'amber' : ''}`}>{e.state === 'trial' ? `Trial · ${e.daysLeft}d left` : e.state === 'active' ? 'In plan' : e.state === 'expired' ? 'Ended' : 'Available'}</span></div>
        <p>{m.description}</p>
        {deps.length > 0 && <p className="v7-meta">Needs {deps.map(d => MOD[d].short).join(', ')}{e.via ? ` · started with ${MOD[e.via].short}` : ''}</p>}
        <div className="flex gap-2 mt-2">{e.state === 'off' && <button type="button" className="v7-btn sm" onClick={() => onOpen(m.id)} data-testid={`plan-try-${m.id}`}>Try free for {m.trialDays} days</button>}
          {(e.state === 'trial' || e.state === 'expired') && MANAGER.test(actor.role) && <button type="button" className="v7-btn sm primary" onClick={() => activate(p.id, m.id, actor.name)} data-testid={`plan-keep-${m.id}`}>Add to plan</button>}</div>
      </div>; })}</div>
    </section>; })}
    <section className="v7-card core-plan-sec" data-testid="plan-history"><h2 className="v7-h3">Plan history</h2>{log.length ? <ul className="core-log">{log.map((a, i) => <li key={i}><span className="mono">{new Date(a.at).toLocaleDateString()}</span> {a.detail} <span className="v7-muted">· {a.by}</span></li>)}</ul> : <p className="v7-empty">No changes yet.</p>}</section>
  </div>;
};

/** Core patient record (name, DOB, contact, documents, visits) used when the Chart module is off. */
export const MinimalPatient: React.FC<{ pid: string; onBack: () => void; onTryChart: () => void }> = ({ pid, onBack, onTryChart }) => {
  useMedTick(); const p = medRepo.patient(pid); if (!p) return null; const docs = docsOf(pid); const visits = medRepo.visits(pid).sort((a, b) => (b.date + b.time).localeCompare(a.date + a.time));
  return <div className="v7-page" data-testid="core-patient">
    <button type="button" className="v7-quiet" onClick={onBack}>‹ Patients</button>
    <div className="v7-card core-pt"><div><h1 className="v7-h1">{p.name}</h1><div className="v7-meta">DOB {p.dob} · {p.phone || 'no phone'}{p.email ? ` · ${p.email}` : ''}</div><div className="v7-meta">Vityls Core patient record · minimal identity</div></div></div>
    <div className="core-pt-grid">
      <section className="v7-card core-plan-sec"><h2 className="v7-h3">Documents <span className="v7-h3-sub">· {docs.length}</span></h2>{docs.length ? <ul className="core-log" data-testid="core-patient-docs">{docs.map(d => <li key={d.id}><b>{d.type}</b> · {d.title} <span className="v7-muted">· {usDate(d.docDate)} · {d.source}</span></li>)}</ul> : <p className="v7-empty">No documents.</p>}</section>
      <section className="v7-card core-plan-sec"><h2 className="v7-h3">Appointments <span className="v7-h3-sub">· {visits.length}</span></h2>{visits.length ? <ul className="core-log">{visits.slice(0, 8).map(v => <li key={v.id}><span className="mono">{usDate(v.date)} {v.time}</span> {v.visitType} · {v.provider}</li>)}</ul> : <p className="v7-empty">None.</p>}</section>
    </div>
    <div className="core-banner" data-testid="chart-teaser-line"><Lock size={14} /><span>The full chart (summary, diagnoses, notes, labs, photos) is part of the <b>Patient chart</b> module.</span><button type="button" className="v7-quiet" onClick={onTryChart} data-testid="core-patient-try-chart">See the chart</button></div>
  </div>;
};
export { now as coreNow };
