import { EditionCard } from '../v7/EditionCard';
import { ComplianceAsk } from '../surgery/asc10/compliance102';
import React, { useState, useEffect, useRef } from 'react';
import { ProvidersAdmin } from '../v7/ProvidersAdmin';
import { 
  Building2, 
  ShieldCheck, 
  FileText, 
  Sparkles, 
  UploadCloud, 
  UserCheck, 
  Award, 
  FileCheck, 
  Scale, 
  Users, 
  Truck, 
  BookOpen, 
  Stethoscope, 
  Wrench, 
  Lock, 
  CheckCircle2, 
  AlertCircle, 
  Clock, 
  Plus, 
  Search, 
  Download, 
  ChevronRight, 
  RefreshCw, 
  Edit3, 
  Save, 
  Server, 
  Activity, 
  Phone, 
  MapPin, 
  Mail, 
  FileSpreadsheet, 
  Database,
  Sliders,
  Check,
  Eye,
  Trash2,
  BellRing,
  Key,
  ShieldAlert,
  Calendar,
  CreditCard,
  Pill,
  Palette,
  ExternalLink,
  Info,
  X,
  FileUp,
  Filter,
  CheckSquare,
  AlertTriangle,
  FolderOpen,
  File,
  Layers,
  HelpCircle
} from 'lucide-react';
import {
  PracticeConfig,
  PracticeType,
  ProviderDegree,
  UserRoleTitle,
  ProviderItem,
  UserItem,
  VisitTypeSetting,
  RoomSetting,
  EPrescribeConfig,
  CreditCardConfig
} from '../types';
import { PayrollStaffingPage } from './PayrollStaffingPage';
import { DocumentIntakeQueuePage } from './DocumentIntakeQueuePage';
import { ClinicalFormStudioPage } from './ClinicalFormStudioPage';
import { FormsWorkspacePage } from './FormsWorkspacePage';
import { PracticeAdminHome } from './PracticeAdminHome';

export type AdminActiveSection =
  | 'home'
  | 'configure-practice'
  | 'people'
  | 'providers'
  | 'users'
  | 'eprescribe'
  | 'creditcard'
  | 'documents'
  | 'integrations'
  | 'intake-forms'
  | 'form-studio'
  | 'payroll-staffing'
  | 'document-intake';

interface AdministrationPageProps {
  onShowToast?: (msg: string) => void;
  activeSection?: AdminActiveSection;
  onSectionChange?: (section: AdminActiveSection) => void;
  practiceConfig?: PracticeConfig;
  onUpdatePracticeConfig?: (updated: PracticeConfig) => void;
  practicesList?: PracticeConfig[];
  activePracticeId?: string;
  onSelectPractice?: (id: string) => void;
  onAddPractice?: (newPractice: PracticeConfig) => void;
  onDeletePractice?: (id: string) => void;
  onOpenLocalPracticeDashboard?: (practice: { id: string; name: string; createdAt: string }) => void;
  onOpenFormsWorkspace?: () => void;
  onNavigateBilling?: () => void;
  /** Surgery.Vityls v1.4: hide the old 'Administration Home' breadcrumb (ASC keeps it; default false). */
  hideAdminHome?: boolean;
}

export const AdministrationPage: React.FC<AdministrationPageProps> = ({ 
  onShowToast,
  activeSection: externalActiveSection,
  onSectionChange,
  practiceConfig: externalConfig,
  onUpdatePracticeConfig,
  practicesList,
  activePracticeId,
  onSelectPractice,
  onAddPractice,
  onDeletePractice,
  onOpenLocalPracticeDashboard,
  onOpenFormsWorkspace,
  onNavigateBilling,
  hideAdminHome
}) => {
  // Section Navigation State
  const [activeSection, setActiveSection] = useState<AdminActiveSection>(externalActiveSection || 'home');

  useEffect(() => {
    if (externalActiveSection) {
      setActiveSection(externalActiveSection);
    }
  }, [externalActiveSection]);

  const handleSwitchSection = (section: AdminActiveSection) => {
    setActiveSection(section);
    if (onSectionChange) onSectionChange(section);
  };

  const [adminQuery, setAdminQuery] = useState('');
  const adminDestinations: Array<{
    id: AdminActiveSection;
    title: string;
    description: string;
    keywords: string;
    group: string;
  }> = [
    { id:'configure-practice', title:'Practice Configuration', description:'Facility identity, rooms, scheduling and Medical Director designation.', keywords:'location facility rooms medical director practice address', group:'Practice setup' },
    { id:'people', title:'Providers', description:'Medical staff, clinical employees, administrative staff, credentials, access and signatures.', keywords:'doctor surgeon provider credential license nurse staff user payroll', group:'People' },
    { id:'documents', title:'Facility Accreditation & Document Center', description:'Accreditation files, policies, contracts, manuals and renewal tracking.', keywords:'quad a accreditation policy compliance audit document', group:'Compliance' },
    { id:'payroll-staffing', title:'Staffing & Payroll', description:'Staff scheduling, payroll and workforce administration.', keywords:'payroll staffing employee workforce schedule', group:'People' },
  ];
  const visibleAdminDestinations = adminDestinations.filter(item =>
    !adminQuery.trim() || `${item.title} ${item.description} ${item.keywords} ${item.group}`.toLowerCase().includes(adminQuery.toLowerCase())
  );

  // Provider credentialing invitation / upload workflow (frontend prototype; backend persistence/email delivery to follow)
  const [credentialInviteOpen, setCredentialInviteOpen] = useState(false);
  const [credentialPortalOpen, setCredentialPortalOpen] = useState(false);
  const [inviteSurgeonName, setInviteSurgeonName] = useState('');
  const [inviteSurgeonEmail, setInviteSurgeonEmail] = useState('');
  const [credentialRequests, setCredentialRequests] = useState<Array<{id:string;providerId?:string;name:string;email:string;sentAt:string;status:'Application Pending'|'Pending Medical Director Review'|'Privileges Approved'}>>([]);
  const [credentialUploads, setCredentialUploads] = useState<Record<string,string>>({});
  type AccessRecord = { status:'Invitation Pending'|'Active'|'Inactive'; username?:string; passwordSetup?:boolean; signaturePinSetup?:boolean; invitedAt?:string; lastPasswordReset?:string };
  const [accessRecords, setAccessRecords] = useState<Record<string,AccessRecord>>(()=>{try{return JSON.parse(localStorage.getItem('vityls:access-records:v1')||'{}')}catch{return {}}});
  useEffect(()=>{try{localStorage.setItem('vityls:access-records:v1',JSON.stringify(accessRecords))}catch{}},[accessRecords]);
  const accessFor = (id:string):AccessRecord => accessRecords[id] || {status:'Invitation Pending'};
  const sendAccessInvitation = (id:string,name:string,email:string,kind:'provider'|'staff') => {
    const token=Math.random().toString(36).slice(2,10); const activationUrl=`https://portal.vityls.com/account/activate/${token}`;
    setAccessRecords(prev=>({...prev,[id]:{...prev[id],status:'Invitation Pending',invitedAt:new Date().toLocaleDateString()}}));
    const subject=`${practiceName || 'Your Practice'} — Vityls account activation`;
    const extra=kind==='provider'?'Complete your membership / privileges application, then create your username and password and configure your Signature Authentication PIN.':'Create your Vityls username and password and configure your Signature Authentication PIN.';
    const body=`Dear ${name},\n\n${practiceName || 'Our facility'} has invited you to Vityls.\n\n${extra}\n\nSecure activation link:\n${activationUrl}\n\nThank you.`;
    onShowToast?.(`Account activation invitation prepared for ${name}.`); window.location.href=`mailto:${encodeURIComponent(email)}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
  };
  const toggleAccess=(id:string,name:string)=>{const a=accessFor(id); const next=a.status==='Inactive'?'Active':'Inactive'; setAccessRecords(prev=>({...prev,[id]:{...a,status:next}})); onShowToast?.(`${name} access ${next==='Inactive'?'deactivated':'reactivated'}.`)};
  const resetPassword=(id:string,name:string,email:string)=>{const a=accessFor(id); setAccessRecords(prev=>({...prev,[id]:{...a,lastPasswordReset:new Date().toLocaleString()}})); onShowToast?.(`Password reset prepared for ${name}.`); window.location.href=`mailto:${encodeURIComponent(email)}?subject=${encodeURIComponent('Reset your Vityls password')}&body=${encodeURIComponent(`Hello ${name},\n\nUse your Vityls account recovery screen to create a new password. For security, administrators never see or assign user passwords.`)}`};
  const resetSignaturePin=(id:string,name:string)=>{const a=accessFor(id); setAccessRecords(prev=>({...prev,[id]:{...a,signaturePinSetup:false}})); onShowToast?.(`Signature Authentication PIN reset initiated for ${name}. The user must verify identity and create a new PIN.`)};

  const credentialDocumentCategories = [
    'Medical License', 'DEA Registration', 'Malpractice Insurance', 'Board Certification', 'NPI / Enumeration', 'CV', 'Photo ID', 'Other Credential'
  ];

  const openCredentialInvite = (provider?: ProviderItem) => {
    setInviteSurgeonName(provider?.name || '');
    setInviteSurgeonEmail(provider?.email || '');
    setCredentialInviteOpen(true);
  };

  const sendCredentialInvite = () => {
    if (!inviteSurgeonEmail.trim()) {
      onShowToast?.('Enter the surgeon’s email address before sending the request.');
      return;
    }
    const token = Math.random().toString(36).slice(2, 10);
    const portalUrl = `https://portal.vityls.com/credentialing/invite/${token}`;
    const accountUrl = `https://portal.vityls.com/account/activate/${token}`;
    const subject = `${practiceName || 'Your Practice'} — Membership & Privileges Application`;
    const body = `Dear ${inviteSurgeonName || 'Doctor'},

${practiceName || 'Our facility'} is requesting your membership / privileges application through Vityls.

Please complete the online Surgeon Membership & Privileges Application and upload the requested credential documents, including your medical license, DEA registration (if applicable), malpractice insurance, and other requested credentials.

Secure credentialing link:
${portalUrl}

Create your Vityls username and password:
${accountUrl}

During activation, configure your Signature Authentication PIN for clinical attestations and Quick Sign.

After your application and credentials are verified, the Medical Director must review and approve your privileges before privileging is complete.

Thank you.`;
    const id = `cred-${Date.now()}`;
    const matchedProvider = fullProvidersList.find(p => p.email.toLowerCase() === inviteSurgeonEmail.toLowerCase());
    setCredentialRequests(prev => [{id,providerId:matchedProvider?.id,name:inviteSurgeonName || 'Surgeon',email:inviteSurgeonEmail,sentAt:new Date().toLocaleDateString(),status:'Application Pending'}, ...prev]);
    if (matchedProvider && !matchedProvider.isPrimary) setAdditionalProviders(prev => prev.map(p => p.id === matchedProvider.id ? {...p, credentialStatus:'Application Pending'} : p));
    if (matchedProvider) setAccessRecords(prev=>({...prev,[matchedProvider.id]:{...prev[matchedProvider.id],status:'Invitation Pending',invitedAt:new Date().toLocaleDateString()}}));
    setCredentialInviteOpen(false);
    onShowToast?.('Credentialing request prepared. Your email client will open with the invitation prefilled.');
    window.location.href = `mailto:${encodeURIComponent(inviteSurgeonEmail)}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
  };

  // 1. PRACTICE CONFIGURATION STATE
  const [practiceName, setPracticeName] = useState(externalConfig?.practiceName || 'Practice');
  const [locationName, setLocationName] = useState(externalConfig?.locationName || 'Beverly Hills - Main Surgical Pavilion');
  const [isSatellite, setIsSatellite] = useState<boolean>(externalConfig?.isSatellite ?? false);
  const [isPrimary, setIsPrimary] = useState<boolean>(externalConfig?.isPrimary ?? true);
  const [practiceType, setPracticeType] = useState<PracticeType>(externalConfig?.practiceType || 'ASC');
  const [specialty, setSpecialty] = useState(externalConfig?.specialty || 'Plastic & Reconstructive Surgery');
  const [streetAddress, setStreetAddress] = useState(externalConfig?.streetAddress || '1000 Practice Way, Suite 400');
  const [city, setCity] = useState(externalConfig?.city || 'Beverly Hills');
  const [state, setState] = useState(externalConfig?.state || 'CA');
  const [zipCode, setZipCode] = useState(externalConfig?.zipCode || '90210');
  const [country, setCountry] = useState(externalConfig?.country || 'United States');
  const [telephone, setTelephone] = useState(externalConfig?.telephone || '');
  const [email, setEmail] = useState(externalConfig?.email || 'info@auravanguardsurgical.com');
  const [website, setWebsite] = useState(externalConfig?.website || 'https://auravanguardsurgical.com');

  // Primary Provider State
  const [primaryFirstName, setPrimaryFirstName] = useState(externalConfig?.primaryProvider?.firstName || 'Alistair');
  const [primaryLastName, setPrimaryLastName] = useState(externalConfig?.primaryProvider?.lastName || 'Sterling');
  const [primaryDegree, setPrimaryDegree] = useState<ProviderDegree>(externalConfig?.primaryProvider?.degree || 'MD');
  const [primaryCellPhone, setPrimaryCellPhone] = useState(externalConfig?.primaryProvider?.cellPhone || '(310) 555-0185');
  const [primaryEmail, setPrimaryEmail] = useState(externalConfig?.primaryProvider?.email || 'dr.sterling@auravanguardsurgical.com');
  const [primaryNpi, setPrimaryNpi] = useState(externalConfig?.primaryProvider?.npi || '1982736450');

  // Calendar / Scheduler Settings
  const [calendarStartTime, setCalendarStartTime] = useState(externalConfig?.calendarSettings?.startTime || '07:00 AM');
  const [calendarEndTime, setCalendarEndTime] = useState(externalConfig?.calendarSettings?.endTime || '07:00 PM');

  // Visit Types Settings
  const [visitTypes, setVisitTypes] = useState<VisitTypeSetting[]>(externalConfig?.calendarSettings?.visitTypes || [
    { id: 'vt-1', name: 'New Patient', color: '#3b82f6', durationMins: 45 },
    { id: 'vt-2', name: 'Follow Up', color: '#10b981', durationMins: 20 },
    { id: 'vt-3', name: 'Post-op', color: '#8b5cf6', durationMins: 30 },
    { id: 'vt-4', name: 'Pre-op', color: '#f59e0b', durationMins: 45 },
    { id: 'vt-5', name: 'Consultation', color: '#06b6d4', durationMins: 60 },
  ]);

  // Operating Room Settings
  const [rooms, setRooms] = useState<RoomSetting[]>(externalConfig?.calendarSettings?.rooms || [
    { id: 'rm-1', name: 'OR #1', color: '#64748b', type: 'OR', active: true, sortOrder: 1 },
    { id: 'rm-2', name: 'OR #2', color: '#64748b', type: 'OR', active: true, sortOrder: 2 },
    { id: 'rm-3', name: 'GI Suite #1', color: '#64748b', type: 'Procedure', active: true, sortOrder: 3 },
    { id: 'rm-4', name: 'LASER Room', color: '#64748b', type: 'Procedure', active: true, sortOrder: 4 },
  ]);

  // Sync with externalConfig whenever it changes
  useEffect(() => {
    if (externalConfig) {
      setPracticeName(externalConfig.practiceName || '');
      setLocationName(externalConfig.locationName || '');
      setIsSatellite(externalConfig.isSatellite ?? false);
      setIsPrimary(externalConfig.isPrimary ?? false);
      setPracticeType(externalConfig.practiceType || 'ASC');
      setSpecialty(externalConfig.specialty || '');
      setStreetAddress(externalConfig.streetAddress || '');
      setCity(externalConfig.city || '');
      setState(externalConfig.state || '');
      setZipCode(externalConfig.zipCode || '');
      setCountry(externalConfig.country || 'United States');
      setTelephone(externalConfig.telephone || '');
      setEmail(externalConfig.email || '');
      setWebsite(externalConfig.website || '');
      if (externalConfig.primaryProvider) {
        setPrimaryFirstName(externalConfig.primaryProvider.firstName || '');
        setPrimaryLastName(externalConfig.primaryProvider.lastName || '');
        setPrimaryDegree(externalConfig.primaryProvider.degree || 'MD');
        setPrimaryCellPhone(externalConfig.primaryProvider.cellPhone || '');
        setPrimaryEmail(externalConfig.primaryProvider.email || '');
        setPrimaryNpi(externalConfig.primaryProvider.npi || '');
      }
      if (externalConfig.calendarSettings) {
        if (externalConfig.calendarSettings.startTime) setCalendarStartTime(externalConfig.calendarSettings.startTime);
        if (externalConfig.calendarSettings.endTime) setCalendarEndTime(externalConfig.calendarSettings.endTime);
        if (externalConfig.calendarSettings.visitTypes) setVisitTypes(externalConfig.calendarSettings.visitTypes);
        if (externalConfig.calendarSettings.rooms) setRooms(externalConfig.calendarSettings.rooms.map((room, index) => ({ ...room, active: room.active !== false, sortOrder: room.sortOrder ?? index + 1 })).sort((a,b) => (a.sortOrder ?? 0) - (b.sortOrder ?? 0)));
      }
    }
  }, [externalConfig]);

  // Add Practice / Location Modal State
  const [isAddLocationModalOpen, setIsAddLocationModalOpen] = useState(false);
  const [newLocPracticeName, setNewLocPracticeName] = useState('');
  const [newLocBranchName, setNewLocBranchName] = useState('');
  const [newLocType, setNewLocType] = useState<PracticeType>('Office-based Surgery');
  const [newLocSpecialty, setNewLocSpecialty] = useState('Plastic & Aesthetic Surgery');
  const [newLocStreet, setNewLocStreet] = useState('');
  const [newLocCity, setNewLocCity] = useState('');
  const [newLocState, setNewLocState] = useState('CA');
  const [newLocZip, setNewLocZip] = useState('');
  const [newLocCountry, setNewLocCountry] = useState('United States');
  const [newLocPhone, setNewLocPhone] = useState('');
  const [newLocEmail, setNewLocEmail] = useState('');
  const [newLocWebsite, setNewLocWebsite] = useState('');
  const [newLocIsSatellite, setNewLocIsSatellite] = useState(true);
  const [newLocDirectorFirst, setNewLocDirectorFirst] = useState('');
  const [newLocDirectorLast, setNewLocDirectorLast] = useState('');
  const [newLocDirectorDegree, setNewLocDirectorDegree] = useState<ProviderDegree>('MD');
  const [newLocDirectorPhone, setNewLocDirectorPhone] = useState('');
  const [newLocDirectorEmail, setNewLocDirectorEmail] = useState('');
  const [newLocDirectorNpi, setNewLocDirectorNpi] = useState('');
  const [newLocRooms, setNewLocRooms] = useState('Procedure Suite 1, Treatment Bay 2');

  const handleOpenAddPracticeModal = () => {
    setNewLocPracticeName(practiceName ? `${practiceName} (Satellite)` : '');
    setNewLocBranchName('');
    setNewLocType('Office-based Surgery');
    setNewLocSpecialty(specialty || 'Plastic & Aesthetic Surgery');
    setNewLocStreet('');
    setNewLocCity(city || '');
    setNewLocState(state || 'CA');
    setNewLocZip('');
    setNewLocCountry(country || 'United States');
    setNewLocPhone('');
    setNewLocEmail('');
    setNewLocWebsite(website || '');
    setNewLocIsSatellite(true);
    setNewLocDirectorFirst(primaryFirstName || 'Evelyn');
    setNewLocDirectorLast(primaryLastName || 'Vance');
    setNewLocDirectorDegree('MD');
    setNewLocDirectorPhone(primaryCellPhone || '');
    setNewLocDirectorEmail(primaryEmail || '');
    setNewLocDirectorNpi('');
    setNewLocRooms('Procedure Suite 1, Consult Bay 2');
    setIsAddLocationModalOpen(true);
  };

  const handleSaveNewLocation = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newLocPracticeName.trim()) {
      if (onShowToast) onShowToast('Please provide a Practice or Location Name.');
      return;
    }
    if (!newLocCity.trim() || !newLocState.trim()) {
      if (onShowToast) onShowToast('Please enter at least City and State for the location.');
      return;
    }

    const roomNames = newLocRooms.split(',').map(r => r.trim()).filter(Boolean);
    const generatedRooms: RoomSetting[] = roomNames.length > 0
      ? roomNames.map((name, idx) => ({
          id: `rm-new-${idx + 1}-${Date.now()}`,
          name,
          color: idx % 2 === 0 ? '#0284c7' : '#0d9488',
          type: name.toLowerCase().includes('consult') ? 'Consult' : 'Procedure'
        }))
      : [
          { id: `rm-new-1-${Date.now()}`, name: 'Procedure Bay 1', color: '#0284c7', type: 'Procedure' },
          { id: `rm-new-2-${Date.now()}`, name: 'Consult Room A', color: '#0d9488', type: 'Consult' }
        ];

    const newPracticeObj: PracticeConfig = {
      id: `loc-${Date.now()}`,
      practiceName: newLocPracticeName.trim(),
      locationName: newLocBranchName.trim() || `${newLocCity.trim()} - Satellite Office`,
      isSatellite: newLocIsSatellite,
      isPrimary: !newLocIsSatellite,
      practiceType: newLocType,
      specialty: newLocSpecialty.trim(),
      streetAddress: newLocStreet.trim() || '100 Medical Center Way',
      city: newLocCity.trim(),
      state: newLocState.trim().toUpperCase(),
      zipCode: newLocZip.trim() || '90001',
      country: newLocCountry.trim() || 'United States',
      telephone: newLocPhone.trim() || telephone || '',
      email: newLocEmail.trim() || email || 'office@auravanguardsurgical.com',
      website: newLocWebsite.trim() || website || 'https://auravanguardsurgical.com',
      primaryProvider: {
        firstName: newLocDirectorFirst.trim() || 'Medical',
        lastName: newLocDirectorLast.trim(),
        degree: newLocDirectorDegree,
        cellPhone: newLocDirectorPhone.trim(),
        email: newLocDirectorEmail.trim(),
        npi: newLocDirectorNpi.trim()
      },
      calendarSettings: {
        startTime: '08:00 AM',
        endTime: '06:00 PM',
        visitTypes: [
          { id: `vt-n-1`, name: 'Consultation', color: '#3b82f6', durationMins: 45 },
          { id: `vt-n-2`, name: 'Procedure', color: '#10b981', durationMins: 60 },
          { id: `vt-n-3`, name: 'Follow Up', color: '#8b5cf6', durationMins: 20 },
        ],
        rooms: generatedRooms
      }
    };

    if (onAddPractice) {
      onAddPractice(newPracticeObj);
    } else if (onUpdatePracticeConfig) {
      onUpdatePracticeConfig(newPracticeObj);
    }

    setIsAddLocationModalOpen(false);
    if (onShowToast) {
      onShowToast(`Added new location: ${newPracticeObj.practiceName} (${newPracticeObj.locationName})!`);
    }
  };

  // Modals for Visit Types & Rooms
  const [isAddingVisitType, setIsAddingVisitType] = useState(false);
  const [newVisitTypeName, setNewVisitTypeName] = useState('');
  const [newVisitTypeColor, setNewVisitTypeColor] = useState('#6366f1');

  const [isAddingRoom, setIsAddingRoom] = useState(false);
  const [newRoomName, setNewRoomName] = useState('');
  const [newRoomColor, setNewRoomColor] = useState('#10b981');

  // 2. ADDITIONAL PROVIDERS STATE (Primary provider is dynamically merged)
  const [additionalProviders, setAdditionalProviders] = useState<ProviderItem[]>(()=>{try{return JSON.parse(localStorage.getItem('vityls:practice-providers:v1')||'[]')}catch{return []}});
  useEffect(()=>{try{localStorage.setItem('vityls:practice-providers:v1',JSON.stringify(additionalProviders))}catch{}},[additionalProviders]);

  // Provider Modal
  const [isProviderModalOpen, setIsProviderModalOpen] = useState(false);
  const [editingProviderId, setEditingProviderId] = useState<string | null>(null);
  const [providerFormName, setProviderFormName] = useState('');
  const [providerFormDegree, setProviderFormDegree] = useState<ProviderDegree>('MD');
  const [providerFormCell, setProviderFormCell] = useState('');
  const [providerFormEmail, setProviderFormEmail] = useState('');
  const [providerFormNpi, setProviderFormNpi] = useState('');
  const [providerFormSpecialty, setProviderFormSpecialty] = useState('');
  const [providerFormColor, setProviderFormColor] = useState('#2563eb');
  const [medicalDirectorProviderId, setMedicalDirectorProviderId] = useState<string>(() => localStorage.getItem('vityls:medical-director-provider:v1') || 'primary-p1');
  useEffect(()=>{ try { localStorage.setItem('vityls:medical-director-provider:v1', medicalDirectorProviderId); } catch {} }, [medicalDirectorProviderId]);
  const [peopleTab, setPeopleTab] = useState<'medical'|'clinical'|'administrative'|'vendors'>('medical');

  // 3. ADDITIONAL USERS STATE (Primary provider is dynamically merged as a user)
  const [additionalUsers, setAdditionalUsers] = useState<UserItem[]>(()=>{try{return JSON.parse(localStorage.getItem('vityls:practice-users:v1')||'[]')}catch{return []}});
  useEffect(()=>{try{localStorage.setItem('vityls:practice-users:v1',JSON.stringify(additionalUsers))}catch{}},[additionalUsers]);

  // User Modal
  const [isUserModalOpen, setIsUserModalOpen] = useState(false);
  const [editingUserId, setEditingUserId] = useState<string | null>(null);
  const [userFormName, setUserFormName] = useState('');
  const [userFormTitle, setUserFormTitle] = useState<UserRoleTitle | string>('Nurse');
  const [userFormCell, setUserFormCell] = useState('');
  const [userFormEmail, setUserFormEmail] = useState('');

  // 4. E-PRESCRIBE SETUP STATE
  const [ePrescribeData, setEPrescribeData] = useState<EPrescribeConfig>({
    surescriptsId: '', deaNumber: '', epcsTokenSerial: '', spiNumber: '', stateLicense: '',
    defaultPharmacyNetwork: '', twoFactorAuthEnabled: false, status: 'PENDING'
  });

  // 5. CREDIT CARD PROCESSING SETUP STATE
  const [creditCardData, setCreditCardData] = useState<CreditCardConfig>({
    merchantAccountId: '', gatewayProvider: '', terminalIpOrSerial: '', surchargePercentage: 0,
    hsaFsaAccepted: false, autoReceiptMode: 'Email & SMS', status: 'PENDING'
  });

  // 6. DOCUMENT REPOSITORY & ACCREDITATION TABS
  const [activeDocTab, setActiveDocTab] = useState<
    | "Employee Files"
    | "Doctor's Credentials"
    | "Accreditation"
    | "Policy and Procedures"
    | "Legal"
    | "HR"
    | "Vendors"
    | "Manuals"
    | "Equipment Records"
    | "Financial & Audit"
  >("Employee Files");

  const [docSearchQuery, setDocSearchQuery] = useState('');
  const [uploadCategory, setUploadCategory] = useState('Employee Files');
  const [uploadedFilesList, setUploadedFilesList] = useState<Array<{ name: string; category: string; date: string; size: string }>>([]);

  const sampleCategoryFiles: Record<string, { aiSummary: string; files: Array<{ id: string; title: string; type: string; uploader: string; date: string; size: string; status: 'Active' | 'Verified' | 'Expiring Soon' | 'Pending Review'; expDate?: string }> }> = {
    "Employee Files": { aiSummary: "", files: [] },
    "Doctor's Credentials": { aiSummary: "", files: [] },
    "Accreditation": { aiSummary: "", files: [] },
    "Policy and Procedures": { aiSummary: "", files: [] },
    "Legal": { aiSummary: "", files: [] },
    "HR": { aiSummary: "", files: [] },
    "Vendors": { aiSummary: "", files: [] },
    "Manuals": { aiSummary: "", files: [] },
    "Equipment Records": { aiSummary: "", files: [] },
    "Financial & Audit": { aiSummary: "", files: [] }
  };

  // 7. INTAKE FORMS REPOSITORY STATE & DATA MODEL
  const [intakeFormsList, setIntakeFormsList] = useState<Array<{
    id: string;
    title: string;
    category: 'Registration & Demographics' | 'Medical & Surgical History' | 'Consents & Agreements' | 'Financial & HIPAA' | 'Specialty Questionnaire' | 'Pre/Post-Op Instructions';
    targetAudience: string;
    fileFormat: 'PDF' | 'DOCX' | 'DOC' | 'Form';
    fileName: string;
    fileSize: string;
    version: string;
    lastUpdated: string;
    uploadedBy: string;
    isMandatory: boolean;
    status: 'Active' | 'Draft' | 'Archived';
    description: string;
    signatureRequired: boolean;
  }>>([
    {
      id: 'form-1',
      title: 'General Patient Registration & Demographic Intake Form (2026 Revision)',
      category: 'Registration & Demographics',
      targetAudience: 'All New Patients',
      fileFormat: 'PDF',
      fileName: 'General_Patient_Registration_2026_Rev4.pdf',
      fileSize: '1.4 MB',
      version: 'v4.2',
      lastUpdated: 'Jul 18, 2026',
      uploadedBy: 'Sarah Jenkins (Practice Admin)',
      isMandatory: true,
      status: 'Active',
      description: 'Comprehensive patient identification, emergency contacts, legal guarantor, insurance carriers, and pharmacy preferences.',
      signatureRequired: true,
    },
    {
      id: 'form-2',
      title: 'Comprehensive Medical, Surgical & Anesthesia History Questionnaire',
      category: 'Medical & Surgical History',
      targetAudience: 'Surgical Candidates & ASC Admissions',
      fileFormat: 'PDF',
      fileName: 'Medical_Surgical_Anesthesia_History_v3.1.pdf',
      fileSize: '2.8 MB',
      version: 'v3.1',
      lastUpdated: 'Jun 02, 2026',
      uploadedBy: 'Anesthesia Provider',
      isMandatory: true,
      status: 'Active',
      description: 'Detailed past surgical history, cardiopulmonary risks, anesthesia complications, current medications, allergies, and family history.',
      signatureRequired: true,
    },
    {
      id: 'form-3',
      title: 'Informed Surgical Consent, Risks Disclosure & Arbitration Agreement',
      category: 'Consents & Agreements',
      targetAudience: 'Pre-Operative Surgical Patients',
      fileFormat: 'PDF',
      fileName: 'Informed_Surgical_Consent_Arbitration_2026.pdf',
      fileSize: '3.2 MB',
      version: 'v5.0',
      lastUpdated: 'May 20, 2026',
      uploadedBy: 'Provider',
      isMandatory: true,
      status: 'Active',
      description: 'Mandatory clinical risk consent, blood transfusion policy, photography/video authorization, and physician binding arbitration agreement.',
      signatureRequired: true,
    },
    {
      id: 'form-4',
      title: 'HIPAA Notice of Privacy Practices & Medical Records Release Authorization',
      category: 'Financial & HIPAA',
      targetAudience: 'All Patients',
      fileFormat: 'PDF',
      fileName: 'HIPAA_Privacy_Practices_Disclosure_2026.pdf',
      fileSize: '850 KB',
      version: 'v2.0',
      lastUpdated: 'Jan 10, 2026',
      uploadedBy: 'Sarah Jenkins (HR)',
      isMandatory: true,
      status: 'Active',
      description: 'HIPAA compliant notice of privacy practices, electronic communication consent, and PHI designated representative designations.',
      signatureRequired: true,
    },
    {
      id: 'form-5',
      title: 'Patient Financial Agreement, Fee Schedule & Cancellation Policy Terms',
      category: 'Financial & HIPAA',
      targetAudience: 'Self-Pay & Out-of-Network Patients',
      fileFormat: 'PDF',
      fileName: 'Financial_Agreement_Fee_Policy_2026.pdf',
      fileSize: '1.1 MB',
      version: 'v2.2',
      lastUpdated: 'Feb 14, 2026',
      uploadedBy: 'David Montgomery (Billing)',
      isMandatory: true,
      status: 'Active',
      description: 'Outlines deposit policies, surgery center facility fees, anesthesia fee schedules, non-refundable booking fees, and payment plans.',
      signatureRequired: true,
    },
    {
      id: 'form-6',
      title: 'Pre-Operative Medication, Fasting (NPO) & Herbal Supplement Guidelines',
      category: 'Pre/Post-Op Instructions',
      targetAudience: 'Outpatient Surgical Cases',
      fileFormat: 'PDF',
      fileName: 'PreOp_Medication_NPO_Fasting_Instructions.pdf',
      fileSize: '950 KB',
      version: 'v1.8',
      lastUpdated: 'Mar 22, 2026',
      uploadedBy: 'Clinical Staff',
      isMandatory: false,
      status: 'Active',
      description: 'Clear pre-operative fasting timeline, list of anticoagulants/NSAIDs to suspend 14 days prior, and morning-of surgery protocols.',
      signatureRequired: false,
    },
    {
      id: 'form-7',
      title: 'Post-Operative Responsible Caretaker & Transportation Agreement',
      category: 'Consents & Agreements',
      targetAudience: 'General Anesthesia & Sedation Cases',
      fileFormat: 'DOCX',
      fileName: 'PostOp_Caretaker_Transportation_Agreement.docx',
      fileSize: '620 KB',
      version: 'v1.5',
      lastUpdated: 'Apr 08, 2026',
      uploadedBy: 'Sarah Holloway, RN',
      isMandatory: true,
      status: 'Active',
      description: 'Designates authorized adult chaperone for hospital discharge, 24-hour post-op in-home supervision commitment, and emergency contacts.',
      signatureRequired: true,
    },
    {
      id: 'form-8',
      title: 'Facial Aesthetic & Cosmetic Surgical Goals Assessment Questionnaire',
      category: 'Specialty Questionnaire',
      targetAudience: 'Facial Plastic & Reconstructive Consults',
      fileFormat: 'PDF',
      fileName: 'Facial_Aesthetic_Goals_Questionnaire_Rev2.pdf',
      fileSize: '1.6 MB',
      version: 'v2.4',
      lastUpdated: 'Jun 15, 2026',
      uploadedBy: 'Provider',
      isMandatory: false,
      status: 'Active',
      description: 'Patient self-reported aesthetic priorities, skin type classification, prior neuromodulator/filler history, and recovery schedule availability.',
      signatureRequired: false,
    }
  ]);

  const [intakeSearchQuery, setIntakeSearchQuery] = useState('');
  const [intakeCategoryFilter, setIntakeCategoryFilter] = useState<string>('All');
  const [intakeRequirementFilter, setIntakeRequirementFilter] = useState<'All' | 'Mandatory' | 'Optional'>('All');
  
  // Upload Form Panel State
  const [isUploadPanelOpen, setIsUploadPanelOpen] = useState(false);
  const [uploadFormTitle, setUploadFormTitle] = useState('');
  const [uploadFormCategory, setUploadFormCategory] = useState<'Registration & Demographics' | 'Medical & Surgical History' | 'Consents & Agreements' | 'Financial & HIPAA' | 'Specialty Questionnaire' | 'Pre/Post-Op Instructions'>('Registration & Demographics');
  const [uploadFormTarget, setUploadFormTarget] = useState('All New Patients');
  const [uploadFormVersion, setUploadFormVersion] = useState('v1.0 (2026)');
  const [uploadFormDescription, setUploadFormDescription] = useState('');
  const [uploadFormIsMandatory, setUploadFormIsMandatory] = useState(true);
  const [uploadFormSignatureRequired, setUploadFormSignatureRequired] = useState(true);
  const [selectedFileObj, setSelectedFileObj] = useState<File | null>(null);

  // Modals state: Preview & Delete Confirmation
  const [previewingIntakeForm, setPreviewingIntakeForm] = useState<any | null>(null);
  const [deletingIntakeForm, setDeletingIntakeForm] = useState<any | null>(null);
  // Which template is currently being replaced with a new uploaded file
  const [replaceTargetFormId, setReplaceTargetFormId] = useState<string | null>(null);
  const replaceFileInputRef = useRef<HTMLInputElement>(null);

  // EMR Integration Toggles
  const [integrations, setIntegrations] = useState({
    eRx: true,
    questLabs: true,
    billingEdi: true,
    patientSms: true,
    intakeKiosk: true,
    prescriptionMonitoring: true,
  });

  const toggleIntegration = (key: keyof typeof integrations) => {
    setIntegrations(prev => {
      const updated = { ...prev, [key]: !prev[key] };
      if (onShowToast) onShowToast(`Integration setting updated.`);
      return updated;
    });
  };

  // Dynamic Provider List: Merges Primary Provider + Additional Providers
  const fullProvidersList: ProviderItem[] = [
    {
      id: 'primary-p1',
      name: `${primaryFirstName} ${primaryLastName}`.trim() || 'Medical Director',
      degree: primaryDegree,
      specialty: specialty || 'Plastic & Reconstructive Surgery',
      email: primaryEmail || 'primary@mypractice.com',
      cellPhone: primaryCellPhone,
      npi: primaryNpi,
      colorCode: '#2563eb',
      isPrimary: true,
      credentialStatus: 'Active'
    },
    ...additionalProviders
  ];

  // Dynamic Users List: Merges Primary Provider (as Attending Physician) + Additional Users
  const fullUsersList: UserItem[] = [
    {
      id: 'primary-u1',
      name: `${primaryFirstName} ${primaryLastName}`.trim() || 'Medical Director',
      title: 'Medical Director',
      email: primaryEmail || 'primary@mypractice.com',
      cellPhone: primaryCellPhone,
      isPrimary: true
    },
    ...additionalUsers
  ];

  // SAVE PRACTICE CONFIGURATION HANDLER
  const handleSavePracticeConfig = (e: React.FormEvent) => {
    e.preventDefault();

    if (!practiceName.trim()) {
      if (onShowToast) onShowToast('Please enter a valid Practice Name.');
      return;
    }

    if (!streetAddress.trim() || !city.trim() || !state.trim() || !zipCode.trim()) {
      if (onShowToast) onShowToast('Please enter complete Practice Address fields.');
      return;
    }

    if (!primaryFirstName.trim() || !primaryLastName.trim()) {
      if (onShowToast) onShowToast('Please enter Medical Director first and last name.');
      return;
    }

    const compiledConfig: PracticeConfig = {
      id: externalConfig?.id || activePracticeId || 'loc-1',
      practiceName,
      locationName: locationName || `${city} Campus`,
      isSatellite,
      isPrimary,
      practiceType,
      specialty,
      streetAddress,
      city,
      state,
      zipCode,
      country,
      telephone,
      email,
      website,
      primaryProvider: {
        firstName: primaryFirstName,
        lastName: primaryLastName,
        degree: primaryDegree,
        cellPhone: primaryCellPhone,
        email: primaryEmail,
        npi: primaryNpi
      },
      calendarSettings: {
        startTime: calendarStartTime,
        endTime: calendarEndTime,
        visitTypes,
        rooms
      }
    };

    if (onUpdatePracticeConfig) {
      onUpdatePracticeConfig(compiledConfig);
    }

    if (onShowToast) {
      onShowToast('✓ Practice Configuration saved! Medical Director synced to Providers & Users tables.');
    }
  };

  // PROVIDER ACTIONS (ADD / EDIT / DELETE)
  const handleOpenAddProvider = () => {
    setEditingProviderId(null);
    setProviderFormName('');
    setProviderFormDegree('MD');
    setProviderFormCell('');
    setProviderFormEmail('');
    setProviderFormNpi('');
    setProviderFormSpecialty('Surgical Specialty');
    setProviderFormColor('#2563eb');
    setIsProviderModalOpen(true);
  };

  const handleOpenEditProvider = (provider: ProviderItem) => {
    setEditingProviderId(provider.id);
    setProviderFormName(provider.name);
    setProviderFormDegree(provider.degree || 'MD');
    setProviderFormCell(provider.cellPhone || '');
    setProviderFormEmail(provider.email);
    setProviderFormNpi(provider.npi || '');
    setProviderFormSpecialty(provider.specialty);
    setProviderFormColor(provider.colorCode);
    setIsProviderModalOpen(true);
  };

  const handleSaveProviderModal = (e: React.FormEvent) => {
    e.preventDefault();
    if (!providerFormName.trim() || !providerFormEmail.trim()) {
      if (onShowToast) onShowToast('Provider name and email are required.');
      return;
    }

    if (editingProviderId === 'primary-p1') {
      // Editing primary provider in modal -> update primary provider state
      const parts = providerFormName.split(' ');
      setPrimaryFirstName(parts[0] || '');
      setPrimaryLastName(parts.slice(1).join(' ') || '');
      setPrimaryDegree(providerFormDegree);
      setPrimaryCellPhone(providerFormCell);
      setPrimaryEmail(providerFormEmail);
      setPrimaryNpi(providerFormNpi);
      setSpecialty(providerFormSpecialty);
      if (onShowToast) onShowToast('Medical Director details updated successfully!');
    } else if (editingProviderId) {
      // Editing additional provider
      setAdditionalProviders(prev => prev.map(p => {
        if (p.id === editingProviderId) {
          return {
            ...p,
            name: providerFormName,
            degree: providerFormDegree,
            cellPhone: providerFormCell,
            email: providerFormEmail,
            npi: providerFormNpi,
            specialty: providerFormSpecialty,
            colorCode: providerFormColor
          };
        }
        return p;
      }));
      if (onShowToast) onShowToast(`Updated provider ${providerFormName}.`);
    } else {
      // Adding new provider
      const newProv: ProviderItem = {
        id: `p-${Date.now()}`,
        name: providerFormName,
        degree: providerFormDegree,
        cellPhone: providerFormCell,
        email: providerFormEmail,
        npi: providerFormNpi,
        specialty: providerFormSpecialty,
        colorCode: providerFormColor,
        credentialStatus: 'Invitation Pending'
      };
      setAdditionalProviders(prev => [...prev, newProv]);
      setInviteSurgeonName(providerFormName);
      setInviteSurgeonEmail(providerFormEmail);
      setCredentialInviteOpen(true);
      if (onShowToast) onShowToast(`Added ${providerFormName}. Send the application and account-activation invitation to begin credentialing.`);
    }

    setIsProviderModalOpen(false);
  };

  const handleDeleteProvider = (id: string) => {
    if (id === 'primary-p1') {
      if (onShowToast) onShowToast('Cannot delete the Medical Director. Change the Medical Director assignment before removing this provider.');
      return;
    }
    setAdditionalProviders(prev => prev.filter(p => p.id !== id));
    if (onShowToast) onShowToast('Provider removed.');
  };

  // USER ACTIONS (ADD / EDIT / DELETE)
  const handleOpenAddUser = () => {
    setEditingUserId(null);
    setUserFormName('');
    setUserFormTitle('Nurse');
    setUserFormCell('');
    setUserFormEmail('');
    setIsUserModalOpen(true);
  };

  const handleOpenEditUser = (user: UserItem) => {
    setEditingUserId(user.id);
    setUserFormName(user.name);
    setUserFormTitle(user.title);
    setUserFormCell(user.cellPhone || '');
    setUserFormEmail(user.email);
    setIsUserModalOpen(true);
  };

  const handleSaveUserModal = (e: React.FormEvent) => {
    e.preventDefault();
    if (!userFormName.trim() || !userFormEmail.trim()) {
      if (onShowToast) onShowToast('User name and email are required.');
      return;
    }

    if (editingUserId === 'primary-u1') {
      const parts = userFormName.split(' ');
      setPrimaryFirstName(parts[0] || '');
      setPrimaryLastName(parts.slice(1).join(' ') || '');
      setPrimaryEmail(userFormEmail);
      setPrimaryCellPhone(userFormCell);
      if (onShowToast) onShowToast('Medical Director user profile updated!');
    } else if (editingUserId) {
      setAdditionalUsers(prev => prev.map(u => {
        if (u.id === editingUserId) {
          return {
            ...u,
            name: userFormName,
            title: userFormTitle,
            cellPhone: userFormCell,
            email: userFormEmail
          };
        }
        return u;
      }));
      if (onShowToast) onShowToast(`Updated user profile for ${userFormName}.`);
    } else {
      const newUser: UserItem = {
        id: `u-${Date.now()}`,
        name: userFormName,
        title: userFormTitle,
        cellPhone: userFormCell,
        email: userFormEmail
      };
      setAdditionalUsers(prev => [...prev, newUser]);
      setAccessRecords(prev=>({...prev,[newUser.id]:{status:'Invitation Pending'}}));
      setTimeout(()=>sendAccessInvitation(newUser.id,userFormName,userFormEmail,'staff'),0);
      if (onShowToast) onShowToast(`Added ${userFormName}. Account activation invitation is ready.`);
    }

    setIsUserModalOpen(false);
  };

  const handleDeleteUser = (id: string) => {
    if (id === 'primary-u1') {
      if (onShowToast) onShowToast('Cannot delete the Medical Director account while the role is assigned.');
      return;
    }
    setAdditionalUsers(prev => prev.filter(u => u.id !== id));
    if (onShowToast) onShowToast('User account removed.');
  };

  // VISIT TYPE ACTIONS
  const handleAddVisitType = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newVisitTypeName.trim()) return;
    const newVT: VisitTypeSetting = {
      id: `vt-${Date.now()}`,
      name: newVisitTypeName.trim(),
      color: newVisitTypeColor,
      durationMins: 30
    };
    setVisitTypes(prev => [...prev, newVT]);
    setNewVisitTypeName('');
    setIsAddingVisitType(false);
    if (onShowToast) onShowToast(`Added visit type: ${newVT.name}`);
  };

  const handleDeleteVisitType = (id: string) => {
    if (visitTypes.length <= 1) {
      if (onShowToast) onShowToast('At least one visit type is required.');
      return;
    }
    setVisitTypes(prev => prev.filter(v => v.id !== id));
    if (onShowToast) onShowToast('Visit type removed.');
  };

  // ROOM ACTIONS — Practice configuration is the scheduler room source of truth.
  const handleAddRoom = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newRoomName.trim()) return;
    const newRm: RoomSetting = {
      id: `rm-${Date.now()}`,
      name: newRoomName.trim(),
      color: '#64748b',
      type: /(^|\s)or(\s|#|$)/i.test(newRoomName.trim()) ? 'OR' : 'Procedure',
      active: true,
      sortOrder: rooms.length + 1
    };
    setRooms(prev => [...prev, newRm]);
    setNewRoomName('');
    setIsAddingRoom(false);
    onShowToast?.(`Added scheduling room: ${newRm.name}`);
  };

  const handleDeleteRoom = (id: string) => {
    if (rooms.length <= 1) { onShowToast?.('At least one scheduling room is required.'); return; }
    setRooms(prev => prev.filter(r => r.id !== id).map((room, index) => ({ ...room, sortOrder: index + 1 })));
    onShowToast?.('Room removed. Existing database cases should retain the stable room ID for historical integrity.');
  };
  const handleRenameRoom = (id: string, name: string) => setRooms(prev => prev.map(room => room.id === id ? { ...room, name } : room));
  const handleToggleRoomActive = (id: string) => {
    setRooms(prev => {
      const target = prev.find(room => room.id === id);
      if (!target) return prev;
      const activeCount = prev.filter(room => room.active !== false).length;
      if (target.active !== false && activeCount <= 1) { onShowToast?.('At least one scheduling room must remain active.'); return prev; }
      return prev.map(room => room.id === id ? { ...room, active: room.active === false } : room);
    });
  };
  const handleMoveRoom = (id: string, direction: -1 | 1) => {
    setRooms(prev => {
      const ordered = [...prev].sort((a,b) => (a.sortOrder ?? 0) - (b.sortOrder ?? 0));
      const index = ordered.findIndex(room => room.id === id);
      const targetIndex = index + direction;
      if (index < 0 || targetIndex < 0 || targetIndex >= ordered.length) return prev;
      [ordered[index], ordered[targetIndex]] = [ordered[targetIndex], ordered[index]];
      return ordered.map((room, idx) => ({ ...room, sortOrder: idx + 1 }));
    });
  };

  // File upload simulation for Document Repository
  const handleFileUploadSim = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const fileName = e.target.files[0].name;
      const sizeMb = (e.target.files[0].size / (1024 * 1024)).toFixed(1) + ' MB';
      
      const newFileObj = {
        name: fileName,
        category: uploadCategory,
        date: 'Today',
        size: sizeMb
      };

      setUploadedFilesList(prev => [newFileObj, ...prev]);
      if (onShowToast) onShowToast(`Uploaded ${fileName} to ${uploadCategory} repository.`);
    }
  };

  const currentTabContent = sampleCategoryFiles[activeDocTab] || sampleCategoryFiles['Employee Files'];
  const filteredFiles = currentTabContent.files.filter(
    f => f.title.toLowerCase().includes(docSearchQuery.toLowerCase()) || f.uploader.toLowerCase().includes(docSearchQuery.toLowerCase())
  );

  // Intake Forms Handlers & Filters
  const handleIntakeFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const file = e.target.files[0];
      setSelectedFileObj(file);
      if (!uploadFormTitle.trim()) {
        const cleanName = file.name.replace(/\.[^/.]+$/, "").replace(/[-_]/g, " ");
        setUploadFormTitle(cleanName);
      }
    }
  };

  const handleCreateIntakeForm = (e: React.FormEvent) => {
    e.preventDefault();
    if (!uploadFormTitle.trim()) {
      if (onShowToast) onShowToast('Please specify a Form Title.');
      return;
    }

    const ext = selectedFileObj ? selectedFileObj.name.split('.').pop()?.toUpperCase() : 'PDF';
    const detectedFormat = (ext === 'DOCX' ? 'DOCX' : ext === 'DOC' ? 'DOC' : 'PDF') as 'PDF' | 'DOCX' | 'DOC' | 'Form';
    const sizeStr = selectedFileObj 
      ? (selectedFileObj.size / (1024 * 1024) >= 1 
          ? `${(selectedFileObj.size / (1024 * 1024)).toFixed(1)} MB` 
          : `${Math.round(selectedFileObj.size / 1024)} KB`)
      : '1.4 MB';

    const newForm = {
      id: `intake-${Date.now()}`,
      title: uploadFormTitle.trim(),
      category: uploadFormCategory,
      targetAudience: uploadFormTarget.trim() || 'All New Patients',
      fileFormat: detectedFormat,
      fileName: selectedFileObj ? selectedFileObj.name : `${uploadFormTitle.trim().replace(/\s+/g, '_')}_2026.pdf`,
      fileSize: sizeStr,
      version: uploadFormVersion.trim() || 'v1.0 (2026)',
      lastUpdated: 'Aug 17, 2026',
      uploadedBy: `${primaryFirstName} ${primaryLastName}`.trim() || 'Practice Admin',
      isMandatory: uploadFormIsMandatory,
      status: 'Active' as const,
      description: uploadFormDescription.trim() || 'Custom patient onboarding and registration intake form.',
      signatureRequired: uploadFormSignatureRequired
    };

    setIntakeFormsList(prev => [newForm, ...prev]);
    setUploadFormTitle('');
    setUploadFormDescription('');
    setSelectedFileObj(null);
    setIsUploadPanelOpen(false);
    if (onShowToast) onShowToast(`✓ Successfully uploaded and published "${newForm.title}" to Intake Forms.`);
  };

  const handleConfirmDeleteIntakeForm = () => {
    if (!deletingIntakeForm) return;
    const formTitle = deletingIntakeForm.title;
    setIntakeFormsList(prev => prev.filter(f => f.id !== deletingIntakeForm.id));
    setDeletingIntakeForm(null);
    if (onShowToast) onShowToast(`Removed intake form "${formTitle}".`);
  };

  const handleToggleFormMandatory = (formId: string) => {
    setIntakeFormsList(prev => prev.map(f => {
      if (f.id === formId) {
        const nextVal = !f.isMandatory;
        if (onShowToast) onShowToast(`Updated "${f.title}" requirement to: ${nextVal ? 'Mandatory for check-in' : 'Optional'}`);
        return { ...f, isMandatory: nextVal };
      }
      return f;
    }));
  };

  // Replace an existing template's source file (delete/update/replace/upload
  // requirement from the "Shared Application Requirements" spec) — swaps in
  // the newly uploaded PDF/DOCX while keeping the template's id, category,
  // and configuration intact.
  const handleReplaceFileSelected = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    const targetId = replaceTargetFormId;
    e.target.value = '';
    setReplaceTargetFormId(null);
    if (!file || !targetId) return;

    const ext = file.name.split('.').pop()?.toUpperCase();
    const detectedFormat = (ext === 'DOCX' ? 'DOCX' : ext === 'DOC' ? 'DOC' : 'PDF') as 'PDF' | 'DOCX' | 'DOC' | 'Form';
    const sizeStr = file.size / (1024 * 1024) >= 1
      ? `${(file.size / (1024 * 1024)).toFixed(1)} MB`
      : `${Math.round(file.size / 1024)} KB`;
    const todayStr = new Date().toLocaleDateString('en-US', { month: 'short', day: '2-digit', year: 'numeric' });

    let replacedTitle = '';
    setIntakeFormsList(prev => prev.map(f => {
      if (f.id !== targetId) return f;
      replacedTitle = f.title;
      return {
        ...f,
        fileName: file.name,
        fileFormat: detectedFormat,
        fileSize: sizeStr,
        lastUpdated: todayStr,
        uploadedBy: `${primaryFirstName} ${primaryLastName}`.trim() || 'Practice Admin',
      };
    }));
    if (onShowToast) onShowToast(`✓ Replaced source file for "${replacedTitle}" — converted to interactive HTML form.`);
  };

  const filteredIntakeForms = intakeFormsList.filter(form => {
    const matchesSearch = 
      form.title.toLowerCase().includes(intakeSearchQuery.toLowerCase()) ||
      form.description.toLowerCase().includes(intakeSearchQuery.toLowerCase()) ||
      form.fileName.toLowerCase().includes(intakeSearchQuery.toLowerCase()) ||
      form.uploadedBy.toLowerCase().includes(intakeSearchQuery.toLowerCase()) ||
      form.category.toLowerCase().includes(intakeSearchQuery.toLowerCase());

    const matchesCategory = intakeCategoryFilter === 'All' || form.category === intakeCategoryFilter;

    const matchesRequirement = 
      intakeRequirementFilter === 'All' || 
      (intakeRequirementFilter === 'Mandatory' && form.isMandatory) ||
      (intakeRequirementFilter === 'Optional' && !form.isMandatory);

    return matchesSearch && matchesCategory && matchesRequirement;
  });

  if (activeSection === 'home') {
    return (
      <PracticeAdminHome
        practiceConfig={externalConfig || { practiceName: 'Your Practice' } as PracticeConfig}
        onNavigate={handleSwitchSection}
        onOpenForms={onOpenFormsWorkspace}
        onNavigateBilling={onNavigateBilling}
        onShowToast={onShowToast}
      />
    );
  }


  return (
    <div className="w-full space-y-6 animate-in fade-in duration-300 font-sans">
      
      <div className="flex flex-wrap items-center justify-between gap-3 px-1">
        <div>
          {!hideAdminHome && <><button onClick={()=>handleSwitchSection('home')} className="text-xs font-bold text-emerald-700 hover:underline">Administration Home</button>
          <span className="text-xs text-stone-400 mx-2">/</span></>}
          {hideAdminHome ? <h1 className="sv-title">Compliance &amp; credentials</h1> : <span className="text-xs font-semibold text-stone-700">Practice configuration</span>}
        </div>
        <button onClick={() => onShowToast?.('Running Nightingale AI Administrative System Audit...')} className="px-3 py-2 rounded-lg border border-stone-200 bg-white text-xs font-bold text-stone-700 flex items-center gap-1.5"><RefreshCw className="w-3.5 h-3.5"/>Run System Audit</button>
      </div>
      {hideAdminHome && <ComplianceAsk />}

      {activeSection === 'people' && (
        <div className="space-y-5">
          <div className="bg-gradient-to-r from-[#14432E] to-[#1F6E52] text-white rounded-2xl p-6">
            <div className="flex items-start justify-between gap-4 flex-wrap"><div><div className="text-[10px] font-bold uppercase tracking-[.14em] text-emerald-100">Providers & staff</div><h2 className="text-xl font-bold mt-1 !text-white">One person. One identity. Multiple roles.</h2><p className="text-xs text-white/80 mt-2 max-w-3xl">Manage professional credentials, employment relationship, Vityls access, signature authentication, privileges, renewals, and workforce status without creating the same person in multiple places.</p></div><button type="button" onClick={peopleTab==='medical'?handleOpenAddProvider:handleOpenAddUser} className="px-4 py-2 rounded-xl bg-white text-emerald-900 text-xs font-bold">+ Add Person</button></div>
          </div>
          <div className="bg-white rounded-2xl border border-stone-200 p-3 flex flex-wrap gap-2">
            {([['medical','Providers'],['clinical','Clinical Staff'],['administrative','Administrative Staff'],['vendors','Vendors & Contractors']] as const).map(([id,label])=><button key={id} type="button" onClick={()=>setPeopleTab(id)} className={`px-4 py-2 rounded-lg text-xs font-bold ${peopleTab===id?'bg-emerald-700 text-white':'bg-stone-50 text-stone-700 border border-stone-200'}`}>{label}</button>)}
          </div>
          {peopleTab==='medical' && <div className="space-y-5">
            <ProvidersAdmin practice={practiceName} onToast={m=>onShowToast?.(m)} />
            <div className="vy-card p-5"><div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200"><div className="text-[10px] uppercase tracking-wider font-bold text-emerald-700">Medical Director designation</div><div className="flex flex-col sm:flex-row gap-2 mt-2"><select value={medicalDirectorProviderId} onChange={(e)=>setMedicalDirectorProviderId(e.target.value)} className="flex-1 px-3 py-2 rounded-lg border border-emerald-200 bg-white text-xs font-semibold">{fullProvidersList.map(p=><option key={p.id} value={p.id}>{p.name}{p.degree?`, ${p.degree}`:''} — {p.specialty}</option>)}</select><button type="button" onClick={()=>onShowToast?.('Medical Director designation saved for this evaluation practice.')} className="px-3 py-2 rounded-lg bg-emerald-700 text-white text-xs font-bold">Save Designation</button></div></div></div>
          </div>}
          {(peopleTab==='clinical'||peopleTab==='administrative') && <div className="bg-white rounded-2xl border border-stone-200 p-6 space-y-4"><div className="flex justify-between gap-3 flex-wrap"><div><h3 className="font-bold text-stone-900">{peopleTab==='clinical'?'Clinical Staff':'Administrative Staff'}</h3><p className="text-xs text-stone-500 mt-1">{peopleTab==='clinical'?'RNs, LVNs, MAs and clinical employees: licenses/certifications, competencies, access, signature authentication and workforce status.':'Administrator, front desk, billing and office staff: employment, access, training and workforce status.'}</p></div><button type="button" onClick={handleOpenAddUser} className="px-3 py-2 rounded-lg bg-emerald-700 text-white text-xs font-bold">+ Add Employee & Invite</button></div><div className="overflow-x-auto"><table className="w-full text-left text-xs"><thead><tr className="bg-stone-50 text-[10px] uppercase text-stone-500"><th className="p-3">Person</th><th className="p-3">Role</th><th className="p-3">Credentials / Training</th><th className="p-3">Account</th><th className="p-3">Signature</th><th className="p-3 text-right">User Actions</th></tr></thead><tbody>{additionalUsers.filter(u=>peopleTab==='clinical'?/nurse|rn|lvn|medical assistant|ma|tech/i.test(String(u.title)):!/nurse|rn|lvn|medical assistant|ma|tech/i.test(String(u.title))).map(u=>{const a=accessFor(u.id);return <tr key={u.id} className="border-t border-stone-100"><td className="p-3 font-bold">{u.name}<div className="text-[10px] text-stone-400 font-normal">{u.email}</div></td><td className="p-3">{u.title}</td><td className="p-3">Nightingale monitored</td><td className="p-3"><span className={`font-semibold ${a.status==='Inactive'?'text-rose-700':a.status==='Active'?'text-emerald-700':'text-amber-700'}`}>{a.status}</span><div className="text-[10px] text-stone-400">Username/password + role permissions</div></td><td className="p-3">{peopleTab==='clinical'?(a.signaturePinSetup?'PIN active':'Signature PIN setup'):'Account authentication'}</td><td className="p-3 text-right"><div className="flex flex-wrap justify-end gap-1"><button type="button" onClick={()=>sendAccessInvitation(u.id,u.name,u.email,'staff')} className="px-2 py-1 rounded bg-blue-50 text-blue-800 font-semibold">{a.invitedAt?'Resend Invite':'Send Invite'}</button><button type="button" onClick={()=>resetPassword(u.id,u.name,u.email)} className="px-2 py-1 rounded bg-stone-100 font-semibold">Reset Password</button>{peopleTab==='clinical'&&<button type="button" onClick={()=>resetSignaturePin(u.id,u.name)} className="px-2 py-1 rounded bg-stone-100 font-semibold">Reset PIN</button>}<button type="button" onClick={()=>toggleAccess(u.id,u.name)} className={`px-2 py-1 rounded font-semibold ${a.status==='Inactive'?'bg-emerald-50 text-emerald-800':'bg-rose-50 text-rose-700'}`}>{a.status==='Inactive'?'Reactivate':'Deactivate'}</button><button type="button" onClick={()=>handleOpenEditUser(u)} className="px-2 py-1 rounded bg-stone-100 font-semibold">Edit</button></div></td></tr>})}</tbody></table></div>{!additionalUsers.length&&<div className="p-6 text-center text-xs text-stone-500 border border-dashed rounded-xl">Add staff here once. Vityls sends account activation so the user creates their own username and password. Clinical staff also establish signature authentication.</div>}</div>}
          {peopleTab==='vendors' && <div className="bg-white rounded-2xl border border-stone-200 p-8 text-center"><h3 className="font-bold">Vendors & Contractors</h3><p className="text-xs text-stone-500 mt-2">Contracts, insurance, required documents, access status and expiration monitoring live here. Vendors are not employee/user records unless access is explicitly granted.</p><button type="button" onClick={()=>onShowToast?.('Vendor/contractor record workflow is staged for database integration.')} className="mt-4 px-3 py-2 rounded-lg bg-emerald-700 text-white text-xs font-bold">+ Add Vendor / Contractor</button></div>}
          <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 text-xs text-amber-900"><strong>Nightingale credential watch:</strong> this workspace is the single place for license, malpractice, certification, privilege, training and renewal status. Payroll/timekeeping applies to employees; it is not automatically applied to surgeons or independent providers.</div>
        </div>
      )}

      {/* ======================================================== */}
      {/* SECTION 9: PAYROLL & STAFFING COMMAND CENTER              */}
      {/* ======================================================== */}
      {activeSection === 'payroll-staffing' && (
        <PayrollStaffingPage onShowToast={onShowToast} />
      )}

      {/* ======================================================== */}
      {/* SECTION 10: DOCUMENT INTAKE / OCR REVIEW QUEUE             */}
      {/* ======================================================== */}
      {activeSection === 'document-intake' && (
        <DocumentIntakeQueuePage onShowToast={onShowToast} />
      )}

      {/* ======================================================== */}
      {/* SECTION 1: CONFIGURE PRACTICE SECTION                    */}
      {/* ======================================================== */}
      {activeSection === 'configure-practice' && (
        <form onSubmit={handleSavePracticeConfig} id="practice-setup-section" className="space-y-6">
          <EditionCard />
          {/* Practice Information Card */}
          <div className="bg-white p-6 sm:p-8 rounded-2xl border border-stone-200 shadow-2xs space-y-6">
            <div className="border-b border-stone-200 pb-4 flex items-center justify-between flex-wrap gap-3">
              <div>
                <div className="flex items-center gap-2 flex-wrap">
                  <h3 className="text-base font-bold text-stone-900 flex items-center gap-2">
                    <Building2 className="w-5 h-5 text-emerald-700" />
                    <span>Practice Information</span>
                  </h3>
                  {isSatellite ? (
                    <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-900 border border-amber-300">
                      Satellite Location
                    </span>
                  ) : (
                    <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-900 border border-emerald-300">
                      Primary Campus
                    </span>
                  )}
                  {locationName && (
                    <span className="text-xs font-semibold text-stone-500 bg-stone-100 px-2 py-0.5 rounded-md">
                      {locationName}
                    </span>
                  )}
                </div>
                <p className="text-xs text-stone-500 mt-0.5">
                  Core facility demographics, satellite locations, and licensing identity
                </p>
              </div>

              <div className="flex items-center gap-2.5 flex-wrap">
                {/* Add a New Practice or Location Button */}
                <button
                  type="button"
                  onClick={handleOpenAddPracticeModal}
                  id="admin-add-practice-btn"
                  className="hidden px-3.5 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold items-center gap-1.5 transition-all shadow-xs hover:shadow-md cursor-pointer shrink-0"
                  title="Add a New Practice Location or Satellite Office"
                >
                  <Plus className="w-4 h-4" />
                  <span>Add a New Practice or Location</span>
                </button>

                <span className="px-2.5 py-1 rounded-full text-[11px] font-bold bg-emerald-50 text-emerald-800 border border-emerald-200">
                  Mandatory Setup
                </span>
              </div>
            </div>

            {/* Multiple Locations Quick Switcher if configured */}
            {false && practicesList && practicesList.length > 0 && (
              <div className="bg-stone-50/90 p-3.5 rounded-xl border border-stone-200/90 space-y-2">
                <div className="flex items-center justify-between flex-wrap gap-2">
                  <div className="flex items-center gap-2">
                    <MapPin className="w-4 h-4 text-emerald-700" />
                    <span className="text-xs font-bold text-stone-900">Configured Practices & Locations ({practicesList.length}):</span>
                    <span className="text-[11px] text-stone-500">Click to switch or edit</span>
                  </div>
                  <span className="text-[11px] text-stone-500 font-medium">Active: <strong className="text-stone-900">{practiceName}</strong></span>
                </div>

                <div className="flex items-center gap-2 flex-wrap pt-1">
                  {practicesList.map((loc) => {
                    const isCurrent = loc.id === (externalConfig?.id || activePracticeId);
                    return (
                      <button
                        key={loc.id || loc.practiceName}
                        type="button"
                        onClick={() => {
                          if (onSelectPractice && loc.id) {
                            onSelectPractice(loc.id);
                          }
                        }}
                        className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-2 transition-all cursor-pointer ${
                          isCurrent
                            ? 'bg-emerald-700 text-white shadow-xs font-bold ring-2 ring-emerald-700/20'
                            : 'bg-white text-stone-700 hover:bg-stone-100 border border-stone-200'
                        }`}
                      >
                        <Building2 className="w-3.5 h-3.5" />
                        <span className="truncate max-w-[190px]">{loc.locationName || loc.practiceName}</span>
                        {loc.isPrimary && (
                          <span className={`text-[9px] px-1.5 py-0.5 rounded-sm uppercase tracking-wider font-bold ${isCurrent ? 'bg-emerald-800 text-emerald-100' : 'bg-emerald-100 text-emerald-800'}`}>
                            Main
                          </span>
                        )}
                        {loc.isSatellite && (
                          <span className={`text-[9px] px-1.5 py-0.5 rounded-sm uppercase tracking-wider font-bold ${isCurrent ? 'bg-amber-600 text-white' : 'bg-amber-100 text-amber-800'}`}>
                            Satellite
                          </span>
                        )}
                      </button>
                    );
                  })}
                </div>
              </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
              
              {/* Practice Name */}
              <div className="space-y-1.5 md:col-span-2">
                <label className="text-xs font-bold text-stone-700">
                  Practice Name <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={practiceName}
                  onChange={(e) => setPracticeName(e.target.value)}
                  placeholder="e.g. Practice"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 focus:border-emerald-600 text-xs text-stone-900 outline-hidden bg-stone-50/50 focus:bg-white"
                />
              </div>

              {/* Location / Satellite Branch Name — hidden in ASC edition. */}
              <div className="hidden space-y-1.5">
                <label className="text-xs font-bold text-stone-700 flex items-center justify-between">
                  <span>Location / Branch Subtitle</span>
                  <span className="text-[10px] text-stone-400 font-normal">Optional</span>
                </label>
                <input
                  type="text"
                  value={locationName}
                  onChange={(e) => setLocationName(e.target.value)}
                  placeholder="e.g. Beverly Hills Main OR, Century City Annex"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 focus:border-emerald-600 text-xs text-stone-900 outline-hidden bg-stone-50/50 focus:bg-white"
                />
              </div>

              {/* Practice Type */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-stone-700">
                  Practice Type <span className="text-rose-500">*</span>
                </label>
                <select
                  value={practiceType}
                  onChange={(e) => setPracticeType(e.target.value as PracticeType)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 focus:border-emerald-600 text-xs text-stone-900 outline-hidden bg-stone-50/50 focus:bg-white"
                >
                  <option value="ASC">Ambulatory Surgical Center (ASC)</option>
                  <option value="Office-based Surgery">Office-based Surgery (OBS)</option>
                  <option value="General Medical/Surgical">General Medical/Surgical</option>
                  <option value="Medspa">Medspa & Aesthetic Clinic</option>
                  <option value="Surgeon-Owned Operating Suite">Surgeon-Owned Operating Suite</option>
                  <option value="Multispecialty Clinic">Multispecialty Clinic</option>
                  <option value="Other">Other Practice Type</option>
                </select>
              </div>

              {/* Location Classification — hidden in ASC edition. */}
              <div className="hidden space-y-1.5 flex flex-col justify-center">
                <label className="text-xs font-bold text-stone-700">
                  Location Classification
                </label>
                <div className="flex items-center gap-4 pt-1">
                  <label className="flex items-center gap-2 text-xs text-stone-700 cursor-pointer">
                    <input
                      type="radio"
                      name="locClassification"
                      checked={!isSatellite}
                      onChange={() => {
                        setIsSatellite(false);
                        setIsPrimary(true);
                      }}
                      className="text-emerald-700 focus:ring-emerald-600"
                    />
                    <span>Main / Primary Location</span>
                  </label>
                  <label className="flex items-center gap-2 text-xs text-stone-700 cursor-pointer">
                    <input
                      type="radio"
                      name="locClassification"
                      checked={isSatellite}
                      onChange={() => {
                        setIsSatellite(true);
                        setIsPrimary(false);
                      }}
                      className="text-emerald-700 focus:ring-emerald-600"
                    />
                    <span>Satellite Office</span>
                  </label>
                </div>
              </div>

              {/* Specialty (Applicable especially for General Medical/Surgical) */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-stone-700">
                  Clinical Specialty {practiceType === 'General Medical/Surgical' && <span className="text-rose-500">*</span>}
                </label>
                <input
                  type="text"
                  value={specialty}
                  onChange={(e) => setSpecialty(e.target.value)}
                  placeholder="e.g. Plastic Surgery, Orthopedics, ENT"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 focus:border-emerald-600 text-xs text-stone-900 outline-hidden bg-stone-50/50 focus:bg-white"
                />
              </div>

              {/* Telephone */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-stone-700">
                  Telephone <span className="text-rose-500">*</span>
                </label>
                <input
                  type="tel"
                  required
                  value={telephone}
                  onChange={(e) => setTelephone(e.target.value)}
                  placeholder="(310) 859-2000"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 focus:border-emerald-600 text-xs text-stone-900 outline-hidden bg-stone-50/50 focus:bg-white"
                />
              </div>

              {/* Main Practice Email */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-stone-700">
                  Main Practice Email Address <span className="text-rose-500">*</span>
                </label>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="info@mypractice.com"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 focus:border-emerald-600 text-xs text-stone-900 outline-hidden bg-stone-50/50 focus:bg-white"
                />
              </div>

              {/* Practice Website */}
              <div className="space-y-1.5 md:col-span-2">
                <label className="text-xs font-bold text-stone-700">
                  Practice Website <span className="text-rose-500">*</span>
                </label>
                <input
                  type="url"
                  required
                  value={website}
                  onChange={(e) => setWebsite(e.target.value)}
                  placeholder="https://mypractice.com"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 focus:border-emerald-600 text-xs text-stone-900 outline-hidden bg-stone-50/50 focus:bg-white"
                />
              </div>

            </div>

            {/* Address Group */}
            <div className="pt-4 border-t border-stone-100 space-y-3">
              <label className="text-xs font-bold text-stone-800 uppercase tracking-wider">
                Practice Facility Physical Address <span className="text-rose-500">*</span>
              </label>

              <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
                <div className="md:col-span-5 space-y-1">
                  <label className="text-[11px] font-semibold text-stone-600">Street Address</label>
                  <input
                    type="text"
                    required
                    value={streetAddress}
                    onChange={(e) => setStreetAddress(e.target.value)}
                    placeholder="435 N Bedford Dr, Suite 300"
                    className="w-full px-3.5 py-2 rounded-xl border border-stone-300 text-xs outline-hidden focus:border-emerald-600"
                  />
                </div>

                <div className="md:col-span-3 space-y-1">
                  <label className="text-[11px] font-semibold text-stone-600">City</label>
                  <input
                    type="text"
                    required
                    value={city}
                    onChange={(e) => setCity(e.target.value)}
                    placeholder="Beverly Hills"
                    className="w-full px-3.5 py-2 rounded-xl border border-stone-300 text-xs outline-hidden focus:border-emerald-600"
                  />
                </div>

                <div className="md:col-span-2 space-y-1">
                  <label className="text-[11px] font-semibold text-stone-600">State</label>
                  <input
                    type="text"
                    required
                    value={state}
                    onChange={(e) => setState(e.target.value)}
                    placeholder="CA"
                    className="w-full px-3.5 py-2 rounded-xl border border-stone-300 text-xs outline-hidden focus:border-emerald-600"
                  />
                </div>

                <div className="md:col-span-2 space-y-1">
                  <label className="text-[11px] font-semibold text-stone-600">ZIP Code</label>
                  <input
                    type="text"
                    required
                    value={zipCode}
                    onChange={(e) => setZipCode(e.target.value)}
                    placeholder="90210"
                    className="w-full px-3.5 py-2 rounded-xl border border-stone-300 text-xs outline-hidden focus:border-emerald-600"
                  />
                </div>
              </div>
            </div>

          </div>

          {/* Primary Provider Card — MED edition only; hidden in ASC edition. */}
          <div className="hidden bg-white p-6 sm:p-8 rounded-2xl border border-stone-200 shadow-2xs space-y-6">
            <div className="border-b border-stone-200 pb-4 flex items-center justify-between">
              <div>
                <h3 className="text-base font-bold text-stone-900 flex items-center gap-2">
                  <Stethoscope className="w-5 h-5 text-indigo-700" />
                  <span>Primary Provider Fields</span>
                </h3>
                <p className="text-xs text-stone-500 mt-0.5">
                  Attending physician whose credentials automatically populate Providers & Users tables
                </p>
              </div>
              <span className="px-2.5 py-1 rounded-full text-[11px] font-bold bg-indigo-50 text-indigo-800 border border-indigo-200">
                Auto-Synced
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
              
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-stone-700">
                  Provider First Name <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required={practiceType !== 'ASC'}
                  value={primaryFirstName}
                  onChange={(e) => setPrimaryFirstName(e.target.value)}
                  placeholder="Stuart"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 focus:border-emerald-600 text-xs text-stone-900 outline-hidden bg-stone-50/50 focus:bg-white"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-bold text-stone-700">
                  Provider Last Name <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required={practiceType !== 'ASC'}
                  value={primaryLastName}
                  onChange={(e) => setPrimaryLastName(e.target.value)}
                  placeholder="Sterling"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 focus:border-emerald-600 text-xs text-stone-900 outline-hidden bg-stone-50/50 focus:bg-white"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-bold text-stone-700">
                  Degree <span className="text-rose-500">*</span>
                </label>
                <select
                  value={primaryDegree}
                  onChange={(e) => setPrimaryDegree(e.target.value as ProviderDegree)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 focus:border-emerald-600 text-xs text-stone-900 outline-hidden bg-stone-50/50 focus:bg-white"
                >
                  <option value="MD">MD (Doctor of Medicine)</option>
                  <option value="DO">DO (Doctor of Osteopathic Medicine)</option>
                  <option value="DPM">DPM (Podiatric Medicine)</option>
                  <option value="DMD">DMD (Dental Medicine)</option>
                  <option value="DDS">DDS (Dental Surgery)</option>
                  <option value="Other">Other Degree</option>
                </select>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-bold text-stone-700">
                  Cell Phone (for text notifications) <span className="text-rose-500">*</span>
                </label>
                <input
                  type="tel"
                  required={practiceType !== 'ASC'}
                  value={primaryCellPhone}
                  onChange={(e) => setPrimaryCellPhone(e.target.value)}
                  placeholder="(310) 859-2005"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 focus:border-emerald-600 text-xs text-stone-900 outline-hidden bg-stone-50/50 focus:bg-white"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-bold text-stone-700">
                  Email (for email notifications) <span className="text-rose-500">*</span>
                </label>
                <input
                  type="email"
                  required={practiceType !== 'ASC'}
                  value={primaryEmail}
                  onChange={(e) => setPrimaryEmail(e.target.value)}
                  placeholder="provider@example.org"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 focus:border-emerald-600 text-xs text-stone-900 outline-hidden bg-stone-50/50 focus:bg-white"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-bold text-stone-700">
                  National Provider Identifier (NPI)
                </label>
                <input
                  type="text"
                  value={primaryNpi}
                  onChange={(e) => setPrimaryNpi(e.target.value)}
                  placeholder="1827364910"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 focus:border-emerald-600 text-xs text-stone-900 outline-hidden bg-stone-50/50 focus:bg-white font-mono"
                />
              </div>

            </div>
          </div>

          {/* Calendar / Scheduler Settings Card */}
          <div className="bg-white p-6 sm:p-8 rounded-2xl border border-stone-200 shadow-2xs space-y-6">
            <div className="border-b border-stone-200 pb-4">
              <h3 className="text-base font-bold text-stone-900 flex items-center gap-2">
                <Calendar className="w-5 h-5 text-teal-700" />
                <span>Calendar & Scheduler Settings</span>
              </h3>
              <p className="text-xs text-stone-500 mt-0.5">
                Set facility operating hours and configure the rooms/suites displayed by the ASC scheduler
              </p>
            </div>

            {/* Operating Times */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-stone-700">
                  Calendar Start Time (Default: 7:00 AM) <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  value={calendarStartTime}
                  onChange={(e) => setCalendarStartTime(e.target.value)}
                  placeholder="07:00 AM"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 text-xs outline-hidden focus:border-emerald-600 font-mono"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-bold text-stone-700">
                  Calendar End Time (Default: 7:00 PM) <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  value={calendarEndTime}
                  onChange={(e) => setCalendarEndTime(e.target.value)}
                  placeholder="07:00 PM"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 text-xs outline-hidden focus:border-emerald-600 font-mono"
                />
              </div>
            </div>

            {/* Visit Types — retained for MED.Vityls, hidden in ASC.Vityls. */}
            <div className="hidden pt-4 border-t border-stone-100 space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-xs font-bold text-stone-800 uppercase tracking-wider">
                    Visit Types & Color Coding
                  </h4>
                  <p className="text-[11px] text-stone-500">
                    Default options include New Patient, Follow Up, Post-op, Pre-op, Consultation
                  </p>
                </div>

                <button
                  type="button"
                  onClick={() => setIsAddingVisitType(true)}
                  className="px-3 py-1.5 bg-stone-100 hover:bg-stone-200 text-stone-800 text-xs font-bold rounded-lg flex items-center gap-1 cursor-pointer transition-colors"
                >
                  <Plus className="w-3.5 h-3.5 text-stone-600" />
                  <span>Add Visit Type</span>
                </button>
              </div>

              {/* Add Visit Type Form Modal inline */}
              {isAddingVisitType && (
                <div className="p-4 bg-stone-50 rounded-xl border border-stone-300 space-y-3 animate-in fade-in">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-stone-800">New Visit Type</span>
                    <button type="button" onClick={() => setIsAddingVisitType(false)} className="text-stone-400 hover:text-stone-700 text-xs">✕</button>
                  </div>
                  <div className="flex flex-wrap items-center gap-3">
                    <input
                      type="text"
                      placeholder="Visit type name (e.g. Minor Procedure)"
                      value={newVisitTypeName}
                      onChange={(e) => setNewVisitTypeName(e.target.value)}
                      className="px-3 py-2 rounded-lg border border-stone-300 text-xs outline-hidden focus:border-emerald-600 bg-white min-w-[220px]"
                    />
                    <div className="flex items-center gap-2">
                      <span className="text-xs text-stone-600 font-medium">Color:</span>
                      <input
                        type="color"
                        value={newVisitTypeColor}
                        onChange={(e) => setNewVisitTypeColor(e.target.value)}
                        className="w-8 h-8 rounded-lg cursor-pointer border border-stone-300 p-0.5"
                      />
                    </div>
                    <button
                      type="button"
                      onClick={handleAddVisitType}
                      className="px-4 py-2 bg-emerald-700 text-white rounded-lg text-xs font-bold hover:bg-emerald-800 cursor-pointer"
                    >
                      Save Visit Type
                    </button>
                  </div>
                </div>
              )}

              {/* Visit Types List */}
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                {visitTypes.map((vt) => (
                  <div key={vt.id} className="p-3 bg-stone-50 rounded-xl border border-stone-200 flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2.5">
                      <div className="w-3.5 h-3.5 rounded-full shadow-2xs shrink-0" style={{ backgroundColor: vt.color }} />
                      <span className="text-xs font-bold text-stone-900">{vt.name}</span>
                    </div>
                    <button
                      type="button"
                      onClick={() => handleDeleteVisitType(vt.id)}
                      className="text-stone-400 hover:text-rose-600 p-1 transition-colors cursor-pointer"
                      title="Delete Visit Type"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            </div>

            <div className="pt-4 border-t border-stone-100 space-y-3">
            <div className="flex items-start justify-between gap-4 flex-wrap">

                <div><h4 className="text-xs font-bold text-stone-800 uppercase tracking-wider">Operating & Procedure Rooms</h4><p className="text-[11px] text-stone-500">Room names, active status, and display order flow directly to the Schedule page. Scheduler colors come from the assigned surgeon, not the room.</p></div>
                <button type="button" onClick={() => setIsAddingRoom(true)} className="px-3 py-1.5 bg-stone-100 hover:bg-stone-200 text-stone-800 text-xs font-bold rounded-lg flex items-center gap-1 cursor-pointer transition-colors"><Plus className="w-3.5 h-3.5 text-stone-600" /><span>Add Room</span></button>
              </div>
              {isAddingRoom && (<div className="p-4 bg-stone-50 rounded-xl border border-stone-300 space-y-3 animate-in fade-in"><div className="flex items-center justify-between"><span className="text-xs font-bold text-stone-800">New Operating / Procedure Room</span><button type="button" onClick={() => setIsAddingRoom(false)} className="text-stone-400 hover:text-stone-700 text-xs">✕</button></div><div className="flex flex-wrap items-center gap-3"><input type="text" placeholder="Room name (e.g. OR #3, GI Suite #1, LASER Room)" value={newRoomName} onChange={(e) => setNewRoomName(e.target.value)} className="px-3 py-2 rounded-lg border border-stone-300 text-xs outline-hidden focus:border-emerald-600 bg-white min-w-[260px]" /><button type="button" onClick={handleAddRoom} className="px-4 py-2 bg-teal-700 text-white rounded-lg text-xs font-bold hover:bg-teal-800 cursor-pointer">Save Room</button></div></div>)}
              <div className="space-y-2">
                {[...rooms].sort((a,b) => (a.sortOrder ?? 0) - (b.sortOrder ?? 0)).map((rm, index, orderedRooms) => (<div key={rm.id} className={`p-3 rounded-xl border flex flex-col sm:flex-row sm:items-center gap-3 ${rm.active === false ? 'bg-stone-100 border-stone-200 opacity-70' : 'bg-white border-stone-200'}`}><div className="flex items-center gap-2 shrink-0"><Building2 className="w-4 h-4 text-teal-700" /><span className="text-[10px] font-black text-stone-400 w-6">#{index + 1}</span></div><input aria-label={`Room name ${index + 1}`} value={rm.name} onChange={(e) => handleRenameRoom(rm.id, e.target.value)} className="flex-1 min-w-[180px] px-3 py-2 rounded-lg border border-stone-300 bg-white text-xs font-bold text-stone-900 focus:outline-none focus:ring-2 focus:ring-emerald-600/20 focus:border-emerald-600" placeholder="Room name" /><select value={rm.type || 'Procedure'} onChange={(e) => setRooms(prev => prev.map(room => room.id === rm.id ? { ...room, type: e.target.value as RoomSetting['type'] } : room))} className="px-2.5 py-2 rounded-lg border border-stone-300 bg-white text-xs font-semibold text-stone-700"><option value="OR">Operating Room</option><option value="Procedure">Procedure Room</option><option value="Consult">Consult Room</option><option value="Recovery">Recovery</option></select><label className="flex items-center gap-2 text-xs font-bold text-stone-700 whitespace-nowrap"><input type="checkbox" checked={rm.active !== false} onChange={() => handleToggleRoomActive(rm.id)} />Active</label><div className="flex items-center gap-1 shrink-0"><button type="button" disabled={index === 0} onClick={() => handleMoveRoom(rm.id, -1)} className="px-2 py-1.5 rounded-md border border-stone-200 bg-white text-xs font-bold disabled:opacity-30" title="Move room up">↑</button><button type="button" disabled={index === orderedRooms.length - 1} onClick={() => handleMoveRoom(rm.id, 1)} className="px-2 py-1.5 rounded-md border border-stone-200 bg-white text-xs font-bold disabled:opacity-30" title="Move room down">↓</button><button type="button" onClick={() => handleDeleteRoom(rm.id)} className="text-stone-400 hover:text-rose-600 p-2 transition-colors cursor-pointer" title="Delete Room"><Trash2 className="w-3.5 h-3.5" /></button></div></div>))}
              </div>
              <p className="text-[11px] text-stone-500">Each room retains a stable internal ID so renaming the display label does not break existing case assignments when Henry connects the database.</p>
            </div>

          </div>

          {/* Submit / Save Bar */}
          <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-2xs flex items-center justify-between">
            <div className="flex items-center gap-2 text-xs text-stone-600">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              <span>All mandatory fields configured will update practice-wide scheduling & provider rosters.</span>
            </div>

            <button
              type="submit"
              id="save-practice-config-btn"
              className="px-6 py-2.5 bg-gradient-to-r from-emerald-700 to-emerald-800 hover:from-emerald-800 hover:to-emerald-900 text-white text-xs font-bold rounded-xl shadow-md flex items-center gap-2 cursor-pointer transition-all"
            >
              <Save className="w-4 h-4 text-teal-300" />
              <span>Save Practice Configuration</span>
            </button>
          </div>

        </form>
      )}

      {/* ======================================================== */}
      {/* SECTION 2: PROVIDERS SECTION                             */}
      {/* ======================================================== */}
      {activeSection === 'providers' && (
        <div className="space-y-6">
          <div className="bg-gradient-to-r from-[#14432E] to-[#1F6E52] text-white p-6 rounded-2xl shadow-sm">
            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
              <div>
                <div className="text-[10px] uppercase tracking-[0.14em] font-black text-[#F4DFA7]">Provider credentialing</div>
                <h3 className="text-lg font-black mt-1 text-white">Invite surgeons to request membership & privileges</h3>
                <p className="text-xs text-white/80 mt-1 max-w-3xl">Vityls sends a secure request containing the online membership application. The surgeon can complete the application and upload license, DEA, malpractice insurance, board certification and other credentials from one portal.</p>
              </div>
              <div className="flex flex-wrap gap-2 shrink-0">
                <button type="button" onClick={()=>setCredentialPortalOpen(true)} className="px-4 py-2.5 rounded-xl bg-white/10 border border-white/20 text-white text-xs font-black flex items-center gap-2"><Eye className="w-4 h-4"/>Preview Surgeon Portal</button>
              </div>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-5 gap-2 mt-5 text-xs">
              {['1 Email application + account activation','2 Surgeon completes application','3 Upload & verify credentials','4 Medical Director reviews & approves privileges','5 Nightingale tracks renewals'].map(x=><div key={x} className="bg-white/10 border border-white/15 rounded-xl p-3 font-bold">{x}</div>)}
            </div>
          </div>

          {credentialRequests.length > 0 && <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-2xs">
            <h3 className="text-sm font-black text-stone-900">Credentialing Requests</h3>
            <div className="mt-3 divide-y divide-stone-100">{credentialRequests.map(r=><div key={r.id} className="py-3 flex flex-wrap items-center justify-between gap-3"><div><div className="text-xs font-bold text-stone-900">{r.name}</div><div className="text-[11px] text-stone-500">{r.email} • {r.sentAt}</div></div><div className="flex items-center gap-2"><span className="px-2.5 py-1 rounded-full bg-amber-50 border border-amber-200 text-amber-800 text-[10px] font-bold">{r.status}</span>{r.status === 'Application Pending' && <button type="button" onClick={()=>{setCredentialRequests(prev=>prev.map(x=>x.id===r.id?{...x,status:'Pending Medical Director Review'}:x)); if(r.providerId) setAdditionalProviders(prev=>prev.map(p=>p.id===r.providerId?{...p,credentialStatus:'Pending Medical Director Review'}:p)); onShowToast?.('Application and credentials verified; routed to the Medical Director for privileges review.');}} className="px-2.5 py-1 rounded-lg bg-stone-100 text-stone-700 text-[10px] font-bold">Verify & Route to Medical Director</button>}{r.status === 'Pending Medical Director Review' && <button type="button" onClick={()=>{setCredentialRequests(prev=>prev.map(x=>x.id===r.id?{...x,status:'Privileges Approved'}:x)); if(r.providerId) setAdditionalProviders(prev=>prev.map(p=>p.id===r.providerId?{...p,credentialStatus:'Privileges Approved'}:p)); onShowToast?.('Medical Director approved surgeon privileges.');}} className="px-2.5 py-1 rounded-lg bg-emerald-700 text-white text-[10px] font-bold">Medical Director Approve</button>}</div></div>)}</div>
          </div>}

          <div className="bg-white p-6 sm:p-8 rounded-2xl border border-stone-200 shadow-2xs space-y-5">
            
            {/* Header & + Add New Provider Button */}
            <div className="flex flex-wrap items-center justify-between gap-4 border-b border-stone-200 pb-4">
              <div>
                <h3 className="text-base font-bold text-stone-900 flex items-center gap-2">
                  <Stethoscope className="w-5 h-5 text-emerald-700" />
                  <span>Medical & Surgical Providers</span>
                </h3>
                <p className="text-xs text-stone-500 mt-0.5">
                  Manage surgeons, Medical Director designation, specialties, credentialing status, NPI numbers, and scheduler color assignments.
                </p>
              </div>

              <button
                type="button"
                onClick={handleOpenAddProvider}
                id="add-new-provider-btn"
                className="px-4 py-2 bg-gradient-to-r from-emerald-700 to-emerald-800 hover:from-emerald-800 hover:to-emerald-900 text-white text-xs font-bold rounded-xl shadow-xs flex items-center gap-1.5 cursor-pointer transition-all"
              >
                <Plus className="w-4 h-4 text-teal-300" />
                <span>+ Add Provider & Send Invitation</span>
              </button>
            </div>

            {/* Providers Table */}
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-stone-200 bg-stone-50 text-stone-600 font-bold uppercase tracking-wider text-[10px]">
                    <th className="py-3 px-4">Provider Name</th>
                    <th className="py-3 px-4">Specialty</th>
                    <th className="py-3 px-4">Email</th>
                    <th className="py-3 px-4">Scheduler Color Code</th>
                    <th className="py-3 px-4">Status</th>
                    <th className="py-3 px-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-100">
                  {fullProvidersList.map((p) => (
                    <tr key={p.id} className="hover:bg-stone-50/80 transition-colors">
                      
                      {/* Name & Degree */}
                      <td className="py-3.5 px-4 font-bold text-stone-900">
                        <div className="flex items-center gap-2">
                          <span>{p.name}{p.degree ? `, ${p.degree}` : ''}</span>
                          {p.isPrimary && (
                            <span className="px-2 py-0.5 rounded-full text-[9px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
                              Medical Director
                            </span>
                          )}
                        </div>
                        {p.npi && <div className="text-[10px] text-stone-400 font-mono font-normal">NPI: {p.npi}</div>}
                      </td>

                      {/* Specialty */}
                      <td className="py-3.5 px-4 text-stone-700 font-medium">
                        {p.specialty}
                      </td>

                      {/* Email */}
                      <td className="py-3.5 px-4 text-stone-600">
                        <a href={`mailto:${p.email}`} className="text-emerald-700 hover:underline">
                          {p.email}
                        </a>
                      </td>

                      {/* Scheduler Color Code */}
                      <td className="py-3.5 px-4">
                        <div className="flex items-center gap-2">
                          <div 
                            className="w-4 h-4 rounded-full shadow-2xs border border-stone-300" 
                            style={{ backgroundColor: p.colorCode }} 
                          />
                          <span className="text-[11px] font-mono text-stone-600 font-semibold">{p.colorCode}</span>
                        </div>
                      </td>

                      {/* Credentialing / access status */}
                      <td className="py-3.5 px-4">
                        <span className={`px-2.5 py-1 rounded-full border text-[10px] font-bold ${p.credentialStatus === 'Privileges Approved' || p.credentialStatus === 'Active' ? 'bg-emerald-50 border-emerald-200 text-emerald-800' : p.credentialStatus === 'Pending Medical Director Review' ? 'bg-violet-50 border-violet-200 text-violet-800' : 'bg-amber-50 border-amber-200 text-amber-800'}`}>{p.isPrimary ? 'Active · Medical Director' : (p.credentialStatus || 'Invitation Pending')}</span>
                      </td>

                      {/* Action Buttons */}
                      <td className="py-3.5 px-4 text-right space-x-1.5">
                        <button
                          type="button"
                          onClick={() => openCredentialInvite(p)}
                          className="px-2.5 py-1 rounded-lg bg-emerald-50 hover:bg-emerald-100 text-emerald-800 font-semibold text-xs transition-colors cursor-pointer inline-flex items-center gap-1"
                        >
                          <Mail className="w-3 h-3" />
                          <span>{p.credentialStatus === 'Invitation Pending' || p.credentialStatus === 'Application Pending' ? 'Resend Invitation' : 'Request Privileges'}</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => handleOpenEditProvider(p)}
                          className="px-2.5 py-1 rounded-lg bg-stone-100 hover:bg-stone-200 text-stone-700 font-semibold text-xs transition-colors cursor-pointer inline-flex items-center gap-1"
                        >
                          <Edit3 className="w-3 h-3 text-stone-600" />
                          <span>Modify</span>
                        </button>

                        {!p.isPrimary && (
                          <button
                            type="button"
                            onClick={() => handleDeleteProvider(p.id)}
                            className="p-1 text-stone-400 hover:text-rose-600 transition-colors cursor-pointer inline-flex items-center"
                            title="Delete Provider"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </td>

                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* SECTION 3: USERS SECTION                                 */}
      {/* ======================================================== */}
      {activeSection === 'users' && (
        <div className="space-y-6">
          <div className="bg-white p-6 sm:p-8 rounded-2xl border border-stone-200 shadow-2xs space-y-5">
            
            {/* Header & + Add New User Button */}
            <div className="flex flex-wrap items-center justify-between gap-4 border-b border-stone-200 pb-4">
              <div>
                <h3 className="text-base font-bold text-stone-900 flex items-center gap-2">
                  <Users className="w-5 h-5 text-indigo-700" />
                  <span>Practice Users & Staff Roles</span>
                </h3>
                <p className="text-xs text-stone-500 mt-0.5">
                  Medical Director is included as a role-based user. Manage nurse, medical assistant, front office, and administrative accounts.
                </p>
              </div>

              <button
                type="button"
                onClick={handleOpenAddUser}
                id="add-new-user-btn"
                className="px-4 py-2 bg-gradient-to-r from-emerald-700 to-slate-900 hover:from-emerald-800 hover:to-slate-950 text-white text-xs font-bold rounded-xl shadow-xs flex items-center gap-1.5 cursor-pointer transition-all"
              >
                <Plus className="w-4 h-4 text-teal-300" />
                <span>+ Add New User</span>
              </button>
            </div>

            {/* Users Table */}
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-stone-200 bg-stone-50 text-stone-600 font-bold uppercase tracking-wider text-[10px]">
                    <th className="py-3 px-4">User Name</th>
                    <th className="py-3 px-4">Title / Role</th>
                    <th className="py-3 px-4">Email</th>
                    <th className="py-3 px-4">Cell Phone</th>
                    <th className="py-3 px-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-100">
                  {fullUsersList.map((u) => (
                    <tr key={u.id} className="hover:bg-stone-50/80 transition-colors">
                      
                      {/* User Name */}
                      <td className="py-3.5 px-4 font-bold text-stone-900">
                        <div className="flex items-center gap-2">
                          <span>{u.name}</span>
                          {u.isPrimary && (
                            <span className="px-2 py-0.5 rounded-full text-[9px] font-bold bg-indigo-100 text-indigo-800 border border-indigo-200">
                              Primary User
                            </span>
                          )}
                        </div>
                      </td>

                      {/* Title */}
                      <td className="py-3.5 px-4">
                        <span className="px-2.5 py-1 rounded-full text-[11px] font-semibold bg-stone-100 text-stone-800 border border-stone-200">
                          {u.title}
                        </span>
                      </td>

                      {/* Email */}
                      <td className="py-3.5 px-4 text-stone-600">
                        <a href={`mailto:${u.email}`} className="text-emerald-700 hover:underline">
                          {u.email}
                        </a>
                      </td>

                      {/* Cell Phone */}
                      <td className="py-3.5 px-4 text-stone-600 font-mono text-[11px]">
                        {u.cellPhone || 'N/A'}
                      </td>

                      {/* Actions */}
                      <td className="py-3.5 px-4 text-right space-x-1.5">
                        <button
                          type="button"
                          onClick={() => handleOpenEditUser(u)}
                          className="px-2.5 py-1 rounded-lg bg-stone-100 hover:bg-stone-200 text-stone-700 font-semibold text-xs transition-colors cursor-pointer inline-flex items-center gap-1"
                        >
                          <Edit3 className="w-3 h-3 text-stone-600" />
                          <span>Modify</span>
                        </button>

                        {!u.isPrimary && (
                          <button
                            type="button"
                            onClick={() => handleDeleteUser(u.id)}
                            className="p-1 text-stone-400 hover:text-rose-600 transition-colors cursor-pointer inline-flex items-center"
                            title="Delete User"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </td>

                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* SECTION 4: E-PRESCRIBE SETUP SECTION                     */}
      {/* ======================================================== */}
      {activeSection === 'eprescribe' && (
        <div className="space-y-6">
          <div className="bg-white p-6 sm:p-8 rounded-2xl border border-stone-200 shadow-2xs space-y-6">
            
            <div className="border-b border-stone-200 pb-4 flex flex-wrap items-center justify-between gap-4">
              <div>
                <h3 className="text-base font-bold text-stone-900 flex items-center gap-2">
                  <Pill className="w-5 h-5 text-emerald-700" />
                  <span>E-Prescribe Setup & EPCS Electronic Prescribing</span>
                </h3>
                <p className="text-xs text-stone-500 mt-0.5">
                  Configure digital prescription routing, Surescripts connectivity, and DEA controlled substance token verification.
                </p>
              </div>

              <span className="px-3 py-1 rounded-full text-xs font-bold bg-amber-100 text-amber-900 border border-amber-300 flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-amber-700" />
                <span>Configuration Details Pending</span>
              </span>
            </div>

            {/* Pending Notice Callout */}
            <div className="p-4 rounded-xl bg-emerald-50/70 border border-emerald-200 text-emerald-900 text-xs flex items-start gap-3">
              <Info className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <div className="space-y-1">
                <div className="font-bold">E-Prescribe Configuration Instructions</div>
                <p className="text-stone-600 leading-relaxed">
                  The exact production API keys and certified identity proofing credentials will be provisioned during final Surescripts network onboarding. You can update placeholder details below in preparation for go-live.
                </p>
              </div>
            </div>

            {/* Form with Editable Placeholder Fields */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-stone-700">
                  Surescripts Account ID / Network Service ID
                </label>
                <input
                  type="text"
                  value={ePrescribeData.surescriptsId}
                  onChange={(e) => setEPrescribeData({ ...ePrescribeData, surescriptsId: e.target.value })}
                  placeholder="e.g. SUR-981723-CA"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 text-xs text-stone-900 font-mono outline-hidden focus:border-emerald-600 bg-stone-50/50"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-bold text-stone-700">
                  DEA Registration Number
                </label>
                <input
                  type="text"
                  value={ePrescribeData.deaNumber}
                  onChange={(e) => setEPrescribeData({ ...ePrescribeData, deaNumber: e.target.value })}
                  placeholder="e.g. BL-9827361"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 text-xs text-stone-900 font-mono outline-hidden focus:border-emerald-600 bg-stone-50/50"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-bold text-stone-700">
                  EPCS 2-Factor Hard Token / Device Serial
                </label>
                <input
                  type="text"
                  value={ePrescribeData.epcsTokenSerial}
                  onChange={(e) => setEPrescribeData({ ...ePrescribeData, epcsTokenSerial: e.target.value })}
                  placeholder="e.g. HYP-2026-FIPS-0918"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 text-xs text-stone-900 font-mono outline-hidden focus:border-emerald-600 bg-stone-50/50"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-bold text-stone-700">
                  SPI / NCPDP Provider Identifier
                </label>
                <input
                  type="text"
                  value={ePrescribeData.spiNumber}
                  onChange={(e) => setEPrescribeData({ ...ePrescribeData, spiNumber: e.target.value })}
                  placeholder="e.g. 1092837465"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 text-xs text-stone-900 font-mono outline-hidden focus:border-emerald-600 bg-stone-50/50"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-bold text-stone-700">
                  State Controlled Substance License
                </label>
                <input
                  type="text"
                  value={ePrescribeData.stateLicense}
                  onChange={(e) => setEPrescribeData({ ...ePrescribeData, stateLicense: e.target.value })}
                  placeholder="e.g. CA-C52918"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 text-xs text-stone-900 font-mono outline-hidden focus:border-emerald-600 bg-stone-50/50"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-bold text-stone-700">
                  Default Pharmacy Routing Network
                </label>
                <input
                  type="text"
                  value={ePrescribeData.defaultPharmacyNetwork}
                  onChange={(e) => setEPrescribeData({ ...ePrescribeData, defaultPharmacyNetwork: e.target.value })}
                  placeholder="Surescripts National Network"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 text-xs text-stone-900 outline-hidden focus:border-emerald-600 bg-stone-50/50"
                />
              </div>

            </div>

            <div className="pt-4 border-t border-stone-100 flex items-center justify-between">
              <span className="text-xs text-stone-500 font-medium">
                EPCS Two-Factor Authentication Status: <strong className="text-emerald-700">Enabled</strong>
              </span>
              <button
                type="button"
                onClick={() => {
                  if (onShowToast) onShowToast('E-Prescribe placeholder configuration saved.');
                }}
                className="px-5 py-2.5 bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold rounded-xl cursor-pointer"
              >
                Save E-Prescribe Details
              </button>
            </div>

          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* SECTION 5: CREDIT CARD PROCESSING SETUP SECTION          */}
      {/* ======================================================== */}
      {activeSection === 'creditcard' && (
        <div className="space-y-6">
          <div className="bg-white p-6 sm:p-8 rounded-2xl border border-stone-200 shadow-2xs space-y-6">
            
            <div className="border-b border-stone-200 pb-4 flex flex-wrap items-center justify-between gap-4">
              <div>
                <h3 className="text-base font-bold text-stone-900 flex items-center gap-2">
                  <CreditCard className="w-5 h-5 text-amber-700" />
                  <span>Credit Card Processing & Payment Gateway Setup</span>
                </h3>
                <p className="text-xs text-stone-500 mt-0.5">
                  Configure merchant gateway, point-of-sale card terminals, HSA/FSA eligibility, and automated patient receipts.
                </p>
              </div>

              <span className="px-3 py-1 rounded-full text-xs font-bold bg-amber-100 text-amber-900 border border-amber-300 flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-amber-700" />
                <span>Configuration Details Pending</span>
              </span>
            </div>

            {/* Pending Notice Callout */}
            <div className="p-4 rounded-xl bg-amber-50/70 border border-amber-200 text-amber-900 text-xs flex items-start gap-3">
              <Info className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
              <div className="space-y-1">
                <div className="font-bold">Merchant Account Onboarding Status</div>
                <p className="text-stone-600 leading-relaxed">
                  Final merchant account keys and physical terminal pairing will activate upon completion of PCI-DSS compliance verification. Update your current merchant parameters below.
                </p>
              </div>
            </div>

            {/* Form with Editable Placeholder Fields */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-stone-700">
                  Merchant Account ID (MID)
                </label>
                <input
                  type="text"
                  value={creditCardData.merchantAccountId}
                  onChange={(e) => setCreditCardData({ ...creditCardData, merchantAccountId: e.target.value })}
                  placeholder="e.g. MID-7829-4820-MED"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 text-xs text-stone-900 font-mono outline-hidden focus:border-emerald-600 bg-stone-50/50"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-bold text-stone-700">
                  Payment Gateway Provider
                </label>
                <select
                  value={creditCardData.gatewayProvider}
                  onChange={(e) => setCreditCardData({ ...creditCardData, gatewayProvider: e.target.value as any })}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 text-xs text-stone-900 outline-hidden focus:border-emerald-600 bg-stone-50/50"
                >
                  <option value="Stripe Healthcare">Stripe Healthcare (Custom Medical API)</option>
                  <option value="CardConnect Point-to-Point">CardConnect Point-to-Point Encryption</option>
                  <option value="TSYS Healthcare">TSYS Healthcare Merchant Solutions</option>
                  <option value="Clover Medical">Clover Medical POS</option>
                  <option value="Other">Other Gateway</option>
                </select>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-bold text-stone-700">
                  Physical POS Terminal IP / Serial Number
                </label>
                <input
                  type="text"
                  value={creditCardData.terminalIpOrSerial}
                  onChange={(e) => setCreditCardData({ ...creditCardData, terminalIpOrSerial: e.target.value })}
                  placeholder="192.168.1.145 (Verifone P400)"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 text-xs text-stone-900 font-mono outline-hidden focus:border-emerald-600 bg-stone-50/50"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-bold text-stone-700">
                  Patient Automated Receipt Delivery
                </label>
                <select
                  value={creditCardData.autoReceiptMode}
                  onChange={(e) => setCreditCardData({ ...creditCardData, autoReceiptMode: e.target.value as any })}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 text-xs text-stone-900 outline-hidden focus:border-emerald-600 bg-stone-50/50"
                >
                  <option value="Email & SMS">Automated Email & SMS Receipts</option>
                  <option value="Email Only">Email Only</option>
                  <option value="SMS Only">SMS Only</option>
                  <option value="Manual Print">Manual Paper Print Only</option>
                </select>
              </div>

            </div>

            <div className="pt-4 border-t border-stone-100 flex items-center justify-between">
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={creditCardData.hsaFsaAccepted}
                  onChange={(e) => setCreditCardData({ ...creditCardData, hsaFsaAccepted: e.target.checked })}
                  className="w-4 h-4 rounded-sm border-stone-300 text-amber-600 focus:ring-amber-500"
                />
                <span className="text-xs text-stone-700 font-semibold">Accept Health Savings Account (HSA) & Flexible Spending Account (FSA) Cards</span>
              </label>

              <button
                type="button"
                onClick={() => {
                  if (onShowToast) onShowToast('Credit Card Processing setup parameters saved.');
                }}
                className="px-5 py-2.5 bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold rounded-xl cursor-pointer"
              >
                Save Gateway Details
              </button>
            </div>

          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* SECTION 6: DOCUMENTS & ACCREDITATION REPOSITORY          */}
      {/* ======================================================== */}
      {activeSection === 'documents' && (
        <div className="space-y-6">
          <div className="bg-gradient-to-r from-[#14432E] to-[#1F6E52] text-white p-6 rounded-2xl shadow-sm">
            <div className="flex items-start gap-3"><Sparkles className="w-5 h-5 text-amber-300 mt-0.5"/><div><h3 className="font-bold text-base">How Vityls manages compliance documents</h3><p className="text-xs text-white/85 mt-1 leading-relaxed">Upload individual documents or a complete scanned credentialing file. Nightingale can identify document type, provider, license or certificate number, issuing authority, issue date and expiration date, then place each item in the appropriate category for administrator review.</p></div></div>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-2 mt-5 text-xs">
              {['1 Upload','2 Nightingale identifies','3 Administrator confirms','4 Track renewals & history'].map(x=><div key={x} className="bg-white/10 border border-white/15 rounded-xl p-3 font-bold">{x}</div>)}
            </div>
          </div>
          <div className="bg-white border border-stone-200 rounded-2xl p-5 shadow-2xs">
            <h3 className="text-sm font-bold text-stone-900">Provider credential file categories</h3>
            <p className="text-xs text-stone-500 mt-1">Each category keeps one clearly marked current document plus prior versions in secure history. Replacing one item never deletes the original uploaded PDF or other extracted components.</p>
            <div className="flex flex-wrap gap-2 mt-4">{['Membership Application','Medical License','DEA Registration','NPI','Malpractice Certificate','Board Certification','Privileges','Other Required Records'].map(x=><span key={x} className="px-3 py-1.5 rounded-full bg-[#F1F3EC] border border-[#DCE3DD] text-xs font-semibold text-[#425149]">{x}</span>)}</div>
          </div>
          
          {/* Document Categories Bar */}
          <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-2xs space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-4">
              <div>
                <h3 className="text-base font-bold text-stone-900 flex items-center gap-2">
                  <FileCheck className="w-5 h-5 text-purple-700" />
                  <span>Facility Accreditation, Credentials & Document Repositories</span>
                </h3>
                <p className="text-xs text-stone-500">
                  AAAASF, CLIA, OSHA, Joint Commission, and California Department of Public Health regulatory binders
                </p>
              </div>

              {/* Upload Action */}
              <label className="px-4 py-2 bg-purple-700 hover:bg-purple-800 text-white text-xs font-bold rounded-xl shadow-xs flex items-center gap-1.5 cursor-pointer transition-all">
                <UploadCloud className="w-4 h-4" />
                <span>Upload New Compliance File</span>
                <input type="file" onChange={handleFileUploadSim} className="hidden" />
              </label>
            </div>

            {/* Doc Tabs */}
            <div className="flex flex-wrap items-center gap-1.5 pt-2 border-t border-stone-100">
              {Object.keys(sampleCategoryFiles).map((tabName) => (
                <button
                  key={tabName}
                  onClick={() => setActiveDocTab(tabName as any)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                    activeDocTab === tabName
                      ? 'bg-purple-900 text-white shadow-2xs'
                      : 'text-stone-600 hover:text-stone-900 hover:bg-stone-100'
                  }`}
                >
                  {tabName}
                </button>
              ))}
            </div>
          </div>

          {/* Active Category Content */}
          <div className="bg-white p-6 rounded-2xl border border-stone-200 shadow-2xs space-y-4">
            
            {/* AI Summary Banner */}
            <div className="p-4 rounded-xl bg-purple-50/70 border border-purple-200 text-purple-950 text-xs flex items-start gap-3">
              <Sparkles className="w-4 h-4 text-purple-600 shrink-0 mt-0.5" />
              <div>
                <div className="font-bold">{activeDocTab} AI Governance Audit</div>
                <p className="text-stone-600 mt-0.5 leading-relaxed">{currentTabContent.aiSummary}</p>
              </div>
            </div>

            {/* Search Files */}
            <div className="relative">
              <Search className="w-4 h-4 text-stone-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder={`Search ${activeDocTab} repository files...`}
                value={docSearchQuery}
                onChange={(e) => setDocSearchQuery(e.target.value)}
                className="w-full pl-9 pr-4 py-2 rounded-xl border border-stone-200 text-xs outline-hidden focus:border-purple-600"
              />
            </div>

            {/* Files List */}
            <div className="divide-y divide-stone-100">
              {filteredFiles.map((file) => (
                <div key={file.id} className="py-3 flex flex-wrap items-center justify-between gap-3 hover:bg-stone-50/50 p-2 rounded-xl transition-colors">
                  <div className="flex items-center gap-3">
                    <div className="p-2 rounded-lg bg-stone-100 text-stone-700">
                      <FileText className="w-4 h-4 text-purple-700" />
                    </div>
                    <div>
                      <div className="text-xs font-bold text-stone-900">{file.title}</div>
                      <div className="text-[10px] text-stone-400">
                        {file.type} • Uploaded by {file.uploader} on {file.date} ({file.size})
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800">
                      {file.status}
                    </span>
                    <button
                      type="button"
                      onClick={() => {
                        if (onShowToast) onShowToast(`Downloading ${file.title}...`);
                      }}
                      className="px-2.5 py-1 bg-stone-100 hover:bg-stone-200 text-stone-800 text-xs font-semibold rounded-lg flex items-center gap-1 cursor-pointer"
                    >
                      <Download className="w-3 h-3" />
                      <span>Download</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>

          </div>

        </div>
      )}

      {/* ======================================================== */}
      {/* SECTION 7: EMR INTEGRATIONS                              */}
      {/* ======================================================== */}
      {activeSection === 'integrations' && (
        <div className="bg-white p-6 sm:p-8 rounded-2xl border border-stone-200 shadow-2xs space-y-6">
          <div className="border-b border-stone-200 pb-4">
            <h3 className="text-base font-bold text-stone-900 flex items-center gap-2">
              <Server className="w-5 h-5 text-cyan-700" />
              <span>EMR System Integrations & Health Information Exchange</span>
            </h3>
            <p className="text-xs text-stone-500 mt-0.5">
              Live bidirectional connectivity with national lab networks, e-prescribe gateways, and electronic clearinghouses.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            
            <div className="p-4 rounded-xl border border-stone-200 bg-stone-50/60 flex items-center justify-between">
              <div>
                <div className="text-xs font-bold text-stone-900">e-Prescribing gateway (not connected)</div>
                <div className="text-[11px] text-stone-500">Test build: prescriptions are simulated and nothing is sent to a pharmacy</div>
              </div>
              <button
                type="button"
                onClick={() => toggleIntegration('eRx')}
                className={`px-3 py-1 rounded-full text-xs font-bold transition-all cursor-pointer ${
                  integrations.eRx ? 'bg-emerald-600 text-white' : 'bg-stone-200 text-stone-600'
                }`}
              >
                {integrations.eRx ? 'Connected' : 'Disabled'}
              </button>
            </div>

            <div className="p-4 rounded-xl border border-stone-200 bg-stone-50/60 flex items-center justify-between">
              <div>
                <div className="text-xs font-bold text-stone-900">Quest Diagnostics & LabCorp Bi-Directional Feed</div>
                <div className="text-[11px] text-stone-500">Automated lab orders & electronic result ingestion</div>
              </div>
              <button
                type="button"
                onClick={() => toggleIntegration('questLabs')}
                className={`px-3 py-1 rounded-full text-xs font-bold transition-all cursor-pointer ${
                  integrations.questLabs ? 'bg-emerald-600 text-white' : 'bg-stone-200 text-stone-600'
                }`}
              >
                {integrations.questLabs ? 'Connected' : 'Disabled'}
              </button>
            </div>

            <div className="p-4 rounded-xl border border-stone-200 bg-stone-50/60 flex items-center justify-between">
              <div>
                <div className="text-xs font-bold text-stone-900">EDI 837 / 835 Billing Clearinghouse (Change Healthcare)</div>
                <div className="text-[11px] text-stone-500">Automated electronic claims submission & ERA remittance</div>
              </div>
              <button
                type="button"
                onClick={() => toggleIntegration('billingEdi')}
                className={`px-3 py-1 rounded-full text-xs font-bold transition-all cursor-pointer ${
                  integrations.billingEdi ? 'bg-emerald-600 text-white' : 'bg-stone-200 text-stone-600'
                }`}
              >
                {integrations.billingEdi ? 'Connected' : 'Disabled'}
              </button>
            </div>

            <div className="p-4 rounded-xl border border-stone-200 bg-stone-50/60 flex items-center justify-between">
              <div>
                <div className="text-xs font-bold text-stone-900">Twilio HIPAA-Compliant SMS Gateway</div>
                <div className="text-[11px] text-stone-500">Encrypted arrival alerts & pre-op NPO text reminders</div>
              </div>
              <button
                type="button"
                onClick={() => toggleIntegration('patientSms')}
                className={`px-3 py-1 rounded-full text-xs font-bold transition-all cursor-pointer ${
                  integrations.patientSms ? 'bg-emerald-600 text-white' : 'bg-stone-200 text-stone-600'
                }`}
              >
                {integrations.patientSms ? 'Connected' : 'Disabled'}
              </button>
            </div>

          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* SECTION 8: PATIENT INTAKE & CLINICAL FORMS               */}
      {/* ======================================================== */}
      {activeSection === 'form-studio' && (
        <FormsWorkspacePage onBack={() => setActiveSection('home')} onShowToast={onShowToast} activePracticeId={activePracticeId} />
      )}

      {activeSection === 'intake-forms' && (
        <div id="intake-forms-management-section" className="space-y-6">
          
          {/* Top Banner & Quick Controls */}
          <div className="bg-white p-6 rounded-2xl border border-stone-200 shadow-2xs space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-4">
              <div>
                <div className="flex items-center gap-2">
                  <div className="p-2 rounded-xl bg-emerald-600 text-white shadow-2xs">
                    <FileText className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-base font-bold text-stone-900">
                      Patient Intake & Registration Forms Repository
                    </h3>
                    <p className="text-xs text-stone-500 mt-0.5">
                      Upload, configure, preview, and deploy patient onboarding questionnaires, medical history binders, consents, and financial agreements.
                    </p>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2.5">
                <button
                  type="button"
                  onClick={() => {
                    setIsUploadPanelOpen(!isUploadPanelOpen);
                    if (!isUploadPanelOpen && onShowToast) onShowToast('Opened Intake Form Upload panel.');
                  }}
                  id="admin-upload-intake-form-btn"
                  className="px-4 py-2 bg-gradient-to-r from-emerald-600 to-teal-700 hover:from-emerald-700 hover:to-teal-800 text-white text-xs font-bold rounded-xl shadow-xs flex items-center gap-1.5 transition-all cursor-pointer"
                >
                  <FileUp className="w-4 h-4" />
                  <span>{isUploadPanelOpen ? 'Close Upload Form' : '+ Upload New Intake Form'}</span>
                </button>
              </div>
            </div>

            {/* Quick Metrics Strip */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2 border-t border-stone-100">
              <div className="p-3 rounded-xl bg-stone-50 border border-stone-200/80 flex items-center justify-between">
                <div>
                  <div className="text-[11px] font-semibold text-stone-500">Total Active Forms</div>
                  <div className="text-lg font-black text-stone-900">{intakeFormsList.length}</div>
                </div>
                <div className="p-2 rounded-lg bg-emerald-100/80 text-emerald-700">
                  <FileSpreadsheet className="w-4 h-4" />
                </div>
              </div>

              <div className="p-3 rounded-xl bg-stone-50 border border-stone-200/80 flex items-center justify-between">
                <div>
                  <div className="text-[11px] font-semibold text-stone-500">Check-In Mandatory</div>
                  <div className="text-lg font-black text-emerald-700">
                    {intakeFormsList.filter(f => f.isMandatory).length}
                  </div>
                </div>
                <div className="p-2 rounded-lg bg-emerald-100/80 text-emerald-700">
                  <CheckSquare className="w-4 h-4" />
                </div>
              </div>

              <div className="p-3 rounded-xl bg-stone-50 border border-stone-200/80 flex items-center justify-between">
                <div>
                  <div className="text-[11px] font-semibold text-stone-500">E-Signature Enabled</div>
                  <div className="text-lg font-black text-indigo-700">
                    {intakeFormsList.filter(f => f.signatureRequired).length}
                  </div>
                </div>
                <div className="p-2 rounded-lg bg-indigo-100/80 text-indigo-700">
                  <ShieldCheck className="w-4 h-4" />
                </div>
              </div>

              <div className="p-3 rounded-xl bg-stone-50 border border-stone-200/80 flex items-center justify-between">
                <div>
                  <div className="text-[11px] font-semibold text-stone-500">Patient Portal Sync</div>
                  <div className="text-xs font-bold text-emerald-700 flex items-center gap-1 mt-1">
                    <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                    <span>Active & Live</span>
                  </div>
                </div>
                <div className="p-2 rounded-lg bg-teal-100/80 text-teal-700">
                  <Sparkles className="w-4 h-4" />
                </div>
              </div>
            </div>
          </div>

          {/* Collapsible Upload Form Section */}
          {isUploadPanelOpen && (
            <div className="bg-white p-6 sm:p-8 rounded-2xl border-2 border-emerald-500/30 shadow-md space-y-6 animate-in fade-in zoom-in-98 duration-200">
              <div className="flex items-center justify-between border-b border-stone-200 pb-4">
                <div className="flex items-center gap-2.5">
                  <div className="p-2 rounded-xl bg-emerald-50 text-emerald-700">
                    <FileUp className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-stone-900">Upload & Publish New Intake Form</h4>
                    <p className="text-xs text-stone-500">
                      Upload PDF or DOCX forms to automatically deploy to the Patient Portal check-in kiosk
                    </p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setIsUploadPanelOpen(false)}
                  className="p-1 rounded-lg text-stone-400 hover:text-stone-700 hover:bg-stone-100 cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <form onSubmit={handleCreateIntakeForm} className="space-y-5">
                
                {/* Drag and Drop Zone */}
                <div className="p-6 border-2 border-dashed border-stone-300 hover:border-emerald-500 rounded-2xl bg-stone-50/50 hover:bg-emerald-50/30 transition-all text-center space-y-3">
                  <input
                    type="file"
                    id="intake-file-upload-input"
                    accept=".pdf,.docx,.doc,.png,.jpg,.jpeg"
                    onChange={handleIntakeFileSelect}
                    className="hidden"
                  />
                  <label htmlFor="intake-file-upload-input" className="cursor-pointer block space-y-2">
                    <div className="w-12 h-12 rounded-2xl bg-emerald-100 text-emerald-700 flex items-center justify-center mx-auto shadow-2xs">
                      <UploadCloud className="w-6 h-6" />
                    </div>
                    {selectedFileObj ? (
                      <div className="space-y-1">
                        <div className="text-xs font-bold text-emerald-800 flex items-center justify-center gap-1.5">
                          <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                          <span>Selected: {selectedFileObj.name}</span>
                        </div>
                        <p className="text-[11px] text-stone-500">
                          {(selectedFileObj.size / (1024 * 1024)).toFixed(2)} MB · Click to choose a different file
                        </p>
                      </div>
                    ) : (
                      <div className="space-y-1">
                        <p className="text-xs font-bold text-stone-800">
                          Click to browse files or drag and drop intake document
                        </p>
                        <p className="text-[11px] text-stone-500">
                          Supports PDF, DOCX, DOC files up to 50 MB
                        </p>
                      </div>
                    )}
                  </label>
                </div>

                {/* Form Details Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  
                  {/* Form Title */}
                  <div className="space-y-1 md:col-span-2">
                    <label className="text-xs font-bold text-stone-700">
                      Form Title / Name <span className="text-rose-500">*</span>
                    </label>
                    <input
                      type="text"
                      required
                      value={uploadFormTitle}
                      onChange={(e) => setUploadFormTitle(e.target.value)}
                      placeholder="e.g. Comprehensive Cosmetic & Facial Plastic Health Intake"
                      className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 focus:border-emerald-600 text-xs text-stone-900 outline-hidden bg-white"
                    />
                  </div>

                  {/* Category */}
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-stone-700">
                      Intake Category <span className="text-rose-500">*</span>
                    </label>
                    <select
                      value={uploadFormCategory}
                      onChange={(e) => setUploadFormCategory(e.target.value as any)}
                      className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 focus:border-emerald-600 text-xs text-stone-900 outline-hidden bg-white"
                    >
                      <option value="Registration & Demographics">Registration & Demographics</option>
                      <option value="Medical & Surgical History">Medical & Surgical History</option>
                      <option value="Consents & Agreements">Consents & Agreements</option>
                      <option value="Financial & HIPAA">Financial & HIPAA</option>
                      <option value="Specialty Questionnaire">Specialty Questionnaire</option>
                      <option value="Pre/Post-Op Instructions">Pre/Post-Op Instructions</option>
                    </select>
                  </div>

                  {/* Target Audience / Applicable Cohort */}
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-stone-700">
                      Applicable Patient Cohort
                    </label>
                    <input
                      type="text"
                      value={uploadFormTarget}
                      onChange={(e) => setUploadFormTarget(e.target.value)}
                      placeholder="e.g. All New Patients, Surgical Candidates"
                      className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 focus:border-emerald-600 text-xs text-stone-900 outline-hidden bg-white"
                    />
                  </div>

                  {/* Version Tag */}
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-stone-700">
                      Version Code / Revision
                    </label>
                    <input
                      type="text"
                      value={uploadFormVersion}
                      onChange={(e) => setUploadFormVersion(e.target.value)}
                      placeholder="e.g. v2026.2"
                      className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 focus:border-emerald-600 text-xs text-stone-900 outline-hidden bg-white"
                    />
                  </div>

                  {/* Clinical Description / Instructions */}
                  <div className="space-y-1 md:col-span-3">
                    <label className="text-xs font-bold text-stone-700">
                      Description & Patient Instructions
                    </label>
                    <input
                      type="text"
                      value={uploadFormDescription}
                      onChange={(e) => setUploadFormDescription(e.target.value)}
                      placeholder="e.g. Required pre-operative disclosure detailing anesthesia risks, bleeding precautions, and recovery chaperone rules."
                      className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 focus:border-emerald-600 text-xs text-stone-900 outline-hidden bg-white"
                    />
                  </div>

                </div>

                {/* Toggles Strip */}
                <div className="p-4 rounded-xl bg-stone-50 border border-stone-200 flex flex-wrap items-center justify-between gap-4">
                  <div className="flex items-center gap-6 flex-wrap">
                    
                    <label className="flex items-center gap-2.5 cursor-pointer select-none">
                      <input
                        type="checkbox"
                        checked={uploadFormIsMandatory}
                        onChange={(e) => setUploadFormIsMandatory(e.target.checked)}
                        className="w-4 h-4 rounded-sm text-emerald-600 border-stone-300 focus:ring-emerald-500"
                      />
                      <div>
                        <div className="text-xs font-bold text-stone-800">Mandatory for New Patient Check-In</div>
                        <div className="text-[11px] text-stone-500">Patients cannot bypass this form during portal onboarding</div>
                      </div>
                    </label>

                    <label className="flex items-center gap-2.5 cursor-pointer select-none">
                      <input
                        type="checkbox"
                        checked={uploadFormSignatureRequired}
                        onChange={(e) => setUploadFormSignatureRequired(e.target.checked)}
                        className="w-4 h-4 rounded-sm text-indigo-600 border-stone-300 focus:ring-indigo-500"
                      />
                      <div>
                        <div className="text-xs font-bold text-stone-800">Require Electronic Signature</div>
                        <div className="text-[11px] text-stone-500">Enforces HIPAA compliant digital canvas sign-off</div>
                      </div>
                    </label>

                  </div>

                  <div className="flex items-center gap-2 ml-auto">
                    <button
                      type="button"
                      onClick={() => setIsUploadPanelOpen(false)}
                      className="px-4 py-2 rounded-xl text-xs font-semibold text-stone-600 hover:bg-stone-200/70 transition-colors cursor-pointer"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      id="admin-confirm-upload-form-btn"
                      className="px-5 py-2 bg-gradient-to-r from-emerald-600 to-teal-700 hover:from-emerald-700 hover:to-teal-800 text-white text-xs font-bold rounded-xl shadow-xs flex items-center gap-1.5 cursor-pointer"
                    >
                      <FileUp className="w-3.5 h-3.5" />
                      <span>Upload & Deploy Form</span>
                    </button>
                  </div>
                </div>

              </form>
            </div>
          )}

          {/* Search, Filter & View Controls */}
          <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-2xs space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-3">
              
              {/* Search Bar */}
              <div className="relative flex-1 min-w-[260px]">
                <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-stone-400" />
                <input
                  type="text"
                  value={intakeSearchQuery}
                  onChange={(e) => setIntakeSearchQuery(e.target.value)}
                  placeholder="Search intake forms by title, keyword, category, or file..."
                  className="w-full pl-9 pr-8 py-2 rounded-xl border border-stone-300 focus:border-emerald-600 text-xs text-stone-900 outline-hidden bg-stone-50/50 focus:bg-white"
                />
                {intakeSearchQuery && (
                  <button
                    onClick={() => setIntakeSearchQuery('')}
                    className="absolute right-2.5 top-1/2 -translate-y-1/2 text-stone-400 hover:text-stone-700 text-xs font-bold"
                  >
                    ✕
                  </button>
                )}
              </div>

              {/* Requirement Filter Tabs */}
              <div className="flex items-center gap-1.5 p-1 bg-stone-100 rounded-xl border border-stone-200">
                <button
                  onClick={() => setIntakeRequirementFilter('All')}
                  className={`px-3 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                    intakeRequirementFilter === 'All'
                      ? 'bg-white text-stone-900 shadow-xs'
                      : 'text-stone-600 hover:text-stone-900'
                  }`}
                >
                  All ({intakeFormsList.length})
                </button>
                <button
                  onClick={() => setIntakeRequirementFilter('Mandatory')}
                  className={`px-3 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                    intakeRequirementFilter === 'Mandatory'
                      ? 'bg-emerald-700 text-white shadow-xs'
                      : 'text-stone-600 hover:text-stone-900'
                  }`}
                >
                  Mandatory ({intakeFormsList.filter(f => f.isMandatory).length})
                </button>
                <button
                  onClick={() => setIntakeRequirementFilter('Optional')}
                  className={`px-3 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                    intakeRequirementFilter === 'Optional'
                      ? 'bg-stone-800 text-white shadow-xs'
                      : 'text-stone-600 hover:text-stone-900'
                  }`}
                >
                  Optional ({intakeFormsList.filter(f => !f.isMandatory).length})
                </button>
              </div>

            </div>

            {/* Category Filter Pills */}
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1 pt-1 text-xs">
              <span className="text-[11px] font-bold text-stone-400 uppercase tracking-wider mr-1 flex items-center gap-1">
                <Filter className="w-3 h-3" />
                <span>Categories:</span>
              </span>
              {[
                { key: 'All', label: 'All Categories' },
                { key: 'Registration & Demographics', label: 'Registration & Demographics' },
                { key: 'Medical & Surgical History', label: 'Medical History' },
                { key: 'Consents & Agreements', label: 'Consents & Agreements' },
                { key: 'Financial & HIPAA', label: 'Financial & HIPAA' },
                { key: 'Specialty Questionnaire', label: 'Specialty Questionnaire' },
                { key: 'Pre/Post-Op Instructions', label: 'Pre/Post-Op' },
              ].map(cat => (
                <button
                  key={cat.key}
                  onClick={() => setIntakeCategoryFilter(cat.key)}
                  className={`px-3 py-1.5 rounded-xl font-medium whitespace-nowrap transition-colors cursor-pointer border ${
                    intakeCategoryFilter === cat.key
                      ? 'bg-slate-900 text-white border-slate-900 font-bold shadow-xs'
                      : 'bg-stone-50 hover:bg-stone-100 text-stone-700 border-stone-200'
                  }`}
                >
                  {cat.label}
                </button>
              ))}
            </div>
          </div>

          {/* Intake Forms Table Card */}
          <div className="bg-white rounded-2xl border border-stone-200 shadow-2xs overflow-hidden">
            
            <div className="p-4 bg-stone-50/80 border-b border-stone-200 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-stone-800">
                  Showing {filteredIntakeForms.length} of {intakeFormsList.length} Intake Forms
                </span>
                {intakeCategoryFilter !== 'All' && (
                  <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-emerald-100 text-emerald-800">
                    Category: {intakeCategoryFilter}
                  </span>
                )}
                {intakeRequirementFilter !== 'All' && (
                  <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-purple-100 text-purple-800">
                    Filter: {intakeRequirementFilter}
                  </span>
                )}
              </div>

              <span className="text-[11px] text-stone-500">
                Synced with Patient Registration & Check-In Kiosk
              </span>
            </div>

            {filteredIntakeForms.length > 0 ? (
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className="bg-stone-100/70 border-b border-stone-200 text-[11px] font-bold text-stone-600 uppercase tracking-wider">
                      <th className="py-3.5 px-4 font-bold">Form Name & Details</th>
                      <th className="py-3.5 px-4 font-bold">Category</th>
                      <th className="py-3.5 px-4 font-bold">Patient Requirement</th>
                      <th className="py-3.5 px-4 font-bold">File Format</th>
                      <th className="py-3.5 px-4 font-bold">Revision & Author</th>
                      <th className="py-3.5 px-4 font-bold text-center">Status</th>
                      <th className="py-3.5 px-4 font-bold text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-stone-200/70">
                    {filteredIntakeForms.map((form) => {
                      // Category badge colors
                      let categoryColor = 'bg-stone-100 text-stone-800 border-stone-200';
                      if (form.category === 'Registration & Demographics') {
                        categoryColor = 'bg-emerald-50 text-emerald-800 border-emerald-200';
                      } else if (form.category === 'Medical & Surgical History') {
                        categoryColor = 'bg-emerald-50 text-emerald-800 border-emerald-200';
                      } else if (form.category === 'Consents & Agreements') {
                        categoryColor = 'bg-purple-50 text-purple-800 border-purple-200';
                      } else if (form.category === 'Financial & HIPAA') {
                        categoryColor = 'bg-amber-50 text-amber-800 border-amber-200';
                      } else if (form.category === 'Specialty Questionnaire') {
                        categoryColor = 'bg-teal-50 text-teal-800 border-teal-200';
                      } else if (form.category === 'Pre/Post-Op Instructions') {
                        categoryColor = 'bg-indigo-50 text-indigo-800 border-indigo-200';
                      }

                      return (
                        <tr 
                          key={form.id} 
                          id={`intake-form-row-${form.id}`}
                          className="hover:bg-stone-50/80 transition-colors group"
                        >
                          {/* Form Name & Info */}
                          <td className="py-4 px-4 max-w-sm">
                            <div className="flex items-start gap-3">
                              <div className={`p-2 rounded-xl text-xs font-black shrink-0 shadow-2xs ${
                                form.fileFormat === 'PDF' 
                                  ? 'bg-rose-50 text-rose-700 border border-rose-200' 
                                  : 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                              }`}>
                                {form.fileFormat}
                              </div>
                              <div className="space-y-1">
                                <div className="font-bold text-stone-900 text-xs flex items-center gap-1.5 flex-wrap">
                                  <span>{form.title}</span>
                                  <span className="px-1.5 py-0.2 rounded-md text-[10px] font-mono bg-stone-100 text-stone-600 border border-stone-200">
                                    {form.version}
                                  </span>
                                </div>
                                <p className="text-[11px] text-stone-500 line-clamp-1">
                                  {form.description}
                                </p>
                                {form.signatureRequired && (
                                  <div className="inline-flex items-center gap-1 text-[10px] font-bold text-indigo-700 bg-indigo-50 px-1.5 py-0.2 rounded-md border border-indigo-100">
                                    <CheckSquare className="w-3 h-3" />
                                    <span>E-Signature Required</span>
                                  </div>
                                )}
                              </div>
                            </div>
                          </td>

                          {/* Category */}
                          <td className="py-4 px-4 whitespace-nowrap">
                            <span className={`px-2.5 py-1 rounded-full text-[11px] font-bold border ${categoryColor}`}>
                              {form.category}
                            </span>
                          </td>

                          {/* Requirement & Target */}
                          <td className="py-4 px-4">
                            <div className="space-y-1">
                              <button
                                type="button"
                                onClick={() => handleToggleFormMandatory(form.id)}
                                title="Click to toggle mandatory status"
                                className={`px-2.5 py-1 rounded-full text-[11px] font-bold inline-flex items-center gap-1.5 border transition-all cursor-pointer ${
                                  form.isMandatory 
                                    ? 'bg-emerald-50 text-emerald-800 border-emerald-200 hover:bg-emerald-100' 
                                    : 'bg-stone-100 text-stone-600 border-stone-200 hover:bg-stone-200'
                                }`}
                              >
                                {form.isMandatory ? (
                                  <>
                                    <Check className="w-3 h-3 text-emerald-600" />
                                    <span>Mandatory for Check-In</span>
                                  </>
                                ) : (
                                  <span>Optional Intake</span>
                                )}
                              </button>
                              <div className="text-[10px] text-stone-500 pl-1">
                                Target: <span className="font-semibold text-stone-700">{form.targetAudience}</span>
                              </div>
                            </div>
                          </td>

                          {/* File Details */}
                          <td className="py-4 px-4 whitespace-nowrap">
                            <div className="space-y-0.5">
                              <div className="font-semibold text-stone-800 text-[11px] truncate max-w-[150px]" title={form.fileName}>
                                {form.fileName}
                              </div>
                              <div className="text-[10px] text-stone-500 font-mono">
                                {form.fileSize}
                              </div>
                            </div>
                          </td>

                          {/* Last Revision & Staff */}
                          <td className="py-4 px-4 whitespace-nowrap">
                            <div className="space-y-0.5">
                              <div className="text-[11px] font-semibold text-stone-800">
                                {form.lastUpdated}
                              </div>
                              <div className="text-[10px] text-stone-500">
                                by {form.uploadedBy}
                              </div>
                            </div>
                          </td>

                          {/* Status */}
                          <td className="py-4 px-4 text-center whitespace-nowrap">
                            <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-bold bg-emerald-50 text-emerald-800 border border-emerald-200">
                              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                              <span>Active</span>
                            </span>
                          </td>

                          {/* Action Buttons */}
                          <td className="py-4 px-4 text-right whitespace-nowrap">
                            <div className="flex items-center justify-end gap-1">
                              
                              {/* Preview Button */}
                              <button
                                type="button"
                                onClick={() => setPreviewingIntakeForm(form)}
                                className="p-2 rounded-xl text-stone-600 hover:text-emerald-700 hover:bg-emerald-50 transition-colors cursor-pointer border border-stone-200 hover:border-emerald-200 shadow-2xs"
                                title="View & Preview Form"
                                id={`preview-intake-form-${form.id}`}
                              >
                                <Eye className="w-4 h-4" />
                              </button>

                              {/* Download Button */}
                              <button
                                type="button"
                                onClick={() => {
                                  if (onShowToast) onShowToast(`Downloading ${form.fileName}...`);
                                }}
                                className="p-2 rounded-xl text-stone-600 hover:text-emerald-700 hover:bg-emerald-50 transition-colors cursor-pointer border border-stone-200 hover:border-emerald-200 shadow-2xs"
                                title="Download Document"
                                id={`download-intake-form-${form.id}`}
                              >
                                <Download className="w-4 h-4" />
                              </button>

                              {/* Replace Button — swaps the template's source file in place */}
                              <button
                                type="button"
                                onClick={() => {
                                  setReplaceTargetFormId(form.id);
                                  replaceFileInputRef.current?.click();
                                }}
                                className="p-2 rounded-xl text-stone-600 hover:text-indigo-700 hover:bg-indigo-50 transition-colors cursor-pointer border border-stone-200 hover:border-indigo-200 shadow-2xs"
                                title="Replace / Update Source File"
                                id={`replace-intake-form-${form.id}`}
                              >
                                <RefreshCw className="w-4 h-4" />
                              </button>

                              {/* Delete Button */}
                              <button
                                type="button"
                                onClick={() => setDeletingIntakeForm(form)}
                                className="p-2 rounded-xl text-stone-500 hover:text-rose-700 hover:bg-rose-50 transition-colors cursor-pointer border border-stone-200 hover:border-rose-200 shadow-2xs"
                                title="Delete Intake Form"
                                id={`delete-intake-form-${form.id}`}
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>

                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
                {/* Hidden input backing the per-row Replace action above */}
                <input
                  ref={replaceFileInputRef}
                  type="file"
                  accept=".pdf,.doc,.docx"
                  className="hidden"
                  onChange={handleReplaceFileSelected}
                />
              </div>
            ) : (
              <div className="p-12 text-center space-y-4">
                <div className="w-14 h-14 rounded-2xl bg-stone-100 text-stone-400 flex items-center justify-center mx-auto">
                  <FileText className="w-7 h-7" />
                </div>
                <div className="space-y-1">
                  <h4 className="text-sm font-bold text-stone-800">No matching intake forms found</h4>
                  <p className="text-xs text-stone-500 max-w-sm mx-auto">
                    {intakeSearchQuery 
                      ? `No forms match your search "${intakeSearchQuery}". Try clearing search filters.`
                      : 'No intake forms found in this category. Upload a new form to get started.'}
                  </p>
                </div>
                <div className="flex items-center justify-center gap-2">
                  {(intakeSearchQuery || intakeCategoryFilter !== 'All' || intakeRequirementFilter !== 'All') && (
                    <button
                      type="button"
                      onClick={() => {
                        setIntakeSearchQuery('');
                        setIntakeCategoryFilter('All');
                        setIntakeRequirementFilter('All');
                      }}
                      className="px-3.5 py-1.5 rounded-xl text-xs font-semibold bg-stone-100 hover:bg-stone-200 text-stone-700 cursor-pointer"
                    >
                      Reset Filters
                    </button>
                  )}
                  <button
                    type="button"
                    onClick={() => setIsUploadPanelOpen(true)}
                    className="px-4 py-1.5 rounded-xl text-xs font-bold bg-emerald-600 hover:bg-emerald-700 text-white shadow-xs cursor-pointer flex items-center gap-1.5"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Upload New Form</span>
                  </button>
                </div>
              </div>
            )}
          </div>

        </div>
      )}

      {/* ======================================================== */}
      {/* POPUP MODAL: ADD / EDIT PROVIDER                         */}
      {/* ======================================================== */}
      {isProviderModalOpen && (
        <div className="fixed inset-0 z-50 bg-stone-950/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl border border-stone-300 shadow-2xl p-6 max-w-lg w-full space-y-4 animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between border-b border-stone-200 pb-3">
              <h3 className="text-base font-bold text-stone-900 flex items-center gap-2">
                <Stethoscope className="w-5 h-5 text-emerald-700" />
                <span>{editingProviderId ? 'Modify Medical Provider' : '+ Add New Provider'}</span>
              </h3>
              <button
                onClick={() => setIsProviderModalOpen(false)}
                className="text-stone-400 hover:text-stone-700 text-xs font-bold cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveProviderModal} className="space-y-4">
              
              {/* Name & Degree */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="sm:col-span-2 space-y-1">
                  <label className="text-xs font-bold text-stone-700">Provider Name <span className="text-rose-500">*</span></label>
                  <input
                    type="text"
                    required
                    value={providerFormName}
                    onChange={(e) => setProviderFormName(e.target.value)}
                    placeholder="e.g. David Chen"
                    className="w-full px-3 py-2 rounded-xl border border-stone-300 text-xs outline-hidden focus:border-emerald-600"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-stone-700">Degree <span className="text-rose-500">*</span></label>
                  <select
                    value={providerFormDegree}
                    onChange={(e) => setProviderFormDegree(e.target.value as ProviderDegree)}
                    className="w-full px-3 py-2 rounded-xl border border-stone-300 text-xs outline-hidden focus:border-emerald-600 bg-white"
                  >
                    <option value="MD">MD</option>
                    <option value="DO">DO</option>
                    <option value="DPM">DPM</option>
                    <option value="DMD">DMD</option>
                    <option value="DDS">DDS</option>
                    <option value="Other">Other</option>
                  </select>
                </div>
              </div>

              {/* Specialty */}
              <div className="space-y-1">
                <label className="text-xs font-bold text-stone-700">Specialty</label>
                <input
                  type="text"
                  value={providerFormSpecialty}
                  onChange={(e) => setProviderFormSpecialty(e.target.value)}
                  placeholder="e.g. Anesthesiology, Plastic Surgery"
                  className="w-full px-3 py-2 rounded-xl border border-stone-300 text-xs outline-hidden focus:border-emerald-600"
                />
              </div>

              {/* Email & Cell Phone */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-stone-700">Email <span className="text-rose-500">*</span></label>
                  <input
                    type="email"
                    required
                    value={providerFormEmail}
                    onChange={(e) => setProviderFormEmail(e.target.value)}
                    placeholder="provider@mypractice.com"
                    className="w-full px-3 py-2 rounded-xl border border-stone-300 text-xs outline-hidden focus:border-emerald-600"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-stone-700">Cell Phone (for text alerts)</label>
                  <input
                    type="tel"
                    value={providerFormCell}
                    onChange={(e) => setProviderFormCell(e.target.value)}
                    placeholder="(310) 859-2010"
                    className="w-full px-3 py-2 rounded-xl border border-stone-300 text-xs outline-hidden focus:border-emerald-600"
                  />
                </div>
              </div>

              {/* NPI & Color Code */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-stone-700">National Provider Identifier (NPI)</label>
                  <input
                    type="text"
                    value={providerFormNpi}
                    onChange={(e) => setProviderFormNpi(e.target.value)}
                    placeholder="1029384756"
                    className="w-full px-3 py-2 rounded-xl border border-stone-300 text-xs outline-hidden focus:border-emerald-600 font-mono"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-stone-700">Scheduler Color Code</label>
                  <div className="flex items-center gap-2">
                    <input
                      type="color"
                      value={providerFormColor}
                      onChange={(e) => setProviderFormColor(e.target.value)}
                      className="w-10 h-8 rounded-lg cursor-pointer border border-stone-300 p-0.5"
                    />
                    <input
                      type="text"
                      value={providerFormColor}
                      onChange={(e) => setProviderFormColor(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl border border-stone-300 text-xs font-mono"
                    />
                  </div>
                </div>
              </div>

              <div className="pt-3 border-t border-stone-200 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsProviderModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-stone-600 hover:bg-stone-100 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-gradient-to-r from-emerald-700 to-emerald-800 hover:from-emerald-800 hover:to-emerald-900 text-white text-xs font-bold rounded-xl shadow-xs cursor-pointer"
                >
                  {editingProviderId ? 'Save Provider' : 'Add Provider & Send Invitation'}
                </button>
              </div>

            </form>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* POPUP MODAL: ADD / EDIT USER                             */}
      {/* ======================================================== */}
      {isUserModalOpen && (
        <div className="fixed inset-0 z-50 bg-stone-950/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl border border-stone-300 shadow-2xl p-6 max-w-lg w-full space-y-4 animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between border-b border-stone-200 pb-3">
              <h3 className="text-base font-bold text-stone-900 flex items-center gap-2">
                <Users className="w-5 h-5 text-indigo-700" />
                <span>{editingUserId ? 'Modify User Account' : '+ Add New User'}</span>
              </h3>
              <button
                onClick={() => setIsUserModalOpen(false)}
                className="text-stone-400 hover:text-stone-700 text-xs font-bold cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveUserModal} className="space-y-4">
              
              {/* User Name */}
              <div className="space-y-1">
                <label className="text-xs font-bold text-stone-700">Full Name <span className="text-rose-500">*</span></label>
                <input
                  type="text"
                  required
                  value={userFormName}
                  onChange={(e) => setUserFormName(e.target.value)}
                  placeholder="e.g. Sarah Jenkins"
                  className="w-full px-3 py-2 rounded-xl border border-stone-300 text-xs outline-hidden focus:border-emerald-600"
                />
              </div>

              {/* Title / Role */}
              <div className="space-y-1">
                <label className="text-xs font-bold text-stone-700">Title / Role <span className="text-rose-500">*</span></label>
                <select
                  value={userFormTitle}
                  onChange={(e) => setUserFormTitle(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-stone-300 text-xs outline-hidden focus:border-emerald-600 bg-white"
                >
                  <option value="Nurse">Nurse (RN / BSN)</option>
                  <option value="Medical Assistant">Medical Assistant (MA)</option>
                  <option value="Front Office">Front Office & Scheduling Coordinator</option>
                  <option value="Practice Administrator">Practice Administrator / Office Manager</option>
                  <option value="Surgical Tech">Surgical Technologist</option>
                  <option value="Billing Specialist">Billing Specialist & Coder</option>
                  <option value="Attending Physician">Attending Physician</option>
                  <option value="Anesthesiologist">Anesthesiologist</option>
                  <option value="Other">Other Clinical / Administrative Role</option>
                </select>
              </div>

              {/* Email & Cell Phone */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-stone-700">Email Address <span className="text-rose-500">*</span></label>
                  <input
                    type="email"
                    required
                    value={userFormEmail}
                    onChange={(e) => setUserFormEmail(e.target.value)}
                    placeholder="user@mypractice.com"
                    className="w-full px-3 py-2 rounded-xl border border-stone-300 text-xs outline-hidden focus:border-emerald-600"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-stone-700">Cell Phone (for 2FA & alerts)</label>
                  <input
                    type="tel"
                    value={userFormCell}
                    onChange={(e) => setUserFormCell(e.target.value)}
                    placeholder="(310) 859-2002"
                    className="w-full px-3 py-2 rounded-xl border border-stone-300 text-xs outline-hidden focus:border-emerald-600"
                  />
                </div>
              </div>

              <div className="pt-3 border-t border-stone-200 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsUserModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-stone-600 hover:bg-stone-100 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-gradient-to-r from-emerald-700 to-slate-900 hover:from-emerald-800 hover:to-slate-950 text-white text-xs font-bold rounded-xl shadow-xs cursor-pointer"
                >
                  Save User Account
                </button>
              </div>

            </form>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* POPUP MODAL: PREVIEW INTAKE FORM                         */}
      {/* ======================================================== */}
      {previewingIntakeForm && (
        <div className="fixed inset-0 z-50 bg-stone-950/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl border border-stone-300 shadow-2xl max-w-2xl w-full max-h-[90vh] flex flex-col animate-in fade-in zoom-in-95 overflow-hidden">
            
            {/* Modal Header */}
            <div className="p-4 sm:p-5 border-b border-stone-200 flex items-center justify-between bg-stone-50/80">
              <div className="flex items-center gap-3">
                <div className={`p-2 rounded-xl text-xs font-black shrink-0 ${
                  previewingIntakeForm.fileFormat === 'PDF' 
                    ? 'bg-rose-100 text-rose-800' 
                    : 'bg-emerald-100 text-emerald-800'
                }`}>
                  {previewingIntakeForm.fileFormat}
                </div>
                <div>
                  <h3 className="text-sm font-bold text-stone-900 line-clamp-1">
                    {previewingIntakeForm.title}
                  </h3>
                  <div className="flex items-center gap-2 text-[11px] text-stone-500 mt-0.5">
                    <span className="font-semibold text-emerald-700">{previewingIntakeForm.category}</span>
                    <span>•</span>
                    <span>{previewingIntakeForm.version}</span>
                    <span>•</span>
                    <span>{previewingIntakeForm.fileSize}</span>
                  </div>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setPreviewingIntakeForm(null)}
                className="p-1.5 rounded-lg text-stone-400 hover:text-stone-700 hover:bg-stone-200/60 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Document Preview Body (Simulating Form View) */}
            <div className="p-6 overflow-y-auto space-y-6 bg-stone-100/50 flex-1">
              
              {/* Simulated Paper Sheet */}
              <div className="bg-white p-6 sm:p-8 rounded-xl border border-stone-200 shadow-xs space-y-5 max-w-xl mx-auto text-stone-900 text-xs">
                
                {/* Document Letterhead */}
                <div className="border-b-2 border-stone-900 pb-4 text-center space-y-1">
                  <div className="text-[10px] font-black uppercase tracking-widest text-stone-400">
                    AURA VANGUARD SURGICAL & AESTHETIC PAVILION
                  </div>
                  <h4 className="text-sm font-black text-stone-900 uppercase">
                    {previewingIntakeForm.title}
                  </h4>
                  <div className="text-[10px] text-stone-500 font-mono">
                    Document Revision: {previewingIntakeForm.version} | HIPAA Compliance Reference: AV-2026-REG
                  </div>
                </div>

                {/* Target & Description Alert */}
                <div className="p-3 rounded-lg bg-stone-50 border border-stone-200 text-[11px] text-stone-600 space-y-1">
                  <div className="font-bold text-stone-800 flex items-center justify-between">
                    <span>Applicability: {previewingIntakeForm.targetAudience}</span>
                    {previewingIntakeForm.isMandatory && (
                      <span className="text-emerald-700 font-bold">Mandatory Intake Requirement</span>
                    )}
                  </div>
                  <p>{previewingIntakeForm.description}</p>
                </div>

                {/* Section 1: Patient Identification */}
                <div className="space-y-2">
                  <div className="font-bold text-xs uppercase tracking-wider text-stone-700 border-b border-stone-200 pb-1">
                    Section 1: Patient Demographics & Record Verification
                  </div>
                  <div className="grid grid-cols-2 gap-3 text-[11px]">
                    <div className="p-2 rounded-lg bg-stone-50 border border-stone-200">
                      <span className="text-stone-400 block text-[10px]">Patient Full Legal Name</span>
                      <span className="font-semibold text-stone-800">___________________________</span>
                    </div>
                    <div className="p-2 rounded-lg bg-stone-50 border border-stone-200">
                      <span className="text-stone-400 block text-[10px]">Date of Birth (MM/DD/YYYY)</span>
                      <span className="font-semibold text-stone-800">____ / ____ / ________</span>
                    </div>
                    <div className="p-2 rounded-lg bg-stone-50 border border-stone-200">
                      <span className="text-stone-400 block text-[10px]">Primary Mobile / SMS</span>
                      <span className="font-semibold text-stone-800">( _____ ) _____ - ________</span>
                    </div>
                    <div className="p-2 rounded-lg bg-stone-50 border border-stone-200">
                      <span className="text-stone-400 block text-[10px]">Email Address</span>
                      <span className="font-semibold text-stone-800">___________________________</span>
                    </div>
                  </div>
                </div>

                {/* Section 2: Clinical Disclosures / Questionnaires */}
                <div className="space-y-2">
                  <div className="font-bold text-xs uppercase tracking-wider text-stone-700 border-b border-stone-200 pb-1">
                    Section 2: Clinical Questionnaire & Compliance Acknowledgments
                  </div>
                  <div className="space-y-2 text-[11px] text-stone-600">
                    <div className="flex items-start gap-2">
                      <div className="w-3.5 h-3.5 rounded-sm border border-stone-400 mt-0.5 shrink-0"></div>
                      <span>I confirm all provided personal, insurance, medical history, and allergy data are accurate and true to the best of my knowledge.</span>
                    </div>
                    <div className="flex items-start gap-2">
                      <div className="w-3.5 h-3.5 rounded-sm border border-stone-400 mt-0.5 shrink-0"></div>
                      <span>I acknowledge receipt of Notice of Privacy Practices (HIPAA) and practice financial policies regarding copays and deposits.</span>
                    </div>
                    <div className="flex items-start gap-2">
                      <div className="w-3.5 h-3.5 rounded-sm border border-stone-400 mt-0.5 shrink-0"></div>
                      <span>I consent to outpatient medical photography and diagnostic imaging strictly for surgical planning and medical chart records.</span>
                    </div>
                  </div>
                </div>

                {/* Section 3: Signature */}
                {previewingIntakeForm.signatureRequired && (
                  <div className="space-y-2 pt-2">
                    <div className="font-bold text-xs uppercase tracking-wider text-stone-700 border-b border-stone-200 pb-1 flex items-center justify-between">
                      <span>Section 3: Patient / Legal Guardian Electronic Signature</span>
                      <span className="text-[10px] font-semibold text-indigo-600">HIPAA ESIGN Compliant</span>
                    </div>
                    <div className="p-4 border-2 border-dashed border-stone-300 rounded-xl bg-stone-50/60 text-center space-y-1">
                      <div className="text-[11px] font-mono text-stone-400">
                        [ Digital Touch / Stylus Signature Area - Captured on Check-In Kiosk ]
                      </div>
                      <div className="text-[10px] text-stone-500">
                        Timestamp & IP Hash automatically verified upon patient completion
                      </div>
                    </div>
                  </div>
                )}

              </div>

            </div>

            {/* Modal Footer */}
            <div className="p-4 border-t border-stone-200 bg-white flex items-center justify-between gap-3">
              <div className="text-xs text-stone-500">
                File: <span className="font-mono font-semibold text-stone-700">{previewingIntakeForm.fileName}</span>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    if (onShowToast) onShowToast(`Sent "${previewingIntakeForm.title}" to clinic printer.`);
                  }}
                  className="px-3.5 py-2 rounded-xl text-xs font-semibold bg-stone-100 hover:bg-stone-200 text-stone-700 cursor-pointer"
                >
                  Print Form
                </button>
                <button
                  type="button"
                  onClick={() => {
                    if (onShowToast) onShowToast(`Downloading ${previewingIntakeForm.fileName}...`);
                  }}
                  className="px-4 py-2 rounded-xl text-xs font-bold bg-slate-900 hover:bg-black text-white cursor-pointer flex items-center gap-1.5"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download Document</span>
                </button>
              </div>
            </div>

          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* POPUP MODAL: DELETE CONFIRMATION                         */}
      {/* ======================================================== */}
      {/* MODAL: ADD A NEW PRACTICE OR LOCATION */}
      {credentialInviteOpen && <div className="fixed inset-0 z-[120] bg-slate-950/55 p-4 flex items-center justify-center">
        <div className="w-full max-w-xl bg-white rounded-2xl shadow-2xl overflow-hidden">
          <div className="bg-[#14432E] text-white px-5 py-4 flex items-center justify-between"><div><div className="text-[10px] uppercase tracking-wider font-black text-[#F4DFA7]">Credentialing invitation</div><h3 className="font-black mt-0.5">Request Membership & Privileges</h3></div><button onClick={()=>setCredentialInviteOpen(false)} className="p-1.5 rounded-lg hover:bg-white/10"><X className="w-5 h-5"/></button></div>
          <div className="p-5 space-y-4">
            <p className="text-xs text-stone-600">The email includes the Surgeon Membership & Privileges Application, credential upload checklist, and a secure account-activation link so the surgeon can create a username and password. After verification, privileges are routed to the Medical Director for final review and approval.</p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3"><div><label className="text-xs font-bold text-stone-700">Surgeon name</label><input value={inviteSurgeonName} onChange={e=>setInviteSurgeonName(e.target.value)} className="mt-1 w-full px-3 py-2.5 border rounded-xl text-sm" placeholder="Jane Smith, MD"/></div><div><label className="text-xs font-bold text-stone-700">Email</label><input type="email" value={inviteSurgeonEmail} onChange={e=>setInviteSurgeonEmail(e.target.value)} className="mt-1 w-full px-3 py-2.5 border rounded-xl text-sm" placeholder="doctor@example.com"/></div></div>
            <div className="rounded-xl bg-[#F6F8F5] border border-[#DCE3DD] p-4"><div className="text-xs font-black text-[#20352B]">Requested items</div><div className="grid grid-cols-1 sm:grid-cols-2 gap-2 mt-2">{['Vityls Account Activation','Membership & Privileges Application','Medical License','DEA Registration (if applicable)','Malpractice Insurance','Board Certification','CV / Other requested credentials'].map(x=><div key={x} className="flex items-center gap-2 text-xs text-stone-600"><CheckCircle2 className="w-3.5 h-3.5 text-[#1F6E52]"/>{x}</div>)}</div></div>
          </div>
          <div className="px-5 py-4 bg-stone-50 border-t flex justify-end gap-2"><button onClick={()=>setCredentialInviteOpen(false)} className="px-4 py-2 border rounded-lg text-xs font-bold">Cancel</button><button onClick={sendCredentialInvite} className="px-4 py-2 bg-[#1F6E52] text-white rounded-lg text-xs font-black flex items-center gap-2"><Mail className="w-4 h-4"/>Send Application & Account Invite</button></div>
        </div>
      </div>}

      {credentialPortalOpen && <div className="fixed inset-0 z-[120] bg-slate-950/60 p-3 sm:p-6 flex items-center justify-center">
        <div className="w-full max-w-6xl h-[92vh] bg-white rounded-2xl shadow-2xl overflow-hidden flex flex-col">
          <div className="bg-[#14432E] text-white px-5 py-4 flex items-center justify-between"><div><div className="text-[10px] uppercase tracking-wider font-black text-[#F4DFA7]">Surgeon credentialing portal</div><h3 className="font-black">Membership Application & Credential Uploads</h3></div><button onClick={()=>setCredentialPortalOpen(false)} className="p-1.5 rounded-lg hover:bg-white/10"><X className="w-5 h-5"/></button></div>
          <div className="flex-1 min-h-0 grid grid-cols-1 lg:grid-cols-[1.4fr_.6fr]">
            <div className="min-h-0 bg-[#E9ECE8] p-3 overflow-auto"><iframe title="Surgeon Membership Application" src="forms/Surgeon_Membership_Application.html" className="w-full h-[1500px] bg-white border-0 shadow-sm rounded-lg"/></div>
            <div className="min-h-0 overflow-auto p-5 border-l border-stone-200 bg-white">
              <h4 className="font-black text-[#20352B]">Upload credential documents</h4><p className="text-xs text-stone-500 mt-1">Upload individually or provide a complete credentialing PDF. Nightingale can later identify and classify documents while preserving the source file.</p>
              <div className="mt-4 space-y-3">{credentialDocumentCategories.map(cat=><label key={cat} className="block p-3 rounded-xl border border-[#DCE3DD] hover:border-[#1F6E52] cursor-pointer"><div className="flex items-center justify-between gap-2"><div><div className="text-xs font-bold text-[#20352B]">{cat}</div><div className="text-[10px] text-[#748078] mt-0.5">{credentialUploads[cat] || 'No file uploaded'}</div></div><span className="px-2.5 py-1 rounded-lg bg-[#F1F3EC] text-[10px] font-bold text-[#1F6E52]">Upload</span></div><input type="file" accept="application/pdf,image/*" className="hidden" onChange={e=>{const f=e.target.files?.[0]; if(f){setCredentialUploads(prev=>({...prev,[cat]:f.name})); onShowToast?.(`${cat} uploaded for credentialing review.`);}}}/></label>)}</div>
              <label className="mt-4 block p-4 rounded-xl border-2 border-dashed border-[#BFCAC2] text-center cursor-pointer bg-[#F8FAF8]"><UploadCloud className="w-6 h-6 mx-auto text-[#1F6E52]"/><div className="text-xs font-black text-[#20352B] mt-2">Upload complete credentialing packet</div><div className="text-[10px] text-[#748078] mt-1">PDF may contain multiple credential documents</div><input type="file" accept="application/pdf" className="hidden" onChange={e=>{const f=e.target.files?.[0]; if(f){setCredentialUploads(prev=>({...prev,'Complete Credentialing Packet':f.name})); onShowToast?.('Complete credentialing packet uploaded. Nightingale classification is ready for backend connection.');}}}/></label>
              <div className="mt-5 rounded-xl bg-[#EAF8F3] border border-[#BFE5D6] p-4 text-xs text-[#2F5C49]"><b>Nightingale workflow:</b> identify document boundaries, extract provider/name/license/issuer/issue/expiration data, present classifications for administrator confirmation, then preserve source + version history.</div>
            </div>
          </div>
        </div>
      </div>}


      {isAddLocationModalOpen && (
        <div className="fixed inset-0 z-50 bg-stone-950/70 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl border border-stone-300 shadow-2xl max-w-2xl w-full p-6 sm:p-8 space-y-6 animate-in fade-in zoom-in-95 my-8 max-h-[90vh] overflow-y-auto">
            
            <div className="flex items-start justify-between border-b border-stone-200 pb-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center shrink-0">
                  <Building2 className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-stone-900">
                    Add a New Practice or Location
                  </h3>
                  <p className="text-xs text-stone-500">
                    Provision satellite offices, outpatient surgical annexes, or new clinical branches
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsAddLocationModalOpen(false)}
                className="text-stone-400 hover:text-stone-700 p-1.5 rounded-lg hover:bg-stone-100 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveNewLocation} className="space-y-5">
              
              {/* Classification Selector */}
              <div className="bg-emerald-50/70 p-4 rounded-xl border border-emerald-200/80 space-y-2">
                <label className="text-xs font-bold text-emerald-950 block">
                  Location Classification <span className="text-rose-500">*</span>
                </label>
                <div className="grid grid-cols-2 gap-3 text-xs">
                  <label className={`p-3 rounded-lg border flex items-start gap-2.5 cursor-pointer transition-all ${
                    newLocIsSatellite ? 'bg-white border-emerald-600 shadow-2xs' : 'bg-white/50 border-stone-200 text-stone-600'
                  }`}>
                    <input
                      type="radio"
                      name="modalLocType"
                      checked={newLocIsSatellite}
                      onChange={() => setNewLocIsSatellite(true)}
                      className="mt-0.5 text-emerald-600"
                    />
                    <div>
                      <span className="font-bold text-stone-900 block">Satellite Office / Clinical Annex</span>
                      <span className="text-[11px] text-stone-500">Sub-location, medspa, or regional outpatient surgery bay</span>
                    </div>
                  </label>

                  <label className={`p-3 rounded-lg border flex items-start gap-2.5 cursor-pointer transition-all ${
                    !newLocIsSatellite ? 'bg-white border-emerald-600 shadow-2xs' : 'bg-white/50 border-stone-200 text-stone-600'
                  }`}>
                    <input
                      type="radio"
                      name="modalLocType"
                      checked={!newLocIsSatellite}
                      onChange={() => setNewLocIsSatellite(false)}
                      className="mt-0.5 text-emerald-600"
                    />
                    <div>
                      <span className="font-bold text-stone-900 block">Independent Main Practice</span>
                      <span className="text-[11px] text-stone-500">Distinct surgery center or primary medical facility</span>
                    </div>
                  </label>
                </div>
              </div>

              {/* Core Facility Names */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-stone-700">
                    Practice / Facility Name <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={newLocPracticeName}
                    onChange={(e) => setNewLocPracticeName(e.target.value)}
                    placeholder="e.g. Example Practice Medical Spa"
                    className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 focus:border-emerald-600 text-xs text-stone-900 outline-hidden bg-stone-50/50 focus:bg-white"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-stone-700">
                    Location / Satellite Title <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={newLocBranchName}
                    onChange={(e) => setNewLocBranchName(e.target.value)}
                    placeholder="e.g. Century City - Laser & Clinical Pavilion"
                    className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 focus:border-emerald-600 text-xs text-stone-900 outline-hidden bg-stone-50/50 focus:bg-white"
                  />
                </div>
              </div>

              {/* Type & Specialty */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-stone-700">
                    Facility Type
                  </label>
                  <select
                    value={newLocType}
                    onChange={(e) => setNewLocType(e.target.value as PracticeType)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 focus:border-emerald-600 text-xs text-stone-900 outline-hidden bg-stone-50/50 focus:bg-white"
                  >
                    <option value="Office-based Surgery">Office-based Surgery (OBS)</option>
                    <option value="ASC">Ambulatory Surgical Center (ASC)</option>
                    <option value="Medspa">Medspa & Aesthetic Clinic</option>
                    <option value="General Medical/Surgical">General Medical/Surgical</option>
                    <option value="Surgeon-Owned Operating Suite">Surgeon-Owned Operating Suite</option>
                    <option value="Multispecialty Clinic">Multispecialty Clinic</option>
                  </select>
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-stone-700">
                    Specialty Focus
                  </label>
                  <input
                    type="text"
                    value={newLocSpecialty}
                    onChange={(e) => setNewLocSpecialty(e.target.value)}
                    placeholder="e.g. Laser Aesthetics & Non-Surgical"
                    className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 focus:border-emerald-600 text-xs text-stone-900 outline-hidden bg-stone-50/50 focus:bg-white"
                  />
                </div>
              </div>

              {/* Address Fields */}
              <div className="space-y-3 pt-1 border-t border-stone-200">
                <div className="text-xs font-bold text-stone-800 flex items-center gap-1.5">
                  <MapPin className="w-3.5 h-3.5 text-emerald-700" />
                  <span>Physical Address</span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div className="sm:col-span-3 space-y-1">
                    <label className="text-[11px] font-semibold text-stone-600">Street Address</label>
                    <input
                      type="text"
                      value={newLocStreet}
                      onChange={(e) => setNewLocStreet(e.target.value)}
                      placeholder="e.g. 1900 Avenue of the Stars, Suite 2200"
                      className="w-full px-3 py-2 rounded-xl border border-stone-300 focus:border-emerald-600 text-xs text-stone-900 outline-hidden"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[11px] font-semibold text-stone-600">City *</label>
                    <input
                      type="text"
                      required
                      value={newLocCity}
                      onChange={(e) => setNewLocCity(e.target.value)}
                      placeholder="Los Angeles"
                      className="w-full px-3 py-2 rounded-xl border border-stone-300 focus:border-emerald-600 text-xs text-stone-900 outline-hidden"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[11px] font-semibold text-stone-600">State *</label>
                    <input
                      type="text"
                      required
                      value={newLocState}
                      onChange={(e) => setNewLocState(e.target.value)}
                      placeholder="CA"
                      className="w-full px-3 py-2 rounded-xl border border-stone-300 focus:border-emerald-600 text-xs text-stone-900 outline-hidden"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[11px] font-semibold text-stone-600">ZIP Code</label>
                    <input
                      type="text"
                      value={newLocZip}
                      onChange={(e) => setNewLocZip(e.target.value)}
                      placeholder="90067"
                      className="w-full px-3 py-2 rounded-xl border border-stone-300 focus:border-emerald-600 text-xs text-stone-900 outline-hidden"
                    />
                  </div>
                </div>
              </div>

              {/* Contact Info */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                <div className="space-y-1">
                  <label className="text-[11px] font-semibold text-stone-600">Direct Phone</label>
                  <input
                    type="tel"
                    value={newLocPhone}
                    onChange={(e) => setNewLocPhone(e.target.value)}
                    placeholder="(310) 555-0220"
                    className="w-full px-3 py-2 rounded-xl border border-stone-300 focus:border-emerald-600 text-xs text-stone-900 outline-hidden"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[11px] font-semibold text-stone-600">Location Email</label>
                  <input
                    type="email"
                    value={newLocEmail}
                    onChange={(e) => setNewLocEmail(e.target.value)}
                    placeholder="centurycity@auravanguardsurgical.com"
                    className="w-full px-3 py-2 rounded-xl border border-stone-300 focus:border-emerald-600 text-xs text-stone-900 outline-hidden"
                  />
                </div>
              </div>

              {/* Operating / Procedure Bays */}
              <div className="space-y-1.5 pt-1 border-t border-stone-200">
                <label className="text-xs font-bold text-stone-700 flex items-center justify-between">
                  <span>Operating Rooms & Procedure Bays</span>
                  <span className="text-[10px] text-stone-400 font-normal">Comma-separated</span>
                </label>
                <input
                  type="text"
                  value={newLocRooms}
                  onChange={(e) => setNewLocRooms(e.target.value)}
                  placeholder="e.g. Procedure Suite 1, Treatment Bay 2, Laser Room A"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 focus:border-emerald-600 text-xs text-stone-900 outline-hidden bg-stone-50/50 focus:bg-white"
                />
              </div>

              {/* Modal Actions */}
              <div className="flex items-center justify-end gap-3 pt-4 border-t border-stone-200">
                <button
                  type="button"
                  onClick={() => setIsAddLocationModalOpen(false)}
                  className="px-4 py-2.5 rounded-xl text-xs font-semibold text-stone-600 hover:bg-stone-100 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  id="save-new-location-btn"
                  className="px-5 py-2.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold shadow-md hover:shadow-lg transition-all flex items-center gap-1.5 cursor-pointer"
                >
                  <Plus className="w-4 h-4" />
                  <span>Create Practice Location</span>
                </button>
              </div>

            </form>
          </div>
        </div>
      )}

      {deletingIntakeForm && (
        <div className="fixed inset-0 z-50 bg-stone-950/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl border border-stone-300 shadow-2xl max-w-md w-full p-6 space-y-5 animate-in fade-in zoom-in-95">
            
            <div className="flex items-start gap-3.5">
              <div className="w-10 h-10 rounded-2xl bg-rose-100 text-rose-700 flex items-center justify-center shrink-0">
                <AlertTriangle className="w-5 h-5" />
              </div>
              <div className="space-y-1">
                <h3 className="text-base font-bold text-stone-900">
                  Delete Intake Form?
                </h3>
                <p className="text-xs text-stone-500">
                  This action will permanently unpublish this document from the Patient Portal and check-in kiosks.
                </p>
              </div>
            </div>

            {/* Target Form Summary Box */}
            <div className="p-3.5 rounded-xl bg-stone-50 border border-stone-200 space-y-1.5 text-xs">
              <div className="font-bold text-stone-900">
                {deletingIntakeForm.title}
              </div>
              <div className="text-[11px] text-stone-500 flex items-center gap-2">
                <span className="font-semibold text-emerald-700">{deletingIntakeForm.category}</span>
                <span>•</span>
                <span>{deletingIntakeForm.version}</span>
                <span>•</span>
                <span>{deletingIntakeForm.fileName}</span>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-stone-200">
              <button
                type="button"
                onClick={() => setDeletingIntakeForm(null)}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-stone-600 hover:bg-stone-100 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmDeleteIntakeForm}
                id="confirm-delete-intake-form-btn"
                className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold rounded-xl shadow-xs cursor-pointer flex items-center gap-1.5"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Confirm & Delete Form</span>
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
};
