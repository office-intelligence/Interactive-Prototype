import { SparkWordmark } from '../surgery/asc10/kit';
/*
 * Vityls Front Door shell (shared design layer, phase 1 of the mockup conversion; see mockups/surgery-home.html).
 * Copilot-style: a warm sidebar with a Chat | Practice toggle, New chat, Search, the consolidated headings, past chats and a
 * profile menu (settings, billing, admin live there). Responsive: full sidebar ≥1024px, an icon rail 768–1023px (tablets
 * keep one-tap navigation), a drawer below 768px. Everything is scoped under `.fd` (fd.css) so ASC.Vityls is untouched.
 * The shell is presentational: the app owns routing, data, PIN gates and audit.
 */
import React, { useEffect, useRef, useState } from 'react';
import { ChevronUp, Lock, Menu, MessageSquarePlus, Search, X } from 'lucide-react';
import './fd.css';

export interface FdHeading { id: string; label: string; icon: React.ReactNode; testId: string; badge?: number; locked?: boolean; title?: string }
export interface FdChat { id: string; title: string }
export interface FdMenuItem { label: string; testId: string; run: () => void; locked?: boolean; danger?: boolean; hint?: string }

export const FdShell: React.FC<{
  brand: string; responsive?: boolean; mode: 'chat' | 'practice'; onMode: (m: 'chat' | 'practice') => void; onNewChat: () => void; onSearch: () => void; onLogo: () => void;
  headings: FdHeading[]; active: string; onNav: (id: string) => void;
  chats: FdChat[]; activeChat?: string; onOpenChat: (id: string) => void;
  me: { name: string; role: string }; menu: FdMenuItem[]; menuExtra?: React.ReactNode;
  crumb: React.ReactNode; topRight?: React.ReactNode; children: React.ReactNode;
}> = p => {
  const [drawer, setDrawer] = useState(false); const [menu, setMenu] = useState(false); const meRef = useRef<HTMLDivElement>(null); const menuRef = useRef<HTMLDivElement>(null); const [pos, setPos] = useState<React.CSSProperties>({});
  useEffect(() => { if (!menu) return; const f = (e: MouseEvent) => { const t = e.target as Node; if (meRef.current && !meRef.current.contains(t) && !(menuRef.current && menuRef.current.contains(t))) setMenu(false); }; const k = (e: KeyboardEvent) => { if (e.key === 'Escape') setMenu(false); }; document.addEventListener('mousedown', f); document.addEventListener('keydown', k); return () => { document.removeEventListener('mousedown', f); document.removeEventListener('keydown', k); }; }, [menu]);
  const close = () => setDrawer(false);
  /* v1.2 (Surgery only): expanded ≥1281px, icon rail 900–1280px, drawer <900px; the user's rail choice is saved per band. */
  const sv = p.responsive ?? p.brand === 'Surgery'; /* v2.0.1: Medical and custom practice brands keep the rail/drawer layout */ const bandOf = () => window.innerWidth < 900 ? 'm' : window.innerWidth <= 1280 ? 't' : 'd';
  const [band, setBand] = useState(bandOf); const railKey = (b: string) => `vityls.nav.rail.${b}`;
  const railFor = (b: string) => { const v = localStorage.getItem(railKey(b)); return v === null ? b === 't' : v === '1'; };
  const [rail, setRail] = useState(() => railFor(bandOf()));
  useEffect(() => { if (!sv) return; const f = () => { const b = bandOf(); setBand(b); setRail(railFor(b)); if (b !== 'm') setDrawer(false); }; window.addEventListener('resize', f); return () => window.removeEventListener('resize', f); }, [sv]);
  const toggleRail = () => { const r = !rail; localStorage.setItem(railKey(band), r ? '1' : '0'); setRail(r); };
  const appCls = sv ? `fd-app fd-sv12 fd-b-${band}${band !== 'm' ? (rail ? ' fd-railon' : ' fd-x') : ''}` : 'fd-app';
  const ini = p.me.name.replace(/,.*$/, '').split(/\s+/).map(x => x[0]).join('').toUpperCase().slice(0, 2);
  return <div className={appCls} data-nav={sv ? (band === 'm' ? 'drawer' : rail ? 'rail' : 'expanded') : undefined}>
    {drawer && <div className="fd-ov" onClick={close} aria-hidden="true" />}
    <aside className={`fd-side ${drawer ? 'open' : ''}`} aria-label="Sidebar" data-testid="fd-side">
      <div className="fd-logo"><button type="button" onClick={() => { p.onLogo(); close(); }} data-testid="sv-logo" aria-label={`${p.brand}.Vityls home`}>{p.brand === 'ASC' && (window as any).__vitylsAsc2 ? <span className="v10-brand"><SparkWordmark /></span> : <><span className="fd-mark" aria-hidden="true">🪶</span><span className="fd-lbl">{p.brand}<span className="fd-dim">.Vityls</span></span></>}</button>
        {sv && band !== 'm' && <button type="button" className="fd-icon fd-navtog" onClick={toggleRail} aria-label={rail ? 'Expand navigation' : 'Collapse navigation'} title={rail ? 'Expand menu' : 'Collapse menu'} data-testid="fd-navtog">{rail ? '»' : '«'}</button>}
        <button type="button" className="fd-icon fd-only-m" onClick={close} aria-label="Close menu"><X size={18} /></button></div>
      <div className="fd-seg" role="group" aria-label="Mode">{(['chat', 'practice'] as const).map(m => <button key={m} type="button" aria-pressed={p.mode === m} className={p.mode === m ? 'on' : ''} onClick={() => { p.onMode(m); close(); }} data-testid={`fd-mode-${m}`} title={m === 'chat' ? 'Chat with Nightingale' : 'Practice pages'}><span className="fd-lbl">{m === 'chat' ? 'Chat' : 'Practice'}</span><span className="fd-rail-only" aria-hidden="true">{m === 'chat' ? 'C' : 'P'}</span></button>)}</div>
      <div className="fd-grp">
        <button type="button" className="fd-sl" onClick={() => { p.onNewChat(); close(); }} data-testid="fd-new-chat" title="New chat"><MessageSquarePlus size={17} /><span className="fd-lbl">New chat</span></button>
        <button type="button" className="fd-sl" onClick={() => { p.onSearch(); close(); }} data-testid="fd-search" title="Search"><Search size={17} /><span className="fd-lbl">Search</span></button>
      </div>
      <nav className="fd-grp" aria-label="Primary">{p.headings.map(h => <button key={h.id} type="button" className={`fd-sl ${p.active === h.id ? 'on' : ''} ${h.locked ? 'locked core-locked' : ''}`} aria-current={p.active === h.id ? 'page' : undefined} title={h.title || h.label} onClick={() => { p.onNav(h.id); close(); }} data-testid={h.testId}>{h.icon}<span className="fd-lbl">{h.label}</span>{h.locked && <Lock size={12} className="fd-lk" />}{!!h.badge && <span className="fd-n">{h.badge}</span>}</button>)}</nav>
      <div className="fd-chats" aria-label="Past chats">{p.mode === 'chat' && <>
        <div className="fd-sh fd-lbl">Recent chats</div>
        {p.chats.length === 0 ? <div className="fd-sl fd-muted fd-lbl">No chats yet</div> : p.chats.map(c => <button key={c.id} type="button" className={`fd-sl fd-chat fd-lbl ${p.activeChat === c.id ? 'on' : ''}`} onClick={() => { p.onOpenChat(c.id); close(); }} data-testid="fd-chat-item" title={c.title}>{c.title}</button>)}</>}
      </div>
      <div className="fd-me" ref={meRef}>
        <button type="button" className="fd-me-btn" aria-haspopup="menu" aria-expanded={menu} onClick={e => { const r = (e.currentTarget as HTMLElement).getBoundingClientRect(); setPos({ left: Math.max(8, r.left), bottom: Math.max(8, window.innerHeight - r.top + 6) }); setMenu(o => !o); }} data-testid="fd-profile"><span className="fd-av">{ini}</span><span className="fd-lbl fd-me-txt"><b>{p.me.name.replace(/,.*$/, '')}</b><span>{p.me.role}</span></span><ChevronUp size={15} className="fd-lbl" /></button>
      </div>
    </aside>
    {/* the menu sits outside the sidebar so it layers above station panels */}
    {menu && <div className="fd-menu" role="menu" data-testid="fd-menu" ref={menuRef} style={pos}>
          <div className="fd-menu-who"><b>{p.me.name}</b><span>{p.me.role}</span></div>
          {p.menuExtra}
          {p.menu.map(m => <button key={m.testId} type="button" role="menuitem" className={`fd-mi ${m.danger ? 'danger' : ''} ${m.locked ? 'core-locked' : ''}`} onClick={() => { setMenu(false); close(); m.run(); }} data-testid={m.testId} title={m.hint}>{m.locked && <Lock size={12} />}{m.label}</button>)}
        </div>}
    <div className="fd-body">
      <header className="fd-top" data-testid="fd-top">
        <button type="button" className="fd-icon fd-only-m" onClick={() => setDrawer(true)} aria-label="Open menu" data-testid="fd-hamburger"><Menu size={19} /></button>
        <div className="fd-crumb" data-testid="fd-crumb">{p.crumb}</div>
        <div className="fd-top-r">{p.topRight}</div>
      </header>
      {p.children}
    </div>
  </div>;
};

/** Centered chat hero (greeting, ask box, chips). Used by the Chat home of each edition. */
export const FdHero: React.FC<{ greet: string; sub?: React.ReactNode; box: React.ReactNode; chips?: React.ReactNode; foot?: React.ReactNode; after?: React.ReactNode }> = ({ greet, sub, box, chips, foot, after }) =>
  <div className="fd-hero" data-testid="fd-hero"><div className="fd-col">
    <h1 className="fd-greet" data-testid="fd-greet">{greet}</h1>{sub && <div className="fd-hero-sub">{sub}</div>}{box}{chips && <div className="fd-chips">{chips}</div>}{after}{foot && <div className="fd-disc">{foot}</div>}
  </div></div>;

/** Wide side drawer (stations open here from the Today timeline). */
export const FdDrawer: React.FC<{ title: React.ReactNode; onClose: () => void; children: React.ReactNode; testId?: string }> = ({ title, onClose, children, testId }) => {
  useEffect(() => { const k = (e: KeyboardEvent) => { if (e.key === 'Escape' && !document.querySelector('[role=dialog][aria-modal=true]:not(.fd-drawer)')) onClose(); }; window.addEventListener('keydown', k); document.body.classList.add('fd-drawer-open'); return () => { window.removeEventListener('keydown', k); document.body.classList.remove('fd-drawer-open'); }; }, [onClose]);
  return <><div className="fd-dov" onClick={onClose} aria-hidden="true" /><aside className="fd-drawer" role="dialog" aria-label="Station" data-testid={testId || 'fd-drawer'}>
    <div className="fd-drawer-h"><div className="fd-drawer-t">{title}</div><button type="button" className="fd-icon" onClick={onClose} aria-label="Close panel" data-testid="fd-drawer-close"><X size={18} /></button></div>
    <div className="fd-drawer-b">{children}</div></aside></>;
};
