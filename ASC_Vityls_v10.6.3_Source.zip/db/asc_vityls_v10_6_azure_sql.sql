/* ============================================================================================================
   ASC.Vityls v10.6 · Azure SQL schema (T-SQL, compatibility level 160)
   Companion to DATABASE_HANDOFF_AZURE_SQL_v10.6.md. Conventions: UTC DATETIME2(3); UNIQUEIDENTIFIER keys;
   facility_id on every row (Row-Level Security at the end); legacy_id keeps the test build's string IDs during migration.
   Files live in Azure Blob Storage; SQL keeps the URI + hash. Append-only tables are marked.
   ============================================================================================================ */
CREATE SCHEMA asc;
GO

/* ---------- Practice & people ---------- */
CREATE TABLE asc.facility (
  facility_id      UNIQUEIDENTIFIER NOT NULL CONSTRAINT pk_facility PRIMARY KEY DEFAULT NEWSEQUENTIALID(),
  legacy_id        NVARCHAR(64) NULL,
  name             NVARCHAR(200) NOT NULL,
  address_line1    NVARCHAR(200) NULL, address_line2 NVARCHAR(200) NULL, city NVARCHAR(100) NULL, state CHAR(2) NULL, postal_code NVARCHAR(10) NULL,
  phone            NVARCHAR(30) NULL, email NVARCHAR(254) NULL, website NVARCHAR(254) NULL,
  logo_blob_uri    NVARCHAR(1024) NULL,            -- invoice letterhead
  npi              NVARCHAR(10) NULL, tax_id NVARCHAR(20) NULL,
  time_zone        NVARCHAR(64) NOT NULL DEFAULT N'America/Los_Angeles',
  created_at       DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME()
);
CREATE TABLE asc.room (
  room_id      UNIQUEIDENTIFIER NOT NULL CONSTRAINT pk_room PRIMARY KEY DEFAULT NEWSEQUENTIALID(),
  facility_id  UNIQUEIDENTIFIER NOT NULL REFERENCES asc.facility(facility_id),
  code         NVARCHAR(20) NOT NULL,              -- 'OR 1', 'Proc 1'
  kind         NVARCHAR(20) NOT NULL CHECK (kind IN (N'OR', N'Procedure')),
  active       BIT NOT NULL DEFAULT 1,
  CONSTRAINT uq_room UNIQUE (facility_id, code)
);
CREATE TABLE asc.app_user (
  user_id        UNIQUEIDENTIFIER NOT NULL CONSTRAINT pk_app_user PRIMARY KEY DEFAULT NEWSEQUENTIALID(),
  facility_id    UNIQUEIDENTIFIER NOT NULL REFERENCES asc.facility(facility_id),
  entra_oid      UNIQUEIDENTIFIER NULL,
  display_name   NVARCHAR(200) NOT NULL,
  initials       NVARCHAR(5) NOT NULL,
  primary_role   NVARCHAR(60) NOT NULL,             -- 'Front desk', 'Pre-op RN', 'Anesthesiologist', 'Surgeon', ...
  pin_hash       VARBINARY(256) NULL,               -- Argon2/bcrypt only
  pin_failed     INT NOT NULL DEFAULT 0, pin_locked_until DATETIME2(3) NULL,
  active         BIT NOT NULL DEFAULT 1,
  created_at     DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME()
);
CREATE UNIQUE INDEX uq_app_user_entra ON asc.app_user (entra_oid) WHERE entra_oid IS NOT NULL;
CREATE TABLE asc.provider (
  provider_id   UNIQUEIDENTIFIER NOT NULL CONSTRAINT pk_provider PRIMARY KEY DEFAULT NEWSEQUENTIALID(),
  facility_id   UNIQUEIDENTIFIER NOT NULL REFERENCES asc.facility(facility_id),
  user_id       UNIQUEIDENTIFIER NULL REFERENCES asc.app_user(user_id),
  full_name     NVARCHAR(200) NOT NULL,             -- 'Sam Patel, MD'
  kind          NVARCHAR(20) NOT NULL CHECK (kind IN (N'surgeon', N'anesthesia')),
  npi           NVARCHAR(10) NULL, email NVARCHAR(254) NULL, phone NVARCHAR(30) NULL,
  office_name   NVARCHAR(200) NULL, office_address NVARCHAR(400) NULL,
  active        BIT NOT NULL DEFAULT 1
);
CREATE TABLE asc.patient (
  patient_id       UNIQUEIDENTIFIER NOT NULL CONSTRAINT pk_patient PRIMARY KEY DEFAULT NEWSEQUENTIALID(),
  legacy_id        NVARCHAR(64) NULL,
  full_name        NVARCHAR(200) NOT NULL,
  dob              DATE NOT NULL,
  sex              NVARCHAR(10) NOT NULL CHECK (sex IN (N'Female', N'Male', N'Other')),
  phone            NVARCHAR(30) NULL, email NVARCHAR(254) NULL, language NVARCHAR(40) NULL,
  insurance_text   NVARCHAR(200) NULL, emergency_contact NVARCHAR(300) NULL,
  allergies_confirmed_at DATETIME2(3) NULL, allergies_confirmed_by UNIQUEIDENTIFIER NULL REFERENCES asc.app_user(user_id),
  created_at       DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME()
);
CREATE TABLE asc.facility_patient (
  facility_id UNIQUEIDENTIFIER NOT NULL REFERENCES asc.facility(facility_id),
  patient_id  UNIQUEIDENTIFIER NOT NULL REFERENCES asc.patient(patient_id),
  mrn         NVARCHAR(40) NULL,
  CONSTRAINT pk_facility_patient PRIMARY KEY (facility_id, patient_id)
);
CREATE TABLE asc.patient_allergy (
  allergy_id  UNIQUEIDENTIFIER NOT NULL CONSTRAINT pk_patient_allergy PRIMARY KEY DEFAULT NEWSEQUENTIALID(),
  patient_id  UNIQUEIDENTIFIER NOT NULL REFERENCES asc.patient(patient_id),
  substance   NVARCHAR(200) NOT NULL, reaction NVARCHAR(200) NULL,
  recorded_at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME(), recorded_by UNIQUEIDENTIFIER NULL REFERENCES asc.app_user(user_id)
);
GO

/* ---------- Cases & workflow ---------- */
CREATE TABLE asc.surgical_case (
  case_id          UNIQUEIDENTIFIER NOT NULL CONSTRAINT pk_surgical_case PRIMARY KEY DEFAULT NEWSEQUENTIALID(),
  facility_id      UNIQUEIDENTIFIER NOT NULL REFERENCES asc.facility(facility_id),
  legacy_id        NVARCHAR(64) NULL,               -- 'c4'
  patient_id       UNIQUEIDENTIFIER NOT NULL REFERENCES asc.patient(patient_id),
  dos              DATE NOT NULL,
  booked_start     TIME(0) NOT NULL,
  duration_min     INT NOT NULL CHECK (duration_min > 0),
  room_id          UNIQUEIDENTIFIER NULL REFERENCES asc.room(room_id),
  surgeon_id       UNIQUEIDENTIFIER NOT NULL REFERENCES asc.provider(provider_id),
  anesthesia_id    UNIQUEIDENTIFIER NULL REFERENCES asc.provider(provider_id),
  anesthesia_type  NVARCHAR(20) NULL,               -- General, MAC, Local, Regional
  procedure_text   NVARCHAR(400) NOT NULL,
  cpt              NVARCHAR(20) NULL,
  side             NVARCHAR(20) NULL,
  loc              NVARCHAR(12) NOT NULL DEFAULT N'scheduled'
                   CHECK (loc IN (N'scheduled', N'arrived', N'preop', N'or', N'pacu', N'discharged', N'closed')),
  pay_type         NVARCHAR(60) NULL,               -- payer or 'Self-pay'
  is_self_pay      BIT NOT NULL DEFAULT 0,
  created_at       DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME(),
  updated_at       DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME(),
  row_version      ROWVERSION
);
CREATE INDEX ix_case_day ON asc.surgical_case (facility_id, dos, booked_start) INCLUDE (loc, room_id, surgeon_id);
CREATE INDEX ix_case_patient ON asc.surgical_case (patient_id, dos DESC);

CREATE TABLE asc.case_event (            -- OR times. Edits add a new row (append-only); the latest row per key wins.
  case_event_id  UNIQUEIDENTIFIER NOT NULL CONSTRAINT pk_case_event PRIMARY KEY DEFAULT NEWSEQUENTIALID(),
  facility_id    UNIQUEIDENTIFIER NOT NULL,
  case_id        UNIQUEIDENTIFIER NOT NULL REFERENCES asc.surgical_case(case_id),
  event_key      NVARCHAR(12) NOT NULL CHECK (event_key IN (N'inRoom', N'anesStart', N'incision', N'close', N'anesEnd', N'outRoom', N'pacuIn', N'pacuOut')),
  at_local       TIME(0) NOT NULL, at_text NVARCHAR(12) NOT NULL,   -- '07:34 AM' as entered
  edit_reason    NVARCHAR(400) NULL,                               -- required when correcting
  by_user_id     UNIQUEIDENTIFIER NOT NULL REFERENCES asc.app_user(user_id), by_role NVARCHAR(60) NOT NULL,
  recorded_at    DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME()
);
CREATE INDEX ix_case_event ON asc.case_event (case_id, event_key, recorded_at DESC);

CREATE TABLE asc.case_item_value (       -- the app's case.d map: one row per item key, latest wins; history kept.
  case_item_value_id UNIQUEIDENTIFIER NOT NULL CONSTRAINT pk_case_item_value PRIMARY KEY DEFAULT NEWSEQUENTIALID(),
  facility_id   UNIQUEIDENTIFIER NOT NULL,
  case_id       UNIQUEIDENTIFIER NOT NULL REFERENCES asc.surgical_case(case_id),
  item_key      NVARCHAR(60) NOT NULL,              -- forms, financial, insurance, clearance, labs, id, vitals, npo, iv, sitecheck, exceptions, ...
  value_json    NVARCHAR(MAX) NOT NULL CHECK (ISJSON(value_json) = 1),
  what          NVARCHAR(400) NULL,
  by_user_id    UNIQUEIDENTIFIER NOT NULL REFERENCES asc.app_user(user_id), by_role NVARCHAR(60) NOT NULL,
  recorded_at   DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME(),
  superseded_by UNIQUEIDENTIFIER NULL
);
CREATE INDEX ix_case_item ON asc.case_item_value (case_id, item_key) WHERE superseded_by IS NULL;

CREATE TABLE asc.station_signoff (       -- append-only: one PIN signature per station per case
  signoff_id     UNIQUEIDENTIFIER NOT NULL CONSTRAINT pk_station_signoff PRIMARY KEY DEFAULT NEWSEQUENTIALID(),
  facility_id    UNIQUEIDENTIFIER NOT NULL,
  case_id        UNIQUEIDENTIFIER NOT NULL REFERENCES asc.surgical_case(case_id),
  station        NVARCHAR(20) NOT NULL CHECK (station IN (N'front', N'verify', N'nursing', N'anesthesia', N'surgeon', N'or', N'pacu', N'discharge', N'closure')),
  exceptions_json NVARCHAR(MAX) NULL CHECK (exceptions_json IS NULL OR ISJSON(exceptions_json) = 1),   -- items left open -> flags
  signature_id   UNIQUEIDENTIFIER NULL,
  by_user_id     UNIQUEIDENTIFIER NOT NULL REFERENCES asc.app_user(user_id), by_role NVARCHAR(60) NOT NULL,
  signed_at      DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME()
);
CREATE TABLE asc.case_cancellation (
  cancellation_id UNIQUEIDENTIFIER NOT NULL CONSTRAINT pk_case_cancellation PRIMARY KEY DEFAULT NEWSEQUENTIALID(),
  facility_id UNIQUEIDENTIFIER NOT NULL, case_id UNIQUEIDENTIFIER NOT NULL REFERENCES asc.surgical_case(case_id),
  reason NVARCHAR(400) NOT NULL, by_user_id UNIQUEIDENTIFIER NOT NULL REFERENCES asc.app_user(user_id), by_role NVARCHAR(60) NOT NULL, at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME()
);
CREATE TABLE asc.schedule_history (
  schedule_history_id UNIQUEIDENTIFIER NOT NULL CONSTRAINT pk_schedule_history PRIMARY KEY DEFAULT NEWSEQUENTIALID(),
  facility_id UNIQUEIDENTIFIER NOT NULL, patient_id UNIQUEIDENTIFIER NOT NULL REFERENCES asc.patient(patient_id), case_id UNIQUEIDENTIFIER NULL REFERENCES asc.surgical_case(case_id),
  kind NVARCHAR(20) NOT NULL CHECK (kind IN (N'booked', N'rescheduled', N'cancelled')), from_text NVARCHAR(200) NULL, to_text NVARCHAR(200) NULL, reason NVARCHAR(400) NULL,
  by_user_id UNIQUEIDENTIFIER NOT NULL REFERENCES asc.app_user(user_id), at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME()
);
GO

/* ---------- Forms & signatures ---------- */
CREATE TABLE asc.form_template (
  form_template_id UNIQUEIDENTIFIER NOT NULL CONSTRAINT pk_form_template PRIMARY KEY DEFAULT NEWSEQUENTIALID(),
  facility_id UNIQUEIDENTIFIER NOT NULL, file_name NVARCHAR(200) NOT NULL, title NVARCHAR(200) NOT NULL,
  station NVARCHAR(20) NULL, is_consent BIT NOT NULL DEFAULT 0,     -- consents always open full screen with in-form signature
  template_blob_uri NVARCHAR(1024) NOT NULL, version INT NOT NULL DEFAULT 1, active BIT NOT NULL DEFAULT 1,
  updated_by UNIQUEIDENTIFIER NULL REFERENCES asc.app_user(user_id), updated_at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME()
);
CREATE TABLE asc.signature (             -- append-only
  signature_id UNIQUEIDENTIFIER NOT NULL CONSTRAINT pk_signature PRIMARY KEY DEFAULT NEWSEQUENTIALID(),
  facility_id UNIQUEIDENTIFIER NOT NULL, case_id UNIQUEIDENTIFIER NULL REFERENCES asc.surgical_case(case_id),
  signer_kind NVARCHAR(12) NOT NULL CHECK (signer_kind IN (N'staff', N'patient', N'guardian', N'witness', N'interpreter')),
  signer_name NVARCHAR(200) NOT NULL, signer_user_id UNIQUEIDENTIFIER NULL REFERENCES asc.app_user(user_id),
  image_blob_uri NVARCHAR(1024) NULL, image_sha256 BINARY(32) NULL, pin_verified BIT NOT NULL DEFAULT 0,
  signed_at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME()
);
CREATE TABLE asc.case_form (
  case_form_id UNIQUEIDENTIFIER NOT NULL CONSTRAINT pk_case_form PRIMARY KEY DEFAULT NEWSEQUENTIALID(),
  facility_id UNIQUEIDENTIFIER NOT NULL, case_id UNIQUEIDENTIFIER NOT NULL REFERENCES asc.surgical_case(case_id),
  form_template_id UNIQUEIDENTIFIER NULL REFERENCES asc.form_template(form_template_id),
  kind NVARCHAR(30) NOT NULL,                       -- 'form', 'brief-op-report', 'full-op-report'
  answers_json NVARCHAR(MAX) NOT NULL CHECK (ISJSON(answers_json) = 1),
  status NVARCHAR(12) NOT NULL DEFAULT N'draft' CHECK (status IN (N'draft', N'signed', N'amended')),
  signature_id UNIQUEIDENTIFIER NULL REFERENCES asc.signature(signature_id),
  updated_by UNIQUEIDENTIFIER NOT NULL REFERENCES asc.app_user(user_id), updated_at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME()
);
GO

/* ---------- Standard orders (Practice settings, per surgeon) ---------- */
CREATE TABLE asc.surgeon_order_list (
  order_list_id UNIQUEIDENTIFIER NOT NULL CONSTRAINT pk_surgeon_order_list PRIMARY KEY DEFAULT NEWSEQUENTIALID(),
  facility_id UNIQUEIDENTIFIER NOT NULL,
  surgeon_id UNIQUEIDENTIFIER NULL REFERENCES asc.provider(provider_id),   -- NULL = facility standard
  phase NVARCHAR(4) NOT NULL CHECK (phase IN (N'pre', N'post')), version INT NOT NULL,
  updated_by UNIQUEIDENTIFIER NOT NULL REFERENCES asc.app_user(user_id), updated_at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME()
);
CREATE TABLE asc.surgeon_order_item (
  order_item_id UNIQUEIDENTIFIER NOT NULL CONSTRAINT pk_surgeon_order_item PRIMARY KEY DEFAULT NEWSEQUENTIALID(),
  order_list_id UNIQUEIDENTIFIER NOT NULL REFERENCES asc.surgeon_order_list(order_list_id),
  sort_order INT NOT NULL, text NVARCHAR(1000) NOT NULL
);
CREATE TABLE asc.case_order_list (       -- snapshot taken when the case is booked
  case_order_list_id UNIQUEIDENTIFIER NOT NULL CONSTRAINT pk_case_order_list PRIMARY KEY DEFAULT NEWSEQUENTIALID(),
  facility_id UNIQUEIDENTIFIER NOT NULL, case_id UNIQUEIDENTIFIER NOT NULL REFERENCES asc.surgical_case(case_id),
  phase NVARCHAR(4) NOT NULL CHECK (phase IN (N'pre', N'post')), source_list_id UNIQUEIDENTIFIER NULL REFERENCES asc.surgeon_order_list(order_list_id),
  source_version INT NULL, taken_at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME(),
  CONSTRAINT uq_case_order_list UNIQUE (case_id, phase)
);
CREATE TABLE asc.case_order_item (
  case_order_item_id UNIQUEIDENTIFIER NOT NULL CONSTRAINT pk_case_order_item PRIMARY KEY DEFAULT NEWSEQUENTIALID(),
  case_order_list_id UNIQUEIDENTIFIER NOT NULL REFERENCES asc.case_order_list(case_order_list_id),
  sort_order INT NOT NULL, text NVARCHAR(1000) NOT NULL, one_off BIT NOT NULL DEFAULT 0,
  added_by UNIQUEIDENTIFIER NULL REFERENCES asc.app_user(user_id), added_at DATETIME2(3) NULL
);
CREATE TABLE asc.case_order_tick (       -- append-only; untick = row with ticked = 0
  tick_id UNIQUEIDENTIFIER NOT NULL CONSTRAINT pk_case_order_tick PRIMARY KEY DEFAULT NEWSEQUENTIALID(),
  case_order_item_id UNIQUEIDENTIFIER NOT NULL REFERENCES asc.case_order_item(case_order_item_id),
  ticked BIT NOT NULL, time_text NVARCHAR(12) NOT NULL, initials NVARCHAR(5) NOT NULL,
  by_user_id UNIQUEIDENTIFIER NOT NULL REFERENCES asc.app_user(user_id), by_role NVARCHAR(60) NOT NULL, at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME()
);
GO

/* ---------- Medical history ---------- */
CREATE TABLE asc.case_medical_history (
  case_id UNIQUEIDENTIFIER NOT NULL CONSTRAINT pk_case_medical_history PRIMARY KEY REFERENCES asc.surgical_case(case_id),
  facility_id UNIQUEIDENTIFIER NOT NULL,
  allergies NVARCHAR(MAX) NULL, meds NVARCHAR(MAX) NULL, conditions NVARCHAR(MAX) NULL, surgical NVARCHAR(MAX) NULL, anesthesia NVARCHAR(MAX) NULL, notes NVARCHAR(MAX) NULL,
  drafted_by NVARCHAR(60) NULL,                     -- 'Nightingale' when drafted from the portal
  confirmed_by UNIQUEIDENTIFIER NULL REFERENCES asc.app_user(user_id), confirmed_role NVARCHAR(60) NULL, confirmed_at DATETIME2(3) NULL
);
CREATE TABLE asc.case_medical_history_amendment (
  amendment_id UNIQUEIDENTIFIER NOT NULL CONSTRAINT pk_cmh_amendment PRIMARY KEY DEFAULT NEWSEQUENTIALID(),
  case_id UNIQUEIDENTIFIER NOT NULL REFERENCES asc.case_medical_history(case_id),
  before_json NVARCHAR(MAX) NOT NULL CHECK (ISJSON(before_json) = 1), reason NVARCHAR(400) NOT NULL,
  by_user_id UNIQUEIDENTIFIER NOT NULL REFERENCES asc.app_user(user_id), by_role NVARCHAR(60) NOT NULL, at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME()
);
GO

/* ---------- Documents (bytes in Blob) ---------- */
CREATE TABLE asc.document (
  document_id UNIQUEIDENTIFIER NOT NULL CONSTRAINT pk_document PRIMARY KEY DEFAULT NEWSEQUENTIALID(),
  facility_id UNIQUEIDENTIFIER NOT NULL, legacy_id NVARCHAR(64) NULL,
  patient_id UNIQUEIDENTIFIER NOT NULL REFERENCES asc.patient(patient_id), case_id UNIQUEIDENTIFIER NULL REFERENCES asc.surgical_case(case_id), dos DATE NULL,
  title NVARCHAR(300) NOT NULL,
  kind NVARCHAR(20) NOT NULL CHECK (kind IN (N'H&P', N'Labs', N'ECG', N'Clearance', N'Imaging', N'Records', N'ID', N'Insurance', N'Receipt', N'Consent', N'Other')),
  source NVARCHAR(20) NOT NULL CHECK (source IN (N'upload', N'records', N'fax', N'portal', N'generated')),
  station NVARCHAR(20) NULL, page_count INT NOT NULL DEFAULT 1,
  blob_uri NVARCHAR(1024) NULL, mime NVARCHAR(100) NULL, size_bytes BIGINT NULL, sha256 BINARY(32) NULL, note NVARCHAR(400) NULL,
  uploaded_by UNIQUEIDENTIFIER NULL REFERENCES asc.app_user(user_id), uploaded_role NVARCHAR(60) NULL, uploaded_at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME()
);
CREATE INDEX ix_document_case ON asc.document (case_id, kind);
CREATE TABLE asc.document_page (
  document_id UNIQUEIDENTIFIER NOT NULL REFERENCES asc.document(document_id), page_no INT NOT NULL,
  blob_uri NVARCHAR(1024) NULL, extracted_text NVARCHAR(MAX) NULL,
  CONSTRAINT pk_document_page PRIMARY KEY (document_id, page_no)
);

/* NEW v10.6 · "Reviewed & initialed" on a clearance document (append-only) */
CREATE TABLE asc.clearance_review (
  review_id UNIQUEIDENTIFIER NOT NULL CONSTRAINT pk_clearance_review PRIMARY KEY DEFAULT NEWSEQUENTIALID(),
  facility_id UNIQUEIDENTIFIER NOT NULL, case_id UNIQUEIDENTIFIER NOT NULL REFERENCES asc.surgical_case(case_id),
  document_id UNIQUEIDENTIFIER NOT NULL REFERENCES asc.document(document_id),
  initials NVARCHAR(5) NOT NULL, by_user_id UNIQUEIDENTIFIER NOT NULL REFERENCES asc.app_user(user_id), by_role NVARCHAR(60) NOT NULL,
  reviewed_at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME()
);
CREATE INDEX ix_clearance_review ON asc.clearance_review (case_id, document_id);

/* NEW v10.6 · pen / highlighter / initials stamp on a page. Points normalized to a 1000 x 1294 page box. */
CREATE TABLE asc.document_annotation (
  annotation_id UNIQUEIDENTIFIER NOT NULL CONSTRAINT pk_document_annotation PRIMARY KEY DEFAULT NEWSEQUENTIALID(),
  facility_id UNIQUEIDENTIFIER NOT NULL, case_id UNIQUEIDENTIFIER NOT NULL REFERENCES asc.surgical_case(case_id),
  document_id UNIQUEIDENTIFIER NOT NULL REFERENCES asc.document(document_id), page_no INT NOT NULL,
  tool NVARCHAR(6) NOT NULL CHECK (tool IN (N'pen', N'hi', N'stamp')), color NVARCHAR(9) NOT NULL,
  points_json NVARCHAR(MAX) NULL CHECK (points_json IS NULL OR ISJSON(points_json) = 1),   -- [[x,y],...] for pen/hi
  stamp_x INT NULL, stamp_y INT NULL, stamp_text NVARCHAR(40) NULL,                         -- for stamp
  by_user_id UNIQUEIDENTIFIER NOT NULL REFERENCES asc.app_user(user_id), by_role NVARCHAR(60) NOT NULL,
  created_at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME(),
  voided_at DATETIME2(3) NULL                                                               -- "Undo" / "Clear mine": never deleted
);
CREATE INDEX ix_annotation_page ON asc.document_annotation (document_id, page_no) WHERE voided_at IS NULL;
GO

/* ---------- Notes, flags, messages ---------- */
/* NEW v10.6 · station notes (typed, dictated, or said in chat) */
CREATE TABLE asc.station_note (
  note_id UNIQUEIDENTIFIER NOT NULL CONSTRAINT pk_station_note PRIMARY KEY DEFAULT NEWSEQUENTIALID(),
  facility_id UNIQUEIDENTIFIER NOT NULL, case_id UNIQUEIDENTIFIER NOT NULL REFERENCES asc.surgical_case(case_id),
  station NVARCHAR(30) NOT NULL,                    -- 'Pre-op nursing', 'OR', 'PACU', 'Discharge', ...
  body NVARCHAR(MAX) NOT NULL, source NVARCHAR(10) NOT NULL DEFAULT N'typed' CHECK (source IN (N'typed', N'dictated', N'chat', N'talk')),
  flagged_to_team NVARCHAR(12) NULL, flag_id UNIQUEIDENTIFIER NULL,
  by_user_id UNIQUEIDENTIFIER NOT NULL REFERENCES asc.app_user(user_id), by_role NVARCHAR(60) NOT NULL,
  created_at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME()
);
CREATE INDEX ix_station_note ON asc.station_note (case_id, created_at DESC);

CREATE TABLE asc.flag (                  -- everyone sees all flags; the owner team also gets it in their queue
  flag_id UNIQUEIDENTIFIER NOT NULL CONSTRAINT pk_flag PRIMARY KEY DEFAULT NEWSEQUENTIALID(),
  facility_id UNIQUEIDENTIFIER NOT NULL, patient_id UNIQUEIDENTIFIER NULL REFERENCES asc.patient(patient_id), case_id UNIQUEIDENTIFIER NULL REFERENCES asc.surgical_case(case_id),
  to_team NVARCHAR(12) NOT NULL CHECK (to_team IN (N'front', N'preop', N'pacu', N'anesthesia', N'surgeon', N'or', N'ma', N'coord', N'pm')),
  to_user_id UNIQUEIDENTIFIER NULL REFERENCES asc.app_user(user_id),
  kind NVARCHAR(20) NULL,                           -- 'op-report', 'station-exception', ...
  body NVARCHAR(2000) NOT NULL,
  status NVARCHAR(10) NOT NULL DEFAULT N'open' CHECK (status IN (N'open', N'answered', N'closed')),
  reply NVARCHAR(2000) NULL, replied_by UNIQUEIDENTIFIER NULL REFERENCES asc.app_user(user_id), replied_at DATETIME2(3) NULL,
  from_user_id UNIQUEIDENTIFIER NOT NULL REFERENCES asc.app_user(user_id), from_role NVARCHAR(60) NOT NULL,
  created_at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME()
);
CREATE INDEX ix_flag_open ON asc.flag (facility_id, status, to_team) INCLUDE (case_id, created_at);
ALTER TABLE asc.station_note ADD CONSTRAINT fk_note_flag FOREIGN KEY (flag_id) REFERENCES asc.flag(flag_id);

CREATE TABLE asc.outbox_message (
  message_id UNIQUEIDENTIFIER NOT NULL CONSTRAINT pk_outbox_message PRIMARY KEY DEFAULT NEWSEQUENTIALID(),
  facility_id UNIQUEIDENTIFIER NOT NULL, case_id UNIQUEIDENTIFIER NULL REFERENCES asc.surgical_case(case_id),
  channel NVARCHAR(6) NOT NULL CHECK (channel IN (N'email', N'sms', N'fax')), to_address NVARCHAR(254) NOT NULL,
  subject NVARCHAR(300) NULL, body NVARCHAR(MAX) NULL, attachment_blob_uri NVARCHAR(1024) NULL,
  related_kind NVARCHAR(30) NULL, related_id UNIQUEIDENTIFIER NULL,     -- e.g. 'invoice_delivery'
  status NVARCHAR(12) NOT NULL DEFAULT N'queued' CHECK (status IN (N'queued', N'sent', N'failed', N'delivered')),
  provider_message_id NVARCHAR(200) NULL, error NVARCHAR(1000) NULL,
  created_by UNIQUEIDENTIFIER NULL REFERENCES asc.app_user(user_id), created_at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME(), sent_at DATETIME2(3) NULL
);
GO

/* ---------- Money ---------- */
CREATE TABLE asc.fee_schedule (
  fee_schedule_id UNIQUEIDENTIFIER NOT NULL CONSTRAINT pk_fee_schedule PRIMARY KEY DEFAULT NEWSEQUENTIALID(),
  facility_id UNIQUEIDENTIFIER NOT NULL, name NVARCHAR(100) NOT NULL, surgeon_flat DECIMAL(12,2) NOT NULL DEFAULT 0,
  insured_share_pct DECIMAL(5,2) NOT NULL DEFAULT 0, effective_from DATE NOT NULL, effective_to DATE NULL, active BIT NOT NULL DEFAULT 1
);
CREATE TABLE asc.fee_time_rule (         -- facility and anesthesia time fees
  fee_schedule_id UNIQUEIDENTIFIER NOT NULL REFERENCES asc.fee_schedule(fee_schedule_id),
  component NVARCHAR(12) NOT NULL CHECK (component IN (N'facility', N'anesthesia')),
  base_amount DECIMAL(12,2) NOT NULL, included_min INT NOT NULL, per_increment DECIMAL(12,2) NOT NULL, increment_min INT NOT NULL,
  CONSTRAINT pk_fee_time_rule PRIMARY KEY (fee_schedule_id, component)
);
CREATE TABLE asc.fee_item (
  fee_item_id UNIQUEIDENTIFIER NOT NULL CONSTRAINT pk_fee_item PRIMARY KEY DEFAULT NEWSEQUENTIALID(),
  fee_schedule_id UNIQUEIDENTIFIER NOT NULL REFERENCES asc.fee_schedule(fee_schedule_id),
  category NVARCHAR(20) NOT NULL CHECK (category IN (N'Facility fee', N'Anesthesia', N'Implants', N'Supplies', N'Pathology', N'Other')),
  label NVARCHAR(200) NOT NULL, amount DECIMAL(12,2) NOT NULL, procedure_match NVARCHAR(200) NULL, cpt NVARCHAR(20) NULL, active BIT NOT NULL DEFAULT 1
);
CREATE TABLE asc.invoice (
  invoice_id UNIQUEIDENTIFIER NOT NULL CONSTRAINT pk_invoice PRIMARY KEY DEFAULT NEWSEQUENTIALID(),
  facility_id UNIQUEIDENTIFIER NOT NULL, invoice_number NVARCHAR(30) NOT NULL,
  case_id UNIQUEIDENTIFIER NOT NULL REFERENCES asc.surgical_case(case_id), patient_id UNIQUEIDENTIFIER NOT NULL REFERENCES asc.patient(patient_id),
  dos DATE NOT NULL, pay_type NVARCHAR(60) NOT NULL,
  minutes_basis NVARCHAR(10) NOT NULL CHECK (minutes_basis IN (N'booked', N'recorded')), billed_minutes INT NOT NULL,
  subtotal DECIMAL(12,2) NOT NULL, total DECIMAL(12,2) NOT NULL,
  fee_schedule_id UNIQUEIDENTIFIER NULL REFERENCES asc.fee_schedule(fee_schedule_id),
  created_by UNIQUEIDENTIFIER NOT NULL REFERENCES asc.app_user(user_id), created_at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME(),
  issued_by UNIQUEIDENTIFIER NULL REFERENCES asc.app_user(user_id), issued_at DATETIME2(3) NULL, pdf_blob_uri NVARCHAR(1024) NULL,
  CONSTRAINT uq_invoice_number UNIQUE (facility_id, invoice_number)
);
CREATE TABLE asc.invoice_line (
  invoice_line_id UNIQUEIDENTIFIER NOT NULL CONSTRAINT pk_invoice_line PRIMARY KEY DEFAULT NEWSEQUENTIALID(),
  invoice_id UNIQUEIDENTIFIER NOT NULL REFERENCES asc.invoice(invoice_id),
  sort_order INT NOT NULL, label NVARCHAR(300) NOT NULL, qty DECIMAL(9,2) NOT NULL DEFAULT 1, amount DECIMAL(12,2) NOT NULL, fee_item_id UNIQUEIDENTIFIER NULL REFERENCES asc.fee_item(fee_item_id)
);

/* NEW v10.6 · when and to whom a case is billed */
CREATE TABLE asc.invoice_billing_plan (
  case_id UNIQUEIDENTIFIER NOT NULL CONSTRAINT pk_invoice_billing_plan PRIMARY KEY REFERENCES asc.surgical_case(case_id),
  facility_id UNIQUEIDENTIFIER NOT NULL,
  timing NVARCHAR(4) NOT NULL CHECK (timing IN (N'pre', N'post')),          -- pre: send 14 days before DOS (booked minutes); post: actual in/out-of-room minutes
  bill_to NVARCHAR(8) NOT NULL CHECK (bill_to IN (N'patient', N'surgeon', N'both')),
  set_by UNIQUEIDENTIFIER NULL REFERENCES asc.app_user(user_id), set_at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME()
);
/* NEW v10.6 · each send of an invoice (append-only) */
CREATE TABLE asc.invoice_delivery (
  delivery_id UNIQUEIDENTIFIER NOT NULL CONSTRAINT pk_invoice_delivery PRIMARY KEY DEFAULT NEWSEQUENTIALID(),
  facility_id UNIQUEIDENTIFIER NOT NULL, invoice_id UNIQUEIDENTIFIER NOT NULL REFERENCES asc.invoice(invoice_id),
  case_id UNIQUEIDENTIFIER NOT NULL REFERENCES asc.surgical_case(case_id),
  recipients NVARCHAR(16) NOT NULL CHECK (recipients IN (N'patient', N'surgeon', N'both')),
  addresses NVARCHAR(1000) NOT NULL,                -- comma-separated emails as sent
  timing NVARCHAR(4) NOT NULL CHECK (timing IN (N'pre', N'post')), basis_text NVARCHAR(200) NOT NULL, total DECIMAL(12,2) NOT NULL,
  by_user_id UNIQUEIDENTIFIER NOT NULL REFERENCES asc.app_user(user_id), by_role NVARCHAR(60) NOT NULL, sent_at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME()
);
CREATE TABLE asc.payment (
  payment_id UNIQUEIDENTIFIER NOT NULL CONSTRAINT pk_payment PRIMARY KEY DEFAULT NEWSEQUENTIALID(),
  facility_id UNIQUEIDENTIFIER NOT NULL, receipt_number NVARCHAR(30) NOT NULL, patient_id UNIQUEIDENTIFIER NOT NULL REFERENCES asc.patient(patient_id),
  amount DECIMAL(12,2) NOT NULL CHECK (amount > 0), method NVARCHAR(20) NOT NULL, card_brand NVARCHAR(20) NULL, card_last4 CHAR(4) NULL,  -- never store PAN/CVV
  processor_ref NVARCHAR(100) NULL, reason NVARCHAR(200) NULL, channel NVARCHAR(12) NOT NULL CHECK (channel IN (N'in person', N'phone', N'portal link')),
  taken_by UNIQUEIDENTIFIER NOT NULL REFERENCES asc.app_user(user_id), taken_role NVARCHAR(60) NOT NULL, taken_at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME(),
  CONSTRAINT uq_receipt UNIQUE (facility_id, receipt_number)
);
CREATE TABLE asc.payment_application (
  payment_id UNIQUEIDENTIFIER NOT NULL REFERENCES asc.payment(payment_id), case_id UNIQUEIDENTIFIER NOT NULL REFERENCES asc.surgical_case(case_id),
  amount DECIMAL(12,2) NOT NULL, CONSTRAINT pk_payment_application PRIMARY KEY (payment_id, case_id)
);
CREATE TABLE asc.patient_credit (
  credit_id UNIQUEIDENTIFIER NOT NULL CONSTRAINT pk_patient_credit PRIMARY KEY DEFAULT NEWSEQUENTIALID(),
  facility_id UNIQUEIDENTIFIER NOT NULL, patient_id UNIQUEIDENTIFIER NOT NULL REFERENCES asc.patient(patient_id),
  amount DECIMAL(12,2) NOT NULL, credit_type NVARCHAR(40) NOT NULL, method NVARCHAR(20) NOT NULL, reference NVARCHAR(100) NULL, notes NVARCHAR(400) NULL, receipt_number NVARCHAR(30) NOT NULL,
  by_user_id UNIQUEIDENTIFIER NOT NULL REFERENCES asc.app_user(user_id), by_role NVARCHAR(60) NOT NULL, at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME()
);
CREATE TABLE asc.credit_application (
  credit_id UNIQUEIDENTIFIER NOT NULL REFERENCES asc.patient_credit(credit_id), case_id UNIQUEIDENTIFIER NOT NULL REFERENCES asc.surgical_case(case_id),
  amount DECIMAL(12,2) NOT NULL, at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME(), CONSTRAINT pk_credit_application PRIMARY KEY (credit_id, case_id, at)
);
GO

/* ---------- AI drafts, Talk mode, chat, preferences ---------- */
CREATE TABLE asc.ai_case_draft (         -- Nightingale drafts only; staff confirm
  draft_id UNIQUEIDENTIFIER NOT NULL CONSTRAINT pk_ai_case_draft PRIMARY KEY DEFAULT NEWSEQUENTIALID(),
  facility_id UNIQUEIDENTIFIER NOT NULL, case_id UNIQUEIDENTIFIER NOT NULL REFERENCES asc.surgical_case(case_id),
  kind NVARCHAR(30) NOT NULL,                       -- 'records-brief', 'clearance-summary', 'station-card', 'living-summary'
  station NVARCHAR(20) NULL, content_json NVARCHAR(MAX) NOT NULL CHECK (ISJSON(content_json) = 1),
  sources_json NVARCHAR(MAX) NULL CHECK (sources_json IS NULL OR ISJSON(sources_json) = 1),   -- document/page citations
  model NVARCHAR(60) NULL, created_at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME()
);
/* NEW v10.6 · Talk mode bedside capture */
CREATE TABLE asc.bedside_capture (
  capture_id UNIQUEIDENTIFIER NOT NULL CONSTRAINT pk_bedside_capture PRIMARY KEY DEFAULT NEWSEQUENTIALID(),
  facility_id UNIQUEIDENTIFIER NOT NULL, case_id UNIQUEIDENTIFIER NOT NULL REFERENCES asc.surgical_case(case_id),
  station NVARCHAR(20) NOT NULL, transcript NVARCHAR(MAX) NOT NULL, audio_blob_uri NVARCHAR(1024) NULL,
  drafts_json NVARCHAR(MAX) NOT NULL CHECK (ISJSON(drafts_json) = 1),   -- { nursing:[{text,target}], anesthesia:[...], surgeon:[...] }
  captured_by UNIQUEIDENTIFIER NOT NULL REFERENCES asc.app_user(user_id), captured_at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME(),
  confirmed_by UNIQUEIDENTIFIER NULL REFERENCES asc.app_user(user_id), confirmed_at DATETIME2(3) NULL
);
CREATE TABLE asc.chat_thread (
  chat_id UNIQUEIDENTIFIER NOT NULL CONSTRAINT pk_chat_thread PRIMARY KEY DEFAULT NEWSEQUENTIALID(),
  facility_id UNIQUEIDENTIFIER NOT NULL, user_id UNIQUEIDENTIFIER NOT NULL REFERENCES asc.app_user(user_id),
  title NVARCHAR(200) NOT NULL, created_at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME()
);
CREATE TABLE asc.chat_message (
  chat_message_id UNIQUEIDENTIFIER NOT NULL CONSTRAINT pk_chat_message PRIMARY KEY DEFAULT NEWSEQUENTIALID(),
  chat_id UNIQUEIDENTIFIER NOT NULL REFERENCES asc.chat_thread(chat_id),
  author NVARCHAR(2) NOT NULL CHECK (author IN (N'me', N'ng')), body NVARCHAR(MAX) NOT NULL,
  actions_json NVARCHAR(MAX) NULL CHECK (actions_json IS NULL OR ISJSON(actions_json) = 1),   -- action cards
  cites_json NVARCHAR(MAX) NULL CHECK (cites_json IS NULL OR ISJSON(cites_json) = 1),
  created_at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME()
);
/* NEW v10.6 · per-user preferences: station view (essentials/full), station mode (standard/talk), chat-only */
CREATE TABLE asc.user_preference (
  user_id UNIQUEIDENTIFIER NOT NULL REFERENCES asc.app_user(user_id), pref_key NVARCHAR(60) NOT NULL, pref_value NVARCHAR(400) NOT NULL,
  updated_at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME(), CONSTRAINT pk_user_preference PRIMARY KEY (user_id, pref_key)
);
CREATE TABLE asc.role_preference (
  facility_id UNIQUEIDENTIFIER NOT NULL REFERENCES asc.facility(facility_id), role_name NVARCHAR(60) NOT NULL, pref_key NVARCHAR(60) NOT NULL, pref_value NVARCHAR(400) NOT NULL,
  set_by UNIQUEIDENTIFIER NULL REFERENCES asc.app_user(user_id), updated_at DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME(),
  CONSTRAINT pk_role_preference PRIMARY KEY (facility_id, role_name, pref_key)
);
GO

/* ---------- Audit (ledger, append-only) ---------- */
CREATE TABLE asc.audit_log (
  audit_id    BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT pk_audit_log PRIMARY KEY,
  facility_id UNIQUEIDENTIFIER NOT NULL,
  at          DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME(),
  subject     NVARCHAR(80) NOT NULL,             -- app caseId convention: 'asc8:<case>', 'pt:<patient>', 'practice'
  case_id     UNIQUEIDENTIFIER NULL, patient_id UNIQUEIDENTIFIER NULL,
  user_id     UNIQUEIDENTIFIER NULL, user_name NVARCHAR(200) NOT NULL, user_role NVARCHAR(60) NOT NULL,
  action      NVARCHAR(60) NOT NULL,             -- e.g. asc106.review, asc106.mark, asc106.note, asc106.invoice.sent, asc106.talk
  detail      NVARCHAR(MAX) NULL,
  client_ip   NVARCHAR(45) NULL, device NVARCHAR(100) NULL
) WITH (LEDGER = ON (APPEND_ONLY = ON));
CREATE INDEX ix_audit_case ON asc.audit_log (case_id, at);
GO

/* ---------- Derived views (computed, not stored) ---------- */
CREATE VIEW asc.v_invoice_todo AS        -- front desk: self-pay pre-surgery invoices due 14 days before DOS
SELECT c.facility_id, c.case_id, c.patient_id, c.dos, DATEADD(DAY, -14, c.dos) AS send_by,
       CASE WHEN CAST(SYSUTCDATETIME() AS DATE) > DATEADD(DAY, -14, c.dos) THEN 1 ELSE 0 END AS overdue
FROM asc.surgical_case c
LEFT JOIN asc.invoice_billing_plan p ON p.case_id = c.case_id
WHERE (p.timing = N'pre' OR (p.case_id IS NULL AND c.is_self_pay = 1))
  AND c.loc NOT IN (N'discharged', N'closed')
  AND CAST(SYSUTCDATETIME() AS DATE) >= DATEADD(DAY, -14, c.dos)
  AND NOT EXISTS (SELECT 1 FROM asc.invoice_delivery d WHERE d.case_id = c.case_id AND d.timing = N'pre');
GO
CREATE VIEW asc.v_case_actual_minutes AS -- post-surgery billing basis: actual in/out-of-room minutes (latest edit per key)
SELECT c.case_id,
       DATEDIFF(MINUTE, i.at_local, o.at_local) AS recorded_minutes, c.duration_min AS booked_minutes
FROM asc.surgical_case c
OUTER APPLY (SELECT TOP 1 at_local FROM asc.case_event e WHERE e.case_id = c.case_id AND e.event_key = N'inRoom' ORDER BY recorded_at DESC) i
OUTER APPLY (SELECT TOP 1 at_local FROM asc.case_event e WHERE e.case_id = c.case_id AND e.event_key = N'outRoom' ORDER BY recorded_at DESC) o;
GO

/* ---------- Row-Level Security (shared database, one row filter per facility) ---------- */
CREATE SCHEMA sec;
GO
CREATE FUNCTION sec.fn_facility_filter (@facility_id UNIQUEIDENTIFIER)
RETURNS TABLE WITH SCHEMABINDING AS
RETURN SELECT 1 AS ok WHERE @facility_id = CAST(SESSION_CONTEXT(N'facility_id') AS UNIQUEIDENTIFIER);
GO
/* Add one FILTER + BLOCK predicate per table that carries facility_id, e.g.: */
CREATE SECURITY POLICY sec.facility_policy
  ADD FILTER PREDICATE sec.fn_facility_filter(facility_id) ON asc.surgical_case,
  ADD BLOCK  PREDICATE sec.fn_facility_filter(facility_id) ON asc.surgical_case,
  ADD FILTER PREDICATE sec.fn_facility_filter(facility_id) ON asc.document,
  ADD FILTER PREDICATE sec.fn_facility_filter(facility_id) ON asc.clearance_review,
  ADD FILTER PREDICATE sec.fn_facility_filter(facility_id) ON asc.document_annotation,
  ADD FILTER PREDICATE sec.fn_facility_filter(facility_id) ON asc.station_note,
  ADD FILTER PREDICATE sec.fn_facility_filter(facility_id) ON asc.flag,
  ADD FILTER PREDICATE sec.fn_facility_filter(facility_id) ON asc.invoice,
  ADD FILTER PREDICATE sec.fn_facility_filter(facility_id) ON asc.invoice_delivery,
  ADD FILTER PREDICATE sec.fn_facility_filter(facility_id) ON asc.payment,
  ADD FILTER PREDICATE sec.fn_facility_filter(facility_id) ON asc.audit_log
  WITH (STATE = ON);
GO
/* The API sets the facility once per connection:  EXEC sp_set_session_context @key = N'facility_id', @value = @fid, @read_only = 1; */
