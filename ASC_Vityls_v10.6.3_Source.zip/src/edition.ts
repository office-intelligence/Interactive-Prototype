/*
 * Vityls edition switch (ASC.Vityls vs MED.Vityls). Imported FIRST by main.tsx.
 *
 * A practice uses ONE edition, never both. In production this is `practices.edition` on the server.
 * In this test build:
 *  - Each package has a build default (VITE_EDITION, default 'ASC'). The ASC package behaves exactly as v7.5.
 *  - The practice setting is remembered per package in browser storage and can be changed by an administrator
 *    (Administration > Practice Configuration > Edition, confirmed and audited) or by the test URL switch
 *    `?edition=med` / `?edition=asc` (also audited).
 *  - MED keeps its data in its own namespace inside browser storage (keys prefixed `vityls-med~`), so the ASC
 *    test data in the same browser is never touched. The ASC store stays readable through `rawStorage`, which is
 *    how the simulated Network ASC layer finds the surgeon's ASC cases.
 */
/** Surgery.Vityls (2026-10-09): third value. SURGERY shares the office (MED) code paths, so `isMed` means "office family". */
/** Medical.Vityls v1.0 (2026-10-13): fourth value. MEDICAL runs the Surgery.Vityls code paths with ASC/surgical features
 *  switched off and the Medical terminology layer (src/surgery/terms.ts) on. `isSurgery` means "Surgery family". */
/** ASC.Vityls v8.0 (2026-10-22): fifth value ASC2 = the ASC edition of the Surgery.Vityls codebase (one app, three editions).
 *  Legacy 'ASC' stays the frozen v7.5/7.6 code path. ASC2 runs the Surgery code with src/surgery/asc8 on. */
export type Edition = 'ASC' | 'MED' | 'SURGERY' | 'MEDICAL' | 'ASC2';
import { activePracticeId, practice as corePractice, sweepExpiry, Practice, CORE_ASC, CENTER_ID } from './core/practices';

const env = ((import.meta as any).env || {}) as Record<string, string | undefined>;
const envEd = String(env.VITE_EDITION || '').toUpperCase();
export const BUILD_EDITION: Edition = envEd === 'MED' ? 'MED' : envEd === 'SURGERY' ? 'SURGERY' : envEd === 'MEDICAL' ? 'MEDICAL' : envEd === 'ASC2' ? 'ASC2' : 'ASC';

/** The browser's real storage (never namespaced). Captured before MED installs its namespace. */
export const rawStorage: Storage = window.localStorage;

const SETTING_KEY = `vityls:practice-edition:${BUILD_EDITION.toLowerCase()}-package`;
const EDITION_AUDIT_KEY = 'vityls:practice-edition:audit';
export const MED_NAMESPACE = 'vityls-med~';
export const SURGERY_NAMESPACE = 'vityls-surgery~';
export const MEDICAL_NAMESPACE = 'vityls-medical~';
export const ASC2_NAMESPACE = 'vityls-asc2~';

export interface EditionAuditEntry { at: string; by: string; role: string; from: Edition; to: Edition; reason: string; via: 'administration' | 'test-url' }
export function editionAudit(): EditionAuditEntry[] { try { return JSON.parse(rawStorage.getItem(EDITION_AUDIT_KEY) || '[]'); } catch { return []; } }
function appendEditionAudit(e: EditionAuditEntry) { try { rawStorage.setItem(EDITION_AUDIT_KEY, JSON.stringify([...editionAudit(), e])); } catch { /* storage full: test build */ } }

function resolveEdition(): Edition {
  try {
    const p = new URLSearchParams(location.search).get('edition');
    if (p && /^(med|asc|surgery|medical|asc2)$/i.test(p)) {
      const to = p.toUpperCase() as Edition; const prev = (rawStorage.getItem(SETTING_KEY) as Edition | null) || BUILD_EDITION;
      rawStorage.setItem(SETTING_KEY, to);
      if (prev !== to) appendEditionAudit({ at: new Date().toISOString(), by: 'Tester (URL switch)', role: 'Test build', from: prev, to, reason: `Test URL switch ?edition=${p.toLowerCase()}`, via: 'test-url' });
      return to;
    }
    const s = rawStorage.getItem(SETTING_KEY);
    if (s === 'MED' || s === 'ASC' || s === 'SURGERY' || s === 'MEDICAL' || s === 'ASC2') return s;
  } catch { /* storage unavailable */ }
  return BUILD_EDITION;
}

/** core-modules v1.0: the combined test build (VITE_CORE=1) picks the edition from the active Vityls Core practice. */
export const IS_CORE_BUILD = String(env.VITE_CORE || '') === '1';
let corePrac: Practice | undefined;
if (IS_CORE_BUILD) { try { sweepExpiry(); corePrac = corePractice(activePracticeId(BUILD_EDITION)); } catch { /* */ } }
if (!IS_CORE_BUILD && CORE_ASC) { try { sweepExpiry(); corePrac = corePractice(CENTER_ID); } catch { /* */ } }
export const IS_CORE_ASC = CORE_ASC && !!corePrac;
export const ACTIVE_PRACTICE: Practice | undefined = corePrac;
export const EDITION: Edition = corePrac ? corePrac.runtime : resolveEdition();
/** Office family (MED.Vityls and Surgery.Vityls). */
export const isMed = EDITION === 'MED' || EDITION === 'SURGERY' || EDITION === 'MEDICAL' || EDITION === 'ASC2';
/** Surgery family: Surgery.Vityls and Medical.Vityls share this code. */
export const isSurgery = EDITION === 'SURGERY' || EDITION === 'MEDICAL' || EDITION === 'ASC2';
/** ASC.Vityls v8.0: the ASC edition of the Surgery codebase (day-of-surgery steps, OR, PACU, op report, Operations). */
export const isAscEd = EDITION === 'ASC2';
if (typeof window !== 'undefined') (window as any).__vitylsAsc2 = isAscEd;
/** Medical.Vityls: no ASC, no surgical modules, Doctor terminology. */
export const isMedical = EDITION === 'MEDICAL';
export const isAsc = !isMed;
export const EDITION_LABEL: Record<Edition, string> = { ASC: 'ASC.Vityls', MED: 'MED.Vityls', SURGERY: 'Surgery.Vityls', MEDICAL: 'Medical.Vityls', ASC2: 'ASC.Vityls' };
export const EDITION_EXPLAIN: Record<Edition, string> = {
  ASC: 'Ambulatory surgery center: operating rooms, pre-op clearance, anesthesia, OR team, PACU and time-based facility fees. Use this for a multi-surgeon or multi-specialty surgery center.',
  SURGERY: 'Surgical office: episodic surgical care for a surgeon’s office. Nightingale-led patient chart with a living summary, station workflow from intake links to checkout with an ambient scribe (simulated), visit-type colors, and surgeries and block time from the affiliated ASC on the office schedule. Surgical modules can be switched off for a future Medical.Vityls.',
  MEDICAL: 'Medical office: internal medicine and family practice. Nightingale-led patient chart, station workflow (Portal/At-home, Front desk, Nursing, Doctor), diagnoses and care plans, scheduler, forms editor, records packets.',
  ASC2: 'Ambulatory surgery center on the Surgery.Vityls codebase: seven day-of-surgery steps (pre-admission to billing/close), one view per station, OR times with audit, PACU, op report, Operations.',
  MED: 'Physician office: office visits (check-in, rooming/vitals, provider visit, checkout), a longitudinal chart, surgical risk awareness, lab results and caregiver access in the portal, and a flat practice fee schedule. Use this for a surgeon’s or physician’s office.',
};
/** Roles allowed to change the edition (administrators only). */
export const EDITION_ADMIN_ROLES = ['Practice Administrator', 'Administrator', 'PRACTICE_ADMIN', 'CEO'];

/** Admin-only, confirmed in the UI, audited, then reloads the app in the new edition. */
export function switchEdition(to: Edition, by: string, role: string, reason: string) {
  if (!EDITION_ADMIN_ROLES.some(r => r.toLowerCase() === role.trim().toLowerCase())) throw new Error('Only a practice administrator can change the edition.');
  if (/nightingale|\bai\b/i.test(by) || !by.trim()) throw new Error('A named administrator must confirm this change.');
  if (reason.trim().length < 4) throw new Error('Enter a reason for the change.');
  appendEditionAudit({ at: new Date().toISOString(), by: by.trim(), role, from: EDITION, to, reason: reason.trim(), via: 'administration' });
  rawStorage.setItem(SETTING_KEY, to);
  const u = new URL(location.href); u.searchParams.delete('edition');
  location.replace(u.toString());
}

/* ---------------- MED storage namespace ---------------- */
function installNamespace(prefix: string) {
  const real = rawStorage;
  const keys = () => { const out: string[] = []; for (let i = 0; i < real.length; i++) { const k = real.key(i); if (k && k.startsWith(prefix)) out.push(k.slice(prefix.length)); } return out; };
  const api: Record<string, any> = {
    getItem: (k: string) => real.getItem(prefix + k),
    setItem: (k: string, v: string) => real.setItem(prefix + k, String(v)),
    removeItem: (k: string) => real.removeItem(prefix + k),
    clear: () => keys().forEach(k => real.removeItem(prefix + k)),
    key: (i: number) => keys()[i] ?? null,
  };
  Object.defineProperty(api, 'length', { get: () => keys().length, enumerable: false, configurable: true });
  const proxy = new Proxy(api, {
    get: (t, k) => (k in t ? (t as any)[k] : typeof k === 'string' ? (real.getItem(prefix + k) ?? undefined) : undefined),
    set: (t, k, v) => { if (typeof k === 'string' && !(k in t)) real.setItem(prefix + k, String(v)); return true; },
    has: (t, k) => k in t || (typeof k === 'string' && real.getItem(prefix + k) !== null),
    deleteProperty: (_t, k) => { if (typeof k === 'string') real.removeItem(prefix + k); return true; },
    ownKeys: () => keys(),
    getOwnPropertyDescriptor: (_t, k) => typeof k === 'string' && real.getItem(prefix + k) !== null ? { value: real.getItem(prefix + k), enumerable: true, configurable: true, writable: true } : undefined,
  });
  try { Object.defineProperty(window, 'localStorage', { configurable: true, enumerable: true, get: () => proxy }); }
  catch { console.warn('MED.Vityls: could not namespace browser storage; MED and ASC test data will share keys.'); }
}
if (corePrac) { if (corePrac.namespace) installNamespace(corePrac.namespace); }
else {
if (EDITION === 'MED') installNamespace(MED_NAMESPACE);
if (EDITION === 'SURGERY') installNamespace(SURGERY_NAMESPACE);
if (EDITION === 'MEDICAL') installNamespace(MEDICAL_NAMESPACE);
if (EDITION === 'ASC2') installNamespace(ASC2_NAMESPACE);
}
try { document.documentElement.dataset.edition = EDITION; } catch { /* */ }

/** Keys that belong to the other edition, the edition setting/audit or the simulated network area. A reset of the
 *  ASC test data clears everything else (same as v7.5) but keeps these, so it does not wipe MED test data. */
const PRESERVE_ON_ASC_RESET = ['vityls-med~', 'vityls-surgery~', 'vityls-medical~', 'vityls-asc2~', 'vityls:practice-edition:', 'vityls:network:', 'vityls:core:', 'vityls-p-'];
export function clearAscStorage() {
  try {
    const keys: string[] = []; for (let i = 0; i < rawStorage.length; i++) { const k = rawStorage.key(i); if (k) keys.push(k); }
    keys.filter(k => !PRESERVE_ON_ASC_RESET.some(p => k.startsWith(p))).forEach(k => rawStorage.removeItem(k));
  } catch { /* storage unavailable */ }
}
