/* ASC.Vityls v10.1 · Vendor connector layer (STUBS).
 * Every connector reports "Not connected". Nothing leaves the browser, and no credential is ever stored in the
 * front end: Henry's server holds the keys and calls the vendor. A connector can only be configured once the
 * center's BAA with Vityls AND the vendor's BAA are recorded (BAA gate). Fictional data only. */
import { svRead, svWrite } from '../surgery/store';
import { repo } from '../v6/dataLayer';

export type ConnectorId = 'finix' | 'stedi' | 'acs-sms' | 'acs-email' | 'fax' | 'intake-email';
export interface ConnectorDef { id: ConnectorId; vendor: string; name: string; group: 'billing' | 'notifications'; what: string; ops: string[]; needsVendorBaa: boolean; fields: { k: string; label: string; ph: string }[] }
export const CONNECTORS: ConnectorDef[] = [
  { id: 'finix', vendor: 'Finix', name: 'Card payments', group: 'billing', what: 'Tokenized card payments and SaaS billing. Card numbers go straight to Finix hosted fields; Vityls only keeps a token.', ops: ['tokenize (hosted fields)', 'authorize / capture', 'refund', 'subscriptions'], needsVendorBaa: true, fields: [{ k: 'merchantId', label: 'Finix merchant ID', ph: 'e.g. MU-xxxxxxxx' }, { k: 'env', label: 'Environment', ph: 'e.g. sandbox' }] },
  { id: 'stedi', vendor: 'Stedi', name: 'Insurance (EDI)', group: 'billing', what: 'Eligibility 270/271, claims 837P / 837I, claim status 277CA and remittance 835.', ops: ['270/271 eligibility', '837P professional claim', '837I institutional claim', '277CA acknowledgement', '835 remittance'], needsVendorBaa: true, fields: [{ k: 'submitterId', label: 'Submitter ID', ph: 'e.g. 123456' }, { k: 'env', label: 'Environment', ph: 'e.g. test' }] },
  { id: 'acs-sms', vendor: 'Azure Communication Services', name: 'Text messages (SMS)', group: 'notifications', what: 'Reminders, the next-day text and portal links.', ops: ['send SMS', 'delivery receipts', 'opt-out (STOP)'], needsVendorBaa: true, fields: [{ k: 'from', label: 'Sending number', ph: 'e.g. (310) 555-1234' }] },
  { id: 'acs-email', vendor: 'Azure Communication Services', name: 'Email', group: 'notifications', what: 'Appointment, portal and records emails.', ops: ['send email', 'delivery status'], needsVendorBaa: true, fields: [{ k: 'from', label: 'From address', ph: 'e.g. frontdesk@yourcenter.com' }] },
  { id: 'fax', vendor: 'Documo or Sinch', name: 'Fax in / out', group: 'notifications', what: 'Inbound faxes land in Booking intake; records packets go out by fax.', ops: ['receive fax (webhook)', 'send fax', 'status'], needsVendorBaa: true, fields: [{ k: 'provider', label: 'Provider', ph: 'e.g. Documo' }, { k: 'number', label: 'Fax number', ph: 'e.g. (310) 555-1234' }] },
  { id: 'intake-email', vendor: 'Vityls', name: 'Intake email address', group: 'notifications', what: 'A forwarding address; Nightingale reads referral mail and files attachments (Email intake module).', ops: ['receive mail (webhook)', 'parse attachments'], needsVendorBaa: false, fields: [{ k: 'address', label: 'Intake address', ph: 'e.g. intake@yourcenter.vityls.com' }] },
];
export interface Baa { centerSignedBy?: string; centerSignedAt?: string; vendors: Partial<Record<ConnectorId, { by: string; at: string }>> }
export const baa = (): Baa => svRead<Baa>('asc10-baa', { vendors: {} });
const saveBaa = (b: Baa) => svWrite('asc10-baa', b);
const aud = (by: string, role: string, detail: string) => repo.audit({ caseId: 'practice', user: by, role, action: 'asc10.connector' as any, detail });
export function signCenterBaa(by: string, role: string) { saveBaa({ ...baa(), centerSignedBy: by, centerSignedAt: new Date().toISOString() }); aud(by, role, 'Center BAA with Vityls recorded (PIN)'); }
export function recordVendorBaa(id: ConnectorId, by: string, role: string) { const b = baa(); saveBaa({ ...b, vendors: { ...b.vendors, [id]: { by, at: new Date().toISOString() } } }); aud(by, role, `Vendor BAA recorded: ${def(id).vendor}`); }
export const def = (id: ConnectorId) => CONNECTORS.find(c => c.id === id)!;
/** BAA gate: center BAA plus (if needed) the vendor's BAA. */
export function gate(id: ConnectorId): { open: boolean; missing: string[] } {
  const b = baa(); const m: string[] = []; if (!b.centerSignedAt) m.push('Center BAA with Vityls'); if (def(id).needsVendorBaa && !b.vendors[id]) m.push(`${def(id).vendor} BAA`); return { open: !m.length, missing: m };
}
export type ConnStatus = 'not-connected' | 'configured';
export interface ConnConfig { status: ConnStatus; values: Record<string, string>; by: string; at: string }
export const configs = () => svRead<Partial<Record<ConnectorId, ConnConfig>>>('asc10-connectors', {});
export const status = (id: ConnectorId): ConnStatus => configs()[id]?.status || 'not-connected';
export function configure(id: ConnectorId, values: Record<string, string>, by: string, role: string) {
  const g = gate(id); if (!g.open) throw new Error(`BAA needed first: ${g.missing.join(', ')}`);
  if (Object.values(values).some(v => /sk_|secret|password|-----BEGIN/i.test(v))) throw new Error('Do not enter keys or passwords here. Credentials are set on the server.');
  svWrite('asc10-connectors', { ...configs(), [id]: { status: 'configured', values, by, at: new Date().toISOString() } }); aud(by, role, `${def(id).vendor} · ${def(id).name} settings saved (awaiting server connection)`);
}
/** Runtime calls. All of them refuse until Henry's server implements them. */
export class NotConnected extends Error { constructor(id: ConnectorId, op: string) { super(`${def(id).vendor} is not connected (${op}).`); this.name = 'NotConnected'; } }
const nc = (id: ConnectorId, op: string) => async (..._a: unknown[]): Promise<never> => { throw new NotConnected(id, op); };
export const finix = { tokenize: nc('finix', 'tokenize'), charge: nc('finix', 'charge'), refund: nc('finix', 'refund'), subscribe: nc('finix', 'subscription') };
export const stedi = { eligibility270: nc('stedi', '270/271'), claim837P: nc('stedi', '837P'), claim837I: nc('stedi', '837I'), status277CA: nc('stedi', '277CA'), remit835: nc('stedi', '835') };
export const acs = { sms: nc('acs-sms', 'send SMS'), email: nc('acs-email', 'send email') };
export const fax = { send: nc('fax', 'send fax') };
export const intakeEmail = { address: () => configs()['intake-email']?.values.address || '' };
