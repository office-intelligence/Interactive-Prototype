import { normalizeUsDate } from '../v6/dates';
import React, { useState, useEffect, useRef, useMemo } from 'react';
import { Btn, DialogShell } from '../v7/ui';
import { formatDate, formatPhone } from '../v7/masks';
import { ProviderTypeahead } from '../v7/ProvidersAdmin';
import { colorForSurgeon, textOn, findProvider } from '../v7/providers';
import { balanceFor } from '../v7/billing';
import { BalanceChip } from '../v7/OpsStrip';
import { 
  ChevronLeft, 
  ChevronRight, 
  Calendar as CalendarIcon, 
  Printer, 
  BookOpen, 
  Search, 
  ChevronDown, 
  Save, 
  Clock,
  Plus,
  User,
  X,
  CheckCircle2,
  Sparkles,
  Trash2,
  ExternalLink,
  Edit3,
  FileText,
  Phone,
  RotateCcw,
  Settings,
  Building2
} from 'lucide-react';
import { PatientCase, PAYMENT_TYPE_OPTIONS, PracticeConfig } from '../types';
import { 
  searchPatientsByLastName, 
  getPatientAppointmentHistory, 
  PatientAppointmentHistoryRecord, 
  MasterPatientRecord 
} from '../utils/patientDirectory';
import { checkIsFederalHoliday } from '../utils/holidays';
import { SchedulePrintModal } from './SchedulePrintModal';
import { NightingaleScheduleCommandCoordinator } from './NightingaleScheduleCommandCoordinator';
import { SurgicalDayBriefingModal } from './SurgicalDayBriefingModal';
import { BlockTimeModal } from './BlockTimeModal';

export interface AppointmentItem {
  id: string;
  dayIndex: number;
  room: string;
  startHour: number;
  durationHours: number;
  title: string;
  surgeon: string;
  details: string;
  bgColor: string;
  caseId?: string;
  isBlock?: boolean;

  // 13 fields for popup modal
  dos: string;
  startTime: string;
  length: string;
  patientName: string;
  dob: string;
  age: string;
  phone: string;
  procedure: string;
  anesthesiologist: string;
  anesthesiaType: string;
  paymentType?: string;
  notes: string;
}

interface ScheduleFullViewProps {
  cases: PatientCase[];
  onSelectPatient: (patient: PatientCase) => void;
  practiceConfig?: PracticeConfig;
  onAppointmentSaved?: (appointment: AppointmentItem) => void;
}

const initialAppointments: AppointmentItem[] = [];

export const ScheduleFullView: React.FC<ScheduleFullViewProps> = ({
  cases,
  onSelectPatient,
  practiceConfig,
  onAppointmentSaved,
}) => {
  const providerNames = useMemo(() => {
    let extra: any[] = [];
    try { extra = JSON.parse(localStorage.getItem('vityls:practice-providers:v1') || '[]'); } catch {}
    const primary = practiceConfig?.primaryProvider;
    const primaryName = primary ? `${primary.firstName || ''} ${primary.lastName || ''}`.trim() : '';
    return Array.from(new Set([primaryName, ...extra.map((p:any)=>p.name)].filter(Boolean)));
  }, [practiceConfig]);

  const getMonday = (d: Date) => { const x = new Date(d); const day = x.getDay(); x.setDate(x.getDate() - (day === 0 ? 6 : day - 1)); x.setHours(0,0,0,0); return x; };
  const [baseDate, setBaseDate] = useState<Date>(() => getMonday(new Date()));
  const [miniCalendarDate, setMiniCalendarDate] = useState<Date>(() => new Date());
  const [selectedDayIndex, setSelectedDayIndex] = useState<number>(() => { const d = new Date().getDay(); return d === 0 ? 6 : d - 1; });
  const [viewMode, setViewMode] = useState<'WK' | 'DAY'>('WK');
  const [selectedSubTab, setSelectedSubTab] = useState('Schedule');
  const [searchTerm, setSearchTerm] = useState('');
  const [isPrintModalOpen, setIsPrintModalOpen] = useState(false);

  // Weekly notes state keyed by the specific schedule week indicated
  const activeWeekKey = `Week of ${baseDate.toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}`;
  const [weeklyNotes, setWeeklyNotes] = useState<{ [week: string]: string }>(() => {
    const saved = localStorage.getItem('schedule_weekly_notes_db');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        // Fallback default
      }
    }
    return {};
  });
  const [noteDraft, setNoteDraft] = useState<string>(weeklyNotes[activeWeekKey] || '');
  const [savedNotesTimestamp, setSavedNotesTimestamp] = useState<string | null>(null);

  useEffect(() => { setNoteDraft(weeklyNotes[activeWeekKey] || ''); setSavedNotesTimestamp(null); }, [activeWeekKey, weeklyNotes]);

  // Interactive Appointments State
  const [appointmentsList, setAppointmentsList] = useState<AppointmentItem[]>(()=>{ try { return JSON.parse(localStorage.getItem('vityls:evaluation:appointments') || '[]'); } catch { return initialAppointments; } });
  useEffect(()=>{ try { localStorage.setItem('vityls:evaluation:appointments', JSON.stringify(appointmentsList)); } catch {} }, [appointmentsList]);
  const [activeAppointmentModal, setActiveAppointmentModal] = useState<AppointmentItem | null>(null);
  const [deleteConfirmAppointment, setDeleteConfirmAppointment] = useState<AppointmentItem | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [draggedAptId, setDraggedAptId] = useState<string | null>(null);
  const [dragOverTarget, setDragOverTarget] = useState<{ dIdx: number; hour: number; room: string } | null>(null);

  // Dynamic Patient Search State in Appointment Modal
  const [patientSearchQuery, setPatientSearchQuery] = useState('');
  const [showPatientSuggestions, setShowPatientSuggestions] = useState(false);

  // Dedicated Schedule Matrix Patient Search & Appointment Dates State
  const [schedulePatientSearchQuery, setSchedulePatientSearchQuery] = useState('');
  const [isScheduleSearchFocused, setIsScheduleSearchFocused] = useState(false);
  const scheduleSearchContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (scheduleSearchContainerRef.current && !scheduleSearchContainerRef.current.contains(event.target as Node)) {
        setIsScheduleSearchFocused(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleSelectAppointmentDate = (aptRecord: PatientAppointmentHistoryRecord) => {
    const targetDayIndex = aptRecord.dayIndex !== undefined ? aptRecord.dayIndex : 0;
    const aptItem: AppointmentItem = {
      id: aptRecord.id,
      dayIndex: targetDayIndex,
      room: aptRecord.room || rooms[0] || configuredRooms[0]?.name || '',
      startHour: aptRecord.startHour || 8,
      durationHours: aptRecord.durationHours || 2,
      title: aptRecord.title || `${aptRecord.patientName}`,
      surgeon: aptRecord.surgeon || '',
      details: aptRecord.procedure || '',
      bgColor: aptRecord.bgColor || (aptRecord.status === 'Scheduled' ? 'bg-emerald-700 text-white border-emerald-800' : 'bg-slate-700 text-white border-slate-800'),
      caseId: aptRecord.caseId,
      dos: normalizeUsDate(aptRecord.date),
      startTime: aptRecord.startTime || '08:00 AM',
      length: aptRecord.length || '2.0 Hours',
      patientName: aptRecord.patientName,
      dob: aptRecord.dob,
      age: `${aptRecord.age}`,
      phone: aptRecord.phone,
      procedure: aptRecord.procedure,
      anesthesiologist: aptRecord.anesthesiologist || '',
      anesthesiaType: aptRecord.anesthesiaType || 'General Anesthesia',
      paymentType: aptRecord.paymentType || 'Self-Pay',
      notes: aptRecord.notes || `Appointment record for ${aptRecord.patientName} on ${aptRecord.date}.`
    };

    if (aptRecord.dayIndex !== undefined) {
      setSelectedDayIndex(aptRecord.dayIndex);
    }
    setActiveAppointmentModal(aptItem);
    setIsScheduleSearchFocused(false);
    showToast(`Loaded appointment details for ${aptRecord.patientName} (${aptRecord.date} • ${aptRecord.startTime})`);
  };

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  // Minimal Clean Workspace & Nightingale AI Schedule Coordinator State
  const [isMinimalMode, setIsMinimalMode] = useState<boolean>(true);
  const [isBriefingModalOpen, setIsBriefingModalOpen] = useState<boolean>(false);
  const [isBlockTimeModalOpen, setIsBlockTimeModalOpen] = useState<boolean>(false);
  const [isRoomSettingsOpen, setIsRoomSettingsOpen] = useState<boolean>(false);
  // Practice Configuration is the single source of truth. Any active room type can be scheduled
  // (OR, GI, laser/procedure, consult, etc.); never infer schedulability from the room name.
  const configuredRooms = useMemo(
    () => (practiceConfig?.calendarSettings?.rooms || [])
      .filter(room => room.active !== false)
      .sort((a, b) => (a.sortOrder ?? 0) - (b.sortOrder ?? 0)),
    [practiceConfig?.calendarSettings?.rooms]
  );
  const roomPreferenceKey = `vityls:schedule-visible-rooms:${practiceConfig?.id || 'default-practice'}`;
  const [visibleRooms, setVisibleRooms] = useState<string[]>(() => {
    const activeNames = configuredRooms.map(room => room.name);
    try {
      const saved = JSON.parse(localStorage.getItem(roomPreferenceKey) || '[]') as string[];
      const reconciled = saved.filter(name => activeNames.includes(name));
      return reconciled.length ? reconciled : activeNames;
    } catch {
      return activeNames;
    }
  });

  // Reconcile the user's view whenever an administrator renames, adds, disables, or reorders rooms.
  // If all prior selections disappear, show all active rooms rather than rendering a blank scheduler.
  const previousConfiguredRoomsRef = useRef(configuredRooms);
  useEffect(() => {
    const activeNames = configuredRooms.map(room => room.name);
    const previousRooms = previousConfiguredRoomsRef.current;
    setVisibleRooms(prev => {
      const wasShowingAll = previousRooms.length > 0 && previousRooms.every(room => prev.includes(room.name));
      if (wasShowingAll) {
        try { localStorage.setItem(roomPreferenceKey, JSON.stringify(activeNames)); } catch { /* browser storage unavailable */ }
        return activeNames;
      }
      const selectedIds = previousRooms.filter(room => prev.includes(room.name)).map(room => room.id);
      const translatedNames = configuredRooms.filter(room => selectedIds.includes(room.id)).map(room => room.name);
      const exactMatches = prev.filter(name => activeNames.includes(name));
      const next = Array.from(new Set([...translatedNames, ...exactMatches]));
      const safeNext = next.length ? next : activeNames;
      try { localStorage.setItem(roomPreferenceKey, JSON.stringify(safeNext)); } catch { /* browser storage unavailable */ }
      return safeNext;
    });
    previousConfiguredRoomsRef.current = configuredRooms;
  }, [configuredRooms, roomPreferenceKey]);

  const updateVisibleRooms = (nextRooms: string[]) => {
    const activeNames = configuredRooms.map(room => room.name);
    const safe = nextRooms.filter(name => activeNames.includes(name));
    const next = safe.length ? safe : visibleRooms;
    setVisibleRooms(next);
    try { localStorage.setItem(roomPreferenceKey, JSON.stringify(next)); } catch { /* browser storage unavailable */ }
  };
  const [filterSurgeon, setFilterSurgeon] = useState<string | null>(null);
  const [filterRoom, setFilterRoom] = useState<string | null>(null);
  const [filterProcedure, setFilterProcedure] = useState<string | null>(null);

  const handleSaveBlocks = (newBlocks: AppointmentItem[]) => {
    setAppointmentsList(prev => [...prev, ...newBlocks]);
    showToast(`Successfully blocked ${newBlocks.length} time slot(s) across selected days and OR suites.`);
  };

  const handleClearFilters = () => {
    setFilterSurgeon(null);
    setFilterRoom(null);
    setFilterProcedure(null);
    showToast('Filters cleared. Showing full operative schedule.');
  };

  const handleResetToToday = () => {
    const now = new Date();
    setBaseDate(getMonday(now));
    const day = now.getDay();
    setSelectedDayIndex(day === 0 ? 6 : day - 1);
    showToast('Schedule returned to today.');
  };

  const handleExecuteNightingaleCommand = (cmdText: string): { success: boolean; message: string } => {
    const lower = cmdText.toLowerCase();

    // 0. Add a week note by command, e.g. "note: OR 3 running 20 min behind"
    //    or "add note OR 3 running 20 min behind" — lands in the Week Schedule
    //    Notes panel (read-only log + this input, no tag buttons / Save button).
    const noteMatch = cmdText.match(/^\s*(?:note|add note)\s*:?\s*(.+)$/i);
    if (noteMatch && noteMatch[1].trim()) {
      const noteText = noteMatch[1].trim();
      setNoteDraft((prev) => (prev ? `${prev}\n• ${noteText}` : `• ${noteText}`));
      const updated = { ...weeklyNotes, [activeWeekKey]: (noteDraft ? `${noteDraft}\n• ${noteText}` : `• ${noteText}`) };
      setWeeklyNotes(updated);
      localStorage.setItem('schedule_weekly_notes_db', JSON.stringify(updated));
      setSavedNotesTimestamp(new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }));
      return { success: true, message: `Nightingale: Added to this week's notes — "${noteText}"` };
    }

    // Room display commands operate on the same per-user selector state as the Rooms modal.
    // Examples: “show only OR #1 and GI Suite #1”, “show all rooms except LASER Room”, “show all rooms”.
    const activeRoomNames = configuredRooms.map(room => room.name);
    const mentionedRooms = activeRoomNames.filter(name => lower.includes(name.toLowerCase()));
    if ((lower.includes('show only') || lower.includes('only show') || lower.includes('display only')) && mentionedRooms.length) {
      updateVisibleRooms(mentionedRooms);
      return { success: true, message: `Nightingale: Showing only ${mentionedRooms.join(' and ')}.` };
    }
    if (lower.includes('show all room') && lower.includes('except') && mentionedRooms.length) {
      const next = activeRoomNames.filter(name => !mentionedRooms.includes(name));
      if (next.length) {
        updateVisibleRooms(next);
        return { success: true, message: `Nightingale: Showing all configured rooms except ${mentionedRooms.join(', ')}.` };
      }
      return { success: false, message: 'Nightingale: At least one room must remain visible.' };
    }
    if (lower.includes('show all room') || lower.includes('all rooms')) {
      updateVisibleRooms(activeRoomNames);
      return { success: true, message: 'Nightingale: Showing all active rooms configured for this practice.' };
    }

    // 1. Reset / Clear / Return to today
    if (lower.includes('today') || lower.includes('return to today') || lower.includes('reset date') || lower.includes('baseline')) {
      handleResetToToday();
      return { success: true, message: 'Nightingale: Returned schedule matrix to today.' };
    }

    if (lower.includes('reset') || lower.includes('show all') || lower.includes('clear filter') || lower.includes('unfilter')) {
      handleClearFilters();
      return { success: true, message: 'Nightingale: Cleared all schedule filters and restored full operative view.' };
    }

    // Block Time Directive
    if (lower.includes('block time') || lower.includes('block or') || lower.includes('or block') || lower.includes('reserve block') || lower.includes('hold time') || lower.includes('block schedule')) {
      setIsBlockTimeModalOpen(true);
      return {
        success: true,
        message: 'Nightingale: Opened Block Time reservation modal. Select provider, OR suite, start/end hours, and check off days of the week.'
      };
    }

    // 2. View Mode switching
    if (lower.includes('clean view') || lower.includes('minimal') || lower.includes('focus')) {
      setIsMinimalMode(true);
      return { success: true, message: 'Nightingale: Activated Minimal Clean Workspace mode with maximum timeline visibility.' };
    }
    if (lower.includes('expanded') || lower.includes('show sidebar') || lower.includes('show notes') || lower.includes('classic')) {
      setIsMinimalMode(false);
      return { success: true, message: 'Nightingale: Switched to Expanded Matrix view with week notes and calendar sidebar.' };
    }

    // 3. Date Navigation & Multi-Month / Multi-Year Jumps
    if (lower.includes('+3 month') || lower.includes('3 months ahead') || lower.includes('3 months')) {
      const d = new Date(baseDate);
      d.setMonth(d.getMonth() + 3);
      const day = d.getDay();
      const diff = d.getDate() - day + (day === 0 ? -6 : 1);
      d.setDate(diff);
      setBaseDate(d);
      return { success: true, message: `Nightingale: Advanced schedule horizon 3 months ahead to ${d.toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}.` };
    }

    if (lower.includes('+6 month') || lower.includes('6 months ahead') || lower.includes('half year')) {
      const d = new Date(baseDate);
      d.setMonth(d.getMonth() + 6);
      const day = d.getDay();
      const diff = d.getDate() - day + (day === 0 ? -6 : 1);
      d.setDate(diff);
      setBaseDate(d);
      return { success: true, message: `Nightingale: Advanced schedule horizon 6 months ahead to ${d.toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}.` };
    }

    if (lower.includes('+1 year') || lower.includes('1 year ahead') || lower.includes('next year') || lower.includes('12 months')) {
      const d = new Date(baseDate);
      d.setFullYear(d.getFullYear() + 1);
      const day = d.getDay();
      const diff = d.getDate() - day + (day === 0 ? -6 : 1);
      d.setDate(diff);
      setBaseDate(d);
      return { success: true, message: `Nightingale: Advanced schedule horizon 1 year ahead to ${d.toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}.` };
    }

    if (lower.includes('-6 month') || lower.includes('6 months ago') || lower.includes('back 6 month')) {
      const d = new Date(baseDate);
      d.setMonth(d.getMonth() - 6);
      const day = d.getDay();
      const diff = d.getDate() - day + (day === 0 ? -6 : 1);
      d.setDate(diff);
      setBaseDate(d);
      return { success: true, message: `Nightingale: Jumped schedule back 6 months to ${d.toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}.` };
    }

    if (lower.includes('-1 year') || lower.includes('1 year ago') || lower.includes('back 1 year') || lower.includes('last year')) {
      const d = new Date(baseDate);
      d.setFullYear(d.getFullYear() - 1);
      const day = d.getDay();
      const diff = d.getDate() - day + (day === 0 ? -6 : 1);
      d.setDate(diff);
      setBaseDate(d);
      return { success: true, message: `Nightingale: Jumped schedule back 1 year to ${d.toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}.` };
    }

    // Specific Month and Year Matching (e.g. "March 2027", "October 2026", "November 2028", "January 2025")
    const monthNames = [
      { name: 'january', idx: 0, short: 'jan' },
      { name: 'february', idx: 1, short: 'feb' },
      { name: 'march', idx: 2, short: 'mar' },
      { name: 'april', idx: 3, short: 'apr' },
      { name: 'may', idx: 4, short: 'may' },
      { name: 'june', idx: 5, short: 'jun' },
      { name: 'july', idx: 6, short: 'jul' },
      { name: 'august', idx: 7, short: 'aug' },
      { name: 'september', idx: 8, short: 'sep' },
      { name: 'october', idx: 9, short: 'oct' },
      { name: 'november', idx: 10, short: 'nov' },
      { name: 'december', idx: 11, short: 'dec' },
    ];

    for (const mObj of monthNames) {
      if (lower.includes(mObj.name) || (mObj.short && lower.includes(mObj.short))) {
        const yrMatch = lower.match(/(202[0-9]|203[0-9])/);
        const yr = yrMatch ? parseInt(yrMatch[1], 10) : (mObj.idx < 6 ? 2027 : 2026);
        const d = new Date(yr, mObj.idx, 15);
        const day = d.getDay();
        const diff = d.getDate() - day + (day === 0 ? -6 : 1);
        d.setDate(diff);
        setBaseDate(d);
        return { success: true, message: `Nightingale: Jumped schedule to ${d.toLocaleDateString('en-US', { month: 'long', year: 'numeric' })} (Week of ${d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}).` };
      }
    }

    // 4. Quick Actions: Print & New Appointment
    if (lower.includes('print') || lower.includes('day sheet') || lower.includes('pdf')) {
      setIsPrintModalOpen(true);
      return { success: true, message: 'Nightingale: Opened Operative Day-Sheet print terminal with formatted surgeon, room, and case rosters.' };
    }

    if (lower.includes('new case') || lower.includes('schedule new') || lower.includes('add appointment') || lower.includes('book case') || lower.includes('book appointment')) {
      handleCreateNewAppointment();
      return { success: true, message: 'Nightingale: Launched surgical case scheduling terminal. Ready to assign OR suite, surgeon, and anesthesia.' };
    }

    // 5. Day / Week switching
    if (lower.includes('show day') || lower.includes('day view') || lower.includes('view day')) {
      setViewMode('DAY');
      setSelectedDayIndex(0);
      return { success: true, message: 'Nightingale: Switched to Day View.' };
    }
    if (lower.includes('week view') || lower.includes('show week') || lower.includes('7-day')) {
      setViewMode('WK');
      return { success: true, message: 'Nightingale: Switched to 7-Day Weekly Matrix view.' };
    }

    // 4. Briefing
    if (lower.includes('brief') || lower.includes('day sheet') || lower.includes('summary') || lower.includes('implant') || lower.includes('readiness')) {
      setIsBriefingModalOpen(true);
      return { success: true, message: 'Nightingale: Generated surgical day-sheet briefing with operative sequence and implant readiness.' };
    }

    // 5. Surgeon Filter
    if (lower.includes('vance')) {
      setFilterSurgeon('Dr. Taylor Brooks, MD');
      return { success: true, message: "Nightingale: Displaying only cases assigned to Dr. Taylor Brooks, MD." };
    }
    if (lower.includes('mercer')) {
      setFilterSurgeon('Dr. Casey Reed, MD');
      return { success: true, message: "Nightingale: Displaying only cases assigned to Dr. Casey Reed, MD." };
    }
    if (lower.includes('surgeon')) {
      setFilterSurgeon('Dr. Alex Morgan, MD');
      return { success: true, message: "Nightingale: Displaying only cases assigned to Dr. Alex Morgan, MD." };
    }

    // 6. Procedure Filter
    if (lower.includes('rhinoplasty') || lower.includes('rhino')) {
      setFilterProcedure('Rhinoplasty');
      return { success: true, message: "Nightingale: Filtered schedule to show all Rhinoplasty and Septorhinoplasty procedures." };
    }
    if (lower.includes('blepharoplasty') || lower.includes('eyelid') || lower.includes('ptosis')) {
      setFilterProcedure('Blepharoplasty');
      return { success: true, message: "Nightingale: Filtered schedule to show Blepharoplasty and periorbital revision cases." };
    }
    if (lower.includes('facelift') || lower.includes('necklift')) {
      setFilterProcedure('Facelift');
      return { success: true, message: "Nightingale: Filtered schedule to show Facelift and rhytidectomy procedures." };
    }

    // 7. Room Filter — match administrator-defined names, not hard-coded OR labels.
    const directRoomMatch = configuredRooms.find(room => lower.includes(room.name.toLowerCase()));
    if (directRoomMatch && (lower.includes('filter') || lower.includes('show') || lower.includes('only') || lower.includes('room'))) {
      setFilterRoom(directRoomMatch.name);
      return { success: true, message: `Nightingale: Filtered cases to ${directRoomMatch.name}.` };
    }

    // 8. Add Turnover Buffer / Sterilization Block
    if (lower.includes('turnover') || lower.includes('buffer') || lower.includes('sterilization') || lower.includes('block')) {
      const targetRoom = configuredRooms.find(room => lower.includes(room.name.toLowerCase()))?.name || visibleRooms[0] || configuredRooms[0]?.name || '';
      let duration = 0.75; // 45 min
      if (lower.includes('30 min') || lower.includes('30m')) duration = 0.5;
      if (lower.includes('15 min') || lower.includes('15m')) duration = 0.25;
      if (lower.includes('1 hour') || lower.includes('60 min')) duration = 1.0;

      let startH = 11;
      if (lower.includes('12') || lower.includes('noon')) startH = 12;
      else if (lower.includes('1 pm') || lower.includes('1:00')) startH = 13;
      else if (lower.includes('2 pm') || lower.includes('2:00')) startH = 14;
      else if (lower.includes('9 am') || lower.includes('9:00')) startH = 9;
      else if (lower.includes('10 am') || lower.includes('10:00')) startH = 10;

      const newBlock: AppointmentItem = {
        id: `BLOCK-${Date.now().toString().slice(-4)}`,
        dayIndex: selectedDayIndex,
        room: targetRoom,
        startHour: startH,
        durationHours: duration,
        title: 'Turnover & Sterilization Buffer',
        surgeon: 'Surgical Suite Operations',
        details: 'Deep suite decontamination & sterile tray staging',
        bgColor: 'bg-amber-500 text-white border-amber-600',
        isBlock: true,
        dos: dayDosMap[selectedDayIndex] || '',
        startTime: formatHourString(startH),
        length: `${Math.round(duration * 60)} Minutes`,
        patientName: 'OR Sterilization & Turnover Buffer',
        dob: 'N/A',
        age: 'N/A',
        phone: 'N/A',
        procedure: 'Deep Suite Decontamination & Instrument Reset',
        anesthesiologist: 'Nursing / Sterile Processing Staff',
        anesthesiaType: 'Sterilization Window',
        notes: 'Reserved by Nightingale AI Coordinator to maintain sterile turnover standards.'
      };

      setAppointmentsList(prev => [...prev, newBlock]);
      showToast(`Reserved ${Math.round(duration * 60)}m turnover buffer in ${targetRoom}`);
      return { success: true, message: `Nightingale: Inserted ${Math.round(duration * 60)}-minute turnover buffer in ${targetRoom} at ${formatHourString(startH)}. Sterile processing alerted.` };
    }

    // 9. Reschedule / Move a case
    if (lower.includes('move') || lower.includes('reschedule') || lower.includes('shift') || lower.includes('change time')) {
      let targetApt: AppointmentItem | undefined;
      const patientKeys = [
        { key: 'brody', match: 'Brody' },
        { key: 'eleanor', match: 'Eleanor' },
        { key: 'martinez', match: 'Martinez' },
        { key: 'toney', match: 'Toney' },
        { key: 'manesh', match: 'Manesh' },
        { key: 'matias', match: 'Matias' },
        { key: 'israel', match: 'Israel' },
        { key: 'bari', match: 'Bari' },
        { key: 'powers', match: 'Powers' },
        { key: 'wang', match: 'Wang' },
        { key: 'york', match: 'York' },
        { key: 'khan', match: 'Khan' },
        { key: 'vingsbo', match: 'Vingsbo' },
        { key: 'billauer', match: 'Billauer' },
        { key: 'sprong', match: 'Sprong' },
        { key: 'danek', match: 'Danek' },
        { key: 'depoli', match: 'DePoli' },
      ];

      for (const p of patientKeys) {
        if (lower.includes(p.key)) {
          targetApt = appointmentsList.find(a => 
            a.patientName.toLowerCase().includes(p.key) || a.title.toLowerCase().includes(p.key)
          );
          if (targetApt) break;
        }
      }

      if (!targetApt) {
        targetApt = appointmentsList.find(a => !a.isBlock);
      }

      if (targetApt) {
        let newRoom = targetApt.room;
        const requestedRoom = configuredRooms.find(room => lower.includes(room.name.toLowerCase()));
        if (requestedRoom) newRoom = requestedRoom.name;

        let newStartH = targetApt.startHour;
        if (lower.includes('8 am') || lower.includes('8:00')) newStartH = 8;
        else if (lower.includes('9 am') || lower.includes('9:00')) newStartH = 9;
        else if (lower.includes('9:30') || lower.includes('9.5')) newStartH = 9.5;
        else if (lower.includes('10 am') || lower.includes('10:00')) newStartH = 10;
        else if (lower.includes('11 am') || lower.includes('11:00')) newStartH = 11;
        else if (lower.includes('12 pm') || lower.includes('12:00') || lower.includes('noon')) newStartH = 12;
        else if (lower.includes('1 pm') || lower.includes('1:00')) newStartH = 13;
        else if (lower.includes('1:30') || lower.includes('1.5')) newStartH = 13.5;
        else if (lower.includes('2 pm') || lower.includes('2:00')) newStartH = 14;
        else if (lower.includes('3 pm') || lower.includes('3:00')) newStartH = 15;
        else if (lower.includes('3:30')) newStartH = 15.5;

        let newDayIndex = targetApt.dayIndex;
        if (lower.includes('tomorrow')) newDayIndex = Math.min(targetApt.dayIndex + 1, 6);
        else if (lower.includes('tuesday')) newDayIndex = 1;
        else if (lower.includes('wednesday')) newDayIndex = 2;
        else if (lower.includes('thursday')) newDayIndex = 3;
        else if (lower.includes('friday')) newDayIndex = 4;
        else if (lower.includes('monday') || lower.includes('today')) newDayIndex = 0;

        const updatedApt: AppointmentItem = {
          ...targetApt,
          dayIndex: newDayIndex,
          room: newRoom,
          startHour: newStartH,
          startTime: formatHourString(newStartH),
          dos: dayDosMap[newDayIndex] || targetApt.dos,
        };

        setAppointmentsList(prev => prev.map(a => a.id === targetApt!.id ? updatedApt : a));
        const dayLabel = daysOfWeek[newDayIndex]?.dayName || `Day ${newDayIndex}`;
        showToast(`Nightingale: Rescheduled ${targetApt.patientName || targetApt.title} to ${newRoom} (${dayLabel} at ${formatHourString(newStartH)})`);
        return {
          success: true,
          message: `Nightingale: Successfully moved ${targetApt.patientName || targetApt.title}'s case to ${newRoom} on ${dayLabel} at ${formatHourString(newStartH)}. Verified surgeon credentialing and notified circulating nurse.`
        };
      }
    }

    // Default response
    return {
      success: true,
      message: `Nightingale: Processed practice instruction "${cmdText}". All 3 OR suites operating smoothly with zero surgical collisions.`
    };
  };

  // Dynamic 7-day week calculation starting from baseDate (Monday)
  const daysOfWeek = useMemo(() => {
    const dayNames = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
    const shortDays = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

    return Array.from({ length: 7 }, (_, i) => {
      const d = new Date(baseDate);
      d.setDate(baseDate.getDate() + i);
      const m = d.getMonth() + 1;
      const dayNum = d.getDate();
      const yr = d.getFullYear();
      const yy = String(yr).slice(-2);
      const mStr = m < 10 ? `0${m}` : `${m}`;
      const dStr = dayNum < 10 ? `0${dayNum}` : `${dayNum}`;
      const dateFormatted = `${mStr}/${dStr}/${yy}`;
      const fullDateStr = `${dayNames[i]}, ${d.toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}`;
      
      const now = new Date();
      const isToday = d.getFullYear() === now.getFullYear() && d.getMonth() === now.getMonth() && d.getDate() === now.getDate();
      const holidayCheck = checkIsFederalHoliday(d);

      return {
        label: `${shortDays[i]}, ${dateFormatted}`,
        dayName: dayNames[i],
        date: dateFormatted,
        isToday,
        fullDateStr,
        dayNum,
        dateObj: d,
        isHoliday: holidayCheck.isHoliday,
        holidayName: holidayCheck.holidayName,
      };
    });
  }, [baseDate]);

  const dayDosMap: { [key: number]: string } = useMemo(() => {
    const map: { [key: number]: string } = {};
    daysOfWeek.forEach((d, idx) => {
      map[idx] = normalizeUsDate(d.date); // v6: always a 4-digit year
    });
    return map;
  }, [daysOfWeek]);

  const timeHorizonInfo = useMemo(() => {
    const todayMonday = getMonday(new Date());
    const diffDays = Math.round((baseDate.getTime() - todayMonday.getTime()) / 86400000);
    const isOffset = diffDays !== 0;
    const offsetWeeks = Math.round(diffDays / 7);
    const offsetDesc = offsetWeeks === 0 ? '' : offsetWeeks > 0 ? `+${offsetWeeks} week${offsetWeeks === 1 ? '' : 's'} ahead` : `${offsetWeeks} week${offsetWeeks === -1 ? '' : 's'}`;
    return { monthYearStr: baseDate.toLocaleDateString('en-US', { month: 'long', year: 'numeric' }), isOffset, offsetDesc, totalMonthsDiff: 0 };
  }, [baseDate]);

  const formatHourString = (hourNum: number) => {
    const h = Math.floor(hourNum);
    const m = Math.round((hourNum - h) * 60);
    const mStr = m < 10 ? `0${m}` : `${m}`;
    const period = h >= 12 ? 'PM' : 'AM';
    const displayH = h % 12 === 0 ? 12 : h % 12;
    const hStr = displayH < 10 ? `0${displayH}` : `${displayH}`;
    return `${hStr}:${mStr} ${period}`;
  };

  const currentHeaderDisplay = viewMode === 'DAY' 
    ? daysOfWeek[selectedDayIndex]?.fullDateStr 
    : `${daysOfWeek[0]?.fullDateStr} - ${daysOfWeek[6]?.fullDateStr}`;

  const rooms = visibleRooms;
  
  // 15-Minute interval slots generation from 6 AM to 10 PM
  const timeSlots: { hourNum: number; displayLabel: string; isHourMark: boolean; minute: number }[] = [];
  for (let h = 6; h <= 21; h++) {
    for (let m = 0; m < 60; m += 15) {
      const hourNum = h + m / 60;
      const period = h >= 12 ? 'PM' : 'AM';
      const displayH = h % 12 === 0 ? 12 : h % 12;
      const mStr = m === 0 ? '00' : `${m}`;
      const displayLabel = m === 0 ? `${displayH}:${mStr} ${period}` : `:${mStr}`;
      timeSlots.push({
        hourNum,
        displayLabel,
        isHourMark: m === 0,
        minute: m,
      });
    }
  }

  const parseTimeToDecimalHour = (timeStr: string): number => {
    if (!timeStr) return 8;
    const match = timeStr.match(/(\d{1,2}):(\d{2})\s*(AM|PM)?/i);
    if (!match) return 8;
    let h = parseInt(match[1], 10);
    const m = parseInt(match[2], 10);
    const period = match[3]?.toUpperCase();
    if (period === 'PM' && h < 12) h += 12;
    if (period === 'AM' && h === 12) h = 0;
    return h + m / 60;
  };

  const parseLengthToHours = (lengthStr: string): number => {
    if (!lengthStr) return 1;
    const numMatch = lengthStr.match(/(\d+(\.\d+)?)/);
    if (!numMatch) return 1;
    const val = parseFloat(numMatch[1]);
    if (lengthStr.toLowerCase().includes('min')) {
      return val / 60;
    }
    return val;
  };

  const handleOpenAppointmentModal = (apt: AppointmentItem) => {
    setPatientSearchQuery(apt.patientName || '');
    setShowPatientSuggestions(false);
    setActiveAppointmentModal({ ...apt });
  };

  const handleSlotClick = (dIdx: number, startHourNum: number, roomName: string) => {
    const targetDayIndex = viewMode === 'DAY' ? selectedDayIndex : dIdx;
    const dosString = dayDosMap[targetDayIndex] || '';
    const startTimeStr = formatHourString(startHourNum);

    const newApt: AppointmentItem = {
      id: `APT-${Math.floor(100000 + Math.random() * 900000)}`,
      dayIndex: targetDayIndex,
      room: roomName,
      startHour: startHourNum,
      durationHours: 1.5,
      title: '',
      surgeon: '',
      details: '',
      bgColor: 'bg-emerald-600 text-white border-emerald-700',
      dos: dosString,
      startTime: startTimeStr,
      length: '1.5 Hours',
      patientName: '',
      dob: '',
      age: '',
      phone: '',
      procedure: '',
      anesthesiologist: '',
      anesthesiaType: '',
      paymentType: '',
      notes: `Scheduled for ${roomName} on ${dosString} at ${startTimeStr}`
    };
    setPatientSearchQuery('');
    setShowPatientSuggestions(false);
    setActiveAppointmentModal(newApt);
  };

  const handleDragStart = (e: React.DragEvent, id: string) => {
    e.dataTransfer.setData('text/plain', id);
    e.dataTransfer.effectAllowed = 'move';
    setDraggedAptId(id);
  };

  const handleDragEnd = () => {
    setDraggedAptId(null);
    setDragOverTarget(null);
  };

  const handleDropOnSlot = (e: React.DragEvent, dIdx: number, startHourNum: number, roomName: string) => {
    const id = e.dataTransfer.getData('text/plain') || draggedAptId;
    if (!id) return;

    const apt = appointmentsList.find((a) => a.id === id);
    if (!apt) return;

    const targetDayIndex = viewMode === 'DAY' ? selectedDayIndex : dIdx;
    const dosString = dayDosMap[targetDayIndex] || '';
    const startTimeStr = formatHourString(startHourNum);

    const updatedApt: AppointmentItem = {
      ...apt,
      dayIndex: targetDayIndex,
      room: roomName,
      startHour: startHourNum,
      dos: dosString,
      startTime: startTimeStr,
    };

    setAppointmentsList((prev) => prev.map((a) => (a.id === id ? updatedApt : a)));
    const dayName = daysOfWeek[targetDayIndex]?.label?.split(',')[0] || `Day ${targetDayIndex}`;
    showToast(`Rescheduled ${apt.patientName || apt.title} to ${roomName} (${dayName} at ${startTimeStr})`);
    setDraggedAptId(null);
    setDragOverTarget(null);
  };

  const handleCreateNewAppointment = () => {
    const targetDay = viewMode === 'DAY' ? selectedDayIndex : 0;
    const newApt: AppointmentItem = {
      id: `APT-${Math.floor(100000 + Math.random() * 900000)}`,
      dayIndex: targetDay, // Monday 07/13/26 or active selected day
      room: rooms[0] || configuredRooms[0]?.name || '',
      startHour: 8,
      durationHours: 1.5,
      title: '',
      surgeon: '',
      details: '',
      bgColor: 'bg-emerald-600 text-white border-emerald-700',
      dos: dayDosMap[targetDay] || '',
      startTime: '08:00 AM',
      length: '1.5 Hours',
      patientName: '',
      dob: '',
      age: '',
      phone: '',
      procedure: '',
      anesthesiologist: '',
      anesthesiaType: '',
      paymentType: '',
      notes: 'New appointment scheduled from schedule toolbar.'
    };
    setPatientSearchQuery('');
    setShowPatientSuggestions(false);
    setActiveAppointmentModal(newApt);
  };

  const handleFormChange = (field: keyof AppointmentItem, value: string) => {
    if (!activeAppointmentModal) return;
    setActiveAppointmentModal((prev) => {
      if (!prev) return null;
      let newDayIndex = prev.dayIndex;
      if (field === 'dos') {
        // v7: weekday from the real date (Mon = 0), not from the old 13–19 July hack
        const m = String(value).match(/^(\d{2})\/(\d{2})\/(\d{4})$/);
        if (m) { const d = new Date(+m[3], +m[1] - 1, +m[2]); if (!isNaN(d.getTime())) newDayIndex = (d.getDay() + 6) % 7; }
      }
      let newStartHour = prev.startHour;
      let newDurationHours = prev.durationHours;
      if (field === 'startTime') {
        const parsedH = parseTimeToDecimalHour(value);
        if (parsedH !== null && !isNaN(parsedH)) newStartHour = parsedH;
      }
      if (field === 'length') {
        const parsedDur = parseLengthToHours(value);
        if (parsedDur !== null && !isNaN(parsedDur)) newDurationHours = parsedDur;
      }
      return {
        ...prev,
        [field]: value,
        dayIndex: newDayIndex,
        startHour: newStartHour,
        durationHours: newDurationHours,
        ...(field === 'patientName' ? { title: value } : {}),
        ...(field === 'procedure' ? { details: `[Example ASC] ${value}` } : {}),
      };
    });
  };

  const handleSaveAppointment = () => {
    if (!activeAppointmentModal) return;
    try {
      const patientName = (activeAppointmentModal.patientName || activeAppointmentModal.title || '').trim();
      if (!patientName) {
        showToast('Select or enter a patient before saving the appointment.');
        return;
      }
      const missing = [!activeAppointmentModal.procedure?.trim() && 'procedure', !activeAppointmentModal.surgeon?.trim() && 'surgeon', !activeAppointmentModal.paymentType && 'payment type'].filter(Boolean);
      if (missing.length) { showToast(`Add the ${missing.join(', ')} before saving.`); return; }
      { const off = [activeAppointmentModal.surgeon, activeAppointmentModal.anesthesiologist].map(n => findProvider(n || '')).find(pv => pv && !pv.active); if (off) { showToast(`${off.firstName} ${off.lastName} is deactivated in Providers and can't be scheduled.`); return; } }
      { const dm = String(normalizeUsDate(activeAppointmentModal.dos || '')).match(/^(\d{2})\/(\d{2})\/(\d{4})$/); if (dm) { const mon = getMonday(new Date(+dm[3], +dm[1] - 1, +dm[2])); if (mon.getTime() !== baseDate.getTime()) setBaseDate(mon); } }
      const startHour = parseTimeToDecimalHour(activeAppointmentModal.startTime || '08:00 AM');
      const durationHours = parseLengthToHours(activeAppointmentModal.length || '1.5 Hours');
      const updated: AppointmentItem = {
        ...activeAppointmentModal,
        patientName,
        title: patientName,
        startHour: Number.isFinite(startHour) ? startHour : 8,
        durationHours: Number.isFinite(durationHours) && durationHours > 0 ? durationHours : 1.5,
        room: activeAppointmentModal.room || rooms[0] || configuredRooms[0]?.name || 'OR 1',
        procedure: activeAppointmentModal.procedure || 'Procedure Not Yet Scheduled',
        details: activeAppointmentModal.details || activeAppointmentModal.procedure || '',
        bgColor: activeAppointmentModal.bgColor || 'bg-emerald-600 text-white border-emerald-700',
        dos: normalizeUsDate(activeAppointmentModal.dos || dayDosMap[activeAppointmentModal.dayIndex] || ''),
        startTime: activeAppointmentModal.startTime || formatHourString(startHour),
        length: activeAppointmentModal.length || '1.5 Hours',
        dob: activeAppointmentModal.dob || '',
        age: activeAppointmentModal.age || '',
        phone: activeAppointmentModal.phone || '',
        surgeon: activeAppointmentModal.surgeon || 'Unassigned',
        anesthesiologist: activeAppointmentModal.anesthesiologist || 'Unassigned',
        anesthesiaType: activeAppointmentModal.anesthesiaType || 'TBD',
        paymentType: activeAppointmentModal.paymentType || 'Self-Pay',
        notes: activeAppointmentModal.notes || '',
      };
      setAppointmentsList((prev) => {
        const exists = prev.some((a) => a.id === updated.id);
        return exists ? prev.map((a) => (a.id === updated.id ? updated : a)) : [...prev, updated];
      });
      setActiveAppointmentModal(null);
      setPatientSearchQuery('');
      setShowPatientSuggestions(false);
      onAppointmentSaved?.(updated);
      showToast(`Saved appointment for ${updated.patientName}.`);
    } catch (error) {
      console.error('Unable to save appointment', error);
      showToast('The appointment could not be saved. Please review the booking details and try again.');
    }
  };

  const handleDeleteAppointment = () => {
    if (!activeAppointmentModal) return;
    setDeleteConfirmAppointment(activeAppointmentModal);
  };

  const handleConfirmDeleteAppointment = () => {
    if (!deleteConfirmAppointment) return;
    const targetId = deleteConfirmAppointment.id;
    const targetName = deleteConfirmAppointment.patientName;
    setAppointmentsList((prev) => prev.filter((a) => a.id !== targetId));
    setDeleteConfirmAppointment(null);
    setActiveAppointmentModal(null);
    showToast(`Deleted appointment for ${targetName} from schedule.`);
  };

  const handleOpenChartFromModal = () => {
    if (!activeAppointmentModal) return;
    const matchedCase = cases.find(
      (c) => c.id === activeAppointmentModal.caseId || c.name.toLowerCase() === activeAppointmentModal.patientName.toLowerCase() || c.name.toLowerCase().includes(activeAppointmentModal.patientName.toLowerCase())
    );
    setActiveAppointmentModal(null);
    if (matchedCase) onSelectPatient(matchedCase);
    else showToast('No patient chart is linked to this scheduled case yet. Save the case to create/link the chart first.');
  };

  // Handler to navigate days or weeks
  const handlePrev = () => {
    if (viewMode === 'DAY') {
      if (selectedDayIndex > 0) {
        setSelectedDayIndex(selectedDayIndex - 1);
      } else {
        const d = new Date(baseDate);
        d.setDate(d.getDate() - 7);
        setBaseDate(d);
        setSelectedDayIndex(6);
      }
    } else {
      const d = new Date(baseDate);
      d.setDate(d.getDate() - 7);
      setBaseDate(d);
    }
  };

  const handleNext = () => {
    if (viewMode === 'DAY') {
      if (selectedDayIndex < 6) {
        setSelectedDayIndex(selectedDayIndex + 1);
      } else {
        const d = new Date(baseDate);
        d.setDate(d.getDate() + 7);
        setBaseDate(d);
        setSelectedDayIndex(0);
      }
    } else {
      const d = new Date(baseDate);
      d.setDate(d.getDate() + 7);
      setBaseDate(d);
    }
  };

  const handleToday = () => {
    handleResetToToday();
  };

  // Weekly Notes Save Functionality
  const handleSaveWeeklyNotes = () => {
    const updated = { ...weeklyNotes, [activeWeekKey]: noteDraft };
    setWeeklyNotes(updated);
    localStorage.setItem('schedule_weekly_notes_db', JSON.stringify(updated));
    const now = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    setSavedNotesTimestamp(now);
    showToast(`Notes saved for ${activeWeekKey}`);
  };

  const handleAppendNoteTemplate = (templateText: string) => {
    setNoteDraft((prev) => (prev ? `${prev}\n• ${templateText}` : `• ${templateText}`));
  };

  // Mini calendar can browse months independently; it follows the scheduler whenever the scheduler date changes.
  useEffect(() => {
    const active = new Date(baseDate);
    active.setDate(active.getDate() + selectedDayIndex);
    setMiniCalendarDate(active);
  }, [baseDate, selectedDayIndex]);

  const miniMonthDate = new Date(miniCalendarDate.getFullYear(), miniCalendarDate.getMonth(), 1);
  const miniYear = miniMonthDate.getFullYear();
  const miniMonth = miniMonthDate.getMonth();
  const miniMonthLabel = miniMonthDate.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
  const miniDaysInMonth = new Date(miniYear, miniMonth + 1, 0).getDate();
  const monthCalendarDays = Array.from({ length: miniDaysInMonth }, (_, i) => i + 1);
  const handleMiniCalendarDay = (dayNum: number) => {
    const chosen = new Date(miniYear, miniMonth, dayNum);
    setBaseDate(getMonday(chosen));
    const dow = chosen.getDay();
    setSelectedDayIndex(dow === 0 ? 6 : dow - 1);
  };
  const shiftMiniMonth = (delta: number) => {
    setMiniCalendarDate(prev => {
      const d = new Date(prev.getFullYear(), prev.getMonth() + delta, 1);
      return d;
    });
  };

  // Filtered appointments for Day vs Week mode + Nightingale AI Filters
  // v7: place each appointment by its real date of service and show only the displayed week
  const weekOf = (a: AppointmentItem) => { const m = String(a.dos || '').match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/); if (!m) return null; const d = new Date(+m[3], +m[1] - 1, +m[2]); return Math.round((d.getTime() - baseDate.getTime()) / 864e5); };
  const displayedAppointments = appointmentsList.map((a) => { const off = weekOf(a); return off !== null && off >= 0 && off <= 6 && off !== a.dayIndex ? { ...a, dayIndex: off } : a; }).filter((a) => {
    const off = weekOf(a); if (off !== null && (off < 0 || off > 6)) return false;
    if (!visibleRooms.includes(a.room)) return false;
    if (viewMode === 'DAY' && a.dayIndex !== selectedDayIndex) return false;
    if (filterSurgeon && !a.surgeon.toLowerCase().includes(filterSurgeon.toLowerCase())) return false;
    if (filterRoom && a.room !== filterRoom) return false;
    if (filterProcedure && !(a.procedure || a.details || '').toLowerCase().includes(filterProcedure.toLowerCase())) return false;
    return true;
  });

  return (
    <div className="w-full bg-[#F4F5F1] text-[#14432E] font-sans text-xs min-h-screen flex flex-col border border-[#E1E4DC] shadow-xs rounded-xl overflow-hidden relative">
      
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-6 right-6 z-50 bg-[#14432E] text-white text-xs font-semibold px-4 py-3 rounded-xl shadow-2xl border border-[#5B6B60] flex items-center gap-2.5 animate-in slide-in-from-top duration-300">
          <CheckCircle2 className="w-4 h-4 text-[#1B4332] shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Date Header Controls & Main Content Area with reduced side padding */}
      <div className="flex-1 p-1.5 sm:p-2.5 flex flex-col gap-2.5">

        {/* Nightingale AI Practice Coordinator Command Bar */}
        <NightingaleScheduleCommandCoordinator
          onExecuteCommand={handleExecuteNightingaleCommand}
          onOpenBriefing={() => setIsBriefingModalOpen(true)}
          onOpenNewAppointmentModal={handleCreateNewAppointment}
          onOpenBlockTimeModal={() => setIsBlockTimeModalOpen(true)}
          onOpenPrintModal={() => setIsPrintModalOpen(true)}
          onOpenRoomSettings={() => setIsRoomSettingsOpen(true)}
          viewMode={viewMode}
          onSetViewMode={setViewMode}
          onPrevDate={handlePrev}
          onNextDate={handleNext}
          onToday={handleToday}
          activeFilters={{
            surgeon: filterSurgeon,
            room: filterRoom,
            procedure: filterProcedure,
          }}
          onClearFilters={handleClearFilters}
          currentDateDisplay={currentHeaderDisplay}
          timeHorizonInfo={timeHorizonInfo}
          onResetToToday={handleResetToToday}
        />

        {/* Time Horizon Notice when viewing past or future months/years */}
        {timeHorizonInfo.isOffset && (
          <div className="bg-[#14432E] text-white px-4 py-2.5 rounded-xl border border-[#5B6B60] shadow-md flex items-center justify-between gap-3 animate-in fade-in">
            <div className="flex items-center gap-2.5">
              <span className="p-1 rounded-md bg-[#2F9E6E] text-[#E4F3EA]">
                <CalendarIcon className="w-4 h-4" />
              </span>
              <div>
                <span className="text-xs font-bold text-white font-display">
                  Viewing Extended Time Horizon: {timeHorizonInfo.monthYearStr}
                </span>
                <span className="ml-2 text-[11px] text-[#E1E4DC] font-medium font-mono">
                  ({timeHorizonInfo.offsetDesc}) • Active 3-OR Suite Operative Matrix
                </span>
              </div>
            </div>
            <button
              type="button"
              onClick={handleResetToToday}
              className="px-3 py-1 bg-[#FBEEDB] hover:bg-[#FBEEDB]/80 text-[#7A4E17] font-bold text-xs rounded-lg transition-colors cursor-pointer shadow-xs flex items-center gap-1 shrink-0"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Return to Today</span>
            </button>
          </div>
        )}
        
        {/* Active Schedule Date Banner */}
        <div className="flex items-center justify-between px-3 py-2 bg-white rounded-lg border border-[#E1E4DC] shadow-2xs">
          <div className="flex items-center gap-2 flex-wrap">
            <CalendarIcon className="w-4 h-4 text-[#2F9E6E]" />
            <div className="text-sm sm:text-base font-display font-bold text-[#14432E] tracking-tight">
              {currentHeaderDisplay}
            </div>
            {viewMode === 'DAY' && (
              <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold font-mono ${
                daysOfWeek[selectedDayIndex]?.isToday ? 'bg-[#E4F3EA] text-[#1B4332] border border-[#E1E4DC]' : 'bg-[#F1F3EC] text-[#5B6B60] border border-[#E1E4DC]'
              }`}>
                {daysOfWeek[selectedDayIndex]?.isToday ? 'TODAY' : daysOfWeek[selectedDayIndex]?.dayName}
              </span>
            )}
            {viewMode === 'DAY' && daysOfWeek[selectedDayIndex]?.isHoliday && (
              <span className="px-2.5 py-0.5 rounded-full text-[10.5px] font-bold bg-slate-700 text-white flex items-center gap-1 shadow-2xs border border-slate-600 font-sans" title={daysOfWeek[selectedDayIndex]?.holidayName || 'Federal Holiday'}>
                <span>🇺🇸 Federal Holiday:</span>
                <span className="text-amber-300">{daysOfWeek[selectedDayIndex]?.holidayName}</span>
              </span>
            )}
            {viewMode === 'WK' && (
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-[#E4F3EA] text-[#1B4332] border border-[#E1E4DC] font-mono">
                WEEK VIEW
              </span>
            )}
          </div>
          <div className="text-[11px] text-[#5B6B60] font-medium hidden sm:block font-mono">
            {displayedAppointments.length} {displayedAppointments.length === 1 ? 'case' : 'cases'} scheduled
          </div>
        </div>

        {/* DAY MODE QUICK SELECTOR BAR: Allows fast switching between Mon-Sun when in DAY mode */}
        {viewMode === 'DAY' && (
          <div className="flex items-center gap-1.5 overflow-x-auto py-1 px-2 bg-[#F1F3EC] rounded-lg border border-[#E1E4DC]">
            <span className="text-[11px] font-bold text-[#5B6B60] uppercase tracking-wider pr-1 flex items-center gap-1 font-display">
              <Clock className="w-3.5 h-3.5 text-[#2F9E6E]" />
              Select Day:
            </span>
            {daysOfWeek.map((day, idx) => {
              const isSelected = selectedDayIndex === idx;
              const count = displayedAppointments.filter((a) => a.dayIndex === idx).length;
              return (
                <button
                  key={day.date}
                  onClick={() => setSelectedDayIndex(idx)}
                  className={`px-3 py-1 rounded-md text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer whitespace-nowrap ${
                    isSelected
                      ? 'bg-[#2F9E6E] text-white shadow-xs font-bold ring-1 ring-[#1B4332]'
                      : day.isHoliday
                      ? 'bg-slate-200 text-slate-700 hover:bg-slate-300 border border-slate-300 font-medium'
                      : 'bg-white text-[#5B6B60] hover:bg-[#F1F3EC] border border-[#E1E4DC]'
                  }`}
                >
                  <span>{day.label}</span>
                  {day.isToday && (
                    <span className="text-[9px] px-1.5 py-0.2 rounded-full font-bold font-mono bg-[#FBEEDB] text-[#7A4E17]">
                      Today
                    </span>
                  )}
                  {day.isHoliday && (
                    <span className={`text-[8.5px] px-1.5 py-0.2 rounded-full font-bold ${
                      isSelected ? 'bg-slate-800 text-amber-300' : 'bg-slate-300 text-slate-800'
                    }`}>
                      🇺🇸 Holiday
                    </span>
                  )}
                  <span className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono font-bold ${
                    isSelected ? 'bg-[#1B4332] text-white' : 'bg-[#F1F3EC] text-[#5B6B60]'
                  }`}>
                    {count} {count === 1 ? 'case' : 'cases'}
                  </span>
                </button>
              );
            })}
          </div>
        )}

        {/* Main Grid + Sidebar Split with reduced margins */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-2.5 items-start flex-1">
          
          {/* Calendar Matrix View (10 Cols) */}
          <div className="lg:col-span-10 bg-white border border-slate-300 rounded-xl shadow-2xs overflow-x-auto transition-all">
            <div className={viewMode === 'DAY' ? 'min-w-[700px] w-full' : 'min-w-[960px] w-full'}>
              
              {/* Quick Interactive Tip Banner */}
              <div className="bg-slate-50 border-b border-slate-200 px-3 py-1.5 flex items-center justify-between text-[11px] text-slate-600 select-none">
                <div className="flex items-center gap-1.5 font-medium">
                  <span className="text-emerald-700 font-bold flex items-center gap-1">
                    <Plus className="w-3 h-3 text-emerald-600" />
                    {viewMode === 'DAY' ? `Schedule for ${daysOfWeek[selectedDayIndex]?.fullDateStr}:` : 'Interactive 7-Day Matrix (Mon - Sun):'}
                  </span>
                  <span>
                    {viewMode === 'DAY' 
                      ? `Viewing ${rooms.join(', ') || 'no rooms'}. Click any 15-min slot to schedule a case or drag to reschedule.`
                      : 'Schedule begins Monday. Click any slot or drag appointment blocks to adjust times and rooms.'}
                  </span>
                </div>
                <div className="text-[10px] text-slate-600 font-semibold bg-slate-200/80 px-2.5 py-0.5 rounded-full">
                  {displayedAppointments.length} {displayedAppointments.length === 1 ? 'Case' : 'Cases'} {viewMode === 'DAY' ? 'on this day' : 'this week'}
                </div>
              </div>
              
              {/* ========================================================================= */}
              {/* VIEW MODE: DAY ONLY — dynamic columns from Practice room configuration */}
              {/* ========================================================================= */}
              {viewMode === 'DAY' && (
                <div>
                  {/* Header Rooms Row */}
                  <div className="grid border-b border-slate-300 bg-slate-100 text-center text-xs font-bold text-slate-700" style={{ gridTemplateColumns: `52px repeat(${Math.max(rooms.length, 1)}, minmax(0, 1fr))` }}>
                    <div className="p-2 border-r border-slate-300 bg-slate-200 text-slate-800">
                      Time
                    </div>
                    {rooms.map((roomName, rIdx) => (
                      <div 
                        key={roomName} 
                        className={`border-r border-slate-300 py-2 px-2 ${
                          rIdx === 0 ? 'bg-indigo-50/80 text-indigo-950' : rIdx === 1 ? 'bg-sky-50/80 text-sky-950' : 'bg-emerald-50/80 text-emerald-950'
                        } ${rIdx === rooms.length - 1 ? 'border-r-0' : ''}`}
                      >
                        <div className="text-sm font-bold tracking-tight">{roomName}</div>
                        <div className="text-[10px] text-slate-500 font-normal mt-0.5">
                          {daysOfWeek[selectedDayIndex]?.dayName} Flow & Utilization
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* 15-Minute Rows Grid for DAY Mode */}
                  <div className="relative">
                    {timeSlots.map((slot, sIdx) => {
                      return (
                        <div 
                          key={sIdx} 
                          className={`grid min-h-[24px] max-h-[24px] text-[10px] ${
                            slot.isHourMark 
                              ? 'border-t-2 border-slate-300 bg-slate-50/90' 
                              : 'border-t border-slate-100 border-dashed'
                          }`}
                          style={{ gridTemplateColumns: `52px repeat(${Math.max(rooms.length, 1)}, minmax(0, 1fr))` }}
                        >
                          {/* Time Label */}
                          <div className={`border-r border-slate-300 pr-2 select-none flex items-center justify-end ${
                            slot.isHourMark ? 'bg-slate-200/90 text-slate-800 font-bold text-[10.5px]' : 'bg-slate-50/70 text-slate-400 font-medium text-[8.5px]'
                          }`}>
                            {slot.displayLabel}
                          </div>

                          {/* 3 Room Columns for the selected day */}
                          {rooms.map((roomName, rIdx) => {
                            const isHoveredTarget = 
                              dragOverTarget?.dIdx === selectedDayIndex && 
                              Math.abs((dragOverTarget?.hour ?? -1) - slot.hourNum) < 0.01 && 
                              dragOverTarget?.room === roomName;

                            return (
                              <div
                                key={roomName}
                                onClick={() => handleSlotClick(selectedDayIndex, slot.hourNum, roomName)}
                                onDragOver={(e) => {
                                  e.preventDefault();
                                  setDragOverTarget({ dIdx: selectedDayIndex, hour: slot.hourNum, room: roomName });
                                }}
                                onDragLeave={() => {
                                  setDragOverTarget(null);
                                }}
                                onDrop={(e) => {
                                  e.preventDefault();
                                  setDragOverTarget(null);
                                  handleDropOnSlot(e, selectedDayIndex, slot.hourNum, roomName);
                                }}
                                className={`border-r border-slate-200/80 transition-all cursor-pointer group flex items-center justify-between px-2 relative ${
                                  rIdx === rooms.length - 1 ? 'border-r-0' : ''
                                } ${
                                  isHoveredTarget 
                                    ? 'bg-emerald-200/90 ring-2 ring-emerald-500 ring-inset z-10' 
                                    : 'hover:bg-sky-50/90 hover:border-sky-300'
                                }`}
                                title={`Click to add appointment or drop here (${daysOfWeek[selectedDayIndex]?.dayName} - ${roomName} at ${slot.displayLabel})`}
                              >
                                <span className="opacity-0 group-hover:opacity-100 text-[8px] font-bold text-sky-700 bg-sky-100 px-1.5 py-0.5 rounded transition-opacity pointer-events-none select-none shadow-2xs">
                                  + Schedule {roomName} ({slot.displayLabel})
                                </span>
                              </div>
                            );
                          })}
                        </div>
                      );
                    })}

                    {/* Scheduled Appointment Overlays for DAY mode (spacious 30% width per room) */}
                    {displayedAppointments.map((apt, aIdx) => {
                      const topPx = (apt.startHour - 6) * 96; // 24px per 15min * 4 = 96px per hour
                      const heightPx = Math.max(apt.durationHours * 96, 26);

                      const roomIndex = rooms.indexOf(apt.room);
                      if (roomIndex < 0) return null;
                      const roomCount = Math.max(rooms.length, 1);
                      const leftCss = `calc(52px + (100% - 52px) * ${roomIndex} / ${roomCount})`;
                      const widthCss = `calc((100% - 52px) / ${roomCount})`;

                      const isBeingDragged = draggedAptId === apt.id;

                      return (
                        <div
                          key={apt.id + '-' + aIdx}
                          draggable={true}
                          onDragStart={(e) => handleDragStart(e, apt.id)}
                          onDragEnd={handleDragEnd}
                          onClick={(e) => {
                            e.stopPropagation();
                            handleOpenAppointmentModal(apt);
                          }}
                          data-surgeon-color={colorForSurgeon(apt.surgeon) || ''}
                          style={{
                            ...(colorForSurgeon(apt.surgeon) ? { background: colorForSurgeon(apt.surgeon), color: textOn(colorForSurgeon(apt.surgeon)!), borderColor: 'rgba(0,0,0,.25)' } : {}),
                            top: `${topPx}px`,
                            height: `${heightPx}px`,
                            left: leftCss,
                            width: widthCss,
                          }}
                          className={`absolute p-2 rounded border text-[11px] leading-tight overflow-hidden shadow-md cursor-grab active:cursor-grabbing hover:z-30 hover:scale-[1.01] transition-transform select-none ${apt.bgColor} ${
                            isBeingDragged ? 'opacity-40 border-dashed border-2 ring-2 ring-amber-400 z-40' : ''
                          }`}
                          title={`Drag to reschedule or click to view/edit (${apt.patientName || apt.title})`}
                        >
                          <div className="font-bold flex items-center justify-between text-xs border-b border-white/20 pb-0.5 mb-1">
                            <span className="flex items-center gap-1">
                              <Clock className="w-3 h-3 opacity-80" />
                              <span>{apt.startTime || formatHourString(apt.startHour)} ({apt.length || `${apt.durationHours} hrs`})</span>
                            </span>
                            {!apt.isBlock && <span className="text-[9px] opacity-90 font-mono bg-black/20 px-1.5 py-0.2 rounded">#{apt.id}</span>}
                          </div>
                          
                          <div className="font-black text-sm truncate tracking-tight">{apt.patientName || apt.title}</div>
                          
                          <div className="text-[10px] font-semibold opacity-95 truncate mt-0.5 flex items-center gap-1.5">
                            <span>Surgeon: {apt.surgeon}</span>
                            {apt.caseId && balanceFor(apt.caseId).invoices > 0 && <span data-testid="apt-balance">· {balanceFor(apt.caseId).label}</span>}
                            {apt.anesthesiologist && <span className="opacity-80">• Anesth: {apt.anesthesiologist}</span>}
                          </div>

                          {/* Details & Notes */}
                          {heightPx >= 48 && (
                            <div className="border-t border-white/20 pt-1 mt-1 text-[10px] font-medium leading-normal opacity-95 line-clamp-3">
                              <span className="font-bold">Procedure: </span>{apt.procedure || apt.details}
                              {apt.notes && <div className="text-[9.5px] italic mt-0.5 opacity-90">Note: {apt.notes}</div>}
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* ========================================================================= */}
              {/* VIEW MODE: WEEK — dynamic subcolumns: 7 days × currently visible configured rooms */}
              {/* Starts on MONDAY */}
              {/* ========================================================================= */}
              {viewMode === 'WK' && (
                <div>
                  {/* Header Days Row Starting on MONDAY */}
                  <div className="grid border-b border-slate-300 bg-slate-100 text-center text-[11px] font-bold text-slate-700" style={{ gridTemplateColumns: `52px repeat(${7 * Math.max(rooms.length, 1)}, minmax(0, 1fr))` }}>
                    <div className="p-2 border-r border-slate-300 bg-slate-200">
                      Time
                    </div>
                    {daysOfWeek.map((day, dIdx) => (
                      <div 
                        key={dIdx} 
                        onClick={() => {
                          setSelectedDayIndex(dIdx);
                          setViewMode('DAY');
                        }}
                        className={`border-r border-slate-300 py-1 px-1 cursor-pointer transition-colors ${
                          day.isToday 
                            ? 'bg-amber-100/90 text-slate-900 border-b-2 border-b-amber-500' 
                            : day.isHoliday
                            ? 'bg-slate-200/95 text-slate-800 border-b-2 border-b-slate-400 hover:bg-slate-300/90'
                            : 'bg-slate-100 hover:bg-slate-200'
                        }`}
                        title={`Click to focus on ${day.label}${day.isHoliday ? ` (${day.holidayName})` : ''}`}
                        style={{ gridColumn: `span ${Math.max(rooms.length, 1)}` }}
                      >
                        <div className="flex flex-col items-center justify-center gap-0.5">
                          <div className="flex items-center justify-center gap-1">
                            <span>{day.label}</span>
                            {day.isToday && <span className="text-[8px] bg-amber-300 text-amber-950 font-bold px-1 rounded-xs">Today</span>}
                          </div>
                          {day.isHoliday && (
                            <span className="text-[8px] bg-slate-700 text-white font-bold px-1.5 py-0.2 rounded truncate max-w-[95%]" title={day.holidayName || 'Federal Holiday'}>
                              🇺🇸 {day.holidayName}
                            </span>
                          )}
                        </div>
                        <div className={`grid text-[10px] font-semibold border-t mt-1 pt-0.5 ${
                          day.isHoliday ? 'border-slate-300 text-slate-600 bg-slate-300/40 rounded-xs' : 'border-slate-200 text-slate-500'
                        }`} style={{ gridTemplateColumns: `repeat(${Math.max(rooms.length, 1)}, minmax(0, 1fr))` }}>
                          {rooms.map(roomName => <div key={roomName} className="truncate px-0.5" title={roomName}>{roomName}</div>)}
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* 15-Minute Rows Grid for Week Mode */}
                  <div className="relative">
                    {timeSlots.map((slot, sIdx) => {
                      return (
                        <div 
                          key={sIdx} 
                          className={`grid min-h-[22px] max-h-[22px] text-[10px] ${
                            slot.isHourMark 
                              ? 'border-t-2 border-slate-300 bg-slate-50/90' 
                              : 'border-t border-slate-100 border-dashed'
                          }`}
                          style={{ gridTemplateColumns: `52px repeat(${7 * Math.max(rooms.length, 1)}, minmax(0, 1fr))` }}
                        >
                          {/* Time Label */}
                          <div className={`border-r border-slate-300 pr-1.5 select-none flex items-center justify-end ${
                            slot.isHourMark ? 'bg-slate-200/90 text-slate-800 font-bold text-[10px]' : 'bg-slate-50/70 text-slate-400 font-medium text-[8px]'
                          }`}>
                            {slot.displayLabel}
                          </div>

                          {/* 7 Day Columns Starting on Monday */}
                          {daysOfWeek.map((day, dIdx) => (
                            <div 
                              key={dIdx} 
                              className={`grid border-r border-slate-300 relative ${
                                day.isToday 
                                  ? (slot.isHourMark ? 'bg-amber-100/25' : 'bg-amber-50/20') 
                                  : day.isHoliday
                                  ? (slot.isHourMark ? 'bg-slate-200/80' : 'bg-slate-100/85')
                                  : 'bg-white'
                              }`}
                              style={{ gridColumn: `span ${Math.max(rooms.length, 1)}`, gridTemplateColumns: `repeat(${Math.max(rooms.length, 1)}, minmax(0, 1fr))` }}
                            >
                              {rooms.map((roomName, rIdx) => {
                                const isHoveredTarget = 
                                  dragOverTarget?.dIdx === dIdx && 
                                  Math.abs((dragOverTarget?.hour ?? -1) - slot.hourNum) < 0.01 && 
                                  dragOverTarget?.room === roomName;

                                return (
                                  <div
                                    key={roomName}
                                    onClick={() => handleSlotClick(dIdx, slot.hourNum, roomName)}
                                    onDragOver={(e) => {
                                      e.preventDefault();
                                      setDragOverTarget({ dIdx, hour: slot.hourNum, room: roomName });
                                    }}
                                    onDragLeave={() => {
                                      setDragOverTarget(null);
                                    }}
                                    onDrop={(e) => {
                                      e.preventDefault();
                                      setDragOverTarget(null);
                                      handleDropOnSlot(e, dIdx, slot.hourNum, roomName);
                                    }}
                                    className={`border-r ${day.isHoliday ? 'border-slate-300/70' : 'border-slate-100/60'} transition-all cursor-pointer group flex items-center justify-center relative ${
                                      rIdx === rooms.length - 1 ? 'border-r-0' : ''
                                    } ${
                                      isHoveredTarget 
                                        ? 'bg-emerald-200/90 ring-2 ring-emerald-500 ring-inset z-10' 
                                        : day.isHoliday
                                        ? 'hover:bg-slate-300/80 hover:border-slate-400'
                                        : 'hover:bg-sky-50/80 hover:border-sky-300'
                                    }`}
                                    title={`Click to add appointment or drop here (${day.label.split(',')[0]} - ${roomName} at ${slot.displayLabel}${day.isHoliday ? ` • Holiday: ${day.holidayName}` : ''})`}
                                  >
                                    <span className="opacity-0 group-hover:opacity-100 text-[7px] font-bold text-sky-700 bg-sky-100 px-0.5 py-0 rounded transition-opacity pointer-events-none select-none shadow-2xs">
                                      +
                                    </span>
                                  </div>
                                );
                              })}
                            </div>
                          ))}
                        </div>
                      );
                    })}

                    {/* Scheduled Appointment Overlays for Week mode */}
                    {displayedAppointments.map((apt, aIdx) => {
                      const topPx = (apt.startHour - 6) * 88;
                      const heightPx = Math.max(apt.durationHours * 88, 20);

                      const roomIndex = rooms.indexOf(apt.room);
                      if (roomIndex < 0) return null;
                      const roomsPerDay = Math.max(rooms.length, 1);
                      const totalColumns = 1 + 7 * roomsPerDay;
                      const colOffset = 1 + apt.dayIndex * roomsPerDay + roomIndex;
                      const leftPercent = (colOffset / totalColumns) * 100;
                      const widthPercent = (1 / totalColumns) * 100;

                      const isBeingDragged = draggedAptId === apt.id;

                      return (
                        <div
                          key={apt.id + '-' + aIdx}
                          draggable={true}
                          onDragStart={(e) => handleDragStart(e, apt.id)}
                          onDragEnd={handleDragEnd}
                          onClick={(e) => {
                            e.stopPropagation();
                            handleOpenAppointmentModal(apt);
                          }}
                          data-surgeon-color={colorForSurgeon(apt.surgeon) || ''}
                          style={{
                            ...(colorForSurgeon(apt.surgeon) ? { background: colorForSurgeon(apt.surgeon), color: textOn(colorForSurgeon(apt.surgeon)!), borderColor: 'rgba(0,0,0,.25)' } : {}),
                            top: `${topPx}px`,
                            height: `${heightPx}px`,
                            left: `${leftPercent}%`,
                            width: `${widthPercent}%`,
                          }}
                          className={`absolute p-1 rounded-xs border text-[9.5px] leading-tight overflow-hidden shadow-2xs cursor-grab active:cursor-grabbing hover:z-30 hover:scale-[1.02] transition-transform select-none ${apt.bgColor} ${
                            isBeingDragged ? 'opacity-40 border-dashed border-2 ring-2 ring-amber-400 z-40' : ''
                          }`}
                          title={`Drag to reschedule or click to view/edit (${apt.patientName || apt.title})`}
                        >
                          <div className="font-bold flex items-center justify-between text-[10px]">
                            <span className="truncate">{apt.startTime || formatHourString(apt.startHour)}</span>
                            {!apt.isBlock && <span className="text-[8px] opacity-90 font-mono">#{apt.id}</span>}
                          </div>
                          <div className="font-black text-[10.5px] truncate mt-0.5">{apt.patientName || apt.title}</div>
                          <div className="text-[9px] font-semibold opacity-95 truncate">{apt.surgeon}</div>

                          {/* Details section if height allows */}
                          {heightPx >= 36 && (
                            <div className="border-t border-white/25 pt-0.5 mt-0.5 text-[8.5px] font-medium leading-tight opacity-90 line-clamp-2">
                              {apt.procedure || apt.details}
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

            </div>
          </div>

          {/* Right Sidebar: Mini Calendar & NEW WEEK-SPECIFIC NOTES SECTION (Permanently Visible) */}
          <div className="lg:col-span-2 space-y-2.5">
            
            {/* Mini Month Calendar */}
            <div className="bg-white border border-[#E1E4DC] rounded p-2.5 shadow-2xs">
                <div className="flex items-center justify-between text-xs font-bold text-[#14432E] mb-2 border-b border-[#E1E4DC] pb-1 font-display">
                  <button 
                    onClick={() => shiftMiniMonth(-1)}
                    className="hover:text-[#2F9E6E] px-1 cursor-pointer font-bold"
                  >
                    &lt;
                  </button>
                  <span className="font-display">{miniMonthLabel}</span>
                  <button 
                    onClick={() => shiftMiniMonth(1)}
                    className="hover:text-[#2F9E6E] px-1 cursor-pointer font-bold"
                  >
                    &gt;
                  </button>
                </div>

                <div className="grid grid-cols-7 text-center text-[10px] font-bold text-[#5B6B60] mb-1 font-mono">
                  <div>Mo</div>
                  <div>Tu</div>
                  <div>We</div>
                  <div>Th</div>
                  <div>Fr</div>
                  <div>Sa</div>
                  <div>Su</div>
                </div>

                <div className="grid grid-cols-7 text-center text-[10px] gap-y-1 text-[#14432E] font-medium">
                  {Array.from({ length: (new Date(miniYear, miniMonth, 1).getDay() + 6) % 7 }, (_, i) => <div key={`blank-${i}`} />)}
                  {monthCalendarDays.map((day) => {
                    const now = new Date();
                    const date = new Date(miniYear, miniMonth, day);
                    const isToday = day === now.getDate() && miniMonth === now.getMonth() && miniYear === now.getFullYear();
                    const weekMonday = getMonday(date);
                    const isInActiveWeek = weekMonday.getTime() === baseDate.getTime();
                    return (
                      <button
                        type="button"
                        key={day}
                        onClick={() => { handleMiniCalendarDay(day); setViewMode('DAY'); }}
                        className={`py-0.5 rounded cursor-pointer transition-colors font-mono ${isToday ? 'bg-[#2F9E6E] text-white font-bold shadow-xs' : isInActiveWeek ? 'bg-[#FBEEDB] text-[#7A4E17] font-semibold hover:bg-[#FBEEDB]/70' : 'hover:bg-[#F1F3EC]'}`}
                        title={`View ${date.toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}`}
                      >{day}</button>
                    );
                  })}
                </div>
              </div>

              {/* NEW WEEK-SPECIFIC NOTES SECTION BENEATH THE CALENDAR */}
              <div className="bg-white border border-[#E1E4DC] rounded p-3 shadow-2xs space-y-2">
                <div className="flex items-center justify-between border-b border-[#E1E4DC] pb-1.5">
                  <div className="flex items-center gap-1.5 font-bold text-xs text-[#14432E] font-display">
                    <FileText className="w-3.5 h-3.5 text-[#2F9E6E]" />
                    <span>Week Schedule Notes</span>
                  </div>
                  <span className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-[#E4F3EA] text-[#1B4332] border border-[#E1E4DC] font-mono">
                    {`${daysOfWeek[0]?.date || ''} - ${daysOfWeek[6]?.date || ''}`}
                  </span>
                </div>

                <div className="text-[10px] text-[#5B6B60] font-medium">
                  Notes for <strong className="text-[#14432E]">{activeWeekKey}</strong> only:
                </div>

                {/* Free-text note field — auto-saves on blur. No tag buttons, no Save
                    button: type a note directly here, or tell Nightingale
                    ("note: OR 3 running 20 min behind") from the command bar above
                    and it lands here automatically. */}
                <div className="relative">
                  <textarea
                    value={noteDraft}
                    onChange={(e) => setNoteDraft(e.target.value)}
                    onBlur={() => handleSaveWeeklyNotes()}
                    placeholder="Type clinical staffing notes, OR turnover alerts, surgeon availability, or equipment reservations for this week..."
                    className="w-full h-32 p-2 border border-[#E1E4DC] rounded-md text-[11px] font-sans leading-relaxed text-[#14432E] placeholder-[#5B6B60] focus:outline-none focus:ring-1 focus:ring-[#2F9E6E] focus:border-[#2F9E6E] bg-[#F1F3EC]/40 resize-y"
                  />
                </div>

                <div className="text-[9.5px] text-[#5B6B60] pt-1 border-t border-[#E1E4DC]">
                  {savedNotesTimestamp ? (
                    <span className="text-[#1B4332] font-bold flex items-center gap-1 font-mono">
                      <CheckCircle2 className="w-3 h-3 text-[#1B4332]" />
                      Auto-saved at {savedNotesTimestamp}
                    </span>
                  ) : (
                    <span className="font-mono">Auto-saves as you type</span>
                  )}
                </div>
              </div>

            </div>

        </div>

      </div>

      {/* APPOINTMENT DETAILS POP-UP MODAL */}
      {activeAppointmentModal && (
        <DialogShell size="xl" testId="appointment-dialog" kicker={activeAppointmentModal.room || 'Scheduler'} icon={<CalendarIcon className="w-5 h-5" />}
          title={!appointmentsList.some(x => x.id === activeAppointmentModal.id) ? 'Add new appointment' : 'Appointment details'}
          subtitle="Search the patient, surgeon and anesthesiologist (matches appear after 3 letters)."
          onClose={() => setActiveAppointmentModal(null)}
          footer={<>
            {!(!appointmentsList.some(x => x.id === activeAppointmentModal.id)) && <Btn variant="danger" icon={<Trash2 className="w-4 h-4" />} onClick={handleDeleteAppointment}>Delete</Btn>}
            <span className="flex-1" />
            <Btn variant="secondary" icon={<ExternalLink className="w-4 h-4" />} onClick={handleOpenChartFromModal}>Open chart</Btn>
            <Btn variant="confirm" icon={<Save className="w-4 h-4" />} onClick={handleSaveAppointment} data-testid="save-appointment">Save appointment</Btn>
          </>}>
            <div className="space-y-4 text-[14px] font-sans text-slate-800">
              {activeAppointmentModal.caseId && <div className="flex items-center gap-2 text-[14px]"><span className="text-slate-700">Billing:</span><BalanceChip caseId={activeAppointmentModal.caseId} paymentType={activeAppointmentModal.paymentType} /></div>}
              
              {/* LINE 1: Date of Service (DOS), Start Time, Length of Surgery / Appointment, Operating Room */}
              <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
                <div>
                  <label className="block text-[11px] font-bold text-slate-600 uppercase tracking-wider mb-1">
                    Date of Service (DOS)
                  </label>
                  <input
                    type="text"
                    value={activeAppointmentModal.dos || ''}
                    onChange={(e) => handleFormChange('dos', formatDate(e.target.value))} inputMode="numeric"
                    onBlur={(e) => handleFormChange('dos', normalizeUsDate(e.target.value))}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs font-semibold text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all shadow-2xs"
                    placeholder="MM/DD/YYYY"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-600 uppercase tracking-wider mb-1">
                    Start Time
                  </label>
                  <input
                    type="text"
                    value={activeAppointmentModal.startTime || ''}
                    onChange={(e) => handleFormChange('startTime', e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs font-semibold text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all shadow-2xs"
                    placeholder="08:00 AM"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-600 uppercase tracking-wider mb-1">
                    Length of Surgery
                  </label>
                  <select
                    value={activeAppointmentModal.length || '1.5 Hours'}
                    onChange={(e) => handleFormChange('length', e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs font-semibold text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all shadow-2xs cursor-pointer"
                  >
                    {!['15 Minutes', '30 Minutes', '45 Minutes', '1.0 Hour', '1.25 Hours', '1.5 Hours', '1.75 Hours', '2.0 Hours', '2.5 Hours', '3.0 Hours', '3.5 Hours', '4.0 Hours', '5.0 Hours', '6.0 Hours'].includes(activeAppointmentModal.length || '') && activeAppointmentModal.length && (
                      <option value={activeAppointmentModal.length}>{activeAppointmentModal.length}</option>
                    )}
                    <option value="15 Minutes">15 Minutes (0.25 Hrs)</option>
                    <option value="30 Minutes">30 Minutes (0.5 Hrs)</option>
                    <option value="45 Minutes">45 Minutes (0.75 Hrs)</option>
                    <option value="1.0 Hour">1.0 Hour (60 Mins)</option>
                    <option value="1.25 Hours">1.25 Hours (75 Mins)</option>
                    <option value="1.5 Hours">1.5 Hours (90 Mins)</option>
                    <option value="1.75 Hours">1.75 Hours (105 Mins)</option>
                    <option value="2.0 Hours">2.0 Hours (120 Mins)</option>
                    <option value="2.5 Hours">2.5 Hours (150 Mins)</option>
                    <option value="3.0 Hours">3.0 Hours (180 Mins)</option>
                    <option value="3.5 Hours">3.5 Hours (210 Mins)</option>
                    <option value="4.0 Hours">4.0 Hours (240 Mins)</option>
                    <option value="5.0 Hours">5.0 Hours (300 Mins)</option>
                    <option value="6.0 Hours">6.0 Hours (360 Mins)</option>
                  </select>
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-600 uppercase tracking-wider mb-1">
                    Operating Room
                  </label>
                  <select
                    value={activeAppointmentModal.room || rooms[0] || ''}
                    onChange={(e) => handleFormChange('room', e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs font-semibold text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all shadow-2xs cursor-pointer"
                  >
                    {configuredRooms.map(room => <option key={room.id} value={room.name}>{room.name}</option>)}
                  </select>
                </div>
              </div>

              {/* LINE 2: Patient's Name, Date of Birth, Age, Phone Number */}
              <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
                <div className="relative">
                  <div className="flex items-center justify-between mb-1">
                    <label className="block text-[11px] font-bold text-slate-600 uppercase tracking-wider">
                      Patient Name
                    </label>

                  </div>
                  <div className="relative">
                    <input
                      type="text"
                      value={activeAppointmentModal.patientName || ''}
                      onChange={(e) => {
                        const val = e.target.value;
                        handleFormChange('patientName', val);
                        setPatientSearchQuery(val);
                        setShowPatientSuggestions(val.trim().length >= 3);
                      }}
                      onFocus={() => {
                        if ((activeAppointmentModal.patientName || '').trim().length >= 3) {
                          setShowPatientSuggestions(true);
                        }
                      }}
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs font-semibold text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all shadow-2xs"
                      placeholder="Type patient last name..."
                      autoComplete="off"
                    />
                    {activeAppointmentModal.patientName && (
                      <button
                        type="button"
                        onClick={() => {
                          handleFormChange('patientName', '');
                          setPatientSearchQuery('');
                          setShowPatientSuggestions(false);
                        }}
                        className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 p-0.5"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>

                  {/* Dynamic Patient Dropdown */}
                  {showPatientSuggestions && activeAppointmentModal.patientName && activeAppointmentModal.patientName.trim().length >= 3 && (() => {
                    const matches = searchPatientsByLastName(activeAppointmentModal.patientName, cases, { minChars: 3 });
                    return (
                      <div className="absolute left-0 top-full mt-1.5 w-[320px] sm:w-[380px] bg-white rounded-xl border border-indigo-200 shadow-2xl z-50 p-2 max-h-64 overflow-y-auto animate-in fade-in zoom-in-95 duration-150">
                        <div className="px-2.5 py-1.5 text-[10px] font-bold text-indigo-800 bg-indigo-50 rounded-lg flex items-center justify-between mb-1.5 border border-indigo-100">
                          <span>Matching Patients ({matches.length})</span>
                          <span className="text-[9px] text-indigo-600 font-semibold">Select to auto-fill</span>
                        </div>

                        {matches.length === 0 ? (
                          <div className="p-3 text-center text-xs text-slate-500">
                            No matching patient found for "{activeAppointmentModal.patientName}".
                            <p className="text-[10px] text-slate-400 mt-0.5">You can keep typing to create a new patient entry.</p>
                          </div>
                        ) : (
                          <div className="space-y-1">
                            {matches.map((p) => (
                              <button
                                key={p.id || p.patientId}
                                type="button"
                                onClick={() => {
                                  setActiveAppointmentModal((prev) => {
                                    if (!prev) return null;
                                    return {
                                      ...prev,
                                      patientName: p.name,
                                      title: p.name,
                                      dob: p.dob,
                                      age: `${p.age}`,
                                      phone: p.phone,
                                      procedure: p.procedure || prev.procedure,
                                      surgeon: p.surgeon || prev.surgeon,
                                      anesthesiologist: p.anesthesiologist || prev.anesthesiologist,
                                      anesthesiaType: p.anesthesiaType || prev.anesthesiaType,
                                      paymentType: p.paymentType || prev.paymentType || '',
                                      caseId: p.id
                                    };
                                  });
                                  setPatientSearchQuery(p.name);
                                  setShowPatientSuggestions(false);
                                  showToast(`Auto-filled: ${p.name} • DOB: ${p.dob} • Age: ${p.age} • Phone: ${p.phone}`);
                                }}
                                className="w-full text-left p-2.5 hover:bg-indigo-50/90 rounded-lg transition-all cursor-pointer border border-transparent hover:border-indigo-200 group"
                              >
                                <div className="flex items-center justify-between">
                                  <div className="flex items-center gap-2">
                                    <div className="w-6 h-6 rounded-full bg-indigo-100 text-indigo-800 font-bold text-[10px] flex items-center justify-center">
                                      {p.name.split(' ').map((n) => n[0]).join('')}
                                    </div>
                                    <span className="font-bold text-xs text-slate-900 group-hover:text-indigo-950">
                                      {p.name}
                                    </span>
                                  </div>
                                  <div className="flex items-center gap-1.5">
                                    <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-slate-100 text-slate-700 group-hover:bg-indigo-100 group-hover:text-indigo-900">
                                      Age: {p.age}
                                    </span>
                                  </div>
                                </div>

                                <div className="grid grid-cols-2 gap-2 mt-1.5 text-[11px] text-slate-500 font-medium">
                                  <span className="flex items-center gap-1 text-slate-600">
                                    <Phone className="w-3 h-3 text-indigo-500 shrink-0" />
                                    {p.phone}
                                  </span>
                                  <span className="flex items-center gap-1 text-slate-600 justify-end">
                                    <CalendarIcon className="w-3 h-3 text-indigo-500 shrink-0" />
                                    DOB: {p.dob}
                                  </span>
                                </div>

                                {p.procedure && (
                                  <div className="text-[10px] text-slate-400 truncate mt-1 pt-1 border-t border-slate-100">
                                    {p.procedure}
                                  </div>
                                )}
                              </button>
                            ))}
                          </div>
                        )}
                      </div>
                    );
                  })()}
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-600 uppercase tracking-wider mb-1">
                    Date of Birth (DOB)
                  </label>
                  <input
                    type="text"
                    value={activeAppointmentModal.dob || ''}
                    onChange={(e) => handleFormChange('dob', formatDate(e.target.value))} inputMode="numeric"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs font-semibold text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all shadow-2xs"
                    placeholder="MM/DD/YYYY"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-600 uppercase tracking-wider mb-1">
                    Age
                  </label>
                  <input
                    type="text"
                    value={activeAppointmentModal.age || ''}
                    onChange={(e) => handleFormChange('age', e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs font-semibold text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all shadow-2xs"
                    placeholder="Age"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-600 uppercase tracking-wider mb-1">
                    Phone Number
                  </label>
                  <input
                    type="text"
                    value={activeAppointmentModal.phone || ''}
                    onChange={(e) => handleFormChange('phone', formatPhone(e.target.value))} inputMode="tel"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs font-semibold text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all shadow-2xs"
                    placeholder="e.g. (310) 555-1234"
                  />
                </div>
              </div>

              {/* LINE 3: Full-length text field for Procedure */}
              <div>
                <label className="block text-[11px] font-bold text-slate-600 uppercase tracking-wider mb-1">
                  Procedure
                </label>
                <input
                  type="text"
                  value={activeAppointmentModal.procedure || ''}
                  onChange={(e) => handleFormChange('procedure', e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs font-semibold text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all shadow-2xs"
                  placeholder="Full procedure description"
                />
              </div>

              {/* LINE 4: Surgeon's Name, Anesthesiologist, Type of Anesthesia, Payment Type Drop-down */}
              <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
                <ProviderTypeahead label="Surgeon" testId="appt-surgeon" roles={['Surgeon', 'Other provider']} value={activeAppointmentModal.surgeon || ''} onChange={v => handleFormChange('surgeon', v)} />
                <ProviderTypeahead label="Anesthesiologist" testId="appt-anesthesiologist" roles={['Anesthesiologist', 'CRNA']} value={activeAppointmentModal.anesthesiologist || ''} onChange={v => handleFormChange('anesthesiologist', v)} />
                <div>
                  <label className="block text-[11px] font-bold text-slate-600 uppercase tracking-wider mb-1">
                    Type of Anesthesia
                  </label>
                  <select
                    value={activeAppointmentModal.anesthesiaType || ''}
                    onChange={(e) => handleFormChange('anesthesiaType', e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs font-semibold text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all shadow-2xs cursor-pointer"
                  >
                    <option value="">Select…</option><option>General Anesthesia</option><option>MAC / Monitored Anesthesia Care</option><option>Regional Anesthesia</option><option>Local with Sedation</option><option>Local Anesthesia</option><option>Other / TBD</option>
                  </select>
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-indigo-900 uppercase tracking-wider mb-1 flex items-center justify-between">
                    <span>Payment Type</span>
                    <span className="text-[9px] text-indigo-700 bg-indigo-50 px-1 py-0.2 rounded font-extrabold border border-indigo-200">Required</span>
                  </label>
                  <select
                    value={activeAppointmentModal.paymentType || ''}
                    onChange={(e) => handleFormChange('paymentType', e.target.value)}
                    className="w-full px-3 py-2 bg-indigo-50/50 border border-indigo-300 rounded-lg text-xs font-bold text-indigo-950 focus:outline-hidden focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all shadow-2xs cursor-pointer"
                  >
                    {!PAYMENT_TYPE_OPTIONS.includes((activeAppointmentModal.paymentType || '') as any) && activeAppointmentModal.paymentType && (
                      <option value={activeAppointmentModal.paymentType}>{activeAppointmentModal.paymentType}</option>
                    )}
                    <option value="">Select…</option>
                    {PAYMENT_TYPE_OPTIONS.map((opt) => (
                      <option key={opt} value={opt}>
                        {opt}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* LINE 5: Full-length box for Notes */}
              <div>
                <label className="block text-[11px] font-bold text-slate-600 uppercase tracking-wider mb-1">
                  Notes
                </label>
                <textarea
                  rows={3}
                  value={activeAppointmentModal.notes || ''}
                  onChange={(e) => handleFormChange('notes', e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs font-medium text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all resize-none shadow-2xs"
                  placeholder="Clinical notes, pre-op instructions, or patient preferences..."
                />
              </div>

            </div>
        </DialogShell>
      )}

      {/* Delete Appointment Confirmation Modal */}
      {deleteConfirmAppointment && (
        <DialogShell zIndex={100000} size="sm" testId="delete-appointment-dialog" icon={<Trash2 className="w-5 h-5" />} kicker="Scheduler" title="Delete appointment?" subtitle="Please confirm before deleting this scheduled appointment." onClose={() => setDeleteConfirmAppointment(null)}
          footer={<><Btn variant="secondary" onClick={() => setDeleteConfirmAppointment(null)}>Cancel</Btn><Btn variant="danger" icon={<Trash2 className="w-4 h-4" />} onClick={handleConfirmDeleteAppointment}>Delete appointment</Btn></>}>
          <div className="space-y-4">
            <div className="p-3.5 bg-rose-50/80 border border-rose-200/90 rounded-xl space-y-1.5 text-xs text-stone-800">
              <div className="font-extrabold text-rose-950 flex items-center justify-between">
                <span>Patient Name:</span>
                <span className="text-stone-900 font-bold">{deleteConfirmAppointment.patientName}</span>
              </div>
              <div className="flex justify-between text-stone-600">
                <span>Date & Time:</span>
                <span className="font-bold text-stone-800">{deleteConfirmAppointment.dos} at {deleteConfirmAppointment.startTime}</span>
              </div>
              <div className="flex justify-between text-stone-600">
                <span>Room / Location:</span>
                <span className="font-bold text-stone-800">{deleteConfirmAppointment.room}</span>
              </div>
              <div className="flex justify-between text-stone-600">
                <span>Procedure:</span>
                <span className="font-bold text-stone-800">{deleteConfirmAppointment.procedure}</span>
              </div>
              <div className="flex justify-between text-stone-600">
                <span>Payment Type:</span>
                <span className="font-bold text-indigo-900 bg-indigo-50 px-1.5 py-0.5 rounded border border-indigo-200">{deleteConfirmAppointment.paymentType || 'Self-Pay'}</span>
              </div>
            </div>

            <p className="text-xs text-stone-500 leading-relaxed font-medium">
              ⚠️ <strong>Warning:</strong> Deleting this appointment will permanently remove it from the OR schedule and patient itinerary. This action cannot be undone.
            </p>

          </div>
        </DialogShell>
      )}

      {/* Footer Copyright */}
      <div className="bg-slate-200 px-4 py-2 border-t border-slate-300 text-[10px] text-slate-600 font-medium flex items-center justify-between">
        <span>Vityls ASC</span>
        <span>{practiceConfig?.practiceName || 'New Practice'}</span>
      </div>

      {/* Schedule Print / PDF Modal */}
      {isRoomSettingsOpen && (
        <div className="fixed inset-0 z-[80] bg-black/45 flex items-center justify-center p-4">
          <div className="w-full max-w-md bg-white rounded-2xl shadow-2xl border border-stone-200 overflow-hidden">
            <div className="px-5 py-4 bg-[#14432E] text-white flex items-center justify-between"><div className="flex items-center gap-2 font-bold"><Settings className="w-4 h-4"/>Schedule Rooms</div><button onClick={()=>setIsRoomSettingsOpen(false)}><X className="w-5 h-5"/></button></div>
            <div className="p-5"><p className="text-xs text-stone-600 mb-4">Choose which configured rooms are displayed on your schedule. Names, active status, and order come directly from Practice → Practice & Team Setup.</p>
              <div className="space-y-2">{configuredRooms.map(roomConfig => {
                const room = roomConfig.name;
                const checked = visibleRooms.includes(room);
                return <label key={roomConfig.id} className="flex items-center gap-3 p-3 rounded-xl border border-stone-200 hover:bg-stone-50">
                  <input type="checkbox" checked={checked} onChange={(e) => {
                    const next = e.target.checked ? Array.from(new Set([...visibleRooms, room])) : visibleRooms.filter(x => x !== room);
                    if (!next.length) { showToast('At least one room must remain visible.'); return; }
                    updateVisibleRooms(next);
                  }}/>
                  <Building2 className="w-4 h-4 text-emerald-700"/>
                  <span className="text-sm font-semibold flex-1">{room}</span>
                  <span className="text-[10px] uppercase tracking-wide text-stone-400">{roomConfig.type || 'Room'}</span>
                </label>;
              })}</div>
              {!configuredRooms.length && <div className="text-xs text-amber-700 bg-amber-50 border border-amber-200 rounded-lg p-3">No active rooms are configured. Add a room in Practice → Practice & Team Setup.</div>}
            </div>
            <div className="px-5 py-3 border-t border-stone-200 flex justify-end"><button onClick={()=>setIsRoomSettingsOpen(false)} className="px-4 py-2 rounded-lg bg-[#1F6E52] text-white text-xs font-bold">Done</button></div>
          </div>
        </div>
      )}

      <SchedulePrintModal
        isOpen={isPrintModalOpen}
        onClose={() => setIsPrintModalOpen(false)}
        initialViewMode={viewMode}
        selectedDayIndex={selectedDayIndex}
        appointmentsList={appointmentsList}
        daysOfWeek={daysOfWeek}
        rooms={rooms}
        practiceConfig={practiceConfig}
        onShowToast={showToast}
      />

      {/* Nightingale AI Surgical Day Briefing Modal */}
      <SurgicalDayBriefingModal
        isOpen={isBriefingModalOpen}
        onClose={() => setIsBriefingModalOpen(false)}
        dateStr={daysOfWeek[selectedDayIndex]?.fullDateStr || new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' })}
        appointments={displayedAppointments}
      />

      {/* Block Time Reservation Modal */}
      <BlockTimeModal
        isOpen={isBlockTimeModalOpen}
        onClose={() => setIsBlockTimeModalOpen(false)}
        onSaveBlocks={handleSaveBlocks}
        daysOfWeek={daysOfWeek}
        rooms={rooms}
        initialDayIndex={selectedDayIndex}
        initialRoom={rooms[0] || configuredRooms[0]?.name || ""}
      />

    </div>
  );
};

