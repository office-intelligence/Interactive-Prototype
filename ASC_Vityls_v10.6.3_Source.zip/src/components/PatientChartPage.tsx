import React, { useState, useEffect, useRef } from 'react';
import { bundledFetch } from '../v6/formSource';
import { 
  FileText, 
  Plus, 
  Sparkles, 
  Search, 
  ChevronRight, 
  ChevronDown,
  ChevronUp, 
  CheckCircle2, 
  AlertCircle,
  AlertTriangle,
  User, 
  UserPlus,
  Calendar, 
  Activity, 
  Pill,
  Mic,
  Send, 
  ExternalLink, 
  ShieldCheck, 
  FileCheck, 
  Clock, 
  CreditCard, 
  MessageSquare, 
  Building2,
  Filter,
  Maximize2,
  X,
  Download,
  Eye,
  Check,
  Printer,
  Upload,
  FolderOpen,
  FolderCheck,
  Save,
  Mail,
  CheckSquare,
  Square,
  Laptop,
  Smartphone,
  Share2,
  Copy,
  Link,
  Lock,
  Trash2,
  DollarSign,
  Zap,
  Layers,
  Stethoscope,
  PenTool,
  Phone,
  Tag,
  Pencil,
  Camera,
  MapPin,
  Info,
  ClipboardList,
  Syringe,
  ClipboardCheck as ClipboardCheckIcon,
} from 'lucide-react';
import { PatientCase, EncounterJourneyStatus } from '../types';
import { initialPatientCases } from '../data/mockData';
import { 
  generateSampleDriverLicense, 
  generateSampleInsuranceFront, 
  generateSampleInsuranceBack 
} from '../utils/cardTemplates';
import { PatientChartPrintModal, PrintOptionType, AuditTrailItem } from './PatientChartPrintModal';
import { ElectronicFormsPortal, ClinicalFormTab } from './ElectronicFormsPortal';
import { ClinicalPdfFormsView } from './ClinicalPdfFormsView';
import { IntakeHtmlForm } from '../data/intakeHtmlForms';
import genericAdmissionHtml from '../../reference-forms/asc-default-library/Admission_Form.html?raw';
import { getPrefilledIntakeHtml } from '../utils/formPrefill';
import { NoteHtmlForm, INITIAL_NOTES_HTML_FORMS } from '../data/notesHtmlForms';
import { NursingHtmlForm, INITIAL_NURSING_HTML_FORMS, SURGICAL_EPISODES } from '../data/nursingHtmlForms';
import { ClinicalWorkflowPage, ClinicalWorkflowRole } from './ClinicalWorkflowPage';
import { CaseRecordCommandCenter } from './CaseRecordCommandCenter';
import { AIWorkflowExamples } from './AIWorkflowExamples';
import { AIPatientChartOverview } from './AIPatientChartOverview';
import { NightingaleChartCommandCoordinator } from './NightingaleChartCommandCoordinator';
import { PatientChartPortalMessagesSection } from './PatientChartPortalMessagesSection';
import { getUnreadCount, subscribeToMessageUpdates } from '../utils/portalMessageStore';
import { listCurrentPracticeForms, listPdfTemplates, type LocalFormTemplate, type LocalPdfTemplate } from '../utils/localFormStudioDb';
import { localTemplateToIntakeForm } from '../utils/localFormRuntime';
import { MasterFormsDocumentsFolder } from './MasterFormsDocumentsFolder';
import { DayOfSurgeryJourney } from './DayOfSurgeryJourney';
import { PdfTemplateInteractiveViewer } from './PdfTemplateInteractiveViewer';
import { MinimalWorkflowHeader } from './MinimalWorkflowHeader';
import { IsolatedHtmlFormRenderer } from './IsolatedHtmlFormRenderer';
import { SignaturePad } from './SignaturePad';
import { AddPatientModal } from './AddPatientModal';
import { AllergyStatus, Btn } from '../v7/ui';
import { AppointmentHistory } from '../v7/AppointmentHistory';
import { ClearanceFiles, ClearanceReview } from '../v7/ClearanceWorkspace';
import { InvoicePanel } from '../v7/InvoicePanel';
import { SimulatedRxDialog } from '../v7/SimulatedRx';
import { answerFromLegacyChart } from '../v7/chartAnswers';
import { BalanceChip } from '../v7/OpsStrip';
import { effectiveAllergy } from '../v7/allergy';
import { VITYLS_FORM_CATALOG, FORM_WORKFLOWS, isAssignedToWorkflow, readWorkflowAssignment, templateStorageKey, schemaStorageKey, type WorkflowKey } from '../data/formWorkspaceCatalog';
import { OFFICIAL_HTML_FORM_LIBRARY } from '../data/officialHtmlFormLibrary';
import { 
  searchPatientsByLastName, 
  convertMasterRecordToPatientCase, 
  getAllMasterPatients, 
  MasterPatientRecord 
} from '../utils/patientDirectory';

export interface DocumentItem {
  id: string;
  title: string;
  fileName: string;
  submissionDate: string;
  type: string;
  status: string;
  summary: string;
  fileSize?: string;
  tags?: string[];
  formTab?: 'standing-orders' | 'preop-checklist' | 'surgical-checklist';
  content?: string;
}

const INITIAL_DOCUMENTS: DocumentItem[] = [];

export interface PreOpPdfForm {
  id: string;
  title: string;
  pdfGroup: string;
  subtitle: string;
  pageNumber: string;
  defaultChecked: boolean;
  status: 'Pending Send' | 'Sent via Email' | 'Completed in Portal';
  description: string;
}

export const PRE_OP_INTAKE_PDF_FORMS: PreOpPdfForm[] = [];

interface PatientChartPageProps {
  cases: PatientCase[];
  initialSelectedPatientId?: string;
  initialSelectedSection?: string;
  onOpenPatientModal?: (patient: PatientCase) => void;
  onNavigateToPortalTab?: () => void;
  onOpenAddPatient?: () => void;
  onAdvanceEncounter?: (caseId: string, toStatus: EncounterJourneyStatus, reason?: string, unresolvedItems?: string[]) => void;
  onUpdatePatient?: (patient: PatientCase) => void;
  activePracticeId?: string;
  onOpenVitylsNext?: (patient: PatientCase, station?: 'intake'|'nursing'|'anesthesia'|'surgeon'|'or'|'intraop'|'pacu'|'discharge'|'final') => void;
}

export const PatientChartPage: React.FC<PatientChartPageProps> = ({
  cases,
  initialSelectedPatientId,
  initialSelectedSection,
  onOpenPatientModal,
  onNavigateToPortalTab,
  onOpenAddPatient,
  onAdvanceEncounter,
  onUpdatePatient,
  activePracticeId,
  onOpenVitylsNext,
}) => {
  // Find selected patient with robust fallbacks to master patient registry
  const fallbackPatient: PatientCase = {
    id: '', patientId: '', name: '', age: 0, gender: '', dob: '', phone: '',
    scheduledTime: '', estimatedDurationMins: 0, room: '', surgeon: '', anesthesiologist: '',
    procedure: '', aiSummary: '', readinessScore: 0, readinessLevel: 'IN_PROGRESS', allergies: [], labs: [],
    stage: 'CHECK_IN', arrivalStatus: 'NOT_ARRIVED', bottlenecks: [], actionItems: [], notes: '',
    medicalProfile: { medications: [], pastMedicalHistory: [], pastSurgeries: [], priorAnesthesiaComplications: '', familyHistory: [], smokingStatus: '', alcoholUse: '', illicitDrugUse: '', exerciseLevel: '', reviewOfSystems: [], primaryCarePhysician: '', height: '', weight: '', priorGeneralAnesthesia: '', postOpNauseaHistory: '', airwayConcerns: [] }
  };

  const defaultPatient = 
    cases.find((c) => c.id === initialSelectedPatientId || c.patientId === initialSelectedPatientId) ||
    initialPatientCases.find((c) => c.id === initialSelectedPatientId || c.patientId === initialSelectedPatientId) ||
    cases[0] ||
    fallbackPatient;

  const [selectedPatient, setSelectedPatient] = useState<PatientCase>(defaultPatient);

  // Sync selected patient when initialSelectedPatientId or cases change
  useEffect(() => {
    if (initialSelectedPatientId) {
      const found = 
        cases.find((c) => c.id === initialSelectedPatientId || c.patientId === initialSelectedPatientId) ||
        initialPatientCases.find((c) => c.id === initialSelectedPatientId || c.patientId === initialSelectedPatientId);
      if (found) {
        setSelectedPatient(found);
      }
    } else if (!selectedPatient) {
      setSelectedPatient(cases[0] || initialPatientCases[0] || fallbackPatient);
    }
  }, [initialSelectedPatientId, cases]);

  // Ensure selectedPatient is never null or undefined
  useEffect(() => {
    if (!selectedPatient) {
      const safe = cases[0] || initialPatientCases[0] || fallbackPatient;
      setSelectedPatient(safe);
    }
  }, [selectedPatient, cases]);
  
  // Tab states
  const [activeSubTab, setActiveSubTab] = useState<'Documents' | 'Notes' | 'ID & Insurance Cards' | 'Timeline' | 'Labs & Imaging' | 'Billing' | 'Communications'>('Documents');
  const [docSearchQuery, setDocSearchQuery] = useState('');
  const [docList, setDocList] = useState<DocumentItem[]>([]);
  const [viewingDoc, setViewingDoc] = useState<DocumentItem | null>(null);
  // Separate from viewingDoc's summary popup — opens the original source
  // document (facsimile of the uploaded/converted file) for human review,
  // per the "Shared Application Requirements" spec.
  const [viewingOriginalDoc, setViewingOriginalDoc] = useState<DocumentItem | null>(null);
  const [docFilterCategory, setDocFilterCategory] = useState<string>('All');
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Top Chart Search Bar State
  const [chartSearchQuery, setChartSearchQuery] = useState('');
  const [isChartSearchFocused, setIsChartSearchFocused] = useState(false);
  const chartSearchContainerRef = useRef<HTMLDivElement>(null);
  const [isChartMinimalMode, setIsChartMinimalMode] = useState(false);

  const handleExecuteChartDirective = (directive: string, param?: string) => {
    switch (directive) {
      case 'check_clearance':
        handleExecuteAiCommand('Check pre-operative clearance and airway risk', 'clearance');
        break;
      case 'draft_soap_note':
        handleExecuteAiCommand('Draft clinical SOAP progress note', 'clinicalNotes');
        break;
      case 'eprescribe':
        handleExecuteAiCommand('Review medications and e-prescribe', 'medications');
        break;
      case 'send_intake':
        setIsPreOpEmailModalOpen(true);
        break;
      case 'print_chart':
        setPrintModalOption('facesheet');
        break;
      case 'print_labels':
        setPrintModalOption('labels');
        break;
      case 'view_appointments':
      case 'appointments':
        handleExecuteAiCommand('View appointment history & encounter logs', 'appointments');
        break;
      case 'view_vitals':
        handleExecuteAiCommand('Review nursing admission vitals & allergies', 'nursingNotes');
        break;
      case 'view_documents':
        handleExecuteAiCommand('Open verified documents and lab reports', 'documents');
        break;
      case 'view_billing':
        handleExecuteAiCommand('Verify insurance coverage and surgical fees', 'financial');
        break;
      default:
        handleExecuteAiCommand(directive, 'all');
        break;
    }
  };

  // Print Dropdown & Modal State
  const [isPrintDropdownOpen, setIsPrintDropdownOpen] = useState(false);
  const [printModalOption, setPrintModalOption] = useState<PrintOptionType | null>(null);
  const printDropdownRef = useRef<HTMLDivElement>(null);

  // Patient Header: Photo Capture/Upload State
  // Keyed by patientId so switching charts keeps each patient's own photo.
  const [patientPhotos, setPatientPhotos] = useState<{ [patientId: string]: string }>({});
  const photoInputRef = useRef<HTMLInputElement>(null);
  const currentPatientPhotoUrl = patientPhotos[selectedPatient.patientId];

  const handlePatientPhotoFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const url = URL.createObjectURL(file);
    setPatientPhotos((prev) => ({ ...prev, [selectedPatient.patientId]: url }));
    showToast(`Photo updated for ${selectedPatient.name}`);
    e.target.value = '';
  };

  // Patient Header: Editable Contact Info State (address/phone/email)
  // The data model doesn't carry address/email today, so reasonable per-patient
  // defaults are synthesized and can be overridden by staff via the edit icon.
  const getDefaultPatientAddress = (p: PatientCase) => {
    const num = (parseInt((p.patientId || '0').replace(/\D/g, ''), 10) % 9000) + 1000;
    return `${num} Ocean Ave, Beverly Hills, CA 90210`;
  };
  const getDefaultPatientEmail = (p: PatientCase) => {
    const slug = p.name.toLowerCase().replace(/[^a-z\s]/g, '').trim().split(/\s+/).join('.');
    return `${slug || 'patient'}@patientmail.com`;
  };
  const [contactOverrides, setContactOverrides] = useState<{ [patientId: string]: { phone?: string; email?: string; address?: string } }>({});
  const [isEditContactOpen, setIsEditContactOpen] = useState(false);
  const [editContactForm, setEditContactForm] = useState({ phone: '', email: '', address: '' });

  const currentContactInfo = {
    phone: contactOverrides[selectedPatient.patientId]?.phone || selectedPatient.phone,
    email: contactOverrides[selectedPatient.patientId]?.email || selectedPatient.email || getDefaultPatientEmail(selectedPatient),
    address: contactOverrides[selectedPatient.patientId]?.address || selectedPatient.address || getDefaultPatientAddress(selectedPatient),
  };

  const openEditContactModal = () => { setIsEditContactOpen(true); };
  const saveEditContactModal = () => {
    setContactOverrides((prev) => ({ ...prev, [selectedPatient.patientId]: { ...editContactForm } }));
    setIsEditContactOpen(false);
    showToast(`Contact info updated for ${selectedPatient.name}`);
  };

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (chartSearchContainerRef.current && !chartSearchContainerRef.current.contains(event.target as Node)) {
        setIsChartSearchFocused(false);
      }
      if (printDropdownRef.current && !printDropdownRef.current.contains(event.target as Node)) {
        setIsPrintDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const [deleteConfirmation, setDeleteConfirmation] = useState<{
    type: 'Document' | 'Doctor Note' | 'Nursing Note' | 'Draft Note';
    id?: string;
    name: string;
    details?: string;
    action: () => void;
  } | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 3500);
  };

  const handleDownloadDoc = (doc: DocumentItem) => {
    const contentToDownload = doc.content || `DOCUMENT REPORT\nTitle: ${doc.title}\nFile Name: ${doc.fileName}\nSubmission Date: ${doc.submissionDate}\nCategory: ${doc.type}\nStatus: ${doc.status}\n\nSummary:\n${doc.summary}`;
    const blob = new Blob([contentToDownload], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = doc.fileName;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);

    showToast(`Downloaded "${doc.fileName}"`);
  };

  const handleDeleteDoc = (id: string) => {
    const target = docList.find((d) => d.id === id);
    if (target) {
      setDeleteConfirmation({
        type: 'Document',
        id: target.id,
        name: target.fileName,
        details: `Category: ${target.type} · Submission Date: ${target.submissionDate} · Status: ${target.status}`,
        action: () => {
          setDocList((prev) => prev.filter((d) => d.id !== id));
          if (viewingDoc?.id === id) {
            setViewingDoc(null);
          }
          if (viewingOriginalDoc?.id === id) {
            setViewingOriginalDoc(null);
          }
          showToast(`Deleted document "${target.fileName}" from patient chart.`);
        }
      });
    }
  };

  const handleDeleteDoctorNote = (id: string) => {
    const target = notesFormsList.find((n) => n.id === id);
    if (target) {
      setDeleteConfirmation({
        type: 'Doctor Note',
        id: target.id,
        name: target.title,
        details: `Author: ${target.author} · Date: ${target.date} · Status: ${target.status}`,
        action: () => {
          setNotesFormsList((prev) => prev.filter((n) => n.id !== id));
          if (viewingNoteForm?.id === id) {
            setViewingNoteForm(null);
          }
          showToast(`Deleted Doctor Note "${target.title}"`);
        }
      });
    }
  };

  const handleDeleteNursingNote = (id: string) => {
    const target = nursingFormsList.find((f) => f.id === id);
    if (target) {
      setDeleteConfirmation({
        type: 'Nursing Note',
        id: target.id,
        name: target.title,
        details: `Author: ${target.author} · Date: ${target.date} · Status: ${target.status}`,
        action: () => {
          setNursingFormsList((prev) => prev.filter((f) => f.id !== id));
          if (editingNursingForm?.id === id) {
            setEditingNursingForm(null);
          }
          if (viewingFullNursingForm?.id === id) {
            setViewingFullNursingForm(null);
          }
          showToast(`Deleted Nursing Note "${target.title}"`);
        }
      });
    }
  };

  const handleClearDraftNote = () => {
    if (!draftNoteContent) return;
    setDeleteConfirmation({
      type: 'Draft Note',
      name: 'Draft Physician Note',
      details: 'Unsaved text in the clinical note workspace',
      action: () => {
        setDraftNoteContent('');
        showToast('Cleared draft physician note.');
      }
    });
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    const file = files[0];
    const newDoc: DocumentItem = {
      id: `upload-${Date.now()}`,
      title: file.name.replace(/\.[^/.]+$/, ''),
      fileName: file.name,
      type: 'Uploaded Document',
      submissionDate: new Date().toLocaleDateString('en-US', { month: 'short', day: '2-digit', year: 'numeric' }),
      status: 'Uploaded',
      fileSize: `${(file.size / 1024).toFixed(1)} KB`,
      summary: `Uploaded file by clinician on ${new Date().toLocaleDateString()}. Stored & archived in EHR chart.`,
      tags: ['User Uploaded', 'New Attachment'],
      content: `OFFICIAL EHR PATIENT CHART ATTACHMENT\nFile Name: ${file.name}\nSize: ${file.size} bytes\nType: ${file.type || 'Standard File'}\nUpload Time: ${new Date().toLocaleString()}\nPatient Name: ${selectedPatient.name} (ID: ${selectedPatient.patientId})\n\n[Document archived and verified in patient electronic chart]`
    };

    setDocList((prev) => [newDoc, ...prev]);
    showToast(`Uploaded "${file.name}" successfully!`);
    e.target.value = '';
  };

  const filteredDocList = docList.filter((doc) => {
    const matchesSearch =
      doc.fileName.toLowerCase().includes(docSearchQuery.toLowerCase()) ||
      doc.title.toLowerCase().includes(docSearchQuery.toLowerCase()) ||
      doc.submissionDate.toLowerCase().includes(docSearchQuery.toLowerCase()) ||
      doc.type.toLowerCase().includes(docSearchQuery.toLowerCase());

    const matchesCategory =
      docFilterCategory === 'All' || doc.type === docFilterCategory;

    return matchesSearch && matchesCategory;
  });

  const [selectedDocId, setSelectedDocId] = useState('doc-1');
  const [isDragging, setIsDragging] = useState(false);
  const [isIDModalOpen, setIsIDModalOpen] = useState(false);

  // Section Collapse/Expand state for Patient Chart major sections (Demographics and AI Brief expanded by default)
  const [expandedSections, setExpandedSections] = useState<Record<string, boolean>>({
    demographics: true,
    aiBrief: true,
    aiWorkflows: false,
    portalMessages: initialSelectedSection === 'portalMessages',
    docUpload: false,
    documents: false,
    admissionRegistration: false,
    intakeForms: false,
    clinicalNotes: false,
    nursingNotes: false,
    clearance: initialSelectedSection === 'clearance',
    admission: false,
    nursingForms: false,
    appointmentHistory: false,
    appointments: false,
    medications: false,
    idInsuranceCards: false,
    surgicalDetails: false,
    quickActions: false,
    // v7.2: hidden until their Case Tracker card, Nightingale command or a link opens them
    dayOfSurgery: false,
    clearanceFiles: false,
    clearanceReview: false,
  });
  React.useEffect(() => { setExpandedSections(prev => ({ ...prev, dayOfSurgery: false, clearanceFiles: false, clearanceReview: false })); }, [selectedPatient.id]);
  const hideSection = (k: string) => setExpandedSections(prev => ({ ...prev, [k]: false }));
  // v7.2 billing on the patient page (Nightingale "Billing"): test-build stand-in for the signed-in role
  const BILLING_ACTORS = [{ name: 'Front Desk Tester', role: 'Front desk' }, { name: 'Pat Quinn', role: 'Practice Manager' }, { name: 'Practice Administrator', role: 'Administrator' }];
  const [billingRole, setBillingRole] = useState('Front desk');

  const [patientUnreadCount, setPatientUnreadCount] = useState<number>(() => {
    return getUnreadCount(selectedPatient.patientId);
  });

  // Track unread messages for this patient in real-time
  useEffect(() => {
    setPatientUnreadCount(getUnreadCount(selectedPatient.patientId));
    const unsub = subscribeToMessageUpdates(() => {
      setPatientUnreadCount(getUnreadCount(selectedPatient.patientId));
    });
    return unsub;
  }, [selectedPatient.patientId]);

  // Handle initialSelectedSection navigation
  useEffect(() => {
    if (initialSelectedSection === 'portalMessages') {
      handleExecuteAiCommand('Show Patient Portal Messages', 'portalMessages');
    }
  }, [initialSelectedSection, selectedPatient.id]);

  const [showEarlierVisits, setShowEarlierVisits] = useState(false);

  const toggleSection = (key: string) => {
    setExpandedSections((prev) => ({
      ...prev,
      [key]: !prev[key],
    }));
  };

  const expandAllSections = () => {
    setExpandedSections({
      demographics: true,
      aiBrief: true,
      portalMessages: true,
      docUpload: true,
      docRecords: true,
      clearance: true,
      admission: true,
      clinicalNotes: true,
      nursingForms: true,
      appointmentHistory: true,
      medications: true,
      idInsuranceCards: true,
      surgicalDetails: true,
      quickActions: true,
    });
  };

  const collapseAllSections = () => {
    setExpandedSections({
      demographics: false,
      aiBrief: false,
      portalMessages: false,
      docUpload: false,
      docRecords: false,
      clearance: false,
      admission: false,
      clinicalNotes: false,
      nursingForms: false,
      appointmentHistory: false,
      medications: false,
      idInsuranceCards: false,
      surgicalDetails: false,
      quickActions: false,
    });
  };

  // Ask Nightingale AI Chat & Active Result Views state
  const [askAiInput, setAskAiInput] = useState('');
  const [selectedCommandKey, setSelectedCommandKey] = useState<string>(
    initialSelectedSection === 'portalMessages' ? 'portalMessages' : 'clearance'
  );
  const [aiAskChatLog, setAiAskChatLog] = useState<Array<{ sender: 'user' | 'ai'; text: string; timestamp: string }>>([
    {
      sender: 'ai',
      text: `Hello! I'm Nightingale AI. Select a command below or ask me about ${selectedPatient.name}'s chart to display specific records on demand.`,
      timestamp: 'Just now',
    },
  ]);
  const [activeAiResults, setActiveAiResults] = useState<string[]>([
    initialSelectedSection === 'portalMessages' ? 'portalMessages' : 'clearance'
  ]);

  const handleExecuteAiCommand = (commandLabel: string, sectionKey: string) => {
    let aiResponse = `Nightingale AI: Displaying details for "${commandLabel}".`;
    if (sectionKey === 'portalMessages') {
      aiResponse = `Nightingale AI: Displaying Patient Portal Messages & Two-Way Clinical Communications for ${selectedPatient.name}.`;
    } else if (sectionKey === 'clearance' || sectionKey === 'clearanceReview') {
      aiResponse = `Nightingale: Opened Review & alerts for ${selectedPatient.name}. The summary is a draft; a clinician confirms and clears.`;
    } else if (sectionKey === 'clearanceFiles' || sectionKey === 'documents') {
      aiResponse = `Nightingale: Opened the pre-op clearance files for ${selectedPatient.name}.`;
    } else if (sectionKey === 'intakeForms') {
      aiResponse = `Nightingale: Opened Intake Forms for ${selectedPatient.name}.`;
    } else if (sectionKey === 'dayOfSurgery') {
      aiResponse = `Nightingale: Opened the Day of Surgery stations for ${selectedPatient.name}. Tap a station to open its workstation.`;
    } else if (sectionKey === 'clinicalNotes') {
      aiResponse = `Nightingale AI: Displaying Doctor Notes and Clinical Progress Records for ${selectedPatient.name}.`;
    } else if (sectionKey === 'nursingNotes') {
      aiResponse = `Nightingale AI: Displaying Pre-Op & PACU Nursing Notes for ${selectedPatient.name}.`;
    } else if (sectionKey === 'documents') {
      aiResponse = `Nightingale: Opened documents for ${selectedPatient.name}.`;
    } else if (sectionKey === 'medications') {
      aiResponse = `Nightingale: Opened medications. The e-prescribe screen is a simulation; nothing is sent to a pharmacy.`;
    } else if (sectionKey === 'financial') {
      aiResponse = `Nightingale: Opened Billing & payments for ${selectedPatient.name}: invoice, payments and (for managers) the invoice override.`;
    } else if (sectionKey === 'appointments' || sectionKey === 'appointmentHistory') {
      aiResponse = `Nightingale AI: Displaying Appointment History & 5 Clinical Encounters for ${selectedPatient.name}.`;
    } else if (sectionKey === 'idInsurance') {
      aiResponse = `Nightingale AI: Displaying Driver's License Photo ID and Primary Insurance Cards (Front & Back).`;
    } else if (sectionKey === 'surgicalDetails') {
      aiResponse = `Nightingale AI: Displaying Surgical Team, Surgeon, Anesthesiologist, and OR Location.`;
    } else if (sectionKey === 'quickActions') {
      aiResponse = `Nightingale AI: Displaying Quick Chart Actions & Messaging options.`;
    } else if (sectionKey === 'aiWorkflows') {
      aiResponse = `Nightingale AI: Displaying Chart Intelligence Overview & Ambient Dictation.`;
    } else if (sectionKey === 'all') {
      aiResponse = `Nightingale AI: Displaying all chart sections for ${selectedPatient.name}.`;
    }

    setAiAskChatLog((prev) => [
      ...prev,
      { sender: 'user', text: commandLabel, timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) },
      { sender: 'ai', text: aiResponse, timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) },
    ]);

    setSelectedCommandKey(sectionKey);

    if (sectionKey === 'all') {
      setExpandedSections({
        demographics: true,
        aiBrief: true,
        portalMessages: true,
        aiWorkflows: true,
        docUpload: true,
        documents: true,
        intakeForms: true,
        clinicalNotes: true,
        nursingNotes: true,
        clearance: true,
        medications: true,
        financial: true,
        idInsuranceCards: true,
        idInsurance: true,
        surgicalDetails: true,
        quickActions: true,
        appointments: true,
        appointmentHistory: true,
        // v7.2: these open only from their own card, command or link
        dayOfSurgery: false,
        clearanceFiles: false,
        clearanceReview: false,
      });
      setActiveAiResults(['portalMessages', 'clearance', 'appointments', 'intakeForms', 'clinicalNotes', 'nursingNotes', 'documents', 'medications', 'financial', 'idInsurance', 'surgicalDetails', 'quickActions', 'aiWorkflows']);
    } else {
      setExpandedSections({
        demographics: true,
        aiBrief: true,
        portalMessages: sectionKey === 'portalMessages',
        aiWorkflows: sectionKey === 'aiWorkflows',
        docUpload: false,
        documents: sectionKey === 'documents',
        intakeForms: sectionKey === 'intakeForms',
        clinicalNotes: sectionKey === 'clinicalNotes',
        nursingNotes: sectionKey === 'nursingNotes',
        clearance: sectionKey === 'clearance',
        medications: sectionKey === 'medications',
        financial: sectionKey === 'financial',
        idInsuranceCards: sectionKey === 'idInsurance' || sectionKey === 'idInsuranceCards',
        idInsurance: sectionKey === 'idInsurance' || sectionKey === 'idInsuranceCards',
        surgicalDetails: sectionKey === 'surgicalDetails',
        quickActions: sectionKey === 'quickActions',
        appointments: sectionKey === 'appointments' || sectionKey === 'appointmentHistory',
        appointmentHistory: sectionKey === 'appointments' || sectionKey === 'appointmentHistory',
        dayOfSurgery: sectionKey === 'dayOfSurgery',
        clearanceFiles: sectionKey === 'clearanceFiles' || sectionKey === 'documents',
        clearanceReview: sectionKey === 'clearanceReview' || sectionKey === 'clearance',
      });
      setActiveAiResults([sectionKey]);
    }

    // Smooth scroll to the section if element exists
    setTimeout(() => {
      const target = sectionKey === 'clearance' ? 'clearanceReview' : sectionKey === 'documents' ? 'clearanceFiles' : sectionKey;
      const el = document.getElementById(`${target}-section`);
      if (el) {
        el.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    }, 100);
  };

  const handleAskAiSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!askAiInput.trim()) return;
    const query = askAiInput.trim();
    setAskAiInput('');

    let matchedKey = 'all';
    const qLower = query.toLowerCase();
    if (/day of surgery|work ?stations?|\bstations?\b/.test(qLower)) matchedKey = 'dayOfSurgery';
    else if (/clearance (file|doc)|h&p|\blabs?\b|ecg|ekg|document|record/.test(qLower)) matchedKey = 'clearanceFiles';
    else if (/review|alert|summar/.test(qLower)) matchedKey = 'clearanceReview';
    else if (/intake|check-?in|at-home/.test(qLower)) matchedKey = 'intakeForms';
    else if (qLower.includes('clear') || qLower.includes('pre-op') || qLower.includes('preop')) matchedKey = 'clearanceReview';
    else if (qLower.includes('intake') || qLower.includes('form')) matchedKey = 'intakeForms';
    else if (qLower.includes('doctor') || qLower.includes('clinical') || qLower.includes('h&p')) matchedKey = 'clinicalNotes';
    else if (qLower.includes('nurse') || qLower.includes('nursing')) matchedKey = 'nursingNotes';
    else if (qLower.includes('doc') || qLower.includes('record')) matchedKey = 'documents';
    else if (qLower.includes('med') || qLower.includes('rx') || qLower.includes('prescrip')) matchedKey = 'medications';
    else if (qLower.includes('pay') || qLower.includes('financ') || qLower.includes('bill') || qLower.includes('invoic')) matchedKey = 'financial';
    else if (qLower.includes('insurance') || qLower.includes('card') || qLower.includes('id')) matchedKey = 'idInsurance';
    else if (qLower.includes('surgeon') || qLower.includes('team') || qLower.includes('procedur')) matchedKey = 'surgicalDetails';
    else if (qLower.includes('appoint') || qLower.includes('visit') || qLower.includes('encounter') || qLower.includes('history') || qLower.includes('schedule')) matchedKey = 'appointments';
    else if (qLower.includes('action') || qLower.includes('quick')) matchedKey = 'quickActions';

    handleExecuteAiCommand(query, matchedKey);
  };

  // Image Zoom Lightbox Modal state
  const [zoomedImage, setZoomedImage] = useState<{ url: string; title: string; subtitle?: string } | null>(null);

  // Clinical Assessment PDF Forms Modal State
  const [isPdfFormsModalOpen, setIsPdfFormsModalOpen] = useState(false);
  const [activePdfFormTab, setActivePdfFormTab] = useState<'standing-orders' | 'preop-checklist' | 'surgical-checklist'>('standing-orders');

  // Pre-Surgery PDF Forms Email & Portal Intake state
  const [selectedPreOpFormIds, setSelectedPreOpFormIds] = useState<string[]>(
    PRE_OP_INTAKE_PDF_FORMS.map((f) => f.id)
  );
  const [formStatuses, setFormStatuses] = useState<Record<string, 'Pending Send' | 'Sent via Email' | 'Completed in Portal'>>({
    'patients-rights': 'Sent via Email',
    'hipaa-notice': 'Completed in Portal',
    'disclosure-ownership': 'Completed in Portal',
    'complaint-grievance': 'Sent via Email',
    'advanced-directives': 'Pending Send',
    'arbitration-agreement': 'Pending Send',
    'acknowledgement-receipt': 'Pending Send',
    'anesthesia-questionnaire': 'Pending Send',
    'consent-anesthesia': 'Pending Send',
    'mh-vte-assessment': 'Pending Send',
    'billing-fee-disclosure': 'Completed in Portal',
    'welcome-surgical-center': 'Sent via Email',
  });
  const [isPreOpEmailModalOpen, setIsPreOpEmailModalOpen] = useState(false);
  const [isPreOpPortalPreviewOpen, setIsPreOpPortalPreviewOpen] = useState(false);
  const [activePortalFormId, setActivePortalFormId] = useState<string>('patients-rights');
  const [preOpEmailSuccessToast, setPreOpEmailSuccessToast] = useState<string | null>(null);
  const [customEmailRecipient, setCustomEmailRecipient] = useState<string>('');

  // Patient Portal forms are no longer seeded from the legacy Intake Forms list.
  // They are derived exclusively from the current Form Studio workflow assignments.
  const [intakeFormsList, setIntakeFormsList] = useState<IntakeHtmlForm[]>([]);
  const [selectedIntakeFormIds, setSelectedIntakeFormIds] = useState<string[]>([]);
  const [viewingHtmlForm, setViewingHtmlForm] = useState<IntakeHtmlForm | null>(null);
  const [chartFormSignature, setChartFormSignature] = useState<string>('');
  const [sendFormModalItem, setSendFormModalItem] = useState<IntakeHtmlForm | null>(null);
  const [isSendFormsModalOpen, setIsSendFormsModalOpen] = useState(false);
  const [sendChannel, setSendChannel] = useState<'email' | 'sms'>('email');
  const [sendRecipient, setSendRecipient] = useState<string>('');
  const [portalHtmlForm, setPortalHtmlForm] = useState<IntakeHtmlForm | null>(null);
  const [portalTestIndex, setPortalTestIndex] = useState(0);

  const handleCompleteIntakeForm = (form: IntakeHtmlForm, signatureName: string) => {
    const signer = signatureName.trim() || selectedPatient.name;
    const dateStr = new Date().toLocaleDateString('en-US', { month: 'short', day: '2-digit', year: 'numeric' });
    const updated = intakeFormsList.map((f) => {
      if (f.id === form.id) {
        return {
          ...f,
          status: 'Completed in Portal' as const,
          completedDate: dateStr,
          signedBy: signer
        };
      }
      return f;
    });
    setIntakeFormsList(updated);

    if (viewingHtmlForm?.id === form.id) {
      setViewingHtmlForm({
        ...form,
        status: 'Completed in Portal',
        completedDate: dateStr,
        signedBy: signer
      });
    }

    // Also create verified PDF document in Documents
    const newDoc: DocumentItem = {
      id: `doc-signed-${Date.now()}`,
      title: `Signed ${form.title}`,
      fileName: `${form.fileName.replace(/\.html$/i, '')}_Signed.pdf`,
      type: 'Intake Forms',
      submissionDate: dateStr,
      status: 'Verified Signed',
      fileSize: '1.4 MB',
      summary: `Digitally executed and attested by ${signer} on ${dateStr}. Sealed with SHA-256 cryptographic audit trail.`,
      tags: ['Patient Attestation', 'Informed Consent', 'Signed'],
      content: `ELECTRONICALLY SIGNED INTAKE FORM\nTitle: ${form.title}\nPatient: ${selectedPatient.name} (ID: ${selectedPatient.patientId})\nSigner: ${signer}\nExecution Date: ${dateStr}\nStatus: Verified Legal Attestation & Consent\n\n[Full electronic form filed in EHR database]`
    };

    setDocList((prev) => [newDoc, ...prev]);
    showToast(`Form "${form.title}" completed, signed, and filed to chart!`);
  };

  // Upload Form Modal State
  const [isUploadIntakeModalOpen, setIsUploadIntakeModalOpen] = useState(false);
  const [uploadFormTitle, setUploadFormTitle] = useState('');
  const [uploadFormCategory, setUploadFormCategory] = useState<'Admission' | 'Insurance' | 'Medical' | 'Anesthesia'>('Admission');
  const [uploadFormAudience, setUploadFormAudience] = useState('Patient');
  const [uploadFormContent, setUploadFormContent] = useState('');
  // Whether this custom form needs the full legal e-signature panel (canvas
  // signature + attestation + audit trail) or completes with a lighter
  // "Mark as Reviewed" action. Defaults on, since most uploaded intake/consent
  // paperwork is signature-bearing; the practice admin can uncheck it for
  // purely informational documents (surveys, handouts, etc.).
  const [uploadFormRequiresSignature, setUploadFormRequiresSignature] = useState(true);

  // Electronic Clinical Forms Module State
  const [selectedAppointmentDateForForms, setSelectedAppointmentDateForForms] = useState<string>('');
  const [activeClinicalFormTab, setActiveClinicalFormTab] = useState<ClinicalFormTab>('asc-1-hp');

  // Notes HTML Forms Module State
  const [notesFormsList, setNotesFormsList] = useState<NoteHtmlForm[]>(INITIAL_NOTES_HTML_FORMS);
  const [viewingNoteForm, setViewingNoteForm] = useState<NoteHtmlForm | null>(null);

  // Nursing Notes HTML Forms Module State
  const [nursingFormsList, setNursingFormsList] = useState<NursingHtmlForm[]>([]);
  const [localPracticeForms, setLocalPracticeForms] = useState<LocalFormTemplate[]>([]);
  const [localPdfTemplates, setLocalPdfTemplates] = useState<LocalPdfTemplate[]>([]);
  const [workflowHtmlByKey, setWorkflowHtmlByKey] = useState<Record<WorkflowKey, IntakeHtmlForm[]>>(() => Object.fromEntries(FORM_WORKFLOWS.map(w => [w.key, []])) as Record<WorkflowKey, IntakeHtmlForm[]>);
  const [workflowPdfByKey, setWorkflowPdfByKey] = useState<Record<WorkflowKey, LocalPdfTemplate[]>>(() => Object.fromEntries(FORM_WORKFLOWS.map(w => [w.key, []])) as Record<WorkflowKey, LocalPdfTemplate[]>);
  const [intakePdfTemplates, setIntakePdfTemplates] = useState<LocalPdfTemplate[]>([]);
  const [selectedIntakePdfIds, setSelectedIntakePdfIds] = useState<string[]>([]);
  const [activeIntakePdf, setActiveIntakePdf] = useState<LocalPdfTemplate | null>(null);

  useEffect(() => {
    let cancelled = false;
    const loadWorkflowForms = async () => {
      if (!activePracticeId) {
        setLocalPracticeForms([]); setIntakeFormsList([]); setSelectedIntakeFormIds([]);
        setLocalPdfTemplates([]); setIntakePdfTemplates([]); setSelectedIntakePdfIds([]); setWorkflowHtmlByKey(Object.fromEntries(FORM_WORKFLOWS.map(w => [w.key, []])) as Record<WorkflowKey, IntakeHtmlForm[]>); setWorkflowPdfByKey(Object.fromEntries(FORM_WORKFLOWS.map(w => [w.key, []])) as Record<WorkflowKey, LocalPdfTemplate[]>);
        return;
      }

      try {
        const [customForms, pdfs] = await Promise.all([
          listCurrentPracticeForms(activePracticeId),
          listPdfTemplates(activePracticeId),
        ]);
        if (cancelled) return;
        setLocalPracticeForms(customForms);

        const assignedCatalog = VITYLS_FORM_CATALOG.filter(item => {
          const assignment = readWorkflowAssignment(item.file);
          return FORM_WORKFLOWS.some(w => assignment[w.key].enabled);
        });
        const resolvedForms = await Promise.all(assignedCatalog.map(async (item, index): Promise<IntakeHtmlForm> => {
          const savedHtml = localStorage.getItem(templateStorageKey(item.file));
          let htmlTemplate = savedHtml || '';
          if (!htmlTemplate) {
            if (item.file === 'Admission_Form.html') htmlTemplate = genericAdmissionHtml;
            else htmlTemplate = await bundledFetch(item.file).then(r => r.ok ? r.text() : '').catch(() => '');
          }

          const official = OFFICIAL_HTML_FORM_LIBRARY.find(t => t.sourceFile === item.file || t.title === item.title);
          let schemaFields: any[] = official?.fields || [];
          try {
            const savedSchema = JSON.parse(localStorage.getItem(schemaStorageKey(item.file)) || 'null');
            if (savedSchema?.fields) schemaFields = savedSchema.fields;
          } catch {/* use official schema */}
          const signatureZones = schemaFields.filter(f => f.type === 'signature').map(f => ({
            id: f.id, label: f.label || 'Signature', owner: f.owner, required: f.required !== false,
          }));

          const category: IntakeHtmlForm['category'] = item.title === 'Admission Form'
            ? 'Admission'
            : item.title.toLowerCase().includes('insurance')
            ? 'Insurance'
            : item.category === 'Anesthesia'
            ? 'Anesthesia'
            : 'Medical';

          return {
            id: `workflow-html-${item.file}`,
            order: index + 1,
            title: item.title,
            category,
            type: 'Vityls HTML Form',
            targetAudience: 'Patient Portal',
            status: 'Pending Send',
            fileName: item.file,
            summary: `${item.category} · ${item.stage}`,
            description: 'Assigned through Form Studio → Patient Portal workflow.',
            htmlTemplate,
            requiresSignature: signatureZones.length > 0,
            signatureZones,
          };
        }));

        const activePdfs = pdfs.filter(pdf => pdf.status !== 'Retired');
        const htmlGroups = Object.fromEntries(FORM_WORKFLOWS.map(w => [w.key, resolvedForms.filter(form => {
          const file = form.fileName;
          return isAssignedToWorkflow(file, w.key);
        })])) as Record<WorkflowKey, IntakeHtmlForm[]>;
        const pdfGroups = Object.fromEntries(FORM_WORKFLOWS.map(w => [w.key, activePdfs.filter(pdf => isAssignedToWorkflow(`pdf:${pdf.id}`, w.key))])) as Record<WorkflowKey, LocalPdfTemplate[]>;
        const portalForms = htmlGroups.patientPortal;
        const portalPdfs = pdfGroups.patientPortal;
        if (cancelled) return;
        setWorkflowHtmlByKey(htmlGroups);
        setWorkflowPdfByKey(pdfGroups);
        setIntakeFormsList(portalForms);
        setSelectedIntakeFormIds(portalForms.map(form => form.id));
        setLocalPdfTemplates(activePdfs);
        setIntakePdfTemplates(portalPdfs);
        setSelectedIntakePdfIds(portalPdfs.map(pdf => pdf.id));
      } catch {
        if (cancelled) return;
        setLocalPracticeForms([]); setIntakeFormsList([]); setSelectedIntakeFormIds([]);
        setLocalPdfTemplates([]); setIntakePdfTemplates([]); setSelectedIntakePdfIds([]); setWorkflowHtmlByKey(Object.fromEntries(FORM_WORKFLOWS.map(w => [w.key, []])) as Record<WorkflowKey, IntakeHtmlForm[]>); setWorkflowPdfByKey(Object.fromEntries(FORM_WORKFLOWS.map(w => [w.key, []])) as Record<WorkflowKey, LocalPdfTemplate[]>);
      }
    };
    loadWorkflowForms();
    const refresh = () => loadWorkflowForms();
    window.addEventListener('focus', refresh);
    window.addEventListener('vityls-form-workflow-updated', refresh as EventListener);
    return () => { cancelled = true; window.removeEventListener('focus', refresh); window.removeEventListener('vityls-form-workflow-updated', refresh as EventListener); };
  }, [selectedPatient.id, activePracticeId]);

  const [selectedSurgicalEpisode, setSelectedSurgicalEpisode] = useState<string>('ep-current');
  const [viewingFullNursingForm, setViewingFullNursingForm] = useState<NursingHtmlForm | null>(null);
  const [editingNursingForm, setEditingNursingForm] = useState<NursingHtmlForm | null>(null);
  // Clinical Workflow full-page state — set to the active role to open the
  // Nursing / Anesthesia / Surgeons workflow page for the selected patient.
  const [activeClinicalWorkflowRole, setActiveClinicalWorkflowRole] = useState<ClinicalWorkflowRole | null>(null);
  const [isCaseRecordOpen, setIsCaseRecordOpen] = useState(false);

  // Schedule-to-clinical handoff: accepting a patient from the Nursing queue
  // opens the role workspace automatically instead of making the RN hunt for it.
  useEffect(() => {
    if (initialSelectedSection === 'nursing-workflow') setActiveClinicalWorkflowRole('Nursing');
    if (initialSelectedSection === 'anesthesia-workflow') setActiveClinicalWorkflowRole('Anesthesia');
    if (initialSelectedSection === 'surgeon-workflow') setActiveClinicalWorkflowRole('Surgeons');
  }, [initialSelectedSection, selectedPatient.id]);
  const [saveEpisodeSuccessToast, setSaveEpisodeSuccessToast] = useState<string | null>(null);

  const handleIframeAutoHeight = (e: React.SyntheticEvent<HTMLIFrameElement>) => {
    const iframe = e.currentTarget;
    if (iframe && iframe.contentWindow && iframe.contentWindow.document) {
      const doc = iframe.contentWindow.document;
      const body = doc.body;
      const html = doc.documentElement;
      if (body) {
        body.style.overflow = 'hidden';
        const height = Math.max(
          body.scrollHeight,
          body.offsetHeight,
          html ? html.clientHeight : 0,
          html ? html.scrollHeight : 0,
          html ? html.offsetHeight : 0
        );
        if (height > 0) {
          iframe.style.height = `${height + 40}px`;
        }
      }
    }
  };

  // Draft Note Workspace state (Image 1)
  const [isNoteWorkspaceOpen, setIsNoteWorkspaceOpen] = useState(false);
  const [draftNoteContent, setDraftNoteContent] = useState('');
  const [viewingHistoryNote, setViewingHistoryNote] = useState<{ id: string; title: string; author: string; date: string; status: string; content: string } | null>(null);

  const openFormsForAppointment = (dateStr: string, defaultTab: ClinicalFormTab = 'asc-1-hp') => {
    setSelectedAppointmentDateForForms(dateStr);
    setActiveClinicalFormTab(defaultTab);
    setActiveSubTab('Documents');
  };

  // E-Prescribe Modal state
  const [isEPrescribeOpen, setIsEPrescribeOpen] = useState(false);
  const [eRxData, setERxData] = useState({
    medication: 'Amoxicillin / Clavulanate (Augmentin)',
    dosage: '875mg / 125mg Oral Tablet',
    instructions: 'Take 1 tablet by mouth twice daily for 7 days',
    quantity: '14',
    refills: '0',
    pharmacy: '',
  });
  const [eRxSuccess, setERxSuccess] = useState(false);

  // Derived card URLs with automatic fallback
  const idCardUrl = selectedPatient.idCardUrl || generateSampleDriverLicense(selectedPatient.name, selectedPatient.dob || '02/11/1972');
  const driverLicenseUrl = idCardUrl;
  const insuranceCardFrontUrl = selectedPatient.insuranceCardFrontUrl || generateSampleInsuranceFront(selectedPatient.name);
  const insuranceCardBackUrl = selectedPatient.insuranceCardBackUrl || generateSampleInsuranceBack();

  // Current Visit To-Do Tasks State
  const [todoTasks, setTodoTasks] = useState([
    { id: 'task-1', text: 'Confirm appointment', completed: true, category: 'Pre-Op Scheduling' },
    { id: 'task-2', text: 'Obtain medical records & clearance', completed: true, category: 'Medical Clearance' },
    { id: 'task-3', text: 'Collect payment', completed: true, category: 'Financial / Billing' },
    { id: 'task-4', text: 'Pre-op phone call', completed: true, category: 'Patient Prep Call' },
    { id: 'task-5', text: 'Patient check-in', completed: true, category: 'Patient Check-In' },
    { id: 'task-6', text: 'Nursing check-in & surgical readiness', completed: false, category: 'Nursing Readiness' },
    { id: 'task-7', text: 'Verified & signed consent', completed: false, category: 'Surgical Consents' },
    { id: 'task-8', text: 'Post-operative paperwork', completed: false, category: 'Post-Op Paperwork' },
    { id: 'task-9', text: 'Patient survey', completed: false, category: 'Patient Survey' },
    { id: 'task-10', text: 'Case finished', completed: false, category: 'Case Complete' },
  ]);

  // Payment & Financial Brief state for Patient Nightingale Brief
  interface PatientPaymentRecord {
    patientId: string;
    source: 'self-pay' | 'doctor-to-pay' | 'insurance' | 'other';
    received: boolean;
    amount: number;
    date: string;
    method: string;
    notes: string;
    invoiceNumber?: string;
  }

  const [patientPayments, setPatientPayments] = useState<{ [key: string]: PatientPaymentRecord }>({
    'p-101': {
      patientId: 'p-101',
      source: 'self-pay',
      received: true,
      amount: 14500,
      date: '2026-07-28',
      method: 'Credit Card (Stripe Patient Portal)',
      notes: 'Pre-op balance paid in full. Facility fee ($8,500) & Surgeon fee ($6,000) settled.',
      invoiceNumber: 'INV-2026-901',
    },
    'p-102': {
      patientId: 'p-102',
      source: 'insurance',
      received: true,
      amount: 18200,
      date: '2026-07-25',
      method: 'Commercial PPO Electronic Remittance (ERA)',
      notes: 'Primary insurance Blue Shield PPO cleared with $500 patient copay.',
      invoiceNumber: 'INV-2026-884',
    },
    'p-103': {
      patientId: 'p-103',
      source: 'doctor-to-pay',
      received: false,
      amount: 9800,
      date: '',
      method: 'Physician Courtesy Account',
      notes: 'Professional courtesy / Doctor house account. Facility fee pending administrative invoice creation.',
      invoiceNumber: '',
    },
    'p-104': {
      patientId: 'p-104',
      source: 'self-pay',
      received: false,
      amount: 16500,
      date: '',
      method: 'Pending Patient Payment',
      notes: 'Self-pay surgical estimate issued. Pre-op deposit outstanding ahead of OR prep.',
      invoiceNumber: '',
    },
  });

  const [isBlankInvoiceModalOpen, setIsBlankInvoiceModalOpen] = useState(false);
  const [isCreateInvoiceModalOpen, setIsCreateInvoiceModalOpen] = useState(false);
  const [isCollectDepositModalOpen, setIsCollectDepositModalOpen] = useState(false);
  const [isInvoiceSendConfirmOpen, setIsInvoiceSendConfirmOpen] = useState(false);
  const [invoiceDeliveryMethod, setInvoiceDeliveryMethod] = useState<'Email' | 'SMS' | 'Email + SMS'>('Email');
  const [patientCredits, setPatientCredits] = useState<{ [key: string]: number }>({});
  const [depositForm, setDepositForm] = useState({ amount: 0, method: 'Credit Card', type: 'Deposit / Account Credit', reference: '', notes: '' });

  // New Invoice Form State inside Patient Chart
  const [newInvoiceForm, setNewInvoiceForm] = useState({
    patientName: '',
    patientId: '',
    source: 'self-pay' as 'self-pay' | 'doctor-to-pay' | 'insurance' | 'other',
    facilityFee: 8500,
    surgeonFee: 6000,
    anesthesiaFee: 1200,
    implantCharges: 800,
    discounts: 0,
    paymentReceivedAmount: 0,
    paymentDate: new Date().toISOString().split('T')[0],
    notes: '',
  });

  // Blank Invoice Editable Form State
  const [blankInvoiceData, setBlankInvoiceData] = useState({
    invoiceNumber: `INV-BLANK-${Math.floor(1000 + Math.random() * 9000)}`,
    invoiceDate: new Date().toISOString().split('T')[0],
    dueDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    patientName: '',
    patientId: '',
    dob: '',
    guarantor: '',
    dos: new Date().toISOString().split('T')[0],
    surgeon: 'Provider',
    anesthesiologist: '',
    procedure: '',
    facilityFee: 0,
    surgeonFee: 0,
    anesthesiaFee: 0,
    implantCharges: 0,
    medicationCharges: 0,
    discounts: 0,
    paymentsReceived: 0,
  });

  // Derived current payment record for selected patient
  const currentPayment = patientPayments[selectedPatient.patientId] || {
    patientId: selectedPatient.patientId,
    source: 'self-pay',
    received: false,
    amount: 14500,
    date: '',
    method: 'Pending Payment',
    notes: 'Surgical encounter estimated charges pending payment confirmation.',
    invoiceNumber: '',
  };

  
  // Q&A state for Nightingale patient summary
  const [questionText, setQuestionText] = useState('');
  const [chatLog, setChatLog] = useState<Array<{ sender: 'Clinician' | 'Nightingale'; text: string }>>([
    {
      sender: 'Nightingale',
      text: "Ask about allergies, labs, medications, clearance, consents or the procedure. I answer only from what is recorded in this chart and say so when something is not recorded. I don't sign, clear or order.",
    },
  ]);

  const handleAskQuestion = (e: React.FormEvent) => {
    e.preventDefault();
    if (!questionText.trim()) return;

    const userQ = questionText.trim();
    setChatLog((prev) => [...prev, { sender: 'Clinician', text: userQ }]);
    setQuestionText('');

    // Generate responsive Nightingale answer based on user question
    setTimeout(() => {
      // Safety fix: answer only from what is recorded in this chart, or say it is not recorded.
      const aiAns = answerFromLegacyChart(selectedPatient, userQ);
      setChatLog((prev) => [...prev, { sender: 'Nightingale', text: aiAns }]);
    }, 600);
  };

  return (
    <div className="w-full space-y-6 animate-in fade-in duration-300">


      {/* Top Section Toggle Control Bar (Hidden as requested) */}
      {false && (
        <div className="bg-white p-3.5 rounded-2xl border border-stone-200/90 shadow-2xs flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-emerald-50 text-emerald-700 rounded-xl border border-emerald-200/80">
              <FolderOpen className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-xs font-bold text-stone-900">
                Patient Chart Sections ({Object.values(expandedSections).filter(Boolean).length} / {Object.keys(expandedSections).length} Expanded)
              </h3>
              <p className="text-[11px] text-stone-500 font-medium">
                Click any section title or arrow to toggle view details. All major sections are collapsed by default.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={expandAllSections}
              className="px-3 py-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 text-xs font-bold rounded-xl border border-emerald-200 transition-colors cursor-pointer"
            >
              Expand All Sections
            </button>
            <button
              onClick={collapseAllSections}
              className="px-3 py-1.5 bg-stone-100 hover:bg-stone-200 text-stone-700 text-xs font-bold rounded-xl border border-stone-200 transition-colors cursor-pointer"
            >
              Collapse All Sections
            </button>
          </div>
        </div>
      )}
      
      {/* Top Patient Chart Search & Quick-Switch Navigation Bar (Visible in Classic Mode) */}
      <div className="bg-white px-4 py-3 rounded-2xl border border-stone-200/90 shadow-2xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          
          {/* Dynamic Search Input with 3-letter Last Name Matching */}
          <div ref={chartSearchContainerRef} className="relative flex-1 max-w-xl">
            <div className="relative">
              <Search className="w-4 h-4 text-stone-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                type="text"
                value={chartSearchQuery}
                onChange={(e) => {
                  setChartSearchQuery(e.target.value);
                  setIsChartSearchFocused(true);
                }}
                onFocus={() => setIsChartSearchFocused(true)}
                onKeyDown={(e) => {
                  if (e.key === 'Escape') {
                    setIsChartSearchFocused(false);
                  }
                }}
                placeholder="Enter first 3 letters of patient last name (e.g. 'Ros', 'Ken', 'Van', 'Hol')..."
                className="w-full pl-10 pr-9 py-2.5 bg-stone-50 border border-stone-200 rounded-xl text-xs font-semibold text-stone-900 placeholder:text-stone-400 focus:outline-hidden focus:ring-2 focus:ring-sky-500 focus:bg-white transition-all shadow-2xs"
                autoComplete="off"
                id="patient-chart-dynamic-search-input"
              />
              {chartSearchQuery && (
                <button
                  type="button"
                  onClick={() => {
                    setChartSearchQuery('');
                    setIsChartSearchFocused(false);
                  }}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-stone-400 hover:text-stone-600 p-0.5 cursor-pointer"
                  title="Clear search"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>

            {/* Dynamic Search Results Dropdown */}
            {isChartSearchFocused && (
              <>
                {chartSearchQuery.trim().length >= 3 ? (() => {
                  const matches = searchPatientsByLastName(chartSearchQuery, cases, { minChars: 3 });
                  return (
                    <div className="absolute left-0 top-full mt-1.5 w-full bg-white rounded-2xl border border-sky-300 shadow-2xl z-50 p-2.5 max-h-80 overflow-y-auto animate-in fade-in zoom-in-95 duration-150">
                      <div className="px-3 py-2 text-[11px] font-bold text-sky-950 bg-sky-50/90 rounded-xl flex items-center justify-between mb-2 border border-sky-200">
                        <span className="flex items-center gap-1.5">
                          <Search className="w-3.5 h-3.5 text-sky-600" />
                          Matching Patients ({matches.length})
                        </span>
                        <span className="text-[10px] text-sky-700 font-semibold bg-white px-2 py-0.5 rounded-md border border-sky-200">
                          Click patient to load chart
                        </span>
                      </div>

                      {matches.length === 0 ? (
                        <div className="p-4 text-center text-xs text-stone-500">
                          <p className="font-semibold text-stone-700">No patient records found matching "{chartSearchQuery}".</p>
                          <p className="text-[11px] text-stone-400 mt-1">Please verify the spelling of the patient's last name.</p>
                        </div>
                      ) : (
                        <div className="space-y-1.5">
                          {matches.map((p) => {
                            const isSelected = (selectedPatient.id === p.id) || (selectedPatient.patientId === p.patientId) || (selectedPatient.name.toLowerCase() === p.name.toLowerCase());
                            return (
                              <button
                                key={p.id || p.patientId}
                                type="button"
                                onClick={() => {
                                  const newCase = convertMasterRecordToPatientCase(p, cases);
                                  setSelectedPatient(newCase);
                                  setChartSearchQuery('');
                                  setIsChartSearchFocused(false);
                                  showToast(`Loaded chart for ${p.name} (DOB: ${p.dob} • Tel: ${p.phone})`);
                                }}
                                className={`w-full text-left p-3 rounded-xl transition-all cursor-pointer border group ${
                                  isSelected
                                    ? 'bg-sky-50 border-sky-300 ring-2 ring-sky-400/40 shadow-2xs'
                                    : 'hover:bg-sky-50/60 border-stone-200 hover:border-sky-200 bg-white'
                                }`}
                              >
                                {/* Top Line: Name, Avatar, MRN, Age & Gender */}
                                <div className="flex items-center justify-between gap-2">
                                  <div className="flex items-center gap-2.5 min-w-0">
                                    <div className="w-7 h-7 rounded-full bg-sky-100 text-sky-900 font-bold text-xs flex items-center justify-center shrink-0 border border-sky-200 group-hover:bg-sky-600 group-hover:text-white transition-colors">
                                      {p.name.split(' ').map((n) => n[0]).join('')}
                                    </div>
                                    <div className="min-w-0">
                                      <div className="flex items-center gap-2">
                                        <span className="font-bold text-sm text-stone-900 group-hover:text-sky-950 truncate">
                                          {p.name}
                                        </span>
                                        {isSelected && (
                                          <span className="text-[9px] font-bold px-1.5 py-0.5 rounded-full bg-sky-600 text-white shadow-2xs">
                                            ACTIVE
                                          </span>
                                        )}
                                      </div>
                                      <span className="text-[11px] text-stone-500 font-medium">
                                        MRN: #{p.patientId}
                                      </span>
                                    </div>
                                  </div>
                                  <span className="text-[11px] font-bold px-2.5 py-1 rounded-lg bg-stone-100 text-stone-700 group-hover:bg-sky-100 group-hover:text-sky-900 shrink-0">
                                    Age {p.age} · {p.gender || 'Female'}
                                  </span>
                                </div>

                                {/* Bottom Line: Phone Number & Date of Birth */}
                                <div className="grid grid-cols-2 gap-3 mt-2 pt-2 border-t border-stone-100 text-xs font-semibold">
                                  <span className="flex items-center gap-1.5 text-stone-700">
                                    <Phone className="w-3.5 h-3.5 text-sky-600 shrink-0" />
                                    <span>Phone: <strong className="text-stone-900">{p.phone}</strong></span>
                                  </span>
                                  <span className="flex items-center gap-1.5 text-stone-700 justify-end">
                                    <Calendar className="w-3.5 h-3.5 text-sky-600 shrink-0" />
                                    <span>DOB: <strong className="text-stone-900">{p.dob}</strong></span>
                                  </span>
                                </div>

                                {p.procedure && (
                                  <div className="text-[11px] text-stone-500 truncate mt-1.5 font-medium flex items-center gap-1">
                                    <span className="text-stone-400">Procedure:</span>
                                    <span className="text-stone-700 truncate">{p.procedure}</span>
                                  </div>
                                )}
                              </button>
                            );
                          })}
                        </div>
                      )}
                    </div>
                  );
                })() : chartSearchQuery.trim().length > 0 ? (
                  <div className="absolute left-0 top-full mt-1.5 w-full bg-white rounded-xl border border-sky-200 shadow-lg z-50 p-3 text-xs text-stone-600 animate-in fade-in zoom-in-95 duration-100">
                    <div className="flex items-center gap-2 text-sky-800 font-semibold">
                      <Search className="w-4 h-4 text-sky-600 shrink-0" />
                      <span>Type at least 3 letters of patient's last name to search</span>
                    </div>
                    <p className="text-[11px] text-stone-400 mt-1 pl-6">
                      Search by patient name, ID, or date of birth.
                    </p>
                  </div>
                ) : null}
              </>
            )}
          </div>

          {/* Quick-Switch Chips for Practice Patients */}
          <div className="flex items-center gap-1.5 flex-wrap">
            {onOpenAddPatient && (
              <button
                type="button"
                onClick={onOpenAddPatient}
                className="px-2.5 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer bg-[#1F6E52] hover:bg-[#17553F] text-white border border-[#17553F] shadow-2xs mr-1.5"
                title="Register a new patient"
              >
                <UserPlus className="w-3.5 h-3.5" />
                Add Patient
              </button>
            )}
            <span className="text-[10px] font-bold text-stone-400 uppercase tracking-wider mr-1">
              Quick Switch:
            </span>
            {getAllMasterPatients(cases).slice(0, 5).map((mp) => {
              const isActive = (selectedPatient.id === mp.id) || (selectedPatient.patientId === mp.patientId) || (selectedPatient.name.toLowerCase() === mp.name.toLowerCase());
              return (
                <button
                  key={mp.patientId}
                  type="button"
                  onClick={() => {
                    const newCase = convertMasterRecordToPatientCase(mp, cases);
                    setSelectedPatient(newCase);
                    setChartSearchQuery('');
                    setIsChartSearchFocused(false);
                    showToast(`Active Chart: ${mp.name}`);
                  }}
                  className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition-all cursor-pointer border ${
                    isActive
                      ? 'bg-[#1f6e52] text-white border-[#17573f] shadow-2xs'
                      : 'bg-stone-50 text-stone-700 border-stone-200 hover:bg-stone-100'
                  }`}
                >
                  {mp.name}
                </button>
              );
            })}
          </div>

        </div>
      </div>

      {/* Main Workspace Layout: 2/3 and 1/3 Grid Columns */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* Left Column: 2/3 of page (8 cols) */}
        <div className="lg:col-span-8 space-y-6">
          
          {/* Patient ID Header — restored preferred identity design; photo + Profile added. */}
          <div className="bg-white rounded-md border border-stone-200 shadow-2xs overflow-hidden">
            <div className="p-5">
              <div className="flex flex-wrap items-start justify-between gap-5">
                <div className="flex items-start gap-4 min-w-0">
                  <div className="relative shrink-0">
                    <input
                      ref={photoInputRef}
                      type="file"
                      accept="image/*"
                      capture="environment"
                      className="hidden"
                      onChange={handlePatientPhotoFileChange}
                      id="patient-photo-file-input"
                    />
                    <button
                      type="button"
                      onClick={() => photoInputRef.current?.click()}
                      className="w-16 h-16 rounded-md overflow-hidden border border-[#D7E5DD] bg-[#E7F1EB] shadow-2xs block cursor-pointer relative group"
                      title="Take or upload patient photo"
                    >
                      {currentPatientPhotoUrl ? (
                        <img src={currentPatientPhotoUrl} alt={selectedPatient.name} className="w-full h-full object-cover" />
                      ) : (
                        <div className="w-full h-full text-[#0F5A43] font-black text-base tracking-[0.12em] flex items-center justify-center">
                          {selectedPatient.name.split(' ').map((n) => n[0]).join('').slice(0,3)}
                        </div>
                      )}
                      <div className="absolute inset-0 bg-black/0 group-hover:bg-black/35 transition-colors flex items-center justify-center opacity-0 group-hover:opacity-100">
                        <Camera className="w-5 h-5 text-white" />
                      </div>
                    </button>
                  </div>

                  <div className="min-w-0">
                    <div className="flex flex-wrap items-center gap-3">
                      <h2 className="text-[28px] leading-none font-serif text-[#142D24] tracking-tight">{selectedPatient.name}</h2>
                    </div>
                    <div className="mt-2 text-[12px] text-stone-600 font-medium">
                      {selectedPatient.id === 'local-empty-patient'
                        ? `Demographics not entered · MRN ${selectedPatient.patientId}`
                        : `${selectedPatient.age} · ${selectedPatient.gender} · DOB ${selectedPatient.dob || 'Not entered'} · MRN ${selectedPatient.patientId} · Provider `}
                      {selectedPatient.id !== 'local-empty-patient' && <strong className="text-stone-800">{selectedPatient.surgeon || 'Unassigned'}</strong>}
                    </div>
                    <div className="mt-2 flex flex-wrap items-center gap-x-5 gap-y-1 text-[12px] text-stone-500 font-medium">
                      <span>{currentContactInfo.address}</span>
                      <span>{currentContactInfo.phone}</span>
                      <span>{currentContactInfo.email}</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2 ml-auto flex-wrap justify-end">
                  {selectedPatient.id !== 'local-empty-patient' && <BalanceChip caseId={selectedPatient.id} paymentType={selectedPatient.paymentType} onClick={() => handleExecuteAiCommand('Billing', 'financial')} />}
                  <button
                    type="button"
                    onClick={openEditContactModal}
                    className="vy-btn vy-btn-edit"
                    data-testid="open-profile"
                    title="Open and edit the patient profile"
                  >
                    <User className="w-3.5 h-3.5" />
                    Profile
                  </button>
                  <button
                    type="button"
                    onClick={() => onOpenVitylsNext?.(selectedPatient, 'nursing')}
                    className="vy-btn vy-btn-secondary"
                    data-testid="open-workstations"
                    title="Open the day-of-surgery workstations for this patient to review, verify and find incomplete records"
                  >
                    <ClipboardCheckIcon className="w-4 h-4" />
                    Workstations
                  </button>
                  {patientUnreadCount > 0 && <button type="button" onClick={() => handleExecuteAiCommand('Show Patient Portal Messages', 'portalMessages')} className="vy-btn vy-btn-secondary" title="Unread portal messages">{patientUnreadCount} new message{patientUnreadCount > 1 ? 's' : ''}</button>}
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-2 mt-5">
                <AllergyStatus allergies={selectedPatient.allergies} patientId={selectedPatient.id} testId="chart-allergy" />
                <div className="bg-[#F7F8F6] border border-stone-200 rounded-sm px-4 py-3 min-h-[70px]">
                  <div className="text-[9px] font-black uppercase tracking-[0.16em] text-stone-500">Major Medications</div>
                  <div className="mt-2 text-[13px] font-bold text-[#142D24]">
                    {selectedPatient.medications?.length ? selectedPatient.medications.map((m:any)=>typeof m==='string'?m:(m.name||m.medication||'')).filter(Boolean).join(', ') : 'None documented'}
                  </div>
                </div>
                <div className="bg-[#F7F8F6] border border-stone-200 rounded-sm px-4 py-3 min-h-[70px]">
                  <div className="text-[9px] font-black uppercase tracking-[0.16em] text-stone-500">Chronic Conditions</div>
                  <div className="mt-2 text-[13px] font-bold text-[#142D24]">
                    {selectedPatient.conditions?.length ? selectedPatient.conditions.join(', ') : 'None documented'}
                  </div>
                </div>
              </div>

              {effectiveAllergy(selectedPatient.allergies, selectedPatient.id).state === 'not-reported' && (
                <div className="mt-2 border border-[#D8DED9] bg-[#FAFBF9] rounded-sm px-3.5 py-2.5 text-[14px] leading-relaxed text-[#6b4708]" data-testid="allergy-not-reported-note">
                  <span className="font-semibold">Allergy status not reported.</span> Record allergies or NKDA (Profile, intake or nursing) before any medication order.
                </div>
              )}
            </div>
          </div>

          {/* Current Encounter — restored preferred encounter design. */}
          <div className="bg-white rounded-md border border-stone-200 shadow-2xs overflow-hidden">
            <div className="px-5 py-4 flex flex-wrap items-start justify-between gap-3 border-b border-stone-200">
              <div>
                <div className="text-[11px] font-black uppercase tracking-[0.18em] text-[#173F32]">Current Encounter</div>
                <div className="mt-2 text-[12px] text-stone-500 font-medium">
                  {selectedPatient.room || 'OR-2'} · {selectedPatient.procedure || 'Procedure not scheduled'} · {selectedPatient.scheduledTime || 'Time pending'}
                </div>
              </div>
              <div className="flex flex-wrap items-center gap-1.5">
                <span className="px-2.5 py-1 rounded-sm bg-[#F5F1E5] text-[#4E4A38] text-[9px] font-black uppercase tracking-[0.12em]">Live AI</span>
                <span className="px-2.5 py-1 rounded-sm bg-[#E2F0E8] text-[#1D5C46] text-[9px] font-black uppercase tracking-[0.12em]">Clearance Reviewed</span>
                <span className="px-2.5 py-1 rounded-sm bg-[#F1F2EF] text-stone-500 text-[9px] font-black uppercase tracking-[0.12em]">{selectedPatient.appointmentDate ? 'Appointment Scheduled' : 'Appointment Unconfirmed'}</span>
              </div>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 border-b border-stone-200">
              {[
                ['Reason', selectedPatient.procedure || 'Not scheduled'],
                ['Surgeon', selectedPatient.surgeon || 'Unassigned'],
                ['Anesthesia', selectedPatient.anesthesiologist || 'Unassigned'],
                ['DOS', selectedPatient.scheduledTime || 'Time pending'],
              ].map(([label,value],i) => (
                <div key={label} className={`px-5 py-5 min-h-[110px] ${i < 3 ? 'md:border-r border-stone-200' : ''} ${i < 2 ? 'border-b md:border-b-0 border-stone-200' : ''}`}>
                  <div className="text-[9px] font-black uppercase tracking-[0.17em] text-stone-500">{label}</div>
                  <div className={`mt-7 text-[13px] font-bold ${value === 'Unassigned' || value === 'Not scheduled' ? 'text-[#8A6514]' : 'text-[#142D24]'}`}>{value}</div>
                </div>
              ))}
            </div>

            <div className="px-5 py-4">
              <div className="text-[9px] font-black uppercase tracking-[0.18em] text-stone-500">Nightingale Brief</div>
              <p className="mt-3 text-[13px] leading-relaxed text-[#263A32]">
                {selectedPatient.id === 'local-empty-patient'
                  ? 'Patient and encounter information will populate here as scheduling, intake, records, and clearance information are collected.'
                  : (selectedPatient.aiHistory || `${selectedPatient.age}-year-old ${selectedPatient.gender?.toLowerCase()} for ${selectedPatient.procedure || 'the current encounter'}. Nightingale is monitoring intake, pre-operative records, clearance, and unresolved clinical discrepancies before the day-of-surgery workflow.`)}
              </p>
              {selectedPatient.id !== 'local-empty-patient' && (
                <div className="mt-4 pt-3 border-t border-stone-200 text-[12px] leading-relaxed text-stone-500">
                  <strong className="text-[#142D24]">Previous · {selectedPatient.previousVisitDate || '14 March 2026'} · Pre-operative consultation.</strong>{' '}
                  {selectedPatient.previousVisitSummary || 'Prior clinical summary remains available here with response to treatment and relevant follow-up.'}
                </div>
              )}
            </div>
          </div>

          {/* Active Content Section Display (Shown On-Demand Based on Selected Command) */}

          {/* Legacy standalone clearance checklist removed. Clearance readiness now lives inside Day of Surgery Journey. */}

          {/* Section: Chart Intelligence Overview */}
          {/* Safety fix: the legacy 'Chart Intelligence Overview' showed canned clinical findings (airway class, labs) not drawn from the chart; hidden in both editions. */}
          {false && (expandedSections.aiWorkflows || expandedSections.all) && (
            <div id="aiWorkflows-section">
              <AIPatientChartOverview
                patient={selectedPatient}
                onShowToast={showToast}
              />
            </div>
          )}

                    {selectedPatient.id === 'local-empty-patient' && (expandedSections.documents || expandedSections.all) && (
            <MasterFormsDocumentsFolder
              patient={selectedPatient}
              activePracticeId={activePracticeId}
              onOpenForm={(form) => {
                const runtimeForm = localTemplateToIntakeForm(form);
                setViewingHtmlForm(runtimeForm);
              }}
            />
          )}

{/* Section 1: Documents — v7: replaced by Case Tracker 03 · Pre-op clearance files (real per-case documents) */}
          {false && selectedPatient.id !== 'local-empty-patient' && (expandedSections.documents || expandedSections.all) && (
          <div id="documents-section" className="bg-white rounded-2xl border border-stone-200/90 shadow-2xs overflow-hidden transition-all">
            <button
              onClick={() => toggleSection('documents')}
              className="w-full p-4 flex items-center justify-between gap-4 text-left hover:bg-stone-50/80 transition-colors cursor-pointer"
            >
              <div className="flex items-center gap-3 min-w-0">
                <div className="w-8 h-8 rounded-xl bg-emerald-600 text-white flex items-center justify-center shadow-xs shrink-0">
                  <FileText className="w-4 h-4 text-white" />
                </div>
                <div className="min-w-0">
                  <div className="flex items-center gap-2">
                    <h3 className="text-sm font-bold text-stone-900 truncate">Documents</h3>
                    <span className="px-2.5 py-0.5 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-200 text-[10px] font-bold">
                      9 Verified Records
                    </span>
                  </div>
                  <div className="flex items-center gap-1.5 text-xs text-stone-600 font-medium mt-0.5 truncate">
                    <Sparkles className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
                    <span><strong>AI Summary:</strong> 9 the practice PDF records converted into interactive HTML forms for DOS .</span>
                  </div>
                </div>
              </div>

              <div className="p-1.5 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-700 transition-colors shrink-0">
                <ChevronDown className={`w-5 h-5 text-stone-600 transition-transform duration-200 ${expandedSections.documents ? 'rotate-180' : ''}`} />
              </div>
            </button>

            {expandedSections.documents && (
              <div className="p-5 border-t border-stone-200/80 bg-white space-y-6 animate-in fade-in duration-200">
                {/* Toast Notification Banner */}
                {toastMessage && (
                  <div className="p-3.5 bg-emerald-600 text-white font-bold text-xs rounded-xl shadow-md flex items-center justify-between animate-in fade-in slide-in-from-top-2 duration-200">
                    <div className="flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4 text-emerald-200" />
                      <span>{toastMessage}</span>
                    </div>
                    <button
                      onClick={() => setToastMessage(null)}
                      className="text-emerald-200 hover:text-white text-xs font-bold cursor-pointer"
                    >
                      ✕
                    </button>
                  </div>
                )}

                {/* Section Header & Toolbar */}
                <div className="flex flex-wrap items-center justify-between border-b border-stone-200/80 pb-4 gap-4">
                  <div>
                    <h3 className="font-bold text-base text-stone-900 flex items-center gap-2">
                      <FileText className="w-5 h-5 text-indigo-600" />
                      <span>Uploaded Patient Documents & Clinical Records</span>
                      <span className="px-2.5 py-0.5 rounded-full bg-indigo-100 text-indigo-900 text-xs font-bold border border-indigo-200">
                        {filteredDocList.length} Files
                      </span>
                    </h3>
                    <p className="text-xs text-stone-500 mt-1">
                      Structured index of all uploaded records, converted PDF assessment forms, consents, and lab reports for {selectedPatient.name}
                    </p>
                  </div>

                  <div className="flex items-center gap-2.5">
                    {/* Upload Document Button */}
                    <label className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-xl flex items-center gap-2 shadow-sm transition-colors cursor-pointer">
                      <Upload className="w-4 h-4 text-indigo-200" />
                      <span>Upload Document</span>
                      <input
                        type="file"
                        className="hidden"
                        onChange={handleFileUpload}
                      />
                    </label>
                  </div>
                </div>

                {/* Search Bar & Category Filters */}
                <div className="space-y-3">
                  <div className="flex flex-wrap items-center gap-3">
                    <div className="relative flex-1 min-w-[240px]">
                      <Search className="w-4 h-4 text-stone-400 absolute left-3.5 top-3" />
                      <input
                        type="text"
                        value={docSearchQuery}
                        onChange={(e) => setDocSearchQuery(e.target.value)}
                        placeholder="Search by file name, submission date, or category..."
                        className="w-full pl-10 pr-4 py-2 bg-stone-50 border border-stone-300 rounded-xl text-xs text-stone-800 focus:outline-none focus:ring-2 focus:ring-indigo-500 font-medium"
                      />
                      {docSearchQuery && (
                        <button
                          onClick={() => setDocSearchQuery('')}
                          className="absolute right-3 top-2.5 text-stone-400 hover:text-stone-600 text-xs font-bold"
                        >
                          ✕
                        </button>
                      )}
                    </div>
                  </div>

                  {/* Category Filter Pills */}
                  <div className="flex flex-wrap gap-1.5">
                    {['All', 'Converted PDF Form', 'Clinical Note', 'Consent', 'Laboratory', 'Outside Record', 'ID & Insurance', 'Uploaded Document'].map((cat) => (
                      <button
                        key={cat}
                        onClick={() => setDocFilterCategory(cat)}
                        className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                          docFilterCategory === cat
                            ? 'bg-indigo-900 text-white shadow-xs'
                            : 'bg-stone-100 text-stone-600 hover:bg-stone-200 border border-stone-200'
                        }`}
                      >
                        {cat}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Reorganized Documents Table */}
                <div className="bg-white rounded-2xl border border-stone-200/90 shadow-2xs overflow-hidden max-w-4xl">
                  <div className="overflow-x-auto">
                    <table className="w-full text-left border-collapse">
                      <thead>
                        <tr className="bg-stone-100/90 border-b border-stone-200 text-[11px] font-bold text-stone-600 uppercase tracking-wider">
                          <th className="py-3.5 px-4">File Name & Details</th>
                          <th className="py-3.5 px-4">Submission Date</th>
                          <th className="py-3.5 px-4 text-center">Actions</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-stone-100 text-xs text-stone-700 font-medium">
                        {filteredDocList.map((doc) => (
                          <tr key={doc.id} className="hover:bg-indigo-50/40 transition-colors group">
                            {/* File Name & Details */}
                            <td className="py-3.5 px-4">
                              <div className="flex items-center gap-3">
                                <div className="w-9 h-9 rounded-xl bg-indigo-50 text-indigo-700 border border-indigo-200 flex items-center justify-center shrink-0 shadow-2xs group-hover:bg-indigo-600 group-hover:text-white transition-colors">
                                  <FileText className="w-4.5 h-4.5" />
                                </div>
                                <div className="min-w-0">
                                  <div className="font-bold text-stone-900 flex items-center gap-2 flex-wrap">
                                    <span 
                                      onClick={() => setViewingDoc(doc)}
                                      className="hover:text-indigo-600 transition-colors cursor-pointer"
                                    >
                                      {doc.fileName}
                                    </span>
                                    {doc.status === 'Interactive HTML' && (
                                      <span className="px-1.5 py-0.5 rounded bg-indigo-100 text-indigo-800 text-[9px] font-bold border border-indigo-200">
                                        HTML Form
                                      </span>
                                    )}
                                  </div>
                                  <div className="text-[11px] text-stone-500 font-normal mt-0.5 truncate max-w-md">
                                    {doc.title} {doc.fileSize ? `· ${doc.fileSize}` : ''}
                                  </div>
                                </div>
                              </div>
                            </td>

                            {/* Submission Date */}
                            <td className="py-3.5 px-4 whitespace-nowrap font-semibold text-stone-600">
                              <div className="flex items-center gap-1.5">
                                <Calendar className="w-3.5 h-3.5 text-stone-400" />
                                <span>{doc.submissionDate}</span>
                              </div>
                            </td>

                            {/* Actions: View, Download, Delete (Icons Only) */}
                            <td className="py-3.5 px-4 text-center whitespace-nowrap">
                              <div className="flex items-center justify-center gap-1.5">
                                {/* View Button */}
                                <button
                                  onClick={() => setViewingDoc(doc)}
                                  title="View Document"
                                  className="p-2 rounded-xl bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200 transition-colors cursor-pointer shadow-2xs"
                                >
                                  <Eye className="w-4 h-4 text-indigo-600" />
                                </button>

                                {/* View Original Document Button — opens the source file facsimile, separate from the summary popup above */}
                                <button
                                  onClick={() => setViewingOriginalDoc(doc)}
                                  title="View Original Document"
                                  className="p-2 rounded-xl bg-amber-50 hover:bg-amber-100 text-amber-700 border border-amber-200 transition-colors cursor-pointer shadow-2xs"
                                >
                                  <ExternalLink className="w-4 h-4 text-amber-600" />
                                </button>

                                {/* Download Button */}
                                <button
                                  onClick={() => handleDownloadDoc(doc)}
                                  title="Download File"
                                  className="p-2 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-200 transition-colors cursor-pointer shadow-2xs"
                                >
                                  <Download className="w-4 h-4 text-emerald-600" />
                                </button>

                                {/* Delete Button */}
                                <button
                                  onClick={() => handleDeleteDoc(doc.id)}
                                  title="Delete Document"
                                  className="p-2 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 transition-colors cursor-pointer shadow-2xs"
                                >
                                  <Trash2 className="w-4 h-4 text-rose-600" />
                                </button>
                              </div>
                            </td>
                          </tr>
                        ))}

                        {filteredDocList.length === 0 && (
                          <tr>
                            <td colSpan={3} className="py-8 text-center text-stone-500 font-medium">
                              No documents match your search query or selected category filter.
                            </td>
                          </tr>
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* Documents Clearance Summary Card */}
                <div className="p-4 bg-stone-50/50 rounded-xl border border-stone-200/80 space-y-4">
                  <div className="flex items-center justify-between border-b border-stone-100 pb-3">
                    <h4 className="font-bold text-sm text-stone-900">Pre-Operative Clearance Documents Status</h4>
                    <button
                      onClick={() => alert(`Viewing full clearance checklist for ${selectedPatient.name}`)}
                      className="text-xs font-bold text-emerald-700 hover:text-emerald-800 flex items-center gap-1 cursor-pointer"
                    >
                      <span>View full checklist</span>
                      <span>→</span>
                    </button>
                  </div>

                  {/* Clearance Pills */}
                  <div className="flex flex-wrap gap-2">
                    <span className="px-3 py-1.5 bg-emerald-50 text-emerald-800 text-xs font-bold rounded-xl border border-emerald-200 flex items-center gap-1.5 shadow-2xs">
                      <span className="text-emerald-600 font-bold">✓</span> History & Physical (≤ 30 days)
                    </span>
                    <span className="px-3 py-1.5 bg-emerald-50 text-emerald-800 text-xs font-bold rounded-xl border border-emerald-200 flex items-center gap-1.5 shadow-2xs">
                      <span className="text-emerald-600 font-bold">✓</span> CBC
                    </span>
                    <span className="px-3 py-1.5 bg-emerald-50 text-emerald-800 text-xs font-bold rounded-xl border border-emerald-200 flex items-center gap-1.5 shadow-2xs">
                      <span className="text-emerald-600 font-bold">✓</span> BMP
                    </span>
                    <span className="px-3 py-1.5 bg-emerald-50 text-emerald-800 text-xs font-bold rounded-xl border border-emerald-200 flex items-center gap-1.5 shadow-2xs">
                      <span className="text-emerald-600 font-bold">✓</span> ECG (age &gt; 50 or cardiac history)
                    </span>
                    <span className="px-3 py-1.5 bg-emerald-50 text-emerald-800 text-xs font-bold rounded-xl border border-emerald-200 flex items-center gap-1.5 shadow-2xs">
                      <span className="text-emerald-600 font-bold">✓</span> Anesthesia pre-operative review
                    </span>
                    <span className="px-3 py-1.5 bg-emerald-50 text-emerald-800 text-xs font-bold rounded-xl border border-emerald-200 flex items-center gap-1.5 shadow-2xs">
                      <span className="text-emerald-600 font-bold">✓</span> Signed informed consent
                    </span>
                  </div>

                  {/* AI Callout Box */}
                  <div className="p-3.5 bg-purple-50/70 border border-purple-200/80 rounded-xl text-xs text-purple-950 flex items-start gap-2.5">
                    <span className="text-purple-600 font-bold text-sm leading-none pt-0.5">✦</span>
                    <p className="leading-relaxed">
                      <strong className="font-bold text-purple-900">AI keeps this current:</strong> every checklist item updates automatically as new documents arrive, so this reflects the real-time clearance state — not what was true at last chart review.
                    </p>
                  </div>
                </div>
              </div>
            )}
          </div>
          )}

          <DayOfSurgeryJourney
            patient={selectedPatient}
            htmlForms={localPracticeForms}
            pdfForms={localPdfTemplates}
            onOpenPreArrival={() => onOpenVitylsNext?.(selectedPatient, 'intake')}
            onOpenCheckIn={() => onOpenVitylsNext?.(selectedPatient, 'nursing')}
            onOpenNursing={() => onOpenVitylsNext?.(selectedPatient, 'nursing')}
            onOpenAnesthesia={() => onOpenVitylsNext?.(selectedPatient, 'anesthesia')}
            onOpenSurgeon={() => onOpenVitylsNext?.(selectedPatient, 'surgeon')}
            onOpenOrTeam={() => onOpenVitylsNext?.(selectedPatient, 'or')}
            onOpenPacu={() => onOpenVitylsNext?.(selectedPatient, 'pacu')}
            onOpenFinal={() => onOpenVitylsNext?.(selectedPatient, 'final')}
            workflowCounts={Object.fromEntries(FORM_WORKFLOWS.map(w => [w.key, workflowHtmlByKey[w.key].length + workflowPdfByKey[w.key].length]))}
            onOpenIntake={() => handleExecuteAiCommand('Intake Forms', 'intakeForms')}
            onOpenClearanceFiles={() => handleExecuteAiCommand('Pre-op Clearance Files', 'clearanceFiles')}
            onOpenReview={() => handleExecuteAiCommand('Review & Alerts', 'clearanceReview')}
            showDayOfSurgery={!!expandedSections.dayOfSurgery}
            onOpenDayOfSurgery={() => handleExecuteAiCommand('Day of Surgery', 'dayOfSurgery')}
            onHideDayOfSurgery={() => hideSection('dayOfSurgery')}
          />
          {selectedPatient.id !== 'local-empty-patient' && <>
            {expandedSections.clearanceFiles && <ClearanceFiles patient={selectedPatient} onHide={() => hideSection('clearanceFiles')} />}
            {expandedSections.clearanceReview && <ClearanceReview patient={selectedPatient} onHide={() => hideSection('clearanceReview')} />}
          </>}

          {/* Section 3: Intake Forms */}
          {selectedCommandKey === 'intakeForms' && (
          <div id="intakeForms-section" className="bg-white rounded-2xl border border-stone-200/90 shadow-2xs overflow-hidden transition-all">
            <button
              onClick={() => toggleSection('intakeForms')}
              className="w-full p-4 flex items-center justify-between gap-4 text-left hover:bg-stone-50/80 transition-colors cursor-pointer"
            >
              <div className="flex items-center gap-3 min-w-0">
                <div className="w-8 h-8 rounded-xl bg-indigo-600 text-white flex items-center justify-center shadow-xs shrink-0">
                  <FileCheck className="w-4 h-4 text-white" />
                </div>
                <div className="min-w-0">
                  <div className="flex items-center gap-2">
                    <h3 className="text-sm font-bold text-stone-900 truncate">At-Home Intake</h3>
                    <span className="px-2.5 py-0.5 rounded-full bg-indigo-50 text-indigo-800 border border-indigo-200 text-[10px] font-bold">
                      Open / Resume
                    </span>
                  </div>
                  <div className="flex items-center gap-1.5 text-xs text-stone-600 font-medium mt-0.5 truncate">
                    <Sparkles className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
                    <span><strong>Patient Intake:</strong> Open or resume the patient's unified At-Home Intake. Staff can assist the patient with incomplete information, acknowledgments, documents and signatures without returning to legacy forms.</span>
                  </div>
                </div>
              </div>

              <div className="p-1.5 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-700 transition-colors shrink-0">
                <ChevronDown className={`w-5 h-5 text-stone-600 transition-transform duration-200 ${expandedSections.intakeForms ? 'rotate-180' : ''}`} />
              </div>
            </button>

            {expandedSections.intakeForms && (
              <div className="p-5 border-t border-stone-200/80 bg-white space-y-4 animate-in fade-in duration-200">
                {/* Header Actions & Upload Button */}
                <div className="flex flex-wrap items-center justify-between gap-3 border-b border-stone-200/80 pb-3">
                  <div>
                    <h4 className="font-bold text-sm text-stone-900">Pre-Operative Patient Intake Forms</h4>
                    <p className="text-xs text-stone-500 font-medium mt-0.5">
                      Select forms assigned to the Patient Portal workflow below—HTML or PDF—and send portal access by Email/SMS for <strong className="text-stone-800">{selectedPatient.name}</strong>.
                    </p>
                  </div>

                  <div className="flex flex-wrap items-center gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        const first = intakeFormsList.find((f) => selectedIntakeFormIds.includes(f.id)) || intakeFormsList[0];
                        if (first) { const ids = selectedIntakeFormIds.length ? selectedIntakeFormIds : intakeFormsList.map(f=>f.id); if (!selectedIntakeFormIds.length) setSelectedIntakeFormIds(ids); setPortalTestIndex(Math.max(0, ids.indexOf(first.id))); setPortalHtmlForm(first); }
                      }}
                      disabled={intakeFormsList.length === 0}
                      className="px-3.5 py-1.5 bg-white hover:bg-stone-50 disabled:bg-stone-100 disabled:text-stone-400 text-indigo-700 font-bold text-xs rounded-xl border border-indigo-200 shadow-2xs transition-colors cursor-pointer flex items-center gap-1.5"
                    >
                      <Eye className="w-4 h-4" />
                      <span>Test as Patient</span>
                    </button>
                    <button
                      onClick={() => {
                        if (selectedIntakeFormIds.length === 0 && intakeFormsList.length > 0) {
                          setSelectedIntakeFormIds(intakeFormsList.map((f) => f.id));
                        }
                        const firstPending = intakeFormsList.find((f) => selectedIntakeFormIds.includes(f.id)) || intakeFormsList[0];
                        if (firstPending || selectedIntakePdfIds.length > 0) {
                          setSendFormModalItem(firstPending || null);
                          setSendRecipient(selectedPatient.email || '');
                          setIsSendFormsModalOpen(true);
                        }
                      }}
                      className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-2xs transition-colors cursor-pointer flex items-center gap-1.5"
                    >
                      <Send className="w-4 h-4" />
                      <span>Send Selected ({selectedIntakeFormIds.length + selectedIntakePdfIds.length}) via Email/SMS</span>
                    </button>
                  </div>
                </div>

                {/* Toast Notification */}
                {preOpEmailSuccessToast && (
                  <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-xs font-bold text-emerald-900 flex items-center justify-between shadow-2xs">
                    <div className="flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                      <span>{preOpEmailSuccessToast}</span>
                    </div>
                    <button onClick={() => setPreOpEmailSuccessToast(null)} className="text-emerald-700 hover:text-emerald-900 font-bold cursor-pointer">
                      Dismiss
                    </button>
                  </div>
                )}

                {/* Unified HTML + PDF Intake Form Table */}
                <div className="overflow-x-auto border border-stone-200 rounded-2xl shadow-2xs max-w-5xl">
                  <table className="w-full text-left border-collapse">
                    <thead>
                      <tr className="bg-stone-100/80 border-b border-stone-200 text-[11px] font-bold text-stone-600 uppercase tracking-wider">
                        <th className="p-3.5 pl-4 w-10 text-center">
                          <input
                            type="checkbox"
                            checked={(intakeFormsList.length + intakePdfTemplates.length) > 0 &&
                              selectedIntakeFormIds.length === intakeFormsList.length &&
                              selectedIntakePdfIds.length === intakePdfTemplates.length}
                            onChange={(e) => {
                              if (e.target.checked) {
                                setSelectedIntakeFormIds(intakeFormsList.map((f) => f.id));
                                setSelectedIntakePdfIds(intakePdfTemplates.map((pdf) => pdf.id));
                              } else {
                                setSelectedIntakeFormIds([]);
                                setSelectedIntakePdfIds([]);
                              }
                            }}
                            className="w-4 h-4 rounded border-stone-300 text-indigo-600 focus:ring-indigo-500 cursor-pointer"
                            title="Select / Deselect All Forms"
                          />
                        </th>
                        <th className="p-3.5">Form Name</th>
                                                <th className="p-3.5">Station</th>
                        <th className="p-3.5">Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-stone-200/80 text-xs">
                      {intakeFormsList.map((form, idx) => (
                        <tr key={`html-${form.id}`} className="hover:bg-stone-50/80 transition-colors">
                          <td className="p-3.5 pl-4 w-10 text-center">
                            <input
                              type="checkbox"
                              checked={selectedIntakeFormIds.includes(form.id)}
                              onChange={(e) => setSelectedIntakeFormIds((prev) =>
                                e.target.checked ? [...prev, form.id] : prev.filter((id) => id !== form.id)
                              )}
                              className="w-4 h-4 rounded border-stone-300 text-indigo-600 focus:ring-indigo-500 cursor-pointer"
                            />
                          </td>
                          <td className="p-3.5 min-w-[220px]">
                            <div className="font-bold text-stone-900">{form.title}</div>
                            
                          </td>
                                                    <td className="p-3.5 text-stone-600">{form.targetAudience || 'Home / Front Desk'}</td>
                          <td className="p-3.5">
                            <span className={`px-2.5 py-1 rounded-full text-[10.5px] font-bold border inline-flex items-center gap-1.5 ${
                              form.status === 'Completed in Portal'
                                ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                                : form.status === 'Sent via Email'
                                ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                                : form.status === 'Sent via SMS'
                                ? 'bg-teal-50 text-teal-800 border-teal-200'
                                : 'bg-amber-50 text-amber-800 border-amber-200'
                            }`}>
                              {form.status === 'Completed in Portal' && <CheckCircle2 className="w-3 h-3"/>}
                              {form.status === 'Sent via Email' && <Mail className="w-3 h-3"/>}
                              {form.status === 'Sent via SMS' && <Smartphone className="w-3 h-3"/>}
                              {form.status === 'Pending Send' && <Clock className="w-3 h-3"/>}
                              {form.status}
                            </span>
                          </td>
                        </tr>
                      ))}

                      {intakePdfTemplates.map((pdf) => (
                        <tr key={`pdf-${pdf.id}`} className="hover:bg-violet-50/30 transition-colors">
                          <td className="p-3.5 pl-4 w-10 text-center">
                            <input
                              type="checkbox"
                              checked={selectedIntakePdfIds.includes(pdf.id)}
                              onChange={(e) => setSelectedIntakePdfIds((prev) =>
                                e.target.checked ? [...prev, pdf.id] : prev.filter((id) => id !== pdf.id)
                              )}
                              className="w-4 h-4 accent-violet-600"
                            />
                          </td>
                          <td className="p-3.5 min-w-[220px]">
                            <div className="font-bold text-stone-900">{pdf.title}</div>
                            
                          </td>
                                                    <td className="p-3.5 text-stone-600">{pdf.collectionStage}</td>
                          <td className="p-3.5"><span className="px-2.5 py-1 rounded-full bg-violet-50 text-violet-800 border border-violet-200 text-[10.5px] font-bold">Interactive</span></td>
                        </tr>
                      ))}

                      {intakeFormsList.length === 0 && intakePdfTemplates.length === 0 && (
                        <tr><td colSpan={4} className="p-8 text-center text-stone-500 font-medium">No forms are currently assigned to the Patient Portal workflow in Form Studio.</td></tr>
                      )}
                    </tbody>
                  </table>
                </div>

                <div className="p-3.5 bg-teal-50/80 border border-teal-200 rounded-xl text-xs text-teal-950 flex items-center justify-between shadow-2xs">
                  <div className="flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-teal-700 shrink-0" />
                    <span>
                      <strong>EHR Documents Integration:</strong> When patients complete any intake form via portal link, it automatically becomes part of the patient's master <strong>Forms &amp; Documents</strong> folder.
                    </span>
                  </div>
                </div>
              </div>
            )}
          </div>
          )}

          {/* Section 4: Doctor Notes */}
          {(expandedSections.clinicalNotes || expandedSections.all) && (
          <div id="clinicalNotes-section" className="bg-white rounded-2xl border border-stone-200/90 shadow-2xs overflow-hidden transition-all">
            <button
              onClick={() => toggleSection('clinicalNotes')}
              className="w-full p-4 flex items-center justify-between gap-4 text-left hover:bg-stone-50/80 transition-colors cursor-pointer"
            >
              <div className="flex items-center gap-3 min-w-0">
                <div className="w-8 h-8 rounded-xl bg-purple-600 text-white flex items-center justify-center shadow-xs shrink-0">
                  <FileText className="w-4 h-4 text-white" />
                </div>
                <div className="min-w-0">
                  <div className="flex items-center gap-2">
                    <h3 className="text-sm font-bold text-stone-900 truncate">Doctor Notes</h3>
                    <span className="px-2.5 py-0.5 rounded-full bg-purple-50 text-purple-800 border border-purple-200 text-[10px] font-bold">
                      {notesFormsList.length} Doctor Notes Forms
                    </span>
                  </div>
                  <div className="flex items-center gap-1.5 text-xs text-stone-600 font-medium mt-0.5 truncate">
                    <Sparkles className="w-3.5 h-3.5 text-purple-600 shrink-0" />
                    <span><strong>Interactive Physician Notes:</strong> 1. History & Physical, 2. SOAP Note, 3. Daily Doctor's Note HTML forms attached and ready.</span>
                  </div>
                </div>
              </div>

              <div className="p-1.5 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-700 transition-colors shrink-0">
                <ChevronDown className={`w-5 h-5 text-stone-600 transition-transform duration-200 ${expandedSections.clinicalNotes ? 'rotate-180' : ''}`} />
              </div>
            </button>

            {expandedSections.clinicalNotes && (
              <div className="p-5 border-t border-stone-200/80 bg-white space-y-4 animate-in fade-in duration-200">
                <div className="flex flex-wrap items-center justify-between border-b border-stone-200/80 pb-3 gap-2">
                  <div className="flex items-center gap-2">
                    <FileText className="w-4 h-4 text-indigo-600" />
                    <h4 className="font-bold text-sm text-stone-900">Doctor Notes</h4>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    {/* Dictate Notes Button */}
                    <button
                      onClick={() => { setIsNoteWorkspaceOpen(true); handleExecuteAiCommand('Open doctor note dictation workspace', 'clinicalNotes'); }}
                      className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-2xs transition-colors flex items-center gap-1.5 cursor-pointer border border-emerald-500"
                    >
                      <Mic className="w-3.5 h-3.5 text-indigo-300" />
                      <span>Dictate Notes</span>
                      <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                    </button>

                    <button
                      onClick={() => setIsNoteWorkspaceOpen(!isNoteWorkspaceOpen)}
                      className="px-3 py-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 text-xs font-bold rounded-xl transition-colors cursor-pointer flex items-center gap-1"
                    >
                      <span>{isNoteWorkspaceOpen ? 'Close workspace' : 'Open draft workspace'}</span>
                    </button>
                  </div>
                </div>

                {/* Table of the 3 Attached HTML Forms in Positions 1, 2, and 3 */}
                <div className="overflow-x-auto border border-stone-200/90 rounded-2xl shadow-2xs bg-white">
                  <table className="w-full text-left border-collapse">
                    <thead>
                      <tr className="bg-stone-100/90 border-b border-stone-200 text-[11px] font-bold text-stone-600 uppercase tracking-wider">
                        <th className="py-3.5 px-4">Position & Form Title</th>
                        <th className="py-3.5 px-4">Author / Provider</th>
                        <th className="py-3.5 px-4">Status</th>
                        <th className="py-3.5 px-4 text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-stone-100 text-xs font-medium text-stone-800">
                      {notesFormsList.map((note) => (
                        <tr key={note.id} className="hover:bg-purple-50/40 transition-colors group">
                          <td className="py-3.5 px-4 min-w-[240px]">
                            <div className="flex items-start gap-3">
                              <span className="w-6 h-6 rounded-lg bg-indigo-600 text-white font-bold text-xs flex items-center justify-center shrink-0 mt-0.5 shadow-2xs">
                                {note.order}
                              </span>
                              <div>
                                <div className="font-bold text-stone-900 text-xs flex items-center gap-2">
                                  <span 
                                    onClick={() => setViewingNoteForm(note)}
                                    className="hover:text-indigo-600 cursor-pointer transition-colors"
                                  >
                                    {note.title}
                                  </span>
                                  <span className="px-1.5 py-0.5 rounded bg-purple-100 text-purple-800 text-[9px] font-bold border border-purple-200">
                                    HTML Form
                                  </span>
                                </div>
                                <div className="text-[11px] text-stone-500 font-normal mt-0.5 max-w-md">
                                  {note.subtitle}
                                </div>
                              </div>
                            </div>
                          </td>

                          <td className="py-3.5 px-4 whitespace-nowrap text-stone-700">
                            <div className="font-bold text-stone-900">{note.author}</div>
                            <div className="text-[10.5px] text-stone-400 font-mono">{note.date}</div>
                          </td>

                          <td className="py-3.5 px-4 whitespace-nowrap">
                            <span className="px-2.5 py-1 rounded-full text-[10.5px] font-bold bg-emerald-50 text-emerald-800 border border-emerald-200 flex items-center gap-1.5 w-fit">
                              <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                              <span>{note.status}</span>
                            </span>
                          </td>

                          <td className="py-3.5 px-4 text-right whitespace-nowrap">
                            <div className="flex items-center justify-end gap-2">
                              {/* Open Button */}
                              <button
                                onClick={() => setViewingNoteForm(note)}
                                className="px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-xl shadow-2xs transition-colors cursor-pointer flex items-center gap-1.5"
                              >
                                <ExternalLink className="w-3.5 h-3.5 text-indigo-200" />
                                <span>Open</span>
                              </button>
                              {/* Delete Button */}
                              <button
                                onClick={() => handleDeleteDoctorNote(note.id)}
                                title="Delete Doctor Note"
                                className="px-2.5 py-1.5 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 font-bold text-xs rounded-xl shadow-2xs transition-colors cursor-pointer flex items-center gap-1"
                              >
                                <Trash2 className="w-3.5 h-3.5 text-rose-600" />
                                <span>Delete</span>
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                {/* Interactive Draft Note Workspace */}
                {isNoteWorkspaceOpen && (
                  <div className="p-5 bg-stone-50/80 border border-stone-200 rounded-2xl space-y-4 animate-in fade-in duration-200 mt-3">
                    <div className="text-[10px] font-bold text-stone-400 uppercase tracking-wider">
                      STRUCTURED DATA PULLED FROM CHART · {selectedPatient.name.toUpperCase()}
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                      <div className="p-3 bg-white/80 border border-stone-200/80 rounded-xl">
                        <span className="text-[9.5px] font-bold text-stone-400 block uppercase tracking-wider">PATIENT</span>
                        <span className="font-bold text-stone-900">{selectedPatient.name} · MRN-{selectedPatient.patientId || '88213'}</span>
                      </div>
                      <div className="p-3 bg-white/80 border border-stone-200/80 rounded-xl">
                        <span className="text-[9.5px] font-bold text-stone-400 block uppercase tracking-wider">PROCEDURE</span>
                        <span className="font-bold text-stone-900">{selectedPatient.procedure || 'Laparoscopic Cholecystectomy'}</span>
                      </div>
                      <div className="p-3 bg-white/80 border border-stone-200/80 rounded-xl">
                        <span className="text-[9.5px] font-bold text-stone-400 block uppercase tracking-wider">ASA CLASS</span>
                        <span className="font-bold text-stone-900">II</span>
                      </div>
                      <div className="p-3 bg-white/80 border border-stone-200/80 rounded-xl">
                        <span className="text-[9.5px] font-bold text-stone-400 block uppercase tracking-wider">ALLERGIES</span>
                        <AllergyStatus compact allergies={selectedPatient.allergies} patientId={selectedPatient.id} />
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => {
                          setDraftNoteContent(`ADMISSION H&P NOTE - ${selectedPatient.name.toUpperCase()}\nProcedure: ${selectedPatient.procedure}\nASA Class: II | Allergies: ${selectedPatient.allergies && selectedPatient.allergies.length > 0 ? selectedPatient.allergies.join(', ') : 'NKDA'}\n\nClinical Summary:\nPatient presents cleared for surgery. Pre-op vitals stable.`);
                        }}
                        className="px-4 py-2 bg-teal-800 hover:bg-teal-900 text-white font-bold text-xs rounded-xl shadow-xs transition-colors cursor-pointer flex items-center gap-2"
                      >
                        <Sparkles className="w-3.5 h-3.5 text-emerald-300" />
                        <span>Generate draft note</span>
                      </button>

                      {draftNoteContent && (
                        <button
                          onClick={handleClearDraftNote}
                          className="px-3.5 py-2 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 font-bold text-xs rounded-xl transition-colors cursor-pointer flex items-center gap-1.5 shadow-2xs"
                        >
                          <Trash2 className="w-3.5 h-3.5 text-rose-600" />
                          <span>Delete Draft Note</span>
                        </button>
                      )}
                    </div>

                    <textarea
                      value={draftNoteContent}
                      onChange={(e) => setDraftNoteContent(e.target.value)}
                      placeholder="Click &quot;Generate draft note&quot; to have the assistant draft this note from the structured chart data."
                      className="w-full h-32 p-3.5 bg-white border border-stone-300 rounded-xl text-xs text-stone-800 focus:outline-none font-sans"
                    />
                  </div>
                )}
              </div>
            )}
          </div>
          )}

          {/* Section 5: Nursing Notes */}
          {false && (
          <div id="nursingNotes-section" className="bg-white rounded-2xl border border-stone-200/90 shadow-2xs overflow-hidden transition-all">
            <button
              onClick={() => toggleSection('nursingNotes')}
              className="w-full p-4 flex items-center justify-between gap-4 text-left hover:bg-stone-50/80 transition-colors cursor-pointer"
            >
              <div className="flex items-center gap-3 min-w-0">
                <div className="w-8 h-8 rounded-xl bg-emerald-600 text-white flex items-center justify-center shadow-xs shrink-0">
                  <FileCheck className="w-4 h-4 text-white" />
                </div>
                <div className="min-w-0">
                  <div className="flex items-center gap-2">
                    <h3 className="text-sm font-bold text-stone-900 truncate">Nursing Notes</h3>
                    <span className="px-2.5 py-0.5 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-200 text-[10px] font-bold">
                      {nursingFormsList.length} Attached HTML Forms
                    </span>
                  </div>
                  <div className="flex items-center gap-1.5 text-xs text-stone-600 font-medium mt-0.5 truncate">
                    <Sparkles className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                    <span><strong>AI Verified Perioperative Forms:</strong> All 7 nursing HTML forms organized & saved per surgical episode.</span>
                  </div>
                </div>
              </div>

              <div className="p-1.5 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-700 transition-colors shrink-0">
                <ChevronDown className={`w-5 h-5 text-stone-600 transition-transform duration-200 ${expandedSections.nursingNotes ? 'rotate-180' : ''}`} />
              </div>
            </button>

            {expandedSections.nursingNotes && (
              <div className="p-5 border-t border-stone-200/80 bg-white space-y-4 animate-in fade-in duration-200">
                
                {/* Save Confirmation Toast Banner */}
                {saveEpisodeSuccessToast && (
                  <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-xs text-emerald-900 font-medium flex items-center justify-between gap-2 animate-in fade-in slide-in-from-top-1">
                    <div className="flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                      <span>{saveEpisodeSuccessToast}</span>
                    </div>
                    <button 
                      onClick={() => setSaveEpisodeSuccessToast(null)}
                      className="text-emerald-700 hover:text-emerald-950 font-bold text-xs"
                    >
                      Dismiss
                    </button>
                  </div>
                )}

                {/* Surgical Episode Selector & Actions Bar */}
                <div className="p-3.5 bg-stone-50 border border-stone-200/90 rounded-2xl flex flex-wrap items-center justify-between gap-3">
                  <div className="flex items-center gap-2.5 min-w-[280px] flex-1">
                    <FolderCheck className="w-4 h-4 text-emerald-700 shrink-0" />
                    <div className="space-y-0.5 flex-1">
                      <label className="text-[10px] font-bold text-stone-500 uppercase tracking-wider block">
                        Select Surgical Episode
                      </label>
                      <select
                        value={selectedSurgicalEpisode}
                        onChange={(e) => setSelectedSurgicalEpisode(e.target.value)}
                        className="w-full bg-white border border-stone-300 rounded-lg px-2.5 py-1.5 text-xs font-bold text-stone-900 focus:outline-none focus:ring-2 focus:ring-emerald-500 cursor-pointer"
                      >
                        {SURGICAL_EPISODES.map((ep) => (
                          <option key={ep.id} value={ep.id}>
                            {ep.name}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        const activeEpName = SURGICAL_EPISODES.find(ep => ep.id === selectedSurgicalEpisode)?.name || 'Current Episode';
                        setSaveEpisodeSuccessToast(`Saved collection of ${nursingFormsList.length} Nursing Notes forms to ${activeEpName}`);
                        setTimeout(() => setSaveEpisodeSuccessToast(null), 5000);
                      }}
                      className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs rounded-xl shadow-2xs transition-colors cursor-pointer flex items-center gap-1.5"
                    >
                      <Save className="w-3.5 h-3.5 text-emerald-200" />
                      <span>Save Collection to Episode</span>
                    </button>
                  </div>
                </div>

                {/* Table of Attached Nursing HTML Forms */}
                <div className="border border-stone-200/90 rounded-2xl shadow-2xs bg-white overflow-hidden">
                  <table className="w-full text-left border-collapse text-xs">
                    <thead>
                      <tr className="bg-stone-100/90 border-b border-stone-200 text-[10.5px] font-bold text-stone-600 uppercase tracking-wider">
                        <th className="py-2.5 px-3">Position & Form Title</th>
                        <th className="py-2.5 px-3">Form Status</th>
                        <th className="py-2.5 px-3 text-right">Action</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-stone-100 font-medium text-stone-800">
                      {nursingFormsList.map((form) => (
                        <tr key={form.id} className="hover:bg-emerald-50/40 transition-colors group">
                          {/* Position & Title */}
                          <td className="py-2.5 px-3">
                            <div className="flex items-start gap-2.5">
                              <span className="w-5 h-5 rounded-md bg-emerald-700 text-white font-bold text-[11px] flex items-center justify-center shrink-0 mt-0.5 shadow-2xs">
                                {form.order}
                              </span>
                              <div className="min-w-0">
                                <div className="font-bold text-stone-900 text-xs flex items-center gap-1.5 flex-wrap">
                                  <span 
                                    onClick={() => setEditingNursingForm(form)}
                                    className="hover:text-emerald-700 cursor-pointer transition-colors"
                                  >
                                    {form.title}
                                  </span>
                                  <span className="px-1.5 py-0.2 rounded bg-emerald-100 text-emerald-800 text-[9px] font-bold border border-emerald-200">
                                    HTML Form
                                  </span>
                                </div>
                                <div className="text-[10.5px] text-stone-500 font-normal mt-0.5 line-clamp-1">
                                  {form.summary}
                                </div>
                              </div>
                            </div>
                          </td>

                          {/* Form Status */}
                          <td className="py-2.5 px-3 whitespace-nowrap">
                            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-900 border border-emerald-300 flex items-center gap-1 w-fit">
                              <CheckCircle2 className="w-3 h-3 text-emerald-700" />
                              <span>{form.status}</span>
                            </span>
                          </td>

                          {/* Actions */}
                          <td className="py-2.5 px-3 text-right whitespace-nowrap">
                            <div className="flex items-center justify-end gap-1.5">
                              <button
                                type="button"
                                onClick={() => setEditingNursingForm(form)}
                                className="px-3 py-1 bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs rounded-lg shadow-2xs transition-colors cursor-pointer inline-flex items-center gap-1"
                                id="open-nursing-form-btn"
                              >
                                <FileText className="w-3.5 h-3.5 text-emerald-200" />
                                <span>Open</span>
                              </button>
                              <button
                                type="button"
                                onClick={() => handleDeleteNursingNote(form.id)}
                                title="Delete Nursing Note"
                                className="px-2 py-1 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 font-bold text-xs rounded-lg shadow-2xs transition-colors cursor-pointer inline-flex items-center gap-1"
                              >
                                <Trash2 className="w-3.5 h-3.5 text-rose-600" />
                                <span>Delete</span>
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                {/* AI Callout Box */}
                <div className="p-3.5 bg-purple-50/70 border border-purple-200/80 rounded-xl text-xs text-purple-950 flex items-start gap-2.5">
                  <Sparkles className="w-4 h-4 text-purple-600 shrink-0 mt-0.5" />
                  <p className="leading-relaxed">
                    <strong className="font-bold text-purple-900">AI Perioperative Assistant:</strong> All 7 nursing HTML forms are linked and tracked for Episode #2026-0506. AI checks pre-op NPO status, AORN 4-stage safety timeout indicators, PACU Aldrete recovery scores, and discharge criteria before archiving into the surgical episode record.
                  </p>
                </div>

              </div>
            )}
          </div>
          )}

          {/* Section 6: Reconciled Medications */}
          {(expandedSections.medications || expandedSections.all) && (
            <div id="medications-section" className="bg-white rounded-2xl border border-stone-200/90 shadow-2xs p-5 space-y-4 animate-in fade-in duration-200">
              <div className="flex flex-wrap items-center justify-between border-b border-stone-200/80 pb-3 gap-2">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-xl bg-rose-600 text-white flex items-center justify-center shadow-xs shrink-0">
                    <Stethoscope className="w-4.5 h-4.5 text-white" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-stone-900">Reconciled Medications & E-Prescribe Portal</h3>
                    <p className="text-xs text-stone-500 font-medium">Active pre-op and post-op medication orders for {selectedPatient.name}</p>
                  </div>
                </div>
                <button
                  onClick={() => setIsEPrescribeOpen(true)}
                  className="px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-xl shadow-2xs transition-colors flex items-center gap-1.5 cursor-pointer shrink-0"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Open E-Prescribe Portal</span>
                </button>
              </div>

              <AllergyStatus allergies={selectedPatient.allergies} patientId={selectedPatient.id} label="Documented drug allergies" />

              <div className="overflow-x-auto border border-stone-200/90 rounded-xl shadow-2xs">
                <table className="w-full text-left text-xs">
                  <thead className="bg-stone-100/90 text-stone-700 uppercase font-bold text-[10px] tracking-wider">
                    <tr>
                      <th className="p-3">Medication</th>
                      <th className="p-3">Dosage / Sig</th>
                      <th className="p-3">Category</th>
                      <th className="p-3 text-right">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-stone-100 font-medium text-stone-800">
                    <tr>
                      <td className="p-3 font-bold text-stone-900">Celebrex (Celecoxib)</td>
                      <td className="p-3">200mg PO QD</td>
                      <td className="p-3 text-stone-600">Pre-op Anti-inflammatory</td>
                      <td className="p-3 text-right"><span className="px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-bold border border-emerald-300">Administered</span></td>
                    </tr>
                    <tr>
                      <td className="p-3 font-bold text-stone-900">Emend (Aprepitant)</td>
                      <td className="p-3">40mg PO 1hr Pre-op</td>
                      <td className="p-3 text-stone-600">PONV Prophylaxis</td>
                      <td className="p-3 text-right"><span className="px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-bold border border-emerald-300">Administered</span></td>
                    </tr>
                    <tr>
                      <td className="p-3 font-bold text-stone-900">Ancef (Cefazolin)</td>
                      <td className="p-3">1g IV Piggyback</td>
                      <td className="p-3 text-stone-600">Surgical Prophylaxis</td>
                      <td className="p-3 text-right"><span className="px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-bold border border-emerald-300">Ordered (Pre-Incision)</span></td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* Section 7: Payment & Financial Summary */}
          {(expandedSections.financial || expandedSections.all) && selectedPatient.id !== 'local-empty-patient' && (
            <div id="financial-section" className="scroll-mt-4 space-y-3" data-testid="billing-section">
              {/* v7.2: the Billing command opens the real invoice + payment functions (incl. manager override) */}
              <div className="vy-card px-5 py-3 flex flex-wrap items-center gap-3 justify-between">
                <label className="flex items-center gap-2 text-[14.5px] text-[#39443E]">Acting as (test build)
                  <select className="vy-input !w-auto" value={billingRole} onChange={e => setBillingRole(e.target.value)} data-testid="billing-acting-as">
                    {BILLING_ACTORS.map(a => <option key={a.role} value={a.role}>{a.name} · {a.role}</option>)}
                  </select></label>
                <div className="flex items-center gap-2 text-[14.5px] text-[#39443E]">Account credit ${(patientCredits[selectedPatient.patientId] || 0).toLocaleString()}
                  <Btn variant="secondary" icon={<CreditCard className="w-4 h-4" />} onClick={() => setIsCollectDepositModalOpen(true)}>Collect deposit</Btn>
                  <Btn variant="ghost" onClick={() => setExpandedSections(prev => ({ ...prev, financial: false }))} data-testid="hide-billing">Hide</Btn></div>
              </div>
              <InvoicePanel patient={selectedPatient} actor={(BILLING_ACTORS.find(a => a.role === billingRole) || BILLING_ACTORS[0]).name} role={billingRole} />
            </div>
          )}

          {/* Section 8: Patient ID & Insurance Cards */}
          {(expandedSections.idInsuranceCards || expandedSections.idInsurance || expandedSections.all) && (
            <div id="idInsurance-section" className="bg-white rounded-2xl border border-stone-200/90 shadow-2xs p-5 space-y-4 animate-in fade-in duration-200">
              <div className="flex items-center justify-between border-b border-stone-200/80 pb-3">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-xl bg-sky-600 text-white flex items-center justify-center shadow-xs shrink-0">
                    <CreditCard className="w-4.5 h-4.5 text-white" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-stone-900">Driver's License Photo ID & Primary Insurance Cards</h3>
                    <p className="text-xs text-stone-500 font-medium">Verified identity and insurance document scans</p>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div 
                  onClick={() => setZoomedImage({ url: idCardUrl, title: `${selectedPatient.name} — California Driver License`, subtitle: 'Government Issued Photo ID' })}
                  className="p-3 bg-stone-50 rounded-xl border border-stone-200 cursor-pointer hover:border-indigo-400 transition-all group"
                >
                  <div className="text-xs font-bold text-stone-800 mb-2 flex items-center justify-between">
                    <span>Driver's License</span>
                    <Eye className="w-3.5 h-3.5 text-stone-400 group-hover:text-indigo-600" />
                  </div>
                  <div className="aspect-video bg-stone-200 rounded-lg overflow-hidden flex items-center justify-center">
                    <img src={idCardUrl} alt="Driver License" className="w-full h-full object-cover group-hover:scale-105 transition-transform" />
                  </div>
                </div>

                <div 
                  onClick={() => setZoomedImage({ url: insuranceCardFrontUrl, title: `${selectedPatient.name} — Primary Insurance (Front)`, subtitle: 'Blue Shield PPO Member ID' })}
                  className="p-3 bg-stone-50 rounded-xl border border-stone-200 cursor-pointer hover:border-indigo-400 transition-all group"
                >
                  <div className="text-xs font-bold text-stone-800 mb-2 flex items-center justify-between">
                    <span>Insurance Card (Front)</span>
                    <Eye className="w-3.5 h-3.5 text-stone-400 group-hover:text-indigo-600" />
                  </div>
                  <div className="aspect-video bg-stone-200 rounded-lg overflow-hidden flex items-center justify-center">
                    <img src={insuranceCardFrontUrl} alt="Insurance Front" className="w-full h-full object-cover group-hover:scale-105 transition-transform" />
                  </div>
                </div>

                <div 
                  onClick={() => setZoomedImage({ url: insuranceCardBackUrl, title: `${selectedPatient.name} — Primary Insurance (Back)`, subtitle: 'Claims & Rx Bin Information' })}
                  className="p-3 bg-stone-50 rounded-xl border border-stone-200 cursor-pointer hover:border-indigo-400 transition-all group"
                >
                  <div className="text-xs font-bold text-stone-800 mb-2 flex items-center justify-between">
                    <span>Insurance Card (Back)</span>
                    <Eye className="w-3.5 h-3.5 text-stone-400 group-hover:text-indigo-600" />
                  </div>
                  <div className="aspect-video bg-stone-200 rounded-lg overflow-hidden flex items-center justify-center">
                    <img src={insuranceCardBackUrl} alt="Insurance Back" className="w-full h-full object-cover group-hover:scale-105 transition-transform" />
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Section 9: Surgical Team & Room Details */}
          {(expandedSections.surgicalDetails || expandedSections.all) && (
            <div id="surgicalDetails-section" className="bg-white rounded-2xl border border-stone-200/90 shadow-2xs p-5 space-y-4 animate-in fade-in duration-200">
              <div className="flex items-center justify-between border-b border-stone-200/80 pb-3">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-xl bg-amber-600 text-white flex items-center justify-center shadow-xs shrink-0">
                    <Building2 className="w-4.5 h-4.5 text-white" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-stone-900">Surgical Team & Operating Room Assignment</h3>
                    <p className="text-xs text-stone-500 font-medium">the practice staff & room details for DOS </p>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                <div className="p-3 bg-stone-50 rounded-xl border border-stone-200">
                  <span className="text-[10px] font-bold text-stone-400 block uppercase">Surgeon</span>
                  <span className="font-extrabold text-stone-900">{selectedPatient.surgeon || 'Provider'}</span>
                </div>
                <div className="p-3 bg-stone-50 rounded-xl border border-stone-200">
                  <span className="text-[10px] font-bold text-stone-400 block uppercase">Anesthesiologist</span>
                  <span className="font-extrabold text-stone-900"></span>
                </div>
                <div className="p-3 bg-stone-50 rounded-xl border border-stone-200">
                  <span className="text-[10px] font-bold text-stone-400 block uppercase">Operating Room</span>
                  <span className="font-extrabold text-amber-700">{selectedPatient.room || 'OR 2'}</span>
                </div>
                <div className="p-3 bg-stone-50 rounded-xl border border-stone-200">
                  <span className="text-[10px] font-bold text-stone-400 block uppercase">Circulating Nurse</span>
                  <span className="font-extrabold text-stone-900"></span>
                </div>
              </div>
            </div>
          )}

          {/* Quick Chart Actions panel removed — these repeated per-patient actions
              (portal messages, e-prescribe, dictate note, print) are now presented
              as Nightingale AI suggested commands in the right-hand coordinator,
              per the "reduce clutter and centralize routine actions" design request. */}

          {/* Section: Patient Portal Messages & Two-Way Clinical Communication */}
          {(expandedSections.portalMessages || expandedSections.all || selectedCommandKey === 'portalMessages') && (
            <div id="portalMessages-section" className="scroll-mt-6">
              <PatientChartPortalMessagesSection
                patient={selectedPatient}
                patientId={selectedPatient.patientId}
                patientName={selectedPatient.name}
                patientPhone={selectedPatient.phone}
                patientProcedure={selectedPatient.procedure}
                patientSurgeon={selectedPatient.surgeon}
                onShowToast={showToast}
                onNavigateToPortalTab={onNavigateToPortalTab}
              />
            </div>
          )}

        </div>

        {/* Right Column: 1/3 of page (4 cols) */}
        <div className="lg:col-span-4 space-y-6">
          {/* Nightingale AI Clinical Chart Coordinator & AI Assistant */}
          <NightingaleChartCommandCoordinator
            selectedPatient={selectedPatient}
            cases={cases}
            onSelectPatient={(p) => {
              setSelectedPatient(p);
              showToast(`Loaded clinical chart: ${p.name}`);
            }}
            onOpenPrintModal={(option) => setPrintModalOption(option || 'facesheet')}
            onExecuteDirective={handleExecuteChartDirective}
            onExecuteAiCommand={handleExecuteAiCommand}
            selectedCommandKey={selectedCommandKey}
            patientUnreadCount={patientUnreadCount}
            onOpenEPrescribe={() => setIsEPrescribeOpen(true)}
            onOpenIntakeSendModal={() => setIsPreOpEmailModalOpen(true)}
            onOpenNoteWorkspace={() => {
              setIsNoteWorkspaceOpen(true);
              handleExecuteAiCommand('Open doctor note dictation workspace', 'clinicalNotes');
            }}
            onCollectPayment={() => setIsCollectDepositModalOpen(true)}
            isMinimalMode={false}
          />

          {/* v7 item 6: real Appointment History (current or most recent encounter expanded; dropdown filters records) */}
          <AppointmentHistory key={selectedPatient.id} patient={selectedPatient} cases={cases} onOpenWorkstations={() => onOpenVitylsNext?.(selectedPatient, 'nursing')} />

        </div>

      </div>

      {/* Lightbox Zoom Modal for Patient Cards */}
      {zoomedImage && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-200">
          <div className="bg-white rounded-3xl max-w-2xl w-full p-6 space-y-4 shadow-2xl border border-stone-200 relative">
            <div className="flex items-center justify-between border-b border-stone-200 pb-3">
              <div>
                <h3 className="text-base font-bold text-stone-900 flex items-center gap-2">
                  <CreditCard className="w-5 h-5 text-emerald-600" />
                  <span>{zoomedImage.title}</span>
                </h3>
                {zoomedImage.subtitle && (
                  <p className="text-xs text-stone-500 font-medium mt-0.5">{zoomedImage.subtitle}</p>
                )}
              </div>
              <button 
                onClick={() => setZoomedImage(null)}
                className="p-2 rounded-full hover:bg-stone-100 text-stone-500 hover:text-stone-800 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="bg-stone-100 rounded-2xl p-4 flex items-center justify-center border border-stone-200 overflow-hidden min-h-[280px]">
              <img 
                src={zoomedImage.url} 
                alt="Enlarged Document" 
                className="max-h-[70vh] w-auto max-w-full rounded-xl object-contain shadow-lg"
              />
            </div>

            <div className="flex items-center justify-between pt-2">
              <span className="text-xs text-stone-500 font-medium flex items-center gap-1">
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                <span>Verified High-Resolution Scan · HIPAA Encrypted</span>
              </span>

              <div className="flex items-center gap-2">
                <button 
                  onClick={() => {
                    const a = document.createElement('a');
                    a.href = zoomedImage.url;
                    a.download = `${selectedPatient.name.replace(/\s+/g, '_')}_card.png`;
                    a.click();
                  }}
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl flex items-center gap-2 transition-colors cursor-pointer shadow-2xs"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download Scan</span>
                </button>
                <button 
                  onClick={() => setZoomedImage(null)}
                  className="px-4 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 text-xs font-bold rounded-xl transition-colors cursor-pointer"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* E-Prescribe: safety fix (MED v0.1 / ASC v7.6) — simulated, never transmitted, provider PIN required */}
      {isEPrescribeOpen && <SimulatedRxDialog patientName={selectedPatient.name} dob={selectedPatient.dob} auditKey={selectedPatient.id} defaultPrescriber={selectedPatient.surgeon} onClose={() => setIsEPrescribeOpen(false)} />}

      {/* Interactive Clinical Assessment PDF Forms Pop-up Modal */}
      {isPdfFormsModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6 animate-in fade-in duration-200 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-4xl w-full p-6 space-y-5 shadow-2xl border border-stone-200 relative my-auto max-h-[92vh] flex flex-col overflow-hidden">
            
            {/* Modal Top Nav Bar */}
            <div className="flex flex-wrap items-center justify-between border-b border-stone-200 pb-4 shrink-0 gap-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-indigo-600 text-white flex items-center justify-center shadow-md shadow-indigo-500/20 shrink-0">
                  <FileText className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-stone-900 flex items-center gap-2">
                    <span>the practice — Clinical Assessment Scans</span>
                    <span className="px-2 py-0.5 rounded bg-indigo-50 text-indigo-700 text-[10px] font-bold border border-indigo-200">
                      Converted PDF HTML Forms
                    </span>
                  </h3>
                  <p className="text-xs text-stone-500 font-medium">
                    Patient: <span className="font-bold text-stone-800">{selectedPatient.name}</span> (ID: {selectedPatient.patientId}) · DOS: 05/06/2026 · Provider
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => window.print()}
                  className="px-3.5 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 text-xs font-bold rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>Print Form</span>
                </button>
                <button 
                  onClick={() => setIsPdfFormsModalOpen(false)}
                  className="p-2 rounded-full hover:bg-stone-100 text-stone-500 hover:text-stone-800 transition-colors cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Sub-Tab Form Switcher Buttons */}
            <div className="flex gap-2 border-b border-stone-200 pb-3 shrink-0 bg-stone-50 p-1.5 rounded-2xl">
              <button
                onClick={() => setActivePdfFormTab('standing-orders')}
                className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold transition-all cursor-pointer text-center ${
                  activePdfFormTab === 'standing-orders'
                    ? 'bg-white text-indigo-900 shadow-2xs border border-indigo-200'
                    : 'text-stone-600 hover:text-stone-900 hover:bg-white/60'
                }`}
              >
                1. Doctors Standing Orders
              </button>
              <button
                onClick={() => setActivePdfFormTab('preop-checklist')}
                className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold transition-all cursor-pointer text-center ${
                  activePdfFormTab === 'preop-checklist'
                    ? 'bg-white text-indigo-900 shadow-2xs border border-indigo-200'
                    : 'text-stone-600 hover:text-stone-900 hover:bg-white/60'
                }`}
              >
                2. Pre-Op Checklist & Assessment
              </button>
              <button
                onClick={() => setActivePdfFormTab('surgical-checklist')}
                className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold transition-all cursor-pointer text-center ${
                  activePdfFormTab === 'surgical-checklist'
                    ? 'bg-white text-indigo-900 shadow-2xs border border-indigo-200'
                    : 'text-stone-600 hover:text-stone-900 hover:bg-white/60'
                }`}
              >
                3. Comprehensive Surgical Checklist
              </button>
            </div>

            {/* Scrollable Form Body Container */}
            <div className="flex-1 overflow-y-auto p-4 sm:p-6 bg-stone-50/70 rounded-2xl border border-stone-200 space-y-6 text-stone-900">
              
              {/* FORM 1: DOCTORS STANDING ORDERS */}
              {activePdfFormTab === 'standing-orders' && (
                <div className="bg-white p-6 sm:p-8 rounded-xl border border-stone-300 shadow-sm space-y-6 font-serif max-w-2xl mx-auto">
                  <div className="text-center space-y-1 border-b border-stone-300 pb-4">
                    <h2 className="text-lg font-bold tracking-wider uppercase text-stone-900">the facility</h2>
                    <p className="text-xs font-sans text-stone-600">1000 Practice Way, Suite 500, Los Angeles, CA 90024</p>
                    <h3 className="text-sm font-bold tracking-wide uppercase pt-2 text-stone-800 underline">Doctors Standing Orders</h3>
                  </div>

                  {/* Preoperative Orders */}
                  <div className="space-y-3 font-sans">
                    <h4 className="font-bold text-xs uppercase tracking-wider text-stone-900 border-b border-stone-200 pb-1">Preoperative Orders</h4>
                    <div className="space-y-2 text-xs">
                      <div className="flex items-center gap-2">
                        <span className="w-4 h-4 bg-stone-900 text-white rounded flex items-center justify-center font-bold text-xs">✓</span>
                        <span className="font-semibold">History and Physical</span>
                      </div>
                      <div className="flex items-start gap-2">
                        <span className="w-4 h-4 bg-stone-900 text-white rounded flex items-center justify-center font-bold text-xs shrink-0 mt-0.5">✓</span>
                        <div>
                          <span className="font-semibold">Surgery Consents For: </span>
                          <span className="font-mono underline font-bold text-stone-900">Face / Necklift, Septo / Rhinoplasty, Turbinates Reduction</span>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="w-4 h-4 bg-stone-900 text-white rounded flex items-center justify-center font-bold text-xs">✓</span>
                        <span className="font-semibold">IV Per Anesthesia</span>
                      </div>
                      <div className="flex items-start gap-2">
                        <span className="w-4 h-4 bg-stone-900 text-white rounded flex items-center justify-center font-bold text-xs shrink-0 mt-0.5">✓</span>
                        <div>
                          <span className="font-semibold">Labs Ordered: </span>
                          <span>Hgb, Hct, CBC, UA, PT, PTT, Electrolytes, Chest X Ray, EKG, HIV, Hepatitis</span>
                        </div>
                      </div>
                      <div className="flex items-start gap-2">
                        <span className="w-4 h-4 bg-stone-900 text-white rounded flex items-center justify-center font-bold text-xs shrink-0 mt-0.5">✓</span>
                        <div>
                          <span className="font-semibold">PreOP Medication: </span>
                          <span className="font-mono underline font-bold text-stone-900">IV Ancef 1g</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Postoperative Orders */}
                  <div className="space-y-3 font-sans border-t border-stone-300 pt-4">
                    <h4 className="font-bold text-xs uppercase tracking-wider text-stone-900 border-b border-stone-200 pb-1">Postoperative Orders</h4>
                    <div className="space-y-2 text-xs">
                      <div className="flex items-center gap-2">
                        <span className="w-4 h-4 bg-stone-900 text-white rounded flex items-center justify-center font-bold text-xs">✓</span>
                        <span className="font-semibold">Routine Vital Signs.</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="w-4 h-4 bg-stone-900 text-white rounded flex items-center justify-center font-bold text-xs">✓</span>
                        <span className="font-semibold">D/C IV when patient tolerating PO fluids without nausea and stable.</span>
                      </div>
                      <div className="flex items-start gap-2 pl-6">
                        <span className="font-semibold">Take home meds: </span>
                        <span className="font-mono underline font-bold text-stone-900">as prescribed by MD</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="w-4 h-4 bg-stone-900 text-white rounded flex items-center justify-center font-bold text-xs">✓</span>
                        <span className="font-semibold">D/C patient per Anesthesiologist</span>
                      </div>
                    </div>
                  </div>

                  {/* Signatures & Patient Stamp Box */}
                  <div className="border-t-2 border-stone-800 pt-4 grid grid-cols-2 gap-4 font-sans text-xs">
                    <div className="space-y-2">
                      <div><span className="font-bold">M.D. Signature:</span> <span className="font-serif italic font-bold text-emerald-900 underline">Provider</span></div>
                      <div><span className="font-bold">Date:</span> <span className="underline font-bold">5/6/26</span></div>
                      <div><span className="font-bold">Noted by:</span> <span className="underline font-bold"></span></div>
                    </div>

                    <div className="p-3 bg-stone-100 rounded-lg border border-stone-400 text-[11px] font-mono space-y-0.5">
                      <div className="font-bold border-b border-stone-300 pb-1">Sterling-Fox, Ashlee (113561)</div>
                      <div>DOB: 2/11/1972 | Age: 54 | Sex: Female</div>
                      <div>Provider: Alex Morgan, M.D.</div>
                      <div>DOS: 05/06/2026</div>
                    </div>
                  </div>
                </div>
              )}

              {/* FORM 2: PRE-OPERATIVE CHECKLIST & ASSESSMENT */}
              {activePdfFormTab === 'preop-checklist' && (
                <div className="bg-white p-6 sm:p-8 rounded-xl border border-stone-300 shadow-sm space-y-5 font-sans max-w-2xl mx-auto text-xs">
                  <div className="text-center border-b-2 border-stone-800 pb-2">
                    <h3 className="text-sm font-bold uppercase tracking-wide">the facility Pre-Operative Checklist and Assessment</h3>
                  </div>

                  <div className="grid grid-cols-2 gap-3 bg-stone-50 p-3 rounded-lg border border-stone-200">
                    <div><span className="font-bold">Date:</span> <span className="underline font-mono">05 / 06 / 2026</span></div>
                    <div><span className="font-bold">Transportation:</span> <span className="underline font-bold">Driver "Imortel"</span> (424-271-0010)</div>
                    <div><span className="font-bold">Home Caregiver:</span> <span className="underline">Nurse Tara (424-285-3701), Anna</span></div>
                    <div><span className="font-bold">Tomorrow Contact:</span> <span className="underline">Husband Tony (818-264-9795)</span></div>
                  </div>

                  {/* Vitals Banner */}
                  <div className="p-3 bg-rose-50 border border-rose-300 rounded-lg space-y-1">
                    <div className="font-bold text-rose-950 flex justify-between">
                      <span>Admission Vitals: Ht: 4'9" | Wt: 117.6 lb | Temp: 36.8°C | BP: 141/85 | RR: 16 | SpO2: 99%</span>
                    </div>
                    <div className="text-rose-900 font-bold underline">
                      Allergies (including soy & sulfites): PCN - Hives
                    </div>
                  </div>

                  {/* Pre-Op Checklist Table */}
                  <div className="grid grid-cols-2 gap-4 border-t border-stone-300 pt-3">
                    <div className="space-y-1.5">
                      <div className="flex justify-between font-bold border-b border-stone-200 pb-1">
                        <span>Checklist Item</span>
                        <span>Status</span>
                      </div>
                      <div className="flex justify-between"><span>H&P in chart</span><span className="font-bold text-emerald-700">✓ Yes</span></div>
                      <div className="flex justify-between"><span>Surgical consent signed</span><span className="font-bold text-emerald-700">✓ Yes</span></div>
                      <div className="flex justify-between"><span>Patient verbalized site</span><span className="font-bold text-emerald-700">✓ Yes</span></div>
                      <div className="flex justify-between"><span>NPO Time</span><span className="font-bold underline">8pm - 5/5/26</span></div>
                      <div className="flex justify-between"><span>Dentures/Loose teeth</span><span className="font-bold text-amber-800">Lower left loose</span></div>
                      <div className="flex justify-between"><span>Jewelry Removed</span><span className="font-bold text-emerald-700">✓ Yes</span></div>
                      <div className="flex justify-between"><span>Metal implants</span><span className="font-bold text-stone-500">No</span></div>
                    </div>

                    <div className="space-y-1.5 border-l border-stone-200 pl-4">
                      <div className="flex justify-between font-bold border-b border-stone-200 pb-1">
                        <span>Initial Assessment</span>
                        <span>Result</span>
                      </div>
                      <div className="flex justify-between"><span>Resp</span><span className="font-bold">WNL</span></div>
                      <div className="flex justify-between"><span>CV</span><span className="font-bold">WNL (Pulsex4, SR)</span></div>
                      <div className="flex justify-between"><span>Skin</span><span className="font-bold">WNL</span></div>
                      <div className="flex justify-between"><span>Color</span><span className="font-bold">Pink / WNL</span></div>
                      <div className="flex justify-between"><span>LOC</span><span className="font-bold">A&O x4</span></div>
                      <div className="flex justify-between"><span>Bleeding Tendencies</span><span className="font-bold text-stone-500">No</span></div>
                    </div>
                  </div>

                  <div className="border-t border-stone-300 pt-3 space-y-1.5">
                    <div className="font-bold">Pre-Operative Orders Administered:</div>
                    <div className="flex flex-wrap gap-2 text-[11px]">
                      <span className="px-2 py-1 bg-stone-100 rounded border font-bold">✓ Celebrex</span>
                      <span className="px-2 py-1 bg-stone-100 rounded border font-bold">✓ Emend</span>
                      <span className="px-2 py-1 bg-stone-100 rounded border font-bold">✓ Journavax</span>
                      <span className="px-2 py-1 bg-emerald-100 text-emerald-900 rounded border border-emerald-300 font-bold">✓ Valium 5mg</span>
                    </div>
                    <div className="pt-2 text-[11px] text-stone-600">
                      IV Site: <span className="font-bold text-stone-900 underline">Left Hand</span> | Inserted by: <span className="font-bold text-stone-900"></span> | Nurse: <span className="font-bold text-stone-900"></span>
                    </div>
                  </div>
                </div>
              )}

              {/* FORM 3: COMPREHENSIVE SURGICAL CHECKLIST */}
              {activePdfFormTab === 'surgical-checklist' && (
                <div className="bg-white p-6 sm:p-8 rounded-xl border border-stone-300 shadow-sm space-y-5 font-sans max-w-3xl mx-auto text-xs">
                  <div className="text-center border-b-2 border-stone-800 pb-2">
                    <h3 className="text-sm font-bold uppercase tracking-wide">Comprehensive Surgical Checklist (AORN / WHO Protocol)</h3>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
                    {/* Phase 1 */}
                    <div className="p-3 bg-stone-50 rounded-lg border border-stone-300 space-y-2">
                      <div className="font-bold text-stone-900 uppercase border-b border-stone-200 pb-1 text-[11px]">
                        In Holding Area
                      </div>
                      <div className="space-y-1 text-[11px]">
                        <div>RN: <span className="font-bold underline"></span></div>
                        <div className="text-emerald-700 font-bold">✓ Identity Confirmed</div>
                        <div className="text-emerald-700 font-bold">✓ Procedure & Site</div>
                        <div className="text-emerald-700 font-bold">✓ Consents Signed</div>
                        <div className="text-emerald-700 font-bold">✓ Site Marked</div>
                      </div>
                    </div>

                    {/* Phase 2 */}
                    <div className="p-3 bg-stone-50 rounded-lg border border-stone-300 space-y-2">
                      <div className="font-bold text-stone-900 uppercase border-b border-stone-200 pb-1 text-[11px]">
                        Before Induction (Sign-In)
                      </div>
                      <div className="space-y-1 text-[11px]">
                        <div>Anesthesia: <span className="font-bold underline"></span></div>
                        <div className="text-rose-700 font-bold">✓ Allergy: PCN (hives)</div>
                        <div className="text-emerald-700 font-bold">✓ Difficult Airway: No</div>
                        <div className="text-emerald-700 font-bold">✓ Equipment Ready</div>
                        <div className="text-emerald-700 font-bold">✓ SCD 40mmHg On</div>
                      </div>
                    </div>

                    {/* Phase 3 */}
                    <div className="p-3 bg-stone-50 rounded-lg border border-stone-300 space-y-2">
                      <div className="font-bold text-stone-900 uppercase border-b border-stone-200 pb-1 text-[11px]">
                        Before Incision (Time-Out)
                      </div>
                      <div className="space-y-1 text-[11px]">
                        <div>Surgeon: <span className="font-bold underline">Provider</span></div>
                        <div className="text-emerald-700 font-bold">✓ Time-Out Executed</div>
                        <div className="text-emerald-700 font-bold">✓ Abx: IV Ancef 1g</div>
                        <div className="text-emerald-700 font-bold">✓ Sterilization Confirm</div>
                        <div className="text-emerald-700 font-bold">✓ Images Displayed</div>
                      </div>
                    </div>

                    {/* Phase 4 */}
                    <div className="p-3 bg-stone-50 rounded-lg border border-stone-300 space-y-2">
                      <div className="font-bold text-stone-900 uppercase border-b border-stone-200 pb-1 text-[11px]">
                        Before Leaving OR (Sign-Out)
                      </div>
                      <div className="space-y-1 text-[11px]">
                        <div>RN: <span className="font-bold underline">Ani Abadjian, RN</span></div>
                        <div className="text-emerald-700 font-bold">✓ Procedure Name</div>
                        <div className="text-emerald-700 font-bold">✓ Counts Complete</div>
                        <div className="text-emerald-700 font-bold">✓ Specimens Labeled</div>
                        <div className="text-emerald-700 font-bold">✓ PACU Transfer Ready</div>
                      </div>
                    </div>
                  </div>

                  <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-lg text-center font-bold text-emerald-900">
                    Surgical Safety Verification Complete · All 4 Audit Gateways Signed & Recorded
                  </div>
                </div>
              )}

            </div>

            {/* Modal Bottom Footer */}
            <div className="flex items-center justify-between pt-3 border-t border-stone-200 shrink-0">
              <span className="text-xs text-stone-500 font-medium flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                <span>Verified Digital Chart Record · the practice HIPAA Vault</span>
              </span>

              <button
                onClick={() => setIsPdfFormsModalOpen(false)}
                className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl transition-colors cursor-pointer"
              >
                Close Form Portal
              </button>
            </div>

          </div>
        </div>
      )}

      {/* Note Reader Modal */}
      {viewingHistoryNote && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-200">
          <div className="bg-white rounded-3xl max-w-2xl w-full p-6 shadow-2xl border border-stone-300 space-y-4 relative">
            <div className="flex items-center justify-between border-b border-stone-200 pb-3">
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-base font-bold text-stone-900">{viewingHistoryNote.title}</h3>
                  <span className="px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-bold border border-emerald-200">
                    {viewingHistoryNote.status}
                  </span>
                </div>
                <p className="text-xs text-stone-500 font-medium mt-0.5">
                  Author: <strong className="text-stone-800">{viewingHistoryNote.author}</strong> · {viewingHistoryNote.date}
                </p>
              </div>
              <button
                onClick={() => setViewingHistoryNote(null)}
                className="p-2 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-600 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-4 bg-stone-50 rounded-2xl border border-stone-200 text-xs text-stone-800 leading-relaxed font-mono whitespace-pre-wrap max-h-[60vh] overflow-y-auto">
              {viewingHistoryNote.content}
            </div>

            <div className="flex items-center justify-between pt-2 border-t border-stone-200">
              <span className="text-[11px] text-stone-500 font-medium">Verified in the practice EHR</span>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => alert('Printing note...')}
                  className="px-3 py-1.5 bg-stone-100 hover:bg-stone-200 text-stone-800 font-bold text-xs rounded-xl transition-colors cursor-pointer flex items-center gap-1.5"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>Print Note</span>
                </button>
                <button
                  onClick={() => setViewingHistoryNote(null)}
                  className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-xs transition-colors cursor-pointer"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Pre-Op Email Intake Link Modal */}
      {isPreOpEmailModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-200">
          <div className="bg-white rounded-3xl max-w-2xl w-full p-6 shadow-2xl border border-stone-300 space-y-5 relative">
            <div className="flex items-center justify-between border-b border-stone-200 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-indigo-50 text-indigo-700 rounded-xl">
                  <Mail className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-stone-900">Email Pre-Op Intake Forms to Patient</h3>
                  <p className="text-xs text-stone-500 font-medium">
                    Send secure Patient Portal link with selected pre-operative PDF forms
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsPreOpEmailModalOpen(false)}
                className="p-2 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-600 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4 text-xs">
              {/* Recipient Input */}
              <div className="space-y-1">
                <label className="font-bold text-stone-800">Patient Email Address</label>
                <input
                  type="email"
                  value={customEmailRecipient}
                  onChange={(e) => setCustomEmailRecipient(e.target.value)}
                  className="w-full p-2.5 bg-stone-50 border border-stone-300 rounded-xl font-mono text-stone-900 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  placeholder="patient@example.com"
                />
              </div>

              {/* Subject Line */}
              <div className="space-y-1">
                <label className="font-bold text-stone-800">Email Subject Line</label>
                <input
                  type="text"
                  defaultValue={`Action Required: Pre-Operative Intake & Consent Packet for ${selectedPatient.name}`}
                  className="w-full p-2.5 bg-stone-50 border border-stone-300 rounded-xl font-bold text-stone-900 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              {/* Email Body & Portal Link Preview Box */}
              <div className="p-4 bg-stone-50 rounded-2xl border border-stone-200 space-y-3">
                <div className="text-[11px] font-bold text-stone-500 uppercase tracking-wider">
                  PREVIEW OF EMAIL SENT TO PATIENT
                </div>
                <p className="text-stone-800 leading-relaxed font-sans">
                  Dear <strong>{selectedPatient.name}</strong>,<br />
                  Your pre-operative surgical appointment at <strong>the facility</strong> is scheduled for <strong>{selectedPatient.appointmentDate || ''}</strong>.
                </p>
                <p className="text-stone-800 leading-relaxed font-sans">
                  Please click the link below to access your confidential Patient Portal. You must review, complete, and electronically sign the <strong>{selectedPreOpFormIds.length} pre-operative intake forms</strong> prior to your surgery date.
                </p>

                {/* Secure Portal Link Callout */}
                <div className="p-3 bg-indigo-50 border border-indigo-200 rounded-xl flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2 min-w-0">
                    <Link className="w-4 h-4 text-indigo-600 shrink-0" />
                    <span className="font-mono text-[11px] text-indigo-900 font-bold truncate">
                      https://portal.auravanguard.com/intake/{selectedPatient.patientId || 'p-113561'}?token=preop-2026
                    </span>
                  </div>
                  <button
                    onClick={() => {
                      navigator.clipboard.writeText(`https://portal.auravanguard.com/intake/${selectedPatient.patientId || 'p-113561'}?token=preop-2026`);
                      alert('Portal link copied to clipboard!');
                    }}
                    className="px-2.5 py-1 bg-white hover:bg-stone-100 border border-indigo-200 text-indigo-800 text-[11px] font-bold rounded-lg cursor-pointer flex items-center gap-1 shrink-0"
                  >
                    <Copy className="w-3 h-3" />
                    <span>Copy</span>
                  </button>
                </div>

                {/* Included Forms Badges */}
                <div className="pt-2 border-t border-stone-200">
                  <div className="text-[11px] font-bold text-stone-700 mb-2">
                    {selectedPreOpFormIds.length} Forms Included in This Portal Link:
                  </div>
                  <div className="flex flex-wrap gap-1.5 max-h-36 overflow-y-auto">
                    {PRE_OP_INTAKE_PDF_FORMS.filter((f) => selectedPreOpFormIds.includes(f.id)).map((f) => (
                      <span key={f.id} className="px-2.5 py-1 bg-white border border-stone-200 rounded-lg text-[11px] font-bold text-stone-800 shadow-2xs">
                        ✓ {f.title}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* Modal Bottom Actions */}
            <div className="flex items-center justify-between pt-3 border-t border-stone-200">
              <span className="text-[11px] text-stone-500 font-medium">
                HIPAA Secure Transmittal · Example Practice Patient Portal
              </span>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setIsPreOpEmailModalOpen(false)}
                  className="px-4 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 font-bold text-xs rounded-xl transition-colors cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  onClick={() => {
                    const updated = { ...formStatuses };
                    selectedPreOpFormIds.forEach((id) => {
                      updated[id] = 'Sent via Email';
                    });
                    setFormStatuses(updated);
                    setIsPreOpEmailModalOpen(false);
                    setPreOpEmailSuccessToast(
                      `Pre-operative intake email with secure Patient Portal link was sent to ${customEmailRecipient || selectedPatient.name}!`
                    );
                  }}
                  className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-xl shadow-xs transition-colors cursor-pointer flex items-center gap-1.5"
                >
                  <Send className="w-4 h-4" />
                  <span>Send Email with Portal Link</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Patient Portal Interactive Preview Modal */}
      {isPreOpPortalPreviewOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-200">
          <div className="bg-white rounded-3xl max-w-4xl w-full p-6 shadow-2xl border border-stone-300 space-y-4 relative max-h-[92vh] flex flex-col">
            
            {/* Header Bar */}
            <div className="flex items-center justify-between border-b border-stone-200 pb-3 shrink-0">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-emerald-50 text-emerald-700 rounded-xl">
                  <Laptop className="w-5 h-5" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-base font-bold text-stone-900">the practice — Patient Portal Preview</h3>
                    <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-bold border border-emerald-200">
                      LIVE PATIENT PORTAL
                    </span>
                  </div>
                  <p className="text-xs text-stone-500 font-medium">
                    Simulating how <strong className="text-stone-800">{selectedPatient.name}</strong> completes and signs pre-op forms
                  </p>
                </div>
              </div>

              <button
                onClick={() => setIsPreOpPortalPreviewOpen(false)}
                className="p-2 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-600 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Portal Patient Greeting Banner */}
            <div className="p-3 bg-gradient-to-r from-slate-900 to-emerald-950 text-white rounded-2xl flex flex-wrap items-center justify-between gap-3 text-xs shrink-0">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-full bg-indigo-500/30 text-indigo-200 font-bold flex items-center justify-center border border-indigo-400/30">
                  {selectedPatient.name.split(' ').map(n=>n[0]).join('')}
                </div>
                <div>
                  <div className="font-bold text-white text-sm">{selectedPatient.name}</div>
                  <div className="text-indigo-200 text-[11px]">
                    Surgery Date: {selectedPatient.appointmentDate || ''} · Surgeon: {selectedPatient.surgeon || 'Provider'}
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <span className="px-2.5 py-1 bg-white/10 text-emerald-300 font-mono text-[11px] rounded-lg border border-white/20">
                  🔒 Secure SSL Connection
                </span>
              </div>
            </div>

            {/* Main Portal View Layout */}
            <div className="flex-1 overflow-hidden grid grid-cols-1 md:grid-cols-12 gap-4 min-h-[380px]">
              
              {/* Left Sidebar Form Navigation */}
              <div className="md:col-span-4 bg-stone-50 p-3 rounded-2xl border border-stone-200 space-y-2 overflow-y-auto max-h-[460px]">
                <div className="text-[10px] font-bold text-stone-400 uppercase tracking-wider px-2 pt-1">
                  PRE-SURGERY INTAKE PACKET
                </div>

                {PRE_OP_INTAKE_PDF_FORMS.map((form) => {
                  const isActive = activePortalFormId === form.id;
                  const isCheckedInEmail = selectedPreOpFormIds.includes(form.id);
                  const status = formStatuses[form.id] || form.status;

                  return (
                    <button
                      key={form.id}
                      onClick={() => setActivePortalFormId(form.id)}
                      className={`w-full text-left p-2.5 rounded-xl border text-xs transition-all cursor-pointer flex items-center justify-between gap-2 ${
                        isActive
                          ? 'bg-indigo-600 text-white border-indigo-600 shadow-xs'
                          : isCheckedInEmail
                          ? 'bg-white text-stone-800 border-stone-200 hover:bg-stone-100'
                          : 'bg-stone-100/60 text-stone-400 border-stone-200 opacity-60'
                      }`}
                    >
                      <div className="min-w-0 flex-1">
                        <div className="font-bold truncate">{form.title}</div>
                        <div className={`text-[10px] truncate ${isActive ? 'text-indigo-100' : 'text-stone-500'}`}>
                          {form.pdfGroup}
                        </div>
                      </div>

                      <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded shrink-0 ${
                        status === 'Completed in Portal'
                          ? isActive ? 'bg-emerald-500 text-white' : 'bg-emerald-100 text-emerald-800'
                          : isActive ? 'bg-indigo-700 text-white' : 'bg-stone-200 text-stone-700'
                      }`}>
                        {status === 'Completed in Portal' ? '✓ Signed' : 'Pending'}
                      </span>
                    </button>
                  );
                })}
              </div>

              {/* Right Main Form Viewer & Signature Pad */}
              {(() => {
                const currentForm = PRE_OP_INTAKE_PDF_FORMS.find((f) => f.id === activePortalFormId) || PRE_OP_INTAKE_PDF_FORMS[0];
                const isCompleted = formStatuses[currentForm.id] === 'Completed in Portal';

                return (
                  <div className="md:col-span-8 bg-white p-5 rounded-2xl border border-stone-200 space-y-4 overflow-y-auto max-h-[460px] text-xs">
                    
                    {/* Form Header */}
                    <div className="border-b border-stone-200 pb-3 flex items-start justify-between gap-2">
                      <div>
                        <div className="text-[10px] font-bold text-indigo-600 uppercase tracking-wider">
                          PRACTICE · FORM PACKET
                        </div>
                        <h4 className="font-bold text-base text-stone-900 mt-0.5">{currentForm.title}</h4>
                        <p className="text-stone-500 text-xs font-medium">{currentForm.subtitle}</p>
                      </div>

                      <span className={`px-2.5 py-1 rounded-full text-xs font-bold border shrink-0 ${
                        isCompleted
                          ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                          : 'bg-amber-50 text-amber-800 border-amber-200'
                      }`}>
                        {isCompleted ? '✓ Signed in Portal' : 'Action Required'}
                      </span>
                    </div>

                    {/* Form Description & Content Preview */}
                    <div className="p-3.5 bg-stone-50 rounded-xl border border-stone-200 text-stone-800 leading-relaxed space-y-2 font-sans">
                      <p className="font-bold text-stone-900">{currentForm.description}</p>

                      {currentForm.id === 'patients-rights' && (
                        <div className="space-y-1.5 text-[11px] text-stone-700 pt-2 border-t border-stone-200">
                          <div>• Patients are treated with respect, consideration, and dignity with personal privacy.</div>
                          <div>• Right to be fully informed of scope of services, post-op instructions, and fees.</div>
                          <div>• Responsibility to provide complete medical/medication history and a responsible adult driver.</div>
                        </div>
                      )}

                      {currentForm.id === 'advanced-directives' && (
                        <div className="space-y-2 text-[11px] text-stone-700 pt-2 border-t border-stone-200">
                          <p>the practice performs elective outpatient procedures. In event of emergency, cardiac life support is instituted and patient transferred to acute hospital care.</p>
                          <div className="space-y-1 font-bold">
                            <label className="flex items-center gap-2 cursor-pointer">
                              <input type="checkbox" defaultChecked className="rounded border-stone-300 text-indigo-600 focus:ring-indigo-500" />
                              <span>I have read and understand Advanced Directives policy</span>
                            </label>
                            <label className="flex items-center gap-2 cursor-pointer">
                              <input type="checkbox" className="rounded border-stone-300 text-indigo-600 focus:ring-indigo-500" />
                              <span>I DO have an Advance Directive</span>
                            </label>
                            <label className="flex items-center gap-2 cursor-pointer">
                              <input type="checkbox" defaultChecked className="rounded border-stone-300 text-indigo-600 focus:ring-indigo-500" />
                              <span>I DO NOT have an Advance Directive</span>
                            </label>
                          </div>
                        </div>
                      )}

                      {currentForm.id === 'anesthesia-questionnaire' && (
                        <div className="grid grid-cols-2 gap-2 text-[11px] pt-2 border-t border-stone-200 font-sans">
                          <div><strong>Height:</strong> 5' 6"</div>
                          <div><strong>Weight:</strong> 138 lbs</div>
                          <div><strong>Drug Allergies:</strong> Penicillin (Hives)</div>
                          <div><strong>Latex Allergy:</strong> No</div>
                          <div><strong>Past Surgeries:</strong> Appendectomy (2018)</div>
                          <div><strong>Airway History:</strong> Normal</div>
                        </div>
                      )}
                    </div>

                    {/* Electronic Patient Signature Box */}
                    <div className="p-4 bg-stone-50 rounded-2xl border border-stone-300 space-y-3">
                      <div className="flex items-center justify-between">
                        <label className="font-bold text-stone-900 text-xs flex items-center gap-1.5">
                          <CheckCircle2 className="w-4 h-4 text-indigo-600" />
                          <span>Patient Electronic Signature & Date</span>
                        </label>
                        <span className="text-[10px] text-stone-400 font-mono">21 C.F.R. Part 11 Compliant</span>
                      </div>

                      <div className="p-3 bg-white rounded-xl border border-stone-300 text-center font-serif italic font-bold text-lg text-indigo-900 border-dashed min-h-[50px] flex items-center justify-center">
                        {selectedPatient.name}
                      </div>

                      <div className="flex items-center justify-between text-[11px] text-stone-500">
                        <span>Signed by IP: 192.168.1.42</span>
                        <span>Date: </span>
                      </div>
                    </div>

                    {/* Submit Form Button */}
                    <button
                      onClick={() => {
                        setFormStatuses({
                          ...formStatuses,
                          [currentForm.id]: 'Completed in Portal',
                        });
                        alert(`Successfully submitted and signed "${currentForm.title}" in Patient Portal!`);
                      }}
                      className="w-full py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs rounded-xl shadow-2xs transition-colors cursor-pointer flex items-center justify-center gap-2"
                    >
                      <CheckCircle2 className="w-4 h-4" />
                      <span>{isCompleted ? 'Update Signed Form in Portal' : 'Complete & Sign Form in Patient Portal'}</span>
                    </button>
                  </div>
                );
              })()}
            </div>

            {/* Modal Bottom Footer */}
            <div className="flex items-center justify-between pt-3 border-t border-stone-200 shrink-0">
              <span className="text-xs text-stone-500 font-medium flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                <span>Patient Portal Sync Enabled · Real-time intake feed for the practice</span>
              </span>

              <button
                onClick={() => setIsPreOpPortalPreviewOpen(false)}
                className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl transition-colors cursor-pointer"
              >
                Close Portal Preview
              </button>
            </div>

          </div>
        </div>
      )}

      {/* Full-Screen Overlay Document Viewer (Blank Page with ONLY a Close Button, NO header or navigation) */}
      {viewingDoc && (
        <div className="fixed inset-0 z-[99999] bg-stone-100 flex flex-col w-screen h-screen overflow-hidden animate-in fade-in duration-150">
          <MinimalWorkflowHeader
            title={viewingDoc.title}
            onClose={() => setViewingDoc(null)}
          />

          {/* Blank Page Document Container */}
          <div className="w-full flex-1 overflow-y-auto overflow-x-auto bg-stone-200/60 px-3 sm:px-6 py-5">
            <div className="w-full max-w-4xl bg-white rounded-2xl shadow-xl border border-stone-200 p-6 sm:p-10 my-4 sm:my-8 flex flex-col justify-between space-y-6">
              {/* If Converted PDF Form Tab */}
              {viewingDoc.formTab === 'standing-orders' && (
                <div className="space-y-6 text-xs text-stone-800">
                  <div className="text-center space-y-1 border-b border-stone-300 pb-4">
                    <h2 className="text-base font-bold tracking-wider uppercase text-stone-900">PRACTICE</h2>
                    <p className="text-xs text-stone-600">1000 Practice Way, Suite 500, Los Angeles, CA 90024</p>
                    <h3 className="text-sm font-bold tracking-wide uppercase pt-2 text-stone-800 underline">DOCTORS STANDING ORDERS</h3>
                  </div>
                  <div className="space-y-4">
                    <div className="p-4 bg-stone-50 rounded-xl border border-stone-200 space-y-2">
                      <h4 className="font-bold text-stone-900 uppercase">Preoperative Orders</h4>
                      <p>✓ History and Physical | ✓ Surgery Consents for Face/Necklift, Rhinoplasty | ✓ IV Per Anesthesia | ✓ PreOP Med: IV Ancef 1g</p>
                    </div>
                    <div className="p-4 bg-stone-50 rounded-xl border border-stone-200 space-y-2">
                      <h4 className="font-bold text-stone-900 uppercase">Postoperative Orders</h4>
                      <p>✓ Routine Vital Signs | ✓ D/C IV when patient tolerating PO fluids | ✓ D/C patient per Anesthesiologist</p>
                    </div>
                  </div>
                  <div className="border-t-2 border-stone-800 pt-4 flex justify-between items-center text-xs">
                    <div><strong>MD Signature:</strong> Provider | <strong>Date:</strong> 5/6/26</div>
                    <div><strong>Noted by:</strong> </div>
                  </div>
                </div>
              )}

              {viewingDoc.formTab === 'preop-checklist' && (
                <div className="space-y-6 text-xs text-stone-800">
                  <div className="text-center border-b-2 border-stone-800 pb-2">
                    <h3 className="text-base font-bold uppercase tracking-wide">the facility Pre-Operative Checklist and Assessment</h3>
                  </div>
                  <div className="p-4 bg-rose-50 border border-rose-300 rounded-xl space-y-1">
                    <div className="font-bold text-rose-950">Admission Vitals: Ht: 4'9" | Wt: 117.6 lb | BP: 141/85 | RR: 16 | SpO2: 99%</div>
                    <div className="text-rose-900 font-bold underline">Allergies: PCN (Hives)</div>
                  </div>
                  <div className="p-4 bg-stone-50 rounded-xl border border-stone-200 space-y-2">
                    <div className="font-bold text-stone-900">Checklist Summary:</div>
                    <p>✓ H&P in chart | ✓ Surgical consent signed | ✓ Site marked | ✓ NPO since 8pm | Loose lower left tooth noted</p>
                  </div>
                </div>
              )}

              {viewingDoc.formTab === 'surgical-checklist' && (
                <div className="space-y-6 text-xs text-stone-800">
                  <div className="text-center border-b-2 border-stone-800 pb-2">
                    <h3 className="text-base font-bold uppercase tracking-wide">Comprehensive Surgical Checklist (AORN / WHO Protocol)</h3>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="p-3 bg-stone-50 rounded-lg border border-stone-200 space-y-1">
                      <div className="font-bold text-stone-900">1. Holding Area</div>
                      <p>✓ Identity & site confirmed by </p>
                    </div>
                    <div className="p-3 bg-stone-50 rounded-lg border border-stone-200 space-y-1">
                      <div className="font-bold text-stone-900">2. Before Induction</div>
                      <p>✓ Allergy PCN noted by </p>
                    </div>
                    <div className="p-3 bg-stone-50 rounded-lg border border-stone-200 space-y-1">
                      <div className="font-bold text-stone-900">3. Time-Out</div>
                      <p>✓ Executed by Provider</p>
                    </div>
                    <div className="p-3 bg-stone-50 rounded-lg border border-stone-200 space-y-1">
                      <div className="font-bold text-stone-900">4. Sign-Out</div>
                      <p>✓ Counts complete by </p>
                    </div>
                  </div>
                </div>
              )}

              {/* ID & Insurance Scans */}
              {(viewingDoc.id === 'doc-5' || viewingDoc.id === 'doc-6') && (
                <div className="space-y-6 text-center">
                  <h3 className="text-base font-bold text-stone-900">{viewingDoc.title}</h3>
                  <div className="flex justify-center">
                    <img
                      src={viewingDoc.id === 'doc-5' ? idCardUrl : insuranceCardFrontUrl}
                      alt={viewingDoc.title}
                      className="max-h-96 rounded-2xl shadow-lg border border-stone-300 object-contain"
                    />
                  </div>
                  {viewingDoc.id === 'doc-6' && (
                    <div className="flex justify-center">
                      <img
                        src={insuranceCardBackUrl}
                        alt="Insurance Card Back"
                        className="max-h-96 rounded-2xl shadow-lg border border-stone-300 object-contain"
                      />
                    </div>
                  )}
                  <p className="text-xs text-stone-500 font-mono">{viewingDoc.summary}</p>
                </div>
              )}

              {/* Standard text document content view */}
              {!viewingDoc.formTab && viewingDoc.id !== 'doc-5' && viewingDoc.id !== 'doc-6' && (
                <div className="space-y-6">
                  <div className="border-b border-stone-200 pb-4">
                    <h2 className="text-lg font-bold text-stone-900">{viewingDoc.title}</h2>
                    <p className="text-xs text-stone-500 font-medium mt-1">
                      Category: <span className="font-bold text-stone-700">{viewingDoc.type}</span> · Submission Date: <span className="font-bold text-stone-700">{viewingDoc.submissionDate}</span>
                    </p>
                  </div>

                  <div className="p-5 bg-stone-50 rounded-xl border border-stone-200 whitespace-pre-wrap font-mono text-xs text-stone-800 leading-relaxed min-h-[300px]">
                    {viewingDoc.content || viewingDoc.summary}
                  </div>

                  <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-xl flex items-center justify-between text-xs text-emerald-900 font-bold">
                    <span className="flex items-center gap-1.5">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                      <span>Verified EHR Record Attachment</span>
                    </span>
                    <span>Archival ID: #{viewingDoc.id.toUpperCase()}</span>
                  </div>
                </div>
              )}

              {/* Footer inside document card */}
              <div className="pt-6 border-t border-stone-200 flex flex-wrap items-center justify-between gap-4 text-xs text-stone-500">
                <div>Patient: <strong>{selectedPatient.name}</strong> | DOB: <strong>{selectedPatient.dob || '02/11/1972'}</strong> | MRN: <strong>{selectedPatient.patientId}</strong></div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* View Original Document — plain facsimile of the source file, separate from the styled summary popup above */}
      {viewingOriginalDoc && (
        <div className="fixed inset-0 z-[99999] bg-stone-500/90 flex flex-col w-screen h-screen overflow-y-auto animate-in fade-in duration-150">
          <MinimalWorkflowHeader
            title={viewingOriginalDoc.title}
            onClose={() => setViewingOriginalDoc(null)}
          />

          <div className="w-full flex-1 p-2 sm:p-8 flex justify-center items-start min-h-screen overflow-x-hidden">
            <div
              className="w-full max-w-3xl bg-white shadow-2xl my-10 sm:my-16 p-8 sm:p-12 text-stone-900"
              style={{ fontFamily: 'Georgia, "Times New Roman", serif', minHeight: '11in' }}
            >
              <div className="text-center border-b-4 border-stone-800 pb-4 mb-6 space-y-1">
                <h2 className="text-lg font-bold tracking-wide uppercase">Example Practice Surgical &amp; Aesthetic Pavilion</h2>
                <p className="text-[11px] text-stone-600">1000 Practice Way, Suite 500, Los Angeles, CA 90024 · (310) 555-0100</p>
              </div>

              <div className="flex items-center justify-between text-xs text-stone-600 font-semibold mb-6 pb-3 border-b border-stone-300">
                <span>File: {viewingOriginalDoc.fileName}</span>
                <span>{viewingOriginalDoc.submissionDate}</span>
              </div>

              <h3 className="text-base font-bold text-center uppercase tracking-wide mb-6">{viewingOriginalDoc.title}</h3>

              {(viewingOriginalDoc.id === 'doc-5' || viewingOriginalDoc.id === 'doc-6') ? (
                <div className="space-y-6 text-center">
                  <div className="flex justify-center">
                    <img
                      src={viewingOriginalDoc.id === 'doc-5' ? idCardUrl : insuranceCardFrontUrl}
                      alt={viewingOriginalDoc.title}
                      className="max-h-96 border border-stone-300 object-contain"
                    />
                  </div>
                  {viewingOriginalDoc.id === 'doc-6' && (
                    <div className="flex justify-center">
                      <img src={insuranceCardBackUrl} alt="Insurance Card Back" className="max-h-96 border border-stone-300 object-contain" />
                    </div>
                  )}
                </div>
              ) : (
                <div className="whitespace-pre-wrap text-[13px] leading-relaxed">
                  {viewingOriginalDoc.content || viewingOriginalDoc.summary}
                </div>
              )}

              <div className="mt-10 pt-4 border-t border-stone-400 flex items-center justify-between text-[11px] text-stone-500">
                <span>Patient: {selectedPatient.name} · DOB: {selectedPatient.dob || '02/11/1972'} · MRN: {selectedPatient.patientId}</span>
                <span>Archival ID #{viewingOriginalDoc.id.toUpperCase()}</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ---------------------------------------------------- */}
      {/* HTML INTAKE FORMS MODALS & OVERLAYS                  */}
      {/* ---------------------------------------------------- */}

      {/* 1. View & Sign HTML Form Overlay (Full-Screen Form with Integrated Attestation & Pre-Fill) */}
      {viewingHtmlForm && (
        <div className="fixed inset-0 z-[99999] bg-stone-100 flex flex-col w-screen h-screen overflow-hidden animate-in fade-in duration-150">
          <MinimalWorkflowHeader
            title={viewingHtmlForm.title}
            onClose={() => setViewingHtmlForm(null)}
          />

          {/* Blank Page Native Form Container & Integrated Signature Section (Full Screen No Scrollbars) */}
          <div className="w-full flex-1 overflow-y-auto overflow-x-auto bg-stone-200/60 px-3 sm:px-6 py-5">
            <div className="w-full max-w-[980px] mx-auto bg-white shadow-md border border-stone-300 p-5 sm:p-8 relative">
              <IsolatedHtmlFormRenderer html={getPrefilledIntakeHtml(viewingHtmlForm.htmlTemplate, selectedPatient)} />

              {/* Patient Electronic Signature & Legal Attestation Section at the bottom of the single form page */}
              <div className="mt-8 pt-6 border-t-2 border-stone-200/90">
                {viewingHtmlForm.status === 'Completed in Portal' ? (
                  <div className="p-6 bg-emerald-50/80 border-2 border-emerald-400/60 rounded-2xl space-y-3.5 text-xs text-emerald-950 shadow-xs">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2 text-emerald-900 font-bold text-sm">
                        <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                        <span>Patient Electronic Signature &amp; Legal Attestation</span>
                      </div>
                      <span className="bg-emerald-200/80 text-emerald-900 font-bold px-2.5 py-0.5 rounded-full text-[10.5px]">
                        Completed &amp; Verified
                      </span>
                    </div>

                    <p className="leading-relaxed text-emerald-900">
                      This clinical intake questionnaire has been digitally completed, attested, and legally executed by the patient. A verified PDF copy is securely filed in the patient's Documents repository.
                    </p>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 border-t border-emerald-200/80 font-mono text-[11px]">
                      <div>
                        <span className="text-emerald-700 block font-sans font-bold text-[10px] uppercase">Legally Signed By</span>
                        <span className="font-bold text-emerald-950">{viewingHtmlForm.signedBy || selectedPatient.name}</span>
                      </div>
                      <div>
                        <span className="text-emerald-700 block font-sans font-bold text-[10px] uppercase">Execution Timestamp</span>
                        <span className="font-bold text-emerald-950">{viewingHtmlForm.completedDate || 'Aug 16, 2026'} · Verified</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 pt-1 text-[10.5px] text-emerald-800 font-mono">
                      <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
                      <span>Audit Trail: Cryptographic SHA-256 Signature Sealed into EHR Chart</span>
                    </div>
                  </div>
                ) : (
                  <div className="p-6 bg-stone-50 border-2 border-teal-500/40 rounded-2xl space-y-4 text-xs text-stone-900 shadow-md">
                    <div className="flex items-center gap-2 text-teal-900 font-bold text-sm">
                      <PenTool className="w-4 h-4 text-teal-600" />
                      <span>Patient Electronic Signature &amp; Legal Attestation</span>
                    </div>

                    <div className="p-3.5 bg-teal-50/70 border border-teal-200 rounded-xl text-xs text-teal-950 space-y-2">
                      <p className="leading-relaxed">
                        By typing the legal name and submitting this document, you certify that all information provided is accurate and complete to the best of your knowledge, and consent is authorized for clinical procedures and electronic medical record archiving.
                      </p>
                      <div className="flex items-center gap-2 pt-1 font-mono text-[11px] text-teal-800">
                        <Lock className="w-3.5 h-3.5 text-teal-600" />
                        <span>IP Address &amp; Time: {new Date().toLocaleDateString()} {new Date().toLocaleTimeString()} (Logged)</span>
                      </div>
                    </div>

                    <div className="space-y-3 pt-1">
                      <SignaturePad
                        label="Patient Signature"
                        signerName={selectedPatient.name}
                        savedSignature={chartFormSignature || null}
                        onSave={setChartFormSignature}
                      />
                    </div>

                    <div className="pt-3 border-t border-stone-200 flex items-center justify-between">
                      <button
                        type="button"
                        onClick={() => setViewingHtmlForm(null)}
                        className="px-4 py-2 bg-stone-200 hover:bg-stone-300 text-stone-700 rounded-xl text-xs font-bold transition-colors cursor-pointer"
                      >
                        Cancel
                      </button>

                      <button
                        type="button"
                        onClick={() => handleCompleteIntakeForm(viewingHtmlForm, selectedPatient.name)}
                        disabled={!chartFormSignature}
                        className="px-6 py-2.5 bg-teal-600 hover:bg-teal-700 disabled:bg-stone-300 disabled:cursor-not-allowed text-white rounded-xl text-xs font-bold shadow-md transition-all flex items-center gap-2 cursor-pointer"
                      >
                        <CheckCircle2 className="w-4 h-4" />
                        <span>Submit &amp; Sign to Chart</span>
                      </button>
                    </div>
                  </div>
                )}
              </div>

            </div>
          </div>
        </div>
      )}

      {/* 2. Send Link via Email / SMS Modal */}
      {isSendFormsModalOpen && (
        <div className="fixed inset-0 z-[120] bg-stone-900/80 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in duration-200">
          <div className="bg-white rounded-2xl max-w-lg w-full shadow-2xl border border-stone-200 overflow-hidden space-y-0">
            {/* Modal Header */}
            <div className="p-5 bg-gradient-to-r from-stone-900 to-emerald-950 text-white flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2.5 bg-emerald-500/20 rounded-xl border border-emerald-400/30 text-emerald-300">
                  <Send className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-base text-white">Send Form Link to Patient</h3>
                  <p className="text-xs text-stone-300">Share secure portal link via Email or SMS</p>
                </div>
              </div>

              <button
                onClick={() => { setSendFormModalItem(null); setIsSendFormsModalOpen(false); }}
                className="p-1.5 rounded-lg bg-stone-800 hover:bg-stone-700 text-stone-300 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-6 space-y-5 text-xs text-stone-800">
              {/* Selected Forms List Box */}
              <div className="p-3.5 bg-indigo-50/80 border border-indigo-200 rounded-xl space-y-2.5">
                <div className="flex items-center justify-between">
                  <label className="font-bold text-stone-900 text-xs flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 text-indigo-600" />
                    <span>Selected Forms ({selectedIntakeFormIds.length + selectedIntakePdfIds.length}):</span>
                  </label>
                  <button
                    type="button"
                    onClick={() => {
                      if (selectedIntakeFormIds.length === intakeFormsList.length) {
                        setSelectedIntakeFormIds([]);
                      } else {
                        setSelectedIntakeFormIds(intakeFormsList.map((f) => f.id));
                      }
                    }}
                    className="text-[11px] font-bold text-indigo-600 hover:text-indigo-800 cursor-pointer underline"
                  >
                    {selectedIntakeFormIds.length === intakeFormsList.length ? 'Deselect All' : 'Select All'}
                  </button>
                </div>

                <div className="space-y-1.5 max-h-48 overflow-y-auto pr-1">
                  {intakeFormsList
                    .filter((f) => selectedIntakeFormIds.includes(f.id))
                    .map((form) => (
                      <div key={form.id} className="p-2.5 bg-white border border-indigo-100 rounded-xl flex items-center justify-between gap-2 shadow-2xs">
                        <div className="flex items-center gap-2 min-w-0">
                          <FileText className="w-4 h-4 text-indigo-600 shrink-0" />
                          <div className="min-w-0">
                            <div className="font-bold text-stone-900 text-xs truncate">{form.title}</div>
                            <div className="text-[10.5px] text-stone-500 font-medium truncate">{form.fileName}</div>
                          </div>
                        </div>
                        <button
                          type="button"
                          onClick={() => setSelectedIntakeFormIds((prev) => prev.filter((id) => id !== form.id))}
                          className="p-1 hover:bg-stone-100 rounded-lg text-stone-400 hover:text-stone-600 cursor-pointer transition-colors"
                          title="Remove form from email"
                        >
                          <X className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    ))}

                  {intakePdfTemplates
                    .filter((pdf) => selectedIntakePdfIds.includes(pdf.id))
                    .map((pdf) => (
                      <div key={pdf.id} className="p-2.5 bg-white border border-violet-200 rounded-xl flex items-center justify-between gap-2 shadow-2xs">
                        <div className="flex items-center gap-2 min-w-0">
                          <FileText className="w-4 h-4 text-violet-600 shrink-0" />
                          <div className="min-w-0">
                            <div className="font-bold text-stone-900 text-xs truncate">{pdf.title}</div>
                            <div className="text-[10.5px] text-stone-500 font-medium truncate">PDF · {pdf.version} · {pdf.collectionStage}</div>
                          </div>
                        </div>
                        <button type="button" onClick={() => setSelectedIntakePdfIds((prev) => prev.filter((id) => id !== pdf.id))} className="p-1 hover:bg-stone-100 rounded-lg text-stone-400 hover:text-stone-600"><X className="w-3.5 h-3.5"/></button>
                      </div>
                    ))}

                  {selectedIntakeFormIds.length === 0 && selectedIntakePdfIds.length === 0 && (
                    <div className="p-4 text-center text-amber-800 bg-amber-50 rounded-xl border border-amber-200 font-medium text-xs">
                      No forms selected. Please check at least one form or click "Select All".
                    </div>
                  )}
                </div>
              </div>

              {/* Delivery Channel Selection */}
              <div className="space-y-2">
                <label className="font-bold text-stone-900 block">Select Delivery Method</label>
                <div className="grid grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => {
                      setSendChannel('email');
                      setSendRecipient(selectedPatient.email || `${selectedPatient.name.toLowerCase().replace(/[^a-z]/g, '')}@example.com`);
                    }}
                    className={`p-3 rounded-xl border text-left font-bold flex items-center gap-2 transition-all cursor-pointer ${
                      sendChannel === 'email'
                        ? 'bg-emerald-50 border-emerald-600 text-emerald-900 shadow-2xs'
                        : 'bg-stone-50 border-stone-200 text-stone-700 hover:bg-stone-100'
                    }`}
                  >
                    <Mail className={`w-4 h-4 ${sendChannel === 'email' ? 'text-emerald-600' : 'text-stone-400'}`} />
                    <span>Email Address</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setSendChannel('sms');
                      setSendRecipient(selectedPatient.phone || '(310) 555-0199');
                    }}
                    className={`p-3 rounded-xl border text-left font-bold flex items-center gap-2 transition-all cursor-pointer ${
                      sendChannel === 'sms'
                        ? 'bg-teal-50 border-teal-600 text-teal-900 shadow-2xs'
                        : 'bg-stone-50 border-stone-200 text-stone-700 hover:bg-stone-100'
                    }`}
                  >
                    <Smartphone className={`w-4 h-4 ${sendChannel === 'sms' ? 'text-teal-600' : 'text-stone-400'}`} />
                    <span>SMS Text Message</span>
                  </button>
                </div>
              </div>

              {/* Recipient Input */}
              <div className="space-y-1.5">
                <label className="font-bold text-stone-900 block">
                  {sendChannel === 'email' ? 'Patient Email Recipient' : 'Patient Mobile Phone Number'}
                </label>
                <input
                  type={sendChannel === 'email' ? 'email' : 'tel'}
                  value={sendRecipient}
                  onChange={(e) => setSendRecipient(e.target.value)}
                  placeholder={sendChannel === 'email' ? 'patient@example.com' : '(310) 555-0199'}
                  className="w-full p-3 bg-stone-50 border border-stone-300 rounded-xl font-medium text-stone-900 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              {/* Shareable Link Preview */}
              <div className="space-y-1">
                <label className="font-bold text-stone-700 text-[11px] block">Generated Portal Link</label>
                <div className="p-2.5 bg-stone-100 border border-stone-200 rounded-xl font-mono text-[10.5px] text-stone-600 break-all flex items-center justify-between gap-2">
                  <span className="truncate">
                    /patient-portal/intake?forms={[...selectedIntakeFormIds, ...selectedIntakePdfIds].join(',')}&patient={selectedPatient.patientId}
                  </span>
                  <button
                    type="button"
                    onClick={() => navigator.clipboard.writeText(`/patient-portal/intake?forms=${[...selectedIntakeFormIds, ...selectedIntakePdfIds].join(',')}&patient=${selectedPatient.patientId}`)}
                    className="px-2 py-1 bg-white hover:bg-stone-200 border border-stone-300 text-stone-800 font-bold text-[10px] rounded shrink-0 cursor-pointer"
                  >
                    Copy
                  </button>
                </div>
              </div>
            </div>

            {/* Modal Actions */}
            <div className="p-4 bg-stone-50 border-t border-stone-200 flex items-center justify-end gap-3">
              <button
                type="button"
                onClick={() => { setSendFormModalItem(null); setIsSendFormsModalOpen(false); }}
                className="px-4 py-2 bg-white hover:bg-stone-100 text-stone-700 font-bold rounded-xl border border-stone-300 text-xs transition-colors cursor-pointer"
              >
                Cancel
              </button>

              <button
                type="button"
                disabled={selectedIntakeFormIds.length + selectedIntakePdfIds.length === 0}
                onClick={() => {
                  const newStatus = sendChannel === 'email' ? 'Sent via Email' : 'Sent via SMS';
                  const dateStr = new Date().toLocaleDateString('en-US', { month: 'short', day: '2-digit', year: 'numeric' });
                  const selectedForms = intakeFormsList.filter((f) => selectedIntakeFormIds.includes(f.id));
                  setIntakeFormsList((prev) =>
                    prev.map((f) => (selectedIntakeFormIds.includes(f.id) ? { ...f, status: newStatus, lastSentDate: dateStr } : f))
                  );
                  const pdfNames = intakePdfTemplates.filter((pdf) => selectedIntakePdfIds.includes(pdf.id)).map((pdf) => pdf.title);
                  const namesList = [...selectedForms.map((f) => f.title), ...pdfNames].join(', ');
                  setPreOpEmailSuccessToast(
                    `Secure portal link for "${namesList || 'Selected Forms'}" sent via ${sendChannel.toUpperCase()} to ${sendRecipient || 'patient'}!`
                  );
                  setSendFormModalItem(null); setIsSendFormsModalOpen(false);
                }}
                className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 disabled:bg-stone-300 disabled:cursor-not-allowed text-white font-bold rounded-xl text-xs shadow-md transition-colors cursor-pointer flex items-center gap-1.5"
              >
                <Send className="w-3.5 h-3.5" />
                <span>Send {sendChannel === 'email' ? 'Email' : 'SMS'} Link ({selectedIntakeFormIds.length + selectedIntakePdfIds.length})</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 3. Patient Portal Form Completion Simulation Modal */}
      {portalHtmlForm && (
        <div className="fixed inset-0 z-[99999] bg-stone-100 flex flex-col w-screen h-screen overflow-hidden animate-in fade-in duration-150">
          <MinimalWorkflowHeader
            title={`Patient Intake · ${portalHtmlForm.title}`}
            onClose={() => setPortalHtmlForm(null)}
          />
          <div className="bg-white border-b border-stone-200 px-5 py-3 flex items-center justify-between gap-4">
            <div className="text-xs font-bold text-stone-700">Form {portalTestIndex + 1} of {Math.max(1, selectedIntakeFormIds.length)} · {Math.round(((portalTestIndex)/Math.max(1,selectedIntakeFormIds.length))*100)}% completed</div>
            <div className="h-2 flex-1 max-w-md rounded-full bg-stone-200 overflow-hidden"><div className="h-full bg-emerald-600" style={{width:`${((portalTestIndex)/Math.max(1,selectedIntakeFormIds.length))*100}%`}} /></div>
          </div>
          <div className="w-full flex-1 overflow-y-auto overflow-x-auto bg-stone-200/60 px-3 sm:px-6 py-5">
            <div className="w-full max-w-[980px] mx-auto bg-white shadow-md border border-stone-300 p-5 sm:p-8 relative">
              <IsolatedHtmlFormRenderer html={getPrefilledIntakeHtml(portalHtmlForm.htmlTemplate, selectedPatient)} />
            </div>
          </div>
          <div className="bg-white border-t border-stone-200 px-5 py-3 flex items-center justify-between">
            <span className="text-xs text-stone-500">Your answers are saved in this browser for testing. Known patient and encounter information is prepopulated.</span>
            <button type="button" onClick={() => {
              const ids = selectedIntakeFormIds.length ? selectedIntakeFormIds : intakeFormsList.map(f=>f.id);
              const nextIndex = portalTestIndex + 1;
              if (nextIndex < ids.length) { const nextForm = intakeFormsList.find(f=>f.id===ids[nextIndex]); if(nextForm){setPortalTestIndex(nextIndex);setPortalHtmlForm(nextForm);} }
              else { setPortalHtmlForm(null); showToast('At-Home Intake test complete. All selected forms were reviewed.'); }
            }} className="px-5 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-black">
              {portalTestIndex + 1 < Math.max(1, selectedIntakeFormIds.length) ? 'Save & Continue →' : 'Complete Intake ✓'}
            </button>
          </div>
        </div>
      )}

      {/* 3.5 Note Form Viewer Modal (Blank page with ONLY a close button, NO iframe) */}
      {viewingNoteForm && (
        <div className="fixed inset-0 z-[99999] bg-stone-100 flex flex-col w-screen h-screen overflow-hidden animate-in fade-in duration-150">
          <MinimalWorkflowHeader
            title={viewingNoteForm.title}
            onClose={() => setViewingNoteForm(null)}
          />

          {/* Blank Page Native Form Container */}
          <div className="w-full flex-1 overflow-y-auto overflow-x-auto bg-stone-200/60 px-3 sm:px-6 py-5">
            <div className="w-full max-w-[980px] mx-auto bg-white shadow-md border border-stone-300 p-5 sm:p-8 relative">
              <IsolatedHtmlFormRenderer html={viewingNoteForm.htmlTemplate} />
            </div>
          </div>
        </div>
      )}

      {/* 3.6 & 3.7 Nursing Form View / Open (Blank page with ONLY a close button, NO iframe) */}
      {(editingNursingForm || viewingFullNursingForm) && (
        <div className="fixed inset-0 z-[99999] bg-stone-100 flex flex-col w-screen h-screen overflow-hidden animate-in fade-in duration-150">
          <MinimalWorkflowHeader
            title={(editingNursingForm || viewingFullNursingForm)!.title}
            onClose={() => {
              setEditingNursingForm(null);
              setViewingFullNursingForm(null);
            }}
          />

          {/* Blank Page Native Form Container */}
          <div className="w-full flex-1 overflow-y-auto overflow-x-auto bg-stone-200/60 px-3 sm:px-6 py-5">
            <div className="w-full max-w-[980px] mx-auto bg-white shadow-md border border-stone-300 p-5 sm:p-8 relative">
              <IsolatedHtmlFormRenderer html={(editingNursingForm || viewingFullNursingForm)!.htmlTemplate} />
            </div>
          </div>
        </div>
      )}

      {/* Cross-role case record command center */}
      {isCaseRecordOpen && (
        <CaseRecordCommandCenter
          patient={selectedPatient}
          onClose={() => setIsCaseRecordOpen(false)}
          onOpenWorkflow={(role) => {
            setIsCaseRecordOpen(false);
            setActiveClinicalWorkflowRole(role);
          }}
          onAdvanceGate={(toStatus, reason, unresolvedItems) => onAdvanceEncounter?.(selectedPatient.id, toStatus, reason, unresolvedItems)}
          activePracticeId={activePracticeId}
        />
      )}

      {/* Legacy form-based Front Office check-in removed; all check-in entry points use the unified V3 Nursing workspace. */}

      {/* Clinical Workflow Full Page — Nursing / Anesthesia / Surgeons */}
      {activeClinicalWorkflowRole && (
        <ClinicalWorkflowPage
          role={activeClinicalWorkflowRole}
          patient={selectedPatient}
          nursingForms={nursingFormsList}
          intakeForms={intakeFormsList}
          onClose={() => setActiveClinicalWorkflowRole(null)}
          onAdvanceGate={(toStatus, reason, unresolvedItems) => onAdvanceEncounter?.(selectedPatient.id, toStatus, reason, unresolvedItems)}
          localPracticeForms={localPracticeForms}
          activePracticeId={activePracticeId}
          assignedHtmlForms={activeClinicalWorkflowRole === 'Nursing'
            ? workflowHtmlByKey.nursing
            : activeClinicalWorkflowRole === 'Anesthesia'
            ? workflowHtmlByKey.anesthesia
            : [...workflowHtmlByKey.surgeon, ...workflowHtmlByKey.orTeam]}
          assignedPdfForms={activeClinicalWorkflowRole === 'Nursing'
            ? workflowPdfByKey.nursing
            : activeClinicalWorkflowRole === 'Anesthesia'
            ? workflowPdfByKey.anesthesia
            : [...workflowPdfByKey.surgeon, ...workflowPdfByKey.orTeam]}
        />
      )}

      {/* BLANK PATIENT INVOICE TEMPLATE MODAL */}
      {isBlankInvoiceModalOpen && (
        <div className="fixed inset-0 z-[120] bg-slate-950/80 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto animate-in fade-in duration-200">
          <div className="bg-white rounded-3xl max-w-3xl w-full p-6 sm:p-8 shadow-2xl border border-stone-300 space-y-6 my-8">
            
            {/* Modal Header Actions */}
            <div className="flex items-center justify-between border-b border-stone-200 pb-4">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-indigo-50 text-indigo-600 rounded-xl border border-indigo-200">
                  <FileText className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-base text-stone-900">Blank Patient Invoice & Financial Statement</h3>
                  <p className="text-xs text-stone-500 font-medium">Standard Itemized Medical Invoice Form</p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => window.print()}
                  className="px-3 py-1.5 bg-stone-100 hover:bg-stone-200 text-stone-800 font-bold text-xs rounded-xl border border-stone-300 flex items-center gap-1.5 cursor-pointer transition-colors"
                >
                  <Printer className="w-4 h-4" />
                  <span>Print Blank Template</span>
                </button>
                <button
                  onClick={() => setIsBlankInvoiceModalOpen(false)}
                  className="p-1.5 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-600 cursor-pointer transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Editable Blank Invoice Printable Canvas */}
            <div className="p-6 bg-white border-2 border-stone-200 rounded-2xl shadow-2xs font-sans space-y-6 text-stone-900">
              
              {/* Header Letterhead */}
              <div className="flex flex-wrap justify-between items-start border-b-2 border-stone-900 pb-6 gap-4">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <Building2 className="w-6 h-6 text-indigo-700" />
                    <span className="font-black text-xl tracking-tight text-stone-900 uppercase">the practice LLC</span>
                  </div>
                  <div className="text-xs text-stone-600 font-medium leading-relaxed">
                    1000 Practice Way, Suite 500<br />
                    Los Angeles, CA 90024<br />
                    Phone: (310) 858-3000 · Tax ID: 95-4819201 · NPI: 1982736450
                  </div>
                </div>

                <div className="text-right space-y-1">
                  <div className="font-black text-lg text-indigo-950 tracking-wider">ITEMIZED INVOICE STATEMENT</div>
                  <div className="font-mono text-xs font-bold text-stone-700">
                    Invoice #: <input
                      type="text"
                      value={blankInvoiceData.invoiceNumber}
                      onChange={(e) => setBlankInvoiceData({ ...blankInvoiceData, invoiceNumber: e.target.value })}
                      className="border-b border-dashed border-stone-400 text-indigo-600 font-bold focus:outline-none w-32 px-1"
                    />
                  </div>
                  <div className="font-mono text-xs text-stone-600">
                    Invoice Date: <input
                      type="date"
                      value={blankInvoiceData.invoiceDate}
                      onChange={(e) => setBlankInvoiceData({ ...blankInvoiceData, invoiceDate: e.target.value })}
                      className="border-b border-dashed border-stone-400 focus:outline-none px-1"
                    />
                  </div>
                  <div className="font-mono text-xs text-stone-600">
                    Due Date: <input
                      type="date"
                      value={blankInvoiceData.dueDate}
                      onChange={(e) => setBlankInvoiceData({ ...blankInvoiceData, dueDate: e.target.value })}
                      className="border-b border-dashed border-stone-400 focus:outline-none px-1"
                    />
                  </div>
                </div>
              </div>

              {/* Patient & Guarantor Inputs */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                <div className="p-3.5 bg-stone-50 rounded-xl border border-stone-200 space-y-2">
                  <div className="font-bold text-stone-400 text-[10px] uppercase tracking-wider">Patient Information</div>
                  <input
                    type="text"
                    placeholder="Patient Full Name..."
                    value={blankInvoiceData.patientName}
                    onChange={(e) => setBlankInvoiceData({ ...blankInvoiceData, patientName: e.target.value })}
                    className="w-full p-2 bg-white border border-stone-300 rounded-lg font-bold text-stone-900"
                  />
                  <div className="grid grid-cols-2 gap-2">
                    <input
                      type="text"
                      placeholder="Patient ID (e.g. p-101)..."
                      value={blankInvoiceData.patientId}
                      onChange={(e) => setBlankInvoiceData({ ...blankInvoiceData, patientId: e.target.value })}
                      className="p-1.5 bg-white border border-stone-300 rounded-lg font-mono"
                    />
                    <input
                      type="text"
                      placeholder="DOB (MM/DD/YYYY)..."
                      value={blankInvoiceData.dob}
                      onChange={(e) => setBlankInvoiceData({ ...blankInvoiceData, dob: e.target.value })}
                      className="p-1.5 bg-white border border-stone-300 rounded-lg font-mono"
                    />
                  </div>
                </div>

                <div className="p-3.5 bg-stone-50 rounded-xl border border-stone-200 space-y-2">
                  <div className="font-bold text-stone-400 text-[10px] uppercase tracking-wider">Responsible Guarantor</div>
                  <input
                    type="text"
                    placeholder="Guarantor Name (Self / Parent)..."
                    value={blankInvoiceData.guarantor}
                    onChange={(e) => setBlankInvoiceData({ ...blankInvoiceData, guarantor: e.target.value })}
                    className="w-full p-2 bg-white border border-stone-300 rounded-lg font-bold text-stone-900"
                  />
                  <div className="flex items-center gap-2">
                    <span className="font-medium text-stone-600">DOS:</span>
                    <input
                      type="date"
                      value={blankInvoiceData.dos}
                      onChange={(e) => setBlankInvoiceData({ ...blankInvoiceData, dos: e.target.value })}
                      className="p-1.5 bg-white border border-stone-300 rounded-lg font-mono text-stone-900"
                    />
                  </div>
                </div>
              </div>

              {/* Procedure & Clinical Banner */}
              <div className="p-3 bg-stone-50 rounded-xl border border-stone-200 text-xs grid grid-cols-1 md:grid-cols-3 gap-2">
                <div>
                  <label className="font-bold text-stone-600 text-[10px] block uppercase">Procedure</label>
                  <input
                    type="text"
                    placeholder="Surgical Procedure Description..."
                    value={blankInvoiceData.procedure}
                    onChange={(e) => setBlankInvoiceData({ ...blankInvoiceData, procedure: e.target.value })}
                    className="w-full p-1.5 bg-white border border-stone-300 rounded-lg font-medium"
                  />
                </div>
                <div>
                  <label className="font-bold text-stone-600 text-[10px] block uppercase">Surgeon</label>
                  <input
                    type="text"
                    value={blankInvoiceData.surgeon}
                    onChange={(e) => setBlankInvoiceData({ ...blankInvoiceData, surgeon: e.target.value })}
                    className="w-full p-1.5 bg-white border border-stone-300 rounded-lg font-medium"
                  />
                </div>
                <div>
                  <label className="font-bold text-stone-600 text-[10px] block uppercase">Anesthesiologist</label>
                  <input
                    type="text"
                    value={blankInvoiceData.anesthesiologist}
                    onChange={(e) => setBlankInvoiceData({ ...blankInvoiceData, anesthesiologist: e.target.value })}
                    className="w-full p-1.5 bg-white border border-stone-300 rounded-lg font-medium"
                  />
                </div>
              </div>

              {/* Itemized Services Grid */}
              <div className="space-y-2">
                <div className="font-bold text-xs text-stone-900 uppercase tracking-wider">Itemized Medical Charges ($)</div>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3 text-xs">
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-stone-600 uppercase">Facility Fee ($)</label>
                    <input
                      type="number"
                      value={blankInvoiceData.facilityFee}
                      onChange={(e) => setBlankInvoiceData({ ...blankInvoiceData, facilityFee: parseFloat(e.target.value) || 0 })}
                      className="w-full p-2 bg-stone-50 border border-stone-300 rounded-lg font-mono font-bold text-stone-900"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-stone-600 uppercase">Surgeon Fee ($)</label>
                    <input
                      type="number"
                      value={blankInvoiceData.surgeonFee}
                      onChange={(e) => setBlankInvoiceData({ ...blankInvoiceData, surgeonFee: parseFloat(e.target.value) || 0 })}
                      className="w-full p-2 bg-stone-50 border border-stone-300 rounded-lg font-mono font-bold text-stone-900"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-stone-600 uppercase">Anesthesia Fee ($)</label>
                    <input
                      type="number"
                      value={blankInvoiceData.anesthesiaFee}
                      onChange={(e) => setBlankInvoiceData({ ...blankInvoiceData, anesthesiaFee: parseFloat(e.target.value) || 0 })}
                      className="w-full p-2 bg-stone-50 border border-stone-300 rounded-lg font-mono font-bold text-stone-900"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-stone-600 uppercase">Implants & Supplies ($)</label>
                    <input
                      type="number"
                      value={blankInvoiceData.implantCharges}
                      onChange={(e) => setBlankInvoiceData({ ...blankInvoiceData, implantCharges: parseFloat(e.target.value) || 0 })}
                      className="w-full p-2 bg-stone-50 border border-stone-300 rounded-lg font-mono font-bold text-stone-900"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-emerald-700 uppercase">Prompt Discount ($)</label>
                    <input
                      type="number"
                      value={blankInvoiceData.discounts}
                      onChange={(e) => setBlankInvoiceData({ ...blankInvoiceData, discounts: parseFloat(e.target.value) || 0 })}
                      className="w-full p-2 bg-emerald-50 border border-emerald-300 rounded-lg font-mono font-bold text-emerald-800"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-emerald-800 uppercase">Payments Received ($)</label>
                    <input
                      type="number"
                      value={blankInvoiceData.paymentsReceived}
                      onChange={(e) => setBlankInvoiceData({ ...blankInvoiceData, paymentsReceived: parseFloat(e.target.value) || 0 })}
                      className="w-full p-2 bg-emerald-50 border border-emerald-300 rounded-lg font-mono font-bold text-emerald-900"
                    />
                  </div>
                </div>
              </div>

              {/* Total Calculation */}
              <div className="flex justify-end pt-2">
                <div className="w-full md:w-80 bg-stone-900 text-white p-4 rounded-xl border border-stone-800 text-xs space-y-2 font-mono">
                  <div className="flex justify-between">
                    <span className="text-stone-400 font-sans">Gross Charges:</span>
                    <span className="font-bold">${(blankInvoiceData.facilityFee + blankInvoiceData.surgeonFee + blankInvoiceData.anesthesiaFee + blankInvoiceData.implantCharges).toLocaleString()}</span>
                  </div>
                  {blankInvoiceData.discounts > 0 && (
                    <div className="flex justify-between text-emerald-400">
                      <span className="font-sans">Prompt Discount:</span>
                      <span>-${blankInvoiceData.discounts.toLocaleString()}</span>
                    </div>
                  )}
                  {blankInvoiceData.paymentsReceived > 0 && (
                    <div className="flex justify-between text-sky-400">
                      <span className="font-sans">Payments Received:</span>
                      <span>-${blankInvoiceData.paymentsReceived.toLocaleString()}</span>
                    </div>
                  )}
                  <div className="flex justify-between pt-2 border-t border-slate-700 text-base font-black text-emerald-400">
                    <span className="font-sans">NET BALANCE DUE:</span>
                    <span>${Math.max(0, (blankInvoiceData.facilityFee + blankInvoiceData.surgeonFee + blankInvoiceData.anesthesiaFee + blankInvoiceData.implantCharges) - blankInvoiceData.discounts - blankInvoiceData.paymentsReceived).toLocaleString()}</span>
                  </div>
                </div>
              </div>

            </div>

            {/* Bottom Actions */}
            <div className="flex justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setIsBlankInvoiceModalOpen(false)}
                className="px-4 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 font-bold text-xs rounded-xl transition-colors cursor-pointer"
              >
                Close
              </button>
              <button
                type="button"
                onClick={() => {
                  window.print();
                }}
                className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-xl shadow-md transition-colors cursor-pointer flex items-center gap-1.5"
              >
                <Printer className="w-4 h-4" />
                <span>Print Statement</span>
              </button>
            </div>

          </div>
        </div>
      )}


      {/* COLLECT / RECORD DEPOSIT OR ACCOUNT CREDIT */}
      {isCollectDepositModalOpen && (
        <div className="fixed inset-0 z-[130] bg-slate-950/80 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-stone-300 space-y-5">
            <div className="flex items-center justify-between border-b border-stone-200 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-emerald-50 text-emerald-700 rounded-xl border border-emerald-200"><CreditCard className="w-5 h-5" /></div>
                <div><h3 className="font-bold text-base text-stone-900">Collect / Record Payment</h3><p className="text-xs text-stone-500">Record a deposit or unapplied credit before an invoice exists.</p></div>
              </div>
              <button onClick={() => setIsCollectDepositModalOpen(false)} className="p-1.5 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-600"><X className="w-5 h-5" /></button>
            </div>
            <div className="p-3 bg-stone-50 rounded-xl border border-stone-200 text-xs"><strong>Patient:</strong> {selectedPatient.name} ({selectedPatient.patientId})<br/><strong>Current available credit:</strong> ${(patientCredits[selectedPatient.patientId] || 0).toLocaleString()}</div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <label className="font-bold text-stone-700">Amount ($)<input type="number" min="0" step="0.01" value={depositForm.amount} onChange={e=>setDepositForm({...depositForm, amount:Number(e.target.value)||0})} className="mt-1 w-full p-2.5 border border-stone-300 rounded-xl font-mono"/></label>
              <label className="font-bold text-stone-700">Payment Type<select value={depositForm.type} onChange={e=>setDepositForm({...depositForm,type:e.target.value})} className="mt-1 w-full p-2.5 border border-stone-300 rounded-xl bg-white"><option>Deposit / Account Credit</option><option>Payment toward existing balance</option><option>Refundable reservation deposit</option></select></label>
              <label className="font-bold text-stone-700">Method<select value={depositForm.method} onChange={e=>setDepositForm({...depositForm,method:e.target.value})} className="mt-1 w-full p-2.5 border border-stone-300 rounded-xl bg-white"><option>Credit Card</option><option>Debit Card</option><option>Cash</option><option>Check</option><option>ACH / Bank Transfer</option></select></label>
              <label className="font-bold text-stone-700">Reference / Transaction #<input value={depositForm.reference} onChange={e=>setDepositForm({...depositForm,reference:e.target.value})} className="mt-1 w-full p-2.5 border border-stone-300 rounded-xl" placeholder="Optional"/></label>
            </div>
            <label className="block text-xs font-bold text-stone-700">Notes<textarea value={depositForm.notes} onChange={e=>setDepositForm({...depositForm,notes:e.target.value})} className="mt-1 w-full p-2.5 border border-stone-300 rounded-xl" rows={2}/></label>
            <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-xs text-emerald-950">This payment is stored as an <strong>unapplied patient credit</strong>. When an invoice is later created, Vityls can apply the available credit before calculating the balance due.</div>
            <div className="flex justify-end gap-2">
              <button onClick={()=>setIsCollectDepositModalOpen(false)} className="px-4 py-2 bg-stone-100 text-stone-700 font-bold text-xs rounded-xl">Cancel</button>
              <button onClick={()=>{ if(depositForm.amount<=0){alert('Enter a payment amount.');return;} setPatientCredits(prev=>({...prev,[selectedPatient.patientId]:(prev[selectedPatient.patientId]||0)+depositForm.amount})); showToast(`Payment of $${depositForm.amount.toLocaleString()} recorded as account credit for ${selectedPatient.name}.`); setDepositForm({ amount:0, method:'Credit Card', type:'Deposit / Account Credit', reference:'', notes:''}); setIsCollectDepositModalOpen(false); }} className="px-5 py-2 bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs rounded-xl">Record Payment & Credit Account</button>
            </div>
          </div>
        </div>
      )}

      {/* CREATE NEW INVOICE MODAL (ENABLED WHEN PAYMENT NOT YET RECEIVED) */}
      {isCreateInvoiceModalOpen && (
        <div className="fixed inset-0 z-[120] bg-slate-950/80 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto animate-in fade-in duration-200">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-stone-300 space-y-5 my-8">
            <div className="flex items-center justify-between border-b border-stone-200 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-indigo-50 text-indigo-600 rounded-xl border border-indigo-200">
                  <Plus className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-base text-stone-900">Create New Patient Invoice</h3>
                  <p className="text-xs text-stone-500 font-medium">Issue itemized statement for outstanding surgical encounter</p>
                </div>
              </div>
              <button
                onClick={() => setIsCreateInvoiceModalOpen(false)}
                className="p-1.5 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-600 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form
              onSubmit={(e) => e.preventDefault()}
              className="space-y-4 text-xs"
            >
              <div className="p-3 bg-stone-50 rounded-xl border border-stone-200 space-y-1">
                <div><strong>Patient:</strong> {selectedPatient.name} ({selectedPatient.patientId})</div>
                <div><strong>Procedure:</strong> {selectedPatient.procedure}</div>
                <div><strong>Surgeon:</strong> {selectedPatient.surgeon}</div>
              </div>

              <div className="space-y-1">
                <label className="font-bold text-stone-700 block">Payment Source Classification *</label>
                <select
                  value={newInvoiceForm.source}
                  onChange={(e) => setNewInvoiceForm({ ...newInvoiceForm, source: e.target.value as any })}
                  className="w-full p-2.5 bg-stone-50 border border-stone-300 rounded-xl font-bold text-stone-900 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                >
                  <option value="self-pay">💳 Self-Pay (Patient Direct Cash)</option>
                  <option value="doctor-to-pay">🩺 Doctor to Pay (Professional Courtesy)</option>
                  <option value="insurance">🛡️ Insurance (Commercial PPO / Medicare)</option>
                  <option value="other">📋 Other (Lien / Workers' Comp)</option>
                </select>
              </div>

              <div className="p-3.5 bg-stone-50 rounded-2xl border border-stone-200 space-y-2">
                <div className="font-bold text-stone-900 border-b border-stone-200 pb-1">Itemized Financial Breakdown ($)</div>
                <div className="grid grid-cols-2 gap-2">
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-stone-600 uppercase">Facility Fee ($)</label>
                    <input
                      type="number"
                      value={newInvoiceForm.facilityFee}
                      onChange={(e) => setNewInvoiceForm({ ...newInvoiceForm, facilityFee: parseFloat(e.target.value) || 0 })}
                      className="w-full p-2 bg-white border border-stone-300 rounded-lg font-mono font-bold text-stone-900"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-stone-600 uppercase">Surgeon Fee ($)</label>
                    <input
                      type="number"
                      value={newInvoiceForm.surgeonFee}
                      onChange={(e) => setNewInvoiceForm({ ...newInvoiceForm, surgeonFee: parseFloat(e.target.value) || 0 })}
                      className="w-full p-2 bg-white border border-stone-300 rounded-lg font-mono font-bold text-stone-900"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-stone-600 uppercase">Anesthesia Fee ($)</label>
                    <input
                      type="number"
                      value={newInvoiceForm.anesthesiaFee}
                      onChange={(e) => setNewInvoiceForm({ ...newInvoiceForm, anesthesiaFee: parseFloat(e.target.value) || 0 })}
                      className="w-full p-2 bg-white border border-stone-300 rounded-lg font-mono font-bold text-stone-900"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-stone-600 uppercase">Implants & Supplies ($)</label>
                    <input
                      type="number"
                      value={newInvoiceForm.implantCharges}
                      onChange={(e) => setNewInvoiceForm({ ...newInvoiceForm, implantCharges: parseFloat(e.target.value) || 0 })}
                      className="w-full p-2 bg-white border border-stone-300 rounded-lg font-mono font-bold text-stone-900"
                    />
                  </div>
                </div>

                <div className="pt-2 border-t border-stone-200 flex justify-between items-center font-bold text-indigo-950">
                  <span>Calculated Invoice Total:</span>
                  <span className="font-mono text-sm font-black">${((newInvoiceForm.facilityFee + newInvoiceForm.surgeonFee + newInvoiceForm.anesthesiaFee + newInvoiceForm.implantCharges) - newInvoiceForm.discounts).toLocaleString()}</span>
                </div>
              </div>

              <div className="space-y-1">
                <label className="font-bold text-stone-700 block">Record Payment Received Now ($ optional)</label>
                <input
                  type="number"
                  placeholder="Leave 0 if payment is pending..."
                  value={newInvoiceForm.paymentReceivedAmount}
                  onChange={(e) => setNewInvoiceForm({ ...newInvoiceForm, paymentReceivedAmount: parseFloat(e.target.value) || 0 })}
                  className="w-full p-2.5 bg-stone-50 border border-stone-300 rounded-xl font-mono text-stone-900"
                />
              </div>

              <div className="space-y-1">
                <label className="font-bold text-stone-700 block">Billing Notes</label>
                <input
                  type="text"
                  placeholder="e.g. Pre-op payment arrangement confirmed..."
                  value={newInvoiceForm.notes}
                  onChange={(e) => setNewInvoiceForm({ ...newInvoiceForm, notes: e.target.value })}
                  className="w-full p-2.5 bg-stone-50 border border-stone-300 rounded-xl font-medium text-stone-900"
                />
              </div>

              <div className="pt-2 border-t border-stone-200 space-y-2">
                <div className="flex flex-wrap justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => setIsCreateInvoiceModalOpen(false)}
                    className="px-4 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 font-bold text-xs rounded-xl transition-colors cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      const totalCalculated = (newInvoiceForm.facilityFee + newInvoiceForm.surgeonFee + newInvoiceForm.anesthesiaFee + newInvoiceForm.implantCharges) - newInvoiceForm.discounts;
                      const availableCredit = patientCredits[selectedPatient.patientId] || 0;
                      const appliedCredit = Math.min(availableCredit, Math.max(0, totalCalculated - newInvoiceForm.paymentReceivedAmount));
                      const totalApplied = newInvoiceForm.paymentReceivedAmount + appliedCredit;
                      const isPaid = totalApplied >= totalCalculated;
                      if (appliedCredit > 0) setPatientCredits(prev => ({ ...prev, [selectedPatient.patientId]: Math.max(0, availableCredit - appliedCredit) }));
                      setPatientPayments(prev => ({ ...prev, [selectedPatient.patientId]: {
                        patientId: selectedPatient.patientId, source: newInvoiceForm.source, received: isPaid, amount: totalCalculated,
                        date: isPaid ? newInvoiceForm.paymentDate : '', method: isPaid ? 'Credit Card / Recorded Payment' : 'Draft Invoice',
                        notes: newInvoiceForm.notes || `Draft invoice saved for ${selectedPatient.name}. Applied credit: $${appliedCredit.toLocaleString()}. Remaining balance: $${Math.max(0,totalCalculated-totalApplied).toLocaleString()}.`,
                        invoiceNumber: `INV-2026-${Math.floor(100 + Math.random() * 900)}`,
                      }}));
                      setIsCreateInvoiceModalOpen(false);
                      showToast(`Draft invoice saved for ${selectedPatient.name}.`);
                    }}
                    className="px-5 py-2 bg-white hover:bg-stone-50 text-stone-800 border border-stone-300 font-bold text-xs rounded-xl transition-colors cursor-pointer flex items-center gap-1.5"
                  >
                    <Save className="w-4 h-4" />
                    <span>Save Draft</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setIsInvoiceSendConfirmOpen(true)}
                    className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-xl shadow-md transition-colors cursor-pointer flex items-center gap-1.5"
                  >
                    <Mail className="w-4 h-4" />
                    <span>Finalize & Send Invoice</span>
                  </button>
                </div>
                <p className="text-[10px] text-stone-500 text-right">Saving a draft does not contact the patient. Finalize & Send opens a delivery confirmation first.</p>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* FINALIZE & SEND INVOICE CONFIRMATION */}
      {isInvoiceSendConfirmOpen && (
        <div className="fixed inset-0 z-[140] bg-slate-950/80 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-stone-300 space-y-5">
            <div className="flex items-center justify-between border-b border-stone-200 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-indigo-50 text-indigo-700 rounded-xl border border-indigo-200"><Mail className="w-5 h-5" /></div>
                <div><h3 className="font-bold text-base text-stone-900">Finalize & Send Invoice</h3><p className="text-xs text-stone-500">Confirm recipient and delivery before sending.</p></div>
              </div>
              <button onClick={() => setIsInvoiceSendConfirmOpen(false)} className="p-1.5 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-600"><X className="w-5 h-5" /></button>
            </div>
            <div className="p-3 bg-stone-50 rounded-xl border border-stone-200 text-xs space-y-1">
              <div><strong>Patient:</strong> {selectedPatient.name}</div>
              <div><strong>Email:</strong> {selectedPatient.email || 'No email on file'}</div>
              <div><strong>Mobile:</strong> {selectedPatient.phone || 'No mobile number on file'}</div>
            </div>
            <label className="block text-xs font-bold text-stone-700">Delivery method
              <select value={invoiceDeliveryMethod} onChange={e => setInvoiceDeliveryMethod(e.target.value as any)} className="mt-1 w-full p-2.5 border border-stone-300 rounded-xl bg-white">
                <option>Email</option><option>SMS</option><option>Email + SMS</option>
              </select>
            </label>
            <div className="p-3 rounded-xl bg-indigo-50 border border-indigo-200 text-xs text-indigo-950">
              When the payment gateway is connected, the delivered invoice will include a secure <strong>View Invoice / Pay Online</strong> link. This frontend build records the send action but does not transmit email or SMS yet.
            </div>
            <div className="flex justify-end gap-2">
              <button onClick={() => setIsInvoiceSendConfirmOpen(false)} className="px-4 py-2 bg-stone-100 text-stone-700 font-bold text-xs rounded-xl">Back</button>
              <button onClick={() => {
                const totalCalculated = (newInvoiceForm.facilityFee + newInvoiceForm.surgeonFee + newInvoiceForm.anesthesiaFee + newInvoiceForm.implantCharges) - newInvoiceForm.discounts;
                const availableCredit = patientCredits[selectedPatient.patientId] || 0;
                const appliedCredit = Math.min(availableCredit, Math.max(0, totalCalculated - newInvoiceForm.paymentReceivedAmount));
                const totalApplied = newInvoiceForm.paymentReceivedAmount + appliedCredit;
                const isPaid = totalApplied >= totalCalculated;
                if (appliedCredit > 0) setPatientCredits(prev => ({ ...prev, [selectedPatient.patientId]: Math.max(0, availableCredit - appliedCredit) }));
                setPatientPayments(prev => ({ ...prev, [selectedPatient.patientId]: {
                  patientId: selectedPatient.patientId, source: newInvoiceForm.source, received: isPaid, amount: totalCalculated,
                  date: isPaid ? newInvoiceForm.paymentDate : '', method: isPaid ? 'Credit Card / Recorded Payment' : `Invoice sent by ${invoiceDeliveryMethod}`,
                  notes: newInvoiceForm.notes || `Invoice finalized and queued for ${invoiceDeliveryMethod}. Applied credit: $${appliedCredit.toLocaleString()}. Remaining balance: $${Math.max(0,totalCalculated-totalApplied).toLocaleString()}.`,
                  invoiceNumber: `INV-2026-${Math.floor(100 + Math.random() * 900)}`,
                }}));
                setIsInvoiceSendConfirmOpen(false);
                setIsCreateInvoiceModalOpen(false);
                showToast(`Invoice finalized and queued for ${invoiceDeliveryMethod} to ${selectedPatient.name}.`);
              }} className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-xl flex items-center gap-1.5">
                <Send className="w-4 h-4" /><span>Confirm & Send</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Deletion Confirmation Modal */}
      {deleteConfirmation && (
        <div className="fixed inset-0 bg-stone-900/80 backdrop-blur-xs flex items-center justify-center z-[100002] p-4 animate-in fade-in duration-150">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 border border-stone-200 shadow-2xl space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-rose-100 border border-rose-200 text-rose-600 flex items-center justify-center shrink-0">
                <Trash2 className="w-5 h-5 text-rose-600" />
              </div>
              <div>
                <h3 className="text-base font-extrabold text-stone-900">
                  Confirm {deleteConfirmation.type} Deletion
                </h3>
                <p className="text-xs text-stone-500 font-medium">
                  Please confirm before deleting this record.
                </p>
              </div>
            </div>

            <div className="p-3.5 bg-rose-50/80 border border-rose-200/90 rounded-xl space-y-1.5 text-xs text-stone-800">
              <div className="font-extrabold text-rose-950 flex items-center justify-between">
                <span>{deleteConfirmation.type} Name:</span>
                <span className="text-stone-900 font-bold truncate max-w-[200px]">{deleteConfirmation.name}</span>
              </div>
              {deleteConfirmation.details && (
                <div className="text-[11px] text-stone-600 pt-1 border-t border-rose-200/60 font-medium">
                  {deleteConfirmation.details}
                </div>
              )}
            </div>

            <p className="text-xs text-stone-500 leading-relaxed font-medium">
              ⚠️ <strong>Warning:</strong> Deleting this {deleteConfirmation.type.toLowerCase()} will permanently remove it from {selectedPatient.name}'s chart. This action cannot be undone.
            </p>

            <div className="pt-2 flex items-center justify-end gap-2.5">
              <button
                type="button"
                onClick={() => setDeleteConfirmation(null)}
                className="px-4 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 font-bold text-xs rounded-xl border border-stone-200 transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => {
                  deleteConfirmation.action();
                  setDeleteConfirmation(null);
                }}
                className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs rounded-xl shadow-md transition-colors flex items-center gap-1.5 cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Confirm Delete {deleteConfirmation.type}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Patient Chart Print Modal */}
      {printModalOption && (
        <PatientChartPrintModal
          isOpen={Boolean(printModalOption)}
          initialOption={printModalOption}
          patient={selectedPatient}
          onClose={() => setPrintModalOption(null)}
          onShowToast={showToast}
          dos="05/06/2026"
          auditTrail={[
            ...intakeFormsList.map((f): AuditTrailItem => ({
              title: f.title,
              category: `Intake · ${f.category}`,
              status: f.status,
              date: f.completedDate || f.lastSentDate,
            })),
            ...nursingFormsList.map((f): AuditTrailItem => ({
              title: f.title,
              category: `Clinical · ${f.category}`,
              status: f.status,
            })),
            ...docList.map((d): AuditTrailItem => ({
              title: d.title,
              category: d.type,
              status: d.status,
              date: d.submissionDate,
            })),
          ]}
        />
      )}

      {/* Full patient edit uses the same demographic model and fields as Add New Patient. */}
      <AddPatientModal
        isOpen={isEditContactOpen}
        onClose={() => setIsEditContactOpen(false)}
        onAddPatient={() => {}}
        initialPatient={{
          ...selectedPatient,
          phone: currentContactInfo.phone,
          email: currentContactInfo.email,
          address: currentContactInfo.address,
        }}
        onSavePatient={(updated) => {
          setSelectedPatient(updated);
          setContactOverrides((prev) => ({
            ...prev,
            [updated.patientId]: { phone: updated.phone, email: updated.email, address: updated.address },
          }));
          onUpdatePatient?.(updated);
          showToast(`Patient record updated for ${updated.name}`);
        }}
      />

      {activeIntakePdf && (
        <PdfTemplateInteractiveViewer
          patientId={selectedPatient.id}
          patientName={selectedPatient.name}
          template={activeIntakePdf}
          onClose={() => setActiveIntakePdf(null)}
        />
      )}
</div>
  );
};
