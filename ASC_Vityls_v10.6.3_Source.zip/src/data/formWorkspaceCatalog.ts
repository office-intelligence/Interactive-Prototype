import { isMed, isAscEd } from '../edition';
import { ASC_FORMS, ASC_WORKFLOWS, isCredentialing } from '../surgery/asc8/formSet';
import { GENERATED_REFERENCE_FORMS } from './generatedReferenceForms';
import { STATION_PLAN } from '../v6/formRules';
export type WorkflowKey = 'patientPortal' | 'frontOffice' | 'nursing' | 'anesthesia' | 'surgeon' | 'orTeam' | 'pacu';
export type WorkflowMap = Record<WorkflowKey, { enabled: boolean }>;
export type FormCatalogItem = { title: string; file: string; category: string; audience: string; stage: string };

const ASC_FORM_WORKFLOWS: { key: WorkflowKey; label: string; note: string }[] = [
  { key:'patientPortal', label:'Patient Portal', note:'Forms patients complete or review before or after the visit.' },
  { key:'frontOffice', label:'Front Office', note:'Registration, demographics, insurance, check-in and administrative forms.' },
  { key:'nursing', label:'Nursing', note:'Pre-op, intra-op, recovery and nursing documentation.' },
  { key:'anesthesia', label:'Anesthesia', note:'Anesthesia questionnaires, evaluations, consents and records.' },
  { key:'surgeon', label:'Surgeon / Physician', note:'Provider clearances, orders, consents and operative documentation.' },
  { key:'orTeam', label:'OR Team', note:'Time-out, safety checklist and intra-operative workflow.' },
  { key:'pacu', label:'PACU / Discharge', note:'Recovery, discharge orders and instructions.' },
];
/** MED v0.1: office visit steps reuse the station keys (patientPortal, frontOffice, nursing, surgeon); OR-only keys are hidden. */
const MED_FORM_WORKFLOWS: { key: WorkflowKey; label: string; note: string }[] = [
  { key:'patientPortal', label:'Patient Portal (pre-visit)', note:'Forms patients complete before the visit.' },
  { key:'frontOffice', label:'Check-in', note:'Registration, demographics, insurance, photo consent and payment forms.' },
  { key:'nursing', label:'Rooming / vitals', note:'Medical history review, vitals and intake.' },
  { key:'surgeon', label:'Provider visit', note:'Procedure consents and provider documentation.' },
];
export const FORM_WORKFLOWS = isAscEd ? ASC_WORKFLOWS : isMed ? MED_FORM_WORKFLOWS : ASC_FORM_WORKFLOWS;


const BASE_VITYLS_FORM_CATALOG: FormCatalogItem[] = [
  { title:'Patient Registration', file:'Patient_Registration.html', category:'Intake', audience:'Patient / Front Desk', stage:'Registration' },
  { title:'Admission Form', file:'Admission_Form.html', category:'Intake', audience:'Patient / Front Desk', stage:'Pre-arrival' },
  { title:'AMA / Refusal Form', file:'AMA_Refusal_Form.html', category:'Consent', audience:'Patient / Clinical', stage:'Encounter' },
  { title:'Anesthesia Consent', file:'Anesthesia_Consent.html', category:'Anesthesia', audience:'Patient / Anesthesiologist', stage:'Pre-op' },
  { title:'Anesthesia Evaluation', file:'Anesthesia_Evaluation.html', category:'Anesthesia', audience:'Anesthesiologist', stage:'Pre-op' },
  { title:'Anesthesia Intra-Op Record', file:'Anesthesia_IntraOp_Record.html', category:'Anesthesia', audience:'Anesthesiologist', stage:'Intra-op' },
  { title:'Anesthesia Questionnaire', file:'Anesthesia_Questionnaire.html', category:'Anesthesia', audience:'Patient', stage:'Pre-arrival' },
  { title:'Cash Payment Fee Disclosure', file:'Billing_Fee_Disclosure.html', category:'Financial', audience:'Patient', stage:'Pre-arrival' },
  { title:'Credit Card Authorization', file:'Credit_Card_Authorization.html', category:'Financial', audience:'Patient', stage:'Pre-arrival' },
  { title:'Day-of Interval H&P Update', file:'DayOf_Interval_HP_Update.html', category:'Clinical', audience:'Surgeon', stage:'Day of surgery' },
  { title:'Emergency Transfer Form', file:'Emergency_Transfer_Form.html', category:'Clinical', audience:'Clinical Staff', stage:'Encounter' },
  { title:'Insurance Information', file:'Insurance_Information.html', category:'Intake', audience:'Patient / Front Desk', stage:'Pre-arrival' },
  { title:'Intra-Op Nursing Record & Time Out', file:'IntraOp_Nursing_Record_TO.html', category:'Nursing', audience:'OR Nurse', stage:'Intra-op' },
  { title:'Medical History', file:'Medical_History.html', category:'Clinical', audience:'Patient', stage:'Pre-arrival' },
  { title:'MH & VTE Assessment', file:'MH_and_VTE_Assessment.html', category:'Clinical', audience:'Patient / Nursing', stage:'Pre-op' },
  { title:'Nursing Admission', file:'Nursing_Admission.html', category:'Nursing', audience:'Pre-op Nurse', stage:'Pre-op' },
  { title:'PACU Recovery Record', file:'PACU_Recovery_Record.html', category:'Nursing', audience:'PACU Nurse', stage:'PACU' },
  { title:'Patient Satisfaction Survey', file:'Patient_Satisfaction_Survey.html', category:'Follow-up', audience:'Patient', stage:'Post-discharge' },
  { title:'Photography / Media / Research Consent', file:'Photography_Media_Research_Consent.html', category:'Consent', audience:'Patient', stage:'Pre-arrival' },
  { title:'Physician Discharge Order', file:'Physician_Discharge_Order.html', category:'Clinical', audience:'Physician', stage:'Discharge' },
  { title:'Post-Op Discharge', file:'PostOp_Discharge.html', category:'Discharge', audience:'Nursing / Patient', stage:'Discharge' },
  { title:'Pre-Op H&P Clearance', file:'PreOp_HP_Clearance.html', category:'Clinical', audience:'Physician', stage:'Pre-op' },
  { title:'Procedure Consent', file:'Procedure_Consent.html', category:'Consent', audience:'Patient / Surgeon', stage:'Pre-op' },
  { title:'Surgeon Operative Report', file:'Surgeon_Operative_Report.html', category:'Clinical', audience:'Surgeon', stage:'Post-op' },
  { title:'Surgeon Pre-Op Clearance', file:'Surgeon_PreOp_Clearance.html', category:'Clinical', audience:'Surgeon', stage:'Pre-op' },
  { title:'Universal Protocol Safety Checklist', file:'Universal_Protocol_Safety_Checklist.html', category:'Safety', audience:'OR Team', stage:'Intra-op' },
  { title:'Written Discharge Instructions', file:'Written_Discharge_Instructions.html', category:'Discharge', audience:'Patient / Nursing', stage:'Discharge' },
  { title:'Surgeon Membership & Privileges Application', file:'Surgeon_Membership_Application.html', category:'Credentialing', audience:'Surgeon / Provider', stage:'Provider onboarding' },
  { title:'Anesthesia Orders', file:'Anesthesia_Order_Form.html', category:'Anesthesia', audience:'Anesthesiologist / Nursing', stage:'Pre-op' },
  { title:'PACU Doctor Orders', file:'PACU_Doctor_Orders.html', category:'Clinical', audience:'Physician / PACU', stage:'PACU' },
  { title:'Surgeon Orders', file:'Surgeon_Orders.html', category:'Clinical', audience:'Surgeon / Nursing', stage:'Pre-op' },
  { title:'Blank Custom Form', file:'Blank_Custom_Form.html', category:'Custom', audience:'Practice-defined', stage:'Practice-defined' },
];

// Every HTML file placed in public/forms is discovered at dev/build time. Existing
// curated metadata wins; newly added files appear automatically as Practice-defined
// templates and can be customized/assigned in Form Studio without code changes.
const knownFiles = new Set(BASE_VITYLS_FORM_CATALOG.map(item => item.file));
const ALL_VITYLS_FORM_CATALOG: FormCatalogItem[] = [
  ...BASE_VITYLS_FORM_CATALOG,
  ...GENERATED_REFERENCE_FORMS
    .filter(item => !knownFiles.has(item.file))
    .map(item => ({
      title: item.title, file: item.file, category: 'Custom',
      audience: 'Practice-defined', stage: 'Practice-defined'
    })),
];

/** MED v0.1: forms that make sense in a physician office. ASC-only forms (anesthesia, OR, PACU, admission, pre-op clearance) are hidden in MED. */
export const MED_FORM_FILES = new Set(['Patient_Registration.html', 'Insurance_Information.html', 'Medical_History.html', 'Photography_Media_Research_Consent.html', 'Credit_Card_Authorization.html', 'Procedure_Consent.html', 'Billing_Fee_Disclosure.html', 'Patient_Satisfaction_Survey.html', 'Blank_Custom_Form.html', 'AMA_Refusal_Form.html']);
/** ASC.Vityls v8.0/8.1: the ASC edition's 26 templates (v8.1 restored 3 order sheets) (merged ones have their own file) + the builder's Blank Custom Form. */
const ASC2_CATALOG: FormCatalogItem[] = [...ASC_FORMS.map(f => ({ title: f.title, file: f.file, category: f.category, audience: f.audience, stage: f.step })), { title: 'Blank Custom Form', file: 'Blank_Custom_Form.html', category: 'Custom', audience: 'Practice-defined', stage: 'Practice-defined' }];
export const VITYLS_FORM_CATALOG: FormCatalogItem[] = isAscEd ? ASC2_CATALOG : isMed ? ALL_VITYLS_FORM_CATALOG.filter(f => MED_FORM_FILES.has(f.file) || f.category === 'Custom') : ALL_VITYLS_FORM_CATALOG;

export const workflowStorageKey = (file: string) => `vityls-form-workflow:${file}`;
export const templateStorageKey = (file: string) => `vityls-form-template:${file}`;
export const schemaStorageKey = (file: string) => `vityls-form-schema:${file}`;

export const blankWorkflow = (): WorkflowMap => ({
  patientPortal:{enabled:false}, frontOffice:{enabled:false}, nursing:{enabled:false}, anesthesia:{enabled:false},
  surgeon:{enabled:false}, orTeam:{enabled:false}, pacu:{enabled:false}
});

// v6: default station assignments come from the single station plan (src/v6/formRules.ts),
// so the chart, the station workspace and Form Studio agree. Intra-op and PACU forms no longer
// sit on the pre-op Nursing station, and the four previously unassigned forms (AMA, Anesthesia
// Orders, PACU Doctor Orders, Surgeon Orders) now have a home (focused addendum §1, baseline 5b.4).
const DEFAULT_WORKFLOWS: Partial<Record<string, WorkflowKey[]>> = (() => {
  const out: Partial<Record<string, WorkflowKey[]>> = {};
  (Object.keys(STATION_PLAN) as WorkflowKey[]).forEach(k => {
    [...STATION_PLAN[k].required, ...STATION_PLAN[k].asNeeded].forEach(f => { (out[f] ||= []).includes(k) || out[f]!.push(k); });
  });
  ['Photography_Media_Research_Consent.html', 'Patient_Satisfaction_Survey.html'].forEach(f => { (out[f] ||= []).includes('patientPortal') || out[f]!.push('patientPortal'); });
  return out;
})();

function defaultWorkflowFor(file: string): WorkflowMap {
  const next = blankWorkflow();
  if (isAscEd) { const f = ASC_FORMS.find(x => x.file === file); if (f && !isCredentialing(f.file)) next[f.station].enabled = true; return next; }
  (DEFAULT_WORKFLOWS[file] || []).forEach(key => { next[key].enabled = true; });
  return next;
}

export function readWorkflowAssignment(file: string): WorkflowMap {
  let next = defaultWorkflowFor(file);
  try {
    const raw = JSON.parse(localStorage.getItem(workflowStorageKey(file)) || 'null');
    if (!raw) return next;
    FORM_WORKFLOWS.forEach(w => { next[w.key].enabled = Boolean(raw[w.key]?.enabled ?? raw[w.key] === true); });
  } catch {/* blank = explicitly unassigned */}
  return next;
}

export function isAssignedToWorkflow(file: string, workflow: WorkflowKey): boolean {
  return readWorkflowAssignment(file)[workflow].enabled;
}
