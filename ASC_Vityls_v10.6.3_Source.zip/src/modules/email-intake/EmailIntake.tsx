/* AI Email Intake page (v0.7 design language): inbox · message · Nightingale review card · draft reply. */
import React, { useMemo, useState } from 'react';
import { Paperclip, Sparkles, Check, Send, Inbox, CalendarPlus } from 'lucide-react';
import nightingaleIcon from '../../assets/nightingale-ai-icon.png';
import { useActor, useMedTick } from '../../med/ui';
import { medRepo, usDate } from '../../med/record';
import { getSettings } from '../../med/settings';
import { acceptExtraction, bookRequest, dismiss, draftReply, Email, Extraction, inbox, requests, sendReply } from './data';
import { modOn, useCoreTick } from '../../core/useCore';
import { TrialBanner } from '../../core/ui';
import { outbox } from '../../core/store';
import './email.css';

const FIELDS: [keyof Omit<Extraction, 'confidence'>, string][] = [['patient', 'Patient'], ['dob', 'Date of birth'], ['phone', 'Contact'], ['procedure', 'Procedure'], ['requestedDate', 'Requested date'], ['surgeon', 'Surgeon'], ['referring', 'Referring office'], ['insurance', 'Insurance'], ['urgency', 'Urgency']];
const when = (iso: string) => new Date(iso).toLocaleString([], { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' });

export const EmailIntakePage: React.FC<{ onOpenPatient: (pid: string) => void; onOpenSchedule: () => void; toast: (m: string) => void }> = ({ onOpenPatient, onOpenSchedule, toast }) => {
  useMedTick(); useCoreTick(); const [actor] = useActor(); const list = inbox(); const [sel, setSel] = useState(list[0]?.id || ''); const [view, setView] = useState<'inbox' | 'outbox'>('inbox');
  const e = list.find(m => m.id === sel); const sched = modOn('scheduling'); const pending = requests().filter(r => r.status === 'awaiting-scheduling');
  const nNew = list.filter(m => m.status === 'new' && m.kind === 'request').length;
  return <div className="v7-page ei" data-testid="email-intake">
    <TrialBanner m="email-intake" />
    <div className="ei-head"><div><h1 className="v7-h1">Email intake</h1><div className="v7-meta">scheduling@{getSettings().practiceName.toLowerCase().replace(/[^a-z]+/g, '')}.example · simulated inbox, fictional emails · nothing is sent</div></div>
      <div className="flex gap-2"><button type="button" className={`v7-btn sm ${view === 'inbox' ? 'primary' : ''}`} onClick={() => setView('inbox')} data-testid="ei-tab-inbox"><Inbox size={14} />Inbox</button><button type="button" className={`v7-btn sm ${view === 'outbox' ? 'primary' : ''}`} onClick={() => setView('outbox')} data-testid="ei-tab-outbox"><Send size={14} />Outbox · {outbox().filter(o => o.module === 'email-intake').length}</button></div></div>
    <div className="v7-ng ei-ng" data-testid="ei-brief"><div className="v7-ng-head"><span className="t"><img src={nightingaleIcon} alt="" width={18} height={18} />NIGHTINGALE</span><span className="m">reads the inbox · scripted, on-device</span></div>
      <div>{nNew ? `${nNew} new scheduling request${nNew > 1 ? 's' : ''} with ${list.filter(m => m.status === 'new').reduce((a, m) => a + m.attachments.length, 0)} attachments. I pulled out the patient, procedure, date and surgeon for your review.` : 'All requests are handled.'}{pending.length > 0 && ` ${pending.length} accepted request${pending.length > 1 ? 's are' : ' is'} waiting for a date${sched ? '' : ' (Scheduling is not in your plan; the requests are kept here)'}.`}</div></div>
    {view === 'outbox' ? <OutboxView /> : <div className="ei-grid">
      <ul className="v7-card ei-list" aria-label="Inbox" data-testid="ei-list">{list.map(m => <li key={m.id}><button type="button" aria-current={m.id === sel || undefined} onClick={() => setSel(m.id)} data-testid={`ei-mail-${m.id}`}>
        <div className="flex justify-between gap-2"><b className={m.status === 'new' ? '' : 'read'}>{m.fromName}</b><span className="v7-meta">{when(m.receivedAt)}</span></div>
        <div className="s">{m.subject}</div>
        <div className="flex gap-2 items-center mt-1">{m.attachments.length > 0 && <span className="v7-meta"><Paperclip size={11} /> {m.attachments.length}</span>}<span className={`v7-pill ${m.status === 'new' ? m.kind === 'request' ? 'blue' : '' : m.status === 'replied' ? 'green' : m.status === 'accepted' ? 'amber' : ''}`}>{m.status === 'new' ? m.kind === 'request' ? 'Request' : 'Not a request' : m.status}</span></div>
      </button></li>)}</ul>
      {e ? <Message key={e.id + e.status} e={e} sched={sched} onOpenPatient={onOpenPatient} onOpenSchedule={onOpenSchedule} toast={toast} actor={actor} /> : <div className="v7-card"><p className="v7-empty">Select an email.</p></div>}
    </div>}
  </div>;
};

const Message: React.FC<{ e: Email; sched: boolean; onOpenPatient: (pid: string) => void; onOpenSchedule: () => void; toast: (m: string) => void; actor: { name: string; role: string } }> = ({ e, sched, onOpenPatient, onOpenSchedule, toast, actor }) => {
  const [x, setX] = useState<Extraction | undefined>(e.extraction); const visit = e.visitId ? medRepo.visit(e.visitId) : undefined;
  const [reply, setReply] = useState(() => e.reply?.text || draftReply(e, getSettings().practiceName, visit ? { date: usDate(visit.date), time: visit.time } : undefined));
  const req = e.requestId ? requests().find(r => r.id === e.requestId) : undefined;
  const accept = () => { try { const out = acceptExtraction(e.id, x!, actor.name, actor.role, sched); toast(out.visitId ? `Accepted. ${x!.patient} ${out.matched ? 'matched' : 'created'}, ${out.filedDocs?.length} attachment(s) filed, appointment booked.` : `Accepted. ${x!.patient} ${out.matched ? 'matched' : 'created'}, ${out.filedDocs?.length} attachment(s) filed, scheduling request queued.`); } catch (er) { toast((er as Error).message); } };
  return <div className="ei-msg">
    <article className="v7-card ei-mail" data-testid="ei-message"><h2 className="v7-h2">{e.subject}</h2><div className="v7-meta">{e.fromName} · {e.org} &lt;{e.from}&gt; · {when(e.receivedAt)}</div>
      <pre className="ei-body">{e.body}</pre>
      {e.attachments.length > 0 && <div className="ei-atts">{e.attachments.map(a => <span key={a.id} className="ei-att" data-testid="ei-att"><Paperclip size={12} />{a.name}<span className="v7-meta"> · {a.kind}</span></span>)}</div>}
    </article>
    {e.kind === 'other' ? <div className="v7-card ei-card"><p>Nightingale: this isn’t a scheduling request.</p>{e.status === 'new' && <button type="button" className="v7-btn sm" onClick={() => dismiss(e.id, actor.name, actor.role)} data-testid="ei-dismiss">Mark as not a request</button>}</div>
    : x && <section className="v7-card ei-card" data-testid="ei-review"><div className="ei-card-h"><Sparkles size={15} /><b>Nightingale extracted this request</b><span className="v7-meta">· check each field before accepting</span></div>
      <div className="ei-fields">{FIELDS.map(([k, l]) => <label key={k} className="ei-f"><span>{l}{x.confidence[k] === 'medium' && <em title="Nightingale is less sure about this field"> · check</em>}</span>
        {e.status === 'new' ? <input className="v7-input" value={x[k]} onChange={ev => setX({ ...x, [k]: ev.target.value })} data-testid={`ei-f-${k}`} /> : <div className="ei-v">{x[k] || '—'}</div>}</label>)}</div>
      <div className="ei-f"><span>Attachments → Documents</span><div className="ei-v">{e.attachments.map(a => `${a.name} → ${a.docType}`).join(' · ') || 'None'}</div></div>
      {e.status === 'new' ? <div className="flex flex-wrap gap-2 items-center mt-3"><button type="button" className="v7-btn primary" onClick={accept} data-testid="ei-accept"><Check size={15} />Accept · {sched ? 'create patient, file attachments, book appointment' : 'create patient, file attachments, queue request'}</button><span className="v7-meta">{(() => { const m = medRepo.patients().find(p => p.name.toLowerCase() === x.patient.toLowerCase() && p.dob === x.dob); return m ? `Matches existing patient ${m.name} (DOB ${m.dob})` : 'New patient in Vityls Core'; })()}</span></div>
      : <div className="ei-done" data-testid="ei-accepted"><Check size={14} />{e.matched ? 'Matched' : 'Created'} <button type="button" className="v7-quiet" onClick={() => onOpenPatient(e.patientId!)} data-testid="ei-open-patient">{x.patient}</button> · {e.filedDocs?.length || 0} filed to Documents · {visit ? <>appointment {usDate(visit.date)} {visit.time} <button type="button" className="v7-quiet" onClick={onOpenSchedule}>Schedule →</button></> : req?.status === 'awaiting-scheduling' ? <>scheduling request queued{sched && <button type="button" className="v7-quiet ml-2" onClick={() => { bookRequest(req.id, actor.name, actor.role); toast('Appointment booked from the request.'); }} data-testid="ei-book"><CalendarPlus size={12} /> Book now</button>}</> : 'booked'}</div>}
    </section>}
    {e.kind === 'request' && <section className="v7-card ei-card" data-testid="ei-reply"><div className="ei-card-h"><img src={nightingaleIcon} alt="" width={16} height={16} /><b>Draft reply</b><span className="v7-meta">· to {e.from} · edit, then approve</span></div>
      {e.status === 'replied' ? <><pre className="ei-body">{e.reply!.text}</pre><div className="ei-done" data-testid="ei-replied"><Send size={13} />Approved by {e.reply!.by} · in the simulated outbox · nothing was sent</div></>
      : <><textarea className="v7-input ei-ta" rows={9} value={reply} onChange={ev => setReply(ev.target.value)} data-testid="ei-reply-text" />
        <div className="flex gap-2 items-center mt-2"><button type="button" className="v7-btn primary" disabled={e.status !== 'accepted' && e.status !== 'new'} onClick={() => { sendReply(e.id, reply, actor.name, actor.role); toast('Reply approved. It is in the simulated outbox; nothing was sent.'); }} data-testid="ei-send"><Send size={14} />Approve &amp; send</button>
          {e.status === 'accepted' && <button type="button" className="v7-btn sm" onClick={() => setReply(draftReply(e, getSettings().practiceName, visit ? { date: usDate(visit.date), time: visit.time } : undefined))} data-testid="ei-redraft">Redraft</button>}
          <span className="v7-meta">Simulated: goes to the outbox only.</span></div></>}
    </section>}
  </div>;
};

const OutboxView: React.FC = () => { const l = outbox().filter(o => o.module === 'email-intake').slice().reverse(); return <div className="v7-card ei-card" data-testid="ei-outbox"><h2 className="v7-h3">Simulated outbox <span className="v7-h3-sub">· nothing leaves this browser</span></h2>{l.length ? l.map(o => <div key={o.id} className="ei-out"><div className="flex justify-between"><b>{o.subject}</b><span className="v7-meta">{when(o.at)}</span></div><div className="v7-meta">To {o.to} · approved by {o.by}</div><pre className="ei-body">{o.body}</pre></div>) : <p className="v7-empty">Nothing sent yet.</p>}</div>; };
