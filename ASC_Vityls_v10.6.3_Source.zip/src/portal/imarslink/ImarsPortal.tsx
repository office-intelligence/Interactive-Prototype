/*
 * Vityls Patient Portal v0.5 · Kevin's iMARSLINK structure with a Microsoft Copilot-style chat.
 * 1) AI Chat (Copilot layout: sidebar with Chat | Portal toggle, centered greeting, one big message box, chips).
 * 2) Portal: 2a Timeline (vertical journal with colored nodes, Past / Upcoming), 2b Details (My Doctors, My Labs, My Health, Messages).
 * Billing, plan and settings sit in the profile menu. Warm ivory palette, Nightingale green as the brand accent.
 * Data only through usePortalData (store/hub/finder). Fictional data; every connection is simulated until a BAA is signed.
 */
import { Fragment, useEffect, useRef, useState, type ReactNode } from 'react';
import { Bell, CalendarCheck, ChevronDown, ChevronRight, CreditCard, FileText, FlaskConical, Link2, MessageSquare, Pill, Plus, Search, Send, ClipboardList, Inbox as InboxIcon, X, Menu, Settings, SquarePen, Clock, Sparkles, Stethoscope, HeartPulse, LogOut } from 'lucide-react';
import * as S from '../store';
import * as H from '../hub';
import type { Account, Lab, Chat } from '../store';
import { Auth, CAROUSEL, CareTeam, Connect, Docs, Family, Finder, History, Inbox, LAB_PRESETS, Meds, PlanPage, PromptCards, Trend, type P, type Page } from '../PortalApp';
import { go, srcName, timeline, labPanels, useRoute, usePortalData, isOpen, taskLink, pendingTasks, unseen, NAV_TREE, PROFILE_MENU, type Ev, type Route, type Section } from './usePortalData';
import './imarslink.css';

type PX = P & { grants?: H.Caregiver[]; refresh?: () => void };
const fmt = (d: string) => new Date(d.length === 10 ? d + 'T12:00:00' : d).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
const fmtT = (d: string) => new Date(d).toLocaleString('en-US', { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' });
const DISCLAIMER = 'Nightingale explains and organizes your records. She does not diagnose or tell you whether to do something; your doctor does.';
export const CALM = 'A value outside the range is common and often temporary. It does not by itself mean something is wrong. It is worth discussing with your doctor, who can look at it alongside the rest of your health.';

/* ---------- accessible modal ---------- */
export function Modal({ title, onClose, children, testid }: { title: string; onClose: () => void; children: ReactNode; testid?: string }) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const prev = document.activeElement as HTMLElement | null; const el = ref.current!;
    const items = () => Array.from(el.querySelectorAll<HTMLElement>('button,[href],input,select,textarea,[tabindex]:not([tabindex="-1"])')).filter(x => !x.hasAttribute('disabled'));
    (items()[1] || items()[0] || el).focus();
    const key = (e: KeyboardEvent) => { if (e.key === 'Escape') { e.preventDefault(); onClose(); } if (e.key === 'Tab') { const l = items(); if (!l.length) return; const f = l[0], z = l[l.length - 1]; if (e.shiftKey && document.activeElement === f) { e.preventDefault(); z.focus(); } else if (!e.shiftKey && document.activeElement === z) { e.preventDefault(); f.focus(); } } };
    el.addEventListener('keydown', key); return () => { el.removeEventListener('keydown', key); prev?.focus?.(); };
  }, []);
  return <div className="fixed inset-0 z-50 bg-[#3b2a1f]/30 flex items-end sm:items-center justify-center p-0 sm:p-4" onMouseDown={e => { if (e.target === e.currentTarget) onClose(); }}>
    <div ref={ref} role="dialog" aria-modal="true" aria-label={title} tabIndex={-1} data-testid={testid} className="ng-surface w-full sm:max-w-lg max-h-[92vh] overflow-y-auto rounded-t-2xl sm:rounded-[14px] p-5 outline-none">
      <div className="flex items-center justify-between gap-3 mb-3"><h2 className="ng-h2">{title}</h2><button onClick={onClose} aria-label="Close" className="p-1.5 rounded-full hover:bg-[#f3ebe1] text-[#7a6a5d]" data-testid="imx-modal-close"><X className="w-4 h-4" /></button></div>
      {children}
    </div></div>;
}
const initials = (n: string) => n.split(' ').map(x => x[0]).slice(0, 2).join('').toUpperCase();
const Avatar = ({ name, big }: { name: string; big?: boolean }) => <span aria-hidden="true" className={`ng-avatar ${big ? 'big' : ''}`}>{initials(name || '?')}</span>;
const Feather = ({ small }: { small?: boolean }) => <span aria-hidden="true" className={`ng-mark ${small ? 'small' : ''}`}>🪶</span>;

/* ---------- chat archive (New chat) ---------- */
const chatTitle = (m: Chat[]) => (m.find(x => x.who === 'me')?.text || 'Conversation').slice(0, 48);
function newChat(save: PX['save']) { save(x => { if (x.chat.some(m => m.who === 'me')) (x.chats ||= []).unshift({ id: S.uid('ch-'), title: chatTitle(x.chat), at: S.nowIso(), msgs: x.chat }); x.chat = []; }); go({ view: 'chat' }); }
function openChat(id: string, save: PX['save']) { save(x => { const c = (x.chats || []).find(y => y.id === id); if (!c) return; const cur = x.chat; x.chats = (x.chats || []).filter(y => y.id !== id); if (cur.some(m => m.who === 'me')) x.chats.unshift({ id: S.uid('ch-'), title: chatTitle(cur), at: S.nowIso(), msgs: cur }); x.chat = c.msgs; }); go({ view: 'chat' }); }

/* ---------- sidebar (Copilot layout) ---------- */
const HEAD_ICON: Record<string, ReactNode> = { timeline: <Clock className="w-4 h-4" aria-hidden="true" />, doctors: <Stethoscope className="w-4 h-4" aria-hidden="true" />, labs: <FlaskConical className="w-4 h-4" aria-hidden="true" />, health: <HeartPulse className="w-4 h-4" aria-hidden="true" />, messages: <MessageSquare className="w-4 h-4" aria-hidden="true" /> };
function Sidebar({ p, guest, onAuth, route, open, setOpen, onSearch, onGuestFinder }: { p?: PX; guest?: boolean; onAuth?: (m: 'in' | 'up', r?: string) => void; route: Route; open: boolean; setOpen: (b: boolean) => void; onSearch: () => void; onGuestFinder?: () => void }) {
  const [menu, setMenu] = useState(false); const view = route.view === 'chat' ? 'chat' : 'portal';
  const sec = route.view === 'portal' ? route.section : route.view === 'task' ? 'timeline' : null;
  const nav = (r: Route) => { setOpen(false); setMenu(false); go(r); };
  const portalClick = () => guest ? onAuth!('up', 'Your Portal (timeline, labs, doctors and messages) needs a free account, so your records are saved and private. Find a doctor works without one.') : nav({ view: 'portal', section: 'timeline' });
  const a = p?.a; const plus = a ? S.isPlus(a) : false;
  return <>
    {open && <div className="fixed inset-0 z-40 bg-[#3b2a1f]/25 lg:hidden" onClick={() => setOpen(false)} aria-hidden="true" />}
    <aside className={`ng-side ${open ? 'open' : ''}`} aria-label="Nightingale navigation" data-testid="imx-sidebar">
      <div className="flex items-center justify-between px-1"><button onClick={() => nav({ view: 'chat' })} className="flex items-center gap-2" aria-label="Nightingale chat home" data-testid="pp-logo"><Feather small /><span className="ng-wordmark">Nightingale</span></button>
        <button className="lg:hidden p-1.5 rounded-full hover:bg-[#efe5d8]" onClick={() => setOpen(false)} aria-label="Close menu" data-testid="imx-drawer-close"><X className="w-4 h-4" /></button></div>
      <div className="ng-seg" role="tablist" aria-label="Chat or Portal"><button role="tab" aria-selected={view === 'chat'} className={view === 'chat' ? 'on' : ''} onClick={() => nav({ view: 'chat' })} data-testid="imx-open-chat">Chat</button><button role="tab" aria-selected={view === 'portal'} className={view === 'portal' ? 'on' : ''} onClick={portalClick} data-testid="imx-open-portal">Portal</button></div>
      <nav className="flex flex-col gap-0.5" aria-label="Main">
        <button className="ng-sidelink strong" onClick={() => { setOpen(false); if (guest) { S.saveGuest({ ...S.guest(), chat: [] }); window.dispatchEvent(new Event('vityls-portal-hub')); go({ view: 'chat' }); } else newChat(p!.save); }} data-testid="imx-newchat"><SquarePen className="w-4 h-4" aria-hidden="true" />New chat</button>
        <button className="ng-sidelink" onClick={() => { setOpen(false); onSearch(); }} data-testid="imx-search-open"><Search className="w-4 h-4" aria-hidden="true" />Search</button>
      </nav>
      {!guest && <nav className="flex flex-col gap-0.5" aria-label="Portal sections" data-testid="imx-nav">
        <div className="ng-sidehead">Portal</div>
        {NAV_TREE.map(g => { const active = g.items.some(i => i[0] === sec); const single = g.items.length === 1;
          return <div key={g.id}>
            <button className={`ng-sidelink ${active ? 'on' : ''}`} aria-expanded={single ? undefined : active} onClick={() => nav({ view: 'portal', section: g.items[0][0] })} data-testid={single ? `pp-nav-${g.items[0][0]}` : `imx-head-${g.id}`}>{HEAD_ICON[g.id]}{g.label}{!single && <ChevronRight className={`w-3.5 h-3.5 ml-auto transition-transform ${active ? 'rotate-90' : ''}`} aria-hidden="true" />}</button>
            {!single && <div className={`ml-6 flex-col ${active ? 'flex' : 'hidden'}`}>{g.items.map(([k, l]) => <button key={k} className={`ng-sublink ${sec === k ? 'on' : ''}`} aria-current={sec === k ? 'page' : undefined} onClick={() => nav({ view: 'portal', section: k })} data-testid={`pp-nav-${k}`}>{l}</button>)}</div>}
          </div>; })}
      </nav>}
      {guest && <nav className="flex flex-col gap-0.5" aria-label="Explore"><div className="ng-sidehead">Explore</div><button className="ng-sidelink" onClick={() => { setOpen(false); onGuestFinder!(); }} data-testid="pp-guest-finder"><Stethoscope className="w-4 h-4" aria-hidden="true" />Find a doctor</button></nav>}
      <div className="ng-sidehead">Chats</div>
      <div className="flex-1 min-h-0 overflow-y-auto flex flex-col gap-0.5" data-testid="imx-chats">
        {guest || !(a!.chats || []).length ? <p className="px-2 text-[12px] text-[#9a8a7c] leading-snug">No past chats yet. Once you start chatting, you can come back to past conversations here.</p>
          : a!.chats!.map(c => <button key={c.id} className="ng-sublink truncate text-left" onClick={() => { setOpen(false); openChat(c.id, p!.save); }} title={c.title} data-testid="imx-chat-item">{c.title}</button>)}
      </div>
      <div className="border-t border-[#eadfce] pt-3 relative">
        {guest ? <div className="flex flex-col gap-2"><button className="ng-btn" onClick={() => onAuth!('up')} data-testid="pp-guest-signup">Create free account</button><button className="ng-btn ghost" onClick={() => onAuth!('in')} data-testid="pp-guest-signin">Sign in</button></div> : <>
          {menu && <div className="ng-menu" role="menu" data-testid="imx-profile-menu">
            {p!.grants && p!.grants.length > 0 && <label className="block px-3 py-2 text-[12px] text-[#7a6a5d]">Viewing profile<select className="ng-input mt-1 w-full" value={a!.id} onChange={e => { S.setViewing(e.target.value); setMenu(false); go({ view: 'chat' }); p!.refresh!(); }} data-testid="pp-profile-switch"><option value={p!.me.id}>{p!.me.name} (me)</option>{p!.grants.map(g => <option key={g.id} value={g.ownerAcct}>{g.ownerName} ({g.relation})</option>)}</select></label>}
            {PROFILE_MENU.map(([k, l]) => <button key={k} role="menuitem" className="ng-menuitem" onClick={() => nav({ view: 'portal', section: k })} data-testid={`pp-nav-${k}`}>{l}</button>)}
            <button role="menuitem" className="ng-menuitem" onClick={() => { setMenu(false); S.setSession(null); go({ view: 'chat' }); p!.refresh!(); }} data-testid="pp-signout"><LogOut className="w-3.5 h-3.5" aria-hidden="true" />Sign out</button></div>}
          <div className="flex items-center gap-2"><Avatar name={p!.me.name} /><div className="min-w-0 flex-1"><div className="text-[13px] font-semibold truncate">{p!.me.name}</div><span className="ng-tag">{plus ? 'Plus' : 'Free'}</span></div>
            <button className="p-1.5 rounded-full hover:bg-[#efe5d8]" aria-label="Profile, billing and settings" aria-expanded={menu} aria-haspopup="menu" onClick={() => setMenu(!menu)} data-testid="imx-profile"><Settings className="w-4 h-4" /></button></div>
          {!plus && <button className="ng-btn ghost w-full mt-2" onClick={() => nav({ view: 'portal', section: 'plan' })} data-testid="imx-upgrade">Upgrade to Plus</button>}</>}
      </div>
    </aside></>;
}
function TopBar({ setOpen, unread, guest, title }: { setOpen: (b: boolean) => void; unread?: number; guest?: boolean; title?: string }) {
  return <div className="ng-top" data-testid="imx-header"><button className="lg:hidden p-2 rounded-full hover:bg-[#f3ebe1]" onClick={() => setOpen(true)} aria-label="Open menu" data-testid="imx-menu"><Menu className="w-5 h-5" /></button>
    <span className="text-[13px] text-[#7a6a5d] truncate min-w-0">{title}</span>
    <div className="ml-auto flex items-center gap-1">{!guest && <button onClick={() => go({ view: 'portal', section: 'alerts' })} className="relative p-2 rounded-full hover:bg-[#f3ebe1] text-[#5b4a3e]" aria-label={`Notifications${unread ? `, ${unread} unread` : ''}`} data-testid="imx-bell"><Bell className="w-[18px] h-[18px]" aria-hidden="true" />{!!unread && <span className="absolute top-0.5 right-0.5 min-w-4 h-4 px-1 rounded-full bg-[#c8664a] text-white text-[10px] font-bold flex items-center justify-center" data-testid="pp-unread">{unread}</span>}</button>}</div></div>;
}

/* ---------- message box with + upload ---------- */
function Composer({ value, setValue, onSend, onUpload, placeholder }: { value: string; setValue: (s: string) => void; onSend: () => void; onUpload: (type: string, f: File) => void; placeholder: string }) {
  const [m, setM] = useState(false); const [type, setType] = useState('Lab report'); const file = useRef<HTMLInputElement>(null);
  return <div className="ng-composer relative">
    <button className="ng-plus" onClick={() => setM(!m)} aria-label="Upload lab results, notes or documents" aria-expanded={m} data-testid="imx-plus"><Plus className="w-5 h-5" aria-hidden="true" /></button>
    {m && <div className="ng-menu up" role="menu" data-testid="imx-plus-menu">{[['Lab report', 'Upload lab results'], ['Visit note', 'Upload a visit note'], ['Other', 'Upload another document']].map(([t, l]) => <button key={t} role="menuitem" className="ng-menuitem" onClick={() => { setType(t); setM(false); file.current?.click(); }} data-testid={`imx-plus-${t.split(' ')[0].toLowerCase()}`}><FileText className="w-3.5 h-3.5" aria-hidden="true" />{l}</button>)}</div>}
    <input ref={file} type="file" hidden accept="image/*,.pdf" onChange={e => { const f = e.target.files?.[0]; if (f) onUpload(type, f); e.target.value = ''; }} data-testid="imx-upload-input" />
    <input aria-label="Message Nightingale" value={value} onChange={e => setValue(e.target.value)} onKeyDown={e => { if (e.key === 'Enter') onSend(); }} placeholder={placeholder} className="flex-1 min-w-0 bg-transparent border-none text-[15px] text-[#2b211b] focus:outline-none px-1 py-3" data-testid="pp-ask" />
    <button onClick={onSend} disabled={!value.trim()} aria-label="Send" className="ng-send" data-testid="pp-ask-go"><Send className="w-4 h-4" aria-hidden="true" /></button></div>;
}
const Chip = ({ children, onClick, testid, tone }: { children: ReactNode; onClick: () => void; testid?: string; tone?: 'task' }) => <button onClick={onClick} className={`ng-chip ${tone || ''}`} data-testid={testid}>{children}</button>;
const NgLine = ({ children, testid }: { children: ReactNode; testid?: string }) => <div className="flex gap-3 items-start" data-testid={testid}><Feather small /><div className="min-w-0 flex-1 ng-bubble">{children}</div></div>;
const MeLine = ({ children }: { children: ReactNode }) => <div className="flex justify-end"><div className="ng-bubble me">{children}</div></div>;
function Examples({ onTry }: { onTry: (k: string) => void }) {
  const [i, setI] = useState(0); const [pause, setPause] = useState(false);
  useEffect(() => { if (pause) return; const t = setInterval(() => setI(x => (x + 1) % CAROUSEL.length), 5000); return () => clearInterval(t); }, [pause]);
  const c = CAROUSEL[i];
  return <div className="ng-examples" onMouseEnter={() => setPause(true)} onMouseLeave={() => setPause(false)} onFocus={() => setPause(true)} data-testid="pp-carousel" data-index={i} aria-roledescription="carousel" aria-label="Examples of what Nightingale can do">
    <div className="flex items-center gap-2 min-w-0" data-testid={`pp-slide-${c.key}`}><span className="ng-tag">Example</span><span className="truncate">{c.text.replace(/^Example: /, '')}</span><button className="ng-link shrink-0" onClick={() => onTry(c.key)} data-testid="pp-slide-try">Try it</button></div>
    <div className="flex gap-1.5 justify-center mt-1.5">{CAROUSEL.map((x, j) => <button key={x.key} aria-label={x.title} aria-current={j === i} onClick={() => setI(j)} className={`ng-dot ${j === i ? 'on' : ''}`} data-testid={`pp-dot-${j}`} />)}</div></div>;
}

/* ---------- brief reminder of unfinished tasks: one short Nightingale line with links ---------- */
function reminder(a: Account) {
  const t = pendingTasks(a.id); const news = unseen(a.id); const pend = H.linksFor(a.id).filter(l => l.status === 'pending');
  if (!t.length && !news.length && !pend.length) return null;
  const links: { label: string; route: Route; testid: string }[] = [];
  const VERB: Record<string, string> = { checkin: 'check in', reminder: 'confirm your visit' };
  t.forEach(x => links.push({ label: x.kind === 'bill' ? `pay $${(x.amount || 0).toFixed(2)}` : x.kind === 'form' ? `"${x.title}"` : VERB[x.kind], route: { view: 'task', id: x.id }, testid: `ng-task-${x.kind}` }));
  const res = news.filter(n => n.kind === 'result'); const docs = news.filter(n => n.kind === 'document'); const msgs = news.filter(n => n.kind === 'message' || n.kind === 'refill-reply');
  if (res.length) links.push({ label: res.length === 1 ? 'a new result' : `${res.length} new results`, route: { view: 'task', id: res[0].id }, testid: 'ng-task-result' });
  if (docs.length) links.push({ label: docs.length === 1 ? 'a new document' : `${docs.length} documents`, route: { view: 'task', id: docs[0].id }, testid: 'ng-task-document' });
  if (msgs.length) links.push({ label: msgs.length === 1 ? 'a message' : `${msgs.length} messages`, route: { view: 'task', id: msgs[0].id }, testid: 'ng-task-message' });
  pend.forEach(l => links.push({ label: `${l.practiceName} wants to connect`, route: { view: 'portal', section: 'care' }, testid: 'ng-task-link' }));
  const from = [...new Set([...t, ...news].map(x => x.practiceName).concat(pend.map(l => l.practiceName)))];
  const abn = res.some(r => r.lab && (r.lab.value > r.lab.high || r.lab.value < r.lab.low));
  return { from, links, abn, count: t.length };
}
function ReminderLine({ a }: { a: Account }) {
  const r = reminder(a); if (!r) return null;
  return <NgLine testid="ng-inbox"><span data-testid="ng-inbox-text">{r.count ? `You have ${r.count} thing${r.count > 1 ? 's' : ''} to finish` : 'New from your doctors'} from {r.from.join(' and ')}: </span>
    {r.links.map((l, i) => <span key={i}>{i > 0 && (i === r.links.length - 1 ? ' and ' : ', ')}<button className="ng-link" onClick={() => go(l.route)} data-testid={l.testid}>{l.label}</button></span>)}.
    {r.abn && <span className="block mt-1 text-[13px] text-[#7a6a5d]" data-testid="ng-inbox-calm">One new value is outside the usual range. That is common and worth discussing with your doctor.</span>}</NgLine>;
}
const taskChips = (a: Account) => pendingTasks(a.id).slice(0, 3).map(t => ({ label: t.kind === 'bill' ? `Pay $${(t.amount || 0).toFixed(0)} bill` : t.kind === 'form' ? `${t.practiceName.split(' ')[0]} forms` : t.kind === 'checkin' ? 'Check in' : 'Confirm visit', id: t.id, kind: t.kind }));

/* ---------- 1) AI Chat ---------- */
function ChatPage({ p }: { p: PX }) {
  const { a, save } = p; const [q, setQ] = useState(''); const [ask, setAsk] = useState(false); const first = a.name.split(' ')[0];
  const say = (text: string) => save(x => { x.chat.push({ id: S.uid(), who: 'me', text, at: S.nowIso() }); x.chat.push({ id: S.uid(), who: 'ng', text: S.nightingaleReply(x, text), at: S.nowIso() }); });
  const send = () => { if (q.trim()) { say(q.trim()); setQ(''); } };
  const upload = (type: string, f: File) => { const r = new FileReader(); r.onload = () => save(x => { const t = f.name.replace(/\.[^.]+$/, ''); x.docs.unshift({ id: S.uid('doc-'), title: t, type, date: S.today(), source: 'Uploaded by me', size: `${Math.max(1, Math.round(f.size / 1024))} KB`, dataUrl: f.size < 1.5e6 ? String(r.result) : undefined }); if (!x.sources.some(s => s.kind === 'patient-upload')) x.sources.push({ id: 'me', kind: 'patient-upload', name: 'My uploads', connectedAt: S.nowIso() }); x.audit.push({ at: S.nowIso(), what: `Uploaded ${f.name} from the chat` });
    x.chat.push({ id: S.uid(), who: 'me', text: `Uploaded: ${f.name}`, at: S.nowIso() }); x.chat.push({ id: S.uid(), who: 'ng', text: `Thank you. I filed "${t}" under Documents as a ${type.toLowerCase()} and added it to your timeline. Open it there and tap Explain for a plain-language summary.`, at: S.nowIso() }); }); r.readAsDataURL(f); };
  const talking = a.chat.some(m => m.who === 'me'); const chips = taskChips(a); const prompts = S.prompts(a);
  const tryEx = (k: string) => k === 'lab' ? go({ view: 'portal', section: 'labs' }) : k === 'medlab' ? say('Check my medications') : k === 'wear' ? go({ view: 'portal', section: 'wearables' }) : k === 'visit' ? say('Help me prepare for my visit') : k === 'doc' ? go({ view: 'portal', section: 'docs' }) : go({ view: 'portal', section: 'family' });
  const box = <>
    <Composer value={q} setValue={setQ} onSend={send} onUpload={upload} placeholder="Message Nightingale" />
    <div className="flex flex-wrap justify-center gap-2 mt-3" data-testid="imx-chips"><Chip onClick={() => document.querySelector<HTMLButtonElement>('[data-testid=imx-plus]')?.click()} testid="imx-chip-upload">Upload labs</Chip><Chip onClick={() => say('Explain my labs')} testid="imx-chip-explain">Explain a result</Chip>
      {chips.map(c => <Chip key={c.id} tone="task" onClick={() => go({ view: 'task', id: c.id })} testid={`imx-chip-task-${c.kind}`}>{c.label}</Chip>)}</div></>;
  return <main className={`ng-main ${talking ? '' : 'hero'}`} data-testid="pp-home">
    {p.role === 'caregiver' && <p className="ng-note mb-3" data-testid="pp-caregiver-banner">You are acting for {a.name}. Everything you do is recorded in {first}'s history.</p>}
    {!talking ? <div className="ng-hero" data-testid="pp-chat" aria-live="polite">
      <h1 className="ng-greet">Hi {first}, what can I help you with?</h1>
      <div className="w-full max-w-[44rem] mx-auto space-y-3">
        <ReminderLine a={a} />
        {prompts.length > 0 && (ask ? <div className="imx-legacy imx-prompts" data-testid="pp-prompts"><PromptCards {...p} max={1} /></div>
          : <NgLine><span>{prompts[0].kind === 'labs-meds' ? 'I looked at your latest labs and have a question about your medicines.' : `I have a quick question about your ${prompts[0].title.toLowerCase()}.`} </span><button className="ng-link" onClick={() => setAsk(true)} data-testid="imx-ask-open">Answer it</button></NgLine>)}
        <div className="pt-2">{box}</div>
        <p className="text-center text-[11.5px] text-[#9a8a7c] pt-1">{DISCLAIMER}</p>
      </div>
      <div className="w-full max-w-[44rem] mx-auto mt-10"><Examples onTry={tryEx} /></div>
    </div> : <div className="ng-convo">
      <section className="flex-1 space-y-4 pb-4" data-testid="pp-chat" aria-label="Conversation" aria-live="polite">
        {a.chat.slice(-16).map(m => m.who === 'ng' ? <NgLine key={m.id}>{m.text}</NgLine> : <MeLine key={m.id}>{m.text}</MeLine>)}
        <ReminderLine a={a} />
        {prompts.length > 0 && <div className="imx-legacy imx-prompts" data-testid="pp-prompts"><PromptCards {...p} max={1} /></div>}
      </section>
      <div className="ng-dock">{box}<p className="text-center text-[11.5px] text-[#9a8a7c] mt-2">{DISCLAIMER}</p></div></div>}
  </main>;
}

/* ---------- guest chat (3 free explanations, then sign-up) ---------- */
function GuestChat({ onAuth }: { onAuth: (m: 'in' | 'up', reason?: string) => void }) {
  const [g, setG] = useState(S.guest()); const [lab, setLab] = useState({ name: 'ALT', value: '' }); const [q, setQ] = useState(''); const [labRow, setLabRow] = useState(false);
  useEffect(() => { const f = () => setG(S.guest()); window.addEventListener('vityls-portal-hub', f); return () => window.removeEventListener('vityls-portal-hub', f); }, []);
  const left = Math.max(0, S.GUEST_LIMIT - g.used); const put = (n: S.Guest) => { S.saveGuest(n); setG(n); };
  const limit = () => onAuth('up', `You've used your ${S.GUEST_LIMIT} free guest explanations. Create a free account to keep going; your guest session comes with you.`);
  const need = (what: string) => onAuth('up', `${what} needs a free account, so your records are saved and private. What you did as a guest comes with you.`);
  const explain = () => { const v = parseFloat(lab.value); if (isNaN(v)) return; if (left <= 0) return limit(); const [unit, low, high] = LAB_PRESETS[lab.name]; const l: Lab = { id: S.uid('lab-'), name: lab.name, code: '', value: v, unit, low, high, date: S.today(), source: 'guest' };
    put({ used: g.used + 1, labs: [...g.labs, l], chat: [...g.chat, { id: S.uid(), who: 'me', text: `Explain my ${lab.name} of ${v} ${unit}`, at: S.nowIso() }, { id: S.uid(), who: 'ng', text: S.explainLab(l), at: S.nowIso() }] }); setLab({ ...lab, value: '' }); };
  const ask = () => { const t = q.trim(); if (!t) return; const tmp = S.blankAccount('Guest', 'g@x', 'x', '2000-01-01'); tmp.labs = g.labs; const r = S.nightingaleReply(tmp, t); const urgent = /911/.test(r);
    if (!urgent && left <= 0) return limit();
    put({ ...g, used: g.used + (urgent ? 0 : 1), chat: [...g.chat, { id: S.uid(), who: 'me', text: t, at: S.nowIso() }, { id: S.uid(), who: 'ng', text: r, at: S.nowIso() }] }); setQ(''); };
  const gated: [string, string][] = [['Connect my doctor', 'Connecting your doctors'], ['Message my practice', 'Messaging a practice'], ['Family access', 'Family access'], ['Save my records', 'Saving records'], ['Wearables', 'Wearables']];
  const talking = g.chat.length > 0;
  const box = <><Composer value={q} setValue={setQ} onSend={ask} onUpload={() => need('Keeping uploads')} placeholder="Ask about a lab result or a word in your report" />
    <div className="flex flex-wrap justify-center gap-2 mt-3"><Chip onClick={() => need('Keeping uploads')} testid="pp-guest-gate-upload">Upload labs</Chip><Chip onClick={() => setLabRow(true)} testid="imx-chip-explain">Explain a result</Chip>{gated.map(([l, w]) => <Chip key={l} onClick={() => need(w)} testid={`pp-guest-gate-${l.split(' ')[0].toLowerCase()}`}>{l}</Chip>)}</div>
    {(labRow || talking) && <div className="flex flex-wrap gap-2 items-center justify-center mt-3" data-testid="imx-guest-labrow"><select aria-label="Lab test" className="ng-input" value={lab.name} onChange={e => setLab({ ...lab, name: e.target.value })} data-testid="pp-guest-lab">{Object.keys(LAB_PRESETS).map(k => <option key={k}>{k}</option>)}</select>
      <input aria-label="Lab value" className="ng-input w-32" placeholder={`Value (${LAB_PRESETS[lab.name][0]})`} value={lab.value} onChange={e => setLab({ ...lab, value: e.target.value })} onKeyDown={e => e.key === 'Enter' && explain()} data-testid="pp-guest-value" />
      <button className="ng-btn" onClick={explain} data-testid="pp-guest-explain">Explain</button></div>}
    <p className="text-center text-[12px] text-[#7a6a5d] mt-3" data-testid="pp-guest-left">{left} of {S.GUEST_LIMIT} free guest explanations left · nothing is saved until you create an account</p>
    <p className="text-center text-[11.5px] text-[#9a8a7c] mt-1">{DISCLAIMER}</p></>;
  return !talking ? <main className="ng-main hero"><div className="ng-hero" data-testid="pp-chat">
      <h1 className="ng-greet">Hi, what can I help you with?</h1>
      <p className="text-center text-[14px] text-[#7a6a5d] -mt-3 mb-6 max-w-xl mx-auto">Ask about a lab value or a word in your report. No sign-in needed.</p>
      <div className="w-full max-w-[44rem] mx-auto">{box}</div>
      <div className="w-full max-w-[44rem] mx-auto mt-10"><Examples onTry={k => { if (k === 'lab') { setLabRow(true); setLab({ name: 'ALT', value: '68' }); } else need(CAROUSEL.find(c => c.key === k)!.title); }} /></div></div></main>
    : <main className="ng-main"><div className="ng-convo"><section className="flex-1 space-y-4 pb-4" data-testid="pp-chat" aria-live="polite">{g.chat.slice(-12).map(m => m.who === 'ng' ? <NgLine key={m.id}>{m.text}</NgLine> : <MeLine key={m.id}>{m.text}</MeLine>)}</section><div className="ng-dock">{box}</div></div></main>;
}

/* ---------- spectrum bar (from the Nightingale concept: where a value sits, in calm words) ---------- */
function Spectrum({ l }: { l: { value: number; low: number; high: number; unit: string } }) {
  const span = (l.high - l.low) || 1; const min = l.low - span * 0.6, max = l.high + span * 0.6; const pos = Math.max(2, Math.min(98, ((l.value - min) / (max - min)) * 100));
  const lo = ((l.low - min) / (max - min)) * 100, hi = ((l.high - min) / (max - min)) * 100; const out = l.value > l.high || l.value < l.low;
  return <div className="ng-spec" data-testid="imx-spectrum" role="img" aria-label={`${l.value} ${l.unit}; usual range ${l.low} to ${l.high}; ${out ? 'outside the usual range' : 'within the usual range'}`}>
    <div className="band"><span className="ok" style={{ left: `${lo}%`, width: `${hi - lo}%` }} /><span className={`pin ${out ? 'warm' : 'ok'}`} style={{ left: `${pos}%` }} /></div>
    <div className="flex justify-between text-[10.5px] text-[#9a8a7c] mt-1"><span>Worth discussing</span><span>Usual range</span><span>Worth discussing</span></div></div>;
}

/* ---------- task panel (deep link #portal/task/<id>) ---------- */
function TaskPanel({ p, id }: { p: PX; id: string }) {
  const { a, me, role, save } = p; const it = H.items().find(x => x.id === id && x.acctId === a.id);
  const [ans, setAns] = useState<Record<string, string>>({}); const [sig, setSig] = useState(''); const [rep, setRep] = useState(''); const [ex, setEx] = useState('');
  useEffect(() => { if (it) H.markOpened(it, me.name, role); }, [id]);
  const close = () => go({ view: 'portal', section: 'timeline' });
  if (!it) return <Modal title="Item not found" onClose={close} testid="imx-task"><p className="text-sm text-[#5b4a3e]" data-testid="imx-task-missing">This link doesn't match anything in {a.name.split(' ')[0]}'s Portal. It may belong to another profile or have been withdrawn.</p></Modal>;
  const done = !isOpen(it); const btn = 'ng-btn w-full mt-3';
  const lab = it.lab; const abn = lab && (lab.value > lab.high || lab.value < lab.low);
  const title = { form: 'At-home form', checkin: 'Check in', bill: 'Pay your bill', reminder: 'Confirm your appointment', result: 'New result', document: 'New document', message: 'Message', 'refill-reply': 'Refill reply', 'refill-request': 'Refill request', 'appt-request': 'Appointment request' }[it.kind];
  const ok = 'mt-3 text-sm ng-ok font-semibold';
  return <Modal title={title} onClose={close} testid="imx-task">
    <div className="text-xs text-[#7a6a5d] mb-2" data-testid="imx-task-meta">{it.practiceName} · {fmtT(it.at)} · <span className="font-semibold">{done ? 'Done' : 'Waiting for you'}</span></div>
    <h3 className="ng-h3">{it.title}</h3>{it.body && <p className="text-sm text-[#5b4a3e] mt-1">{it.body}</p>}
    {it.kind === 'form' && (done ? <p className={ok} data-testid="imx-task-done">Signed{it.answers?.__signedBy ? ` by ${it.answers.__signedBy}` : ''}. {it.practiceName} has it.</p> : <div className="mt-3 space-y-2">
      {(it.fields || []).map(f => <label key={f} className="ng-label">{f}<input className="ng-input mt-1 w-full" value={ans[f] || ''} onChange={e => setAns({ ...ans, [f]: e.target.value })} data-testid="pp-form-field" /></label>)}
      <label className="ng-label">Type your full name to sign<input className="ng-input mt-1 w-full" value={sig} onChange={e => setSig(e.target.value)} data-testid="pp-form-sign" /></label>
      <button className={btn} disabled={sig.trim().length < 3} onClick={() => { H.act(it.id, 'signed', me.name, role, { answers: { ...ans, __signedBy: sig.trim() } }, `${it.title} signed by ${sig.trim()}${role === 'caregiver' ? ` (caregiver for ${a.name})` : ''}`); save(x => { x.docs.unshift({ id: S.uid('doc-'), title: `${it.title} (signed)`, type: 'Signed form', date: S.today(), source: `${it.practiceName} (Vityls practice)`, fromPractice: true }); }); }} data-testid="pp-form-submit">Sign and send to {it.practiceName}</button></div>)}
    {it.kind === 'checkin' && (done ? <p className={ok} data-testid="imx-task-done">You're checked in. The front desk can see it.</p> : <><p className="mt-3 text-sm text-[#5b4a3e]">Confirm your address, phone and insurance haven't changed, then check in.</p><button className={btn} onClick={() => H.act(it.id, 'checked-in', me.name, role, {}, `Checked in from the Portal for ${it.title}`)} data-testid="pp-checkin">Everything is the same · check in</button></>)}
    {it.kind === 'bill' && (done ? <p className={ok} data-testid="imx-task-done">Paid ${it.amount?.toFixed(2)}. Thank you.</p> : <><p className="mt-3 ng-num text-3xl">${it.amount?.toFixed(2)}</p><button className={btn} onClick={() => H.act(it.id, 'paid', me.name, role, {}, `Paid $${it.amount?.toFixed(2)} by card •••• 4242 (simulated)`)} data-testid="pp-pay">Pay with card •••• 4242 (simulated)</button><p className="mt-2 text-[11px] text-[#7a6a5d]">Bills from your practice are never part of any paid plan.</p></>)}
    {it.kind === 'reminder' && (done ? <p className={ok} data-testid="imx-task-done">Confirmed.</p> : <button className={btn} onClick={() => H.act(it.id, 'confirmed', me.name, role, {}, `Appointment confirmed: ${it.title}`)} data-testid="pp-confirm">Confirm appointment</button>)}
    {it.kind === 'result' && lab && <div className="mt-3 ng-card p-3" data-testid="imx-task-result"><div className="flex items-baseline justify-between gap-2"><b className="text-sm">{lab.name}</b><span className={`ng-chip-s ${abn ? 'warm' : 'ok'}`}>{abn ? 'Outside the usual range' : 'In range'}</span></div>
      <div className="ng-num text-2xl mt-1">{lab.value} <span className="text-sm text-[#7a6a5d]">{lab.unit}</span></div><div className="text-xs text-[#7a6a5d]">Reference range {lab.low}–{lab.high} {lab.unit}</div>
      <Spectrum l={lab} />
      {abn && <p className="mt-2 ng-calm" data-testid="imx-calm">{CALM}</p>}
      {ex ? <p className="mt-2 ng-explain" data-testid="pp-lab-explain">{ex}</p> : <button className="mt-2 ng-link text-xs" onClick={() => setEx(S.explainLab({ ...lab, id: 'x', source: it.practiceName }))} data-testid="imx-explain">Explain in plain English (free: sent by your practice)</button>}
      <button className={btn} onClick={() => go({ view: 'portal', section: 'labs', focus: lab.name })} data-testid="imx-task-labs">Open in My Labs with trend</button></div>}
    {it.kind === 'document' && <button className={btn} onClick={() => go({ view: 'portal', section: 'docs' })} data-testid="imx-task-docs">Open in Documents</button>}
    {(it.kind === 'message' || it.kind === 'refill-reply') && <div className="mt-3 space-y-2"><textarea aria-label="Reply" className="ng-input w-full" rows={3} value={rep} onChange={e => setRep(e.target.value)} placeholder={`Reply to ${it.practiceName}`} data-testid="imx-reply-text" />
      <button className={btn} disabled={!rep.trim()} onClick={() => { H.patientSend(a.id, it.practiceId, 'message', 'Reply', rep.trim(), me.name, role, it.id); setRep(''); go({ view: 'portal', section: 'messages' }); }} data-testid="imx-reply-send">Send reply</button></div>}
    <p className="mt-3 text-[11px] text-[#9a8a7c] break-all">Direct link (what a text or email opens): {taskLink(it.id)}</p>
  </Modal>;
}

/* ---------- 2a) Timeline: health journal ---------- */
const NODE: Record<Ev['kind'], [typeof Bell, string, string]> = { form: [ClipboardList, 'plum', 'At-home form'], checkin: [CalendarCheck, 'green', 'Office visit'], reminder: [CalendarCheck, 'green', 'Office visit'], appt: [CalendarCheck, 'green', 'Appointment'], bill: [CreditCard, 'amber', 'Bill'], message: [MessageSquare, 'sky', 'Message'], refill: [Pill, 'terra', 'Refill'], result: [FlaskConical, 'peach', 'Lab result'], labs: [FlaskConical, 'peach', 'Lab results'], document: [FileText, 'stone', 'Document'], connect: [Link2, 'green', 'Connection'], request: [InboxIcon, 'stone', 'Records request'] };
const TONE: Record<Ev['tone'], string> = { todo: 'warm', done: 'ok', info: 'plain', flag: 'peach' };
type Filter = 'all' | 'todo' | 'appts' | 'results' | 'docs' | 'messages' | 'payments';
const FILTERS: [Filter, string, (e: Ev) => boolean][] = [['all', 'All', () => true], ['todo', 'To do', e => e.tone === 'todo'], ['appts', 'Visits', e => ['checkin', 'reminder', 'appt'].includes(e.kind)], ['results', 'Labs', e => e.kind === 'labs'], ['docs', 'Documents', e => e.kind === 'document' || e.kind === 'form'], ['messages', 'Messages', e => ['message', 'refill'].includes(e.kind)], ['payments', 'Payments', e => e.kind === 'bill']];
const summary = (e: Ev) => e.labs ? e.labs.map(l => `${l.name} ${l.value} ${l.unit}`).slice(0, 3).join(' · ') : e.doc ? (e.doc.explained ? e.doc.explained : `${e.doc.type}${e.doc.size ? ' · ' + e.doc.size : ''}`) : e.body || (e.kind === 'connect' ? 'Your records from this practice sync into your Portal.' : e.kind === 'request' ? 'A request for copies of your records.' : '');
const age = (dob: string) => { const d = new Date(dob); const n = new Date(); let y = n.getFullYear() - d.getFullYear(); if (n < new Date(n.getFullYear(), d.getMonth(), d.getDate())) y--; return y; };
function Glance({ p }: { p: PX }) {
  const { a } = p; const first = a.name.split(' ')[0]; const docs = H.linksFor(a.id).filter(l => l.status === 'active'); const t = pendingTasks(a.id);
  const conds = (a.history || []).slice(0, 3);
  return <aside className="ng-card p-4 space-y-4 min-w-0" data-testid="imx-glance" aria-label="You at a glance">
    <div className="flex items-center gap-3"><Avatar name={a.name} big /><div className="min-w-0"><div className="ng-name truncate">{a.name}</div><div className="text-xs text-[#7a6a5d]">{age(a.dob)} years old</div></div></div>
    <p className="text-[13.5px] leading-relaxed text-[#5b4a3e]" data-testid="imx-glance-sentence">{first} sees {docs.length ? docs.map(d => d.doctor || d.practiceName).join(' and ') : 'no connected doctors yet'}{conds.length ? `, and is keeping track of ${conds.join(', ').toLowerCase()}` : ''}. {a.meds.length ? `${a.meds.length} medicine${a.meds.length > 1 ? 's' : ''} on file.` : ''}</p>
    <div><div className="ng-sidehead !px-0">Today</div>{t.length ? <ul className="space-y-1">{t.slice(0, 3).map(x => <li key={x.id}><button className="ng-link text-[13px] text-left" onClick={() => go({ view: 'task', id: x.id })}>{x.title}</button></li>)}</ul> : <p className="text-[13px] text-[#7a6a5d]">Nothing to do today.</p>}</div>
    <div><div className="ng-sidehead !px-0">Allergies</div><p className="text-[13px] text-[#5b4a3e]">{a.allergies.length ? a.allergies.map(x => x.name).join(', ') : 'None recorded'}</p></div>
    <div><div className="ng-sidehead !px-0">My doctors</div>{docs.length ? <ul className="text-[13px] text-[#5b4a3e] space-y-0.5">{docs.map(d => <li key={d.id}>{d.doctor} · {d.practiceName}</li>)}</ul> : <button className="ng-link text-[13px]" onClick={() => go({ view: 'portal', section: 'connect' })}>Connect my doctor</button>}</div>
  </aside>;
}
function EventCard({ e, open, setOpen, ex, explain }: { e: Ev; open: boolean; setOpen: () => void; ex?: string; explain: () => void }) {
  const [Ic, col, tag] = NODE[e.kind];
  return <li className="ng-ev" data-testid={`imx-ev-${e.kind}`}>
    <span className={`ng-node ${col}`} aria-hidden="true"><Ic className="w-3.5 h-3.5" /></span>
    <div className={`ng-evcard ${e.tone === 'todo' ? 'todo' : ''}`}>
      <button className="w-full text-left px-3.5 py-3" aria-expanded={open} onClick={setOpen} data-testid="imx-ev-toggle">
        <span className="flex items-center gap-2 flex-wrap"><span className={`ng-type ${col}`}>{e.upcoming ? 'Upcoming ' : ''}{tag}</span><span className="text-[11.5px] text-[#9a8a7c] flex items-center gap-1"><CalendarCheck className="w-3 h-3" aria-hidden="true" />{fmt(e.date.slice(0, 10))}</span>
          <span className={`ml-auto ng-chip-s ${TONE[e.tone]}`} data-testid="imx-ev-status">{e.status}</span></span>
        <span className="flex items-start gap-2 mt-1"><span className="min-w-0 flex-1"><span className="block text-[14.5px] font-semibold text-[#2b211b] truncate">{e.title}</span><span className="block text-[12px] text-[#7a6a5d] truncate">{e.practice}</span>
          {summary(e) && <span className="block text-[12.5px] text-[#5b4a3e] truncate mt-0.5" data-testid="imx-ev-summary">{summary(e)}</span>}</span>
          <ChevronDown className={`w-4 h-4 text-[#9a8a7c] shrink-0 mt-1 transition-transform ${open ? 'rotate-180' : ''}`} aria-hidden="true" /></span></button>
      {open && <div className="px-3.5 pb-3.5 text-sm text-[#5b4a3e] space-y-2" data-testid="imx-ev-body">
        {e.body && <p>{e.body}</p>}
        {e.labs && <div className="space-y-2">{e.labs.map(l => <div key={l.id}><div className="flex justify-between gap-2 text-[13px]"><span>{l.name}</span><span className="ng-num">{l.value} {l.unit} <span className="text-[#9a8a7c] font-normal">({l.low}–{l.high})</span></span></div><Spectrum l={l} /></div>)}</div>}
        {ex && <p className="ng-explain whitespace-pre-line" data-testid="imx-ev-explained">{ex}</p>}
        {e.doc?.explained && !ex && <p className="ng-explain">{e.doc.explained}</p>}
        <div className="flex flex-wrap gap-2">
          {e.item && e.item.from === 'practice' && <button className="ng-btn sm" onClick={() => go({ view: 'task', id: e.item!.id })} data-testid="imx-ev-open">{e.tone === 'todo' ? ({ form: 'Fill out form', checkin: 'Check in', bill: 'Pay now', reminder: 'Confirm' } as Record<string, string>)[e.item.kind] || 'Open' : 'Open'}</button>}
          {(e.kind === 'labs' || (e.kind === 'document' && !e.doc?.explained)) && !ex && <button className="ng-btn soft sm" onClick={explain} data-testid="imx-ev-explain">Explain in plain English</button>}
          {e.kind === 'labs' && <button className="ng-btn ghost sm" onClick={() => go({ view: 'portal', section: 'labs', focus: e.id })} data-testid="imx-ev-labs">Open in My Labs</button>}
          {e.kind === 'document' && <button className="ng-btn ghost sm" onClick={() => go({ view: 'portal', section: 'docs' })}>Documents</button>}
          {e.kind === 'connect' && <button className="ng-btn ghost sm" onClick={() => go({ view: 'portal', section: 'care' })}>Care team</button>}
          {(e.kind === 'message' || e.kind === 'refill') && <button className="ng-btn ghost sm" onClick={() => go({ view: 'portal', section: 'messages' })}>Messages</button>}
        </div></div>}
    </div></li>;
}
function Timeline({ p, focus }: { p: PX; focus?: string }) {
  const { a, save } = p; const evs = timeline(a); const [f, setF] = useState<Filter>('all'); const [open, setOpen] = useState<string | null>(focus || null); const [ex, setEx] = useState<Record<string, string>>({}); const [msg, setMsg] = useState('');
  const shown = evs.filter(FILTERS.find(x => x[0] === f)![2]); const up = shown.filter(e => e.upcoming); const past = shown.filter(e => !e.upcoming); const todo = evs.filter(e => e.tone === 'todo').length;
  const explain = (e: Ev) => {
    const fromP = e.kind === 'labs' ? e.labs!.every(l => l.source.includes('Vityls practice')) : !!e.doc?.fromPractice;
    if (!S.canExplain(a, fromP)) { setMsg(`You've used your ${S.FREE_EXPLAIN_LIMIT} free explanations this month. Portal Plus is unlimited. Anything your practice sends is always explained free.`); return; }
    save(x => { S.useExplain(x, fromP); if (e.doc) { const d = x.docs.find(y => y.id === e.doc!.id); if (d) d.explained = S.explainDoc(d); } });
    setEx({ ...ex, [e.id]: e.kind === 'labs' ? e.labs!.map(l => S.explainLab(l)).join('\n\n') + (e.labs!.some(l => S.labFlag(l) !== 'normal') ? '\n\n' + CALM : '') : S.explainDoc(e.doc!) }); setMsg('');
  };
  const list = (l: Ev[]) => { let yr = ''; return <ol className="ng-line">{l.map(e => { const y = e.date.slice(0, 4); const mark = y !== yr; yr = y; return <Fragment key={e.id}>{mark && <li className="ng-year" aria-hidden="true">{y}</li>}<EventCard e={e} open={open === e.id} setOpen={() => setOpen(open === e.id ? null : e.id)} ex={ex[e.id]} explain={() => explain(e)} /></Fragment>; })}</ol>; };
  return <div className="grid grid-cols-1 xl:grid-cols-[17rem_1fr] gap-6 items-start">
    <Glance p={p} />
    <div data-testid="imx-timeline" className="min-w-0">
      <div className="flex flex-wrap items-baseline justify-between gap-2 mb-1"><h2 className="ng-h1">{a.name.split(' ')[0]}'s health journal</h2><span className="text-[11px] text-[#9a8a7c]" data-testid="imx-tl-count">{shown.length} events</span></div>
      <p className="text-[13px] text-[#7a6a5d] mb-4">Everything from every doctor, in one line. Tap a card for details.</p>
      {todo > 0 && f !== 'todo' && <div className="mb-4"><NgLine testid="imx-tl-offer">You have {todo} thing{todo > 1 ? 's' : ''} left to do. Want me to show you? <button className="ng-link" onClick={() => setF('todo')} data-testid="imx-tl-offer-go">Show me</button></NgLine></div>}
      <div className="flex flex-wrap gap-1.5 mb-4" role="tablist" aria-label="Filter timeline">{FILTERS.map(([k, l]) => <button key={k} role="tab" aria-selected={f === k} onClick={() => setF(k)} className={`ng-pill ${f === k ? 'on' : ''}`} data-testid={`imx-tl-f-${k}`}>{l}</button>)}</div>
      {msg && <p className="ng-note mb-2" data-testid="pp-limit">{msg}</p>}
      {!shown.length && <p className="ng-card p-4 text-sm text-[#7a6a5d]" data-testid="imx-tl-empty">Nothing here yet. When you connect a doctor or a Vityls practice sends you something, it shows up on your timeline.</p>}
      {up.length > 0 && <section data-testid="imx-tl-upcoming" aria-label="Upcoming" className="mb-5"><h3 className="ng-sechead">Upcoming</h3>{list(up)}</section>}
      {past.length > 0 && <section data-testid="imx-tl-past" aria-label="Past"><h3 className="ng-sechead">Past</h3>{list(past)}</section>}
    </div></div>;
}

/* ---------- My Labs ---------- */
function LabsSection({ p, focus }: { p: PX; focus?: string }) {
  const { a, save } = p; const panels = labPanels(a); const [sel, setSel] = useState<string | null>(focus && focus.startsWith('labs:') ? focus : null); const [ex, setEx] = useState<Record<string, string>>({}); const [msg, setMsg] = useState('');
  const analytes: Record<string, Lab[]> = {}; a.labs.forEach(l => (analytes[l.name] ||= []).push(l));
  const panel = panels.find(x => x.id === sel);
  useEffect(() => { if (focus && !focus.startsWith('labs:')) document.getElementById('imx-an-' + focus.replace(/\W+/g, '-'))?.scrollIntoView({ block: 'center' }); }, [focus]);
  const explain = (l: Lab) => { const fromP = l.source.includes('Vityls practice'); if (!S.canExplain(a, fromP)) { setMsg(`You've used your ${S.FREE_EXPLAIN_LIMIT} free explanations this month. Portal Plus is unlimited. Results your practice sends are always explained free.`); return; } save(x => S.useExplain(x, fromP)); setEx({ ...ex, [l.id]: S.explainLab(l) }); setMsg(''); };
  return <div data-testid="pp-labs"><h2 className="ng-h1">My Labs</h2><p className="text-[13px] text-[#7a6a5d] mb-4">Every lab from every source, newest first. The green band shows each test's usual range.</p>
    {msg && <p className="ng-note mb-2" data-testid="pp-limit">{msg}</p>}
    {!panels.length && <p className="ng-card p-4 text-sm">No labs yet. Connect my doctor or upload a lab report with the + in the chat.</p>}
    {panels.length > 0 && <div className="ng-card overflow-x-auto"><table className="w-full text-[13px] min-w-[34rem]" data-testid="imx-labs-table"><thead className="text-[#9a8a7c] text-left text-[11.5px]"><tr><th className="p-2.5 font-medium">Date</th><th className="p-2.5 font-medium">Tests</th><th className="p-2.5 font-medium">Source</th><th className="p-2.5 font-medium">Flag</th><th className="p-2.5"><span className="sr-only">Open</span></th></tr></thead>
      <tbody>{panels.map(x => <tr key={x.id} className={`border-t border-[#f0e6da] ${sel === x.id ? 'bg-[#fbf3e8]' : ''}`} data-testid="imx-labs-row"><td className="p-2.5 whitespace-nowrap">{fmt(x.date)}</td><td className="p-2.5">{x.labs.map(l => l.name).join(', ')}</td><td className="p-2.5">{srcName(x.source)}</td><td className="p-2.5">{x.abnormal.length ? <span className="ng-chip-s peach" data-testid="imx-labs-flag">{x.abnormal.length} outside range</span> : <span className="ng-chip-s ok">In range</span>}</td><td className="p-2.5"><button className="ng-link" onClick={() => setSel(sel === x.id ? null : x.id)} data-testid="imx-labs-view">{sel === x.id ? 'Close' : 'View result'}</button></td></tr>)}</tbody></table></div>}
    {panel && <div className="mt-3 ng-card p-4" data-testid="imx-lab-result"><div className="ng-h3">Result · {fmt(panel.date)} · {srcName(panel.source)}</div>
      {panel.abnormal.length > 0 && <p className="mt-2 ng-calm" data-testid="imx-calm">{CALM}</p>}
      {panel.labs.map(l => <div key={l.id} className="mt-3 border-t border-[#f0e6da] pt-3"><div className="flex flex-wrap justify-between gap-2 text-sm"><b>{l.name}</b><span className="ng-num">{l.value} {l.unit} <span className="text-[#9a8a7c] font-normal">({l.low}–{l.high})</span></span></div><Spectrum l={l} />
        {ex[l.id] ? <p className="ng-explain mt-2" data-testid="pp-lab-explain">{ex[l.id]}</p> : <button className="ng-link text-xs mt-1" onClick={() => explain(l)} data-testid="pp-lab-explain-btn">Explain in plain English</button>}</div>)}</div>}
    <h3 className="ng-sechead mt-6">Trends by test</h3>
    <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-3">{Object.entries(analytes).map(([n, l]) => { const last = [...l].sort((x, y) => y.date.localeCompare(x.date))[0]; const fl = S.labFlag(last); return <div key={n} id={'imx-an-' + n.replace(/\W+/g, '-')} className={`ng-card p-3.5 min-w-0 ${focus === n ? 'ring-2 ring-[#1f5f4a]/25' : ''}`} data-testid={`pp-lab-${n.replace(/\s+/g, '-')}`}>
      <div className="flex justify-between items-center gap-2"><b className="text-sm">{n}</b><span className={`ng-chip-s ${fl === 'normal' ? 'ok' : 'peach'}`}>{fl === 'normal' ? 'In range' : fl === 'high' ? 'Above range' : 'Below range'}</span></div>
      <div className="ng-num text-xl">{last.value} <span className="text-xs text-[#7a6a5d] font-normal">{last.unit}</span></div><div className="text-[11px] text-[#9a8a7c]">{fmt(last.date)} · {srcName(last.source)} · {l.length} result{l.length > 1 ? 's' : ''}</div>
      <Spectrum l={last} />
      <div className="imx-trend overflow-hidden mt-2"><Trend pts={l} /></div>
      {fl !== 'normal' && <p className="text-[11.5px] text-[#7a6a5d]">Worth discussing with your doctor; one value outside the range is common.</p>}</div>; })}</div></div>;
}

/* ---------- My Health: conditions, wearables & journal ---------- */
function Conditions({ p }: { p: PX }) {
  const { a, save } = p; const [n, setN] = useState('');
  const add = () => { const t = n.trim(); if (!t) return; save(x => { x.history = [...(x.history || []), t]; x.audit.push({ at: S.nowIso(), what: `Added condition: ${t}` }); }); setN(''); };
  return <section className="ng-card p-4 mt-4" data-testid="imx-conditions"><h3 className="ng-h3">Conditions</h3><p className="text-[12.5px] text-[#7a6a5d] mb-2">What you and your doctors keep track of. Nightingale uses this to explain things in context; she does not diagnose.</p>
    {(a.history || []).length ? <ul className="flex flex-wrap gap-1.5 mb-2">{a.history!.map((c, i) => <li key={i} className="ng-chip-s plain" data-testid="imx-cond-name">{c}</li>)}</ul> : <p className="text-sm text-[#7a6a5d] mb-2">None recorded.</p>}
    <div className="flex gap-2"><input aria-label="Add a condition" className="ng-input flex-1 min-w-0" value={n} onChange={e => setN(e.target.value)} onKeyDown={e => e.key === 'Enter' && add()} placeholder="e.g. High blood pressure" /><button className="ng-btn sm" onClick={add} data-testid="imx-cond-add">Add</button></div></section>;
}
function Wearables({ p }: { p: PX }) {
  const { a, save } = p; const plus = S.isPlus(a); const [t, setT] = useState('');
  const add = () => { const v = t.trim(); if (!v) return; save(x => { x.symptoms.unshift({ id: S.uid('sy-'), text: v, at: S.nowIso() }); x.audit.push({ at: S.nowIso(), what: 'Journal entry added' }); }); setT(''); };
  return <div className="space-y-4"><h2 className="ng-h1">Wearables & journal</h2>
    <section className="ng-card p-4" data-testid="imx-wearables"><h3 className="ng-h3">Wearables & devices {!plus && <span className="ng-tag">Plus</span>}</h3>
      {plus ? <><p className="text-[12.5px] text-[#7a6a5d] mb-2">Simulated device data (fictional).</p><div className="grid sm:grid-cols-3 gap-2">{[['Apple Health', 'Steps 7,842 · resting HR 61'], ['Omron BP cuff', '128/79 this morning'], ['Fitbit', 'Sleep 6 h 50 m']].map(([n, v]) => <div key={n} className="ng-soft p-3" data-testid="imx-wearable"><b className="text-sm block">{n}</b><span className="text-[13px] text-[#5b4a3e]">{v}</span></div>)}</div></>
        : <p className="text-sm text-[#5b4a3e]" data-testid="imx-wearables-locked">Connect Apple Health, Fitbit and home devices with Portal Plus. <button className="ng-link" onClick={() => go({ view: 'portal', section: 'plan' })}>Try it free for 14 days</button>.</p>}</section>
    <section className="ng-card p-4" data-testid="imx-journal"><h3 className="ng-h3">My journal</h3><p className="text-[12.5px] text-[#7a6a5d] mb-2">Note how you feel, in your own words. Handy to bring to a visit. Always free.</p>
      <div className="flex gap-2"><input aria-label="Journal entry" className="ng-input flex-1 min-w-0" value={t} onChange={e => setT(e.target.value)} onKeyDown={e => e.key === 'Enter' && add()} placeholder="e.g. Slept badly, mild headache in the morning" data-testid="imx-journal-text" /><button className="ng-btn sm" onClick={add} data-testid="imx-journal-add">Add</button></div>
      <ul className="mt-3 space-y-1.5">{a.symptoms.slice(0, 12).map(s => <li key={s.id} className="text-[13px] text-[#5b4a3e]"><span className="text-[#9a8a7c] mr-2">{fmtT(s.at)}</span>{s.text}</li>)}</ul></section></div>;
}

/* ---------- Messages: appointments ---------- */
function Appointments({ p }: { p: PX }) {
  const { a, me, role } = p; const its = H.itemsFor(a.id).filter(i => ['checkin', 'reminder', 'appt-request'].includes(i.kind)).sort((x, y) => (y.due || y.at).localeCompare(x.due || x.at));
  const links = H.linksFor(a.id).filter(l => l.status === 'active'); const [pid, setPid] = useState(links[0]?.practiceId || ''); const [why, setWhy] = useState(''); const [sent, setSent] = useState('');
  const req = () => { if (!pid || !why.trim()) return; const r = H.patientSend(a.id, pid, 'appt-request', 'Appointment request', why.trim(), me.name, role); setSent(typeof r === 'string' ? r : 'Sent. The practice will reply here and in Messages.'); setWhy(''); };
  return <div data-testid="imx-appointments"><h2 className="ng-h1">Appointments</h2><p className="text-[13px] text-[#7a6a5d] mb-4">Upcoming visits, check-ins and requests.</p>
    {!its.length ? <p className="ng-card p-4 text-sm">No appointments yet.</p> : <ul className="space-y-2">{its.map(i => <li key={i.id} className="ng-card px-4 py-3 flex flex-wrap items-center gap-3" data-testid="imx-appt-row"><CalendarCheck className="w-4 h-4 text-[#1f5f4a]" aria-hidden="true" /><div className="min-w-0 flex-1"><div className="text-sm font-semibold truncate">{i.title}</div><div className="text-[12px] text-[#7a6a5d]">{i.practiceName}{i.due ? ` · ${fmt(i.due)}` : ''}</div></div><span className={`ng-chip-s ${isOpen(i) ? 'warm' : 'ok'}`}>{isOpen(i) ? (i.from === 'patient' ? 'Requested' : 'To do') : 'Done'}</span>{isOpen(i) && i.from === 'practice' && <button className="ng-btn sm" onClick={() => go({ view: 'task', id: i.id })}>Open</button>}</li>)}</ul>}
    {links.length > 0 && <section className="ng-card p-4 mt-4"><h3 className="ng-h3 mb-2">Request an appointment</h3><div className="flex flex-wrap gap-2"><select aria-label="Practice" className="ng-input" value={pid} onChange={e => setPid(e.target.value)}>{links.map(l => <option key={l.id} value={l.practiceId}>{l.practiceName}</option>)}</select><input aria-label="Reason for visit" className="ng-input flex-1 min-w-[12rem]" value={why} onChange={e => setWhy(e.target.value)} placeholder="Reason, and days that work for you" /><button className="ng-btn sm" onClick={req} data-testid="imx-appt-request">Send request</button></div>{sent && <p className="text-[12.5px] ng-ok mt-2">{sent}</p>}</section>}</div>;
}

/* ---------- profile menu pages: billing, settings, notifications ---------- */
function Billing({ p }: { p: PX }) {
  const bills = H.itemsFor(p.a.id).filter(i => i.kind === 'bill');
  return <div data-testid="imx-billing"><h2 className="ng-h1">Billing</h2><p className="text-[13px] text-[#7a6a5d] mb-4">Bills from your practices. Practice bills are never part of any paid plan. Payments are simulated in this build.</p>
    {!bills.length ? <p className="ng-card p-4 text-sm">No bills.</p> : <ul className="space-y-2">{bills.map(b => <li key={b.id} className="ng-card px-4 py-3 flex flex-wrap items-center gap-3" data-testid="imx-bill-row"><CreditCard className="w-4 h-4 text-[#c08a2b]" aria-hidden="true" /><div className="min-w-0 flex-1"><div className="text-sm font-semibold truncate">{b.title}</div><div className="text-[12px] text-[#7a6a5d]">{b.practiceName} · {fmt(b.at.slice(0, 10))}</div></div><span className="ng-num">${(b.amount || 0).toFixed(2)}</span>{isOpen(b) ? <button className="ng-btn sm" onClick={() => go({ view: 'task', id: b.id })} data-testid="imx-bill-pay">Pay</button> : <span className="ng-chip-s ok">Paid</span>}</li>)}</ul>}
    <p className="text-[12.5px] text-[#7a6a5d] mt-4">Your Vityls plan: {S.isPlus(p.a) ? 'Portal Plus' : 'Free'}. <button className="ng-link" onClick={() => go({ view: 'portal', section: 'plan' })}>Manage plan</button></p></div>;
}
function SettingsPage({ p }: { p: PX }) {
  const { me, save, a } = p; const pr = a.prefs || { text: true, email: true };
  const set = (k: 'text' | 'email', v: boolean) => save(x => { x.prefs = { ...(x.prefs || { text: true, email: true }), [k]: v }; x.audit.push({ at: S.nowIso(), what: `Notification by ${k} turned ${v ? 'on' : 'off'}` }); });
  return <div data-testid="imx-settings"><h2 className="ng-h1">Settings</h2>
    <section className="ng-card p-4 mt-3"><h3 className="ng-h3">Account</h3><p className="text-sm text-[#5b4a3e] mt-1">{me.name} · {me.email}</p><p className="text-[12px] text-[#7a6a5d] mt-1">This account is yours, not any doctor's office.</p></section>
    <section className="ng-card p-4 mt-3"><h3 className="ng-h3">How we tell you about new items</h3><p className="text-[12.5px] text-[#7a6a5d] mb-2">Texts and emails only say "you have a new item" with a link that opens it here after you sign in. No health details are sent. Simulated in this build.</p>
      {(['text', 'email'] as const).map(k => <label key={k} className="flex items-center gap-2 text-sm py-1"><input type="checkbox" checked={pr[k]} onChange={e => set(k, e.target.checked)} data-testid={`imx-pref-${k}`} />{k === 'text' ? 'Text message' : 'Email'}</label>)}</section></div>;
}
function Alerts({ p }: { p: PX }) {
  const l = H.noticesFor(p.me.id);
  useEffect(() => { if (l.some(n => !n.read)) setTimeout(() => H.markRead(p.me.id), 1500); }, []);
  return <div data-testid="pp-alerts"><h2 className="ng-h1">Notifications</h2><p className="text-[13px] text-[#7a6a5d] mb-4">Nightingale also mentions new items in the chat. Texts and emails only say "you have a new item, sign in to view" (simulated in this build).</p>
    {!l.length && <p className="ng-card p-4 text-sm">Nothing yet.</p>}
    <ul className="space-y-1.5">{l.map(n => <li key={n.id} className={`ng-card px-3.5 py-2.5 text-sm ${n.read ? '' : 'unread'}`} data-testid={`pp-notice-${n.kind}`}><div className="flex justify-between gap-2 text-[11px] text-[#9a8a7c]"><b className="text-[#5b4a3e]">{n.profileAcct === p.me.id ? 'You' : n.profileName}</b><span>{fmtT(n.at)}</span></div>{n.text}</li>)}</ul></div>;
}

/* ---------- search (chats + timeline) ---------- */
function SearchModal({ p, onClose }: { p?: PX; onClose: () => void }) {
  const [q, setQ] = useState(''); const t = q.trim().toLowerCase();
  const chats = p ? [{ id: '__cur', title: 'Current chat', msgs: p.a.chat }, ...(p.a.chats || [])].filter(c => t && c.msgs.some(m => m.text.toLowerCase().includes(t))) : [];
  const evs = p && t ? timeline(p.a).filter(e => (e.title + ' ' + e.practice + ' ' + summary(e)).toLowerCase().includes(t)).slice(0, 8) : [];
  return <Modal title="Search" onClose={onClose} testid="imx-search">
    <input autoFocus aria-label="Search chats and records" className="ng-input w-full" placeholder={p ? 'Search chats, labs, documents, messages' : 'Sign in to search your records'} value={q} onChange={e => setQ(e.target.value)} data-testid="imx-search-q" />
    {t && !chats.length && !evs.length && <p className="text-sm text-[#7a6a5d] mt-3">No matches.</p>}
    {chats.length > 0 && <><div className="ng-sidehead !px-0 mt-3">Chats</div>{chats.map(c => <button key={c.id} className="ng-menuitem w-full" onClick={() => { onClose(); if (c.id !== '__cur') openChat(c.id, p!.save); else go({ view: 'chat' }); }} data-testid="imx-search-chat">{c.title}</button>)}</>}
    {evs.length > 0 && <><div className="ng-sidehead !px-0 mt-3">Timeline</div>{evs.map(e => <button key={e.id} className="ng-menuitem w-full" onClick={() => { onClose(); go(e.item && e.item.from === 'practice' ? { view: 'task', id: e.item.id } : { view: 'portal', section: 'timeline', focus: e.id }); }} data-testid="imx-search-ev"><span className="truncate">{e.title}</span><span className="ml-auto text-[11px] text-[#9a8a7c] shrink-0">{fmt(e.date.slice(0, 10))}</span></button>)}</>}
  </Modal>;
}

/* ---------- 2b) Portal page ---------- */
const TITLE: Partial<Record<Section, string>> = Object.fromEntries([...NAV_TREE.flatMap(g => g.items), ...PROFILE_MENU]) as Partial<Record<Section, string>>;
function PortalPage({ p, section, focus }: { p: PX; section: Section; focus?: string }) {
  const legacy = (n: ReactNode) => <div className="imx-legacy">{n}</div>;
  return <main className="ng-main portal" data-testid="portal-app">
    {p.role === 'caregiver' && <p className="ng-note mb-4" data-testid="pp-caregiver-banner">You are acting for {p.a.name}. Everything you do is recorded in {p.a.name.split(' ')[0]}'s history.</p>}
    <section className="min-w-0" aria-label={TITLE[section]}>
      {section === 'timeline' && <Timeline p={p} focus={focus} />}
      {section === 'labs' && <LabsSection p={p} focus={focus} />}
      {section === 'messages' && legacy(<Inbox {...p} />)}
      {section === 'appointments' && <Appointments p={p} />}
      {section === 'care' && legacy(<CareTeam {...p} />)}
      {section === 'finder' && legacy(<Finder acct={p} />)}
      {section === 'connect' && legacy(<Connect {...p} />)}
      {section === 'docs' && legacy(<Docs {...p} />)}
      {section === 'meds' && <>{legacy(<Meds {...p} />)}<Conditions p={p} /></>}
      {section === 'wearables' && <Wearables p={p} />}
      {section === 'family' && legacy(<Family {...p} refresh={p.refresh!} />)}
      {section === 'history' && legacy(<History {...p} />)}
      {section === 'alerts' && <Alerts p={p} />}
      {section === 'plan' && legacy(<PlanPage {...p} />)}
      {section === 'billing' && <Billing p={p} />}
      {section === 'settings' && <SettingsPage p={p} />}
    </section>
    <p className="mt-10 text-center text-[11px] text-[#b3a395]">Test build · fictional data · every connection is simulated until a BAA is signed · module patient-portal</p>
  </main>;
}

/* ---------- root ---------- */
const PAGE_TO: Record<Page, Route> = { home: { view: 'chat' }, finder: { view: 'portal', section: 'finder' }, inbox: { view: 'portal', section: 'messages' }, care: { view: 'portal', section: 'care' }, labs: { view: 'portal', section: 'labs' }, docs: { view: 'portal', section: 'docs' }, meds: { view: 'portal', section: 'meds' }, connect: { view: 'portal', section: 'connect' }, family: { view: 'portal', section: 'family' }, history: { view: 'portal', section: 'history' }, alerts: { view: 'portal', section: 'alerts' }, plan: { view: 'portal', section: 'plan' } };
export function ImarsPortal() {
  const [ready, setReady] = useState(false);
  useEffect(() => { if (location.search.includes('reset-portal')) S.resetPortal(); else S.seedPortal(); setReady(true); }, []);
  const route = useRoute(); const d = usePortalData(); const [auth, setAuth] = useState<null | { mode: 'in' | 'up'; reason?: string }>(null);
  const [drawer, setDrawer] = useState(false); const [search, setSearch] = useState(false); const [gFinder, setGFinder] = useState(false);
  useEffect(() => { if (ready && !d.me && route.view === 'task') setAuth({ mode: 'in', reason: 'Your doctor\'s office sent you something. Sign in to view it; it opens right after.' }); }, [ready, route.view, !!d.me]);
  useEffect(() => { window.scrollTo(0, 0); setDrawer(false); }, [route.view, (route as any).section]);
  if (!ready) return null;
  const onAuth = (mode: 'in' | 'up', reason?: string) => setAuth({ mode, reason });
  const authEl = auth && <div className="imx-legacy"><Auth mode={auth.mode} reason={auth.reason} onClose={() => setAuth(null)} onDone={() => { setAuth(null); setDrawer(false); d.refresh(); }} /></div>;
  if (!d.me) return <div className="imx ng-app" data-testid="pp-guest">
    <Sidebar guest onAuth={onAuth} route={{ view: 'chat' }} open={drawer} setOpen={setDrawer} onSearch={() => setSearch(true)} onGuestFinder={() => setGFinder(true)} />
    <div className="ng-body"><TopBar setOpen={setDrawer} guest title={gFinder ? 'Find a doctor' : ''} />
      {gFinder ? <main className="ng-main portal"><button className="ng-link text-[13px] mb-3" onClick={() => setGFinder(false)} data-testid="imx-guest-back">← Back to Nightingale</button><div className="imx-legacy"><Finder onNeed={r => onAuth('up', r)} /></div></main> : <GuestChat onAuth={onAuth} />}</div>
    {search && <SearchModal onClose={() => setSearch(false)} />}{authEl}</div>;
  const { me, a, role, grants, save, refresh, unread } = d as Extract<typeof d, { a: Account }>;
  const p: PX = { a, me, save, role, go: (pg: Page) => go(PAGE_TO[pg]), grants, refresh };
  const title = route.view === 'chat' ? '' : route.view === 'task' ? 'Timeline' : TITLE[route.section] || '';
  return <div className="imx ng-app">
    <Sidebar p={p} route={route} open={drawer} setOpen={setDrawer} onSearch={() => setSearch(true)} />
    <div className="ng-body"><TopBar setOpen={setDrawer} unread={unread} title={title} />
      {route.view === 'chat' && <ChatPage p={p} />}
      {route.view === 'portal' && <PortalPage p={p} section={route.section} focus={route.focus} />}
      {route.view === 'task' && <><PortalPage p={p} section="timeline" /><TaskPanel key={route.id} p={p} id={route.id} /></>}
    </div>
    {search && <SearchModal p={p} onClose={() => setSearch(false)} />}
  </div>;
}
