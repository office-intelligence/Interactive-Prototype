/*
 * Portal v0.4 (iMARSLINK design) · translation layer. The iMARSLINK screens never touch storage directly:
 * everything comes from the v0.3 Portal data layer (store.ts = patient account, hub.ts = practice items /
 * append-only interactions / notifications / caregivers, finder.ts = Doctor Finder) through this hook.
 * Module: `patient-portal` (src/core/modules.ts). Entitlements are per patient (Free / Plus), never per practice.
 */
import { useEffect, useState } from 'react';
import * as S from '../store';
import * as H from '../hub';
import type { Account, Lab, Doc } from '../store';

export const MODULE_ID = 'patient-portal';
export type Section = 'timeline' | 'labs' | 'messages' | 'care' | 'finder' | 'connect' | 'family' | 'history' | 'docs' | 'meds' | 'alerts' | 'plan' | 'wearables' | 'appointments' | 'billing' | 'settings';
/** v0.5 navigation: five headings with subsections; billing, plan and settings live in the profile menu. */
export const NAV_TREE: { id: string; label: string; items: [Section, string][] }[] = [
  { id: 'timeline', label: 'Timeline', items: [['timeline', 'Timeline']] },
  { id: 'doctors', label: 'My Doctors', items: [['care', 'Care team'], ['finder', 'Find a doctor'], ['connect', 'Connect & records']] },
  { id: 'labs', label: 'My Labs', items: [['labs', 'Results & trends']] },
  { id: 'health', label: 'My Health', items: [['meds', 'Medicines, allergies & conditions'], ['docs', 'Documents'], ['wearables', 'Wearables & journal'], ['family', 'Family access']] },
  { id: 'messages', label: 'Messages', items: [['messages', 'Messages & refills'], ['appointments', 'Appointments'], ['history', 'Activity history']] },
];
export const PROFILE_MENU: [Section, string][] = [['billing', 'Billing & payments'], ['plan', 'Plan · Upgrade to Plus'], ['alerts', 'Notifications'], ['settings', 'Settings']];
export type Route = { view: 'chat' } | { view: 'portal'; section: Section; focus?: string } | { view: 'task'; id: string };

/** Hash routes: #portal (chat) · #portal/view/<section>[/<focus>] · #portal/task/<itemId> (deep link from a text/email). */
export function parseRoute(hash = location.hash): Route {
  const m = hash.replace(/^#/, '').split('/');
  if (m[0] !== 'portal') return { view: 'chat' };
  if (m[1] === 'task' && m[2]) return { view: 'task', id: decodeURIComponent(m[2]) };
  if (m[1] === 'view' && m[2]) return { view: 'portal', section: m[2] as Section, focus: m[3] ? decodeURIComponent(m[3]) : undefined };
  return { view: 'chat' };
}
export const routeHash = (r: Route) => r.view === 'chat' ? '#portal' : r.view === 'task' ? `#portal/task/${encodeURIComponent(r.id)}` : `#portal/view/${r.section}${r.focus ? '/' + encodeURIComponent(r.focus) : ''}`;
export const go = (r: Route) => { const h = routeHash(r); if (location.hash !== h) location.hash = h; else window.dispatchEvent(new HashChangeEvent('hashchange')); };
/** The link a simulated practice text/email carries ("sign in to view"). */
export const taskLink = (itemId: string) => `${location.href.split('#')[0]}#portal/task/${encodeURIComponent(itemId)}`;

export function useRoute() {
  const [r, setR] = useState<Route>(parseRoute());
  useEffect(() => { const f = () => setR(parseRoute()); window.addEventListener('hashchange', f); return () => window.removeEventListener('hashchange', f); }, []);
  return r;
}
export function useHubTick() {
  const [, setN] = useState(0);
  useEffect(() => { const f = () => setN(n => n + 1); ['vityls-portal-hub', 'storage', 'focus'].forEach(e => window.addEventListener(e, f)); return () => ['vityls-portal-hub', 'storage', 'focus'].forEach(e => window.removeEventListener(e, f)); }, []);
}

/* ---------- entitlements (Free / Plus); practice items are never paywalled ---------- */
export function entitlements(a: Account) {
  const plus = S.isPlus(a);
  return { plan: plus ? (a.plan.state === 'trial' ? 'Plus trial' : 'Plus') : 'Free', plus, wearables: plus, reports: plus, unlimitedExplain: plus,
    explainLeft: plus ? Infinity : Math.max(0, S.FREE_EXPLAIN_LIMIT - a.plan.explainUsed), practiceItemsFree: true as const };
}

/* ---------- pending practice tasks (shown by Nightingale in the chat) ---------- */
export const TASK_KINDS: H.ItemKind[] = ['form', 'checkin', 'bill', 'reminder'];
export const isOpen = (i: H.Item) => ['sent', 'opened'].includes(i.status);
export function pendingTasks(acctId: string) { return H.itemsFor(acctId).filter(i => i.from === 'practice' && TASK_KINDS.includes(i.kind) && isOpen(i)); }
/** Things that arrived and haven't been looked at: results, documents, messages, refill replies. */
export function unseen(acctId: string) { return H.itemsFor(acctId).filter(i => i.from === 'practice' && ['result', 'document', 'message', 'refill-reply'].includes(i.kind) && i.status === 'sent'); }

/* ---------- timeline: every task, result, document, appointment, payment and message ---------- */
export type EvKind = 'form' | 'checkin' | 'bill' | 'reminder' | 'message' | 'refill' | 'appt' | 'result' | 'labs' | 'document' | 'connect' | 'request';
export interface Ev { id: string; kind: EvKind; date: string; title: string; practice: string; status: string; tone: 'todo' | 'done' | 'info' | 'flag'; upcoming?: boolean; item?: H.Item; labs?: Lab[]; doc?: Doc; body?: string; }
const tone = (i: H.Item): Ev['tone'] => isOpen(i) && TASK_KINDS.includes(i.kind) ? 'todo' : 'done';
const statusLabel = (i: H.Item) => ({ sent: TASK_KINDS.includes(i.kind) ? 'To do' : 'New', opened: TASK_KINDS.includes(i.kind) ? 'To do' : 'Seen', signed: 'Signed', 'checked-in': 'Checked in', paid: 'Paid', confirmed: 'Confirmed', done: 'Done' } as Record<string, string>)[i.status] || i.status;
export function labPanels(a: Account) {
  const g: Record<string, Lab[]> = {}; a.labs.forEach(l => (g[l.date + '|' + l.source] ||= []).push(l));
  return Object.entries(g).map(([k, labs]) => ({ id: 'labs:' + k, date: labs[0].date, source: labs[0].source, labs, abnormal: labs.filter(l => S.labFlag(l) !== 'normal') })).sort((x, y) => y.date.localeCompare(x.date));
}
export const srcName = (s: string) => s.split(' (')[0];
export function timeline(a: Account): Ev[] {
  const out: Ev[] = []; const today = S.today();
  H.itemsFor(a.id).forEach(i => {
    if (i.kind === 'result' || i.kind === 'document') return; // shown via the synced lab/doc records below
    const kind: EvKind = i.kind === 'refill-request' || i.kind === 'refill-reply' ? 'refill' : i.kind === 'appt-request' ? 'appt' : i.kind as EvKind;
    const title = i.kind === 'message' ? (i.from === 'patient' ? 'You sent a message' : `Message from ${i.practiceName}`) : i.kind === 'bill' ? `${i.title} · $${(i.amount || 0).toFixed(2)}` : i.kind === 'refill-reply' ? `Refill reply: ${i.title}` : i.title;
    const up = (i.kind === 'checkin' || i.kind === 'reminder') && isOpen(i);
    out.push({ id: i.id, kind, date: (up && i.due) ? i.due : i.at, title, practice: i.practiceName, status: i.from === 'patient' ? 'Sent' : statusLabel(i), tone: tone(i), upcoming: up && !!i.due && i.due >= today, item: i, body: i.body });
  });
  labPanels(a).forEach(p => out.push({ id: p.id, kind: 'labs', date: p.date, title: p.labs.length === 1 ? `Lab result: ${p.labs[0].name}` : `Lab results: ${p.labs.map(l => l.name).slice(0, 3).join(', ')}${p.labs.length > 3 ? ` +${p.labs.length - 3}` : ''}`, practice: srcName(p.source), status: p.abnormal.length ? `${p.abnormal.length} outside range` : 'In range', tone: p.abnormal.length ? 'flag' : 'info', labs: p.labs }));
  a.docs.forEach(d => out.push({ id: 'doc:' + d.id, kind: 'document', date: d.date, title: d.title, practice: srcName(d.source), status: d.explained ? 'Explained' : d.type, tone: 'info', doc: d }));
  H.linksFor(a.id).forEach(l => out.push({ id: 'link:' + l.id, kind: 'connect', date: l.grantedAt || l.requestedAt, title: l.status === 'pending' ? `${l.practiceName} wants to connect` : l.status === 'active' ? `Connected to ${l.practiceName}` : `Connection with ${l.practiceName} ended`, practice: l.practiceName, status: l.status === 'pending' ? 'Needs you' : l.status === 'active' ? 'Connected' : 'Revoked', tone: l.status === 'pending' ? 'todo' : 'info' }));
  a.requests.forEach(r => out.push({ id: 'rr:' + r.id, kind: 'request', date: r.createdAt, title: `Records request to ${r.provider}`, practice: r.provider, status: r.status, tone: 'info' }));
  return out.sort((x, y) => (y.upcoming ? 1 : 0) - (x.upcoming ? 1 : 0) || y.date.localeCompare(x.date));
}

/* ---------- Nightingale's grouped, conversational message about what's waiting ---------- */
export interface Ask { text: string; actions: { label: string; route: Route; testid: string }[] }
const VERB: Record<string, string> = { form: 'Fill out', checkin: 'Check in', bill: 'Pay', reminder: 'Confirm' };
export function nightingaleInbox(a: Account, first: string): Ask | null {
  const tasks = pendingTasks(a.id); const news = unseen(a.id); const pend = H.linksFor(a.id).filter(l => l.status === 'pending');
  if (!tasks.length && !news.length && !pend.length) return null;
  const parts: string[] = []; const actions: Ask['actions'] = [];
  const byP: Record<string, H.Item[]> = {}; tasks.forEach(t => (byP[t.practiceName] ||= []).push(t));
  Object.entries(byP).forEach(([p, l]) => {
    const desc = l.map(t => t.kind === 'form' ? `a form ("${t.title}")` : t.kind === 'checkin' ? `check-in for ${t.title.replace(/^Check in: /, '')}` : t.kind === 'bill' ? `a bill for $${(t.amount || 0).toFixed(2)}` : `an appointment to confirm (${t.title.replace(/^Appointment reminder: /, '')})`);
    parts.push(`${p} sent you ${desc.length > 1 ? desc.slice(0, -1).join(', ') + ' and ' + desc[desc.length - 1] : desc[0]}.`);
    l.forEach(t => actions.push({ label: `${VERB[t.kind]}${t.kind === 'bill' ? ` $${(t.amount || 0).toFixed(2)}` : t.kind === 'form' ? ` "${t.title}"` : ''}`, route: { view: 'task', id: t.id }, testid: `ng-task-${t.kind}` }));
  });
  const res = news.filter(n => n.kind === 'result'); const docs = news.filter(n => n.kind === 'document'); const msgs = news.filter(n => n.kind === 'message' || n.kind === 'refill-reply');
  if (res.length) { const abn = res.filter(r => r.lab && (r.lab.value > r.lab.high || r.lab.value < r.lab.low)); parts.push(`${res.length === 1 ? 'A new result' : `${res.length} new results`} arrived from ${[...new Set(res.map(r => r.practiceName))].join(' and ')}${abn.length ? `. ${abn.length === 1 ? 'One value is' : 'Some values are'} outside the usual range, which is common and worth discussing with your doctor; I can explain what the test measures` : ''}.`); actions.push({ label: res.length === 1 ? 'See the result' : 'See the results', route: { view: 'task', id: res[0].id }, testid: 'ng-task-result' }); }
  if (docs.length) { parts.push(`${docs.length === 1 ? `"${docs[0].title}"` : `${docs.length} documents`} arrived.`); actions.push({ label: 'Open document', route: { view: 'task', id: docs[0].id }, testid: 'ng-task-document' }); }
  if (msgs.length) { parts.push(`You have ${msgs.length === 1 ? 'a new message' : `${msgs.length} new messages`} from ${[...new Set(msgs.map(m => m.practiceName))].join(' and ')}.`); actions.push({ label: msgs.length === 1 ? 'Read message' : 'Read messages', route: { view: 'task', id: msgs[0].id }, testid: 'ng-task-message' }); }
  pend.forEach(l => { parts.push(`${l.practiceName} asked to connect to your Portal so they can send forms, results and bills here.`); actions.push({ label: `Review ${l.practiceName}`, route: { view: 'portal', section: 'care' }, testid: 'ng-task-link' }); });
  const n = tasks.length;
  return { text: `${first ? first + ', h' : 'H'}ere's what's waiting for you. ${parts.join(' ')}${n ? ` Want to take care of ${n === 1 ? 'it' : 'them'} now? It only takes a minute${n > 1 ? ' each' : ''}.` : ''}`, actions };
}

/** One place for the account the signed-in user is acting on (own profile or a family member's). */
export function usePortalData() {
  useHubTick(); const [, setN] = useState(0); const refresh = () => setN(n => n + 1);
  const meId = S.session(); const me = meId ? S.getAccount(meId) : null;
  if (!me) return { me: null, refresh } as const;
  const grants = H.grantsFor(me); const v = S.viewing(); const a = (v && grants.some(g => g.ownerAcct === v) && S.getAccount(v)) || me;
  const role: 'patient' | 'caregiver' = a.id === me.id ? 'patient' : 'caregiver';
  const fresh = S.getAccount(a.id); if (fresh && S.syncFromHub(fresh)) S.saveAccount(fresh);
  const acct = S.getAccount(a.id) || a;
  const save = (f: (x: Account) => void) => { const x = S.getAccount(acct.id)!; f(x); S.saveAccount(x); refresh(); };
  const unread = H.noticesFor(me.id).filter(n => !n.read).length;
  return { me, a: acct, role, grants, save, refresh, unread, ent: entitlements(acct) } as const;
}
