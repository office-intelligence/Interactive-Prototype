/* Vityls Patient Portal v0.2 · patient-facing app on Vityls Core (module `patient-portal`). All data fictitious; connections simulated. */
import { useEffect, useMemo, useState } from 'react';
import * as S from './store';
import * as H from './hub';
import * as F from './finder';
import type { Account, Lab, Doc } from './store';
import './portal.css';

export type Page = 'home' | 'finder' | 'inbox' | 'care' | 'labs' | 'docs' | 'meds' | 'connect' | 'family' | 'history' | 'alerts' | 'plan';
const NAV: [Page, string][] = [['home', 'Nightingale'], ['finder', 'Find a doctor'], ['inbox', 'From my practices'], ['care', 'Care team'], ['labs', 'Labs'], ['docs', 'Documents'], ['meds', 'Medications & allergies'], ['connect', 'Connect my doctor'], ['family', 'Family access'], ['history', 'History'], ['alerts', 'Notifications'], ['plan', 'Plan']];
const fmt = (d: string) => new Date(d.length === 10 ? d + 'T12:00:00' : d).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
const fmtT = (d: string) => new Date(d).toLocaleString('en-US', { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' });

function useHubTick() { const [, setN] = useState(0); useEffect(() => { const f = () => setN(n => n + 1); window.addEventListener('vityls-portal-hub', f); window.addEventListener('storage', f); window.addEventListener('focus', f); return () => { window.removeEventListener('vityls-portal-hub', f); window.removeEventListener('storage', f); window.removeEventListener('focus', f); }; }, []); }

import { ImarsPortal } from './imarslink/ImarsPortal';
/** v0.4: the Portal is Kevin's iMARSLINK design (src/portal/imarslink). The v0.3 shell stays available as LegacyPortalApp. */
export function PortalApp() { return <ImarsPortal />; }
export function LegacyPortalApp() {
  const [ready, setReady] = useState(false);
  useEffect(() => { if (location.search.includes('reset-portal')) S.resetPortal(); else S.seedPortal(); setReady(true); }, []);
  useHubTick(); const [, setN] = useState(0); const refresh = () => setN(n => n + 1);
  const [auth, setAuth] = useState<null | { mode: 'in' | 'up'; reason?: string }>(null);
  if (!ready) return null;
  const meId = S.session(); const me = meId ? S.getAccount(meId) : null;
  if (!me) return <>{<Guest onAuth={(mode, reason) => setAuth({ mode, reason })} />}{auth && <Auth mode={auth.mode} reason={auth.reason} onClose={() => setAuth(null)} onDone={() => { setAuth(null); refresh(); }} />}</>;
  return <Shell me={me} refresh={refresh} />;
}

export type P = { a: Account; me: Account; save: (f: (a: Account) => void) => void; go?: (p: Page) => void; role: 'patient' | 'caregiver' };

function Shell({ me, refresh }: { me: Account; refresh: () => void }) {
  const [page, setPage] = useState<Page>('home');
  const grants = H.grantsFor(me); const v = S.viewing(); const a = (v && grants.some(g => g.ownerAcct === v) && S.getAccount(v)) || me;
  const role: 'patient' | 'caregiver' = a.id === me.id ? 'patient' : 'caregiver';
  useEffect(() => { const fresh = S.getAccount(a.id); if (fresh && S.syncFromHub(fresh)) { S.saveAccount(fresh); refresh(); } }); // v0.3: always sync the freshly stored account (no stale-render double import)
  const save = (f: (x: Account) => void) => { const x = S.getAccount(a.id)!; f(x); S.saveAccount(x); refresh(); };
  const unread = H.noticesFor(me.id).filter(n => !n.read).length;
  const todo = H.itemsFor(a.id).filter(i => i.from === 'practice' && ['sent', 'opened'].includes(i.status) && ['form', 'checkin', 'bill', 'reminder'].includes(i.kind)).length;
  const pend = H.linksFor(a.id).filter(l => l.status === 'pending').length;
  const p: P = { a, me, save, go: setPage, role };
  return <div className="pp" data-testid="portal-app">
    <aside className="pp-side">
      <div className="pp-logo" data-testid="pp-logo"><span className="pp-dot" />Vityls <b>Portal</b></div>
      {grants.length > 0 && <label className="pp-field">Viewing profile<select value={a.id} onChange={e => { S.setViewing(e.target.value); setPage('home'); refresh(); }} data-testid="pp-profile-switch"><option value={me.id}>{me.name} (me)</option>{grants.map(g => <option key={g.id} value={g.ownerAcct}>{g.ownerName} ({g.relation})</option>)}</select></label>}
      {role === 'caregiver' && <div className="pp-note pp-small" data-testid="pp-caregiver-banner">You are acting for {a.name}. Everything you do is recorded in {a.name.split(' ')[0]}'s history.</div>}
      <nav>{NAV.map(([k, l]) => <button key={k} className={page === k ? 'on' : ''} onClick={() => setPage(k)} data-testid={`pp-nav-${k}`}>{l}
        {k === 'plan' && <span className="pp-pill">{S.isPlus(a) ? 'Plus' : 'Free'}</span>}{k === 'alerts' && unread > 0 && <span className="pp-pill pp-count" data-testid="pp-unread">{unread}</span>}{k === 'inbox' && todo > 0 && <span className="pp-pill pp-count" data-testid="pp-todo-count">{todo}</span>}{k === 'care' && pend > 0 && <span className="pp-pill pp-count">{pend}</span>}</button>)}</nav>
      <div className="pp-me"><b>{me.name}</b><span>Vityls ID {me.id.replace('vp-', '').toUpperCase()}</span><button className="pp-link" onClick={() => { S.setSession(null); refresh(); }} data-testid="pp-signout">Sign out</button></div>
    </aside>
    <main className="pp-main">
      <div className="pp-sim">Test build · fictional data · every connection is simulated until a BAA is signed</div>
      {page === 'home' && <Home {...p} />}
      {page === 'finder' && <Finder acct={p} />}
      {page === 'inbox' && <Inbox {...p} />}
      {page === 'care' && <CareTeam {...p} />}
      {page === 'labs' && <Labs {...p} />}
      {page === 'docs' && <Docs {...p} />}
      {page === 'meds' && <Meds {...p} />}
      {page === 'connect' && <Connect {...p} />}
      {page === 'family' && <Family {...p} refresh={refresh} />}
      {page === 'history' && <History {...p} />}
      {page === 'alerts' && <Alerts {...p} refresh={refresh} />}
      {page === 'plan' && <PlanPage {...p} />}
    </main>
  </div>;
}

export function Auth({ mode: m0, reason, onClose, onDone }: { mode: 'in' | 'up'; reason?: string; onClose: () => void; onDone: () => void }) {
  const [mode, setMode] = useState(m0); const [f, setF] = useState({ name: '', email: '', password: '', dob: '' }); const [err, setErr] = useState('');
  const g = S.guest();
  const go = () => { const r = mode === 'in' ? S.signIn(f.email, f.password) : S.signUp(f.name, f.email, f.password, f.dob); if (typeof r === 'string') setErr(r); else onDone(); };
  const inp = (k: keyof typeof f, label: string, type = 'text') => <label className="pp-field">{label}<input type={type} value={f[k]} onChange={e => setF({ ...f, [k]: e.target.value })} data-testid={`pp-auth-${String(k)}`} /></label>;
  return <div className="pp-modal" data-testid="portal-auth"><div className="pp-card pp-authcard">
    <div className="pp-prompt-h"><div className="pp-logo"><span className="pp-dot" />Vityls <b>Portal</b></div><button className="pp-link" onClick={onClose} data-testid="pp-auth-close">Close</button></div>
    {reason && <p className="pp-note" data-testid="pp-auth-reason">{reason}</p>}
    <h1>{mode === 'in' ? 'Sign in' : 'Create your free health account'}</h1>
    <p className="pp-muted">Your account belongs to you, not to a doctor's office.{mode === 'up' && (g.chat.length || g.labs.length) ? ' What you did as a guest comes with you.' : ''}</p>
    {mode === 'up' && inp('name', 'Full name')}{inp('email', 'Email', 'email')}{mode === 'up' && inp('dob', 'Date of birth', 'date')}{inp('password', 'Password', 'password')}
    {err && <p className="pp-err" data-testid="pp-auth-err">{err}</p>}
    <button className="pp-btn" onClick={go} data-testid="pp-auth-go">{mode === 'in' ? 'Sign in' : 'Create account'}</button>
    <button className="pp-link" onClick={() => { setMode(mode === 'in' ? 'up' : 'in'); setErr(''); }} data-testid="pp-auth-switch">{mode === 'in' ? 'New here? Create an account' : 'Have an account? Sign in'}</button>
    <p className="pp-muted pp-small">Demo (fictional): jordan.rivera@example.test or alex.rivera@example.test · password portal2026</p>
  </div></div>;
}

/* ---------------- Guest mode: Nightingale with no sign-in ---------------- */
export const LAB_PRESETS: Record<string, [string, number, number]> = { ALT: ['U/L', 7, 56], 'LDL cholesterol': ['mg/dL', 0, 100], 'Hemoglobin A1c': ['%', 4, 5.6], Glucose: ['mg/dL', 70, 99], TSH: ['mIU/L', 0.4, 4], Potassium: ['mmol/L', 3.5, 5.1], Creatinine: ['mg/dL', 0.7, 1.3] };
export function Guest({ onAuth }: { onAuth: (m: 'in' | 'up', reason?: string) => void }) {
  const [gview, setGview] = useState<'chat' | 'finder'>('chat');
  const [g, setG] = useState(S.guest()); const [lab, setLab] = useState({ name: 'ALT', value: '' }); const [q, setQ] = useState('');
  const left = Math.max(0, S.GUEST_LIMIT - g.used);
  const put = (n: S.Guest) => { S.saveGuest(n); setG(n); };
  const need = (what: string) => onAuth('up', `${what} needs a free account, so your records are saved and private. What you did as a guest comes with you.`);
  const explain = () => { const v = parseFloat(lab.value); if (isNaN(v)) return; if (left <= 0) { onAuth('up', `You've used your ${S.GUEST_LIMIT} free guest explanations. Create a free account to keep going; your guest session comes with you.`); return; }
    const [unit, low, high] = LAB_PRESETS[lab.name]; const l: Lab = { id: S.uid('lab-'), name: lab.name, code: '', value: v, unit, low, high, date: S.today(), source: 'guest' };
    put({ used: g.used + 1, labs: [...g.labs, l], chat: [...g.chat, { id: S.uid(), who: 'me', text: `Explain my ${lab.name} of ${v} ${unit}`, at: S.nowIso() }, { id: S.uid(), who: 'ng', text: S.explainLab(l), at: S.nowIso() }] }); setLab({ ...lab, value: '' }); };
  const ask = () => { if (!q.trim()) return; if (left <= 0) { onAuth('up', `You've used your ${S.GUEST_LIMIT} free guest explanations. Create a free account to keep going.`); return; }
    const tmp = S.blankAccount('Guest', 'g@x', 'x', '2000-01-01'); tmp.labs = g.labs; const r = S.nightingaleReply(tmp, q.trim());
    put({ ...g, used: g.used + 1, chat: [...g.chat, { id: S.uid(), who: 'me', text: q.trim(), at: S.nowIso() }, { id: S.uid(), who: 'ng', text: r, at: S.nowIso() }] }); setQ(''); };
  const gated: [string, string][] = [['Save my records', 'Saving records'], ['Connect my doctor', 'Connecting your doctors'], ['Message my practice', 'Messaging a practice'], ['Family access', 'Family access'], ['Wearables', 'Wearables'], ['Upload a document', 'Keeping uploads']];
  return <div className="pp pp-guest" data-testid="pp-guest"><main className="pp-main pp-guestmain">
    <div className="pp-prompt-h"><div className="pp-logo"><span className="pp-dot" />Vityls <b>Portal</b></div><div className="pp-row"><button className={'pp-link' + (gview === 'finder' ? ' on' : '')} onClick={() => setGview(gview === 'finder' ? 'chat' : 'finder')} data-testid="pp-guest-finder">{gview === 'finder' ? 'Back to Nightingale' : 'Find a doctor'}</button><button className="pp-link" onClick={() => onAuth('in')} data-testid="pp-guest-signin">Sign in</button><button className="pp-btn" onClick={() => onAuth('up')} data-testid="pp-guest-signup">Create free account</button></div></div>
    <div className="pp-sim">Test build · fictional data · you're a guest: nothing is saved to an account</div>
    {gview === 'finder' ? <Finder onNeed={r => onAuth('up', r)} /> : <>
    <header className="pp-ng"><div className="pp-ngicon">N</div><div><h1>Nightingale</h1><p>Ask about a lab result or a word in your report. No sign-in needed. I explain; I never diagnose or tell you whether to do something.</p></div></header>
    <section className="pp-card pp-chat" data-testid="pp-chat">
      {!g.chat.length && <div className="pp-bubble ng">Hi, I'm Nightingale. Type a lab value below and I'll explain it in plain language. You have {S.GUEST_LIMIT} free explanations as a guest.</div>}
      {g.chat.slice(-10).map(m => <div key={m.id} className={'pp-bubble ' + m.who}>{m.text}</div>)}
      <div className="pp-row"><select className="pp-input" value={lab.name} onChange={e => setLab({ ...lab, name: e.target.value })} data-testid="pp-guest-lab">{Object.keys(LAB_PRESETS).map(k => <option key={k}>{k}</option>)}</select><input className="pp-input" placeholder={`Value (${LAB_PRESETS[lab.name][0]})`} value={lab.value} onChange={e => setLab({ ...lab, value: e.target.value })} data-testid="pp-guest-value" /><button className="pp-btn" onClick={explain} data-testid="pp-guest-explain">Explain</button></div>
      <div className="pp-row"><input className="pp-input" placeholder="Or ask a question…" value={q} onChange={e => setQ(e.target.value)} onKeyDown={e => e.key === 'Enter' && ask()} data-testid="pp-ask" /><button className="pp-btn" onClick={ask} data-testid="pp-ask-go">Send</button></div>
      <p className="pp-small pp-muted" data-testid="pp-guest-left">{left} of {S.GUEST_LIMIT} free guest explanations left</p>
      <div className="pp-chips">{gated.map(([l, w]) => <button key={l} className="pp-chip" onClick={() => need(w)} data-testid={`pp-guest-gate-${l.split(' ')[0].toLowerCase()}`}>{l}</button>)}</div>
      <Carousel onTry={k => k === 'lab' ? setLab({ name: 'ALT', value: '68' }) : need(CAROUSEL.find(c => c.key === k)!.title)} />
    </section></>}
  </main></div>;
}

/* ---------------- Example carousel ---------------- */
export const CAROUSEL: { key: string; title: string; text: string }[] = [
  { key: 'lab', title: 'Lab trends', text: 'Example: “Your LDL went 162 → 148 → 121 mg/dL. It’s moving toward the range (under 100).”' },
  { key: 'medlab', title: 'Medicines and labs', text: 'Example: “Atorvastatin is known to sometimes raise ALT. Worth asking your doctor about.”' },
  { key: 'wear', title: 'Wearables', text: 'Example: “Resting heart rate averaged 61 this week; sleep 6 h 50 m, a bit less than last week.”' },
  { key: 'visit', title: 'Visit prep', text: 'Example: “For Friday: 2 out-of-range labs, 3 medicines, 1 symptom note, 2 questions.”' },
  { key: 'doc', title: 'Document explained', text: 'Example: “Your MRI impression says ‘mild degenerative change’: common wear with age.”' },
  { key: 'care', title: 'Caregiver alert', text: 'Example: “Mom’s A1c went up for the third time in a row. Dr. Kim’s office sent a message.”' },
];
export function Mini({ k }: { k: string }) {
  const G = '#1a5340', R = '#b4442f';
  if (k === 'lab') return <svg width="120" height="46"><rect x="0" y="26" width="120" height="20" fill="#e4efe9" /><polyline points="8,6 60,14 112,28" fill="none" stroke={G} strokeWidth="2" />{[[8, 6], [60, 14], [112, 28]].map(([x, y]) => <circle key={x} cx={x} cy={y} r="3" fill={y < 26 ? R : G} />)}</svg>;
  if (k === 'medlab') return <svg width="120" height="46"><rect x="4" y="12" width="40" height="18" rx="3" fill="#e4efe9" stroke={G} /><text x="24" y="25" fontSize="9" textAnchor="middle" fill={G}>Rx</text><path d="M48 21h22" stroke={G} strokeDasharray="3 2" /><rect x="74" y="12" width="40" height="18" rx="3" fill="#f8e5e0" stroke={R} /><text x="94" y="25" fontSize="9" textAnchor="middle" fill={R}>ALT ↑</text></svg>;
  if (k === 'wear') return <svg width="120" height="46"><polyline points="4,30 20,26 36,32 52,22 68,28 84,18 100,24 116,20" fill="none" stroke={R} strokeWidth="1.6" />{[0, 1, 2, 3, 4, 5, 6].map(i => <rect key={i} x={6 + i * 16} y={46 - (10 + (i * 7) % 12)} width="9" height={10 + (i * 7) % 12} fill="#cfe1d6" />)}</svg>;
  if (k === 'visit') return <svg width="120" height="46"><rect x="30" y="2" width="60" height="42" rx="3" fill="#fff" stroke="#cfd8d1" />{[10, 18, 26, 34].map(y => <rect key={y} x="38" y={y} width={y === 10 ? 30 : 44} height="3" rx="1" fill={y === 10 ? G : '#cfd8d1'} />)}</svg>;
  if (k === 'doc') return <svg width="120" height="46"><rect x="20" y="2" width="36" height="42" rx="3" fill="#fff" stroke="#cfd8d1" />{[10, 17, 24, 31].map(y => <rect key={y} x="26" y={y} width="24" height="3" fill="#cfd8d1" />)}<rect x="64" y="12" width="50" height="22" rx="3" fill="#e4efe9" /><text x="89" y="26" fontSize="8.5" textAnchor="middle" fill={G}>plain words</text></svg>;
  return <svg width="120" height="46"><circle cx="34" cy="16" r="8" fill="#cfe1d6" /><rect x="22" y="26" width="24" height="16" rx="3" fill="#cfe1d6" /><rect x="58" y="10" width="56" height="24" rx="3" fill="#fbf6ea" stroke="#efe2bf" /><circle cx="68" cy="22" r="3" fill={R} /><rect x="75" y="20" width="32" height="3" fill="#d9c79b" /></svg>;
}
export function Carousel({ onTry }: { onTry: (k: string) => void }) {
  const [i, setI] = useState(0); const [pause, setPause] = useState(false);
  useEffect(() => { if (pause) return; const t = setInterval(() => setI(x => (x + 1) % CAROUSEL.length), 4500); return () => clearInterval(t); }, [pause]);
  const c = CAROUSEL[i];
  return <div className="pp-carousel" onMouseEnter={() => setPause(true)} onMouseLeave={() => setPause(false)} data-testid="pp-carousel" data-paused={pause ? '1' : '0'} data-index={i}>
    <div className="pp-cslide" data-testid={`pp-slide-${c.key}`}><Mini k={c.key} /><div><div className="pp-small"><span className="pp-pill">Example</span> <b>{c.title}</b></div><div className="pp-small pp-muted">{c.text}</div></div><button className="pp-btn ghost" onClick={() => onTry(c.key)} data-testid="pp-slide-try">Try it</button></div>
    <div className="pp-dots">{CAROUSEL.map((x, j) => <button key={x.key} className={j === i ? 'on' : ''} onClick={() => setI(j)} aria-label={x.title} data-testid={`pp-dot-${j}`} />)}</div>
  </div>;
}

/* ---------------- From my practices (forms, check-in, bills, messages, refills, reminders) ---------------- */
export function Inbox({ a, me, save, role }: P) {
  useHubTick(); const ls = H.linksFor(a.id).filter(l => l.status === 'active'); const all = H.itemsFor(a.id);
  const [pid, setPid] = useState(ls[0]?.practiceId || ''); const [t, setT] = useState(''); const [rem, setRem] = useState({ title: '', due: S.today(), repeat: 'once' });
  const [open, setOpen] = useState<string | null>(null); const [ans, setAns] = useState<Record<string, string>>({}); const [sig, setSig] = useState('');
  const todo = all.filter(i => i.from === 'practice' && ['form', 'checkin', 'bill', 'reminder'].includes(i.kind));
  const thread = all.filter(i => i.practiceId === pid && ['message', 'refill-request', 'refill-reply', 'appt-request'].includes(i.kind)).reverse();
  const drafts = a.messages.filter(m => m.practiceId === '__draft__');
  const openIt = (i: H.Item) => { setOpen(open === i.id ? null : i.id); H.markOpened(i, me.name, role); };
  const done = (i: H.Item) => !['sent', 'opened'].includes(i.status);
  return <div data-testid="pp-inbox"><h2>From my practices</h2><p className="pp-muted">Everything your Vityls practices send is free and never counts toward any limit.</p>
    {!ls.length && <p className="pp-card" data-testid="pp-inbox-empty">No Vityls practices connected yet. When your doctor's office uses Vityls, they send a connection request; you approve it in Care team.</p>}
    {todo.length > 0 && <section className="pp-card"><h3>To do</h3>{todo.map(i => <div key={i.id} className="pp-item" data-testid={`pp-item-${i.kind}`}>
      <div className="pp-prompt-h"><div><b>{i.title}</b> <span className="pp-muted pp-small">· {i.practiceName} · {fmtT(i.at)}</span></div><div className="pp-row"><span className={'pp-flag ' + (done(i) ? 'normal' : 'high')} data-testid="pp-item-status">{i.status}</span><button className="pp-link" onClick={() => openIt(i)} data-testid="pp-item-open">{open === i.id ? 'Close' : 'Open'}</button></div></div>
      {open === i.id && <div className="pp-itembody">{i.body && <p className="pp-small">{i.body}</p>}
        {i.kind === 'form' && (done(i) ? <p className="pp-free pp-small">Signed {i.answers?.__signedBy ? 'by ' + i.answers.__signedBy : ''}</p> : <>{(i.fields || []).map(f => <label key={f} className="pp-field">{f}<input value={ans[f] || ''} onChange={e => setAns({ ...ans, [f]: e.target.value })} data-testid="pp-form-field" /></label>)}
          <label className="pp-field">Type your full name to sign<input value={sig} onChange={e => setSig(e.target.value)} data-testid="pp-form-sign" /></label><button className="pp-btn" disabled={sig.trim().length < 3} onClick={() => { H.act(i.id, 'signed', me.name, role, { answers: { ...ans, __signedBy: sig.trim() } }, `${i.title} signed by ${sig.trim()}${role === 'caregiver' ? ` (caregiver for ${a.name})` : ''}`); save(x => { x.docs.unshift({ id: S.uid('doc-'), title: `${i.title} (signed)`, type: 'Signed form', date: S.today(), source: `${i.practiceName} (Vityls practice)`, fromPractice: true }); }); setSig(''); setAns({}); }} data-testid="pp-form-submit">Sign and send</button></>)}
        {i.kind === 'checkin' && (done(i) ? <p className="pp-free pp-small">Checked in</p> : <><p className="pp-small">Confirm your address, phone and insurance haven't changed, then check in.</p><button className="pp-btn" onClick={() => H.act(i.id, 'checked-in', me.name, role, {}, `Checked in from the Portal for ${i.title}`)} data-testid="pp-checkin">Everything is the same · check in</button></>)}
        {i.kind === 'bill' && (done(i) ? <p className="pp-free pp-small">Paid ${i.amount?.toFixed(2)}</p> : <><p className="pp-big">${i.amount?.toFixed(2)}</p><button className="pp-btn" onClick={() => H.act(i.id, 'paid', me.name, role, {}, `Paid $${i.amount?.toFixed(2)} by card •••• 4242 (simulated)`)} data-testid="pp-pay">Pay with card •••• 4242 (simulated)</button></>)}
        {i.kind === 'reminder' && (done(i) ? <p className="pp-free pp-small">Confirmed</p> : <button className="pp-btn" onClick={() => H.act(i.id, 'confirmed', me.name, role, {}, `Appointment confirmed: ${i.title}`)} data-testid="pp-confirm">Confirm</button>)}
      </div>}</div>)}</section>}
    {ls.length > 0 && <div className="pp-grid2"><section className="pp-card"><h3>Secure messages</h3>
      <select className="pp-input" value={pid} onChange={e => setPid(e.target.value)} data-testid="pp-msg-practice">{ls.map(p => <option key={p.practiceId} value={p.practiceId}>{p.practiceName} · {p.doctor}</option>)}</select>
      {drafts.map(d => <div key={d.id} className="pp-note" data-testid="pp-msg-draft">{d.text}<div className="pp-row"><button className="pp-btn" onClick={() => { H.patientSend(a.id, pid, 'message', 'Question from Nightingale draft', d.text.replace(/^Draft question for my doctor: /, ''), me.name, role); save(x => { x.messages = x.messages.filter(m => m.id !== d.id); }); }} data-testid="pp-draft-send">Send to {ls.find(p => p.practiceId === pid)?.practiceName}</button><button className="pp-link" onClick={() => save(x => { x.messages = x.messages.filter(m => m.id !== d.id); })}>Discard</button></div></div>)}
      <div className="pp-thread" data-testid="pp-thread">{thread.map(m => <div key={m.id} className={'pp-bubble ' + (m.from === 'patient' ? 'me' : 'ng')} onMouseEnter={() => H.markOpened(m, me.name, role)}><div className="pp-small"><b>{m.kind === 'refill-request' ? 'Refill request' : m.kind === 'refill-reply' ? 'Refill reply' : m.kind === 'appt-request' ? 'Appointment request' : ''}</b></div>{m.body || m.title}<div className="pp-small pp-muted">{m.by} · {fmtT(m.at)}</div></div>)}</div>
      <div className="pp-row"><input className="pp-input" placeholder="Write a message" value={t} onChange={e => setT(e.target.value)} data-testid="pp-msg-text" /><button className="pp-btn" disabled={!t.trim()} onClick={() => { H.patientSend(a.id, pid, 'message', 'Message', t.trim(), me.name, role); setT(''); }} data-testid="pp-msg-send">Send</button></div></section>
    <section className="pp-card"><h3>Refill requests</h3>{a.meds.length ? a.meds.map(m => <div key={m.id} className="pp-li"><span>{m.name} {m.dose}</span><button className="pp-link" onClick={() => H.patientSend(a.id, pid, 'refill-request', `Refill: ${m.name} ${m.dose}`.trim(), `Please refill ${m.name} ${m.dose}`.trim(), me.name, role)} data-testid="pp-refill">Request refill</button></div>) : <p className="pp-muted">Add medicines first.</p>}
      {all.filter(i => i.kind === 'refill-request').map(r => { const rep = all.find(x => x.kind === 'refill-reply' && x.replyTo === r.id); return <div key={r.id} className="pp-small pp-muted" data-testid="pp-refill-row">{r.title} · {r.practiceName} · {rep ? <b className="pp-free" data-testid="pp-refill-reply">{rep.body}</b> : 'waiting for the practice'}</div>; })}
      <h3>Reminders</h3>{a.reminders.map(r => <div key={r.id} className="pp-li" data-testid="pp-rem-row"><label><input type="checkbox" checked={!!r.done} onChange={() => save(x => { const y = x.reminders.find(z => z.id === r.id)!; y.done = !y.done; })} /> {r.title}</label><span className="pp-small pp-muted">{fmt(r.due)} · {r.repeat}</span></div>)}
      <div className="pp-row"><input className="pp-input" placeholder="New reminder" value={rem.title} onChange={e => setRem({ ...rem, title: e.target.value })} data-testid="pp-rem-title" /><input className="pp-input" type="date" value={rem.due} onChange={e => setRem({ ...rem, due: e.target.value })} /><select className="pp-input" value={rem.repeat} onChange={e => setRem({ ...rem, repeat: e.target.value })}>{['once', 'daily', 'weekly', 'monthly'].map(x => <option key={x}>{x}</option>)}</select>
        <button className="pp-btn" disabled={!rem.title.trim()} onClick={() => { save(x => { x.reminders.push({ id: S.uid(), ...rem }); }); setRem({ ...rem, title: '' }); }} data-testid="pp-rem-add">Add</button></div></section></div>}
  </div>;
}

/* ---------------- Care team ---------------- */
export function CareTeam({ a, me, save, go, role }: P) {
  useHubTick(); const ls = H.linksFor(a.id); const [view, setView] = useState<string | null>(null); const [req, setReq] = useState<Record<string, string>>({}); const [o, setO] = useState({ name: '', specialty: '', phone: '' });
  const outside: { name: string; detail: string }[] = [...a.sources.filter(s => s.kind === 'fhir').map(s => ({ name: s.name, detail: `${s.vendor} · connected by FHIR` })), ...a.requests.map(r => ({ name: r.provider, detail: `records request ${r.id} · ${r.status}` })), ...S.uploadLinks().filter(l => l.acctId === a.id).map(l => ({ name: l.recipient, detail: `upload link · ${l.uploads} uploads` })), ...(a.outside || []).map(x => ({ name: x.name, detail: `${x.specialty}${x.phone ? ' · ' + x.phone : ''} · added by me` }))];
  return <div data-testid="pp-care"><h2>Care team</h2>
    <section className="pp-card"><h3>In the Vityls network</h3>{!ls.length && <p className="pp-muted">None yet.</p>}
      {ls.map(l => { const its = H.itemsFor(a.id, l.practiceId); return <div key={l.id} className="pp-team" data-testid={`pp-team-${l.practiceId}`}>
        <div className="pp-prompt-h"><div><b>{l.practiceName}</b> <span className="pp-muted">· {l.doctor}</span><div className="pp-small pp-muted">{l.status === 'active' ? `Connected since ${fmt(l.grantedAt!)} · shares ${l.scopes.join(', ')}` : l.status === 'pending' ? `Wants to connect (asked ${fmt(l.requestedAt)} by ${l.requestedBy})` : 'Connection revoked'}</div></div>
          {l.status === 'pending' ? <div className="pp-row"><button className="pp-btn" onClick={() => H.answerLink(l.id, true, me.name, role)} data-testid="pp-link-accept">Allow</button><button className="pp-link" onClick={() => H.answerLink(l.id, false, me.name, role)}>Decline</button></div> : l.status === 'active' ? <button className="pp-link" onClick={() => H.revokeLink(l.id, me.name, role)} data-testid="pp-link-revoke">Revoke</button> : null}</div>
        {l.status === 'active' && <><div className="pp-row"><button className="pp-btn ghost" onClick={() => go!('inbox')} data-testid="pp-team-message">Message</button><button className="pp-btn ghost" onClick={() => setView(view === l.id + 'r' ? null : l.id + 'r')} data-testid="pp-team-book">Request appointment</button><button className="pp-btn ghost" onClick={() => setView(view === l.id ? null : l.id)} data-testid="pp-team-forms">Forms & bills ({its.filter(i => i.kind === 'form' || i.kind === 'bill').length})</button><button className="pp-link" onClick={() => go!('history')}>History</button></div>
          {view === l.id + 'r' && <div className="pp-row"><input className="pp-input" placeholder="Reason and preferred days" value={req[l.id] || ''} onChange={e => setReq({ ...req, [l.id]: e.target.value })} data-testid="pp-appt-reason" /><button className="pp-btn" disabled={!(req[l.id] || '').trim()} onClick={() => { H.patientSend(a.id, l.practiceId, 'appt-request', 'Appointment request', req[l.id], me.name, role); setReq({ ...req, [l.id]: '' }); setView(null); }} data-testid="pp-appt-send">Send request</button></div>}
          {view === l.id && <table className="pp-table" data-testid="pp-team-forms-table"><tbody>{its.filter(i => i.kind === 'form' || i.kind === 'bill').map(i => <tr key={i.id}><td>{i.kind === 'bill' ? 'Bill' : 'Form'}</td><td>{i.title}{i.amount ? ` · $${i.amount.toFixed(2)}` : ''}</td><td>{i.status}</td><td>{fmt(i.at)}</td></tr>)}</tbody></table>}</>}
      </div>; })}</section>
    <section className="pp-card" data-testid="pp-outside"><h3>Other providers (not on Vityls)</h3>{!outside.length && <p className="pp-muted">None yet.</p>}
      {outside.map((x, i) => <div key={i} className="pp-li"><div><b>{x.name}</b> <span className="pp-muted pp-small">{x.detail}</span></div><button className="pp-link" onClick={() => go!('connect')}>Records</button></div>)}
      <div className="pp-row"><input className="pp-input" placeholder="Doctor or office" value={o.name} onChange={e => setO({ ...o, name: e.target.value })} data-testid="pp-outside-name" /><input className="pp-input" placeholder="Specialty" value={o.specialty} onChange={e => setO({ ...o, specialty: e.target.value })} /><input className="pp-input" placeholder="Phone" value={o.phone} onChange={e => setO({ ...o, phone: e.target.value })} />
        <button className="pp-btn" disabled={!o.name.trim()} onClick={() => { save(x => { (x.outside ||= []).push({ id: S.uid('op-'), ...o }); }); setO({ name: '', specialty: '', phone: '' }); }} data-testid="pp-outside-add">Add</button></div></section>
  </div>;
}

/* ---------------- Family / caregiver access ---------------- */
export function Family({ a, me, role, refresh }: P & { refresh: () => void }) {
  useHubTick(); const [f, setF] = useState({ name: '', email: '', relation: 'Daughter' }); const [ok, setOk] = useState(false); const [err, setErr] = useState('');
  const mine = H.caregiversOf(a.id); const inv = H.invitesFor(me); const grants = H.grantsFor(me);
  return <div data-testid="pp-family"><h2>Family access</h2>
    {inv.length > 0 && <section className="pp-card" data-testid="pp-invites"><h3>Invitations for you</h3>{inv.map(c => <div key={c.id} className="pp-li"><div><b>{c.ownerName}</b> invited you as {c.relation.toLowerCase()} with full access.<div className="pp-small pp-muted">{c.consent}</div></div><button className="pp-btn" onClick={() => { H.acceptCaregiver(c.id, me); refresh(); }} data-testid="pp-invite-accept">Accept</button></div>)}</section>}
    {grants.length > 0 && <section className="pp-card"><h3>Profiles you can open</h3>{grants.map(g => <div key={g.id} className="pp-li"><span><b>{g.ownerName}</b> · you are {g.relation.toLowerCase()}</span><button className="pp-link" onClick={() => { S.setViewing(g.ownerAcct); refresh(); }} data-testid="pp-open-profile">Open profile</button></div>)}</section>}
    {role === 'patient' || true ? <section className="pp-card"><h3>{role === 'caregiver' ? `People with access to ${a.name}` : 'Give a family member access'}</h3>
      {mine.map(c => <div key={c.id} className="pp-li" data-testid="pp-cg-row"><div><b>{c.name}</b> <span className="pp-muted">{c.relation} · {c.email} · {c.status}{c.acceptedAt ? ` since ${fmt(c.acceptedAt)}` : ''}{c.revokedAt ? ` · revoked ${fmt(c.revokedAt)}` : ''}</span></div>{c.status !== 'revoked' && role === 'patient' && <button className="pp-link" onClick={() => H.revokeCaregiver(c.id, me.name)} data-testid="pp-cg-revoke">Revoke</button>}</div>)}
      {role === 'patient' && <><div className="pp-row"><input className="pp-input" placeholder="Name" value={f.name} onChange={e => setF({ ...f, name: e.target.value })} data-testid="pp-cg-name" /><input className="pp-input" placeholder="Email" value={f.email} onChange={e => setF({ ...f, email: e.target.value })} data-testid="pp-cg-email" /><select className="pp-input" value={f.relation} onChange={e => setF({ ...f, relation: e.target.value })}>{['Daughter', 'Son', 'Spouse', 'Parent', 'Other family', 'Caregiver'].map(r => <option key={r}>{r}</option>)}</select></div>
        {f.name && <p className="pp-letter pp-small" data-testid="pp-cg-consent">{H.CONSENT_TEXT(a.name, f.name, f.relation)}</p>}
        <label className="pp-small"><input type="checkbox" checked={ok} onChange={e => setOk(e.target.checked)} data-testid="pp-cg-agree" /> I agree and sign this consent</label>
        {err && <p className="pp-err">{err}</p>}
        <button className="pp-btn" disabled={!ok} onClick={() => { const r = H.inviteCaregiver(a, f.name, f.email, f.relation); if (typeof r === 'string') setErr(r); else { setF({ name: '', email: '', relation: 'Daughter' }); setOk(false); setErr(''); } }} data-testid="pp-cg-invite">Send invitation (simulated email)</button>
        <p className="pp-small pp-muted">They sign in (or create a free account) with that email and accept. They'll get notifications about abnormal results, worsening trends and messages from your practices.</p></>}</section> : null}
  </div>;
}

/* ---------------- Interaction history (append-only) ---------------- */
export function History({ a }: P) {
  useHubTick(); const ls = H.linksFor(a.id); const [pid, setPid] = useState('');
  const rows = H.historyFor(a.id, pid || undefined);
  return <div data-testid="pp-history"><h2>History</h2><p className="pp-muted">Every interaction with your practices and everyone with access, in order. Entries can't be edited or deleted.</p>
    <select className="pp-input" value={pid} onChange={e => setPid(e.target.value)} data-testid="pp-history-filter"><option value="">All practices and family</option>{[...new Map(ls.map(l => [l.practiceId, l.practiceName])).entries()].map(([id, n]) => <option key={id} value={id}>{n}</option>)}</select>
    <table className="pp-table" data-testid="pp-history-table"><thead><tr><th>#</th><th>When</th><th>Practice</th><th>Who</th><th>What</th><th>Detail</th></tr></thead><tbody>{rows.map(r => <tr key={r.id}><td>{r.seq}</td><td className="pp-nowrap">{fmtT(r.at)}</td><td>{r.practiceName || '—'}</td><td>{r.actor} <span className="pp-muted pp-small">({r.role})</span></td><td className="pp-mono pp-small">{r.action}</td><td className="pp-small">{r.detail}</td></tr>)}</tbody></table></div>;
}

/* ---------------- Notification center ---------------- */
export function Alerts({ me, refresh }: P & { refresh: () => void }) {
  useHubTick(); const l = H.noticesFor(me.id);
  return <div data-testid="pp-alerts"><div className="pp-prompt-h"><h2>Notifications</h2><button className="pp-link" onClick={() => { H.markRead(me.id); refresh(); }} data-testid="pp-alerts-read">Mark all read</button></div><p className="pp-muted pp-small">In-app only in this test build (email/text are simulated).</p>
    {!l.length && <p className="pp-card">Nothing yet.</p>}
    {l.map(n => <div key={n.id} className={'pp-card pp-notice' + (n.read ? '' : ' unread')} data-testid={`pp-notice-${n.kind}`}><div className="pp-prompt-h"><b>{n.profileAcct === me.id ? 'You' : n.profileName}</b><span className="pp-small pp-muted">{fmtT(n.at)}</span></div><p className="pp-small">{n.text}</p></div>)}</div>;
}

/* ---------------- Home: Nightingale chat + proactive cards ---------------- */
export const MED_CHIPS = ['Atorvastatin', 'Acetaminophen', 'Ibuprofen', 'Lisinopril', 'Biotin', 'Multivitamin'];
/** v0.4: Nightingale's proactive question cards, reusable inside the iMARSLINK chat. */
export function PromptCards({ a, save, go, max }: P & { max?: number }) {
  const [medsSel, setMedsSel] = useState<string[]>([]); const [other, setOther] = useState(''); const [more, setMore] = useState(false);
  const all = S.prompts(a); const cards = more || !max ? all : all.slice(0, max);
  const answer = (id: string, f: (x: Account) => string, me: string) => save(x => { x.answered.push(id); x.chat.push({ id: S.uid(), who: 'me', text: me, at: S.nowIso() }); x.chat.push({ id: S.uid(), who: 'ng', text: f(x), at: S.nowIso() }); });
  return <>
    {cards.length > 0 && <section className="pp-cards" data-testid="pp-prompts">{cards.map(c => <div key={c.id} className="pp-card pp-prompt" data-testid={`pp-prompt-${c.kind}`}>
      <div className="pp-prompt-h"><b>{c.title}</b><button className="pp-link" onClick={() => save(x => { x.dismissed.push(c.id); })} data-testid="pp-prompt-dismiss">Not now</button></div>
      <p>{c.text}</p>
      {c.kind === 'labs-meds' && <div><div className="pp-chips">{[...new Set([...a.meds.map(m => m.name), ...MED_CHIPS])].map(m => <button key={m} className={'pp-chip' + (medsSel.includes(m) ? ' on' : '')} onClick={() => setMedsSel(medsSel.includes(m) ? medsSel.filter(x => x !== m) : [...medsSel, m])} data-testid={`pp-medchip-${m}`}>{m}</button>)}</div>
        <div className="pp-row"><input className="pp-input" placeholder="Other medicines or supplements" value={other} onChange={e => setOther(e.target.value)} data-testid="pp-labsmeds-other" /><button className="pp-btn" data-testid="pp-labsmeds-go" onClick={() => { const list = [...medsSel, ...other.split(',').map(s => s.trim()).filter(Boolean)]; answer(c.id, x => {
          list.forEach(n => { if (!x.meds.some(m => m.name.toLowerCase() === n.toLowerCase())) x.meds.push({ id: S.uid('med-'), name: n, dose: '', how: '', source: 'Told to Nightingale' }); }); x.medsConfirmed = true;
          const links = S.medLabLinks(list, x.labs);
          if (links.length) x.messages.push({ id: S.uid(), practiceId: '__draft__', from: 'me', at: S.nowIso(), text: `Draft question for my doctor: My recent labs showed ${S.latestLabs(x.labs).filter(l => S.labFlag(l) !== 'normal').map(l => `${l.name} ${l.value} ${l.unit}`).join(', ')}. I take ${list.join(', ')}. Could any of these explain the results?` });
          return links.length ? `Thank you, I added them to your medication list. In general terms: ${links.join(' ')} This is not a diagnosis, and please don't change any medicine on your own. I drafted a question for your doctor in Messages.` : `Thank you, I added them to your list. None of these are commonly known to affect those particular results, but your doctor can tell you more. I can draft a question for them.`;
        }, list.length ? `I take: ${list.join(', ')}` : 'I don’t take any medicines'); setMedsSel([]); setOther(''); }}>Send</button></div></div>}
      {c.kind === 'allergies' && <AllergyQuick onNone={() => answer(c.id, x => { x.allergiesVerified = true; return 'Got it: no known allergies, confirmed by you today. I’ll share that with any practice you link.'; }, 'No known allergies')} onAdd={(n, r) => answer(c.id, x => { x.allergies.push({ id: S.uid('al-'), name: n, reaction: r }); x.allergiesVerified = true; return `Recorded: ${n}${r ? ` (${r})` : ''}. Anything else? You can edit allergies any time.`; }, `I'm allergic to ${n}${r ? ` (${r})` : ''}`)} />}
      {c.kind === 'meds' && <button className="pp-btn ghost" onClick={() => go!('meds')} data-testid="pp-prompt-meds-go">Add my medicines</button>}
      {c.kind === 'history' && <HistQuick onSave={h => answer(c.id, x => { x.history = h; return h.length ? `Saved to your history: ${h.join(', ')}.` : 'Saved: no surgeries or ongoing conditions.'; }, h.length ? h.join(', ') : 'None')} />}
      {c.kind === 'connect' && <button className="pp-btn ghost" onClick={() => go!('connect')} data-testid="pp-prompt-connect-go">Connect my doctor</button>}
      {c.kind === 'doc' && <button className="pp-btn ghost" onClick={() => go!('docs')} data-testid="pp-prompt-doc-go">Open Documents</button>}
    </div>)}</section>}
    {max && all.length > max && <button className="pp-link" onClick={() => setMore(!more)} data-testid="pp-prompts-more">{more ? 'Fewer questions' : `Nightingale has ${all.length - max} more question${all.length - max > 1 ? 's' : ''}`}</button>}
  </>;
}
export function Home({ a, save, go }: P) {
  const [q, setQ] = useState(''); const [medsSel, setMedsSel] = useState<string[]>([]); const [other, setOther] = useState('');
  const cards = S.prompts(a);
  const say = (text: string, reply?: string) => save(x => { x.chat.push({ id: S.uid(), who: 'me', text, at: S.nowIso() }); x.chat.push({ id: S.uid(), who: 'ng', text: reply ?? S.nightingaleReply(x, text), at: S.nowIso() }); });
  const answer = (id: string, f: (x: Account) => string, me: string) => save(x => { x.answered.push(id); x.chat.push({ id: S.uid(), who: 'me', text: me, at: S.nowIso() }); x.chat.push({ id: S.uid(), who: 'ng', text: f(x), at: S.nowIso() }); });
  const chips: [string, () => void][] = [['Explain my labs', () => say('Explain my labs')], ['Check my medications', () => say('Check my medications')], ['Prepare for my visit', () => say('Help me prepare for my visit')], ['Find a doctor', () => go!('finder')], ['Connect my doctor', () => go!('connect')], ['Request my records', () => go!('connect')], ['Upload a document', () => go!('docs')]];
  return <div data-testid="pp-home">
    <header className="pp-ng"><div className="pp-ngicon">N</div><div><h1>Nightingale</h1><p>Your health journal. I explain and organize; I never diagnose or tell you whether to do something.</p></div></header>
    <PromptCards a={a} me={a} save={save} go={go} role="patient" />
    <section className="pp-card pp-chat" data-testid="pp-chat">
      {a.chat.slice(-12).map(m => <div key={m.id} className={'pp-bubble ' + m.who}>{m.text}</div>)}
      <div className="pp-chips">{chips.map(([l, f]) => <button key={l} className="pp-chip" onClick={f} data-testid={`pp-cmd-${l.split(' ')[0].toLowerCase()}`}>{l}</button>)}</div>
      <div className="pp-row"><input className="pp-input" placeholder="Ask Nightingale…" value={q} onChange={e => setQ(e.target.value)} onKeyDown={e => { if (e.key === 'Enter' && q.trim()) { say(q.trim()); setQ(''); } }} data-testid="pp-ask" /><button className="pp-btn" onClick={() => { if (q.trim()) { say(q.trim()); setQ(''); } }} data-testid="pp-ask-go">Send</button></div>
      <Carousel onTry={k => k === 'lab' ? go!('labs') : k === 'medlab' ? say('Check my medications') : k === 'wear' ? go!('plan') : k === 'visit' ? say('Help me prepare for my visit') : k === 'doc' ? go!('docs') : go!('family')} />
    </section>
  </div>;
}
export function AllergyQuick({ onNone, onAdd }: { onNone: () => void; onAdd: (n: string, r: string) => void }) {
  const [n, setN] = useState(''); const [r, setR] = useState('');
  return <div className="pp-row"><button className="pp-btn ghost" onClick={onNone} data-testid="pp-allergy-none">No known allergies</button><input className="pp-input" placeholder="Allergy" value={n} onChange={e => setN(e.target.value)} data-testid="pp-allergy-name" /><input className="pp-input" placeholder="Reaction" value={r} onChange={e => setR(e.target.value)} /><button className="pp-btn" disabled={!n.trim()} onClick={() => onAdd(n.trim(), r.trim())} data-testid="pp-allergy-add">Add</button></div>;
}
export function HistQuick({ onSave }: { onSave: (h: string[]) => void }) {
  const opts = ['High blood pressure', 'Asthma', 'Diabetes', 'Appendectomy', 'Knee surgery']; const [sel, setSel] = useState<string[]>([]);
  return <div><div className="pp-chips">{opts.map(o => <button key={o} className={'pp-chip' + (sel.includes(o) ? ' on' : '')} onClick={() => setSel(sel.includes(o) ? sel.filter(x => x !== o) : [...sel, o])}>{o}</button>)}</div><button className="pp-btn" onClick={() => onSave(sel)} data-testid="pp-history-save">{sel.length ? 'Save' : 'None of these'}</button></div>;
}

/* ---------------- Labs ---------------- */
export function Trend({ pts }: { pts: Lab[] }) {
  const W = 260, H = 70, s = [...pts].sort((x, y) => x.date.localeCompare(y.date)); const l = s[0];
  const vals = s.map(p => p.value).concat([l.low, l.high]); const mn = Math.min(...vals), mx = Math.max(...vals), sp = mx - mn || 1;
  const X = (i: number) => s.length === 1 ? W / 2 : 10 + i * (W - 20) / (s.length - 1), Y = (v: number) => H - 8 - (v - mn) / sp * (H - 16);
  return <svg width={W} height={H} className="pp-trend" data-testid="pp-trend"><rect x="0" y={Y(l.high)} width={W} height={Math.max(1, Y(l.low) - Y(l.high))} fill="#e4efe9" />
    <polyline fill="none" stroke="#1a5340" strokeWidth="2" points={s.map((p, i) => `${X(i)},${Y(p.value)}`).join(' ')} />
    {s.map((p, i) => <circle key={p.id} cx={X(i)} cy={Y(p.value)} r="3.5" fill={S.labFlag(p) === 'normal' ? '#1a5340' : '#b4442f'} />)}</svg>;
}
export function Labs({ a, save }: P) {
  const [open, setOpen] = useState<string | null>(null); const [msg, setMsg] = useState('');
  const groups = useMemo(() => { const g: Record<string, Lab[]> = {}; a.labs.forEach(l => (g[l.name] ||= []).push(l)); return Object.entries(g).sort((x, y) => Math.max(...y[1].map(l => +new Date(l.date))) - Math.max(...x[1].map(l => +new Date(l.date)))); }, [a]);
  const explain = (l: Lab) => { const fromP = l.source.includes('Vityls practice'); if (!S.canExplain(a, fromP)) { setMsg(`You've used your ${S.FREE_EXPLAIN_LIMIT} free explanations this month. Portal Plus is unlimited. Results your practice sends are always explained free.`); return; } save(x => S.useExplain(x, fromP)); setOpen(l.id); setMsg(''); };
  return <div data-testid="pp-labs"><h2>Labs</h2><p className="pp-muted">From every source, deduplicated. The shaded band is the lab's reference range.</p>
    {msg && <p className="pp-note" data-testid="pp-limit">{msg}</p>}
    {!groups.length && <p className="pp-card">No labs yet. Use Connect my doctor or upload a lab report.</p>}
    <div className="pp-grid">{groups.map(([n, l]) => { const last = [...l].sort((x, y) => y.date.localeCompare(x.date))[0]; const f = S.labFlag(last); return <div key={n} className="pp-card" data-testid={`pp-lab-${n.replace(/\s+/g, '-')}`}>
      <div className="pp-prompt-h"><b>{n}</b><span className={'pp-flag ' + f}>{f === 'normal' ? 'In range' : f === 'high' ? 'High' : 'Low'}</span></div>
      <div className="pp-big">{last.value} <small>{last.unit}</small></div><div className="pp-muted pp-small">{fmt(last.date)} · {last.source.split(' (')[0]} · {last.code}</div>
      <Trend pts={l} />
      {open === last.id ? <p className="pp-explain" data-testid="pp-lab-explain">{S.explainLab(last)}</p> : <button className="pp-link" onClick={() => explain(last)} data-testid="pp-lab-explain-btn">Explain in plain language</button>}
    </div>; })}</div></div>;
}

/* ---------------- Documents ---------------- */
export function Docs({ a, save }: P) {
  const [type, setType] = useState('Lab report'); const [msg, setMsg] = useState('');
  const upload = (f: File) => { const r = new FileReader(); r.onload = () => save(x => { x.docs.unshift({ id: S.uid('doc-'), title: f.name.replace(/\.[^.]+$/, ''), type, date: S.today(), source: 'Uploaded by me', size: `${Math.max(1, Math.round(f.size / 1024))} KB`, dataUrl: f.size < 1.5e6 ? String(r.result) : undefined });
    if (!x.sources.some(s => s.kind === 'patient-upload')) x.sources.push({ id: 'me', kind: 'patient-upload', name: 'My uploads', connectedAt: S.nowIso() }); x.audit.push({ at: S.nowIso(), what: `Uploaded ${f.name}` }); }); r.readAsDataURL(f); };
  const explain = (d: Doc) => { if (!S.canExplain(a, d.fromPractice)) { setMsg(`Free plan limit reached (${S.FREE_EXPLAIN_LIMIT}/month). Documents from your practice are always explained free.`); return; } save(x => { S.useExplain(x, d.fromPractice); const t = x.docs.find(y => y.id === d.id)!; t.explained = S.explainDoc(t); }); };
  return <div data-testid="pp-docs"><h2>Documents</h2>
    <div className="pp-card pp-row"><select className="pp-input" value={type} onChange={e => setType(e.target.value)} data-testid="pp-doc-type">{['Lab report', 'Imaging report', 'Visit note', 'Insurance card', 'Other'].map(t => <option key={t}>{t}</option>)}</select>
      <label className="pp-btn">Upload a file<input type="file" hidden accept="image/*,.pdf" onChange={e => e.target.files?.[0] && upload(e.target.files[0])} data-testid="pp-doc-upload" /></label><span className="pp-muted pp-small">Photos or PDFs. Nightingale sorts and explains them.</span></div>
    {msg && <p className="pp-note">{msg}</p>}
    <table className="pp-table" data-testid="pp-doc-table"><thead><tr><th>Document</th><th>Type</th><th>Date</th><th>From</th><th /></tr></thead><tbody>{a.docs.map(d => <tr key={d.id}>
      <td><b>{d.title}</b>{d.note && <div className="pp-small pp-muted">Note: {d.note}</div>}{d.explained && <div className="pp-explain" data-testid="pp-doc-explained">{d.explained}</div>}</td><td>{d.type}</td><td>{fmt(d.date)}</td><td>{d.source.split(' (')[0]}{d.fromPractice && <div className="pp-small pp-free">from your practice · always free</div>}</td>
      <td className="pp-nowrap">{!d.explained && <button className="pp-link" onClick={() => explain(d)} data-testid="pp-doc-explain">Explain</button>}{d.dataUrl && <a className="pp-link" href={d.dataUrl} download={d.title}>Download</a>}</td></tr>)}</tbody></table></div>;
}

/* ---------------- Medications & allergies ---------------- */
export function Meds({ a, save }: P) {
  const [m, setM] = useState({ name: '', dose: '', how: '' }); const [al, setAl] = useState({ name: '', reaction: '' });
  return <div data-testid="pp-meds"><h2>Medications & allergies</h2><div className="pp-grid2">
    <section className="pp-card"><h3>Medications</h3>{!a.meds.length && <p className="pp-muted">None recorded.</p>}
      {a.meds.map(x => <div key={x.id} className="pp-li"><div><b>{x.name}</b> {x.dose} {x.how}<div className="pp-small pp-muted">{x.source.split(' (')[0]}</div></div><button className="pp-link" onClick={() => save(y => { y.meds = y.meds.filter(z => z.id !== x.id); })}>Remove</button></div>)}
      <div className="pp-row"><input className="pp-input" placeholder="Medicine" value={m.name} onChange={e => setM({ ...m, name: e.target.value })} data-testid="pp-med-name" /><input className="pp-input" placeholder="Dose" value={m.dose} onChange={e => setM({ ...m, dose: e.target.value })} /><input className="pp-input" placeholder="How often" value={m.how} onChange={e => setM({ ...m, how: e.target.value })} />
        <button className="pp-btn" disabled={!m.name.trim()} onClick={() => { save(y => { y.meds.push({ id: S.uid('med-'), ...m, source: 'Entered by me' }); y.medsConfirmed = true; }); setM({ name: '', dose: '', how: '' }); }} data-testid="pp-med-add">Add</button></div>
      {!a.medsConfirmed && !a.meds.length && <button className="pp-link" onClick={() => save(y => { y.medsConfirmed = true; })}>I don't take any medicines</button>}</section>
    <section className="pp-card"><h3>Allergies</h3>{a.allergies.length ? a.allergies.map(x => <div key={x.id} className="pp-li"><div><b>{x.name}</b> <span className="pp-muted">{x.reaction}</span></div><button className="pp-link" onClick={() => save(y => { y.allergies = y.allergies.filter(z => z.id !== x.id); })}>Remove</button></div>) : <p className="pp-muted" data-testid="pp-allergy-state">{a.allergiesVerified ? 'No known allergies (confirmed by you).' : 'Not recorded yet.'}</p>}
      <div className="pp-row"><input className="pp-input" placeholder="Allergy" value={al.name} onChange={e => setAl({ ...al, name: e.target.value })} data-testid="pp-al-name" /><input className="pp-input" placeholder="Reaction" value={al.reaction} onChange={e => setAl({ ...al, reaction: e.target.value })} />
        <button className="pp-btn" disabled={!al.name.trim()} onClick={() => { save(y => { y.allergies.push({ id: S.uid('al-'), ...al }); y.allergiesVerified = true; }); setAl({ name: '', reaction: '' }); }} data-testid="pp-al-add">Add</button></div></section>
  </div></div>;
}

/* ---------------- Connect my doctor ---------------- */
export function Connect({ a, save }: P) {
  const [q, setQ] = useState(''); const [step, setStep] = useState<{ id: string; phase: 'login' | 'consent' } | null>(null); const [res, setRes] = useState('');
  const [rr, setRr] = useState(() => { const pf = JSON.parse(sessionStorage.getItem('vityls:portal:rr-prefill') || 'null'); sessionStorage.removeItem('vityls:portal:rr-prefill'); return { provider: pf?.provider || '', fax: pf?.fax || '', scope: 'All records from the last 3 years: notes, labs, imaging reports, medication list' }; }); const [draft, setDraft] = useState<S.RecordsRequest | null>(null);
  const [rec, setRec] = useState(() => { const v = sessionStorage.getItem('vityls:portal:ul-prefill') || ''; sessionStorage.removeItem('vityls:portal:ul-prefill'); return v; }); const links = S.uploadLinks().filter(l => l.acctId === a.id); const [, bump] = useState(0);
  const dir = S.FHIR_DIRECTORY.filter(d => (d.name + d.vendor).toLowerCase().includes(q.toLowerCase()));
  const base = location.href.split('#')[0];
  return <div data-testid="pp-connect"><h2>Connect my doctor</h2><p className="pp-muted">Your records are yours by law (HIPAA right of access, 21st Century Cures Act). Four ways to bring them in, none of which need your doctor to be on Vityls.</p>
    <section className="pp-card"><h3>1 · Sign in to your patient portal (FHIR)</h3><p className="pp-muted pp-small">Epic MyChart, Oracle Health, athenahealth and other certified systems. Simulated: fictional health systems, no real sign-in.</p>
      <input className="pp-input" placeholder="Search health systems" value={q} onChange={e => setQ(e.target.value)} data-testid="pp-fhir-search" />
      {dir.map(d => { const c = a.sources.find(s => s.id === d.id); return <div key={d.id} className="pp-li" data-testid={`pp-fhir-${d.id}`}><div><b>{d.name}</b> <span className="pp-muted">{d.vendor} · {d.city}</span>{c && <div className="pp-small pp-free">Connected · last sync {fmt(c.lastSync || c.connectedAt)}</div>}</div>
        <button className="pp-btn ghost" onClick={() => setStep({ id: d.id, phase: 'login' })} data-testid={`pp-fhir-connect-${d.id}`}>{c ? 'Sync again' : 'Connect'}</button></div>; })}
      {step && <div className="pp-modal" data-testid="pp-fhir-modal"><div className="pp-card">{step.phase === 'login' ? <><h3>{S.FHIR_DIRECTORY.find(d => d.id === step.id)!.vendor} sign-in (simulated)</h3><p className="pp-muted">In production this is the health system's own login page (SMART on FHIR). Vityls never sees your password.</p><input className="pp-input" defaultValue={a.email} /><input className="pp-input" type="password" defaultValue="********" />
        <button className="pp-btn" onClick={() => setStep({ ...step, phase: 'consent' })} data-testid="pp-fhir-login">Sign in</button></> : <><h3>Allow Vityls Portal to read your records?</h3><ul className="pp-small"><li>Labs and vitals (Observation)</li><li>Medications, allergies, conditions</li><li>Visit notes and reports (DocumentReference)</li></ul>
        <button className="pp-btn" onClick={() => { let r: ReturnType<typeof S.simulatedFhirImport>; save(x => { r = S.simulatedFhirImport(x, step.id); }); setRes(`Imported ${r!.labs} labs, ${r!.meds} medications, ${r!.docs} documents, ${r!.allergies} allergies. ${r!.dupes} duplicates skipped. Nightingale has questions for you on Home.`); setStep(null); }} data-testid="pp-fhir-allow">Allow</button></>}
        <button className="pp-link" onClick={() => setStep(null)}>Cancel</button></div></div>}
      {res && <p className="pp-note" data-testid="pp-fhir-result">{res}</p>}</section>
    <section className="pp-card"><h3>2 · Records request (fax or Direct)</h3><p className="pp-muted pp-small">For offices without a portal. Nightingale writes your HIPAA right-of-access request with a return inbox just for this request; records that come back file themselves.</p>
      <div className="pp-row"><input className="pp-input" placeholder="Doctor or office" value={rr.provider} onChange={e => setRr({ ...rr, provider: e.target.value })} data-testid="pp-rr-provider" /><input className="pp-input" placeholder="Office fax" value={rr.fax} onChange={e => setRr({ ...rr, fax: e.target.value })} data-testid="pp-rr-fax" /></div>
      <input className="pp-input pp-wide" value={rr.scope} onChange={e => setRr({ ...rr, scope: e.target.value })} /><button className="pp-btn" disabled={!rr.provider.trim()} onClick={() => setDraft(S.newRecordsRequest(a, rr.provider, rr.fax, rr.scope))} data-testid="pp-rr-make">Write the request</button>
      {draft && <div className="pp-letter" data-testid="pp-rr-letter"><p><b>Request for access to my health information (45 CFR 164.524)</b></p><p>To: {draft.provider}{draft.fax && `, fax ${draft.fax}`}<br />From: {a.name}, date of birth {fmt(a.dob)}</p>
        <p>Under the HIPAA right of access, I request a copy of: {draft.scope}. Please send electronic copies if available. This is my own request for my own records; it is not an authorization to disclose to a third party.</p>
        <p>Send to fax <b>{draft.returnFax}</b> or Direct secure email <b>{draft.returnDirect}</b> (reference {draft.id}). Please respond within 30 days (by {fmt(draft.due)}).</p><p>Signed electronically: {a.name} · {fmt(S.today())}</p>
        <div className="pp-row"><button className="pp-btn" onClick={() => { save(x => { x.requests.push({ ...draft, status: 'sent (simulated)' }); x.reminders.push({ id: S.uid(), title: `Records due from ${draft.provider} (${draft.id})`, due: draft.due, repeat: 'once' }); }); setDraft(null); }} data-testid="pp-rr-send">Send (simulated)</button><button className="pp-link" onClick={() => window.print()}>Print</button></div></div>}
      {a.requests.map(r => <div key={r.id} className="pp-li" data-testid="pp-rr-row"><div><b>{r.provider}</b> <span className="pp-muted">{r.id} · {r.status} · due {fmt(r.due)}</span></div>
        {r.status !== 'received' && <button className="pp-link" onClick={() => save(x => { const t = x.requests.find(y => y.id === r.id)!; t.status = 'received'; x.docs.unshift({ id: S.uid('doc-'), title: `Records from ${r.provider}`, type: 'Visit note', date: S.today(), source: `${r.provider} (fax to ${r.id}, simulated)`, size: '12 pages' }); })} data-testid="pp-rr-simreceive">Simulate fax received</button>}</div>)}</section>
    <section className="pp-card"><h3>3 · Secure upload link for an office</h3><p className="pp-muted pp-small">Give an office a one-time link or QR code. They upload results for you only, without an account. Expires in 7 days.</p>
      <div className="pp-row"><input className="pp-input" placeholder="Office name (optional)" value={rec} onChange={e => setRec(e.target.value)} data-testid="pp-ul-recipient" /><button className="pp-btn" onClick={() => { S.newUploadLink(a, rec || 'Outside office'); setRec(''); bump(n => n + 1); }} data-testid="pp-ul-make">Create link</button></div>
      {links.map(l => { const st = S.linkStatus(l); const url = `${base}#portal-upload=${l.token}`; return <div key={l.token} className="pp-li" data-testid="pp-ul-row"><div className="pp-ul"><QR text={l.token} /><div><b>{l.recipient}</b> <span className="pp-muted">· {st === 'ok' ? `expires ${fmt(l.expires)}` : st} · {l.uploads} uploads</span><div className="pp-small pp-mono" data-testid="pp-ul-url">{url}</div></div></div>
        <div className="pp-nowrap"><a className="pp-link" href={url} target="_blank" data-testid="pp-ul-open">Open as the office</a>{st === 'ok' && <button className="pp-link" onClick={() => { S.saveLink({ ...l, revoked: true }); bump(n => n + 1); }}>Revoke</button>}</div></div>; })}</section>
    <section className="pp-card pp-muted"><h3>4 · Nationwide networks (later)</h3><p className="pp-small">TEFCA Individual Access Services and Carequality/CommonWell will let you pull records from almost every participating provider at once, after identity verification. Not in this test build.</p></section>
    <section className="pp-card"><h3>Your sources</h3>{a.sources.map(s => <div key={s.id} className="pp-li"><div><b>{s.name}</b> <span className="pp-muted">{s.kind}{s.vendor ? ` · ${s.vendor}` : ''}</span></div><span className="pp-small pp-muted">since {fmt(s.connectedAt)}</span></div>)}</section>
  </div>;
}
/** Decorative QR-style mark derived from the token (simulated; not a scannable QR code). */
export function QR({ text }: { text: string }) {
  const n = 11; let h = 0; const cells: boolean[] = []; for (let i = 0; i < n * n; i++) { h = (h * 31 + text.charCodeAt(i % text.length) + i) >>> 0; cells.push((h >> 7) % 2 === 0); }
  const fin = (x: number, y: number) => (x < 3 && y < 3) || (x > n - 4 && y < 3) || (x < 3 && y > n - 4);
  return <svg width="56" height="56" viewBox={`0 0 ${n} ${n}`} className="pp-qr">{cells.map((c, i) => { const x = i % n, y = Math.floor(i / n); return (fin(x, y) || c) ? <rect key={i} x={x} y={y} width="1" height="1" fill="#143f31" /> : null; })}</svg>;
}

/* ---------------- Plan ---------------- */
export function PlanPage({ a, save }: P) {
  const plus = S.isPlus(a);
  return <div data-testid="pp-plan"><h2>Your plan</h2><div className="pp-grid2">
    <section className={'pp-card' + (!plus ? ' pp-current' : '')} data-testid="pp-plan-free"><h3>Free</h3><ul className="pp-small"><li>Your account, records, labs, documents, medicines, allergies</li><li>Plain-language explanations ({S.FREE_EXPLAIN_LIMIT} per month; used {a.plan.explainUsed})</li><li>Reminders, refill requests, messages</li><li>Connect my doctor, records requests, upload links</li><li><b>Everything your practice sends</b>: forms, check-in, results, messages, bills. Always free.</li></ul>{!plus && <span className="pp-pill">Current plan</span>}</section>
    <section className={'pp-card' + (plus ? ' pp-current' : '')} data-testid="pp-plan-plus"><h3>Portal Plus <span className="pp-muted pp-small">$6.99/month (test price)</span></h3><ul className="pp-small"><li>Wearables and home devices (Apple Health, Fitbit, BP cuff, glucose meter)</li><li>Unlimited explanations and whole-record review</li><li>Report drafting: visit-prep summary, symptom diary, summary for a new doctor</li></ul>
      {plus ? <p className="pp-free" data-testid="pp-plan-state">{a.plan.state === 'trial' ? `Free trial · ends ${fmt(a.plan.trialEnd!)}` : 'Active'}</p> : <div className="pp-row"><button className="pp-btn" onClick={() => save(x => { x.plan.state = 'trial'; x.plan.trialEnd = new Date(Date.now() + 14 * 864e5).toISOString().slice(0, 10); x.audit.push({ at: S.nowIso(), what: 'Portal Plus trial started (14 days)' }); })} data-testid="pp-plan-trial">Try free for 14 days</button><button className="pp-btn ghost" onClick={() => save(x => { x.plan.state = 'active'; })} data-testid="pp-plan-upgrade">Upgrade (simulated)</button></div>}
      {plus && <button className="pp-link" onClick={() => save(x => { x.plan.state = 'free'; x.plan.trialEnd = undefined; })} data-testid="pp-plan-cancel">Switch back to Free</button>}</section></div>
    <section className="pp-card" data-testid="pp-wearables"><h3>Wearables & devices {!plus && <span className="pp-pill">Plus</span>}</h3>{plus ? <><p className="pp-muted pp-small">Simulated device data (fictional).</p><div className="pp-grid">{[['Apple Health', 'Steps 7,842 · resting HR 61'], ['Omron BP cuff', '128/79 this morning'], ['Fitbit', 'Sleep 6 h 50 m']].map(([n, v]) => <div key={n} className="pp-li" data-testid="pp-wearable"><b>{n}</b><span>{v}</span></div>)}</div></> : <p className="pp-muted" data-testid="pp-wearables-locked">Connect Apple Health, Fitbit and home devices with Portal Plus. Try it free for 14 days.</p>}</section>
    <section className="pp-card" data-testid="pp-report"><h3>Visit-prep summary {!plus && <span className="pp-pill">Plus</span>}</h3>{plus ? <div className="pp-letter" data-testid="pp-report-draft"><b>Health summary for {a.name}</b> (draft by Nightingale, for you to review)<p>Medicines: {a.meds.map(m => `${m.name} ${m.dose}`).join(', ') || 'none recorded'}. Allergies: {a.allergies.map(x => x.name).join(', ') || (a.allergiesVerified ? 'no known allergies' : 'not recorded')}.</p><p>Out-of-range labs: {S.latestLabs(a.labs).filter(l => S.labFlag(l) !== 'normal').map(l => `${l.name} ${l.value} ${l.unit} (${fmt(l.date)})`).join('; ') || 'none'}.</p><p>Symptoms noted: {a.symptoms.map(s => s.text).join('; ') || 'none'}.</p><p className="pp-small pp-muted">Questions to ask: what do my results mean for me, and does anything need follow-up?</p></div> : <p className="pp-muted">Nightingale drafts a one-page summary to bring to your visit.</p>}</section>
  </div>;
}

/* ---------------- Provider upload page (no account) ---------------- */
export function ProviderUploadPage({ token }: { token: string }) {
  useEffect(() => { S.seedPortal(); }, []);
  const [l, setL] = useState(() => S.uploadLinks().find(x => x.token === token)); const st = S.linkStatus(l);
  const [f, setF] = useState({ office: '', title: '', type: 'Lab report', note: '' }); const [file, setFile] = useState<File | null>(null); const [done, setDone] = useState(0);
  const submit = () => { if (!l || !file) return; const a = S.getAccount(l.acctId); if (!a) return; const r = new FileReader(); r.onload = () => {
    a.docs.unshift({ id: S.uid('doc-'), title: f.title || file.name.replace(/\.[^.]+$/, ''), type: f.type, date: S.today(), source: `${f.office || l.recipient} (secure upload link, simulated)`, size: `${Math.max(1, Math.round(file.size / 1024))} KB`, note: f.note || undefined, dataUrl: file.size < 1.5e6 ? String(r.result) : undefined });
    if (!a.sources.some(s => s.id === 'ul-' + l.token)) a.sources.push({ id: 'ul-' + l.token, kind: 'upload-link', name: f.office || l.recipient, connectedAt: S.nowIso() });
    a.audit.push({ at: S.nowIso(), what: `Upload link: ${f.office || l.recipient} uploaded ${file.name}` }); S.saveAccount(a); const nl = { ...l, uploads: l.uploads + 1 }; S.saveLink(nl); setL(nl); setDone(d => d + 1); setFile(null); setF({ ...f, title: '', note: '' }); }; r.readAsDataURL(file); };
  const initials = l ? l.patient.split(' ').map(x => x[0]).join('') + '.' : '';
  return <div className="pp-auth" data-testid="pp-upload-page"><div className="pp-card pp-authcard"><div className="pp-logo"><span className="pp-dot" />Vityls <b>Secure upload</b></div>
    {st !== 'ok' ? <><h1>This link is {st === 'missing' ? 'not valid' : st}</h1><p className="pp-muted" data-testid="pp-upload-invalid">Ask the patient for a new link.</p></> : <>
      <h1>Send records to {initials}</h1><p className="pp-muted">Your patient asked you to upload their records here. No account needed. Only this patient receives what you upload. Link expires {fmt(l!.expires)}.</p>
      <label className="pp-field">Your office<input value={f.office} onChange={e => setF({ ...f, office: e.target.value })} data-testid="pp-up-office" /></label>
      <label className="pp-field">Document title<input value={f.title} onChange={e => setF({ ...f, title: e.target.value })} data-testid="pp-up-title" /></label>
      <label className="pp-field">Type<select value={f.type} onChange={e => setF({ ...f, type: e.target.value })}>{['Lab report', 'Imaging report', 'Visit note', 'Other'].map(t => <option key={t}>{t}</option>)}</select></label>
      <label className="pp-field">Note for the patient (optional)<input value={f.note} onChange={e => setF({ ...f, note: e.target.value })} data-testid="pp-up-note" /></label>
      <input type="file" onChange={e => setFile(e.target.files?.[0] || null)} data-testid="pp-up-file" />
      <button className="pp-btn" disabled={!file} onClick={submit} data-testid="pp-up-send">Upload securely (simulated)</button>
      {done > 0 && <p className="pp-note" data-testid="pp-up-done">Uploaded. The patient will see it in their Documents. ({l!.uploads} so far)</p>}
      <div className="pp-promo"><b>Your practice could do this every day.</b> Vityls connects practices to their patients: forms, check-in, results and messages, with Nightingale. Learn about Vityls for practices.</div></>}
  </div></div>;
}

/* ---------------- Doctor Finder (v0.3) ---------------- */
const FINDER_CHIPS = ['Find a cardiologist near 90210', 'Dermatologists in Beverly Hills', 'Family medicine in Los Angeles', 'Pediatricians near 90048', 'Orthopaedic surgeon near 90211'];
const PAGE_SIZE = 10;
export function Finder({ acct, onNeed }: { acct?: P; onNeed?: (reason: string) => void }) {
  useHubTick();
  const [q, setQ] = useState<F.Query>({ city: 'Beverly Hills', state: 'CA', specialty: 'Cardiovascular Disease' }); const [text, setText] = useState('');
  const [mode, setModeS] = useState<F.Mode>(F.getMode()); const [liveNote, setLiveNote] = useState(''); const [live, setLive] = useState<F.Provider[] | null>(null); const [busy, setBusy] = useState(false);
  const [sort, setSort] = useState<F.Sort>('last'); const [flt, setFlt] = useState({ sex: '', cred: '', vityls: false, minYears: 0 }); const [pg, setPg] = useState(0); const [detail, setDetail] = useState<F.Provider | null>(null); const [msg, setMsg] = useState('');
  const base = mode === 'live' && live ? live : F.searchSnapshot(q);
  const yrs = (p: F.Provider) => new Date().getFullYear() - (parseInt(p.enumerated) || 9999);
  const list = F.sortList(base.filter(p => (!flt.sex || p.sex === flt.sex) && (!flt.cred || p.credential.replace(/\./g, '').toUpperCase().includes(flt.cred)) && (!flt.vityls || p.vityls) && yrs(p) >= flt.minYears), sort);
  const pages = Math.max(1, Math.ceil(list.length / PAGE_SIZE)); const shown = list.slice(pg * PAGE_SIZE, pg * PAGE_SIZE + PAGE_SIZE);
  const run = async (nq: F.Query) => { setQ(nq); setPg(0); setDetail(null); setLive(null); if (mode === 'live') { setBusy(true); try { setLive(await F.searchLive(nq)); setLiveNote('Live NPPES results.'); } catch { setLiveNote('Live call failed (the NPPES API sends no CORS headers, so browsers block it). Showing the bundled snapshot.'); setLive(null); } setBusy(false); } };
  const ask = (t: string) => { const nq = F.parse(t); setText(t); run(nq); };
  const a = acct?.a; const me = acct?.me; const role = acct?.role || 'patient';
  const need = (what: string) => { onNeed?.(`${what} needs a free account. Searching stays free.`); };
  const linked = (p: F.Provider) => a && p.vityls && H.linksFor(a.id).find(l => l.practiceId === p.vityls!.practiceId && l.status === 'active');
  const inTeam = (p: F.Provider) => !!a && (a.outside || []).some(x => x.id === 'npi-' + p.npi);
  const actions = (p: F.Provider) => {
    if (p.vityls) return <div className="pp-row">
      <button className="pp-btn" onClick={() => { if (!a) return need('Connecting to a practice'); H.patientConnect(a, p.vityls!.practiceId, p.vityls!.practiceName, F.displayName(p), me!.name, role); setMsg(`Connected to ${p.vityls!.practiceName}. It now appears in Care team.`); }} disabled={!!linked(p)} data-testid="fd-connect">{linked(p) ? 'Connected' : 'Connect'}</button>
      <button className="pp-btn ghost" onClick={() => { if (!a) return need('Messaging a practice'); if (!linked(p)) H.patientConnect(a, p.vityls!.practiceId, p.vityls!.practiceName, F.displayName(p), me!.name, role); acct!.go!('inbox'); }} data-testid="fd-message">Message</button>
      <button className="pp-btn ghost" onClick={() => { if (!a) return need('Requesting an appointment'); if (!linked(p)) H.patientConnect(a, p.vityls!.practiceId, p.vityls!.practiceName, F.displayName(p), me!.name, role); H.patientSend(a.id, p.vityls!.practiceId, 'appt-request', 'Appointment request', `New appointment request with ${F.displayName(p)} (from the Doctor Finder)`, me!.name, role); setMsg(`Appointment request sent to ${p.vityls!.practiceName}.`); }} data-testid="fd-book">Request appointment</button></div>;
    return <div className="pp-row">
      <button className="pp-btn ghost" disabled={inTeam(p)} onClick={() => { if (!a) return need('Saving to your care team'); acct!.save(x => { (x.outside ||= []).push({ id: 'npi-' + p.npi, name: F.displayName(p), specialty: `${p.specialty} · NPI ${p.npi}`, phone: F.phoneFmt(p.phone) }); }); setMsg(`${F.displayName(p)} added to your care team.`); }} data-testid="fd-add">{inTeam(p) ? 'In my care team' : 'Add to my care team'}</button>
      <button className="pp-btn ghost" onClick={() => { if (!a) return need('Sending a records request'); sessionStorage.setItem('vityls:portal:rr-prefill', JSON.stringify({ provider: `${F.displayName(p)} (NPI ${p.npi})`, fax: F.phoneFmt(p.fax) })); acct!.go!('connect'); }} data-testid="fd-rr">Send records request</button>
      <button className="pp-btn ghost" onClick={() => { if (!a) return need('Sending an upload link'); sessionStorage.setItem('vityls:portal:ul-prefill', F.displayName(p)); acct!.go!('connect'); }} data-testid="fd-ul">Send upload link</button></div>;
  };
  const Card = ({ p }: { p: F.Provider }) => <div className="pp-card pp-doc" data-testid="fd-card">
    <div className="pp-prompt-h"><div><button className="pp-link pp-docname" onClick={() => setDetail(p)} data-testid="fd-open"><b>{F.displayName(p)}</b></button>{p.vityls && <span className="pp-pill pp-vbadge" data-testid="fd-vityls">Vityls</span>}{p.fictional && <span className="pp-small pp-muted"> · fictional test entry</span>}
      <div className="pp-small">{p.specialty}</div></div><span className="pp-small pp-muted pp-mono" data-testid="fd-npi">NPI {p.npi}</span></div>
    <div className="pp-small pp-muted">{p.org && p.type === 'NPI-1' ? p.org + ' · ' : ''}{p.line1}{p.line2 ? ', ' + p.line2 : ''}, {p.city}, {p.state} {p.zip}</div>
    <div className="pp-small pp-muted">{p.phone && <>Phone {F.phoneFmt(p.phone)}</>}{p.fax && <> · Fax {F.phoneFmt(p.fax)}</>}{p.enumerated && <> · <span data-testid="fd-since">{F.since(p)}</span></>}</div>
    {actions(p)}</div>;
  return <div data-testid="pp-finder"><h2>Find a doctor</h2>
    <p className="pp-muted pp-small">From the public NPPES NPI Registry (CMS). Nightingale lists doctors; she never ranks them or says one is better. Years are estimated from the NPI date, which isn't a record of years in practice.</p>
    <div className="pp-mode" data-testid="fd-mode">{mode === 'snapshot' ? <>Mode: <b>bundled snapshot</b> · {F.SNAPSHOT_INFO.count} real public NPI records for Beverly Hills and Los Angeles, CA (12 specialties) · fetched {F.SNAPSHOT_INFO.fetched.slice(0, 10)}</> : <>Mode: <b>live NPPES</b>{F.proxyUrl() ? ' via Vityls proxy' : ' (direct)'}</>}
      <button className="pp-link" onClick={async () => { const m: F.Mode = mode === 'snapshot' ? 'live' : 'snapshot'; F.setMode(m); setModeS(m); setLive(null); if (m === 'live') setLiveNote(await F.checkLive()); else setLiveNote(''); }} data-testid="fd-mode-toggle">{mode === 'snapshot' ? 'Try live' : 'Use snapshot'}</button>
      {liveNote && <div className="pp-small" data-testid="fd-live-note">{liveNote}</div>}</div>
    <div className="pp-chips">{FINDER_CHIPS.map(c => <button key={c} className="pp-chip" onClick={() => ask(c)} data-testid="fd-chip">{c}</button>)}</div>
    <div className="pp-row"><input className="pp-input" placeholder="Ask Nightingale: “find a dermatologist in Los Angeles”" value={text} onChange={e => setText(e.target.value)} onKeyDown={e => e.key === 'Enter' && ask(text)} data-testid="fd-ask" /><button className="pp-btn" onClick={() => ask(text)} data-testid="fd-ask-go">Search</button></div>
    <div className="pp-card pp-row pp-filters">
      <input className="pp-input" placeholder="Name" value={q.name || ''} onChange={e => setQ({ ...q, name: e.target.value })} data-testid="fd-name" />
      <select className="pp-input" value={q.specialty || ''} onChange={e => setQ({ ...q, specialty: e.target.value })} data-testid="fd-specialty"><option value="">Any specialty</option>{F.SPECIALTIES.map(s => <option key={s}>{s}</option>)}</select>
      <input className="pp-input" placeholder="Practice / organization" value={q.org || ''} onChange={e => setQ({ ...q, org: e.target.value })} data-testid="fd-org" />
      <input className="pp-input" placeholder="City" value={q.city || ''} onChange={e => setQ({ ...q, city: e.target.value })} data-testid="fd-city" />
      <input className="pp-input pp-narrow" placeholder="State" value={q.state || ''} onChange={e => setQ({ ...q, state: e.target.value })} data-testid="fd-state" />
      <input className="pp-input pp-narrow" placeholder="ZIP" value={q.zip || ''} onChange={e => setQ({ ...q, zip: e.target.value })} data-testid="fd-zip" />
      <button className="pp-btn" onClick={() => run(q)} data-testid="fd-search">Search</button>
      <button className="pp-link" onClick={() => run({})} data-testid="fd-clear">Clear</button></div>
    <div className="pp-row pp-small"><span data-testid="fd-count">{busy ? 'Searching…' : `${list.length} providers`}{q.zip ? ` · near ${q.zip} (same ZIP area)` : ''}</span>
      <select className="pp-input pp-narrow" value={flt.sex} onChange={e => { setFlt({ ...flt, sex: e.target.value }); setPg(0); }} data-testid="fd-f-sex"><option value="">Any gender</option><option value="F">Female</option><option value="M">Male</option></select>
      <select className="pp-input pp-narrow" value={flt.cred} onChange={e => { setFlt({ ...flt, cred: e.target.value }); setPg(0); }} data-testid="fd-f-cred"><option value="">Any credential</option>{['MD', 'DO', 'NP', 'PA'].map(c => <option key={c}>{c}</option>)}</select>
      <select className="pp-input pp-narrow" value={flt.minYears} onChange={e => { setFlt({ ...flt, minYears: +e.target.value }); setPg(0); }} data-testid="fd-f-years"><option value={0}>Any NPI age</option><option value={10}>NPI 10+ yrs</option><option value={15}>NPI 15+ yrs</option></select>
      <label><input type="checkbox" checked={flt.vityls} onChange={e => { setFlt({ ...flt, vityls: e.target.checked }); setPg(0); }} data-testid="fd-f-vityls" /> On Vityls only</label>
      <select className="pp-input pp-narrow" value={sort} onChange={e => setSort(e.target.value as F.Sort)} data-testid="fd-sort"><option value="last">Last name A–Z</option><option value="first">First name A–Z</option><option value="since-old">NPI date, oldest first</option><option value="since-new">NPI date, newest first</option><option value="zip">ZIP</option></select></div>
    {msg && <p className="pp-note" data-testid="fd-msg">{msg}</p>}
    {detail ? <div className="pp-card" data-testid="fd-detail"><button className="pp-link" onClick={() => setDetail(null)} data-testid="fd-back">← Back to results</button>
      <h3>{F.displayName(detail)} {detail.vityls && <span className="pp-pill pp-vbadge">Vityls</span>}</h3>
      <table className="pp-table"><tbody>
        <tr><td>NPI</td><td className="pp-mono">{detail.npi} {!detail.fictional && <a className="pp-link" href={`https://npiregistry.cms.hhs.gov/provider-view/${detail.npi}`} target="_blank" rel="noreferrer">view on NPPES</a>}</td></tr>
        <tr><td>Type</td><td>{detail.type === 'NPI-1' ? 'Individual' : 'Organization'}{detail.sex ? ` · ${detail.sex === 'F' ? 'Female' : 'Male'}` : ''}</td></tr>
        <tr><td>Specialties (NUCC)</td><td data-testid="fd-taxonomies">{detail.taxonomies.join(' · ')} <span className="pp-muted pp-small">(primary code {detail.taxonomy})</span></td></tr>
        <tr><td>Practice address</td><td>{detail.line1}{detail.line2 ? ', ' + detail.line2 : ''}, {detail.city}, {detail.state} {detail.zip}</td></tr>
        <tr><td>Phone / fax</td><td>{F.phoneFmt(detail.phone) || '—'} / {F.phoneFmt(detail.fax) || '—'}</td></tr>
        <tr><td>Years</td><td>{F.since(detail)}</td></tr><tr><td>NPI record updated</td><td>{detail.updated}</td></tr></tbody></table>
      <p className="pp-small pp-muted">Nightingale doesn't rate doctors. Check insurance, location and availability with the office.</p>{actions(detail)}</div>
    : <>{shown.map(p => <Card key={p.npi} p={p} />)}{!shown.length && <p className="pp-card pp-muted" data-testid="fd-empty">No providers match. Try a nearby ZIP or a broader specialty.</p>}
      {pages > 1 && <div className="pp-row pp-pager" data-testid="fd-pager"><button className="pp-btn ghost" disabled={pg === 0} onClick={() => setPg(pg - 1)} data-testid="fd-prev">Previous</button><span className="pp-small" data-testid="fd-page">Page {pg + 1} of {pages}</span><button className="pp-btn ghost" disabled={pg >= pages - 1} onClick={() => setPg(pg + 1)} data-testid="fd-next">Next</button></div>}</>}
  </div>;
}
