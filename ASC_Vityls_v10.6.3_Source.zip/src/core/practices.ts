/*
 * Vityls Core · tenant + entitlements (simulated, browser storage; in production: practices, practice_modules, trials,
 * plans tables in Vityls Core — see report/Vityls_Core_Modules_Architecture.md).
 * This file must not import the app: edition.ts reads it before the per-practice storage namespace is installed.
 */
import { ALL_MODULE_IDS, EDITION_BUNDLES, MOD, ModuleId, requiresDeep, dependents } from './modules';

const raw: Storage = window.localStorage; // captured before any namespace proxy
const K = 'vityls:core:';
const DAY = 86400000;
export type ModState = 'off' | 'trial' | 'active' | 'expired';
export interface Entitlement { state: ModState; trialStart?: string; trialEnd?: string; trialDays?: number; via?: ModuleId; since?: string; trialsUsed?: number }
export type CoreEdition = 'ASC' | 'SURGERY' | 'MEDICAL';
export interface Practice {
  id: string; name: string; edition: CoreEdition;
  /** Code path the shell runs. Frozen full-bundle ASC runs the ASC.Vityls app; every other practice runs the modular office shell. */
  runtime: 'ASC' | 'SURGERY' | 'MEDICAL' | 'ASC2'; namespace: string; brand: string;
  locked: 'teaser' | 'hidden';          // locked modules: calm “Try free” teaser in nav, or only on Modules & plan
  expired: 'read-only' | 'hidden';      // after a trial ends
  frozen?: boolean; note?: string;
  /** v10.1 (Core on for ASC): plan, status and onboarding, shown in the CEO console. No PHI. */
  plan?: 'starter' | 'clinical' | 'full' | 'custom'; status?: 'sandbox' | 'live' | 'suspended'; onboarded?: boolean; demo?: boolean; createdAt?: string;
  modules: Record<string, Entitlement>;
}
export interface CoreAudit { at: string; practiceId: string; by: string; action: string; module?: ModuleId; detail: string }

const read = <T,>(k: string, f: T): T => { try { const v = raw.getItem(K + k); return v ? JSON.parse(v) : f; } catch { return f; } };
const write = (k: string, v: unknown) => { try { raw.setItem(K + k, JSON.stringify(v)); } catch { /* full */ } try { window.dispatchEvent(new Event('vityls-core-updated')); } catch { /* */ } };

/* ---------- simulated clock (admin console “+7 days”) ---------- */
export const clockOffsetDays = () => read<number>('clock-offset-days', 0);
export const now = () => new Date(Date.now() + clockOffsetDays() * DAY);
export function advanceClock(days: number, by = 'Vityls admin') { write('clock-offset-days', clockOffsetDays() + days); audit({ practiceId: '*', by, action: 'clock.advance', detail: `Simulated clock moved ${days > 0 ? '+' : ''}${days} days (now ${now().toDateString()})` }); sweepExpiry(); }
export function resetClock(by = 'Vityls admin') { write('clock-offset-days', 0); audit({ practiceId: '*', by, action: 'clock.reset', detail: 'Simulated clock reset to today' }); }

/* ---------- audit ---------- */
export const coreAudit = (practiceId?: string): CoreAudit[] => read<CoreAudit[]>('audit', []).filter(a => !practiceId || a.practiceId === practiceId || a.practiceId === '*');
export function audit(a: Omit<CoreAudit, 'at'>) { write('audit', [...read<CoreAudit[]>('audit', []), { ...a, at: now().toISOString() }].slice(-800)); }

/* ---------- practices ---------- */
const bundle = (ed: CoreEdition): Record<string, Entitlement> => Object.fromEntries(ALL_MODULE_IDS.map(m => [m, { state: EDITION_BUNDLES[ed].includes(m) ? 'active' : 'off' } as Entitlement]));
/* ---------- v10.1: ASC.Vityls on Vityls Core ---------- */
const envC = ((import.meta as any).env || {}) as Record<string, string | undefined>;
export const CORE_ASC = String(envC.VITE_CORE_ASC || '') === '1' && String(envC.VITE_EDITION || '').toUpperCase() === 'ASC2';
export const CENTER_ID = 'this-center';
/** The full ASC bundle (behaves like v9.1); Email intake is an add-on. */
export const ascBundle = (): Record<string, Entitlement> => Object.fromEntries(ALL_MODULE_IDS.map(m => [m, { state: EDITION_BUNDLES.ASC.includes(m) ? 'active' : 'off', since: new Date().toISOString() } as Entitlement]));
export const thisCenter = (): Practice => ({ id: CENTER_ID, name: 'This surgery center', edition: 'ASC', runtime: 'ASC2', namespace: '', brand: 'ASC', locked: 'teaser', expired: 'read-only', modules: ascBundle(), plan: 'full', status: 'sandbox', onboarded: false, createdAt: new Date().toISOString(), note: 'Your center (fill in Practice profile or the onboarding wizard)' });
const demoOn = () => { try { const q = new URLSearchParams(location.search); if (q.has('demo')) return q.get('demo') !== '0'; return raw.getItem('vityls:asc10:demo') === '1'; } catch { return false; } };
function defaults(): Practice[] {
  if (CORE_ASC) return [thisCenter(), ...(demoOn() ? legacyDefaults().map(p => ({ ...p, demo: true, status: 'live' as const, onboarded: true, plan: p.id === 'sierra' ? 'starter' as const : 'full' as const })) : [])];
  return legacyDefaults();
}
function legacyDefaults(): Practice[] {
  const sierra = Object.fromEntries(ALL_MODULE_IDS.map(m => [m, { state: m === 'email-intake' ? 'active' : 'off' } as Entitlement]));
  return [
    { id: 'coastline', name: 'Coastline Plastic Surgery', edition: 'SURGERY', runtime: 'SURGERY', namespace: 'vityls-surgery~', brand: 'Surgery', locked: 'hidden', expired: 'read-only', modules: bundle('SURGERY'), note: 'Surgery.Vityls v0.13 default bundle' },
    { id: 'bayview', name: 'Bayview Family Medicine', edition: 'MEDICAL', runtime: 'MEDICAL', namespace: 'vityls-medical~', brand: 'Medical', locked: 'hidden', expired: 'read-only', modules: bundle('MEDICAL'), note: 'Medical.Vityls v1.0 default bundle' },
    { id: 'harbor-asc', name: 'Harbor Surgery Center', edition: 'ASC', runtime: 'ASC', namespace: '', brand: 'ASC', locked: 'hidden', expired: 'read-only', frozen: true, modules: bundle('ASC'), note: 'ASC.Vityls (frozen) full bundle' },
    { id: 'sierra', name: 'Sierra Vista Surgery Center', edition: 'ASC', runtime: 'SURGERY', namespace: 'vityls-p-sierra~', brand: 'ASC', locked: 'teaser', expired: 'read-only', modules: sierra, note: 'New ASC customer: starts with AI Email Intake only' },
  ];
}
export function practices(): Practice[] {
  const l = read<Practice[] | null>('practices', null);
  if (!l) { const d = defaults(); write('practices', d); return d; }
  if (CORE_ASC && !l.some(p => p.id === CENTER_ID)) { l.unshift(thisCenter()); write('practices', l); }
  if (CORE_ASC && !demoOn() && l.some(p => p.demo)) { const c = l.filter(p => !p.demo); write('practices', c); return c; }
  if (CORE_ASC && demoOn() && !l.some(p => p.demo)) { const c = [...l, ...defaults().filter(p => p.demo)]; write('practices', c); return c; }
  // add any module registered after the practice was saved
  l.forEach(p => ALL_MODULE_IDS.forEach(m => { if (!p.modules[m]) p.modules[m] = { state: 'off' }; }));
  return l;
}
export const practice = (id: string) => practices().find(p => p.id === id);
function save(p: Practice) { write('practices', practices().map(x => x.id === p.id ? p : x)); }
export function resetPractices(by = 'Vityls admin') { write('practices', defaults()); audit({ practiceId: '*', by, action: 'practices.reset', detail: 'Demo practices and entitlements reset' }); }

const BUILD_DEFAULT: Record<string, string> = { SURGERY: 'coastline', MEDICAL: 'bayview', ASC: 'harbor-asc', MED: 'coastline' };
export function activePracticeId(buildEdition: string): string {
  try {
    const q = new URLSearchParams(location.search);
    const pq = q.get('practice'); if (pq && practice(pq)) { raw.setItem(K + 'active', pq); return pq; }
    const e = q.get('edition'); // legacy test switch ?edition=surgery|medical|asc
    if (e) { const id = BUILD_DEFAULT[e.toUpperCase()]; if (id) { raw.setItem(K + 'active', id); return id; } }
  } catch { /* */ }
  if (CORE_ASC) return CENTER_ID;
  const a = raw.getItem(K + 'active'); if (a && practice(a)) return a;
  return BUILD_DEFAULT[buildEdition] || 'coastline';
}
export function setActivePractice(id: string, by = 'Vityls admin') { raw.setItem(K + 'active', id); audit({ practiceId: id, by, action: 'practice.open', detail: `Opened ${practice(id)?.name}` }); }

/* ---------- entitlements ---------- */
/** Resolve a trial against the simulated clock. */
export function entitlement(p: Practice, m: ModuleId): Entitlement & { daysLeft?: number } {
  const e = p.modules[m] || { state: 'off' };
  if (e.state === 'trial' && e.trialEnd) { const left = Math.ceil((new Date(e.trialEnd).getTime() - now().getTime()) / DAY); if (left <= 0) return { ...e, state: 'expired', daysLeft: 0 }; return { ...e, daysLeft: left }; }
  return e;
}
/** Persist expiries the clock has passed (audited once). */
export function sweepExpiry() {
  practices().forEach(p => { let ch = false; ALL_MODULE_IDS.forEach(m => { const e = p.modules[m]; if (e?.state === 'trial' && entitlement(p, m).state === 'expired') { p.modules[m] = { ...e, state: 'expired' }; ch = true; audit({ practiceId: p.id, by: 'Vityls Core', action: 'trial.expire', module: m, detail: `${MOD[m].name} trial ended. Data kept; module is ${p.expired === 'read-only' ? 'read-only' : 'hidden'} until upgraded.` }); } }); if (ch) save(p); });
}
export const usable = (s: ModState) => s === 'active' || s === 'trial';
export function missingDeps(p: Practice, m: ModuleId): ModuleId[] { return requiresDeep(m).filter(d => !usable(entitlement(p, d).state)); }
export function blockingDependents(p: Practice, m: ModuleId): ModuleId[] { return dependents(m).filter(d => usable(entitlement(p, d).state)); }

function setState(pid: string, m: ModuleId, e: Entitlement, by: string, action: string, detail: string) {
  const p = practice(pid); if (!p) throw new Error('Unknown practice'); p.modules[m] = e; save(p); audit({ practiceId: pid, by, action, module: m, detail });
}
/** Start a free trial. Hard dependencies that are not on are started with it (documented choice: “bring along”, shown before confirming). */
export function startTrial(pid: string, m: ModuleId, by: string, days = MOD[m].trialDays) {
  const p = practice(pid)!; const deps = missingDeps(p, m); const start = now(); const end = new Date(start.getTime() + days * DAY);
  const prev = p.modules[m]; const used = (prev?.trialsUsed || 0) + 1;
  setState(pid, m, { state: 'trial', trialStart: start.toISOString(), trialEnd: end.toISOString(), trialDays: days, trialsUsed: used }, by, 'trial.start', `${MOD[m].name}: ${days}-day free trial started (ends ${end.toDateString()})${deps.length ? `; also started: ${deps.map(d => MOD[d].name).join(', ')} (required)` : ''}`);
  deps.forEach(d => { const q = practice(pid)!; q.modules[d] = { state: 'trial', trialStart: start.toISOString(), trialEnd: end.toISOString(), trialDays: days, via: m, trialsUsed: (q.modules[d]?.trialsUsed || 0) + 1 }; save(q); audit({ practiceId: pid, by, action: 'trial.start', module: d, detail: `${MOD[d].name}: trial started with ${MOD[m].name} (required by it)` }); });
}
export function extendTrial(pid: string, m: ModuleId, days: number, by: string) {
  const p = practice(pid)!; const e = p.modules[m]; const base = e.state === 'trial' && e.trialEnd && new Date(e.trialEnd) > now() ? new Date(e.trialEnd) : now();
  const end = new Date(base.getTime() + days * DAY);
  setState(pid, m, { ...e, state: 'trial', trialStart: e.trialStart || now().toISOString(), trialEnd: end.toISOString(), trialDays: (e.trialDays || 0) + days }, by, 'trial.extend', `${MOD[m].name}: trial extended ${days} days (ends ${end.toDateString()})`);
}
export function activate(pid: string, m: ModuleId, by: string) {
  const p = practice(pid)!; const deps = missingDeps(p, m);
  setState(pid, m, { state: 'active', since: now().toISOString(), trialsUsed: p.modules[m]?.trialsUsed }, by, 'module.activate', `${MOD[m].name} switched on (paid plan)${deps.length ? `; also switched on: ${deps.map(d => MOD[d].name).join(', ')} (required)` : ''}`);
  deps.forEach(d => setState(pid, d, { state: 'active', since: now().toISOString(), via: m }, by, 'module.activate', `${MOD[d].name} switched on (required by ${MOD[m].name})`));
}
export function deactivate(pid: string, m: ModuleId, by: string) {
  const p = practice(pid)!; const blk = blockingDependents(p, m);
  if (blk.length) throw new Error(`${MOD[m].name} is needed by ${blk.map(d => MOD[d].name).join(', ')}. Switch those off first.`);
  setState(pid, m, { state: 'off', trialsUsed: p.modules[m]?.trialsUsed }, by, 'module.off', `${MOD[m].name} switched off. Its data is kept.`);
}
export function expireNow(pid: string, m: ModuleId, by: string) { const p = practice(pid)!; setState(pid, m, { ...p.modules[m], state: 'expired', trialEnd: now().toISOString() }, by, 'trial.expire', `${MOD[m].name}: trial ended by admin. Data kept.`); }
export function setEdition(pid: string, ed: CoreEdition, by: string) {
  const p = practice(pid)!; if (p.frozen) throw new Error('ASC.Vityls (Harbor) is frozen and always runs its full bundle.');
  p.edition = ed; p.brand = ed === 'ASC' ? 'ASC' : ed === 'MEDICAL' ? 'Medical' : 'Surgery'; if (!p.namespace.startsWith('vityls-p-')) { /* keep data namespace */ }
  p.runtime = ed === 'MEDICAL' ? 'MEDICAL' : 'SURGERY';
  ALL_MODULE_IDS.forEach(m => { p.modules[m] = { state: EDITION_BUNDLES[ed].includes(m) && !(ed === 'ASC' && m === 'asc-perioperative') ? 'active' : p.modules[m]?.state === 'trial' ? p.modules[m].state : 'off' }; });
  if (ed === 'ASC') p.modules['email-intake'] = { state: 'active' };
  save(p); audit({ practiceId: pid, by, action: 'edition.set', detail: `Edition bundle set to ${ed}: ${EDITION_BUNDLES[ed].map(m => MOD[m].short).join(', ')}` });
}
export function setPracticeOption(pid: string, k: 'locked' | 'expired', v: string, by: string) { const p = practice(pid)!; (p as any)[k] = v; save(p); audit({ practiceId: pid, by, action: 'practice.option', detail: `${k === 'locked' ? 'Locked modules' : 'Expired trials'}: ${v}` }); }

/** v10.1: create/replace a practice record (CEO console, onboarding). */
export function upsertPractice(p: Practice, by: string, detail: string) { const l = practices(); write('practices', l.some(x => x.id === p.id) ? l.map(x => x.id === p.id ? p : x) : [...l, p]); audit({ practiceId: p.id, by, action: 'practice.update', detail }); }
export function setModules(pid: string, mods: Record<string, Entitlement>, by: string, detail: string) { const p = practice(pid); if (!p) return; upsertPractice({ ...p, modules: { ...p.modules, ...mods } }, by, detail); }
export const coreRead = read; export const coreWrite = write;
