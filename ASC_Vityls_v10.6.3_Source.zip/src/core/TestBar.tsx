/* Combined Core test build only: a small practice switcher + link to the Vityls admin console (bottom-left).
 * Hidden with ?bare=1 (screenshots of the untouched editions). */
import React from 'react';
import { practices, setActivePractice } from './practices';
import { ACTIVE_PRACTICE } from '../edition';
import './core.css';
export const CoreTestBar: React.FC = () => {
  if (/[?&]bare=1/.test(location.search) || sessionStorage.getItem('vityls-bare') === '1') { try { sessionStorage.setItem('vityls-bare', '1'); } catch { /* */ } return null; }
  return <div className="core-testbar" data-testid="core-testbar"><span>Test practice</span>
    <select value={ACTIVE_PRACTICE?.id} onChange={e => { setActivePractice(e.target.value, 'Tester (switcher)'); location.href = location.pathname; }} aria-label="Test practice" data-testid="core-practice-switch">{practices().map(p => <option key={p.id} value={p.id}>{p.name} · {p.edition}</option>)}</select>
    <a href="#vityls-admin" data-testid="core-admin-link">Vityls admin</a></div>;
};
