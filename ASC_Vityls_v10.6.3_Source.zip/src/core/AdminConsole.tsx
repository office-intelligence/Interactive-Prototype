/* Vityls admin console (internal, simulated). Opened with #vityls-admin. Pick a practice, set its edition bundle,
 * toggle modules, start/extend trials and move the simulated clock to show expiry. Everything is audited. */
import React, { useState } from 'react';
import { MODULES, ModuleId, MOD, EDITION_BUNDLES } from './modules';
import { activate, advanceClock, coreAudit, deactivate, entitlement, expireNow, extendTrial, now, practices, resetClock, resetPractices, setActivePractice, setEdition, setPracticeOption, startTrial, clockOffsetDays, CoreEdition } from './practices';
import { useCoreTick } from './useCore';
import { dataMap } from './store';
import { ACTIVE_PRACTICE } from '../edition';
import '../surgery/surgery.css';
import '../surgery/v07/v7.css';
import './core.css';

const BY = 'Vityls admin (Kevin)';
export const AdminConsole: React.FC = () => {
  useCoreTick(); const list = practices(); const [pid, setPid] = useState(ACTIVE_PRACTICE?.id || list[0].id); const [msg, setMsg] = useState(''); const p = list.find(x => x.id === pid)!;
  const run = (f: () => void, ok: string) => { try { f(); setMsg(ok); } catch (e) { setMsg((e as Error).message); } };
  const open = (id: string) => { setActivePractice(id, BY); location.href = location.pathname; };
  const map = ACTIVE_PRACTICE?.id === pid ? dataMap() : [];
  const byMod = map.reduce<Record<string, { n: number; b: number }>>((a, r) => { a[r.module] = { n: (a[r.module]?.n || 0) + 1, b: (a[r.module]?.b || 0) + r.bytes }; return a; }, {});
  return <div className="sv sv7-on" data-testid="vityls-admin"><main className="sv-main"><div className="v7-page">
    <div className="ei-head" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', flexWrap: 'wrap', gap: 12 }}><div><div className="core-kicker">Vityls · internal · simulated</div><h1 className="v7-h1">Vityls admin console</h1><div className="v7-meta">Practices, edition bundles, modules and trials in Vityls Core. Simulated date: <b data-testid="admin-clock">{now().toDateString()}</b>{clockOffsetDays() ? ` (+${clockOffsetDays()} days)` : ''}</div></div>
      <div className="flex gap-2 flex-wrap"><button type="button" className="v7-btn" onClick={() => run(() => advanceClock(7, BY), 'Clock moved +7 days. Trials past their end date have expired.')} data-testid="admin-plus7">+7 days</button><button type="button" className="v7-btn sm" onClick={() => run(() => resetClock(BY), 'Clock reset.')} data-testid="admin-clock-reset">Reset clock</button><button type="button" className="v7-btn sm" onClick={() => run(() => resetPractices(BY), 'Demo practices reset.')} data-testid="admin-reset">Reset demo practices</button></div></div>
    {msg && <div className="core-banner" role="status" data-testid="admin-msg">{msg}</div>}
    <section className="v7-card core-plan-sec"><h2 className="v7-h3">Practices</h2><div className="core-plan-grid">{list.map(x => <div key={x.id} className={`core-mod ${x.id === pid ? 'trial' : ''}`} style={x.id === pid ? { borderColor: 'var(--v7-acc)' } : undefined} data-testid={`admin-practice-${x.id}`}>
      <div className="flex justify-between gap-2"><button type="button" className="v7-quiet" style={{ fontSize: 14 }} onClick={() => setPid(x.id)} data-testid={`admin-pick-${x.id}`}>{x.name}</button>{ACTIVE_PRACTICE?.id === x.id && <span className="v7-pill green">open</span>}</div>
      <p>{x.edition} edition · {MODULES.filter(m => m.audience !== 'patient' && ['active', 'trial'].includes(entitlement(x, m.id).state)).length} modules on{x.frozen ? ' · frozen' : ''}</p><p className="v7-meta">{x.note}</p>
      <button type="button" className="v7-btn sm mt-2" onClick={() => open(x.id)} data-testid={`admin-open-${x.id}`}>Open practice</button></div>)}</div></section>
    <section className="v7-card core-plan-sec" data-testid="admin-detail"><div className="flex justify-between flex-wrap gap-3 items-end"><h2 className="v7-h3" style={{ margin: 0 }}>{p.name}</h2>
      <div className="flex gap-3 flex-wrap items-center text-[13px]">
        <label>Edition bundle <select className="v7-input" value={p.edition} disabled={p.frozen} onChange={e => run(() => setEdition(p.id, e.target.value as CoreEdition, BY), `Edition bundle set to ${e.target.value}.`)} data-testid="admin-edition">{(['ASC', 'SURGERY', 'MEDICAL'] as CoreEdition[]).map(ed => <option key={ed} value={ed}>{ed} · {EDITION_BUNDLES[ed].length} modules</option>)}</select></label>
        <label>Locked modules <select className="v7-input" value={p.locked} onChange={e => run(() => setPracticeOption(p.id, 'locked', e.target.value, BY), 'Saved.')} data-testid="admin-locked"><option value="teaser">Teaser in navigation</option><option value="hidden">Only on Modules &amp; plan</option></select></label>
        <label>Expired trials <select className="v7-input" value={p.expired} onChange={e => run(() => setPracticeOption(p.id, 'expired', e.target.value, BY), 'Saved.')} data-testid="admin-expired"><option value="read-only">Read-only + upgrade prompt</option><option value="hidden">Hidden + upgrade teaser</option></select></label></div></div>
      {p.frozen && <p className="core-note">ASC.Vityls is frozen: Harbor always runs the full ASC bundle in the original ASC app. The modular ASC path is shown with Sierra Vista.</p>}
      <table className="core-table" data-testid="admin-modules"><thead><tr><th>Module</th><th>Needs</th><th>State</th><th>Trial</th><th /></tr></thead><tbody>{MODULES.filter(m => m.audience !== 'patient').map(m => { const e = entitlement(p, m.id); return <tr key={m.id} data-testid={`admin-mod-${m.id}`}>
        <td><b>{m.name}</b><div className="v7-meta">{m.id}</div></td><td className="v7-meta">{m.requires.map(r => MOD[r].short).join(', ') || '—'}</td>
        <td><span className={`v7-pill ${e.state === 'active' ? 'green' : e.state === 'trial' ? 'blue' : e.state === 'expired' ? 'amber' : ''}`} data-testid="admin-state">{e.state}</span>{e.via && <div className="v7-meta">with {MOD[e.via].short}</div>}</td>
        <td className="v7-meta">{e.state === 'trial' ? `${e.daysLeft} days left · ends ${new Date(e.trialEnd!).toLocaleDateString()}` : e.trialEnd ? `ended ${new Date(e.trialEnd).toLocaleDateString()}` : ''}</td>
        <td><div className="flex gap-1 flex-wrap justify-end">{!p.frozen && <>
          {(e.state === 'off' || e.state === 'expired') && <button type="button" className="v7-btn sm" onClick={() => run(() => startTrial(p.id, m.id, BY), `${m.name}: trial started.`)} data-testid={`admin-trial-${m.id}`}>Start trial</button>}
          {e.state === 'trial' && <button type="button" className="v7-btn sm" onClick={() => run(() => extendTrial(p.id, m.id, 7, BY), `${m.name}: +7 trial days.`)} data-testid={`admin-extend-${m.id}`}>Extend +7</button>}
          {e.state === 'trial' && <button type="button" className="v7-btn sm" onClick={() => run(() => expireNow(p.id, m.id, BY), `${m.name}: trial ended.`)} data-testid={`admin-expire-${m.id}`}>End trial</button>}
          {e.state !== 'active' && <button type="button" className="v7-btn sm" onClick={() => run(() => activate(p.id, m.id, BY), `${m.name}: on.`)} data-testid={`admin-on-${m.id}`}>Turn on</button>}
          {e.state !== 'off' && <button type="button" className="v7-btn sm" onClick={() => run(() => deactivate(p.id, m.id, BY), `${m.name}: off.`)} data-testid={`admin-off-${m.id}`}>Off</button>}</>}</div></td></tr>; })}</tbody></table>
    </section>
    {map.length > 0 && <section className="v7-card core-plan-sec" data-testid="admin-datamap"><h2 className="v7-h3">Data map · {p.name} <span className="v7-h3-sub">· browser storage keys by owner (Core or module), for the database tables</span></h2><table className="core-table"><tbody>{Object.entries(byMod).map(([k, v]) => <tr key={k}><td><b>{k}</b></td><td className="v7-meta">{v.n} keys · {(v.b / 1024).toFixed(1)} KB</td><td className="v7-meta">{map.filter(r => r.module === k).slice(0, 6).map(r => r.key).join(', ')}{v.n > 6 ? ' …' : ''}</td></tr>)}</tbody></table></section>}
    <section className="v7-card core-plan-sec" data-testid="admin-audit"><h2 className="v7-h3">Audit · entitlements</h2><ul className="core-log">{coreAudit().slice(-14).reverse().map((a, i) => <li key={i}><span className="mono">{new Date(a.at).toLocaleString()}</span> · <b>{a.practiceId === '*' ? 'all' : list.find(x => x.id === a.practiceId)?.name}</b> · {a.action} · {a.detail} <span className="v7-muted">· {a.by}</span></li>)}</ul></section>
    <p className="v7-meta">Back to the app: <a href={location.pathname} className="v7-quiet">open {list.find(x => x.id === ACTIVE_PRACTICE?.id)?.name || 'practice'}</a></p>
  </div></main></div>;
};
