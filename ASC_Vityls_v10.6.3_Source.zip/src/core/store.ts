/* Vityls Core · data layer for modules. Every module keeps its data under `vityls:mod:<module-id>:<key>` inside the
 * active practice's namespace, so Henry can map Core tables plus one table set per module. Existing (pre-module)
 * keys are mapped to modules by prefix in modules.ts (moduleOfKey) and listed in the admin console › Data map. */
import type { ModuleId } from './modules';
import { moduleOfKey } from './modules';
export const modKey = (m: ModuleId | 'core', k: string) => `vityls:mod:${m}:${k}`;
export function moduleStore(m: ModuleId | 'core') {
  return {
    read<T>(k: string, f: T): T { try { const v = localStorage.getItem(modKey(m, k)); return v ? JSON.parse(v) : f; } catch { return f; } },
    write(k: string, v: unknown) { try { localStorage.setItem(modKey(m, k), JSON.stringify(v)); } catch { throw new Error('Browser storage is full (test build).'); } try { window.dispatchEvent(new Event('vityls-med-updated')); } catch { /* */ } },
  };
}
/** Data map of the active practice: every key, its owner module and size. */
export function dataMap(): { key: string; module: string; bytes: number }[] {
  const out: { key: string; module: string; bytes: number }[] = [];
  try { for (let i = 0; i < localStorage.length; i++) { const k = localStorage.key(i); if (!k) continue; const v = localStorage.getItem(k) || ''; const m = k.startsWith('vityls:mod:') ? k.split(':')[2] : moduleOfKey(k); out.push({ key: k, module: m, bytes: v.length }); } } catch { /* */ }
  return out.sort((a, b) => a.module.localeCompare(b.module) || a.key.localeCompare(b.key));
}
/** Core outbox (simulated): nothing leaves the browser. */
export interface OutboxItem { id: string; at: string; module: ModuleId | 'core'; to: string; subject: string; body: string; by: string; attachments?: string[] }
const core = moduleStore('core');
export const outbox = () => core.read<OutboxItem[]>('outbox', []);
export function queueOutbox(o: Omit<OutboxItem, 'id' | 'at'>, at: string) { const it = { ...o, id: `out-${Date.now().toString(36)}`, at }; core.write('outbox', [...outbox(), it]); return it; }
