/*
 * MED.Vityls v0.1 app shell. Used only when the practice edition is MED (src/edition.ts); ASC keeps App.tsx unchanged.
 * Same bottom navigation as ASC (Dashboard · Schedule · Patients · Messages · Practice) with MED screens.
 */
import React, { useEffect, useState } from 'react';
import { Home, Calendar, FileText, MessageSquare, Building2, Sparkles, UserRound } from 'lucide-react';
import { PracticeWorkspace, PracticeSubModule } from '../components/PracticeWorkspace';
import { AdminActiveSection } from '../components/AdministrationPage';
import { FormsWorkspacePage } from '../components/FormsWorkspacePage';
import { PracticeConfig } from '../types';
import { MED_ROOMS } from './seed';
import { getSettings } from './settings';
import { medRepo } from './record';
import { ActingAs, useMedTick } from './ui';
import { MedDashboard } from './MedDashboard';
import { MedSchedule } from './MedSchedule';
import { MedChart } from './MedChart';
import { MedVisitWorkspace } from './MedVisit';
import { MedMessages } from './MedMessages';
import { MedPortal } from './MedPortal';
import { MedPracticeSettings } from './MedPracticeSettings';
import { NightingaleMedDrawer } from './NightingaleMed';

export type MedTab = 'home' | 'schedule' | 'patients' | 'messages' | 'practice' | 'forms' | 'med-settings';
const practice = (): PracticeConfig => ({
  id: 'default-practice', practiceName: getSettings().practiceName, locationName: 'Main office', isPrimary: true, isSatellite: false, practiceType: 'General Medical/Surgical', specialty: 'Plastic Surgery',
  streetAddress: '', city: '', state: 'CA', zipCode: '', country: 'United States', telephone: '', email: '', website: '',
  primaryProvider: { firstName: 'Sam', lastName: 'Patel', degree: 'MD', cellPhone: '', email: '', npi: '' },
  calendarSettings: { startTime: '07:00 AM', endTime: '05:00 PM', visitTypes: [], rooms: MED_ROOMS.map((n, i) => ({ id: `room-exam-${i + 1}`, name: n, color: '#64748b', type: n.startsWith('Procedure') ? 'Procedure' : 'Exam', active: true, sortOrder: i + 1 })) },
} as PracticeConfig);

export const MedApp: React.FC = () => {
  useMedTick();
  const [tab, setTab] = useState<MedTab>('home');
  const [patientId, setPatientId] = useState<string>('');
  const [chartSection, setChartSection] = useState<string>('overview');
  const [visitId, setVisitId] = useState<string>('');
  const [portal, setPortal] = useState(false);
  const [aiOpen, setAiOpen] = useState(false);
  const [toast, setToast] = useState('');
  const [practiceConfig, setPracticeConfig] = useState<PracticeConfig>(practice);
  const [adminSection, setAdminSection] = useState<AdminActiveSection>('home');
  const [practiceSub, setPracticeSub] = useState<PracticeSubModule>('admin');
  const [practiceNavKey, setPracticeNavKey] = useState(0);
  useEffect(() => { if (!toast) return; const t = setTimeout(() => setToast(''), 3500); return () => clearTimeout(t); }, [toast]);
  useEffect(() => { document.title = 'MED.Vityls v0.1 (test build)'; }, []);
  const openChart = (pid: string, section = 'overview') => { setPatientId(pid); setChartSection(section); setVisitId(''); setTab('patients'); };
  const openVisit = (vid: string) => { const v = medRepo.visit(vid); if (v) { setPatientId(v.patientId); setVisitId(vid); setTab('patients'); } };
  const nav = (t: MedTab) => { setTab(t); if (t === 'patients') setVisitId(''); if (t === 'practice') { setAdminSection('home'); setPracticeSub('admin'); setPracticeNavKey(k => k + 1); } };
  if (portal) return <MedPortal onExit={() => setPortal(false)} />;
  const NavBtn: React.FC<{ id: MedTab; label: string; icon: React.ReactNode; active?: boolean }> = ({ id, label, icon, active }) =>
    <button type="button" onClick={() => nav(id)} data-testid={`med-nav-${id}`} className={`flex flex-col sm:flex-row items-center gap-1 sm:gap-2 px-3 sm:px-4 py-2 rounded-xl text-[13px] sm:text-[15px] font-semibold ${active ? 'bg-[#E7F1EC] text-[#1F6E52]' : 'text-[#39443E] hover:bg-[#f2f5f3]'}`}>{icon}<span>{label}</span></button>;
  return <div className="min-h-screen bg-[#F6F7F4] text-[#1f2b25] flex flex-col" data-edition="MED">
    <header className="sticky top-0 z-30 bg-white/95 backdrop-blur border-b border-[#E1E4DC] px-3 sm:px-6 py-2 flex items-center gap-3 flex-wrap">
      <button type="button" onClick={() => nav('home')} className="flex items-baseline gap-2" data-testid="med-logo"><span className="font-display text-[26px] leading-none text-[#14432E]">MED.Vityls</span><span className="text-[12.5px] font-semibold text-[#5f6862]">v0.1 test build · fictional data</span></button>
      <span className="hidden md:inline text-[14px] text-[#39443E] truncate">{getSettings().practiceName}</span>
      <div className="ml-auto flex items-center gap-2 flex-wrap">
        <ActingAs compact />
        <button type="button" onClick={() => setPortal(true)} className="vy-btn vy-btn-secondary !min-h-[38px]" data-testid="open-portal"><UserRound size={16} />Patient portal</button>
        <button type="button" onClick={() => setAiOpen(true)} className="vy-btn !min-h-[38px] !bg-[#0f766e] !text-white" data-testid="open-nightingale"><Sparkles size={16} />Nightingale</button>
      </div>
    </header>
    <main className={`flex-1 w-full mx-auto pb-28 ${tab === 'schedule' ? 'px-2 py-3 max-w-[99vw]' : 'px-3 sm:px-6 py-4 max-w-[1500px]'}`}>
      {tab === 'home' && <MedDashboard onOpenChart={openChart} onOpenVisit={openVisit} onNavigate={nav} />}
      {tab === 'schedule' && <MedSchedule onOpenChart={openChart} onOpenVisit={openVisit} onToast={setToast} />}
      {tab === 'patients' && (visitId ? <MedVisitWorkspace visitId={visitId} onBack={() => setVisitId('')} onOpenChart={openChart} onToast={setToast} />
        : <MedChart patientId={patientId} section={chartSection} onSelectPatient={pid => openChart(pid)} onSection={setChartSection} onOpenVisit={openVisit} onToast={setToast} />)}
      {tab === 'messages' && <MedMessages onOpenChart={openChart} />}
      {tab === 'forms' && <FormsWorkspacePage activePracticeId="default-practice" onShowToast={setToast} onBack={() => nav('practice')} />}
      {tab === 'med-settings' && <MedPracticeSettings onBack={() => nav('practice')} onToast={setToast} />}
      {tab === 'practice' && <div className="space-y-4">
        {adminSection === 'home' && practiceSub === 'admin' && <div className="max-w-5xl mx-auto pt-4 flex flex-wrap gap-2 items-center" data-testid="med-practice-links"><span className="vy-kicker mr-2">MED.Vityls</span><button type="button" className="vy-btn vy-btn-primary" onClick={() => setTab('med-settings')} data-testid="open-med-settings">MED settings: fee schedule, risk triggers, results, portal</button><button type="button" className="vy-btn vy-btn-secondary" onClick={() => setTab('forms')}>Forms & Workflow</button></div>}
        <PracticeWorkspace navKey={practiceNavKey} initialSubModule={practiceSub} cases={[]} onShowToast={setToast} onOpenPatientChartById={pid => openChart(pid)} onOpenPatientChart={c => openChart(c.patientId)}
          onTriggerEKGFastTrack={() => {}} onUpdateStage={() => {}} practiceConfig={practiceConfig} practicesList={[practiceConfig]} activePracticeId="default-practice" onSelectPractice={() => {}} onAddPractice={() => setToast('Additional locations are not part of the MED v0.1 test build.')}
          onDeletePractice={() => {}} onUpdatePracticeConfig={setPracticeConfig} adminActiveSection={adminSection} onAdminSectionChange={setAdminSection}
          onNavigateTab={t => { if (t === 'form-studio') setTab('forms'); else if (t === 'messages') setTab('messages'); else if (t === 'billing') { setPracticeSub('billing'); setPracticeNavKey(k => k + 1); } else if (t === 'workflows' || t === 'ai-home') { setPracticeSub('workflows'); setPracticeNavKey(k => k + 1); } else setTab('practice'); }} />
      </div>}
    </main>
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur border-t border-[#E1E4DC] px-2 py-2 flex items-center justify-around sm:justify-center sm:gap-3" aria-label="Primary navigation">
      <NavBtn id="home" label="Dashboard" icon={<Home size={18} />} active={tab === 'home'} />
      <NavBtn id="schedule" label="Schedule" icon={<Calendar size={18} />} active={tab === 'schedule'} />
      <NavBtn id="patients" label="Patients" icon={<FileText size={18} />} active={tab === 'patients'} />
      <NavBtn id="messages" label="Messages" icon={<MessageSquare size={18} />} active={tab === 'messages'} />
      <NavBtn id="practice" label="Practice" icon={<Building2 size={18} />} active={tab === 'practice' || tab === 'forms' || tab === 'med-settings'} />
    </nav>
    {aiOpen && <NightingaleMedDrawer patientId={tab === 'patients' ? patientId : ''} onClose={() => setAiOpen(false)} onOpenChart={openChart} onNavigate={nav} />}
    {toast && <div role="status" className="fixed bottom-24 left-1/2 -translate-x-1/2 z-50 bg-[#14432E] text-white px-4 py-2.5 rounded-lg shadow-lg text-[14.5px] max-w-[90vw]" data-testid="med-toast">{toast}</div>}
  </div>;
};
