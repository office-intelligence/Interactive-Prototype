/*
 * MED billing: a flat practice fee schedule (per visit type / service), not time-based.
 * Invoices reuse the v7 invoice store (getInvoices, recordPayment, manager override with audit).
 */
import { Invoice, saveInvoice, getInvoices } from '../v7/billing';
import { isManagerRole } from '../v7/roles';
import { repo } from '../v6/dataLayer';
import { MedVisit, medRepo, usDate } from './record';
import { FeeItem, getSettings } from './settings';

export function medInvoiceEligibility(v: MedVisit): { ok: boolean; reasons: string[] } {
  const reasons: string[] = [];
  const note = medRepo.note(v.id);
  if (!note || note.status !== 'signed') reasons.push('Visit note not signed');
  if (!repo.getStationVerification(v.id)['checkout']) reasons.push('Checkout not verified');
  return { ok: reasons.length === 0, reasons };
}
export interface FeeLine { item: FeeItem; qty: number; amount: number }
export function defaultFeeLines(v: MedVisit): FeeLine[] {
  // v1.5 #9: a video / phone consult bills its own fee by default (the appointment type), otherwise the visit type's fee
  const mode = (v as any).mode as string | undefined; const fees = getSettings().fees;
  const f = (mode === 'video' || mode === 'phone' ? fees.find(x => x.active && x.visitType === (mode === 'video' ? 'Video Consult' : 'Phone Consult')) : undefined) || fees.find(x => x.active && x.visitType === v.visitType);
  return f ? [{ item: f, qty: 1, amount: f.price }] : [];
}
export function buildMedInvoice(v: MedVisit, patientName: string, lines: FeeLine[], by: string, role: string, overrideReason?: string): Invoice {
  if (!lines.length) throw new Error('Add at least one service from the fee schedule.');
  const elig = medInvoiceEligibility(v);
  if (!elig.ok) {
    if (!isManagerRole(role)) throw new Error(`Not ready to invoice: ${elig.reasons.join('; ')}. A manager can issue it with an override.`);
    if (!overrideReason || overrideReason.trim().length < 4) throw new Error('A manager override needs a reason.');
  }
  const all = getInvoices(); const now = new Date().toISOString();
  const inv: Invoice = {
    id: `inv-${Date.now()}`, number: `INV-${new Date().getFullYear()}-${String(all.length + 1).padStart(4, '0')}`, caseId: v.id, patientName, patientId: v.patientId,
    dos: usDate(v.date), procedure: `${v.visitType}${v.reason ? `: ${v.reason}` : ''}`, surgeon: v.provider, paymentType: 'Self-Pay',
    scheduleId: 'med-practice-fee-schedule', scheduleName: 'Practice fee schedule (flat)', facilityMin: 0, anesthesiaMin: 0,
    lines: lines.map(l => ({ label: l.item.name + (l.item.code ? ` (${l.item.code})` : ''), detail: l.qty > 1 ? `${l.qty} × $${l.amount}` : 'Flat fee', amount: Math.round(l.amount * l.qty * 100) / 100 })),
    total: Math.round(lines.reduce((s, l) => s + l.amount * l.qty, 0) * 100) / 100, paid: 0, status: 'Draft', createdAt: now, createdBy: by,
    ...(elig.ok ? {} : { override: { by, role, reason: overrideReason!.trim(), at: now, unmet: elig.reasons } }),
  };
  saveInvoice(inv);
  if (!elig.ok) repo.audit({ caseId: v.id, user: by, role, action: 'invoice.override', detail: `Invoice ${inv.number} issued before: ${elig.reasons.join('; ')} · reason: ${overrideReason}` });
  return inv;
}
