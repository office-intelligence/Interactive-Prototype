/*
 * MED longitudinal chart (Phase 2), after the Nightingale deck: "you at a glance" left column; a medical journal
 * filterable by date, condition and entry type; a condition view tying visits, meds, labs and notes together;
 * vitals and lab trends; and a care plan that becomes the portal's Medications & Activities plan.
 */
import React, { useState } from 'react';
import { Search, Pill, FlaskConical, Stethoscope, FileText, Activity, ClipboardList, HeartPulse, Building, Users, Receipt, Sparkles, ShieldAlert, BookOpen, Watch, Printer } from 'lucide-react';
import { Btn, AllergyStatus, DialogShell } from '../v7/ui';
import { repo } from '../v6/dataLayer';
import { SimulatedRxDialog } from '../v7/SimulatedRx';
import { getProviders, displayName } from '../v7/providers';
import { medRepo, MedPatient, patientKey, ageFrom, fmtDate, fmtDateTime, usDate, vitalsText, conditionLabel, uid, CarePlan, CarePlanItem, Medication, isoDay, addDays, PROVIDER_ROLES } from './record';
import { RiskPanel } from './RiskPanel';
import { NetworkThread } from './NetworkThread';
import { networkCasesFor, setSharingConsent } from './network';
import { recordLab, reviewLab, releaseLab, bandFor, activeCaregivers, grantCaregiver, revokeCaregiver, scopeText } from './portal';
import { getSettings } from './settings';
import { MedInvoicePanel } from './MedBilling';
import { NightingaleAsk } from './NightingaleMed';
import { ProblemQuickAdd, AllergyCard, MedRecCard, IntakeCard } from './MedVisit';
import { verifyProviderPin } from '../v7/SimulatedRx';
import { STEP_LABEL } from './MedSchedule';
import { Card, Chip, Empty, SimBadge, TrendChart, ActingAs, useActor, useMedTick, printHtml, esc } from './ui';

const SECTIONS: { id: string; label: string; icon: React.ReactNode }[] = [
  { id: 'overview', label: 'Overview', icon: <BookOpen size={16} /> }, { id: 'journal', label: 'Journal', icon: <FileText size={16} /> }, { id: 'conditions', label: 'Conditions', icon: <HeartPulse size={16} /> },
  { id: 'risk', label: 'Risk awareness', icon: <ShieldAlert size={16} /> }, { id: 'trends', label: 'Trends', icon: <Activity size={16} /> }, { id: 'meds', label: 'Medications', icon: <Pill size={16} /> },
  { id: 'labs', label: 'Labs', icon: <FlaskConical size={16} /> }, { id: 'careplan', label: 'Care plan', icon: <ClipboardList size={16} /> }, { id: 'visits', label: 'Visits & notes', icon: <Stethoscope size={16} /> },
  { id: 'network', label: 'Network ASC', icon: <Building size={16} /> }, { id: 'caregivers', label: 'Caregivers', icon: <Users size={16} /> }, { id: 'billing', label: 'Billing', icon: <Receipt size={16} /> },
  { id: 'nightingale', label: 'Ask Nightingale', icon: <Sparkles size={16} /> }, { id: 'audit', label: 'Audit', icon: <ClipboardList size={16} /> },
];
const initials = (n: string) => n.split(/\s+/).map(x => x[0]).slice(0, 2).join('').toUpperCase();

export const MedChart: React.FC<{ patientId: string; section: string; onSelectPatient: (pid: string) => void; onSection: (s: string) => void; onOpenVisit: (vid: string) => void; onToast: (m: string) => void }> = ({ patientId, section, onSelectPatient, onSection, onOpenVisit, onToast }) => {
  useMedTick(); const [q, setQ] = useState('');
  const p = patientId ? medRepo.patient(patientId) : undefined;
  if (!p) { const list = medRepo.patients().filter(x => x.name.toLowerCase().includes(q.toLowerCase()));
    return <div className="space-y-3" data-testid="med-patient-list"><div className="vy-page-header"><div><div className="vy-page-kicker">Patients</div><div className="vy-page-title">Longitudinal charts</div><div className="vy-page-sub">{medRepo.patients().length} fictional patients</div></div></div>
      <div className="relative max-w-md"><Search size={18} className="absolute left-3 top-3.5 text-[#5f6862]" /><input className="vy-input !pl-10" placeholder="Search by name" value={q} onChange={e => setQ(e.target.value)} data-testid="patient-search" /></div>
      <div className="grid sm:grid-cols-2 xl:grid-cols-3 gap-3">{list.map(x => { const next = medRepo.visits(x.id).find(v => v.date >= isoDay() && v.step !== 'complete'); return <button key={x.id} type="button" onClick={() => onSelectPatient(x.id)} className="vy-card p-4 text-left hover:border-[#7fbf98]" data-testid={`patient-${x.id}`}><div className="flex items-center gap-3"><span className="w-11 h-11 rounded-full bg-[#e1efe7] text-[#14432E] font-bold flex items-center justify-center">{initials(x.name)}</span><div><div className="font-semibold text-[16px]">{x.name}</div><div className="text-[13.5px] text-[#5f6862]">{ageFrom(x.dob)} y · DOB {x.dob} · {x.primaryProvider}</div></div></div><div className="mt-2"><AllergyStatus allergies={x.allergies} patientId={patientKey(x.id)} compact /></div>{next && <div className="text-[13.5px] mt-2">Next: {next.visitType} {usDate(next.date)} {next.time}</div>}</button>; })}</div></div>; }
  return <div className="grid lg:grid-cols-[300px_1fr] gap-4" data-testid="med-chart">
    <AtAGlance p={p} onSection={onSection} onOpenVisit={onOpenVisit} />
    <div className="min-w-0 space-y-3">
      <div className="flex items-center justify-between gap-2 flex-wrap"><div><div className="vy-kicker">Patient chart</div><h1 className="font-display text-[30px] leading-tight text-[#14432E]" data-testid="chart-name">{p.name}</h1></div><div className="flex gap-2 flex-wrap items-center"><ActingAs compact /><Btn onClick={() => onSelectPatient('')}>All patients</Btn></div></div>
      <div className="flex gap-1 overflow-x-auto bg-white border border-[#dfe5e1] rounded-xl p-1" role="tablist">{SECTIONS.map(s => <button key={s.id} type="button" role="tab" aria-selected={section === s.id} onClick={() => onSection(s.id)} data-testid={`chart-tab-${s.id}`} className={`flex-none px-3 py-2 rounded-lg text-[14.5px] font-semibold flex items-center gap-1.5 ${section === s.id ? (s.id === 'nightingale' ? 'bg-[#0f766e] text-white' : 'bg-[#1f6e52] text-white') : 'text-[#26332c] hover:bg-[#f2f5f3]'}`}>{s.icon}{s.label}</button>)}</div>
      {section === 'overview' && <div className="grid xl:grid-cols-2 gap-3"><RiskPanel patient={p} compact onOpenFull={() => onSection('risk')} /><Journal p={p} limit={8} /><TrendsMini p={p} /><Card kicker="Problems" title="Active problem list">{medRepo.problems(p.id).filter(x => x.status === 'active').map(x => <p key={x.id} className="text-[14.5px]">{x.description} <span className="text-[#5f6862] text-[13px]">· {conditionLabel(x.conditionType)}</span></p>)}</Card></div>}
      {section === 'journal' && <Journal p={p} />}
      {section === 'conditions' && <Conditions p={p} />}
      {section === 'risk' && <RiskPanel patient={p} />}
      {section === 'trends' && <Trends p={p} />}
      {section === 'meds' && <Meds p={p} onToast={onToast} />}
      {section === 'labs' && <Labs p={p} onToast={onToast} />}
      {section === 'careplan' && <CarePlanEditor p={p} onToast={onToast} />}
      {section === 'visits' && <Visits p={p} onOpenVisit={onOpenVisit} />}
      {section === 'network' && <NetworkTab p={p} />}
      {section === 'caregivers' && <Caregivers p={p} onToast={onToast} />}
      {section === 'billing' && <div className="space-y-3">{medRepo.visits(p.id).filter(v => v.step !== 'scheduled').map(v => <Card key={v.id} kicker={usDate(v.date)} title={v.visitType}><MedInvoicePanel visit={v} onToast={onToast} /></Card>)}{!medRepo.visits(p.id).some(v => v.step !== 'scheduled') && <Empty>No visits to bill yet.</Empty>}</div>}
      {section === 'nightingale' && <Card tone="nightingale" kicker="Nightingale · on-device" title="Ask about this chart"><NightingaleAsk patientId={p.id} /></Card>}
      {section === 'audit' && <AuditTab p={p} />}
    </div>
  </div>;
};

const AtAGlance: React.FC<{ p: MedPatient; onSection: (s: string) => void; onOpenVisit: (v: string) => void }> = ({ p, onSection, onOpenVisit }) => {
  const today = medRepo.visits(p.id).find(v => v.date === isoDay()); const cg = activeCaregivers(p.id); const asc = networkCasesFor(p.id).filter(c => c.date >= isoDay());
  return <aside className="space-y-3" data-testid="at-a-glance">
    <Card kicker="At a glance">
      <div className="flex items-center gap-3"><span className="w-16 h-16 rounded-full bg-[#e1efe7] text-[#14432E] text-[22px] font-bold flex items-center justify-center" aria-label="Photo placeholder">{initials(p.name)}</span><div><div className="font-semibold text-[17px]">{p.name}</div><div className="text-[14px] text-[#39443E]">{ageFrom(p.dob)} y · {p.sex} · DOB {p.dob}</div><div className="text-[13.5px] text-[#5f6862]">Language: {p.language} · {p.id}</div></div></div>
      <div className="mt-3"><AllergyStatus allergies={p.allergies} patientId={patientKey(p.id)} testId="glance-allergy" /></div>
      {today && <Btn variant="primary" className="w-full mt-3" onClick={() => onOpenVisit(today.id)} data-testid="open-today-visit">{today.step === 'scheduled' ? 'Start' : 'Continue'} today’s visit · {STEP_LABEL[today.step]}</Btn>}
    </Card>
    <Card kicker="Care team"><ul className="text-[14px] space-y-1">{p.careTeam.map(c => <li key={c.name}><b>{c.name}</b><div className="text-[13px] text-[#5f6862]">{c.role}{c.phone ? ` · ${c.phone}` : ''}</div></li>)}</ul>{p.emergencyContact && <p className="text-[13.5px] mt-2"><b>Emergency:</b> {p.emergencyContact}</p>}</Card>
    <Card kicker="Caregiver access" right={<Btn variant="ghost" onClick={() => onSection('caregivers')}>Manage</Btn>}>{cg.length ? cg.map(c => <p key={c.id} className="text-[14px]"><b>{c.name}</b> ({c.relationship})<br /><span className="text-[13px] text-[#5f6862]">{scopeText(c.scope)}</span></p>) : <Empty>No caregiver access.</Empty>}</Card>
    <Card kicker="Network ASC" right={<SimBadge text="Simulated" />}>{asc.length ? asc.map(c => <button key={c.id} type="button" className="block text-left text-[14px] hover:underline" onClick={() => onSection('network')}><b>{c.procedure}</b><br />{usDate(c.date)} {c.time} · {c.surgeon}</button>) : <Empty>No upcoming ASC case.</Empty>}</Card>
    <RiskPanel patient={p} compact onOpenFull={() => onSection('risk')} />
    <div className="vy-card p-4 opacity-70" aria-disabled="true" data-testid="rpm-coming-later"><div className="flex items-center gap-2 font-semibold text-[15px]"><Watch size={17} />Remote monitoring (wearables)</div><p className="text-[13.5px] text-[#5f6862] mt-1">Coming later. Data model hooks only in v0.1; nothing connects.</p></div>
  </aside>;
};

type Entry = { at: string; type: string; title: string; detail?: string; problemIds: string[] };
const ENTRY_TYPES = ['Visit', 'Note', 'Vitals', 'Lab', 'Medication', 'Problem', 'Care plan', 'Message', 'ASC case', 'Risk review'];
function journalEntries(p: MedPatient): Entry[] {
  const out: Entry[] = [];
  medRepo.visits(p.id).forEach(v => { out.push({ at: `${v.date}T${String(Math.floor(+toMinStr(v.time) / 60)).padStart(2, '0')}:00:00`, type: 'Visit', title: `${v.visitType} with ${v.provider}`, detail: `${v.reason} · ${STEP_LABEL[v.step]}`, problemIds: v.problemIds }); const n = medRepo.note(v.id); if (n?.status === 'signed') out.push({ at: n.signedAt!, type: 'Note', title: `Visit note signed by ${n.signedBy}`, detail: n.assessment.slice(0, 140), problemIds: v.problemIds }); });
  medRepo.vitals(p.id).forEach(v => out.push({ at: v.at, type: 'Vitals', title: 'Vitals recorded', detail: vitalsText(v), problemIds: [] }));
  medRepo.labs(p.id).forEach(l => out.push({ at: `${l.collectedAt}T08:00:00`, type: 'Lab', title: `${l.test} ${l.value}${l.unit ? ' ' + l.unit : ''}`, detail: l.status === 'awaiting-review' ? 'Awaiting clinician review' : l.status === 'released' ? `Released to portal${l.reviewedBy ? ` · reviewed by ${l.reviewedBy}` : ''}` : `Reviewed by ${l.reviewedBy}`, problemIds: l.problemIds }));
  medRepo.meds(p.id).forEach(m => { out.push({ at: m.recordedAt, type: 'Medication', title: `${m.name} ${m.dose} ${m.frequency}`, detail: `${m.status === 'stopped' ? 'Stopped' : 'On list'} · ${m.source}`, problemIds: m.problemIds }); });
  medRepo.problems(p.id).forEach(x => out.push({ at: x.recordedAt, type: 'Problem', title: x.description, detail: `${conditionLabel(x.conditionType)} · ${x.status}`, problemIds: [x.id] }));
  const cp = medRepo.carePlan(p.id); if (cp?.published) out.push({ at: cp.published.signedAt, type: 'Care plan', title: `Care plan v${cp.published.version} signed by ${cp.published.signedBy}`, detail: `${cp.published.items.length} items`, problemIds: Array.from(new Set(cp.published.items.map(i => i.problemId).filter(Boolean) as string[])) });
  medRepo.messages(p.id).forEach(m => out.push({ at: m.at, type: 'Message', title: `Portal message from ${m.author}`, detail: m.text.slice(0, 140), problemIds: [] }));
  networkCasesFor(p.id).forEach(c => out.push({ at: `${c.date}T07:00:00`, type: 'ASC case', title: `${c.procedure} at ${c.ascName}`, detail: `${c.status} · ${c.surgeon}`, problemIds: [] }));
  medRepo.riskReviews(p.id).forEach(r => out.push({ at: r.at, type: 'Risk review', title: `Risk factor marked ${r.status === 'reviewed' ? 'reviewed' : 'not relevant'} by ${r.by}`, detail: r.note, problemIds: [] }));
  return out.sort((a, b) => b.at.localeCompare(a.at));
}
const toMinStr = (t: string) => { const m = String(t).match(/(\d{1,2}):(\d{2})\s*(AM|PM)?/i); if (!m) return '540'; let h = +m[1]; if (m[3] && /pm/i.test(m[3]) && h < 12) h += 12; if (m[3] && /am/i.test(m[3]) && h === 12) h = 0; return String(h * 60 + +m[2]); };

const Journal: React.FC<{ p: MedPatient; limit?: number }> = ({ p, limit }) => {
  const [range, setRange] = useState('all'); const [cond, setCond] = useState(''); const [type, setType] = useState('');
  const since = range === 'all' ? '' : addDays(isoDay(), -({ '30': 30, '90': 90, '365': 365 } as any)[range]);
  const problems = medRepo.problems(p.id);
  const list = journalEntries(p).filter(e => (!since || e.at.slice(0, 10) >= since) && (!cond || e.problemIds.includes(cond)) && (!type || e.type === type));
  return <Card kicker="Medical journal" title={limit ? 'Recent entries' : `${list.length} entries`} testId="journal">
    {!limit && <div className="flex flex-wrap gap-2 mb-3">
      <select className="vy-input !w-auto" value={range} onChange={e => setRange(e.target.value)} data-testid="journal-range"><option value="all">All dates</option><option value="30">Last 30 days</option><option value="90">Last 90 days</option><option value="365">Last 12 months</option></select>
      <select className="vy-input !w-auto" value={cond} onChange={e => setCond(e.target.value)} data-testid="journal-condition"><option value="">All conditions</option>{problems.map(x => <option key={x.id} value={x.id}>{x.description}</option>)}</select>
      <select className="vy-input !w-auto" value={type} onChange={e => setType(e.target.value)} data-testid="journal-type"><option value="">All entry types</option>{ENTRY_TYPES.map(t => <option key={t}>{t}</option>)}</select></div>}
    {list.length === 0 ? <Empty>No entries match.</Empty> : <ol className="relative border-l-2 border-[#d6e3dc] ml-2 space-y-3">{list.slice(0, limit || 400).map((e, i) => <li key={i} className="pl-4 relative" data-testid="journal-entry"><span className="absolute -left-[7px] top-1.5 w-3 h-3 rounded-full bg-[#1f6e52]" /><div className="text-[12.5px] text-[#5f6862]">{fmtDate(e.at)} · <b className="text-[#1d5f47]">{e.type}</b></div><div className="text-[15px] font-semibold">{e.title}</div>{e.detail && <div className="text-[14px] text-[#39443E]">{e.detail}</div>}</li>)}</ol>}
  </Card>;
};

const Conditions: React.FC<{ p: MedPatient }> = ({ p }) => {
  useMedTick(); const [actor] = useActor(); const problems = medRepo.problems(p.id); const [sel, setSel] = useState(problems.find(x => x.status === 'active')?.id || '');
  const pr = problems.find(x => x.id === sel);
  const visits = medRepo.visits(p.id).filter(v => v.problemIds.includes(sel)); const meds = medRepo.meds(p.id).filter(m => m.problemIds.includes(sel)); const labs = medRepo.labs(p.id).filter(l => l.problemIds.includes(sel));
  const cp = medRepo.carePlan(p.id); const items = (cp?.published?.items || []).filter(i => i.problemId === sel);
  const tests = Array.from(new Set(labs.map(l => l.test)));
  return <div className="grid xl:grid-cols-[280px_1fr] gap-3" data-testid="conditions">
    <div className="space-y-3"><Card kicker="Conditions">{problems.map(x => <button key={x.id} type="button" onClick={() => setSel(x.id)} className={`block w-full text-left px-3 py-2 rounded-lg mb-1 ${sel === x.id ? 'bg-[#e3f2e9] font-semibold' : 'hover:bg-[#f2f5f3]'}`} data-testid={`condition-${x.id}`}>{x.description}<div className="text-[12.5px] text-[#5f6862] font-normal">{conditionLabel(x.conditionType)} · {x.status}</div></button>)}</Card><ProblemQuickAdd p={p} /></div>
    {pr ? <div className="space-y-3"><Card kicker={conditionLabel(pr.conditionType)} title={pr.description} right={<Btn variant="secondary" onClick={() => medRepo.saveProblem({ ...pr, status: pr.status === 'active' ? 'resolved' : 'active' }, actor.name)}>{pr.status === 'active' ? 'Mark resolved' : 'Reactivate'}</Btn>}>
      <p className="text-[14px] text-[#39443E]">Recorded {fmtDate(pr.recordedAt)} by {pr.recordedBy} · {pr.source}{pr.onset ? ` · onset ${pr.onset}` : ''}</p></Card>
      <div className="grid lg:grid-cols-2 gap-3">
        <Card kicker="Visits" title={`${visits.length}`}>{visits.length ? visits.map(v => <p key={v.id} className="text-[14.5px]">{usDate(v.date)} · {v.visitType}{medRepo.note(v.id)?.status === 'signed' ? <span className="text-[#5f6862]"> · note: {medRepo.note(v.id)!.assessment.slice(0, 80)}</span> : ''}</p>) : <Empty>No visits linked.</Empty>}</Card>
        <Card kicker="Medications" title={`${meds.length}`}>{meds.length ? meds.map(m => <p key={m.id} className="text-[14.5px]">{m.name} {m.dose} {m.frequency} <span className="text-[#5f6862]">· {m.status}</span></p>) : <Empty>No medications linked.</Empty>}</Card>
        <Card kicker="Labs" title={`${labs.length} results`} className="lg:col-span-2">{tests.length ? tests.map(t => { const pts = labs.filter(l => l.test === t && l.valueNum != null).map(l => ({ date: l.collectedAt, value: l.valueNum! })); return <div key={t} className="mb-3"><div className="font-semibold text-[15px]">{t}</div><TrendChart points={pts} unit={labs.find(l => l.test === t)?.unit} band={bandRange(t)} height={120} /></div>; }) : <Empty>No labs linked.</Empty>}</Card>
        <Card kicker="Care plan items" title={`${items.length}`} className="lg:col-span-2">{items.length ? items.map(i => <p key={i.id} className="text-[14.5px]"><b>{i.title}</b> · {i.instructions}</p>) : <Empty>No signed care plan items for this condition.</Empty>}</Card>
      </div></div> : <Empty>Add or choose a condition.</Empty>}
  </div>;
};
const bandRange = (test: string) => { const b = getSettings().bands.find(x => x.test === test && x.approvedBy.trim()); return b ? { low: b.low, high: b.high } : null; };

const TrendsMini: React.FC<{ p: MedPatient }> = ({ p }) => { const v = medRepo.vitals(p.id); return <Card kicker="Trend" title="Blood pressure (systolic / diastolic dashed)"><TrendChart points={v.filter(x => x.bpSys).map(x => ({ date: x.at, value: x.bpSys! }))} second={v.filter(x => x.bpDia).map(x => ({ date: x.at, value: x.bpDia! }))} height={130} /><p className="text-[12.5px] text-[#5f6862]">Neutral display; no ranges are built in.</p></Card>; };
const Trends: React.FC<{ p: MedPatient }> = ({ p }) => {
  const v = medRepo.vitals(p.id); const labs = medRepo.labs(p.id); const tests = Array.from(new Set(labs.map(l => l.test)));
  const series = (k: 'bpSys' | 'weightLb' | 'bmi' | 'hr') => v.filter(x => x[k] != null).map(x => ({ date: x.at, value: x[k] as number }));
  return <div className="grid xl:grid-cols-2 gap-3" data-testid="trends">
    <Card kicker="Vitals" title="Blood pressure (mmHg)"><TrendChart points={series('bpSys')} second={v.filter(x => x.bpDia).map(x => ({ date: x.at, value: x.bpDia! }))} testId="trend-bp" /></Card>
    <Card kicker="Vitals" title="Weight (lb)"><TrendChart points={series('weightLb')} /></Card>
    <Card kicker="Vitals" title="BMI (calculated)"><TrendChart points={series('bmi')} /></Card>
    <Card kicker="Vitals" title="Pulse"><TrendChart points={series('hr')} /></Card>
    {tests.map(t => { const ls = labs.filter(l => l.test === t && l.valueNum != null); const b = bandRange(t); return <Card key={t} kicker="Lab" title={`${t}${ls[0]?.unit ? ` (${ls[0].unit})` : ''}`} right={<Chip tone={b ? 'info' : 'muted'}>{b ? 'Practice range shaded' : 'Range not configured'}</Chip>}><TrendChart points={ls.map(l => ({ date: l.collectedAt, value: l.valueNum! }))} band={b} testId={`trend-${t}`} /></Card>; })}
    <p className="text-[13px] text-[#5f6862] xl:col-span-2">Status bands appear only where your practice configured and approved a range (Practice &gt; MED settings). Nothing is judged “high” or “low” by the app.</p>
  </div>;
};

const Meds: React.FC<{ p: MedPatient; onToast: (m: string) => void }> = ({ p, onToast }) => {
  useMedTick(); const [actor] = useActor(); const [rx, setRx] = useState(false); const [edit, setEdit] = useState<Medication | null>(null);
  const meds = medRepo.meds(p.id);
  return <div className="grid xl:grid-cols-2 gap-3">
    <Card kicker="Medication list" title={`${meds.filter(m => m.status === 'active').length} active`} right={<Btn variant="add" icon={<Pill />} onClick={() => setRx(true)} data-testid="open-rx">Prescription (simulated)</Btn>} testId="med-list">
      <table className="vy-table"><thead><tr><th>Medication</th><th>Status</th><th>Source</th><th /></tr></thead><tbody>{meds.map(m => <tr key={m.id}><td><b>{m.name}</b> {m.dose}<div className="text-[13px]">{m.frequency}</div></td><td><Chip tone={m.status === 'active' ? 'ok' : 'muted'}>{m.status}</Chip>{m.simulatedRx && <div className="text-[12px] text-[#6b4708] mt-1">simulated Rx, not sent</div>}</td><td className="text-[13px]">{m.source}<div className="text-[#5f6862]">{fmtDate(m.recordedAt)} · {m.recordedBy}</div></td><td><Btn variant="ghost" onClick={() => setEdit(m)}>Edit</Btn></td></tr>)}</tbody></table>
    </Card>
    <MedRecCard p={p} />
    <AllergyCard p={p} />
    <IntakeCard p={p} />
    {rx && <SimulatedRxDialog patientName={p.name} dob={p.dob} auditKey={patientKey(p.id)} defaultPrescriber={p.primaryProvider} onClose={() => setRx(false)} onRecorded={r => { medRepo.saveMed({ id: uid('med'), patientId: p.id, name: r.medication, dose: r.dose, frequency: r.instructions, status: 'active', problemIds: [], source: `Simulated prescription by ${r.prescriber} (NOT sent)`, recordedAt: r.at, recordedBy: r.prescriber, simulatedRx: true }, r.prescriber, 'med.add'); onToast('Simulated prescription recorded. Nothing was sent.'); }} />}
    {edit && <DialogShell title={`Edit ${edit.name}`} onClose={() => setEdit(null)} size="sm" footer={<><Btn onClick={() => setEdit(null)}>Cancel</Btn><Btn variant="primary" onClick={() => { medRepo.saveMed({ ...edit, recordedAt: new Date().toISOString(), recordedBy: actor.name, source: `Edited in chart by ${actor.name}` }, actor.name); setEdit(null); }}>Save</Btn></>}>
      {(['name', 'dose', 'frequency'] as const).map(k => <label key={k} className="block mb-2"><span className="vy-label capitalize">{k}</span><input className="vy-input" value={edit[k]} onChange={e => setEdit({ ...edit, [k]: e.target.value })} /></label>)}
      <label className="block"><span className="vy-label">Status</span><select className="vy-input" value={edit.status} onChange={e => setEdit({ ...edit, status: e.target.value as any })}><option value="active">active</option><option value="stopped">stopped</option></select></label>
      <label className="block mt-2"><span className="vy-label">Linked conditions</span>{medRepo.problems(p.id).map(x => <label key={x.id} className="flex items-center gap-2 text-[14.5px]"><input type="checkbox" checked={edit.problemIds.includes(x.id)} onChange={e => setEdit({ ...edit, problemIds: e.target.checked ? [...edit.problemIds, x.id] : edit.problemIds.filter(y => y !== x.id) })} />{x.description}</label>)}</label>
    </DialogShell>}
  </div>;
};

const Labs: React.FC<{ p: MedPatient; onToast: (m: string) => void }> = ({ p, onToast }) => {
  useMedTick(); const [actor] = useActor(); const labs = [...medRepo.labs(p.id)].reverse(); const s = getSettings();
  const [f, setF] = useState({ test: '', value: '', unit: '', reportedRange: '', collectedAt: isoDay(), problemIds: [] as string[] });
  const [rev, setRev] = useState<{ id: string; note: string; patientNote: string } | null>(null);
  const canReview = PROVIDER_ROLES.includes(actor.role);
  const add = () => { if (!f.test.trim() || !f.value.trim()) { onToast('Enter the test and the value.'); return; } const n = parseFloat(f.value); recordLab({ patientId: p.id, test: f.test.trim(), value: f.value.trim(), valueNum: isNaN(n) ? undefined : n, unit: f.unit.trim(), reportedRange: f.reportedRange.trim(), collectedAt: f.collectedAt, enteredBy: actor.name, source: 'Entered by staff from a lab report', problemIds: f.problemIds }); setF({ ...f, test: '', value: '', unit: '', reportedRange: '' }); onToast(s.autoReleaseResults ? 'Result saved and released to the portal (automatic release is on).' : 'Result saved. It reaches the portal after a clinician reviews and releases it.'); };
  return <div className="space-y-3" data-testid="labs">
    <Card kicker="Results" title={`${labs.length} results`} right={<Chip tone="info">{s.autoReleaseResults ? 'Automatic release ON' : 'Release after clinician review'}</Chip>}>
      <div className="overflow-x-auto"><table className="vy-table"><thead><tr><th>Collected</th><th>Test</th><th>Value</th><th>Lab’s reported range</th><th>Practice band</th><th>Status</th><th /></tr></thead><tbody>{labs.map(l => { const b = bandFor(l); return <tr key={l.id} data-testid={`lab-${l.id}`}><td>{usDate(l.collectedAt)}</td><td>{l.test}</td><td><b>{l.value}</b> {l.unit}</td><td className="text-[13px]">{l.reportedRange || '—'}</td><td><Chip tone={b.tone === 'warn' ? 'warn' : b.tone === 'ok' ? 'ok' : 'muted'}>{b.label}</Chip></td>
        <td>{l.status === 'awaiting-review' ? <Chip tone="warn">Awaiting review</Chip> : l.status === 'reviewed' ? <Chip tone="info">Reviewed · not released</Chip> : <Chip tone="ok">Released</Chip>}<div className="text-[12px] text-[#5f6862]">{l.reviewedBy ? `${l.reviewedBy} · ${fmtDate(l.reviewedAt)}` : ''}</div></td>
        <td>{l.status === 'awaiting-review' && <Btn variant="confirm" disabled={!canReview} onClick={() => setRev({ id: l.id, note: '', patientNote: '' })} data-testid="lab-review">Review</Btn>}{l.status === 'reviewed' && <Btn disabled={!canReview} onClick={() => releaseLab(l, actor.name, actor.role)}>Release</Btn>}</td></tr>; })}</tbody></table></div>
      {!canReview && <p className="text-[13px] text-[#5f6862] mt-2">Results are reviewed by a provider (switch “Acting as”).</p>}
    </Card>
    <Card kicker="Enter a result" title="From an outside lab report">
      <div className="grid sm:grid-cols-3 lg:grid-cols-6 gap-2"><input className="vy-input" placeholder="Test" list="lab-tests" value={f.test} onChange={e => setF({ ...f, test: e.target.value })} data-testid="lab-test" /><datalist id="lab-tests">{Object.keys(s.labDescriptions).map(t => <option key={t} value={t} />)}</datalist><input className="vy-input" placeholder="Value" value={f.value} onChange={e => setF({ ...f, value: e.target.value })} data-testid="lab-value" /><input className="vy-input" placeholder="Unit" value={f.unit} onChange={e => setF({ ...f, unit: e.target.value })} /><input className="vy-input" placeholder="Lab’s reported range (as printed)" value={f.reportedRange} onChange={e => setF({ ...f, reportedRange: e.target.value })} /><input className="vy-input" type="date" value={f.collectedAt} onChange={e => setF({ ...f, collectedAt: e.target.value })} /><Btn variant="add" onClick={add} data-testid="lab-add">Save result</Btn></div>
      <div className="flex flex-wrap gap-3 mt-2 text-[14px]">{medRepo.problems(p.id).map(x => <label key={x.id} className="flex items-center gap-1.5"><input type="checkbox" checked={f.problemIds.includes(x.id)} onChange={e => setF({ ...f, problemIds: e.target.checked ? [...f.problemIds, x.id] : f.problemIds.filter(y => y !== x.id) })} />{x.description}</label>)}</div>
    </Card>
    {rev && (() => { const l = labs.find(x => x.id === rev.id)!; return <DialogShell title={`Review ${l.test} ${l.value} ${l.unit || ''}`} subtitle={`Collected ${usDate(l.collectedAt)} · ${l.source}`} onClose={() => setRev(null)} size="md" testId="lab-review-dialog" footer={<><Btn onClick={() => setRev(null)}>Cancel</Btn><Btn onClick={() => { reviewLab(l, actor.name, actor.role, rev.note, false); setRev(null); }}>Reviewed, don’t release yet</Btn><Btn variant="primary" onClick={() => { reviewLab(l, actor.name, actor.role, rev.note, true, rev.patientNote); setRev(null); onToast('Reviewed and released to the portal.'); }} data-testid="lab-release">Reviewed · release to portal</Btn></>}>
      <label className="block mb-2"><span className="vy-label">Internal review note (optional)</span><input className="vy-input" value={rev.note} onChange={e => setRev({ ...rev, note: e.target.value })} /></label>
      <label className="block"><span className="vy-label">Message to the patient with this result (optional, plain English)</span><textarea className="vy-input" value={rev.patientNote} onChange={e => setRev({ ...rev, patientNote: e.target.value })} data-testid="lab-patient-note" /></label>
      <p className="text-[13px] text-[#5f6862] mt-2">The portal shows the value, the lab’s printed range, the practice’s plain-English description of the test, and your message. It does not add its own verdict.</p>
    </DialogShell>; })()}
  </div>;
};

const TIMES: CarePlanItem['times'] = ['morning', 'midday', 'evening', 'bedtime']; const DAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
const CarePlanEditor: React.FC<{ p: MedPatient; onToast: (m: string) => void }> = ({ p, onToast }) => {
  useMedTick(); const [actor] = useActor(); const cur = medRepo.carePlan(p.id);
  const [plan, setPlan] = useState<CarePlan>(() => cur || { patientId: p.id, items: [], goals: [], status: 'draft', updatedAt: '', updatedBy: '', version: 0 });
  const [sign, setSign] = useState(false); const [who, setWho] = useState(getProviders().some(x => displayName(x) === actor.name) ? actor.name : p.primaryProvider); const [pin, setPin] = useState(''); const [err, setErr] = useState('');
  const upd = (i: number, x: Partial<CarePlanItem>) => setPlan({ ...plan, status: 'draft', items: plan.items.map((it, j) => j === i ? { ...it, ...x } : it) });
  const saveDraft = () => { const n = { ...plan, status: 'draft' as const, updatedAt: new Date().toISOString(), updatedBy: actor.name }; medRepo.saveCarePlan(n); setPlan(n); repo.audit({ caseId: patientKey(p.id), user: actor.name, role: actor.role, action: 'careplan.save', detail: `Care plan draft saved (${n.items.length} items)` }); onToast('Care plan draft saved. The portal still shows the last signed version.'); };
  const doSign = () => { const e = verifyProviderPin(who, pin); if (e) { setErr(e); setPin(''); return; } const now = new Date().toISOString(); const v = (plan.published?.version || 0) + 1; const n: CarePlan = { ...plan, status: 'signed', signedBy: who, signedAt: now, updatedAt: now, updatedBy: who, version: v, published: { items: plan.items, goals: plan.goals, signedBy: who, signedAt: now, version: v } }; medRepo.saveCarePlan(n); setPlan(n); repo.audit({ caseId: patientKey(p.id), user: who, role: 'Provider', action: 'careplan.sign', detail: `Care plan v${v} signed with PIN (${n.items.length} items) · now shown in the portal` }); setSign(false); setPin(''); setErr(''); onToast(`Care plan v${v} signed. It now shows in the portal as the Medications & Activities plan.`); };
  const meds = medRepo.meds(p.id).filter(m => m.status === 'active'); const problems = medRepo.problems(p.id);
  const print = () => { const pub = plan.published; if (!pub) return; printHtml(`Medications & Activities · ${p.name}`, `<h1>Medications &amp; Activities</h1><p>${esc(p.name)} · plan v${pub.version} signed by ${esc(pub.signedBy)} on ${fmtDate(pub.signedAt)}</p><table><tr><th>What</th><th>How</th><th>When</th><th>Days</th></tr>${pub.items.map(i => `<tr><td>${esc(i.title)}</td><td>${esc(i.instructions)}</td><td>${i.times.join(', ')}</td><td>${i.days.length === 7 ? 'Every day' : i.days.map(d => DAYS[d]).join(', ')}</td></tr>`).join('')}</table>${pub.goals.length ? `<h2>Goals</h2><ul>${pub.goals.map(g => `<li>${esc(g.text)}</li>`).join('')}</ul>` : ''}`); };
  return <div className="space-y-3" data-testid="careplan">
    <Card kicker="Care plan" title={plan.published ? `Portal shows v${plan.published.version} · signed by ${plan.published.signedBy} on ${fmtDate(plan.published.signedAt)}` : 'Not signed yet: the portal shows nothing'} right={<>{plan.published && <Btn icon={<Printer />} onClick={print}>Print (on demand)</Btn>}<Chip tone={plan.status === 'signed' ? 'ok' : 'warn'}>{plan.status === 'signed' ? 'Signed' : 'Draft changes'}</Chip></>}>
      <p className="text-[14px] text-[#39443E]">Each item becomes a line in the patient’s Medications &amp; Activities plan (by day, by week and by medication). Only a provider can sign; Nightingale never writes or signs the plan.</p></Card>
    {plan.items.map((it, i) => <div key={it.id} className="vy-card p-3 grid lg:grid-cols-[120px_1fr_1fr] gap-2 items-start" data-testid="careplan-item">
      <select className="vy-input" value={it.kind} onChange={e => upd(i, { kind: e.target.value as any })}><option value="medication">Medication</option><option value="activity">Activity</option><option value="check">Check</option></select>
      <div className="space-y-2"><input className="vy-input" value={it.title} onChange={e => upd(i, { title: e.target.value })} placeholder="Title" /><input className="vy-input" value={it.instructions} onChange={e => upd(i, { instructions: e.target.value })} placeholder="Instructions in plain English" /></div>
      <div className="space-y-2"><div className="flex flex-wrap gap-1">{TIMES.map(t => <button key={t} type="button" onClick={() => upd(i, { times: it.times.includes(t) ? it.times.filter(x => x !== t) : [...it.times, t] })} className={`px-2.5 min-h-[36px] rounded-lg border text-[13.5px] ${it.times.includes(t) ? 'bg-[#1f6e52] text-white border-[#1f6e52]' : 'bg-white border-[#b9c5be]'}`}>{t}</button>)}</div>
        <div className="flex flex-wrap gap-1">{DAYS.map((d, k) => <button key={d} type="button" onClick={() => upd(i, { days: it.days.includes(k) ? it.days.filter(x => x !== k) : [...it.days, k].sort() })} className={`w-11 min-h-[34px] rounded-md border text-[13px] ${it.days.includes(k) ? 'bg-[#e3f2e9] border-[#7fbf98] font-semibold' : 'bg-white border-[#d3d8d4]'}`}>{d}</button>)}</div>
        <div className="flex gap-2"><select className="vy-input" value={it.problemId || ''} onChange={e => upd(i, { problemId: e.target.value || undefined })}><option value="">No linked condition</option>{problems.map(x => <option key={x.id} value={x.id}>{x.description}</option>)}</select><Btn variant="danger" onClick={() => setPlan({ ...plan, status: 'draft', items: plan.items.filter((_, j) => j !== i) })}>Remove</Btn></div></div>
    </div>)}
    <div className="flex flex-wrap gap-2"><select className="vy-input !w-auto" value="" onChange={e => { const m = meds.find(x => x.id === e.target.value); if (m) setPlan({ ...plan, status: 'draft', items: [...plan.items, { id: uid('ci'), kind: 'medication', title: `${m.name} ${m.dose}`, instructions: m.frequency, times: ['morning'], days: [0, 1, 2, 3, 4, 5, 6], medId: m.id, problemId: m.problemIds[0] }] }); }} data-testid="careplan-add-med"><option value="">Add from medication list…</option>{meds.map(m => <option key={m.id} value={m.id}>{m.name} {m.dose}</option>)}</select>
      <Btn variant="add" onClick={() => setPlan({ ...plan, status: 'draft', items: [...plan.items, { id: uid('ci'), kind: 'activity', title: '', instructions: '', times: ['morning'], days: [0, 1, 2, 3, 4, 5, 6] }] })}>Add activity</Btn>
      <Btn onClick={() => setPlan({ ...plan, status: 'draft', goals: [...plan.goals, { id: uid('g'), text: '' }] })}>Add goal</Btn></div>
    {plan.goals.length > 0 && <Card kicker="Goals">{plan.goals.map((g, i) => <div key={g.id} className="flex gap-2 mb-2"><input className="vy-input" value={g.text} onChange={e => setPlan({ ...plan, status: 'draft', goals: plan.goals.map((x, j) => j === i ? { ...x, text: e.target.value } : x) })} /><Btn variant="danger" onClick={() => setPlan({ ...plan, status: 'draft', goals: plan.goals.filter((_, j) => j !== i) })}>Remove</Btn></div>)}</Card>}
    <div className="flex gap-2 flex-wrap"><Btn onClick={saveDraft} data-testid="careplan-save">Save draft</Btn><Btn variant="primary" onClick={() => setSign(true)} data-testid="careplan-sign">Sign with PIN and publish to portal</Btn></div>
    {sign && <DialogShell title="Sign the care plan" onClose={() => setSign(false)} size="sm" footer={<><Btn onClick={() => setSign(false)}>Cancel</Btn><Btn variant="primary" onClick={doSign} data-testid="careplan-sign-confirm">Sign</Btn></>}>
      <label className="block mb-2"><span className="vy-label">Signing provider</span><select className="vy-input" value={who} onChange={e => setWho(e.target.value)}>{getProviders().filter(x => x.active).map(x => <option key={x.id} value={displayName(x)}>{displayName(x)}</option>)}</select></label>
      <label className="block"><span className="vy-label">Signature PIN</span><input className="vy-input" type="password" inputMode="numeric" value={pin} onChange={e => setPin(e.target.value)} data-testid="careplan-pin" /></label>{err && <p className="vy-field-error mt-2">{err}</p>}</DialogShell>}
  </div>;
};

const Visits: React.FC<{ p: MedPatient; onOpenVisit: (v: string) => void }> = ({ p, onOpenVisit }) => {
  const vs = [...medRepo.visits(p.id)].reverse();
  return <Card kicker="Visits & notes" title={`${vs.length} visits`}><div className="overflow-x-auto"><table className="vy-table"><thead><tr><th>Date</th><th>Visit</th><th>Provider</th><th>Step</th><th>Note</th><th /></tr></thead><tbody>{vs.map(v => { const n = medRepo.note(v.id); return <tr key={v.id}><td>{usDate(v.date)} {v.time}</td><td>{v.visitType}<div className="text-[13px] text-[#5f6862]">{v.reason}</div></td><td>{v.provider}</td><td>{STEP_LABEL[v.step]}</td><td>{n?.status === 'signed' ? <span><Chip tone="ok">Signed</Chip><div className="text-[12.5px]">{n.signedBy}</div></span> : n ? <Chip tone="warn">Draft</Chip> : '—'}</td><td><Btn onClick={() => onOpenVisit(v.id)}>Open</Btn></td></tr>; })}</tbody></table></div></Card>;
};

const NetworkTab: React.FC<{ p: MedPatient }> = ({ p }) => {
  useMedTick(); const [actor] = useActor(); const cases = networkCasesFor(p.id); const c = p.recordSharingConsent;
  return <div className="space-y-3" data-testid="network-tab">
    <Card kicker="Network ASC" title="Record-sharing consent" right={<SimBadge />}>
      <p className="text-[14.5px]">{c?.granted ? <>Consent on file: <b>{c.scope}</b> · recorded by {c.by} on {fmtDate(c.at)}</> : 'No consent to share records with the network ASC is recorded.'}</p>
      <div className="flex gap-2 mt-2"><Btn variant="confirm" onClick={() => setSharingConsent(p, true, actor.name, actor.role, 'Surgical records for the booked procedure')} data-testid="consent-record">Record consent</Btn>{c?.granted && <Btn variant="danger" onClick={() => setSharingConsent(p, false, actor.name, actor.role, c.scope)}>Withdraw</Btn>}</div>
      <p className="text-[12.5px] text-[#5f6862] mt-2">Simulated. The real rules for sharing between practices need legal review; see the backend contract in the report.</p></Card>
    {cases.length === 0 ? <Empty>No ASC cases are linked to this chart (simulated match on name + date of birth).</Empty> : cases.map(x => <Card key={x.id} kicker={`${x.ascName} · ${x.source === 'asc-store' ? 'from ASC data in this browser' : 'fictional seed'}`} title={`${x.procedure} · ${usDate(x.date)} ${x.time}`} right={<Chip>{x.status}</Chip>}><NetworkThread c={x} /></Card>)}
  </div>;
};

const Caregivers: React.FC<{ p: MedPatient; onToast: (m: string) => void }> = ({ p, onToast }) => {
  useMedTick(); const [actor] = useActor(); const all = medRepo.caregivers(p.id);
  const [f, setF] = useState({ name: '', relationship: '', email: '', authorization: '', expiresOn: '', scope: { results: true, plan: true, appointments: true, messages: false } }); const [err, setErr] = useState('');
  const grant = () => { try { grantCaregiver({ patientId: p.id, name: f.name, relationship: f.relationship, email: f.email, scope: f.scope, grantedBy: actor.name, grantedVia: 'staff', authorization: f.authorization, expiresOn: f.expiresOn || undefined }); setF({ ...f, name: '', relationship: '', email: '', authorization: '', expiresOn: '' }); setErr(''); onToast('Caregiver access granted (audited).'); } catch (e: any) { setErr(e.message); } };
  const audit = repo.getAudit(patientKey(p.id)).filter(a => a.action.startsWith('proxy.')).reverse();
  return <div className="grid xl:grid-cols-2 gap-3" data-testid="caregivers">
    <Card kicker="Caregiver / proxy access" title={`${activeCaregivers(p.id).length} active`}>{all.length === 0 ? <Empty>None.</Empty> : all.map(c => <div key={c.id} className="border border-[#e7ece9] rounded-lg p-3 mb-2"><div className="flex justify-between gap-2 flex-wrap"><b>{c.name} ({c.relationship})</b>{c.revokedAt ? <Chip tone="muted">Revoked {fmtDate(c.revokedAt)}</Chip> : c.expiresOn && c.expiresOn < isoDay() ? <Chip tone="muted">Expired</Chip> : <Chip tone="ok">Active</Chip>}</div><div className="text-[14px]">Can see: {scopeText(c.scope)}</div><div className="text-[13px] text-[#5f6862]">Granted by {c.grantedBy} ({c.grantedVia}) on {fmtDate(c.grantedAt)} · {c.authorization}{c.expiresOn ? ` · until ${usDate(c.expiresOn)}` : ''}</div>{!c.revokedAt && <Btn variant="danger" className="mt-2" onClick={() => revokeCaregiver(c, actor.name, actor.role)}>Revoke</Btn>}</div>)}</Card>
    <Card kicker="Grant access" title="Patient-authorized caregiver">
      <div className="grid grid-cols-2 gap-2"><input className="vy-input" placeholder="Name" value={f.name} onChange={e => setF({ ...f, name: e.target.value })} data-testid="cg-name" /><input className="vy-input" placeholder="Relationship" value={f.relationship} onChange={e => setF({ ...f, relationship: e.target.value })} data-testid="cg-rel" /><input className="vy-input" placeholder="Email (invitation is simulated)" value={f.email} onChange={e => setF({ ...f, email: e.target.value })} /><input className="vy-input" type="date" value={f.expiresOn} onChange={e => setF({ ...f, expiresOn: e.target.value })} title="Expires on (optional)" /></div>
      <input className="vy-input mt-2" placeholder="How did the patient authorize this? (e.g., signed form on file)" value={f.authorization} onChange={e => setF({ ...f, authorization: e.target.value })} data-testid="cg-auth" />
      <div className="flex flex-wrap gap-3 mt-2 text-[14.5px]">{(Object.keys(f.scope) as (keyof typeof f.scope)[]).map(k => <label key={k} className="flex items-center gap-1.5"><input type="checkbox" className="w-5 h-5" checked={f.scope[k]} onChange={e => setF({ ...f, scope: { ...f.scope, [k]: e.target.checked } })} />{({ results: 'Lab results', plan: 'Medications & Activities plan', appointments: 'Appointments', messages: 'Messages' } as any)[k]}</label>)}</div>
      <Btn variant="primary" className="mt-3" onClick={grant} data-testid="cg-grant">Grant access</Btn>{err && <p className="vy-field-error mt-2">{err}</p>}</Card>
    <Card kicker="Audit" title="Caregiver access history" className="xl:col-span-2">{audit.length ? <ul className="text-[14px] space-y-1">{audit.map(a => <li key={a.id}>{fmtDateTime(a.at)} · {a.user} · {a.action} · {a.detail}</li>)}</ul> : <Empty>No entries.</Empty>}</Card>
  </div>;
};

const AuditTab: React.FC<{ p: MedPatient }> = ({ p }) => {
  const rows = [...repo.getAudit(patientKey(p.id)), ...medRepo.visits(p.id).flatMap(v => repo.getAudit(v.id))].sort((a, b) => b.at.localeCompare(a.at));
  return <Card kicker="Audit trail" title={`${rows.length} entries (patient + visits)`}><div className="overflow-x-auto"><table className="vy-table" data-testid="chart-audit"><thead><tr><th>When</th><th>Who</th><th>Action</th><th>Detail</th></tr></thead><tbody>{rows.map(a => <tr key={a.id}><td className="whitespace-nowrap">{fmtDateTime(a.at)}</td><td>{a.user}<div className="text-[12.5px] text-[#5f6862]">{a.role}</div></td><td>{a.action}</td><td>{a.detail}</td></tr>)}</tbody></table></div></Card>;
};

/* Surgery.Vityls reuses these sections as right-panel pulls. */
export { Journal, Trends, Meds, Labs, CarePlanEditor, Visits, NetworkTab, Caregivers, AuditTab, Conditions };
