/*
 * Lab results release + caregiver (proxy) access for the MED portal.
 * Default: a result reaches the portal only after a clinician reviews and releases it. Practice setting
 * `autoReleaseResults` releases on entry instead. Caregiver access is granted by the patient or staff, scoped
 * (results / plan / appointments / messages), can expire, can be revoked, and every grant, revoke and caregiver
 * portal view is audited. Status bands stay neutral ("not configured") unless the practice set an approved range.
 */
import { repo } from '../v6/dataLayer';
import { Caregiver, LabResult, medRepo, patientKey, uid, isHuman } from './record';
import { getSettings } from './settings';

export function recordLab(l: Omit<LabResult, 'id' | 'status' | 'enteredAt'>): LabResult {
  const auto = getSettings().autoReleaseResults; const now = new Date().toISOString();
  const lab: LabResult = { ...l, id: uid('lab'), enteredAt: now, status: auto ? 'released' : 'awaiting-review', ...(auto ? { releasedAt: now, releasedBy: 'Automatic release (practice setting)' } : {}) };
  medRepo.saveLab(lab);
  repo.audit({ caseId: patientKey(l.patientId), user: l.enteredBy, role: 'Staff', action: 'lab.record', detail: `${l.test} ${l.value}${l.unit ? ' ' + l.unit : ''} (collected ${l.collectedAt})${auto ? ' · auto-released to portal (practice setting)' : ' · awaiting clinician review'}` });
  return lab;
}
export function reviewLab(l: LabResult, by: string, role: string, note: string, release: boolean, patientNote = '') {
  if (!isHuman(by)) throw new Error('Results are reviewed by a named clinician, not Nightingale.');
  const now = new Date().toISOString();
  const next: LabResult = { ...l, status: release ? 'released' : 'reviewed', reviewedBy: by, reviewedAt: now, reviewNote: note, patientNote: patientNote || l.patientNote, ...(release ? { releasedAt: now, releasedBy: by } : {}) };
  medRepo.saveLab(next);
  repo.audit({ caseId: patientKey(l.patientId), user: by, role, action: 'lab.review', detail: `${l.test} ${l.value} reviewed${note ? ` · ${note}` : ''}` });
  if (release) repo.audit({ caseId: patientKey(l.patientId), user: by, role, action: 'lab.release', detail: `${l.test} released to portal` });
}
export function releaseLab(l: LabResult, by: string, role: string) {
  medRepo.saveLab({ ...l, status: 'released', releasedAt: new Date().toISOString(), releasedBy: by });
  repo.audit({ caseId: patientKey(l.patientId), user: by, role, action: 'lab.release', detail: `${l.test} released to portal` });
}
/** Neutral unless the practice configured an approved range for this test. Never a verdict beyond the practice's own range. */
export function bandFor(l: LabResult): { label: string; tone: 'muted' | 'ok' | 'warn' } {
  const b = getSettings().bands.find(x => x.test === l.test && x.approvedBy.trim() && (x.low != null || x.high != null));
  if (!b || l.valueNum == null) return { label: 'Range not configured by your practice', tone: 'muted' };
  const inside = (b.low == null || l.valueNum >= b.low) && (b.high == null || l.valueNum <= b.high);
  return inside ? { label: 'Within your practice’s range', tone: 'ok' } : { label: 'Outside your practice’s range — talk with your care team', tone: 'warn' };
}

export const activeCaregivers = (pid: string) => medRepo.caregivers(pid).filter(c => !c.revokedAt && (!c.expiresOn || c.expiresOn >= new Date().toISOString().slice(0, 10)));
export function grantCaregiver(c: Omit<Caregiver, 'id' | 'grantedAt'>): Caregiver {
  if (!c.name.trim() || !c.relationship.trim()) throw new Error('Enter the caregiver’s name and relationship.');
  if (!c.authorization.trim()) throw new Error('Record how the patient authorized this access.');
  if (!Object.values(c.scope).some(Boolean)) throw new Error('Choose at least one thing the caregiver can see.');
  const g: Caregiver = { ...c, id: uid('cg'), grantedAt: new Date().toISOString() };
  medRepo.saveCaregiver(g);
  repo.audit({ caseId: patientKey(c.patientId), user: c.grantedBy, role: c.grantedVia === 'patient' ? 'Patient' : 'Staff', action: 'proxy.grant', detail: `${c.name} (${c.relationship}) · scope: ${scopeText(c.scope)}${c.expiresOn ? ` · until ${c.expiresOn}` : ''} · authorization: ${c.authorization}` });
  return g;
}
export function revokeCaregiver(c: Caregiver, by: string, role: string) {
  medRepo.saveCaregiver({ ...c, revokedAt: new Date().toISOString(), revokedBy: by });
  repo.audit({ caseId: patientKey(c.patientId), user: by, role, action: 'proxy.revoke', detail: `${c.name} (${c.relationship}) access revoked` });
}
export const scopeText = (s: Caregiver['scope']) => Object.entries(s).filter(([, v]) => v).map(([k]) => ({ results: 'lab results', plan: 'medications & activities plan', appointments: 'appointments', messages: 'messages' } as any)[k]).join(', ');
