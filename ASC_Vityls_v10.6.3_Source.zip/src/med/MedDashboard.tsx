/* MED dashboard: today's visit flow, network ASC cases, and what needs attention. All counts come from recorded data. */
import React, { useState } from 'react';
import { Sparkles, Building, FlaskConical, MessageSquare, ShieldAlert, FileSignature } from 'lucide-react';
import { medRepo, isoDay, addDays, usDate, VisitStep } from './record';
import { networkRepo, matchPatient, NetworkCase } from './network';
import { riskFlags, reviewState } from './risk';
import { Card, Chip, Empty, SimBadge, useMedTick } from './ui';
import { STEP_LABEL, NetworkCaseDialog } from './MedSchedule';
import type { MedTab } from './MedApp';

const COLS: VisitStep[] = ['scheduled', 'check-in', 'rooming', 'provider', 'checkout', 'complete'];
export const MedDashboard: React.FC<{ onOpenChart: (pid: string, section?: string) => void; onOpenVisit: (vid: string) => void; onNavigate: (t: MedTab) => void }> = ({ onOpenChart, onOpenVisit, onNavigate }) => {
  useMedTick(); const T = isoDay(); const [sel, setSel] = useState<NetworkCase | null>(null);
  const today = medRepo.visits().filter(v => v.date === T);
  const net = networkRepo.cases().filter(c => c.date >= T && c.date <= addDays(T, 30)).sort((a, b) => a.date.localeCompare(b.date));
  const toReview = medRepo.labs().filter(l => l.status === 'awaiting-review');
  const msgs = medRepo.patients().map(p => ({ p, last: medRepo.messages(p.id).slice(-1)[0] })).filter(x => x.last && x.last.from !== 'office');
  const unsigned = today.filter(v => v.step !== 'scheduled' && medRepo.note(v.id)?.status !== 'signed');
  const riskOpen = net.map(c => matchPatient(c)).filter((p, i, a) => p && a.findIndex(x => x?.id === p.id) === i).map(p => ({ p: p!, n: riskFlags(p!).filter(f => { const r = reviewState(f, medRepo.riskReviews(p!.id)); return !r.review || r.changedSinceReview; }).length })).filter(x => x.n > 0);
  const name = (pid: string) => medRepo.patient(pid)?.name || pid;
  return <div className="space-y-4" data-testid="med-dashboard">
    <div className="vy-page-header"><div><div className="vy-page-kicker">Office dashboard</div><div className="vy-page-title">{new Date().toLocaleDateString([], { weekday: 'long', month: 'long', day: 'numeric' })}</div><div className="vy-page-sub">{today.length} visits today · {today.filter(v => v.step === 'complete').length} complete · {net.length} upcoming ASC case{net.length === 1 ? '' : 's'}</div></div></div>
    <Card tone="nightingale" kicker="Nightingale · from today’s recorded data" title={<span className="flex items-center gap-2"><Sparkles size={18} className="text-[#0f766e]" />Today at a glance</span>} testId="med-brief">
      <ul className="text-[14.5px] space-y-1 list-disc pl-5">
        <li>{today.length} office visits on the schedule; {today.filter(v => v.step !== 'scheduled' && v.step !== 'complete').length} in progress.</li>
        <li>{toReview.length} lab result{toReview.length === 1 ? '' : 's'} waiting for clinician review before release to the portal.</li>
        <li>{msgs.length} patient or caregiver message{msgs.length === 1 ? '' : 's'} waiting for a reply.</li>
        <li>{riskOpen.length} patient{riskOpen.length === 1 ? '' : 's'} with an upcoming ASC case {riskOpen.length === 1 ? 'has' : 'have'} risk factors not yet reviewed by the surgeon.</li>
      </ul><p className="text-[12.5px] text-[#39443E] mt-2">Counts only. Nightingale does not judge risk, sign or order.</p></Card>
    <Card kicker="Visit flow" title="Today’s office visits" testId="visit-flow">
      <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-6 gap-3">{COLS.map(col => <div key={col} className="bg-[#f6f7f4] rounded-lg p-2 min-h-[90px]"><div className="text-[13px] font-bold uppercase tracking-wide text-[#3a463f] mb-2">{STEP_LABEL[col]} ({today.filter(v => v.step === col).length})</div>
        {today.filter(v => v.step === col).map(v => <button type="button" key={v.id} onClick={() => onOpenVisit(v.id)} className="w-full text-left bg-white border border-[#dfe5e1] rounded-md p-2 mb-2 hover:border-[#7fbf98]" data-testid="flow-card"><div className="font-semibold text-[14.5px]">{name(v.patientId)}</div><div className="text-[13px] text-[#39443E]">{v.time} · {v.room}</div><div className="text-[13px] text-[#5f6862] truncate">{v.visitType} · {v.provider.replace(/,.*$/, '')}</div></button>)}</div>)}</div>
    </Card>
    <div className="grid lg:grid-cols-2 gap-4">
      <Card kicker="Network ASC" title={<span className="flex items-center gap-2"><Building size={18} />Upcoming ASC cases (30 days)</span>} right={<SimBadge text="Simulated network link" />} testId="dash-network">
        {net.length === 0 ? <Empty>No ASC cases booked for this office’s surgeons.</Empty> : <table className="vy-table"><thead><tr><th>Date</th><th>Patient</th><th>Procedure</th><th>Surgeon</th></tr></thead><tbody>{net.map(c => { const m = matchPatient(c); return <tr key={c.id} className="cursor-pointer hover:bg-[#f6f7f4]" onClick={() => setSel(c)}><td>{usDate(c.date)} {c.time}</td><td>{c.patientName}{!m && <div><Chip tone="warn">not linked</Chip></div>}</td><td>{c.procedure}<div className="text-[12.5px] text-[#5f6862]">{c.status} · {c.source === 'asc-store' ? 'from ASC data in this browser' : 'fictional seed'}</div></td><td>{c.surgeon.replace(/,.*$/, '')}</td></tr>; })}</tbody></table>}
      </Card>
      <Card kicker="Needs attention" title="Work queue" testId="dash-attention">
        <div className="space-y-3 text-[14.5px]">
          <div><div className="font-semibold flex items-center gap-2"><FlaskConical size={16} />Results to review ({toReview.length})</div>{toReview.slice(0, 5).map(l => <button key={l.id} type="button" className="block text-left underline-offset-2 hover:underline" onClick={() => onOpenChart(l.patientId, 'labs')}>{name(l.patientId)} · {l.test} {l.value} {l.unit} ({usDate(l.collectedAt)})</button>)}</div>
          <div><div className="font-semibold flex items-center gap-2"><MessageSquare size={16} />Portal messages waiting ({msgs.length})</div>{msgs.map(x => <button key={x.p.id} type="button" className="block text-left hover:underline" onClick={() => onNavigate('messages')}>{x.p.name}: “{x.last.text.slice(0, 70)}…”</button>)}</div>
          <div><div className="font-semibold flex items-center gap-2"><ShieldAlert size={16} />Risk factors to review before ASC surgery ({riskOpen.length})</div>{riskOpen.map(x => <button key={x.p.id} type="button" className="block text-left hover:underline" onClick={() => onOpenChart(x.p.id, 'risk')}>{x.p.name}: {x.n} factor{x.n === 1 ? '' : 's'} not reviewed</button>)}</div>
          <div><div className="font-semibold flex items-center gap-2"><FileSignature size={16} />Visit notes not signed today ({unsigned.length})</div>{unsigned.map(v => <button key={v.id} type="button" className="block text-left hover:underline" onClick={() => onOpenVisit(v.id)}>{name(v.patientId)} · {v.visitType}</button>)}</div>
        </div>
      </Card>
    </div>
    {sel && <NetworkCaseDialog c={sel} onClose={() => setSel(null)} onOpenChart={pid => { setSel(null); onOpenChart(pid, 'network'); }} />}
  </div>;
};
