/* Risk awareness panel (MED v0.1). Awareness only: no score, no go/no-go. The surgeon or physician decides. */
import React, { useState } from 'react';
import { ShieldAlert } from 'lucide-react';
import { Btn } from '../v7/ui';
import { MedPatient, medRepo, fmtDate, RISK_DECIDER_ROLES } from './record';
import { riskFlags, measurements, reviewState, saveReview, RiskFlag } from './risk';
import { Card, Chip, Empty, useActor, useMedTick } from './ui';

export const RiskPanel: React.FC<{ patient: MedPatient; compact?: boolean; onOpenFull?: () => void }> = ({ patient, compact, onOpenFull }) => {
  useMedTick(); const [actor] = useActor();
  const flags = riskFlags(patient); const reviews = medRepo.riskReviews(patient.id); const meas = measurements(patient);
  const open = flags.filter(f => { const r = reviewState(f, reviews); return !r.review || r.changedSinceReview; });
  const [editing, setEditing] = useState<{ f: RiskFlag; status: 'reviewed' | 'not-relevant' } | null>(null);
  const [note, setNote] = useState(''); const [err, setErr] = useState('');
  const canDecide = RISK_DECIDER_ROLES.includes(actor.role);
  const save = () => { if (!editing) return; try { saveReview(patient, editing.f, editing.status, note, actor.name, actor.role); setEditing(null); setNote(''); setErr(''); } catch (e: any) { setErr(e.message); } };
  if (compact) return <Card kicker="Surgical risk awareness" title={<span className="flex items-center gap-2"><ShieldAlert size={18} className="text-[#8a5a00]" />{flags.length} factor{flags.length === 1 ? '' : 's'}</span>} testId="risk-compact"
    right={onOpenFull && <Btn variant="ghost" onClick={onOpenFull}>Open</Btn>}>
    {flags.length === 0 ? <Empty>No risk factors found in the recorded data.</Empty> : <ul className="space-y-1.5">{flags.slice(0, 7).map(f => { const r = reviewState(f, reviews); return <li key={f.id} className="text-[14px] leading-snug flex gap-2 items-start"><span className={`mt-1.5 w-2 h-2 rounded-full flex-none ${!r.review || r.changedSinceReview ? 'bg-[#b7791f]' : 'bg-[#9aa59f]'}`} /><span>{f.label}{r.review && !r.changedSinceReview && <span className="text-[#5f6862]"> · {r.review.status === 'reviewed' ? 'reviewed' : 'not relevant'}</span>}</span></li>; })}{flags.length > 7 && <li className="text-[13.5px] text-[#5f6862]">+{flags.length - 7} more</li>}</ul>}
    <p className="text-[12.5px] text-[#5f6862] mt-2">{open.length} not yet reviewed. Awareness only, no score.</p>
  </Card>;
  return <Card kicker="Surgical risk awareness" title="Factors that may raise surgical risk" testId="risk-panel" right={<Chip tone={open.length ? 'warn' : 'ok'} testId="risk-open-count">{open.length} to review</Chip>}>
    <p className="text-[14px] text-[#39443E] mb-3">Drawn from the problem list, medications, allergies, vitals, labs and intake. <b>No score and no go/no-go:</b> the surgeon or physician decides. Mark each factor reviewed or not relevant; every decision is audited.</p>
    {!canDecide && <p className="text-[13.5px] mb-3 rounded-md bg-[#f3f4f2] border border-[#d3d8d4] px-3 py-2">You are acting as {actor.role}. Only a surgeon or physician can mark factors; switch “Acting as” to decide.</p>}
    {flags.length === 0 ? <Empty>No risk factors found in the recorded data.</Empty> :
      <ul className="divide-y divide-[#e7ece9] border border-[#e7ece9] rounded-lg">{flags.map(f => { const r = reviewState(f, reviews); return <li key={f.id} className="p-3" data-testid={`risk-flag-${f.id}`}>
        <div className="flex flex-wrap items-start gap-2 justify-between"><div className="min-w-0"><div className="font-semibold text-[15px]">{f.label}</div><div className="text-[14px] text-[#39443E]">{f.detail}</div>
          <div className="text-[13px] text-[#5f6862] mt-0.5">Source: {f.source}{f.recordedAt ? ` · recorded ${fmtDate(f.recordedAt)}` : ' · date not recorded'}</div>
          {r.review && <div className="text-[13px] mt-1"><Chip tone={r.changedSinceReview ? 'warn' : r.review.status === 'reviewed' ? 'ok' : 'muted'}>{r.changedSinceReview ? 'Changed since review' : r.review.status === 'reviewed' ? 'Reviewed' : 'Not relevant'}</Chip> <span className="text-[#39443E]">{r.review.by} · {fmtDate(r.review.at)}{r.review.note ? ` · “${r.review.note}”` : ''}</span></div>}
        </div>
          <div className="flex gap-2 flex-none"><Btn variant="confirm" className="!min-h-[38px]" disabled={!canDecide} onClick={() => { setEditing({ f, status: 'reviewed' }); setNote(''); setErr(''); }} data-testid="risk-mark-reviewed">Reviewed</Btn><Btn variant="secondary" className="!min-h-[38px]" disabled={!canDecide} onClick={() => { setEditing({ f, status: 'not-relevant' }); setNote(''); setErr(''); }}>Not relevant</Btn></div></div>
        {editing?.f.id === f.id && <div className="mt-2 flex flex-wrap gap-2 items-end bg-[#fafbfa] p-2 rounded-md"><label className="flex-1 min-w-[220px]"><span className="vy-label">{editing.status === 'reviewed' ? 'Note (optional)' : 'Why not relevant? (required)'}</span><input className="vy-input" value={note} onChange={e => setNote(e.target.value)} data-testid="risk-note" /></label><Btn variant="primary" onClick={save} data-testid="risk-save">Save as {actor.name}</Btn><Btn onClick={() => setEditing(null)}>Cancel</Btn>{err && <p className="vy-field-error w-full">{err}</p>}</div>}
      </li>; })}</ul>}
    <div className="mt-4"><div className="vy-section-title">Measurements (flag only with a practice-approved trigger)</div>
      <ul className="text-[14px] space-y-1">{meas.map(m => <li key={m.trigger.id} className="flex flex-wrap gap-x-2"><b>{m.trigger.label}:</b> {m.value != null ? `${m.value} ${m.trigger.unit}` : 'not recorded'}{m.recordedAt && <span className="text-[#5f6862]">({m.source}, {fmtDate(m.recordedAt)})</span>}<span className="text-[#5f6862]">· {m.configured ? `trigger ${m.trigger.operator} ${m.trigger.value} (approved by ${m.trigger.approvedBy})` : 'no trigger configured; the medical director must approve one in Practice > MED settings'}</span></li>)}</ul></div>
  </Card>;
};
