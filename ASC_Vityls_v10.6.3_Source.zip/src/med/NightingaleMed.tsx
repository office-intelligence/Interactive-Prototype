/*
 * Nightingale in MED v0.1: answers ONLY from what is recorded (problem list, meds, allergies, vitals, labs, risk
 * factors, care plan, caregivers, ASC cases), names the source and date, and says plainly when something is not
 * recorded. No remote AI in this build (no PHI leaves the device). Never signs, orders, clears or scores risk.
 */
import React, { useState } from 'react';
import { Sparkles, Send } from 'lucide-react';
import { repo } from '../v6/dataLayer';
import { effectiveAllergy } from '../v7/allergy';
import { medRepo, patientKey, fmtDate, usDate, vitalsText, conditionLabel } from './record';
import { riskFlags } from './risk';
import { networkCasesFor } from './network';
import { activeCaregivers, scopeText } from './portal';
import type { MedTab } from './MedApp';

export function answerFromMedChart(pid: string, question: string): string {
  const p = medRepo.patient(pid); if (!p) return 'Open a patient chart first. I answer only from a chart’s recorded data.';
  const q = question.toLowerCase();
  if (/allerg/.test(q)) { const a = effectiveAllergy(p.allergies, patientKey(p.id)); return a.state === 'not-reported' ? `Allergy status for ${p.name} is Not Reported. (Source: allergy record.)` : `Allergies: ${a.text}${a.pendingConfirm ? ` — patient-reported on ${a.sourceForm}, not yet confirmed` : p.allergiesConfirmedAt ? ` (confirmed by ${p.allergiesConfirmedBy} on ${fmtDate(p.allergiesConfirmedAt)})` : ''}.`; }
  if (/risk|surg(ical|ery)? risk|safe|concern/.test(q)) { const f = riskFlags(p); return f.length ? `Recorded risk factors (awareness only, no score, the surgeon decides): ${f.map(x => `${x.label} [${x.source}${x.recordedAt ? `, ${fmtDate(x.recordedAt)}` : ''}]`).join('; ')}.` : 'No risk factors are found in the recorded data. That is not a clearance.'; }
  if (/med|drug|rx|prescri|blood thinner|anticoag/.test(q)) { const m = medRepo.meds(p.id).filter(x => x.status === 'active'); return m.length ? `Active medications on the list: ${m.map(x => `${x.name} ${x.dose} ${x.frequency} (${x.source}, ${fmtDate(x.recordedAt)})`).join('; ')}.` : 'No active medications are recorded.'; }
  if (/problem|condition|diagnos|history|diabet|heart|hypertens/.test(q)) { const pr = medRepo.problems(p.id).filter(x => x.status === 'active'); return pr.length ? `Active problems: ${pr.map(x => `${x.description} (${conditionLabel(x.conditionType)}, recorded ${fmtDate(x.recordedAt)})`).join('; ')}.` : 'No active problems are recorded.'; }
  if (/a1c|lab|result|creatinine|hemoglobin|ldl|inr|platelet/.test(q)) {
    const labs = medRepo.labs(p.id); if (!labs.length) return 'No lab results are recorded in this chart.';
    const byTest = new Map<string, typeof labs[number]>(); labs.forEach(l => byTest.set(l.test, l));
    const want = [...byTest.values()].filter(l => q.includes(l.test.toLowerCase().split(' ').slice(-1)[0]) || /lab|result/.test(q));
    const list = (want.length ? want : [...byTest.values()]);
    return `Latest recorded results: ${list.map(l => `${l.test} ${l.value}${l.unit ? ' ' + l.unit : ''} (collected ${usDate(l.collectedAt)}, ${l.status === 'awaiting-review' ? 'awaiting clinician review' : l.status})`).join('; ')}. I don’t interpret results; ranges are set by your practice.`;
  }
  if (/vital|bp|blood pressure|weight|bmi|pulse/.test(q)) { const v = medRepo.vitals(p.id).slice(-1)[0]; return v ? `Latest vitals (${fmtDate(v.at)}, ${v.by}): ${vitalsText(v)}.` : 'No vitals are recorded.'; }
  if (/surgery|asc|case|procedure|booked/.test(q)) { const c = networkCasesFor(p.id); return c.length ? `ASC cases (simulated network link): ${c.map(x => `${x.procedure} on ${usDate(x.date)} ${x.time} with ${x.surgeon} (${x.status})`).join('; ')}.` : 'No ASC cases are linked to this chart.'; }
  if (/care ?plan|activit|plan/.test(q)) { const cp = medRepo.carePlan(p.id); return cp?.published ? `Signed care plan v${cp.published.version} by ${cp.published.signedBy} on ${fmtDate(cp.published.signedAt)}: ${cp.published.items.map(i => i.title).join('; ')}.` : 'No signed care plan is recorded.'; }
  if (/caregiver|proxy|daughter|son|family/.test(q)) { const c = activeCaregivers(p.id); return c.length ? `Active caregiver access: ${c.map(x => `${x.name} (${x.relationship}): ${scopeText(x.scope)}`).join('; ')}.` : 'No caregiver has portal access.'; }
  return `I can only answer from what is recorded in ${p.name}'s chart, and I didn’t find that. Try allergies, medications, problems, labs, vitals, risk factors, ASC cases, care plan or caregivers.`;
}

export const NightingaleAsk: React.FC<{ patientId: string; compact?: boolean }> = ({ patientId, compact }) => {
  const [q, setQ] = useState(''); const [log, setLog] = useState<{ who: 'you' | 'n'; text: string }[]>([{ who: 'n', text: 'Ask about this chart. I answer only from recorded data and say when something isn’t recorded. I never sign, order, clear or score risk.' }]);
  const ask = (text = q) => { if (!text.trim()) return; const a = answerFromMedChart(patientId, text); setLog(l => [...l, { who: 'you', text }, { who: 'n', text: a }]); setQ(''); const act = repo.getActor(); if (patientId) repo.audit({ caseId: patientKey(patientId), user: act.name, role: act.role, action: 'nightingale.answer', detail: `Q: ${text.slice(0, 80)}` }); };
  return <div data-testid="nightingale-ask">
    <div className={`space-y-2 ${compact ? 'max-h-[260px]' : 'max-h-[420px]'} overflow-y-auto mb-2`}>{log.map((m, i) => <div key={i} className={`rounded-lg px-3 py-2 text-[14.5px] ${m.who === 'n' ? 'bg-[#f2fbfa] border border-[#99d5cf]' : 'bg-white border border-[#dfe5e1] ml-8'}`}>{m.who === 'n' && <b className="text-[#0f766e]">Nightingale: </b>}{m.text}</div>)}</div>
    <div className="flex flex-wrap gap-1.5 mb-2">{['Allergies?', 'Risk factors?', 'Blood thinners?', 'Latest A1c?', 'Upcoming surgery?'].map(s => <button key={s} type="button" className="px-3 min-h-[36px] rounded-full border border-[#99d5cf] text-[#0f5f59] text-[13.5px] font-semibold bg-white" onClick={() => ask(s)}>{s}</button>)}</div>
    <div className="flex gap-2"><input className="vy-input" placeholder="Ask about this chart" value={q} onChange={e => setQ(e.target.value)} onKeyDown={e => { if (e.key === 'Enter') ask(); }} data-testid="nightingale-input" /><button type="button" className="vy-btn !bg-[#0f766e] !text-white" onClick={() => ask()} data-testid="nightingale-send"><Send size={16} />Ask</button></div>
  </div>;
};

export const NightingaleMedDrawer: React.FC<{ patientId: string; onClose: () => void; onOpenChart: (pid: string, s?: string) => void; onNavigate: (t: MedTab) => void }> = ({ patientId, onClose, onOpenChart, onNavigate }) => {
  const [pid, setPid] = useState(patientId); const patients = medRepo.patients();
  return <div className="fixed inset-0 z-[150] bg-black/30 flex justify-end" onMouseDown={e => { if (e.target === e.currentTarget) onClose(); }}>
    <aside className="w-full max-w-[460px] h-full bg-white shadow-2xl flex flex-col" data-testid="nightingale-drawer">
      <header className="px-4 py-3 bg-[#0f766e] text-white flex items-center gap-2"><Sparkles size={18} /><span className="font-display text-[24px]">Nightingale</span><span className="text-[12.5px] ml-1 opacity-90">on-device · chart data only</span><button type="button" className="ml-auto vy-icon-btn !w-10 !h-10" onClick={onClose} aria-label="Close">✕</button></header>
      <div className="p-4 space-y-3 overflow-y-auto flex-1">
        <label className="block"><span className="vy-label">Patient</span><select className="vy-input" value={pid} onChange={e => setPid(e.target.value)}><option value="">Choose a chart…</option>{patients.map(x => <option key={x.id} value={x.id}>{x.name}</option>)}</select></label>
        {pid && <><NightingaleAsk patientId={pid} key={pid} /><button type="button" className="vy-btn vy-btn-secondary" onClick={() => { onOpenChart(pid); onClose(); }}>Open {medRepo.patient(pid)?.name}’s chart</button></>}
        <div className="flex flex-wrap gap-2 pt-2 border-t border-[#e7ece9]"><button type="button" className="vy-btn vy-btn-ghost" onClick={() => { onNavigate('schedule'); onClose(); }}>Schedule</button><button type="button" className="vy-btn vy-btn-ghost" onClick={() => { onNavigate('messages'); onClose(); }}>Messages</button><button type="button" className="vy-btn vy-btn-ghost" onClick={() => { onNavigate('med-settings'); onClose(); }}>MED settings</button></div>
        <p className="text-[12.5px] text-[#5f6862]">Remote AI is off in this build. Turning it on needs a Business Associate Agreement; until then no chart data leaves the device.</p>
      </div>
    </aside>
  </div>;
};
