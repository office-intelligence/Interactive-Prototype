/*
 * SIMULATED Network Provider link (MED v0.1). Until Henry's backend exists:
 *  - "ASC cases" = cases booked for this office's surgeons at the network ASC. Read from the ASC.Vityls case store in
 *    the SAME browser storage when present (ASC data is never modified), otherwise from fictional seed cases that are
 *    clearly labeled.
 *  - Patient identity match = exact name + date of birth (simulation only; the backend contract uses a proper
 *    shared-identity match with consent, see the report appendix).
 *  - The per-case secure thread and document share live in a shared "network" area of browser storage.
 * NetworkRepository is the swap point for the real API.
 */
import { rawStorage } from '../edition';
import { repo } from '../v6/dataLayer';
import { findProvider, getProviders } from '../v7/providers';
import { medRepo, MedPatient, patientKey, uid, isoDay } from './record';
import { getSettings } from './settings';

export interface NetworkCase { id: string; source: 'asc-store' | 'fictional-seed'; ascName: string; date: string; time: string; durationMin: number; surgeon: string; patientName: string; dob: string; procedure: string; room: string; status: string }
export interface NetworkMessage { id: string; caseId: string; at: string; fromOrg: 'office' | 'asc'; author: string; role: string; text: string; simulatedReply?: boolean }
export interface NetworkDocument { id: string; caseId: string; at: string; fromOrg: 'office' | 'asc'; sharedBy: string; title: string; fileName?: string; mime?: string; dataUrl?: string; text?: string }

export interface NetworkRepository {
  cases(): NetworkCase[]; thread(caseId: string): NetworkMessage[]; post(m: NetworkMessage): void;
  documents(caseId: string): NetworkDocument[]; share(d: NetworkDocument): void;
}
const NK = 'vityls:network';
const rread = <T,>(k: string, f: T): T => { try { const r = rawStorage.getItem(k); return r ? JSON.parse(r) : f; } catch { return f; } };
const rwrite = (k: string, v: unknown) => { try { rawStorage.setItem(k, JSON.stringify(v)); } catch { throw new Error('Browser storage is full; share a smaller file.'); } try { window.dispatchEvent(new Event('vityls-med-updated')); } catch { /* */ } };
const norm = (s: string) => String(s || '').toLowerCase().replace(/,.*$/, '').replace(/^dr\.?\s+/, '').replace(/[^a-z ]/g, '').trim();

export function officeSurgeons(): string[] {
  return getProviders().filter(p => p.active && (p.role === 'Surgeon' || p.role === 'Physician')).map(p => `${p.firstName} ${p.lastName}`);
}
function ascStoreCases(): NetworkCase[] {
  const dc = rread<Record<string, any[]>>('vityls:evaluation:date-cases', {});
  const mine = new Set(officeSurgeons().map(norm));
  const out: NetworkCase[] = [];
  Object.entries(dc).forEach(([day, list]) => (Array.isArray(list) ? list : []).forEach(c => {
    if (!c || !mine.has(norm(c.surgeon))) return;
    out.push({ id: `asc:${c.id}`, source: 'asc-store', ascName: 'Network ASC (ASC.Vityls test data in this browser)', date: /^\d{4}-\d{2}-\d{2}$/.test(day) ? day : isoDay(), time: c.scheduledTime || '', durationMin: c.estimatedDurationMins || 90, surgeon: c.surgeon, patientName: c.name, dob: c.dob || '', procedure: c.procedure || '', room: c.room || '', status: c.stage || 'Booked' });
  }));
  return out;
}
class LocalNetworkRepository implements NetworkRepository {
  cases() {
    const asc = ascStoreCases();
    if (asc.length) return asc;
    const ascName = getSettings().ascName;
    return (JSON.parse(localStorage.getItem('vityls:med:network-seed') || '[]') as NetworkCase[]).map(c => ({ ...c, ascName }));
  }
  thread(caseId: string) { return rread<NetworkMessage[]>(`${NK}:thread:${caseId}`, []); }
  post(m: NetworkMessage) { rwrite(`${NK}:thread:${m.caseId}`, [...this.thread(m.caseId), m]); }
  documents(caseId: string) { return rread<NetworkDocument[]>(`${NK}:docs:${caseId}`, []); }
  share(d: NetworkDocument) { rwrite(`${NK}:docs:${d.caseId}`, [...this.documents(d.caseId), d]); }
}
export const networkRepo: NetworkRepository = new LocalNetworkRepository();

/** Simulated identity match: exact name + DOB against office charts. */
export function matchPatient(c: NetworkCase, patients: MedPatient[] = medRepo.patients()): MedPatient | undefined {
  const n = c.patientName.toLowerCase().replace(/\s+/g, ' ').trim();
  return patients.find(p => p.name.toLowerCase().replace(/\s+/g, ' ').trim() === n && p.dob === c.dob);
}
export const networkCasesFor = (pid: string) => { const p = medRepo.patient(pid); return p ? networkRepo.cases().filter(c => matchPatient(c, [p])) : []; };
export const surgeonColor = (name: string) => findProvider(name)?.color || '#475569';

export function postNetworkMessage(c: NetworkCase, text: string, author: string, role: string, fromOrg: 'office' | 'asc' = 'office', simulatedReply = false) {
  if (!text.trim()) throw new Error('Type a message.');
  networkRepo.post({ id: uid('nm'), caseId: c.id, at: new Date().toISOString(), fromOrg, author, role, text: text.trim(), simulatedReply });
  const p = matchPatient(c); repo.audit({ caseId: p ? patientKey(p.id) : `network:${c.id}`, user: author, role, action: 'network.message', detail: `${fromOrg === 'office' ? 'Office → ASC' : 'ASC → office (simulated)'} · ${c.procedure}: ${text.trim().slice(0, 100)}` });
}
export function shareNetworkDocument(c: NetworkCase, d: Omit<NetworkDocument, 'id' | 'at' | 'caseId'>, role: string) {
  const p = matchPatient(c);
  if (!p) throw new Error('This ASC case is not linked to an office chart, so documents cannot be shared.');
  if (!p.recordSharingConsent?.granted) throw new Error('Record the patient’s consent to share records with the network ASC first (patient chart > Network ASC).');
  networkRepo.share({ ...d, id: uid('nd'), at: new Date().toISOString(), caseId: c.id });
  repo.audit({ caseId: patientKey(p.id), user: d.sharedBy, role, action: 'network.document', detail: `Shared "${d.title}" with ${c.ascName} for ${c.procedure}` });
}
export function setSharingConsent(p: MedPatient, granted: boolean, by: string, role: string, scope: string) {
  medRepo.savePatient({ ...p, recordSharingConsent: { granted, by, at: new Date().toISOString(), scope } });
  repo.audit({ caseId: patientKey(p.id), user: by, role, action: 'network.consent', detail: `${granted ? 'Recorded' : 'Withdrew'} consent to share records with the network ASC · scope: ${scope}` });
}
