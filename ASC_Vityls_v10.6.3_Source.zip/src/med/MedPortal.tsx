/*
 * MED patient portal (test build). Patients and authorized caregivers see: released lab results in plain English
 * with a trend view, the signed Medications & Activities plan, appointments and messages. Caregiver access is
 * scoped and every caregiver view is audited. Bands stay neutral unless the practice configured a range.
 * Remote monitoring (wearables) is a disabled "coming later" card.
 */
import React, { useState } from 'react';
import { ArrowLeft, FlaskConical, ClipboardList, CalendarDays, MessageSquare, Users, Watch, Printer, Home } from 'lucide-react';
import { Btn } from '../v7/ui';
import { repo } from '../v6/dataLayer';
import { medRepo, MedPatient, Caregiver, patientKey, usDate, fmtDate, fmtDateTime, isoDay, uid } from './record';
import { activeCaregivers, bandFor, grantCaregiver, revokeCaregiver, scopeText } from './portal';
import { networkCasesFor } from './network';
import { getSettings } from './settings';
import { Card, Chip, Empty, TrendChart, useMedTick, printHtml, esc } from './ui';
import { isSurgery } from '../edition';
import { PortalForms } from '../surgery/newPatient';
import { PortalConfirm } from '../surgery/reminders';
import { SurgeryPortalMessages } from '../surgery/v12/MsgAttach';

type Who = { kind: 'patient'; p: MedPatient } | { kind: 'caregiver'; p: MedPatient; c: Caregiver };
const DAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']; const TIMES = ['morning', 'midday', 'evening', 'bedtime'] as const;

export const MedPortal: React.FC<{ onExit: () => void }> = ({ onExit }) => {
  useMedTick(); const [who, setWho] = useState<Who | null>(null); const [tab, setTab] = useState('home');
  const signIn = (w: Who) => { setWho(w); setTab('home'); if (w.kind === 'patient') repo.audit({ caseId: patientKey(w.p.id), user: w.p.name, role: 'Patient', action: 'portal.view', detail: 'Signed in to the portal (test build)' }); else repo.audit({ caseId: patientKey(w.p.id), user: w.c.name, role: `Caregiver (${w.c.relationship})`, action: 'proxy.access', detail: `Signed in as caregiver · scope: ${scopeText(w.c.scope)}` }); };
  if (!who) return <div className="min-h-screen bg-[#F6F7F4] p-4 sm:p-8" data-testid="portal-signin"><div className="max-w-2xl mx-auto space-y-4">
    <div className="flex items-center justify-between"><div><div className="font-display text-[32px] text-[#14432E]">Patient portal</div><div className="text-[14px] text-[#39443E]">{getSettings().practiceName} · test build, fictional data</div></div><Btn icon={<ArrowLeft />} onClick={onExit}>Back to office app</Btn></div>
    <Card kicker="Test sign-in" title="Choose who is signing in"><p className="text-[14px] text-[#39443E] mb-3">Real sign-in (with identity checks) comes with the backend.</p>
      <div className="space-y-2">{medRepo.patients().map(p => <div key={p.id}><button type="button" className="vy-btn vy-btn-secondary w-full !justify-start" onClick={() => signIn({ kind: 'patient', p })} data-testid={`portal-as-${p.id}`}>{p.name} <span className="font-normal text-[#5f6862]">· patient</span></button>
        {activeCaregivers(p.id).map(c => <button key={c.id} type="button" className="vy-btn vy-btn-secondary w-full !justify-start mt-1 ml-6 !w-[calc(100%-1.5rem)]" onClick={() => signIn({ kind: 'caregiver', p, c })} data-testid={`portal-cg-${c.id}`}>{c.name} <span className="font-normal text-[#5f6862]">· {c.relationship.toLowerCase()} and caregiver for {p.name}</span></button>)}</div>)}</div></Card></div></div>;
  const p = medRepo.patient(who.p.id)!; const c = who.kind === 'caregiver' ? medRepo.caregivers(p.id).find(x => x.id === who.c.id)! : null;
  const stillActive = !c || activeCaregivers(p.id).some(x => x.id === c.id);
  const can = (k: keyof Caregiver['scope']) => !c || c.scope[k];
  const tabs = [{ id: 'home', label: 'Journal', icon: <Home size={16} />, ok: true }, { id: 'results', label: 'Lab results', icon: <FlaskConical size={16} />, ok: can('results') }, { id: 'plan', label: 'Medications & Activities', icon: <ClipboardList size={16} />, ok: can('plan') }, { id: 'appts', label: 'Appointments', icon: <CalendarDays size={16} />, ok: can('appointments') }, { id: 'messages', label: 'Messages', icon: <MessageSquare size={16} />, ok: can('messages') }, { id: 'access', label: 'Caregiver access', icon: <Users size={16} />, ok: !c }].filter(t => t.ok);
  const go = (t: string) => { setTab(t); if (c) repo.audit({ caseId: patientKey(p.id), user: c.name, role: `Caregiver (${c.relationship})`, action: 'proxy.access', detail: `Viewed ${tabs.find(x => x.id === t)?.label}` }); };
  return <div className="min-h-screen bg-[#F6F7F4]" data-testid="portal">
    <header className="bg-white border-b border-[#E1E4DC] px-4 py-3 flex flex-wrap items-center gap-3"><span className="font-display text-[26px] text-[#14432E]">My health</span><span className="text-[14.5px]">{c ? <>Signed in as <b>{c.name}</b>, viewing <b>{p.name}</b>’s record as {c.relationship.toLowerCase()} and caregiver</> : <>Signed in as <b>{p.name}</b></>}</span><div className="ml-auto flex gap-2"><Btn onClick={() => setWho(null)}>Switch person</Btn><Btn icon={<ArrowLeft />} onClick={onExit}>Office app</Btn></div></header>
    {!stillActive ? <div className="p-6"><Empty>This caregiver access has been revoked or has expired.</Empty></div> : <div className="max-w-5xl mx-auto p-3 sm:p-6 space-y-3">
      {c && <div className="rounded-lg border border-[#a9c8e2] bg-[#e6f0f8] px-3 py-2 text-[14px] text-[#174d77]" data-testid="caregiver-banner">Caregiver access granted by {c.grantedBy} on {fmtDate(c.grantedAt)}. You can see: {scopeText(c.scope)}. Every view is recorded.</div>}
      <div className="flex gap-1 overflow-x-auto bg-white border border-[#dfe5e1] rounded-xl p-1">{tabs.map(t => <button key={t.id} type="button" onClick={() => go(t.id)} data-testid={`portal-tab-${t.id}`} className={`flex-none px-3 py-2.5 rounded-lg text-[15px] font-semibold flex items-center gap-1.5 ${tab === t.id ? 'bg-[#1f6e52] text-white' : 'text-[#26332c] hover:bg-[#f2f5f3]'}`}>{t.icon}{t.label}</button>)}</div>
      {tab === 'home' && isSurgery && !c && <PortalForms p={p} />}
      {tab === 'home' && <PortalHome p={p} can={can} />}
      {tab === 'results' && <PortalResults p={p} />}
      {tab === 'plan' && <PortalPlan p={p} />}
      {tab === 'appts' && <PortalAppts p={p} />}
      {tab === 'messages' && isSurgery && <SurgeryPortalMessages p={p} author={c ? `${c.name} (${c.relationship.toLowerCase()})` : p.name} from={c ? 'caregiver' : 'patient'} />}
      {tab === 'messages' && !isSurgery && <PortalMessages p={p} author={c ? `${c.name} (${c.relationship.toLowerCase()})` : p.name} from={c ? 'caregiver' : 'patient'} />}
      {tab === 'access' && !c && <PortalAccess p={p} />}
      <div className="vy-card p-4 opacity-70" aria-disabled="true" data-testid="portal-rpm"><div className="flex items-center gap-2 font-semibold"><Watch size={17} />Connect a wearable or home device</div><p className="text-[14px] text-[#5f6862]">Coming later. Not available in this test build.</p></div>
    </div>}
  </div>;
};

const PortalHome: React.FC<{ p: MedPatient; can: (k: keyof Caregiver['scope']) => boolean }> = ({ p, can }) => {
  const items: { at: string; text: string }[] = [];
  if (can('results')) medRepo.labs(p.id).filter(l => l.status === 'released').forEach(l => items.push({ at: l.releasedAt || l.collectedAt, text: `New result: ${l.test} ${l.value} ${l.unit || ''}` }));
  if (can('plan')) { const pub = medRepo.carePlan(p.id)?.published; if (pub) items.push({ at: pub.signedAt, text: `Your Medications & Activities plan was updated by ${pub.signedBy}` }); }
  if (can('appointments')) medRepo.visits(p.id).forEach(v => items.push({ at: `${v.date}T09:00:00`, text: `${v.date >= isoDay() ? 'Upcoming' : 'Visit'}: ${v.visitType} with ${v.provider} on ${usDate(v.date)} ${v.time}` }));
  if (can('messages')) medRepo.messages(p.id).forEach(m => items.push({ at: m.at, text: `Message from ${m.from === 'office' ? 'the office' : m.author}` }));
  items.sort((a, b) => b.at.localeCompare(a.at));
  return <Card kicker="Your journal" title="What’s new">{items.length ? <ol className="border-l-2 border-[#d6e3dc] ml-2 space-y-2">{items.slice(0, 15).map((x, i) => <li key={i} className="pl-4 relative"><span className="absolute -left-[7px] top-1.5 w-3 h-3 rounded-full bg-[#1f6e52]" /><div className="text-[12.5px] text-[#5f6862]">{fmtDate(x.at)}</div><div className="text-[15px]">{x.text}</div></li>)}</ol> : <Empty>Nothing yet.</Empty>}</Card>;
};

const PortalResults: React.FC<{ p: MedPatient }> = ({ p }) => {
  const labs = medRepo.labs(p.id).filter(l => l.status === 'released'); const tests = Array.from(new Set(labs.map(l => l.test))); const s = getSettings();
  const pending = medRepo.labs(p.id).filter(l => l.status !== 'released').length;
  return <div className="space-y-3" data-testid="portal-results">
    {pending > 0 && <p className="text-[14px] text-[#39443E]">{pending} result{pending === 1 ? ' is' : 's are'} waiting for your care team to review. You’ll see {pending === 1 ? 'it' : 'them'} here after review.</p>}
    {tests.length === 0 ? <Empty>No results have been released yet.</Empty> : tests.map(t => { const ls = labs.filter(l => l.test === t); const last = ls[ls.length - 1]; const band = bandFor(last); return <Card key={t} kicker={`Latest ${usDate(last.collectedAt)}`} title={`${t}: ${last.value} ${last.unit || ''}`} right={<Chip tone={band.tone === 'warn' ? 'warn' : band.tone === 'ok' ? 'ok' : 'muted'} testId="portal-band">{band.label}</Chip>} testId="portal-result">
      <p className="text-[15px]"><b>What this test is:</b> {s.labDescriptions[t] || 'Your practice has not added a description for this test yet.'}</p>
      {last.reportedRange && <p className="text-[14.5px] mt-1">The lab’s report lists this reference range: {last.reportedRange}. Your care team decides what your result means for you.</p>}
      {last.patientNote && <p className="text-[14.5px] mt-1 rounded-md bg-[#f3faf6] border border-[#b5d9c2] px-3 py-2"><b>Note from {last.reviewedBy}:</b> {last.patientNote}</p>}
      <p className="text-[13px] text-[#5f6862] mt-1">Reviewed by {last.reviewedBy || 'your care team'}{last.releasedAt ? ` · released ${fmtDate(last.releasedAt)}` : ''}</p>
      {ls.filter(l => l.valueNum != null).length > 1 && <div className="mt-2"><div className="vy-section-title">Over time</div><TrendChart points={ls.filter(l => l.valueNum != null).map(l => ({ date: l.collectedAt, value: l.valueNum! }))} height={120} /></div>}
    </Card>; })}
  </div>;
};

const PortalPlan: React.FC<{ p: MedPatient }> = ({ p }) => {
  const pub = medRepo.carePlan(p.id)?.published; const [view, setView] = useState<'today' | 'week' | 'med'>('today'); const dow = new Date().getDay();
  if (!pub) return <Empty>Your care team hasn’t shared a Medications & Activities plan yet.</Empty>;
  const print = (wallet: boolean) => printHtml(`Medications & Activities · ${p.name}`, wallet ? `<div class="wallet"><b>${esc(p.name)}</b> · Medications &amp; Activities (v${pub.version}, ${fmtDate(pub.signedAt)})<br>${pub.items.map(i => `${esc(i.title)}: ${i.times.join('/')}${i.days.length < 7 ? ' (' + i.days.map(d => DAYS[d]).join(',') + ')' : ''}`).join('<br>')}<br>Allergies: ${esc(p.allergies.join(', ') || 'Not reported')}</div>` : `<h1>Medications &amp; Activities</h1><p>${esc(p.name)} · from ${esc(pub.signedBy)}, ${fmtDate(pub.signedAt)}</p><table><tr><th>What</th><th>How</th>${TIMES.map(t => `<th>${t}</th>`).join('')}<th>Days</th></tr>${pub.items.map(i => `<tr><td>${esc(i.title)}</td><td>${esc(i.instructions)}</td>${TIMES.map(t => `<td>${i.times.includes(t) ? '☐' : ''}</td>`).join('')}<td>${i.days.length === 7 ? 'Every day' : i.days.map(d => DAYS[d]).join(', ')}</td></tr>`).join('')}</table>${pub.goals.length ? `<h2>Goals</h2><ul>${pub.goals.map(g => `<li>${esc(g.text)}</li>`).join('')}</ul>` : ''}`);
  return <div className="space-y-3" data-testid="portal-plan">
    <Card kicker={`From ${pub.signedBy} · ${fmtDate(pub.signedAt)}`} title="Medications & Activities" right={<><Btn icon={<Printer />} onClick={() => print(false)}>Print page</Btn><Btn onClick={() => print(true)}>Wallet size</Btn></>}>
      <div className="flex gap-1 mb-3">{([['today', 'Today'], ['week', 'This week'], ['med', 'By medication']] as const).map(([k, l]) => <button key={k} type="button" onClick={() => setView(k)} className={`px-3 min-h-[40px] rounded-lg border text-[14.5px] font-semibold ${view === k ? 'bg-[#1f6e52] text-white border-[#1f6e52]' : 'bg-white border-[#b9c5be]'}`} data-testid={`plan-view-${k}`}>{l}</button>)}</div>
      {view === 'today' && <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-2">{TIMES.map(t => <div key={t} className="bg-[#f6f7f4] rounded-lg p-3"><div className="vy-kicker mb-1">{t}</div>{pub.items.filter(i => i.times.includes(t) && i.days.includes(dow)).map(i => <div key={i.id} className="text-[14.5px] mb-1.5"><b>{i.title}</b><div className="text-[13.5px] text-[#39443E]">{i.instructions}</div></div>)}{!pub.items.some(i => i.times.includes(t) && i.days.includes(dow)) && <span className="text-[13px] text-[#5f6862]">Nothing</span>}</div>)}</div>}
      {view === 'week' && <div className="overflow-x-auto"><table className="vy-table"><thead><tr><th>Item</th>{DAYS.map(d => <th key={d}>{d}</th>)}</tr></thead><tbody>{pub.items.map(i => <tr key={i.id}><td><b>{i.title}</b><div className="text-[12.5px]">{i.times.join(', ')}</div></td>{DAYS.map((d, k) => <td key={d} className="text-center">{i.days.includes(k) ? '●' : ''}</td>)}</tr>)}</tbody></table></div>}
      {view === 'med' && <ul className="space-y-2">{pub.items.filter(i => i.kind === 'medication').map(i => <li key={i.id} className="text-[15px]"><b>{i.title}</b> · {i.instructions} · {i.times.join(', ')}{i.days.length < 7 ? ` · ${i.days.map(d => DAYS[d]).join(', ')}` : ''}</li>)}</ul>}
      {pub.goals.length > 0 && <div className="mt-3"><div className="vy-section-title">Goals</div><ul className="list-disc pl-5 text-[15px]">{pub.goals.map(g => <li key={g.id}>{g.text}</li>)}</ul></div>}
      <p className="text-[13px] text-[#5f6862] mt-3">Reminders by email and text message come later. Questions? Use Messages.</p>
    </Card></div>;
};

const PortalAppts: React.FC<{ p: MedPatient }> = ({ p }) => {
  const up = medRepo.visits(p.id).filter(v => v.date >= isoDay() && v.step !== 'complete'); const asc = networkCasesFor(p.id).filter(c => c.date >= isoDay());
  return <Card kicker="Appointments" title="Upcoming" testId="portal-appts">{up.length + asc.length === 0 ? <Empty>No upcoming appointments.</Empty> : <ul className="space-y-2 text-[15px]">{up.map(v => <li key={v.id}><b>{usDate(v.date)} {v.time}</b> · {v.visitType} with {v.provider}{isSurgery && <PortalConfirm v={v} />}</li>)}{asc.map(c => <li key={c.id}><b>{usDate(c.date)} {c.time}</b> · {c.procedure} at {c.ascName} with {c.surgeon}</li>)}</ul>}</Card>;
};

const PortalMessages: React.FC<{ p: MedPatient; author: string; from: 'patient' | 'caregiver' }> = ({ p, author, from }) => {
  useMedTick(); const [t, setT] = useState(''); const msgs = medRepo.messages(p.id);
  const send = () => { if (!t.trim()) return; medRepo.addMessage({ id: uid('pm'), patientId: p.id, from, author, text: t.trim(), at: new Date().toISOString() }); setT(''); };
  return <Card kicker="Messages" title="Your care team" testId="portal-messages"><div className="space-y-2 max-h-[360px] overflow-y-auto mb-2">{msgs.length ? msgs.map(m => <div key={m.id} className={`rounded-lg px-3 py-2 text-[14.5px] max-w-[85%] ${m.from === 'office' ? 'bg-white border border-[#dfe5e1]' : 'ml-auto bg-[#e3f2e9]'}`}><div className="text-[12.5px] text-[#5f6862]">{m.author} · {fmtDateTime(m.at)}</div>{m.text}</div>) : <Empty>No messages.</Empty>}</div>
    <div className="flex gap-2"><input className="vy-input" placeholder="Write a message (not for emergencies)" value={t} onChange={e => setT(e.target.value)} data-testid="portal-msg" /><Btn variant="primary" onClick={send} data-testid="portal-send">Send</Btn></div></Card>;
};

const PortalAccess: React.FC<{ p: MedPatient }> = ({ p }) => {
  useMedTick(); const list = medRepo.caregivers(p.id); const [f, setF] = useState({ name: '', relationship: '', email: '', results: true, plan: true, appointments: true, messages: false }); const [err, setErr] = useState('');
  const grant = () => { try { grantCaregiver({ patientId: p.id, name: f.name, relationship: f.relationship, email: f.email, scope: { results: f.results, plan: f.plan, appointments: f.appointments, messages: f.messages }, grantedBy: p.name, grantedVia: 'patient', authorization: 'Granted by the patient in the portal' }); setF({ ...f, name: '', relationship: '', email: '' }); setErr(''); } catch (e: any) { setErr(e.message); } };
  return <div className="grid lg:grid-cols-2 gap-3" data-testid="portal-access">
    <Card kicker="Who can see your record" title={`${activeCaregivers(p.id).length} caregiver${activeCaregivers(p.id).length === 1 ? '' : 's'}`}>{list.length === 0 ? <Empty>Only you.</Empty> : list.map(c => <div key={c.id} className="border border-[#e7ece9] rounded-lg p-3 mb-2"><b>{c.name}</b> ({c.relationship}) {c.revokedAt ? <Chip tone="muted">Removed</Chip> : <Chip tone="ok">Active</Chip>}<div className="text-[14px]">Can see: {scopeText(c.scope)}</div>{!c.revokedAt && <Btn variant="danger" className="mt-2" onClick={() => revokeCaregiver(c, p.name, 'Patient')}>Remove access</Btn>}</div>)}</Card>
    <Card kicker="Add a caregiver" title="Share your record"><div className="grid grid-cols-2 gap-2"><input className="vy-input" placeholder="Name" value={f.name} onChange={e => setF({ ...f, name: e.target.value })} /><input className="vy-input" placeholder="Relationship" value={f.relationship} onChange={e => setF({ ...f, relationship: e.target.value })} /><input className="vy-input col-span-2" placeholder="Email (invitation is simulated)" value={f.email} onChange={e => setF({ ...f, email: e.target.value })} /></div>
      <div className="flex flex-wrap gap-3 mt-2 text-[14.5px]">{(['results', 'plan', 'appointments', 'messages'] as const).map(k => <label key={k} className="flex items-center gap-1.5"><input type="checkbox" className="w-5 h-5" checked={f[k]} onChange={e => setF({ ...f, [k]: e.target.checked })} />{({ results: 'Lab results', plan: 'Medications & Activities', appointments: 'Appointments', messages: 'Messages' })[k]}</label>)}</div>
      <Btn variant="primary" className="mt-3" onClick={grant}>Give access</Btn>{err && <p className="vy-field-error mt-2">{err}</p>}</Card>
  </div>;
};
