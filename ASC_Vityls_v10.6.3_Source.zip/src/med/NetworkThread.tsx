/* Simulated secure office <-> network ASC thread and document share, per ASC case. */
import React, { useState } from 'react';
import { Send, Paperclip, FileText } from 'lucide-react';
import { Btn } from '../v7/ui';
import { networkRepo, NetworkCase, postNetworkMessage, shareNetworkDocument, matchPatient } from './network';
import { fmtDateTime } from './record';
import { Empty, SimBadge, useActor, useMedTick } from './ui';

export const NetworkThread: React.FC<{ c: NetworkCase }> = ({ c }) => {
  useMedTick(); const [actor] = useActor();
  const [text, setText] = useState(''); const [docTitle, setDocTitle] = useState(''); const [err, setErr] = useState('');
  const msgs = networkRepo.thread(c.id); const docs = networkRepo.documents(c.id); const m = matchPatient(c);
  const send = () => { try { postNetworkMessage(c, text, actor.name, actor.role); setText(''); setErr(''); } catch (e: any) { setErr(e.message); } };
  const simulateReply = () => { try { postNetworkMessage(c, 'Received, thank you. (Simulated reply from the ASC scheduler.)', 'ASC scheduler (simulated)', 'ASC staff', 'asc', true); } catch (e: any) { setErr(e.message); } };
  const shareFile = (file?: File | null) => {
    if (!file) return; if (file.size > 900_000) { setErr('In this test build, share files under 0.9 MB.'); return; }
    const r = new FileReader(); r.onload = () => { try { shareNetworkDocument(c, { fromOrg: 'office', sharedBy: actor.name, title: docTitle.trim() || file.name, fileName: file.name, mime: file.type, dataUrl: String(r.result) }, actor.role); setDocTitle(''); setErr(''); } catch (e: any) { setErr(e.message); } }; r.readAsDataURL(file);
  };
  const shareSummary = () => { try { shareNetworkDocument(c, { fromOrg: 'office', sharedBy: actor.name, title: docTitle.trim() || 'Office pre-surgical summary (text)', text: `Patient: ${c.patientName} (DOB ${c.dob})\nProcedure: ${c.procedure}\nShared by ${actor.name} from the office chart. [Fictional test document]` }, actor.role); setDocTitle(''); setErr(''); } catch (e: any) { setErr(e.message); } };
  return <div className="grid lg:grid-cols-2 gap-4" data-testid="network-thread">
    <div><div className="vy-section-title flex items-center gap-2">Secure thread with the ASC <SimBadge text="Simulated" /></div>
      <div className="border border-[#dfe5e1] rounded-lg p-2 max-h-[300px] overflow-y-auto space-y-2 bg-[#fafbfa]">{msgs.length === 0 ? <Empty>No messages yet.</Empty> : msgs.map(x => <div key={x.id} className={`rounded-lg px-3 py-2 text-[14.5px] max-w-[88%] ${x.fromOrg === 'office' ? 'ml-auto bg-[#e3f2e9]' : 'bg-white border border-[#dfe5e1]'}`}><div className="text-[12.5px] text-[#5f6862]">{x.fromOrg === 'office' ? 'Office' : 'ASC'} · {x.author} · {fmtDateTime(x.at)}</div>{x.text}</div>)}</div>
      <div className="flex gap-2 mt-2"><input className="vy-input" placeholder="Message to the ASC (no PHI leaves this browser)" value={text} onChange={e => setText(e.target.value)} onKeyDown={e => { if (e.key === 'Enter') send(); }} data-testid="network-msg" /><Btn variant="primary" icon={<Send />} onClick={send} data-testid="network-send">Send</Btn></div>
      <Btn variant="ghost" className="mt-1" onClick={simulateReply}>Simulate an ASC reply</Btn></div>
    <div><div className="vy-section-title">Shared documents</div>
      <ul className="space-y-1.5 mb-2">{docs.length === 0 ? <Empty>No documents shared yet.</Empty> : docs.map(d => <li key={d.id} className="flex items-center gap-2 text-[14.5px]"><FileText size={16} className="text-[#1f6e52]" />{d.dataUrl ? <a href={d.dataUrl} download={d.fileName} className="underline">{d.title}</a> : <span title={d.text}>{d.title}</span>}<span className="text-[12.5px] text-[#5f6862]">{d.fromOrg === 'office' ? 'from office' : 'from ASC'} · {d.sharedBy} · {fmtDateTime(d.at)}</span></li>)}</ul>
      {m ? <><p className="text-[13.5px] text-[#39443E] mb-2">Record-sharing consent: {m.recordSharingConsent?.granted ? <b className="text-[#14532f]">on file ({m.recordSharingConsent.scope})</b> : <b className="text-[#8a1f1f]">not recorded (record it in the patient chart, Network ASC tab)</b>}</p>
        <input className="vy-input mb-2" placeholder="Document title (optional)" value={docTitle} onChange={e => setDocTitle(e.target.value)} />
        <div className="flex flex-wrap gap-2"><label className="vy-btn vy-btn-secondary cursor-pointer"><Paperclip size={16} />Share a file<input type="file" className="hidden" onChange={e => shareFile(e.target.files?.[0])} data-testid="network-file" /></label><Btn onClick={shareSummary} data-testid="network-share-summary">Share office summary (text)</Btn></div></>
        : <p className="text-[13.5px] text-[#8a1f1f]">This ASC case is not linked to an office chart, so documents cannot be shared. Messages are allowed for scheduling.</p>}
      {err && <p className="vy-field-error mt-2">{err}</p>}
    </div>
  </div>;
};
