/* MED staff messages: patient / caregiver portal threads (stored through the MED record layer) + network ASC threads. */
import React, { useState } from 'react';
import { Btn } from '../v7/ui';
import { medRepo, uid, fmtDateTime, usDate, isoDay } from './record';
import { networkRepo, matchPatient } from './network';
import { Card, Empty, SimBadge, useActor, useMedTick } from './ui';

export const MedMessages: React.FC<{ onOpenChart: (pid: string, s?: string) => void }> = ({ onOpenChart }) => {
  useMedTick(); const [actor] = useActor();
  const threads = medRepo.patients().map(p => ({ p, msgs: medRepo.messages(p.id) })).filter(x => x.msgs.length).sort((a, b) => b.msgs[b.msgs.length - 1].at.localeCompare(a.msgs[a.msgs.length - 1].at));
  const [sel, setSel] = useState(threads[0]?.p.id || ''); const [t, setT] = useState('');
  const cur = threads.find(x => x.p.id === sel);
  const send = () => { if (!t.trim() || !cur) return; medRepo.addMessage({ id: uid('pm'), patientId: cur.p.id, from: 'office', author: `${actor.name} (office)`, text: t.trim(), at: new Date().toISOString() }); setT(''); };
  const net = networkRepo.cases().filter(c => c.date >= isoDay()).map(c => ({ c, n: networkRepo.thread(c.id).length })).filter(x => x.n > 0);
  return <div className="grid lg:grid-cols-[320px_1fr] gap-4" data-testid="med-messages">
    <div className="space-y-3"><Card kicker="Portal messages" title={`${threads.length} threads`}>{threads.length === 0 ? <Empty>No messages.</Empty> : threads.map(x => { const last = x.msgs[x.msgs.length - 1]; return <button key={x.p.id} type="button" onClick={() => setSel(x.p.id)} className={`block w-full text-left px-3 py-2 rounded-lg mb-1 ${sel === x.p.id ? 'bg-[#e3f2e9]' : 'hover:bg-[#f2f5f3]'}`}><div className="font-semibold text-[15px]">{x.p.name}{last.from !== 'office' && <span className="ml-2 text-[12.5px] text-[#6b4708]">awaiting reply</span>}</div><div className="text-[13px] text-[#5f6862] truncate">{last.author}: {last.text}</div></button>; })}</Card>
      <Card kicker="Network ASC threads" title={`${net.length} active`} right={<SimBadge text="Simulated" />}>{net.length === 0 ? <Empty>No ASC threads.</Empty> : net.map(x => { const m = matchPatient(x.c); return <button key={x.c.id} type="button" disabled={!m} onClick={() => m && onOpenChart(m.id, 'network')} className="block w-full text-left px-3 py-2 rounded-lg hover:bg-[#f2f5f3] text-[14px]"><b>{x.c.patientName}</b> · {x.c.procedure} · {usDate(x.c.date)} ({x.n})</button>; })}</Card></div>
    {cur ? <Card kicker="Thread" title={cur.p.name} right={<Btn onClick={() => onOpenChart(cur.p.id)}>Open chart</Btn>}>
      <div className="space-y-2 max-h-[460px] overflow-y-auto mb-2">{cur.msgs.map(m => <div key={m.id} className={`rounded-lg px-3 py-2 text-[14.5px] max-w-[85%] ${m.from === 'office' ? 'ml-auto bg-[#e3f2e9]' : 'bg-white border border-[#dfe5e1]'}`}><div className="text-[12.5px] text-[#5f6862]">{m.author} · {m.from} · {fmtDateTime(m.at)}</div>{m.text}</div>)}</div>
      <div className="flex gap-2"><input className="vy-input" placeholder={`Reply as ${actor.name}`} value={t} onChange={e => setT(e.target.value)} data-testid="office-reply" /><Btn variant="primary" onClick={send} data-testid="office-send">Send</Btn></div>
      <p className="text-[12.5px] text-[#5f6862] mt-1">Nightingale does not draft clinical replies in this build.</p></Card> : <Empty>Choose a thread.</Empty>}
  </div>;
};
