/* MED schedule: day view by provider, office visits + the simulated "ASC cases" layer (Network Provider architecture). */
import React, { useState } from 'react';
import { ChevronLeft, ChevronRight, Plus, Building } from 'lucide-react';
import { Btn, DialogShell } from '../v7/ui';
import { getProviders, displayName, textOn } from '../v7/providers';
import { repo } from '../v6/dataLayer';
import { medRepo, MedVisit, VISIT_TYPES, isoDay, addDays, usDate, toMin, uid, ageFrom } from './record';
import { MED_ROOMS } from './seed';
import { networkRepo, matchPatient, NetworkCase } from './network';
import { Chip, SimBadge, useActor, useMedTick } from './ui';
import { NetworkThread } from './NetworkThread';

const START = 7 * 60, END = 18 * 60, PX = 1.25; // px per minute
const parse = (t: string) => +toMin(t);
const fmt = (m: number) => { const h = Math.floor(m / 60), mm = m % 60; return `${String(((h + 11) % 12) + 1).padStart(2, '0')}:${String(mm).padStart(2, '0')} ${h < 12 ? 'AM' : 'PM'}`; };
export const STEP_LABEL: Record<string, string> = { scheduled: 'Scheduled', 'check-in': 'Checked in', rooming: 'Rooming', provider: 'With provider', checkout: 'Checkout', complete: 'Complete' };

export const MedSchedule: React.FC<{ onOpenChart: (pid: string) => void; onOpenVisit: (vid: string) => void; onToast: (m: string) => void }> = ({ onOpenChart, onOpenVisit, onToast }) => {
  useMedTick(); const [actor] = useActor();
  const [day, setDay] = useState(isoDay()); const [showAsc, setShowAsc] = useState(true); const [adding, setAdding] = useState<{ provider: string; time: string } | null>(null);
  const [sel, setSel] = useState<NetworkCase | null>(null);
  const providers = getProviders().filter(p => p.active).map(p => ({ name: displayName(p), color: p.color, role: p.role }));
  const visits = medRepo.visits().filter(v => v.date === day);
  const net = networkRepo.cases().filter(c => c.date === day);
  const norm = (s: string) => s.toLowerCase().replace(/,.*$/, '').trim();
  const H = (END - START) * PX;
  return <div className="space-y-3" data-testid="med-schedule">
    <div className="vy-page-header"><div><div className="vy-page-kicker">Office schedule</div><div className="vy-page-title">{new Date(day + 'T12:00:00').toLocaleDateString([], { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' })}</div><div className="vy-page-sub">{visits.length} office visit{visits.length === 1 ? '' : 's'}{showAsc ? ` · ${net.length} ASC case${net.length === 1 ? '' : 's'} at the network ASC` : ''}</div></div>
      <div className="flex gap-2 flex-wrap items-center"><Btn onClick={() => setDay(addDays(day, -1))} aria-label="Previous day"><ChevronLeft /></Btn><Btn onClick={() => setDay(isoDay())}>Today</Btn><Btn onClick={() => setDay(addDays(day, 1))} aria-label="Next day"><ChevronRight /></Btn>
        <label className="flex items-center gap-2 bg-white text-[#1f2b25] rounded-lg px-3 min-h-[44px] text-[15px] font-semibold"><input type="checkbox" checked={showAsc} onChange={e => setShowAsc(e.target.checked)} data-testid="toggle-asc-layer" className="w-5 h-5" />ASC cases</label>
        <Btn variant="add" icon={<Plus />} onClick={() => setAdding({ provider: providers[0]?.name || '', time: '09:00 AM' })} data-testid="add-visit">Add visit</Btn></div></div>
    {showAsc && <div className="flex flex-wrap gap-2 items-center text-[13.5px] text-[#39443E]"><span className="inline-block w-5 h-3 rounded-sm border border-[#475569]" style={{ background: 'repeating-linear-gradient(135deg,#eef2f6,#eef2f6 5px,#dde3ea 5px,#dde3ea 10px)' }} />ASC case booked for this office’s surgeon at the network ASC <SimBadge text="Simulated network link" /></div>}
    <div className="overflow-x-auto bg-white border border-[#dfe5e1] rounded-xl">
      <div className="grid" style={{ gridTemplateColumns: `64px repeat(${providers.length}, minmax(200px, 1fr))`, minWidth: 64 + providers.length * 200 }}>
        <div className="sticky left-0 bg-white z-10 border-b border-[#e7ece9]" />
        {providers.map(p => <div key={p.name} className="px-3 py-2 border-b border-l border-[#e7ece9] font-semibold text-[15px] flex items-center gap-2"><span className="w-3 h-3 rounded-full" style={{ background: p.color }} />{p.name}<span className="text-[12.5px] font-normal text-[#5f6862]">{p.role}</span></div>)}
        <div className="relative sticky left-0 bg-white z-10" style={{ height: H }}>{Array.from({ length: (END - START) / 60 + 1 }, (_, i) => <div key={i} className="absolute right-2 text-[12px] text-[#5f6862]" style={{ top: i * 60 * PX - 7 }}>{fmt(START + i * 60).replace(':00', '')}</div>)}</div>
        {providers.map(p => <div key={p.name} className="relative border-l border-[#e7ece9]" style={{ height: H }} onDoubleClick={e => { const r = (e.currentTarget as HTMLDivElement).getBoundingClientRect(); const m = START + Math.round(((e.clientY - r.top) / PX) / 15) * 15; setAdding({ provider: p.name, time: fmt(m) }); }}>
          {Array.from({ length: (END - START) / 30 }, (_, i) => <div key={i} className={`absolute left-0 right-0 border-t ${i % 2 ? 'border-[#f1f3f1]' : 'border-[#e7ece9]'}`} style={{ top: i * 30 * PX }} />)}
          {showAsc && net.filter(c => norm(c.surgeon) === norm(p.name)).map(c => { const top = (parse(c.time) - START) * PX; const m = matchPatient(c); return <button type="button" key={c.id} onClick={() => setSel(c)} data-testid="asc-case-block" className="absolute left-[61%] right-1 rounded-md border-2 border-[#475569] text-left px-2 py-1 overflow-hidden text-[13px] text-[#1f2b25]" style={{ top, height: Math.max(36, c.durationMin * PX), background: 'repeating-linear-gradient(135deg,#eef2f6,#eef2f6 6px,#dde3ea 6px,#dde3ea 12px)' }}>
            <div className="font-bold flex items-center gap-1"><Building size={13} />ASC case · {c.time}</div><div className="truncate">{c.patientName}{m ? '' : ' (not linked)'}</div><div className="truncate text-[12px]">{c.procedure}</div></button>; })}
          {visits.filter(v => norm(v.provider) === norm(p.name)).map(v => { const pt = medRepo.patient(v.patientId); const top = (parse(v.time) - START) * PX; return <button type="button" key={v.id} onClick={() => onOpenVisit(v.id)} data-testid="visit-block" className={`absolute left-1 ${showAsc ? 'right-[40%]' : 'right-1'} rounded-md text-left px-2 py-1 overflow-hidden text-[13px] shadow-sm`} style={{ top, height: Math.max(34, v.durationMin * PX - 2), background: p.color, color: textOn(p.color) }}>
            <div className="font-bold truncate">{v.time} · {pt?.name}</div><div className="truncate text-[12.5px]">{v.visitType} · {v.room} · {STEP_LABEL[v.step]}</div></button>; })}
        </div>)}
      </div>
    </div>
    <p className="text-[13px] text-[#5f6862]">Double-tap a provider column to add a visit at that time. Tap a visit to open it; tap an ASC case for the secure thread and documents.</p>
    {adding && <AddVisitDialog initial={adding} day={day} providers={providers.map(p => p.name)} onClose={() => setAdding(null)} onSaved={v => { setAdding(null); repo.audit({ caseId: v.id, user: actor.name, role: actor.role, action: 'visit.create', detail: `${v.visitType} ${usDate(v.date)} ${v.time} with ${v.provider} in ${v.room}` }); onToast(`Visit added for ${medRepo.patient(v.patientId)?.name}.`); }} />}
    {sel && <NetworkCaseDialog c={sel} onClose={() => setSel(null)} onOpenChart={pid => { setSel(null); onOpenChart(pid); }} />}
  </div>;
};

export const AddVisitDialog: React.FC<{ initial: { provider: string; time: string; patientId?: string; visitType?: string; reason?: string }; day: string; providers: string[]; onClose: () => void; onSaved: (v: MedVisit) => void }> = ({ initial, day, providers, onClose, onSaved }) => {
  const [actor] = useActor();
  const [f, setF] = useState({ patientId: initial.patientId || '', q: '', date: day, time: initial.time, provider: initial.provider, room: MED_ROOMS[0], visitType: initial.visitType || VISIT_TYPES[0] as string, reason: initial.reason || '', duration: 30 });
  const [err, setErr] = useState('');
  const matches = f.q.trim().length >= 2 ? medRepo.patients().filter(p => p.name.toLowerCase().includes(f.q.toLowerCase())).slice(0, 6) : [];
  const pt = medRepo.patient(f.patientId);
  const save = () => {
    if (!pt) { setErr('Choose a patient.'); return; } if (!/^\d{1,2}:\d{2}\s?(AM|PM)$/i.test(f.time.trim())) { setErr('Time must look like 09:30 AM.'); return; }
    const v: MedVisit = { id: uid('visit'), patientId: pt.id, date: f.date, time: f.time.trim().toUpperCase(), durationMin: f.duration, provider: f.provider, room: f.room, visitType: f.visitType, reason: f.reason, step: 'scheduled', problemIds: [], createdAt: new Date().toISOString(), createdBy: actor.name };
    medRepo.saveVisit(v); onSaved(v);
  };
  return <DialogShell title="Add office visit" onClose={onClose} size="md" testId="add-visit-dialog" footer={<><Btn onClick={onClose}>Cancel</Btn><Btn variant="primary" onClick={save} data-testid="save-visit">Save visit</Btn></>}>
    <div className="grid sm:grid-cols-2 gap-3">
      <div className="sm:col-span-2"><span className="vy-label">Patient</span>{pt ? <div className="flex items-center gap-2"><b>{pt.name}</b><span className="text-[14px] text-[#5f6862]">DOB {pt.dob} · {ageFrom(pt.dob)} y</span><Btn variant="ghost" onClick={() => setF({ ...f, patientId: '' })}>Change</Btn></div> :
        <><input className="vy-input" placeholder="Type 2+ letters of the name" value={f.q} onChange={e => setF({ ...f, q: e.target.value })} data-testid="visit-patient-search" />{matches.map(m => <button key={m.id} type="button" className="block w-full text-left px-3 py-2 hover:bg-[#f2f5f3] text-[15px]" onClick={() => setF({ ...f, patientId: m.id, q: '' })}>{m.name} · DOB {m.dob}</button>)}</>}</div>
      <label><span className="vy-label">Date</span><input type="date" className="vy-input" value={f.date} onChange={e => setF({ ...f, date: e.target.value })} /></label>
      <label><span className="vy-label">Time</span><input className="vy-input" value={f.time} onChange={e => setF({ ...f, time: e.target.value })} /></label>
      <label><span className="vy-label">Provider</span><select className="vy-input" value={f.provider} onChange={e => setF({ ...f, provider: e.target.value })}>{providers.map(p => <option key={p}>{p}</option>)}</select></label>
      <label><span className="vy-label">Exam room</span><select className="vy-input" value={f.room} onChange={e => setF({ ...f, room: e.target.value })}>{MED_ROOMS.map(r => <option key={r}>{r}</option>)}</select></label>
      <label><span className="vy-label">Visit type</span><select className="vy-input" value={f.visitType} onChange={e => setF({ ...f, visitType: e.target.value })}>{VISIT_TYPES.map(t => <option key={t}>{t}</option>)}</select></label>
      <label><span className="vy-label">Length</span><select className="vy-input" value={f.duration} onChange={e => setF({ ...f, duration: +e.target.value })}>{[15, 30, 45, 60].map(n => <option key={n} value={n}>{n} min</option>)}</select></label>
      <label className="sm:col-span-2"><span className="vy-label">Reason for visit</span><input className="vy-input" value={f.reason} onChange={e => setF({ ...f, reason: e.target.value })} /></label>
      {err && <p className="vy-field-error sm:col-span-2">{err}</p>}
    </div>
  </DialogShell>;
};

export const NetworkCaseDialog: React.FC<{ c: NetworkCase; onClose: () => void; onOpenChart: (pid: string) => void }> = ({ c, onClose, onOpenChart }) => {
  const m = matchPatient(c);
  return <DialogShell title={`ASC case · ${c.procedure}`} subtitle={`${c.ascName} · ${usDate(c.date)} ${c.time} · ${c.room} · ${c.surgeon}`} kicker="Network ASC" onClose={onClose} size="lg" testId="network-case-dialog" footer={<>{m && <Btn onClick={() => onOpenChart(m.id)}>Open office chart</Btn>}<Btn variant="primary" onClick={onClose}>Close</Btn></>}>
    <div className="flex flex-wrap gap-2 items-center mb-3"><SimBadge /><Chip tone={c.source === 'asc-store' ? 'info' : 'muted'}>{c.source === 'asc-store' ? 'Read from ASC.Vityls data in this browser' : 'Fictional seed network case'}</Chip><Chip tone={m ? 'ok' : 'warn'}>{m ? `Linked to office chart ${m.name} (name + DOB match, simulated)` : 'Not linked to an office chart'}</Chip><Chip>{c.status}</Chip></div>
    <NetworkThread c={c} />
  </DialogShell>;
};
