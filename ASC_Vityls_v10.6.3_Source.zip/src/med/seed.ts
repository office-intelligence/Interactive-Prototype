/*
 * MED.Vityls v0.1 test scaffolding: a FICTIONAL plastic surgery office. No real patient data.
 * Runs only in the MED edition, inside the MED storage namespace (ASC test data is never touched).
 * ?reset-test-data in the address bar wipes the MED test data and reloads this seed.
 * Backend: delete this file; data comes from the API.
 */
import { isMedical } from '../edition';
import { repo } from '../v6/dataLayer';
import { hashPin, Provider } from '../v7/providers';
import { medRepo, MedPatient, Problem, Medication, Vitals, LabResult, IntakeAnswer, CarePlan, MedVisit, VisitNote, isoDay, addDays, bmiFrom, patientKey } from './record';
import { NetworkCase, networkRepo } from './network';

export const MED_SEED_VERSION = 'med-v0.1';
const now = () => new Date().toISOString();
const at = (iso: string, hh = '10:00') => new Date(`${iso}T${hh}:00`).toISOString();
const app = (id: string) => ({ id: `APP-${id}`, status: 'Privileges approved' as const, createdAt: now(), history: [{ status: 'Queued', at: now(), by: 'Seed data' }, { status: 'Privileges approved', at: now(), by: 'Seed data' }] });
const onb = () => ({ invitedAt: now(), applicationAt: now(), accountAt: now(), pinAt: now(), username: '(seeded)' });
export const MED_PROVIDERS: Provider[] = [
  { id: 'prov-patel', firstName: 'Sam', lastName: 'Patel', degree: 'MD', role: 'Surgeon', specialty: 'Plastic Surgery', npi: '', email: '', phone: '', color: '#1D4ED8', pinHash: hashPin('1234'), active: true, app: app('patel'), onboarding: onb() },
  { id: 'prov-whitfield', firstName: 'Dana', lastName: 'Whitfield', degree: 'MD', role: 'Surgeon', specialty: 'Plastic & Reconstructive Surgery', npi: '', email: '', phone: '', color: '#7C3AED', pinHash: hashPin('1234'), active: true, app: app('whitfield'), onboarding: onb() },
  { id: 'prov-ortiz', firstName: 'Jamie', lastName: 'Ortiz', degree: 'NP', role: 'Nurse practitioner', specialty: 'Aesthetic medicine', npi: '', email: '', phone: '', color: '#0F766E', pinHash: hashPin('1234'), active: true, app: app('ortiz'), onboarding: onb() },
];
const PATEL = 'Sam Patel, MD', WHIT = 'Dana Whitfield, MD', ORTIZ = 'Jamie Ortiz, NP';
export const MED_ROOMS = ['Exam 1', 'Exam 2', 'Exam 3', isMedical ? 'Treatment room' : 'Procedure room'];

const MY_FORMS: [string, string[], string][] = [
  ['Patient_Registration.html', ['frontOffice'], 'required'], ['Insurance_Information.html', ['frontOffice'], 'as-needed'],
  ['Medical_History.html', ['patientPortal', 'nursing'], 'required'], ['Photography_Media_Research_Consent.html', ['patientPortal', 'frontOffice'], 'as-needed'],
  ['Credit_Card_Authorization.html', ['frontOffice'], 'as-needed'], ['Procedure_Consent.html', ['surgeon'], 'as-needed'],
];

/** Surgery.Vityls reuses this seed with its own version string and an `after` hook for its extra data. */
export function seedMedData(opts: { version?: string; after?: () => void } = {}) {
  const VERSION = opts.version || MED_SEED_VERSION;
  try {
    const params = new URLSearchParams(location.search);
    if (params.has('reset-test-data') || localStorage.getItem('vityls:seed-version') !== VERSION) {
      localStorage.clear(); // MED namespace only (see src/edition.ts)
      localStorage.setItem('vityls:seed-version', VERSION);
      if (params.has('reset-test-data')) { const u = new URL(location.href); u.searchParams.delete('reset-test-data'); history.replaceState(null, '', u.toString()); }
    }
    if (medRepo.patients().length) return;
    const T = isoDay();
    // legacy one-time cleanups in App.tsx must not wipe the seeded My Forms setup
    localStorage.setItem('vityls-explicit-form-workflow-v3-clean', 'done'); localStorage.setItem('oi-premiere-official-html-library-v27-clean', 'done');
    localStorage.setItem('vityls:v7:providers', JSON.stringify(MED_PROVIDERS));
    repo.setActor({ name: 'Morgan Avery', role: 'Medical assistant', credentials: 'MA', kind: 'human' });
    localStorage.setItem('vityls-my-forms:default-practice', JSON.stringify(MY_FORMS.map(f => f[0])));
    MY_FORMS.forEach(([file, stations, req]) => { const wf: Record<string, { enabled: boolean }> = {}; ['patientPortal', 'frontOffice', 'nursing', 'anesthesia', 'orTeam', 'surgeon', 'pacu'].forEach(k => wf[k] = { enabled: stations.includes(k) }); localStorage.setItem(`vityls-form-workflow:${file}`, JSON.stringify(wf)); localStorage.setItem(`vityls-form-requirement:${file}`, req); });

    const pt = (id: string, name: string, dob: string, sex: MedPatient['sex'], allergies: string[], primary: string, extra: Partial<MedPatient> = {}): MedPatient =>
      ({ id, name, dob, sex, phone: `(555) 014-${id.slice(-4)}`, email: `${name.split(' ')[0].toLowerCase()}@example.test`, language: 'English', allergies, primaryProvider: primary, careTeam: [{ name: primary, role: 'Surgeon' }], fictional: true, ...extra });
    const patients: MedPatient[] = [
      pt('MED-1001', 'Ellen Testwood', '04/18/1954', 'Female', ['Penicillin (hives)', 'Codeine (nausea)'], PATEL, { allergiesConfirmedAt: at(addDays(T, -30)), allergiesConfirmedBy: 'Casey Morgan, RN', careTeam: [{ name: PATEL, role: 'Surgeon' }, { name: 'Lena Brooks, MD (fictional)', role: 'Primary care (outside)', phone: '(555) 014-2200' }, { name: 'Omar Haddad, MD (fictional)', role: 'Cardiology (outside)', phone: '(555) 014-2300' }], emergencyContact: 'Gene Testwood (daughter) (555) 014-1002', recordSharingConsent: { granted: true, by: 'Front Desk Tester', at: at(addDays(T, -30)), scope: 'Surgical records for the booked procedure' } }),
      pt('MED-1003', 'Marisol Sampleton', '09/02/1980', 'Female', ['NKDA'], WHIT, { allergiesConfirmedAt: at(addDays(T, -60)), allergiesConfirmedBy: 'Casey Morgan, RN', language: 'English, Spanish' }),
      pt('MED-1004', 'Robert Fictus', '01/27/1965', 'Male', ['Sulfa drugs (rash)'], WHIT, { allergiesConfirmedAt: at(addDays(T, -45)), allergiesConfirmedBy: 'Casey Morgan, RN', recordSharingConsent: { granted: true, by: 'Front Desk Tester', at: at(addDays(T, -45)), scope: 'Surgical records for the booked procedure' } }),
      pt('MED-1005', 'Priya Demoshah', '06/11/1988', 'Female', [], ORTIZ),
      pt('MED-1006', 'Grace Placeholder', '12/05/1971', 'Female', ['NKDA'], PATEL, { allergiesConfirmedAt: at(addDays(T, -200)), allergiesConfirmedBy: 'Casey Morgan, RN' }),
      pt('MED-1007', 'Tomas Exampleton', '03/30/1992', 'Male', [], PATEL),
    ];
    patients.forEach(p => medRepo.savePatient(p));
    repo.putFacts(patientKey('MED-1005'), [{ concept: 'patient.reportedAllergies', value: 'Latex (rash)', source: { kind: 'manual', label: 'Medical History (patient portal)', formTitle: 'Medical History (patient portal)', by: 'Patient', at: at(addDays(T, -2)), needsConfirm: true } }]);

    const prob = (id: string, pid: string, d: string, t: Problem['conditionType'], daysAgo: number, onset?: string): Problem => ({ id, patientId: pid, description: d, conditionType: t, status: 'active', onset, recordedAt: at(addDays(T, -daysAgo)), recordedBy: 'Casey Morgan, RN', source: 'Rooming review (seed)' });
    [prob('pr-e1', 'MED-1001', 'Type 2 diabetes', 'diabetes', 400, '2011'), prob('pr-e2', 'MED-1001', 'Hypertension', 'hypertension', 400, '2008'), prob('pr-e3', 'MED-1001', 'Coronary artery disease, stent 2019', 'heart', 400, '2019'),
     prob('pr-e4', 'MED-1001', 'Obstructive sleep apnea, uses CPAP', 'osa', 400), prob('pr-e5', 'MED-1001', 'Dermatochalasis, upper lids (surgical problem)', 'skin', 30),
     prob('pr-m1', 'MED-1003', 'Hypothyroidism', 'thyroid', 60), prob('pr-r1', 'MED-1004', 'Atrial fibrillation', 'heart', 45), prob('pr-r2', 'MED-1004', 'Hypertension', 'hypertension', 45),
    ].forEach(p => medRepo.saveProblem(p, 'Seed data'));

    const med = (id: string, pid: string, name: string, dose: string, freq: string, probs: string[], daysAgo: number): Medication => ({ id, patientId: pid, name, dose, frequency: freq, status: 'active', problemIds: probs, source: 'Patient-reported, reconciled (seed)', recordedAt: at(addDays(T, -daysAgo)), recordedBy: 'Casey Morgan, RN' });
    [med('m-e1', 'MED-1001', 'Metformin', '1000 mg', 'twice daily', ['pr-e1'], 400), med('m-e2', 'MED-1001', 'Semaglutide (Ozempic)', '1 mg', 'weekly', ['pr-e1'], 180), med('m-e3', 'MED-1001', 'Lisinopril', '20 mg', 'daily', ['pr-e2'], 400),
     med('m-e4', 'MED-1001', 'Atorvastatin', '40 mg', 'nightly', ['pr-e3'], 400), med('m-e5', 'MED-1001', 'Clopidogrel (Plavix)', '75 mg', 'daily', ['pr-e3'], 400),
     med('m-m1', 'MED-1003', 'Levothyroxine', '75 mcg', 'daily', ['pr-m1'], 60), med('m-r1', 'MED-1004', 'Apixaban (Eliquis)', '5 mg', 'twice daily', ['pr-r1'], 45), med('m-r2', 'MED-1004', 'Metoprolol', '25 mg', 'twice daily', ['pr-r1', 'pr-r2'], 45),
     med('m-g1', 'MED-1006', 'Aspirin', '81 mg', 'daily', [], 200),
    ].forEach(m => medRepo.saveMed(m, 'Seed data', 'med.add'));

    const vit = (pid: string, daysAgo: number, bpSys: number, bpDia: number, hr: number, heightIn: number, weightLb: number): Vitals => ({ id: `v-${pid}-${daysAgo}`, patientId: pid, at: at(addDays(T, -daysAgo), '09:05'), by: 'Morgan Avery, MA', source: 'manual', bpSys, bpDia, hr, spo2: 97, heightIn, weightLb, bmi: bmiFrom(heightIn, weightLb) });
    [vit('MED-1001', 540, 138, 82, 74, 64, 176), vit('MED-1001', 365, 134, 80, 72, 64, 172), vit('MED-1001', 180, 142, 84, 76, 64, 170), vit('MED-1001', 30, 136, 78, 70, 64, 169),
     vit('MED-1003', 60, 122, 76, 80, 65, 184), vit('MED-1004', 45, 128, 80, 66, 70, 196), vit('MED-1004', 8, 130, 78, 68, 70, 194), vit('MED-1006', 200, 118, 72, 64, 66, 142),
    ].forEach(v => medRepo.addVitals(v));

    const lab = (id: string, pid: string, test: string, v: number, unit: string, daysAgo: number, probs: string[], status: LabResult['status'], range = ''): LabResult => {
      const d = addDays(T, -daysAgo); const base: LabResult = { id, patientId: pid, test, value: String(v), valueNum: v, unit, reportedRange: range, collectedAt: d, enteredAt: at(d, '15:00'), enteredBy: 'Front Desk Tester', source: 'Outside lab report, entered by staff (fictional)', problemIds: probs, status };
      return status === 'awaiting-review' ? base : { ...base, reviewedBy: PATEL, reviewedAt: at(addDays(d, 1)), releasedAt: at(addDays(d, 1)), releasedBy: PATEL, status: 'released' };
    };
    [lab('l-e1', 'MED-1001', 'Hemoglobin A1c', 7.4, '%', 540, ['pr-e1'], 'released'), lab('l-e2', 'MED-1001', 'Hemoglobin A1c', 7.1, '%', 365, ['pr-e1'], 'released'), lab('l-e3', 'MED-1001', 'Hemoglobin A1c', 6.9, '%', 180, ['pr-e1'], 'released'), lab('l-e4', 'MED-1001', 'Hemoglobin A1c', 7.2, '%', 10, ['pr-e1'], 'awaiting-review'),
     lab('l-e5', 'MED-1001', 'Creatinine', 1.0, 'mg/dL', 365, [], 'released'), lab('l-e6', 'MED-1001', 'Creatinine', 1.1, 'mg/dL', 10, [], 'awaiting-review'),
     lab('l-e7', 'MED-1001', 'LDL cholesterol', 112, 'mg/dL', 365, ['pr-e3'], 'released'), lab('l-e8', 'MED-1001', 'LDL cholesterol', 94, 'mg/dL', 180, ['pr-e3'], 'released'),
     lab('l-e9', 'MED-1001', 'Hemoglobin', 12.9, 'g/dL', 180, [], 'released'), lab('l-e10', 'MED-1001', 'Hemoglobin', 13.1, 'g/dL', 10, [], 'awaiting-review'),
     lab('l-r1', 'MED-1004', 'Hemoglobin', 14.2, 'g/dL', 20, [], 'released'), lab('l-r2', 'MED-1004', 'Creatinine', 0.9, 'mg/dL', 20, [], 'released'),
    ].forEach(l => medRepo.saveLab(l));

    const ia = (key: IntakeAnswer['key'], value: string, daysAgo: number, detail?: string): IntakeAnswer => ({ key, value, detail, recordedAt: at(addDays(T, -daysAgo)), source: 'Medical History (patient portal)' });
    medRepo.saveIntake('MED-1001', [ia('smoking', 'Former (quit 1998)', 30), ia('priorAnesthesiaProblems', 'Yes', 30, 'Nausea and vomiting after surgery in 2015 (patient-reported)'), ia('bleedingHistory', 'No', 30), ia('sleepApnea', 'Yes', 30, 'Uses CPAP'), ia('malignantHyperthermia', 'No', 30)], 'Seed data');
    medRepo.saveIntake('MED-1003', [ia('smoking', 'Current', 3, 'About half a pack a day (patient-reported)'), ia('priorAnesthesiaProblems', 'No', 3), ia('bleedingHistory', 'No', 3), ia('bloodClots', 'No', 3), ia('pregnancy', 'No', 3)], 'Seed data');
    medRepo.saveIntake('MED-1004', [ia('smoking', 'Never', 45), ia('priorAnesthesiaProblems', 'No', 45), ia('bleedingHistory', 'No', 45)], 'Seed data');
    medRepo.saveIntake('MED-1006', [ia('smoking', 'Never', 5), ia('malignantHyperthermia', 'Yes', 5, 'Father had a reaction to anesthesia described as malignant hyperthermia (patient-reported)'), ia('bleedingHistory', 'Yes', 5, 'Bruises easily (patient-reported)')], 'Seed data');

    const plan: CarePlan = { patientId: 'MED-1001', version: 1, status: 'signed', updatedAt: at(addDays(T, -30)), updatedBy: PATEL, signedBy: PATEL, signedAt: at(addDays(T, -30), '11:40'),
      goals: [{ id: 'g1', text: 'Bring your home blood pressure log to the pre-surgical visit.', problemId: 'pr-e2' }, { id: 'g2', text: 'Keep using CPAP every night, including after surgery.', problemId: 'pr-e4' }],
      items: [
        { id: 'ci1', kind: 'medication', title: 'Metformin 1000 mg', instructions: 'With breakfast and dinner', times: ['morning', 'evening'], days: [0, 1, 2, 3, 4, 5, 6], medId: 'm-e1', problemId: 'pr-e1' },
        { id: 'ci2', kind: 'medication', title: 'Lisinopril 20 mg', instructions: 'Once a day', times: ['morning'], days: [0, 1, 2, 3, 4, 5, 6], medId: 'm-e3', problemId: 'pr-e2' },
        { id: 'ci3', kind: 'medication', title: 'Clopidogrel 75 mg', instructions: 'Once a day. Do not stop on your own; your surgeon and cardiologist will tell you what to do before surgery.', times: ['morning'], days: [0, 1, 2, 3, 4, 5, 6], medId: 'm-e5', problemId: 'pr-e3' },
        { id: 'ci4', kind: 'medication', title: 'Atorvastatin 40 mg', instructions: 'At bedtime', times: ['bedtime'], days: [0, 1, 2, 3, 4, 5, 6], medId: 'm-e4', problemId: 'pr-e3' },
        { id: 'ci5', kind: 'medication', title: 'Semaglutide 1 mg injection', instructions: 'Once a week on Mondays. Ask the office before surgery about when to take it.', times: ['morning'], days: [1], medId: 'm-e2', problemId: 'pr-e1' },
        { id: 'ci6', kind: 'check', title: 'Check blood pressure', instructions: 'Write it in your log', times: ['morning'], days: [0, 1, 2, 3, 4, 5, 6], problemId: 'pr-e2' },
        { id: 'ci7', kind: 'activity', title: 'CPAP', instructions: 'Every night', times: ['bedtime'], days: [0, 1, 2, 3, 4, 5, 6], problemId: 'pr-e4' },
      ] };
    plan.published = { items: plan.items, goals: plan.goals, signedBy: PATEL, signedAt: plan.signedAt!, version: 1 };
    medRepo.saveCarePlan(plan);
    medRepo.saveCaregiver({ id: 'cg-gene', patientId: 'MED-1001', name: 'Gene Testwood', relationship: 'Daughter', email: 'gene@example.test', scope: { results: true, plan: true, appointments: true, messages: true }, grantedBy: 'Front Desk Tester', grantedVia: 'staff', authorization: 'Signed caregiver authorization form on file (fictional)', grantedAt: at(addDays(T, -30)) });
    repo.audit({ caseId: patientKey('MED-1001'), user: 'Front Desk Tester', role: 'Front desk', action: 'proxy.grant', detail: 'Gene Testwood (Daughter) · scope: lab results, medications & activities plan, appointments, messages · authorization: signed form on file (seed)' });
    medRepo.addMessage({ id: 'pm-1', patientId: 'MED-1001', from: 'caregiver', author: 'Gene Testwood (daughter)', text: 'Hi, this is Gene. Mom has her eyelid surgery coming up. Does she need to do anything about her Plavix or her weekly Ozempic shot beforehand? Thank you.', at: at(addDays(T, -1), '18:20') });

    const visit = (id: string, pid: string, date: string, time: string, provider: string, room: string, visitType: string, reason: string, step: MedVisit['step'], problemIds: string[] = []): MedVisit =>
      ({ id, patientId: pid, date, time, durationMin: 30, provider, room, visitType, reason, step, problemIds, createdAt: now(), createdBy: 'Front Desk Tester' });
    const visits: MedVisit[] = [
      visit('visit-e-old', 'MED-1001', addDays(T, -30), '10:00 AM', PATEL, 'Exam 1', 'Cosmetic consultation', 'Heavy upper eyelids affecting vision', 'complete', ['pr-e5']),
      visit('visit-r-old', 'MED-1004', addDays(T, -45), '02:00 PM', WHIT, 'Exam 2', 'Pre-surgical consult', 'Facelift / necklift', 'complete', ['pr-r1']),
      visit('visit-e', 'MED-1001', T, '08:30 AM', PATEL, 'Exam 1', 'Pre-surgical consult', 'Upper blepharoplasty booked at network ASC', 'scheduled', ['pr-e5', 'pr-e1', 'pr-e3']),
      visit('visit-m', 'MED-1003', T, '09:15 AM', WHIT, 'Exam 2', 'Cosmetic consultation', 'Abdominoplasty', 'scheduled'),
      visit('visit-r', 'MED-1004', T, '10:00 AM', WHIT, 'Exam 3', 'Post-op follow-up', 'Facelift / necklift, post-op day 8', 'scheduled', ['pr-r1']),
      visit('visit-p', 'MED-1005', T, '10:30 AM', ORTIZ, 'Procedure room', 'Injectables / filler', 'Neuromodulator, forehead and glabella', 'scheduled'),
      visit('visit-g', 'MED-1006', T, '11:15 AM', PATEL, 'Exam 1', 'Skin check', 'Spot on left cheek', 'scheduled'),
      visit('visit-t', 'MED-1007', T, '01:00 PM', PATEL, 'Exam 2', 'Cosmetic consultation', 'Rhinoplasty', 'scheduled'),
      visit('visit-e-next', 'MED-1001', addDays(T, 19), '09:00 AM', PATEL, 'Exam 1', 'Post-op follow-up', 'One week after blepharoplasty', 'scheduled', ['pr-e5']),
    ];
    visits.forEach(v => medRepo.saveVisit(v));
    const signedNote = (visitId: string, by: string, daysAgo: number, s: string, a: string, p: string): VisitNote => ({ visitId, template: 'Consultation', subjective: s, objective: 'See vitals recorded at rooming.', assessment: a, plan: p, status: 'signed', updatedAt: at(addDays(T, -daysAgo), '10:40'), updatedBy: by, signedBy: by, signedAt: at(addDays(T, -daysAgo), '10:45'), contentHash: 'seed', addenda: [] });
    medRepo.saveNote(signedNote('visit-e-old', PATEL, 30, '[Fictional] Patient reports upper eyelid heaviness. Daughter present.', '[Fictional] Dermatochalasis, upper lids.', '[Fictional] Discussed upper blepharoplasty. Visual field testing ordered. Will coordinate with cardiology about clopidogrel; surgeon to decide.'));
    medRepo.saveNote(signedNote('visit-r-old', WHIT, 45, '[Fictional] Interested in facelift / necklift.', '[Fictional] Facial aging; on apixaban for atrial fibrillation.', '[Fictional] Booked at network ASC. Anticoagulation plan to be coordinated with cardiology; surgeon to decide.'));
    ['visit-e-old', 'visit-r-old'].forEach(v => ['check-in', 'rooming', 'provider', 'checkout'].forEach(st => repo.setStationVerification(v, st, { by: 'Seed data', role: 'Staff', at: now() })));

    const nc = (id: string, daysFromNow: number, time: string, surgeon: string, patientName: string, dob: string, procedure: string, room: string, status: string, durationMin = 120): NetworkCase =>
      ({ id, source: 'fictional-seed', ascName: '', date: addDays(T, daysFromNow), time, durationMin, surgeon, patientName, dob, procedure, room, status });
    localStorage.setItem('vityls:med:network-seed', JSON.stringify([
      nc('net-seed-1', 12, '07:30 AM', PATEL, 'Ellen Testwood', '04/18/1954', 'Bilateral upper blepharoplasty', 'OR 2', 'Booked'),
      nc('net-seed-2', -8, '08:00 AM', WHIT, 'Robert Fictus', '01/27/1965', 'Facelift / necklift', 'OR 1', 'Completed', 240),
      nc('net-seed-3', 21, '09:00 AM', WHIT, 'Marisol Sampleton', '09/02/1980', 'Abdominoplasty', 'OR 1', 'Booking requested', 180),
      nc('net-seed-4', 0, '02:00 PM', PATEL, 'Avery Networkcase', '08/08/1985', 'Breast augmentation (network-only patient)', 'OR 2', 'Booked'),
      nc('net-seed-5', 5, '11:00 AM', PATEL, 'Jordan Unlinkedson', '02/14/1990', 'Rhinoplasty (no office chart)', 'OR 3', 'Booked'),
    ]));
    if (!networkRepo.thread('net-seed-1').length) networkRepo.post({ id: 'nm-seed-1', caseId: 'net-seed-1', at: at(addDays(T, -2), '14:10'), fromOrg: 'asc', author: 'ASC pre-admission nurse (fictional)', role: 'ASC staff', text: 'Hello Dr. Patel’s office. We have Ms. Testwood booked for bilateral upper blepharoplasty. Could you share the office pre-surgical note and medication list when ready? (Fictional seed message)', simulatedReply: true });
    opts.after?.();
  } catch (e) { console.warn('MED seed failed', e); }
}
