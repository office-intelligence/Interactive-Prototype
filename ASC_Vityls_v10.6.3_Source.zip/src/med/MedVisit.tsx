/*
 * MED office visit, check-in through checkout (Phase 1).
 * Steps: Check-in → Rooming / vitals → Provider visit → Checkout → Visit record. Visit timestamps reuse the shared
 * event bar. Forms come from My Forms (same smart-form engine and PIN signing as ASC). The note is signed with a
 * provider PIN; Nightingale never signs or orders. PDF only on demand (Print / Save as PDF), never automatic.
 */
import React, { useState } from 'react';
import { ArrowLeft, CheckCircle2, Mic, Printer, FileSignature, ClipboardList } from 'lucide-react';
import { Btn, DialogShell, AllergyStatus } from '../v7/ui';
import { repo } from '../v6/dataLayer';
import { EventBar } from '../v6/EventBar';
import { FormPage } from '../v6/FormPage';
import { stationPlan } from '../v7/myForms';
import { VITYLS_FORM_CATALOG, WorkflowKey } from '../data/formWorkspaceCatalog';
import { effectiveAllergy, parseAllergyList } from '../v7/allergy';
import { getProviders, displayName } from '../v7/providers';
import { voiceConfig } from '../v6/voice';
import { verifyProviderPin } from '../v7/SimulatedRx';
import { medRepo, MedVisit, MedPatient, VISIT_STEPS, VisitStep, Vitals, VisitNote, IntakeAnswer, IntakeKey, Problem, CONDITION_TYPES, ConditionType, patientKey, uid, bmiFrom, visitAsCase, vitalsText, usDate, ageFrom, fmtDateTime, fmtDate, addDays, isoDay, isHuman } from './record';
import { RiskPanel } from './RiskPanel';
import { MedInvoicePanel } from './MedBilling';
import { Card, Chip, Empty, ActingAs, useActor, useMedTick, printHtml, esc } from './ui';

export const VISIT_EVENTS = [{ id: 'visit.arrived', label: 'Arrived' }, { id: 'visit.checkedIn', label: 'Checked in' }, { id: 'visit.roomed', label: 'Roomed' }, { id: 'visit.providerIn', label: 'Provider in' }, { id: 'visit.providerOut', label: 'Provider out' }, { id: 'visit.checkedOut', label: 'Checked out' }];
const STEP_KEY: Record<string, WorkflowKey | null> = { 'check-in': 'frontOffice', rooming: 'nursing', provider: 'surgeon', checkout: null };
const NEXT: Record<string, VisitStep> = { 'check-in': 'rooming', rooming: 'provider', provider: 'checkout', checkout: 'complete' };
const TEMPLATES: Record<string, { s: string; o: string; a: string; p: string }> = {
  'Cosmetic consultation': { s: 'Concerns and goals:\nPrior procedures:\n', o: '', a: 'Candidacy discussion:\n', p: 'Options discussed:\nPhotos (consent on file?):\nQuote / next steps:\n' },
  'Pre-surgical consult': { s: 'Planned procedure:\nInterval history since consultation:\n', o: '', a: 'Surgical risk factors reviewed (see Risk awareness panel):\n', p: 'Pre-operative instructions:\nMedication instructions (surgeon decision):\nCoordination with network ASC:\n' },
  'Post-op follow-up': { s: 'Procedure and date:\nPain / concerns:\n', o: 'Incision / site:\n', a: 'Post-operative course:\n', p: 'Wound care:\nActivity:\nNext follow-up:\n' },
  'Injectables / filler': { s: 'Areas treated before / today:\n', o: 'Pre-treatment assessment:\n', a: '', p: 'Product, lot and units/volume:\nAftercare given:\n' },
  'Skin check': { s: 'Lesion(s) of concern:\n', o: 'Location, size, appearance:\n', a: '', p: 'Biopsy / removal / monitor:\n' },
  'Established patient visit': { s: '', o: '', a: '', p: '' },
};
const INTAKE_Q: { key: IntakeKey; q: string; opts: string[] }[] = [
  { key: 'smoking', q: 'Tobacco / nicotine use', opts: ['Never', 'Former', 'Current'] },
  { key: 'priorAnesthesiaProblems', q: 'Ever had a problem with anesthesia?', opts: ['No', 'Yes', 'Unknown'] },
  { key: 'malignantHyperthermia', q: 'You or a blood relative ever had malignant hyperthermia?', opts: ['No', 'Yes', 'Unknown'] },
  { key: 'bleedingHistory', q: 'Bleeding problems or bruise easily?', opts: ['No', 'Yes', 'Unknown'] },
  { key: 'bloodClots', q: 'Ever had a blood clot (DVT/PE)?', opts: ['No', 'Yes', 'Unknown'] },
  { key: 'sleepApnea', q: 'Sleep apnea?', opts: ['No', 'Yes', 'Unknown'] },
  { key: 'pregnancy', q: 'Could you be pregnant? (if applicable)', opts: ['No', 'Possible', 'Yes', 'Not applicable'] },
];
const hash = (s: string) => { let h = 5381; for (const c of s) h = ((h << 5) + h + c.charCodeAt(0)) >>> 0; return h.toString(16); };

export function advanceVisit(v: MedVisit, step: string, by: string, role: string) {
  repo.setStationVerification(v.id, step, { by, role, at: new Date().toISOString() });
  const next = NEXT[step] || v.step; const order = ['scheduled', 'check-in', 'rooming', 'provider', 'checkout', 'complete'];
  medRepo.saveVisit({ ...v, step: order.indexOf(next) > order.indexOf(v.step) ? next : v.step });
  repo.audit({ caseId: v.id, user: by, role, action: 'station.verify', detail: `${VISIT_STEPS.find(s => s.id === step)?.label} verified` });
}
function stamp(v: MedVisit, id: string, label: string) {
  const f = repo.getFacts(v.id); if (f[id]?.value) return; const a = repo.getActor(); const d = new Date(); const val = `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
  repo.putFacts(v.id, [{ concept: id, value: val, source: { kind: 'event', label: `Visit timestamps · ${label}`, formTitle: 'Visit timestamps', by: a.name, at: d.toISOString() } }]);
  repo.audit({ caseId: v.id, user: a.name, role: a.role, action: 'event.time', detail: `${label} = ${val}` });
}

export const MedVisitWorkspace: React.FC<{ visitId: string; onBack: () => void; onOpenChart: (pid: string, s?: string) => void; onToast: (m: string) => void }> = ({ visitId, onBack, onOpenChart, onToast }) => {
  useMedTick(); const [actor] = useActor();
  const v = medRepo.visit(visitId); const p = v ? medRepo.patient(v.patientId) : undefined;
  const initial = v && v.step !== 'scheduled' && v.step !== 'complete' ? v.step : v?.step === 'complete' ? 'record' : 'check-in';
  const [step, setStep] = useState<string>(initial);
  if (!v || !p) return <Empty>Visit not found.</Empty>;
  const ver = repo.getStationVerification(v.id);
  const verify = (s: string) => {
    if (s === 'check-in') { stamp(v, 'visit.arrived', 'Arrived'); stamp(v, 'visit.checkedIn', 'Checked in'); }
    if (s === 'rooming') stamp(v, 'visit.roomed', 'Roomed');
    if (s === 'provider') stamp(v, 'visit.providerOut', 'Provider out');
    if (s === 'checkout') stamp(v, 'visit.checkedOut', 'Checked out');
    advanceVisit(medRepo.visit(v.id)!, s, actor.name, actor.role); onToast(`${VISIT_STEPS.find(x => x.id === s)?.label} verified by ${actor.name}.`);
    setStep(s === 'checkout' ? 'record' : NEXT[s]);
  };
  const tabs = [...VISIT_STEPS.map(s => ({ id: s.id as string, label: s.label })), { id: 'record', label: 'Visit record' }];
  return <div className="space-y-3" data-testid="med-visit">
    <div className="vy-page-header"><div className="min-w-0"><div className="vy-page-kicker">Office visit · {v.visitType}</div><div className="vy-page-title">{p.name} <span className="font-normal text-[16px]">· {ageFrom(p.dob)} y · DOB {p.dob}</span></div><div className="vy-page-sub">{usDate(v.date)} {v.time} · {v.provider} · {v.room}{v.reason ? ` · ${v.reason}` : ''}</div></div>
      <div className="flex gap-2 flex-wrap"><Btn onClick={onBack} icon={<ArrowLeft />}>Back</Btn><Btn onClick={() => onOpenChart(p.id)}>Open chart</Btn></div></div>
    <div className="flex flex-wrap gap-2 items-center justify-between"><AllergyStatus allergies={p.allergies} patientId={patientKey(p.id)} compact testId="visit-allergy" /><ActingAs /></div>
    <div className="flex gap-1 overflow-x-auto bg-white border border-[#dfe5e1] rounded-xl p-1" role="tablist">{tabs.map(t => <button key={t.id} type="button" role="tab" aria-selected={step === t.id} onClick={() => setStep(t.id)} data-testid={`visit-tab-${t.id}`} className={`flex-1 min-w-[120px] px-3 py-2.5 rounded-lg text-[15px] font-semibold flex items-center justify-center gap-1.5 ${step === t.id ? 'bg-[#1f6e52] text-white' : 'text-[#26332c] hover:bg-[#f2f5f3]'}`}>{ver[t.id] && <CheckCircle2 size={16} />}{t.label}</button>)}</div>
    <EventBar caseId={v.id} events={VISIT_EVENTS} title="Visit timestamps" />
    {step === 'check-in' && <CheckIn v={v} p={p} />}
    {step === 'rooming' && <Rooming v={v} p={p} onToast={onToast} />}
    {step === 'provider' && <ProviderVisit v={v} p={p} onToast={onToast} onOpenChart={onOpenChart} />}
    {step === 'checkout' && <Checkout v={v} p={p} onToast={onToast} />}
    {step === 'record' && <VisitRecord v={v} p={p} />}
    {step !== 'record' && <div className="vy-card p-4 flex flex-wrap items-center justify-between gap-3"><div className="text-[14.5px]">{ver[step] ? <span className="text-[#14532f] font-semibold">Verified by {ver[step].by} · {fmtDateTime(ver[step].at)}</span> : <span>When this step is done, verify it. Your name and the time are recorded.</span>}</div><Btn variant="confirm" icon={<CheckCircle2 />} onClick={() => verify(step)} data-testid={`verify-${step}`}>{ver[step] ? 'Verify again' : `Verify ${VISIT_STEPS.find(x => x.id === step)?.label}`}</Btn></div>}
  </div>;
};

const StepForms: React.FC<{ v: MedVisit; step: string }> = ({ v, step }) => {
  useMedTick(); const key = STEP_KEY[step]; const [open, setOpen] = useState<string | null>(null);
  if (!key) return null;
  const plan = stationPlan(key); const extra = step === 'check-in' ? stationPlan('patientPortal') : { required: [], asNeeded: [] };
  const files = Array.from(new Set([...plan.required, ...plan.asNeeded, ...extra.required, ...extra.asNeeded]));
  const item = (f: string) => VITYLS_FORM_CATALOG.find(x => x.file === f) || { title: f.replace(/\.html$/, '').replace(/_/g, ' '), file: f, category: 'Form', stage: '' };
  const caseLike = visitAsCase(v);
  if (open) return <FormPage patient={caseLike} form={item(open)} station={key} onClose={() => setOpen(null)} />;
  return <Card kicker="Forms for this step" title="From My Forms" testId={`step-forms-${step}`}>{files.length === 0 ? <Empty>No forms assigned to this step. Practice &gt; Forms & Workflow.</Empty> :
    <ul className="divide-y divide-[#e7ece9]">{files.map(f => { const r = repo.getForm(v.id, f); const req = [...plan.required, ...extra.required].includes(f); return <li key={f} className="py-2 flex items-center justify-between gap-2"><div><div className="font-semibold text-[15px]">{item(f).title}</div><div className="text-[13px] text-[#5f6862]">{req ? 'Required' : 'As needed'} · {r.status === 'locked' ? 'Signed' : r.status === 'partially-signed' ? 'Partly signed' : r.status === 'draft' ? 'Draft' : 'Not started'}</div></div><Btn onClick={() => setOpen(f)} data-testid={`open-${f}`}>{r.status === 'not-started' ? 'Open' : 'Continue'}</Btn></li>; })}</ul>}</Card>;
};

const CheckIn: React.FC<{ v: MedVisit; p: MedPatient }> = ({ v, p }) => {
  const nc = repo.getFacts(v.id);
  return <div className="grid lg:grid-cols-2 gap-3">
    <Card kicker="Check-in" title="Confirm who the patient is" testId="checkin-demo">
      <dl className="grid grid-cols-[140px_1fr] gap-y-1.5 text-[15px]"><dt className="text-[#5f6862]">Name</dt><dd>{p.name}</dd><dt className="text-[#5f6862]">Date of birth</dt><dd>{p.dob}</dd><dt className="text-[#5f6862]">Phone</dt><dd>{p.phone}</dd><dt className="text-[#5f6862]">Email</dt><dd>{p.email || '—'}</dd><dt className="text-[#5f6862]">Language</dt><dd>{p.language}</dd><dt className="text-[#5f6862]">Emergency contact</dt><dd>{p.emergencyContact || 'Not recorded'}</dd></dl>
      <p className="text-[13.5px] text-[#5f6862] mt-2">Changes to demographics are made on the forms (Patient Registration). {nc['visit.arrived'] ? `Arrived ${nc['visit.arrived'].value}.` : 'Tap “Arrived” in the timestamps bar when the patient arrives.'}</p>
    </Card>
    <StepForms v={v} step="check-in" />
  </div>;
};

const Rooming: React.FC<{ v: MedVisit; p: MedPatient; onToast: (m: string) => void }> = ({ v, p, onToast }) => {
  useMedTick(); const [actor] = useActor();
  const last = medRepo.vitals(p.id).filter(x => x.visitId !== v.id).slice(-1)[0]; const mine = medRepo.vitals(p.id).filter(x => x.visitId === v.id).slice(-1)[0];
  const [f, setF] = useState<Record<string, string>>({ bpSys: '', bpDia: '', hr: '', rr: '', spo2: '', tempF: '', heightIn: last?.heightIn ? String(last.heightIn) : '', weightLb: '' });
  const [voice, setVoice] = useState(''); const [sugg, setSugg] = useState<Record<string, string> | null>(null);
  const bmi = bmiFrom(+f.heightIn || undefined, +f.weightLb || undefined);
  const saveVitals = () => {
    const num = (k: string) => f[k].trim() ? +f[k] : undefined;
    if (!['bpSys', 'bpDia', 'hr', 'weightLb'].some(k => f[k].trim())) { onToast('Enter at least one vital sign.'); return; }
    const rec: Vitals = { id: uid('vit'), patientId: p.id, visitId: v.id, at: new Date().toISOString(), by: actor.name, source: sugg ? 'simulated-voice' : 'manual', bpSys: num('bpSys'), bpDia: num('bpDia'), hr: num('hr'), rr: num('rr'), spo2: num('spo2'), tempF: num('tempF'), heightIn: num('heightIn'), weightLb: num('weightLb'), bmi };
    medRepo.addVitals(rec); onToast('Vitals saved.'); setSugg(null);
  };
  const listen = async () => {
    await voiceConfig.transcriber.start(); const t = await voiceConfig.transcriber.stop(voice || 'Blood pressure 128 over 82, pulse 72, oxygen 98 percent, temperature 98.4, weight 168 pounds');
    const s = t.text; const out: Record<string, string> = {};
    const bp = s.match(/(\d{2,3})\s*(?:over|\/)\s*(\d{2,3})/i); if (bp) { out.bpSys = bp[1]; out.bpDia = bp[2]; }
    const hr = s.match(/(?:pulse|heart rate|hr)\s*(?:is|of)?\s*(\d{2,3})/i); if (hr) out.hr = hr[1];
    const sp = s.match(/(?:oxygen|sat(?:uration)?s?|spo2)\s*(?:is|of)?\s*(\d{2,3})/i); if (sp) out.spo2 = sp[1];
    const tp = s.match(/(?:temp(?:erature)?)\s*(?:is|of)?\s*(\d{2,3}(?:\.\d)?)/i); if (tp) out.tempF = tp[1];
    const wt = s.match(/(?:weight|weighs)\s*(?:is|of)?\s*(\d{2,3})/i); if (wt) out.weightLb = wt[1];
    const rr = s.match(/(?:resp(?:irations?|iratory rate)?|rr)\s*(?:is|of)?\s*(\d{1,2})/i); if (rr) out.rr = rr[1];
    setVoice(s); setSugg(out);
    repo.audit({ caseId: v.id, user: actor.name, role: actor.role, action: 'voice.suggest', detail: `Simulated voice (local, nothing left the device): ${Object.entries(out).map(([k, x]) => `${k} ${x}`).join(', ') || 'nothing recognized'}` });
  };
  return <div className="grid xl:grid-cols-2 gap-3">
    <Card kicker="Rooming" title="Vitals" testId="rooming-vitals" right={mine && <Chip tone="ok">Saved {fmtDateTime(mine.at)}</Chip>}>
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">{([['bpSys', 'BP systolic'], ['bpDia', 'BP diastolic'], ['hr', 'Pulse'], ['rr', 'Resp. rate'], ['spo2', 'SpO₂ %'], ['tempF', 'Temp °F'], ['heightIn', 'Height in'], ['weightLb', 'Weight lb']] as const).map(([k, l]) => <label key={k}><span className="vy-label">{l}</span><input className={`vy-input ${sugg?.[k] ? '!border-[#0f766e] !bg-[#f2fbfa]' : ''}`} inputMode="decimal" value={f[k]} onChange={e => setF({ ...f, [k]: e.target.value.replace(/[^\d.]/g, '') })} data-testid={`vital-${k}`} /></label>)}</div>
      <div className="mt-2 text-[14.5px]">BMI (calculated): <b data-testid="bmi-calc">{bmi ?? '—'}</b> <span className="text-[13px] text-[#5f6862]">No BMI threshold is built in; flags only if the practice configures one.</span></div>
      {last && <p className="text-[13.5px] text-[#5f6862] mt-1">Last visit: {vitalsText(last)} ({fmtDate(last.at)})</p>}
      <div className="mt-3 border-t border-[#e7ece9] pt-3"><div className="vy-section-title flex items-center gap-2"><Mic size={15} />Simulated voice (nothing leaves this device)</div>
        <textarea className="vy-input !min-h-[60px]" placeholder="Type what would be said, e.g. “Blood pressure 128 over 82, pulse 72…” or leave blank for a sample" value={voice} onChange={e => setVoice(e.target.value)} />
        <div className="flex gap-2 mt-2 flex-wrap"><Btn onClick={listen} icon={<Mic />} data-testid="voice-listen">Listen (simulated)</Btn>{sugg && Object.keys(sugg).length > 0 && <Btn variant="confirm" onClick={() => { setF({ ...f, ...sugg }); repo.audit({ caseId: v.id, user: actor.name, role: actor.role, action: 'voice.accept', detail: 'Accepted simulated voice vitals' }); }} data-testid="voice-accept">Accept {Object.keys(sugg).length} suggestion{Object.keys(sugg).length === 1 ? '' : 's'}</Btn>}{sugg && <span className="text-[13.5px] self-center">{Object.entries(sugg).map(([k, x]) => `${k}: ${x}`).join(' · ') || 'Nothing recognized.'}</span>}</div></div>
      <Btn variant="primary" className="mt-3" onClick={saveVitals} data-testid="save-vitals">Save vitals</Btn>
    </Card>
    <AllergyCard p={p} />
    <MedRecCard v={v} p={p} />
    <IntakeCard p={p} />
    <StepForms v={v} step="rooming" />
  </div>;
};

export const AllergyCard: React.FC<{ p: MedPatient }> = ({ p }) => {
  useMedTick(); const [actor] = useActor(); const [edit, setEdit] = useState(false); const [txt, setTxt] = useState('');
  const a = effectiveAllergy(p.allergies, patientKey(p.id));
  const confirm = () => { const list = a.rawList.length ? a.rawList : a.state === 'nkda' ? ['NKDA'] : []; if (!list.length) return; medRepo.savePatient({ ...medRepo.patient(p.id)!, allergies: list, allergiesConfirmedAt: new Date().toISOString(), allergiesConfirmedBy: actor.name }); repo.audit({ caseId: patientKey(p.id), user: actor.name, role: actor.role, action: 'allergy.confirm', detail: `Allergies confirmed: ${list.join(', ')}` }); };
  const save = () => { const list = parseAllergyList(txt); medRepo.savePatient({ ...medRepo.patient(p.id)!, allergies: list, allergiesConfirmedAt: new Date().toISOString(), allergiesConfirmedBy: actor.name }); repo.audit({ caseId: patientKey(p.id), user: actor.name, role: actor.role, action: 'fact.edit', detail: `Allergies edited: ${a.text} → ${list.join(', ') || 'Not Reported'}` }); setEdit(false); };
  return <Card kicker="Allergies" title="Confirm with the patient" testId="allergy-card">
    <AllergyStatus allergies={p.allergies} patientId={patientKey(p.id)} />
    {p.allergiesConfirmedAt && !a.pendingConfirm && <p className="text-[13px] text-[#5f6862] mt-1">Last confirmed by {p.allergiesConfirmedBy} on {fmtDate(p.allergiesConfirmedAt)}</p>}
    {edit ? <div className="mt-2 flex gap-2 flex-wrap"><input className="vy-input flex-1" placeholder="e.g. Penicillin (hives); or NKDA" value={txt} onChange={e => setTxt(e.target.value)} data-testid="allergy-edit-input" /><Btn variant="primary" onClick={save}>Save</Btn><Btn onClick={() => setEdit(false)}>Cancel</Btn></div>
      : <div className="mt-2 flex gap-2"><Btn variant="confirm" onClick={confirm} disabled={a.state === 'not-reported'} data-testid="allergy-confirm">Confirm</Btn><Btn variant="edit" onClick={() => { setTxt(a.state === 'nkda' ? 'NKDA' : a.items.join('; ')); setEdit(true); }} data-testid="allergy-edit">Edit</Btn></div>}
  </Card>;
};

export const MedRecCard: React.FC<{ v?: MedVisit; p: MedPatient }> = ({ v, p }) => {
  useMedTick(); const [actor] = useActor(); const meds = medRepo.meds(p.id).filter(m => m.status === 'active');
  const [out, setOut] = useState<Record<string, string>>({}); const [add, setAdd] = useState({ name: '', dose: '', frequency: '' });
  const done = v ? repo.getAudit(v.id).some(a => a.action === 'med.reconcile') : false;
  const save = () => {
    meds.forEach(m => { const o = out[m.id]; if (o === 'stopped') medRepo.saveMed({ ...m, status: 'stopped', stoppedAt: new Date().toISOString() }, actor.name); });
    repo.audit({ caseId: v ? v.id : patientKey(p.id), user: actor.name, role: actor.role, action: 'med.reconcile', detail: meds.map(m => `${m.name}: ${out[m.id] || 'continuing'}`).join('; ') || 'No active medications' });
    setOut({});
  };
  const addMed = () => { if (!add.name.trim()) return; medRepo.saveMed({ id: uid('med'), patientId: p.id, name: add.name.trim(), dose: add.dose.trim(), frequency: add.frequency.trim(), status: 'active', problemIds: [], source: 'Patient-reported at rooming', recordedAt: new Date().toISOString(), recordedBy: actor.name }, actor.name, 'med.add'); setAdd({ name: '', dose: '', frequency: '' }); };
  return <Card kicker="Medications" title="Reconcile with the patient" testId="medrec-card" right={done && <Chip tone="ok">Reconciled this visit</Chip>}>
    {meds.length === 0 ? <Empty>No active medications recorded.</Empty> : <ul className="divide-y divide-[#e7ece9]">{meds.map(m => <li key={m.id} className="py-2 flex flex-wrap items-center justify-between gap-2"><div><div className="font-semibold text-[15px]">{m.name} {m.dose}</div><div className="text-[13px] text-[#5f6862]">{m.frequency} · {m.source}</div></div>
      <div className="flex gap-1">{['continuing', 'stopped', 'changed'].map(o => <button key={o} type="button" onClick={() => setOut({ ...out, [m.id]: o })} className={`px-3 min-h-[40px] rounded-lg border text-[14px] font-semibold ${(out[m.id] || 'continuing') === o ? 'bg-[#1f6e52] text-white border-[#1f6e52]' : 'bg-white border-[#b9c5be]'}`}>{o === 'continuing' ? 'Still taking' : o === 'stopped' ? 'Stopped' : 'Changed'}</button>)}</div></li>)}</ul>}
    <div className="grid grid-cols-3 gap-2 mt-2"><input className="vy-input" placeholder="Add medication" value={add.name} onChange={e => setAdd({ ...add, name: e.target.value })} data-testid="add-med-name" /><input className="vy-input" placeholder="Dose" value={add.dose} onChange={e => setAdd({ ...add, dose: e.target.value })} /><input className="vy-input" placeholder="How often" value={add.frequency} onChange={e => setAdd({ ...add, frequency: e.target.value })} /></div>
    <div className="flex gap-2 mt-2"><Btn variant="add" onClick={addMed} data-testid="add-med">Add</Btn><Btn variant="confirm" onClick={save} data-testid="save-medrec">Save reconciliation</Btn></div>
    <p className="text-[12.5px] text-[#5f6862] mt-1">“Changed” is noted in the audit; edit the dose in the chart’s Medications tab.</p>
  </Card>;
};

export const IntakeCard: React.FC<{ p: MedPatient }> = ({ p }) => {
  useMedTick(); const [actor] = useActor(); const cur = medRepo.intake(p.id);
  const [ans, setAns] = useState<Record<string, { value: string; detail: string }>>(() => Object.fromEntries(INTAKE_Q.map(q => { const c = cur.find(x => x.key === q.key); return [q.key, { value: c?.value || '', detail: c?.detail || '' }]; })));
  const save = () => { const now = new Date().toISOString(); const list: IntakeAnswer[] = INTAKE_Q.filter(q => ans[q.key].value).map(q => ({ key: q.key, value: ans[q.key].value, detail: ans[q.key].detail || undefined, recordedAt: now, source: `Rooming review with patient (${actor.name})` })); medRepo.saveIntake(p.id, list, actor.name); };
  return <Card kicker="Intake · surgical history" title="Review with the patient" testId="intake-card">
    <div className="space-y-2">{INTAKE_Q.map(q => { const c = cur.find(x => x.key === q.key); return <div key={q.key} className="flex flex-wrap items-center gap-2 justify-between"><div className="text-[14.5px] min-w-[200px] flex-1">{q.q}{c && <div className="text-[12.5px] text-[#5f6862]">On file: {c.value}{c.detail ? ` (${c.detail})` : ''} · {c.source} · {fmtDate(c.recordedAt)}</div>}</div>
      <div className="flex gap-1">{q.opts.map(o => <button key={o} type="button" onClick={() => setAns({ ...ans, [q.key]: { ...ans[q.key], value: o } })} className={`px-2.5 min-h-[38px] rounded-lg border text-[13.5px] font-semibold ${ans[q.key].value.startsWith(o) ? 'bg-[#1f6e52] text-white border-[#1f6e52]' : 'bg-white border-[#b9c5be]'}`}>{o}</button>)}</div></div>; })}</div>
    <Btn variant="confirm" className="mt-3" onClick={save} data-testid="save-intake">Save intake review</Btn>
  </Card>;
};

const ProviderVisit: React.FC<{ v: MedVisit; p: MedPatient; onToast: (m: string) => void; onOpenChart: (pid: string, s?: string) => void }> = ({ v, p, onToast, onOpenChart }) => {
  useMedTick(); const [actor] = useActor();
  const existing = medRepo.note(v.id); const vit = medRepo.vitals(p.id).filter(x => x.visitId === v.id).slice(-1)[0];
  const tpl = TEMPLATES[v.visitType] || TEMPLATES['Established patient visit'];
  const [n, setN] = useState<VisitNote>(() => existing || { visitId: v.id, template: v.visitType, subjective: tpl.s, objective: (vit ? `Vitals: ${vitalsText(vit)}\n` : '') + tpl.o, assessment: tpl.a, plan: tpl.p, status: 'draft', updatedAt: '', updatedBy: '', addenda: [] });
  const [sign, setSign] = useState(false); const [addendum, setAddendum] = useState('');
  const signed = existing?.status === 'signed';
  const saveDraft = () => { const x = { ...n, updatedAt: new Date().toISOString(), updatedBy: actor.name }; medRepo.saveNote(x); stamp(v, 'visit.providerIn', 'Provider in'); repo.audit({ caseId: v.id, user: actor.name, role: actor.role, action: 'visit.note.save', detail: 'Visit note draft saved' }); onToast('Note draft saved.'); };
  const addAdd = () => { if (!addendum.trim() || !existing) return; medRepo.saveNote({ ...existing, addenda: [...existing.addenda, { at: new Date().toISOString(), by: actor.name, text: addendum.trim() }] }); repo.audit({ caseId: v.id, user: actor.name, role: actor.role, action: 'visit.addendum', detail: addendum.trim().slice(0, 120) }); setAddendum(''); };
  return <div className="grid xl:grid-cols-[1fr_420px] gap-3">
    <div className="space-y-3">
      <Card kicker={`Visit note · ${n.template} template`} title={signed ? `Signed by ${existing!.signedBy} · ${fmtDateTime(existing!.signedAt)}` : 'Draft'} testId="visit-note" right={signed ? <Chip tone="ok">Signed · locked</Chip> : <Chip tone="warn">Not signed</Chip>}>
        {(['subjective', 'objective', 'assessment', 'plan'] as const).map(k => <label key={k} className="block mb-2"><span className="vy-label capitalize">{k}</span><textarea className="vy-input !min-h-[84px]" value={n[k]} disabled={signed} onChange={e => setN({ ...n, [k]: e.target.value })} data-testid={`note-${k}`} /></label>)}
        {!signed ? <div className="flex gap-2 flex-wrap"><Btn onClick={saveDraft} data-testid="save-note">Save draft</Btn><Btn variant="primary" icon={<FileSignature />} onClick={() => { saveDraft(); setSign(true); }} data-testid="sign-note">Sign with PIN</Btn></div>
          : <div><div className="vy-section-title">Addenda</div>{existing!.addenda.map((a, i) => <p key={i} className="text-[14px]">{fmtDateTime(a.at)} · {a.by}: {a.text}</p>)}<div className="flex gap-2 mt-1"><input className="vy-input" placeholder="Add an addendum" value={addendum} onChange={e => setAddendum(e.target.value)} /><Btn onClick={addAdd}>Add</Btn></div></div>}
        <p className="text-[12.5px] text-[#5f6862] mt-2">Templates give headings only. Nightingale never writes clinical content into the note, signs or orders.</p>
      </Card>
      <ProblemQuickAdd p={p} v={v} />
      <StepForms v={v} step="provider" />
      <Card kicker="Care plan" title="Medications & Activities plan" right={<Btn onClick={() => onOpenChart(p.id, 'careplan')}>Open care plan</Btn>}><p className="text-[14px]">The signed care plan is what the patient (and authorized caregivers) see in the portal as their Medications &amp; Activities plan. {medRepo.carePlan(p.id)?.status === 'signed' ? `Current plan signed by ${medRepo.carePlan(p.id)!.signedBy} on ${fmtDate(medRepo.carePlan(p.id)!.signedAt)}.` : 'No signed plan yet.'}</p></Card>
    </div>
    <RiskPanel patient={p} />
    {sign && <SignNoteDialog v={v} onClose={() => setSign(false)} onSigned={() => { setSign(false); onToast('Note signed and locked.'); }} />}
  </div>;
};

const ProblemQuickAdd: React.FC<{ p: MedPatient; v?: MedVisit }> = ({ p, v }) => {
  useMedTick(); const [actor] = useActor(); const [d, setD] = useState(''); const [t, setT] = useState<ConditionType>('other');
  const list = medRepo.problems(p.id);
  const add = () => { if (!d.trim()) return; const pr: Problem = { id: uid('pr'), patientId: p.id, description: d.trim(), conditionType: t, status: 'active', recordedAt: new Date().toISOString(), recordedBy: actor.name, source: v ? `${v.visitType} ${usDate(v.date)}` : 'Chart' }; medRepo.saveProblem(pr, actor.name); if (v) medRepo.saveVisit({ ...medRepo.visit(v.id)!, problemIds: [...(medRepo.visit(v.id)!.problemIds), pr.id] }); setD(''); setT('other'); };
  return <Card kicker="Problem list" title={`${list.filter(x => x.status === 'active').length} active`} testId="problem-quick">
    <ul className="text-[14.5px] mb-2 space-y-0.5">{list.map(x => <li key={x.id} className={x.status === 'resolved' ? 'line-through text-[#5f6862]' : ''}>{x.description} <span className="text-[12.5px] text-[#5f6862]">· {CONDITION_TYPES.find(c => c.id === x.conditionType)?.label}</span></li>)}</ul>
    <div className="flex gap-2 flex-wrap"><input className="vy-input flex-1 min-w-[180px]" placeholder="Add problem" value={d} onChange={e => setD(e.target.value)} data-testid="problem-desc" /><select className="vy-input !w-auto" value={t} onChange={e => setT(e.target.value as ConditionType)} data-testid="problem-type">{CONDITION_TYPES.map(c => <option key={c.id} value={c.id}>{c.label}</option>)}</select><Btn variant="add" onClick={add} data-testid="problem-add">Add</Btn></div>
    <p className="text-[12.5px] text-[#5f6862] mt-1">Condition type drives risk awareness now and (later, switched off in v0.1) chronic-disease registries.</p>
  </Card>;
};

export const SignNoteDialog: React.FC<{ v: MedVisit; onClose: () => void; onSigned: () => void }> = ({ v, onClose, onSigned }) => {
  const [actor] = useActor(); const providers = getProviders().filter(x => x.active);
  const [who, setWho] = useState(providers.some(x => displayName(x) === actor.name) ? actor.name : providers.some(x => displayName(x) === v.provider) ? v.provider : ''); const [pin, setPin] = useState(''); const [err, setErr] = useState('');
  const go = () => {
    const e = verifyProviderPin(who, pin); if (e) { setErr(e); setPin(''); return; }
    if (!isHuman(who)) { setErr('Nightingale cannot sign.'); return; }
    const n = medRepo.note(v.id)!; const h = hash([n.subjective, n.objective, n.assessment, n.plan].join('\u241e'));
    medRepo.saveNote({ ...n, status: 'signed', signedBy: who, signedAt: new Date().toISOString(), contentHash: h });
    repo.audit({ caseId: v.id, user: who, role: 'Provider', action: 'visit.note.sign', detail: `Visit note signed with PIN · fingerprint ${h}` }); onSigned();
  };
  return <DialogShell title="Sign the visit note" subtitle="Signing locks the note. Changes after signing are addenda." icon={<FileSignature />} onClose={onClose} size="sm" testId="sign-dialog" footer={<><Btn onClick={onClose}>Cancel</Btn><Btn variant="primary" onClick={go} data-testid="sign-confirm">Sign</Btn></>}>
    <label className="block mb-2"><span className="vy-label">Signing provider</span><select className="vy-input" value={who} onChange={e => setWho(e.target.value)} data-testid="sign-who"><option value="">Choose…</option>{providers.map(x => <option key={x.id} value={displayName(x)}>{displayName(x)}</option>)}</select></label>
    <label className="block"><span className="vy-label">Signature PIN</span><input className="vy-input" type="password" inputMode="numeric" autoComplete="off" value={pin} onChange={e => setPin(e.target.value)} onKeyDown={e => { if (e.key === 'Enter') go(); }} data-testid="sign-pin" /></label>
    {err && <p className="vy-field-error mt-2">{err}</p>}
  </DialogShell>;
};

const Checkout: React.FC<{ v: MedVisit; p: MedPatient; onToast: (m: string) => void }> = ({ v, p, onToast }) => {
  useMedTick(); const [actor] = useActor(); const [rc, setRc] = useState({ when: addDays(isoDay(), 14), reason: '' });
  const setRecall = () => { if (!rc.reason.trim()) { onToast('Enter a reason for the follow-up.'); return; } medRepo.saveVisit({ ...medRepo.visit(v.id)!, recall: { when: rc.when, reason: rc.reason.trim(), by: actor.name, at: new Date().toISOString() } }); repo.audit({ caseId: v.id, user: actor.name, role: actor.role, action: 'visit.recall', detail: `Follow-up ${usDate(rc.when)}: ${rc.reason}` }); onToast('Follow-up / recall saved.'); };
  const book = () => { const nv: MedVisit = { id: uid('visit'), patientId: p.id, date: rc.when, time: '09:00 AM', durationMin: 30, provider: v.provider, room: v.room, visitType: v.visitType === 'Pre-surgical consult' ? 'Post-op follow-up' : 'Established patient visit', reason: rc.reason || 'Follow-up', step: 'scheduled', problemIds: v.problemIds, createdAt: new Date().toISOString(), createdBy: actor.name }; medRepo.saveVisit(nv); repo.audit({ caseId: nv.id, user: actor.name, role: actor.role, action: 'visit.create', detail: `Follow-up booked ${usDate(nv.date)} 09:00 AM` }); onToast(`Follow-up booked ${usDate(nv.date)} 09:00 AM (adjust on the schedule).`); };
  const avs = () => { const n = medRepo.note(v.id); const plan = medRepo.carePlan(p.id); printHtml(`After-visit summary · ${p.name}`, `<h1>After-visit summary</h1><p>${esc(p.name)} · DOB ${esc(p.dob)} · ${esc(v.visitType)} with ${esc(v.provider)} · ${usDate(v.date)}</p><h2>Plan from your visit</h2><p>${n?.status === 'signed' ? esc(n.plan).replace(/\n/g, '<br>') : '<span class="muted">The visit note is not signed yet.</span>'}</p><h2>Medications on file</h2><ul>${medRepo.meds(p.id).filter(m => m.status === 'active').map(m => `<li>${esc(m.name)} ${esc(m.dose)} ${esc(m.frequency)}</li>`).join('') || '<li>None recorded</li>'}</ul>${plan?.status === 'signed' ? `<h2>Your Medications &amp; Activities plan</h2><ul>${plan.items.map(i => `<li>${esc(i.title)}: ${esc(i.instructions)}</li>`).join('')}</ul>` : ''}${medRepo.visit(v.id)?.recall ? `<h2>Follow-up</h2><p>${usDate(medRepo.visit(v.id)!.recall!.when)}: ${esc(medRepo.visit(v.id)!.recall!.reason)}</p>` : ''}`); };
  return <div className="grid xl:grid-cols-2 gap-3">
    <Card kicker="Checkout" title="Follow-up / recall" testId="checkout-recall">{v.recall && <p className="text-[14.5px] mb-2">Saved: {usDate(v.recall.when)} · {v.recall.reason} ({v.recall.by})</p>}
      <div className="grid grid-cols-2 gap-2"><label><span className="vy-label">When</span><input type="date" className="vy-input" value={rc.when} onChange={e => setRc({ ...rc, when: e.target.value })} /></label><label><span className="vy-label">Reason</span><input className="vy-input" value={rc.reason} onChange={e => setRc({ ...rc, reason: e.target.value })} data-testid="recall-reason" /></label></div>
      <div className="flex gap-2 mt-2 flex-wrap"><Btn variant="confirm" onClick={setRecall} data-testid="save-recall">Save recall</Btn><Btn variant="add" onClick={book}>Book the follow-up visit</Btn></div></Card>
    <Card kicker="After-visit summary" title="Print or save as PDF (on demand)" testId="checkout-avs"><p className="text-[14px] mb-2">Nothing is generated automatically when the visit closes.</p><Btn icon={<Printer />} onClick={avs} data-testid="print-avs">Print / Save as PDF</Btn></Card>
    <Card kicker="Billing" title="Invoice from the practice fee schedule" className="xl:col-span-2" testId="checkout-invoice"><MedInvoicePanel visit={v} onToast={onToast} /></Card>
  </div>;
};

const VisitRecord: React.FC<{ v: MedVisit; p: MedPatient }> = ({ v, p }) => {
  useMedTick(); const ver = repo.getStationVerification(v.id); const n = medRepo.note(v.id); const facts = repo.getFacts(v.id); const audit = repo.getAudit(v.id).slice().reverse();
  return <div className="space-y-3" data-testid="visit-record">
    <div className="grid lg:grid-cols-3 gap-3">
      <Card kicker="Steps" title="Verification">{VISIT_STEPS.map(s => <p key={s.id} className="text-[14.5px]">{ver[s.id] ? '✓' : '○'} {s.label}{ver[s.id] ? ` · ${ver[s.id].by} · ${fmtDateTime(ver[s.id].at)}` : ''}</p>)}</Card>
      <Card kicker="Timestamps" title="Visit times">{VISIT_EVENTS.map(e => <p key={e.id} className="text-[14.5px]">{e.label}: {(facts[e.id]?.value as string) || '—'}</p>)}</Card>
      <Card kicker="Note" title={n?.status === 'signed' ? 'Signed' : 'Not signed'}>{n?.status === 'signed' ? <p className="text-[14.5px]">{n.signedBy} · {fmtDateTime(n.signedAt)} · fingerprint {n.contentHash}</p> : <Empty>Not signed yet.</Empty>}</Card>
    </div>
    <Card kicker="Audit trail" title={<span className="flex items-center gap-2"><ClipboardList size={18} />{audit.length} entries for this visit</span>}><div className="overflow-x-auto"><table className="vy-table"><thead><tr><th>When</th><th>Who</th><th>Action</th><th>Detail</th></tr></thead><tbody>{audit.map(a => <tr key={a.id}><td className="whitespace-nowrap">{fmtDateTime(a.at)}</td><td>{a.user}<div className="text-[12.5px] text-[#5f6862]">{a.role}</div></td><td>{a.action}</td><td>{a.detail}</td></tr>)}</tbody></table></div><p className="text-[12.5px] text-[#5f6862] mt-2">Patient-level entries (risk reviews, results, caregivers) are in the chart’s Audit tab for {p.name}.</p></Card>
  </div>;
};
export { ProblemQuickAdd };
export { StepForms, stamp, VisitRecord };
