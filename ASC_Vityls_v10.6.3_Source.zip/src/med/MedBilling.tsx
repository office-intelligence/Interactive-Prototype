/* MED billing hub content: flat practice fee schedule + visit invoices (manager override kept). Ops: visit timestamps. */
import { isSurgery } from '../edition';
import { practiceUnlocked } from '../surgery/practiceLock';
import React, { useState } from 'react';
import { Btn, CardTitle } from '../v7/ui';
import { CaseInvoicesTable } from '../v7/InvoicePanel';
import { getInvoices, recordPayment } from '../v7/billing';
import { isManagerRole } from '../v7/roles';
import { repo } from '../v6/dataLayer';
import { medRepo, MedVisit, usDate } from './record';
import { getSettings, saveSettings, FeeItem, fmtMoney } from './settings';
import { buildMedInvoice, defaultFeeLines, medInvoiceEligibility, FeeLine } from './fees';
import { Chip, Empty, useActor, useMedTick } from './ui';

export const MedFeeScheduleEditor: React.FC<{ onToast?: (m: string) => void }> = ({ onToast }) => {
  useMedTick(); const [actor] = useActor(); const s = getSettings();
  const [rows, setRows] = useState<FeeItem[]>(s.fees);
  const canEdit = isManagerRole(actor.role) || (isSurgery && practiceUnlocked());
  const save = () => { saveSettings({ ...getSettings(), fees: rows }, actor.name, actor.role, `Practice fee schedule saved (${rows.length} items)`, 'fee.schedule'); onToast?.('Practice fee schedule saved.'); };
  return <section className="vy-card p-5" data-testid="med-fee-schedule"><CardTitle kicker={isSurgery ? "Practice fee schedule" : "MED · practice fee schedule"} title="Flat fee per visit type or service" sub="Not time-based. Amounts are placeholders for testing, not pricing advice. Codes are optional and must be verified by your biller." />
    <div className="overflow-x-auto mt-3"><table className="vy-table"><thead><tr><th>Service</th><th>Default for visit type</th><th>Code (optional)</th><th>Amount</th><th>Active</th></tr></thead><tbody>{rows.map((r, i) => <tr key={r.id}>
      <td><input className="vy-input" value={r.name} disabled={!canEdit} onChange={e => setRows(rows.map((x, j) => j === i ? { ...x, name: e.target.value } : x))} /></td>
      <td className="text-[14px]">{r.visitType || '—'}</td>
      <td><input className="vy-input !w-28" value={r.code} disabled={!canEdit} onChange={e => setRows(rows.map((x, j) => j === i ? { ...x, code: e.target.value } : x))} /></td>
      <td><input className="vy-input !w-28" type="number" min={0} value={r.price} disabled={!canEdit} onChange={e => setRows(rows.map((x, j) => j === i ? { ...x, price: Math.max(0, +e.target.value) } : x))} data-testid={`fee-${r.id}`} /></td>
      <td><input type="checkbox" className="w-5 h-5" checked={r.active} disabled={!canEdit} onChange={e => setRows(rows.map((x, j) => j === i ? { ...x, active: e.target.checked } : x))} /></td></tr>)}</tbody></table></div>
    <div className="flex gap-2 mt-3 items-center flex-wrap"><Btn variant="add" disabled={!canEdit} onClick={() => setRows([...rows, { id: `fee-${Date.now()}`, name: 'New service', price: 0, code: '', active: true }])}>Add service</Btn><Btn variant="primary" disabled={!canEdit} onClick={save} data-testid="save-fees">Save fee schedule</Btn>{!canEdit && <span className="text-[13.5px] text-[#5f6862]">Managers edit the fee schedule (Acting as: Practice Manager).</span>}</div>
  </section>;
};

/** Invoice panel for one visit (used at Checkout and in the Billing hub). */
export const MedInvoicePanel: React.FC<{ visit: MedVisit; onToast?: (m: string) => void }> = ({ visit, onToast }) => {
  useMedTick(); const [actor] = useActor(); const s = getSettings();
  const [lines, setLines] = useState<FeeLine[]>(() => defaultFeeLines(visit)); const [reason, setReason] = useState(''); const [err, setErr] = useState(''); const [pay, setPay] = useState('');
  const invs = getInvoices().filter(i => i.caseId === visit.id); const elig = medInvoiceEligibility(visit); const mgr = isManagerRole(actor.role);
  const pt = medRepo.patient(visit.patientId);
  const create = () => { try { const inv = buildMedInvoice(visit, pt?.name || '', lines, actor.name, actor.role, elig.ok ? undefined : reason); onToast?.(`Invoice ${inv.number} created: ${fmtMoney(inv.total)}.`); setErr(''); } catch (e: any) { setErr(e.message); } };
  return <div className="space-y-3" data-testid="med-invoice-panel">
    {invs.map(i => <div key={i.id} className="border border-[#dfe5e1] rounded-lg p-3"><div className="flex flex-wrap gap-2 items-center justify-between"><b>{i.number}</b><span>{fmtMoney(i.total)} · paid {fmtMoney(i.paid)}</span><Chip tone={i.status === 'Paid in full' ? 'ok' : 'info'}>{i.status}</Chip></div>
      <ul className="text-[14px] mt-1">{i.lines.map((l, k) => <li key={k}>{l.label} · {l.detail} · {fmtMoney(l.amount)}</li>)}</ul>{i.override && <p className="text-[13px] text-[#6b4708] mt-1">Manager override by {i.override.by}: {i.override.reason} (before: {i.override.unmet.join('; ')})</p>}
      {i.paid < i.total && <div className="flex gap-2 mt-2"><input className="vy-input !w-36" type="number" placeholder="Amount" value={pay} onChange={e => setPay(e.target.value)} /><Btn onClick={() => { const a = +pay; if (a > 0) { recordPayment(i.id, a, actor.name); setPay(''); onToast?.('Payment recorded (simulated).'); } }}>Record payment (simulated)</Btn></div>}</div>)}
    {invs.length === 0 && <>
      <div className="text-[14px]">{elig.ok ? <Chip tone="ok">Ready to invoice</Chip> : <span><Chip tone="warn">Not ready</Chip> {elig.reasons.join('; ')}{mgr ? ' · you can issue it now with a manager override.' : ' · a manager can override.'}</span>}</div>
      <table className="vy-table"><tbody>{lines.map((l, i) => <tr key={i}><td>{l.item.name}</td><td><input type="number" min={1} className="vy-input !w-20" value={l.qty} onChange={e => setLines(lines.map((x, j) => j === i ? { ...x, qty: Math.max(1, +e.target.value) } : x))} /></td><td><input type="number" min={0} className="vy-input !w-28" value={l.amount} onChange={e => setLines(lines.map((x, j) => j === i ? { ...x, amount: Math.max(0, +e.target.value) } : x))} /></td><td><Btn variant="ghost" onClick={() => setLines(lines.filter((_, j) => j !== i))}>Remove</Btn></td></tr>)}</tbody></table>
      <select className="vy-input !w-auto" value="" onChange={e => { const f = s.fees.find(x => x.id === e.target.value); if (f) setLines([...lines, { item: f, qty: 1, amount: f.price }]); }} data-testid="add-fee-line"><option value="">Add a service from the fee schedule…</option>{s.fees.filter(f => f.active).map(f => <option key={f.id} value={f.id}>{f.name} · {fmtMoney(f.price)}</option>)}</select>
      <div className="font-semibold">Total {fmtMoney(lines.reduce((a, l) => a + l.amount * l.qty, 0))}</div>
      {!elig.ok && mgr && <label className="block"><span className="vy-label">Override reason (manager)</span><input className="vy-input" value={reason} onChange={e => setReason(e.target.value)} data-testid="override-reason" /></label>}
      <Btn variant="primary" onClick={create} disabled={!elig.ok && !mgr} data-testid="create-invoice">{elig.ok ? 'Create invoice' : 'Create invoice (manager override)'}</Btn></>}
    {err && <p className="vy-field-error">{err}</p>}
  </div>;
};

export const MedBillingInvoices: React.FC<{ onToast?: (m: string) => void }> = ({ onToast }) => {
  useMedTick(); const visits = medRepo.visits().filter(v => v.step !== 'scheduled');
  return <div className="space-y-3"><CaseInvoicesTable />
    <section className="vy-card p-5"><CardTitle kicker="Live · this browser" title={`Visits to invoice (${visits.length})`} sub="Flat practice fee schedule. Ready once the note is signed and checkout is verified; a manager can override (audited)." />
      <div className="mt-3 space-y-2">{visits.length === 0 ? <Empty>No visits started yet.</Empty> : visits.map(v => <details key={v.id} className="border border-[#dfe5e1] rounded-lg bg-white"><summary className="px-3 py-2 cursor-pointer text-[15px]"><b>{medRepo.patient(v.patientId)?.name}</b> · {v.visitType} · {usDate(v.date)}</summary><div className="p-3"><MedInvoicePanel visit={v} onToast={onToast} /></div></details>)}</div></section></div>;
};

export const MedOpsLive: React.FC = () => {
  useMedTick(); const visits = medRepo.visits().filter(v => v.step !== 'scheduled');
  const hm = (v: any) => { const m = String(v || '').match(/^(\d{2}):(\d{2})$/); return m ? +m[1] * 60 + +m[2] : null; };
  const rows = visits.map(v => { const f = repo.getFacts(v.id); const a = hm(f['visit.arrived']?.value), r = hm(f['visit.roomed']?.value), pin = hm(f['visit.providerIn']?.value), out = hm(f['visit.checkedOut']?.value); return { v, wait: a != null && r != null ? r - a : null, toProv: r != null && pin != null ? pin - r : null, total: a != null && out != null ? out - a : null }; });
  const avg = (k: 'wait' | 'toProv' | 'total') => { const x = rows.map(r => r[k]).filter((n): n is number => n != null); return x.length ? `${Math.round(x.reduce((a, b) => a + b, 0) / x.length)} min` : '—'; };
  return <div className="space-y-4" data-testid="med-ops-live"><div className="pt-2"><div className="vy-kicker">MED v0.1 · live from this browser</div><h2 className="vy-card-title">Office visit flow</h2><p className="vy-card-sub">From visit timestamps (arrived, roomed, provider in, checked out).</p></div>
    <section className="grid sm:grid-cols-4 gap-3">{[['Visits started', String(visits.length)], ['Avg arrival → roomed', avg('wait')], ['Avg roomed → provider', avg('toProv')], ['Avg total visit', avg('total')]].map(([k, v]) => <div key={k} className="vy-card p-4"><div className="vy-kicker">{k}</div><div className="text-[24px] font-bold">{v}</div></div>)}</section>
    <section className="vy-card p-5"><table className="vy-table"><thead><tr><th>Patient</th><th>Visit</th><th>Step</th><th>Arrival → roomed</th><th>Total</th></tr></thead><tbody>{rows.map(r => <tr key={r.v.id}><td>{medRepo.patient(r.v.patientId)?.name}</td><td>{r.v.visitType} · {usDate(r.v.date)}</td><td>{r.v.step}</td><td>{r.wait == null ? '—' : `${r.wait} min`}</td><td>{r.total == null ? '—' : `${r.total} min`}</td></tr>)}</tbody></table></section></div>;
};
