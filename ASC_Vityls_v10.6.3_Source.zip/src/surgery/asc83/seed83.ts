/* v8.3 · fictional seed: three cases 8–12 days out (unpaid / partial / paid) and one earlier, closed case so the chart shows previous cases. */
import { medRepo, isoDay } from '../../med/record';
import { svRead, svWrite } from '../store';
import * as A from '../asc8/logic';
import * as S from '../asc8/store';
import { collectPayment } from './pay';
const add = (d: string, n: number) => { const x = new Date(d + 'T12:00:00'); x.setDate(x.getDate() + n); return `${x.getFullYear()}-${String(x.getMonth() + 1).padStart(2, '0')}-${String(x.getDate()).padStart(2, '0')}`; };
export function ensureAsc83Seed() {
  if (svRead('asc83-seeded', false) || !S.cases().length) return; const T = isoDay(); const at = new Date().toISOString(); const done = { by: 'ASC seed', at };
  const mk = (id: string, pid: string, date: string, time: string, dur: number, room: string, surgeon: string, procedure: string, cpt: string, loc: A.Loc, d: Record<string, any>) => {
    const vid = `visit-asc83-${id}`; medRepo.saveVisit({ id: vid, patientId: pid, date, time, durationMin: dur, provider: surgeon, room, visitType: 'Surgery case', reason: procedure, step: loc === 'closed' ? 'done' : 'scheduled', problemIds: [], createdAt: at, createdBy: 'ASC seed' } as any);
    return { id, pid, visitId: vid, date, time, durationMin: dur, room, surgeon, anesthesia: S.ANES[0], procedure, cpt, loc, d, events: loc === 'closed' ? { inRoom: '08:05 AM', incision: '08:20 AM', close: '09:10 AM', outRoom: '09:20 AM' } : {}, audit: [{ at, by: 'ASC seed', role: 'System', what: 'Case scheduled (fictional)' }], from: 'ASC' } as any as A.AscCase; };
  const W = 'Dana Whitfield, MD';
  const add83 = [
    mk('c83a', 'ASC-2001', add(T, 8), '08:00 AM', 60, 'OR 2', S.PATEL, 'Excision of forearm lipoma, left', '', 'scheduled', { payType: 'Self-pay', quote: 1800 }),
    mk('c83b', 'ASC-2003', add(T, 10), '09:30 AM', 120, 'OR 1', W, 'Breast implant exchange', '', 'scheduled', { payType: 'Self-pay', quote: 6400 }),
    mk('c83c', 'ASC-2008', add(T, 12), '07:30 AM', 90, 'OR 3', S.PATEL, 'Inguinal hernia repair, left', '', 'scheduled', { payType: 'Fictional Health Plan PPO', quote: 650 }),
    mk('c83p', 'ASC-2002', add(T, -182), '08:00 AM', 75, 'OR 1', S.PATEL, 'Umbilical hernia repair', '', 'closed', { payType: 'Fictional Health Plan PPO', quote: 500, forms: done, financial: done, insurance: done, clearance: done, labs: done, id: done, adult: { name: 'Fictional escort', phone: '(555) 019-0000', present: true }, arrival: '06:40 AM', nursingForm: done, hpUpdate: done, consentConfirm: done, anesConsent: done, asa: 'II', opReport: { text: 'PROCEDURE\nUmbilical hernia repair, primary suture.\nFINDINGS\n1.5 cm fascial defect.\nEBL minimal. No complications. (Fictional.)', signedBy: S.PATEL, signedAt: at }, dischargeOrder: done, instructions: done, charges: { total: 500 } }),
  ];
  svWrite('asc8-cases', [...S.cases(), ...add83]); svWrite('asc83-seeded', true);
  collectPayment(add83[1], 1000, 'Card (simulated)', 'Deposit · Visa ••4242', 'ASC seed', 'System', 'pre-service');
  collectPayment(add83[2], 650, 'Card (simulated)', 'Visa ••4242', 'ASC seed', 'System', 'pre-service');
  collectPayment(add83[3], 500, 'Card (simulated)', 'Visa ••4242', 'ASC seed', 'System', 'check-in');
}
