/* v8.3 · FULL operative report: pure model + mobile-ready API contract (no storage, no React; node:test). Fictional. */
export type OpStatus = 'pending' | 'dictated' | 'signed';
export const OP_SECTIONS: [key: string, label: string][] = [
  ['preDx', 'Pre-operative diagnosis'], ['postDx', 'Post-operative diagnosis'], ['procedure', 'Procedure(s) performed'], ['team', 'Surgeon / assistants'],
  ['anesthesia', 'Anesthesia'], ['indications', 'Indications'], ['findings', 'Findings'], ['description', 'Detailed description of the procedure'],
  ['ebl', 'Estimated blood loss (EBL)'], ['specimens', 'Specimens'], ['implants', 'Implants'], ['drains', 'Drains'], ['complications', 'Complications'], ['disposition', 'Condition / disposition']];
export interface FullOpReport { cid: string; pid: string; surgeon: string; dos: string; procedure: string; status: OpStatus; sections: Record<string, string>; updatedAt?: string; updatedBy?: string; source?: 'web' | 'mobile'; signed?: { by: string; at: string; sigId?: string } ; version: number }
export interface OpCtx { cid: string; pid: string; surgeon: string; dos: string; procedure: string; side?: string; anesthesia?: string; assistant?: string; dx?: string }
export const blankOp = (x: OpCtx): FullOpReport => ({ cid: x.cid, pid: x.pid, surgeon: x.surgeon, dos: x.dos, procedure: x.procedure, status: 'pending', sections: {}, version: 0 });
export const missingSections = (r: FullOpReport) => OP_SECTIONS.filter(([k]) => !(r.sections[k] || '').trim()).map(([, l]) => l);
/** status is derived: signed > dictated (every section filled) > pending */
export const opStatus = (r: FullOpReport): OpStatus => r.signed ? 'signed' : missingSections(r).length === 0 ? 'dictated' : 'pending';
/** Simulated scribe: what the surgeon "said" for one section (deterministic fictional text). */
export function scribeSection(k: string, x: OpCtx): string { const proc = `${x.side ? x.side + ' ' : ''}${x.procedure}`; const dx = x.dx || `Condition requiring ${x.procedure.toLowerCase()}`;
  return ({ preDx: dx, postDx: `Same as pre-operative (${dx})`, procedure: proc, team: `Surgeon: ${x.surgeon}${x.assistant ? `; assistant: ${x.assistant}` : '; no assistant'}`, anesthesia: x.anesthesia || 'General (LMA)',
    indications: `Symptomatic despite conservative care; risks, benefits and alternatives discussed and consent signed.`, findings: `Findings consistent with the pre-operative diagnosis; no unexpected pathology.`,
    description: `Patient identified, time-out performed, site marking confirmed. ${proc} carried out in the standard fashion under ${x.anesthesia || 'anesthesia'}. Hemostasis obtained; irrigation; layered closure; sterile dressing. Sponge and needle counts correct ×2.`,
    ebl: 'Minimal (<10 mL)', specimens: 'None', implants: 'None', drains: 'None', complications: 'None', disposition: 'Stable; extubated in the OR and taken to PACU in good condition.' } as Record<string, string>)[k] || ''; }
/** Mobile/API contract (JSON). See Henry doc v8.3 for the HTTP shape. */
export interface OpListItem { cid: string; pid: string; patientName: string; dos: string; procedure: string; status: OpStatus; deepLink: string }
export const deepLink = (cid: string) => `ascvityls://op-report/${cid}`;
export interface OpSubmit { cid: string; sections: Partial<Record<string, string>>; baseVersion: number; source: 'web' | 'mobile'; by: string }
export interface OpSign { cid: string; by: string; pinVerified: boolean; signaturePng?: string; baseVersion: number }
export type ApiResult<T> = { ok: true; data: T } | { ok: false; error: 'not-found' | 'forbidden' | 'conflict' | 'locked' | 'incomplete' | 'pin-required'; detail?: string };
/** Pure transition used by both web and mobile: merge a draft submission. */
export function applySubmit(r: FullOpReport, s: OpSubmit, at: string): ApiResult<FullOpReport> {
  if (r.signed) return { ok: false, error: 'locked', detail: 'Signed reports are locked; use an addendum.' }; if (s.by !== r.surgeon) return { ok: false, error: 'forbidden' }; if (s.baseVersion !== r.version) return { ok: false, error: 'conflict', detail: `Current version ${r.version}` };
  const n: FullOpReport = { ...r, sections: { ...r.sections, ...Object.fromEntries(Object.entries(s.sections).filter(([k]) => OP_SECTIONS.some(([x]) => x === k)).map(([k, v]) => [k, String(v ?? '')])) }, updatedAt: at, updatedBy: s.by, source: s.source, version: r.version + 1 };
  return { ok: true, data: { ...n, status: opStatus(n) } }; }
export function applySign(r: FullOpReport, s: OpSign, at: string, sigId?: string): ApiResult<FullOpReport> {
  if (r.signed) return { ok: false, error: 'locked' }; if (s.by !== r.surgeon) return { ok: false, error: 'forbidden' }; if (!s.pinVerified) return { ok: false, error: 'pin-required' }; if (s.baseVersion !== r.version) return { ok: false, error: 'conflict' };
  const miss = missingSections(r); if (miss.length) return { ok: false, error: 'incomplete', detail: miss.join(', ') };
  return { ok: true, data: { ...r, signed: { by: s.by, at, sigId }, status: 'signed', version: r.version + 1 } }; }
