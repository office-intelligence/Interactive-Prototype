/* ASC.Vityls v8.3 · patient chart for an ASC (no longitudinal care): Overview, Documents (by case / date of service,
 * audit-ready, manual print/export) and Billing & payments. Surgery/Medical leftovers (clinical record, photos & charts,
 * notes, timelines, problems, risk factors, diagnoses, journey to-do) are not shown in the ASC edition. Fictional data. */
import React, { useState } from 'react';
import { medRepo, ageFrom, isoDay } from '../../med/record';
import { useMedTick } from '../../med/ui';
import { useSv } from '../ui';
import * as A from '../asc8/logic';
import * as S from '../asc8/store';
import { use81 } from '../asc81/store81';
import { XClose, FormInPlace } from '../asc82/common';
import { caseMoney, casePays, payTypeOf, PAY_LABEL } from './pay';
import { PayChip, CollectPay, cancelledCases } from './frontdesk';
import { surgeonColor } from './booking';
import { docsForCase, exportText, GROUPS, type Doc } from './docs';
import { docCategory, DOC_CATS } from '../asc89/pure89';
import { patientPayments } from '../payments';
import { PrintPacket } from '../asc86/ui86';
import { openInvoice, openUpload } from '../asc87/ui87';
import { ProfileDialog, PrintChartDialog, CreditDialog } from '../asc89/chart89';
import { availableCredit, credits } from '../asc89/store89';
import { creditLeft } from '../asc89/pure89';
import * as L8 from '../asc8/logic';
import { openAsc } from '../asc8/ui';
import * as D86 from '../asc86/store86';
import { useActor } from '../../med/ui';

const money = (n: number) => `$${n.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
const dos = (d: string) => new Date(d + 'T12:00').toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
type Tab = 'overview' | 'documents' | 'billing';
export const AscChart: React.FC<{ patientId: string }> = ({ patientId }) => {
  useMedTick(); use81(); const { setTab: goTab, go } = useSv(); void goTab; const p = medRepo.patient(patientId); const [tab, setTab] = useState<Tab>('overview');
  const cs = S.cases().filter(c => c.pid === patientId).sort((a, b) => b.date.localeCompare(a.date)); const cx = cancelledCases(patientId);
  const [sel, setSel] = useState<string>(cs[0]?.id || ''); const c = cs.find(x => x.id === sel) || cs[0];
  if (!p) return null; const meds = medRepo.meds(p.id).filter(m => m.status === 'active');
  const T = isoDay(); const upcoming = cs.filter(x => x.date >= T && x.loc !== 'closed'); const previous = cs.filter(x => !upcoming.includes(x));
  const CaseRow: React.FC<{ x: A.AscCase }> = ({ x }) => <button type="button" className={`a83-caserow ${c?.id === x.id ? 'on' : ''}`} onClick={() => setSel(x.id)} data-testid="a83-chart-case"><span className="d">{dos(x.date)}</span><span className="min-w-0 flex-1"><b>{x.procedure}</b><span className="sv-small sv-muted"> · <i className="a83-dot" style={{ background: surgeonColor(x.surgeon) }} />{x.surgeon} · {x.room}</span></span><span className="a83-st">{A.LOC_LABEL[x.loc]}</span><PayChip c={x} /></button>;
  const [dlg, setDlg] = useState<'' | 'profile' | 'print' | 'credit'>(''); const cr = availableCredit(p.id); const due = cs.reduce((n, x) => n + caseMoney(x).balance, 0);
  const nextC = upcoming.slice().sort((a, b) => a.date.localeCompare(b.date))[0]; const miss = nextC ? L8.ITEMS.filter(i => L8.actionable(nextC, i, T) && !L8.isDone(nextC, i.key)).slice(0, 5) : [];
  const jump = (id: string) => document.getElementById(id)?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  const attn: { k: string; t: string; d: string; act?: () => void; a?: string }[] = [
    ...(due > 0 ? [{ k: 'terra', t: `${money(due)} open balance`, d: 'Patient responsibility from the fee schedule', act: () => setTab('billing'), a: 'Billing' }] : []),
    ...(nextC && miss.length ? [{ k: 'amber', t: `${miss.length} open item${miss.length === 1 ? '' : 's'} for ${dos(nextC.date)}`, d: miss.map(i => i.label).join(' · '), act: () => openAsc({ t: 'step', cid: nextC.id, station: miss[0].station } as any), a: 'Open station' }] : []),
    ...(!p.allergies.length && !p.allergiesConfirmedAt ? [{ k: 'amber', t: 'Allergies not confirmed', d: 'Confirm at pre-op' }] : []),
    ...(cr > 0 ? [{ k: 'green', t: `${money(cr)} account credit available`, d: 'Applied automatically to the next invoice' }] : [])];
  return <div className="v7-page a83-chart a89-chart" data-testid="a83-chart">
    <div className="a89-crumb"><button type="button" className="sv-link sv-small a87-back" onClick={() => go({ type: 'tab', tab: 'patients' } as any)} data-testid="a87-chart-back">‹ Patients</button><span>/</span><b>{p.name}</b></div>
    <header className="a83-chead a89-hero"><div className="av">{p.name.split(' ').map(x => x[0]).slice(0, 2).join('')}</div><div className="min-w-0 flex-1"><h1 data-testid="a83-chart-name">{p.name}</h1><div className="sv-small sv-muted">{ageFrom(p.dob)} years · {p.sex} · DOB {p.dob} · MRN {p.id} · {p.language || 'English'}</div>
      <div className="a89-pills">{nextC && <span className="a89-pill dark">{A.LOC_LABEL[nextC.loc]} · {dos(nextC.date)}</span>}<span className={`a89-pill ${p.allergies.length ? 'terra' : ''}`}>{p.allergies.length ? `Allergy: ${p.allergies.join(', ')}` : 'NKDA'}</span><span className="a89-pill">{(p as any).insurance || 'Self-pay'}</span>{cr > 0 && <span className="a89-pill green" data-testid="a89-credit-chip">Credit {money(cr)}</span>}</div></div>
      <div className="a89-acts"><button type="button" className="a8-btn" onClick={() => setDlg('profile')} data-testid="a89-btn-profile">Profile</button><button type="button" className="a8-btn" onClick={() => setDlg('print')} data-testid="a89-btn-print">Print</button><button type="button" className="a8-btn pri" onClick={() => setDlg('credit')} data-testid="a89-btn-collect">Collect payment</button>{c && <button type="button" className="a8-btn" onClick={() => openUpload(c.id, c.pid)} data-testid="a89-btn-upload">Upload</button>}</div></header>
    <nav className="a89-jump">{([['a89-attn', 'Needs attention'], ['a89-snap', 'Clinical snapshot'], ['a89-tl', 'Timeline'], ['a89-docs', 'Documents & packets']] as const).map(([id, l]) => <button key={id} type="button" onClick={() => jump(id)}>{l}</button>)}</nav>
    <div className="a89-cgrid"><div className="a89-cmain">
    <section className="a89-card" id="a89-attn" data-testid="a89-attn"><h2>Needs attention</h2>{attn.length ? attn.map((x, i) => <div key={i} className={`a89-attn ${x.k}`}><i /><div className="flex-1 min-w-0"><b>{x.t}</b><div className="sv-small sv-muted">{x.d}</div></div>{x.act && <button type="button" className="a8-btn" onClick={x.act}>{x.a}</button>}</div>) : <p className="sv-small sv-muted">Nothing needs attention.</p>}</section>
    <section className="a89-card" id="a89-snap" data-testid="a89-snap"><h2>Clinical snapshot</h2><div className="a83-cfacts"><div><span>Allergies</span><b className={p.allergies.length ? 'alg' : ''}>{p.allergies.length ? p.allergies.join('; ') : 'NKDA'}</b></div><div><span>Medications ({meds.length})</span><b>{meds.map(m => `${m.name} ${m.dose}`).join(', ') || 'None'}</b></div><div><span>Payment</span><b>{(p as any).insurance || 'Self-pay'}</b></div><div><span>Contact</span><b>{p.phone} · {p.email}</b></div>{c && <><div><span>Procedure</span><b>{c.procedure}</b></div><div><span>Surgeon · Anesthesia</span><b>{c.surgeon} · {c.anesthesia}</b></div></>}</div></section>
    <section className="a89-card" id="a89-tl" data-testid="a89-timeline"><h2>Timeline</h2><ol className="a89-tl">{(c ? c.audit.slice(-8).reverse() : []).map((x, i) => <li key={i} className={/sign|complete|paid|credit/i.test(x.what) ? 'n-green' : /cancel|declin/i.test(x.what) ? 'n-terra' : /changed|correct/i.test(x.what) ? 'n-amber' : 'n-sky'}><b>{x.what}</b><span className="sv-small sv-muted">{new Date(x.at).toLocaleString('en-US', { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' })} · {x.by}</span></li>)}{!c?.audit.length && <li className="n-sky"><span className="sv-small sv-muted">No activity yet.</span></li>}</ol></section>
    <section className="a89-card" id="a89-docs"><h2>Documents &amp; packets</h2>
    <nav className="a83-tabs a89-tabs" role="tablist">{([['overview', 'Overview'], ['documents', 'Documents'], ['billing', 'Billing & payments']] as const).map(([k, l]) => <button key={k} type="button" role="tab" aria-selected={tab === k} className={tab === k ? 'on' : ''} onClick={() => setTab(k)} data-testid={`a83-chart-tab-${k}`}>{l}</button>)}</nav>
    {tab === 'overview' && <Overview pid={p.id} cs={cs} />}{tab === 'documents' && (c ? <Documents c={c} cs={cs} onPick={setSel} /> : <p className="sv-muted">No cases yet.</p>)}{tab === 'billing' && <Billing pid={p.id} cs={cs} />}</section>
    </div><aside className="a89-cside">
    <section className="a83-sec2 a89-card" data-testid="a83-chart-cases"><h2>Cases <span className="a83-badge g">{cs.length}</span></h2>
      {upcoming.length > 0 && <><h4 className="a83-h">Upcoming / today</h4>{upcoming.map(x => <CaseRow key={x.id} x={x} />)}</>}
      <h4 className="a83-h">Previous cases (date of service)</h4>{previous.length ? previous.map(x => <CaseRow key={x.id} x={x} />) : <p className="sv-small sv-muted">No previous cases at this ASC.</p>}
      {cx.length > 0 && <><h4 className="a83-h">Cancelled</h4>{cx.map((x: any) => <div key={x.id} className="a83-caserow off"><span className="d">{dos(x.date)}</span><span className="flex-1">{x.procedure}</span><span className="sv-small">Cancelled · {x.cancelled.reason}</span></div>)}</>}
      {D86.schedHistory(p.id).length > 0 && <details className="mt-2" data-testid="a86-chart-hist"><summary className="sv-small">Booking, reschedule &amp; cancellation history ({D86.schedHistory(p.id).length})</summary>{D86.schedHistory(p.id).map((h, i) => <div key={i} className="a81-line sv-small"><b>{h.kind}</b> · {new Date(h.at).toLocaleString()} · {h.by} · {h.from || h.to}{h.reason ? ` · ${h.reason}` : ''}</div>)}</details>}</section>
    {c && <section className="a89-card"><h2>Care team</h2><div className="a89-team"><div><span>Surgeon</span><b>{c.surgeon}</b></div><div><span>Anesthesia</span><b>{c.anesthesia}</b></div><div><span>Room</span><b>{c.room}</b></div></div></section>}
    <section className="a89-card" data-testid="a89-account"><h2>Account</h2><div className="a89-team"><div><span>Open balance</span><b>{money(due)}</b></div><div><span>Available credit</span><b className="g" data-testid="a89-chart-credit">{money(cr)}</b></div></div>{credits(p.id).length > 0 && <div className="sv-small sv-muted" style={{ marginTop: 6 }}>{credits(p.id).map(k => <div key={k.id}>{k.receipt} · {k.type} · {money(k.amount)} · left {money(creditLeft(k))}</div>)}</div>}<button type="button" className="a8-btn pri" style={{ marginTop: 8 }} onClick={() => setDlg('credit')}>Collect payment</button></section>
    </aside></div>
    {dlg === 'profile' && <ProfileDialog pid={p.id} onClose={() => setDlg('')} />}{dlg === 'print' && <PrintChartDialog pid={p.id} cid={c?.id} onClose={() => setDlg('')} />}{dlg === 'credit' && <CreditDialog pid={p.id} onClose={() => setDlg('')} />}
  </div>;
};
export const Overview: React.FC<{ pid: string; cs: A.AscCase[] }> = ({ pid, cs }) => { const s = use81(); const cards: Record<string, string> = Object.assign({}, ...cs.map(c => s.ai(c.id).v82?.cards || {}));
  const due = cs.reduce((n, c) => n + caseMoney(c).balance, 0); const next = cs.filter(c => c.loc === 'scheduled').sort((a, b) => a.date.localeCompare(b.date))[0];
  return <div className="a83-ov" data-testid="a83-chart-overview"><div className="a82-sec"><h3 className="a81-h3">Next case</h3>{next ? <p><b>{next.procedure}</b> · {dos(next.date)} {next.time.replace(/^0/, '')} · {next.surgeon} · {next.room}</p> : <p className="sv-muted">Nothing scheduled.</p>}</div>
    <div className="a82-sec"><h3 className="a81-h3">Account</h3><p className={due ? 'a81-warn' : 'a81-ok'} data-testid="a83-chart-due">{due ? `${money(due)} open across cases` : 'No balance due'}</p></div>
    <div className="a82-sec"><h3 className="a81-h3">ID &amp; insurance cards</h3>{Object.keys(cards).filter(k => cards[k]).length ? <div className="a83-thumbs">{Object.entries(cards).filter(([, v]) => v).map(([k, v]) => <img key={k} src={v} alt={k} />)}</div> : <p className="sv-small sv-muted">No card images yet; captured at check-in.</p>}</div></div>; };

export const Documents: React.FC<{ c: A.AscCase; cs: A.AscCase[]; onPick: (id: string) => void }> = ({ c, cs, onPick }) => {
  const [actor] = useActor(); const [cat, setCat] = useState<string>('All'); const all = docsForCase(c); const docs = cat === 'All' ? all : all.filter(d => docCategory(d) === cat); const [view, setView] = useState<Doc | null>(null); const [form, setForm] = useState(''); const [printing, setPrinting] = useState(false);
  const exp = () => { const b = new Blob([exportText(c, docs)], { type: 'text/plain' }); const a = document.createElement('a'); a.href = URL.createObjectURL(b); a.download = `ASC_documents_${medRepo.patient(c.pid)?.name.replace(/\W+/g, '_')}_${c.date}.txt`; a.click(); URL.revokeObjectURL(a.href); D86.logPrint(c.id, actor.name, actor.role, `Documents export (.txt) for DOS ${c.date}`, 'export'); };
  return <div data-testid="a83-chart-docs">
    {form && <FormInPlace c={c} file={form} station="frontOffice" onClose={() => setForm('')} />}
    <div className="a83-docbar"><label className="a83-f"><span className="a83-l">Date of service</span><select className="sv-input" value={c.id} onChange={e => onPick(e.target.value)} data-testid="a83-doc-dos">{cs.map(x => <option key={x.id} value={x.id}>{dos(x.date)} · {x.procedure}</option>)}</select></label>
      <span className="sv-small sv-muted" style={{ flex: 1 }}>{docs.length} documents for this date of service. Inspectors: everything for this case is here.</span>
      <button type="button" className="a8-btn pri" onClick={() => openUpload(c.id, c.pid)} data-testid="a88-chart-upload">Upload</button><button type="button" className="a8-btn" onClick={() => setPrinting(true)} data-testid="a83-doc-print">Print episode packet</button><button type="button" className="a8-btn" onClick={exp} data-testid="a83-doc-export">Export all (.txt)</button></div>
    <div className="a89-cats" role="tablist" aria-label="Document category" data-testid="a89-doc-cats">{(['All', ...DOC_CATS] as string[]).map(k => <button key={k} type="button" role="tab" aria-selected={cat === k} className={cat === k ? 'on' : ''} onClick={() => setCat(k)} data-testid={`a89-cat-${k.replace(/\W+/g, '-')}`}>{k} <span>{k === 'All' ? all.length : all.filter(d => docCategory(d) === k).length}</span></button>)}</div>
    <p className="sv-small sv-muted">Manual only: nothing is printed or exported automatically.</p>
    {GROUPS.filter(g => cat === 'All' || docs.some(d => d.group === g)).map(g => { const l = docs.filter(d => d.group === g); return <section key={g} className="a83-docgrp" data-testid="a83-doc-group" data-group={g}><h4 className="a83-h">{g} <span className="a83-badge g">{l.length}</span></h4>
      {l.length ? l.map(d => <div key={d.id} className="a83-doc" data-testid="a83-doc"><span className="min-w-0 flex-1"><span className={`a89-ctag c-${docCategory(d).replace(/\W+/g, '')}`} data-testid="a89-doc-cat">{docCategory(d)}</span> <b>{d.title}</b><span className="sv-small sv-muted">{d.status ? ` · ${d.status}` : ''}{d.by ? ` · ${d.by}` : ''}{d.date ? ` · ${d.date}` : ''}</span></span><button type="button" className="sv-link sv-small" onClick={() => d.form ? setForm(d.form) : setView(d)} data-testid="a83-doc-view">View</button></div>) : <p className="sv-small sv-muted">None for this case.</p>}</section>; })}
    {view && <div className="a81-modal a83-modal" onMouseDown={e => { if (e.target === e.currentTarget) setView(null); }}><div className="a81-dialog a83-dlg" role="dialog" aria-label={view.title} data-testid="a83-doc-viewer"><div className="a81-dhead"><b>{view.title}</b><span style={{ marginLeft: 'auto' }} /><XClose onClick={() => setView(null)} /></div><div className="a81-dbody">{view.img && <img src={view.img} alt={view.title} style={{ maxWidth: '100%' }} />}{view.text && <pre className="a81-pre">{view.text}</pre>}</div></div></div>}
    {printing && <PrintPacket c={c} onClose={() => setPrinting(false)} />}
  </div>;
};
export const Billing: React.FC<{ pid: string; cs: A.AscCase[] }> = ({ pid, cs }) => { const [open, setOpen] = useState('');
  const pays = patientPayments(pid).slice().sort((a, b) => b.at.localeCompare(a.at));
  return <div data-testid="a83-chart-billing"><section className="a82-sec"><h3 className="a81-h3">Bills by case</h3><div className="a83-scroll"><table className="sv-table"><thead><tr><th>DOS</th><th>Procedure</th><th>Payment type</th><th>Patient part</th><th>Paid</th><th>Balance</th><th>Status</th><th /></tr></thead>
    <tbody>{cs.map(c => { const m = caseMoney(c); return <React.Fragment key={c.id}><tr data-testid="a83-bill-row"><td>{dos(c.date)}</td><td>{c.procedure}</td><td>{payTypeOf(c)}</td><td>{money(m.due)}</td><td>{money(m.paid)}</td><td>{money(m.balance)}</td><td><span className={`a83-pay ${m.status}`}>{PAY_LABEL[m.status]}</span></td><td><button type="button" className="sv-link sv-small" onClick={() => openInvoice(c.id)} data-testid="a87-chart-invoice">Invoice</button>{m.balance > 0 && <button type="button" className="sv-link sv-small" style={{ marginLeft: 8 }} onClick={() => setOpen(open === c.id ? '' : c.id)} data-testid="a83-bill-collect">Collect</button>}</td></tr>
      {open === c.id && <tr><td colSpan={8}><CollectPay c={c} when="pre-service" /></td></tr>}</React.Fragment>; })}</tbody></table></div></section>
    <section className="a82-sec"><h3 className="a81-h3">Payment history</h3>{pays.length ? <div className="a83-scroll"><table className="sv-table"><thead><tr><th>Date</th><th>Receipt</th><th>For</th><th>Method</th><th>Amount</th><th>Taken by</th></tr></thead><tbody>{pays.map(x => <tr key={x.id} data-testid="a83-pay-row"><td>{new Date(x.at).toLocaleDateString('en-US')}</td><td>{x.receipt}</td><td>{x.reason}</td><td>{x.reference || x.method}</td><td>{money(x.amount)}</td><td>{x.takenBy}</td></tr>)}</tbody></table></div> : <p className="sv-small sv-muted">No payments yet.</p>}</section></div>; };
