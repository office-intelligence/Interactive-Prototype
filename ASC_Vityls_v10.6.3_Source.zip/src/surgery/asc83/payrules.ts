/* v8.3 · pure payment rules (node:test). Patient responsibility estimate, case pay status, the 7–14 day collection window. Fictional amounts. */
export type PayStatus = 'paid' | 'partial' | 'unpaid' | 'none';
export const isSelfPay = (payType: string) => /self|cash|cosmetic/i.test(payType || '');
/** Facility fee (fee schedule base for the CPT, else $2,500 fictional) → patient part: self-pay 100%, insurance 20% coinsurance estimate. */
export function estimateDue(feeBase: number | undefined, payType: string): number { const fee = feeBase && feeBase > 0 ? feeBase : 2500; return Math.round((isSelfPay(payType) ? fee : fee * 0.2) * 100) / 100; }
export function payStatus(due: number, paid: number): PayStatus { if (due <= 0) return 'none'; if (paid <= 0) return 'unpaid'; if (paid + 0.005 < due) return 'partial'; return 'paid'; }
export const daysBetween = (fromIso: string, toIso: string) => Math.round((Date.parse(toIso + 'T12:00:00') - Date.parse(fromIso + 'T12:00:00')) / 86400000);
/** Flag for front desk: date of service 7 to 14 days away and a balance still open. */
export const inCollectWindow = (today: string, dos: string, status: PayStatus) => { const d = daysBetween(today, dos); return d >= 7 && d <= 14 && (status === 'unpaid' || status === 'partial'); };
export const PAY_LABEL: Record<PayStatus, string> = { paid: 'Paid', partial: 'Partial', unpaid: 'Unpaid', none: 'No balance' };
/* Simulated scribe phrases for the hold-to-talk op-report mic (deterministic, fictional). */
const SCRIBE = ['Patient tolerated the procedure well with no intraoperative complications.', 'Estimated blood loss minimal. No specimens sent unless noted.', 'Wound irrigated and closed in layers; sterile dressing applied.', 'Counts correct times two. Patient taken to PACU in stable condition.'];
export function scribeLine(ctx: { procedure: string; side?: string }, n: number): string { return n === 0 ? `Dictated: ${ctx.side ? ctx.side + ' ' : ''}${ctx.procedure} performed as planned. ${SCRIBE[0]}` : SCRIBE[n % SCRIBE.length]; }

/* Block-time generator (Mon=0 … Fri=4), repeats weekly. */
export const monday = (d: string) => { const x = new Date(d + 'T12:00:00'); const k = (x.getDay() + 6) % 7; x.setDate(x.getDate() - k); return x; };
export const isoOf = (x: Date) => `${x.getFullYear()}-${String(x.getMonth() + 1).padStart(2, '0')}-${String(x.getDate()).padStart(2, '0')}`;
export function blockPlan(day: string, days: number[], weeks: number, rooms: string[]): { date: string; room: string }[] {
  const m = monday(day); const out: { date: string; room: string }[] = [];
  for (let w = 0; w < weeks; w++) days.forEach(i => { const x = new Date(m); x.setDate(m.getDate() + w * 7 + i); rooms.forEach(room => out.push({ date: isoOf(x), room })); }); return out;
}
