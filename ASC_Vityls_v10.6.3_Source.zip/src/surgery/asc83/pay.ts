/* v8.3 · case-level patient payments (simulated; nothing is charged). Each payment is also posted to the patient
 * account ledger (`patient-payments`) so Billing & payments shows it. Henry: /api/cases/:id/payments. */
import { medRepo, isoDay, uid } from '../../med/record';
import { repo } from '../../v6/dataLayer';
import { svRead, svWrite } from '../store';
import * as A from '../asc8/logic';
import * as S from '../asc8/store';
import { estimateDue, payStatus, inCollectWindow, type PayStatus } from './payrules';
export * from './payrules';
import { caseCharges, schedule, creditApplied, availableCredit } from '../asc89/store89';
import { patientDue, isSelfPay } from '../asc89/pure89';

export interface CasePay { id: string; caseId: string; pid: string; amount: number; method: string; ref: string; at: string; by: string; role: string; receipt: string; when: 'pre-service' | 'check-in' | 'other' }
export const casePays = (cid?: string) => { const l = svRead<CasePay[]>('asc83-case-pay', []); return cid ? l.filter(x => x.caseId === cid) : l; };
export const payTypeOf = (c: A.AscCase) => c.d.payType || (medRepo.patient(c.pid) as any)?.insurance || 'Self-pay';
/** v10 fix: an unapplied deposit / account credit reduces the balance right away. The patient's available credit is
 * allocated to their open cases in date order (display only; it is formally applied when the invoice is generated). */
function rawDue(c: A.AscCase) { return typeof c.d.quote === 'number' ? c.d.quote : patientDue(caseCharges(c).total, isSelfPay(payTypeOf(c)), schedule().insuredSharePct); }
function depositShare(c: A.AscCase, due: number): number {
  let left = availableCredit(c.pid); if (!(left > 0)) return 0;
  const open = S.cases().filter(x => x.pid === c.pid && x.loc !== 'closed' && !(x as any).cancelled).sort((a, b) => (a.date + a.time).localeCompare(b.date + b.time));
  for (const x of open) { const d = x.id === c.id ? due : rawDue(x); const need = Math.max(0, d - casePays(x.id).reduce((s, p) => s + p.amount, 0) - creditApplied(x.id)); const take = Math.min(left, need); if (x.id === c.id) return take; left -= take; if (left <= 0) return 0; }
  return 0;
}
export function caseMoney(c: A.AscCase): { due: number; paid: number; balance: number; status: PayStatus } {
  /* v8.9: ONE fee schedule (Practice Settings / Billing) drives the invoice AND this balance; an agreed quote still overrides. Applied patient credit counts as paid. */
  const due = typeof c.d.quote === 'number' ? c.d.quote : patientDue(caseCharges(c).total, isSelfPay(payTypeOf(c)), schedule().insuredSharePct); void estimateDue;
  const paid = Math.round((casePays(c.id).reduce((s, p) => s + p.amount, 0) + creditApplied(c.id) + depositShare(c, due)) * 100) / 100; return { due, paid, balance: Math.max(0, Math.round((due - paid) * 100) / 100), status: payStatus(due, paid) };
}
export function collectPayment(c: A.AscCase, amount: number, method: string, ref: string, by: string, role: string, when: CasePay['when']): CasePay {
  if (!(amount > 0)) throw new Error('Enter an amount.');
  const p: CasePay = { id: uid('cp'), caseId: c.id, pid: c.pid, amount: Math.round(amount * 100) / 100, method, ref, at: new Date().toISOString(), by, role, receipt: `R-${Date.now().toString(36).toUpperCase()}`, when };
  svWrite('asc83-case-pay', [...casePays(), p]);
  const led = svRead<any[]>('patient-payments', []); const mk = /card/i.test(method) ? 'card' : /cash/i.test(method) ? 'cash' : /check/i.test(method) ? 'check' : 'other';
  svWrite('patient-payments', [{ id: p.id, receipt: p.receipt, patientId: c.pid, amount: p.amount, method: mk, reference: ref || method, reason: `ASC case ${c.procedure} · DOS ${c.date}${when === 'check-in' ? ' · collected at check-in' : ''}`, takenBy: by, role, at: p.at, channel: 'in person', applied: [], status: 'posted' }, ...led]);
  repo.audit({ caseId: `asc8:${c.id}`, user: by, role, action: 'asc83.payment' as any, detail: `Payment $${p.amount.toFixed(2)} (${method}, simulated) · receipt ${p.receipt}` });
  window.dispatchEvent(new Event('vityls-med-updated')); return p;
}
/** Cases the front desk should collect on now (DOS 7–14 days out, unpaid or partial). */
export const toCollect = (today = isoDay()) => S.cases().filter(c => inCollectWindow(today, c.date, caseMoney(c).status));
export const unpaidCases = () => S.cases().filter(c => ['unpaid', 'partial'].includes(caseMoney(c).status) && c.loc !== 'closed');
