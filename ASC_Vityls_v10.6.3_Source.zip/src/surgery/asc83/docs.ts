/* v8.3 · every document for one patient + date of service, for inspectors (manual print/export only; no automatic PDF). */
import { medRepo } from '../../med/record';
import { repo } from '../../v6/dataLayer';
import * as A from '../asc8/logic';
import { s81 } from '../asc81/store81';
import { sigsFor, formTitle } from '../asc82/common';
import { casePays } from './pay';
import { fullOpFor } from './opreport';
import { OP_SECTIONS } from './oppure';
import { uploads } from '../asc87/store87';
import { UPLOAD_CAT } from '../asc89/pure89';
export const laDay = (iso?: string) => iso ? new Date(iso).toLocaleDateString('en-CA', { timeZone: 'America/Los_Angeles' }) : '';
export type DocGroup = 'Pre-op & incoming records' | 'ASC forms' | 'Consents' | 'Signed station documents' | 'Operative report' | 'PACU & discharge' | 'ID & insurance cards' | 'Payments & receipts' | 'Audit trail';
export interface Doc { id: string; group: DocGroup; title: string; cat?: string; date?: string; by?: string; status?: string; text?: string; img?: string; form?: string }
export const GROUPS: DocGroup[] = ['Pre-op & incoming records', 'ASC forms', 'Consents', 'Signed station documents', 'Operative report', 'PACU & discharge', 'ID & insurance cards', 'Payments & receipts', 'Audit trail'];
const CONSENT = /consent/i; const PACU = /pacu|discharge/i;
export function docsForCase(c: A.AscCase): Doc[] {
  const out: Doc[] = []; const ai = s81.ai(c.id);
  const pages = s81.pages(c.id); const byDoc: Record<string, typeof pages> = {}; pages.forEach(p => { (byDoc[p.doc] = byDoc[p.doc] || []).push(p); });
  Object.entries(byDoc).forEach(([d, ps]) => out.push({ id: `rec-${d}`, group: 'Pre-op & incoming records', title: `${ps[0].docTitle} (${ps.length} page${ps.length === 1 ? '' : 's'})`, date: ps[0].date, text: ps.map(p => `Page ${p.page} · ${p.date}\n${p.text}`).join('\n\n') }));
  if (c.d.clearance) out.push({ id: 'clr', group: 'Pre-op & incoming records', title: 'Pre-op clearance received & reviewed', by: c.d.clearance.by, date: laDay(c.d.clearance.at) });
  if (c.d.labs) out.push({ id: 'labs', group: 'Pre-op & incoming records', title: 'Labs received & reviewed', by: c.d.labs.by, date: laDay(c.d.labs.at) });
  const files = new Set<string>([...repo.listForms(c.visitId).map(r => r.file), ...A.ITEMS.filter(i => i.form).map(i => i.form!)]);
  files.forEach(f => { const r = repo.getForm(c.visitId, f); const it = A.ITEMS.find(i => i.form === f); const done = it ? A.isDone(c, it.key) : false; const n = Object.values(r.values || {}).filter(v => v !== '' && v != null && v !== false).length;
    if (!n && !done && r.status === 'not-started') return;
    out.push({ id: `form-${f}`, group: CONSENT.test(f) ? 'Consents' : PACU.test(f) ? 'PACU & discharge' : 'ASC forms', title: formTitle(f), status: done ? 'signed / complete' : r.status, by: it && done ? c.d[it.key]?.by : undefined, form: f, text: Object.entries(r.values || {}).filter(([, v]) => v !== '' && v != null).map(([k, v]) => `${r.labels?.[k] || k}: ${v}`).join('\n') }); });
  A.ITEMS.filter(i => i.sign && A.isDone(c, i.key) && !i.form).forEach(i => out.push({ id: `sig-${i.key}`, group: 'Signed station documents', title: i.label, by: c.d[i.key]?.by || c.d[i.key]?.signedBy, date: laDay(c.d[i.key]?.at || c.d[i.key]?.signedAt || ''), status: 'signed' }));
  const v = ai.v82 || {}; if (v.nursing?.signed) out.push({ id: 'nurse82', group: 'Signed station documents', title: 'Nursing admission checklist', by: v.nursing.signed.by, date: laDay(v.nursing.signed.at), status: 'locked & signed', text: Object.entries(v.nursing.checks || {}).filter(([, x]) => x).map(([k]) => `✓ ${k}`).join('\n') });
  if (v.anes?.evalSigned) out.push({ id: 'anes82', group: 'Signed station documents', title: 'Pre-anesthesia evaluation', by: v.anes.evalSigned.by, date: laDay(v.anes.evalSigned.at), status: 'signed', text: `ASA ${v.anes.asa || c.d.asa || ''}\nAirway ${JSON.stringify(v.anes.airway || {})}\nType ${v.anes.type || ''} ${(v.anes.tech || []).join(', ')}` });
  if (v.anes?.pre) out.push({ id: 'pre82', group: 'Signed station documents', title: 'Immediate pre-induction re-evaluation', by: v.anes.pre.by, date: laDay(v.anes.pre.at), status: 'signed', text: v.anes.preNote || '' });
  (['preOrders', 'postOrders'] as const).forEach(k => { const o = v.surg?.[k]; if (o?.signed) out.push({ id: k, group: 'Signed station documents', title: k === 'preOrders' ? 'Surgeon pre-op orders' : 'Surgeon post-op orders', by: o.signed.by, date: laDay(o.signed.at), status: 'signed', text: o.text }); });
  if (ai.orders?.signed) out.push({ id: 'pacuorders', group: 'PACU & discharge', title: 'Anesthesia PACU orders', by: ai.orders.signed.by, status: 'signed', text: ai.orders.text });
  if (c.d.opReport?.text) out.push({ id: 'op', group: 'Operative report', title: 'Operative report', by: c.d.opReport.signedBy, date: laDay(c.d.opReport.signedAt || ''), status: c.d.opReport.signedAt ? 'signed' : 'draft', text: c.d.opReport.text });
  const fo = fullOpFor(c.id); if (fo) out.push({ id: 'opfull', group: 'Operative report', title: 'Full operative report', by: fo.signed?.by || fo.updatedBy, date: laDay(fo.signed?.at || fo.updatedAt || ''), status: fo.signed ? 'signed' : fo.status, text: OP_SECTIONS.map(([k, l]) => `${l}: ${fo.sections[k] || ''}`).join('\n') });
  if (ai.discharge?.text) out.push({ id: 'dc', group: 'PACU & discharge', title: 'Discharge instructions', by: ai.discharge.signed?.by, status: ai.discharge.signed ? 'signed' : 'draft', text: ai.discharge.text });
  if (v.dc?.patient) out.push({ id: 'dcpt', group: 'PACU & discharge', title: `Discharge acknowledgement · ${v.dc.patient.name}`, date: laDay(v.dc.patient.at), status: 'signed (drawn)', img: v.dc.patient.png });
  sigsFor(c.id).forEach(sg => out.push({ id: sg.id, group: 'Signed station documents', title: `Signature · ${sg.title}`, by: sg.name, date: laDay(sg.at), status: sg.role, img: sg.png }));
  const cards = v.cards || {}; Object.entries(cards).filter(([, x]) => x).forEach(([k, x]) => out.push({ id: `card-${k}`, group: 'ID & insurance cards', title: ({ idFront: 'Photo ID · front', idBack: 'Photo ID · back', insFront: 'Insurance card · front', insBack: 'Insurance card · back' } as any)[k] || k, img: x as string }));
  if (c.d.id && !Object.keys(cards).length) out.push({ id: 'idok', group: 'ID & insurance cards', title: 'ID & insurance confirmed at check-in (no images)', by: c.d.id.by });
  casePays(c.id).forEach(p => out.push({ id: p.id, group: 'Payments & receipts', title: `Receipt ${p.receipt} · $${p.amount.toFixed(2)} · ${p.method}`, by: p.by, date: laDay(p.at), status: p.when, text: `Patient: ${medRepo.patient(c.pid)?.name}\nCase: ${c.procedure} · DOS ${c.date}\nAmount: $${p.amount.toFixed(2)}\nMethod: ${p.method} ${p.ref || ''}\nTaken by: ${p.by}\nSimulated payment (fictional).` }));
  uploads(c.id).forEach(u => out.push({ id: u.id, cat: u.cat || UPLOAD_CAT[u.type], group: (UPLOAD_CAT[u.type] || u.cat) === 'OP Reports' ? 'Operative report' : 'Pre-op & incoming records', title: `${u.type} · ${u.name} (uploaded)`, by: u.by, date: laDay(u.at), status: 'uploaded', img: u.data && /^data:image/.test(u.data) ? u.data : undefined, text: `File: ${u.name} (${Math.round(u.size / 1024)} KB, ${u.mime || 'file'})${u.note ? `\nNote: ${u.note}` : ''}\nUploaded by ${u.by} (${u.role}) · source content unaltered` }));
  out.push({ id: 'audit', group: 'Audit trail', title: `Case audit trail (${c.audit.length} entries)`, text: c.audit.map(a => `${a.at.replace('T', ' ').slice(0, 16)} · ${a.by} · ${a.what}`).join('\n') });
  return out;
}
export function exportText(c: A.AscCase, docs: Doc[]): string { const p = medRepo.patient(c.pid)!;
  return [`ASC.Vityls · audit packet (fictional data)`, `Patient: ${p.name} · DOB ${p.dob} · MRN ${p.id}`, `Date of service: ${c.date} · ${c.procedure} · ${c.surgeon} · ${c.room}`, `Exported manually ${new Date().toLocaleString('en-US', { timeZone: 'America/Los_Angeles' })} PT`, '',
    ...GROUPS.flatMap(g => { const l = docs.filter(d => d.group === g); return l.length ? [`=== ${g} ===`, ...l.flatMap(d => [`— ${d.title}${d.status ? ` [${d.status}]` : ''}${d.by ? ` · ${d.by}` : ''}${d.date ? ` · ${d.date}` : ''}`, d.text || (d.img ? '(image on file)' : ''), ''])] : []; })].join('\n'); }
