/* v8.3 · Hold-to-talk microphone (simulated scribe; no audio is recorded or sent anywhere). */
import React, { useRef, useState } from 'react';
import { scribeLine } from './payrules';
export const HoldMic: React.FC<{ ctx: { procedure: string; side?: string }; onText: (t: string) => void; disabled?: boolean }> = ({ ctx, onText, disabled }) => {
  const [on, setOn] = useState(false); const n = useRef(0); const t0 = useRef(0);
  const start = (e: React.PointerEvent | React.KeyboardEvent) => { if (disabled || on) return; e.preventDefault(); t0.current = Date.now(); setOn(true); };
  const stop = () => { if (!on) return; setOn(false); onText(scribeLine(ctx, n.current++)); };
  return <span className="a82-sh" style={{ gap: 8 }}><button type="button" className={`a83-mic ${on ? 'on' : ''}`} disabled={disabled} aria-pressed={on} onPointerDown={start} onPointerUp={stop} onPointerLeave={stop} onKeyDown={e => { if (e.key === ' ' || e.key === 'Enter') start(e); }} onKeyUp={stop} data-testid="a83-mic">🎙 {on ? 'Listening… release to insert' : 'Hold to talk'}</button><span className="sv-small sv-muted">Simulated scribe · fictional text</span></span>;
};
