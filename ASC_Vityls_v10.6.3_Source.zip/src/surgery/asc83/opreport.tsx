/* v8.3 · Full operative report on the Surgeon workbench: hold-to-talk dictation per section, draft/save, drawn + PIN signature. */
import React, { useState } from 'react';
import { medRepo } from '../../med/record';
import { useMedTick } from '../../med/ui';
import { svRead, svWrite } from '../store';
import * as A from '../asc8/logic';
import * as S from '../asc8/store';
import { OP_SECTIONS, blankOp, opStatus, scribeSection, applySubmit, applySign, deepLink, missingSections, type FullOpReport, type OpCtx, type OpListItem, type ApiResult, type OpSubmit, type OpSign } from './oppure';
export * from './oppure';
const KEY = 'asc83-op-full';
const all = () => svRead<Record<string, FullOpReport>>(KEY, {});
const ctxOf = (c: A.AscCase): OpCtx => ({ cid: c.id, pid: c.pid, surgeon: c.surgeon, dos: c.date, procedure: c.procedure, side: c.side && !new RegExp(c.side, 'i').test(c.procedure) ? c.side : undefined, anesthesia: `${c.d.anesType || 'General anesthesia'}${c.anesthesia ? ` (${c.anesthesia})` : ''}`, assistant: c.d.assistant });
/* ---- local API (same contract a mobile client would call over HTTP; see Henry doc) ---- */
export const opApi = {
  get(cid: string): ApiResult<FullOpReport> { const c = S.caseById(cid); if (!c) return { ok: false, error: 'not-found' }; return { ok: true, data: all()[cid] || blankOp(ctxOf(c)) }; },
  listForSurgeon(surgeon: string, status?: FullOpReport['status']): OpListItem[] { return S.cases().filter(c => c.surgeon === surgeon && ['or', 'pacu', 'discharged', 'closed'].includes(c.loc)).map(c => { const r = all()[c.id] || blankOp(ctxOf(c)); return { cid: c.id, pid: c.pid, patientName: medRepo.patient(c.pid)?.name || '', dos: c.date, procedure: c.procedure, status: opStatus(r), deepLink: deepLink(c.id) }; }).filter(x => !status || x.status === status); },
  submit(s: OpSubmit): ApiResult<FullOpReport> { const g = opApi.get(s.cid); if (!g.ok) return g; const r = applySubmit(g.data, s, new Date().toISOString()); if (r.ok) { svWrite(KEY, { ...all(), [s.cid]: r.data }); const c = S.caseById(s.cid)!; S.saveCase({ ...c, audit: [...c.audit, { at: new Date().toISOString(), by: s.by, role: 'surgeon', what: `Full op report draft saved (v${r.data.version}, ${s.source})` }] } as any, s.by, 'surgeon', 'op-full.save'); } return r; },
  sign(s: OpSign, sigId?: string): ApiResult<FullOpReport> { const g = opApi.get(s.cid); if (!g.ok) return g; const r = applySign(g.data, s, new Date().toISOString(), sigId); if (r.ok) { svWrite(KEY, { ...all(), [s.cid]: r.data }); const c = S.caseById(s.cid)!; S.saveCase({ ...c, audit: [...c.audit, { at: new Date().toISOString(), by: s.by, role: 'surgeon', what: 'Full operative report signed (drawn signature + PIN)' }] } as any, s.by, 'surgeon', 'op-full.sign'); } return r; },
};
export const fullOpFor = (cid: string): FullOpReport | undefined => all()[cid];
const LBL: Record<string, string> = { pending: 'Pending', dictated: 'Dictated · awaiting signature', signed: 'Signed' };
export const FullOpReportPanel: React.FC<{ c: A.AscCase; Sign: React.FC<any>; roles: string[] }> = ({ c, Sign, roles }) => { useMedTick(); const g = opApi.get(c.id); const base = g.ok ? g.data : blankOp(ctxOf(c));
  const [d, setD] = useState<Record<string, string>>(base.sections); const [hold, setHold] = useState(''); const [msg, setMsg] = useState(''); const locked = !!base.signed;
  const live: FullOpReport = { ...base, sections: d }; const st = opStatus(live); const dirty = JSON.stringify(d) !== JSON.stringify(base.sections);
  const save = () => { const r = opApi.submit({ cid: c.id, sections: d, baseVersion: base.version, source: 'web', by: c.surgeon }); setMsg(r.ok ? `Draft saved · ${LBL[r.data.status]}` : `Not saved: ${(r as any).error}`); };
  const fill = (k: string) => setD(x => ({ ...x, [k]: x[k]?.trim() ? `${x[k].trimEnd()} ${scribeSection(k, ctxOf(c))}` : scribeSection(k, ctxOf(c)) }));
  const fillAll = () => setD(x => Object.fromEntries(OP_SECTIONS.map(([k]) => [k, x[k]?.trim() ? x[k] : scribeSection(k, ctxOf(c))])));
  const Mic: React.FC<{ k: string }> = ({ k }) => <button type="button" className={`a83-mic ${hold === k ? 'on' : ''}`} disabled={locked} onPointerDown={e => { e.preventDefault(); setHold(k); }} onPointerUp={() => { if (hold === k) { setHold(''); k === '*' ? fillAll() : fill(k); } }} onPointerLeave={() => { if (hold === k) { setHold(''); k === '*' ? fillAll() : fill(k); } }} data-testid={k === '*' ? 'a83-opf-mic-all' : `a83-opf-mic-${k}`}>🎙 {hold === k ? 'Listening…' : k === '*' ? 'Hold to dictate the whole report' : 'Hold'}</button>;
  return <section className="a82-sec" data-testid="a83-opfull" data-status={base.signed ? 'signed' : st}><div className="a82-sh"><h3 className="a81-h3">Full operative report</h3><span className={`a83-pay ${base.signed ? 'paid' : st === 'dictated' ? 'partial' : 'unpaid'}`} data-testid="a83-opf-status">{LBL[base.signed ? 'signed' : st]}</span></div>
    <p className="sv-small sv-muted">Simulated scribe: hold a mic, speak, release, and the scribe fills that section. Edit freely before signing. Mobile link: <code>{deepLink(c.id)}</code></p>
    {!locked && <div className="a82-row" style={{ gap: 8, flexWrap: 'wrap' }}><Mic k="*" /></div>}
    <div className="a83-opgrid">{OP_SECTIONS.map(([k, l]) => <label key={k} className={`a83-f ${k === 'description' || k === 'findings' || k === 'indications' ? 'span4' : ''}`}><span className="a83-l" style={{ display: 'flex', alignItems: 'center', gap: 8 }}>{l}{!locked && <Mic k={k} />}</span><textarea className="sv-input" rows={k === 'description' ? 5 : 2} readOnly={locked} value={d[k] || ''} onChange={e => setD({ ...d, [k]: e.target.value })} data-testid={`a83-opf-${k}`} /></label>)}</div>
    {msg && <p className="sv-small" data-testid="a83-opf-msg">{msg}</p>}
    {locked ? <p className="a81-ok" data-testid="a83-opf-signed">✓ Signed by {base.signed!.by} · {new Date(base.signed!.at).toLocaleString('en-US', { timeZone: 'America/Los_Angeles' })} PT · filed under the case Documents</p>
      : <div className="a81-foot"><span className="sv-small">{missingSections(live).length ? `${missingSections(live).length} sections still empty` : 'All sections dictated'}</span><button type="button" className="a8-btn" disabled={!dirty} onClick={save} data-testid="a83-opf-save">Save draft</button>
        <Sign label="Sign full op report" roles={roles} allow={(p: { name: string }) => p.name === c.surgeon} cid={c.id} what="Full operative report" testId="a83-opf-sign" disabled={!!missingSections(live).length}
          onSigned={(by: string) => { let b = base; if (dirty) { const r = opApi.submit({ cid: c.id, sections: d, baseVersion: base.version, source: 'web', by: c.surgeon }); if (!r.ok) return setMsg(`Not saved: ${(r as any).error}`); b = r.data; } const r = opApi.sign({ cid: c.id, by, pinVerified: true, baseVersion: b.version }); setMsg(r.ok ? 'Signed and filed.' : `Not signed: ${(r as any).error}${(r as any).error === 'forbidden' ? ' (only the case surgeon can sign)' : ''}`); }} /></div>}
  </section>; };
