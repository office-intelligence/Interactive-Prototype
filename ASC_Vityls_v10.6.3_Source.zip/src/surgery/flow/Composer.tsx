/* Surgery.Vityls v1.3 · the rounded pill chat composer, fixed at the bottom of EVERY page (Kevin: exception to the 3px rule).
   It replaces the old green Nightingale box on Today and the page-top Nightingale card. Same scripted on-device answers as
   before (chartAnswer on a patient page, globalAnswer elsewhere); + opens quick actions; the mic is simulated (nothing recorded). */
import React, { useEffect, useRef, useState } from 'react';
import { Plus, Mic, ArrowUp, X } from 'lucide-react';
import './flow.css';
import { repo } from '../../v6/dataLayer';
import { patientKey, medRepo } from '../../med/record';
import { useActor } from '../../med/ui';
import { useSv } from '../ui';
import { Answer, chartAnswer, globalAnswer } from '../nightingale';

export const FlowComposer: React.FC<{ patientId?: string }> = ({ patientId }) => {
  const { go, toast, setTab } = useSv(); const [actor] = useActor();
  const [q, setQ] = useState(''); const [ans, setAns] = useState<Answer | null>(null); const [plus, setPlus] = useState(false); const [busy, setBusy] = useState(false);
  const inp = useRef<HTMLInputElement>(null); const shownAt = useRef(0);
  // a new page or patient clears an old answer (but not the one that just navigated there)
  useEffect(() => { if (Date.now() - shownAt.current > 1500) setAns(null); }, [patientId]);
  useEffect(() => { if (ans) document.body.dataset.flcAns = '1'; else delete document.body.dataset.flcAns; return () => { delete document.body.dataset.flcAns; }; }, [ans]);
  useEffect(() => { const f = (e: KeyboardEvent) => { const t = e.target as HTMLElement; if (e.key === '/' && !/input|textarea|select/i.test(t.tagName) && !t.isContentEditable) { e.preventDefault(); inp.current?.focus(); } }; window.addEventListener('keydown', f); return () => window.removeEventListener('keydown', f); }, []);
  const ask = () => { const text = q.trim(); if (!text) return; setQ(''); setBusy(true);
    window.setTimeout(() => { const a = patientId ? chartAnswer(patientId, text) : globalAnswer(text); shownAt.current = Date.now(); setAns(a); setBusy(false);
      if (patientId) repo.audit({ caseId: patientKey(patientId), user: actor.name, role: actor.role, action: 'nightingale.answer', detail: `Q: ${text.slice(0, 80)}` });
      if (a.act) go(a.act); }, 220); };
  const name = patientId ? medRepo.patient(patientId)?.name.split(' ')[0] : '';
  return <div className="fl flc" data-testid="flow-composer">
    {ans && <div className="ans" aria-live="polite" data-testid="nightingale-answer"><button type="button" className="ib" style={{ float: 'right', width: 28, height: 28 }} aria-label="Close answer" onClick={() => setAns(null)}><X size={14} /></button><div style={{ fontSize: 12, color: 'var(--mu)' }}>You asked: {ans.q}</div><div>{ans.text}</div><div style={{ fontSize: 11.5, color: 'var(--mu2)', marginTop: 4 }}>On-device, from recorded data only. Nightingale drafts; staff review and send.</div></div>}
    {plus && <div className="plus" role="menu" data-testid="flow-composer-menu">
      <button type="button" role="menuitem" onClick={() => { setPlus(false); setTab('schedule'); }}>New appointment</button>
      <button type="button" role="menuitem" onClick={() => { setPlus(false); setTab('patients'); }}>Find or add a patient</button>
      <button type="button" role="menuitem" onClick={() => { setPlus(false); toast('Attach a document: simulated in this build (nothing is uploaded).'); }}>Attach a document</button>
      <button type="button" role="menuitem" onClick={() => { setPlus(false); setTab('chat'); }}>New chat</button></div>}
    <form className="cbox2" role="search" onSubmit={e => { e.preventDefault(); ask(); }} data-testid="nightingale-bar">
      <button type="button" className="ib" aria-label="More actions" aria-expanded={plus} onClick={() => setPlus(x => !x)} data-testid="flow-composer-plus"><Plus size={18} /></button>
      <label htmlFor="flc-in" className="sr-only">Ask Nightingale</label>
      <input id="flc-in" ref={inp} value={q} onChange={e => setQ(e.target.value)} placeholder={busy ? 'Reading…' : patientId ? `Ask about ${name}, or tell Nightingale what to do` : 'Ask Nightingale: “who’s next”, “what needs my attention”'} autoComplete="off" data-testid="nightingale-input" />
      <button type="button" className="ib" aria-label="Speak (simulated)" title="Simulated: nothing is recorded" onClick={() => { setQ(patientId ? 'What changed since the last visit?' : 'Who’s next?'); toast('Simulated voice: nothing was recorded. A sample question was typed for you.'); inp.current?.focus(); }} data-testid="flow-composer-mic"><Mic size={18} /></button>
      {q.trim() && <button type="submit" className="ib send" aria-label="Send" data-testid="flow-composer-send"><ArrowUp size={18} /></button>}
    </form>
  </div>;
};
