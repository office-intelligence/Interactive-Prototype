/*
 * Surgery.Vityls v1.3 · Kevin's 7-step patient workflow (Oct 20), pure logic (no browser, no storage; unit-tested with node:test).
 *   1 Scheduling        appointment booked · admission/registration forms sent
 *   2 Front desk        registration complete · required payment collected
 *   3 Nurse / exam room vital signs (incl. respiratory rate) · reason for visit · additional notes
 *   4 Doctor            interview + exam · body charts · pre-op photos · consult note · price quote
 *        → optional "Consultation Performed — Undecided": the workflow stops; resuming starts at Step 5 (abbreviated)
 *   5 Doctor/Coordinator quote accepted · deposit amount + date · case booked + surgery date · clearance yes/no → PCP checklist
 *   6 ASC               clearance documents sent · surgery date and time confirmed
 *   7 Post-op           routine visits with reminders/confirmations only (no separate workflow)
 * The v1.2 journey engine (journey/logic.ts, 11 steps) still runs underneath; `fromJourneyStep` maps its steps onto these 7.
 * The checklist holds only these critical items. Statuses: Done · Incomplete · Due · Overdue. Nothing here asks to reconfirm.
 */
export type FStep = 1 | 2 | 3 | 4 | 5 | 6 | 7;
export const FSTEPS: { n: FStep; short: string; title: string; owner: string }[] = [
  { n: 1, short: 'Scheduling', title: 'New patient scheduling', owner: 'Front desk' },
  { n: 2, short: 'Front desk', title: 'Front desk', owner: 'Front desk' },
  { n: 3, short: 'Nurse', title: 'Nurse · exam room', owner: 'Nurse / coordinator' },
  { n: 4, short: 'Doctor', title: 'Doctor · exam room', owner: 'Surgeon' },
  { n: 5, short: 'Book & clear', title: 'Book the case & clearance', owner: 'Doctor / coordinator' },
  { n: 6, short: 'ASC', title: 'Ambulatory surgery center', owner: 'Coordinator' },
  { n: 7, short: 'Post-op', title: 'Post-op care', owner: 'Front desk · surgeon' },
];
/** Medical.Vityls v2.0: the 5-step office workflow (Scheduling → Front desk → Nurse/MA → Doctor → Checkout). Pure toggle so node tests
 *  can exercise it; the MEDICAL edition calls setFlowMedical(true) once at boot. Surgery never calls it (7 steps unchanged). */
export let FLOW_MED = false;
const SURG_STEPS = FSTEPS.slice();
export const MED_STEPS: typeof FSTEPS = [
  { n: 1, short: 'Scheduling', title: 'Scheduling', owner: 'Front desk' },
  { n: 2, short: 'Front desk', title: 'Front desk', owner: 'Front desk' },
  { n: 3, short: 'Nurse / MA', title: 'Nurse / MA · exam room', owner: 'Nurse / MA' },
  { n: 4, short: 'Doctor', title: 'Doctor · exam room', owner: 'Doctor' },
  { n: 5, short: 'Checkout', title: 'Checkout', owner: 'Front desk' },
];
export function setFlowMedical(on: boolean) { FLOW_MED = on; FSTEPS.splice(0, FSTEPS.length, ...(on ? MED_STEPS : SURG_STEPS)); }
export const lastStep = (): FStep => (FLOW_MED ? 5 : 7);
export const stepDef = (n: number) => FSTEPS.find(s => s.n === n)!;
export type FStatus = 'done' | 'incomplete' | 'due' | 'overdue';
export const STATUS_LABEL: Record<FStatus, string> = { done: 'Done', incomplete: 'Incomplete', due: 'Due', overdue: 'Overdue' };
export type Mode = 'office' | 'video' | 'phone';
/** PCP checklist (Kevin): H&P, CBC, CMP, UA, ECG, PT, PTT, chest x-ray. */
/** v1.5: + Pregnancy test (Kevin, Oct 21). Practice default list = this list (Surgery settings can trim it). */
export const PCP_CHECKLIST = ['H&P', 'CBC', 'CMP', 'UA', 'ECG', 'PT', 'PTT', 'CXR', 'Preg'] as const;
export const PCP_LABEL: Record<string, string> = { 'H&P': 'History & physical', CBC: 'CBC', CMP: 'CMP', UA: 'UA', ECG: 'ECG', PT: 'PT', PTT: 'PTT', CXR: 'Chest x-ray', Preg: 'Pregnancy test' };
/** Default tests for a patient: the practice list; the pregnancy test is left off for male patients (staff can tick it). */
export const defaultTestsFor = (sex: string | undefined, practice: readonly string[] = PCP_CHECKLIST) => practice.filter(t => t !== 'Preg' || !/^m/i.test(sex || ''));

export interface Stamp { at: string; by?: string; note?: string }
/** Everything the 7 steps need, read from the chart (see flow/store.ts). Absent = not done yet. */
export interface FlowFacts {
  today: string;
  mode: Mode;
  /** Date of the consultation visit (anchors Steps 2-4 due dates). */ visitDate?: string;
  booked?: Stamp; formsSent?: Stamp;
  registration?: Stamp; registrationMissing?: string[]; paymentRequired: boolean; paid?: Stamp;
  vitals?: Stamp; vitalsMissing?: string[]; reason?: Stamp; nurseNotes?: Stamp;
  exam?: Stamp; bodyChart?: Stamp; photos?: Stamp; noteSigned?: Stamp; quote?: Stamp;
  undecided?: { at: string; by: string; reason?: string }; resumed?: { at: string; by: string };
  quoteAccepted?: Stamp; deposit?: Stamp & { amount: number; date: string }; caseBooked?: Stamp & { surgeryDate: string; time?: string };
  clearance?: { required: boolean; at: string; by: string }; pcpSent?: Stamp; clearanceTests?: string[];
  received?: Partial<Record<string, Stamp>>; ascSent?: Stamp; ascConfirmed?: Stamp & { time?: string };
  postop?: { date: string; confirmed: boolean }[];
  /** Medical v2.0: checkout finished (follow-up booked / balance settled / visit closed). */ checkout?: Stamp;
}
export interface FlowItem { /** v1.5: why Nightingale lists it (inferred next step) */ why?: string; key: string; step: FStep; label: string; status: FStatus; due?: string; at?: string; by?: string; note?: string; /** what the chip opens */ action: FAction; sub?: boolean }
export type FAction = 'book' | 'forms' | 'registration' | 'payment' | 'nurse' | 'doctor' | 'doctor-photos' | 'doctor-charts' | 'doctor-note' | 'doctor-quote'
  | 'quote-accept' | 'deposit' | 'book-case' | 'clearance' | 'pcp-letter' | 'docs' | 'send-asc' | 'asc-confirm' | 'postop' | 'checkout';
export interface Flow { step: FStep; undecided: boolean; stopped: boolean; resumed: boolean; items: FlowItem[]; remote: boolean }

export const addDays = (iso: string, n: number) => { const [y, m, d] = iso.slice(0, 10).split('-').map(Number); return new Date(Date.UTC(y, m - 1, d + n)).toISOString().slice(0, 10); };
export const daysBetween = (from: string, to: string) => Math.round((Date.UTC(+to.slice(0, 4), +to.slice(5, 7) - 1, +to.slice(8, 10)) - Date.UTC(+from.slice(0, 4), +from.slice(5, 7) - 1, +from.slice(8, 10))) / 864e5);
/** Done if stamped. Otherwise Overdue past its due date, Due on or within 2 days of it, Incomplete before that (or with no due date). */
export function statusFor(s: Stamp | undefined | boolean, due: string | undefined, today: string): FStatus {
  if (s) return 'done'; if (!due) return 'incomplete'; const d = daysBetween(today, due); return d < 0 ? 'overdue' : d <= 2 ? 'due' : 'incomplete';
}

export function deriveFlow(f: FlowFacts): Flow {
  const T = f.today; const items: FlowItem[] = []; const remote = f.mode !== 'office';
  const add = (step: FStep, key: string, label: string, s: Stamp | undefined, due: string | undefined, action: FAction, sub = false) =>
    items.push({ key, step, label, status: statusFor(s, due, T), due, at: s?.at, by: s?.by, note: s?.note, action, sub });
  const bookedOn = f.booked?.at.slice(0, 10); const vd = f.visitDate;
  // 1 · Scheduling
  add(1, 'booked', 'Appointment booked', f.booked, undefined, 'book');
  add(1, 'forms', 'Admission & registration forms sent', f.formsSent, bookedOn ? addDays(bookedOn, 1) : undefined, 'forms');
  // 2 · Front desk
  add(2, 'registration', 'Registration complete', f.registration, vd, 'registration');
  if (f.paymentRequired) add(2, 'payment', 'Required payment collected', f.paid, vd, 'payment');
  // 3 · Nurse (video/phone: no vitals in the room; the reason is still recorded)
  if (!remote) add(3, 'vitals', 'Vital signs recorded (incl. respiratory rate)', f.vitals, vd, 'nurse');
  add(3, 'reason', 'Reason for visit documented', f.reason, vd, 'nurse');
  add(3, 'nurse-notes', 'Additional notes added', f.nurseNotes, vd, 'nurse');
  if (FLOW_MED) {
    // Medical v2.0: Doctor = interview/exam + signed note (body chart & photos stay available as tools, never required). 5 · Checkout.
    add(4, 'exam', remote ? 'Interview (remote visit)' : 'Interview & examination', f.exam, vd, 'doctor');
    add(4, 'note', 'Visit note signed', f.noteSigned, vd, 'doctor-note');
    add(5, 'checkout', 'Checkout complete', f.checkout, vd, 'checkout');
    const all5 = [1, 2, 3, 4, 5] as FStep[]; const dn = (n: FStep) => items.filter(i => i.step === n).every(i => i.status === 'done');
    const act = all5.filter(n => items.some(i => i.step === n && i.status === 'done')); const floor = Math.max(1, ...act); let st: FStep = 5;
    for (const n of all5) { if (n < floor) continue; if (!dn(n)) { st = n; break; } }
    return { step: st, undecided: false, stopped: false, resumed: false, items, remote };
  }
  // 4 · Doctor (phone: no body chart or photos; video: patient-sent photos)
  add(4, 'exam', remote ? 'Surgical interview (remote exam)' : 'Surgical interview & examination', f.exam, vd, 'doctor');
  if (f.mode !== 'phone') { add(4, 'body-chart', 'Body charts completed', f.bodyChart, vd, 'doctor-charts'); add(4, 'photos', f.mode === 'video' ? 'Pre-op photos (sent by the patient)' : 'Pre-op photos taken', f.photos, vd, 'doctor-photos'); }
  add(4, 'note', 'Consultation note signed', f.noteSigned, vd, 'doctor-note');
  add(4, 'quote', 'Price quote prepared', f.quote, vd, 'doctor-quote');
  // 5 · Doctor / coordinator
  const s5open = f.resumed?.at.slice(0, 10) || f.quote?.at.slice(0, 10) || vd;
  add(5, 'quote-accepted', 'Quote accepted', f.quoteAccepted, undefined, 'quote-accept');
  add(5, 'deposit', 'Deposit recorded (amount + date)', f.deposit, f.quoteAccepted ? addDays(f.quoteAccepted.at, 7) : undefined, 'deposit');
  add(5, 'case', 'Case booked with surgery date', f.caseBooked, f.quoteAccepted ? addDays(f.quoteAccepted.at, 7) : undefined, 'book-case');
  add(5, 'clearance', 'Pre-op clearance decision', f.clearance, f.caseBooked ? f.caseBooked.at.slice(0, 10) : undefined, 'clearance');
  const surg = f.caseBooked?.surgeryDate;
  if (f.clearance?.required) add(5, 'pcp', 'Pre-op checklist sent to the PCP', f.pcpSent, f.clearance ? addDays(f.clearance.at, 2) : undefined, 'pcp-letter');
  void s5open;
  // 6 · ASC
  if (f.clearance?.required) add(6, 'docs', 'Clearance documents received', (f.clearanceTests || [...PCP_CHECKLIST]).every(t => f.received?.[t]) ? { at: f.received && Object.keys(f.received).length ? lastAt(f.received) : f.clearance.at } : undefined, surg ? addDays(surg, -9) : undefined, 'docs');
  add(6, 'asc-sent', f.clearance?.required ? 'Clearance documents sent to the ASC' : 'Case documents sent to the ASC', f.ascSent, surg ? addDays(surg, -7) : undefined, 'send-asc');
  add(6, 'asc-confirmed', 'Surgery date & time confirmed by the ASC', f.ascConfirmed, surg ? addDays(surg, -5) : undefined, 'asc-confirm');
  // 7 · Post-op (routine visits; reminders + confirmations only)
  const pv = f.postop || [];
  add(7, 'postop', 'Post-op visits booked', pv.length ? { at: pv[0].date } : undefined, surg ? addDays(surg, 1) : undefined, 'postop');

  const done = (n: FStep) => items.filter(i => i.step === n).every(i => i.status === 'done');
  const undecided = !!f.undecided && !f.resumed; const resumed = !!f.resumed;
  // Current step: the first unfinished step at or after the furthest step that has work in it. An earlier gap (say, an
  // uncollected fee) does not hold the patient back; it is carried forward and flagged instead (see carried()).
  const all = [1, 2, 3, 4, 5, 6, 7] as FStep[]; const active = all.filter(n => !(resumed && n < 5) && items.some(i => i.step === n && i.status === 'done'));
  const floor = Math.max(resumed ? 5 : 1, ...active.filter(n => n < 7 || !!surg)); let step: FStep = 7;
  for (const n of all) { if (n < floor && !(n === floor)) continue; if (!done(n)) { step = n; break; } }
  // Undecided stops the workflow after Step 4. Accepting a quote (or resuming) moves it on.
  if (undecided && !f.quoteAccepted) step = Math.min(step, 4) as FStep;
  // Step 7 opens once the ASC part is done or the surgery date has passed.
  if (surg && T >= surg) step = 7;
  return { step, undecided, stopped: undecided && !f.quoteAccepted && done(4), resumed, items, remote };
}
const lastAt = (r: Partial<Record<string, Stamp>>) => Object.values(r).map(x => x!.at).sort().slice(-1)[0];
export const itemsOf = (fl: Flow, n: FStep) => fl.items.filter(i => i.step === n);
/** Unfinished items from earlier steps (carried forward; Nightingale flags them). Not after a resume (abbreviated). */
export const carried = (fl: Flow) => fl.items.filter(i => i.step < fl.step && i.status !== 'done' && !(fl.resumed && i.step < 5));
export const stepDone = (fl: Flow, n: FStep) => itemsOf(fl, n).every(i => i.status === 'done');
/** The single next thing to do on the current step (Overdue first, then Due, then in order). */
export function nextItem(fl: Flow): FlowItem | undefined {
  if (fl.stopped) return undefined; const open = itemsOf(fl, fl.step).filter(i => i.status !== 'done');
  const rank: Record<FStatus, number> = { overdue: 0, due: 1, incomplete: 2, done: 3 };
  // keep the natural order for the booking chain (quote → deposit → case → clearance → PCP)
  return fl.step === 5 ? open[0] : open.slice().sort((a, b) => rank[a.status] - rank[b.status] || fl.items.indexOf(a) - fl.items.indexOf(b))[0];
}
/** Steps whose dots can be opened: finished steps (edit, audited) and the current one. */
export const openable = (fl: Flow, n: FStep) => n <= fl.step || stepDone(fl, n);
/** Checklist for the current step: earlier steps collapse into one "Steps 1–N complete" row (no recaps of routine steps). */
export function checklist(fl: Flow): { label: string; status: FStatus; key: string }[] {
  const n = fl.step; const rows: { label: string; status: FStatus; key: string }[] = [];
  if (n > 1) rows.push({ key: 'prior', label: n === 2 ? 'Step 1 complete' : `Steps 1–${n - 1} complete`, status: ([1, 2, 3, 4, 5, 6] as FStep[]).filter(s => s < n).every(s => stepDone(fl, s)) ? 'done' : 'incomplete' });
  itemsOf(fl, n).forEach(i => rows.push({ key: i.key, label: i.label, status: i.status }));
  return rows;
}
/** v1.2 journey step (11) → v1.3 step (7). Steps 2+3 (pre-visit, check-in) are the front desk; 7-8 clearance/readiness are the ASC step; 11 (return visit) re-enters at the front desk. */
export function fromJourneyStep(n: number): FStep { return ({ 1: 1, 2: 2, 3: 2, 4: 3, 5: 4, 6: 5, 7: 6, 8: 6, 9: 6, 10: 7, 11: 2 } as Record<number, FStep>)[n] || 1; }
/** Overdue / Due / Incomplete items across patients for the To-do panel. */
export function todoGroups<T extends { item: FlowItem }>(xs: T[], today: string) {
  const open = xs.filter(x => x.item.status !== 'done');
  return [{ id: 'overdue', label: 'Overdue', items: open.filter(x => x.item.status === 'overdue') },
    { id: 'today', label: 'Due today', items: open.filter(x => x.item.status === 'due' && (!x.item.due || x.item.due <= today)) },
    { id: 'week', label: 'This week', items: open.filter(x => (x.item.status === 'due' && x.item.due! > today) || (x.item.status === 'incomplete' && x.item.due && daysBetween(today, x.item.due) <= 7)) }].filter(g => g.items.length);
}

/* ---------------- v1.5 · the patient's To-do list (Kevin, Oct 21) ----------------
 * Every unfinished task for the patient, maintained by Nightingale. Nothing here blocks anything: any workspace opens at any time;
 * this list only tracks. Surgical tasks are inferred in order: surgery suggested → quote → quote accepted → book the case, deposit,
 * clearance → PCP letter → clearance packet → send to the ASC → ASC confirms date/time → post-op visits. A task appears once its
 * trigger has happened (it is never shown before the surgery is even suggested). */
export interface TodoCtx { surgerySuggested?: boolean }
export function openTodos(fl: Flow, f: FlowFacts, ctx: TodoCtx = {}): FlowItem[] {
  if (FLOW_MED) return fl.items.filter(i => i.status !== 'done' && !!f.visitDate && (i.step <= fl.step || (i.step === 5 && !!f.exam))); // Medical: only work that is reachable now
  if (fl.stopped) return [{ key: 'undecided', step: 4, label: 'Consultation Performed — Undecided: follow up with the patient', status: 'incomplete', action: 'quote-accept', why: 'The patient has not decided yet' }];
  const open = fl.items.filter(i => i.status !== 'done' && !(fl.resumed && i.step < 5));
  const surgical = !!(ctx.surgerySuggested || f.quote || f.quoteAccepted || f.caseBooked);
  const keep = (i: FlowItem): boolean => {
    if (i.step <= 3) return !!f.visitDate;
    if (i.step === 4) return i.key === 'quote' ? surgical : !!f.visitDate;
    switch (i.key) {
      case 'quote-accepted': return !!f.quote;
      case 'deposit': case 'case': case 'clearance': return !!(f.quoteAccepted || f.caseBooked);
      case 'pcp': return !!f.clearance?.required;
      case 'docs': return !!f.clearance?.required && !!f.pcpSent;
      case 'asc-sent': case 'asc-confirmed': case 'postop': return !!f.caseBooked;
      default: return true;
    }
  };
  const why: Record<string, string> = { quote: 'Surgery suggested at the consult', 'quote-accepted': 'Quote given', deposit: 'Quote accepted', case: 'Quote accepted', clearance: 'Quote accepted', pcp: 'Clearance required', docs: 'PCP letter sent', 'asc-sent': 'Case booked', 'asc-confirmed': 'Case booked', postop: 'Case booked' };
  return open.filter(keep).map(i => ({ ...i, why: i.why || why[i.key] }));
}
