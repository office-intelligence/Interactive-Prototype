/* Surgery.Vityls v1.3 · the chat workflow page (approved mockup: mockups/src/journey-chat-flow.html). One page for EVERY patient:
   7-dot strip (+ Undecided pill), one-line patient summary, Nightingale's prompt for the current step (flags only what is missing
   or discrepant), chips that LAUNCH the real station workspace in a slide-over, the thread of posted checks, and the checklist
   (critical steps only) behind a toggle. Past dots open their station for editing; every open/edit lands in the audit log. */
import React, { useMemo, useRef, useState } from 'react';
import './flow.css';
import { medRepo, isoDay, ageFrom } from '../../med/record';
import { useActor, useMedTick } from '../../med/ui';
import { useSv } from '../ui';
import { PrintSendButton } from '../v13/PrintSend';
import * as F from './logic';
import { flowFor, flagsFor, flowAudit, logFlow, postedChecks, postCheck, consultVisit, resumeFlow, keepUndecided, flowState } from './store';
import { ModeIcon, modeLabel, startLabel, modeOf } from './apptMode';
import { WsId, wsFor, WS_TITLE } from './Workspaces';
import { openWs } from './WsHost';
import { startRemoteVisit } from './remote';
import { useEffect } from 'react';

const d5 = (iso?: string) => iso ? new Date(iso.length <= 10 ? `${iso}T12:00:00` : iso).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }) : '';
const STC: Record<F.FStatus, string> = { done: 'ok', incomplete: 'inc', due: 'due', overdue: 'ovd' };
export const StatusPill: React.FC<{ s: F.FStatus }> = ({ s }) => <span className={`st ${STC[s]}`} data-testid="flow-status">{F.STATUS_LABEL[s]}</span>;

export const FlowPage: React.FC<{ pid: string }> = ({ pid }) => {
  useMedTick(); const [actor] = useActor(); const { go, toast } = useSv();
  const [, bump] = useState(0); const refresh = () => bump(x => x + 1);
  const p = medRepo.patient(pid); const today = isoDay();
  const fl = flowFor(pid, today); const flags = useMemo(() => flagsFor(pid, fl), [pid, fl]);
  const [ck, setCk] = useState(false); const [hist, setHist] = useState(false);
  useEffect(() => { const h = () => refresh(); window.addEventListener('vityls-med-updated', h); return () => window.removeEventListener('vityls-med-updated', h); }, []);
  if (!p) return <div className="fl" data-testid="flow-none">Patient not found.</div>;
  const v = medRepo.visits(pid).find(x => x.date === today && !/post-?op/i.test(x.visitType)) || consultVisit(pid);
  const st = F.stepDef(fl.step); const nx = F.nextItem(fl); const first = p.name.split(' ')[0];
  const items = F.itemsOf(fl, fl.step); const openIts = items.filter(i => i.status !== 'done');
  /* v1.5 B/D: workspaces open in the one app-wide host, at any time (no gating). */
  const open = (id: WsId, focus?: string, edit?: F.FStep) => openWs({ id, pid, focus, edit, vid: id === 'postop' ? undefined : v?.id });
  const age = ageFrom(p.dob);
  /* ---------- Nightingale's prompt for the current step ---------- */
  const say = (() => {
    if (fl.stopped) { const u = flowState(pid).undecided!; return <>Consultation Performed — <b>Undecided</b> since {d5(u.at)}{u.reason ? ` (${u.reason})` : ''}. The workflow is stopped. If {first} calls back, resume at Step 5: Steps 1–4 stay on file.</>; }
    switch (fl.step) {
      case 1: return <>{v ? <>{first} is booked for <b>{v.visitType.toLowerCase()}</b> on {d5(v.date)} at {v.time}.</> : <>{first} has no visit booked.</>} {items.find(i => i.key === 'forms')?.status !== 'done' ? 'Registration forms have not gone out yet.' : 'Forms are out.'}</>;
      case 2: return <>{v && v.date === today ? fl.remote ? <>{first} has a <b>{modeLabel(modeOf(v))}</b> today at {v.time} ({v.visitType.toLowerCase()}).</> : <>{first} is here today at {v.time} for {v.visitType.toLowerCase()}.</> : <>Front desk for {first}'s {v?.visitType.toLowerCase() || 'visit'}.</>} {openIts.length ? `${openIts.length === 1 ? 'One thing' : `${openIts.length} things`} left at the front desk.` : ''}</>;
      case 3: return <>{first} is ready for the nurse.{fl.remote ? ' Remote visit: no vitals in the room; record the reason and notes.' : ''}</>;
      case 4: return <>{first} is ready for {p.primaryProvider.replace(/,.*$/, '')}. The doctor workspace opens full screen.</>;
      case 5: if (F.FLOW_MED) return <>{first} is ready for checkout. {nx ? <>Next: <b>{nx.label[0].toLowerCase() + nx.label.slice(1)}</b>.</> : 'Checkout is complete.'}</>;
        return <>Consult done. {nx ? <>Next: <b>{nx.label[0].toLowerCase() + nx.label.slice(1)}</b>.</> : 'Booking and clearance are complete.'}</>;
      case 6: return <>The ASC needs the case package before surgery. {nx ? <>Next: <b>{nx.label[0].toLowerCase() + nx.label.slice(1)}</b>{nx.due ? ` (due ${d5(nx.due)})` : ''}.</> : 'All set with the ASC.'}</>;
      default: return <>Post-op: routine visits with reminders and confirmations only.</>;
    }
  })();
  const chips: { label: string; run: () => void; pri?: boolean; tid: string }[] = [];
  if (fl.stopped) { chips.push({ label: 'Patient called back · resume at Step 5', pri: true, tid: 'flow-resume', run: () => { resumeFlow(pid, actor.name, actor.role); postCheck(pid, 'Workflow resumed at Step 5'); refresh(); } }); chips.push({ label: 'Keep undecided', tid: 'flow-keep', run: () => { keepUndecided(pid, actor.name, actor.role); toast('Kept as Undecided'); refresh(); } }); }
  else {
    if (fl.step === 2 && fl.remote && v && v.date === today && v.step === 'scheduled') chips.push({ label: startLabel(modeOf(v)), pri: true, tid: 'flow-start-remote', run: () => { startRemoteVisit(v, actor.name, actor.role); logFlow(pid, 2, `${startLabel(modeOf(v))}: started (simulated)`, actor.name, actor.role); open('doctor'); } });
    const seen = new Set<string>();
    if (nx) { const w = wsFor(nx.action); seen.add(w); chips.push({ label: `Open ${WS_TITLE[w].replace(/^Front desk/, 'front desk').replace(/^Nurse/, 'nurse').replace(/^Doctor/, 'doctor').replace(/^Booking/, 'booking').replace(/^Scheduling/, 'scheduling').replace(/^Post-op/, 'post-op')}`, pri: !chips.length, tid: 'flow-open-ws', run: () => open(w, nx.key) }); }
    openIts.filter(i => i !== nx).forEach(i => { const w = wsFor(i.action); if (seen.has(w)) return; seen.add(w); chips.push({ label: i.label, tid: `flow-chip-${i.key}`, run: () => open(w, i.key) }); });
    if (fl.step === 4 && !fl.undecided) chips.push({ label: 'Consultation Performed — Undecided', tid: 'flow-undecided', run: () => open('doctor', 'undecided') });
  }
  const checks = postedChecks(pid); const cl = F.checklist(fl); const ckDone = cl.filter(r => r.status === 'done').length;
  const aud = flowAudit(pid).slice().reverse();
  return <div className="fl" data-testid="flow-page" data-step={fl.step}>
    <div className="cw">
      <nav className="strip" aria-label="Workflow steps" data-testid="flow-strip">
        {F.FSTEPS.map(s => { const done = F.stepDone(fl, s.n) && s.n < fl.step; const cur = s.n === fl.step; const can = true; // v1.5 D: any step opens at any time; Nightingale only tracks
          return <button type="button" key={s.n} className={`dt${done ? ' done' : ''}${cur ? ' cur' : ''}`} disabled={!can} data-testid={`flow-dot-${s.n}`} aria-current={cur ? 'step' : undefined} aria-label={`Step ${s.n}, ${s.title}${cur ? ', current' : done ? ', done, open to edit' : ', open'}`}
            onClick={() => open(wsFor(F.itemsOf(fl, s.n)[0]?.action || (s.n === 7 ? 'postop' : 'book')), undefined, s.n < fl.step ? s.n : undefined)}><b /><span>{s.short}</span></button>; })}
        <span className={`und${fl.undecided ? ' on' : ''}`} data-testid="flow-undecided-pill">{fl.resumed && !fl.undecided ? 'Resumed' : 'Undecided'}</span>
      </nav>
      <div className="pl" data-testid="flow-summary">
        <span className="nm">{p.name}</span><span className="m">{age}{p.sex[0]} · {p.id}{v ? <> · <ModeIcon mode={modeOf(v)} /> {v.visitType} {d5(v.date)}</> : ''}</span>
        {p.allergies.length > 0 && <span className="alg">Allergy: {p.allergies.join(', ')}</span>}
        <span className="r"><PrintSendButton p={p} /><button type="button" className="btn sm" onClick={() => go({ type: 'chart', pid })} data-testid="flow-open-chart">Open chart</button></span>
      </div>
      <div className="th" data-testid="flow-thread">
        {checks.map((c, i) => <div key={i} className="chk-me" data-testid="flow-check">✓ {c.text}<span className="t" data-testid="flow-check-at">{new Date(c.at).toLocaleString('en-US', { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' })}</span></div>)}
        <div className="ng"><span className="av" aria-hidden>N</span><div className="bub" data-testid="flow-prompt"><div style={{ fontSize: 12, color: 'var(--mu)', marginBottom: 4 }}>Step {fl.step} · {st.title} · {st.owner}</div>{say}
          {flags.map((f, i) => <div key={i} className="flag" data-testid={`flow-flag-${f.kind}`}><b>{f.kind === 'missing' ? 'Missing' : 'Discrepancy'}:</b> {f.text}</div>)}</div></div>
        {chips.length > 0 && <div className="chips">{chips.map(c => <button type="button" key={c.tid} className={`chp${c.pri ? ' pri' : ''}`} onClick={c.run} data-testid={c.tid}>{c.label}</button>)}</div>}
      </div>
      <div className="cktog"><button type="button" className="btn sm" onClick={() => setCk(x => !x)} data-testid="flow-checklist-toggle">{ck ? 'Hide' : 'Show'} checklist ({ckDone}/{cl.length})</button>
        <button type="button" className="btn sm" onClick={() => setHist(x => !x)} data-testid="flow-history-toggle">{hist ? 'Hide' : 'Show'} change log ({aud.length})</button></div>
      {ck && <div className="ckl" data-testid="flow-checklist">{cl.map(r => <div key={r.key}><span className={`o${r.status === 'done' ? '' : ' x'}`}>{r.status === 'done' ? '✓' : ''}</span>{r.label}<span className="s"><StatusPill s={r.status} /></span></div>)}</div>}
      {hist && <div className="ckl" data-testid="flow-history">{aud.length ? aud.slice(0, 40).map((a, i) => <div key={i} className="aud">{new Date(a.at).toLocaleString('en-US', { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' })} · {a.by} · {a.step ? `Step ${a.step} · ` : ''}{a.what}</div>) : <div className="aud">No changes logged yet.</div>}</div>}
    </div>
  </div>;
};
export default FlowPage;
