/* Surgery.Vityls v1.3 · fictional seed for the 7-step workflow demos (all names fictional; no real doctors).
   A  Tomas Exampleton (existing, today 1:00 PM) — Step 2 front desk: registration forms back from the Portal with a blank field; card images missing.
   B  Ruth Calder — Step 5: consult signed 2 days ago, quote v1 presented; deposit, booking, clearance (58, hypertension) next.
   C  Mary James (existing v1.2 seed) — Step 6 ASC: ECG missing from the PCP packet, metformin dose differs.
   D  Lena Ortiz — Consultation Performed — Undecided since July (second opinion), quote expired; she calls back today.
   Video: Priya Nair, new-patient Video Consult today 11:30. Phone: Ben Cho, Phone Consult today 3:15 PM (Medical gets two too). */
import { isMedical } from '../../edition';
import { repo } from '../../v6/dataLayer';
import { medRepo, MedPatient, MedVisit, isoDay, addDays, uid } from '../../med/record';
import { svRead, svWrite, saveNurseAdmission } from '../store';
import { createQuote, setQuoteStatus } from '../quotes';
import { setFlowState } from './store';
import { startJourney, journeysFor } from '../journey/store';

const PATEL = 'Sam Patel, MD';
/** Seeded example quotes get their own numbers so the practice's real sequence (Q-YYYY-0001…) starts untouched. */
const renumber = (id: string, number: string) => svWrite('quotes', svRead<any[]>('quotes', []).map(x => x.id === id ? { ...x, number } : x));
export function ensureFlowSeed() {
  if (svRead<boolean>('flow-seeded-v13', false)) return;
  const T = isoDay(); const iso = (d: number, h = '10:00') => new Date(`${addDays(T, d)}T${h}:00`).toISOString();
  const mk = (id: string, name: string, dob: string, sex: MedPatient['sex'], extra: Record<string, unknown> = {}) => { if (!medRepo.patient(id)) medRepo.savePatient({ id, name, dob, sex, phone: '(555) 014-' + id.slice(-4), email: name.toLowerCase().replace(' ', '.') + '@example.test', language: 'English', allergies: [], primaryProvider: PATEL, careTeam: [{ name: PATEL, role: 'Surgeon' }, { name: 'Elena Marsh, MD (fictional)', role: 'Primary care (outside)', phone: '(555) 014-7700' }], insurance: 'Self-pay (cosmetic)', fictional: true, paymentType: 'Self-pay', firstName: name.split(' ')[0], lastName: name.split(' ')[1], ...extra } as MedPatient); };
  const visit = (v: Partial<MedVisit> & { id: string; patientId: string; date: string; time: string; visitType: string; reason: string }, mode?: 'video' | 'phone') => { if (!medRepo.visit(v.id)) medRepo.saveVisit({ durationMin: 30, provider: PATEL, room: mode === 'video' ? 'Video' : mode === 'phone' ? 'Phone' : 'Exam 2', step: 'scheduled', problemIds: [], createdAt: iso(-10), createdBy: 'Taylor Brooks', ...(mode ? { mode } : {}), ...v } as MedVisit); };
  const packet = (pid: string, d: number) => svWrite('forms-packets', [...svRead<any[]>('forms-packets', []), { id: uid('fp'), patientId: pid, forms: ['Patient_Registration.html', 'Admission_Form.html', 'Medical_History.html'], portal: true, email: true, text: false, message: 'Welcome! Please complete your forms before your visit.', link: 'https://portal.example.test/forms (simulated)', sentAt: iso(d), by: 'Taylor Brooks', role: 'Front desk', transport: 'simulated-outbox' }]);
  const portalForm = (pid: string, file: string, fields: [string, string, string][], d: number) => { const values: Record<string, string> = {}; const labels: Record<string, string> = {}; fields.forEach(([k, l, v]) => { values[k] = v; labels[k] = l; });
    repo.saveForm({ ...repo.getForm(`portal-forms:${pid}`, file), values, labels, status: 'locked', lockedAt: iso(d, '20:15'), updatedAt: iso(d, '20:15'), updatedBy: `${medRepo.patient(pid)?.name} (Portal)` } as any); };
  const own = (pid: string) => { setFlowState(pid, s => ({ ...s, since: '' })); if (!journeysFor(pid).length) { const p = medRepo.patient(pid); if (p) try { startJourney(p, { service: 'Consultation' }, 'Fictional seed', 'System', iso(-120)); } catch { /* */ } } };

  if (!isMedical) {
    // A · Tomas: portal forms returned last night; one blank field; cards not captured yet
    const tomas = medRepo.patient('MED-1007');
    if (tomas) { packet(tomas.id, -12);
      portalForm(tomas.id, 'Patient_Registration.html', [['firstName', 'First Name', 'Tomas'], ['lastName', 'Last Name', tomas.name.split(' ').slice(-1)[0]], ['dob', 'Date of Birth', tomas.dob], ['gender', 'Gender', tomas.sex], ['preferredLanguage', 'Preferred Language', 'English'], ['phone', 'Phone', tomas.phone], ['email', 'Email', tomas.email || 'tomas@example.test'], ['address1', 'Street Address', '18 Harbor Lane'], ['city', 'City', 'Bayview'], ['state', 'State', 'CA'], ['zip', 'ZIP', '94000'], ['emergencyName', 'Emergency Contact Name', 'Rosa Exampleton'], ['emergencyRelationship', 'Relationship', 'Spouse'], ['emergencyPhone', 'Emergency Contact Phone', ''], ['referralSource', 'How did you hear about us?', 'Friend']], -1);
      portalForm(tomas.id, 'Admission_Form.html', [['pt_name', 'Patient name', tomas.name], ['consent', 'Consent to treatment', 'yes'], ['pharmacy', 'Preferred pharmacy', 'Harbor Drug (fictional)']], -1);
      portalForm(tomas.id, 'Medical_History.html', [['pt_name', 'Patient name', tomas.name], ['allergies', 'Allergies', 'None known'], ['surgeries', 'Past surgeries', 'Nasal fracture repair (age 19)']], -1); }

    // B · Ruth Calder at Step 5
    mk('MED-2071', 'Ruth Calder', '04/11/1968', 'Female', { referralSource: 'Physician referral' });
    if (!medRepo.problems('MED-2071').length) medRepo.saveProblem({ id: 'pr-rc1', patientId: 'MED-2071', description: 'Hypertension', conditionType: 'hypertension' as any, status: 'active', recordedAt: iso(-2), recordedBy: 'Casey Morgan, RN', source: 'Medical history (Portal)' }, 'Fictional seed');
    if (!medRepo.meds('MED-2071').length) medRepo.saveMed({ id: 'md-rc1', patientId: 'MED-2071', name: 'Amlodipine', dose: '5 mg', frequency: 'daily', status: 'active', problemIds: ['pr-rc1'], source: 'Medical history (Portal)', recordedAt: iso(-2), recordedBy: 'Casey Morgan, RN' } as any, 'Fictional seed', 'med.add');
    visit({ id: 'visit-ruth-consult', patientId: 'MED-2071', date: addDays(T, -2), time: '10:30 AM', visitType: 'New patient consultation', reason: 'Rhinoplasty consultation', step: 'complete', createdAt: iso(-14) });
    packet('MED-2071', -14);
    medRepo.addVitals({ id: 'vit-rc1', patientId: 'MED-2071', visitId: 'visit-ruth-consult', at: iso(-2, '10:38'), by: 'Casey Morgan, RN', source: 'manual', bpSys: 138, bpDia: 86, hr: 78, rr: 16, spo2: 98, heightIn: 64, weightLb: 162 });
    saveNurseAdmission({ visitId: 'visit-ruth-consult', patientId: 'MED-2071', chiefComplaint: 'Rhinoplasty consultation (dorsal hump, droopy tip)', pain: '0', vitalsId: 'vit-rc1', allergiesConfirmed: true, medsReviewed: true, anticoagulantLastDose: '', npo: '', escort: '', fallRisk: '', nurseNote: 'Prior nasal fracture age 19.', by: 'Casey Morgan, RN', role: 'RN', at: iso(-2, '10:40') } as any);
    medRepo.saveNote({ visitId: 'visit-ruth-consult', template: 'Ambient scribe draft (simulated) · reviewed by clinician', subjective: '58-year-old woman seen for rhinoplasty consultation. Dorsal hump and tip ptosis; prior nasal fracture at 19.', objective: 'Dorsal hump, tip ptosis, mild septal deviation to the left. (Simulated exam.)', assessment: 'Candidate for open rhinoplasty (surgeon’s assessment, simulated).', plan: '• Open rhinoplasty at Harborview Surgery Center.\n• Pre-op clearance with her PCP (age 58, hypertension).', status: 'signed', updatedAt: iso(-2, '11:20'), updatedBy: PATEL, signedBy: PATEL, signedAt: iso(-2, '11:22'), addenda: [] });
    svWrite('scribe', { ...svRead<Record<string, any>>('scribe', {}), 'visit-ruth-consult': { visitId: 'visit-ruth-consult', status: 'stopped', startedAt: iso(-2, '10:50'), startedBy: PATEL, stoppedAt: iso(-2, '11:10'), lines: [{ at: iso(-2, '10:50'), speaker: 'Surgeon', text: 'Good morning Ms. Calder. Tell me what brings you in today.' }], draft: { hpi: '', exam: '', assessment: '', plan: '' }, suggestions: [] } });
    svWrite('body-charts', [...svRead<any[]>('body-charts', []), { id: 'bc-rc1', seriesId: 'bcs-rc1', version: 1, patientId: 'MED-2071', visitId: 'visit-ruth-consult', diagram: 'nose', title: 'Nose · planned changes', strokes: [{ c: '#b23b32', w: 3, pts: [200, 160, 240, 150, 280, 160] }], texts: [{ x: 210, y: 130, t: 'reduce hump', c: '#b23b32' }], by: PATEL, role: 'Surgeon', at: iso(-2, '11:00'), example: true }]);
    const ph = (view: 'frontal' | 'profile', area: string, v: string) => ({ id: uid('ph'), patientId: 'MED-2071', visitId: 'visit-ruth-consult', synth: { view, tone: 0, hair: 1, procedure: 'rhino', phase: 'before', date: addDays(T, -2), label: `${area} · ${v}` }, phase: 'before', date: addDays(T, -2), area, view: v, note: 'Fictional example photo (generated illustration).', by: PATEL, role: 'Surgeon', at: iso(-2, '11:05'), example: true });
    svWrite('photos', [...svRead<any[]>('photos', []), ph('frontal', 'Face', 'Frontal'), ph('profile', 'Nose', 'Profile right')]);
    const line = (label: string, cat: string, unit: number) => ({ id: uid('ql'), cat, label, qty: 1, unit });
    const q = createQuote('MED-2071', { date: addDays(T, -2), validUntil: addDays(T, 28), procedure: 'Rhinoplasty (open)', surgeon: PATEL, lines: [line('Surgeon fee · open rhinoplasty', 'Surgeon fee', 7200), line('Facility fee · Harborview Surgery Center', 'Facility fee', 2600), line('Anesthesia', 'Anesthesia', 1600)] as any, terms: 'Deposit due to book; balance due 14 days before surgery (fictional).', financing: '', note: '' }, PATEL, 'Plastic surgeon', 'Presented');
    renumber(q.id, 'Q-EX-2071');
    svWrite('patient-payments', [...svRead<any[]>('patient-payments', []), { id: uid('pay'), receipt: 'R-30071', patientId: 'MED-2071', amount: 150, method: 'card', card: { brand: 'Visa', last4: '4242', exp: '08/29' }, reference: 'terminal (simulated)', reason: 'Consultation fee', takenBy: 'Taylor Brooks', role: 'Front desk', at: iso(-2, '10:25'), channel: 'in person', applied: [], status: 'posted (simulated)' }]);
    own('MED-2071');

    // D · Lena Ortiz, Undecided since July
    mk('MED-2072', 'Lena Ortiz', '09/02/1979', 'Female', { referralSource: 'Google search' });
    visit({ id: 'visit-lena-consult', patientId: 'MED-2072', date: addDays(T, -98), time: '02:00 PM', visitType: 'New patient consultation', reason: 'Facelift consultation', step: 'complete', createdAt: iso(-110) });
    packet('MED-2072', -110);
    medRepo.addVitals({ id: 'vit-lo1', patientId: 'MED-2072', visitId: 'visit-lena-consult', at: iso(-98, '14:08'), by: 'Casey Morgan, RN', source: 'manual', bpSys: 122, bpDia: 76, hr: 70, rr: 14, spo2: 99, heightIn: 66, weightLb: 140 });
    saveNurseAdmission({ visitId: 'visit-lena-consult', patientId: 'MED-2072', chiefComplaint: 'Facelift consultation', pain: '0', vitalsId: 'vit-lo1', allergiesConfirmed: true, medsReviewed: true, anticoagulantLastDose: '', npo: '', escort: '', fallRisk: '', nurseNote: '', by: 'Casey Morgan, RN', role: 'RN', at: iso(-98, '14:10') } as any);
    medRepo.saveNote({ visitId: 'visit-lena-consult', template: 'Consultation', subjective: '47-year-old woman seen for facelift consultation.', objective: 'Jowling and neck laxity. (Simulated exam.)', assessment: 'Candidate for facelift / necklift.', plan: '• Patient will consider; second opinion planned.', status: 'signed', updatedAt: iso(-98, '15:00'), updatedBy: PATEL, signedBy: PATEL, signedAt: iso(-98, '15:02'), addenda: [] });
    svWrite('body-charts', [...svRead<any[]>('body-charts', []), { id: 'bc-lo1', seriesId: 'bcs-lo1', version: 1, patientId: 'MED-2072', visitId: 'visit-lena-consult', diagram: 'face-front', title: 'Face · plan', strokes: [{ c: '#b23b32', w: 3, pts: [180, 300, 220, 340, 260, 350] }], texts: [], by: PATEL, role: 'Surgeon', at: iso(-98, '14:40'), example: true }]);
    svWrite('photos', [...svRead<any[]>('photos', []), { id: uid('ph'), patientId: 'MED-2072', visitId: 'visit-lena-consult', synth: { view: 'frontal', tone: 1, hair: 3, procedure: 'facelift', phase: 'before', date: addDays(T, -98), label: 'Face · Frontal' }, phase: 'before', date: addDays(T, -98), area: 'Face', view: 'Frontal', note: 'Fictional example photo (generated illustration).', by: PATEL, role: 'Surgeon', at: iso(-98, '14:45'), example: true }]);
    const lq = createQuote('MED-2072', { date: addDays(T, -98), validUntil: addDays(T, -6), procedure: 'Facelift / necklift', surgeon: PATEL, lines: [line('Surgeon fee · facelift / necklift', 'Surgeon fee', 10800), line('Facility fee', 'Facility fee', 2600), line('Anesthesia', 'Anesthesia', 1400)] as any, terms: 'Valid 90 days (fictional).', financing: '', note: '' }, PATEL, 'Plastic surgeon', 'Presented');
    renumber(lq.id, 'Q-EX-2072');
    svWrite('patient-payments', [...svRead<any[]>('patient-payments', []), { id: uid('pay'), receipt: 'R-29812', patientId: 'MED-2072', amount: 150, method: 'card', card: { brand: 'Mastercard', last4: '5100', exp: '02/28' }, reference: 'terminal (simulated)', reason: 'Consultation fee', takenBy: 'Taylor Brooks', role: 'Front desk', at: iso(-98, '13:55'), channel: 'in person', applied: [], status: 'posted (simulated)' }]);
    own('MED-2072'); setFlowState('MED-2072', s => ({ ...s, undecided: { at: iso(-98, '15:05'), by: PATEL, reason: 'second opinion' } }));
    svWrite('flow-audit', [...svRead<any[]>('flow-audit', []), { at: iso(-98, '15:05'), by: PATEL, role: 'Plastic surgeon', pid: 'MED-2072', step: 4, what: 'Consultation Performed — Undecided (second opinion). Workflow stopped.' }]);
    medRepo.addMessage({ id: 'msg-lo1', patientId: 'MED-2072', from: 'patient', author: 'Lena Ortiz', text: 'Hi, I would like to go ahead with the facelift after all. What are the next steps?', at: iso(0, '08:12') } as any);

    // Video + phone consults today
    mk('MED-2073', 'Priya Nair', '12/05/1990', 'Female', { referralSource: 'Instagram' });
    visit({ id: 'visit-priya-video', patientId: 'MED-2073', date: T, time: '11:30 AM', visitType: 'New patient consultation', reason: 'Rhinoplasty consultation (video)', createdAt: iso(-5) }, 'video'); packet('MED-2073', -5); own('MED-2073');
    mk('MED-2074', 'Ben Cho', '07/19/1972', 'Male', { referralSource: 'Returning patient' });
    visit({ id: 'visit-ben-phone', patientId: 'MED-2074', date: T, time: '03:15 PM', durationMin: 15, visitType: 'Follow-up visit', reason: 'Questions about scar care (phone)', createdAt: iso(-3) }, 'phone'); packet('MED-2074', -3); own('MED-2074');
  } else {
    // Medical: one video and one phone visit today on existing fictional patients
    const ps = medRepo.patients().slice(0, 2);
    if (ps[0]) visit({ id: 'visit-med-video', patientId: ps[0].id, date: T, time: '11:30 AM', durationMin: 20, provider: ps[0].primaryProvider, visitType: 'Follow-up visit', reason: 'Blood pressure follow-up (video)', createdAt: iso(-4) }, 'video');
    if (ps[1]) visit({ id: 'visit-med-phone', patientId: ps[1].id, date: T, time: '03:15 PM', durationMin: 15, provider: ps[1].primaryProvider, visitType: 'Follow-up visit', reason: 'Lab results call (phone)', createdAt: iso(-2) }, 'phone');
  }
  svWrite('flow-seeded-v13', true);
}
