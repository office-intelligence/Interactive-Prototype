/* Surgery.Vityls v1.3 · Appointment type (Kevin, Oct 20): In Office, Video Consult, Phone Consult. Surgery and Medical only
   (ASC.Vityls has its own app and never shows this). Stored on the visit as `mode`; visits without one are In Office.
   Video and phone visits skip Arrived and rooming: the front desk sees "Start video visit" / "Start phone visit" (simulated). */
import React from 'react';
import { Building2, Video, Phone } from 'lucide-react';
import type { MedVisit } from '../../med/record';

export type ApptMode = 'office' | 'video' | 'phone';
export const MODES: { id: ApptMode; label: string; short: string }[] = [
  { id: 'office', label: 'In Office', short: 'In office' }, { id: 'video', label: 'Video Consult', short: 'Video' }, { id: 'phone', label: 'Phone Consult', short: 'Phone' }];
export const modeOf = (v?: Pick<MedVisit, 'id'> & { mode?: ApptMode } | null): ApptMode => (v && (v as any).mode) || 'office';
export const modeLabel = (m: ApptMode) => MODES.find(x => x.id === m)!.label;
export const isRemote = (v?: (Pick<MedVisit, 'id'> & { mode?: ApptMode }) | null) => modeOf(v) !== 'office';
/** What the front desk taps instead of Arrived for a remote visit. */
export const startLabel = (m: ApptMode) => m === 'video' ? 'Start video visit' : m === 'phone' ? 'Start phone visit' : 'Arrived';

export const ModeIcon: React.FC<{ mode: ApptMode; size?: number; label?: boolean; testId?: string }> = ({ mode, size = 13, label, testId = 'appt-mode-icon' }) => {
  const I = mode === 'video' ? Video : mode === 'phone' ? Phone : Building2;
  return <span className={`v13-mode ${mode}`} title={modeLabel(mode)} aria-label={modeLabel(mode)} data-testid={testId} data-mode={mode} style={{ display: 'inline-flex', alignItems: 'center', gap: 4, flex: 'none' }}><I size={size} aria-hidden="true" />{label && <span>{MODES.find(x => x.id === mode)!.short}</span>}</span>;
};

/** ASC.Vityls v8.0: the ASC has no telemedicine appointment types, so no mode picker (every case is in person). */
export const ModePicker: React.FC<{ value: ApptMode; onChange: (m: ApptMode) => void; disabled?: boolean; prefix: string }> = ({ value, onChange, disabled, prefix }) => (typeof window !== 'undefined' && (window as any).__vitylsAsc2) ? null as any :
  <div className="sm:col-span-2"><span className="sv-label">Appointment type</span>
    <div className="flex flex-wrap gap-1.5" role="radiogroup" aria-label="Appointment type" data-testid={`${prefix}-mode`}>{MODES.map(m => <button key={m.id} type="button" role="radio" aria-checked={value === m.id} disabled={disabled} onClick={() => onChange(m.id)}
      className="text-[13px] px-3 py-1.5 rounded inline-flex items-center gap-1.5" style={{ minHeight: 40, background: value === m.id ? '#eaf3ee' : '#fff', border: `1px solid ${value === m.id ? '#2e7d4f' : '#d8cfc4'}`, fontWeight: value === m.id ? 700 : 400 }} data-testid={`${prefix}-mode-${m.id}`}><ModeIcon mode={m.id} testId="mode-opt-icon" />{m.label}</button>)}</div>
    {value !== 'office' && <p className="sv-small sv-muted mt-1">{value === 'video' ? 'The patient gets a video link in the reminders (simulated).' : 'The office calls the patient at the booked time.'} No arrival or rooming at the front desk.</p>}</div>;
