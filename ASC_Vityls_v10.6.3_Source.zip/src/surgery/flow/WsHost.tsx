/* Surgery.Vityls v1.5 B · ONE host for the slide-over workspaces, mounted once in the app. Every entry point (Today schedule chips,
   "Continue · …", the appointment panel, the chart, the chat, the To-do lists, the workflow page) opens a workspace by firing
   `flow-open-ws` { id, pid, vid?, focus?, edit? }. Nothing is gated: any workspace opens at any time. On Save & close the host posts a
   check to the patient's journey for every item that turned Done, and logs it. */
import React, { useEffect, useRef, useState } from 'react';
import './flow.css';
import { useActor } from '../../med/ui';
import { useSv } from '../ui';
import * as F from './logic';
import { flowFor, postCheck, logFlow } from './store';
import { Workspace, WsId } from './Workspaces';
export interface WsOpen { id: WsId; pid: string; vid?: string; focus?: string; edit?: F.FStep }
export const openWs = (d: WsOpen) => window.dispatchEvent(new CustomEvent('flow-open-ws', { detail: d }));
export const WsHost: React.FC = () => {
  const [actor] = useActor(); const { toast } = useSv(); const [ws, setWs] = useState<WsOpen | null>(null); const snap = useRef<Set<string>>(new Set());
  useEffect(() => { const h = (e: Event) => { const d = (e as CustomEvent).detail as WsOpen; if (!d?.pid || !d.id) return; snap.current = new Set(flowFor(d.pid).items.filter(i => i.status === 'done').map(i => i.key));
    if (d.edit) logFlow(d.pid, d.edit, `Opened Step ${d.edit} (${F.stepDef(d.edit).short}) for editing`, actor.name, actor.role); setWs(null); setTimeout(() => setWs(d), 0); };
    window.addEventListener('flow-open-ws', h); return () => window.removeEventListener('flow-open-ws', h); }, [actor.name, actor.role]);
  if (!ws) return null;
  const close = () => { const now = flowFor(ws.pid); const fresh = now.items.filter(i => i.status === 'done' && !snap.current.has(i.key));
    fresh.forEach(i => { postCheck(ws.pid, i.label); logFlow(ws.pid, i.step, `${i.label}: done`, actor.name, actor.role); });
    if (ws.edit && !fresh.length) logFlow(ws.pid, ws.edit, `Closed Step ${ws.edit} (no changes)`, actor.name, actor.role);
    if (fresh.length) toast(`✓ ${fresh.map(i => i.label).join(' · ')}`); setWs(null); window.dispatchEvent(new Event('vityls-med-updated')); };
  return <div className="fl" data-testid="ws-host"><Workspace key={`${ws.id}:${ws.pid}:${ws.vid || ''}`} id={ws.id} pid={ws.pid} vid={ws.vid} focus={ws.focus} edit={ws.edit} onClose={close} /></div>;
};
