/* Surgery.Vityls v1.5 #1 · "Save & close" is the only way out of a workspace, and it saves whatever was typed. Sections with
   typed-but-unsaved input register a saver here; Save & close (and Esc / the scrim) runs every saver, then closes. */
import { useEffect, useRef } from 'react';
const savers = new Set<{ current: () => void }>();
export function useWsSaver(fn: () => void) { const r = useRef(fn); r.current = fn; useEffect(() => { savers.add(r); return () => { savers.delete(r); }; }, []); }
export function runWsSavers(): number { let n = 0; savers.forEach(s => { try { s.current(); n++; } catch (e) { console.warn('ws saver', e); } }); return n; }
