/* v1.3 · Start a video or phone visit (simulated). No arrival or rooming: the visit opens straight at the Doctor step.
   Times are stamped like an arrival so the day list, journey and reports stay consistent. Nothing is dialled or streamed. */
import { repo } from '../../v6/dataLayer';
import { medRepo, MedVisit } from '../../med/record';
import { checkInVisit } from '../SurgeryStation';
import { modeOf, modeLabel } from './apptMode';
export function startRemoteVisit(v: MedVisit, by: string, role: string) {
  const m = modeOf(v); checkInVisit(v, by, role); const cur = medRepo.visit(v.id)!;
  if (cur.step === 'scheduled' || cur.step === 'check-in' || cur.step === 'rooming') medRepo.saveVisit({ ...cur, step: 'provider' });
  repo.audit({ caseId: v.id, user: by, role, action: 'visit.remote.start' as any, detail: `${modeLabel(m)} started (simulated${m === 'video' ? ' video link' : ' call'}); arrival and rooming not needed` });
}
