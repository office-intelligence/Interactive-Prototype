/*
 * Send to ASC (simulated network link). The surgery office fills a scheduling form, picks the supporting documents,
 * picks the surgery center (a surgeon may operate at several), and sends one packet. A simulated "received" event
 * then files every item into the patient's chart at that ASC. Nothing leaves the browser in this build.
 * The shape here is the backend contract documented for Henry in the v0.2 changelog.
 */
import { isMedical } from '../edition';
import { repo } from '../v6/dataLayer';
import { VITYLS_FORM_CATALOG } from '../data/formWorkspaceCatalog';
import { medRepo, MedPatient, MedVisit, patientKey, uid, usDate, vitalsText, fmtDateTime } from '../med/record';
import { networkRepo, NetworkDocument } from '../med/network';
import { getSettings } from '../med/settings';
import { svRead, svWrite, requestBooking, updateBooking, checkoutOrders, nurseAdmission, surgicalHistory, scribeSession } from './store';
import { labSlips } from './nightingale';

const alText = (x: unknown) => Array.isArray(x) ? x.join(', ') : String(x || '');
export interface AscFacility { id: string; name: string; city: string; active: boolean; primary?: boolean }
export const DEFAULT_FACILITIES: AscFacility[] = [
  { id: 'asc-harborview', name: 'Harborview Surgery Center (fictional)', city: 'Harbor City', active: true, primary: true },
  { id: 'asc-bayside', name: 'Bayside Outpatient Surgery (fictional)', city: 'Bayside', active: true },
  { id: 'asc-coastline', name: 'Coastline Surgical Pavilion (fictional)', city: 'Coastline', active: true },
];
/** Medical.Vityls has no ASC: no facilities, no packets. */
export const ascFacilities = () => isMedical ? [] : svRead<AscFacility[]>('asc-facilities', DEFAULT_FACILITIES);
export const saveFacilities = (l: AscFacility[]) => svWrite('asc-facilities', l);
/** Block time seeded in this build belongs to the primary facility (shown as getSettings().ascName elsewhere). */
export const isPrimary = (f: AscFacility) => !!f.primary;

export type PacketDocKind = 'note' | 'clearance' | 'lab' | 'vitals' | 'meds' | 'allergy' | 'problems' | 'history' | 'form' | 'nurse' | 'intake' | 'scribe';
export interface PacketDoc { id: string; kind: PacketDocKind; title: string; detail: string; text: string; recommended: boolean }
export interface SchedulingForm {
  procedure: string; cpt: string; diagnosis: string; icd10: string; laterality: 'N/A' | 'Left' | 'Right' | 'Bilateral';
  anesthesia: 'General' | 'MAC / sedation' | 'Regional' | 'Local' | 'Surgeon to discuss'; durationMin: number;
  blockId: string; preferredDate: string; preferredTime: string; admission: 'Outpatient (same day)' | '23-hour observation';
  equipment: string; implants: string; specialNeeds: string; latexAllergy: boolean; allergies: string; notes: string;
}
export interface AscPacket {
  id: string; patientId: string; visitId: string; caseId: string; facilityId: string; facilityName: string; surgeon: string;
  form: SchedulingForm; docs: { id: string; kind: PacketDocKind; title: string; detail: string }[];
  sentBy: string; sentRole: string; sentAt: string; status: 'sent' | 'received'; receivedAt?: string; ascChartId?: string;
}
export const ascPackets = (pid?: string) => { if (isMedical) return [] as AscPacket[]; const l = svRead<AscPacket[]>('asc-packets', []); return pid ? l.filter(x => x.patientId === pid) : l; };
const savePackets = (l: AscPacket[]) => svWrite('asc-packets', l);

/** Every document the office could include, built from the chart. "recommended" ones are pre-ticked. */
export function availableDocs(p: MedPatient, v: MedVisit): PacketDoc[] {
  const out: PacketDoc[] = [];
  const notes = medRepo.visits(p.id).map(x => ({ x, n: medRepo.note(x.id) })).filter(y => y.n && (y.n.status === 'signed' || y.x.id === v.id)).sort((a, b) => b.x.date.localeCompare(a.x.date));
  notes.forEach(({ x, n }) => out.push({ id: `note:${x.id}`, kind: 'note', title: `${x.visitType} note · ${usDate(x.date)}`, detail: n!.status === 'signed' ? `signed by ${n!.signedBy}` : 'draft (not signed)', recommended: x.id === v.id && n!.status === 'signed', text: `${x.visitType} — ${usDate(x.date)} — ${x.provider}\nS: ${n!.subjective}\nO: ${n!.objective}\nA: ${n!.assessment}\nP: ${n!.plan}\n${n!.status === 'signed' ? `Signed ${n!.signedBy} ${n!.signedAt}` : 'DRAFT'}` }));
  checkoutOrders().filter(o => o.patientId === p.id && o.kind === 'clearance').forEach(o => out.push({ id: `clear:${o.id}`, kind: 'clearance', title: 'Pre-op clearance request', detail: `${o.text}${o.status === 'done' ? ' · letter printed' : ' · to do'}`, recommended: true, text: `${o.text}\n${o.detail}` }));
  labSlips(p.id).forEach((s, i) => out.push({ id: `lab:${s.date}`, kind: 'lab', title: `Lab results · ${usDate(s.date)}`, detail: s.labs.map(l => l.test.replace('Hemoglobin A1c', 'A1c')).join(', '), recommended: i === 0, text: s.labs.map(l => `${l.test}: ${l.value} ${l.unit || ''} (${l.reportedRange || 'no range'}) · ${l.status}`).join('\n') }));
  const vit = medRepo.vitals(p.id); const lv = vit[vit.length - 1]; if (lv) out.push({ id: 'vitals', kind: 'vitals', title: 'Latest vitals', detail: `${fmtDateTime(lv.at)} · ${vitalsText(lv).split(' · ').slice(0, 3).join(' · ')}`, recommended: true, text: vitalsText(lv) });
  const meds = medRepo.meds(p.id).filter(m => m.status === 'active'); out.push({ id: 'meds', kind: 'meds', title: 'Medication list', detail: `${meds.length} active`, recommended: true, text: meds.map(m => `${m.name} ${m.dose} ${m.frequency || ''}`).join('\n') || 'No active medications.' });
  out.push({ id: 'allergy', kind: 'allergy', title: 'Allergy list', detail: alText(p.allergies) || 'not recorded', recommended: true, text: alText(p.allergies) || 'Not recorded' });
  const probs = medRepo.problems(p.id).filter(x => x.status === 'active'); out.push({ id: 'problems', kind: 'problems', title: 'Problem list', detail: `${probs.length} active`, recommended: true, text: probs.map(x => x.description).join('\n') || 'None' });
  const sh = surgicalHistory(p.id); if (sh.length) out.push({ id: 'history', kind: 'history', title: 'Surgical history', detail: `${sh.length} item${sh.length === 1 ? '' : 's'}`, recommended: false, text: sh.map(h => `${h.text}${h.year ? ` (${h.year})` : ''}`).join('\n') });
  const na = nurseAdmission(v.id); if (na) out.push({ id: `nurse:${v.id}`, kind: 'nurse', title: 'Nursing admission', detail: `by ${na.by}`, recommended: false, text: `Reason: ${na.chiefComplaint}\nPain: ${na.pain}\nNPO: ${na.npo}\nNote: ${na.nurseNote}` });
  const sc = scribeSession(v.id); if (sc.lines.length) out.push({ id: `scribe:${v.id}`, kind: 'scribe', title: 'Ambient transcript (surgeon visit)', detail: `${sc.lines.length} lines · simulated`, recommended: false, text: sc.lines.map(l => `${l.speaker}: ${l.text}`).join('\n') });
  medRepo.visits(p.id).forEach(x => repo.listForms(x.id).filter(f => f.status === 'locked' || f.status === 'partially-signed').forEach(f => { const c = VITYLS_FORM_CATALOG.find(y => y.file === f.file); out.push({ id: `form:${x.id}:${f.file}`, kind: 'form', title: c?.title || f.file, detail: `${f.status === 'locked' ? 'signed' : 'partly signed'} · ${usDate(x.date)}`, recommended: /consent|history|h&p|registration/i.test(c?.title || ''), text: `${c?.title || f.file} (${f.status})` }); }));
  return out;
}

export function defaultForm(p: MedPatient, v: MedVisit, surgeon: string): SchedulingForm {
  const booking = checkoutOrders(v.id).find(o => o.kind === 'surgery-booking'); const probs = medRepo.problems(p.id).filter(x => x.status === 'active'); const prob = probs.find(x => /surg/i.test(`${x.conditionType} ${x.description}`)) || probs.find(x => x.conditionType === ('other' as any)); const note = medRepo.note(v.id);
  return { procedure: booking ? booking.text.replace(/^(Book|Confirm)\s+/i, '').replace(/\s+at .*$/, '').replace(/^\w/, c => c.toUpperCase()) : '', cpt: '', diagnosis: prob?.description.replace(/\s*\(.*\)$/, '') || (note?.assessment || '').split('.')[0] || v.reason || '', icd10: '', laterality: 'N/A', anesthesia: 'General', durationMin: 90, blockId: '', preferredDate: '', preferredTime: '', admission: 'Outpatient (same day)', equipment: '', implants: '', specialNeeds: '', latexAllergy: /latex/i.test(alText(p.allergies)), allergies: alText(p.allergies) || 'Not recorded', notes: '' };
}

const RECEIVE_MS = 2500;
/** Send the packet: one booking request (shows on the schedule), the documents on the case, a thread message. */
export function sendPacket(a: { p: MedPatient; v: MedVisit; facility: AscFacility; surgeon: string; form: SchedulingForm; docs: PacketDoc[]; date: string; time: string; room: string; by: string; role: string }): AscPacket {
  if (!a.form.procedure.trim()) throw new Error('Enter the procedure.');
  if (!a.date) throw new Error('Choose block time or a preferred date.');
  const bk = requestBooking({ ascName: a.facility.name, date: a.date, time: a.time || '07:30', durationMin: a.form.durationMin, surgeon: a.surgeon, patientName: a.p.name, dob: a.p.dob, procedure: a.form.procedure.trim(), room: a.room || 'TBD', requestedBy: a.by, visitId: a.v.id, patientId: a.p.id }, a.role);
  const at = new Date().toISOString();
  const formText = Object.entries(a.form).map(([k, x]) => `${k}: ${x}`).join('\n');
  const docs: NetworkDocument[] = [{ id: uid('nd'), caseId: bk.id, at, fromOrg: 'office', sharedBy: a.by, title: 'Surgery scheduling form', text: formText }, ...a.docs.map(d => ({ id: uid('nd'), caseId: bk.id, at, fromOrg: 'office' as const, sharedBy: a.by, title: d.title, text: d.text }))];
  docs.forEach(d => networkRepo.share(d));
  networkRepo.post({ id: uid('nm'), caseId: bk.id, at, fromOrg: 'office', author: a.by, role: a.role, text: `Scheduling request: ${a.form.procedure} · ${usDate(a.date)} ${a.time || ''} · ${a.surgeon}. Attached: scheduling form + ${a.docs.length} document${a.docs.length === 1 ? '' : 's'} (${a.docs.map(d => d.title).join('; ')}).` });
  const pk: AscPacket = { id: uid('pk'), patientId: a.p.id, visitId: a.v.id, caseId: bk.id, facilityId: a.facility.id, facilityName: a.facility.name, surgeon: a.surgeon, form: a.form, docs: a.docs.map(({ id, kind, title, detail }) => ({ id, kind, title, detail })), sentBy: a.by, sentRole: a.role, sentAt: at, status: 'sent' };
  savePackets([...ascPackets(), pk]);
  repo.audit({ caseId: patientKey(a.p.id), user: a.by, role: a.role, action: 'asc.packet.send', detail: `Sent to ${a.facility.name}: scheduling form (${a.form.procedure}, ${a.date}) + ${a.docs.length} document(s) · signed with PIN · SIMULATED, nothing left this browser` });
  setTimeout(() => receivePending(), RECEIVE_MS);
  return pk;
}
/** Simulated ASC acknowledgement: anything sent more than RECEIVE_MS ago is marked received and filed in the ASC chart. */
export function receivePending() {
  const now = Date.now(); let changed = false;
  const l = ascPackets().map(pk => {
    if (pk.status !== 'sent' || now - Date.parse(pk.sentAt) < RECEIVE_MS - 100) return pk;
    changed = true; const at = new Date().toISOString(); const chart = `ASC-${pk.patientId.replace(/\D/g, '').padStart(4, '0')}`;
    updateBooking(pk.caseId, { status: 'Received by ASC (simulated)' });
    networkRepo.post({ id: uid('nm'), caseId: pk.caseId, at, fromOrg: 'asc', author: `${pk.facilityName.replace(/\s*\(.*\)/, '')} scheduling`, role: 'ASC scheduler (simulated)', text: `Received. The scheduling form and ${pk.docs.length} document${pk.docs.length === 1 ? '' : 's'} were added to the patient's ASC chart ${chart}. We will confirm the time. (Simulated reply)`, simulatedReply: true });
    repo.audit({ caseId: patientKey(pk.patientId), user: pk.facilityName, role: 'ASC (simulated)', action: 'asc.packet.received', detail: `Received by ${pk.facilityName}; scheduling form + ${pk.docs.length} document(s) added to ASC chart ${chart} (simulated)` });
    return { ...pk, status: 'received' as const, receivedAt: at, ascChartId: chart };
  });
  if (changed) savePackets(l);
}
export const primaryAscName = () => getSettings().ascName;
