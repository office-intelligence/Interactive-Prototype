/* ASC.Vityls v10.6 · Station tablet shell (mockups "Pre-op nursing · tablet" and "· talk mode"). Sits at the top of every
 * station: open flags everyone sees, the Nightingale bar (role brief, "Say it" dictation into the station notes, Standard /
 * Talk toggle) and a To-do strip that jumps to each part of the station below. Talk mode captures the bedside
 * conversation (simulated ambient) and shows what was heard for this role to confirm and what was not heard yet; heard
 * values pre-fill the station's own fields as drafts. Nothing here replaces a station function. Fictional data. */
import React, { useState } from 'react';
import { Sparkles, Flag, MessageCircle, ListChecks, Mic, Bell } from 'lucide-react';
import { medRepo } from '../../med/record';
import { useActor, useMedTick } from '../../med/ui';
import { repo } from '../../v6/dataLayer';
import * as A from '../asc8/logic';
import * as S from '../asc8/store';
import { s81, use81, SAMPLE_BEDSIDE } from '../asc81/store81';
import * as L from '../asc81/ai';
import { caseSignals } from '../asc81/Workbench';
import * as D10 from '../asc10/store10';
import { DictateMic } from '../asc10/native103';
import { OR_TILES } from '../asc89/pure89';
import { svRead, svWrite } from '../store';
import { clearanceDocs, reviewsFor } from './clearance106';
import { addNote, notesFor } from './stations106';

type Mode = 'standard' | 'talk';
const MK = 'asc106-mode';
const STATION_NAME: Record<string, string> = { or: 'OR', front: 'Front desk', arrival: 'Front desk', verify: 'Pre-op nursing', nursing: 'Pre-op nursing', anesthesia: 'Anesthesia', surgeon: 'Surgeon', pacu: 'PACU', discharge: 'Discharge', after: 'Follow-up', closure: 'Closure', brief: 'Pre-op nursing', orders: 'Pre-op nursing' };
const ROLE: Record<string, L.BedRole | undefined> = { verify: 'nursing', nursing: 'nursing', anesthesia: 'anesthesia', surgeon: 'surgeon' };
const EXPECT: Record<L.BedRole, string[]> = { nursing: ['Vitals', 'NPO status', 'Post-op care & ride', 'Belongings & implants', 'IV site'], anesthesia: ['Airway exam', 'Plan & ASA', 'Focused exam'], surgeon: ['Site marking', 'Consent discussion'] };

const jump = (sel: string) => { const el = document.querySelector(`.a81-dialog ${sel}`) as HTMLElement | null; if (el) { el.scrollIntoView({ behavior: 'smooth', block: 'start' }); el.classList.add('b6-glow'); setTimeout(() => el.classList.remove('b6-glow'), 1400); } };

export const StationBar106: React.FC<{ c: A.AscCase; bench: string }> = ({ c, bench }) => {
  useMedTick(); use81(); const [actor] = useActor(); const [mode, setModeS] = useState<Mode>(() => svRead<Mode>(MK, 'standard'));
  const setMode = (m: Mode) => { svWrite(MK, m); setModeS(m); };
  const p = medRepo.patient(c.pid); const first = p?.name.split(' ')[0] || 'Patient'; const station = STATION_NAME[bench] || 'Station'; const role = ROLE[bench];
  const flags = S.flagsAll().filter(f => f.status === 'open' && (f.caseId === c.id || (!f.caseId && f.pid === c.pid)));
  const phase: D10.Phase | null = ['nursing', 'verify', 'orders'].includes(bench) ? 'pre' : ['pacu', 'discharge'].includes(bench) ? 'post' : null;
  const list = phase ? D10.viewList(c.id, c.surgeon, phase) : null; const ticked = list ? list.items.filter(i => list.ticks[i.id]).length : 0;
  const docs = ['verify', 'nursing', 'anesthesia', 'surgeon', 'pacu'].includes(bench) ? clearanceDocs(c) : []; const rev = Object.keys(reviewsFor(c.id)).length;
  const miss = L.bookingChecklist(caseSignals(c, s81.ai(c.id))).filter(i => i.state === 'missing');
  const x = S.caseById(c.id) || c; const d = x.d as any;
  const consents = bench === 'nursing' || bench === 'anesthesia' || bench === 'surgeon' ? [['Surgical', !!d.consentConfirm], ['Anesthesia', !!d.anesConsent]] as [string, boolean][] : [];
  const notes = notesFor(c.id); const nNotice = flags.length + miss.length; void Flag; void MessageCircle; void ListChecks; void DictateMic; void addNote;
  const todo_: { k: string; label: string; v: string; done: boolean; go: () => void }[] = [
    ...(miss.length && (bench === 'arrival' || bench === 'verify' || bench === 'nursing') ? [{ k: 'miss', label: 'Missing documents', v: `${miss.length}`, done: false, go: () => jump('[data-testid="v106-clearance-docs"]') }] : []),
    ...(list && list.items.length ? [{ k: 'orders', label: `${phase === 'pre' ? 'Pre' : 'Post'}-op orders`, v: `${ticked} of ${list.items.length}`, done: ticked === list.items.length, go: () => jump(`[data-testid="v10-list-${phase}"]`) }] : []),
    ...(docs.length ? [{ k: 'clr', label: 'Clearance reviewed', v: `${Math.min(rev, docs.length)} of ${docs.length}`, done: rev >= docs.length, go: () => jump('[data-testid="v106-clearance-summary"], [data-testid="v106-clearance-docs"]') }] : []),
    ...(consents.length ? [{ k: 'cons', label: 'Consents', v: `${consents.filter(z => z[1]).length} of ${consents.length}`, done: consents.every(z => z[1]), go: () => { const el = Array.from(document.querySelectorAll('.a81-dialog h3, .a81-dialog h4, .a81-dialog b')).find(e => /consent/i.test(e.textContent || '')) as HTMLElement | undefined; el?.scrollIntoView({ behavior: 'smooth', block: 'center' }); } }] : []),
    { k: 'notes', label: 'Notes', v: `${notes.length}`, done: notes.length > 0, go: () => jump('[data-testid="v106-notes"]') },
  ];
  const brief = [
    docs.length ? `${rev >= docs.length ? 'All' : `${Math.min(rev, docs.length)} of ${docs.length}`} clearance documents reviewed.` : '',
    list && list.items.length ? `${c.surgeon.replace(/,.*$/, '')}’s standard ${phase}-op orders are ready (${ticked} of ${list.items.length} done).` : '',
    bench === 'or' ? `${OR_TILES.filter(o => (x.events as any)[o.key]).length} of ${OR_TILES.length} OR event times stamped.` : '',

  ].filter(Boolean).join(' ') || `${first} is ready for ${station === 'OR' || station === 'PACU' ? 'the ' + station : station.toLowerCase()}.`;

  // Talk mode · bedside capture (simulated ambient)
  const ai = s81.ai(c.id); const bed = ai.bedside; const heard = role ? (bed?.drafts?.[role] || []) : [];
  const byTarget = heard.reduce<Record<string, string[]>>((m, l) => { (m[l.target] = m[l.target] || []).push(l.text); return m; }, {});
  const notHeard = role ? EXPECT[role].filter(t => !byTarget[t]) : [];
  const sample = SAMPLE_BEDSIDE.replace(/left wrist/g, /\bright\b/i.test(c.procedure) ? 'right side' : /\bleft\b/i.test(c.procedure) ? 'left side' : 'site').replace(/Dr\. Lee/g, `Dr. ${c.anesthesia.replace(/,.*$/, '').split(' ').slice(-1)[0]}`).replace(/Dr\. Patel/g, `Dr. ${c.surgeon.replace(/,.*$/, '').split(' ').slice(-1)[0]}`);
  const capture = (t: string) => { const drafts = L.splitBedside(t, { anesthesia: [c.anesthesia], surgeon: [c.surgeon] }); s81.setAi(c.id, a => ({ ...a, bedside: { ...(a.bedside || {}), transcript: t, drafts } })); repo.audit({ caseId: `asc8:${c.id}`, user: actor.name, role: actor.role, action: 'asc106.talk' as any, detail: `${station}: bedside conversation captured (simulated ambient); drafts for each role` }); };
  const confirmHeard = () => { repo.audit({ caseId: `asc8:${c.id}`, user: actor.name, role: actor.role, action: 'asc106.talk-confirm' as any, detail: `${station}: confirmed heard items: ${Object.keys(byTarget).join(', ')}` }); addNote({ cid: c.id, station: station as any, text: `Confirmed from bedside conversation: ${Object.entries(byTarget).map(([k, v]) => `${k} — ${v.map(s => s.replace(/^Patient: /, '')).join(' / ')}`).join('; ')}`, by: actor.name, role: actor.role }); setMode('standard'); };

  return <div className="b6" data-testid="v106-station-bar" data-mode={mode}>
    <div className="b6-row">
      <button type="button" className={`b6-talkbtn ${mode === 'talk' ? 'on' : ''}`} aria-pressed={mode === 'talk'} onClick={() => setMode(mode === 'talk' ? 'standard' : 'talk')} data-testid="v106-mode-talk"><span className="ic"><Mic size={20} /></span><span><b>{mode === 'talk' ? 'Listening' : 'Talk'}</b><small>{mode === 'talk' ? 'Tap to stop' : 'Record & fill'}</small></span></button>
      <div className="b6-card ai" data-testid="v106-bar-ai"><span className="b6-k"><Sparkles size={13} /> Nightingale</span><p data-testid="v106-bar-brief">{brief}</p></div>
      <button type="button" className={`b6-card note ${nNotice ? 'warn' : 'ok'}`} onClick={() => { const el = document.querySelector('[data-testid="v106-before-sign"]') as HTMLElement | null; el?.scrollIntoView({ behavior: 'smooth', block: 'start' }); }} data-testid="v106-bar-notices"><span className="b6-k"><Bell size={13} /> Notifications</span><p>{nNotice ? `${flags.length ? `${flags.length} flag${flags.length === 1 ? '' : 's'}` : ''}${flags.length && miss.length ? ' · ' : ''}${miss.length ? `${miss.length} missing` : ''}` : 'None open'}</p></button>
    </div>
    {mode === 'talk' && <div className="b6-talk" data-testid="v106-talk">
        {!bed?.transcript ? <div className="b6-tstart"><p>Talk with {first} as usual. Nightingale listens, splits what was said by role, and drafts the fields. Nothing is saved until you confirm.</p><DictateMic sample={sample} label="Start listening" testId="v106-talk-mic" onText={capture} /></div> : <>
          <div className="b6-cols">
            <section><h4>Heard · confirm <span className="b6-mu">· {Object.keys(byTarget).length}</span></h4>{Object.keys(byTarget).length ? <ul>{Object.entries(byTarget).map(([k, v]) => <li key={k}><b>{k}</b><span>{v.join(' · ')}</span></li>)}</ul> : <p className="b6-mu">Nothing for {station.toLowerCase()} in this conversation.</p>}
              {role && Object.keys(byTarget).length > 0 && <button type="button" className="b6-btn pri" onClick={confirmHeard} data-testid="v106-talk-confirm">Confirm {Object.keys(byTarget).length === 2 ? 'both' : 'all'}</button>}</section>
            <section><h4>Not heard yet <span className="b6-mu">· {notHeard.length}</span></h4>{notHeard.length ? <div className="b6-nh">{notHeard.map(t => <span key={t}>{t}</span>)}</div> : <p className="b6-mu">Everything for this role was covered.</p>}
              <DictateMic sample={sample} label="Listen again" testId="v106-talk-again" onText={capture} /></section>
          </div>
          <details className="b6-tr"><summary>Transcript</summary><pre>{bed.transcript}</pre></details></>}
      </div>}
  </div>;
};

/** Sign bar pinned to the bottom of the station (mockup footer). It presses the station's own sign button, so the
 * station's PIN / signature flow and checks run exactly as before; it only makes that button always reachable. */
export const SignBar106: React.FC = () => {
  const ref = React.useRef<HTMLDivElement>(null); const [st, setSt] = useState<{ label: string; disabled: boolean; hint: string } | null>(null);
  const target = () => { const dlg = ref.current?.closest('.a81-dialog') as HTMLElement | null; const btns = dlg ? Array.from(dlg.querySelectorAll('.a81-dbody .a81-foot button')) as HTMLButtonElement[] : [];
    const signs = btns.filter(b => /\bsign|discharge|lock|complete|close case/i.test(b.innerText || '') && !/save|row|draft/i.test(b.innerText || ''));
    return signs.find(b => b.classList.contains('pri')) || signs[signs.length - 1] || null; };
  React.useEffect(() => { const tick = () => { const b = target(); const hint = (b?.closest('.a81-foot')?.querySelector('.sv-small, .a81-warn, small') as HTMLElement | null)?.innerText || '';
    const next = b ? { label: (b.innerText || 'Sign').trim(), disabled: b.disabled, hint } : null; setSt(s => JSON.stringify(s) === JSON.stringify(next) ? s : next); };
    tick(); const id = window.setInterval(tick, 600); return () => window.clearInterval(id); }, []);
  return <div ref={ref} className="b6-sign" data-testid="v106-signbar" hidden={!st}>{st && <>
    <button type="button" className="b6-signbtn" disabled={st.disabled} onClick={() => target()?.click()} data-testid="v106-sign">{st.label}</button>
    <span>{st.hint || 'Anything still open becomes a flag everyone can see.'}</span></>}</div>;
};
