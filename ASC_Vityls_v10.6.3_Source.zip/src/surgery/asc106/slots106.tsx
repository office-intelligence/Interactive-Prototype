/* ASC.Vityls v10.6.2 · One data-entry flow per station (Kevin's review, Oct 30).
 * - MoreFields: the station's remaining form fields continue the station's own numbered sections (6, 7, …) in the same card
 *   design, with tap buttons, quick "normal" texts and done states. Fields the station already asks in its own sections are
 *   not asked again, and fields that belong to a later phase (intra-op, PACU, transfer) are left to the station that does them.
 * - AlreadyKnown: history and Nightingale summaries, collapsed, near the bottom.
 * - BeforeSign: flags, warnings, missing items and the station verification together, just above the signature.
 * Data and signing are unchanged: answers are saved to the same case answers the forms print from. Fictional data. */
import React, { useMemo, useState } from 'react';
import { Flag, CheckCircle2, AlertTriangle } from 'lucide-react';
import { useActor, useMedTick } from '../../med/ui';
import * as A from '../asc8/logic';
import * as S from '../asc8/store';
import * as E from '../asc10/bank/engine';
import { BANK_STATION, type BenchStation, stationOpen, saveAnswers, prefilled, tplTitle } from '../asc10/bank10';
import { ConfirmStation } from '../asc10/station102';
import { historyVerified } from '../asc10/store10';

export const StationCtx = React.createContext<{ c: A.AscCase; bench: string } | null>(null);

/** Asked already in the station's own numbered sections (same data point) → not asked twice. */
const COVERED: Record<string, string[]> = {
  nursing: ['RN-27', 'RN-10', 'RN-11', 'RN-02', 'RN-13', 'RN-14', 'RN-15', 'RN-16', 'RN-09', 'RN-23', 'RN-26', 'RN-19', 'RN-20', 'RN-21', 'RN-29', 'RN-31'],
  anesthesia: ['AN-15', 'AN-12', 'AN-13', 'AN-10', 'AN-11', 'AN-17', 'AN-18', 'AN-23', 'AN-41'],
  surgeon: ['SX-41', 'SX-14', 'SX-16', 'SX-23', 'SX-24', 'SX-02', 'SX-26', 'SX-27', 'SX-30', 'SX-32', 'SX-33', 'SX-34', 'SX-35'],
  discharge: ['PA-14'],
};
/** Belongs to a later phase or another station's record (done there, still on the full forms). */
const LATER: Record<string, RegExp> = {
  anesthesia: /intra-?operative record|pacu|post anesthesia/i,
  surgeon: /operative report/i,
};
const LATER_IDS: Record<string, string[]> = { anesthesia: ['AN-34', 'AN-25', 'AN-26', 'AN-29', 'AN-31', 'AN-27', 'AN-35', 'AN-33'], surgeon: ['SX-03', 'SX-29', 'SX-31'] };
const OPEN = (i: E.StationItem) => i.status === 'missing' || i.status === 'empty' || i.status === 'default';
const short = (t: string) => t.replace(/\s*\((?:[^()]*)\)\s*/g, ' ').replace(/\s+/g, ' ').trim();

export function moreItems(c: A.AscCase, bench: string): E.StationItem[] {
  const st = (BANK_STATION as any)[bench] as E.Station | undefined; if (!st) return [];
  const cov = new Set([...(COVERED[bench] || []), ...(LATER_IDS[bench] || [])]); const later = LATER[bench];
  return stationOpen(c, st).filter(i => !cov.has(i.q.id) && !(later && later.test(E.TEMPLATES[i.q.form || '']?.title || '')));
}

/** One field: tap buttons for short choices, multi-select chips, quick "normal" texts above free text. */
const Field106: React.FC<{ q: E.Question; v: string; on: (v: string) => void; id: string }> = ({ q, v, on, id }) => {
  const [t, setT] = useState(v); React.useEffect(() => setT(v), [v]);
  const opts = q.kind === 'yesno' ? (q.options.length ? q.options : ['Yes', 'No']) : q.options;
  if ((q.kind === 'yesno' || q.kind === 'choice') && opts.length) {
    if (opts.length <= 8 || (opts.length <= 12 && opts.every(o => o.length <= 3))) return <div className="v106-chips" role="radiogroup" aria-label={q.text} id={id} data-testid={id} data-value={v}>{opts.map((o, i) => <button key={o} type="button" role="radio" aria-checked={v === o} className={v === o ? 'on' : ''} onClick={() => on(o)} data-testid={`${id}-opt-${i}`}>{o}</button>)}</div>;
    return <select className="sv-input" value={v} onChange={e => on(e.target.value)} id={id} data-testid={id}><option value="">Choose…</option>{opts.map(o => <option key={o}>{o}</option>)}</select>;
  }
  const quick = opts.filter(o => o.length <= 40 && !/^(type and location|status and removed|time)$/i.test(o)).slice(0, 6);
  const parts = t.split(/\s*,\s*/).filter(Boolean);
  const toggle = (o: string) => { const has = parts.includes(o); const n = q.kind === 'multi' || q.kind === 'list' ? (has ? parts.filter(x => x !== o) : [...parts, o]).join(', ') : (has ? '' : o); setT(n); on(n); };
  return <div className="v106-fld">
    {quick.length > 0 && <div className="v106-chips sm" aria-label="Quick answers">{quick.map((o, i) => <button key={o} type="button" aria-pressed={parts.includes(o) || t === o} className={parts.includes(o) || t === o ? 'on' : ''} onClick={() => toggle(o)} data-testid={`${id}-quick-${i}`}>{o}</button>)}</div>}
    {q.kind === 'narrative' || q.kind === 'list' || q.kind === 'multi'
      ? <textarea className="sv-input" rows={2} value={t} onChange={e => setT(e.target.value)} onBlur={() => t !== v && on(t)} id={id} data-testid={id} placeholder={quick.length ? 'Or type…' : ''} />
      : <input className="sv-input" type={q.kind === 'number' ? 'number' : 'text'} inputMode={q.kind === 'number' ? 'decimal' : undefined} value={t} onChange={e => setT(e.target.value)} onBlur={() => t !== v && on(t)} id={id} data-testid={id} placeholder={q.kind === 'date' ? 'e.g. 10/29 9:00 PM' : ''} />}
  </div>;
};

/** The station's remaining fields, continuing its numbered sections. */
export const MoreFields: React.FC<{ start: number }> = ({ start }) => {
  useMedTick(); const ctx = React.useContext(StationCtx); const [actor] = useActor(); const [, f] = useState(0);
  const c = ctx ? (S.caseById(ctx.c.id) || ctx.c) : null; const bench = ctx?.bench || '';
  const st = (BANK_STATION as any)[bench] as E.Station | undefined;
  const a = c ? prefilled(c) : {};
  const items = useMemo(() => c ? moreItems(c, bench) : [], [c?.id, bench, JSON.stringify(a)]);
  if (!c || !st || !items.length) return null;
  const byTpl = items.reduce<Record<string, E.StationItem[]>>((m, i) => { const k = tplTitle(i.q.form, st); (m[k] = m[k] || []).push(i); return m; }, {});
  const set = (q: E.Question, v: string) => { saveAnswers(c.id, E.setAnswer(prefilled(c), q.id, v, { source: 'staff', by: actor.name, at: new Date().toISOString(), station: st })); f(x => x + 1); };
  return <div className="a82-sections v106-more" data-testid="v10-bank" data-open={items.filter(OPEN).length}>{(Object.entries(byTpl) as [string, E.StationItem[]][]).map(([tpl, l], gi) => {
    const done = l.filter(i => !OPEN(i)).length;
    return <section key={tpl} className="a82-sec v106-msec" data-testid="v10-bank-tpl" data-tpl={tpl}>
      <div className="a82-sh"><span className="n">{start + gi}</span><h3 className="a81-h3">{tpl === 'Other details' ? 'More for this station' : tpl}</h3><span className={`a81-progress ${done === l.length ? 'done' : ''}`}>{done} of {l.length}</span></div>
      {l.map(i => { const id = `v10-q-${i.q.id}`; const ok = !OPEN(i);
        return <div key={i.q.id} className={`v106-q ${ok ? 'ok' : ''}`} data-testid="v10-bank-inp" data-qid={i.q.id}>
          <label className="v106-ql" htmlFor={id} data-testid="v10-bank-q" data-qid={i.q.id}>{ok ? <CheckCircle2 size={16} aria-hidden="true" /> : <span className="dot" aria-hidden="true" />}{short(i.q.text)}{i.required && !ok && <span className="req">required</span>}</label>
          <Field106 q={i.q} v={i.value} on={v => set(i.q, v)} id={id} /></div>; })}
    </section>; })}</div>;
};

/** History and Nightingale summaries, collapsed. */
export const AlreadyKnown: React.FC<{ children: React.ReactNode; what?: string }> = ({ children, what }) =>
  <details className="v106-known" data-testid="v106-known"><summary><span><b>Already known</b>{what && <span className="mu"> · {what}</span>}</span><span className="v106-rc">Review</span></summary><div className="v106-kbody">{children}</div></details>;

/** Everything to check before signing, in one place just above the signature. */
export const BeforeSign: React.FC<{ children?: React.ReactNode; confirm?: boolean }> = ({ children, confirm = true }) => {
  useMedTick(); const ctx = React.useContext(StationCtx); if (!ctx) return <>{children}</>;
  const c = S.caseById(ctx.c.id) || ctx.c; const flags = S.flagsAll().filter(x => x.status === 'open' && (x.caseId === c.id || (!x.caseId && x.pid === c.pid)));
  const left = moreItems(c, ctx.bench).filter(i => OPEN(i) && i.required);
  const hv = historyVerified(c.id);
  const kids = React.Children.toArray(children).filter(Boolean);
  return <section className="v106-before" data-testid="v106-before-sign">
    <h3>Before you sign</h3>
    {flags.map(x => <div key={x.id} className="v106-bitem flag" data-testid="v106-bs-flag"><Flag size={16} aria-hidden="true" /><span>{x.text} <span className="mu">· {x.from} → {A.TEAM_LABEL[x.to] || x.to}</span></span></div>)}
    {!hv && ['nursing', 'anesthesia', 'surgeon'].includes(ctx.bench) && <div className="v106-bitem warn" data-testid="v10-official-pending"><AlertTriangle size={16} aria-hidden="true" /><span><b>Medical history not verified yet.</b> The nurse confirms it at Verify medical history. You can continue.</span></div>}
    {left.length > 0 && <div className="v106-bitem warn" data-testid="v106-bs-left"><AlertTriangle size={16} aria-hidden="true" /><span><b>{left.length} required field{left.length === 1 ? '' : 's'} still open:</b> {left.slice(0, 6).map(i => short(i.q.text)).join(' · ')}{left.length > 6 ? ` +${left.length - 6} more` : ''}</span></div>}
    {kids}
    {!flags.length && hv && !left.length && !kids.length && <div className="v106-bitem ok"><CheckCircle2 size={16} aria-hidden="true" /><span>No open flags or warnings.</span></div>}
    {confirm && <ConfirmStation c={c} bench={ctx.bench === 'preop' ? 'nursing' : ctx.bench} />}
  </section>;
};
export type { BenchStation };
