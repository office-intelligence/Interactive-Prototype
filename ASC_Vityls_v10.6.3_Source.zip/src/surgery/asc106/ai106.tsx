/* ASC.Vityls v10.6.3 · One standard Nightingale box on every page (AI-first).
 * AiBox106 is the same pill as the main Chat page (sparkle · input · mic · round send). Pages that already had their own
 * ask (Schedule, Practice Intelligence, Billing) now use it in place; every other page gets AiDock106 floating near the
 * bottom. The dock runs the chat commands (who's next, check in, orders, flags, invoice…) with action cards, and otherwise
 * answers about the page. Draft answers only; nothing is signed or sent from here. Fictional data. */
import React, { useState } from 'react';
import { ArrowUp, Mic, Sparkles, X } from 'lucide-react';
import { useActor, useMedTick } from '../../med/ui';
import { ascCommand, Acts106, type Reply106 } from './chat106';
import { draftAnswer } from '../asc90/shell90';
import './ai106.css';

export const AiBox106: React.FC<{ value: string; onChange: (v: string) => void; onSubmit: () => void; placeholder: string; inputId?: string; goId?: string; sample?: string; label?: string }> =
  ({ value, onChange, onSubmit, placeholder, inputId, goId, sample, label }) =>
  <form className="ai6-box" role="search" onSubmit={e => { e.preventDefault(); onSubmit(); }}>
    <span className="ai6-mark" aria-hidden="true"><Sparkles size={16} /></span>
    <input value={value} onChange={e => onChange(e.target.value)} placeholder={placeholder} aria-label={label || 'Ask Nightingale'} data-testid={inputId} autoComplete="off" />
    <button type="button" className="ai6-mic" aria-label="Voice (simulated)" title="Simulated voice: types a sample question" onClick={() => sample && onChange(sample)}><Mic size={17} /></button>
    <button type="submit" className="ai6-send" aria-label="Ask" data-testid={goId}><ArrowUp size={18} /></button>
  </form>;

const PAGE: Record<string, [string, string, string]> = {
  home: ['Today page', 'Ask Nightingale: “who’s next”, “what’s missing”, “check in Priya”…', 'Who’s next?'],
  patients: ['patient record', 'Ask Nightingale about this patient or say what to do…', 'What’s missing?'],
  messages: ['messages', 'Ask Nightingale about messages, flags or a patient…', 'What’s missing?'],
  'ops-hub': ['operations page', 'Ask Nightingale about rooms, cases or the day…', 'Who’s next?'],
};

/** Floating standard box for pages without their own Nightingale box. */
export const AiDock106: React.FC<{ tab: string }> = ({ tab }) => {
  useMedTick(); const [actor] = useActor(); const [q, setQ] = useState(''); const [r, setR] = useState<(Reply106 & { q: string }) | null>(null);
  const [page, ph, sample] = PAGE[tab] || ['page', 'Ask Nightingale or tell it what to do…', 'Who’s next?'];
  const ask = (text: string) => { const t = text.trim(); if (!t) return; const x = ascCommand(t, actor) || { text: draftAnswer(t, page), acts: [] }; setR({ ...x, q: t }); setQ(''); };
  return <div className="ai6-dock" data-testid="n9-ask">
    {r && <div className="ai6-ans" data-testid="n9-ask-answer" role="status"><div className="ai6-ah"><span className="ai6-mark sm"><Sparkles size={13} /></span><b>Nightingale</b><span className="ai6-q">“{r.q}”</span><button type="button" className="ai6-x" aria-label="Close" onClick={() => setR(null)} data-testid="n9-ask-close"><X size={16} /></button></div>
      <p>{r.text}</p>{r.acts.length > 0 && <Acts106 acts={r.acts} onAsk={ask} />}<span className="ai6-mu">Draft only · nothing is signed or sent from here.</span></div>}
    <AiBox106 value={q} onChange={setQ} onSubmit={() => ask(q)} placeholder={ph} inputId="n9-ask-input" goId="n9-ask-go" sample={sample} label="Ask Nightingale about this page" />
  </div>;
};
