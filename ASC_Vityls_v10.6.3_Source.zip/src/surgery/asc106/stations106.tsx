/* ASC.Vityls v10.6 · stations: "Essentials" view (only what is still needed, default) vs "Full record", and a Notes box on every
 * nursing station (pre-op nursing, OR, PACU, discharge) with an optional "Flag for the team".
 * Consents are never collapsed: they always open full screen with the signature captured on the form itself.
 * Storage (browser, test build): asc106-view (per device), asc106-notes. Henry: station_note. */
import React, { useEffect, useState } from 'react';
import { ListChecks, FileStack, Flag } from 'lucide-react';
import { useActor, useMedTick } from '../../med/ui';
import { repo } from '../../v6/dataLayer';
import { svRead, svWrite } from '../store';
import * as A from '../asc8/logic';
import * as S from '../asc8/store';
import { DictateMic } from '../asc10/native103';
import { useSv } from '../ui';
import './stations106.css';

/* ---------------- Essentials / Full record ---------------- */
export type View106 = 'essentials' | 'full';
const VK = 'asc106-view'; const VEV = 'asc106-view';
export const view106 = (): View106 => svRead<View106>(VK, 'essentials');
const apply = (v: View106) => { document.documentElement.dataset.v106View = v; };
export function setView106(v: View106) { svWrite(VK, v); apply(v); window.dispatchEvent(new Event(VEV)); }
export function useView106(): View106 { const [v, setV] = useState<View106>(view106); useEffect(() => { apply(view106()); const h = () => setV(view106()); window.addEventListener(VEV, h); return () => window.removeEventListener(VEV, h); }, []); return v; }

export const ViewToggle: React.FC = () => { const v = useView106();
  const B = (k: View106, label: string, Icon: React.FC<any>) => <button type="button" aria-pressed={v === k} className={v === k ? 'on' : ''} onClick={() => setView106(k)} data-testid={`v106-view-${k}`} title={k === 'essentials' ? 'Show only what is still needed' : 'Show every form and field'}><Icon size={15} aria-hidden="true" />{label}</button>;
  return <div className="v106-viewtog" role="group" aria-label="Station view" data-testid="v106-view-toggle">{B('essentials', 'Essentials', ListChecks)}{B('full', 'Full record', FileStack)}</div>; };

/** Collapsible full form: open by default in Full record, collapsed to one bar in Essentials. */
export const FullFormFold: React.FC<{ title: string; children: React.ReactNode }> = ({ title, children }) => {
  const v = useView106(); const [open, setOpen] = useState(false);
  if (v === 'full' || open) return <div className="v106-fold-open">{v === 'essentials' && <button type="button" className="a8-link" onClick={() => setOpen(false)} data-testid="v106-fold-close">Hide the full form</button>}{children}</div>;
  return <div className="v106-fold" data-testid="v106-fold"><div><b>{title}</b><span>Fields filled at this station go into this form automatically. Open it to review or edit every field.</span></div><button type="button" className="a8-btn" onClick={() => setOpen(true)} data-testid="v106-fold-open">Open full form</button></div>;
};

/* ---------------- Notes on nursing stations ---------------- */
export interface StationNote { id: string; cid: string; station: string; text: string; by: string; role: string; at: string; flaggedTo?: A.Team }
const NK = 'asc106-notes';
export const notesFor = (cid: string) => svRead<StationNote[]>(NK, []).filter(n => n.cid === cid).sort((a, b) => b.at.localeCompare(a.at));
export function addNote(n: Omit<StationNote, 'id' | 'at'>) {
  const x: StationNote = { ...n, id: `note-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 5)}`, at: new Date().toISOString() };
  svWrite(NK, [...svRead<StationNote[]>(NK, []), x]);
  repo.audit({ caseId: `asc8:${n.cid}`, user: n.by, role: n.role, action: 'asc106.note' as any, detail: `${n.station} note${n.flaggedTo ? ` (flagged to ${A.TEAM_LABEL[n.flaggedTo]})` : ''}: ${n.text}` });
  window.dispatchEvent(new Event('vityls-med-updated')); return x;
}
const NEXT_TEAM: Record<string, A.Team> = { 'Pre-op nursing': 'anesthesia', OR: 'pacu', PACU: 'surgeon', Discharge: 'coord' };

export const StationNotes: React.FC<{ c: A.AscCase; station: 'Pre-op nursing' | 'OR' | 'PACU' | 'Discharge' }> = ({ c, station }) => {
  useMedTick(); const [actor] = useActor(); const { toast } = useSv(); const [txt, setTxt] = useState(''); const [flag, setFlag] = useState(false); const [to, setTo] = useState<A.Team>(NEXT_TEAM[station] || 'preop');
  const list = notesFor(c.id);
  const save = () => { const text = txt.trim(); if (!text) return;
    addNote({ cid: c.id, station, text, by: actor.name, role: actor.role, flaggedTo: flag ? to : undefined });
    if (flag) S.raiseFlag({ from: actor.name, fromRole: actor.role, to, pid: c.pid, caseId: c.id, text });
    setTxt(''); setFlag(false); toast(flag ? `Note saved and flagged to ${A.TEAM_LABEL[to]}. Everyone sees the flag.` : 'Note saved.'); };
  return <section className="v10-card v106-notes" data-testid="v106-notes" data-station={station}>
    <div className="v10-row"><h3 className="v10-h" style={{ margin: 0, flex: 1 }}>Notes</h3><DictateMic testId="v106-notes-mic" label="Dictate a note" sample="Patient anxious about nausea after the last anesthetic. Reassured and told anesthesia." onText={t => setTxt(x => (x ? x + ' ' : '') + t)} /></div>
    <label className="sr-only" htmlFor={`v106-note-${c.id}`}>Note</label>
    <textarea id={`v106-note-${c.id}`} className="sv-input v106-note-ta" rows={3} value={txt} onChange={e => setTxt(e.target.value)} placeholder="Anything that comes up: patient concerns, events, calls made…" data-testid="v106-note-text" />
    <div className="v10-row" style={{ marginTop: 8 }}>
      <label className="v106-flagck"><input type="checkbox" checked={flag} onChange={e => setFlag(e.target.checked)} data-testid="v106-note-flag" /><Flag size={15} aria-hidden="true" />Flag for</label>
      <select className="sv-input" style={{ width: 'auto' }} value={to} onChange={e => setTo(e.target.value as A.Team)} disabled={!flag} aria-label="Flag for team" data-testid="v106-note-to">{(Object.keys(A.TEAM_LABEL) as A.Team[]).map(k => <option key={k} value={k}>{A.TEAM_LABEL[k]}</option>)}</select>
      <span style={{ marginLeft: 'auto' }} /><button type="button" className="a8-btn pri" disabled={!txt.trim()} onClick={save} data-testid="v106-note-save">Save note</button>
    </div>
    <p className="v10-sub" style={{ marginTop: 6 }}>Saved to the {station.toLowerCase()} record with your name and time. Flags are visible to the whole team.</p>
    {list.length > 0 && <ul className="v106-notelist" data-testid="v106-note-list">{list.slice(0, 6).map(n => <li key={n.id}><span>{n.text}</span><small>{n.station} · {n.by.replace(/,.*$/, '')} · {new Date(n.at).toLocaleString('en-US', { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' })}{n.flaggedTo ? ` · flagged to ${A.TEAM_LABEL[n.flaggedTo]}` : ''}</small></li>)}</ul>}
  </section>;
};
