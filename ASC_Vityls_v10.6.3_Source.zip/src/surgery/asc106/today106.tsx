/* ASC.Vityls v10.6 · Today (approved mockup "Today · Front desk" + "Today · Rooms view").
 * One patient list for everyone (patient-first): Arriving · In the building · Discharged. Each row: where the patient is and
 * what is next, missing items as chips, flags everyone can see, one primary button that opens the next station, and a "⋯"
 * menu with Chart, Details, Cancel and every station (all v10.5 popups kept). Counter tiles filter; "My station" is optional.
 * Right rail: my queue for today, all flags, coming up. Rooms view: OR lanes over the day with a now line. Fictional data. */
import React, { useEffect, useState } from 'react';
import { ChevronLeft, ChevronRight, MoreHorizontal, Flag, Sparkles, Check } from 'lucide-react';
import { medRepo, isoDay, addDays } from '../../med/record';
import { useActor, useMedTick } from '../../med/ui';
import { useSv } from '../ui';
import * as A from '../asc8/logic';
import * as S from '../asc8/store';
import { openAsc } from '../asc8/ui';
import { use81 } from '../asc81/store81';
import { WSS } from '../asc84/chips';
import { CheckInDialog } from '../asc83/frontdesk';
import { buildTodos, TodoList, CancelDialog, type Todo } from '../asc87/ui87';
import * as F from '../asc90/flow90';
import { caseFlow, anesType } from '../asc90/today90';
import './today106.css';

const hm = (t: string) => t.replace(/^0/, '').replace(/\s?AM$/i, '').replace(/\s?PM$/i, ' PM');
const shortDr = (n: string) => `Dr. ${n.replace(/,.*$/, '').split(' ').slice(-1)[0]}`;
const WHERE: Record<string, string> = { scheduled: 'Not arrived', arrived: 'Checked in', preop: 'In pre-op', or: 'In OR', pacu: 'In PACU', discharged: 'Discharged', closed: 'Closed' };
type Key = 'all' | 'arriving' | 'nursing' | 'anesthesia' | 'or' | 'pacu' | 'done' | 'missing' | 'late';
const ROOMS_START = 7 * 60, ROOMS_SPAN = 9 * 60;

function mineMatcher(st: A.Station, name: string) {
  const re: Record<string, RegExp> = { front: /front desk|scheduler|coordinator/i, preop: /pre-op/i, pacu: /pacu/i, anesthesia: /anesth|crna/i, surgeon: /surgeon/i, or: /\bor team\b/i, billing: /billing|records|front desk/i };
  return (who: string) => who.includes(name.replace(/,.*$/, '')) || !!re[st]?.test(who);
}

export const AscToday106: React.FC = () => {
  useMedTick(); use81(); const [actor] = useActor(); const { go } = useSv(); const T = isoDay(); const [day, setDay] = useState(T);
  const [view, setView] = useState<'list' | 'rooms'>('list'); const [k, setK] = useState<Key>('all'); const [mine, setMine] = useState(false);
  const [ci, setCi] = useState(''); const [cx, setCx] = useState(''); const [doneOpen, setDoneOpen] = useState(false); const [menu, setMenu] = useState(''); const [sel, setSel] = useState('');
  const openChart = (pid: string) => go({ type: 'chart', pid } as any);
  const st = A.stationOf(actor.role); const isToday = day === T; const now = new Date(); const nowMin = now.getHours() * 60 + now.getMinutes();
  const all = S.cases().filter(c => c.date === day && (st !== 'surgeon' || c.surgeon === actor.name)).sort((a, b) => A.toMin(a.time) - A.toMin(b.time));
  const flows = new Map(all.map(c => [c.id, caseFlow(c)]));
  const flags = S.flagsAll().filter(f => f.status === 'open');
  const caseFlags = (cid: string) => flags.filter(f => f.caseId === cid);
  const late = (c: A.AscCase) => isToday && (c.loc === 'scheduled' || c.loc === 'arrived' || c.loc === 'preop') && nowMin > A.toMin(c.time) + 10;
  const stageKey = (c: A.AscCase): Key => { const cur = flows.get(c.id)!.cur; return cur < 0 ? 'arriving' : cur >= 6 || c.loc === 'discharged' || c.loc === 'closed' ? 'done' : cur <= 1 ? 'nursing' : F.FLOW[cur] === 'discharge' ? 'pacu' : (F.FLOW[cur] as Key); };
  const myKey: Key | null = ({ preop: 'nursing', anesthesia: 'anesthesia', or: 'or', pacu: 'pacu', front: 'arriving' } as Record<string, Key>)[st] || null;
  const keep = (c: A.AscCase) => { if (mine && myKey && stageKey(c) !== myKey) return false; if (k === 'all') return true; if (k === 'missing') return flows.get(c.id)!.missing.length > 0; if (k === 'late') return late(c); return stageKey(c) === k; };
  const arriving = all.filter(c => c.loc === 'scheduled' && keep(c)); const inside = all.filter(c => ['arrived', 'preop', 'or', 'pacu'].includes(c.loc) && keep(c)); const done = all.filter(c => (c.loc === 'discharged' || c.loc === 'closed') && keep(c));
  const count = (x: Key) => all.filter(c => x === 'all' ? true : x === 'missing' ? flows.get(c.id)!.missing.length > 0 : x === 'late' ? late(c) : stageKey(c) === x).length;
  const tiles: [Key, string][] = [['all', 'All cases'], ['arriving', 'Arriving'], ['nursing', 'Pre-op'], ['anesthesia', 'Anesthesia'], ['or', 'In OR'], ['pacu', 'PACU'], ['done', 'Discharged'], ['missing', 'Missing items'], ['late', 'Running late']];
  const todos = buildTodos(T, day); const isMine = mineMatcher(st, actor.name);
  const todayT = todos.filter(t => t.due <= day); const myQ = todayT.filter(t => isMine(t.who)); const flagT = todayT.filter(t => !isMine(t.who)); const later = todos.filter(t => t.due > day);
  const usedRooms = new Set(all.map(c => c.room)); const dl = new Date(day + 'T12:00');
  const missingArr = all.filter(c => c.loc === 'scheduled' && flows.get(c.id)!.missing.length); const worst = [...missingArr].sort((a, b) => flows.get(b.id)!.missing.length - flows.get(a.id)!.missing.length)[0]; const lates = all.filter(late);
  const brief = <>{missingArr.length ? <>{missingArr.length === all.filter(c => c.loc === 'scheduled').length ? 'All' : missingArr.length} of the {all.filter(c => c.loc === 'scheduled').length} patients still to arrive have missing items.{worst && flows.get(worst.id)!.missing.length > 2 ? <> <b>{medRepo.patient(worst.pid)?.name} ({hm(worst.time)})</b> is missing {flows.get(worst.id)!.missing.length}, including {flows.get(worst.id)!.missing.slice(0, 2).join(' and ').toLowerCase()}.</> : null}</> : 'Everyone still to arrive has their documents in.'}{lates.length ? <> {lates.map(c => medRepo.patient(c.pid)?.name).join(', ')} {lates.length === 1 ? 'is' : 'are'} behind the booked start.</> : null}</>;
  useEffect(() => { if (!menu) return; const f = (e: MouseEvent) => { if (!(e.target as HTMLElement).closest('.t6-menu,.t6-more')) setMenu(''); }; document.addEventListener('mousedown', f); return () => document.removeEventListener('mousedown', f); }, [menu]);

  const More: React.FC<{ c: A.AscCase }> = ({ c }) => { const p = medRepo.patient(c.pid)!; const open = menu === c.id;
    return <span className="t6-morewrap"><button type="button" className="t6-more" aria-label={`More for ${p.name}: chart, details, stations, cancel`} aria-expanded={open} onClick={() => setMenu(open ? '' : c.id)} data-testid="t6-more"><MoreHorizontal size={18} /></button>
      {open && <div className="t6-menu" role="menu" data-testid="t6-menu">
        <button type="button" role="menuitem" onClick={() => { setMenu(''); openChart(c.pid); }} data-testid="a87-chart">Chart</button>
        <button type="button" role="menuitem" onClick={() => { setMenu(''); openAsc({ t: 'details', cid: c.id }); }} data-testid="n9-details">Details</button>
        <div className="t6-msep">Open a station</div>
        {F.FLOW.map(key => { const w = WSS.find(x => x.k === key)!; return <button key={key} type="button" role="menuitem" onClick={() => { setMenu(''); w.open(c); }} data-testid={`a84-ws-${key}`}>{F.FLOW_LABEL[key]}</button>; })}
        {c.loc === 'scheduled' && <><div className="t6-msep" /><button type="button" role="menuitem" className="danger" onClick={() => { setMenu(''); setCx(c.id); }} data-testid="a87-cancel">Cancel case…</button></>}
      </div>}</span>; };
  const FlagLines: React.FC<{ c: A.AscCase }> = ({ c }) => <>{caseFlags(c.id).slice(0, 2).map(f => <div key={f.id} className="t6-flag"><Flag size={15} aria-hidden="true" /><span>{f.text}<span className="t6-who"> · {f.from.replace(/,.*$/, '')} → {A.TEAM_LABEL[f.to]}</span></span></div>)}</>;
  const Who: React.FC<{ c: A.AscCase }> = ({ c }) => { const p = medRepo.patient(c.pid)!; return <div className="t6-who-line"><button type="button" className="t6-name" onClick={() => openChart(c.pid)} data-testid="n9-case-open">{p.name}</button><span className="t6-proc">{c.procedure}{c.side && !c.procedure.toLowerCase().includes(c.side.toLowerCase()) ? ` (${c.side})` : ''} · {shortDr(c.surgeon)} · {anesType(c)}</span></div>; };
  const Track: React.FC<{ cur: number }> = ({ cur }) => <div className="t6-track" aria-hidden="true">{F.FLOW.map((_, i) => <span key={i} className={i < cur ? 'd' : i === cur ? 'c' : ''} />)}</div>;

  const list = <div className="t6-cols">
    <div className="t6-main">
      {arriving.length > 0 && <section className="t6-sec" aria-labelledby="t6-arr"><header><h2 id="t6-arr">Arriving <span>· {arriving.length}</span></h2>{isToday && arriving[0] && <span className="t6-mu">Next: {medRepo.patient(arriving[0].pid)?.name} at {hm(arriving[0].time)}</span>}</header>
        <ol>{arriving.map(c => { const f = flows.get(c.id)!; return <li key={c.id} className="t6-row" data-testid="a87-card" data-case={c.id} data-cleared={f.clear === 'cleared' ? '1' : '0'}>
          <div className="t6-time"><b>{hm(c.time)}</b><span>{c.room}</span></div>
          <div className="t6-body"><Who c={c} />
            {f.missing.length > 0 ? <div className="t6-miss" data-testid="n9-clear"><b>{f.missing.length} missing:</b>{f.missing.slice(0, 3).map(m => <button key={m} type="button" className="t6-chip" onClick={() => openAsc({ t: 'details', cid: c.id })}>{m}</button>)}{f.missing.length > 3 && <button type="button" className="t6-chip more" onClick={() => openAsc({ t: 'details', cid: c.id })}>+{f.missing.length - 3} more</button>}</div>
              : <div className="t6-ok"><Check size={15} aria-hidden="true" />All pre-admission items in</div>}
            {late(c) && <span className="t6-late">Behind booked start</span>}<FlagLines c={c} /></div>
          <div className="t6-acts">{isToday && <button type="button" className="t6-pri" onClick={() => setCi(c.id)} data-testid="a87-checkin">Check in</button>}<More c={c} /></div></li>; })}</ol></section>}
      {inside.length > 0 && <section className="t6-sec" aria-labelledby="t6-in"><header><h2 id="t6-in">In the building <span>· {inside.length}</span></h2><span className="t6-mu">Front desk → Pre-op → Anesthesia → OR → PACU → Discharge</span></header>
        <ol>{inside.map(c => { const f = flows.get(c.id)!; const nk = F.FLOW[Math.min(5, Math.max(0, f.cur))]; const w = WSS.find(x => x.k === nk)!;
          return <li key={c.id} className="t6-row" data-testid="a87-card" data-case={c.id} data-cleared={f.clear === 'cleared' ? '1' : '0'}>
            <div className="t6-time"><b>{hm(c.time)}</b><span>{c.room}</span></div>
            <div className="t6-body"><Who c={c} /><FlagLines c={c} /></div>
            <div className="t6-stage"><Track cur={f.cur} /><div><b data-testid="a87-stage">{WHERE[c.loc]}{c.loc !== 'or' && c.loc !== 'pacu' ? ` · next: ${F.FLOW_LABEL[nk]}` : ''}</b>{late(c) && <span className="t6-late">Behind booked start</span>}</div></div>
            <div className="t6-acts"><button type="button" className="t6-sec-btn" onClick={() => w.open(c)} data-testid="t6-open-next">Open {F.FLOW_LABEL[nk]}</button><More c={c} /></div></li>; })}</ol></section>}
      {(done.length > 0) && <section className="t6-sec t6-done" aria-label="Discharged"><button type="button" className="t6-donebtn" aria-expanded={doneOpen} onClick={() => setDoneOpen(!doneOpen)} data-testid="t6-done-toggle"><b>Discharged <span>· {done.length}</span></b><span className="t6-mu">{done.map(c => medRepo.patient(c.pid)?.name).join(' · ')}</span><span className="t6-showhide">{doneOpen ? 'Hide' : 'Show'}</span></button>
        {doneOpen && <ol>{done.map(c => <li key={c.id} className="t6-row" data-testid="a87-card" data-case={c.id}><div className="t6-time"><b>{hm(c.time)}</b><span>{c.room}</span></div><div className="t6-body"><Who c={c} /><FlagLines c={c} /></div><div className="t6-acts"><button type="button" className="t6-q" onClick={() => openChart(c.pid)} data-testid="a87-chart">Chart</button><More c={c} /></div></li>)}</ol>}</section>}
      {!arriving.length && !inside.length && !done.length && <p className="t6-empty" data-testid="a87-none">{all.length ? <>No patients match this filter. <button type="button" className="t6-link" onClick={() => { setK('all'); setMine(false); }}>Show everyone</button></> : 'No surgeries on this date.'}</p>}
    </div>
    <aside className="t6-rail">
      <section className="t6-card" data-testid="n9-todo-card"><h2>My queue <span>· today {myQ.length}</span></h2>{myQ.length ? <TodoList items={myQ} /> : <p className="t6-mu">Nothing waiting for you.</p>}</section>
      <Coll title="All flags & to-dos" n={flagT.length} sub="Everyone sees every flag. The owner also has it in their queue." tid="t6-all-flags" open0={flagT.length < 8}><TodoList items={flagT} /></Coll>
      <Coll title="Coming up, not today" n={later.length} tid="t6-later" open0={false}><TodoList items={later} /></Coll>
    </aside>
  </div>;

  return <div className="t6" data-testid="sv-dashboard" data-station={st}>
    <header className="t6-head">
      <div><div className="t6-kicker">{({ front: 'Front desk', preop: 'Pre-op nursing', anesthesia: 'Anesthesia', surgeon: 'Surgeon', or: 'OR team', pacu: 'PACU', billing: 'Billing' } as Record<string, string>)[st] || 'Today'} · {dl.toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' })}</div>
        <h1 data-testid="today-title">{isToday ? 'Today' : dl.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' })}</h1>
        <div className="t6-mu" data-testid="today-greeting">{all.length} case{all.length === 1 ? '' : 's'} · {usedRooms.size} room{usedRooms.size === 1 ? '' : 's'}{all[0] ? ` · first case ${hm(all[0].time)}` : ''}{isToday ? <> · now <b>{now.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' })}</b></> : null}</div></div>
      <div className="t6-nav">
        <button type="button" className="t6-ib" onClick={() => setDay(addDays(day, -1))} aria-label="Previous day" data-testid="a87-prev"><ChevronLeft size={18} /></button>
        <input type="date" className="t6-date" value={day} onChange={e => e.target.value && setDay(e.target.value)} data-testid="a87-date" aria-label="Pick a date" />
        <button type="button" className="t6-ib" onClick={() => setDay(addDays(day, 1))} aria-label="Next day" data-testid="a87-next"><ChevronRight size={18} /></button>
        <button type="button" className="t6-q" onClick={() => setDay(T)} disabled={isToday} data-testid="a87-today-btn">Today</button>
        <div className="t6-seg" role="group" aria-label="View"><button type="button" aria-pressed={view === 'list'} className={view === 'list' ? 'on' : ''} onClick={() => setView('list')} data-testid="t6-view-list">List</button><button type="button" aria-pressed={view === 'rooms'} className={view === 'rooms' ? 'on' : ''} onClick={() => setView('rooms')} data-testid="t6-view-rooms">Rooms</button></div>
      </div>
    </header>
    {all.length > 0 && <section className="t6-brief" aria-label="Nightingale brief" data-testid="n9-note"><span className="t6-bmark" aria-hidden="true"><Sparkles size={17} /></span><p>{brief}</p></section>}
    <div className="t6-tiles" data-testid="a87-kpis">{tiles.map(([key, label]) => { const n = count(key); const warn = key === 'missing' || key === 'late';
      return <button key={key} type="button" aria-pressed={k === key} className={`t6-tile ${k === key ? 'on' : ''} ${warn && n ? (key === 'late' ? 'red' : 'amber') : ''}`} onClick={() => setK(k === key ? 'all' : key)} data-testid={`t6-tile-${key}`}><b data-testid="n9-stat">{n}</b><span>{label}</span></button>; })}
      {myKey && <button type="button" aria-pressed={mine} className={`t6-tile mine ${mine ? 'on' : ''}`} onClick={() => setMine(!mine)} data-testid="t6-mine"><b>{mine ? 'On' : 'Off'}</b><span>My station</span></button>}</div>
    {view === 'list' ? list : <RoomsView cases={all} flows={flows} isToday={isToday} nowMin={nowMin} sel={sel} setSel={setSel} onChart={openChart} late={late} />}
    {ci && <CheckInDialog cid={ci} onClose={() => setCi('')} />}{cx && <CancelDialog cid={cx} onClose={() => setCx('')} />}
  </div>;
};

const Coll: React.FC<{ title: string; n: number; sub?: string; tid: string; open0?: boolean; children: React.ReactNode }> = ({ title, n, sub, tid, open0 = true, children }) => { const [o, setO] = useState(open0);
  return <section className="t6-card" data-testid={tid}><button type="button" className="t6-collh" aria-expanded={o} onClick={() => setO(!o)}><h2>{title} <span>· {n}</span></h2><span className="t6-showhide">{o ? 'Hide' : 'Show'}</span></button>{sub && o && <p className="t6-mu">{sub}</p>}{o && (n ? children : <p className="t6-mu">None.</p>)}</section>; };

/* ---------------- Rooms view ---------------- */
const RoomsView: React.FC<{ cases: A.AscCase[]; flows: Map<string, ReturnType<typeof caseFlow>>; isToday: boolean; nowMin: number; sel: string; setSel: (s: string) => void; onChart: (pid: string) => void; late: (c: A.AscCase) => boolean }> = ({ cases, flows, isToday, nowMin, sel, setSel, onChart, late }) => {
  const rooms = Array.from(new Set([...cases.map(c => c.room), 'OR 1', 'OR 2', 'OR 3', 'Proc 1'])).sort((a, b) => (a.startsWith('Proc') ? 1 : 0) - (b.startsWith('Proc') ? 1 : 0) || a.localeCompare(b));
  const start = Math.min(ROOMS_START, ...cases.map(c => A.toMin(c.time) - 30)); const span = Math.max(ROOMS_SPAN, ...cases.map(c => A.toMin(c.time) + (c.durationMin || 60) + 30 - start));
  const pct = (m: number) => `${((m - start) / span) * 100}%`; const hours = Array.from({ length: Math.floor(span / 60) + 1 }, (_, i) => start - (start % 60) + i * 60).filter(m => m >= start && m <= start + span);
  const s = cases.find(c => c.id === sel) || cases.find(c => late(c)) || cases[0];
  const cls = (c: A.AscCase) => c.loc === 'discharged' || c.loc === 'closed' || c.loc === 'pacu' ? 'done' : c.loc === 'or' ? 'live' : late(c) ? 'late' : c.loc === 'scheduled' ? (flows.get(c.id)!.missing.length ? 'miss' : 'sched') : 'in';
  return <div className="t6-rooms" data-testid="t6-rooms">
    <div className="t6-legend"><span><i className="done" />Done / recovering</span><span><i className="live" />In the room now</span><span><i className="in" />Checked in</span><span><i className="miss" />Not arrived · missing items</span><span><i className="late" />Running late</span></div>
    <div className="t6-lanes"><div className="t6-lanes-in">
      <div className="t6-hours"><span />{<div>{hours.map(m => <em key={m} style={{ left: pct(m) }}>{((Math.floor(m / 60) + 11) % 12) + 1}</em>)}</div>}</div>
      {rooms.map(r => { const rc = cases.filter(c => c.room === r); const booked = rc.reduce((n, c) => n + (c.durationMin || 60), 0);
        return <div key={r} className="t6-lane"><div className="t6-lname"><b>{r}</b><span>{Math.floor(booked / 60)} h {booked % 60 ? `${booked % 60} min` : ''} booked</span></div>
          <div className="t6-ltrack">{rc.map(c => { const p = medRepo.patient(c.pid)!; const t = A.toMin(c.time);
            return <button key={c.id} type="button" className={`t6-block ${cls(c)} ${s?.id === c.id ? 'sel' : ''}`} style={{ left: pct(t), width: `calc(${((c.durationMin || 60) / span) * 100}% - 4px)` }} onClick={() => setSel(c.id)} aria-pressed={s?.id === c.id} aria-label={`${c.time} ${c.room}, ${p.name}, ${WHERE[c.loc]}`} data-testid="t6-block"><b>{p.name}</b><span>{WHERE[c.loc]}{c.loc === 'scheduled' && flows.get(c.id)!.missing.length ? ` · ${flows.get(c.id)!.missing.length} missing` : ''}</span></button>; })}
            {isToday && nowMin >= start && nowMin <= start + span && <i className="t6-now" style={{ left: pct(nowMin) }} aria-hidden="true" />}</div></div>; })}
    </div></div>
    {s && (() => { const f = flows.get(s.id)!; const nk = F.FLOW[Math.min(5, Math.max(0, f.cur))]; const w = WSS.find(x => x.k === nk)!; const p = medRepo.patient(s.pid)!;
      return <section className="t6-selbar" aria-live="polite" data-testid="t6-selected"><div className="t6-time"><b>{hm(s.time)}</b><span>{s.room}</span></div>
        <div className="t6-body"><b className="t6-big">{p.name}</b> <span className="t6-proc">{s.procedure} · {shortDr(s.surgeon)}</span><div className="t6-mu">{WHERE[s.loc]}{f.cur >= 0 && f.cur < 6 ? ` · next: ${F.FLOW_LABEL[nk]}` : ''}{f.missing.length ? ` · missing: ${f.missing.join(', ')}` : ''}</div></div>
        <button type="button" className="t6-pri" onClick={() => w.open(s)}>Open {F.FLOW_LABEL[nk]}</button><button type="button" className="t6-q" onClick={() => onChart(s.pid)}>Chart</button></section>; })()}
  </div>;
};
