/* ASC.Vityls v10.6 · Patient chart per the approved tablet mockups ("Patient chart · overview", "· documents", "· past cases",
 * "· past case"). Patient banner (status tags, allergy, flag line) → tabs Overview · Documents · Billing · Past cases.
 * The current case is today's (or the next upcoming); a past case opens in its own read-only view so nothing from another
 * date of service leaks in. Every v9.0 function stays: Profile / Print / Collect payment / Upload, allergy Confirm / Edit,
 * station opening, documents viewer & packet, invoices, credits, cancelled cases and schedule history. Fictional data. */
import React, { useState } from 'react';
import { Check, ClipboardCheck, Stethoscope, Syringe, Scissors, BedDouble, Car, Sparkles, Home, Send, Flag, ChevronLeft, FileText } from 'lucide-react';
import { medRepo, ageFrom, isoDay } from '../../med/record';
import { useActor, useMedTick } from '../../med/ui';
import { useSv } from '../ui';
import { repo } from '../../v6/dataLayer';
import * as A from '../asc8/logic';
import * as S from '../asc8/store';
import { openAsc } from '../asc8/ui';
import { s81, use81 } from '../asc81/store81';
import { caseSignals } from '../asc81/Workbench';
import { bookingChecklist } from '../asc81/ai';
import { WSS, wsStatus } from '../asc84/chips';
import { caseMoney, payTypeOf } from '../asc83/pay';
import { PayChip, cancelledCases } from '../asc83/frontdesk';
import { Overview as StationCards, Documents, Billing } from '../asc83/chart';
import { docsForCase } from '../asc83/docs';
import * as D86 from '../asc86/store86';
import { openUpload, openInvoice } from '../asc87/ui87';
import { ProfileDialog, PrintChartDialog, CreditDialog } from '../asc89/chart89';
import { availableCredit, credits } from '../asc89/store89';
import { creditLeft, OR_TILES } from '../asc89/pure89';
import * as F from '../asc90/flow90';
import { caseFlow, anesType } from '../asc90/today90';
import { clearanceDocs, openDoc, reviewsFor } from './clearance106';
import { notesFor } from './stations106';
import './chart106.css';

const money = (n: number) => `$${n.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
const dos = (d: string) => new Date(d + 'T12:00').toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
const md = (iso?: string) => iso ? new Date(iso).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }) : '';
const hm = (t?: string) => (t || '').replace(/^0/, '');
const shortDr = (n: string) => `Dr. ${n.replace(/,.*$/, '').split(' ').slice(-1)[0]}`;
const done = (c: A.AscCase) => c.loc === 'discharged' || c.loc === 'closed';
type Tab = 'overview' | 'documents' | 'billing' | 'cases';
type St = 'done' | 'in-progress' | 'not-started' | 'exceptions';
interface Ev { k: string; ty: string; when?: string; sub: React.ReactNode; st: St; I: React.FC<any>; open: () => void }

const w = (k: string) => WSS.find(x => x.k === k)!;
const checklistOf = (c: A.AscCase) => bookingChecklist(caseSignals(c, s81.ai(c.id)));
const missingOf = (c: A.AscCase) => checklistOf(c).filter(i => i.state === 'missing');

/** One journey per case: portal → send-to-ASC → six stations. Status comes from the stations themselves. */
function journey(c: A.AscCase): Ev[] {
  const d = c.d as any; const f = caseFlow(c); const upTo = (iso?: string) => iso && iso.slice(0, 10) <= c.date ? md(iso) : ''; const cl = checklistOf(c); const miss = cl.filter(i => i.state === 'missing');
  const curK = f.cur >= 0 && f.cur < 6 ? F.FLOW[f.cur] : '';
  const s = (k: string): St => { const v = wsStatus(c, w(k)).s as St; return v === 'not-started' && k === curK ? 'in-progress' : v; };
  const e = c.events as Record<string, string | undefined>;
  const orT = OR_TILES.filter(o => e[o.key]).map(o => <span key={o.key}>{o.label} <b>{hm(e[o.key])}</b></span>);
  return [
    { k: 'home', ty: 'At-home forms', when: upTo(d.forms?.at), sub: d.forms && d.financial ? 'Consent + health history e-signed in the portal' : 'Registration / financial forms not signed in the portal yet', st: d.forms && d.financial ? 'done' : 'not-started', I: Home, open: () => openAsc({ t: 'details', cid: c.id }) },
    { k: 'send', ty: 'Send-to-ASC', when: upTo(d.clearance?.at), sub: `${shortDr(c.surgeon)}’s office · ${cl.length - miss.length} of ${cl.length} documents${miss.length ? ` · missing ${miss.map(i => i.label.toLowerCase()).join(', ')}` : ''}`, st: miss.length ? 'exceptions' : 'done', I: Send, open: () => openAsc({ t: 'details', cid: c.id }) },
    { k: 'front', ty: 'Front desk', when: d.arrival ? hm(d.arrival) : '', sub: c.loc === 'scheduled' ? 'Not checked in yet' : 'Checked in · ID and insurance verified', st: A.atLeast(c.loc, 'arrived') ? 'done' : s('front'), I: ClipboardCheck, open: () => w('front').open(c) },
    { k: 'nursing', ty: 'Pre-op nursing', sub: 'Vitals, NPO, IV, site check, consent', st: s('nursing'), I: Stethoscope, open: () => w('nursing').open(c) },
    { k: 'anesthesia', ty: 'Anesthesia', sub: `ASA, airway, plan (${anesType(c)})`, st: s('anesthesia'), I: Syringe, open: () => w('anesthesia').open(c) },
    { k: 'or', ty: 'OR', sub: orT.length ? <span className="c6-ort">{orT}</span> : 'Time-out, counts, event times', st: s('or'), I: Scissors, open: () => w('or').open(c) },
    { k: 'pacu', ty: 'PACU', sub: 'Recovery record', st: s('pacu'), I: BedDouble, open: () => w('pacu').open(c) },
    { k: 'discharge', ty: 'Discharge', sub: done(c) ? 'Discharged with instructions and escort' : 'Instructions, discharge order, escort', st: done(c) ? 'done' : s('discharge'), I: Car, open: () => w('discharge').open(c) },
  ];
}
const ST_LIVE: Record<St, [string, string]> = { done: ['Done', 'ok'], 'in-progress': ['In progress', 'warm'], 'not-started': ['Not started', 'plain'], exceptions: ['Needs review', 'peach'] };
const STATION_KEYS = ['nursing', 'anesthesia', 'or', 'pacu'];

const Journey: React.FC<{ c: A.AscCase; past?: boolean }> = ({ c, past }) => {
  const ev = journey(c); const nDone = ev.filter(e => e.st === 'done').length; const unsigned = ev.filter(e => STATION_KEYS.includes(e.k) && e.st !== 'done');
  return <section className="c6-box" data-testid="a89-timeline">
    <div className="c6-bh"><h3>{past ? 'Journey that day' : `${c.date === isoDay() ? 'Today’s' : 'Case'} journey`}</h3><span className="c6-mu">· {past && unsigned.length ? `${unsigned.length} not signed` : `${nDone} of ${ev.length} done`}</span></div>
    <ol className="c6-journey">{ev.map(e => { const [lab, cls] = past && e.k !== 'home' && e.k !== 'send' ? (e.st === 'done' ? ['Signed', 'ok'] : ['Not signed', 'peach']) : ST_LIVE[e.st]; const active = !past && e.st === 'in-progress';
      return <li key={e.k} className={`c6-ev ${e.st === 'done' ? 'ok' : active ? 'now' : ''}`} data-testid="n9-rec-ev" data-k={e.k}>
        <span className="c6-node" aria-hidden="true">{e.st === 'done' ? <Check size={14} /> : <e.I size={14} />}</span>
        <button type="button" className="c6-evb" onClick={e.open} data-testid={`n9-rec-${e.k}`}><span className="c6-evt"><b>{e.ty}</b>{e.when && <span className="c6-mu">{e.when}</span>}<span className={`n9-chip ${cls}`}>{lab}</span></span><span className="c6-evs">{e.sub}</span></button>
        {active && <button type="button" className="c6-btn pri sm" onClick={e.open}>Open</button>}
      </li>; })}</ol>
  </section>;
};

const NotesFlags: React.FC<{ c: A.AscCase; title: string; empty: string }> = ({ c, title, empty }) => {
  const notes = notesFor(c.id); const flags = S.flagsAll().filter(f => f.caseId === c.id).sort((a, b) => b.at.localeCompare(a.at));
  const items = [...notes.map(n => ({ id: n.id, at: n.at, text: n.text, by: `${n.by} · ${n.station}${n.flaggedTo ? ` · flagged for ${A.TEAM_LABEL[n.flaggedTo] || n.flaggedTo}` : ''}`, flag: !!n.flaggedTo, st: '' })),
    ...flags.map(f => ({ id: f.id, at: f.at, text: f.text, by: `${f.from} · ${f.fromRole} → ${A.TEAM_LABEL[f.to] || f.to}`, flag: true, st: f.status === 'open' ? 'Open' : f.reply ? `Answered: ${f.reply}` : 'Closed' }))].sort((a, b) => b.at.localeCompare(a.at));
  return <section className="c6-box" data-testid="c6-notes"><div className="c6-bh"><h3>{title}</h3><span className="c6-mu">· {items.length}</span></div>
    {items.length ? <ul className="c6-notes">{items.map(n => <li key={n.id} className={n.flag ? 'flag' : ''}>{n.flag && <Flag size={14} />}<div><p>{n.text}</p><span className="c6-mu">{n.by} · {new Date(n.at).toLocaleString('en-US', { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' })}{n.st ? ` · ${n.st}` : ''}</span></div></li>)}</ul> : <p className="c6-mu">{empty}</p>}
  </section>;
};

const summaryOf = (c: A.AscCase, first: string, extra = '') => {
  const T = isoDay(); const miss = missingOf(c).map(i => i.label.toLowerCase()); const e = c.events as Record<string, string | undefined>; const m = caseMoney(c);
  const when = c.date === T ? 'today' : `on ${dos(c.date)}`;
  if (done(c)) return `${c.procedure} with ${shortDr(c.surgeon)} in ${c.room} ${when}.${e.inRoom ? ` In room ${hm(e.inRoom)}` : ''}${e.outRoom ? `, out ${hm(e.outRoom)}` : ''}${e.inRoom ? '.' : ''} Discharged with instructions and an escort. ${m.paid > 0 ? `Paid ${money(m.paid)}; ` : ''}balance ${money(m.balance)}.${extra}`;
  return `${first} ${c.loc === 'scheduled' ? 'is scheduled for' : 'is having'} ${c.procedure.toLowerCase()} with ${shortDr(c.surgeon)} in ${c.room} ${when} at ${hm(c.time)} under ${anesType(c).toLowerCase()} anesthesia. ${miss.length ? `Still missing: ${miss.slice(0, 4).join(', ')}.` : 'All clearance documents are in.'}${m.balance > 0 ? ` Open balance ${money(m.balance)}.` : ''}${extra}`;
};

/** Read-only view of one date of service: everything from that day and nothing from any other. */
const PastCase: React.FC<{ c: A.AscCase; first: string; onBack?: () => void }> = ({ c, first, onBack }) => {
  const ev = journey(c); const unsigned = ev.filter(e => STATION_KEYS.includes(e.k) && e.st !== 'done'); const m = caseMoney(c); const e = c.events as Record<string, string | undefined>;
  const times = OR_TILES.filter(o => e[o.key]);
  return <div className="c6-past" data-testid="c6-past-case" data-case={c.id}>
    {onBack && <button type="button" className="c6-back" onClick={onBack} data-testid="c6-past-back"><ChevronLeft size={16} /> All cases</button>}
    <div className="c6-pasth"><span className="c6-kick">Date of service · {c.date < isoDay() ? 'past case' : c.date === isoDay() ? 'today' : 'upcoming'}</span><h2>{dos(c.date)} · {c.procedure}</h2><span className="c6-mu">{shortDr(c.surgeon)} · {c.room} · {hm(c.time)} · {anesType(c)}{done(c) ? ' · read-only record' : ''}</span></div>
    <section className="c6-ai"><span className="c6-mark"><Sparkles size={14} /></span><div><b>That day, in short</b><p data-testid="c6-past-sum">{summaryOf(c, first)}</p>{unsigned.length > 0 && <p className="c6-warn">{unsigned.length} station record{unsigned.length === 1 ? ' was' : 's were'} never signed ({unsigned.map(x => x.ty.toLowerCase()).join(', ')}).</p>}</div></section>
    <div className="c6-grid">
      <div className="c6-col"><Journey c={c} past={done(c)} />
        {times.length > 0 && <section className="c6-box"><div className="c6-bh"><h3>OR times</h3></div><div className="c6-times">{times.map(o => <div key={o.key}><span>{o.label}</span><b>{hm(e[o.key])}</b></div>)}</div></section>}</div>
      <div className="c6-col">
        <section className="c6-box" data-testid="c6-past-bill"><div className="c6-bh"><h3>Billing</h3><button type="button" className="c6-btn sm" style={{ marginLeft: 'auto' }} onClick={() => openInvoice(c.id)} data-testid="c6-past-invoice">Invoice</button></div>
          <div className="c6-kv"><div><span>Patient part</span><b>{money(m.due)}</b></div><div><span>Paid</span><b>{money(m.paid)}</b></div><div><span>Balance</span><b className={m.balance > 0 ? 'r' : ''}>{money(m.balance)}</b></div><div><span>Payment type</span><b>{payTypeOf(c)}</b></div></div></section>
        <NotesFlags c={c} title="Notes & flags that day" empty="No notes or flags were recorded for this case." />
      </div>
    </div>
    <section className="c6-box"><div className="c6-bh"><h3>Documents</h3><span className="c6-mu">· {docsForCase(c).length}</span></div><Documents c={c} cs={[c]} onPick={() => {}} /></section>
  </div>;
};

export const AscChart106: React.FC<{ patientId: string }> = ({ patientId }) => {
  useMedTick(); use81(); const [actor] = useActor(); const { go, toast } = useSv(); const p = medRepo.patient(patientId);
  const [tab, setTab] = useState<Tab>('overview'); const [dlg, setDlg] = useState<'' | 'profile' | 'print' | 'credit'>(''); const [pastSel, setPastSel] = useState(''); const [docSel, setDocSel] = useState('');
  const T = isoDay(); const cs = S.cases().filter(c => c.pid === patientId).sort((a, b) => b.date.localeCompare(a.date));
  const c = cs.find(x => x.date === T) || cs.filter(x => x.date > T).sort((a, b) => a.date.localeCompare(b.date))[0];
  if (!p) return null;
  const first = p.name.split(' ')[0]; const cr = availableCredit(p.id); const due = cs.reduce((n, x) => n + caseMoney(x).balance, 0);
  const f = c ? caseFlow(c) : null; const sc = f ? F.stageChip(f.cur) : null; const miss = c ? missingOf(c) : [];
  const cdocs = c ? clearanceDocs(c) : []; const reviewed = c ? reviewsFor(c.id) : {}; const medClear = c && cdocs.some(d => d.kind === 'Clearance' || d.kind === 'H&P');
  const flags = S.flagsAll().filter(x => x.status === 'open' && (x.pid === p.id || cs.some(k => k.id === x.caseId)));
  const confirmAllergy = () => { medRepo.savePatient({ ...p, allergiesConfirmedAt: new Date().toISOString() } as any); repo.audit({ caseId: `pt:${p.id}`, user: actor.name, role: actor.role, action: 'asc90.allergy-confirm' as any, detail: `Allergies confirmed: ${p.allergies.join('; ') || 'NKDA'}` }); toast('Allergies confirmed and logged.'); };
  const today = S.cases().filter(x => x.date === T).sort((a, b) => A.toMin(a.time) - A.toMin(b.time));
  const docCase = cs.find(x => x.id === docSel) || c || cs[0]; const pastCase = cs.find(x => x.id === pastSel);
  const nDocs = docCase ? docsForCase(docCase).length : 0;
  const nextOpen = c ? journey(c).find(e => e.st === 'in-progress' && STATION_KEYS.concat('front', 'discharge').includes(e.k)) : undefined;
  const pick = (k: Tab) => { setTab(k); if (k === 'cases') setPastSel(''); };

  return <div className="c6" data-testid="a83-chart">
    <div className="c6-top"><button type="button" className="c6-crumb" onClick={() => go({ type: 'tab', tab: 'patients' } as any)} data-testid="a87-chart-back"><ChevronLeft size={16} /> Patients</button>
      <div className="c6-acts"><button type="button" className="c6-btn" onClick={() => setDlg('profile')} data-testid="a89-btn-profile">Profile</button><button type="button" className="c6-btn" onClick={() => setDlg('print')} data-testid="a89-btn-print">Print</button>{(c || cs[0]) && <button type="button" className="c6-btn" onClick={() => { const x = c || cs[0]; openUpload(x.id, x.pid); }} data-testid="a89-btn-upload">Upload</button>}<button type="button" className="c6-btn pri" onClick={() => setDlg('credit')} data-testid="a89-btn-collect">Collect payment</button></div></div>

    <section className="c6-pt" data-testid="a89-snap">
      <div className="c6-id"><span className="c6-av">{p.name.split(' ').map(x => x[0]).slice(0, 2).join('')}</span>
        <div className="min-w-0"><h1 data-testid="a83-chart-name">{p.name}</h1>
          <div className="c6-mu">{ageFrom(p.dob)} · {p.sex[0]}{c ? <> · <b className="c6-ink">{c.procedure}</b> · {shortDr(c.surgeon)} · {c.room} · {hm(c.time)}{c.date !== T ? ` (${dos(c.date)})` : ''} · {anesType(c)} · {c.anesthesia}</> : p.insurance ? ` · ${p.insurance}` : ''}</div>
          <div className="c6-tags">{c && medClear && <span className="n9-chip ok">Medically cleared</span>}{c && <span className={`n9-chip ${miss.length ? 'peach' : 'ok'}`} data-testid="c6-missing-tag">{miss.length ? `${miss.length} item${miss.length === 1 ? '' : 's'} missing` : 'All items in'}</span>}{sc && <span className={`n9-chip ${sc.cls}`}>{sc.t}</span>}{cr > 0 && <span className="n9-chip ok" data-testid="a89-credit-chip">Credit {money(cr)}</span>}{!c && cs[0] && <span className="n9-chip plain">No upcoming case</span>}</div></div>
        <div className={`c6-alg ${p.allergies.length ? 'red' : 'green'}`} data-testid="n9-allergy"><span className="c6-kick">{p.allergies.length ? 'Allergy' : 'Allergies'}</span><b>{p.allergies.length ? p.allergies.join('; ') : 'No known drug allergies'}</b>
          <span className="c6-algb">{p.allergiesConfirmedAt ? <span className="c6-mu">Confirmed {md(p.allergiesConfirmedAt)}</span> : <><span className="c6-mu">Not confirmed today</span><button type="button" className="c6-btn sm" onClick={confirmAllergy} data-testid="n9-allergy-confirm">Confirm</button></>}<button type="button" className="c6-lnk" onClick={() => setDlg('profile')} data-testid="n9-allergy-edit">Edit</button></span></div></div>
      {flags.length > 0 && <div className="c6-flagline" data-testid="c6-flagline"><Flag size={15} /><b>{flags.length} flag{flags.length === 1 ? '' : 's'}</b><span>· {flags[0].text} <span className="c6-mu">({flags[0].from})</span>{flags.length > 1 ? ` +${flags.length - 1} more` : ''}</span></div>}
    </section>

    <nav className="c6-tabs" role="tablist">{([['overview', 'Overview'], ['documents', `Documents · ${nDocs}`], ['billing', `Billing${due > 0 ? ` · ${money(due)}` : ''}`], ['cases', `Past cases · ${cs.filter(x => x.date < T).length}`]] as [Tab, string][]).map(([k, l]) =>
      <button key={k} type="button" role="tab" aria-selected={tab === k} className={tab === k ? 'on' : ''} onClick={() => pick(k)} data-testid={`a83-chart-tab-${k}`}>{l}</button>)}</nav>

    {tab === 'overview' && (c ? <div className="c6-grid" data-testid="c6-overview">
      <div className="c6-col">
        <section className="c6-ai"><span className="c6-mark"><Sparkles size={14} /></span><div><b>Living summary <span className="c6-mu">· Draft · staff confirm</span></b><p data-testid="n9-living">{summaryOf(c, first, cr > 0 ? ` ${money(cr)} credit on account.` : '')}</p></div></section>
        {(nextOpen || due > 0) && <div className="c6-next" data-testid="c6-next"><span className="c6-mu">{due > 0 ? `${money(due)} open` : 'Nothing owed'}</span>{due > 0 && <button type="button" className="c6-btn" onClick={() => setDlg('credit')}>Collect {money(due)}</button>}{nextOpen && <button type="button" className="c6-btn pri" onClick={nextOpen.open} data-testid="c6-open-next">Open {nextOpen.ty}</button>}</div>}
        <Journey c={c} />
        <div className="c6-pills" data-testid="n9-open-station"><span className="c6-mu">Open a station:</span>{F.FLOW.map(k => <button key={k} type="button" className="c6-pill" onClick={() => w(k).open(c)} data-testid={`n9-os-${k}`}>{F.FLOW_LABEL[k]}</button>)}</div>
        <details className="c6-box c6-fold"><summary>Station summaries (Nightingale drafts)</summary><StationCards pid={p.id} cs={[c]} /></details>
      </div>
      <div className="c6-col">
        <section className="c6-box" data-testid="a89-attn"><div className="c6-bh"><h3>Missing</h3><span className="c6-mu">· {miss.length}</span></div>
          {miss.length ? <ul className="c6-miss">{miss.map(i => <li key={i.id}><span>{i.label}</span><button type="button" className="c6-btn sm" onClick={() => openAsc({ t: 'details', cid: c.id })}>Add</button></li>)}</ul> : <p className="c6-mu">Nothing missing for this case.</p>}
          {!p.allergiesConfirmedAt && <p className="c6-mu">Allergies not confirmed.</p>}</section>
        <NotesFlags c={c} title="Notes from the team" empty="Notes typed or dictated at any station show here, newest first." />
        {cdocs.length > 0 && <section className="c6-box" data-testid="n9-clear-docs"><div className="c6-bh"><h3>Clearance documents</h3><span className="c6-mu">· {Object.keys(reviewed).length} of {cdocs.length} reviewed</span></div>
          <ul className="c6-docs">{cdocs.map(d => <li key={d.id}><FileText size={15} /><span className="flex-1">{d.title}<span className="c6-mu"> · {d.kind}</span></span>{reviewed[d.id] && <span className="n9-chip ok">✓ {reviewed[d.id].initials}</span>}<button type="button" className="c6-lnk" onClick={() => openDoc(c.id, d.id)} data-testid="c6-clr-view">View</button></li>)}</ul></section>}
        <section className="c6-box" data-testid="a89-account"><div className="c6-bh"><h3>Account & care team</h3></div><div className="c6-kv"><div><span>Open balance</span><b className={due > 0 ? 'r' : ''}>{money(due)}</b></div><div><span>Available credit</span><b className="g" data-testid="a89-chart-credit">{money(cr)}</b></div><div><span>Surgeon</span><b>{c.surgeon}</b></div><div><span>Anesthesia</span><b>{c.anesthesia}</b></div><div><span>Room</span><b>{c.room}</b></div><div><span>Payment</span><b>{payTypeOf(c)}</b></div></div></section>
        <section className="c6-box" data-testid="n9-today-cases"><div className="c6-bh"><h3>Today’s cases</h3></div>{today.map(x => { const xm = missingOf(x).length; return <button key={x.id} type="button" className={`c6-tcr ${x.pid === p.id ? 'on' : ''}`} onClick={() => go({ type: 'chart', pid: x.pid } as any)}><span>{hm(x.time)} · {medRepo.patient(x.pid)?.name}</span><span className={`n9-chip ${xm ? 'peach' : 'ok'}`}>{xm ? `${xm} missing` : 'all in'}</span></button>; })}{!today.length && <p className="c6-mu">No cases today.</p>}</section>
      </div>
    </div> : cs[0] ? <PastCase c={cs[0]} first={first} /> : <p className="c6-mu">No cases yet. Book one from the Schedule.</p>)}

    {tab === 'documents' && (docCase ? <div className="c6-col" data-testid="c6-docs">
      {docCase.id === c?.id && miss.length > 0 && <div className="c6-banner" data-testid="c6-doc-missing"><b>{miss.length} missing:</b> {miss.map(i => i.label).join(', ')}<button type="button" className="c6-btn sm" onClick={() => openUpload(docCase.id, docCase.pid)}>Upload</button></div>}
      {docCase.id === c?.id && cdocs.length > 0 && <section className="c6-box"><div className="c6-bh"><h3>Clearance documents</h3><span className="c6-mu">· open full screen to mark or initial</span></div><ul className="c6-docs">{cdocs.map(d => <li key={d.id}><FileText size={15} /><span className="flex-1">{d.title}<span className="c6-mu"> · {d.kind} · {d.date}</span></span>{reviewed[d.id] && <span className="n9-chip ok">Reviewed · {reviewed[d.id].initials}</span>}<button type="button" className="c6-lnk" onClick={() => openDoc(docCase.id, d.id)} data-testid="c6-doc-clr-view">View</button></li>)}</ul></section>}
      <section className="c6-box"><Documents c={docCase} cs={cs} onPick={setDocSel} /></section></div> : <p className="c6-mu">No cases yet.</p>)}

    {tab === 'billing' && <div className="c6-col" data-testid="c6-billing">
      <section className="c6-box"><div className="c6-kv"><div><span>Open balance</span><b className={due > 0 ? 'r' : ''}>{money(due)}</b></div><div><span>Available credit</span><b className="g">{money(cr)}</b></div></div>
        {credits(p.id).length > 0 && <ul className="c6-mu c6-cred">{credits(p.id).map(k => <li key={k.id}>{k.receipt} · {k.type} · {money(k.amount)} · left {money(creditLeft(k))}</li>)}</ul>}</section>
      <section className="c6-box"><Billing pid={p.id} cs={cs} /></section></div>}

    {tab === 'cases' && (pastCase ? <PastCase c={pastCase} first={first} onBack={() => setPastSel('')} /> : <div className="c6-col" data-testid="a83-chart-cases">
      <ul className="c6-cases">{cs.map(x => { const m = caseMoney(x); const ev = journey(x); const un = done(x) ? ev.filter(e => STATION_KEYS.includes(e.k) && e.st !== 'done').length : 0; const dt = new Date(x.date + 'T12:00');
        return <li key={x.id}><button type="button" className={`c6-case ${x.id === c?.id ? 'on' : ''}`} onClick={() => setPastSel(x.id)} data-testid="a83-chart-case">
          <span className="c6-date"><small>{dt.toLocaleDateString('en-US', { month: 'short' })}</small><b>{dt.getDate()}</b><small>{dt.getFullYear()}</small></span>
          <span className="min-w-0 flex-1"><b>{x.procedure}</b><span className="c6-mu">{x.date === T ? 'Today · ' : ''}{shortDr(x.surgeon)} · {x.room} · {hm(x.time)} · {anesType(x)}</span>
            <span className="c6-tags"><span className="n9-chip plain">{A.LOC_LABEL[x.loc]}</span><span className="c6-mu">{docsForCase(x).length} documents</span><PayChip c={x} />{m.balance > 0 && <span className="c6-mu">{money(m.balance)} open</span>}{un > 0 && <span className="n9-chip peach">{un} stations not signed</span>}</span></span>
          <span className="c6-chev" aria-hidden="true">›</span></button></li>; })}</ul>
      <p className="c6-mu">Tap a case to see everything from that date of service: timeline, times, documents, billing, notes and flags.</p>
      {cancelledCases(p.id).map((x: any) => <div key={x.id} className="a83-caserow off"><span className="d">{dos(x.date)}</span><span className="flex-1">{x.procedure}</span><span className="sv-small">Cancelled · {x.cancelled.reason}</span></div>)}
      {D86.schedHistory(p.id).length > 0 && <details className="c6-box c6-fold" data-testid="a86-chart-hist"><summary>Booking, reschedule &amp; cancellation history ({D86.schedHistory(p.id).length})</summary>{D86.schedHistory(p.id).map((h, i) => <div key={i} className="a81-line sv-small"><b>{h.kind}</b> · {new Date(h.at).toLocaleString()} · {h.by} · {h.from || h.to}{h.reason ? ` · ${h.reason}` : ''}</div>)}</details>}
    </div>)}

    {dlg === 'profile' && <ProfileDialog pid={p.id} onClose={() => setDlg('')} />}{dlg === 'print' && <PrintChartDialog pid={p.id} cid={(c || cs[0])?.id} onClose={() => setDlg('')} />}{dlg === 'credit' && <CreditDialog pid={p.id} onClose={() => setDlg('')} />}
  </div>;
};
