/* ASC.Vityls v10.6 · invoice timing, bill-to and sending.
 *  - Self-pay / cash-pay cases are flagged for the front desk to create the invoice and send it 14 days before the day of
 *    surgery (estimate from the booked time on the fee schedule), to the patient and/or the surgeon.
 *  - Cases billed after surgery get an invoice from the actual in-room / out-of-room time on the same fee schedule,
 *    normally sent to the surgeon to pay.
 *  - The invoice keeps the standard template (practice logo, address, contact; asc88 Letterhead). Sending is simulated
 *    (asc8-outbox). Storage: asc106-billing (plan per case), asc106-sent. Henry: invoice.billing_timing, invoice.bill_to,
 *    invoice_delivery. */
import React from 'react';
import { Send, Clock, CalendarClock } from 'lucide-react';
import { useActor, useMedTick } from '../../med/ui';
import { medRepo } from '../../med/record';
import { repo } from '../../v6/dataLayer';
import { svRead, svWrite } from '../store';
import * as A from '../asc8/logic';
import * as S from '../asc8/store';
import { billMinutes } from '../asc89/store89';
import { payTypeOf } from '../asc83/pay';
import * as P from '../asc87/pure87';
import * as D from '../asc87/store87';
import { findProvider } from '../../v7/providers';
import { useSv } from '../ui';

export type Timing = 'pre' | 'post'; export type BillTo = 'patient' | 'surgeon' | 'both';
export interface BillPlan { timing: Timing; billTo: BillTo; setBy?: string; at?: string }
export interface Sent { at: string; by: string; to: ('patient' | 'surgeon')[]; addresses: string[]; number: string; timing: Timing; basis: string; total: number }
const PK = 'asc106-billing'; const SK = 'asc106-sent';
export const SEND_DAYS_BEFORE = 14;

export const isCashCase = (c: A.AscCase) => P.isCash(payTypeOf(c));
export function planFor(c: A.AscCase): BillPlan | null {
  const st = svRead<Record<string, BillPlan>>(PK, {})[c.id]; if (st) return st;
  return isCashCase(c) ? { timing: 'pre', billTo: 'patient' } : null;
}
export function setPlan(c: A.AscCase, p: BillPlan, by: string, role: string) {
  svWrite(PK, { ...svRead<Record<string, BillPlan>>(PK, {}), [c.id]: { ...p, setBy: by, at: new Date().toISOString() } });
  repo.audit({ caseId: `asc8:${c.id}`, user: by, role, action: 'asc106.billplan' as any, detail: `Billing: ${p.timing === 'pre' ? `before surgery (${SEND_DAYS_BEFORE} days ahead)` : 'after surgery (actual room time)'} · bill to ${p.billTo}` });
  window.dispatchEvent(new Event('vityls-med-updated'));
}
export const sentFor = (cid: string) => svRead<Record<string, Sent[]>>(SK, {})[cid] || [];
export const sendBy = (dos: string) => { const d = new Date(dos + 'T12:00'); d.setDate(d.getDate() - SEND_DAYS_BEFORE); return d.toISOString().slice(0, 10); };

export function basisOf(c: A.AscCase) { const m = billMinutes(c); const e = c.events as Record<string, string | undefined>;
  return m.from === 'recorded' ? `Actual room time ${m.orMin} min (in ${tm(e.inRoom)} · out ${tm(e.outRoom)})` : `Estimate from the booked time, ${m.orMin} min`; }
const tm = (v?: string) => !v ? '—' : isNaN(Date.parse(v)) ? v.replace(/^0/, '') : new Date(v).toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' });

export function surgeonContact(c: A.AscCase) { const prov = findProvider(c.surgeon);
  return { name: c.surgeon, email: prov?.email || '', phone: prov?.phone || '' }; }

export function sendInvoice(c: A.AscCase, inv: D.AscInvoice, to: ('patient' | 'surgeon')[], by: string, role: string) {
  const p = medRepo.patient(c.pid)!; const sc = surgeonContact(c); const plan = planFor(c) || { timing: 'pre', billTo: 'patient' };
  const total = P.invoiceTotals(inv.lines, []).total; const basis = basisOf(c);
  const addr = to.map(t => t === 'patient' ? (p.email || `${p.name} (portal message)`) : (sc.email || `${sc.name} (office)`));
  const s: Sent = { at: new Date().toISOString(), by, to, addresses: addr, number: inv.number, timing: plan.timing as Timing, basis, total };
  svWrite(SK, { ...svRead<Record<string, Sent[]>>(SK, {}), [c.id]: [...sentFor(c.id), s] });
  const body = `Invoice ${inv.number} for ${p.name}\nProcedure: ${c.procedure} · Date of surgery ${c.date}\n${basis}\nTotal $${total.toFixed(2)}\n${plan.timing === 'pre' ? `Please pay before the day of surgery.` : 'Billed after surgery from the actual room time.'}\n(Simulated: nothing is sent from this test build.)`;
  svWrite('asc8-outbox', [...S.outbox(), ...addr.map(a => ({ id: `ob-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 5)}`, at: s.at, to: a, subject: `Invoice ${inv.number} · ${c.procedure} · ${c.date}`, body, via: 'Email (simulated)', caseId: c.id }))]);
  repo.audit({ caseId: `asc8:${c.id}`, user: by, role, action: 'asc106.invoice.sent' as any, detail: `Invoice ${inv.number} sent to ${addr.join(' and ')} · ${basis} · $${total.toFixed(2)} (simulated)` });
  window.dispatchEvent(new Event('vityls-med-updated')); return s;
}

/** Front-desk to-dos: pre-surgery invoices (14 days ahead) and post-surgery invoices (after room time is recorded). */
export interface InvTodo { id: string; cid: string; title: string; who: string; due: string; label: string }
export function invoiceTodos(T: string): InvTodo[] {
  const out: InvTodo[] = [];
  S.cases().forEach(c => { const plan = planFor(c); if (!plan || c.loc === 'cancelled' as any) return; const sent = sentFor(c.id); const pn = medRepo.patient(c.pid)?.name || 'patient';
    if (plan.timing === 'pre' && c.date >= T && !sent.some(s => s.timing === 'pre')) { const by = sendBy(c.date); const days = P.daysBetween(T, c.date);
      if (days <= SEND_DAYS_BEFORE) out.push({ id: `inv-pre-${c.id}`, cid: c.id, title: `Create and send the pre-surgery invoice · ${pn} (${payTypeOf(c)}) · surgery ${c.date}${T > by ? ' · overdue' : ''}`, who: 'Front desk', due: by < T ? T : by, label: 'Invoice' }); }
    if (plan.timing === 'post' && (c.events as any)?.outRoom && !sent.some(s => s.timing === 'post')) out.push({ id: `inv-post-${c.id}`, cid: c.id, title: `Create the post-surgery invoice from the actual room time · ${pn} · bill ${plan.billTo === 'patient' ? 'the patient' : plan.billTo === 'both' ? 'patient and surgeon' : c.surgeon.replace(/,.*$/, '')}`, who: 'Front desk', due: T, label: 'Invoice' });
  });
  return out;
}

/** Billing panel shown at the top of the invoice: when it is billed, who pays, and send. */
export const BillingPanel: React.FC<{ c: A.AscCase; inv?: D.AscInvoice; onNeedInvoice: () => D.AscInvoice | undefined }> = ({ c, inv, onNeedInvoice }) => {
  useMedTick(); const [actor] = useActor(); const { toast } = useSv(); const plan = planFor(c) || { timing: 'post' as Timing, billTo: 'surgeon' as BillTo }; const sent = sentFor(c.id); const sc = surgeonContact(c); const p = medRepo.patient(c.pid)!;
  const set = (x: Partial<BillPlan>) => setPlan(c, { timing: plan.timing, billTo: plan.billTo, ...x }, actor.name, actor.role);
  const send = (to: ('patient' | 'surgeon')[]) => { const i = inv || onNeedInvoice(); if (!i) return; const s = sendInvoice(c, i, to, actor.name, actor.role); toast(`Invoice ${i.number} sent to ${s.addresses.join(' and ')} (simulated).`); };
  const Seg = <T extends string>({ v, opts, on, tid }: { v: T; opts: [T, string][]; on: (x: T) => void; tid: string }) => <div className="v106-seg" role="group">{opts.map(([k, l]) => <button key={k} type="button" aria-pressed={v === k} className={v === k ? 'on' : ''} onClick={() => on(k)} data-testid={`${tid}-${k}`}>{l}</button>)}</div>;
  const days = P.daysBetween(new Date().toISOString().slice(0, 10), c.date);
  return <section className="v106-billing" data-testid="v106-billing">
    <div className="v106-brow"><span className="sv-label">When</span><Seg v={plan.timing} tid="v106-timing" on={x => set({ timing: x, billTo: x === 'post' && plan.billTo === 'patient' && !isCashCase(c) ? 'surgeon' : plan.billTo })} opts={[['pre', `Before surgery · send by ${sendBy(c.date)}`], ['post', 'After surgery · actual room time']]} /></div>
    <div className="v106-brow"><span className="sv-label">Bill to</span><Seg v={plan.billTo} tid="v106-billto" on={x => set({ billTo: x })} opts={[['patient', 'Patient'], ['surgeon', 'Surgeon'], ['both', 'Patient and surgeon']]} /></div>
    <p className="v106-basis" data-testid="v106-basis">{plan.timing === 'pre' ? <CalendarClock size={15} aria-hidden="true" /> : <Clock size={15} aria-hidden="true" />}{basisOf(c)} · fee schedule{plan.timing === 'pre' ? ` · surgery in ${days} day${days === 1 ? '' : 's'}` : ''}</p>
    <div className="v106-brow">
      {(plan.billTo === 'patient' || plan.billTo === 'both') && <button type="button" className="a8-btn pri" onClick={() => send(plan.billTo === 'both' ? ['patient', 'surgeon'] : ['patient'])} data-testid="v106-send"><Send size={15} aria-hidden="true" /> Send to {plan.billTo === 'both' ? 'patient and surgeon' : p.name.split(' ')[0]}</button>}
      {plan.billTo === 'surgeon' && <button type="button" className="a8-btn pri" onClick={() => send(['surgeon'])} data-testid="v106-send"><Send size={15} aria-hidden="true" /> Send to {sc.name.replace(/,.*$/, '')}</button>}
      {!sc.email && plan.billTo !== 'patient' && <span className="v10-sub">No email on file for {sc.name}: it goes to the surgeon’s office (Practice settings › Providers).</span>}
    </div>
    {sent.length > 0 && <ul className="v106-sent" data-testid="v106-sent">{sent.map((s, i) => <li key={i}>Sent {new Date(s.at).toLocaleString('en-US', { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' })} · {s.number} · to {s.addresses.join(' and ')} · ${s.total.toFixed(2)} · {s.timing === 'pre' ? 'before surgery' : 'after surgery'} · {s.by.replace(/,.*$/, '')}</li>)}</ul>}
  </section>;
};

/** "Bill to" block of the standard invoice template. */
export const BillToBlock: React.FC<{ c: A.AscCase }> = ({ c }) => { const plan = planFor(c); const p = medRepo.patient(c.pid)!; const sc = surgeonContact(c);
  const pt = <div><span className="sv-label">Bill to · patient</span><b>{p.name}</b><div className="sv-small">MRN {p.id} · DOB {p.dob}</div><div className="sv-small">{p.phone} · {p.email}</div></div>;
  const sg = <div><span className="sv-label">Bill to · surgeon</span><b>{sc.name}</b><div className="sv-small">{sc.email || 'Surgeon’s office'}{sc.phone ? ` · ${sc.phone}` : ''}</div><div className="sv-small">Patient: {p.name} · MRN {p.id}</div></div>;
  return plan?.billTo === 'surgeon' ? sg : plan?.billTo === 'both' ? <>{pt}{sg}</> : pt; };
