import { DEMO } from '../asc10/demo';
/* v8.5 · Nightingale search/chat over the schedule (simulated, local data; nothing is sent). */
import { AiBox106 } from '../asc106/ai106';
import React, { useState } from 'react';
import { medRepo, isoDay } from '../../med/record';
import { useMedTick } from '../../med/ui';
import * as S from '../asc8/store';
import * as A from '../asc8/logic';
import { confirmationOf } from '../reminders';
import { caseMoney } from '../asc83/pay';
import { surgeonColor } from '../asc83/booking';
import { ask, type AskCase, type AskResult } from './askpure';
const SUGGEST = DEMO ? ['When is Hugo Pell?', 'Dr Patel’s cases next week', 'Unconfirmed cases', 'Missing clearance this week', 'Unpaid cases'] : ['Cases next week', 'Unconfirmed cases', 'Missing clearance this week', 'Unpaid cases'];
export const toAsk = (): AskCase[] => S.cases().map(c => ({ id: c.id, date: c.date, time: c.time, patient: medRepo.patient(c.pid)?.name || '', surgeon: c.surgeon, procedure: c.procedure, room: c.room, confirmed: confirmationOf(c.visitId)?.status === 'confirmed', missing: A.ITEMS.filter(i => !A.isDone(c, i.key)).map(i => i.label), pay: caseMoney(c).status, loc: A.LOC_LABEL[c.loc] }));
export const ScheduleAsk: React.FC<{ onDay: (d: string) => void; onOpen: (cid: string) => void }> = ({ onDay, onOpen }) => { useMedTick(); const [q, setQ] = useState(''); const [r, setR] = useState<AskResult | null>(null);
  const run = (x = q) => { setQ(x); setR(ask(x, toAsk(), isoDay())); };
  return <section className="a85-ask" data-testid="a85-ask"><AiBox106 value={q} onChange={setQ} onSubmit={() => run()} placeholder="Ask Nightingale: “when is Hugo Pell”, “Dr Patel’s cases next week”, “unconfirmed cases”…" inputId="a85-ask-in" goId="a85-ask-go" sample="Dr Patel’s cases next week" label="Ask Nightingale about the schedule" />{r && <button type="button" className="sv-link sv-small" onClick={() => { setQ(''); setR(null); }}>Clear answer</button>}
    {!r && <div className="a85-sugg">{SUGGEST.map(s => <button key={s} type="button" onClick={() => run(s)} data-testid="a85-ask-sugg">{s}</button>)}</div>}
    {r && <div className="a85-ans" data-testid="a85-ask-answer"><p><b>Nightingale:</b> {r.answer} <span className="sv-small sv-muted">(searched this device’s schedule · simulated)</span></p>
      {r.cases.length > 0 && <ul>{r.cases.map(c => <li key={c.id}><button type="button" onClick={() => { onDay(c.date); onOpen(c.id); }} data-testid="a85-ask-hit" style={{ borderLeftColor: surgeonColor(c.surgeon) }}><b>{new Date(c.date + 'T12:00').toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' })} · {c.time.replace(/^0/, '')}</b> {c.patient} <span className="sv-muted">· {c.procedure} · {c.surgeon.replace(/,.*$/, '')} · {c.room} · {c.loc}{c.confirmed ? '' : ' · not confirmed'}{c.pay === 'unpaid' || c.pay === 'partial' ? ` · ${c.pay}` : ''}</span></button></li>)}</ul>}</div>}
  </section>; };
