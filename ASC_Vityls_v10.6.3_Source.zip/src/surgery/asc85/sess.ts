/* v8.5 · sign-in modes and the shared clinical tablet (pure; node:test). Simulated: no real auth backend. */
export type DeviceMode = 'front' | 'admin' | 'staff';
export const MODE_LABEL: Record<DeviceMode, string> = { front: 'Front desk login', admin: 'Administrator login', staff: 'Clinical tablet · Staff login' };
export const SHARED_STAFF = { name: 'Clinical tablet (Staff)', role: 'Staff tablet' };
/** Roles allowed to act on the shared clinical tablet (nurses, MAs, anesthesia, surgeons, OR). */
export const CLINICAL_RE = /\b(RN|nurse|medical assistant|MA|scrub|circulat\w*|anesthes\w*|CRNA|surgeon|physician|MD|DO)\b/i;
export const isClinical = (role: string) => CLINICAL_RE.test(role) && !/front desk|billing|administrator|manager|coordinator/i.test(role);
export interface UserSession { name: string; role: string; device: string; since: string; last: string; how: 'avatar+pin' | 'pin' }
/** PIN-only identification: the PIN must match exactly one clinical user; otherwise ask the person to tap their name. */
export function identifyByPin<T extends { name: string }>(people: T[], matches: (p: T) => boolean): { kind: 'one'; who: T } | { kind: 'many'; who: T[] } | { kind: 'none' } {
  const m = people.filter(matches); return m.length === 1 ? { kind: 'one', who: m[0] } : m.length ? { kind: 'many', who: m } : { kind: 'none' }; }
export const idleExpired = (lastIso: string, nowMs: number, idleSec: number) => nowMs - Date.parse(lastIso) >= idleSec * 1000;
export const clampIdle = (sec: number) => Math.min(900, Math.max(30, Math.round(sec || 120)));
/** What each sign-in type may open (role-based access still applies inside). */
export function modeAllows(mode: DeviceMode, area: 'board' | 'front' | 'clinical' | 'practice' | 'billing', userRole?: string): boolean {
  if (mode === 'admin') return true;
  if (mode === 'front') return area === 'board' || area === 'front' || area === 'billing';
  if (area === 'board') return true; if (!userRole) return false; return area === 'clinical' && isClinical(userRole); }
