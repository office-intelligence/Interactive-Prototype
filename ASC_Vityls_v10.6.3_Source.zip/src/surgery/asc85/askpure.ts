/* v8.5 · Nightingale schedule search (simulated, local data only; pure for node:test). */
export interface AskCase { id: string; date: string; time: string; patient: string; surgeon: string; procedure: string; room: string; confirmed: boolean; missing: string[]; pay: string; loc: string }
export interface AskResult { answer: string; cases: AskCase[]; intent: string }
const iso = (d: Date) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
const add = (s: string, n: number) => { const d = new Date(s + 'T12:00:00'); d.setDate(d.getDate() + n); return iso(d); };
const monday = (s: string) => { const d = new Date(s + 'T12:00:00'); return add(s, -((d.getDay() + 6) % 7)); };
const DOW = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
export function dateRange(q: string, today: string): [string, string, string] | null {
  if (/\btoday\b/.test(q)) return [today, today, 'today']; if (/\btomorrow\b/.test(q)) return [add(today, 1), add(today, 1), 'tomorrow'];
  if (/\bnext week\b/.test(q)) { const m = add(monday(today), 7); return [m, add(m, 6), 'next week']; }
  if (/\bthis week\b/.test(q)) { const m = monday(today); return [m, add(m, 6), 'this week']; }
  if (/\b(next|coming) (14|two) days\b|\bnext 2 weeks\b/.test(q)) return [today, add(today, 13), 'the next 14 days'];
  const d = DOW.findIndex(x => q.includes(x)); if (d >= 0) { const cur = new Date(today + 'T12:00:00').getDay(); const n = (d - cur + 7) % 7; return [add(today, n), add(today, n), DOW[d][0].toUpperCase() + DOW[d].slice(1)]; }
  return null; }
const last = (n: string) => n.replace(/,.*$/, '').replace(/^dr\.?\s+/i, '').split(/\s+/).pop()!.toLowerCase();
export function ask(qRaw: string, cases: AskCase[], today: string): AskResult {
  const q = qRaw.toLowerCase().replace(/[’']s\b/g, '').replace(/[?.!]/g, ' ').trim(); if (!q) return { answer: '', cases: [], intent: 'none' };
  let l = cases.slice(); const bits: string[] = []; let intent = 'search';
  const surgeons = Array.from(new Set(cases.map(c => c.surgeon))); const sg = surgeons.find(s => new RegExp(`\\b${last(s)}\\b`).test(q)); if (sg) { l = l.filter(c => c.surgeon === sg); bits.push(sg.replace(/,.*$/, '')); }
  const pts = Array.from(new Set(cases.map(c => c.patient))); const pt = pts.find(p => p.toLowerCase().split(/\s+/).filter(w => w.length > 2).every(w => q.includes(w))) || pts.find(p => p.toLowerCase().split(/\s+/).some(w => w.length > 3 && new RegExp(`\\b${w}\\b`).test(q)));
  if (pt) { l = l.filter(c => c.patient === pt); bits.push(pt); intent = 'patient'; }
  const r = dateRange(q, today); if (r) { l = l.filter(c => c.date >= r[0] && c.date <= r[1]); bits.push(r[2]); } else if (!pt) l = l.filter(c => c.date >= today);
  if (/unconfirm|not confirmed/.test(q)) { l = l.filter(c => !c.confirmed); bits.push('not confirmed'); intent = 'unconfirmed'; }
  if (/unpaid|balance|owe|partial/.test(q)) { l = l.filter(c => c.pay === 'unpaid' || c.pay === 'partial'); bits.push('open balance'); intent = 'unpaid'; }
  const item = /clearance|labs?|consent|h&p|forms?|insurance/.exec(q); if (item && /missing|need|without|pending|outstanding|no /.test(q)) { const k = item[0]; l = l.filter(c => c.missing.some(m => m.toLowerCase().includes(k.replace(/s$/, '')))); bits.push(`missing ${k}`); intent = 'missing'; }
  if (/\b(or ?\d|procedure room)\b/.test(q)) { const m = /\bor ?(\d)|procedure room/.exec(q)!; const room = m[1] ? `OR ${m[1]}` : 'Procedure room'; l = l.filter(c => c.room === room); bits.push(room); }
  l.sort((a, b) => (a.date + a.time.replace(/(\d+):(\d+) (AM|PM)/, (_, h, mm, ap) => String((+h % 12) + (ap === 'PM' ? 12 : 0)).padStart(2, '0') + mm)).localeCompare(b.date + b.time.replace(/(\d+):(\d+) (AM|PM)/, (_, h, mm, ap) => String((+h % 12) + (ap === 'PM' ? 12 : 0)).padStart(2, '0') + mm)));
  const what = bits.length ? bits.join(' · ') : 'upcoming cases';
  const answer = intent === 'patient' && l.length ? `${pt} is booked ${l.map(c => `${c.date} at ${c.time.replace(/^0/, '')} (${c.procedure}, ${c.surgeon.replace(/,.*$/, '')}, ${c.room})`).join('; ')}.` : l.length ? `${l.length} case${l.length === 1 ? '' : 's'} · ${what}.` : `No cases found for ${what}.`;
  return { answer, cases: l.slice(0, 25), intent }; }
