/* v8.5 · Sign-in modes: Front desk · Administrator · Clinical tablet (shared Staff login + personal PIN, idle return). Simulated. */
import React, { useEffect, useRef, useState } from 'react';
import { medRepo, isoDay } from '../../med/record';
import { useActor, useMedTick } from '../../med/ui';
import { repo } from '../../v6/dataLayer';
import { svRead, svWrite } from '../store';
import { people, verifyPersonPin, staffList } from '../staff';
import { hashPin, checkSignerPin } from '../../v7/providers';
import * as S from '../asc8/store';
import * as A from '../asc8/logic';
import { MODE_LABEL, SHARED_STAFF, isClinical, identifyByPin, idleExpired, clampIdle, type DeviceMode, type UserSession } from './sess';
export * from './sess';
const DEV = 'asc85-device', USR = 'asc85-user', IDLE = 'asc85-idle-sec';
export const deviceMode = (): DeviceMode => svRead<{ mode: DeviceMode }>(DEV, { mode: 'admin' }).mode;
export const deviceId = () => svRead<{ id?: string }>(DEV, {}).id || 'tablet-1 (simulated)';
export const userSession = () => svRead<UserSession | null>(USR, null);
export const idleSec = () => clampIdle(svRead<number>(IDLE, 120));
export const setIdleSec = (n: number, by: string, role: string) => { svWrite(IDLE, clampIdle(n)); repo.audit({ caseId: 'practice', user: by, role, action: 'session.idle.set' as any, detail: `Clinical tablet idle return set to ${clampIdle(n)} s` }); bump(); };
const bump = () => window.dispatchEvent(new Event('vityls-med-updated'));
export const clinicalPeople = () => people().filter(p => isClinical(p.role));
const pinMatches = (name: string, pin: string) => { const s = staffList().find(x => x.name === name); if (s) return s.active && !s.locked && s.pinHash === hashPin(pin); return checkSignerPin(name, pin) === 'ok'; };
const audit = (user: string, role: string, action: string, detail: string) => repo.audit({ caseId: 'session', user, role, action: action as any, detail: `${detail} · device ${deviceId()}` });
/** Device sign-in (Front desk / Administrator / Clinical tablet). */
export function signInDevice(mode: DeviceMode, setActor: (a: any) => void) {
  const u = userSession(); if (u) endUser('device change', setActor, true);
  svWrite(DEV, { mode, id: deviceId(), at: new Date().toISOString() });
  const a = mode === 'front' ? { name: 'Front Desk Tester', role: 'Front desk', kind: 'human' } : mode === 'admin' ? { name: 'Practice Administrator', role: 'Practice Administrator', kind: 'human' } : { ...SHARED_STAFF, kind: 'human' };
  setActor(a); audit(a.name, a.role, 'session.device', `${MODE_LABEL[mode]} (device session started)`); bump(); }
export function startUser(name: string, role: string, how: UserSession['how'], setActor: (a: any) => void) {
  const now = new Date().toISOString(); const prev = userSession(); svWrite(USR, { name, role, device: deviceId(), since: now, last: now, how });
  setActor({ name, role, kind: 'human' }); audit(name, role, prev ? 'session.user.switch' : 'session.user.start', `${prev ? `Switched from ${prev.name} to` : 'Signed in on shared tablet:'} ${name} (${how === 'pin' ? 'PIN only' : 'tapped name + PIN'})`); bump(); }
export function endUser(reason: 'done' | 'timeout' | 'device change' | 'switch', setActor: (a: any) => void, silent = false) {
  const u = userSession(); if (!u) return; svWrite(USR, null); audit(u.name, u.role, reason === 'timeout' ? 'session.user.timeout' : 'session.user.end', `Returned to shared Staff screen (${reason === 'timeout' ? `idle ${idleSec()} s` : reason})`);
  if (!silent) setActor({ ...SHARED_STAFF, kind: 'human' }); bump(); }
const touch = () => { const u = userSession(); if (u) svWrite(USR, { ...u, last: new Date().toISOString() }); };

export const DeviceSwitch: React.FC = () => { useMedTick(); const [, setActor] = useActor(); const m = deviceMode();
  return <label className="a85-dev" title="Simulated sign-in type for this device (test build)"><span className="hidden xl:inline">Sign-in</span><select className="sv-select" value={m} onChange={e => signInDevice(e.target.value as DeviceMode, setActor)} data-testid="a85-device" aria-label="Sign-in type (simulation)">{(['front', 'admin', 'staff'] as DeviceMode[]).map(k => <option key={k} value={k}>{MODE_LABEL[k]}</option>)}</select></label>; };

/** Shown on the clinical tablet while a person is acting: who, Switch (PIN only), Done. Also runs the idle timer and view audit. */
export const UserChip: React.FC<{ tab: string }> = ({ tab }) => { useMedTick(); const [actor, setActor] = useActor(); const u = userSession(); const [left, setLeft] = useState(idleSec());
  useEffect(() => { if (!u) return; const on = () => touch(); ['pointerdown', 'keydown', 'wheel'].forEach(e => window.addEventListener(e, on, true));
    const t = setInterval(() => { const x = userSession(); if (!x) return; const n = idleSec() - Math.floor((Date.now() - Date.parse(x.last)) / 1000); setLeft(Math.max(0, n)); if (idleExpired(x.last, Date.now(), idleSec())) endUser('timeout', setActor); }, 1000);
    return () => { clearInterval(t); ['pointerdown', 'keydown', 'wheel'].forEach(e => window.removeEventListener(e, on, true)); }; }, [u?.name]);
  useEffect(() => { if (u) audit(u.name, u.role, 'session.view', `Viewed ${tab}`); }, [tab, u?.name]);
  useEffect(() => { if (!u) return; const h = (e: Event) => { const d = (e as CustomEvent).detail || {}; const c = d.cid ? S.caseById(d.cid) : undefined; audit(u.name, u.role, 'session.view', `Opened ${d.bench} workbench${c ? ` · ${medRepo.patient(c.pid)?.name}` : ''}`); }; window.addEventListener('asc81-bench', h); return () => window.removeEventListener('asc81-bench', h); }, [u?.name]);
  if (deviceMode() !== 'staff' || !u) return null;
  return <span className="a85-user" data-testid="a85-user"><span className="av">{initials(u.name)}</span><b>{u.name}</b><span className="sv-small sv-muted hidden md:inline">{u.role}</span><span className="a85-idle" title="Returns to the shared Staff screen when idle" data-testid="a85-idle">{left}s</span>
    <button type="button" className="a85-btn" onClick={() => endUser('switch', setActor)} data-testid="a85-switch">Switch</button><button type="button" className="a85-btn pri" onClick={() => endUser('done', setActor)} data-testid="a85-done">Done</button></span>; };
const initials = (n: string) => n.replace(/,.*$/, '').split(/\s+/).map(x => x[0]).slice(0, 2).join('');
const COLORS = ['#0f766e', '#2563eb', '#7c3aed', '#b45309', '#be185d', '#0369a1', '#4d7c0f'];

/** The shared Staff screen: read-only board + tap your name / enter your PIN. Covers the app until a person signs in. */
export const StaffBoard: React.FC = () => { useMedTick(); const [, setActor] = useActor(); const [who, setWho] = useState(''); const [pin, setPin] = useState(''); const [err, setErr] = useState(''); const [pick, setPick] = useState<string[]>([]); const ref = useRef<HTMLInputElement>(null);
  const vis = deviceMode() === 'staff' && !userSession();
  useEffect(() => { if (vis) { setWho(''); setPin(''); setErr(''); setPick([]); } }, [vis]);
  if (!vis) return null;
  const T = isoDay(); const cs = S.cases().filter(c => c.date === T).sort((a, b) => A.toMin(a.time) - A.toMin(b.time)); const ppl = clinicalPeople();
  const go = (p = pin) => { setErr(''); if (!/^\d{4,8}$/.test(p)) return setErr('Enter your 4-digit PIN.');
    if (who) { const e = verifyPersonPin(who, p); if (e) { setPin(''); return setErr(e); } const r = ppl.find(x => x.name === who)!; startUser(r.name, r.role, 'avatar+pin', setActor); return; }
    const r = identifyByPin(ppl, x => pinMatches(x.name, p)); if (r.kind === 'one') return startUser(r.who.name, r.who.role, 'pin', setActor);
    if (r.kind === 'many') { setPick(r.who.map(x => x.name)); return setErr('This PIN matches more than one person on this tablet: tap your name, then confirm your PIN.'); }
    audit(SHARED_STAFF.name, SHARED_STAFF.role, 'session.pin.fail', 'Unrecognized PIN on shared tablet'); setPin(''); setErr('PIN not recognized. Tap your name and try again.'); };
  const key = (k: string) => { if (k === '⌫') return setPin(x => x.slice(0, -1)); if (k === 'OK') return go(); setPin(x => (x + k).slice(0, 8)); };
  const shown = pick.length ? ppl.filter(p => pick.includes(p.name)) : ppl;
  return <div className="a85-board" data-testid="a85-board" role="dialog" aria-label="Clinical tablet · shared Staff login">
    <header><div><div className="k">Clinical tablet · shared Staff login</div><h1>Today’s board <span className="sv-small sv-muted">read-only</span></h1></div><span className="a85-ro">🔒 Read-only until you tap your name or enter your PIN</span></header>
    <div className="a85-grid"><section className="a85-cases" data-testid="a85-board-cases">{cs.length ? cs.map(c => { const p = medRepo.patient(c.pid); return <div key={c.id} className="a85-case"><span className="t">{c.time.replace(/^0/, '')}</span><span className="min-w-0 flex-1"><b>{p?.name}</b><span className="sv-small sv-muted"> · {c.procedure} · {c.surgeon.replace(/,.*$/, '')} · {c.room}</span></span><span className="a85-loc" style={{ background: A.LOC_COLOR[c.loc] }}>{A.LOC_LABEL[c.loc]}</span></div>; }) : <p className="sv-muted">No cases today.</p>}</section>
      <section className="a85-who"><h2>Who’s using the tablet?</h2><p className="sv-small sv-muted">Tap your name, or just enter your personal PIN. You act as yourself; everything you view, enter or sign is audited to you. Returns here after {idleSec() / 60 >= 1 ? `${Math.round(idleSec() / 60 * 10) / 10} min` : `${idleSec()} s`} idle.</p>
        <div className="a85-avs">{shown.map((p, i) => <button key={p.name} type="button" className={`a85-av ${who === p.name ? 'on' : ''}`} onClick={() => { setWho(who === p.name ? '' : p.name); setErr(''); setTimeout(() => ref.current?.focus(), 0); }} data-testid={`a85-avatar`} data-name={p.name}><span className="c" style={{ background: COLORS[i % COLORS.length] }}>{initials(p.name)}</span><b>{p.name.replace(/,.*$/, '')}</b><span>{p.role}</span></button>)}</div>
        <div className="a85-pinrow"><input ref={ref} className="sv-input" type="password" inputMode="numeric" autoComplete="off" placeholder={who ? `PIN for ${who.replace(/,.*$/, '')}` : 'Your PIN'} value={pin} onChange={e => setPin(e.target.value.replace(/\D/g, '').slice(0, 8))} onKeyDown={e => { if (e.key === 'Enter') go(); }} data-testid="a85-pin" /><button type="button" className="a8-btn pri" onClick={() => go()} data-testid="a85-pin-go">Continue</button></div>
        <div className="a85-pad">{['1', '2', '3', '4', '5', '6', '7', '8', '9', '⌫', '0', 'OK'].map(k => <button key={k} type="button" onClick={() => key(k)} data-testid={`a85-key-${k === '⌫' ? 'del' : k}`}>{k}</button>)}</div>
        {err && <p className="a81-err" data-testid="a85-pin-err">{err}</p>}</section></div></div>; };

export const IdleSetting: React.FC = () => { useMedTick(); const [actor] = useActor(); const [v, setV] = useState(String(idleSec()));
  return <section className="sv-sec mt-8" id="tablet-idle" data-testid="a85-idle-setting"><h2 className="sv-title" style={{ fontSize: 20 }}>Clinical tablet</h2><p className="sv-small sv-muted">Shared Staff login: return to the shared screen after this much inactivity (30–900 seconds).</p>
    <div className="a82-row" style={{ gap: 8 }}><input className="sv-input" style={{ width: 120 }} inputMode="numeric" value={v} onChange={e => setV(e.target.value.replace(/\D/g, ''))} data-testid="a85-idle-input" /><span>seconds</span><button type="button" className="a8-btn" onClick={() => { setIdleSec(+v, actor.name, actor.role); setV(String(idleSec())); }} data-testid="a85-idle-save">Save</button><span className="sv-small">Now: {idleSec()} s</span></div></section>; };
