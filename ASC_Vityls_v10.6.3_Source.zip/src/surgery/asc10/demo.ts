/* ASC.Vityls v10 · clean production build vs optional demo pack.
 * Default: CLEAN. No patients, cases, summaries, sample faxes, messages or activity. Only test sign-in accounts named by
 * role (replaced by Henry's identity service) so every station can be signed during testing.
 * Demo pack (fictional seed data for sales demos and staff training): build with VITE_DEMO=1, or open the app with ?demo=1
 * (remembered in this browser; ?demo=0 turns it off again). Switching wipes this browser's ASC test storage.
 * Pure module: must not import the app (edition.ts / main.tsx read it first). */
const env = ((import.meta as any).env || {}) as Record<string, string | undefined>;
const KEY = 'vityls:asc10:demo';
function resolve(): boolean {
  try {
    const q = new URLSearchParams(location.search);
    if (q.has('demo')) { const on = q.get('demo') !== '0'; window.localStorage.setItem(KEY, on ? '1' : '0'); return on; }
    const s = window.localStorage.getItem(KEY); if (s === '1' || s === '0') return s === '1';
  } catch { /* */ }
  return String(env.VITE_DEMO || '') === '1';
}
export const DEMO: boolean = typeof window !== 'undefined' ? resolve() : false;
export const CLEAN = !DEMO;
/** Seed version: different keys for clean and demo so switching resets the browser test storage once. */
export const ASC10_SEED_VERSION = DEMO ? 'asc101-demo-1' : 'asc101-clean-1';
/** Names of the sign-in accounts. Demo: the fictional v9 people. Clean: role-titled test accounts (not people). */
export const NAMES = DEMO ? {
  surgeon1: 'Sam Patel, MD', surgeon2: 'Dana Whitfield, MD', anes1: 'Noor Haddad, MD', anes2: 'Quinn Ellis, CRNA',
} : {
  surgeon1: 'Test Surgeon, MD', surgeon2: 'Test Surgeon Two, MD', anes1: 'Test Anesthesiologist, MD', anes2: 'Test CRNA, CRNA',
};
/** Re-write the demo flag after a seed reset cleared storage (keeps the demo pack on across reloads). */
export const rememberDemo = () => { try { window.localStorage.setItem(KEY, DEMO ? '1' : '0'); } catch { /* */ } };
