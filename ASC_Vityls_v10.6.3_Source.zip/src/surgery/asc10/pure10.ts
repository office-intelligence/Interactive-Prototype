/* ASC.Vityls v10 · pure helpers (node:test): Nightingale history draft from plain inputs, front-desk document check. */
export interface HxInput { allergies: string[]; allergiesConfirmed?: boolean; meds: { name: string; dose?: string; frequency?: string }[]; problems: string[]; surgical: { text: string; year?: string; detail?: string }[]; intake: { key: string; value: string; detail?: string }[]; formValues: Record<string, unknown> }
export interface HxDraft { allergies: string; meds: string; conditions: string; surgical: string; anesthesia: string; notes: string; sources: number; summary: string }
const yes = (v: unknown) => typeof v === 'string' && v.trim() && !/^(no|none|n\/a|false)$/i.test(v.trim());
/** Nightingale drafts only: it lists what the records say and never decides. Empty input → empty draft (no invented text). */
export function draftHistory(x: HxInput): HxDraft {
  const allergies = x.allergies.length ? x.allergies.join('; ') : '';
  const meds = x.meds.map(m => [m.name, m.dose, m.frequency].filter(Boolean).join(' ')).join('; ');
  const conditions = x.problems.join('; ');
  const fv = Object.entries(x.formValues || {}).filter(([k, v]) => /surg|operation/i.test(k) && yes(v)).map(([, v]) => String(v));
  const surgical = [...x.surgical.map(s => [s.text, s.year && `(${s.year})`, s.detail && `— ${s.detail}`].filter(Boolean).join(' ')), ...fv].join('; ');
  const an = x.intake.filter(a => /anesth|hyperthermia|ponv|nausea/i.test(a.key) && yes(a.value)).map(a => a.detail || `${a.key}: ${a.value}`);
  const anf = Object.entries(x.formValues || {}).filter(([k, v]) => /anesth|ponv|hyperthermia|reaction/i.test(k) && yes(v)).map(([, v]) => String(v));
  const anesthesia = [...an, ...anf].join('; ');
  const notes = x.intake.filter(a => /smok|bleed|clot|apnea|osa/i.test(a.key) && yes(a.value)).map(a => `${a.key}: ${a.value}${a.detail ? ` (${a.detail})` : ''}`).join('; ');
  const sources = [allergies, meds, conditions, surgical, anesthesia, notes].filter(Boolean).length;
  const parts = [conditions && `Conditions: ${conditions}`, allergies ? `Allergies: ${allergies}` : 'No allergies on file yet', meds && `Medications: ${meds}`, anesthesia && `Anesthesia history: ${anesthesia}`];
  return { allergies, meds, conditions, surgical, anesthesia, notes, sources, summary: sources ? parts.filter(Boolean).join('. ') + '.' : 'Nothing on file yet. Add what the patient and the records say, then confirm.' };
}
/** Front desk: which forms and clearance documents are present (no clinical verification). */
export const FRONT_DOCS: { id: string; label: string; kind: 'form' | 'clearance' }[] = [
  { id: 'portal', label: 'Portal forms', kind: 'form' }, { id: 'intake', label: 'Intake forms', kind: 'form' },
  { id: 'hp', label: 'H&P', kind: 'clearance' }, { id: 'labs', label: 'Labs', kind: 'clearance' }, { id: 'ecg', label: 'ECG', kind: 'clearance' }];
export const DOC_TYPE_FOR: Record<string, string> = { portal: 'Registration forms', athome: 'Registration forms', intake: 'Registration forms', hp: 'Pre-op H&P', labs: 'Lab results', ecg: 'ECG' };
export function frontDocs(have: Record<string, boolean>): { id: string; label: string; kind: string; present: boolean }[] { return FRONT_DOCS.map(d => ({ ...d, present: !!have[d.id] })); }
/** Deposit and payments reduce the balance; never below zero. */
export function balanceAfter(charges: number, payments: number[], deposits: number[]): number { const r = Math.round((charges - [...payments, ...deposits].reduce((a, b) => a + b, 0)) * 100) / 100; return r; }
