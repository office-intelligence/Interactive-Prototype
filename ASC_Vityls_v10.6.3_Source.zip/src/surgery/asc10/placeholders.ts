/* ASC.Vityls v10 · placeholder text shows only examples. Any placeholder that is not already an instruction or an
 * "e.g." example is shown as "e.g. …" so it never looks like a real entry. Light gray, regular weight (asc10.css). */
const INSTRUCTION = /^(e\.g\.|search|find|type|ask|enter|add|choose|select|write|optional|dictate|reason|note|search…|filter|message|reply|\.\.\.|…)/i;
export function examplePlaceholder(p: string): string {
  const t = (p || '').trim(); if (!t || INSTRUCTION.test(t) || /e\.g\./i.test(t) || t.length > 60 || /[?]$/.test(t)) return p;
  /* only data-looking text (numbers, emails, dates, a person-like name) is turned into an example */
  if (!/\d|@|^[A-Z][a-z]+ [A-Z][a-z]+(,? [A-Z]{2,4})?$/.test(t)) return p;
  return `e.g. ${t.replace(/^(eg|ex|example)[:.]?\s*/i, '')}`;
}
function fix(el: Element) { const i = el as HTMLInputElement; const p = i.getAttribute('placeholder'); if (p == null) return; const n = examplePlaceholder(p); if (n !== p) i.setAttribute('placeholder', n); }
let on = false;
export function installPlaceholderExamples() {
  if (on || typeof MutationObserver === 'undefined') return; on = true;
  const scan = (root: ParentNode) => root.querySelectorAll?.('input[placeholder],textarea[placeholder]').forEach(fix);
  new MutationObserver(ms => ms.forEach(m => { if (m.type === 'attributes') fix(m.target as Element); else m.addedNodes.forEach(n => { if (n.nodeType === 1) { const e = n as Element; if (e.matches('input[placeholder],textarea[placeholder]')) fix(e); scan(e); } }); }))
    .observe(document.documentElement, { subtree: true, childList: true, attributes: true, attributeFilter: ['placeholder'] });
  scan(document);
}
