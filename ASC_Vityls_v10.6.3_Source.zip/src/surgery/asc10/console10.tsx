/* ASC.Vityls v10.1 · CEO console (owner only). Merges the old CeoAdminDashboard (overview: practices, revenue, health)
 * and the Core AdminConsole (edition, modules, trials) into one page. Opens at #vityls-console (also #vityls-admin and
 * #ceo). Its own sign-in (platform owner test account, PIN 1234; Henry: server-checked owner role + 2FA).
 * Never shows patient charts: only counts. Starts empty without the demo pack. Every action is written to the Core audit log. */
import React, { useState } from 'react';
import { MODULES, MOD, type ModuleId } from '../../core/modules';
import * as P from '../../core/practices';
import { useCoreTick } from '../../core/useCore';
import { staffList } from '../staff';
import { svRead } from '../store';
import { status as connStatus } from '../../connectors';
import { SparkWordmark } from './kit';

export const PLAN_PRICE: Record<string, number> = { starter: 299, clinical: 899, full: 1499, custom: 0 };
export const PLAN_LABEL: Record<string, string> = { starter: 'Starter (Email intake)', clinical: 'Clinical', full: 'Full ASC bundle', custom: 'Custom' };
export const PLAN_MODS: Record<string, ModuleId[]> = { starter: ['email-intake'], clinical: ['email-intake', 'scheduling', 'chart', 'stations-workflow', 'forms', 'asc-perioperative'], full: MODULES.filter(m => m.audience !== 'patient').map(m => m.id).filter(m => m !== 'email-intake') };
export interface Lead { id: string; center: string; contact: string; at: string; plan: string; source: string }
export const leads = () => P.coreRead<Lead[]>('leads', []);
export const addLead = (l: Lead) => P.coreWrite('leads', [...leads(), l]);
const OWNER = 'Platform owner (test account)';
const SESSION = 'vityls:asc10:owner';
const money = (n: number) => `$${n.toLocaleString()}`;
export const mrr = (l: P.Practice[]) => l.filter(p => p.status === 'live').reduce((s, p) => s + (PLAN_PRICE[p.plan || 'custom'] || 0), 0);
const usable = (p: P.Practice, m: ModuleId) => P.usable(P.entitlement(p, m).state);
/** Apply a plan: modules in the plan on (with dependencies), others off. */
export function applyPlan(pid: string, plan: string, by: string) {
  const p = P.practice(pid)!; const want = new Set<ModuleId>((PLAN_MODS[plan] || []).flatMap(m => [m, ...P.missingDeps(p, m)]));
  const mods = Object.fromEntries(Object.keys(p.modules).map(m => [m, want.has(m as ModuleId) ? { ...p.modules[m], state: 'active' as const, since: new Date().toISOString() } : { ...p.modules[m], state: 'off' as const }]));
  P.upsertPractice({ ...p, plan: plan as any, modules: mods }, by, `Plan set to ${PLAN_LABEL[plan]} (${want.size} modules)`);
}
/** Turn a module on, adding missing dependencies automatically (offered and logged). */
export function addModule(pid: string, m: ModuleId, by: string) { const p = P.practice(pid)!; const deps = P.missingDeps(p, m); [...deps, m].forEach(x => P.activate(pid, x, by)); return deps; }

const Gate: React.FC<{ onIn: () => void }> = ({ onIn }) => { const [pin, setPin] = useState(''); const [err, setErr] = useState('');
  return <div className="v10-page" data-testid="ceo-gate" style={{ maxWidth: 420, margin: '10vh auto' }}><div className="v10-card"><SparkWordmark /><h1 className="v10-h" style={{ fontSize: 22 }}>Vityls CEO console</h1>
    <p className="v10-sub">Platform owner only. Clinical staff accounts cannot open this page, and it never shows patient charts.</p>
    <label className="sv-small">Account<input className="sv-input" value={OWNER} readOnly /></label>
    <label className="sv-small">PIN<input className="sv-input" type="password" inputMode="numeric" value={pin} onChange={e => setPin(e.target.value)} placeholder="e.g. 4-digit PIN" data-testid="ceo-pin" /></label>
    {err && <p className="a81-err">{err}</p>}
    <button type="button" className="a8-btn pri" onClick={() => { if (pin === '1234') { sessionStorage.setItem(SESSION, '1'); P.audit({ practiceId: '*', by: OWNER, action: 'console.signin', detail: 'Owner signed in to the CEO console' }); onIn(); } else setErr('Wrong PIN.'); }} data-testid="ceo-signin">Sign in</button>
    <p className="v10-sub">Test build: owner PIN 1234. Production: server-checked owner role with two-step sign-in.</p></div></div>; };

export const CeoConsole: React.FC = () => {
  useCoreTick(); const [inn, setIn] = useState(() => sessionStorage.getItem(SESSION) === '1'); const [open, setOpen] = useState(''); const [tab, setTab] = useState<'practices' | 'leads' | 'usage' | 'audit'>('practices'); const [, f] = useState(0); const [msg, setMsg] = useState('');
  if (!inn) return <Gate onIn={() => setIn(true)} />;
  const by = OWNER; const all = P.practices().filter(p => p.id !== P.CENTER_ID || p.onboarded || p.status === 'live' || P.coreRead('center-touched', false));
  const trials = all.reduce((n, p) => n + Object.values(p.modules).filter(e => e.state === 'trial').length, 0);
  const portalPlans = svRead<any[]>('portal-plus-subs', []); const users = staffList().length; const cases = svRead<any[]>('asc8-cases', []).length;
  const r = () => f(x => x + 1);
  return <div className="v10-page" data-testid="ceo-console" style={{ maxWidth: 1180, margin: '0 auto', padding: 24 }}>
    <div className="v10-row"><SparkWordmark /><h1 className="v10-h" style={{ fontSize: 22, margin: 0 }}>CEO console</h1><span className="v10-chip info">Owner only · no patient data</span><span style={{ marginLeft: 'auto' }} />
      <button type="button" className="a8-btn" onClick={() => { sessionStorage.removeItem(SESSION); setIn(false); }} data-testid="ceo-signout">Sign out</button><a className="a8-btn" href="./">Back to the app</a></div>
    {msg && <div className="a81-ok" data-testid="ceo-msg">{msg}</div>}
    <div className="v10-grid" style={{ gridTemplateColumns: 'repeat(5,1fr)' }} data-testid="ceo-kpis">
      {[['Practices', all.length], ['Live', all.filter(p => p.status === 'live').length], ['Sandbox', all.filter(p => p.status !== 'live' && p.status !== 'suspended').length], ['Active trials', trials], ['MRR', money(mrr(all))]].map(([k, v]) => <div key={k as string} className="v10-card" data-testid={`ceo-kpi-${String(k).toLowerCase().replace(/\W+/g, '')}`}><div className="v10-sub">{k}</div><b style={{ fontSize: 22 }}>{v}</b></div>)}
    </div>
    <div className="v10-card v10-row" data-testid="ceo-finix"><b>Billing (Finix)</b><span className="v10-chip nc">{connStatus('finix') === 'configured' ? 'Configured · awaiting server' : 'Not connected'}</span><span className="v10-sub">MRR is computed from plan test prices for live practices. Real invoices, card/bank payments and dunning come from Finix once connected.</span></div>
    <div className="v10-tabs" role="tablist">{(['practices', 'leads', 'usage', 'audit'] as const).map(t => <button key={t} type="button" role="tab" aria-selected={tab === t} className={tab === t ? 'on' : ''} onClick={() => setTab(t)} data-testid={`ceo-tab-${t}`}>{t[0].toUpperCase() + t.slice(1)}</button>)}</div>
    {tab === 'practices' && (!all.length ? <div className="v10-empty" data-testid="ceo-empty"><b>No practices yet</b><p>New sign-ups from the onboarding wizard appear here as sandbox practices.</p></div> :
      <table className="v10-table" data-testid="ceo-practices"><thead><tr><th>Practice</th><th>Edition</th><th>Plan</th><th>Status</th><th>Modules</th><th /></tr></thead><tbody>
        {all.map(p => <React.Fragment key={p.id}><tr data-testid="ceo-practice" data-pid={p.id}><td><b>{p.name}</b>{p.demo && <span className="v10-chip info">demo</span>}</td>
          <td><select className="sv-input" value={p.edition} onChange={e => { P.upsertPractice({ ...p, edition: e.target.value as any }, by, `Edition set to ${e.target.value}`); r(); }} data-testid="ceo-edition"><option>ASC</option><option>SURGERY</option><option>MEDICAL</option></select></td>
          <td><select className="sv-input" value={p.plan || 'custom'} onChange={e => { applyPlan(p.id, e.target.value, by); setMsg(`${p.name}: plan set to ${PLAN_LABEL[e.target.value]}.`); r(); }} data-testid="ceo-plan">{Object.keys(PLAN_LABEL).map(k => <option key={k} value={k}>{PLAN_LABEL[k]}{PLAN_PRICE[k] ? ` · ${money(PLAN_PRICE[k])}/mo` : ''}</option>)}</select></td>
          <td><select className="sv-input" value={p.status || 'sandbox'} onChange={e => { P.upsertPractice({ ...p, status: e.target.value as any }, by, `Status set to ${e.target.value}`); r(); }} data-testid="ceo-status"><option value="sandbox">Sandbox</option><option value="live">Live</option><option value="suspended">Suspended</option></select></td>
          <td>{MODULES.filter(m => m.audience !== 'patient' && usable(p, m.id)).length} on</td>
          <td><button type="button" className="a8-btn" onClick={() => setOpen(open === p.id ? '' : p.id)} data-testid="ceo-modules-open">{open === p.id ? 'Close' : 'Modules & trials'}</button></td></tr>
          {open === p.id && <tr><td colSpan={6}><div className="v10-grid" data-testid="ceo-modules">{MODULES.filter(m => m.audience !== 'patient').map(m => { const e = P.entitlement(p, m.id); return <div key={m.id} className="v10-card" data-testid="ceo-mod" data-mod={m.id} data-state={e.state}>
            <div className="v10-row"><b>{m.name}</b><span className={`v10-chip ${e.state === 'active' ? 'ok' : e.state === 'trial' ? 'info' : e.state === 'expired' ? 'warn' : 'nc'}`}>{e.state}{e.state === 'trial' && e.daysLeft != null ? ` · ${e.daysLeft} d left` : ''}</span></div>
            <div className="v10-sub">{m.requires.length ? `Needs: ${m.requires.map(x => MOD[x].short).join(', ')}` : 'No dependencies'}</div>
            <div className="v10-row">{!P.usable(e.state) ? <><button type="button" className="a8-btn pri" onClick={() => { const d = addModule(p.id, m.id, by); P.upsertPractice({ ...P.practice(p.id)!, plan: 'custom' }, by, `Module added: ${m.name}`); setMsg(`${m.name} on${d.length ? ` (also added ${d.map(x => MOD[x].short).join(', ')})` : ''}.`); r(); }} data-testid="ceo-mod-on">Turn on</button>
              <button type="button" className="a8-btn" onClick={() => { try { P.startTrial(p.id, m.id, by); setMsg(`${m.name}: ${m.trialDays}-day trial started.`); } catch (x) { setMsg((x as Error).message); } r(); }} data-testid="ceo-mod-trial">Start trial</button></>
              : <>{e.state === 'trial' && <><button type="button" className="a8-btn" onClick={() => { P.extendTrial(p.id, m.id, 7, by); r(); }} data-testid="ceo-mod-extend">+7 days</button><button type="button" className="a8-btn" onClick={() => { P.expireNow(p.id, m.id, by); r(); }} data-testid="ceo-mod-end">End trial</button></>}
                <button type="button" className="a8-btn danger" onClick={() => { const blk = P.blockingDependents(p, m.id); if (blk.length) { setMsg(`Turn off ${blk.map(x => MOD[x].short).join(', ')} first.`); return; } P.deactivate(p.id, m.id, by); P.upsertPractice({ ...P.practice(p.id)!, plan: 'custom' }, by, `Module turned off: ${m.name}`); setMsg(`${m.name} off. Its data is kept.`); r(); }} data-testid="ceo-mod-off">Turn off</button></>}</div></div>; })}</div></td></tr>}
        </React.Fragment>)}</tbody></table>)}
    {tab === 'leads' && (!leads().length ? <div className="v10-empty" data-testid="ceo-leads-empty"><b>No leads yet</b><p>Sign-ups and go-live requests from the onboarding wizard show here.</p></div> :
      <table className="v10-table" data-testid="ceo-leads"><thead><tr><th>Center</th><th>Contact</th><th>Plan</th><th>Source</th><th>When</th></tr></thead><tbody>{leads().map(l => <tr key={l.id}><td>{l.center}</td><td>{l.contact}</td><td>{PLAN_LABEL[l.plan] || l.plan}</td><td>{l.source}</td><td>{new Date(l.at).toLocaleString()}</td></tr>)}</tbody></table>)}
    {tab === 'usage' && <table className="v10-table" data-testid="ceo-usage"><thead><tr><th>Practice</th><th>Staff accounts</th><th>Cases</th><th>Portal Free</th><th>Portal Plus</th></tr></thead><tbody>
      {all.map(p => <tr key={p.id}><td>{p.name}</td>{p.id === P.CENTER_ID ? <><td>{users}</td><td>{cases}</td><td>{portalPlans.filter((x: any) => x.plan !== 'plus').length}</td><td>{portalPlans.filter((x: any) => x.plan === 'plus').length}</td></> : <td colSpan={4} className="v10-sub">Reported by the server once connected</td>}</tr>)}
      {!all.length && <tr><td colSpan={5} className="v10-sub">No practices yet.</td></tr>}</tbody></table>}
    {tab === 'audit' && <table className="v10-table" data-testid="ceo-audit"><thead><tr><th>When</th><th>Who</th><th>Action</th><th>Detail</th></tr></thead><tbody>{P.coreAudit().slice().reverse().slice(0, 200).map((a, i) => <tr key={i}><td>{new Date(a.at).toLocaleString()}</td><td>{a.by}</td><td>{a.action}</td><td>{a.detail}</td></tr>)}</tbody></table>}
    <p className="v10-sub" style={{ marginTop: 16 }}>Replaces CeoAdminDashboard and the Core AdminConsole. Simulated in the browser; Henry: CenterModule table, server-side entitlement checks, owner role.</p>
  </div>;
};
