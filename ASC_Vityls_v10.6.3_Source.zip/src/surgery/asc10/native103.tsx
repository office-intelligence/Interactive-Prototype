/* ASC.Vityls v10.3 · a form-library HTML form rendered natively inside a station (no link, no iframe).
 * Same layout and checkmarks as the library form; answers autosave to the case record; ambient capture fills drafts. Fictional data. */
import React from 'react';
import type { WorkflowKey } from '../../data/formWorkspaceCatalog';
import * as A from '../asc8/logic';
import { FormInPlace } from '../asc82/common';

export const NativeRecord: React.FC<{ c: A.AscCase; file: string; station: WorkflowKey }> = ({ c, file, station }) =>
  <section className="v103-native" data-testid="v103-native" data-file={file}>
    <FormInPlace inline noClose c={c} file={file} station={station} onClose={() => undefined} />
  </section>;

/* ---------- v10.3 · dictation mic (simulated until a BAA-covered speech service is connected) ---------- */
import { Mic } from 'lucide-react';
export const DictateMic: React.FC<{ sample: string; onText: (t: string) => void; label?: string; testId: string }> = ({ sample, onText, label = 'Dictate', testId }) => {
  const [on, setOn] = React.useState(false); const [txt, setTxt] = React.useState(sample);
  return <span className="v103-dict" data-testid={testId}>
    <button type="button" className={`v103-mic sm ${on ? 'on' : ''}`} aria-pressed={on} onClick={() => { if (on) { onText(txt); setOn(false); } else { setTxt(sample); setOn(true); } }} data-testid={testId + '-btn'}><Mic size={18} /> {on ? 'Stop & fill' : label}</button>
    {on && <span className="v103-dictpop" data-testid={testId + '-pop'}><b>● Listening</b> <span className="sv-small sv-muted">Simulated: edit what was said, then tap “Stop &amp; fill”. Filled values are drafts for you to review.</span>
      <textarea className="sv-input" value={txt} onChange={e => setTxt(e.target.value)} /></span>}
  </span>;
};
/** Pull "Label: value." / "label value." pieces out of a dictated sentence. */
export const pick = (t: string, re: RegExp) => { const m = t.match(re); return m ? m[1].trim().replace(/[.;,]$/, '') : ''; };
export const parseBriefOp = (t: string) => ({
  pre: pick(t, /pre-?op(?:erative)? diagnosis[:\s]+([^.]+)/i), post: pick(t, /post-?op(?:erative)? diagnosis[:\s]+([^.]+)/i),
  procedure: pick(t, /procedure(?: performed)?[:\s]+([^.]+)/i), findings: pick(t, /findings[:\s]+([^.]+)/i), ebl: pick(t, /(?:EBL|blood loss)[:\s]+([^.]+)/i),
  specimens: pick(t, /specimens?[:\s]+([^.]+)/i), implants: pick(t, /implants?[:\s]+([^.]+)/i), complications: pick(t, /complications?[:\s]+([^.]+)/i), condition: pick(t, /condition(?: to PACU)?[:\s]+([^.]+)/i),
});

/* ---------- v10.4 · forms shown one after another inside a station (Anesthesia: questionnaire → evaluation → consent) ---------- */
import { repo } from '../../v6/dataLayer';
import { useMedTick } from '../../med/ui';
export const FormSequence: React.FC<{ c: A.AscCase; steps: { file: string; title: string }[]; station: WorkflowKey; testId: string }> = ({ c, steps, station, testId }) => {
  useMedTick(); const [i, setI] = React.useState(0); const [, tick] = React.useState(0);
  React.useEffect(() => { const t = setInterval(() => tick(x => x + 1), 1500); return () => clearInterval(t); }, []);
  const stat = (f: string) => { const r = repo.getForm(c.visitId, f); return r.signatures?.length ? (r.status === 'locked' ? 'Signed' : `${r.signatures.length} signed`) : r.status === 'not-started' ? 'Not started' : 'In progress'; };
  const go = (n: number) => { setI(n); setTimeout(() => document.querySelector(`[data-testid="${testId}"]`)?.scrollIntoView({ block: 'start', behavior: 'smooth' }), 30); };
  const nav = (where: string) => <div className="v104-nav" data-testid={`${testId}-nav-${where}`}>
    <button type="button" className="a8-btn" disabled={i === 0} onClick={() => go(i - 1)} data-testid={`${testId}-back`}>‹ Back</button>
    <span className="v104-of">Form {i + 1} of {steps.length}</span>
    {i < steps.length - 1 ? <button type="button" className="a8-btn pri" onClick={() => go(i + 1)} data-testid={`${testId}-next`}>Next: {steps[i + 1].title} ›</button> : <span className="sv-small sv-muted">Last form</span>}
  </div>;
  return <section className="v104-seq" data-testid={testId} data-step={i + 1}>
    <ol className="v104-steps" data-testid={`${testId}-steps`}>{steps.map((s, k) => { const st = stat(s.file);
      return <li key={s.file}><button type="button" className={`v104-step ${k === i ? 'here' : ''} ${/igned/.test(st) ? 'done' : ''}`} onClick={() => go(k)} aria-current={k === i ? 'step' : undefined} data-testid={`${testId}-step-${k + 1}`}>
        <span className="n">{/igned/.test(st) ? '✓' : k + 1}</span><span className="t"><b>{s.title}</b><small>{st}</small></span></button></li>; })}</ol>
    {nav('top')}
    <NativeRecord key={steps[i].file} c={c} file={steps[i].file} station={station} />
    {nav('bottom')}
  </section>;
};
