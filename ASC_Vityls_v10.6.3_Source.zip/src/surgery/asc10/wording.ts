/* ASC.Vityls v10 · production wording (clean build only). Earlier builds labelled every outside service "simulated" and
 * every screen "fictional". In the clean build nothing is fictional and outside services are simply not connected yet,
 * so the display reads "not connected" instead (see SIMULATED_FEATURES.md for the full list of stubbed services).
 * This is a display layer over legacy strings; new v10 code writes the production wording directly. */
const RULES: [RegExp, string][] = [
  [/\s*\((?:dictated,\s*)?simulat(?:ed|ion)(?:[^()]*)\)/gi, ' (not connected)'],
  [/\bSIMULATION(?: · fictional)?\b/g, 'NOT CONNECTED'],
  [/^Simulated:\s*/i, 'Not connected: '],
  [/\bSimulated scribe\b/gi, 'Scribe (not connected)'],
  [/\bSimulate a patient reply\b/gi, 'Record a patient reply'],
  [/\bSimulate AI unavailable\b/gi, 'Nightingale unavailable'],
  [/\bsimulated OCR\b/gi, 'document reading'],
  [/\bsimulated\b/gi, 'not connected'],
  [/\bSimulated\b/g, 'Not connected'],
  [/\s*·?\s*\bFictional data(?: only)?\.?/g, ''],
  [/\s*\(fictional(?: example)?\)/gi, ''],
  [/\s*·?\s*\bfictional\.?(?=\s*$)/gi, ''],
  [/\bfictional\s+/gi, ''],
];
/** v10.2: internal vocabulary (build notes, our design terms) never reaches users. Applies to every ASC build, demo included. */
const INTERNAL: [RegExp, string][] = [
  [/\(Bank only — no template field\)/g, 'Other details'],
  [/\bQuestion bank\b/g, 'Form questions'], [/\bquestion bank\b/g, 'form questions'], [/\bbank question\b/gi, 'question'],
  [/\bseeded \(test\)/g, '—'], [/\(test account\)/g, ''],
  [/\b(?:v\d+(?:\.\d+)*|MED v0\.\d+|Surgery v0\.\d+):\s+/g, ''],
  [/Practice settings · Surgery\.Vityls/g, 'Practice settings'],
  [/\bSurgery\.Vityls\b/g, 'ASC.Vityls'],
  [/\s*Placeholder facility\s*·?/g, ''],
];
let CLEAN = true;
export function productionText(s: string): string { let t = s; for (const [re, to] of INTERNAL) t = t.replace(re, to); if (CLEAN) for (const [re, to] of RULES) t = t.replace(re, to); return t; }
const NEEDS = /simulat|fictional|SIMULATION|[Bb]ank|seeded \(test|test account|v\d+(\.\d+)*:|Surgery\.Vityls|Placeholder facility/i;
const ATTRS = ['placeholder', 'title', 'aria-label'];
const SKIP = new Set(['SCRIPT', 'STYLE', 'TEXTAREA', 'CODE', 'PRE']);
function fixText(n: Text) { const p = n.parentElement; if (!p || SKIP.has(p.tagName) || p.isContentEditable) return; const v = n.nodeValue || ''; if (!NEEDS.test(v)) return; const t = productionText(v); if (t !== v) n.nodeValue = t; }
function fixEl(e: Element) { ATTRS.forEach(a => { const v = e.getAttribute(a); if (v && NEEDS.test(v)) { const t = productionText(v); if (t !== v) e.setAttribute(a, t); } }); }
function walk(root: Node) {
  if (root.nodeType === 3) return fixText(root as Text); if (root.nodeType !== 1) return; const el = root as Element; if (SKIP.has(el.tagName) && el.tagName !== 'TEXTAREA') return; fixEl(el);
  const w = document.createTreeWalker(el, NodeFilter.SHOW_TEXT | NodeFilter.SHOW_ELEMENT); let n: Node | null = w.nextNode();
  while (n) { if (n.nodeType === 3) fixText(n as Text); else fixEl(n as Element); n = w.nextNode(); }
}
let on = false;
export function installProductionWording(clean = true) {
  CLEAN = clean; if (on || typeof MutationObserver === 'undefined') return; on = true;
  const run = () => walk(document.body);
  new MutationObserver(ms => ms.forEach(m => { if (m.type === 'characterData') fixText(m.target as Text); else if (m.type === 'attributes') fixEl(m.target as Element); else m.addedNodes.forEach(walk); }))
    .observe(document.documentElement, { subtree: true, childList: true, characterData: true, attributes: true, attributeFilter: ATTRS });
  if (document.body) run(); else document.addEventListener('DOMContentLoaded', run);
}
