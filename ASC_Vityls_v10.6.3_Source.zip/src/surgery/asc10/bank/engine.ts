/*
 * ASC.Vityls v7.8 — question-bank engine (pure: no React, no storage). Fictional data only.
 * One master bank of questions (src/v78/bank/bank.json, from Kevin's approved Question Bank v1, QUAD A OBS v16.1).
 * Each station shows only the questions assigned to it (Ask or Confirm). Answers are stored once per episode with provenance.
 * Documents are generated from answers (layout = question groups + signers), PIN-signed as a locked, hashed version;
 * corrections are dated addenda. Nightingale/scribe values stay "AI draft" until a person confirms them.
 */
import BANK from './bank.json';
import { sha256 } from './sha256';

export type Station = 'FD' | 'RN' | 'AN' | 'SX' | 'OR' | 'PA' | 'DC';
export type Kind = 'yesno' | 'choice' | 'multi' | 'text' | 'number' | 'date' | 'list' | 'narrative' | 'event' | 'auto' | 'sign';
export type Rule = { k: 'minor' | 'bmi' | 'female' | 'upt' | 'allergy' | 'always' | 'notHome' | 'vte' | 'notLocal' | 'mhPositive' | 'facilityHP' } | { k: 'has'; q: string; re: string } | { k: 'setting'; s: keyof CenterSettings } | { k: 'classMin'; c: 'A' | 'B' | 'C' } | { k: 'triggered'; x: 'transfer' | 'ama' };
export interface Question {
  id: string; team: string; group: string; text: string; typeText: string; kind: Kind; options: string[]; default: string | null; ruleText: string; rule: Rule | null;
  ask: (Station | 'PT')[]; confirm: Station[]; source: string; required: 'always' | 'classC' | 'ifShown' | 'no'; requiredText: string; docs: { doc: string; signer: string }[];
  verifyGroup: string; verifiedBy: string; cosignedBy: string; obs: string; obsClass: string; medicare: string; v76form: string; pack: string; hidden: boolean;
  /** v7.9: stations whose known-info summary shows this answer (role relevance; customizable). Undefined = every ask/confirm station. */
  summaryFor?: Station[];
  /** v7.9: fixed statement / attestation wording shown with the question and printed verbatim on its documents. */
  statement?: string;
  /** v7.9: source template field(s) in the existing v7.6 form library (scripts/asc79/templates79.py). */
  /** v7.9: 'patient' = documented per case on a station; 'facility' = policy attested periodically (Center Compliance). */
  form?: string; formSection?: string; formOrder?: number[]; bankText?: string; bankOptions?: string[]; tplType?: string;
  scope?: 'patient' | 'facility'; attestedBy?: string; reviewDays?: number;
  src?: { file: string; section: number | null; sectionTitle: string; field: string; fieldIdx: number; score: number; type?: string; options?: string[] }[];
}
import TPL from './templates.json';
export interface TplSection { h: string; fields: string[]; text: string[] }
export interface Tpl { file: string; title: string; sections: TplSection[] }
/** v7.9: the existing v7.6 form templates parsed into layouts (title, section order, field labels, fixed wording). */
export const TEMPLATES: Record<string, Tpl> = TPL as any;
export const DOC_TEMPLATE: Record<string, string> = { 'Registration': 'Patient_Registration', 'Admission Packet': 'Admission_Form', 'Insurance & Fees': 'Insurance_Information', 'Medical History': 'Medical_History', 'Nursing Admission': 'Nursing_Admission', 'MH & VTE': 'MH_and_VTE_Assessment', 'Anesthesia Questionnaire': 'Anesthesia_Questionnaire', 'Anesthesia Evaluation': 'Anesthesia_Evaluation', 'Anesthesia Consent': 'Anesthesia_Consent', 'Anesthesia Orders': 'Anesthesia_Order_Form', 'Anesthesia Record': 'Anesthesia_IntraOp_Record', 'H&P / Clearance': 'PreOp_HP_Clearance', 'Interval H&P': 'DayOf_Interval_HP_Update', 'Surgeon Pre-Op': 'Surgeon_PreOp_Clearance', 'Procedure Consent': 'Procedure_Consent', 'Photography Consent': 'Photography_Media_Research_Consent', 'Surgeon Orders': 'Surgeon_Orders', 'Universal Protocol': 'Universal_Protocol_Safety_Checklist', 'Intra-Op Nursing': 'IntraOp_Nursing_Record_TO', 'Op Report': 'Surgeon_Operative_Report', 'PACU Record': 'PACU_Recovery_Record', 'Discharge Order': 'Physician_Discharge_Order', 'Discharge Instructions': 'Written_Discharge_Instructions', 'Discharge Sign-off': 'PostOp_Discharge', 'Transfer Form': 'Emergency_Transfer_Form', 'AMA / Refusal Form': 'AMA_Refusal_Form', 'Survey': 'Patient_Satisfaction_Survey', 'Immediate Pre-Anesthesia Note': 'Anesthesia_Evaluation' };
export const BASE: Question[] = (BANK as any).questions;
export const BANK_VERSION: string = (BANK as any).version;

export const STATIONS: { id: Station; label: string; role: string; team: string }[] = [
  { id: 'FD', label: 'Front desk', role: 'Front desk', team: 'front' }, { id: 'RN', label: 'Pre-op nursing', role: 'Pre-op RN', team: 'nursing' },
  { id: 'AN', label: 'Anesthesia', role: 'Anesthesia', team: 'anesthesia' }, { id: 'SX', label: 'Surgeon', role: 'Surgeon', team: 'surgeon' },
  { id: 'OR', label: 'OR nursing', role: 'Circulating RN', team: 'nursing' }, { id: 'PA', label: 'PACU', role: 'PACU RN', team: 'nursing' },
  { id: 'DC', label: 'Discharge', role: 'Discharge RN', team: 'nursing' },
];
export const stationLabel = (s: Station | 'PT') => s === 'PT' ? 'Patient portal' : STATIONS.find(x => x.id === s)!.label;

/* ---------- center settings (per practice; QUAD A OBS starter pack) ---------- */
export interface CenterSettings {
  accreditor: 'QUAD A'; program: 'Office-Based Surgery v16.1'; medicarePack: boolean; anesClass: 'A' | 'B' | 'C';
  mhTriggers: boolean; orRecovery: boolean; hpDays: number; uptMaxAge: number; specialtyPacks: string[];
}
export const DEFAULT_SETTINGS: CenterSettings = { accreditor: 'QUAD A', program: 'Office-Based Surgery v16.1', medicarePack: false, anesClass: 'C', mhTriggers: true, orRecovery: false, hpDays: 30, uptMaxAge: 50, specialtyPacks: [] };

/* ---------- practice customization: edit / hide / add / reassign ---------- */
export interface BankOverrides { edits: Record<string, Partial<Pick<Question, 'text' | 'ask' | 'confirm' | 'required' | 'hidden' | 'options' | 'default' | 'summaryFor' | 'statement'>>>; added: Question[]; docs?: Record<string, DocEdit> }
/** v7.9: per-document wording and signer edits (settings). */
export interface DocEdit { attestation?: string; signers?: Station[]; template?: string }
let DOC_EDITS: Record<string, DocEdit> = {};
export const setDocEdits = (d?: Record<string, DocEdit>) => { DOC_EDITS = d || {}; };
export const EMPTY_OVERRIDES: BankOverrides = { edits: {}, added: [] };
export function effectiveBank(o: BankOverrides = EMPTY_OVERRIDES, base: Question[] = BASE): Question[] {
  setDocEdits(o.docs);
  return [...base, ...o.added].map(q => ({ ...q, ...(o.edits[q.id] || {}) }));
}
export function newQuestion(o: BankOverrides, p: { text: string; group: string; kind: Kind; options?: string[]; ask: Station[]; confirm?: Station[]; required?: boolean; doc?: string }): Question {
  const n = o.added.length + 1;
  return { id: `PR-${String(n).padStart(2, '0')}`, team: 'Practice', group: p.group || 'Practice questions', text: p.text, typeText: p.kind, kind: p.kind, options: p.options || (p.kind === 'yesno' ? ['Yes', 'No'] : []), default: null, ruleText: '', rule: null,
    ask: p.ask, confirm: p.confirm || [], source: 'Staff', required: p.required ? 'always' : 'no', requiredText: p.required ? 'Required' : 'Optional', docs: p.doc ? [{ doc: p.doc, signer: '' }] : [], verifyGroup: '', verifiedBy: '', cosignedBy: '', obs: '', obsClass: '', medicare: '', v76form: '', pack: 'practice', hidden: false, summaryFor: [...p.ask, ...(p.confirm || [])], statement: '' };
}

/* ---------- answers with provenance ---------- */
export type SourceKind = 'portal' | 'booking' | 'records' | 'scribe' | 'staff' | 'default' | 'prior-visit' | 'system' | 'nightingale';
export interface Confirm { station: Station; by: string; at: string }
export interface Answer { value: string; source: SourceKind; sourceLabel: string; by: string; at: string; station?: Station; aiDraft?: boolean; confirms: Confirm[]; history?: Omit<Answer, 'history'>[] }
export type Answers = Record<string, Answer>;
export const SOURCE_LABEL: Record<SourceKind, string> = { portal: 'Patient portal', booking: 'Booking', records: 'Records brief', scribe: 'Ambient scribe (AI draft)', staff: 'Typed by staff', default: 'Center default', 'prior-visit': 'Prior visit', system: 'System', nightingale: 'Nightingale (AI draft)' };
export function setAnswer(a: Answers, qid: string, value: string, src: { source: SourceKind; label?: string; by: string; at: string; station?: Station }): Answers {
  const prev = a[qid]; const ai = src.source === 'scribe' || src.source === 'nightingale';
  const staffEntered = src.source === 'staff' && src.station;
  const next: Answer = { value, source: src.source, sourceLabel: src.label || SOURCE_LABEL[src.source], by: src.by, at: src.at, station: src.station, aiDraft: ai || undefined,
    confirms: staffEntered ? [{ station: src.station!, by: src.by, at: src.at }] : [], history: prev ? [...(prev.history || []), { ...prev, history: undefined } as any] : undefined };
  return { ...a, [qid]: next };
}
/** Fill only when empty (prefill never overwrites a person's answer). */
export function prefill(a: Answers, qid: string, value: string | undefined | null, src: { source: SourceKind; label?: string; by: string; at: string }): Answers {
  if (value == null || value === '' || a[qid]) return a; return setAnswer(a, qid, String(value), src);
}
export function confirmAnswer(a: Answers, qid: string, station: Station, by: string, at: string): Answers {
  const x = a[qid]; if (!x) return a; if (x.confirms.some(c => c.station === station) && !x.aiDraft) return a;
  return { ...a, [qid]: { ...x, aiDraft: undefined, confirms: [...x.confirms.filter(c => c.station !== station), { station, by, at }] } };
}
export const confirmedBy = (x?: Answer) => (x?.confirms || []).map(c => `${c.by} (${stationLabel(c.station)})`).join(', ');

/* ---------- case context + conditional rules ---------- */
export interface CaseCtx { signedDocs?: string[]; age?: number; gender?: string; anesthesia?: string; durationMins?: number; triggered?: { transfer?: boolean; ama?: boolean }; mrn?: string }
const val = (a: Answers, id: string) => (a[id]?.value || '').toLowerCase();
export const isFemale = (c: CaseCtx, a: Answers = {}) => /^f/i.test(c.gender || a['SH-03']?.value || '');
const CLASS_N = { A: 1, B: 2, C: 3 } as const;
export const MH_SCREEN = ['SH-41', 'SH-42', 'SH-43', 'SH-44', 'SH-45'];
/** Any yes (or unsure) on the MH screen flags anesthesia and opens AN-40. */
export function mhPositive(a: Answers): string[] { return MH_SCREEN.filter(id => { const v = val(a, id); return !!v && !/^(no|none|n\/a)\b/.test(v); }); }
export function visible(q: Question, c: CaseCtx, a: Answers, s: CenterSettings): boolean {
  if (q.hidden) return false; if (q.pack === 'medicare' && !s.medicarePack) return false;
  const r = q.rule; if (!r) return true;
  switch (r.k) {
    case 'minor': return (c.age ?? 99) < 18 || /lacks capacity|guardian/i.test(val(a, 'SH-09'));
    case 'female': return isFemale(c, a);
    case 'upt': return isFemale(c, a) && (c.age ?? 99) < s.uptMaxAge;
    case 'has': return new RegExp(r.re, 'i').test(val(a, r.q));
    case 'allergy': { const v = val(a, 'SH-15'); return !!v && !/^nkda$|^none$/.test(v.trim()); }
    case 'notHome': { const v = val(a, 'SH-34'); return !!v && !/^home/.test(v); }
    case 'vte': return /general/i.test(c.anesthesia || '') || (c.durationMins ?? 0) >= 60;
    case 'notLocal': return !/^(local|topical)/i.test(c.anesthesia || '');
    case 'setting': return !!s[r.s];
    case 'mhPositive': return s.mhTriggers && mhPositive(a).length > 0;
    case 'classMin': return CLASS_N[s.anesClass] >= CLASS_N[r.c];
    case 'facilityHP': return /facility/i.test(val(a, 'SX-05')) || !a['SX-05'];
    case 'triggered': return !!c.triggered?.[r.x];
    default: return true;
  }
}
export function isRequired(q: Question, c: CaseCtx, a: Answers, s: CenterSettings): boolean {
  if (!visible(q, c, a, s)) return false;
  if (q.required === 'always') return true; if (q.required === 'ifShown') return true;
  if (q.required === 'classC') return s.anesClass === 'C' && (q.id !== 'SH-37' || !/^(local|topical)/i.test(c.anesthesia || ''));
  return false;
}
export function bmi(hs?: string, ws?: string): string | null {
  const h = parseFloat(hs || ''), w = parseFloat(ws || ''); if (!h || !w) return null;
  const m = /cm/i.test(hs!) || h > 100 ? h / 100 : /m\b/i.test(hs!) && h < 3 ? h : h * 0.0254; const kg = /kg/i.test(ws!) ? w : w * 0.4536;
  return (kg / (m * m)).toFixed(1);
}
/** Value the engine computes itself (never typed): MRN, BMI, NPO compliance suggestion. */
export function computed(q: Question, c: CaseCtx, a: Answers): string | null {
  if (q.id === 'SH-04') return c.mrn || null;
  if (q.id === 'SH-14') return bmi(a['SH-12']?.value, a['SH-13']?.value);
  const has = (id: string) => !!a[id]?.value; const sd = c.signedDocs || [];
  if (q.id === 'RN-04') return a['FD-09']?.value ? `${a['FD-09'].value.replace(/ · .*/, '')} · Pre-op` : null;
  if (q.id === 'RN-06') return [['H&P', 'SX-05'], ['Labs', 'SX-06'], ['ECG', 'SX-07'], ['Clearance', 'SX-08']].map(([l, id]) => `${l} ${has(id) ? '✓' : '—'}`).join(' · ') + (/OLDER/.test(a['SX-05']?.value || '') ? ' · H&P older than the center limit' : '');
  if (q.id === 'RN-07') return has('SX-13') ? `Done (${a['SX-13'].by})` : 'Pending — surgeon pre-op assessment';
  if (q.id === 'RN-08') { const p = sd.includes('Procedure Consent'), an = sd.includes('Anesthesia Consent'); return p && an ? 'Both consents signed' : `Pending: ${[!p && 'procedure consent', !an && 'anesthesia consent'].filter(Boolean).join(', ')}`; }
  if (q.id === 'SX-28') return [a['OR-14']?.value && `Times ${a['OR-14'].value}`, a['AN-17']?.value, a['AN-15']?.value && `ASA ${a['AN-15'].value}`].filter(Boolean).join(' · ') || 'Pending — OR and anesthesia events';
  if (q.id === 'FD-09') return a['FD-09']?.value || 'Not checked in yet';
  if (q.id === 'PA-19' || q.id === 'PA-20') return a[q.id]?.value || 'Scheduled at discharge (simulated)';
  return null;
}
export function defaultFor(q: Question, s: CenterSettings): string | null {
  if (q.id === 'PA-25') return s.orRecovery ? 'Yes' : 'No';
  return q.default;
}

/* ---------- a station's screen ---------- */
export type ItemStatus = 'done' | 'known' | 'draft' | 'default' | 'missing' | 'empty' | 'auto' | 'sign';
export interface StationItem { q: Question; mode: 'ask' | 'confirm'; answer?: Answer; value: string; status: ItemStatus; required: boolean }
export function stationItems(bank: Question[], st: Station, c: CaseCtx, a: Answers, s: CenterSettings): StationItem[] {
  const out: StationItem[] = [];
  for (const q of bank) {
    const mode = q.ask.includes(st) ? 'ask' : q.confirm.includes(st) ? 'confirm' : null; if (!mode) continue;
    if (!visible(q, c, a, s)) continue;
    if (mode === 'confirm' && !relevantTo(q, st)) continue; // v7.9: role relevance — irrelevant known info is not shown
    const req = isRequired(q, c, a, s); const ans = a[q.id]; const comp = computed(q, c, a); const dflt = defaultFor(q, s);
    let status: ItemStatus; let value = ans?.value ?? '';
    if (q.kind === 'sign') status = 'sign';
    else if (q.kind === 'auto' || comp != null) { status = 'auto'; value = comp ?? ans?.value ?? ''; }
    else if (!ans) { if (dflt) { status = 'default'; value = dflt; } else status = req ? 'missing' : 'empty'; }
    else if (ans.aiDraft) status = 'draft';
    else if (ans.confirms.some(x => x.station === st)) status = 'done';
    else status = 'known';
    out.push({ q, mode, answer: ans, value, status, required: req });
  }
  return out;
}
export const relevantTo = (q: Question, st: Station) => !q.summaryFor || q.summaryFor.includes(st) || q.ask.includes(st);
/* v7.9: role-relevant AI summary — known, relevant answers condensed into (at most) 3 cards per station. */
export type CardKind = 'clinical' | 'allergy' | 'records' | 'logistics';
const CARD_OF: Record<string, CardKind> = { 'Allergies': 'allergy', 'Medications': 'allergy', 'H&P, records & clearance review': 'records', 'Chart readiness (confirm only)': 'records', 'NPO & medications': 'records', 'Vitals & IV': 'records', 'Review of tests & risk': 'records', 'Consent & site marking': 'records', 'Anesthesia plan & consent': 'records', 'Pregnancy': 'records',
  'Past medical history': 'clinical', 'Pre-anesthesia history (patient-reported)': 'clinical', 'Malignant hyperthermia risk screen': 'clinical', 'Body measures': 'clinical', 'Exam & airway': 'clinical', 'Past surgical & anesthesia history': 'clinical', "Women's health & VTE risk": 'clinical' };
export const CARD_TITLE: Record<Station, Record<CardKind, string>> = Object.fromEntries((['FD', 'RN', 'AN', 'SX', 'OR', 'PA', 'DC'] as Station[]).map(st => [st, { clinical: st === 'AN' ? 'Cardiopulmonary & history' : 'Medical history', allergy: 'Allergies & medications', records: st === 'AN' ? 'Labs, records & NPO' : st === 'FD' ? 'Records & consents' : 'Records, consents & NPO', logistics: st === 'FD' ? 'Registration & contact' : 'Case & logistics' }])) as any;
export const shortLabel = (t: string) => { const x = t.split(/[(:,;?]| — /)[0].trim(); return x.length > 38 ? x.slice(0, 36) + '…' : x; };
export const isAllergyAlert = (a: Answers) => { const v = (a['SH-15']?.value || '') + ' ' + (a['SH-16']?.value || ''); return !!v.trim() && !/^\s*(nkda|no known|none|no)\b/i.test(v); };
export interface SummaryCard { kind: CardKind; title: string; items: StationItem[]; alert: boolean }
export function summaryCards(st: Station, items: StationItem[], a: Answers, max = 3): { cards: SummaryCard[]; more: StationItem[] } {
  const known = items.filter(i => i.mode === 'confirm' && i.value && ['known', 'done', 'auto', 'default'].includes(i.status));
  const by: Record<CardKind, StationItem[]> = { clinical: [], allergy: [], records: [], logistics: [] };
  known.forEach(i => by[CARD_OF[i.q.group] || 'logistics'].push(i));
  const order: CardKind[] = st === 'FD' || st === 'DC' ? ['logistics', 'allergy', 'records', 'clinical'] : ['clinical', 'allergy', 'records', 'logistics'];
  const cards = order.filter(k => by[k].length).map(k => ({ kind: k, title: CARD_TITLE[st][k], items: by[k], alert: k === 'allergy' && isAllergyAlert(a) }));
  return { cards: cards.slice(0, max), more: cards.slice(max).flatMap(c => c.items) };
}
export interface ComplianceAttest { value: string; by: string; role: string; at: string; reviewDays?: number; note?: string }
export function complianceStatus(q: Question, x: ComplianceAttest | undefined, today = new Date()): { state: 'never' | 'current' | 'due-soon' | 'overdue'; due?: string } {
  if (!x) return { state: 'never' }; const d = new Date(x.at); d.setDate(d.getDate() + (x.reviewDays ?? q.reviewDays ?? 365)); const due = d.toISOString().slice(0, 10);
  const left = (d.getTime() - today.getTime()) / 864e5; return { state: left < 0 ? 'overdue' : left < 30 ? 'due-soon' : 'current', due };
}
export const groupItems = (items: StationItem[]) => items.reduce<[string, StationItem[]][]>((g, it) => { const l = g.find(x => x[0] === it.q.group); if (l) l[1].push(it); else g.push([it.q.group, [it]]); return g; }, []);
export function stationProgress(items: StationItem[]) {
  const req = items.filter(i => i.required && i.status !== 'sign' && i.status !== 'auto');
  const done = req.filter(i => i.status === 'done').length;
  return { required: req.length, done, missing: req.filter(i => i.status === 'missing').length, toConfirm: req.filter(i => ['known', 'default', 'draft'].includes(i.status)).length, drafts: items.filter(i => i.status === 'draft').length };
}
/** One tap: confirm every known / default answer on this station (AI drafts are left for individual review). */
export function confirmAllKnown(a: Answers, items: StationItem[], st: Station, by: string, at: string): Answers {
  let n = a;
  for (const i of items) {
    if (i.status === 'known') n = confirmAnswer(n, i.q.id, st, by, at);
    else if (i.status === 'default') { n = setAnswer(n, i.q.id, i.value, { source: 'default', by, at }); n = confirmAnswer(n, i.q.id, st, by, at); }
  }
  return n;
}

/* ---------- verification / co-sign matrix (per verification group; per-center setting) ---------- */
export interface VerifyRow { group: string; verifiedBy: string; cosignedBy: string; questions: string[] }
export function verifyMatrix(bank: Question[]): VerifyRow[] {
  const m = new Map<string, VerifyRow>();
  for (const q of bank) if (q.verifyGroup) { const r = m.get(q.verifyGroup) || { group: q.verifyGroup, verifiedBy: q.verifiedBy, cosignedBy: q.cosignedBy, questions: [] }; r.questions.push(q.id); m.set(q.verifyGroup, r); }
  return [...m.values()];
}

/* ---------- ambient scribe (simulated): one conversation → drafts for this and other stations ---------- */
const SCRIBE: [RegExp, string, (m: RegExpMatchArray) => string][] = [
  [/\bBP (\d{2,3}\/\d{2,3}),? heart rate (\d+),? (?:RR (\d+),? )?SpO2 (\d+)/i, 'RN-24', m => `BP ${m[1]}, HR ${m[2]}${m[3] ? `, RR ${m[3]}` : ''}, SpO2 ${m[4]}%`],
  [/(?:toast|ate|food)[^.]*?at (\d{1,2}(?::\d\d)?\s*(?:am|pm)?|\d{1,2} last night)/i, 'RN-10', m => `Last solids ${m[1]}`],
  [/sip of water at (\d{1,2}(?::\d\d)?)\s*(?:this morning|am)?/i, 'RN-11', m => `Clear liquid ${m[1]} AM`],
  [/my (sister|brother|wife|husband|son|daughter|friend|partner) (\w+)[^.]*?(?:stay|home)/i, 'SH-36', m => `${m[2]} (${m[1]})`],
  [/(?:stay with me|stays? with (?:me|her|him))[^.]*?(tonight|24 hours|overnight)/i, 'SH-37', () => 'Yes'],
  [/sick to my stomach|nausea after anesthesia|threw up after/i, 'AN-04', () => 'Yes'],
  [/Mallampati (I{1,3}V?|IV)\b/i, 'AN-10', m => m[1].toUpperCase()],
  [/(good mouth opening[^.]*neck movement)/i, 'AN-11', m => m[1]],
  [/Lungs clear to auscultation, regular rhythm/i, 'AN-13', () => 'Normal (heart, lungs)'],
  [/ASA (\d|I{1,3}V?)\b/i, 'AN-15', m => ({ '1': 'I', '2': 'II', '3': 'III', '4': 'IV' } as any)[m[1]] || m[1].toUpperCase()],
  [/plan (general anesthesia|MAC|monitored anesthesia care|TIVA)[^.]*/i, 'AN-17', m => /general/i.test(m[1]) ? 'General LMA' : m[1]],
  [/(PONV prophylaxis)/i, 'AN-18', () => 'Standard ASA monitoring; PONV prophylaxis (prior PONV)'],
  [/mark the site[^.]*?(left|right) (\w+)/i, 'SX-23', () => 'Marked'],
  [/reviewed the risks, benefits and alternatives/i, 'SX-19', () => 'Yes'],
  [/(bridge|dentures?|partial) (?:removed|out)/i, 'RN-19', m => `${m[1][0].toUpperCase()}${m[1].slice(1)} removed`],
  [/(left|right) (knee|hip) (?:implant|replacement)/i, 'RN-22', m => `${m[1]} ${m[2]} implant`],
  [/(\d{2}) gauge (?:IV )?(?:in the )?(left|right) (hand|forearm|antecubital)/i, 'RN-26', m => `${m[1]}g ${m[2]} ${m[3]}`],
  [/no change since (?:the )?H&P/i, 'SX-14', () => 'No change since H&P'],
];
export interface ScribeDraft { qid: string; value: string; station: Station; line: string }
export function scribeExtract(text: string, bank: Question[]): ScribeDraft[] {
  const out: ScribeDraft[] = [];
  for (const line of text.split(/\n+/).map(s => s.trim()).filter(Boolean)) for (const [re, qid, f] of SCRIBE) { const m = line.match(re); if (!m || out.some(o => o.qid === qid)) continue; const q = bank.find(x => x.id === qid); if (!q) continue; out.push({ qid, value: f(m), station: (q.ask.find(s => s !== 'PT') || q.confirm[0]) as Station, line }); }
  return out;
}
export function applyScribe(a: Answers, drafts: ScribeDraft[], by: string, at: string): Answers {
  let n = a; for (const d of drafts) { const x = n[d.qid]; if (x && !x.aiDraft && x.confirms.length) continue; n = setAnswer(n, d.qid, d.value, { source: 'scribe', label: 'Ambient scribe (AI draft)', by, at }); } return n;
}

/* ---------- documents: generated from answers ---------- */
export interface DocMeta { signers: Station[]; patient?: boolean; cosigners?: Station[]; note?: string; attestation?: string }
export const DOC_META: Record<string, DocMeta> = {
  'Registration': { signers: ['FD'] }, 'Admission Packet': { signers: ['FD'], patient: true }, 'Insurance & Fees': { signers: ['FD'], patient: true },
  'Medical History': { signers: ['RN'], cosigners: ['SX', 'AN'], note: 'Co-signed by the surgeon (day-of H&P update) and anesthesia (pre-induction re-evaluation)' },
  'Nursing Admission': { signers: ['RN'] }, 'MH & VTE': { signers: ['AN'], cosigners: ['SX'], note: 'Anesthesia reviews the screen; the surgeon signs the prophylaxis decision' },
  'Anesthesia Questionnaire': { signers: ['RN'] }, 'Anesthesia Evaluation': { signers: ['AN'] }, 'Anesthesia Consent': { signers: ['AN'], patient: true }, 'Anesthesia Orders': { signers: ['AN'] }, 'Anesthesia Record': { signers: ['AN'] },
  'H&P / Clearance': { signers: ['SX'] }, 'Interval H&P': { signers: ['SX'] }, 'Immediate Pre-Anesthesia Note': { signers: ['AN'], note: 'Written immediately prior to induction (QUAD A OBS anesthesia re-evaluation)', attestation: 'This note documents the anesthesia re-evaluation performed immediately prior to induction.' }, 'Surgeon Pre-Op': { signers: ['SX'] }, 'Procedure Consent': { signers: ['SX'], patient: true }, 'Photography Consent': { signers: ['SX'], patient: true }, 'Surgeon Orders': { signers: ['SX'] },
  'Universal Protocol': { signers: ['OR'] }, 'Intra-Op Nursing': { signers: ['OR'] }, 'Operative Log': { signers: ['OR'] }, 'Specimen Log': { signers: ['OR'] },
  'Op Report': { signers: ['SX'], note: 'Dictated on the phone after PACU (v7.7 flow); filed here when signed' },
  'PACU Record': { signers: ['PA'] }, 'Discharge Order': { signers: ['SX'] }, 'Discharge Instructions': { signers: ['DC'] }, 'Discharge Sign-off': { signers: ['DC'], patient: true },
  'Transfer Form': { signers: ['RN'] }, 'AMA / Refusal Form': { signers: ['RN'], patient: true },
  'Booking record': { signers: [] }, 'Survey': { signers: [] }, 'Follow-up log': { signers: [] },
};
export interface DocLayout { id: string; name: string; groups: [string, string[]][]; signers: Station[]; cosigners: Station[]; patient: boolean; note?: string; attestation?: string; template?: string }
export const docId = (name: string) => name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
export function layouts(bank: Question[]): DocLayout[] {
  const m = new Map<string, DocLayout>();
  for (const q of bank) for (const d of q.docs) {
    const meta = { ...(DOC_META[d.doc] || { signers: [] }), ...(DOC_EDITS[d.doc] || {}) } as DocMeta; const l = m.get(d.doc) || { id: docId(d.doc), name: d.doc, groups: [], signers: meta.signers, cosigners: meta.cosigners || [], patient: !!meta.patient, note: meta.note, attestation: meta.attestation, template: (DOC_EDITS[d.doc]?.template ?? DOC_TEMPLATE[d.doc]) || undefined };
    const g = l.groups.find(x => x[0] === q.group); if (g) g[1].push(q.id); else l.groups.push([q.group, [q.id]]); m.set(d.doc, l);
  }
  return [...m.values()];
}
export function caseDocs(bank: Question[], c: CaseCtx, a: Answers, s: CenterSettings): DocLayout[] {
  const byId = new Map(bank.map(q => [q.id, q]));
  return layouts(bank).map(l => ({ ...l, groups: l.groups.map(([g, ids]) => [g, ids.filter(id => { const q = byId.get(id)!; return visible(q, c, a, s); })] as [string, string[]]).filter(([, ids]) => ids.length) })).filter(l => l.groups.length);
}
export interface Header { name: string; dob?: string; age?: number; gender?: string; mrn?: string; procedure: string; surgeon: string; dateOfService: string; center: string }
export interface Rendered { text: string; values: Record<string, string>; pending: string[]; drafts: string[] }
const fmtSrc = (x?: Answer) => !x ? '' : `${x.sourceLabel}${x.aiDraft ? ' · AI draft, unconfirmed' : ''}${x.confirms.length ? ` · confirmed by ${confirmedBy(x)}` : ''}`;
/** Canonical full document text: this exact text is shown at signing, hashed and locked. */
export function renderDoc(l: DocLayout, bank: Question[], h: Header, c: CaseCtx, a: Answers, s: CenterSettings): Rendered {
  const byId = new Map(bank.map(q => [q.id, q])); const values: Record<string, string> = {}; const pending: string[] = []; const drafts: string[] = [];
  const tpl = l.template ? TEMPLATES[l.template] : undefined;
  const lines = [`${h.center}`, `${l.name.toUpperCase()}`, ...(tpl ? [`${tpl.title} — center template layout (${tpl.file}); answers from the question bank`] : []), `Patient: ${h.name}${h.dob ? ` · DOB ${h.dob}` : ''}${h.age != null ? ` · ${h.age} y` : ''}${h.gender ? ` · ${h.gender}` : ''}${h.mrn ? ` · MRN ${h.mrn}` : ''}`, `Date of service: ${h.dateOfService} · Procedure: ${h.procedure} · Surgeon: ${h.surgeon}`, `Accreditation: ${s.accreditor} ${s.program}${s.medicarePack ? ' + Medicare ASC pack' : ''} · Anesthesia class ${s.anesClass}`, ''];
  // v7.9: template layout — template section order and fixed wording; each answer placed at its source field
  let sections: [string, string[], string[]][] = l.groups.map(([g, ids]) => [g, ids, []]);
  if (tpl) {
    const place = new Map<number, { id: string; k: number }[]>(); const extra: string[] = [];
    for (const id of l.groups.flatMap(([, ids]) => ids)) { const sx = byId.get(id)?.src?.find(x => x.file === l.template && x.section != null); if (sx) { if (!place.has(sx.section!)) place.set(sx.section!, []); place.get(sx.section!)!.push({ id, k: sx.fieldIdx }); } else extra.push(id); }
    const idx = [...place.keys()]; const lo = Math.min(...idx), hi = Math.max(...idx); const all = l.patient || !idx.length;
    sections = tpl.sections.map((sec, i) => [sec.h === '(header)' ? 'Case information' : sec.h, (place.get(i) || []).sort((a, b) => a.k - b.k).map(x => x.id), (all || (i >= lo && i <= hi)) && sec.h !== '(header)' ? sec.text : []] as [string, string[], string[]]).filter(([, ids, tx]) => ids.length || tx.length);
    if (extra.length) sections.push(['Additional items (question bank)', extra, []]);
  }
  for (const [g, ids, wording] of sections) {
    lines.push(`— ${g} —`); for (const w of wording) lines.push(w);
    for (const id of ids) {
      const q = byId.get(id)!; if (q.kind === 'sign') continue;
      const v = computed(q, c, a) ?? a[id]?.value ?? ''; values[id] = v;
      if (!v && isRequired(q, c, a, s)) pending.push(id); if (a[id]?.aiDraft) drafts.push(id);
      lines.push(`${q.text}: ${v || '—'}${a[id] ? `   [${fmtSrc(a[id])}]` : ''}`);
      if (q.statement) lines.push(`   Statement: "${q.statement}"`);
    }
    lines.push('');
  }
  if (l.attestation) lines.push(`Attestation: ${l.attestation}`);
  lines.push(`Signers: ${[...(l.patient ? ['Patient / representative'] : []), ...l.signers.map(stationLabel), ...l.cosigners.map(x => `${stationLabel(x)} (co-sign)`)].join(', ') || 'none (record only)'}`);
  return { text: lines.join('\n'), values, pending, drafts };
}
export interface Sig { role: string; station?: Station | 'PT'; by: string; at: string; hash: string }
export interface Addendum { at: string; by: string; role: string; text: string; hash: string; prevHash: string; values?: Record<string, string> }
export interface SignedVersion { docId: string; name: string; version: number; content: string; values: Record<string, string>; hash: string; lockedAt: string; signatures: Sig[]; addenda: Addendum[] }
export function signBlockers(r: Rendered, l: DocLayout, st: Station | 'PT', bank: Question[] = BASE): string[] {
  const b: string[] = []; const where = (id: string) => { const q = bank.find(x => x.id === id); return q ? `${id} (${q.ask.filter(x => x !== 'PT').map(stationLabel).join('/') || 'Patient portal'})` : id; };
  if (st !== 'PT' && ![...l.signers, ...l.cosigners].includes(st as Station)) b.push(`${stationLabel(st)} is not a signer of this document`);
  if (r.pending.length) b.push(`${r.pending.length} required answer(s) missing: ${r.pending.map(where).join(', ')}`);
  if (r.drafts.length) b.push(`${r.drafts.length} AI draft(s) not confirmed yet: ${r.drafts.join(', ')}`);
  return b;
}
/** First signature locks the exact rendered version (hash of its content). Later signers co-sign that same locked version. */
export function sign(versions: SignedVersion[], l: DocLayout, r: Rendered, who: { role: string; station: Station | 'PT'; by: string; at: string }): SignedVersion[] {
  const cur = versions.filter(v => v.docId === l.id).sort((a, b) => b.version - a.version)[0];
  if (cur && cur.content === r.text) { if (cur.signatures.some(s => s.station === who.station)) return versions; return versions.map(v => v === cur ? { ...v, signatures: [...v.signatures, { ...who, hash: v.hash }] } : v); }
  if (cur) throw new Error('locked: corrections after signing are addenda');
  const hash = sha256(r.text);
  return [...versions, { docId: l.id, name: l.name, version: 1, content: r.text, values: r.values, hash, lockedAt: who.at, signatures: [{ ...who, hash }], addenda: [] }];
}
export const verifyVersion = (v: SignedVersion) => sha256(v.content) === v.hash && v.addenda.every((ad, i) => ad.prevHash === (i ? v.addenda[i - 1].hash : v.hash) && ad.hash === sha256(ad.prevHash + '\n' + ad.at + '\n' + ad.by + '\n' + ad.text));
export function addAddendum(versions: SignedVersion[], id: string, text: string, by: string, role: string, at: string, values?: Record<string, string>): SignedVersion[] {
  return versions.map(v => { if (v.docId !== id) return v; const prevHash = v.addenda.length ? v.addenda[v.addenda.length - 1].hash : v.hash; return { ...v, addenda: [...v.addenda, { at, by, role, text, prevHash, hash: sha256(prevHash + '\n' + at + '\n' + by + '\n' + text), values }] }; });
}
/** Answers that changed after the document was locked → Nightingale drafts the addendum text for the signer to review. */
export function changedSince(v: SignedVersion, r: Rendered, bank: Question[]): { qid: string; was: string; now: string; text: string }[] {
  const base = [...v.addenda].reverse().find(a => a.values)?.values || v.values; // an addendum documents the values as of its time
  return Object.keys(r.values).filter(k => (base[k] ?? '') !== (r.values[k] ?? '')).map(k => ({ qid: k, was: base[k] ?? '', now: r.values[k] ?? '', text: bank.find(q => q.id === k)?.text || k }));
}
export const draftAddendum = (ch: ReturnType<typeof changedSince>) => ch.map(c => `Correction: ${c.text.split(/[:(]/)[0].trim()} was "${c.was || '—'}", now "${c.now || '—'}".`).join('\n');
export const docStatus = (versions: SignedVersion[], l: DocLayout) => { const v = versions.find(x => x.docId === l.id); const need = [...l.signers, ...l.cosigners, ...(l.patient ? ['PT' as const] : [])]; const got = new Set(v?.signatures.map(s => s.station)); return { v, signed: !!v, complete: !!v && need.every(n => got.has(n as any)), waiting: need.filter(n => !got.has(n as any)) }; };

/* ---------- episodes: a patient is an identity + dates of service ---------- */
export const patientKey = (p: { name: string; dob?: string }) => `${p.name.trim().toLowerCase()}|${(p.dob || '').trim()}`;
export const CARRY_FORWARD = ['SH-01', 'SH-02', 'SH-03', 'SH-05', 'SH-06', 'SH-07', 'SH-08', 'SH-10', 'SH-11', 'SH-15', 'SH-16'];
/** Repeat visit: only demographics and allergies are offered (unconfirmed, never assumed). */
export function carryForward(a: Answers, prior: Answers, priorDate: string, at: string): Answers {
  let n = a; for (const id of CARRY_FORWARD) if (prior[id]?.value && !n[id]) n = setAnswer(n, id, prior[id].value, { source: 'prior-visit', label: `Prior visit ${priorDate} (offered to confirm)`, by: 'System', at }); return n;
}

/* ---------- readiness + to-dos for a station ---------- */
export function stationTodos(st: Station, items: StationItem[], docs: DocLayout[], versions: SignedVersion[], a: Answers, s: CenterSettings, extra: { checkedIn: boolean }): string[] {
  const t: string[] = []; const p = stationProgress(items);
  if (st !== 'FD' && !extra.checkedIn) t.push('Waiting for front-desk check-in (the one gate)');
  if (st === 'FD' && !extra.checkedIn) t.push('Check in and hand the patient to Pre-op nursing');
  if (p.missing) t.push(`${p.missing} required answer${p.missing > 1 ? 's' : ''} missing`);
  if (p.toConfirm) t.push(`${p.toConfirm} known answer${p.toConfirm > 1 ? 's' : ''} to confirm`);
  if (p.drafts) t.push(`${p.drafts} AI draft${p.drafts > 1 ? 's' : ''} to review`);
  if (st === 'AN' && s.mhTriggers && mhPositive(a).length && !a['AN-40']?.value) t.push('MH screen positive: complete the MH precautions plan (AN-40)');
  for (const l of docs) { const ds = docStatus(versions, l); if ([...l.signers, ...l.cosigners].includes(st) && !ds.v?.signatures.some(x => x.station === st)) t.push(`Sign ${l.name}`); }
  return t;
}
