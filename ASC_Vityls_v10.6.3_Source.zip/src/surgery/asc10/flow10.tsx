/* ASC.Vityls v10 · frozen workflow pieces (Kevin, Oct 2026):
 *  Front desk documents (presence only) · Verify medical history (brief step, nurse confirms once with PIN, official for every
 *  later station, viewable by all, amendable by licensed clinicians with a reason) · surgeon standing pre-op/post-op checklists
 *  (tick with time + initials; one-off orders in the same list) · Brief OP report (circulating RN writes, surgeon PIN-signs) ·
 *  Capture/Upload on every station. Never holds a case: missing items are tinted warnings only. Nightingale drafts only. */
import { DictateMic, parseBriefOp } from './native103';
import React, { useMemo, useState } from 'react';
import { Camera, Upload, FileText, Check, AlertTriangle, Pencil, ShieldCheck, ClipboardList, Plus } from 'lucide-react';
import { medRepo, PROVIDER_ROLES } from '../../med/record';
import { repo } from '../../v6/dataLayer';
import { useActor, useMedTick } from '../../med/ui';
import { PinSign } from '../sign';
import { surgicalHistory } from '../store';
import * as A from '../asc8/logic';
import * as S from '../asc8/store';
import { s81, use81 } from '../asc81/store81';
import { uploads } from '../asc87/store87';
import { openUpload } from '../asc87/ui87';
import { parseAllergyList } from '../../v7/allergy';
import * as D from './store10';
import { draftHistory, frontDocs, DOC_TYPE_FOR } from './pure10';
import { AllergyCard } from './kit';
import { ClearanceDocsCard } from '../asc106/clearance106';

export const CLINICIAN_ROLES = [...S.NURSE_ROLES, ...S.ANES_ROLES, ...PROVIDER_ROLES, 'Medical Director'];
const tm = (iso?: string) => iso ? new Date(iso).toLocaleString('en-US', { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' }) : '';

/* ---------------- Capture / Upload (every station) ---------------- */
export const CaptureUpload: React.FC<{ c: A.AscCase; compact?: boolean; station?: string }> = ({ c, compact, station }) =>
  <button type="button" className="a8-btn" onClick={() => openUpload(c.id, c.pid, station)} data-testid="v10-capture" title="Capture a paper document with the camera or upload a file">
    <Camera size={16} aria-hidden="true" style={{ display: 'inline', marginRight: 6, verticalAlign: '-3px' }} />{compact ? 'Capture' : 'Capture / Upload'}</button>;

/* ---------------- Front desk: forms + clearance documents present? (no clinical verification) ---------------- */
export function frontDocState(c: A.AscCase) {
  const ups = uploads(c.id).map(u => u.type); const ck: Record<string, boolean> = (s81.ai(c.id).checklist || {}) as any; const v10: Record<string, boolean> = (s81.ai(c.id) as any).v10docs || {};
  const formDone = (f: string) => { const r: any = repo.getForm(c.visitId, f); return r && (r.status === 'completed' || r.status === 'signed' || Object.keys(r.values || {}).length > 0); };
  const have: Record<string, boolean> = {
    portal: !!v10.portal || !!ck.portal || formDone('Medical_History.html') || !!c.d.forms, athome: !!v10.athome || formDone('Anesthesia_Questionnaire.html'), intake: !!v10.intake || !!v10.athome || formDone('Anesthesia_Questionnaire.html') || formDone('Patient_Registration.html') || formDone('ASC_Registration_Insurance.html'),
    hp: !!v10.hp || !!ck.hp || ups.includes('Pre-op H&P') || ups.includes('H&P + clearance') || !!c.d.clearance, labs: !!v10.labs || !!ck.labs || ups.includes('Lab results') || !!c.d.labs, ecg: !!v10.ecg || !!ck.ecg || ups.includes('ECG') };
  return frontDocs(have);
}
export const FrontDeskDocs: React.FC<{ c: A.AscCase }> = ({ c }) => {
  useMedTick(); const s = use81(); const [actor] = useActor(); const docs = frontDocState(c); const miss = docs.filter(d => !d.present);
  const mark = (id: string) => { s.setAi(c.id, a => ({ ...a, v10docs: { ...((a as any).v10docs || {}), [id]: true } } as any)); repo.audit({ caseId: `asc8:${c.id}`, user: actor.name, role: actor.role, action: 'asc10.frontdocs' as any, detail: `Front desk: ${docs.find(d => d.id === id)?.label} received` }); };
  return <section className="v10-card" data-testid="v10-frontdocs"><h3 className="v10-h"><ClipboardList size={18} aria-hidden="true" />Forms &amp; clearance documents
    <span className={`v10-chip ${miss.length ? 'warn' : 'ok'}`} style={{ marginLeft: 'auto' }} data-testid="v10-frontdocs-count">{docs.length - miss.length} of {docs.length} on file</span></h3>
    <p className="v10-sub">Front desk checks that these are here and collects anything missing. Clinical review happens at Verify medical history.</p>
    <div className="v10-grid" style={{ marginTop: 10 }}>{docs.map(d => <div key={d.id} className={`v10-li ${d.present ? 'done' : 'miss'}`} data-testid={`v10-doc-${d.id}`} data-present={d.present ? '1' : '0'}>
      {d.present ? <Check size={16} aria-hidden="true" /> : <AlertTriangle size={16} aria-hidden="true" />}<span style={{ flex: 1 }}>{d.label}</span>
      </div>)}</div>
    {miss.length > 0 && <p className="v10-sub" style={{ marginTop: 8 }} data-testid="v10-frontdocs-warn">Missing items never hold the case: they stay as warnings until they arrive.</p>}</section>;
};

/* ---------------- Verify medical history ---------------- */
function buildDraft(c: A.AscCase) {
  const p = medRepo.patient(c.pid)!; const meds = (medRepo as any).meds(p.id).filter((m: any) => m.status === 'active'); const probs = (medRepo as any).problems(p.id).filter((x: any) => x.status === 'active');
  const fv = { ...(repo.getForm(c.visitId, 'Medical_History.html').values || {}), ...(repo.getForm(c.visitId, 'Anesthesia_Questionnaire.html').values || {}) };
  return draftHistory({ allergies: p.allergies || [], meds, problems: probs.map((x: any) => x.description), surgical: surgicalHistory(p.id), intake: medRepo.intake(p.id), formValues: fv });
}
const SourceLinks: React.FC<{ c: A.AscCase }> = ({ c }) => {
  const ups = uploads(c.id); const forms = ['Medical_History.html', 'Anesthesia_Questionnaire.html', 'Patient_Registration.html'].filter(f => Object.keys(repo.getForm(c.visitId, f).values || {}).length);
  const open = (u: { data?: string; name: string }) => { if (!u.data) return; const w = window.open(); if (w) w.document.write(`<title>${u.name}</title><iframe src="${u.data}" style="border:0;width:100%;height:100%"></iframe>`); };
  return <div data-testid="v10-hx-sources"><b className="sv-small">Original documents &amp; forms</b>
    {!ups.length && !forms.length && <p className="v10-sub" data-testid="v10-hx-nosources">No H&amp;P, labs or forms on file yet. Use Capture / Upload at the top right to add them.</p>}
    <ul style={{ margin: '6px 0 0', paddingLeft: 0, listStyle: 'none' }}>{ups.map(u => <li key={u.id}><button type="button" className="sv-link sv-small" onClick={() => open(u)} data-testid="v10-hx-src"><FileText size={14} style={{ display: 'inline', verticalAlign: '-2px' }} /> {u.type} · {u.name}</button></li>)}
      {forms.map(f => <li key={f} className="sv-small"><FileText size={14} style={{ display: 'inline', verticalAlign: '-2px' }} /> {f.replace(/_/g, ' ').replace('.html', '')} (patient answers)</li>)}</ul></div>;
};
export const VerifyHistory: React.FC<{ c: A.AscCase; onClose: (m?: string) => void }> = ({ c, onClose }) => {
  useMedTick(); const [actor] = useActor(); const rec = D.historyOf(c.id); const draft = useMemo(() => buildDraft(c), [c.id]);
  const init: D.HistoryFields = rec ? { allergies: rec.allergies, meds: rec.meds, conditions: rec.conditions, surgical: rec.surgical, anesthesia: rec.anesthesia, notes: rec.notes } : { allergies: draft.allergies, meds: draft.meds, conditions: draft.conditions, surgical: draft.surgical, anesthesia: draft.anesthesia, notes: draft.notes };
  const [f, setF] = useState<D.HistoryFields>(init); const [editing, setEditing] = useState(!rec?.confirmed); const [sign, setSign] = useState(false); const [reason, setReason] = useState('');
  const amend = !!rec?.confirmed; const changed = JSON.stringify(f) !== JSON.stringify(init);
  const confirm = (by: string, role: string) => {
    const at = new Date().toISOString(); const st = { by, role, at };
    const next: D.HistoryRec = amend ? { ...rec!, ...f, amendments: [...rec!.amendments, { ...st, reason: reason.trim(), before: init }] } : { ...f, confirmed: st, amendments: [], draftedBy: 'Nightingale' };
    D.saveHistory(c.id, next, by, role, amend ? `Medical history amended: ${reason.trim()}` : 'Medical history verified and confirmed (no signature required)');
    const p = medRepo.patient(c.pid)!; const list = /^\s*(nkda|nka|none|no known)/i.test(f.allergies) ? ['NKDA'] : parseAllergyList(f.allergies);
    medRepo.savePatient({ ...p, allergies: list, allergiesConfirmedAt: at, allergiesConfirmedBy: by }); let x = S.caseById(c.id)!; x = S.setValue(x, 'allergy', { by, at }, by, role, 'Allergies confirmed in Verify medical history');
    S.setValue(x, 'historyVerified', { by, at }, by, role, amend ? 'Official history amended' : 'Official medical history confirmed');
    setSign(false); setEditing(false); setReason(''); if (!amend) onClose(`Medical history confirmed by ${by}. It is now the official history for every station.`);
  };
  const F = (k: keyof D.HistoryFields) => <label key={k} className="block mt-2"><span className="sv-label">{D.HISTORY_LABEL[k]}</span>
    <textarea className="sv-input" rows={k === 'notes' ? 2 : 2} readOnly={!editing} value={f[k]} placeholder={k === 'allergies' ? 'e.g. Penicillin (hives); or NKDA' : 'e.g. None reported'} onChange={e => setF({ ...f, [k]: e.target.value })} data-testid={`v10-hx-${k}`} /></label>;
  const isClin = CLINICIAN_ROLES.some(r => r.toLowerCase() === actor.role.toLowerCase());
  return <><ClearanceDocsCard c={c} /><div className="a82-two" data-testid="v10-verify">
    <div>
      <div className="vt-alert vt-alert--ai" data-testid="v10-hx-ai"><ShieldCheck aria-hidden="true" /><div><span className="vt-alert__title">Nightingale summary (draft)</span>{draft.summary}<div className="sv-small" style={{ marginTop: 4 }}>Nightingale drafts from the records. The nurse edits and confirms; Nightingale never signs.</div></div></div>
      <div style={{ marginTop: 10 }}><AllergyCard list={medRepo.patient(c.pid)?.allergies} confirmed={rec?.confirmed ? `Confirmed ${tm(rec.confirmed.at)} · ${rec.confirmed.by}` : 'Not yet confirmed for this surgery'} /></div>
      <div className="v10-card" style={{ marginTop: 10 }}><SourceLinks c={c} /></div>
    </div>
    <div>
      {rec?.confirmed && <div className="vt-alert vt-alert--success" data-testid="v10-hx-official"><Check aria-hidden="true" /><div><span className="vt-alert__title">Official medical history</span>Confirmed by {rec.confirmed.by} · {tm(rec.confirmed.at)}. Every later station uses this record; anyone on the team can view it.{rec.amendments.length > 0 && <> Amended {rec.amendments.length}× (latest: {rec.amendments[rec.amendments.length - 1].reason}).</>}</div></div>}
      {(Object.keys(D.HISTORY_LABEL) as (keyof D.HistoryFields)[]).map(F)}
      {amend && editing && <label className="block mt-2"><span className="sv-label">Reason for the amendment (required)</span><input className="sv-input" value={reason} onChange={e => setReason(e.target.value)} placeholder="e.g. Patient recalled a latex allergy at the bedside" data-testid="v10-hx-reason" /></label>}
      <div className="a81-foot" style={{ marginTop: 10 }}>
        {!rec?.confirmed && <button type="button" className="a8-btn" onClick={() => { D.saveHistory(c.id, { ...f, amendments: [], draftedBy: 'Nightingale' }, actor.name, actor.role, 'Medical history draft saved'); onClose('Draft saved.'); }} data-testid="v10-hx-save">Save draft</button>}
        {rec?.confirmed && !editing && (isClin ? <button type="button" className="a8-btn" onClick={() => setEditing(true)} data-testid="v10-hx-amend"><Pencil size={14} style={{ display: 'inline', verticalAlign: '-2px' }} /> Amend</button> : <span className="v10-sub">Licensed clinicians can amend this record.</span>)}
        {editing && <button type="button" className="a8-btn pri" disabled={amend && (!reason.trim() || !changed)} onClick={() => confirm(actor.name, actor.role)} data-testid="v10-hx-confirm">{amend ? 'Save amendment' : 'Confirm medical history'}</button>}
      </div>
    </div>
    {/* v10.6.3: verifying the history needs no signature; the confirm is recorded with the user's name and time. */}
  </div></>;
};
/** Read-only official history for later stations (brief narrative, no form links). */
export const OfficialHistory: React.FC<{ c: A.AscCase }> = ({ c }) => {
  useMedTick(); const rec = D.historyOf(c.id); const p = medRepo.patient(c.pid);
  if (!rec?.confirmed) return <div className="vt-alert vt-alert--warning" data-testid="v10-official-pending"><AlertTriangle aria-hidden="true" /><div><span className="vt-alert__title">Medical history not verified yet</span>The nurse confirms it at Verify medical history. You can continue.</div></div>;
  const line = (k: keyof D.HistoryFields) => rec[k] ? <p key={k} style={{ margin: '4px 0' }}><b>{D.HISTORY_LABEL[k]}:</b> {rec[k]}</p> : null;
  return <section className="v10-card" data-testid="v10-official"><h3 className="v10-h">Medical history <span className="v10-chip ok">Official · {rec.confirmed.by.replace(/,.*$/, '')}</span></h3>
    <AllergyCard compact list={p?.allergies} />{(['conditions', 'meds', 'surgical', 'anesthesia', 'notes'] as (keyof D.HistoryFields)[]).map(line)}
    {rec.amendments.length > 0 && <p className="v10-sub">Amended {rec.amendments.length}× · latest by {rec.amendments[rec.amendments.length - 1].by}: {rec.amendments[rec.amendments.length - 1].reason}</p>}</section>;
};

/* ---------------- Surgeon standing checklist (pre-op at Nursing, post-op at PACU) ---------------- */
export const StandingChecklist: React.FC<{ c: A.AscCase; phase: D.Phase }> = ({ c, phase }) => {
  useMedTick(); const [actor] = useActor(); const l = D.viewList(c.id, c.surgeon, phase); const [txt, setTxt] = useState('');
  const title = phase === 'pre' ? 'Surgeon’s pre-op orders' : 'Surgeon’s post-op orders'; const done = l.items.filter(i => l.ticks[i.id]).length;
  return <section className="v10-card" data-testid={`v10-list-${phase}`}><h3 className="v10-h"><ClipboardList size={18} aria-hidden="true" />{title}
    <span className="v10-sub" style={{ fontWeight: 500 }}>{c.surgeon} · {l.version ? `own orders v${l.version}` : 'facility standard'}</span><span className={`v10-chip ${done === l.items.length && l.items.length ? 'ok' : 'warn'}`} style={{ marginLeft: 'auto' }}>{done} of {l.items.length}</span></h3>
    {!l.items.length && <div className="v10-empty" data-testid={`v10-list-empty-${phase}`}><b>No standard {phase === 'pre' ? 'pre-op' : 'post-op'} list for {c.surgeon} yet</b>Add them in Practice Settings › Standard pre-op & post-op orders, or add a one-off order below.</div>}
    {l.items.map(i => { const t = l.ticks[i.id]; return <label key={i.id} className={`v10-li ${t ? 'done' : ''}`} data-testid={`v10-li-${phase}`}><input type="checkbox" checked={!!t} onChange={e => D.tickItem(c.id, c.surgeon, phase, i.id, e.target.checked, actor.name, actor.role)} data-testid={`v10-tick-${phase}-${i.id}`} />
      <span style={{ flex: 1 }}>{i.text}{i.oneOff && <span className="v10-chip info" style={{ marginLeft: 6 }}>One-off</span>}</span>{t && <span className="v10-chip ok" data-testid="v10-tick-stamp">{t.time} · {t.initials}</span>}</label>; })}
    <div className="v10-row" style={{ marginTop: 8 }}><input className="sv-input" style={{ flex: 1 }} value={txt} onChange={e => setTxt(e.target.value)} placeholder="Add a one-off order for this patient, e.g. Recheck glucose before transfer" data-testid={`v10-oneoff-${phase}`} />
      <button type="button" className="a8-btn" disabled={!txt.trim()} onClick={() => { D.addOneOff(c.id, c.surgeon, phase, txt.trim(), actor.name, actor.role); setTxt(''); }} data-testid={`v10-oneoff-add-${phase}`}><Plus size={14} style={{ display: 'inline', verticalAlign: '-2px' }} /> Add</button></div>
    <p className="v10-sub" style={{ marginTop: 6 }}>Ticks record the time and your initials. The orders are locked to this case when nursing starts.</p></section>;
};

/* ---------------- Brief OP report (OR circulating nurse writes; surgeon PIN-signs before leaving) ---------------- */
export const BriefOpReport: React.FC<{ c: A.AscCase }> = ({ c }) => {
  useMedTick(); const [actor] = useActor(); const cur = D.briefOp(c.id); const blank = { pre: '', post: '', procedure: c.procedure, findings: '', ebl: c.d.ebl || '', specimens: '', implants: '', complications: '', condition: '' } as D.BriefOp;
  const [b, setB] = useState<D.BriefOp>(cur || blank); const [sign, setSign] = useState(false); const signed = !!cur?.signed;
  const save = () => D.saveBriefOp(c.id, { ...b, writtenBy: cur?.writtenBy || D.stamp(actor.name, actor.role) }, actor.name, actor.role, 'Brief OP report saved');
  return <section className="v10-card" data-testid="v10-briefop"><h3 className="v10-h">Brief OP report {signed ? <span className="v10-chip ok" data-testid="v10-briefop-signed">Signed · {cur!.signed!.by}</span> : <span className="v10-chip warn">Surgeon signature needed before leaving</span>}</h3>
    <p className="v10-sub">The circulating nurse writes it in the OR; the surgeon signs with PIN. The formal op report comes later from dictation.</p>
    {!signed && <div style={{ marginTop: 6 }}><DictateMic testId="v103-bo-mic" label="Dictate brief OP report" sample={`Pre-op diagnosis: ${c.procedure.replace(/ release| repair| excision/i, '')}. Post-op diagnosis: same. Procedure performed: ${c.procedure}. Findings: as expected. EBL: 10 mL. Specimens: none. Implants: none. Complications: none. Condition to PACU: stable.`} onText={t => { const v = parseBriefOp(t); setB(x => { const n: any = { ...x }; Object.entries(v).forEach(([k, val]) => { if (val) n[k] = val; }); return n; }); }} /></div>}
    <div className="v10-grid" style={{ marginTop: 8 }}>{D.BRIEF_FIELDS.map(([k, l, ph]) => <label key={k}><span className="sv-label">{l}</span><input className="sv-input" readOnly={signed} value={(b as any)[k] || ''} placeholder={ph} onChange={e => setB({ ...b, [k]: e.target.value })} data-testid={`v10-bo-${k}`} /></label>)}</div>
    <div className="a81-foot" style={{ marginTop: 10 }}>{!signed && <><button type="button" className="a8-btn" onClick={save} data-testid="v10-bo-save">Save</button>
      <button type="button" className="a8-btn pri" onClick={() => { save(); setSign(true); }} data-testid="v10-bo-sign">Surgeon: sign with PIN</button></>}</div>
    {sign && <PinSign title="Sign brief OP report" sigCase={c.id} roles={PROVIDER_ROLES} allow={p => p.name === c.surgeon} statement={<>I reviewed the brief operative report for {c.procedure}.</>} onClose={() => setSign(false)}
      onSigned={s => { const at = new Date().toISOString(); D.saveBriefOp(c.id, { ...b, writtenBy: cur?.writtenBy || D.stamp(actor.name, actor.role), signed: { by: s.name, role: s.role, at } }, s.name, s.role, 'Brief OP report signed by the surgeon (PIN)');
        S.saveOpReport(S.caseById(c.id)!, D.BRIEF_FIELDS.map(([k, l]) => `${l}: ${(b as any)[k] || '—'}`).join('\n'), s.name, s.role, { name: s.name, at }); setSign(false); }} />}
  </section>;
};
