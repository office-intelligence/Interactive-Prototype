/* ASC.Vityls v10 · design kit v1.2 pieces for React: Nightingale Spark wordmark (ASC green), kit X close, allergy card,
 * kit toast. Icons come from lucide-react (the kit's ui icons are the same Lucide set, ISC). */
import React from 'react';
import { X, CheckCircle2, AlertTriangle, Info, ShieldAlert } from 'lucide-react';
import { allergyState } from '../../v7/allergy';
import wmLight from './kit/wordmark/Nightingale-Spark-wordmark-asc-light.svg';
import wmDark from './kit/wordmark/Nightingale-Spark-wordmark-asc-dark.svg';
export { wmLight, wmDark };
export const SparkWordmark: React.FC<{ dark?: boolean; height?: number }> = ({ dark, height = 32 }) =>
  <img src={dark ? wmDark : wmLight} alt="ASC.Vityls" className="v10-wordmark" style={{ height, width: 'auto' }} data-testid="v10-wordmark" />;
export const KitClose: React.FC<{ onClick: () => void; label?: string; testId?: string }> = ({ onClick, label = 'Close', testId }) =>
  <button type="button" className="vt-btn-close" onClick={onClick} aria-label={label} title={label} data-testid={testId}><X size={20} /></button>;
/** NKDA green · allergies red (2 px) · Not reported amber dashed. Never blocks. */
export const AllergyCard: React.FC<{ list?: string[] | string | null; confirmed?: string; compact?: boolean }> = ({ list, confirmed, compact }) => {
  const a = allergyState(list); const kind = a.state === 'nkda' ? 'nkda' : a.state === 'allergies' ? 'present' : 'unknown';
  const Ico = kind === 'nkda' ? CheckCircle2 : kind === 'present' ? ShieldAlert : AlertTriangle;
  return <div className={`vt-allergy vt-allergy--${kind} ${compact ? 'v10-allergy-compact' : ''}`} data-testid="v10-allergy" data-state={kind} role={kind === 'present' ? 'alert' : undefined}>
    <Ico aria-hidden="true" /><div><span className="vt-allergy__label">Allergies</span><span className="vt-allergy__value">{kind === 'nkda' ? 'NKDA' : kind === 'present' ? a.items.join('; ') : 'Not reported'}</span>
      {confirmed && <div className="v10-allergy-sub">{confirmed}</div>}</div></div>;
};
export const KitToast: React.FC<{ msg: string; onClose: () => void; kind?: 'success' | 'warning' | 'danger' | 'info' }> = ({ msg, onClose, kind = 'success' }) => {
  const Ico = kind === 'success' ? CheckCircle2 : kind === 'info' ? Info : AlertTriangle;
  return <div className="vt-toast-region"><div role="status" className={`vt-toast vt-toast--${kind}`} data-testid="sv-toast"><Ico aria-hidden="true" /><span>{msg}</span><KitClose onClick={onClose} label="Dismiss" /></div></div>;
};
export const KitAlert: React.FC<{ kind?: 'info' | 'success' | 'warning' | 'danger' | 'ai'; title?: string; children: React.ReactNode; testId?: string }> = ({ kind = 'warning', title, children, testId }) => {
  const Ico = kind === 'success' ? CheckCircle2 : kind === 'info' || kind === 'ai' ? Info : AlertTriangle;
  return <div className={`vt-alert vt-alert--${kind}`} data-testid={testId}><Ico aria-hidden="true" /><div>{title && <span className="vt-alert__title">{title}</span>}{children}</div></div>;
};
