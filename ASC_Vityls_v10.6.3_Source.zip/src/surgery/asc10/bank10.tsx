/* ASC.Vityls v10.2 · Missing information on the stations (was: question bank).
 * v10.2: a station shows only its own team's questions (front desk also asks what the patient left blank on the intake forms),
 * laid out as an aligned online form; no Export / Print on the stations.
 * Templates (the center's forms) stay on the surface: fields are grouped by template and section.
 * Every field maps to ONE bank question, answered once per case; a station shows only its unanswered fields
 * (answered ones are behind "Show answered"). A PDF is never generated automatically: the form text is rendered
 * from the answers only when staff press Export / Print. Fictional data only. */
import React, { useMemo, useState } from 'react';
import { medRepo, ageFrom } from '../../med/record';
import { useActor, useMedTick } from '../../med/ui';
import { svRead, svWrite } from '../store';
import * as A from '../asc8/logic';
import * as E from './bank/engine';
import { historyOf } from './store10';

export type BenchStation = 'arrival' | 'nursing' | 'anesthesia' | 'surgeon' | 'or' | 'pacu' | 'discharge';
export const BANK_STATION: Record<BenchStation, E.Station> = { arrival: 'FD', nursing: 'RN', anesthesia: 'AN', surgeon: 'SX', or: 'OR', pacu: 'PA', discharge: 'DC' };
const K = 'asc10-answers';
export const answersOf = (cid: string): E.Answers => (svRead<Record<string, E.Answers>>(K, {})[cid] || {});
export const saveAnswers = (cid: string, a: E.Answers) => { const all = svRead<Record<string, E.Answers>>(K, {}); svWrite(K, { ...all, [cid]: a }); window.dispatchEvent(new Event('vityls-med-updated')); };
export const bank = () => E.BASE.filter(q => !q.hidden && q.scope !== 'facility');
export function ctxOf(c: A.AscCase): E.CaseCtx { const p = medRepo.patient(c.pid) as any; return { age: p?.dob ? ageFrom(p.dob) : undefined, gender: p?.gender || p?.sex, anesthesia: c.anesthesia, durationMins: c.durationMin, mrn: c.pid }; }
/** Prefill answers we already hold (booking, official history) so they are never asked twice. */
export function prefilled(c: A.AscCase): E.Answers {
  let a = answersOf(c.id); const p = medRepo.patient(c.pid) as any; const at = new Date().toISOString(); const h = historyOf(c.id);
  const src = (label: string, source: E.SourceKind = 'booking') => ({ source, label, by: 'System', at });
  a = E.prefill(a, 'SH-01', p?.name, src('Booking')); a = E.prefill(a, 'SH-02', p?.dob, src('Booking')); a = E.prefill(a, 'SH-03', p?.gender || p?.sex, src('Booking'));
  a = E.prefill(a, 'SH-05', p?.phone, src('Booking'));
  if (h?.confirmed) { a = E.prefill(a, 'SH-15', h.allergies, src('Official medical history', 'staff')); a = E.prefill(a, 'SH-17', h.meds, src('Official medical history', 'staff')); a = E.prefill(a, 'SH-25', h.conditions, src('Official medical history', 'staff')); }
  return a;
}
const ASKABLE: E.Kind[] = ['yesno', 'choice', 'multi', 'text', 'number', 'date', 'list', 'narrative'];
const Field: React.FC<{ q: E.Question; v: string; on: (v: string) => void }> = ({ q, v, on }) => {
  const id = `v10-q-${q.id}`;
  if (q.kind === 'yesno' || (q.kind === 'choice' && q.options.length)) { const opts = q.kind === 'yesno' ? ['Yes', 'No'] : q.options;
    /* v10.6 tablet: short option lists are big tap targets, not a dropdown. */
    if (opts.length <= 8 && opts.every(o => o.length <= 60)) return <div className="v106-chips" role="radiogroup" aria-label={q.text} id={id} data-testid={id} data-value={v}>{opts.map((o, i) => <button key={o} type="button" role="radio" aria-checked={v === o} className={v === o ? 'on' : ''} onClick={() => on(o)} data-testid={`${id}-opt-${i}`}>{o}</button>)}</div>;
    return <select className="sv-input" value={v} onChange={e => on(e.target.value)} id={id} data-testid={id}><option value="">Choose…</option>{opts.map(o => <option key={o}>{o}</option>)}</select>; }
  if (q.kind === 'narrative' || q.kind === 'list' || q.kind === 'multi') return <textarea className="sv-input" rows={2} defaultValue={v} onBlur={e => on(e.target.value)} placeholder={q.options.length ? `e.g. ${q.options.slice(0, 2).join(', ')}` : ''} id={id} data-testid={id} />;
  return <input className="sv-input" type={q.kind === 'number' ? 'number' : 'text'} defaultValue={v} onBlur={e => on(e.target.value)} placeholder={q.kind === 'date' ? 'e.g. 03/14/2026' : ''} id={id} data-testid={id} />;
};
/** v10.2: each station asks only its own team's questions; patient-supplied ones are asked once, at the front desk, when left blank on the intake forms. */
export const STATION_TEAMS: Record<E.Station, string[]> = { FD: ['Front desk / Admin', 'Shared (patient-supplied)'], RN: ['Pre-op Nursing'], AN: ['Anesthesia'], SX: ['Surgeon'], OR: ['OR Nursing'], PA: ['PACU / Discharge'], DC: ['PACU / Discharge'] } as any;
export const ownQuestion = (q: E.Question, st: E.Station) => (STATION_TEAMS[st] || []).includes(q.team);
/** A form's owning team = the team with most of its questions; a station only uses a form's title for forms it owns. */
const FORM_TEAM: Record<string, string> = (() => { const m: Record<string, Record<string, number>> = {}; E.BASE.forEach(q => { if (!q.form) return; (m[q.form] = m[q.form] || {})[q.team] = (m[q.form]?.[q.team] || 0) + 1; }); return Object.fromEntries(Object.entries(m).map(([f, t]) => [f, Object.entries(t).sort((a, b) => b[1] - a[1])[0][0]])); })();
export const tplTitle = (f: string | undefined, st: E.Station) => (f && !/^\(/.test(f) && (STATION_TEAMS[st] || []).includes(FORM_TEAM[f]) && E.TEMPLATES[f]?.title) || 'Other details';
export function stationOpen(c: A.AscCase, st: E.Station) { const a = prefilled(c); return E.stationItems(bank(), st, ctxOf(c), a, E.DEFAULT_SETTINGS).filter(i => i.mode === 'ask' && ASKABLE.includes(i.q.kind) && ownQuestion(i.q, st)); }
export const BankFields: React.FC<{ c: A.AscCase; bench: BenchStation }> = ({ c, bench }) => {
  useMedTick(); const [actor] = useActor(); const st = BANK_STATION[bench]; const [all, setAll] = useState(false); const [open, setOpen] = useState(true); const [, f] = useState(0); const [tplOpen, setTplOpen] = useState<string | null>(null);
  const a = prefilled(c);
  const items = useMemo(() => stationOpen(c, st), [c.id, st, JSON.stringify(a)]);
  const open_ = items.filter(i => i.status === 'missing' || i.status === 'empty' || i.status === 'default'); const done = items.length - open_.length;
  const shown = all ? items : open_;
  const byTpl = shown.reduce<Record<string, E.StationItem[]>>((m, i) => { const k = tplTitle(i.q.form, st); (m[k] = m[k] || []).push(i); return m; }, {});
  const set = (q: E.Question, v: string) => { if (!v.trim()) return; saveAnswers(c.id, E.setAnswer(a, q.id, v, { source: 'staff', by: actor.name, at: new Date().toISOString(), station: st })); f(x => x + 1); };
  if (!items.length) return null;
  return <section className="v10-card" data-testid="v10-bank" data-open={open_.length} data-done={done}>
    <div className="v10-row"><b className="v10-h">To do</b><span className={`v10-chip ${open_.length ? 'warn' : 'ok'}`} data-testid="v10-bank-count">{open_.length ? `${open_.length} to complete` : 'All complete'}</span>
      <span style={{ marginLeft: 'auto' }} /><button type="button" className="a8-btn" onClick={() => setOpen(!open)} data-testid="v10-bank-toggle">{open ? 'Hide' : 'Show'}</button></div>
    <p className="v10-sub">Only what is still missing at this station. Anything already answered is not asked again.</p>
    {open && <>
      {done > 0 && <label className="sv-small"><input type="checkbox" checked={all} onChange={e => setAll(e.target.checked)} data-testid="v10-bank-all" /> Show completed ({done})</label>}
      {!shown.length && <div className="v10-empty" data-testid="v10-bank-empty"><b>Nothing missing here</b></div>}
      {(Object.entries(byTpl) as [string, E.StationItem[]][]).map(([tpl, l], gi) => { const isOpen = tplOpen === null ? gi === 0 : tplOpen === tpl; const left = l.filter(i => i.status === 'missing' || i.status === 'empty' || i.status === 'default').length;
        return <div key={tpl} className={`v102-group ${isOpen ? 'open' : 'shut'}`} data-testid="v10-bank-tpl" data-tpl={tpl}><button type="button" className="v106-grp" aria-expanded={isOpen} onClick={() => setTplOpen(isOpen ? '' : tpl)} data-testid="v106-grp"><h4>{tpl}</h4><span className={left ? 'warn' : 'ok'}>{left ? `${left} to do` : 'Done'}</span><span className="chev" aria-hidden="true">›</span></button>
        {isOpen && <div className="v102-form">{l.map(i => <React.Fragment key={i.q.id}><label className="lab" htmlFor={`v10-q-${i.q.id}`} data-testid="v10-bank-q" data-qid={i.q.id}>{E.shortLabel(i.q.text) === i.q.text ? i.q.text : i.q.text.replace(/\s*\(.*?\)\s*/g, ' ').trim()}{i.required && <span className="req">required</span>}</label>
          <div className="inp" data-testid="v10-bank-inp" data-qid={i.q.id}><Field q={i.q} v={i.value} on={v => set(i.q, v)} /></div></React.Fragment>)}</div>}</div>; })}
    </>}
  </section>;
};
