/* ASC.Vityls v10 · clean start (default build). Creates configuration only: two role-titled test surgeon accounts so the
 * stations can be signed in testing, the session actor and the default form assignment. No patients, cases, documents,
 * messages, summaries, faxes or activity. Henry's API replaces all of this with the practice's real setup. */
import { repo } from '../../v6/dataLayer';
import { hashPin } from '../../v7/providers';
import { ASC10_SEED_VERSION } from './demo';

const MY_FORMS: [string, string[], string][] = [
  ['Patient_Registration.html', ['frontOffice'], 'required'], ['Insurance_Information.html', ['frontOffice'], 'as-needed'],
  ['Medical_History.html', ['patientPortal', 'nursing'], 'required'], ['Photography_Media_Research_Consent.html', ['patientPortal', 'frontOffice'], 'as-needed'],
  ['Credit_Card_Authorization.html', ['frontOffice'], 'as-needed'], ['Procedure_Consent.html', ['surgeon'], 'as-needed'],
];
const now = () => new Date().toISOString();
const testSurgeon = (id: string, last: string, color: string) => ({ id, firstName: 'Test', lastName: last, degree: 'MD', role: 'Surgeon', specialty: 'Surgery', npi: '', email: '', phone: '', color, pinHash: hashPin('1234'), active: true,
  app: { id: `APP-${id}`, status: 'Privileges approved' as const, createdAt: now(), history: [{ status: 'Privileges approved', at: now(), by: 'Test account' }] },
  onboarding: { invitedAt: now(), applicationAt: now(), accountAt: now(), pinAt: now(), username: '(test account)' } });

export function seedClean() {
  try {
    const params = new URLSearchParams(location.search);
    if (params.has('reset-test-data') || localStorage.getItem('vityls:seed-version') !== ASC10_SEED_VERSION) {
      localStorage.clear(); localStorage.setItem('vityls:seed-version', ASC10_SEED_VERSION);
      if (params.has('reset-test-data')) { const u = new URL(location.href); u.searchParams.delete('reset-test-data'); history.replaceState(null, '', u.toString()); }
    }
    if (localStorage.getItem('vityls:asc10:clean-config')) return;
    localStorage.setItem('vityls-explicit-form-workflow-v3-clean', 'done'); localStorage.setItem('oi-premiere-official-html-library-v27-clean', 'done');
    localStorage.setItem('vityls:v7:providers', JSON.stringify([testSurgeon('prov-test1', 'Surgeon', '#1D4ED8'), testSurgeon('prov-test2', 'Surgeon Two', '#7C3AED')]));
    repo.setActor({ name: 'Front desk (test account)', role: 'Front desk', kind: 'human' } as any);
    localStorage.setItem('vityls-my-forms:default-practice', JSON.stringify(MY_FORMS.map(f => f[0])));
    MY_FORMS.forEach(([file, stations, req]) => { const wf: Record<string, { enabled: boolean }> = {}; ['patientPortal', 'frontOffice', 'nursing', 'anesthesia', 'orTeam', 'surgeon', 'pacu'].forEach(k => wf[k] = { enabled: stations.includes(k) }); localStorage.setItem(`vityls-form-workflow:${file}`, JSON.stringify(wf)); localStorage.setItem(`vityls-form-requirement:${file}`, req); });
    localStorage.setItem('vityls:asc10:clean-config', now());
  } catch (e) { console.warn('ASC v10 clean start failed', e); }
}
