/* ASC.Vityls v10.3 · Portal / At-home: the intake forms sent to the patient (with status), and front desk picks forms from the
 * At-home station's list and sends them (simulated outbox). The Booking intake stays one tap away. Fictional data. */
import React, { useState } from 'react';
import { createPortal } from 'react-dom';
import { medRepo } from '../../med/record';
import { useActor, useMedTick } from '../../med/ui';
import { repo } from '../../v6/dataLayer';
import { stationPlan } from '../../v7/myForms';
import * as S from '../asc8/store';
import { XClose } from '../asc82/common';
import { openBench } from '../asc81/practice81';
import { formsPackets, sendFormsPacket, formTitle } from '../newPatient';

let setOpenG: ((pid: string | null) => void) | null = null;
export const openPortal103 = (pid?: string) => setOpenG?.(pid || '');
const status = (pid: string, f: string) => { const cs = S.cases().filter(c => c.pid === pid); const recs = [...cs.map(c => repo.getForm(c.visitId, f)), repo.getForm(`portal-forms:${pid}`, f)];
  return recs.some(r => r.status === 'locked') ? 'Completed' : recs.some(r => r.status !== 'not-started') ? 'In progress' : 'Not started'; };

export const Portal103Host: React.FC = () => { const [pid, setPid] = useState<string | null>(null); setOpenG = setPid; return pid === null ? null : createPortal(<Portal103 pid0={pid} onClose={() => setPid(null)} />, document.body); };

const Portal103: React.FC<{ pid0: string; onClose: () => void }> = ({ pid0, onClose }) => {
  useMedTick(); const [actor] = useActor(); const [pid, setPid] = useState(pid0); const p = pid ? medRepo.patient(pid) : undefined;
  const plan = stationPlan('patientPortal'); const list = Array.from(new Set([...plan.required, ...plan.asNeeded]));
  const sent = p ? formsPackets(p.id) : []; const sentFiles = Array.from(new Set(sent.flatMap(x => x.forms)));
  const [pick, setPick] = useState<string[]>([]); const [text, setText] = useState(true); const [email, setEmail] = useState(true); const [portal, setPortal] = useState(true); const [msg, setMsg] = useState(''); const [err, setErr] = useState('');
  const send = () => { if (!p) return; setErr(''); try { sendFormsPacket(p, { forms: pick, text: text && !!p.phone, email: email && !!p.email, portal }, actor.name, actor.role); setMsg(`${pick.length} form${pick.length === 1 ? '' : 's'} queued for ${p.name} in the outbox. Nothing is texted or emailed in this build.`); setPick([]); } catch (e) { setErr((e as Error).message); } };
  const pts = medRepo.patients().slice().sort((a, b) => a.name.localeCompare(b.name));
  return <div className="a81-modal a83-modal v104-portal-layer" onMouseDown={e => { if (e.target === e.currentTarget) onClose(); }}><div className="a81-dialog a83-dlg wide" role="dialog" aria-label="Portal / At-home forms" data-testid="v103-portal">
    <div className="a81-dhead"><b>Portal / At-home forms</b><span style={{ marginLeft: 'auto' }} /><XClose onClick={onClose} testId="v103-portal-close" /></div>
    <div className="a81-dbody">
      <label className="a83-f"><span className="a83-l">Patient</span><select className="sv-input" value={pid} onChange={e => { setPid(e.target.value); setMsg(''); setPick([]); }} data-testid="v103-portal-patient"><option value="">Choose a patient…</option>{pts.map(x => <option key={x.id} value={x.id}>{x.name} · DOB {x.dob}</option>)}</select></label>
      {p && <>
        <section className="a82-sec" data-testid="v103-portal-sent"><h3 className="a81-h3">Forms sent to {p.name}</h3>
          {sentFiles.length ? <ul className="v103-plist">{sentFiles.map(f => { const st = status(p.id, f); const last = sent.filter(x => x.forms.includes(f)).slice(-1)[0];
            return <li key={f} data-testid="v103-portal-sent-row"><span className="t">{formTitle(f)}</span><span className="sv-small sv-muted">sent {new Date(last.sentAt).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}</span><span className={`v10-chip ${st === 'Completed' ? 'ok' : st === 'In progress' ? 'warn' : ''}`}>{st}</span></li>; })}</ul>
            : <p className="sv-small sv-muted">No forms have been sent to this patient yet.</p>}</section>
        <section className="a82-sec" data-testid="v103-portal-pick"><h3 className="a81-h3">Send forms from the At-home list</h3>
          <div className="v103-plist">{list.map(f => <label key={f} className="a82-ck row"><input type="checkbox" checked={pick.includes(f)} onChange={e => setPick(e.target.checked ? [...pick, f] : pick.filter(x => x !== f))} data-testid={`v103-portal-f-${f}`} /><span className="l">{formTitle(f)}{plan.required.includes(f) && <span className="a81-chip">Required</span>}{sentFiles.includes(f) && <span className="sv-small sv-muted"> · sent before</span>}</span></label>)}</div>
          <div className="flex flex-wrap gap-4 mt-2 text-[14px]"><label className="flex items-center gap-2"><input type="checkbox" checked={text && !!p.phone} disabled={!p.phone} onChange={e => setText(e.target.checked)} />Text {p.phone || '(no mobile)'}</label><label className="flex items-center gap-2"><input type="checkbox" checked={email && !!p.email} disabled={!p.email} onChange={e => setEmail(e.target.checked)} />Email {p.email || '(no email)'}</label><label className="flex items-center gap-2"><input type="checkbox" checked={portal} onChange={e => setPortal(e.target.checked)} />Patient portal</label></div>
          {err && <p className="a81-err">{err}</p>}{msg && <p className="a81-ok" data-testid="v103-portal-msg">{msg}</p>}
          <div className="a81-foot"><button type="button" className="a8-btn" onClick={() => setPick(list.filter(f => !sentFiles.includes(f)))}>Select all not yet sent</button><button type="button" className="a8-btn pri" disabled={!pick.length} onClick={send} data-testid="v103-portal-send">Send {pick.length || ''} form{pick.length === 1 ? '' : 's'} to the patient</button></div></section>
      </>}
      <p className="sv-small sv-muted mt-2">Booking requests from surgeon offices are in <button type="button" className="sv-link" onClick={() => { onClose(); openBench('intake' as any); }} data-testid="v103-portal-intake">Booking intake</button>.</p>
    </div></div></div>;
};
