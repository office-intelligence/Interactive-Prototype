/* ASC.Vityls v10.2 · Nightingale chat box on Compliance & credentials: staff ask for compliance tasks in plain words
 * ("which licenses expire in 60 days?", "remind me to renew the CLIA waiver"). Nightingale drafts the task; a person
 * confirms it. Nothing leaves the device and nothing is sent. Fictional data only. */
import React, { useState } from 'react';
import { Sparkles, Send, Check, X } from 'lucide-react';
import { useActor } from '../../med/ui';
import { svRead, svWrite } from '../store';
import { repo } from '../../v6/dataLayer';

export interface CTask { id: string; text: string; due?: string; status: 'draft' | 'open' | 'done'; by: string; at: string }
const K = 'asc102-compliance-tasks';
export const ctasks = () => svRead<CTask[]>(K, []);
const put = (l: CTask[]) => { svWrite(K, l); window.dispatchEvent(new Event('vityls-med-updated')); };
/** Pure: Nightingale's draft reply + task for a request. Never decides; it only proposes. */
export function draftComplianceTask(q: string): { reply: string; task?: string; due?: string } {
  const t = q.trim(); if (!t) return { reply: '' };
  const days = t.match(/(\d+)\s*days?/i)?.[1]; const due = days ? new Date(Date.now() + +days * 864e5).toISOString().slice(0, 10) : undefined;
  if (/expir|renew|due/i.test(t) && /\?$/.test(t)) return { reply: `I would check every credential and facility document with a renewal date${days ? ` in the next ${days} days` : ''}. Nothing is tracked with a date yet in this center. I drafted a task to review renewals.`, task: `Review credentials and documents due for renewal${days ? ` within ${days} days` : ''}`, due };
  if (/audit|survey|aaaasf|quad\s*a|joint commission|cdph/i.test(t)) return { reply: 'I drafted an accreditation readiness task. I can list the documents each binder needs once you upload them.', task: `Accreditation readiness: ${t.replace(/[?.!]+$/, '')}`, due };
  return { reply: 'I drafted this as a task. Confirm it to add it to the list.', task: t.replace(/^(please\s+)?(remind me to|create a task to|add a task to)\s+/i, '').replace(/[?.!]+$/, '').replace(/^./, m => m.toUpperCase()), due };
}
export const ComplianceAsk: React.FC = () => {
  const [actor] = useActor(); const [q, setQ] = useState(''); const [log, setLog] = useState<{ q: string; a: string }[]>([]); const [l, setL] = useState<CTask[]>(ctasks());
  const send = () => { const d = draftComplianceTask(q); if (!d.reply) return; const n = d.task ? [...l, { id: `ct-${Date.now().toString(36)}`, text: d.task, due: d.due, status: 'draft' as const, by: 'Nightingale (draft)', at: new Date().toISOString() }] : l; put(n); setL(n); setLog([...log, { q, a: d.reply }]); setQ(''); };
  const set = (id: string, status: CTask['status'] | 'delete') => { const n = status === 'delete' ? l.filter(x => x.id !== id) : l.map(x => x.id === id ? { ...x, status, by: actor.name } : x); put(n); setL(n); repo.audit({ caseId: 'practice', user: actor.name, role: actor.role, action: 'asc102.ctask' as any, detail: `Compliance task ${status}: ${l.find(x => x.id === id)?.text}` }); };
  return <section className="v10-card" data-testid="v102-compliance-ask" style={{ background: '#fff', marginTop: 12 }}>
    <h3 className="v10-h"><Sparkles size={18} aria-hidden="true" />Ask Nightingale for a compliance task</h3>
    <form className="v10-row" onSubmit={e => { e.preventDefault(); send(); }}><input className="sv-input" style={{ flex: 1 }} value={q} onChange={e => setQ(e.target.value)} placeholder="e.g. Which licenses expire in the next 60 days?" data-testid="v102-cask-input" />
      <button type="submit" className="a8-btn pri" disabled={!q.trim()} data-testid="v102-cask-send"><Send size={14} style={{ display: 'inline', verticalAlign: '-2px', marginRight: 4 }} />Ask</button></form>
    {log.slice(-3).map((m, i) => <div key={i} className="sv-small" style={{ marginTop: 8 }} data-testid="v102-cask-reply"><b>You:</b> {m.q}<br /><b>Nightingale:</b> {m.a}</div>)}
    {l.length > 0 && <div style={{ marginTop: 10 }} data-testid="v102-ctasks">{l.map(t => <div key={t.id} className={`v10-li ${t.status === 'done' ? 'done' : ''}`} data-testid="v102-ctask" data-status={t.status}>
      <span style={{ flex: 1 }}>{t.text}{t.due ? ` · due ${t.due}` : ''}</span><span className={`v10-chip ${t.status === 'draft' ? 'warn' : t.status === 'done' ? 'ok' : 'info'}`}>{t.status === 'draft' ? 'Draft' : t.status === 'open' ? 'Open' : 'Done'}</span>
      {t.status === 'draft' && <button type="button" className="sv-link sv-small" onClick={() => set(t.id, 'open')} data-testid="v102-ctask-confirm">Confirm</button>}
      {t.status === 'open' && <button type="button" className="sv-link sv-small" onClick={() => set(t.id, 'done')}><Check size={13} /> Done</button>}
      <button type="button" className="sv-link sv-small" aria-label="Remove" onClick={() => set(t.id, 'delete')}><X size={13} /></button></div>)}</div>}
    <p className="v10-sub" style={{ marginTop: 8 }}>Nightingale drafts tasks only. A person confirms each one.</p></section>;
};
