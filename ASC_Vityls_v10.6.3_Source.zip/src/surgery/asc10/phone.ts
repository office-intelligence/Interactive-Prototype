/* ASC.Vityls v10 · phone fields. Every phone field formats itself as you type: (310) 555-1234, optional "ext. 12".
 * Stored as E.164 (+13105551234;ext=12) where the code saves it (toE164). Incomplete numbers get a soft warning only:
 * the field is tinted and a hint shows, nothing is blocked. Pure helpers + one delegated listener for the whole app. */
export function phoneDigits(v: string): { main: string; ext: string } {
  const s = String(v || ''); const m = /(?:ext\.?|x|#)\s*(\d{0,6})\s*$/i.exec(s); const ext = m ? m[1] : '';
  let main = (m ? s.slice(0, m.index) : s).replace(/\D/g, ''); if (main.length === 11 && main.startsWith('1')) main = main.slice(1);
  return { main: main.slice(0, 10), ext };
}
export function formatPhone(v: string): string {
  const raw = String(v || ''); const wantsExt = /(?:ext\.?|x|#)/i.test(raw); const { main: d, ext } = phoneDigits(raw); if (!d) return wantsExt ? raw : '';
  let out = d.length < 4 ? `(${d}` : d.length < 7 ? `(${d.slice(0, 3)}) ${d.slice(3)}` : `(${d.slice(0, 3)}) ${d.slice(3, 6)}-${d.slice(6)}`;
  if (wantsExt) out += ` ext. ${ext}`; return out;
}
/** E.164 for storage/texting: +1XXXXXXXXXX (US/Canada). Returns '' when incomplete. */
export function toE164(v: string): string { const { main, ext } = phoneDigits(v); if (main.length !== 10) return ''; return `+1${main}${ext ? `;ext=${ext}` : ''}`; }
export function fromE164(v: string): string { const m = /^\+1(\d{10})(?:;ext=(\d+))?$/.exec(String(v || '')); return m ? formatPhone(m[1] + (m[2] ? ` ext ${m[2]}` : '')) : v; }
export const phoneComplete = (v: string) => { const d = phoneDigits(v).main; return !d || d.length === 10; };

/** Which inputs count as phone fields: type=tel, or a name/id/label/placeholder/test id that says phone, mobile, cell or fax. */
export function isPhoneField(el: Element | null): el is HTMLInputElement {
  if (!el || el.tagName !== 'INPUT') return false; const i = el as HTMLInputElement; if (i.type === 'tel') return true;
  if (i.type && !['text', 'search', ''].includes(i.type)) return false; if (i.dataset.nophone === '1') return false;
  const hint = [i.name, i.id, i.getAttribute('aria-label'), i.placeholder, i.dataset.testid, i.autocomplete].join(' ');
  if (/\(\d{3}\)\s*\d{3}-\d{4}/.test(i.placeholder || '')) return true;
  const lab = (i.closest('label')?.textContent || i.parentElement?.parentElement?.querySelector('label,span')?.textContent || '').slice(0, 40);
  return (/\b(phone|mobile|cell|fax|tel)\b|phone|mobile/i.test(hint) && !/email|e-mail|name|search|find/i.test(hint)) || (/\b(phone|mobile|cell|fax)\b/i.test(lab) && !/email/i.test(lab));
}
const nativeSet = typeof window !== 'undefined' ? Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value')!.set! : null;
function apply(i: HTMLInputElement) {
  const before = i.value; const next = formatPhone(before); if (next === before) return;
  nativeSet!.call(i, next); i.dispatchEvent(new Event('input', { bubbles: true }));
  try { i.setSelectionRange(next.length, next.length); } catch { /* */ }
}
function warn(i: HTMLInputElement) {
  const ok = phoneComplete(i.value); i.classList.toggle('v10-phone-warn', !ok); i.title = ok ? '' : 'This phone number looks incomplete: (310) 555-1234';
  let hint = i.nextElementSibling as HTMLElement | null; if (hint && !hint.classList.contains('v10-phone-hint')) hint = null;
  if (!ok && !hint) { hint = document.createElement('span'); hint.className = 'v10-phone-hint'; hint.setAttribute('role', 'status'); hint.textContent = 'Phone number looks incomplete'; i.insertAdjacentElement('afterend', hint); }
  if (ok && hint) hint.remove();
}
let installed = false;
export function installPhoneFields() {
  if (installed || typeof document === 'undefined') return; installed = true;
  document.addEventListener('input', e => { const t = e.target as Element; if (!isPhoneField(t) || (e as any).__v10) return; if ((e as InputEvent).inputType === 'deleteContentBackward') return; (e as any).__v10 = 1; apply(t); }, true);
  document.addEventListener('focusin', e => { const t = e.target as Element; if (isPhoneField(t)) { if (t.type !== 'tel') t.setAttribute('inputmode', 'tel'); if (!t.placeholder || !/^e\.g\./i.test(t.placeholder)) t.placeholder = 'e.g. (310) 555-1234'; } }, true);
  document.addEventListener('focusout', e => { const t = e.target as Element; if (isPhoneField(t)) { apply(t); warn(t); } }, true);
}
