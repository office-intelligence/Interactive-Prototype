/* ASC.Vityls v10 · fixes for the v9.1 issues Kevin listed, plus the formal op report pending state. */
import { DictateMic } from './native103';
import { use81 } from '../asc81/store81';
import React from 'react';
import { Clock } from 'lucide-react';
import * as A from '../asc8/logic';
import * as D86 from '../asc86/store86';
import * as P86 from '../asc86/pure86';
import { useMedTick } from '../../med/ui';
/** ASC never e-prescribes (Medical and Surgery.Vityls will). */
export const RX_LINE = 'To be done by the operating surgeon';
/** PACU orders are the standard anesthesia library form (v8.6 order sets): signed = an active signed version exists. */
export function pacuOrdersSigned(cid: string): boolean { const s = D86.orderSet(cid, 'pacu'); return !!s && !!P86.activeVersion(s) && !!P86.activeVersion(s)!.signed; }
/** The formal op report arrives from the outside dictation service days later. Until then the case shows this state. */
export const formalOpReceived = (cid: string) => !!D86.opReceipt(cid).received;
export const FormalOpPending: React.FC<{ c: A.AscCase }> = ({ c }) => { useMedTick(); const r = D86.opReceipt(c.id);
  return r.received ? <div className="vt-alert vt-alert--success" data-testid="v10-formal-op-received"><Clock aria-hidden="true" /><div><span className="vt-alert__title">Formal op report received</span>via {r.received.via}</div></div>
    : <div className="vt-alert vt-alert--info" data-testid="v10-formal-op-pending"><Clock aria-hidden="true" /><div><span className="vt-alert__title">Formal op report pending</span>It arrives from the outside dictation service. Medical records marks it received in Follow-up.<FormalOpDictate c={c} /></div></div>; };
/** v10.3 · formal op report dictation (simulated; for the mobile app later). Saved as a draft dictation on the case. */
const FormalOpDictate: React.FC<{ c: A.AscCase }> = ({ c }) => { const s = use81(); const d = (s.ai(c.id) as any).v103opDict as { text: string; at: string } | undefined;
  return <div style={{ marginTop: 8 }} data-testid="v103-formal-dict"><DictateMic testId="v103-op-mic" label="Dictate formal op report" sample={`Operative report. Procedure: ${c.procedure}. Indications: as documented in the H and P. Description: the patient was brought to the operating room, time-out performed, standard approach, closed in layers, sterile dressing applied. Complications: none. Condition: stable to PACU.`} onText={t => s.setAi(c.id, a => ({ ...a, v103opDict: { text: t, at: new Date().toISOString() } } as any))} />
    {d && <div className="sv-small" data-testid="v103-formal-dict-saved" style={{ marginTop: 6 }}><b>Dictation draft saved</b> {new Date(d.at).toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' })}. It is kept with the case for the formal op report (the mobile app will send it to dictation later). Simulated in this build.</div>}</div>; };
/* OR screen: one time bar (OrTimes89); the brief op report and the paper anesthesia record have their own cards.
 * PACU: Aldrete is scored once, in the PACU Recovery Record. */
export const V10_SHOWN_ELSEWHERE = ['events', 'opReport', 'intraop', 'aldrete'];
import { repo } from '../../v6/dataLayer';
import * as S from '../asc8/store';
import { useActor } from '../../med/ui';
import { uploads } from '../asc87/store87';
import { CaptureUpload } from './flow10';
export const PaperAnesRecord: React.FC<{ c: A.AscCase }> = ({ c }) => { useMedTick(); const [actor] = useActor(); const on = uploads(c.id).some(u => /anesth/i.test(u.type + ' ' + u.name)) || !!c.d.intraop;
  return <section className="v10-card" data-testid="v10-paper-anes"><h3 className="v10-h">Intra-op anesthesia record <span className={`v10-chip ${on ? 'ok' : 'warn'}`}>{on ? 'On file' : 'Paper · scan when done'}</span></h3>
    <p className="v10-sub">The intra-op anesthesia record stays on paper. Scan it in and it files to this case.</p>
    <div className="v10-row" style={{ marginTop: 8 }}><span className="sv-small sv-muted">Scan it with Capture / Upload at the top right.</span>{!c.d.intraop && <button type="button" className="a8-btn" onClick={() => S.setValue(S.caseById(c.id)!, 'intraop', { by: actor.name, at: new Date().toISOString(), paper: true }, actor.name, actor.role, 'Paper anesthesia record scanned and filed')} data-testid="v10-paper-anes-done">Mark scanned</button>}</div></section>; };
const aldreteFromRecord = (c: A.AscCase): number | null => { const v: Record<string, any> = repo.getForm(c.visitId, 'PACU_Recovery_Record.html').values || {}; const hit = Object.entries(v).filter(([k, x]) => /aldrete|total.?score/i.test(k) && String(x).trim() !== '' && !isNaN(Number(x))).map(([, x]) => Number(x)); return hit.length ? hit[hit.length - 1] : null; };
export const AldreteOnce: React.FC<{ c: A.AscCase }> = ({ c }) => { useMedTick(); const [actor] = useActor(); const sc = aldreteFromRecord(c) ?? (c.d.aldrete ? Number(c.d.aldrete.score ?? c.d.aldrete) : null);
  React.useEffect(() => { if (sc !== null && sc >= 9 && !A.isDone(c, 'aldrete')) S.setValue(c, 'aldrete', { score: sc }, actor.name, actor.role, `Aldrete ${sc} (from the PACU Recovery Record)`); }, [sc]);
  return <div className={`v10-li ${sc !== null && sc >= 9 ? 'done' : 'miss'}`} data-testid="v10-aldrete">Aldrete is scored once, in the PACU Recovery Record{sc !== null ? ` · latest ${sc} of 10` : ' · not scored yet'}</div>; };
