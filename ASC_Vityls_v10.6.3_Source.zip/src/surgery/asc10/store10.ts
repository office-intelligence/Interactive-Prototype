/* ASC.Vityls v10 · storage for the frozen workflow (browser storage today; Henry: tables noted per block).
 *  - history:        case_history (one official medical history per case; confirmed once with PIN; amendments with reason)
 *  - surgeon lists:  surgeon_order_list (+ version) — one standard pre-op and one post-op checklist per surgeon
 *  - case lists:     case_order_list (snapshot of the surgeon's lists when the case reaches nursing; ticks + one-off orders)
 *  - brief op report: case_brief_op (circulating RN writes, surgeon PIN-signs before leaving)
 *  - formal op report pending/received stays in asc86 opReceipt. */
import { repo } from '../../v6/dataLayer';
import { svRead, svWrite } from '../store';
const bump = () => window.dispatchEvent(new Event('vityls-med-updated'));
const aud = (cid: string, by: string, role: string, detail: string) => repo.audit({ caseId: `asc8:${cid}`, user: by, role, action: 'asc10.flow' as any, detail });
export interface Stamp { by: string; role: string; at: string }
export const stamp = (by: string, role: string): Stamp => ({ by, role, at: new Date().toISOString() });

/* ---------- Verify medical history ---------- */
export interface HistoryFields { allergies: string; meds: string; conditions: string; surgical: string; anesthesia: string; notes: string }
export interface HistoryRec extends HistoryFields { confirmed?: Stamp; amendments: (Stamp & { reason: string; before: HistoryFields })[]; draftedBy?: string }
export const HISTORY_LABEL: Record<keyof HistoryFields, string> = { allergies: 'Allergies', meds: 'Medications', conditions: 'Medical conditions', surgical: 'Surgical history', anesthesia: 'Anesthesia history', notes: 'Other notes' };
export const historyOf = (cid: string): HistoryRec | undefined => svRead<Record<string, HistoryRec>>('asc10-history', {})[cid];
export function saveHistory(cid: string, h: HistoryRec, by: string, role: string, what: string) { svWrite('asc10-history', { ...svRead<Record<string, HistoryRec>>('asc10-history', {}), [cid]: h }); aud(cid, by, role, what); bump(); }
export const historyVerified = (cid: string) => !!historyOf(cid)?.confirmed;

/* ---------- Surgeon standing lists ---------- */
export type Phase = 'pre' | 'post';
export interface ListItem { id: string; text: string; oneOff?: boolean; addedBy?: string; addedAt?: string }
export interface SurgeonList { surgeon: string; phase: Phase; version: number; items: ListItem[]; updatedBy: string; updatedAt: string }
/* v10.2: the facility's standard orders (Kevin's form-library PACU & Post Anesthesia Orders) apply to every surgeon unless the
 * surgeon saves their own version. Pre-op items are the facility's standard pre-op orders. For Medical Director approval. */
export const FACILITY_PRE: string[] = [
  'Surgical antibiotic prophylaxis within 60 min before incision: Cefazolin 2 g IV once (Clindamycin 900 mg IV if beta-lactam allergy)',
  'Pre-emptive analgesia: Acetaminophen 1000 mg PO once',
  'PONV prophylaxis for high-risk patients: Scopolamine 1.5 mg transdermal patch',
  'Sequential compression devices on before induction',
  'Fingerstick glucose on arrival for diabetic patients',
  'Confirm NPO, site marking and ride home with the patient',
];
export const FACILITY_POST: string[] = [
  'Vital signs: monitor BP, HR, RR and SpO₂ every 15 minutes from arrival through Phase I recovery',
  'Oxygenation: titrate oxygen by nasal cannula to keep SpO₂ > 92% (if SpO₂ drops below 92% on room air)',
  'Pain: Fentanyl 25 mcg IV, repeat in 10 min × 4 PRN pain',
  'Pain: Hydromorphone 1 mg IV, repeat in 20 min × 2 PRN pain',
  'Pain: Ketorolac 30 mg IV, repeat in 10 min × 2 PRN pain',
  'Pain: Acetaminophen 1000 mg IV / PO',
  'Severe pain (7/10): Fentanyl 25–50 mcg IV every 10 minutes (max 150 mcg)',
  'Nausea: Ondansetron (Zofran) 4 mg IV once for nausea or vomiting',
  'Nausea: Promethazine 12.5 mg IV',
  'Nausea: Metoclopramide 10 mg IV',
  'Nausea: Dexamethasone 4 mg IV',
  'Hypothermia: forced-air warming blanket if core temperature is below 36 °C (96.8 °F)',
  'IV fluids: Lactated Ringer’s or Normal Saline at 100 mL/hr until oral intake resumes',
  'Discharge readiness: Modified Aldrete score every 30 minutes until ≥ 9',
  'Notify the physician for abnormal vital signs, SpO₂ below target, fever, or pain or nausea not controlled by the orders above',
];
export const facilityList = (phase: Phase): ListItem[] => (phase === 'pre' ? FACILITY_PRE : FACILITY_POST).map((text, i) => ({ id: `std-${phase}${i}`, text }));
export const surgeonLists = (): SurgeonList[] => svRead<SurgeonList[] | null>('asc10-surgeon-lists', null) ?? [];
/** A surgeon's own saved list, or the facility standard (version 0) when they have not edited theirs. */
export const surgeonList = (surgeon: string, phase: Phase): SurgeonList => surgeonLists().find(l => l.surgeon === surgeon && l.phase === phase)
  || { surgeon, phase, version: 0, items: facilityList(phase), updatedBy: 'Facility standard', updatedAt: '' };
export const usesFacilityStandard = (surgeon: string, phase: Phase) => !surgeonLists().some(l => l.surgeon === surgeon && l.phase === phase);
export function saveSurgeonList(surgeon: string, phase: Phase, items: ListItem[], by: string, role: string) {
  const cur = surgeonList(surgeon, phase); const n: SurgeonList = { surgeon, phase, items, version: (cur?.version || 0) + 1, updatedBy: by, updatedAt: new Date().toISOString() };
  svWrite('asc10-surgeon-lists', [...surgeonLists().filter(l => !(l.surgeon === surgeon && l.phase === phase)), n]);
  repo.audit({ caseId: 'practice', user: by, role, action: 'asc10.list' as any, detail: `${surgeon} · standard ${phase === 'pre' ? 'pre-op' : 'post-op'} list v${n.version} saved (${items.length} items). Applies to cases that have not reached nursing.` }); bump();
}

/* ---------- Case snapshot of the lists (taken when the case reaches nursing; in-progress cases keep their version) ---------- */
export interface Tick { at: string; time: string; initials: string; by: string }
export interface CaseList { phase: Phase; version: number; items: ListItem[]; ticks: Record<string, Tick>; takenAt: string }
const caseLists = () => svRead<Record<string, Partial<Record<Phase, CaseList>>>>('asc10-case-lists', {});
export const caseList = (cid: string, phase: Phase): CaseList | undefined => caseLists()[cid]?.[phase];
const putCaseList = (cid: string, phase: Phase, l: CaseList) => { const all = caseLists(); svWrite('asc10-case-lists', { ...all, [cid]: { ...(all[cid] || {}), [phase]: l } }); bump(); };
/** Live (not yet snapshotted) view: the surgeon's current list. */
export function viewList(cid: string, surgeon: string, phase: Phase): CaseList { const s = caseList(cid, phase); if (s) return s; const l = surgeonList(surgeon, phase); return { phase, version: l?.version || 0, items: l?.items || [], ticks: {}, takenAt: '' }; }
export function snapshotLists(cid: string, surgeon: string) { (['pre', 'post'] as Phase[]).forEach(p => { if (!caseList(cid, p)) { const l = surgeonList(surgeon, p); putCaseList(cid, p, { phase: p, version: l?.version || 0, items: l?.items || [], ticks: {}, takenAt: new Date().toISOString() }); } }); }
export const initials = (name: string) => name.replace(/\(.*?\)|,.*$/g, '').trim().split(/\s+/).filter(Boolean).map(w => w[0].toUpperCase()).join('').slice(0, 3);
export const clock = () => new Date().toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' });
export function tickItem(cid: string, surgeon: string, phase: Phase, id: string, on: boolean, by: string, role: string) {
  snapshotLists(cid, surgeon); const l = caseList(cid, phase)!; const ticks = { ...l.ticks }; const it = l.items.find(i => i.id === id);
  if (on) ticks[id] = { at: new Date().toISOString(), time: clock(), initials: initials(by), by }; else delete ticks[id];
  putCaseList(cid, phase, { ...l, ticks }); aud(cid, by, role, `${phase === 'pre' ? 'Pre-op' : 'Post-op'} order ${on ? 'done' : 'un-ticked'}: ${it?.text || id}`);
}
export function addOneOff(cid: string, surgeon: string, phase: Phase, text: string, by: string, role: string) {
  snapshotLists(cid, surgeon); const l = caseList(cid, phase)!; const it: ListItem = { id: `once-${Date.now().toString(36)}`, text, oneOff: true, addedBy: by, addedAt: new Date().toISOString() };
  putCaseList(cid, phase, { ...l, items: [...l.items, it] }); aud(cid, by, role, `One-off ${phase === 'pre' ? 'pre-op' : 'post-op'} order added: ${text}`);
}

/* ---------- Brief OP report (OR circulating nurse writes; surgeon PIN-signs) ---------- */
export interface BriefOp { pre: string; post: string; procedure: string; findings: string; ebl: string; specimens: string; implants: string; complications: string; condition: string; writtenBy?: Stamp; signed?: Stamp }
export const BRIEF_FIELDS: [keyof BriefOp, string, string][] = [['pre', 'Pre-op diagnosis', 'e.g. Carpal tunnel syndrome, right'], ['post', 'Post-op diagnosis', 'e.g. Same'], ['procedure', 'Procedure performed', 'e.g. Carpal tunnel release, right'], ['findings', 'Findings', 'e.g. Thickened transverse carpal ligament'], ['ebl', 'Estimated blood loss', 'e.g. 10 mL'], ['specimens', 'Specimens', 'e.g. None'], ['implants', 'Implants', 'e.g. None'], ['complications', 'Complications', 'e.g. None'], ['condition', 'Condition to PACU', 'e.g. Stable']];
export const briefOp = (cid: string): BriefOp | undefined => svRead<Record<string, BriefOp>>('asc10-briefop', {})[cid];
export function saveBriefOp(cid: string, b: BriefOp, by: string, role: string, what: string) { svWrite('asc10-briefop', { ...svRead<Record<string, BriefOp>>('asc10-briefop', {}), [cid]: b }); aud(cid, by, role, what); bump(); }

/* ---------- optional follow-ups (both kept, both optional) ---------- */
export interface FollowPrefs { text: boolean; call: boolean }
export const followPrefs = (cid: string): FollowPrefs => svRead<Record<string, FollowPrefs>>('asc10-follow', {})[cid] || { text: true, call: true };
export function setFollowPrefs(cid: string, p: FollowPrefs, by: string, role: string) { svWrite('asc10-follow', { ...svRead<Record<string, FollowPrefs>>('asc10-follow', {}), [cid]: p }); aud(cid, by, role, `Follow-up: next-day text ${p.text ? 'on' : 'off'} · Day-2 call ${p.call ? 'on' : 'off'}`); bump(); }
