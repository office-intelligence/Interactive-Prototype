/* Surgery.Vityls v0.4 · Practice access PIN gate (see practiceLock.ts). */
import React, { useEffect, useRef, useState } from 'react';
import { Lock } from 'lucide-react';
import { repo } from '../v6/dataLayer';
import { useActor } from '../med/ui';
import { PinSign } from './sign';
import { useSv } from './ui';
import { PRACTICE_ROLES, unlockPractice } from './practiceLock';

export const PracticeGate: React.FC = () => {
  const [actor] = useActor(); const { setTab, toast } = useSv(); const [ask, setAsk] = useState(true); const logged = useRef(false);
  useEffect(() => { if (logged.current) return; logged.current = true; repo.audit({ caseId: 'practice', user: actor.name, role: actor.role, action: 'practice.denied', detail: `Practice is locked; access PIN requested (tablet session: ${actor.name})` }); }, [actor.name, actor.role]);
  return <div className="sv-page" data-testid="practice-gate">
    <div className="sv-lock" style={{ maxWidth: 640 }}><Lock size={20} /><div>
      <b className="text-[15px]">Practice is locked</b>
      <p className="text-[13.5px] mt-1">Staff, settings, fees, forms and reports need the access PIN of a practice manager, practice administrator or provider. The visit workflow, charts, photos and payments stay open to everyone on this tablet.</p>
      <p className="sv-small sv-muted mt-1">Tablet session: {actor.name} ({actor.role}). Practice re-locks when you leave it, after 5 minutes without activity, or when you press Lock.</p>
      <div className="flex gap-2 mt-3"><button type="button" className="sv-btn primary" onClick={() => setAsk(true)} data-testid="practice-unlock">Enter access PIN</button><button type="button" className="sv-btn" onClick={() => setTab('home')}>Back to today</button></div>
    </div></div>
    {ask && <PinSign title="Open Practice" statement={<>Enter your own PIN to open Practice. Changes you make are recorded under your name.</>} roles={PRACTICE_ROLES} confirmLabel="Unlock" onClose={() => setAsk(false)} onSigned={w => { unlockPractice(w, actor.name); setAsk(false); toast(`Practice unlocked by ${w.name}.`); }} />}
  </div>;
};
