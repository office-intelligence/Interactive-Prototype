/* Surgery.Vityls v1.1 · Surgical Episodes: browser-storage repository (swap point for Henry's API), settings and seed.
   All writes are audited. Fictional data only. */
import { repo } from '../../v6/dataLayer';
import { medRepo, patientKey, uid, isoDay, addDays, ageFrom, MedPatient } from '../../med/record';
import { svRead, svWrite } from '../store';
import { getSettings } from '../../med/settings';
import * as L from './logic';
import { focusOf } from '../cases/focus';

const K = 'episodes';
export const episodeSettings = (): L.EpisodeSettings => ({ ...L.DEFAULT_EPISODE_SETTINGS, ...svRead<Partial<L.EpisodeSettings>>('episode-settings', {}) });
export function saveEpisodeSettings(s: L.EpisodeSettings, by: string, role: string, what: string) { svWrite('episode-settings', s); repo.audit({ caseId: 'practice', user: by, role, action: 'settings.episodes', detail: what }); }

export const episodes = (): L.Episode[] => svRead<L.Episode[]>(K, []);
export const episode = (id: string) => episodes().find(e => e.id === id);
export const episodesFor = (pid: string) => episodes().filter(e => e.patientId === pid).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
/** v1.6: the focused case's episode when staff opened a specific case, else the newest open episode. */
export const activeEpisode = (pid: string) => { const f = focusOf(pid); const l = episodesFor(pid).filter(e => e.stage !== 'closed'); return (f && l.find(e => e.id === f)) || l[0]; };
/** Kevin's rule applies once the patient is booked: the Surgery page becomes the default view. */
export function saveEpisode(e: L.Episode, by: string, role: string, what: string) {
  const all = episodes(); const i = all.findIndex(x => x.id === e.id); const n = L.withStage(e); if (i >= 0) all[i] = n; else all.push(n); svWrite(K, all);
  repo.audit({ caseId: patientKey(e.patientId), user: by, role, action: 'episode.update', detail: `${e.procedure}: ${what}` });
  return n;
}
export const mutate = (id: string, f: (e: L.Episode) => L.Episode, by: string, role: string, what: string) => { const e = episode(id); if (!e) throw new Error('Episode not found'); return saveEpisode(f(e), by, role, what); };

export const conditionsOf = (pid: string) => medRepo.problems(pid).filter(p => p.status === 'active').map(p => p.conditionType as string);
export const pcpOf = (p: MedPatient) => { const c = p.careTeam.find(x => /primary care|internal/i.test(x.role)); return c ? c.name : 'Primary care physician (not on file)'; };
/** Stale-data check for a returning patient (allergies, meds and history are always reconfirmed for a new episode). */
export function staleFor(p: MedPatient, today = isoDay()) {
  const prof = p as MedPatient & { cardsUpdatedAt?: string; formsUpdatedAt?: string; idUpdatedAt?: string };
  const meds = medRepo.meds(p.id).filter(m => m.status === 'active');
  return L.staleItems([
    { label: 'allergies', last: p.allergies.join(', ') || 'none recorded', date: p.allergiesConfirmedAt, always: true },
    { label: 'medications', last: meds.map(m => m.name).join(', ') || 'none recorded', date: meds[0]?.recordedAt, always: true },
    { label: 'medical history', last: `${medRepo.problems(p.id).length} problem(s) on file`, date: medRepo.problems(p.id)[0]?.recordedAt, always: true },
    { label: 'photo ID and insurance cards', last: p.insurance || 'on file', date: prof.cardsUpdatedAt },
    { label: 'registration and history forms', last: 'signed', date: prof.formsUpdatedAt },
  ], today, episodeSettings().staleMonths);
}
export function startEpisode(p: MedPatient, x: { procedure: string; surgeryDate: string; total: number; ascName?: string; quoteId?: string; consultVisitId?: string }, by: string, role: string): L.Episode {
  const s = episodeSettings(); const returning = episodesFor(p.id).some(e => e.stage === 'closed');
  const e = L.buildEpisode({ id: uid('ep'), patientId: p.id, procedure: x.procedure, surgeon: p.primaryProvider, ascName: x.ascName || getSettings().ascName, surgeryDate: x.surgeryDate, bookedOn: isoDay(), createdAt: new Date().toISOString(), createdBy: by,
    totalAmount: x.total, depositAmount: Math.round(x.total * s.depositPct) / 100, age: ageFrom(p.dob), conditions: conditionsOf(p.id), pcp: pcpOf(p), quoteId: x.quoteId, consultVisitId: x.consultVisitId, returning, stale: returning ? staleFor(p) : [] }, s);
  return saveEpisode(e, by, role, `episode started${returning ? ' (returning patient: stale items flagged)' : ''}`);
}

/* ---------------- seed: Mary James (mid pre-op) + a returning patient ---------------- */
export const MARY = 'MED-2055', CAROL = 'MED-2058';
export function ensureEpisodeSeed() {
  if (svRead<boolean>('episodes-seeded-v11', false)) return;
  const T = isoDay(); const iso = (d: number, h = '10:00') => new Date(`${addDays(T, d)}T${h}:00`).toISOString(); const PATEL = 'Sam Patel, MD'; const ASC = getSettings().ascName || 'Harborview Surgery Center (fictional)';
  const pcp = { name: 'Elena Marsh, MD (fictional)', role: 'Primary care (outside)', phone: '(555) 014-7700' };
  const mk = (id: string, name: string, dob: string, extra: Record<string, unknown>) => { if (!medRepo.patient(id)) medRepo.savePatient({ id, name, dob, sex: 'Female', phone: '(555) 014-' + id.slice(-4), email: name.toLowerCase().replace(' ', '.') + '@example.test', language: 'English', allergies: ['Sulfa (rash)'], allergiesConfirmedAt: iso(-20), allergiesConfirmedBy: 'Casey Morgan, RN', primaryProvider: PATEL, careTeam: [{ name: PATEL, role: 'Surgeon' }, pcp], insurance: 'Self-pay (cosmetic)', fictional: true, ...extra } as MedPatient); };
  const dob = (age: number, md = '03/14') => `${md}/${new Date().getFullYear() - age - (new Date() < new Date(`${new Date().getFullYear()}-${md.slice(0, 2)}-${md.slice(3)}`) ? 1 : 0)}`;
  mk(MARY, 'Mary James', dob(55), { firstName: 'Mary', lastName: 'James', paymentType: 'Self-pay', referralSource: 'Google search', cardsUpdatedAt: iso(-20), formsUpdatedAt: iso(-21) });
  mk(CAROL, 'Carol Bennett', dob(61, '07/02'), { firstName: 'Carol', lastName: 'Bennett', paymentType: 'Self-pay', referralSource: 'Returning patient', allergiesConfirmedAt: iso(-760), cardsUpdatedAt: iso(-760), formsUpdatedAt: iso(-760) });
  const prob = (pid: string, id: string, d: string, c: string, ago: number) => medRepo.saveProblem({ id, patientId: pid, description: d, conditionType: c as any, status: 'active', recordedAt: iso(-ago), recordedBy: 'Fictional seed', source: 'Medical History form (portal)' }, 'Fictional seed');
  const med = (pid: string, id: string, n: string, dose: string, ago: number) => medRepo.saveMed({ id, patientId: pid, name: n, dose, frequency: 'daily', status: 'active', problemIds: [], source: 'Medical History form (portal)', recordedAt: iso(-ago), recordedBy: 'Fictional seed' }, 'Fictional seed');
  prob(MARY, 'pr-mj1', 'Hypertension', 'hypertension', 21); prob(MARY, 'pr-mj2', 'Type 2 diabetes', 'diabetes', 21); med(MARY, 'md-mj1', 'Lisinopril', '10 mg', 21); med(MARY, 'md-mj2', 'Metformin', '500 mg', 21);
  prob(CAROL, 'pr-cb1', 'Hypothyroidism', 'thyroid', 760); med(CAROL, 'md-cb1', 'Levothyroxine', '75 mcg', 760);
  const cv = `ep-consult-${MARY}`; if (!medRepo.visit(cv)) { medRepo.saveVisit({ id: cv, patientId: MARY, date: addDays(T, -18), time: '10:00 AM', durationMin: 30, provider: PATEL, room: 'Exam 1', visitType: 'New patient consultation', reason: 'Rhinoplasty consultation', step: 'complete', problemIds: [], createdAt: iso(-25), createdBy: 'Front Desk Tester' }); medRepo.addVitals({ id: 'vit-mj1', patientId: MARY, visitId: cv, at: iso(-18), by: 'Casey Morgan, RN', source: 'manual', bpSys: 138, bpDia: 86, hr: 76, rr: 14, spo2: 98, heightIn: 64, weightLb: 158 }); }
  const s = episodeSettings(); const by = 'Riley Shaw', at = iso(-18, '11:00');
  let m = L.buildEpisode({ id: 'ep-mary', patientId: MARY, procedure: 'Rhinoplasty (open)', surgeon: PATEL, ascName: ASC, surgeryDate: addDays(T, 16), surgeryTime: '07:30 AM', bookedOn: addDays(T, -18), createdAt: at, createdBy: by, totalAmount: 9800, depositAmount: 2450, age: 55, conditions: ['hypertension', 'diabetes'], pcp: pcp.name, consultVisitId: cv }, s);
  m = L.setItem(m, 'forms', 'done', 'Front Desk Tester', iso(-19)); m = L.setItem(m, 'quote', 'done', by, at, 'Quote accepted · $9,800');
  m = L.applyPayment(m, 2450, 'Taylor Brooks', iso(-17)); m = L.decideClearance(m, true, PATEL, iso(-18, '10:40'));
  m = L.requestClearance(m, 'Casey Morgan, RN', iso(-16)); m = L.receiveTests(m, ['CBC', 'CMP', 'UA', 'PT', 'PTT', 'CXR'], 'Front Desk Tester', iso(-3));
  m = { ...m, clearance: { ...m.clearance, suggested: [] } };
  const c0 = L.buildEpisode({ id: 'ep-carol-1', patientId: CAROL, procedure: 'Upper blepharoplasty', surgeon: PATEL, ascName: ASC, surgeryDate: addDays(T, -730), bookedOn: addDays(T, -760), createdAt: iso(-760), createdBy: by, totalAmount: 4200, depositAmount: 1050, age: 59, conditions: ['thyroid'], pcp: pcp.name }, s);
  let c1 = c0; c0.items.forEach(i => { if (L.isOpen(i)) c1 = L.setItem(c1, i.key, 'done', 'Fictional seed', iso(-640)); }); c1 = { ...c1, paid: 4200, closedAt: iso(-640), stage: 'closed' };
  svWrite(K, [m, c1]);
  const cp = medRepo.patient(CAROL)!; let c2 = L.buildEpisode({ id: 'ep-carol-2', patientId: CAROL, procedure: 'Facelift / necklift', surgeon: PATEL, ascName: ASC, surgeryDate: addDays(T, 45), bookedOn: T, createdAt: iso(-1), createdBy: by, totalAmount: 16500, depositAmount: 4125, age: ageFrom(cp.dob), conditions: ['thyroid'], pcp: pcp.name, returning: true, stale: staleFor(cp, T) }, s);
  c2 = L.setItem(c2, 'quote', 'done', by, iso(-1), 'Quote accepted · $16,500');
  svWrite(K, [m, c1, c2]); svWrite('episodes-seeded-v11', true);
}
