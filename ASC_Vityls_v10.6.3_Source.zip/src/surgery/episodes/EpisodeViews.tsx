/*
 * Surgery.Vityls v1.1 · Surgeries page (board / list by stage) and the patient Surgery page (episode view).
 * Kevin's rule: once a patient is booked, show ONLY what still needs to be done. Done items go to the collapsed History.
 * Tablet-first: generous spacing, 44px touch targets, 3px corners, no thick left borders, Nightingale green accent.
 */
import React, { useMemo, useRef, useState } from 'react';
import { ChevronDown, ClipboardList, FileText, Sparkles, X } from 'lucide-react';
import { medRepo, MedPatient, isoDay, usDate, ageFrom, uid, fmtDateTime } from '../../med/record';
import { useActor, useMedTick } from '../../med/ui';
import { visitTypeDef } from '../store';
import { PinSign } from '../sign';
import { ROLE_GROUP } from '../staff';
import { collectPayment } from '../payments';
import { useSv } from '../ui';
import * as L from './logic';
import { episodes, activeEpisode, episodesFor, mutate, episodeSettings, startEpisode } from './store';
import * as N from './nightingale';
import './episodes.css';

const today = () => isoDay();
const dd = (iso: string) => usDate(iso).slice(0, 5);
const dueText = (i: L.EpisodeItem, T: string) => { const n = L.daysBetween(T, i.due); return n < 0 ? `${-n} day${n === -1 ? '' : 's'} overdue` : n === 0 ? 'due today' : `due ${dd(i.due)} · in ${n} day${n === 1 ? '' : 's'}`; };
export const Dot: React.FC<{ s: L.DueState }> = ({ s }) => <span className={`ep-dot ${s}`} aria-label={s === 'overdue' ? 'overdue' : s === 'soon' ? 'due soon' : 'on track'} />;
const worst = (items: L.EpisodeItem[], T: string): L.DueState => items.some(i => L.dueState(i, T) === 'overdue') ? 'overdue' : items.some(i => L.dueState(i, T) === 'soon') ? 'soon' : 'ok';
const OWNER_FILTERS: { id: L.Owner | 'all'; label: string }[] = [{ id: 'all', label: 'All' }, { id: 'front', label: 'Front desk' }, { id: 'nurse', label: 'Nurse / coordinator' }, { id: 'surgeon', label: 'Surgeon' }];
const useOwner = (): [L.Owner | 'all', (o: L.Owner | 'all') => void] => { const [actor] = useActor(); const [o, setO] = useState<L.Owner | 'all' | null>(() => (sessionStorage.getItem('ep-owner') as L.Owner | 'all' | null)); return [o ?? L.ROLE_OWNER(actor.role), (x) => { sessionStorage.setItem('ep-owner', x); setO(x); }]; };

/* ---------------- Surgeries page ---------------- */
export const SurgeriesPage: React.FC = () => {
  useMedTick(); const { go } = useSv(); const T = today(); const [owner, setOwner] = useOwner();
  const [view, setView] = useState<'board' | 'list'>(() => (localStorage.getItem('ep-view') as 'board' | 'list') || (window.innerWidth < 1100 ? 'list' : 'board'));
  const setV = (v: 'board' | 'list') => { localStorage.setItem('ep-view', v); setView(v); };
  const list = episodes().filter(e => e.stage !== 'closed' && medRepo.patient(e.patientId)).map(e => { const all = L.nextToDo(e, T); const mine = owner === 'all' ? all : all.filter(i => i.owner === owner); return { e, p: medRepo.patient(e.patientId)!, all, mine }; })
    .sort((a, b) => a.e.surgeryDate.localeCompare(b.e.surgeryDate));
  const cols = L.STAGES.filter(s => s.id !== 'closed');
  const Card: React.FC<{ x: typeof list[number] }> = ({ x }) => { const show = (x.mine.length ? x.mine : x.all).slice(0, 3); const n = L.daysBetween(T, x.e.surgeryDate);
    return <button type="button" className="ep-card" onClick={() => go({ type: 'episode', pid: x.p.id })} data-testid="ep-card" aria-label={`${x.p.name}, ${x.e.procedure}`}>
      <span className="ep-card-h"><Dot s={worst(x.all, T)} /><b>{x.p.name}</b><span className="ep-mute ml-auto">{n >= 0 ? `in ${n}d` : `${-n}d ago`}</span></span>
      <span className="ep-mute">{x.e.procedure} · {dd(x.e.surgeryDate)}</span>
      {show.length ? <ul className="ep-card-items">{show.map(i => <li key={i.id}><Dot s={L.dueState(i, T)} />{i.label}</li>)}</ul> : <span className="ep-mute">Nothing open</span>}
      {x.all.length > show.length && <span className="ep-mute">+{x.all.length - show.length} more{owner !== 'all' && x.mine.length ? ' (others)' : ''}</span>}
    </button>; };
  return <div className="ep-page" data-testid="surgeries-page">
    <header className="ep-head"><div><h1 className="ep-h1">Surgeries</h1><p className="ep-mute">Only what still needs doing. Finished items move to each patient’s history.</p></div>
      <div className="ep-tools">
        <div className="ep-seg" role="group" aria-label="Whose items">{OWNER_FILTERS.map(f => <button key={f.id} type="button" className={owner === f.id ? 'on' : ''} aria-pressed={owner === f.id} onClick={() => setOwner(f.id)} data-testid={`ep-owner-${f.id}`}>{f.label}</button>)}</div>
        <div className="ep-seg" role="group" aria-label="View">{(['board', 'list'] as const).map(v => <button key={v} type="button" className={view === v ? 'on' : ''} aria-pressed={view === v} onClick={() => setV(v)} data-testid={`ep-view-${v}`}>{v === 'board' ? 'Board' : 'List'}</button>)}</div>
      </div></header>
    {list.length === 0 ? <p className="ep-empty">No active surgeries. Start one from a patient’s quote or the Surgery page.</p> : view === 'board' ?
      <div className="ep-board" data-testid="ep-board">{cols.map(c => { const xs = list.filter(x => x.e.stage === c.id); return <section key={c.id} className="ep-col" aria-label={c.label}><h2 className="ep-col-h">{c.label} <span className="ep-mute">{xs.length}</span></h2>{xs.map(x => <Card key={x.e.id} x={x} />)}</section>; })}</div> :
      <div className="ep-list" data-testid="ep-list">{list.map(x => { const nx = (x.mine.length ? x.mine : x.all)[0]; return <button key={x.e.id} type="button" className="ep-row" onClick={() => go({ type: 'episode', pid: x.p.id })} data-testid="ep-row">
        <Dot s={worst(x.all, T)} /><span className="ep-row-n"><b>{x.p.name}</b><span className="ep-mute">{x.e.procedure} · {L.stageLabel(x.e.stage)}</span></span>
        <span className="ep-row-d">{usDate(x.e.surgeryDate)}<span className="ep-mute">{L.daysBetween(T, x.e.surgeryDate)} days</span></span>
        <span className="ep-row-next">{nx ? <>{nx.label}<span className="ep-mute">{dueText(nx, T)}</span></> : <span className="ep-mute">Nothing open</span>}</span>
        <span className="ep-count">{x.all.length}</span></button>; })}</div>}
  </div>;
};

/* ---------------- Patient Surgery page ---------------- */
type Dlg = { kind: 'draft'; d: N.Draft; onOk: () => void } | { kind: 'pay'; item: L.EpisodeItem } | { kind: 'receive' } | { kind: 'review' } | { kind: 'rx' } | { kind: 'close' } | null;
export const EpisodePage: React.FC<{ pid: string }> = ({ pid }) => {
  useMedTick(); const { go, toast } = useSv(); const [actor] = useActor(); const T = today(); const [owner, setOwner] = useOwner(); const [dlg, setDlg] = useState<Dlg>(null);
  const p = medRepo.patient(pid); const ep = activeEpisode(pid) || episodesFor(pid)[0];
  if (!p || !ep) return <div className="ep-page"><p className="ep-empty">No surgical episode for this patient.</p></div>;
  const by = actor.name, role = actor.role;
  const m = (f: (e: L.Episode) => L.Episode, what: string, msg?: string) => { mutate(ep.id, f, by, role, what); if (msg) toast(msg); };
  const done = (i: L.EpisodeItem, note?: string) => m(e => L.setItem(e, i.key, 'done', by, new Date().toISOString(), note), `${i.label}: done`, `${i.label} · done. Moved to history.`);
  const draft = (d: N.Draft, onOk: () => void) => setDlg({ kind: 'draft', d, onOk });
  const next = L.forRole(L.nextToDo(ep, T), owner); const groups = L.groupByOwner(owner === 'all' ? next : next.filter(i => i.owner === owner)); const others = owner === 'all' ? 0 : next.filter(i => i.owner !== owner).length;
  const hist = L.doneItems(ep).filter(i => i.status === 'done' || i.doneAt); const brief = N.episodeBrief(ep, p, T);
  const act = (i: L.EpisodeItem): React.ReactNode => {
    const B = (label: string, f: () => void, primary = true, tid = `ep-act-${i.key}`) => <button type="button" className={`ep-btn ${primary ? 'primary' : ''}`} onClick={f} data-testid={tid}>{label}</button>;
    switch (i.action) {
      case 'collect-deposit': case 'collect-balance': return <>{B(i.action === 'collect-deposit' ? 'Collect deposit' : 'Collect balance', () => setDlg({ kind: 'pay', item: i }))}{B('Draft reminder', () => draft(N.paymentReminder(ep, p, i.action === 'collect-deposit' ? 'deposit' : 'balance'), () => toast('Payment reminder queued (simulated, nothing sent).')), false, `ep-remind-${i.key}`)}</>;
      case 'decide-clearance': return <>{B('Clearance required', () => m(e => L.decideClearance(e, true, by, new Date().toISOString()), 'clearance required', 'Clearance required · request is next.'))}{B('Not required', () => m(e => L.decideClearance(e, false, by, new Date().toISOString()), 'clearance not required', 'Clearance not required.'), false, 'ep-clr-no')}</>;
      case 'send-clearance': return B('Draft request to PCP', () => draft(N.clearanceRequest(ep, p), () => m(e => L.requestClearance(e, by, new Date().toISOString()), 'clearance request sent (simulated)', 'Clearance request sent (simulated). Waiting for the documents.')));
      case 'mark-received': return <>{B('Upload / mark received', () => setDlg({ kind: 'receive' }))}{L.missingTests(ep).length > 0 && ep.clearance.requestedAt && B('Draft chase', () => draft(N.chaseMissing(ep, p, T), () => m(e => ({ ...e, history: [...e.history, { at: new Date().toISOString(), by, what: `Chase sent for ${L.missingTests(e).join(', ')} (simulated)` }] }), 'chase sent', 'Follow-up queued (simulated, nothing sent).')), false, 'ep-chase')}</>;
      case 'surgeon-review': { const ready = !L.isOpen(ep.items.find(x => x.key === 'clr-receive')!); return <button type="button" className="ep-btn primary" disabled={!ready} title={ready ? undefined : 'Waiting for all clearance items'} onClick={() => setDlg({ kind: 'review' })} data-testid={`ep-act-${i.key}`}>{ready ? 'Review & initial (PIN)' : 'Waiting for items'}</button>; }
      case 'send-asc': { const miss = L.ascMissing(ep, ['Surgical consent', 'Medication list']); return B(miss.length ? `Send to ASC (${miss.length} missing)` : 'Send to ASC', () => m(e => L.setItem({ ...e, asc: { ...e.asc, sentAt: new Date().toISOString(), missing: miss } }, 'asc-send', 'done', by, new Date().toISOString(), miss.length ? `sent with ${miss.join(', ')} still missing` : 'complete packet sent'), 'ASC packet sent (simulated)', `Packet sent to ${ep.ascName} (simulated).`)); }
      case 'asc-confirm': return B('Check ASC reply', () => { const miss = L.ascMissing(ep, ['Surgical consent', 'Medication list']); if (!ep.asc.sentAt) { toast('Send the packet to the ASC first.'); return; } if (miss.length) { m(e => ({ ...e, asc: { ...e.asc, missing: miss }, items: e.items.map(x => x.key === 'asc-confirm' ? { ...x, status: 'waiting', note: `ASC says missing: ${miss.join(', ')}` } : x) }), `ASC reply: missing ${miss.join(', ')}`, `${ep.ascName}: missing ${miss.join(', ')} (simulated reply).`); } else m(e => L.setItem({ ...e, asc: { ...e.asc, confirmedAt: new Date().toISOString(), missing: [] } }, 'asc-confirm', 'done', 'ASC (simulated)', new Date().toISOString(), 'ASC confirmed packet complete'), 'ASC confirmed complete', 'ASC confirmed: packet complete.'); });
      case 'send-instructions': return B('Draft instructions', () => draft(N.dayBefore(ep, p), () => done(i, 'day-before reminder scheduled (simulated)')));
      case 'schedule-postop': return B('Book proposed visits', () => { const vt = 'Post-op follow-up'; ep.postOp.forEach(v => { medRepo.saveVisit({ id: uid('visit'), patientId: p.id, date: v.date, time: '09:00 AM', durationMin: visitTypeDef(vt).durationMin, provider: ep.surgeon, room: 'Exam 1', visitType: vt, reason: `POD ${v.pod} after ${ep.procedure}${v.photos ? ' · photo set' : ''}`, step: 'scheduled', problemIds: [], createdAt: new Date().toISOString(), createdBy: by }); }); done(i, `booked ${N.postOpProposal(ep).join('; ')}`); });
      case 'postop-photos': return B('Photo sets done', () => done(i));
      case 'sign-rx': return B('Rx set · sign (PIN)', () => setDlg({ kind: 'rx' }));
      case 'close': return B('Close episode', () => setDlg({ kind: 'close' }));
      case 'reconfirm': return B('Reconfirmed', () => done(i, 'reconfirmed with patient'));
      case 'send-forms': return B('Mark complete', () => done(i));
      default: return B('Mark done', () => done(i));
    }
  };
  const n = L.daysBetween(T, ep.surgeryDate);
  return <div className="ep-page" data-testid="episode-page">
    <header className="ep-head">
      <div className="min-w-0"><div className="ep-mute ep-kicker">Surgery · {L.stageLabel(ep.stage)}{ep.returning ? ' · returning patient' : ''}</div><h1 className="ep-h1" data-testid="ep-name">{p.name}</h1>
        <p className="ep-mute">{ageFrom(p.dob)} y · DOB {p.dob} · {ep.procedure} · {ep.surgeon} · {ep.ascName}</p></div>
      <div className="ep-tools"><div className="ep-when" data-testid="ep-when"><b>{usDate(ep.surgeryDate)}</b><span>{n >= 0 ? `in ${n} days` : `${-n} days ago`}</span></div>
        <button type="button" className="ep-btn" onClick={() => go({ type: 'fullchart', pid })} data-testid="ep-open-chart"><FileText size={16} />Open chart</button></div>
    </header>
    <ol className="ep-stages" aria-label="Stage">{L.STAGES.map(s => <li key={s.id} className={s.id === ep.stage ? 'on' : L.STAGES.findIndex(x => x.id === s.id) < L.STAGES.findIndex(x => x.id === ep.stage) ? 'past' : ''}>{s.label}</li>)}</ol>
    <section className="ep-ng" aria-label="Nightingale" data-testid="ep-nightingale"><div className="ep-ng-h"><Sparkles size={16} /><b>Nightingale</b><span className="ep-mute">simulated · drafts only · staff review everything · never signs, orders or clears</span></div>
      <p>{brief.text}</p>{brief.flags.length > 0 && <ul className="ep-flags" data-testid="ep-flags">{brief.flags.map(f => <li key={f}>{f}</li>)}</ul>}</section>
    <section aria-label="Next to do" data-testid="ep-next">
      <div className="ep-sec-h"><h2 className="ep-h2"><ClipboardList size={18} />Next to do <span className="ep-mute">{next.length}</span></h2>
        <div className="ep-seg" role="group" aria-label="Whose items">{OWNER_FILTERS.map(f => <button key={f.id} type="button" className={owner === f.id ? 'on' : ''} aria-pressed={owner === f.id} onClick={() => setOwner(f.id)} data-testid={`ep-owner-${f.id}`}>{f.label}</button>)}</div></div>
      {next.length === 0 ? <p className="ep-empty" data-testid="ep-nothing">Nothing to do right now.</p> : groups.map(g => <div key={g.owner} className="ep-group" data-testid={`ep-group-${g.owner}`}><h3 className="ep-h3">{L.OWNER_LABEL[g.owner]}</h3>
        {g.items.map(i => <div key={i.id} className="ep-item" data-testid="ep-item" data-key={i.key}><Dot s={L.dueState(i, T)} />
          <div className="ep-item-t"><b>{i.label}</b><span className="ep-mute">{dueText(i, T)}{i.status === 'waiting' ? ' · waiting' : ''}{i.note ? ` · ${i.note}` : ''}</span>
            {i.key === 'clr-receive' && <span className="ep-tests" data-testid="ep-tests">{Object.entries(ep.clearance.tests).map(([k, v]) => <span key={k} className={`ep-test ${v}`}>{v === 'received' ? '✓ ' : ''}{k}</span>)}</span>}
            {i.key === 'decide-clearance' && ep.clearance.reasons.length > 0 && <span className="ep-mute">Facts: {ep.clearance.reasons.join('; ')}. The practice rule suggests clearance; you decide.</span>}
            {i.key === 'asc-confirm' && ep.asc.missing?.length ? <span className="ep-miss" data-testid="ep-asc-missing">ASC required items missing: {ep.asc.missing.join(', ')}</span> : null}
            {(i.key === 'collect-balance' || i.key === 'balance') && <span className="ep-mute">Balance ${L.balanceDue(ep).toFixed(2)} of ${ep.totalAmount.toFixed(2)}</span>}
            {i.key === 'postop-book' && <span className="ep-mute">Nightingale proposes: {N.postOpProposal(ep).join(' · ')}</span>}
          </div><div className="ep-item-a">{act(i)}</div></div>)}</div>)}
      {others > 0 && <button type="button" className="ep-quiet" onClick={() => setOwner('all')} data-testid="ep-show-all">+ {others} item{others === 1 ? '' : 's'} for other roles · show all</button>}
    </section>
    <details className="ep-hist" data-testid="ep-history"><summary><ChevronDown size={15} />History · {hist.length} done</summary>
      <ol className="ep-tl">{[...ep.history].reverse().map((h, k) => <li key={k}><span className="ep-mute">{fmtDateTime(h.at)} · {h.by}</span>{h.what}</li>)}</ol></details>
    {dlg?.kind === 'draft' && <DraftDialog d={dlg.d} onClose={() => setDlg(null)} onOk={() => { dlg.onOk(); setDlg(null); }} />}
    {dlg?.kind === 'pay' && <PayDialog ep={ep} p={p} item={dlg.item} onClose={() => setDlg(null)} />}
    {dlg?.kind === 'receive' && <ReceiveDialog ep={ep} onClose={() => setDlg(null)} />}
    {dlg?.kind === 'review' && <PinSign title="Surgeon review of the clearance" statement={<>You reviewed the clearance documents for {p.name}. Nightingale does not judge fitness for surgery; this is your review.</>} roles={ROLE_GROUP.provider} confirmLabel="Initial" onClose={() => setDlg(null)} onSigned={s => { mutate(ep.id, e => L.setItem({ ...e, clearance: { ...e.clearance, reviewedBy: s.name } }, 'clr-review', 'done', s.name, s.at, 'initialed with PIN'), s.name, s.role, 'clearance reviewed (PIN)'); setDlg(null); toast(`Clearance reviewed by ${s.name}.`); }} />}
    {dlg?.kind === 'rx' && <RxSetDialog p={p} onClose={() => setDlg(null)} onSigned={(s, txt) => { mutate(ep.id, e => L.setItem(e, 'rx', 'done', s.name, s.at, txt), s.name, s.role, 'post-op Rx signed (simulated eRx)'); setDlg(null); toast(`Post-op prescriptions signed by ${s.name} (simulated eRx).`); }} />}
    {dlg?.kind === 'close' && <Modal title="Close this episode?" onClose={() => setDlg(null)}><p className="text-[14px]">The episode moves to history. No PDF is created; export or print from the chart only if you need one.</p>
      <p className="ep-mute mt-2">Nightingale summary (draft): {p.name} had {ep.procedure.toLowerCase()} on {usDate(ep.surgeryDate)}. {ep.postOp.length} post-op visits planned. Payments ${ep.paid.toFixed(2)} of ${ep.totalAmount.toFixed(2)}.</p>
      <div className="ep-dlg-a"><button type="button" className="ep-btn" onClick={() => setDlg(null)}>Cancel</button><button type="button" className="ep-btn primary" onClick={() => { mutate(ep.id, e => ({ ...L.setItem(e, 'close', 'done', by, new Date().toISOString()), closedAt: new Date().toISOString() }), by, role, 'episode closed (no automatic PDF)'); setDlg(null); toast('Episode closed.'); }} data-testid="ep-close-confirm">Close episode</button></div></Modal>}
  </div>;
};

export const Modal: React.FC<{ title: string; onClose: () => void; children: React.ReactNode; testId?: string }> = ({ title, onClose, children, testId }) =>
  <div className="sv-modal ep-modal" role="dialog" aria-modal="true" aria-label={title} data-testid={testId || 'ep-dialog'} onKeyDown={e => { if (e.key === 'Escape') onClose(); }}>
    <div className="sv-modal-scrim" onClick={onClose} /><div className="sv-modal-box" style={{ width: 'min(640px, 94vw)' }}>
      <div className="ep-dlg-h"><b>{title}</b><button type="button" className="ep-x" onClick={onClose} aria-label="Close"><X size={18} /></button></div>{children}</div></div>;

const DraftDialog: React.FC<{ d: N.Draft; onClose: () => void; onOk: () => void }> = ({ d, onClose, onOk }) => { const [body, setBody] = useState(d.body);
  return <Modal title={d.title} onClose={onClose} testId="ep-draft">
    <div className="ep-ng-tag"><Sparkles size={14} />Draft by Nightingale · review and edit before sending</div>
    <div className="ep-kv"><span>To</span><b data-testid="ep-draft-to">{d.to}</b><span>How</span><b>{d.channel}</b></div>
    <textarea className="sv-input ep-ta" value={body} onChange={e => setBody(e.target.value)} rows={12} data-testid="ep-draft-body" />
    <p className="ep-mute">Simulation: nothing leaves this device until a BAA-covered service is connected.</p>
    <div className="ep-dlg-a"><button type="button" className="ep-btn" onClick={onClose}>Cancel</button><button type="button" className="ep-btn primary" onClick={onOk} data-testid="ep-draft-send">Approve & send (simulated)</button></div></Modal>; };

const PayDialog: React.FC<{ ep: L.Episode; p: MedPatient; item: L.EpisodeItem; onClose: () => void }> = ({ ep, p, item, onClose }) => {
  const [actor] = useActor(); const { toast } = useSv(); const dep = item.key === 'deposit';
  const [amt, setAmt] = useState(String(dep ? Math.max(0, ep.depositAmount - ep.paid) : L.balanceDue(ep))); const [method, setMethod] = useState<'card' | 'cash' | 'check' | 'financing'>('card'); const [err, setErr] = useState('');
  const ok = () => { try { const a = +amt; collectPayment({ patientId: p.id, amount: a, method, reference: '', reason: `${ep.procedure} · ${dep ? 'deposit' : 'balance'}`, takenBy: actor.name, role: actor.role, channel: 'in person' }); mutate(ep.id, e => L.applyPayment(e, a, actor.name, new Date().toISOString()), actor.name, actor.role, `payment $${a.toFixed(2)} (simulated)`); toast(`Payment $${a.toFixed(2)} recorded (simulated, nothing charged).`); onClose(); } catch (e) { setErr((e as Error).message); } };
  return <Modal title={dep ? 'Collect deposit' : 'Collect balance'} onClose={onClose} testId="ep-pay">
    <label className="block mb-3"><span className="sv-label">Amount ($)</span><input className="sv-input ep-in" inputMode="decimal" value={amt} onChange={e => setAmt(e.target.value)} data-testid="ep-pay-amount" /></label>
    <label className="block mb-3"><span className="sv-label">Method</span><select className="sv-input ep-in" value={method} onChange={e => setMethod(e.target.value as typeof method)}><option value="card">Card (simulated)</option><option value="cash">Cash</option><option value="check">Check</option><option value="financing">Patient financing</option></select></label>
    <p className="ep-mute">Total ${ep.totalAmount.toFixed(2)} · paid ${ep.paid.toFixed(2)} · balance due by {usDate(ep.items.find(i => i.key === 'balance')?.due)}</p>
    {err && <p className="text-[13px] text-[var(--crit)]" role="alert">{err}</p>}
    <div className="ep-dlg-a"><button type="button" className="ep-btn" onClick={onClose}>Cancel</button><button type="button" className="ep-btn primary" onClick={ok} data-testid="ep-pay-ok">Record payment</button></div></Modal>;
};

const ReceiveDialog: React.FC<{ ep: L.Episode; onClose: () => void }> = ({ ep, onClose }) => {
  const [actor] = useActor(); const { toast } = useSv(); const file = useRef<HTMLInputElement>(null);
  const open = Object.entries(ep.clearance.tests).filter(([, v]) => v !== 'received').map(([k]) => k);
  const [tick, setTick] = useState<string[]>(ep.clearance.suggested || []); const [note, setNote] = useState('');
  const read = (name: string) => { const r = N.readClearanceDoc(ep, name); setTick(r.found); setNote(r.note); mutate(ep.id, e => ({ ...e, clearance: { ...e.clearance, suggested: r.found }, history: [...e.history, { at: new Date().toISOString(), by: 'Nightingale (simulated)', what: r.note }] }), actor.name, actor.role, `document read (simulated): ${name}`); };
  return <Modal title="Clearance items received" onClose={onClose} testId="ep-receive">
    <div className="flex flex-wrap gap-2 mb-3"><button type="button" className="ep-btn" onClick={() => file.current?.click()} data-testid="ep-upload">Upload document</button><input ref={file} type="file" hidden onChange={e => { const f = e.target.files?.[0]; if (f) read(f.name); }} />
      <button type="button" className="ep-btn" onClick={() => read('PCP_fax_ECG_' + ep.patientId + '.pdf')} data-testid="ep-sample-fax">Use sample incoming fax (ECG)</button></div>
    {note && <div className="ep-ng-tag" data-testid="ep-read-note"><Sparkles size={14} />{note}</div>}
    <div className="ep-checks">{open.map(t => <label key={t} className="ep-check"><input type="checkbox" checked={tick.includes(t)} onChange={e => setTick(e.target.checked ? [...tick, t] : tick.filter(x => x !== t))} data-testid={`ep-rcv-${t}`} />{t}{(ep.clearance.suggested || []).includes(t) && <span className="ep-mute"> · Nightingale found it, please confirm</span>}</label>)}</div>
    <div className="ep-dlg-a"><button type="button" className="ep-btn" onClick={onClose}>Cancel</button><button type="button" className="ep-btn primary" disabled={!tick.length} onClick={() => { mutate(ep.id, e => L.receiveTests(e, tick, actor.name, new Date().toISOString()), actor.name, actor.role, `clearance received: ${tick.join(', ')}`); toast(`Marked received: ${tick.join(', ')}.`); onClose(); }} data-testid="ep-rcv-ok">Confirm received</button></div></Modal>;
};

export const RX_SETS: { id: string; label: string; items: { name: string; dose: string; frequency: string }[] }[] = [
  { id: 'pain-abx', label: 'Pain + antibiotic', items: [{ name: 'Hydrocodone-acetaminophen 5/325 mg', dose: '1 tab', frequency: 'every 6 hours as needed for pain · #12' }, { name: 'Cephalexin 500 mg', dose: '1 cap', frequency: 'four times daily × 5 days' }] },
  { id: 'nonopioid-abx', label: 'Non-opioid pain + antibiotic', items: [{ name: 'Acetaminophen 500 mg', dose: '2 tabs', frequency: 'every 6 hours as needed' }, { name: 'Cephalexin 500 mg', dose: '1 cap', frequency: 'four times daily × 5 days' }] },
  { id: 'pain-abx-pcn', label: 'Pain + antibiotic (penicillin allergy)', items: [{ name: 'Hydrocodone-acetaminophen 5/325 mg', dose: '1 tab', frequency: 'every 6 hours as needed for pain · #12' }, { name: 'Clindamycin 300 mg', dose: '1 cap', frequency: 'three times daily × 5 days' }] },
];
/** Quick post-op prescription sets: a draft until a provider signs with their own PIN (simulated eRx, nothing sent). */
export const RxSetDialog: React.FC<{ p: MedPatient; onClose: () => void; onSigned?: (s: { name: string; role: string; at: string }, text: string) => void }> = ({ p, onClose, onSigned }) => {
  const { toast } = useSv(); const pcn = p.allergies.some(a => /penicillin|cephal/i.test(a)); const [set, setSet] = useState(pcn ? 'pain-abx-pcn' : 'pain-abx'); const [pin, setPin] = useState(false);
  const s = RX_SETS.find(x => x.id === set)!; const text = s.items.map(i => `${i.name} ${i.dose} ${i.frequency}`).join('; ');
  if (pin) return <PinSign title="Sign post-op prescriptions" statement={<>Sign {s.label.toLowerCase()} for {p.name}: {text}. Simulated eRx, nothing is sent.</>} roles={ROLE_GROUP.provider} onClose={() => setPin(false)} onSigned={w => {
    s.items.forEach(i => medRepo.saveMed({ id: uid('med'), patientId: p.id, name: i.name, dose: i.dose, frequency: i.frequency, status: 'active', problemIds: [], source: `Post-op Rx set (signed by ${w.name}, simulated eRx)`, recordedAt: w.at, recordedBy: w.name, startedAt: w.at, simulatedRx: true }, w.name, 'med.add'));
    if (onSigned) onSigned(w, text); else { toast(`Post-op prescriptions signed by ${w.name} (simulated eRx).`); onClose(); } }} />;
  return <Modal title="Post-op prescription set" onClose={onClose} testId="ep-rx">
    <div className="ep-ng-tag"><Sparkles size={14} />Draft · a provider signs with their own PIN. Allergies on file: {p.allergies.join(', ') || 'none recorded'}</div>
    <div className="ep-checks">{RX_SETS.map(x => <label key={x.id} className="ep-check"><input type="radio" name="rxset" checked={set === x.id} onChange={() => setSet(x.id)} data-testid={`ep-rx-${x.id}`} /><span><b>{x.label}</b><span className="ep-mute block">{x.items.map(i => `${i.name} ${i.frequency}`).join(' · ')}</span></span></label>)}</div>
    <div className="ep-dlg-a"><button type="button" className="ep-btn" onClick={onClose}>Cancel</button><button type="button" className="ep-btn primary" onClick={() => setPin(true)} data-testid="ep-rx-sign">Sign with PIN</button></div></Modal>;
};
export const RxSetButton: React.FC<{ p: MedPatient }> = ({ p }) => { const [o, setO] = useState(false); return <><button type="button" className="sv-btn" onClick={() => setO(true)} data-testid="rx-set-open">Post-op Rx set</button>{o && <RxSetDialog p={p} onClose={() => setO(false)} />}</>; };

/* ---------------- Today feed: open episode items that are overdue or due within 3 days ---------------- */
export function episodeAttention(T = today()) {
  return episodes().filter(e => e.stage !== 'closed' && medRepo.patient(e.patientId)).flatMap(e => L.nextToDo(e, T).filter(i => L.dueState(i, T) !== 'ok').map(i => ({ e, i, p: medRepo.patient(e.patientId)!, s: L.dueState(i, T) })));
}
export const useEpisodeSettings = () => useMemo(() => episodeSettings(), []);

/** Start a surgical episode from an accepted quote (or from a patient with no active episode). */
export const StartEpisodeButton: React.FC<{ p: MedPatient; quoteId?: string; procedure?: string; total?: number; className?: string }> = ({ p, quoteId, procedure = '', total = 0, className = 'sv-btn sm primary' }) => {
  const [o, setO] = useState(false); const [actor] = useActor(); const { go, toast } = useSv(); const [f, setF] = useState({ procedure, date: '', total: String(total || '') });
  if (activeEpisode(p.id)) return null;
  return <>{<button type="button" className={className} onClick={() => setO(true)} data-testid="ep-start">Start surgery</button>}
    {o && <Modal title={`Start a surgical episode for ${p.name}`} onClose={() => setO(false)} testId="ep-start-dlg">
      <label className="block mb-3"><span className="sv-label">Procedure</span><input className="sv-input ep-in" value={f.procedure} onChange={e => setF({ ...f, procedure: e.target.value })} data-testid="ep-start-proc" /></label>
      <label className="block mb-3"><span className="sv-label">Surgery date</span><input type="date" className="sv-input ep-in" value={f.date} min={isoDay()} onChange={e => setF({ ...f, date: e.target.value })} data-testid="ep-start-date" /></label>
      <label className="block mb-3"><span className="sv-label">Total ($)</span><input className="sv-input ep-in" inputMode="decimal" value={f.total} onChange={e => setF({ ...f, total: e.target.value })} /></label>
      <p className="ep-mute">The default checklist from Surgery settings is applied: deposit at booking, balance 14 days before, clearance if the practice rule suggests it, ASC packet, day-before instructions and post-op visits.</p>
      <div className="ep-dlg-a"><button type="button" className="ep-btn" onClick={() => setO(false)}>Cancel</button><button type="button" className="ep-btn primary" disabled={!f.procedure.trim() || !f.date} onClick={() => { const e = startEpisode(p, { procedure: f.procedure.trim(), surgeryDate: f.date, total: +f.total || 0, quoteId }, actor.name, actor.role); let x = e; if (quoteId) x = mutate(e.id, y => L.setItem(y, 'quote', 'done', actor.name, new Date().toISOString(), 'quote accepted'), actor.name, actor.role, 'quote accepted'); void x; setO(false); toast(`Surgical episode started for ${p.name}.`); go({ type: 'episode', pid: p.id }); }} data-testid="ep-start-ok">Start episode</button></div></Modal>}</>;
};
