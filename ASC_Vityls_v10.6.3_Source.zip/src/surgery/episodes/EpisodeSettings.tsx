/* Surgery.Vityls v1.1 · Practice settings for surgical episodes: default stage checklists (owner, due date relative to
   surgery/booking), clearance rule, post-op schedule, ASC required items, stale-data limit, day-before instructions. */
import React, { useState } from 'react';
import { useSv } from '../ui';
import * as L from './logic';
import { episodeSettings, saveEpisodeSettings } from './store';

export const EpisodeSettingsSection: React.FC<{ can: boolean; actor: { name: string; role: string } }> = ({ can, actor }) => {
  const { toast } = useSv(); const cur = episodeSettings(); const [s, setS] = useState<L.EpisodeSettings>(cur); const dirty = JSON.stringify(s) !== JSON.stringify(cur);
  const up = (i: number, p: Partial<L.TemplateItem>) => setS({ ...s, template: s.template.map((t, j) => j === i ? { ...t, ...p } : t) });
  const csv = (v: string) => v.split(',').map(x => x.trim()).filter(Boolean);
  const save = () => { saveEpisodeSettings(s, actor.name, actor.role, `Surgical episode settings saved · ${s.template.length} checklist items · clearance rule age ≥ ${s.rule.minAge} or ${s.rule.conditions.join('/')} · post-op days ${s.postOpDays.join('/')} · stale after ${s.staleMonths} months`); toast('Surgical episode settings saved. New episodes use them.'); };
  return <section className="sv-sec mt-8" id="episode-settings" data-testid="episode-settings">
    <h2 className="sv-title" style={{ fontSize: 20 }}>Surgical episodes</h2>
    <p className="text-[13px] sv-muted mb-3">Default checklist for every new surgery, from consult to close. Due dates are days before (−) or after (+) the surgery date or the booking date. Existing episodes keep their own list.</p>
    <div className="overflow-x-auto"><table className="sv-table" data-testid="ep-tpl-table"><thead><tr><th>Stage</th><th>Item</th><th>Owner</th><th>Due (days)</th><th>From</th><th></th></tr></thead><tbody>{s.template.map((t, i) => <tr key={t.key}>
      <td><select className="sv-input" value={t.stage} disabled={!can} onChange={e => up(i, { stage: e.target.value as L.Stage })}>{L.STAGES.filter(x => x.id !== 'closed').map(x => <option key={x.id} value={x.id}>{x.label}</option>)}</select></td>
      <td><input className="sv-input" value={t.label} disabled={!can} onChange={e => up(i, { label: e.target.value })} data-testid={`ep-tpl-label-${t.key}`} /></td>
      <td><select className="sv-input" value={t.owner} disabled={!can} onChange={e => up(i, { owner: e.target.value as L.Owner })}>{(Object.keys(L.OWNER_LABEL) as L.Owner[]).map(o => <option key={o} value={o}>{L.OWNER_LABEL[o]}</option>)}</select></td>
      <td style={{ width: 90 }}><input className="sv-input" inputMode="numeric" value={t.offsetDays} disabled={!can} onChange={e => up(i, { offsetDays: parseInt(e.target.value.replace(/[^\d-]/g, '') || '0', 10) || 0 })} data-testid={`ep-tpl-due-${t.key}`} /></td>
      <td><select className="sv-input" value={t.anchor} disabled={!can} onChange={e => up(i, { anchor: e.target.value as L.Anchor })}><option value="surgery">Surgery date</option><option value="booking">Booking date</option></select></td>
      <td>{can && !['deposit', 'balance', 'clr-request', 'clr-receive', 'clr-review', 'close'].includes(t.key) && <button type="button" className="sv-link text-[12.5px]" onClick={() => setS({ ...s, template: s.template.filter((_, j) => j !== i) })}>Remove</button>}</td></tr>)}</tbody></table></div>
    {can && <button type="button" className="sv-btn sm mt-2" onClick={() => setS({ ...s, template: [...s.template, { key: `custom-${Date.now().toString(36)}`, stage: 'preop', label: 'New checklist item', owner: 'front', anchor: 'surgery', offsetDays: -7, action: 'mark-done' }] })} data-testid="ep-tpl-add">Add checklist item</button>}
    <div className="grid gap-3 mt-4" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(260px, 1fr))' }}>
      <label><span className="sv-label">Clearance suggested at age ≥</span><input className="sv-input" inputMode="numeric" value={s.rule.minAge} disabled={!can} onChange={e => setS({ ...s, rule: { ...s.rule, minAge: +e.target.value.replace(/\D/g, '') || 0 } })} data-testid="ep-rule-age" /></label>
      <label><span className="sv-label">…or any of these conditions (comma-separated)</span><input className="sv-input" value={s.rule.conditions.join(', ')} disabled={!can} onChange={e => setS({ ...s, rule: { ...s.rule, conditions: csv(e.target.value) } })} /></label>
      <label><span className="sv-label">Deposit (% of the quote)</span><input className="sv-input" inputMode="numeric" value={s.depositPct} disabled={!can} onChange={e => setS({ ...s, depositPct: +e.target.value.replace(/\D/g, '') || 0 })} /></label>
      <label><span className="sv-label">Post-op visits (days after surgery)</span><input className="sv-input" value={s.postOpDays.join(', ')} disabled={!can} onChange={e => setS({ ...s, postOpDays: csv(e.target.value).map(Number).filter(n => n > 0) })} data-testid="ep-postop-days" /></label>
      <label><span className="sv-label">ASC required items</span><input className="sv-input" value={s.ascRequired.join(', ')} disabled={!can} onChange={e => setS({ ...s, ascRequired: csv(e.target.value) })} /></label>
      <label><span className="sv-label">Reconfirm data older than (months)</span><input className="sv-input" inputMode="numeric" value={s.staleMonths} disabled={!can} onChange={e => setS({ ...s, staleMonths: +e.target.value.replace(/\D/g, '') || 12 })} /></label>
    </div>
    <label className="block mt-3"><span className="sv-label">Day-before pre-op instructions template ({'{asc}'}, {'{arrive}'})</span><textarea className="sv-input" rows={3} value={s.instructions} disabled={!can} onChange={e => setS({ ...s, instructions: e.target.value })} /></label>
    <p className="text-[12px] sv-muted mt-1">The clearance rule only suggests clearance; the surgeon decides. Nightingale never gives a go / no-go opinion.</p>
    {can && <div className="flex gap-2 mt-2"><button type="button" className="sv-btn sm primary" disabled={!dirty} onClick={save} data-testid="ep-settings-save">Save episode settings</button><button type="button" className="sv-btn sm" onClick={() => setS(L.DEFAULT_EPISODE_SETTINGS)}>Restore defaults</button></div>}
  </section>;
};
