/* Surgery.Vityls v1.1 · Nightingale for surgical episodes (SIMULATED, scripted, on-device).
   Drafts and flags only: staff review every draft before it goes anywhere (and sending is simulated until a BAA).
   Nightingale never signs, never orders, and never says whether a patient is fit for surgery. */
import { MedPatient, medRepo, usDate, ageFrom } from '../../med/record';
import { getSettings } from '../../med/settings';
import * as L from './logic';
import { episodeSettings } from './store';

const first = (n: string) => n.split(/\s+/)[0];
const d = (iso: string) => usDate(iso);
export interface Draft { title: string; to: string; channel: string; body: string }

export function clearanceRequest(ep: L.Episode, p: MedPatient): Draft {
  const meds = medRepo.meds(p.id).filter(m => m.status === 'active').map(m => `${m.name} ${m.dose}`).join(', ') || 'none recorded';
  const probs = medRepo.problems(p.id).filter(x => x.status === 'active').map(x => x.description).join(', ') || 'none recorded';
  const tests = Object.keys(ep.clearance.tests);
  return { title: 'Pre-operative clearance request', to: ep.clearance.pcp, channel: 'Secure email / fax (simulated)',
    body: `Dear ${ep.clearance.pcp.replace(/\s*\(fictional\)/, '')},\n\nOur mutual patient ${p.name} (DOB ${p.dob}) is scheduled for ${ep.procedure} with ${ep.surgeon} at ${ep.ascName} on ${d(ep.surgeryDate)}.\n\nWe would be grateful for a pre-operative evaluation. Please send the following by ${d(L.addDaysIso(ep.surgeryDate, -10))}:\n${tests.map(t => `  ☐ ${L.TEST_LABEL[t] || t}`).join('\n')}\n  ☐ History & physical and your clearance letter\n\nActive problems on our record: ${probs}.\nCurrent medications: ${meds}.\nAllergies: ${p.allergies.join(', ') || 'none recorded'}.\n\nPlease fax or email the documents to ${getSettings().practiceName}. Thank you.\n\n${ep.surgeon}` };
}
export function chaseMissing(ep: L.Episode, p: MedPatient, today: string): Draft {
  const miss = L.missingTests(ep); const days = L.daysBetween(today, ep.surgeryDate);
  return { title: 'Follow-up: missing clearance items', to: ep.clearance.pcp, channel: 'Secure email / fax (simulated)',
    body: `Dear ${ep.clearance.pcp.replace(/\s*\(fictional\)/, '')},\n\nThank you for the documents for ${p.name} (DOB ${p.dob}). We are still missing: ${miss.join(', ') || 'nothing'}.\nSurgery is in ${days} days (${d(ep.surgeryDate)}). Could your office send ${miss.length === 1 ? 'it' : 'them'} at your earliest convenience?\n\nThank you,\n${getSettings().practiceName}` };
}
export function paymentReminder(ep: L.Episode, p: MedPatient, kind: 'deposit' | 'balance'): Draft {
  const amt = kind === 'deposit' ? ep.depositAmount - Math.min(ep.paid, ep.depositAmount) : L.balanceDue(ep); const due = ep.items.find(i => i.key === kind)?.due || '';
  return { title: `Payment reminder (${kind})`, to: `${p.name} · ${p.phone}${p.email ? ` · ${p.email}` : ''}`, channel: 'Text / email (simulated)',
    body: `Hi ${first(p.name)}, this is ${getSettings().practiceName}. A friendly reminder that the ${kind} of $${amt.toFixed(2)} for your ${ep.procedure.toLowerCase()} on ${d(ep.surgeryDate)} is due ${d(due)}. You can pay in your portal or call us. Thank you!` };
}
export function dayBefore(ep: L.Episode, p: MedPatient): Draft {
  const tpl = episodeSettings().instructions.replace('{asc}', ep.ascName).replace('{arrive}', ep.surgeryTime === '07:30 AM' ? '6:00 AM' : `90 minutes before ${ep.surgeryTime}`);
  return { title: 'Day-before reminder and pre-op instructions', to: `${p.name} · ${p.phone}`, channel: 'Text / email (simulated), sent the day before',
    body: `Hi ${first(p.name)}, your ${ep.procedure.toLowerCase()} with ${ep.surgeon} is tomorrow, ${d(ep.surgeryDate)}.\n\n${tpl}\n\nQuestions tonight? Call ${getSettings().practiceName}.` };
}
export function postOpProposal(ep: L.Episode) { return ep.postOp.map(v => `POD ${v.pod} · ${d(v.date)}${v.photos ? ' · photo set' : ''}`); }
/** Simulated document reader: quotes what it "found" with the source. Staff confirm each tick. */
export function readClearanceDoc(ep: L.Episode, fileName: string): { found: string[]; note: string } {
  const want = Object.entries(ep.clearance.tests).filter(([, v]) => v !== 'received').map(([k]) => k);
  const f = fileName.toLowerCase(); const ecgOnly = /ecg|ekg/.test(f);
  const found = ecgOnly ? want.filter(t => t === 'ECG') : want.filter(t => t !== 'ECG');
  return { found, note: `Nightingale read “${fileName}” (simulated): found ${found.join(', ') || 'none of the requested items'}${want.filter(t => !found.includes(t)).length ? `; not found: ${want.filter(t => !found.includes(t)).join(', ')}` : ''}. Values are quoted from the document; please confirm each item.` };
}
/** Plain-language brief + flags for the top of the Surgery page. Facts only, no go/no-go. */
export function episodeBrief(ep: L.Episode, p: MedPatient, today: string): { text: string; flags: string[] } {
  const next = L.nextToDo(ep, today); const days = L.daysBetween(today, ep.surgeryDate); const flags: string[] = [];
  const bal = ep.items.find(i => i.key === 'balance'); if (bal && L.isOpen(bal)) { const dd = L.daysBetween(today, bal.due); if (dd < 5) flags.push(`Balance $${L.balanceDue(ep).toFixed(2)} ${dd < 0 ? `was due ${-dd} day(s) ago` : `due in ${dd} day(s)`}`); }
  const dep = ep.items.find(i => i.key === 'deposit'); if (dep && L.isOpen(dep)) flags.push('Deposit not paid yet');
  const miss = L.missingTests(ep); if (ep.clearance.required && ep.clearance.requestedAt && miss.length) flags.push(`Clearance still missing: ${miss.join(', ')} · surgery in ${days} days`);
  if (ep.returning) ep.stale.forEach(s => { const it = ep.items.find(i => i.action === 'reconfirm' && i.label.endsWith(s.label)); if (it && L.isOpen(it)) flags.push(`Reconfirm ${s.label} (last ${s.lastDate ? d(s.lastDate) : 'unknown'})`); });
  const text = ep.stage === 'closed' ? `${p.name}’s ${ep.procedure.toLowerCase()} episode is closed.` : `${p.name}, ${ageFrom(p.dob)}, ${ep.procedure.toLowerCase()} ${days >= 0 ? `in ${days} days (${d(ep.surgeryDate)})` : `${-days} days ago`} at ${ep.ascName}. ${next.length ? `${next.length} thing${next.length === 1 ? '' : 's'} left to do${next.filter(i => L.dueState(i, today) === 'overdue').length ? `, ${next.filter(i => L.dueState(i, today) === 'overdue').length} overdue` : ''}.` : 'Nothing left to do right now.'}${ep.clearance.required && ep.clearance.reasons.length ? ` Clearance: ${ep.clearance.decidedBy ? `required by ${ep.clearance.decidedBy}` : `your practice rule suggests it (${ep.clearance.reasons.join('; ')}); the surgeon decides`}.` : ''}`;
  return { text, flags };
}
