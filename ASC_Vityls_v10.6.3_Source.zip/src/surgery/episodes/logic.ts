/*
 * Surgery.Vityls v1.1 · Surgical Episodes: pure logic (no browser, no storage, so it is unit-tested with node).
 * One episode per planned surgery: Consult → Booked → Pre-op → Surgery → Post-op → Closed.
 * Each checklist item has an owner role, a due date relative to the surgery date (or the booking date) and a status.
 * Kevin's rule (v1.1): once a patient is booked, staff see ONLY what still needs to be done; done items go to history.
 * Henry: this is the shape of the `surgical_episodes` + `episode_items` tables (see report/v1.1_progress.md).
 */
export type Stage = 'consult' | 'booked' | 'preop' | 'surgery' | 'postop' | 'closed';
export const STAGES: { id: Stage; label: string }[] = [
  { id: 'consult', label: 'Consult' }, { id: 'booked', label: 'Booked' }, { id: 'preop', label: 'Pre-op' },
  { id: 'surgery', label: 'Surgery' }, { id: 'postop', label: 'Post-op' }, { id: 'closed', label: 'Closed' },
];
export const stageLabel = (s: Stage) => STAGES.find(x => x.id === s)?.label || s;
export type Owner = 'front' | 'nurse' | 'surgeon' | 'asc' | 'patient';
export const OWNER_LABEL: Record<Owner, string> = { front: 'Front desk', nurse: 'Nurse / coordinator', surgeon: 'Surgeon', asc: 'ASC', patient: 'Patient' };
export type ItemStatus = 'todo' | 'waiting' | 'done' | 'na';
export type ActionKind = 'collect-deposit' | 'collect-balance' | 'send-clearance' | 'mark-received' | 'surgeon-review' | 'send-asc' | 'asc-confirm'
  | 'send-instructions' | 'schedule-postop' | 'postop-photos' | 'sign-rx' | 'close' | 'reconfirm' | 'mark-done' | 'decide-clearance' | 'send-forms';
export type Anchor = 'surgery' | 'booking';
export interface TemplateItem { key: string; stage: Stage; label: string; owner: Owner; anchor: Anchor; offsetDays: number; action: ActionKind; needs?: 'clearance' }
/** Kevin: default pre-op clearance tests. CMP = chemistry panel, CXR = chest x-ray. */
export const CLEARANCE_TESTS = ['CBC', 'CMP', 'UA', 'ECG', 'PT', 'PTT', 'CXR'] as const;
export const TEST_LABEL: Record<string, string> = { CBC: 'CBC', CMP: 'CMP (chemistry panel)', UA: 'UA', ECG: 'ECG', PT: 'PT', PTT: 'PTT', CXR: 'Chest x-ray (CXR)' };
export type ClearanceTest = typeof CLEARANCE_TESTS[number];
export type TestState = 'needed' | 'requested' | 'received';

export const DEFAULT_TEMPLATE: TemplateItem[] = [
  { key: 'forms', stage: 'consult', label: 'Registration, admission and history forms complete', owner: 'front', anchor: 'booking', offsetDays: 0, action: 'send-forms' },
  { key: 'quote', stage: 'consult', label: 'Price quote accepted', owner: 'nurse', anchor: 'booking', offsetDays: 0, action: 'mark-done' },
  { key: 'deposit', stage: 'booked', label: 'Collect deposit', owner: 'front', anchor: 'booking', offsetDays: 0, action: 'collect-deposit' },
  { key: 'clr-decide', stage: 'booked', label: 'Decide whether pre-op clearance is needed', owner: 'surgeon', anchor: 'booking', offsetDays: 0, action: 'decide-clearance' },
  { key: 'rx', stage: 'preop', label: 'Post-op prescriptions (sign with PIN)', owner: 'surgeon', anchor: 'surgery', offsetDays: -7, action: 'sign-rx' },
  { key: 'clr-request', stage: 'preop', label: 'Send clearance request to the PCP', owner: 'nurse', anchor: 'booking', offsetDays: 2, action: 'send-clearance', needs: 'clearance' },
  { key: 'clr-receive', stage: 'preop', label: 'Clearance items received', owner: 'front', anchor: 'surgery', offsetDays: -10, action: 'mark-received', needs: 'clearance' },
  { key: 'clr-review', stage: 'preop', label: 'Surgeon reviews the clearance (PIN)', owner: 'surgeon', anchor: 'surgery', offsetDays: -7, action: 'surgeon-review', needs: 'clearance' },
  { key: 'balance', stage: 'preop', label: 'Collect balance', owner: 'front', anchor: 'surgery', offsetDays: -14, action: 'collect-balance' },
  { key: 'asc-send', stage: 'preop', label: 'Send the packet to the ASC', owner: 'nurse', anchor: 'surgery', offsetDays: -7, action: 'send-asc' },
  { key: 'asc-confirm', stage: 'preop', label: 'ASC confirms the packet is complete', owner: 'asc', anchor: 'surgery', offsetDays: -5, action: 'asc-confirm' },
  { key: 'instructions', stage: 'preop', label: 'Day-before reminder and pre-op instructions', owner: 'front', anchor: 'surgery', offsetDays: -1, action: 'send-instructions' },
  { key: 'opnote', stage: 'surgery', label: 'Op note received back from the ASC', owner: 'asc', anchor: 'surgery', offsetDays: 1, action: 'mark-done' },
  { key: 'postop-book', stage: 'postop', label: 'Book the post-op visits', owner: 'front', anchor: 'surgery', offsetDays: -3, action: 'schedule-postop' },
  { key: 'postop-photos', stage: 'postop', label: 'Post-op photo set at each milestone', owner: 'nurse', anchor: 'surgery', offsetDays: 30, action: 'postop-photos' },
  { key: 'close', stage: 'postop', label: 'Close the episode (no automatic PDF)', owner: 'surgeon', anchor: 'surgery', offsetDays: 90, action: 'close' },
];

export interface ClearanceRule { minAge: number; conditions: string[] }
export const DEFAULT_CLEARANCE_RULE: ClearanceRule = { minAge: 50, conditions: ['hypertension', 'diabetes', 'heart', 'osa', 'ckd', 'bleeding', 'lung'] };
export const DEFAULT_POSTOP_DAYS = [1, 7, 30, 90];
export const DEFAULT_ASC_REQUIRED = ['CBC', 'CMP', 'UA', 'ECG', 'PT', 'PTT', 'CXR', 'Surgical consent', 'Medication list'];
export const DEFAULT_STALE_MONTHS = 12;
export const DEFAULT_INSTRUCTIONS = 'Nothing to eat or drink after midnight. Take your usual blood-pressure medicine with a sip of water. Do not take diabetes pills the morning of surgery. Arrive at {asc} at {arrive}. Bring your photo ID and a responsible adult to drive you home.';

export interface EpisodeItem extends TemplateItem { id: string; status: ItemStatus; due: string; doneAt?: string; doneBy?: string; note?: string }
export interface HistoryEntry { at: string; by: string; what: string }
export interface PostOpVisit { pod: number; date: string; visitId?: string; photos: boolean; photosDone?: boolean }
export interface Episode {
  id: string; patientId: string; procedure: string; surgeon: string; ascName: string; surgeryDate: string; surgeryTime: string; bookedOn: string;
  createdAt: string; createdBy: string; stage: Stage; items: EpisodeItem[];
  quoteId?: string; consultVisitId?: string; depositAmount: number; totalAmount: number; paid: number;
  clearance: { required: boolean; reasons: string[]; decidedBy?: string; pcp: string; tests: Record<string, TestState>; suggested?: string[]; requestedAt?: string; reviewedBy?: string };
  asc: { required: string[]; sentAt?: string; confirmedAt?: string; missing?: string[] };
  postOp: PostOpVisit[]; stale: { label: string; last: string; lastDate?: string }[]; returning: boolean; history: HistoryEntry[]; closedAt?: string;
}

export const addDaysIso = (iso: string, n: number) => { const [y, m, d] = iso.split('-').map(Number); const x = new Date(Date.UTC(y, m - 1, d + n)); return x.toISOString().slice(0, 10); };
export const daysBetween = (from: string, to: string) => Math.round((Date.UTC(+to.slice(0, 4), +to.slice(5, 7) - 1, +to.slice(8, 10)) - Date.UTC(+from.slice(0, 4), +from.slice(5, 7) - 1, +from.slice(8, 10))) / 864e5);
export const dueFor = (t: TemplateItem, surgeryDate: string, bookedOn: string) => addDaysIso(t.anchor === 'surgery' ? surgeryDate : bookedOn, t.offsetDays);

/** The practice rule only SUGGESTS clearance (facts, never a fitness opinion). The surgeon decides. */
export function clearanceSuggestion(age: number, conditionTypes: string[], rule: ClearanceRule = DEFAULT_CLEARANCE_RULE): { suggested: boolean; reasons: string[] } {
  const reasons: string[] = [];
  if (age >= rule.minAge) reasons.push(`Age ${age} (rule: ${rule.minAge} or older)`);
  Array.from(new Set(conditionTypes.filter(c => rule.conditions.includes(c)))).forEach(c => reasons.push(`${c[0].toUpperCase()}${c.slice(1)} on the problem list`));
  return { suggested: reasons.length > 0, reasons };
}
export const postOpSchedule = (surgeryDate: string, days: number[] = DEFAULT_POSTOP_DAYS): PostOpVisit[] => days.map(pod => ({ pod, date: addDaysIso(surgeryDate, pod), photos: pod >= 7 }));

export interface NewEpisodeInput { id: string; patientId: string; procedure: string; surgeon: string; ascName: string; surgeryDate: string; surgeryTime?: string; bookedOn: string; createdAt: string; createdBy: string;
  totalAmount: number; depositAmount: number; age: number; conditions: string[]; pcp: string; quoteId?: string; consultVisitId?: string; returning?: boolean; stale?: Episode['stale'] }
export interface EpisodeSettings { template: TemplateItem[]; rule: ClearanceRule; postOpDays: number[]; ascRequired: string[]; staleMonths: number; instructions: string; depositPct: number }
export const DEFAULT_EPISODE_SETTINGS: EpisodeSettings = { template: DEFAULT_TEMPLATE, rule: DEFAULT_CLEARANCE_RULE, postOpDays: DEFAULT_POSTOP_DAYS, ascRequired: DEFAULT_ASC_REQUIRED, staleMonths: DEFAULT_STALE_MONTHS, instructions: DEFAULT_INSTRUCTIONS, depositPct: 25 };

export function buildEpisode(x: NewEpisodeInput, s: EpisodeSettings = DEFAULT_EPISODE_SETTINGS): Episode {
  const sug = clearanceSuggestion(x.age, x.conditions, s.rule);
  const items: EpisodeItem[] = s.template.map(t => ({ ...t, id: `${x.id}:${t.key}`, status: (t.needs === 'clearance' && !sug.suggested ? 'na' : 'todo') as ItemStatus, due: dueFor(t, x.surgeryDate, x.bookedOn) }));
  items.unshift(...(x.stale || []).map((st, i) => ({ key: `reconfirm-${i}`, stage: 'consult', label: `Reconfirm ${st.label}`, owner: /allerg|medication|medical history/i.test(st.label) ? 'nurse' : 'front', anchor: 'booking', offsetDays: 0, action: 'reconfirm', id: `${x.id}:reconfirm-${i}`, status: 'todo', due: x.bookedOn, note: `Last: ${st.last}${st.lastDate ? ` (${st.lastDate})` : ''}` } as EpisodeItem)));
  const ep: Episode = { id: x.id, patientId: x.patientId, procedure: x.procedure, surgeon: x.surgeon, ascName: x.ascName, surgeryDate: x.surgeryDate, surgeryTime: x.surgeryTime || '07:30 AM', bookedOn: x.bookedOn,
    createdAt: x.createdAt, createdBy: x.createdBy, stage: 'consult', items, quoteId: x.quoteId, consultVisitId: x.consultVisitId, depositAmount: x.depositAmount, totalAmount: x.totalAmount, paid: 0,
    clearance: { required: sug.suggested, reasons: sug.reasons, pcp: x.pcp, tests: Object.fromEntries((sug.suggested ? CLEARANCE_TESTS : []).map(t => [t, 'needed'])) },
    asc: { required: s.ascRequired }, postOp: postOpSchedule(x.surgeryDate, s.postOpDays), stale: x.stale || [], returning: !!x.returning,
    history: [{ at: x.createdAt, by: x.createdBy, what: `Episode started: ${x.procedure} on ${x.surgeryDate}${sug.suggested ? ` · practice rule suggests clearance (${sug.reasons.join('; ')})` : ''}` }] };
  return withStage(ep);
}

const OPEN: ItemStatus[] = ['todo', 'waiting'];
export const isOpen = (i: EpisodeItem) => OPEN.includes(i.status);
const idx = (s: Stage) => STAGES.findIndex(x => x.id === s);
/** The stage is the earliest stage that still has open items (Closed once everything is done or not needed). */
export function deriveStage(ep: Episode): Stage {
  if (ep.closedAt) return 'closed';
  const open = ep.items.filter(isOpen); if (!open.length) return 'closed';
  return open.reduce((m, i) => idx(i.stage) < idx(m) ? i.stage : m, 'postop' as Stage);
}
export const withStage = (ep: Episode): Episode => ({ ...ep, stage: deriveStage(ep) });

export type DueState = 'overdue' | 'soon' | 'ok';
export const dueState = (i: EpisodeItem, today: string, soonDays = 3): DueState => { const d = daysBetween(today, i.due); return d < 0 ? 'overdue' : d <= soonDays ? 'soon' : 'ok'; };

/**
 * Kevin's rule: show ONLY what still needs doing. Open items in the current stage, plus open items from any later
 * stage that are already due soon or overdue. Done / not-needed items never appear here (they live in history).
 */
export function nextToDo(ep: Episode, today: string): EpisodeItem[] {
  if (ep.stage === 'closed') return [];
  const cur = idx(ep.stage);
  return ep.items.filter(i => isOpen(i) && (idx(i.stage) <= cur || dueState(i, today) !== 'ok')).sort((a, b) => a.due.localeCompare(b.due));
}
export const doneItems = (ep: Episode) => ep.items.filter(i => !isOpen(i));

export const ROLE_OWNER = (role: string): Owner | 'all' => /front|reception|desk/i.test(role) ? 'front' : /surgeon|physician|^md|nurse practitioner|physician assistant/i.test(role) ? 'surgeon' : /rn|nurse|assistant|coordinator/i.test(role) ? 'nurse' : 'all';
/** My items first, then everyone else's (the 'All' filter shows everything). */
export function forRole(items: EpisodeItem[], owner: Owner | 'all'): EpisodeItem[] {
  if (owner === 'all') return items; return [...items.filter(i => i.owner === owner), ...items.filter(i => i.owner !== owner)];
}
export function groupByOwner(items: EpisodeItem[]): { owner: Owner; items: EpisodeItem[] }[] {
  const order: Owner[] = ['front', 'nurse', 'surgeon', 'asc', 'patient'];
  return order.map(o => ({ owner: o, items: items.filter(i => i.owner === o) })).filter(g => g.items.length);
}

export function setItem(ep: Episode, key: string, status: ItemStatus, by: string, at: string, note?: string): Episode {
  const items = ep.items.map(i => i.key === key ? { ...i, status, ...(status === 'done' || status === 'na' ? { doneAt: at, doneBy: by } : {}), ...(note ? { note } : {}) } : i);
  const it = ep.items.find(i => i.key === key);
  return withStage({ ...ep, items, history: [...ep.history, { at, by, what: `${it?.label || key}: ${status === 'done' ? 'done' : status === 'na' ? 'not needed' : status}${note ? ` · ${note}` : ''}` }] });
}

/** Clearance: the surgeon's decision switches the clearance items on or off. */
export function decideClearance(ep: Episode, required: boolean, by: string, at: string): Episode {
  let e: Episode = { ...ep, clearance: { ...ep.clearance, required, decidedBy: by, tests: required ? (Object.keys(ep.clearance.tests).length ? ep.clearance.tests : Object.fromEntries(CLEARANCE_TESTS.map(t => [t, 'needed']))) : {} } };
  e = { ...e, items: e.items.map(i => i.needs === 'clearance' ? { ...i, status: required ? (i.status === 'na' ? 'todo' : i.status) : 'na' } : i) };
  return setItem(e, 'clr-decide', 'done', by, at, required ? 'clearance required' : 'clearance not required');
}
export function requestClearance(ep: Episode, by: string, at: string): Episode {
  const tests = Object.fromEntries(Object.entries(ep.clearance.tests).map(([k, v]) => [k, v === 'needed' ? 'requested' : v])) as Record<string, TestState>;
  let e = setItem({ ...ep, clearance: { ...ep.clearance, tests, requestedAt: at } }, 'clr-request', 'done', by, at, `sent to ${ep.clearance.pcp}`);
  e = { ...e, items: e.items.map(i => i.key === 'clr-receive' && i.status === 'todo' ? { ...i, status: 'waiting' } : i) };
  return withStage(e);
}
export const missingTests = (ep: Episode) => Object.entries(ep.clearance.tests).filter(([, v]) => v !== 'received').map(([k]) => k);
export function receiveTests(ep: Episode, tests: string[], by: string, at: string): Episode {
  const t = { ...ep.clearance.tests }; tests.forEach(x => { if (x in t) t[x] = 'received'; });
  let e: Episode = { ...ep, clearance: { ...ep.clearance, tests: t, suggested: (ep.clearance.suggested || []).filter(x => !tests.includes(x)) }, history: [...ep.history, { at, by, what: `Clearance received: ${tests.join(', ')}` }] };
  if (!missingTests(e).length) e = setItem(e, 'clr-receive', 'done', by, at);
  return withStage(e);
}
/** Payments: deposit then balance; items close automatically when the amount is reached. */
export function applyPayment(ep: Episode, amount: number, by: string, at: string): Episode {
  let e: Episode = { ...ep, paid: Math.round((ep.paid + amount) * 100) / 100, history: [...ep.history, { at, by, what: `Payment $${amount.toFixed(2)} recorded toward the surgery` }] };
  if (e.paid >= e.depositAmount && isOpen(e.items.find(i => i.key === 'deposit')!)) e = setItem(e, 'deposit', 'done', by, at);
  if (e.paid >= e.totalAmount && isOpen(e.items.find(i => i.key === 'balance')!)) e = setItem(e, 'balance', 'done', by, at);
  return withStage(e);
}
export const balanceDue = (ep: Episode) => Math.max(0, Math.round((ep.totalAmount - ep.paid) * 100) / 100);
/** ASC: missing = the ASC's required items that are not yet on file (clearance tests not received, others assumed on file). */
export function ascMissing(ep: Episode, onFile: string[]): string[] { const got = new Set([...onFile, ...Object.entries(ep.clearance.tests).filter(([, v]) => v === 'received').map(([k]) => k)]); return ep.asc.required.filter(r => !got.has(r) && (ep.clearance.required || !(CLEARANCE_TESTS as readonly string[]).includes(r))); }

/** Stale data on a returning patient: anything older than the practice limit is reopened as "Reconfirm". */
export function staleItems(records: { label: string; last: string; date?: string; always?: boolean }[], today: string, months = DEFAULT_STALE_MONTHS) {
  return records.filter(r => r.always || !r.date || daysBetween(r.date.slice(0, 10), today) > months * 30.4).map(r => ({ label: r.label, last: r.last, lastDate: r.date?.slice(0, 10) }));
}
