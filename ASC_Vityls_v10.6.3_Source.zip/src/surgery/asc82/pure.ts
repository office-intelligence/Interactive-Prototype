/* v8.2 · pure helpers (no browser state) so node:test can load them: patient matching, requested day, nursing checklist and airway definitions. */
import type { AscCase } from '../asc8/logic';
const localDay = () => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; };
export const normName = (n: string) => n.toLowerCase().replace(/,.*$/, '').replace(/[^a-z ]/g, ' ').replace(/\s+/g, ' ').trim();
export const normDob = (d: string) => { const m = /(\d{1,4})[/-](\d{1,2})[/-](\d{1,4})/.exec(d || ''); if (!m) return ''; return m[1].length === 4 ? `${m[2].padStart(2, '0')}/${m[3].padStart(2, '0')}/${m[1]}` : `${m[1].padStart(2, '0')}/${m[2].padStart(2, '0')}/${m[3]}`; };
export interface PtLite { id: string; name: string; dob: string; phone?: string }
export type MatchResult = { kind: 'exact'; pick: PtLite; candidates: PtLite[] } | { kind: 'ambiguous'; candidates: PtLite[] } | { kind: 'none'; candidates: [] };
/** Same name + same DOB → link. Same name, DOB missing or different, or several hits → staff choose. Otherwise a new patient. */
export function matchPatient(name: string, dob: string, all: PtLite[]): MatchResult {
  const n = normName(name); if (!n) return { kind: 'none', candidates: [] };
  const last = n.split(' ').pop()!; const firstN = n.split(' ')[0];
  const same = all.filter(p => normName(p.name) === n); const near = all.filter(p => !same.includes(p) && normName(p.name).split(' ').pop() === last && normName(p.name).startsWith(firstN.slice(0, 3)));
  const d = normDob(dob); const exact = d ? same.filter(p => normDob(p.dob) === d) : [];
  if (exact.length === 1) return { kind: 'exact', pick: exact[0], candidates: [...same, ...near] };
  if (same.length || near.length) return { kind: 'ambiguous', candidates: [...same, ...near] };
  return { kind: 'none', candidates: [] };
}
/** "11/03/2026", "2026-11-03", "Nov 3" → ISO day; empty/past → next weekday. */
export function requestedDay(s: string, today = localDay()): string {
  const iso = /(\d{4})-(\d{2})-(\d{2})/.exec(s || ''); const us = /(\d{1,2})\/(\d{1,2})\/(\d{2,4})/.exec(s || '');
  let d = iso ? `${iso[1]}-${iso[2]}-${iso[3]}` : us ? `${us[3].length === 2 ? '20' + us[3] : us[3]}-${us[1].padStart(2, '0')}-${us[2].padStart(2, '0')}` : '';
  if (!d && s) { const t = new Date(`${s} ${today.slice(0, 4)}`); if (!isNaN(+t)) d = `${t.getFullYear()}-${String(t.getMonth() + 1).padStart(2, '0')}-${String(t.getDate()).padStart(2, '0')}`; }
  if (d && d >= today) return d;
  const x = new Date(today + 'T12:00:00'); do { x.setDate(x.getDate() + 1); } while (x.getDay() === 0 || x.getDay() === 6);
  return `${x.getFullYear()}-${String(x.getMonth() + 1).padStart(2, '0')}-${String(x.getDate()).padStart(2, '0')}`;
}

export type NI = { id: string; label: string; pre?: (c: AscCase) => string | false; vals?: [string, string][]; caseKey?: string };
export const NURSE_SECTIONS: { title: string; items: NI[] }[] = [
  { title: 'Consent & records', items: [
    { id: 'consent', label: 'Procedure consent signed and matches the booking', pre: c => !!c.d.consentConfirm && 'Surgeon confirmed' },
    { id: 'anescon', label: 'Anesthesia consent on the chart', pre: c => !!c.d.anesConsent && 'Signed' },
    { id: 'clearance', label: 'H&P / pre-op clearance and labs on the chart', pre: c => !!c.d.clearance && 'Received before surgery', caseKey: 'clearance' }] },
  { title: 'NPO, allergies & medications', items: [
    { id: 'npo', label: 'NPO confirmed with the patient', vals: [['solids', 'Last solids'], ['clears', 'Last clear liquids']], caseKey: 'npo' },
    { id: 'allergy', label: 'Allergy band on if any (allergies are confirmed once in Verify medical history)', pre: c => !!c.d.allergy && 'Confirmed', caseKey: 'allergy' },
    { id: 'meds', label: 'Morning meds taken as instructed (list in the official history)', pre: c => !!c.d.historyVerified && 'History verified', caseKey: 'meds' },
    { id: 'anticoag', label: 'Blood thinners held as instructed (or not taking any)' },
    { id: 'glp1', label: 'GLP-1 medications held as instructed (or not taking)' }] },
  { title: 'Assessment', items: [
    { id: 'vitals', label: 'Vitals taken', vals: [['bp', 'BP'], ['hr', 'HR'], ['spo2', 'SpO₂ %'], ['temp', 'Temp °F'], ['wt', 'Weight kg']], caseKey: 'vitals' },
    { id: 'glucose', label: 'Fingerstick glucose if diabetic (or not applicable)' },
    { id: 'preg', label: 'Pregnancy test if applicable (or not applicable)' },
    { id: 'skin', label: 'Skin intact at the surgical site; voided before surgery' }] },
  { title: 'Lines & prep', items: [
    { id: 'iv', label: 'IV started', vals: [['site', 'IV site'], ['gauge', 'Gauge']], caseKey: 'iv' },
    { id: 'prep', label: 'Skin prep / hair removal per protocol' },
    { id: 'removed', label: 'Dentures, jewelry, contacts and hearing aids removed; belongings secured' }] },
  { title: 'Discharge planning', items: [
    { id: 'home', label: 'Post-op plan confirmed (home with adult overnight, or recovery facility)', vals: [['plan', 'Plan'], ['facility', 'Post-op recovery facility name']] }] }];
export const HOME_PLANS = ['Home, adult stays overnight', 'Post-op recovery facility', 'Aftercare hotel / private nurse'];
export const needsFacility = (plan?: string) => !!plan && plan !== HOME_PLANS[0];
export const nurseCounts = (checks: Record<string, any>) => { const all = NURSE_SECTIONS.flatMap(s => s.items); return { done: all.filter(i => checks[i.id]).length, total: all.length }; };
export const AIRWAY: [string, string, string[]][] = [['mallampati', 'Mallampati', ['I', 'II', 'III', 'IV']], ['tmd', 'Thyromental distance', ['≥ 6 cm', '< 6 cm']], ['mouth', 'Mouth opening', ['≥ 3 fingers', '< 3 fingers']], ['neck', 'Neck ROM', ['Full', 'Limited']], ['teeth', 'Dentition', ['Intact', 'Caps / crowns', 'Dentures', 'Loose / chipped', 'Edentulous']]];
