/* ASC.Vityls v8.2 · shared station pieces: patient header card, hand-drawn signature pad, brief medical history,
 * per-station form list (Open + summary + missing fields inline), the X close icon, and a form opened in place. Fictional data. */
import React, { useEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { X } from 'lucide-react';
import { medRepo, ageFrom, visitAsCase } from '../../med/record';
import { repo } from '../../v6/dataLayer';
import { FormPage } from '../../v6/FormPage';
import { stationPlan } from '../../v7/myForms';
import { VITYLS_FORM_CATALOG, WorkflowKey } from '../../data/formWorkspaceCatalog';
import { svRead, svWrite } from '../store';
import * as A from '../asc8/logic';
import { StationIcon } from '../asc81/icons81';

import { AllergyCard } from '../asc10/kit';
export const XClose: React.FC<{ onClick: () => void; testId?: string }> = ({ onClick, testId = 'a82-x' }) => <button type="button" className="a82-x" onClick={onClick} aria-label="Close" title="Close" data-testid={testId}><X size={18} /></button>;

const sexWord = (s?: string) => /^f/i.test(s || '') ? 'Female' : /^m/i.test(s || '') ? 'Male' : s || '—';
/** Whose chart is open: shown at the top of every station and workbench (tablets get handed around). */
export const CaseCard: React.FC<{ c: A.AscCase; station?: A.Station; right?: React.ReactNode }> = ({ c, station, right }) => {
  const p = medRepo.patient(c.pid); if (!p) return null;
  return <div className="a82-case" data-testid="a82-case-card">{station && <StationIcon st={station} boxed size={18} />}
    <div className="min-w-0 flex-1"><div className="nm" data-testid="a82-case-name">{p.name}</div>
      <div className="facts"><span data-testid="a82-case-age">{ageFrom(p.dob)} y</span><span>{sexWord(p.sex)}</span><span><b>{c.procedure}</b>{c.side && !c.procedure.toLowerCase().includes(c.side.toLowerCase()) ? ` · ${c.side}` : ''}</span><span>Surgeon: {c.surgeon}</span><span>{c.room} · {c.time.replace(/^0/, '')}</span></div></div><AllergyCard compact list={p.allergies} confirmed={c.d.allergy ? 'Confirmed today' : undefined} />
    {right}</div>;
};

export { SigPad, saveSig, sigsFor } from './sigpad';
export type { SigRec } from './sigpad';
import { SigPad } from './sigpad';
/* ---------------- brief medical history (anesthesia + surgeon) ---------------- */
const SRC = { clearance: 'ASC_PreOp_HP_Clearance.html', history: 'Medical_History.html', anesQ: 'Anesthesia_Questionnaire.html' };
export const MedSummary: React.FC<{ c: A.AscCase; onOpenForm?: (file: string) => void; compact?: boolean }> = ({ c, onOpenForm, compact }) => {
  const p = medRepo.patient(c.pid); if (!p) return null;
  const meds = (medRepo as any).meds(p.id).filter((m: any) => m.status === 'active'); const probs = (medRepo as any).problems(p.id).filter((x: any) => x.status === 'active');
  const hist = repo.getForm(c.visitId, SRC.history).values || {}; const anq = repo.getForm(c.visitId, SRC.anesQ).values || {};
  const pick = (o: Record<string, any>, re: RegExp) => Object.entries(o).filter(([k, v]) => re.test(k) && v && v !== 'No' && typeof v === 'string').map(([, v]) => String(v)).slice(0, 3);
  const surg = [...pick(hist, /surg|operation|procedure_hist/i), ...(c.d.surgHx ? [c.d.surgHx] : [])]; const anesHx = pick(anq, /anesth|ponv|nausea|reaction|family/i);
  const L = (file: string, t: string) => onOpenForm ? <button type="button" className="a82-src" onClick={() => onOpenForm(file)} data-testid="a82-src">{t}</button> : <span className="a82-src">{t}</span>;
  return <section className={`a82-hx ${compact ? 'compact' : ''}`} data-testid="a82-medsummary"><h3 className="a81-h3">Brief medical history</h3>
    <div className="grid">
      <div><b>Allergies</b>{p.allergies.length ? p.allergies.map(a => <div key={a} className="alg">{a}</div>) : <div>No known drug allergies</div>}<div className="s">{c.d.allergy ? '✓ confirmed today' : 'not yet confirmed today'} · {L(SRC.history, 'Medical history')}</div></div>
      <div><b>Medications</b>{meds.length ? meds.map((m: any) => <div key={m.id}>{m.name} {m.dose} {m.frequency}</div>) : <div>None</div>}<div className="s">{L(SRC.clearance, 'Pre-op clearance')}</div></div>
      <div><b>Conditions</b>{probs.length ? probs.map((x: any) => <div key={x.id}>{x.description}</div>) : <div>None recorded</div>}<div className="s">{L(SRC.clearance, 'Pre-op clearance')} · {L(SRC.history, 'Medical history')}</div></div>
      <div><b>Surgical / anesthesia history</b>{surg.length || anesHx.length ? [...surg, ...anesHx].map((x, i) => <div key={i}>{x}</div>) : <div>No prior problems recorded</div>}<div className="s">{L(SRC.anesQ, 'Anesthesia questionnaire')}</div></div>
      {c.d.vitals?.bp && <div><b>Today</b><div>BP {c.d.vitals.bp} · HR {c.d.vitals.hr ?? '—'}{c.d.vitals.spo2 ? ` · SpO₂ ${c.d.vitals.spo2}%` : ''}</div>{c.d.npo && <div>NPO solids {c.d.npo.solids} · clears {c.d.npo.clears}</div>}</div>}
    </div></section>;
};

/* ---------------- a form opened in place (full form, not missing-items mode) ---------------- */
const catItem = (f: string) => VITYLS_FORM_CATALOG.find(x => x.file === f) || { title: f.replace(/\.html$/, '').replace(/_/g, ' '), file: f, category: 'Form', stage: '' } as any;
export const FormInPlace: React.FC<{ c: A.AscCase; file: string; station: WorkflowKey; onClose: () => void; inline?: boolean; noClose?: boolean }> = ({ c, file, station, onClose, inline, noClose }) => {
  const v = medRepo.visit(c.visitId); if (!v) return <p className="sv-muted">No visit on file.</p>;
  const el = <div className={`sv-flat a82-form ${inline ? "v103-host" : ""}`} data-testid={`a82-form-${file}`}><FormPage patient={visitAsCase(v)} form={catItem(file)} station={station} onClose={onClose} inline={inline} noClose={noClose} /></div>;
  // v10.4: a full-screen form is rendered at the top of the page so no station header or stepper can sit over its close X.
  return inline ? el : createPortal(el, document.body);
};
export const WK: Record<A.Station, WorkflowKey> = { front: 'frontOffice', preop: 'nursing', anesthesia: 'anesthesia', surgeon: 'surgeon', or: 'orTeam', pacu: 'pacu', billing: 'patientPortal' } as any;
export const formTitle = (f: string) => catItem(f).title;
/** Forms assigned to a station: each with Open, a one-line summary of what's collected, and the missing items inline (rendered by the caller). */
export function stationForms(c: A.AscCase, st: A.Station) { const plan = stationPlan(WK[st]); const files = Array.from(new Set([...plan.required, ...plan.asNeeded]));
  return files.map(f => { const r = repo.getForm(c.visitId, f); const vals = Object.values(r.values || {}).filter(v => v !== '' && v !== false && v != null).length;
    return { file: f, title: formTitle(f), required: plan.required.includes(f), status: r.status as string, filled: vals }; }); }
