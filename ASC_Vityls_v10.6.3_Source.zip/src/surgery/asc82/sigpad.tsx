/* v8.2 · hand-drawn signature pad (finger / stylus / mouse). Stored as a PNG data URL next to the PIN signature. */
import React, { useEffect, useRef, useState } from 'react';
import { svRead, svWrite } from '../store';
/* ---------------- hand-drawn signature (finger / stylus / mouse) ---------------- */
export const SigPad: React.FC<{ onChange: (png: string) => void; label?: string; testId?: string }> = ({ onChange, label = 'Sign here', testId = 'a82-sigpad' }) => {
  const ref = useRef<HTMLCanvasElement>(null); const drawing = useRef(false); const [has, setHas] = useState(false);
  useEffect(() => { const cv = ref.current!; const r = cv.getBoundingClientRect(); cv.width = Math.max(260, r.width) * 2; cv.height = 140 * 2; const g = cv.getContext('2d')!; g.scale(2, 2); g.lineWidth = 2.2; g.lineCap = 'round'; g.strokeStyle = '#0f1f3d'; }, []);
  const pt = (e: React.PointerEvent) => { const r = ref.current!.getBoundingClientRect(); return [e.clientX - r.left, e.clientY - r.top]; };
  const down = (e: React.PointerEvent) => { e.preventDefault(); ref.current!.setPointerCapture(e.pointerId); drawing.current = true; const g = ref.current!.getContext('2d')!; const [x, y] = pt(e); g.beginPath(); g.moveTo(x, y); g.lineTo(x + 0.1, y + 0.1); g.stroke(); };
  const move = (e: React.PointerEvent) => { if (!drawing.current) return; const g = ref.current!.getContext('2d')!; const [x, y] = pt(e); g.lineTo(x, y); g.stroke(); };
  const up = () => { if (!drawing.current) return; drawing.current = false; setHas(true); onChange(ref.current!.toDataURL('image/png')); };
  const clear = () => { const cv = ref.current!; cv.getContext('2d')!.clearRect(0, 0, cv.width, cv.height); setHas(false); onChange(''); };
  return <div className="a82-sig" data-testid={testId} data-signed={has ? '1' : '0'}><div className="h"><span>{label}</span>{has && <button type="button" className="sv-link sv-small" onClick={clear} data-testid={`${testId}-clear`}>Clear</button>}</div>
    <canvas ref={ref} onPointerDown={down} onPointerMove={move} onPointerUp={up} onPointerLeave={up} aria-label={`${label} — draw your signature`} style={{ touchAction: 'none' }} data-testid={`${testId}-canvas`} />
    <div className="line">✕ ________________________________</div></div>;
};
export interface SigRec { id: string; title: string; name: string; role: string; at: string; png: string; caseId?: string }
export const saveSig = (r: Omit<SigRec, 'id'>) => { svWrite('asc82-sigs', [...svRead<SigRec[]>('asc82-sigs', []), { ...r, id: `sig-${Date.now().toString(36)}` }]); };
export const sigsFor = (caseId: string) => svRead<SigRec[]>('asc82-sigs', []).filter(s => s.caseId === caseId);

