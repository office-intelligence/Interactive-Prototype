/* v8.2 · Booking intake → scheduler. Patient matching (name + DOB), the pending "Add appointment" prefill, and the case
 * that is created once the appointment is booked. Pure helpers are exported for unit tests. Fictional data only. */
import { medRepo, isoDay, uid } from '../../med/record';
import { repo } from '../../v6/dataLayer';
import { svRead, svWrite } from '../store';
import * as A from '../asc8/logic';
import * as S from '../asc8/store';
import type { BookingDraft } from '../asc81/ai';
import { s81, mid } from '../asc81/store81';

export { normName, normDob, matchPatient, requestedDay } from './pure';
import { normDob } from './pure';
export type { PtLite, MatchResult } from './pure';
export interface PendingBook { intakeId: string; patientId: string; date: string; time: string; room: string; provider: string; duration: number; reason: string; notes: string; source: string; anesthesia: string; email?: string; phone?: string; draft?: { name?: string; dob?: string; phone?: string; email?: string; sex?: string; procedure?: string; anesthesia?: string; payType?: string; duration?: number; notes?: string; assistant?: string; equipment?: string } }
export const pendingBook = () => svRead<PendingBook | null>('asc82-pending-book', null);
export const setPendingBook = (p: PendingBook | null) => { svWrite('asc82-pending-book', p); window.dispatchEvent(new Event('asc82-book')); };

export function createPatientFromDraft(d: BookingDraft): string {
  const pid = uid('ASC-N'); const y = new Date().getFullYear() - (d.age || 40);
  medRepo.savePatient({ id: pid, name: d.patientName, dob: normDob(d.dob) || `01/01/${y}`, sex: /^f/i.test(d.gender || '') ? 'Female' : /^m/i.test(d.gender || '') ? 'Male' : 'Other', phone: d.phone || '', email: d.email || '', language: 'English', allergies: [], primaryProvider: d.surgeon || S.PATEL, careTeam: [], insurance: d.paymentType || 'Self-pay', fictional: true } as any);
  return pid;
}
/** Called by the scheduler after "Book appointment": the ASC case is built on that visit and the intake item is closed. */
export function completeIntakeBooking(p: PendingBook, v: { id: string; patientId: string; date: string; time: string; durationMin: number; provider: string; room: string; reason?: string }, by: string, role: string): A.AscCase {
  const at = new Date().toISOString();
  const c: A.AscCase = { id: uid('c'), pid: v.patientId, visitId: v.id, date: v.date, time: v.time, durationMin: v.durationMin, room: /^OR/.test(v.room) ? v.room : p.room, surgeon: v.provider, anesthesia: S.ANES[0], procedure: v.reason || p.reason, cpt: '', loc: 'scheduled', d: {}, events: {}, audit: [{ at, by, role, what: `Case created from ${p.source} intake via the scheduler (Nightingale pre-fill confirmed by staff)` }], from: 'ASC' } as any;
  svWrite('asc8-cases', [...S.cases(), c]);
  const it = s81.intake().find(i => i.id === p.intakeId); if (it) s81.upIntake({ ...it, status: 'booked', caseId: c.id });
  s81.addMsg({ id: mid('m'), caseId: c.id, channel: 'portal', to: p.email || p.phone || '[patient]', subject: 'Admission & registration forms', body: 'Your surgery center forms are ready in the patient portal.', status: 'sent (simulated)', at, by });
  repo.audit({ caseId: `asc8:${c.id}`, user: by, role, action: 'asc8.case' as any, detail: `${medRepo.patient(v.patientId)?.name} · case created from ${p.source} intake, booked ${v.date} ${v.time}` });
  setPendingBook(null); window.dispatchEvent(new Event('vityls-med-updated')); return c;
}
