/* v1.2 P6 · gap screens on the step page: acknowledgments (Step 6, tied to the accepted quote version + expiry), surgery-day
   cancel/delay/change record and facility record import (Step 9), red-flag screen, tracker and proposed post-op schedule
   (Step 10), interval questions + last-confirmed marks (Step 11). All simulated; Nightingale never decides. */
import React, { useState } from 'react';
import { isoDay, uid, usDate } from '../../med/record';
import { useActor } from '../../med/ui';
import * as G from './gaps';
import * as C from './confirm';
import { SJourney, setX, confirmationsOf, confirmRules } from './store';
import { activeEpisode } from '../episodes/store';
import { quotesFor } from '../quotes';

export type GapKind = 'ack' | 'day-record' | 'records' | 'redflag' | 'tracker' | 'postop-plan' | 'reconcile';
const now = () => new Date().toISOString();
const Shell: React.FC<{ title: string; lead?: React.ReactNode; onClose: () => void; testId: string; children: React.ReactNode; foot: React.ReactNode }> = ({ title, lead, onClose, testId, children, foot }) =>
  <div className="mod open" role="dialog" aria-modal="true" aria-label={title} data-testid={testId} onClick={e => { if (e.target === e.currentTarget) onClose(); }}><div className="card" style={{ maxWidth: 640 }}>
    <h3>{title}</h3>{lead && <div className="lead">{lead}</div>}<div style={{ maxHeight: '60vh', overflow: 'auto' }}>{children}</div><div className="row"><button type="button" className="btn" onClick={onClose}>Cancel</button>{foot}</div></div></div>;

export const GapDialog: React.FC<{ kind: GapKind; j: SJourney; onClose: (msg?: string) => void }> = ({ kind, j, onClose }) => {
  const [actor] = useActor(); const pid = j.patientId; const ep = activeEpisode(pid); const T = isoDay();
  const save = (f: (x: SJourney['x']) => SJourney['x'], what: string, msg: string) => { try { setX(pid, f, actor.name, actor.role, what); onClose(msg); } catch (e: any) { onClose(e.message); } };
  const cancel = () => onClose();
  if (kind === 'ack') {
    const q = quotesFor(pid).find((x: any) => x.status === 'accepted') || quotesFor(pid)[0] as any; const miss = G.missingAcks(j.x.acks); const [on, setOn] = useState<Record<string, boolean>>({}); const [via, setVia] = useState<'in-office' | 'portal'>('in-office');
    const chk = q ? G.canAccept({ validUntil: (q as any).validUntil || '9999-12-31', superseded: (q as any).status === 'superseded' }, T) : { ok: true };
    return <Shell title="Acknowledgments" testId="jy-acks" onClose={cancel} lead={<>Tied to {q ? <>quote v{(q as any).version || 1} · valid until {usDate((q as any).validUntil)}{!chk.ok ? <b> · {chk.why}</b> : ''}</> : 'the current quote'}. The patient acknowledges each item; staff records how.</>}
      foot={<button type="button" className="btn pri" disabled={!miss.every(k => on[k])} data-testid="jy-acks-save" onClick={() => save(x => ({ ...x, acks: [...x.acks, ...miss.map(k => ({ kind: k, text: G.ACK_TEXT[k], at: now(), by: actor.name, via, quoteVersion: (q as any)?.version }))] }), 'acknowledgments recorded', 'Acknowledgments recorded')}>Record acknowledgments</button>}>
      {G.REQUIRED_ACKS.map(k => { const done = j.x.acks.find(a => a.kind === k); return <label key={k} className="chk"><input type="checkbox" checked={!!done || !!on[k]} disabled={!!done} onChange={e => setOn({ ...on, [k]: e.target.checked })} /><span><b>{k[0].toUpperCase() + k.slice(1)}</b> · {G.ACK_TEXT[k]}{done && <small style={{ display: 'block' }}>✓ {done.by} · {usDate(done.at)} · {done.via}</small>}</span></label>; })}
      <div className="seg2" style={{ marginTop: 8 }}>Recorded: <select value={via} onChange={e => setVia(e.target.value as any)} aria-label="How"><option value="in-office">in office (patient signs on the tablet)</option><option value="portal">in the Portal</option></select></div></Shell>;
  }
  if (kind === 'day-record') {
    const [k, setK] = useState<G.DayEventKind>('on-schedule'); const [reason, setReason] = useState(''); const [newTime, setNT] = useState(''); const [newDate, setND] = useState(''); const [newProcedure, setNP] = useState('');
    const e = { kind: k, reason, newTime, newDate, newProcedure }; const probs = G.dayEventProblems(e);
    return <Shell title="Surgery day: record what happened" testId="jy-day" onClose={cancel} lead="On schedule, delayed, cancelled, procedure changed or rescheduled. Logged with your name and the time."
      foot={<button type="button" className="btn pri" disabled={!!probs.length} data-testid="jy-day-save" onClick={() => save(x => ({ ...x, dayEvents: [...x.dayEvents, { ...e, at: now(), by: actor.name }] }), `surgery day: ${k}`, 'Surgery-day record saved')}>Save</button>}>
      <select value={k} onChange={x => setK(x.target.value as any)} aria-label="What happened">{(['on-schedule', 'delayed', 'cancelled', 'procedure-changed', 'rescheduled'] as G.DayEventKind[]).map(o => <option key={o} value={o}>{o.replace('-', ' ')}</option>)}</select>
      {k !== 'on-schedule' && <><label>Reason</label><textarea value={reason} onChange={x => setReason(x.target.value)} aria-label="Reason" /></>}
      {k === 'delayed' && <><label>New time</label><input value={newTime} onChange={x => setNT(x.target.value)} aria-label="New time" placeholder="9:30 AM" /></>}
      {k === 'rescheduled' && <><label>New date</label><input type="date" value={newDate} onChange={x => setND(x.target.value)} aria-label="New date" /></>}
      {k === 'procedure-changed' && <><label>New procedure</label><input value={newProcedure} onChange={x => setNP(x.target.value)} aria-label="New procedure" /></>}
      {probs.length > 0 && <div className="err">Required: {probs.join(', ')}.</div>}
      {j.x.dayEvents.map((d, i) => <div key={i} className="fine">{usDate(d.at)} · {d.kind} · {d.by}{d.reason ? ` · ${d.reason}` : ''}</div>)}</Shell>;
  }
  if (kind === 'records') {
    const from = (ep?.ascName || 'Facility').replace(/\s*\(fictional\)/, '');
    return <Shell title="Facility records" testId="jy-records" onClose={cancel} lead={`Import or link the operative note and discharge summary from ${from}. Nightingale matches name, DOB and surgery date (simulated).`}
      foot={<button type="button" className="btn pri" data-testid="jy-records-import" onClick={() => save(x => ({ ...x, records: [...x.records.filter(r => !G.REQUIRED_RECORDS.includes(r.kind)), ...G.REQUIRED_RECORDS.map(k => ({ kind: k, how: 'imported' as const, from, at: now(), by: actor.name, matched: true }))] }), 'facility records imported', 'Op note + discharge summary imported and matched')}>Import from {from} (simulated)</button>}>
      {(Object.keys(G.RECORD_LABEL) as G.RecordKind[]).map(k => { const r = j.x.records.find(x => x.kind === k); return <div key={k} className="chk"><span>{r?.matched ? '✓' : G.REQUIRED_RECORDS.includes(k) ? '✕' : '·'}</span><span><b>{G.RECORD_LABEL[k]}</b>{G.REQUIRED_RECORDS.includes(k) ? ' (required)' : ''}{r && <small style={{ display: 'block' }}>{r.how} · {r.by} · {usDate(r.at)} · {r.matched ? 'name + DOB + date matched' : 'needs matching'}</small>}</span></div>; })}</Shell>;
  }
  if (kind === 'redflag') {
    const [a, setA] = useState<Record<string, boolean>>({}); const [via, setVia] = useState<'phone' | 'visit' | 'portal'>('phone'); const r = G.screenResult({ answers: a });
    const all = G.RED_FLAGS.every(f => f.id in a);
    return <Shell title="Red-flag screen" testId="jy-redflag" onClose={cancel} lead="Ask each question. Any yes goes to the surgeon right away. Nightingale lists answers; she does not assess them."
      foot={<button type="button" className="btn pri" disabled={!all} data-testid="jy-redflag-save" onClick={() => save(x => ({ ...x, screens: [...x.screens, { at: now(), by: actor.name, via, answers: a }], ...(r.escalate ? { tracked: [...x.tracked, { id: uid('tr'), kind: 'complication' as const, text: `Red flag: ${r.positives.join(', ')}`, at: now(), by: actor.name, status: 'open' as const, owner: 'surgeon' as const }] } : {}) }), `red-flag screen: ${r.text}`, r.escalate ? 'Escalated to the surgeon (tracker item created)' : 'Screen recorded · no red flags')}>Save screen</button>}>
      {G.RED_FLAGS.map(f => <div key={f.id} className="chk" data-testid={`rf-${f.id}`}><span style={{ flex: 1 }}>{f.label}</span><button type="button" className={`btn sm${a[f.id] === false ? ' pri' : ''}`} onClick={() => setA({ ...a, [f.id]: false })}>No</button><button type="button" className={`btn sm${a[f.id] ? ' warn' : ''}`} onClick={() => setA({ ...a, [f.id]: true })}>Yes</button></div>)}
      <div className="seg2" style={{ marginTop: 8 }}>Via <select value={via} onChange={e => setVia(e.target.value as any)} aria-label="Via"><option value="phone">phone</option><option value="visit">visit</option><option value="portal">portal</option></select></div>
      {r.escalate && <div className="err">{r.text}</div>}</Shell>;
  }
  if (kind === 'tracker') {
    const [k, setK] = useState<G.TrackKind>('question'); const [text, setText] = useState('');
    return <Shell title="Post-op tracker" testId="jy-tracker" onClose={cancel} lead="Questions, refills, complications, tests and referrals stay here until someone closes them. Refills and complications route to the surgeon."
      foot={<button type="button" className="btn pri" disabled={text.trim().length < 3} onClick={() => save(x => ({ ...x, tracked: [...x.tracked, { id: uid('tr'), kind: k, text, at: now(), by: actor.name, status: 'open', owner: G.routeTracked(k) }] }), `tracker: ${k} added`, 'Added to the tracker')}>Add</button>}>
      {j.x.tracked.map(t => <div key={t.id} className="chk" data-testid="jy-tracked"><span>{t.status === 'closed' ? '✓' : '•'}</span><span style={{ flex: 1 }}><b>{G.TRACK_LABEL[t.kind]}</b> · {t.text}<small style={{ display: 'block' }}>{t.owner} · {usDate(t.at)}{t.closedBy ? ` · closed by ${t.closedBy}: ${t.resolution}` : ''}</small></span>
        {t.status === 'open' && <button type="button" className="btn sm" data-testid="jy-track-close" onClick={() => save(x => ({ ...x, tracked: x.tracked.map(y => y.id === t.id ? { ...y, status: 'closed', closedAt: now(), closedBy: actor.name, resolution: 'resolved' } : y) }), `tracker: closed ${t.kind}`, 'Closed')}>Close</button>}</div>)}
      {!j.x.tracked.length && <div className="fine">Nothing tracked yet.</div>}
      <div className="two" style={{ marginTop: 10 }}><select value={k} onChange={e => setK(e.target.value as any)} aria-label="Kind">{(Object.keys(G.TRACK_LABEL) as G.TrackKind[]).map(o => <option key={o} value={o}>{G.TRACK_LABEL[o]}</option>)}</select><input value={text} onChange={e => setText(e.target.value)} placeholder="What is it?" aria-label="Tracker text" /></div></Shell>;
  }
  if (kind === 'postop-plan') {
    const plan = ep ? G.proposePostOp(ep.surgeryDate) : [];
    return <Shell title="Proposed post-op schedule" testId="jy-postop" onClose={cancel} lead="Nightingale proposes visits from the surgery date and the practice defaults. The front desk books them; nothing is booked until you approve."
      foot={<button type="button" className="btn pri" data-testid="jy-postop-ok" onClick={() => onClose('__postop__')}>Approve plan</button>}>
      <table className="tbl"><tbody><tr><th>Visit</th><th>Date</th><th>Photos</th></tr>{plan.map(v => <tr key={v.pod}><td>Post-op day {v.pod}</td><td>{usDate(v.date)}</td><td>{v.photos ? 'yes' : '—'}</td></tr>)}</tbody></table></Shell>;
  }
  // reconcile (Step 11): interval questions + marks per category
  const conf = confirmationsOf(pid); const [marks, setMarks] = useState<Record<string, C.Mark>>(() => Object.keys(j.x.marks).length ? j.x.marks as any : C.defaultMarks(conf, T, confirmRules()));
  const [ans, setAns] = useState<Record<string, 'yes' | 'no'>>(() => Object.fromEntries(Object.entries(j.x.interval).map(([k, v]) => [k, v.answer])));
  return <Shell title="Since the last surgery" testId="jy-reconcile" onClose={cancel} lead="Interval questions and the last-confirmed date of every part of the record. Mark each as confirmed, changed, unknown or needs review."
    foot={<button type="button" className="btn pri" data-testid="jy-reconcile-save" onClick={() => save(x => ({ ...x, marks, interval: Object.fromEntries(Object.entries(ans).map(([k, v]) => [k, { answer: v, at: now(), by: actor.name }])) }), 'interval questions + marks saved', C.reconciled(marks) ? 'Reconciled' : 'Saved · some items still need review')}>Save</button>}>
    {G.INTERVAL_QUESTIONS.map(q => <div key={q.id} className="chk"><span style={{ flex: 1 }}>{q.q}</span><button type="button" className={`btn sm${ans[q.id] === 'no' ? ' pri' : ''}`} onClick={() => setAns({ ...ans, [q.id]: 'no' })}>No</button><button type="button" className={`btn sm${ans[q.id] === 'yes' ? ' warn' : ''}`} onClick={() => setAns({ ...ans, [q.id]: 'yes' })}>Yes</button></div>)}
    <table className="tbl" style={{ marginTop: 10 }}><tbody><tr><th>Part of the record</th><th>Last confirmed</th><th>Mark</th></tr>{C.ALL_CATS.map(k => <tr key={k}><td>{C.CAT_LABEL[k]}</td><td>{C.lcText(conf[k])}</td><td><select value={marks[k]} onChange={e => setMarks({ ...marks, [k]: e.target.value as C.Mark })} aria-label={`Mark ${C.CAT_LABEL[k]}`}>{(Object.keys(C.MARK_LABEL) as C.Mark[]).map(m => <option key={m} value={m}>{C.MARK_LABEL[m]}</option>)}</select></td></tr>)}</tbody></table></Shell>;
};
