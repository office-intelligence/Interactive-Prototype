/*
 * Surgery.Vityls v1.2 · pieces Kevin's document asks for that v1.1 did not have (pure, unit-tested):
 *  - procedural + financial acknowledgments and cancellation / refund terms (Step 6)
 *  - surgery-day record: cancellation / delay / procedure change, and op + discharge records imported or linked from the ASC (Step 9)
 *  - red-flag symptom screening with escalation, and a questions / refills / complications / tests / referrals tracker (Step 10)
 *  - an auto-proposed post-op visit schedule (Step 10)
 * Facts and routing only: nothing here diagnoses, prescribes or gives clearance.
 */
export type AckKind = 'procedural' | 'financial' | 'cancellation' | 'refund' | 'photo';
export const ACK_TEXT: Record<AckKind, string> = {
  procedural: 'I have discussed the procedure, its material risks, benefits, alternatives and recovery with my surgeon and had my questions answered.',
  financial: 'I understand the quote, the deposit due at booking and that the balance is due 14 days before surgery.',
  cancellation: 'Cancellations or reschedules within 14 days of surgery may forfeit the deposit; facility and anesthesia fees follow the facility policy.',
  refund: 'Refunds of payments beyond the deposit are issued within 30 days of a cancellation made more than 14 days before surgery.',
  photo: 'I consent to standardized medical photographs for my record (not for marketing unless I sign separately).',
};
export interface Ack { kind: AckKind; text: string; at: string; by: string; via: 'in-office' | 'portal'; quoteVersion?: number }
export const REQUIRED_ACKS: AckKind[] = ['procedural', 'financial', 'cancellation', 'refund'];
export const missingAcks = (acks: Ack[]) => REQUIRED_ACKS.filter(k => !acks.some(a => a.kind === k));
/** A quote version can only be accepted while it is current and not expired. */
export function canAccept(q: { validUntil: string; superseded?: boolean }, today: string): { ok: boolean; why?: string } {
  if (q.superseded) return { ok: false, why: 'A newer version exists' };
  if (q.validUntil < today) return { ok: false, why: `Expired ${q.validUntil}. Revise to a new version first.` };
  return { ok: true };
}

/* ---------- Step 9: surgery-day record ---------- */
export type DayEventKind = 'on-schedule' | 'delayed' | 'cancelled' | 'procedure-changed' | 'rescheduled';
export interface DayEvent { kind: DayEventKind; at: string; by: string; reason: string; newTime?: string; newDate?: string; newProcedure?: string }
export function dayEventProblems(e: Omit<DayEvent, 'at' | 'by'>): string[] {
  const p: string[] = []; if (e.kind !== 'on-schedule' && e.reason.trim().length < 5) p.push('a reason');
  if (e.kind === 'delayed' && !e.newTime) p.push('the new time'); if (e.kind === 'rescheduled' && !e.newDate) p.push('the new date'); if (e.kind === 'procedure-changed' && !e.newProcedure?.trim()) p.push('the procedure performed');
  return p;
}
export type RecordKind = 'operative-note' | 'discharge-summary' | 'anesthesia-record' | 'pathology';
export const RECORD_LABEL: Record<RecordKind, string> = { 'operative-note': 'Operative note', 'discharge-summary': 'Discharge summary / instructions', 'anesthesia-record': 'Anesthesia record', pathology: 'Pathology report' };
export interface FacilityRecord { kind: RecordKind; how: 'imported' | 'linked'; from: string; at: string; by: string; docId?: string; matched: boolean }
export const REQUIRED_RECORDS: RecordKind[] = ['operative-note', 'discharge-summary'];
export const recordsReconciled = (r: FacilityRecord[]) => REQUIRED_RECORDS.every(k => r.some(x => x.kind === k && x.matched));

/* ---------- Step 10: red flags + tracker ---------- */
export const RED_FLAGS = [
  { id: 'fever', label: 'Fever over 101 °F (38.3 °C) or chills' },
  { id: 'bleeding', label: 'Bleeding that soaks through the dressing' },
  { id: 'breath', label: 'Shortness of breath or chest pain' },
  { id: 'calf', label: 'Calf pain or swelling in one leg' },
  { id: 'pain', label: 'Pain not controlled by the prescribed medicine' },
  { id: 'wound', label: 'Spreading redness, pus or wound opening' },
  { id: 'vision', label: 'Vision change (eyelid / facial surgery)' },
  { id: 'swelling', label: 'Rapid one-sided swelling or a tense, enlarging area' },
] as const;
export interface Screen { at: string; by: string; via: 'phone' | 'visit' | 'portal'; answers: Record<string, boolean>; note?: string }
/** Any "yes" escalates: the surgeon is notified now with the answers. It is a routing rule, not an assessment. */
export function screenResult(s: Pick<Screen, 'answers'>): { escalate: boolean; positives: string[]; text: string } {
  const pos = RED_FLAGS.filter(f => s.answers[f.id]).map(f => f.label);
  return { escalate: pos.length > 0, positives: pos, text: pos.length ? `Escalate to the surgeon now: ${pos.join('; ')}` : 'No red-flag symptoms reported' };
}
export type TrackKind = 'question' | 'refill' | 'complication' | 'test' | 'referral';
export const TRACK_LABEL: Record<TrackKind, string> = { question: 'Question', refill: 'Refill request', complication: 'Complication', test: 'Test', referral: 'Referral' };
export interface Tracked { id: string; kind: TrackKind; text: string; at: string; by: string; status: 'open' | 'closed'; owner: 'front' | 'nurse' | 'surgeon'; closedAt?: string; closedBy?: string; resolution?: string }
/** Default routing: refills and complications go to the surgeon, questions and tests to the nurse, referrals to the front desk. */
export const routeTracked = (k: TrackKind): Tracked['owner'] => k === 'refill' || k === 'complication' ? 'surgeon' : k === 'referral' ? 'front' : 'nurse';
export const trackerClear = (t: Tracked[]) => t.every(x => x.status === 'closed');
/** Auto-proposed post-op schedule (practice defaults, editable): days after surgery, with photo milestones from day 7. */
export function proposePostOp(surgeryDate: string, days: number[] = [1, 7, 30, 90]): { pod: number; date: string; photos: boolean }[] {
  const [y, m, d] = surgeryDate.split('-').map(Number);
  return days.map(pod => ({ pod, date: new Date(Date.UTC(y, m - 1, d + pod)).toISOString().slice(0, 10), photos: pod >= 7 }));
}
/** Step 11 interval-events questions (asked once, answers recorded with the date). */
export const INTERVAL_QUESTIONS = [
  { id: 'hosp', q: 'Any hospital stays or ER visits since your last surgery with us?' },
  { id: 'proc', q: 'Any surgeries or procedures elsewhere?' },
  { id: 'newdx', q: 'Any new diagnoses (for example heart, lung, blood clots, diabetes)?' },
  { id: 'meds', q: 'Any new medicines, including blood thinners, supplements or GLP-1 medicines?' },
  { id: 'allergy', q: 'Any new allergies or reactions?' },
  { id: 'preg', q: 'Pregnancy or breastfeeding since your last visit (if applicable)?' },
] as const;
