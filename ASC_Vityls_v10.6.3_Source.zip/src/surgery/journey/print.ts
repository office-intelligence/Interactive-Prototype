/*
 * Surgery.Vityls v1.2 · Face sheet + Avery 5160 labels (pure, unit-tested). Kevin's Oct 17 revisions.
 * Face sheet: name, phone, email, insurance, ID card and insurance card images. Used with pathology / lab samples.
 * Avery 5160 (US Letter): 30 labels per sheet, 3 columns × 10 rows, each 2 5/8" × 1"; top/bottom margin 0.5",
 * left/right margin 3/16" (0.1875"), 1/8" (0.125") gap between columns, no gap between rows. Printing only on export/print.
 */
export const AVERY_5160 = { pageW: 8.5, pageH: 11, cols: 3, rows: 10, labelW: 2.625, labelH: 1, marginTop: 0.5, marginLeft: 0.1875, gapX: 0.125, gapY: 0, perSheet: 30 } as const;
export interface LabelData { name: string; mrn: string; dob: string; age: number | string; provider: string }
export const labelLines = (p: LabelData) => [p.name, `MR# ${p.mrn}`, `DOB ${p.dob} · ${p.age} y`, p.provider];
export interface Pos { page: number; row: number; col: number; x: number; y: number }
/** Positions (inches from the page's top-left) for `count` labels, starting at label number `startAt` (1-30) on the first sheet so a part-used sheet can be reused. */
export function labelPositions(count: number, startAt = 1): Pos[] {
  const A = AVERY_5160; const out: Pos[] = []; const s = Math.min(Math.max(1, Math.floor(startAt)), A.perSheet) - 1;
  for (let k = 0; k < Math.max(0, Math.floor(count)); k++) { const slot = s + k; const page = Math.floor(slot / A.perSheet); const inSheet = slot % A.perSheet; const row = Math.floor(inSheet / A.cols); const col = inSheet % A.cols;
    out.push({ page, row, col, x: +(A.marginLeft + col * (A.labelW + A.gapX)).toFixed(4), y: +(A.marginTop + row * (A.labelH + A.gapY)).toFixed(4) }); }
  return out;
}
const esc = (s: unknown) => String(s ?? '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' } as Record<string, string>)[c]);
export function labelSheetHtml(p: LabelData, count = 30, startAt = 1): string {
  const A = AVERY_5160; const pos = labelPositions(count, startAt); const pages = pos.length ? pos[pos.length - 1].page + 1 : 1; const L = labelLines(p);
  const sheet = (pg: number) => `<div class="sheet">${pos.filter(x => x.page === pg).map(x => `<div class="lbl" style="left:${x.x}in;top:${x.y}in"><b>${esc(L[0])}</b><span>${esc(L[1])}</span><span>${esc(L[2])}</span><span>${esc(L[3])}</span></div>`).join('')}</div>`;
  return `<!doctype html><html><head><meta charset="utf-8"><title>Labels · ${esc(p.name)} (Avery 5160)</title><style>@page{size:letter;margin:0}*{box-sizing:border-box}body{margin:0;font-family:Arial,Helvetica,sans-serif}
.sheet{position:relative;width:${A.pageW}in;height:${A.pageH}in;page-break-after:always;overflow:hidden}.sheet:last-child{page-break-after:auto}
.lbl{position:absolute;width:${A.labelW}in;height:${A.labelH}in;padding:0.08in 0.14in;display:flex;flex-direction:column;justify-content:center;font-size:9pt;line-height:1.2;overflow:hidden}
.lbl b{font-size:10.5pt}@media screen{body{background:#eee}.sheet{background:#fff;margin:12px auto;box-shadow:0 1px 6px rgba(0,0,0,.2)}.lbl{outline:1px dashed #ccc}}</style></head><body>${Array.from({ length: pages }, (_, i) => sheet(i)).join('')}</body></html>`;
}
export interface FaceSheet { practice: string; name: string; dob: string; age: number | string; sex: string; mrn: string; phone: string; email?: string; address?: string; provider: string;
  insurance: { payer: string; member?: string; group?: string; subscriber?: string } | null; payment?: string; idImage?: string; cardFront?: string; cardBack?: string; printedBy: string; printedAt: string }
export function faceSheetHtml(f: FaceSheet): string {
  const img = (src: string | undefined, label: string) => `<figure><div class="ph">${src ? `<img src="${esc(src)}" alt="${esc(label)}">` : '<span>Not on file</span>'}</div><figcaption>${esc(label)}</figcaption></figure>`;
  const row = (k: string, v: unknown) => `<tr><th>${esc(k)}</th><td>${esc(v) || '—'}</td></tr>`;
  return `<!doctype html><html><head><meta charset="utf-8"><title>Face sheet · ${esc(f.name)}</title><style>@page{size:letter;margin:0.6in}body{font-family:Arial,Helvetica,sans-serif;color:#222;font-size:11pt}
h1{font-size:18pt;margin:0}h2{font-size:12pt;margin:18px 0 6px;border-bottom:1px solid #999;padding-bottom:3px}.hd{display:flex;justify-content:space-between;align-items:flex-end;border-bottom:2px solid #222;padding-bottom:8px}
table{border-collapse:collapse;width:100%}th{text-align:left;width:34%;padding:4px 6px;font-weight:600;color:#555}td{padding:4px 6px}tr{border-bottom:1px solid #eee}
.imgs{display:grid;grid-template-columns:1fr 1fr;gap:14px}figure{margin:0}.ph{border:1px solid #bbb;border-radius:3px;height:2.1in;display:flex;align-items:center;justify-content:center;overflow:hidden;background:#fafafa}
.ph img{max-width:100%;max-height:100%}.ph span{color:#999}figcaption{font-size:9pt;color:#555;margin-top:3px}.ft{margin-top:18px;font-size:8.5pt;color:#777}</style></head><body>
<div class="hd"><div><div style="font-size:9pt;color:#666">${esc(f.practice)}</div><h1>Face sheet</h1></div><div style="text-align:right;font-size:10pt"><b>${esc(f.name)}</b><br>MR# ${esc(f.mrn)} · DOB ${esc(f.dob)} (${esc(f.age)} y)</div></div>
<h2>Patient</h2><table>${row('Name', f.name)}${row('Date of birth / age / sex', `${f.dob} · ${f.age} y · ${f.sex}`)}${row('MR#', f.mrn)}${row('Phone', f.phone)}${row('Email', f.email)}${f.address ? row('Address', f.address) : ''}${row('Provider', f.provider)}</table>
<h2>Insurance</h2><table>${f.insurance ? row('Payer', f.insurance.payer) + row('Member ID', f.insurance.member) + row('Group', f.insurance.group) + row('Subscriber', f.insurance.subscriber) : row('Payment', f.payment || 'Self-pay')}</table>
<h2>ID and insurance cards</h2><div class="imgs">${img(f.idImage, 'Photo ID')}${img(f.cardFront, 'Insurance card · front')}${img(f.cardBack, 'Insurance card · back')}</div>
<div class="ft">Printed ${esc(f.printedAt)} by ${esc(f.printedBy)} · for pathology / lab requisitions · fictional test data · printed on request only (no automatic PDF)</div></body></html>`;
}
