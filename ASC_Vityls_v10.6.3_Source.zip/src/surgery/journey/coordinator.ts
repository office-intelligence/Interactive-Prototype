/*
 * Surgery.Vityls v1.2 · Nightingale as the journey coordinator (SIMULATED, scripted, on-device; drafts only, human-approved).
 * - handoff(): the summary card at the top of every step page (recap of the previous step with linked chips, Done, Still open,
 *   ONE Next action with its owner, sources, gaps, confidence and the required reviewer).
 * - drafts for checklist items (clearance requests, chase letters, reminders, instructions, patient messages incl. clinical replies
 *   for staff review), work queues per role ("Your N things today"), overdue escalation, stale / duplicate / contradiction checks,
 *   simulated classification of incoming records with identity + date checks, and "outside range" flags for clinician review.
 * Nightingale never diagnoses, prescribes, gives clearance, signs or finalizes documentation.
 */
import { medRepo, MedPatient, usDate, ageFrom, isoDay } from '../../med/record';
import { getSettings } from '../../med/settings';
import * as J from './logic';
import * as C from './confirm';
import { SJourney, journeys, confirmationsOf, confirmRules, journeyVisit } from './store';
import { activeEpisode, episodesFor } from '../episodes/store';
import * as EL from '../episodes/logic';
import { docsOf } from '../documents';
import { photosOf } from '../media';
import { svRead } from '../store';

export type Seg = string | { chip: string; doc: string; miss?: boolean };
export interface Handoff { title: string; sub: string; paras: Seg[][]; done: string[]; open: { text: string; flags?: string[]; reviewer?: string; icon: '!' | '◷' | '$' }[]; sources: { label: string; doc: string }[]; gaps: string; confidence: 'High' | 'Medium' | 'Low'; confWhy: string; reviewer: string }
const d5 = (iso?: string) => iso ? new Date(iso.length <= 10 ? `${iso}T12:00:00` : iso).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }) : '';
const first = (n: string) => n.replace(/^Dr\.?\s*/, '').split(/[\s,]+/)[0];
export const drName = (n: string) => /,\s*(MD|DO)\b/.test(n) ? `Dr. ${n.replace(/,.*$/, '').replace(/\s*\(fictional\)/, '')}` : n.replace(/\s*\(fictional\)/, '');
const money = (n: number) => `$${n.toLocaleString('en-US', { maximumFractionDigits: 0 })}`;

/** Values outside the lab's own reference range. A flag means exactly that: no interpretation, no go/no-go. */
export function outsideRange(pid: string) {
  return medRepo.labs(pid).filter(l => { const m = String(l.reportedRange || '').match(/([\d.]+)\s*[–-]\s*([\d.]+)/); return m && l.valueNum != null && (l.valueNum < +m[1] || l.valueNum > +m[2]); });
}
export const outsideMeds = (pid: string) => svRead<Record<string, C.Med[]>>('outside-hp-meds', {})[pid] || [];
/** Contradictions between our record and incoming documents (medications, allergies). */
export function contradictions(j: SJourney, p: MedPatient): C.MedDiff[] {
  const ours = medRepo.meds(p.id).filter(m => m.status === 'active').map(m => ({ name: m.name, dose: m.dose }));
  return C.medDiffs(ours, outsideMeds(p.id)).filter(d => d.kind !== 'missing' && !j.x.resolved[`med:${d.theirs?.name}`]);
}
export function lastConfirmedText(pid: string, cat: C.Cat) { return C.lcText(confirmationsOf(pid)[cat]); }

/** The handoff card for a step: what happened before, linked; done; still open; gaps. */
export function handoff(j: SJourney, n: J.StepNo, p: MedPatient): Handoff {
  const ep = activeEpisode(p.id) || episodesFor(p.id)[0]; const path = J.pathFor(j.kind); const idx = path.indexOf(n); const prev = path.slice(Math.max(0, idx - 2), idx);
  const prevDone = prev.flatMap(s => J.completedItems(j, s)); const docs = docsOf(p.id); const pn = first(p.name); const surgeon = drName(p.primaryProvider);
  const v = journeyVisit(j); const note = v ? medRepo.note(v.id) : undefined; const photos = photosOf(p.id).filter(x => !v || x.visitId === v.id || x.date >= j.createdAt.slice(0, 10));
  const paras: Seg[][] = []; const sources: Handoff['sources'] = []; const open: Handoff['open'] = []; let gaps = 'none'; let confidence: Handoff['confidence'] = 'High'; let confWhy = 'Every item matched by name and date of birth'; let reviewer = J.stepDef(n).owners.includes('surgeon') ? 'Surgeon' : J.JOWNER_LABEL[J.stepDef(n).owners[0]];
  const title = idx <= 0 ? (j.kind === 'return' ? `Welcome back · since ${pn}'s last surgery` : 'New request') : prev.length > 1 ? `Since the ${J.stepDef(prev[0]).short.toLowerCase()} (Steps ${prev[0]}–${prev[prev.length - 1]})` : `Since ${J.stepDef(prev[0]).short.toLowerCase()} (Step ${prev[0]})`;
  const consultNote = note?.status === 'signed' ? { chip: `📝 Consult note · signed ${d5(note.signedAt)}`, doc: 'note' } : null;
  if (n === 7 && ep) {
    const quoteDone = ep.items.find(i => i.key === 'quote'); const reqAt = ep.clearance.requestedAt; const recv = Object.entries(ep.clearance.tests).filter(([, s]) => s === 'received').map(([k]) => k); const miss = EL.missingTests(ep);
    const hp = docs.find(x => /outside|h&p|history/i.test(`${x.type} ${x.title}`)); const lab = docs.find(x => /lab/i.test(x.type)); const flagged = outsideRange(p.id);
    paras.push([`${surgeon} saw ${pn} on ${d5(note?.signedAt || ep.createdAt)} for an ${ep.procedure.toLowerCase().replace(/\s*\((open)\)/, ' (open)').replace('rhinoplasty (open)', 'open rhinoplasty')} consult and signed the note `, consultNote || { chip: '📝 Consult note', doc: 'note' }, '. ', ...(photos.length ? [`${photos.length >= 6 ? 'Six' : photos.length} standard views were taken with consent `, { chip: `📷 Photos · ${photos.length} views`, doc: 'photos' } as Seg, '.'] : [])]);
    paras.push([`She accepted `, { chip: `$ ${quoteDone?.note?.replace('Quote accepted · ', 'Quote · ') || 'Quote'}`, doc: 'quote' }, ep.paid > 0 ? ' and paid the deposit ' : '', ...(ep.paid > 0 ? [{ chip: `🧾 Deposit receipt · ${money(Math.min(ep.paid, ep.depositAmount))}`, doc: 'deposit' } as Seg] : []), `. ${ep.clearance.reasons.length ? `Because she is ${ageFrom(p.dob)}${medRepo.problems(p.id).length ? ` with ${medRepo.problems(p.id).map(x => x.description.toLowerCase().replace('type 2 ', '')).join(' and ')}` : ''}, ${surgeon} required clearance.` : ''} `, ...(reqAt ? [`The request went to ${drName(ep.clearance.pcp)} on ${d5(reqAt)} `, { chip: `✉ Clearance request · ${d5(reqAt)}`, doc: 'request' } as Seg, '.'] : [])]);
    if (recv.length) paras.push([`${drName(ep.clearance.pcp)}'s office sent the ${hp ? 'H&P, ' : ''}labs${recv.includes('CXR') ? ' and chest x-ray' : ''} `, ...(hp ? [{ chip: `📄 H&P · ${d5(hp.docDate)}`, doc: hp.id } as Seg, ' '] : []), ...(lab ? [{ chip: `🧪 Labs · ${d5(lab.docDate)}`, doc: 'labs' } as Seg] : []), '. ', ...(miss.length ? [`The ${miss.join(', ')} ${miss.length === 1 ? 'was' : 'were'} not in the packet `, ...miss.map(m => ({ chip: `✕ ${m} · not received`, doc: `missing:${m}`, miss: true } as Seg))] : []), flagged.length ? `${miss.length ? ', and ' : ''}${flagged.length === 1 ? 'one lab value is' : `${flagged.length === 2 ? 'two' : flagged.length} lab values are`} outside the reference range for ${surgeon} to review.` : '.']);
    if (miss.length) { open.push({ text: `${miss.join(', ')} missing from ${drName(ep.clearance.pcp)}'s packet. Last asked ${d5(reqAt)}.`, icon: '!' }); gaps = `${miss.join(', ')} not received`; }
    if (!J.closed(j.items.find(i => i.key === 's7-review') || { status: 'done' } as J.JItem)) open.push({ text: 'Surgeon review of returned results.', flags: flagged.map(l => `✦ ${l.test} ${l.value}`), reviewer: 'Surgeon', icon: '!' });
    if (!ep.asc.sentAt) open.push({ text: `Send package to ${ep.ascName.replace(/\s*\(fictional\)/, '')} (waits on ${miss.length ? 'both above' : 'the review'}).`, icon: '◷' });
    const bal = EL.balanceDue(ep); const bi = ep.items.find(i => i.key === 'balance'); if (bal > 0 && bi) open.push({ text: `Heads-up for Step 8: balance ${money(bal)} due ${new Date(bi.due + 'T12:00:00').toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' })}.`, icon: '$' });
    [['Consult note', 'note'], ['Request', 'request'], ...(hp ? [['H&P', hp.id]] : []), ['Labs', 'labs'], ...(recv.includes('CXR') ? [['CXR', docs.find(x => /imag/i.test(x.type))?.id || 'labs']] : [])].forEach(([l, d]) => sources.push({ label: l, doc: d }));
    if (!recv.length) { confidence = 'Medium'; confWhy = 'Nothing returned yet'; }
  } else {
    // Generic recap from the completed items of the previous steps (who did what, when) + linked documents.
    prev.forEach(s => { const its = J.completedItems(j, s).slice(0, 3); if (its.length) paras.push([`Step ${s} · ${J.stepDef(s).title}: `, its.map(i => `${i.label.toLowerCase().replace(/\s*\(.*?\)/, '')} (${i.doneBy?.replace(/,.*$/, '')}, ${d5(i.doneAt)})`).join('; '), '.']); });
    if (n === 1) paras.push([`${p.name} is a new patient${(p as any).referralSource ? `, ${/referral/i.test((p as any).referralSource) ? `referred by ${(p as any).referredBy ? drName((p as any).referredBy) : 'a colleague'}` : `found the practice through ${(p as any).referralSource}`}` : ''}. ${v ? `${v.visitType} booked for ${usDate(v.date)} at ${v.time} with ${drName(v.provider)}.` : 'No appointment yet.'}`]);
    if (n === 11) { const last = episodesFor(p.id).find(e => e.stage === 'closed'); paras.push([`${pn} had ${last ? `${last.procedure.toLowerCase()} with ${drName(last.surgeon)} on ${usDate(last.surgeryDate)}` : 'surgery here before'} and is back for a ${j.service.toLowerCase()}. Her chart was found by name and date of birth, so no duplicate was created. `, { chip: `📁 Prior surgery & photos`, doc: 'history' }, ` Below, each part of her record shows when it was last confirmed. Only what is older than ${confirmRules().staleMonths} months or never confirmed is asked again.`]); }
    if (consultNote && n > 5) paras.push(['Consult: ', consultNote, ...(photos.length ? [' ', { chip: `📷 Photos · ${photos.length}`, doc: 'photos' } as Seg] : [])]);
    if (ep && n >= 8) paras.push([`${ep.procedure} at ${ep.ascName.replace(/\s*\(fictional\)/, '')} on ${usDate(ep.surgeryDate)}. Paid ${money(ep.paid)} of ${money(ep.totalAmount)}${ep.asc.confirmedAt ? `; the ASC confirmed the package on ${d5(ep.asc.confirmedAt)}` : ''}.`]);
    if (n === 10 && j.x.records.length) paras.push(['Records back from the facility: ', ...j.x.records.map(r => ({ chip: `📄 ${r.kind === 'operative-note' ? 'Op note' : r.kind === 'discharge-summary' ? 'Discharge' : r.kind} · ${r.how}`, doc: `rec:${r.kind}` } as Seg))]);
    J.openItems(j, n).filter(i => J.statusOf(j, i) !== 'blocked').slice(0, 3).forEach(i => open.push({ text: i.label + (i.due ? ` · due ${d5(i.due)}` : ''), icon: i.status === 'waiting' ? '◷' : '!' }));
    if (!paras.length) paras.push([`Nothing has happened yet in this step. ${J.stepDef(n).trigger} opened it.`]);
    sources.push(...docs.slice(0, 3).map(x => ({ label: x.type, doc: x.id })));
    const stale = C.needsFor(C.ALL_CATS, confirmationsOf(p.id), { today: isoDay(), rules: confirmRules() }); if (stale.length && (n === 11 || n === 2 || n === 3)) { gaps = `${stale.length} record part${stale.length === 1 ? '' : 's'} need reconfirming`; confidence = n === 11 ? 'Medium' : confidence; confWhy = n === 11 ? 'Some data is over the practice age limit' : confWhy; }
  }
  const done = prevDone.slice(0, 6).map(i => `${i.label.replace(/\s*\(.*?\)/, '')} · ${i.doneBy?.replace(/,.*$/, '')} · ${d5(i.doneAt)}`);
  return { title, sub: `Nightingale handoff · updated today ${new Date().toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' })} · from ${j.audit.length} chart events and ${docs.length} documents`, paras, done, open, sources, gaps, confidence, confWhy, reviewer };
}

/* ---------------- drafts (always "needs your review"; sending is simulated) ---------------- */
export interface JDraft { kind: string; title: string; to: string; channel: string; body: string; source: string; confidence: 'High' | 'Medium' | 'Low'; reviewer: string }
export function draftFor(key: string, j: SJourney, p: MedPatient, signer: string): JDraft {
  const ep = activeEpisode(p.id); const prac = getSettings().practiceName.replace(/\s*\(fictional\)/, ''); const surgeon = drName(p.primaryProvider); const pcp = drName(ep?.clearance.pcp || 'Primary care physician'); const v = journeyVisit(j); const pn = first(p.name);
  const asc = (ep?.ascName || getSettings().ascName || 'the surgery center').replace(/\s*\(fictional\)/, '');
  const dob = p.dob; const due = ep ? new Date(J.addDaysIso(ep.surgeryDate, -9) + 'T12:00:00').toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' }) : '';
  const B = (kind: string, title: string, to: string, channel: string, body: string, source: string, reviewer = signer, confidence: JDraft['confidence'] = 'High'): JDraft => ({ kind, title, to, channel, body, source, confidence, reviewer });
  if (key.startsWith('s7-t-')) { const t = key.slice(5); const recv = docsOf(p.id).filter(x => /lab|outside|imag/i.test(x.type)); return B(`chase-${t}`, `${t} chase letter to ${pcp}`, `${pcp}, Primary care · fax (555) 014-7701`, 'Fax (simulated)',
    `To: ${pcp}, Primary care · fax (555) 014-7701\nRe: ${p.name} · DOB ${dob} · preoperative clearance\n\nDear ${pcp},\n\nThank you for the ${recv.length ? 'H&P, labs and chest x-ray' : 'help'} for ${p.name}${recv.length ? `, which we received on ${d5(recv[0].receivedAt)}` : ''}. For her ${ep?.procedure.toLowerCase().replace('rhinoplasty (open)', 'open rhinoplasty') || 'surgery'} with ${surgeon} on ${d5(ep?.surgeryDate)}, ${asc} also requires ${t === 'ECG' ? 'a 12-lead ECG from the last 6 months' : `the ${J.CLEARANCE_LABEL[t] || t}`}. It was not in the packet we received.\n\nCould your office fax or securely email the ${t === 'ECG' ? 'ECG tracing and interpretation' : 'result'} by ${due}? If ${pn} still needs one done, please let us know and we will help her schedule it.\n\nThank you,\n${signer}, for ${surgeon}\n(555) 014-2200`,
    `the ${d5(ep?.clearance.requestedAt)} request and ${asc}'s required items`); }
  switch (key) {
    case 's7-request': case 's7-route': return B('clearance-request', 'Preoperative clearance request', `${pcp} · fax + secure email`, 'Fax + secure email (simulated)', `Dear ${pcp},\n\nOur mutual patient ${p.name} (DOB ${dob}) is scheduled for ${ep?.procedure || j.service} with ${surgeon} at ${asc} on ${usDate(ep?.surgeryDate)}.\n\nPlease send by ${due}:\n${(svRead<J.JourneySettings>('journey-settings', J.DEFAULT_JOURNEY_SETTINGS).clearanceTests || J.CLEARANCE_ITEMS).map(t => `  ☐ ${J.CLEARANCE_LABEL[t] || t}`).join('\n')}\n  ☐ Your clearance letter\n\nActive problems: ${medRepo.problems(p.id).map(x => x.description).join(', ') || 'none recorded'}. Medications: ${medRepo.meds(p.id).filter(m => m.status === 'active').map(m => `${m.name} ${m.dose}`).join(', ') || 'none recorded'}. Allergies: ${p.allergies.join(', ') || 'none recorded'}.\n\nThank you,\n${signer}, for ${surgeon}`, 'the consult note, problem list and the practice clearance list');
    case 's1-confirm': return B('appt-confirm', 'Appointment confirmation', `${p.name} · ${p.phone}${p.email ? ` · ${p.email}` : ''}`, 'Text + email (simulated)', `Hi ${pn}, this is ${prac}. You're booked for a ${v?.visitType.toLowerCase() || 'consultation'} with ${surgeon} on ${usDate(v?.date)} at ${v?.time}. Tap to confirm: [Confirm link]. Your new-patient forms are in your Portal. Reply STOP to opt out.`, 'the appointment on the schedule', signer);
    case 's1-intake': case 's2-consents': return B('intake', 'New-patient intake packet', `${p.name} · Portal + text link`, 'Portal + text (simulated)', `Hi ${pn}, please complete before your visit (about 10 minutes): registration, medical history, medications and allergies, consent to treat and HIPAA notice, and photos of your ID and insurance card (front and back). Open your Portal: [Portal link]`, 'the practice intake packet', signer);
    case 's2-records': return B('records', 'Request for outside records', 'Referring / previous provider', 'Fax (simulated)', `Please send recent office notes, medication list and any imaging for ${p.name} (DOB ${dob}) before the visit on ${usDate(v?.date)}. A signed release is on file.`, 'the referral', signer, 'Medium');
    case 's2-reminder': return B('reminder', 'Appointment reminder', `${p.name} · ${p.phone}`, 'Text (simulated)', `Hi ${pn}, a reminder of your visit with ${surgeon} on ${usDate(v?.date)} at ${v?.time}. Reply C to confirm or call us to change it.`, 'the schedule', signer);
    case 's2-instr': return B('previsit-instr', 'Pre-visit instructions', `${p.name}`, 'Text + email (simulated)', `Please arrive 15 minutes early, bring your photo ID and a list of your medicines. No makeup on the area to be examined, please.`, 'the practice template', signer);
    case 's6-instr': case 's8-logistics': return B('preop-instr', 'Pre-op instructions', `${p.name} · ${p.phone}`, 'Text + email (simulated)', `Hi ${pn}, your ${ep?.procedure.toLowerCase() || 'surgery'} is on ${usDate(ep?.surgeryDate)} at ${asc}. Arrive at ${ep?.surgeryTime === '07:30 AM' ? '6:00 AM' : '90 minutes early'}. Nothing to eat or drink after midnight. A responsible adult must drive you home and stay with you the first night. Bring your photo ID. Questions: (555) 014-2200.`, 'the practice instructions template', signer);
    case 's8-final': return B('final-reminder', 'Day-before reminder', `${p.name} · ${p.phone}`, 'Text (simulated, sent the day before)', `Hi ${pn}, your surgery is tomorrow at ${asc}. Arrive at ${ep?.surgeryTime === '08:00 AM' ? '6:30 AM' : '6:00 AM'}. Nothing to eat or drink after midnight. Your ride home is required. See you tomorrow!`, 'the surgery date and the instructions template', signer);
    case 's10-update': return B('postop-instr', 'Updated recovery instructions', `${p.name} · Portal`, 'Portal (simulated)', `Hi ${pn}, from ${surgeon}'s office: keep your head elevated and use cool compresses for 20 minutes at a time. No heavy lifting or bending for 2 weeks. Call us right away for fever over 101 °F, bleeding that soaks the dressing, or vision changes.`, 'the post-op instruction template (the surgeon edits and approves)', 'Surgeon', 'Medium');
    default: return B('message', `Message to ${p.name}`, `${p.name} · Portal`, 'Portal (simulated)', `Hi ${pn}, this is ${prac}. [Staff completes this message.]`, 'the chart', signer, 'Medium');
  }
}
/** Clinical reply to a patient message: drafted for staff review (Kevin approved), staff always review and send. */
export function clinicalReplyDraft(p: MedPatient, question: string, signer: string): JDraft {
  const refill = /refill|ointment|prescription/i.test(question);
  return { kind: 'clinical-reply', title: `Reply to ${first(p.name)}'s portal message`, to: `${p.name} · Portal`, channel: 'Portal (simulated)', source: 'the patient message and the post-op instruction template', confidence: 'Medium', reviewer: refill ? 'Surgeon (refills need a provider)' : signer,
    body: refill ? `Hi ${first(p.name)}, thanks for the update, glad the swelling is going down. We've asked ${drName(p.primaryProvider)} about the refill; you'll get a message when it's sent to your pharmacy. Keep using it as directed until then.` : `Hi ${first(p.name)}, thanks for your message. [Staff completes the clinical answer from the instructions.]` };
}

/* ---------------- incoming records: simulated classification with identity + date checks ---------------- */
export function classify(fileName: string, p: MedPatient): { type: string; test?: string; nameOk: boolean; dobOk: boolean; dateOk: boolean; text: string } {
  const f = fileName.toLowerCase(); const test = /ecg|ekg/.test(f) ? 'ECG' : /cxr|chest|x-?ray/.test(f) ? 'CXR' : /h&p|h_p|history|physical/.test(f) ? 'H&P' : /cbc/.test(f) ? 'CBC' : /cmp|chem/.test(f) ? 'CMP' : /ua\b|urin/.test(f) ? 'UA' : /ptt/.test(f) ? 'PTT' : /\bpt\b|inr/.test(f) ? 'PT' : /op.?note|operative/.test(f) ? undefined : undefined;
  const type = test === 'ECG' ? 'ECG' : test === 'CXR' ? 'Imaging' : test === 'H&P' ? 'Outside records' : test ? 'Laboratory' : /op.?note|operative/.test(f) ? 'Operative report' : /discharge/.test(f) ? 'Outside records' : 'Other';
  return { type, test, nameOk: true, dobOk: true, dateOk: true, text: `Classified as ${type}${test ? ` (${test})` : ''} · name + DOB match ${p.name} · dated within the request window` };
}

/* ---------------- work queues: "Your N things today" ---------------- */
export interface QItem { pid: string; name: string; step: J.StepNo; key: string; label: string; due?: string; overdue: boolean; owner: J.JOwner; why: string }
export function workQueue(owner: J.JOwner | 'all', today = isoDay()): QItem[] {
  const out: QItem[] = [];
  journeys().filter(j => !j.closedAt).forEach(j => { const p = medRepo.patient(j.patientId); if (!p) return;
    J.openItems(j, j.current).filter(i => J.statusOf(j, i) === 'open' && (owner === 'all' || i.owner === owner) && i.owner !== 'asc' && i.owner !== 'patient')
      .forEach(i => out.push({ pid: p.id, name: p.name, step: j.current, key: i.key, label: i.label, due: i.due, overdue: !!i.due && i.due < today, owner: i.owner, why: i.due ? (i.due < today ? `overdue since ${d5(i.due)}` : `due ${d5(i.due)}`) : `Step ${j.current} · ${J.stepDef(j.current).short}` })); });
  return out.sort((a, b) => Number(b.overdue) - Number(a.overdue) || (a.due || '9999').localeCompare(b.due || '9999'));
}
/** Overdue escalation: anything past due in an active step, with who it escalates to. */
export function escalations(today = isoDay()) {
  return journeys().filter(j => !j.closedAt).flatMap(j => J.overdue(j, today).map(i => ({ pid: j.patientId, label: i.label, due: i.due!, to: i.owner === 'surgeon' ? 'Surgeon' : 'Practice manager', owner: i.owner })));
}
/** Duplicate check (name + DOB, or phone) used by Step 1 / Step 11. */
export function duplicates(p: MedPatient) {
  const nm = (s: string) => s.toLowerCase().replace(/[^a-z]/g, '');
  return medRepo.patients().filter(x => x.id !== p.id && ((nm(x.name) === nm(p.name) && x.dob === p.dob) || (x.phone && x.phone === p.phone)));
}
/** Composer answers on a step page (scripted demo words + a general fallback). */
export function stepAnswer(q: string, j: SJourney, n: J.StepNo, p: MedPatient): { kind: string; html: string } {
  const s = q.toLowerCase(); const ep = activeEpisode(p.id);
  if (/ecg|ekg/.test(s)) return { kind: 'ecg', html: '' };
  if (/lab|glucose|potass|cbc|cmp/.test(s)) { const f = outsideRange(p.id); return { kind: 'labs', html: f.length ? `From the lab report: ${f.map((l, i) => `<b>${l.test.toLowerCase()} ${l.value} ${l.unit || ''}</b> (reference ${l.reportedRange}) <span class="cit" data-doc="labs" data-mark="${l.id}">${i + 1}</span>`).join(' and ')} ${f.length === 1 ? 'is' : 'are'} outside the lab's range. The rest is within range. I've listed these for ${drName(p.primaryProvider)}'s review; I don't interpret them or advise on surgery.` : 'No results outside the lab\'s range on file.' }; }
  if (/asc|harbor|package|facility/.test(s)) { const miss = [...(ep ? EL.missingTests(ep) : []).map(t => `${t} (not received)`), ...(J.closed(j.items.find(i => i.key === 's7-review') || ({ status: 'done' } as J.JItem)) ? [] : ['Documented surgeon review of results'])];
    return { kind: 'asc', html: `${(ep?.ascName || 'The ASC').replace(/\s*\(fictional\)/, '')}'s required list: ${miss.length ? `still needed:<ul>${miss.map(m => `<li>${m}</li>`).join('')}</ul>The package can go once those are done.` : ep?.asc.sentAt ? 'the package has been sent.' : 'nothing is missing. The package is ready to send.'}` }; }
  const next = J.nextAction(j, n); const c = J.counts(j, n);
  return { kind: 'general', html: `${p.name} is at Step ${n} · ${J.stepDef(n).title}. ${c.open} open, ${c.waiting} waiting, ${c.blocked} blocked. ${next ? `Next: <b>${next.label}</b> (${J.JOWNER_LABEL[next.owner]}).` : 'Nothing open.'}` };
}
