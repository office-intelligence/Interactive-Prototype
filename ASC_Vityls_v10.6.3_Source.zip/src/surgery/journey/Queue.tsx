/* v1.2 P5 · Nightingale as coordinator: "Your N things today" (role queue from every active journey), overdue escalations,
   and each line's source + reviewer. Scripted and on-device; it organizes and drafts, never decides. */
import React, { useEffect, useState } from 'react';
import './journey.css';
import { medRepo } from '../../med/record';
import { useActor, useMedTick } from '../../med/ui';
import { useSv } from '../ui';
import * as J from './logic';
import { workQueue, escalations } from './coordinator';
import { syncJourney, journeys } from './store';

export const JourneyQueue: React.FC = () => {
  useMedTick(); const [actor] = useActor(); const { go } = useSv(); const [all, setAll] = useState(false);
  useEffect(() => { journeys().filter(j => !j.closedAt).forEach(j => syncJourney(j.patientId)); }, []);
  const me = J.ROLE_TO_OWNER(actor.role); const owner = all || me === 'asc' || me === 'patient' ? 'all' : me;
  const q = workQueue(owner); const esc = escalations();
  if (!q.length && !esc.length) return null;
  return <div className="jy" style={{ background: 'transparent', marginBottom: 14 }}><section className="card sec" data-testid="jy-queue">
    <div className="sh2"><h2><span className="si att">✦</span>{owner === 'all' ? `${q.length} things today across the team` : `Your ${q.length} thing${q.length === 1 ? '' : 's'} today`}</h2><span className="aitag">✦ Sorted by Nightingale</span>
      <div className="r"><button type="button" className="btn sm" onClick={() => setAll(!all)} data-testid="jy-queue-all">{owner === 'all' && !all ? 'Everyone' : all ? 'Only mine' : 'Everyone'}</button></div>
      <div className="sd">From every active surgery journey. Overdue first. Source: each patient's checklist · Reviewer: the item's owner.</div></div>
    {esc.length > 0 && <div className="rolehint on" data-testid="jy-escalations"><b>{esc.length} overdue</b> · escalated to {[...new Set(esc.map(e => e.to))].join(' and ')}: {esc.slice(0, 3).map(e => `${medRepo.patient(e.pid)?.name} (${e.label.toLowerCase()})`).join('; ')}</div>}
    <div className="att-list">{q.slice(0, 8).map(x => <div className="ai-row" key={x.pid + x.key} data-testid="jy-queue-row"><span className="ico">{x.overdue ? '!' : '→'}</span>
      <div><div className="tt">{x.name} · {x.label}</div><div className="ds">Step {x.step} · {J.stepDef(x.step).short} · {J.JOWNER_LABEL[x.owner]} · {x.why}</div></div>
      <span className={`chip2 ${x.overdue ? 'k-miss' : 'k-due'}`}>{x.overdue ? 'Overdue' : 'Open'}</span><button type="button" className="btn sm pri" style={{ minHeight: 44 }} onClick={() => go({ type: 'episode', pid: x.pid })}>Open</button></div>)}</div>
    {q.length > 8 && <div className="fine">+{q.length - 8} more on the Surgeries page.</div>}
  </section></div>;
};
