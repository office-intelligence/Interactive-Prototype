/*
 * Surgery.Vityls v1.2 · Patient Journey: browser-storage repository (swap point for Henry's API), chart-fact sync and seed.
 * One journey per patient per service. The v1.1 surgical episode still holds surgery data (payments, clearance tests, ASC, post-op);
 * chartFacts() reads the chart + episode and closes matching journey items, attributed to whoever did the work.
 * Every write is audited. Fictional data only; nothing external is sent (text/email/fax/ASC/payments are simulated).
 */
import { repo } from '../../v6/dataLayer';
import { medRepo, MedPatient, patientKey, uid, isoDay, addDays, ageFrom } from '../../med/record';
import { svRead, svWrite } from '../store';
import { getSettings } from '../../med/settings';
import * as J from './logic';
import * as C from './confirm';
import * as G from './gaps';
import * as EL from '../episodes/logic';
import { episodesFor, activeEpisode, mutate as mutateEpisode, saveEpisode, episodeSettings, MARY, CAROL, conditionsOf } from '../episodes/store';

export interface DraftRec { id: string; kind: string; title: string; to: string; channel: string; body: string; status: 'draft' | 'sent' | 'discarded'; at: string; by: string; source: string; confidence: 'High' | 'Medium' | 'Low'; reviewer: string; itemKey?: string; approvedBy?: string; approvedAt?: string }
export interface JExtra { acks: G.Ack[]; dayEvents: G.DayEvent[]; records: G.FacilityRecord[]; screens: G.Screen[]; tracked: G.Tracked[]; marks: Record<string, C.Mark>; interval: Record<string, { answer: 'yes' | 'no'; detail?: string; at: string; by: string }>;
  drafts: DraftRec[]; resolved: Record<string, { at: string; by: string; choice: string }>; ascReply?: { at: string; text: string }; disposition?: { value: string; at: string; by: string } }
export type SJourney = J.Journey & { x: JExtra };
const EMPTY = (): JExtra => ({ acks: [], dayEvents: [], records: [], screens: [], tracked: [], marks: {}, interval: {}, drafts: [], resolved: {} });
const K = 'journeys';
export const jSettings = (): J.JourneySettings => ({ ...J.DEFAULT_JOURNEY_SETTINGS, ...svRead<Partial<J.JourneySettings>>('journey-settings', {}) });
export function saveJSettings(s: J.JourneySettings, by: string, role: string, what: string) { svWrite('journey-settings', s); repo.audit({ caseId: 'practice', user: by, role, action: 'settings.journey' as any, detail: what }); }
export const journeys = (): SJourney[] => svRead<SJourney[]>(K, []).map(j => ({ ...j, x: { ...EMPTY(), ...(j.x || {}) } }));
export const journeysFor = (pid: string) => journeys().filter(j => j.patientId === pid).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
export const journeyFor = (pid: string) => journeysFor(pid).find(j => !j.closedAt);
export function saveJourney(j: SJourney, by: string, role: string, what: string): SJourney {
  const all = journeys(); const i = all.findIndex(x => x.id === j.id); if (i >= 0) all[i] = j; else all.push(j); svWrite(K, all);
  repo.audit({ caseId: patientKey(j.patientId), user: by, role, action: 'journey.update' as any, detail: `${j.service}: ${what}` }); return j;
}
export const who = (by: string, role: string): J.Who => ({ by, role, at: new Date().toISOString() });
/** Apply a journey mutation, then let chart facts + the complete-when rules advance the step. */
export function mutateJ(pid: string, f: (j: SJourney) => SJourney, by: string, role: string, what: string): SJourney {
  const j = journeyFor(pid); if (!j) throw new Error('No active journey'); const n = f(j);
  return saveJourney(syncOnce(n), by, role, what);
}

/* ---------------- confirmations (per patient) ---------------- */
export const confirmationsOf = (pid: string): C.Confirmations => svRead<Record<string, C.Confirmations>>('confirmations', {})[pid] || {};
export function confirmCats(pid: string, cats: C.Cat[], by: string, role: string, via: C.Via = 'staff', at = new Date().toISOString()) {
  const all = svRead<Record<string, C.Confirmations>>('confirmations', {}); all[pid] = C.confirmGroup(all[pid] || {}, cats, { at, by, via }); svWrite('confirmations', all);
  repo.audit({ caseId: patientKey(pid), user: by, role, action: 'data.confirm' as any, detail: `All still correct: ${cats.map(c => C.CAT_LABEL[c]).join(', ')}${via === 'portal' ? ' (patient, Portal)' : ''}` });
}
export const confirmRules = (): C.Rules => { const s = jSettings(); return { staleMonths: s.staleMonths, checkpointFreshDays: s.checkpointFreshDays }; };

/* ---------------- chart facts → journey items ---------------- */
type Fact = { by: string; at: string; note?: string };
const epHist = (ep: EL.Episode, re: RegExp): Fact | undefined => { const h = ep.history.find(x => re.test(x.what)); return h ? { by: h.by, at: h.at } : undefined; };
const epItem = (ep: EL.Episode, key: string): Fact | undefined => { const i = ep.items.find(x => x.key === key); return i && (i.status === 'done') && i.doneAt ? { by: i.doneBy || 'Staff', at: i.doneAt, note: i.note } : undefined; };
export function journeyVisit(j: J.Journey) { const vs = medRepo.visits(j.patientId).filter(v => v.date >= j.createdAt.slice(0, 10) && !/post-op/i.test(v.visitType)); return vs[0]; }
export function chartFacts(j: SJourney): Record<string, Fact | undefined> {
  const p = medRepo.patient(j.patientId); if (!p) return {}; const f: Record<string, Fact | undefined> = {}; const sp = p as MedPatient & Record<string, any>;
  const c = confirmationsOf(p.id); const base: Fact = { by: j.createdBy, at: j.createdAt };
  f.profile = base; if (p.phone) f.contact = base; if (sp.referralSource) f.referral = { ...base, note: sp.referralSource }; if (sp.paymentType || p.insurance) f.paytype = { ...base, note: sp.paymentType || p.insurance };
  (['demographics', 'history', 'medications', 'allergies', 'id', 'contact'] as C.Cat[]).forEach(k => { const lc = c[k]; const need = C.needFor(k, c, { today: isoDay(), rules: confirmRules(), checkpoint: k === 'id' ? 'first-arrival' : k === 'allergies' ? 'rooming' : undefined });
    if (lc && !need) f[`cf-${k}`] = { by: lc.by, at: lc.at, note: lc.via === 'portal' ? 'confirmed by the patient in the Portal' : 'confirmed' }; });
  const v = journeyVisit(j);
  if (v) { f.reason = { by: v.createdBy, at: v.createdAt, note: v.reason }; f.appt = { by: v.createdBy, at: v.createdAt, note: `${v.visitType} · ${v.date} ${v.time}` };
    const facts = repo.getFacts(v.id); const st = v.step; const stamp = (k: string): Fact | undefined => facts[k]?.value ? { by: (facts[k] as any).by || 'Front desk', at: (facts[k] as any).at || v.date } : undefined;
    const past = (s: string) => ['scheduled', 'check-in', 'rooming', 'provider', 'checkout', 'complete'].indexOf(st) > ['scheduled', 'check-in', 'rooming', 'provider', 'checkout', 'complete'].indexOf(s);
    f.arrived = stamp('visit.arrived') || (past('scheduled') ? { by: 'Front desk', at: v.date } : undefined);
    f['checked-in'] = stamp('visit.checkedIn') || (past('check-in') ? { by: 'Front desk', at: v.date } : undefined);
    if (f.arrived) f['forms-done'] = f['forms-done'] || f.arrived;
    const vit = medRepo.vitals(p.id).find(x => x.visitId === v.id); if (vit) f.vitals = { by: vit.by, at: vit.at };
    f.roomed = stamp('visit.roomed') || (past('rooming') ? { by: vit?.by || 'Nurse', at: vit?.at || v.date } : undefined);
    if (past('rooming')) f['ready-for-md'] = f.roomed;
    const n = medRepo.note(v.id); if (n) { f['md-opened'] = { by: n.updatedBy, at: n.updatedAt }; f.scribe = f['md-opened']; f['note-draft'] = f['md-opened']; }
    if (n?.status === 'signed') f['note-signed'] = { by: n.signedBy || n.updatedBy, at: n.signedAt || n.updatedAt };
  }
  if (j.x.disposition) f.disposition = { by: j.x.disposition.by, at: j.x.disposition.at, note: j.x.disposition.value };
  const ep = (j.episodeId && episodesFor(p.id).find(e => e.id === j.episodeId)) || activeEpisode(p.id);
  if (ep) {
    f.quote = epItem(ep, 'quote') || epHist(ep, /quote/i); f['quote-accepted'] = epItem(ep, 'quote'); f.booked = { by: ep.createdBy, at: ep.createdAt, note: `${ep.procedure} · ${ep.surgeryDate} · ${ep.ascName}` };
    if (ep.paid > 0) f.invoice = epHist(ep, /Payment/); if (EL.balanceDue(ep) <= 0) f['paid-full'] = epItem(ep, 'balance') || epHist(ep, /Payment/);
    if (ep.clearance.requestedAt) f['clr-requested'] = { by: epItem(ep, 'clr-request')?.by || 'Staff', at: ep.clearance.requestedAt, note: `sent to ${ep.clearance.pcp}` };
    Object.entries(ep.clearance.tests).forEach(([t, s]) => { if (s === 'received') f[`clr-${t}`] = epHist(ep, new RegExp(`Clearance received:.*\\b${t}\\b`)) || { by: 'Staff', at: ep.createdAt }; });
    f['clr-reviewed'] = epItem(ep, 'clr-review'); if (ep.asc.sentAt) f['asc-sent'] = epItem(ep, 'asc-send') || { by: 'Staff', at: ep.asc.sentAt };
    if (ep.asc.confirmedAt) f['asc-confirmed'] = { by: ep.ascName, at: ep.asc.confirmedAt, note: 'package complete' };
    f['rx-signed'] = epItem(ep, 'rx'); f['final-reminder'] = epItem(ep, 'instructions'); f['postop-booked'] = epItem(ep, 'postop-book');
    if (!ep.clearance.required || J.completeCheck(j, 7).ok) f['clearance-complete'] = { by: 'Vityls', at: new Date().toISOString(), note: ep.clearance.required ? 'Step 7 complete' : 'clearance not required' };
  }
  if (G.missingAcks(j.x.acks).length === 0 && j.x.acks.length) { const a = j.x.acks[j.x.acks.length - 1]; f['ack-financial'] = { by: a.by, at: a.at }; f['ack-procedural'] = { by: a.by, at: a.at }; }
  if (G.recordsReconciled(j.x.records)) { const r = j.x.records[j.x.records.length - 1]; f['op-records'] = { by: r.by, at: r.at, note: 'op note + discharge summary reconciled' }; }
  if (j.x.screens.length) { const s = j.x.screens[j.x.screens.length - 1]; f['redflag-screened'] = { by: s.by, at: s.at, note: G.screenResult(s).text }; }
  if (j.x.tracked.length && G.trackerClear(j.x.tracked)) f['tracker-clear'] = { by: 'Vityls', at: new Date().toISOString(), note: 'no open questions, refills or complications' };
  if (j.kind === 'return') { if (Object.keys(j.x.marks).length && C.reconciled(j.x.marks)) f['marks-done'] = { by: 'Staff', at: new Date().toISOString() }; if (Object.keys(j.x.interval).length >= G.INTERVAL_QUESTIONS.length) f.interval = { by: Object.values(j.x.interval)[0].by, at: Object.values(j.x.interval)[0].at }; }
  return f;
}
function syncOnce(j: SJourney): SJourney { const n = J.advance(J.applyFacts(j, chartFacts(j)), { by: 'Vityls', role: 'System', at: new Date().toISOString() }) as SJourney; return { ...n, x: j.x }; }
/** Called when a journey page opens: picks up work done on other screens (stations, scheduler, payments, episode). */
export function syncJourney(pid: string): SJourney | undefined {
  const j = journeyFor(pid); if (!j) return undefined; const n = syncOnce(j);
  if (JSON.stringify(n.items) !== JSON.stringify(j.items) || n.current !== j.current) { const all = journeys(); const i = all.findIndex(x => x.id === j.id); all[i] = n; svWrite(K, all); }
  return n;
}

/* ---------------- start a journey ---------------- */
export function startJourney(p: MedPatient, x: { service: string; kind?: 'new' | 'return'; startAt?: J.StepNo; episodeId?: string; surgeryDate?: string }, by: string, role: string, at = new Date().toISOString()): SJourney {
  const kind = x.kind || (journeysFor(p.id).some(j => j.closedAt) || episodesFor(p.id).some(e => e.stage === 'closed') ? 'return' : 'new');
  const age = ageFrom(p.dob); const conditions = conditionsOf(p.id); const rule = episodeSettings().rule;
  const ctx: J.TailorCtx = { age, conditions, procedure: x.service, payment: (p as any).paymentType || p.insurance, returning: kind === 'return', clearance: J.clearanceSuggested(age, conditions, rule.minAge, rule.conditions), anticoag: medRepo.meds(p.id).some(m => /warfarin|apixaban|clopidogrel|rivaroxaban/i.test(m.name)) };
  const j = J.buildJourney({ id: uid('jy'), patientId: p.id, kind, service: x.service, ctx, createdAt: at, createdBy: by, role, episodeId: x.episodeId, surgeryDate: x.surgeryDate, startAt: x.startAt }, jSettings());
  return saveJourney({ ...j, x: EMPTY() }, by, role, `journey started (${kind})`);
}
/** Link a booked surgery (episode) to the journey: due dates follow the surgery date; Step 7 turns on/off with the surgeon's clearance decision. */
export function linkEpisode(pid: string, ep: EL.Episode, by: string, role: string) {
  const j = journeyFor(pid); if (!j) return; const ctx = { ...j.ctx, clearance: ep.clearance.required, procedure: ep.procedure };
  const fresh = J.buildJourney({ id: j.id, patientId: pid, kind: j.kind, service: ep.procedure, ctx, createdAt: j.createdAt, createdBy: j.createdBy, surgeryDate: ep.surgeryDate }, jSettings());
  const items = fresh.items.map(i => j.items.find(o => o.key === i.key) ? { ...j.items.find(o => o.key === i.key)!, due: i.due } : i).concat(j.items.filter(o => o.followUpOf));
  saveJourney({ ...j, ctx, service: ep.procedure, episodeId: ep.id, surgeryDate: ep.surgeryDate, items, steps: j.steps.map(s => s.n === 7 ? { ...s, state: ep.clearance.required ? (s.state === 'skipped' ? 'upcoming' : s.state) : 'skipped' } : s) }, by, role, `surgery linked: ${ep.procedure} on ${ep.surgeryDate}`);
}

/* ---------------- Step 7 actions mirrored into the episode ---------------- */
const now = () => new Date().toISOString();
export function receiveClearance(pid: string, tests: string[], by: string, role: string, note: string) {
  const ep = activeEpisode(pid); const epTests = tests.filter(t => t !== 'H&P');
  if (ep && epTests.length) mutateEpisode(ep.id, e => EL.receiveTests(e, epTests.filter(t => t in e.clearance.tests), by, now()), by, role, `clearance received: ${epTests.join(', ')}`);
  return mutateJ(pid, j => tests.reduce((x, t) => { const k = `s7-t-${t}`; const it = x.items.find(i => i.key === k); if (!it || J.closed(it)) return x; try { return { ...J.complete(x, k, who(by, role), note), x: j.x } as SJourney; } catch { return x; /* v1.5 D: the v1.2 engine's blockers never stop the user; the 7-step flow tracks what is open */ } }, j), by, role, `received ${tests.join(', ')}`);
}
export function surgeonReview(pid: string, by: string, role: string, note: string) {
  const ep = activeEpisode(pid); if (ep) { const it = ep.items.find(i => i.key === 'clr-review'); if (it && EL.isOpen(it)) mutateEpisode(ep.id, e => EL.setItem(e, 'clr-review', 'done', by, now(), note), by, role, 'surgeon reviewed clearance (PIN)'); }
  return mutateJ(pid, j => ({ ...J.complete(j, 's7-review', who(by, role), note, 'reviewed'), x: j.x }), by, role, 'surgeon review signed (PIN)');
}
export function sendToAsc(pid: string, by: string, role: string, docs: number) {
  const ep = activeEpisode(pid); if (ep) mutateEpisode(ep.id, e => EL.setItem({ ...e, asc: { ...e.asc, sentAt: now(), missing: [] } }, 'asc-send', 'done', by, now(), `${docs} documents (simulated)`), by, role, 'package sent to ASC (simulated)');
  return syncJourney(pid);
}
export function ascConfirmed(pid: string, text: string) {
  const ep = activeEpisode(pid); if (ep) mutateEpisode(ep.id, e => EL.setItem({ ...e, asc: { ...e.asc, confirmedAt: now(), missing: [] } }, 'asc-confirm', 'done', e.ascName, now(), 'package complete (simulated)'), 'ASC (simulated)', 'ASC', 'ASC confirmed package');
  const j = journeyFor(pid); if (j) saveJourney({ ...j, x: { ...j.x, ascReply: { at: now(), text } } }, 'ASC (simulated)', 'ASC', 'ASC reply recorded');
  return syncJourney(pid);
}
export function addDraft(pid: string, d: Omit<DraftRec, 'id' | 'status' | 'at'>) { const j = journeyFor(pid); if (!j) return; const rec: DraftRec = { ...d, id: uid('dr'), status: 'draft', at: now() }; saveJourney({ ...j, x: { ...j.x, drafts: [...j.x.drafts.filter(x => !(x.kind === d.kind && x.status === 'draft')), rec] } }, 'Nightingale (simulated)', 'AI', `draft: ${d.title}`); return rec; }
export function setDraft(pid: string, id: string, status: DraftRec['status'], by: string, role: string, body?: string) {
  const j = journeyFor(pid); if (!j) return; saveJourney({ ...j, x: { ...j.x, drafts: j.x.drafts.map(d => d.id === id ? { ...d, status, ...(body != null ? { body } : {}), ...(status === 'sent' ? { approvedBy: by, approvedAt: now() } : {}) } : d) } }, by, role, `draft ${status}${status === 'sent' ? ' (approved by staff, simulated send)' : ''}`);
}
export const setX = (pid: string, f: (x: JExtra) => JExtra, by: string, role: string, what: string) => mutateJ(pid, j => ({ ...j, x: f(j.x) }), by, role, what);

/* ---------------- seed (all fictional; no real doctors) ---------------- */
export const SEED_PATIENTS = { NORA: 'MED-2061', DANIEL: 'MED-2062', OLIVIA: 'MED-2063', MARCUS: 'MED-2064' } as const;
export function ensureJourneySeed() {
  if (svRead<boolean>('journeys-seeded-v12', false)) return;
  const T = isoDay(); const iso = (d: number, h = '10:00') => new Date(`${addDays(T, d)}T${h}:00`).toISOString(); const PATEL = 'Sam Patel, MD';
  const ASC = getSettings().ascName || 'Harborview Surgery Center (fictional)'; const pcp = { name: 'Elena Marsh, MD (fictional)', role: 'Primary care (outside)', phone: '(555) 014-7700' };
  const W = (by: string, role: string, d: number, h = '10:00'): J.Who => ({ by, role, at: iso(d, h) });
  const mk = (id: string, name: string, dob: string, sex: MedPatient['sex'], extra: Record<string, unknown> = {}) => { if (!medRepo.patient(id)) medRepo.savePatient({ id, name, dob, sex, phone: '(555) 014-' + id.slice(-4), email: name.toLowerCase().replace(' ', '.') + '@example.test', language: 'English', allergies: [], allergiesConfirmedAt: iso(-3), allergiesConfirmedBy: 'Patient (Portal)', primaryProvider: PATEL, careTeam: [{ name: PATEL, role: 'Surgeon' }, pcp], insurance: 'Self-pay (cosmetic)', fictional: true, paymentType: 'Self-pay', ...extra } as MedPatient); };
  const done = (j: SJourney, keys: string[], w: J.Who, note?: string): SJourney => keys.reduce((x, k) => { const it = x.items.find(i => i.key === k); if (!it || J.closed(it)) return x; try { return { ...J.complete(x, k, w, note), x: x.x } as SJourney; } catch { return x; } }, j);
  const finish = (j: SJourney, n: J.StepNo, w: J.Who): SJourney => done(j, J.stepItems(j, n).filter(i => !i.followUpOf).map(i => i.key), w);
  const walk = (j: SJourney, upto: J.StepNo, ws: Partial<Record<number, J.Who>>): SJourney => { let x = j; for (const n of J.pathFor(j.kind)) { if (n === upto) break; if (J.stepState(x, n) === 'skipped') continue; x = finish(finish(x, n, ws[n]!), n, ws[n]!); x = { ...J.advance(x, ws[n]!), x: x.x } as SJourney; } return x; };
  const all: SJourney[] = []; const conf = svRead<Record<string, C.Confirmations>>('confirmations', {});
  const cf = (pid: string, cats: C.Cat[], by: string, d: number, via: C.Via = 'staff') => { conf[pid] = C.confirmGroup(conf[pid] || {}, cats, { at: iso(d), by, via }); };

  // Mary James · Step 7 exactly as the approved mockup (ECG missing, glucose 168 / K 3.3 flagged, metformin ER contradiction, balance due in 2 days)
  const mary = medRepo.patient(MARY);
  if (mary) {
    medRepo.savePatient({ ...mary, dob: `03/08/${new Date().getFullYear() - 55 - (new Date() < new Date(`${new Date().getFullYear()}-03-08`) ? 1 : 0)}`, address: '412 Seabright Ave, Santa Cruz, CA 95062 (fictional)' } as MedPatient);
    const ep = activeEpisode(MARY);
    let j: SJourney = { ...J.buildJourney({ id: 'jy-mary', patientId: MARY, kind: 'new', service: 'Rhinoplasty (open)', ctx: { age: 55, conditions: ['hypertension', 'diabetes'], procedure: 'Rhinoplasty (open)', payment: 'Self-pay', clearance: true }, createdAt: iso(-27, '09:10'), createdBy: 'Taylor Brooks', role: 'Front desk', episodeId: ep?.id, surgeryDate: ep?.surgeryDate || addDays(T, 16) }, jSettings()), x: EMPTY() };
    j = walk(j, 7, { 1: W('Taylor Brooks', 'Front desk', -27, '09:20'), 2: W('Taylor Brooks', 'Front desk', -20), 3: W('Taylor Brooks', 'Front desk', -18, '09:48'), 4: W('Casey Morgan, RN', 'RN', -18, '09:58'), 5: W(PATEL, 'Plastic surgeon', -18, '16:12'), 6: W('Riley Shaw', 'Surgical Coordinator', -17) });
    j = done(j, ['s7-request', 's7-route'], W('Casey Morgan, RN', 'RN', -17), 'fax + secure email to Dr. Elena Marsh · drafted by Nightingale');
    j = done(j, ['s7-t-H&P', 's7-t-CBC', 's7-t-CMP', 's7-t-UA', 's7-t-PT', 's7-t-PTT', 's7-t-CXR', 's7-classify'], W('Taylor Brooks', 'Front desk', -4, '11:30'), 'classified by Nightingale · matched to the request');
    j = done(j, ['s7-verify'], W('Riley Shaw', 'Surgical Coordinator', -3), 'checked by Nightingale · confirmed by staff');
    j = done(j, ['s7-abn'], W('Riley Shaw', 'Surgical Coordinator', -3), '2 values outside range listed for surgeon review; ECG missing');
    j = { ...j, x: { ...j.x, acks: (['procedural', 'financial', 'cancellation', 'refund'] as G.AckKind[]).map(k => ({ kind: k, text: G.ACK_TEXT[k], at: iso(-18, '16:40'), by: 'Mary James', via: 'in-office' as const, quoteVersion: 2 })), disposition: { value: 'proceeding', at: iso(-18, '16:12'), by: PATEL } } };
    all.push(j);
    cf(MARY, ['demographics', 'contact', 'insurance', 'pharmacy', 'prefs'], 'Mary James', -21, 'portal'); cf(MARY, ['id'], 'Taylor Brooks', -18, 'in-person');
    cf(MARY, ['history', 'diagnoses', 'surgeries', 'specialists'], PATEL, -18); cf(MARY, ['medications', 'allergies'], 'Casey Morgan, RN', -18); cf(MARY, ['consents'], 'Mary James', -18, 'in-person');
    // returned clearance labs (fictional)
    const lab = (id: string, test: string, value: string, num: number, unit: string, range: string) => medRepo.saveLab({ id, patientId: MARY, test, value, valueNum: num, unit, reportedRange: range, collectedAt: iso(-6, '07:40'), enteredAt: iso(-4, '11:30'), enteredBy: 'Taylor Brooks', source: 'Coastal Lab (fictional) · ordered by Dr. Elena Marsh · clearance packet', problemIds: [] } as any);
    lab('lab-mj-glu', 'Glucose', '168', 168, 'mg/dL', '70–99'); lab('lab-mj-k', 'Potassium', '3.3', 3.3, 'mmol/L', '3.5–5.1'); lab('lab-mj-na', 'Sodium', '139', 139, 'mmol/L', '135–145'); lab('lab-mj-cr', 'Creatinine', '0.9', 0.9, 'mg/dL', '0.6–1.1');
    lab('lab-mj-hgb', 'Hemoglobin', '13.4', 13.4, 'g/dL', '12.0–15.5'); lab('lab-mj-plt', 'Platelets', '241', 241, 'K/µL', '150–400'); lab('lab-mj-pt', 'PT / INR', '12.1 s / 1.0', 12.1, 's', '11–13.5'); lab('lab-mj-ptt', 'PTT', '29', 29, 's', '25–35'); lab('lab-mj-ua', 'Urinalysis', 'negative', 0, '', 'negative');
    if (ep) { const pcpMeds = { hpMeds: [{ name: 'Lisinopril', dose: '10 mg' }, { name: 'Metformin ER', dose: '750 mg' }] }; svWrite('outside-hp-meds', { ...svRead<Record<string, unknown>>('outside-hp-meds', {}), [MARY]: pcpMeds.hpMeds }); }
    // Mary's filed documents, as in the mockup (fictional): H&P (lists metformin ER 750), labs, CXR report, and the sent clearance request.
    const D = (id: string, type: string, title: string, source: string, d: number, text: string, by = 'Taylor Brooks', role = 'Front desk') => ({ id, patientId: MARY, type, title, source, docDate: addDays(T, d), receivedAt: iso(-4, '11:30'), receivedBy: by, receivedRole: role, description: 'Classified by Nightingale · name + DOB matched (simulated)', text, example: true });
    const docs = svRead<any[]>('documents', []).filter(x => !String(x.id).startsWith('doc-mj-'));
    svWrite('documents', [...docs,
      D('doc-mj-hp', 'Outside records', 'History & physical', 'Dr. Elena Marsh (fictional)', -7, 'History & physical · Mary James · DOB 03/08\nProblems: hypertension, type 2 diabetes.\nMedications: Lisinopril 10 mg daily; Metformin ER 750 mg daily.\nAllergies: sulfa (rash).\nExam documented. 4 pages (simulated).'),
      D('doc-mj-labs', 'Laboratory', 'CBC, CMP, UA, PT/PTT', 'Coastal Lab (fictional)', -6, 'Lab report (simulated). See the results table.'),
      D('doc-mj-cxr', 'Imaging', 'Chest x-ray report', 'Coastal Imaging (fictional)', -6, 'Chest x-ray, 2 views. Radiologist report filed (simulated).'),
      D('doc-mj-req', 'Sent', 'Clearance request', 'To Dr. Elena Marsh', ep?.clearance.requestedAt ? J.daysBetween(T, ep.clearance.requestedAt.slice(0, 10)) : -17, 'Preoperative clearance request sent by fax + secure email (simulated).', 'Casey Morgan, RN', 'RN')]);
  }

  // Nora Lindqvist · Step 1 (new caller referred by a colleague; consult booked, confirmation + intake packet still to send)
  mk(SEED_PATIENTS.NORA, 'Nora Lindqvist', '06/21/1984', 'Female', { firstName: 'Nora', lastName: 'Lindqvist', referralSource: 'Physician referral', referredBy: 'Elena Marsh, MD (fictional)' });
  if (!medRepo.visit('visit-nora-consult')) medRepo.saveVisit({ id: 'visit-nora-consult', patientId: SEED_PATIENTS.NORA, date: addDays(T, 9), time: '10:30 AM', durationMin: 30, provider: PATEL, room: 'Exam 1', visitType: 'New patient consultation', reason: 'Breast augmentation consultation', step: 'scheduled', problemIds: [], createdAt: iso(0, '08:40'), createdBy: 'Taylor Brooks' });
  { let j: SJourney = { ...J.buildJourney({ id: 'jy-nora', patientId: SEED_PATIENTS.NORA, kind: 'new', service: 'Breast augmentation consultation', ctx: { age: 42, conditions: [], procedure: 'Breast augmentation', payment: 'Self-pay' }, createdAt: iso(0, '08:35'), createdBy: 'Taylor Brooks', role: 'Front desk' }, jSettings()), x: EMPTY() };
    j = done(j, ['s1-dup', 's1-profile', 's1-contact', 's1-referral', 's1-reason', 's1-appt', 's1-ins'], W('Taylor Brooks', 'Front desk', 0, '08:40')); all.push(j); }

  // Tomas Exampleton · Step 3 (today's 1:00 PM rhinoplasty consult; nothing about his visit state is changed)
  const tomas = medRepo.patient('MED-1007');
  if (tomas) { let j: SJourney = { ...J.buildJourney({ id: 'jy-tomas', patientId: 'MED-1007', kind: 'new', service: 'Rhinoplasty consultation', ctx: { age: ageFrom(tomas.dob), conditions: conditionsOf('MED-1007'), procedure: 'Rhinoplasty', payment: (tomas as any).paymentType || tomas.insurance }, createdAt: iso(-12), createdBy: 'Front Desk Tester', role: 'Front desk' }, jSettings()), x: EMPTY() };
    j = walk(j, 3, { 1: W('Front Desk Tester', 'Front desk', -12), 2: W('Front Desk Tester', 'Front desk', -2) }); all.push(j);
    cf('MED-1007', ['demographics', 'contact', 'insurance', 'pharmacy', 'prefs', 'medications', 'allergies', 'history'], tomas.name, -2, 'portal'); }

  // Daniel Reyes · Step 5 (roomed, vitals done, waiting for the surgeon)
  mk(SEED_PATIENTS.DANIEL, 'Daniel Reyes', '11/02/1979', 'Male', { firstName: 'Daniel', lastName: 'Reyes', referralSource: 'Google search' });
  if (!medRepo.visit('visit-daniel')) { medRepo.saveVisit({ id: 'visit-daniel', patientId: SEED_PATIENTS.DANIEL, date: T, time: '09:45 AM', durationMin: 30, provider: PATEL, room: 'Exam 3', visitType: 'New patient consultation', reason: 'Upper and lower eyelids (blepharoplasty) consultation', step: 'provider', problemIds: [], createdAt: iso(-9), createdBy: 'Taylor Brooks' });
    medRepo.addVitals({ id: 'vit-dr1', patientId: SEED_PATIENTS.DANIEL, visitId: 'visit-daniel', at: iso(0, '09:58'), by: 'Casey Morgan, RN', source: 'manual', bpSys: 128, bpDia: 80, hr: 70, rr: 14, spo2: 99, heightIn: 70, weightLb: 182 }); }
  { let j: SJourney = { ...J.buildJourney({ id: 'jy-daniel', patientId: SEED_PATIENTS.DANIEL, kind: 'new', service: 'Blepharoplasty consultation', ctx: { age: 46, conditions: [], procedure: 'Blepharoplasty', payment: 'Self-pay' }, createdAt: iso(-9), createdBy: 'Taylor Brooks', role: 'Front desk' }, jSettings()), x: EMPTY() };
    j = walk(j, 5, { 1: W('Taylor Brooks', 'Front desk', -9), 2: W('Taylor Brooks', 'Front desk', -1), 3: W('Taylor Brooks', 'Front desk', 0, '09:40'), 4: W('Casey Morgan, RN', 'RN', 0, '09:58') }); all.push(j);
    cf(SEED_PATIENTS.DANIEL, ['demographics', 'contact', 'insurance', 'pharmacy', 'prefs', 'history', 'diagnoses', 'surgeries', 'specialists'], 'Daniel Reyes', -1, 'portal'); cf(SEED_PATIENTS.DANIEL, ['id'], 'Taylor Brooks', 0, 'in-person'); cf(SEED_PATIENTS.DANIEL, ['medications', 'allergies'], 'Casey Morgan, RN', 0); }

  // Olivia Grant · Step 8 (no clearance needed; surgery in 4 days; consent + final reminder + supplies open; balance paid)
  mk(SEED_PATIENTS.OLIVIA, 'Olivia Grant', '02/17/1988', 'Female', { firstName: 'Olivia', lastName: 'Grant', referralSource: 'Instagram' });
  { const s = episodeSettings(); let e = EL.buildEpisode({ id: 'ep-olivia', patientId: SEED_PATIENTS.OLIVIA, procedure: 'Breast augmentation', surgeon: PATEL, ascName: ASC, surgeryDate: addDays(T, 4), surgeryTime: '08:00 AM', bookedOn: addDays(T, -40), createdAt: iso(-40), createdBy: 'Riley Shaw', totalAmount: 8900, depositAmount: 2225, age: 38, conditions: [], pcp: pcp.name }, s);
    e.items.filter(i => EL.isOpen(i) && !['instructions', 'postop-book', 'postop-photos', 'close', 'opnote', 'asc-confirm', 'rx'].includes(i.key)).forEach(i => { e = EL.setItem(e, i.key, 'done', 'Riley Shaw', iso(-10)); });
    e = { ...EL.applyPayment(e, 8900, 'Taylor Brooks', iso(-20)), asc: { ...e.asc, sentAt: iso(-8) } }; e = EL.setItem(e, 'asc-confirm', 'done', ASC, iso(-7)); e = { ...e, asc: { ...e.asc, confirmedAt: iso(-7) } };
    saveEpisode(e, 'Fictional seed', 'System', 'seed v1.2');
    let j: SJourney = { ...J.buildJourney({ id: 'jy-olivia', patientId: SEED_PATIENTS.OLIVIA, kind: 'new', service: 'Breast augmentation', ctx: { age: 38, conditions: [], procedure: 'Breast augmentation', payment: 'Self-pay', clearance: false }, createdAt: iso(-60), createdBy: 'Taylor Brooks', role: 'Front desk', episodeId: 'ep-olivia', surgeryDate: addDays(T, 4) }, jSettings()), x: EMPTY() };
    j = { ...j, x: { ...j.x, acks: (['procedural', 'financial', 'cancellation', 'refund'] as G.AckKind[]).map(k => ({ kind: k, text: G.ACK_TEXT[k], at: iso(-40), by: 'Olivia Grant', via: 'portal' as const, quoteVersion: 1 })), disposition: { value: 'proceeding', at: iso(-42), by: PATEL } } };
    j = walk(j, 8, { 1: W('Taylor Brooks', 'Front desk', -60), 2: W('Taylor Brooks', 'Front desk', -45), 3: W('Taylor Brooks', 'Front desk', -42, '09:00'), 4: W('Casey Morgan, RN', 'RN', -42, '09:10'), 5: W(PATEL, 'Plastic surgeon', -42, '11:00'), 6: W('Riley Shaw', 'Surgical Coordinator', -40) });
    j = done(j, ['s8-clear', 's8-facility', 's8-pay'], W('Riley Shaw', 'Surgical Coordinator', -6)); all.push(j);
    cf(SEED_PATIENTS.OLIVIA, ['demographics', 'contact', 'insurance', 'pharmacy', 'prefs', 'id', 'history', 'diagnoses', 'surgeries', 'specialists', 'medications', 'allergies'], 'Olivia Grant', -42, 'portal'); cf(SEED_PATIENTS.OLIVIA, ['id'], 'Taylor Brooks', -42, 'in-person'); }

  // Marcus Hale · Step 10 (upper blepharoplasty 5 days ago; red-flag screen due; an open refill question)
  mk(SEED_PATIENTS.MARCUS, 'Marcus Hale', '08/09/1977', 'Male', { firstName: 'Marcus', lastName: 'Hale', referralSource: 'Returning friend referral' });
  { const s = episodeSettings(); let e = EL.buildEpisode({ id: 'ep-marcus', patientId: SEED_PATIENTS.MARCUS, procedure: 'Upper blepharoplasty', surgeon: PATEL, ascName: ASC, surgeryDate: addDays(T, -5), bookedOn: addDays(T, -45), createdAt: iso(-45), createdBy: 'Riley Shaw', totalAmount: 4600, depositAmount: 1150, age: 49, conditions: [], pcp: pcp.name }, s);
    e.items.filter(i => EL.isOpen(i) && !['postop-photos', 'close'].includes(i.key)).forEach(i => { e = EL.setItem(e, i.key, 'done', 'Riley Shaw', iso(-6)); }); e = { ...EL.applyPayment(e, 4600, 'Taylor Brooks', iso(-20)), asc: { ...e.asc, sentAt: iso(-12), confirmedAt: iso(-11) } };
    saveEpisode(e, 'Fictional seed', 'System', 'seed v1.2');
    e.postOp.filter(v => v.pod > 5).slice(0, 1).forEach(v => { if (!medRepo.visit('visit-marcus-pod7')) medRepo.saveVisit({ id: 'visit-marcus-pod7', patientId: SEED_PATIENTS.MARCUS, date: v.date, time: '09:30 AM', durationMin: 15, provider: PATEL, room: 'Exam 1', visitType: 'Post-op follow-up', reason: `POD ${v.pod} after upper blepharoplasty · photo set`, step: 'scheduled', problemIds: [], createdAt: iso(-6), createdBy: 'Taylor Brooks' }); });
    let j: SJourney = { ...J.buildJourney({ id: 'jy-marcus', patientId: SEED_PATIENTS.MARCUS, kind: 'new', service: 'Upper blepharoplasty', ctx: { age: 49, conditions: [], procedure: 'Upper blepharoplasty', payment: 'Self-pay', clearance: false }, createdAt: iso(-70), createdBy: 'Taylor Brooks', role: 'Front desk', episodeId: 'ep-marcus', surgeryDate: addDays(T, -5) }, jSettings()), x: EMPTY() };
    j = { ...j, x: { ...j.x, acks: (['procedural', 'financial', 'cancellation', 'refund'] as G.AckKind[]).map(k => ({ kind: k, text: G.ACK_TEXT[k], at: iso(-45), by: 'Marcus Hale', via: 'in-office' as const })), disposition: { value: 'proceeding', at: iso(-46), by: PATEL },
      records: [{ kind: 'operative-note', how: 'imported', from: ASC, at: iso(-4), by: 'Taylor Brooks', matched: true }, { kind: 'discharge-summary', how: 'linked', from: ASC, at: iso(-4), by: 'Taylor Brooks', matched: true }],
      tracked: [{ id: 'tr-mh1', kind: 'refill', text: 'Asked for a refill of the eye ointment (portal message)', at: iso(-1, '18:20'), by: 'Marcus Hale (Portal)', status: 'open', owner: 'surgeon' }] } };
    j = walk(j, 10, { 1: W('Taylor Brooks', 'Front desk', -70), 2: W('Taylor Brooks', 'Front desk', -50), 3: W('Taylor Brooks', 'Front desk', -46, '09:00'), 4: W('Casey Morgan, RN', 'RN', -46, '09:10'), 5: W(PATEL, 'Plastic surgeon', -46, '11:00'), 6: W('Riley Shaw', 'Surgical Coordinator', -45), 8: W('Riley Shaw', 'Surgical Coordinator', -2), 9: W('Casey Morgan, RN', 'RN', -4) });
    j = done(j, ['s10-visits'], W('Taylor Brooks', 'Front desk', -4)); all.push(j);
    cf(SEED_PATIENTS.MARCUS, ['demographics', 'contact', 'insurance', 'pharmacy', 'prefs', 'history', 'diagnoses', 'surgeries', 'specialists', 'medications', 'allergies', 'consents'], 'Marcus Hale', -45, 'portal'); cf(SEED_PATIENTS.MARCUS, ['id'], 'Taylor Brooks', -46, 'in-person');
    if (!medRepo.messages(SEED_PATIENTS.MARCUS).length) medRepo.addMessage({ id: 'msg-mh1', patientId: SEED_PATIENTS.MARCUS, from: 'patient', author: 'Marcus Hale', text: 'Hi, I am almost out of the eye ointment. Can I get a refill? Swelling is going down nicely.', at: iso(-1, '18:20') }); }

  // Carol Bennett · Step 11 (returning patient, facelift two years after eyelid surgery; old data flagged by last-confirmed date)
  const carol = medRepo.patient(CAROL);
  if (carol) { const ep = activeEpisode(CAROL); const j: SJourney = { ...J.buildJourney({ id: 'jy-carol', patientId: CAROL, kind: 'return', service: 'Facelift / necklift', ctx: { age: ageFrom(carol.dob), conditions: ['thyroid'], procedure: 'Facelift / necklift', payment: 'Self-pay', returning: true, clearance: true }, createdAt: iso(-1), createdBy: 'Taylor Brooks', role: 'Front desk', episodeId: ep?.id, surgeryDate: ep?.surgeryDate }, jSettings()), x: EMPTY() };
    all.push(done(j, ['s11-locate'], W('Taylor Brooks', 'Front desk', -1), 'existing chart found by name + DOB; no duplicate created'));
    cf(CAROL, ['demographics', 'contact', 'insurance', 'pharmacy', 'prefs', 'id', 'history', 'diagnoses', 'surgeries', 'medications', 'allergies', 'consents'], 'Casey Morgan, RN', -760); cf(CAROL, ['contact', 'prefs'], 'Carol Bennett', -1, 'portal'); }
  // a closed journey for Carol's 2024 eyelid surgery (history for the Overview timeline)
  if (carol) all.push({ ...J.buildJourney({ id: 'jy-carol-2024', patientId: CAROL, kind: 'new', service: 'Upper blepharoplasty', ctx: { age: 59, conditions: ['thyroid'], payment: 'Self-pay', clearance: true }, createdAt: iso(-780), createdBy: 'Front Desk Tester' }, jSettings()), closedAt: iso(-640), x: EMPTY() });

  svWrite(K, all); svWrite('confirmations', conf); svWrite('journeys-seeded-v12', true);
}
