/*
 * Surgery.Vityls v1.2 · Patient Journey engine: pure logic (no browser, no storage; unit-tested with node:test).
 * Kevin's framework (kevin_docs/journey.txt): every encounter follows
 *   trigger → responsible role → required data → checklist → validation → documentation → communication → task routing → completion → audit.
 * 11 steps. Each step has an owner, a trigger, a practice-editable checklist (tailored by age, conditions, procedure, payment and policy),
 * a "complete when" rule, item statuses (open / done / waived / blocked / waiting), prerequisites, waive-with-reason + a required
 * follow-up task, and an audit record of who completed, reviewed, changed or waived each item and when.
 * Henry: this is the shape of the `journeys`, `journey_items` and `journey_audit` tables (see report/Surgery_v1.2_Changelog.md).
 */
export type StepNo = 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11;
export type JOwner = 'front' | 'nurse' | 'surgeon' | 'asc' | 'patient';
export const JOWNER_LABEL: Record<JOwner, string> = { front: 'Front desk', nurse: 'Nurse / coordinator', surgeon: 'Surgeon', asc: 'ASC', patient: 'Patient' };
export type JStatus = 'open' | 'done' | 'waived' | 'blocked' | 'waiting';
export type StepState = 'upcoming' | 'active' | 'done' | 'hold' | 'skipped';
/** What a checklist row's main button does. The page maps each kind to an existing Vityls screen or a Nightingale draft. */
export type JAction = 'mark' | 'confirm' | 'schedule' | 'station-front' | 'station-nurse' | 'station-doctor' | 'send-forms' | 'draft' | 'collect' | 'upload'
  | 'pin' | 'send-asc' | 'quote' | 'ack' | 'photos' | 'note' | 'disposition' | 'dup-search' | 'redflag' | 'tracker' | 'postop-plan' | 'records' | 'reconcile' | 'start-consult' | 'day-record';
/** Tailoring flags. An item with `when` applies only if every flag holds for this patient (`!flag` negates). */
export type Flag = 'clearance' | 'selfpay' | 'insured' | 'minor' | 'returning' | 'new' | 'diabetes' | 'anticoag' | 'surgical' | 'general-anesthesia';
export interface ItemDef { key: string; step: StepNo; label: string; owner: JOwner; action: JAction; when?: (Flag | `!${Flag}`)[]; needs?: string[]; optional?: boolean;
  /** Days from the anchor (surgery date for steps 6-10, the step's open date otherwise). */ dueDays?: number; anchor?: 'surgery' | 'open';
  /** Chart fact that completes this item automatically (from the existing stations, scheduler, notes, payments…). */ fact?: string; safety?: boolean }
export interface StepDef { n: StepNo; short: string; title: string; owners: JOwner[]; ownerLabel: string; trigger: string; completeWhen: string }

export const STEPS: StepDef[] = [
  { n: 1, short: 'Scheduling', title: 'New-patient scheduling', owners: ['front'], ownerLabel: 'Front desk', trigger: 'First phone, portal or referral request', completeWhen: 'Appointment is scheduled, confirmation is sent, and outstanding intake items have owners and deadlines.' },
  { n: 2, short: 'Pre-visit', title: 'Pre-visit intake & readiness', owners: ['front', 'nurse'], ownerLabel: 'Front desk · clinical review where required', trigger: 'Appointment scheduled', completeWhen: 'Patient is confirmed and marked Ready, or unresolved items are visibly flagged.' },
  { n: 3, short: 'Check-in', title: 'Arrival & front-desk check-in', owners: ['front'], ownerLabel: 'Front desk', trigger: 'Patient arrives', completeWhen: 'Administrative requirements are satisfied and the patient is handed off.' },
  { n: 4, short: 'Rooming', title: 'Clinical rooming', owners: ['nurse'], ownerLabel: 'Nurse or medical assistant', trigger: 'Clinical handoff', completeWhen: 'Required intake is documented and exceptions are escalated.' },
  { n: 5, short: 'Consult', title: 'Surgical consultation', owners: ['surgeon'], ownerLabel: 'Surgeon', trigger: 'Patient ready for clinician', completeWhen: 'Documentation is signed and the next pathway is selected.' },
  { n: 6, short: 'Quote & booking', title: 'Quote & surgery booking', owners: ['nurse', 'surgeon'], ownerLabel: 'Patient coordinator or authorized clinician', trigger: 'Patient chooses to proceed', completeWhen: 'Surgery is booked and every prerequisite has an owner and due date.' },
  { n: 7, short: 'Clearance', title: 'Preoperative clearance', owners: ['nurse', 'surgeon'], ownerLabel: 'Nurse / Coordinator · surgeon reviews', trigger: 'Clearance required', completeWhen: 'The surgeon and ASC requirements are satisfied and documented.' },
  { n: 8, short: 'Final readiness', title: 'Final preoperative readiness', owners: ['nurse', 'front'], ownerLabel: 'Coordinator / front desk · clinical review', trigger: 'Surgery approaching', completeWhen: 'The case is Ready for surgery, or placed on hold with a documented reason.' },
  { n: 9, short: 'Surgery day', title: 'Surgery-day handoff', owners: ['nurse', 'asc'], ownerLabel: 'Surgical office + ASC', trigger: 'Day of surgery', completeWhen: 'Facility documentation is reconciled and postoperative tasks are active.' },
  { n: 10, short: 'Post-op', title: 'Postoperative care', owners: ['surgeon', 'nurse'], ownerLabel: 'Surgeon + clinical team', trigger: 'Procedure completed', completeWhen: 'Recovery milestones are met and no unresolved clinical tasks remain.' },
  { n: 11, short: 'Return visit', title: 'Existing-patient return encounter', owners: ['front', 'nurse'], ownerLabel: 'Front desk + clinical team', trigger: 'Established patient requests another service', completeWhen: 'The historical chart is reconciled and current enough for the new encounter.' },
];
export const stepDef = (n: number) => STEPS.find(s => s.n === n)!;

/** Clearance tests (Kevin): H&P, CBC, CMP, UA, ECG, PT, PTT, chest x-ray. */
export const CLEARANCE_ITEMS = ['H&P', 'CBC', 'CMP', 'UA', 'ECG', 'PT', 'PTT', 'CXR'] as const;
export const CLEARANCE_LABEL: Record<string, string> = { 'H&P': 'History & physical (H&P)', CBC: 'CBC', CMP: 'Chemistry panel (CMP)', UA: 'Urinalysis (UA)', ECG: 'ECG (12-lead)', PT: 'PT', PTT: 'PTT', CXR: 'Chest x-ray' };

const I = (step: StepNo, key: string, label: string, owner: JOwner, action: JAction, o: Partial<ItemDef> = {}): ItemDef => ({ step, key, label, owner, action, ...o });
/** Default checklists, taken line by line from Kevin's document. Practice-editable (Surgery settings › Patient journey). */
export const DEFAULT_ITEMS: ItemDef[] = [
  // 1 · New-patient scheduling
  I(1, 's1-dup', 'Search for possible duplicate patient records', 'front', 'dup-search', { fact: 'dup-checked' }),
  I(1, 's1-profile', 'Create or verify the patient profile', 'front', 'mark', { fact: 'profile' }),
  I(1, 's1-contact', 'Record contact details and communication preferences', 'front', 'mark', { fact: 'contact' }),
  I(1, 's1-referral', 'Record referral source and referring clinician', 'front', 'mark', { fact: 'referral' }),
  I(1, 's1-reason', 'Capture reason for visit and requested procedure', 'front', 'mark', { fact: 'reason' }),
  I(1, 's1-appt', 'Select visit type, provider, location, date and time', 'front', 'schedule', { fact: 'appt' }),
  I(1, 's1-ins', 'Record insurance or self-pay status', 'front', 'mark', { fact: 'paytype' }),
  I(1, 's1-confirm', 'Send appointment confirmation', 'front', 'draft', { needs: ['s1-appt'], fact: 'confirm-sent' }),
  I(1, 's1-intake', 'Send registration, history, medication, allergy, consent, ID and insurance-card requests', 'front', 'send-forms', { needs: ['s1-appt'], fact: 'forms-sent' }),
  I(1, 's1-tasks', 'Create tasks for missing records or referral documents', 'front', 'mark', { optional: true }),
  // 2 · Pre-visit intake & readiness
  I(2, 's2-demo', 'Confirm registration and demographic information', 'front', 'confirm', { fact: 'cf-demographics' }),
  I(2, 's2-ins', 'Verify insurance information', 'front', 'mark', { when: ['insured'] }),
  I(2, 's2-selfpay', 'Verify cosmetic self-pay status', 'front', 'mark', { when: ['selfpay'], fact: 'paytype' }),
  I(2, 's2-cards', 'Confirm ID and card images are legible', 'front', 'mark', { fact: 'cards' }),
  I(2, 's2-hx', 'Confirm medical, surgical, family and social history', 'nurse', 'confirm', { fact: 'cf-history' }),
  I(2, 's2-meds', 'Confirm medications, allergies, pharmacy and specialists', 'nurse', 'confirm', { fact: 'cf-medications' }),
  I(2, 's2-consents', 'Check required consents and questionnaires', 'front', 'send-forms', { fact: 'forms-done' }),
  I(2, 's2-records', 'Request missing outside records', 'front', 'draft', { optional: true }),
  I(2, 's2-reminder', 'Send reminder and obtain confirmation', 'front', 'draft', { fact: 'appt-confirmed' }),
  I(2, 's2-instr', 'Communicate fasting, arrival or record instructions', 'front', 'draft', { optional: true }),
  I(2, 's2-flag', 'Flag incomplete or clinically significant responses', 'nurse', 'mark'),
  // 3 · Arrival & check-in
  I(3, 's3-arrived', 'Mark arrived with timestamp', 'front', 'station-front', { fact: 'arrived' }),
  I(3, 's3-id', 'Verify identity using approved identifiers', 'front', 'confirm', { fact: 'cf-id', safety: true }),
  I(3, 's3-reconfirm', 'Reconfirm contact, pharmacy, insurance and guarantor details', 'front', 'confirm', { fact: 'cf-contact' }),
  I(3, 's3-forms', 'Verify forms and consents', 'front', 'station-front', { fact: 'forms-done' }),
  I(3, 's3-pay', 'Collect required payment', 'front', 'collect', { optional: true }),
  I(3, 's3-scan', 'Scan any missing documents', 'front', 'upload', { fact: 'cards' }),
  I(3, 's3-handoff', 'Notify clinical staff that the patient is ready', 'front', 'station-front', { needs: ['s3-arrived'], fact: 'checked-in' }),
  I(3, 's3-needs', 'Record delays, accommodation or interpreter needs', 'front', 'mark', { optional: true }),
  // 4 · Clinical rooming
  I(4, 's4-id', 'Confirm patient identity and reason for visit', 'nurse', 'station-nurse', { fact: 'roomed' }),
  I(4, 's4-vitals', 'Record BP, pulse, respiratory rate, SpO₂, height and weight', 'nurse', 'station-nurse', { fact: 'vitals' }),
  I(4, 's4-recon', 'Reconcile medications and allergies', 'nurse', 'confirm', { fact: 'cf-allergies', safety: true }),
  I(4, 's4-hx', 'Review relevant history and current symptoms', 'nurse', 'station-nurse', { fact: 'roomed' }),
  I(4, 's4-abn', 'Identify abnormal findings or safety concerns', 'nurse', 'mark', { fact: 'vitals' }),
  I(4, 's4-prep', 'Prepare required forms, photographs, supplies and records', 'nurse', 'mark', { optional: true }),
  I(4, 's4-ready', 'Update encounter status to Ready for clinician', 'nurse', 'station-nurse', { needs: ['s4-vitals'], fact: 'ready-for-md' }),
  // 5 · Surgical consultation
  I(5, 's5-review', 'Review intake, vital signs, history, medications and allergies', 'surgeon', 'station-doctor', { fact: 'md-opened' }),
  I(5, 's5-goals', 'Clarify goals, expectations and relevant symptoms', 'surgeon', 'station-doctor', { fact: 'scribe' }),
  I(5, 's5-exam', 'Perform and document the examination', 'surgeon', 'station-doctor', { fact: 'scribe' }),
  I(5, 's5-photos', 'Capture standardized photographs with consent', 'surgeon', 'photos', { fact: 'photos', when: ['surgical'] }),
  I(5, 's5-assess', 'Document assessment and proposed procedure', 'surgeon', 'station-doctor', { fact: 'note-draft' }),
  I(5, 's5-discuss', 'Discuss options, limitations, material risks, benefits, alternatives and recovery', 'surgeon', 'station-doctor', { fact: 'note-draft' }),
  I(5, 's5-cand', 'Record candidacy and unresolved clinical issues', 'surgeon', 'station-doctor', { fact: 'note-draft' }),
  I(5, 's5-note', 'Prepare or dictate the visit note (sign with PIN)', 'surgeon', 'note', { fact: 'note-signed' }),
  I(5, 's5-dispo', 'Determine disposition: considering, declined, follow-up required or proceeding', 'surgeon', 'disposition', { fact: 'disposition' }),
  // 6 · Quote & booking
  I(6, 's6-quote', 'Generate an itemized quote', 'nurse', 'quote', { fact: 'quote' }),
  I(6, 's6-version', 'Record quote version, expiration and acceptance', 'nurse', 'quote', { needs: ['s6-quote'], fact: 'quote-accepted' }),
  I(6, 's6-book', 'Select procedure, surgeon, facility and proposed date', 'nurse', 'mark', { fact: 'booked' }),
  I(6, 's6-terms', 'Provide deposit, balance, cancellation and refund terms', 'nurse', 'ack', { fact: 'ack-financial' }),
  I(6, 's6-invoice', 'Create invoice and payment schedule', 'front', 'collect', { needs: ['s6-version'], fact: 'invoice' }),
  I(6, 's6-instr', 'Provide preoperative instructions', 'nurse', 'draft', { fact: 'instructions' }),
  I(6, 's6-acks', 'Obtain required procedural and financial acknowledgments', 'nurse', 'ack', { fact: 'ack-procedural' }),
  I(6, 's6-tasks', 'Create tasks for clearance, testing, prescriptions, facility documents and payments', 'nurse', 'mark', { needs: ['s6-book'], fact: 'booked' }),
  // 7 · Preoperative clearance (only when clearance is required)
  I(7, 's7-request', 'Generate a clearance request with procedure and deadline', 'nurse', 'draft', { when: ['clearance'], fact: 'clr-requested' }),
  I(7, 's7-route', 'Route it to the primary care clinician or designated provider', 'nurse', 'draft', { when: ['clearance'], fact: 'clr-requested' }),
  ...CLEARANCE_ITEMS.map(t => I(7, `s7-t-${t}`, `${CLEARANCE_LABEL[t]} received`, 'front', 'upload', { when: ['clearance'], fact: `clr-${t}`, needs: ['s7-request'], dueDays: -9, anchor: 'surgery' })),
  I(7, 's7-classify', 'Upload and classify every returned document', 'front', 'upload', { when: ['clearance'], fact: 'clr-classified' }),
  I(7, 's7-verify', 'Verify patient identity and dates on each item', 'nurse', 'mark', { when: ['clearance'], fact: 'clr-verified' }),
  I(7, 's7-abn', 'Identify missing, abnormal or inconsistent information', 'nurse', 'mark', { when: ['clearance'], fact: 'clr-flagged' }),
  I(7, 's7-review', 'Surgeon review of returned results (PIN)', 'surgeon', 'pin', { when: ['clearance'], fact: 'clr-reviewed', dueDays: -9, anchor: 'surgery' }),
  I(7, 's7-asc', 'Send the completed package to the ASC', 'nurse', 'send-asc', { when: ['clearance'], needs: ['s7-t-ECG', 's7-review'], fact: 'asc-sent', dueDays: -7, anchor: 'surgery' }),
  I(7, 's7-ascok', 'Record ASC confirmation and deficiencies', 'asc', 'mark', { when: ['clearance'], needs: ['s7-asc'], fact: 'asc-confirmed', dueDays: -6, anchor: 'surgery' }),
  // 8 · Final readiness
  I(8, 's8-consent', 'Verify signed consents', 'nurse', 'confirm', { fact: 'consent-signed', safety: true, dueDays: -3, anchor: 'surgery' }),
  I(8, 's8-clear', 'Verify clearance and testing completion', 'nurse', 'mark', { fact: 'clearance-complete', dueDays: -3, anchor: 'surgery' }),
  I(8, 's8-facility', 'Verify facility confirmation', 'nurse', 'mark', { fact: 'asc-confirmed', dueDays: -3, anchor: 'surgery' }),
  I(8, 's8-rx', 'Verify prescriptions and medication instructions', 'surgeon', 'pin', { fact: 'rx-signed', dueDays: -3, anchor: 'surgery' }),
  I(8, 's8-pay', 'Verify deposit and final balance', 'front', 'collect', { fact: 'paid-full', dueDays: -14, anchor: 'surgery' }),
  I(8, 's8-logistics', 'Confirm date, time, location, arrival, fasting, transportation and escort', 'front', 'draft', { fact: 'logistics', dueDays: -2, anchor: 'surgery' }),
  I(8, 's8-supplies', 'Confirm postoperative supplies and instructions', 'nurse', 'mark', { dueDays: -2, anchor: 'surgery' }),
  I(8, 's8-escalate', 'Escalate missing items before the cutoff', 'nurse', 'mark', { optional: true }),
  I(8, 's8-final', 'Send final reminder', 'front', 'draft', { fact: 'final-reminder', dueDays: -1, anchor: 'surgery' }),
  // 9 · Surgery-day handoff
  I(9, 's9-sched', 'Confirm the final schedule and facility receipt', 'nurse', 'mark', { fact: 'asc-confirmed', dueDays: 0, anchor: 'surgery' }),
  I(9, 's9-pkg', 'Make the current chart package available', 'nurse', 'send-asc', { fact: 'asc-sent', dueDays: 0, anchor: 'surgery' }),
  I(9, 's9-change', 'Record cancellation, delay or procedure changes', 'nurse', 'day-record', { optional: true }),
  I(9, 's9-records', 'Import or link operative and discharge records', 'front', 'records', { fact: 'op-records', dueDays: 1, anchor: 'surgery' }),
  I(9, 's9-plan', 'Create the postoperative follow-up plan', 'nurse', 'postop-plan', { fact: 'postop-booked', dueDays: 1, anchor: 'surgery' }),
  // 10 · Post-op care
  I(10, 's10-visits', 'Schedule required postoperative visits', 'front', 'postop-plan', { fact: 'postop-booked', dueDays: 1, anchor: 'surgery' }),
  I(10, 's10-recovery', 'Review pain, medication use, wound status, symptoms and recovery', 'nurse', 'redflag', { fact: 'recovery-reviewed', dueDays: 7, anchor: 'surgery' }),
  I(10, 's10-redflag', 'Screen for red-flag symptoms and escalate promptly', 'nurse', 'redflag', { fact: 'redflag-screened', safety: true, dueDays: 3, anchor: 'surgery' }),
  I(10, 's10-exam', 'Perform and document the examination', 'surgeon', 'note', { fact: 'postop-note', dueDays: 7, anchor: 'surgery' }),
  I(10, 's10-photos', 'Capture postoperative photographs when appropriate', 'nurse', 'photos', { optional: true, fact: 'postop-photos' }),
  I(10, 's10-update', 'Update restrictions, wound care, medications and return precautions', 'surgeon', 'draft', { fact: 'restrictions', dueDays: 7, anchor: 'surgery' }),
  I(10, 's10-track', 'Track questions, refill requests, complications, tests and referrals', 'nurse', 'tracker', { fact: 'tracker-clear' }),
  I(10, 's10-next', 'Schedule the next follow-up', 'front', 'schedule', { fact: 'next-fu', dueDays: 30, anchor: 'surgery' }),
  // 11 · Existing-patient return
  I(11, 's11-locate', 'Locate and verify the existing chart; do not create a duplicate', 'front', 'dup-search', { fact: 'dup-checked' }),
  I(11, 's11-dates', 'Display the date each key data category was last confirmed', 'front', 'reconcile', { fact: 'lc-shown' }),
  I(11, 's11-demo', 'Reconfirm demographics, insurance, contacts, pharmacy and communication preferences', 'front', 'confirm', { fact: 'cf-demographics' }),
  I(11, 's11-hx', 'Update history, diagnoses, surgeries, medications, allergies, specialists and consents', 'nurse', 'confirm', { fact: 'cf-history' }),
  I(11, 's11-interval', 'Identify interval hospitalizations, procedures or significant events', 'nurse', 'reconcile', { fact: 'interval' }),
  I(11, 's11-mark', 'Mark older information as confirmed, changed, unknown or needs review', 'nurse', 'reconcile', { fact: 'marks-done' }),
  I(11, 's11-start', 'Start the appropriate consultation workflow', 'front', 'start-consult', { needs: ['s11-locate'], fact: 'consult-booked' }),
  I(11, 's11-keep', 'Preserve prior procedures, photographs, outcomes and communications', 'front', 'mark', { fact: 'history-kept' }),
];

/* ---------------- practice settings ---------------- */
export interface JourneySettings { disabled: string[]; labels: Record<string, string>; owners: Record<string, JOwner>; extra: ItemDef[]; staleMonths: number; checkpointFreshDays: number; clearanceTests: string[] }
export const DEFAULT_JOURNEY_SETTINGS: JourneySettings = { disabled: [], labels: {}, owners: {}, extra: [], staleMonths: 12, checkpointFreshDays: 7, clearanceTests: [...CLEARANCE_ITEMS] };
export function practiceItems(s: JourneySettings = DEFAULT_JOURNEY_SETTINGS): ItemDef[] {
  return [...DEFAULT_ITEMS, ...s.extra].filter(d => !s.disabled.includes(d.key))
    .filter(d => !d.key.startsWith('s7-t-') || s.clearanceTests.includes(d.key.slice(5)))
    .map(d => ({ ...d, label: s.labels[d.key] || d.label, owner: s.owners[d.key] || d.owner }));
}

/* ---------------- tailoring ---------------- */
export interface TailorCtx { age: number; conditions: string[]; procedure?: string; payment?: string; returning?: boolean; clearance?: boolean; anticoag?: boolean }
export function flagsFor(c: TailorCtx): Set<Flag> {
  const f = new Set<Flag>();
  if (c.clearance) f.add('clearance');
  if (/self/i.test(c.payment || '')) f.add('selfpay'); else f.add('insured');
  if (c.age < 18) f.add('minor');
  f.add(c.returning ? 'returning' : 'new');
  if (c.conditions.includes('diabetes')) f.add('diabetes');
  if (c.anticoag) f.add('anticoag');
  if (!c.procedure || !/injectable|filler|botox|skin check/i.test(c.procedure)) f.add('surgical');
  if (c.procedure && /rhinoplasty|facelift|abdominoplasty|breast|lipo/i.test(c.procedure)) f.add('general-anesthesia');
  return f;
}
export const applies = (d: ItemDef, f: Set<Flag>) => (d.when || []).every(w => w.startsWith('!') ? !f.has(w.slice(1) as Flag) : f.has(w as Flag));
/** Practice clearance rule (facts only, the surgeon decides): age 50+ or a listed condition. */
export const clearanceSuggested = (age: number, conditions: string[], minAge = 50, list = ['hypertension', 'diabetes', 'heart', 'osa', 'ckd', 'bleeding', 'lung']) => age >= minAge || conditions.some(c => list.includes(c));

/* ---------------- journey records ---------------- */
export interface Audit { at: string; by: string; role: string; kind: 'created' | 'completed' | 'reviewed' | 'changed' | 'waived' | 'reopened' | 'waiting' | 'confirmed' | 'step' | 'hold'; item?: string; what: string }
export interface Waiver { reason: string; details: string; by: string; at: string; followUp: string }
export interface JItem { id: string; key: string; step: StepNo; label: string; owner: JOwner; action: JAction; status: Exclude<JStatus, 'blocked'>; needs: string[]; optional: boolean; safety?: boolean; fact?: string;
  due?: string; doneAt?: string; doneBy?: string; reviewedBy?: string; note?: string; waiver?: Waiver; followUpOf?: string; carry?: boolean }
export interface JStepRec { n: StepNo; state: StepState; openedAt?: string; doneAt?: string; holdReason?: string; ready?: { at: string; by: string } }
export interface Journey { id: string; patientId: string; kind: 'new' | 'return'; service: string; episodeId?: string; surgeryDate?: string; createdAt: string; createdBy: string;
  current: StepNo; steps: JStepRec[]; items: JItem[]; audit: Audit[]; ctx: TailorCtx; closedAt?: string }

export const addDaysIso = (iso: string, n: number) => { const [y, m, d] = iso.slice(0, 10).split('-').map(Number); return new Date(Date.UTC(y, m - 1, d + n)).toISOString().slice(0, 10); };
export const daysBetween = (from: string, to: string) => Math.round((Date.UTC(+to.slice(0, 4), +to.slice(5, 7) - 1, +to.slice(8, 10)) - Date.UTC(+from.slice(0, 4), +from.slice(5, 7) - 1, +from.slice(8, 10))) / 864e5);

/** The order a patient walks the steps. Returning patients start at Step 11 and then re-enter at check-in (Steps 1-2 are replaced by 11). */
export const pathFor = (kind: 'new' | 'return'): StepNo[] => kind === 'new' ? [1, 2, 3, 4, 5, 6, 7, 8, 9, 10] : [11, 3, 4, 5, 6, 7, 8, 9, 10];
export const DISPLAY_ORDER: StepNo[] = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11];

const dueOf = (d: ItemDef, open: string, surgery?: string) => d.dueDays == null ? undefined : addDaysIso(d.anchor === 'surgery' && surgery ? surgery : open, d.dueDays);
function itemsForStep(n: StepNo, j: Pick<Journey, 'id' | 'ctx' | 'surgeryDate'>, defs: ItemDef[], openedAt: string): JItem[] {
  const f = flagsFor(j.ctx);
  return defs.filter(d => d.step === n && applies(d, f)).map(d => ({ id: `${j.id}:${d.key}`, key: d.key, step: n, label: d.label, owner: d.owner, action: d.action, status: 'open' as const, needs: d.needs || [], optional: !!d.optional, safety: d.safety, fact: d.fact, due: dueOf(d, openedAt.slice(0, 10), j.surgeryDate) }));
}

export interface NewJourney { id: string; patientId: string; kind: 'new' | 'return'; service: string; ctx: TailorCtx; createdAt: string; createdBy: string; role?: string; episodeId?: string; surgeryDate?: string; startAt?: StepNo }
/** Build a journey. Every step's checklist is created up front (tailored), so upcoming steps can show "what will be asked". */
export function buildJourney(x: NewJourney, s: JourneySettings = DEFAULT_JOURNEY_SETTINGS): Journey {
  const defs = practiceItems(s); const path = pathFor(x.kind); const start = x.startAt && path.includes(x.startAt) ? x.startAt : path[0];
  const base = { id: x.id, ctx: x.ctx, surgeryDate: x.surgeryDate };
  const items = path.flatMap(n => itemsForStep(n, base, defs, x.createdAt));
  const steps: JStepRec[] = DISPLAY_ORDER.map(n => ({ n, state: !path.includes(n) ? 'skipped' : n === start ? 'active' : path.indexOf(n) < path.indexOf(start) ? 'done' : 'upcoming', openedAt: n === start ? x.createdAt : undefined }));
  // Step 7 is skipped entirely when clearance is not required.
  const j: Journey = { id: x.id, patientId: x.patientId, kind: x.kind, service: x.service, episodeId: x.episodeId, surgeryDate: x.surgeryDate, createdAt: x.createdAt, createdBy: x.createdBy, current: start, steps, items, ctx: x.ctx,
    audit: [{ at: x.createdAt, by: x.createdBy, role: x.role || '', kind: 'created', what: `Journey started: ${x.service} (${x.kind === 'new' ? 'new patient' : 'returning patient'})` }] };
  return skipEmpty(j);
}
const skipEmpty = (j: Journey): Journey => ({ ...j, steps: j.steps.map(s => s.state !== 'skipped' && !j.items.some(i => i.step === s.n) ? { ...s, state: 'skipped' as StepState } : s) });

/* ---------------- statuses, prerequisites, blockers ---------------- */
export const closed = (i: JItem) => i.status === 'done' || i.status === 'waived';
/** Effective status: an open item whose prerequisites are not done (or waived) is Blocked. */
export function statusOf(j: Journey, i: JItem): JStatus {
  if (closed(i) || i.status === 'waiting') return i.status;
  const missing = blockersOf(j, i); return missing.length ? 'blocked' : 'open';
}
export const blockersOf = (j: Journey, i: JItem): JItem[] => i.needs.map(k => j.items.find(x => x.key === k)).filter((x): x is JItem => !!x && !closed(x));
export const stepItems = (j: Journey, n: StepNo) => j.items.filter(i => i.step === n);
/** Kevin's rule: the page shows ONLY what still needs doing (open, waiting, blocked). Carried follow-ups from earlier steps show too. */
export function openItems(j: Journey, n: StepNo): JItem[] {
  return j.items.filter(i => !closed(i) && (i.step === n || (i.carry && i.step < n && stepState(j, i.step) === 'done'))).filter(i => !i.optional || i.status === 'waiting' || !!i.followUpOf);
}
export const completedItems = (j: Journey, n: StepNo) => stepItems(j, n).filter(closed).sort((a, b) => (b.doneAt || '').localeCompare(a.doneAt || ''));
export const stepState = (j: Journey, n: StepNo) => j.steps.find(s => s.n === n)?.state || 'upcoming';
export interface StepCounts { open: number; waiting: number; blocked: number; done: number; waived: number }
export function counts(j: Journey, n: StepNo): StepCounts {
  const c: StepCounts = { open: 0, waiting: 0, blocked: 0, done: 0, waived: 0 };
  openItems(j, n).forEach(i => { c[statusOf(j, i) as 'open' | 'waiting' | 'blocked']++; }); stepItems(j, n).forEach(i => { if (i.status === 'done') c.done++; if (i.status === 'waived') c.waived++; });
  return c;
}
/** "Complete when" rule per step. Required items done or waived; a waived item's follow-up must exist (it is created by waive()).
 *  Step 8 additionally needs every carried follow-up closed (a waiver can't slip past Ready for surgery). */
export function completeCheck(j: Journey, n: StepNo): { ok: boolean; missing: string[] } {
  const req = stepItems(j, n).filter(i => !i.optional && !i.followUpOf);
  const missing = req.filter(i => !closed(i)).map(i => i.label);
  if (n === 8) j.items.filter(i => i.followUpOf && !closed(i)).forEach(i => missing.push(`Follow-up: ${i.label}`));
  if (n === 1 && stepItems(j, 1).some(i => !closed(i) && !i.due && !i.optional)) { /* outstanding intake items need owners and deadlines: every item has an owner; due dates are added on open */ }
  return { ok: missing.length === 0, missing };
}
export function overdue(j: Journey, today: string): JItem[] { return j.items.filter(i => !closed(i) && i.due && i.due < today && stepState(j, i.step) === 'active'); }

/* ---------------- mutations (all audited) ---------------- */
const log = (j: Journey, a: Audit): Journey => ({ ...j, audit: [...j.audit, a] });
const upd = (j: Journey, key: string, f: (i: JItem) => JItem) => ({ ...j, items: j.items.map(i => i.key === key ? f(i) : i) });
export interface Who { by: string; role: string; at: string }
export function complete(j: Journey, key: string, w: Who, note?: string, kind: 'completed' | 'reviewed' = 'completed'): Journey {
  const it = j.items.find(i => i.key === key); if (!it) throw new Error(`No item ${key}`); if (closed(it)) return j;
  const b = blockersOf(j, it); if (b.length) throw new Error(`Blocked by: ${b.map(x => x.label).join(', ')}`);
  const n = upd(j, key, i => ({ ...i, status: 'done', doneAt: w.at, doneBy: w.by, ...(kind === 'reviewed' ? { reviewedBy: w.by } : {}), ...(note ? { note } : {}) }));
  return log(n, { at: w.at, by: w.by, role: w.role, kind, item: key, what: `${it.label}${note ? ` · ${note}` : ''}` });
}
export function setWaiting(j: Journey, key: string, w: Who, note: string): Journey {
  const it = j.items.find(i => i.key === key)!; return log(upd(j, key, i => ({ ...i, status: 'waiting', note })), { at: w.at, by: w.by, role: w.role, kind: 'waiting', item: key, what: `${it.label} · ${note}` });
}
export function reopen(j: Journey, key: string, w: Who, why: string): Journey {
  const it = j.items.find(i => i.key === key)!; return log(upd(j, key, i => ({ ...i, status: 'open', doneAt: undefined, doneBy: undefined, waiver: undefined })), { at: w.at, by: w.by, role: w.role, kind: 'reopened', item: key, what: `${it.label} reopened · ${why}` });
}
export function changeItem(j: Journey, key: string, w: Who, patch: Partial<Pick<JItem, 'label' | 'owner' | 'due' | 'note'>>): Journey {
  const it = j.items.find(i => i.key === key)!; const what = Object.entries(patch).map(([k, v]) => `${k}: ${(it as any)[k] ?? '—'} → ${v}`).join('; ');
  return log(upd(j, key, i => ({ ...i, ...patch })), { at: w.at, by: w.by, role: w.role, kind: 'changed', item: key, what: `${it.label} · ${what}` });
}
export interface WaiveInput { reason: string; details: string; followUp: { label: string; owner: JOwner; due: string } }
export function waiveProblems(x: WaiveInput): string[] {
  const p: string[] = []; if (!x.reason.trim()) p.push('a reason'); if (x.details.trim().length < 10) p.push('details (at least 10 characters)');
  if (!x.followUp.label.trim()) p.push('a follow-up task'); if (!x.followUp.due) p.push('a follow-up due date'); return p;
}
/** Waive = exception with a required reason AND a required follow-up task (Kevin's doc). The follow-up becomes an open item that is
 *  carried forward until closed, and Step 8 cannot complete while it is open. Safety checkpoints can only be waived by a clinician. */
export function waive(j: Journey, key: string, x: WaiveInput, w: Who): Journey {
  const p = waiveProblems(x); if (p.length) throw new Error(`Waiver needs ${p.join(', ')}`);
  const it = j.items.find(i => i.key === key); if (!it) throw new Error(`No item ${key}`);
  if (it.safety && !/md|surgeon|physician|rn|nurse practitioner|physician assistant/i.test(w.role)) throw new Error('Safety checkpoints can only be waived by a clinician');
  const fuKey = `fu-${key}-${j.items.filter(i => i.followUpOf === key).length + 1}`;
  const fu: JItem = { id: `${j.id}:${fuKey}`, key: fuKey, step: it.step, label: x.followUp.label.trim(), owner: x.followUp.owner, action: 'mark', status: 'open', needs: [], optional: false, due: x.followUp.due, followUpOf: key, carry: true };
  const wv: Waiver = { reason: x.reason.trim(), details: x.details.trim(), by: w.by, at: w.at, followUp: fuKey };
  let n: Journey = { ...j, items: [...j.items.map(i => i.key === key ? { ...i, status: 'waived' as const, doneAt: w.at, doneBy: w.by, waiver: wv } : i), fu] };
  n = log(n, { at: w.at, by: w.by, role: w.role, kind: 'waived', item: key, what: `${it.label} waived: ${x.reason.trim()} · “${x.details.trim()}”` });
  return log(n, { at: w.at, by: w.by, role: w.role, kind: 'created', item: fuKey, what: `Follow-up task “${fu.label}” for ${JOWNER_LABEL[fu.owner]}, due ${fu.due}` });
}
/** Chart facts (from stations, scheduler, notes, payments, episode) close matching items automatically, attributed to whoever did the work. */
export function applyFacts(j: Journey, facts: Record<string, { by: string; at: string; note?: string } | undefined>, role = 'Vityls'): Journey {
  let n = j;
  for (const i of j.items) {
    const f = i.fact && facts[i.fact]; if (!f || closed(i)) continue;
    if (blockersOf(n, n.items.find(x => x.key === i.key)!).length) continue;
    n = complete(n, i.key, { by: f.by, role, at: f.at }, f.note || 'recorded in the chart');
  }
  return n;
}
/** Advance: when the current step's rule is satisfied, close it and open the next step on the patient's path. */
export function advance(j: Journey, w: Who): Journey {
  const path = pathFor(j.kind).filter(n => stepState(j, n) !== 'skipped'); let n = j;
  for (let guard = 0; guard < 12; guard++) {
    if (n.closedAt || !completeCheck(n, n.current).ok) break;
    const idx = path.indexOf(n.current); const nxt = path[idx + 1];
    n = { ...n, steps: n.steps.map(s => s.n === n.current ? { ...s, state: 'done', doneAt: w.at } : s.n === nxt ? { ...s, state: 'active', openedAt: w.at } : s) };
    n = log(n, { at: w.at, by: w.by, role: w.role, kind: 'step', what: `Step ${n.current} · ${stepDef(n.current).title} complete${nxt ? ` → Step ${nxt} · ${stepDef(nxt).title}` : ' · journey closed (no automatic PDF)'}` });
    if (!nxt) { n = { ...n, closedAt: w.at }; break; }
    n = { ...n, current: nxt };
  }
  return n;
}
/** Jump to a step (e.g. surgery-day trigger) — earlier active steps stay open with their items carried. */
export function openStep(j: Journey, step: StepNo, w: Who, why: string): Journey {
  if (stepState(j, step) === 'skipped') return j;
  return log({ ...j, current: step, steps: j.steps.map(s => s.n === step ? { ...s, state: 'active', openedAt: s.openedAt || w.at } : s.state === 'active' && s.n !== step ? { ...s, state: completeCheck(j, s.n).ok ? 'done' : 'active' } : s) }, { at: w.at, by: w.by, role: w.role, kind: 'step', what: `Step ${step} opened · ${why}` });
}
/** Step 2 "Ready" status and Step 8 "Ready for surgery" / hold. */
export function markReady(j: Journey, n: 2 | 8, w: Who): Journey {
  const c = completeCheck(j, n); if (!c.ok) throw new Error(`Not ready: ${c.missing.join(', ')}`);
  return log({ ...j, steps: j.steps.map(s => s.n === n ? { ...s, ready: { at: w.at, by: w.by }, holdReason: undefined } : s) }, { at: w.at, by: w.by, role: w.role, kind: 'step', what: n === 2 ? 'Marked Ready for the visit' : 'Marked Ready for surgery' });
}
export function hold(j: Journey, n: StepNo, reason: string, w: Who): Journey {
  if (reason.trim().length < 5) throw new Error('A hold needs a documented reason');
  return log({ ...j, steps: j.steps.map(s => s.n === n ? { ...s, state: 'hold', holdReason: reason.trim() } : s) }, { at: w.at, by: w.by, role: w.role, kind: 'hold', what: `Step ${n} on hold · ${reason.trim()}` });
}
export const isReady = (j: Journey, n: 2 | 8) => !!j.steps.find(s => s.n === n)?.ready;
/** Who did what on this item (completed, reviewed, changed, waived), newest first. */
export const itemAudit = (j: Journey, key: string) => j.audit.filter(a => a.item === key).slice().reverse();
/** The one Next action for the step (role-aware): first unblocked open item, mine first, then by due date. */
export function nextAction(j: Journey, n: StepNo, owner?: JOwner): JItem | undefined {
  const xs = openItems(j, n).filter(i => statusOf(j, i) === 'open');
  const sorted = xs.sort((a, b) => (a.due || '9999').localeCompare(b.due || '9999'));
  return (owner && sorted.find(i => i.owner === owner)) || sorted[0];
}
export function forOwner(items: JItem[], owner: JOwner | 'all'): JItem[] { return owner === 'all' ? items : [...items.filter(i => i.owner === owner), ...items.filter(i => i.owner !== owner)]; }
export const ROLE_TO_OWNER = (role: string): JOwner | 'all' => /front|reception|desk/i.test(role) ? 'front' : /surgeon|physician|^md|, md|nurse practitioner|physician assistant/i.test(role) ? 'surgeon' : /rn|nurse|assistant|coordinator/i.test(role) ? 'nurse' : 'all';
