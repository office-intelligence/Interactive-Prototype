/* v1.2 P7 · Face sheet (for pathology / lab samples) and Avery 5160 patient labels, opened in a print window. Simulated, local only. */
import { medRepo, MedPatient, ageFrom } from '../../med/record';
import { getSettings } from '../../med/settings';
import { cardsFor, cardImg } from '../v12/cards';
import { faceSheetHtml, labelSheetHtml } from './print';
const open = (html: string) => { const w = window.open('', '_blank'); if (!w) return false; w.document.open(); w.document.write(html); w.document.close(); return true; };
export const faceSheetFor = (p: MedPatient, by: string) => { const c = cardsFor(p.id); const ins = c.insurance[0]; const img = (slot: string, side: 'front' | 'back') => { try { return (cardImg(p.id, slot, side) as any) || undefined; } catch { return undefined; } };
  return faceSheetHtml({ practice: getSettings().practiceName, name: p.name, dob: p.dob, age: ageFrom(p.dob), sex: p.sex || '', mrn: p.id, phone: p.phone, email: p.email, address: (p as any).address, provider: p.primaryProvider,
    insurance: ins && ins.carrier ? { payer: ins.carrier, member: ins.memberId, group: ins.group } : null, payment: ins?.carrier ? undefined : 'Self-pay', idImage: img('id', 'front'), cardFront: ins ? img(ins.id, 'front') : undefined, cardBack: ins ? img(ins.id, 'back') : undefined, printedBy: by, printedAt: new Date().toLocaleString('en-US') }); };
export const labelsFor = (p: MedPatient, count = 30, startAt = 1) => labelSheetHtml({ name: p.name, mrn: p.id, dob: p.dob, age: ageFrom(p.dob), provider: p.primaryProvider }, count, startAt);
export const printFaceSheet = (pid: string, by: string) => { const p = medRepo.patient(pid); return !!p && open(faceSheetFor(p, by)); };
export const printLabels = (pid: string, count = 30, startAt = 1) => { const p = medRepo.patient(pid); return !!p && open(labelsFor(p, count, startAt)); };
