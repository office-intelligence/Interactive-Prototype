/*
 * Surgery.Vityls v1.2 · Sparing confirmation (pure, unit-tested). Kevin: "treat confirmation sparingly and only when absolutely required."
 * Every data category quietly stores when it was last confirmed and by whom (shown on hover). Staff are asked to confirm ONLY when:
 *   1. the data is stale beyond the practice limit (default 12 months; never confirmed counts as stale),
 *   2. it changed or contradicts an incoming record (e.g. an outside H&P lists a medication we don't have), or
 *   3. it is a safety checkpoint: ID at the first arrival, allergies + medications at rooming, signed consent before surgery.
 * Patient Portal confirmations count, so staff don't re-ask (except ID, which must be seen in person once).
 * When a confirmation is needed it is ONE "All still correct" tap per group, never field by field.
 */
export type Cat = 'demographics' | 'contact' | 'insurance' | 'pharmacy' | 'prefs' | 'id' | 'history' | 'medications' | 'allergies' | 'specialists' | 'diagnoses' | 'surgeries' | 'consents';
export const CAT_LABEL: Record<Cat, string> = { demographics: 'Demographics', contact: 'Contacts', insurance: 'Insurance / self-pay', pharmacy: 'Pharmacy', prefs: 'Communication preferences', id: 'Photo ID & cards', history: 'Medical, surgical, family & social history', medications: 'Medications', allergies: 'Allergies', specialists: 'Specialists', diagnoses: 'Diagnoses', surgeries: 'Prior surgeries', consents: 'Consents' };
export const ALL_CATS = Object.keys(CAT_LABEL) as Cat[];
export const GROUPS: { id: string; label: string; cats: Cat[] }[] = [
  { id: 'admin', label: 'Registration (demographics, contacts, insurance, pharmacy, preferences)', cats: ['demographics', 'contact', 'insurance', 'pharmacy', 'prefs'] },
  { id: 'id', label: 'Photo ID & insurance cards', cats: ['id'] },
  { id: 'clinical', label: 'Medications & allergies', cats: ['medications', 'allergies'] },
  { id: 'history', label: 'History, diagnoses, prior surgeries & specialists', cats: ['history', 'diagnoses', 'surgeries', 'specialists'] },
  { id: 'consents', label: 'Consents', cats: ['consents'] },
];
export type Via = 'staff' | 'portal' | 'in-person' | 'import';
export interface LastConf { at: string; by: string; via: Via }
export type Confirmations = Partial<Record<Cat, LastConf>>;
export type Checkpoint = 'first-arrival' | 'rooming' | 'pre-surgery';
export const CHECKPOINT_CATS: Record<Checkpoint, Cat[]> = { 'first-arrival': ['id'], rooming: ['allergies', 'medications'], 'pre-surgery': ['consents'] };
export interface Rules { staleMonths: number; checkpointFreshDays: number }
export const DEFAULT_RULES: Rules = { staleMonths: 12, checkpointFreshDays: 7 };
export type Reason = 'stale' | 'changed' | 'checkpoint';
export interface Need { cat: Cat; reason: Reason; text: string }
const days = (from: string, to: string) => Math.round((Date.parse(to.slice(0, 10)) - Date.parse(from.slice(0, 10))) / 864e5);
const usd = (iso: string) => { const [y, m, d] = iso.slice(0, 10).split('-'); return `${m}/${d}/${y}`; };

export interface NeedCtx { today: string; rules?: Rules; checkpoint?: Checkpoint; changed?: Cat[]; since?: string }
/** Does this category need a confirmation right now? null = no, stay quiet. */
export function needFor(cat: Cat, c: Confirmations, x: NeedCtx): Need | null {
  const r = x.rules || DEFAULT_RULES; const lc = c[cat];
  if (x.changed?.includes(cat)) return { cat, reason: 'changed', text: `${CAT_LABEL[cat]}: an incoming record differs from ours` };
  if (x.checkpoint && CHECKPOINT_CATS[x.checkpoint].includes(cat)) {
    if (cat === 'id') { if (!lc || lc.via === 'portal' || lc.via === 'import') return { cat, reason: 'checkpoint', text: 'Photo ID must be seen in person once, at the first arrival' }; }
    else if (cat === 'consents') { if (!lc || (x.since && lc.at < x.since)) return { cat, reason: 'checkpoint', text: 'Signed consent for this surgery is required before surgery' }; }
    else if (!lc || days(lc.at, x.today) > r.checkpointFreshDays) return { cat, reason: 'checkpoint', text: `${CAT_LABEL[cat]} are checked at rooming${lc ? ` (last confirmed ${usd(lc.at)})` : ''}` };
    return null;
  }
  if (!lc) return { cat, reason: 'stale', text: `${CAT_LABEL[cat]}: never confirmed` };
  if (days(lc.at, x.today) > r.staleMonths * 30.44) return { cat, reason: 'stale', text: `${CAT_LABEL[cat]}: last confirmed ${usd(lc.at)}, older than ${r.staleMonths} months` };
  return null;
}
export const needsFor = (cats: Cat[], c: Confirmations, x: NeedCtx) => cats.map(k => needFor(k, c, x)).filter((n): n is Need => !!n);
/** One prompt per group (a single "All still correct" tap), only for groups with at least one need. */
export function groupPrompts(cats: Cat[], c: Confirmations, x: NeedCtx): { id: string; label: string; cats: Cat[]; needs: Need[] }[] {
  const needs = needsFor(cats, c, x);
  return GROUPS.map(g => ({ id: g.id, label: g.label, cats: g.cats.filter(k => cats.includes(k)), needs: needs.filter(n => g.cats.includes(n.cat)) })).filter(g => g.needs.length);
}
/** "All still correct": one tap confirms the whole group. */
export function confirmGroup(c: Confirmations, cats: Cat[], who: LastConf): Confirmations { const n = { ...c }; cats.forEach(k => { n[k] = { ...who }; }); return n; }
export const lcText = (lc?: LastConf) => !lc ? 'never confirmed' : `${usd(lc.at)} by ${lc.via === 'portal' ? `${lc.by} (Portal)` : lc.by}`;

/* ---------------- contradictions with incoming records ---------------- */
export interface Med { name: string; dose: string }
export interface MedDiff { kind: 'new' | 'changed' | 'missing'; ours?: Med; theirs?: Med; text: string }
const base = (n: string) => n.toLowerCase().replace(/\b(er|xr|sr|xl|cr|dr|la)\b/g, '').replace(/[^a-z]/g, ' ').trim().split(/\s+/)[0];
const norm = (m: Med) => `${m.name} ${m.dose}`.toLowerCase().replace(/\s+/g, ' ').trim();
/** Compare our medication list with an outside record (H&P, discharge summary). Facts only. */
export function medDiffs(ours: Med[], theirs: Med[]): MedDiff[] {
  const out: MedDiff[] = [];
  theirs.forEach(t => { const o = ours.find(m => base(m.name) === base(t.name));
    if (!o) out.push({ kind: 'new', theirs: t, text: `${t.name} ${t.dose} is listed in the outside record and not in ours` });
    else if (norm(o) !== norm(t)) out.push({ kind: 'changed', ours: o, theirs: t, text: `Outside record lists ${t.name} ${t.dose}; ours has ${o.name} ${o.dose}` }); });
  ours.forEach(o => { if (!theirs.some(t => base(t.name) === base(o.name))) out.push({ kind: 'missing', ours: o, text: `${o.name} ${o.dose} is in our record but not in the outside record` }); });
  return out;
}
export function allergyDiffs(ours: string[], theirs: string[]): string[] {
  const b = (s: string) => s.toLowerCase().replace(/\(.*\)/, '').trim();
  return theirs.filter(t => !ours.some(o => b(o) === b(t))).map(t => `${t} is listed in the outside record and not in ours`);
}

/* ---------------- Step 11: reconciliation marks ---------------- */
export type Mark = 'confirmed' | 'changed' | 'unknown' | 'needs-review';
export const MARK_LABEL: Record<Mark, string> = { confirmed: 'Confirmed', changed: 'Changed', unknown: 'Unknown', 'needs-review': 'Needs review' };
/** Default mark for each category on a returning patient: fresh → confirmed; stale → needs review; never → unknown. */
export function defaultMarks(c: Confirmations, today: string, rules: Rules = DEFAULT_RULES, cats: Cat[] = ALL_CATS): Record<string, Mark> {
  const m: Record<string, Mark> = {}; cats.forEach(k => { const lc = c[k]; m[k] = !lc ? 'unknown' : days(lc.at, today) > rules.staleMonths * 30.44 ? 'needs-review' : 'confirmed'; }); return m;
}
export const reconciled = (marks: Record<string, Mark>) => Object.values(marks).every(v => v === 'confirmed' || v === 'changed');
