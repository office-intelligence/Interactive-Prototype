/* ASC.Vityls v8.8 · PAYMENT GATEWAY ADAPTER (single integration point for Henry).
 * Today: SIMULATED — nothing is charged, no card data leaves the browser, only brand + last 4 are kept.
 * To go live: implement PaymentGateway with the vendor's tokenized SDK (card fields in the vendor iframe; never send PAN/CVV to our server)
 * and call setGateway(live) at startup. Every Collect button goes through chargeCard() below. */
import { luhn, expOk, last4 } from './pure88';
export interface ChargeRequest { amount: number; currency: 'USD'; caseId: string; patientId: string; card?: { number: string; exp: string; cvv: string; zip: string; name: string }; method: 'card' | 'cash' | 'check' }
export interface ChargeResult { ok: boolean; ref: string; brand?: string; last4?: string; message: string; simulated: boolean }
export interface PaymentGateway { name: string; live: boolean; charge(r: ChargeRequest): Promise<ChargeResult> }
const brand = (n: string) => /^4/.test(n) ? 'Visa' : /^5[1-5]/.test(n) ? 'Mastercard' : /^3[47]/.test(n) ? 'Amex' : /^6/.test(n) ? 'Discover' : 'Card';
export const simulatedGateway: PaymentGateway = { name: 'Simulated (no gateway connected)', live: false, async charge(r) {
  if (!(r.amount > 0)) return { ok: false, ref: '', message: 'Enter an amount.', simulated: true };
  if (r.method !== 'card') return { ok: true, ref: `SIM-${r.method.toUpperCase()}-${Date.now().toString(36).toUpperCase()}`, message: 'Recorded (simulated).', simulated: true };
  const c = r.card; const n = (c?.number || '').replace(/\D/g, '');
  if (!luhn(n)) return { ok: false, ref: '', message: 'Card number is not valid.', simulated: true };
  if (!expOk(c!.exp)) return { ok: false, ref: '', message: 'Expiry must be MM/YY and not in the past.', simulated: true };
  if (!/^\d{3,4}$/.test(c!.cvv)) return { ok: false, ref: '', message: 'CVV must be 3 or 4 digits.', simulated: true };
  if (n.endsWith('0002')) return { ok: false, ref: '', message: 'Declined by the simulated gateway (test decline card).', simulated: true };
  return { ok: true, ref: `SIM-AUTH-${Date.now().toString(36).toUpperCase()}`, brand: brand(n), last4: last4(n), message: 'Approved (simulated).', simulated: true }; } };
let current: PaymentGateway = simulatedGateway;
export const gateway = () => current;
export const setGateway = (g: PaymentGateway) => { current = g; };
export const chargeCard = (r: ChargeRequest) => current.charge(r);
