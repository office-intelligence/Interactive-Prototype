/* ASC.Vityls v8.8 · journey bar on every station: numbered/checked steps for this patient's episode; tap a step to open that station
 * for the same patient. Never blocks. Lean: no done-steps recap. Fictional data. */
import React from 'react';
import { Check, ChevronRight } from 'lucide-react';
import { medRepo } from '../../med/record';
import * as A from '../asc8/logic';
import * as S from '../asc8/store';
import { openAsc } from '../asc8/ui';
import { openBench } from '../asc81/practice81';
import type { Bench } from '../asc81/Workbench';
import * as D86 from '../asc86/store86';
import * as P from './pure88';
import { historyVerified } from '../asc10/store10';
type Go = { bench?: Bench; asc?: () => void };
const GO = (c: A.AscCase): Record<P.StepKey, Go> => ({
  booking: { asc: () => openAsc({ t: 'details', cid: c.id } as any) }, verify: { bench: 'verify' }, preop: { bench: 'brief' }, checkin: { bench: 'arrival' }, nursing: { bench: 'nursing' },
  anesthesia: { bench: 'anesthesia' }, surgeon: { bench: 'surgeon' }, or: { asc: () => openAsc({ t: 'step', cid: c.id, station: 'or' } as any) }, pacu: { bench: 'pacu' },
  discharge: { bench: 'discharge' }, followup: { bench: 'after' }, closure: { bench: 'closure' } });
export const BENCH_STEP: Partial<Record<Bench, P.StepKey>> = { verify: 'verify', brief: 'anesthesia', arrival: 'checkin', nursing: 'nursing', anesthesia: 'anesthesia', surgeon: 'surgeon', pacu: 'pacu', discharge: 'discharge', after: 'followup', closure: 'closure', orders: 'surgeon' };
export const JourneyBar: React.FC<{ c: A.AscCase; here?: P.StepKey; onLeave?: () => void; next?: A.AscCase; onNext?: () => void }> = ({ c, here, onLeave, next, onNext }) => {
  const cur = P.currentStep(c.loc as P.Loc, { followUpDone: !!D86.followUp(c.id)?.done, closed: !!D86.closeState(c.id).closed, verified: historyVerified(c.id) }); const g = GO(c);
  const p = medRepo.patient(c.pid); const first = (p?.name || 'Patient').split(' ')[0];
  const open = (k: P.StepKey) => { const x = g[k]; onLeave?.(); if (x.bench) openBench(x.bench, c.id); else x.asc?.(); };
  return <div className="a88-journey" data-testid="a88-journey">
    <div className="a88-jhead"><b>{first.toUpperCase()}'S JOURNEY · {c.procedure.toUpperCase()}</b><span className="sv-small sv-muted">Step {Math.min(cur + 1, P.JOURNEY.length)} of {P.JOURNEY.length} · tap a step to open it</span>
      {next && <button type="button" className="a88-next" onClick={onNext} data-testid="a88-next-patient">Next patient: {medRepo.patient(next.pid)?.name?.split(' ')[0]} <ChevronRight size={14} /></button>}</div>
    <ol className="a88-steps">{P.JOURNEY.map((s, i) => { const st = P.stepState(i, cur); const on = here === s.k;
      return <li key={s.k} className={`a88-step ${st} ${on ? 'here' : ''}`}><button type="button" onClick={() => open(s.k)} aria-current={on ? 'step' : undefined} data-testid={`a88-step-${s.k}`} data-state={st} title={`Open ${s.label} for ${p?.name}`}>
        <span className="a88-circle">{st === 'done' ? <Check size={14} /> : i + 1}</span><span className="a88-lbl">{s.label}</span>{on && <span className="a88-now">HERE</span>}</button></li>; })}</ol>
  </div>;
};
/** For the single-panel stations (booking details, check-in, OR step, surgeon tab): the same bar docked at the top of the screen. */
export const JourneyDock: React.FC<{ cid: string; here?: P.StepKey; onLeave: () => void }> = ({ cid, here, onLeave }) => { const ref = React.useRef<HTMLDivElement>(null); /* v8.9: dock height feeds the slide-over offset */
  React.useLayoutEffect(() => { const el = ref.current; if (!el) return; const set = () => document.documentElement.style.setProperty('--v9-dockh', `${Math.ceil(el.getBoundingClientRect().height)}px`); set(); const ro = new ResizeObserver(set); ro.observe(el); return () => ro.disconnect(); });
  const c = S.caseById(cid); if (!c) return null;
  return <div ref={ref} className="a88-dock" data-testid="a88-dock"><JourneyBar c={c} here={here} onLeave={onLeave} /></div>; };
