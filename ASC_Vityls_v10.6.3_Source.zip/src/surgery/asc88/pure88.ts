/* ASC.Vityls v8.8 · pure logic (unit-tested): episode journey steps, upload→checklist links, block-time generation, fee schedule lines. Fictional data. */
export type StepKey = 'booking' | 'verify' | 'preop' | 'checkin' | 'nursing' | 'anesthesia' | 'surgeon' | 'or' | 'pacu' | 'discharge' | 'followup' | 'closure';
export const JOURNEY: { k: StepKey; label: string }[] = [
  { k: 'booking', label: 'Booking' }, { k: 'checkin', label: 'Check-in' }, { k: 'verify', label: 'Verify medical history' }, { k: 'nursing', label: 'Nursing admission' },
  { k: 'anesthesia', label: 'Anesthesia' }, { k: 'surgeon', label: 'Surgeon' }, { k: 'or', label: 'OR' }, { k: 'pacu', label: 'PACU' }, { k: 'discharge', label: 'Discharge' },
  { k: 'followup', label: 'Follow-up' }, { k: 'closure', label: 'Closure' }];
export type Loc = 'scheduled' | 'arrived' | 'preop' | 'or' | 'pacu' | 'discharged' | 'closed';
/** Index of the step the patient is at now, from location (+ follow-up done). */
export function currentStep(loc: Loc, o: { followUpDone?: boolean; closed?: boolean; verified?: boolean } = {}): number {
  const k: StepKey = loc === 'scheduled' ? 'checkin' : loc === 'arrived' ? (o.verified ? 'nursing' : 'verify') : loc === 'preop' ? 'anesthesia' : loc === 'or' ? 'or' : loc === 'pacu' ? 'pacu'
    : loc === 'discharged' ? (o.followUpDone ? 'closure' : 'followup') : 'closure';
  const i = JOURNEY.findIndex(s => s.k === k); return loc === 'closed' || o.closed ? JOURNEY.length : i;
}
export const stepState = (i: number, cur: number) => i < cur ? 'done' : i === cur ? 'now' : 'todo';

/** Upload document types → booking checklist item ids they satisfy. */
export const DOC_TO_CHECK: Record<string, string[]> = {
  'Pre-op H&P': ['hp'], 'Medical clearance': ['clearance'], 'Lab results': ['labs'], 'ECG': ['ecg'], 'Consent (outside)': ['consent'], 'Surgical consent': ['consent'],
  'Registration forms': ['portal'], 'Ride home & caregiver': ['ride'], 'Post-op care location': ['lodging'], 'H&P + clearance': ['hp', 'clearance'] };
export function uploadChecks(types: string[]): Record<string, boolean> { const o: Record<string, boolean> = {}; types.forEach(t => (DOC_TO_CHECK[t] || []).forEach(k => { o[k] = true; })); return o; }

/** Block time: dates in [start,end] whose weekday (0=Sun..6=Sat) is selected. */
export function blockDates(start: string, end: string, days: number[], max = 120): string[] {
  const out: string[] = []; if (!start || !end || end < start) return out; let d = new Date(start + 'T12:00:00Z');
  while (out.length < max) { const iso = d.toISOString().slice(0, 10); if (iso > end) break; if (days.includes(d.getUTCDay())) out.push(iso); d = new Date(d.getTime() + 864e5); }
  return out;
}
export const toMin = (t: string) => { const [h, m] = t.split(':').map(Number); return h * 60 + (m || 0); };

/** Practice fee schedule (itemized). */
export interface FeeItem { id: string; cat: 'Facility fee' | 'Anesthesia' | 'Implants' | 'Supplies' | 'Pathology' | 'Other'; label: string; amount: number; procedure?: string; active: boolean }
export const FEE_CATS: FeeItem['cat'][] = ['Facility fee', 'Anesthesia', 'Implants', 'Supplies', 'Pathology', 'Other'];
export const FEE_SEED: FeeItem[] = [
  { id: 'f1', cat: 'Facility fee', label: 'Facility fee · first hour of OR time', amount: 1800, active: true },
  { id: 'f2', cat: 'Facility fee', label: 'Facility fee · each additional 30 min', amount: 450, active: true },
  { id: 'f3', cat: 'Anesthesia', label: 'Anesthesia professional fee · first hour', amount: 900, active: true },
  { id: 'f4', cat: 'Anesthesia', label: 'Anesthesia · each additional 15 min', amount: 150, active: true },
  { id: 'f5', cat: 'Implants', label: 'Breast implants (pair)', amount: 2400, procedure: 'breast', active: true },
  { id: 'f6', cat: 'Implants', label: 'Hernia mesh', amount: 350, procedure: 'hernia', active: true },
  { id: 'f7', cat: 'Supplies', label: 'Surgical supplies & dressings', amount: 250, active: true },
  { id: 'f8', cat: 'Pathology', label: 'Pathology specimen', amount: 180, procedure: 'excision|lipoma', active: true },
  { id: 'f9', cat: 'Other', label: 'Post-op garment', amount: 120, procedure: 'abdominoplasty|lipo|breast', active: true }];
/** Invoice lines: every active non-procedure-specific item (facility/anesthesia base & supplies) + items whose procedure pattern matches. Extra-time items are excluded unless minutes exceed 60. */
export function feeLines(items: FeeItem[], procedure: string, minutes = 60): { label: string; detail: string; amount: number }[] {
  const out: { label: string; detail: string; amount: number }[] = [];
  for (const f of items.filter(i => i.active)) {
    if (f.procedure && !new RegExp(f.procedure, 'i').test(procedure)) continue;
    if (/additional 30/i.test(f.label)) { const n = Math.max(0, Math.ceil((minutes - 60) / 30)); if (n) out.push({ label: f.cat, detail: `${f.label} × ${n}`, amount: f.amount * n }); continue; }
    if (/additional 15/i.test(f.label)) { const n = Math.max(0, Math.ceil((minutes - 60) / 15)); if (n) out.push({ label: f.cat, detail: `${f.label} × ${n}`, amount: f.amount * n }); continue; }
    out.push({ label: f.cat, detail: f.label, amount: f.amount });
  }
  return out;
}
/** Card checks (simulated gateway). */
export const luhn = (n: string) => { const d = n.replace(/\D/g, ''); if (d.length < 13) return false; let s = 0; for (let i = 0; i < d.length; i++) { let x = +d[d.length - 1 - i]; if (i % 2) { x *= 2; if (x > 9) x -= 9; } s += x; } return s % 10 === 0; };
export const expOk = (mmyy: string, now = new Date()) => { const m = /^(\d{2})\s*\/\s*(\d{2})$/.exec(mmyy); if (!m) return false; const mo = +m[1], y = 2000 + +m[2]; if (mo < 1 || mo > 12) return false; return y > now.getFullYear() || (y === now.getFullYear() && mo >= now.getMonth() + 1); };
export const last4 = (n: string) => n.replace(/\D/g, '').slice(-4);
