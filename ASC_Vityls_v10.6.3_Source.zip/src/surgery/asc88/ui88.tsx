/* ASC.Vityls v8.8 · fee schedule (itemized) + facility profile & logo settings, invoice letterhead, standard card-processing popup (v7.5 style).
 * Payments stay SIMULATED until a gateway is connected (asc88/gateway.ts). Fictional data. */
import React, { useEffect, useState } from 'react';
import { CreditCard, Lock, Plus, Trash2, Upload, X } from 'lucide-react';
import { medRepo } from '../../med/record';
import { useActor, useMedTick } from '../../med/ui';
import { useSv } from '../ui';
import * as S from '../asc8/store';
import { collectPayment, caseMoney, type CasePay } from '../asc83/pay';
import * as P from './pure88';
import * as D from './store88';
import { chargeCard, gateway } from './gateway';
import { addCredit, availableCredit } from '../asc89/store89';
const money = (n: number) => `$${n.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

/* ---------- fee schedule ---------- */
export const FeeScheduleSettings: React.FC = () => {
  useMedTick(); const [actor] = useActor(); const { toast } = useSv(); const [l, setL] = useState<P.FeeItem[]>(() => D.feeItems()); const dirty = JSON.stringify(l) !== JSON.stringify(D.feeItems());
  const up = (id: string, x: Partial<P.FeeItem>) => setL(l.map(f => f.id === id ? { ...f, ...x } : f));
  const add = () => setL([...l, { id: `f${Date.now().toString(36)}`, cat: 'Other', label: 'New fee item', amount: 0, active: true }]);
  return <section className="sv-sec mt-8 a88-card" id="fee-schedule" data-testid="a88-fees"><h2 className="sv-title" style={{ fontSize: 20 }}>Fee schedule (cash-pay prices)</h2>
    <p className="sv-small sv-muted">Itemized prices used to build every cash-pay invoice. "Applies to" is an optional procedure keyword (e.g. <i>breast</i>, <i>hernia</i>); blank = every case. Extra-time items are added only when the booked time is over 60 min. Example prices · fictional.</p>
    <div className="a88-tablewrap"><table className="sv-table a88-feet"><thead><tr><th>Category</th><th>Item</th><th>Amount</th><th>Applies to</th><th>Active</th><th /></tr></thead>
      <tbody>{l.map(f => <tr key={f.id} data-testid="a88-fee-row"><td><select className="sv-input" value={f.cat} onChange={e => up(f.id, { cat: e.target.value as P.FeeItem['cat'] })}>{P.FEE_CATS.map(c => <option key={c}>{c}</option>)}</select></td>
        <td><input className="sv-input" value={f.label} onChange={e => up(f.id, { label: e.target.value })} data-testid="a88-fee-label" /></td>
        <td><input className="sv-input" inputMode="decimal" style={{ width: 110 }} value={String(f.amount)} onChange={e => up(f.id, { amount: +e.target.value || 0 })} data-testid="a88-fee-amt" /></td>
        <td><input className="sv-input" style={{ width: 150 }} placeholder="all cases" value={f.procedure || ''} onChange={e => up(f.id, { procedure: e.target.value || undefined })} /></td>
        <td><input type="checkbox" checked={f.active} onChange={e => up(f.id, { active: e.target.checked })} aria-label="Active" /></td>
        <td><button type="button" className="sv-link sv-small" onClick={() => setL(l.filter(x => x.id !== f.id))} aria-label={`Remove ${f.label}`} data-testid="a88-fee-del"><Trash2 size={14} /></button></td></tr>)}</tbody></table></div>
    <div className="a81-foot"><button type="button" className="a8-btn" onClick={add} data-testid="a88-fee-add"><Plus size={14} /> Add item</button><span style={{ flex: 1 }} />
      <button type="button" className="a8-btn pri" disabled={!dirty} onClick={() => { D.saveFeeItems(l, actor.name, actor.role, `${l.length} items saved`); toast('Fee schedule saved.'); }} data-testid="a88-fee-save">Save fee schedule</button></div></section>;
};

/* ---------- facility profile + logo ---------- */
const FF: [keyof D.Facility, string][] = [['name', 'Facility name'], ['address', 'Street address'], ['city', 'City, state, ZIP'], ['phone', 'Phone'], ['fax', 'Fax'], ['email', 'Billing email'], ['website', 'Website'], ['taxId', 'Tax ID'], ['npi', 'Facility NPI']];
export const FacilitySettings: React.FC = () => {
  useMedTick(); const [actor] = useActor(); const { toast } = useSv(); const [f, setF] = useState<D.Facility>(() => D.facility()); const [err, setErr] = useState(''); const dirty = JSON.stringify(f) !== JSON.stringify(D.facility());
  const pick = (file?: File) => { setErr(''); if (!file) return; if (!/^image\/(png|jpeg|svg\+xml)$/.test(file.type)) return setErr('Logo must be PNG, JPG or SVG.'); if (file.size > 512 * 1024) return setErr('Logo must be under 512 KB.');
    const r = new FileReader(); r.onload = () => setF(v => ({ ...v, logo: String(r.result), logoName: file.name })); r.readAsDataURL(file); };
  return <section className="sv-sec mt-8 a88-card" id="facility-profile" data-testid="a88-facility"><h2 className="sv-title" style={{ fontSize: 20 }}>Facility profile &amp; logo</h2>
    <p className="sv-small sv-muted">Shown on invoices, receipts and printed packets. Placeholder facility · fictional.</p>
    <div className="a88-logo"><div className="a88-logoprev" data-testid="a88-logo-preview">{f.logo ? <img src={f.logo} alt="Facility logo preview" /> : <span>No logo</span>}</div>
      <div><label className="a8-btn"><Upload size={14} /> Upload logo<input type="file" accept="image/png,image/jpeg,image/svg+xml" hidden onChange={e => pick(e.target.files?.[0])} data-testid="a88-logo-input" /></label>
        {f.logo && <button type="button" className="sv-link sv-small" style={{ marginLeft: 8 }} onClick={() => setF({ ...f, logo: undefined, logoName: undefined })}>Remove</button>}
        <p className="sv-small sv-muted">PNG, JPG or SVG · up to 512 KB{f.logoName ? ` · ${f.logoName}` : ''}</p>{err && <p className="a81-err" data-testid="a88-logo-err">{err}</p>}</div></div>
    <div className="a88-grid3">{FF.map(([k, l]) => <label key={k} className="a83-f"><span className="a83-l">{l}</span><input className="sv-input" value={String(f[k] || '')} onChange={e => setF({ ...f, [k]: e.target.value })} data-testid={`a88-fac-${k}`} /></label>)}</div>
    <div className="a81-foot"><span style={{ flex: 1 }} /><button type="button" className="a8-btn pri" disabled={!dirty} onClick={() => { D.saveFacility(f, actor.name, actor.role, f.logo !== D.facility().logo ? 'logo + details saved' : 'details saved'); toast('Facility profile saved.'); }} data-testid="a88-fac-save">Save facility profile</button></div></section>;
};
export const Letterhead: React.FC<{ number?: string; issued?: string }> = ({ number, issued }) => { const f = D.facility();
  return <div className="a88-letterhead" data-testid="a88-letterhead">{f.logo ? <img src={f.logo} alt="" className="a88-lhlogo" /> : <div className="a88-lhlogo ph">{f.name.slice(0, 1)}</div>}
    <div className="a88-lhinfo"><b>{f.name}</b><div>{f.address} · {f.city}</div><div>Phone {f.phone} · Fax {f.fax}</div><div>{f.email} · {f.website}</div><div className="sv-muted">Tax ID {f.taxId} · NPI {f.npi}</div></div>
    <div className="a88-lhinv"><div className="t">INVOICE</div><div className="n">{number || 'DRAFT'}</div><div className="sv-small">Issued {issued || '—'}</div></div></div>; };

/* ---------- standard card-processing popup ---------- */
type Open = { cid: string; amount?: number; when?: CasePay['when']; onDone?: (p: CasePay) => void; credit?: { pid: string; type: string; method: string; notes: string; ref: string; onDone?: (receipt: string) => void } };
export const openCardPay = (o: Open) => window.dispatchEvent(new CustomEvent('asc88-card', { detail: o }));
export const CardPayHost: React.FC = () => { const [o, setO] = useState<Open | null>(null);
  useEffect(() => { const h = (e: Event) => setO((e as CustomEvent).detail); window.addEventListener('asc88-card', h); return () => window.removeEventListener('asc88-card', h); }, []);
  return o ? <CardPayDialog {...o} onClose={() => setO(null)} /> : null; };
export const CardPayDialog: React.FC<Open & { onClose: () => void }> = ({ cid, amount, when, onDone, onClose, credit }) => {
  const [actor] = useActor(); const c0 = cid ? S.caseById(cid) : undefined; const pid = c0?.pid || credit?.pid || ''; const c = c0 || ({ id: '', pid, procedure: 'Patient account credit', date: new Date().toISOString().slice(0, 10), loc: 'scheduled' } as any); const p = medRepo.patient(pid); const m = c0 ? caseMoney(c0) : { balance: amount || 0, due: 0, paid: 0, status: 'none' as const }; const fac = D.facility();
  const [method, setMethod] = useState<'card' | 'cash' | 'check'>('card'); const [amt, setAmt] = useState(String(amount ?? m.balance ?? ''));
  const [card, setCard] = useState({ name: p?.name || '', number: '', exp: '', cvv: '', zip: '' }); const [ref, setRef] = useState(''); const [busy, setBusy] = useState(false); const [err, setErr] = useState(''); const [rc, setRc] = useState<CasePay & { auth: string; brand?: string; last4?: string } | null>(null);
  const go = async (e: React.FormEvent) => { e.preventDefault(); setErr(''); setBusy(true);
    const r = await chargeCard({ amount: +amt, currency: 'USD', caseId: c.id, patientId: c.pid, method, card: method === 'card' ? card : undefined }); setBusy(false);
    if (!r.ok) return setErr(r.message);
    try { const label = method === 'card' ? 'Card (simulated)' : method === 'cash' ? 'Cash' : 'Check'; const refTxt = method === 'card' ? `${r.brand} •••• ${r.last4} · ${r.ref}` : method === 'check' ? `Check ${ref || '—'}` : r.ref;
      if (credit) { const cr = addCredit({ pid, amount: +amt, type: credit.type, method: method === 'card' ? `${credit.method} (simulated)` : label, ref: [credit.ref, refTxt].filter(Boolean).join(' · '), notes: credit.notes, by: actor.name, role: actor.role }); setCard({ ...card, number: '', cvv: '' }); setRc({ id: cr.id, caseId: '', pid, amount: cr.amount, method: cr.method, ref: cr.ref, at: cr.at, by: cr.by, role: cr.role, receipt: cr.receipt, when: 'other', auth: r.ref, brand: r.brand, last4: r.last4 }); credit.onDone?.(cr.receipt); return; }
      const pay = collectPayment(c, +amt, label, refTxt, actor.name, actor.role, when || (c.loc === 'scheduled' ? 'pre-service' : 'other'));
      setCard({ ...card, number: '', cvv: '' }); setRc({ ...pay, auth: r.ref, brand: r.brand, last4: r.last4 }); onDone?.(pay); } catch (x) { setErr((x as Error).message); } };
  return <div className="a81-modal a88-cardmodal" onMouseDown={e => { if (e.target === e.currentTarget) onClose(); }}>
    <div className="a88-cardpop" role="dialog" aria-label="Card payment" data-testid="a88-cardpop">
      <div className="a88-cardhead"><div><span className="k">Secure payment gateway · {gateway().live ? 'live' : 'simulated'}</span><h3>{rc ? 'Payment receipt' : 'Collect payment'}</h3></div><button type="button" onClick={onClose} aria-label="Close" data-testid="a88-card-close"><X size={20} /></button></div>
      {!rc ? <form onSubmit={go} className="a88-cardbody">
        <div className="a88-due"><div><b>{c0 ? 'Balance due' : 'Account credit / deposit'}</b><span>{p?.name} · {c0 ? `${c.procedure} · DOS ${c.date}` : credit?.type}</span></div><strong>{money(c0 ? m.balance : +amt || 0)}</strong></div>
        <div className="a88-meth" role="tablist">{(['card', 'cash', 'check'] as const).map(k => <button key={k} type="button" role="tab" aria-selected={method === k} className={method === k ? 'on' : ''} onClick={() => setMethod(k)} data-testid={`a88-meth-${k}`}>{k === 'card' ? 'Credit / debit card' : k === 'cash' ? 'Cash' : 'Check'}</button>)}</div>
        <label className="a83-f"><span className="a83-l">Amount (USD)</span><input className="sv-input" inputMode="decimal" value={amt} onChange={e => setAmt(e.target.value)} data-testid="a88-card-amt" required /></label>
        {method === 'card' && <><label className="a83-f"><span className="a83-l">Name on card</span><input className="sv-input" value={card.name} onChange={e => setCard({ ...card, name: e.target.value })} autoComplete="off" /></label>
          <label className="a83-f"><span className="a83-l">Card number</span><input className="sv-input mono" placeholder="4242 4242 4242 4242" value={card.number} onChange={e => { setErr(""); setCard({ ...card, number: e.target.value }); }} autoComplete="off" inputMode="numeric" data-testid="a88-card-num" required /></label>
          <div className="a88-grid3"><label className="a83-f"><span className="a83-l">Expires</span><input className="sv-input mono" placeholder="MM/YY" value={card.exp} onChange={e => setCard({ ...card, exp: e.target.value })} data-testid="a88-card-exp" required /></label>
            <label className="a83-f"><span className="a83-l">CVV</span><input className="sv-input mono" placeholder="123" value={card.cvv} onChange={e => setCard({ ...card, cvv: e.target.value })} autoComplete="off" data-testid="a88-card-cvv" required /></label>
            <label className="a83-f"><span className="a83-l">ZIP</span><input className="sv-input mono" placeholder="90000" value={card.zip} onChange={e => setCard({ ...card, zip: e.target.value })} data-testid="a88-card-zip" /></label></div></>}
        {method === 'check' && <label className="a83-f"><span className="a83-l">Check number</span><input className="sv-input" value={ref} onChange={e => setRef(e.target.value)} /></label>}
        {err && <p className="a81-err" data-testid="a88-card-err">{err}</p>}
        <button type="submit" className="a88-paybtn" disabled={busy} data-testid="a88-card-pay"><Lock size={14} /> {busy ? 'Processing…' : `${method === 'card' ? 'Charge' : 'Record'} ${money(+amt || 0)}`}</button>
        <p className="a88-simnote" data-testid="a88-simnote"><CreditCard size={13} /> Simulated until payment gateway connected · nothing is charged · only card brand and last 4 digits are kept. Test card 4242 4242 4242 4242.</p>
      </form> : <div className="a88-cardbody" data-testid="a88-receipt">
        <div className="a88-rchead">{fac.logo ? <img src={fac.logo} alt="" /> : null}<div><b>{fac.name}</b><div className="sv-small">{fac.address} · {fac.city} · {fac.phone}</div></div></div>
        <table className="a88-rct"><tbody><tr><td>Receipt</td><td data-testid="a88-rc-no">{rc.receipt}</td></tr><tr><td>Date</td><td>{new Date(rc.at).toLocaleString('en-US')}</td></tr><tr><td>Patient</td><td>{p?.name}</td></tr><tr><td>For</td><td>{c.procedure} · DOS {c.date}</td></tr>
          <tr><td>Method</td><td>{rc.method}{rc.last4 ? ` · ${rc.brand} •••• ${rc.last4}` : ''}</td></tr><tr><td>Authorization</td><td>{rc.auth} (simulated)</td></tr><tr><td><b>Amount paid</b></td><td><b data-testid="a88-rc-amt">{money(rc.amount)}</b></td></tr>{c0 ? <tr><td>Remaining balance</td><td>{money(caseMoney(S.caseById(cid)!).balance)}</td></tr> : <tr><td>Available account credit</td><td data-testid="a88-rc-credit">{money(availableCredit(pid))}</td></tr>}</tbody></table>
        <div className="a81-foot"><button type="button" className="a8-btn" onClick={() => window.print()} data-testid="a88-rc-print">Print receipt</button><span style={{ flex: 1 }} /><button type="button" className="a8-btn pri" onClick={onClose} data-testid="a88-rc-done">Done</button></div>
        <p className="a88-simnote">Simulated receipt · no real transaction.</p></div>}
    </div></div>;
};
