/* ASC.Vityls v9.1 · Block time popup: Edit (time, room, surgeon, notes) · Delete (this occurrence / whole series, confirmed) ·
 * Book patient in this block (opens the Appointment details popup prefilled; the case replaces or trims the block). Audited. */
import React, { useState } from 'react';
import { useActor } from '../../med/ui';
import { useSv } from '../ui';
import { Dlg } from '../asc84/appt';
import { surgeonList, surgeonColor } from '../asc83/booking';
import * as B from './block91';
const to24 = (t: string) => { const m = B.toMin(t); return isNaN(m) ? '' : `${String(Math.floor(m / 60)).padStart(2, '0')}:${String(m % 60).padStart(2, '0')}`; };
const from24 = (s: string) => { const m = /^(\d{1,2}):(\d{2})$/.exec(s); return m ? B.fmt(+m[1] * 60 + +m[2]) : s; };
export const ROOMS91 = ['OR 1', 'OR 2', 'OR 3', 'Proc 1', 'Procedure room'];
const DOW = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
export const BlockPopup: React.FC<{ b: B.Blk; onClose: () => void; onBook: (b: B.Blk) => void }> = ({ b, onClose, onBook }) => {
  const [actor] = useActor(); const { toast } = useSv(); const [ed, setEd] = useState<false | 'one' | 'series'>(false); const [conf, setConf] = useState(false); const [del, setDel] = useState(false); const [err, setErr] = useState('');
  const p0 = B.planOf(b.id) || { from: b.date, to: b.date, days: [new Date(b.date + 'T12:00').getDay()], start: b.start, end: b.end, room: b.room, surgeon: b.surgeon, notes: b.notes || '' };
  const [f, setF] = useState({ ...p0, date: b.date, start: to24(p0.start), end: to24(p0.end) }); const startEd = (sc: 'one' | 'series') => { setEd(sc); setConf(false); setErr(''); setF(sc === 'one' ? { ...p0, date: b.date, start: to24(b.start), end: to24(b.end), room: b.room, surgeon: b.surgeon, notes: b.notes || '' } : { ...p0, date: b.date, start: to24(p0.start), end: to24(p0.end) }); }; const n = B.seriesOf(b.id).length;
  const surgeons = surgeonList(); if (!surgeons.includes(f.surgeon)) surgeons.push(f.surgeon); const rooms = ROOMS91.includes(f.room) ? ROOMS91 : [...ROOMS91, f.room];
  const span = p0.from === p0.to ? p0.from : `${p0.from} to ${p0.to} · ${p0.days.map(d => DOW[d]).join(', ')}`;
  const save = () => { try { if (ed === 'one') { B.editOne(b.id, { date: f.date, start: from24(f.start), end: from24(f.end), room: f.room, surgeon: f.surgeon, notes: f.notes }, actor.name, actor.role); toast('This block updated (detached from the series).'); } else { const k = B.editBlock(b.id, { ...f, start: from24(f.start), end: from24(f.end) }, actor.name, actor.role); toast(`Series updated · ${k} slot${k === 1 ? '' : 's'}.`); } onClose(); } catch (e) { setErr((e as Error).message); setConf(false); } };
  const rm = (sc: 'one' | 'series') => { const k = B.deleteBlock(b.id, sc, actor.name, actor.role); toast(`Block deleted (${k} slot${k === 1 ? '' : 's'}).`); onClose(); };
  return <Dlg kicker="Block time" title={`${b.surgeon.replace(/,.*$/, '')} · ${b.room}`} sub={`${b.start.replace(/^0/, '')}–${b.end.replace(/^0/, '')} · ${span}${b.notes ? ` · ${b.notes}` : ''}`} testId="b91-pop" onClose={onClose}
    foot={<>{!ed && !del && <><button type="button" className="a8-btn red" onClick={() => setDel(true)} data-testid="b91-del">Delete</button><span style={{ flex: 1 }} />{n > 1 ? <><button type="button" className="a8-btn" onClick={() => startEd('one')} data-testid="b91-edit-one">Edit this block</button><button type="button" className="a8-btn" onClick={() => startEd('series')} data-testid="b91-edit-series">Edit series</button></> : <button type="button" className="a8-btn" onClick={() => startEd('one')} data-testid="b91-edit-one">Edit</button>}<button type="button" className="a8-btn pri" onClick={() => onBook(b)} data-testid="b91-book">Book patient in this block</button></>}
      {ed && !conf && <><span style={{ flex: 1 }} /><button type="button" className="a8-btn" onClick={() => setEd(false)}>Cancel</button><button type="button" className="a8-btn pri" onClick={() => setConf(true)} data-testid="b91-save">Save…</button></>}
      {ed && conf && <><span className="sv-small" style={{ flex: 1 }} data-testid="b91-save-confirm">{ed === 'one' ? (n > 1 ? 'Save this block only? It will be detached from the series.' : 'Save changes to this block?') : `Save changes to the whole series (${n} slots)?`}</span><button type="button" className="a8-btn" onClick={() => setConf(false)}>Back</button><button type="button" className="a8-btn pri" onClick={save} data-testid="b91-save-yes">Confirm</button></>}
      {del && <><span className="sv-small" style={{ flex: 1 }}>Delete which?</span><button type="button" className="a8-btn" onClick={() => setDel(false)}>Keep</button><button type="button" className="a8-btn red" onClick={() => rm('one')} data-testid="b91-del-one">This block only</button>{n > 1 && <button type="button" className="a8-btn red" onClick={() => rm('series')} data-testid="b91-del-series">Whole series ({n})</button>}</>}</>}>
    <div className="b91-sw" style={{ borderColor: surgeonColor(b.surgeon) }}><i style={{ background: surgeonColor(b.surgeon) }} />Reserved for {b.surgeon}. Edit or delete this block only, or the whole series. Booking a patient replaces only the booked slot; the rest stays blocked.</div>
    {ed && <div className="a81-grid2" style={{ marginTop: 10 }}>
      {ed === 'one' && <label className="a84-f" style={{ gridColumn: '1/-1' }}><span className="a84-l">Date</span><input type="date" className="sv-input" value={f.date} onChange={e => setF({ ...f, date: e.target.value })} data-testid="b91-date" /></label>}
      {ed === 'series' && <><label className="a84-f"><span className="a84-l">From</span><input type="date" className="sv-input" value={f.from} onChange={e => setF({ ...f, from: e.target.value })} data-testid="b91-from" /></label>
      <label className="a84-f"><span className="a84-l">To</span><input type="date" className="sv-input" value={f.to} onChange={e => setF({ ...f, to: e.target.value })} data-testid="b91-to" /></label>
      <div className="a84-f" style={{ gridColumn: '1/-1' }}><span className="a84-l">Days</span><div className="flex gap-1 flex-wrap">{DOW.map((d, i) => <button key={d} type="button" className={`a8-btn${f.days.includes(i) ? ' pri' : ''}`} onClick={() => setF({ ...f, days: f.days.includes(i) ? f.days.filter(x => x !== i) : [...f.days, i].sort() })} data-testid={`b91-dow-${i}`}>{d}</button>)}</div></div></>}
      <label className="a84-f"><span className="a84-l">Start</span><input type="time" className="sv-input" value={f.start} onChange={e => setF({ ...f, start: e.target.value })} data-testid="b91-start" /></label>
      <label className="a84-f"><span className="a84-l">End</span><input type="time" className="sv-input" value={f.end} onChange={e => setF({ ...f, end: e.target.value })} data-testid="b91-end" /></label>
      <label className="a84-f"><span className="a84-l">Room</span><select className="sv-input" value={f.room} onChange={e => setF({ ...f, room: e.target.value })} data-testid="b91-room">{rooms.map(r => <option key={r}>{r}</option>)}</select></label>
      <label className="a84-f"><span className="a84-l">Surgeon</span><select className="sv-input" value={f.surgeon} onChange={e => setF({ ...f, surgeon: e.target.value })} data-testid="b91-surgeon">{surgeons.map(r => <option key={r}>{r}</option>)}</select></label>
      <label className="a84-f" style={{ gridColumn: '1/-1' }}><span className="a84-l">Notes</span><input className="sv-input" value={f.notes} onChange={e => setF({ ...f, notes: e.target.value })} data-testid="b91-notes" /></label></div>}
    {del && <p className="sv-small sv-muted" style={{ marginTop: 8 }} data-testid="b91-del-confirm">Delete this block on {b.date}{n > 1 ? `, or the whole series (${n} slots, ${p0.from} to ${p0.to})` : ''}? Booked cases are not affected. Audited.</p>}
    {err && <p className="a81-err">{err}</p>}
  </Dlg>;
};
