/* ASC.Vityls v9.1 · Practice Intelligence: pure metrics + role gate (unit-tested). Fictional data only. */
export const canSeeIntel = (role: string) => /administrator|medical director/i.test(role || '');
export type Period = 'today' | 'week' | 'month' | 'quarter' | '12m' | 'custom';
const iso = (d: Date) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
export function range(p: Period, today: string, custom?: [string, string]): [string, string] {
  const t = new Date(today + 'T12:00'); const back = (n: number) => { const d = new Date(t); d.setDate(d.getDate() - n); return iso(d); };
  if (p === 'today') return [today, today];
  if (p === 'week') { const d = new Date(t); d.setDate(d.getDate() - ((d.getDay() + 6) % 7)); const e = new Date(d); e.setDate(e.getDate() + 6); return [iso(d), iso(e)]; }
  if (p === 'month') return [`${today.slice(0, 7)}-01`, iso(new Date(t.getFullYear(), t.getMonth() + 1, 0, 12))];
  if (p === 'quarter') { const q = Math.floor(t.getMonth() / 3) * 3; return [iso(new Date(t.getFullYear(), q, 1, 12)), iso(new Date(t.getFullYear(), q + 3, 0, 12))]; }
  if (p === '12m') return [back(364), today];
  return custom && custom[0] && custom[1] ? custom : [today, today];
}
export const workdays = (a: string, b: string) => { let n = 0; for (let d = new Date(a + 'T12:00'); iso(d) <= b; d.setDate(d.getDate() + 1)) if (d.getDay() % 6) n++; return Math.max(1, n); };
export interface MCase { date: string; time: string; durationMin: number; room: string; surgeon: string; done: boolean; orMin: number; lateMin: number | null; paid: number }
export interface MCancel { date: string; surgeon: string; reason: string }
export const REASONS = ['Incomplete clearance', 'No responsible ride', 'Clinical / medical', 'Insurance / auth', 'Patient request / other'];
export const reasonBucket = (r: string) => /clear|h&p|lab|ekg/i.test(r) ? REASONS[0] : /ride|escort|driver|responsible/i.test(r) ? REASONS[1] : /clinic|medical|ill|sick|fever|npo|ate/i.test(r) ? REASONS[2] : /insur|auth|pay/i.test(r) ? REASONS[3] : REASONS[4];
export function metrics(cases: MCase[], cancels: MCancel[], rooms: string[], days: number) {
  const done = cases.filter(c => c.done); const sched = cases.length + cancels.length; const mins = (c: MCase) => c.orMin || c.durationMin;
  const roomUse = rooms.map(r => { const m = cases.filter(c => c.room === r).reduce((n, c) => n + mins(c), 0); return { room: r, min: m, pct: Math.min(100, Math.round(100 * m / (600 * days))) }; });
  const util = roomUse.length ? Math.round(roomUse.reduce((n, r) => n + r.pct, 0) / roomUse.length) : 0;
  const surgeons = [...new Set([...cases.map(c => c.surgeon), ...cancels.map(c => c.surgeon)])].sort().map(s => { const cs = cases.filter(c => c.surgeon === s); const st = cs.filter(c => c.lateMin !== null); const dn = cs.filter(c => c.done);
    return { surgeon: s, cases: dn.length, booked: cs.length, onTime: st.length ? Math.round(100 * st.filter(c => (c.lateMin || 0) <= 5).length / st.length) : null, avg: dn.length ? Math.round(dn.reduce((n, c) => n + mins(c), 0) / dn.length) : null, cancel: cancels.filter(c => c.surgeon === s).length }; });
  const caseMin = cases.reduce((n, c) => n + mins(c), 0);
  const ROLES: [string, number, number][] = [['Pre-op nursing', 2, 0.55], ['Circulator / scrub', 2, 1], ['PACU', 2, 0.8], ['Anesthesia tech', 1, 0.9], ['Front office', 2, 0.35]];
  const staff = ROLES.map(([role, n, w]) => { const worked = n * 8 * days; const prod = Math.min(worked, (caseMin / 60) * w); const ot = Math.max(0, +((caseMin / 60) * w * 1.15 - worked).toFixed(1)); return { role, worked: Math.round(worked + ot), productive: worked ? Math.round(100 * prod / worked) : 0, ot }; });
  const reasons = REASONS.map(r => ({ reason: r, n: cancels.filter(c => reasonBucket(c.reason) === r).length }));
  return { completed: done.length, scheduled: sched, cancels: cancels.length, cancelPct: sched ? Math.round(100 * cancels.length / sched) : 0, util, roomUse, overtime: +staff.reduce((n, s) => n + s.ot, 0).toFixed(1), collections: cases.reduce((n, c) => n + c.paid, 0), surgeons, staff, reasons };
}
export type Metrics = ReturnType<typeof metrics>;
export function evaluate(m: Metrics) {
  const busiest = [...m.roomUse].sort((a, b) => b.min - a.min)[0]; const top = [...m.reasons].sort((a, b) => b.n - a.n)[0]; const otRole = [...m.staff].sort((a, b) => b.ot - a.ot)[0];
  return [
    { k: 'Volume', t: `${m.completed} case${m.completed === 1 ? '' : 's'} completed of ${m.scheduled} scheduled${busiest && busiest.min ? `, busiest room ${busiest.room}` : ''}.` },
    { k: 'Rooms', t: `OR utilization ${m.util}% (target 80%). ${m.roomUse.map(r => `${r.room} ${r.pct}%`).join(' · ')}.` },
    { k: 'Cancellations', t: m.cancels ? `${m.cancels} cancelled (${m.cancelPct}%). Most common: ${top.reason.toLowerCase()} (${top.n}).` : 'No cancellations in this period.' },
    { k: 'Staff', t: m.overtime ? `Estimated overtime ${m.overtime} h, mostly ${otRole.role}.` : 'No estimated overtime; staffed hours cover case minutes.' },
  ];
}
export function answer(q: string, m: Metrics) { const s = q.toLowerCase(); const ev = evaluate(m);
  if (/room|util|block/.test(s)) return ev[1].t; if (/cancel/.test(s)) return ev[2].t; if (/overtime|staff|labor|hour/.test(s)) return ev[3].t;
  if (/surgeon|doctor|on.time/.test(s)) return m.surgeons.length ? m.surgeons.map(x => `${x.surgeon}: ${x.cases} done, on-time ${x.onTime ?? '—'}%`).join('; ') + '.' : 'No surgeon activity in this period.';
  if (/money|collect|revenue|pay/.test(s)) return `Estimated collections $${m.collections.toLocaleString()} posted in this period (simulated payments).`;
  return ev[0].t + ' Ask about rooms, cancellations, staff or surgeons.'; }
