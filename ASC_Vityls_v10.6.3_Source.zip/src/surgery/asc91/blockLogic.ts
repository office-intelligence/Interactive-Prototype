/* ASC.Vityls v9.1 · block time pure logic (unit-tested). */
export interface Blk { id: string; surgeon: string; date: string; start: string; end: string; room: string; notes?: string; series?: string }
export const toMin = (t: string) => { const m = /^(\d{1,2}):(\d{2})\s*(AM|PM)?$/i.exec((t || '').trim()); if (!m) return NaN; let h = +m[1]; const ap = m[3]?.toUpperCase(); if (ap === 'PM' && h < 12) h += 12; if (ap === 'AM' && h === 12) h = 0; return h * 60 + +m[2]; };
export const fmt = (m: number) => { const h = Math.floor(m / 60), mm = m % 60; const ap = h >= 12 ? 'PM' : 'AM'; return `${String(h % 12 || 12).padStart(2, '0')}:${String(mm).padStart(2, '0')} ${ap}`; };
/** what is left of block [bs,be] after a case [cs,ce]: 0, 1 or 2 pieces (≥15 min each). */
export function remainder(bs: number, be: number, cs: number, ce: number): [number, number][] { const out: [number, number][] = []; if (cs > bs) out.push([bs, Math.min(cs, be)]); if (ce < be) out.push([Math.max(ce, bs), be]); return out.filter(([a, b]) => b - a >= 15); }
/** series key: same surgeon + room + times (blocks created together share these). */
export const seriesKey = (b: Blk) => b.series || `${b.surgeon}|${b.room}|${b.start}|${b.end}`;
