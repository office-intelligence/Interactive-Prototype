/* ASC.Vityls v9.1 · Practice Intelligence (the v7.7 "Facility performance" page, retitled; live data).
 * Administrator and Medical Director only. Nightingale evaluation is generated locally (drafts only, no external service). */
import { AiBox106 } from '../asc106/ai106';
import React, { useState } from 'react';
import { medRepo, isoDay } from '../../med/record';
import { useActor, useMedTick } from '../../med/ui';
import { svRead } from '../store';
import * as L from '../asc8/logic';
import * as S from '../asc8/store';
import { caseMoney } from '../asc83/pay';
import { staffList } from '../staff';
import * as I from './intelLogic';
const PERIODS: [I.Period, string][] = [['today', 'Today'], ['week', 'This week'], ['month', 'This month'], ['quarter', 'Quarter'], ['12m', 'Trailing 12 months'], ['custom', 'Custom range']];
const ROOMS = ['OR 1', 'OR 2', 'OR 3', 'Proc 1'];
const STEPS = [...new Set(L.ITEMS.map(i => i.step))]; const SIGNS = L.ITEMS.filter(i => i.sign);
const money = (n: number) => n >= 10000 ? `$${(n / 1000).toFixed(n >= 100000 ? 0 : 1)}k` : `$${n.toLocaleString()}`;
const Bar: React.FC<{ pct: number; c?: string }> = ({ pct, c = 'var(--i91-green)' }) => <span className="i91-bar"><i style={{ width: `${Math.max(0, Math.min(100, pct))}%`, background: c }} /></span>;
export const PracticeIntelligence: React.FC = () => {
  useMedTick(); const [actor] = useActor(); const T = isoDay();
  const [p, setP] = useState<I.Period>('week'); const [cr, setCr] = useState<[string, string]>([T, T]); const [q, setQ] = useState(''); const [ans, setAns] = useState(''); const [stamp, setStamp] = useState(() => new Date()); const [rep, setRep] = useState<string | null>(null);
  if (!I.canSeeIntel(actor.role)) return <div className="sv-page i91" data-testid="i91-noaccess"><div className="i91-card i91-no"><h1 className="i91-h1">Practice Intelligence</h1><p>Practice Intelligence is available to the Practice Administrator and the Medical Director. Ask an administrator if you need a report.</p></div></div>;
  const [a, b] = I.range(p, T, cr); const days = I.workdays(a, b);
  const all = S.cases(); const inR = all.filter(c => c.date >= a && c.date <= b);
  const canc = svRead<any[]>('asc83-cancelled', []).filter(c => c.date >= a && c.date <= b).map(c => ({ date: c.date, surgeon: c.surgeon, reason: c.cancelled?.reason || '' }));
  const mc: I.MCase[] = inR.map(c => ({ date: c.date, time: c.time, durationMin: c.durationMin, room: c.room === 'Procedure room' ? 'Proc 1' : c.room, surgeon: c.surgeon, done: ['discharged', 'closed'].includes(c.loc) || !!c.events.outRoom, orMin: L.orMinutes(c), lateMin: c.events.inRoom ? L.toMin(c.events.inRoom) - L.toMin(c.time) : null, paid: caseMoney(c).paid }));
  const m = I.metrics(mc, canc, ROOMS, days); const ev = I.evaluate(m); void stamp;
  const today = all.filter(c => c.date === T).sort((x, y) => L.toMin(x.time) - L.toMin(y.time));
  const roomTime = (c: L.AscCase) => L.orMinutes(c) ? `${L.orMinutes(c)} min` : '—';
  const avgRoom = today.filter(c => L.orMinutes(c)).length ? `${Math.round(today.reduce((n, c) => n + L.orMinutes(c), 0) / today.filter(c => L.orMinutes(c)).length)} min` : '—';
  const cleared = (c: L.AscCase) => L.LOC_ORDER.indexOf(c.loc) >= 1; const bal = (c: L.AscCase) => { const x = caseMoney(c); return x.due ? `$${x.balance.toLocaleString()}` : 'No invoice'; };
  const nm = (c: { pid: string }) => medRepo.patient(c.pid)?.name || '—';
  const REPORTS: [string, string, string, () => [string[], (string | number)[][]]][] = [
    ['Volume', 'Case register', 'Completed, scheduled, add-on, and cancelled cases by room and surgeon.', () => [['Date', 'Time', 'Patient', 'Room', 'Surgeon', 'Status'], [...inR.map(c => [c.date, c.time, nm(c), c.room, c.surgeon, L.LOC_LABEL[c.loc]]), ...canc.map(c => [c.date, '', '', '', c.surgeon, `Cancelled · ${c.reason}`])]]],
    ['Rooms', 'Block and utilization', 'Staffed minutes, first-case on time, turnover, and unused block.', () => { const bl = svRead<any[]>('block-seed', []).filter(x => x.date >= a && x.date <= b); return [['Room', 'Case minutes', 'Utilization', 'Open block minutes'], m.roomUse.map(r => [r.room, r.min, `${r.pct}%`, bl.filter(x => x.room === r.room).reduce((n, x) => n + L.toMin(x.end) - L.toMin(x.start), 0)])]; }],
    ['People', 'Labor productivity', 'Hours, overtime, and hours per case by role.', () => [['Role', 'Worked h', 'Productive', 'OT h', 'h / case'], m.staff.map(s => [s.role, s.worked, `${s.productive}%`, s.ot, m.completed ? (s.worked / m.completed).toFixed(1) : '—'])]],
    ['Quality', 'Surgeon scorecard', 'Volume, start time, duration variance, and cancellation rate.', () => [['Surgeon', 'Completed', 'On-time', 'Avg min', 'Cancel'], m.surgeons.map(s => [s.surgeon, s.cases, s.onTime === null ? '—' : `${s.onTime}%`, s.avg ?? '—', s.cancel])]],
    ['Access', 'Cancellation log', 'T-24 cancellations with reason and preventable flag.', () => [['Date', 'Surgeon', 'Reason', 'Preventable'], canc.map(c => [c.date, c.surgeon, c.reason || '—', /Incomplete|ride|Insurance/.test(I.reasonBucket(c.reason)) ? 'Yes' : 'No'])]],
    ['Revenue', 'Day sheet', 'Posted charges, estimated collections, and incomplete encounters.', () => [['Date', 'Patient', 'Due', 'Paid', 'Balance'], inR.map(c => { const x = caseMoney(c); return [c.date, nm(c), `$${x.due}`, `$${x.paid}`, `$${x.balance}`]; })]],
    ['Compliance', 'Credentialing due', 'Licenses, privileges, and Medical Director attestations nearing expiry.', () => [['Name', 'Role', 'Status'], staffList().filter(s => s.active).map(s => [s.name, s.role, /MD|DO|CRNA/.test(s.name) ? 'Privileges review due within 90 days (fictional)' : 'Current'])]],
    ['Supply', 'Implant and pack use', 'Preference-card variance and unused opened product.', () => [['Procedure', 'Cases', 'Packs opened', 'Unused (est.)'], [...new Set(inR.map(c => c.procedure))].map(pr => { const n = inR.filter(c => c.procedure === pr).length; return [pr, n, n, Math.round(n * 0.1)]; })]],
  ];
  const r0 = REPORTS.find(r => r[1] === rep); const rd = r0?.[3]();
  return <div className="sv-page i91" data-testid="i91-page">
    <div className="i91-kick">ASC operations</div><h1 className="i91-h1">Practice Intelligence</h1><p className="i91-sub">Volume, rooms, people, and money, evaluated by Nightingale for the selected period. Live from this device’s records (fictional).</p>
    <div className="i91-period" data-testid="i91-period"><span className="i91-kick">Period</span>{PERIODS.map(([k, l]) => <button key={k} type="button" className={p === k ? 'on' : ''} onClick={() => setP(k)} data-testid={`i91-p-${k}`}>{l}</button>)}
      {p === 'custom' && <><input type="date" className="sv-input" value={cr[0]} onChange={e => setCr([e.target.value, cr[1]])} aria-label="From" /><input type="date" className="sv-input" value={cr[1]} onChange={e => setCr([cr[0], e.target.value])} aria-label="To" /></>}<span className="i91-range">{a === b ? a : `${a} – ${b}`}</span></div>
    <section className="i91-ng" data-testid="i91-eval"><div className="hd"><span className="ng">Nightingale</span><span className="t">Operations evaluation · {PERIODS.find(x => x[0] === p)![1].toLowerCase()}</span><button type="button" className="i91-btn" onClick={() => { setStamp(new Date()); setAns(''); }} data-testid="i91-refresh">Refresh evaluation</button></div>
      <div className="bd"><AiBox106 value={q} onChange={setQ} onSubmit={() => { if (q.trim()) setAns(I.answer(q, m)); }} placeholder="Ask Nightingale: utilization by room, cancellation reasons, overtime by role…" inputId="i91-ask" goId="i91-ask-go" sample="Utilization by room" />
        {ans && <div className="ins ans" data-testid="i91-answer"><b>Nightingale (draft)</b>{ans}</div>}
        {ev.map(x => <div key={x.k} className="ins" data-testid="i91-insight"><b>{x.k}</b>{x.t}</div>)}</div></section>
    <div className="i91-kpis" data-testid="i91-kpis">{[['Cases completed', m.completed, `${days} working day${days === 1 ? '' : 's'}`], ['Scheduled', m.scheduled, 'Booked in the period'], ['Cancellations', m.cancels, `${m.cancelPct}% of scheduled`], ['OR utilization', `${m.util}%`, 'Target 80%'], ['Staff overtime', `${m.overtime}h`, 'Estimated from case minutes'], ['Estimated collections', money(m.collections), 'Posted (simulated)']].map(([k, v, s]) => <div key={k as string} className="i91-card kpi"><span>{k}</span><b>{v}</b><small>{s}</small></div>)}</div>
    <div className="i91-two">
      <section className="i91-card" data-testid="i91-surgeons"><div className="ch"><b>Surgeon performance</b><span>Completed cases</span></div><table className="i91-t"><thead><tr><th>Surgeon</th><th>Cases</th><th>On-time start</th><th>Avg minutes</th><th>Cancel</th></tr></thead><tbody>{m.surgeons.map(s => <tr key={s.surgeon}><td>{s.surgeon.replace(/,.*$/, '')}</td><td>{s.cases}</td><td>{s.onTime === null ? '—' : `${s.onTime}%`}</td><td>{s.avg ?? '—'}</td><td>{s.cancel}</td></tr>)}{!m.surgeons.length && <tr><td colSpan={5} className="mut">No cases in this period.</td></tr>}</tbody></table></section>
      <section className="i91-card" data-testid="i91-util"><div className="ch"><b>OR utilization</b><span>Staffed minutes</span></div><table className="i91-t"><thead><tr><th>Room</th><th>Use</th><th /></tr></thead><tbody>{m.roomUse.map((r, i) => <tr key={r.room}><td>{r.room}</td><td>{r.pct}%</td><td style={{ width: '55%' }}><Bar pct={r.pct} c={['var(--i91-green)', '#8a5a2b', '#2f6f73', '#6b5b95'][i % 4]} /></td></tr>)}</tbody></table></section>
      <section className="i91-card" data-testid="i91-staff"><div className="ch"><b>Staff efficiency</b><span>Hours vs case minutes</span></div><table className="i91-t"><thead><tr><th>Role</th><th>Worked</th><th>Productive</th><th>OT</th></tr></thead><tbody>{m.staff.map(s => <tr key={s.role}><td>{s.role}</td><td>{s.worked}h</td><td>{s.productive}%</td><td>{s.ot}h</td></tr>)}</tbody></table></section>
      <section className="i91-card" data-testid="i91-reasons"><div className="ch"><b>Cancellation reasons</b><span>After T-24</span></div><table className="i91-t"><thead><tr><th>Reason</th><th>N</th><th /></tr></thead><tbody>{m.reasons.map(r => <tr key={r.reason}><td>{r.reason}</td><td>{r.n}</td><td style={{ width: '45%' }}><Bar pct={m.cancels ? 100 * r.n / m.cancels : 0} c="#8a5a2b" /></td></tr>)}</tbody></table></section>
    </div>
    <div className="i91-kick mt">Reports</div>
    <div className="i91-reps" data-testid="i91-reports">{REPORTS.map(([k, t, s]) => <button key={t} type="button" className={`i91-card rep${rep === t ? ' on' : ''}`} onClick={() => setRep(rep === t ? null : t)} data-testid="i91-report"><span>{k}</span><b>{t}</b><small>{s}</small></button>)}</div>
    {r0 && rd && <section className="i91-card" data-testid="i91-report-view"><div className="ch"><b>{r0[1]}</b><span>{a === b ? a : `${a} – ${b}`} · {rd[1].length} row{rd[1].length === 1 ? '' : 's'}</span><button type="button" className="i91-x" aria-label="Close report" onClick={() => setRep(null)}>✕</button></div><div className="i91-scroll"><table className="i91-t"><thead><tr>{rd[0].map(h => <th key={h}>{h}</th>)}</tr></thead><tbody>{rd[1].map((row, i) => <tr key={i}>{row.map((v, j) => <td key={j}>{v}</td>)}</tr>)}{!rd[1].length && <tr><td colSpan={rd[0].length} className="mut">No rows for this period.</td></tr>}</tbody></table></div><p className="mut sm">Print manually from the browser if you need a copy.</p></section>}
    <div className="i91-kick mt">Live from this device</div><h2 className="i91-h2">Today’s case flow</h2><p className="i91-sub">Real cases and workstation data on this device, alongside the evaluation above.</p>
    <div className="i91-kpis four">{[['Cases', today.length], ['Cleared for surgery', today.filter(cleared).length], ['Average room time', avgRoom], ['Open balance', `$${today.reduce((n, c) => n + caseMoney(c).balance, 0).toLocaleString()}`]].map(([k, v]) => <div key={k as string} className="i91-card kpi"><span>{k}</span><b>{v}</b></div>)}</div>
    <section className="i91-card" data-testid="i91-flow"><div className="ch"><b>Case flow</b><span>Stations verified, documents locked, room time against booked time, clearance and balance</span></div><div className="i91-scroll"><table className="i91-t"><thead><tr><th>Patient</th><th>Time</th><th>Room</th><th>Stations verified</th><th>Documents locked</th><th>Room time</th><th>Clearance</th><th>Balance</th></tr></thead><tbody>{today.map(c => <tr key={c.id} data-testid="i91-flow-row"><td>{nm(c)}</td><td>{c.time.replace(/^0/, '')}</td><td>{c.room}</td><td>{STEPS.filter(s => L.stepComplete(c, s)).length} / {STEPS.length}</td><td>{SIGNS.filter(i => L.isDone(c, i.key)).length} / {SIGNS.length}</td><td>{roomTime(c)} <span className="mut">/ {c.durationMin}</span></td><td><span className={`i91-tag${cleared(c) ? ' ok' : ''}`}>{cleared(c) ? 'Cleared' : 'Not reviewed'}</span></td><td>{bal(c)}</td></tr>)}{!today.length && <tr><td colSpan={8} className="mut">No cases today.</td></tr>}</tbody></table></div></section>
  </div>;
};
