/* ASC.Vityls v9.1 · block time: pure trim/split + store ops (edit, delete one/series, consume by a booked case). Audited. */
import { svRead, svWrite } from '../store';
import { repo } from '../../v6/dataLayer';
import { remainder, seriesKey, toMin, fmt, type Blk } from './blockLogic';
export * from './blockLogic';
const K = 'block-seed'; export const blocksAll = () => svRead<Blk[]>(K, []); const put = (l: Blk[]) => svWrite(K, l);
const audit = (by: string, role: string, detail: string) => repo.audit({ caseId: 'practice', user: by, role, action: 'asc91.block' as any, detail });
/** the whole block (all dates of its series) is one unit */
export const seriesOf = (id: string) => { const l = blocksAll(); const b = l.find(x => x.id === id); return b ? l.filter(x => seriesKey(x) === seriesKey(b)).sort((x, y) => x.date.localeCompare(y.date)) : []; };
export interface BlockPlan { from: string; to: string; days: number[]; start: string; end: string; room: string; surgeon: string; notes?: string }
export function planOf(id: string): BlockPlan | null { const m = seriesOf(id); if (!m.length) return null; const b = m.find(x => x.id === id)!; const full = m.reduce((w, x) => toMin(x.end) - toMin(x.start) > toMin(w.end) - toMin(w.start) ? x : w, m[0]);
  return { from: m[0].date, to: m[m.length - 1].date, days: [...new Set(m.map(x => new Date(x.date + 'T12:00').getDay()))].sort(), start: full.start, end: full.end, room: b.room, surgeon: b.surgeon, notes: b.notes || '' }; }
const iso = (d: Date) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
export function editBlock(id: string, p: BlockPlan, by: string, role: string): number { const old = seriesOf(id); if (!old.length) return 0;
  if (toMin(p.end) <= toMin(p.start)) throw new Error('End must be after start.'); if (!p.from || !p.to || p.to < p.from) throw new Error('Pick a valid date range.'); if (!p.days.length) throw new Error('Pick at least one day of the week.');
  const key = `ser-${old[0].id}`; const out: Blk[] = []; let k = 0;
  for (let d = new Date(p.from + 'T12:00'); iso(d) <= p.to; d.setDate(d.getDate() + 1)) { if (!p.days.includes(d.getDay())) continue; const date = iso(d);
    const pieces: [number, number][] = [[toMin(p.start), toMin(p.end)]];
    pieces.forEach(([x, y]) => out.push({ id: `${key}-${k++}`, surgeon: p.surgeon, date, start: fmt(x), end: fmt(y), room: p.room, notes: p.notes, series: key })); }
  const ids = new Set(old.map(x => x.id)); put([...blocksAll().filter(x => !ids.has(x.id)), ...out]);
  audit(by, role, `Block edited (whole series): ${old[0].surgeon} ${old[0].room} → ${p.surgeon} ${p.room} ${p.start}–${p.end}, ${p.from} to ${p.to}, ${out.length} slot(s)${p.notes ? ` · ${p.notes}` : ''}`); return out.length; }
/** edit one block only: it is detached from its series (own series key). */
export function editOne(id: string, p: { date: string; start: string; end: string; room: string; surgeon: string; notes?: string }, by: string, role: string) { const l = blocksAll(); const b = l.find(x => x.id === id); if (!b) return;
  if (toMin(p.end) <= toMin(p.start)) throw new Error('End must be after start.'); if (!p.date) throw new Error('Pick a date.');
  const n: Blk = { ...b, ...p, series: `solo-${b.id}` }; put(l.map(x => x.id === id ? n : x));
  audit(by, role, `Block edited (this block only, detached from series): ${b.date} ${b.surgeon} ${b.room} ${b.start}–${b.end} → ${n.date} ${n.surgeon} ${n.room} ${n.start}–${n.end}${n.notes ? ` · ${n.notes}` : ''}`); }
export function deleteBlock(id: string, scope: 'one' | 'series', by: string, role: string): number { const all = seriesOf(id); const gone = scope === 'one' ? all.filter(x => x.id === id) : all; if (!gone.length) return 0; const ids = new Set(gone.map(x => x.id)); put(blocksAll().filter(x => !ids.has(x.id)));
  audit(by, role, `Block deleted (${scope === 'one' ? 'this block only' : `whole series, ${gone.length} slot(s) ${gone[0].date} to ${gone[gone.length - 1].date}`}): ${gone[0].surgeon} ${gone[0].room} ${gone[0].start}–${gone[0].end}`); return gone.length; }
export function consumeBlock(id: string, date: string, time: string, len: number, by: string, role: string, who: string) { const l = blocksAll(); const b = l.find(x => x.id === id); if (!b || b.date !== date) return;
  const rest = remainder(toMin(b.start), toMin(b.end), toMin(time), toMin(time) + len); const pieces: Blk[] = rest.map(([a, z], i) => ({ ...b, id: i ? `${b.id}-b` : `${b.id}-a`, start: fmt(a), end: fmt(z), series: seriesKey(b) }));
  put([...l.filter(x => x.id !== id), ...pieces]); audit(by, role, `Block ${b.start}–${b.end} ${b.room} ${rest.length ? `trimmed to ${pieces.map(p => `${p.start}–${p.end}`).join(', ')}` : 'removed'}: replaced by case ${who} ${time} (${len} min)`); }
