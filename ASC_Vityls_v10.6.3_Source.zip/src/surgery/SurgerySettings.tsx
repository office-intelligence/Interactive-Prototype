import { isAscEd } from '../edition';
/* Surgery.Vityls practice settings: visit types & colors (scheduler/dashboard) and surgical modules (edition presets). Desktop page; managers edit, everyone can read. */
import { isMedical } from '../edition';
import { ResourceManager } from './SurgerySchedule';
import { QuoteSettingsPage } from './quotes';
import React, { useState } from 'react';
import { useActor, useMedTick } from '../med/ui';
import { CATEGORY_LABEL, DEFAULT_VISIT_TYPES, edgeOf, MEDICAL_PRESET, MODULE_LABEL, SURGERY_MODULES, SurgicalModules, surgerySettings, saveSurgerySettings, VisitCategory, VisitTypeDef } from './store';
import { uid, medRepo } from '../med/record';
import { useSv } from './ui';
import { practiceActor, practiceUnlocked } from './practiceLock';
import { ascFacilities, saveFacilities, AscFacility } from './asc';
import { repo } from '../v6/dataLayer';
import { IntakeListsSettings } from './profile';
import { ReminderSettingsSection } from './reminders';
import { EpisodeSettingsSection } from './episodes/EpisodeSettings';
import { ClearanceDefaults } from './v15/clrDefaults';

const PALETTE = ['#DBEAFE', '#DCFCE7', '#FEF3C7', '#D1FAE5', '#EDE9FE', '#FCE7F3', '#FFEDD5', '#E0F2FE', '#F1F5F9', '#FEE2E2'];
const EDITORS = ['Practice Manager', 'Practice Administrator'];

export const SurgerySettings: React.FC = () => {
  useMedTick(); const [session] = useActor(); const actor = practiceActor(session); const { toast, setTab } = useSv(); const can = practiceUnlocked() || EDITORS.includes(session.role);
  const cur = surgerySettings(); const [vt, setVt] = useState<VisitTypeDef[]>(cur.visitTypes); const [pick, setPick] = useState(-1); const [mods, setMods] = useState<SurgicalModules>(cur.modules);
  const dirtyVt = JSON.stringify(vt) !== JSON.stringify(cur.visitTypes); const dirtyMods = JSON.stringify(mods) !== JSON.stringify(cur.modules);
  const up = (i: number, p: Partial<VisitTypeDef>) => setVt(vt.map((x, j) => j === i ? { ...x, ...p } : x));
  const saveVt = () => { if (vt.some(x => !x.name.trim())) { toast('Every visit type needs a name.'); return; } const names = vt.map(x => x.name.trim().toLowerCase()); if (new Set(names).size !== names.length) { toast('Visit type names must be unique.'); return; }
    const renamed = vt.map(x => ({ from: cur.visitTypes.find(o => o.id === x.id)?.name, to: x.name.trim() })).filter(r => r.from && r.from !== r.to);
    renamed.forEach(r => medRepo.visits().filter(v => v.visitType === r.from).forEach(v => medRepo.saveVisit({ ...v, visitType: r.to })));
    saveSurgerySettings({ ...surgerySettings(), visitTypes: vt.map(x => ({ ...x, name: x.name.trim() })) }, actor.name, actor.role, `Visit types & colors saved${renamed.length ? ` (renamed: ${renamed.map(r => `${r.from} → ${r.to}`).join(', ')}; booked visits follow)` : ''}: ${vt.filter(x => x.active).map(x => `${x.name} ${x.color}`).join(', ')}`, 'visittype.settings'); toast('Visit types & colors saved. The schedule and Today use them now.'); };
  const saveMods = () => { saveSurgerySettings({ ...surgerySettings(), modules: mods }, actor.name, actor.role, `Modules: ${(Object.keys(mods) as (keyof SurgicalModules)[]).map(k => `${MODULE_LABEL[k].label} ${mods[k] ? 'on' : 'off'}`).join('; ')}`, 'module.settings'); toast('Modules saved.'); };
  return <div className="sv-page" style={{ maxWidth: 1100 }} data-testid="sv-settings">
    <div className="flex flex-wrap items-end justify-between gap-2 mb-3"><div><h1 className="sv-title" data-ps-legacy="">Visit types, colors, intake lists &amp; reminders</h1><div className="sv-sub" data-ps-legacy={can ? '' : undefined}>Practice settings · Surgery.Vityls{can ? '' : ` · read-only for ${actor.role} (a practice manager or administrator edits)`}</div></div><button type="button" className="sv-link text-[13px]" data-ps-legacy="" onClick={() => setTab('practice')}>← Practice</button></div>
    {isAscEd && <><section className="sv-sec mb-6" id="schedule-columns"><h2 className="sv-title" style={{ fontSize: 20 }}>Schedule columns</h2><p className="sv-small sv-muted mb-2" data-testid="v103-rooms-note">Rooms added here are the facility's rooms everywhere: the schedule, booking, and Practice › Hours &amp; rooms.</p><ResourceManager /></section></>}
    <section className="mb-6 sv-sec">
      <h2 className="sv-h">Visit types &amp; colors</h2>
      <p className="text-[13px] sv-muted mb-2">Colors appear on the schedule and the Today cards. Keep them light so text stays readable; color is the only decoration on these pages.</p>
      <div className="overflow-x-auto"><table className="sv-table" data-testid="vt-table"><thead><tr><th>Color</th><th>Name</th><th>Minutes</th><th>Category</th><th>Surgical</th><th>Active</th></tr></thead><tbody>{vt.map((t, i) => <tr key={t.id}>
        <td><div className="flex items-center gap-1.5"><button type="button" disabled={!can} onClick={() => setPick(pick === i ? -1 : i)} aria-label={`Change color for ${t.name}`} aria-expanded={pick === i} className="inline-block w-8 h-6 rounded" style={{ background: t.color, border: `1px solid ${edgeOf(t.color)}`, minHeight: 0, padding: 0 }} data-testid={`vt-swatch-${i}`} />{can && pick === i && <><input type="color" value={t.color.length === 7 ? t.color : '#ffffff'} onChange={e => up(i, { color: e.target.value.toUpperCase() })} aria-label={`Color for ${t.name}`} style={{ width: 28, height: 24, padding: 0, border: 0, background: 'none' }} data-testid={`vt-color-${i}`} /><span className="flex flex-wrap gap-1" style={{ maxWidth: 150 }}>{PALETTE.map(c => <button key={c} type="button" onClick={() => { up(i, { color: c }); setPick(-1); }} aria-label={`Use ${c}`} style={{ width: 18, height: 18, minHeight: 0, minWidth: 0, background: c, border: `1px solid ${edgeOf(c)}`, borderRadius: 2, padding: 0 }} />)}</span></>}</div></td>
        <td><input className="sv-input" value={t.name} disabled={!can} onChange={e => up(i, { name: e.target.value })} data-testid={`vt-name-${i}`} /></td>
        <td style={{ width: 80 }}><input className="sv-input" inputMode="numeric" value={t.durationMin} disabled={!can} onChange={e => up(i, { durationMin: +e.target.value.replace(/\D/g, '') || 0 })} /></td>
        <td><select className="sv-input" value={t.category} disabled={!can} onChange={e => up(i, { category: e.target.value as VisitCategory })}>{(Object.keys(CATEGORY_LABEL) as VisitCategory[]).map(c => <option key={c} value={c}>{CATEGORY_LABEL[c]}</option>)}</select></td>
        <td className="text-center"><input type="checkbox" checked={t.surgical} disabled={!can} onChange={e => up(i, { surgical: e.target.checked })} aria-label="Surgical" /></td>
        <td className="text-center"><input type="checkbox" checked={t.active} disabled={!can} onChange={e => up(i, { active: e.target.checked })} aria-label="Active" /></td></tr>)}</tbody></table></div>
      {can && <div className="flex flex-wrap gap-2 mt-2"><button type="button" className="sv-btn sm" onClick={() => setVt([...vt, { id: uid('vt'), name: 'New visit type', color: '#F1F5F9', durationMin: 30, category: 'other', surgical: false, active: true }])} data-testid="vt-add">Add visit type</button><button type="button" className="sv-btn sm" onClick={() => setVt(DEFAULT_VISIT_TYPES)}>Restore defaults</button><button type="button" className="sv-btn sm primary" disabled={!dirtyVt} onClick={saveVt} data-testid="vt-save">Save visit types</button></div>}
      <p className="text-[12px] sv-muted mt-1">Renaming a type renames it on booked visits too. Inactive types stay on past visits but are not offered for new bookings.</p>
    </section>
    {!isMedical && !isAscEd && <section>
      <h2 className="sv-h">Modules</h2>
      <p className="text-[13px] sv-muted mb-2">Surgical features are modules. The Medical.Vityls preset switches the surgical ones off; nothing is deleted.</p>
      <table className="sv-table" data-testid="mod-table"><tbody>{(Object.keys(MODULE_LABEL) as (keyof SurgicalModules)[]).map(k => <tr key={k}><td style={{ width: 36 }}><input type="checkbox" checked={mods[k]} disabled={!can} onChange={e => setMods({ ...mods, [k]: e.target.checked })} aria-label={MODULE_LABEL[k].label} data-testid={`mod-${k}`} /></td><td><b>{MODULE_LABEL[k].label}</b>{MODULE_LABEL[k].surgical && <span className="sv-tag ml-2">surgical</span>}<div className="sv-muted text-[12.5px]">{MODULE_LABEL[k].explain}</div></td></tr>)}</tbody></table>
      {can && <div className="flex flex-wrap gap-2 mt-2"><button type="button" className="sv-btn sm" onClick={() => setMods(SURGERY_MODULES)} data-testid="preset-surgery">Surgery preset (all on)</button><button type="button" className="sv-btn sm" onClick={() => setMods(MEDICAL_PRESET)} data-testid="preset-medical">Medical preset (surgical off)</button><button type="button" className="sv-btn sm primary" disabled={!dirtyMods} onClick={saveMods} data-testid="mod-save">Save modules</button></div>}
    </section>}
    {!isMedical && !isAscEd && <Facilities can={can} />}
    <IntakeListsSettings can={can} actor={actor} />
    <ReminderSettingsSection can={can} actor={actor} />
    {!isMedical && <ClearanceDefaults can={can} actor={actor} />}
    {!isMedical && !isAscEd && <EpisodeSettingsSection can={can} actor={actor} />}
    {!isAscEd && <><section className="sv-sec mt-8" id="schedule-columns"><h2 className="sv-title" style={{ fontSize: 20 }}>Schedule columns</h2><ResourceManager /></section></>}
    {!isAscEd && <section className="sv-sec mt-8" id="quote-settings"><QuoteSettingsPage /></section>}
  </div>;
};

/* Surgery centers this office sends requests to (a surgeon may operate at several). Not ASC configuration. */
const Facilities: React.FC<{ can: boolean }> = ({ can }) => {
  useMedTick(); const [session] = useActor(); const actor = practiceActor(session); const { toast } = useSv(); const list = ascFacilities(); const [nm, setNm] = useState(''); const [city, setCity] = useState('');
  const save = (l: AscFacility[], what: string) => { saveFacilities(l); repo.audit({ caseId: 'practice', user: actor.name, role: actor.role, action: 'visittype.settings', detail: what }); toast(what); };
  return <section className="mt-6" data-testid="facilities">
    <h2 className="sv-h">Surgery centers you send to</h2>
    <p className="text-[13px] sv-muted mb-2">Shown in Checkout › Send request to ASC. Block time appears for the primary center (from its schedule). Fictional names.</p>
    <table className="sv-table"><tbody>{list.map(f => <tr key={f.id}><td><b>{f.name}</b>{f.primary && <span className="sv-tag ml-2">primary · block time</span>}</td><td>{f.city}</td><td>{f.active ? 'Active' : <span className="sv-muted">Hidden</span>}</td><td className="text-right">{can && <button type="button" className="sv-link text-[12.5px]" onClick={() => save(list.map(x => x.id === f.id ? { ...x, active: !x.active } : x), `${f.name} ${f.active ? 'hidden' : 'shown'} in Send to ASC`)}>{f.active ? 'Hide' : 'Show'}</button>}</td></tr>)}</tbody></table>
    {can && <div className="flex flex-wrap items-end gap-2 mt-2"><label className="flex-1 min-w-[220px]"><span className="sv-label">Add a surgery center</span><input className="sv-input" value={nm} onChange={e => setNm(e.target.value)} placeholder="Name" /></label><label><span className="sv-label">City</span><input className="sv-input" value={city} onChange={e => setCity(e.target.value)} /></label><button type="button" className="sv-btn" onClick={() => { if (!nm.trim()) return; save([...list, { id: uid('asc'), name: nm.trim(), city: city.trim(), active: true }], `Surgery center added: ${nm.trim()}`); setNm(''); setCity(''); }}>Add</button></div>}
  </section>;
};
