/*
 * Surgery.Vityls v0.6 · Patient contact notes ("Add or dictate a note").
 * Anyone on the care team (front desk, MA, nurse, coordinator, doctor) documents a patient contact that is not tied
 * to an appointment: a phone call, a portal message, a walk-in, an email. Typed or dictated (ambient voice is
 * SIMULATED: a scripted transcript is typed for you; nothing is recorded).
 * Saving a contact note needs no PIN: it is a staff record, filed under the author and the tablet session. A provider
 * can optionally sign it as a clinical note with their own PIN, and any note can be flagged for provider review;
 * a provider clears the flag with their PIN. Notes show on the timeline and in Records › Contact notes.
 * Henry: `contact_notes(id, patient_id, channel, direction, reason, text, author, author_role, session_user,
 * contact_at, dictated, flagged, reviewed_by/at, signed_by/at/hash)`.
 */
import React, { useEffect, useRef, useState } from 'react';
import { Mic, Square, X, Phone, Flag } from 'lucide-react';
import { repo } from '../v6/dataLayer';
import { MedPatient, patientKey, uid, fmtDateTime, PROVIDER_ROLES } from '../med/record';
import { useActor, useMedTick } from '../med/ui';
import { svRead, svWrite } from './store';
import { PinSign } from './sign';
import { people } from './staff';
import { useSv } from './ui';
import { R, chartAnswerHooks } from './nightingale';

export const CHANNELS = ['Phone call', 'Portal message', 'In person (walk-in)', 'Email', 'Text message', 'Other'] as const;
export const CONTACT_REASONS = ['Post-op concern', 'Medication / refill', 'Question about surgery', 'Scheduling', 'Billing / payment', 'Results', 'Records request', 'Other'];
export interface ContactNote { id: string; patientId: string; channel: string; direction: 'Incoming' | 'Outgoing'; reason: string; text: string; author: string; authorRole: string; session: string; contactAt: string; at: string; dictated: boolean; flagged: boolean; reviewed?: { by: string; at: string }; signed?: { by: string; role: string; at: string; hash: string } }
const all = () => svRead<ContactNote[]>('contact-notes', []);
export const contactNotes = (pid: string) => all().filter(n => n.patientId === pid).sort((a, b) => b.contactAt.localeCompare(a.contactAt));
export const flaggedNotes = (pid: string) => contactNotes(pid).filter(n => n.flagged && !n.reviewed);
const h = (s: string) => { let x = 5381; for (const c of s) x = ((x << 5) + x + c.charCodeAt(0)) >>> 0; return x.toString(16); };
export function saveContactNote(n: ContactNote) {
  svWrite('contact-notes', [...all().filter(x => x.id !== n.id), n]);
  repo.audit({ caseId: patientKey(n.patientId), user: n.author, role: n.authorRole, action: n.signed ? 'contact.note.sign' : 'contact.note', detail: `Contact note · ${n.direction.toLowerCase()} ${n.channel.toLowerCase()} · ${n.reason}${n.dictated ? ' · dictated (simulated voice)' : ''}${n.flagged ? ' · flagged for provider review' : ''}${n.signed ? ` · signed by ${n.signed.by} with PIN (fingerprint ${n.signed.hash})` : ' · saved without a signature (staff record)'} · tablet session ${n.session}: “${n.text.slice(0, 90)}${n.text.length > 90 ? '…' : ''}”` });
}
export function reviewContactNote(id: string, by: string, role: string) {
  const n = all().find(x => x.id === id); if (!n) return; svWrite('contact-notes', all().map(x => x.id === id ? { ...x, reviewed: { by, at: new Date().toISOString() } } : x));
  repo.audit({ caseId: patientKey(n.patientId), user: by, role, action: 'contact.note.review', detail: `Flagged contact note reviewed (${n.reason}, ${fmtDateTime(n.contactAt)}) with ${by}’s PIN` });
}

const SCRIPTS: Record<string, string[]> = {
  'Post-op concern': ['Patient called about mild swelling and some bruising around the left eye, three days after surgery.', 'No fever. Vision unchanged. Pain controlled with acetaminophen.', 'Reviewed the after-care sheet with her: cold compresses, head elevated, no bending or lifting.', 'Sending to Dr. Patel for review. Patient will call back right away if swelling increases, vision changes or bleeding starts.'],
  'Medication / refill': ['Patient called asking for a refill of her post-op eye ointment.', 'Says she has two days left. No new symptoms.', 'Told her the request goes to the surgeon for approval and we will call her back today.'],
  'Question about surgery': ['Patient called with questions about the day of surgery.', 'Asked whether she should take her morning medicines and how long she needs a driver.', 'Told her the surgeon or nurse will review her medication instructions with her before surgery. She needs an adult escort home.', 'Coordinator to call her back with the arrival time.'],
  Scheduling: ['Patient called to move her post-op visit to later in the week.', 'Offered Thursday at 10:30 or Friday at 2:00. She will confirm by text.'],
  'Billing / payment': ['Patient called about the balance on her statement.', 'Explained the charges for the office procedure and the deposit already applied.', 'She will pay the remaining balance by card at her next visit.'],
  Results: ['Patient called asking about her lab results from last week.', 'Told her the results are with the surgeon for review and will be released to the portal once reviewed.'],
  'Records request': ['Patient asked for a copy of her operative report and photos for her own records.', 'Records release form sent to the portal for signature.'],
  Other: ['Patient called the office.', 'Message taken and passed to the care team.'],
};

export const ContactNoteDialog: React.FC<{ p: MedPatient; onClose: () => void; onSaved: (n: ContactNote) => void }> = ({ p, onClose, onSaved }) => {
  const [actor] = useActor(); const team = people();
  const [f, setF] = useState({ channel: 'Phone call', direction: 'Incoming' as 'Incoming' | 'Outgoing', reason: '', author: team.some(x => x.name === actor.name) ? actor.name : (team[0]?.name || actor.name), text: '', flagged: false, sign: false, when: '' });
  const [listen, setListen] = useState(false); const [dictated, setDictated] = useState(false); const [err, setErr] = useState(''); const [pin, setPin] = useState(false); const idx = useRef(0);
  useEffect(() => { if (!listen) return; const s = SCRIPTS[f.reason] || SCRIPTS.Other; const t = setInterval(() => { if (idx.current >= s.length) { setListen(false); return; } const line = s[idx.current++]; setF(x => ({ ...x, text: (x.text ? x.text.replace(/\s*$/, ' ') : '') + line })); }, 650); return () => clearInterval(t); }, [listen, f.reason]);
  const authorRole = team.find(x => x.name === f.author)?.role || actor.role;
  const build = (signed?: ContactNote['signed']): ContactNote => ({ id: uid('cn'), patientId: p.id, channel: f.channel, direction: f.direction, reason: f.reason, text: f.text.trim(), author: f.author, authorRole, session: actor.name, contactAt: f.when ? new Date(f.when).toISOString() : new Date().toISOString(), at: new Date().toISOString(), dictated, flagged: f.flagged, signed });
  const save = () => { if (!f.reason) { setErr('Choose what the contact was about.'); return; } if (f.text.trim().length < 5) { setErr('Write or dictate the note.'); return; } setErr(''); if (f.sign) { setPin(true); return; } const n = build(); saveContactNote(n); onSaved(n); };
  return <div className="sv-modal" role="dialog" aria-modal="true" aria-label="Add or dictate a note" data-testid="contact-note-dialog"><div className="sv-modal-scrim" onClick={onClose} />
    <div className="sv-modal-box" style={{ width: 'min(600px, calc(100vw - 24px))', maxHeight: 'calc(100vh - 40px)', overflowY: 'auto' }}>
      <div className="flex items-center gap-2 mb-1"><Phone size={16} /><b className="text-[15px]">Add or dictate a note · {p.name}</b><button type="button" className="ml-auto" onClick={onClose} aria-label="Close"><X size={16} /></button></div>
      <p className="sv-small sv-muted mb-2">Document a patient contact outside an appointment. Anyone on the care team can write it; no PIN needed to save.</p>
      <span className="sv-label">How the patient reached us</span>
      <div className="sv-chips mb-2" role="radiogroup" aria-label="Channel">{CHANNELS.map(c => <button key={c} type="button" role="radio" aria-checked={f.channel === c} aria-selected={f.channel === c} onClick={() => setF({ ...f, channel: c })} data-testid="cn-channel">{c}</button>)}</div>
      <div className="grid sm:grid-cols-3 gap-2">
        <label><span className="sv-label">Direction</span><select className="sv-input" value={f.direction} onChange={e => setF({ ...f, direction: e.target.value as any })} data-testid="cn-direction"><option>Incoming</option><option>Outgoing</option></select></label>
        <label><span className="sv-label">About</span><select className="sv-input" value={f.reason} onChange={e => setF({ ...f, reason: e.target.value })} data-testid="cn-reason"><option value="">Choose…</option>{CONTACT_REASONS.map(r => <option key={r}>{r}</option>)}</select></label>
        <label><span className="sv-label">Written by</span><select className="sv-input" value={f.author} onChange={e => setF({ ...f, author: e.target.value })} data-testid="cn-author">{team.map(x => <option key={x.name} value={x.name}>{x.name} · {x.role}</option>)}</select></label>
      </div>
      <div className="flex items-center gap-2 mt-2 flex-wrap"><span className="sv-label m-0">Note</span>
        {listen ? <button type="button" className="sv-btn sm" onClick={() => setListen(false)} data-testid="cn-stop"><Square size={13} />Stop</button>
          : <button type="button" className="sv-btn sm inline-flex items-center gap-1" onClick={() => { if (!f.reason) { setErr('Choose what the contact was about, then dictate.'); return; } setErr(''); idx.current = 0; setDictated(true); setListen(true); }} data-testid="cn-dictate"><Mic size={14} />Dictate</button>}
        {listen && <span className="sv-rec" data-testid="cn-listening"><span className="r" />Listening… (simulated)</span>}
        <label className="ml-auto sv-small inline-flex items-center gap-1.5"><span className="sv-muted">Contact time</span><input type="datetime-local" className="sv-input" style={{ width: 'auto', minHeight: 30 }} value={f.when} onChange={e => setF({ ...f, when: e.target.value })} aria-label="Contact time (defaults to now)" /></label></div>
      <textarea className="sv-input mt-1" rows={6} value={f.text} onChange={e => setF({ ...f, text: e.target.value })} placeholder="What the patient said, what you told them, and what happens next." data-testid="cn-text" />
      <div className="flex flex-col gap-1 mt-2 text-[13px]">
        <label className="inline-flex items-center gap-2"><input type="checkbox" checked={f.flagged} onChange={e => setF({ ...f, flagged: e.target.checked })} data-testid="cn-flag" /><Flag size={13} />Flag for provider review (shows under “Worth your attention” until a provider clears it)</label>
        <label className="inline-flex items-center gap-2"><input type="checkbox" checked={f.sign} onChange={e => setF({ ...f, sign: e.target.checked })} data-testid="cn-sign" />Sign as a clinical note (provider PIN)</label>
      </div>
      {dictated && <p className="sv-small sv-muted mt-1">Simulated dictation: a sample transcript for “{f.reason || 'Other'}” was typed. Edit it before saving. Real speech needs a BAA-covered service.</p>}
      {err && <p className="text-[12.5px] text-[var(--crit)] mt-2" role="alert">{err}</p>}
      <div className="flex justify-end gap-2 mt-3"><button type="button" className="sv-btn" onClick={onClose}>Cancel</button><button type="button" className="sv-btn primary" onClick={save} data-testid="cn-save">{f.sign ? 'Save & sign…' : 'Save note'}</button></div>
    </div>
    {pin && <PinSign title="Sign contact note" statement={<>I reviewed this contact note for {p.name} and sign it as a clinical note.</>} roles={PROVIDER_ROLES} confirmLabel="Sign" onClose={() => setPin(false)} onSigned={w => { const n = build({ by: w.name, role: w.role, at: w.at, hash: h(f.text.trim()) }); saveContactNote(n); setPin(false); onSaved(n); }} />}
  </div>;
};

export const ContactNotesPanel: React.FC<{ p: MedPatient; id?: string }> = ({ p, id }) => {
  useMedTick(); const { toast } = useSv(); const [add, setAdd] = useState(false); const [rev, setRev] = useState(''); const list = contactNotes(p.id);
  return <div data-testid="contact-notes-panel">
    <button type="button" className="sv-btn sm primary mb-3 inline-flex items-center gap-1" onClick={() => setAdd(true)} data-testid="cn-panel-add"><Mic size={14} />Add or dictate a note</button>
    {list.length === 0 ? <p className="sv-muted">No contact notes yet.</p> : list.map(n => <article key={n.id} className={`sv-cnote ${n.id === id ? 'cur' : ''}`} data-testid="contact-note">
      <div className="flex flex-wrap items-baseline gap-x-2"><b>{n.reason}</b><span className="sv-small sv-muted">{n.direction} · {n.channel} · {fmtDateTime(n.contactAt)}</span>{n.flagged && !n.reviewed && <span className="sv-tag warn">for provider review</span>}{n.signed && <span className="sv-tag ok">signed</span>}</div>
      <p className="my-1 text-[13.5px] whitespace-pre-wrap">{n.text}</p>
      <div className="sv-small sv-muted">{n.author} · {n.authorRole}{n.dictated ? ' · dictated (simulated)' : ''}{n.session !== n.author ? ` · entered on ${n.session}’s tablet session` : ''}{n.signed ? ` · signed by ${n.signed.by} ${fmtDateTime(n.signed.at)}` : ' · staff record, not signed'}{n.reviewed ? ` · reviewed by ${n.reviewed.by} ${fmtDateTime(n.reviewed.at)}` : ''}</div>
      {n.flagged && !n.reviewed && <button type="button" className="sv-link sv-small" onClick={() => setRev(n.id)} data-testid="cn-review">Mark reviewed (provider PIN)</button>}
    </article>)}
    {add && <ContactNoteDialog p={p} onClose={() => setAdd(false)} onSaved={() => { setAdd(false); toast('Contact note saved to the chart.'); }} />}
    {rev && <PinSign title="Review flagged note" statement={<>I reviewed the flagged contact note for {p.name}.</>} roles={PROVIDER_ROLES} confirmLabel="Reviewed" onClose={() => setRev('')} onSigned={w => { reviewContactNote(rev, w.name, w.role); setRev(''); toast('Flag cleared.'); }} />}
  </div>;
};

/* fictional seed: one flagged post-op call for Ellen (2 days ago), one scheduling call for Robert */
export function seedContactNotes() {
  const d = (n: number, hh: string) => { const x = new Date(); x.setDate(x.getDate() + n); const [H, M] = hh.split(':').map(Number); x.setHours(H, M, 0, 0); return x.toISOString(); };
  svWrite('contact-notes', [
    { id: 'cn-e1', patientId: 'MED-1001', channel: 'Phone call', direction: 'Incoming', reason: 'Question about surgery', text: 'Patient called asking whether she should keep taking clopidogrel before her eyelid surgery. Told her not to change any medicine on her own; the surgeon will decide with her cardiologist and call her. Coordinator to follow up.', author: 'Front Desk Tester', authorRole: 'Front desk', session: 'Front Desk Tester', contactAt: d(-2, '10:20'), at: d(-2, '10:26'), dictated: false, flagged: true },
    { id: 'cn-r1', patientId: 'MED-1004', channel: 'Text message', direction: 'Outgoing', reason: 'Scheduling', text: 'Texted to confirm drain removal at the post-op visit. Patient confirmed.', author: 'Front Desk Tester', authorRole: 'Front desk', session: 'Front Desk Tester', contactAt: d(-1, '15:05'), at: d(-1, '15:06'), dictated: false, flagged: false },
  ] as ContactNote[]);
}

chartAnswerHooks.push((pid, q) => {
  if (!/(phone )?call(ed)?\b|contact note|phone note|who called|messages? taken/.test(q)) return null;
  const l = contactNotes(pid); const ref = R('contactnotes', 'Contact notes', pid);
  return { text: l.length ? `${l.length} contact note${l.length === 1 ? '' : 's'}. Latest: ${l.slice(0, 3).map(n => `${fmtDateTime(n.contactAt)} ${n.channel.toLowerCase()} (${n.reason}, ${n.author.replace(/,.*$/, '')}${n.flagged && !n.reviewed ? ', flagged for review' : ''}): “${n.text.slice(0, 90)}${n.text.length > 90 ? '…' : ''}”`).join(' · ')}` : 'No contact notes in this chart. Use Add / dictate note in the chart header.', cites: [ref], act: { type: 'panel', ref } };
});
