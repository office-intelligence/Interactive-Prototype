/* Which station step the Today timeline asked for (one-shot). */
let pending = '';
export const fdStationStep = (s: string) => { pending = s; };
export const takeFdStationStep = () => { const s = pending; pending = ''; return s; };
