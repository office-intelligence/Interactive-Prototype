/* Front Door: the forms assigned to a station (Practice › Forms & workflow) shown inside the station panel, fillable and
   signable right there (FormPage; signatures ask for the signer's own PIN). Nightingale never signs. */
import React, { useState } from 'react';
import { repo } from '../../v6/dataLayer';
import { FormPage } from '../../v6/FormPage';
import { stationPlan } from '../../v7/myForms';
import { VITYLS_FORM_CATALOG, WorkflowKey } from '../../data/formWorkspaceCatalog';
import { MedVisit, visitAsCase } from '../../med/record';
import { useMedTick } from '../../med/ui';
import { SURGERY_STATION_LABEL } from '../v10/stations';
const item = (f: string) => VITYLS_FORM_CATALOG.find(x => x.file === f) || { title: f.replace(/\.html$/, '').replace(/_/g, ' '), file: f, category: 'Form', stage: '' };
export const FdStationForms: React.FC<{ v: MedVisit; station: WorkflowKey; step: string }> = ({ v, station, step }) => {
  useMedTick(); const [open, setOpen] = useState<string | null>(null);
  const plan = stationPlan(station); const files = Array.from(new Set([...plan.required, ...plan.asNeeded]));
  if (open) return <div className="sv-flat fd-station-forms" data-testid={`fd-station-form-open`}><FormPage patient={visitAsCase(v)} form={item(open)} station={station} onClose={() => setOpen(null)} /></div>;
  return <section className="fd-station-forms" data-testid={`fd-station-forms-${step}`}>
    <h2 className="sv-h">Forms for this station · {SURGERY_STATION_LABEL[station] || station}</h2>
    {files.length === 0 ? <p className="sv-muted text-[13.5px]">No forms are assigned to this station. Forms &amp; Documents › Forms &amp; workflow.</p> :
      <table className="sv-table"><thead><tr><th>Form</th><th>Status</th><th></th></tr></thead><tbody>{files.map(f => { const r = repo.getForm(v.id, f); return <tr key={f} data-testid="fd-station-form">
        <td>{item(f).title}<div className="sv-muted text-[11.5px]">{plan.required.includes(f) ? 'Required' : 'As needed'}</div></td>
        <td>{r.status === 'locked' ? <span className="sv-tag ok">Signed</span> : r.status === 'not-started' ? <span className="sv-muted">Not started</span> : <span className="sv-tag warn">{r.status === 'draft' ? 'Draft' : 'Partly signed'}</span>}</td>
        <td className="text-right"><button type="button" className="sv-btn sm" onClick={() => setOpen(f)} data-testid={`fd-form-open-${f}`}>{r.status === 'not-started' ? 'Fill in' : r.status === 'locked' ? 'View' : 'Continue / sign'}</button></td></tr>; })}</tbody></table>}
  </section>;
};
