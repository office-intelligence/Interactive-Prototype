/* Front Door chats with Nightingale: kept on this device in the practice namespace (fictional data only). */
import { svRead, svWrite } from '../store';
import type { Act, Ref } from '../nightingale';
export interface FdMsg { who: 'me' | 'ng'; text: string; cites?: Ref[]; pid?: string; act?: Act; a106?: any[]; at: string }
export interface FdChatRec { id: string; title: string; at: string; by: string; msgs: FdMsg[] }
const KEY = 'fd-chats';
export const fdChats = (): FdChatRec[] => svRead<FdChatRec[]>(KEY, []);
export const fdChat = (id: string) => fdChats().find(c => c.id === id);
export function saveFdChat(c: FdChatRec) { const all = fdChats().filter(x => x.id !== c.id); svWrite(KEY, [c, ...all].slice(0, 40)); window.dispatchEvent(new Event('fd-chats')); }
