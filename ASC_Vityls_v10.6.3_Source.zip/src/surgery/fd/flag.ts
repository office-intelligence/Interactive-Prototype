/** Front Door design: Surgery.Vityls (phase 1, v1.0) and Medical.Vityls (phase 2, v2.0) share the same SurgeryApp code.
 *  ASC.Vityls never loads it. */
import { EDITION } from '../../edition';
export const FD = EDITION === 'SURGERY' || EDITION === 'MEDICAL' || EDITION === 'ASC2';
