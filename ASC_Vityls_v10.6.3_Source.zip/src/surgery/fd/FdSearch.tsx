/* Front Door search: patients (opens the chart), today's visits (opens the station), pages and past chats. */
import React, { useEffect, useRef, useState } from 'react';
import { medRepo, isoDay } from '../../med/record';
import { fdChats } from './chats';
export interface FdPage { label: string; run: () => void }
export const FdSearch: React.FC<{ onClose: () => void; onPatient: (pid: string) => void; onVisit: (vid: string) => void; onChat: (id: string) => void; pages: FdPage[] }> = ({ onClose, onPatient, onVisit, onChat, pages }) => {
  const [q, setQ] = useState(''); const inp = useRef<HTMLInputElement>(null);
  useEffect(() => { inp.current?.focus(); const k = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose(); }; window.addEventListener('keydown', k); return () => window.removeEventListener('keydown', k); }, [onClose]);
  const s = q.trim().toLowerCase(); const T = isoDay();
  const pts = s ? medRepo.patients().filter(p => p.name.toLowerCase().includes(s) || p.id.toLowerCase().includes(s)).slice(0, 8) : [];
  const vis = s ? medRepo.visits().filter(v => v.date === T && (medRepo.patient(v.patientId)?.name || '').toLowerCase().includes(s)).slice(0, 4) : [];
  const pg = s ? pages.filter(p => p.label.toLowerCase().includes(s)) : pages.slice(0, 6);
  const ch = s ? fdChats().filter(c => c.title.toLowerCase().includes(s)).slice(0, 5) : [];
  const hit = (key: string, label: React.ReactNode, sub: string, run: () => void) => <button key={key} type="button" className="fd-hit" onClick={() => { onClose(); run(); }} data-testid="fd-search-hit">{label}<span>{sub}</span></button>;
  return <div className="fd-search" onMouseDown={e => { if (e.target === e.currentTarget) onClose(); }} role="dialog" aria-modal="true" aria-label="Search" data-testid="fd-search-dialog">
    <div className="fd-search-card"><input ref={inp} value={q} onChange={e => setQ(e.target.value)} placeholder="Search patients, today’s visits, pages, chats…" data-testid="fd-search-input" aria-label="Search" />
      <div className="fd-search-list">
        {pts.map(p => hit('p' + p.id, p.name, `Patient · ${p.id}`, () => onPatient(p.id)))}
        {vis.map(v => hit('v' + v.id, `${medRepo.patient(v.patientId)?.name} · ${v.time}`, `Today · ${v.visitType}`, () => onVisit(v.id)))}
        {pg.map(p => hit('g' + p.label, p.label, 'Page', p.run))}
        {ch.map(c => hit('c' + c.id, c.title, 'Chat', () => onChat(c.id)))}
        {s && !pts.length && !vis.length && !pg.length && !ch.length && <div className="fd-hit fd-muted">No matches</div>}
      </div></div></div>;
};
