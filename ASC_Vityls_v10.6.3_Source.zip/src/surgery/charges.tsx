/*
 * Charges and invoice, shared by the nurse, physician and checkout stations (v0.2).
 * Any authorized person at those stations adds items from the practice fee schedule to the visit's charges (e.g. a
 * nurse-only lab-draw visit). "Create invoice" turns un-invoiced charges into a Draft invoice (v7 invoice store);
 * while it is Draft and unpaid, later items join it. Checkout finalizes (simulated send) and takes payment.
 */
import React, { useEffect, useState } from 'react';
import { repo } from '../v6/dataLayer';
import { Invoice, saveInvoice, getInvoices, invoicesForCase, recordPayment } from '../v7/billing';
import { MedVisit, medRepo, uid, usDate, fmtDateTime } from '../med/record';
import { getSettings } from '../med/settings';
import { useActor, useMedTick } from '../med/ui';
import { svRead, svWrite } from './store';
import { useSv } from './ui';
import { Ico } from './icons';

export type Station = 'Nurse' | 'Physician' | 'Checkout';
export interface ChargeLine { id: string; visitId: string; patientId: string; feeId: string; label: string; code: string; qty: number; amount: number; addedBy: string; role: string; station: Station | 'Fee schedule'; at: string; invoiceId?: string }
const all = () => svRead<Record<string, ChargeLine[]>>('charges', {});
export const visitCharges = (visitId: string): ChargeLine[] | undefined => all()[visitId];
const put = (visitId: string, l: ChargeLine[]) => { const a = all(); a[visitId] = l; svWrite('charges', a); };
const SCHEDULE_ID = 'surgery-visit-charges';

/** First touch: start the list with the visit-type fee (if the fee schedule has one). */
export function ensureCharges(v: MedVisit) {
  if (visitCharges(v.id)) return; const f = getSettings().fees.find(x => x.active && x.visitType === v.visitType);
  put(v.id, f ? [{ id: uid('chg'), visitId: v.id, patientId: v.patientId, feeId: f.id, label: f.name, code: f.code, qty: 1, amount: f.price, addedBy: 'visit type', role: 'System', station: 'Fee schedule', at: new Date().toISOString() }] : []);
}
export function addCharge(v: MedVisit, feeId: string, qty: number, by: string, role: string, station: Station) {
  const f = getSettings().fees.find(x => x.id === feeId); if (!f) throw new Error('Choose a service from the fee schedule.');
  ensureCharges(v); const q = Math.max(1, Math.round(qty || 1));
  put(v.id, [...(visitCharges(v.id) || []), { id: uid('chg'), visitId: v.id, patientId: v.patientId, feeId: f.id, label: f.name, code: f.code, qty: q, amount: f.price, addedBy: by, role, station, at: new Date().toISOString() }]);
  repo.audit({ caseId: v.id, user: by, role, action: 'charge.add', detail: `${station} station added ${q > 1 ? `${q} × ` : ''}${f.name}${f.code ? ` (${f.code})` : ''} $${(f.price * q).toFixed(2)}` });
  syncDraft(v, by);
}
export function removeCharge(v: MedVisit, id: string, by: string, role: string, station: Station) {
  const l = visitCharges(v.id) || []; const c = l.find(x => x.id === id); if (!c) return;
  const inv = c.invoiceId ? getInvoices().find(i => i.id === c.invoiceId) : undefined; if (inv && (inv.status !== 'Draft' || inv.paid > 0)) throw new Error(`Already on invoice ${inv.number} (${inv.status}); it can’t be removed here.`);
  put(v.id, l.filter(x => x.id !== id)); repo.audit({ caseId: v.id, user: by, role, action: 'charge.remove', detail: `${station} station removed ${c.label}` }); syncDraft(v, by);
}
const draftFor = (v: MedVisit) => invoicesForCase(v.id).find(i => i.scheduleId === SCHEDULE_ID && i.status === 'Draft' && i.paid === 0);
const toLines = (l: ChargeLine[]) => l.map(c => ({ label: c.label + (c.code ? ` (${c.code})` : ''), detail: `${c.qty > 1 ? `${c.qty} × $${c.amount} · ` : ''}added by ${c.addedBy} · ${c.station}`, amount: Math.round(c.amount * c.qty * 100) / 100 }));
/** Keep an existing Draft invoice in step with the charges assigned to it. */
function syncDraft(v: MedVisit, by: string) {
  const d = draftFor(v); if (!d) return; const l = (visitCharges(v.id) || []); const mine = l.filter(c => !c.invoiceId || c.invoiceId === d.id);
  put(v.id, l.map(c => !c.invoiceId ? { ...c, invoiceId: d.id } : c)); const lines = toLines(mine);
  saveInvoice({ ...d, lines, total: Math.round(lines.reduce((s, x) => s + x.amount, 0) * 100) / 100, createdBy: by });
}
export function createInvoice(v: MedVisit, by: string, role: string, station: Station): Invoice {
  ensureCharges(v); const l = visitCharges(v.id) || []; const open = l.filter(c => !c.invoiceId);
  const d = draftFor(v); if (d) { syncDraft(v, by); return getInvoices().find(i => i.id === d.id)!; }
  if (!open.length) throw new Error('Add at least one item from the fee schedule first.');
  const p = medRepo.patient(v.patientId); const now = new Date().toISOString(); const lines = toLines(open);
  const inv: Invoice = { id: `inv-${Date.now()}`, number: `INV-${new Date().getFullYear()}-${String(getInvoices().length + 1).padStart(4, '0')}`, caseId: v.id, patientName: p?.name || '', patientId: v.patientId, dos: usDate(v.date), procedure: `${v.visitType}${v.reason ? `: ${v.reason}` : ''}`, surgeon: v.provider, paymentType: 'Self-Pay', scheduleId: SCHEDULE_ID, scheduleName: 'Practice fee schedule · visit charges', facilityMin: 0, anesthesiaMin: 0, lines, total: Math.round(lines.reduce((s, x) => s + x.amount, 0) * 100) / 100, paid: 0, status: 'Draft', createdAt: now, createdBy: by };
  saveInvoice(inv); put(v.id, l.map(c => c.invoiceId ? c : { ...c, invoiceId: inv.id }));
  repo.audit({ caseId: v.id, user: by, role, action: 'invoice.create', detail: `${station} station created invoice ${inv.number} (Draft) · ${lines.length} item(s) · $${inv.total.toFixed(2)}` });
  return inv;
}
export function finalizeInvoice(inv: Invoice, by: string, role: string) { saveInvoice({ ...inv, status: 'Sent (simulated)', createdBy: by }); repo.audit({ caseId: inv.caseId, user: by, role, action: 'invoice.create', detail: `Invoice ${inv.number} finalized at checkout and sent (simulated) · $${inv.total.toFixed(2)}` }); }

export const ChargesPanel: React.FC<{ v: MedVisit; station: Station; roles: string[] }> = ({ v, station, roles }) => {
  useMedTick(); const [actor] = useActor(); const { toast } = useSv();
  useEffect(() => { ensureCharges(v); }, [v]);
  const fees = getSettings().fees.filter(f => f.active); const [fee, setFee] = useState(''); const [qty, setQty] = useState('1'); const [pay, setPay] = useState('');
  const lines = visitCharges(v.id) || []; const invs = invoicesForCase(v.id).filter(i => i.scheduleId === SCHEDULE_ID);
  const can = roles.length >= 0; /* v0.4: open stations, anyone on the tablet adds items; audited under the session */ const total = lines.reduce((s, c) => s + c.amount * c.qty, 0); const open = lines.filter(c => !c.invoiceId).length;
  const run = (f: () => void) => { try { f(); } catch (e) { toast((e as Error).message); } };
  return <section className="sv-charges" data-testid={`charges-${station.toLowerCase()}`}>
    <h2 className="sv-h flex items-center gap-1.5"><Ico k="invoice" />Charges &amp; invoice · {station} station</h2>
    <table className="sv-table text-[13px]"><thead><tr><th>Item</th><th className="text-right">Qty</th><th className="text-right">Amount</th><th>Added</th><th></th></tr></thead><tbody>
      {lines.map(c => { const inv = c.invoiceId ? invs.find(i => i.id === c.invoiceId) : undefined; return <tr key={c.id} data-testid="charge-line"><td>{c.label}{c.code && <span className="sv-muted"> · {c.code}</span>}</td><td className="text-right">{c.qty}</td><td className="text-right">${(c.amount * c.qty).toFixed(2)}</td><td className="sv-muted text-[12px]">{c.station} · {c.addedBy}{inv && <> · <span className="sv-tag">{inv.number}</span></>}</td><td className="text-right">{can && (!inv || (inv.status === 'Draft' && inv.paid === 0)) && <button type="button" className="sv-link text-[12px]" onClick={() => run(() => removeCharge(v, c.id, actor.name, actor.role, station))} aria-label={`Remove ${c.label}`}>remove</button>}</td></tr>; })}
      {!lines.length && <tr><td colSpan={5} className="sv-muted">No items yet.</td></tr>}
      <tr><td colSpan={2}><b>Total</b></td><td className="text-right"><b data-testid="charges-total">${total.toFixed(2)}</b></td><td colSpan={2}></td></tr>
    </tbody></table>
    {can ? <div className="flex flex-wrap items-end gap-2 mt-2">
      <label className="flex-1 min-w-[200px]"><span className="sv-label">Add from the fee schedule</span><select className="sv-input" value={fee} onChange={e => setFee(e.target.value)} data-testid={`charge-fee-${station.toLowerCase()}`}><option value="">Choose a service…</option>{fees.map(f => <option key={f.id} value={f.id}>{f.name}{f.code ? ` (${f.code})` : ''} · ${f.price}</option>)}</select></label>
      <label style={{ width: 70 }}><span className="sv-label">Qty</span><input className="sv-input" inputMode="numeric" value={qty} onChange={e => setQty(e.target.value.replace(/\D/g, ''))} /></label>
      <button type="button" className="sv-btn" disabled={!fee} onClick={() => run(() => { addCharge(v, fee, +qty || 1, actor.name, actor.role, station); setFee(''); setQty('1'); toast('Added to the visit charges.'); })} data-testid={`charge-add-${station.toLowerCase()}`}>Add item</button>
      <button type="button" className="sv-btn primary" onClick={() => run(() => { const i = createInvoice(v, actor.name, actor.role, station); toast(`Invoice ${i.number} · Draft · $${i.total.toFixed(2)}`); })} data-testid={`invoice-create-${station.toLowerCase()}`}>{draftFor(v) ? 'Update invoice' : 'Create invoice'}{open ? ` · ${open} new` : ''}</button>
    </div> : <p className="text-[12.5px] sv-muted mt-2">Switch “Acting as” to someone at this station to add items.</p>}
    {invs.length > 0 && <div className="mt-3 space-y-1.5" data-testid="invoice-list">{invs.map(i => <div key={i.id} className="flex flex-wrap items-center gap-2 text-[13px]"><Ico k="invoice" /><b>{i.number}</b><span className={`sv-tag ${i.status === 'Paid in full' ? 'ok' : i.status === 'Draft' ? 'warn' : ''}`} data-testid="invoice-status">{i.status}</span><span>${i.total.toFixed(2)}{i.paid ? ` · paid $${i.paid.toFixed(2)}` : ''}</span><span className="sv-muted text-[12px]">created {fmtDateTime(i.createdAt)}</span>
      {station === 'Checkout' && can && i.status === 'Draft' && <button type="button" className="sv-btn sm" onClick={() => { finalizeInvoice(i, actor.name, actor.role); toast(`${i.number} finalized (sending is simulated).`); }} data-testid="invoice-finalize">Finalize &amp; send (simulated)</button>}
      {station === 'Checkout' && can && i.status !== 'Paid in full' && <span className="inline-flex gap-1 items-center"><input className="sv-input" style={{ width: 90 }} inputMode="decimal" placeholder={`$${(i.total - i.paid).toFixed(2)}`} value={pay} onChange={e => setPay(e.target.value.replace(/[^\d.]/g, ''))} aria-label="Payment amount" /><button type="button" className="sv-btn sm" onClick={() => { const amt = +(pay || (i.total - i.paid)); if (amt > 0) { recordPayment(i.id, amt, actor.name); setPay(''); toast('Payment recorded (simulated).'); } }} data-testid="invoice-pay">Record payment</button></span>}
    </div>)}</div>}
    <p className="text-[11.5px] sv-muted mt-1.5">Fee schedule: Practice › Fee schedule. Nurse, physician and checkout all add to the same visit invoice. Payments are simulated.</p>
  </section>;
};
