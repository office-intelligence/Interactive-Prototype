/* ASC.Vityls v9.0 · Today = Mockup v2 "Today's case flow". Left: summary card (date nav, 2×2 stats, case flow, clearance legend,
 * Nightingale note) + collapsible To-do and Nightingale activity. Main: room pills, vertical timeline with station-coloured nodes,
 * a red "Now" marker, case cards (time · room, name, procedure · surgeon · anesthesia, clearance + station chips) and a full-width
 * station pill row that opens the slide-over. Check in / Chart / Cancel / Details stay on every card. Never blocks. Fictional data. */
import React, { useState } from 'react';
import { ChevronLeft, ChevronRight, ChevronDown, Check, Clock, ClipboardCheck, Stethoscope, Syringe, Scissors, BedDouble, Car, Sparkles } from 'lucide-react';
import { medRepo, isoDay, addDays } from '../../med/record';
import { useActor, useMedTick } from '../../med/ui';
import { useSv } from '../ui';
import * as A from '../asc8/logic';
import * as S from '../asc8/store';
import { openAsc } from '../asc8/ui';
import { s81, use81 } from '../asc81/store81';
import { WSS, wsStatus } from '../asc84/chips';
import { CheckInDialog } from '../asc83/frontdesk';
import { caseSignals } from '../asc81/Workbench';
import { bookingChecklist } from '../asc81/ai';
import { buildTodos, TodoList, NightingalePanel, CancelDialog, cleared } from '../asc87/ui87';
import * as F from './flow90';

const hm = (t: string) => t.replace(/^0/, '');
const ICON: Record<string, React.FC<any>> = { front: ClipboardCheck, nursing: Stethoscope, anesthesia: Syringe, or: Scissors, pacu: BedDouble, discharge: Car };
export function caseFlow(c: A.AscCase) { const w = (k: string) => WSS.find(x => x.k === k)!; const nDone = wsStatus(c, w('nursing')).s === 'done'; const pDone = wsStatus(c, w('pacu')).s === 'done';
  const cur = F.currentIdx(c.loc as F.LocLite, nDone, pDone); const missing = c.loc === 'scheduled' ? bookingChecklist(caseSignals(c, s81.ai(c.id))).filter(i => i.state === 'missing').map(i => i.label) : [];
  return { cur, clear: F.clearOf(cleared(c), missing), missing }; }
export const anesType = (c: A.AscCase) => (c.d.plan?.technique as string) || (/colonoscopy|endoscopy/i.test(c.procedure) ? 'MAC' : /lesion|excision of skin/i.test(c.procedure) ? 'Local' : 'General');
const shortDr = (n: string) => `Dr. ${n.replace(/,.*$/, '').split(' ').slice(-1)[0]}`;

export const Coll: React.FC<{ title: React.ReactNode; count?: number; open0?: boolean; tid: string; children: React.ReactNode }> = ({ title, count, open0 = true, tid, children }) => { const [o, setO] = useState(open0);
  return <section className="n9-card n9-coll" data-testid={tid} data-open={o ? '1' : '0'}><button type="button" className="n9-collh" onClick={() => setO(!o)} aria-expanded={o}><b>{title}</b>{count !== undefined && <span className="n9-cnt">{count}</span>}<ChevronDown size={16} style={{ marginLeft: 'auto', transform: o ? 'rotate(180deg)' : undefined }} /></button><div hidden={!o} className="n9-collb">{children}</div></section>; };

export const AscToday90: React.FC = () => {
  useMedTick(); use81(); const [actor] = useActor(); const { go } = useSv(); const openChart = (pid: string) => go({ type: 'chart', pid } as any); const T = isoDay(); const [day, setDay] = useState(T); const [ci, setCi] = useState(''); const [cx, setCx] = useState(''); const [room, setRoom] = useState('All');
  const st = A.stationOf(actor.role); const all = S.cases().filter(c => c.date === day && (st !== 'surgeon' || c.surgeon === actor.name)).sort((a, b) => A.toMin(a.time) - A.toMin(b.time));
  const rooms = Array.from(new Set([...all.map(c => c.room), 'OR 1', 'OR 2', 'OR 3', 'Proc 1'])).sort((a, b) => (a.startsWith('Proc') ? 1 : 0) - (b.startsWith('Proc') ? 1 : 0) || a.localeCompare(b));
  const cs = all.filter(c => room === 'All' || c.room === room); const flows = new Map(all.map(c => [c.id, caseFlow(c)]));
  const isToday = day === T; const now = new Date(); const nowMin = now.getHours() * 60 + now.getMinutes(); const todos = buildTodos(T, day);
  const k = { cases: all.length, prog: all.filter(c => ['arrived', 'preop', 'or', 'pacu'].includes(c.loc)).length, notClear: all.filter(c => flows.get(c.id)!.clear !== 'cleared').length, late: isToday ? all.filter(c => F.lateStart(c.loc as F.LocLite, A.toMin(c.time), nowMin)).length : 0 };
  const usedRooms = new Set(all.map(c => c.room)); const nIdx = isToday ? F.nowIndex(cs.map(c => A.toMin(c.time)), nowMin) : -1;
  const note = all.find(c => flows.get(c.id)!.missing.length); const dl = new Date(day + 'T12:00');
  const nowL = now.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' }).replace(/\s?[AP]M$/, '');
  return <div className="n9-today" data-testid="sv-dashboard" data-station={st}>
    <aside className="n9-left">
      <section className="n9-card n9-sum" data-testid="n9-summary">
        <div className="n9-dnav"><button type="button" className="n9-ib" onClick={() => setDay(addDays(day, -1))} aria-label="Previous day" data-testid="a87-prev"><ChevronLeft size={15} /></button>
          <input type="date" className="n9-date" value={day} onChange={e => e.target.value && setDay(e.target.value)} data-testid="a87-date" aria-label="Pick a date" />
          <button type="button" className="n9-ib" onClick={() => setDay(addDays(day, 1))} aria-label="Next day" data-testid="a87-next"><ChevronRight size={15} /></button>
          <button type="button" className="n9-pill sm" onClick={() => setDay(T)} disabled={isToday} data-testid="a87-today-btn">Today</button></div>
        <h2 className="n9-st" data-testid="today-title">{isToday ? 'Today' : 'Day'} · {dl.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' })}</h2>
        <div className="n9-mu s" data-testid="today-greeting">{usedRooms.size} room{usedRooms.size === 1 ? '' : 's'}{all[0] ? ` · first case ${hm(all[0].time).replace(/\s?[AP]M$/, '')}` : ' · no cases'}</div>
        <div className="n9-stats" data-testid="a87-kpis">{([[k.cases, 'cases'], [k.prog, 'in progress'], [k.notClear, 'not cleared'], [k.late, 'late start']] as [number, string][]).map(([n, l]) => <div key={l} className="n9-stat" data-testid="n9-stat"><b>{n}</b><span>{l}</span></div>)}</div>
        <div className="n9-lab">Case flow</div><div className="n9-flowtxt">Front desk → Pre-op → Anesthesia → OR → PACU → Discharge</div>
        <div className="n9-lab">Clearance</div><div className="n9-legend">{(['cleared', 'pending', 'missing'] as F.Clear[]).map(x => <span key={x} className={`n9-chip ${F.CLEAR_CLS[x]}`}>{F.CLEAR_LABEL[x]}</span>)}</div>
        {note && <div className="n9-note" data-testid="n9-note"><span className="n9-mark"><Sparkles size={14} /></span><p>{medRepo.patient(note.pid)?.name.split(' ')[0]}’s {flows.get(note.id)!.missing[0].toLowerCase()} hasn’t come in yet{note.surgeon ? ` from ${shortDr(note.surgeon)}’s office` : ''}. <button type="button" className="n9-lnk" onClick={() => openAsc({ t: 'details', cid: note.id })} data-testid="n9-note-open">Open case</button></p></div>}
      </section>
      <Coll title="To-do" count={todos.length} tid="n9-todo-card"><TodoList items={todos} /></Coll>
      <Coll title="Nightingale activity" open0={false} tid="n9-ng-card"><NightingalePanel /></Coll>
    </aside>
    <section className="n9-main" aria-label="Today's case flow" data-testid="a87-patients">
      <div className="n9-h"><h1>{isToday ? 'Today’s case flow' : `Case flow · ${dl.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' })}`}</h1><span className="n9-mu">Tap a case to open its record; tap a station to work in it</span></div>
      <div className="n9-rooms" role="tablist" aria-label="Room">{['All', ...rooms].map(r => <button key={r} type="button" role="tab" aria-selected={room === r} className={`n9-pill ${room === r ? 'on' : ''}`} onClick={() => setRoom(r)} data-testid={`n9-room-${r.replace(/\s+/g, '')}`}>{r}</button>)}</div>
      {!cs.length && <p className="n9-mu" data-testid="a87-none">No surgeries {room === 'All' ? 'on this date' : `in ${room}`}.</p>}
      <ol className="n9-line">{cs.map((c, i) => { const p = medRepo.patient(c.pid)!; const f = flows.get(c.id)!; const sc = F.stageChip(f.cur); const NodeI = f.cur >= 6 ? Check : f.cur < 0 ? Clock : ICON[F.FLOW[f.cur]];
        const canCi = isToday && c.loc === 'scheduled'; const canCx = c.loc === 'scheduled';
        return <React.Fragment key={c.id}>{i === nIdx && <li className="n9-now" data-testid="n9-now">Now · {nowL}</li>}
          <li className="n9-ev" data-testid="a87-card" data-case={c.id} data-cleared={f.clear === 'cleared' ? '1' : '0'}>
            <span className={`n9-node ${F.nodeCls(f.cur)}`} aria-hidden="true"><NodeI size={15} /></span>
            <div className="n9-cc" role="button" tabIndex={0} onClick={() => openChart(c.pid)} onKeyDown={e => { if (e.key === 'Enter') openChart(c.pid); }} data-testid="n9-case-open">
              <div className="n9-row"><span className="n9-tr">{hm(c.time)} · {c.room.toUpperCase()}</span><b className="n9-nm">{p.name}</b>
                <span className="n9-chips"><span className={`n9-chip ${F.CLEAR_CLS[f.clear]}`} data-testid="n9-clear" title={f.missing.join(', ')}>{F.CLEAR_LABEL[f.clear]}</span><span className={`n9-chip ${sc.cls}`} data-testid="a87-stage">{sc.t}</span></span></div>
              <div className="n9-sub">{c.procedure}{c.side && !c.procedure.toLowerCase().includes(c.side.toLowerCase()) ? ` (${c.side})` : ''} · {shortDr(c.surgeon)} · {anesType(c)}
                <span className="n9-acts" onClick={e => e.stopPropagation()}>{canCi && <button type="button" className="n9-a ok" onClick={() => setCi(c.id)} data-testid="a87-checkin">Check in</button>}<button type="button" className="n9-a" onClick={() => openChart(c.pid)} data-testid="a87-chart">Chart</button><button type="button" className="n9-a" onClick={() => openAsc({ t: 'details', cid: c.id })} data-testid="n9-details">Details</button>{canCx && <button type="button" className="n9-a red" onClick={() => setCx(c.id)} data-testid="a87-cancel">Cancel</button>}</span></div>
              {isToday && <div className="n9-pills" data-testid="a84-ws-chips" onClick={e => e.stopPropagation()}>{F.FLOW.map((key, j) => { const w = WSS.find(x => x.k === key)!; const s = F.pillState(j, f.cur);
                return <button key={key} type="button" className={`n9-sp ${s}`} onClick={() => w.open(c)} data-testid={`a84-ws-${key}`} data-state={s} title={`${F.FLOW_LABEL[key]} · open station`}>{s === 'done' && <Check size={12} />}{F.FLOW_LABEL[key]}</button>; })}</div>}
            </div></li></React.Fragment>; })}{nIdx === cs.length && cs.length > 0 && <li className="n9-now" data-testid="n9-now">Now · {nowL}</li>}</ol>
      <p className="n9-foot">Fictional patients and surgeons · test build</p>
    </section>
    {ci && <CheckInDialog cid={ci} onClose={() => setCi('')} />}{cx && <CancelDialog cid={cx} onClose={() => setCx('')} />}
  </div>;
};
