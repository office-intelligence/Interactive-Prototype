/* ASC.Vityls v9.0 · Patient page = Mockup v2 "Case record". Left: identity card with living summary (Nightingale draft), allergy
 * card (Confirm / Edit), clearance docs via send-to-ASC, needs-attention + account/credit; Today's cases (quick switch); care team.
 * Main: Case record timeline of station events (each opens its station), Open-a-station pills, then Documents (categories),
 * Billing & payments, Past cases and Overview. Profile / Print / Collect payment / Upload at top right. Fictional data. */
import React, { useState } from 'react';
import { Check, Clock, ClipboardCheck, Stethoscope, Syringe, Scissors, BedDouble, Car, Sparkles, Home, Send } from 'lucide-react';
import { medRepo, ageFrom, isoDay } from '../../med/record';
import { useActor, useMedTick } from '../../med/ui';
import { useSv } from '../ui';
import { repo } from '../../v6/dataLayer';
import * as A from '../asc8/logic';
import * as S from '../asc8/store';
import { openAsc } from '../asc8/ui';
import { s81, use81 } from '../asc81/store81';
import { caseSignals } from '../asc81/Workbench';
import { bookingChecklist } from '../asc81/ai';
import { WSS, wsStatus } from '../asc84/chips';
import { caseMoney, payTypeOf } from '../asc83/pay';
import { PayChip, cancelledCases } from '../asc83/frontdesk';
import { Overview, Documents, Billing } from '../asc83/chart';
import * as D86 from '../asc86/store86';
import { openUpload } from '../asc87/ui87';
import { ProfileDialog, PrintChartDialog, CreditDialog } from '../asc89/chart89';
import { availableCredit, credits } from '../asc89/store89';
import { creditLeft, OR_TILES } from '../asc89/pure89';
import * as F from './flow90';
import { caseFlow, anesType } from './today90';

const money = (n: number) => `$${n.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
const dos = (d: string) => new Date(d + 'T12:00').toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
const md = (iso?: string) => iso ? new Date(iso).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }) : '';
const hm = (t?: string) => (t || '').replace(/^0/, '');
const shortDr = (n: string) => `Dr. ${n.replace(/,.*$/, '').split(' ').slice(-1)[0]}`;
const ST: Record<string, [string, string]> = { done: ['Done', 'ok'], 'in-progress': ['In progress', 'warm'], 'not-started': ['Not started', 'plain'], exceptions: ['Needs review', 'peach'] };
type Tab = 'documents' | 'billing' | 'cases' | 'overview';

export const AscChart90: React.FC<{ patientId: string }> = ({ patientId }) => {
  useMedTick(); use81(); const [actor] = useActor(); const { go, toast } = useSv(); const p = medRepo.patient(patientId); const [tab, setTab] = useState<Tab>('documents'); const [dlg, setDlg] = useState<'' | 'profile' | 'print' | 'credit'>('');
  const cs = S.cases().filter(c => c.pid === patientId).sort((a, b) => b.date.localeCompare(a.date)); const T = isoDay();
  const pick0 = cs.find(c => c.date === T) || cs.filter(c => c.date >= T).sort((a, b) => a.date.localeCompare(b.date))[0] || cs[0]; const [sel, setSel] = useState(pick0?.id || ''); const c = cs.find(x => x.id === sel) || pick0;
  if (!p) return null; const cr = availableCredit(p.id); const due = cs.reduce((n, x) => n + caseMoney(x).balance, 0); const f = c ? caseFlow(c) : null; const sc = f ? F.stageChip(f.cur) : null;
  const checklist = c ? bookingChecklist(caseSignals(c, s81.ai(c.id))) : []; const first = p.name.split(' ')[0];
  const summary = c ? `${first} ${c.loc === 'scheduled' ? 'is scheduled for' : c.loc === 'discharged' || c.loc === 'closed' ? 'had' : 'is having'} ${c.procedure.toLowerCase()} with ${shortDr(c.surgeon)} in ${c.room} ${c.date === T ? 'today' : `on ${dos(c.date)}`} at ${hm(c.time)} under ${anesType(c).toLowerCase()} anesthesia. ${(() => { const m = checklist.filter(i => i.state === 'missing').map(i => i.label.toLowerCase()); return m.length ? `Still missing: ${m.slice(0, 3).join(', ')}.` : 'All clearance documents are in.'; })()}${due > 0 ? ` Open balance ${money(due)}.` : ''}${cr > 0 ? ` ${money(cr)} credit on account.` : ''}` : `${first} has no cases at this ASC yet.`;
  const confirmAllergy = () => { medRepo.savePatient({ ...p, allergiesConfirmedAt: new Date().toISOString() } as any); repo.audit({ caseId: `pt:${p.id}`, user: actor.name, role: actor.role, action: 'asc90.allergy-confirm' as any, detail: `Allergies confirmed: ${p.allergies.join('; ') || 'NKDA'}` }); toast('Allergies confirmed and logged.'); };
  const today = S.cases().filter(x => x.date === T).sort((a, b) => A.toMin(a.time) - A.toMin(b.time));
  const attn: { k: string; t: string; act?: () => void }[] = [...(due > 0 ? [{ k: 'peach', t: `${money(due)} open balance`, act: () => setTab('billing') }] : []), ...(f && f.missing.length ? [{ k: 'warm', t: `${f.missing.length} clearance item${f.missing.length === 1 ? '' : 's'} missing`, act: () => c && openAsc({ t: 'details', cid: c.id }) }] : []), ...(!p.allergiesConfirmedAt ? [{ k: 'warm', t: 'Allergies not confirmed' }] : [])];
  const w = (k: string) => WSS.find(x => x.k === k)!;
  type Ev = { k: string; ty: string; when?: string; sub: React.ReactNode; st: [string, string]; node: string; I: React.FC<any>; open?: () => void };
  const ev: Ev[] = c ? (() => { const d = c.d as any; const curK = f && f.cur >= 0 && f.cur < 6 ? F.FLOW[f.cur] : ''; const s = (k: string) => { const v = wsStatus(c, w(k)).s; return v === 'not-started' && k === curK ? 'in-progress' : v; }; const e = c.events as Record<string, string | undefined>;
    const fm = d.forms && d.financial; const sendIn = checklist.filter(i => i.state !== 'missing').length; const orT = OR_TILES.filter(o => e[o.key]).map(o => <span key={o.key}>{o.label}: <b>{F && hm(e[o.key])}</b></span>);
    return [
      { k: 'home', ty: 'At-home forms', when: md(d.forms?.at), sub: fm ? 'Portal / at-home · consent + health history e-signed by patient' : 'Registration / financial forms not yet signed in the portal', st: fm ? ['Signed', 'ok'] : ['Pending', 'warm'], node: 'n-plum', I: Home, open: () => openAsc({ t: 'details', cid: c.id }) },
      { k: 'send', ty: 'Send-to-ASC', when: md(d.clearance?.at), sub: `${shortDr(c.surgeon)}’s office · ${sendIn} of ${checklist.length} documents received${f!.missing.length ? ` · missing ${f!.missing.join(', ').toLowerCase()}` : ''}`, st: f!.missing.length ? ['Missing items', 'peach'] : ['Received', 'ok'], node: 'n-sky', I: Send, open: () => openAsc({ t: 'details', cid: c.id }) },
      { k: 'front', ty: 'Front desk', when: d.arrival ? hm(d.arrival) : '', sub: c.loc === 'scheduled' ? 'Not checked in yet' : 'Checked in · ID and insurance verified', st: ST[A.atLeast(c.loc, 'arrived') ? 'done' : s('front')], node: 'n-stone', I: ClipboardCheck, open: () => w('front').open(c) },
      { k: 'nursing', ty: 'Pre-op nursing', sub: s('nursing') === 'done' ? 'Signed with PIN' : 'Vitals, NPO, IV, site check, consent', st: ST[s('nursing')], node: 'n-sky', I: Stethoscope, open: () => w('nursing').open(c) },
      { k: 'anesthesia', ty: 'Anesthesia', sub: s('anesthesia') === 'done' ? 'Signed with PIN' : `ASA, airway, plan (${anesType(c)})`, st: ST[s('anesthesia')], node: 'n-plum', I: Syringe, open: () => w('anesthesia').open(c) },
      { k: 'or', ty: 'OR · OR/Surgeon', sub: orT.length ? <span className="n9-ort">{orT}</span> : 'Time-out, counts, event times', st: ST[s('or')], node: 'n-terra', I: Scissors, open: () => w('or').open(c) },
      { k: 'pacu', ty: 'PACU · PACU/Discharge', sub: s('pacu') === 'done' ? 'Recovery complete' : 'Tap to open the station panel', st: ST[s('pacu')], node: 'n-peach', I: BedDouble, open: () => w('pacu').open(c) },
      { k: 'discharge', ty: 'Discharge', sub: c.loc === 'discharged' || c.loc === 'closed' ? 'Discharged with instructions and escort' : 'Instructions, discharge order, escort', st: ST[c.loc === 'discharged' || c.loc === 'closed' ? 'done' : s('discharge')], node: 'n-amber', I: Car, open: () => w('discharge').open(c) },
    ]; })() : [];
  return <div className="n9-chart" data-testid="a83-chart">
    <aside className="n9-left">
      <section className="n9-card n9-pc" data-testid="a89-snap">
        <div className="n9-pid"><span className="n9-av">{p.name.split(' ').map(x => x[0]).slice(0, 2).join('')}</span><div className="min-w-0"><h1 data-testid="a83-chart-name">{p.name}</h1><div className="n9-mu s">{ageFrom(p.dob)}{c ? ` · ${c.procedure}` : ''}</div></div></div>
        <div className="n9-chips l">{f && <span className={`n9-chip ${F.CLEAR_CLS[f.clear]}`}>{f.clear === 'cleared' ? 'Cleared · moving forward' : F.CLEAR_LABEL[f.clear]}</span>}{sc && <span className={`n9-chip ${sc.cls}`}>{sc.t}</span>}{cr > 0 && <span className="n9-chip ok" data-testid="a89-credit-chip">Credit {money(cr)}</span>}</div>
        <div className="n9-lab">Living summary</div><p className="n9-sumtxt" data-testid="n9-living">{summary}</p>
        <div className={`n9-alg ${p.allergies.length ? 'red' : 'green'}`} data-testid="n9-allergy"><b>{p.allergies.length ? 'Allergies' : 'No known drug allergies'}</b>{p.allergies.length > 0 && <div className="n9-algl">{p.allergies.join('; ')}</div>}
          <div className="n9-algb">{p.allergiesConfirmedAt ? <span className="n9-mu s">Confirmed {md(p.allergiesConfirmedAt)}</span> : <button type="button" className="n9-btn sm" onClick={confirmAllergy} data-testid="n9-allergy-confirm">Confirm</button>}<button type="button" className="n9-btn link sm" onClick={() => setDlg('profile')} data-testid="n9-allergy-edit">Edit</button></div></div>
        <div className="n9-lab">Clearance docs · via send-to-ASC</div>
        <ul className="n9-docs" data-testid="n9-clear-docs">{checklist.map(i => <li key={i.id}><span className="n9-dic">▤</span><span className="flex-1">{i.label}</span><span className={`n9-chip ${i.state === 'missing' ? 'peach' : i.state === 'abnormal' ? 'warm' : 'ok'}`}>{i.state === 'missing' ? 'Missing' : `Received${md((c?.d as any)?.[i.id]?.at) ? ` ${md((c?.d as any)?.[i.id]?.at)}` : ''}`}</span></li>)}{!checklist.length && <li className="n9-mu s">No case yet.</li>}</ul>
        <div className="n9-note"><span className="n9-mark"><Sparkles size={14} /></span><p>I keep this summary up to date from the case timeline. Drafts only; staff confirm.</p></div>
      </section>
      <section className="n9-card" data-testid="a89-attn"><div className="n9-lab" style={{ marginTop: 0 }}>Needs attention</div>{attn.length ? attn.map((a, i) => <button key={i} type="button" className="n9-att" onClick={a.act} disabled={!a.act}><i className={a.k} />{a.t}</button>) : <p className="n9-mu s">Nothing needs attention.</p>}
        <div className="n9-acct" data-testid="a89-account"><div><span>Open balance</span><b>{money(due)}</b></div><div><span>Available credit</span><b className="g" data-testid="a89-chart-credit">{money(cr)}</b></div></div>
        {credits(p.id).length > 0 && <div className="n9-mu s">{credits(p.id).map(k => <div key={k.id}>{k.receipt} · {k.type} · {money(k.amount)} · left {money(creditLeft(k))}</div>)}</div>}</section>
      <section className="n9-card n9-tc" data-testid="n9-today-cases"><div className="n9-lab" style={{ marginTop: 0 }}>Today’s cases</div>{today.map(x => { const xf = caseFlow(x); return <button key={x.id} type="button" className={`n9-tcr ${x.pid === p.id ? 'on' : ''}`} onClick={() => go({ type: 'chart', pid: x.pid } as any)}><span>{hm(x.time)} · {medRepo.patient(x.pid)?.name}</span><span className={`n9-chip ${F.CLEAR_CLS[xf.clear]}`}>{xf.clear === 'cleared' ? 'cleared' : xf.clear === 'pending' ? 'pending' : 'missing'}</span></button>; })}{!today.length && <p className="n9-mu s">No cases today.</p>}</section>
      {c && <section className="n9-card"><div className="n9-lab" style={{ marginTop: 0 }}>Care team</div><div className="n9-acct"><div><span>Surgeon</span><b>{c.surgeon}</b></div><div><span>Anesthesia</span><b>{c.anesthesia}</b></div><div><span>Room</span><b>{c.room}</b></div><div><span>Payment</span><b>{payTypeOf(c)}</b></div></div></section>}
    </aside>
    <section className="n9-main">
      <div className="n9-crumb"><button type="button" className="n9-lnk" onClick={() => go({ type: 'tab', tab: 'patients' } as any)} data-testid="a87-chart-back">‹ Patients</button><span>/</span><span>{p.name}</span></div>
      <div className="n9-h"><h1>Case record</h1><span className="n9-mu">Every event from every station · PDF only on export or print</span>
        <div className="n9-hacts"><button type="button" className="n9-btn" onClick={() => setDlg('profile')} data-testid="a89-btn-profile">Profile</button><button type="button" className="n9-btn" onClick={() => setDlg('print')} data-testid="a89-btn-print">Print</button><button type="button" className="n9-btn pri" onClick={() => setDlg('credit')} data-testid="a89-btn-collect">Collect payment</button>{c && <button type="button" className="n9-btn" onClick={() => openUpload(c.id, c.pid)} data-testid="a89-btn-upload">Upload</button>}</div></div>
      {cs.length > 1 && <div className="n9-rooms"><span className="n9-mu s">Case:</span>{cs.map(x => <button key={x.id} type="button" className={`n9-pill ${c?.id === x.id ? 'on' : ''}`} onClick={() => setSel(x.id)} data-testid="n9-case-pick">{dos(x.date)} · {x.procedure.split(',')[0]}</button>)}</div>}
      {c && <div className="n9-rooms" data-testid="n9-open-station"><span className="n9-mu s">Open a station:</span>{F.FLOW.map(k => <button key={k} type="button" className="n9-pill" onClick={() => w(k).open(c)} data-testid={`n9-os-${k}`}>{F.FLOW_LABEL[k]}</button>)}</div>}
      <ol className="n9-line rec" data-testid="a89-timeline">{ev.map(e => <li key={e.k} className="n9-ev" data-testid="n9-rec-ev" data-k={e.k}><span className={`n9-node ${e.st[1] === 'ok' ? 'n-green' : e.node}`} aria-hidden="true">{e.st[1] === 'ok' && e.k !== 'home' && e.k !== 'send' ? <Check size={15} /> : <e.I size={15} />}</span>
        <button type="button" className="n9-cc rec" onClick={e.open} data-testid={`n9-rec-${e.k}`}><div className="n9-row"><span className={`n9-ty ${e.st[1] === 'warm' || e.st[1] === 'peach' ? 'c-terra' : ''}`}>{e.ty}</span>{e.when && <span className="n9-mu s">{e.when}</span>}<span className={`n9-chip ${e.st[1]}`} style={{ marginLeft: 'auto' }}>{e.st[0]}</span></div><div className="n9-sub">{e.sub}</div></button></li>)}
        {!c && <li className="n9-mu">No case yet. Book one from the Schedule.</li>}</ol>
      <section className="n9-card n9-tabs">
        <nav className="n9-rooms" role="tablist">{([['documents', 'Documents'], ['billing', 'Billing & payments'], ['cases', 'Past cases'], ['overview', 'Overview']] as const).map(([k, l]) => <button key={k} type="button" role="tab" aria-selected={tab === k} className={`n9-pill ${tab === k ? 'on' : ''}`} onClick={() => setTab(k)} data-testid={`a83-chart-tab-${k}`}>{l}</button>)}</nav>
        {tab === 'documents' && (c ? <Documents c={c} cs={cs} onPick={setSel} /> : <p className="n9-mu">No cases yet.</p>)}{tab === 'billing' && <Billing pid={p.id} cs={cs} />}{tab === 'overview' && <Overview pid={p.id} cs={cs} />}
        {tab === 'cases' && <div data-testid="a83-chart-cases">{cs.map(x => <button key={x.id} type="button" className={`a83-caserow ${c?.id === x.id ? 'on' : ''}`} onClick={() => setSel(x.id)} data-testid="a83-chart-case"><span className="d">{dos(x.date)}</span><span className="min-w-0 flex-1"><b>{x.procedure}</b><span className="sv-small sv-muted"> · {x.surgeon} · {x.room}</span></span><span className="a83-st">{A.LOC_LABEL[x.loc]}</span><PayChip c={x} /></button>)}
          {cancelledCases(p.id).map((x: any) => <div key={x.id} className="a83-caserow off"><span className="d">{dos(x.date)}</span><span className="flex-1">{x.procedure}</span><span className="sv-small">Cancelled · {x.cancelled.reason}</span></div>)}
          {D86.schedHistory(p.id).length > 0 && <details className="mt-2" data-testid="a86-chart-hist"><summary className="sv-small">Booking, reschedule &amp; cancellation history ({D86.schedHistory(p.id).length})</summary>{D86.schedHistory(p.id).map((h, i) => <div key={i} className="a81-line sv-small"><b>{h.kind}</b> · {new Date(h.at).toLocaleString()} · {h.by} · {h.from || h.to}{h.reason ? ` · ${h.reason}` : ''}</div>)}</details>}</div>}
      </section>
    </section>
    {dlg === 'profile' && <ProfileDialog pid={p.id} onClose={() => setDlg('')} />}{dlg === 'print' && <PrintChartDialog pid={p.id} cid={c?.id} onClose={() => setDlg('')} />}{dlg === 'credit' && <CreditDialog pid={p.id} onClose={() => setDlg('')} />}
  </div>;
};
void Clock;
