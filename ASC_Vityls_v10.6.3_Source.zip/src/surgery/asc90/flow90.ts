/* ASC.Vityls v9.0 · pure helpers for the Mockup v2 Today case flow (station pill states, chips, now-marker). */
export const FLOW = ['front', 'nursing', 'anesthesia', 'or', 'pacu', 'discharge'] as const;
export type FlowKey = typeof FLOW[number];
export const FLOW_LABEL: Record<FlowKey, string> = { front: 'Front desk', nursing: 'Pre-op', anesthesia: 'Anesthesia', or: 'OR', pacu: 'PACU', discharge: 'Discharge' };
export type LocLite = 'scheduled' | 'arrived' | 'preop' | 'or' | 'pacu' | 'discharged' | 'closed';
/** index of the current station (-1 = not started, 6 = all done). */
export function currentIdx(loc: LocLite, nursingDone = false, pacuDone = false): number {
  switch (loc) { case 'scheduled': return -1; case 'arrived': return 1; case 'preop': return nursingDone ? 2 : 1; case 'or': return 3; case 'pacu': return pacuDone ? 5 : 4; default: return 6; } }
export const pillState = (i: number, cur: number): 'done' | 'cur' | 'todo' => i < cur ? 'done' : i === cur ? 'cur' : 'todo';
export function stageChip(cur: number): { t: string; cls: string } {
  if (cur < 0) return { t: 'Scheduled', cls: 'plain' }; if (cur >= 6) return { t: 'Discharged', cls: 'ok' };
  const k = FLOW[cur]; return { t: FLOW_LABEL[k], cls: ({ front: 'plain', nursing: 'sky', anesthesia: 'plum', or: 'peach', pacu: 'peach', discharge: 'ok' } as Record<FlowKey, string>)[k] }; }
export function nodeCls(cur: number): string { if (cur < 0) return 'n-stone'; if (cur >= 6) return 'n-green'; return ({ front: 'n-stone', nursing: 'n-sky', anesthesia: 'n-plum', or: 'n-terra', pacu: 'n-peach', discharge: 'n-amber' } as Record<FlowKey, string>)[FLOW[cur]]; }
export type Clear = 'cleared' | 'pending' | 'missing';
export const CLEAR_LABEL: Record<Clear, string> = { cleared: 'Cleared', pending: 'Pending items', missing: 'Missing items' };
export const CLEAR_CLS: Record<Clear, string> = { cleared: 'ok', pending: 'warm', missing: 'peach' };
export function clearOf(isCleared: boolean, missing: string[]): Clear { if (isCleared) return 'cleared'; return missing.some(m => /clearance|h&p|consent/i.test(m)) ? 'missing' : 'pending'; }
/** where the "Now" marker goes: index of first case whose start minute is after now (cases sorted by time). */
export const nowIndex = (mins: number[], now: number) => { const i = mins.findIndex(m => m > now); return i < 0 ? mins.length : i; };
export const lateStart = (loc: LocLite, start: number, now: number) => loc === 'scheduled' && now > start + 10;
