/* ASC.Vityls v8.9 · storage: the ONE fee schedule (drives invoices AND the check-in balance), patient credits, extended patient profile,
 * billing configuration, claim notes. Henry: fee_schedule(+fee_item), patient_credit(+credit_application), patient_profile, billing_config. Fictional data. */
import { repo } from '../../v6/dataLayer';
import { svRead, svWrite } from '../store';
import { uid } from '../../med/record';
import * as A from '../asc8/logic';
import * as P from './pure89';
const bump = () => window.dispatchEvent(new Event('vityls-med-updated'));
const aud = (cid: string, by: string, role: string, detail: string, action: string) => repo.audit({ caseId: cid ? (cid.startsWith('asc8:') || cid === 'practice' ? cid : `asc8:${cid}`) : 'practice', user: by, role, action: action as any, detail });

/* fee schedule (migrates the v8.8 itemized list on first read) */
export function schedule(): P.FeeSchedule {
  const s = svRead<P.FeeSchedule | null>('asc89-schedule', null); if (s) return s;
  const old = svRead<any[] | null>('asc88-fees', null); if (!old) return P.SCHEDULE_SEED;
  const items = old.filter(f => f.cat !== 'Facility fee' && f.cat !== 'Anesthesia').map(f => ({ id: f.id, cat: f.cat, label: f.label, amount: f.amount, procedure: f.procedure, active: f.active }));
  return { ...P.SCHEDULE_SEED, items: items.length ? items : P.SCHEDULE_SEED.items };
}
export function saveSchedule(s: P.FeeSchedule, by: string, role: string, what: string) { svWrite('asc89-schedule', s); aud('practice', by, role, `Fee schedule "${s.name}": ${what}`, 'asc89.fees'); bump(); }
/** Minutes for billing: recorded OR / anesthesia times when present, else the booked duration. */
export function billMinutes(c: A.AscCase): { orMin: number; anesMin: number; from: 'recorded' | 'booked' } {
  const e = c.events as Record<string, string | undefined>; const or = P.span(e.inRoom, e.outRoom); const an = P.span(e.anesStart, e.anesEnd);
  return { orMin: or || c.durationMin || 60, anesMin: an || or || c.durationMin || 60, from: or ? 'recorded' : 'booked' };
}
export function caseCharges(c: A.AscCase): { lines: P.Line[]; total: number } { const m = billMinutes(c); const lines = P.caseLines(schedule(), c.procedure, m.orMin, m.anesMin, m.from); return { lines, total: P.sum(lines) }; }

/* patient credits */
export const credits = (pid?: string) => svRead<P.Credit[]>('asc89-credits', []).filter(c => !pid || c.pid === pid);
const writeCredits = (l: P.Credit[]) => { const others = svRead<P.Credit[]>('asc89-credits', []).filter(x => !l.some(y => y.id === x.id)); svWrite('asc89-credits', [...others, ...l]); };
export function addCredit(x: Omit<P.Credit, 'id' | 'receipt' | 'applied' | 'at'>): P.Credit {
  if (!(x.amount > 0)) throw new Error('Enter an amount.');
  const c: P.Credit = { ...x, amount: P.r2(x.amount), id: uid('cr'), receipt: `CR-${Date.now().toString(36).toUpperCase()}`, applied: [], at: new Date().toISOString() };
  writeCredits([c]); const led = svRead<any[]>('patient-payments', []);
  svWrite('patient-payments', [{ id: c.id, receipt: c.receipt, patientId: c.pid, amount: c.amount, method: /card/i.test(c.method) ? 'card' : /cash/i.test(c.method) ? 'cash' : /check/i.test(c.method) ? 'check' : 'other', reference: c.ref || c.method, reason: `${c.type} · unapplied patient credit`, takenBy: c.by, role: c.role, at: c.at, channel: 'in person', applied: [], status: 'posted' }, ...led]);
  aud(`pt:${c.pid}`, c.by, c.role, `Patient credit recorded $${c.amount.toFixed(2)} · ${c.type} · ${c.method}${c.ref ? ` · ref ${c.ref}` : ''} · receipt ${c.receipt} (simulated)`, 'asc89.credit'); bump(); return c;
}
export const availableCredit = (pid: string) => P.available(credits(pid));
export const creditApplied = (cid: string) => P.appliedTo(credits(), cid);
/** Apply available credit to a case before its balance is calculated (oldest credit first). */
export function applyCreditTo(cid: string, pid: string, need: number, by: string, role: string): number {
  const r = P.applyCredits(credits(pid), cid, need, new Date().toISOString()); if (r.applied <= 0) return 0;
  writeCredits(r.credits); aud(cid, by, role, `Account credit applied $${r.applied.toFixed(2)} to this case's invoice`, 'asc89.credit-applied'); bump(); return r.applied;
}

/* extended patient profile (fields the core record does not hold) */
export interface Ins { payer: string; memberId: string; group: string; auth: string; holder: string }
export interface Emerg { name: string; rel: string; phone: string; note: string }
export interface Profile { preferredName: string; address: string; city: string; state: string; zip: string; ssn: string; maritalStatus: string; occupation: string; primary: Ins; secondary: Ins; emergency: Emerg[]; payType: string; interpreter: string; pcp: string; referring: string }
const EI: Ins = { payer: '', memberId: '', group: '', auth: '', holder: '' };
export const EMPTY_PROFILE: Profile = { preferredName: '', address: '', city: '', state: '', zip: '', ssn: '', maritalStatus: '', occupation: '', primary: { ...EI }, secondary: { ...EI }, emergency: [{ name: '', rel: '', phone: '', note: '' }, { name: '', rel: '', phone: '', note: '' }], payType: '', interpreter: '', pcp: '', referring: '' };
export const profile = (pid: string): Profile => { const p = svRead<Record<string, Partial<Profile>>>('asc89-profile', {})[pid] || {}; return { ...EMPTY_PROFILE, ...p, primary: { ...EI, ...(p.primary || {}) }, secondary: { ...EI, ...(p.secondary || {}) }, emergency: p.emergency?.length ? p.emergency : EMPTY_PROFILE.emergency }; };
export function saveProfile(pid: string, p: Profile, changed: string[], by: string, role: string) { const all = svRead<Record<string, Profile>>('asc89-profile', {}); svWrite('asc89-profile', { ...all, [pid]: p }); aud(`pt:${pid}`, by, role, `Profile updated: ${changed.join(', ') || 'no field changes'}`, 'asc89.profile'); bump(); }

/* billing configuration (simulated settings) + claim notes */
export const billCfg = () => svRead<Record<string, Record<string, string | boolean>>>('asc89-billcfg', {});
export function saveBillCfg(tab: string, v: Record<string, string | boolean>, by: string, role: string) { svWrite('asc89-billcfg', { ...billCfg(), [tab]: v }); aud('practice', by, role, `Billing configuration saved: ${tab}`, 'asc89.billcfg'); bump(); }
export interface Claim { cid: string; status: 'Not submitted' | 'Pending clearinghouse' | 'Unpaid' | 'Paid' | 'Denied'; ch: string; internal: string; paid: number; scrubbed?: string }
export const claims = () => svRead<Record<string, Claim>>('asc89-claims', {});
export function saveClaim(c: Claim, by: string, role: string, what: string) { svWrite('asc89-claims', { ...claims(), [c.cid]: c }); aud(c.cid, by, role, `Claim: ${what}`, 'asc89.claim'); bump(); }
export const ORDER_LOG = (cid: string, by: string, role: string, what: string) => aud(cid, by, role, what, 'asc89.or-times');
