/* ASC.Vityls v8.9 · pure logic (unit-tested): ONE fee schedule (v7.7 time-based facility/anesthesia + surgeon flat + v8.8 itemized extras),
 * patient credits (deposits applied before balance), OR event tiles, document categories, billing period / aging maths, SSN masking. Fictional data. */
export interface TimeFee { base: number; includedMin: number; perInc: number; incMin: number }
export interface FeeItem { id: string; cat: 'Facility fee' | 'Anesthesia' | 'Implants' | 'Supplies' | 'Pathology' | 'Other'; label: string; amount: number; procedure?: string; active: boolean }
export interface FeeSchedule { name: string; facility: TimeFee; anesthesia: TimeFee; surgeonFlat: number; items: FeeItem[]; insuredSharePct: number }
export const FEE_CATS: FeeItem['cat'][] = ['Implants', 'Supplies', 'Pathology', 'Other', 'Facility fee', 'Anesthesia'];
export const SCHEDULE_SEED: FeeSchedule = { name: 'Standard cash-pay', facility: { base: 1500, includedMin: 60, perInc: 250, incMin: 15 }, anesthesia: { base: 600, includedMin: 30, perInc: 125, incMin: 15 }, surgeonFlat: 0, insuredSharePct: 20,
  items: [
    { id: 'i1', cat: 'Implants', label: 'Breast implants (pair)', amount: 2400, procedure: 'breast (augmentation|implant)', active: true },
    { id: 'i2', cat: 'Implants', label: 'Hernia mesh', amount: 350, procedure: 'hernia', active: true },
    { id: 'i3', cat: 'Supplies', label: 'Surgical supplies & dressings', amount: 250, active: true },
    { id: 'i4', cat: 'Pathology', label: 'Pathology specimen', amount: 180, procedure: 'excision|lipoma|cholecystectomy', active: true },
    { id: 'i5', cat: 'Other', label: 'Post-op garment', amount: 120, procedure: 'abdominoplasty|lipo|breast', active: true }] };
/** Time-based fee: base covers the first N minutes, then per increment (rounded up). */
export function timeFee(f: TimeFee, minutes: number): { base: number; incs: number; extra: number; total: number } {
  const incs = f.incMin > 0 ? Math.max(0, Math.ceil((minutes - f.includedMin) / f.incMin)) : 0; const extra = incs * f.perInc; return { base: f.base, incs, extra, total: f.base + extra };
}
export const fmtTF = (f: TimeFee) => [60, 90, 120].map(m => `${m} min → $${timeFee(f, m).total.toLocaleString('en-US')}`).join(' · ');
export interface Line { label: string; detail: string; amount: number; kind?: 'fee' | 'credit' }
/** Every charge for a case from the single schedule. orMin = in-room→out-of-room (else booked); anesMin = anesthesia start→end (else booked). */
export function caseLines(s: FeeSchedule, procedure: string, orMin: number, anesMin: number, timesFrom: 'recorded' | 'booked' = 'booked'): Line[] {
  const f = timeFee(s.facility, orMin), a = timeFee(s.anesthesia, anesMin); const src = timesFrom === 'recorded' ? 'recorded OR times' : 'booked time';
  const out: Line[] = [{ label: 'Facility fee', detail: `Base · includes first ${s.facility.includedMin} min`, amount: f.base }];
  if (f.incs) out.push({ label: 'Facility fee', detail: `OR time ${orMin} min (${src}) · ${f.incs} × ${s.facility.incMin} min @ $${s.facility.perInc}`, amount: f.extra });
  out.push({ label: 'Anesthesia', detail: `Base · includes first ${s.anesthesia.includedMin} min`, amount: a.base });
  if (a.incs) out.push({ label: 'Anesthesia', detail: `Anesthesia time ${anesMin} min (${src}) · ${a.incs} × ${s.anesthesia.incMin} min @ $${s.anesthesia.perInc}`, amount: a.extra });
  if (s.surgeonFlat > 0) out.push({ label: 'Surgeon fee', detail: 'Flat surgeon fee', amount: s.surgeonFlat });
  for (const i of s.items.filter(x => x.active)) { if (i.procedure && !safeRe(i.procedure).test(procedure)) continue; out.push({ label: i.cat, detail: i.label, amount: i.amount }); }
  return out;
}
const safeRe = (p: string) => { try { return new RegExp(p, 'i'); } catch { return new RegExp(p.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'i'); } };
export const sum = (l: { amount: number }[]) => r2(l.reduce((n, x) => n + x.amount, 0));
export const r2 = (n: number) => Math.round(n * 100) / 100;
/** Patient responsibility: self-pay = full charges; insured = estimated share (coinsurance %). */
export const patientDue = (total: number, selfPay: boolean, pct: number) => r2(selfPay ? total : total * pct / 100);
export const isSelfPay = (t: string) => /self|cash|cosmetic|financ/i.test(t || '');

/* ---------- patient credit (deposits / account credit) ---------- */
export interface Credit { id: string; pid: string; amount: number; type: string; method: string; ref: string; notes: string; at: string; by: string; role: string; receipt: string; applied: { cid: string; amount: number; at: string }[] }
export const creditLeft = (c: Credit) => r2(c.amount - c.applied.reduce((n, a) => n + a.amount, 0));
export const available = (l: Credit[]) => r2(l.reduce((n, c) => n + creditLeft(c), 0));
export const appliedTo = (l: Credit[], cid: string) => r2(l.reduce((n, c) => n + c.applied.filter(a => a.cid === cid).reduce((m, a) => m + a.amount, 0), 0));
/** Apply oldest credit first up to `need`. Returns updated credits + amount applied. Never negative. */
export function applyCredits(l: Credit[], cid: string, need: number, at: string): { credits: Credit[]; applied: number } {
  let left = r2(Math.max(0, need)); let applied = 0;
  const credits = [...l].sort((a, b) => a.at.localeCompare(b.at)).map(c => { const can = Math.min(creditLeft(c), left); if (can <= 0) return c; left = r2(left - can); applied = r2(applied + can); return { ...c, applied: [...c.applied, { cid, amount: r2(can), at }] }; });
  return { credits, applied };
}
export const PAY_TYPES = ['Deposit / Account credit', 'Pre-payment for scheduled surgery', 'Copay / coinsurance on account', 'Other credit'];
export const METHODS = ['Credit card', 'Debit card', 'Cash', 'Check', 'HSA / FSA card'];
export const isCardMethod = (m: string) => /card/i.test(m);

/* ---------- OR event tiles ---------- */
export type OrKey = 'inRoom' | 'anesStart' | 'incision' | 'close' | 'anesEnd' | 'outRoom';
export const OR_TILES: { key: OrKey; label: string }[] = [{ key: 'inRoom', label: 'In room' }, { key: 'anesStart', label: 'Anesthesia start' }, { key: 'incision', label: 'Incision' }, { key: 'close', label: 'Closure' }, { key: 'anesEnd', label: 'Anesthesia end' }, { key: 'outRoom', label: 'Out of room' }];
export const toMin = (t: string) => { const m = /^(\d{1,2}):(\d{2})\s*(AM|PM)?$/i.exec((t || '').trim()); if (!m) return NaN; let h = +m[1]; const ap = m[3]?.toUpperCase(); if (ap === 'PM' && h < 12) h += 12; if (ap === 'AM' && h === 12) h = 0; return h * 60 + +m[2]; };
export const span = (a?: string, b?: string) => { if (!a || !b) return 0; const x = toMin(a), y = toMin(b); return isNaN(x) || isNaN(y) ? 0 : Math.max(0, y - x); };
/** Order warnings only (never blocks). */
export function orderWarnings(ev: Partial<Record<OrKey, string>>): string[] { const w: string[] = []; for (let i = 1; i < OR_TILES.length; i++) { const a = ev[OR_TILES[i - 1].key], b = ev[OR_TILES[i].key]; if (a && b && toMin(b) < toMin(a)) w.push(`${OR_TILES[i].label} is before ${OR_TILES[i - 1].label}`); } return w; }
export const to24 = (t: string) => { const m = toMin(t); return isNaN(m) ? '' : `${String(Math.floor(m / 60)).padStart(2, '0')}:${String(m % 60).padStart(2, '0')}`; };

/* ---------- documents ---------- */
export type DocCat = 'Pre-op Clearance' | 'Nursing' | 'Anesthesia' | 'OP Reports' | 'Other';
export const DOC_CATS: DocCat[] = ['Pre-op Clearance', 'Nursing', 'Anesthesia', 'OP Reports', 'Other'];
export function docCategory(d: { group: string; title: string; cat?: string }): DocCat {
  if (d.cat && (DOC_CATS as string[]).includes(d.cat)) return d.cat as DocCat; const t = `${d.group} ${d.title}`;
  if (/operative report|op report|op note|brief op|surgeon post-op|implant log/i.test(t)) return 'OP Reports';
  if (/anesth|asa\b|induction|airway|pacu orders/i.test(t)) return 'Anesthesia';
  if (/clearance|h&p|history|lab|ecg|ekg|imaging|incoming records|surgeon office/i.test(t)) return 'Pre-op Clearance';
  if (/nurs|pacu|discharge|vital|admission checklist|flowsheet|pre-op rn/i.test(t)) return 'Nursing';
  return 'Other';
}
export const UPLOAD_CAT: Record<string, DocCat> = { 'Pre-op H&P': 'Pre-op Clearance', 'Medical clearance': 'Pre-op Clearance', 'Lab results': 'Pre-op Clearance', 'ECG': 'Pre-op Clearance', 'Imaging report': 'Pre-op Clearance', 'Surgeon office records': 'Pre-op Clearance',
  'Nursing note': 'Nursing', 'Anesthesia record': 'Anesthesia', 'Operative report': 'OP Reports' };

/* ---------- billing page maths ---------- */
export type Period = 'today' | 'month' | 'quarter' | 'ttm' | 'custom';
export function periodRange(p: Period, today: string, custom?: { from: string; to: string }): { from: string; to: string } {
  const d = new Date(today + 'T12:00:00Z'); const iso = (x: Date) => x.toISOString().slice(0, 10);
  if (p === 'today') return { from: today, to: today };
  if (p === 'month') return { from: today.slice(0, 8) + '01', to: today };
  if (p === 'quarter') { const q = Math.floor(d.getUTCMonth() / 3) * 3; return { from: iso(new Date(Date.UTC(d.getUTCFullYear(), q, 1, 12))), to: today }; }
  if (p === 'ttm') return { from: iso(new Date(Date.UTC(d.getUTCFullYear() - 1, d.getUTCMonth(), d.getUTCDate() + 1, 12))), to: today };
  return custom && custom.from && custom.to ? custom : { from: today, to: today };
}
export const inRange = (day: string, r: { from: string; to: string }) => day >= r.from && day <= r.to;
export const BUCKETS = ['0–30', '31–60', '61–90', '91–120', '120+'] as const;
export const bucket = (ageDays: number) => ageDays <= 30 ? '0–30' : ageDays <= 60 ? '31–60' : ageDays <= 90 ? '61–90' : ageDays <= 120 ? '91–120' : '120+';
export const payerGroup = (payType: string) => isSelfPay(payType) ? 'Self-pay & copays' : /medicare|medicaid/i.test(payType) ? 'Medicare / Medicaid' : 'Commercial';
export const maskSsn = (s?: string) => { const d = (s || '').replace(/\D/g, ''); return d.length >= 4 ? `***-**-${d.slice(-4)}` : ''; };
export const ageDays = (from: string, to: string) => Math.round((Date.parse(to + 'T12:00:00Z') - Date.parse(from + 'T12:00:00Z')) / 864e5);
