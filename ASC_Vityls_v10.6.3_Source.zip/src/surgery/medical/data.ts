/* Medical.Vityls v1.0: fictional internal medicine / family practice seed data (no real patients). Used only when
 * EDITION === 'MEDICAL'; Surgery.Vityls keeps its own seed. Type-only imports so this file has no import cycles. */
import type { VisitTypeDef, SurgicalModules } from '../store';
export const MEDICAL_PRACTICE = 'Bayside Family & Internal Medicine (fictional)';
export const MEDICAL_VISIT_TYPES: VisitTypeDef[] = [
  { id: 'vt-new', name: 'New patient visit', color: '#93C5FD', durationMin: 40, category: 'new', surgical: false, active: true },
  { id: 'vt-fu', name: 'Follow-up visit', color: '#86EFAC', durationMin: 20, category: 'follow-up', surgical: false, active: true },
  { id: 'vt-chronic', name: 'Chronic care visit', color: '#FCD34D', durationMin: 30, category: 'follow-up', surgical: false, active: true },
  { id: 'vt-annual', name: 'Annual wellness / physical', color: '#C4B5FD', durationMin: 40, category: 'other', surgical: false, active: true },
  { id: 'vt-sick', name: 'Same-day sick visit', color: '#FCA5A5', durationMin: 15, category: 'other', surgical: false, active: true },
  { id: 'vt-nurse', name: 'Nurse visit', color: '#6EE7B7', durationMin: 15, category: 'other', surgical: false, active: true },
  { id: 'vt-proc', name: 'Office treatment', color: '#F9A8D4', durationMin: 30, category: 'procedure', surgical: false, active: true },
];
/** Medical preset: every surgical / ASC module off. Risk awareness stays on and is labelled "Significant risk factors". */
export const MEDICAL_MODULES: SurgicalModules = { riskAwareness: true, networkAsc: false, blockTime: false, surgeryBooking: false, preopClearance: false, ambientScribe: true };
export const MEDICAL_VT_MAP: Record<string, string> = { 'visit-e': 'Chronic care visit', 'visit-m': 'New patient visit', 'visit-r': 'Follow-up visit', 'visit-p': 'Annual wellness / physical', 'visit-g': 'Same-day sick visit', 'visit-t': 'New patient visit', 'visit-e-next': 'Chronic care visit', 'visit-e-old': 'Chronic care visit', 'visit-r-old': 'New patient visit' };
export const MEDICAL_REASONS: Record<string, string> = {
  'visit-e-old': 'Diabetes and blood pressure check', 'visit-r-old': 'Establish care: atrial fibrillation, hypertension',
  'visit-e': 'Diabetes 3-month check, A1c and kidney labs', 'visit-m': 'New patient: fatigue, thyroid follow-up', 'visit-r': 'Blood pressure recheck after medication change',
  'visit-p': 'Annual physical and preventive screening', 'visit-g': 'Cough and sore throat for 4 days', 'visit-t': 'New patient: asthma, establish primary care', 'visit-e-next': 'Diabetes follow-up, review home BP log',
};
export const MEDICAL_FEES = [
  { id: 'fee-new', name: 'New patient visit', visitType: 'New patient visit', price: 180, code: '99204', active: true },
  { id: 'fee-fu', name: 'Follow-up visit', visitType: 'Follow-up visit', price: 110, code: '99213', active: true },
  { id: 'fee-chronic', name: 'Chronic care visit', visitType: 'Chronic care visit', price: 140, code: '99214', active: true },
  { id: 'fee-annual', name: 'Annual wellness / physical', visitType: 'Annual wellness / physical', price: 220, code: '99396', active: true },
  { id: 'fee-sick', name: 'Same-day sick visit', visitType: 'Same-day sick visit', price: 110, code: '99213', active: true },
  { id: 'fee-nurse', name: 'Nurse visit', visitType: 'Nurse visit', price: 45, code: '99211', active: true },
  { id: 'fee-proc', name: 'Office treatment', visitType: 'Office treatment', price: 150, code: '', active: true },
  { id: 'fee-labdraw', name: 'Lab draw (venipuncture)', price: 25, code: '36415', active: true },
  { id: 'fee-ecg', name: 'ECG, 12-lead with interpretation', price: 60, code: '93000', active: true },
  { id: 'fee-flu', name: 'Influenza vaccine (administration + vaccine)', price: 55, code: '90686', active: true },
  { id: 'fee-a1c', name: 'Point-of-care A1c', price: 30, code: '83036', active: true },
  { id: 'fee-spiro', name: 'Spirometry', price: 70, code: '94010', active: true },
  { id: 'fee-inject', name: 'Injection (administration)', price: 35, code: '96372', active: true },
  { id: 'fee-product', name: 'Product / supply (enter amount)', price: 0, code: '', active: true },
];
/** Diagnoses with plan items (treatments, orders, referrals): status 'performed' is shown as Completed, 'planned' as Planned. */
export interface MedDx { diagnosis: string; icd: string; plan: [string, 'planned' | 'performed', string?][] }
export const MEDICAL_DX_BY_NAME: Record<string, MedDx[]> = {
  'Ellen Testwood': [{ diagnosis: 'Type 2 diabetes mellitus without complications', icd: 'E11.9', plan: [['Metformin titration to 1000 mg twice daily', 'performed', '2026-04-10'], ['Hemoglobin A1c every 3 months', 'planned'], ['Referral to ophthalmology: diabetic eye exam', 'planned']] },
    { diagnosis: 'Essential hypertension', icd: 'I10', plan: [['Lisinopril 20 mg daily', 'performed', '2025-11-02'], ['Home blood pressure log, review in 4 weeks', 'planned']] },
    { diagnosis: 'Coronary artery disease, s/p stent', icd: 'I25.10', plan: [['Cardiology follow-up', 'performed', '2026-08-20']] }],
  'Marisol Sampleton': [{ diagnosis: 'Hypothyroidism', icd: 'E03.9', plan: [['TSH in 6 weeks after dose change', 'planned'], ['Levothyroxine 75 mcg daily', 'performed', '2026-08-14']] },
    { diagnosis: 'Tobacco use disorder', icd: 'F17.210', plan: [['Smoking cessation counseling', 'performed', '2026-10-01'], ['Nicotine replacement therapy', 'planned']] }],
  'Robert Fictus': [{ diagnosis: 'Essential hypertension', icd: 'I10', plan: [['Metoprolol dose adjustment', 'planned'], ['BP recheck in 2 weeks', 'planned']] },
    { diagnosis: 'Atrial fibrillation, persistent', icd: 'I48.19', plan: [['Apixaban 5 mg twice daily', 'performed', '2025-09-12'], ['Referral to cardiology (electrophysiology)', 'planned']] }],
  'Priya Demoshah': [{ diagnosis: 'Encounter for general adult exam', icd: 'Z00.00', plan: [['Cervical cancer screening', 'performed', '2026-07-14'], ['Fasting lipid panel', 'planned']] }],
  'Grace Placeholder': [{ diagnosis: 'Acute pharyngitis', icd: 'J02.9', plan: [['Rapid strep test', 'planned']] },
    { diagnosis: 'Hyperlipidemia', icd: 'E78.5', plan: [['Atorvastatin 20 mg nightly', 'performed', '2026-05-03'], ['Lipid panel in 3 months', 'planned']] }],
  'Tomas Exampleton': [{ diagnosis: 'Mild persistent asthma', icd: 'J45.30', plan: [['Inhaled corticosteroid controller', 'performed', '2026-06-18'], ['Spirometry', 'planned']] },
    { diagnosis: 'Hyperlipidemia', icd: 'E78.5', plan: [['Fasting lipid panel', 'planned']] }],
};
/** Extra fictional chronic-care diagnoses for the generated test patients (diabetes, HTN, COPD, CKD...). */
export const MEDICAL_DX_POOL: MedDx[] = [
  { diagnosis: 'Type 2 diabetes mellitus without complications', icd: 'E11.9', plan: [['Hemoglobin A1c every 3 months', 'planned'], ['Diabetes self-management education', 'planned']] },
  { diagnosis: 'Essential hypertension', icd: 'I10', plan: [['Start amlodipine 5 mg daily', 'planned']] },
  { diagnosis: 'Chronic obstructive pulmonary disease', icd: 'J44.9', plan: [['Spirometry', 'planned'], ['Pneumococcal vaccine', 'performed', '2026-03-02']] },
  { diagnosis: 'Chronic kidney disease, stage 3a', icd: 'N18.31', plan: [['Referral to nephrology', 'planned']] },
  { diagnosis: 'Major depressive disorder, single episode, mild', icd: 'F32.0', plan: [['Referral to behavioral health', 'performed', '2026-07-22']] },
  { diagnosis: 'Hyperlipidemia', icd: 'E78.5', plan: [['Lipid panel in 3 months', 'planned']] },
  { diagnosis: 'Obesity, BMI 30-34.9', icd: 'E66.9', plan: [['Nutrition counseling referral', 'planned']] },
  { diagnosis: 'Gastroesophageal reflux disease', icd: 'K21.9', plan: [['Omeprazole 20 mg daily', 'performed', '2026-05-15']] },
];
