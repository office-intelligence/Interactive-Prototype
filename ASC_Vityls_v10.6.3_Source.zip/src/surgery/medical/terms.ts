/*
 * Medical.Vityls v1.0 terminology layer.
 *
 * Medical.Vityls and Surgery.Vityls share one codebase (edition MEDICAL runs the Surgery code paths). Features that do
 * not exist in a medical office (ASC, block time, surgery booking...) are switched off explicitly (see medical/index.ts
 * and the `isMedical` checks). The remaining surgical WORDING is translated here, at the four places text leaves the app:
 *   1. the live DOM (text nodes + placeholder/title/aria-label/alt), including same-origin iframes (forms, previews);
 *   2. document.write (print windows); 3. pdf-lib drawText (schedule PDF, packets, quotes);
 *   4. document.title, alert/confirm/prompt.
 * Surgery.Vityls never loads this file's installer (it runs only when EDITION === 'MEDICAL').
 * User-entered text in inputs/textareas/contenteditable is never touched.
 */
import { PDFPage } from 'pdf-lib';

type Pair = [RegExp, string];
const P = (re: string, to: string, flags = 'g'): Pair => [new RegExp(re, flags), to];
/** Phrases kept verbatim (medical-history terms). Protected before the map runs, restored after. */
const KEEP = [/after surgery in \d{4}/g, /Past surgical history/g, /past surgical history/g, /Surgical history/g, /surgical history/g, /Past Surgical History/g, /PAST SURGICAL HISTORY/g, /SURGICAL HISTORY/g];
export const TERMS: Pair[] = [
  P('Surgery\\.Vityls', 'Medical.Vityls'), P('SURGERY\\.VITYLS', 'MEDICAL.VITYLS'), P('surgery\\.vityls', 'medical.vityls'),
  P('Surgeon\\s?/\\s?[Pp]hysician', 'Doctor'), P('surgeon\\s?/\\s?physician', 'doctor'), P('Physician\\s?/\\s?[Ss]urgeon', 'Doctor'),
  P('[Ss]urgical coordinators', 'Care coordinators'), P('[Ss]urgical coordinator', 'Care coordinator'), P('[Ss]urgery coordinator', 'Care coordinator'),
  P('Surgical risk factors', 'Significant risk factors'), P('surgical risk factors', 'significant risk factors'), P('SURGICAL RISK FACTORS', 'SIGNIFICANT RISK FACTORS'),
  P('Surgical risk', 'Significant risk'), P('surgical risk', 'significant risk'), P('SURGICAL RISK', 'SIGNIFICANT RISK'),
  P('Diagnosis\\s?&\\s?Procedures?', 'Diagnosis & Plan'), P('Diagnosis\\s?&\\s?procedures?', 'Diagnosis & plan'), P('DIAGNOSIS\\s?&\\s?PROCEDURES?', 'DIAGNOSIS & PLAN'),
  P('Diagnoses\\s?&\\s?[Pp]rocedures', 'Diagnoses & plans'), P('Diagnosis\\s?/\\s?[Pp]rocedure', 'Diagnosis / Plan'), P('DIAGNOSIS\\s?/\\s?PROCEDURE', 'DIAGNOSIS / PLAN'),
  P('Pre-op clearance packet for ASC', 'Referral packet to specialist'),
  P('Surgery centers?', 'Hospital or facility'), P('surgery centers?', 'hospital or facility'), P('Surgery scheduling', 'Scheduling'), P('surgery scheduling', 'scheduling'), P('Operative reports', 'Specialist and hospital reports'), P('operative reports', 'specialist and hospital reports'),
  P('Procedure performed', 'Completed'), P('procedure performed', 'completed'), P('Procedure not performed', 'Planned'),
  P('Planned / not performed', 'Planned'), P('Not performed', 'Planned'), P('not performed', 'planned'), P('NOT PERFORMED', 'PLANNED'),
  P('Performed', 'Completed'), P('performed', 'completed'), P('PERFORMED', 'COMPLETED'),
  P('Procedure / plan', 'Service / plan'), P('Procedure note', 'Treatment note'), P('procedure note', 'treatment note'), P('Office procedure', 'Office treatment'), P('[Pp]rocedure room', 'Treatment room'), P('Procedure_Consent', 'Treatment_Consent'), P('Procedure [Cc]onsent', 'Treatment Consent'),
  P('Procedures', 'Plan items'), P('procedures', 'plan items'), P('PROCEDURES', 'PLAN ITEMS'), P('Procedure', 'Plan item'), P('procedure', 'plan item'), P('PROCEDURE', 'PLAN ITEM'),
  P('Pre-surgical', 'New-problem'), P('pre-surgical', 'new-problem'), P('Pre-operative', 'Pre-visit'), P('pre-operative', 'pre-visit'), P('Post-operative', 'Follow-up'), P('post-operative', 'follow-up'),
  P('Postoperative', 'Follow-up'), P('postoperative', 'follow-up'), P('Preoperative', 'Pre-visit'), P('preoperative', 'pre-visit'), P('Perioperative', 'Treatment'), P('perioperative', 'treatment'),
  P('Operative', 'Treatment'), P('operative', 'treatment'),
  P('Pre-op clearance', 'Medical clearance'), P('pre-op clearance', 'medical clearance'), P('PRE-OP', 'PRE-VISIT'), P('Pre-op', 'Pre-visit'), P('pre-op', 'pre-visit'), P('Preop', 'Pre-visit'), P('preop', 'pre-visit'),
  P('POST-OP', 'FOLLOW-UP'), P('Post-op', 'Follow-up'), P('post-op', 'follow-up'), P('Postop', 'Follow-up'), P('postop', 'follow-up'),
  P('physician’s or surgeon’s', 'doctor’s'), P('surgeon’s or physician’s', 'doctor’s'), P('physician or surgeon', 'doctor'), P('surgeon or physician', 'doctor'), P('physician’s or doctor’s', 'doctor’s'),
  P('Surgeons', 'Doctors'), P('surgeons', 'doctors'), P('SURGEONS', 'DOCTORS'), P('Surgeon', 'Doctor'), P('surgeon', 'doctor'), P('SURGEON', 'DOCTOR'),
  P('Surgical', 'Clinical'), P('surgical', 'clinical'), P('SURGICAL', 'CLINICAL'),
  P('Surgeries', 'Treatments'), P('surgeries', 'treatments'), P('Surgery', 'Treatment'), P('surgery', 'treatment'), P('SURGERY', 'TREATMENT'),
  P('Plastic & Reconstructive Treatment', 'Internal Medicine'), P('Plastic Treatment', 'Family Medicine'),
  P('\\ba doctor\\b', 'a doctor'), P('\\ban Plan', 'a Plan'), P('\\ban plan', 'a plan'), P('\\bAn plan', 'A plan'), P('\\bA ASC', 'An ASC'),
];
export function medTerm(s: string): string {
  if (!s || !/urg|rocedur|ASC|perat|op\b|-op|Op\b|erform|Vityls/i.test(s)) return s;
  const saved: string[] = []; let out = s;
  KEEP.forEach(re => { out = out.replace(re, m => { saved.push(m); return `\u0000${saved.length - 1}\u0000`; }); });
  for (const [re, to] of TERMS) out = out.replace(re, to);
  return out.replace(/\u0000(\d+)\u0000/g, (_m, i) => saved[+i]);
}
const ATTRS = ['placeholder', 'title', 'aria-label', 'alt'];
const editable = (n: Node | null) => { for (let e = n instanceof Element ? n : n?.parentElement; e; e = e.parentElement) { const t = e.tagName; if (t === 'TEXTAREA' || t === 'SCRIPT' || t === 'STYLE' || (e as HTMLElement).isContentEditable || e.hasAttribute?.('data-no-terms')) return true; } return false; };
function fixText(n: Node) { if (editable(n)) return; const v = n.nodeValue || ''; const w = medTerm(v); if (w === v) return;
  // <option> without a value attribute: keep its original text as the value so controlled <select>s still match.
  const o = n.parentElement; if (o && o.tagName === 'OPTION' && !o.hasAttribute('value')) o.setAttribute('value', v);
  n.nodeValue = w; }
function fixEl(e: Element) {
  ATTRS.forEach(a => { const v = e.getAttribute(a); if (v) { const w = medTerm(v); if (w !== v) e.setAttribute(a, w); } });
  if (e.tagName === 'OPTION') { /* text node handled by walker */ }
  if (e.tagName === 'INPUT' && /^(button|submit)$/i.test((e as HTMLInputElement).type)) { const i = e as HTMLInputElement; const w = medTerm(i.value); if (w !== i.value) i.value = w; }
  if (e.tagName === 'IFRAME') hookFrame(e as HTMLIFrameElement);
}
function walk(root: Node) {
  if (root.nodeType === 3) { fixText(root); return; }
  if (root.nodeType !== 1 && root.nodeType !== 9 && root.nodeType !== 11) return;
  if (root.nodeType === 1) fixEl(root as Element);
  const d = (root as any).ownerDocument || root; const tw = (d as Document).createTreeWalker(root, 5 /* element|text */);
  for (let n = tw.nextNode(); n; n = tw.nextNode()) { if (n.nodeType === 3) fixText(n); else fixEl(n as Element); }
}
const observed = new WeakSet<Document>();
export function observeDoc(doc: Document) {
  if (!doc || observed.has(doc)) return; observed.add(doc);
  const go = () => { if (doc.body) walk(doc.body); if (doc.title) { const t = medTerm(doc.title); if (t !== doc.title) doc.title = t; } };
  go();
  new MutationObserver(ms => { for (const m of ms) {
    if (m.type === 'characterData') fixText(m.target);
    else if (m.type === 'attributes') fixEl(m.target as Element);
    else m.addedNodes.forEach(walk);
  } const t = medTerm(doc.title); if (t !== doc.title) doc.title = t; }).observe(doc.documentElement, { subtree: true, childList: true, characterData: true, attributes: true, attributeFilter: [...ATTRS, 'value'] });
}
function hookFrame(f: HTMLIFrameElement) {
  const tryIt = () => { try { const d = f.contentDocument; if (d && d.documentElement) observeDoc(d); } catch { /* cross-origin (blob PDF viewer): text comes from pdf-lib, already translated */ } };
  if (!(f as any).__terms) { (f as any).__terms = true; f.addEventListener('load', () => { tryIt(); }); }
  tryIt();
}
let installed = false;
export function installMedicalTerms() {
  if (installed) return; installed = true;
  // pdf-lib: every PDF the app draws (schedule print, records packets, quotes) goes through drawText.
  const dt = PDFPage.prototype.drawText; PDFPage.prototype.drawText = function (this: PDFPage, text: string, opts?: any) { return dt.call(this, medTerm(String(text ?? '')), opts); };
  // print windows and iframes written with document.write
  const w = Document.prototype.write; Document.prototype.write = function (this: Document, ...a: string[]) { const r = w.apply(this, a.map(x => medTerm(String(x)))); try { observeDoc(this); } catch { /* */ } return r; };
  const ow = window.open; window.open = function (...a: any[]) { const nw = (ow as any).apply(window, a) as Window | null; try { if (nw?.document) setTimeout(() => { try { observeDoc(nw.document); } catch { /* */ } }, 0); } catch { /* */ } return nw; } as any;
  // srcdoc iframes
  const sd = Object.getOwnPropertyDescriptor(HTMLIFrameElement.prototype, 'srcdoc');
  if (sd?.set) Object.defineProperty(HTMLIFrameElement.prototype, 'srcdoc', { ...sd, set(v: string) { sd.set!.call(this, medTerm(String(v))); hookFrame(this as HTMLIFrameElement); } });
  const al = window.alert, cf = window.confirm, pr = window.prompt;
  window.alert = (m?: any) => al.call(window, medTerm(String(m ?? ''))); window.confirm = (m?: any) => cf.call(window, medTerm(String(m ?? ''))); window.prompt = (m?: any, d?: any) => pr.call(window, medTerm(String(m ?? '')), d);
  const start = () => observeDoc(document);
  if (document.documentElement) start(); else document.addEventListener('DOMContentLoaded', start);
}
