/* Medical.Vityls v2.0 · fictional seed (no real patients): today's office, video and phone visits for the two doctors
 * (Sam Patel, MD and Dana Whitfield, MD, both fictional), doctor jots, one Nightingale draft, a lab to review, follow-up / referral /
 * refill to-dos (refills are drafts for the doctor; nothing is ordered), and flags to every team including Patient Coordinators. */
import { medRepo, MedPatient, MedVisit, isoDay, addDays } from '../../med/record';
import { svRead, svWrite, saveOrder } from '../store';
import { setFlowState } from '../flow/store';
import type { RoleFlag, RoleView, FlagTarget, Jot, ClinicalNote } from '../v17/logic';
const PATEL = 'Sam Patel, MD', WHIT = 'Dana Whitfield, MD';
export function ensureMed20Seed() {
  if (svRead<boolean>('med20-seeded', false)) return; const T = isoDay(); const iso = (h: string, d = 0) => new Date(`${addDays(T, d)}T${h}:00`).toISOString();
  svWrite('v17-notes-since', addDays(T, -1));
  const pt = (id: string, name: string, dob: string, sex: MedPatient['sex'], doc: string, extra: Partial<MedPatient> = {}) => { if (!medRepo.patient(id)) medRepo.savePatient({ id, name, dob, sex, phone: '(555) 020-' + id.slice(-4), email: name.toLowerCase().replace(' ', '.') + '@example.test', language: 'English', allergies: [], primaryProvider: doc, careTeam: [{ name: doc, role: 'Physician' }], insurance: 'Bayside Health Plan (fictional)', fictional: true, paymentType: 'Insurance', ...extra } as MedPatient); setFlowState(id, s => ({ ...s, since: '' })); };
  const visit = (v: Partial<MedVisit> & Pick<MedVisit, 'id' | 'patientId' | 'time' | 'visitType' | 'reason' | 'step' | 'provider'>) => { if (!medRepo.visit(v.id)) medRepo.saveVisit({ durationMin: 20, room: 'Exam 1', problemIds: [], createdAt: iso('07:30'), createdBy: 'Taylor Brooks', date: T, ...v } as MedVisit); };
  const jots: Jot[] = []; const jot = (vid: string, pid: string, by: string, text: string, h: string, voice = false) => jots.push({ id: `jot-${vid}-${h}`, visitId: vid, pid, text, voice, by, at: iso(h) });
  // Dr. Patel
  pt('MED-4101', 'Harold Brennan', '02/11/1958', 'Male', PATEL, { allergies: ['Penicillin'] } as any);
  if (!medRepo.problems('MED-4101').length) { medRepo.saveProblem({ id: 'pr-hb1', patientId: 'MED-4101', description: 'Type 2 diabetes', conditionType: 'other' as any, status: 'active', recordedAt: iso('08:30'), recordedBy: 'Morgan Avery, MA', source: 'Medical history' }, 'seed'); medRepo.saveProblem({ id: 'pr-hb2', patientId: 'MED-4101', description: 'Hypertension', conditionType: 'other' as any, status: 'active', recordedAt: iso('08:30'), recordedBy: 'Morgan Avery, MA', source: 'Medical history' }, 'seed'); }
  if (!medRepo.meds('MED-4101').length) { medRepo.saveMed({ id: 'md-hb1', patientId: 'MED-4101', name: 'Metformin', dose: '1000 mg', frequency: 'twice daily', status: 'active', problemIds: ['pr-hb1'], source: 'Medical history', recordedAt: iso('08:30'), recordedBy: 'Morgan Avery, MA' }, 'seed'); medRepo.saveMed({ id: 'md-hb2', patientId: 'MED-4101', name: 'Lisinopril', dose: '20 mg', frequency: 'daily', status: 'active', problemIds: ['pr-hb2'], source: 'Medical history', recordedAt: iso('08:30'), recordedBy: 'Morgan Avery, MA' }, 'seed'); }
  visit({ id: 'visit-m20-harold', patientId: 'MED-4101', time: '08:30 AM', visitType: 'Chronic care visit', reason: 'Diabetes and blood pressure 3-month check', step: 'complete', provider: PATEL });
  jot('visit-m20-harold', 'MED-4101', PATEL, 'A1c 7.4 (was 7.9). BP 138/84. Feet: monofilament intact.', '09:00'); jot('visit-m20-harold', 'MED-4101', PATEL, 'Continue metformin; recheck A1c 3 mo; eye exam referral', '09:02', true);
  pt('MED-4102', 'Alicia Moreno', '09/30/1984', 'Female', PATEL);
  visit({ id: 'visit-m20-alicia', patientId: 'MED-4102', time: '09:30 AM', visitType: 'Same-day sick visit', reason: 'Cough and fever for 3 days', step: 'checkout', room: 'Exam 2', provider: PATEL });
  jot('visit-m20-alicia', 'MED-4102', PATEL, 'T 100.9, crackles R base. Likely CAP. CXR if not better 48 h.', '09:50');
  svWrite('v17-notes', { ...svRead<Record<string, ClinicalNote>>('v17-notes', {}), 'visit-m20-alicia': { id: 'note-m20-alicia', visitId: 'visit-m20-alicia', pid: 'MED-4102', type: 'SOAP', stage: 'draft', text: 'SUBJECTIVE\nAlicia Moreno, 42-year-old female, cough and fever for 3 days.\n\nOBJECTIVE\nT 100.9. Crackles right base.\n\nASSESSMENT\n[doctor to complete]\n\nPLAN\n[doctor to complete]', authorId: PATEL, dictated: false, draftedBy: 'Nightingale', updatedAt: iso('09:55'), updatedBy: PATEL } });
  pt('MED-4103', 'Walter Kim', '06/18/1949', 'Male', PATEL);
  visit({ id: 'visit-m20-walter', patientId: 'MED-4103', time: '01:00 PM', visitType: 'Follow-up visit', reason: 'Video follow-up: home blood pressure log', step: 'scheduled', provider: PATEL, mode: 'video' } as any);
  // Dr. Whitfield
  pt('MED-4201', 'Priya Natarajan', '04/04/1990', 'Female', WHIT);
  visit({ id: 'visit-m20-priya', patientId: 'MED-4201', time: '09:00 AM', visitType: 'Annual wellness / physical', reason: 'Annual physical and preventive screening', step: 'complete', room: 'Exam 3', provider: WHIT });
  jot('visit-m20-priya', 'MED-4201', WHIT, 'Well. Pap due; lipids + TSH ordered by nurse protocol. Flu shot given.', '09:40');
  pt('MED-4202', 'Gerald Fox', '12/02/1962', 'Male', WHIT);
  visit({ id: 'visit-m20-gerald', patientId: 'MED-4202', time: '11:00 AM', visitType: 'Follow-up visit', reason: 'Phone visit: thyroid lab results', step: 'scheduled', provider: WHIT, mode: 'phone' } as any);
  pt('MED-4203', 'Rosa Delgado', '07/21/1975', 'Female', WHIT);
  visit({ id: 'visit-m20-rosa', patientId: 'MED-4203', time: '02:30 PM', visitType: 'New patient visit', reason: 'New patient: establish care, asthma', step: 'scheduled', room: 'Exam 4', provider: WHIT });
  svWrite('v17-jots', [...svRead<Jot[]>('v17-jots', []).filter(j => !/^jot-visit-m20/.test(j.id)), ...jots]);
  if (!medRepo.labs('MED-4202').length) medRepo.saveLab({ id: 'lab-m20-gerald-tsh', patientId: 'MED-4202', test: 'TSH', value: '6.8', valueNum: 6.8, unit: 'mIU/L', reportedRange: '0.4–4.5', collectedAt: iso('07:30', -2), enteredAt: iso('08:00'), enteredBy: 'Lab interface (simulated)', source: 'Outside lab (fictional)', problemIds: [], status: 'awaiting-review' } as any);
  const O = (id: string, vid: string, pid: string, kind: 'follow-up' | 'other', text: string, detail: string, by: string) => saveOrder({ id, visitId: vid, patientId: pid, kind, text, detail, status: 'to-do', source: `Nightingale from ${by.replace(/,.*$/, '')}'s jots`, createdBy: 'Nightingale', createdAt: iso('10:00') }, 'Nightingale', 'Assistant', 'Seed');
  O('ord-m20-1', 'visit-m20-harold', 'MED-4101', 'follow-up', 'Chronic care visit in 3 months with A1c', 'Book with Dr. Patel', PATEL);
  O('ord-m20-2', 'visit-m20-harold', 'MED-4101', 'other', 'Referral: diabetic eye exam (ophthalmology)', 'Send records + last A1c', PATEL);
  O('ord-m20-3', 'visit-m20-harold', 'MED-4101', 'other', 'Refill: Lisinopril 20 mg daily, 90 days', 'Drafted by Nightingale for the doctor to review. Not sent.', PATEL);
  O('ord-m20-4', 'visit-m20-priya', 'MED-4201', 'follow-up', 'Annual physical in 1 year', 'Book with Dr. Whitfield', WHIT);
  const F = (id: string, from: string, fromRole: RoleView, to: FlagTarget, pid: string, text: string, h: string, ans?: [string, string]) => ({ id, from, fromRole, to, pid, text, at: iso(h), status: ans ? 'answered' : 'open', ...(ans ? { reply: ans[1], repliedBy: ans[0], repliedAt: iso('10:40') } : {}) }) as RoleFlag;
  svWrite('v17-flags', [
    F('flag-m20-1', PATEL, 'doctor', 'clinical', 'MED-4102', 'Please call Alicia tomorrow to check her fever.', '10:05'),
    F('flag-m20-2', 'Casey Morgan', 'clinical', 'front', 'MED-4203', 'Rosa should bring her inhalers and last spirometry to her 2:30 visit.', '09:40'),
    F('flag-m20-3', WHIT, 'doctor', 'ma', 'MED-4203', 'Please room Rosa with a peak flow before I come in.', '09:15'),
    F('flag-m20-4', PATEL, 'doctor', 'coord', 'MED-4101', 'Harold needs the eye-exam referral coordinated with his insurance.', '09:10'),
    F('flag-m20-5', 'Taylor Brooks', 'front', 'pm', '', 'Two phone lines down this morning — can we add a temp line?', '08:50'),
    F('flag-m20-6', PATEL, 'doctor', 'front', 'MED-4101', 'Book Harold a 3-month chronic care visit.', '09:05', ['Taylor Brooks', 'Booked for 3 months out, 9:00 AM — confirmed by text.']),
  ]);
  svWrite('med20-seeded', true);
}
