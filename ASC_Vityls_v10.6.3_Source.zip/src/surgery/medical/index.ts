/* Medical.Vityls v1.0: edition hooks (terminology layer + seed overrides). Only used when EDITION === 'MEDICAL'. */
import { installMedicalTerms } from './terms';
export { installMedicalTerms };
export const MEDICAL_SEED_VERSION = 'medical-v1.0';

/** Phrases in the shared fictional seed (written for a plastic-surgery office) rewritten for a primary-care office.
 *  Applied once to the seeded data in the Medical namespace only. Longest phrases first. */
const SEED_MAP: [RegExp, string][] = ([
  ['Coastline Plastic Surgery \\(fictional\\)', 'Bayside Family & Internal Medicine (fictional)'], ['Coastline Plastic Surgery', 'Bayside Family & Internal Medicine'],
  ['Plastic & Reconstructive Surgery', 'Internal Medicine'], ['Plastic Surgery', 'Family Medicine'], ['Aesthetic medicine', 'Family nurse practitioner'],
  ['Mom has her eyelid surgery coming up\\. Does she need to do anything about her Plavix or her weekly Ozempic shot beforehand\\?', 'Mom\'s sugars have been running high in the evenings. Should she change anything about her weekly Ozempic shot before her next visit?'],
  ['Dermatochalasis, upper lids \\(surgical problem\\)', 'Diabetic retinopathy screening due'],
  ['Patient reports upper eyelid heaviness\\. Daughter present\\.', 'Here for diabetes and blood pressure follow-up. Daughter present. Home sugars 120-160.'],
  ['Dermatochalasis, upper lids\\.', 'Type 2 diabetes, fair control; hypertension, controlled.'],
  ['Discussed upper blepharoplasty\\. Visual field testing ordered\\. Will coordinate with cardiology about clopidogrel; surgeon to decide\\.', 'Continue metformin and semaglutide. A1c and kidney labs in 3 months. Diabetic eye exam referral. Continue clopidogrel per cardiology.'],
  ['Interested in facelift / necklift\\.', 'Establishing care. Palpitations controlled.'],
  ['Facial aging; on apixaban for atrial fibrillation\\.', 'Atrial fibrillation on apixaban; hypertension.'],
  ['Booked at network ASC\\. Anticoagulation plan to be coordinated with cardiology; surgeon to decide\\.', 'Continue apixaban and metoprolol. Cardiology referral. Recheck BP in 2 weeks.'],
  ['Bring your home blood pressure log to the pre-surgical visit\\.', 'Bring your home blood pressure log to your next visit.'],
  ['Keep using CPAP every night, including after surgery\\.', 'Keep using CPAP every night.'],
  ['Do not stop on your own; your surgeon and cardiologist will tell you what to do before surgery\\.', 'Do not stop on your own; ask your doctor or cardiologist first.'],
  ['Ask the office before surgery about when to take it\\.', 'Take it on the same day each week.'],
  ['Surgical records for the booked procedure', 'Records for continuity of care'],
  ['Harborview Surgery Center \\(fictional network ASC\\)', 'outside hospital (fictional)'], ['Bayview Surgery Center', 'outside hospital (fictional)'], ['Harborview Surgery Center', 'outside hospital (fictional)'],
  ['Bilateral upper blepharoplasty', 'Diabetic eye exam'], ['Upper blepharoplasty', 'Diabetes follow-up'], ['upper blepharoplasty', 'diabetes follow-up'], ['blepharoplasty', 'diabetes follow-up'], ['Blepharoplasty', 'Diabetes follow-up'],
  ['Facelift / necklift, post-op day 8', 'Blood pressure recheck'], ['Facelift / necklift', 'Hypertension follow-up'], ['facelift / necklift', 'hypertension follow-up'], ['facelift', 'hypertension follow-up'], ['Facelift', 'Hypertension follow-up'],
  ['Neuromodulator, forehead and glabella', 'Annual physical'], ['Neuromodulator injection', 'Annual physical'], ['neuromodulator', 'vaccine'], ['Neuromodulator', 'Vaccine'],
  ['Abdominoplasty', 'Thyroid follow-up'], ['abdominoplasty', 'thyroid follow-up'], ['Rhinoplasty', 'Asthma follow-up'], ['rhinoplasty', 'asthma follow-up'],
  ['Reduction mammaplasty', 'Mammogram'], ['Breast augmentation \\(network-only patient\\)', 'Outside referral'], ['Breast augmentation', 'Mammogram'],
  ['Mohs reconstruction, local flap', 'Dermatology referral'], ['Spot on left cheek', 'Cough and sore throat'],
  ['Injectables / filler visit', 'Office treatment'], ['Injectables / filler', 'Office treatment'], ['Cosmetic consultation', 'New patient visit'], ['cosmetic', 'preventive'], ['Cosmetic', 'Preventive'],
  ['Compression garment \\(supply\\)', 'Blood pressure cuff (supply)'], ['eyelid photos', 'home BP log'], ['eyelid', 'eye'], ['Eyelid', 'Eye'],
  ['Before / after', 'Clinical'],
] as [string, string][]).map(([a, b]) => [new RegExp(a, 'g'), b]);
export const medSeedText = (s: string) => SEED_MAP.reduce((t, [re, to]) => t.replace(re, to), s);

/** Run after every Surgery seed hook: rewrites the seeded data for a primary-care office. */
export function seedMedicalOverrides() {
  try {
    localStorage.setItem('vityls:med:network-seed', '[]');
    const keys: string[] = []; for (let i = 0; i < localStorage.length; i++) { const k = localStorage.key(i); if (k) keys.push(k); }
    keys.forEach(k => { const v = localStorage.getItem(k); if (!v || v.length > 2_000_000 || /^data:/.test(v)) return; const w = medSeedText(v); if (w !== v) localStorage.setItem(k, w); });
  } catch (e) { console.warn('Medical seed override failed', e); }
}
