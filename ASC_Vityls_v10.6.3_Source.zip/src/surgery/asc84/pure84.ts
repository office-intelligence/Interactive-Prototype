/* v8.4 pure helpers (node:test). */
export const LENGTHS84 = [15, 30, 45, 60, 75, 90, 105, 120, 150, 180, 210, 240, 300, 360];
export const lenLabel84 = (m: number) => m < 60 ? `${m} Minutes (${(m / 60).toFixed(2).replace(/0$/, '')} Hrs)` : `${(m / 60).toFixed(m % 30 ? 2 : 1).replace(/(\.\d)0$/, '$1')} Hour${m === 60 ? '' : 's'} (${m} Mins)`;
export function billingChip(payType: string, money?: { due: number; paid: number; balance: number; status: string }): { text: string; cls: string } {
  const t = payType || 'Payment type not set'; if (!money || money.status === 'none') return { text: `${t} · No invoice`, cls: 'none' };
  if (money.status === 'paid') return { text: `${t} · Paid`, cls: 'paid' }; return { text: `${t} · $${money.balance.toFixed(2)} due`, cls: money.status }; }
const iso = (x: Date) => `${x.getFullYear()}-${String(x.getMonth() + 1).padStart(2, '0')}-${String(x.getDate()).padStart(2, '0')}`;
/** Day cards for the block-time popup: n days from the Monday of `day`. */
export function blockDays(day: string, n = 14) { const x = new Date(day + 'T12:00:00'); x.setDate(x.getDate() - ((x.getDay() + 6) % 7));
  return Array.from({ length: n }, (_, i) => { const y = new Date(x); y.setDate(x.getDate() + i); return { iso: iso(y), dow: y.toLocaleDateString('en-US', { weekday: 'short' }), dom: y.getDate(), mon: y.toLocaleDateString('en-US', { month: 'short' }), weekday: y.getDay() > 0 && y.getDay() < 6 }; }); }
export const blockTotal = (days: number, rooms: number) => days * rooms;
/* ---- workflow never blocks: per-station status for the station chips ---- */
export type StStatus = 'not-started' | 'in-progress' | 'done' | 'exceptions';
export function stationStatus(total: number, done: number, exceptions: number, passed: boolean): StStatus {
  if (exceptions) return 'exceptions'; if (total > 0 && done >= total) return 'done'; if (passed) return done < total ? 'exceptions' : 'done'; return done > 0 ? 'in-progress' : 'not-started'; }
export const ST_LABEL: Record<StStatus, string> = { 'not-started': 'Not started', 'in-progress': 'In progress', done: 'Done', exceptions: 'Exceptions' };
