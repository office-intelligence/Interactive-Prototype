/* v8.4 · Every workstation for a patient, with status, one click away (Today rows). */
import React from 'react';
import * as A from '../asc8/logic';
import { openAsc } from '../asc8/ui';
import { openBench } from '../asc81/practice81';
import { STATION_COLOR } from '../asc81/icons81';
import { stationStatus, ST_LABEL, type StStatus } from './pure84';
type WS = { k: string; label: string; st: A.Station; until: A.Loc; exc: string[]; open: (c: A.AscCase) => void; keys?: (i: A.Item) => boolean };
const WS_COLOR: Record<string, { fg: string; bg: string }> = { front: STATION_COLOR.front, nursing: STATION_COLOR.preop, anesthesia: STATION_COLOR.anesthesia, surgeon: STATION_COLOR.surgeon, or: STATION_COLOR.or, pacu: STATION_COLOR.pacu, discharge: { fg: '#0369a1', bg: '#e0f2fe' } };
export const WSS: WS[] = [
  { k: 'front', label: 'Front desk', st: 'front', until: 'arrived', exc: ['checkin', 'arrived'], open: c => c.loc === 'scheduled' ? openAsc({ t: 'details', cid: c.id }) : openBench('arrival', c.id) },
  { k: 'nursing', label: 'Nursing', st: 'preop', until: 'or', exc: ['nursing', 'preop'], open: c => openBench('nursing', c.id) },
  { k: 'anesthesia', label: 'Anesthesia', st: 'anesthesia', until: 'or', exc: ['anesthesia'], open: c => openBench('anesthesia', c.id) },
  { k: 'surgeon', label: 'Surgeon', st: 'surgeon', until: 'pacu', exc: ['surgeon'], open: c => openBench('surgeon', c.id) },
  { k: 'or', label: 'OR', st: 'or', until: 'pacu', exc: ['or', 'pacu'], open: c => openAsc({ t: 'step', cid: c.id, station: 'or' }) },
  { k: 'pacu', label: 'PACU', st: 'pacu', until: 'discharged', exc: [], open: c => openBench('pacu', c.id), keys: i => i.step === 'pacu' && !['instructions', 'dischargeOrder'].includes(i.key) },
  { k: 'discharge', label: 'Discharge', st: 'pacu', until: 'discharged', exc: ['discharge', 'discharged'], open: c => openBench('discharge', c.id), keys: i => ['instructions', 'dischargeOrder'].includes(i.key) }];
export function wsStatus(c: A.AscCase, w: WS): { s: StStatus; exc: string[] } {
  const its = A.ITEMS.filter(i => w.keys ? w.keys(i) : i.station === w.st); const done = its.filter(i => A.isDone(c, i.key)).length;
  const exc = w.exc.flatMap(k => c.d.exceptions?.[k]?.items || []); const passed = A.atLeast(c.loc, w.until);
  return { s: stationStatus(its.length, done, exc.length, passed), exc };
}
export const StationChips: React.FC<{ c: A.AscCase }> = ({ c }) => <div className="a84-chips" data-testid="a84-ws-chips">{WSS.map(w => { const { s, exc } = wsStatus(c, w);
  return <button key={w.k} type="button" className={`a84-ws ${s}`} onClick={e => { e.stopPropagation(); w.open(c); }} title={`${w.label}: ${ST_LABEL[s]}${exc.length ? ` · ${exc.join('; ')}` : ''}`} data-testid={`a84-ws-${w.k}`} data-status={s} style={{ background: WS_COLOR[w.k].bg, color: WS_COLOR[w.k].fg, borderColor: WS_COLOR[w.k].bg }}><i className={`a88-dot ${s === 'not-started' ? 'red' : 'green'}`} aria-label={ST_LABEL[s]} />{w.label}</button>; })}</div>;
