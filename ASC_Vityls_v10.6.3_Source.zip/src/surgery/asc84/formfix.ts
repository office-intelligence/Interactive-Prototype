/* v8.4 · Encounter forms: fixed legal/consent statements are read-only (edit them in the form editor / Settings),
 * and every long text field shows in full (auto-height, no inner scroll bar). */
export const isFixedStatement = (templateText: string) => templateText.trim().length >= 60;
export function enhanceForm(host: HTMLElement | null) { const root = host?.shadowRoot; if (!root) return;
  if (!root.querySelector('style[data-a84]')) { const s = document.createElement('style'); s.setAttribute('data-a84', ''); s.textContent = `textarea{overflow:hidden!important;resize:none!important;max-height:none!important}textarea.a84-fixed{background:#f8fafc!important;border:1px solid #e2e8f0!important;color:#1f2937!important;cursor:default}.a84-fixed-note{display:block;font-size:11px;color:#64748b;margin:2px 0 6px}`; root.appendChild(s); }
  root.querySelectorAll('textarea').forEach(t => { const ta = t as HTMLTextAreaElement;
    if (!ta.dataset.a84 && isFixedStatement(ta.defaultValue)) { ta.readOnly = true; ta.classList.add('a84-fixed'); ta.setAttribute('aria-readonly', 'true'); ta.title = 'Fixed statement · edit it in Settings → Forms';
      if (ta.value.trim() !== ta.defaultValue.trim()) ta.value = ta.defaultValue; const n = document.createElement('span'); n.className = 'a84-fixed-note'; n.textContent = 'Fixed statement · not editable here (edit in Settings → Forms)'; ta.insertAdjacentElement('afterend', n);
      let par: HTMLElement | null = ta.parentElement; for (let up = 0; up < 2 && par; up++, par = par.parentElement) par.querySelectorAll('*').forEach(e => { if (!e.children.length && /\(editable\)/i.test(e.textContent || '')) e.textContent = (e.textContent || '').replace(/\(editable\)/i, '(fixed statement)'); }); }
    const fit = () => { if (!ta.offsetParent) return; ta.style.height = 'auto'; ta.style.height = `${ta.scrollHeight + 2}px`; };
    if (!ta.dataset.a84) { ta.addEventListener('input', fit); ta.dataset.a84 = '1'; } fit(); }); }
