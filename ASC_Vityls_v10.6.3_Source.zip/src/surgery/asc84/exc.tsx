import React from 'react';
/** v8.4 · light-yellow "missing, not blocking" box. */
export const ExcBox: React.FC<{ items: string[]; tid: string; note?: string; title?: string }> = ({ items, tid, note, title = 'Missing (not blocking)' }) => !items.length ? null :
  <div className="a84-exc" data-testid={tid} role="status"><b>⚠ {title} · {items.length}</b><ul>{items.map(i => <li key={i}>{i}</li>)}</ul>{note && <p>{note}</p>}</div>;
