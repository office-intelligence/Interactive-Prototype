/* v8.4 · Surgeon colors live in Practice settings (removed from the scheduler strip). */
import React, { useState } from 'react';
import { useActor } from '../../med/ui';
import { repo } from '../../v6/dataLayer';
import { svWrite } from '../store';
import { surgeonList, surgeonColor, surgeonColors, tint } from '../asc83/booking';
export const SurgeonColorSettings: React.FC = () => { const [actor] = useActor(); const [, f] = useState(0);
  return <section className="sv-sec mt-8" id="surgeon-colors" data-testid="a84-surgeon-colors"><h2 className="sv-title" style={{ fontSize: 20 }}>Surgeon colors on the schedule</h2><p className="sv-small sv-muted">Each surgeon’s cases are tinted in this color on the scheduler.</p>
    <div className="a84-colors">{surgeonList().map(s => <label key={s} className="a84-colorrow" style={{ background: tint(surgeonColor(s), 0.14), borderLeft: `5px solid ${surgeonColor(s)}` }}><span className="flex-1">{s}</span>
      <input type="color" value={surgeonColor(s)} aria-label={`Color for ${s}`} onChange={e => { svWrite('asc83-surgeon-colors', { ...surgeonColors(), [s]: e.target.value }); repo.audit({ caseId: 'practice', user: actor.name, role: actor.role, action: 'asc83.color' as any, detail: `Schedule color for ${s} → ${e.target.value}` }); f(x => x + 1); window.dispatchEvent(new Event('vityls-med-updated')); }} data-testid="a83-color-in" /></label>)}</div></section>; };
