/* Surgery.Vityls v1.6 · case seed (fictional): Mary James gets a closed rhinoplasty case (pre-op visits, phone and video calls, post-op
   calls over months), her current case becomes a facelift a year later, and a closed filler quick case. Other seeds are unchanged. */
import { medRepo, MedVisit, isoDay, addDays } from '../../med/record';
import { svRead, svWrite } from '../store';
import { episodes, MARY, episodeSettings } from '../episodes/store';
import * as EL from '../episodes/logic';
import { saveContactNote } from '../contactNotes';
import { seedCaseRow } from './store';
import { getSettings } from '../../med/settings';

export const MARY_RHINO = 'ep-mary-rhino', MARY_FILLER = 'case-mary-filler', MARY_FACE = 'ep-mary';
export function ensureCaseSeed() {
  if (svRead<boolean>('cases-seed-v16', false) || !medRepo.patient(MARY)) return;
  const T = isoDay(); const iso = (d: number, h = '10:00') => new Date(`${addDays(T, d)}T${h}:00`).toISOString(); const PATEL = 'Sam Patel, MD';
  // the current case is a facelift (a year after the rhinoplasty)
  const eps = episodes().map(e => e.id === MARY_FACE ? { ...e, procedure: 'Facelift / necklift', history: [...e.history] } : e);
  const cv = medRepo.visit(`ep-consult-${MARY}`); if (cv) medRepo.saveVisit({ ...cv, reason: 'Facelift consultation', caseId: MARY_FACE });
  const js = svRead<any[]>('journeys', []); if (js.length) svWrite('journeys', js.map(j => j.id === 'jy-mary' ? { ...j, service: 'Facelift / necklift' } : j));
  // closed rhinoplasty case, about a year earlier
  const s = episodeSettings(); const surg = addDays(T, -380);
  let r = EL.buildEpisode({ id: MARY_RHINO, patientId: MARY, procedure: 'Rhinoplasty (open)', surgeon: PATEL, ascName: getSettings().ascName || 'Harborview Surgery Center (fictional)', surgeryDate: surg, surgeryTime: '07:30 AM', bookedOn: addDays(T, -410), createdAt: iso(-410), createdBy: 'Riley Shaw', totalAmount: 9800, depositAmount: 2450, age: 54, conditions: ['hypertension', 'diabetes'], pcp: 'Elena Marsh, MD (fictional)' }, s);
  r.items.forEach(i => { if (EL.isOpen(i)) r = EL.setItem(r, i.key, 'done', 'Fictional seed', iso(-290)); }); r = { ...r, paid: 9800, closedAt: iso(-285), stage: 'closed' };
  svWrite('episodes', [...eps.filter(e => e.id !== MARY_RHINO), r]);
  seedCaseRow({ id: MARY_RHINO, patientId: MARY, procedure: r.procedure, kind: 'surgical', status: 'closed', openedAt: iso(-410), openedBy: 'Riley Shaw', closedAt: iso(-285), closedBy: 'Nightingale', closeReason: 'last post-op visit done (automatic)', episodeId: MARY_RHINO, source: 'seed',
    log: [{ at: iso(-410), by: 'Riley Shaw', role: 'Coordinator', what: 'Surgical case opened (doctor suggested): Rhinoplasty (open)' }, { at: iso(-380), by: 'Sam Patel, MD', role: 'Surgeon', what: `Surgery done at the ASC (${surg})` }, { at: iso(-285), by: 'Nightingale', role: 'Assistant', what: 'Case closed: last post-op visit done (automatic)' }] });
  const V = (id: string, d: number, time: string, visitType: string, reason: string, mode: 'office' | 'phone' | 'video', caseId: string, note?: string) => {
    if (medRepo.visit(id)) return; const v = { id, patientId: MARY, date: addDays(T, d), time, durationMin: mode === 'office' ? 30 : 15, provider: PATEL, room: mode === 'video' ? 'Video' : mode === 'phone' ? 'Phone' : 'Exam 1', visitType, reason, step: 'complete', problemIds: [], createdAt: iso(d - 7), createdBy: 'Front Desk Tester', caseId, ...(mode !== 'office' ? { mode } : {}) } as MedVisit;
    medRepo.saveVisit(v);
    if (note) medRepo.saveNote({ visitId: id, template: visitType, subjective: note, objective: '', assessment: '', plan: '', status: 'signed', updatedAt: iso(d, '12:00'), updatedBy: PATEL, signedBy: PATEL, signedAt: iso(d, '12:00'), addenda: [] }); };
  V('mj-r1', -425, '10:00 AM', 'Cosmetic consultation', 'Rhinoplasty consultation', 'office', MARY_RHINO, 'Dorsal hump and tip ptosis. Discussed open rhinoplasty. (Fictional)');
  V('mj-r2', -415, '04:30 PM', 'Phone Consult', 'Rhinoplasty questions: recovery time and cost', 'phone', MARY_RHINO);
  V('mj-r3', -400, '11:00 AM', 'Video Consult', 'Pre-op planning and photo review', 'video', MARY_RHINO);
  V('mj-r4', -388, '09:00 AM', 'Pre-surgical consult', 'Rhinoplasty pre-op visit, consents signed', 'office', MARY_RHINO, 'Pre-op visit. Consents reviewed and signed. (Fictional)');
  V('mj-r5', -379, '09:30 AM', 'Post-op follow-up', 'POD 1 · splint check', 'office', MARY_RHINO, 'POD 1: splint intact, no bleeding. (Fictional)');
  V('mj-r6', -373, '02:00 PM', 'Post-op follow-up', 'POD 7 · phone check-in', 'phone', MARY_RHINO);
  V('mj-r7', -350, '10:30 AM', 'Post-op follow-up', 'POD 30 · video check-in, photos', 'video', MARY_RHINO);
  V('mj-r8', -290, '09:00 AM', 'Post-op follow-up', 'POD 90 · final post-op visit', 'office', MARY_RHINO, 'POD 90: healed well; discharged from post-op care. (Fictional)');
  const call = (id: string, d: number, dir: 'Incoming' | 'Outgoing', reason: string, text: string) => saveContactNote({ id, patientId: MARY, channel: 'Phone', direction: dir, reason, text, author: 'Riley Shaw', authorRole: 'Coordinator', session: 'seed', contactAt: iso(d, '15:00'), at: iso(d, '15:05'), dictated: false, flagged: false } as any);
  call('cn-mj-r1', -409, 'Outgoing', 'Booking and deposit', 'Called to confirm the surgery date and the deposit. (Fictional)');
  call('cn-mj-r2', -366, 'Incoming', 'Swelling question', 'Asked about swelling after POD 7; reassured, cold compresses. (Fictional)');
  // closed filler quick case (one in-office visit)
  V('mj-f1', -200, '01:00 PM', 'Injectables / filler', 'Filler injections (nasolabial folds)', 'office', MARY_FILLER, 'Hyaluronic acid filler, nasolabial folds, 1 syringe each side. Tolerated well. (Fictional)');
  seedCaseRow({ id: MARY_FILLER, patientId: MARY, procedure: 'Filler injections', kind: 'office-procedure', status: 'closed', openedAt: iso(-206), openedBy: 'Front Desk Tester', closedAt: iso(-200, '13:45'), closedBy: 'Nightingale', closeReason: 'paid and procedure note signed (automatic)', source: 'new-appointment',
    quick: { visitId: 'mj-f1', price: 650, paidAt: iso(-200, '13:40'), paidBy: 'Front Desk Tester' },
    log: [{ at: iso(-206), by: 'Front Desk Tester', role: 'Front desk', what: 'Office procedure opened (new appointment): Filler injections' }, { at: iso(-200, '13:40'), by: 'Front Desk Tester', role: 'Front desk', what: 'Paid $650 (simulated)' }, { at: iso(-200, '13:45'), by: 'Nightingale', role: 'Assistant', what: 'Case closed: paid and procedure note signed (automatic)' }] });
  svWrite('cases-seed-v16', true);
}
