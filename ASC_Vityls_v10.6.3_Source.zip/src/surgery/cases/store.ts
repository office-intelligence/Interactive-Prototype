/*
 * Surgery.Vityls v1.6 · Surgical cases: browser-storage repository (swap point for Henry's API).
 * Tables: `cases` (one row per case; surgical cases share the Episode's id and keep quote/deposit/booking/clearance on the Episode)
 * and `case-links` (entity:id → caseId for calls, messages, documents, quotes, payments, forms, body charts and photos; visits also
 * carry `caseId` on the visit row, and a visit's note follows its visit). Every change is audited. Fictional data only.
 */
import { repo } from '../../v6/dataLayer';
import { medRepo, MedVisit, isoDay, patientKey, uid } from '../../med/record';
import { svRead, svWrite } from '../store';
import { episodes, episode, episodesFor } from '../episodes/store';
import { docsOf } from '../documents';
import { quotesFor, cur as curQuote } from '../quotes';
import { patientPayments } from '../payments';
import { photosOf, bodyCharts } from '../media';
import { formsPackets } from '../newPatient';
import { contactNotes } from '../contactNotes';
import { focusOf } from './focus';
import * as C from './logic';
export * from './logic';

const RK = 'cases', LK = 'case-links';
const recs = () => svRead<C.SurgicalCase[]>(RK, []);
const links = () => svRead<Record<string, C.CaseLink>>(LK, {});
function saveRec(c: C.SurgicalCase) { const l = recs(); const i = l.findIndex(x => x.id === c.id); if (i >= 0) l[i] = c; else l.push(c); svWrite(RK, l); }
const POSTOP = /post-?op/i;
const undecidedOf = (key: string) => { const s = svRead<Record<string, any>>('flow-state', {})[key]; return !!s?.undecided && !s?.resumed; };

/** A case with its live status (surgical cases follow their Episode until closed). */
function live(c: C.SurgicalCase, today = isoDay()): C.SurgicalCase {
  if (c.closedAt) return { ...c, status: 'closed' };
  if (c.kind === 'surgical' && c.episodeId) { const e = episode(c.episodeId); if (e) return { ...c, status: C.statusFromEpisode(e.stage, e.surgeryDate, today, undecidedOf(c.id)), closedAt: e.closedAt }; }
  if (c.kind === 'surgical') return { ...c, status: undecidedOf(c.id) ? 'undecided' : 'open' };
  return { ...c, status: 'open' };
}
export const allCases = (today = isoDay()) => recs().map(c => live(c, today));
export const casesFor = (pid: string, today = isoDay()) => recs().filter(c => c.patientId === pid).map(c => live(c, today)).sort((a, b) => b.openedAt.localeCompare(a.openedAt));
export const caseById = (id?: string) => { const c = id ? recs().find(x => x.id === id) : undefined; return c ? live(c) : undefined; };
export const openCases = (pid: string) => casesFor(pid).filter(C.isOpenCase);
/** The case the 7-step workflow follows: the focused one (staff opened it), else the newest open surgical case. */
export function primaryCase(pid: string): C.SurgicalCase | undefined {
  const l = openCases(pid).filter(c => c.kind === 'surgical'); const f = focusOf(pid);
  return (f && l.find(c => c.id === f)) || l[0];
}
/** Where a patient's workflow state lives: the primary case, or the patient until a case opens. */
export const flowKey = (pid: string, caseId?: string) => caseId || primaryCase(pid)?.id || pid;

/* ---------------- links ---------------- */
export const caseOfVisit = (v?: MedVisit) => !v ? C.GENERAL : v.caseId || links()[C.linkKey('visit', v.id)]?.caseId || C.GENERAL;
export function caseOf(entity: C.CaseEntity, id: string): string {
  if (entity === 'visit' || entity === 'note') return caseOfVisit(medRepo.visit(id));
  return links()[C.linkKey(entity, id)]?.caseId || C.GENERAL;
}
const nameOf = (id: string) => id === C.GENERAL ? 'General (not case-related)' : (caseById(id)?.procedure || id);
function logTo(caseId: string, e: C.CaseLogEntry) { const c = recs().find(x => x.id === caseId); if (c) saveRec({ ...c, log: [...c.log, e].slice(-200) }); }
/** Put an item in a case (one tap anywhere it shows). Audited on the patient and in both cases' logs. */
export function linkTo(entity: C.CaseEntity, id: string, pid: string, caseId: string, by: string, role: string, how: C.CaseLink['how'] = 'staff', quiet = false) {
  const r = C.reassign(links(), { entity, id, patientId: pid, caseId }, by, new Date().toISOString(), how);
  const from = entity === 'visit' ? caseOfVisit(medRepo.visit(id)) : r.from;
  svWrite(LK, r.links);
  if (entity === 'visit') { const v = medRepo.visit(id); if (v && v.caseId !== caseId) medRepo.saveVisit({ ...v, caseId }); }
  if (from === caseId || quiet) return false;
  const what = `${C.ENTITY_LABEL[entity]} ${id} moved from ${nameOf(from)} to ${nameOf(caseId)}`; const at = new Date().toISOString();
  repo.audit({ caseId: patientKey(pid), user: by, role, action: 'case.link' as any, detail: what });
  [from, caseId].filter(x => x !== C.GENERAL).forEach(c => logTo(c, { at, by, role, what }));
  return true;
}

/** Seed / import only: write a case row as given. */
export const seedCaseRow = (c: C.SurgicalCase) => saveRec(c);

/* ---------------- open / close ---------------- */
export function openCase(pid: string, x: { procedure: string; kind: C.CaseKind; source: C.SurgicalCase['source']; episodeId?: string; id?: string; openedAt?: string; quick?: C.QuickState }, by: string, role: string): C.SurgicalCase {
  const at = x.openedAt || new Date().toISOString(); const id = x.id || x.episodeId || uid('case');
  const ex = recs().find(c => c.id === id); if (ex) return live(ex);
  const firstSurgical = x.kind === 'surgical' && !openCases(pid).some(c => c.kind === 'surgical');
  const c: C.SurgicalCase = { id, patientId: pid, procedure: x.procedure, kind: x.kind, status: 'open', openedAt: at, openedBy: by, source: x.source, episodeId: x.episodeId, quick: x.quick, log: [{ at, by, role, what: `${C.KIND_LABEL[x.kind]} opened (${x.source.replace('-', ' ')}): ${x.procedure}` }] };
  saveRec(c);
  // the patient's workflow so far moves into their first surgical case (it was kept per patient until now)
  if (firstSurgical) { const fs = svRead<Record<string, any>>('flow-state', {}); if (fs[pid] && !fs[id]) { fs[id] = fs[pid]; svWrite('flow-state', fs); } }
  repo.audit({ caseId: patientKey(pid), user: by, role, action: 'case.open' as any, detail: `${C.KIND_LABEL[x.kind]} opened: ${x.procedure} (${id})` });
  return live(c);
}
export function closeCase(id: string, by: string, role: string, reason: string) {
  const c = recs().find(x => x.id === id); if (!c || c.closedAt) return; const at = new Date().toISOString();
  saveRec({ ...c, closedAt: at, closedBy: by, closeReason: reason, status: 'closed', log: [...c.log, { at, by, role, what: `Case closed: ${reason}` }] });
  repo.audit({ caseId: patientKey(c.patientId), user: by, role, action: 'case.close' as any, detail: `${c.procedure} closed: ${reason}` });
}
export function reopenCase(id: string, by: string, role: string) {
  const c = recs().find(x => x.id === id); if (!c?.closedAt) return; const at = new Date().toISOString();
  saveRec({ ...c, closedAt: undefined, closedBy: undefined, closeReason: undefined, status: 'open', log: [...c.log, { at, by, role, what: 'Case reopened' }] });
  repo.audit({ caseId: patientKey(c.patientId), user: by, role, action: 'case.reopen' as any, detail: `${c.procedure} reopened` });
}

/* ---------------- quick (office-procedure) case ---------------- */
export function quickFacts(c: C.SurgicalCase): C.QuickFacts {
  const v = c.quick?.visitId ? medRepo.visit(c.quick.visitId) : medRepo.visits(c.patientId).find(x => caseOfVisit(x) === c.id); const n = v ? medRepo.note(v.id) : undefined;
  const pay = c.quick?.paidAt ? { at: c.quick.paidAt, by: c.quick.paidBy } : (() => { const p = patientPayments(c.patientId).find(x => caseOf('payment', x.id) === c.id); return p ? { at: p.at, by: p.takenBy } : undefined; })();
  const arrived = v ? repo.getFacts(v.id)['visit.checkin'] || repo.getFacts(v.id)['visit.arrived'] : undefined;
  return { scheduledAt: v?.createdAt, visitStep: v?.step, checkedInAt: arrived?.value ? String((arrived as any).source?.at || '') : undefined, noteSigned: n?.status === 'signed' ? { at: n.signedAt || n.updatedAt, by: n.signedBy } : undefined, paid: pay, closedAt: c.closedAt };
}
export function markQuickPaid(id: string, by: string, role: string) {
  const c = recs().find(x => x.id === id); if (!c) return; const at = new Date().toISOString();
  saveRec({ ...c, quick: { ...(c.quick || {}), paidAt: at, paidBy: by }, log: [...c.log, { at, by, role, what: `Paid${c.quick?.price ? ` $${c.quick.price}` : ''} (simulated)` }] });
  repo.audit({ caseId: patientKey(c.patientId), user: by, role, action: 'case.paid' as any, detail: `${c.procedure}: paid (simulated)` }); syncCases();
}

/* ---------------- everything in a case (its timeline) ---------------- */
export interface CaseEvent { at: string; entity: C.CaseEntity | 'log'; id: string; caseId: string; title: string; sub?: string; visitId?: string }
export function eventsFor(pid: string): CaseEvent[] {
  const L = links(); const cOf = (e: C.CaseEntity, id: string) => L[C.linkKey(e, id)]?.caseId || C.GENERAL; const out: CaseEvent[] = [];
  medRepo.visits(pid).forEach(v => { const cid = caseOfVisit(v); const mode = (v as any).mode || 'office';
    out.push({ at: `${v.date}T${String(Math.floor(+toMin(v.time) / 60)).padStart(2, '0')}:${String(+toMin(v.time) % 60).padStart(2, '0')}`, entity: 'visit', id: v.id, caseId: cid, visitId: v.id, title: `${mode === 'phone' ? 'Phone call' : mode === 'video' ? 'Video visit' : 'Office visit'} · ${v.visitType}`, sub: `${v.reason || ''}${v.step === 'complete' ? ' · complete' : ''}` });
    const n = medRepo.note(v.id); if (n) out.push({ at: n.signedAt || n.updatedAt, entity: 'note', id: v.id, caseId: cid, visitId: v.id, title: `${n.template || 'Visit note'} ${n.status === 'signed' ? 'signed' : '(draft)'}`, sub: n.signedBy || n.updatedBy }); });
  contactNotes(pid).forEach(n => out.push({ at: n.contactAt, entity: /message|portal|text|email/i.test(n.channel) ? 'message' : 'call', id: n.id, caseId: cOf(/message|portal|text|email/i.test(n.channel) ? 'message' : 'call', n.id), title: `${n.channel} · ${n.direction}`, sub: n.reason || n.text.slice(0, 80) }));
  medRepo.messages(pid).forEach(m => out.push({ at: m.at, entity: 'message', id: m.id, caseId: cOf('message', m.id), title: `Portal message · ${m.author}`, sub: m.text.slice(0, 80) }));
  docsOf(pid).forEach(d => out.push({ at: d.receivedAt || d.docDate, entity: 'document', id: d.id, caseId: cOf('document', d.id), title: d.title, sub: d.type }));
  quotesFor(pid).forEach(q => out.push({ at: curQuote(q).createdAt, entity: 'quote', id: q.id, caseId: cOf('quote', q.id), title: `Quote ${q.number}`, sub: `${curQuote(q).procedure} · $${curQuote(q).total}` }));
  patientPayments(pid).forEach(p => out.push({ at: p.at, entity: 'payment', id: p.id, caseId: cOf('payment', p.id), title: `Payment $${p.amount}`, sub: p.reason }));
  formsPackets(pid).forEach(f => out.push({ at: f.sentAt, entity: 'form', id: f.id, caseId: cOf('form', f.id), title: `Forms sent (${f.forms.length})`, sub: f.forms.join(', ') }));
  bodyCharts(pid).forEach(b => out.push({ at: b.at, entity: 'bodychart', id: b.id, caseId: cOf('bodychart', b.id), title: `Body chart · ${b.title}` }));
  photosOf(pid).forEach(p => out.push({ at: p.at, entity: 'photo', id: p.id, caseId: cOf('photo', p.id), title: `Photo · ${p.area} ${p.view}`, sub: p.phase }));
  return out.sort((a, b) => b.at.localeCompare(a.at));
}
function toMin(t: string) { const m = String(t || '').match(/(\d{1,2}):(\d{2})\s*(AM|PM)?/i); if (!m) return '0'; let h = +m[1]; if (m[3]) { if (/pm/i.test(m[3]) && h < 12) h += 12; if (/am/i.test(m[3]) && h === 12) h = 0; } return String(h * 60 + +m[2]); }
export const caseEvents = (c: C.SurgicalCase) => eventsFor(c.patientId).filter(e => e.caseId === c.id);

/* ---------------- migration: every existing record gets a case ---------------- */
export function migrateCases(by = 'Vityls migration', role = 'System') {
  if (svRead<boolean>('cases-migrated-v16', false)) return 0; let n = 0;
  episodes().forEach(e => { if (!recs().some(c => c.id === e.id)) { saveRec({ id: e.id, patientId: e.patientId, procedure: e.procedure, kind: 'surgical', status: 'open', openedAt: e.createdAt, openedBy: e.createdBy, closedAt: e.closedAt, closedBy: e.closedAt ? 'Fictional seed' : undefined, closeReason: e.closedAt ? 'closed before v1.6' : undefined, episodeId: e.id, source: 'migration', log: [{ at: e.createdAt, by: e.createdBy, role: 'Staff', what: `Surgical case opened: ${e.procedure}` }] }); n++; } });
  const L = links(); const put = (entity: C.CaseEntity, id: string, pid: string, caseId: string) => { const k = C.linkKey(entity, id); if (!L[k]) L[k] = { entity, id, patientId: pid, caseId, at: new Date().toISOString(), by, how: 'migration' }; };
  medRepo.patients().forEach(p => {
    const cs = recs().filter(c => c.patientId === p.id); const qd: Record<string, string> = {};
    cs.forEach(c => { if (c.quick?.visitId) { const v = medRepo.visit(c.quick.visitId); if (v) qd[c.id] = v.date; } });
    const pick = (date: string, text: string) => C.assignByDate(cs, date, text, qd);
    medRepo.visits(p.id).forEach(v => { if (v.caseId) return; const own = cs.find(c => c.quick?.visitId === v.id || episode(c.episodeId || '')?.consultVisitId === v.id || episode(c.episodeId || '')?.postOp.some(x => x.visitId === v.id));
      medRepo.saveVisit({ ...v, caseId: own?.id || pick(v.date, `${v.visitType} ${v.reason}`) }); });
    contactNotes(p.id).forEach(x => put(/message|portal|text|email/i.test(x.channel) ? 'message' : 'call', x.id, p.id, pick(x.contactAt, `${x.reason} ${x.text}`)));
    medRepo.messages(p.id).forEach(m => put('message', m.id, p.id, pick(m.at, m.text)));
    docsOf(p.id).forEach(d => put('document', d.id, p.id, pick(d.receivedAt || d.docDate, `${d.title} ${d.description || ''}`)));
    quotesFor(p.id).forEach(q => { const ep = episodesFor(p.id).find(e => e.quoteId === q.id); put('quote', q.id, p.id, ep?.id || pick(curQuote(q).createdAt, curQuote(q).procedure)); });
    patientPayments(p.id).forEach(x => put('payment', x.id, p.id, pick(x.at, x.reason)));
    formsPackets(p.id).forEach(f => put('form', f.id, p.id, pick(f.sentAt, '')));
    const viaVisit = (vid: string | undefined, at: string, text: string) => { const v = vid ? medRepo.visit(vid) : undefined; return v?.caseId || (v ? pick(v.date, text) : pick(at, text)); };
    bodyCharts(p.id).forEach(b => put('bodychart', b.id, p.id, viaVisit(b.visitId, b.at, b.title)));
    photosOf(p.id).forEach(x => put('photo', x.id, p.id, viaVisit(x.visitId, x.at, x.area)));
  });
  svWrite(LK, L);
  // the per-patient workflow state moves to the patient's open surgical case
  const fs = svRead<Record<string, any>>('flow-state', {}); medRepo.patients().forEach(p => { const pc = primaryCase(p.id); if (pc && fs[p.id] && !fs[pc.id]) fs[pc.id] = fs[p.id]; }); svWrite('flow-state', fs);
  svWrite('cases-migrated-v16', true); repo.audit({ caseId: 'practice', user: by, role, action: 'case.migrate' as any, detail: `v1.6 migration: ${n} surgical case(s) from episodes; visits, calls, messages, documents, quotes, payments, forms, body charts and photos assigned to cases or General` });
  return n;
}
/** New items without a case get Nightingale's suggestion (the patient's open case); quick cases close once paid + signed; surgical cases close after the last post-op visit. */
export function syncCases(today = isoDay()) {
  if (!svRead<boolean>('cases-migrated-v16', false)) return;
  episodes().forEach(e => { if (recs().some(c => c.id === e.id || c.episodeId === e.id)) return;
    // a case Nightingale opened at the consult becomes this booking's case (same folder, now with the Episode's quote/deposit/booking/clearance)
    const pre = recs().find(c => c.patientId === e.patientId && c.kind === 'surgical' && !c.episodeId && !c.closedAt);
    if (pre) { saveRec({ ...pre, episodeId: e.id, procedure: e.procedure, log: [...pre.log, { at: e.createdAt, by: e.createdBy, role: 'Staff', what: `Booked: ${e.procedure} on ${e.surgeryDate}` }] }); return; }
    if (!recs().some(c => c.id === e.id)) openCase(e.patientId, { procedure: e.procedure, kind: 'surgical', source: 'manual', episodeId: e.id, openedAt: e.createdAt }, e.createdBy, 'Staff'); });
  recs().forEach(c0 => { const c = live(c0, today); if (c.status === 'closed') return;
    if (c.kind === 'office-procedure' && C.quickShouldClose(quickFacts(c))) closeCase(c.id, 'Nightingale', 'Assistant', 'paid and procedure note signed (automatic)');
    if (c.kind === 'surgical' && c.episodeId) { const e = episode(c.episodeId); const pv = medRepo.visits(c.patientId).filter(v => POSTOP.test(v.visitType) && caseOfVisit(v) === c.id && e && v.date >= e.surgeryDate);
      if (e && C.surgicalShouldClose(e.surgeryDate, pv.map(v => ({ date: v.date, step: v.step })), today)) closeCase(c.id, 'Nightingale', 'Assistant', 'last post-op visit done (automatic)'); } });
  const L = links(); let changed = false;
  medRepo.patients().forEach(p => { const sug = C.suggestCase(casesFor(p.id, today));
    medRepo.visits(p.id).forEach(v => { if (!v.caseId && !L[C.linkKey('visit', v.id)]) { medRepo.saveVisit({ ...v, caseId: sug }); } });
    const put = (entity: C.CaseEntity, id: string) => { const k = C.linkKey(entity, id); if (!L[k]) { L[k] = { entity, id, patientId: p.id, caseId: sug, at: new Date().toISOString(), by: 'Nightingale', how: 'nightingale' }; changed = true; } };
    contactNotes(p.id).forEach(x => put(/message|portal|text|email/i.test(x.channel) ? 'message' : 'call', x.id)); docsOf(p.id).forEach(d => put('document', d.id));
    quotesFor(p.id).forEach(q => put('quote', q.id)); patientPayments(p.id).forEach(x => put('payment', x.id)); formsPackets(p.id).forEach(f => put('form', f.id));
    bodyCharts(p.id).forEach(b => put('bodychart', b.id)); photosOf(p.id).forEach(x => put('photo', x.id)); });
  if (changed) svWrite(LK, L);
}
