/*
 * Surgery.Vityls v1.6 · Surgical cases: pure logic (no browser, no storage) so it is unit-tested with node.
 * A case is one reason the patient is with us: a surgery (built on the existing Episode, same id), an in-office procedure
 * (quick case: scheduled → checked in → procedure done → paid → closed) or a general folder. Everything the practice records
 * (visits, calls, messages, notes, documents, quotes, payments, forms, body charts, photos) carries a caseId or 'general'.
 * Henry: this is the shape of the `cases` and `case_links` tables (report/Case_Data_Model_for_Henry.md).
 */
export type CaseKind = 'surgical' | 'office-procedure' | 'general';
export type CaseStatus = 'open' | 'booked' | 'post-op' | 'closed' | 'undecided';
export const GENERAL = 'general';
export type CaseEntity = 'visit' | 'call' | 'message' | 'note' | 'document' | 'quote' | 'payment' | 'form' | 'bodychart' | 'photo';
export const ENTITY_LABEL: Record<CaseEntity, string> = { visit: 'Visit', call: 'Call', message: 'Message', note: 'Note', document: 'Document', quote: 'Quote', payment: 'Payment', form: 'Forms', bodychart: 'Body chart', photo: 'Photo' };
export interface CaseLogEntry { at: string; by: string; role: string; what: string }
export interface QuickState { visitId?: string; price?: number; paidAt?: string; paidBy?: string; paymentId?: string }
export interface SurgicalCase {
  id: string; patientId: string; procedure: string; kind: CaseKind; status: CaseStatus; openedAt: string; openedBy: string;
  closedAt?: string; closedBy?: string; closeReason?: string; /** surgical cases: the Episode (quote, deposit, booking, clearance) */ episodeId?: string;
  source: 'doctor-suggested' | 'manual' | 'migration' | 'seed' | 'new-appointment'; quick?: QuickState; log: CaseLogEntry[];
}
export interface CaseLink { entity: CaseEntity; id: string; patientId: string; caseId: string; at: string; by: string; how: 'migration' | 'staff' | 'nightingale' | 'seed' | 'auto' }
export const linkKey = (entity: CaseEntity, id: string) => `${entity}:${id}`;

/** Episode stage → case status (a closed case stays closed; an undecided consult is shown as undecided). */
export function statusFromEpisode(stage: string, surgeryDate: string | undefined, today: string, undecided = false): CaseStatus {
  if (stage === 'closed') return 'closed';
  if (stage === 'postop' || stage === 'surgery' || (surgeryDate && surgeryDate < today)) return 'post-op';
  if (stage === 'booked' || stage === 'preop') return 'booked';
  return undecided ? 'undecided' : 'open';
}
export const isOpenCase = (c: Pick<SurgicalCase, 'status'>) => c.status !== 'closed';
export const yearOf = (iso: string) => (iso || '').slice(0, 4);
export const caseTitle = (c: Pick<SurgicalCase, 'procedure' | 'openedAt' | 'status' | 'kind'>, events?: number) =>
  [c.procedure, yearOf(c.openedAt), c.status === 'post-op' ? 'post-op' : c.status, events != null ? `${events} event${events === 1 ? '' : 's'}` : ''].filter(Boolean).join(' · ');
export const KIND_LABEL: Record<CaseKind, string> = { surgical: 'Surgical case', 'office-procedure': 'Office procedure', general: 'General' };

const addDays = (iso: string, n: number) => { const [y, m, d] = iso.slice(0, 10).split('-').map(Number); return new Date(Date.UTC(y, m - 1, d + n)).toISOString().slice(0, 10); };
/** The dates a case covers: from a month before it opened (the consult) to its close (open cases run on). Quick cases cover their one visit day. */
export function caseWindow(c: Pick<SurgicalCase, 'openedAt' | 'closedAt' | 'kind' | 'quick'>, visitDate?: string): [string, string] {
  if (c.kind === 'office-procedure') { const d = visitDate || c.openedAt.slice(0, 10); return [d, (c.closedAt || '9999').slice(0, 10) < d ? d : (c.closedAt || '9999').slice(0, 10)]; }
  return [addDays(c.openedAt, -45), c.closedAt ? c.closedAt.slice(0, 10) : '9999-12-31'];
}
const words = (s: string) => (s || '').toLowerCase().split(/[^a-z]+/).filter(w => w.length > 3);
/**
 * Migration / suggestion: which case does a dated item belong to? Quick cases claim their own visit; then a case whose window holds
 * the date (a procedure word in the item's text wins a tie, then the most recently opened); else General.
 */
export function assignByDate(cases: SurgicalCase[], date: string, text = '', quickVisitDates: Record<string, string> = {}): string {
  const d = (date || '').slice(0, 10); if (!d) return GENERAL;
  const hits = cases.filter(c => c.kind !== 'general').filter(c => { const [a, b] = caseWindow(c, quickVisitDates[c.id]); return d >= a && d <= b; });
  if (!hits.length) return GENERAL;
  const t = words(text); const named = hits.filter(c => words(c.procedure).some(w => t.includes(w)));
  const pool = named.length ? named : hits.filter(c => c.kind !== 'office-procedure').length ? hits.filter(c => c.kind !== 'office-procedure') : hits;
  return pool.slice().sort((a, b) => b.openedAt.localeCompare(a.openedAt))[0].id;
}
/** Nightingale's default for a new appointment: the patient's open case (surgical first, newest first), else General. */
export function suggestCase(cases: SurgicalCase[]): string {
  const open = cases.filter(c => isOpenCase(c) && c.kind !== 'general');
  const s = open.filter(c => c.kind === 'surgical'); const pool = s.length ? s : open;
  return pool.length ? pool.slice().sort((a, b) => b.openedAt.localeCompare(a.openedAt))[0].id : GENERAL;
}

/* ---------------- quick (office-procedure) case ---------------- */
export interface QuickFacts { visitStep?: string; noteSigned?: { at: string; by?: string }; paid?: { at: string; by?: string }; scheduledAt?: string; checkedInAt?: string; closedAt?: string }
export interface QuickStep { key: 'scheduled' | 'checked-in' | 'procedure' | 'paid' | 'closed'; label: string; done?: { at: string; by?: string } }
const ORDER = ['scheduled', 'check-in', 'rooming', 'provider', 'checkout', 'complete'];
export function quickSteps(f: QuickFacts): QuickStep[] {
  const past = (s: string) => !!f.visitStep && ORDER.indexOf(f.visitStep) > ORDER.indexOf(s);
  return [
    { key: 'scheduled', label: 'Scheduled', done: f.scheduledAt ? { at: f.scheduledAt } : undefined },
    { key: 'checked-in', label: 'Checked in', done: f.checkedInAt ? { at: f.checkedInAt } : past('check-in') || f.visitStep === 'check-in' ? { at: f.scheduledAt || '' } : undefined },
    { key: 'procedure', label: 'Procedure done (note signed)', done: f.noteSigned },
    { key: 'paid', label: 'Paid', done: f.paid },
    { key: 'closed', label: 'Closed', done: f.closedAt ? { at: f.closedAt } : undefined },
  ];
}
/** A quick case closes itself once it is paid and the procedure note is signed. */
export const quickShouldClose = (f: QuickFacts) => !!f.noteSigned && !!f.paid && !f.closedAt;
/** A surgical case closes after its last post-op visit (all post-op visits in the past and finished, none booked ahead). */
export function surgicalShouldClose(surgeryDate: string | undefined, postop: { date: string; step: string }[], today: string): boolean {
  if (!surgeryDate || surgeryDate >= today || !postop.length) return false;
  return postop.every(v => v.date < today && v.step === 'complete');
}

/* ---------------- reassignment (one tap, audited) ---------------- */
export function reassign(links: Record<string, CaseLink>, l: Omit<CaseLink, 'at' | 'by' | 'how'>, by: string, at: string, how: CaseLink['how'] = 'staff'): { links: Record<string, CaseLink>; from: string; to: string; changed: boolean } {
  const k = linkKey(l.entity, l.id); const from = links[k]?.caseId || GENERAL; const next = { ...links, [k]: { ...l, at, by, how } };
  return { links: next, from, to: l.caseId, changed: from !== l.caseId };
}

/* ---------------- per-case to-do grouping (Today) ---------------- */
export interface CaseTodo<T> { pid: string; name: string; caseId: string; caseTitle: string; item: T }
export function groupTodos<T>(list: CaseTodo<T>[]): { pid: string; name: string; cases: { caseId: string; caseTitle: string; items: T[] }[] }[] {
  const out: { pid: string; name: string; cases: { caseId: string; caseTitle: string; items: T[] }[] }[] = [];
  list.forEach(t => { let p = out.find(x => x.pid === t.pid); if (!p) out.push(p = { pid: t.pid, name: t.name, cases: [] });
    let c = p.cases.find(x => x.caseId === t.caseId); if (!c) p.cases.push(c = { caseId: t.caseId, caseTitle: t.caseTitle, items: [] }); c.items.push(t.item); });
  return out;
}
