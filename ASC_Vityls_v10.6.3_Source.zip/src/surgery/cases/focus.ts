/* v1.6 · Which of a patient's open cases staff are working on right now (session only, no storage). Default: the primary case. */
const focus = new Map<string, string>();
export const focusCase = (pid: string, caseId?: string) => { if (caseId) focus.set(pid, caseId); else focus.delete(pid); };
export const focusOf = (pid: string) => focus.get(pid);
