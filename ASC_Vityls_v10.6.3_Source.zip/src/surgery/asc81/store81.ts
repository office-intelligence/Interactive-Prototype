/* ASC.Vityls v8.1 · storage for the AI-first workbench (ported from v7.7 src/v77/store.ts) in the ASC2 namespace via svRead/svWrite.
 * Henry tables (unchanged from v7.7): asc_intake, asc_booking_check, asc_records_brief, asc_bedside_draft, asc_nurse_admission,
 * asc_pacu_task, asc_aldrete, asc_discharge, asc_message_out. Keyed by ASC2 case id (asc8-cases). Fictional data only. */
import { useEffect, useState } from 'react';
import { svRead, svWrite } from '../store';
import type { BookingDraft, BedRole, BedLine, NurseItem, Vitals, PacuTask, Aldrete, RecPage } from './ai';
export interface IntakeItem { id: string; source: 'email' | 'fax'; from: string; at: string; subject: string; text: string; status: 'new' | 'booked' | 'dismissed'; caseId?: string; draft?: BookingDraft }
export interface Msg { id: string; caseId?: string; channel: 'email' | 'sms' | 'portal' | 'survey'; to: string; subject?: string; body: string; status: 'draft' | 'sent (simulated)' | 'scheduled (simulated)'; on?: string; at: string; by: string }
export interface Signed { by: string; at: string }
export interface CaseAI {
  checklist?: Record<string, boolean>; brief?: { asaAccepted?: { cls: number; by: string; at: string; changed: boolean } };
  bedside?: { transcript?: string; drafts?: Partial<Record<BedRole, BedLine[]>>; text?: Partial<Record<BedRole, string>>; signed?: Partial<Record<BedRole, Signed>> };
  nursing?: { items?: NurseItem[]; vitals?: Vitals; signed?: Signed };
  orders?: { text: string; signed?: Signed }; pacu?: { tasks?: PacuTask[]; aldrete?: Aldrete[] };
  discharge?: { language?: string; ride?: string; caregiver?: string; text?: string; patientSigned?: boolean; signed?: Signed };
  replies?: { at: string; text: string; concern: boolean; summary: string }[];
  /** v8.2 bench state: nursing checklist, anesthesia, surgeon, discharge signatures, ID/insurance card images */
  v82?: { nursing?: any; anes?: any; surg?: any; dc?: any; cards?: Record<string, string> };
}
const EV = 'asc81';
const rd = <T,>(k: string, d: T): T => svRead<T>(k, d);
const wr = (k: string, v: unknown) => { svWrite(k, v); window.dispatchEvent(new Event(EV)); window.dispatchEvent(new Event('vityls-med-updated')); };
export const s81 = {
  intake: () => rd<IntakeItem[]>('asc81-intake', SEED_INTAKE),
  upIntake: (i: IntakeItem) => { const l = s81.intake(); const x = l.findIndex(y => y.id === i.id); if (x >= 0) l[x] = i; else l.unshift(i); wr('asc81-intake', l); },
  ai: (id: string) => rd<Record<string, CaseAI>>('asc81-ai', {})[id] || {},
  setAi: (id: string, f: (a: CaseAI) => CaseAI) => { const m = rd<Record<string, CaseAI>>('asc81-ai', {}); m[id] = f(m[id] || {}); wr('asc81-ai', m); },
  msgs: () => rd<Msg[]>('asc81-outbox', []),
  addMsg: (m: Msg) => wr('asc81-outbox', [m, ...s81.msgs()]),
  pages: (caseId: string) => rd<Record<string, RecPage[]>>('asc81-records', {})[caseId] || SEED_PAGES[caseId] || [],
  faxN: () => rd<number>('asc81-faxn', 0), bumpFax: () => wr('asc81-faxn', s81.faxN() + 1),
};
export function use81() { const [, f] = useState(0); useEffect(() => { const h = () => f(x => x + 1); [EV, 'vityls-med-updated', 'storage'].forEach(e => window.addEventListener(e, h)); return () => [EV, 'vityls-med-updated', 'storage'].forEach(e => window.removeEventListener(e, h)); }, []); return s81; }
export const mid = (p: string) => `${p}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 6)}`;
const now = new Date().toISOString();
export const SEED_INTAKE: IntakeItem[] = [
  { id: 'in-email-1', source: 'email', from: 'scheduling@fictional-surgeons.example', at: now, subject: 'Booking request — hernia repair', status: 'new',
    text: 'FICTIONAL TEST EMAIL\nPatient: Jamie Testcase\nPhone: (555) 010-2233\nEmail: jamie.testcase@example.test\nAge: 58\nGender: Male\nDOB: 02/11/1968\nProcedure: Left inguinal hernia repair\nEstimated duration: 1.5 h\nSurgeon: Sam Patel, MD\nAssistant: None\nPayment type: Commercial insurance (fictional)\nAnesthesia: General\nEquipment: Laparoscopy tower\nRequested date: 11/03/2026' },
  { id: 'in-email-2', source: 'email', from: 'office@fictional-surgeons.example', at: now, subject: 'Booking request — returning patient', status: 'new',
    text: 'FICTIONAL TEST EMAIL\nPatient: Desmond Akers\nDOB: 01/30/1965\nPhone: (555) 010-7788\nEmail: desmond.akers@example.test\nAge: 61\nGender: Male\nProcedure: Left inguinal hernia repair\nEstimated duration: 1.5 h\nSurgeon: Sam Patel, MD\nAssistant: None\nPayment type: Commercial insurance (fictional)\nAnesthesia: General\nEquipment: None\nRequested date: 11/05/2026' },
];
export const SAMPLE_FAXES: string[] = [
  'FAX · Fictional Hand & Ortho Group · page 1 of 1\nFICTIONAL TEST FAX\nName: Morgan Sampleton\nAge: 44\nSex: F\nPhone: (555) 010-4455\nProcedure: Right carpal tunnel release\nDuration: 45 min\nSurgeon: Riley Nguyen, MD\nPayment: Self-Pay\nAnesthesia: MAC with local\nEquipment: Mini C-arm',
  'FAX · Fictional Eye Associates · page 1 of 1\nFICTIONAL TEST FAX\nName: Avery Placeholder\nAge: 71\nSex: M\nProcedure: Left cataract extraction with IOL\nDuration: 30 min\nSurgeon: Sam Patel, MD\nPayment: Medicare (fictional)\nAnesthesia: MAC',
];
const P = (doc: string, docTitle: string, page: number, date: string, text: string): RecPage => ({ doc, docTitle, page, date, text: `FICTIONAL. ${text}` });
export const SEED_PAGES: Record<string, RecPage[]> = {
  'c4': [
    P('pcp', 'Primary care records (fictional, 6 pages)', 1, '2026-09-12', 'Problem list: hypertension, type 2 diabetes, obstructive sleep apnea on CPAP. Medications: lisinopril 20 mg daily, metformin 1000 mg BID, semaglutide (Ozempic) weekly.'),
    P('pcp', 'Primary care records (fictional, 6 pages)', 2, '2026-08-03', 'Telephone encounter: patient called about refill request for metformin.'),
    P('pcp', 'Primary care records (fictional, 6 pages)', 3, '2025-11-20', 'Missed appointment. Appointment reminder sent.'),
    P('pcp', 'Primary care records (fictional, 6 pages)', 4, '2021-05-14', 'Sleep study: moderate obstructive sleep apnea, AHI 24. CPAP started.'),
    P('pcp', 'Primary care records (fictional, 6 pages)', 5, '2024-02-01', 'Portal message: question about billing statement.'),
    P('pcp', 'Primary care records (fictional, 6 pages)', 6, '2026-09-12', 'Exam: lungs clear to auscultation, regular rhythm, no murmur. Mallampati II.'),
    P('lab', 'Lab report — CBC, BMP, A1c (fictional)', 1, '2026-10-01', 'CBC: WBC 7.2, Hgb 13.8, Platelets 245. BMP: Sodium 139, Potassium 5.6, Creatinine 1.1, Glucose 182. HbA1c 7.9'),
    P('ecg', '12-lead ECG (fictional)', 1, '2026-10-01', 'ECG: normal sinus rhythm, rate 72. QTc 452 ms. No acute ST changes.'),
    P('clr', 'Pre-op clearance letter (fictional)', 1, '2026-10-06', 'Patient is medically optimized and cleared for surgery from a cardiac standpoint, signed Dr. Avery Example.'),
  ],
  'c6': [
    P('hp1', 'H&P — surgeon office (fictional)', 1, '2026-10-10', 'Healthy. No significant medical history. Medications: none. Exam normal.'),
    P('lab1', 'Labs (fictional)', 1, '2026-10-09', 'Hemoglobin 13.1, Potassium 4.2, Sodium 140.'),
  ],
  'c5': [P('hp3', 'H&P — primary care (fictional)', 1, '2026-10-02', 'No significant past medical history. hCG negative. Cleared for surgery, acceptable risk, signed Dr. Quinn Sample.')],
};
export const SAMPLE_BEDSIDE = `Nurse: Good morning. BP 132/84, heart rate 76, SpO2 97 percent.
Nurse: When did you last eat or drink?
Patient: Toast at 7 last night, a sip of water at 5 this morning.
Nurse: Who is driving you home?
Patient: My sister Dana, she'll stay with me at home tonight.
Dr. Lee: Any problems with anesthesia before?
Patient: I got sick to my stomach last time.
Dr. Lee: Mallampati II, good mouth opening, full neck movement.
Dr. Lee: Lungs clear to auscultation, regular rhythm.
Dr. Lee: Plan general anesthesia with PONV prophylaxis, ASA 2.
Dr. Patel: Let me mark the site — this is the left wrist, correct?
Patient: Yes, the left wrist.
Dr. Patel: We reviewed the risks, benefits and alternatives and you signed the consent.`;
