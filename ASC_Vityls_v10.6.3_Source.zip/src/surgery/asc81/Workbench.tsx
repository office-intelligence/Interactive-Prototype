/* ASC.Vityls v8.1 · AI-first workbench, ported from v7.7 (src/v77/Home77.tsx Bench77) onto ASC2 cases (asc8-cases).
 * Benches: booking intake, arrival & check-in, records brief, pre-op bedside, nursing admission, PACU, discharge, after surgery,
 * accreditation & audit pack. Nightingale drafts; people sign with their own PIN (PinSign). Email/fax/OCR/ambient/SMS are simulated.
 * No automatic PDF: the audit pack is a manual .txt download. Fictional data only. */
import { ViewToggle } from '../asc106/stations106';
import { BankFields, BANK_STATION, type BenchStation } from '../asc10/bank10'; void BankFields; void BANK_STATION; export type { BenchStation };
import React, { useState } from 'react';
import { medRepo, isoDay, uid, ageFrom } from '../../med/record';
import { useActor, useMedTick } from '../../med/ui';
import { repo } from '../../v6/dataLayer';
import { PinSign } from '../sign';
import { svWrite } from '../store';
import * as A from '../asc8/logic';
import * as S from '../asc8/store';
import * as L from './ai';
import { use81, s81, mid, SAMPLE_FAXES, SAMPLE_BEDSIDE, type CaseAI } from './store81';
import { CaseCard, XClose } from '../asc82/common';
import { CheckInFlow } from '../asc83/frontdesk';
import { OrdersSection, ClosurePanel, FollowUpCard, OpReceiptCard } from '../asc86/ui86';
import { Intake82, CardCapture, Nursing82, Anesthesia82, Surgeon82, Pacu82, Discharge82 } from '../asc82/benches';

/** v10.6.2: these stations place their remaining fields and the before-you-sign box themselves. */
const SELF_PLACED: string[] = ['nursing', 'anesthesia', 'surgeon', 'pacu', 'discharge'];
export type Bench = 'intake' | 'arrival' | 'verify' | 'brief' | 'nursing' | 'anesthesia' | 'surgeon' | 'pacu' | 'discharge' | 'after' | 'orders' | 'closure' | 'export';
/** v8.2 order: intake → arrival → records brief → nursing (pre-op bedside merged in) → anesthesia → surgeon → PACU → discharge → after → audit pack. */
export const BENCHES: { id: Bench; label: string; station: A.Station | 'all' }[] = [
  { id: 'intake', label: 'Booking intake', station: 'front' }, { id: 'arrival', label: 'Arrival & check-in', station: 'front' },
  { id: 'verify', label: 'Verify medical history', station: 'preop' }, { id: 'brief', label: 'Records brief', station: 'anesthesia' }, { id: 'nursing', label: 'Nursing admission', station: 'preop' },
  { id: 'anesthesia', label: 'Anesthesia', station: 'anesthesia' }, { id: 'surgeon', label: 'Surgeon', station: 'surgeon' },
  { id: 'orders', label: 'Doctor orders', station: 'surgeon' }, { id: 'pacu', label: 'PACU', station: 'pacu' }, { id: 'discharge', label: 'Discharge', station: 'pacu' },
  { id: 'after', label: 'After surgery', station: 'preop' }, { id: 'closure', label: 'Episode closure', station: 'billing' }, { id: 'export', label: 'Audit pack', station: 'billing' }];
const STAGE: Record<A.Loc, string> = { scheduled: 'CHECK_IN', arrived: 'PRE_OP', preop: 'PRE_OP', or: 'IN_OR', pacu: 'PACU_RECOVERY', discharged: 'DISCHARGED', closed: 'DISCHARGED' };
/** ASC2 case → the v7.7 CaseLite shape the ported logic expects. */
export function lite(c: A.AscCase): L.CaseLite { const p = medRepo.patient(c.pid); return { id: c.id, name: p?.name || c.pid, stage: STAGE[c.loc], encounterWorkflow: c.loc === 'arrived' ? { status: 'READY_FOR_PREOP' } : undefined, scheduledTime: c.time, room: c.room, surgeon: c.surgeon, anesthesiologist: c.anesthesia, procedure: c.procedure, gender: p?.sex, age: p ? ageFrom(p.dob) : undefined, allergies: p?.allergies || [], phone: p?.phone, email: p?.email, estimatedDurationMins: c.durationMin }; }
export function caseSignals(c: A.AscCase, ai: CaseAI): L.CaseSignals77 {
  const pages = s81.pages(c.id); const has = (re: RegExp) => pages.some(p => re.test(p.docTitle + ' ' + p.text)); const ck: Record<string, any> = { ...uploadChecks(uploads(c.id).map(u => u.type)), ...(caseMoney(c).status === 'paid' ? { payment: true } : {}), ...(ai.checklist || {}) }; const b = L.recordsBrief(pages); const d = c.d;
  return { portalForms: !!ck.portal || !!d.forms, hp: has(/h&p|history|problem list|healthy/i) || !!ck.hp || !!d.forms, labs: has(/lab|potassium|hemoglobin/i) || !!ck.labs || !!d.labs, labsAbnormal: b.lines.some(l => l.kind === 'lab' && l.abnormal),
    ecg: has(/ecg|ekg/i) || !!ck.ecg || (lite(c).age || 0) < 50, clearance: !!b.clearance || !!ck.clearance || !!d.clearance, consent: !!ck.consent || !!d.consentConfirm, paid: !!ck.payment || !!d.financial, ride: !!ck.ride || !!d.adult || !!ai.nursing?.items?.find(i => i.id === 'caregiver')?.value, lodging: !!ck.lodging || !!ai.nursing?.items?.find(i => i.id === 'postop')?.value } as any;
}
import { uploadChecks } from '../asc88/pure88';
import { CaptureUpload, FrontDeskDocs, VerifyHistory } from '../asc10/flow10';
import { ConfirmStation } from '../asc10/station102'; void ConfirmStation;
import { JourneyBar, BENCH_STEP } from '../asc88/journey88';
import { StationBar106 } from '../asc106/bar106';
import { StationCtx, MoreFields, BeforeSign } from '../asc106/slots106';
import '../asc106/bar106.css';
import { uploads } from '../asc87/store87';
import { caseMoney } from '../asc83/pay';
const audit = (cid: string, by: string, role: string, detail: string) => repo.audit({ caseId: `asc8:${cid}`, user: by, role, action: 'asc81.bench' as any, detail });
const stamp = (by: string) => ({ by, at: new Date().toISOString() });
const first = (n: string) => n.split(/\s+/)[0];
const roman = (n: number) => ['', 'I', 'II', 'III', 'IV'][n] || String(n);
const Sim: React.FC<{ children: React.ReactNode }> = ({ children }) => <p className="sv-small sv-muted mt-2">Simulated: {children} No BAA-covered vendor is connected yet.</p>;
const Foot: React.FC<{ children: React.ReactNode }> = ({ children }) => <div className="a81-foot">{children}</div>;
const H: React.FC<{ children: React.ReactNode }> = ({ children }) => <h3 className="a81-h3">{children}</h3>;
/** PIN only for signing: opens the shared PinSign dialog (each person's own PIN). */
const Sign: React.FC<{ label?: string; roles: string[]; what: string; testId: string; onSigned: (by: string, role: string) => void }> = ({ label = 'Sign with PIN', roles, what, testId, onSigned }) => {
  const [o, setO] = useState(false);
  return <>{<button type="button" className="a8-btn pri" onClick={() => setO(true)} data-testid={`${testId}-open`}>{label}</button>}
    {o && <PinSign title={label} statement={<>I reviewed “{what}”. Nightingale drafted; it does not sign.</>} roles={roles} onClose={() => setO(false)} onSigned={s => { setO(false); onSigned(s.name, s.role); }} />}</>;
};
const tryMove = (c: A.AscCase, to: A.Loc, by: string, role: string): string => { try { S.move(c, to, by, role); return ''; } catch (e) { return (e as Error).message; } };

export const Workbench: React.FC<{ bench: Bench; cid?: string; onClose: (m?: string) => void }> = ({ bench, cid, onClose }) => {
  useMedTick(); use81(); const [actor] = useActor(); const T = isoDay(); const [pick, setPick] = useState(cid);
  const fit: Partial<Record<Bench, (c: A.AscCase) => boolean>> = { arrival: c => c.loc === 'scheduled', anesthesia: c => c.loc === 'arrived' || c.loc === 'preop' || c.loc === 'or', surgeon: c => c.loc !== 'closed', nursing: c => c.loc === 'arrived' || c.loc === 'preop', verify: c => c.loc === 'arrived' || c.loc === 'preop' || c.loc === 'scheduled', pacu: c => c.loc === 'pacu', discharge: c => c.loc === 'pacu' || c.loc === 'discharged', after: c => c.loc === 'discharged' || c.loc === 'closed', closure: c => c.loc === 'discharged' || c.loc === 'closed' };
  const needs = !['intake', 'export'].includes(bench);
  const pool = S.cases().filter(c => c.date === T && (A.stationOf(actor.role) !== 'surgeon' || c.surgeon === actor.name));
  const shown = pool.filter(fit[bench] || (() => true)); const extra = pick && !pool.some(x => x.id === pick) ? [S.caseById(pick)].filter(Boolean) as A.AscCase[] : []; const list = [...extra, ...shown, ...pool.filter(x => !shown.includes(x))]; const c = list.find(x => x.id === pick) || list[0];
  const title = BENCHES.find(b => b.id === bench)!.label;
  return <div className="a81-modal" onMouseDown={e => { if (e.target === e.currentTarget) onClose(); }}>
    <div className="a81-dialog" role="dialog" aria-label={title} data-testid={`a81-bench-${bench}`}>
      <div className="a81-dhead"><b>{bench === 'export' ? 'Accreditation & audit pack' : title}</b>
        {needs && list.length > 1 && <select className="sv-input a81-pick" value={c?.id} onChange={e => setPick(e.target.value)} data-testid="a81-case-pick" aria-label="Switch patient">{list.map(x => <option key={x.id} value={x.id}>{medRepo.patient(x.pid)?.name} · {x.time}{fit[bench] && !fit[bench]!(x) ? ' (not at this step)' : ''}</option>)}</select>}
        {needs && <span className={`v10-chip ${!c || c.date === T ? 'ok' : 'warn'}`} data-testid="v10-today-pill">{!c || c.date === T ? 'Today' : 'Not today'} · {new Date((c?.date || T) + 'T12:00').toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' })}</span>}<span style={{ marginLeft: 'auto' }} />{needs && c && <ViewToggle />}{needs && c && <CaptureUpload c={c} station={title} />}<XClose onClick={() => onClose()} testId="a81-close" /></div>
      {needs && c && <JourneyBar c={c} here={BENCH_STEP[bench]} onLeave={() => onClose()} next={list[(list.indexOf(c) + 1) % list.length] !== c ? list[(list.indexOf(c) + 1) % list.length] : undefined} onNext={() => setPick(list[(list.indexOf(c) + 1) % list.length].id)} />}
      {needs && c && <div className="a82-dcase"><CaseCard c={c} station={BENCHES.find(b => b.id === bench)!.station as A.Station} /></div>}{needs && c && <StationBar106 key={'b6' + c.id} c={c} bench={bench} />}
      <StationCtx.Provider value={c ? { c, bench } : null}><div className="a81-dbody v106-dbody">{needs && !c ? <div className="v10-empty" data-testid="v10-bench-empty"><b>No patients at this step today</b><p>Cases booked for today appear here as they reach this station.</p></div> :
        bench === 'intake' ? <Intake82 onClose={onClose} /> : bench === 'arrival' ? <Arrival key={c!.id} c={c!} onClose={onClose} /> : bench === 'verify' ? <VerifyHistory key={c!.id} c={c!} onClose={onClose} /> : bench === 'brief' ? <Brief key={c!.id} c={c!} onClose={onClose} /> :
        bench === 'nursing' ? <Nursing82 key={c!.id} c={c!} onClose={onClose} /> : bench === 'anesthesia' ? <Anesthesia82 key={c!.id} c={c!} onClose={onClose} /> : bench === 'surgeon' ? <Surgeon82 key={c!.id} c={c!} onClose={onClose} /> : bench === 'pacu' ? <Pacu82 key={c!.id} c={c!} onClose={onClose} /> :
        bench === 'discharge' ? <Discharge82 key={c!.id} c={c!} onClose={onClose} /> : bench === 'after' ? <><OpReceiptCard key={'op' + c!.id} c={c!} /><FollowUpCard key={'fu' + c!.id} c={c!} /><After key={c!.id} c={c!} /></> : bench === 'orders' ? <OrdersSection key={c!.id} c={c!} /> : bench === 'closure' ? <ClosurePanel key={c!.id} c={c!} /> : <ExportPack />}{needs && c && !SELF_PLACED.includes(bench) && <><MoreFields key={'mf' + c.id} start={1} /><BeforeSign key={'bs' + c.id} /></>}</div></StationCtx.Provider>
    </div></div>;
};

/* 1 · booking intake (email + scanned paper fax) */
const FIELDS: [keyof L.BookingDraft, string][] = [['patientName', 'Patient name'], ['phone', 'Phone'], ['email', 'Email'], ['age', 'Age'], ['gender', 'Gender'], ['procedure', 'Procedure'], ['durationMins', 'Duration (min)'], ['surgeon', 'Surgeon'], ['assistant', 'Assistant'], ['paymentType', 'Payment type'], ['anesthesia', 'Anesthesia type'], ['equipment', 'Special equipment']];
export function createCaseFromDraft(d: L.BookingDraft, room: string, time: string, source: string, by: string, role: string): A.AscCase {
  const at = new Date().toISOString(); const pid = uid('ASC-N'); const T = isoDay(); const y = new Date().getFullYear() - (d.age || 40);
  medRepo.savePatient({ id: pid, name: d.patientName, dob: d.dob || `01/01/${y}`, sex: /^f/i.test(d.gender || '') ? 'Female' : /^m/i.test(d.gender || '') ? 'Male' : 'Other', phone: d.phone || '', email: d.email || '', language: 'English', allergies: [], primaryProvider: d.surgeon || S.PATEL, careTeam: [], insurance: d.paymentType || 'Self-pay', fictional: true } as any);
  const vid = `visit-asc81-${pid}`; medRepo.saveVisit({ id: vid, patientId: pid, date: T, time, durationMin: d.durationMins || 60, provider: d.surgeon || S.PATEL, room, visitType: 'Surgery case', reason: d.procedure, step: 'scheduled', problemIds: [], createdAt: at, createdBy: by } as any);
  const c: A.AscCase = { id: uid('c'), pid, visitId: vid, date: T, time, durationMin: d.durationMins || 60, room, surgeon: d.surgeon || S.PATEL, anesthesia: S.ANES[0], procedure: d.procedure, cpt: '', loc: 'scheduled', d: {}, events: {}, audit: [{ at, by, role, what: `Case created from ${source} intake (Nightingale pre-fill confirmed by staff)` }], from: 'ASC' };
  svWrite('asc8-cases', [...S.cases(), c]); repo.audit({ caseId: `asc8:${c.id}`, user: by, role, action: 'asc8.case' as any, detail: `${d.patientName} · case created from ${source} intake` }); window.dispatchEvent(new Event('vityls-med-updated')); return c;
}
const to12 = (t: string) => { const m = /(\d+):(\d+)\s*(AM|PM)?/i.exec(t); if (!m) return t; let h = +m[1]; const ap = m[3] ? m[3].toUpperCase() : h >= 12 ? 'PM' : 'AM'; if (!m[3] && h > 12) h -= 12; return `${String(h).padStart(2, '0')}:${m[2]} ${ap}`; };
/* 2 · arrival: checklist, follow-up emails, check-in gate */
const Arrival: React.FC<{ c: A.AscCase; onClose: (m?: string) => void }> = ({ c, onClose }) => {
  const s = use81(); const [actor] = useActor(); const ai = s.ai(c.id); const items = L.bookingChecklist(caseSignals(c, ai)); const cl = lite(c);
  const drafts = (['patient', 'surgeon office'] as const).map(to => L.followUpEmail({ name: cl.name, email: cl.email, surgeon: c.surgeon, dateLabel: 'today' }, items, to)).filter(Boolean) as NonNullable<ReturnType<typeof L.followUpEmail>>[];
  const [edit, setEdit] = useState<Record<number, string>>({}); const [err, setErr] = useState('');
  const mark = (id: string) => s.setAi(c.id, a => ({ ...a, checklist: { ...(a.checklist || {}), [id]: true } }));
  const checkIn = () => { let x = S.caseById(c.id)!; if (!A.isDone(x, 'id')) x = S.setValue(x, 'id', stamp(actor.name), actor.name, actor.role, 'ID and insurance confirmed');
    const e = tryMove(x, 'arrived', actor.name, actor.role); if (e) return setErr(e);
    S.raiseFlag({ from: actor.name, fromRole: actor.role, to: 'preop', pid: c.pid, caseId: c.id, text: `${cl.name} is checked in and ready for pre-op nursing.` });
    onClose(`${cl.name} checked in. Pre-op nursing is flagged.`); };
  return <div data-testid="a81-arrival"><FrontDeskDocs c={c} /><CardCapture c={c} /><CheckInFlow cid={c.id} onDone={m => onClose(m)} /><details className="a81-box mt-2"><summary>Booking checklist &amp; follow-up emails</summary><p className="mt-2">{L.checklistLine(items)}.</p>
    <div className="a81-grid3" data-testid="a81-checklist">{items.map(i => <div key={i.id} className="a81-check" data-state={i.state} data-testid="a81-check"><span className={`a81-chip ${i.state}`}>{i.state}</span><span style={{ flex: 1 }}>{i.label}</span>{i.state === 'missing' && <button type="button" className="sv-link sv-small" onClick={() => mark(i.id)} data-testid={`a81-mark-${i.id}`}>Received</button>}</div>)}</div>
    {drafts.length > 0 && <><H>Follow-up emails Nightingale drafted</H>{drafts.map((d, i) => <div key={i} className="a81-box mb-2" data-testid="a81-followup"><div className="sv-small">To: {d.to} · {d.subject}</div><textarea className="sv-input mt-1" rows={5} value={edit[i] ?? d.body} onChange={e => setEdit({ ...edit, [i]: e.target.value })} />
      <div className="a81-foot"><button type="button" className="a8-btn pri" onClick={() => { s.addMsg({ id: mid('m'), caseId: c.id, channel: 'email', to: d.to, subject: d.subject, body: edit[i] ?? d.body, status: 'sent (simulated)', at: new Date().toISOString(), by: actor.name }); audit(c.id, actor.name, actor.role, `Follow-up email to outbox (simulated): ${d.subject}`); }} data-testid="a81-followup-send">Send (simulated)</button></div></div>)}<Sim>email goes to the outbox only.</Sim></>}
    </details></div>;
};

/* 3 · records brief with page citations + ASA suggestion (anesthesia accepts) */
const Brief: React.FC<{ c: A.AscCase; onClose: (m?: string) => void }> = ({ c, onClose }) => {
  const s = use81(); const [actor] = useActor(); const pages = s.pages(c.id); const b = L.recordsBrief(pages); const ai = s.ai(c.id);
  const [src, setSrc] = useState<L.BriefLine['src'] | null>(null); const [cls, setCls] = useState<number>(ai.brief?.asaAccepted?.cls || b.asa.cls);
  const canAsa = ['anesthesia', 'billing'].includes(A.stationOf(actor.role));
  const group = (k: L.BriefLine['kind'][], t: string) => { const xs = b.lines.filter(l => k.includes(l.kind)); return xs.length ? <><H>{t}</H>{xs.map((l, i) => <div key={i} className={`a81-line ${l.abnormal ? 'abn' : ''}`} data-testid="a81-brief-line" data-abnormal={l.abnormal ? '1' : '0'}><span style={{ flex: 1 }}>{l.text}</span><span className="sv-small sv-muted">{l.date}</span><button type="button" className="sv-link sv-small" onClick={() => setSrc(l.src)} data-testid="a81-src-link">p.{l.src.page}</button></div>)}</> : null; };
  const sp = src && pages.find(x => x.doc === src.doc && x.page === src.page);
  const accept = () => { s.setAi(c.id, a => ({ ...a, brief: { asaAccepted: { cls, by: actor.name, at: new Date().toISOString(), changed: cls !== b.asa.cls } } })); S.setValue(S.caseById(c.id)!, 'asa', roman(cls), actor.name, actor.role, `ASA ${roman(cls)} ${cls !== b.asa.cls ? `chosen (Nightingale suggested ${roman(b.asa.cls)})` : 'accepted as suggested'}`); onClose(`ASA ${roman(cls)} saved.`); };
  return <div className="a81-cols wide" data-testid="a81-brief"><div>
    <p>{pages.length} pages read · <b>{b.kept} relevant</b> · {b.dropped} set aside (calls, refills, missed visits, billing). Every line links to its source page.</p>
    {!pages.length && <p className="sv-muted" data-testid="a81-brief-empty">No outside records on file for this patient yet. Use Capture / Upload to add them.</p>}
    {group(['conflict'], 'Needs a look')}{group(['lab'], 'Labs')}{group(['test'], 'ECG & tests')}{group(['problem'], 'Active problems')}{group(['med'], 'Medications of interest')}{group(['clearance'], 'Clearance')}</div>
    <div>{!pages.length ? <div className="v10-empty" data-testid="a81-asa-none"><b>No ASA suggestion</b>Nightingale suggests an ASA class only when outside records are on file.</div> : <div className="a81-box" data-testid="a81-asa"><div className="sv-small sv-muted">Suggested before the anesthesia visit</div><div className="a81-big">ASA {roman(b.asa.cls)}</div><div className="sv-small">{b.asa.why.join(' · ')}</div>
      {ai.brief?.asaAccepted ? <p className="a81-ok" data-testid="a81-asa-saved">ASA {roman(ai.brief.asaAccepted.cls)} {ai.brief.asaAccepted.changed ? 'set' : 'accepted'} by {ai.brief.asaAccepted.by}</p> : canAsa ? <div className="a81-foot"><select className="sv-input" style={{ width: 'auto' }} value={cls} onChange={e => setCls(+e.target.value)} data-testid="a81-asa-pick">{[1, 2, 3, 4].map(n => <option key={n} value={n}>ASA {roman(n)}</option>)}</select><button type="button" className="a8-btn pri" onClick={accept} data-testid="a81-asa-accept">{cls === b.asa.cls ? 'Accept' : 'Save change'}</button></div> : <p className="sv-small sv-muted">The anesthesiologist accepts or changes this.</p>}</div>}
      {sp ? <div className="a81-box mt-2" data-testid="a81-src-view"><b className="sv-small">{sp.docTitle} · page {sp.page} · {sp.date}</b><p className="a81-pre">{sp.text}</p></div> : <p className="sv-small sv-muted mt-2">Tap a page link to see the original.</p>}</div></div>;
};

/* 8 · after surgery: scheduled text + survey, simulated replies triaged (concern → flag to pre-op nursing) */
const After: React.FC<{ c: A.AscCase }> = ({ c }) => {
  const s = use81(); const [actor] = useActor(); const msgs = s.msgs().filter(m => m.caseId === c.id); const ai = s.ai(c.id); const [r, setR] = useState(''); const cl = lite(c);
  const reply = () => { if (!r.trim()) return; const t = L.triageReply(r); s.setAi(c.id, a => ({ ...a, replies: [...(a.replies || []), { at: new Date().toISOString(), text: r, ...t }] })); if (t.concern) S.raiseFlag({ from: 'Nightingale (automatic)', fromRole: 'System', to: 'preop', pid: c.pid, caseId: c.id, text: `Follow-up concern from ${cl.name}: call back.` }); audit(c.id, actor.name, actor.role, `Patient reply (simulated): ${t.summary}`); setR(''); };
  return <div data-testid="a81-after"><H>Scheduled</H>{msgs.filter(m => m.channel === 'sms' || m.channel === 'survey').map(m => <div key={m.id} className="a81-line" data-testid="a81-sched"><b>{m.channel === 'sms' ? 'Next-day text' : 'Satisfaction survey'}</b> · {m.on} · {m.status}<div className="sv-small">{m.body}</div></div>)}
    {!msgs.some(m => m.channel === 'sms') && <p className="sv-muted">Set automatically when discharge is signed.</p>}
    <H>Replies</H>{(ai.replies || []).map((x, i) => <div key={i} className={x.concern ? 'a81-alert' : 'a81-okpanel'} data-testid="a81-reply">{x.summary}</div>)}
    <div className="a81-foot"><input className="sv-input" style={{ flex: 1 }} placeholder="Simulate a patient reply, e.g. 3 - fever since last night" value={r} onChange={e => setR(e.target.value)} data-testid="a81-reply-in" /><button type="button" className="a8-btn pri" onClick={reply} data-testid="a81-reply-go">Add reply</button></div><Sim>texts and the survey are queued in the outbox, not sent.</Sim></div>;
};

/* 9 · accreditation / audit pack (manual download; no automatic PDF) */
export function auditRows(): L.CaseAudit[] { return S.cases().map(c => { const ai = s81.ai(c.id); const signedItems = A.ITEMS.filter(i => i.sign && i.form).map(i => ({ file: i.form!, title: i.label, signed: A.isDone(c, i.key) }));
  const forms = [{ file: 'nursing', title: 'Nursing admission', signed: !!ai.nursing?.signed || A.isDone(c, 'nursingForm') }, { file: 'orders', title: 'Post-op orders', signed: !!ai.orders?.signed }, { file: 'dc', title: 'Discharge instructions', signed: !!ai.discharge?.signed || A.isDone(c, 'instructions') }, ...signedItems];
  return { id: c.id, name: `${medRepo.patient(c.pid)?.name || c.pid} (${c.date})`, forms, times: Object.values(c.events).filter(Boolean).length, opReport: !!c.d.opReport?.signedBy }; }); }
export const ExportPack: React.FC = () => {
  useMedTick(); const pk = L.accreditationPack(auditRows());
  const dl = () => { const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([pk.lines.join('\n')], { type: 'text/plain' })); a.download = 'ASC_audit_pack_fictional.txt'; a.click(); };
  return <div data-testid="a81-export"><p><b>{pk.complete} of {pk.total}</b> cases complete.</p><pre className="a81-pre" data-testid="a81-export-text">{pk.lines.join('\n')}</pre><Foot><button type="button" className="a8-btn" onClick={dl} data-testid="a81-export-dl">Download (.txt)</button></Foot></div>;
};
