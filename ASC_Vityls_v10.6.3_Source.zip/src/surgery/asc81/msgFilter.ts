/* ASC.Vityls v8.1 · Messages filters (from v7.7 Messages: All inbound, Unread, Clinical, Rx refills, Billing). Pure. */
export type MsgFilter = 'all' | 'unread' | 'clinical' | 'rx' | 'billing';
export const MSG_FILTERS: [MsgFilter, string][] = [['all', 'All inbound'], ['unread', 'Unread'], ['clinical', 'Clinical'], ['rx', 'Rx refills'], ['billing', 'Billing']];
/** v8.1 (from v7.7 Messages): classify a thread by its latest inbound message. Keyword rules; staff can always read every thread. */
export function msgMatches(f: MsgFilter, msgs: { from: string; text: string }[]): boolean {
  const inbound = msgs.filter(m => m.from !== 'office'); if (f === 'all') return true; const last = msgs[msgs.length - 1]; if (f === 'unread') return !!last && last.from !== 'office';
  const t = inbound.map(m => m.text).join(' ').toLowerCase();
  if (f === 'rx') return /refill|prescription|\brx\b|pharmacy|medication/.test(t);
  if (f === 'billing') return /bill|invoice|payment|deposit|insurance|statement|charge|copay/.test(t);
  return !/refill|prescription|\brx\b|pharmacy|bill|invoice|payment|deposit|statement|copay/.test(t) && inbound.length > 0;
}
