/* ASC.Vityls v8.1 · v7.7 features restored on the ASC2 shell: workbench chips + host, Nightingale quick actions, Day Briefing,
 * Operations Pipeline / Priority views (from the v7.7 Classic board), Medical Director workspace, Accreditation & audit pack page,
 * and the fictional v8.1 seed (portal messages for the Messages filters, credentialing applications). Fictional data only. */
import { XClose } from '../asc82/common';
import React, { useEffect, useState } from 'react';
import { medRepo, isoDay, uid } from '../../med/record';
import { useActor, useMedTick } from '../../med/ui';
import { repo } from '../../v6/dataLayer';
import { svRead, svWrite } from '../store';
import { useSv } from '../ui';
import { PinSign } from '../sign';
import { staffList } from '../staff';
import * as A from '../asc8/logic';
import * as S from '../asc8/store';
import { openAsc, Stage } from '../asc8/ui';
import * as L from './ai';
import { Workbench, BENCHES, type Bench, lite, ExportPack } from './Workbench';
import { StationIcon } from './icons81';

export const openBench = (bench: Bench, cid?: string) => window.dispatchEvent(new CustomEvent('asc81-bench', { detail: { bench, cid } }));
export const Asc81Host: React.FC = () => {
  const [b, setB] = useState<{ bench: Bench; cid?: string } | null>(null); const { toast } = useSv();
  useEffect(() => { const h = (e: Event) => setB((e as CustomEvent).detail); window.addEventListener('asc81-bench', h); return () => window.removeEventListener('asc81-bench', h); }, []);
  return b ? <Workbench key={b.bench + ':' + (b.cid || '')} bench={b.bench} cid={b.cid} onClose={m => { setB(null); if (m) toast(m); }} /> : null;
};
/** Workbench chips on Today (v7.7 Home): my station's benches first, then the rest. */
export const BenchChips: React.FC = () => {
  const [actor] = useActor(); const st = A.stationOf(actor.role); const [all, setAll] = useState(false);
  const mine = BENCHES.filter(b => b.station === st || (st === 'surgeon' && b.id === 'brief') || (st === 'anesthesia' && b.id === 'orders') || ((st === 'pacu' || st === 'billing') && b.id === 'closure'));
  const list = all || !mine.length ? BENCHES : mine;
  return <div className="a81-chips" data-testid="a81-bench-chips"><span className="a81-chips-k">Nightingale workbench</span>{list.map(b => <button key={b.id} type="button" className="a81-chip-btn" onClick={() => openBench(b.id)} data-testid={`a81-chip-${b.id}`}><StationIcon st={b.station === 'all' ? 'billing' : b.station} size={14} />{b.label}</button>)}
    {mine.length > 0 && mine.length < BENCHES.length && <button type="button" className="a81-chip-btn ghost" onClick={() => setAll(x => !x)} data-testid="a81-chip-all">{all ? 'Mine only' : 'All workbenches'}</button>}</div>;
};
/** Nightingale quick actions (v7.7 coordinator panel): each opens the screen; Nightingale never signs or decides. */
export const QuickActions: React.FC = () => {
  const { setTab, toast } = useSv(); const [actor] = useActor(); const T = isoDay();
  const ekg = () => { const c = S.cases().find(x => x.date === T && x.loc === 'scheduled' && !x.d.labs) || S.cases().find(x => x.date === T && x.loc === 'scheduled'); if (!c) return toast('No scheduled case today needs an EKG hold.');
    S.raiseFlag({ from: actor.name, fromRole: actor.role, to: 'anesthesia', pid: c.pid, caseId: c.id, text: `EKG hold? ${medRepo.patient(c.pid)?.name}: no EKG on file — please confirm before pre-op.` }); toast('Anesthesia flagged about the EKG (they decide).'); };
  const acts: [string, string, () => void][] = [['3-OR matrix', 'qa-matrix', () => setTab('ops-hub')], ['Billing & claims', 'qa-billing', () => setTab('billing-hub')], ['Portal messages', 'qa-messages', () => setTab('messages')], ['Clinical Form Studio', 'qa-forms', () => setTab('forms')], ['EKG hold', 'qa-ekg', ekg], ['Audit pack', 'qa-audit', () => openBench('export')]];
  return <div className="a81-qa" data-testid="a81-quick-actions"><span className="a81-chips-k">Ask Nightingale</span>{acts.map(([l, id, f]) => <button key={id} type="button" className="a81-chip-btn" onClick={f} data-testid={`a81-${id}`}>{l}</button>)}</div>;
};

/* ---------------- Day Briefing (v7.7 Schedule › Day Briefing) ---------------- */
export const DayBriefing: React.FC<{ day: string; onClose: () => void }> = ({ day, onClose }) => {
  useMedTick(); const cs = S.cases().filter(c => c.date === day).sort((a, b) => A.toMin(a.time) - A.toMin(b.time)); const sum = L.daySummary(cs.map(lite));
  const allergic = cs.filter(c => (medRepo.patient(c.pid)?.allergies || []).length); const flags = S.flagsAll().filter(f => f.status === 'open' && cs.some(c => c.id === f.caseId));
  return <div className="a81-modal" onMouseDown={e => { if (e.target === e.currentTarget) onClose(); }}><div className="a81-dialog narrow" role="dialog" aria-label="Day briefing" data-testid="a81-day-briefing">
    <div className="a81-dhead"><b>Surgical day briefing · {new Date(day + 'T12:00').toLocaleDateString('en-US', { weekday: 'long', month: 'short', day: 'numeric' })}</b><span style={{ marginLeft: 'auto' }} /><XClose onClick={onClose} testId="a81-brief-close" /></div>
    <div className="a81-dbody"><p className="a81-okpanel" data-testid="a81-brief-text">{sum.text}</p>
      <div className="a81-grid3 mt-2"><div className="a81-box"><b>Ages</b>{Object.entries(sum.ageBands).map(([k, n]) => <div key={k} className="sv-small">{k}: {n}</div>)}</div><div className="a81-box"><b>Rooms</b>{sum.rooms.map(([r, n]) => <div key={r} className="sv-small">{r}: {n}</div>)}</div><div className="a81-box"><b>Procedures</b>{sum.procedures.map(([p, n]) => <div key={p} className="sv-small">{n} × {p}</div>)}</div></div>
      <h3 className="a81-h3">Cases</h3>{cs.map(c => <div key={c.id} className="a81-line"><span style={{ width: 70 }}>{c.time}</span><span style={{ flex: 1 }}><b>{medRepo.patient(c.pid)?.name}</b> · {c.procedure} · {c.room} · {c.surgeon.replace(/,.*$/, '')}</span><Stage c={c} /></div>)}
      <h3 className="a81-h3">Allergies</h3>{allergic.length ? allergic.map(c => <div key={c.id} className="sv-small">⚠ {medRepo.patient(c.pid)?.name}: {medRepo.patient(c.pid)?.allergies.join('; ')}</div>) : <p className="sv-small sv-muted">None recorded.</p>}
      <h3 className="a81-h3">Open flags</h3>{flags.length ? flags.map(f => <div key={f.id} className="sv-small">⚑ {f.text} <span className="sv-muted">→ {A.TEAM_LABEL[f.to]}</span></div>) : <p className="sv-small sv-muted">No open flags.</p>}
      <p className="sv-small sv-muted mt-2">Print from the schedule's Print button. No PDF is created automatically.</p></div></div></div>;
};

/* ---------------- Operations: Pipeline + Priority (v7.7 Classic board views) ---------------- */
export const OpsViews: React.FC = () => {
  useMedTick(); const T = isoDay(); const [v, setV] = useState<'pipeline' | 'priority'>('pipeline'); const cs = S.cases().filter(c => c.date === T);
  const flags = S.flagsAll().filter(f => f.status === 'open');
  const pri = cs.map(c => { const miss = A.STATIONS.flatMap(st => A.missing(c, st, T)); const fl = flags.filter(f => f.caseId === c.id).length; const late = c.loc === 'scheduled' && A.toMin(c.time) < new Date().getHours() * 60 + new Date().getMinutes(); return { c, miss, fl, late, score: miss.filter(i => i.req).length + 3 * fl + (late ? 5 : 0) }; }).filter(x => !['discharged', 'closed'].includes(x.c.loc)).sort((a, b) => b.score - a.score);
  return <section className="v7-card" data-testid="a81-ops-views"><div className="a81-dhead" style={{ padding: 0, border: 0 }}><h2 className="a8-h2">Case board</h2><span className="a8-sw" style={{ marginLeft: 'auto' }}><button type="button" className={v === 'pipeline' ? 'on' : ''} onClick={() => setV('pipeline')} data-testid="a81-view-pipeline">Pipeline</button><button type="button" className={v === 'priority' ? 'on' : ''} onClick={() => setV('priority')} data-testid="a81-view-priority">Priority</button></span></div>
    {v === 'pipeline' ? <div className="a81-pipe" data-testid="a81-pipeline">{A.LOC_ORDER.map(l => { const xs = cs.filter(c => c.loc === l); return <div key={l} className="a81-pcol"><div className="h" style={{ borderTopColor: A.LOC_COLOR[l] }}>{A.LOC_LABEL[l]} <b>{xs.length}</b></div>{xs.map(c => <button key={c.id} type="button" className="a81-pcard" onClick={() => openAsc({ t: 'record', cid: c.id })} data-testid="a81-pipe-card"><b>{medRepo.patient(c.pid)?.name}</b><span>{c.time} · {c.room}</span><span>{c.procedure}</span></button>)}</div>; })}</div>
      : <div data-testid="a81-priority">{pri.map(({ c, miss, fl, late, score }, i) => <button key={c.id} type="button" className="a8-case" onClick={() => openAsc({ t: 'record', cid: c.id })} data-testid="a81-pri-row"><span className="tm">#{i + 1}</span><span className="min-w-0 flex-1"><span className="nm">{medRepo.patient(c.pid)?.name}</span><span className="sub">{c.time} · {c.procedure} · {c.room}</span><span className="miss">{[late ? 'Late to arrive' : '', fl ? `${fl} open flag${fl > 1 ? 's' : ''}` : '', miss.length ? `${miss.length} item${miss.length > 1 ? 's' : ''} missing` : ''].filter(Boolean).join(' · ') || 'On track'}</span></span><span className="a81-score" title="Priority score">{score}</span><Stage c={c} /></button>)}</div>}
  </section>;
};

/* ---------------- Medical Director workspace ---------------- */
interface Cred { id: string; name: string; specialty: string; submitted: string; items: { k: string; ok: boolean }[]; status: 'Pending Medical Director Review' | 'Privileges Approved' | 'Returned'; privileges: string[]; decidedBy?: string; decidedAt?: string; note?: string }
interface MdState { director: string; designatedAt: string; creds: Cred[]; reviews: { id: string; what: string; by: string; at: string; next: string }[] }
const MD_SEED = (): MdState => ({ director: 'Sam Patel, MD', designatedAt: new Date().toISOString(), reviews: [], creds: [
  { id: 'cr-1', name: 'Lena Example, MD', specialty: 'Orthopedic surgery (fictional)', submitted: isoDay(), status: 'Pending Medical Director Review', privileges: ['Knee arthroscopy', 'Carpal tunnel release', 'Shoulder arthroscopy'], items: [{ k: 'Medical license verified (simulated primary source)', ok: true }, { k: 'DEA registration', ok: true }, { k: 'Board certification', ok: true }, { k: 'Malpractice insurance (COI)', ok: true }, { k: 'Hospital transfer agreement / admitting privileges', ok: false }, { k: 'NPDB query (simulated)', ok: true }] },
  { id: 'cr-2', name: 'Omar Testwell, MD', specialty: 'Plastic surgery (fictional)', submitted: isoDay(), status: 'Pending Medical Director Review', privileges: ['Abdominoplasty', 'Breast augmentation'], items: [{ k: 'Medical license verified (simulated primary source)', ok: true }, { k: 'DEA registration', ok: true }, { k: 'Board certification', ok: true }, { k: 'Malpractice insurance (COI)', ok: true }, { k: 'Hospital transfer agreement / admitting privileges', ok: true }, { k: 'NPDB query (simulated)', ok: true }] }] });
export const mdState = () => svRead<MdState>('asc81-md', MD_SEED());
const saveMd = (m: MdState) => { svWrite('asc81-md', m); window.dispatchEvent(new Event('vityls-med-updated')); };
const addYear = (d: string) => { const x = new Date(d + 'T12:00'); x.setFullYear(x.getFullYear() + 1); return x.toISOString().slice(0, 10); };
export const MedicalDirector: React.FC = () => {
  useMedTick(); const [actor] = useActor(); const { setTab, toast } = useSv(); const md = mdState(); const T = isoDay();
  const docs = staffList().filter(s => s.active && /surgeon|anesth/i.test(s.role)).map(s => s.name);
  const [sign, setSign] = useState<{ title: string; what: string; run: (by: string) => void } | null>(null);
  const cs = S.cases(); const unsigned = cs.filter(c => ['pacu', 'discharged'].includes(c.loc) && !c.d.opReport?.signedBy).length; const late = A.delays(cs.filter(c => c.date === T)).length;
  const POL = ['Infection control plan', 'Malignant hyperthermia protocol & drill', 'Emergency transfer agreement', 'Patient rights & grievance policy', 'Quality improvement (QAPI) program', 'Peer review'];
  const latest = (w: string) => md.reviews.filter(r => r.what === w).slice(-1)[0];
  return <div className="sv-page" data-testid="a81-md"><button type="button" className="sv-link text-[13px]" data-ps-legacy="" onClick={() => setTab('practice')}>‹ Practice</button><h1 className="sv-title mt-1" data-ps-legacy="">Medical Director</h1>
    <div className="sv-sub mb-3" data-ps-legacy="">Designation, privileges review and annual policy attestations. The Medical Director signs with their own PIN; Nightingale never approves.</div>
    <section className="v7-card a81-sec" data-testid="a81-md-designation"><h2 className="a8-h2">Designation</h2><div className="a81-foot" style={{ justifyContent: 'flex-start' }}><select className="sv-input" style={{ width: 'auto' }} value={md.director} onChange={e => { saveMd({ ...md, director: e.target.value, designatedAt: new Date().toISOString() }); repo.audit({ caseId: 'practice', user: actor.name, role: actor.role, action: 'asc81.md' as any, detail: `Medical Director designated: ${e.target.value}` }); toast('Medical Director updated.'); }} data-testid="a81-md-pick">{Array.from(new Set([md.director, ...docs])).map(n => <option key={n}>{n}</option>)}</select><span className="sv-small sv-muted">since {new Date(md.designatedAt).toLocaleDateString()}</span></div></section>
    <section className="v7-card a81-sec" data-testid="a81-md-quality"><h2 className="a8-h2">Quality snapshot (fictional)</h2><div className="a81-grid3"><div className="a81-box"><div className="a81-big">{cs.length}</div><span className="sv-small">cases on file</span></div><div className="a81-box"><div className="a81-big">{unsigned}</div><span className="sv-small">op reports not signed</span></div><div className="a81-box"><div className="a81-big">{late}</div><span className="sv-small">late starts today</span></div></div></section>
    <section className="v7-card a81-sec" data-testid="a81-md-creds"><h2 className="a8-h2">Privileges review · {md.creds.filter(c => c.status === 'Pending Medical Director Review').length} pending</h2>
      {md.creds.map(c => <div key={c.id} className="a81-box mb-2" data-testid="a81-cred"><div className="a81-foot" style={{ justifyContent: 'flex-start', marginTop: 0 }}><b>{c.name}</b><span className="sv-small sv-muted">{c.specialty}</span><span className={`a81-pill ${c.status === 'Privileges Approved' ? 'ok' : c.status === 'Returned' ? 'warn' : ''}`} data-testid="a81-cred-status">{c.status}</span></div>
        <div className="a81-grid2 mt-1">{c.items.map(i => <div key={i.k} className="sv-small">{i.ok ? '✓' : '✗'} {i.k}</div>)}</div><div className="sv-small mt-1">Requested privileges: {c.privileges.join(', ')}</div>
        {c.decidedBy && <div className="sv-small a81-ok">{c.status} by {c.decidedBy} · {new Date(c.decidedAt!).toLocaleDateString()}{c.note ? ` · ${c.note}` : ''}</div>}
        {c.status === 'Pending Medical Director Review' && <div className="a81-foot"><button type="button" className="a8-btn" onClick={() => setSign({ title: 'Return application', what: `Return ${c.name}'s application (missing items)`, run: by => saveMd({ ...mdState(), creds: mdState().creds.map(x => x.id === c.id ? { ...x, status: 'Returned', decidedBy: by, decidedAt: new Date().toISOString(), note: c.items.filter(i => !i.ok).map(i => i.k).join('; ') || 'Returned' } : x) }) })} data-testid="a81-cred-return">Return</button>
          <button type="button" className="a8-btn pri" disabled={c.items.some(i => !i.ok)} title={c.items.some(i => !i.ok) ? 'Every item must be verified first' : ''} onClick={() => setSign({ title: 'Approve privileges', what: `Privileges for ${c.name}: ${c.privileges.join(', ')}`, run: by => saveMd({ ...mdState(), creds: mdState().creds.map(x => x.id === c.id ? { ...x, status: 'Privileges Approved', decidedBy: by, decidedAt: new Date().toISOString() } : x) }) })} data-testid="a81-cred-approve">Approve privileges</button></div>}</div>)}</section>
    <section className="v7-card a81-sec" data-testid="a81-md-policies"><h2 className="a8-h2">Annual reviews &amp; attestations</h2>{POL.map(p => { const r = latest(p); const due = r ? r.next : T; return <div key={p} className="a81-line" data-testid="a81-md-policy"><span style={{ flex: 1 }}>{p}</span><span className={`a81-pill ${r && r.next > T ? 'ok' : 'warn'}`}>{r ? `Reviewed ${r.at.slice(0, 10)} · next ${r.next}` : 'Review due'}</span>
      <button type="button" className="a8-btn sm" onClick={() => setSign({ title: 'Attest review', what: `${p} reviewed and approved for the next 12 months`, run: by => saveMd({ ...mdState(), reviews: [...mdState().reviews, { id: uid('rv'), what: p, by, at: new Date().toISOString(), next: addYear(T) }] }) })} data-testid="a81-md-attest">{due <= T ? 'Attest' : 'Re-attest'}</button></div>; })}
      <p className="sv-small sv-muted mt-1">Policy documents themselves live in Practice › Facility accreditation &amp; documents.</p></section>
    {sign && <PinSign title={sign.title} statement={<>As Medical Director ({md.director}), I attest: {sign.what}.</>} roles={['Surgeon', 'Anesthesiologist']} allow={p => p.name === md.director} onClose={() => setSign(null)} onSigned={s => { sign.run(s.name); repo.audit({ caseId: 'practice', user: s.name, role: s.role, action: 'asc81.md' as any, detail: `${sign.title}: ${sign.what} (PIN)` }); setSign(null); toast(`${sign.title} · signed by ${s.name}.`); }} />}
  </div>;
};
export const AuditPackPage: React.FC = () => { const { setTab } = useSv(); return <div className="sv-page" data-testid="a81-audit-page"><button type="button" className="sv-link text-[13px]" onClick={() => setTab('practice')}>‹ Practice</button><h1 className="sv-title mt-1">Accreditation &amp; audit pack</h1><div className="sv-sub mb-3">Per-case completeness: signed forms, OR times and op report. Manual download only (no automatic PDF). The shelved question bank remains an accreditation reference.</div><section className="v7-card a81-sec"><ExportPack /></section></div>; };

/* ---------------- v8.1 fictional seed ---------------- */
export const ASC81_SEED = 'asc81-seed-1';
export function ensureAsc81Seed() {
  if (svRead<string>('asc81-seeded', '') === ASC81_SEED) return; const d = (h: number) => new Date(Date.now() - h * 36e5).toISOString();
  const M = (pid: string, from: 'patient' | 'office', author: string, text: string, h: number) => { if (medRepo.patient(pid)) medRepo.addMessage({ id: uid('pm'), patientId: pid, from, author, text: `${text} (fictional)`, at: d(h) }); };
  M('ASC-2008', 'patient', 'Hugo Pell', 'Do I stop my apixaban before surgery tomorrow? Who decides the hold?', 5);
  M('ASC-2006', 'patient', 'Owen Marsh', 'Can I get a refill of my pain medication prescription sent to my pharmacy after the knee surgery?', 3);
  M('ASC-2007', 'patient', 'Celia Ortega', 'I got a statement for my surgery deposit — is the payment already applied to my invoice?', 8);
  M('ASC-2001', 'patient', 'Ada Kerr', 'Wrist is a little swollen today but pain is 2/10. Is that normal?', 20); M('ASC-2001', 'office', 'Casey Morgan (office)', 'Mild swelling is expected. Keep it elevated; call if pain rises or fingers go numb.', 19);
  svWrite('asc81-seeded', ASC81_SEED);
}

/* ---------------- Block time (v7.7 Schedule › Block Time) ---------------- */
export const BlockTimeDialog: React.FC<{ day: string; onClose: () => void }> = ({ day, onClose }) => {
  const [actor] = useActor(); const { toast } = useSv(); const surgeons = staffList().filter(s => /surgeon/i.test(s.role)).map(s => s.name);
  const [f, setF] = useState({ surgeon: surgeons[0] || S.PATEL, room: 'OR 1', date: day, start: '07:00', end: '12:00' }); const [err, setErr] = useState('');
  const save = () => { const t = (x: string) => { const [h, m] = x.split(':').map(Number); return `${String(((h + 11) % 12) + 1).padStart(2, '0')}:${String(m).padStart(2, '0')} ${h < 12 ? 'AM' : 'PM'}`; };
    if (f.end <= f.start) return setErr('End must be after start.'); const l = svRead<any[]>('block-seed', []);
    if (l.some(b => b.date === f.date && b.room === f.room && A.toMin(b.start) < A.toMin(t(f.end)) && A.toMin(t(f.start)) < A.toMin(b.end))) return setErr(`${f.room} already has block time then.`);
    svWrite('block-seed', [...l, { id: uid('blk'), surgeon: f.surgeon, date: f.date, start: t(f.start), end: t(f.end), room: f.room }]); repo.audit({ caseId: 'practice', user: actor.name, role: actor.role, action: 'asc81.block' as any, detail: `Block time ${f.surgeon} · ${f.room} · ${f.date} ${f.start}–${f.end}` }); window.dispatchEvent(new Event('vityls-med-updated')); toast('Block time saved.'); onClose(); };
  return <div className="a81-modal" onMouseDown={e => { if (e.target === e.currentTarget) onClose(); }}><div className="a81-dialog narrow" role="dialog" aria-label="Block time" data-testid="a81-block-dialog"><div className="a81-dhead"><b>Block time</b><span style={{ marginLeft: 'auto' }} /><XClose onClick={onClose} testId="a81-block-close" /></div>
    <div className="a81-dbody"><div className="a81-grid2"><label><span className="sv-label">Surgeon</span><select className="sv-input" value={f.surgeon} onChange={e => setF({ ...f, surgeon: e.target.value })} data-testid="a81-block-surgeon">{surgeons.map(s => <option key={s}>{s}</option>)}</select></label><label><span className="sv-label">Room</span><select className="sv-input" value={f.room} onChange={e => setF({ ...f, room: e.target.value })} data-testid="a81-block-room">{S.ROOMS.map(r => <option key={r}>{r}</option>)}</select></label>
      <label><span className="sv-label">Date</span><input type="date" className="sv-input" value={f.date} onChange={e => setF({ ...f, date: e.target.value })} /></label><div className="a81-grid2"><label><span className="sv-label">Start</span><input type="time" className="sv-input" value={f.start} onChange={e => setF({ ...f, start: e.target.value })} /></label><label><span className="sv-label">End</span><input type="time" className="sv-input" value={f.end} onChange={e => setF({ ...f, end: e.target.value })} /></label></div></div>
      {err && <p className="a81-err" data-testid="a81-block-err">{err}</p>}<div className="a81-foot"><button type="button" className="a8-btn pri" onClick={save} data-testid="a81-block-save">Save block</button></div></div></div></div>;
};
