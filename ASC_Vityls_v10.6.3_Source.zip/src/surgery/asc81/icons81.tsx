/* ASC.Vityls v8.1 · one distinct colored icon per station (light tint background), per Kevin's design direction. */
import React from 'react';
import { ClipboardList, HeartPulse, Wind, Stethoscope, Scissors, Activity, Receipt } from 'lucide-react';
import type { Station } from '../asc8/logic';
export const STATION_COLOR: Record<Station, { fg: string; bg: string; Icon: React.FC<any> }> = {
  front: { fg: '#2563eb', bg: '#e8f0fe', Icon: ClipboardList },
  preop: { fg: '#d6336c', bg: '#fde8ef', Icon: HeartPulse },
  anesthesia: { fg: '#7c3aed', bg: '#f1eafe', Icon: Wind },
  surgeon: { fg: '#0f766e', bg: '#e0f4f1', Icon: Stethoscope },
  or: { fg: '#ea580c', bg: '#fff0e5', Icon: Scissors },
  pacu: { fg: '#16a34a', bg: '#e6f7ec', Icon: Activity },
  billing: { fg: '#b45309', bg: '#fdf3dc', Icon: Receipt },
};
export const StationIcon: React.FC<{ st: Station; size?: number; boxed?: boolean }> = ({ st, size = 16, boxed }) => { const c = STATION_COLOR[st] || STATION_COLOR.billing; const I = c.Icon;
  return <span className={`a81-sticon ${boxed ? 'boxed' : ''}`} style={{ color: c.fg, background: c.bg }} data-station-icon={st} aria-hidden="true"><I size={size} /></span>; };
