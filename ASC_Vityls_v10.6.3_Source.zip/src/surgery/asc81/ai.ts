/* ASC.Vityls v8.1 · AI-first workbench logic ported from v7.7 (src/v77/logic.ts), adapted to the ASC2 case model.
 * Pure: no React, no storage. Nightingale drafts and suggests; it never signs, orders or decides. Externals are simulated. Fictional data. */
export type TeamId = 'front' | 'nursing' | 'anesthesia' | 'surgeon' | 'ma' | 'coordinator' | 'pm';
export interface CaseLite { id: string; name: string; stage?: string; encounterWorkflow?: any; scheduledTime?: string; room?: string; surgeon?: string; procedure?: string; gender?: string; age?: number; allergies?: string[]; [k: string]: any }
export interface Flag { id: string; toTeam: TeamId; fromName: string; fromTeam: TeamId; caseId?: string; patientName?: string; text: string; at: string; kind: 'flag'; auto?: boolean; status: 'open' }
let seq = 0;
export function newFlag(f: Omit<Flag, 'id' | 'at' | 'status' | 'kind'>): Flag { if (!f.text.trim()) throw new Error('Write what you need.'); return { ...f, kind: 'flag', id: `flag-${Date.now().toString(36)}-${(seq++).toString(36)}`, at: new Date().toISOString(), status: 'open', text: f.text.trim() }; }

/* ---------------- day summary strip ---------------- */
export const cleanProc = (p: string) => p.replace(/\s*\(fictional[^)]*\)/i, '').trim();
export const toMin = (t?: string) => { const m = (t || '').match(/(\d+):(\d+)\s*(AM|PM)?/i); if (!m) return NaN; let h = +m[1] % 12; if (/pm/i.test(m[3] || '')) h += 12; if (!m[3] && +m[1] === 12) h = 12; return h * 60 + +m[2]; };
export const fmtMin = (m: number) => { const h = Math.floor(m / 60), mm = m % 60; return `${((h + 11) % 12) + 1}:${String(mm).padStart(2, '0')} ${h < 12 ? 'AM' : 'PM'}`; };
export interface DaySummary { count: number; ageMin?: number; ageMax?: number; ageBands: Record<string, number>; procedures: [string, number][]; rooms: [string, number][]; busiest?: string; text: string }
export function daySummary(cases: (CaseLite & { estimatedDurationMins?: number })[]): DaySummary {
  const ages = cases.map(c => c.age).filter((a): a is number => typeof a === 'number');
  const bands: Record<string, number> = { '<40': 0, '40–64': 0, '65+': 0 }; ages.forEach(a => bands[a < 40 ? '<40' : a < 65 ? '40–64' : '65+']++);
  const cnt = (xs: string[]) => Object.entries(xs.reduce<Record<string, number>>((m, x) => (m[x] = (m[x] || 0) + 1, m), {})).sort((a, b) => b[1] - a[1]);
  const procedures = cnt(cases.map(c => cleanProc(c.procedure)));
  const rooms = cnt(cases.map(c => c.room || '—'));
  // busiest 2-hour window by cases starting in it
  const starts = cases.map(c => toMin(c.scheduledTime)).filter(n => !isNaN(n)).sort((a, b) => a - b);
  let best = 0, at = -1; starts.forEach(s => { const n = starts.filter(x => x >= s && x < s + 120).length; if (n > best) { best = n; at = s; } });
  const busiest = at >= 0 && rooms.length ? `${rooms[0][0]} busiest · ${fmtMin(at)}–${fmtMin(at + 120)}` : undefined;
  const ageTxt = ages.length ? `ages ${Math.min(...ages)}–${Math.max(...ages)}` : 'ages —';
  const text = `${cases.length} patient${cases.length === 1 ? '' : 's'} · ${ageTxt} · ${procedures.map(([p, n]) => `${n} ${p.toLowerCase()}`).join(', ') || 'no procedures'}${busiest ? ` · ${busiest}` : ''}`;
  return { count: cases.length, ageMin: ages.length ? Math.min(...ages) : undefined, ageMax: ages.length ? Math.max(...ages) : undefined, ageBands: bands, procedures, rooms, busiest, text };
}

/* ---------------- booking intake: email or scanned paper fax ---------------- */
export type IntakeSource = 'email' | 'fax';
export interface BookingDraft {
  source: IntakeSource; patientName: string; phone: string; email: string; age?: number; gender: string; dob: string;
  procedure: string; durationMins?: number; surgeon: string; assistant: string; paymentType: string; anesthesia: string; equipment: string; requestedDate: string;
  missing: string[]; confidence: Record<string, 'high' | 'low'>; ocr?: boolean;
}
const grab = (t: string, re: RegExp) => (t.match(re)?.[1] || '').trim();
/** Simulated Nightingale extraction (a rule-based stand-in for the BAA-covered AI/OCR service). */
export function parseBooking(text: string, source: IntakeSource): BookingDraft {
  const t = text.replace(/\r/g, '');
  const L = (k: string) => grab(t, new RegExp(`^\\s*(?:${k})\\s*[:#-]\\s*(.+)$`, 'im'));
  const name = L('patient(?: name)?|name');
  const age = +(L('age') || grab(t, /\b(\d{1,3})\s*(?:yo|y\/o|year[- ]old)/i)) || undefined;
  const g = (L('gender|sex') || grab(t, /\b(male|female)\b/i));
  const gender = /^f/i.test(g) ? 'Female' : /^m/i.test(g) ? 'Male' : '';
  const dur = L('(?:estimated )?duration|length|est\\.? time');
  const durationMins = dur ? (/h/i.test(dur) ? Math.round(parseFloat(dur) * 60) : parseInt(dur, 10)) || undefined : undefined;
  const d: BookingDraft = {
    source, patientName: name, phone: L('phone|tel(?:ephone)?|cell') || grab(t, /(\(\d{3}\)\s*\d{3}-\d{4})/), email: L('e-?mail') || grab(t, /([\w.+-]+@[\w-]+\.[\w.]+)/), age, gender, dob: L('dob|date of birth'),
    procedure: L('procedure|planned procedure|surgery'), durationMins, surgeon: L('surgeon'), assistant: L('assistant(?: surgeon)?|assist'), paymentType: L('payment(?: type)?|insurance|payer'),
    anesthesia: L('anesthesia(?: type)?|anesthesia planned'), equipment: L('(?:special )?equipment|implants?|vendor'), requestedDate: L('requested date|date requested|preferred date|date'),
    missing: [], confidence: {}, ocr: source === 'fax',
  };
  const need: [keyof BookingDraft, string][] = [['patientName', 'Patient name'], ['phone', 'Phone'], ['email', 'Email'], ['age', 'Age'], ['gender', 'Gender'], ['procedure', 'Procedure'], ['durationMins', 'Duration'], ['surgeon', 'Surgeon'], ['paymentType', 'Payment type'], ['anesthesia', 'Anesthesia type']];
  d.missing = need.filter(([k]) => !d[k]).map(([, l]) => l);
  need.forEach(([k]) => { d.confidence[k as string] = d[k] ? (source === 'fax' && /[|~]/.test(String(d[k])) ? 'low' : 'high') : 'low'; });
  return d;
}
export interface Busy { room?: string; scheduledTime?: string; estimatedDurationMins?: number; equipment?: string }
/** First open slot (7:00 AM–5:00 PM, 15-min steps) in any room that fits the duration with no overlap and no equipment clash. */
export function suggestSlot(dur: number, busy: Busy[], rooms: string[], equipment = ''): { room: string; time: string } | null {
  for (let m = 7 * 60; m + dur <= 17 * 60; m += 15) for (const r of rooms) {
    const clash = busy.some(b => { const s = toMin(b.scheduledTime); if (isNaN(s)) return false; const e = s + (b.estimatedDurationMins || 90); const overlap = m < e + 15 && s < m + dur + 15; return overlap && (b.room === r || (!!equipment && !!b.equipment && b.equipment.toLowerCase() === equipment.toLowerCase())); });
    if (!clash) return { room: r, time: fmtMin(m) };
  }
  return null;
}

/* ---------------- per-case booking checklist ---------------- */
export type ItemState = 'received' | 'missing' | 'abnormal';
export interface CheckItem { id: string; label: string; state: ItemState; note?: string; owner: 'patient' | 'surgeon office' | 'asc' }
export interface CaseSignals77 { portalForms: boolean; hp: boolean; labs: boolean; labsAbnormal?: boolean; ecg: boolean; clearance: boolean; consent: boolean; paid: boolean; ride: boolean; lodging: boolean }
export function bookingChecklist(s: CaseSignals77): CheckItem[] {
  const I = (id: string, label: string, ok: boolean, owner: CheckItem['owner'], abn = false, note?: string): CheckItem => ({ id, label, state: !ok ? 'missing' : abn ? 'abnormal' : 'received', owner, note });
  return [
    I('portal', 'Admission & registration forms', s.portalForms, 'patient'), I('hp', 'H&P', s.hp, 'surgeon office'), I('labs', 'Labs', s.labs, 'surgeon office', !!s.labsAbnormal, s.labsAbnormal ? 'See records brief' : undefined),
    I('ecg', 'ECG', s.ecg, 'surgeon office'), I('clearance', 'Pre-op clearance', s.clearance, 'surgeon office'), I('consent', 'Surgical consent', s.consent, 'surgeon office'),
    I('payment', 'Fees paid', s.paid, 'patient'), I('ride', 'Ride home & caregiver', s.ride, 'patient'), I('lodging', 'Post-op care location', s.lodging, 'patient'),
  ];
}
export const checklistLine = (items: CheckItem[]) => { const m = items.filter(i => i.state === 'missing'); const a = items.filter(i => i.state === 'abnormal'); return m.length || a.length ? `Ready except ${[...m.map(i => i.label.toLowerCase()), ...a.map(i => `${i.label.toLowerCase()} (abnormal)`)].join(', ')}` : 'Ready'; };
/** Drafted follow-up email (staff review and press Send; sending is simulated). No diagnosis or results in the body. */
export function followUpEmail(c: { name: string; email?: string; surgeon: string; dateLabel: string }, items: CheckItem[], to: 'patient' | 'surgeon office') {
  const need = items.filter(i => i.state === 'missing' && i.owner === to);
  if (!need.length) return null;
  const first = c.name.split(/\s+/)[0];
  const body = to === 'patient'
    ? `Hi ${first},\n\nWe're getting ready for your surgery on ${c.dateLabel}. We still need:\n${need.map(i => `• ${i.label}`).join('\n')}\n\nYou can complete these in your patient portal. Reply or call us with any questions.\n\nThank you,\nThe surgery center team`
    : `Hello,\n\nFor ${c.surgeon}'s patient scheduled on ${c.dateLabel}, we still need:\n${need.map(i => `• ${i.label}`).join('\n')}\n\nPlease send them by secure fax or the provider link.\n\nThank you,\nThe surgery center team`;
  return { to: to === 'patient' ? (c.email || '[patient email]') : `[${c.surgeon} office]`, subject: to === 'patient' ? 'Items needed before your surgery' : `Pre-op records needed · ${c.dateLabel}`, body, items: need.map(i => i.id) };
}

/* ---------------- the one readiness gate: check-in hands to nursing ---------------- */
export function checkInHandoff(c: CaseLite, by: string): Flag {
  return newFlag({ toTeam: 'nursing', fromName: by || 'Front desk', fromTeam: 'front', caseId: c.id, patientName: c.name, text: `${c.name} is checked in and ready for pre-op nursing.`, auto: true });
}

/* ---------------- parallel pre-op bedside ---------------- */
export type BedRole = 'nursing' | 'anesthesia' | 'surgeon';
export const BED_ROLES: { id: BedRole; label: string; station: string }[] = [{ id: 'nursing', label: 'Pre-op nurse', station: 'nursing' }, { id: 'anesthesia', label: 'Anesthesiologist', station: 'anesthesia' }, { id: 'surgeon', label: 'Surgeon', station: 'surgeon' }];
/** After check-in, every pre-op role's forms are open at once; nothing waits on another role. */
export const preopOpen = (c: CaseLite) => c.stage === 'PRE_OP' || ['READY_FOR_PREOP', 'PREOP_NURSING', 'READY_FOR_ANESTHESIA', 'ANESTHESIA_EVALUATION', 'READY_FOR_OR'].includes(c.encounterWorkflow?.status || '');
export interface BedLine { role: BedRole; text: string; target: string }
const ROUTES: [RegExp, BedRole, string][] = [
  [/\b(bp|blood pressure|heart rate|hr|pulse|spo2|o2 sat|temp|weight|height)\b/i, 'nursing', 'Vitals'],
  [/\b(npo|last (?:ate|food|drink|solid|liquid)|eat or drink|nothing to eat)\b/i, 'nursing', 'NPO status'],
  [/\b(denture|bridge|loose teeth|jewel|ring|contact lens|implant)\b/i, 'nursing', 'Belongings & implants'],
  [/\b(ride|driv\w*|pick (?:you|her|him) up|caregiver|hotel|airbnb|recovery facility)\b/i, 'nursing', 'Post-op care & ride'],
  [/\b(iv|angiocath|gauge)\b/i, 'nursing', 'IV site'],
  [/\b(mallampati|airway|mouth opening|neck|thyromental|dentition)\b/i, 'anesthesia', 'Airway exam'],
  [/\b(asa|anesthesia plan|general anesthesia|mac|sedation|block|nausea before|ponv)\b/i, 'anesthesia', 'Plan & ASA'],
  [/\b(lungs|heart sounds|murmur|clear to auscultation|regular rhythm)\b/i, 'anesthesia', 'Focused exam'],
  [/\b(mark(?:ed|ing)? (?:the )?site|site mark|left|right|laterality)\b/i, 'surgeon', 'Site marking'],
  [/\b(consent|risks|benefits|alternatives)\b/i, 'surgeon', 'Consent discussion'],
];
/** Split a bedside conversation into each role's draft. Speaker tags win ("Nurse:", "Anesthesia:", "Dr. Patel:"); otherwise topic routing. Patient lines go to the role that asked. */
export function splitBedside(transcript: string, who: Partial<Record<BedRole, string[]>> = {}): Record<BedRole, BedLine[]> {
  const out: Record<BedRole, BedLine[]> = { nursing: [], anesthesia: [], surgeon: [] };
  let last: BedRole | null = null; let lastTarget = 'Notes';
  for (const raw of transcript.split(/\n+/).map(s => s.trim()).filter(Boolean)) {
    const m = raw.match(/^([^:]{2,40}):\s*(.+)$/); const spk = (m?.[1] || '').toLowerCase(); const text = m ? m[2] : raw;
    const named = (r: BedRole) => (who[r] || []).some(n => spk.includes(n.toLowerCase().replace(/,.*$/, '').split(/\s+/).slice(-1)[0]));
    let role: BedRole | null = /nurse|\brn\b/.test(spk) || named('nursing') ? 'nursing' : /anesth|crna/.test(spk) || named('anesthesia') ? 'anesthesia' : /surgeon/.test(spk) || named('surgeon') ? 'surgeon' : null;
    const route = ROUTES.find(([re]) => re.test(text));
    if (!role && /patient/.test(spk)) role = last || route?.[1] || 'nursing';
    if (!role) role = route?.[1] || last || 'nursing';
    const own = ROUTES.find(([re, r]) => r === role && re.test(text))?.[2];
    const target = /patient/.test(spk) ? (own || lastTarget) : (own || 'Notes');
    out[role].push({ role, text: /patient/.test(spk) ? `Patient: ${text}` : text, target });
    if (!/patient/.test(spk)) { last = role; lastTarget = target; }
  }
  return out;
}

/* ---------------- pre-op records brief ---------------- */
export interface RecPage { doc: string; docTitle: string; page: number; date: string; text: string }
export interface BriefLine { kind: 'lab' | 'test' | 'problem' | 'med' | 'clearance' | 'conflict'; text: string; date?: string; abnormal?: boolean; src: { doc: string; page: number; title: string } }
const NOISE = /\b(phone (?:call|message)|telephone encounter|refill (?:request|sent)|no[- ]show|missed appointment|appointment reminder|portal message|left voicemail|billing)\b/i;
const RANGES: [RegExp, string, number, number, string][] = [
  [/potassium\s*[:=]?\s*(\d+(?:\.\d+)?)/i, 'Potassium', 3.5, 5.1, 'mmol/L'], [/sodium\s*[:=]?\s*(\d+(?:\.\d+)?)/i, 'Sodium', 135, 145, 'mmol/L'],
  [/(?:hgb|hemoglobin)\s*[:=]?\s*(\d+(?:\.\d+)?)/i, 'Hemoglobin', 12, 17.5, 'g/dL'], [/platelets?\s*[:=]?\s*(\d+(?:\.\d+)?)/i, 'Platelets', 150, 400, 'K/µL'],
  [/creatinine\s*[:=]?\s*(\d+(?:\.\d+)?)/i, 'Creatinine', 0.6, 1.3, 'mg/dL'], [/glucose\s*[:=]?\s*(\d+(?:\.\d+)?)/i, 'Glucose', 70, 140, 'mg/dL'],
  [/(?:hba1c|a1c)\s*[:=]?\s*(\d+(?:\.\d+)?)/i, 'HbA1c', 4, 6.4, '%'], [/\binr\s*[:=]?\s*(\d+(?:\.\d+)?)/i, 'INR', 0.8, 1.2, ''],
  [/\bwbc\s*[:=]?\s*(\d+(?:\.\d+)?)/i, 'WBC', 4, 11, 'K/µL'], [/qtc\s*[:=]?\s*(\d+)/i, 'QTc', 350, 450, 'ms'],
];
const PROBLEMS: [RegExp, string, number][] = [[/sleep apnea|\bosa\b/i, 'Obstructive sleep apnea', 1], [/type 2 diabetes|diabetes/i, 'Diabetes', 1], [/hypertension|\bhtn\b/i, 'Hypertension', 1], [/coronary|\bcad\b|stent|myocardial infarction/i, 'Coronary artery disease', 2], [/heart failure|\bchf\b/i, 'Heart failure', 2], [/copd|emphysema/i, 'COPD', 1], [/asthma/i, 'Asthma', 1], [/ckd|chronic kidney/i, 'Chronic kidney disease', 1], [/bmi\s*(?:of\s*)?(4\d|5\d)/i, 'Obesity (BMI ≥ 40)', 2], [/malignant hyperthermia/i, 'Family/personal history of malignant hyperthermia', 2], [/difficult (?:airway|intubation)/i, 'Prior difficult airway', 1]];
const MEDS: [RegExp, string][] = [[/eliquis|apixaban/i, 'Apixaban (Eliquis) — anticoagulant'], [/xarelto|rivaroxaban/i, 'Rivaroxaban — anticoagulant'], [/warfarin|coumadin/i, 'Warfarin — anticoagulant'], [/clopidogrel|plavix/i, 'Clopidogrel — antiplatelet'], [/semaglutide|ozempic|wegovy|tirzepatide|mounjaro/i, 'GLP-1 agonist'], [/metformin/i, 'Metformin'], [/insulin/i, 'Insulin']];
export interface Brief { kept: number; dropped: number; lines: BriefLine[]; asa: { cls: 1 | 2 | 3 | 4; why: string[] }; clearance?: BriefLine }
export function recordsBrief(pages: RecPage[], questionnaire: { denies?: string[] } = {}): Brief {
  const keep = pages.filter(p => !NOISE.test(p.text)); const lines: BriefLine[] = [];
  const src = (p: RecPage) => ({ doc: p.doc, page: p.page, title: p.docTitle });
  const probs = new Map<string, [number, RecPage]>();
  for (const p of keep) {
    for (const [re, name, lo, hi, unit] of RANGES) { const m = p.text.match(re); if (m) { const v = +m[1]; const ab = v < lo || v > hi; lines.push({ kind: name === 'QTc' ? 'test' : 'lab', text: `${name} ${v}${unit ? ' ' + unit : ''}${ab ? (v > hi ? ' (high)' : ' (low)') : ''}`, date: p.date, abnormal: ab, src: src(p) }); } }
    if (/\b(ecg|ekg|electrocardiogram)\b/i.test(p.text) && !/qtc/i.test(p.text)) lines.push({ kind: 'test', text: `ECG: ${grab(p.text, /(?:ecg|ekg)[^.:]*[:.]\s*([^.]+)/i) || 'reported'}`, date: p.date, src: src(p) });
    if (/\b(echo(?:cardiogram)?|stress test|sleep study|chest x-?ray)\b/i.test(p.text)) { const nm = p.text.match(/\b(echo(?:cardiogram)?|stress test|sleep study|chest x-?ray)\b/i)![1]; lines.push({ kind: 'test', text: `${nm[0].toUpperCase()}${nm.slice(1)}: ${grab(p.text, new RegExp(nm + '[^:]*:\\s*([^.]+)', 'i')) || 'see source'}`, date: p.date, abnormal: /abnormal|moderate|severe|reduced|ef\s*(?:of\s*)?[1-3]\d/i.test(p.text), src: src(p) }); }
    for (const [re, name, w] of PROBLEMS) if (re.test(p.text) && !probs.has(name)) probs.set(name, [w, p]);
    for (const [re, name] of MEDS) if (re.test(p.text) && !lines.some(l => l.kind === 'med' && l.text.startsWith(name))) { const hold = /hold|stop|discontinu/i.test(p.text); lines.push({ kind: 'med', text: `${name}${/anticoag|antiplatelet|GLP-1/.test(name) ? (hold ? ' · hold instructions present' : ' · no hold date found') : ''}`, date: p.date, abnormal: /anticoag|antiplatelet|GLP-1/.test(name) && !hold, src: src(p) }); }
    if (/clear(?:ed|ance) for (?:surgery|anesthesia)|medically optimized|acceptable risk/i.test(p.text)) lines.push({ kind: 'clearance', text: `Clearance: ${grab(p.text, /((?:cleared|clearance|medically optimized|acceptable risk)[^.]*)/i)}${grab(p.text, /(?:signed|by)\s+(Dr\.?\s+[A-Z][\w-]+(?:\s+[A-Z][\w-]+)?)/) ? ` — ${grab(p.text, /(?:signed|by)\s+(Dr\.?\s+[A-Z][\w-]+(?:\s+[A-Z][\w-]+)?)/)}` : ''}`, date: p.date, src: src(p) });
  }
  probs.forEach(([, p], name) => lines.push({ kind: 'problem', text: name, date: p.date, src: src(p) }));
  for (const d of questionnaire.denies || []) { const pr = [...probs.entries()].find(([n]) => n.toLowerCase().includes(d.toLowerCase()) || (d.toLowerCase() === 'osa' && /sleep apnea/i.test(n))); if (pr) lines.push({ kind: 'conflict', text: `Patient questionnaire denies ${d}, but the records show ${pr[0].toLowerCase()}`, date: pr[1][1].date, abnormal: true, src: src(pr[1][1]) }); }
  const score = [...probs.values()].reduce((s, [w]) => s + w, 0); const heavy = [...probs.values()].some(([w]) => w >= 2);
  const cls = (score === 0 ? 1 : heavy || score >= 3 ? 3 : 2) as 1 | 2 | 3;
  const why = probs.size ? [...probs.keys()] : ['No systemic disease found in the records'];
  return { kept: keep.length, dropped: pages.length - keep.length, lines, asa: { cls, why }, clearance: lines.find(l => l.kind === 'clearance') };
}

/* ---------------- nursing admission checklist ---------------- */
export interface NurseItem { id: string; label: string; value: string; source: string; verified: boolean; applies: boolean }
export const NURSE_ITEMS: [string, string][] = [
  ['postop', 'Post-operative care location'], ['caregiver', 'Person responsible for transport & care'], ['caregiverPhone', 'Contact telephone'], ['records', 'H&P, labs, ECG, clearance completed'],
  ['surgeonVisit', 'Pre-op visit by surgeon completed'], ['upt', 'Urine pregnancy test negative'], ['lmp', 'Last menstrual period'], ['consent', 'Surgical consent signed'], ['site', 'Patient verbalized site & plan'],
  ['npoSolid', 'NPO — last solids'], ['npoLiquid', 'NPO — last liquids'], ['dentures', 'Dentures / loose teeth / bridge removed'], ['jewelry', 'Jewelry removed'], ['implants', 'Metal implants'], ['contacts', 'Contact lenses removed'],
  ['dcInstr', 'Discharge instructions provided'], ['iv', 'IV site & placed by'], ['orders', 'Surgeon pre-op orders reviewed (antibiotics, etc.)'], ['notes', 'Nursing notes'],
];
export const uptApplies = (gender?: string, age?: number) => /^f/i.test(gender || '') && (age ?? 0) >= 11 && (age ?? 99) <= 55;
export function nursingPrefill(c: CaseLite, known: Record<string, string>): NurseItem[] {
  return NURSE_ITEMS.map(([id, label]) => ({ id, label, value: known[id] || '', source: known[id] ? (known[`${id}.src`] || 'Patient questionnaire') : '', verified: false, applies: (id === 'upt' || id === 'lmp') ? uptApplies(c.gender, c.age) : true }));
}
export function nursingConflicts(meds: string[], items: NurseItem[]): string[] {
  const out: string[] = []; const m = meds.join(' ');
  for (const [re, name] of MEDS) if (re.test(m) && /anticoag|antiplatelet|GLP-1/.test(name) && !/hold|stopped|last dose/i.test(m)) out.push(`${name.split(' — ')[0]} on the medication list, but no hold date.`);
  if (items.find(i => i.id === 'caregiver' && i.applies && !i.value)) out.push('No responsible adult for the ride home yet.');
  return out;
}
/** Place dictated exceptions ("bridge removed, left knee implant") into the right checkbox. */
export function applyDictation(items: NurseItem[], said: string): NurseItem[] {
  const parts = said.split(/[,;.\n]+/).map(s => s.trim()).filter(Boolean); const next = items.map(i => ({ ...i }));
  const put = (id: string, v: string) => { const it = next.find(i => i.id === id); if (it) { it.value = v; it.source = 'Dictated by nurse'; } };
  for (const p of parts) {
    if (/denture|bridge|loose teeth/i.test(p)) put('dentures', p); else if (/jewel|ring|earring|piercing/i.test(p)) put('jewelry', p); else if (/implant|hardware|replacement|pacemaker/i.test(p)) put('implants', p);
    else if (/contact/i.test(p)) put('contacts', p); else if (/\biv\b|gauge|angiocath/i.test(p)) put('iv', p); else if (/last (?:ate|solid|food)/i.test(p)) put('npoSolid', p); else if (/last (?:drank|liquid|water|clear)/i.test(p)) put('npoLiquid', p);
    else if (/lmp|period/i.test(p)) put('lmp', p); else if (/upt|pregnan/i.test(p)) put('upt', p); else { const n = next.find(i => i.id === 'notes')!; n.value = [n.value, p].filter(Boolean).join('; '); n.source = 'Dictated by nurse'; }
  }
  return next;
}
export interface Vitals { bp?: string; hr?: number; rr?: number; temp?: number; spo2?: number; height?: string; weight?: string }
export function vitalFlags(v: Vitals): string[] {
  const f: string[] = []; const [s, d] = (v.bp || '').split('/').map(Number);
  if (s >= 180 || d >= 110) f.push(`BP ${v.bp} is high`); else if (s && s < 90) f.push(`BP ${v.bp} is low`);
  if (v.hr && (v.hr > 110 || v.hr < 50)) f.push(`HR ${v.hr}`); if (v.spo2 && v.spo2 < 92) f.push(`SpO₂ ${v.spo2}%`); if (v.temp && v.temp >= 100.4) f.push(`Temp ${v.temp}°F`); if (v.rr && (v.rr > 24 || v.rr < 10)) f.push(`RR ${v.rr}`);
  return f;
}

/* ---------------- PACU ---------------- */
export interface PacuTask { id: string; text: string; done?: { by: string; at: string } }
export const USUAL_ORDERS = ['Ondansetron 4 mg IV q6h PRN nausea', 'Fentanyl 25 mcg IV q5min PRN pain > 5, max 100 mcg', 'Acetaminophen 1 g PO once if not given intra-op', 'O₂ to keep SpO₂ ≥ 94%', 'Discharge when Aldrete ≥ 9 twice and pain ≤ 4'];
export const ordersToTasks = (orders: string[]): PacuTask[] => orders.filter(o => o.trim()).map((text, i) => ({ id: `t${i + 1}`, text: text.trim() }));
export interface Aldrete { activity: number; respiration: number; circulation: number; consciousness: number; spo2: number; pain?: number; at: string }
export const aldreteTotal = (a: Aldrete) => a.activity + a.respiration + a.circulation + a.consciousness + a.spo2;
export function pacuAlerts(list: Aldrete[]): { ready: boolean; alerts: string[] } {
  const alerts: string[] = []; const n = list.length; if (!n) return { ready: false, alerts };
  const last = list[n - 1]; const prev = list[n - 2];
  const ready = n >= 2 && aldreteTotal(last) >= 9 && aldreteTotal(prev) >= 9 && (last.pain ?? 0) <= 4;
  if (prev && aldreteTotal(last) < aldreteTotal(prev)) alerts.push(`Aldrete fell ${aldreteTotal(prev)} → ${aldreteTotal(last)}`);
  if (prev && (last.pain ?? 0) > (prev.pain ?? 0) && (last.pain ?? 0) >= 6) alerts.push(`Pain rising to ${last.pain}/10`);
  if (last.spo2 < 2) alerts.push('SpO₂ score below 2');
  if (ready) alerts.unshift('Discharge criteria met (Aldrete ≥ 9 twice, pain ≤ 4)');
  return { ready, alerts };
}

/* ---------------- discharge, next-day text, survey ---------------- */
const LANG: Record<string, Record<string, string>> = {
  English: { h: 'Going home after your', ride: 'Your ride home', call: 'Call us at', fever: 'Call right away for fever over 101°F, bleeding that soaks the dressing, or pain not helped by medicine.', meds: 'Medicines', diet: 'Start with clear liquids, then a light diet as you feel ready.', drive: 'Do not drive, drink alcohol or sign legal papers for 24 hours.' },
  Spanish: { h: 'Regreso a casa después de su', ride: 'Quién lo lleva a casa', call: 'Llámenos al', fever: 'Llame de inmediato si tiene fiebre de más de 101°F, sangrado que empape el vendaje o dolor que no mejora con la medicina.', meds: 'Medicinas', diet: 'Empiece con líquidos claros y luego una dieta ligera.', drive: 'No maneje, no tome alcohol ni firme documentos legales por 24 horas.' },
};
const PROC_CARE: [RegExp, string][] = [[/knee|arthroscop/i, 'Keep the leg raised, ice 20 minutes every hour while awake, and use crutches as shown.'], [/carpal|hand|wrist/i, 'Keep the hand above heart level and move your fingers often. Keep the dressing dry.'], [/excision|lesion|skin/i, 'Keep the dressing dry for 48 hours, then wash gently.'], [/hernia/i, 'No lifting over 10 lb for 2 weeks.'], [/cataract|eye/i, 'Wear the eye shield at night and use drops as directed.']];
export function dischargeDraft(c: CaseLite, o: { language?: string; ride?: string; caregiver?: string; meds?: string[]; phone?: string }): string {
  const L = LANG[o.language || 'English'] || LANG.English;
  const care = PROC_CARE.find(([re]) => re.test(c.procedure))?.[1] || 'Follow your surgeon\u2019s wound-care instructions.';
  return [`${L.h} ${cleanProc(c.procedure).toLowerCase()}`, ``, care, L.diet, L.drive, ``, `${L.meds}: ${(o.meds || []).join('; ') || '[confirm with surgeon]'}`, `${L.ride}: ${o.ride || '[confirm]'}${o.caregiver ? ` · ${o.caregiver}` : ''}`, ``, L.fever, `${L.call} ${o.phone || '(555) 010-0000'}.`].join('\n');
}
export const addDays = (iso: string, n: number) => { const d = new Date(iso + 'T10:00:00'); d.setDate(d.getDate() + n); return d.toISOString().slice(0, 10); };
export interface Followups { nextDayText: { on: string; body: string }; survey: { on: string; form: string } }
/** Next-day check-in text (on), then the survey form one week after surgery. Both simulated. */
export function followups(surgeryIso: string, first: string): Followups {
  return { nextDayText: { on: addDays(surgeryIso, 1), body: `Hi ${first}, this is your surgery center checking in. How are you feeling today? Reply 1 = good, 2 = some pain or nausea, 3 = please call me.` }, survey: { on: addDays(surgeryIso, 7), form: 'Patient Satisfaction Survey' } };
}
const CONCERN = /\b(3|fever|bleed|bleeding|pus|swollen|severe|worse|can'?t|vomit|call me|unhappy|rude|terrible|chest pain|short of breath)\b/i;
export function triageReply(text: string): { concern: boolean; summary: string } {
  const concern = CONCERN.test(text.trim());
  return { concern, summary: concern ? `Concern: “${text.trim().slice(0, 120)}” — nursing to call back` : `Doing well: “${text.trim().slice(0, 120)}”` };
}

/* ---------------- accreditation / audit pack ---------------- */
export interface CaseAudit { id: string; name: string; forms: { file: string; title: string; signed: boolean }[]; times: number; opReport: boolean }
export function accreditationPack(rows: CaseAudit[]): { lines: string[]; complete: number; total: number } {
  const lines = ['ASC.Vityls accreditation completeness (fictional test data)', `Generated ${new Date().toLocaleString()}`, ''];
  let complete = 0;
  for (const r of rows) { const uns = r.forms.filter(f => !f.signed); const ok = !uns.length && r.times >= 6 && r.opReport; if (ok) complete++; lines.push(`${r.name}: ${ok ? 'complete' : 'incomplete'} · ${r.forms.length - uns.length}/${r.forms.length} forms signed · OR times ${r.times}/6 · op report ${r.opReport ? 'signed' : 'open'}${uns.length ? ` · unsigned: ${uns.map(f => f.title).join(', ')}` : ''}`); }
  lines.push('', `${complete} of ${rows.length} cases complete.`);
  return { lines, complete, total: rows.length };
}

/* ---------------- chat commands ---------------- */
export type Cmd = { kind: 'intake' | 'brief' | 'bedside' | 'nursing' | 'pacu' | 'discharge' | 'after' | 'export' | 'forms' | 'checkin' | 'open' | 'today' | 'help'; who?: string };
export function parseCommand(q: string): Cmd {
  const s = q.toLowerCase(); const who = (q.match(/\b(?:for|of)\s+([A-Z][\w'-]+(?:\s+[A-Z][\w'-]+)?)/)?.[1]) || undefined;
  if (/fax|email|book|booking|intake|new case/.test(s)) return { kind: 'intake', who };
  if (/brief|records|labs?|clearance|asa/.test(s)) return { kind: 'brief', who };
  if (/bedside|ambient|conversation|listen/.test(s)) return { kind: 'bedside', who };
  if (/admission|nursing|checklist|vitals|pre-?op/.test(s)) return { kind: 'nursing', who };
  if (/pacu|aldrete|orders/.test(s)) return { kind: 'pacu', who };
  if (/discharge|instructions/.test(s)) return { kind: 'discharge', who };
  if (/survey|text|follow.?up|next.?day/.test(s)) return { kind: 'after', who };
  if (/audit|accredit|export|completeness/.test(s)) return { kind: 'export', who };
  if (/form|template|editor/.test(s)) return { kind: 'forms', who };
  if (/check.?in|arriv/.test(s)) return { kind: 'checkin', who };
  if (/open|chart|show/.test(s) && who) return { kind: 'open', who };
  if (/today|how many|traffic|schedule|summary/.test(s)) return { kind: 'today', who };
  return { kind: 'help', who };
}
