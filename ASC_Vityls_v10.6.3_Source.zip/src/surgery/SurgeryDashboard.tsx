/*
 * Surgery.Vityls Today (dashboard). Tablet-first. ASC-like structure: today's patients as expanded cards
 * (visit-type color stripe, name, age, gender, phone, reason, station) with Check in → station and Open → chart,
 * then a short "needs attention" column and what is coming up at the ASC. Colors match the schedule.
 */
import React, { useState } from 'react';
import { medRepo, MedVisit, isoDay, addDays, usDate, ageFrom, toMin, patientKey } from '../med/record';
import { getProviders, displayName } from '../v7/providers';
import { effectiveAllergy } from '../v7/allergy';
import { useActor, useMedTick } from '../med/ui';
import { ascBlocks, ascCases, checkoutOrders, edgeOf, modules, visitTypeDef } from './store';
import { STATION_LABEL, R, awaitingLabs, lastFrom, nextAscCase, openRisks, relDay, slipRef, daysFrom } from './nightingale';
import { useSv } from './ui';
import { repo } from '../v6/dataLayer';
import { arriveVisit, checkInVisit } from './SurgeryStation';
import { Ico } from './icons';
import { AddNewPatientButton } from './newPatient';
import { ConfBadge, ReminderDialog } from './reminders';

type Filter = 'all' | 'waiting' | 'in' | 'done';
const order = (v: MedVisit) => toMin(v.time);

export const SurgeryDashboard: React.FC = () => {
  useMedTick(); const [actor] = useActor(); const { go, setTab } = useSv(); const mods = modules();
  const [filter, setFilter] = useState<Filter>('all'); const [prov, setProv] = useState('');
  const T = isoDay(); const [day, setDay] = useState(() => sessionStorage.getItem('sv-today-day') || T); const pickDay = (d: string) => { if (!d) return; setDay(d); sessionStorage.setItem('sv-today-day', d); };
  const all = medRepo.visits().filter(v => v.date === day).sort((a, b) => order(a).localeCompare(order(b)));
  const providers = getProviders().filter(p => p.active).map(displayName);
  const list = all.filter(v => (!prov || v.provider === prov) && (filter === 'all' || (filter === 'waiting' ? v.step === 'scheduled' : filter === 'done' ? v.step === 'complete' : v.step !== 'scheduled' && v.step !== 'complete')));
  const counts = { waiting: all.filter(v => v.step === 'scheduled').length, in: all.filter(v => v.step !== 'scheduled' && v.step !== 'complete').length, done: all.filter(v => v.step === 'complete').length };
  // needs attention
  const labs = awaitingLabs(); const labPts = Array.from(new Set(labs.map(l => l.patientId)));
  const unsigned = medRepo.visits().filter(v => { const n = medRepo.note(v.id); return n && n.status !== 'signed'; });
  const todos = checkoutOrders().filter(o => o.status === 'to-do');
  const riskPts = mods.riskAwareness && mods.networkAsc ? medRepo.patients().filter(p => { const nc = nextAscCase(p.id); return nc && daysFrom(nc.date) <= 21 && openRisks(p).length > 0; }) : [];
  const msgPts = medRepo.patients().filter(p => lastFrom(p.id));
  const asc = [...(mods.blockTime ? ascBlocks().filter(b => b.date >= T && b.date <= addDays(T, 7)).map(b => ({ k: b.date + toMin(b.start), date: b.date, text: `Block · ${b.surgeon.replace(/,.*$/, '')} · ${b.start.replace(/^0/, '')}–${b.end.replace(/^0/, '')} · ${b.room}`, pid: '' })) : []),
    ...(mods.networkAsc ? ascCases().filter(c => c.date >= T && c.date <= addDays(T, 7)).map(c => ({ k: c.date + toMin(c.time), date: c.date, text: `${c.time.replace(/^0/, '')} · ${c.patientName} · ${c.procedure}`, pid: medRepo.patients().find(p => p.name === c.patientName && p.dob === c.dob)?.id || '' })) : [])].sort((a, b) => a.k.localeCompare(b.k));
  return <div className="sv-page" data-testid="sv-dashboard">
    <div className="flex flex-wrap items-end justify-between gap-2 mb-3">
      <div><div className="sv-daynav" data-testid="today-datenav">
          <button type="button" className="sv-btn sm" onClick={() => pickDay(addDays(day, -1))} aria-label="Previous day" data-testid="today-prev">‹</button>
          <h1 className="sv-title" data-testid="today-title">{day === T ? 'Today · ' : ''}{new Date(day + 'T12:00').toLocaleDateString([], { weekday: 'long', month: 'long', day: 'numeric', ...(day.slice(0, 4) !== T.slice(0, 4) ? { year: 'numeric' } : {}) })}</h1>
          <button type="button" className="sv-btn sm" onClick={() => pickDay(addDays(day, 1))} aria-label="Next day" data-testid="today-next">›</button>
          <input type="date" className="sv-input" style={{ width: 'auto' }} value={day} onChange={e => pickDay(e.target.value)} aria-label="Choose a date" data-testid="today-date" />
          {day !== T && <button type="button" className="sv-btn sm" onClick={() => pickDay(T)} data-testid="today-today">Today</button>}
        </div>
        <div className="sv-sub">{all.length} patient{all.length === 1 ? '' : 's'} scheduled{day === T ? ` · ${counts.waiting} not arrived · ${counts.in} in the office · ${counts.done} done` : day > T ? ' · upcoming' : ''} · tablet session: {actor.name}</div></div>
      <div className="flex flex-wrap items-center gap-2">
        <AddNewPatientButton />
        <div className="sv-seg" role="group" aria-label="Filter">{([['all', `All ${all.length}`], ['waiting', `Not arrived ${counts.waiting}`], ['in', `In office ${counts.in}`], ['done', `Done ${counts.done}`]] as [Filter, string][]).map(([k, l]) => <button key={k} type="button" aria-pressed={filter === k} onClick={() => setFilter(k)} data-testid={`dash-f-${k}`}>{l}</button>)}</div>
        <select className="sv-input" style={{ width: 'auto' }} value={prov} onChange={e => setProv(e.target.value)} aria-label="Provider"><option value="">All providers</option>{providers.map(p => <option key={p}>{p}</option>)}</select>
      </div>
    </div>
    <div className="sv-dash">
      <section aria-label="Today's patients" data-testid="dash-patients">
        {list.length === 0 ? <p className="sv-muted text-[13.5px]">No patients scheduled in this view. <button type="button" className="sv-link" onClick={() => setTab('schedule')}>Open the schedule</button></p> : list.map(v => <PatientCard key={v.id} v={v} isToday={day === T} />)}
      </section>
      <aside className="space-y-5" aria-label="Needs attention">
        <div data-testid="dash-attention"><h2 className="sv-h flex items-center gap-1.5"><Ico k="risk" />Needs attention</h2>
          <ul className="text-[13.5px] space-y-1.5 sv-att">
            {labPts.map(pid => { const l = labs.filter(x => x.patientId === pid); return <li key={pid}><Ico k="lab" className="!text-[var(--crit)]" /><button type="button" className="sv-link" onClick={() => go({ type: 'chart', pid, ref: slipRef(l[l.length - 1].collectedAt, pid) })}>{l.length} result{l.length === 1 ? '' : 's'} to review · {medRepo.patient(pid)?.name}</button></li>; })}
            {riskPts.map(p => { const nc = nextAscCase(p.id)!; return <li key={p.id}><Ico k="risk" className="!text-[var(--warn)]" /><button type="button" className="sv-link" onClick={() => go({ type: 'chart', pid: p.id, ref: R('risk', 'Risk awareness', p.id) })}>{openRisks(p).length} risk factor{openRisks(p).length === 1 ? '' : 's'} to review · {p.name} · surgery {relDay(nc.date)}</button></li>; })}
            {unsigned.map(v => <li key={v.id}><Ico k="note" /><button type="button" className="sv-link" onClick={() => go({ type: 'station', visitId: v.id })}>Unsigned note · {medRepo.patient(v.patientId)?.name} · {usDate(v.date)}</button></li>)}
            {todos.map(o => <li key={o.id}><Ico k={o.kind === 'surgery-booking' ? 'asc' : o.kind === 'follow-up' ? 'visit' : 'form'} /><button type="button" className="sv-link" onClick={() => go({ type: 'station', visitId: o.visitId })}>Checkout to-do · {o.text} · {medRepo.patient(o.patientId)?.name}</button></li>)}
            {msgPts.length > 0 && <li><Ico k="message" /><button type="button" className="sv-link" onClick={() => setTab('messages')}>{msgPts.length} portal message{msgPts.length === 1 ? '' : 's'} waiting</button></li>}
            {!labPts.length && !riskPts.length && !unsigned.length && !todos.length && !msgPts.length && <li className="sv-muted">Nothing waiting.</li>}
          </ul></div>
        {(mods.networkAsc || mods.blockTime) && <div data-testid="dash-asc"><h2 className="sv-h flex items-center gap-1.5"><Ico k="asc" />At the ASC · next 7 days</h2>
          {asc.length === 0 ? <p className="sv-muted text-[13px]">Nothing booked.</p> : <table className="sv-table"><tbody>{asc.map((x, i) => <tr key={i}><td className="whitespace-nowrap sv-muted" style={{ width: 70 }}>{x.date === T ? 'Today' : usDate(x.date).slice(0, 5)}</td><td>{x.pid ? <button type="button" className="sv-link" onClick={() => go({ type: 'chart', pid: x.pid, ref: R('asc', 'Network ASC', x.pid) })}>{x.text}</button> : <span className={x.text.startsWith('Block') ? 'sv-muted' : ''}>{x.text}</span>}</td></tr>)}</tbody></table>}
          <button type="button" className="sv-link text-[12.5px] mt-1" onClick={() => setTab('schedule')}>Schedule</button></div>}
      </aside>
    </div>
  </div>;
};

const PatientCard: React.FC<{ v: MedVisit; isToday: boolean }> = ({ v, isToday }) => {
  const { go, toast } = useSv(); const [actor] = useActor(); const [rm, setRm] = useState(false); const p = medRepo.patient(v.patientId); if (!p) return null;
  const facts = repo.getFacts(v.id); const arrived = facts['visit.arrived']?.value as string | undefined; const checked = facts['visit.checkedIn']?.value as string | undefined;
  const t = visitTypeDef(v.visitType); const a = effectiveAllergy(p.allergies, patientKey(p.id)); const nc = nextAscCase(p.id); const labs = awaitingLabs(p.id).length;
  const primary = v.step === 'scheduled' ? (isToday ? 'Check in' : 'Open workflow') : v.step === 'complete' ? 'Visit record' : `Continue · ${STATION_LABEL[v.step]}`;
  return <article className={`sv-pcard ${v.step === 'complete' ? 'is-done' : ''}`} data-testid="dash-card" aria-label={`${p.name}, ${v.time}`}>
    <div className="stripe" style={{ background: t.color, borderRight: `1px solid ${edgeOf(t.color)}` }} />
    <div className="body">
      <div className="flex flex-wrap items-baseline gap-x-2"><span className="text-[13px] font-semibold tabular-nums" style={{ minWidth: 62 }}>{v.time.replace(/^0/, '')}</span><span className="nm">{p.name}</span><span className="text-[13px] sv-muted">{ageFrom(p.dob)} · {p.sex} · {p.phone}</span></div>
      <div className="text-[13px] mt-0.5" style={{ paddingLeft: 70 }}>{v.reason || '—'}</div>
      <div className="text-[12.5px] mt-1 flex flex-wrap items-center gap-x-2 gap-y-1" style={{ paddingLeft: 70 }}>
        <span className="inline-flex items-center rounded px-1.5" style={{ background: t.color, border: `1px solid ${edgeOf(t.color)}` }}>{v.visitType}</span>
        <span className="sv-muted">{v.provider.replace(/,.*$/, '')} · {v.room}</span>
        <span className={`sv-tag ${v.step === 'complete' ? 'ok' : v.step === 'scheduled' ? '' : 'n'}`} data-testid="dash-card-step">{STATION_LABEL[v.step]}</span>
        {arrived && <span className="sv-tag ok" data-testid="dash-arrived">Arrived {arrived}</span>}{checked && <span className="sv-tag ok" data-testid="dash-checkedin">Checked in {checked}</span>}
        {a.state !== 'nkda' && a.state !== 'not-reported' && <span className="text-[var(--crit)]">Allergies: {a.text}</span>}
        {labs > 0 && <span className="sv-tag crit">{labs} result{labs === 1 ? '' : 's'} to review</span>}
        {nc && <span className="sv-tag">Surgery {relDay(nc.date)}</span>}
        {v.step === 'scheduled' && <ConfBadge v={v} onClick={() => setRm(true)} />}{rm && <ReminderDialog visitId={v.id} onClose={() => setRm(false)} />}
      </div>
    </div>
    <div className="acts">
      {isToday && !arrived && v.step === 'scheduled' && <button type="button" className="sv-btn" onClick={() => { arriveVisit(v, actor.name, actor.role); toast(`${p.name} arrived · time recorded.`); }} data-testid="dash-arrive">Arrived</button>}
      <button type="button" className={`sv-btn ${v.step === 'complete' ? '' : 'primary'}`} onClick={() => { if (isToday && v.step === 'scheduled') { checkInVisit(v, actor.name, actor.role); toast(`${p.name} checked in · time recorded.`); } go({ type: 'station', visitId: v.id }); }} data-testid="dash-checkin">{primary}</button>
      <button type="button" className="sv-btn" onClick={() => go({ type: 'chart', pid: p.id })} data-testid="dash-open">Open</button>
    </div>
  </article>;
};
