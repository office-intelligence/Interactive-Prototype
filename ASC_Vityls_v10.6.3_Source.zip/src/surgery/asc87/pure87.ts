/* ASC.Vityls v8.7 · pure logic (unit-tested): standing doctor's orders list, cash-pay invoice math, Today to-do ordering.
 * Seeded standing orders are EXAMPLES FOR MEDICAL DIRECTOR APPROVAL (Kevin asked for predefined doses). Fictional data. */
export type OrderCat = 'Pre-op' | 'Post-op' | 'PACU';
export interface StandingOrder { id: string; category: OrderCat; text: string; drug?: string; dose?: string; route?: string; freq?: string; active: boolean; signer: 'surgeon' | 'anesthesia'; example?: boolean }
export const EXAMPLE_LABEL = 'Example · for Medical Director approval';
const S = (id: string, category: OrderCat, text: string, signer: StandingOrder['signer'], drug = '', dose = '', route = '', freq = ''): StandingOrder => ({ id, category, text, drug, dose, route, freq, active: true, signer, example: true });
export const STANDING_SEED: StandingOrder[] = [
  S('so-1', 'Pre-op', 'Surgical antibiotic prophylaxis within 60 min before incision', 'surgeon', 'Cefazolin', '2 g', 'IV', 'Once'),
  S('so-2', 'Pre-op', 'If beta-lactam allergy: alternative prophylaxis', 'surgeon', 'Clindamycin', '900 mg', 'IV', 'Once'),
  S('so-3', 'Pre-op', 'Pre-emptive analgesia', 'anesthesia', 'Acetaminophen', '1000 mg', 'PO', 'Once'),
  S('so-4', 'Pre-op', 'PONV prophylaxis (high-risk patients)', 'anesthesia', 'Scopolamine patch', '1.5 mg', 'Transdermal', 'Once'),
  S('so-5', 'Pre-op', 'Sequential compression devices on before induction', 'surgeon'),
  S('so-6', 'Pre-op', 'Fingerstick glucose on arrival for diabetic patients', 'anesthesia'),
  /* v10.2: PACU entries = the facility's PACU & Post Anesthesia Orders form (form library) */
  S('so-7', 'PACU', 'Vital signs: BP, HR, RR and SpO₂ every 15 min through Phase I recovery', 'anesthesia'),
  S('so-8', 'PACU', 'Oxygen by nasal cannula to keep SpO₂ > 92%', 'anesthesia', 'Oxygen', 'Titrate', 'Nasal cannula', 'Titrate'),
  S('so-9', 'PACU', 'Pain', 'anesthesia', 'Fentanyl', '25 mcg', 'IV', 'repeat in 10 min × 4 PRN'),
  S('so-10', 'PACU', 'Pain', 'anesthesia', 'Hydromorphone', '1 mg', 'IV', 'repeat in 20 min × 2 PRN'),
  S('so-10b', 'PACU', 'Pain', 'anesthesia', 'Ketorolac', '30 mg', 'IV', 'repeat in 10 min × 2 PRN'),
  S('so-10c', 'PACU', 'Pain', 'anesthesia', 'Acetaminophen', '1000 mg', 'IV / PO', 'Once'),
  S('so-11', 'PACU', 'Nausea / vomiting', 'anesthesia', 'Ondansetron (Zofran)', '4 mg', 'IV', 'Once'),
  S('so-11b', 'PACU', 'Nausea', 'anesthesia', 'Promethazine', '12.5 mg', 'IV', 'PRN'),
  S('so-11c', 'PACU', 'Nausea', 'anesthesia', 'Metoclopramide', '10 mg', 'IV', 'PRN'),
  S('so-11d', 'PACU', 'Nausea', 'anesthesia', 'Dexamethasone', '4 mg', 'IV', 'PRN'),
  S('so-11e', 'PACU', 'Hypothermia below 36 °C (96.8 °F): forced-air warming blanket', 'anesthesia'),
  S('so-11f', 'PACU', 'IV fluids until oral intake resumes', 'anesthesia', "Lactated Ringer's or Normal Saline", '100 mL/hr', 'IV', 'Continuous'),
  S('so-12', 'PACU', 'Modified Aldrete every 30 min; discharge from PACU when ≥ 9', 'anesthesia'),
  S('so-13', 'Post-op', 'Mild–moderate pain at home', 'surgeon', 'Ibuprofen', '600 mg', 'PO', 'q6 h PRN with food'),
  S('so-14', 'Post-op', 'Moderate–severe pain at home', 'surgeon', 'Oxycodone', '5 mg', 'PO', 'q4–6 h PRN, #12'),
  S('so-15', 'Post-op', 'Diet as tolerated; ice 20 min on / 20 min off', 'surgeon'),
  S('so-16', 'Post-op', 'Follow-up with surgeon in 7–14 days', 'surgeon'),
];
export const CAT_PHASE: Record<OrderCat, 'preop' | 'postop' | 'pacu'> = { 'Pre-op': 'preop', 'Post-op': 'postop', PACU: 'pacu' };
export const orderLine = (o: Pick<StandingOrder, 'text' | 'drug' | 'route' | 'freq'>) => o.drug ? `${o.drug} · ${o.route || ''} · ${o.freq || ''} — ${o.text}`.replace(/ · {2}·/g, ' ·') : o.text;
export const move = <T,>(l: T[], i: number, d: -1 | 1): T[] => { const j = i + d; if (j < 0 || j >= l.length) return l; const n = [...l]; [n[i], n[j]] = [n[j], n[i]]; return n; };

/* invoice */
export interface InvLine { label: string; detail: string; amount: number }
export interface Payment { amount: number; at: string; method: string; receipt: string }
export const r2 = (n: number) => Math.round(n * 100) / 100;
export function invoiceTotals(lines: InvLine[], pays: Payment[]) { const total = r2(lines.reduce((s, l) => s + l.amount, 0)); const paid = r2(pays.reduce((s, p) => s + p.amount, 0)); const balance = r2(Math.max(0, total - paid));
  const status = !total ? 'Draft' : paid <= 0 ? 'Issued · unpaid' : balance > 0 ? 'Partially paid' : 'Paid in full'; return { total, paid, balance, credit: r2(Math.max(0, paid - total)), status }; }
export const invoiceNumber = (dos: string, seq: number) => `INV-ASC-${dos.slice(0, 4)}-${String(seq).padStart(4, '0')}`;
export const isCash = (payType: string) => /self|cash|financ/i.test(payType || '');

/* to-do */
export type TodoKind = 'payment' | 'clearance' | 'forms' | 'orders' | 'scheduling' | 'followup' | 'closure' | 'flag';
export const KIND_ORDER: TodoKind[] = ['flag', 'payment', 'clearance', 'forms', 'orders', 'scheduling', 'followup', 'closure'];
export interface TodoLite { kind: TodoKind; due: string }
export const sortTodos = <T extends TodoLite>(l: T[]) => [...l].sort((a, b) => a.due.localeCompare(b.due) || KIND_ORDER.indexOf(a.kind) - KIND_ORDER.indexOf(b.kind));
export const daysBetween = (a: string, b: string) => Math.round((Date.parse(b + 'T12:00') - Date.parse(a + 'T12:00')) / 86400000);
