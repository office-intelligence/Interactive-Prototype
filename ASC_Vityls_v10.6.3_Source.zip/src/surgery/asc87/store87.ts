/* ASC.Vityls v8.7 · storage: document uploads, standing doctor's orders list, cash-pay invoices, Nightingale activity (simulated).
 * Henry: document(upload), standing_order, invoice(+invoice_line), nightingale_event. Fictional data. */
import { repo } from '../../v6/dataLayer';
import { svRead, svWrite } from '../store';
import { uid } from '../../med/record';
import * as P from './pure87';
const bump = () => window.dispatchEvent(new Event('vityls-med-updated'));
const aud = (cid: string, by: string, role: string, detail: string, action: string) => repo.audit({ caseId: cid ? `asc8:${cid}` : 'practice', user: by, role, action: action as any, detail });

/* uploads */
export const DOC_TYPES = ['Pre-op H&P', 'Medical clearance', 'Lab results', 'ECG', 'Imaging report', 'Surgeon office records', 'Consent (outside)', 'Surgical consent', 'Registration forms', 'Ride home & caregiver', 'Post-op care location', 'ID / insurance', 'Nursing note', 'Anesthesia record', 'Operative report', 'Other'];
export interface Upload { id: string; pid: string; cid: string; dos: string; type: string; cat?: string; station?: string; name: string; size: number; mime: string; data?: string; at: string; by: string; role: string; note?: string }
export const uploads = (cid?: string, pid?: string) => svRead<Upload[]>('asc87-uploads', []).filter(u => (!cid || u.cid === cid) && (!pid || u.pid === pid));
export function addUploads(list: Upload[], by: string, role: string) {
  try { svWrite('asc87-uploads', [...uploads(), ...list]); } catch { svWrite('asc87-uploads', [...uploads(), ...list.map(u => ({ ...u, data: undefined }))]); }
  list.forEach(u => aud(u.cid, by, role, `Document uploaded: ${u.type} · ${u.name} (${Math.round(u.size / 1024)} KB) · filed to DOS ${u.dos || 'general'}`, 'asc87.upload'));
  logActivity('filed', `${list.length} document${list.length === 1 ? '' : 's'} filed (${list[0]?.type})`, list[0]?.cid); bump();
}
/* standing orders */
export const standing = () => svRead<P.StandingOrder[]>('asc87-standing', P.STANDING_SEED);
export function saveStanding(l: P.StandingOrder[], by: string, role: string, what: string) { svWrite('asc87-standing', l); aud('', by, role, `Standard doctor's orders: ${what}`, 'asc87.standing'); bump(); }
/* invoices */
export interface AscInvoice { id: string; number: string; cid: string; pid: string; dos: string; payType: string; lines: P.InvLine[]; createdAt: string; createdBy: string; issued?: { at: string; by: string } }
export const invoices = () => svRead<AscInvoice[]>('asc87-invoices', []);
export const invoiceFor = (cid: string) => invoices().find(i => i.cid === cid);
export function saveInvoice(i: AscInvoice, by: string, role: string, what: string) { const l = invoices(); svWrite('asc87-invoices', l.some(x => x.id === i.id) ? l.map(x => x.id === i.id ? i : x) : [...l, i]); aud(i.cid, by, role, `Invoice ${i.number}: ${what}`, 'asc87.invoice'); bump(); }
export const nextSeq = () => invoices().length + 1;
/* Nightingale activity (background work; simulated) */
export type ActKind = 'request' | 'clearance' | 'forms' | 'reminder' | 'filed' | 'payment' | 'match';
export interface Activity { id: string; kind: ActKind; text: string; at: string; cid?: string }
export const activity = () => svRead<Activity[]>('asc87-activity', []);
export function logActivity(kind: ActKind, text: string, cid?: string) { svWrite('asc87-activity', [{ id: uid('na'), kind, text, at: new Date().toISOString(), cid }, ...activity()].slice(0, 200)); }
export function ensureAsc87Seed() {
  if (svRead<string>('asc87-seeded', '') === 'asc87-seed-1') return; const t = (m: number) => new Date(Date.now() - m * 60000).toISOString();
  const seed: [ActKind, string, number, string?][] = [
    ['request', 'Surgery scheduling request received by email from Dr Patel’s office (Desmond Akers) and pre-filled for booking', 35],
    ['request', 'Scanned fax booking request read (simulated OCR) and queued in Booking intake', 80],
    ['clearance', 'Pre-op clearance from the cardiology office received and matched to Hugo Pell (DOS tomorrow)', 50, 'c8'],
    ['clearance', 'Lab results (BMP, CBC) received and matched to Desmond Akers', 120, 'c4'],
    ['match', 'Incoming fax matched to an existing chart by name + DOB (no duplicate created)', 140],
    ['forms', 'Registration forms returned on the portal by Owen Marsh', 95, 'c6'],
    ['forms', 'Financial agreement signed on the portal by Priya Lund', 160, 'c5'],
    ['reminder', 'Two-day reminders queued for 3 patients (arrive 1 hour early)', 60],
    ['reminder', 'Booking confirmation texts sent (simulated) to 2 patients', 200],
    ['filed', 'Surgeon office records (6 pages) filed under Maren Holt · today’s DOS', 25, 'c2'],
    ['payment', 'Payment reminders sent to 2 patients with surgery in 7–14 days', 240]];
  svWrite('asc87-activity', seed.map(([kind, text, m, cid], i) => ({ id: `na-seed-${i}`, kind, text, at: t(m), cid })));
  svWrite('asc87-seeded', 'asc87-seed-1');
}
