/*
 * Surgery.Vityls v0.6 · Documents folder on every chart.
 * Outside notes, past records, labs, ECGs, imaging reports, referrals, insurance cards… filed by type in one table
 * with icon actions: View, Download, AI summary (Nightingale) and Delete (removed from the chart, recoverable).
 * Nightingale also reads the folder as a whole: a records digest above the table, and a one-line narrative in the
 * chart header (who the patient is), which updates whenever a document is added or removed.
 * Summaries are SIMULATED: scripted for the fictional seed documents and a rule-based, on-device reading of the text
 * for uploads (PDF/text). Production uses a BAA-covered model; a clinician still reads the original.
 * Files stay in this browser (test build), up to 3 MB each. Henry: `documents(id, patient_id, type, title, source,
 * doc_date, received_at, received_by, storage_key, mime, size, summary jsonb, removed_at/by/reason)`, files in
 * object storage, summaries regenerated server-side on upload.
 */
import React, { useEffect, useRef, useState } from 'react';
import * as pdfjsLib from 'pdfjs-dist';
// PDF text extraction runs pdf.js in the main thread ("fake worker") so it also works when index.html is opened from
// file:// (browsers block worker scripts there). The worker module is bundled and exposed only while extracting.
// @ts-ignore no types for the worker build
import * as pdfjsWorkerModule from 'pdfjs-dist/build/pdf.worker.min.mjs';
import { Eye, Download, Trash2, Sparkles, Upload, RotateCcw, X } from 'lucide-react';
import { repo } from '../v6/dataLayer';
import { MedPatient, patientKey, uid, usDate, fmtDateTime, isoDay, addDays } from '../med/record';
import { useActor, useMedTick } from '../med/ui';
import { svRead, svWrite, seedHooks } from './store';
import { Ico, IconKind } from './icons';
import { useSv } from './ui';
import { R, chartAnswerHooks } from './nightingale';
import { seedContactNotes } from './contactNotes';

/* ---------------- types (practice-configurable) ---------------- */
export const DEFAULT_DOC_TYPES = ['Clinical note', 'Laboratory', 'ECG', 'Imaging', 'Outside records', 'Referral', 'Consult / clearance letter', 'Operative report', 'Insurance', 'Consent / legal', 'Other'];
export const docTypes = (): string[] => { const l = svRead<string[]>('doc-types', []); return l.length ? l : DEFAULT_DOC_TYPES; };
export function saveDocTypes(l: string[], by: string, role: string) { svWrite('doc-types', l); repo.audit({ caseId: 'practice', user: by, role, action: 'document.types', detail: `Document types: ${l.join(', ')}` }); }
export const docIcon = (t: string): IconKind => /lab/i.test(t) ? 'lab' : /ecg|ekg/i.test(t) ? 'vitals' : /imag|x-?ray|mri|ct\b|ultra/i.test(t) ? 'photo' : /referr/i.test(t) ? 'send' : /consult|clearance|consent|legal/i.test(t) ? 'form' : /insur/i.test(t) ? 'invoice' : /operat/i.test(t) ? 'surgery' : /note/i.test(t) ? 'note' : 'document';

/* ---------------- store ---------------- */
export interface DocSummary { text: string; facts: string[]; engine: string; at: string; by: string }
export interface DocRec { id: string; patientId: string; type: string; title: string; source: string; docDate: string; receivedAt: string; receivedBy: string; receivedRole: string; description?: string; fileName?: string; mime?: string; size?: number; dataUrl?: string; text?: string; lines?: string[]; scripted?: { text: string; facts: string[] }; summary?: DocSummary; example?: boolean; removedAt?: string; removedBy?: string; removedReason?: string }
const all = () => svRead<DocRec[]>('documents', []);
const put = (l: DocRec[]) => { try { svWrite('documents', l); } catch { throw new Error('This browser’s test storage is full. Remove large test documents or reset test data (?reset-test-data).'); } };
export const docsOf = (pid: string, removed = false) => all().filter(d => d.patientId === pid && !!d.removedAt === removed).sort((a, b) => b.docDate.localeCompare(a.docDate) || b.receivedAt.localeCompare(a.receivedAt));
export const docById = (id: string) => all().find(d => d.id === id);
const upd = (id: string, patch: Partial<DocRec>) => put(all().map(d => d.id === id ? { ...d, ...patch } : d));
export function addDoc(d: DocRec) { put([...all(), d]); repo.audit({ caseId: patientKey(d.patientId), user: d.receivedBy, role: d.receivedRole, action: 'document.add', detail: `Document filed: ${d.type} · ${d.title} · from ${d.source || '—'} · dated ${usDate(d.docDate)}${d.fileName ? ` · ${d.fileName}` : ''}` }); }
export function removeDoc(id: string, reason: string, by: string, role: string) { const d = docById(id); if (!d) return; upd(id, { removedAt: new Date().toISOString(), removedBy: by, removedReason: reason }); repo.audit({ caseId: patientKey(d.patientId), user: by, role, action: 'document.remove', detail: `Document removed from the chart: ${d.type} · ${d.title} · ${reason}. Kept in “Removed” and can be restored.` }); }
export function restoreDoc(id: string, by: string, role: string) { const d = docById(id); if (!d) return; upd(id, { removedAt: undefined, removedBy: undefined, removedReason: undefined }); repo.audit({ caseId: patientKey(d.patientId), user: by, role, action: 'document.add', detail: `Document restored to the chart: ${d.type} · ${d.title}` }); }

/* ---------------- Nightingale (simulated) ---------------- */
const KEY = /(impression|assessment|diagnos|recommend|plan|history of|finding|result|abnormal|elevated|low\b|high\b|normal|clear(ed|ance)|risk|allerg|medication|taking|hold|stop|follow|ejection|rhythm|a1c|hemoglobin|creatinine|platelet|glucose|apnea|stent|surgery|procedure)/i;
const MEDS = /\b(metformin|insulin|semaglutide|ozempic|wegovy|lisinopril|losartan|amlodipine|metoprolol|atorvastatin|rosuvastatin|clopidogrel|plavix|aspirin|warfarin|apixaban|eliquis|rivaroxaban|xarelto|prednisone|levothyroxine|sertraline|gabapentin|omeprazole)\b/gi;
export function summarizeText(text: string, d: Pick<DocRec, 'type' | 'source' | 'docDate' | 'description'>): { text: string; facts: string[] } {
  const clean = text.replace(/\s+/g, ' ').trim();
  const src = d.source && d.source !== 'Not stated' ? d.source : 'an unstated source';
  if (!clean) {
  const base = `${d.type} from ${src} dated ${usDate(d.docDate)}.`; return { text: `${base} ${d.description ? `Filed with the note: “${d.description}”.` : ''} The file has no readable text (scan or image), so Nightingale could not read its content. Open the original.`, facts: [d.description ? `${d.type.toLowerCase()} ${usDate(d.docDate)}: ${d.description}` : `${d.type.toLowerCase()} received ${usDate(d.docDate)} (not machine-readable)`] }; }
  const sents = clean.split(/(?<=[.!?])\s+(?=[A-Z0-9])/).map(s => s.trim()).filter(s => s.length > 12 && s.length < 320);
  const key = sents.filter(s => KEY.test(s)).slice(0, 5); const meds = [...new Set((clean.match(MEDS) || []).map(m => m.toLowerCase()))];
  const pick = key.length ? key : sents.slice(0, 3);
  const out = `${d.type} from ${src}, dated ${usDate(d.docDate)}. Key statements: ${pick.map(s => `“${s.length > 200 ? s.slice(0, 200) + '…' : s}”`).join(' ')}${meds.length ? ` Medications named: ${meds.join(', ')}.` : ''}`;
  const facts = pick.slice(0, 2).map(s => s.length > 110 ? s.slice(0, 110) + '…' : s);
  return { text: out, facts: facts.length ? facts : [`${d.type.toLowerCase()} ${usDate(d.docDate)}`] };
}
export function ensureSummary(d: DocRec, by: string, role: string): DocSummary {
  if (d.summary) return d.summary;
  const s = d.scripted || summarizeText(d.text || (d.lines || []).join('\n'), d);
  const sum: DocSummary = { ...s, engine: d.scripted ? 'Nightingale · scripted test summary (fictional document)' : 'Nightingale · on-device rule-based reading (simulated AI)', at: new Date().toISOString(), by };
  upd(d.id, { summary: sum }); repo.audit({ caseId: patientKey(d.patientId), user: by, role, action: 'document.summary', detail: `Nightingale summary generated for ${d.type} · ${d.title} (${sum.engine})` });
  return sum;
}
const factsOf = (d: DocRec) => (d.summary?.facts || d.scripted?.facts || []);
/** The whole folder, read together (shown above the table). */
export function recordsDigest(pid: string): { count: number; byType: [string, number][]; range: string; points: { text: string; id: string; type: string }[] } {
  const l = docsOf(pid); const by = new Map<string, number>(); l.forEach(d => by.set(d.type, (by.get(d.type) || 0) + 1));
  const ds = l.map(d => d.docDate).sort(); const range = ds.length ? (ds[0].slice(0, 7) === ds[ds.length - 1].slice(0, 7) ? usDate(ds[0]).replace(/\/\d{2}\//, '/') : `${usDate(ds[0]).replace(/\/\d{2}\//, '/')}–${usDate(ds[ds.length - 1]).replace(/\/\d{2}\//, '/')}`) : '';
  const points = l.filter(d => !/insur/i.test(d.type)).flatMap(d => factsOf(d).slice(0, 1).map(t => ({ text: t, id: d.id, type: d.type })));
  return { count: l.length, byType: [...by.entries()], range, points };
}
/** One or two sentences for the chart header: who the patient is, from the outside records. */
export function recordsNarrative(pid: string): string {
  const g = recordsDigest(pid); if (!g.count) return '';
  return `Outside records (${g.count} document${g.count === 1 ? '' : 's'}${g.range ? `, ${g.range}` : ''}): ${g.points.slice(0, 4).map(p => p.text.replace(/\.$/, '')).join('; ')}.`;
}

/* ---------------- file helpers ---------------- */
const MAX = 3 * 1024 * 1024;
const readUrl = (f: File) => new Promise<string>((res, rej) => { const r = new FileReader(); r.onload = () => res(String(r.result)); r.onerror = () => rej(r.error); r.readAsDataURL(f); });
async function fileText(f: File): Promise<string> {
  if (/^text\//.test(f.type) || /\.(txt|csv|md)$/i.test(f.name)) return (await f.text()).slice(0, 60000);
  if (f.type === 'application/pdf' || /\.pdf$/i.test(f.name)) {
    const job = (async () => { const g = globalThis as any; const had = g.pdfjsWorker; g.pdfjsWorker = pdfjsWorkerModule; let doc: any; try { doc = await pdfjsLib.getDocument({ data: new Uint8Array(await f.arrayBuffer()) }).promise; } finally { if (had === undefined) delete g.pdfjsWorker; else g.pdfjsWorker = had; } let out = ''; for (let i = 1; i <= Math.min(doc.numPages, 15); i++) { const pg = await doc.getPage(i); const c = await pg.getTextContent(); out += c.items.map((x: any) => x.str).join(' ') + '\n'; } return out.trim(); })();
    return Promise.race([job.catch(e => { console.warn('Surgery.Vityls: PDF text extraction failed', e); return ''; }), new Promise<string>(res => setTimeout(() => res(''), 8000))]);
  }
  return '';
}
const sheetText = (d: DocRec) => [`${d.title}`, `${d.type} · from ${d.source} · dated ${usDate(d.docDate)}`, '', ...(d.lines || [d.text || '']), '', 'EXAMPLE DATA · fictional document · Surgery.Vityls test build'].join('\n');
export function downloadDoc(d: DocRec) {
  const a = document.createElement('a');
  if (d.dataUrl) { a.href = d.dataUrl; a.download = d.fileName || `${d.title}.bin`; }
  else { a.href = URL.createObjectURL(new Blob([sheetText(d)], { type: 'text/plain' })); a.download = `${d.title.replace(/[^\w\- ]+/g, '').replace(/\s+/g, '_')}.txt`; }
  document.body.appendChild(a); a.click(); a.remove();
}

/* ---------------- UI ---------------- */
const short = (iso: string) => { const m = iso.match(/^(\d{4})-(\d{2})-(\d{2})/); return m ? `${m[2]}/${m[3]}/${m[1].slice(2)}` : iso; };
export const DocumentsSection: React.FC<{ p: MedPatient; inPanel?: boolean }> = ({ p, inPanel }) => {
  useMedTick(); const [actor] = useActor(); const { openPanel, toast } = useSv();
  const [type, setType] = useState('All'); const [add, setAdd] = useState(false); const [open, setOpen] = useState<string>(''); const [busy, setBusy] = useState(''); const [del, setDel] = useState<DocRec | null>(null); const [showRemoved, setShowRemoved] = useState(false);
  const docs = docsOf(p.id); const removed = docsOf(p.id, true); const g = recordsDigest(p.id);
  const types = [...new Set([...docTypes(), ...docs.map(d => d.type)])].filter(t => docs.some(d => d.type === t));
  const list = type === 'All' ? docs : docs.filter(d => d.type === type);
  const summarize = (d: DocRec) => { if (open === d.id) { setOpen(''); return; } setBusy(d.id); setOpen(d.id); window.setTimeout(() => { ensureSummary(d, actor.name, actor.role); setBusy(''); }, d.summary ? 0 : 450); };
  return <section className="sv-docs" aria-labelledby="h-docs" data-testid="chart-documents">
    <div className="flex items-center gap-2 flex-wrap mb-1"><h3 id="h-docs" className="sv-h m-0 flex items-center gap-1.5"><Ico k="attachment" />Documents</h3><span className="sv-small sv-muted">{docs.length} on file · outside notes, past records, labs, ECG, imaging, referrals</span>
      <button type="button" className="sv-btn sm ml-auto inline-flex items-center gap-1" onClick={() => setAdd(true)} data-testid="doc-add"><Upload size={14} />Add document</button></div>
    {g.count > 0 && <div className="sv-digest" data-testid="doc-digest"><b className="k"><Sparkles size={12} className="inline -mt-0.5" /> Nightingale · all documents read together</b>
      <p className="m-0">{g.count} document{g.count === 1 ? '' : 's'} on file{g.range ? ` (${g.range})` : ''}: {g.byType.map(([t, n]) => `${n} ${t.toLowerCase()}`).join(', ')}.</p>
      {g.points.length > 0 && <ul>{g.points.slice(0, 6).map((x, i) => <li key={i}><button type="button" className="sv-link text-left" onClick={() => openPanel(R('doc', x.type, p.id, x.id))}>{x.text}</button></li>)}</ul>}
      <div className="sv-small sv-muted">Simulated summary from the documents only · no interpretation · verify against the originals.</div></div>}
    {docs.length > 0 && <div className="sv-chips" role="tablist" aria-label="Filter by type">{['All', ...types].map(t => <button key={t} type="button" role="tab" aria-selected={type === t} onClick={() => setType(t)} data-testid="doc-filter">{t === 'All' ? `All (${docs.length})` : <><Ico k={docIcon(t)} />{t} ({docs.filter(d => d.type === t).length})</>}</button>)}</div>}
    {docs.length === 0 ? <p className="sv-muted text-[13px]">No documents yet. Use Add document to file outside records, labs, ECGs, imaging, referrals or insurance cards.</p> :
      <table className="sv-table sv-doctable" data-testid="doc-table"><thead><tr><th>Type</th><th>Document</th><th>Dated</th><th className="text-right">Actions</th></tr></thead><tbody>
        {list.map(d => <React.Fragment key={d.id}><tr data-testid="doc-row">
          <td className="whitespace-nowrap"><span className="inline-flex items-center gap-1.5"><Ico k={docIcon(d.type)} />{d.type}</span></td>
          <td><button type="button" className="font-semibold text-left hover:underline" onClick={() => openPanel(R('doc', d.title, p.id, d.id))}>{d.title}</button><div className="sv-small sv-muted">{d.source}{d.example ? ' · example data' : ''} · filed {short(isoDay(new Date(d.receivedAt)))} by {d.receivedBy.replace(/,.*$/, '')}</div></td>
          <td className="whitespace-nowrap">{short(d.docDate)}</td>
          <td className="text-right whitespace-nowrap"><span className="sv-iconbtns">
            <button type="button" onClick={() => openPanel(R('doc', d.title, p.id, d.id))} title="View" aria-label={`View ${d.title}`} data-testid="doc-view"><Eye size={16} /></button>
            <button type="button" onClick={() => { downloadDoc(d); repo.audit({ caseId: patientKey(p.id), user: actor.name, role: actor.role, action: 'document.download', detail: `Downloaded ${d.type} · ${d.title}` }); }} title="Download" aria-label={`Download ${d.title}`} data-testid="doc-download"><Download size={16} /></button>
            <button type="button" className={`ai ${open === d.id ? 'on' : ''}`} onClick={() => summarize(d)} title="AI summary (Nightingale)" aria-label={`Nightingale summary of ${d.title}`} aria-expanded={open === d.id} data-testid="doc-ai"><Sparkles size={16} /></button>
            <button type="button" className="del" onClick={() => setDel(d)} title="Delete" aria-label={`Delete ${d.title}`} data-testid="doc-delete"><Trash2 size={16} /></button></span></td></tr>
          {open === d.id && <tr className="sv-doc-sum"><td colSpan={4} data-testid="doc-summary">{busy === d.id ? <span className="sv-muted">Nightingale is reading the document…</span> : (() => { const s = docById(d.id)?.summary; return s ? <><b className="k"><Sparkles size={12} className="inline -mt-0.5" /> Nightingale summary</b> {s.text}<div className="sv-small sv-muted mt-1">{s.engine} · {fmtDateTime(s.at)} · Nightingale summarizes; it does not interpret or advise. Open the original before acting.</div></> : null; })()}</td></tr>}
        </React.Fragment>)}
      </tbody></table>}
    {removed.length > 0 && <div className="mt-1"><button type="button" className="sv-link sv-small" onClick={() => setShowRemoved(s => !s)} data-testid="doc-show-removed">{showRemoved ? 'Hide' : 'Show'} removed ({removed.length})</button>
      {showRemoved && <ul className="sv-small mt-1">{removed.map(d => <li key={d.id} className="py-0.5">{d.type} · {d.title} <span className="sv-muted">· removed by {d.removedBy} {fmtDateTime(d.removedAt)} · {d.removedReason}</span> <button type="button" className="sv-link inline-flex items-center gap-0.5" onClick={() => { restoreDoc(d.id, actor.name, actor.role); toast('Document restored to the chart.'); }} data-testid="doc-restore"><RotateCcw size={12} />Restore</button></li>)}</ul>}</div>}
    {add && <AddDocumentDialog p={p} onClose={() => setAdd(false)} onDone={d => { setAdd(false); setOpen(d.id); toast(`Filed: ${d.title}. Nightingale summary added; header updated.`); }} />}
    {del && <DeleteDocDialog d={del} onClose={() => setDel(null)} onDone={() => { setDel(null); if (open === del.id) setOpen(''); toast('Document removed from the chart (restorable under “Show removed”).'); }} />}
  </section>;
};

const DeleteDocDialog: React.FC<{ d: DocRec; onClose: () => void; onDone: () => void }> = ({ d, onClose, onDone }) => {
  const [actor] = useActor(); const [reason, setReason] = useState(''); const R2 = ['Filed to the wrong patient', 'Duplicate', 'Not a medical record', 'Other'];
  return <div className="sv-modal" role="dialog" aria-modal="true" aria-label="Delete document" data-testid="doc-delete-dialog"><div className="sv-modal-scrim" onClick={onClose} /><div className="sv-modal-box">
    <b className="text-[15px] flex items-center gap-1.5"><Trash2 size={16} />Delete this document?</b>
    <p className="text-[13px] my-2"><b>{d.title}</b> · {d.type} · dated {usDate(d.docDate)}</p>
    <label className="block"><span className="sv-label">Reason</span><select className="sv-input" value={reason} onChange={e => setReason(e.target.value)} data-testid="doc-del-reason"><option value="">Choose…</option>{R2.map(r => <option key={r}>{r}</option>)}</select></label>
    <p className="text-[11.5px] sv-muted mt-2">It leaves the chart, the digest and the header narrative. It stays restorable under “Show removed”, and the deletion is audited under {actor.name}.</p>
    <div className="flex justify-end gap-2 mt-3"><button type="button" className="sv-btn" onClick={onClose}>Cancel</button><button type="button" className="sv-btn danger" disabled={!reason} onClick={() => { removeDoc(d.id, reason, actor.name, actor.role); onDone(); }} data-testid="doc-del-confirm">Delete</button></div>
  </div></div>;
};

export const AddDocumentDialog: React.FC<{ p: MedPatient; onClose: () => void; onDone: (d: DocRec) => void }> = ({ p, onClose, onDone }) => {
  const [actor] = useActor(); const [file, setFile] = useState<File | null>(null); const [f, setF] = useState({ type: '', title: '', source: '', docDate: isoDay(), description: '' }); const [err, setErr] = useState(''); const [busy, setBusy] = useState(false);
  const save = async () => {
    if (!f.type) { setErr('Choose a document type.'); return; } if (!file && !f.description.trim()) { setErr('Attach a file, or describe the record (e.g. a faxed page you will scan later).'); return; }
    if (file && file.size > MAX) { setErr('This test build keeps files up to 3 MB. Scan at a lower resolution or split the file.'); return; }
    setBusy(true); setErr('');
    try {
      const dataUrl = file ? await readUrl(file) : undefined; const text = file ? await fileText(file) : f.description.trim();
      const d: DocRec = { id: uid('doc'), patientId: p.id, type: f.type, title: f.title.trim() || file?.name.replace(/\.[^.]+$/, '') || f.type, source: f.source.trim() || 'Not stated', docDate: f.docDate || isoDay(), receivedAt: new Date().toISOString(), receivedBy: actor.name, receivedRole: actor.role, description: f.description.trim() || undefined, fileName: file?.name, mime: file?.type, size: file?.size, dataUrl, text: text || undefined };
      addDoc(d); ensureSummary(d, actor.name, actor.role); onDone(d);
    } catch (e: any) { setErr(e?.message || 'Could not file the document.'); setBusy(false); }
  };
  return <div className="sv-modal" role="dialog" aria-modal="true" aria-label="Add document" data-testid="doc-add-dialog"><div className="sv-modal-scrim" onClick={onClose} /><div className="sv-modal-box" style={{ width: 'min(540px, calc(100vw - 24px))' }}>
    <div className="flex items-center gap-2 mb-2"><Upload size={16} /><b className="text-[15px]">Add document · {p.name}</b><button type="button" className="ml-auto" onClick={onClose} aria-label="Close"><X size={16} /></button></div>
    <label className="block mb-2"><span className="sv-label">File (PDF, image or text; on a tablet you can take a photo of the page)</span><input type="file" accept="application/pdf,image/*,text/plain,.txt" className="sv-input" onChange={e => { const x = e.target.files?.[0] || null; setFile(x); if (x && !f.title) setF(v => ({ ...v, title: x.name.replace(/\.[^.]+$/, '') })); }} data-testid="doc-file" /></label>
    <div className="grid sm:grid-cols-2 gap-2">
      <label><span className="sv-label">Type</span><select className="sv-input" value={f.type} onChange={e => setF({ ...f, type: e.target.value })} data-testid="doc-type"><option value="">Choose…</option>{docTypes().map(t => <option key={t}>{t}</option>)}</select></label>
      <label><span className="sv-label">Document date</span><input type="date" className="sv-input" value={f.docDate} onChange={e => setF({ ...f, docDate: e.target.value })} data-testid="doc-date" /></label>
      <label className="sm:col-span-2"><span className="sv-label">Title</span><input className="sv-input" value={f.title} onChange={e => setF({ ...f, title: e.target.value })} placeholder="e.g. Cardiology letter" data-testid="doc-title" /></label>
      <label className="sm:col-span-2"><span className="sv-label">From (sender / facility)</span><input className="sv-input" value={f.source} onChange={e => setF({ ...f, source: e.target.value })} placeholder="e.g. Bayside Cardiology (fax)" data-testid="doc-source" /></label>
      <label className="sm:col-span-2"><span className="sv-label">Brief description (optional; helps Nightingale with scans)</span><textarea className="sv-input" rows={2} value={f.description} onChange={e => setF({ ...f, description: e.target.value })} data-testid="doc-desc" /></label>
    </div>
    {err && <p className="text-[12.5px] text-[var(--crit)] mt-2" role="alert">{err}</p>}
    <p className="text-[11.5px] sv-muted mt-2">Filed under {actor.name}. Nightingale summarizes it right away (simulated, on this device) and updates the chart header. Nothing is uploaded anywhere in this test build.</p>
    <div className="flex justify-end gap-2 mt-3"><button type="button" className="sv-btn" onClick={onClose}>Cancel</button><button type="button" className="sv-btn primary" disabled={busy} onClick={save} data-testid="doc-save">{busy ? 'Reading…' : 'Add to chart'}</button></div>
  </div></div>;
};

/** Right panel: the document itself (original or the fictional sheet) with its Nightingale summary. */
export const DocViewer: React.FC<{ p: MedPatient; id?: string }> = ({ p, id }) => {
  useMedTick(); const [actor] = useActor(); const d = id ? docById(id) : undefined; const [url, setUrl] = useState(''); const logged = useRef('');
  useEffect(() => { let u = ''; if (d?.dataUrl && /pdf/.test(d.mime || '')) { fetch(d.dataUrl).then(r => r.blob()).then(b => { u = URL.createObjectURL(b); setUrl(u); }).catch(() => setUrl('')); } else setUrl(''); return () => { if (u) URL.revokeObjectURL(u); }; }, [d?.id]);
  useEffect(() => { if (d && logged.current !== d.id) { logged.current = d.id; repo.audit({ caseId: patientKey(p.id), user: actor.name, role: actor.role, action: 'document.view', detail: `Viewed ${d.type} · ${d.title}` }); } }, [d?.id]);
  if (!d) return <DocumentsSection p={p} inPanel />;
  const s = d.summary || ensureSummary(d, actor.name, actor.role);
  return <div data-testid="doc-viewer">
    <div className="flex items-center gap-2 flex-wrap mb-2"><span className="sv-tag inline-flex items-center gap-1"><Ico k={docIcon(d.type)} />{d.type}</span><span className="sv-small sv-muted">{d.source} · dated {usDate(d.docDate)} · filed {fmtDateTime(d.receivedAt)} by {d.receivedBy}</span>
      <button type="button" className="sv-btn sm ml-auto inline-flex items-center gap-1" onClick={() => downloadDoc(d)} data-testid="docv-download"><Download size={14} />Download</button></div>
    <div className="sv-ann mb-3" data-testid="docv-summary"><b>Nightingale summary</b>{s.text}<div className="sv-small sv-muted mt-1">{s.engine}</div></div>
    {d.lines ? <div className="sv-docsheet"><div className="t">{d.title}</div>{d.lines.map((l, i) => l === '' ? <br key={i} /> : <p key={i}>{l}</p>)}<div className="sv-ex">EXAMPLE DATA · fictional document</div></div>
      : d.dataUrl && /^image\//.test(d.mime || '') ? <img src={d.dataUrl} alt={d.title} className="max-w-full border border-[var(--line)]" />
      : url ? <iframe title={d.title} src={url} className="w-full border border-[var(--line)]" style={{ height: '70vh' }} />
      : d.text ? <pre className="sv-docsheet whitespace-pre-wrap">{d.text}</pre> : <p className="sv-muted">No preview for this file type. Use Download.</p>}
    {d.description && <p className="sv-small mt-2"><b>Filed with the note:</b> {d.description}</p>}
  </div>;
};

/** The Records & documents grid line. */
export const DocsRecordLink: React.FC<{ p: MedPatient }> = ({ p }) => { const { openPanel } = useSv(); const n = docsOf(p.id).length;
  return <li><button type="button" className="sv-rec-link" onClick={() => openPanel(R('documents', 'Documents', p.id))} data-testid="rec-documents"><Ico k="attachment" /><span>Documents folder</span><span className="m">{n}</span></button></li>; };

/* ---------------- fictional seed (Ellen Testwood, Robert) ---------------- */
export function seedDocuments() {
  const T = isoDay(); const at = (d: number) => new Date(`${addDays(T, d)}T09:30:00`).toISOString();
  const doc = (id: string, pid: string, type: string, title: string, source: string, d: number, lines: string[], scripted: { text: string; facts: string[] }, rd = d + 1): DocRec => ({ id, patientId: pid, type, title, source, docDate: addDays(T, d), receivedAt: at(Math.min(0, rd)), receivedBy: 'Front Desk Tester', receivedRole: 'Front desk', lines, scripted, example: true });
  svWrite('documents', [
    doc('doc-e-ref', 'MED-1001', 'Referral', 'Referral letter · upper eyelids', 'Lena Brooks, MD · primary care (fictional)', -45, ['Dear Dr. Patel,', 'I am referring Mrs. Ellen Testwood, 72, for evaluation of heavy upper eyelids. She reports the lids obstruct her upper vision when reading and driving, worse in the evening.', 'History of type 2 diabetes (A1c 7.4% in June), hypertension, coronary artery disease with a drug-eluting stent in 2019 on clopidogrel, and obstructive sleep apnea on CPAP.', 'She had nausea and vomiting after anesthesia for her gallbladder surgery in 2015.', 'Allergies: penicillin (hives), codeine (nausea).', 'Thank you for seeing her.', 'Lena Brooks, MD'],
      { text: 'Primary-care referral for heavy upper eyelids that block upper vision when reading and driving. Lists type 2 diabetes (A1c 7.4% in June), hypertension, coronary stent 2019 on clopidogrel, sleep apnea on CPAP, nausea/vomiting after anesthesia in 2015, and allergies to penicillin (hives) and codeine (nausea).', facts: ['Referred by her PCP for heavy upper lids blocking upper vision when reading and driving'] }),
    doc('doc-e-sleep', 'MED-1001', 'Outside records', 'Sleep study report (2024)', 'Coastal Sleep Center (fictional)', -720, ['Polysomnography · overnight, in lab.', 'Apnea-hypopnea index (AHI) 22 events/hour: moderate obstructive sleep apnea.', 'Lowest oxygen saturation 84%.', 'CPAP titration: effective at 10 cm H2O.', 'Impression: moderate OSA, responds to CPAP 10 cm H2O.'],
      { text: 'Overnight sleep study: moderate obstructive sleep apnea (AHI 22/hour, lowest oxygen saturation 84%). CPAP was effective at 10 cm H2O.', facts: ['Moderate sleep apnea (AHI 22) on CPAP 10 cm H2O since 2024'] }),
    doc('doc-e-card', 'MED-1001', 'Consult / clearance letter', 'Cardiology letter', 'Omar Haddad, MD · cardiology (fictional)', -12, ['Re: Ellen Testwood · planned upper eyelid surgery', 'Coronary artery disease with drug-eluting stent to the LAD in 2019. No angina. Walks 2 miles daily without symptoms.', 'Echocardiogram 03/2026: ejection fraction 60%, no significant valve disease.', 'ECG today attached: sinus rhythm, no acute changes.', 'Clopidogrel: the decision to continue or hold peri-operatively should be made jointly with the surgeon; please call our office before any change.', 'From a cardiac standpoint she is at acceptable risk for the planned procedure.', 'Omar Haddad, MD'],
      { text: 'Cardiology letter for the planned eyelid surgery: coronary stent (LAD, 2019), no angina, walks 2 miles daily; echo 03/2026 ejection fraction 60%. States acceptable cardiac risk. On clopidogrel the cardiologist asks to be called before any peri-operative change and to decide jointly with the surgeon.', facts: ['Cardiology: acceptable cardiac risk, EF 60%; call cardiology before any clopidogrel change'] }),
    doc('doc-e-ecg', 'MED-1001', 'ECG', '12-lead ECG', 'Omar Haddad, MD · cardiology (fictional)', -12, ['Rate 68 bpm · PR 172 ms · QRS 92 ms · QTc 428 ms.', 'Sinus rhythm.', 'No acute ST-T changes.', 'Unchanged from prior tracing (2025).'],
      { text: '12-lead ECG: sinus rhythm at 68, normal intervals (PR 172, QRS 92, QTc 428 ms), no acute ST-T changes, unchanged from 2025.', facts: ['ECG: sinus rhythm 68, no acute changes, unchanged from 2025'] }),
    doc('doc-e-lab', 'MED-1001', 'Laboratory', 'Outside labs · CBC, BMP', 'Harbor Reference Lab (fictional)', -9, ['CBC: hemoglobin 12.8 g/dL (ref 12.0–15.5) · platelets 214 K/uL (150–400) · WBC 6.9 K/uL.', 'BMP: glucose 148 mg/dL (70–99) H · creatinine 1.0 mg/dL (0.6–1.1) · potassium 4.3 mmol/L · sodium 139 mmol/L.', 'PT/INR 1.0.'],
      { text: 'Outside labs: hemoglobin 12.8, platelets 214, WBC 6.9; glucose 148 (flagged high by the lab), creatinine 1.0, potassium 4.3, sodium 139; INR 1.0.', facts: ['Outside labs: glucose 148 (high per lab); hemoglobin, platelets, creatinine and INR within the lab’s ranges'] }),
    doc('doc-e-ins', 'MED-1001', 'Insurance', 'Medicare card (front and back)', 'Scanned at the front desk', -45, ['Medicare Health Insurance · Part A and Part B', 'Member: Ellen Testwood · ID 1EG4-TE5-MK00 (fictional)'],
      { text: 'Medicare card, Part A and B, fictional member ID on file.', facts: ['Medicare Part A and B card on file'] }, -45),
    doc('doc-r-op', 'MED-1004', 'Operative report', 'Operative report · facelift / necklift', 'Harborview Surgery Center (fictional network ASC)', -6, ['Procedure: deep-plane facelift with platysmaplasty.', 'Anesthesia: general. Estimated blood loss 120 mL. No complications.', 'Drains ×2 placed, to be removed at the first post-op visit.', 'Disposition: discharged home with escort the same day.'],
      { text: 'Operative report: deep-plane facelift with platysmaplasty under general anesthesia, blood loss 120 mL, no complications, two drains to come out at the first post-op visit, discharged home the same day.', facts: ['Facelift/necklift 6 days ago at Harborview, uncomplicated; two drains to remove at first post-op visit'] }),
  ]);
}
seedHooks.push(seedDocuments, seedContactNotes);
/** v0.6: seed the fictional documents once on top of existing v0.5 test data (no reset needed). */
export function ensureV06Seed() { if (!svRead<boolean>('v06-seeded', false)) { if (!all().length) seedDocuments(); if (!svRead<unknown[]>('contact-notes', []).length) seedContactNotes(); svWrite('v06-seeded', true); } }

/* Nightingale: “documents”, “outside records”, “cardiology letter”, “summarize records”… */
chartAnswerHooks.push((pid, q) => {
  if (!/document|outside record|records? (from|we got|received)|summari[sz]e (the )?records|letter|referral|sleep study|operative report|ecg report|ekg report/.test(q)) return null;
  const g = recordsDigest(pid); const ref = R('documents', 'Documents folder', pid);
  if (!g.count) return { text: 'No documents are filed in this chart yet. Use Add document in the Documents folder.', cites: [ref], act: { type: 'panel', ref } };
  const hit = docsOf(pid).find(d => q.split(/\W+/).filter(w => w.length > 3 && !/document|records?|summari[sz]e|outside/.test(w)).some(w => (d.title + ' ' + d.type).toLowerCase().includes(w)));
  if (hit) { const s = hit.summary || hit.scripted; return { text: `${hit.title} (${hit.type}, ${usDate(hit.docDate)}, from ${hit.source}): ${s ? s.text : 'not summarized yet; open it and press the AI summary icon.'}`, cites: [R('doc', hit.title, pid, hit.id)] }; }
  return { text: `${g.count} document${g.count === 1 ? '' : 's'} on file${g.range ? ` (${g.range})` : ''}: ${g.points.slice(0, 5).map(p => p.text.replace(/\.$/, '')).join('; ')}. Summaries are simulated; verify against the originals.`, cites: [ref, ...g.points.slice(0, 3).map(p => R('doc', p.type, pid, p.id))] };
});
