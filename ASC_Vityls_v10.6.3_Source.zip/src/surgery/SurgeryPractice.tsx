import { AscPracticeHome } from './asc10/settings10';
import { IdleSetting } from './asc85/tablet';
import { StandingOrdersSettings } from './asc87/ui87';
import { FacilitySettings } from './asc88/ui88';
/*
 * Surgery.Vityls Practice (v0.2): the same grouped structure as before, in the Surgery.Vityls visual language, with no
 * operating-room or ASC configuration (that belongs to ASC.Vityls). Nightingale lives only in the page header; every
 * setting below is also a Nightingale command.
 */
import { isMedical, isAscEd } from '../edition';
import { SURGERY_WORKFLOWS } from './v10/stations';
import React, { useState } from 'react';
import { getSettings, saveSettings } from '../med/settings';
import { MED_ROOMS } from '../med/seed';
import { useActor, useMedTick } from '../med/ui';
import { requestPinReset, unlockPerson, OutMail } from './v12/pinReset';
import { MailPreview } from './v12/PinReset';
import { staffList, addStaff, setStaffActive, ROLE_GROUP, STAFF_ROLES, COORDINATOR_ROLE, StaffInvite, StaffMember, staffInvites, sendStaffInvite, patientsOfCoordinator } from './staff';
import { svRead, svWrite } from './store';
import { useSv } from './ui';
import { resources } from './v09/schedData';
import { practiceActor, practiceUnlocked } from './practiceLock';
import { Ico } from './icons';
import { PRACTICE_COMMANDS } from './nightingale';
import type { SvTab } from './ui';
import { isCoreBuild, tabOn, useCoreTick } from '../core/useCore';

const GROUPS: { title: string; icon: string; items: { label: string; sub: string; tab: SvTab }[] }[] = [
  { title: 'Workspaces', icon: 'careteam', items: [
    { label: 'Practice profile & rooms', sub: isAscEd ? 'Facility profile & logo, name, address, hours, rooms' : 'Name, address, hours, exam and procedure rooms', tab: 'profile' },
    // v1.5 #10: Surgery reaches Billing & payments from the sidebar only (removed from Practice)
    ...(isMedical ? [{ label: 'Billing & payments', sub: 'Invoices, payments and ledger', tab: 'billing-hub' as SvTab }] : []),
    { label: 'Practice performance & reports', sub: isMedical ? 'Patient visits, diagnoses & plans, coordinators, collections, reports' : 'Patient visits, surgeries, ASC utilization, coordinators, collections, reports', tab: 'ops-hub' }] },
  { title: 'Practice setup', icon: 'block', items: [
    ...(!isMedical ? [{ label: 'Billing settings', sub: isAscEd ? 'Billing configuration and the fee schedule (administrator)' : 'Billing configuration and the practice fee per visit type', tab: 'billing-settings' as SvTab }] : []),
    { label: 'Visit types, intake lists & reminders', sub: 'Schedule colors, durations, payment types & referral sources, appointment reminders, surgical modules, surgery centers', tab: 'surgery-settings' },
    { label: isAscEd ? 'Surgery settings' : 'Surgery.Vityls settings', sub: isAscEd ? 'Result release, risk triggers, portal ranges' : 'Fee schedule, result release, risk triggers, lab descriptions, portal', tab: 'med-settings' }] },
  { title: 'Clinical configuration', icon: 'form', items: [
    { label: 'Forms & workflow', sub: `My Forms, ${SURGERY_WORKFLOWS.length} stations, signers · edit forms in the form editor`, tab: 'forms' }] },
  { title: 'People & compliance', icon: 'audit', items: [
    { label: 'Providers', sub: 'Surgeons, physicians, NPs and PAs; signature PINs', tab: 'people' },
    { label: 'Staff, coordinators & invitations', sub: 'Front desk, surgical coordinators, MAs, nurses, managers; invitation link, one PIN per person', tab: 'staff' },
    { label: 'Patient records', sub: 'Document types for the Documents folder; hidden and deleted charts (restore / delete permanently)', tab: 'records-admin' },
    { label: isAscEd ? 'Facility accreditation & documents' : 'Policies & manuals', sub: isAscEd ? 'Accreditation, policies & procedures, manuals, credentials, HR, vendors, equipment records; renewal tracking' : 'Office policies and documents', tab: 'documents' },
    ...(isAscEd ? [{ label: 'Medical Director', sub: 'Designation, privileges review, annual policy attestations (PIN)', tab: 'medical-director' as SvTab }, { label: 'Accreditation & audit pack', sub: 'Per-case completeness: signed forms, OR times, op report · manual download', tab: 'audit-pack' as SvTab }] : [])] },
];

export const PracticeHome: React.FC = () => {
  if (isAscEd) return <AscPracticeHome />;
  useCoreTick(); const { setTab } = useSv(); const name = getSettings().practiceName;
  // core-modules: Practice panels of modules that are off are left out; Modules & plan is a Core panel (combined build).
  const groups = GROUPS.map(g => ({ ...g, items: g.items.filter(i => tabOn(i.tab)) })).filter(g => g.items.length).map((g, gi) => gi === 0 && isCoreBuild ? { ...g, items: [{ label: 'Modules & plan', sub: 'What’s in your plan, free trials and modules you can try', tab: 'modules' as SvTab }, ...g.items] } : g);
  return <div className="sv-page" data-testid="sv-practice">
    <h1 className="sv-title">Practice</h1>
    <div className="sv-sub mb-3">{name} · administration. Ask Nightingale above for any setting, e.g. “fee schedule” or “staff PINs”.</div>
    <div className="sv-prac-grid" data-testid="sv-practice-links">{groups.map(g => <section key={g.title} className="sv-prac-group" aria-labelledby={`pg-${g.title}`}>
      <h2 id={`pg-${g.title}`} className="sv-h flex items-center gap-1.5"><Ico k={g.icon} />{g.title}</h2>
      <ul>{g.items.map(i => <li key={i.label}><button type="button" className="sv-prac-item" onClick={() => setTab(i.tab)} data-testid={`prac-${i.tab}`}><b>{i.label}</b><span>{i.sub}</span><span className="go">›</span></button></li>)}</ul>
    </section>)}</div>
    {isAscEd && <IdleSetting />}
    {!isMedical && <p className="sv-small sv-muted mt-4">Operating rooms, ASC block-time setup and facility configuration live in ASC.Vityls, not here. Surgery.Vityls only keeps the list of surgery centers you send requests to.</p>}
  </div>;
};
export const practiceNext = () => PRACTICE_COMMANDS.slice(0, 6).map(c => ({ label: c.label, act: { type: 'tab' as const, tab: c.tab } }));

const Back: React.FC<{ title: string; sub?: string }> = ({ title, sub }) => { const { setTab } = useSv(); return <div className="mb-3" data-ps-legacy=""><button type="button" className="sv-link text-[13px]" onClick={() => setTab('practice')}>‹ Practice</button><h1 className="sv-title mt-1">{title}</h1>{sub && <div className="sv-sub">{sub}</div>}</div>; };

export const StaffPins: React.FC = () => {
  useMedTick(); const [session] = useActor(); const actor = practiceActor(session); const { toast } = useSv(); const list = staffList(); const admin = practiceUnlocked() || ROLE_GROUP.admin.includes(session.role);
  const [nm, setNm] = useState(''); const [role, setRole] = useState(COORDINATOR_ROLE); const [email, setEmail] = useState('');
  const [preview, setPreview] = useState<StaffInvite | null>(null); const [mail, setMail] = useState<OutMail | null>(null);
  const run = (f: () => void, ok: string) => { try { f(); toast(ok); } catch (e) { toast((e as Error).message); } };
  const status = (s: StaffMember) => !s.active ? <span className="sv-tag">Inactive</span> : s.status === 'invited' ? <span className="sv-tag warn" data-testid="staff-invited">Invited · account not created</span> : s.locked ? <span className="sv-tag crit">Locked</span> : <span className="sv-tag ok">Active</span>;
  return <div className="sv-page" data-testid="sv-staff">
    <Back title="Staff, coordinators & signing PINs" sub="Shared tablets stay signed in. Each person enters their own PIN only when they sign or attest." />
    {!admin && <p className="sv-banner">Viewing only. A Practice Manager or Practice Administrator registers staff (switch the Session).</p>}
    {admin && <section className="sv-reg" data-testid="staff-register">
      <h2 className="sv-h">Register a team member</h2>
      <p className="text-[13px] sv-muted mb-2">They get one personal link to create their own username, password and signing PIN. You never see or set them. Surgeons and other providers are registered under Practice › Providers (same kind of invitation, plus credentialing).</p>
      <div className="flex flex-wrap items-end gap-2">
        <label className="flex-1 min-w-[180px]"><span className="sv-label">Full name</span><input className="sv-input" value={nm} onChange={e => setNm(e.target.value)} placeholder="e.g. Alex Doe" data-testid="staff-name" /></label>
        <label className="min-w-[180px]"><span className="sv-label">Role</span><select className="sv-input" value={role} onChange={e => setRole(e.target.value)} data-testid="staff-role">{STAFF_ROLES.map(r => <option key={r}>{r}</option>)}</select></label>
        <label className="flex-1 min-w-[220px]"><span className="sv-label">Email (invitation link)</span><input className="sv-input" type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="name@example.test" data-testid="staff-email" /></label>
        <button type="button" className="sv-btn primary" onClick={() => run(() => { const inv = addStaff(nm, role, email, actor.name, actor.role); setPreview(inv); setNm(''); setEmail(''); }, 'Registered. Invitation link queued in the simulated outbox (nothing was sent).')} data-testid="staff-add">Register &amp; send invitation</button>
      </div>
      {role === COORDINATOR_ROLE && <p className="sv-small sv-muted mt-1.5">Surgical coordinators follow a patient from consultation to after surgery. Assigning one to a patient is optional (chart header › Coordinator).</p>}
    </section>}
    {preview && <InvitePreview inv={preview} onClose={() => setPreview(null)} />}
    {mail && <MailPreview m={mail} onClose={() => setMail(null)} />}
    <div className="overflow-x-auto sv-sec"><table className="sv-table v102-staff" data-testid="staff-table"><thead><tr><th>Name</th><th>Role</th><th>Account</th><th>Status</th><th>PIN</th><th></th></tr></thead><tbody>
      {list.map(s => <tr key={s.id} data-testid={`staff-row-${s.id}`}><td><b>{s.name}</b>{s.credentials ? `, ${s.credentials}` : ''}{s.email && <div className="sv-muted sv-small">{s.email}</div>}</td><td>{s.role === COORDINATOR_ROLE ? <span className="inline-flex items-center gap-1"><Ico k="careteam" />{s.role}</span> : s.role}{s.role === COORDINATOR_ROLE && <div className="sv-muted sv-small">{patientsOfCoordinator(s.id).length} patient(s)</div>}</td>
        <td className="sv-small">{s.status === 'invited' ? <span className="sv-muted">invited {s.invitedAt ? new Date(s.invitedAt).toLocaleDateString() : ''}</span> : s.username ? <>username <b>{s.username}</b></> : <span className="sv-muted">seeded (test)</span>}</td>
        <td>{status(s)}</td>
        <td><span className="sv-muted">{s.status === 'invited' ? 'set by them' : `set by them${s.fails ? ` · ${s.fails} wrong` : ''}`}</span></td>
        <td className="text-right whitespace-nowrap">{admin && <>{s.status === 'invited' ? <><button type="button" className="sv-link text-[12.5px] mr-3" onClick={() => { const l = staffInvites(s.id).filter(x => !x.revokedAt).slice(-1)[0]; if (l) setPreview(l); }} data-testid={`staff-view-invite-${s.id}`}>View invitation</button><button type="button" className="sv-link text-[12.5px] mr-3" onClick={() => run(() => setPreview(sendStaffInvite(s.id, actor.name, actor.role, true)), 'Invitation resent (simulated). The earlier link no longer works.')}>Resend</button></> : <><button type="button" className="sv-link text-[12.5px] mr-3" onClick={() => run(() => setMail(requestPinReset(s.name, actor.name, actor.role, 'admin')), `PIN reset link emailed to ${s.name} (simulated). You never see or set their PIN.`)} data-testid={`staff-reset-${s.id}`}>Reset PIN (send link)</button>{s.locked && <button type="button" className="sv-link text-[12.5px] mr-3" onClick={() => run(() => unlockPerson(s.name, actor.name, actor.role), `${s.name} unlocked.`)} data-testid={`staff-unlock-${s.id}`}>Unlock</button>}</>}<button type="button" className="sv-link text-[12.5px]" onClick={() => run(() => setStaffActive(s.id, !s.active, actor.name, actor.role), s.active ? 'Deactivated.' : 'Reactivated.')}>{s.active ? 'Deactivate' : 'Reactivate'}</button></>}</td></tr>)}
    </tbody></table></div>
    <div className="sv-sec"><h2 className="sv-h">Who signs what</h2>
    <p className="sv-small sv-muted mb-1">v0.4: every station (check-in, rooming and vitals, MA tasks, nurse intake, ambient scribe, charts &amp; photos, checkout) is open to whoever holds the tablet. Only a signature asks for a PIN, and the audit names the signer, not the tablet session.</p>
    <table className="sv-table text-[13px]" data-testid="who-signs"><tbody>
      <tr><td style={{ width: 230 }}>Check-in · rooming/nurse intake · checkout verification</td><td>Anyone on the care team (front desk, MA, RN, coordinators, managers, providers)</td></tr>
      <tr><td>{isMedical ? 'Allergy verification · Collect payment' : 'Allergy verification · Send to ASC · Collect payment'}</td><td>Anyone on the care team, with their own PIN</td></tr>
      <tr><td>Save or sign the visit note · surgeon step · living-summary initial · review lab results</td><td>Providers only (their provider signature PIN). Anyone may dictate or edit the draft; it reaches the record only with a provider PIN.</td></tr>
      <tr><td>Open Practice (staff, settings, fees, forms, reports)</td><td>Practice Manager, Practice Administrator or a provider (access PIN; re-locks on leaving Practice or after 5 minutes idle)</td></tr>
      <tr><td>Body charts · clinical photos</td><td>Anyone on the care team takes, draws and reviews (no PIN; every add and view is audited)</td></tr>
    </tbody></table>
    <p className="sv-small sv-muted mt-2">People you register choose their own PIN through the invitation link. Five wrong PINs lock that person until a manager resets it.</p></div>
  </div>;
};

/** The invitation email as it would be sent (simulated outbox), with the link the person would tap. */
export const InvitePreview: React.FC<{ inv: StaffInvite; onClose: () => void }> = ({ inv, onClose }) => <section className="sv-mail" data-testid="invite-preview">
  <div className="flex items-start justify-between gap-2"><div><div className="sv-h">Invitation · simulated outbox · nothing was sent</div><div className="sv-small"><b>To:</b> {inv.toName} &lt;{inv.to}&gt; · <b>Subject:</b> {inv.subject}</div></div><button type="button" className="sv-link sv-small" onClick={onClose}>Close</button></div>
  <pre className="sv-mail-body">{inv.body}</pre>
  <div className="flex flex-wrap gap-2 items-center"><a className="sv-btn sm primary" href={inv.link} data-testid="invite-open-link">Open the link (as {inv.toName.split(' ')[0]})</a><button type="button" className="sv-btn sm" onClick={() => { try { void navigator.clipboard?.writeText(inv.link); } catch { /* */ } }}>Copy link</button><span className="sv-small sv-muted">Expires {new Date(inv.expiresAt).toLocaleDateString()} · single use</span></div>
</section>;

interface Profile { address: string; phone: string; email?: string; hoursStart: string; hoursEnd: string; rooms: string[] }
export const PracticeProfile: React.FC = () => {
  useMedTick(); const [session] = useActor(); const actor = practiceActor(session); const { toast } = useSv(); const s = getSettings();
  const [name, setName] = useState(s.practiceName); const [pf, setPf] = useState<Profile>(() => svRead<Profile>('profile', { address: '100 Example Way, Coastline, CA (fictional)', phone: '(555) 010-2000', hoursStart: '07:00', hoursEnd: '18:00', rooms: isAscEd ? ['OR 1', 'OR 2'] : [...MED_ROOMS] }));
  const [room, setRoom] = useState('');
  const save = () => { saveSettings({ ...getSettings(), practiceName: name.trim() || s.practiceName }, actor.name, actor.role, 'Practice profile updated'); svWrite('profile', pf); toast('Practice profile saved.'); };
  return <div className={isAscEd ? 'sv-page' : 'sv-page'} data-testid="sv-profile" style={isAscEd ? { paddingTop: 0 } : undefined}>
    {isAscEd ? <></> : <Back title="Practice profile & rooms" />}<div className={isAscEd ? 'sv-sec' : ''} data-testid="v102-hours-rooms">{isAscEd && <h2 className="sv-title" style={{ fontSize: 20 }}>Hours &amp; rooms</h2>}
    <div className="grid gap-3 max-w-[720px]" style={{ gridTemplateColumns: 'repeat(auto-fill,minmax(220px,1fr))' }}>
      {!isAscEd && <><label style={{ gridColumn: '1/-1' }}><span className="sv-label">Practice name</span><input className="sv-input" value={name} onChange={e => setName(e.target.value)} /></label>
      <label style={{ gridColumn: '1/-1' }}><span className="sv-label">Address</span><input className="sv-input" value={pf.address} onChange={e => setPf({ ...pf, address: e.target.value })} /></label>
      <label><span className="sv-label">Phone</span><input className="sv-input" value={pf.phone} onChange={e => setPf({ ...pf, phone: e.target.value })} /></label>
      <label><span className="sv-label">Email</span><input type="email" className="sv-input" value={pf.email ?? 'office@coastline-surgery.example.test'} onChange={e => setPf({ ...pf, email: e.target.value })} placeholder="office@example.test" data-testid="profile-email" /></label>
      </>}<label><span className="sv-label">Office opens</span><input type="time" className="sv-input" value={pf.hoursStart} onChange={e => setPf({ ...pf, hoursStart: e.target.value })} /></label>
      <label><span className="sv-label">Office closes</span><input type="time" className="sv-input" value={pf.hoursEnd} onChange={e => setPf({ ...pf, hoursEnd: e.target.value })} /></label>
    </div>
    {isAscEd ? <RoomsLinked /> : <><h2 className="sv-h mt-4">Exam &amp; procedure rooms</h2>
    <ul className="text-[13.5px] max-w-[520px]">{pf.rooms.map((r, i) => <li key={r + i} className="flex items-center gap-2 py-1 border-b border-[var(--line)]"><Ico k="visit" />{r}<button type="button" className="sv-link text-[12px] ml-auto" onClick={() => setPf({ ...pf, rooms: pf.rooms.filter((_, j) => j !== i) })}>remove</button></li>)}</ul>
    <div className="flex gap-2 mt-2 max-w-[520px]"><input className="sv-input" value={room} onChange={e => setRoom(e.target.value)} placeholder={isAscEd ? 'e.g. OR 3' : 'e.g. Exam 5'} /><button type="button" className="sv-btn" onClick={() => { if (room.trim()) { setPf({ ...pf, rooms: [...pf.rooms, room.trim()] }); setRoom(''); } }}>Add room</button></div></>}
    <button type="button" className="sv-btn primary mt-4" onClick={save}>Save</button>
    </div></div>;
};

/** v10.3 · one source of truth for rooms: the Schedule columns list. Hours & rooms shows it and links there. */
const RoomsLinked: React.FC = () => { const { setTab } = useSv(); const rooms = resources().filter(r => r.kind === 'room');
  return <div className="mt-4" data-testid="v103-rooms-linked"><h2 className="sv-h">Operating &amp; procedure rooms</h2>
    <ul className="text-[14px] max-w-[520px]">{rooms.map(r => <li key={r.id} className="flex items-center gap-2 py-1.5 border-b border-[var(--line)]" data-testid="v103-room"><Ico k="visit" />{r.name}{!r.schedulable && <span className="sv-small sv-muted">(hidden from the schedule)</span>}</li>)}{!rooms.length && <li className="sv-muted">No rooms yet.</li>}</ul>
    <p className="sv-small sv-muted mt-2">Rooms are kept in one place, the Schedule columns list, so the schedule and this page always match.</p>
    <button type="button" className="sv-btn mt-2" onClick={() => { setTab('surgery-settings' as any); setTimeout(() => document.getElementById('schedule-columns')?.scrollIntoView({ behavior: 'smooth' }), 120); }} data-testid="v103-edit-rooms">Add or edit rooms in Schedule columns ›</button></div>; };
