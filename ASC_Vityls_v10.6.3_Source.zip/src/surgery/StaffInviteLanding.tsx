/* Surgery.Vityls v0.3: what a newly registered team member sees when they open their invitation link
   (#staff-invite=<token>). One page: username, password, signing PIN. Simulated account service (see staff.ts). */
import React, { useState } from 'react';
import { acceptStaffInvite, resolveStaffInvite } from './staff';
import { getSettings } from '../med/settings';
import './surgery.css';

export const StaffInviteLanding: React.FC<{ token: string }> = ({ token }) => {
  const [c, setC] = useState(() => resolveStaffInvite(token)); const [u, setU] = useState(''); const [pw, setPw] = useState(''); const [pw2, setPw2] = useState(''); const [pin, setPin] = useState(''); const [pin2, setPin2] = useState(''); const [err, setErr] = useState(''); const [done, setDone] = useState(false);
  const back = () => { const url = location.href.split('#')[0]; history.replaceState(null, '', url); location.reload(); };
  const submit = () => { setErr(''); if (pw !== pw2) { setErr('The two passwords don’t match.'); return; } if (pin !== pin2) { setErr('The two PINs don’t match.'); return; } try { acceptStaffInvite(token, u.trim(), pw, pin); setDone(true); setC(resolveStaffInvite(token)); } catch (e) { setErr((e as Error).message); } };
  return <div className="sv" data-testid="staff-invite-landing" style={{ background: '#e2e5ea' }}>
    <div className="sv-main" style={{ maxWidth: 560, minHeight: 0, marginTop: 40 }}>
      <div className="sv-mark mb-1">Surgery<span>.Vityls</span></div>
      <div className="sv-sub mb-4">{getSettings().practiceName} · account setup · SIMULATION (fictional; nothing leaves this browser)</div>
      {done ? <div data-testid="invite-done"><h1 className="sv-title">You’re all set, {c.staff?.name.split(' ')[0]}.</h1><p className="mt-2 text-[14px]">Your username is <b>{c.staff?.username}</b>. Your PIN is now how you sign your own work on the office tablets. Your practice manager can see that your account is active, never your password or PIN.</p><button type="button" className="sv-btn primary mt-4" onClick={back} data-testid="invite-back">Go to Surgery.Vityls</button></div>
        : c.state !== 'ok' ? <div data-testid="invite-invalid"><h1 className="sv-title">This link can’t be used</h1><p className="mt-2">{c.state === 'used' ? 'It was already used to create an account.' : c.state === 'revoked' ? 'A newer invitation replaced it. Use the most recent email.' : c.state === 'expired' ? 'It expired. Ask your practice manager to resend it.' : 'It isn’t a valid invitation.'}</p><button type="button" className="sv-btn mt-4" onClick={back}>Back</button></div>
        : <form onSubmit={e => { e.preventDefault(); submit(); }} data-testid="invite-form">
          <h1 className="sv-title">Welcome, {c.staff!.name}</h1>
          <p className="sv-sub mb-3">You were added as <b>{c.staff!.role}</b>. Create your sign-in and your signing PIN.</p>
          <label className="block mb-2"><span className="sv-label">Username</span><input className="sv-input" value={u} onChange={e => setU(e.target.value)} autoComplete="username" data-testid="invite-username" /></label>
          <div className="grid grid-cols-2 gap-2"><label><span className="sv-label">Password (10+ characters, a number)</span><input className="sv-input" type="password" value={pw} onChange={e => setPw(e.target.value)} autoComplete="new-password" data-testid="invite-password" /></label><label><span className="sv-label">Repeat password</span><input className="sv-input" type="password" value={pw2} onChange={e => setPw2(e.target.value)} autoComplete="new-password" data-testid="invite-password2" /></label></div>
          <div className="grid grid-cols-2 gap-2 mt-2"><label><span className="sv-label">Signing PIN (4–6 digits)</span><input className="sv-input" type="password" inputMode="numeric" value={pin} onChange={e => setPin(e.target.value.replace(/\D/g, ''))} data-testid="invite-pin" /></label><label><span className="sv-label">Repeat PIN</span><input className="sv-input" type="password" inputMode="numeric" value={pin2} onChange={e => setPin2(e.target.value.replace(/\D/g, ''))} data-testid="invite-pin2" /></label></div>
          <p className="sv-small sv-muted mt-2">Avoid repeated or sequential digits. Nobody at the practice will ever ask for your password or PIN.</p>
          {err && <p className="text-[13px] text-[var(--crit)] mt-2" role="alert" data-testid="invite-error">{err}</p>}
          <button type="submit" className="sv-btn primary mt-3" data-testid="invite-submit">Create my account</button>
        </form>}
    </div>
  </div>;
};
