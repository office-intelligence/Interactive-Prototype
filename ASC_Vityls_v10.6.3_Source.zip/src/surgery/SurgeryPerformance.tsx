/*
 * Surgery.Vityls v0.3 · Practice performance (Kevin's markups on "Facility performance", 10/10):
 *  white sheet on gray like the other Surgery pages; no second Nightingale (the header one serves the page) but the
 *  period selector stays; "Patient visits" and "Surgeries scheduled"; ASC utilization by ASC name; staff efficiency =
 *  surgical coordinators; reports for a surgeon's office. Figures come from this browser's records where they exist
 *  (marked live); the rest are labeled example figures until Henry's reporting API exists.
 */
import { isMedical } from '../edition';
import React, { useMemo, useState } from 'react';
import { repo } from '../v6/dataLayer';
import { getInvoices } from '../v7/billing';
import { getProviders, displayName } from '../v7/providers';
import { medRepo, isoDay, addDays, usDate, PROVIDER_ROLES } from '../med/record';
import { useMedTick } from '../med/ui';
import { ascCases, visitTypeDef, checkoutOrders } from './store';
import { ascFacilities } from './asc';
import { coordinators, patientsOfCoordinator, coordinatorFor } from './staff';
import { patientPayments, METHOD_LABEL } from './payments';
import { visitCharges } from './charges';
import { useSv } from './ui';
import { Ico } from './icons';

type Period = 'today' | 'week' | 'month' | 'quarter' | 'ttm';
const PERIODS: { id: Period; label: string }[] = [{ id: 'today', label: 'Today' }, { id: 'week', label: 'This week' }, { id: 'month', label: 'This month' }, { id: 'quarter', label: 'Quarter' }, { id: 'ttm', label: 'Trailing 12 months' }];
const range = (p: Period): [string, string] => { const T = isoDay(); const d = new Date(); if (p === 'today') return [T, T]; if (p === 'week') { const s = addDays(T, -((d.getDay() + 6) % 7)); return [s, addDays(s, 6)]; } if (p === 'month') return [T.slice(0, 8) + '01', isoDay(new Date(d.getFullYear(), d.getMonth() + 1, 0))]; if (p === 'quarter') { const q = Math.floor(d.getMonth() / 3) * 3; const s = `${d.getFullYear()}-${String(q + 1).padStart(2, '0')}-01`; return [s, addDays(`${d.getFullYear()}-${String(q + 4).padStart(2, '0')}-01`, -1)]; } return [addDays(T, -365), T]; };
const inR = (d: string, [a, b]: [string, string]) => d >= a && d <= b;
const money = (n: number) => `$${n.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 0 })}`;
const scale: Record<Period, number> = { today: 0.2, week: 1, month: 4.3, quarter: 13, ttm: 52 };
const REASONS = isMedical ? [{ r: 'Patient rescheduled (personal)', n: 2 }, { r: 'Illness / weather', n: 1 }, { r: 'Insurance not verified', n: 1 }, { r: 'No-show (office visit)', n: 1 }] : [{ r: 'Pre-op clearance not complete', n: 2 }, { r: 'Deposit / financing not received', n: 1 }, { r: 'Patient rescheduled (personal)', n: 1 }, { r: 'No-show (office visit)', n: 1 }];

type ReportId = 'dx' | 'register' | 'coord' | 'cancel' | 'daysheet' | 'collections' | 'fees' | 'referral' | 'cred';
const REPORTS: { id: ReportId; group: string; title: string; sub: string }[] = [
  { id: 'dx', group: 'Clinical', title: 'Diagnoses & procedures', sub: 'Patients by diagnosis / condition, procedure performed vs not performed' },
  { id: 'register', group: 'Visits', title: 'Visit register', sub: 'Every office visit by date, type, surgeon and status' },
  { id: 'coord', group: 'Coordinators', title: 'Coordinator workload', sub: 'Patients per surgical coordinator, upcoming surgeries, open checkout to-dos' },
  { id: 'cancel', group: 'Access', title: 'Cancellations & no-shows', sub: 'Visits and surgeries cancelled or missed, with reason' },
  { id: 'daysheet', group: 'Revenue', title: 'Day sheet', sub: 'Today’s visits, charges, invoices and payments' },
  { id: 'collections', group: 'Revenue', title: 'Collections', sub: 'Payments taken (card, cash, check), credit on account, applied credit' },
  { id: 'fees', group: 'Revenue', title: 'Fee activity', sub: 'Charges by fee-schedule item' },
  { id: 'referral', group: 'Growth', title: 'Referral sources', sub: 'How new patients found the practice' },
  { id: 'cred', group: 'Compliance', title: 'Credentialing due', sub: 'Provider licenses, privileges and staff PIN status' },
];

export const SurgeryPerformance: React.FC = () => {
  useMedTick(); const { setTab } = useSv(); const [period, setPeriod] = useState<Period>('week'); const [rep, setRep] = useState<ReportId | null>(null);
  const R = range(period);
  const d = useMemo(() => {
    const visits = medRepo.visits().filter(v => inR(v.date, R)); const surg = ascCases().filter(c => inR(c.date, R) && !/cancel/i.test(c.status));
    const pays = patientPayments().filter(x => inR(x.at.slice(0, 10), R)); const inv = getInvoices().filter(i => inR(i.createdAt.slice(0, 10), R));
    const collected = pays.reduce((s, x) => s + x.amount, 0) + inv.reduce((s, i) => s + i.paid, 0) - pays.reduce((s, x) => s + x.applied.reduce((a, b) => a + b.amount, 0), 0);
    const surgeons = Array.from(new Set(medRepo.visits().map(v => v.provider)));
    return { visits, surg, collected, pays, inv, surgeons };
  }, [period]); // eslint-disable-line react-hooks/exhaustive-deps
  const live = <span className="sv-tag ok">live</span>; const ex = <span className="sv-tag">example</span>;
  const facilities = ascFacilities().filter(f => f.active);
  return <div className="sv-page sv-perf" data-testid="sv-performance">
    <button type="button" className="sv-link text-[13px]" onClick={() => setTab('practice')}>‹ Practice</button>
    <div className="flex flex-wrap items-end justify-between gap-3 mt-1">
      <div><h1 className="sv-title">Practice performance</h1><div className="sv-sub">Patient visits, surgeries, coordinators and money for the selected period. Ask Nightingale above, e.g. “cancellations this month”.</div></div>
      <div className="sv-seg" role="radiogroup" aria-label="Period" data-testid="perf-period">{PERIODS.map(p => <button key={p.id} type="button" role="radio" aria-checked={period === p.id} className={period === p.id ? 'on' : ''} onClick={() => setPeriod(p.id)}>{p.label}</button>)}</div>
    </div>
    <div className="sv-small sv-muted mt-1">{usDate(R[0])} – {usDate(R[1])}</div>
    <div className="sv-kpis" data-testid="perf-kpis">
      <div><span>Patient visits</span><b data-testid="kpi-visits">{d.visits.length}</b><i>{d.visits.filter(v => v.step === 'complete').length} completed {live}</i></div>
      {!isMedical && <div><span>Surgeries scheduled</span><b data-testid="kpi-surgeries">{d.surg.length}</b><i>at {new Set(d.surg.map(c => c.ascName)).size} ASC{new Set(d.surg.map(c => c.ascName)).size === 1 ? '' : 's'} {live}</i></div>}
      <div><span>Cancellations</span><b>{Math.max(0, Math.round(REASONS.reduce((s, x) => s + x.n, 0) * scale[period] / 1))}</b><i>{isMedical ? 'office visits' : 'visits + surgeries'} {ex}</i></div>
      {!isMedical && <div><span>ASC block utilization</span><b>78%</b><i>target 80% {ex}</i></div>}
      <div><span>Coordinator follow-ups</span><b>{coordinators().reduce((s, c) => s + patientsOfCoordinator(c.id).length, 0)}</b><i>patients assigned {live}</i></div>
      <div><span>Collections</span><b data-testid="kpi-collections">{money(d.collected)}</b><i>payments in period {live}</i></div>
    </div>
    <div className="sv-perf-grid">
      <section><h2 className="sv-h">Surgeon performance {live}</h2><table className="sv-table text-[13px]"><thead><tr><th>Surgeon</th><th className="text-right">Visits</th><th className="text-right">Consults</th><th className="text-right">Surgeries</th><th className="text-right">Avg visit min</th></tr></thead><tbody>
        {d.surgeons.map(s => { const vs = d.visits.filter(v => v.provider === s); const sg = d.surg.filter(c => c.surgeon.replace(/,.*$/, '') === s.replace(/,.*$/, '')); return <tr key={s}><td>{s}</td><td className="text-right">{vs.length}</td><td className="text-right">{vs.filter(v => ['new', 'pre-op'].includes(visitTypeDef(v.visitType).category) || /consult/i.test(v.visitType)).length}</td><td className="text-right">{sg.length}</td><td className="text-right">{vs.length ? Math.round(vs.reduce((a, v) => a + v.durationMin, 0) / vs.length) : '—'}</td></tr>; })}
      </tbody></table></section>
      {!isMedical && <section data-testid="perf-asc"><h2 className="sv-h">ASC utilization {ex}</h2><table className="sv-table text-[13px]"><thead><tr><th>ASC names</th><th className="text-right">Cases</th><th>Block use</th></tr></thead><tbody>
        {facilities.map((f, i) => { const pct = [81, 67, 54, 72][i % 4]; const n = ascCases().filter(c => inR(c.date, R) && (c.ascName.replace(/\s*\(.*\)/, '') === f.name.replace(/\s*\(.*\)/, '') || (f.primary && /network|harborview/i.test(c.ascName)))).length; return <tr key={f.id}><td>{f.name}{f.primary && <span className="sv-muted"> · primary</span>}</td><td className="text-right">{n}</td><td><span className="sv-bar"><i style={{ width: `${pct}%` }} /></span> {pct}%</td></tr>; })}
      </tbody></table></section>}
      <section data-testid="perf-coordinators"><h2 className="sv-h">Staff efficiency · surgical coordinators {live}</h2><table className="sv-table text-[13px]"><thead><tr><th>Coordinator</th><th className="text-right">Patients</th><th className="text-right">Surgeries ahead</th><th className="text-right">Open to-dos</th></tr></thead><tbody>
        {coordinators().map(c => { const pids = patientsOfCoordinator(c.id); const ahead = ascCases().filter(x => x.date >= isoDay() && pids.some(pid => medRepo.patient(pid)?.name === x.patientName)).length; return <tr key={c.id}><td><span className="inline-flex items-center gap-1.5 whitespace-nowrap"><Ico k="careteam" />{c.name}</span></td><td className="text-right">{pids.length}</td><td className="text-right">{ahead}</td><td className="text-right">{checkoutOrders().filter(o => o.status === 'to-do' && pids.includes(o.patientId)).length}</td></tr>; })}
        {!coordinators().length && <tr><td colSpan={4} className="sv-muted">No surgical coordinators registered (Practice › Staff).</td></tr>}
      </tbody></table><p className="sv-small sv-muted mt-1">Practices without coordinators can ignore this; assignment is optional.</p></section>
      <section><h2 className="sv-h">Cancellation reasons {ex}</h2><table className="sv-table text-[13px]"><tbody>{REASONS.map(x => <tr key={x.r}><td>{x.r}</td><td className="text-right" style={{ width: 40 }}>{x.n}</td><td style={{ width: 120 }}><span className="sv-bar"><i style={{ width: `${x.n * 40}%` }} /></span></td></tr>)}</tbody></table></section>
    </div>
    <h2 className="sv-h mt-5">Reports</h2>
    <div className="sv-reports" data-testid="perf-reports">{REPORTS.map(r => <button key={r.id} type="button" className={rep === r.id ? 'on' : ''} onClick={() => setRep(rep === r.id ? null : r.id)} data-testid={`report-${r.id}`}><span className="k">{r.group}</span><b>{r.title}</b><span>{r.sub}</span></button>)}</div>
    {rep && <Report id={rep} R={R} />}
    <VisitFlow />
  </div>;
};

const Report: React.FC<{ id: ReportId; R: [string, string] }> = ({ id, R }) => {
  const title = REPORTS.find(r => r.id === id)!.title; const T = isoDay();
  let body: React.ReactNode = null;
  if (id === 'dx') return <DxReport />;
  if (id === 'register') body = <table className="sv-table text-[13px]"><thead><tr><th>Date</th><th>Patient</th><th>Visit type</th><th>Surgeon</th><th>Status</th></tr></thead><tbody>{medRepo.visits().filter(v => inR(v.date, R)).map(v => <tr key={v.id}><td>{usDate(v.date)} {v.time}</td><td>{medRepo.patient(v.patientId)?.name}</td><td>{v.visitType}</td><td>{v.provider}</td><td>{v.step}</td></tr>)}</tbody></table>;
  if (id === 'coord') body = <table className="sv-table text-[13px]"><thead><tr><th>Coordinator</th><th>Patients</th></tr></thead><tbody>{coordinators().map(c => <tr key={c.id}><td>{c.name}</td><td>{patientsOfCoordinator(c.id).map(pid => medRepo.patient(pid)?.name).join(', ') || '—'}</td></tr>)}<tr><td className="sv-muted">Unassigned</td><td className="sv-muted">{medRepo.patients().filter(p => !coordinatorFor(p.id)).map(p => p.name).join(', ')}</td></tr></tbody></table>;
  if (id === 'cancel') body = <><table className="sv-table text-[13px]"><tbody>{ascCases().filter(c => /cancel/i.test(c.status)).map(c => <tr key={c.id}><td>{usDate(c.date)}</td><td>{c.patientName}</td><td>{c.procedure}</td><td>{c.status}</td></tr>)}{REASONS.map(x => <tr key={x.r}><td colSpan={3}>{x.r}</td><td>{x.n} (example)</td></tr>)}</tbody></table></>;
  if (id === 'daysheet') { const vs = medRepo.visits().filter(v => v.date === T); body = <table className="sv-table text-[13px]"><thead><tr><th>Time</th><th>Patient</th><th>Visit</th><th className="text-right">Charges</th><th>Invoice</th></tr></thead><tbody>{vs.map(v => { const ch = (visitCharges(v.id) || []).reduce((s, c) => s + c.amount * c.qty, 0); const inv = getInvoices().filter(i => i.caseId === v.id); return <tr key={v.id}><td>{v.time}</td><td>{medRepo.patient(v.patientId)?.name}</td><td>{v.visitType}</td><td className="text-right">${ch.toFixed(2)}</td><td>{inv.map(i => `${i.number} ${i.status}`).join(', ') || '—'}</td></tr>; })}<tr><td colSpan={3}><b>Payments taken today</b></td><td className="text-right"><b>${patientPayments().filter(x => x.at.slice(0, 10) === T).reduce((s, x) => s + x.amount, 0).toFixed(2)}</b></td><td></td></tr></tbody></table>; }
  if (id === 'collections') body = <table className="sv-table text-[13px]"><thead><tr><th>Date</th><th>Patient</th><th>Receipt</th><th>Method</th><th className="text-right">Amount</th></tr></thead><tbody>{patientPayments().filter(x => inR(x.at.slice(0, 10), R)).map(x => <tr key={x.id}><td>{usDate(x.at.slice(0, 10))}</td><td>{medRepo.patient(x.patientId)?.name}</td><td>{x.receipt}</td><td>{METHOD_LABEL[x.method]}{x.card ? ` ••${x.card.last4}` : ''}</td><td className="text-right">${x.amount.toFixed(2)}</td></tr>)}{getInvoices().filter(i => i.paid > 0 && inR(i.createdAt.slice(0, 10), R)).map(i => <tr key={i.id}><td>{usDate(i.createdAt.slice(0, 10))}</td><td>{i.patientName}</td><td>{i.number}</td><td>on invoice</td><td className="text-right">${i.paid.toFixed(2)}</td></tr>)}</tbody></table>;
  if (id === 'fees') { const m = new Map<string, { n: number; amt: number }>(); medRepo.visits().filter(v => inR(v.date, R)).forEach(v => (visitCharges(v.id) || []).forEach(c => { const x = m.get(c.label) || { n: 0, amt: 0 }; m.set(c.label, { n: x.n + c.qty, amt: x.amt + c.amount * c.qty }); })); body = <table className="sv-table text-[13px]"><thead><tr><th>Item</th><th className="text-right">Qty</th><th className="text-right">Amount</th></tr></thead><tbody>{[...m.entries()].map(([k, x]) => <tr key={k}><td>{k}</td><td className="text-right">{x.n}</td><td className="text-right">${x.amt.toFixed(2)}</td></tr>)}{!m.size && <tr><td colSpan={3} className="sv-muted">No charges in this period yet (charges start when a visit reaches the nurse, physician or checkout station).</td></tr>}</tbody></table>; }
  if (id === 'referral') body = <p className="text-[13px] sv-muted">Referral source is not captured yet. Add a “How did you hear about us?” question to the new-patient intake form (Form Studio) and this report fills in. Henry: patients.referral_source.</p>;
  if (id === 'cred') body = <table className="sv-table text-[13px]"><thead><tr><th>Provider</th><th>Role</th><th>Status</th></tr></thead><tbody>{getProviders().filter(p => PROVIDER_ROLES.includes(p.role as string) || p.role === 'Surgeon').map(p => <tr key={p.id}><td>{displayName(p)}</td><td>{p.role}</td><td>{p.app?.status || '—'}</td></tr>)}</tbody></table>;
  return <section className="sv-report" data-testid="report-view"><div className="flex items-center justify-between"><h3 className="sv-h">{title}</h3><button type="button" className="sv-link sv-small" onClick={() => window.print()}>Print</button></div>{body}</section>;
};

import { DxReport } from './v10/DxReport';
const VisitFlow: React.FC = () => {
  const visits = medRepo.visits().filter(v => v.step !== 'scheduled');
  const hm = (x: unknown) => { const m = String(x || '').match(/^(\d{2}):(\d{2})$/); return m ? +m[1] * 60 + +m[2] : null; };
  const rows = visits.map(v => { const f = repo.getFacts(v.id); const a = hm(f['visit.arrived']?.value), r = hm(f['visit.roomed']?.value), o = hm(f['visit.checkedOut']?.value); return { v, wait: a != null && r != null ? r - a : null, total: a != null && o != null ? o - a : null }; });
  return <section className="mt-6" data-testid="perf-flow"><h2 className="sv-h">Office visit flow · live from this browser</h2><table className="sv-table text-[13px]"><thead><tr><th>Patient</th><th>Visit</th><th>Step</th><th>Arrival → roomed</th><th>Total</th></tr></thead><tbody>{rows.map(r => <tr key={r.v.id}><td>{medRepo.patient(r.v.patientId)?.name}</td><td>{r.v.visitType} · {usDate(r.v.date)}</td><td>{r.v.step}</td><td>{r.wait == null ? '—' : `${r.wait} min`}</td><td>{r.total == null ? '—' : `${r.total} min`}</td></tr>)}{!rows.length && <tr><td colSpan={5} className="sv-muted">No visits started yet today.</td></tr>}</tbody></table></section>;
};
