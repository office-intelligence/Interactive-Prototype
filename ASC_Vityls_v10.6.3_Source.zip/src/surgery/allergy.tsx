/* Allergies: verify once, then treat as verified until an update is required (v0.2).
   An update is required only when: never verified, status not reported, or the patient reported something new
   (portal / intake form) after the last verification. No repeated confirmations across the care team. */
import React, { useState } from 'react';
import { repo } from '../v6/dataLayer';
import { effectiveAllergy, parseAllergyList, reportedAllergy } from '../v7/allergy';
import { medRepo, MedPatient, patientKey, fmtDate } from '../med/record';
import { useMedTick } from '../med/ui';
import { PinSign } from './sign';
import { ROLE_GROUP } from './staff';
import { Ico } from './icons';

export type AllergyNeed = null | 'never' | 'not-reported' | 'reported-change';
export function allergyStatus(p: MedPatient) {
  const a = effectiveAllergy(p.allergies, patientKey(p.id));
  let rep: any; try { rep = (repo.getFacts(patientKey(p.id)) as any)['patient.reportedAllergies']; } catch { rep = undefined; }
  const repAt: string | undefined = rep?.source?.at;
  const need: AllergyNeed = a.state === 'not-reported' && !a.pendingConfirm ? 'not-reported' : a.pendingConfirm ? 'reported-change' : !p.allergiesConfirmedAt ? 'never' : repAt && reportedAllergy(patientKey(p.id)) && repAt > p.allergiesConfirmedAt ? 'reported-change' : null;
  return { a, need, by: p.allergiesConfirmedBy, at: p.allergiesConfirmedAt, verified: need === null };
}
const NEED_TEXT: Record<Exclude<AllergyNeed, null>, string> = { never: 'Not verified yet', 'not-reported': 'Allergy status not reported', 'reported-change': 'Patient reported a change · verify' };

export const AllergyVerify: React.FC<{ p: MedPatient; compact?: boolean }> = ({ p, compact }) => {
  useMedTick(); const s = allergyStatus(p); const [sign, setSign] = useState<null | 'verify' | 'edit'>(null); const [edit, setEdit] = useState<string | null>(null);
  const list = s.a.rawList.length ? s.a.rawList : s.a.state === 'nkda' ? ['NKDA'] : [];
  const done = (who: { name: string; role: string }, newList?: string[]) => {
    const cur = medRepo.patient(p.id)!; const l = newList || list;
    medRepo.savePatient({ ...cur, allergies: l, allergiesConfirmedAt: new Date().toISOString(), allergiesConfirmedBy: who.name });
    repo.audit({ caseId: patientKey(p.id), user: who.name, role: who.role, action: 'allergy.verify', detail: `${newList ? 'Allergies updated and verified' : 'Allergies verified'} with the patient: ${l.join(', ') || 'Not reported'} (PIN)` });
    setSign(null); setEdit(null);
  };
  return <div className={`sv-allergy-v ${s.a.state === 'allergies' ? 'has' : ''}`} data-testid="allergy-verify">
    <div className="flex flex-wrap items-baseline gap-x-2 gap-y-1">
      <span className="sv-h !m-0 inline-flex items-center gap-1" style={{ color: s.a.state === 'allergies' ? 'var(--crit)' : undefined }}><Ico k="allergy" size={13} />Allergies</span>
      <span className={s.a.state === 'allergies' ? 'sv-crit' : s.a.state === 'not-reported' ? 'sv-warn' : ''} data-testid="allergy-text">{s.a.state === 'not-reported' ? 'Not reported' : s.a.text}</span>
      {s.verified ? <span className="sv-tag ok" data-testid="allergy-verified">✓ Verified · {s.by} · {fmtDate(s.at)}</span> : <span className="sv-tag warn" data-testid="allergy-needs">{NEED_TEXT[s.need!]}</span>}
      {!compact && !s.verified && <button type="button" className="sv-btn sm" onClick={() => setSign('verify')} disabled={!list.length} data-testid="allergy-verify-btn">Verify with patient</button>}
      {!compact && edit === null && <button type="button" className="sv-link text-[12px]" onClick={() => setEdit(s.a.state === 'nkda' ? 'NKDA' : s.a.items.join('; '))} data-testid="allergy-change">Record a change</button>}
    </div>
    {s.verified && !compact && <p className="text-[11.5px] sv-muted mt-0.5">Verified once; stays verified until the patient reports a change. No need to confirm again at each station.</p>}
    {edit !== null && <div className="flex flex-wrap gap-2 mt-2"><input className="sv-input flex-1 min-w-[200px]" value={edit} onChange={e => setEdit(e.target.value)} placeholder="e.g. Penicillin (hives); or NKDA" data-testid="allergy-edit-input" /><button type="button" className="sv-btn sm primary" onClick={() => setSign('edit')} data-testid="allergy-edit-save">Save &amp; verify</button><button type="button" className="sv-btn sm" onClick={() => setEdit(null)}>Cancel</button></div>}
    {sign && <PinSign title={sign === 'edit' ? 'Update and verify allergies' : 'Verify allergies'} statement={<>I reviewed the allergy list with {p.name}: <b>{sign === 'edit' ? (parseAllergyList(edit || '').join(', ') || 'Not reported') : list.join(', ')}</b>.</>} roles={ROLE_GROUP.everyone} onClose={() => setSign(null)} onSigned={w => done(w, sign === 'edit' ? parseAllergyList(edit || '') : undefined)} confirmLabel="Verify" />}
  </div>;
};
