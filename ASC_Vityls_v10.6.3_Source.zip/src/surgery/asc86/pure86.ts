/* ASC.Vityls v8.6 · pure logic (no browser APIs; unit-tested in tests/asc86.test.ts).
 * Doctor orders (versions, signer role, status), PACU vitals flowsheet, episode worklist + closure checklist,
 * booking dedupe, reschedule history, two-day reminder text, episode search, print header, efficiency metrics.
 * All seeded order-set text is EXAMPLE TEMPLATE TEXT awaiting clinical approval; it carries no drug doses. Fictional data. */

/* ---------------- content hash: binds a signature to the exact version signed ---------------- */
export function contentHash(s: string): string { let h = 0x811c9dc5; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 0x01000193) >>> 0; } return h.toString(16).padStart(8, '0'); }

/* ---------------- doctor orders ---------------- */
export type Phase = 'preop' | 'postop' | 'pacu';
export type SignerRole = 'surgeon' | 'anesthesia';
export type OrderStatus = 'draft' | 'active' | 'discontinued' | 'superseded';
export const PHASE_LABEL: Record<Phase, string> = { preop: 'Pre-op orders', postop: 'Post-op orders', pacu: 'PACU orders' };
export const STATUS_LABEL: Record<OrderStatus, string> = { draft: 'Draft · not signed', active: 'Signed · active', discontinued: 'Discontinued', superseded: 'Superseded' };
export const TEMPLATE_BANNER = 'EXAMPLE TEMPLATE TEXT · items come from the Standard doctor’s orders list (examples for Medical Director approval). Example doses are pre-filled; the ordering clinician confirms or adjusts every dose before signing.';
export interface OrderItem { id: string; text: string; on: boolean; field?: string; value?: string; orig?: string }
export interface Stamp { by: string; role: string; at: string }
export interface OrderVersion { v: number; items: OrderItem[]; note?: string; status: OrderStatus; author: Stamp; proposedBy?: 'Nightingale' | 'Template'; signed?: Stamp & { hash: string }; ended?: Stamp & { reason: string }; acks: Stamp[]; exec: (Stamp & { itemId: string; note?: string })[] }
export interface OrderSet { id: string; caseId: string; phase: Phase; signer: SignerRole; versions: OrderVersion[] }
/** Example templates: workflow placeholders only. Patient-specific fields are blank for the ordering clinician. */
export const TEMPLATES: Record<Phase, { signer: SignerRole; items: [string, string?][] }> = {
  preop: { signer: 'surgeon', items: [['Antibiotic prophylaxis per approved center protocol', 'Drug / dose / timing (ordering clinician enters)'], ['VTE prophylaxis per approved risk assessment', 'Method'], ['Hold or continue home medications as specified', 'Which medications'], ['Site marking verification with the patient'], ['Additional pre-op test, if indicated', 'Test']] },
  postop: { signer: 'surgeon', items: [['Diet advance as tolerated, or as specified', 'Diet'], ['Activity / weight-bearing', 'Specify'], ['Wound and dressing care', 'Instructions'], ['Discharge prescriptions per surgeon', 'Prescriptions (ordering clinician enters)'], ['Follow-up appointment', 'When / where']] },
  pacu: { signer: 'anesthesia', items: [['Vital signs every 15 minutes or per approved PACU policy', 'Interval'], ['Oxygen to keep SpO2 at the ordered target', 'Target (ordering clinician enters)'], ['Analgesia per anesthesiologist', 'Drug / dose (ordering clinician enters)'], ['Antiemetic per anesthesiologist, if needed', 'Drug / dose (ordering clinician enters)'], ['Notify anesthesiologist for parameters outside ordered limits', 'Parameters'], ['Discharge from PACU when approved criteria are met']] },
};
export const versionText = (v: Pick<OrderVersion, 'items' | 'note'>) => v.items.filter(i => i.on).map(i => `${i.text}${i.field ? `: ${i.value || '—'}${i.orig != null && i.orig !== '' && i.value !== i.orig ? ` (adjusted from standard ${i.orig})` : ''}` : ''}`).join('\n') + (v.note ? `\nNote: ${v.note}` : '');
export const current = (s: OrderSet) => s.versions[s.versions.length - 1];
export const activeVersion = (s: OrderSet) => s.versions.find(v => v.status === 'active');
export function newSet(id: string, caseId: string, phase: Phase, author: Stamp, proposedBy: OrderVersion['proposedBy'] = 'Template', signer?: SignerRole): OrderSet {
  const t = TEMPLATES[phase]; return { id, caseId, phase, signer: signer || t.signer, versions: [{ v: 1, items: t.items.map(([text, field], i) => ({ id: `${phase}-${i + 1}`, text, on: true, ...(field ? { field, value: '' } : {}) })), status: 'draft', author, proposedBy, acks: [], exec: [] }] };
}
/** Edit: drafts edit in place; editing a signed set starts a new draft version (the signed one stays active until the new one is signed). */
export function editSet(s: OrderSet, items: OrderItem[], note: string | undefined, by: Stamp): OrderSet {
  const cur = current(s); if (cur.status === 'draft') return { ...s, versions: [...s.versions.slice(0, -1), { ...cur, items, note, author: by }] };
  return { ...s, versions: [...s.versions, { v: cur.v + 1, items, note, status: 'draft', author: by, acks: [], exec: [] }] };
}
export const roleFits = (signer: SignerRole, personRole: string) => signer === 'anesthesia' ? /anesthesiolog|crna/i.test(personRole) : /^(surgeon|physician)$/i.test(personRole.trim());
/** Sign the current draft. Only a person whose role matches the set's signer role may sign; Nightingale/System never can. */
export function signSet(s: OrderSet, by: Stamp): OrderSet {
  if (/nightingale|system/i.test(by.by) || /system/i.test(by.role)) throw new Error('Nightingale cannot sign or release orders.');
  if (!roleFits(s.signer, by.role)) throw new Error(`These orders need the ${s.signer === 'anesthesia' ? 'anesthesiologist' : 'surgeon'}’s signature.`);
  const cur = current(s); if (cur.status !== 'draft') throw new Error('Nothing to sign: no draft.');
  return { ...s, versions: s.versions.map(v => v === cur ? { ...v, status: 'active' as const, signed: { ...by, hash: contentHash(versionText(v)) } } : v.status === 'active' ? { ...v, status: 'superseded' as const, ended: { ...by, reason: `Replaced by version ${cur.v}` } } : v) };
}
export function discontinue(s: OrderSet, by: Stamp, reason: string): OrderSet {
  if (!reason.trim()) throw new Error('Give a reason.'); return { ...s, versions: s.versions.map(v => v.status === 'active' ? { ...v, status: 'discontinued' as const, ended: { ...by, reason } } : v) };
}
export function acknowledge(s: OrderSet, by: Stamp): OrderSet { return { ...s, versions: s.versions.map(v => v.status === 'active' ? { ...v, acks: [...v.acks, by] } : v) }; }
export function execute(s: OrderSet, itemId: string, by: Stamp, note = ''): OrderSet { return { ...s, versions: s.versions.map(v => v.status === 'active' ? { ...v, exec: [...v.exec, { ...by, itemId, note }] } : v) }; }
/** Signed content still matches its signature (signature bound to the exact version). */
export const signatureValid = (v: OrderVersion) => !!v.signed && v.signed.hash === contentHash(versionText(v));
/** Nurse-facing state per set: needs acknowledgment when the active version has none since signing. */
export function nurseState(s: OrderSet): 'none' | 'draft-only' | 'needs-ack' | 'acked' | 'discontinued' {
  const a = activeVersion(s); if (!a) return s.versions.some(v => v.status === 'discontinued') ? 'discontinued' : 'draft-only'; return a.acks.length ? 'acked' : 'needs-ack';
}

/* ---------------- PACU vitals flowsheet ---------------- */
export interface VRow { id: string; kind: 'scheduled' | 'adhoc'; measured: string /* HH:MM */; enteredAt: string /* ISO */; by: string; bp?: string; hr?: string; rr?: string; spo2?: string; temp?: string; pain?: string; note?: string; corrects?: string; correctReason?: string }
export const VFIELDS: [keyof VRow, string][] = [['bp', 'BP'], ['hr', 'HR'], ['rr', 'RR'], ['spo2', 'SpO₂ %'], ['temp', 'Temp °C'], ['pain', 'Pain 0–10']];
export const hmToMin = (t: string) => { const m = /(\d+):(\d+)\s*(AM|PM)?/i.exec(t || ''); if (!m) return NaN; let h = +m[1]; if (m[3]) { h %= 12; if (/pm/i.test(m[3])) h += 12; } return h * 60 + +m[2]; };
export const minToHm = (n: number) => `${String(Math.floor(((n % 1440) + 1440) % 1440 / 60)).padStart(2, '0')}:${String(((n % 60) + 60) % 60).padStart(2, '0')}`;
/** Late entry: entered more than `lateMin` after the time measured (both in local minutes of the day). */
export const isLate = (measured: string, enteredMin: number, lateMin = 10) => enteredMin - hmToMin(measured) > lateMin;
/** 15-minute slots from PACU arrival to now; each slot filled by a scheduled row within ±7 min. Never auto-completes. */
export function slots(pacuIn: string, nowMin: number, rows: VRow[], every = 15, graceMin = 5) {
  const start = hmToMin(pacuIn); if (isNaN(start)) return [];
  const live = rows.filter(r => !rows.some(x => x.corrects === r.id));
  const out: { at: string; filled?: VRow; overdue: boolean }[] = [];
  for (let t = start; t <= nowMin; t += every) { const f = live.find(r => Math.abs(hmToMin(r.measured) - t) <= 7); out.push({ at: minToHm(t), filled: f, overdue: !f && nowMin - t > graceMin }); }
  return out;
}
export const liveRows = (rows: VRow[]) => rows.filter(r => !rows.some(x => x.corrects === r.id)).sort((a, b) => hmToMin(a.measured) - hmToMin(b.measured));
export function trend(rows: VRow[], k: 'hr' | 'rr' | 'spo2' | 'pain' | 'sys'): number[] { return liveRows(rows).map(r => k === 'sys' ? parseInt(String(r.bp || '').split('/')[0]) : parseFloat(String(r[k] || ''))).filter(n => !isNaN(n)); }
/** A new row always starts blank: no copy-forward of prior vitals. */
export const blankRow = (id: string, measured: string, enteredAt: string, by: string, kind: VRow['kind']): VRow => ({ id, kind, measured, enteredAt, by });

/* ---------------- dedupe, reschedule history, reminder ---------------- */
export const normName = (n: string) => n.toLowerCase().replace(/[^a-z ]/g, '').split(/\s+/).filter(Boolean).sort().join(' ');
export const normDob = (d: string) => { const m = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/.exec(d.trim()); if (m) return `${m[3]}-${m[1].padStart(2, '0')}-${m[2].padStart(2, '0')}`; return /^\d{4}-\d{2}-\d{2}$/.test(d.trim()) ? d.trim() : ''; };
export function dupCandidates<P extends { id: string; name: string; dob: string; phone?: string }>(name: string, dob: string, phone: string, pts: P[]): { p: P; why: string }[] {
  const n = normName(name), d = normDob(dob), ph = (phone || '').replace(/\D/g, '');
  return pts.map(p => { const sameN = normName(p.name) === n, sameD = !!d && normDob(p.dob) === d, sameP = ph.length >= 7 && (p.phone || '').replace(/\D/g, '') === ph;
    const why = sameN && sameD ? 'same name and date of birth' : sameD && sameP ? 'same date of birth and phone' : sameN && sameP ? 'same name and phone' : ''; return { p, why }; }).filter(x => x.why);
}
export interface SchedChange { at: string; by: string; role: string; kind: 'booked' | 'rescheduled' | 'cancelled'; from?: string; to?: string; reason?: string; notices: string[] }
export function scheduleDiff(a: { date: string; time: string; room: string; surgeon: string }, b: { date: string; time: string; room: string; surgeon: string }): string {
  const p: string[] = []; if (a.date !== b.date) p.push(`date ${a.date} → ${b.date}`); if (a.time !== b.time) p.push(`time ${a.time} → ${b.time}`); if (a.room !== b.room) p.push(`room ${a.room} → ${b.room}`); if (a.surgeon !== b.surgeon) p.push(`surgeon ${a.surgeon} → ${b.surgeon}`); return p.join(' · ');
}
export const arrivalTime = (start: string, before = 60) => { const m = hmToMin(start) - before; const h = Math.floor(m / 60), mm = m % 60; return `${((h + 11) % 12) + 1}:${String(mm).padStart(2, '0')} ${h < 12 ? 'AM' : 'PM'}`; };
export const REMINDER_INSTR = ['Fasting: follow the instructions your care team gave you.', 'Medications: take or hold only as your surgeon or anesthesiologist instructed.', 'Escort: a responsible adult must drive you home and stay with you.', 'Questions about your care go to the nurse line; this message cannot give medical advice.'];
export function twoDayReminder(x: { first: string; date: string; start: string; location: string; phone: string; arrivalOverride?: string }): string {
  const arr = x.arrivalOverride || arrivalTime(x.start);
  return [`Hi ${x.first}, this is a reminder of your surgery on ${x.date}.`, `Please arrive at ${arr} (1 hour before your ${x.start.replace(/^0/, '')} start${x.arrivalOverride ? ', per your care team' : ''}).`, `Location: ${x.location}.`, ...REMINDER_INSTR, `Contact: ${x.phone}.`].join('\n');
}

/* ---------------- episode search ---------------- */
export interface SearchCase { id: string; pid: string; date: string; name: string; procedure: string; cancelled?: boolean }
export function searchEpisodes(q: string, dos: string, list: SearchCase[]): SearchCase[] {
  const s = q.trim().toLowerCase(); if (!s && !dos) return [];
  return list.filter(c => (!s || c.pid.toLowerCase() === s || c.pid.toLowerCase().includes(s) || c.name.toLowerCase().includes(s)) && (!dos || c.date === dos)).sort((a, b) => b.date.localeCompare(a.date));
}

/* ---------------- closure checklist + status ---------------- */
export type Owner = 'Front desk' | 'Pre-op nursing' | 'Anesthesia' | 'Surgeon' | 'PACU nursing' | 'Billing' | 'Medical records';
export interface CloseItem { id: string; label: string; owner: Owner; done: boolean; source: string; financial?: boolean }
export interface CloseState { reviewed?: Stamp & { mode: 'ai' | 'manual' }; exceptions: Record<string, Stamp & { reason: string }>; closed?: Stamp; reopened: (Stamp & { reason: string })[]; amendments: (Stamp & { what: string; doc: string })[] }
export const emptyClose = (): CloseState => ({ exceptions: {}, reopened: [], amendments: [] });
export function closureGaps(items: CloseItem[], st: CloseState) { const doc = items.filter(i => !i.financial), fin = items.filter(i => i.financial);
  const openDoc = doc.filter(i => !i.done && !st.exceptions[i.id]); return { docTotal: doc.length, docDone: doc.length - openDoc.length, openDoc, finOpen: fin.filter(i => !i.done), canClose: true /* Kevin: closing is never blocked; open items are shown and logged */, clean: openDoc.length === 0 && !!st.reviewed }; }
export const docStatus = (items: CloseItem[], st: CloseState) => st.closed ? 'Closed' : closureGaps(items, st).openDoc.length ? 'Documentation open' : 'Documentation complete';
export const finStatus = (items: CloseItem[]) => items.filter(i => i.financial && !i.done).length ? 'Financial open' : 'Financial reconciled';
export function byOwner(items: CloseItem[], st: CloseState): Record<string, CloseItem[]> { const o: Record<string, CloseItem[]> = {}; items.filter(i => !i.done && !st.exceptions[i.id]).forEach(i => (o[i.owner] = o[i.owner] || []).push(i)); return o; }

/* ---------------- follow-up call ---------------- */
export interface CallAttempt { at: string; by: string; outcome: 'reached' | 'no answer' | 'left message' | 'concern'; note: string }
export interface FollowUp { owner: string; due: string; attempts: CallAttempt[]; escalated?: Stamp & { to: string; note: string }; done?: Stamp }
export const followDue = (dos: string) => { const d = new Date(dos + 'T12:00'); d.setDate(d.getDate() + 2); return d.toISOString().slice(0, 10); };
export const followNeedsEscalation = (f: FollowUp) => !f.escalated && (f.attempts.some(a => a.outcome === 'concern') || f.attempts.filter(a => a.outcome !== 'reached').length >= 3);

/* ---------------- metrics ---------------- */
export function median(xs: number[]) { if (!xs.length) return NaN; const s = [...xs].sort((a, b) => a - b); const m = s.length >> 1; return s.length % 2 ? s[m] : (s[m - 1] + s[m]) / 2; }
export const pct = (a: number, b: number) => b ? Math.round((100 * a) / b) : 0;
