/* ASC.Vityls v8.6 · browser storage for orders, flowsheet, follow-up, closure, op-report receipt, schedule history,
 * consent witness and print/export events. Every change is audited through repo.audit. Fictional data; externals simulated.
 * Henry: order_set/order_version/order_ack/order_exec, vitals_row, follow_up(+attempt), episode_closure, schedule_change, print_event. */
import { repo } from '../../v6/dataLayer';
import { svRead, svWrite } from '../store';
import * as P from './pure86';
const bump = () => window.dispatchEvent(new Event('vityls-med-updated'));
const K = { orders: 'asc86-orders', vit: 'asc86-vitals', fu: 'asc86-followup', close: 'asc86-closure', op: 'asc86-opreceipt', hist: 'asc86-sched-history', wit: 'asc86-witness', print: 'asc86-print-log', remind: 'asc86-reminders', dc: 'asc86-discharge' };
export const audit86 = (cid: string, by: string, role: string, detail: string, action = 'asc86') => repo.audit({ caseId: `asc8:${cid}`, user: by, role, action: action as any, detail });
const map = <T,>(k: string) => svRead<Record<string, T>>(k, {});
const put = <T,>(k: string, id: string, v: T) => { svWrite(k, { ...map<T>(k), [id]: v }); bump(); };
export const stamp = (by: string, role: string): P.Stamp => ({ by, role, at: new Date().toISOString() });

/* orders */
export const orderSets = (cid: string) => Object.values(map<P.OrderSet>(K.orders)).filter(s => s.caseId === cid);
export const orderSet = (cid: string, phase: P.Phase) => orderSets(cid).find(s => s.phase === phase);
export function saveSet(s: P.OrderSet, by: P.Stamp, what: string) { put(K.orders, s.id, s); audit86(s.caseId, by.by, by.role, `${P.PHASE_LABEL[s.phase]} v${P.current(s).v}: ${what}`, 'asc86.order'); }
/* vitals */
export const vitals = (cid: string) => map<P.VRow[]>(K.vit)[cid] || [];
export function addVital(cid: string, r: P.VRow, role: string, what: string) { put(K.vit, cid, [...vitals(cid), r]); audit86(cid, r.by, role, what, 'asc86.vitals'); }
/* discharge extras */
export const dcx = (cid: string) => map<Record<string, any>>(K.dc)[cid] || {};
export function setDcx(cid: string, x: Record<string, any>, by: string, role: string, what: string) { put(K.dc, cid, { ...dcx(cid), ...x }); audit86(cid, by, role, what, 'asc86.discharge'); }
/* follow-up + survey */
export const followUp = (cid: string) => map<P.FollowUp & { survey?: { status: string; at: string } }>(K.fu)[cid];
export function saveFollow(cid: string, f: P.FollowUp & { survey?: any }, by: string, role: string, what: string) { put(K.fu, cid, f); audit86(cid, by, role, what, 'asc86.followup'); }
/* op report receipt */
export interface OpReceipt { received?: P.Stamp & { via: string }; signed?: P.Stamp; amendments: (P.Stamp & { note: string; hash: string })[] }
export const opReceipt = (cid: string): OpReceipt => map<OpReceipt>(K.op)[cid] || { amendments: [] };
export function saveOp(cid: string, r: OpReceipt, by: string, role: string, what: string) { put(K.op, cid, r); audit86(cid, by, role, what, 'asc86.opreport'); }
/* closure */
export const closeState = (cid: string): P.CloseState => ({ ...P.emptyClose(), ...(map<P.CloseState>(K.close)[cid] || {}) });
export function saveClose(cid: string, s: P.CloseState, by: string, role: string, what: string) { put(K.close, cid, s); audit86(cid, by, role, what, 'asc86.closure'); }
/* schedule history (booked / rescheduled / cancelled), keyed by patient so cancelled episodes stay linked */
export const schedHistory = (pid: string) => (map<P.SchedChange[]>(K.hist)[pid] || []);
export function logSched(pid: string, cid: string, x: P.SchedChange) { put(K.hist, pid, [...schedHistory(pid), x]); audit86(cid, x.by, x.role, `Schedule ${x.kind}${x.from ? `: ${x.from}` : ''}${x.reason ? ` · ${x.reason}` : ''} · notices: ${x.notices.join('; ') || 'none'}`, 'asc86.schedule'); }
/* reminders (simulated outbox) */
export const reminders = (cid: string) => map<{ kind: string; on: string; body: string; status: string }[]>(K.remind)[cid] || [];
export function setReminders(cid: string, list: { kind: string; on: string; body: string; status: string }[]) { put(K.remind, cid, list); }
/* consent witness / representative */
export const witness = (cid: string) => map<Record<string, any>>(K.wit)[cid] || {};
export function saveWitness(cid: string, doc: string, w: any, by: string, role: string) { put(K.wit, cid, { ...witness(cid), [doc]: w }); audit86(cid, by, role, `${doc}: ${w.kind === 'representative' ? `signed by representative ${w.name} (${w.relation})` : `witnessed by ${w.name}`}`, 'asc86.consent'); }
/* print / export events */
export const printLog = () => svRead<{ at: string; by: string; role: string; cid: string; what: string; kind: 'print' | 'export' }[]>(K.print, []);
export function logPrint(cid: string, by: string, role: string, what: string, kind: 'print' | 'export' = 'print') { svWrite(K.print, [...printLog(), { at: new Date().toISOString(), by, role, cid, what, kind }]); audit86(cid, by, role, `${kind === 'print' ? 'Printed' : 'Exported'}: ${what}`, `asc86.${kind}`); }
/* duplicate-patient preventions (metric) */
export const dupCount = () => svRead<number>('asc86-dupes', 0);
export const incDup = () => svWrite('asc86-dupes', dupCount() + 1);
/* booking confirmation + two-day reminder (simulated outbox; regenerated on reschedule) */
export const CENTER = { location: 'ASC.Vityls Surgery Center (fictional), 100 Example Ave, Suite 1, check in at the 1st-floor front desk', phone: '(555) 010-0100' };
export function queueReminders(cid: string, first: string, date: string, time: string) {
  const d = new Date(date + 'T12:00'); d.setDate(d.getDate() - 2); const on = d.toISOString().slice(0, 10);
  const prev = reminders(cid).map(r => r.status.startsWith('queued') ? { ...r, status: 'replaced (schedule changed)' } : r);
  setReminders(cid, [...prev, { kind: 'Booking confirmation', on: new Date().toISOString().slice(0, 10), body: `Hi ${first}, your surgery is booked for ${date} at ${time.replace(/^0/, '')}. Reply C to confirm.`, status: 'queued (simulated)' }, { kind: 'Two-day reminder', on, body: P.twoDayReminder({ first, date, start: time, location: CENTER.location, phone: CENTER.phone }), status: 'queued (simulated)' }]);
}
/* fictional seed: PACU patient c2 gets a signed example PACU order set + two flowsheet rows (labeled example template text) */
export function ensureAsc86Seed() {
  if (svRead<string>('asc86-seeded', '') === 'asc86-seed-1') return; const at = new Date().toISOString(); const d = new Date();
  let s = P.newSet('os-c2-pacu', 'c2', 'pacu', { by: 'Noor Haddad, MD', role: 'Anesthesiologist', at }, 'Template');
  s = P.editSet(s, P.current(s).items.map(i => i.field ? { ...i, value: i.id === 'pacu-1' ? 'Every 15 min × 4, then every 30 min' : '[example — clinician enters]' } : i), 'Example template text awaiting clinical approval (fictional).', { by: 'Noor Haddad, MD', role: 'Anesthesiologist', at });
  s = P.signSet(s, { by: 'Noor Haddad, MD', role: 'Anesthesiologist', at });
  svWrite(K.orders, { ...map<P.OrderSet>(K.orders), [s.id]: s });
  const hm = (back: number) => { const x = new Date(d.getTime() - back * 60000); return `${String(x.getHours()).padStart(2, '0')}:${String(x.getMinutes()).padStart(2, '0')}`; };
  svWrite(K.vit, { ...map<P.VRow[]>(K.vit), c2: [{ ...P.blankRow('vs1', hm(32), new Date(d.getTime() - 31 * 60000).toISOString(), 'Alex Rivera', 'scheduled'), bp: '132/78', hr: '84', rr: '16', spo2: '97', temp: '36.4', pain: '4' }, { ...P.blankRow('vs2', hm(17), new Date(d.getTime() - 16 * 60000).toISOString(), 'Alex Rivera', 'scheduled'), bp: '126/76', hr: '80', rr: '14', spo2: '98', pain: '3' }] });
  svWrite('asc86-seeded', 'asc86-seed-1');
}
