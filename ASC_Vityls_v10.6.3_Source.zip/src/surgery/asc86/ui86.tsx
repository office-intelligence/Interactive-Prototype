/* ASC.Vityls v8.6 · Doctor Orders section + active orders card, PACU vitals flowsheet, discharge confirmations,
 * follow-up call + survey, op report receipt, Nightingale closure checklist (human review, manual path), close/reopen/amend,
 * episode worklist, episode search, print packet with per-page patient header, admin efficiency metrics, consent witness.
 * Kevin's rule: nothing ever blocks a station or the episode close; missing items are tinted warnings and are logged.
 * Nightingale drafts only (never signs/releases orders). External services simulated. Fictional data only. */
import React, { useState } from 'react';
import { medRepo, isoDay, PROVIDER_ROLES } from '../../med/record';
import { useActor, useMedTick } from '../../med/ui';
import * as A from '../asc8/logic';
import * as S from '../asc8/store';
import { use81, s81 } from '../asc81/store81';
import { PinSign } from '../sign';
import { ExcBox } from '../asc84/exc';
import { XClose } from '../asc82/common';
import { caseMoney } from '../asc83/pay';
import { cancelledCases } from '../asc83/frontdesk';
import { docsForCase, exportText } from '../asc83/docs';
import * as P from './pure86';
import * as D from './store86';
import { standingItems } from '../asc87/ui87';

const tm = (iso?: string) => iso ? new Date(iso).toLocaleString([], { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' }) : '';
const nowHm = () => { const d = new Date(); return `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`; };
const nowMin = () => { const d = new Date(); return d.getHours() * 60 + d.getMinutes(); };
const pname = (c: A.AscCase) => medRepo.patient(c.pid)?.name || c.pid;
const Sec: React.FC<{ title: React.ReactNode; right?: React.ReactNode; tid?: string; tone?: string; children: React.ReactNode }> = ({ title, right, tid, tone, children }) => <section className={`a82-sec a86-sec ${tone || ''}`} data-testid={tid}><div className="a82-sh"><h3 className="a81-h3">{title}</h3>{right}</div>{children}</section>;
const SignBtn: React.FC<{ label: string; roles: string[]; what: string; tid: string; cid?: string; allow?: (p: { name: string; role: string }) => boolean; onSigned: (by: string, role: string) => void; ghost?: boolean }> = ({ label, roles, what, tid, cid, allow, onSigned, ghost }) => {
  const [o, setO] = useState(false);
  return <><button type="button" className={`a8-btn ${ghost ? '' : 'pri'}`} onClick={() => setO(true)} data-testid={`${tid}-open`}>{label}</button>{o && <PinSign title={label} sigCase={cid} statement={<>I reviewed “{what}”. Nightingale drafted; it does not sign.</>} roles={roles} allow={allow} confirmLabel="Sign" onClose={() => setO(false)} onSigned={s => { setO(false); onSigned(s.name, s.role); }} />}</>;
};
const SIGN_ROLES = (s: P.SignerRole) => s === 'anesthesia' ? S.ANES_ROLES : PROVIDER_ROLES;
const NURSES = [...S.NURSE_ROLES];

/* ======================= Doctor Orders (dedicated section) ======================= */
export const StatusPill: React.FC<{ s: P.OrderStatus }> = ({ s }) => <span className={`a86-pill ${s}`} data-testid="a86-status" data-status={s}>{P.STATUS_LABEL[s]}</span>;
export const OrdersSection: React.FC<{ c: A.AscCase }> = ({ c }) => {
  useMedTick(); const [phase, setPhase] = useState<P.Phase>('preop');
  return <div data-testid="a86-orders"><div className="a86-banner" data-testid="a86-template-banner">⚠ {P.TEMPLATE_BANNER}</div>
    <nav className="a83-tabs" role="tablist">{(['preop', 'postop', 'pacu'] as P.Phase[]).map(p => { const s = D.orderSet(c.id, p); return <button key={p} type="button" role="tab" aria-selected={phase === p} className={phase === p ? 'on' : ''} onClick={() => setPhase(p)} data-testid={`a86-ord-tab-${p}`}>{P.PHASE_LABEL[p]}{s && <StatusPill s={(P.activeVersion(s) && P.current(s).status === 'draft') ? 'draft' : P.current(s).status} />}</button>; })}</nav>
    <OrderPhase key={phase} c={c} phase={phase} /></div>;
};
const OrderPhase: React.FC<{ c: A.AscCase; phase: P.Phase }> = ({ c, phase }) => {
  const [actor] = useActor(); const set = D.orderSet(c.id, phase); const me = D.stamp(actor.name, actor.role);
  const [signer, setSigner] = useState<P.SignerRole>(P.TEMPLATES[phase].signer); const [why, setWhy] = useState(''); const [err, setErr] = useState('');
  const start = (by: 'Template' | 'Nightingale') => { const s0 = P.newSet(`os-${c.id}-${phase}`, c.id, phase, by === 'Nightingale' ? { by: 'Nightingale (draft)', role: 'AI draft', at: me.at } : me, by, signer); const std = standingItems(phase); const s = std.length ? { ...s0, versions: [{ ...s0.versions[0], items: std }] } : s0; D.saveSet(s, me, `${by === 'Nightingale' ? 'Nightingale proposed a draft' : 'Draft started from the standard doctor’s orders list'} · signer: ${signer}`); };
  const legacy = phase === 'pacu' ? s81.ai(c.id).orders : undefined;
  const Legacy = legacy?.text ? <details className="a81-box mt-2" data-testid="a86-legacy-orders"><summary>Legacy free-text PACU orders (read-only, before v8.6.1){legacy.signed ? ` · signed ${legacy.signed.by} ${tm(legacy.signed.at)}` : ' · not signed'}</summary><pre className="a81-pre">{legacy.text}</pre></details> : null;
  if (!set) return <Sec title={P.PHASE_LABEL[phase]} tid={`a86-phase-${phase}`}>{Legacy}<p className="sv-muted">No orders yet.</p>
    <div className="a81-foot"><label className="sv-small">Signer for this set <select className="sv-input" style={{ width: 'auto' }} value={signer} onChange={e => setSigner(e.target.value as P.SignerRole)} data-testid="a86-signer"><option value="surgeon">Surgeon</option><option value="anesthesia">Anesthesiologist</option></select></label>
      <button type="button" className="a8-btn" onClick={() => start('Nightingale')} data-testid="a86-ord-propose">✦ Nightingale: propose draft</button><button type="button" className="a8-btn pri" onClick={() => start('Template')} data-testid="a86-ord-new">Start from standard list</button></div>
    <p className="sv-small sv-muted">Nightingale can only propose a draft. The {signer === 'anesthesia' ? 'anesthesiologist' : 'surgeon'} confirms applicability, edits, and signs with their own PIN.</p></Sec>;
  const cur = P.current(set); const act = P.activeVersion(set); const editing = cur.status === 'draft';
  const upItems = (items: P.OrderItem[], note = cur.note) => { setErr(''); D.saveSet(P.editSet(set, items, note, me), me, editing ? 'draft edited' : `new draft version started (v${cur.v} stays active until signed)`); };
  const sign = (by: string, role: string) => { try { const n = P.signSet(set, D.stamp(by, role)); D.saveSet(n, D.stamp(by, role), `signed by ${by} (${role})${act ? `; v${act.v} superseded` : ''} · nursing notified`); S.raiseFlag({ from: by, fromRole: role, to: phase === 'pacu' || phase === 'postop' ? 'pacu' : 'preop', pid: c.pid, caseId: c.id, text: `${P.PHASE_LABEL[phase]} v${P.current(n).v} signed for ${pname(c)}: please acknowledge.` }); } catch (e) { setErr((e as Error).message); } };
  return <Sec title={<>{P.PHASE_LABEL[phase]} <span className="sv-small sv-muted">· signer: {set.signer === 'anesthesia' ? 'Anesthesiologist' : 'Surgeon'}</span></>} tid={`a86-phase-${phase}`} right={<StatusPill s={cur.status} />}>
    {act && editing && <p className="a86-tint warn" data-testid="a86-pending-change">Version {act.v} is active. Version {cur.v} is an unsigned draft change and is NOT in effect until signed.</p>}
    {(editing ? cur : act || cur).items.map((it, i) => <div key={it.id} className={`a82-ck ${it.on ? 'on' : ''}`} data-testid="a86-ord-item"><label className="row"><input type="checkbox" checked={it.on} disabled={!editing && cur.status !== 'active'} onChange={e => upItems(cur.items.map((x, j) => j === i ? { ...x, on: e.target.checked } : x))} data-testid={`a86-ord-on-${i}`} /><span className="l">{it.text}</span></label>
      {it.field && <div className="vals"><label><span className="sv-label">{it.field}</span><input className="sv-input" value={it.value || ''} readOnly={cur.status !== 'draft' && cur.status !== 'active'} onChange={e => upItems(cur.items.map((x, j) => j === i ? { ...x, value: e.target.value } : x))} data-testid={`a86-ord-val-${i}`} /></label></div>}</div>)}
    <textarea className="sv-input mt-1" rows={2} placeholder="Patient-specific note (optional)" value={cur.note || ''} readOnly={!editing && cur.status !== 'active'} onChange={e => upItems(cur.items, e.target.value)} data-testid="a86-ord-note" />
    <p className="sv-small sv-muted">Author: {cur.author.by}{cur.proposedBy === 'Nightingale' ? ' (Nightingale proposal: human review required)' : ''} · {tm(cur.author.at)}</p>
    {err && <p className="a81-err" data-testid="a86-ord-err">{err}</p>}
    <div className="a81-foot">{(cur.status === 'active' || cur.status === 'draft') && act && <><input className="sv-input" style={{ flex: 1 }} placeholder="Reason to discontinue" value={why} onChange={e => setWhy(e.target.value)} data-testid="a86-dc-why" /><button type="button" className="a8-btn red" onClick={() => { try { D.saveSet(P.discontinue(set, me, why), me, `discontinued: ${why}`); setWhy(''); } catch (e) { setErr((e as Error).message); } }} data-testid="a86-ord-dc">Discontinue</button></>}
      {editing && <SignBtn label={`Sign ${P.PHASE_LABEL[phase].toLowerCase()}`} roles={SIGN_ROLES(set.signer)} cid={c.id} what={`${P.PHASE_LABEL[phase]} v${cur.v}`} tid="a86-ord-sign" onSigned={sign} />}</div>
    <details className="a81-box mt-2" data-testid="a86-ord-history"><summary>Version history ({set.versions.length})</summary>{[...set.versions].reverse().map(v => <div key={v.v} className={`a86-ver ${v.status}`} data-testid="a86-ver"><b>v{v.v}</b> <StatusPill s={v.status} /> <span className="sv-small">by {v.author.by}{v.signed ? ` · signed ${v.signed.by} (${v.signed.role}) ${tm(v.signed.at)} · ${P.signatureValid(v) ? 'signature matches content' : 'CONTENT CHANGED AFTER SIGNING'}` : ''}{v.ended ? ` · ${v.status} ${tm(v.ended.at)}: ${v.ended.reason}` : ''}{v.acks.length ? ` · acknowledged by ${v.acks.map(a => a.by).join(', ')}` : ''}</span><pre className="a81-pre">{P.versionText(v)}</pre></div>)}</details>{Legacy}
  </Sec>;
};

/** Standalone card on Nursing and PACU: only signed/active orders, with acknowledgment + execution record. */
export const ActiveOrdersCard: React.FC<{ c: A.AscCase; phases: P.Phase[] }> = ({ c, phases }) => {
  useMedTick(); const [actor] = useActor(); const sets = phases.map(p => D.orderSet(c.id, p)).filter(Boolean) as P.OrderSet[]; const me = D.stamp(actor.name, actor.role);
  return <Sec title="Active doctor orders" tid="a86-active-orders" tone="a86-orders-card" right={<span className="sv-small sv-muted">Signed orders only · full record in Orders</span>}>
    {!sets.some(P.activeVersion) && <p className="a86-tint warn" data-testid="a86-no-active">No signed {phases.map(p => P.PHASE_LABEL[p].toLowerCase()).join(' / ')} yet. Drafts are not orders. Escalate if needed (not blocking).</p>}
    {sets.map(s => { const a = P.activeVersion(s); const cur = P.current(s); const st = P.nurseState(s);
      return <div key={s.id} className="a86-ocard" data-testid="a86-ocard" data-phase={s.phase}><div className="a82-row"><b>{P.PHASE_LABEL[s.phase]}</b>{a ? <StatusPill s="active" /> : <StatusPill s={cur.status} />}{a && <span className="sv-small sv-muted">v{a.v} · {a.signed!.by} · {tm(a.signed!.at)}</span>}</div>
        {cur.status === 'draft' && a && <p className="a86-tint warn sv-small">A changed draft (v{cur.v}) is waiting for signature; follow v{a.v} until it is signed.</p>}
        {a ? <>{a.items.filter(i => i.on).map(i => { const ex = a.exec.filter(e => e.itemId === i.id); return <div key={i.id} className="a81-line" data-testid="a86-order-line"><span style={{ flex: 1 }}>{i.text}{i.field ? <b>: {i.value || '—'}</b> : null}{ex.length > 0 && <span className="sv-small a81-ok"> · done {ex.map(e => `${e.by.split(' ')[0]} ${tm(e.at)}`).join(', ')}</span>}</span><button type="button" className="sv-link sv-small" onClick={() => D.saveSet(P.execute(s, i.id, me), me, `executed: ${i.text}`)} data-testid="a86-exec">Record done</button></div>; })}
          <div className="a81-foot">{st === 'needs-ack' ? <button type="button" className="a8-btn pri" onClick={() => D.saveSet(P.acknowledge(s, me), me, 'acknowledged by nursing')} data-testid="a86-ack">Acknowledge orders</button> : <span className="a81-ok" data-testid="a86-acked">✓ Acknowledged by {a.acks.map(x => x.by).join(', ')}</span>}
            <button type="button" className="a8-btn" onClick={() => S.raiseFlag({ from: actor.name, fromRole: actor.role, to: s.signer === 'anesthesia' ? 'anesthesia' : 'surgeon', pid: c.pid, caseId: c.id, text: `Order question (${P.PHASE_LABEL[s.phase]}) for ${pname(c)}: missing, conflicting or unclear order.` })} data-testid="a86-escalate">Escalate to {s.signer === 'anesthesia' ? 'anesthesia' : 'surgeon'}</button></div></> : null}
      </div>; })}
  </Sec>;
};

/* ======================= PACU vitals flowsheet ======================= */
const Spark: React.FC<{ xs: number[]; label: string }> = ({ xs, label }) => { if (xs.length < 2) return <span className="a86-spark sv-small sv-muted">{label} —</span>; const mn = Math.min(...xs), mx = Math.max(...xs), r = mx - mn || 1;
  return <span className="a86-spark" data-testid="a86-spark"><span className="sv-small">{label}</span><svg width="70" height="20"><polyline fill="none" stroke="#2f7d6d" strokeWidth="1.6" points={xs.map((v, i) => `${(i * 68) / (xs.length - 1) + 1},${19 - ((v - mn) / r) * 17}`).join(' ')} /></svg><span className="sv-small">{xs[xs.length - 1]}</span></span>; };
export const Flowsheet: React.FC<{ c: A.AscCase }> = ({ c }) => {
  useMedTick(); const [actor] = useActor(); const rows = D.vitals(c.id); const live = P.liveRows(rows); 
  const start = c.events.pacuIn ? P.minToHm(P.hmToMin(c.events.pacuIn)) : ''; const sl = start ? P.slots(start, nowMin(), rows) : []; const overdue = sl.filter(s => s.overdue);
  const [f, setF] = useState<Partial<P.VRow>>({ measured: '' }); const [fix, setFix] = useState<string>(''); const [why, setWhy] = useState(''); const [err, setErr] = useState('');
  const save = (kind: P.VRow['kind']) => { const m = f.measured || nowHm(); if (!P.VFIELDS.some(([k]) => String((f as any)[k] || '').trim())) return setErr('Enter at least one measured value. Nothing is copied from earlier rows.');
    if (fix && !why.trim()) return setErr('Give a reason for the correction.');
    const r: P.VRow = { ...P.blankRow(`v${Date.now()}`, m, new Date().toISOString(), actor.name, kind), ...f, measured: m, ...(fix ? { corrects: fix, correctReason: why } : {}) };
    const late = P.isLate(m, nowMin()); D.addVital(c.id, r, actor.role, `${fix ? 'Correction' : kind === 'adhoc' ? 'Ad-hoc' : 'Scheduled'} vitals measured ${m}, entered ${nowHm()}${late ? ' (LATE ENTRY)' : ''}${fix ? ` · reason: ${why}` : ''}`);
    setF({ measured: '' }); setFix(''); setWhy(''); setErr(''); };
  return <Sec title="PACU vitals flowsheet" tid="a86-flowsheet" right={<span className="sv-small sv-muted">15-min rows from PACU arrival {start || '(not recorded)'} · interval per approved policy/orders</span>}>
    {overdue.length > 0 && <div className="a86-tint warn" data-testid="a86-overdue" role="status">⏰ Overdue observations: {overdue.map(o => o.at).join(', ')}. Reminder only; never auto-completed.</div>}
    <div className="a86-trends" data-testid="a86-trends"><Spark xs={P.trend(rows, 'sys')} label="SBP" /><Spark xs={P.trend(rows, 'hr')} label="HR" /><Spark xs={P.trend(rows, 'spo2')} label="SpO₂" /><Spark xs={P.trend(rows, 'pain')} label="Pain" /></div>
    <div className="a83-scroll"><table className="sv-table a86-vt"><thead><tr><th>Measured</th><th>Entered</th>{P.VFIELDS.map(([, l]) => <th key={l}>{l}</th>)}<th>Notes</th><th>By</th><th /></tr></thead><tbody>
      {sl.filter(s => !s.filled).map(s => <tr key={'s' + s.at} className={s.overdue ? 'a86-row-over' : ''} data-testid="a86-slot-empty"><td>{s.at}</td><td colSpan={P.VFIELDS.length + 4} className="sv-small">{s.overdue ? 'Overdue · not documented' : 'Due'}</td></tr>)}
      {[...rows].sort((a, b) => P.hmToMin(a.measured) - P.hmToMin(b.measured)).map(r => { const corrected = rows.some(x => x.corrects === r.id); const ent = new Date(r.enteredAt); const late = P.isLate(r.measured, ent.getHours() * 60 + ent.getMinutes());
        return <tr key={r.id} className={corrected ? 'a86-struck' : ''} data-testid="a86-vrow" data-late={late ? '1' : '0'}><td>{r.measured}{r.kind === 'adhoc' && <span className="a86-tag">ad hoc</span>}</td><td className="sv-small">{tm(r.enteredAt)}{late && <span className="a86-tag late" data-testid="a86-late">late entry</span>}{r.corrects && <span className="a86-tag fix">correction: {r.correctReason}</span>}{corrected && <span className="a86-tag">corrected</span>}</td>
          {P.VFIELDS.map(([k]) => <td key={k}>{String((r as any)[k] || '')}</td>)}<td className="sv-small">{r.note}</td><td className="sv-small">{r.by.split(' ')[0]}</td><td>{!corrected && <button type="button" className="sv-link sv-small" onClick={() => { setFix(r.id); setF({ measured: r.measured }); }} data-testid="a86-fix">Correct</button>}</td></tr>; })}
    </tbody></table></div>
    <div className="a86-vin" data-testid="a86-vin">{fix && <p className="a86-tint warn sv-small">Correcting the {rows.find(r => r.id === fix)?.measured} row. The original stays visible (struck through).</p>}
      <label><span className="sv-label">Measured at</span><input className="sv-input" type="time" value={f.measured || ''} onChange={e => setF({ ...f, measured: e.target.value })} data-testid="a86-v-measured" /></label>
      {P.VFIELDS.map(([k, l]) => <label key={k}><span className="sv-label">{l}</span><input className="sv-input" value={String((f as any)[k] || '')} onChange={e => setF({ ...f, [k]: e.target.value })} data-testid={`a86-v-${k}`} /></label>)}
      <label style={{ gridColumn: 'span 2' }}><span className="sv-label">Notes · intervention / response / escalation</span><input className="sv-input" value={f.note || ''} onChange={e => setF({ ...f, note: e.target.value })} data-testid="a86-v-note" /></label>
      {fix && <label style={{ gridColumn: 'span 2' }}><span className="sv-label">Correction reason</span><input className="sv-input" value={why} onChange={e => setWhy(e.target.value)} data-testid="a86-v-why" /></label>}</div>
    {err && <p className="a81-err">{err}</p>}
    <div className="a81-foot"><span className="sv-small sv-muted" style={{ flex: 1 }}>Leave “Measured at” blank to use now. Values are never copied forward. Device feed: not connected (validation required).</span>{fix && <button type="button" className="a8-btn" onClick={() => setFix('')}>Cancel correction</button>}<button type="button" className="a8-btn" onClick={() => save('adhoc')} data-testid="a86-v-adhoc">Add ad-hoc row</button><button type="button" className="a8-btn pri" onClick={() => save('scheduled')} data-testid="a86-v-save">{fix ? 'Save correction' : 'Save 15-min row'}</button></div>
  </Sec>;
};

/* ======================= Discharge confirmations ======================= */
export const DischargeExtras: React.FC<{ c: A.AscCase }> = ({ c }) => {
  useMedTick(); const [actor] = useActor(); const x = D.dcx(c.id); const set = (k: string, v: any, what: string) => D.setDcx(c.id, { [k]: v }, actor.name, actor.role, what);
  const stamp = () => ({ by: actor.name, at: new Date().toISOString() });
  return <Sec title="Discharge confirmations" tid="a86-dc-extras" right={<span className="sv-small sv-muted">Criteria and readiness are decided by clinicians, not Nightingale</span>}>
    <label className={`a82-ck row ${x.criteria ? 'on' : ''}`}><input type="checkbox" checked={!!x.criteria} onChange={e => set('criteria', e.target.checked ? stamp() : null, e.target.checked ? 'Patient meets the center’s approved discharge criteria (nurse confirmed)' : 'Discharge criteria confirmation removed')} data-testid="a86-dc-criteria" /><span className="l">Patient meets the center’s approved discharge criteria (criteria set by center policy)</span>{x.criteria && <span className="a82-onfile">{x.criteria.by}</span>}</label>
    <div className="a82-row">{x.auth ? <span className="a81-ok" data-testid="a86-dc-auth-ok">✓ Discharge authorized by {x.auth.by} ({x.auth.role}) · {tm(x.auth.at)}</span> : <><span className="l">Discharge authorization (anesthesiologist or surgeon)</span><SignBtn label="Authorize discharge" roles={[...PROVIDER_ROLES, ...S.ANES_ROLES]} cid={c.id} what="Discharge authorization" tid="a86-dc-auth" onSigned={(by, role) => D.setDcx(c.id, { auth: { by, role, at: new Date().toISOString() } }, by, role, 'Discharge authorization signed (PIN)')} /></>}</div>
    <div className="a84-grid4"><label><span className="sv-label">Understanding confirmed by</span><select className="sv-input" value={x.understood?.who || ''} onChange={e => set('understood', e.target.value ? { who: e.target.value, method: x.understood?.method || 'Teach-back', ...stamp() } : null, `Instructions understood: ${e.target.value}`)} data-testid="a86-dc-und"><option value="">—</option><option>Patient</option><option>Caregiver</option><option>Patient and caregiver</option></select></label>
      <label><span className="sv-label">Method</span><select className="sv-input" value={x.understood?.method || 'Teach-back'} onChange={e => x.understood && set('understood', { ...x.understood, method: e.target.value }, `Understanding method: ${e.target.value}`)}><option>Teach-back</option><option>Verbal confirmation</option><option>Interpreter used</option></select></label>
      <label><span className="sv-label">Copy of instructions given</span><select className="sv-input" value={x.copy || ''} onChange={e => set('copy', e.target.value, `Instructions copy: ${e.target.value}`)} data-testid="a86-dc-copy"><option value="">—</option><option>Printed copy</option><option>Portal copy (simulated)</option><option>Large-print copy</option></select></label>
      <label><span className="sv-label">Transport</span><select className="sv-input" value={x.transport || ''} onChange={e => set('transport', e.target.value, `Transport: ${e.target.value}`)} data-testid="a86-dc-transport"><option value="">—</option><option>Private car with escort</option><option>Medical transport</option><option>Post-op recovery facility transport</option></select></label>
      <label style={{ gridColumn: 'span 2' }}><span className="sv-label">Escort name &amp; phone</span><input className="sv-input" value={x.escort ?? c.d.adult?.name ?? ''} onChange={e => D.setDcx(c.id, { escort: e.target.value }, actor.name, actor.role, 'Escort updated')} data-testid="a86-dc-escort" /></label>
      <label style={{ gridColumn: 'span 2' }}><span className="sv-label">Unresolved clinical concern routed to</span><input className="sv-input" placeholder="None, or who was contacted" value={x.concern || ''} onChange={e => D.setDcx(c.id, { concern: e.target.value }, actor.name, actor.role, `Concern routed: ${e.target.value}`)} /></label></div>
  </Sec>;
};

/* ======================= Op report receipt ======================= */
export const OpReceiptCard: React.FC<{ c: A.AscCase }> = ({ c }) => {
  useMedTick(); const [actor] = useActor(); const r = D.opReceipt(c.id); const op = c.d.opReport; const [note, setNote] = useState(''); const me = D.stamp(actor.name, actor.role);
  const signed = r.signed || (op?.signedAt ? { by: op.signedBy, role: 'Surgeon', at: op.signedAt } : undefined);
  return <Sec title="Formal operative report" tid="a86-opreceipt">
    <div className="a86-steps"><span className={r.received ? 'ok' : 'no'} data-testid="a86-op-received">{r.received ? `✓ Received ${tm(r.received.at)} via ${r.received.via}` : '○ Not received'}</span><span className={signed ? 'ok' : 'no'} data-testid="a86-op-signed">{signed ? `✓ Signed by ${signed.by}` : '○ Surgeon signature pending'}</span><span className={r.amendments.length ? 'warn' : ''} data-testid="a86-op-amended">{r.amendments.length ? `Amended ×${r.amendments.length}` : 'No amendments'}</span></div>
    <div className="a81-foot">{!r.received && <><button type="button" className="a8-btn" onClick={() => { D.saveOp(c.id, { ...r, received: { ...me, via: op?.text ? 'ASC dictation' : 'Surgeon office upload (simulated)' } }, me.by, me.role, 'Formal op report received'); S.setValue(S.caseById(c.id)!, 'formalOpReceived', { by: me.by, at: new Date().toISOString() }, me.by, me.role, 'Formal op report received from dictation'); }} data-testid="a86-op-receive">Mark received</button></>}
      <input className="sv-input" style={{ flex: 1 }} placeholder="Amendment / addendum (original signed version is kept)" value={note} onChange={e => setNote(e.target.value)} data-testid="a86-op-amend-text" />
      <SignBtn ghost label="Sign addendum" roles={PROVIDER_ROLES} cid={c.id} what="Operative report addendum" tid="a86-op-amend" allow={p => p.name === c.surgeon} onSigned={(by, role) => { if (!note.trim()) return; D.saveOp(c.id, { ...r, amendments: [...r.amendments, { by, role, at: new Date().toISOString(), note, hash: P.contentHash((op?.text || '') + note) }] }, by, role, `Op report addendum signed: ${note}`); setNote(''); }} /></div>
    {r.amendments.map((a, i) => <p key={i} className="a86-tint sv-small" data-testid="a86-op-amend-row">Addendum {i + 1} · {a.by} · {tm(a.at)} · #{a.hash}: {a.note}</p>)}
    <p className="sv-small sv-muted">Mobile dictation app: proposed (data contract only). Dictation must link to the patient and episode and be authenticated by the surgeon.</p></Sec>;
};

/* ======================= Follow-up call + survey ======================= */
export const FollowUpCard: React.FC<{ c: A.AscCase }> = ({ c }) => {
  useMedTick(); const [actor] = useActor(); const f0 = D.followUp(c.id); const [out, setOut] = useState<P.CallAttempt['outcome']>('reached'); const [note, setNote] = useState('');
  const f = f0 || { owner: 'Alex Rivera (PACU RN)', due: P.followDue(c.date), attempts: [] };
  const save = (x: any, what: string) => D.saveFollow(c.id, x, actor.name, actor.role, what);
  return <Sec title="Day-2 follow-up call (optional)" tid="a86-followup" right={<span className={`a83-pay ${f.done ? 'paid' : 'unpaid'}`}>{f.done ? 'Done' : `Due ${f.due}`}</span>}>
    <div className="a82-row"><span className="sv-small">Owner</span><input className="sv-input" style={{ width: 240 }} value={f.owner} onChange={e => save({ ...f, owner: e.target.value }, `Follow-up owner: ${e.target.value}`)} data-testid="a86-fu-owner" /><span className="sv-small sv-muted">Escalation path: concern → surgeon on call → anesthesia if anesthesia-related</span></div>
    {f.attempts.map((a, i) => <div key={i} className={`a81-line ${a.outcome === 'concern' ? 'a86-tint warn' : ''}`} data-testid="a86-fu-attempt">Attempt {i + 1} · {tm(a.at)} · {a.by} · <b>{a.outcome}</b> {a.note}</div>)}
    {P.followNeedsEscalation(f) && <p className="a86-tint warn" data-testid="a86-fu-esc-needed">Escalation suggested (concern reported or 3 unanswered attempts).</p>}
    {f.escalated && <p className="a81-ok" data-testid="a86-fu-escalated">Escalated to {f.escalated.to} by {f.escalated.by} · {tm(f.escalated.at)}</p>}
    {!f.done && <div className="a81-foot"><select className="sv-input" style={{ width: 'auto' }} value={out} onChange={e => setOut(e.target.value as any)} data-testid="a86-fu-outcome"><option>reached</option><option>no answer</option><option>left message</option><option>concern</option></select><input className="sv-input" style={{ flex: 1 }} placeholder="Response / note" value={note} onChange={e => setNote(e.target.value)} data-testid="a86-fu-note" />
      <button type="button" className="a8-btn" onClick={() => { save({ ...f, attempts: [...f.attempts, { at: new Date().toISOString(), by: actor.name, outcome: out, note }] }, `Follow-up call attempt: ${out}${note ? ` · ${note}` : ''}`); setNote(''); }} data-testid="a86-fu-log">Log attempt</button>
      <button type="button" className="a8-btn" onClick={() => { save({ ...f, escalated: { ...D.stamp(actor.name, actor.role), to: c.surgeon, note } }, `Follow-up escalated to ${c.surgeon}`); S.raiseFlag({ from: actor.name, fromRole: actor.role, to: 'surgeon', pid: c.pid, caseId: c.id, text: `Day-2 call concern for ${pname(c)}: please call the patient.` }); }} data-testid="a86-fu-escalate">Escalate</button>
      <button type="button" className="a8-btn pri" onClick={() => save({ ...f, done: D.stamp(actor.name, actor.role) }, 'Follow-up call completed')} data-testid="a86-fu-done">Mark complete</button></div>}
    <div className="a81-box mt-2 sv-small" data-testid="a86-survey">Satisfaction survey (separate from clinical follow-up): {(f as any).survey ? `${(f as any).survey.status} ${tm((f as any).survey.at)}` : <button type="button" className="sv-link sv-small" onClick={() => save({ ...f, survey: { status: 'queued (simulated)', at: new Date().toISOString() } }, 'Satisfaction survey queued (simulated)')} data-testid="a86-survey-send">Queue survey (simulated)</button>}</div></Sec>;
};

/* ======================= Closure checklist ======================= */
export function closureItems(c: A.AscCase): P.CloseItem[] {
  const ai = s81.ai(c.id); const v = ai.v82 || {}; const op = D.opReceipt(c.id); const fu = D.followUp(c.id); const x = D.dcx(c.id); const m = caseMoney(c);
  const ord = (p: P.Phase) => { const s = D.orderSet(c.id, p); return !!s && !!P.activeVersion(s) && P.current(s).status !== 'draft'; };
  const I = (id: string, label: string, owner: P.Owner, done: boolean, source: string, financial = false): P.CloseItem => ({ id, label, owner, done, source, financial });
  return [I('reg', 'Registration forms complete', 'Front desk', A.isDone(c, 'forms'), 'case.d.forms'), I('clear', 'Pre-op H&P / clearance received', 'Pre-op nursing', A.isDone(c, 'clearance'), 'case.d.clearance'),
    I('consent', 'Surgical consent signed', 'Surgeon', !!c.d.consentConfirm, 'case.d.consentConfirm'), I('anescon', 'Anesthesia consent signed', 'Anesthesia', !!c.d.anesConsent, 'case.d.anesConsent'), I('hp', 'Interval H&P signed', 'Surgeon', !!c.d.hpUpdate, 'case.d.hpUpdate'),
    I('nurse', 'Nursing admission signed', 'Pre-op nursing', !!v.nursing?.signed || A.isDone(c, 'nursingForm'), 'nursing checklist'), I('anesEval', 'Pre-anesthesia evaluation signed', 'Anesthesia', !!v.anes?.evalSigned || !!c.d.asa, 'anesthesia bench'),
    I('oPre', 'Pre-op orders signed', 'Surgeon', ord('preop'), 'Orders'), I('oPost', 'Post-op orders signed', 'Surgeon', ord('postop'), 'Orders'), I('oPacu', 'PACU orders signed', 'Anesthesia', ord('pacu'), 'Orders'),
    I('timeout', 'Time-out documented', 'Surgeon', A.isDone(c, 'timeout'), 'case.d.timeout'), I('vitals', 'PACU flowsheet documented', 'PACU nursing', D.vitals(c.id).length > 0, 'flowsheet'),
    I('dcCrit', 'Discharge criteria + authorization', 'PACU nursing', !!x.criteria && !!x.auth, 'discharge'), I('dcUnd', 'Patient/caregiver understanding recorded', 'PACU nursing', !!x.understood, 'discharge'),
    I('brief', 'Brief OP report signed by surgeon', 'Surgeon', !!c.d.opReport?.signedAt, 'brief op report'), I('opRec', 'Formal op report received', 'Medical records', !!op.received, 'op receipt'), I('opSig', 'Formal op report signed by surgeon', 'Surgeon', !!op.signed, 'formal op report'),
    I('charges', 'Charges posted (procedure + OR time)', 'Billing', A.isDone(c, 'charges'), 'billing', true), I('bal', 'Balance reconciled', 'Billing', m.balance <= 0, 'payments', true)];
}
export const ClosurePanel: React.FC<{ c: A.AscCase }> = ({ c }) => {
  useMedTick(); use81(); const [actor] = useActor(); const st = D.closeState(c.id); const items = closureItems(c); const g = P.closureGaps(items, st); const own = P.byOwner(items, st);
  const [aiDown, setAiDown] = useState(false); const [exc, setExc] = useState<Record<string, string>>({}); const [why, setWhy] = useState(''); const me = D.stamp(actor.name, actor.role);
  const save = (n: P.CloseState, what: string) => D.saveClose(c.id, n, actor.name, actor.role, what);
  return <div data-testid="a86-closure">
    <div className="a86-steps"><span className={g.openDoc.length ? 'warn' : 'ok'} data-testid="a86-doc-status">Documentation: {P.docStatus(items, st)} ({g.docDone}/{g.docTotal})</span><span className={g.finOpen.length ? 'warn' : 'ok'} data-testid="a86-fin-status">Financial: {P.finStatus(items)}</span><span className={st.closed ? 'ok' : ''} data-testid="a86-episode-status">Episode: {st.closed ? `Closed by ${st.closed.by}` : st.reopened.length ? 'Reopened' : 'Open'}</span></div>
    <Sec title={<>✦ Nightingale completeness check {aiDown && <span className="a86-tag late">AI unavailable · manual reconciliation</span>}</>} tid="a86-ai-check" right={<label className="sv-small"><input type="checkbox" checked={aiDown} onChange={e => setAiDown(e.target.checked)} data-testid="a86-ai-down" /> Simulate AI unavailable</label>}>
      <p className="sv-small sv-muted">{aiDown ? 'Manual path: review each line against the record yourself.' : 'Nightingale checked every step against the example completeness checklist (awaiting approval). It flags, it does not fabricate, sign or certify.'} Findings need human review.</p>
      {Object.entries(own).map(([o, l]) => <div key={o} className="a86-owner" data-testid="a86-owner-todo"><b>{o}</b> · {l.length}<ul>{l.map(i => <li key={i.id}>{i.label}{i.financial ? ' (financial)' : ''}</li>)}</ul></div>)}
      {!Object.keys(own).length && <p className="a81-ok">No open items.</p>}
      <div className="a81-foot">{st.reviewed ? <span className="a81-ok" data-testid="a86-reviewed">✓ Findings reviewed by {st.reviewed.by} ({st.reviewed.mode === 'manual' ? 'manual' : 'AI-assisted'}) · {tm(st.reviewed.at)}</span> : <button type="button" className="a8-btn pri" onClick={() => save({ ...st, reviewed: { ...me, mode: aiDown ? 'manual' : 'ai' } }, `Closure findings reviewed (${aiDown ? 'manual path' : 'AI-assisted'})`)} data-testid="a86-review">I reviewed these findings</button>}</div></Sec>
    <Sec title="Checklist" tid="a86-checklist">{items.map(i => <div key={i.id} className={`a81-line ${i.done ? '' : st.exceptions[i.id] ? 'a86-tint' : 'a86-tint warn'}`} data-testid="a86-close-item" data-done={i.done ? '1' : '0'}><span style={{ flex: 1 }}>{i.done ? '✓' : '○'} {i.label} <span className="sv-small sv-muted">· {i.owner}{i.financial ? ' · financial' : ''}</span>{st.exceptions[i.id] && <span className="sv-small"> · exception: {st.exceptions[i.id].reason} ({st.exceptions[i.id].by})</span>}</span>
      {!i.done && !st.exceptions[i.id] && <><input className="sv-input" style={{ width: 200 }} placeholder="Exception reason" value={exc[i.id] || ''} onChange={e => setExc({ ...exc, [i.id]: e.target.value })} data-testid={`a86-exc-${i.id}`} /><button type="button" className="sv-link sv-small" onClick={() => exc[i.id] && save({ ...st, exceptions: { ...st.exceptions, [i.id]: { ...me, reason: exc[i.id] } } }, `Exception documented: ${i.label} · ${exc[i.id]}`)} data-testid={`a86-exc-save-${i.id}`}>Document exception</button></>}</div>)}</Sec>
    {g.openDoc.length > 0 && !st.closed && <ExcBox items={g.openDoc.map(i => `${i.label} (${i.owner})`)} tid="a86-close-open" title="Still open (not blocking)" note="You can close the episode now. Open items are logged with the closure and stay on the owners’ to-do lists." />}
    <div className="a81-foot">{st.closed ? <><input className="sv-input" style={{ flex: 1 }} placeholder="Reason to reopen / amend" value={why} onChange={e => setWhy(e.target.value)} data-testid="a86-reopen-why" /><button type="button" className="a8-btn" onClick={() => { if (!why.trim()) return; save({ ...st, closed: undefined, reopened: [...st.reopened, { ...me, reason: why }] }, `Episode reopened for amendment: ${why} (signed versions preserved)`); setWhy(''); }} data-testid="a86-reopen">Reopen for amendment</button></>
      : <button type="button" className="a8-btn pri" onClick={() => { save({ ...st, closed: me }, `Episode closed${g.openDoc.length ? ` with ${g.openDoc.length} open item(s): ${g.openDoc.map(i => i.label).join('; ')}` : ''}${st.reviewed ? '' : ' · findings not reviewed'} · financial: ${P.finStatus(items)}`); const x = S.caseById(c.id); if (x && x.loc !== 'closed') S.saveCase({ ...x, loc: 'closed' }, actor.name, actor.role, 'Episode closed'); }} data-testid="a86-close">{g.openDoc.length ? `Close episode (${g.openDoc.length} open, logged)` : 'Close episode'}</button>}</div>
    {st.reopened.length > 0 && <p className="sv-small sv-muted" data-testid="a86-reopen-log">Reopened: {st.reopened.map(r => `${tm(r.at)} ${r.by}: ${r.reason}`).join(' · ')}</p>}
  </div>;
};

/* ======================= Episode worklist (every station) ======================= */
export function episodeOf(c: A.AscCase) {
  const items = closureItems(c); const st = D.closeState(c.id); const exc = S.exceptionsOf(c).flatMap(e => e.items);
  const stage = st.closed ? 'Closed' : A.LOC_LABEL[c.loc]; const open = items.filter(i => !i.done && !st.exceptions[i.id]);
  const due = (ids: string[]) => open.filter(i => ids.includes(i.id));
  const nextIds: Record<A.Loc, string[]> = { scheduled: ['reg', 'clear'], arrived: ['nurse', 'oPre', 'anescon', 'consent'], preop: ['anesEval', 'hp', 'oPre', 'oPacu', 'consent'], or: ['timeout', 'oPost', 'oPacu'], pacu: ['vitals', 'oPacu', 'dcCrit', 'dcUnd'], discharged: ['opRec', 'opSig', 'fu', 'charges'], closed: [] };
  const next = st.closed ? [] : due(nextIds[c.loc]); const blockers = [...exc, ...(!A.isDone(c, 'clearance') && (c.loc !== 'scheduled' || c.date <= isoDay()) ? ['Clearance missing (warning, not a hold)'] : [])];
  return { stage, next, blockers: Array.from(new Set(blockers)), open };
}
export const EpisodeWorklist: React.FC<{ day: string }> = ({ day }) => {
  useMedTick(); use81(); const cs = S.cases().filter(c => c.date === day).sort((a, b) => A.toMin(a.time) - A.toMin(b.time)); const [open, setOpen] = useState(false);
  if (!cs.length) return null;
  return <section className="v7-card a86-wl" data-testid="a86-worklist"><h2 className="a8-h2" onClick={() => setOpen(o => !o)} style={{ cursor: 'pointer' }}>✦ Episode worklist <span className="sv-small sv-muted">stage · next steps · owners · warnings (never holds)</span><span style={{ marginLeft: 'auto' }}>{open ? '▾' : '▸'}</span></h2>
    {(open ? cs : cs.slice(0, 4)).map(c => { const e = episodeOf(c); return <div key={c.id} className={`a86-wlrow ${e.blockers.length ? 'warn' : ''}`} data-testid="a86-wl-row"><span className="nm"><b>{pname(c)}</b><span className="sv-small sv-muted"> · {c.time.replace(/^0/, '')} · {c.procedure}</span></span><span className="a86-tag">{e.stage}</span>
      <span className="sv-small" style={{ flex: 1 }}>{e.next.length ? e.next.map(i => `${i.label} → ${i.owner}`).join(' · ') : 'No next steps'}</span>{e.blockers.length > 0 && <span className="a86-tag late" data-testid="a86-wl-warn">⚠ {e.blockers.slice(0, 2).join('; ')}{e.blockers.length > 2 ? ` +${e.blockers.length - 2}` : ''}</span>}</div>; })}
    {!open && cs.length > 4 && <button type="button" className="a8-link" onClick={() => setOpen(true)}>Show all {cs.length}</button>}</section>;
};

/* ======================= Episode search (name / MRN + DOS) ======================= */
export const EpisodeSearch: React.FC<{ onOpen: (cid: string) => void }> = ({ onOpen }) => {
  useMedTick(); const [q, setQ] = useState(''); const [dos, setDos] = useState('');
  const list: P.SearchCase[] = [...S.cases().map(c => ({ id: c.id, pid: c.pid, date: c.date, name: pname(c), procedure: c.procedure })), ...cancelledCases().map((c: any) => ({ id: c.id, pid: c.pid, date: c.date, name: medRepo.patient(c.pid)?.name || c.pid, procedure: c.procedure, cancelled: true }))];
  const hits = P.searchEpisodes(q, dos, list).slice(0, 8);
  return <div className="a86-search" data-testid="a86-search"><input className="sv-input" placeholder="Find episode: name or MRN" value={q} onChange={e => setQ(e.target.value)} data-testid="a86-search-q" /><input type="date" className="sv-input" value={dos} onChange={e => setDos(e.target.value)} data-testid="a86-search-dos" aria-label="Date of service" />
    {hits.length > 0 && <div className="a86-hits">{hits.map(h => <button key={h.id + h.date} type="button" disabled={h.cancelled} onClick={() => onOpen(h.id)} data-testid="a86-search-hit"><b>{h.name}</b> · MRN {h.pid} · DOS {h.date} · {h.procedure}{h.cancelled ? ' · cancelled' : ''}</button>)}</div>}</div>;
};

/* ======================= Print packet (manual only; header on every page) ======================= */
export function supplementalSections(c: A.AscCase): { title: string; status: string; lines: string[] }[] {
  const out: { title: string; status: string; lines: string[] }[] = [];
  D.orderSets(c.id).forEach(s => s.versions.forEach(v => out.push({ title: `${P.PHASE_LABEL[s.phase]} · version ${v.v}`, status: `${P.STATUS_LABEL[v.status]}${v.signed ? ` · signed ${v.signed.by} (${v.signed.role}) ${tm(v.signed.at)} · #${v.signed.hash}` : ' · NOT SIGNED'}`, lines: P.versionText(v).split('\n') })));
  const vr = D.vitals(c.id); if (vr.length) out.push({ title: 'PACU vitals flowsheet', status: `${vr.length} rows`, lines: vr.map(r => `${r.measured} (entered ${tm(r.enteredAt)}${r.corrects ? `, correction: ${r.correctReason}` : ''}) BP ${r.bp || '—'} HR ${r.hr || '—'} RR ${r.rr || '—'} SpO2 ${r.spo2 || '—'} T ${r.temp || '—'} Pain ${r.pain || '—'} ${r.note || ''} · ${r.by}`) });
  const x = D.dcx(c.id); out.push({ title: 'Discharge confirmations', status: x.auth ? 'Authorized' : 'PENDING', lines: [`Criteria met: ${x.criteria ? `yes (${x.criteria.by})` : 'pending'}`, `Authorization: ${x.auth ? `${x.auth.by} ${tm(x.auth.at)}` : 'pending'}`, `Understanding: ${x.understood ? `${x.understood.who} · ${x.understood.method}` : 'pending'}`, `Transport: ${x.transport || 'pending'} · Escort: ${x.escort || c.d.adult?.name || 'pending'}`] });
  const f = D.followUp(c.id); out.push({ title: 'Day-2 follow-up call', status: f?.done ? 'Complete' : 'PENDING', lines: (f?.attempts || []).map(a => `${tm(a.at)} ${a.by}: ${a.outcome} ${a.note}`) });
  const o = D.opReceipt(c.id); out.push({ title: 'Operative report receipt', status: o.received ? 'Received' : 'PENDING', lines: [`Received: ${o.received ? tm(o.received.at) : 'pending'}`, ...o.amendments.map((a, i) => `Addendum ${i + 1} ${a.by} ${tm(a.at)}: ${a.note}`)] });
  const st = D.closeState(c.id); out.push({ title: 'Episode closure', status: st.closed ? `Closed by ${st.closed.by}` : 'OPEN', lines: [...Object.entries(st.exceptions).map(([k, e]) => `Exception ${k}: ${e.reason} (${e.by})`), ...st.reopened.map(r => `Reopened ${tm(r.at)} ${r.by}: ${r.reason}`)] });
  return out;
}
export const PrintPacket: React.FC<{ c: A.AscCase; onClose: () => void }> = ({ c, onClose }) => {
  const [actor] = useActor(); const p = medRepo.patient(c.pid)!; const docs = docsForCase(c); const sup = supplementalSections(c);
  const pages: { title: string; body: React.ReactNode }[] = [{ title: 'Episode documents index', body: <pre className="a81-pre">{exportText(c, docs)}</pre> }, ...sup.map(s => ({ title: `Supplemental · ${s.title}`, body: <><p><b>Status:</b> {s.status}</p><p className="sv-small">Recorded outside the form templates as a structured episode record.</p><ul>{s.lines.map((l, i) => <li key={i}>{l}</li>)}</ul></> }))];
  const go = () => { D.logPrint(c.id, actor.name, actor.role, `Episode packet (${pages.length} pages) for DOS ${c.date}`); window.print(); };
  return <div className="a81-modal a86-printwrap" data-testid="a86-print"><div className="a81-dialog a83-dlg" role="dialog" aria-label="Print packet"><div className="a81-dhead no-print"><b>Print episode packet · preview</b><span style={{ marginLeft: 'auto' }} /><button type="button" className="a8-btn pri" onClick={go} data-testid="a86-print-go">Print</button><XClose onClick={onClose} testId="a86-print-close" /></div>
    <div className="a81-dbody"><p className="sv-small sv-muted no-print">Manual print only. No PDF is generated or saved. Pending steps print as PENDING.</p>{pages.map((pg, i) => <div key={i} className="a86-page" data-testid="a86-page"><div className="a86-phead" data-testid="a86-phead"><b>{p.name}</b> · MRN {p.id} · DOB {p.dob} · DOS {c.date} · <i>{pg.title}</i><span>Page {i + 1} of {pages.length}</span></div>{pg.body}<div className="a86-pfoot">ASC.Vityls · fictional test data · printed by {actor.name}</div></div>)}</div></div></div>;
};

/* ======================= Consent witness / representative ======================= */
export const WitnessCapture: React.FC<{ c: A.AscCase; doc: string }> = ({ c, doc }) => {
  useMedTick(); const [actor] = useActor(); const w = D.witness(c.id)[doc]; const [f, setF] = useState({ kind: 'witness', name: '', relation: '' });
  if (w) return <p className="a81-ok sv-small" data-testid="a86-witness-ok">✓ {w.kind === 'representative' ? `Signed by representative ${w.name} (${w.relation})` : `Witness: ${w.name}`} · {tm(w.at)}</p>;
  return <div className="a82-row sv-small" data-testid="a86-witness"><select className="sv-input" style={{ width: 'auto' }} value={f.kind} onChange={e => setF({ ...f, kind: e.target.value })}><option value="witness">Witness</option><option value="representative">Patient representative</option></select><input className="sv-input" style={{ width: 160 }} placeholder="Name" value={f.name} onChange={e => setF({ ...f, name: e.target.value })} data-testid="a86-witness-name" />{f.kind === 'representative' && <input className="sv-input" style={{ width: 140 }} placeholder="Relationship / authority" value={f.relation} onChange={e => setF({ ...f, relation: e.target.value })} />}<button type="button" className="sv-link sv-small" onClick={() => f.name.trim() && D.saveWitness(c.id, doc, { ...f, at: new Date().toISOString(), recordedBy: actor.name }, actor.name, actor.role)} data-testid="a86-witness-save">Record</button></div>;
};

/* ======================= Efficiency metrics (admin) ======================= */
export const MetricsCard: React.FC = () => {
  useMedTick(); const cs = S.cases(); const T = isoDay(); const up = cs.filter(c => c.date >= T && c.loc === 'scheduled');
  const reg = P.pct(up.filter(c => A.isDone(c, 'forms')).length, up.length); const unresolved = up.reduce((n, c) => n + ['forms', 'financial', 'insurance', 'clearance', 'labs'].filter(k => !A.isDone(c, k)).length, 0);
  const done = cs.filter(c => c.loc === 'discharged' || c.loc === 'closed'); const overdueDocs = done.reduce((n, c) => n + closureItems(c).filter(i => !i.done && !i.financial).length, 0);
  const closed = cs.map(c => D.closeState(c.id)).filter(s => s.closed); const flags = S.flagsAll(); const ans = flags.filter(f => f.repliedAt && f.at).map(f => (Date.parse(f.repliedAt!) - Date.parse(f.at)) / 60000);
  const tiles: [string, string][] = [['Registration complete (upcoming)', `${reg}%`], ['Unresolved pre-op items', String(unresolved)], ['Median task turnaround', ans.length ? `${Math.round(P.median(ans))} min` : '—'], ['Overdue documentation items', String(overdueDocs)], ['Episodes closed', `${closed.length} of ${done.length}`], ['Duplicate patients prevented', String(D.dupCount())]];
  return <section className="v7-card a86-metrics" data-testid="a86-metrics"><h2 className="a8-h2">Efficiency metrics <span className="sv-small sv-muted">admin · from recorded events · rule changes need approval</span></h2><div className="a86-tiles">{tiles.map(([l, v]) => <div key={l} className="a86-tile" data-testid="a86-metric"><b>{v}</b><span>{l}</span></div>)}</div></section>;
};
