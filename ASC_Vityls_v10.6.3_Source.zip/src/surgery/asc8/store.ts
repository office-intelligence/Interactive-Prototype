/* ASC.Vityls v8.0 · storage for ASC cases, steps, OR times, flags and op reports (browser storage, ASC2 namespace; nothing external).
 * One ASC case per surgery: patient + visit live in the shared patient record (medRepo) so the chart, search and scheduler see them.
 * Henry's mapping: case → `case` (edition ASC), case.d → `case_step`/`case_fact`, events → `case_event`, flags → `flag`, op report → `note`. */
import { repo } from '../../v6/dataLayer';
import { medRepo, MedPatient, isoDay, addDays, uid, ageFrom } from '../../med/record';
import { svRead, svWrite } from '../store';
import * as L from './logic';
import { DEMO, NAMES } from '../asc10/demo';
const bump = () => window.dispatchEvent(new Event('vityls-med-updated'));
export const ROOMS = ['OR 1', 'OR 2', 'OR 3', 'Procedure room'];
export const PATEL = NAMES.surgeon1, WHITFIELD = NAMES.surgeon2;
export const ANES = [NAMES.anes1, NAMES.anes2];
export const ANES_ROLES = ['Anesthesiologist', 'CRNA'];
export const NURSE_ROLES = ['Pre-op RN', 'PACU RN', 'Circulating RN', 'RN'];

export const cases = () => svRead<L.AscCase[]>('asc8-cases', []);
export const caseById = (id?: string) => cases().find(c => c.id === id);
export const caseOfPatient = (pid: string) => cases().filter(c => c.pid === pid).sort((a, b) => b.date.localeCompare(a.date))[0];
export function saveCase(c: L.AscCase, by: string, role: string, what: string) {
  const at = new Date().toISOString(); const x0 = { ...c, audit: what ? [...c.audit, { at, by, role, what }] :  c.audit }; const nl = L.autoLoc(x0); const x = nl !== x0.loc ? { ...x0, loc: nl, audit: [...x0.audit, { at, by, role, what: `Patient ${L.LOC_LABEL[nl].toLowerCase()}` }] } : x0;
  svWrite('asc8-cases', cases().map(o => o.id === c.id ? x : o)); if (what) repo.audit({ caseId: `asc8:${c.id}`, user: by, role, action: 'asc8.case' as any, detail: `${medRepo.patient(c.pid)?.name || c.pid} · ${what}` });
  // keep the scheduler block status in step with the case (same color coding)
  const v = medRepo.visit(c.visitId); if (v) { const step = x.loc === 'scheduled' ? 'scheduled' : x.loc === 'closed' || x.loc === 'discharged' ? 'complete' : x.loc === 'arrived' ? 'check-in' : 'provider'; if (v.step !== step) medRepo.saveVisit({ ...v, step: step as any }); }
  bump(); return x;
}
export function setValue(c: L.AscCase, key: string, value: any, by: string, role: string, what?: string) { return saveCase({ ...c, d: { ...c.d, [key]: value } }, by, role, what ?? `${L.item(key)?.label || key} recorded`); }
export function move(c: L.AscCase, to: L.Loc, by: string, role: string) { const w = L.moveWarnings(c, to); const at = new Date().toISOString();
  const d = w.length ? { ...c.d, exceptions: { ...(c.d.exceptions || {}), [to]: { items: w, by, at } } } : c.d;
  return saveCase({ ...c, d, loc: to }, by, role, `Patient ${L.LOC_LABEL[to].toLowerCase()}${w.length ? ` · proceeded with exceptions: ${w.join('; ')}` : ''}`); }
export const exceptionsOf = (c: L.AscCase): { at: L.Loc; items: string[]; by: string }[] => Object.entries(c.d.exceptions || {}).map(([k, v]: [string, any]) => ({ at: k as L.Loc, items: v.items, by: v.by }));
export function recordEvent(c: L.AscCase, k: L.EventKey, time: string, by: string, role: string, reason = '') { const x = L.setEvent(c, k, time, by, role, new Date().toISOString(), reason); svWrite('asc8-cases', cases().map(o => o.id === c.id ? x : o)); repo.audit({ caseId: `asc8:${c.id}`, user: by, role, action: 'asc8.or-time' as any, detail: x.audit[x.audit.length - 1].what }); bump(); return x; }
export const nowTime = () => new Date().toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' }).replace(/^(\d):/, '0$1:');
/** Patient to PACU: needs Out-of-room; records PACU arrival and sends the case surgeon (only) the "Dictate op report" flag. */
export function toPacu(c: L.AscCase, by: string, role: string) {
  const w = L.moveWarnings(c, 'pacu'); let x0 = c; if (w.length) x0 = saveCase({ ...c, d: { ...c.d, exceptions: { ...(c.d.exceptions || {}), pacu: { items: w, by, at: new Date().toISOString() } } } }, by, role, `To PACU with exceptions: ${w.join('; ')}`);
  let x = recordEvent(x0, 'pacuIn', x0.events.pacuIn || nowTime(), by, role); x = saveCase({ ...x, loc: 'pacu' }, by, role, 'Patient to PACU');
  raiseFlag({ from: 'Nightingale (automatic)', fromRole: 'System', to: 'surgeon', toPerson: c.surgeon, pid: c.pid, caseId: c.id, kind: 'op-report', text: `Dictate op report: ${c.procedure}` }); return x;
}
/* ---------------- allergies ---------------- */
export function confirmAllergies(c: L.AscCase, by: string, role: string) { const p = medRepo.patient(c.pid)!; medRepo.savePatient({ ...p, allergiesConfirmedAt: new Date().toISOString(), allergiesConfirmedBy: by }); return setValue(c, 'allergy', { by, at: new Date().toISOString(), list: p.allergies }, by, role, `Allergies confirmed: ${p.allergies.join('; ') || 'NKDA'}`); }
export function editAllergies(c: L.AscCase, list: string[], by: string, role: string) { const p = medRepo.patient(c.pid)!; const prev = p.allergies.join('; ') || 'NKDA'; medRepo.savePatient({ ...p, allergies: list, allergiesConfirmedAt: undefined, allergiesConfirmedBy: undefined }); return saveCase({ ...c, d: { ...c.d, allergy: undefined } }, by, role, `Allergies edited: ${prev} → ${list.join('; ') || 'NKDA'} (needs confirming)`); }
/* ---------------- fees + billing ---------------- */
export const fees = () => svRead<L.Fee[]>('asc8-fees', L.DEFAULT_FEES);
export function saveFees(l: L.Fee[], by: string, role: string) { svWrite('asc8-fees', l); repo.audit({ caseId: 'practice', user: by, role, action: 'asc8.fees' as any, detail: `Fee schedule saved (${l.length} rows)` }); bump(); }
/* ---------------- flags ---------------- */
export const flagsAll = () => svRead<L.AscFlag[]>('asc8-flags', []);
const saveFlags = (l: L.AscFlag[]) => { svWrite('asc8-flags', l); bump(); };
export function raiseFlag(f: Omit<L.AscFlag, 'id' | 'at' | 'status'>) { const x: L.AscFlag = { ...f, id: uid('aflag'), at: new Date().toISOString(), status: 'open' }; saveFlags([...flagsAll(), x]); if (f.pid) repo.audit({ caseId: `asc8:${f.caseId || ''}`, user: f.from, role: f.fromRole, action: 'asc8.flag' as any, detail: `Flag to ${f.toPerson || L.TEAM_LABEL[f.to]}: ${f.text}` }); return x; }
export function replyFlag(id: string, reply: string, by: string) { saveFlags(flagsAll().map(f => f.id === id ? { ...f, status: f.kind === 'op-report' ? 'closed' : 'answered', reply: reply.trim() || 'Done', repliedBy: by, repliedAt: new Date().toISOString() } : f)); }
export const ackFlag = (id: string) => saveFlags(flagsAll().map(f => f.id === id ? { ...f, status: 'closed' } : f));
/* ---------------- op report (note page, type "Op report") ---------------- */
export function opCtx(c: L.AscCase): L.OpCtx { const p = medRepo.patient(c.pid)!; return { name: p.name, age: ageFrom(p.dob), sex: p.sex, date: c.date, procedure: c.procedure, side: c.side, surgeon: c.surgeon, anesthesia: c.anesthesia, technique: c.d.plan?.technique, asa: c.d.asa, ebl: c.d.ebl !== undefined ? String(c.d.ebl) : undefined, wound: c.d.wound, implants: c.d.implants?.none ? 'None' : c.d.implants?.list, specimens: c.d.specimens?.none ? 'None' : c.d.specimens?.list, times: c.events, allergies: p.allergies, jots: c.d.jots || [] }; }
export const outbox = () => svRead<{ id: string; at: string; to: string; subject: string; body: string; link?: string; via: string; caseId: string }[]>('asc8-outbox', []);
export function saveOpReport(c: L.AscCase, text: string, by: string, role: string, sign?: { name: string; at: string; email?: string }) {
  const prev = c.d.opReport || {}; let x = setValue(c, 'opReport', { ...prev, text, draftedBy: prev.draftedBy || 'Nightingale', updatedAt: new Date().toISOString(), updatedBy: by, ...(sign ? { signedBy: sign.name, signedAt: sign.at } : {}) }, by, role, sign ? `Op report signed with PIN by ${sign.name}; filed to the ASC chart` : 'Op report draft saved');
  if (sign) { const cp = L.copyPlan(!!c.surgeonOnSurgeryVityls, sign.email || 'surgeon@example.test'); const link = cp.via === 'secure-link' ? `https://vityls.example.test/s/${uid('lnk').slice(-12)}` : undefined;
    svWrite('asc8-outbox', [...outbox(), { id: uid('ob'), at: new Date().toISOString(), to: cp.to, subject: cp.subject, body: cp.body, link, via: cp.via, caseId: c.id }]);
    x = saveCase({ ...x, d: { ...x.d, opReport: { ...x.d.opReport, copy: cp.via, copyTo: cp.to } } }, by, role, cp.via === 'surgery-vityls' ? 'Op report copy filed to Surgery.Vityls (simulated network)' : `Op report copy: secure link emailed to ${cp.to} (simulated; no patient details)`);
    flagsAll().filter(f => f.kind === 'op-report' && f.caseId === c.id && f.status === 'open').forEach(f => replyFlag(f.id, 'Op report signed', sign.name)); }
  return x;
}
/* ---------------- to-do (one list, by station) ---------------- */
export interface ATodo { id: string; kind: 'item' | 'flag' | 'answer'; station: L.Station; c?: L.AscCase; pid?: string; name: string; label: string; why: string; keys?: string[]; flag?: L.AscFlag }
export const allRolesOn = () => sessionStorage.getItem('asc8-all') === '1';
export const setAllRoles = (on: boolean) => { sessionStorage.setItem('asc8-all', on ? '1' : '0'); bump(); };
const pn = (pid?: string) => (pid && medRepo.patient(pid)?.name) || 'Practice';
export function ascTodos(me: string, role: string, all = false, today = isoDay()): ATodo[] {
  const st = L.stationOf(role); const out: ATodo[] = [];
  L.flagsFor(flagsAll(), me, role, all).forEach(({ f, kind }) => out.push(kind === 'incoming'
    ? { id: `flag:${f.id}`, kind: 'flag', station: (f.to === 'ma' || f.to === 'coord' ? 'preop' : f.to === 'pm' ? 'billing' : f.to) as L.Station, pid: f.pid, c: caseById(f.caseId), name: pn(f.pid), label: f.text, why: f.kind === 'op-report' ? 'Patient in PACU · flag to you' : `Flag from ${f.from.replace(/,.*$/, '')} to ${L.TEAM_LABEL[f.to]}`, flag: f }
    : { id: `ans:${f.id}`, kind: 'answer', station: st, pid: f.pid, name: pn(f.pid), label: `Answered: ${f.reply}`, why: `Your flag to ${L.TEAM_LABEL[f.to]}: “${f.text}” · ${f.repliedBy?.replace(/,.*$/, '')}`, flag: f }));
  const sts = all ? L.STATIONS : [st];
  sts.forEach(s => L.stationQueue(cases(), s, today, all ? undefined : me).forEach(({ c, items }) => { const its = items.filter(i => !(i.key === 'opReport' && out.some(t => t.flag?.kind === 'op-report' && t.flag.caseId === c.id)));
    if (its.length) out.push({ id: `item:${s}:${c.id}`, kind: 'item', station: s, c, pid: c.pid, name: pn(c.pid), label: its.length === 1 ? its[0].label : `${its[0].label} +${its.length - 1} more`, why: `${c.date === today ? c.time : c.date} · ${c.procedure} · ${c.room} · ${L.LOC_LABEL[c.loc]}`, keys: its.map(i => i.key) }); }));
  return out;
}

/* ---------------- fictional seed ---------------- */
export const ASC8_SEED = 'asc80-seed-1+v90';
export function ensureAsc8Seed() {
  if (svRead<string>('asc8-seeded', '') === ASC8_SEED) return; const T = isoDay(); const at = new Date().toISOString();
  // the ASC has no office visits: drop the shared seed's office appointments (patients stay as fictional chart history)
  try { localStorage.setItem('vityls:med:visits', '[]'); } catch { /* */ }
  const P = (id: string, name: string, dob: string, sex: MedPatient['sex'], allergies: string[], meds: [string, string, string][], probs: string[]) => {
    medRepo.savePatient({ id, name, dob, sex, phone: `(555) 017-${id.slice(-4)}`, email: `${name.split(' ')[0].toLowerCase()}@example.test`, language: 'English', allergies, primaryProvider: PATEL, careTeam: [], insurance: 'Fictional Health Plan PPO', fictional: true } as MedPatient);
    meds.forEach(([n, d, f], i) => medRepo.saveMed({ id: `m-${id}-${i}`, patientId: id, name: n, dose: d, frequency: f, status: 'active', problemIds: [], source: 'ASC seed (fictional)', recordedAt: at, recordedBy: 'ASC seed' }, 'ASC seed'));
    probs.forEach((x, i) => medRepo.saveProblem({ id: `p-${id}-${i}`, patientId: id, description: x, conditionType: 'chronic' as any, status: 'active', recordedAt: at, recordedBy: 'ASC seed', source: 'ASC seed (fictional)' }, 'ASC seed'));
  };
  P('ASC-2001', 'Ada Kerr', '03/14/1969', 'Female', [], [['Lisinopril', '10 mg', 'daily']], ['Hypertension']);
  P('ASC-2002', 'Maren Holt', '07/02/1972', 'Female', ['Penicillin (rash)'], [['Omeprazole', '20 mg', 'daily']], ['Symptomatic cholelithiasis', 'Obesity (BMI 31)']);
  P('ASC-2003', 'Talia Wren', '11/19/1987', 'Female', [], [], []);
  P('ASC-2004', 'Desmond Akers', '01/30/1965', 'Male', ['Sulfa (hives)'], [['Metformin', '500 mg', 'twice daily'], ['Atorvastatin', '20 mg', 'nightly']], ['Type 2 diabetes', 'Right inguinal hernia', 'Sleep apnea (uses CPAP)']);
  P('ASC-2005', 'Priya Lund', '09/08/1978', 'Female', ['Latex (contact rash)'], [], ['Left carpal tunnel syndrome']);
  P('ASC-2006', 'Owen Marsh', '05/21/1992', 'Male', [], [], ['Right medial meniscus tear']);
  P('ASC-2007', 'Celia Ortega', '02/11/1980', 'Female', ['Codeine (nausea)'], [['Sertraline', '50 mg', 'daily']], ['Abdominal wall laxity after pregnancy']);
  P('ASC-2009', 'Iris Navarro', '06/22/1961', 'Female', [], [], ['Colon cancer screening']);
  P('ASC-2010', 'Jonah Reyes', '04/03/1984', 'Male', [], [], ['Skin lesion, back']);
  P('ASC-2008', 'Hugo Pell', '12/04/1958', 'Male', [], [['Apixaban', '5 mg', 'twice daily']], ['Atrial fibrillation (anticoagulated)', 'Left inguinal hernia']);
  const all: L.AscCase[] = []; const done = { by: 'ASC seed', at };
  const pre = { forms: done, financial: done, insurance: done, clearance: done, labs: done };
  const chk = { id: done, adult: { name: 'Fictional escort', phone: '(555) 019-0000', present: true }, arrival: '06:30 AM' };
  const prep = { vitals: done, npo: { solids: '10:00 PM', clears: '05:00 AM' }, allergy: done, meds: done, iv: { site: 'L hand', gauge: '20g' }, sitecheck: done, nursingForm: done, hpUpdate: done, sitemark: done, consentConfirm: done };
  const an = { asa: 'II', airway: { mallampati: 'II', notes: '' }, plan: { technique: 'General' }, anesConsent: done };
  const C = (id: string, pid: string, time: string, dur: number, room: string, surgeon: string, anes: string, procedure: string, cpt: string, loc: L.Loc, d: Record<string, any>, events: L.AscCase['events'] = {}, extra: Partial<L.AscCase> = {}, date = T) => {
    const vid = `visit-asc8-${id}`; medRepo.saveVisit({ id: vid, patientId: pid, date, time, durationMin: dur, provider: surgeon, room, visitType: 'Surgery case', reason: procedure, step: 'scheduled', problemIds: [], createdAt: at, createdBy: 'ASC seed' } as any);
    all.push({ id, pid, visitId: vid, date, time, durationMin: dur, room, surgeon, anesthesia: anes, procedure, cpt, loc, d, events, audit: [{ at, by: 'ASC seed', role: 'System', what: 'Case scheduled (fictional)' }], from: 'ASC', ...extra }); };
  C('c1', 'ASC-2001', '07:00 AM', 45, 'OR 3', PATEL, ANES[1], 'Carpal tunnel release, right', '64721', 'discharged', { ...pre, ...chk, ...prep, ...an, timeout: done, counts: done, ebl: 5, wound: 'I · Clean', implants: { none: true }, specimens: { none: true }, intraop: done, aldrete: 10, pain: '2/10', criteria: done, instructions: done, handoff: { ...done, signedAt: at, adult: 'Fictional escort' }, anesDischarge: done, dischargeOrder: done, opReport: { text: 'Signed op report (fictional).', signedBy: PATEL, signedAt: at, copy: 'surgery-vityls' } }, { inRoom: '07:02 AM', anesStart: '07:06 AM', incision: '07:15 AM', close: '07:38 AM', outRoom: '07:46 AM', pacuIn: '07:50 AM', pacuOut: '08:40 AM' }, { side: 'Right', surgeonOnSurgeryVityls: true });
  C('c2', 'ASC-2002', '07:30 AM', 90, 'OR 1', PATEL, ANES[0], 'Laparoscopic cholecystectomy', '47562', 'pacu', { ...pre, ...chk, ...prep, ...an, asa: 'II', timeout: done, counts: done, ebl: 25, wound: 'II · Clean-contaminated', implants: { none: true }, specimens: { list: 'Gallbladder to pathology' }, intraop: done, jots: ['Mildly inflamed gallbladder, no stones in the duct', 'Critical view of safety obtained'] }, { inRoom: '07:34 AM', anesStart: '07:38 AM', incision: '07:55 AM', close: '08:52 AM', outRoom: '09:05 AM', pacuIn: '09:08 AM' }, { surgeonOnSurgeryVityls: false });
  C('c3', 'ASC-2003', '08:00 AM', 120, 'OR 2', WHITFIELD, ANES[1], 'Breast augmentation', '19325', 'or', { ...pre, ...chk, ...prep, ...an, asa: 'I', timeout: done }, { inRoom: '08:06 AM', anesStart: '08:10 AM', incision: '08:31 AM' }, { surgeonOnSurgeryVityls: true });
  C('c4', 'ASC-2004', '09:30 AM', 75, 'OR 1', PATEL, ANES[0], 'Inguinal hernia repair, right', '49505', 'arrived', { ...pre, ...chk, arrival: '08:20 AM', vitals: done, npo: { solids: '09:00 PM', clears: '06:00 AM' }, meds: done }, {}, { side: 'Right', surgeonOnSurgeryVityls: false });
  C('c5', 'ASC-2005', '10:30 AM', 45, 'OR 3', WHITFIELD, ANES[1], 'Carpal tunnel release, left', '64721', 'scheduled', { ...pre }, {}, { side: 'Left', surgeonOnSurgeryVityls: true });
  C('c6', 'ASC-2006', '12:00 PM', 60, 'OR 2', PATEL, ANES[0], 'Knee arthroscopy with partial meniscectomy, right', '29881', 'scheduled', { forms: done, financial: done, insurance: done }, {}, { side: 'Right' });
  C('c7', 'ASC-2007', '01:00 PM', 150, 'OR 1', WHITFIELD, ANES[0], 'Abdominoplasty', '15830', 'scheduled', {}, {}, { surgeonOnSurgeryVityls: true });
  C('c9', 'ASC-2009', '08:30 AM', 30, 'Proc 1', PATEL, ANES[1], 'Colonoscopy, screening', '45378', 'preop', { ...pre, ...chk, arrival: '07:45 AM', vitals: done, npo: { solids: '08:00 PM', clears: '05:30 AM' }, allergy: done, meds: done, iv: { site: 'R hand', gauge: '22g' }, nursingForm: done }, {}, { surgeonOnSurgeryVityls: true });
  C('c10', 'ASC-2010', '01:30 PM', 30, 'Proc 1', WHITFIELD, ANES[1], 'Excision of skin lesion, back', '11403', 'scheduled', { forms: done, financial: done, insurance: done, clearance: done, labs: done }, {}, {});
  C('c8', 'ASC-2008', '07:30 AM', 75, 'OR 1', PATEL, ANES[0], 'Inguinal hernia repair, left', '49505', 'scheduled', {}, {}, { side: 'Left', from: 'Surgery.Vityls' }, addDays(T, 1));
  svWrite('asc8-cases', all);
  const F = (id: string, from: string, fromRole: string, to: L.Team, pid: string, cid: string, text: string, ans?: [string, string], kind?: 'op-report', toPerson?: string): L.AscFlag => ({ id, from, fromRole, to, toPerson, pid, caseId: cid, text, kind, at, status: ans ? 'answered' : 'open', ...(ans ? { reply: ans[1], repliedBy: ans[0], repliedAt: at } : {}) });
  svWrite('asc8-flags', [
    F('af-op-c2', 'Nightingale (automatic)', 'System', 'surgeon', 'ASC-2002', 'c2', 'Dictate op report: Laparoscopic cholecystectomy', undefined, 'op-report', PATEL),
    F('af-1', 'Noor Haddad, MD', 'Anesthesiologist', 'preop', 'ASC-2004', 'c4', 'Desmond: please get a fingerstick glucose before he goes back.'),
    F('af-2', 'Casey Morgan', 'Pre-op RN', 'front', 'ASC-2006', 'c6', 'Owen’s escort phone number is missing — please call him.'),
    F('af-3', 'Robin Lee', 'Circulating RN', 'pm', '', '', 'OR 2 light handle is loose; please log a service call.', ['Pat Quinn', 'Service call booked for 5 PM today.']),
    F('af-4', 'Sam Patel, MD', 'Surgeon', 'coord', 'ASC-2008', 'c8', 'Hugo (tomorrow) is on apixaban — confirm the hold with his cardiologist.'),
  ]);
  // block time (sideways scheduler) + station configuration: forms placed at their ASC station, signers per station
  svWrite('block-seed', [{ id: 'blk-1', surgeon: PATEL, date: T, start: '07:00 AM', end: '01:00 PM', room: 'OR 1' }, { id: 'blk-2', surgeon: WHITFIELD, date: T, start: '08:00 AM', end: '03:00 PM', room: 'OR 2' }]);
  svWrite('asc8-seeded', ASC8_SEED); bump();
}
