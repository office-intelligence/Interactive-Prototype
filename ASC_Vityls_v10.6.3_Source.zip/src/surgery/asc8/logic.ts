/* ASC.Vityls v8.0 · the ASC edition of Surgery.Vityls. Pure logic (no browser, no storage); unit-tested in tests/asc80.test.ts.
 * Seven day-of-surgery steps; each station sees only its own missing items. A step turns green when its required items are complete
 * (no "reviewed" checkbox). Nightingale drafts (op report) but never signs, orders or decides. Fictional data only. */
export type StepId = 'preadmit' | 'checkin' | 'preop' | 'anesthesia' | 'or' | 'pacu' | 'billing';
export type Station = 'front' | 'preop' | 'anesthesia' | 'surgeon' | 'or' | 'pacu' | 'billing';
export type Loc = 'scheduled' | 'arrived' | 'preop' | 'or' | 'pacu' | 'discharged' | 'closed';
export const STEPS: { id: StepId; n: number; label: string; who: string }[] = [
  { id: 'preadmit', n: 1, label: 'Pre-admission', who: 'Front desk, coordinator, nursing' },
  { id: 'checkin', n: 2, label: 'Check-in', who: 'Front desk' },
  { id: 'preop', n: 3, label: 'Pre-op nursing', who: 'Pre-op nurse' },
  { id: 'anesthesia', n: 4, label: 'Anesthesia', who: 'Anesthesia' },
  { id: 'or', n: 5, label: 'OR', who: 'OR team, surgeon' },
  { id: 'pacu', n: 6, label: 'PACU / Discharge', who: 'PACU nurse' },
  { id: 'billing', n: 7, label: 'Billing / close', who: 'Billing, Practice Manager' }];
export const STATION_LABEL: Record<Station, string> = { front: 'Front desk', preop: 'Pre-op nursing', anesthesia: 'Anesthesia', surgeon: 'Surgeon', or: 'OR team', pacu: 'PACU / Discharge', billing: 'Billing / Practice Manager' };
export const STATIONS: Station[] = ['front', 'preop', 'anesthesia', 'surgeon', 'or', 'pacu', 'billing'];
/** Staff role → station. MA and Patient Coordinator share the pre-op nursing view (Kevin: no separate view, own flag list). Pre-op and
 *  PACU nurses are separate stations (Kevin's decision 3). */
export function stationOf(role: string): Station {
  const r = role || '';
  if (/anesth|crna/i.test(r)) return 'anesthesia';
  if (/surgeon|physician|\bmd\b/i.test(r)) return 'surgeon';
  if (/pacu|recovery/i.test(r)) return 'pacu';
  if (/circulat|scrub|\bor\b|operating/i.test(r)) return 'or';
  if (/front|desk|reception|scheduler/i.test(r)) return 'front';
  if (/billing|manager|administrator|admin|owner|ceo/i.test(r)) return 'billing';
  return 'preop';
}
export const LOC_ORDER: Loc[] = ['scheduled', 'arrived', 'preop', 'or', 'pacu', 'discharged', 'closed'];
export const LOC_LABEL: Record<Loc, string> = { scheduled: 'Scheduled', arrived: 'Checked in', preop: 'In pre-op', or: 'In OR', pacu: 'In PACU', discharged: 'Discharged', closed: 'Closed' };
/** Case color coding by status (same colors on Today rows, scheduler blocks and the Operations room grid). Warm palette. */
export const LOC_COLOR: Record<Loc, string> = { scheduled: '#8a7f72', arrived: '#b7791f', preop: '#c2620a', or: '#a8402a', pacu: '#7a4fa0', discharged: '#3f7d5a', closed: '#5b6b63' };
const li = (l: Loc) => LOC_ORDER.indexOf(l);
export const atLeast = (l: Loc, min: Loc) => li(l) >= li(min);

export type EventKey = 'inRoom' | 'anesStart' | 'incision' | 'close' | 'anesEnd' | 'outRoom' | 'pacuIn' | 'pacuOut';
export const EVENTS: { key: EventKey; label: string }[] = [{ key: 'inRoom', label: 'In room' }, { key: 'anesStart', label: 'Anesthesia start' }, { key: 'incision', label: 'Incision' }, { key: 'close', label: 'Close' }, { key: 'outRoom', label: 'Out of room' }];
export interface AuditRow { at: string; by: string; role: string; what: string }
export interface Signed { by: string; at: string }
export interface AscCase {
  id: string; pid: string; visitId: string; date: string; time: string; durationMin: number; room: string; surgeon: string; anesthesia: string; procedure: string; cpt: string; side?: string;
  loc: Loc; d: Record<string, any>; events: Partial<Record<EventKey, string>>; audit: AuditRow[]; from?: 'Surgery.Vityls' | 'ASC'; surgeonOnSurgeryVityls?: boolean;
}
export interface Item { key: string; step: StepId; station: Station; label: string; req: boolean; sign?: boolean; form?: string }
/** Every item per step. `station` owns it; `sign` = needs a PIN signature; `form` = the ASC template it is recorded on. */
export const ITEMS: Item[] = [
  { key: 'forms', step: 'preadmit', station: 'front', label: 'Patient forms signed', req: true, form: 'ASC_Registration_Insurance.html' },
  { key: 'financial', step: 'preadmit', station: 'front', label: 'Financial form signed', req: true, form: 'ASC_Financial.html' },
  { key: 'insurance', step: 'preadmit', station: 'front', label: 'Insurance verified / deposit', req: true },
  { key: 'clearance', step: 'preadmit', station: 'preop', label: 'Clearance received & reviewed', req: true, form: 'ASC_PreOp_HP_Clearance.html' },
  { key: 'labs', step: 'preadmit', station: 'preop', label: 'Labs received & reviewed', req: true },
  { key: 'id', step: 'checkin', station: 'front', label: 'ID & insurance card confirmed', req: true },
  { key: 'adult', step: 'checkin', station: 'front', label: 'Responsible adult', req: true },
  { key: 'arrival', step: 'checkin', station: 'front', label: 'Arrival time', req: true },
  { key: 'vitals', step: 'preop', station: 'preop', label: 'Vitals', req: true },
  { key: 'npo', step: 'preop', station: 'preop', label: 'NPO', req: true },
  { key: 'allergy', step: 'preop', station: 'preop', label: 'Confirm allergies', req: true },
  { key: 'meds', step: 'preop', station: 'preop', label: 'Medications reviewed', req: true },
  { key: 'iv', step: 'preop', station: 'preop', label: 'IV', req: true },
  { key: 'nursingForm', step: 'preop', station: 'preop', label: 'Nursing pre-op assessment', req: true, sign: true, form: 'ASC_Nursing_PreOp_Assessment.html' },
  { key: 'hpUpdate', step: 'preop', station: 'surgeon', label: 'Interval H&P update', req: true, sign: true, form: 'DayOf_Interval_HP_Update.html' },
  { key: 'sitemark', step: 'preop', station: 'surgeon', label: 'Site marked', req: true },
  { key: 'consentConfirm', step: 'preop', station: 'surgeon', label: 'Procedure consent confirmed', req: true },
  { key: 'asa', step: 'anesthesia', station: 'anesthesia', label: 'ASA class', req: true },
  { key: 'airway', step: 'anesthesia', station: 'anesthesia', label: 'Airway', req: true },
  { key: 'plan', step: 'anesthesia', station: 'anesthesia', label: 'Plan', req: true },
  { key: 'anesConsent', step: 'anesthesia', station: 'anesthesia', label: 'Anesthesia consent', req: true, sign: true, form: 'Anesthesia_Consent.html' },
  { key: 'timeout', step: 'or', station: 'or', label: 'Time-out', req: true, form: 'Universal_Protocol_Safety_Checklist.html' },
  { key: 'events', step: 'or', station: 'or', label: 'OR times', req: true },
  { key: 'counts', step: 'or', station: 'or', label: 'Counts correct', req: true, form: 'IntraOp_Nursing_Record_TO.html' },
  { key: 'ebl', step: 'or', station: 'or', label: 'EBL', req: true },
  { key: 'wound', step: 'or', station: 'or', label: 'Wound class', req: true },
  { key: 'implants', step: 'or', station: 'or', label: 'Implants', req: true },
  { key: 'specimens', step: 'or', station: 'or', label: 'Specimens', req: true },
  { key: 'intraop', step: 'or', station: 'anesthesia', label: 'Anesthesia intra-op record (paper, scanned and uploaded)', req: true },
  { key: 'toPacu', step: 'or', station: 'or', label: 'Patient to PACU', req: true },
  { key: 'aldrete', step: 'pacu', station: 'pacu', label: 'Aldrete score', req: true, form: 'PACU_Recovery_Record.html' },
  { key: 'criteria', step: 'pacu', station: 'pacu', label: 'Discharge criteria', req: true },
  { key: 'instructions', step: 'pacu', station: 'pacu', label: 'Discharge instructions', req: true, form: 'Written_Discharge_Instructions.html' },
  { key: 'anesDischarge', step: 'pacu', station: 'anesthesia', label: 'Anesthesia discharge from PACU', req: true, sign: true },
  { key: 'opReport', step: 'or', station: 'surgeon', label: 'Brief OP report signed', req: true, sign: true },
  { key: 'charges', step: 'billing', station: 'billing', label: 'Charges from the fee schedule', req: true },
  { key: 'close', step: 'billing', station: 'billing', label: 'Close the case', req: true }];
export const itemsOf = (s: StepId) => ITEMS.filter(i => i.step === s);
export const item = (k: string) => ITEMS.find(i => i.key === k)!;

/** Is an item complete? Values live in case.d; OR times in case.events. */
export function isDone(c: AscCase, key: string): boolean {
  const v = c.d[key];
  switch (key) {
    case 'events': return EVENTS.every(e => !!c.events[e.key]);
    case 'adult': return !!(v && v.name && v.phone);
    case 'npo': return !!(v && v.solids && v.clears);
    case 'airway': return !!(v && v.mallampati);
    case 'plan': return !!(v && v.technique);
    case 'aldrete': return !!(v && Number(v) >= 9) || !!(v && typeof v === 'object' && Number(v.score) >= 9);
    case 'ebl': return v !== undefined && v !== '' && v !== null;
    case 'implants': case 'specimens': return !!(v && (v.none || (v.list && v.list.trim())));
    case 'toPacu': return atLeast(c.loc, 'pacu');
    case 'close': return c.loc === 'closed';
    case 'opReport': return !!(v && v.signedAt);
    case 'handoff': return !!(v && v.signedAt);
    default: return !!v;
  }
}
/** When an item can be worked on: pre-admission any time; check-in on the day; pre-op/anesthesia once arrived; OR once in the room;
 *  PACU items once in PACU; billing once discharged. */
export function actionable(c: AscCase, it: Item, today: string): boolean {
  if (c.loc === 'closed') return false;
  if (it.step === 'preadmit') return true;
  if (it.step === 'checkin') return c.date <= today;
  if (it.step === 'preop' || it.step === 'anesthesia') return c.date <= today && atLeast(c.loc, 'arrived');
  if (it.key === 'intraop') return atLeast(c.loc, 'or');
  if (it.step === 'or') return atLeast(c.loc, 'preop') && (it.key === 'timeout' || it.key === 'events' || atLeast(c.loc, 'or'));
  if (it.step === 'pacu') return atLeast(c.loc, 'pacu');
  if (it.step === 'billing') return atLeast(c.loc, 'discharged');
  return false;
}
export const missing = (c: AscCase, st: Station, today: string) => ITEMS.filter(i => i.station === st && actionable(c, i, today) && !isDone(c, i.key));
export const stepComplete = (c: AscCase, s: StepId) => itemsOf(s).filter(i => i.req).every(i => isDone(c, i.key));
export const doneLine = (c: AscCase, s: StepId) => itemsOf(s).filter(i => isDone(c, i.key)).map(i => i.label);
/** The first step that is not complete (the case's "current step"). */
export function currentStep(c: AscCase): StepId | 'done' { const s = STEPS.find(x => !stepComplete(c, x.id)); return s ? s.id : 'done'; }
/** Patients a station works on right now: cases with at least one missing item it owns (surgeon: own cases only). */
export function stationQueue(cases: AscCase[], st: Station, today: string, me?: string) {
  return cases.filter(c => c.date === today || (c.date > today && missing(c, st, today).some(i => i.step === 'preadmit')))
    .filter(c => st !== 'surgeon' || !me || c.surgeon === me)
    .map(c => ({ c, items: missing(c, st, today) })).filter(x => x.items.length)
    .sort((a, b) => a.c.date.localeCompare(b.c.date) || toMin(a.c.time) - toMin(b.c.time));
}
export function toMin(t: string): number { const m = /(\d+):(\d+)\s*(AM|PM)?/i.exec(t || ''); if (!m) return 0; let h = +m[1] % 12; if (m[3] && /pm/i.test(m[3])) h += 12; if (!m[3] && +m[1] === 12) h = 12; return h * 60 + +m[2]; }

/* ---------------- moving the patient ---------------- */
/** Next location from an action. Into the OR = the "In room" time; Patient to PACU needs Out-of-room; discharge needs the PACU items. */
/** v8.4 · workflow never blocks: what is still missing when a patient moves on (shown as light-yellow exceptions). */
export function moveWarnings(c: AscCase, to: Loc): string[] { const w: string[] = [];
  if (to === 'arrived' && !isDone(c, 'id')) w.push('ID and insurance not confirmed');
  if (to === 'or' && !c.events.inRoom) w.push('In-room time not recorded');
  if (to === 'pacu' && !c.events.outRoom) w.push('Out-of-room time not recorded');
  if (to === 'discharged') ITEMS.filter(i => i.step === 'pacu' && i.key !== 'opReport' && !isDone(c, i.key)).forEach(i => w.push(i.label));
  if (to === 'closed') { if (!isDone(c, 'opReport')) w.push('Brief OP report not signed'); if (!c.d.formalOpReceived) w.push('Formal op report pending'); if (!isDone(c, 'charges')) w.push('Charges not posted'); }
  return w; }
/** Kept for compatibility: never blocks any more (always ''). Use moveWarnings for the exception list. */
export function canMove(_c: AscCase, _to: Loc): string { return ''; }
/** OR event time edit: a first entry is just recorded; changing a recorded time needs a reason and is audited. */
export function setEvent(c: AscCase, k: EventKey, time: string, by: string, role: string, at: string, reason = ''): AscCase {
  const prev = c.events[k]; if (prev && prev !== time && reason.trim().length < 3) throw new Error('Enter a reason to change a recorded time.');
  const label = EVENTS.find(e => e.key === k)?.label || (k === 'anesEnd' ? 'Anesthesia end' : k);
  const what = prev ? `${label} changed ${prev} → ${time} (reason: ${reason.trim()})` : `${label} recorded ${time}`;
  return { ...c, events: { ...c.events, [k]: time }, loc: k === 'inRoom' && !atLeast(c.loc, 'or') ? 'or' : c.loc, audit: [...c.audit, { at, by, role, what }] };
}

/* ---------------- billing ---------------- */
export interface Fee { cpt: string; desc: string; base: number; per15: number; includedMin: number }
/** Fictional facility fee schedule: a base fee covering the first `includedMin` OR minutes, then per 15 minutes. */
export const DEFAULT_FEES: Fee[] = [
  { cpt: '47562', desc: 'Laparoscopic cholecystectomy', base: 4200, per15: 310, includedMin: 60 },
  { cpt: '29881', desc: 'Knee arthroscopy with meniscectomy', base: 3600, per15: 280, includedMin: 45 },
  { cpt: '15830', desc: 'Panniculectomy / abdominoplasty', base: 5200, per15: 340, includedMin: 90 },
  { cpt: '19325', desc: 'Breast augmentation', base: 4800, per15: 320, includedMin: 75 },
  { cpt: '49505', desc: 'Inguinal hernia repair', base: 3300, per15: 260, includedMin: 60 },
  { cpt: '64721', desc: 'Carpal tunnel release', base: 1900, per15: 180, includedMin: 30 }];
export const orMinutes = (c: AscCase) => c.events.inRoom && c.events.outRoom ? Math.max(0, toMin(c.events.outRoom) - toMin(c.events.inRoom)) : 0;
export function charges(c: AscCase, fees: Fee[]): { lines: { what: string; amount: number }[]; total: number } {
  const f = fees.find(x => x.cpt === c.cpt); if (!f) return { lines: [], total: 0 };
  const mins = orMinutes(c); const extra = Math.max(0, Math.ceil((mins - f.includedMin) / 15)); const lines = [{ what: `${f.cpt} ${f.desc} · facility fee (first ${f.includedMin} min)`, amount: f.base }];
  if (extra) lines.push({ what: `OR time ${mins} min · ${extra} × 15 min`, amount: extra * f.per15 });
  const imp = c.d.implants?.list ? String(c.d.implants.list).split(/[,;\n]/).filter(x => x.trim()).length : 0; if (imp) lines.push({ what: `Implants × ${imp} (at invoice cost, fictional)`, amount: imp * 250 });
  return { lines, total: lines.reduce((n, l) => n + l.amount, 0) };
}

/* ---------------- flags (ASC teams) ---------------- */
export type Team = 'front' | 'preop' | 'pacu' | 'anesthesia' | 'surgeon' | 'or' | 'ma' | 'coord' | 'pm';
export const TEAMS: Team[] = ['front', 'preop', 'pacu', 'anesthesia', 'surgeon', 'or', 'ma', 'coord', 'pm'];
export const TEAM_LABEL: Record<Team, string> = { front: 'Front desk', preop: 'Pre-op nursing', pacu: 'PACU nursing', anesthesia: 'Anesthesia', surgeon: 'Surgeons', or: 'OR team', ma: 'Medical assistants', coord: 'Patient coordinators', pm: 'Practice manager' };
export function teamsOf(role: string): Team[] {
  const r = role || ''; if (/medical assistant|^ma$/i.test(r)) return ['preop', 'ma']; if (/coordinator/i.test(r)) return ['preop', 'coord'];
  const s = stationOf(r); return s === 'billing' ? ['pm'] : [s as Team];
}
export interface AscFlag { id: string; from: string; fromRole: string; to: Team; toPerson?: string; pid?: string; caseId?: string; text: string; at: string; kind?: 'op-report'; status: 'open' | 'answered' | 'closed'; reply?: string; repliedBy?: string; repliedAt?: string }
/** Open flags show for the receiving team (a person-addressed flag, like "Dictate op report", only for that person); answers go back to the sender. */
export function flagsFor(all: AscFlag[], me: string, role: string, allRoles = false) {
  const tg = teamsOf(role); const out: { f: AscFlag; kind: 'incoming' | 'answer' }[] = [];
  all.forEach(f => { if (f.status === 'open' && (allRoles || (f.toPerson ? f.toPerson === me : tg.includes(f.to)))) out.push({ f, kind: 'incoming' });
    if (f.status === 'answered' && (allRoles || f.from === me)) out.push({ f, kind: 'answer' }); });
  return out;
}

/* ---------------- op report ---------------- */
export interface OpCtx { name: string; age: number; sex: string; date: string; procedure: string; side?: string; surgeon: string; anesthesia: string; technique?: string; asa?: string; ebl?: string; wound?: string; implants?: string; specimens?: string; times: Partial<Record<EventKey, string>>; allergies: string[]; jots: string[] }
/** Nightingale's op-report draft from recorded case facts only. Findings and technique carry "[surgeon to complete]"; never signed by Nightingale. */
export function draftOpReport(c: OpCtx): string {
  const t = (k: EventKey) => c.times[k] || '—';
  return [`OPERATIVE REPORT (Nightingale draft · surgeon to review, edit and sign)`,
    `PATIENT\n${c.name}, ${c.age}-year-old ${c.sex.toLowerCase()}. Date of surgery ${c.date}.`,
    `PROCEDURE\n${c.procedure}${c.side ? ` (${c.side})` : ''}`, `SURGEON\n${c.surgeon}`, `ANESTHESIA\n${c.technique || '[surgeon to complete]'}${c.asa ? ` · ASA ${c.asa}` : ''} · ${c.anesthesia}`,
    `PRE-OPERATIVE DIAGNOSIS\n[surgeon to complete]`, `POST-OPERATIVE DIAGNOSIS\n[surgeon to complete]`,
    `TIMES\nIn room ${t('inRoom')} · Incision ${t('incision')} · Close ${t('close')} · Out ${t('outRoom')}`,
    `FINDINGS\n${c.jots.length ? c.jots.map(j => `- ${j}`).join('\n') : '[surgeon to complete]'}`, `DESCRIPTION OF PROCEDURE\n[surgeon to complete]`,
    `ESTIMATED BLOOD LOSS\n${c.ebl ? `${c.ebl} mL` : '[not recorded]'}`, `WOUND CLASS\n${c.wound || '[not recorded]'}`, `IMPLANTS\n${c.implants || 'None'}`, `SPECIMENS\n${c.specimens || 'None'}`,
    `ALLERGIES\n${c.allergies.length ? c.allergies.join('; ') : 'No known allergies'}`, `CONDITION\nTo PACU in [surgeon to complete] condition.`].join('\n\n');
}
/** Where the signed copy goes: the surgeon's own Surgery.Vityls (network, simulated) or a secure-link email that carries no patient details. */
export function copyPlan(onSurgeryVityls: boolean, email: string): { via: 'surgery-vityls' | 'secure-link'; to: string; subject: string; body: string } {
  if (onSurgeryVityls) return { via: 'surgery-vityls', to: 'Surgery.Vityls (your practice)', subject: 'Signed operative report', body: 'A signed copy was filed to your Surgery.Vityls chart through the network link (simulated).' };
  return { via: 'secure-link', to: email, subject: 'A signed document is ready', body: 'A document you signed at the surgery center is ready. Open the secure link and sign in to view it. This email contains no patient information. (Simulated; nothing is sent.)' };
}
/** Email copy must never carry patient identifiers. */
export const hasPhi = (s: string, name: string, dob: string) => [name, ...name.split(/\s+/).filter(x => x.length > 2), dob].some(x => x && s.toLowerCase().includes(x.toLowerCase()));

/* ---------------- Operations ---------------- */
export function turnovers(cases: AscCase[]) {
  const by: Record<string, AscCase[]> = {}; cases.forEach(c => (by[c.room] = by[c.room] || []).push(c)); const out: { room: string; from: string; to: string; min: number }[] = [];
  Object.entries(by).forEach(([room, l]) => { const s = l.filter(c => c.events.inRoom).sort((a, b) => toMin(a.events.inRoom!) - toMin(b.events.inRoom!));
    for (let i = 1; i < s.length; i++) if (s[i - 1].events.outRoom) out.push({ room, from: s[i - 1].id, to: s[i].id, min: toMin(s[i].events.inRoom!) - toMin(s[i - 1].events.outRoom!) }); });
  return out;
}
export function utilization(cases: AscCase[], rooms: string[], dayMin = 600) { return rooms.map(r => { const m = cases.filter(c => c.room === r).reduce((n, c) => n + orMinutes(c), 0); return { room: r, min: m, pct: Math.round(100 * m / dayMin) }; }); }
export const delays = (cases: AscCase[]) => cases.filter(c => c.events.inRoom).map(c => ({ id: c.id, min: toMin(c.events.inRoom!) - toMin(c.time) })).filter(x => x.min > 0);
/** Bottlenecks: which step holds the most open items today. */
export function bottlenecks(cases: AscCase[], today: string) {
  return STEPS.map(s => { const open = cases.filter(c => c.date === today).reduce((n, c) => n + itemsOf(s.id).filter(i => actionable(c, i, today) && !isDone(c, i.key)).length, 0); return { step: s.id, label: s.label, open }; }).filter(x => x.open).sort((a, b) => b.open - a.open);
}

/** Automatic location from completed work (no "reviewed" checkbox): check-in complete → Checked in; first pre-op item → In pre-op;
 *  PACU items complete (op report may still be pending) → Discharged. In room / Patient to PACU / Close are explicit actions. */
export function autoLoc(c: AscCase): Loc {
  if (c.loc === 'scheduled' && stepComplete(c, 'checkin')) return 'arrived';
  if (c.loc === 'arrived' && itemsOf('preop').some(i => i.station === 'preop' && isDone(c, i.key))) return 'preop';
  if (c.loc === 'pacu' && ITEMS.filter(i => i.step === 'pacu' && i.key !== 'opReport').every(i => isDone(c, i.key))) return 'discharged';
  return c.loc;
}
/** The one-line patient header: only facts that are actually recorded (no "Not yet recorded" cards). */
export function headerFacts(c: AscCase, allergies: string[], confirmed: boolean, weightKg?: number): string[] {
  const out: string[] = [];
  out.push(allergies.length ? `Allergy: ${allergies.join(', ')}${confirmed ? ' (confirmed)' : ''}` : confirmed ? 'No known allergies (confirmed)' : '');
  if (c.d.npo?.solids) out.push(`NPO since ${c.d.npo.solids}`); if (weightKg) out.push(`${weightKg} kg`); if (c.d.asa) out.push(`ASA ${c.d.asa}`);
  return out.filter(Boolean);
}
