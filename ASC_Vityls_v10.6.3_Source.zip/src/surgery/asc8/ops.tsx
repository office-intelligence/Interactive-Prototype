/* ASC.Vityls v8.0 · Operations (Practice Manager / admin): one summary line, the room grid (moved from the retired Classic board),
 * bottlenecks (also from the Classic board), turnover, utilization and delays. The CEO/admin dashboard folds into this line.
 * Plus the fee schedule editor (Practice › Billing). Fictional data. */
import React, { useState } from 'react';
import { medRepo, isoDay } from '../../med/record';
import { useActor, useMedTick } from '../../med/ui';
import { useSv } from '../ui';
import * as L from './logic';
import * as S from './store';
import { openAsc } from './ui';
import { OpsViews } from '../asc81/practice81';
const START = 7 * 60, END = 17 * 60;
export const AscOperations: React.FC = () => {
  useMedTick(); const { setTab } = useSv(); const T = isoDay(); const cs = S.cases().filter(c => c.date === T);
  const util = L.utilization(cs, S.ROOMS); const turn = L.turnovers(cs); const del = L.delays(cs); const bn = L.bottlenecks(S.cases(), T);
  const avgT = turn.length ? Math.round(turn.reduce((n, t) => n + t.min, 0) / turn.length) : 0; const pct = (m: number) => `${(100 * (m - START) / (END - START)).toFixed(2)}%`;
  const billed = cs.reduce((n, c) => n + (c.d.charges?.total || 0), 0);
  return <div className="sv-page a8-ops" data-testid="a8-ops">
    <h1 className="sv-title">Operations</h1>
    <p className="a8-brief" data-testid="a8-ops-line">{cs.length} cases today · {cs.filter(c => c.loc === 'or').length} in the OR · OR utilization {Math.round(util.reduce((n, u) => n + u.pct, 0) / util.length)}% · average turnover {avgT || '—'} min · {del.length} late start{del.length === 1 ? '' : 's'} · ${billed.toLocaleString()} posted (fictional)</p>
    <section className="v7-card a8-grid-rooms" aria-label="Room grid" data-testid="a8-room-grid"><h2 className="a8-h2">Rooms today</h2>
      <div className="hours">{Array.from({ length: (END - START) / 60 + 1 }, (_, i) => <span key={i} style={{ left: pct(START + i * 60) }}>{((7 + i - 1) % 12) + 1}{7 + i < 12 ? 'a' : 'p'}</span>)}</div>
      {S.ROOMS.map(r => <div key={r} className="room" data-testid="a8-room-row"><b>{r}</b><div className="lane">{cs.filter(c => c.room === r).map(c => { const s = Math.min(END - 15, Math.max(START, L.toMin(c.events.inRoom || c.time))); const e = Math.max(s + 15, Math.min(END, c.events.outRoom ? L.toMin(c.events.outRoom) : s + c.durationMin));
        return <button key={c.id} type="button" className="blk" style={{ left: pct(s), width: `${(100 * (e - s) / (END - START)).toFixed(2)}%`, background: L.LOC_COLOR[c.loc] }} onClick={() => openAsc({ t: 'record', cid: c.id })} title={`${medRepo.patient(c.pid)?.name} · ${c.procedure} · ${L.LOC_LABEL[c.loc]}`} data-testid="a8-room-block">{medRepo.patient(c.pid)?.name.split(' ')[0]} · {c.procedure.split(/[ ,]/)[0]}</button>; })}</div></div>)}
      <div className="a8-legend">{L.LOC_ORDER.map(l => <span key={l}><i style={{ background: L.LOC_COLOR[l] }} />{L.LOC_LABEL[l]}</span>)}</div></section>
    <OpsViews />
    <div className="a8-two">
      <section className="v7-card" data-testid="a8-bottlenecks"><h2 className="a8-h2">Bottlenecks</h2>{bn.length ? bn.map(b => <div key={b.step} className="a8-line"><span>{b.label}</span><b>{b.open} open</b></div>) : <p className="a8-mut">No open items.</p>}</section>
      <section className="v7-card" data-testid="a8-turnover"><h2 className="a8-h2">Turnover &amp; delays</h2>{turn.map((t, i) => <div key={i} className="a8-line"><span>{t.room} turnover</span><b>{t.min} min</b></div>)}{del.map(d => <div key={d.id} className="a8-line"><span>{medRepo.patient(S.caseById(d.id)!.pid)?.name} started late</span><b>{d.min} min</b></div>)}{!turn.length && !del.length && <p className="a8-mut">No turnovers yet today.</p>}
        <button type="button" className="a8-link" onClick={() => setTab('staff')} data-testid="a8-ops-staff">Staffing &amp; payroll ›</button></section>
    </div>
  </div>;
};
export const FeeSchedule: React.FC = () => {
  useMedTick(); const [actor] = useActor(); const { toast } = useSv(); const [rows, setRows] = useState<L.Fee[]>(() => S.fees());
  const set = (i: number, k: keyof L.Fee, v: string) => setRows(r => r.map((x, j) => j === i ? { ...x, [k]: k === 'cpt' || k === 'desc' ? v : Number(v) || 0 } : x));
  return <section className="v7-card a8-fees" data-testid="a8-fees"><h2 className="a8-h2">ASC facility fee schedule (fictional)</h2>
    <table className="a8-table"><thead><tr><th>CPT</th><th>Procedure</th><th>Base fee</th><th>Included min</th><th>Per 15 min</th></tr></thead><tbody>{rows.map((r, i) => <tr key={i}>{(['cpt', 'desc', 'base', 'includedMin', 'per15'] as (keyof L.Fee)[]).map(k => <td key={k}><input className="a8-in" value={String(r[k])} onChange={e => set(i, k, e.target.value)} data-testid={`a8-fee-${k}`} /></td>)}</tr>)}</tbody></table>
    <div className="a8-row"><button type="button" className="a8-link" onClick={() => setRows(r => [...r, { cpt: '', desc: '', base: 0, includedMin: 60, per15: 0 }])}>+ Add row</button><button type="button" className="a8-btn pri" style={{ marginLeft: 'auto' }} onClick={() => { S.saveFees(rows.filter(r => r.cpt), actor.name, actor.role); toast('Fee schedule saved.'); }} data-testid="a8-fees-save">Save</button></div></section>;
};
