/* ASC.Vityls v8.0 · merged ASC templates on the Surgery form engine (browser: uses the template parser). Every source field is kept:
 * a field whose name already exists is kept only once when it is the same question (same label), otherwise it is renamed. */
import { parseTemplate, formLibHooks, FormDef, Field, Section } from '../v09/formLib';
import { getBundledFormHtml } from '../../v6/formSource';
import { GENERATED_REFERENCE_FORMS } from '../../data/generatedReferenceForms';
import { ASC_FORMS, MERGED, AscForm, isCredentialing } from './formSet';
import { uid } from '../../med/record';
const srcTitle = (f: string) => GENERATED_REFERENCE_FORMS.find(x => x.file === f)?.title || f.replace(/\.html$/, '').replace(/_/g, ' ');
const cache: Record<string, FormDef> = {};
const norm = (s: string) => (s || '').toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim();
export function mergedDef(file: string): FormDef | undefined {
  const m = MERGED.find(f => f.file === file); if (!m) return undefined; if (cache[file]) return cache[file];
  const names = new Map<string, string>(); const sections: Section[] = []; let intro = '';
  m.sources.forEach(src => { const d = parseTemplate(getBundledFormHtml(src), srcTitle(src)); if (!intro && d.intro) intro = d.intro;
    d.sections.forEach(s => { const fields: Field[] = []; s.fields.forEach(f => { const seen = names.get(f.name);
      if (seen !== undefined && norm(seen) === norm(f.label)) return; // same question asked twice (e.g. patient name): keep once
      let name = f.name; let i = 2; while (names.has(name)) name = `${f.name}_${i++}`; names.set(name, f.label); fields.push({ ...f, name }); });
      if (fields.length) sections.push({ ...s, title: m.sources.length > 1 && s === d.sections[0] ? `${srcTitle(src)} · ${s.title}` : s.title, fields }); }); });
  if (m.extra) sections.push({ id: uid('s'), title: m.extra.title, columns: 1, fields: m.extra.fields.map(f => ({ id: uid('f'), type: f.type, name: f.name, label: f.label, width: 3 as const })) });
  return (cache[file] = { title: m.title, intro: intro || undefined, sections });
}
/** Feature check: every source field (name + label) is present in the merged template. */
export function mergeCheck(): { file: string; title: string; sources: number; sourceFields: number; mergedFields: number; lost: string[] }[] {
  return MERGED.map(m => { const d = mergedDef(m.file)!; const got = d.sections.flatMap(s => s.fields); const lost: string[] = [];
    m.sources.forEach(src => parseTemplate(getBundledFormHtml(src), srcTitle(src)).sections.flatMap(s => s.fields).forEach(f => { if (!got.some(g => norm(g.label) === norm(f.label) && (g.name === f.name || g.name.startsWith(f.name + '_')) || (g.name === f.name && norm(g.label) === norm(f.label)))) lost.push(`${src}: ${f.label}`); }));
    return { file: m.file, title: m.title, sources: m.sources.length, sourceFields: m.sources.reduce((n, src) => n + parseTemplate(getBundledFormHtml(src), '').sections.flatMap(s => s.fields).length, 0), mergedFields: got.length, lost }; });
}
export function installAscForms() { try { localStorage.setItem('vityls-explicit-form-workflow-v3-clean', 'done'); localStorage.setItem('oi-premiere-official-html-library-v27-clean', 'done'); } catch { /* */ } formLibHooks.original = (file: string) => mergedDef(file); (window as any).__asc8 = { ...(window as any).__asc8, mergeCheck, forms: ASC_FORMS.length }; }
export const formsByStation = (st: AscForm['station']) => ASC_FORMS.filter(f => f.station === st);
import { repo } from '../../v6/dataLayer';
import { blankWorkflow, workflowStorageKey } from '../../data/formWorkspaceCatalog';
/** Station configuration for the ASC edition (seeded once; the practice edits it in Practice › Forms & workflow): every template in
 *  My Forms, placed at its station, Required / As needed, and the signers for that station. */
export function ensureAscFormConfig() {
  localStorage.setItem('vityls-explicit-form-workflow-v3-clean', 'done'); localStorage.setItem('oi-premiere-official-html-library-v27-clean', 'done');
  if (localStorage.getItem('asc8-forms-config') === '2' && localStorage.getItem(workflowStorageKey('ASC_Financial.html'))) return;
  localStorage.setItem('vityls-my-forms:default-practice', JSON.stringify(ASC_FORMS.map(f => f.file)));
  ASC_FORMS.forEach(f => { const w = blankWorkflow(); if (!isCredentialing(f.file)) w[f.station].enabled = true; // credentialing is a provider form: My Forms + Practice › Staff, never on a patient case localStorage.setItem(workflowStorageKey(f.file), JSON.stringify(w)); localStorage.setItem(`vityls-form-requirement:${f.file}`, f.req);
    if (f.signers.length) repo.saveSignerConfig({ file: f.file, signers: f.signers.map((r, i) => ({ id: `s${i + 1}`, role: r, label: r, attestation: `${r} signature`, required: true, patient: /patient/i.test(r) })), sequential: false, initials: [], updatedAt: new Date().toISOString(), updatedBy: 'ASC.Vityls v8.0 setup' } as any); });
  localStorage.setItem('asc8-forms-config', '2');
}
