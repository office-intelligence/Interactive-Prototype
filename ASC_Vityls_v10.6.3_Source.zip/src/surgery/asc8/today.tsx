import { StationChips } from '../asc84/chips';
/* ASC.Vityls v8.0 · Today (Surgery's Today patient view, for the OR day) and "My to-do" on Chat. Each station sees only its own work:
 * its patients and their missing items. "See all roles" shows every team's progress (read-only). The Classic board is retired;
 * its room grid and bottlenecks live in Operations. */
import { CollectCard } from '../asc83/frontdesk';
import { EpisodeWorklist, EpisodeSearch, MetricsCard } from '../asc86/ui86';
import React from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { medRepo, isoDay, addDays } from '../../med/record';
import { useActor, useMedTick } from '../../med/ui';
import { displayName } from '../v07/Today7';
import * as L from './logic';
import * as S from './store';
import { openAsc, openFor, Stage } from './ui';
import { StationIcon } from '../asc81/icons81';
import { BenchChips, QuickActions } from '../asc81/practice81';
const hm = (t: string) => { const m = L.toMin(t); return `${String(Math.floor(m / 60)).padStart(2, '0')}:${String(m % 60).padStart(2, '0')}`; };
const RoleSwitch: React.FC<{ st: L.Station; all: boolean }> = ({ st, all }) => <span className="a8-sw" role="group" aria-label="Whose work"><button type="button" className={!all ? 'on' : ''} onClick={() => S.setAllRoles(false)} data-testid="a8-my-station">{L.STATION_LABEL[st]}</button><button type="button" className={all ? 'on' : ''} onClick={() => S.setAllRoles(true)} data-testid="a8-all-roles">See all roles</button></span>;

/** Chat page: flags + my station's to-do (each row opens only the missing piece). */
export const AscTodo: React.FC<{ limit?: number }> = ({ limit = 8 }) => {
  useMedTick(); const [actor] = useActor(); const st = L.stationOf(actor.role); const all = S.allRolesOn(); const list = S.ascTodos(actor.name, actor.role, all); const [more, setMore] = React.useState(false);
  const shown = more ? list : list.slice(0, limit);
  return <section className="a8-todo" aria-label="My to-do" data-testid="a8-todo" data-station={st} data-all={all ? '1' : '0'}>
    <h3>{all ? 'All roles' : 'My to-do'} <span className="n" data-testid="a8-todo-count">{list.length}</span><RoleSwitch st={st} all={all} /></h3>
    {!list.length ? <p className="a8-row-i none" data-testid="a8-todo-none">✓ Nothing waiting for you.</p> : shown.map(t =>
      <button key={t.id} type="button" className="a8-row-i" onClick={() => t.kind === 'item' && t.c ? openFor(t.station, t.c, t.keys) : t.flag?.kind === 'op-report' && t.c ? openAsc({ t: 'op', cid: t.c.id }) : t.flag && openAsc({ t: 'reply', id: t.flag.id })} data-testid="a8-todo-item" data-kind={t.kind} data-station={t.station}>
        {t.kind === 'flag' ? <span className="a8-tag flag">Flag</span> : all && <span className="a8-tag" data-testid="a8-role-tag"><StationIcon st={t.station} size={12} />{L.STATION_LABEL[t.station]}</span>}
        <span className="t"><b>{t.name} · {t.label}</b><span className="w">{t.why}</span></span>{t.c && <Stage c={t.c} />}</button>)}
    <div className="a8-row">{list.length > limit && <button type="button" className="a8-link" onClick={() => setMore(m => !m)} data-testid="a8-todo-more">{more ? 'Show fewer' : `Show all ${list.length}`}</button>}
      <button type="button" className="a8-link" style={{ marginLeft: 'auto' }} onClick={() => openAsc({ t: 'flag' })} data-testid="a8-flag-new">⚑ Flag a team</button></div>
  </section>;
};

/** Today: the day's OR cases for my station (surgeons: own cases), each with only its missing items; See all roles = every case + 7 steps. */
export const AscToday: React.FC = () => {
  useMedTick(); const [actor] = useActor(); const T = isoDay(); const [day, setDay] = React.useState(T); const st = L.stationOf(actor.role); const all = S.allRolesOn();
  const h = new Date().getHours(); const hello = h < 12 ? 'Good morning' : h < 17 ? 'Good afternoon' : 'Good evening';
  const dayCases = S.cases().filter(c => c.date === day && (st !== 'surgeon' || all || c.surgeon === actor.name)).sort((a, b) => L.toMin(a.time) - L.toMin(b.time));
  const queue = all ? [] : L.stationQueue(S.cases(), st, day, actor.name).filter(x => x.c.date === day || st === 'front' || st === 'preop');
  const inOr = dayCases.filter(c => c.loc === 'or').length; const pacu = dayCases.filter(c => c.loc === 'pacu').length;
  const brief = `${dayCases.length} case${dayCases.length === 1 ? '' : 's'} ${day === T ? 'today' : 'on this day'} · ${inOr} in the OR · ${pacu} in PACU.${all ? '' : ` ${queue.length ? `${queue.length} need${queue.length === 1 ? 's' : ''} you.` : 'Nothing waiting for you.'}`}`;
  return <div className="v7-page a8-today" data-testid="sv-dashboard" data-station={st}>
    <div className="v7-today-head"><div className="min-w-0"><h1 className="v7-h1" data-testid="today-greeting">{hello}, {displayName(actor.name, actor.role)}</h1>
      <div className="v7-daynav"><span className="v7-date" data-testid="today-title">{new Date(day + 'T12:00').toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' })}</span>
        <button type="button" className="v7-icon-btn" onClick={() => setDay(addDays(day, -1))} aria-label="Previous day"><ChevronLeft size={16} /></button><button type="button" className="v7-icon-btn" onClick={() => setDay(addDays(day, 1))} aria-label="Next day" data-testid="today-next"><ChevronRight size={16} /></button>
        <button type="button" className="v7-btn sm" onClick={() => setDay(T)} disabled={day === T}>Today</button></div>
      <p className="a8-brief" data-testid="a8-brief">{brief}</p></div><RoleSwitch st={st} all={all} /></div>
    <EpisodeSearch onOpen={cid => openAsc({ t: 'record', cid })} />
    <BenchChips />{/administrator|manager|medical director/i.test(actor.role) && <MetricsCard />}<EpisodeWorklist day={day} />{st === 'billing' && <QuickActions />}{(st === 'front' || st === 'billing') && <CollectCard />}
    {!all ? <section className="v7-card a8-list" aria-label={L.STATION_LABEL[st]} data-testid="a8-station-view" data-station={st}>
      <h2 className="a8-h2 a81-sth"><StationIcon st={st} boxed />{L.STATION_LABEL[st]} · {queue.length} patient{queue.length === 1 ? '' : 's'}</h2>
      {queue.length === 0 ? <p className="a8-mut" data-testid="a8-station-empty">✓ Nothing waiting at your station.</p> : queue.map(({ c, items }) => { const p = medRepo.patient(c.pid)!;
        return <div key={c.id} className="a84-rowwrap"><button type="button" className="a8-case" onClick={() => openFor(st, c, items.map(i => i.key))} data-testid="a8-station-row" data-case={c.id}>
          <span className="tm">{c.date === day ? hm(c.time) : c.date.slice(5)}</span><span className="min-w-0 flex-1"><span className="nm">{p.name}</span><span className="sub">{c.procedure} · {c.surgeon.replace(/,.*$/, '')} · {c.room}</span>
          <span className="miss" data-testid="a8-missing">{items.map(i => i.label).join(' · ')}</span></span><Stage c={c} /></button><StationChips c={c} /></div>; })}
    </section> : <section className="v7-card a8-list" aria-label="All roles" data-testid="a8-all-view">
      <div className="a8-counts" data-testid="a8-team-counts">{L.STATIONS.map(s => { const n = L.stationQueue(S.cases(), s, day).length; return <span key={s} className={n ? 'on' : ''}><StationIcon st={s} size={12} />{L.STATION_LABEL[s]} <b>{n}</b></span>; })}</div>
      {dayCases.map(c => { const p = medRepo.patient(c.pid)!; return <div key={c.id} className="a84-rowwrap"><button type="button" className="a8-case" onClick={() => openAsc(c.loc === 'scheduled' ? { t: 'details', cid: c.id } : { t: 'record', cid: c.id })} data-testid="a8-all-row">
        <span className="tm">{hm(c.time)}</span><span className="min-w-0 flex-1"><span className="nm">{p.name}</span><span className="sub">{c.procedure} · {c.surgeon.replace(/,.*$/, '')} · {c.room}</span>
          <span className="a8-dots" aria-label="Steps">{L.STEPS.map(s => <i key={s.id} className={L.stepComplete(c, s.id) ? 'ok' : ''} title={s.label} />)}</span></span><Stage c={c} /></button><StationChips c={c} /></div>; })}
      <div className="a8-legend">{L.LOC_ORDER.map(l => <span key={l}><i style={{ background: L.LOC_COLOR[l] }} />{L.LOC_LABEL[l]}</span>)}</div>
    </section>}
  </div>;
};
