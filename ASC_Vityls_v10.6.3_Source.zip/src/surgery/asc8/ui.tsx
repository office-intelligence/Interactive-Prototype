import { NativeRecord } from '../asc10/native103';
import { StationBar106 } from '../asc106/bar106';
import { StationCtx, MoreFields, BeforeSign } from '../asc106/slots106';
import '../asc106/bar106.css';
import { ViewToggle, FullFormFold, StationNotes } from '../asc106/stations106';
import { ClearanceSummary } from '../asc106/clearance106';
import { logPrint } from '../asc86/store86';
import { OrTimes89 } from '../asc89/chart89';
import { BriefOpReport, CaptureUpload, OfficialHistory } from '../asc10/flow10';
import { PaperAnesRecord, AldreteOnce, V10_SHOWN_ELSEWHERE } from '../asc10/fixes10';
import { BankFields } from '../asc10/bank10';
import { ConfirmStation } from '../asc10/station102';
void BankFields; void ConfirmStation;
/* ASC.Vityls v8.0 · station views, the step panel (only what is missing), the Surgeon tab, the op-report page, flags and the case record.
 * Everything opens through one host (Asc8Host, `asc8-open`) over Today or Chat; Save & close returns. PIN only to sign. Fictional data. */
import React, { useEffect, useState } from 'react';
import './asc8.css';
import { medRepo, isoDay, ageFrom, uid, PROVIDER_ROLES } from '../../med/record';
import { useActor, useMedTick } from '../../med/ui';
import { useSv } from '../ui';
import { PinSign } from '../sign';
import { StationIcon } from '../asc81/icons81';
import { JourneyDock, JourneyBar } from '../asc88/journey88';
import type { ShellProps } from '../asc83/frontdesk';
import { FdStationForms } from '../fd/StationForms';
import { CaseDetails, CheckInDialog } from '../asc83/frontdesk';
import { CaseCard, XClose, MedSummary, FormInPlace, WK, stationForms, formTitle } from '../asc82/common';
import * as L from './logic';
import * as S from './store';

export type AscOpen = { t: 'step'; cid: string; station: L.Station } | { t: 'op'; cid: string } | { t: 'flag'; pid?: string; cid?: string } | { t: 'reply'; id: string } | { t: 'record'; cid: string } | { t: 'surgeon'; cid: string; tab?: STab } | { t: 'details'; cid: string; station?: L.Station } | { t: 'checkin'; cid: string };
export const openAsc = (d: AscOpen) => window.dispatchEvent(new CustomEvent('asc8-open', { detail: d }));
const first = (n: string) => n.replace(/,.*$/, '');
const dr = (n: string) => /,\s*MD/.test(n) ? `Dr. ${first(n).split(' ').slice(-1)[0]}` : first(n);
const sexL = (s: string) => s === 'Female' ? 'F' : s === 'Male' ? 'M' : '';
export const Stage: React.FC<{ c: L.AscCase }> = ({ c }) => <span className="a8-stage" style={{ background: L.LOC_COLOR[c.loc] }} data-testid="a8-stage" data-loc={c.loc}>{L.LOC_LABEL[c.loc]}</span>;
/** Open the right thing for a station + case: surgeons get the Surgeon tab (op report flag → the phone page). */
export function openFor(st: L.Station, c: L.AscCase, keys?: string[]) { if (c.loc === 'scheduled' && st !== 'surgeon' && st !== 'anesthesia') { openAsc({ t: 'details', cid: c.id, station: st }); return; } if (st === 'surgeon') { if (keys && keys.length === 1 && keys[0] === 'opReport') openAsc({ t: 'op', cid: c.id }); else openAsc({ t: 'surgeon', cid: c.id }); } else openAsc({ t: 'step', cid: c.id, station: st }); }

/* ---------------- patient header (one line of recorded facts) ---------------- */
export const PatientHead: React.FC<{ c: L.AscCase; onClose: () => void; right?: React.ReactNode }> = ({ c, onClose, right }) => {
  const p = medRepo.patient(c.pid)!; const wt = c.d.vitals?.wt; const facts = L.headerFacts(c, p.allergies, !!c.d.allergy, wt ? Number(wt) : undefined);
  return <header className="a8-head" data-testid="a8-head"><div className="min-w-0"><h2 data-testid="a8-head-name">{p.name} · {ageFrom(p.dob)}{sexL(p.sex)} · {c.procedure} · {dr(c.surgeon)} · {c.room} · {c.time.replace(/^0/, '')}</h2>
    {facts.length > 0 && <div className="f" data-testid="a8-head-facts">{facts.join(' · ')}</div>}</div><div className="r">{right}<XClose onClick={onClose} testId="a8-close" /></div></header>;
};

/* ---------------- allergy cards ---------------- */
export const AllergyCard: React.FC<{ c: L.AscCase }> = ({ c }) => {
  const [actor] = useActor(); const { toast } = useSv(); const p = medRepo.patient(c.pid)!; const [edit, setEdit] = useState(false); const [txt, setTxt] = useState(p.allergies.join('; '));
  const ok = !!c.d.allergy;
  return <div className={`a8-allergy ${p.allergies.length ? 'red' : 'green'}`} data-testid="a8-allergy" data-confirmed={ok ? '1' : '0'}>
    <div className="t">{p.allergies.length ? p.allergies.join(' · ') : 'No known allergies'}</div>
    {edit ? <div className="a8-row"><input className="a8-in" value={txt} onChange={e => setTxt(e.target.value)} placeholder="Allergy (reaction); separate with ;" data-testid="a8-allergy-in" />
      <button type="button" className="a8-btn" onClick={() => { S.editAllergies(c, txt.split(';').map(x => x.trim()).filter(Boolean), actor.name, actor.role); setEdit(false); toast('Allergies updated. Confirm them with the patient.'); }} data-testid="a8-allergy-save">Save</button></div>
      : <div className="a8-row">{ok ? <span className="a8-ok" data-testid="a8-allergy-ok">✓ Confirmed · {first(c.d.allergy.by)}</span> : <button type="button" className="a8-btn green" onClick={() => { S.confirmAllergies(c, actor.name, actor.role); toast('Allergies confirmed.'); }} data-testid="a8-allergy-confirm">Confirm</button>}
        <button type="button" className="a8-btn red" onClick={() => setEdit(true)} data-testid="a8-allergy-edit">Edit</button></div>}
  </div>;
};

/* ---------------- OR event bar (times with edit + audit) ---------------- */
export const EventBar: React.FC<{ c: L.AscCase }> = ({ c }) => {
  const [actor] = useActor(); const { toast } = useSv(); const [ed, setEd] = useState<L.EventKey | null>(null); const [t, setT] = useState(''); const [why, setWhy] = useState('');
  const rec = (k: L.EventKey, time: string, reason = '') => { try { S.recordEvent(S.caseById(c.id)!, k, time, actor.name, actor.role, reason); setEd(null); setWhy(''); } catch (e: any) { toast(e.message); } };
  return <div className="a8-events" data-testid="a8-events">{L.EVENTS.map(e => { const v = c.events[e.key]; return <div key={e.key} className={`ev ${v ? 'on' : ''} ${ed === e.key ? 'ed' : ''}`} data-testid={`a8-ev-${e.key}`}>
    <span className="l">{e.label}</span>{ed === e.key ? <span className="a8-row"><input className="a8-in sm" value={t} onChange={x => setT(x.target.value)} data-testid="a8-ev-time" />{v && <input className="a8-in" value={why} onChange={x => setWhy(x.target.value)} placeholder="Reason for change" data-testid="a8-ev-why" />}<button type="button" className="a8-btn" onClick={() => rec(e.key, t, why)} data-testid="a8-ev-save">Save</button></span>
      : v ? <button type="button" className="v" onClick={() => { setEd(e.key); setT(v); }} title="Edit (logged)" data-testid="a8-ev-edit">{v.replace(/^0/, '')}</button> : <button type="button" className="a8-btn pri" onClick={() => rec(e.key, S.nowTime())} data-testid={`a8-ev-now-${e.key}`}>Now</button>}</div>; })}
    {c.audit.some(a => /changed .* → /.test(a.what)) && <details className="a8-audit" data-testid="a8-ev-audit"><summary>Time changes ({c.audit.filter(a => /changed .* → /.test(a.what)).length})</summary>{c.audit.filter(a => /changed .* → /.test(a.what)).map((a, i) => <div key={i}>{a.what} · {first(a.by)}</div>)}</details>}
  </div>;
};

/* ---------------- one editor per missing item ---------------- */
type Val = Record<string, any>;
const Seg: React.FC<{ opts: string[]; v?: string; on: (x: string) => void; tid: string }> = ({ opts, v, on, tid }) => <span className="a8-seg" role="group">{opts.map(o => <button key={o} type="button" className={v === o ? 'on' : ''} onClick={() => on(o)} data-testid={`${tid}-${o.replace(/\W+/g, '').toLowerCase()}`}>{o}</button>)}</span>;
const Chk: React.FC<{ label: string; v?: boolean; on: (b: boolean) => void; tid: string }> = ({ label, v, on, tid }) => <label className="a8-chk"><input type="checkbox" checked={!!v} onChange={e => on(e.target.checked)} data-testid={tid} /> {label}</label>;
export const ItemEditor: React.FC<{ c: L.AscCase; it: L.Item; f: Val; set: (k: string, v: any) => void; onSign: (it: L.Item) => void; onAct: (k: string) => void }> = ({ c, it, f, set, onSign, onAct }) => {
  const k = it.key; const g = (x: string) => (f[k] || {})[x]; const so = (x: string, v: any) => set(k, { ...(f[k] || {}), [x]: v }); const tid = `a8-f-${k}`;
  const p = medRepo.patient(c.pid)!;
  let body: React.ReactNode = null;
  switch (k) {
    case 'forms': case 'financial': case 'id': case 'counts': case 'criteria': case 'instructions': case 'sitecheck': case 'meds': case 'timeout': case 'consentConfirm': case 'sitemark':
      body = <Chk label={({ forms: 'Registration & insurance, history and anesthesia questionnaires signed by the patient', financial: 'Card authorization & cash fee disclosure signed', id: 'Photo ID and insurance card match the chart', counts: 'Sponge, sharp and instrument counts correct', criteria: 'Discharge criteria met (stable vitals, pain controlled, tolerating fluids, ambulating)', instructions: 'Written instructions given to the patient and responsible adult', sitecheck: 'Surgical site marked by the surgeon and verified', meds: `Medications reviewed${medRepo.meds(c.pid).filter(m => m.status === 'active').length ? ': ' + medRepo.meds(c.pid).filter(m => m.status === 'active').map(m => `${m.name} ${m.dose}`).join(', ') : ' (none)'}`, timeout: 'Time-out done: patient, procedure, site, consent, allergies, antibiotics', consentConfirm: 'Procedure consent signed and matches the booking', sitemark: `Site marked${c.side ? ` (${c.side})` : ''}` } as Record<string, string>)[k]} v={!!f[k]} on={b => set(k, b ? true : undefined)} tid={tid} />; break;
    case 'insurance': body = <input className="a8-in" value={f[k] || ''} onChange={e => set(k, e.target.value)} placeholder="Verified with plan · deposit received" data-testid={tid} />; break;
    case 'clearance': body = <Chk label="Clearance received and reviewed (no open issues)" v={!!f[k]} on={b => set(k, b ? true : undefined)} tid={tid} />; break;
    case 'labs': body = <Chk label="Labs received and reviewed" v={!!f[k]} on={b => set(k, b ? true : undefined)} tid={tid} />; break;
    case 'adult': body = <div className="a8-grid"><label>Name<input className="a8-in" value={g('name') || ''} onChange={e => so('name', e.target.value)} data-testid="a8-f-adult-name" /></label><label>Phone<input className="a8-in" value={g('phone') || ''} onChange={e => so('phone', e.target.value)} data-testid="a8-f-adult-phone" /></label><Chk label="Present" v={g('present')} on={b => so('present', b)} tid="a8-f-adult-present" /></div>; break;
    case 'arrival': body = <span className="a8-row"><input className="a8-in sm" value={f[k] || ''} onChange={e => set(k, e.target.value)} data-testid={tid} /><button type="button" className="a8-btn" onClick={() => set(k, S.nowTime())} data-testid="a8-f-arrival-now">Now</button></span>; break;
    case 'vitals': body = <div className="a8-grid">{[['bp', 'BP'], ['hr', 'HR'], ['rr', 'RR'], ['spo2', 'SpO₂ %'], ['temp', 'Temp °F'], ['wt', 'Weight kg']].map(([x, l]) => <label key={x}>{l}<input className="a8-in" value={g(x) || ''} onChange={e => so(x, e.target.value)} data-testid={`a8-f-vit-${x}`} /></label>)}</div>; break;
    case 'npo': body = <div className="a8-grid"><label>Last solids<input className="a8-in" value={g('solids') || ''} onChange={e => so('solids', e.target.value)} placeholder="10:00 PM" data-testid="a8-f-npo-solids" /></label><label>Last clear liquids<input className="a8-in" value={g('clears') || ''} onChange={e => so('clears', e.target.value)} placeholder="05:00 AM" data-testid="a8-f-npo-clears" /></label></div>; break;
    case 'allergy': body = <AllergyCard c={c} />; break;
    case 'iv': body = <div className="a8-grid"><label>Site<input className="a8-in" value={g('site') || ''} onChange={e => so('site', e.target.value)} data-testid="a8-f-iv-site" /></label><label>Gauge<input className="a8-in" value={g('gauge') || ''} onChange={e => so('gauge', e.target.value)} data-testid="a8-f-iv-gauge" /></label></div>; break;
    case 'asa': body = <Seg opts={['I', 'II', 'III', 'IV']} v={f[k]} on={x => set(k, x)} tid={tid} />; break;
    case 'airway': body = <div className="a8-grid"><label>Mallampati<select className="a8-in" value={g('mallampati') || ''} onChange={e => so('mallampati', e.target.value)} data-testid="a8-f-airway-mall"><option value="">Choose…</option>{['I', 'II', 'III', 'IV'].map(x => <option key={x}>{x}</option>)}</select></label><label>Notes<input className="a8-in" value={g('notes') || ''} onChange={e => so('notes', e.target.value)} data-testid="a8-f-airway-notes" /></label></div>; break;
    case 'plan': body = <span className="a8-row wrap"><Seg opts={['General', 'MAC', 'Regional']} v={g('technique')} on={x => so('technique', x)} tid="a8-f-plan" /><button type="button" className="a8-btn" onClick={() => so('notes', `${g('notes') ? g('notes') + ' ' : ''}[Dictated, simulated] LMA planned; PONV prophylaxis.`)} data-testid="a8-f-plan-dictate">🎙 Dictate</button>{g('notes') && <span className="a8-mut">{g('notes')}</span>}</span>; break;
    case 'events': body = <EventBar c={c} />; break;
    case 'ebl': body = <span className="a8-row"><input className="a8-in sm" inputMode="numeric" value={f[k] ?? ''} onChange={e => set(k, e.target.value)} data-testid={tid} /> mL</span>; break;
    case 'wound': body = <Seg opts={['I · Clean', 'II · Clean-contaminated', 'III · Contaminated', 'IV · Dirty']} v={f[k]} on={x => set(k, x)} tid={tid} />; break;
    case 'implants': case 'specimens': body = <span className="a8-row wrap"><Chk label="None" v={g('none')} on={b => set(k, b ? { none: true } : undefined)} tid={`${tid}-none`} />{!g('none') && <input className="a8-in" value={g('list') || ''} onChange={e => so('list', e.target.value)} placeholder={k === 'implants' ? 'Implant, lot #' : 'Specimen → pathology'} data-testid={`${tid}-list`} />}</span>; break;
    case 'toPacu': body = <button type="button" className="a8-btn pri" onClick={() => onAct('toPacu')} data-testid="a8-to-pacu">Patient to PACU</button>; break;
    case 'aldrete': body = <span className="a8-row"><input className="a8-in sm" inputMode="numeric" value={f[k] ?? ''} onChange={e => set(k, e.target.value)} data-testid={tid} /> of 10 (9 or more to discharge)</span>; break;
    case 'pain': body = <input className="a8-in sm" value={f[k] || ''} onChange={e => set(k, e.target.value)} placeholder="2/10" data-testid={tid} />; break;
    case 'handoff': body = <div className="a8-grid"><label>Handed to<input className="a8-in" value={g('adult') ?? (c.d.adult?.name || '')} onChange={e => so('adult', e.target.value)} data-testid="a8-f-handoff-adult" /></label><Chk label="Responsible adult present" v={g('present') ?? c.d.adult?.present} on={b => so('present', b)} tid="a8-f-handoff-present" /></div>; break;
    case 'charges': { const ch = L.charges(c, S.fees()); body = <div data-testid="a8-charges">{ch.lines.map((l, i) => <div key={i} className="a8-line"><span>{l.what}</span><b>${l.amount.toLocaleString()}</b></div>)}<div className="a8-line tot"><span>Total (fictional)</span><b data-testid="a8-charges-total">${ch.total.toLocaleString()}</b></div><Chk label="Post these charges" v={!!f[k]} on={b => set(k, b ? { total: ch.total, lines: ch.lines } : undefined)} tid={tid} /></div>; break; }
    case 'close': body = <button type="button" className="a8-btn pri" onClick={() => onAct('close')} data-testid="a8-close-case">Close the case</button>; break;
    case 'opReport': body = <button type="button" className="a8-btn pri" onClick={() => onAct('opReport')} data-testid="a8-open-op">Dictate op report</button>; break;
    default: if (it.sign) body = <span className="a8-mut">{it.form ? 'Ready to sign.' : 'Ready to sign.'}</span>;
  }
  return <div className="a8-item" data-testid="a8-item" data-key={k}><div className="lab">{it.label}{it.sign && <button type="button" className="a8-btn" onClick={() => onSign(it)} data-testid={`a8-sign-${k}`}>Sign with PIN</button>}</div>{body}</div>;
};
export const SIGN_ROLES = (it: L.Item): string[] => it.station === 'anesthesia' ? S.ANES_ROLES : it.station === 'surgeon' ? PROVIDER_ROLES : S.NURSE_ROLES;
/** Turn the panel's typed values into case values (signed items are stored separately when signed). */
export function commit(c: L.AscCase, f: Val, by: string, role: string) {
  let x = c; Object.entries(f).forEach(([k, v]) => { if (v === undefined || v === '' || k === 'allergy') return; const it = L.item(k); if (!it || L.isDone(x, k) && JSON.stringify(x.d[k]) === JSON.stringify(v)) return;
    const val = v === true ? { by, at: new Date().toISOString() } : v; x = S.setValue(x, k, val, by, role, `${it.label}: ${typeof v === 'object' ? Object.values(v).filter(z => typeof z === 'string').join(' · ') || 'recorded' : v === true ? 'done' : v}`);
    if (k === 'vitals') { const bp = String(v.bp || '').split('/'); medRepo.addVitals({ id: uid('vit'), patientId: c.pid, visitId: c.visitId, at: new Date().toISOString(), by, source: 'manual', bpSys: +bp[0] || undefined, bpDia: +bp[1] || undefined, hr: +v.hr || undefined, rr: +v.rr || undefined, spo2: +v.spo2 || undefined, tempF: +v.temp || undefined } as any); } });
  return x;
}

/* ---------------- the step panel: one station, one case, only what's missing ---------------- */
export const StepPanel: React.FC<{ cid: string; station: L.Station; onClose: () => void }> = ({ cid, station, onClose }) => {
  useMedTick(); const [actor] = useActor(); const { toast } = useSv(); const c = S.caseById(cid); const [f, setF] = useState<Val>({}); const [sign, setSign] = useState<L.Item | null>(null); const [formOpen, setFormOpen] = useState('');
  if (!c) return null; const T = isoDay();
  const its = L.ITEMS.filter(i => i.station === station && L.actionable(c, i, T) && !V10_SHOWN_ELSEWHERE.includes(i.key)); const open = its.filter(i => !L.isDone(c, i.key)); const done = its.filter(i => L.isDone(c, i.key));
  const set = (k: string, v: any) => setF(x => ({ ...x, [k]: v }));
  const saveClose = () => { const n = Object.keys(f).length; if (n) commit(c, f, actor.name, actor.role); if (n) toast('Saved.'); onClose(); };
  const act = (k: string) => { try { const cur = commit(S.caseById(cid)!, f, actor.name, actor.role); setF({});
    if (k === 'toPacu') { S.toPacu(cur, actor.name, actor.role); toast(`Patient to PACU. ${dr(c.surgeon)} was flagged to dictate the op report.`); }
    if (k === 'close') { S.move(cur, 'closed', actor.name, actor.role); toast('Case closed.'); onClose(); }
    if (k === 'opReport') { onClose(); openAsc({ t: 'op', cid }); } } catch (e: any) { toast(e.message); } };
  const title = L.STATION_LABEL[station];
  const sf = station === 'billing' ? [] : stationForms(c, station); const files = Array.from(new Set([...sf.map(x => x.file), ...its.map(i => i.form || '')]));
  const groups = files.map(file => { const x = sf.find(y => y.file === file); return { file, title: file ? formTitle(file) : '', req: !!x?.required || its.some(i => i.form === file && i.req), status: x?.status || '', filled: x?.filled || 0 }; })
    .filter(g => g.file === '' ? its.some(i => !i.form) : true).sort((a, b) => (a.file === '' ? -1 : 0) - (b.file === '' ? -1 : 0));
  return <><div className="a8-scrim" onClick={saveClose} />
    <section className="a8-panel" role="dialog" aria-modal="true" aria-label={title} data-testid="a8-step" data-station={station}>
      <div className="a81-dhead v106-stephead"><b>{title}</b><span style={{ marginLeft: 'auto' }} /><ViewToggle /><CaptureUpload c={c} station={title} /><XClose onClick={saveClose} testId="a8-close" /></div>
      <JourneyBar c={c} here={station === 'or' ? 'or' : undefined} onLeave={saveClose} />
      <div className="a82-dcase"><CaseCard c={c} station={station} /></div><StationBar106 key={'b6' + c.id} c={c} bench={station === 'preop' ? 'nursing' : station} />
      <div className="a8-body"><div className="a81-stephead"><span className="a81-sttag" data-testid="a81-station-tag">Station {({ front: 2, preop: 3, anesthesia: 4, surgeon: 5, or: 5, pacu: 6, billing: 7 } as Record<string, number>)[station]} · {title}</span><span className={`a81-progress ${open.length ? '' : 'done'}`} data-testid="a81-progress">{done.length} of {its.length} complete</span></div><h3 data-testid="a8-step-title" className="a81-sth"><StationIcon st={station} boxed size={18} />{title} — {open.length ? `${open.length} item${open.length === 1 ? '' : 's'} left` : 'complete'}</h3>
        {formOpen ? <><button type="button" className="a8-link" onClick={() => setFormOpen('')} data-testid="a82-back-to-station">← Back to the station list</button><FormInPlace inline c={c} file={formOpen} station={WK[station]} onClose={() => setFormOpen('')} /></> : <>
        {station === 'or' && <FullFormFold title="Intra-operative nursing record & time-out log"><NativeRecord c={c} file="IntraOp_Nursing_Record_TO.html" station="orTeam" /></FullFormFold>}{station === 'pacu' && <FullFormFold title="PACU progress & recovery record"><NativeRecord c={c} file="PACU_Recovery_Record.html" station="pacu" /></FullFormFold>}{station === 'or' && <OrTimes89 c={c} />}{station === 'or' && <BriefOpReport c={c} />}{station === 'or' && <PaperAnesRecord c={c} />}{station === 'pacu' && <AldreteOnce c={c} />}{(station === 'anesthesia' || station === 'surgeon') && <OfficialHistory c={c} />}{(['preop', 'anesthesia', 'surgeon', 'pacu'] as string[]).includes(station) && <ClearanceSummary c={c} station={station} />}
        
        {groups.map(g => { const gi = its.filter(i => (i.form || '') === g.file); const go = gi.filter(i => !L.isDone(c, i.key)); const gd = gi.filter(i => L.isDone(c, i.key));
          return <div key={g.file || 'items'} className="a82-fcard" data-testid="a82-station-form" data-file={g.file}><div className="h"><b>{g.file ? g.title : 'Station checklist'}</b>{g.req && <span className="a81-chip">Required</span>}<span className="a82-sum" data-testid="a82-form-summary">{gi.length ? `${gd.length} of ${gi.length} done` : ''}{g.file && g.filled ? `${gi.length ? ' · ' : ''}${g.filled} field${g.filled === 1 ? '' : 's'} on file` : ''}{g.file && g.status ? ` · ${g.status}` : ''}</span>{g.file && <button type="button" className="a8-btn" onClick={() => setFormOpen(g.file)} data-testid="a82-open-form">Open</button>}</div>
            {gd.length > 0 && <p className="a8-done">✓ Collected: {gd.map(i => i.label).join(' · ')}</p>}
            {go.map(it => <ItemEditor key={it.key} c={c} it={it} f={f} set={set} onSign={x => setSign(x)} onAct={act} />)}
            {!gi.length && g.file && <p className="a8-mut sv-small">{g.filled ? 'Collected before the day of surgery.' : 'Nothing collected yet. Open to fill in.'}</p>}</div>; })}
        <StationCtx.Provider value={{ c, bench: station === 'preop' ? 'nursing' : station }}><MoreFields start={groups.length + 1} />
        {station === 'or' && <StationNotes c={c} station="OR" />}{station === 'pacu' && <StationNotes c={c} station="PACU" />}{station === 'preop' && <StationNotes c={c} station="Pre-op nursing" />}
        <BeforeSign /></StationCtx.Provider>
        </>}
      </div>
      <footer className="a8-foot"><button type="button" className="a8-link" onClick={() => { saveClose(); openAsc({ t: 'flag', pid: c.pid, cid }); }} data-testid="a8-flag-from-step">⚑ Flag a team</button>
        <button type="button" className="a8-btn pri" onClick={saveClose} data-testid="a8-save">Save &amp; close</button></footer>
      {sign && <PinSign title={`Sign · ${sign.label}`} statement={<>I completed and reviewed “{sign.label}” for {medRepo.patient(c.pid)?.name}. Nightingale does not sign.</>} roles={SIGN_ROLES(sign)} onClose={() => setSign(null)}
        onSigned={s => { const cur = commit(S.caseById(cid)!, f, actor.name, actor.role); setF({}); const v = sign.key === 'handoff' ? { ...(f.handoff || {}), adult: f.handoff?.adult ?? cur.d.adult?.name, by: s.name, signedAt: s.at, at: s.at } : { by: s.name, at: s.at, signed: true };
          S.setValue(cur, sign.key, v, s.name, s.role, `${sign.label} signed with PIN by ${s.name}`); setSign(null); toast(`✓ ${sign.label} signed by ${first(s.name)}.`); }} confirmLabel="Sign" />}
    </section></>;
};

/* ---------------- Surgeon tab (Surgery Doctor workspace without body chart / photos) ---------------- */
type STab = 'signoffs' | 'note' | 'forms';
export const SurgeonTab: React.FC<{ cid: string; tab?: STab; onClose: () => void }> = ({ cid, tab: t0, onClose }) => {
  useMedTick(); const [actor] = useActor(); const { toast } = useSv(); const c = S.caseById(cid); const [tab, setTab] = useState<STab>(t0 || 'signoffs'); const [jot, setJot] = useState('');
  if (!c) return null; const p = medRepo.patient(c.pid)!; const T = isoDay(); const v = medRepo.visit(c.visitId);
  const mine = L.ITEMS.filter(i => i.station === 'surgeon'); const open = mine.filter(i => L.actionable(c, i, T) && !L.isDone(c, i.key));
  const meds = medRepo.meds(p.id).filter(m => m.status === 'active'); const probs = medRepo.problems(p.id).filter(x => x.status === 'active');
  const addJot = (voice: boolean) => { const text = voice ? `Dictated jot (simulated): ${jot || 'findings as expected'}` : jot.trim(); if (!text) return; S.setValue(c, 'jots', [...(c.d.jots || []), text], actor.name, actor.role, `Surgeon jot${voice ? ' (dictated, simulated)' : ''}`); setJot(''); toast('Jot saved to this case.'); };
  return <><div className="a8-scrim" onClick={onClose} />
    <section className="a8-panel full" role="dialog" aria-modal="true" aria-label="Surgeon" data-testid="a8-surgeon">
      <PatientHead c={c} onClose={onClose} right={<button type="button" className="a8-btn pri" onClick={onClose} data-testid="a8-save">Save &amp; close</button>} />
      <div className="a8-doc">
        <div className="main">
          <div className="a8-row" style={{ padding: '10px 20px 0' }} data-testid="a8-quickjot"><input className="a8-in" value={jot} onChange={e => setJot(e.target.value)} placeholder="Quick jot for the op report…" data-testid="a8-jot-in" /><button type="button" className="a8-btn" onClick={() => addJot(false)} disabled={!jot.trim()} data-testid="a8-jot-add">Jot</button><button type="button" className="a8-btn" onClick={() => addJot(true)} aria-label="Voice jot (simulated)">🎙</button></div>
          <nav className="a8-tabs" role="tablist" data-testid="a8-surgeon-tabs">{([['signoffs', `Sign-offs${open.length ? ` (${open.length})` : ' ✓'}`], ['note', 'Op report & dictation'], ['forms', 'Forms']] as [STab, string][]).map(([k, l]) => <button key={k} type="button" role="tab" aria-selected={tab === k} className={tab === k ? 'on' : ''} onClick={() => setTab(k)} data-testid={`a8-stab-${k}`}>{l}</button>)}</nav>
          <div className="pane" data-testid={`a8-spane-${tab}`}>
            {tab === 'signoffs' && <SurgeonSignoffs c={c} />}
            {tab === 'note' && <div><p className="a8-mut">The op report opens on the note page (phone friendly). Nightingale drafts it from the case; you edit and sign with your PIN.</p>
              {c.d.opReport?.signedAt ? <p className="a8-ok" data-testid="a8-op-signed">✓ Op report signed · {first(c.d.opReport.signedBy)} · copy: {c.d.opReport.copy === 'surgery-vityls' ? 'Surgery.Vityls' : 'secure link email'}</p> : null}
              <button type="button" className="a8-btn pri" onClick={() => { onClose(); openAsc({ t: 'op', cid }); }} disabled={!L.atLeast(c.loc, 'or')} data-testid="a8-surgeon-op">{c.d.opReport?.signedAt ? 'View op report' : 'Open op report'}</button>{!L.atLeast(c.loc, 'or') && <span className="a8-mut"> Available once the case is in the OR.</span>}</div>}
            {tab === 'forms' && v && <FdStationForms v={v} station="surgeon" step="surgeon" />}
          </div>
        </div>
        <aside className="a8-rail" aria-label="Nightingale" data-testid="a8-surgeon-rail"><h4>Nightingale</h4><div className="bub">{open.length ? <>Next: <b>{open[0].label}</b>.</> : 'Nothing waiting for you on this case.'}</div>
          <h4>Allergies</h4><div>{p.allergies.length ? p.allergies.join(', ') : 'No known allergies'}{c.d.allergy ? ' · confirmed' : ''}</div>
          {meds.length > 0 && <><h4>Medications</h4>{meds.map(m => <div key={m.id}>{m.name} {m.dose} {m.frequency}</div>)}</>}
          {probs.length > 0 && <><h4>Problems</h4>{probs.map(x => <div key={x.id}>{x.description}</div>)}</>}
          {c.d.vitals?.bp && <><h4>Vitals</h4><div>BP {c.d.vitals.bp} · HR {c.d.vitals.hr}{c.d.vitals.spo2 ? ` · SpO₂ ${c.d.vitals.spo2}%` : ''}</div></>}
          {(c.d.jots || []).length > 0 && <><h4>Your jots</h4>{c.d.jots.map((j: string, i: number) => <div key={i}>{j}</div>)}</>}
        </aside>
      </div>
    </section></>;
};
const SurgeonSignoffs: React.FC<{ c: L.AscCase }> = ({ c }) => {
  const [actor] = useActor(); const { toast } = useSv(); const [sign, setSign] = useState<L.Item | null>(null); const [f, setF] = useState<Val>({}); const T = isoDay();
  const mine = L.ITEMS.filter(i => i.station === 'surgeon' && L.actionable(c, i, T)); const open = mine.filter(i => !L.isDone(c, i.key)); const done = mine.filter(i => L.isDone(c, i.key));
  const save = () => { if (Object.keys(f).length) { commit(c, f, actor.name, actor.role); setF({}); toast('Saved.'); } };
  return <div>{open.length === 0 && <p className="a8-ok" data-testid="a8-signoffs-none">✓ Nothing waiting for you on this case.</p>}
    {open.map(it => <ItemEditor key={it.key} c={c} it={it} f={f} set={(k, v) => setF(x => ({ ...x, [k]: v }))} onSign={x => setSign(x)} onAct={k => { if (k === 'opReport') openAsc({ t: 'op', cid: c.id }); }} />)}
    {Object.keys(f).length > 0 && <button type="button" className="a8-btn" onClick={save} data-testid="a8-signoffs-save">Save</button>}
    {done.length > 0 && <p className="a8-done">✓ Done: {done.map(i => i.label).join(' · ')}</p>}
    {sign && <PinSign title={`Sign · ${sign.label}`} statement={<>I reviewed “{sign.label}”. Nightingale does not sign.</>} roles={PROVIDER_ROLES} allow={p => p.name === c.surgeon} onClose={() => setSign(null)} onSigned={s => { S.setValue(S.caseById(c.id)!, sign.key, { by: s.name, at: s.at, signed: true }, s.name, s.role, `${sign.label} signed with PIN by ${s.name}`); setSign(null); toast(`✓ ${sign.label} signed.`); }} confirmLabel="Sign" />}
  </div>;
};

/* ---------------- op report: note page, type "Op report", phone friendly ---------------- */
export const OpReportPage: React.FC<{ cid: string; onClose: () => void }> = ({ cid, onClose }) => {
  useMedTick(); const [actor] = useActor(); const { toast } = useSv(); const c = S.caseById(cid)!; const p = medRepo.patient(c.pid)!;
  const ex = c.d.opReport; const signed = !!ex?.signedAt; const [text, setText] = useState<string>(() => ex?.text || L.draftOpReport(S.opCtx(c))); const [drafted, setDrafted] = useState(!ex?.text); const [pin, setPin] = useState(false);
  const saveClose = () => { if (!signed) S.saveOpReport(S.caseById(cid)!, text, actor.name, actor.role); toast(signed ? 'Op report closed.' : 'Op report saved as a draft. The flag stays until you sign.'); onClose(); };
  const copy = signed ? S.outbox().filter(o => o.caseId === cid).slice(-1)[0] : undefined;
  return <><div className="a8-scrim" onClick={saveClose} />
    <section className="a8-panel full a8-op" role="dialog" aria-modal="true" aria-label={`Op report · ${p.name}`} data-testid="a8-op">
      <PatientHead c={c} onClose={saveClose} right={<>{signed ? <span className="a8-ok" data-testid="a8-op-signed-badge">✓ Signed · {first(ex.signedBy)}</span> : <button type="button" className="a8-btn" onClick={() => setPin(true)} disabled={!text.trim()} data-testid="a8-op-sign">Sign with PIN</button>}<button type="button" className="a8-btn pri" onClick={saveClose} data-testid="a8-op-save">Save &amp; close</button></>} />
      <div className="a8-opbar">{!signed && <><button type="button" className="a8-btn" onClick={() => { setText(t => t.replace('DESCRIPTION OF PROCEDURE\n[surgeon to complete]', 'DESCRIPTION OF PROCEDURE\n[Dictated, simulated] The patient was placed supine; after induction the site was prepped and draped. The procedure was performed as planned without complication.')); setDrafted(false); toast('Simulated dictation: nothing was recorded. Sample text was added for you to edit.'); }} data-testid="a8-op-dictate">🎙 Dictate</button>
        <button type="button" className="a8-btn" onClick={() => { setText(L.draftOpReport(S.opCtx(S.caseById(cid)!))); setDrafted(true); }} data-testid="a8-op-redraft">Re-draft from case</button></>}
        {drafted && !signed && <span className="a8-draft" data-testid="a8-op-draft">Nightingale draft · review and edit before signing</span>}
        {copy && <span className="a8-ok" data-testid="a8-op-copy">{copy.via === 'surgery-vityls' ? 'Copy filed to your Surgery.Vityls' : `Secure link emailed to ${copy.to} (no patient details)`}</span>}</div>
      <textarea className="a8-optext" value={text} readOnly={signed} onChange={e => { setText(e.target.value); setDrafted(false); }} aria-label="Op report" data-testid="a8-op-text" />
      {pin && <PinSign title="Sign op report" statement={<>I reviewed and edited this operative report for {p.name}. Nightingale drafted it; it does not sign. It files to the ASC chart{c.surgeonOnSurgeryVityls ? ' and a copy goes to your Surgery.Vityls' : '; a secure link (no patient details) is emailed to you'}.</>} roles={PROVIDER_ROLES} allow={x => x.name === c.surgeon} onClose={() => setPin(false)}
        onSigned={s => { S.saveOpReport(S.caseById(cid)!, text, actor.name, actor.role, { name: s.name, at: s.at, email: `${first(s.name).split(' ')[1]?.toLowerCase() || 'surgeon'}@example.test` }); setPin(false); toast(`✓ Op report signed by ${first(s.name)} and filed to the ASC chart.`); }} confirmLabel="Sign op report" />}
    </section></>;
};

/* ---------------- flags ---------------- */
const Panel: React.FC<{ title: string; sub?: string; onClose: () => void; save?: () => boolean | void; saveLabel?: string; testId: string; children: React.ReactNode }> = ({ title, sub, onClose, save, saveLabel = 'Save & close', testId, children }) =>
  <><div className="a8-scrim" onClick={onClose} /><aside className="a8-side" role="dialog" aria-modal="true" aria-label={title} data-testid="a8-side" data-panel={testId}>
    <header><h2>{title}</h2>{sub && <div className="a8-mut">{sub}</div>}</header><div className="b">{children}</div>
    <footer><button type="button" className="a8-btn pri" onClick={() => { if (save && save() === false) return; onClose(); }} data-testid="a8-side-save">{save ? saveLabel : 'Close'}</button></footer></aside></>;
export const FlagDialog: React.FC<{ pid?: string; cid?: string; onClose: () => void }> = ({ pid, cid, onClose }) => {
  const [actor] = useActor(); const { toast } = useSv(); const mine = L.teamsOf(actor.role); const [to, setTo] = useState<L.Team>(mine.includes('front') ? 'preop' : 'front'); const [who, setWho] = useState(pid || ''); const [text, setText] = useState('');
  return <Panel testId="flag-new" title="Flag a team" sub="Goes to everyone on that team; the reply comes back to your to-do." onClose={onClose} saveLabel="Send flag" save={() => { if (!text.trim()) { toast('Write what is needed.'); return false; } S.raiseFlag({ from: actor.name, fromRole: actor.role, to, pid: who || undefined, caseId: cid || (who ? S.caseOfPatient(who)?.id : undefined), text: text.trim() }); toast(`Flag sent to ${L.TEAM_LABEL[to]}.`); }}>
    <span className="a8-seg wrap" role="group" aria-label="To">{L.TEAMS.map(r => <button key={r} type="button" className={to === r ? 'on' : ''} onClick={() => setTo(r)} data-testid={`a8-flag-to-${r}`}>{L.TEAM_LABEL[r]}</button>)}</span>
    <label>Patient (optional)<select className="a8-in" value={who} onChange={e => setWho(e.target.value)} data-testid="a8-flag-patient"><option value="">— none —</option>{S.cases().map(c => <option key={c.id} value={c.pid}>{medRepo.patient(c.pid)?.name} · {c.procedure}</option>)}</select></label>
    <label>What is needed<textarea className="a8-in" rows={3} value={text} onChange={e => setText(e.target.value)} placeholder="Please confirm the escort’s phone number." data-testid="a8-flag-text" /></label></Panel>;
};
const FlagReply: React.FC<{ id: string; onClose: () => void }> = ({ id, onClose }) => {
  const [actor] = useActor(); const { toast } = useSv(); const f = S.flagsAll().find(x => x.id === id); const [r, setR] = useState(''); if (!f) return null; const nm = f.pid ? medRepo.patient(f.pid)?.name : 'Practice';
  if (f.status === 'answered') return <Panel testId="flag-answer" title="Flag answered" sub={nm} onClose={onClose} saveLabel="Got it" save={() => { S.ackFlag(f.id); }}><p>You asked {L.TEAM_LABEL[f.to]}: “{f.text}”</p><p data-testid="a8-flag-answer"><b>{first(f.repliedBy || '')}:</b> {f.reply}</p></Panel>;
  return <Panel testId="flag-reply" title="Flag" sub={`${nm} · from ${first(f.from)}`} onClose={onClose} saveLabel="Mark done & reply" save={() => { S.replyFlag(f.id, r, actor.name); toast(`Reply sent back to ${first(f.from)}.`); }}>
    <p style={{ fontSize: 15 }} data-testid="a8-flag-q">“{f.text}”</p><label>Reply (goes back to {first(f.from)})<textarea className="a8-in" rows={3} value={r} onChange={e => setR(e.target.value)} data-testid="a8-flag-reply" /></label></Panel>;
};

/* ---------------- case record (read-only, print, audit) ---------------- */
export const CaseRecord: React.FC<{ cid: string; onClose: () => void }> = ({ cid, onClose }) => {
  useMedTick(); const [actor] = useActor(); const c = S.caseById(cid); if (!c) return null;
  return <><div className="a8-scrim" onClick={onClose} /><section className="a8-panel" role="dialog" aria-modal="true" aria-label="Case record" data-testid="a8-record">
    <PatientHead c={c} onClose={onClose} right={<button type="button" className="a8-btn" onClick={() => { logPrint(c.id, actor.name, actor.role, 'Case record'); window.print(); }} data-testid="a8-record-print">Print</button>} />
    <div className="a8-body"><div className="a8-steps" data-testid="a8-record-steps">{L.STEPS.map(s => { const ok = L.stepComplete(c, s.id); const miss = L.itemsOf(s.id).filter(i => !L.isDone(c, i.key)); return <div key={s.id} className={`s ${ok ? 'ok' : ''}`}><b>{s.n}. {s.label}</b><span>{ok ? '✓ Complete' : `${miss.length} open: ${miss.map(i => i.label).join(', ')}`}</span></div>; })}</div>
      {Object.keys(c.events).length > 0 && <p className="a8-mut">Times: {L.EVENTS.filter(e => c.events[e.key]).map(e => `${e.label} ${c.events[e.key]}`).join(' · ')}{c.events.pacuIn ? ` · PACU ${c.events.pacuIn}` : ''}</p>}
      <details className="a8-audit" data-testid="a8-record-audit"><summary>Audit ({c.audit.length})</summary>{c.audit.slice().reverse().map((a, i) => <div key={i}>{new Date(a.at).toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' })} · {first(a.by)} · {a.what}</div>)}</details></div>
  </section></>;
};

/** v10.5 · a screen that fails to render shows a message instead of blanking the whole app. */
export class ScreenBoundary extends React.Component<{ children: React.ReactNode; name: string }, { err: string }> {
  state = { err: '' };
  static getDerivedStateFromError(e: any) { return { err: String(e?.message || e).slice(0, 200) }; }
  componentDidCatch(e: any) { try { console.error('Screen error', (this as any).props.name, e); } catch { /* ignore */ } }
  render() { return this.state.err ? <div className="a81-modal" data-testid="v105-screen-error"><div className="a81-dialog" role="alertdialog" style={{ maxWidth: 460, height: 'auto', padding: 20 }}><b>This screen could not open.</b><p className="sv-small" style={{ margin: '8px 0 14px' }}>Nothing was lost. The error was logged for support.</p><button type="button" className="a8-btn pri" onClick={() => { (this as any).setState({ err: '' }); window.dispatchEvent(new CustomEvent('asc8-open', { detail: null })); }}>Close</button></div></div> : (this as any).props.children; }
}
export const Asc8Host: React.FC = () => <ScreenBoundary name="asc8"><Asc8HostInner /></ScreenBoundary>;
const Asc8HostInner: React.FC = () => {
  const [o, setO] = useState<AscOpen | null>(null);
  useEffect(() => { const h = (e: Event) => setO((e as CustomEvent).detail); window.addEventListener('asc8-open', h); return () => window.removeEventListener('asc8-open', h); }, []);
  useEffect(() => { if (!o) return; const k = (e: KeyboardEvent) => { if (e.key === 'Escape' && !document.querySelector('[data-testid=pin-sign]')) setO(null); }; window.addEventListener('keydown', k); return () => window.removeEventListener('keydown', k); }, [o]);
  if (!o) return null; const close = () => setO(null);
  if (o.t === 'step') return <StepPanel key={o.cid + o.station} cid={o.cid} station={o.station} onClose={close} />;
  if (o.t === 'op') return <OpReportPage key={o.cid} cid={o.cid} onClose={close} />;
  if (o.t === 'surgeon') return <><SurgeonTab key={o.cid} cid={o.cid} tab={o.tab} onClose={close} /><JourneyDock cid={o.cid} here={'surgeon'} onLeave={close} /></>;
  if (o.t === 'details') { const cid = o.cid; const Shell: React.FC<ShellProps> = p => <BookingShell cid={cid} {...p} />; return <CaseDetails key={o.cid} cid={o.cid} Shell={Shell} onClose={close} onCheckIn={() => setO({ t: 'checkin', cid: o.cid })} onStation={o.station && o.station !== 'front' ? () => setO({ t: 'step', cid: o.cid, station: o.station! }) : undefined} />; }
  if (o.t === 'checkin') return <CheckInDialog key={o.cid} cid={o.cid} onClose={close} />;
  if (o.t === 'record') return <CaseRecord key={o.cid} cid={o.cid} onClose={close} />;
  if (o.t === 'reply') return <FlagReply key={o.id} id={o.id} onClose={close} />;
  return <FlagDialog pid={o.pid} cid={o.cid} onClose={close} />;
};

/** v10.6.2 · Booking (case details) opens in the same station frame as every other step: header, journey, patient, body, actions. */
const BookingShell: React.FC<ShellProps & { cid: string }> = ({ cid, onClose, children, foot, testId }) => { const c = S.caseById(cid); if (!c) return null; const T = new Date().toISOString().slice(0, 10);
  return <div className="a81-modal" onMouseDown={e => { if (e.target === e.currentTarget) onClose(); }}><div className="a81-dialog" role="dialog" aria-label="Booking" data-testid="a81-bench-booking">
    <div className="a81-dhead"><b>Booking</b><span className={`v10-chip ${c.date === T ? 'ok' : 'warn'}`}>{c.date === T ? 'Today' : 'Not today'} · {new Date(c.date + 'T12:00').toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' })}</span><span style={{ marginLeft: 'auto' }} /><CaptureUpload c={c} station="Booking" /><XClose onClick={onClose} testId={`${testId}-close`} /></div>
    <JourneyBar c={c} here="booking" onLeave={onClose} />
    <div className="a81-dbody v106-dbody v106-booking" data-testid={testId}>{children}{foot && <div className="a81-foot v106-bkfoot">{foot}</div>}</div>
  </div></div>; };
