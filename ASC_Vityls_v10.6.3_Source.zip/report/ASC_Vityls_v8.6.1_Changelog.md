# ASC Vityls v8.6.1 · Changelog (branch asc-v8.6.1 from asc-v8.6)

Kevin approved this change.
- **Anesthesia bench:** removed the old free-text PACU orders box and its "Sign PACU orders" button. Section 4 is now titled "Consent" instead of "Consent & post-op orders". Everything else on the Anesthesia bench is unchanged: airway, ASA and exam, type and technique, anesthesia consent, and pre-induction re-evaluation.
- **PACU orders** now live only in the structured Orders section (PACU tab, anesthesia signer).
- **Legacy data stays readable.** If a case has old free-text PACU orders, the Orders › PACU tab shows them read-only in a "Legacy free-text PACU orders" panel, with the original signer and time. That data is not migrated, edited or deleted. Older PACU task ticks and the audit pack still read it.

## Tests
- tsc: 68 errors, the same as the baseline, with no new ones. Unit tests: 172/172.
- `python3 scripts/walk86.py URL 1440 390` → **40/40**. The new check confirms the free-text box is gone and that the consent and pre-induction sections are still present.
