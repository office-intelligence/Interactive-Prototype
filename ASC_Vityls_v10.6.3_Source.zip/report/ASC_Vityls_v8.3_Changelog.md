# ASC.Vityls v8.3 — Changelog (branch asc-v8.3, from asc-v8.2)
All data fictional. External services simulated. PIN only for signing. No automatic PDF. Anesthesia workbench unchanged.

## Scheduler
- **Add appointment → Surgical case booking popup** (v7.5-style, rebuilt on the ASC case model): DOS, start, length, OR; patient search (2+ letters) or new patient (name, DOB, phone, sex); procedure, surgeon, anesthesiologist, anesthesia type, payment type, assistant, notes; clash warning. Booking creates patient (if new) + visit + ASC case.
- **Block time popup** (v7.5-style): assigned to (surgeon list or custom), rooms (all / selected), time window, days of week, repeat weeks, purpose/notes, "Total blocks to generate".
- **Intake "Confirm & create"** opens the booking popup prefilled (patient no longer created until you book).
- **Cases colored by surgeon**: tint + colored left border; editable surgeon color legend (audited).

## Today
- White page (no gray background).
- Clicking a scheduled patient opens **Case details** (name, age, gender, procedure, surgeon, time, room, allergies, payment status). Buttons: **Check in** (primary), **Open chart**, small **Cancel case** link → confirmation with reason (+ note); cancelled cases are archived and shown in the chart.
- **Check-in flow** (6 steps with progress chips): identity (2 identifiers) → ID/insurance capture if missing → responsible adult → front-desk forms (old station checklist, forms open full screen) → balance (collect now or manager-approved later) → arrival time "Now" → **"✓ Checked in · handed to nursing"**; board pill becomes *Checked in*, pre-op nursing flagged. Arrival workbench uses the same flow.
- **Collect before surgery** card on the Front desk / Billing Today: cases 7–14 days out with unpaid/partial balance, badge count, inline Collect.

## Payments
- Case balance model (fictional estimate: self-pay 100% of quote/fee, insurance 20%); pay status paid/partial/unpaid; payments per case (receipt, method, who, when) mirrored to the patient ledger.
- Billing → **Unpaid cases** tab: search + filter (all / due now 7–14 d / unpaid / partial), inline Collect.

## Forms
- Every form opened from a station, workbench, check-in or chart opens **full screen**; close with the X. PACU Recovery Record opens full screen by default; X reveals the PACU tasks (reopen button).

## Surgeon workbench
- Always-visible links: **Open surgical consent document**, **Open interval H&P document**.
- **Hold-to-talk** mic (simulated scribe) for the brief op report.
- **Full operative report** (14 standard sections) with per-section and whole-report hold-to-talk, Save draft, status Pending / Dictated / Signed, drawn signature + PIN, filed under the case Documents. Mobile-ready API contract (see Henry doc).

## Nursing admission
- New item: **GLP-1 medications held as instructed (or not taking)**.
- Discharge planning: plan select (Home / Post-op recovery facility / Aftercare hotel or nurse); **recovery facility name** shown when not home (required to finish).

## Patient chart (ASC)
- New ASC chart: header (age, sex, DOB, MRN, allergies, meds, payment, contact), **Cases** (upcoming, previous with date of service, cancelled).
- Tabs: **Overview**, **Documents**, **Billing & payments**. Removed: clinical record, photos & charts, notes, timelines, problems, risk factors, diagnoses, journey to-do.
- Documents organized by date of service in 9 groups (incoming records/clearances, ASC forms, consents, signed station documents incl. drawn signatures, operative report(s), PACU & discharge, ID/insurance cards, payments & receipts, audit trail). View each; **Print all for this date** / **Export all (.txt)** — manual only.

## Tests
- Unit 152/152 (7 new v8.3 tests). Walkthrough scripts/walk83.py 162/162 (54 × 1440/1024/390). tsc at baseline (68 pre-existing).
