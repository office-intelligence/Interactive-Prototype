# Vityls Patient Portal v0.3: changelog (2026-10-14)

Branch `portal`, tag `portal-v0.3` (from portal-v0.2). Test build: `Vityls_Patient_Portal_v0.3.zip` (`index.html` opens the Portal; `?practice=coastline` opens the practice side, as in v0.2).

## New: Doctor Finder
- **Search:** name, specialty (NUCC taxonomy), practice/organization, city/state/ZIP.
- **Nightingale chips and free text:** for example "Find a cardiologist near 90210", "Dermatologists in Beverly Hills", "find a dermatologist in Los Angeles". Specialty words and ZIP/city are parsed into the form.
- **Filters:** gender, credential, NPI age (10+/15+ yrs), On Vityls only. **Sort:** last name, first name, NPI date oldest/newest, ZIP. **Pagination:** 10 per page.
- **Cards:** name and credentials, primary specialty, address, phone, fax, NPI, and "NPI since YYYY (approx. N yrs)". Years are estimated from the enumeration date and labeled, because NPI doesn't record years in practice. A **detail view** shows all taxonomies, the NPI record update date and a link to the NPPES page.
- **Vityls badge** (fictional test practices only: Coastline/Sam Patel, Bayview/Dana Kim): **Connect** (patient-initiated consent, logged), **Message**, **Request appointment**.
- **Not on Vityls:** **Add to my care team** (listed under "Other providers" with the NPI), **Send records request** (opens the v0.1 request prefilled with name, NPI and fax), **Send upload link** (prefilled office name).
- **Guests** search freely. Saving or sending opens "create a free account" (the v0.2 guest flow).
- **Neutral by rule:** no ranking or "best"/"recommended" language. A test asserts it.

## Data source and modes
- **Live NPPES doesn't work from a browser.** The API returns no `Access-Control-Allow-Origin` header. Confirmed with curl headers and by a live attempt in Chrome from the packaged file.
- The adapter (`src/portal/finder.ts`) has two modes, and the mode label is always visible:
  - **Bundled snapshot** (default): **666 real public NPI-1 records** from 24 API queries (Beverly Hills and Los Angeles, CA × 12 specialties), fetched with curl on 2026-10-14 (`scripts/fetch_npi_snapshot.py`, `src/portal/npi_snapshot.json`).
  - **Live:** calls a configurable proxy (`vityls:portal:finder-proxy` in storage; Henry's `/api/providers`). Without the proxy it tries NPPES directly, reports the CORS block and falls back to the snapshot.
- The snapshot is a point-in-time copy. Phone, fax and address may have changed since. In the snapshot, "near ZIP" means the same 3-digit ZIP area.

## Fixes
- The Portal's hub sync now reads the freshly stored account before importing practice results. This fixes an intermittent duplicate import seen once in the v0.2 suite.
- Null fields in NPI records (e.g. missing credential) are normalized.

## Tests (2026-10-14)
| Suite | Result |
|---|---|
| Doctor Finder (`surgwork/portal/ptest3.py`) | 30 / 30 |
| Portal v0.2 suite on the v0.3 build | 54 / 54 (run 3×; one early run showed the duplicate-import flake fixed above) |
| Portal v0.1 regression on the v0.3 build | 36 / 36 |
| Core module checks (`modtest_portal02.py`) | 44 / 44 |
| Surgery smoke13 (Core build, 1180 px) | 369 / 369 |

Screenshots: `report/portal_v03_screens/` (01–07, plus `regress/`).

## Simulated or not built
- **Live NPI** needs the backend proxy; until then the bundled snapshot is used.
- **Coverage:** the snapshot covers only Beverly Hills/LA, 12 specialties, individuals (NPI-1). Organizations (NPI-2) are supported by the adapter but not in the snapshot.
- **Vityls listings:** in-network entries are fictional. Practice NPI claiming and verification is designed, not built.
- **Distance:** no true distance search yet (ZIP area only). No insurance or availability data.
- **Messaging:** connect, message and appointment requests go through the v0.2 hub (same-browser, simulated). Records requests and upload links are simulated as before.
