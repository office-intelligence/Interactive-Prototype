# Case data model: v9.1 changes (for Henry). Fictional data only.

- **Staff seed.** Added `{ id: 'st-md', name: 'Rhea Castillo, MD', role: 'Medical Director' }`. 'Medical Director' is now in the ASC STAFF_ROLES. Missing seed ids are merged in automatically.
- **Blocks** (`block-seed` storage key). An item is `{ id, surgeon, date, start, end, room, notes?, series? }`.
  - The optional `series` field is new. A block's series key is `series` when present; otherwise it is `surgeon|room|start|end`, which matches blocks created before v9.1.
  - Edit series rewrites every member with `series: 'ser-<firstId>'`.
  - Edit this block sets `series: 'solo-<id>'`, which detaches it.
  - Booking into a block (`consumeBlock`) replaces the block with 0 to 2 remainder pieces (ids `<id>-a`/`<id>-b`) that keep the series key.
- **Audit actions.** `asc91.block` for block edit, delete and consume. Schedule column deletes use the existing resource audit with the detail "Schedule column deleted: …".
- **Unchanged.** Cases, invoices, credits and the fee schedule (`asc89` store) have no schema changes.
- **Role gate.** `canSeeIntel(role)` returns true for /administrator|medical director/i.
