# Vityls Patient Portal v0.1: changelog (2026-10-14)

Branch `portal` (from `core-modules-v1.0`), tag `portal-v0.1`. Test build: `Vityls_Patient_Portal_v0.1.zip`. Unzip it and double-click `index.html`. The Portal also opens at `#portal` in the Core build. All data is fictitious, and **every connection is simulated** until a BAA is signed. Plan: `report/Vityls_Patient_Portal_Plan.md`.

## Core
- `patient-portal` is registered in the Core module registry (`src/core/modules.ts`) as `audience: 'patient'`. It's entitled per patient (Free / Plus, the future `patient_entitlements` table), not per practice, so it doesn't appear in practice plans or the admin module table. `PATIENT_MODULE_IDS` is exported, and the storage prefix is `vityls:portal:`.
- Routes: `#portal` (any build), `#portal-upload=<token>` (provider upload page). The `VITE_PORTAL=1` build opens the Portal by default.
- Code: `src/portal/store.ts` (data, simulations, Nightingale rules), `src/portal/PortalApp.tsx`, `src/portal/portal.css`.

## Features
- **Patient account without a practice.** Sign-up (name, email, DOB, password of 8+ characters) and sign-in. Each patient gets a Vityls ID. Demo patient (fictional): `jordan.rivera@example.test` / `portal2026`. Add `?reset-portal` to the URL to reset.
- **Nightingale home.** Chat with command chips (Explain my labs, Check my medications, Prepare for my visit, Connect my doctor, Request my records, Upload a document) and **proactive question cards driven by the data**:
  - A new abnormal lab (latest value per test) leads to: "Now that I've seen your latest labs… tell me about your medications…". The patient answers with one-tap med chips or free text. The answers are added to the med list. Nightingale names, in general terms, any medicines commonly known to affect those tests, and drafts a question for the doctor in Messages.
  - Missing allergies (with "No known allergies" verified by the patient), missing medicines, health history, "connect your records", and new-document summaries.
  - Guardrails: no diagnosis, and no go/no-go advice ("I can't tell you whether to do that…"). Red-flag words lead to "call 911 or your doctor now". Symptoms are logged to a journal.
- **Labs.** Grouped by test across sources, with a trend chart (reference range shaded) and a plain-language explanation (simulated, rule-based).
- **Documents.** Upload (photo or PDF), type, source, download, and an "Explain" summary (simulated). Items from a practice are labeled "always free".
- **Medications & allergies.** Add and remove, with the source shown for each entry.
- **Connect my doctor:**
  1. FHIR "sign in to your portal" with fictional Northshore Health (Epic MyChart), Redwood Valley (athenahealth) and Harbor Point (Oracle Health). The flow is a simulated login and consent screen, then an import of labs, medications, allergies and documents. Duplicates are skipped on re-sync.
  2. Records-request generator: a HIPAA right-of-access letter (45 CFR 164.524) with a unique return fax and Direct address per request, a 30-day due date and a reminder. "Send" is simulated, and there's a "Simulate fax received" button that files to Documents.
  3. Provider upload link: one per office, valid for 7 days, revocable, with a QR-style mark. The no-account office page at `#portal-upload=<token>` shows only the patient's initials, files uploads to the patient's Documents with a note, rejects invalid, expired or revoked tokens, and includes a short Vityls-for-practices pitch.
  4. TEFCA/Carequality, shown as "later".
- **Messages & reminders** with linked fictional Vityls practices (Bayview Family Medicine, Coastline Plastic Surgery): secure messages (with a simulated auto-reply), Nightingale's drafted questions, refill requests, and reminders (once, daily, weekly or monthly, with practice-set reminders marked).
- **Plan.** Free vs Portal Plus ($6.99/mo, a test price), with a 14-day trial, a simulated upgrade, and switching back to Free:
  - Wearables and the visit-prep summary draft are gated to Plus.
  - Free gets 10 explanations per month. Practice-sent results and documents are always explained free, with no limit.

## Tests (2026-10-14)
| Suite | Result |
|---|---|
| Portal v0.1 (`surgwork/portal/ptest.py`, 1280 px + 390 px mobile shot): sign-up/in, prompts, guardrails, FHIR import + dedupe, records request, upload link + provider page, labs, documents, meds, messages, refills, reminders, plan gating, free limit with practice exemption | 39 / 39 |
| Core module checks (`modtest.py`) on the rebuilt Core build | 44 / 44 |
| Surgery smoke13 on the rebuilt Core build, 1180 px | 369 / 369 |

Screenshots: `report/portal_v01_screens/` (15).

## Simulated or not yet built
- All external connections are simulated: FHIR/SMART login, fax/Direct sending and receiving, the upload link (it works only in the same browser, because data is in localStorage), wearables, and payment.
- Explanations are scripted rules, not a live model.
- The QR mark is decorative and can't be scanned.
- Passwords are stored in plain text in the browser (test build only). There's no MFA, identity proofing or account recovery yet.
- Practice ↔ Portal live linking (practice-side `portal-link` sending forms, check-in and bills into this account) isn't wired yet. The linked practices are seeded.
- Not built yet: Doctor Finder (NPI registry), the TEFCA layer, and caregiver/family profiles.
