# ASC.Vityls v8.2 — Changelog
Branch `asc-v8.2` (from `asc-v8.1` e0d5f27). Fictional data only. PIN is used only for signing. No automatic PDF. External services (fax OCR, ambient capture, email, SMS, portal) are simulated. No other branch was changed.

## Already in v8.1 (before this build)
| Request | v8.1 state |
|---|---|
| Patient header on every station/workbench | Partial: station step panels and the Surgeon tab had one; workbenches had only a patient picker |
| Forms listed per station with Open | Partial: collapsed "Forms for this station" drawer (Fill in/View) and inline editors for missing items; no per-form summary |
| Hand-drawn signature | Missing (PIN only) |
| Brief medical history for Anesthesia/Surgeon | Partial: Surgeon tab right rail only; nothing for Anesthesia |
| Practice Settings PIN | Existed (now removed) |
| X close icons | Partial: step panel and Surgeon tab used ✕; workbench, day briefing, block time, to-do and Send-to-ASC used the word "Close" |
| Today list border | Existed (bordered card) |
| Booking intake → scheduler + patient matching | Missing: created the case directly, always a new patient, always today |
| Arrival ID/insurance capture | Missing: checklist only |
| Pre-op bedside merged into Nursing | Separate bench |
| Nursing checklist (checkboxes only) | Checkbox + free-text field per item |
| Anesthesia / Surgeon workbenches | Missing (some items lived in the step panel / Surgeon tab) |
| PACU full form in place | Missing: tasks + Aldrete picker only |
| Discharge nurse + patient/adult + physician signatures | Partial: patient checkbox + nurse PIN only |

## Global
- **Patient header card** (`asc82/common.tsx · CaseCard`): name, age, sex, procedure (side), surgeon, room and time, allergies, with the station's colored icon. On every station step panel and every workbench.
- **Station forms**: the step panel now lists each assigned form as a card with an **Open** button (opens the full form in place, with a Back link), a summary ("x of y done · n fields on file · status", "✓ Collected: …"), and the missing items inline beneath it so they can be filled without opening the form. Items that belong to no form appear under "Station checklist".
- **Hand-drawn signature** (`asc82/sigpad.tsx`): finger/stylus/mouse canvas. In ASC2 every PIN signature (PinSign) now also needs a drawn signature; the PNG is stored with signer, role, time and case (`asc82-sigs`). The patient/responsible adult signs by drawing only (patients have no PIN).
- **Brief medical history** (`MedSummary`) for Anesthesia and Surgeon (station panels and benches): allergies, medications, conditions, surgical/anesthesia history, today's vitals/NPO, with source links to the pre-op clearance, medical history and anesthesia questionnaire forms.
- **Practice Settings PIN removed** in ASC2 (`practiceUnlocked()` returns true). Signing still uses the PIN.
- **X close icons**: top-right Close buttons on workbenches, day briefing, block time, side panels, the to-do panel, journey dialogs and Send-to-ASC are now an X icon with `aria-label="Close"`.
- **Today**: the station patient list has no bordered container and runs full width (per Kevin's markup).
- **390 px**: the top bar wraps instead of pushing the page sideways. Dialog headers keep the X on the title row. The walkthrough checks for no sideways scroll on Today, Add appointment, Arrival, Nursing, Anesthesia, Surgeon, Discharge, station panel and Schedule.

## Workbench (new order)
Booking intake · Arrival & check-in · Records brief · Nursing admission · **Anesthesia** · **Surgeon** · PACU · Discharge · After surgery · Audit pack.
- **Booking intake**: "Confirm & create" checks name + DOB against the patient database. An exact name + DOB match is linked. The same name with a missing or different DOB, a near name, or duplicate charts → staff choose (radio list). No hit → new patient. It then opens the scheduler's **Add appointment** on the requested surgery day, prefilled (patient, surgeon, OR, suggested time, duration, procedure, notes). The surgery case is created when the appointment is booked, and portal forms are sent (simulated). Seed: a returning-patient email (Desmond Akers, DOB match) plus "Requested date" on the hernia email.
- **Arrival & check-in**: ID and insurance card, front and back. Camera (`capture="environment"`) or upload, compressed to JPEG ≤900 px, "x of 4 on file"; explains when ID was already confirmed.
- **Records brief**: unchanged.
- **Nursing admission** (pre-op bedside merged in): 5 numbered section cards (Identity/consent/records · NPO/allergies/meds · Assessment · Lines & prep · Discharge planning) with checkboxes. There is an "x of y complete" chip overall and per section, "on file" chips with their source, and "Tick what's already on file". Inputs appear only for vitals, NPO times, IV site/gauge and responsible adult. The simulated bedside capture pre-fills NPO, vitals and ride. **Lock & sign** (rose) opens only when everything is checked; signing writes vitals, NPO, allergies, meds, IV, site check, clearance and the nursing form to the case.
- **Anesthesia (new)**: medical summary with source links, plus the records-brief ASA suggestion. Then:
  1. Airway: Mallampati, thyromental distance, mouth opening, neck ROM, dentition.
  2. ASA plus a focused exam checklist.
  3. Anesthesia type and technique, with **Sign evaluation**.
  4. Anesthesia consent and PACU orders (moved here from bedside); signing the orders creates the PACU tasks.
  5. Immediate pre-induction re-evaluation: attestation, note and signature.
- **Surgeon (new)**, all signed with drawn signature + PIN, surgeon only: medical summary, then pre-op orders, surgical consent, interval H&P + site marking, brief op report (drafted, signable once the case has started), and post-op orders.
- **PACU**: the full PACU Recovery Record form opens in place. Signed PACU orders appear above it as tasks. The "missing items only" mode was removed; the PACU station panel also opens the full form first.
- **Discharge**: three required signatures:
  1. Nurse: drawn signature + PIN.
  2. Patient or responsible adult: drawn on the tablet.
  3. Physician discharge order: drawn signature + PIN.
  The chip reads "x of 3 signatures"; **Discharge patient** unlocks at 3 of 3. The existing discharge gate still applies.

## Tests
- Unit: `npx tsx --test tests/*.test.ts` → **145/145** (13 new in `tests/asc82.test.ts`).
- Walkthrough: `python3 scripts/walk82.py http://localhost:8783/ 1440 1024 390` → **135/135** (45 checks × 3 widths), no page errors.
- `tsc` baseline unchanged (68 pre-existing errors, none in new code).
