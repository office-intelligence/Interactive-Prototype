# Vityls Patient Portal v0.2 — changelog (2026-10-14)

Branch `portal`, tag `portal-v0.2` (from portal-v0.1). Test build: `Vityls_Patient_Portal_v0.2.zip`. One `index.html` holds both apps:
- `index.html` opens the Patient Portal (guest mode first).
- `index.html?practice=coastline` (or `?practice=bayview`) opens the practice app. Its new **Portal** nav item (portal-link module) is the practice side.
- Both use the same browser storage. Everything is simulated, and all data is fictitious.

## New
1. **Practices connect to the same Portal.** The shared hub (`src/portal/hub.ts`) uses raw, un-namespaced storage so the Core/Surgery practice app and the Portal see the same data.
   - Connecting: the practice sends a connection request by Portal email, and the patient or caregiver allows or declines it in Care team. Revocable.
   - Practice can send: at-home forms (patient fills in and signs by typing their name; a signed copy files to Documents), check-in, bill (pay with simulated card), messages, appointment reminders (confirm), documents, and results (flow into Labs with trend alerts).
   - Patient side: secure messages, refill requests (practice approves or answers "needs visit", and the reply shows in the Portal), and appointment requests.
   - The pre-loaded demo practices are removed; connections come only from the practice-side flow.
   - Practice-sent results and documents are always explained for free and don't count against limits. Tested at the limit.
2. **Care team page.** Vityls-network practices with Message, Request appointment, Forms & bills, History, Revoke. Non-Vityls providers (FHIR sources, records requests, upload-link offices, manual add) are listed separately.
3. **Interaction history.** Append-only log (the code has no edit or delete path) of every interaction: link requested/granted/revoked, sent, opened, signed, checked-in, paid, confirmed, messages, refills, appointment requests, caregiver invited/accepted/revoked. Each entry has who, role and timestamp.
   - Portal History page: all entries, or filtered per practice.
   - Practice app: "Portal history" for that practice.
4. **Family / caregiver access.**
   - The patient invites a family member (name, email, relation) with full access. The consent text is shown and signed, and access can be revoked.
   - The caregiver accepts after signing in with the invited email, switches profiles, and acts for the patient. A banner shows who they're acting for, and every action is logged as the caregiver.
   - **Notification center** (in-app) for the patient and every active caregiver:
     - abnormal results (from a practice or from an imported connection)
     - worsening trends (moving further outside the range, or 3 moves in a row in one direction ending outside the range)
     - practice messages and refill replies
     - documents and items
     - connection requests
   - Unread badge, and "Mark all read".
5. **Guest mode.**
   - Opens with Nightingale and no sign-in. 3 free explanations are stored locally; the 4th asks the guest to create an account.
   - Saving records, connecting doctors, messaging a practice, family access, wearables and uploads ask for an account right away.
   - The guest's chat and entered labs carry into the new account.
6. **Example carousel** at the bottom of the Nightingale dialogue, both guest and signed-in. It auto-rotates every 4.5 s, has dots, and pauses on hover. Six mini graphics, each labeled "Example" with a "Try it" button: lab trend, medicine and labs, wearable sleep/heart rate, visit prep, document explanation, caregiver alert.

Nightingale still never diagnoses and gives no go/no-go advice. Trend alerts say "worth discussing with the doctor."

## Tests (2026-10-14)
| Suite | Result |
|---|---|
| Portal v0.2 (`surgwork/portal/ptest2.py`): guest, carousel, practice→portal for all item kinds, care team, history (both sides), caregiver invite/accept/switch/notifications/revoke, free-limit exemption | 54 / 54 |
| Portal v0.1 regression adapted to v0.2 (`ptest_v01_regress.py`) | 36 / 36 |
| Core module checks, rebuilt Core build (`modtest_portal02.py`: same 44 checks; the two nav checks now expect the new Portal entry) | 44 / 44 |
| Surgery smoke13 on the rebuilt Core build, 1180 px | 369 / 369 |

Screenshots: `report/portal_v02_screens/` (01–13, plus `regress_v01/`).

## Simulated or not built
- All delivery is simulated: invitations and notifications by email/text/push, payments (card •••• 4242), fax/Direct, FHIR sign-in, wearables.
- The practice and the Portal sync only within the same browser, because data is stored locally. A server is needed for real use.
- Form signature in the Portal is a typed name (patient side). Staff PIN signing is unchanged.
- The practice's form library isn't connected yet. The Portal hub offers 3 simple built-in forms.
- Check-in from the Portal doesn't yet update the practice's Today board/station. An appointment request doesn't create a schedule entry. Both are logged as items only.
- Results don't yet write to the practice chart's labs.
- Passwords are stored in plain text in the browser, and there's no MFA or identity proofing.
- Not built: caregiver scopes other than full, Doctor Finder, and the TEFCA layer.
