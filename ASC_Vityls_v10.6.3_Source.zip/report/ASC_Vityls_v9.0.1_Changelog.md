# ASC.Vityls v9.0.1 — Changelog
From asc-v9.0. The warm mockup page background (#FBF7F1) now fills the whole main area edge to edge on every page: Chat, Today, Patients, Schedule, Messages, Billing, Operations, Settings. The white strips left and right of the centered column came from the v8.4 ASC2 white .fd-body/.sv-page rule. Cards stay white or ivory. tsc 68 · unit 200/200 · walk90 146/146.
