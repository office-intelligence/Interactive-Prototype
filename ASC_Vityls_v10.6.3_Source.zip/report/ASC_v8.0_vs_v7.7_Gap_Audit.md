# ASC Vityls — v8.0 (ASC2) vs v7.7 (+ v7.6 base) Feature Gap Audit
Date: 2026-10-27 (America/Los_Angeles) · Branch asc-v8.1 (from refs/heads/asc-v8.0 @ 6bb1853) · Worktree /workspace/vityls/asc81
Method: both builds were run and clicked through with Playwright and Chrome. v7.7 ran from release/ASC_Vityls_v7/index.html (file://). v8.1 is the ASC2 build served on :8781. Screenshots are in /workspace/vityls/report/asc_v8.1_audit/ (v77_*.png, v81_*.png). Code grep was used only to confirm. All data is fictional.
Status key: **P** = Present · **Pt** = Partial · **M** = Missing in v8.0.

## 1. Shell / navigation
| Feature (v7.7) | v7.7 ref | v8.0 | v8.0 ref / note |
|---|---|---|---|
| Bottom nav Dashboard/Schedule/Patients/Messages/Practice/Nightingale | src/v77/Home77.tsx | P (different form) | Sidebar Chat/Practice + Today/Patients/Schedule/Messages; SurgeryApp.tsx |
| Role/session switching with per-role home | v76/Today76.tsx | P | "Session" select, 16 seeded staff (staff.ts ASC_SEED); v81_today.png |
| Nightingale coordinator panel + quick actions (3-OR matrix, claims, portal msgs, Form Studio, EKG hold) | v77/Home77.tsx | Pt | nightingale.ts/panel.tsx chat present; Henry paused; quick-action set differs |
| Workbench chips (Booking intake → Audit pack, Form templates) | Home77.tsx | Pt | stations via role Today; no chip row, no Audit pack (M) |

## 2. Today / dashboard
| Feature | v7.7 | v8.0 | Note |
|---|---|---|---|
| Today76 board, 7 team flags | v76/Today76.tsx | P | asc8/today.tsx: "Flag", "See all roles", 9 flag teams |
| Classic board: Priority / Room Grid / Bottlenecks / Pipeline views | Today76/Home77 | Pt | Rooms today + Bottlenecks + Turnover moved to Practice › Operations (asc8/ops.tsx, v81_p_Operations.png); **Pipeline view M**; Priority view M |
| Day strip / date nav | Home77 | P | prev/next/Today |
| Allergy cards | v76 | P | surgery/allergy.tsx |
| Editable OR times with audit | v76/logic.ts | Pt | OR-time edit exists (asc8/logic.ts); audit-trail parity must be checked in the port |
| Day Briefing | Schedule | M | no matches in src/surgery |

## 3. Schedule
| Feature | v7.7 | v8.0 | Note |
|---|---|---|---|
| Add appointment | P | P | "Add visit" |
| Block time | P | Pt | "+ Office event" (block-time logic is in code; no UI label) |
| Rooms view, Day/Week, print | P | P | Rooms/Surgeons, Columns, Print (v81_schedule.png) |
| Month day picker | P | Pt | ‹ › only |
| Confirmations / weekly notes / reminders | – | P (v8 extra) | |

## 4. Patients / chart
| Tab (v7.7) | v8.0 | Note |
|---|---|---|
| Profile, Appointment history, Clearance files, Review & alerts | P | SurgeryChart.tsx, profile.tsx, documents.tsx |
| Workstations / Day of Surgery (form-based iMARS flow) | Pt | stations exist (SurgeryStation.tsx, asc8/forms.ts); v7.6 sequential form workflow and OpReportPage must be compared field by field |
| Intake forms / portal | P | v13 PrintSend, documents |
| Billing, Collect payment | P | payments.tsx, charges.tsx, quotes.tsx |
| Provider notes, Dictate note | P | Dictate (16 files) |
| Messages tab, Print | P | |
| E-Prescribe | Pt | 2 refs only, unverified in the UI |
| Ask AI / chart Chat | P | chat panel |
| Add patient | P | newPatient.tsx |

## 5. Messages
| Feature | v8.0 | Note |
|---|---|---|
| Inbox + reply + open chart | P | v81_messages.png |
| Filters All/Unread/Clinical/**Rx Refills**/Billing | M | no filter chips seen; no Rx refill category |

## 6. Practice
| v7.7 section | v8.0 | Note |
|---|---|---|
| Administration & Locations | P | Settings › Practice setup |
| Billing & Payments (fee schedule, claims) | P | Billing & payments: Accounts/Visits to invoice/Payments/Surgery deposits; fee schedule in settings |
| Operations Intelligence | Pt | Operations: rooms/bottlenecks/turnover/staffing; v7.7 KPIs/Pipeline not all present |
| Practice configuration, Rooms & schedule settings | P | PIN-gated Settings (PracticeGate.tsx, demo PIN 1234) |
| **Medical Director** workspace | M | 1 incidental ref |
| Forms & Workflow / My Forms / Form Library (23 templates) | P | Settings › Forms: My Forms, Form Library, Stations & Assignments, Practice PDFs, Add Form, 20+ templates listed |
| Form Studio editor + signer setup | Pt | "Edit form" uses Surgery's editor; v7.7 fe/FormEditor.tsx features (signer roles per section, shim, formLib) need a diff |
| Stations & Assignments | P | |
| Providers / staff registration, invite, PIN, Forgot PIN | P | staff.ts sendStaffInvite, StaffInviteLanding.tsx, v12/PinReset.tsx |
| **Facility Accreditation & Documents** | M | 0 refs |
| **Policies & Manuals** | M/Pt | 2 incidental refs |
| Audit pack | M | |

## 7. Backend / data
| Item | v8.0 | Note |
|---|---|---|
| dataLayer / backend contract for Henry | Pt | 65 refs in src/surgery under a different schema; the v7.7 contract doc and IDs must be reconciled |
| Storage namespace | P | `vityls-asc2~` (separate from v7.x) |

## Counts (≈45 rows)
Present ≈ 27 · Partial ≈ 12 · Missing ≈ 7. Most important missing: Medical Director workspace; Facility Accreditation & Documents; Policies & Manuals; Audit pack; classic Pipeline/Priority views; Messages filters incl. Rx refills; Day Briefing. Most important partial: Form Studio signer setup parity; v7.6 form-based station workflow/op report; OR-time audit trail; dataLayer contract; Nightingale quick actions; E-Prescribe.

## Porting plan (v8.1)
1. **Data first.** Port v7.7 dataLayer contract fields and OR-time audit into asc8/store.ts/logic.ts. Risk: two schemas, so write an adapter and don't fork the store.
2. **Forms.** Diff v77/fe/FormEditor.tsx + formLib.ts against Surgery's editor. Port the signer setup and any missing template fields. Risk: template ID collisions between the 23 templates.
3. **Station workflow parity.** Bring the v7.6 sequential forms and OpReportPage into SurgeryStation. Risk: regressions in existing v8 stations, so add walk tests.
4. **Practice workspaces.** Add Medical Director, Facility Accreditation & Documents (the bank stays here as an audit reference only), Policies & Manuals and Audit pack as new Settings workspaces.
5. **Ops/board.** Add Pipeline + Priority views to Operations, plus Day Briefing in Schedule.
6. **Messages.** Add filters and the Rx refill category.
7. **Nightingale.** Add quick actions and confirm E-Prescribe.
8. **Design pass** (lighter palette, per-station colored icons). Waits for Kevin's screenshots; ref design_inspiration/kevin_v8_inspo_01_preop_nursing.png.

Verification gaps in this audit: the v7.7 deep crawl hung after the chart Workstations tab, so its Day of Surgery, Intake, home chips and the rest of the Practice subsections were judged from code plus the existing screenshots. Step 2/3 needs a field-level diff.

## 8. Field-level comparison (forms & stations), done before porting
Script: /tmp/formcmp.py (BeautifulSoup over public/forms). All v7.7 catalog templates were compared with v8.1 by file bytes and by named fields.

| v7.7 template | fields v7.7 | fields v8.1 | file | in ASC set (v8.1) |
|---|---|---|---|---|
| AMA_Refusal_Form.html | 12 | 12 | identical | Mapped → AMA / Refusal (Kept) |
| Admission_Form.html | 1 | 1 | identical | Mapped → Admission Form (Kept) |
| Anesthesia_Consent.html | 4 | 4 | identical | Mapped → Consent for Anesthesia (Kept) |
| Anesthesia_Evaluation.html | 3 | 3 | identical | Mapped → Anesthesia Pre-Op Evaluation (Added) |
| Anesthesia_IntraOp_Record.html | 29 | 29 | identical | Mapped → Anesthesia Intra-Op Record (Added) |
| Anesthesia_Order_Form.html | 1 | 1 | identical | Not in ASC set |
| Anesthesia_Questionnaire.html | 16 | 16 | identical | Mapped → Anesthesia Questionnaire (Kept) |
| Billing_Fee_Disclosure.html | 1 | 1 | identical | Mapped → Financial: Card Authorization & Cash Fee Disclosure (Merged) |
| Blank_Custom_Form.html | 2 | 2 | identical | Not in ASC set |
| Credit_Card_Authorization.html | 7 | 7 | identical | Mapped → Financial: Card Authorization & Cash Fee Disclosure (Merged) |
| DayOf_Interval_HP_Update.html | 20 | 20 | identical | Mapped → Day-of Interval H&P Update (Kept) |
| Emergency_Transfer_Form.html | 15 | 15 | identical | Mapped → Emergency Transfer (Kept) |
| Insurance_Information.html | 11 | 11 | identical | Mapped → Registration & Insurance (Merged) |
| IntraOp_Nursing_Record_TO.html | 5 | 5 | identical | Mapped → Intra-Op Nursing Record & Counts (Added) |
| MH_and_VTE_Assessment.html | 23 | 23 | identical | Mapped → Nursing Pre-Op Assessment (with MH & VTE risk) (Merged) |
| Medical_History.html | 1 | 1 | identical | Mapped → Medical & Surgical History Questionnaire (Adapted) |
| Nursing_Admission.html | 1 | 1 | identical | Mapped → Nursing Pre-Op Assessment (with MH & VTE risk) (Merged) |
| PACU_Doctor_Orders.html | 1 | 1 | identical | Not in ASC set |
| PACU_Recovery_Record.html | 6 | 6 | identical | Mapped → PACU Recovery Record (Aldrete) (Added) |
| Patient_Registration.html | 23 | 23 | identical | Mapped → Registration & Insurance (Merged) |
| Patient_Satisfaction_Survey.html | 21 | 21 | identical | Mapped → Patient Satisfaction Survey (Kept) |
| Photography_Media_Research_Consent.html | 20 | 20 | identical | Mapped → Photography / Media / Research Consent (Kept) |
| Physician_Discharge_Order.html | 11 | 11 | identical | Mapped → Physician Discharge Order & Diagnosis (Added) |
| PostOp_Discharge.html | 1 | 1 | identical | Mapped → Discharge Evaluation & Handoff (Added) |
| PreOp_HP_Clearance.html | 1 | 1 | identical | Mapped → Pre-Op H&P / Medical Clearance (Merged) |
| Procedure_Consent.html | 7 | 7 | identical | Mapped → Consent to Operation, Anesthetics & Post-Op Care (Adapted) |
| Surgeon_Membership_Application.html | 71 | 71 | identical | Mapped → Provider Credentialing: Membership & Privileges Application (Moved) |
| Surgeon_Operative_Report.html | 25 | 25 | identical | Retired→note page |
| Surgeon_Orders.html | 1 | 1 | identical | Not in ASC set |
| Surgeon_PreOp_Clearance.html | 1 | 1 | identical | Mapped → Pre-Op H&P / Medical Clearance (Merged) |
| Universal_Protocol_Safety_Checklist.html | 9 | 9 | identical | Mapped → Surgical Safety Checklist / Time-out (Added) |
| Written_Discharge_Instructions.html | 19 | 19 | identical | Mapped → Written Discharge Instructions & Acknowledgment (Merged) |

Result: 32/32 templates byte-identical. 27 are mapped into the ASC set (4 merges keep every source field via mergedDef). The Operative Report moved to the note page. Blank Custom Form is builder-only. **3 order sheets were missing (Anesthesia_Order_Form, Surgeon_Orders, PACU_Doctor_Orders) and are restored in v8.1** as as-needed templates with signers (26 templates).
Form editor: v8.1 `src/surgery/v09/formLib.ts` + `FormEditor.tsx` is a superset of v7.7 `src/v77/fe/*` (same exports and test ids, plus `formLibHooks` for merged definitions): drafts, publish/versions, restore original, re-publish, import/export JSON, version pins per patient. Signer setup is per form (`repo.saveSignerConfig`, configured in Practice › Forms & workflow). No gap.
Stations: v7.6's form-based stations map to v8.0 StepPanel items, each with its `form` and a 'Forms for this station' drawer. v7.6 OpReportPage maps to v8.0 OpReportPage (draft, PIN sign, copy via Surgery.Vityls or secure link). OR-time edits need a reason and are audited (asc8 `setEvent`/`recordEvent`). What v8.0 was missing was the v7.7 AI-first workbench layer, which is now ported.

## 9. Corrections after the v7.7 re-crawl (with timeouts; screenshots v77_p_md/p_facility/p_policies/pt_dos/h_forms)
- Facility Accreditation & Documents: **Present** in v8.0. The Practice item 'Policies & manuals' already ran the same v7 document center (AdministrationPage); v8.1 relabels it.
- Month day picker: **Present** (the date input on the schedule).
- OR-time audit: **Present** (reason required on change).
- Medical Director in v7.7 = provider credentialing queue + designation, now covered by the v8.1 Medical Director workspace.

## 10. v8.1 status (after porting)
All Missing and Partial rows above are addressed, except: the free-text coordinator command parser (logic ported, not wired to chat) and E-Prescribe (unchanged from v8.0). See ASC_Vityls_v8.1_Changelog.md.
