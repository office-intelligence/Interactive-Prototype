# Case data model (Surgery.Vityls v1.6, notes/roles/flags added in v1.7, flag roles + provider scoping in v1.8), for Henry

In plain terms, a **case** is one reason the patient is with us. Examples are a rhinoplasty, a facelift a year later, or a filler appointment. Everything the practice records about that reason is filed in the case. Things that are not about any procedure are filed as **General**.

The browser test build keeps these tables in local storage. The TypeScript shapes are in `src/surgery/cases/logic.ts` and are re-exported from `src/v6/dataLayer.ts` as `CaseRow`, `CaseLinkRow` and `EncounterRow`. The swap point for your API is `src/surgery/cases/store.ts`. Screens only call that store.

## The tables, top to bottom

```
patient ─┬─< case ─┬─< encounter (visit / appointment: office, phone, video) ─── note (1 per encounter)
         │         ├─< document
         │         ├─< payment
         │         ├─< quote
         │         └─< task (the case's to-do / checklist items)
         └─ "General" (caseId = 'general') for anything not case-related
```

### 1. patient
This table is unchanged. Key: `id`, for example `MED-2055`.

### 2. case
One row per case.

| column | meaning |
|---|---|
| `id` (PK) | Case id. For a surgical case it is the same id as its surgical episode (for example `ep-mary`), so the existing episode data joins one-to-one. |
| `patient_id` (FK → patient) | Whose case it is. |
| `procedure` | For example "Rhinoplasty (open)" or "Filler injections". |
| `kind` | `surgical` \| `office-procedure` \| `general` |
| `status` | `open` \| `booked` \| `post-op` \| `closed` \| `undecided`. For surgical cases the status is derived from the episode stage until the case is closed. |
| `opened_at`, `opened_by`, `source` | When and how it opened. `source` is one of `doctor-suggested`, `manual`, `new-appointment`, `migration` or `seed`. |
| `closed_at`, `closed_by`, `close_reason` | Set when the case is closed. It closes automatically after the last post-op visit (surgical), or once the case is paid and its note is signed (office procedure). Staff can also close it by hand. |
| `episode_id` (FK → surgical_episode, optional) | Surgical cases only. The episode keeps the quote, deposit, booking, clearance and ASC data that already exists (tables `surgical_episodes` and `episode_items`). |
| `quick_*` | Office procedure only: `visit_id`, `price`, `paid_at`, `paid_by`. |
| `log` | The case's own history: opened, moved items, paid, closed. It can be a child table `case_log(case_id, at, by, role, what)`. |

### 3. encounter (visit / appointment)
This is the existing `visits` table plus one new column, **`case_id`** (FK → case, or `'general'`).
- `mode`: office, phone or video.
- Phone and video consults are encounters as well.
- A visit note hangs off its encounter (`note.visit_id`), so it inherits the case.

### 4. document, payment, quote, task, and the other items
In your database, give each of these tables a **`case_id`** column, matching the encounter table:
- documents
- payments (including deposits)
- quotes
- forms packets
- body charts
- photos
- contact notes (calls)
- portal messages

In the test build they are joined through one link table, `case_links`:

| column | meaning |
|---|---|
| `entity` + `id` (PK) | `document`, `payment`, `quote`, `form`, `bodychart`, `photo`, `call` or `message`, plus that row's id |
| `patient_id` | The patient. |
| `case_id` | The case, or `'general'`. |
| `at`, `by`, `how` | Who filed it, and how: `migration`, `nightingale` (suggestion), `staff` (one-tap move) or `seed`. |

**Task** = a case's to-do item:
- For surgical cases these are the existing `episode_items` rows, keyed by `episode_id` = `case_id`.
- The 7-step workflow state (`flow-state`) is now keyed by **case id**. It was keyed by patient before. A patient who has no case yet is still keyed by patient id until a case opens.
- As a result, two open cases for the same patient keep separate progress and separate to-do lists.

## Rules the app follows
- **Opening a case.** A case opens when the doctor suggests a procedure (scribe suggestion, booking order or quote), when staff choose "New case" while booking, or by hand from the chart.
- **New appointments.** These get Nightingale's suggested case: the patient's newest open surgical case, otherwise their open office-procedure case, otherwise General. Staff can change it on the New appointment dialog, and later with one tap on the visit (appointment panel, workspace header, case timeline).
- **Audit.** Every move is audited (`case.link`), as are open, close, reopen and paid (`case.open`, `case.close`, `case.reopen`, `case.paid`).
- **Closed cases** are read-only history.
- **Migration (v1.6, run once).**
  - Each episode becomes a case.
  - Each existing visit, call, message, document, quote, payment, forms packet, body chart and photo is assigned by date. A case covers from 45 days before it opened to its close. A procedure word in the item's text breaks ties.
  - Items with no matching case go to General.
  - The patient's existing workflow state moves to their open surgical case.
- **Medical.Vityls** does not use cases. The optional `caseId` on visits is ignored there.


---
## v1.7 additions: notes, jots, role tags and flags

Browser build: shapes in `src/surgery/v17/logic.ts` (pure); storage and the swap point for your API in `src/surgery/v17/store.ts`. Screens only call that store.

```
encounter ─── clinical_note (0..1 per encounter; mirrors the existing visit note)
encounter ─< jot
task (derived) ── owner_role
patient / case ─< role_flag
```

### 5. clinical_note (one per encounter)
The one note record for a visit. The chart's Notes list, the Doctor workspace and the near-full-screen note page all read and write it. In the test build each save is also mirrored to the existing `visit_note` row (`medRepo.note`), so older screens keep working; on the backend these can be one table.

| column | meaning |
|---|---|
| `id` (PK) | Note id. |
| `visit_id` (FK → encounter, unique) | The visit it documents. |
| `patient_id` (FK → patient) | |
| `case_id` (FK → case, nullable) | Copied from the visit's case at save time (`general` when none). |
| `type` | `H&P` \| `SOAP` \| `Simple` |
| `stage` | `jot` \| `draft` \| `signed`. Signed notes are read-only (addenda as before). |
| `text` | The full note text (sections as headed blocks). |
| `author_id` | The visit's provider. |
| `dictated` | true when dictation (simulated now) contributed. |
| `drafted_by` | `Nightingale` when the text started as a Nightingale draft; never a signer. |
| `updated_at`, `updated_by` | Last save. |
| `signed_at`, `signed_by` | Set only by the PIN signature of a provider. |

### 6. jot
Quick notes a doctor takes between rooms, typed or by voice.

| column | meaning |
|---|---|
| `id` (PK) | |
| `visit_id` (FK → encounter) | |
| `patient_id`, `case_id` | Copied from the visit. |
| `text` | |
| `voice` | true for a voice jot (simulated now). |
| `by`, `at` | Who and when. |

### 7. Missing-note to-dos (derived, no table)
For each provider: every visit since `notes_since` (practice setting; first day of v1.7) with `step` at or past the doctor station (or a past date), and no signed clinical_note. No due date and no Overdue status: the item stays **Incomplete** until signed.

### 8. owner_role on tasks
Every task carries `owner_role`: `front` \| `clinical` \| `doctor`. It is derived from the task key (`ownerOf()` in logic.ts): front = booking, forms, registration, payment, checkout, post-op booking; clinical (nurse, MA, coordinator share it) = vitals, reason, nurse notes, quotes, deposit, case booking, clearance, PCP letter, documents, ASC; doctor = exam, body charts, photos, notes. Staff roles map to a view by `roleViewOf()`; managers/administrators see all.

### 9. role_flag
A request from anyone to a whole team (not a person).

| column | meaning |
|---|---|
| `id` (PK) | |
| `from_user`, `from_role` | Sender and their view (`front`, `clinical`, `doctor`, `admin`). |
| `to_role` | `front` \| `clinical` \| `ma` \| `coord` \| `pm` (v1.8: Medical Assistants, Patient Coordinators, Practice Manager) |
| `patient_id`, `case_id` (nullable) | Context. |
| `text` | What is needed. |
| `status` | `open` (on the receiving role's to-do) → `answered` (on the sender role's to-do with the reply) → `closed` (sender acknowledged). |
| `reply`, `replied_by`, `replied_at`, `closed_at` | |

Every create/answer is written to the patient audit trail.

## v1.8 additions: flag roles and provider scoping

### 10. Flag inboxes per staff role
`to_role` is always a whole team, never a person. Which inboxes a login reads (`flagTargetsOf()` in `src/surgery/v17/logic.ts`):

| staff role | view | reads flags sent to |
|---|---|---|
| Front desk | front | `front` |
| RN / LVN | clinical | `clinical` |
| Medical assistant | clinical | `clinical`, `ma` |
| Surgical (Patient) Coordinator | clinical | `clinical`, `coord` |
| Practice Manager | admin | `pm` (admin view also shows everyone's open flags) |
| Doctor / Surgeon / NP / PA | doctor | none (doctors send flags and get replies) |

MA, coordinator and Practice Manager get a separate "Flags for …" list on Today for their own inbox; those flags are not repeated in My to-do. A reply goes back to the sender by name (`from_user`), so only the person who asked sees the answer.

### 11. Provider scoping (row-level rule)
A patient is "mine" for provider X when any is true: `patient.primary_provider = X`; X is the surgeon on any of the patient's cases/episodes; X is on the care team with a surgeon/provider role. Name matching ignores case and a "(fictional)" suffix; in production use `provider_id`, not names.

- **Doctor/Surgeon/NP/PA logins:** every patient list, appointment, to-do, missing-note list, search result and Nightingale answer is limited to their own patients (plus visits where they are the visit provider). Enforce this on the server as a row-level filter; the browser build applies it once in `src/surgery/v18/scope.ts` (wraps `medRepo.patients()` / `visits()`).
- **Front desk, nursing, MA, coordinator, Practice Manager, admin:** see the whole practice. An optional provider filter in the top bar narrows lists (a filter, not a permission).
- **Covering:** a surgeon opens another surgeon's chart only through "Cover a colleague's patient" (Patients page, or the gate shown when a chart link is opened). A reason is required. It lasts for the session and writes an audit row: `action = chart.covering`, patient key, user, role, "Covering for <primary provider>… reason: …". Ending it writes "Covering ended". Suggested table:

| column | meaning |
|---|---|
| `id` (PK) | |
| `provider_id` | Who is covering. |
| `patient_id` | Whose chart. |
| `reason` | Required free text. |
| `started_at`, `ended_at` | Session-bound in the test build; production can expire after N hours. |

- The scheduler's provider columns stay visible to staff. A surgeon's scheduler shows only their own appointments.
- Seeds, migrations and background jobs always see the whole practice; scoping is for user-facing reads only.

### 12. Chat-only preference (v1.8)
`user_pref.chat_only` (boolean, per login; null = use the role default) and `role_default.chat_only` (per staff role, set by the Practice Manager/Administrator, audit `settings.chatonly`). This is UI only and changes no data access; provider scoping still applies.

## Future desktop & mobile apps (after real-life testing)
- **Shells, same app:** a desktop shell (Tauri preferred for size, or Electron) and a mobile shell (Capacitor, iOS/Android) wrap the same React web app. There is one codebase and one API.
- **Kevin's decision: store NOTHING on the device, and no offline use.** No PHI is kept locally. The shells do not cache patient data in browser storage (localStorage, IndexedDB, Cache API or service-worker caches). The browser-storage layer in this test build gets replaced by API calls. Session tokens live in memory or in the OS secure store (Keychain / Android Keystore / Windows Credential Manager) only. Without a network the app shows "offline" and no data.
- **Sign-in:** the API's identity provider must support installed apps through OAuth 2.0 / OIDC authorization code + PKCE, using the system browser and a custom-scheme or loopback redirect. Refresh tokens should be short-lived and rotated. The signing PIN stays a server-verified re-authentication.
- **Push notifications:** a server-side push service (APNs / FCM, plus desktop notifications) for new flags and to-dos. Notifications contain **no PHI**: no names, no clinical text, only something like "You have 2 new items in Vityls". The app fetches the details after sign-in.
- **Database:** the tables above are unaffected. You only need a `device_push_token` registration (user, platform, token, created/revoked) on the notification service side.

## Medical.Vityls v2.0 (same schema, fewer tables in use)

Medical.Vityls is the same codebase and the same database as Surgery.Vityls. The practice's edition (`practices.edition = 'MEDICAL'`) switches the surgical parts off. Nothing needs a separate schema.

**Used exactly as in Surgery:** `patient`, `encounter` (visits; `mode` = office, video or phone), `clinical_note`, `jot`, `role_flag` (all five teams, including Patient Coordinators), `owner_role` on tasks, provider scoping and covering (audit), chat-only preference, documents, payments, forms, labs, medications, problems, body charts and photos (generic, optional).

**Unused in Medical (leave empty; keep the tables):** `case` rows of kind `surgical` or `office-procedure`, `case_links`, `surgical_episodes`, `episode_items`, `quote` / quote versions, deposits, clearance and PCP-checklist data, ASC packets and ASC facilities, post-op schedules, block time.

**Optional in Medical:** `encounter.case_id` and the `case_id` columns on documents, payments and so on. Medical never sets them, so they are always `'general'` (or NULL). If you prefer, make the column nullable and leave it NULL for Medical practices.

**Workflow:** the flow state has 5 steps in Medical (Scheduling, Front desk, Nurse/MA, Doctor, Checkout) instead of 7. It is derived from the same facts; there is no extra table. Step 5 is done when the visit is closed.

**Medical to-dos come from rows that already exist:**
- `checkout_orders` of kind `follow-up` belong to the front office (book it).
- Referral orders belong to nursing or coordinators (send it).
- Refill orders belong to the doctor. Nightingale drafts the request as an order row with `status = 'to-do'`. Only the doctor approves or declines it, and staff send it through e-Rx (simulated in this build). Nightingale never sends or orders anything.
- Labs with `status = 'awaiting-review'` belong to nursing.

**Server rule (same as Surgery):** enforce provider scoping on the server. The browser filter is for testing only.

## ASC.Vityls v7.6 additions: role flags and the operative report

ASC keeps its v7.5 case workflow and stations. v7.6 adds two small tables plus two optional ones. Browser build: `src/v76/logic.ts` (rules), `src/v76/store.ts` (localStorage stand-in).

### asc_flag (one row per flag) and asc_flag_reply
| column | meaning |
|---|---|
| `id` (PK) | |
| `to_team` | `front`, `nursing` (incl. PACU), `anesthesia`, `surgeon`, `ma`, `coordinator`, `pm`. Goes to everyone on that team. |
| `to_user_id` | Optional. Set only for the automatic op-report flag (the case surgeon). |
| `from_user_id`, `from_team` | Sender. Replies go back to this person only. |
| `case_id` | Optional FK to the ASC case. |
| `kind` | `flag` or `opreport` (auto). |
| `body` | Free text. |
| `status` | `open` → `answered` → `done`. No due date and no Overdue state. |
| `sender_seen_at` | When the sender acknowledged the reply. |
| `created_at` | |

`asc_flag_reply`: `id`, `flag_id` (FK), `by_user_id`, `by_team`, `body`, `created_at`. Audit actions: `flag.send`, `flag.reply`, `flag.done`.

### asc_op_report (one per case)
| column | meaning |
|---|---|
| `case_id` (PK/FK) | |
| `surgeon_id` | The case surgeon. Only this surgeon (or a covering surgeon, if you add covering) can edit or sign. |
| `body` | The report text. Nightingale's first draft comes from the case: procedure, anesthesia provider and technique, OR event times, staff, implants, specimens, counts. Blanks are marked `[dictate]`. |
| `status` | `draft` or `signed`. Signed reports are locked; changes go through an addendum, like signed forms. |
| `drafted_by` | `Nightingale` (first draft) or `surgeon`. |
| `saved_at`, `signed_at`, `signed_by` | Signing requires the surgeon's PIN (same PIN check as forms). |

**Trigger:** when a case reaches PACU (`encounter_status` PACU or later), the server creates one `asc_flag` row with `kind = opreport`, `to_team = surgeon` and `to_user_id = case surgeon`. Do it server-side and make it idempotent per case. The to-do stays open until `status = signed`.

**Filing:** signing writes the report to the ASC chart (case record). The browser build stores it as the fact `opreport.signed` with audit `opreport.sign`.

### asc_op_report_copy (the surgeon's own copy)
`id`, `case_id`, `destination` (`surgery_vityls` | `secure_link`), `target` (Surgery.Vityls practice/provider id, or email address), `token` (secure link), `expires_at`, `status`, `created_at`. Audit `opreport.copy`.
- **Surgery.Vityls:** a server-to-server hand-off into the surgeon's own Surgery.Vityls chart. This needs a data-sharing agreement between the ASC and the surgeon's practice. Simulated in the test build.
- **Email:** the email carries only a link that expires (7 days) and needs sign-in. It has no name, MRN, procedure or date in the subject or body. Sending needs a BAA-covered email service, so it is simulated in the test build.

### Mobile
The op-report page is designed for phones (390 px). Push alerts for these flags must say only "You have a new task in Vityls", with no patient details. Nothing is stored on the device (same rule as the desktop and mobile shells).

## ASC.Vityls v8.0: the ASC edition on the Surgery codebase (data mapping; **no backend work yet**)

Henry: ASC backend work is **paused** (Kevin, Oct 21 2026). Nothing below needs building now. It records how the v8.0 front end
stores ASC data so the API can match it when work resumes. v8.0 keeps everything client-side (browser storage, fictional data only).

One app and one schema serve Surgery, Medical and ASC. `practice.edition = 'ASC'` turns on the ASC steps. The v7.6 station tables go away.

| ASC v7.5/7.6 data | v8.0 front end (today) | Target table (when work resumes) |
|---|---|---|
| ASC case / encounter | `asc8-cases` row: case id, patient, visit, date, time, minutes, room, surgeon, anesthesia, procedure, CPT, side, `loc` | `case` (same table), plus `room_id` and `encounter_status` (= `loc`) |
| 8 station records + "verified" checkboxes | One value per item in `case.d[itemKey]` (`{by, at}` or the typed value) | **`case_step`**: one row per case per item. Columns: case_id, step (preadmit, checkin, preop, anesthesia, or, pacu, billing), item_key, station, value_json, completed_by, completed_at, signed_by, signed_at. A "verified" flag is not stored; the server computes it from the required items |
| Step completeness | Calculated by `stepComplete()` / `currentStep()` | Calculated on the server from `case_step` (no stored flag) |
| Location (Scheduled → Checked in → In pre-op → In OR → In PACU → Discharged → Closed) | `case.loc`, moved automatically by `autoLoc()` and by the explicit actions (In room, Patient to PACU, Close) | `case.encounter_status`, plus an audit row for every move |
| Clinical facts (allergy confirm, NPO, ASA, airway, plan, EBL, wound class, implants, specimens, Aldrete, pain) | `case.d` keys of the same names | `case_fact` (keys unchanged from v7.6) |
| OR event times (in room, anesthesia start, incision, close, out of room, PACU in) | `case.events`. Changing a recorded time needs a reason; each change is audited | `case_event` (columns unchanged) + `audit` row `asc8.or-time`, with the old value, new value and reason |
| Forms, signers, signatures, addenda | Surgery form engine. The 23-template ASC set, with 4 merged templates, is configured per station. Signers are set per station | Shared forms tables (already common) |
| `asc_flag`, `asc_flag_reply` | `asc8-flags`. 9 teams: front, preop, pacu, anesthesia, surgeon, or, ma, coord, pm. `to_person` is used for person flags (the op-report flag) | Surgery `flag` / `flag_reply`: add teams `preop`, `pacu`, `anesthesia`, `or` and the nullable `to_person` |
| `asc_op_report`, `asc_op_report_copy` | `case.d.opReport` {text, signedBy, signedAt, copy, copyTo} + `asc8-outbox` | Surgery `note` with `type = op_report` + `note_copy` (via = `surgery-vityls` or `secure-link`). The secure-link email body carries no PHI |
| Billing, invoices, fee schedule | `asc8-fees` (per CPT: base, included minutes, per 15 min). Charges are computed from the OR minutes and the implant count | Kept; linked to `case_id`, with `fee_schedule` rows per practice |
| Providers, invitations, PINs | Shared Surgery staff/provider tables. ASC roles: Pre-op RN, PACU RN, Circulating RN, Scrub tech, Anesthesiologist, CRNA | Shared `staff` / `provider` tables, with the ASC role values added |

**Server rules for later** (enforced only client-side in v8.0):
- A station only reads and writes its own items.
- Surgeons see only their own cases.
- Only the case surgeon can sign the op report.
- PIN signing is checked on the server.
- A case cannot close until the op report is signed and the charges are posted.
- Nightingale may draft but has no sign, order or decide permission.

## v8.1 additions (2026-10-27) — ASC2 edition
Keys use the ASC2 case id (`asc8-cases`). The tables below come from the v7.7 layer and keep the same names.
### asc_intake
id, source (email|fax), from, received_at, subject, raw_text, status (new|booked|dismissed), case_id, draft_json (Nightingale pre-fill as confirmed by staff).
### asc_case_ai (one row per case; v7.7 tables folded into JSON columns or split as below)
asc_booking_check (case_id, item_id, received_by, at) · asc_records_brief (case_id, asa_suggested, asa_accepted, accepted_by, at, changed) · asc_bedside_draft (case_id, role nursing|anesthesia|surgeon, text, signed_by, signed_at) · asc_nurse_admission (case_id, items_json [id,label,value,source,verified], vitals_json, signed_by, signed_at) · asc_postop_orders (case_id, text, signed_by, signed_at) · asc_pacu_task (case_id, id, text, done_by, done_at) · asc_aldrete (case_id, at, activity, respiration, circulation, consciousness, spo2, pain) · asc_discharge (case_id, language, ride, text, patient_signed, signed_by, signed_at) · asc_followup_reply (case_id, at, text, concern, summary).
### asc_message_out (outbox, simulated)
id, case_id, channel (email|sms|portal|survey), to, subject, body, status (sent (simulated)|scheduled (simulated)), send_on, created_at, created_by.
### asc_block_time
id, surgeon, room, date, start, end, created_by (audited `asc81.block`).
### asc_medical_director (one per practice) · asc_privilege_application · asc_policy_attestation
director, designated_at · application: id, provider_name, specialty, submitted, items_json [k, verified], privileges[], status (Pending Medical Director Review|Privileges Approved|Returned), decided_by, decided_at, note · attestation: id, policy, attested_by (PIN), at, next_review.
### Audit actions added
asc81.bench (workbench events), asc81.md, asc81.block. Signatures always need the signer's own PIN (PinSign → verifyPersonPin).

## v8.2 additions (2026-10-27) — ASC2 edition
All prototype state is in localStorage (prefix `vityls:surgery`). Server-side suggestions in brackets.
- **Drawn signatures** `asc82-sigs`: `[{ id, title, name, role, at, png (data URL), caseId }]`. Every staff signature = own PIN (verified) + drawing; patient/responsible adult = drawing only. [Table `signature(id, case_id, signer_person_id|null, signer_name, role, kind: 'pin+drawing'|'drawing', purpose, signed_at, image_blob_ref)`; images in encrypted object storage.]
- **Pending booking** `asc82-pending-book`: `{ intakeId, patientId, date, time, room, provider, duration, reason, notes, source, anesthesia, email, phone }`. Written by Booking intake, consumed by the scheduler's Add appointment; the ASC case (`asc8-cases`) is created from the booked visit (`visitId` link) and the intake item becomes `booked`. [Server: intake_item → appointment → case, in one transaction.]
- **Patient matching**: exact normalised name + DOB (one hit) = link. Same name/near name, missing or different DOB, or duplicates = staff choice. Otherwise create a patient. The decision is audited (`asc82.bench`). [Server: the same rule plus phone/email as tie-breakers; never auto-merge.]
- **Per-case bench state** `asc81-ai[caseId].v82`:
  - `nursing { checks{itemId:{by,at,pre?}}, vals{vitals,npo,iv,adult}, signed }`
  - `anes { airway{mallampati,tmd,mouth,neck,teeth}, asa, exam{}, type, tech[], evalSigned, attest, preNote, pre }`
  - `surg { preOrders{text,signed}, postOrders{text,signed}, consentOk, hpOk, markOk, hpNote }`
  - `dc { patient{name,who,at,png} }`
  - `cards { idFront, idBack, insFront, insBack }` (JPEG data URLs)

  Signing writes the canonical case values (`vitals, npo, allergy, meds, iv, sitecheck, clearance, nursingForm, asa, airway, plan, anesConsent, consentConfirm, sitemark, hpUpdate, dischargeOrder, instructions, opReport`) through `S.setValue`, so the station panels, gates and audit stay one source of truth.
- **Practice access PIN**: off in ASC2 (`practiceUnlocked()` = true). [Server: role-based authorization for Practice instead of step-up PIN.]

---
## v8.3 additions
### New storage keys (localStorage prefix `vityls:surgery`)
- `asc83-case-pay`: `CasePay[]` {id, cid, pid, amount, method, ref?, receipt, by, role, at, when:'pre-service'|'check-in'} — mirrored into `patient-payments`.
- `asc83-cancelled`: archived AscCase + `cancelled:{reason, note, by, role, at}` (removed from `asc8-cases`; visit marked cancelled).
- `asc83-surgeon-colors`: Record<surgeonName, hex>.
- `asc83-op-full`: Record<caseId, FullOpReport>.
- `block-seed` entries gain `reason`, `notes`.
- `PendingBook.draft` (intake → booking prefill): name, dob, phone, email, sex, procedure, anesthesia, payType, duration, notes, assistant, equipment.
- Case `d.*`: `payType`, `anesType`, `quote` (numeric, patient quote), `bookingNotes`, `assistant`.
### Case money (derived, not stored)
`caseMoney(c) = {due, paid, balance, status}`; due = quote or estimate (self-pay 100% of fee, else 20%; default fee $2,500 — fictional). Flag window: DOS − today ∈ [7, 14] and status unpaid|partial.

### Full operative report
```ts
FullOpReport { cid, pid, surgeon, dos, procedure, status:'pending'|'dictated'|'signed',
  sections: { preDx, postDx, procedure, team, anesthesia, indications, findings, description,
              ebl, specimens, implants, drains, complications, disposition },
  updatedAt?, updatedBy?, source?: 'web'|'mobile', signed?: { by, at, sigId? }, version: number }
```
Status is derived: signed > dictated (all 14 sections non-empty) > pending. Signed reports are locked (addendum only). Drawn signature stored with the case signatures (sigId); PIN verified client-side in the demo.

### Mobile op-report API contract (to build later; web uses the same functions in `asc83/opreport.tsx` → `opApi`)
Auth: surgeon user token (OIDC); every call scoped to `surgeon == token.user`. Deep link per case: `ascvityls://op-report/{caseId}`.
| Method | Path | Body | Returns |
|---|---|---|---|
| GET | `/api/v1/surgeons/me/op-reports?status=pending\|dictated\|signed` | – | `OpListItem[]` {cid, pid, patientName, dos, procedure, status, deepLink} (cases in OR/PACU/discharged/closed) |
| GET | `/api/v1/cases/{cid}/op-report` | – | `FullOpReport` (blank pending if none) |
| PUT | `/api/v1/cases/{cid}/op-report` | `OpSubmit` {sections (partial), baseVersion, source:'mobile', by} | `FullOpReport` (version+1) |
| POST | `/api/v1/cases/{cid}/op-report/sign` | `OpSign` {by, pinVerified/ PIN re-auth, signaturePng, baseVersion} | `FullOpReport` status signed |
| POST | `/api/v1/cases/{cid}/op-report/audio` (future) | audio chunk | scribe suggestions per section (server-side ASR) |
Errors: `not-found` 404, `forbidden` 403 (not the case surgeon), `conflict` 409 (stale baseVersion — reload and merge), `locked` 423 (already signed), `incomplete` 422 (lists empty sections), `pin-required` 401. Every save/sign appends to the case audit trail. Pure transitions `applySubmit` / `applySign` in `asc83/oppure.ts` are unit-tested and are the reference behavior for the server.

---
## v8.4 additions
- **No gating:** `canMove(c, to)` always returns `''`. `moveWarnings(c, to): string[]` lists what is missing; `move()` stores it.
- `case.d.exceptions: Record<step, { items: string[]; by: string; at: ISO }>`. Steps written: `checkin`, `nursing`, `discharge`, plus loc keys from `move()` (`arrived`, `or`, `pacu`, `discharged`, `closed`). Every write is audited ("proceeded with exceptions …").
- **Station status** (derived, not stored): `stationStatus(total, done, exceptions, passed)` → `not-started | in-progress | done | exceptions`. Any exception means exceptions; a station the case has moved past with items missing also counts as exceptions.
- **Appointment popup** edits the existing case in place (`date, time, durationMin, room, surgeon, anesthesia, procedure, d.payType, d.anesType, d.bookingNotes`) and the linked visit. Delete is `cancelCase(reason 'Deleted from the schedule')` → `asc83-cancelled`.
- **Block time** writes to `block-seed` `{id, surgeon, date, start, end, room, notes}`, one row per day × room.
- **Surgeon colors:** same key `asc83-surgeon-colors`, now edited in Practice settings.
- **Forms:** fixed statements are not stored as editable values; the encounter form shows the template text read-only.

---
## v8.5 — Device session vs user session (clinical tablets)

**Device session** (`asc85-device` = {mode: front|admin|staff, id}): how the hardware is signed in. Staff mode = shared "Clinical tablet (Staff)" account; it can only show a read-only board, never edit or sign.

**User session** (`asc85-user` = {name, role, device, since, last, how: avatar+pin|pin}): the individual currently acting. Created only after PIN verification (`verifyPersonPin` against the person's hashed PIN; PIN-only lookup via `identifyByPin` must match exactly one person, otherwise the user taps their name). Failed tries increment the person's fail counter and log `session.pin.fail`.

**Idle timeout**: `asc85-idle-sec` (default 120 s, clamp 30–900, set in Practice settings, change audited). Activity (pointer/key/touch) refreshes `last`; when exceeded the user session ends (`session.user.timeout`) and the shared board returns. "Done" ends it immediately.

**HIPAA mapping (simulated)**
- 164.312(a)(2)(i) Unique user identification: every edit/sign runs as the named individual, never the shared device account.
- 164.312(a)(2)(iii) Automatic logoff: idle timeout above.
- 164.312(b) Audit controls: `repo.audit` events `session.device`, `session.user.start`, `session.user.switch`, `session.user.end`, `session.user.timeout`, `session.view` (tab/station opened), `session.pin.fail`, `session.idle.set`; each detail includes the device id.
- 164.312(d) Person authentication: PIN; production should use unique PINs + badge/SSO and server-side sessions.

## v8.6 additions (ASC edition) · browser keys → proposed tables
Pure shapes: `src/surgery/asc86/pure86.ts`. Storage: `src/surgery/asc86/store86.ts`. Every write is also audited (`repo.audit`, action `asc86.*`).

| key | table | shape / notes |
|---|---|---|
| `asc86-orders` | `order_set` (id, case_id, phase pre-op/post-op/pacu, signer_role surgeon/anesthesia) → `order_version` (v, items JSON, note, status draft/active/discontinued/superseded, author, proposed_by Template/Nightingale, signed_by/role/at, content_hash, ended_by/at/reason) → `order_ack` (by, role, at) and `order_exec` (item_id, by, at, note) | At most one active version per set. A new signature supersedes the previous active version. Never delete versions. Server must refuse signing by AI/System and check the signer's role against `signer_role`. |
| `asc86-vitals` | `vitals_row` (case_id, kind scheduled/adhoc, measured_time, entered_at, by, bp, hr, rr, spo2, temp, pain, note, corrects_row_id, correct_reason) | Append-only. A correction is a new row pointing at the original. Late = entered − measured > 10 min. |
| `asc86-discharge` | `discharge_confirmation` (case_id, criteria_by/at, auth_by/role/at, understood_who/method, copy, transport, escort, concern) | |
| `asc86-followup` | `follow_up` (case_id, owner, due, done_by/at, escalated_to/by/at) + `follow_up_attempt` (at, by, outcome, note) + `survey` (status, at) | The survey is kept separate from the clinical call. |
| `asc86-opreceipt` | `op_report_receipt` (case_id, received_at/by/via, signed_by/at) + `op_report_amendment` (by, at, note, hash) | |
| `asc86-closure` | `episode_closure` (case_id, reviewed_by/at/mode ai/manual, closed_by/at) + `closure_exception` (item_id, reason, by, at) + `episode_reopen` (by, at, reason) | Closure is never blocked. The close audit line lists the open items. Financial status is computed separately (charges + balance). |
| `asc86-sched-history` | `schedule_change` (patient_id, case_id, kind booked/rescheduled/cancelled, from, to, reason, notices[], by, at) | Keyed by patient so cancelled episodes stay linked. |
| `asc86-reminders` | `notification` (case_id, kind, send_on, body, status queued/replaced/cancelled) | Simulated. Henry: route through the BAA-covered SMS/email vendor. |
| `asc86-witness` | `consent_witness` (case_id, document, kind witness/representative, name, relation, at, recorded_by) | |
| `asc86-print-log` | `print_event` (case_id, kind print/export, what, by, role, at) | |
| `asc86-dupes` | metric counter | Replace with the `duplicate_prevented` audit count. |
