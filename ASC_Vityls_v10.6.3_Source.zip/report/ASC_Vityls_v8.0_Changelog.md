# ASC.Vityls v8.0 — Changelog (test build, fictional data)

The ASC edition now runs on the Surgery.Vityls codebase (branch `asc-v8.0`, from `surgery-v1.8`, includes Medical v2.0.1). Edition `ASC2` (`VITE_EDITION=ASC2` or `?edition=asc2`), own storage namespace `vityls-asc2~`. The legacy `ASC` (v7.6) path is untouched.

## What changed
- **Stations see only their own work.** There are 7 stations: Front desk, Pre-op nursing, Anesthesia, Surgeon, OR team, PACU and Billing/PM. Pre-op and PACU are separate.
  - Today and the chat to-do list show only that station's patients and missing items.
  - There are no tabs for other stations. Everything else is reachable via **See all roles** or the case record.
  - There are no empty boxes and no "Not yet recorded" cards. The patient header shows recorded facts only.
- **Step panels.** A step panel holds only the missing items, with a single "✓ Done" line for the rest. Save & close saves the work; a PIN is asked only to sign. Station forms are tucked away in a collapsible section.
- **Surgeon tab.** This is the Surgery Doctor workspace without the body chart or photos. It has a quick jot, plus Sign-offs, Op report & dictation, and Forms (every form configured for the Surgeon station). A Nightingale rail shows allergies, meds, problems and vitals.
- **Today.** Today is Surgery's patient view. The Classic board is retired; its room grid and bottlenecks moved to **Operations**, which also covers utilization, turnover, delays and a staffing link.
- **Carried over from v7.6:**
  - OR event times, where a change needs a reason and is audited.
  - Allergy green/red cards with Confirm/Edit.
  - NPO, ASA, airway/plan, EBL, wound class, implants and specimens.
  - Responsible adult, from check-in through handoff.
  - Aldrete score and discharge criteria.
  - Billing from an editable fee schedule.
  - Case color coding on Today, scheduler blocks and the Operations grid.
  - Flags (9 teams; see below).
  - Chat-only mode and provider invitation/PIN, through the Surgery staff tools.
- **Op report flow.** Patient to PACU → flag to the case surgeon only → note page (works on a phone, Nightingale draft, Dictate/Re-draft) → PIN sign (case surgeon only) → filed to the ASC chart. A copy goes to the surgeon's Surgery.Vityls, or, if the surgeon isn't on it, a simulated secure-link email with no patient details.
- **Scheduler.** Sideways Rooms/Surgeons toggle (OR 1–3 and the Procedure room), with stage-colored case blocks. The block-time overlay is off in ASC.
- **Forms.** The ASC set has 23 templates in Surgery's form editor.
  - Registration+Insurance, the two financial forms, H&P/clearance (two sources) and Nursing pre-op+MH/VTE are merged. An automatic check shows **0 fields lost**.
  - Discharge instructions gained an acknowledgment section.
  - Signers are configured per station.
  - The credentialing application now shows a **provider/practice header** (provider, specialty, NPI, facility, date) instead of a patient header. It stays in My Forms and is never placed on a patient case.
- **No telemedicine** in ASC (the appointment-mode picker is hidden).
- **Henry's note:** added the ASC data mapping (`case_step` etc.). No backend work; Henry is paused.

## Caveats
- All rules are enforced client-side only (no backend). External services are simulated, and all data is fictional.
- There are 9 flag teams (v7.6 had 7) because Pre-op and PACU are now separate.
- The credentialing header fix applies only to the ASC2 edition.
- "Document intake" uses Surgery's Email intake page. The plan's "Practice › Case steps" on/off editor is covered by Forms & workflow station assignments; there is no separate step editor.
