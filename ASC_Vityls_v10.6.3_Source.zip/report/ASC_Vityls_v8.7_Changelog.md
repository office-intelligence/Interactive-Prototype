# ASC.Vityls v8.7 — Changelog (from asc-v8.6.1)
All data fictional. External services simulated. Workflow never blocks.

## 1. Today redesign
- Header: greeting, ‹ / › day arrows, date picker, Today button, prominent **Upload documents**.
- Removed from Today: loose mm/dd/yyyy box, Nightingale workbench chips, Episode worklist, "Front desk · N patients".
- Left 2/3 **Today's patients**: timeline cards (time, name, age, sex, procedure, surgeon, room, status) with Check in / Chart / Cancel. Station chips only on the day of surgery.
- Future dates: no Check in (Hugo Pell is DOS tomorrow, which is why Check in did nothing before; it is now hidden for future cases and opens the check-in dialog for today's cases).
- Upload documents: patient → episode/DOS → document type, multiple files (≤1.5 MB kept inline, larger recorded by name/size); filed under that DOS in Documents › Pre-op & incoming records; audit `asc87.upload` + Nightingale activity.
- Right 1/3 **To-do list**: one list, typed colored icons (flag, payment, clearance/documents, forms, orders, scheduling, follow-up, closure), filter chips, each item states what/for whom and links to the right place. Payment items in the 7–14 day window → **Collect** opens the invoice.
- **Nightingale activity** panel: counts + recent list (simulated).
- Columns stack ≤900 px; 390 px no sideways scroll.

## 2. Chart
- "‹ Patients" now returns to the patient list (it previously set the tab that was already active) and sits at the left edge.

## 3. Practice Settings cleanup (ASC edition)
- Hidden: Modules, "Surgery centers you send to", Surgical episodes step table, Surgeon colors on the schedule, Price quotes.
- Schedule colors come from Administration › Providers first (old override map only as fallback).

## 4. Standard doctor's orders list (Practice Settings)
- One list (Pre-op / Post-op / PACU): category, text, drug, dose, route, frequency, active, signer role; add, edit, reorder, save (audited).
- 16 seeded entries with example doses, each labeled **"Example · for Medical Director approval"**.
- Case Orders "Start from standard list" pulls active entries for the phase with doses pre-filled; clinician can adjust and PIN-signs. Version history shows "(adjusted from standard X)". Nightingale still only proposes drafts.

## 5. Cash-pay invoice (v7.5 layout)
- Generated from procedure + fee schedule: number INV-ASC-YYYY-####, line items, deposits/payments applied, balance, status (Draft / Issued · unpaid / Partially paid / Paid in full).
- Manual Print only (print logged), Record payment (simulated card/cash/check).
- Reachable from chart Billing & payments (Invoice per case), Billing & Payments › Cash-pay invoices, and To-do payment items.

## Tests
- tsc: 68 errors (baseline unchanged). Unit: 180/180 (8 new in tests/asc87.test.ts). Walk `scripts/walk87.py` at 1440 + 390: 30/30.

## Partial / notes
- walk86 not re-run: it drives the removed Today workbench/worklist; those benches remain reachable via station chips and To-do links.
- To-do shows 10 items then "Show all"; payment items may sit below urgent items (filter chip shows them).
- Standard list is not yet versioned per Medical Director approval (save is audited only).
- Uploads >1.5 MB store metadata only (browser storage limit in this test build).
