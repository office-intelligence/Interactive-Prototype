# Case data model — v8.9 notes for Henry (fictional data)
New localStorage keys (via svRead/svWrite):
- `asc89-schedule`: FeeSchedule `{ name, facility{base,includedMin,perInc,incMin}, anesthesia{…}, surgeonFlat, items[], insuredSharePct }`. It migrates `asc88-fees` items. This is the one source for invoices and `caseMoney`.
- `asc89-credits`: Credit `{ id, pid, amount, type, method, ref, notes, at, by, role, receipt 'CR-…', applied[{cid, amount, at}] }`. Credit is applied oldest-first by `applyCreditTo` on invoice generation. `caseMoney.paid` includes applied credit, and each credit is also posted to the patient-payments ledger.
- `asc89-profile`: extended profile per patient (address, SSN, marital, interpreter, occupation, PCP, referring, payType, primary/secondary insurance, emergency[]). Core fields stay in `medRepo` patient. SSN is only ever shown masked (`***-**-1234`).
- `asc89-billcfg` (billing configuration tabs) and `asc89-claims` (claim status/notes, simulated).
- Case events: `EventKey` now includes `anesEnd`. It is not in EVENTS, so station completion is unchanged. Billing minutes: OR = inRoom→outRoom and anesthesia = anesStart→anesEnd, falling back to the booked duration.
- Upload/Doc gets `cat` (Pre-op Clearance | Nursing | Anesthesia | OP Reports | Other).
- Audit actions: `asc89.fees`, `asc89.credit`, `asc89.profile`, `asc89.print`, plus the existing case audit for OR time corrections (with reason).
