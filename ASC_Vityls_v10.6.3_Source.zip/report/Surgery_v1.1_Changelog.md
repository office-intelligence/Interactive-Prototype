# Surgery.Vityls v1.1 · Surgical Episodes (phase 1) · 2026-10-18

Built on v1.0 Front Door. ASC, Medical and the Portal are unchanged. All data is fictional and Nightingale is simulated.

## Kevin's rule
When a patient is booked for surgery, opening them goes to the **Surgery page**. That page shows **only what still needs doing**. Finished items drop out of sight and live in a collapsed **History** (the episode timeline). The full chart is one click away ("Open chart"). The chart has a "‹ Surgery page" button to get back.

## New
- **Surgical episode** (`src/surgery/episodes/`). It has stages Consult → Booked → Pre-op → Surgery → Post-op → Closed. Each item has an owner (front desk, nurse/coordinator, surgeon, ASC), a due date relative to the surgery or booking date, and a status. The episode links to the patient, consult visit, quote, payments, clearance, ASC packet and post-op visits.
- **Default checklist** (editable in Surgery settings › Surgical episodes):
  - Deposit due at booking; balance due 14 days before surgery.
  - Clearance suggested when the patient is 50 or older, or has HTN, DM, heart disease, OSA, CKD, a bleeding disorder or lung disease. The rule is editable, and the surgeon decides.
  - Clearance tests: **CBC, CMP (chemistry panel), UA, ECG, PT, PTT, chest x-ray (CXR)**. Each goes requested → received → surgeon-reviewed (PIN).
  - ASC packet sent; ASC confirms the packet is complete, or lists what's missing from its required items.
  - Day-before reminder plus a pre-op instructions template.
  - Post-op visits proposed at POD 1/7/30/90, with photo milestones.
  - Close episode. No automatic PDF.
- **Surgeries** in the sidebar. A board or list by stage, showing only open items per patient. Dots: red = overdue, amber = due within 3 days, green = on track. A role filter (Front desk / Nurse-coordinator / Surgeon / All) defaults to your role. Tablet-friendly, with 44 px targets.
- **Surgery page**: Nightingale brief and flags, then "Next to do" grouped by owner, each with a one-tap action:
  - Collect deposit or balance (simulated payment)
  - Draft request to PCP; upload / mark received; draft chase
  - Review & initial (PIN)
  - Send to ASC; check ASC reply
  - Draft instructions; book proposed post-op visits
  - Rx set (PIN); close episode
- **Today › Worth your attention** now includes episode items that are overdue or due within 3 days.
- **Nightingale** (drafts only; staff review and send, simulated):
  - The clearance request to the PCP, with the test checklist.
  - A simulated read of an uploaded clearance document that pre-ticks items for staff to confirm.
  - Chase letters for missing items, payment reminders and warnings, and day-before instructions.
  - A proposed post-op schedule and stale-data flags.
  - It never signs, orders, or gives a go/no-go opinion.
- **Start surgery** button on an accepted price quote.

## Quick fixes
- Respiratory rate field at the Nurse station (the ambient script fills it too).
- The clearance letter "To" field defaults to the patient's PCP, not Cardiology.
- Add New Patient checks name + DOB for an existing chart. It offers "Start new surgical episode", "Open existing chart" or "create a new chart".
- A returning patient's new episode adds "Reconfirm" items. Allergies, medications and history are always reconfirmed. ID/insurance cards and forms are reconfirmed when older than 12 months (the limit is editable).
- Quick post-op prescription sets (pain + antibiotic, a non-opioid option, and a penicillin-allergy option) at the Doctor step and in the episode. They stay drafts until a provider signs with a PIN (simulated eRx).
- Reminder confirm links (`#confirm=<visit>`) now open the app and record the confirmation.

## Demo data (fictional)
- **Mary James**, 55, HTN + DM, open rhinoplasty in 16 days, mid pre-op. Deposit paid; clearance requested; CBC/CMP/UA/PT/PTT/CXR received; **ECG missing**; balance due in 2 days.
- **Carol Bennett**, 61, a returning patient. Her 2024 blepharoplasty episode is closed. A new facelift episode is at Consult with stale items to reconfirm.
- PCP: Elena Marsh, MD (fictional). No real doctors appear on any care team.

## Tests
- Regression suite smoke13 (768 + 1180) on the v1.1 build: **842 / 842** (420/420 per width at 1180 as before, plus the 768 run).
- UI walk: **36 / 36**. Unit tests: **16 / 16**.
- New unit tests: `npx tsx --test tests/episodes.test.ts`. They cover the episode logic, the show-only-open-items rule and the default clearance list.
- New UI walk: `surgwork/fd/shots_v11.py` at 1440 / 1180 / 820.

## For Henry
Tables: `surgical_episodes` and `episode_items` (shape in `episodes/logic.ts`), plus `episode_settings` per practice. Storage keys: `vityls:surgery:episodes` and `vityls:surgery:episode-settings`.
