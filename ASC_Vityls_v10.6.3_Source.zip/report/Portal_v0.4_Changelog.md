# Vityls Patient Portal v0.4: Kevin's iMARSLINK design on Vityls Core (2026-10-15)

Branch `portal-imarslink` (from tag `portal-v0.3`), tag `portal-v0.4`. Test build `Vityls_Patient_Portal_v0.4.zip`: `index.html` opens the Portal, `?practice=coastline` opens the practice side.
Kevin's original files (`/workspace/vityls/kevin_portal_design`) were not modified. His look was ported; his mock data was not.

## Architecture
- `src/portal/imarslink/ImarsPortal.tsx`: the new UI (header, chat front page, portal view, timeline, Labs, task dialog). `PortalApp` now renders it; the v0.3 shell stays as `LegacyPortalApp`.
- `src/portal/imarslink/usePortalData.ts`: the translation layer. The screens read and write only through the v0.3 data layer (`store.ts` account, `hub.ts` portal_items / append-only interactions / notifications / caregivers, `finder.ts`). It also holds hash routes, the timeline builder, the grouped Nightingale task message and Free/Plus entitlements.
- `src/portal/imarslink/imarslink.css`: his teal/slate look. Tailwind utilities are used only inside the `.imx` Portal root. The reused v0.3 sections (Care team, Finder, Connect, Family, History, Documents, Medications, Plan, Messages) are restyled under `.imx-legacy`.
- Module `patient-portal` (already in `src/core/modules.ts`). Entitlements are per patient (Free / Plus trial / Plus). Everything a practice sends is never paywalled.

## Kevin's design decisions
1. **Front page is a clean Nightingale chat.** The incoming-tasks panel is gone. A self-signed-up patient with no practice sees only Nightingale.
   - Office tasks arrive as one grouped, conversational Nightingale message with inline buttons (Fill out form, Check in, Pay, Confirm, See the result, Open document, Read message, Review a connection request).
   - There are no toasts. The bell with a badge is secondary and opens Notifications.
2. **Deep links.** `#portal/task/<itemId>` opens the exact form, check-in, payment, reminder, result, document or message.
   - Signed out, it asks to sign in first and then opens the item.
   - `#portal/view/<section>[/<focus>]` opens a section.
3. **Compact timeline.** Each event is one line: icon, title, date · practice, and a status chip. Tapping expands it to show details, actions, "Explain in plain English", and links to Labs, Documents, Messages and Care team.
   - Tasks, results, documents, appointments/check-ins, payments, messages/refills, connections and records requests all appear.
   - Filters: All, To do, Appointments, Results, Documents, Messages, Payments.
4. **Labs section.**
   - A table of date, tests, source/practice, abnormal flag and "View result".
   - A result view with calm plain-language framing for values outside the range ("common and often temporary… worth discussing with your doctor"; no diagnosis).
   - Per-analyte trend charts (the v0.3 trend). Lab events and result tasks link into Labs.
5. **v0.3 features kept, restyled:**
   - Guest mode: 3 free explanations, then sign-up; the 911 answer is never gated.
   - Carousel under the chat.
   - Proactive question cards inside the chat, one at a time with "N more questions".
   - The 911 emergency catch.
   - Connect my doctor (FHIR, simulated), records request, upload link.
   - Practice Allow/Revoke.
   - Family access with profile switching (header and mobile).
   - Doctor Finder on finder.ts.
   - Append-only history.
   - Free/Plus.
6. **Fixes:**
   - No horizontal overflow at 390 px in any section.
   - The task dialog is `role=dialog` / `aria-modal`, moves focus in, traps Tab, closes on Esc and returns focus.
   - aria-labels on the bell, send button, chat input and section nav.
   - Wording: "Health guide" instead of "Clinical AI"; no "diagnosis/command" prompts.
   - Refills are "Request refill".
   - A neutral placeholder avatar (the mock-up photo is not used).
   - No real doctors from the mock-up. Demo practices are the fictional Bayview Family Medicine / Dana Kim, MD (seeded with backdated history) and Coastline Plastic Surgery / Sam Patel, MD (left unlinked for the practice demo). The Finder's real public NPI snapshot is unchanged.

## Tests (2026-10-15)
| Suite | Result |
|---|---|
| Portal v0.4 (`scripts/portal_ptest4.py`): guest, deep links, grouped chat tasks, no toasts, task dialog a11y, Labs, timeline, practice flow, family, Finder/Connect/Plan, 390 px overflow | 60 / 60 |
| Doctor Finder v0.3 suite on the v0.4 build (navigation adapted to the new shell) | 30 / 30 |
| Core module checks (`modtest_portal02.py`, Core build from this branch) | 44 / 44 |
| Surgery smoke13 (Core build from this branch, 768 + 1180 px) | 739 / 739 |

The v0.1/v0.2 Portal suites drive the old sidebar shell and were not rerun as-is. Their behaviors are covered by the v0.4 suite.

## Simulated / not finished
- Still simulated: email/text/push, card payments, FHIR sign-in, fax/Direct, wearables. Nightingale's answers are scripted, not live AI.
- Practice and Portal sync only within one browser until Henry's server exists.
- Practice-side items still go out from the Portal test page. They are not yet wired from Messages, At-home/Intake, Billing and Scheduler, and a Portal check-in doesn't update the Today board.
- Not built yet: the voice input, monthly health summary, health journal, CGM/BP/activity charts and insurance-ID card from the mock-up. They have no data behind them yet (Plus/wearables tables needed).
- The deep-link URL is shown in the task dialog. Real texts/emails will carry it once messaging (Twilio/SendGrid with a BAA) is connected.
