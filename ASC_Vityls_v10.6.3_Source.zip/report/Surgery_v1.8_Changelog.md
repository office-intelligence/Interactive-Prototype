# Surgery.Vityls v1.8 changelog (from v1.7)

All data is fictional. External services are still simulated. Nothing from v1.7 was removed.

## Answer: in v1.7, could one surgeon see another surgeon's patients?
Yes. Nothing filtered by the logged-in provider: `medRepo.patients()` / `visits()` (`src/med/record.ts`) returned everyone, so the Patients page, search, Today, the Scheduler, to-dos and charts were all practice-wide. Only the doctor's missing-note list was limited to the doctor's own visits. v1.8 fixes this.

## What changed
1. **More flag teams.** Flags can now go to Medical Assistants, Patient Coordinators and the Practice Manager, as well as Front office and Nursing. A flag always goes to the whole team. MA and coordinators keep the Nurse/MA view, and the Practice Manager keeps the manager view. Each of these roles also gets a short "Flags for …" list at the top of Today. Replies go back to the person who sent the flag. Seed flags were added for each new team.
2. **Rounded chat box.** The opening Nightingale box on the Chat/Today page is now a rounded pill like the other chat boxes.
3. **Each surgeon sees only their own patients.** A Doctor/Surgeon login sees only patients, appointments, to-dos, missing notes and search results where they are the patient's provider or the case surgeon. The top bar says "My patients".
   - **Staff still see the whole practice.** This covers front desk, nursing, MA, coordinators and the Practice Manager. A new provider filter in the top bar narrows the lists.
   - **Covering.** To open a colleague's patient, a surgeon uses "Cover a colleague's patient" and gives a reason. This is recorded in the audit log. Opening a chart link to a non-covered patient shows the same Cover step first.
   - **Second surgeon.** Dana Whitfield, MD (fictional) was added with three patients of her own (Iris Calloway, Marcus Fenwick, Lena Okafor) and today's visits.
   - **Scheduler.** Staff still see every provider's column.

4. **Chat-only mode.** Each user can turn this on for themselves from "Chat only" in the top bar. The Practice Manager or Administrator can also set it as the default for a role from the same menu, and that change is audit-logged. When it is on:
   - the side menu and nav are hidden, and the user always lands on Chat (their to-do, Nightingale and flags);
   - chat cards and to-dos open their workspaces full screen (note page, panels, body chart, photos, payments, forms), and Save & close returns to chat;
   - the top bar keeps "Find chart" (search), "← Chat" when away from chat, and the switch to turn the mode off.
5. **Fix found during testing.** Provider scoping now sits on top of the existing hidden-patient filter, so hidden charts stay hidden.

## Tests
- Unit tests: 95/95 (84 from v1.7 + 11 new in `tests/roles18.test.ts`).
- Walk-through `scripts/shots_v18.py` at 1440/1180/768: 180/180. This includes the whole v1.7 walk, flag roles, provider isolation, covering and chat-only mode.
- Smoke regression `scripts/smoke_v18.py` at 1180 only: 388/389. The one failure is a legacy v0.11 step (a Practice modal Back/close click) that timed out. It does the same in two runs and matches the timeout flagged in v1.7. Earlier runs also caught two real bugs, both fixed: scoping bypassed the hidden-patient filter, and the old test expected 3px corners on the chat box. That assertion now checks for the pill.

## Files
New: `src/surgery/v18/` (logic, scope, seed, ui, css) and `tests/roles18.test.ts`. Extended: `src/surgery/v17/{logic,store,ui}`, `SurgeryApp.tsx` (seed, scope, provider filter, cover gate), `SurgeryChart.tsx` (Cover button) and `v07/Today7.tsx`.
