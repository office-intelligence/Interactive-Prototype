# ASC.Vityls v8.8 — Changelog (from asc-v8.7)
Fictional data · external services and payments simulated · workflow never blocks.

## 1. Station-to-station journey bar
- Every station (Pre-op/records, Check-in, Nursing, Anesthesia, Surgeon, PACU, Discharge, Follow-up, Closure, Orders) shows the patient's journey across the top: Booking › Pre-op/registration › Check-in › Nursing admission › Anesthesia › Surgeon › OR › PACU › Discharge › Follow-up › Closure, with numbered/checked circles. The current station is highlighted ("HERE").
- Tapping a step opens that station for the same patient, with no return to Today and no gates (you can jump ahead).
- Single-panel stations (booking details, check-in, OR step, surgeon tab) get the same bar docked at the top of the screen.
- Patient switcher: the existing dropdown plus a "Next patient ›" button.
- No done-steps recap was added (per Kevin's markup).

## 2. Today
- Removed the general Upload documents button. Upload now lives in each chart under Documents (DOS + type picker, audit log kept).
- The five stat boxes are smaller and sit on one line (also at 390 px).
- Patient cards are light blue when cleared to proceed (checked in, or nothing missing on the booking checklist) and light amber when something is missing. The left color bar is removed.
- Station chips: the status text is gone. A green dot means started/done and a red dot means not started. Each station has its own colored badge matching the station icon colors.
- The To-do list has a tinted background.

## 3. Check-in checklist auto-Received
- Uploads link to checklist items by document type: Pre-op H&P→H&P, Medical clearance→Pre-op clearance, Lab results→Labs, ECG→ECG, Consent/Surgical consent→Surgical consent, Registration forms→Admission forms, Ride home & caregiver→Ride, Post-op care location→Post-op location.
- Paid in full → Fees paid.
- The manual "Received" toggles remain as an override.

## 4. Block time
- Start date, end date, Mon–Sun toggles, OR, and start/end times generate the recurring blocks in the range, with a live preview and count. Clash check and audit are kept.
- Block cards on the scheduler use the assigned surgeon's Providers color.

## 5. Cash-pay invoice + fee schedule + facility profile
- Practice Settings › Fee schedule: itemized categories (Facility fee, Anesthesia, Implants, Supplies, Pathology, Other) with add/edit/remove, an active toggle, an optional procedure keyword, and extra-time items. Saves are audited. Example prices.
- Invoices are built from this list: base items, plus procedure-matched items, plus extra time beyond 60 min.
- The invoice letterhead shows the logo, name, address, phone/fax, email, website, tax ID and NPI.
- Practice Settings › Facility profile & logo: logo upload (PNG/JPG/SVG ≤512 KB) with preview, and all contact fields. The placeholder facility is "Harborview Surgery Center (fictional)".

## 6. Background
- Light cream page background (#FAF7F0) on all pages, with white rounded cards. Print stays white.

## 7. Payments
- Every Collect payment button (check-in, chart Billing, invoice, To-do → invoice) opens the standard v7.5-style card-processing popup: amount due, card/cash/check, name, number, exp, CVV, ZIP, then a receipt.
- It is clearly marked "Simulated until payment gateway connected".
- One adapter point: `src/surgery/asc88/gateway.ts`. Only the card brand and last 4 digits are stored.

## Tests
- tsc: 68 (baseline).
- Unit tests: 187/187 (7 new in tests/asc88.test.ts).
- `scripts/walk88.py` at 1440 + 390: 41/41.
- The v8.7 walk was not re-run as-is because it uses the removed Today upload button; its flows are covered by walk88.

## Partial / notes
- The OR step and booking details are existing single-panel dialogs, so their journey bar is docked at the top of the screen rather than inside the panel.
- The patient switcher lists the day's cases (plus the opened case if it is on another date).
- "Cleared to proceed" uses the booking checklist. Abnormal labs still show blue unless an item is missing.
- The fee schedule replaces the CPT fee table for invoices only. Case balance estimates still use the existing payment estimate. Make "invoice total = estimate" a decision for Henry and Kevin.
- No real gateway; card fields are plain inputs in this test build (live = vendor iframe/tokenization).
