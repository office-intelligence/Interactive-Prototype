# ASC.Vityls v8.4 — Changelog (branch asc-v8.4 from asc-v8.3)
Fictional data · external services simulated · PIN only for signing · no automatic PDF · Anesthesia workbench unchanged.

1. **Plain white page everywhere (ASC2):** the gray canvas and the framed/rounded white content panel are gone on Chat/Nightingale home, Today, Patients/chart, Scheduler, Messages, Billing, Operations, Practice settings and full-screen forms. Cards that used a gray fill are white too.
2. **The workflow never blocks:** `canMove` no longer gates; `moveWarnings` lists what is missing. Moving on records `case.d.exceptions[<step>] = {items, by, at}` and audits "proceeded with exceptions".
   - Check-in: "Check in with exceptions (n)".
   - Nursing admission: "Sign with exceptions (n)", recording only the items that were ticked.
   - Discharge: "Discharge with exceptions (n)" with a list of what's missing.
   - To PACU no longer needs the out-of-room time.
   - Missing items show as light-yellow notices and stay on the to-do list.
   - Requirements kept on the document being signed: consent attestation, H&P/site-mark attestation, and the op report can only be signed once the case has started.
3. **v7.7 popups:**
   - **Add new appointment / Appointment details** has a Billing chip and a 4-column grid: DOS, start, length (v7.7 labels, e.g. "1.5 Hours (90 Mins)"), OR; patient search after 3 letters with clear, DOB, age, phone; procedure; surgeon, anesthesiologist, anesthesia type, payment type (required); notes. Footer: Delete, Open chart, Save appointment.
   - The same popup is used for new appointments, clicking an existing case on the schedule, and intake Confirm & create (prefilled).
   - **Block operating room time** has three sections: Provider / Assignee; Operating Room & Time Window (with "All configured rooms"); Select Days of the Week to Block (2 weeks of day cards, plus all-weekdays/clear). The footer shows selected days and "Total blocks to generate".
4. **Scheduler:** the surgeon-color strip is removed and the case-type legend is shown. Cases keep their surgeon colors, which are now set in Practice settings → Surgeon colors on the schedule (also in Settings).
5. **Today:**
   - Flags have a rose tint and "Collect before surgery" has an amber tint.
   - Every patient row (station view and all roles) has chips for Front desk, Nursing, Anesthesia, Surgeon, OR, PACU and Discharge. Each shows a status (not started / in progress / done / exceptions) and opens that station for the patient.
6. **Forms:**
   - Long text fields auto-size to show in full, with no inner scroll bar.
   - Fixed legal/consent statements (template text ≥ 60 characters, e.g. consent terms, anesthesia consent, personal items, discharge acknowledgment, card authorization) are read-only in the encounter form, labelled "fixed statement", and edited only in the form editor/Settings.
7. **The text "Close" button is removed from the form footer**; the X stays.

Tests: unit 158/158; walkthrough walk84.py 222/222 (74 checks each at 1440, 1024 and 390); tsc stays at the 68 pre-existing errors.
