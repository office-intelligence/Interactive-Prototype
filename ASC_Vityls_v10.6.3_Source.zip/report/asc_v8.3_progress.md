# ASC.Vityls v8.3 progress
| Item | Status |
|---|---|
| Booking popup (Add appointment, intake prefill) | Done |
| Block time popup | Done |
| Surgeon colors | Done (legend editable) |
| Today white page | Done |
| Case details popup + cancel with reason | Done |
| Check-in flow + handed to nursing + board pill | Done |
| Collect at check-in / 7–14 day flag / Unpaid cases | Done (fictional estimate rule) |
| Forms full screen with X | Done (FormPage footer still also has a "Close" text button) |
| Surgeon links + hold-to-talk brief op report | Done (simulated scribe) |
| Full operative report + mobile API contract | Done in web; contract documented; no mobile app/HTTP server |
| Nursing GLP-1 + recovery facility | Done |
| ASC chart: Overview / Documents / Billing | Done; print = browser print of a text packet + card images; export = .txt |
| Anesthesia workbench | Unchanged (verified in walkthrough) |
## Partial / notes
- Patient-responsibility estimate is a fictional rule (no real eligibility/clearinghouse).
- Documents "Print all" prints a text packet + images, not pixel-identical copies of each form.
- Cancelled cases are archived (not soft-deleted in place); reschedule = book again.
## Was "collect at check-in" in v8.2?
Partially: chart Account had a patient-level "Collect payment" and check-in had an "Insurance verified / deposit" text field, but no collection inside check-in and no per-case balance. v8.3 adds both.
