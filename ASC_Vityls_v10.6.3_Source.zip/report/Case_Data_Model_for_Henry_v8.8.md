# Case data model — v8.8 additions (for Henry)
Fictional test build; browser localStorage.
- **Journey**: derived, not stored. `currentStep(loc, {followUpDone, closed})` in asc88/pure88.ts maps the case location to the 11 steps.
- **Checklist links**: `DOC_TO_CHECK` maps upload document type to checklist ids. The checklist state is the OR of uploads by type, payment status `paid`, and the manual override (`ai.checklist[id]`).
- `asc88-fees` → **fee_item** {id, cat, label, amount, procedure? (keyword/regex), active}. Invoice lines are built by `feeLines(items, procedure, minutes)`.
- `asc88-facility` → **facility_profile** {name, address, city, phone, fax, email, website, taxId, npi, logo (dataURL; in production store as an asset URL), logoName}.
- Block time: unchanged record shape {id, surgeon, date, start, end, room, notes}. One record is generated per date in the range on the selected weekdays.

## PAYMENT GATEWAY ADAPTER (single integration point)
- File: `src/surgery/asc88/gateway.ts`. Interface: `PaymentGateway { name; live; charge(ChargeRequest): Promise<ChargeResult> }`.
- Today: `simulatedGateway`, which does Luhn/expiry/CVV checks; a card ending 0002 is declined; nothing is charged.
- Going live:
  - Implement the interface with the vendor's tokenizing SDK (hosted fields/iframe, so PAN and CVV never touch our servers; PCI SAQ-A).
  - Call `setGateway(live)` at startup.
  - Persist only the token reference, brand and last 4.
- All Collect buttons call `chargeCard()` from the popup (`CardPayDialog` in asc88/ui88.tsx). On success the popup posts the case payment via `collectPayment()` (asc83/pay.ts) and shows a receipt.
- Before go-live: webhooks for async settlement/refunds, idempotency key = caseId + receipt, server-side amount validation against the invoice balance.
