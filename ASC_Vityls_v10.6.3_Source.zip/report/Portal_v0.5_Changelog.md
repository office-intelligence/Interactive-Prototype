# Vityls Patient Portal v0.5 (2026-10-15)

Branch `portal-imarslink`, tag `portal-v0.5` (built on `portal-v0.4`). The data layer is unchanged: store, hub, finder and `usePortalData`. Only the shell and the look are new.

## What was taken from where
**Microsoft Copilot screenshot (Kevin's notes)**
- A left sidebar with the logo and a **Chat | Portal** toggle where Copilot has "Cowork".
- New chat, Search, a few grouped links, a past chats list, and the profile with a gear and "Upgrade to Plus" at the bottom.
- A centered greeting, "Hi Jordan, what can I help you with?", over one large rounded message box with a **+** for uploading labs, visit notes or documents.
- Chips under the box: Upload labs, Explain a result, plus live tasks from the practices ("Check in", "Bayview forms", "Pay $35 bill").

**iMARSLINK upload**
- Timeline cards: an uppercase type tag (e.g. "UPCOMING OFFICE VISIT"), a calendar icon and date, a status chip on the right, a bold title, the practice line and a description line.
- Colored ring icons on a vertical line, filter pills, and the profile card next to the timeline.

**Nightingale concept PDF (2012)**
- "You at a glance" card: a one-sentence summary of the patient, today's to-dos, allergies and doctors.
- "Medical journal" vertical timeline with year markers.
- Lab results on a spectrum bar ("Worth discussing ↔ Usual range") with the trend history.
- A plain-English Explain on every lab and document.
- Not used: real names and photos.

## What changed
- **Three pages:**
  - AI Chat (hero layout, then a conversation with the message box docked at the bottom).
  - Portal Timeline (Past and Upcoming).
  - Portal Details.
- **Navigation:** Timeline · My Doctors (Care team, Find a doctor, Connect & records) · My Labs · My Health (Medicines, allergies & conditions; Documents; Wearables & journal; Family access) · Messages (Messages & refills, Appointments, Activity history). Billing & payments, Plan, Notifications, Settings and Sign out are in the profile menu.
- **Reminders:** one short Nightingale line, "You have N things to finish from …", with a link for each item. The grouped card and the toasts are gone. The bell stays. The real channel is text/email deep links (`#portal/task/<id>`). Settings has text/email preferences (simulated).
- **Timeline:** compact cards on a vertical line with colored nodes for each event type. Each card shows the type tag, date, status chip, title, practice and a one-line summary; tap to expand. Upcoming and Past sections. Nightingale offers "You have N things left to do. Want me to show you?", which filters to To do.
- **New pages:** Conditions (inside Medicines), Wearables & journal, Appointments (list and request), Billing, Settings.
- **Chat:**
  - The + upload files the document and adds it to the timeline.
  - New chat archives the conversation into the past chats list.
  - Search covers chats and timeline events.
  - The proactive question shows as a single line, "Answer it".
  - The carousel is now a faint one-line example.
- **Palette:** cream and ivory backgrounds, terracotta, peach and amber accents, with Nightingale green as the brand color. Soft shadows. 3px corners on cards and buttons; the bubbles, chips and message box are rounded. No thick left borders (tested).
- **Mobile:** below 1024px the sidebar becomes a drawer opened by the hamburger. It closes on navigation and on sign-in. No overflow at 390px in all 16 sections.
- **Unchanged guardrails:**
  - No diagnosis and no go/no-go advice.
  - Calm wording for values outside the range.
  - The 911 catch is never gated.
  - Practice items are always free.
  - Everything is simulated until a BAA is signed.

## Tests
- `scripts/portal_ptest5.py`: 91/91 (v0.4's 60 checks adapted, plus 31 new ones for the shell, navigation, profile menu, upload, chats, search, timeline sections and offer, new pages, drawer, and no thick borders).
- `scripts/portal_ptest3_on05.py`: 30/30 (finder regression).
- Core regression on a fresh Core build of this branch (`Vityls_Core_Modules_portal05`): modtest 44/44, smoke13 739/739.

Screenshots: `report/portal_v05_screens/` (01–21, plus `_reg_finder/`).
