# Medical.Vityls v2.0 progress (branch medical-v2.0 from tag surgery-v1.8)
Pattern: same codebase, VITE_EDITION=MEDICAL (isMedical gates + src/surgery/medical/terms.ts). Surgery behavior unchanged.
NOTE: an older "Medical_Vityls_v2.0" (Front Door, Oct 16, commit 86e3f86, untagged) exists; its zips are moved to *_prev-2026-10-16.zip before repackaging.
Steering: KEEP Patient Coordinator role (shares Nurse/MA view, flag target + flag list); only surgical coordination tasks go away.
Steps: [x] 1 audit medical build of v1.8  [x] 2 gate cases/quotes/booking/ASC/postop  [x] 3 workflow 5 steps + medical to-dos  [x] 4 seed 2 doctors  [x] 5 tests  [x] 6 shots/smoke/grep  [x] 7 docs/tag/zip
- step 2-4 part: FLOW_MED 5-step flow, medOrderTodo (follow-up/referral/refill), SurgeryApp LEGACY_MED=false, seed20 (Patel+Whitfield)
- ws/case gating + shots_med20.py written
- covering/todo/quotes gating, order panels; rerunning shots
- unit 104/104 (incl. tests/medical20.test.ts 9); shots_med20 132/132, wording scan 0 hits; Surgery v1.8 shots on this branch 180/180; Henry doc Medical section; smoke 1180 running (scripts/smoke_med20_v2.py)
- smoke 1180: 241/260 (19 FAIL: legacy v1.0/surgical checks + some unverified: scheduler column selector, fd icon rail, IndexedDB template, packet/hipaa parts stopped); rerunning shots on final build
- final: unit 104/104, shots 132/132 (0 wording hits), smoke 241/260; tagged medical-v2.0; zipped
