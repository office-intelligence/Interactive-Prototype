# ASC.Vityls v9.0 — Changelog (test build, fictional data)
Built from asc-v8.9. Branch/tag `asc-v9.0`. tsc 68 · unit tests 200/200 · walk90 146/146 (1440 + 390).
Goal: the Today and Patient pages look like the Mockup v2 pages, with every v8.9 function kept.

## Today (`asc90/today90.tsx`)
- **Left summary card:**
  - Date nav (arrows, picker, Today) at the top, then "Today · Wed, Oct 28" with the rooms and the first case.
  - A 2×2 grid of stat tiles: cases, in progress, not cleared, late start.
  - The Case flow line.
  - Clearance legend: **Cleared / Pending items / Missing items**. "Hold" is renamed because nothing holds a case.
  - A Nightingale note with an "Open case" link.
- **Collapsible cards** for the To-do list (counts and type filters kept, compact) and the Nightingale activity (collapsed by default).
- **Main area:** "Today's case flow" with the mockup subtitle and room pills (All / OR 1 / OR 2 / OR 3 / Proc 1).
- **Timeline:** mockup timeline with station-coloured circle icons and a red **Now · time** marker.
- **Case cards:**
  - Header: time · room, name, procedure · surgeon · anesthesia type.
  - Status chips on the right (clearance + current station). Readiness now shows as a chip instead of a whole-card tint.
  - Small Check in / Chart / Details / Cancel actions. Tapping the card opens the chart.
- **Station pills:** a full-width row: Front desk, Pre-op, Anesthesia, OR, PACU, Discharge. Done pills are mint with a ✓, the current one is solid terracotta, and the rest are beige. Each pill opens the station slide-over.
- **Seed:** 2 Proc 1 cases added (Iris Navarro, colonoscopy, in pre-op; Jonah Reyes, lesion excision, scheduled), for 9 same-day cases.

## Patient page (`asc90/chart90.tsx`)
- **Left column:**
  - Identity card: avatar, name, age · procedure, status chips.
  - LIVING SUMMARY (a Nightingale draft built from the record).
  - Allergy card: red when allergies are recorded, green for NKDA. Confirm is audit-logged as `asc90.allergy-confirm`; Edit opens Profile.
  - Clearance docs · via send-to-ASC, with Received / Missing chips.
  - Needs attention plus the account block (balance and available credit).
  - Today's cases quick switch.
  - Care team.
- **Main area:**
  - Breadcrumb back to Patients.
  - "Case record" with the mockup subtitle, and **Profile / Print / Collect payment / Upload** at top right.
  - A case picker when there are several cases, and the "Open a station:" pill row.
  - Timeline of 8 station events: At-home forms, Send-to-ASC, Front desk, Pre-op nursing, Anesthesia, OR (with the recorded times), PACU, Discharge. Each has a status chip and opens its station.
  - Below the timeline: Documents (categories), Billing & payments, Past cases (with cancelled cases and booking history) and Overview.

## Shell (`asc90/shell90.tsx`, `asc90.css`)
- Mockup palette: warm off-white page #FBF7F1, sidebar #F6EFE5, ivory cards, warm borders, terracotta and green. This overrides the v8.1 slate ASC2 palette. Corners stay rounded (12px, against the mockup's 3px).
- Top bar: station shortcut pills (Portal/At-home, Front desk, Pre-op, Anesthesia, OR/Surgeon, PACU/Discharge) and a bell showing the open-flag count.
- The test-as and sign-in controls are compacted and muted.
- A floating bottom-centre **Ask Nightingale about this page** bar. It answers with drafts only; nothing is sent or changed.

## Partials
- The mockup's case-flow source isn't in the zip; only the token CSS (style.css) is. Layout was matched from the screenshots plus style.css.
- The Proc 1 cases use technique fallbacks: MAC is inferred for the colonoscopy and Local for the lesion excision.
- "Late start" counts scheduled cases more than 10 minutes past their start time, so it depends on the time of day you look.
- The top shortcut pills open the station benches. With no matching case they open the station pool.
