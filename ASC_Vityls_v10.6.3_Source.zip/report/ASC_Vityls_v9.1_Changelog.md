# ASC.Vityls v9.1 — Changelog (test build, fictional data)

Built from asc-v9.0.1. Branch and tag: `asc-v9.1`. tsc baseline: 68 errors (unchanged). Unit tests: 209/209. Walk: `scripts/walk91.py` at 1440 and 390, 62/62 checks passed.

## Changes
1. **Chat.** Your message bubble is rounded (18 px, tail corner 6 px). Nightingale replies have no background or border. "Open workspace" is unchanged.
2. **Schedule columns** (Visit types › Schedule columns). Every row now has a trash icon. Deleting asks for confirmation, shows how many upcoming cases use that column, and writes an audit entry. Booked cases keep their surgeon and room: they stay on Today and in the chart, and can be reassigned from Appointment details or by adding the column back.
3. **Billing settings.** Removed the Surgery.Vityls "Practice fee schedule" editor and the "ASC facility fee schedule (fictional)" CPT table. Billing configuration stays. The page now holds the one unified fee schedule (FeeSchedule89) and is limited to the Practice Administrator; other roles see a short notice.
4. **Fee schedule placement.** Removed from the Practice page. On Billing & Payments, the "Fee schedules" config tab now links to Billing settings (the button shows for the administrator only). Invoices and the check-in balance still read the same schedule: Ada Kerr's invoice is $1,800 total and $1,500 balance after a $300 credit. The invoice footer now points to Practice › Billing settings. The fee editor is also hidden from Surgery settings in the ASC build.
5. **Practice settings.**
   - Facility profile & logo moved into Practice profile & rooms.
   - The Standard doctor's orders list moved into the Surgery.Vityls settings page, which is now titled "Surgery settings" (Clinical configuration).
   - The Practice main page now has only the index tiles and Clinical tablet.
6. **Practice Intelligence** (new nav item; the v7.7 "Facility performance" page, retitled). Contents:
   - Period filter: today, week, month, quarter, trailing 12 months, custom.
   - Nightingale operations evaluation with an ask box, insights for Volume, Rooms, Cancellations and Staff, and Refresh. Generated locally; answers are labelled as drafts.
   - Six KPI tiles.
   - Surgeon performance, OR utilization bars, Staff efficiency and Cancellation reasons.
   - A grid of 8 reports. Each opens a live table you can print manually; no PDF is created.
   - Today's case flow, with live KPIs and a table.

   Everything comes from live data on the device: cases, cancellations, payments, blocks and staff. Staff hours and overtime are estimates derived from case minutes, and the page says so. Only the Administrator and the Medical Director can open it; other roles don't see it in the nav, and reaching it shows a no-access card. Styled in the v9 palette with white rounded cards.
7. **Block time.**
   - Blocks now show in OR room columns as well as surgeon columns, in the surgeon's color.
   - Clicking a block opens a popup. **Edit this block** changes date, times, room, surgeon and notes, and detaches that block from its series. **Edit series** changes date range, days of the week, times, room, surgeon and notes, and regenerates the series. **Delete** offers This block only or Whole series. Every edit and delete asks for confirmation.
   - **Book patient in this block** opens Appointment details prefilled with the block's surgeon, room, date, start time and length. You pick or create a patient (with the existing duplicate check) and can change the time and length. On save, the booked part of the block is removed. The block disappears if the case fills it, or is trimmed or split if the case covers only part of it; leftover pieces under 15 minutes are dropped.
   - Every block action is written to the audit log.
8. A new seeded staff member, **Rhea Castillo, MD (Medical Director)**, for testing role access.

## Partials and notes
- The cleared status still uses the v8.8 rule carried over from v9.0.
- Practice Intelligence staffing figures are estimates: there is no timesheet source. Credentialing due is a fictional flag.
- Some seeded blocks overlap seeded cases. To open those blocks, click a free part of the block.
