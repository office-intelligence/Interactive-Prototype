# ASC.Vityls v8.1 — Changelog
Date: 2026-10-27 (America/Los_Angeles) · Branch `asc-v8.1` (from `asc-v8.0` @ 6bb1853) · Edition ASC2 (Surgery.Vityls code) · Fictional data only.
Goal (Kevin): v8.0 is the base. Bring in all the functionality and detail of v7.7 (and its v7.6 base), and give it a lighter palette with a different colored icon for each station. Question-bank stations (v7.7–v7.9) are shelved; the bank stays as an accreditation reference only.

## Ported from v7.7
- **Nightingale workbench (9 benches)** — `src/surgery/asc81/Workbench.tsx`. Logic is ported from v7.7 `src/v77/logic.ts` → `asc81/ai.ts`; storage from v7.7 `store.ts` → `asc81/store81.ts` (ASC2 namespace). Chips on Today list your station's benches first, with "All workbenches" to see the rest:
  1. Booking intake: email plus "Scan paper fax" (simulated OCR). Nightingale pre-fills 12 fields and highlights missing ones, suggests a room and time, and "Confirm & create case" creates a real ASC2 case. Portal forms are "sent" (simulated).
  2. Arrival & check-in: received / missing / abnormal checklist, ID & insurance photo (simulated), follow-up emails Nightingale drafted (outbox only), and "Check in & hand to nursing", which moves the case and flags pre-op nursing.
  3. Records brief: relevant pages kept, noise set aside, abnormal results highlighted, every line linked to its source page. Suggested ASA; only anesthesia (or an admin) accepts or changes it, and it is saved to the case.
  4. Pre-op bedside: ambient capture (sample conversation) split into nursing, anesthesia and surgeon clipboards; each role signs with PIN. Anesthesia signs post-op orders with PIN, and they become PACU tasks.
  5. Nursing admission: pre-filled checklist with the source of each value, dictation placement, med/vital conflicts. Signed with PIN, and the case's nursing item is recorded.
  6. PACU: order tasks, Aldrete & pain scores with alerts ("criteria met" after Aldrete ≥ 9 twice).
  7. Discharge: instructions drafted in English or Spanish, ride re-confirm, patient sign on the tablet, nurse PIN. Schedules the next-day text and the 1-week survey (simulated) and moves the case to Discharged when its PACU items are complete.
  8. After surgery: scheduled messages; simulated replies are triaged, and a concern flags pre-op nursing.
  9. Accreditation & audit pack: per-case completeness (signed forms, OR times ≥ 6, op report). Manual .txt download; no automatic PDF.
- **Nightingale quick actions** (Practice Manager / admin Today): 3-OR matrix, Billing & claims, Portal messages, Clinical Form Studio, EKG hold (flags anesthesia; it never decides), Audit pack.
- **Operations › Case board**: Pipeline (cases by status column) and Priority (late arrivals, open flags, missing items, scored) — the v7.7 Classic board views. They sit next to the existing room grid, bottlenecks and turnover.
- **Schedule**: Day briefing (patients, ages, rooms, procedures, allergies, open flags), Block time dialog (rejects overlaps; audited), and ASC block bands now show in the ASC2 scheduler.
- **Messages**: filter chips All inbound / Unread / Clinical / Rx refills / Billing (`asc81/msgFilter.ts`), plus 5 fictional seed messages.
- **Medical Director workspace** (Practice): designation, quality snapshot, privileges review (approval needs every item verified; Medical Director signs with PIN; Return records the missing items), and annual policy attestations with next-review dates (PIN).
- **Accreditation & audit pack** page (Practice); the Facility accreditation & documents center is relabeled (it already ran the v7 document center).
- **Form set**: the field-level comparison found 3 v7.7 order sheets missing from the ASC set. Restored as "as needed" templates with signers: Anesthesia Orders, Surgeon Orders, PACU Physician Orders (26 templates). All 32 v7.7 templates are byte-identical in v8.1. Blank Custom Form stays in the builder; the Operative Report stays on the note page.

## Design (Kevin's inspiration `kevin_v8_inspo_01_preop_nursing.png`) — `asc81/asc81.css`, `asc81/icons81.tsx`
- Light gray-white page, white main surface, light gray-blue card fills with soft borders, dark navy titles, dark teal uppercase section headings, mint success panels/chips, rose/crimson primary actions (Sign / Save / Lock), blue checkboxes.
- Rounded corners replace the 3px rule: cards 12px, dialogs 14px, inputs/buttons 8px, pills fully rounded. Applied app-wide: Today, stations, scheduler, billing, messages, settings, sidebar, header.
- One distinct colored icon per station on light tints: front desk blue, pre-op rose, anesthesia violet, surgeon teal, OR orange, PACU green, billing amber. Each sidebar destination also gets its own icon color.
- Station panel header: pink "STATION n · NAME" pill, progress chip ("x of y complete"; turns mint when done), and the station icon on the title.
- Case colors in the scheduler moved to light blue, mint and lavender.

## Unchanged rules
PIN only for signing (Practice Settings keeps v8.0's access lock). No automatic PDF. Email, fax/OCR, ambient capture, SMS and portal are simulated. Nightingale drafts and suggests; it never signs, orders or decides.

## Tests
Unit: `npx tsx --test tests/*.test.ts` → 132/132 (new `tests/asc81.test.ts`, 14 tests). Walkthrough: `python3 scripts/walk81.py URL 1440 1024 390` → 90/90. v8.0 regression walk (`shots_asc80.py` on the v8.1 release): 156/159; the 3 failures are only the expected title change (v8.0 → v8.1).
