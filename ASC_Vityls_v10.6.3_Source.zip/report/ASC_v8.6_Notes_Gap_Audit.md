# ASC.Vityls · Kevin's final notes vs v8.5 (gap audit)

Base audited: branch `asc-v8.5`, commit `4fe137f`. Notes: "ASC Patient Workflow: Implementation Instructions", sections 1–10.
Status key: **There** = already in v8.5 · **Partly** = some of it in v8.5 · **Missing** = not in v8.5. The last column is what v8.6 did.
Kevin's standing rule overrides the notes wherever they say "hold before advancing": nothing blocks a station or the episode close. Holds appear as tinted warnings and are logged.

| # | Requirement (section) | v8.5 status | Evidence in v8.5 | v8.6 |
|---|---|---|---|---|
| 1 | Match booking to existing patient or create without duplicates (2.1) | Partly | `asc82/intake.ts` `matchPatient` (intake only); `asc84/appt.tsx` scheduler popup created a new chart from typed name with no duplicate check | Dedupe on name+DOB / DOB+phone / name+phone in the popup; existing chart pre-selected; "create new anyway" logged; counter in metrics |
| 2 | Distinct episode per date of service (2.1) | There | `asc8/store.ts` one `AscCase` per surgery + visit | — |
| 3 | Traceable reschedule/cancel, notifications updated (2.1) | Partly | Cancel archived with reason (`asc83/frontdesk.tsx cancelCase`); appointment edits only an audit line, no history or notice updates | `schedule_change` history (booked/rescheduled/cancelled with from→to, reason, notices), reminders re-queued or cancelled; shown in the appointment popup and chart |
| 4 | Portal registration forms, email/text links (2.1) | There (simulated) | `newPatient.tsx`, portal send prompt; toast "Portal forms sent (simulated)" | — |
| 5 | Track submitted / missing / reviewed items separately (2.1) | Partly | Booking checklist received/missing (`asc81/Workbench.tsx Arrival`); no separate "reviewed" state | Unchanged; listed as partial |
| 6 | Missing-document tasks with accountable owner (2.1) | Partly | Station to-dos by station (`asc8/store.ts ascTodos`), flags | Episode worklist names an owner for each next step |
| 7 | Booking confirmation + 2-day reminder, arrive 1 h early, location, contact, instructions (2.2) | Partly | `reminders.tsx`: confirmation requests + day-before reminder; no arrival-1 h/location content, no 2-day reminder | Confirmation + two-day reminder (arrive 1 h before, location, contact, generic fasting/meds/escort lines that route questions to clinicians), simulated outbox |
| 8 | Predetermined fee collected before surgery; post-case billing with OR time (2.2) | There | `asc83/pay.ts`, `CollectCard`, `asc8/logic.ts charges/orMinutes` | — |
| 9 | Pre-day reconciliation; unresolved items shown, not silently completed (2.2) | There | Station queues + `a84-exc` exception boxes | Also in the episode worklist |
| 10 | Check-in verifies identity, rechecks items, cards (3.1) | There | `asc83/frontdesk.tsx CheckInFlow`, `asc82 CardCapture` | — |
| 11 | Holds displayed before episode advances (3.1) | There (as warnings) | `asc84/exc.tsx`, `S.move` exceptions | Kept as warnings (Kevin's rule) |
| 12 | Nursing admission, reconciliation, review active signed orders (3.2) | Partly | `asc82/benches.tsx Nursing82`; no orders view | Active signed orders card at the top of Nursing |
| 13 | Role-specific worklists (3.2, 9.0) | There | Today station view, `AscTodo` | Plus the episode worklist |
| 14 | Surgeon consent, interval H&P, pre/post-op orders (3.3) | Partly | `Surgeon82`: free-text pre/post-op orders signed as one block | Orders moved to the dedicated Orders section (status shown on the Surgeon bench) |
| 15 | Anesthesia assessment, consent, signed PACU order set (3.3) | Partly | `Anesthesia82` PACU orders = free-text textarea | Structured PACU order set (anesthesia signer) in Orders; Anesthesia bench UI unchanged |
| 16 | Time-out / safety checks (3.3) | There | `asc8/logic.ts ITEMS timeout` | — |
| 17 | Dedicated Orders section: pre-op/post-op/PACU, structured, editable fields, ordering clinician (4.0) | Missing | — | **Built** `asc86/ui86.tsx OrdersSection` |
| 18 | Signer role per order set (surgeon vs anesthesiologist) (4.0) | Missing | Any provider role could sign | **Built**: configurable per set; `roleFits` enforced at signing |
| 19 | Standard sets proposed, clinician confirms/edits/signs (4.0) | Missing | — | **Built**: "Nightingale: propose draft" / template, clinician signs with PIN |
| 20 | Active signed orders as standalone nursing component (4.0) | Missing | PACU tasks inside a collapsible box | **Built** `ActiveOrdersCard` on Nursing and PACU |
| 21 | Drafts / discontinued / superseded labeled distinctly (4.0) | Missing | — | **Built** status pills (dashed yellow, green, red-struck, gray-struck) |
| 22 | Author, signer, time, status, version history; prior versions preserved; nursing notified (4.0) | Missing | — | **Built**; flag to nursing on signing |
| 23 | Acknowledgment, execution, escalation of unclear orders (4.0) | Missing | Task ticks only | **Built** Acknowledge / Record done / Escalate |
| 24 | AI never signs/releases orders (4.0, 10.0) | Partly | PinSign statement only | **Enforced** in `signSet` (throws for Nightingale/System) |
| 25 | PACU handoff + approved PACU form (5.1) | There | `PACU_Recovery_Record.html` full screen | — |
| 26 | Time-based vitals flowsheet, 15-min + extra rows, labeled fields (5.1) | Missing | Vitals only inside the form | **Built** `Flowsheet` |
| 27 | Measured vs entry time, late entries, corrections, no copy-forward (5.1) | Missing | — | **Built** |
| 28 | Overdue reminders not auto-completed; trend next to active orders (5.1) | Missing | — | **Built** |
| 29 | Device integration only after validation (5.1) | n/a | — | Stated "not connected" |
| 30 | Discharge criteria confirmed + authorization recorded (5.2) | Partly | Physician discharge order signature; no explicit criteria confirmation | **Built** criteria checkbox + PIN authorization |
| 31 | Instructions, escort/transport, understanding, accessible copy (5.2) | Partly | Instructions + ride text + patient signature | **Built** understanding (who/method), copy given, transport, escort, concern routing |
| 32 | Day-2 follow-up call with owner, attempts, escalation; survey separate (6.0) | Partly | Next-day text + survey queued, replies triaged (`Workbench After`) | **Built** `FollowUpCard` (owner, due date, attempts, escalation) and separate survey line |
| 33 | Op report receipt and signatures tracked; corrections preserved (6.0) | Partly | Op report signing (`asc8/store saveOpReport`) | **Built** `OpReceiptCard` received/signed/amended + signed addenda |
| 34 | Mobile dictation as proposed feature (6.0) | There | Data contract in v8.3 | — |
| 35 | Nightingale completeness check → owner to-do; human review; manual path (6.0) | Missing | Audit pack completeness only | **Built** `ClosurePanel` |
| 36 | Financial vs documentation status separate (6.0) | Missing | — | **Built** |
| 37 | Close after completion or authorized exception (6.0) | Missing | `closed` location existed, no closure workflow | **Built**; per Kevin closing is never blocked; open items are logged |
| 38 | Reopen / amendment workflow preserving signed records (6.0) | Missing | — | **Built** (reopen with reason; op-report addenda; order versions kept) |
| 39 | Unique accounts, PIN tied to person, active user visible, reauth for signing (7.0) | There | v8.5 login modes, `asc85/tablet.tsx`, `sign.tsx PinSign` | — |
| 40 | Signature bound to exact document/order version (7.0) | Partly | Signatures stored with case + title | Orders and op-report addenda carry a content hash; form signatures unchanged (partial) |
| 41 | Patient vs clinician signatures; witness/representative (7.0) | Partly | Patient draws on the tablet; no witness/representative | **Built** `WitnessCapture` on surgical consent |
| 42 | Search by name/MRN + DOS, opens one episode (8.0) | Partly | Patients search by name; Nightingale schedule ask | **Built** `EpisodeSearch` on Today |
| 43 | Print single docs and complete episode packet, predictable order (8.0) | Partly | "Print all for this date" printed one text block | **Built** paginated `PrintPacket` |
| 44 | No routine PDF (8.0) | There | Manual print/export only | Kept |
| 45 | Steps added outside forms rendered as supplemental sections (8.0) | Missing | — | **Built** (orders, flowsheet, discharge confirmations, follow-up, op receipt, closure) |
| 46 | Patient ID header on every page + page numbers (8.0) | Missing | — | **Built** |
| 47 | Log access and export activity (8.0) | Partly | Access/session audited (v8.5); prints/exports not logged | **Built** `logPrint` for packet, case record print, documents export |
| 48 | Accountable owners per stage (9.0) | Partly | Stations | Worklist + closure to-do by owner |
| 49 | Downtime documentation / failed notifications (9.0) | Partly | AI-unavailable manual path added; downtime paper reconciliation not built | Partial |
| 50 | Live episode worklist: stage, next steps, owners, blockers (10.0) | Missing | Station queues only | **Built** `EpisodeWorklist` on Today for every station |
| 51 | Proactive AI tasks, document extraction, dedupe suggestions (10.0) | Partly | Intake OCR + matching, records brief, ambient (simulated) | Dedupe added; rest unchanged |
| 52 | Never copy forward vitals/signatures (10.0) | Partly | — | Flowsheet enforces blank rows |
| 53 | Audit automated actions; allow stopping automation (10.0) | Partly | Audit trail; no stop switch | Unchanged (partial) |
| 54 | Efficiency metrics (10.0) | Missing | Ops bottlenecks/utilization only (`asc8/logic.ts`) | **Built** `MetricsCard` (admin) |

**Counts (54 items):** There 13 (item 29 is not applicable and is counted here) · Partly 23 · Missing 18.
After v8.6 the following stay partial: #5, #40 (legacy form signatures are not hash-bound), #49, #51, #53, and the legacy free-text PACU orders box on the Anesthesia bench (#15). It was kept because the Anesthesia UI must not change.
