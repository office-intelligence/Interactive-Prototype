# ASC.Vityls v8.9 — Changelog (test build, fictional data)
Built from asc-v8.8. Branch/tag `asc-v8.9`. tsc baseline 68 · unit tests 194/194 · walk89 121/121 (1440 + 390).

## What changed
1. **Mockup v2 design (Today + Patient chart)**
   - Ivory cards (#FFFDF9), warm borders (#eadfce/#f0e6da), and a soft shadow on the plain page background. Corners stay rounded.
   - Chart: breadcrumb with the back link, then a hero (name, status pills, credit chip) with **Profile / Print / Collect payment / Upload**. Below that: a jump bar, **Needs attention**, **Clinical snapshot**, **Timeline** (green/amber/terra/sky nodes), and **Documents & packets** (Overview / Documents / Billing & payments tabs). The right column holds Cases (upcoming, previous, cancelled, history), Care team and Account (balance + available credit).
   - Today keeps every function: date nav, cards with Check in / Chart / Cancel, blue/amber readiness, station chips with dots, the to-do list, Nightingale activity, stats and case details.
   - Tablet/phone: the existing responsive shell keeps the icon rail between 900 and 1280 px and the drawer below 900 px.
2. **Stations open in a near-full-screen slide-over** (94vw, anchored right, X to close). The journey bar is docked as the panel's top band and its height is measured live, which fixes the v8.8 dock overlapping the OR panel. Staff move station to station and patient to patient (Next patient).
3. **Cream background removed.**
4. **Billing & payments page from v7.7, built live:**
   - Period filter.
   - Nightingale revenue evaluation (ask box, 4 insights, Scrub claims, Refresh). It only drafts.
   - 6 KPI tiles.
   - Worklist.
   - AR aging by payer bucket.
   - Surgeon financial output.
   - Claims & AR aging table with filters and simulated clearinghouse actions.
   - Patient accounts with search and Create invoice.
   - Case invoices.
   - Create invoice for cash-pay cases.
   - Billing configuration (10 tabs).
   - The previous ledger views are kept under "Ledger views".
5. **One fee schedule.** Time-based facility and anesthesia fees, an optional flat surgeon fee, the insured share %, and the v8.8 itemized items. It drives both invoices and the check-in balance. Insured invoices show the plan share as a negative line, so invoice total = check-in balance. Practice Settings uses the same editor.
6. **Chart Profile** popup: demographics, contact, address, SSN, payment type, primary/secondary insurance, emergency contacts. Changed fields are audit-logged.
7. **Chart Print** (the v7.7 popup):
   - 5 tabs: Avery 5160 labels, Facesheet, Visit summary, ID & insurance cards, Encounter & audit summary.
   - Facesheet sections 1–6 plus attestation lines, using real record data only. Missing data shows "Not recorded" and the SSN is masked.
   - Printing is manual and logged.
8. **Collect payment** independent of any invoice (the v7.7 Collect / Record Payment fields). The payment is stored as unapplied patient credit and applied oldest-first when an invoice is generated. Card methods open the simulated card popup, and the receipt shows available credit.
9. **Documents categories**: All / Pre-op Clearance / Nursing / Anesthesia / OP Reports / Other. Uploads pick a category, and existing documents are mapped by type.
10. **OR event times strip**:
    - Six tiles: In room, Anesthesia start, Incision, Closure, Anesthesia end, Out of room.
    - Tap once to stamp the time. Tap again to edit; a correction needs a reason and is audit-logged through the existing setEvent.
    - Stamped tiles are **tinted green**. Order warnings are shown but never block.
    - Recorded OR and anesthesia minutes feed OR-time billing.

## Partials / notes
- Clearinghouse, ERA, eligibility and card processing are simulated.
- Single-panel dialogs (invoice, upload, case details) open as centered/side dialogs, not as the 94vw station slide-over.
- The v8.8 walk is superseded by walk89 (v8.9 removed the cream background check and moved the old billing tabs under Ledger views).
- Negative invoice amounts print as "$-1,100.00" (cosmetic).
