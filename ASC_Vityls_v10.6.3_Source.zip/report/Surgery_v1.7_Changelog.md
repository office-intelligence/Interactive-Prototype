# Surgery.Vityls v1.7 — Changelog (Oct 22, 2026)
Built from tag `surgery-v1.6`, branch `surgery-v1.7`, tag `surgery-v1.7`. All data fictional; dictation, email, payments and labs remain simulated (no BAA yet). Nothing from v1.6 was removed: cases, the sideways scheduler, Add Form, the workspaces and the chart all remain.

## 1. Role views (Kevin's decision 1)
- Three working views: **Front office**, **Nurse / MA / Coordinator** (one shared view) and **Doctor**. Managers and administrators see everything.
- The view comes from the Session person's role. Pick a person in the Session menu to switch.
- **The chat page is the default entry point.** It shows **My to-do**, which lists only my role's unfinished tasks. A **See all roles** switch shows every role's tasks, each tagged Front office, Nursing or Doctor.
- **Every to-do has an owner role:**
  - Front office: booking, forms, registration, payments, checkout and post-op booking.
  - Nursing: vitals, reason, notes, quotes, deposits, case booking, clearance, PCP letter, documents, ASC and lab review.
  - Doctor: exam, body charts, photos and notes.
- The chart's To-do list now carries the same role tag.
- **Menus per role:**
  - Front office: Today, Schedule, Patients, Messages and Billing.
  - Nursing: Today, Patients, Schedule, Messages and Billing.
  - Doctor: Today, Patients and Schedule.
  - Everyone keeps Practice Settings (Practice PIN) and Search.
- **Admin items stay behind the Practice PIN.** Surgery settings, Staff & PINs and Patient records admin appear in the profile menu only for managers and administrators, or once the Practice PIN is entered.

## 2. One note flow for doctors (decisions 2 and 3)
- **Quick jots** can be typed or spoken (simulated). They sit at the top of the Doctor workspace and inside the note page, and each jot is linked to its visit and case.
- **Missing-note to-dos.** Nightingale lists every visit where the doctor was the provider, the patient was seen, and the note is not yet signed.
  - Doctors see their own visits; "See all roles" shows every doctor's.
  - There is **no Overdue badge**. The item stays Incomplete until the note is signed.
  - Tracking starts on the first day v1.7 runs, so older closed visits are not flooded in.
- **Near-full-screen note page:**
  - The header shows the patient's name and the visit.
  - A 2–3 line summary covers age, sex, key conditions, risk factors, the reason for the visit and the case.
  - "Your jots" sits behind one expand.
  - An **H&P / SOAP / Simple** switch, then a large, easy-to-read editing area.
  - Dictate (simulated) and "Re-draft from chart" buttons.
  - The only actions are **Save & close** and **Sign with PIN**.
- **Nightingale's basic draft** uses only known data:
  - name, age, gender and reason for visit,
  - PMH and PSH, medications and allergies,
  - risk factors (intake answers and relevant conditions),
  - the doctor's jots, the body chart titles, and the number of photos.
  - Anything it cannot know (exam, ROS, plan) is marked `[doctor to complete]`, and the draft is clearly labelled. Nightingale never signs.
- **Same record.** The note page, the Doctor workspace note and Chart › Notes are one record per visit. Signing in any of them signs it everywhere and removes the to-do.

## 3. Focused missing-item panels
Clicking a to-do opens a slide-over with only the missing piece. Each panel ends with Save & close, and most also offer "Open full workspace ›":
- Vital signs (respiratory rate required)
- Deposit (amount and date)
- Collect payment
- Reason for visit and nurse notes
- Lab review (shows the reported range only, with an optional note for the surgeon)
- Flag reply and flag answer
- Consult note (the note page)

Any other item opens a short panel that names what is missing, with one button that opens its workspace on that section. Consent has no separate to-do in the current flow, so it still goes through the workspace.

## 4. Cross-role flags (decision 4)
- **Who can flag whom.** Anyone can flag the **Front office** or the **Nursing** team: the whole team, not a person. Flags can be sent from My to-do or from the chart's To-do.
- **Where a flag goes.** It lands on the receiving team's to-do. Marking it done with a reply sends the answer back to the sender's to-do, where "Got it" closes it.
- **Audit.** Every flag and reply is written to the patient's audit trail.

## 5. Simpler pages (Kevin's added request)
- **Chat page:** one focus, My to-do. The "Unsigned notes" and "Messages" chips were removed because the to-do and the menu already cover them. The list shows 6 rows, then one "Show all".
- **To-do rows:** several open items of the same role for the same patient and case now fold into one row ("+2 more"). Previously Body charts, Photos and Exam were separate rows.
- **Today:** the schedule is the focus. The four counts, "Worth your attention" and the ASC week now sit behind one expand ("More for today · N not confirmed · N worth attention").
  - "Unsigned note" cards were removed from Worth your attention; they now appear once, on the doctor's to-do.
  - The Today To-do panel shows the same role list instead of a second, different list.
- **Note page:** one editing area, with secondary context (jots) behind a single expand.
- **Panels:** one form each, no tabs.
- **Profile menu:** admin items hidden for non-admin roles.

## Seed data (fictional)
- **Dr. Sam Patel's consults today:**
  - Nora Bellweather (blepharoplasty consult, two jots, smoker, hypothyroid, prior cholecystectomy).
  - Owen Takahara (rhinoplasty consult, draft H&P not signed, one jot, a low hemoglobin awaiting nursing review).
  - Gwen Ashby (post-op scar check, no note).
  - The existing seeded visits for today also appear if they have no signed note.
- **Flags:**
  - doctor → nursing (Ruth's PT/PTT),
  - nursing → front office (Tomas's insurance card),
  - front office → nursing (Gwen's swelling call-back),
  - doctor → front office, already answered (Nora's pre-op booking).

## Tests
- **Unit tests:** `tests/roles17.test.ts` adds 6 tests covering role mapping, owner tags, menus, the note drafts in all three shapes, missing notes without Overdue, and the flag round trip. All tests: **84/84 pass**.
- **v1.7 walk-through** (`scripts/shots_v17.py`) at 1440, 1180 and 768: **96/96 pass** (32 checks per width).
- **Regression** (`scripts/smoke_v17.py` with its own `scripts/regress_parts_v17/`): **1180: 415/415**; 1440: 406/407 and 768: 403/404. In both, the last legacy part (fdpart2) stopped on a click timeout late in the long run; run on its own at 768 it passes 24/24, and the v1.6 baseline at 768 passed 416/416, so this is an order-dependent timeout, not a confirmed defect.
  - Two checks were updated on purpose: the chat chips (now ≥4 plus My to-do) and the profile menu (admin items only for managers or after the Practice PIN).
  - Today's "More for today" expand is opened automatically for the older suites that read the counts.
- **Screenshots:** `report/surgery_v1.7_screens/`.

## For Henry
`Case_Data_Model_for_Henry.md` gains the tables clinical_note, jot, owner_role (derived) and role_flag. The swap point is `src/surgery/v17/store.ts`.

## Not changed / caveats
- The Doctor workspace keeps its Price quote tab. Quote tasks are now owned by Nursing on the to-do, but doctors can still open the tab.
- The role view follows the Session person. A doctor who wants another role's list uses "See all roles"; nothing is locked (no gating).
