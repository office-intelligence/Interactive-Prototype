# Surgery.Vityls v1.6: the Surgical Case restructure

Branch `surgery-v1.6`, built from tag `surgery-v1.5` (7c7d75b).
- All data is fictional and every external action is simulated.
- ASC and Medical behaviour are unchanged. Every new screen and hook is guarded with `!isMedical`, and Medical ignores the optional `MedVisit.caseId`.

## 1. Case model
- **Pure logic, unit-tested** (`src/surgery/cases/logic.ts`): `SurgicalCase` has the fields id, patientId, procedure, kind (`surgical` | `office-procedure` | `general`), status (`open` | `booked` | `post-op` | `closed` | `undecided`), openedAt, openedBy, closedAt, closedBy, closeReason, episodeId, source, quick and log.
- **Built on the existing Episode.** A surgical case shares the episode's id, and the quote, deposit, booking, clearance and ASC data stay on the episode. Its status follows the episode stage until the case closes; "undecided" comes from the workflow's Undecided state.
- **Store** (`cases/store.ts`): `cases` and `case-links`, plus open, close, reopen, link, events and migration.
- **Opening a case** happens in any of three ways:
  - Automatically when the doctor suggests a procedure (scribe suggestion, booking order or quote). Nightingale names it from the quote or the suggestion.
  - From "New case" in New appointment.
  - By hand on the chart.
- **Closing a case** happens in any of three ways:
  - A surgical case closes automatically after its last post-op visit is done.
  - A quick case closes automatically once it is paid and its note is signed.
  - Staff can close a case by hand, with a reason.

## 2. Everything linked to a case
- **Visits** (office, phone and video) carry `caseId`, and a visit's note follows its visit.
- **Everything else** is linked through `case-links` (entity:id → caseId): calls, messages, documents, quotes, payments and deposits, forms packets, body charts and photos.
- **One-time migration** (`migrateCases`):
  - Each episode becomes a case.
  - Every existing item is assigned by date. A case covers from 45 days before it opened to its close. A procedure word in the item's text breaks ties.
  - Anything left over goes to General.
  - The per-patient workflow state moves to the patient's open surgical case.
- **New items** without a case get Nightingale's suggestion (`syncCases`).

## 3. Scheduling
- **New appointment** has a **Case** picker:
  - It defaults to Nightingale's suggestion: the newest open surgical case, otherwise an open office-procedure case, otherwise General.
  - Options are the open cases, "New case…" (procedure + Office procedure or Surgical) and "General (not case-related)".
- **One-tap case chip.** It appears on the appointment panel, in every workspace header, and on each visit in the case and overall timelines.
- **Audit.** Every change is audited (`case.link`, "Visit … moved from X to Y") on the patient and in both cases' logs. Booking also records whether the case was Nightingale's suggestion or chosen by staff.

## 4. Per-case workflow
- **7-step state** (`flow-state`) is keyed by **case id**. A patient who has no case is keyed by patient id until one opens.
- **Case-scoped facts.** `factsFor(pid, today, caseId)` reads that case's consult visit, episode, quotes, payments and post-op visits.
- **To-dos are per case.** `caseTodoLists(pid)` gives one list per open case, so several open cases run independently. Opening a case's workflow or a to-do item focuses that case, and `activeEpisode` follows the focus.
- **Today's To-do** is grouped by patient, then by case. The chart's To-do is grouped by case as well.

## 5. Office-procedure quick case
- One in-office visit. The steps are Scheduled → Checked in → Procedure done (note signed) → Paid → Closed, each with its date and time.
- There is no quote, deposit, clearance or ASC.
- "Record payment (simulated)" is in the case view. The case closes itself once it is paid and the note is signed.

## 6. Chart: Cases section
- **Case folders** show, for example, "Rhinoplasty (open) · 2025 · closed · 14 events" or "Facelift / necklift · 2026 · booked · 6 events".
- **Each folder** opens:
  - the case's own timeline (visits, calls, notes, documents, quotes, payments, forms, body charts and photos)
  - its to-do and "Open workflow"
  - its documents and forms
  - its case log
  - Close case…
- **Overall timeline** has a case filter and "Show all".
- **Closed cases** are read-only history: a banner, no chips and no actions.
- "+ New case" opens a case by hand.

## 7. Seed (Mary James)
- **Closed rhinoplasty case, about a year ago:**
  - Visits: consult, phone consult, video pre-op planning, pre-op visit, and post-op POD 1 (office), POD 7 (phone), POD 30 (video) and POD 90 (office).
  - Signed notes and two phone calls.
  - Closed after the last post-op visit.
- **Open facelift / necklift case:** her existing current case (`ep-mary`), renamed. All its v1.5 workflow data is kept, so scenario C still works.
- **Closed filler quick case**, about 7 months ago.
- Other seeds are unchanged. Ruth and Lena get a case opened automatically from their doctor's suggestion.

## 8. Data layer
- `src/v6/dataLayer.ts` re-exports `CaseRow`, `CaseLinkRow`, `CaseKind`, `CaseStatus` and `CaseEntity`, and adds `EncounterRow` and `CaseScopedRow` (with `caseId`).
- `report/Case_Data_Model_for_Henry.md` describes, in plain language, the tables patient → case → encounter/visit, document, payment, quote and task, with their keys and rules.

## Tests and scripts
- **Unit tests:** `tests/cases.test.ts` adds 8 tests covering status, assignment by date, multiple open cases, Today grouping, quick case steps and auto-close, surgical auto-close, visit reassignment and folder titles.
- **Walk** (`scripts/shots_v16.py`): the v1.5 walk plus 25 v1.6 checks and screenshots C1–C5.
- **Regression** (`scripts/smoke_v16.py` with its own `scripts/regress_parts_v16/`): the station-page parts that failed in v1.5 are updated to the workspaces.
  - v8: Check-in opens the Front desk workspace; Front desk, Nurse, Doctor, Checkout and Visit record workspaces checked; checkout quotes.
  - v9: form header and published form opened from the Front desk workspace.
  - v12: a past visit opens its record; the PIN "Forgot PIN?" check runs from the workspace sign-off.
  - fdpart2: timeline chips open the workspaces over Today; step forms open fillable.
  - Screenshots get a 90 s timeout and never stop a run.
- **Medical check** (`scripts/smoke_med_v16check.py` on `release/Medical_Vityls_v16check`): longer, non-fatal screenshot timeout.
