# ASC v8.5 progress
- [x] Login modes: front desk / administrator / clinical tablet (shared Staff) — simulated
- [x] Shared read-only board, avatar + PIN, PIN-only when unique, Switch, Done, idle return (configurable), per-person audit
- [x] Test-as simulation switcher kept
- [x] Patients zebra rows
- [x] Chart color accents
- [x] Nightingale schedule search; legend row removed
- [x] Unit 163/163, tsc 68 baseline, walk 95/95 at 1440, 1024, 390
## Partial / notes
- All demo PINs are 1234, so PIN-only shows "matches more than one person → tap your name". With unique PINs, PIN-only signs in directly (unit-tested).
- Front desk login sets the actor to the front desk role; menus follow existing role rules (no separate trimmed nav).
- Nightingale box sits just above the calendar grid (where the legend was), below the toolbar.
- Idle timer runs in the browser tab; no server session.
