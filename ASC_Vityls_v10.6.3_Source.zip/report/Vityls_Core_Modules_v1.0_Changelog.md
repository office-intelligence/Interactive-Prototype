# Vityls Core Modules v1.0 — changelog (2026-10-14)

Branch `core-modules` from `medical-v1.0` (Surgery v0.13 + Medical edition layer). Tag `core-modules-v1.0`. Existing tags untouched.

## New
- **Vityls Core module registry** (`src/core/modules.ts`): 12 modules, each declaring Core services, hard/soft dependencies, nav entries, routes, Practice panels, chart surfaces, Nightingale commands, station steps, storage prefixes and trial length. Editions are bundles of these.
- **Entitlements in Core** (`src/core/practices.ts`): per practice and module `off / trial / active / expired`, trial start/end/days left against a (simulatable) clock, extension, expiry sweep, dependency “bring along” with `via`, refusal to switch off a module others need, plan history. Everything audited (`vityls:core:audit`).
- **Gated shell**: nav, routes, Practice panels, chart tabs/cards (Photos & charts, Print/Send + Records sent, quotes), Nightingale chips and the Portal link render only for enabled modules. Locked modules show a calm **“Try free for 7/14 days”** teaser (preview, description, Start trial), in the nav or only on Modules & plan (per practice). Trial banner with days left and “Keep it”. Expired trials: data kept; module read-only with an upgrade prompt, or hidden behind a “Trial ended” teaser (per practice).
- **Minimal standalone modes**: with the Chart off, patients open as the **Core patient record** (name, DOB, contact, documents, appointments) with a “See the chart” teaser line. Scheduling works on that record; Forms works with Scheduling + minimal patient; Email Intake works alone.
- **AI Email Intake module** (new, simulated): fictional inbox (orthopedic, ENT and GI referral requests with H&P, labs, insurance; one newsletter). Nightingale review card (patient, DOB, contact, procedure, requested date, surgeon, referring office, insurance, urgency; editable, “check” on lower-confidence fields). Accept creates or matches the Core patient, files attachments to Documents, queues a scheduling request — or books the appointment when Scheduling is on; queued requests get “Book now” once Scheduling is added. Nightingale draft reply → Approve & send → simulated outbox only.
- **Vityls admin console** (`#vityls-admin`, internal): pick a practice, set its edition bundle, toggle modules, start/extend/end trials, +7 days clock, teaser/expiry display options, data map by module, entitlement audit.
- **Practice › Modules & plan**: In your plan / On trial / Trial ended / Available, with Try and Add to plan, and plan history.
- **Module data layer** (`src/core/store.ts`): `moduleStore(id)` → `vityls:mod:<id>:*` in the practice namespace; Core outbox; `moduleOfKey()` + admin Data map for existing keys.
- **Combined test build**: one app, four demo practices — Coastline Plastic Surgery (Surgery v0.13 bundle), Bayview Family Medicine (Medical v1.0 bundle), Harbor Surgery Center (frozen ASC.Vityls, full bundle), Sierra Vista Surgery Center (ASC customer starting with Email Intake only). Practice switcher bottom-left (hide with `?bare=1`); `?practice=<id>` and the old `?edition=` also work.
- `report/Vityls_Core_Modules_Architecture.md`: modules, dependencies (mermaid), Core services, entitlement model, SQL tables, edition bundles, how to add a module, Portal on Core.

## Unchanged
- ASC.Vityls (Harbor): same app; screenshot pixel-identical to ASC v7.5 at 1180 px.
- Surgery v0.13 (Coastline) and Medical v1.0 (Bayview) default bundles: same nav, pages and behaviour; the only addition is a “Modules & plan” row in Practice (combined build only).

## Tests (2026-10-14, 1180 px, combined build)
- **Core module checks** (`surgwork/core/modtest.py`): 44 / 44 — email-only practice, Email Intake review/accept/reply, locked teaser, scheduling trial, add Forms, dependencies (bring-along, refuse switch-off), +7 days expiry (data kept, read-only), "Trial ended" teaser, Add to plan, default bundles.
- **Surgery smoke13** (Coastline, Surgery bundle): 369 / 369.
- **Medical med10 smoke** (Bayview, Medical bundle): 369 / 370. The one miss is the same as Medical v1.0: the check expects the surgery pre-op packet's ECG, which the Medical referral packet doesn't include.
- **ASC sanity** (Harbor vs ASC v7.5): 4 / 4 — same text, same buttons, screenshot pixel-identical, no page errors.
- Not re-run this round: 768 px passes.

## Rough edges
- Email Intake inbox, replies and outbox are simulated; no real mailbox is connected.
- Trials and the clock live in this browser (localStorage); the admin console is a test tool, not access-controlled.
- Smoke suites share `/tmp` download paths, so Surgery and Medical smokes must not run in parallel.
