# ASC.Vityls v8.1 progress (2026-10-27, America/Los_Angeles)
- [x] Gap audit (report/ASC_v8.0_vs_v7.7_Gap_Audit.md) + branch/worktree asc-v8.1 (/workspace/vityls/asc81)
- [x] Field-level comparison of forms/stations (§8 of the audit): 32/32 v7.7 templates identical; 3 order sheets restored; form editor is a superset; signer config per form present
- [x] Step 1 data: workbench storage keyed to ASC2 cases; OR-time edits already audited with reason (asc8 setEvent); Henry doc updated
- [x] Step 2 forms (order sheets) · Step 3 stations (workbench + station header) · Step 4 Practice (Medical Director, audit pack, accreditation label)
- [x] Step 5 Ops Pipeline/Priority + Day briefing + Block time · Step 6 Messages filters · Step 7 Nightingale quick actions
- [x] Design pass (Kevin approved): light palette, rounded corners, per-station colored icons
- [x] Tests: unit 132/132, walk 90/90 (1440/1024/390), v8.0 regression 156/159 (title only)
- [x] Changelog, zips, tag
- [ ] Open: the v7.7 coordinator chat panel's free-text command parser (parseCommand) is ported as logic but not wired into Nightingale chat; E-Prescribe remains v8.0's (unchanged); Practice Settings access PIN kept from v8.0
