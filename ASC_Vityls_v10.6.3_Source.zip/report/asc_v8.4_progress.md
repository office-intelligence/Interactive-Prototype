# ASC.Vityls v8.4 progress
| Item | Status |
|---|---|
| White page app-wide (ASC2) | Done; checked on Today, Patients, Schedule, Messages, Billing, Settings, forms |
| Workflow never blocks + exceptions | Done (check-in, nursing, discharge, moves); exception status shown on station chips |
| v7.7 Appointment popup (new + details + intake prefill) | Done (re-implemented on the ASC case model in the current palette; the v7.7 code depends on the v7 data layer) |
| v7.7 Block time popup | Done (2-week day cards; no federal-holiday tags) |
| Surgeon colors moved to Practice settings | Done |
| Today tinted flags + per-patient station chips | Done |
| Forms: full-height text, fixed statements read-only | Done (heuristic: prefilled template text ≥ 60 characters = fixed statement) |
| Footer Close removed | Done |
## Partial / notes
- The fixed-statement rule is a heuristic over template text; a per-field "fixed" flag in the form editor would be more exact.
- The block-time popup has no federal-holiday markers (v7.7 had them).
- Delete in Appointment details archives the case as cancelled ("Deleted from the schedule").
- The OR chip opens the OR station panel; there is no separate OR workbench.
