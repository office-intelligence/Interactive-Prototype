# Surgery.Vityls v1.0 — Front Door design (2026-10-16)

Fictional data only. Built from branch `frontdoor`, tag `surgery-v1.0-frontdoor`.

## New design
- **Shared Front Door shell** (FdShell / FdHero / FdDrawer, scoped `fd.css`): warm cream palette, Nightingale green, 3px corners.
- **Chat home** opens first: "Good morning, Dr./name", one message box, chips (Today, Who's next?, Schedule, Unsigned notes, Messages, Find a patient). Answers in a thread, recent chats kept, never auto-navigates.
- **Chat | Practice switch**, New chat, Search (patients, visits, forms).
- **Five sidebar headings:** Today, Patients, Schedule, Messages, Forms & Documents. Settings, billing, staff, records and modules moved to the profile menu.
- **Today timeline:** colour-coded rows per visit with 4 station chips, legend, and **date navigation** (previous day, next day, date picker, Today) so past and future days can be viewed.
- **Station panel:** stations open as a side panel over Today. Each step lists its **assigned forms** (e.g. Check-in: Registration, Insurance, Card authorization, HIPAA release, Photo consent, Medical history), each opens fillable in the panel with signing by the signer's own PIN. Nightingale never signs.
- **Photos & body charts:** delete for photos and body-chart drawings (confirmation + PIN-free cancel, audited `photo.delete`).
- **Custom templates:** surgeons/doctors upload their own body charts or pictures (name + kind + image) to use alongside the built-in templates, and can delete their own.

## Kept from v0.13
Scheduler (day/week, providers, office events, recurring events, print/PDF), patient chart, documents & AI summaries, records packet, HIPAA releases, PIN signing, audit trail, all station workflows.

## Tests
smoke13 suite (adapted to the new shell, plus Front Door tests) at 1180×820: **420 / 420 pass**, no page errors (v0.13: 369 at 1180).

## Not yet in the new design
- Medical, ASC and Patient Portal editions are not converted yet (next stages).
- Practice-settings screens, billing, Forms Studio and some admin pages open in the new shell but keep their v0.13 inner layout.
- Chat answers are scripted/local; texts, emails, payments remain simulated.
