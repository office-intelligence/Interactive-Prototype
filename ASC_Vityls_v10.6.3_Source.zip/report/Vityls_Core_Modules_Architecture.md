# Vityls Core + Modules: architecture (core-modules v1.0)

Branch `core-modules` (from `medical-v1.0`), tag `core-modules-v1.0`. Test build: `Vityls_Core_Modules_v1.0.zip`, one app with a practice switcher (bottom-left) and the internal **Vityls admin console** (`index.html#vityls-admin`).

## 1. The layers

```
┌───────────────────────── Editions (bundles + terminology + templates) ─────────────────────────┐
│  ASC.Vityls        Surgery.Vityls        Medical.Vityls        (MedSpa, Chiropractic … later)    │
├──────────────────────────────────────── Modules ───────────────────────────────────────────────┤
│ email-intake · scheduling · chart · stations-workflow · forms · messages · billing ·            │
│ records-packets · reports · photos-bodycharts · asc-perioperative · portal-link                 │
├──────────────────────────────────────── Vityls Core (always on) ───────────────────────────────┤
│ tenant/practice · users, roles & PINs · patients (minimal identity) · documents store · audit · │
│ Nightingale shell · notifications/outbox · subscription & entitlements                          │
└─────────────────────────────────────────────────────────────────────────────────────────────────┘
```

Code: `src/core/` (Core: `modules.ts` registry, `practices.ts` tenant + entitlements + simulated clock, `store.ts` module data layer + outbox, `useCore.tsx` React gating, `ui.tsx` teaser / trial banner / Modules & plan / minimal patient, `AdminConsole.tsx`), `src/modules/email-intake/` (new module). The shell (`src/surgery/SurgeryApp.tsx`) asks Core before it renders any nav entry, route, Practice panel, chart tab/card, Nightingale chip or Portal link.

## 2. Core services

| Service | What it holds | Today in the code |
|---|---|---|
| Tenant / practice | practice id, name, edition, namespace, teaser + expiry options | `src/core/practices.ts` (`vityls:core:practices`) |
| Users, roles & PINs | staff, providers, session, PIN signing, Forgot PIN | `src/surgery/staff.ts`, `v7/providers.ts`, `surgery/v12/pinReset.ts` |
| Patients (minimal identity) | name, DOB, sex, contact, language, insurance, allergies | `medRepo.patients()` (`vityls:med:patients`) |
| Documents store | every filed document (+ Nightingale summary) | `surgery/documents.tsx` (`vityls:surgery:documents`) |
| Audit | every action (practice audit) + entitlement audit | `repo.audit()` + `vityls:core:audit` |
| Nightingale shell | header card, chips, scripted answers | `surgery/v07/NightingaleCard.tsx`, `surgery/nightingale.ts` |
| Notifications / outbox | simulated email/SMS outbox | `vityls:mod:core:outbox` (`core/store.ts`) + legacy reminder outbox |
| Subscription & entitlements | module state per practice, trials, plan history | `core/practices.ts` |

## 3. Modules

The proposed list was kept with two adjustments, both from how the code really splits:
- **chart** covers notes, documents UI and timeline/activity (they share one page, `Chart7`, and one data set). The Patients **list** and the minimal patient record stay in Core, so every module can open a patient.
- **scheduling** owns Today as well as the Schedule: the Today board is the day's schedule plus arrivals and check-in. Visit types/reminder settings are its Practice panel.
- **portal-link** is a thin module (the Portal button, at-home check-in and portal side of messages/forms); the Patient Portal itself becomes its own app on Core (section 9).

| Module | Hard needs | Enhances | Surfaces it contributes | Alone / without chart | Trial |
|---|---|---|---|---|---|
| email-intake (new) | — | scheduling, chart | nav “Email intake”; Nightingale “Review new requests”, “Draft a reply” | creates/matches a Core patient, files attachments to Core documents, queues a scheduling request | 14 d |
| scheduling (+ reminders) | — | chart, forms, stations, email-intake | nav Today + Schedule; Practice “Visit types, intake lists & reminders”; chart Next/Past visits | patients open as the minimal Core record | 14 d |
| chart | — | scheduling, messages, billing | chart Overview/Clinical/Documents/Notes/Activity; Practice “Patient records” | records chart without scheduling | 14 d |
| stations-workflow | scheduling, chart | forms, billing | station route (visit workflow), station steps Front desk → Nursing → Provider → Checkout | needs a visit and a chart | 14 d |
| forms (+ editor, at-home) | scheduling | stations, chart | Practice “Forms & workflow”, form editor, at-home links, station form steps | with scheduling + minimal patient | 14 d |
| messages | — | chart, portal-link | nav Messages; chart portal messages card | “Open chart” → minimal record | 14 d |
| billing (invoices, payments, quotes) | — | chart, stations | Practice “Billing & payments”; chart quotes | invoices against Core patients | 14 d |
| records-packets | chart | forms | chart Print / Send button, Records sent log | lives on the chart | 7 d |
| reports | — | scheduling, billing, chart | Practice “Practice performance & reports” | reports on what is on | 7 d |
| photos-bodycharts | chart | records-packets | chart “Photos & charts” tab | lives on the chart | 7 d |
| asc-perioperative | scheduling | chart, forms | ASC OR/PACU/anesthesia (ASC app); Send to ASC (Surgery) | part of ASC bundle | 14 d |
| portal-link | — | forms, messages, billing | top-bar Portal link, at-home | — | 14 d |

```mermaid
graph TD
  CORE[Vityls Core: tenant · users/PINs · patients · documents · audit · Nightingale · outbox · entitlements]
  EI[email-intake] --> CORE
  SCH[scheduling] --> CORE
  CH[chart] --> CORE
  MSG[messages] --> CORE
  BIL[billing] --> CORE
  REP[reports] --> CORE
  PL[portal-link] --> CORE
  ST[stations-workflow] -->|requires| SCH
  ST -->|requires| CH
  FO[forms] -->|requires| SCH
  RP[records-packets] -->|requires| CH
  PH[photos-bodycharts] -->|requires| CH
  ASC[asc-perioperative] -->|requires| SCH
  EI -.enhances.-> SCH
  EI -.enhances.-> CH
  FO -.enhances.-> ST
  MSG -.enhances.-> CH
  BIL -.enhances.-> ST
  PL -.enhances.-> FO
  PL -.enhances.-> MSG
```

Solid arrows are hard dependencies; dotted are “enhances” (the module works without it and shows more when it is on).

## 4. Entitlement model

Per practice, each module has a state:

| State | Meaning | What the user sees |
|---|---|---|
| `off` | not in the plan | nothing, or a calm **“Try free for N days”** teaser (preview, description, Start trial) — per practice: `locked = teaser` (nav entry with a lock) or `hidden` (only on Practice › Modules & plan) |
| `trial` | `trial_start`, `trial_end`, days left | full module + a slim “free trial · N days left · Keep it” banner |
| `active` | paid | full module |
| `expired` | trial ended, data kept | per practice `expired = read-only` (module visible, inputs disabled, banner “Read only … Add to plan”) or `hidden` (teaser “Trial ended … Add to plan”) |

- Trials are evaluated against the clock (`now()`; the admin console can move a simulated clock **+7 days**). Expiry is persisted once and audited (`trial.expire`).
- **Dependency choice: “bring along, shown first.”** Enabling or trialing a module whose hard dependency is off shows the need on the teaser (“Needs Patient chart. The trial starts it too, for the same days.”) and on confirm starts the dependency with the same state and end date, marked `via = <module>`. Nothing starts silently. Switching off a module that another enabled module needs is refused with the reason (“Scheduling is needed by Forms & at-home…”). We chose this over a separate “lite” mode because the code has no second, smaller version of the chart or scheduler to maintain; the minimal standalone behaviour lives in Core (minimal patient record) instead.
- Only a practice manager/administrator can start a trial or add a module from inside the practice; Vityls staff can do everything from the admin console. Every change is audited with who/when/what.
- Outside the combined Core build (the per-edition packages) everything is on; nothing changes.

## 5. Proposed SQL tables (Azure SQL / T-SQL flavour)

```sql
CREATE TABLE practices (
  practice_id      UNIQUEIDENTIFIER PRIMARY KEY,
  name             NVARCHAR(200) NOT NULL,
  edition          VARCHAR(20) NOT NULL,          -- ASC | SURGERY | MEDICAL | MEDSPA | CHIRO
  plan_id          VARCHAR(40) NULL REFERENCES plans(plan_id),
  locked_display   VARCHAR(10) NOT NULL DEFAULT 'teaser',   -- teaser | hidden
  expired_display  VARCHAR(10) NOT NULL DEFAULT 'read-only',-- read-only | hidden
  created_at       DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME()
);
CREATE TABLE modules (
  module_id        VARCHAR(40) PRIMARY KEY,       -- 'email-intake', 'scheduling', …
  name             NVARCHAR(120) NOT NULL,
  description      NVARCHAR(1000) NOT NULL,
  default_trial_days INT NOT NULL DEFAULT 14,
  is_core          BIT NOT NULL DEFAULT 0
);
CREATE TABLE module_dependencies (
  module_id        VARCHAR(40) REFERENCES modules(module_id),
  depends_on       VARCHAR(40) REFERENCES modules(module_id),
  kind             VARCHAR(10) NOT NULL,          -- requires | enhances
  PRIMARY KEY (module_id, depends_on)
);
CREATE TABLE plans (
  plan_id          VARCHAR(40) PRIMARY KEY,       -- 'asc-full', 'surgery-standard', 'email-starter'
  name             NVARCHAR(120) NOT NULL,
  edition          VARCHAR(20) NULL,
  monthly_price_cents INT NOT NULL DEFAULT 0
);
CREATE TABLE plan_modules (                       -- edition bundles = plans
  plan_id VARCHAR(40) REFERENCES plans(plan_id), module_id VARCHAR(40) REFERENCES modules(module_id),
  PRIMARY KEY (plan_id, module_id)
);
CREATE TABLE practice_modules (                   -- current state, one row per practice × module
  practice_id      UNIQUEIDENTIFIER REFERENCES practices(practice_id),
  module_id        VARCHAR(40) REFERENCES modules(module_id),
  state            VARCHAR(10) NOT NULL,          -- off | trial | active | expired
  since            DATETIME2 NULL,
  via_module_id    VARCHAR(40) NULL,              -- started as a dependency of …
  PRIMARY KEY (practice_id, module_id)
);
CREATE TABLE trials (                             -- history: every trial, extension and outcome
  trial_id         UNIQUEIDENTIFIER PRIMARY KEY,
  practice_id      UNIQUEIDENTIFIER REFERENCES practices(practice_id),
  module_id        VARCHAR(40) REFERENCES modules(module_id),
  started_at       DATETIME2 NOT NULL, ends_at DATETIME2 NOT NULL,
  started_by       NVARCHAR(120) NOT NULL,
  outcome          VARCHAR(12) NULL,              -- converted | expired | cancelled
  outcome_at       DATETIME2 NULL
);
CREATE TABLE entitlement_audit (
  audit_id BIGINT IDENTITY PRIMARY KEY, practice_id UNIQUEIDENTIFIER NULL, module_id VARCHAR(40) NULL,
  action VARCHAR(40) NOT NULL, detail NVARCHAR(1000) NOT NULL, actor NVARCHAR(120) NOT NULL, at DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME()
);
-- a nightly job: UPDATE practice_modules SET state='expired' … WHERE state='trial' AND trial ends_at < now; insert audit rows.
```

Entitlements are checked **on the server** too: every module API route (`/api/m/scheduling/*`, …) rejects writes when `practice_modules.state` is not `trial|active` (reads allowed when `expired` and `expired_display = read-only`). The browser gating in this build is the UI half.

## 6. Data layer and per-module tables

- New module data goes through `moduleStore(moduleId)` (`src/core/store.ts`), key `vityls:mod:<module>:<key>` inside the practice namespace (one namespace per practice: `vityls-surgery~`, `vityls-medical~`, `vityls-p-sierra~`; ASC runs un-namespaced as before). Email Intake uses it (`inbox`, `requests`); the outbox is `vityls:mod:core:outbox`.
- Existing keys keep their names (renaming would break the frozen Surgery v0.13 / Medical v1.0 test data). Each module declares its key prefixes in `modules.ts › storage`, and `moduleOfKey()` maps any key to its owner. The admin console's **Data map** lists every key of the open practice by owner with size — this is the starting map for Henry's tables:
  - Core tables: `patients`, `documents`, `users`, `providers`, `staff`, `audit`, `outbox`.
  - Per-module tables: `sched_visits`, `sched_reminders`, `sched_appt_notes`, `chart_problems`, `chart_meds`, `chart_vitals`, `chart_labs`, `chart_notes`, `chart_diagnoses`, `station_nurse`, `station_scribe`, `station_orders`, `forms_templates`, `forms_submissions`, `msg_messages`, `bill_quotes`, `bill_payments`, `bill_charges`, `packets_sent`, `photos`, `bodycharts`, `email_inbox`, `email_extractions`, `email_sched_requests`.
- Every table carries `practice_id`; module tables never reference each other directly except along a declared hard dependency, and reference Core ids (patient_id, document_id, user_id) freely.

## 7. Editions = bundles

| Edition | Bundle (default `active`) | Terminology / templates |
|---|---|---|
| ASC.Vityls | all modules except email-intake (offered as an add-on) — runs the frozen ASC.Vityls app unchanged | ASC forms library, OR/PACU/anesthesia |
| Surgery.Vityls | scheduling, chart, stations-workflow, forms, messages, billing, records-packets, reports, photos-bodycharts, asc-perioperative (Send to ASC), portal-link | Surgeon, procedures, pre-op clearance packet |
| Medical.Vityls | Surgery bundle minus asc-perioperative | Doctor, Diagnosis & Plan, referral packet (`src/surgery/medical/terms.ts`) |
| MedSpa / Chiropractic (future) | pick modules + a terminology file + seed templates | — |

A practice's plan can always differ from its edition bundle: Sierra Vista Surgery Center is an ASC that starts with **AI Email Intake only** and is offered Scheduling, then Forms, as trials.

## 8. How to add a new module

1. Add an entry to `MODULES` in `src/core/modules.ts` (id, name, description, pitch, Core services, `requires`, `enhances`, nav/routes/Practice panels/chart surfaces/Nightingale/station steps, storage prefix, trial days). Add its tabs to `TAB_MODULE`.
2. Put the code in `src/modules/<id>/`; store data only through `moduleStore('<id>')` and Core services (patients, documents, audit, outbox).
3. Register its page in the shell (`SurgeryApp.tsx`: a nav entry in `NAV_ALL` and a `{tab === '<route>' && <Page/>}` line). The shell's gate shows the teaser, trial banner or read-only state for free.
4. Make it useful alone: when a soft dependency is off, fall back to Core (e.g. `MinimalPatient`) instead of hiding the action.
5. Add it to the edition bundles that should include it, and to the SQL `modules`/`plan_modules` seed.
6. Tests: module only, with/without each soft dependency, trial → expiry → add to plan.

## 9. The Patient Portal on Core

The Portal is a separate **app** on Core (patient-facing, its own login and Vityls patient ID), and `portal-link` is the practice-side **module** that connects a practice to it:
- Core holds the global patient identity and the consent/link table (`patient_practice_links`: patient_id, practice_id, scopes, granted/revoked).
- With `portal-link` on, the practice's forms, messages, check-in, bills and records packets are delivered to the Portal through that link; with it off, the practice uses the outbox (email/SMS links) only.
- The Portal's own paid features (wearables, trends, unlimited explanations) are entitlements of the **patient** account, modeled the same way (`patient_entitlements` with off/trial/active/expired). Anything a practice sends is never behind the patient's paywall.

## 10. Known limits of this build

- Gating is at the surface level (nav, routes, Practice panels, chart tabs/cards, Nightingale chips, Portal link). Some deep links inside large legacy pages (e.g. Today's “Check-in” button) still exist; when the target module is off they land on its teaser instead of breaking.
- Station steps contributed by Forms are not removed one by one; the whole station workflow is the stations module.
- The patient photo next to the name is still shown when photos-bodycharts is off (only the Photos & charts tab is gated).
- ASC.Vityls stays one frozen app; modular ASC is shown in the office shell (Sierra Vista).

## Test results (v1.0, 2026-10-14)
| Suite | Result |
|---|---|
| Core module checks (email-only, trial, add Forms, expiry, dependencies, teaser) | 44 / 44 |
| Surgery smoke13, Surgery default bundle, 1180 px | 369 / 369 |
| Medical med10 smoke, Medical default bundle, 1180 px | 369 / 370 (known: referral packet has no ECG) |
| ASC sanity vs ASC v7.5 | 4 / 4, pixel-identical |
