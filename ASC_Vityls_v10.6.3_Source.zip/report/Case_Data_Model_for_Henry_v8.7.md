# Case data model — v8.7 additions (for Henry)
Fictional test build; browser localStorage.
- `asc87-uploads`: {id, cid, pid, dos, type, name, size, mime, data?(dataURL ≤1.5 MB), note, by, role, at}. Shown in Documents for that case/DOS. Audit `asc87.upload`.
- `asc87-standing`: StandingOrder {id, category Pre-op|Post-op|PACU, text, drug, dose, route, freq, active, signer surgeon|anesthesia, example}. Seed = examples for Medical Director approval.
- Order items (asc86 sets) gain `orig` = standard dose; `value` = signed dose. History text marks adjustments.
- `asc87-invoices`: {id, cid, number INV-ASC-YYYY-####, lines[{label, detail, amount}], issuedAt, by}. Payments still come from asc83 pay (single source); invoice totals computed, not stored.
- `asc87-activity`: Nightingale activity feed {id, kind, text, cid?, at} (simulated).
