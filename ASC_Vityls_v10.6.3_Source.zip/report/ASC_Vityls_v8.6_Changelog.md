# ASC Vityls v8.6 · Changelog (branch asc-v8.6 from asc-v8.5 @ 4fe137f)

Built from Kevin's final notes, sections 1–10. See `ASC_v8.6_Notes_Gap_Audit.md` for the item-by-item audit: 54 items, of which v8.5 had 13 there, 23 partly there and 18 missing.

## Conflict with the notes (Kevin's rule wins)
The notes ask to "display holds and their resolution before the episode advances" and to close "only after … complete or an authorized exception". Kevin's standing rule is that **nothing ever blocks**. Cases move freely between stations, and the episode can always be closed. Missing items show as tinted warnings. On close, every open item is written to the audit log and stays on its owner's to-do list. Documenting an exception is optional.

## Doctor orders (new, section 4)
- New **Doctor orders** workbench with Pre-op, Post-op and PACU tabs. Each set is a structured checklist with editable patient-specific fields, an author, and a signer role (Surgeon or Anesthesiologist), chosen per set and enforced at signing.
- Statuses look clearly different: **Draft · not signed** (dashed yellow), **Signed · active** (green), **Discontinued** (red, struck through), **Superseded** (gray, struck through).
- Editing a signed set starts a new draft version. The signed version stays in effect until the new one is signed, and is then marked superseded. Version history shows the signer, the time, and a content hash. The signature is bound to the exact text, and any later change shows as "content changed after signing".
- Nightingale can only **propose a draft**. `signSet` rejects Nightingale or System as the signer.
- A banner marks all seeded order text as **EXAMPLE TEMPLATE TEXT awaiting clinical approval**. No drug names or doses are pre-filled; the ordering clinician enters them.
- A standalone **Active doctor orders** card appears on Nursing (pre-op) and PACU (PACU and post-op). It shows signed orders only, warns when a changed draft is pending, and offers Acknowledge, Record done per item, and Escalate to the surgeon or anesthesia. Signing a set flags nursing.
- The Surgeon bench now shows order status and links to Orders, replacing the free-text pre-op and post-op boxes. **The Anesthesia bench is unchanged.** Its legacy PACU orders text box stays, and the structured PACU set lives in Orders.

## PACU vitals flowsheet (section 5.1)
- 15-minute rows from PACU arrival, plus ad-hoc rows. Fields: BP, HR, RR, SpO₂, temperature, pain, and notes (intervention, response, escalation).
- Measured time is kept separate from entry time. Late entries (more than 10 minutes) are tagged. Corrections need a reason, and the original row stays visible, struck through.
- Overdue slots show a reminder and are never auto-completed. Rows are never copied forward; each new row starts blank.
- Small SBP, HR, SpO₂ and pain trend lines sit next to the active orders card.

## Discharge (5.2)
- New: criteria confirmation, a discharge authorization PIN signature from the surgeon or anesthesia, who understood the instructions and how (teach-back, verbal, interpreter), the copy given, transport, escort, and where any concern was routed. Existing nurse, patient and physician signatures are kept.

## After surgery and closure (section 6)
- **Formal op report** receipt card showing received, signed and amended. Surgeon-signed addenda carry a hash, and the original is kept.
- **Day-2 follow-up call**: owner, due date (DOS + 2), logged attempts and outcomes, escalation to the surgeon (suggested after a concern or 3 missed attempts), and mark complete. The **satisfaction survey** is tracked separately (simulated).
- **Episode closure** workbench: a Nightingale completeness check produces an owner-specific to-do list that needs human review ("I reviewed these findings"). A "Simulate AI unavailable" switch gives a manual reconciliation path. Exceptions can be documented per item. **Documentation status and Financial status are shown separately.** Close is never blocked. **Reopen for amendment** requires a reason and preserves signed versions.

## Worklist, search, print, audit, metrics
- An **Episode worklist** on Today for every station shows stage, next steps with owners, and tinted warnings. For example, missing clearance is shown as a warning, never a hold.
- **Find episode**: search by name or MRN plus date of service, which opens that single episode.
- **Print episode packet** (Chart › Documents) shows a paginated preview with a patient ID header on every page (name, MRN, DOB, DOS, title, "Page n of N"). Steps recorded outside the form templates print as supplemental sections, and pending steps print as PENDING. Printing is manual only, and no PDF is generated or saved.
- Packet prints, case-record prints and document exports are now **logged in the audit trail**.
- The surgical consent captures a **witness or patient representative**.
- **Efficiency metrics** card for admins: registration completion, unresolved pre-op items, median task turnaround, overdue documentation, episodes closed, duplicates prevented.

## Scheduling
- **Duplicate prevention** in Add appointment. A name+DOB, DOB+phone or name+phone match selects the existing chart; "Not the same person" creates a new chart and is logged.
- **Traceable booking, reschedule and cancel history** (from → to, reason, notices), shown in Appointment details and the chart.
- A **booking confirmation and two-day reminder** are queued for each case: arrive 1 hour before start, location, contact number, and generic fasting, medication and escort lines that send clinical questions to the care team. They are re-queued on reschedule and cancelled on cancel. All simulated.

## Still partial
- "Submitted vs reviewed" is not tracked separately for registration items.
- Hash-binding covers orders and op-report addenda, but not legacy form signatures.
- Paper downtime reconciliation is not built.
- There is no switch to stop automation.
- The legacy free-text PACU orders box remains on the Anesthesia bench (UI freeze).

## Tests
- tsc: 68 errors, the same as the baseline, with no new ones. Unit tests: `npx tsx --test tests/*.test.ts` → **172/172** (9 new in `tests/asc86.test.ts`).
- Episode walk: `python3 scripts/walk86.py URL 1440 390` → **39/39**. It covers booking, duplicate prevention, reschedule, cancel, missing clearance, Nightingale draft → signed → changed-unsigned → nurse sees v1 → v2 signed, PACU overdue/late entry/correction, discharge, follow-up, closure with open items, reopen, post-op addendum, print packet, export, metrics, and the Anesthesia bench unchanged.
# ASC Vityls v8.6.1 · Changelog (branch asc-v8.6.1 from asc-v8.6)

Kevin approved this change.
- **Anesthesia bench:** removed the old free-text PACU orders box and its "Sign PACU orders" button. Section 4 is now titled "Consent" instead of "Consent & post-op orders". Everything else on the Anesthesia bench is unchanged: airway, ASA and exam, type and technique, anesthesia consent, and pre-induction re-evaluation.
- **PACU orders** now live only in the structured Orders section (PACU tab, anesthesia signer).
- **Legacy data stays readable.** If a case has old free-text PACU orders, the Orders › PACU tab shows them read-only in a "Legacy free-text PACU orders" panel, with the original signer and time. That data is not migrated, edited or deleted. Older PACU task ticks and the audit pack still read it.

## Tests
- tsc: 68 errors, the same as the baseline, with no new ones. Unit tests: 172/172.
- `python3 scripts/walk86.py URL 1440 390` → **40/40**. The new check confirms the free-text box is gone and that the consent and pre-induction sections are still present.
