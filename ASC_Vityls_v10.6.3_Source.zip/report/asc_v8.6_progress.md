# ASC v8.6 progress
- [x] Gap audit (54 items)
- [x] Orders, flowsheet, discharge, follow-up, op receipt, closure, worklist, search, print packet, audit of print/export, witness, metrics, dedupe, schedule history, 2-day reminder
- [x] tsc 68 baseline, unit 172/172, episode walk 39/39 (1440 + 390)
