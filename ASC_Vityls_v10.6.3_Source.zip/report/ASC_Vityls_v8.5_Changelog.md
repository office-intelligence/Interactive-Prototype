# ASC Vityls v8.5 — Changelog (branch asc-v8.5 from asc-v8.4)

## Login modes (simulated; no real auth backend)
- New **Sign-in** control in the header with three device logins: **Front desk login** (current state of the day + front-desk functions), **Administrator login** (sees/does everything), **Clinical tablet · Staff login** (shared device for nurses, MAs, anesthesia, surgeons).
- Staff tablet stays signed in on the shared Staff login and shows a **read-only Today's board** (cases, times, rooms, status) plus "Who's using the tablet?" avatars and a PIN pad.
- A person taps their name/avatar + PIN (or PIN alone when it is unique) and then acts as themselves with their own role access. Header chip shows who, an idle countdown, **Switch** (quick PIN switch) and one-tap **Done** (hand-off).
- Auto-returns to the shared board after idle (default 2 min; configurable 30 s–15 min in Practice settings → "Clinical tablet idle timeout").
- Every user start/switch/end/timeout, tab view, station open and failed PIN is audited to the individual with the device id. Signing still requires the person's PIN.
- The old "Session" dropdown is kept as the **Test as** simulation switcher.
- Anesthesia workbench unchanged.

## Patients list
- Alternating rows get a light green tint (#f1f8f4); table scrolls inside its card on phones.

## Patient chart
- Tinted header card, teal avatar, colored Cases section (teal left accent), teal tab accents. Calm palette.

## Scheduler
- **Nightingale** search/chat box above the grid: "when is Hugo Pell", "Dr Patel's cases next week", "unconfirmed cases", "unpaid", "missing consent", "OR 2 tomorrow"… simulated over local data; results jump to the day/open the appointment.
- Case-type color legend row and "edit colors" removed (colors live in Practice settings).
