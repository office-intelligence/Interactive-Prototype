# Surgery.Vityls v1.2 — Changelog

All people, places and results are fictional. Faxes, emails, the ASC, payments and e-prescribing are simulated. Nothing is sent.

## For Kevin (plain language)

**Every patient now follows an 11-step journey.** It runs from scheduling through return visits. Each step has an owner, a due date and a checklist your practice can edit. Each checklist item is open, done, waived, blocked or waiting. Waiving an item needs a reason and a follow-up task, and everything is logged.

**The step page matches your approved mockup.** Opening a patient with an active journey lands on their current step. The page has:
- a stepper you can tap for a recap of each step
- Nightingale's handoff: what happened, linked documents, what is still open, the next action, sources, confidence and reviewer
- only the open checklist items, with Completed folded below
- documents, payments, ASC requirements and care team on the right
- the Nightingale composer docked at the bottom
- Front desk, Nurse and Surgeon role views

Mary James is at Step 7 exactly as in the mockup. You can work her clearance to the end: chase letter, ECG upload, surgeon PIN, send to ASC, then the simulated ASC confirmation.

**Confirmations are rare now.** You are only asked when:
- the information is older than 12 months
- it changed or contradicts an incoming record (for example, metformin ER 750 on the outside H&P)
- it is a safety checkpoint: photo ID at first arrival, allergies and medications at rooming, consent before surgery

One "All still correct" tap covers a whole group. Hover any known value to see when it was last confirmed.

**The chart is an Overview.** It shows a link to the current step. The Activity tab is now a Timeline with filters and "Review & sign".

**Nightingale coordinates.** Today shows "Your N things today" across all journeys, with overdue items and who they escalate to. She drafts letters and messages for staff review. She never diagnoses, prescribes, clears, signs or finalizes.

**The gaps are filled in:**
- acknowledgments tied to the quote version and its expiry
- Mark Ready after Step 2 and Step 8
- a surgery-day record for cancelled, delayed or changed surgeries
- operative note and discharge summary import
- red-flag screen, tracker and a proposed post-op schedule
- for returning patients: interval questions and a mark for each part of the record

**Your Oct 17 revisions:**
- Print/Send is in the chart header, between Profile and More.
- The separate Medication and Allergy lists are gone from packets. The summary sheet carries both.
- New: a face sheet and Avery 5160 labels, both in More › Print.
- In the sidebar, "Forms & Documents" is now **Practice Settings**.
- Billing & Payments is its own sidebar page for the front desk, administrators and doctors.
- The chat box is restyled, and spacing is a little more generous.
- The sidebar shows as an icon rail at 900–1280px and as a drawer below 900px. Your choice is remembered.
- Touch targets are at least 44px.

**Judgment calls:**
- I kept the app's existing staff names (Taylor Brooks, Riley Shaw).
- The mockup patient "Sam Patel" is now "Owen Carter". He is a 41-year-old man; reusing Mary James would have clashed with her chart.
- Alex Rivera is left as is.
- The chat box keeps 3px corners, per the standing rule.
- The label count and start position are asked with simple prompts.

## For Henry (technical)

**New code in `src/surgery/journey/`:**
- `logic.ts`: pure engine
- `confirm.ts`: sparing-confirmation rules
- `gaps.ts`
- `print.ts`: face sheet and Avery 5160 geometry
- `store.ts`: persistence, chart-fact sync, Step 7 actions mirrored into the v1.1 episode, fictional seed (flag `journeys-seeded-v12`)
- `coordinator.ts`: scripted Nightingale
- `JourneyPage.tsx`, `Gaps.tsx`, `Queue.tsx`, `printTools.ts`
- `journey.css`: mockup CSS scoped under `.jy`

**Changes to existing files:**
- `SurgeryApp.tsx`: routing, seed, sidebar, Billing role gate
- `v07/Chart7.tsx`: journey link, Timeline, Print/Send placement, Print menu
- `v07/Today7.tsx`: queue
- `v13/packet.ts`: lists hidden for Surgery
- `FdShell.tsx` and `fd.css`: rail and drawer bands, Surgery only, via `.fd-sv12`

Medical, ASC and Portal behaviour is unchanged. Changes are gated on `isMedical` or `brand === 'Surgery'`.

**Tests:**
- Unit tests: `npx tsx --test tests/journey.test.ts tests/episodes.test.ts`, 26 + 16.
- Regression: `scripts/smoke_v12.py`.
- The earlier runner pinned its v10–v13 and fd parts to the v1.0 build. It now rewrites every build URL to v1.2.
- Updated test expectations are snapshotted in `scripts/regress_parts/`.
- UI walk and screenshots: `scripts/shots_v12.py`, at 1440, 1180 and 820.
- Packaging: `scripts/package-surgery.mjs` (default OUT `Surgery_Vityls_v1.2`), then `scripts/zip_v12.py`.
