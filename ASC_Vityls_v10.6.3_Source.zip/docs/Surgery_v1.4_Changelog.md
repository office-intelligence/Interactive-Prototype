# Surgery.Vityls v1.4: Changelog

Test build. Every name and record is fictional. Everything external (portal, email, fax, card processing, ASC, video and phone calls) is simulated. ASC.Vityls is untouched.

---

## For Kevin (plain language): your v1.3 notes, item by item

1. **Send-forms popup (Step 1).** Checkboxes are now normal size and sit inline, to the left of each label. **X** and **Not now** close the popup, and so do **X** and **Done** on *Forms queued*. The popup opened by itself and could not be closed; it now opens on first entry and again from the **Send forms** button. Every other modal was checked for the same problem, and this was the only one.
2. **Chat home.** The *Ask Nightingale* box is now a rounded pill, like the chat bar at the bottom.
3. **Add form, in every station.** Front desk (top right of *Portal forms*), Nurse, Doctor (new **Forms** tab), Booking & clearance, ASC and Post-op/checkout all have it.
   - It opens a searchable list of your **My Forms** templates, showing which stations each form is placed at.
   - **Add** puts the form on this patient's visit as **Incomplete**.
   - Staff can then **Open form** or **Send to portal** (simulated).
   - Each add and each send is written to the change log and the audit trail.
4. **Upload documents** at the front desk, top right of *ID & insurance cards*, for PCP notes, labs, imaging and outside records. Pick the document type and it is filed to the chart's **Documents** folder (Nightingale summarizes it, on device), logged, and listed as filed.
5. **Today.** More padding on the left and right of the schedule list.
6. **Old v1.2 step page retired.**
   - On the workflow page, **Timeline** is now a short read-only list of the 7 steps. The second stepper and the old confirmation sections are gone.
   - The chart's *Current step* card reads "Step N of 7" and has **Open workflow**.
7. **Billing & payments, redesigned.**
   - Four totals: collected this month, balance due, patient credit, open surgery balances.
   - Tabs: Accounts, Visits to invoice, Payments, Surgery deposits.
   - *Back to Administration* is gone.
   - **Billing configuration** and the **fee per visit type** moved to the new **Practice Settings → Billing settings** page (saved and audited).
8. **Provider onboarding (Membership & Privileges Application).**
   - The Forms-library form now shows in full: it is open by default, with no inner scroll box.
   - The *Patient / Encounter* header is removed.
   - The page uses the warm design.
9. **Compliance & credentials.** The *Administration Home* link is removed, there is a proper page title, and the colors are the warm palette with Nightingale green (no purple).
10. **Forms & Workflow (My Forms).** Restyled: white header, warm cards, green accents, 3px corners.
11. **Practice profile & rooms.** New **Email** field.
12. **Schedule, week view.**
    - **Columns** now has an **X** and closes when you click outside it or press Esc.
    - Each day is split into the **providers and rooms you selected**, with their names as column headers.
    - New **Notes for this week** at the bottom, saved per week and audited.
13. **Patients list.** Clicking a patient, or the name, opens the patient **chart**.
14. **Workspaces.**
    - The Doctor tab bar is taller.
    - The X is replaced by **Close** next to **Save & close**, in every workspace.
    - **Close** warns only if you typed something that has not been saved yet.
15. **Booking & clearance (Step 5).**
    - **Clearance no longer waits for booking.** Decide Yes/No and send the PCP letter before or after the case is booked. A decision made earlier is copied to the case when it is booked.
    - The **PCP letter shows in full and is editable** (Nightingale drafts; you review).
    - **Tests needed** are checkboxes: H&P, CBC, CMP, UA, ECG, PT, PTT, CXR, all ticked by default. Untick any; none is fine. The letter follows the ticks, and the ASC step then asks only for the ticked tests.
    - **Delivery:** secure email and fax (simulated), and **Print to hand to the patient**.
    - Deposit is unchanged.
16. **Phone and video visits.** *Start phone visit* / *Start video visit* in Step 2 opens the **Doctor workspace** directly.

**Also done (known caveats from v1.3):**
- Blank fields are now outlined on **all** portal forms. That includes Admission Form and Medical History, which have no named fields.
- The chat bar stays visible over the slide-over workspaces where it fits. It is still hidden over the full-screen Doctor workspace, modals and form views, and below 900px.

---

## For Henry (technical)

**Branch** `surgery-v1.4` from tag `surgery-v1.3` (7ffd1c3), with small commits per item. Progress notes are in `report/v1.4_progress.md` in the repo.

| Area | Files |
|---|---|
| Add form | `src/surgery/v14/addForm.tsx`: `addedForms(pid)`, `addForm()`, `sendAddedToPortal()` (store key `flow-added-forms`; form records live under the visit id, or `portal-forms:<pid>`), `AddFormPicker`, `AddedFormsSection` (`embed` mode for the front desk). New audit actions: `forms.add`, `forms.portal.send`. |
| Clearance | `src/surgery/v14/clearance.tsx`: `ClearanceSection`, `letterFor`, `syncClearanceToEpisode`. `FlowState.clearance: ClrState` (required, tests, via, letter, sentAt). `factsFor` reads it when there is no episode. `FlowFacts.clearanceTests` limits Step 6 "docs received" to the chosen tests. `clearanceTests(pid)` drives the ASC list. |
| Billing | `src/surgery/v14/Billing.tsx`: `SurgeryBilling` (Surgery only; Medical keeps `BillingHub`) and `BillingSettings` (new tab `billing-settings`, store `billing-config`, audit `billing.settings`), which reuses `MedFeeScheduleEditor`. |
| Schedule | `SurgerySchedule.tsx`: in week view the columns are day × chosen resource, with a day header row (`sched-col[data-kind=day]` ×7, kept for the legacy suite) and resource sub-headers (`sched-subcol`). The picker closes on outside mousedown and on Esc. `WeekNotes` uses store `week-notes`, keyed by the Monday of the week, audit `schedule.weeknote`. |
| Workspaces | `flow/Workspaces.tsx`: dirty tracking (typed input outside the header; cleared by save-type buttons), **Close** with an unsaved-changes dialog (`ws-unsaved`), Upload documents (`AddDocumentDialog`), and the `flow-open-ws` event (front-desk Start remote → Doctor). `flow/FlowPage.tsx`: the Start-remote chip starts the visit and opens the Doctor workspace; Timeline is a 7-step list (JourneyPage import removed). |
| Shared (ASC unchanged) | `AdministrationPage` gets a new optional prop `hideAdminHome` (default false). `InviteLanding`: when `isSurgery`, the application HTML drops `.vityls-patient-header`, gets warm CSS and opens in full. |
| Styles | `src/surgery/v14/v14.css` (imported by SurgeryApp): chat-home pill, Today padding, picker, clearance, billing, compliance/My Forms overrides (scoped), taller doctor tabs, composer over slide-overs. `flow.css`: normal-size checkboxes inside `.flp-sec` and `.sv-modal`. |
| Routing | The Patients list row and name use `fullchart`. The chart's JourneyLink uses `flowFor` (7 steps). |

### Tests and scripts
- Unit: `npx tsx --test tests/*.test.ts`. New test: clearance without a booked case, with a chosen subset of tests.
- `scripts/smoke_v14.py`: Surgery full regression (768 + 1180) against `release/Surgery_Vityls_v1.4`.
- `scripts/smoke_med_v14check.py`: Medical check against `release/Medical_Vityls_v14check`.
  - Harness fix in `surgwork/fd/fdpart.py`: below 900px, Medical asserts its sidebar (no drawer, by design since v1.2) instead of the Surgery-only drawer check.
- `scripts/shots_v14.py`: UI walk at 1440 / 1180 / 820 (the v1.3 walk plus the v1.4 checks). Screenshots go to `report/surgery_v1.4_screens/`.
- `scripts/zip_v14.py`: the two zips.

### Known limits
- The unsaved-changes check is a heuristic (typed input not followed by a save-type button). Most workspace actions save at once.
- Week view with many chosen columns gets wide: 7 × N columns of 112px each, scrolling sideways.
- The provider application's restyle applies only to the Surgery family (Surgery and Medical). ASC keeps v7.5.
- Print uses the browser print dialog from a hidden frame. Email and fax are only logged.

## Final results (Oct 20, 2026)
- Unit tests: **64 / 64** (`npx tsx --test tests/*.test.ts`).
- Surgery full regression (768 + 1180): **841 / 841 PASS** (`report/logs/regress_v14_run1.log`).
- UI walk (1440 / 1180 / 820): **180 / 180**, with no page errors (`report/logs/shots_v14_run1.log`, screenshots in `report/surgery_v1.4_screens/`).
- Medical check (`Medical_Vityls_v14check`): **869 / 871**. The two failures are *768 fd drawer below 900px* and *1180 fd icon rail on tablet*. Both are Surgery-only nav-shell assertions: FdShell enables the rail/drawer only for the Surgery brand, and that has not changed since v1.2. The same drawer failure was reported in v1.3. These are not regressions. The harness was not changed.
