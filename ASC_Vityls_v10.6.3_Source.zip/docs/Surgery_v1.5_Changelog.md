# Surgery.Vityls v1.5 — Changelog

Branch `surgery-v1.5`, built from `surgery-v1.4` (2f42c86). React/Vite/TS. All data is fictional and every external action is simulated. ASC is untouched. Medical keeps the old station page; every change is guarded with `!isMedical`. Nightingale never signs, orders or blocks.

## Structural changes
- **A. The Surgeries page is removed.** Its nav item is gone. The old `surgeries` tab now renders the Patients list, so stale links still land somewhere.
- **B. The old station page is retired (Surgery only).**
  - Every entry point now opens the new slide-over workspace through one app-wide `WsHost` (event `flow-open-ws`). The entry points are Today's schedule chips and Check-in, the appointment panel, Front Door chat and search, the composer, the chart and the workflow dots.
  - Everything the station had was moved first (see the list below).
- **C. To-do lists.**
  - Each patient chart has a To-do section after the header.
  - The Today To-do slide-out covers all patients. It has Open (launches the workspace) and Chart, plus Nightingale's "why" for each item.
  - Nightingale infers the surgical chain in `openTodos()` (flow/logic.ts):
    - An undecided patient gets a single follow-up item.
    - A quote item appears only once surgery is suggested.
    - Deposit, case and clearance follow acceptance.
    - The PCP step follows when clearance is required.
    - ASC send/confirm and post-op follow a booked case.
- **D. No gating.**
  - All steps open at any time. Journey blockers from v1.2 no longer throw.
  - The 7-step workflow page stays as the journey/history view and is reachable from the chart ("Journey & history" / "Open workflow").

## Moved from the old station
- Identity check (name, DOB, phone, email, language, insurance, emergency contact; "Identity confirmed") → Front desk workspace.
- Arrived / checked-in times with "Now" → Front desk workspace.
- Station forms per role (front office check-in, nursing rooming, surgeon, checkout) → "Forms for this step" in the Front desk, Nurse, Doctor and Checkout workspaces.
- Step sign-off with PIN ("Verify check-in / rooming / provider / checkout") → each workspace. It is optional and nothing waits on it.
- Photo ID front/back upload → Front desk workspace.
- Nurse vitals and rooming autosave → Nurse workspace (saver).
- Surgeon draft keeping → Doctor workspace (saver).
- Remote (phone/video) start → Doctor workspace only.
- Intake details → Scheduling workspace.
- Checkout step (orders, fees, payment) → new Checkout workspace.
- Visit record view → new Record workspace ("Last visit record").

## Smaller fixes
1. The header has only **Save & close**, and it saves whatever was typed (save registry `flow/wsSave.ts`). Esc and clicking the scrim also save. The Close button and the unsaved-changes modal are gone.
2. Every **Open chart** opens the chart page.
3. **Pregnancy test** is in the clearance tests and the practice default list. It is left off for male patients. Settings has a "Practice default tests" editor. The PCP letter has **email and fax** fields, prefilled from the PCP contact and editable. Both are used in delivery and the log.
4. One **Upload clearance packet** button. Nightingale (simulated, `v15/packet.ts`) matches the items in the packet and keeps items already on file. Staff can correct any match ("corrected by staff").
5. **Post-op visit note** with Record (simulated dictation) or typing, signed with a clinical PIN and saved as a signed visit note. It picks the first unsigned post-op visit.
6. Workflow page: the Timeline button is gone, and the check bubbles show date and time.
7. Phone and video start buttons appear only in the Doctor workspace.
8. The Doctor tab bar is 68–70px with no clipped text.
9. Separate **Phone Consult** and **Video Consult** fees, each the default for its visit type. They are added to saved schedules once.
10. Practice › Billing & payments link removed (Surgery). Medical keeps it.

## Tests
See the final report for counts. Harness changes:
- `scripts/shots_v15.py`: the v1.5 walk.
- `scripts/smoke_v15.py`: the v1.4 regression adapted.
  - Check-in now expects the Front desk workspace.
  - The legacy parts written for the retired station page run under a guard that records an early stop as a failure.
- `scripts/smoke_med_v15check.py`: Medical check.
- `fdpart.py`: the chat action may open a workspace.

## Caveats
- The legacy regression parts v8–v12, pin, att, hd, packet, hipaa and fdpart2 were written against the station page (`sv-station`, `st-*` tabs). Where they stop early, that reflects the intentional retirement in item B, not a regression. The v1.5 walk covers the same functions in the new workspaces.
- Dictation, packet matching, PCP delivery and reminders are all simulated.

## Results
- Unit tests: 70/70.
- v1.5 walk (`shots_v15.py`): 100/100 at each of 1440, 1180 and 820. No page errors, and no links to the retired station page.
- Regression (`smoke_v15.py` at 1180): 286/296, no page errors.
  - All 10 failures come from legacy parts written for the retired station page.
  - The hdpart stop is a screenshot timeout.
- Medical check: 0 functional failures in 281 checks at 768 and 328 checks at 1180.
  - Both runs stopped on a Playwright `Page.screenshot` timeout ("waiting for fonts") on the box under load. These are harness/environment stops, not assertion failures.
  - The suite did not reach its end.
