# Surgery.Vityls v1.3: Changelog

Test build. Every name and record in it is fictional, and everything external (portal, email, fax, card processing, ASC, video calls) is simulated.

---

## For Kevin (plain language)

### The chat workflow is now the real app
Opening any patient now shows the chat-style page from the approved mockup, replacing the v1.2 step pages for **every** patient. Each existing patient got a workflow built from what is already in their chart.

- **Seven dots across the top** follow your 7 steps: Scheduling, Front desk, Nurse, Doctor, Book & clear, ASC, Post-op. A pill next to them shows **Undecided** when that applies.
- **Nightingale says one thing:** what the current step needs. It flags only what is **missing** or **does not match**. It gives no recap of routine front-desk steps and asks for no reconfirmation.
- **Buttons under the message open the real workspace.** These are the actual screens, not short popups:
  - **Front desk:**
    - The forms the patient sent from the portal are listed with their status. *Open form* shows the full form, and blank or mismatched fields are outlined, with a Nightingale card listing them.
    - ID and insurance card images.
    - **Arrived.**
    - The real **Collect payment** dialog. It is still simulated, with a note that in production cards are captured by the processor's hosted fields or the card terminal, so card numbers never touch Vityls.
  - **Nurse:** the full nurse station (ambient intake, vitals including RR, reason, notes).
  - **Doctor:** opens **full screen**. Tabs: *Scribe & consult note*, *Body charts*, *Pre-op photos*, *Price quote*, *Plan & decision*. A Nightingale side rail shows the next item, nurse intake, vitals (RR is highlighted if missing), allergies, medications, problems, media and quotes. *Plan & decision* has **Consultation Performed — Undecided**.
  - **Book & clear (Step 5):**
    - Mark the quote accepted.
    - Deposit amount and due date, plus *Collect deposit now*.
    - Book the case with surgery date and time.
    - Clearance yes or no.
    - If yes, Nightingale drafts the letter to the PCP with the checklist (H&P, CBC, CMP, UA, ECG, PT, PTT, CXR). You review it and *Send to PCP* (simulated).
  - **ASC (Step 6):**
    - Each PCP item is shown as Done or Missing, with an upload for the missing ones.
    - Discrepancies such as Mary's metformin dose, each resolved with one tap.
    - *Send to ASC* (simulated reply), and *ASC confirmed* with the time.
  - **Post-op (Step 7):** routine visits with *Send reminder* and *Confirmed* only.
- **Save & close** posts a ✓ line in the chat for each item that was finished, and Nightingale moves to the next prompt.
- **Past dots open that station for editing.** Every open and edit goes into the **change log** (*Show change log*).
- **Status words** are only *Done, Incomplete, Due, Overdue*. "Open" appears only on buttons.
- **The checklist** (behind *Show checklist*) lists only critical items. Earlier steps collapse into one "Steps 1–N complete" line.
- **Undecided:**
  - *Consultation Performed — Undecided* stops the workflow after the consult.
  - When the patient calls back, *Patient called back · resume at Step 5* picks up at booking, with Steps 1–4 kept on file. That is the abbreviated workflow.
  - *Keep undecided* leaves the workflow stopped.

### Today
- The greeting and **schedule come first**. The four numbers moved below the schedule.
- The **To-do** list moved into a **slide-out side panel** (*To-do (N)* button). It has the next critical item per patient, grouped Overdue, Due today, This week, then Later.
- The green Nightingale box is gone. A **rounded chat bar (+, mic)** is now fixed at the bottom of **every** page, the one exception to the 3px corners. **+** offers New appointment, Find or add a patient, Attach a document (simulated) and New chat. The mic is simulated and records nothing.

### Appointment type (Surgery and Medical; not ASC)
- **In Office, Video Consult, Phone Consult** are now in the *Add appointment* and *Edit appointment* popups.
- Each type has its own icon on scheduler blocks, the Today list, appointment details and the station header.
- Video and phone visits **skip arrival and rooming**. The button reads **Start video visit** or **Start phone visit** (simulated).
- For phone visits the Doctor step drops body charts and photos. For video visits the photos are the ones the patient sent.

### Example patients for the demo (fictional)

| Scenario | Patient | What it shows |
|---|---|---|
| A | Tomas Exampleton | Today 1 PM, Front desk. Portal forms are back with a blank emergency-contact phone, and card images are missing. |
| B | Ruth Calder, 58, hypertension | Consult signed and quote presented. She is at Step 5: booking, clearance and PCP letter. |
| C | Mary James | Step 6. The ECG is missing from the PCP packet, and the metformin dose differs from the outside H&P. |
| D | Lena Ortiz | Undecided since July (second opinion), with an expired quote. A portal message today says she wants to go ahead. |
| Video | Priya Nair | New-patient video consult today at 11:30. |
| Phone | Ben Cho | Phone follow-up today at 3:15 PM. |

The Medical edition also has one video and one phone visit today.

### Everything from v1.2 is still there
Face sheet, Avery 5160 labels, Billing, Practice Settings, Print/Send in the header, nav rail and drawer, and the timeline (now the *Timeline* button on the patient page). The PIN is asked only at signing. No PDF is made automatically at case close.

---

## For Henry (technical)

**Branch** `surgery-v1.3` from tag `surgery-v1.2`, with small commits per sub-item (S1–S8). Progress notes are in `report/v1.3_progress.md`.

### New modules (`src/surgery/flow/`)

| File | What it does |
|---|---|
| `logic.ts` | Pure 7-step engine. `FlowFacts` → `deriveFlow()` → `Flow{step, undecided, stopped, resumed, items, remote}`. Also `statusFor` (Overdue if past due, Due within 2 days, else Incomplete), `nextItem`, `carried`, `checklist`, `openable`, `fromJourneyStep` (v1.2 11-step → 7) and `todoGroups`. Earlier unfinished items are **carried forward and flagged**, not blocking. Undecided caps at Step 4 with `stopped`. Resume puts a floor at Step 5. A surgery date in the past forces Step 7. |
| `store.ts` | `factsFor(pid)` maps chart, episode (v1.1), journey (v1.2), quotes, payments, media, portal forms and cards into FlowFacts. Also: `flagsFor` (missing and discrepancy only), `formReviews` / `registrationGaps` (blank keys and mismatches against the chart's name, DOB, phone and email), Undecided / resume, `logFlow` (flow-audit plus `repo.audit 'workflow.update'`), `postCheck`, `todos()` (one next item per patient), and `ensureAllJourneys()`, which gives every patient a v1.2 journey built from their earliest visit (flag `flow-journeys-v13`). |
| `FlowPage.tsx` + `flow.css` | The page, ported from `mockups/build_cf/extra.css` and scoped under `.fl`. Snapshot of done keys when a workspace opens; diff on close; `postCheck` and `logFlow` for each new Done. |
| `Workspaces.tsx` | Slide-over host (Doctor = full screen, `.flp.full`). Reuses `NurseStep`, `SurgeonStep`, `BodyChartsSection`, `PhotoGallery`, `QuoteList`/`NewQuoteButton`, `CollectPayment`, `CardsPanel`, `FormPage`, `startEpisode`, `EL.decideClearance` / `requestClearance` / `applyPayment`, `linkEpisode`, `receiveClearance`, `sendToAsc` / `ascConfirmed` and `draftFor('s7-request')`. Blank-field outlines are injected into FormPage's **shadow DOM** (a `<style data-flblank>` inside each shadow root). |
| `Composer.tsx` | The fixed pill composer. It keeps the `nightingale-bar` / `nightingale-input` / `nightingale-answer` testids so the existing suites still drive it. |
| `apptMode.tsx`, `remote.ts` | `modeOf`, `isRemote`, `ModeIcon`, `ModePicker`, `startRemoteVisit` (check-in, then step `provider`, audit `visit.remote.start`). `MedVisit.mode?: 'video'\|'phone'`; undefined means In Office. |
| `seed.ts` | `ensureFlowSeed()` (flag `flow-seeded-v13`) for scenarios A–D, the video/phone examples and the Medical remote visits. |

### Routing and other changes
- `SurgeryApp.openChart`: every Surgery patient goes to the `episode` tab, which renders `FlowPage`. Medical is unchanged. *Open chart* goes to `fullchart`.
- In FD Surgery, the page-top `NightingaleCard` is replaced by the composer. Chart7's card keeps its summary and chips, but its ask box is hidden (`noAsk`) so there is a single input.
- `Today7`: for Surgery, KPIs come after the schedule and the To-do slide-out is added. The v1.2 JourneyQueue moved inside the To-do panel as a disclosure. Medical's Today is unchanged.
- Registration is strict for upcoming visits that are not yet checked in. Past closed visits count their station items as "on file", so legacy patients don't flood the To-do list.
- `index.html`: an inline favicon. The only console 404 was `GET /favicon.ico`.
- `package-surgery.mjs` defaults to `Surgery_Vityls_v1.3`.

### Tests
- Unit: `npx tsx --test tests/*.test.ts`. New: `tests/flow.test.ts` (7-step mapping, statuses, Undecided/resume, remote) and `tests/apptMode.test.ts`.
- Fast type-check without the out-of-memory error: `npx tsc -p /tmp/tsflow.json` (files limited to flow/*, Today7, Chart7, SurgeryApp). One existing error remains in Chart7 at line 289 (`up`), unrelated to this build.
- Regression: `scripts/smoke_v13.py` (768 and 1180 in one run). Intentional adjustments:
  1. A context init-script taps **Open chart** whenever the flow page appears, because legacy suites expect the chart or step pages.
  2. The `today-today` click is skipped when the button is disabled. `fdpart` hard-codes 2026-10-20 as "not today", and today is 2026-10-20.
- Medical check: `scripts/smoke_med_v13check.py` runs against `release/Medical_Vityls_v13check` (the released v2.0 folder is untouched). The v1.2 drawer handling is ported into its click helper, which the shared shell needs below 900px.
- Walk: `scripts/shots_v13.py` at 1440 / 1180 / 820. Screenshots go to `report/surgery_v1.3_screens/`.

### Known limits
- Admission Form and Medical History are generated forms with no named fields, so blank highlighting works on Patient Registration only.
- The composer also shows on chart pages. Questions there go to `chartAnswer` for that patient.
- The deposit can be recorded before the case is booked (kept in flow-state). It is applied to the episode when a payment is collected after booking.

## Final results (Oct 20, 2026)
- Surgery full regression (768 + 1180): **841 / 841 PASS** (`report/logs/regress_v13_run7.log`).
- Medical check (Medical_Vityls_v13check): **653 / 654**. The single FAIL, "768 fd drawer below 900px", is a Surgery-only v1.2 assertion: `FdShell` enables the drawer only when `brand === 'Surgery'`, unchanged since v1.2, so Medical correctly has no drawer. It is not a regression.
- Unit tests: **63 / 63** (`npx tsx --test tests/*.test.ts`).
- Playwright UI walk at 1440/1180/820: **90 / 90**, no page errors (`report/surgery_v1.3_screens/`).
