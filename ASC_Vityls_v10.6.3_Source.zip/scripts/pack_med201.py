# Medical.Vityls v2.0.1 packaging (v2.0 zips left untouched).
import zipfile, os, subprocess, shutil
R='/workspace/vityls/src_v6/vityls_final_build'; REL=R+'/release/Medical_Vityls_v2.0'; W='/workspace/vityls'; M=W+'/medwork/v20b'
for f in ['README.txt','start-mac.command','start-windows.bat']:
    if os.path.exists(M+'/'+f): shutil.copy(M+'/'+f, REL+'/'+f)
shutil.copy(R+'/report/Medical_v2.0_Changelog.md', REL+'/Medical_v2.0_Changelog.md')
z=zipfile.ZipFile(W+'/Medical_Vityls_v2.0.1.zip','w',zipfile.ZIP_DEFLATED)
for d,_,fs in os.walk(REL):
    for f in fs: p=os.path.join(d,f); z.write(p,'Medical_Vityls_v2.0.1/'+os.path.relpath(p,REL))
z.close()
files=subprocess.check_output(['git','ls-files'],cwd=R,text=True).split('\n')
z=zipfile.ZipFile(W+'/Medical_Vityls_v2.0.1_Source.zip','w',zipfile.ZIP_DEFLATED); n=0
for f in files:
    if f and os.path.isfile(R+'/'+f) and not f.startswith(('release/','dist')): z.write(R+'/'+f,'Medical_Vityls_v2.0.1_Source/'+f); n+=1
z.close(); print('ok',n, round(os.path.getsize(W+'/Medical_Vityls_v2.0.1.zip')/1e6,1), round(os.path.getsize(W+'/Medical_Vityls_v2.0.1_Source.zip')/1e6,1))
