import asyncio
from playwright.async_api import async_playwright
U='file:///workspace/vityls/src_v6/vityls_final_build/release/Surgery_Vityls_v1.0/index.html'
O='/workspace/vityls/src_v6/vityls_final_build/report/frontdoor_surgery_screens'
async def main():
  async with async_playwright() as p:
    b=await p.chromium.launch(executable_path='/usr/bin/google-chrome')
    pg=await (await b.new_context(viewport={'width':1180,'height':820})).new_page()
    async def s(n): await pg.wait_for_timeout(500); await pg.screenshot(path=f'{O}/{n}.png'); print('shot',n,flush=True)
    async def c(x): await pg.locator(x).first.click(timeout=8000); await pg.wait_for_timeout(500)
    await pg.goto(U+'?reset-test-data'); await pg.wait_for_timeout(1500); await pg.goto(U); await pg.wait_for_timeout(1500)
    await s('01_chat_home')
    await c('[data-testid=sv-nav-home]'); await s('02_today_timeline')
    await c('[data-testid=today-next]'); await s('03_today_next_day')
    await c('[data-testid=today-today]')
    await pg.locator('[data-testid=fd-tl-row]').first.locator('[data-testid=fd-tl-station-check-in]').click(); await pg.wait_for_timeout(700)
    await s('04_station_panel_forms')
    o=pg.locator('[data-testid=fd-station-drawer] [data-testid^=fd-form-open-]')
    if await o.count(): await o.first.click(); await pg.wait_for_timeout(1200); await s('05_station_form_fill')
    await pg.goto(U); await pg.wait_for_timeout(1200)
    await c('[data-testid=sv-nav-schedule]'); await s('06_schedule_day')
    await c('[data-testid=view-week]'); await s('07_schedule_week')
    await c('[data-testid=sv-nav-patients]'); await c('[data-testid=patient-MED-1001] button'); await pg.wait_for_timeout(600); await s('08_patient_chart')
    await c('[data-testid=chart-tab-photos]'); await s('09_photos_delete_upload')
    await pg.set_viewport_size({'width':390,'height':844}); await pg.goto(U); await pg.wait_for_timeout(1200); await s('10_mobile_chat_home')
    await b.close()
asyncio.run(main())
