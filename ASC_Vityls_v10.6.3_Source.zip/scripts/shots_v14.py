# Surgery.Vityls v1.4 · Playwright walk (v1.3 walk + Kevin's v1.4 list) (1440 / 1180 / 820): Today + To-do, scenarios A–D on real seeded patients,
# the full-screen Doctor workspace and a video visit. Screenshots → report/surgery_v1.4_screens/. Fictional data only.
import asyncio, os, re, sys
from playwright.async_api import async_playwright
URL='file:///workspace/vityls/src_v6/vityls_final_build/release/Surgery_Vityls_v1.4/index.html'
OUT='/workspace/vityls/report/surgery_v1.4_screens'; os.makedirs(OUT, exist_ok=True)
R=[]
def ok(n,c): R.append((n,bool(c))); print(('PASS ' if c else 'FAIL ')+n, flush=True)
async def run(W,H):
  async with async_playwright() as p:
    b=await p.chromium.launch(executable_path='/usr/bin/google-chrome'); pg=await (await b.new_context(viewport={'width':W,'height':H})).new_page(); errs=[]
    pg.on('pageerror',lambda e:errs.append(str(e)))
    shot=lambda n: pg.screenshot(path=f'{OUT}/{W}_{n}.png')
    async def tid(t, timeout=6000): await pg.locator(f'[data-testid={t}]').first.click(timeout=timeout); await pg.wait_for_timeout(600)
    async def nav(t):
      if await pg.locator('[data-nav=drawer]').count() and not await pg.locator('[data-testid=fd-side].open').count(): await pg.locator('[data-testid=fd-hamburger]').click(); await pg.wait_for_timeout(300)
      await tid(t)
    async def patient(name):
      # v1.4 #13: the Patients list opens the chart; the workflow is one tap away (Open workflow)
      await nav('sv-nav-patients'); await pg.get_by_text(name, exact=True).first.click(); await pg.wait_for_timeout(900)
      await tid('chart-to-episode'); await pg.wait_for_timeout(500)
    step=lambda: pg.locator('[data-testid=flow-page]').get_attribute('data-step')
    prompt=lambda: pg.inner_text('[data-testid=flow-prompt]')
    await pg.goto(URL+'?reset-test-data'); await pg.wait_for_timeout(2500)
    if await pg.locator('[data-testid=fd-chat-home]').count(): await nav('sv-nav-home')
    # ---- Today ----
    ok(f'{W} Today greeting first', await pg.locator('[data-testid=today-greeting]').count()==1)
    order = await pg.evaluate("()=>{const a=document.querySelector('[data-testid=dash-patients]'),k=document.querySelector('[data-testid=today-kpis]'); return !!(a&&k&&(a.compareDocumentPosition(k)&4))}")
    ok(f'{W} Today schedule before KPIs', order)
    ok(f'{W} Today: no green Nightingale box', await pg.locator('[data-testid=sv-dashboard] .v7-ng').count()==0)
    ok(f'{W} pill composer fixed at bottom', await pg.locator('[data-testid=flow-composer]').count()==1 and (await pg.eval_on_selector('[data-testid=flow-composer]','e=>getComputedStyle(e).position'))=='fixed')
    ok(f'{W} schedule shows appointment-type icons', await pg.locator('[data-testid=dash-patients] [data-testid=appt-mode-icon][data-mode=video]').count()>=1 and await pg.locator('[data-testid=dash-patients] [data-testid=appt-mode-icon][data-mode=phone]').count()>=1)
    await shot('01_today')
    await tid('today-todo-open'); ok(f'{W} To-do slide-out', await pg.locator('[data-testid=today-todo-panel] [data-testid=todo-item]').count()>=3); await shot('02_today_todo'); await tid('today-todo-close')
    await pg.fill('[data-testid=nightingale-input]','who is next'); await pg.press('[data-testid=nightingale-input]','Enter'); await pg.wait_for_timeout(700)
    ok(f'{W} composer answers', await pg.locator('[data-testid=nightingale-answer]').count()==1); await shot('03_composer_answer')
    # ---- Scenario A: Tomas (front desk, portal forms with a blank field, cards missing) ----
    await patient('Tomas Exampleton'); ok(f'{W} A Tomas at Step 2', await step()=='2'); t=await prompt()
    ok(f'{W} A flags the blank field + missing cards only', 'blank field' in t and 'image' in t and 'confirm' not in t.lower())
    await shot('10_A_tomas_flow'); await tid('flow-open-ws'); ok(f'{W} A front desk workspace opens', await pg.locator('[data-testid=ws-front]').count()==1)
    ok(f'{W} A payment note: card data never touches Vityls', 'never touch' in await pg.inner_text('[data-testid=ws-pay-note]'))
    await shot('11_A_frontdesk_ws'); await tid('ws-form-open'); ok(f'{W} A full form view + highlighted blank', await pg.locator('[data-testid=v6-form-page]').count()==1 and int(await pg.locator('.flp-form').get_attribute('data-blanks') or 0)>=1)
    await shot('12_A_form_highlight'); await tid('ws-form-back2'); await tid('ws-collect'); ok(f'{W} A Collect payment dialog', 'Collect payment' in await pg.inner_text('body')); await shot('13_A_collect_payment')
    await pg.locator('[role=dialog][aria-label="Collect payment"]').get_by_role('button', name='Cancel').click(); await pg.wait_for_timeout(300)
    await tid('ws-arrive'); await tid('ws-reg-accept'); await tid('ws-save')
    ok(f'{W} A saving posts checks to the chat', await pg.locator('[data-testid=flow-check]').count()>=1); await shot('14_A_after_save')
    # ---- Scenario B: Ruth (Step 5 booking chain + clearance + PCP letter) ----
    await patient('Ruth Calder'); ok(f'{W} B Ruth at Step 5', await step()=='5'); await shot('20_B_ruth_flow')
    await tid('flow-open-ws'); await shot('21_B_booking_ws')
    # v1.4 #15: clearance before booking (parallel), full editable letter, test picker, delivery options
    await tid('ws-clr-yes'); ok(f'{W} B clearance decided before booking', await pg.locator('[data-testid=ws-book-pcp]').count()==1 and await pg.locator('[data-testid=ws-clr-parallel]').count()==1)
    ok(f'{W} B test picker defaults to the practice list (8)', await pg.locator('[data-testid=ws-clr-tests] input[type=checkbox]:checked').count()==8)
    await tid('ws-clr-test-PTT'); await tid('ws-clr-test-CXR'); lt=await pg.input_value('[data-testid=ws-pcp-letter]')
    ok(f'{W} B letter follows the chosen tests', 'Chest x-ray' not in lt and 'PTT' not in lt and 'CBC' in lt)
    sh=await pg.eval_on_selector('[data-testid=ws-pcp-letter]','e=>e.scrollHeight<=e.clientHeight+4'); ok(f'{W} B letter shows in full', sh)
    ok(f'{W} B delivery: email, fax, print', await pg.locator('[data-testid^=ws-pcp-via-]').count()==3)
    await pg.locator('[data-testid=ws-book-pcp]').scroll_into_view_if_needed(); await shot('22_B_pcp_letter')
    await pg.locator('[data-testid=ws-book-clearance]').scroll_into_view_if_needed(); await shot('22b_B_clearance_tests')
    await tid('ws-pcp-send'); ok(f'{W} B letter sent before booking', await pg.locator('[data-testid=ws-pcp-sent]').count()==1)
    for t in ['ws-quote-accept','ws-dep-record','ws-case-book']: await tid(t)
    await tid('ws-save')
    ok(f'{W} B advances to Step 6 (ASC)', await step()=='6'); ok(f'{W} B five checks posted', await pg.locator('[data-testid=flow-check]').count()>=5); await shot('23_B_after')
    # ---- Scenario C: Mary (ASC: ECG missing + metformin discrepancy) ----
    await patient('Mary James'); t=await prompt(); ok(f'{W} C Mary at Step 6', await step()=='6'); ok(f'{W} C flags ECG + metformin', 'ECG' in t and 'Metformin' in t)
    await shot('30_C_mary_flow'); await tid('flow-open-ws'); await shot('31_C_asc_ws'); await tid('ws-asc-upload-ECG'); await tid('ws-flag-ours'); await tid('ws-asc-sendbtn'); await pg.wait_for_timeout(2300); await tid('ws-save')
    ok(f'{W} C no flags left after fixes', await pg.locator('[data-testid^=flow-flag]').count()==0); await shot('32_C_after')
    await tid('flow-dot-2'); ok(f'{W} C past dot opens station for editing', 'editing Step 2' in await pg.inner_text('[role=dialog]')); await tid('ws-close')
    await tid('flow-history-toggle'); ok(f'{W} C change log lists the edit', 'for editing' in await pg.inner_text('[data-testid=flow-history]')); await shot('33_C_changelog')
    # ---- Scenario D: Lena (Undecided → resume at Step 5) ----
    await patient('Lena Ortiz'); ok(f'{W} D Lena stopped at Step 4 (Undecided)', await step()=='4' and 'Undecided' in await prompt()); await shot('40_D_lena_undecided')
    await tid('flow-resume'); ok(f'{W} D resumed at Step 5 (abbreviated)', await step()=='5'); await shot('41_D_resumed')
    # ---- Doctor full workspace (Daniel, roomed today) ----
    await patient('Daniel Reyes'); ok(f'{W} Daniel at Step 4', await step()=='4'); await tid('flow-open-ws')
    full = await pg.eval_on_selector('[data-testid=ws-doctor]','e=>e.getBoundingClientRect().width')
    ok(f'{W} Doctor workspace is full screen', full>=W-2); ok(f'{W} Doctor tabs + Nightingale rail', await pg.locator('[data-testid^=doc-tab-]').count()>=4 and await pg.locator('[data-testid=doc-rail]').count()==1)
    th=await pg.eval_on_selector('[data-testid=doc-tab-scribe]','e=>e.getBoundingClientRect().height'); ok(f'{W} Doctor tabs taller (>=56px)', th>=56)
    ok(f'{W} one X-less Close next to Save & close', (await pg.inner_text('[data-testid=ws-close]')).strip()=='Close')
    await shot('50_doctor_scribe')
    await tid('doc-tab-forms'); await tid('addform-btn'); ok(f'{W} Doctor: Add form picker lists My Forms', await pg.locator('[data-testid=addform-picker] [data-testid^=addform-opt-]').count()>=3); await shot('55_doctor_addform_picker')
    await pg.locator('[data-testid=addform-picker] [data-testid=addform-add]').first.click(); await pg.wait_for_timeout(500)
    ok(f'{W} Doctor: form added as Incomplete', await pg.locator('[data-testid=addform-item]').count()>=1 and 'Incomplete' in await pg.inner_text('[data-testid=addform-item]'))
    await tid('addform-send'); ok(f'{W} Doctor: added form sent to portal (simulated)', 'portal' in await pg.inner_text('[data-testid=addform-item]')); await shot('56_doctor_added_form')
    for t in ['charts','photos','quote','plan']: await tid(f'doc-tab-{t}'); await shot(f'5{["charts","photos","quote","plan"].index(t)+1}_doctor_{t}')
    await tid('ws-close')
    # ---- Video visit (Priya Nair, today) ----
    await patient('Priya Nair'); ok(f'{W} video visit offers Start video visit', await pg.locator('[data-testid=flow-start-remote]').count()==1); await shot('60_video_flow')
    await tid('flow-start-remote'); ok(f'{W} Start video visit opens the Doctor workspace (Step 4)', await pg.locator('[data-testid=ws-doctor]').count()==1)
    await shot('61_video_started_doctor'); await tid('ws-save')
    # ---- v1.4 extras ----
    await patient('Tomas Exampleton'); await tid('flow-open-ws')
    ok(f'{W} #3 front desk Add form + #4 Upload documents', await pg.locator('[data-testid=ws-front] [data-testid=addform-btn]').count()==1 and await pg.locator('[data-testid=ws-upload-docs]').count()==1)
    ok(f'{W} composer visible over the slide-over (fits)', W<900 or await pg.locator('[data-testid=flow-composer]').is_visible())
    await pg.evaluate("()=>document.querySelector('.flp-b')?.scrollTo(0,0)"); await pg.wait_for_timeout(200); await shot('70_front_add_upload')
    await tid('ws-upload-docs'); await shot('71_upload_documents'); await pg.keyboard.press('Escape'); await pg.wait_for_timeout(300)
    if await pg.locator('.sv-modal').count(): await pg.locator('.sv-modal').get_by_role('button', name=re.compile('Cancel|Close')).first.click(); await pg.wait_for_timeout(300)
    await tid('addform-btn'); await shot('72_front_addform_picker'); await tid('addform-close'); ok(f'{W} Add form picker closes', await pg.locator('[data-testid=addform-picker]').count()==0)
    await pg.locator('[data-testid=ws-front-forms] input').first.type('x') if await pg.locator('[data-testid=ws-front-forms] input').count() else None
    await tid('ws-save')
    await tid('flow-dot-1'); ok(f'{W} #1 send-forms popup opens on demand', True)
    if not await pg.locator('[data-testid=forms-prompt]').count(): await tid('ws-send-forms')
    cb=await pg.eval_on_selector('[data-testid=forms-prompt] input[type=checkbox]','e=>{const r=e.getBoundingClientRect(),l=e.closest("label").getBoundingClientRect();return [r.width,Math.abs((r.top+r.height/2)-(l.top+l.height/2))]}')
    ok(f'{W} #1 checkboxes normal size + inline with label', cb[0]<=20 and cb[1]<=4); await shot('73_send_forms_popup')
    await tid('fp-skip'); ok(f'{W} #1 Not now closes', await pg.locator('[data-testid=forms-prompt]').count()==0)
    await tid('ws-send-forms'); await pg.locator('[data-testid=forms-prompt] [aria-label=Close]').click(); await pg.wait_for_timeout(300); ok(f'{W} #1 X closes', await pg.locator('[data-testid=forms-prompt]').count()==0)
    await tid('ws-send-forms'); await tid('fp-send'); await shot('74_forms_queued'); await tid('fp-open-chart'); ok(f'{W} #1 Forms queued Done closes', await pg.locator('[data-testid=forms-prompt]').count()==0)
    await tid('ws-close')
    await tid('flow-timeline'); ok(f'{W} #6 Timeline is the 7-step list (no v1.2 journey page)', await pg.locator('[data-testid^=flow-tl-step-]').count()==7 and await pg.locator('[data-testid=flow-timeline-panel] .jy').count()==0); await shot('75_flow_timeline')
    # schedule week
    await nav('sv-nav-schedule'); await tid('view-week'); await tid('sched-cols'); await shot('80_sched_cols_picker')
    ok(f'{W} #12 columns picker has X', await pg.locator('[data-testid=sched-cols-close]').count()==1)
    await pg.mouse.click(5, H-5); await pg.wait_for_timeout(300); ok(f'{W} #12 picker closes on outside click', await pg.locator('[data-testid=sched-cols-pop]').count()==0)
    ok(f'{W} #12 week sub-column headers show provider names', await pg.locator('[data-testid=sched-subcol]').count()>=7)
    await pg.fill('[data-testid=sched-week-notes-text]','Dr. Whitfield out Friday afternoon (fictional).'); await tid('sched-week-notes-save')
    ok(f'{W} #12 week notes saved', 'Last saved' in await pg.inner_text('[data-testid=sched-week-notes]'))
    await pg.evaluate('()=>window.scrollTo(0,0)'); await pg.evaluate("()=>document.querySelectorAll('*').forEach(e=>{if(e.scrollTop>0)e.scrollTop=0})"); await pg.wait_for_timeout(300); await shot('81_sched_week'); await pg.locator('[data-testid=sched-week-notes]').scroll_into_view_if_needed(); await shot('82_sched_week_notes')
    await tid('sched-next'); ok(f'{W} #12 notes are per week', (await pg.input_value('[data-testid=sched-week-notes-text]'))=='')
    await tid('view-day')
    # billing (front desk / admins / doctors): act as the surgeon
    opts=await pg.eval_on_selector('[data-testid=acting-as]','e=>[...e.options].map(o=>o.value)'); dv=[o for o in opts if 'Whitfield' in o]
    if dv: await pg.select_option('[data-testid=acting-as]', value=dv[0]); await pg.wait_for_timeout(400)
    await nav('sv-nav-billing'); ok(f'{W} #7 Billing redesigned, no Back to Administration', await pg.locator('[data-testid=billing-kpis]').count()==1 and 'Back to Administration' not in await pg.inner_text('body'))
    await shot('90_billing'); await tid('billing-tab-payments'); await shot('91_billing_payments')
    # Practice settings (PIN 1234): billing settings, profile email, compliance, My Forms
    await nav('sv-nav-forms'); await pg.wait_for_timeout(500)
    if await pg.locator('[data-testid=pin-input]').count()==0 and await pg.locator('[data-testid=practice-unlock]').count(): await tid('practice-unlock')
    if await pg.locator('[data-testid=pin-input]').count():
      if await pg.locator('[data-testid=pin-who]').count(): await pg.select_option('[data-testid=pin-who]', index=1)
      await pg.fill('[data-testid=pin-input]','1234'); await pg.click('[data-testid=pin-confirm]'); await pg.wait_for_timeout(600)
    await shot('92_practice_home')
    if await pg.locator('[data-testid=prac-billing-settings]').count():
      await tid('prac-billing-settings'); ok(f'{W} #7 Billing settings page (config + fee schedule)', await pg.locator('[data-testid=billing-config]').count()==1 and await pg.locator('[data-testid=med-fee-schedule]').count()==1); await shot('93_billing_settings')
      await nav('sv-nav-forms'); await pg.wait_for_timeout(400)
      await tid('prac-profile'); ok(f'{W} #11 profile Email field', await pg.locator('[data-testid=profile-email]').count()==1); await shot('94_profile_email')
      await nav('sv-nav-forms'); await pg.wait_for_timeout(400)
      await tid('prac-documents'); ok(f'{W} #9 compliance: no Administration Home link', 'Administration Home' not in await pg.inner_text('#sv-main')); await shot('95_compliance')
      await nav('sv-nav-forms'); await pg.wait_for_timeout(400)
      await tid('prac-forms'); await pg.wait_for_timeout(600); ok(f'{W} #10 My Forms warm header', (await pg.eval_on_selector('[data-testid=surgery-forms-workspace] .vds-page-header','e=>getComputedStyle(e).backgroundColor'))=='rgb(255, 255, 255)'); await shot('96_my_forms')
    else: ok(f'{W} practice unlocked', False)
    ok(f'{W} no page errors', not errs); print(errs[:3])
    await b.close()
async def main():
  for W,H in ([(1440,900),(1180,820),(820,1180)] if len(sys.argv)<2 else [tuple(map(int,sys.argv[1].split('x')))]):
    try: await run(W,H)
    except Exception as e: ok(f'{W} walk completed ({str(e)[:120]})', False)
  print('TOTAL', sum(r[1] for r in R), '/', len(R))
asyncio.run(main())
