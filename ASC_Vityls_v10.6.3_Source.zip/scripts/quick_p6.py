import asyncio
from playwright.async_api import async_playwright
URL='file:///workspace/vityls/src_v6/vityls_final_build/release/Surgery_Vityls_v1.2/index.html'
OUT='/workspace/vityls/report/surgery_v1.2_screens'
async def openp(pg,name):
    nv=pg.locator('[data-testid=sv-nav-patients]')
    if not await nv.is_visible(): await pg.click('[data-testid=fd-hamburger]')
    await nv.click(); await pg.wait_for_timeout(500)
    await pg.locator('[data-testid=sv-patient-list] tbody tr', has_text=name).first.locator('button').first.click(); await pg.wait_for_timeout(800)
async def main():
  async with async_playwright() as p:
    b=await p.chromium.launch(executable_path='/usr/bin/google-chrome'); pg=await b.new_page(viewport={'width':1440,'height':1000}); errs=[]
    pg.on('pageerror',lambda e:errs.append(str(e)))
    await pg.goto(URL+'?reset-test-data'); await pg.wait_for_timeout(2500)
    await openp(pg,'Marcus Hale'); print('marcus step', await pg.get_attribute('[data-testid=journey-page]','data-step'))
    it=pg.locator('[data-testid=jy-item-s10-redflag] button.pri')
    if await it.count():
      await it.first.click(); await pg.wait_for_timeout(300)
      for b2 in await pg.locator('[data-testid^=rf-]').all(): await b2.locator('button',has_text='No').click()
      await pg.screenshot(path=f'{OUT}/1440_step10_redflag.png'); await pg.click('[data-testid=jy-redflag-save]'); await pg.wait_for_timeout(500)
    print('redflag item gone', await pg.locator('[data-testid=jy-item-s10-redflag]').count()==0)
    t=pg.locator('[data-testid=jy-item-s10-track] button.pri')
    if await t.count():
      await t.first.click(); await pg.wait_for_timeout(300); print('tracked', await pg.locator('[data-testid=jy-tracked]').count())
      await pg.screenshot(path=f'{OUT}/1440_step10_tracker.png')
      while await pg.locator('[data-testid=jy-track-close]').count():
        await pg.locator('[data-testid=jy-track-close]').first.click(); await pg.wait_for_timeout(400)
        if await pg.locator('[data-testid=jy-tracker]').count()==0 and await t.count(): await t.first.click(); await pg.wait_for_timeout(300)
      if await pg.locator('[data-testid=jy-tracker]').count(): await pg.keyboard.press('Escape'); await pg.locator('[data-testid=jy-tracker] .btn',has_text='Cancel').click()
    print('track item gone', await pg.locator('[data-testid=jy-item-s10-track]').count()==0)
    await openp(pg,'Carol Bennett')
    r=pg.locator('[data-testid=jy-item-s11-interval] button.pri')
    if await r.count():
      await r.first.click(); await pg.wait_for_timeout(300); await pg.screenshot(path=f'{OUT}/1440_step11_reconcile.png'); await pg.click('[data-testid=jy-reconcile-save]'); await pg.wait_for_timeout(400)
    print('errors', errs[:3]); await b.close()
asyncio.run(main())
