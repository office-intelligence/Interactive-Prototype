set -e
cd "$(dirname "$0")/.."
VITE_EDITION=ASC2 VITE_CORE_ASC=1 npx vite build --outDir dist-asc10 >/tmp/asc10build.log 2>&1 || { tail -30 /tmp/asc10build.log; exit 1; }
DIST=dist-asc10 OUT=ASC_Vityls_v10.5 node scripts/package-surgery.mjs
sed -i 's#<title>[^<]*</title>#<title>ASC.Vityls v10.5</title>#' release/ASC_Vityls_v10.5/index.html
