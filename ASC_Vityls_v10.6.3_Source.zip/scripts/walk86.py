"""ASC.Vityls v8.6 walkthrough (Playwright + Chrome). Usage: python3 scripts/walk82.py [URL] [WIDTH...]. Fictional data; test PIN 1234."""
import asyncio, sys, os
from playwright.async_api import async_playwright
URL = sys.argv[1] if len(sys.argv) > 1 else 'http://localhost:8797/'
WIDTHS = [int(w) for w in sys.argv[2:]] or [1440, 1024, 390]
OUT = '/workspace/vityls/report/asc_v8.6.1_screens/best/'; os.makedirs(OUT, exist_ok=True)
CARD = '/tmp/fake_card.png'
res = []
def ok(name, cond, note=''): res.append((name, bool(cond), note)); print(('PASS' if cond else 'FAIL'), name, note, flush=True)
async def run(w):
    async with async_playwright() as p:
        b = await p.chromium.launch(executable_path='/usr/bin/google-chrome'); pg = await b.new_page(viewport={'width': w, 'height': 900 if w > 500 else 844}); pg.set_default_timeout(8000)
        errs = []; pg.on('pageerror', lambda e: errs.append(str(e))); pg.on('dialog', lambda d: asyncio.ensure_future(d.accept()))
        await pg.goto(URL + '?reset-test-data'); await pg.wait_for_timeout(2500)
        T = f'{w}:'
        async def shot(n):
            await pg.evaluate("()=>document.querySelectorAll('.a81-dbody,.a8-body').forEach(e=>e.scrollTop=0)"); await pg.screenshot(path=f'{OUT}{w}_{n}.png', full_page=True)
        async def noscroll(where):
            sw = await pg.evaluate('()=>document.documentElement.scrollWidth - window.innerWidth'); ok(T+f'no sideways scroll · {where}', sw <= 1, f'+{sw}px')
        async def role(label):
            s = pg.locator('select').first; opts = await s.evaluate("s=>[...s.options].map(o=>o.text)"); await s.select_option(label=[o for o in opts if label in o][0]); await pg.wait_for_timeout(600)
        async def nav(tid):
            await pg.locator(f'[data-testid={tid}]').first.evaluate('e=>e.click()'); await pg.wait_for_timeout(700)
        async def draw(sel):
            c = pg.locator(sel).first; await c.scroll_into_view_if_needed(); bb = await c.bounding_box()
            x, y = bb['x'] + 20, bb['y'] + bb['height'] / 2
            await pg.mouse.move(x, y); await pg.mouse.down()
            for i in range(1, 12): await pg.mouse.move(x + i * 14, y + (12 if i % 2 else -12))
            await pg.mouse.up(); await pg.wait_for_timeout(150)
        async def sign(who=None):
            await pg.wait_for_selector('[data-testid=pin-sign]')
            if who:
                opts = await pg.eval_on_selector('[data-testid=pin-who]', "s=>[...s.options].map(o=>o.text)"); await pg.select_option('[data-testid=pin-who]', label=[o for o in opts if who in o][0])
            else:
                v = await pg.eval_on_selector('[data-testid=pin-who]', 'e=>e.value')
                if not v: await pg.select_option('[data-testid=pin-who]', index=1)
            await draw('[data-testid=pin-sigpad-canvas]')
            await pg.fill('[data-testid=pin-input]', '1234'); await pg.click('[data-testid=pin-confirm]'); await pg.wait_for_timeout(500)
        async def bench(chip, patient=None):
            if await pg.locator('[data-testid=a81-close]').count(): await pg.click('[data-testid=a81-close]')
            await nav('sv-nav-home'); a = pg.locator('[data-testid=a81-chip-all]')
            if await pg.locator(f'[data-testid=a81-chip-{chip}]').count() == 0 and await a.count(): await a.click()
            await pg.click(f'[data-testid=a81-chip-{chip}]'); await pg.wait_for_selector(f'[data-testid=a81-bench-{chip}]')
            if patient:
                opts = await pg.eval_on_selector('[data-testid=a81-case-pick]', "s=>[...s.options].map(o=>o.text)"); await pg.select_option('[data-testid=a81-case-pick]', label=[o for o in opts if patient in o][0]); await pg.wait_for_timeout(300)
        async def fillsel(tid):
            v = await pg.eval_on_selector(f'[data-testid={tid}]', 'e=>e.value')
            if not v: await pg.select_option(f'[data-testid={tid}]', index=1)
        async def close_forms():
            for _ in range(3):
                x = pg.locator('.a82-form [aria-label="Close form"]')
                if await pg.locator('.a82-form').count() and await x.count(): await x.first.click(); await pg.wait_for_timeout(400)
        await pg.evaluate("()=>{window.print=()=>{window.__printed=(window.__printed||0)+1}}")
        LS = lambda: pg.evaluate("()=>JSON.stringify(Object.values(localStorage))")
        if w < 500:
            await role('Front Desk Tester'); await nav('sv-nav-home'); await pg.wait_for_timeout(500); await shot('09_today_phone'); await noscroll('today 390'); ok(T+'worklist on phone', await pg.locator('[data-testid=a86-worklist]').count()); await b.close(); return
        # 1 · Today: search + worklist; missing clearance shows as a warning (never a hold)
        await role('Front Desk Tester'); await nav('sv-nav-home')
        ok(T+'episode worklist on Today', await pg.locator('[data-testid=a86-wl-row]').count() >= 4)
        await pg.click('[data-testid=a86-worklist] h2'); wl = await pg.inner_text('[data-testid=a86-worklist]'); ok(T+'missing clearance = tinted warning with owner', 'Clearance missing' in wl and 'clearance received → Pre-op nursing' in wl and await pg.locator('[data-testid=a86-wl-warn]').count() >= 1, wl[:200])
        await pg.fill('[data-testid=a86-search-q]', 'ASC-2004'); await pg.wait_for_timeout(300); ok(T+'search by MRN', await pg.locator('[data-testid=a86-search-hit]').count() == 1)
        await pg.fill('[data-testid=a86-search-q]', 'Ada'); await shot('01_today_worklist_search'); await pg.fill('[data-testid=a86-search-q]', '')
        # 2 · duplicate prevention
        await nav('sv-nav-schedule'); await pg.wait_for_timeout(500); await pg.locator('[data-testid=add-visit]').first.click(); await pg.wait_for_selector('[data-testid=a83-booking]')
        await pg.fill('[data-testid=a83-book-name]', 'ada kerr'); await pg.keyboard.press('Escape') if False else None
        await pg.evaluate("()=>document.querySelector('[data-testid=a83-book-name]').blur()")
        dob = pg.locator('[data-testid=a83-booking] input[placeholder*="DOB"], [data-testid=a83-book-dob]')
        if await dob.count(): await dob.first.fill('03/14/1969')
        await pg.fill('[data-testid=a83-book-proc]', 'Excision of lipoma, back')
        for t in ['a83-book-surgeon', 'a83-book-anes', 'a83-book-pay']: await fillsel(t)
        await pg.click('[data-testid=a83-book-save]'); await pg.wait_for_timeout(500)
        ok(T+'duplicate patient detected', await pg.locator('[data-testid=a86-dup]').count() == 1, (await pg.inner_text('[data-testid=a83-book-err]')) if await pg.locator('[data-testid=a83-book-err]').count() else 'no err')
        await shot('02_duplicate_prevented')
        await pg.click('[data-testid=a83-book-save]'); await pg.wait_for_timeout(700); ok(T+'booked on the existing chart', await pg.locator('[data-testid=a83-booking]').count() == 0)
        s = await LS(); ok(T+'booking logged + reminders queued', 'Schedule booked' in s and 'Two-day reminder' in s and 'arrive at' in s)
        # 3 · reschedule (traceable) on an existing appointment
        await pg.locator('[data-testid=visit-block]', has_text='Owen').first.evaluate('e=>e.click()'); await pg.wait_for_timeout(700); ok(T+'appointment details open', await pg.locator('[data-testid=a83-booking]').count() == 1)
        d0 = await pg.input_value('[data-testid=a83-book-date]'); import datetime; d1 = (datetime.date.fromisoformat(d0) + datetime.timedelta(days=7)).isoformat()
        await pg.fill('[data-testid=a83-book-date]', d1)
        for t in ['a83-book-anes', 'a83-book-pay']: await fillsel(t)
        await shot('02b_appointment_history') if False else None; await pg.click('[data-testid=a83-book-save]'); await pg.wait_for_timeout(600)
        s = await LS(); ok(T+'reschedule logged with notices', 'Schedule rescheduled' in s and f'date {d0} → {d1}' in s)
        # 4 · cancel (traceable)
        await nav('sv-nav-home'); rows = pg.locator('[data-testid=a8-station-row]')
        for i in range(await rows.count()):
            await rows.nth(i).click(); await pg.wait_for_timeout(300)
            if await pg.locator('[data-testid=a83-case-details]').count(): break
            if await pg.locator('[data-testid=a8-close]').count(): await pg.click('[data-testid=a8-close]')
        if await pg.locator('[data-testid=a83-case-details]').count():
            await pg.click('[data-testid=a83-cancel-open]'); await pg.select_option('[data-testid=a83-cancel-reason]', index=2); await pg.click('[data-testid=a83-cancel-confirm]'); await pg.wait_for_timeout(500)
        s = await LS(); ok(T+'cancel logged; reminders cancelled', 'Schedule cancelled' in s)
        # 5 · orders: Nightingale draft → surgeon signs → changed (unsigned) → nurse sees v1 only → sign v2
        await role('Sam Patel'); await bench('orders', 'Desmond')
        await pg.click('[data-testid=a86-ord-propose]'); await pg.wait_for_timeout(300)
        ok(T+'Nightingale proposal is a draft', await pg.locator('[data-testid=a86-phase-preop] [data-testid=a86-status][data-status=draft]').count() >= 1)
        ok(T+'template banner (awaiting approval)', 'awaiting clinical approval' in await pg.inner_text('[data-testid=a86-template-banner]'))
        await pg.fill('[data-testid=a86-ord-val-0]', '[clinician-entered example]'); await pg.click('[data-testid=a86-ord-sign-open]'); await sign('Patel')
        ok(T+'orders signed → active', await pg.locator('[data-testid=a86-phase-preop] > .a82-sh [data-status=active]').count() == 1)
        await pg.fill('[data-testid=a86-ord-val-2]', 'Hold metformin morning of surgery (example)'); await pg.wait_for_timeout(300)
        ok(T+'changed order = unsigned draft v2, v1 still active', await pg.locator('[data-testid=a86-pending-change]').count() == 1)
        await pg.click('[data-testid=a86-ord-history] summary'); await shot('03_orders_changed_unsigned')
        await pg.click('[data-testid=a81-close]')
        await role('Casey Morgan'); await bench('nursing', 'Desmond'); ct = await pg.inner_text('[data-testid=a86-active-orders]')
        ok(T+'nursing card: active v1 + pending-change warning', 'v1' in ct and 'waiting for signature' in ct, ct[:160])
        await pg.click('[data-testid=a86-ack]'); await pg.click('[data-testid=a86-exec] >> nth=0'); await pg.wait_for_timeout(300); ok(T+'nurse acknowledged + execution recorded', await pg.locator('[data-testid=a86-acked]').count() == 1)
        await pg.locator('[data-testid=a86-active-orders]').scroll_into_view_if_needed(); await pg.screenshot(path=f'{OUT}{w}_04_nursing_active_orders.png'); await pg.click('[data-testid=a81-close]')
        await role('Sam Patel'); await bench('orders', 'Desmond'); await pg.click('[data-testid=a86-ord-sign-open]'); await sign('Patel'); await pg.click('[data-testid=a86-ord-history] summary')
        hs = await pg.locator('[data-testid=a86-ver] [data-testid=a86-status]').evaluate_all("es=>es.map(e=>e.dataset.status)"); ok(T+'v2 signed, v1 superseded', hs[:2] == ['active', 'superseded'], str(hs)); await pg.click('[data-testid=a81-close]')
        # 6 · PACU flowsheet: overdue reminder, late entry, correction, trend next to active orders
        await role('Alex Rivera'); await bench('pacu', 'Maren'); await pg.wait_for_timeout(600); await close_forms()
        ok(T+'active PACU orders card', await pg.locator('[data-testid=a86-ocard][data-phase=pacu]').count() == 1); ok(T+'overdue observations flagged (not auto-completed)', await pg.locator('[data-testid=a86-overdue]').count() == 1)
        late = (datetime.datetime.now() - datetime.timedelta(minutes=25)).strftime('%H:%M')
        await pg.fill('[data-testid=a86-v-measured]', late); await pg.fill('[data-testid=a86-v-bp]', '122/74'); await pg.fill('[data-testid=a86-v-hr]', '78'); await pg.fill('[data-testid=a86-v-spo2]', '98'); await pg.fill('[data-testid=a86-v-pain]', '2'); await pg.click('[data-testid=a86-v-save]'); await pg.wait_for_timeout(300)
        ok(T+'late entry flagged', await pg.locator('[data-testid=a86-vrow][data-late="1"]').count() >= 1)
        ok(T+'no copy-forward (inputs blank)', (await pg.input_value('[data-testid=a86-v-hr]')) == '')
        await pg.locator('[data-testid=a86-fix]').first.click(); await pg.fill('[data-testid=a86-v-hr]', '86'); await pg.fill('[data-testid=a86-v-why]', 'transcription error'); await pg.click('[data-testid=a86-v-save]'); await pg.wait_for_timeout(300)
        ok(T+'correction keeps original (struck)', await pg.locator('tr.a86-struck').count() == 1); ok(T+'trend sparklines', await pg.locator('[data-testid=a86-spark] svg').count() >= 2)
        await pg.locator('[data-testid=a86-active-orders]').scroll_into_view_if_needed(); await pg.screenshot(path=f'{OUT}{w}_05_pacu_flowsheet.png'); await pg.click('[data-testid=a81-close]')
        # 7 · discharge confirmations
        await bench('discharge', 'Maren'); await pg.check('[data-testid=a86-dc-criteria]'); await pg.click('[data-testid=a86-dc-auth-open]'); await sign('Haddad')
        await pg.select_option('[data-testid=a86-dc-und]', 'Patient and caregiver'); await pg.select_option('[data-testid=a86-dc-copy]', index=1); await pg.select_option('[data-testid=a86-dc-transport]', index=1); await pg.wait_for_timeout(300)
        ok(T+'discharge authorization signed', await pg.locator('[data-testid=a86-dc-auth-ok]').count() == 1); await pg.locator('[data-testid=a86-dc-extras]').scroll_into_view_if_needed(); await pg.screenshot(path=f'{OUT}{w}_06_discharge_confirmations.png')
        await pg.click('[data-testid=a82-dc-finish]'); await pg.wait_for_timeout(600)
        # 8 · after surgery: op report receipt, follow-up call, survey; post-op amendment by surgeon
        await role('Practice Administrator'); await bench('after', 'Ada'); await pg.click('[data-testid=a86-op-receive]')
        await pg.select_option('[data-testid=a86-fu-outcome]', 'no answer'); await pg.click('[data-testid=a86-fu-log]'); await pg.select_option('[data-testid=a86-fu-outcome]', 'reached'); await pg.fill('[data-testid=a86-fu-note]', 'Doing well, pain controlled'); await pg.click('[data-testid=a86-fu-log]'); await pg.click('[data-testid=a86-fu-done]'); await pg.click('[data-testid=a86-survey-send]'); await pg.wait_for_timeout(300)
        ok(T+'follow-up attempts logged', await pg.locator('[data-testid=a86-fu-attempt]').count() == 2); await pg.click('[data-testid=a81-close]')
        # 9 · closure: Nightingale checklist (AI unavailable → manual), close with open items (logged), reopen, amend
        await bench('closure', 'Ada'); await pg.check('[data-testid=a86-ai-down]'); ok(T+'owner-specific to-do', await pg.locator('[data-testid=a86-owner-todo]').count() >= 1)
        await pg.click('[data-testid=a86-review]'); ok(T+'financial status separate', 'Financial' in await pg.inner_text('[data-testid=a86-fin-status]'))
        await shot('07_closure_checklist'); await pg.click('[data-testid=a86-close]'); await pg.wait_for_timeout(300); ok(T+'close never blocked', 'Closed' in await pg.inner_text('[data-testid=a86-episode-status]'))
        s = await LS(); ok(T+'open items logged with closure', 'Episode closed with' in s)
        await pg.fill('[data-testid=a86-reopen-why]', 'Post-op addendum to op report'); await pg.click('[data-testid=a86-reopen]'); await pg.wait_for_timeout(300); ok(T+'reopened for amendment', await pg.locator('[data-testid=a86-reopen-log]').count() == 1); await pg.click('[data-testid=a81-close]')
        await role('Sam Patel'); await bench('after', 'Ada'); await pg.fill('[data-testid=a86-op-amend-text]', 'Addendum: drain removed in PACU (fictional).'); await pg.click('[data-testid=a86-op-amend-open]'); await sign('Patel')
        ok(T+'post-op amendment signed, original kept', await pg.locator('[data-testid=a86-op-amend-row]').count() == 1); await pg.click('[data-testid=a81-close]')
        # 10 · print packet: header on every page, supplemental sections, logged
        await role('Practice Administrator'); await nav('sv-nav-patients'); await pg.wait_for_timeout(500)
        await pg.evaluate("()=>{const b=[...document.querySelectorAll('button,a,tr,[role=button]')].find(e=>/Ada Kerr/.test(e.textContent||'')&&e.offsetParent);b&&b.click()}"); await pg.wait_for_timeout(800)
        await pg.click('[data-testid=a83-chart-tab-documents]'); await pg.select_option('[data-testid=a83-doc-dos]', index=1); await pg.click('[data-testid=a83-doc-print]'); await pg.wait_for_selector('[data-testid=a86-print]')
        np = await pg.locator('[data-testid=a86-page]').count(); nh = await pg.locator('[data-testid=a86-phead]').count(); ht = await pg.inner_text('[data-testid=a86-phead] >> nth=0')
        ok(T+'patient header on every page (name, MRN, DOB, DOS, title, page n of N)', np >= 3 and nh == np and all(k in ht for k in ['Ada Kerr', 'MRN', 'DOB', 'DOS', 'Page 1 of']), ht)
        ok(T+'supplemental sections for steps outside forms', 'Supplemental' in await pg.inner_text('[data-testid=a86-print]'))
        await shot('08_print_packet'); await pg.click('[data-testid=a86-print-go]'); s = await LS(); ok(T+'print logged in audit', 'Printed: Episode packet' in s); await pg.click('[data-testid=a86-print-close]')
        await pg.click('[data-testid=a83-doc-export]'); s = await LS(); ok(T+'export logged in audit', 'Exported:' in s)
        # 11 · admin metrics; anesthesia bench unchanged
        await nav('sv-nav-home'); await pg.wait_for_timeout(400); ok(T+'admin efficiency metrics', await pg.locator('[data-testid=a86-metric]').count() == 6)
        await pg.locator('[data-testid=a86-metrics]').scroll_into_view_if_needed(); await pg.screenshot(path=f'{OUT}{w}_10_admin_metrics.png')
        await role('Noor Haddad'); await bench('anesthesia', 'Desmond'); ok(T+'anesthesia workbench unchanged', await pg.locator('[data-testid=a82-medsummary]').count() and await pg.locator('[data-testid=a86-active-orders]').count() == 0); ok(T+'free-text PACU orders box removed', await pg.locator('[data-testid=a81-orders]').count() == 0 and await pg.locator('[data-testid=a82-anescon-form], [data-testid=a82-anescon-signed]').count() >= 1 and await pg.locator('[data-testid=a82-preinduction]').count() == 1); await pg.locator('[data-testid=a82-preinduction]').scroll_into_view_if_needed(); await pg.screenshot(path=f'{OUT}{w}_11_anesthesia_bench.png'); await pg.click('[data-testid=a81-close]')
        ok(T+'no page errors', not errs, '; '.join(errs)[:300]); await b.close()
async def main():
    for w in WIDTHS:
        try: await run(w)
        except Exception as e: ok(f'{w}: walk aborted', False, str(e)[:400])
    f = sum(1 for r in res if not r[1]); print(f'TOTAL {len(res)-f}/{len(res)} passed'); sys.exit(1 if f else 0)
asyncio.run(main())
