// core-modules v1.0: builds release/Vityls_Core_Modules_v1.0/ from dist-core (VITE_CORE=1 VITE_EDITION=SURGERY): one app, practice switcher + Vityls admin console.
// by double-click from file://, plus the static files a few legacy screens still load (PDF templates, images).
// Usage: VITE_CORE=1 VITE_EDITION=SURGERY npx vite build --outDir dist-core && node scripts/package-medical.mjs
import fs from 'fs'; import path from 'path';
const root = path.resolve(path.dirname(new URL(import.meta.url).pathname), '..');
const dist = path.join(root, process.env.DIST || 'dist-core'); const out = path.join(root, 'release', process.env.OUT || 'Vityls_Core_Modules_v1.0');
fs.rmSync(out, { recursive: true, force: true }); fs.mkdirSync(out, { recursive: true });
let html = fs.readFileSync(path.join(dist, 'index.html'), 'utf8');
const js = html.match(/<script type="module" crossorigin src="\.\/(assets\/[^"]+\.js)"><\/script>/);
const css = html.match(/<link rel="stylesheet" crossorigin href="\.\/(assets\/[^"]+\.css)">/);
if (!js || !css) throw new Error('could not find bundle tags in dist/index.html');
const jsText = fs.readFileSync(path.join(dist, js[1]), 'utf8').replace(/<\/script/gi, '<\\/script').replace(/<!--/g, '<\\!--');
const cssText = fs.readFileSync(path.join(dist, css[1]), 'utf8').replace(/<\/style/gi, '<\\/style');
html = html.replace(js[0], '').replace(css[0], () => `<style>${cssText}</style>`)
  .replace('</body>', () => `<script type="module">${jsText}</script>\n</body>`);
if (!process.env.DIST || process.env.DIST === 'dist-core') html = html.replace(/<title>[^<]*<\/title>/, '<title>Vityls Core Modules v1.0 — test build (fictional data)</title>');
if (process.env.TITLE) html = html.replace(/<title>[^<]*<\/title>/, () => `<title>${process.env.TITLE}</title>`);
fs.writeFileSync(path.join(out, 'index.html'), html);
const copy = (rel) => { const s = path.join(dist, rel); if (fs.existsSync(s)) fs.cpSync(s, path.join(out, rel), { recursive: true }); };
['forms', 'concepts', 'pdf-templates', 'bjgback.jpg', 'hero-ai-bg.jpg'].forEach(copy);
fs.readdirSync(path.join(dist, 'assets')).filter(f => f.startsWith('pdf.worker')).forEach(f => copy(path.join('assets', f)));
console.log('wrote', out, (fs.statSync(path.join(out, 'index.html')).size / 1e6).toFixed(1) + ' MB index.html');
