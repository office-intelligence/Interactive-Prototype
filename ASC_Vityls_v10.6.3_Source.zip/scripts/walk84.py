"""ASC.Vityls v8.4 walkthrough (Playwright + Chrome). Usage: python3 scripts/walk82.py [URL] [WIDTH...]. Fictional data; test PIN 1234."""
import asyncio, sys, os
from playwright.async_api import async_playwright
URL = sys.argv[1] if len(sys.argv) > 1 else 'http://localhost:8785/'
WIDTHS = [int(w) for w in sys.argv[2:]] or [1440, 1024, 390]
OUT = '/workspace/vityls/report/asc_v8.4_screens/'; os.makedirs(OUT, exist_ok=True)
CARD = '/tmp/fake_card.png'
res = []
def ok(name, cond, note=''): res.append((name, bool(cond), note)); print(('PASS' if cond else 'FAIL'), name, note, flush=True)
async def run(w):
    async with async_playwright() as p:
        b = await p.chromium.launch(executable_path='/usr/bin/google-chrome'); pg = await b.new_page(viewport={'width': w, 'height': 900 if w > 500 else 844}); pg.set_default_timeout(8000)
        errs = []; pg.on('pageerror', lambda e: errs.append(str(e))); pg.on('dialog', lambda d: asyncio.ensure_future(d.accept()))
        await pg.goto(URL + '?reset-test-data'); await pg.wait_for_timeout(2500)
        T = f'{w}:'
        async def shot(n):
            await pg.evaluate("()=>document.querySelectorAll('.a81-dbody,.a8-body').forEach(e=>e.scrollTop=0)"); await pg.screenshot(path=f'{OUT}{w}_{n}.png', full_page=True)
        async def noscroll(where):
            sw = await pg.evaluate('()=>document.documentElement.scrollWidth - window.innerWidth'); ok(T+f'no sideways scroll · {where}', sw <= 1, f'+{sw}px')
        async def role(label):
            s = pg.locator('select').first; opts = await s.evaluate("s=>[...s.options].map(o=>o.text)"); await s.select_option(label=[o for o in opts if label in o][0]); await pg.wait_for_timeout(600)
        async def nav(tid):
            await pg.locator(f'[data-testid={tid}]').first.evaluate('e=>e.click()'); await pg.wait_for_timeout(700)
        async def draw(sel):
            c = pg.locator(sel).first; await c.scroll_into_view_if_needed(); bb = await c.bounding_box()
            x, y = bb['x'] + 20, bb['y'] + bb['height'] / 2
            await pg.mouse.move(x, y); await pg.mouse.down()
            for i in range(1, 12): await pg.mouse.move(x + i * 14, y + (12 if i % 2 else -12))
            await pg.mouse.up(); await pg.wait_for_timeout(150)
        async def sign(who=None):
            await pg.wait_for_selector('[data-testid=pin-sign]')
            if who:
                opts = await pg.eval_on_selector('[data-testid=pin-who]', "s=>[...s.options].map(o=>o.text)"); await pg.select_option('[data-testid=pin-who]', label=[o for o in opts if who in o][0])
            else:
                v = await pg.eval_on_selector('[data-testid=pin-who]', 'e=>e.value')
                if not v: await pg.select_option('[data-testid=pin-who]', index=1)
            await draw('[data-testid=pin-sigpad-canvas]')
            await pg.fill('[data-testid=pin-input]', '1234'); await pg.click('[data-testid=pin-confirm]'); await pg.wait_for_timeout(500)
        async def bench(chip, patient=None):
            if await pg.locator('[data-testid=a81-close]').count(): await pg.click('[data-testid=a81-close]')
            await nav('sv-nav-home'); a = pg.locator('[data-testid=a81-chip-all]')
            if await pg.locator(f'[data-testid=a81-chip-{chip}]').count() == 0 and await a.count(): await a.click()
            await pg.click(f'[data-testid=a81-chip-{chip}]'); await pg.wait_for_selector(f'[data-testid=a81-bench-{chip}]')
            if patient:
                opts = await pg.eval_on_selector('[data-testid=a81-case-pick]', "s=>[...s.options].map(o=>o.text)"); await pg.select_option('[data-testid=a81-case-pick]', label=[o for o in opts if patient in o][0]); await pg.wait_for_timeout(300)
        async def fillsel(tid):
            v = await pg.eval_on_selector(f'[data-testid={tid}]', 'e=>e.value')
            if not v: await pg.select_option(f'[data-testid={tid}]', index=1)
        async def close_forms():
            for _ in range(3):
                x = pg.locator('.a82-form [aria-label="Close form"]')
                if await pg.locator('.a82-form').count() and await x.count(): await x.first.click(); await pg.wait_for_timeout(400)
        # ---- Today (front desk): white page, collect-before-surgery card
        await role('Front Desk Tester'); await nav('sv-nav-home')
        bg = await pg.evaluate("()=>{let e=document.querySelector('.a8-today');const out=[];while(e){out.push(getComputedStyle(e).backgroundColor);e=e.parentElement}return out}")
        ok(T+'Today page has no gray background', all(c in ('rgb(255, 255, 255)', 'rgba(0, 0, 0, 0)') for c in bg), str(bg[:4]))
        ok(T+'collect card flags 7–14 day unpaid/partial', await pg.locator('[data-testid=a83-collect-row]').count() >= 2); ok(T+'collect card tinted', (await pg.eval_on_selector('[data-testid=a83-collect-card]', 'e=>getComputedStyle(e).backgroundColor')) != 'rgb(255, 255, 255)'); ok(T+'collect badge', (await pg.inner_text('[data-testid=a83-collect-badge]')).strip() in ('2', '3'))
        await shot('01_today_front'); await noscroll('today')
        await pg.locator('[data-testid=a83-collect-open]').first.click(); await pg.fill('[data-testid=a83-pay-amt]', '200'); await pg.click('[data-testid=a83-pay-collect]'); await pg.wait_for_timeout(400)
        ok(T+'pre-service payment collected', await pg.locator('[data-testid=a83-paid]').count() or 'Partial' in await pg.inner_text('[data-testid=a83-collect-card]'))
        # ---- intake → booking popup prefilled
        await bench('intake'); items = pg.locator('[data-testid=a81-intake-item]')
        for i in range(await items.count()):
            if 'returning' in await items.nth(i).inner_text(): await items.nth(i).click(); break
        await pg.click('[data-testid=a81-intake-confirm]'); await pg.wait_for_selector('[data-testid=a83-booking]')
        bt = await pg.inner_text('[data-testid=a83-booking]'); ok(T+'Confirm & create opens the booking popup prefilled', 'Desmond Akers' in bt or 'Desmond' in await pg.eval_on_selector('[data-testid=a83-booking]', "e=>[...e.querySelectorAll('input')].map(i=>i.value).join(' ')"))
        for t in ['a83-book-surgeon', 'a83-book-anes', 'a83-book-pay', 'a83-book-room']: await fillsel(t)
        if not await pg.input_value('[data-testid=a83-book-proc]'): await pg.fill('[data-testid=a83-book-proc]', 'Knee arthroscopy')
        await shot('02_booking_popup'); await noscroll('booking popup')
        await pg.click('[data-testid=a83-book-save]'); await pg.wait_for_timeout(800); ok(T+'case booked from popup', await pg.locator('[data-testid=a83-booking]').count() == 0, (await pg.inner_text('[data-testid=a83-book-err]')) if await pg.locator('[data-testid=a83-book-err]').count() else '')
        if await pg.locator('[data-testid=a83-booking]').count(): await pg.keyboard.press('Escape')
        # ---- scheduler: Add appointment = surgical booking popup, block time, surgeon colors
        await nav('sv-nav-schedule'); await pg.wait_for_timeout(500)
        ok(T+'surgeon color strip removed, case-type legend shown', await pg.locator('[data-testid=a83-surgeon-legend]').count() == 0 and await pg.locator('[data-testid=sched-legend]').is_visible()); ok(T+'cases colored by surgeon', await pg.locator('[data-testid=visit-block][data-surgeon-color]').count() >= 1)
        await shot('03_schedule_colors'); await noscroll('schedule')
        await pg.locator('[data-testid=add-visit]').first.click(); await pg.wait_for_selector('[data-testid=a83-booking]'); bt = await pg.inner_text('[data-testid=a83-booking]'); ok(T+'v7.7 Add new appointment popup', 'Add new appointment' in bt and 'matches appear after 3 letters' in bt and await pg.locator('[data-testid=a84-billing-chip]').count() and await pg.locator('[data-testid=a84-book-anesthesiologist]').count())
        await pg.fill('[data-testid=a83-book-name]', 'Pr'); await pg.wait_for_timeout(200); ok(T+'no matches before 3 letters', await pg.locator('[data-testid=a83-book-hit]').count() == 0)
        await pg.fill('[data-testid=a83-book-name]', 'Priya'); await pg.wait_for_timeout(300); ok(T+'patient search', await pg.locator('[data-testid=a83-book-hit]').count() >= 1)
        await pg.locator('[data-testid=a83-book-hit]').first.click(); await pg.fill('[data-testid=a83-book-proc]', 'Ganglion cyst excision')
        for t in ['a83-book-surgeon', 'a83-book-anes', 'a83-book-pay']: await fillsel(t)
        await pg.click('[data-testid=a83-book-save]'); await pg.wait_for_timeout(700); ok(T+'second case booked', await pg.locator('[data-testid=a83-booking]').count() == 0)
        await pg.locator('[data-testid=visit-block]').first.evaluate('e=>e.click()'); await pg.wait_for_timeout(500)
        if await pg.locator('[data-testid=a83-booking]').count():
            dt = await pg.inner_text('[data-testid=a83-booking]'); ok(T+'click case → Appointment details (Delete · Open chart · Save)', 'Appointment details' in dt and await pg.locator('[data-testid=a84-appt-delete]').count() and await pg.locator('[data-testid=a84-appt-chart]').count())
            ok(T+'billing chip', 'No invoice' in dt or 'due' in dt or 'Paid' in dt); await shot('03b_appointment_details'); await noscroll('appointment details')
            await pg.click('[data-testid=a83-book-save]'); await pg.wait_for_timeout(500); ok(T+'appointment details saved', await pg.locator('[data-testid=a83-booking]').count() == 0)
        else: ok(T+'click case → Appointment details', False)
        await pg.click('[data-testid=a81-block-time]'); await pg.wait_for_selector('[data-testid=a81-block-dialog]'); bt = await pg.text_content('[data-testid=a81-block-dialog]'); ok(T+'v7.7 block time popup (3 sections, day cards, total)', all(k in bt for k in ['Provider / Assignee', 'Operating Room & Time Window', 'Select Days of the Week to Block', 'Total blocks to generate']))
        await pg.select_option('[data-testid=a84-block-room]', index=0); await pg.click('[data-testid=a84-block-weekdays]'); ok(T+'all rooms × weekdays total', '40 block' in await pg.inner_text('[data-testid=a83-block-count]'), await pg.inner_text('[data-testid=a83-block-count]'))
        await pg.select_option('[data-testid=a84-block-room]', label='Procedure room'); await pg.click('[data-testid=a83-block-day-12]')
        await shot('04_block_time'); await pg.click('[data-testid=a81-block-save]'); await pg.wait_for_timeout(500); ok(T+'block saved', await pg.locator('[data-testid=a81-block-dialog]').count() == 0)
        # ---- Today: case details popup → check-in flow
        await nav('sv-nav-home'); rows = pg.locator('[data-testid=a8-station-row]'); cid = None
        for i in range(await rows.count()):
            await rows.nth(i).click(); await pg.wait_for_timeout(400)
            if await pg.locator('[data-testid=a83-case-details]').count(): break
            if await pg.locator('[data-testid=a8-close]').count(): await pg.click('[data-testid=a8-close]')
        ok(T+'clicking a scheduled patient opens Case details', await pg.locator('[data-testid=a83-case-details]').count())
        if await pg.locator('[data-testid=a83-case-details]').count():
            dt = await pg.inner_text('[data-testid=a83-case-details]'); ok(T+'details: age/gender/allergies/payment', all(k in dt for k in ['Allerg', 'Room', 'Surgeon', 'Payment']), dt[:120])
            await shot('05_case_details'); await noscroll('case details')
            await pg.click('[data-testid=a83-checkin-open]'); await pg.wait_for_selector('[data-testid=a83-checkin]')
            await pg.check('[data-testid=a83-ci-ident]')
            if await pg.locator('[data-testid=a82-up-idFront]').count(): await pg.set_input_files('[data-testid=a82-up-idFront]', CARD); await pg.set_input_files('[data-testid=a82-up-insFront]', CARD); await pg.wait_for_timeout(600)
            await pg.check('[data-testid=a83-ci-idok]')
            if not await pg.input_value('[data-testid=a83-ci-adult]'): await pg.fill('[data-testid=a83-ci-adult]', 'Jordan Akers')
            await pg.check('[data-testid=a83-ci-present]')
            if await pg.locator('[data-testid=a83-ci-open-forms]').count():
                await pg.click('[data-testid=a83-ci-open-forms]'); await pg.wait_for_timeout(800)
                fs = await pg.evaluate("()=>{const e=document.querySelector('.a82-form');if(!e)return 0;const r=e.getBoundingClientRect();return r.width>=innerWidth-2&&r.top<=1?1:0}"); ok(T+'form opens full screen', fs == 1); await shot('06_form_fullscreen'); await close_forms()
            for k in ['forms', 'financial', 'insurance']:
                if not await pg.is_checked(f'[data-testid=a83-ci-{k}]'): await pg.check(f'[data-testid=a83-ci-{k}]')
            if await pg.locator('[data-testid=a83-pay-amt]').count(): await pg.locator('[data-testid=a83-pay-collect]').evaluate('e=>e.click()'); await pg.wait_for_timeout(400)
            if await pg.locator('[data-testid=a83-ci-paylater]').count() and not await pg.is_enabled('[data-testid=a83-ci-go]'): await pg.check('[data-testid=a83-ci-paylater]')
            await pg.click('[data-testid=a83-ci-now]'); await shot('07_checkin_flow'); await noscroll('check-in')
            await pg.click('[data-testid=a83-ci-go]'); await pg.wait_for_timeout(500); ok(T+'checked in · handed to nursing', await pg.locator('[data-testid=a83-checked-in]').count()); await shot('08_checked_in')
            await pg.click('[data-testid=a83-ci-close]'); await pg.wait_for_timeout(400)
            await pg.click('[data-testid=a8-sw-all]') if await pg.locator('[data-testid=a8-sw-all]').count() else None
            ok(T+'board pill updated', 'Checked in' in await pg.inner_text('.a8-today'))
        # ---- cancel case with reason
        await nav('sv-nav-home'); rows = pg.locator('[data-testid=a8-station-row]'); n0 = await rows.count()
        for i in range(n0):
            await rows.nth(i).click(); await pg.wait_for_timeout(300)
            if await pg.locator('[data-testid=a83-case-details]').count(): break
            if await pg.locator('[data-testid=a8-close]').count(): await pg.click('[data-testid=a8-close]')
        if await pg.locator('[data-testid=a83-case-details]').count():
            await pg.click('[data-testid=a83-cancel-open]'); await pg.select_option('[data-testid=a83-cancel-reason]', index=1); await pg.click('[data-testid=a83-cancel-confirm]'); await pg.wait_for_timeout(500)
            ok(T+'cancel case with confirmation + reason', await pg.locator('[data-testid=a83-case-details]').count() == 0)
        # ---- billing unpaid cases
        await role('Practice Administrator'); await pg.locator('button:has(.fd-lbl:text-is("Billing"))').first.evaluate('e=>e.click()') if await pg.locator('button:has(.fd-lbl:text-is("Billing"))').count() else await nav('sv-nav-billing'); await pg.wait_for_timeout(600)
        if await pg.locator('[data-testid=billing-tab-unpaid]').count():
            await pg.click('[data-testid=billing-tab-unpaid]'); ok(T+'Billing unpaid cases', await pg.locator('[data-testid=a83-unpaid-row]').count() >= 1)
            await pg.fill('[data-testid=a83-unpaid-q]', 'Talia'); await pg.wait_for_timeout(200); rs = await pg.locator('[data-testid=a83-unpaid-row]').all_inner_texts(); ok(T+'unpaid search', len(rs) >= 1 and all('Talia' in r for r in rs), str(len(rs))); await shot('09_billing_unpaid'); await noscroll('billing')
        else: ok(T+'Billing unpaid cases tab', False, 'billing nav not found')
        # ---- nursing GLP-1 + facility
        await role('Casey Morgan'); await bench('nursing'); ok(T+'GLP-1 item', 'GLP-1' in await pg.inner_text('[data-testid=a81-bench-nursing]'))
        await pg.select_option('[data-testid=a83-nv-home-plan]', index=1); ok(T+'recovery facility field when not home', await pg.locator('[data-testid=a83-nv-home-facility]').count()); await pg.fill('[data-testid=a83-nv-home-facility]', 'Lakeside Recovery Suites (fictional)')
        await pg.select_option('[data-testid=a83-nv-home-plan]', index=0); ok(T+'facility hidden for home', await pg.locator('[data-testid=a83-nv-home-facility]').count() == 0)
        before = await pg.locator('[data-testid^=a81-ver-]').count()
        ok(T+'nursing can sign with exceptions', 'exceptions' in (await pg.inner_text('[data-testid=a81-nurse-open]')).lower() and await pg.locator('[data-testid=a84-nurse-exc]').count()); await shot('09b_nursing_exceptions')
        await pg.click('[data-testid=a81-nurse-open]'); await sign(); ok(T+'nursing signed with exceptions (no gating)', await pg.locator('[data-testid=a81-bench-nursing]').count() == 0)
        await nav('sv-nav-home'); ch = pg.locator('[data-testid=a84-ws-chips]'); ok(T+'station chips on each row', await ch.count() >= 1)
        ok(T+'exceptions status shown', await pg.locator('[data-testid=a84-ws-nursing][data-status=exceptions]').count() >= 1)
        await pg.locator('[data-testid=a84-ws-nursing]').first.click(); await pg.wait_for_timeout(500); ok(T+'chip opens that station', await pg.locator('[data-testid=a81-bench-nursing]').count()); await pg.click('[data-testid=a81-close]')
        await shot('09c_today_station_chips')
        # ---- surgeon: document links + hold-to-talk
        await role('Sam Patel'); await bench('surgeon', 'Desmond'); ok(T+'consent + interval H&P links', await pg.locator('[data-testid=a83-open-consent]').count() and await pg.locator('[data-testid=a83-open-hp]').count())
        before = await pg.input_value('[data-testid=a82-op-text]'); m = pg.locator('[data-testid=a83-mic]'); await m.scroll_into_view_if_needed(); bb = await m.bounding_box()
        await pg.mouse.move(bb['x'] + 10, bb['y'] + 10); await pg.mouse.down(); await pg.wait_for_timeout(500); ok(T+'mic listening while held', 'Listening' in await m.inner_text()); await pg.mouse.up(); await pg.wait_for_timeout(300)
        ok(T+'dictation appended to op report', len(await pg.input_value('[data-testid=a82-op-text]')) > len(before)); await shot('10_surgeon_mic'); await noscroll('surgeon')
        ok(T+'full op report panel (14 sections)', await pg.locator('[data-testid^=a83-opf-mic-]').count() >= 14 and await pg.get_attribute('[data-testid=a83-opfull]', 'data-status') == 'pending')
        m = pg.locator('[data-testid=a83-opf-mic-all]'); await m.scroll_into_view_if_needed(); bb = await m.bounding_box(); await pg.mouse.move(bb['x'] + 10, bb['y'] + 10); await pg.mouse.down(); await pg.wait_for_timeout(400); await pg.mouse.up(); await pg.wait_for_timeout(300)
        ok(T+'scribe filled all sections → dictated', 'Dictated' in await pg.inner_text('[data-testid=a83-opf-status]')); await pg.click('[data-testid=a83-opf-save]'); ok(T+'op report draft saved', 'saved' in await pg.inner_text('[data-testid=a83-opf-msg]'))
        await pg.locator('[data-testid=a83-opfull]').screenshot(path=f'{OUT}{w}_10b_full_op_report.png'); await pg.click('[data-testid=a83-opf-sign-open]'); await sign('Sam Patel'); ok(T+'full op report signed (drawn + PIN)', await pg.locator('[data-testid=a83-opf-signed]').count())
        await pg.locator('[data-testid=a83-open-consent]').scroll_into_view_if_needed(); await pg.click('[data-testid=a83-open-consent]'); await pg.wait_for_timeout(1000); ok(T+'consent document opens', await pg.locator('.a82-form, [data-testid=a82-form-overlay]').count())
        info = await pg.evaluate("()=>{const h=[...document.querySelectorAll('[data-testid=v6-form-host]')].pop();const r=h&&h.shadowRoot;if(!r)return null;const t=r.querySelector('textarea[name=consentTerms]');const all=[...r.querySelectorAll('textarea')].filter(x=>x.offsetParent);return {ro:t?t.readOnly:null,scroll:all.filter(x=>x.scrollHeight>x.clientHeight+3).length,n:all.length}}")
        ok(T+'fixed consent statement read-only', info and info['ro'] is True, str(info)); ok(T+'long text fields full height, no inner scroll', info and info['scroll'] == 0, str(info))
        ok(T+'no text Close button in form footer (X only)', await pg.locator('[data-testid=v6-form-page] footer button:text-is("Close")').count() == 0 and await pg.locator('[aria-label="Close form"]').count() >= 1)
        await shot('10c_consent_fixed_text'); await close_forms()
        if await pg.locator('[data-testid=a82-form-overlay]').count(): await pg.locator('[data-testid=a82-form-overlay] [aria-label=Close]').first.click()
        await pg.click('[data-testid=a81-close]')
        # ---- anesthesia unchanged
        await role('Noor Haddad'); await bench('anesthesia', 'Desmond'); ok(T+'anesthesia workbench unchanged', await pg.locator('[data-testid=a82-medsummary]').count() and await pg.locator('[data-testid=a83-mic]').count() == 0); await pg.click('[data-testid=a81-close]')
        # ---- PACU form full screen by default, X shows tasks
        await role('Alex Rivera'); await bench('pacu', 'Maren'); await pg.wait_for_timeout(800)
        fs = await pg.evaluate("()=>{const e=document.querySelector('[data-testid=a82-pacu-form] .a82-form');if(!e)return 0;const r=e.getBoundingClientRect();return r.width>=innerWidth-2?1:0}"); ok(T+'PACU record full screen', fs == 1); await shot('11_pacu_fullscreen')
        await close_forms(); ok(T+'X closes form to PACU tasks', await pg.locator('[data-testid=a83-pacu-open]').count() and await pg.locator('[data-testid=a82-pacu-form]').count() == 0)
        await pg.click('[data-testid=a81-close]')
        # ---- chart: Overview / Documents / Billing
        await role('Front Desk Tester'); await nav('sv-nav-patients'); await pg.wait_for_timeout(500)
        await pg.evaluate("()=>{const b=[...document.querySelectorAll('button,a,tr,[role=button]')].find(e=>/Maren Holt/.test(e.textContent||'')&&e.offsetParent);b&&b.click()}"); await pg.wait_for_timeout(900)
        ok(T+'ASC chart', await pg.locator('[data-testid=a83-chart]').count())
        if await pg.locator('[data-testid=a83-chart]').count():
            txt = await pg.inner_text('[data-testid=a83-chart]'); ok(T+'no Surgery/Medical leftovers', not any(k in txt for k in ['Clinical record', 'Photos & charts', 'Overall timeline', 'Active problems', 'Surgical risk factors']))
            ok(T+'previous cases with DOS', await pg.locator('[data-testid=a83-chart-case]').count() >= 2); await shot('12_chart_overview'); await noscroll('chart')
            await pg.locator('[data-testid=a83-chart-case]').last.click(); await pg.click('[data-testid=a83-chart-tab-documents]'); ok(T+'documents grouped', await pg.locator('[data-testid=a83-doc-group]').count() == 9)
            ok(T+'op report + payments in documents', await pg.locator('[data-testid=a83-doc]').count() >= 4); ok(T+'print/export all for date (manual)', await pg.locator('[data-testid=a83-doc-print]').count() and await pg.locator('[data-testid=a83-doc-export]').count())
            await shot('13_chart_documents'); await noscroll('documents')
            await pg.locator('[data-testid=a83-doc-view]').first.click(); await pg.wait_for_timeout(500); ok(T+'document viewer', await pg.locator('[data-testid=a83-doc-viewer], .a82-form').count()); await close_forms()
            if await pg.locator('[data-testid=a83-doc-viewer]').count(): await pg.locator('[data-testid=a83-doc-viewer] [aria-label=Close]').first.click()
            await pg.click('[data-testid=a83-chart-tab-billing]'); ok(T+'billing & payments history', await pg.locator('[data-testid=a83-bill-row]').count() >= 1 and await pg.locator('[data-testid=a83-pay-row]').count() >= 1); await shot('14_chart_billing'); await noscroll('chart billing')
        await role('Practice Administrator'); await pg.locator('button:has(.fd-lbl:text-is("Practice Settings"))').first.evaluate('e=>e.click()'); await pg.wait_for_timeout(800)
        ok(T+'surgeon colors in Practice settings', await pg.locator('[data-testid=a84-surgeon-colors] [data-testid=a83-color-in]').count() >= 2)
        if await pg.locator('[data-testid=a84-surgeon-colors]').count(): await pg.locator('[data-testid=a84-surgeon-colors]').scroll_into_view_if_needed(); await pg.screenshot(path=f'{OUT}{w}_15_settings_colors.png')
        for t in ['sv-nav-home', 'sv-nav-patients', 'sv-nav-schedule', 'sv-nav-messages']:
            if await pg.locator(f'[data-testid={t}]').count():
                await nav(t); g = await pg.evaluate("()=>[...document.querySelectorAll('body *')].filter(e=>{const r=e.getBoundingClientRect();const b=getComputedStyle(e).backgroundColor;return r.width>innerWidth*0.6&&r.height>300&&!e.closest('.fd-side')&&!e.closest('.a83-collect')&&b!=='rgba(0, 0, 0, 0)'&&b!=='rgb(255, 255, 255)'}).map(e=>e.className.toString().slice(0,40)+' '+getComputedStyle(e).backgroundColor).slice(0,3)")
                ok(T+f'plain white page · {t}', not g, str(g))
        ok(T+'no page errors', not errs, '; '.join(errs)[:300]); await b.close()
async def main():
    for w in WIDTHS:
        try: await run(w)
        except Exception as e: ok(f'{w}: walk aborted', False, str(e)[:400])
    f = sum(1 for r in res if not r[1]); print(f'TOTAL {len(res)-f}/{len(res)} passed'); sys.exit(1 if f else 0)
asyncio.run(main())
