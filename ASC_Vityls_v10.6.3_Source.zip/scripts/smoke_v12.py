import asyncio, os, re
from playwright.async_api import async_playwright
import sys; sys.path.insert(0,'/workspace/vityls/surgwork/fd'); from v8part import v8; from v9part import v9; from v10part import v10; from v11part import v11; from v12part import v12, pinpart, attpart, hdpart
from v13part import packet, hipaa
from fdpart import fdpart, fdpart2
URL='file:///workspace/vityls/src_v6/vityls_final_build/release/Surgery_Vityls_v1.2/index.html'
OUT='/workspace/vityls/report/surgery_v1.2_regress'
# v1.2: the parts carry their own BASE (pinned to the v1.0 build); point every part at the build under test
import v10part, v11part, v12part, v13part
for _m in (v10part, v11part, v12part, v13part): _m.BASE = URL; os.makedirs(OUT, exist_ok=True)
results=[]
def ok(n,c): results.append((n,bool(c))); print(('PASS ' if c else 'FAIL ')+n, flush=True)
async def run(W,H):
    async with async_playwright() as p:
        b=await p.chromium.launch(executable_path='/usr/bin/google-chrome'); ctx=await b.new_context(viewport={'width':W,'height':H}); pg=await ctx.new_page(); errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
        async def shot(n, full=True):
            await pg.evaluate("()=>{const t=document.querySelector('[data-testid=sv-toast]'); if(t) t.style.visibility='hidden'}")
            if full: await pg.evaluate("()=>{const s=document.createElement('style'); s.id='shot-static'; s.textContent='.sv-top,.fd-top,.fd-side{position:static !important} .fd-side{height:auto !important}'; document.head.appendChild(s)}")
            await pg.screenshot(path=f'{OUT}/{W}_{n}.png', full_page=full)
            if full: await pg.evaluate("()=>document.getElementById('shot-static')?.remove()")
        MENU={'sv-nav-practice','sv-nav-email','sv-nav-portal-hub','open-portal','practice-lock','fd-menu-settings','fd-menu-billing','fd-menu-staff','fd-menu-records','fd-menu-modules'}
        async def c(s):
            # Front Door: settings/admin/portal live in the profile menu; open it first when needed
            m=re.search(r'data-testid=([\w-]+)\]', s)
            if m and m.group(1) in MENU and not await pg.locator(s).first.is_visible():
                if await pg.locator('[data-nav=drawer]').count() and not await pg.locator('[data-testid=fd-side].open').count():
                    await pg.locator('[data-testid=fd-hamburger]').click(); await pg.wait_for_timeout(250)
                await pg.locator('[data-testid=fd-profile]').click(); await pg.wait_for_timeout(150)
            # v1.2: below 900px the Surgery sidebar is a drawer; open it before clicking a sidebar item
            if await pg.locator('[data-nav=drawer]').count() and await pg.locator(f'[data-testid=fd-side] {s}').count() and not await pg.locator('[data-testid=fd-side].open').count():
                await pg.locator('[data-testid=fd-hamburger]').click(); await pg.wait_for_timeout(250)
            try: await pg.locator(s).first.click(timeout=8000)
            except Exception:
                await pg.screenshot(path='/tmp/fail.png'); print('CLICKFAIL', s, flush=True)
                await pg.locator(s).first.click()
        _goto=pg.goto
        async def goto(u, **k):
            u=re.sub(r'release/Surgery_Vityls_v[0-9.]+/index.html', 'release/Surgery_Vityls_v1.2/index.html', u)  # v1.2: every part tests this build
            r=await _goto(u, **k)
            # Front Door opens on the Chat home; the legacy suites start from Today
            if 'Vityls' in u:
                await pg.wait_for_timeout(1200)
                if await pg.locator('[data-testid=fd-chat-home]').count(): await c('[data-testid=sv-nav-home]')
            return r
        pg.goto=goto
        noover = lambda: pg.evaluate("()=>document.documentElement.scrollWidth<=innerWidth+1")
        await _goto(URL+'?reset-test-data'); await pg.wait_for_timeout(1500)
        await fdpart(pg, W, ok, shot, c, noover)
        await pg.select_option('[data-testid=acting-as]', value='Morgan Avery'); await pg.wait_for_timeout(300)
        # ---- Today ----
        ok(f'{W} Today renders v0.7 design', await pg.locator('[data-testid=sv-dashboard].v7-page').count()==1)
        ok(f'{W} greeting', re.match(r'Good (morning|afternoon|evening), Morgan', await pg.inner_text('[data-testid=today-greeting]')))
        ok(f'{W} nav tab highlighted', (await pg.eval_on_selector('[data-testid=sv-nav-home]','e=>getComputedStyle(e).backgroundColor'))=='rgb(239, 229, 216)')
        ok(f'{W} no Add appointment button', await pg.get_by_role('button', name=re.compile('Add appointment')).count()==0)
        ok(f'{W} Add patient button', await pg.locator('[data-testid=sv-dashboard] [data-testid=add-new-patient]').count()==1)
        rows = await pg.locator('[data-testid=dash-card]').count()
        ok(f'{W} KPI visits = rows ({rows})', (await pg.inner_text('[data-testid=kpi-visits] .n'))==str(rows) and rows>0)
        natt = int(await pg.inner_text('[data-testid=kpi-attention] .n'))
        if natt>3: await c('[data-testid=att-all]'); await pg.wait_for_timeout(200)
        ok(f'{W} KPI needs attention = cards ({natt})', await pg.locator('[data-testid=att-card]').count()==natt)
        if natt>3: await c('[data-testid=att-all]'); await pg.wait_for_timeout(200)
        ok(f'{W} KPI new patients', int(await pg.inner_text('[data-testid=kpi-new] .n'))>=1)
        ok(f'{W} Nightingale card + summary', len(await pg.inner_text('[data-testid=nightingale-brief]'))>40 and await pg.locator('[data-testid=ng-chip], [data-testid^=ng-chip]').count()>=1)
        rad = await pg.evaluate("()=>[...document.querySelectorAll('.v7-card,.v7-ng,.v7-att-card,.v7-kpi')].map(e=>getComputedStyle(e)).map(s=>[s.borderTopLeftRadius,s.borderLeftWidth])")
        ok(f'{W} all sections 3px corners', all(r[0]=='3px' for r in rad) and len(rad)>8)
        ok(f'{W} no thick left borders', all(r[1] in ('1px','0px') for r in rad))
        ok(f'{W} default appointment panel open', await pg.locator('[data-testid=today-appt]').count()==1)
        ok(f'{W} no horizontal overflow (Today)', await noover())
        await shot('01_today')
        # panel
        row = pg.locator('[data-testid=dash-card]', has_text='Robert Fictus').first; await row.click(); await pg.wait_for_timeout(400)
        ok(f'{W} row click opens Robert in panel', 'Robert Fictus' in await pg.inner_text('[data-testid=today-appt]'))
        btns = [t.strip() for t in await pg.locator('[data-testid=today-appt] .v7-appt-acts button').all_inner_texts()]
        ok(f'{W} panel buttons exactly Arrived/Check-in/Open chart ({btns})', btns==['Arrived','Check-in','Open chart'])
        ok(f'{W} no Visit workflow in panel', 'Visit workflow' not in await pg.inner_text('[data-testid=today-appt]'))
        await pg.locator('[data-testid=today-appt]').scroll_into_view_if_needed(); await shot('02_today_appointment_panel', full=False)
        await c('[data-testid=dash-arrive]'); await pg.wait_for_timeout(300)
        ok(f'{W} Arrived stamps time', re.search(r'Arrived \d', await pg.inner_text('[data-testid=dash-arrive]')) and 'ARRIVED' in (await pg.inner_text('[data-testid=today-appt-status]')).upper())
        ok(f'{W} list pill Arrived', 'arrived' in (await row.inner_text()).lower())
        await c('[data-testid=dash-checkin]'); await pg.wait_for_timeout(600)
        ok(f'{W} Check-in starts station', await pg.locator('[data-testid=sv-station]').count()==1)
        aud = await pg.evaluate("()=>Object.keys(localStorage).filter(k=>/audit/i.test(k)).map(k=>localStorage.getItem(k)).join('')")
        ok(f'{W} audit visit.arrive + visit.checkin', 'visit.arrive' in aud and 'visit.checkin' in aud)
        await c('[data-testid=sv-nav-home]'); await pg.wait_for_timeout(400)
        ok(f'{W} back on Today: Robert checked in', 'checked in' in (await pg.locator('[data-testid=dash-card]', has_text='Robert Fictus').first.inner_text()).lower())
        await pg.locator('[data-testid=dash-card]', has_text='Robert Fictus').first.click(); await pg.wait_for_timeout(200)
        ok(f'{W} in-progress visit: Continue in check-in slot', 'Continue' in await pg.inner_text('[data-testid=dash-checkin]'))
        await c('[data-testid=today-appt-close]'); await pg.wait_for_timeout(200)
        ok(f'{W} panel closes', await pg.locator('[data-testid=today-appt]').count()==0)
        # date nav
        t0 = await pg.inner_text('[data-testid=today-title]')
        ok(f'{W} Today button disabled on today', await pg.locator('[data-testid=today-today]').is_disabled())
        await c('[data-testid=today-next]'); await pg.wait_for_timeout(300)
        t1 = await pg.inner_text('[data-testid=today-title]')
        ok(f'{W} forward arrow moves a day', t1!=t0 and not await pg.locator('[data-testid=today-today]').is_disabled())
        ok(f'{W} KPI label switches to VISITS', (await pg.inner_text('[data-testid=kpi-visits] .k'))=='VISITS')
        await shot('03_today_date_nav_next_day')
        await c('[data-testid=today-prev]'); await c('[data-testid=today-prev]'); await pg.wait_for_timeout(300)
        await pg.fill('[data-testid=today-date]','2026-10-20'); await pg.wait_for_timeout(300)
        ok(f'{W} date picker jumps', 'October 20' in await pg.inner_text('[data-testid=today-title]'))
        await c('[data-testid=today-today]'); await pg.wait_for_timeout(300)
        ok(f'{W} Today button returns', (await pg.inner_text('[data-testid=today-title]'))==t0)
        # Nightingale
        await pg.fill('[data-testid=nightingale-input]','who is next'); await pg.press('[data-testid=nightingale-input]','Enter'); await pg.wait_for_timeout(700)
        ok(f'{W} Nightingale answers on Today (or acts)', await pg.locator('[data-testid=nightingale-answer]').count()==1 or await pg.locator('[data-testid=sv-station]').count()==1)
        await c('[data-testid=sv-nav-home]'); await pg.wait_for_timeout(300)
        labchip = pg.locator('[data-testid=ng-chip-labs]')
        if await labchip.count():
            await labchip.click(); await pg.wait_for_timeout(500)
            ok(f'{W} lab chip opens chart + slip', await pg.locator('[data-testid=sv-chart]').count()==1 and await pg.locator('[data-testid=right-panel]').count()==1)
            await c('[data-testid=panel-close]')
        # ---- Chart ----
        await c('[data-testid=sv-nav-patients]'); await pg.wait_for_timeout(300)
        ok(f'{W} Patients list restyled + Nightingale card', await pg.locator('[data-testid=sv-patient-list]').count()==1 and await pg.locator('.v8-ngwrap .v7-ng').count()==1 and await pg.locator('.sv-n').count()==0)
        await shot('20_patients_list')
        await c('[data-testid=patient-MED-1001] button'); await pg.wait_for_timeout(500)
        ok(f'{W} chart v0.7 + own Nightingale card', await pg.locator('[data-testid=sv-chart].v7-page').count()==1 and await pg.locator('.v7-ng').count()==1 and await pg.locator('.sv-n').count()==0)
        ok(f'{W} who summary in Nightingale', 'Outside records' in await pg.inner_text('[data-testid=chart-who]'))
        for t in ['chart-allergy','ph-meds','ph-pmh','ph-psh','ph-risks']: ok(f'{W} brief column {t}', await pg.locator(f'[data-testid={t}]').count()==1)
        ok(f'{W} header actions', all([await pg.locator(f'[data-testid={t}]').count()==1 for t in ['chart-add-note','chart-profile-btn','chart-more']]) and await pg.locator('[data-testid=chart-hide]').count()==0)
        ok(f'{W} 6 tabs (v0.11 adds Notes)', await pg.locator('[data-testid=chart-tabs] [role=tab]').count()==6)
        rad = await pg.evaluate("()=>[...document.querySelectorAll('.v7-card,.v7-ng,.v7-tabs')].map(e=>getComputedStyle(e)).map(s=>[s.borderTopLeftRadius,s.borderLeftWidth])")
        ok(f'{W} chart sections 3px, no thick left border', all(r[0]=='3px' and r[1] in ('1px','0px') for r in rad))
        ok(f'{W} no horizontal overflow (chart)', await noover())
        ok(f'{W} overview: attention + problems + risks + side cards', all([await pg.locator(f'[data-testid={t}]').count()==1 for t in ['summary-attention','ov-problems','summary-risks','chart-next-appt','chart-coordinator-row','chart-account','chart-profile-line']]))
        await shot('04_chart_top', full=False); await shot('04b_chart_overview_full')
        await c('[data-testid=chart-tab-clinical]'); await pg.wait_for_timeout(300)
        ok(f'{W} clinical record cards', all([await pg.locator(f'[data-testid={t}]').count()==1 for t in ['cr-meds','cr-allergies','cr-problems','cr-history','cr-results','cr-visits']]))
        await shot('05_chart_clinical_record')
        await c('[data-testid=chart-tab-documents]'); await pg.wait_for_timeout(300)
        ok(f'{W} documents tab: 6 rows + digest', await pg.locator('[data-testid=doc-row]').count()==6 and await pg.locator('[data-testid=doc-digest]').count()==1)
        await pg.locator('[data-testid=doc-row]', has_text='Cardiology').first.locator('[data-testid=doc-ai]').click(); await pg.wait_for_timeout(700)
        ok(f'{W} document AI summary', 'nightingale summary' in (await pg.inner_text('[data-testid=doc-summary]')).lower())
        await shot('06_chart_documents')
        await c('[data-testid=chart-tab-photos]'); await pg.wait_for_timeout(400)
        ok(f'{W} photos & charts tab', await pg.locator('[data-testid=photo-thumb]').count()>=2 and await pg.locator('[data-testid=bodycharts]').count()==1)
        await shot('07_chart_photos_charts')
        await c('[data-testid=chart-tab-activity]'); await pg.wait_for_timeout(300)
        ok(f'{W} activity list', await pg.locator('[data-testid=timeline-item]').count()>=5)
        await shot('08_chart_activity')
        await c('[data-testid=rec-contactnotes]'); await pg.wait_for_timeout(400)
        ok(f'{W} contact notes panel', await pg.locator('[data-testid=contact-note]').count()>=1)
        await shot('09_chart_contact_notes_panel', full=False)
        await c('[data-testid=panel-close]'); await pg.wait_for_timeout(200)
        await c('[data-testid=chart-add-note]'); await pg.wait_for_timeout(300)
        ok(f'{W} add / dictate note dialog', await pg.locator('[data-testid=contact-note-dialog]').count()==1)
        await shot('10_chart_add_note_dialog', full=False)
        await pg.keyboard.press('Escape'); await pg.wait_for_timeout(200)
        if await pg.locator('[data-testid=contact-note-dialog]').count(): await pg.locator('[data-testid=contact-note-dialog] button', has_text='Cancel').first.click()
        await pg.evaluate('scrollTo(0,0)'); await c('[data-testid=chart-more]'); await pg.wait_for_timeout(200)
        ok(f'{W} More menu', await pg.locator('[data-testid=chart-more-menu] [role=menuitem]').count()>=10)
        await shot('11_chart_more_menu', full=False)
        await c('[data-testid=more-careteam]'); await pg.wait_for_timeout(300)
        ok(f'{W} More › Care team opens panel', await pg.locator('[data-testid=right-panel]').count()==1)
        await c('[data-testid=panel-close]')
        await c('[data-testid=chart-profile-btn]'); await pg.wait_for_timeout(300)
        ok(f'{W} Profile opens edit dialog', await pg.locator('[data-testid=edit-profile-dialog]').count()==1)
        await pg.keyboard.press('Escape'); await pg.wait_for_timeout(200)
        await pg.fill('[data-testid=nightingale-input]','blood thinners'); await pg.press('[data-testid=nightingale-input]','Enter'); await pg.wait_for_timeout(700)
        ok(f'{W} chart Nightingale answers', 'clopidogrel' in (await pg.inner_text('[data-testid=nightingale-answer]')).lower())
        await shot('12_chart_nightingale_answer', full=False)
        await v8(pg, W, ok, shot, c, noover)
        await v9(pg, W, ok, shot, c, noover)
        await v10(pg, W, ok, shot, c, noover)
        await v11(pg, W, ok, shot, c, noover)
        await v12(pg, W, ok, shot, c, noover)
        await pinpart(pg, W, ok, shot, c, noover)
        await attpart(pg, W, ok, shot, c, noover)
        await hdpart(pg, W, ok, shot, c, noover)
        await packet(pg, W, ok, shot, c, noover)
        await hipaa(pg, W, ok, shot, c, noover)
        await fdpart2(pg, W, ok, shot, c, noover)
        ok(f'{W} no page errors', not errs); print(errs[:3])
        await b.close()
async def main():
    import sys; WS=[(768,1024),(1180,820)] if len(sys.argv)<2 else [tuple(map(int,sys.argv[1].split('x')))]
    for W,H in WS: await run(W,H)
    print('TOTAL', sum(r[1] for r in results), '/', len(results))
asyncio.run(main())
