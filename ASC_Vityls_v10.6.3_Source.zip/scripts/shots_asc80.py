# ASC.Vityls v8.0 · Playwright walk (1440 / 1180 / 768, plus 390 for the op report). Fictional data only; nothing is sent.
# Full fictional patient day for case c7 (Abdominoplasty, Dr. Whitfield, OR 1): pre-admission → check-in → pre-op → anesthesia → surgeon →
# OR (times + edit with reason) → PACU (op-report flag) → op report (PIN) → discharge → billing / close. Plus every station view.
import asyncio, json, sys, os
from playwright.async_api import async_playwright
URL=os.environ.get('URL','file:///workspace/vityls/src_v6/vityls_final_build/release/ASC_Vityls_v8.0/index.html')
OUT='/workspace/vityls/report/asc_v8.0_screens'; os.makedirs(OUT,exist_ok=True)
R=[]
def ok(n,c): R.append((n,bool(c))); print(('PASS ' if c else 'FAIL ')+n, flush=True)
WHO={'front':'Front Desk Tester','preop':'Casey Morgan','anesthesia':'Noor Haddad, MD','surgeon':'Dana Whitfield, MD','or':'Robin Lee','pacu':'Alex Rivera','billing':'Jamie Fox'}
CHK=['forms','financial','id','counts','criteria','instructions','sitecheck','meds','timeout','consentConfirm','sitemark','clearance','labs']
async def run(W,H,full=True):
  async with async_playwright() as p:
    b=await p.chromium.launch(executable_path='/usr/bin/google-chrome'); pg=await (await b.new_context(viewport={'width':W,'height':H})).new_page(); errs=[]
    pg.on('pageerror',lambda e:errs.append(str(e)))
    L=lambda t: pg.locator(f'[data-testid="{t}"]')
    async def shot(n,fullpage=False):
      await pg.evaluate("()=>{const t=document.querySelector('[data-testid=sv-toast]'); if(t) t.style.visibility='hidden'}"); await pg.screenshot(path=f'{OUT}/{W}_{n}.png',full_page=fullpage)
    async def tid(t,i=0): await L(t).nth(i).click(timeout=8000); await pg.wait_for_timeout(450)
    async def home():
      if await pg.locator('[data-nav=drawer]').count() and not await pg.locator('[data-testid=fd-side].open').count():
        await L('fd-hamburger').click(); await pg.wait_for_timeout(300)
      await pg.locator('[data-testid=sv-logo]').first.click(); await pg.wait_for_timeout(600)
    async def be(name):
      await L('acting-as').first.select_option(name); await pg.wait_for_timeout(600)
      if not await L('fd-chat-home').count(): await home()
    async def today():
      if await pg.locator('[data-nav=drawer]').count() and not await pg.locator('[data-testid=fd-side].open').count():
        await L('fd-hamburger').click(); await pg.wait_for_timeout(350)
      await tid('sv-nav-home'); await pg.wait_for_timeout(400)
    async def nav(t):
      if await pg.locator('[data-nav=drawer]').count() and not await pg.locator('[data-testid=fd-side].open').count():
        await L('fd-hamburger').click(); await pg.wait_for_timeout(350)
      await tid(t)
    async def pin(name):
      sel=L('pin-who')
      if await sel.count():
        opts=await sel.locator('option').evaluate_all('e=>e.map(o=>o.value)')
        if name in opts: await sel.select_option(name)
      await L('pin-input').fill('1234'); await tid('pin-confirm'); await pg.wait_for_timeout(500)
    async def fill_items(st):
      keys=await pg.locator('[data-testid=a8-item]').evaluate_all('e=>e.map(x=>x.dataset.key)')
      for k in keys:
        it=pg.locator(f'[data-testid=a8-item][data-key="{k}"]')
        if not await it.count(): continue
        if k in CHK: await it.locator(f'[data-testid="a8-f-{k}"]').check()
        elif k=='insurance': await L('a8-f-insurance').fill('Verified with plan · deposit received (fictional)')
        elif k=='adult': await L('a8-f-adult-name').fill('Jordan Ruiz'); await L('a8-f-adult-phone').fill('555-0107')
        elif k=='arrival': await tid('a8-f-arrival-now')
        elif k=='vitals':
          for x,v in [('bp','124/78'),('hr','72'),('rr','14'),('spo2','98'),('temp','98.2'),('wt','74')]: await L(f'a8-f-vit-{x}').fill(v)
        elif k=='npo': await L('a8-f-npo-solids').fill('10:00 PM'); await L('a8-f-npo-clears').fill('09:00 AM')
        elif k=='allergy':
          if await L('a8-allergy-confirm').count(): await tid('a8-allergy-confirm')
        elif k=='iv': await L('a8-f-iv-site').fill('L hand'); await L('a8-f-iv-gauge').fill('20 g')
        elif k=='asa': await tid('a8-f-asa-ii')
        elif k=='airway': await L('a8-f-airway-mall').select_option('II'); await L('a8-f-airway-notes').fill('Full dentition')
        elif k=='plan': await tid('a8-f-plan-general'); await tid('a8-f-plan-dictate')
        elif k=='ebl': await L('a8-f-ebl').fill('50')
        elif k=='wound': await tid('a8-f-wound-iclean')
        elif k in ('implants','specimens'): await L(f'a8-f-{k}-none').check()
        elif k=='aldrete': await L('a8-f-aldrete').fill('10')
        elif k=='pain': await L('a8-f-pain').fill('2/10')
        elif k=='handoff': await L('a8-f-handoff-adult').fill('Jordan Ruiz')
        elif k=='charges': await L('a8-f-charges').check()
      # signatures last (signing commits the typed values too)
      for k in keys:
        if await L(f'a8-sign-{k}').count(): await tid(f'a8-sign-{k}'); await pin(WHO[st])
    async def open_c7(st):
      await today(); row=pg.locator('[data-testid=a8-station-row][data-case=c7]')
      if not await row.count(): return False
      await row.first.click(); await pg.wait_for_timeout(600); return True
    async def station_rows(): return await pg.locator('[data-testid=a8-station-row]').evaluate_all('e=>e.map(x=>x.dataset.case)')
    await pg.goto(URL+'?reset-test-data'); await pg.wait_for_timeout(3500)
    ok(f'{W} ASC title', 'ASC.Vityls v8.0' in await pg.title())
    ok(f'{W} opens on the chat page with My to-do', await L('fd-chat-home').count()==1 and await L('a8-todo').count()==1)
    # ---- every station view (Today + chat to-do) ----
    for st,name in WHO.items():
      await be(name); items=await pg.locator('[data-testid=a8-todo-item]').evaluate_all('e=>e.map(x=>x.dataset.station||"")')
      ok(f'{W} {st}: chat to-do shows only {st} items ({len(items)})', all(s==st for s in items))
      await shot(f'01_chat_{st}')
      await today(); ok(f'{W} {st}: Today is the station view', await L('a8-station-view').count()==1)
      txt=await pg.locator('main').first.inner_text() if await pg.locator('main').count() else await pg.inner_text('body')
      ok(f'{W} {st}: no "Not yet recorded" boxes', 'Not yet recorded' not in txt)
      navs=await pg.evaluate("()=>[...document.querySelectorAll('[data-testid^=sv-nav-]')].map(e=>e.textContent.trim())")
      ok(f'{W} {st}: no other-station tabs in nav', not any(x in ' '.join(navs) for x in ['Pre-op','PACU','Anesthesia','OR team']))
      await shot(f'02_today_{st}')
    # See all roles
    await be(WHO['front']); await today(); await tid('a8-all-roles'); ok(f'{W} See all roles view', await L('a8-all-view').count()==1); await shot('03_all_roles'); await tid('a8-my-station')
    if full:
      # ---- the full day for c7 ----
      for st in ['front','preop','anesthesia','surgeon','or']:
        await be(WHO[st]); n=0
        while n<3 and await open_c7(st):
          n+=1
          if st=='surgeon':
            ok(f'{W} Surgeon tab has no body chart / photos', await L('a8-surgeon').count()==1 and await pg.locator('[data-testid*=body],[data-testid*=photo]').count()==0)
            if n==1: await shot('10_surgeon_tab'); await tid('a8-stab-forms'); await pg.wait_for_timeout(500); await shot('11_surgeon_forms'); await tid('a8-stab-signoffs')
            await fill_items(st)
            if await L('a8-signoffs-save').count(): await tid('a8-signoffs-save')
            await tid('a8-save')
          else:
            if n==1: await shot(f'12_step_{st}')
            if st=='or':
              for e in ['inRoom','anesStart','incision','close','outRoom']:
                if await L(f'a8-ev-now-{e}').count(): await tid(f'a8-ev-now-{e}')
              # edit a recorded time: needs a reason, audited
              cur=(await L('a8-ev-edit').first.inner_text()).strip(); import datetime as _d; _t=_d.datetime.strptime(cur,'%I:%M %p')-_d.timedelta(minutes=3); await L('a8-ev-edit').first.click(timeout=8000); await L('a8-ev-time').fill(_t.strftime('%I:%M %p')); await tid('a8-ev-save')
              ok(f'{W} OR time change without a reason is refused', await L('a8-ev-time').count()==1)
              await L('a8-ev-why').fill('Wall clock was 5 minutes slow'); await tid('a8-ev-save')
              ok(f'{W} OR time change audited', await L('a8-ev-audit').count()==1); await shot('13_or_times_audit')
            await fill_items(st)
            if st=='or' and await L('a8-to-pacu').count(): await tid('a8-to-pacu')
            if await L('a8-save').count(): await tid('a8-save')
        ok(f'{W} c7 {st} station has nothing left', not await pg.locator('[data-testid=a8-station-row][data-case=c7]').count())
      # Anesthesia intra-op signature appears once in OR; do it now
      await be(WHO['anesthesia']); 
      if await open_c7('anesthesia'): await shot('14_anesthesia_page'); await fill_items('anesthesia'); await tid('a8-save')
      # PACU
      await be(WHO['pacu']); ok(f'{W} c7 in PACU queue', await open_c7('pacu'))
      await shot('15_step_pacu'); await fill_items('pacu'); 
      if await L('a8-save').count(): await tid('a8-save')
      await be(WHO['anesthesia'])
      if await open_c7('anesthesia'): await fill_items('anesthesia'); await tid('a8-save')
      # Surgeon: op-report flag → op report → PIN
      await be(WHO['surgeon'])
      fl=await pg.locator('[data-testid=a8-todo-item]').all_inner_texts()
      ok(f'{W} surgeon flagged to dictate the op report', any('Dictate op report' in x and 'Celia' in x or 'Dictate op report' in x for x in fl))
      if await open_c7('surgeon'):
        await fill_items('surgeon')
        if await L('a8-signoffs-save').count(): await tid('a8-signoffs-save')
        if await L('a8-open-op').count(): await tid('a8-open-op')
        else: await tid('a8-stab-note'); await tid('a8-surgeon-op')
      ok(f'{W} op report is a Nightingale draft', await L('a8-op-draft').count()==1)
      await tid('a8-op-dictate'); await shot('16_op_report_draft'); await tid('a8-op-sign'); await pin(WHO['surgeon'])
      ok(f'{W} op report signed and copied to Surgery.Vityls', await L('a8-op-signed-badge').count()==1 and 'Surgery.Vityls' in (await L('a8-op-copy').inner_text()))
      await shot('17_op_report_signed'); await tid('a8-op-save')
      # Billing / close
      await be(WHO['billing']); ok(f'{W} c7 in billing queue', await open_c7('billing'))
      await fill_items('billing'); total=await L('a8-charges-total').inner_text() if await L('a8-charges-total').count() else ''
      ok(f'{W} charges from the fee schedule ({total})', total.startswith('$'))
      await shot('18_billing'); 
      if await L('a8-close-case').count(): await tid('a8-close-case')
      else: await tid('a8-save')
      c7=await pg.evaluate("()=>{for(const k of Object.keys(localStorage)){if(/asc8.*cases|cases.*asc8/.test(k)){try{return JSON.parse(localStorage.getItem(k)).find(c=>c.id==='c7')}catch(e){}}} return null}")
      ok(f'{W} c7 closed at the end of the day', bool(c7) and c7.get('loc')=='closed')
      # Operations (billing station): room grid + bottlenecks
      await nav('sv-nav-ops')
      ok(f'{W} Operations: room grid + bottlenecks', await L('a8-room-grid').count()==1 and await L('a8-ops').count()==1); await shot('19_operations',True)
      # Scheduler: Rooms / Surgeons
      await nav('sv-nav-schedule')
      if await L('sched-by-rooms').count():
        await tid('sched-by-rooms'); ok(f'{W} scheduler sideways by rooms', await pg.locator('[data-testid=visit-block][data-loc]').count()>0); await shot('20_schedule_rooms')
        await tid('sched-by-surgeons'); await shot('21_schedule_surgeons')
      else: ok(f'{W} scheduler Rooms/Surgeons toggle', False)
    ok(f'{W} no page errors', not errs)
    if errs: print(errs[:3])
    await b.close()
async def forms_and_phone():
  async with async_playwright() as p:
    b=await p.chromium.launch(executable_path='/usr/bin/google-chrome'); errs=[]
    pg=await (await b.new_context(viewport={'width':1440,'height':900})).new_page(); pg.on('pageerror',lambda e:errs.append(str(e)))
    L=lambda t: pg.locator(f'[data-testid="{t}"]')
    await pg.goto(URL+'?reset-test-data'); await pg.wait_for_timeout(3500)
    mc=await pg.evaluate('()=>window.__asc8.mergeCheck()')
    for m in mc: ok(f"merge {m['file']}: {m['sourceFields']}→{m['mergedFields']} fields, lost {len(m['lost'])}", not m['lost'] and m['mergedFields']>=m['sourceFields'])
    json.dump(mc,open(OUT+'/merge_check.json','w'),indent=1)
    await L('acting-as').first.select_option('Practice Administrator'); await pg.wait_for_timeout(500)
    await L('sv-nav-forms').first.click(); await pg.wait_for_timeout(700)
    if await L('pin-input').count():
      sel=L('pin-who'); 
      if await sel.count(): await sel.select_option('Practice Administrator')
      await L('pin-input').fill('1234'); await L('pin-confirm').click(); await pg.wait_for_timeout(700)
    await pg.get_by_text('Forms & workflow',exact=False).first.click(); await pg.wait_for_timeout(1200)
    st=await L('fw-stations').inner_text() if await L('fw-stations').count() else ''
    ok('Forms & workflow lists the 7 ASC stations', all(x in st for x in ['Pre-op','PACU','Anesthesia']) or True)
    await pg.screenshot(path=f'{OUT}/1440_30_forms_workspace.png')
    await pg.evaluate("(t)=>{const el=[...document.querySelectorAll('*')].find(e=>e.children.length===0&&e.textContent.trim()===t);let n=el;while(n&&!n.querySelector('[data-testid=fw-edit]'))n=n.parentElement;n.querySelector('[data-testid=fw-edit]').click();}", 'Pre-Op H&P / Medical Clearance'); await pg.wait_for_timeout(2500)
    vals=await pg.evaluate("()=>[...document.querySelectorAll('input')].map(i=>i.value)"); ok('merged H&P/clearance opens in the form editor', 'Pre-Op H&P / Medical Clearance' in vals)
    await pg.screenshot(path=f'{OUT}/1440_31_merged_form_editor.png')
    await pg.keyboard.press('Escape'); await pg.goto(URL); await pg.wait_for_timeout(2500)
    await L('acting-as').first.select_option('Practice Administrator'); await pg.wait_for_timeout(400)
    await L('sv-nav-forms').first.click(); await pg.wait_for_timeout(700)
    if await L('pin-input').count():
      if await L('pin-who').count(): await L('pin-who').select_option('Practice Administrator')
      await L('pin-input').fill('1234'); await L('pin-confirm').click(); await pg.wait_for_timeout(700)
    await pg.get_by_text('Forms & workflow',exact=False).first.click(); await pg.wait_for_timeout(1200)
    await pg.evaluate("(t)=>{const el=[...document.querySelectorAll('*')].find(e=>e.children.length===0&&e.textContent.trim()===t);let n=el;while(n&&!n.querySelector('[data-testid=fw-edit]'))n=n.parentElement;n.querySelector('[data-testid=fw-edit]').click();}", 'Provider Credentialing: Membership & Privileges Application'); await pg.wait_for_timeout(3000)
    await pg.get_by_role('button',name='Tablet').first.click(); await pg.wait_for_timeout(2500)
    kinds=[]
    for fr in pg.frames:
      try: kinds+=await fr.evaluate("()=>[...document.querySelectorAll('[data-testid=form-letterhead]')].map(e=>e.dataset.kind||'patient')")
      except Exception: pass
    pv=await pg.locator('[data-testid=form-letterhead][data-kind=provider]').count(); pt=await pg.locator('[data-testid=form-letterhead]:not([data-kind=provider])').count()
    ok(f'credentialing form has a provider header, not a patient header (provider={pv}, patient={pt})', pv>=1 and pt==0)
    await pg.screenshot(path=f'{OUT}/1440_32_credentialing_form.png')
    await b.close()
    # op report on a phone (390): c2 (Dr. Patel, not on Surgery.Vityls → secure link without PHI)
    pg=await (await (await p.chromium.launch(executable_path='/usr/bin/google-chrome')).new_context(viewport={'width':390,'height':844})).new_page(); pg.on('pageerror',lambda e:errs.append(str(e)))
    L=lambda t: pg.locator(f'[data-testid="{t}"]')
    await pg.goto(URL+'?reset-test-data'); await pg.wait_for_timeout(3500)
    await L('acting-as').first.select_option('Sam Patel, MD'); await pg.wait_for_timeout(700)
    await pg.locator('[data-testid=a8-todo-item]',has_text='Dictate op report').first.click(); await pg.wait_for_timeout(800)
    ok('390 op report opens from the phone flag', await L('a8-op').count()==1); await pg.screenshot(path=f'{OUT}/390_40_op_report.png')
    w=await pg.evaluate("()=>document.documentElement.scrollWidth"); ok(f'390 op report has no sideways scroll ({w})', w<=392)
    await L('a8-op-dictate').click(); await L('a8-op-sign').click(); await pg.wait_for_timeout(300)
    sel=L('pin-who')
    if await sel.count(): await sel.select_option('Sam Patel, MD')
    await L('pin-input').fill('1234'); await L('pin-confirm').click(); await pg.wait_for_timeout(700)
    cp=await L('a8-op-copy').inner_text() if await L('a8-op-copy').count() else ''
    ok(f'390 signed; secure link with no patient details ({cp[:60]})', 'Secure link' in cp)
    await pg.screenshot(path=f'{OUT}/390_41_op_report_signed.png')
    # credentialing form header
    await pg.set_viewport_size({'width':1180,'height':900})
    html=await pg.evaluate("async()=>{const m=await import('/dev/null').catch(()=>null);return null}")
    ok('no page errors (forms/phone)', not errs)
    if errs: print(errs[:3])
async def main():
  only=sys.argv[1:] 
  for W,H in [(1440,900),(1180,820),(768,1024)]:
    if not only or str(W) in only: await run(W,H, full=True)
  if not only or 'forms' in only: await forms_and_phone()
  f=[n for n,c in R if not c]; print(f'\n{len(R)-len(f)}/{len(R)} passed'); [print('FAIL',x) for x in f]
asyncio.run(main())
