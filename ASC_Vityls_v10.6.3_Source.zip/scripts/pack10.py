import zipfile, os, subprocess, re
R='/workspace/vityls/src_v6/vityls_final_build'; REL=R+'/release/Surgery_Vityls_v1.0'
rd=open('/workspace/vityls/surgwork/v13/README.txt').read().replace('v0.13','v1.0').replace('2026-10-13','2026-10-16')
rd=rd.replace('WHAT THIS IS','''NEW IN v1.0 (FRONT DOOR DESIGN)
Opens on Nightingale's chat home (Chat | Practice switch). Sidebar headings: Today, Patients, Schedule,
Messages, Forms & Documents; settings, billing and admin are in the profile menu at the bottom. Today is a
colour timeline with a date picker (previous / next day / pick a date). Stations open as a side panel showing
their assigned forms, ready to fill and sign. Photos and body-chart drawings can be deleted (PIN + audit), and
surgeons can upload their own body charts / pictures as templates. See Surgery_v1.0_Changelog.md.

WHAT THIS IS''',1)
open(REL+'/README.txt','w').write(rd)
cl=R+'/report/Surgery_v1.0_Changelog.md'
if os.path.exists(cl): open(REL+'/Surgery_v1.0_Changelog.md','w').write(open(cl).read())
for f in ['start-mac.command','start-windows.bat']:
    s='/workspace/vityls/surgwork/v13/'+f
    if os.path.exists(s): open(REL+'/'+f,'wb').write(open(s,'rb').read())
z=zipfile.ZipFile('/workspace/vityls/Surgery_Vityls_v1.0.zip','w',zipfile.ZIP_DEFLATED)
for d,_,fs in os.walk(REL):
    for f in fs: p=os.path.join(d,f); z.write(p,'Surgery_Vityls_v1.0/'+os.path.relpath(p,REL))
z.close()
files=subprocess.check_output(['git','ls-files'],cwd=R,text=True).split('\n')
z=zipfile.ZipFile('/workspace/vityls/Surgery_Vityls_v1.0_Source.zip','w',zipfile.ZIP_DEFLATED); n=0
for f in files:
    if f and os.path.isfile(R+'/'+f) and not f.startswith(('release/','dist')): z.write(R+'/'+f,'Surgery_Vityls_v1.0_Source/'+f); n+=1
z.close(); print('ok',n, os.path.getsize('/workspace/vityls/Surgery_Vityls_v1.0.zip')//1e6, os.path.getsize('/workspace/vityls/Surgery_Vityls_v1.0_Source.zip')//1e6)
