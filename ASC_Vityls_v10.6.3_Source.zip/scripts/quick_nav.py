import asyncio
from playwright.async_api import async_playwright
URL='file:///workspace/vityls/src_v6/vityls_final_build/release/Surgery_Vityls_v1.2/index.html'
OUT='/workspace/vityls/report/surgery_v1.2_screens'
async def main():
  async with async_playwright() as p:
    b=await p.chromium.launch(executable_path='/usr/bin/google-chrome')
    for W,H in [(1440,900),(1180,820),(820,1100)]:
      pg=await b.new_page(viewport={'width':W,'height':H}); errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
      await pg.goto(URL+'?reset-test-data'); await pg.wait_for_timeout(2000)
      await pg.click('[data-testid=fd-mode-practice]') if await pg.locator('[data-testid=fd-mode-practice]').is_visible() else None
      nav=await pg.get_attribute('.fd-app','data-nav'); sw=await pg.evaluate("()=>document.querySelector('[data-testid=fd-side]').getBoundingClientRect().width")
      labels=[await pg.locator(f'[data-testid={t}]').count() for t in ['sv-nav-billing','sv-nav-forms']]; ft=await pg.inner_text('[data-testid=sv-nav-forms]') if W>1280 else ''
      print(W,nav,round(sw),labels,ft.strip(),errs[:2])
      if W==1180:
        await pg.click('[data-testid=fd-navtog]'); await pg.wait_for_timeout(200); print(' toggled ->', await pg.get_attribute('.fd-app','data-nav'))
        await pg.reload(); await pg.wait_for_timeout(1500); print(' after reload ->', await pg.get_attribute('.fd-app','data-nav'))
      await pg.screenshot(path=f'{OUT}/{W}_nav.png'); await pg.close()
    await b.close()
asyncio.run(main())
