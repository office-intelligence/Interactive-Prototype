import json, urllib.parse, subprocess, time, datetime
SPECS=['Cardiovascular Disease','Family Medicine','Internal Medicine','Dermatology','Orthopaedic Surgery','Plastic Surgery','Obstetrics & Gynecology','Pediatrics','Ophthalmology','Gastroenterology','Endocrinology','Neurology']
CITIES=[('Beverly Hills','CA'),('Los Angeles','CA')]
out={}; queries=[]
for city,st in CITIES:
  for s in SPECS:
    q={'version':'2.1','city':city,'state':st,'taxonomy_description':s,'enumeration_type':'NPI-1','limit':'30'}
    url='https://npiregistry.cms.hhs.gov/api/?'+urllib.parse.urlencode(q)
    d=json.loads(subprocess.check_output(['curl','-s',url])); queries.append({'url':url,'count':d.get('result_count',0)})
    for r in d.get('results',[]):
      b=r['basic']; loc=next((a for a in r['addresses'] if a['address_purpose']=='LOCATION'),r['addresses'][0])
      tx=next((t for t in r['taxonomies'] if t.get('primary')),r['taxonomies'][0])
      z=loc.get('postal_code','')
      out[r['number']]={'npi':r['number'],'type':r['enumeration_type'],'first':b.get('first_name','').title(),'last':b.get('last_name','').title(),'middle':b.get('middle_name','')[:1],'credential':b.get('credential',''),'sex':b.get('sex',''),
        'org':b.get('organization_name',''),'specialty':tx['desc'],'taxonomy':tx['code'],'taxonomies':[t['desc'] for t in r['taxonomies']],'enumerated':b.get('enumeration_date',''),'updated':b.get('last_updated',''),
        'line1':loc.get('address_1','').title(),'line2':loc.get('address_2','').title(),'city':loc.get('city','').title(),'state':loc.get('state',''),'zip':z[:5],'phone':loc.get('telephone_number',''),'fax':loc.get('fax_number','')}
    time.sleep(0.3)
snap={'source':'NPPES NPI Registry API v2.1 (public data, CMS)','fetched':datetime.datetime.now().astimezone().isoformat(timespec='minutes'),'queries':queries,'providers':list(out.values())}
json.dump(snap,open('npi_snapshot.json','w'))
print(len(out), sum(q['count'] for q in queries))
