"""ASC.Vityls v8.8 walkthrough (Playwright + Chrome). Usage: python3 scripts/walk82.py [URL] [WIDTH...]. Fictional data; test PIN 1234."""
import asyncio, sys, os
from playwright.async_api import async_playwright
URL = sys.argv[1] if len(sys.argv) > 1 else 'http://localhost:8799/'
WIDTHS = [int(w) for w in sys.argv[2:]] or [1440, 1024, 390]
OUT = '/workspace/vityls/report/asc_v8.8_screens/best/'; os.makedirs(OUT, exist_ok=True)
CARD = '/tmp/fake_card.png'
res = []
def ok(name, cond, note=''): res.append((name, bool(cond), note)); print(('PASS' if cond else 'FAIL'), name, note, flush=True)
async def run(w):
    async with async_playwright() as p:
        b = await p.chromium.launch(executable_path='/usr/bin/google-chrome'); pg = await b.new_page(viewport={'width': w, 'height': 900 if w > 500 else 844}); pg.set_default_timeout(8000)
        errs = []; pg.on('pageerror', lambda e: errs.append(str(e))); pg.on('dialog', lambda d: asyncio.ensure_future(d.accept()))
        await pg.goto(URL + '?reset-test-data'); await pg.wait_for_timeout(2500)
        T = f'{w}:'
        async def shot(n):
            await pg.evaluate("()=>document.querySelectorAll('.a81-dbody,.a8-body').forEach(e=>e.scrollTop=0)"); await pg.screenshot(path=f'{OUT}{w}_{n}.png', full_page=True)
        async def noscroll(where):
            sw = await pg.evaluate('()=>document.documentElement.scrollWidth - window.innerWidth'); ok(T+f'no sideways scroll · {where}', sw <= 1, f'+{sw}px')
        async def role(label):
            s = pg.locator('select').first; opts = await s.evaluate("s=>[...s.options].map(o=>o.text)"); await s.select_option(label=[o for o in opts if label in o][0]); await pg.wait_for_timeout(600)
        async def nav(tid):
            await pg.locator(f'[data-testid={tid}]').first.evaluate('e=>e.click()'); await pg.wait_for_timeout(700)
        async def draw(sel):
            c = pg.locator(sel).first; await c.scroll_into_view_if_needed(); bb = await c.bounding_box()
            x, y = bb['x'] + 20, bb['y'] + bb['height'] / 2
            await pg.mouse.move(x, y); await pg.mouse.down()
            for i in range(1, 12): await pg.mouse.move(x + i * 14, y + (12 if i % 2 else -12))
            await pg.mouse.up(); await pg.wait_for_timeout(150)
        async def sign(who=None):
            await pg.wait_for_selector('[data-testid=pin-sign]')
            if who:
                opts = await pg.eval_on_selector('[data-testid=pin-who]', "s=>[...s.options].map(o=>o.text)"); await pg.select_option('[data-testid=pin-who]', label=[o for o in opts if who in o][0])
            else:
                v = await pg.eval_on_selector('[data-testid=pin-who]', 'e=>e.value')
                if not v: await pg.select_option('[data-testid=pin-who]', index=1)
            await draw('[data-testid=pin-sigpad-canvas]')
            await pg.fill('[data-testid=pin-input]', '1234'); await pg.click('[data-testid=pin-confirm]'); await pg.wait_for_timeout(500)
        async def bench(chip, patient=None):
            if await pg.locator('[data-testid=a81-close]').count(): await pg.click('[data-testid=a81-close]')
            await nav('sv-nav-home'); a = pg.locator('[data-testid=a81-chip-all]')
            if await pg.locator(f'[data-testid=a81-chip-{chip}]').count() == 0 and await a.count(): await a.click()
            await pg.click(f'[data-testid=a81-chip-{chip}]'); await pg.wait_for_selector(f'[data-testid=a81-bench-{chip}]')
            if patient:
                opts = await pg.eval_on_selector('[data-testid=a81-case-pick]', "s=>[...s.options].map(o=>o.text)"); await pg.select_option('[data-testid=a81-case-pick]', label=[o for o in opts if patient in o][0]); await pg.wait_for_timeout(300)
        async def fillsel(tid):
            v = await pg.eval_on_selector(f'[data-testid={tid}]', 'e=>e.value')
            if not v: await pg.select_option(f'[data-testid={tid}]', index=1)
        async def close_forms():
            for _ in range(3):
                x = pg.locator('.a82-form [aria-label="Close form"]')
                if await pg.locator('.a82-form').count() and await x.count(): await x.first.click(); await pg.wait_for_timeout(400)
        await pg.evaluate("()=>{window.print=()=>{window.__printed=(window.__printed||0)+1}}")
        LS = lambda: pg.evaluate("()=>JSON.stringify(Object.values(localStorage))")
        async def closeall():
            for _ in range(4):
                x = pg.locator('[data-testid=a88-card-close],[data-testid=a81-close],[data-testid=a8-close],[aria-label="Close"]')
                if await x.count():
                    try: await x.first.click(timeout=1500)
                    except Exception: pass
                    await pg.wait_for_timeout(250)
                else: break
        await role('Front Desk Tester'); await nav('sv-nav-home'); await pg.wait_for_timeout(700)
        bg = await pg.evaluate("()=>getComputedStyle(document.getElementById('sv-main')).backgroundColor"); ok(T+'cream page background', bg.replace(' ', '') in ('rgb(250,247,240)',), bg)
        ok(T+'general upload button removed from Today', await pg.locator('[data-testid=a87-upload-open]').count() == 0)
        tops = await pg.locator('[data-testid=a87-kpis] > *').evaluate_all("es=>es.map(e=>Math.round(e.getBoundingClientRect().top))"); ok(T+'5 stat boxes on one line', len(tops) == 5 and len(set(tops)) == 1, str(tops))
        ok(T+'cards tinted (blue cleared / amber missing), no left color bar', await pg.locator('.a87-card.a88-cleared, .a87-card.a88-missing').count() >= 1)
        ct = await pg.inner_text('[data-testid=a87-patients]'); ok(T+"chips: no 'Not started' text", 'Not started' not in ct)
        ok(T+'chips: red/green dots', await pg.locator('.a88-dot.red').count() >= 1 and await pg.locator('.a88-dot.green').count() >= 1)
        tb = await pg.evaluate("()=>getComputedStyle(document.querySelector('[data-testid=a87-todo]')).backgroundColor"); ok(T+'to-do has background color', tb.replace(' ', '') != 'rgb(255,255,255)', tb)
        await noscroll('today'); await shot('01_today')
        if w < 500: return
        # 1 · journey bar: station → station for the same patient, next patient
        card = pg.locator('[data-testid=a87-card]', has_text='Desmond').first; await card.locator('[data-testid=a84-ws-nursing]').click(); await pg.wait_for_timeout(700)
        ok(T+'station shows journey bar', await pg.locator('[data-testid=a81-bench-nursing] [data-testid=a88-journey]').count() == 1)
        ok(T+'current station highlighted', await pg.locator('[data-testid=a88-step-nursing][aria-current=step]').count() == 1)
        await pg.screenshot(path=f'{OUT}{w}_02_station_journey.png')
        await pg.click('[data-testid=a88-step-anesthesia]'); await pg.wait_for_timeout(700)
        dc = await pg.inner_text('[data-testid=a81-bench-anesthesia] .a82-dcase') if await pg.locator('[data-testid=a81-bench-anesthesia]').count() else ''
        ok(T+'tap step → anesthesia for same patient', 'Desmond' in dc, dc[:60])
        nx = pg.locator('[data-testid=a88-next-patient]'); ok(T+'next-patient switcher', await nx.count() == 1)
        before = await pg.inner_text('.a82-dcase'); await nx.click(); await pg.wait_for_timeout(500); after = await pg.inner_text('.a82-dcase'); ok(T+'next patient loads', before != after)
        await pg.click('[data-testid=a88-step-pacu]'); await pg.wait_for_timeout(600); ok(T+'jump ahead never blocked (PACU opens)', await pg.locator('[data-testid=a81-bench-pacu]').count() == 1)
        await close_forms()
        await pg.click('[data-testid=a88-step-booking]'); await pg.wait_for_timeout(600); ok(T+'booking step opens details with docked journey', await pg.locator('[data-testid=a88-dock]').count() == 1)
        await closeall()
        # 3 · upload from chart → checklist auto-Received
        await nav('sv-nav-home'); pc = pg.locator('[data-testid=a87-card]', has_text='Priya').first
        await pc.locator('[data-testid=a84-ws-front]').click(); await pg.wait_for_timeout(600); await pg.click('[data-testid=a88-step-checkin]'); await pg.wait_for_timeout(700)
        await pg.locator('[data-testid=a81-arrival] details summary').first.click()
        st = lambda lbl: pg.locator('[data-testid=a81-check]', has_text=lbl).first.get_attribute('data-state')
        MAP = [('Pre-op clearance', 'Medical clearance'), ('H&P', 'Pre-op H&P'), ('Labs', 'Lab results'), ('Ride home & caregiver', 'Ride home & caregiver'), ('Post-op care location', 'Post-op care location'), ('Surgical consent', 'Surgical consent')]
        LBL, TYP = MAP[0]
        for l_, t_ in MAP:
            if await st(l_) == 'missing': LBL, TYP = l_, t_; break
        b_cl = await st(LBL); await closeall()
        await pc.locator('[data-testid=a87-chart]').click(); await pg.wait_for_timeout(700); await pg.locator('[role=tab]', has_text='Documents').click(); await pg.wait_for_timeout(400)
        ok(T+'Upload button in chart Documents', await pg.locator('[data-testid=a88-chart-upload]').count() == 1)
        await pg.click('[data-testid=a88-chart-upload]'); await pg.wait_for_timeout(400)
        open('/tmp/a88_clear.txt','w').write('Fictional clearance letter (test)')
        await fillsel('a87-up-ep'); await pg.locator('[data-testid=a87-up-type]').first.select_option(TYP); await pg.set_input_files('[data-testid=a87-up-files]', ['/tmp/a88_clear.txt']); await pg.wait_for_timeout(300)
        if await pg.locator('[data-testid=a87-up-type]').count() > 0:
            for i in range(await pg.locator('[data-testid=a87-up-type]').count()): await pg.locator('[data-testid=a87-up-type]').nth(i).select_option(TYP)
        await pg.click('[data-testid=a87-up-save]'); await pg.wait_for_timeout(500); s = await LS(); ok(T+'upload audited', 'asc87.upload' in s and 'a88_clear.txt' in s)
        await nav('sv-nav-home'); pc = pg.locator('[data-testid=a87-card]', has_text='Priya').first
        await pc.locator('[data-testid=a84-ws-front]').click(); await pg.wait_for_timeout(600); await pg.click('[data-testid=a88-step-checkin]'); await pg.wait_for_timeout(700)
        await pg.locator('[data-testid=a81-arrival] details summary').first.click(); a_cl = await st(LBL)
        ok(T+'upload → checklist Received automatically', b_cl == 'missing' and a_cl == 'received', f'{LBL}: {b_cl} → {a_cl}')
        await pg.locator('[data-testid=a81-checklist]').scroll_into_view_if_needed(); await pg.screenshot(path=f'{OUT}{w}_03_checkin_auto_received.png')
        mk = pg.locator('[data-testid^=a81-mark-]'); ok(T+'manual Received override still available', await mk.count() >= 1)
        await closeall()
        # 4 · block time: range + weekdays
        await role('Practice Administrator'); await nav('sv-nav-schedule'); await pg.wait_for_timeout(600); await pg.click('[data-testid=a81-block-time]'); await pg.wait_for_selector('[data-testid=a81-block-dialog]')
        await pg.fill('[data-testid=a88-block-from]', '2026-11-02'); await pg.fill('[data-testid=a88-block-to]', '2026-11-27')
        for d in ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']:
            on = await pg.get_attribute(f'[data-testid=a88-dow-{d}]', 'aria-pressed')
            if (on == 'true') != (d in ('Tue', 'Thu')): await pg.click(f'[data-testid=a88-dow-{d}]')
        await pg.select_option('[data-testid=a84-block-room]', 'OR 3')
        pv = await pg.inner_text('[data-testid=a88-block-preview]'); ok(T+'Tue+Thu over 4 weeks = 8 dates', 'Generates 8 date' in pv, pv[:80])
        await pg.locator('[data-testid=a81-block-dialog]').screenshot(path=f'{OUT}{w}_04_block_time.png')
        await pg.click('[data-testid=a81-block-save]'); await pg.wait_for_timeout(500); s = await LS(); ok(T+'8 blocks saved + audited', s.count('2026-11-') >= 8 and 'asc81.block' in s)
        ok(T+'block cards use surgeon color', await pg.locator('[data-testid=asc-block][data-color]').count() >= 1)
        # 5 · facility logo + fee schedule
        await nav('sv-nav-forms'); await pg.wait_for_timeout(700)
        await pg.set_input_files('[data-testid=a88-logo-input]', '/tmp/a88_logo_real.png'); await pg.wait_for_timeout(400); ok(T+'logo preview', await pg.locator('[data-testid=a88-logo-preview] img').count() == 1)
        await pg.click('[data-testid=a88-fac-save]'); await pg.wait_for_timeout(300)
        fr = await pg.locator('[data-testid=a88-fee-row]').count(); await pg.click('[data-testid=a88-fee-add]'); await pg.locator('[data-testid=a88-fee-label]').last.fill('Post-op compression garment (example)'); await pg.locator('[data-testid=a88-fee-amt]').last.fill('95')
        await pg.click('[data-testid=a88-fee-save]'); await pg.wait_for_timeout(300); s = await LS(); ok(T+'fee item added + audited', fr >= 9 and 'asc88.fees' in s and 'Post-op compression garment' in s)
        await pg.evaluate("()=>{const a=document.querySelector('[data-testid=a88-facility]'),b=document.querySelector('[data-testid=a88-fees]');const w=document.createElement('div');w.id='a88shot';w.style.cssText='background:#FAF7F0;padding:12px';a.parentNode.insertBefore(w,a);w.appendChild(a);w.appendChild(b);document.querySelectorAll('body *').forEach(e=>{const p=getComputedStyle(e).position;if(p==='sticky'||p==='fixed')e.style.position='static'});}")
        await pg.locator('#a88shot').screenshot(path=f'{OUT}{w}_05_fees_logo_settings.png')
        # 5/7 · invoice from fee schedule + card popup
        await role('Front Desk Tester'); await nav('sv-nav-billing'); await pg.wait_for_timeout(500); await pg.locator('[role=tab]', has_text='Cash-pay invoices').click(); await pg.wait_for_timeout(400)
        await pg.locator('[data-testid=a87-inv-row]', has_text='Breast implant').first.locator('[data-testid=a87-inv-open]').click(); await pg.wait_for_timeout(500)
        g = pg.locator('[data-testid=a87-inv-gen]')
        if await g.count(): await g.first.click(); await pg.wait_for_timeout(400)
        it = await pg.inner_text('[data-testid=a87-inv-doc]'); ok(T+'invoice letterhead with logo + contacts', await pg.locator('[data-testid=a88-letterhead] img').count() == 1 and 'Harborview' in it and 'billing@harborview.example' in it)
        ok(T+'itemized from fee schedule (facility, anesthesia, implants)', all(k in it for k in ['Facility fee', 'Anesthesia', 'Implants']))
        await pg.screenshot(path=f'{OUT}{w}_06_invoice.png')
        await pg.click('[data-testid=a87-inv-record]'); await pg.wait_for_timeout(400); ok(T+'Collect opens card popup', await pg.locator('[data-testid=a88-cardpop]').count() == 1)
        ok(T+'simulated-gateway note', 'Simulated until payment gateway connected' in await pg.inner_text('[data-testid=a88-simnote]'))
        await pg.fill('[data-testid=a88-card-amt]', '250'); await pg.fill('[data-testid=a88-card-num]', '4242 4242 4242 4241'); await pg.fill('[data-testid=a88-card-exp]', '12/30'); await pg.fill('[data-testid=a88-card-cvv]', '123')
        await pg.click('[data-testid=a88-card-pay]'); await pg.wait_for_timeout(300); ok(T+'invalid card rejected', await pg.locator('[data-testid=a88-card-err]').count() == 1)
        await pg.fill('[data-testid=a88-card-num]', '4242 4242 4242 4242'); await pg.fill('[data-testid=a88-card-zip]', '90000'); await pg.locator('[data-testid=a88-cardpop]').screenshot(path=f'{OUT}{w}_07_card_popup.png')
        await pg.click('[data-testid=a88-card-pay]'); await pg.wait_for_timeout(600); ok(T+'receipt shown', await pg.locator('[data-testid=a88-receipt]').count() == 1)
        s = await LS(); ok(T+'no full card number stored', '4242424242424242' not in s.replace(' ', '') and '4242 4242 4242 4242' not in s)
        await pg.locator('[data-testid=a88-cardpop]').screenshot(path=f'{OUT}{w}_08_receipt.png'); await pg.click('[data-testid=a88-rc-done]')
        # check-in Collect also opens the popup
        await closeall(); await nav('sv-nav-home'); pc = pg.locator('[data-testid=a87-card]', has_text='Priya').first; await pc.locator('[data-testid=a87-checkin]').click(); await pg.wait_for_timeout(600)
        cb = pg.locator('[data-testid=a83-pay-collect]')
        if await cb.count(): await cb.first.click(); await pg.wait_for_timeout(400); ok(T+'check-in Collect → card popup', await pg.locator('[data-testid=a88-cardpop]').count() == 1)
        else: ok(T+'check-in Collect → card popup (no balance on this case)', True)
        await closeall()
        ok(T+'no page errors', not errs, '; '.join(errs[:2]))

async def main():
    for w in WIDTHS: await run(w)
    f = [r for r in res if not r[1]]; print(f'{len(res)-len(f)}/{len(res)} passed'); [print('FAIL', *r) for r in f]
asyncio.run(main())
