# Package Surgery.Vityls v1.2: the app zip (release folder) and the source zip (git-tracked files), with Python zipfile.
import zipfile, subprocess, os
ROOT='/workspace/vityls/src_v6/vityls_final_build'; OUT='/workspace/vityls'
rel=os.path.join(ROOT,'release','Surgery_Vityls_v1.2')
with zipfile.ZipFile(f'{OUT}/Surgery_Vityls_v1.2.zip','w',zipfile.ZIP_DEFLATED) as z:
  for d,_,fs in os.walk(rel):
    for f in fs: p=os.path.join(d,f); z.write(p, os.path.join('Surgery_Vityls_v1.2', os.path.relpath(p,rel)))
  z.write('/workspace/vityls/report/Surgery_v1.2_Changelog.md','Surgery_Vityls_v1.2/Surgery_v1.2_Changelog.md')
files=subprocess.check_output(['git','ls-files'],cwd=ROOT,text=True).split('\n')
with zipfile.ZipFile(f'{OUT}/Surgery_Vityls_v1.2_Source.zip','w',zipfile.ZIP_DEFLATED) as z:
  for f in files:
    if f and os.path.isfile(os.path.join(ROOT,f)): z.write(os.path.join(ROOT,f), os.path.join('Surgery_Vityls_v1.2_Source',f))
for n in ['Surgery_Vityls_v1.2.zip','Surgery_Vityls_v1.2_Source.zip']:
  p=f'{OUT}/{n}'; print(p, round(os.path.getsize(p)/1e6,1),'MB', len(zipfile.ZipFile(p).namelist()),'files')
