"""ASC.Vityls v9.1 walkthrough: full fictional episode at 1440 and 390. Fictional data; test PIN 1234."""
import asyncio, sys, os
from playwright.async_api import async_playwright
URL = sys.argv[1] if len(sys.argv) > 1 else 'http://localhost:8801/'
WIDTHS = [int(w) for w in sys.argv[2:]] or [1440, 390]
OUT = '/workspace/vityls/report/asc_v9.1_screens/best/'; os.makedirs(OUT, exist_ok=True)
CARD = '/tmp/fake_card.png'
res = []
def ok(name, cond, note=''): res.append((name, bool(cond), note)); print(('PASS' if cond else 'FAIL'), name, note, flush=True)
async def run(w):
    async with async_playwright() as p:
        b = await p.chromium.launch(executable_path='/usr/bin/google-chrome'); pg = await b.new_page(viewport={'width': w, 'height': 900 if w > 500 else 844}); pg.set_default_timeout(8000)
        errs = []; pg.on('pageerror', lambda e: errs.append(str(e))); pg.on('dialog', lambda d: asyncio.ensure_future(d.accept()))
        await pg.goto(URL + '?reset-test-data'); await pg.wait_for_timeout(2500)
        T = f'{w}:'
        async def shot(n):
            await pg.evaluate("()=>document.querySelectorAll('.a81-dbody,.a8-body').forEach(e=>e.scrollTop=0)"); await pg.screenshot(path=f'{OUT}{w}_{n}.png', full_page=True)
        async def noscroll(where):
            sw = await pg.evaluate('()=>document.documentElement.scrollWidth - window.innerWidth'); ok(T+f'no sideways scroll · {where}', sw <= 1, f'+{sw}px')
        async def role(label):
            s = pg.locator('select').first; opts = await s.evaluate("s=>[...s.options].map(o=>o.text)"); await s.select_option(label=[o for o in opts if label in o][0]); await pg.wait_for_timeout(600)
        async def nav(tid):
            await pg.locator(f'[data-testid={tid}]').first.evaluate('e=>e.click()'); await pg.wait_for_timeout(700)
        async def draw(sel):
            c = pg.locator(sel).first; await c.scroll_into_view_if_needed(); bb = await c.bounding_box()
            x, y = bb['x'] + 20, bb['y'] + bb['height'] / 2
            await pg.mouse.move(x, y); await pg.mouse.down()
            for i in range(1, 12): await pg.mouse.move(x + i * 14, y + (12 if i % 2 else -12))
            await pg.mouse.up(); await pg.wait_for_timeout(150)
        async def sign(who=None):
            await pg.wait_for_selector('[data-testid=pin-sign]')
            if who:
                opts = await pg.eval_on_selector('[data-testid=pin-who]', "s=>[...s.options].map(o=>o.text)"); await pg.select_option('[data-testid=pin-who]', label=[o for o in opts if who in o][0])
            else:
                v = await pg.eval_on_selector('[data-testid=pin-who]', 'e=>e.value')
                if not v: await pg.select_option('[data-testid=pin-who]', index=1)
            await draw('[data-testid=pin-sigpad-canvas]')
            await pg.fill('[data-testid=pin-input]', '1234'); await pg.click('[data-testid=pin-confirm]'); await pg.wait_for_timeout(500)
        async def bench(chip, patient=None):
            if await pg.locator('[data-testid=a81-close]').count(): await pg.click('[data-testid=a81-close]')
            await nav('sv-nav-home'); a = pg.locator('[data-testid=a81-chip-all]')
            if await pg.locator(f'[data-testid=a81-chip-{chip}]').count() == 0 and await a.count(): await a.click()
            await pg.click(f'[data-testid=a81-chip-{chip}]'); await pg.wait_for_selector(f'[data-testid=a81-bench-{chip}]')
            if patient:
                opts = await pg.eval_on_selector('[data-testid=a81-case-pick]', "s=>[...s.options].map(o=>o.text)"); await pg.select_option('[data-testid=a81-case-pick]', label=[o for o in opts if patient in o][0]); await pg.wait_for_timeout(300)
        async def fillsel(tid):
            v = await pg.eval_on_selector(f'[data-testid={tid}]', 'e=>e.value')
            if not v: await pg.select_option(f'[data-testid={tid}]', index=1)
        async def close_forms():
            for _ in range(3):
                x = pg.locator('.a82-form [aria-label="Close form"]')
                if await pg.locator('.a82-form').count() and await x.count(): await x.first.click(); await pg.wait_for_timeout(400)
        await pg.evaluate("()=>{window.print=()=>{window.__printed=(window.__printed||0)+1}}")
        LS = lambda: pg.evaluate("()=>JSON.stringify(Object.values(localStorage))")
        async def closeall():
            for _ in range(4):
                x = pg.locator('[data-testid=a88-card-close],[data-testid=a81-close],[data-testid=a8-close],[aria-label="Close"]')
                if await x.count():
                    try: await x.first.click(timeout=1500)
                    except Exception: pass
                    await pg.wait_for_timeout(250)
                else: break
        BS = "()=>{const k=Object.keys(localStorage).find(k=>k.endsWith('block-seed'));return k?JSON.parse(localStorage.getItem(k)):[]}"
        AUD = "()=>Object.keys(localStorage).filter(k=>/audit/i.test(k)).map(k=>localStorage.getItem(k)).join(' ')"
        async def blk(room):
            await pg.locator(f'[data-testid=asc-block][data-room="{room}"]').first.evaluate('e=>e.click()'); await pg.wait_for_selector('[data-testid=b91-pop]')
        async def unlock():
            await pg.wait_for_timeout(500)
            if await pg.locator('[data-testid=practice-unlock]').count() and await pg.locator('[data-testid=practice-unlock]').first.is_visible(): await pg.click('[data-testid=practice-unlock]'); await pg.wait_for_timeout(400)
            if await pg.locator('[data-testid=pin-sign]').count(): await sign('Practice Administrator')
            elif await pg.locator('input[type=password]').count(): await pg.locator('input[type=password]').last.fill('1234'); await pg.get_by_role('button', name='Unlock').click()
            await pg.wait_for_timeout(600)
        await role('Practice Administrator')
        # ---- block time in room columns
        await nav('sv-nav-schedule'); await pg.get_by_role('button', name='Rooms', exact=True).first.click(); await pg.wait_for_timeout(600)
        rooms = await pg.locator('[data-testid=asc-block]').evaluate_all('l=>l.map(e=>e.dataset.room)')
        ok(T+'blocks render in OR room columns', 'OR 1' in rooms and 'OR 2' in rooms, str(rooms)); await noscroll('schedule rooms'); await shot('01_blocks_rooms')
        T0 = await pg.evaluate("()=>{const d=new Date();return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0')}")
        await pg.evaluate("""(t)=>{const k=Object.keys(localStorage).find(k=>k.endsWith('block-seed'));const l=JSON.parse(localStorage.getItem(k));const d=n=>{const x=new Date(t+'T12:00');x.setDate(x.getDate()+n);return x.getFullYear()+'-'+String(x.getMonth()+1).padStart(2,'0')+'-'+String(x.getDate()).padStart(2,'0')};
          [0,7,14].forEach((n,i)=>l.push({id:'wser-'+i,surgeon:'Dana Whitfield, MD',date:d(n),start:'10:00 AM',end:'02:00 PM',room:'OR 3',series:'walk-ser'}));localStorage.setItem(k,JSON.stringify(l))}""", T0)
        await nav('sv-nav-home'); await nav('sv-nav-schedule'); await pg.get_by_role('button', name='Rooms', exact=True).first.click(); await pg.wait_for_timeout(600)
        await blk('OR 3'); await shot('02_block_popup')
        ok(T+'popup offers this block / series', await pg.locator('[data-testid=b91-edit-one]').count() and await pg.locator('[data-testid=b91-edit-series]').count())
        # edit series (notes) with confirm
        await pg.click('[data-testid=b91-edit-series]'); await pg.fill('[data-testid=b91-notes]', 'Hand block (series)'); await pg.click('[data-testid=b91-save]')
        ok(T+'series edit asks to confirm', await pg.locator('[data-testid=b91-save-confirm]').count()); await pg.click('[data-testid=b91-save-yes]'); await pg.wait_for_timeout(500)
        l = await pg.evaluate(BS); ser = [b for b in l if b.get('room') == 'OR 3']
        ok(T+'whole series edited', len(ser) == 3 and all(b.get('notes') == 'Hand block (series)' for b in ser), str(len(ser)))
        # edit this block only -> detached
        await blk('OR 3'); await pg.click('[data-testid=b91-edit-one]'); await pg.fill('[data-testid=b91-end]', '15:00'); await pg.click('[data-testid=b91-save]'); await shot('03_block_edit_confirm'); await pg.click('[data-testid=b91-save-yes]'); await pg.wait_for_timeout(500)
        l = await pg.evaluate(BS); one = [b for b in l if b.get('room') == 'OR 3' and b['date'] == T0]; rest = [b for b in l if b.get('room') == 'OR 3' and b['date'] != T0]
        ok(T+'edit this block only detaches it', one and one[0]['end'] == '03:00 PM' and one[0]['series'].startswith('solo-') and len(rest) == 2 and all(b['end'] == '02:00 PM' and b['series'] != one[0]['series'] for b in rest), str(one))
        # book patient into Patel OR 1 block (7:00-1:00) for 2 h -> trimmed to 9:00-1:00
        await blk('OR 1'); await pg.click('[data-testid=b91-book]'); await pg.wait_for_selector('[data-testid=a83-book-name]')
        sur = await pg.eval_on_selector('[data-testid=a83-book-surgeon]', 'e=>e.value'); rm = await pg.eval_on_selector('[data-testid=a83-book-room]', 'e=>e.value'); tm = await pg.eval_on_selector('[data-testid=a83-book-time]', 'e=>e.value')
        ok(T+'appointment prefilled from block', 'Patel' in sur and rm == 'OR 1' and '7:00' in tm, f'{sur}|{rm}|{tm}')
        await pg.fill('[data-testid=a83-book-name]', f'Vera Lowe{w}'); await pg.fill('[data-testid=a83-book-dob]', '04/02/1971')
        await pg.fill('[data-testid=a83-book-proc]', 'Carpal tunnel release'); await pg.select_option('[data-testid=a83-book-len]', '120') if await pg.eval_on_selector('[data-testid=a83-book-len]', 'e=>e.tagName') == 'SELECT' else await pg.fill('[data-testid=a83-book-len]', '120')
        await fillsel('a83-book-anes'); await fillsel('a83-book-pay'); await shot('04_book_in_block')
        await pg.click('[data-testid=a83-book-save]'); await pg.wait_for_timeout(700)
        if await pg.locator('[data-testid=a83-book-save]').count(): await pg.click('[data-testid=a83-book-save]'); await pg.wait_for_timeout(700)
        l = await pg.evaluate(BS); p1 = [b for b in l if b.get('room') == 'OR 1']
        ok(T+'booking trims the block (7-9 booked → 9:00-1:00 left)', len(p1) == 1 and p1[0]['start'] == '09:00 AM' and p1[0]['end'] == '01:00 PM', str(p1))
        au = await pg.evaluate(AUD); ok(T+'block edits/booking audited', all(x in au for x in ['Block edited (whole series)', 'detached from series', 'replaced by case']))
        # delete this block only (OR 2) with confirm
        await blk('OR 2'); await pg.click('[data-testid=b91-del]'); ok(T+'delete asks to confirm', await pg.locator('[data-testid=b91-del-confirm]').count()); await shot('05_block_delete'); await pg.click('[data-testid=b91-del-one]'); await pg.wait_for_timeout(400)
        ok(T+'delete this block only', not [b for b in await pg.evaluate(BS) if b.get('room') == 'OR 2'])
        # delete whole series: go to next week
        n7 = await pg.evaluate("(t)=>{const x=new Date(t+'T12:00');x.setDate(x.getDate()+7);return x.getFullYear()+'-'+String(x.getMonth()+1).padStart(2,'0')+'-'+String(x.getDate()).padStart(2,'0')}", T0); await pg.locator('input[type=date]').first.fill(n7)
        await pg.wait_for_timeout(500); await blk('OR 3'); await pg.click('[data-testid=b91-del]'); await pg.click('[data-testid=b91-del-series]'); await pg.wait_for_timeout(400)
        l = await pg.evaluate(BS); ok(T+'delete whole series (detached block kept)', len([b for b in l if b.get('room') == 'OR 3']) == 1, str([b['date'] for b in l if b.get('room') == 'OR 3']))
        ok(T+'deletes audited', 'this block only' in await pg.evaluate(AUD) and 'whole series' in await pg.evaluate(AUD))
        # ---- Practice Intelligence
        ok(T+'admin sees Practice Intelligence in nav', await pg.locator('[data-testid=sv-nav-intel]').count())
        await nav('sv-nav-intel'); await pg.wait_for_selector('[data-testid=i91-page]')
        ok(T+'intel: eval, KPIs, 8 reports, flow', await pg.locator('[data-testid=i91-insight]').count() == 4 and await pg.locator('[data-testid=i91-report]').count() == 8 and await pg.locator('[data-testid=i91-flow-row]').count() > 0)
        await pg.fill('[data-testid=i91-ask]', 'cancellation reasons'); await pg.click('[data-testid=i91-ask-go]'); ok(T+'intel ask answers', await pg.locator('[data-testid=i91-answer]').count())
        await pg.locator('[data-testid=i91-report]').first.click(); ok(T+'report opens', await pg.locator('[data-testid=i91-report-view]').count()); await noscroll('intel'); await shot('06_practice_intelligence')
        await role('Rhea Castillo'); await pg.wait_for_timeout(400); ok(T+'Medical Director sees nav + page', await pg.locator('[data-testid=sv-nav-intel]').count() and await pg.locator('[data-testid=i91-page]').count())
        await role('Front Desk Tester'); await pg.wait_for_timeout(400)
        ok(T+'front desk: no nav item', await pg.locator('[data-testid=sv-nav-intel]').count() == 0)
        ok(T+'front desk: no-access if reached', await pg.locator('[data-testid=i91-noaccess]').count() > 0 or await pg.locator('[data-testid=i91-page]').count() == 0)
        if await pg.locator('[data-testid=i91-noaccess]').count(): await shot('07_intel_noaccess')
        # ---- Billing: fee link + Ada Kerr totals
        await role('Practice Administrator'); P = lambda tid: pg.locator(f'[data-testid={tid}]')
        await nav('sv-nav-patients'); await pg.wait_for_timeout(600); await pg.get_by_text('Ada Kerr', exact=True).first.click(); await pg.wait_for_timeout(800)
        await P('a89-btn-collect').first.click(); await pg.wait_for_timeout(400);  await pg.fill('[data-testid=a89-credit-amt]', '300'); await fillsel('a89-credit-type'); mo = await pg.eval_on_selector('[data-testid=a89-credit-method]', "s=>[...s.options].map(o=>o.text)"); await pg.select_option('[data-testid=a89-credit-method]', label=[o for o in mo if 'ash' in o][0]); await P('a89-credit-save').click(); await pg.wait_for_timeout(500); cr = await pg.evaluate("()=>Object.keys(localStorage).filter(k=>/credit/i.test(k)).map(k=>k+localStorage.getItem(k)).join()");  await closeall()
        await P('a83-chart-tab-billing').click(); await pg.wait_for_timeout(400); await P('a87-chart-invoice').first.click(); await pg.wait_for_timeout(500)
        if await P('a87-inv-gen').count(): await P('a87-inv-gen').first.click(); await pg.wait_for_timeout(500)
        it = await P('a87-inv-doc').inner_text() if await P('a87-inv-doc').count() else ''; print('INV', ' '.join(it.split())[600:1600])
        jt=' '.join(it.split()); ok(T+'Ada Kerr invoice $1,800 total, $1,500 balance after $300 credit', 'Total $1,800.00' in jt and 'Balance due $1,500.00' in jt); ok(T+'$300 credit recorded', '300' in (cr or ''), (cr or '')[:80])
        await shot('11_invoice_ada')
        await closeall()
        await nav('sv-nav-billing'); fs = pg.locator('button:has-text("Fee schedules")')
        if await fs.count(): await fs.first.click(); await pg.wait_for_timeout(300)
        ok(T+'Billing & Payments: fee schedules tab links to settings', await pg.locator('[data-testid=fees-link]').count() and await pg.locator('[data-testid=a89-fees],[data-testid=fee89]').count() == 0)
        # ---- Practice: settings moves
        await nav('sv-nav-forms'); await unlock(); await shot('08_practice')
        ok(T+'Practice main has no facility/fees/orders', await pg.locator('[data-testid=a8-fees],[data-testid=a87-standing],[data-testid=fee89],[data-testid=a88-facility]').count() == 0)
        await pg.click('[data-testid=prac-billing-settings]'); await pg.wait_for_timeout(600)
        bt = await pg.inner_text('body'); ok(T+'Billing settings: config + unified fee schedule, no old tables', await pg.locator('[data-testid=billing-fee-schedule]').count() and await pg.locator('[data-testid=billing-live-fees]').count() == 0 and 'ASC facility fee schedule' not in bt); await shot('09_billing_settings')
        await nav('sv-nav-forms'); await pg.click('[data-testid=prac-profile]'); await pg.wait_for_timeout(500); ok(T+'Facility profile in Practice profile', 'Facility profile' in await pg.inner_text('body'))
        await nav('sv-nav-forms'); await pg.click('[data-testid=prac-med-settings]'); await pg.wait_for_timeout(500)
        ok(T+'Surgery settings holds doctor orders', await pg.locator('[data-testid=surgery-settings-orders]').count() and 'Surgery settings' in await pg.inner_text('[data-testid=settings-title]'))
        await nav('sv-nav-forms'); await pg.click('[data-testid=prac-surgery-settings]'); await pg.wait_for_timeout(500)
        n0 = await pg.locator('[data-testid=res-row]').count(); await pg.locator('[data-testid=res-trash]').last.click(); ok(T+'column delete confirms', await pg.locator('[data-testid=res-confirm]').count())
        await shot('10_columns_trash'); await pg.click('[data-testid=res-confirm-del]'); await pg.wait_for_timeout(300); ok(T+'column deleted', await pg.locator('[data-testid=res-row]').count() == n0 - 1)
        ok(T+'no page errors', not errs, '; '.join(errs[:3]))
        await b.close()
async def main():
    for w in WIDTHS: await run(w)
    f = [r for r in res if not r[1]]; print(f'{len(res)-len(f)}/{len(res)} passed')
asyncio.run(main())
