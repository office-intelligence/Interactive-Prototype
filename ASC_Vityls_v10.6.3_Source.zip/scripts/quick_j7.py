import asyncio,sys
from playwright.async_api import async_playwright
URL='file:///workspace/vityls/src_v6/vityls_final_build/release/Surgery_Vityls_v1.2/index.html'
OUT='/workspace/vityls/report/surgery_v1.2_screens'
async def main():
  async with async_playwright() as p:
    b=await p.chromium.launch(executable_path='/usr/bin/google-chrome'); pg=await b.new_page(viewport={'width':1440,'height':1000}); errs=[]
    pg.on('pageerror',lambda e:errs.append(str(e))); pg.on('console',lambda m: errs.append(m.text) if m.type=='error' else None)
    await pg.goto(URL+'?reset-test-data'); await pg.wait_for_timeout(2500)
    nav=pg.locator('[data-testid=sv-nav-surgeries]')
    if not await nav.is_visible(): await pg.click('[data-testid=fd-hamburger]')
    await nav.click(); await pg.wait_for_timeout(600)
    await pg.click('[data-testid=ep-owner-all]'); await pg.click('[data-testid=ep-view-list]')
    await pg.locator('[data-testid=ep-row]', has_text='Mary James').first.click(); await pg.wait_for_timeout(800)
    print('journey', await pg.locator('[data-testid=journey-page]').count(), await pg.locator('[data-testid=journey-page]').get_attribute('data-step') if await pg.locator('[data-testid=journey-page]').count() else None)
    for t in ['jy-status','jy-handoff','jy-checklist','jy-asc']:
      l=pg.locator(f'[data-testid={t}]'); print(t, (await l.inner_text())[:500].replace('\n',' | ') if await l.count() else 'MISSING')
    print('items', await pg.locator('[data-testid^=jy-item-]').evaluate_all('es=>es.map(e=>e.dataset.key)'))
    print('confirm', await pg.locator('[data-testid=jy-confirm]').count())
    await pg.screenshot(path=f'{OUT}/quick_1440_step7.png', full_page=True)
    print('errors', errs[:5])
    await b.close()
asyncio.run(main())
