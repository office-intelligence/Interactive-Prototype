"""ASC.Vityls v10 walkthrough on the CLEAN build: one fictional patient end to end. Test PIN 1234. Fictional data only."""
import asyncio, sys, os, json
from playwright.async_api import async_playwright
URL = sys.argv[1] if len(sys.argv) > 1 else 'http://localhost:8810/'
OUT = os.environ.get('SHOTS', '/workspace/vityls/asc10_shots/'); os.makedirs(OUT, exist_ok=True)
res = []
def ok(n, c, note=''): res.append((n, bool(c))); print('PASS' if c else 'FAIL', n, note, flush=True)
SEED = ['Ada Kerr','Celia Ortega','Desmond Akers','Ellen Testwood','Grace Placeholder','Hugo Pell','Iris Navarro','Jonah Reyes','Maren Holt','Marisol Sampleton','Owen Marsh','Priya Demoshah','Priya Lund','Robert Fictus','Talia Wren','Tomas Exampleton','Sam Patel','Dana Whitfield']
async def main():
  async with async_playwright() as p:
    b = await p.chromium.launch(executable_path='/usr/bin/google-chrome'); pg = await b.new_page(viewport={'width': 1440, 'height': 900}); pg.set_default_timeout(6000)
    errs = []; pg.on('pageerror', lambda e: errs.append(str(e))); pg.on('dialog', lambda d: asyncio.ensure_future(d.accept()))
    await pg.goto(URL + '?reset-test-data'); await pg.wait_for_timeout(2500)
    n = [0]
    async def shot(name):
      n[0] += 1; await pg.wait_for_timeout(300); await pg.screenshot(path=f'{OUT}{n[0]:02d}_{name}.png')
    async def step(name, fn):
      try: await fn(); ok(name, True)
      except Exception as e: ok(name, False, str(e).split('\n')[0][:160])
    async def nav(tid): await pg.locator(f'[data-testid={tid}]').first.evaluate('e=>e.click()'); await pg.wait_for_timeout(700)
    async def draw(sel):
      c = pg.locator(sel).first; await c.scroll_into_view_if_needed(); bb = await c.bounding_box(); x, y = bb['x']+20, bb['y']+bb['height']/2
      await pg.mouse.move(x, y); await pg.mouse.down()
      for i in range(1, 12): await pg.mouse.move(x+i*14, y+(12 if i % 2 else -12))
      await pg.mouse.up()
    async def sign(who=None):
      await pg.wait_for_selector('[data-testid=pin-sign]')
      opts = await pg.eval_on_selector('[data-testid=pin-who]', "s=>[...s.options].map(o=>o.text)")
      pick = [o for o in opts if who and who in o] or [o for o in opts if o and not o.startswith('Choose')]
      await pg.select_option('[data-testid=pin-who]', label=pick[0])
      if await pg.locator('[data-testid=pin-sigpad-canvas]').count(): await draw('[data-testid=pin-sigpad-canvas]')
      await pg.fill('[data-testid=pin-input]', '1234'); await pg.click('[data-testid=pin-confirm]'); await pg.wait_for_timeout(600)
    async def closeall():
      for _ in range(4):
        x = pg.locator('[data-testid=a81-close],[data-testid=a83-booking-close],[data-testid=a8-close]')
        if await x.count():
          try: await x.first.click(timeout=1500)
          except Exception: pass
          await pg.wait_for_timeout(300)
    async def bench(name):
      await closeall(); await pg.evaluate("([b,c])=>window.dispatchEvent(new CustomEvent('asc81-bench',{detail:{bench:b,cid:c}}))", [name, CID[0]]); await pg.wait_for_selector(f'[data-testid=a81-bench-{name}]')
    LS = lambda: pg.evaluate("()=>JSON.stringify(Object.values(localStorage))")
    # 0 clean start
    await shot('today_empty')
    ls = await LS(); ok('clean build: zero seed patients in storage', not [s for s in SEED if s in ls], str([s for s in SEED if s in ls]))
    ok('clean build: no patient cases', '"ASC-2' not in ls)
    body = await pg.inner_text('body'); ok('no "simulated" wording on Today', 'imulat' not in body)
    for t in ['sv-nav-patients', 'sv-nav-messages', 'sv-nav-billing', 'sv-nav-schedule']:
      await nav(t); await shot('empty_' + t.split('-')[-1]); ok(f'{t}: no simulated wording', 'imulat' not in await pg.inner_text('body'))
    # 1 booking
    CID = ['']
    async def book():
      await pg.click('[data-testid=add-visit]'); await pg.wait_for_selector('[data-testid=a83-book-name]')
      await pg.fill('[data-testid=a83-book-name]', 'Jordan Example'); await pg.fill('[data-testid=a83-book-dob]', '03/14/1980')
      ph = pg.locator('[data-testid=a83-booking] input[type=tel], [data-testid=a83-booking] input[placeholder*="555"], [data-testid=a83-booking] input[placeholder*="000"]').first
      await ph.click(); await pg.keyboard.type('31055512'); await pg.keyboard.press('Tab'); await pg.wait_for_timeout(300); await shot('booking_phone_incomplete_warning')
      ok('phone soft warning when incomplete', await pg.locator('.v10-phone-warn').count() > 0)
      await ph.fill(''); await ph.click(); await pg.keyboard.type('3105551234'); await pg.keyboard.press('Tab')
      ok('phone formats (310) 555-1234', await ph.input_value() == '(310) 555-1234', await ph.input_value())
      await pg.fill('[data-testid=a83-book-proc]', 'Carpal tunnel release, right')
      for t in ['a83-book-anes', 'a83-book-pay']: await pg.select_option(f'[data-testid={t}]', index=1)
      await shot('booking_filled'); await pg.click('[data-testid=a83-book-save]'); await pg.wait_for_timeout(900)
      if await pg.locator('[data-testid=a83-book-save]').count(): await pg.click('[data-testid=a83-book-save]'); await pg.wait_for_timeout(900)
      CID[0] = await pg.evaluate("()=>{for(const k of Object.keys(localStorage)){if(!/asc8-cases$/.test(k))continue;const l=JSON.parse(localStorage.getItem(k));const c=l.find(x=>x.procedure&&x.procedure.includes('Carpal'));if(c)return c.id}return ''}")
      assert CID[0], 'case not created'
      await shot('schedule_booked')
    await step('book fictional patient from schedule', book)
    if not CID[0]: print('no case; stop'); await b.close(); return
    # 2 check-in via Today card + arrival bench (same slide-over)
    async def checkin():
      await bench('arrival'); await shot('frontdesk_documents_present')
      ok('front desk: documents present check', await pg.locator('[data-testid=v10-frontdocs]').count())
      ok('Today pill on bench', await pg.locator('[data-testid=v10-today-pill]').count())
      await pg.locator('[data-testid^=v10-doc-mark-]').first.click()
      await pg.click('[data-testid=a83-ci-go]'); await pg.wait_for_timeout(800); await shot('checked_in')
    await step('check-in (never held, exceptions allowed)', checkin)
    async def verify():
      await bench('verify'); await shot('verify_history_ai_draft')
      ok('journey bar shows Verify medical history', 'Verify medical history' in await pg.inner_text('[data-testid=a81-bench-verify]'))
      ok('no Pre-op/Registration step on journey', 'Registration' not in await pg.inner_text('[data-testid=a81-bench-verify]'))
      ok('AI draft label', await pg.locator('[data-testid=v10-hx-ai]').count())
      f = pg.locator('[data-testid=v10-hx-allergies], [data-testid=v10-hx-allergy]')
      if await f.count(): await f.first.fill('NKDA')
      await pg.click('[data-testid=v10-hx-confirm]'); await sign(); await shot('verify_history_confirmed')
      ok('official history recorded', await pg.locator('[data-testid=v10-hx-official]').count() or 'historyVerified' in await LS())
    await step('verify medical history (nurse PIN once)', verify)
    async def nursing():
      await bench('nursing'); await shot('nursing_admission')
      ok('nursing shows official history', await pg.locator('[data-testid=v10-official]').count())
      ok('standing pre-op list (or empty state)', await pg.locator('[data-testid=v10-list-pre],[data-testid=v10-list-empty-pre]').count())
    await step('nursing admission', nursing)
    async def bankchk():
      await bench('nursing'); await pg.evaluate("()=>{window.open=()=>{const d=document.implementation.createHTMLDocument('x');return {document:d,print(){window.__printed=(window.__printed||0)+1;window.__exportText=d.body.textContent}}}}")
      b0 = pg.locator('[data-testid=v10-bank]'); ok('question bank section on nursing', await b0.count())
      n0 = int(await b0.get_attribute('data-open')); await pg.click('[data-testid=v10-bank-toggle]'); await shot('bank_nursing_unanswered')
      ok('bank groups fields by template', await pg.locator('[data-testid=v10-bank-tpl]').count() > 0)
      q = pg.locator('[data-testid=v10-bank-q] select').first; await q.select_option(index=1); await pg.wait_for_timeout(400)
      n1 = int(await pg.locator('[data-testid=v10-bank]').get_attribute('data-open')); ok('answering removes the field (answered once)', n1 == n0 - 1, f'{n0}->{n1}')
      ok('no PDF made automatically', not await pg.evaluate('()=>window.__printed||0'))
      await pg.locator('[data-testid=v10-bank-export]').first.click(); await pg.wait_for_timeout(300)
      ok('Export / Print renders the template from answers', await pg.evaluate('()=>window.__printed||0') == 1 and 'Jordan Example' in (await pg.evaluate('()=>window.__exportText||""')))
      await bench('arrival'); await pg.click('[data-testid=v10-bank-toggle]'); ok('name already known is not asked again at front desk', await pg.locator('[data-testid=v10-bank-q][data-qid=SH-01]').count() == 0)
    await step('question bank on stations', bankchk)
    async def anes():
      await bench('anesthesia'); await shot('anesthesia_station')
      t = await pg.inner_text('[data-testid=a81-bench-anesthesia]'); ok('no ASA I suggestion with 0 records', 'ASA I ' not in t and 'suggests ASA' not in t)
    await step('anesthesia station', anes)
    async def surg():
      await bench('surgeon'); await shot('surgeon_station')
      ok('surgeon Today pill', await pg.locator('[data-testid=v10-today-pill]').count())
      ok('surgeon: no consent / H&P form links', await pg.locator('[data-testid=a83-open-consent],[data-testid=a83-open-hp],[data-testid=a82-consent-form]').count() == 0)
      ok('surgeon: brief consent note + upload + e-sign kept', await pg.locator('[data-testid=v10-consent-note]').count() and await pg.locator('[data-testid=v10-paper-consent]').count() and await pg.locator('[data-testid=a82-consent-open]').count())
      ok('brief OP report + formal pending', await pg.locator('[data-testid=v10-briefop]').count() and await pg.locator('[data-testid=v10-formal-op-pending]').count())
      for k in ['procedure', 'findings']:
        x = pg.locator(f'[data-testid=v10-bo-{k}]')
        if await x.count(): await x.fill('Right carpal tunnel release, uneventful' if k == 'procedure' else 'Thickened transverse carpal ligament')
      if await pg.locator('[data-testid=v10-bo-save]').count(): await pg.click('[data-testid=v10-bo-save]')
      await pg.click('[data-testid=v10-bo-sign]'); await sign('Test Surgeon'); await shot('brief_op_signed')
      ok('brief op signed by surgeon', await pg.locator('[data-testid=v10-briefop-signed]').count())
    await step('surgeon: brief OP report signed', surg)
    async def pacu():
      await bench('pacu'); await shot('pacu')
      ok('no false PACU-orders warning text', await pg.locator('[data-testid=v10-pacu-orders-warn],[data-testid=v10-pacu-orders-ok]').count() <= 1)
    await step('PACU', pacu)
    async def dc():
      await bench('discharge'); await shot('discharge')
      ok('Rx line', 'To be done by the operating surgeon' in await pg.inner_text('[data-testid=a81-bench-discharge]'))
      ok('ibuprofen not hard-coded', 'buprofen' not in await pg.inner_text('[data-testid=a81-bench-discharge]'))
      ok('follow-up text and call optional', await pg.locator('[data-testid=v10-follow-text]').count() and await pg.locator('[data-testid=v10-follow-call]').count())
    await step('discharge', dc)
    async def clos():
      await bench('closure'); await shot('closure')
      t = await pg.inner_text('[data-testid=a81-bench-closure]'); ok('closure separates brief vs formal op report', 'Brief' in t or 'brief' in t)
    await step('closure', clos)
    await closeall(); await nav('sv-nav-home'); await shot('today_after')
    ls = await LS(); ok('end: still zero seed names', not [s for s in SEED if s in ls])
    ok('no page errors', not errs, '; '.join(errs[:3]))
    await b.close()
  f = [r for r in res if not r[1]]; print(f'{len(res)-len(f)}/{len(res)} passed')
asyncio.run(main())
