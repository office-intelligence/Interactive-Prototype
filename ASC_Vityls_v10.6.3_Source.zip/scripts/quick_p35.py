import asyncio
from playwright.async_api import async_playwright
URL='file:///workspace/vityls/src_v6/vityls_final_build/release/Surgery_Vityls_v1.2/index.html'
OUT='/workspace/vityls/report/surgery_v1.2_screens'
async def main():
  async with async_playwright() as p:
    b=await p.chromium.launch(executable_path='/usr/bin/google-chrome'); pg=await b.new_page(viewport={'width':1440,'height':1000}); errs=[]
    pg.on('pageerror',lambda e:errs.append(str(e)))
    await pg.goto(URL+'?reset-test-data'); await pg.wait_for_timeout(2500)
    nav=pg.locator('[data-testid=sv-nav-home]')
    if await nav.count() and not await nav.is_visible(): await pg.click('[data-testid=fd-hamburger]')
    if await nav.count(): await nav.click(); await pg.wait_for_timeout(800)
    print('queue', await pg.locator('[data-testid=jy-queue]').count(), await pg.locator('[data-testid=jy-queue-row]').count())
    if await pg.locator('[data-testid=jy-queue]').count(): print((await pg.inner_text('[data-testid=jy-queue]'))[:300].replace('\n',' | '))
    await pg.screenshot(path=f'{OUT}/quick_1440_today_queue.png')
    # Carol step 11 confirmations
    await pg.locator('[data-testid=jy-queue-all]').click() if await pg.locator('[data-testid=jy-queue-all]').count() else None
    await pg.wait_for_timeout(300)
    nv=pg.locator('[data-testid=sv-nav-patients]')
    if not await nv.is_visible(): await pg.click('[data-testid=fd-hamburger]')
    await nv.click(); await pg.wait_for_timeout(600)
    row=pg.locator('[data-testid=sv-patient-list] tbody tr', has_text='Carol Bennett')
    print('carol rows', await row.count())
    if await row.count():
      await row.first.locator('button').first.click(); await pg.wait_for_timeout(800)
      print('step', await pg.get_attribute('[data-testid=journey-page]','data-step'), 'confirm groups', await pg.locator('[data-testid^=jy-cg-ok-]').count())
      await pg.screenshot(path=f'{OUT}/quick_1440_step11_confirm.png', full_page=True)
      if await pg.locator('[data-testid^=jy-cg-ok-]').count():
        n0=await pg.locator('[data-testid^=jy-cg-ok-]').count(); await pg.locator('[data-testid^=jy-cg-ok-]').first.click(); await pg.wait_for_timeout(400)
        print('after one tap', n0, '->', await pg.locator('[data-testid^=jy-cg-ok-]').count())
      await pg.click('[data-testid=jy-chart]'); await pg.wait_for_timeout(800)
      print('chart journey link', await pg.locator('[data-testid=chart-journey]').count())
      await pg.click('[data-testid=chart-tab-activity]'); await pg.wait_for_timeout(500)
      print('timeline items', await pg.locator('[data-testid=timeline-item]').count(), 'filters', await pg.locator('[data-testid^=tl-f-]').count())
      print((await pg.inner_text('[data-testid=chart-timeline]'))[:400].replace('\n',' | '))
      await pg.click('[data-testid=tl-f-labs]'); await pg.wait_for_timeout(200); print('labs only', await pg.locator('[data-testid=timeline-item]').count())
      await pg.screenshot(path=f'{OUT}/quick_1440_chart_timeline.png', full_page=True)
    print('errors', errs[:5]); await b.close()
asyncio.run(main())
