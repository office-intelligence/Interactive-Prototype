# ASC.Vityls v8.0 · feature-map check: every row of report/ASC_on_Surgery_Plan.md §1 must have code evidence in the ASC edition.
import re, pathlib, sys, json
ROOT=pathlib.Path(__file__).resolve().parent.parent; SRC=ROOT/'src'
PLAN=pathlib.Path('/workspace/vityls/report/ASC_on_Surgery_Plan.md').read_text()
rows=[l for l in PLAN.split('## 2.')[0].splitlines() if l.startswith('| ') and not l.startswith('| ASC v7.5') and not l.startswith('|---')]
def has(f,pat): t=(SRC/f).read_text(); return re.search(pat,t) is not None
E={ # row keyword → list of (file, regex) that must all match; or ('drop',reason)
 'Day-of-surgery dark header':[('surgery/SurgeryApp.tsx','acting-as')],
 '8 station tabs':[('surgery/asc8/logic.ts','export const STEPS'),('surgery/asc8/today.tsx','a8-station-view')],
 'Patient Portal station':[('surgery/asc8/logic.ts',"step: 'preadmit'")],
 'Front Office station':[('surgery/asc8/logic.ts',"step: 'checkin'")],
 'Pre-op Nursing station':[('surgery/asc8/logic.ts',"station: 'preop'")],
 'Anesthesia station':[('surgery/asc8/logic.ts',"station: 'anesthesia'")],
 'Surgeon/Physician station':[('surgery/asc8/ui.tsx','SurgeonTab'),('surgery/asc8/ui.tsx','a8-surgeon-rail')],
 'OR Team station':[('surgery/asc8/logic.ts',"station: 'or'")],
 'PACU/Discharge station':[('surgery/asc8/logic.ts',"station: 'pacu'")],
 'Case Record station':[('surgery/asc8/ui.tsx','a8-record-print'),('surgery/asc8/ui.tsx','a8-record-audit')],
 '"Reviewed this station"':[('surgery/asc8/ui.tsx','Save &amp; close'),('surgery/asc8/logic.ts','export function autoLoc')],
 'Test-build note':[('surgery/SurgeryApp.tsx','SIMULATION|sim-badge|Simulation')],
 'Operations·Billing strip':[('surgery/asc8/ui.tsx','a8-stage')],
 '"Forms for this case"':[('surgery/asc8/ui.tsx','Forms for this station')],
 '"Known clinical facts"':[('surgery/asc8/logic.ts','export function headerFacts')],
 'Forms engine':[('surgery/asc8/forms.ts','formLibHooks.original')],
 'Form signers and PIN':[('surgery/asc8/ui.tsx','PinSign')],
 'Addenda':[('med/record.ts','(?i)addend')],
 'Allergy green/red':[('surgery/asc8/ui.tsx','a8-allergy-confirm'),('surgery/asc8/ui.tsx','a8-allergy-edit')],
 'NPO status':[('surgery/asc8/ui.tsx','a8-f-npo-solids')],
 'ASA class':[('surgery/asc8/ui.tsx',"case 'asa'")],
 'Airway, anesthesia plan':[('surgery/asc8/ui.tsx',"case 'airway'"),('surgery/asc8/ui.tsx',"case 'plan'")],
 'OR event times':[('surgery/asc8/logic.ts','Enter a reason to change'),('surgery/asc8/ui.tsx','a8-ev-audit')],
 'EBL, wound class':[('surgery/asc8/ui.tsx',"case 'ebl'"),('surgery/asc8/ui.tsx',"case 'wound'"),('surgery/asc8/ui.tsx',"case 'implants'")],
 'Patient to PACU button':[('surgery/asc8/store.ts','export function toPacu'),('surgery/asc8/store.ts',"kind: 'op-report'")],
 'Aldrete':[('surgery/asc8/ui.tsx',"case 'aldrete'"),('surgery/asc8/ui.tsx',"criteria")],
 'Responsible adult':[('surgery/asc8/ui.tsx',"case 'adult'"),('surgery/asc8/ui.tsx',"case 'handoff'")],
 'Op report note page':[('surgery/asc8/ui.tsx','OpReportPage'),('surgery/asc8/logic.ts','secure-link')],
 'Flags (7 teams':[('surgery/asc8/logic.ts','export const TEAMS')],
 'Sideways scheduler':[('surgery/SurgerySchedule.tsx','sched-by-rooms'),('surgery/v09/schedData.ts','Procedure room')],
 'Block time':[('surgery/SurgerySchedule.tsx','blocksOn')],
 'Today page (v7.6) and Classic board':[('surgery/asc8/ops.tsx','a8-room-grid'),('surgery/asc8/ops.tsx','a8-bottlenecks')],
 'Nightingale brief':[('surgery/fd/SurgeryChat.tsx','AscTodo')],
 'Messages panel':[('surgery/SurgeryApp.tsx','sv-nav-messages')],
 'Tasks widget':[('surgery/asc8/today.tsx','a8-todo')],
 'Case color coding':[('surgery/asc8/logic.ts','LOC_COLOR'),('surgery/SurgerySchedule.tsx','LOC_COLOR')],
 'Clearance workspace':[('surgery/asc8/logic.ts',"key: 'clearance'")],
 'Document intake queue':[('surgery/SurgeryApp.tsx','EmailIntakePage')],
 'Billing module':[('surgery/asc8/ops.tsx','FeeSchedule'),('surgery/asc8/logic.ts','export function charges')],
 'Operations Intelligence':[('surgery/asc8/logic.ts','export function turnovers'),('surgery/asc8/logic.ts','export function utilization'),('surgery/asc8/logic.ts','export const delays')],
 'CEO/admin dashboard':[('surgery/asc8/ops.tsx','a8-ops-line')],
 'Payroll and staffing':[('surgery/asc8/ops.tsx','a8-ops-staff')],
 'Provider invitation':[('surgery/staff.ts','sendStaffInvite')],
 'Users, roles':[('surgery/staff.ts','ASC_SEED')],
 'ASC workflow configuration':[('data/formWorkspaceCatalog.ts','ASC_WORKFLOWS'),('surgery/v10/stations.ts','ASC_WORKFLOWS')],
 'Edition switch':[('edition.ts',"'ASC2'")],
 'Appointment history':[('surgery/SurgeryApp.tsx','openChart')],
 'Patient registration':[('surgery/SurgeryApp.tsx','openChart')],
 'Print chart':[('surgery/asc8/ui.tsx','a8-record-print')],
 'Public landing page':('drop','not carried over (test/demo pages), as planned'),
 'Receiving cases from Surgery.Vityls':[('surgery/asc8/store.ts',"from: 'Surgery.Vityls'")],
}
res=[]; miss=[]
for r in rows:
  feat=r.split('|')[1].strip(); key=next((k for k in E if feat.startswith(k) or k in feat),None)
  if not key: miss.append(feat); res.append((feat,'NO RULE')); continue
  ev=E[key]
  if isinstance(ev,tuple): res.append((feat,'DROPPED · '+ev[1])); continue
  okk=all(has(f,p) for f,p in ev); res.append((feat,'PRESENT' if okk else 'MISSING')); 
  if not okk: miss.append(feat)
for f,s in res: print(f'{s:9}  {f}')
print(f'\n{len(rows)} plan rows · {sum(1 for _,s in res if s=="PRESENT")} present · {sum(1 for _,s in res if s.startswith("DROPPED"))} dropped as planned · {len(miss)} missing')
json.dump(res,open('/workspace/vityls/report/asc_v8.0_screens/feature_map_check.json','w'),indent=1)
sys.exit(1 if miss else 0)
