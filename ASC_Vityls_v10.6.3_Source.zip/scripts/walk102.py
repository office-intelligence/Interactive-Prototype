"""ASC.Vityls v10.2 walkthrough on the CLEAN build: one fictional patient (Jordan Example) through every station plus the
v10.2 settings checks. Test PIN 1234. Fictional data only."""
import asyncio, sys, os, json
from playwright.async_api import async_playwright
URL = sys.argv[1] if len(sys.argv) > 1 else 'http://localhost:8810/'
OUT = os.environ.get('SHOTS', '/workspace/vityls/asc10_shots/v10.2/'); os.makedirs(OUT, exist_ok=True)
res = []
def ok(n, c, note=''): res.append((n, bool(c))); print('PASS' if c else 'FAIL', n, note, flush=True)
SEED = ['Ada Kerr','Celia Ortega','Desmond Akers','Ellen Testwood','Grace Placeholder','Hugo Pell','Iris Navarro','Jonah Reyes','Maren Holt','Marisol Sampleton','Owen Marsh','Priya Demoshah','Priya Lund','Robert Fictus','Talia Wren','Tomas Exampleton','Sam Patel','Dana Whitfield']
async def main():
  async with async_playwright() as p:
    b = await p.chromium.launch(executable_path='/usr/bin/google-chrome'); pg = await b.new_page(viewport={'width': 1440, 'height': 1500}); pg.set_default_timeout(6000)
    errs = []; pg.on('pageerror', lambda e: errs.append(str(e))); pg.on('dialog', lambda d: asyncio.ensure_future(d.accept()))
    await pg.goto(URL + '?reset-test-data'); await pg.wait_for_timeout(2500)
    n = [0]
    async def shot(name):
      n[0] += 1; await pg.wait_for_timeout(300); await pg.screenshot(path=f'{OUT}{n[0]:02d}_{name}.png')
    async def step(name, fn):
      try: await fn(); ok(name, True)
      except Exception as e: ok(name, False, str(e).split('\n')[0][:160])
    async def nav(tid): await pg.locator(f'[data-testid={tid}]').first.evaluate('e=>e.click()'); await pg.wait_for_timeout(700)
    async def draw(sel):
      c = pg.locator(sel).first; await c.scroll_into_view_if_needed(); bb = await c.bounding_box(); x, y = bb['x']+20, bb['y']+bb['height']/2
      await pg.mouse.move(x, y); await pg.mouse.down()
      for i in range(1, 12): await pg.mouse.move(x+i*14, y+(12 if i % 2 else -12))
      await pg.mouse.up()
    async def sign(who=None):
      await pg.wait_for_selector('[data-testid=pin-sign]')
      opts = await pg.eval_on_selector('[data-testid=pin-who]', "s=>[...s.options].map(o=>o.text)")
      pick = [o for o in opts if who and who in o] or [o for o in opts if o and not o.startswith('Choose')]
      await pg.select_option('[data-testid=pin-who]', label=pick[0])
      if await pg.locator('[data-testid=pin-sigpad-canvas]').count(): await draw('[data-testid=pin-sigpad-canvas]')
      await pg.fill('[data-testid=pin-input]', '1234'); await pg.click('[data-testid=pin-confirm]'); await pg.wait_for_timeout(600)
    async def closeall():
      for _ in range(4):
        x = pg.locator('[data-testid=a81-close],[data-testid=a83-booking-close],[data-testid=a8-close]')
        if await x.count():
          try: await x.first.click(timeout=1500)
          except Exception: pass
          await pg.wait_for_timeout(300)
    async def bench(name):
      await closeall(); await pg.evaluate("([b,c])=>window.dispatchEvent(new CustomEvent('asc81-bench',{detail:{bench:b,cid:c}}))", [name, CID[0]]); await pg.wait_for_selector(f'[data-testid=a81-bench-{name}]'); await pg.wait_for_timeout(500)
    T = lambda tid: pg.locator(f'[data-testid={tid}]')
    LS = lambda: pg.evaluate("()=>JSON.stringify(Object.values(localStorage))")
    # fictional test files: a 3-page scanned stack (PDF) and a card photo (PNG)
    def mkpdf(path, pages=3):
      objs = ['<< /Type /Catalog /Pages 2 0 R >>', '<< /Type /Pages /Kids [%s] /Count %d >>' % (' '.join(f'{3+i} 0 R' for i in range(pages)), pages)]
      for i in range(pages): objs.append('<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] >>')
      out = b'%PDF-1.4\n'; offs = []
      for i, o in enumerate(objs): offs.append(len(out)); out += f'{i+1} 0 obj\n{o}\nendobj\n'.encode()
      x = len(out); out += f'xref\n0 {len(objs)+1}\n0000000000 65535 f \n'.encode() + b''.join(f'{o:010d} 00000 n \n'.encode() for o in offs)
      out += f'trailer\n<< /Size {len(objs)+1} /Root 1 0 R >>\nstartxref\n{x}\n%%EOF\n'.encode(); open(path, 'wb').write(out)
    PDF = '/tmp/walk102_scanned_stack.pdf'; mkpdf(PDF)
    PNG = '/tmp/walk102_card.png'
    import base64; open(PNG, 'wb').write(base64.b64decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg=='))
    await pg.goto(URL + '?reset-test-data'); await pg.wait_for_timeout(2500)
    await shot('today_clean')
    ls = await LS(); ok('clean build: zero seed patients in storage', not [s for s in SEED if s in ls], str([s for s in SEED if s in ls]))
    wm = await pg.evaluate("()=>{const e=document.querySelector('[data-testid=v10-wordmark]');return e?e.getBoundingClientRect().height:0}")
    ok('top-left wordmark is larger (>= 40 px tall)', wm >= 40, f'{wm:.0f}px')
    CID = ['']
    async def book():
      await nav('sv-nav-schedule'); await shot('schedule')
      ok('schedule button reads "Add a Case"', (await T('add-visit').first.inner_text()).strip() == 'Add a Case')
      await T('add-visit').first.click(); await pg.wait_for_selector('[data-testid=a83-book-name]')
      await pg.fill('[data-testid=a83-book-name]', 'Jordan Example'); await pg.fill('[data-testid=a83-book-dob]', '03/14/1980')
      ph = pg.locator('[data-testid=a83-booking] input[type=tel], [data-testid=a83-booking] input[placeholder*="555"]').first
      await ph.click(); await pg.keyboard.type('3105551234'); await pg.keyboard.press('Tab')
      ok('phone formats (310) 555-1234', await ph.input_value() == '(310) 555-1234', await ph.input_value())
      col = await pg.evaluate("()=>{const i=document.querySelector('[data-testid=a83-book-name]');return getComputedStyle(i,'::placeholder').color}")
      ok('lighter placeholder color', col.replace(' ', '') in ('rgb(156,163,159)',), col)
      await pg.fill('[data-testid=a83-book-proc]', 'Carpal tunnel release, right')
      for t in ['a83-book-anes', 'a83-book-pay']: await pg.select_option(f'[data-testid={t}]', index=1)
      await shot('add_a_case_filled'); await pg.click('[data-testid=a83-book-save]'); await pg.wait_for_timeout(900)
      if await T('a83-book-save').count(): await pg.click('[data-testid=a83-book-save]'); await pg.wait_for_timeout(900)
      CID[0] = await pg.evaluate("()=>{for(const k of Object.keys(localStorage)){if(!/asc8-cases$/.test(k))continue;const l=JSON.parse(localStorage.getItem(k));const c=l.find(x=>x.procedure&&x.procedure.includes('Carpal'));if(c)return c.id}return ''}")
      assert CID[0], 'case not created'
    await step('book Jordan Example with "Add a Case"', book)
    if not CID[0]: print('no case; stop'); await b.close(); return
    async def common(name, leak=(), sel=None, head='.a81-dhead'):
      sel = sel or f'[data-testid=a81-bench-{name}]'; t = await pg.inner_text(sel)
      ok(f'{name}: one Capture / Upload button, top right', await pg.locator(f'{sel} [data-testid=v10-capture]').count() == 1 and await pg.locator(f'{sel} {head} [data-testid=v10-capture]').count() == 1)
      ok(f'{name}: one station confirm checkmark', await pg.locator(f'{sel} [data-testid=v102-confirm]').count() == 1)
      ok(f'{name}: no Export / Print, no internal terms', not any(w in t for w in ['Export / Print', 'uestion bank', 'Bank only', 'seeded (test)', 'Surgery.Vityls', 'v0.4']), [w for w in ['Export / Print', 'uestion bank', 'Bank only', 'seeded (test)', 'Surgery.Vityls', 'v0.4'] if w in t])
      if leak: ok(f'{name}: no questions from other stations', not [w for w in leak if w in t], str([w for w in leak if w in t]))
      if await pg.locator(f'{sel} .v102-form').count():
        al = await pg.evaluate("""(s)=>{const f=document.querySelector(s+' .v102-form');const L=[...f.querySelectorAll(':scope>.lab')].map(e=>Math.round(e.getBoundingClientRect().right));const I=[...f.querySelectorAll(':scope>.inp')].map(e=>Math.round(e.getBoundingClientRect().left));return {L:new Set(L).size,I:new Set(I).size,n:L.length}}""", sel)
        ok(f'{name}: missing fields laid out as an aligned form', al['L'] == 1 and al['I'] == 1, str(al))
    async def confirm(name):
      await T('v102-confirm-box').first.click(); await pg.wait_for_timeout(500)
      ok(f'{name}: one check confirms the whole station', await T('v102-confirm').first.get_attribute('data-done') == '1')
    async def checkin():
      await bench('arrival'); await shot('checkin_station')
      t = await pg.inner_text('[data-testid=a81-bench-arrival]')
      ok('check-in: At-home forms removed (Intake forms only)', 'At-home forms' not in t and 'Intake forms' in t)
      ok('check-in: ID and insurance card upload (front/back)', all([await T(f'a82-card-{k}').count() for k in ['idFront', 'idBack', 'insFront', 'insBack']]))
      await T('a82-up-idFront').set_input_files(PNG); await pg.wait_for_timeout(500)
      ok('check-in: photo ID front captured', await T('a82-card-idFront').locator('img').count() == 1)
      await common('arrival', leak=['Surgeon Operative Report', 'Intra-Operative', 'Universal Protocol', 'Consent to Operation'])
      await T('v10-capture').first.click(); await pg.wait_for_selector('[data-testid=a87-upload]'); await shot('upload_general_no_category')
      ok('upload: no document type or category picker', await T('a87-up-type').count() == 0 and await T('a89-up-cat').count() == 0)
      ok('upload dialog names the station', 'Arrival' in await T('a87-upload').inner_text())
      await T('a87-up-files').set_input_files(PDF); await T('a87-up-save').click(); await pg.wait_for_timeout(700)
      up = await pg.evaluate("()=>{for(const k of Object.keys(localStorage)){if(!/asc87-uploads$/.test(k))continue;return JSON.parse(localStorage.getItem(k))}return []}")
      u = [x for x in up if x.get('cid') == CID[0]]
      ok('multipage PDF filed to the case documents, tagged to the station', bool(u) and u[-1]['mime'] == 'application/pdf' and 'Arrival' in u[-1].get('station', '') and u[-1].get('cat') == 'Case documents', str(u[-1] if u else ''))
      await confirm('check-in'); await shot('checkin_confirmed')
      await pg.click('[data-testid=a83-ci-go]'); await pg.wait_for_timeout(800)
    await step('check-in station', checkin)
    async def verify():
      await bench('verify'); await shot('verify_history')
      f = pg.locator('[data-testid=v10-hx-allergies], [data-testid=v10-hx-allergy]')
      if await f.count(): await f.first.fill('NKDA')
      await pg.click('[data-testid=v10-hx-confirm]'); await sign(); await shot('verify_history_confirmed')
      ok('official history recorded', 'asc10-history' in await pg.evaluate("()=>Object.keys(localStorage).join(',')"))
    await step('verify medical history', verify)
    async def nursing():
      await bench('nursing'); await shot('nursing_station')
      await common('nursing', leak=['Emergency Transfer', 'AMA', 'Surgeon Operative Report'])
      t = await pg.inner_text('[data-testid=v10-list-pre]'); ok('pre-op orders = facility standard for every surgeon', 'facility standard' in t and 'Cefazolin' in t)
      vis = await pg.evaluate("()=>[...document.querySelectorAll('[data-testid=a81-nursing] .a82-ck input[type=checkbox]')].filter(e=>e.offsetParent!==null).length")
      ok('nursing: no per-item checkboxes', vis == 0, str(vis))
      ok('nursing: consents are signed here', await T('v102-nurse-consents').count() == 1)
      await T('v102-nc-anes-sign-open').click(); await sign()
      await T('v102-nc-surg-sign-open').click(); await sign()
      ok('both consents signed at nursing admission', await T('v102-nc-anes').get_attribute('data-signed') == '1' and await T('v102-nc-surg').get_attribute('data-signed') == '1')
      await confirm('nursing'); await shot('nursing_confirmed')
      ok('confirm ticks every pre-op order', '6 of 6' in await T('v10-list-pre').inner_text())
      ok('confirm completes the nursing checklist', '16 of 16' in await T('a82-nurse-progress').inner_text(), await T('a82-nurse-progress').inner_text())
    await step('nursing admission', nursing)
    async def anes_surg(name):
      await bench(name); await shot(f'{name}_station')
      await common(name, leak=['Patient Registration', 'Insurance Information'] if name == 'anesthesia' else ['Patient Registration', 'Intra-Operative Nursing'])
      ok(f'{name}: anesthesia questionnaire summary + link', await T('v102-anes-summary').count() == 1 and await T('v102-open-aq').count() == 1)
      ok(f'{name}: consent links show signed at nursing', await T('v102-consent-anes').get_attribute('data-signed') == '1' and await T('v102-consent-surg').get_attribute('data-signed') == '1' and await T('v102-consent-anes-open').count() == 1)
      await T('v102-consent-surg-open').click(); await pg.wait_for_timeout(800); ok(f'{name}: consent link opens the form', await T('v102-form-overlay').count() == 1); await shot(f'{name}_consent_open')
      await pg.locator('[data-testid=v102-form-overlay] [aria-label=Close], [data-testid=v102-form-overlay] [aria-label*=lose]').first.click(); await pg.wait_for_timeout(400); assert await T('v102-form-overlay').count() == 0, 'form did not close'
      await T('v102-open-aq').click(); await pg.wait_for_timeout(800); ok(f'{name}: questionnaire link opens the form', await T('v102-form-overlay').count() == 1)
      await pg.locator('[data-testid=v102-form-overlay] [aria-label=Close], [data-testid=v102-form-overlay] [aria-label*=lose]').first.click(); await pg.wait_for_timeout(400); assert await T('v102-form-overlay').count() == 0, 'form did not close'
      await confirm(name)
    await step('anesthesia station', lambda: anes_surg('anesthesia'))
    async def surg():
      await anes_surg('surgeon')
      for k in ['procedure', 'findings']:
        x = T(f'v10-bo-{k}')
        if await x.count(): await x.fill('Right carpal tunnel release' if k == 'procedure' else 'Thickened transverse carpal ligament')
      await pg.click('[data-testid=v10-bo-sign]'); await sign('Test Surgeon'); await shot('surgeon_brief_op_signed')
      ok('brief OP report signed by the surgeon', await T('v10-briefop-signed').count())
    await step('surgeon station', surg)
    async def orr():
      await closeall(); await pg.evaluate("(c)=>window.dispatchEvent(new CustomEvent('asc8-open',{detail:{t:'step',cid:c,station:'or'}}))", CID[0]); await pg.wait_for_selector('[data-testid=a8-step]'); await pg.wait_for_timeout(500); await shot('or_station')
      await common('or', leak=['Patient Registration', 'Insurance Information'], sel='[data-testid=a8-step]', head='.a82-panelhead'); await confirm('OR')
    await step('OR', orr)
    async def pacu():
      await bench('pacu')
      x = pg.locator('[data-testid=a82-pacu-form] [aria-label=Close], [data-testid=a82-pacu-form] [aria-label*=lose]')
      if await x.count(): await x.first.click(); await pg.wait_for_timeout(400)
      await shot('pacu_station'); await common('pacu')
      t = await pg.inner_text('[data-testid=v10-list-post]'); ok('post-op orders = facility PACU orders (form library)', 'facility standard' in t and 'Fentanyl 25 mcg IV' in t and 'Aldrete' in t)
      await confirm('PACU'); ok('confirm ticks every post-op order', '15 of 15' in await T('v10-list-post').inner_text())
      x = T('a82-pacu-form').locator('[data-testid*=close], [aria-label=Close]')
      if await x.count():
        try: await x.first.click(timeout=1500)
        except Exception: pass
    await step('PACU', pacu)
    async def dc():
      await bench('discharge'); await shot('discharge_station'); await common('discharge'); await confirm('discharge')
    await step('discharge', dc)
    async def clos():
      await bench('closure'); await shot('closure'); ok('closure opens', await T('a81-bench-closure').count())
    await step('closure', clos)
    async def details():
      await closeall(); await nav('sv-nav-home')
      await pg.evaluate("(c)=>window.dispatchEvent(new CustomEvent('asc8-open',{detail:{t:'details',cid:c}}))", CID[0]); await pg.wait_for_selector('[data-testid=a83-case-details]'); await pg.wait_for_timeout(500); await shot('case_details_aligned')
      r = await pg.evaluate("()=>{const d=document.querySelector('[data-testid=a88-dock]');const m=document.querySelector('[data-testid=a83-case-details]').getBoundingClientRect();if(!d)return {nodock:1,top:m.top};const k=d.getBoundingClientRect();return {dl:k.left,dr:k.right,db:k.bottom,ml:m.left,mr:m.right,mt:m.top}}")
      ok('journey stepper and Case details slider aligned (no overlap)', r.get('nodock') or (abs(r['dl'] - r['ml']) < 3 and abs(r['dr'] - r['mr']) < 3 and r['mt'] >= r['db'] - 2), str(r))
      x = T('a83-case-details-close')
      if await x.count(): await x.first.click()
    await step('Case details alignment', details)
    async def intake():
      await closeall(); await nav('sv-nav-home')
      await pg.evaluate("()=>window.dispatchEvent(new CustomEvent('asc81-bench',{detail:{bench:'intake'}}))"); await pg.wait_for_selector('[data-testid=a81-bench-intake]'); await shot('booking_intake_slider')
      ok('Booking intake slider still opens (At-home / Portal)', 'Booking intake' in await T('a81-bench-intake').inner_text())
      await closeall()
    await step('booking intake slider', intake)
    async def role(label):
      s = T('acting-as').locator('select') if await T('acting-as').locator('select').count() else pg.locator('select').first
      opts = await s.evaluate("s=>[...s.options].map(o=>o.text)"); await s.select_option(label=[o for o in opts if label in o][0]); await pg.wait_for_timeout(600)
    async def practice():
      await nav('sv-nav-forms'); await pg.wait_for_timeout(400)
      if await T('practice-unlock').count() and await T('practice-unlock').first.is_visible(): await T('practice-unlock').first.click(); await pg.wait_for_timeout(300)
      if await T('pin-sign').count(): await sign()
      elif await pg.locator('input[type=password]').count(): await pg.locator('input[type=password]').last.fill('1234'); await pg.get_by_role('button', name='Unlock').click(); await pg.wait_for_timeout(500)
      await pg.wait_for_selector('[data-testid=v10-settings]')
    async def open_tab(tab): await practice(); await T(f'prac-{tab}').first.click(); await pg.wait_for_timeout(800)
    async def settings():
      await closeall(); await role('Practice Administrator'); await practice(); await shot('settings_home')
      t = await T('v10-settings').inner_text(); ok('settings: no internal terms', 'uestion bank' not in t and 'Doctor’s orders library' not in t)
      await open_tab('profile'); await shot('settings_facility_profile')
      body = await pg.inner_text('body'); ok('one facility profile (no second practice name/address block)', body.count('Facility name') == 1 and 'Practice name' not in body and 'Practice profile & rooms' not in body)
      await open_tab('staff'); await shot('settings_staff')
      bg = await pg.evaluate("()=>[...document.querySelectorAll('[data-testid=staff-table] tbody tr')].slice(0,6).map(r=>getComputedStyle(r.cells[0]).backgroundColor)")
      ok('staff rows shaded in different light colors', len(set(bg)) >= min(len(bg), 2) and 'rgba(0, 0, 0, 0)' not in bg, str(bg))
      ok('staff page: white section cards, no "seeded (test)"', await pg.locator('[data-testid=sv-staff] .sv-sec').count() >= 2 and 'seeded (test)' not in await pg.inner_text('body'))
      await open_tab('med-settings'); await shot('settings_surgery')
      body = await pg.inner_text('body')
      ok('Surgery settings: plain-English descriptions removed', 'Plain-English' not in body)
      ok('only one orders list (Standard doctor’s orders list removed)', 'Standard doctor’s orders list' not in body and await T('a87-standing').count() == 0)
      ok('Surgery settings: white section cards', await pg.evaluate("()=>[...document.querySelectorAll('.vy-card')].every(e=>getComputedStyle(e).backgroundColor==='rgb(255, 255, 255)')"))
      await open_tab('v10-lists'); await shot('settings_standard_orders')
      ok('standard orders page shows the facility standard', 'Facility standard' in await T('v10-lists').inner_text())
      await open_tab('surgery-settings'); await shot('settings_visit_types')
      pos = await pg.evaluate("()=>{const a=document.querySelector('#schedule-columns'),b=document.querySelector('[data-testid=vt-table]');return a&&b?a.getBoundingClientRect().top<b.getBoundingClientRect().top:false}")
      ok('Visit types page: Schedule columns at the top', pos)
      cols = ' | '.join(await pg.eval_on_selector_all('#schedule-columns input[type=text], #schedule-columns input:not([type])', 'es=>es.map(e=>e.value)')); ok('default room columns are only OR 1 and OR 2', 'OR 1' in cols and 'OR 2' in cols and 'OR 3' not in cols and 'Procedure room' not in cols, cols)
      await open_tab('documents'); await pg.wait_for_timeout(600); await shot('settings_compliance_ask')
      ok('Compliance & credentials: Nightingale chat box', await T('v102-compliance-ask').count() == 1)
      await pg.fill('[data-testid=v102-cask-input]', 'Remind me to renew the CLIA waiver in 30 days'); await T('v102-cask-send').click(); await pg.wait_for_timeout(400)
      ok('Nightingale drafts a task; a person confirms it', await T('v102-ctask').count() == 1 and await T('v102-ctask').get_attribute('data-status') == 'draft')
      await T('v102-ctask-confirm').click(); await pg.wait_for_timeout(300); ok('task confirmed', await T('v102-ctask').get_attribute('data-status') == 'open'); await shot('compliance_task')
    await step('settings', settings)
    ls = await LS(); ok('end: still zero seed names', not [s for s in SEED if s in ls])
    ok('no page errors', not errs, '; '.join(errs[:3]))
    await b.close()
  f = [r for r in res if not r[1]]; print(f'{len(res)-len(f)}/{len(res)} passed'); [print('  FAILED', r[0]) for r in f]
asyncio.run(main())
