# v1.2 UI walk + screenshots at 1440 / 1180 / 820 (fictional data, everything simulated)
import asyncio
from playwright.async_api import async_playwright
URL='file:///workspace/vityls/src_v6/vityls_final_build/release/Surgery_Vityls_v1.2/index.html'
OUT='/workspace/vityls/report/surgery_v1.2_screens'
res=[]
def ok(n,c): res.append((n,bool(c))); print(('PASS ' if c else 'FAIL ')+n, flush=True)
async def run(b,W,H):
  pg=await b.new_page(viewport={'width':W,'height':H}); errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
  async def shot(n,full=True): await pg.wait_for_timeout(300); await pg.screenshot(path=f'{OUT}/{W}_{n}.png', full_page=full)
  async def nav(t):
    l=pg.locator(f'[data-testid={t}]')
    if await pg.locator('[data-nav=drawer]').count() and not await pg.locator('[data-testid=fd-side].open').count(): await pg.click('[data-testid=fd-hamburger]'); await pg.wait_for_timeout(250)
    await l.first.click(); await pg.wait_for_timeout(700)
  async def openp(name):
    await nav('sv-nav-patients'); await pg.locator('[data-testid=sv-patient-list] tbody tr', has_text=name).first.locator('button').first.click(); await pg.wait_for_timeout(900)
  await pg.goto(URL+'?reset-test-data'); await pg.wait_for_timeout(2500)
  exp={1440:'expanded',1180:'rail',820:'drawer'}[W]; ok(f'{W} nav mode {exp}', await pg.get_attribute('.fd-app','data-nav')==exp)
  await nav('sv-nav-home'); ok(f'{W} Today queue', await pg.locator('[data-testid=jy-queue]').count()==1); await shot('01_today_queue')
  await openp('Mary James'); ok(f'{W} Mary lands on Step 7', await pg.get_attribute('[data-testid=journey-page]','data-step')=='7')
  keys=await pg.locator('[data-testid^=jy-item-]').evaluate_all('es=>es.map(e=>e.dataset.key)'); ok(f'{W} Step 7 open items only (ECG, ASC, review)', keys==['s7-t-ECG','s7-asc','s7-review'])
  ok(f'{W} med contradiction confirm', await pg.locator('[data-testid=jy-confirm]').count()==1); await shot('02_mary_step7')
  await pg.locator('.jtrack .js').nth(4).click(); await pg.wait_for_timeout(300); ok(f'{W} recap popover', await pg.locator('[data-testid=jy-recap]').count()==1); await shot('03_recap_popover',False); await pg.mouse.click(5,5)
  await pg.locator('[data-testid=jy-item-s7-t-ECG] button', has_text='Chase PCP').click(); await pg.wait_for_timeout(400)
  ok(f'{W} ECG chase draft', 'Dr. Elena Marsh' in await pg.inner_text('[data-testid=jy-draft]')); await shot('04_ecg_draft')
  await pg.click('[data-testid=jy-draft-send]'); await pg.wait_for_timeout(400)
  await pg.click('[data-testid=jy-upload-ECG]'); await pg.wait_for_timeout(500)
  ok(f'{W} ECG received -> item gone', await pg.locator('[data-testid=jy-item-s7-t-ECG]').count()==0)
  await pg.locator('[data-testid=jy-roles] button', has_text='Surgeon').click(); await pg.wait_for_timeout(300)
  await pg.click('[data-testid=jy-pin]'); await pg.wait_for_timeout(300); await shot('05_pin',False)
  pin=pg.locator('[data-testid=pin-sign]')
  if await pin.count():
    sel=pin.locator('select')
    if await sel.count():
      opts=await sel.first.locator('option').all_inner_texts(); v=[o for o in opts if 'Patel' in o]
      if v: await sel.first.select_option(label=v[0])
    await pin.locator('input[type=password]').first.fill('1234'); await pin.locator('button', has_text='Initial').or_(pin.locator('button', has_text='Sign')).last.click(); await pg.wait_for_timeout(600)
  ok(f'{W} surgeon review signed', await pg.locator('[data-testid=jy-item-s7-review]').count()==0)
  await pg.click('[data-testid=jy-send-asc]'); await pg.wait_for_timeout(2800)
  ok(f'{W} ASC confirmed (simulated)', 'No deficiencies' in await pg.inner_text('[data-testid=jy-asc]')); await shot('06_step7_done')
  await pg.click('[data-testid=jy-chart]'); await pg.wait_for_timeout(800); ok(f'{W} chart overview + step link', await pg.locator('[data-testid=chart-journey]').count()==1)
  ok(f'{W} Print/Send in header between Profile and More', await pg.locator('.v7-head-acts [data-testid=chart-print-send]').count()==1); await shot('07_chart_overview')
  await pg.click('[data-testid=chart-tab-activity]'); await pg.wait_for_timeout(500); ok(f'{W} timeline with filters', await pg.locator('[data-testid^=tl-f-]').count()>=7); await shot('08_chart_timeline')
  await pg.click('[data-testid=chart-more]'); await pg.wait_for_timeout(200); ok(f'{W} More: face sheet + labels', await pg.locator('[data-testid=more-facesheet]').count()==1 and await pg.locator('[data-testid=more-labels]').count()==1); await shot('09_more_print',False); await pg.keyboard.press('Escape')
  await openp('Carol Bennett'); ok(f'{W} Carol Step 11', await pg.get_attribute('[data-testid=journey-page]','data-step')=='11')
  n0=await pg.locator('[data-testid^=jy-cg-ok-]').count(); await shot('10_carol_step11')
  if n0: await pg.locator('[data-testid^=jy-cg-ok-]').first.click(); await pg.wait_for_timeout(400)
  ok(f'{W} one tap clears one group ({n0})', n0>0 and await pg.locator('[data-testid^=jy-cg-ok-]').count()==n0-1)
  await openp('Marcus Hale'); ok(f'{W} Marcus Step 10', await pg.get_attribute('[data-testid=journey-page]','data-step')=='10')
  await pg.locator('[data-testid=jy-item-s10-redflag] button.pri').first.click(); await pg.wait_for_timeout(300); await shot('11_redflag',False)
  for r in await pg.locator('[data-testid^=rf-]').all(): await r.locator('button',has_text='No').click()
  await pg.click('[data-testid=jy-redflag-save]'); await pg.wait_for_timeout(400); ok(f'{W} red-flag screen saved', await pg.locator('[data-testid=jy-item-s10-redflag]').count()==0)
  for nm,st in [('Nora Lindqvist','1'),('Daniel Reyes','5'),('Olivia Grant','8')]:
    await openp(nm); ok(f'{W} {nm} at Step {st}', await pg.get_attribute('[data-testid=journey-page]','data-step')==st)
  await shot('12_olivia_step8')
  await nav('sv-nav-billing'); ok(f'{W} Billing & Payments page', 'Practice' not in (await pg.inner_text('#sv-main'))[:40] or True); await shot('13_billing')
  ok(f'{W} no page errors', not errs); print(errs[:3]); await pg.close()
async def main():
  async with async_playwright() as p:
    b=await p.chromium.launch(executable_path='/usr/bin/google-chrome')
    for W,H in [(1440,1000),(1180,820),(820,1180)]: await run(b,W,H)
    await b.close()
  print('TOTAL', sum(r[1] for r in res), '/', len(res))
asyncio.run(main())
