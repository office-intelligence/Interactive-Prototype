"""ASC.Vityls v8.1 walkthrough (Playwright + Chrome). Usage: python3 scripts/walk81.py [URL] [WIDTH...]. Fictional data; test PIN 1234."""
import asyncio, sys, os
from playwright.async_api import async_playwright
URL = sys.argv[1] if len(sys.argv) > 1 else 'http://localhost:8782/'
WIDTHS = [int(w) for w in sys.argv[2:]] or [1440, 1024, 390]
OUT = '/workspace/vityls/report/asc_v8.1_screens/'; os.makedirs(OUT, exist_ok=True)
res = []
def ok(name, cond, note=''): res.append((name, bool(cond), note)); print(('PASS' if cond else 'FAIL'), name, note, flush=True)
async def run(w):
    async with async_playwright() as p:
        b = await p.chromium.launch(executable_path='/usr/bin/google-chrome'); pg = await b.new_page(viewport={'width': w, 'height': 900 if w > 500 else 844}); pg.set_default_timeout(8000)
        errs = []; pg.on('pageerror', lambda e: errs.append(str(e)))
        await pg.goto(URL + '?reset-test-data'); await pg.wait_for_timeout(2500)
        T = f'{w}:'; shot = lambda n: pg.screenshot(path=f'{OUT}{w}_{n}.png', full_page=True)
        async def role(label):
            s = pg.locator('select').first; opts = await s.evaluate("s=>[...s.options].map(o=>o.text)"); await s.select_option(label=[o for o in opts if label in o][0]); await pg.wait_for_timeout(600)
        async def nav(tid):
            el = pg.locator(f'[data-testid={tid}]').first
            await el.evaluate('e=>e.click()'); await pg.wait_for_timeout(700)
        async def sign(who=None):
            await pg.wait_for_selector('[data-testid=pin-sign]')
            if who: await pg.select_option('[data-testid=pin-who]', label=who)
            else:
                v = await pg.eval_on_selector('[data-testid=pin-who]', 'e=>e.value')
                if not v: await pg.select_option('[data-testid=pin-who]', index=1)
            await pg.fill('[data-testid=pin-input]', '1234'); await pg.click('[data-testid=pin-confirm]'); await pg.wait_for_timeout(500)
        async def bench(chip):
            await nav('sv-nav-home'); a = pg.locator('[data-testid=a81-chip-all]')
            if await pg.locator(f'[data-testid=a81-chip-{chip}]').count() == 0 and await a.count(): await a.click()
            await pg.click(f'[data-testid=a81-chip-{chip}]'); await pg.wait_for_selector(f'[data-testid=a81-bench-{chip}]')
        # Today: front desk
        await role('Front Desk Tester'); await nav('sv-nav-home')
        ok(T+'today chips', await pg.locator('[data-testid=a81-bench-chips]').count()); ok(T+'station icon', await pg.locator('[data-station-icon]').count() > 0); await shot('01_today_front')
        # 1 intake
        await bench('intake'); await pg.click('[data-testid=a81-scan-fax]'); n0 = await pg.locator('[data-testid=a81-intake-item]').count(); ok(T+'fax scanned', n0 >= 2)
        ok(T+'prefill', await pg.input_value('[data-testid=a81-f-patientName]') != ''); await shot('02_intake')
        await pg.click('[data-testid=a81-intake-confirm]'); await pg.wait_for_timeout(600); ok(T+'case created', await pg.locator('[data-testid=a81-bench-intake]').count() == 0)
        # 2 arrival
        await bench('arrival'); ok(T+'checklist', await pg.locator('[data-testid=a81-check]').count() >= 5); await shot('03_arrival')
        await pg.click('[data-testid=a81-checkin]'); await pg.wait_for_timeout(600); ok(T+'checked in', await pg.locator('[data-testid=a81-bench-arrival]').count() == 0)
        # 3 brief as anesthesia
        await role('Noor Haddad'); await bench('brief'); await pg.select_option('[data-testid=a81-case-pick]', label=[o for o in await pg.eval_on_selector('[data-testid=a81-case-pick]', "s=>[...s.options].map(o=>o.text)") if 'Desmond' in o][0])
        ok(T+'brief lines', await pg.locator('[data-testid=a81-brief-line]').count() >= 3); await pg.locator('[data-testid=a81-src-link]').first.click(); ok(T+'source page', await pg.locator('[data-testid=a81-src-view]').count()); await shot('04_brief')
        await pg.click('[data-testid=a81-asa-accept]'); await pg.wait_for_timeout(400)
        # 4 bedside: anesthesia signs orders
        await bench('bedside'); await pg.click('[data-testid=a81-listen]'); await pg.wait_for_timeout(300); ok(T+'bedside draft', len(await pg.input_value('[data-testid=a81-bed-text-anesthesia]')) > 10)
        await pg.click('[data-testid=a81-ord-open]'); await sign('Noor Haddad, MD · Anesthesiologist'); ok(T+'orders signed', await pg.locator('[data-testid=a81-orders-signed]').count()); await shot('05_bedside'); await pg.click('[data-testid=a81-close]')
        # 5 nursing as pre-op RN
        await role('Casey Morgan'); await nav('sv-nav-home'); await shot('06_today_preop'); await bench('nursing'); ok(T+'nurse items', await pg.locator('[data-testid=a81-nurse-item]').count() >= 5)
        await pg.fill('[data-testid=a81-dictate]', 'bridge removed, 20 gauge IV left hand'); await pg.click('[data-testid=a81-dictate-apply]'); await shot('07_nursing')
        await pg.click('[data-testid=a81-nurse-open]'); await sign(); ok(T+'nursing signed', await pg.locator('[data-testid=a81-bench-nursing]').count() == 0)
        # 6 PACU (Maren in PACU) needs orders: sign for Maren via anesthesia bedside
        await role('Noor Haddad'); await bench('bedside'); await pg.select_option('[data-testid=a81-case-pick]', label=[o for o in await pg.eval_on_selector('[data-testid=a81-case-pick]', "s=>[...s.options].map(o=>o.text)") if 'Maren' in o][0]); await pg.click('[data-testid=a81-ord-open]'); await sign('Noor Haddad, MD · Anesthesiologist'); await pg.click('[data-testid=a81-close]')
        await role('Alex Rivera'); await bench('pacu'); ok(T+'pacu tasks', await pg.locator('[data-testid=a81-task]').count() >= 2)
        for k, v in [('activity', '2'), ('respiration', '2'), ('circulation', '2'), ('consciousness', '2'), ('spo2', '2'), ('pain', '2')]: await pg.select_option(f'[data-testid=a81-al-{k}]', v)
        await pg.click('[data-testid=a81-al-add]'); await pg.click('[data-testid=a81-al-add]'); await pg.wait_for_timeout(300); ok(T+'aldrete alerts', await pg.locator('[data-testid=a81-al-alert]').count() >= 1); await shot('08_pacu'); await pg.click('[data-testid=a81-close]')
        # 7 discharge
        await bench('discharge'); ok(T+'dc draft', len(await pg.input_value('[data-testid=a81-dc-text]')) > 50); await pg.select_option('[data-testid=a81-dc-lang]', 'Spanish'); await pg.check('[data-testid=a81-dc-patient]'); await shot('09_discharge')
        await pg.click('[data-testid=a81-dc-open]'); await sign(); await pg.wait_for_timeout(400); ok(T+'dc signed', await pg.locator('[data-testid=a81-dc-signed]').count() or await pg.locator('[data-testid=a81-bench-discharge]').count() == 0)
        if await pg.locator('[data-testid=a81-close]').count(): await pg.click('[data-testid=a81-close]')
        # 8 after
        await bench('after'); await pg.fill('[data-testid=a81-reply-in]', '3 - fever since last night'); await pg.click('[data-testid=a81-reply-go]'); ok(T+'triage reply', await pg.locator('[data-testid=a81-reply]').count()); await pg.click('[data-testid=a81-close]')
        # ops, audit, md as admin
        await role('Practice Administrator'); await nav('sv-nav-home'); ok(T+'quick actions', await pg.locator('[data-testid=a81-quick-actions]').count()); await shot('10_today_admin')
        await bench('export'); ok(T+'audit pack', 'cases complete' in await pg.inner_text('[data-testid=a81-export]')); await pg.click('[data-testid=a81-close]')
        await nav('sv-nav-ops'); ok(T+'pipeline', await pg.locator('[data-testid=a81-pipe-card]').count() >= 5); await shot('11_ops_pipeline'); await pg.click('[data-testid=a81-view-priority]'); ok(T+'priority', await pg.locator('[data-testid=a81-pri-row]').count() >= 2); await shot('12_ops_priority')
        # schedule
        await nav('sv-nav-schedule'); await pg.click('[data-testid=a81-day-briefing-btn]'); ok(T+'day briefing', 'patient' in await pg.inner_text('[data-testid=a81-brief-text]')); await shot('13_day_briefing'); await pg.click('[data-testid=a81-brief-close]')
        await pg.click('[data-testid=a81-block-time]'); await pg.click('[data-testid=a81-block-save]'); await pg.wait_for_timeout(300); ok(T+'block time rule', await pg.locator('[data-testid=a81-block-err]').count() or await pg.locator('[data-testid=a81-block-dialog]').count() == 0)
        if await pg.locator('[data-testid=a81-block-dialog]').count(): await pg.select_option('[data-testid=a81-block-room]', 'OR 3'); await pg.click('[data-testid=a81-block-save]')
        await shot('14_schedule')
        # messages filters
        await nav('sv-nav-messages'); await pg.click('[data-testid=msg-filter-rx]'); ok(T+'rx filter', await pg.locator('[data-testid=msg-thread]').count() >= 1); await shot('15_messages')
        # practice: MD
        await pg.locator('button:has(.fd-lbl:text-is("Practice Settings"))').first.evaluate('e=>e.click()')
        await pg.wait_for_timeout(600)
        await pg.wait_for_timeout(500)
        if await pg.locator('[data-testid=pin-sign]').count() == 0 and await pg.locator('[data-testid=practice-unlock]').count() and await pg.locator('[data-testid=practice-unlock]').first.is_visible():
            await pg.click('[data-testid=practice-unlock]'); await pg.wait_for_timeout(400)
        if await pg.locator('[data-testid=pin-sign]').count() or await pg.locator('input[type=password]').count():
            if await pg.locator('[data-testid=pin-sign]').count(): await sign('Practice Administrator · Practice Administrator')
            else: await pg.locator('input[type=password]').last.fill('1234'); await pg.get_by_role('button', name='Unlock').click()
            await pg.wait_for_timeout(600)
        await shot('16_practice'); await pg.click('[data-testid=prac-medical-director]'); await pg.wait_for_selector('[data-testid=a81-md]')
        await pg.locator('[data-testid=a81-cred-approve]').nth(1).click(); await sign('Sam Patel, MD · Surgeon'); ok(T+'privileges approved', 'Privileges Approved' in await pg.inner_text('[data-testid=a81-md-creds]'))
        await pg.locator('[data-testid=a81-md-attest]').first.click(); await sign('Sam Patel, MD · Surgeon'); ok(T+'policy attested', 'Reviewed' in await pg.inner_text('[data-testid=a81-md-policies]')); await shot('17_medical_director')
        await pg.locator('button:has(.fd-lbl:text-is("Practice Settings"))').first.evaluate('e=>e.click()'); await pg.wait_for_timeout(500); await pg.click('[data-testid=prac-forms]'); await pg.wait_for_timeout(800); ok(T+'forms library', await pg.get_by_text('Nursing Pre-Op Assessment').count() > 0); await shot('18_forms')
        await pg.locator('button:has(.fd-lbl:text-is("Practice Settings"))').first.evaluate('e=>e.click()'); await pg.wait_for_timeout(500); await pg.click('[data-testid=prac-billing-settings]') if await pg.locator('[data-testid=prac-billing-settings]').count() else None; await pg.wait_for_timeout(500); await shot('19_billing_settings')
        await nav('sv-nav-billing') if await pg.locator('[data-testid=sv-nav-billing]').count() else None
        # station step panel with tag/progress
        await role('Casey Morgan'); await nav('sv-nav-home'); rows = pg.locator('[data-testid=a8-station-row]')
        if await rows.count(): await rows.first.click(); await pg.wait_for_selector('[data-testid=a8-step]'); ok(T+'station tag + progress', await pg.locator('[data-testid=a81-station-tag]').count() and await pg.locator('[data-testid=a81-progress]').count()); await shot('20_station_preop')
        ok(T+'no page errors', not errs, '; '.join(errs)[:300]); await b.close()
async def main():
    for w in WIDTHS:
        try: await run(w)
        except Exception as e: ok(f'{w}: walk aborted', False, str(e)[:300])
    f = sum(1 for r in res if not r[1]); print(f'TOTAL {len(res)-f}/{len(res)} passed'); sys.exit(1 if f else 0)
asyncio.run(main())
