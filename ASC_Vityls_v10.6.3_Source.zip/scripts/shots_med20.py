# Medical.Vityls v2.0 · Playwright walk (1440 / 1180 / 768). Role views, flags (incl. MA / Patient Coordinator / PM inboxes),
# missing-note to-do → near-full-screen note page (H&P/SOAP/Simple, Nightingale draft, PIN sign), focused panels, medical to-dos,
# workspaces (5 steps), provider isolation + covering, chat-only mode, and a surgical-wording scan of every page visited.
import asyncio, os, re, json
from playwright.async_api import async_playwright
URL='file:///workspace/vityls/src_v6/vityls_final_build/release/Medical_Vityls_v2.0/index.html'
OUT='/workspace/vityls/report/medical_v2.0_screens'; os.makedirs(OUT, exist_ok=True)
BAD=re.compile(r'\b(surg\w*|ASC|pre-?op\w*|post-?op\w*|quotes?|price quote|deposit|clearance|procedures?|operative|PACU|anesthesia|blepharoplasty|rhinoplasty|abdominoplasty|facelift|liposuction|cosmetic)\b',re.I)
ALLOW=re.compile(r'past surgical history|surgical history|PSH',re.I)
R=[]; HITS={}
def ok(n,c): R.append((n,bool(c))); print(('PASS ' if c else 'FAIL ')+n, flush=True)
async def run(W,H):
  async with async_playwright() as p:
    b=await p.chromium.launch(executable_path='/usr/bin/google-chrome'); pg=await (await b.new_context(viewport={'width':W,'height':H})).new_page(); errs=[]
    pg.on('pageerror',lambda e:errs.append(str(e)))
    L=lambda t: pg.locator(f'[data-testid={t}]')
    async def scan(where):
      t=ALLOW.sub('',await pg.locator('body').inner_text())
      for m in BAD.finditer(t): HITS.setdefault(m.group(0).lower(),set()).add(where)
    async def shot(n):
      await pg.evaluate("()=>{const t=document.querySelector('[data-testid=sv-toast]'); if(t) t.style.visibility='hidden'}"); await pg.screenshot(path=f'{OUT}/{W}_{n}.png'); await scan(n)
    async def tid(t): await L(t).first.click(timeout=8000); await pg.wait_for_timeout(500)
    async def home():
      if await pg.locator('[data-nav=drawer]').count() and not await pg.locator('[data-testid=fd-side].open').count(): await pg.locator('[data-testid=fd-hamburger]').click(); await pg.wait_for_timeout(300)
      await pg.locator('[data-testid=sv-logo]').first.click(); await pg.wait_for_timeout(700)
    async def nav(t):
      if await pg.locator('[data-nav=drawer]').count() and not await pg.locator('[data-testid=fd-side].open').count(): await pg.locator('[data-testid=fd-hamburger]').click(); await pg.wait_for_timeout(300)
      await L(t).first.click(); await pg.wait_for_timeout(800)
    async def be(name):
      await L('acting-as').first.select_option(name); await pg.wait_for_timeout(700)
      if not await L('fd-chat-home').count(): await home()
      await pg.evaluate('()=>window.scrollTo(0,0)')
    async def close_ws():
      for s in ['[data-testid=ws-save]','[data-testid=v17-panel-save]','[data-testid=v17-note-save]']:
        if await pg.locator(s).count(): await pg.locator(s).first.click(); await pg.wait_for_timeout(500); return
      await pg.keyboard.press('Escape'); await pg.wait_for_timeout(500)
    await pg.goto(URL+'?reset-test-data'); await pg.wait_for_timeout(3000)
    ok(f'{W} title is Medical.Vityls v2.0', 'Medical.Vityls v2.0' in await pg.title())
    ok(f'{W} default entry is the chat page with My to-do', await L('fd-chat-home').count()==1 and await L('v17-todo').count()==1)
    # front office
    await be('Front Desk Tester')
    roles=await pg.locator('[data-testid=v17-todo-item]').evaluate_all("e=>e.map(x=>x.dataset.role)")
    ok(f'{W} front sees only front-office items ({len(roles)})', len(roles)>0 and all(r=='front' for r in roles))
    txt=await L('v17-todo').inner_text()
    ok(f'{W} front: follow-up to book (Nightingale, from jots)', 'Follow-up to book' in txt)
    await shot('01_front_today')
    fl=pg.locator('[data-testid=v17-todo-item][data-kind=flag]')
    ok(f'{W} front sees the nursing→front flag', await fl.count()>=1)
    await fl.first.click(); await pg.wait_for_timeout(500); await L('v17-flag-reply').fill('Called Rosa; she will bring both inhalers.'); await shot('02_flag_reply'); await tid('v17-panel-save')
    # nursing
    await be('Casey Morgan')
    roles=await pg.locator('[data-testid=v17-todo-item]').evaluate_all("e=>e.map(x=>x.dataset.role)")
    ok(f'{W} nursing sees only nursing items', len(roles)>0 and all(r=='clinical' for r in roles))
    if await L('v17-todo-more').count(): await tid('v17-todo-more')
    txt=await L('v17-todo').inner_text()
    ok(f'{W} nursing: lab to review + referral to send', 'Review lab' in txt and 'Referral to send' in txt)
    ok(f'{W} nursing: answer to the flag came back', await pg.locator('[data-testid=v17-todo-item][data-kind=answer]').count()>=1)
    await shot('03_nursing_today')
    lab=pg.locator('[data-testid=v17-todo-item][data-kind=lab]').filter(has_text='TSH')
    if await lab.count():
      await lab.first.click(); await pg.wait_for_timeout(500); ok(f'{W} lab panel shows only that lab', await pg.locator('[data-panel=lab]').count()==1); await shot('04_missing_item_lab'); await tid('v17-panel-save')
    else: ok(f'{W} TSH lab to-do present', False)
    await tid('v17-flag-new')
    ok(f'{W} flag dialog offers all 5 teams', all([await L(f'v17-flag-to-{r}').count()==1 for r in ['front','clinical','ma','coord','pm']]))
    await tid('v17-flag-to-coord'); await L('v17-flag-text-in').fill('Please get prior authorization for Gerald’s thyroid ultrasound.'); await shot('05_flag_to_coordinator'); await tid('v17-panel-save')
    # doctor
    await be('Sam Patel, MD')
    ok(f'{W} doctor view', await L('v17-todo').get_attribute('data-view')=='doctor')
    notes=pg.locator('[data-testid=v17-todo-item][data-kind=note]'); n=await notes.count()
    ok(f'{W} doctor sees missing/unsigned note to-dos ({n})', n>=2)
    txt=await L('v17-todo').inner_text()
    ok(f'{W} missing notes never Overdue', 'Overdue' not in txt)
    ok(f'{W} refill drafted for the doctor to review (not ordered)', 'Refill drafted' in txt)
    ok(f'{W} doctor sees none of Dr. Whitfield\'s patients', 'Priya' not in txt and 'Rosa' not in txt)
    await shot('06_doctor_today')
    await notes.filter(has_text='Harold').first.click(); await pg.wait_for_timeout(700)
    ok(f'{W} note page opens near full screen', await L('v17-note').count()==1 and (await L('v17-note').bounding_box())['width']>=W*0.9)
    ok(f'{W} note page: name + brief', 'Harold Brennan' in await L('v17-note-name').inner_text() and 'year-old' in await L('v17-note-brief').inner_text())
    t=await L('v17-note-text').input_value()
    ok(f'{W} Nightingale draft carries PMH, meds and jots', all(x in t for x in ['Type 2 diabetes','Lisinopril','A1c 7.4']))
    await tid('v17-type-hp'); ok(f'{W} H&P switch drafts H&P', 'HPI' in await L('v17-note-text').input_value())
    await shot('07_note_page_hp')
    await tid('v17-type-soap'); ok(f'{W} SOAP re-drafts', 'SUBJECTIVE' in await L('v17-note-text').input_value()); await shot('08_note_page_soap')
    await tid('v17-type-simple'); await tid('v17-note-dictate'); ok(f'{W} dictation (simulated) adds text', 'Dictated, simulated' in await L('v17-note-text').input_value())
    await tid('v17-note-sign'); await L('pin-input').fill('1234'); await tid('pin-confirm'); await pg.wait_for_timeout(700)
    ok(f'{W} signed with PIN → off the to-do', await pg.locator('[data-testid=v17-todo-item][data-kind=note]').filter(has_text='Harold').count()==0)
    rf=pg.locator('[data-testid=v17-todo-item]').filter(has_text='Refill drafted')
    if await rf.count():
      await rf.first.click(); await pg.wait_for_timeout(800); ok(f'{W} refill opens its own review panel', await pg.locator('[data-panel=refill]').count()==1); await shot('09_refill_review'); await tid('v17-panel-save')
      ok(f'{W} approved refill leaves the to-do', await pg.locator('[data-testid=v17-todo-item]').filter(has_text='Refill drafted').count()==0)
    await tid('v17-all-roles'); await shot('10_all_roles')
    if await L('v17-todo-more').count(): await tid('v17-todo-more')
    tags=await pg.locator('[data-testid=v17-role-tag]').evaluate_all("e=>[...new Set(e.map(x=>x.textContent))]")
    ok(f'{W} See all roles shows every role tagged ({tags})', len(tags)>=3); await tid('v17-my-role')
    # flag inboxes (MA, Patient Coordinator, PM)
    for who,box,txt in [('Morgan Avery','ma','Rosa'),('Riley Shaw','coord','Harold'),('Pat Quinn','pm','phone')]:
      await be(who); ib=pg.locator(f'[data-testid=v18-flag-inbox][data-box={box}]')
      ok(f'{W} {who}: own flag list ({box})', await ib.count()==1 and txt in await ib.inner_text())
      if await ib.count(): await ib.scroll_into_view_if_needed()
      await shot(f'11_flags_{box}')
    await be('Riley Shaw'); ok(f'{W} Patient Coordinator received the new nursing flag', 'prior authorization' in await pg.locator('[data-testid=v18-flag-inbox][data-box=coord]').inner_text())
    # workspaces via patients/chart
    await be('Casey Morgan'); await nav('sv-nav-patients')
    ok(f'{W} staff see both doctors\' patients', await L('patient-MED-4101').count()==1 and await L('patient-MED-4201').count()==1)
    await L('v18-provider-filter').select_option('Dana Whitfield, MD'); await pg.wait_for_timeout(600)
    ok(f'{W} provider filter narrows to Dr. Whitfield', await L('patient-MED-4201').count()==1 and await L('patient-MED-4101').count()==0); await shot('12_patients_filter')
    await L('v18-provider-filter').select_option(''); await pg.wait_for_timeout(400)
    await L('patient-MED-4102').first.click(); await pg.wait_for_timeout(1200); await shot('13_chart'); 
    await nav('sv-nav-schedule'); await pg.wait_for_timeout(800); await shot('14_schedule')
    ok(f'{W} schedule shows In Office / Video / Phone', await pg.locator('[data-testid=appt-mode-icon][data-mode=video]').count()>=1 and await pg.locator('[data-testid=appt-mode-icon][data-mode=phone]').count()>=1)
    # workspaces through the window helper used by chat cards
    for ws,pid,vid in [('front','MED-4203','visit-m20-rosa'),('nurse','MED-4102','visit-m20-alicia'),('doctor','MED-4102','visit-m20-alicia'),('checkout','MED-4102','visit-m20-alicia')]:
      okk=await pg.evaluate("([id,pid,vid])=>{ window.dispatchEvent(new CustomEvent('flow-open-ws',{detail:{id,pid,vid}})); return true }",[ws,pid,vid])
      if not okk: break
      await pg.wait_for_timeout(900); ok(f'{W} {ws} workspace opens', await L(f'ws-{ws}').count()==1)
      if ws=='doctor': ok(f'{W} doctor workspace: no price quote / decision tabs', await L('doc-tab-quote').count()==0 and await L('doc-tab-plan').count()==0)
      await shot(f'15_ws_{ws}'); await close_ws()
    # provider isolation + covering
    await be('Sam Patel, MD'); await nav('sv-nav-patients')
    ok(f'{W} Dr. Patel sees only his patients', await L('patient-MED-4201').count()==0 and await L('patient-MED-4101').count()==1)
    if await L('v18-cover-open').count():
      await tid('v18-cover-open'); await L('v18-cover-patient').select_option('MED-4201'); await L('v18-cover-reason').fill('Covering for Dr. Whitfield today'); await shot('16_cover_dialog'); await tid('v18-cover-go'); await pg.wait_for_timeout(800)
      aud=await pg.evaluate("()=>Object.keys(localStorage).some(k=>/audit/i.test(k)&&localStorage.getItem(k).includes('Covering for Dana Whitfield'))")
      ok(f'{W} covering is audit-logged', aud)
    else: ok(f'{W} cover link present', False)
    await be('Dana Whitfield, MD')
    txt=await L('v17-todo').inner_text(); ok(f'{W} Dr. Whitfield: her own missing note (Priya), none of Dr. Patel\'s', 'Priya' in txt and 'Alicia' not in txt); await shot('17_whitfield_today')
    # chat-only
    await be('Pat Quinn'); await tid('v18-co-toggle')
    ok(f'{W} PM can set chat-only default per role', await L('v18-co-role-front-desk').count()==1)
    await L('v18-co-role-front-desk').check(); await pg.wait_for_timeout(300); await tid('v18-co-toggle')
    await L('acting-as').first.select_option('Front Desk Tester'); await pg.wait_for_timeout(900)
    ok(f'{W} chat-only on for Front desk', await L('surgery-app').get_attribute('data-chatonly')=='1' and not await L('fd-side').is_visible())
    await shot('18_chat_only')
    await tid('v18-co-toggle'); await L('v18-co-me').uncheck(); await pg.wait_for_timeout(400)
    ok(f'{W} chat-only can be turned off', await L('surgery-app').get_attribute('data-chatonly')=='0')
    # practice settings scan (admin)
    await be('Practice Administrator')
    for t in ['sv-nav-billing','sv-nav-forms']:
      if await L(t).count(): await nav(t); await pg.wait_for_timeout(600); await scan('nav:'+t)
    ok(f'{W} no page errors', not errs)
    if errs: print(errs[:3])
    await b.close()
async def main():
  for W,H in [(1440,900),(1180,820),(768,1024)]: await run(W,H)
  print('\nSURGICAL WORDING HITS:', json.dumps({k:sorted(v)[:6] for k,v in HITS.items()}, indent=0))
  json.dump({k:sorted(v) for k,v in HITS.items()}, open(OUT+'/wording_hits.json','w'), indent=1)
  f=[n for n,c in R if not c]; print(f'\n{len(R)-len(f)}/{len(R)} passed'); [print('FAIL',x) for x in f]
asyncio.run(main())
