"""ASC.Vityls v8.7 walkthrough (Playwright + Chrome). Usage: python3 scripts/walk82.py [URL] [WIDTH...]. Fictional data; test PIN 1234."""
import asyncio, sys, os
from playwright.async_api import async_playwright
URL = sys.argv[1] if len(sys.argv) > 1 else 'http://localhost:8798/'
WIDTHS = [int(w) for w in sys.argv[2:]] or [1440, 1024, 390]
OUT = '/workspace/vityls/report/asc_v8.7_screens/best/'; os.makedirs(OUT, exist_ok=True)
CARD = '/tmp/fake_card.png'
res = []
def ok(name, cond, note=''): res.append((name, bool(cond), note)); print(('PASS' if cond else 'FAIL'), name, note, flush=True)
async def run(w):
    async with async_playwright() as p:
        b = await p.chromium.launch(executable_path='/usr/bin/google-chrome'); pg = await b.new_page(viewport={'width': w, 'height': 900 if w > 500 else 844}); pg.set_default_timeout(8000)
        errs = []; pg.on('pageerror', lambda e: errs.append(str(e))); pg.on('dialog', lambda d: asyncio.ensure_future(d.accept()))
        await pg.goto(URL + '?reset-test-data'); await pg.wait_for_timeout(2500)
        T = f'{w}:'
        async def shot(n):
            await pg.evaluate("()=>document.querySelectorAll('.a81-dbody,.a8-body').forEach(e=>e.scrollTop=0)"); await pg.screenshot(path=f'{OUT}{w}_{n}.png', full_page=True)
        async def noscroll(where):
            sw = await pg.evaluate('()=>document.documentElement.scrollWidth - window.innerWidth'); ok(T+f'no sideways scroll · {where}', sw <= 1, f'+{sw}px')
        async def role(label):
            s = pg.locator('select').first; opts = await s.evaluate("s=>[...s.options].map(o=>o.text)"); await s.select_option(label=[o for o in opts if label in o][0]); await pg.wait_for_timeout(600)
        async def nav(tid):
            await pg.locator(f'[data-testid={tid}]').first.evaluate('e=>e.click()'); await pg.wait_for_timeout(700)
        async def draw(sel):
            c = pg.locator(sel).first; await c.scroll_into_view_if_needed(); bb = await c.bounding_box()
            x, y = bb['x'] + 20, bb['y'] + bb['height'] / 2
            await pg.mouse.move(x, y); await pg.mouse.down()
            for i in range(1, 12): await pg.mouse.move(x + i * 14, y + (12 if i % 2 else -12))
            await pg.mouse.up(); await pg.wait_for_timeout(150)
        async def sign(who=None):
            await pg.wait_for_selector('[data-testid=pin-sign]')
            if who:
                opts = await pg.eval_on_selector('[data-testid=pin-who]', "s=>[...s.options].map(o=>o.text)"); await pg.select_option('[data-testid=pin-who]', label=[o for o in opts if who in o][0])
            else:
                v = await pg.eval_on_selector('[data-testid=pin-who]', 'e=>e.value')
                if not v: await pg.select_option('[data-testid=pin-who]', index=1)
            await draw('[data-testid=pin-sigpad-canvas]')
            await pg.fill('[data-testid=pin-input]', '1234'); await pg.click('[data-testid=pin-confirm]'); await pg.wait_for_timeout(500)
        async def bench(chip, patient=None):
            if await pg.locator('[data-testid=a81-close]').count(): await pg.click('[data-testid=a81-close]')
            await nav('sv-nav-home'); a = pg.locator('[data-testid=a81-chip-all]')
            if await pg.locator(f'[data-testid=a81-chip-{chip}]').count() == 0 and await a.count(): await a.click()
            await pg.click(f'[data-testid=a81-chip-{chip}]'); await pg.wait_for_selector(f'[data-testid=a81-bench-{chip}]')
            if patient:
                opts = await pg.eval_on_selector('[data-testid=a81-case-pick]', "s=>[...s.options].map(o=>o.text)"); await pg.select_option('[data-testid=a81-case-pick]', label=[o for o in opts if patient in o][0]); await pg.wait_for_timeout(300)
        async def fillsel(tid):
            v = await pg.eval_on_selector(f'[data-testid={tid}]', 'e=>e.value')
            if not v: await pg.select_option(f'[data-testid={tid}]', index=1)
        async def close_forms():
            for _ in range(3):
                x = pg.locator('.a82-form [aria-label="Close form"]')
                if await pg.locator('.a82-form').count() and await x.count(): await x.first.click(); await pg.wait_for_timeout(400)
        await pg.evaluate("()=>{window.print=()=>{window.__printed=(window.__printed||0)+1}}")
        LS = lambda: pg.evaluate("()=>JSON.stringify(Object.values(localStorage))")
        await role('Front Desk Tester'); await nav('sv-nav-home'); await pg.wait_for_timeout(600)
        ok(T+'old sections removed', await pg.locator('[data-testid=a86-worklist],[data-testid=a81-bench-chips]').count() == 0)
        ok(T+'today timeline cards', await pg.locator('[data-testid=a87-card]').count() >= 1)
        ok(T+'to-do + Nightingale panel', await pg.locator('[data-testid=a87-todo]').count() == 1 and await pg.locator('[data-testid=a87-ng]').count() == 1)
        await noscroll('today'); await shot('01_today')
        if w < 500: return
        await pg.locator('[data-testid=a87-todo]').screenshot(path=f'{OUT}{w}_03_todo.png'); await pg.locator('[data-testid=a87-ng]').screenshot(path=f'{OUT}{w}_03b_nightingale.png')
        # check-in today opens dialog
        ci = pg.locator('[data-testid=a87-checkin]')
        if await ci.count():
            await ci.first.click(); await pg.wait_for_timeout(500); ok(T+'check in opens dialog (today)', await pg.locator('[data-testid=a83-checkin]').count() >= 1)
            await pg.keyboard.press('Escape'); x = pg.locator('[aria-label=Close],[data-testid=a8-close],[data-testid=a81-close]')
            if await x.count(): await x.first.click()
            await pg.wait_for_timeout(300)
        # tomorrow: Hugo, no check-in, no station chips
        await pg.click('[data-testid=a87-next]'); await pg.wait_for_timeout(500); t = await pg.inner_text('[data-testid=a87-patients]')
        ok(T+'tomorrow shows Hugo', 'Hugo' in t); ok(T+'future: no check-in, no station chips', await pg.locator('[data-testid=a87-checkin]').count() == 0 and await pg.locator('[data-testid=a84-ws-chips]').count() == 0)
        await pg.click('[data-testid=a87-today-btn]'); await pg.wait_for_timeout(400)
        # upload
        open('/tmp/a87_clear.txt','w').write('Fictional clearance letter (test)'); open('/tmp/a87_ecg.txt','w').write('Fictional ECG (test)')
        await pg.click('[data-testid=a87-upload-open]'); await pg.wait_for_timeout(400)
        q = pg.locator('[data-testid=a87-up-q]')
        if await q.count(): await q.fill('Hugo'); await pg.wait_for_timeout(300)
        h = pg.locator('[data-testid=a87-up-hit]')
        if await h.count(): await h.first.click()
        await fillsel('a87-up-ep'); await pg.set_input_files('[data-testid=a87-up-files]', ['/tmp/a87_clear.txt', '/tmp/a87_ecg.txt']); await pg.wait_for_timeout(400)
        ok(T+'two files queued', await pg.locator('[data-testid=a87-up-list] li, [data-testid=a87-up-list] tr').count() >= 2)
        await shot('02_upload'); await pg.click('[data-testid=a87-up-save]'); await pg.wait_for_timeout(500)
        s = await LS(); ok(T+'upload stored + audited', 'a87_clear.txt' in s and 'asc87.upload' in s)
        # orders from standard list: adjust dose, PIN-sign, history shows original
        go = pg.locator('[data-testid=a87-todo-go-orders]')
        ok(T+'orders to-do present', await go.count() >= 1)
        await go.first.click(); await pg.wait_for_timeout(700)
        await pg.locator('[data-testid=a86-ord-new]').first.click(); await pg.wait_for_timeout(400)
        ok(T+'draft pulls standard list w/ example doses', await pg.locator('[data-testid=a86-ord-val-0]').count() == 1 and (await pg.input_value('[data-testid=a86-ord-val-0]')) != '')
        await pg.fill('[data-testid=a86-ord-val-0]', '3 g'); await pg.wait_for_timeout(200)
        await pg.click('[data-testid=a86-ord-sign-open]'); await sign()
        await pg.click('[data-testid=a86-ord-history] summary'); ht = await pg.inner_text('[data-testid=a86-ord-history]')
        ok(T+'history keeps original vs adjusted dose', 'adjusted from standard' in ht, ht[:200]); await shot('05_orders_adjusted')
        if await pg.locator('[data-testid=a81-close]').count(): await pg.click('[data-testid=a81-close]')
        # invoice via to-do / billing hub
        await role('Front Desk Tester'); await nav('sv-nav-billing'); await pg.wait_for_timeout(500)
        tb = pg.locator('[role=tab]', has_text='Cash-pay invoices'); ok(T+'billing hub invoices tab', await tb.count() == 1)
        await tb.click(); await pg.wait_for_timeout(400); await pg.locator('[data-testid=a87-inv-row]', has_text='Self-pay').first.locator('[data-testid=a87-inv-open]').click(); await pg.wait_for_timeout(500)
        g = pg.locator('[data-testid=a87-inv-gen]')
        if await g.count(): await g.first.click(); await pg.wait_for_timeout(400)
        it = await pg.inner_text('[data-testid=a87-inv-doc]'); ok(T+'invoice number + lines', 'INV-ASC-' in it and await pg.locator('[data-testid=a87-inv-line]').count() >= 1)
        await pg.click('[data-testid=a87-inv-print]'); ok(T+'manual print logged', (await pg.evaluate('window.__printed||0')) >= 1)
        await shot('06_invoice')
        if not await pg.locator('[data-testid=a87-inv-amt]').count():
            await pg.keyboard.press('Escape'); x = pg.locator('[aria-label=Close]')
            if await x.count(): await x.first.click()
            await nav('sv-nav-home'); c = pg.locator('[data-testid=a87-todo-go-payment]')
            if await c.count(): await c.first.click(); await pg.wait_for_timeout(500)
            g = pg.locator('[data-testid=a87-inv-gen]')
            if await g.count(): await g.first.click(); await pg.wait_for_timeout(400)
        ok(T+'record payment available', await pg.locator('[data-testid=a87-inv-amt]').count() == 1)
        if await pg.locator('[data-testid=a87-inv-amt]').count():
            await pg.fill('[data-testid=a87-inv-amt]', '100'); await pg.click('[data-testid=a87-inv-record]'); await pg.wait_for_timeout(500)
            st = await pg.inner_text('[data-testid=a87-inv-status]'); ok(T+'payment recorded → status', 'paid' in st.lower(), st)
        await pg.keyboard.press('Escape'); x = pg.locator('[aria-label=Close]')
        if await x.count(): await x.first.click()
        # chart back link
        await nav('sv-nav-home'); await pg.wait_for_timeout(400); kf = pg.locator('[data-testid=a87-kf-payment]')
        if await kf.count(): await kf.click(); await pg.wait_for_timeout(300)
        pt = pg.locator('[data-testid=a87-todo-go-payment]'); ok(T+'payment to-do in 7–14 day window', await pt.count() >= 1)
        if await pt.count():
            await pt.first.click(); await pg.wait_for_timeout(500); ok(T+'payment to-do opens invoice', await pg.locator('[data-testid=a87-inv-doc]').count() == 1)
            await pg.keyboard.press('Escape'); x = pg.locator('[aria-label=Close]')
            if await x.count(): await x.first.click()
            await pg.wait_for_timeout(300)
        await pg.locator('[data-testid=a87-chart]').first.click(); await pg.wait_for_timeout(700)
        bk = pg.locator('[data-testid=a87-chart-back]'); ok(T+'chart back link present', await bk.count() == 1)
        bb = await bk.bounding_box(); ok(T+'back link at left edge', bb and bb['x'] < 320, str(bb and bb['x']))
        await pg.screenshot(path=f'{OUT}{w}_07_chart_back.png'); await bk.click(); await pg.wait_for_timeout(500)
        ok(T+'back link returns to patient list', await pg.locator('[data-testid=a87-chart-back]').count() == 0)
        # practice settings: standard orders list, removed sections
        await role('Practice Administrator'); await nav('sv-nav-forms'); await pg.wait_for_timeout(700)
        std = pg.locator('[data-testid=a87-standing]'); ok(T+'standard orders list in practice settings', await std.count() == 1)
        if await std.count():
            ok(T+'example label on seeded rows', await pg.locator('[data-testid=a87-std-ex]').count() >= 12)
            await std.scroll_into_view_if_needed(); await std.screenshot(path=f'{OUT}{w}_04_standing_orders.png')
        body = await pg.inner_text('body'); ok(T+'surgeon colors section gone', 'Surgeon colors on the schedule' not in body)
        ok(T+'no page errors', not errs, '; '.join(errs[:2]))

async def main():
    for w in WIDTHS: await run(w)
    f = [r for r in res if not r[1]]; print(f'{len(res)-len(f)}/{len(res)} passed'); [print('FAIL', *r) for r in f]
asyncio.run(main())
