import re
from v8part import pin
TERMS=re.compile(r"surgeon|surgery|surgical|procedure|\bASC\b|\bOR \d|PACU|anesth|operative|pre-?op\b|post-?op\b|blephar|facelift|rhinopl|abdominopl|mammapl|cosmetic|filler|neuromod|botox|eyelid|plastic surg",re.I)
# Justified residual terms (medical-history vocabulary, not surgical-office features)
ALLOW=[r'Past surgical history', r'PAST SURGICAL HISTORY', r'Surgical history', r'surgical history', r'Open Surgical history', r'anesthesia', r'Anesthesia', r'malignant hyperthermia', r'after surgery in \d{4}', r'Laparoscopic cholecystectomy', r'Cesarean section', r'Tonsillectomy', r'Cataract surgery', r'Coronary stent']
GRAB="""()=>{const out=[];const take=(d)=>{if(!d||!d.body)return;out.push(d.body.innerText);d.querySelectorAll('[placeholder],[title],[aria-label]').forEach(e=>{['placeholder','title','aria-label'].forEach(a=>{const v=e.getAttribute(a);if(v)out.push(v)});});d.querySelectorAll('iframe').forEach(f=>{try{take(f.contentDocument)}catch(e){}})};take(document);out.push(document.title);return out.join('\\n')}"""
def residual(text):
    bad=[]
    for line in text.split('\n'):
        t=line
        for a in ALLOW: t=re.sub(a,'',t)
        if TERMS.search(t): bad.append(line.strip()[:140])
    return bad
async def medical(pg, W, ok, shot, c, noover):
    BASE=pg.url.split('?')[0]
    await pg.goto(BASE+'?reset-test-data'); await pg.wait_for_timeout(1500)
    await pg.select_option('[data-testid=acting-as]', value='Morgan Avery'); await pg.wait_for_timeout(300)
    ok(f'{W} M: title Medical.Vityls', 'Medical.Vityls' in await pg.title())
    ok(f'{W} M: edition flag MEDICAL', await pg.evaluate("document.documentElement.dataset.edition")=='MEDICAL')
    ok(f'{W} M: storage in Medical namespace only', await pg.evaluate("()=>{let m=0,s=0;for(let i=0;i<window.localStorage.length;i++){} return 1}")==1)
    allbad={}
    async def audit(where):
        for b in residual(await pg.evaluate(GRAB)): allbad.setdefault(b,set()).add(where)
    await audit('today'); await shot('m01_today')
    await c('[data-testid=sv-nav-schedule]'); await pg.wait_for_timeout(500); await audit('schedule'); await shot('m02_schedule_day')
    ok(f'{W} M: schedule has no ASC toggle/block/cases', await pg.locator('[data-testid=toggle-asc]').count()==0 and await pg.locator('[data-testid=asc-case]').count()==0 and await pg.locator('[data-testid=sched-upcoming]').count()==0)
    if await pg.locator('[data-testid=view-week]').count(): await c('[data-testid=view-week]'); await pg.wait_for_timeout(400); await audit('schedule-week'); await shot('m03_schedule_week')
    await c('[data-testid=sv-nav-patients]'); await pg.wait_for_timeout(400); await audit('patients'); await shot('m04_patients')
    th=' '.join(await pg.locator('[data-testid=sv-patient-list] thead th').all_inner_texts())
    ok(f'{W} M: Patients column "Diagnosis" ({th})', 'diagnosis' in th.lower() and 'procedure' not in th.lower() and 'treatment' not in th.lower())
    cells=' '.join(await pg.locator('[data-testid=dx-cell]').all_inner_texts())
    ok(f'{W} M: primary-care diagnoses seeded', 'diabetes' in cells.lower() and 'hypertension' in cells.lower())
    n=await pg.locator('[data-testid=sv-patient-list] tbody tr').count()
    for i in range(min(n,6)):
        await c('[data-testid=sv-nav-patients]'); await pg.wait_for_timeout(300)
        await pg.locator('[data-testid=sv-patient-list] tbody tr').nth(i).locator('button').first.click(); await pg.wait_for_timeout(500)
        for tab in ['overview','clinical','documents','photos','notes','activity']:
            l=pg.locator(f'[data-testid^=chart-tab-{tab}]')
            if await l.count(): await l.first.click(); await pg.wait_for_timeout(250); await audit(f'chart{i}-{tab}')
            if i==0: await shot(f'm1{["overview","clinical","documents","photos","notes","activity"].index(tab)}_chart_{tab}')
    await c('[data-testid=chart-tab-overview]'); await pg.wait_for_timeout(200)
    ok(f'{W} M: chart risk card says "Significant risk factors"', 'significant risk' in (await pg.inner_text('[data-testid=sv-chart]')).lower())
    await c('[data-testid=sv-nav-messages]'); await pg.wait_for_timeout(400); await audit('messages'); await shot('m20_messages')
    ok(f'{W} M: Messages has no ASC threads list', 'ASC' not in await pg.inner_text('.sv-main') if await pg.locator('.sv-main').count() else True)
    await c('[data-testid=sv-nav-home]'); await pg.wait_for_timeout(300)
    await pg.locator('[data-testid=dash-card]').first.click(); await pg.wait_for_timeout(200); await c('[data-testid=dash-checkin]'); await pg.wait_for_timeout(600)
    steps=[t.strip() for t in await pg.locator('nav.sv-steps [role=tab]').all_inner_texts()]
    ok(f'{W} M: Doctor step, no Surgeon step ({steps})', any('Doctor' in s for s in steps) and not any('Surgeon' in s for s in steps))
    for i,tb in enumerate(steps):
        await pg.locator('nav.sv-steps [role=tab]').nth(i).click(); await pg.wait_for_timeout(500); await audit('station-'+tb)
        await shot(f'm3{i}_station_{re.sub(r"[^a-z]+","_",tb.lower()).strip("_")}')
    ok(f'{W} M: no Send to ASC at Checkout', await pg.get_by_text(re.compile('Send (request )?to ASC', re.I)).count()==0)
    await c('[data-testid=sv-nav-practice]'); await pg.wait_for_timeout(300); await pin(pg,'Pat Quinn'); await pg.wait_for_timeout(400); await audit('practice'); await shot('m40_practice')
    tabs=await pg.locator('[data-testid^=prac-]').evaluate_all("es=>es.map(e=>e.dataset.testid)")
    for t in tabs:
        await c('[data-testid=sv-nav-practice]'); await pg.wait_for_timeout(300)
        if await pg.locator('[data-testid=pin-sign]').count(): await pin(pg,'Pat Quinn')
        await c(f'[data-testid={t}]'); await pg.wait_for_timeout(700); await audit('practice-'+t); await shot(f'm4{tabs.index(t)+1}_{t}')
        if t=='prac-surgery-settings':
            ok(f'{W} M: no surgical modules / surgery centers in settings', await pg.locator('[data-testid=mod-table]').count()==0 and 'Surgery centers' not in await pg.inner_text('.sv-main'))
        if t=='prac-ops-hub':
            ok(f'{W} M: no ASC utilization / surgeries KPI', await pg.locator('[data-testid=perf-asc]').count()==0 and await pg.locator('[data-testid=kpi-surgeries]').count()==0)
    await c('[data-testid=open-portal]'); await pg.wait_for_timeout(500); await audit('portal-signin')
    await pg.locator('[data-testid=portal-signin] button').nth(1).click(); await pg.wait_for_timeout(500); await audit('portal'); await shot('m50_portal')
    for k,v in sorted(allbad.items()): print('RESIDUAL', k, '<<', ','.join(sorted(v))[:80])
    ok(f'{W} M: text audit, no unjustified surgical/ASC terms ({len(allbad)})', len(allbad)==0)
