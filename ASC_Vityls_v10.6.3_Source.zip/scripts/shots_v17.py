# Surgery.Vityls v1.7 · Playwright walk (1440 / 1180 / 768): role Today (chat) views for Front office, Nursing, Doctor, See all roles,
# missing-note to-dos → near-full-screen note page with Nightingale draft → Save & close / Sign with PIN, focus panels, flags both ways.
import asyncio, os, sys
from playwright.async_api import async_playwright
URL='file:///workspace/vityls/src_v6/vityls_final_build/release/Surgery_Vityls_v1.7/index.html'
OUT='/workspace/vityls/report/surgery_v1.7_screens'; os.makedirs(OUT, exist_ok=True)
R=[]
def ok(n,c): R.append((n,bool(c))); print(('PASS ' if c else 'FAIL ')+n, flush=True)
async def run(W,H):
  async with async_playwright() as p:
    b=await p.chromium.launch(executable_path='/usr/bin/google-chrome'); pg=await (await b.new_context(viewport={'width':W,'height':H})).new_page(); errs=[]
    pg.on('pageerror',lambda e:errs.append(str(e)))
    async def shot(n):
      await pg.evaluate("()=>{const t=document.querySelector('[data-testid=sv-toast]'); if(t) t.style.visibility='hidden'}"); await pg.screenshot(path=f'{OUT}/{W}_{n}.png')
    L=lambda t: pg.locator(f'[data-testid={t}]')
    async def tid(t): await L(t).first.click(timeout=8000); await pg.wait_for_timeout(500)
    async def home():
      if await pg.locator('[data-nav=drawer]').count() and not await pg.locator('[data-testid=fd-side].open').count(): await pg.locator('[data-testid=fd-hamburger]').click(); await pg.wait_for_timeout(300)
      await pg.locator('[data-testid=sv-logo]').first.click(); await pg.wait_for_timeout(700)
    async def be(name):
      await L('acting-as').first.select_option(name); await pg.wait_for_timeout(700)
      if not await L('fd-chat-home').count(): await home()
      await pg.evaluate('()=>window.scrollTo(0,0)')
    async def todo_shot(n):
      await L('v17-todo').scroll_into_view_if_needed(); await shot(n)
    await pg.goto(URL+'?reset-test-data'); await pg.wait_for_timeout(2800)
    ok(f'{W} default entry is the chat page', await L('fd-chat-home').count()==1)
    ok(f'{W} chat page carries My to-do', await L('v17-todo').count()==1)
    ok(f'{W} chat chips trimmed (no Unsigned notes / Messages duplicates)', await L('fd-chip-unsigned').count()==0 and await L('fd-chip-messages').count()==0)
    # ---- Front office ----
    await be('Front Desk Tester')
    ok(f'{W} front view', await L('v17-todo').get_attribute('data-view')=='front')
    roles=await pg.locator('[data-testid=v17-todo-item]').evaluate_all("e=>e.map(x=>x.dataset.role)")
    ok(f'{W} front sees only front-office items ({len(roles)})', len(roles)>0 and all(r=='front' for r in roles))
    ok(f'{W} front sees the nursing→front flag', await pg.locator('[data-testid=v17-todo-item][data-kind=flag]').count()>=1)
    ok(f'{W} front menu: Billing yes', await L('sv-nav-billing').count()>=1)
    await todo_shot('01_front_today')
    await pg.locator('[data-testid=v17-todo-item][data-kind=flag]').first.click(); await pg.wait_for_timeout(500)
    ok(f'{W} flag opens a focused reply panel', await pg.locator('[data-panel=flag-reply]').count()==1)
    await L('v17-flag-reply').fill('Asked at check-in; card scanned.'); await shot('06_flag_reply'); await tid('v17-panel-save')
    # ---- Nursing ----
    await be('Casey Morgan')
    ok(f'{W} nursing view', await L('v17-todo').get_attribute('data-view')=='clinical')
    roles=await pg.locator('[data-testid=v17-todo-item]').evaluate_all("e=>e.map(x=>x.dataset.role)")
    ok(f'{W} nursing sees only nursing items', len(roles)>0 and all(r=='clinical' for r in roles))
    ok(f'{W} nursing sees the doctor flag + the front-office flag', await pg.locator('[data-testid=v17-todo-item][data-kind=flag]').count()>=2)
    ok(f'{W} reply came back to nursing (answer)', await pg.locator('[data-testid=v17-todo-item][data-kind=answer]').count()>=1)
    ok(f'{W} nursing menu has no Billing settings admin items in nav', await L('sv-nav-forms').count()>=1)
    await todo_shot('02_nursing_today')
    if await L('v17-todo-more').count(): await tid('v17-todo-more')
    lab=pg.locator('[data-testid=v17-todo-item][data-kind=lab]')
    ok(f'{W} lab review to-do for nursing', await lab.count()>=1)
    if await lab.count():
      await lab.first.click(); await pg.wait_for_timeout(500); ok(f'{W} lab panel shows only that lab', await pg.locator('[data-panel=lab]').count()==1); await shot('05_missing_item_lab'); await tid('v17-panel-save')
    vit=pg.locator('[data-testid=v17-todo-item]').filter(has_text='Vital signs')
    if await vit.count():
      await vit.first.click(); await pg.wait_for_timeout(500); ok(f'{W} vitals panel: just the vitals form', await pg.locator('[data-panel=vitals]').count()==1 and await L('v17-vit-rr').count()==1)
      await shot('05b_missing_item_vitals'); await L('v17-vit-sys').fill('122'); await L('v17-vit-dia').fill('78'); await L('v17-vit-hr').fill('72'); await L('v17-vit-rr').fill('14'); await tid('v17-panel-save')
    # raise a flag to front office
    await tid('v17-flag-new'); await tid('v17-flag-to-front'); await L('v17-flag-text-in').fill('Please send Owen the pre-op instructions.'); await shot('07_flag_new'); await tid('v17-panel-save')
    # ---- Doctor ----
    await be('Sam Patel, MD')
    ok(f'{W} doctor view', await L('v17-todo').get_attribute('data-view')=='doctor')
    notes=pg.locator('[data-testid=v17-todo-item][data-kind=note]'); n=await notes.count()
    ok(f'{W} doctor sees missing-note to-dos ({n})', n>=3)
    ok(f'{W} missing notes say Incomplete, never Overdue', 'Overdue' not in await L('v17-todo').inner_text())
    ok(f'{W} doctor menu trimmed (no Messages/Billing)', await L('sv-nav-messages').count()==0 and await L('sv-nav-billing').count()==0)
    ok(f'{W} doctor got the answer to his flag', await pg.locator('[data-testid=v17-todo-item][data-kind=answer]').count()>=1)
    await todo_shot('03_doctor_today')
    await notes.filter(has_text='Nora').first.click(); await pg.wait_for_timeout(700)
    ok(f'{W} note page opens near full screen', await L('v17-note').count()==1 and (await L('v17-note').bounding_box())['width']>=W*0.9)
    ok(f'{W} note page: name + brief + draft badge', 'Nora Bellweather' in await L('v17-note-name').inner_text() and '52-year-old' in await L('v17-note-brief').inner_text() and await L('v17-note-draft-badge').count()==1)
    t=await L('v17-note-text').input_value()
    ok(f'{W} H&P draft carries PMH, PSH, risk factors and jots', all(x in t for x in ['HPI','Hypothyroidism','Cholecystectomy','Smoker','R>L']))
    await shot('04_note_page_draft')
    await tid('v17-type-soap'); ok(f'{W} SOAP switch re-drafts', 'SUBJECTIVE' in await L('v17-note-text').input_value())
    await tid('v17-type-simple'); await tid('v17-note-dictate'); ok(f'{W} dictation (simulated) adds text', 'Dictated, simulated' in await L('v17-note-text').input_value())
    await tid('v17-note-save')
    ok(f'{W} Save & close keeps it on the to-do', await pg.locator('[data-testid=v17-todo-item][data-kind=note]').filter(has_text='Nora').count()==1)
    await notes.filter(has_text='Nora').first.click(); await pg.wait_for_timeout(600)
    ok(f'{W} reopened note keeps the Simple text', 'Dictated, simulated' in await L('v17-note-text').input_value())
    await tid('v17-note-sign'); await L('pin-input').fill('1234'); await tid('pin-confirm'); await pg.wait_for_timeout(600)
    ok(f'{W} signed with PIN → off the to-do', await pg.locator('[data-testid=v17-todo-item][data-kind=note]').filter(has_text='Nora').count()==0)
    sig=await pg.evaluate("()=>{const n=JSON.parse(localStorage.getItem(Object.keys(localStorage).find(k=>/med.*notes|notes$/.test(k)&&!/v17|contact|appt/.test(k)))||'{}'); return n['visit-v17-nora']?.status}")
    ok(f'{W} same record: the Doctor-station note is signed too ({sig})', sig=='signed')
    await tid('v17-all-roles'); await todo_shot('08_all_roles')
    if await L('v17-todo-more').count(): await tid('v17-todo-more')
    tags=await pg.locator('[data-testid=v17-role-tag]').evaluate_all("e=>[...new Set(e.map(x=>x.textContent))]")
    ok(f'{W} See all roles shows every role tagged ({tags})', len(tags)>=3); await tid('v17-my-role')
    ok(f'{W} no page errors', not errs);
    if errs: print(errs[:3])
    await b.close()
async def main():
  for W,H in [(1440,900),(1180,820),(768,1024)]: await run(W,H)
  f=[n for n,c in R if not c]; print(f'\n{len(R)-len(f)}/{len(R)} passed'); [print('FAIL',x) for x in f]
asyncio.run(main())
