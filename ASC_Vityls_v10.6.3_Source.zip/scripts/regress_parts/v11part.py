import re, base64, subprocess, os
from v8part import pin
from v9part import book
BASE='file:///workspace/vityls/src_v6/vityls_final_build/release/Surgery_Vityls_v1.0/index.html'
OUT='/workspace/vityls/report/frontdoor_surgery_screens'
BAD=re.compile(r'Anesthesiologist|CRNA|PACU|Circulating|OR Team|Scrub tech|Pre-op RN',re.I)
async def practice(pg, c):
    await c('[data-testid=sv-nav-practice]'); await pg.wait_for_timeout(300)
    if await pg.locator('[data-testid=pin-sign]').count(): await pin(pg, 'Pat Quinn')
async def v11(pg, W, ok, shot, c, noover):
    await pg.goto('about:blank'); await pg.goto(BASE+'?reset-test-data'); await pg.wait_for_timeout(1500)
    await pg.select_option('[data-testid=acting-as]', value='Morgan Avery'); await pg.wait_for_timeout(200)
    # 1 ---- Practice: no Form templates link / chip
    await practice(pg, c)
    body = await pg.inner_text('body')
    ok(f'{W} v11 Practice: no "Form templates & editor" link or chip', 'Form templates' not in body and 'Forms & workflow' in body)
    await shot('10_practice_no_form_templates_link', full=False)
    await pg.fill('[data-testid=nightingale-input]','form editor'); await pg.press('[data-testid=nightingale-input]','Enter'); await pg.wait_for_timeout(700)
    ok(f'{W} v11 "form editor" routes to Forms & workflow', await pg.locator('[data-testid=surgery-forms-workspace]').count()==1)
    # 6 ---- signer roles (office only)
    # v1.2 flake fix: let the forms workspace settle (it re-renders once after routing) before clicking its tab
    await pg.locator('[data-testid=surgery-forms-workspace]').wait_for(); await pg.wait_for_timeout(800)
    fl=pg.get_by_role('button', name='Form Library').first
    try: await fl.click(timeout=10000)
    except Exception: await pg.wait_for_timeout(1000); await fl.click(timeout=15000)
    await pg.wait_for_timeout(200)
    await pg.locator('.vds-card', has_text='Procedure Consent').first.get_by_role('button', name='Open').click(); await pg.wait_for_timeout(900)
    b = pg.locator('[data-testid=start-add]')
    if not await b.count(): b = pg.locator('[data-testid=edit-setup]')
    await b.click(); await pg.wait_for_timeout(200); await c('[data-testid=next-signers]'); await pg.wait_for_timeout(300)
    opts = await pg.locator('.vds-modal select').first.locator('option').all_inner_texts()
    want = ['Patient / Guardian','Front desk','Medical assistant','Nurse','Surgical coordinator','Physician assistant / NP','Surgeon / Physician','Witness']
    ok(f'{W} v11 signer roles = office list ({len(opts)})', sorted(opts)==sorted(want))
    roles_now = [await x.input_value() for x in await pg.locator('.vds-modal select').all()]
    ok(f'{W} v11 existing signer slots migrated to office roles', not any(BAD.search(r) for r in roles_now))
    await shot('60_signer_office_roles', full=False)
    await pg.locator('.vds-modal button', has_text='Back').first.click(); await pg.wait_for_timeout(150)
    await pg.locator('.vds-icon-btn').last.click(); await pg.wait_for_timeout(200)
    # ---- ASC-only roles gone everywhere
    found = []
    for t in ['Providers','Staff, coordinators & invitations']:
        await practice(pg, c); await pg.get_by_text(t).first.click(); await pg.wait_for_timeout(600)
        html = await pg.evaluate("()=>document.body.innerText.replace(/v0\\.11:[^\\n]*/g,'')+' '+[...document.querySelectorAll('option')].map(o=>o.textContent).join('|')")
        found += [m.group(0) for m in BAD.finditer(html)]
        if t=='Providers': await shot('61_providers_office_roles', full=False)
    acting = await pg.locator('[data-testid=acting-as] option').all_inner_texts()
    ok(f'{W} v11 no OR / PACU / anesthesia roles in providers, staff, pickers, session list', not found and not any(BAD.search(o) for o in acting))
    # migration of existing Surgery users
    await pg.evaluate("""()=>{const st=JSON.parse(localStorage.getItem('vityls:surgery:staff')||'[]'); if(st){st.push({id:'st-x1',name:'Pat Pacu',role:'PACU RN',active:true,pinHash:'',fails:0}); localStorage.setItem('vityls:surgery:staff',JSON.stringify(st));}
      const pv=JSON.parse(localStorage.getItem('vityls:v7:providers')||'null'); if(pv){pv.push({...pv[0],id:'prov-x1',firstName:'Ana',lastName:'Esthe',role:'Anesthesiologist'}); localStorage.setItem('vityls:v7:providers',JSON.stringify(pv));}
      Object.keys(localStorage).filter(k=>/roles-v011/.test(k)).forEach(k=>localStorage.removeItem(k)); return !!st && !!pv}""")
    await pg.reload(); await pg.wait_for_timeout(1400)
    mig = await pg.evaluate("()=>{const st=JSON.parse(localStorage.getItem('vityls:surgery:staff')||'[]').find(s=>s.id==='st-x1'); const pv=JSON.parse(localStorage.getItem('vityls:v7:providers')||'[]').find(p=>p.id==='prov-x1'); return [st&&st.role, pv&&pv.role]}")
    ok(f'{W} v11 migration: PACU RN → RN, Anesthesiologist → Physician ({mig})', mig==['RN','Physician'])
    await pg.goto(BASE+'?reset-test-data'); await pg.wait_for_timeout(1500); await pg.select_option('[data-testid=acting-as]', value='Morgan Avery'); await pg.wait_for_timeout(200)
    # 4 ---- appointment notes: Today panel
    await c('[data-testid=sv-nav-home]'); await pg.wait_for_timeout(400)
    await pg.locator('[data-testid=dash-card]').first.click(); await pg.wait_for_timeout(300)
    seeded = await pg.input_value('[data-testid=today-appt-notes-text]')
    ok(f'{W} v11 Today panel shows appointment notes ({seeded[:30]})', len(seeded)>5)
    await pg.fill('[data-testid=today-appt-notes-text]', seeded+' · bring ID'); await c('[data-testid=today-appt-notes-save]'); await pg.wait_for_timeout(300)
    ok(f'{W} v11 Today panel notes saved', 'bring ID' in await pg.input_value('[data-testid=today-appt-notes-text]'))
    await pg.locator('[data-testid=today-appt-notes]').scroll_into_view_if_needed(); await shot('40_today_panel_appt_notes', full=False)
    # schedule add with notes, PDF uses real notes
    await c('[data-testid=sv-nav-schedule]'); await pg.wait_for_timeout(400)
    if (await pg.get_attribute('[data-testid=sv-schedule]','data-view'))!='day': await c('[data-testid=view-day]')
    await c('[data-testid=add-visit]'); await pg.wait_for_timeout(300); await pg.fill('[data-testid=visit-time]','03:00 PM')
    await book(pg,'Rob'); await pg.fill('[data-testid=visit-notes]','Wants financing info · cousin translating'); await shot('41_add_visit_notes', full=False)
    await c('[data-testid=save-visit]'); await pg.wait_for_timeout(400)
    await pg.locator('[data-testid=visit-block][data-time="03:00 PM"]').first.click(); await pg.wait_for_timeout(300)
    ok(f'{W} v11 edit popup shows appointment notes', 'financing' in await pg.input_value('[data-testid=appt-notes]'))
    await pg.fill('[data-testid=appt-notes]','Wants financing info · cousin translating · CareCredit form'); await c('[data-testid=appt-save]'); await pg.wait_for_timeout(400)
    if await pg.locator('[data-testid=pin-sign]').count(): await pin(pg,'Pat Quinn')
    if await pg.locator('[data-testid=appt-detail]').count(): await pg.keyboard.press('Escape'); await pg.wait_for_timeout(200)
    await c('[data-testid=sched-print]'); await pg.wait_for_timeout(1500)
    u = await pg.get_attribute('[data-testid=print-pdf-frame]','src')
    b64 = await pg.evaluate("async u=>{const b=await (await fetch(u)).arrayBuffer();let s='';new Uint8Array(b).forEach(x=>s+=String.fromCharCode(x));return btoa(s)}", u)
    pth=f'/tmp/s11_{W}.pdf'; open(pth,'wb').write(base64.b64decode(b64)); t=subprocess.run(['pdftotext','-layout',pth,'-'],capture_output=True,text=True).stdout
    subprocess.run(['pdftoppm','-png','-r','80','-f','1','-l','1',pth,f'{OUT}/{W}_42_pdf_notes_column'])
    for f in os.listdir(OUT):
        if f.startswith(f'{W}_42_pdf_notes_column-'): os.replace(f'{OUT}/{f}', f'{OUT}/{W}_42_pdf_notes_column.png')
    ok(f'{W} v11 PDF Notes column shows real appointment notes', 'CareCredit' in t and 'bring ID' in t)
    ok(f'{W} v11 PDF no longer pads Notes with room/length', ' min |' not in t and 'Unconfirmed' not in t)
    await pg.locator('[data-testid=sched-print-dialog] button', has_text='Close').first.click(); await pg.wait_for_timeout(200)
    # 2 ---- patient photo
    await c('[data-testid=sv-nav-patients]'); await pg.wait_for_timeout(300)
    await pg.locator('[data-testid=sv-patient-list] tbody tr', has_text='Ellen Testwood').first.locator('button').first.click(); await pg.wait_for_timeout(600)
    ok(f'{W} v11 chart photo spot with initials when no photo', await pg.get_attribute('[data-testid=chart-photo]','data-has')=='false' and 'ET' in await pg.inner_text('[data-testid=photo-edit]'))
    await pg.hover('[data-testid=photo-edit]'); await pg.wait_for_timeout(450)
    hv = await pg.evaluate("()=>matchMedia('(hover:hover)').matches")
    dg = await pg.evaluate("()=>{const b=document.querySelector('[data-testid=photo-edit]');b.querySelector('.v11-photo-ov').style.transition='none';const r=b.getBoundingClientRect();const e=document.elementFromPoint(r.x+r.width/2,r.y+r.height/2);return [b.matches(':hover'),getComputedStyle(b.querySelector('.v11-photo-ov')).opacity,e&&e.outerHTML.slice(0,80)]}"); op=float(dg[1])
    ok(f'{W} v11 hover shows edit overlay (hover-capable={hv} {dg})', op>0.9 if hv else True)
    await shot('20_chart_photo_hover', full=False)
    await c('[data-testid=photo-edit]'); await pg.wait_for_timeout(200)
    ok(f'{W} v11 photo menu: upload + take photo (camera capture)', await pg.locator('[data-testid=photo-upload]').count()==1 and await pg.locator('[data-testid=photo-camera]').count()==1 and await pg.locator('[data-testid=photo-upload-input]').count()==1)
    await shot('21_chart_photo_menu', full=False)
    await pg.set_input_files('[data-testid=photo-upload-input]','/workspace/vityls/surgwork/v13/face.png'); await pg.wait_for_timeout(800); await pg.wait_for_timeout(700)
    ok(f'{W} v11 photo uploaded and shown', await pg.locator('[data-testid=photo-img]').count()==1)
    await pg.mouse.move(5,5); await shot('22_chart_photo_set', full=False)
    await c('[data-testid=photo-edit]'); ok(f'{W} v11 replace/remove offered', 'Replace' in await pg.inner_text('[data-testid=photo-menu]') and await pg.locator('[data-testid=photo-remove]').count()==1); await c('[data-testid=photo-edit]')
    await c('[data-testid=chart-back]'); await pg.wait_for_timeout(300)
    ok(f'{W} v11 photo in Patients list', await pg.locator('[data-testid=sv-patient-list] tbody tr', has_text='Ellen Testwood').locator('[data-testid=avatar] img').count()==1)
    await shot('23_patients_list_photo', full=False)
    await c('[data-testid=sv-nav-home]'); await pg.wait_for_timeout(300); await pg.locator('[data-testid=dash-card]', has_text='Ellen').first.click(); await pg.wait_for_timeout(300)
    ok(f'{W} v11 photo in Today panel', await pg.locator('[data-testid=appt-panel] [data-testid=avatar] img').count()==1); await shot('24_today_panel_photo', full=False)
    await c('[data-testid=today-appt-name]'); await pg.wait_for_timeout(500)
    await c('[data-testid=photo-edit]'); await c('[data-testid=photo-remove]'); await pg.wait_for_timeout(300)
    ok(f'{W} v11 photo removed', await pg.get_attribute('[data-testid=chart-photo]','data-has')=='false')
    aud = await pg.evaluate("()=>Object.keys(localStorage).filter(k=>/audit/i.test(k)).map(k=>localStorage.getItem(k)).join('')")
    ok(f'{W} v11 photo changes audited', aud.count('patient.photo')>=2)
    # 3 ---- Notes tab
    await pg.locator('[data-testid=chart-tab-activity]').click(); await pg.wait_for_timeout(300)  # v1.2: tab is labelled Timeline
    await c('[data-testid=rec-notes]'); await pg.wait_for_timeout(300)
    n = await pg.locator('[data-testid=note-row]').count()
    dates = [x.split('\t')[0] for x in await pg.locator('[data-testid=note-row]').all_inner_texts()]
    iso = [d[6:10]+d[0:2]+d[3:5] for d in dates if re.match(r'\d\d/\d\d/\d{4}', d)]
    ok(f'{W} v11 Notes tab lists doctor notes ({n}), newest first', n>=1 and iso==sorted(iso, reverse=True))
    ok(f'{W} v11 Notes rows: author, type, status, open, print', await pg.locator('[data-testid=note-open]').count()==n and await pg.locator('[data-testid=note-print]').count()==n)
    await shot('30_chart_notes_tab')
    await pg.locator('[data-testid=note-open]').first.click(); await pg.wait_for_timeout(400)
    ok(f'{W} v11 Notes open shows the note', await pg.locator('[data-testid=sv-panel], .sv-panel').count()>=1)
    # 5 ---- diagnoses editing
    await pg.keyboard.press('Escape'); await pg.wait_for_timeout(200)
    for sel in ['[data-testid=sv-panel] [aria-label=Close]','.sv-panel [aria-label=Close]']:
        if await pg.locator(sel).count(): await pg.locator(sel).first.click(); await pg.wait_for_timeout(200)
    await pg.locator('[data-testid=chart-tab-overview]').click(force=True); await pg.wait_for_timeout(300)
    n0 = await pg.locator('[data-testid=dx-entry]').count()
    await c('[data-testid=dx-add]'); await pg.wait_for_timeout(300)
    await pg.fill('[data-testid=dx-name]','Ptosis, right upper eyelid'); await pg.fill('[data-testid=dx-icd]','H02.401')
    await pg.fill('[data-testid=dx-proc-name]','Ptosis repair, right'); await pg.select_option('[data-testid=dx-proc-status]','performed')
    await c('[data-testid=dx-save]'); await pg.wait_for_timeout(200)
    ok(f'{W} v11 performed procedure needs a date', await pg.locator('[data-testid=dx-dialog]').count()==1)
    await pg.fill('[data-testid=dx-proc-date]','2026-09-15'); await shot('50_dx_dialog', full=False); await c('[data-testid=dx-save]'); await pg.wait_for_timeout(300)
    ok(f'{W} v11 diagnosis added on chart', await pg.locator('[data-testid=dx-entry]').count()==n0+1 and 'Ptosis' in await pg.inner_text('[data-testid=dx-card]'))
    await pg.locator('[data-testid=dx-entry]', has_text='Ptosis').locator('[data-testid=dx-edit]').click(); await pg.wait_for_timeout(200)
    await c('[data-testid=dx-proc-add]'); await pg.locator('[data-testid=dx-proc-name]').nth(1).fill('Upper blepharoplasty revision'); await c('[data-testid=dx-save]'); await pg.wait_for_timeout(300)
    ok(f'{W} v11 diagnosis edited (2 procedures)', 'blepharoplasty revision' in await pg.inner_text('[data-testid=dx-card]'))
    await pg.locator('[data-testid=ov-dx]').scroll_into_view_if_needed(); await shot('51_chart_dx_card', full=False)
    await c('[data-testid=sv-nav-patients]'); await pg.wait_for_timeout(300)
    ok(f'{W} v11 Patients column shows edited diagnosis', 'Ptosis' in await pg.locator('[data-testid=sv-patient-list] tbody tr', has_text='Ellen Testwood').inner_text())
    await pg.select_option('[data-testid=dx-filter-dx]', label='Ptosis, right upper eyelid'); await pg.wait_for_timeout(200)
    ok(f'{W} v11 filter finds edited diagnosis', await pg.locator('[data-testid=sv-patient-list] tbody tr').count()==1)
    await c('[data-testid=dx-filter-clear]')
    await practice(pg, c); await pg.get_by_text('Practice performance & reports').first.click(); await pg.wait_for_timeout(400); await c('[data-testid=report-dx]'); await pg.wait_for_timeout(300)
    rows = await pg.locator('[data-testid=dx-row]').all_inner_texts()
    mixed = [r for r in rows if re.search(r'\t[1-9]\d*\t[1-9]', r)]
    ok(f'{W} v11 report shows mixed performed / not performed ({len(mixed)})', len(mixed)>=2 and any('Ptosis' in r for r in rows))
    await pg.locator('[data-testid=dx-report]').scroll_into_view_if_needed(); await shot('52_practice_dx_report_mixed', full=False)
    await c('[data-testid=sv-nav-patients]'); await pg.wait_for_timeout(300)
    await pg.locator('[data-testid=sv-patient-list] tbody tr', has_text='Ellen Testwood').first.locator('button').first.click(); await pg.wait_for_timeout(500)
    await pg.locator('[data-testid=dx-entry]', has_text='Ptosis').locator('[data-testid=dx-remove]').click(); await c('[data-testid=dx-remove-ok]'); await pg.wait_for_timeout(300)
    ok(f'{W} v11 diagnosis removed', 'Ptosis' not in await pg.inner_text('[data-testid=dx-card]'))
    aud = await pg.evaluate("()=>Object.keys(localStorage).filter(k=>/audit/i.test(k)).map(k=>localStorage.getItem(k)).join('')")
    ok(f'{W} v11 diagnosis changes audited', aud.count('patient.dx')>=3)
    ok(f'{W} v11 no horizontal overflow', await noover())
