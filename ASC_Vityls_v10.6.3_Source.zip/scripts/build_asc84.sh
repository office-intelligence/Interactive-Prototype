set -e
cd "$(dirname "$0")/.."
VITE_EDITION=ASC2 npx vite build --outDir dist-asc2 >/tmp/asc2build.log 2>&1 || { tail -30 /tmp/asc2build.log; exit 1; }
DIST=dist-asc2 OUT=ASC_Vityls_v8.4 node scripts/package-surgery.mjs
sed -i 's#<title>[^<]*</title>#<title>ASC.Vityls v8.4 — test build (fictional data)</title>#' release/ASC_Vityls_v8.4/index.html
