import asyncio, re
from playwright.async_api import async_playwright
URL='file:///workspace/vityls/src_v6/vityls_final_build/release/Vityls_Patient_Portal_v0.4/index.html'
OUT='/workspace/vityls/report/portal_v04_screens/_reg_finder'
res=[]
def ok(n,c): res.append((n,bool(c))); print(('PASS ' if c else 'FAIL ')+n, flush=True)
async def main():
  async with async_playwright() as p:
    b=await p.chromium.launch(executable_path='/usr/bin/google-chrome'); ctx=await b.new_context(viewport={'width':1280,'height':900}); pg=await ctx.new_page(); errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
    
    async def c(s): await pg.locator(s).first.click(); await pg.wait_for_timeout(250)
    t=lambda s: pg.locator(s).first.inner_text(); n=lambda s: pg.locator(s).count()
    shot=lambda name: pg.screenshot(path=f'{OUT}/{name}.png', full_page=True)
    await pg.goto(URL); await pg.evaluate('window.__vitylsRawStorage.clear()'); await pg.reload(); await pg.wait_for_timeout(900)
    # guest search
    await c('[data-testid=pp-guest-finder]'); ok('guest opens finder', await n('[data-testid=pp-finder]')==1)
    ok('mode label: bundled snapshot', 'bundled snapshot' in await t('[data-testid=fd-mode]') and 'real public NPI' in await t('[data-testid=fd-mode]'))
    await c('[data-testid=fd-search]'); cnt=await t('[data-testid=fd-count]'); ok(f'default search: cardiology Beverly Hills ({cnt})', int(cnt.split()[0])>0)
    card=await t('[data-testid=fd-card]'); ok('card: NPI, phone, since, specialty', re.search(r'NPI \d{10}',card) and 'Phone' in card and 'NPI since' in card and 'Cardiovascular' in card)
    ok('years labeled approx.', 'approx.' in await t('[data-testid=fd-since]'))
    await shot('01_guest_finder')
    await c('[data-testid=fd-add]'); ok('guest save to care team needs account', 'needs a free account' in await t('[data-testid=pp-auth-reason]')); await c('[data-testid=pp-auth-close]')
    # nightingale chip
    await pg.locator('[data-testid=fd-chip]', has_text='cardiologist near 90210').click(); await pg.wait_for_timeout(200)
    ok('chip parses specialty + ZIP', (await pg.input_value('[data-testid=fd-zip]'))=='90210' and (await pg.input_value('[data-testid=fd-specialty]'))=='Cardiovascular Disease' and 'near 90210' in await t('[data-testid=fd-count]'))
    await pg.fill('[data-testid=fd-ask]','find a dermatologist in Los Angeles'); await c('[data-testid=fd-ask-go]'); await pg.wait_for_timeout(200)
    ok('free text parsed: dermatology in Los Angeles', (await pg.input_value('[data-testid=fd-city]'))=='Los Angeles' and (await pg.input_value('[data-testid=fd-specialty]'))=='Dermatology')
    total=int((await t('[data-testid=fd-count]')).split()[0]); ok(f'pagination 10/page ({total})', await n('[data-testid=fd-card]')==min(10,total) and (total<=10 or await n('[data-testid=fd-pager]')==1))
    if total>10:
      first=await t('[data-testid=fd-card]'); await c('[data-testid=fd-next]'); ok('next page', 'Page 2' in await t('[data-testid=fd-page]') and await t('[data-testid=fd-card]')!=first); await c('[data-testid=fd-prev]')
    await pg.select_option('[data-testid=fd-sort]','since-old'); await pg.wait_for_timeout(100); ys=[int(re.search(r'since (\d{4})',x).group(1)) for x in await pg.locator('[data-testid=fd-since]').all_inner_texts()]; ok(f'sort by NPI date {ys[:4]}', ys==sorted(ys))
    await pg.select_option('[data-testid=fd-sort]','last'); 
    await pg.select_option('[data-testid=fd-f-sex]','F'); await pg.wait_for_timeout(100); fN=int((await t('[data-testid=fd-count]')).split()[0]); ok(f'gender filter {fN}<{total}', 0<fN<total); await pg.select_option('[data-testid=fd-f-sex]','')
    await pg.select_option('[data-testid=fd-f-years]','15'); y15=int((await t('[data-testid=fd-count]')).split()[0]); ok(f'NPI-age filter {y15}', y15<=total); await pg.select_option('[data-testid=fd-f-years]','0')
    await shot('02_finder_dermatology_LA')
    # name + org search
    await c('[data-testid=fd-clear]'); await pg.fill('[data-testid=fd-org]','Bayview'); await c('[data-testid=fd-search]'); ok('org search finds Vityls practice', await n('[data-testid=fd-vityls]')==1 and 'Kim' in await t('[data-testid=fd-card]'))
    await c('[data-testid=fd-clear]'); await pg.fill('[data-testid=fd-name]','Patel'); await c('[data-testid=fd-search]'); ok('name search', await n('[data-testid=fd-card]')>=1 and all('Patel' in x for x in await pg.locator('[data-testid=fd-card] [data-testid=fd-open]').all_inner_texts()))
    # detail
    await c('[data-testid=fd-clear]'); await pg.select_option('[data-testid=fd-specialty]','Pediatrics'); await pg.fill('[data-testid=fd-zip]','90048'); await c('[data-testid=fd-search]'); await c('[data-testid=fd-open]')
    ok('detail view with taxonomies + NPPES link', await n('[data-testid=fd-detail]')==1 and 'Pediatrics' in await t('[data-testid=fd-taxonomies]') and await n('[data-testid=fd-detail] a[href*="npiregistry.cms.hhs.gov/provider-view/"]')==1)
    ok('no ranking language', not re.search(r'\b(best|top-rated|recommended)\b', (await t('[data-testid=pp-finder]')).lower()))
    await shot('03_finder_detail'); await c('[data-testid=fd-back]')
    # live mode check (CORS)
    await c('[data-testid=fd-mode-toggle]'); await pg.wait_for_timeout(4000); note=await t('[data-testid=fd-live-note]'); ok(f'live mode reports CORS block: {note[:70]}', 'CORS' in note or 'Live works' in note)
    await shot('04_live_mode_blocked'); await c('[data-testid=fd-mode-toggle]'); ok('back to snapshot', 'bundled snapshot' in await t('[data-testid=fd-mode]'))
    # signed in
    await c('[data-testid=pp-guest-signin]'); await pg.fill('[data-testid=pp-auth-email]','jordan.rivera@example.test'); await pg.fill('[data-testid=pp-auth-password]','portal2026'); await c('[data-testid=pp-auth-go]'); await pg.wait_for_timeout(300); await c('[data-testid=imx-open-portal]')
    await c('[data-testid=pp-nav-finder]'); await c('[data-testid=fd-clear]'); await pg.check('[data-testid=fd-f-vityls]'); await c('[data-testid=fd-search]')
    ok('Vityls-only filter shows 2 fictional practices', await n('[data-testid=fd-card]')==2)
    await pg.locator('[data-testid=fd-card]', has_text='Sam Patel').locator('[data-testid=fd-connect]').click(); ok('connect to Vityls practice', 'Connected to Coastline' in await t('[data-testid=fd-msg]'))
    await pg.locator('[data-testid=fd-card]', has_text='Sam Patel').locator('[data-testid=fd-book]').click(); ok('appointment request sent', 'Appointment request sent' in await t('[data-testid=fd-msg]'))
    await shot('05_finder_vityls_connected')
    await c('[data-testid=pp-nav-care]'); ok('care team shows connected practice', 'Connected since' in await t('[data-testid=pp-team-coastline]'))
    await c('[data-testid=pp-nav-history]'); ok('history logs finder connect + appt', 'link.patient-connected' in await t('[data-testid=pp-history-table]') and 'appointment.requested' in await t('[data-testid=pp-history-table]'))
    # non-vityls actions
    await c('[data-testid=pp-nav-finder]'); await c('[data-testid=fd-search]'); name=(await t('[data-testid=fd-card] [data-testid=fd-open]')).strip()
    await c('[data-testid=fd-add]'); ok('added non-Vityls to care team', 'added to your care team' in await t('[data-testid=fd-msg]') and 'In my care team' in await t('[data-testid=fd-add]'))
    await c('[data-testid=fd-rr]'); await pg.wait_for_timeout(200); ok('records request prefilled from NPI', 'NPI' in await pg.input_value('[data-testid=pp-rr-provider]'))
    await c('[data-testid=pp-rr-make]'); ok('request letter made', '164.524' in await t('[data-testid=pp-rr-letter]'))
    await c('[data-testid=pp-nav-finder]'); await c('[data-testid=fd-search]'); await c('[data-testid=fd-ul]'); await pg.wait_for_timeout(200); ok('upload link prefilled', name.split(',')[0] in await pg.input_value('[data-testid=pp-ul-recipient]'))
    await c('[data-testid=pp-nav-care]'); ok('care team lists NPI provider separately', name.split(',')[0] in await t('[data-testid=pp-outside]') and 'NPI' in await t('[data-testid=pp-outside]'))
    await shot('06_care_team_with_npi')
    await pg.set_viewport_size({'width':390,'height':844}); await c('[data-testid=pp-nav-finder]'); await shot('07_mobile_finder')
    ok(f'no page errors {errs[:2]}', not errs)
    await b.close()
  print(f'TOTAL {sum(1 for _,c in res if c)} / {len(res)}')
asyncio.run(main())
