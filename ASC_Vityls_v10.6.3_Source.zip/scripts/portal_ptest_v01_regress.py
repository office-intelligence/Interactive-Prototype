import asyncio, os, sys
from playwright.async_api import async_playwright
URL='file:///workspace/vityls/src_v6/vityls_final_build/release/Vityls_Patient_Portal_v0.2/index.html'
OUT='/workspace/vityls/report/portal_v02_screens/regress_v01'; W=int(sys.argv[1]) if len(sys.argv)>1 else 1280
res=[]
def ok(n,c): res.append((n,bool(c))); print(('PASS ' if c else 'FAIL ')+n, flush=True)
async def main():
  async with async_playwright() as p:
    b=await p.chromium.launch(executable_path='/usr/bin/google-chrome'); ctx=await b.new_context(viewport={'width':W,'height':900}); pg=await ctx.new_page(); errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
    c=lambda s: pg.locator(s).first.click(); t=lambda s: pg.locator(s).first.inner_text(); n=lambda s: pg.locator(s).count()
    shot=lambda name: pg.screenshot(path=f'{OUT}/{name}.png', full_page=True)
    await pg.goto(URL); await pg.evaluate('window.__vitylsRawStorage.clear()'); await pg.reload(); await pg.wait_for_timeout(900)
    ok('guest home shows', await n('[data-testid=pp-guest]')==1); await c('[data-testid=pp-guest-signin]'); ok('auth screen shows', await n('[data-testid=portal-auth]')==1); await shot('01_sign_in')
    # sign-up without a practice
    await c('[data-testid=pp-auth-switch]'); await pg.fill('[data-testid=pp-auth-name]','Avery Test'); await pg.fill('[data-testid=pp-auth-email]','avery@example.test'); await pg.fill('[data-testid=pp-auth-dob]','1990-02-03'); await pg.fill('[data-testid=pp-auth-password]','short')
    await c('[data-testid=pp-auth-go]'); ok('weak password rejected', await n('[data-testid=pp-auth-err]')==1)
    await pg.fill('[data-testid=pp-auth-password]','longpassword1'); await shot('02_sign_up'); await c('[data-testid=pp-auth-go]'); await pg.wait_for_timeout(300)
    ok('new account lands on Nightingale home', await n('[data-testid=pp-home]')==1)
    ok('new account: allergy/meds/history/connect prompts', all([await n(f'[data-testid=pp-prompt-{k}]') for k in ['allergies','meds','history','connect']]))
    await c('[data-testid=pp-nav-inbox]'); ok('new account has no practices', await n('[data-testid=pp-inbox-empty]')==1)
    await c('[data-testid=pp-nav-home]'); await c('[data-testid=pp-allergy-none]'); ok('no known allergies answered', await n('[data-testid=pp-prompt-allergies]')==0)
    await c('[data-testid=pp-signout]'); await pg.wait_for_timeout(200); await c('[data-testid=pp-guest-signin]')
    # demo patient
    await pg.fill('[data-testid=pp-auth-email]','jordan.rivera@example.test'); await pg.fill('[data-testid=pp-auth-password]','wrong'); await c('[data-testid=pp-auth-go]'); ok('wrong password rejected', await n('[data-testid=pp-auth-err]')==1)
    await pg.fill('[data-testid=pp-auth-password]','portal2026'); await c('[data-testid=pp-auth-go]'); await pg.wait_for_timeout(300)
    ok('demo login', 'Jordan Rivera' in await t('.pp-me')); await shot('03_home_nightingale')
    await c('[data-testid=pp-cmd-explain]'); ok('chat answers labs', 'lab values on file' in await t('[data-testid=pp-chat]'))
    await pg.fill('[data-testid=pp-ask]','Should I stop my statin?'); await c('[data-testid=pp-ask-go]'); ok('no go/no-go advice', "can't tell you whether" in await t('[data-testid=pp-chat]'))
    await pg.fill('[data-testid=pp-ask]','I have chest pain'); await c('[data-testid=pp-ask-go]'); ok('red flag escalates to 911', '911' in await t('[data-testid=pp-chat]'))
    # connect my doctor (FHIR sim)
    await c('[data-testid=pp-nav-connect]'); await c('[data-testid=pp-fhir-connect-northshore]'); await c('[data-testid=pp-fhir-login]'); await shot('04_fhir_consent'); await c('[data-testid=pp-fhir-allow]')
    r=await t('[data-testid=pp-fhir-result]'); ok(f'FHIR import: {r[:60]}', 'Imported 5 labs' in r)
    await c('[data-testid=pp-fhir-connect-northshore]'); await c('[data-testid=pp-fhir-login]'); await c('[data-testid=pp-fhir-allow]'); ok('re-sync dedups', '5 duplicates' in await t('[data-testid=pp-fhir-result]') or 'duplicates skipped' in await t('[data-testid=pp-fhir-result]'))
    # records request
    await pg.fill('[data-testid=pp-rr-provider]','Dr. Lee, Sunview Orthopedics (fictional)'); await pg.fill('[data-testid=pp-rr-fax]','(555) 010-7788'); await c('[data-testid=pp-rr-make]')
    lt=await t('[data-testid=pp-rr-letter]'); ok('records request letter with unique return inbox', '164.524' in lt and '@direct.records.vityls.test' in lt)
    await shot('05_connect_records_request'); await c('[data-testid=pp-rr-send]'); ok('request logged', await n('[data-testid=pp-rr-row]')==1); await c('[data-testid=pp-rr-simreceive]')
    # upload link
    await pg.fill('[data-testid=pp-ul-recipient]','Sunview Orthopedics'); await c('[data-testid=pp-ul-make]'); ok('upload link created', await n('[data-testid=pp-ul-row]')==1)
    url=await t('[data-testid=pp-ul-url]'); await shot('06_connect_upload_link')
    up=await ctx.new_page(); await up.goto(url); await up.wait_for_timeout(800)
    ok('provider upload page opens without account', await up.locator('[data-testid=pp-upload-page] h1').inner_text()=='Send records to JR.')
    await up.fill('[data-testid=pp-up-office]','Sunview Orthopedics'); await up.fill('[data-testid=pp-up-title]','Knee X-ray report'); await up.fill('[data-testid=pp-up-note]','Please review with Dr. Kim')
    open('/tmp/xray.txt','w').write('fictional x-ray report'); await up.set_input_files('[data-testid=pp-up-file]','/tmp/xray.txt'); await up.screenshot(path=f'{OUT}/07_provider_upload_page.png', full_page=True)
    await up.click('[data-testid=pp-up-send]'); await up.wait_for_timeout(300); ok('provider upload done', await up.locator('[data-testid=pp-up-done]').count()==1)
    await up.goto(url.split('#')[0]+'#portal-upload=bogus'); await up.wait_for_timeout(500); ok('bad token rejected', await up.locator('[data-testid=pp-upload-invalid]').count()==1); await up.close()
    # home proactive labs->meds
    await pg.reload(); await pg.wait_for_timeout(600); await c('[data-testid=pp-nav-home]')
    ok('proactive labs->meds card', 'tell me about your medications' in await t('[data-testid=pp-prompt-labs-meds]'))
    ok('new document prompt', await n('[data-testid=pp-prompt-doc]')>=1); await shot('08_home_proactive_cards')
    await c('[data-testid=pp-medchip-Acetaminophen]'); await c('[data-testid=pp-labsmeds-go]'); await pg.wait_for_timeout(200)
    ch=await t('[data-testid=pp-chat]'); ok('Nightingale links statin/acetaminophen to ALT, no diagnosis', 'liver enzymes' in ch and 'not a diagnosis' in ch)
    # labs
    await c('[data-testid=pp-nav-labs]'); ok('lab trend charts', await n('[data-testid=pp-trend]')>=5); await c('[data-testid=pp-lab-ALT] [data-testid=pp-lab-explain-btn]')
    ok('ALT explained, above range', 'above' in await t('[data-testid=pp-lab-explain]')); await shot('09_labs')
    # docs
    await c('[data-testid=pp-nav-docs]'); ok('provider upload filed to documents', 'Knee X-ray report' in await t('[data-testid=pp-doc-table]') and 'Sunview' in await t('[data-testid=pp-doc-table]'))
    await pg.set_input_files('[data-testid=pp-doc-upload]','/tmp/xray.txt'); await pg.wait_for_timeout(300); ok('patient upload', 'xray' in await t('[data-testid=pp-doc-table]'))
    await c('[data-testid=pp-doc-explain]'); ok('doc explained', await n('[data-testid=pp-doc-explained]')>=1); await shot('10_documents')
    # meds
    await c('[data-testid=pp-nav-meds]'); ok('imported atorvastatin listed', 'Atorvastatin' in await t('[data-testid=pp-meds]'))
    await pg.fill('[data-testid=pp-al-name]','Sulfa'); await c('[data-testid=pp-al-add]'); ok('allergy added', 'Sulfa' in await t('[data-testid=pp-meds]')); await shot('11_meds_allergies')
    await c('[data-testid=pp-nav-inbox]'); await pg.fill('[data-testid=pp-rem-title]','x') if await n('[data-testid=pp-rem-title]') else None
    # plan gating
    await c('[data-testid=pp-nav-plan]'); ok('wearables locked on Free', await n('[data-testid=pp-wearables-locked]')==1); await shot('13_plan_free')
    await c('[data-testid=pp-plan-trial]'); ok('trial unlocks wearables', await n('[data-testid=pp-wearable]')==3 and await n('[data-testid=pp-report-draft]')==1); await shot('14_plan_plus_trial')
    await c('[data-testid=pp-plan-cancel]'); ok('back to Free locks again', await n('[data-testid=pp-wearables-locked]')==1)
    # free explanation limit; practice items exempt
    await pg.evaluate("()=>{const l=JSON.parse(window.__vitylsRawStorage.getItem('vityls:portal:accounts'));const a=l.find(x=>x.id==='vp-demo-jordan');a.plan.explainUsed=10;window.__vitylsRawStorage.setItem('vityls:portal:accounts',JSON.stringify(l))}")
    await pg.reload(); await pg.wait_for_timeout(500); await c('[data-testid=pp-nav-labs]'); await c('[data-testid=pp-lab-AST] [data-testid=pp-lab-explain-btn]'); ok('free limit reached message', await n('[data-testid=pp-limit]')==1)
    await c('[data-testid=pp-lab-Potassium] [data-testid=pp-lab-explain-btn]'); ok('non-practice result blocked at limit (practice case in ptest2)', await n('[data-testid=pp-lab-explain]')==0)
    await pg.set_viewport_size({'width':390,'height':844}); await c('[data-testid=pp-nav-home]'); await shot('15_mobile_home')
    ok(f'no page errors {errs[:2]}', not errs)
    await b.close()
  print(f'TOTAL {sum(1 for _,c in res if c)} / {len(res)}')
asyncio.run(main())
