"""ASC.Vityls v10.1 checks: settings (8 groups), surgeon lists editor, connectors + BAA gate, onboarding wizard,
modules (start with email intake only, then add a module), CEO console. Clean build; test PIN 1234. Fictional data."""
import asyncio, sys, os
from playwright.async_api import async_playwright
URL = sys.argv[1] if len(sys.argv) > 1 else 'http://localhost:8811/'
OUT = os.environ.get('SHOTS', '/workspace/vityls/asc10_shots/v10.1/') + 'settings_'; os.makedirs(os.path.dirname(OUT), exist_ok=True)
res = []
def ok(n, c, note=''): res.append((n, bool(c))); print('PASS' if c else 'FAIL', n, note, flush=True)
async def main():
  async with async_playwright() as p:
    b = await p.chromium.launch(executable_path='/usr/bin/google-chrome'); ctx = await b.new_context(viewport={'width': 1440, 'height': 900}); pg = await ctx.new_page(); pg.set_default_timeout(6000)
    errs = []; pg.on('pageerror', lambda e: errs.append(str(e)))
    n = [0]
    async def shot(name): n[0] += 1; await pg.wait_for_timeout(300); await pg.screenshot(path=f'{OUT}{n[0]:02d}_{name}.png')
    async def step(name, fn):
      try: await fn()
      except Exception as e: ok(name, False, str(e).split('\n')[0][:200])
    T = lambda tid: pg.locator(f'[data-testid={tid}]')
    async def nav(tid): await T(tid).first.evaluate('e=>e.click()'); await pg.wait_for_timeout(600)
    async def draw():
      c = T('pin-sigpad-canvas').first
      if not await c.count(): return
      await c.scroll_into_view_if_needed(); bb = await c.bounding_box(); x, y = bb['x']+20, bb['y']+bb['height']/2
      await pg.mouse.move(x, y); await pg.mouse.down()
      for i in range(1, 12): await pg.mouse.move(x+i*14, y+(12 if i % 2 else -12))
      await pg.mouse.up()
    async def sign():
      await pg.wait_for_selector('[data-testid=pin-sign]'); opts = await pg.eval_on_selector('[data-testid=pin-who]', "s=>[...s.options].map(o=>o.text)")
      await pg.select_option('[data-testid=pin-who]', label=[o for o in opts if o and not o.startswith('Choose')][0]); await draw()
      await pg.fill('[data-testid=pin-input]', '1234'); await pg.click('[data-testid=pin-confirm]'); await pg.wait_for_timeout(600)
    async def role(label):
      s = T('acting-as').locator('select') if await T('acting-as').locator('select').count() else pg.locator('select').first
      opts = await s.evaluate("s=>[...s.options].map(o=>o.text)"); await s.select_option(label=[o for o in opts if label in o][0]); await pg.wait_for_timeout(600)
    async def practice():
      await nav('sv-nav-forms'); await pg.wait_for_timeout(400)
      if await T('practice-unlock').count() and await T('practice-unlock').first.is_visible(): await T('practice-unlock').first.click(); await pg.wait_for_timeout(300)
      if await T('pin-sign').count(): await sign()
      elif await pg.locator('input[type=password]').count(): await pg.locator('input[type=password]').last.fill('1234'); await pg.get_by_role('button', name='Unlock').click(); await pg.wait_for_timeout(500)
    # console starts empty (fresh clean browser)
    await pg.goto(URL + '?reset-test-data'); await pg.wait_for_timeout(2500)
    async def console_empty():
      await pg.goto(URL + '#vityls-console'); await pg.wait_for_selector('[data-testid=ceo-gate]'); await shot('ceo_gate')
      ok('CEO console asks for owner sign-in', True)
      await pg.fill('[data-testid=ceo-pin]', '0000'); await pg.click('[data-testid=ceo-signin]'); ok('wrong owner PIN refused', await T('ceo-console').count() == 0)
      await pg.fill('[data-testid=ceo-pin]', '1234'); await pg.click('[data-testid=ceo-signin]'); await pg.wait_for_selector('[data-testid=ceo-console]')
      ok('console starts empty without demo pack', await T('ceo-empty').count() == 1); ok('MRR $0', '$0' in await T('ceo-kpi-mrr').inner_text())
      ok('Finix shows Not connected', 'Not connected' in await T('ceo-finix').inner_text())
      await T('ceo-tab-leads').click(); ok('no leads', await T('ceo-leads-empty').count()); await shot('ceo_empty')
      body = await pg.inner_text('body'); ok('console shows no patient data', 'DOB' not in body and 'MRN' not in body)
    await step('console empty', console_empty)
    await pg.goto(URL); await pg.wait_for_timeout(2000)
    await role('Practice Administrator')
    async def settings():
      await practice(); await pg.wait_for_selector('[data-testid=v10-settings]'); g = await T('v10-group').count(); ok('settings show 8 groups', g == 8, str(g))
      t = await T('v10-groups').inner_text(); ok('group order matches wizard', all(x in t for x in ['Practice profile', 'Rooms & hours', 'People & roles', 'Surgeons & standing orders', 'Forms & consents', 'Billing & fees', 'Nightingale & notifications', 'Security & audit']))
      await shot('8_groups')
    await step('settings groups', settings)
    async def lists():
      await T('prac-v10-lists').first.click(); await pg.wait_for_selector('[data-testid=v10-lists]')
      await pg.fill('[data-testid=v10-lists-new]', 'SCDs on before transfer'); await T('v10-lists-add').click(); await pg.fill('[data-testid=v10-lists-new]', 'Antibiotic given (time)'); await T('v10-lists-add').click()
      await T('v10-lists-save').click(); await pg.wait_for_timeout(300); ok('pre-op list saved as v1', 'v1' in await T('v10-lists-version').inner_text())
      await T('v10-lists-post').click(); await pg.fill('[data-testid=v10-lists-new]', 'Ice 20 min on / 20 off'); await T('v10-lists-add').click(); await T('v10-lists-save').click(); await pg.wait_for_timeout(300)
      ok('post-op list saved', 'v1' in await T('v10-lists-version').inner_text()); await T('v10-lists-pre').click(); ok('pre-op list keeps 2 items', await T('v10-lists-item').count() == 2); await shot('lists_editor')
    await step('surgeon lists editor', lists)
    async def conns():
      await practice(); await T('prac-v10-connectors').first.click(); await pg.wait_for_selector('[data-testid=v10-connectors]')
      st = await pg.locator('[data-testid=v10-conn]').evaluate_all('l=>l.map(e=>e.dataset.status)'); ok('6 connectors, all Not connected', len(st) == 6 and set(st) == {'not-connected'}, str(st))
      ok('every connector gated by BAA', await T('v10-conn-gated').count() == 6); await shot('connectors_gated')
      await T('v10-baa-sign-open').click(); await sign(); ok('center BAA recorded', await T('v10-baa-signed').count())
      fx = pg.locator('[data-testid=v10-conn][data-id=finix]'); ok('Finix still needs vendor BAA', await fx.locator('[data-testid=v10-conn-gated]').count())
      await fx.locator('[data-testid=v10-conn-vbaa]').click(); await fx.locator('[data-testid=v10-conn-config]').click()
      await pg.fill('[data-testid=v10-conn-f-merchantId]', 'sk_live_123'); await T('v10-conn-save').click(); ok('keys refused in the browser', await pg.locator('.a81-err').count())
      await pg.fill('[data-testid=v10-conn-f-merchantId]', 'MU-TEST0001'); await T('v10-conn-save').click(); await pg.wait_for_timeout(300)
      ok('Finix configured, awaiting server', await fx.get_attribute('data-status') == 'configured'); await shot('connectors_baa')
    await step('connectors + BAA gate', conns)
    async def wizard():
      await practice(); await T('v10-open-wizard').click(); await pg.wait_for_selector('[data-testid=v10-wizard]'); await shot('wizard_plan')
      await T('v10-onb-plan-starter').click(); await T('v10-onb-next').click(); await pg.fill('[data-testid=v10-onb-name]', 'Test Surgery Center'); await pg.fill('[data-testid=v10-onb-contact]', 'admin@example.test'); await T('v10-onb-save1').click()
      for i in range(2, 9): await T(f'v10-onb-step-{i}').click(); await T('v10-onb-done').click()
      await T('v10-onb-step-9').click(); await shot('wizard_golive'); await T('v10-onb-finish').click(); ok('wizard finished, go-live requested', await T('v10-onb-finished').count())
    await step('onboarding wizard', wizard)
    async def starter():
      await pg.goto(URL); await pg.wait_for_timeout(1800); await role('Front desk')
      ok('starter: Email intake in nav', await T('sv-nav-email-h').count()); await nav('sv-nav-schedule'); ok('starter: Schedule locked (Try free teaser)', await T('module-teaser').count() and await T('module-teaser').get_attribute('data-module') == 'scheduling')
      ok('starter: no station shortcuts', await pg.locator('[data-testid^=n9-top-]').filter(has_text='Front').count() == 0)
      await nav('sv-nav-email-h'); await shot('starter_email_only'); ok('email intake page empty (no sample mail)', 'imulat' not in await pg.inner_text('body'))
    await step('modules: email intake only', starter)
    async def console_full():
      await pg.goto(URL + '#vityls-console'); await pg.wait_for_timeout(800)
      if await T('ceo-gate').count(): await pg.fill('[data-testid=ceo-pin]', '1234'); await T('ceo-signin').click()
      await pg.wait_for_selector('[data-testid=ceo-console]'); rows = T('ceo-practice'); ok('center appears after onboarding', await rows.count() == 1 and 'Test Surgery Center' in await rows.first.inner_text())
      ok('plan shows Starter', await T('ceo-plan').first.input_value() == 'starter')
      await T('ceo-tab-leads').click(); ok('lead recorded', await T('ceo-leads').count()); await T('ceo-tab-practices').click()
      await T('ceo-modules-open').click(); await pg.locator('[data-testid=ceo-mod][data-mod=stations-workflow] [data-testid=ceo-mod-on]').click(); await pg.wait_for_timeout(300)
      m = await T('ceo-msg').inner_text(); ok('adding Stations auto-adds Scheduling + Chart', 'Scheduling' in m or 'Schedul' in m, m)
      st = await pg.locator('[data-testid=ceo-mod]').evaluate_all('l=>Object.fromEntries(l.map(e=>[e.dataset.mod,e.dataset.state]))')
      ok('stations, scheduling, chart active', all(st[k] == 'active' for k in ['stations-workflow', 'scheduling', 'chart']), str(st))
      await pg.locator('[data-testid=ceo-mod][data-mod=billing] [data-testid=ceo-mod-trial]').click(); await pg.wait_for_timeout(300)
      ok('trial started', await pg.locator('[data-testid=ceo-mod][data-mod=billing]').get_attribute('data-state') == 'trial')
      await T('ceo-tab-usage').click(); ok('usage counts only', await T('ceo-usage').count()); await T('ceo-tab-audit').click(); ok('every action logged', 'Module' in await T('ceo-audit').inner_text() or 'activate' in await T('ceo-audit').inner_text()); await T('ceo-tab-practices').click(); await shot('ceo_modules')
      await pg.goto(URL); await pg.wait_for_timeout(1800); await role('Front desk')
      await nav('sv-nav-schedule'); ok('after adding module: Schedule opens', await T('module-teaser').count() == 0 and await T('sv-schedule').count()); await shot('after_add_module')
    await step('CEO console + add a module', console_full)
    ok('no page errors', not errs, '; '.join(errs[:3]))
    await b.close()
  f = [r for r in res if not r[1]]; print(f'{len(res)-len(f)}/{len(res)} passed')
asyncio.run(main())
