# Surgery.Vityls v1.3 · Playwright walk (1440 / 1180 / 820): Today + To-do, scenarios A–D on real seeded patients,
# the full-screen Doctor workspace and a video visit. Screenshots → report/surgery_v1.3_screens/. Fictional data only.
import asyncio, os, re, sys
from playwright.async_api import async_playwright
URL='file:///workspace/vityls/src_v6/vityls_final_build/release/Surgery_Vityls_v1.3/index.html'
OUT='/workspace/vityls/report/surgery_v1.3_screens'; os.makedirs(OUT, exist_ok=True)
R=[]
def ok(n,c): R.append((n,bool(c))); print(('PASS ' if c else 'FAIL ')+n, flush=True)
async def run(W,H):
  async with async_playwright() as p:
    b=await p.chromium.launch(executable_path='/usr/bin/google-chrome'); pg=await (await b.new_context(viewport={'width':W,'height':H})).new_page(); errs=[]
    pg.on('pageerror',lambda e:errs.append(str(e)))
    shot=lambda n: pg.screenshot(path=f'{OUT}/{W}_{n}.png')
    async def tid(t, timeout=6000): await pg.locator(f'[data-testid={t}]').first.click(timeout=timeout); await pg.wait_for_timeout(600)
    async def nav(t):
      if await pg.locator('[data-nav=drawer]').count() and not await pg.locator('[data-testid=fd-side].open').count(): await pg.locator('[data-testid=fd-hamburger]').click(); await pg.wait_for_timeout(300)
      await tid(t)
    async def patient(name):
      await nav('sv-nav-patients'); await pg.get_by_text(name, exact=True).first.click(); await pg.wait_for_timeout(900)
    step=lambda: pg.locator('[data-testid=flow-page]').get_attribute('data-step')
    prompt=lambda: pg.inner_text('[data-testid=flow-prompt]')
    await pg.goto(URL+'?reset-test-data'); await pg.wait_for_timeout(2500)
    if await pg.locator('[data-testid=fd-chat-home]').count(): await nav('sv-nav-home')
    # ---- Today ----
    ok(f'{W} Today greeting first', await pg.locator('[data-testid=today-greeting]').count()==1)
    order = await pg.evaluate("()=>{const a=document.querySelector('[data-testid=dash-patients]'),k=document.querySelector('[data-testid=today-kpis]'); return !!(a&&k&&(a.compareDocumentPosition(k)&4))}")
    ok(f'{W} Today schedule before KPIs', order)
    ok(f'{W} Today: no green Nightingale box', await pg.locator('[data-testid=sv-dashboard] .v7-ng').count()==0)
    ok(f'{W} pill composer fixed at bottom', await pg.locator('[data-testid=flow-composer]').count()==1 and (await pg.eval_on_selector('[data-testid=flow-composer]','e=>getComputedStyle(e).position'))=='fixed')
    ok(f'{W} schedule shows appointment-type icons', await pg.locator('[data-testid=dash-patients] [data-testid=appt-mode-icon][data-mode=video]').count()>=1 and await pg.locator('[data-testid=dash-patients] [data-testid=appt-mode-icon][data-mode=phone]').count()>=1)
    await shot('01_today')
    await tid('today-todo-open'); ok(f'{W} To-do slide-out', await pg.locator('[data-testid=today-todo-panel] [data-testid=todo-item]').count()>=3); await shot('02_today_todo'); await tid('today-todo-close')
    await pg.fill('[data-testid=nightingale-input]','who is next'); await pg.press('[data-testid=nightingale-input]','Enter'); await pg.wait_for_timeout(700)
    ok(f'{W} composer answers', await pg.locator('[data-testid=nightingale-answer]').count()==1); await shot('03_composer_answer')
    # ---- Scenario A: Tomas (front desk, portal forms with a blank field, cards missing) ----
    await patient('Tomas Exampleton'); ok(f'{W} A Tomas at Step 2', await step()=='2'); t=await prompt()
    ok(f'{W} A flags the blank field + missing cards only', 'blank field' in t and 'image' in t and 'confirm' not in t.lower())
    await shot('10_A_tomas_flow'); await tid('flow-open-ws'); ok(f'{W} A front desk workspace opens', await pg.locator('[data-testid=ws-front]').count()==1)
    ok(f'{W} A payment note: card data never touches Vityls', 'never touch' in await pg.inner_text('[data-testid=ws-pay-note]'))
    await shot('11_A_frontdesk_ws'); await tid('ws-form-open'); ok(f'{W} A full form view + highlighted blank', await pg.locator('[data-testid=v6-form-page]').count()==1 and int(await pg.locator('.flp-form').get_attribute('data-blanks') or 0)>=1)
    await shot('12_A_form_highlight'); await tid('ws-form-back2'); await tid('ws-collect'); ok(f'{W} A Collect payment dialog', 'Collect payment' in await pg.inner_text('body')); await shot('13_A_collect_payment')
    await pg.locator('[role=dialog][aria-label="Collect payment"]').get_by_role('button', name='Cancel').click(); await pg.wait_for_timeout(300)
    await tid('ws-arrive'); await tid('ws-reg-accept'); await tid('ws-save')
    ok(f'{W} A saving posts checks to the chat', await pg.locator('[data-testid=flow-check]').count()>=1); await shot('14_A_after_save')
    # ---- Scenario B: Ruth (Step 5 booking chain + clearance + PCP letter) ----
    await patient('Ruth Calder'); ok(f'{W} B Ruth at Step 5', await step()=='5'); await shot('20_B_ruth_flow')
    await tid('flow-open-ws'); await shot('21_B_booking_ws')
    for t in ['ws-quote-accept','ws-dep-record','ws-case-book','ws-clr-yes']: await tid(t)
    await pg.locator('[data-testid=ws-book-pcp]').scroll_into_view_if_needed(); await shot('22_B_pcp_letter'); await tid('ws-pcp-send'); await tid('ws-save')
    ok(f'{W} B advances to Step 6 (ASC)', await step()=='6'); ok(f'{W} B five checks posted', await pg.locator('[data-testid=flow-check]').count()>=5); await shot('23_B_after')
    # ---- Scenario C: Mary (ASC: ECG missing + metformin discrepancy) ----
    await patient('Mary James'); t=await prompt(); ok(f'{W} C Mary at Step 6', await step()=='6'); ok(f'{W} C flags ECG + metformin', 'ECG' in t and 'Metformin' in t)
    await shot('30_C_mary_flow'); await tid('flow-open-ws'); await shot('31_C_asc_ws'); await tid('ws-asc-upload-ECG'); await tid('ws-flag-ours'); await tid('ws-asc-sendbtn'); await pg.wait_for_timeout(2300); await tid('ws-save')
    ok(f'{W} C no flags left after fixes', await pg.locator('[data-testid^=flow-flag]').count()==0); await shot('32_C_after')
    await tid('flow-dot-2'); ok(f'{W} C past dot opens station for editing', 'editing Step 2' in await pg.inner_text('[role=dialog]')); await tid('ws-close')
    await tid('flow-history-toggle'); ok(f'{W} C change log lists the edit', 'for editing' in await pg.inner_text('[data-testid=flow-history]')); await shot('33_C_changelog')
    # ---- Scenario D: Lena (Undecided → resume at Step 5) ----
    await patient('Lena Ortiz'); ok(f'{W} D Lena stopped at Step 4 (Undecided)', await step()=='4' and 'Undecided' in await prompt()); await shot('40_D_lena_undecided')
    await tid('flow-resume'); ok(f'{W} D resumed at Step 5 (abbreviated)', await step()=='5'); await shot('41_D_resumed')
    # ---- Doctor full workspace (Daniel, roomed today) ----
    await patient('Daniel Reyes'); ok(f'{W} Daniel at Step 4', await step()=='4'); await tid('flow-open-ws')
    full = await pg.eval_on_selector('[data-testid=ws-doctor]','e=>e.getBoundingClientRect().width')
    ok(f'{W} Doctor workspace is full screen', full>=W-2); ok(f'{W} Doctor tabs + Nightingale rail', await pg.locator('[data-testid^=doc-tab-]').count()>=4 and await pg.locator('[data-testid=doc-rail]').count()==1)
    await shot('50_doctor_scribe')
    for t in ['charts','photos','quote','plan']: await tid(f'doc-tab-{t}'); await shot(f'5{["charts","photos","quote","plan"].index(t)+1}_doctor_{t}')
    await tid('ws-close')
    # ---- Video visit (Priya Nair, today) ----
    await patient('Priya Nair'); ok(f'{W} video visit offers Start video visit', await pg.locator('[data-testid=flow-start-remote]').count()==1); await shot('60_video_flow')
    await tid('flow-start-remote'); await tid('ws-start-remote'); ok(f'{W} video visit started (no arrival/rooming)', await pg.locator('[data-testid=ws-front-arrival]').inner_text()!='' and 'Visit started' in await pg.inner_text('[data-testid=ws-front-arrival]'))
    await shot('61_video_started'); await tid('ws-save')
    ok(f'{W} no page errors', not errs); print(errs[:3])
    await b.close()
async def main():
  for W,H in ([(1440,900),(1180,820),(820,1180)] if len(sys.argv)<2 else [tuple(map(int,sys.argv[1].split('x')))]):
    try: await run(W,H)
    except Exception as e: ok(f'{W} walk completed ({str(e)[:120]})', False)
  print('TOTAL', sum(r[1] for r in R), '/', len(R))
asyncio.run(main())
