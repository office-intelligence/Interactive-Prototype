"""ASC.Vityls v8.2 walkthrough (Playwright + Chrome). Usage: python3 scripts/walk82.py [URL] [WIDTH...]. Fictional data; test PIN 1234."""
import asyncio, sys, os
from playwright.async_api import async_playwright
URL = sys.argv[1] if len(sys.argv) > 1 else 'http://localhost:8783/'
WIDTHS = [int(w) for w in sys.argv[2:]] or [1440, 1024, 390]
OUT = '/workspace/vityls/report/asc_v8.2_screens/'; os.makedirs(OUT, exist_ok=True)
CARD = '/tmp/fake_card.png'
res = []
def ok(name, cond, note=''): res.append((name, bool(cond), note)); print(('PASS' if cond else 'FAIL'), name, note, flush=True)
async def run(w):
    async with async_playwright() as p:
        b = await p.chromium.launch(executable_path='/usr/bin/google-chrome'); pg = await b.new_page(viewport={'width': w, 'height': 900 if w > 500 else 844}); pg.set_default_timeout(8000)
        errs = []; pg.on('pageerror', lambda e: errs.append(str(e)))
        await pg.goto(URL + '?reset-test-data'); await pg.wait_for_timeout(2500)
        T = f'{w}:'
        async def shot(n):
            await pg.evaluate("()=>document.querySelectorAll('.a81-dbody,.a8-body').forEach(e=>e.scrollTop=0)"); await pg.screenshot(path=f'{OUT}{w}_{n}.png', full_page=True)
        async def noscroll(where):
            sw = await pg.evaluate('()=>document.documentElement.scrollWidth - window.innerWidth'); ok(T+f'no sideways scroll · {where}', sw <= 1, f'+{sw}px')
        async def role(label):
            s = pg.locator('select').first; opts = await s.evaluate("s=>[...s.options].map(o=>o.text)"); await s.select_option(label=[o for o in opts if label in o][0]); await pg.wait_for_timeout(600)
        async def nav(tid):
            await pg.locator(f'[data-testid={tid}]').first.evaluate('e=>e.click()'); await pg.wait_for_timeout(700)
        async def draw(sel):
            c = pg.locator(sel).first; await c.scroll_into_view_if_needed(); bb = await c.bounding_box()
            x, y = bb['x'] + 20, bb['y'] + bb['height'] / 2
            await pg.mouse.move(x, y); await pg.mouse.down()
            for i in range(1, 12): await pg.mouse.move(x + i * 14, y + (12 if i % 2 else -12))
            await pg.mouse.up(); await pg.wait_for_timeout(150)
        async def sign(who=None):
            await pg.wait_for_selector('[data-testid=pin-sign]')
            if who:
                opts = await pg.eval_on_selector('[data-testid=pin-who]', "s=>[...s.options].map(o=>o.text)"); await pg.select_option('[data-testid=pin-who]', label=[o for o in opts if who in o][0])
            else:
                v = await pg.eval_on_selector('[data-testid=pin-who]', 'e=>e.value')
                if not v: await pg.select_option('[data-testid=pin-who]', index=1)
            await draw('[data-testid=pin-sigpad-canvas]')
            await pg.fill('[data-testid=pin-input]', '1234'); await pg.click('[data-testid=pin-confirm]'); await pg.wait_for_timeout(500)
        async def bench(chip, patient=None):
            if await pg.locator('[data-testid=a81-close]').count(): await pg.click('[data-testid=a81-close]')
            await nav('sv-nav-home'); a = pg.locator('[data-testid=a81-chip-all]')
            if await pg.locator(f'[data-testid=a81-chip-{chip}]').count() == 0 and await a.count(): await a.click()
            await pg.click(f'[data-testid=a81-chip-{chip}]'); await pg.wait_for_selector(f'[data-testid=a81-bench-{chip}]')
            if patient:
                opts = await pg.eval_on_selector('[data-testid=a81-case-pick]', "s=>[...s.options].map(o=>o.text)"); await pg.select_option('[data-testid=a81-case-pick]', label=[o for o in opts if patient in o][0]); await pg.wait_for_timeout(300)
        # ---- Today: full-width list, no border
        await role('Front Desk Tester'); await nav('sv-nav-home')
        bw = await pg.eval_on_selector('.a8-list', 'e=>getComputedStyle(e).borderTopWidth'); ok(T+'today list has no border', bw == '0px', bw)
        ok(T+'bench order', (await pg.eval_on_selector('[data-testid=a81-bench-chips]', "e=>[...e.querySelectorAll('[data-testid^=a81-chip-]')].map(x=>x.dataset.testid)")) is not None)
        await shot('01_today_front'); await noscroll('today')
        # ---- 1 intake → scheduler (returning patient: name + DOB match)
        await bench('intake'); items = pg.locator('[data-testid=a81-intake-item]'); n = await items.count()
        for i in range(n):
            if 'returning' in await items.nth(i).inner_text(): await items.nth(i).click(); break
        ok(T+'match: exact name + DOB', await pg.get_attribute('[data-testid=a82-match]', 'data-kind') == 'exact'); await shot('02_intake_match')
        await pg.click('[data-testid=a81-scan-fax]'); await pg.wait_for_timeout(300); ok(T+'fax without DOB → choose', await pg.get_attribute('[data-testid=a82-match]', 'data-kind') in ('none', 'ambiguous'))
        for i in range(await items.count()):
            if 'returning' in await items.nth(i).inner_text(): await items.nth(i).click(); break
        await pg.click('[data-testid=a81-intake-confirm]'); await pg.wait_for_selector('[data-testid=add-visit-dialog]')
        ok(T+'scheduler Add appointment prefilled', await pg.locator('[data-testid=a82-book-prefill]').count() and 'Desmond Akers' in await pg.inner_text('[data-testid=add-visit-dialog]'))
        ok(T+'requested day', 'November 5' in await pg.inner_text('[data-testid=add-visit-dialog]')); await shot('03_intake_scheduler'); await noscroll('add appointment')
        await pg.click('[data-testid=save-visit]'); await pg.wait_for_timeout(700); ok(T+'case booked from scheduler', await pg.locator('[data-testid=add-visit-dialog]').count() == 0)
        # ---- 2 arrival: card capture
        await bench('arrival'); ok(T+'patient header card', await pg.locator('[data-testid=a82-case-card]').count()); ok(T+'X close', await pg.get_attribute('[data-testid=a81-close]', 'aria-label') == 'Close')
        await pg.set_input_files('[data-testid=a82-up-idFront]', CARD); await pg.set_input_files('[data-testid=a82-up-insFront]', CARD); await pg.wait_for_timeout(800)
        ok(T+'ID + insurance captured', await pg.locator('[data-testid=a82-cards] img').count() >= 2); await shot('04_arrival_cards'); await noscroll('arrival')
        await pg.click('[data-testid=a81-checkin]'); await pg.wait_for_timeout(600)
        # ---- 4 nursing checklist
        await role('Casey Morgan'); await bench('nursing'); ok(T+'nursing sections', await pg.locator('[data-testid=a82-nurse-sec]').count() == 5)
        await pg.click('[data-testid=a82-nurse-known]'); await pg.click('[data-testid=a81-listen]'); await pg.wait_for_timeout(300)
        boxes = pg.locator('[data-testid^=a81-ver-]')
        for i in range(await boxes.count()):
            if not await boxes.nth(i).is_checked(): await boxes.nth(i).check()
        for sel, v in [('vitals-bp', '128/78'), ('vitals-hr', '72'), ('vitals-spo2', '98'), ('vitals-temp', '98.2'), ('vitals-wt', '80'), ('npo-solids', '7:00 PM'), ('npo-clears', '5:00 AM'), ('iv-site', 'L hand'), ('iv-gauge', '20 g')]:
            if not await pg.input_value(f'[data-testid=a82-nv-{sel}]'): await pg.fill(f'[data-testid=a82-nv-{sel}]', v)
        ok(T+'x of y complete', 'complete' in await pg.inner_text('[data-testid=a82-nurse-progress]')); await shot('05_nursing_checklist'); await noscroll('nursing')
        await pg.click('[data-testid=a81-nurse-open]'); ok(T+'signature pad in PIN dialog', await pg.locator('[data-testid=pin-sigpad]').count()); await sign(); ok(T+'nursing locked', await pg.locator('[data-testid=a81-bench-nursing]').count() == 0)
        # ---- 5 anesthesia
        await role('Noor Haddad'); await bench('anesthesia', 'Desmond'); ok(T+'anesthesia med summary', await pg.locator('[data-testid=a82-medsummary]').count()); ok(T+'source links', await pg.locator('[data-testid=a82-src]').count() >= 3)
        for t in ['a82-aw-mallampati-ii', 'a82-aw-tmd-6cm', 'a82-aw-mouth-3fingers', 'a82-aw-neck-full', 'a82-aw-teeth-intact', 'a82-asa-ii', 'a82-type-general', 'a82-tech-lma']: await pg.click(f'[data-testid={t}]')
        for k in ['heart', 'lungs', 'neuro', 'npo', 'iv']: await pg.check(f'[data-testid=a82-exam-{k}]')
        await shot('06_anesthesia'); await noscroll('anesthesia')
        await pg.click('[data-testid=a82-anes-eval-open]'); await sign('Noor Haddad'); ok(T+'anesthesia eval signed', await pg.locator('[data-testid=a82-anes-eval-signed]').count())
        await pg.check('[data-testid=a82-attest]'); await pg.fill('[data-testid=a82-pre-note]', 'No change since evaluation.'); await pg.click('[data-testid=a82-pre-open]'); await sign('Noor Haddad'); ok(T+'pre-induction re-evaluation signed', await pg.locator('[data-testid=a81-bench-anesthesia]').count() == 0)
        await bench('anesthesia', 'Maren'); await pg.click('[data-testid=a81-ord-open]'); await sign('Noor Haddad'); ok(T+'PACU orders signed', await pg.locator('[data-testid=a81-orders-signed]').count())
        # ---- 6 surgeon
        await role('Sam Patel'); await bench('surgeon', 'Desmond'); ok(T+'surgeon med summary', await pg.locator('[data-testid=a82-medsummary]').count())
        await pg.click('[data-testid=a82-preOrders-open]'); await sign('Sam Patel'); ok(T+'pre-op orders signed', await pg.locator('[data-testid=a82-preOrders-signed]').count())
        if await pg.locator('[data-testid=a82-consent-ok]').count(): await pg.check('[data-testid=a82-consent-ok]'); await pg.click('[data-testid=a82-consent-open]'); await sign('Sam Patel')
        ok(T+'consent signed', await pg.locator('[data-testid=a82-consent-signed]').count())
        if await pg.locator('[data-testid=a82-hp-ok]').count():
            await pg.check('[data-testid=a82-hp-ok]')
            if await pg.locator('[data-testid=a82-mark-ok]').is_enabled(): await pg.check('[data-testid=a82-mark-ok]')
            await pg.click('[data-testid=a82-hp-open]'); await sign('Sam Patel')
        ok(T+'interval H&P signed', await pg.locator('[data-testid=a82-hp-signed]').count()); await shot('07_surgeon'); await noscroll('surgeon')
        # ---- 7 PACU full form
        await role('Alex Rivera'); await bench('pacu', 'Maren'); await pg.wait_for_timeout(800); ok(T+'PACU full form in place', await pg.locator('[data-testid=a82-pacu-form] iframe, [data-testid=a82-pacu-form] form, [data-testid=a82-pacu-form] input').count() > 0); ok(T+'PACU tasks', await pg.locator('[data-testid=a81-task]').count() >= 2); await shot('08_pacu_form')
        # ---- 8 discharge three signatures
        await bench('discharge', 'Maren'); await pg.click('[data-testid=a81-dc-open]'); await sign(); ok(T+'nurse signed', await pg.locator('[data-testid=a81-dc-signed]').count())
        await draw('[data-testid=a82-dc-pad-canvas]'); await pg.click('[data-testid=a82-dc-pt-save]'); ok(T+'patient drew signature', await pg.locator('[data-testid=a82-dc-pt-signed]').count())
        await pg.click('[data-testid=a82-dc-doc-open]'); await sign('Sam Patel'); ok(T+'physician signed', '3 of 3' in await pg.inner_text('[data-testid=a82-dc-count]')); await shot('09_discharge_signatures'); await noscroll('discharge')
        await pg.click('[data-testid=a81-close]')
        # ---- station panel: header card, forms with Open + summary + inline missing
        await role('Casey Morgan'); await nav('sv-nav-home'); rows = pg.locator('[data-testid=a8-station-row]')
        if await rows.count():
            await rows.first.click(); await pg.wait_for_selector('[data-testid=a8-step]')
            ok(T+'station header card', await pg.locator('[data-testid=a8-step] [data-testid=a82-case-card]').count()); ok(T+'station forms listed', await pg.locator('[data-testid=a82-station-form]').count() >= 2)
            ok(T+'Open buttons', await pg.locator('[data-testid=a82-open-form]').count() >= 1); await shot('10_station_forms'); await noscroll('station panel')
            await pg.locator('[data-testid=a82-open-form]').first.click(); await pg.wait_for_timeout(800); ok(T+'form opens in place', await pg.locator('[data-testid=a82-back-to-station]').count()); await shot('11_station_form_open')
            await pg.click('[data-testid=a8-close]')
        await role('Noor Haddad'); await nav('sv-nav-home'); rows = pg.locator('[data-testid=a8-station-row]')
        if await rows.count(): await rows.last.click(); await pg.wait_for_selector('[data-testid=a8-step]'); ok(T+'anesthesia station med history', await pg.locator('[data-testid=a8-step] [data-testid=a82-medsummary]').count()); await shot('12_station_anesthesia'); await pg.click('[data-testid=a8-close]')
        # ---- Practice Settings: no PIN
        await role('Practice Administrator'); await pg.locator('button:has(.fd-lbl:text-is("Practice Settings"))').first.evaluate('e=>e.click()'); await pg.wait_for_timeout(800)
        ok(T+'Practice Settings opens without a PIN', await pg.locator('[data-testid=pin-sign]').count() == 0 and await pg.locator('[data-testid=prac-medical-director]').count() > 0); await shot('13_practice_no_pin')
        await nav('sv-nav-schedule'); await pg.click('[data-testid=a81-day-briefing-btn]'); ok(T+'briefing X close', await pg.get_attribute('[data-testid=a81-brief-close]', 'aria-label') == 'Close'); await pg.click('[data-testid=a81-brief-close]'); await shot('14_schedule'); await noscroll('schedule')
        ok(T+'no page errors', not errs, '; '.join(errs)[:300]); await b.close()
async def main():
    for w in WIDTHS:
        try: await run(w)
        except Exception as e: ok(f'{w}: walk aborted', False, str(e)[:400])
    f = sum(1 for r in res if not r[1]); print(f'TOTAL {len(res)-f}/{len(res)} passed'); sys.exit(1 if f else 0)
asyncio.run(main())
