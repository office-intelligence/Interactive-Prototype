"""ASC.Vityls v9.0 walkthrough: full fictional episode at 1440 and 390. Fictional data; test PIN 1234."""
import asyncio, sys, os
from playwright.async_api import async_playwright
URL = sys.argv[1] if len(sys.argv) > 1 else 'http://localhost:8801/'
WIDTHS = [int(w) for w in sys.argv[2:]] or [1440, 390]
OUT = '/workspace/vityls/report/asc_v9.0.1_screens/best/'; os.makedirs(OUT, exist_ok=True)
CARD = '/tmp/fake_card.png'
res = []
def ok(name, cond, note=''): res.append((name, bool(cond), note)); print(('PASS' if cond else 'FAIL'), name, note, flush=True)
async def run(w):
    async with async_playwright() as p:
        b = await p.chromium.launch(executable_path='/usr/bin/google-chrome'); pg = await b.new_page(viewport={'width': w, 'height': 900 if w > 500 else 844}); pg.set_default_timeout(8000)
        errs = []; pg.on('pageerror', lambda e: errs.append(str(e))); pg.on('dialog', lambda d: asyncio.ensure_future(d.accept()))
        await pg.goto(URL + '?reset-test-data'); await pg.wait_for_timeout(2500)
        T = f'{w}:'
        async def shot(n):
            await pg.evaluate("()=>document.querySelectorAll('.a81-dbody,.a8-body').forEach(e=>e.scrollTop=0)"); await pg.screenshot(path=f'{OUT}{w}_{n}.png', full_page=True)
        async def noscroll(where):
            sw = await pg.evaluate('()=>document.documentElement.scrollWidth - window.innerWidth'); ok(T+f'no sideways scroll · {where}', sw <= 1, f'+{sw}px')
        async def role(label):
            s = pg.locator('select').first; opts = await s.evaluate("s=>[...s.options].map(o=>o.text)"); await s.select_option(label=[o for o in opts if label in o][0]); await pg.wait_for_timeout(600)
        async def nav(tid):
            await pg.locator(f'[data-testid={tid}]').first.evaluate('e=>e.click()'); await pg.wait_for_timeout(700)
        async def draw(sel):
            c = pg.locator(sel).first; await c.scroll_into_view_if_needed(); bb = await c.bounding_box()
            x, y = bb['x'] + 20, bb['y'] + bb['height'] / 2
            await pg.mouse.move(x, y); await pg.mouse.down()
            for i in range(1, 12): await pg.mouse.move(x + i * 14, y + (12 if i % 2 else -12))
            await pg.mouse.up(); await pg.wait_for_timeout(150)
        async def sign(who=None):
            await pg.wait_for_selector('[data-testid=pin-sign]')
            if who:
                opts = await pg.eval_on_selector('[data-testid=pin-who]', "s=>[...s.options].map(o=>o.text)"); await pg.select_option('[data-testid=pin-who]', label=[o for o in opts if who in o][0])
            else:
                v = await pg.eval_on_selector('[data-testid=pin-who]', 'e=>e.value')
                if not v: await pg.select_option('[data-testid=pin-who]', index=1)
            await draw('[data-testid=pin-sigpad-canvas]')
            await pg.fill('[data-testid=pin-input]', '1234'); await pg.click('[data-testid=pin-confirm]'); await pg.wait_for_timeout(500)
        async def bench(chip, patient=None):
            if await pg.locator('[data-testid=a81-close]').count(): await pg.click('[data-testid=a81-close]')
            await nav('sv-nav-home'); a = pg.locator('[data-testid=a81-chip-all]')
            if await pg.locator(f'[data-testid=a81-chip-{chip}]').count() == 0 and await a.count(): await a.click()
            await pg.click(f'[data-testid=a81-chip-{chip}]'); await pg.wait_for_selector(f'[data-testid=a81-bench-{chip}]')
            if patient:
                opts = await pg.eval_on_selector('[data-testid=a81-case-pick]', "s=>[...s.options].map(o=>o.text)"); await pg.select_option('[data-testid=a81-case-pick]', label=[o for o in opts if patient in o][0]); await pg.wait_for_timeout(300)
        async def fillsel(tid):
            v = await pg.eval_on_selector(f'[data-testid={tid}]', 'e=>e.value')
            if not v: await pg.select_option(f'[data-testid={tid}]', index=1)
        async def close_forms():
            for _ in range(3):
                x = pg.locator('.a82-form [aria-label="Close form"]')
                if await pg.locator('.a82-form').count() and await x.count(): await x.first.click(); await pg.wait_for_timeout(400)
        await pg.evaluate("()=>{window.print=()=>{window.__printed=(window.__printed||0)+1}}")
        LS = lambda: pg.evaluate("()=>JSON.stringify(Object.values(localStorage))")
        async def closeall():
            for _ in range(4):
                x = pg.locator('[data-testid=a88-card-close],[data-testid=a81-close],[data-testid=a8-close],[aria-label="Close"]')
                if await x.count():
                    try: await x.first.click(timeout=1500)
                    except Exception: pass
                    await pg.wait_for_timeout(250)
                else: break
        await role('Front Desk Tester'); await nav('sv-nav-home'); await pg.wait_for_timeout(700)
        P = lambda tid: pg.locator(f'[data-testid={tid}]')
        await role('Front Desk Tester'); await nav('sv-nav-home'); await pg.wait_for_timeout(700)
        bg = await pg.evaluate("()=>getComputedStyle(document.getElementById('sv-main')).backgroundColor"); ok(T+'mockup warm off-white page', bg.replace(' ', '') == 'rgb(251,247,241)', bg)
        sb = await pg.evaluate("()=>getComputedStyle(document.querySelector('.fd-side')).backgroundColor"); ok(T+'mockup sidebar tone', sb.replace(' ', '') == 'rgb(246,239,229)', sb)
        sh = await pg.evaluate("()=>{const e=document.querySelector('.n9-card');if(!e)return '';const s=getComputedStyle(e);return s.boxShadow+'|'+s.borderTopLeftRadius}"); ok(T+'cards: border + shadow + rounded', 'rgba' in sh and '12px' in sh, sh[:90])
        for tid in ['a87-patients', 'a87-todo', 'a87-kpis', 'a87-date', 'a87-ng']: ok(T+f'Today keeps {tid}', await P(tid).count() >= 1)
        ok(T+'patient cards keep Check in / Chart / Cancel', await P('a87-checkin').count() >= 1 and await P('a87-chart').count() >= 1 and await P('a87-cancel').count() >= 1)
        ok(T+'station pill rows (6 per case)', await pg.locator('.n9-sp').count() >= 6 * await P('a87-card').count())
        ok(T+'done pills mint, current terracotta', await pg.locator('.n9-sp.done').count() >= 1 and await pg.locator('.n9-sp.cur').count() >= 1)
        cc = await pg.evaluate("()=>getComputedStyle(document.querySelector('.n9-sp.cur')).backgroundColor"); ok(T+'current pill = terracotta', cc.replace(' ', '') == 'rgb(200,102,74)', cc)
        ok(T+'2x2 stats', await P('n9-stat').count() == 4); ok(T+'clearance legend renamed (no Hold)', 'Missing items' in await P('n9-summary').inner_text() and 'Hold' not in await P('n9-summary').inner_text())
        ok(T+'6-9 same-day cases', 6 <= await P('a87-card').count() <= 9, str(await P('a87-card').count()))
        await P('n9-room-Proc1').click(); await pg.wait_for_timeout(300); n1 = await P('a87-card').count(); await P('n9-room-All').click(); await pg.wait_for_timeout(300); ok(T+'room filter Proc 1', 1 <= n1 < await P('a87-card').count(), str(n1))
        ok(T+'top station shortcuts + bell', await pg.locator('[data-testid^=n9-top-]').count() == 6 and await P('n9-bell').count() == 1)
        ok(T+'collapsible To-do / Nightingale', await P('n9-todo-card').count() == 1 and await P('n9-ng-card').count() == 1)
        await P('n9-ask-input').fill('Which cases are not cleared?'); await P('n9-ask-go').click(); await pg.wait_for_timeout(300); ok(T+'Ask Nightingale bar answers (draft)', 'not cleared' in (await P('n9-ask-answer').inner_text()).lower()); await P('n9-ask-close').click()
        await noscroll('today'); await shot('01_today')
        card = pg.locator('[data-testid=a87-card]', has_text='Desmond').first; await card.locator('[data-testid=a84-ws-nursing]').evaluate('e=>e.click()'); await pg.wait_for_timeout(700)
        bw = await pg.evaluate("()=>{const d=document.querySelector('.a81-dialog');return d?d.getBoundingClientRect().width/window.innerWidth:0}"); ok(T+'station slide-over >= 92% width', bw >= 0.92, f'{bw:.2f}')
        rt = await pg.evaluate("()=>{const d=document.querySelector('.a81-dialog');return d?Math.round(window.innerWidth-d.getBoundingClientRect().right):99}"); ok(T+'anchored right', rt <= 1, str(rt))
        ok(T+'journey bar inside slide-over', await pg.locator('.a81-dialog [data-testid=a88-journey]').count() >= 1)
        await pg.screenshot(path=f'{OUT}{w}_02_station_slideover.png')
        await P('a88-step-anesthesia').first.click(); await pg.wait_for_timeout(600); ok(T+'station -> station same patient', ('Desmond' in await pg.inner_text('.a82-dcase')) if await pg.locator('.a82-dcase').count() else False)
        nx = P('a88-next-patient')
        if await nx.count():
            b0 = await pg.inner_text('.a82-dcase'); await nx.first.click(); await pg.wait_for_timeout(500); ok(T+'patient -> next patient', b0 != await pg.inner_text('.a82-dcase'))
        await closeall()
        await role('Casey Morgan'); await nav('sv-nav-home'); card = pg.locator('[data-testid=a87-card]', has_text='Desmond').first; await card.locator('[data-testid=a84-ws-or]').evaluate('e=>e.click()'); await pg.wait_for_timeout(700)
        ok(T+'OR panel near-full-screen', await pg.evaluate("()=>{const d=document.querySelector('.a8-panel');return d?d.getBoundingClientRect().width/window.innerWidth:0}") >= 0.92)
        ok(T+'OR event times strip: 6 tiles', await pg.locator('.a89-tile').count() == 6)
        for k in ['inRoom', 'anesStart', 'incision']:
            if await P(f'a89-tile-{k}').get_attribute('data-on') == '0': await P(f'a89-tile-btn-{k}').click(); await pg.wait_for_timeout(300)
        ok(T+'tap stamps current time', await P('a89-tile-incision').get_attribute('data-on') == '1')
        g = await pg.evaluate("()=>getComputedStyle(document.querySelector('[data-testid=a89-tile-incision]')).backgroundColor"); ok(T+'stamped tile tinted green', g.replace(' ', '') == 'rgb(227,242,232)', g)
        await P('a89-tile-btn-inRoom').click(); await P('a89-tile-time').fill('07:40'); await P('a89-tile-save').click(); await pg.wait_for_timeout(300)
        ok(T+'correction without reason not saved', '07:40' not in await pg.inner_text('[data-testid=a89-tile-inRoom]') or await P('a89-tile-time').count() == 1)
        if await P('a89-tile-time').count() == 0: await P('a89-tile-btn-inRoom').click()
        await P('a89-tile-time').fill('07:40'); await P('a89-tile-why').fill('Clock drift - corrected from wall clock (test)'); await P('a89-tile-save').click(); await pg.wait_for_timeout(400)
        tv = await pg.inner_text('[data-testid=a89-tile-inRoom]'); ok(T+'corrected time shown', '07:40' in tv, tv.replace('\n', ' '))
        s = await LS(); ok(T+'correction audit-logged with reason', 'Clock drift' in s)
        for k in ['close', 'anesEnd', 'outRoom']:
            if await P(f'a89-tile-{k}').get_attribute('data-on') == '0': await P(f'a89-tile-btn-{k}').click(); await pg.wait_for_timeout(300)
        ok(T+'billing minutes from recorded times', 'recorded' in await pg.inner_text('[data-testid=a89-or-billmin]'))
        await pg.locator('[data-testid=a89-ortimes]').screenshot(path=f'{OUT}{w}_03_or_times.png'); await pg.screenshot(path=f'{OUT}{w}_03b_or_slideover.png')
        await closeall()
        await role('Front Desk Tester'); await nav('sv-nav-billing'); await pg.wait_for_timeout(800)
        for tid in ['b89-period', 'b89-nightingale', 'b89-scrub', 'b89-refresh', 'b89-ask', 'b89-kpis', 'b89-worklist', 'b89-aging', 'b89-surgeons', 'b89-claims', 'b89-accounts', 'b89-case-invoices', 'b89-create', 'b89-config', 'b89-ledger-toggle']: ok(T+f'billing: {tid}', await P(tid).count() >= 1)
        ok(T+'6 KPI tiles', await P('b89-kpi').count() == 6, str(await P('b89-kpi').count())); ok(T+'4 insights', await P('b89-insight').count() >= 4)
        ok(T+'10 config tabs', await pg.locator('[role=tab][data-testid^=b89-cfg-]').count() >= 10)
        await P('b89-ask').fill('What is my clean claim rate?'); await P('b89-ask-go').click(); await pg.wait_for_timeout(300); ok(T+'Nightingale answers (draft)', await P('b89-answer').count() == 1)
        await noscroll('billing'); await shot('04_billing')
        if w < 500:
            await nav('sv-nav-patients'); await pg.wait_for_timeout(500); await pg.get_by_text('Desmond').first.click(); await pg.wait_for_timeout(800)
            ok(T+'chart on phone', await P('a83-chart').count() == 1); await noscroll('chart phone'); await shot('06_chart')
            ok(T+'no page errors', not errs, '; '.join(errs[:2])); return
        await P('b89-cfg-fees').click(); await pg.wait_for_timeout(300); ok(T+'fee schedules tab = one schedule editor', await P('b89-fees').count() == 1 and await P('b89-fee-facility-base').count() == 1)
        await P('b89-fees').screenshot(path=f'{OUT}{w}_05_fee_schedule.png')
        row = pg.locator('[data-testid=b89-acct-row]', has_text='Balance due').first; ok(T+'account with balance due', await row.count() == 1); who = (await row.locator('td').first.inner_text()).split('\n')[0].strip(); print('patient', who)
        await nav('sv-nav-patients'); await pg.wait_for_timeout(600); await pg.get_by_text(who, exact=True).first.click(); await pg.wait_for_timeout(800)
        ok(T+'case record: 8 station events', await P('n9-rec-ev').count() == 8); ok(T+'living summary + allergy card + clearance docs', await P('n9-living').count() == 1 and await P('n9-allergy').count() == 1 and await P('n9-clear-docs').count() == 1)
        if await P('n9-allergy-confirm').count(): await P('n9-allergy-confirm').click(); await pg.wait_for_timeout(300); ok(T+'allergy confirm logged', 'asc90.allergy-confirm' in await LS())
        await P('n9-os-anesthesia').click(); await pg.wait_for_timeout(600); ok(T+'open-a-station pill -> slide-over', await pg.locator('.a81-dialog').count() >= 1); await closeall()
        await P('n9-rec-or').click(); await pg.wait_for_timeout(600); ok(T+'timeline event opens its station', await pg.locator('.a8-panel, .a81-dialog').count() >= 1); await closeall()
        await P('a83-chart-tab-cases').click(); await pg.wait_for_timeout(200)
        for tid in ['a89-btn-profile', 'a89-btn-print', 'a89-btn-collect', 'a87-chart-back', 'a89-attn', 'a89-snap', 'a89-timeline', 'a83-chart-cases', 'a83-chart-tab-documents', 'a83-chart-tab-billing', 'a83-chart-tab-overview']: ok(T+f'chart: {tid}', await P(tid).count() >= 1)
        await noscroll('chart'); await P('a83-chart-tab-documents').click(); await shot('06_chart')
        await P('a89-btn-collect').click(); await P('a89-credit-amt').fill('300'); await P('a89-credit-method').select_option('Credit card'); await P('a89-credit-notes').fill('Deposit handed over at front desk (test)')
        await pg.locator('[data-testid=a89-credit]').screenshot(path=f'{OUT}{w}_07_collect_payment.png'); await P('a89-credit-save').click(); await pg.wait_for_timeout(400)
        ok(T+'card method opens card popup', await P('a88-cardpop').count() == 1)
        TP = ' '.join(['4242'] * 4)
        await P('a88-card-num').fill(TP); await P('a88-card-exp').fill('12/30'); await P('a88-card-cvv').fill('123')
        if await P('a88-card-zip').count(): await P('a88-card-zip').fill('90000')
        await P('a88-card-pay').click(); await pg.wait_for_timeout(700); ok(T+'receipt shows available credit', await P('a88-rc-credit').count() == 1)
        if await P('a88-rc-done').count(): await P('a88-rc-done').click(); await pg.wait_for_timeout(300)
        ct = await P('a89-chart-credit').inner_text(); ok(T+'chart shows 300 credit', '300.00' in ct, ct)
        s = await LS(); ok(T+'credit audited, full number not stored', 'asc89.credit' in s and TP.replace(' ', '') not in s.replace(' ', ''))
        SSN = '-'.join(['000', '12', '6789'])
        await P('a89-btn-profile').click(); await P('a89-pf-address').fill('100 Example Lane'); await P('a89-pf-city').fill('Testville'); await P('a89-pf-ssn').fill(SSN); await P('a89-pf-em0-name').fill('Jordan Example')
        await P('a89-profile-save').click(); await pg.wait_for_timeout(400); s = await LS(); ok(T+'profile saved + audit-logged', 'asc89.profile' in s and '100 Example Lane' in s)
        await P('a89-btn-print').click(); await pg.wait_for_timeout(400); ok(T+'5 print tabs', await pg.locator('[data-testid^=a89-ptab-]').count() == 5)
        ft = (await P('a89-facesheet').inner_text()).lower(); ok(T+'facesheet sections 1-6 + attestation', all(x in ft for x in ['1. patient identification', '4. primary', '6. scanned', 'physician review']))
        ok(T+'SSN masked', '***-**-6789' in ft and SSN not in ft); ok(T+'address from profile', '100 example lane' in ft); ok(T+'missing data shows Not recorded', 'not recorded' in ft)
        await pg.locator('[data-testid=a89-print]').screenshot(path=f'{OUT}{w}_08_print_facesheet.png')
        await P('a89-print-go').click(); await pg.wait_for_timeout(300); ok(T+'manual print logged', (await pg.evaluate('()=>window.__printed||0')) >= 1 and 'Patient chart documentation' in await LS())
        for k in ['labels', 'visit', 'cards', 'audit']: await P(f'a89-ptab-{k}').click(); await pg.wait_for_timeout(150)
        ok(T+'all print tabs render', await P('a89-print-audit').count() == 1); await P('a89-print-close').click()
        await P('a83-chart-tab-documents').click(); await pg.wait_for_timeout(400); ok(T+'category chips', all([await P(f'a89-cat-{k}').count() == 1 for k in ['All', 'Pre-op-Clearance', 'Nursing', 'Anesthesia', 'OP-Reports']]))
        n_all = await P('a83-doc').count(); await P('a89-cat-Pre-op-Clearance').click(); await pg.wait_for_timeout(300)
        tags = await P('a89-doc-cat').all_inner_texts(); ok(T+'filter shows only that category', len(tags) <= n_all and all(t == 'Pre-op Clearance' for t in tags), f'{len(tags)}/{n_all}')
        await P('a83-chart-docs').screenshot(path=f'{OUT}{w}_09_documents_categories.png'); await P('a89-cat-All').click()
        await P('a83-chart-tab-billing').click(); await pg.wait_for_timeout(400); br = pg.locator('[data-testid=a83-bill-row]').filter(has=pg.locator('[data-testid=a83-bill-collect]')).first; await br.locator('[data-testid=a87-chart-invoice]').click(); await pg.wait_for_timeout(500)
        if await P('a87-inv-gen').count(): await P('a87-inv-gen').first.click(); await pg.wait_for_timeout(500)
        it = await P('a87-inv-doc').inner_text(); ok(T+'invoice: deposit credit applied', 'Account credit applied' in it and '300.00' in it)
        ok(T+'invoice from the one fee schedule', 'Facility' in it and 'Anesthesia' in it)
        await pg.screenshot(path=f'{OUT}{w}_10_invoice_credit_applied.png')
        print('invoice', await P('a87-inv-total').inner_text(), await P('a87-inv-balance').inner_text())
        await closeall(); await nav('sv-nav-patients'); await pg.wait_for_timeout(500); await pg.get_by_text(who, exact=True).first.click(); await pg.wait_for_timeout(700)
        ct = await P('a89-chart-credit').inner_text(); ok(T+'credit consumed after invoice', '300.00' not in ct, ct)
        ok(T+'no page errors', not errs, '; '.join(errs[:2]))

async def main():
    for w in WIDTHS: await run(w)
    f = [r for r in res if not r[1]]; print(f'{len(res)-len(f)}/{len(res)} passed'); [print('FAIL', *r) for r in f]
asyncio.run(main())
